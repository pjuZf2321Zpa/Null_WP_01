<?php

/**
 * WP All Import Cli Class.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PMXI_Cli
 */
class PMXI_Cli {

    /**
     * ## OPTIONS
     *
     * <import_id>
     * : ID of the import.
     *
     * [--disable-log]
     * : Whether or not save import logs.
     *
     * [--force-run]
     * : Run import even it was already triggered.
     *
     * [--resume]
     * : Continue a previously started run from its saved chunk cursor instead
     * of restarting from the beginning. Safe to pass on every invocation: if
     * the import isn't actually mid-run, or its last run was canceled, it
     * behaves like a normal fresh start.
     *
     * [--time-limit=<seconds>]
     * : Stop after roughly this many seconds and exit, leaving the import
     * resumable with --resume. With several import IDs this is the budget for
     * the whole command, shared evenly: the imports run least recently run
     * first, each gets its share of the time that is left, and any that could
     * not start are named and go first on the next call. Each import that
     * starts processes at least one batch, so the command can run past the
     * limit by up to one batch per import. Without this flag (and without
     * --limit) a run processes to completion in one invocation, same as before.
     *
     * [--limit=<records>]
     * : Stop each import after processing roughly this many records and exit,
     * leaving it resumable with --resume. With several import IDs the limit
     * applies to each import separately. Can be combined with --time-limit;
     * whichever is reached first stops the batch.
     *
     * ## EXAMPLES
     *
     *     wp all-import run 1
     *     wp all-import run 1 --disable-log
     *     wp all-import run 1 --limit=500 --resume
     *     wp all-import run 1 --time-limit=1800 --resume
     *
     *     # From your own cron: invoke repeatedly with --resume until the
     *     # command reports "Import completed" instead of a resume prompt.
     *
     * @when after_wp_load
     * @param $args
     * @param $assoc_args
     */
    function run( $args, $assoc_args ) {

        list( $import_ids ) = $args;

	    $import_ids = explode(',', $import_ids );
	    $failed = 0;

        $resume = array_key_exists('resume', $assoc_args);

        $time_limit = $this->positiveIntFlag($assoc_args, 'time-limit');
        $record_limit = $this->positiveIntFlag($assoc_args, 'limit');

        $deadline = null === $time_limit ? null : time() + $time_limit;
        $not_started = [];
        if ( null !== $deadline && count($import_ids) > 1 ) {
            // Least recently run first, so an import the budget did not reach on the last call is not skipped again.
            $import_ids = $this->leastRecentlyRunFirst($import_ids);
        }

        $several = count($import_ids) > 1;
        $force = array_key_exists('force-run', $assoc_args);

        foreach( $import_ids as $position => $import_id) {
            if ( null !== $deadline && time() >= $deadline ) {
                $not_started[] = $import_id;
                continue;
            }
            $run_lock = null;
            try {
				// Set the import ID currently running.
				add_filter('wp_all_import_cli_import_id', function() use ($import_id){ return $import_id;});

            	$logger = function($m) {
		            print("<p>[". wp_all_import_local_date("H:i:s") ."] ".wp_all_import_filter_html_kses($m)."</p>\n");
	            };
                $logger = apply_filters('wp_all_import_logger', $logger);
                if (array_key_exists('disable-log', $assoc_args)) {
                    $logger = NULL;
                }
                $import = new PMXI_Import_Record();
                $import->getById($import_id);

                if ($import->isEmpty()) {
                    $this->refuse($import_id, __('Import not found.', 'wp-all-import-pro'), $several);
                    $failed++;
                    continue;
                }

                // Held for the whole run: registered_on is not refreshed during a download or a long chunk, so it cannot tell a live CLI run from a dead one.
                $run_lock = $this->takeRunLock($import->id);
                if (false === $run_lock) {
                    $this->refuse($import_id, __('Import already running.', 'wp-all-import-pro'), $several);
                    $failed++;
                    continue;
                }

                // A canceled run keeps its cursor, so without this a cron loop passing --resume would undo the Cancel.
                $resuming = $resume && ! $import->canceled && ($import->triggered || $import->queue_chunk_number);

	            $refusal = '';
	            if ($import->executing && ! $force) {
		            $refusal = __('Import already running.', 'wp-all-import-pro');
	            } elseif ($resuming) {
		            // Same 120 s stale-lock failsafe as the cron processing request, for a CLI process killed mid-chunk; --force-run with the CLI lock in hand skips the wait.
		            if ($import->processing == 1 && ((time() - strtotime($import->registered_on)) > 120 || ($force && $run_lock))) {
			            $import->set(['processing' => 0])->update();
		            }
		            if ($import->processing == 1 && ! $force) {
			            $refusal = __('Import already running.', 'wp-all-import-pro');
		            }
	            } elseif ($import->triggered && (int) $import->queue_chunk_number && ! $import->processing && ! $force) {
		            $refusal = sprintf(__('Import #%d is partway through a run that is not processing right now. Run it again with --resume to continue, or with --force-run to start over.', 'wp-all-import-pro'), $import->id);
	            } elseif (($import->triggered || $import->processing) && ! $force) {
		            $refusal = __('Import already running.', 'wp-all-import-pro');
	            }

	            $gate = \Wpai\App\Gate\Gate::instance();

	            // A fresh run is about to reset the cursor blocksRun() reads, so only a resumed run may finish in flight.
	            if ('' === $refusal && ($resuming ? $gate->blocksRun($import) : $gate->blocks())) {
	                $refusal = $gate->apiRefusal();
	            }

	            if ('' !== $refusal) {
	                $this->refuse($import_id, $refusal, $several);
	                $failed++;
	                continue;
	            }

	            $registered_before = $import->registered_on;

                // The cron request's own 120 s failsafe reads registered_on, so a stale stamp would let it take over this run.
                if ($resuming) {
                    $import->set(['registered_on' => date('Y-m-d H:i:s')])->update();
                } else {
                    $import->set([
                        'registered_on' => date('Y-m-d H:i:s'),
                        'triggered' => 1,
                        'imported' => 0,
                        'canceled' => 0,
                        'created' => 0,
                        'updated' => 0,
                        'skipped' => 0,
                        'queue_chunk_number' => 0,
                        'processing' => 0
                    ])->update();
                }

                $log_storage = (int) PMXI_Plugin::getInstance()->getOption('log_storage');

                $history_log = false;
                if ($resuming) {
                    $byRecent = [];
                    $byRecent[] = [['import_id' => $import->id], 'AND'];
                    $recentLogs = new PMXI_History_List();
                    $recentLogs->setColumns('id', 'import_id', 'type', 'date')->getBy($byRecent, 'id DESC');
                    if ($recentLogs->count()) {
                        $candidate = new PMXI_History_Record();
                        $candidate->getBy('id', $recentLogs[0]['id']);
                        if ( ! $candidate->isEmpty() && $candidate->type === 'cli') {
                            $history_log = $candidate;
                        }
                    }
                }
                $time_run_before = $history_log ? (int) $history_log->time_run : 0;
                if ( ! $history_log) {
                    $by = [];
                    $by[] = [['import_id' => $import->id], 'AND'];
                    $historyLogs = new PMXI_History_List();
                    $historyLogs->setColumns('id', 'import_id', 'type', 'date')->getBy($by, 'id ASC');
                    if ($historyLogs->count() and $historyLogs->count() >= $log_storage ) {
                        $logsToRemove = $historyLogs->count() - $log_storage;
                        foreach ($historyLogs as $i => $file) {
                            $historyRecord = new PMXI_History_Record();
                            $historyRecord->getBy('id', $file['id']);
                            if ( ! $historyRecord->isEmpty()) $historyRecord->delete(); // unlink history file only
                            if ($i == $logsToRemove)
                                break;
                        }
                    }

                    $history_log = new PMXI_History_Record();
                    $history_log->set([
                        'import_id' => $import->id,
                        'date' => date('Y-m-d H:i:s'),
                        'type' => 'cli'
                    ])->save();
                }

                $cursor_before = (int) $import->queue_chunk_number;
                $processed_before = (int) $import->imported + (int) $import->skipped;
                $start = time();
                ob_start();
                // Not $history_log->id: execute() deletes the row it is given when the source is gone, losing earlier batches.
                // An even share of what is left, so the first import cannot use up the budget on every call and starve the rest.
                $budget = null === $deadline ? null : max(1, (int) floor(($deadline - time()) / (count($import_ids) - $position)));
                $response = $import->execute($logger, true, false, $budget, $record_limit);
                $failure = $this->runFailure($response);
                if ( '' !== $failure && $logger && (int) $response['status'] >= 500 ) {
                    call_user_func($logger, '<b>' . __('ERROR', 'wp-all-import-pro') . '</b>: ' . $failure);
                }
                $log_data = ob_get_clean();
                $end = time();
                if ($log_storage && $logger) {
                    $wp_uploads = wp_upload_dir();
                    $log_file = wp_all_import_secure_file($wp_uploads['basedir'] . DIRECTORY_SEPARATOR . \PMXI_Plugin::LOGS_DIRECTORY, $history_log->id) . DIRECTORY_SEPARATOR . $history_log->id . '.html';
                    $log = @fopen($log_file, 'a+');
                    if (is_resource($log)) {
                        @fwrite($log, $log_data);
                        @fclose($log);
                    }
                }
                if ( '' !== $failure ) {
                    // execute() leaves the run triggered for the next cron request to retry; the CLI makes no further request.
                    $import->getById($import->id);
                    $import->set([
                        'triggered' => 0,
                        'processing' => 0,
                    ])->update();
                    $history_log->getById($history_log->id);
                    if ( ! $history_log->isEmpty() ) {
                        $history_log->set([
                            'time_run' => $time_run_before + $end - $start,
                            'summary' => $failure
                        ])->save();
                    }
                    WP_CLI::warning(sprintf(__('Import #%1$s failed: %2$s', 'wp-all-import-pro'), $import->id, $failure));
                    $failed++;
                    continue;
                }
                if ( (int) $import->triggered && (int) $import->queue_chunk_number === $cursor_before && (int) $import->imported + (int) $import->skipped === $processed_before ) {
                    $stalled = sprintf(__('Import #%d made no progress because it is still marked as processing. If nothing else is running it, run it again with --resume --force-run.', 'wp-all-import-pro'), $import->id);
                    // The take-over stamp would hold off the 120 s failsafe for a run that never moved.
                    $import->set(['registered_on' => $registered_before])->update();
                    $history_log->getById($history_log->id);
                    if ( ! $history_log->isEmpty() ) {
                        $history_log->set([
                            'time_run' => $time_run_before + $end - $start,
                            'summary' => $stalled
                        ])->save();
                    }
                    WP_CLI::warning($stalled);
                    $failed++;
                    continue;
                }
                $items = [
                    [
                        'Created' => $import->created,
                        'Updated' => $import->updated,
                        'Skipped' => $import->skipped,
                        'Deleted' => $import->deleted,
                        'Changed Missing' => $import->changed_missing,
                        'Count' => $import->count,
                    ]
                ];
                WP_CLI\Utils\format_items( 'table', $items, [ 'Created', 'Updated', 'Skipped', 'Deleted', 'Changed Missing', 'Count' ] );

                if ( (int) $import->queue_chunk_number ) {
                    WP_CLI::success( sprintf(
                        __('Records processed %d of %d. [ time: %s ] Re-run with --resume to continue.', 'wp-all-import-pro'),
                        (int) $import->imported + (int) $import->skipped,
                        (int) $import->count,
                        human_time_diff($start, $end)
                    ) );
                } else {
                    WP_CLI::success( sprintf(__('Import completed. [ time: %s ]', 'wp-all-import-pro'), human_time_diff($start, $end)));
                }

                $custom_type = wp_all_import_custom_type_labels($import->options['custom_type'], $import->options['taxonomy_type']);
                $log_msg = sprintf(__("%d %s created %d updated %d skipped", "wp-all-import-pro"), $import->created, ( ($import->created == 1) ? $custom_type->labels->singular_name : $custom_type->labels->name ), $import->updated, $import->skipped);
                if ($import->options['is_delete_missing']) {
                    if (empty($this->options['delete_missing_action']) || $this->options['delete_missing_action'] != 'remove') {
                        $log_msg = sprintf(__("%d %s created %d updated %d changed missing %d skipped", "wp-all-import-pro"), $import->created, ( ($import->created == 1) ? $custom_type->labels->singular_name : $custom_type->labels->name ), $import->updated, $import->changed_missing, $import->skipped);
                    } else {
                        $log_msg = sprintf(__("%d %s created %d updated %d deleted %d skipped", "wp-all-import-pro"), $import->created, ( ($import->created == 1) ? $custom_type->labels->singular_name : $custom_type->labels->name ), $import->updated, $import->deleted, $import->skipped);
                    }
                }
                $history_log->set([
                    'time_run' => $time_run_before + $end - $start,
                    'summary' => $log_msg
                ])->save();
            } catch (Exception $e) {
                WP_CLI::error($e->getTraceAsString());
            } finally {
                if ($run_lock) {
                    $this->releaseRunLock($import_id);
                }
            }
        }

        if ( $not_started ) {
            WP_CLI::warning(sprintf(__('The time limit was reached before these imports could start: %1$s. Run them with --resume to continue, for example: wp all-import run %2$s --resume', 'wp-all-import-pro'), '#' . implode(', #', $not_started), implode(',', $not_started)));
        }

        if ( $failed ) {
            WP_CLI::error(sprintf(_n('%d import failed.', '%d imports failed.', $failed, 'wp-all-import-pro'), $failed));
        }
    }

    /**
     * One import that cannot run must not stop the others, so with several IDs it is skipped rather than fatal.
     *
     * @param string $import_id
     * @param string $message
     * @param bool $several
     */
    private function refuse( $import_id, $message, $several ) {
        if ( ! $several ) {
            WP_CLI::error($message);
        }
        WP_CLI::warning(sprintf(__('Import #%1$s skipped: %2$s', 'wp-all-import-pro'), $import_id, $message));
    }

    /**
     * @param string[] $import_ids
     * @return string[]
     */
    private function leastRecentlyRunFirst( $import_ids ) {
        $order = [];
        foreach ($import_ids as $position => $import_id) {
            $import = new PMXI_Import_Record();
            $import->getById($import_id);
            $order[] = [$import->isEmpty() ? '' : (string) $import->registered_on, $position, $import_id];
        }
        sort($order);

        return array_column($order, 2);
    }

    /**
     * @param int $import_id
     * @return bool|null True when taken, false when another connection holds it, null when the database has no named locks.
     */
    private function takeRunLock( $import_id ) {
        global $wpdb;
        $suppress = $wpdb->suppress_errors(true);
        $taken = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $this->runLockName($import_id)));
        $wpdb->suppress_errors($suppress);

        return null === $taken ? null : '1' === (string) $taken;
    }

    /**
     * @param int $import_id
     */
    private function releaseRunLock( $import_id ) {
        global $wpdb;
        $suppress = $wpdb->suppress_errors(true);
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $this->runLockName($import_id)));
        $wpdb->suppress_errors($suppress);
    }

    /**
     * @param int $import_id
     * @return string
     */
    private function runLockName( $import_id ) {
        global $wpdb;

        // Named locks are server-wide and capped at 64 characters, so the site is hashed in.
        return 'wpai_cli_run_' . substr(md5((defined('DB_NAME') ? DB_NAME : '') . $wpdb->prefix), 0, 16) . '_' . (int) $import_id;
    }

    /**
     * @param array $assoc_args
     * @param string $flag
     * @return int|null
     */
    private function positiveIntFlag( $assoc_args, $flag ) {
        if ( ! array_key_exists($flag, $assoc_args) ) {
            return null;
        }
        $value = $assoc_args[$flag];
        if ( ! is_string($value) || ! preg_match('/^[1-9][0-9]*$/', trim($value)) ) {
            WP_CLI::error(sprintf(__('--%s must be a whole number greater than 0.', 'wp-all-import-pro'), $flag));
        }

        return (int) $value;
    }

    /**
     * @param mixed $response What PMXI_Import_Record::execute() returned.
     * @return string The reason the run stopped, or '' when it did not fail.
     */
    private function runFailure( $response ) {
        if ( ! is_array($response) || ! isset($response['status']) || (int) $response['status'] < 400 ) {
            return '';
        }
        $message = isset($response['message']) ? $response['message'] : '';
        $message = trim(strip_tags(is_array($message) ? implode(' ', $message) : (string) $message));

        return '' === $message ? __('The import could not run.', 'wp-all-import-pro') : $message;
    }

    /**
     * ## EXAMPLES
     *
     *     wp all-import list
     *
     * @when after_wp_load
     *
     * @subcommand list
     * @param $args
     * @param $assoc_args
     */
    function _list( $args, $assoc_args ) {

        $gate = \Wpai\App\Gate\Gate::instance();

        if ($gate->blocks()) {
            WP_CLI::error($gate->apiRefusal());
        }

        try {
            $items = [];
            $imports = new PMXI_Import_List();
            foreach ($imports->setColumns($imports->getTable() . '.*')->getBy(array('id !=' => '', 'is_preview' => 0))->convertRecords() as $import){
                $import->getById($import->id);
                if ( ! $import->isEmpty() && $import->parent_import_id != 99999 ){
                    $items[] = [
                        'ID' => $import->id,
                        'Name' => empty($import->friendly_name) ? $import->name : $import->friendly_name,
                        'Created' => $import->created,
                        'Updated' => $import->updated,
                        'Skipped' => $import->skipped,
                        'Deleted' => $import->deleted,
                        'Changed Missing' => $import->changed_missing,
                        'Count' => $import->count,
                        'Last Activity' => $import->last_activity
                    ];
                }
            }

            WP_CLI\Utils\format_items( 'table', $items, array( 'ID', 'Name', 'Created', 'Updated', 'Skipped', 'Deleted', 'Changed Missing', 'Count', 'Last Activity' ) );

        } catch (Exception $e) {
            WP_CLI::error($e->getMessage());
        }
    }

    /**
     * Reports whether the licence gate is enforcing, and if not, why not.
     *
     * ## OPTIONS
     *
     * [--format=<format>]
     * : Accepted values: table, json. Default: table.
     *
     * ## EXAMPLES
     *
     *     wp all-import license-gate
     *     wp all-import license-gate --format=json
     *
     * @when after_wp_load
     * @subcommand license-gate
     */
    function license_gate( $args, $assoc_args ) {

        $described = \Wpai\App\Gate\Gate::instance()->describe();

        $format = isset( $assoc_args['format'] ) ? $assoc_args['format'] : 'table';

        if ( $format === 'json' ) {
            WP_CLI::line( wp_json_encode( $described ) );

            return;
        }

        $rows = array(
            array( 'field' => 'enforcing', 'value' => $described['enforcing'] ? 'yes' : 'no' ),
            array( 'field' => 'reason', 'value' => $described['blocked_reason'] ),
            array( 'field' => 'blocking', 'value' => $described['blocking'] ? 'yes' : 'no' ),
            array( 'field' => 'licence_source', 'value' => $described['source'] ),
            array( 'field' => 'licence_source_available', 'value' => $described['source_available'] ? 'yes' : 'no' ),
            array( 'field' => 'edition', 'value' => (string) $described['edition'] ),
        );

        WP_CLI\Utils\format_items( 'table', $rows, array( 'field', 'value' ) );
    }
}
