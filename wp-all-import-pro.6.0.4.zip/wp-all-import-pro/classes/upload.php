<?php
if ( ! class_exists( 'PMXI_Upload' ) ) {

	class PMXI_Upload {

		protected $file;
		protected $errors;
		protected $root_element = '';
		protected $is_csv       = false;

		protected $uploadsPath;

		protected $import_id = 0;

		protected $parse_options;

		protected $bundle_marker = null;

		protected $file_format = '';

		protected $csv_dialect = null;

		/**
		 * @param array|null $parse_options csv_escape and keep_4byte_chars for the import the file is
		 *                                  converted for. Null reads them from the import the request names,
		 *                                  and falls back to the behavior of imports saved before they existed.
		 */
		function __construct( $file, $errors, $targetDir = false, $parse_options = null ) {

			$this->file   = $file;
			$this->errors = $errors;

			$uploads = wp_upload_dir();

			$input     = new PMXI_Input();
			$import_id = $input->get( 'id' );
			// Get import ID from cron processing URL.
			if ( empty( $import_id ) ) {
				$import_id = $input->get( 'import_id' );
			}
			// Get import ID from CLI arguments.
			if ( empty( $import_id ) && PMXI_Plugin::getInstance()->isCli() ) {
				$import_id = wp_all_import_get_import_id();
			}
			$this->import_id = $import_id;
			if ( ! is_array( $parse_options ) ) {
				$parse_options = PMXI_ParseOptions::for_import_id( $import_id );
			}
			$this->parse_options = is_array( $parse_options ) ? PMXI_ParseOptions::from_import_options( $parse_options ) : PMXI_ParseOptions::legacy();
			if ( $uploads['error'] ) {
				$this->uploadsPath = false;
			} else {
				$this->uploadsPath = wp_all_import_get_absolute_path( ( ! $targetDir ) ? wp_all_import_secure_file( $uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::UPLOADS_DIRECTORY, $import_id, true ) : $targetDir );
			}
		}

		public function upload() {

			$this->file = wp_all_import_get_absolute_path( $this->file );

			$templates = false;

			$bundle = array();

			$bundleFiles = array();

			$csv_path = '';

			if ( empty( $this->file ) ) {
				$this->errors->add( 'form-validation', __( 'Please specify a file to import.<br/><br/>If you are uploading the file from your computer, please wait for it to finish uploading (progress bar at 100%), before trying to continue.', 'wp-all-import-pro' ) );
			} elseif ( ! is_file( $this->file ) ) {
				$this->errors->add( 'form-validation', __( 'Uploaded file is empty', 'wp-all-import-pro' ) );
			} elseif ( ! preg_match( '%\W(xml|gzip|zip|csv|tsv|gz|json|txt|dat|psv|sql|xls|xlsx)$%i', trim( basename( $this->file ) ) ) ) {
				$this->errors->add( 'form-validation', __( 'Uploaded file must be XML, CSV, ZIP, GZIP, GZ, JSON, SQL, TXT, DAT or PSV', 'wp-all-import-pro' ) );
			} elseif ( preg_match( '%\W(zip)$%i', trim( basename( $this->file ) ) ) ) {

				if ( ! class_exists( 'WpaiPclZip' ) ) {
					include_once PMXI_Plugin::ROOT_DIR . '/libraries/wpaipclzip.lib.php';
				}

				$archive = new WpaiPclZip( $this->file );

				// Get allowed file extensions (whitelist approach)
				$allowed_extensions = wp_all_import_get_allowed_zip_extensions();

				// Attempt to extract files with whitelist restrictions
				$v_result_list = $archive->extract( WPAI_PCLZIP_OPT_PATH, $this->uploadsPath, WPAI_PCLZIP_OPT_REPLACE_NEWER, WPAI_PCLZIP_OPT_EXTRACT_DIR_RESTRICTION, $this->uploadsPath, WPAI_PCLZIP_OPT_EXTRACT_WHITELIST_RESTRICTIONS, $allowed_extensions );
				if ( empty( $v_result_list ) || ! is_array( $v_result_list ) && $v_result_list < 1 ) {
					$this->errors->add( 'form-validation', __( 'WP All Import couldn\'t find a file to import inside your ZIP.<br/><br/>Either the .ZIP file is broken, or doesn\'t contain a file with an extension of  XML, CSV, PSV, DAT, or TXT. <br/>Please attempt to unzip your .ZIP file on your computer to ensure it is a valid .ZIP file which can actually be unzipped, and that it contains a file which WP All Import can import.', 'wp-all-import-pro' ) );
				} else {
					$filePath         = '';
					$decodedTemplates = array();
					if ( ! empty( $v_result_list ) ) {
						foreach ( $v_result_list as $unzipped_file ) {
							if ( $unzipped_file['status'] == 'ok' and preg_match( '%\W(php)$%i', trim( $unzipped_file['stored_filename'] ) ) ) {
								unlink( $unzipped_file['filename'] );
								continue;
							}
							if ( $unzipped_file['status'] == 'ok' and preg_match( '%\W(xml|csv|txt|dat|psv|json|xls|xlsx|gz)$%i', trim( $unzipped_file['stored_filename'] ) ) and strpos( $unzipped_file['stored_filename'], 'readme.txt' ) === false ) {
								if ( strpos( basename( $unzipped_file['stored_filename'] ), 'WP All Import Template' ) === 0 || strpos( basename( $unzipped_file['stored_filename'] ), 'templates_' ) === 0 ) {
									$templates        = file_get_contents( $unzipped_file['filename'] );
									$decodedTemplates = json_decode( $templates, true );
									$templateOptions  = empty( $decodedTemplates[0] ) ? current( $decodedTemplates ) : $decodedTemplates;
									$this->set_bundle_marker( $templateOptions );
									if ( ! empty( $templateOptions ) and isset( $templateOptions[0]['_import_type'] ) and $templateOptions[0]['_import_type'] == 'url' ) {
										$options = \pmxi_maybe_unserialize( $templateOptions[0]['options'] );
										return array(
											'filePath'     => $templateOptions[0]['_import_url'],
											'bundle'       => $bundle,
											'bundle_xpath' => $templateOptions[0]['bundle_xpath'] ?? '',
											'template'     => json_encode( $templateOptions ),
											'templates'    => $templates,
											'post_type'    => ( ! empty( $options ) ) ? $options['custom_type'] : false,
											'taxonomy_type' => ( ! empty( $options['taxonomy_type'] ) ) ? $options['taxonomy_type'] : false,
											'gravity_form_title' => ( ! empty( $options['gravity_form_title'] ) ) ? $options['gravity_form_title'] : false,
											'is_empty_bundle_file' => true,
										);
									}
								} else {
									if ( $filePath == '' ) {
										$filePath = $unzipped_file['filename'];
									}
									if ( ! in_array( $unzipped_file['filename'], $bundleFiles ) ) {
										$bundleFiles[ basename( $unzipped_file['filename'] ) ] = $unzipped_file['filename'];
									}
								}
							}
						}
					}

					if ( count( $bundleFiles ) > 1 ) {
						if ( ! empty( $decodedTemplates ) ) {
							foreach ( $decodedTemplates as $cpt => $tpl ) {
								$this->set_bundle_marker( $tpl );
								$fileFormats    = $this->get_xml_file( $bundleFiles[ basename( $tpl[0]['source_file_name'] ) ] );
								$bundle[ $cpt ] = $fileFormats['xml'];
							}
						}
						if ( ! empty( $bundle ) ) {
							$filePath = current( $bundle );
						}
					}

					if ( $this->uploadsPath === false ) {
						$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
					}

					if ( empty( $filePath ) ) {
						$filePath = $this->extract_first_importable_file( $this->file );
						if ( false === $filePath ) {
							$filePath = '';
							$this->errors->add( 'form-validation', __( 'WP All Import couldn\'t find a file to import inside your ZIP.<br/><br/>Either the .ZIP file is broken, or doesn\'t contain a file with an extension of  XML, CSV, PSV, DAT, or TXT. <br/>Please attempt to unzip your .ZIP file on your computer to ensure it is a valid .ZIP file which can actually be unzipped, and that it contains a file which WP All Import can import.', 'wp-all-import-pro' ) );
						}
					}
					// Detect if file is very large
					$source      = array(
						'name' => basename( $this->file ),
						'type' => 'upload',
						'path' => $this->file,
					);
					$fileFormats = $this->get_xml_file( $filePath );
					$filePath    = $fileFormats['xml'];
					$csv_path    = $fileFormats['csv'];
				}
			} elseif ( preg_match( '%\W(csv|txt|dat|psv|tsv)$%i', trim( $this->file ) ) ) { // If CSV file uploaded

				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}
				$filePath = $this->file;
				$source   = array(
					'name' => basename( $this->file ),
					'type' => 'upload',
					'path' => $filePath,
				);

				include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';

				$csv = $this->new_csv_parser(
					array(
						'filename'  => $this->file,
						'targetDir' => $this->uploadsPath,
					)
				);
				//@unlink($filePath);
				$csv_path           = $filePath;
				$filePath           = $csv->xml_path;
				$this->is_csv       = $csv->is_csv;
				$this->root_element = 'node';

			} elseif ( preg_match( '%\W(gz)$%i', trim( $this->file ) ) ) { // If gz file uploaded
				$fileInfo = wp_all_import_get_gz( $this->file, 0, $this->uploadsPath );
				if ( ! is_wp_error( $fileInfo ) ) {
					$filePath = $fileInfo['localPath'];
					// Detect if file is very large
					$source = array(
						'name' => basename( $this->file ),
						'type' => 'upload',
						'path' => $this->file,
					);
					// detect CSV or XML
					if ( $fileInfo['type'] == 'csv' ) { // it is CSV file

						include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';
						$csv = $this->new_csv_parser(
							array(
								'filename' => $filePath,
								'targeDir' => $this->uploadsPath,
							)
						); // create chunks
						//@unlink($filePath);
						$csv_path           = $filePath;
						$filePath           = $csv->xml_path;
						$this->is_csv       = $csv->is_csv;
						$this->root_element = 'node';
					}
				} else {
					$this->errors->add( 'form-validation', $fileInfo->get_error_message() );
				}
			} elseif ( preg_match( '%\W(json)$%i', trim( $this->file ) ) ) {

				// Detect if file is very large
				$source = array(
					'name' => basename( $this->file ),
					'type' => 'upload',
					'path' => $this->file,
				);

				$json_str = trim( file_get_contents( $this->file ) );
				$json_str = str_replace( "\xEF\xBB\xBF", '', $json_str );
				$is_json  = wp_all_import_is_json( $json_str );

				if ( is_wp_error( $is_json ) ) {
					$this->errors->add( 'form-validation', $is_json->get_error_message(), 'wp-all-import-pro' );
				} else {
					$xml_data = $this->json_to_xml( json_decode( $json_str, true ) );
					if ( empty( $xml_data ) ) {
						$this->errors->add( 'form-validation', __( 'Can not import this file. JSON to XML conversion failed.', 'wp-all-import-pro' ) );
					} else {
						$jsontmpname = $this->uploadsPath . '/' . wp_all_import_url_title( wp_unique_filename( $this->uploadsPath, str_replace( 'json', 'xml', basename( $this->file ) ) ) );
						//@unlink($this->file);
						file_put_contents( $jsontmpname, $xml_data );
						$filePath = $jsontmpname;

					}
				}
			} elseif ( preg_match( '%\W(sql)$%i', trim( $this->file ) ) ) {
				$source = array(
					'name' => basename( $this->file ),
					'type' => 'upload',
					'path' => $this->file,
				);
				$filePath = $this->parse_sql( $this->file );
			} elseif ( preg_match( '%\W(xls|xlsx)$%i', trim( $this->file ) ) ) {
				$source = array(
					'name' => basename( $this->file ),
					'type' => 'upload',
					'path' => $this->file,
				);

				$filePath = $this->parse_xls( $this->file );
			} else { // If XML file uploaded
				$filePath = $this->file;
				$source   = array(
					'name' => basename( $this->file ),
					'type' => 'upload',
					'path' => $filePath,
				);
			}

			if ( $this->errors->get_error_codes() ) {
				return $this->errors;
			}

			$decodedTemplates = empty( $templates ) ? false : json_decode( $templates, true );

			$source['path'] = wp_all_import_get_relative_path( $source['path'] );

			$templateOptions = '';

			if ( is_array( $decodedTemplates ) ) {
				$templateOptions = empty( $decodedTemplates[0] ) ? current( $decodedTemplates ) : $decodedTemplates;
			}

			$options = ( empty( $templateOptions[0]['options'] ) ) ? false : \pmxi_maybe_unserialize( $templateOptions[0]['options'] );

			if ( ! empty( $options['root_element'] ) ) {
				$this->root_element = $options['root_element'];
			}

			return array(
				'filePath'           => $filePath,
				'bundle'             => $bundle, // sub imports [cpt => filepath]
				'source'             => $source,
				'root_element'       => $this->root_element,
				'is_csv'             => $this->is_csv,
				'csv_path'           => $csv_path,
				'template'           => empty( $templateOptions ) ? '' : json_encode( $templateOptions ),
				'templates'          => $templates,
				'post_type'          => ( ! empty( $options ) ) ? $options['custom_type'] : false,
				'taxonomy_type'      => ( ! empty( $options['taxonomy_type'] ) ) ? $options['taxonomy_type'] : false,
				'gravity_form_title' => ( ! empty( $options['gravity_form_title'] ) ) ? $options['gravity_form_title'] : false,
				'bundle_xpath'       => ( ! empty( $templateOptions[0]['bundle_xpath'] ) ) ? $templateOptions[0]['bundle_xpath'] : false,
			) + $this->result_details();
		}

		public function url( $feed_type = '', $feed_xpath = '', $importTemplate = '' ) {

			$uploads = wp_upload_dir();

			$templates = false;

			$bundle = array();

			$bundleFiles = array();

			if ( empty( $this->file ) ) {
				$this->errors->add( 'form-validation', __( 'Please specify a file to import.', 'wp-all-import-pro' ) );
			} elseif ( ! preg_match( '%^https?://%i', $this->file ) ) {
				$this->errors->add( 'form-validation', __( 'The URL to your file is not valid.<br/><br/>Please make sure the URL starts with http:// or https://. To import from https://, your server must have OpenSSL installed.' ), 'wp-all-import-pro' );
			} elseif ( ! is_writeable( $this->uploadsPath ) ) {
				$this->errors->add( 'form-validation', __( 'Uploads folder ' . $this->uploadsPath . ' is not writable.' ), 'wp-all-import-pro' );
			}

			$this->file = trim( $this->file );

			$csv_path = '';

			if ( empty( $this->errors->errors ) ) {

				// Re-detect feed type from URL analysis. We only override the stored
				// value in two cases:
				// 1. No feed type is stored yet (new import or blank value).
				// 2. A stale 'csv' is stored but the URL extension/path clearly
				//    indicates a different type — this corrects AWIN-style gzip feeds
				//    (stored as 'csv' before gz detection was added) and also
				//    self-heals records that were incorrectly set to 'csv' by the
				//    overly-aggressive re-detection introduced in 5.0.5.
				// When 'csv' is stored but URL detection returns false (opaque URL
				// like .php?token=...), we clear feed_type to '' so the code falls
				// through to header-based detection rather than trusting a potentially
				// corrupted 'csv' value from 5.0.5.
				$detected_type = wp_all_import_get_remote_file_name( trim( $this->file ) );
				if ( $detected_type && (
					empty( $feed_type ) ||
					( 'csv' === $feed_type && $detected_type !== 'csv' )
				) ) {
					$feed_type = $detected_type;
				} elseif ( 'csv' === $feed_type && ! $detected_type ) {
					// Opaque URL with stored 'csv' — cannot confirm from URL alone.
					// Clear so header-based detection runs instead of blindly trusting
					// a value that may have been corrupted by 5.0.5.
					$feed_type = '';
				}

				if ( 'zip' === $feed_type || ( empty( $feed_type ) && preg_match( '%\W(zip)$%i', trim( $this->file ) ) ) ) {

					$tmpname = $this->uploadsPath . '/' . wp_unique_filename( $this->uploadsPath, md5( basename( $this->file ) ) . '.zip' );

					@copy( $this->file, $tmpname );

					if ( ! file_exists( $tmpname ) ) {
						$request = get_file_curl( $this->file, $tmpname );
						if ( is_wp_error( $request ) ) {
							$this->errors->add( 'form-validation', $request->get_error_message() );
						}
						if ( ! file_exists( $tmpname ) ) {
							$this->errors->add( 'form-validation', __( 'Failed upload ZIP archive', 'wp-all-import-pro' ) );
						}
					}

					$zipResult       = $this->extract_zip( $tmpname );
					$filePath        = $zipResult['filePath'];
					$csv_path        = $zipResult['csv_path'];
					$templates       = $zipResult['templates'];
					$templateOptions = $zipResult['templateOptions'];
					$bundle          = $zipResult['bundle'];
					$bundleFiles     = $zipResult['bundleFiles'];
					$source          = array(
						'name' => basename( parse_url( $this->file, PHP_URL_PATH ) ),
						'type' => 'url',
						'path' => $feed_xpath,
					);

					if ( file_exists( $tmpname ) ) {
						wp_all_import_remove_source( $tmpname, false );
					}
				} elseif ( 'csv' == $feed_type or '' == $feed_type and preg_match( '%\W(csv|txt|dat|psv|tsv)$%i', trim( $this->file ) ) ) {

					$source = array(
						'name' => basename( parse_url( $this->file, PHP_URL_PATH ) ),
						'type' => 'url',
						'path' => $feed_xpath,
					);
					// copy remote file in binary mode
					$filePath = wp_all_import_get_url( $this->file, $this->uploadsPath, 'csv' );
					if ( $this->download_failed( $filePath ) ) {
						return $this->errors;
					}
					// Detect if file is very large
					include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';
					$csv = $this->new_csv_parser(
						array(
							'filename'  => $filePath,
							'targetDir' => $this->uploadsPath,
						)
					); // create chunks
					//wp_all_import_remove_source($filePath, false);
					$csv_path           = $filePath;
					$filePath           = $csv->xml_path;
					$this->is_csv       = $csv->is_csv;
					$this->root_element = 'node';
				} elseif ( 'json' == $feed_type or preg_match( '%\W(json)$%i', trim( $this->file ) ) ) {

					$source = array(
						'name' => basename( parse_url( $this->file, PHP_URL_PATH ) ),
						'type' => 'url',
						'path' => $feed_xpath,
					);
					// copy remote file in binary mode
					$filePath = wp_all_import_get_url( $this->file, $this->uploadsPath, 'json' );
					if ( $this->download_failed( $filePath ) ) {
						return $this->errors;
					}
					$json_str = file_get_contents( $filePath );
					$json_str = str_replace( "\xEF\xBB\xBF", '', $json_str );
					$is_json  = wp_all_import_is_json( $json_str );
					if ( is_wp_error( $is_json ) ) {
						$this->errors->add( 'form-validation', $is_json->get_error_message(), 'wp-all-import-pro' );
					} else {
						$xml_data = $this->json_to_xml( json_decode( $json_str, true ) );
						if ( empty( $xml_data ) ) {
							$this->errors->add( 'form-validation', __( 'Can not import this file. JSON to XML conversion failed.', 'wp-all-import-pro' ) );
						} else {
							$tmpname = $this->uploadsPath . '/' . wp_all_import_url_title( wp_unique_filename( $this->uploadsPath, str_replace( 'json', 'xml', basename( $filePath ) ) ) );
							file_put_contents( $tmpname, $xml_data );
							wp_all_import_remove_source( $filePath, false );
							$filePath = $tmpname;
						}
					}
				} elseif ( 'sql' == $feed_type or preg_match( '%\W(sql)$%i', trim( $this->file ) ) ) {
					$source = array(
						'name' => basename( $this->file ),
						'type' => 'url',
						'path' => $feed_xpath,
					);
					// copy remote file in binary mode
					$localSQLPath = wp_all_import_get_url( $this->file, $this->uploadsPath, 'sql' );
					if ( $this->download_failed( $localSQLPath ) ) {
						return $this->errors;
					}
					$filePath = $this->parse_sql( $localSQLPath );
					wp_all_import_remove_source( $localSQLPath, false );
					if ( false === $filePath ) {
						return $this->errors;
					}
				} elseif ( in_array( $feed_type, array( 'xls', 'xlsx' ), true ) ) {

					$source = array(
						'name' => basename( $this->file ),
						'type' => 'url',
						'path' => $feed_xpath,
					);
					// copy remote file in binary mode
					$localXLSPath = wp_all_import_get_url( $this->file, $this->uploadsPath, $feed_type );
					if ( $this->download_failed( $localXLSPath ) ) {
						return $this->errors;
					}
					$filePath = $this->parse_xls( $localXLSPath );
					wp_all_import_remove_source( $localXLSPath, false );
					if ( false === $filePath ) {
						return $this->errors;
					}
					$this->root_element = 'node';
				} else {
					$is_known_gz = in_array( $feed_type, array( 'gz', 'gzip' ), true ) || ( '' == $feed_type && preg_match( '%\W(gz|gzip)$%i', trim( $this->file ) ) );
					if ( $is_known_gz ) {
						// URL is known to be gzip from extension/path — download + decompress in one step.
						$fileInfo = wp_all_import_get_gz( $this->file, 0, $this->uploadsPath );
					} elseif ( ! empty( $feed_type ) ) {
						// Feed type is already known (e.g. 'xml', 'json' stored from a previous run).
						// Pass it as a content-type hint so wp_all_import_get_url skips text-sniffing,
						// which defaults to 'csv' for any content that isn't detected as XML — causing
						// JSON feeds and non-standard XML to be incorrectly treated as CSV.
						$fileInfo = wp_all_import_get_url( $this->file, $this->uploadsPath, $feed_type, false, true );
					} else {
						// Feed type is unknown. Check Content-Type headers to identify the content
						// before downloading, restoring the reliable detection from before 5.0.5.
						// AWIN-style URLs are handled above via $is_known_gz, so the feeds reaching
						// this path are opaque URLs where header inspection is the only reliable method.
						$headers = wp_all_import_get_feed_type( $this->file );
						$encoding = $headers['Content-Encoding'];
						if ( is_array( $encoding ) ) {
							$encoding = end( $encoding );
						}
						if ( ( $headers['Content-Type'] && in_array( $headers['Content-Type'], array( 'gz', 'gzip' ), true ) )
							|| ( $encoding && in_array( $encoding, array( 'gz', 'gzip' ), true ) ) ) {
							$fileInfo = wp_all_import_get_gz( $this->file, 0, $this->uploadsPath, $headers );
						} else {
							$fileInfo = wp_all_import_get_url( $this->file, $this->uploadsPath, $headers['Content-Type'], $headers['Content-Encoding'], true );
						}
					}

					if ( ! is_wp_error( $fileInfo ) && false !== $fileInfo ) {
						$filePath = $fileInfo['localPath'];
						if ( $this->download_failed( $filePath ) ) {
							return $this->errors;
						}
						// Detect if file is very large
						$source           = array(
							'name' => basename( parse_url( $this->file, PHP_URL_PATH ) ),
							'type' => 'url',
							'path' => $feed_xpath,
						);
						$fileInfo['type'] = apply_filters( 'wp_all_import_feed_type', $fileInfo['type'], $this->file );
						// Update feed_type from detection so it flows into the return array.
						if ( ! empty( $fileInfo['type'] ) ) {
							$feed_type = $fileInfo['type'];
						}
						// Known-gz path: wp_all_import_get_gz already decompressed and
						// returned the inner type (csv/xml). Pin feed_type back to 'gz'
						// so the import record stores the correct archive type.
						if ( $is_known_gz ) {
							$feed_type = 'gz';
						}

						// If magic bytes detected gzip, decompress locally and re-detect
						// the inner type so the switch can route it (csv, xml, etc.).
						if ( in_array( $fileInfo['type'], array( 'gz', 'gzip' ), true ) ) {
							$localGzPath = $filePath;
							$gzResult    = wp_all_import_get_gz( $localGzPath, 0, $this->uploadsPath );
							wp_all_import_remove_source( $localGzPath, false );
							if ( ! is_wp_error( $gzResult ) && false !== $gzResult ) {
								$filePath           = $gzResult['localPath'];
								$fileInfo['type']   = $gzResult['type'];
								$fileInfo['localPath'] = $gzResult['localPath'];
								// Pin feed_type to 'gz' — inner type routes the switch,
								// but the archive type must persist for the import record.
								$feed_type = 'gz';
							} else {
								$this->errors->add( 'form-validation', __( 'Failed to decompress gzip file.', 'wp-all-import-pro' ) );
							}
						}

						// Route based on detected file type.
						switch ( $fileInfo['type'] ) {
							case 'csv':
								include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';
								$csv      = $this->new_csv_parser(
									array(
										'filename'  => $filePath,
										'targetDir' => $this->uploadsPath,
									)
								); // create chunks
								$csv_path = $filePath;
								//wp_all_import_remove_source($filePath, false);
								$filePath           = $csv->xml_path;
								$this->is_csv       = $csv->is_csv;
								$this->root_element = 'node';
								break;
							case 'xls':
							case 'xlsx':
								$parsed_path = $this->parse_xls( $filePath );
								wp_all_import_remove_source( $fileInfo['localPath'], false );
								if ( false !== $parsed_path ) {
									$filePath           = $parsed_path;
									$this->root_element = 'node';
								}
								break;
							case 'json':
								$json_str = file_get_contents( $filePath );
								$json_str = str_replace( "\xEF\xBB\xBF", '', $json_str );
								$is_json  = wp_all_import_is_json( $json_str );

								if ( is_wp_error( $is_json ) ) {
									$this->errors->add( 'form-validation', $is_json->get_error_message(), 'wp-all-import-pro' );
								} else {
									$xml_data = $this->json_to_xml( json_decode( $json_str, true ) );
									if ( empty( $xml_data ) ) {
										$this->errors->add( 'form-validation', __( 'Can not import this file. JSON to XML conversion failed.', 'wp-all-import-pro' ) );
									} else {
										$tmpname = $this->uploadsPath . '/' . wp_all_import_url_title( wp_unique_filename( $this->uploadsPath, str_replace( 'json', 'xml', basename( $filePath ) ) ) );
										file_put_contents( $tmpname, $xml_data );
										wp_all_import_remove_source( $filePath, false );
										$filePath = $tmpname;
									}
								}
								break;
							case 'sql':
								$filePath = $this->parse_sql( $filePath );
								break;
							case 'zip':
								$zipResult       = $this->extract_zip( $filePath );
								wp_all_import_remove_source( $filePath, false );
								$filePath        = $zipResult['filePath'];
								$csv_path        = $zipResult['csv_path'];
								$templates       = $zipResult['templates'];
								$templateOptions = $zipResult['templateOptions'];
								$bundle          = $zipResult['bundle'];
								$bundleFiles     = $zipResult['bundleFiles'];
								$source          = array(
									'name' => basename( parse_url( $this->file, PHP_URL_PATH ) ),
									'type' => 'url',
									'path' => $feed_xpath,
								);
								break;
							default:
								# code...
								break;
						}
					} elseif ( ! is_wp_error( $fileInfo ) && pmxi_is_private_ip( $this->file ) ) {
						$this->errors->add( 'form-validation', $this->private_ip_message() );
					} else {
						$this->download_failed( $fileInfo );
					}
				}
			}

			if ( $this->errors->get_error_codes() ) {
				return $this->errors;
			}

			$decodedTemplates = empty( $templates ) ? json_decode( $importTemplate, true ) : json_decode( $templates, true );

			$templateOptions = '';

			if ( is_array( $decodedTemplates ) and ! empty( $decodedTemplates ) ) {
				$templateOptions = empty( $decodedTemplates[0] ) ? current( $decodedTemplates ) : $decodedTemplates;
			}

			$options = ( empty( $templateOptions[0]['options'] ) ) ? false : \pmxi_maybe_unserialize( $templateOptions[0]['options'] );

			if ( ! empty( $options['root_element'] ) ) {
				$this->root_element = $options['root_element'];
			}

			return array(
				'filePath'           => $filePath,
				'bundle'             => $bundle,
				'source'             => $source,
				'root_element'       => $this->root_element,
				'feed_type'          => $feed_type,
				'is_csv'             => $this->is_csv,
				'csv_path'           => $csv_path,
				'template'           => empty( $templateOptions ) ? '' : json_encode( $templateOptions ),
				'templates'          => $templates,
				'post_type'          => ( ! empty( $options ) ) ? $options['custom_type'] : false,
				'taxonomy_type'      => ( ! empty( $options['taxonomy_type'] ) ) ? $options['taxonomy_type'] : false,
				'gravity_form_title' => ( ! empty( $options['gravity_form_title'] ) ) ? $options['gravity_form_title'] : false,
			) + $this->result_details();
		}

		public function file() {

			$templates = false;

			$bundleFiles = array();

			$bundle = array();

			$wp_uploads = wp_upload_dir();

			$uploads = $wp_uploads['basedir'] . DIRECTORY_SEPARATOR . PMXI_Plugin::FILES_DIRECTORY . DIRECTORY_SEPARATOR;

			$this->file = str_replace( DIRECTORY_SEPARATOR . PMXI_Plugin::FILES_DIRECTORY . DIRECTORY_SEPARATOR, '', $this->file );

			$from = $uploads . trim( $this->file );
			$to   = $this->uploadsPath . DIRECTORY_SEPARATOR . basename( $this->file );

			if ( empty( $this->file ) ) {
				$this->errors->add( 'form-validation', __( 'Please specify a file to import.', 'wp-all-import-pro' ) );
			} elseif ( preg_match( '%\W(zip)$%i', trim( $this->file ) ) ) {

				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}

				if ( $this->errors->get_error_codes() ) {
					return $this->errors;
				}

				echo '<span style="display:none">';
				copy( $from, $to );
				echo '</span>';

				$zipfilePath = $to;

				if ( ! class_exists( 'WpaiPclZip' ) ) {
					include_once PMXI_Plugin::ROOT_DIR . '/libraries/wpaipclzip.lib.php';
				}

				$archive = new WpaiPclZip( $zipfilePath );

				// Get allowed file extensions (whitelist approach)
				$allowed_extensions = wp_all_import_get_allowed_zip_extensions();

				// Attempt to extract files with whitelist restrictions
				$v_result_list = $archive->extract( WPAI_PCLZIP_OPT_PATH, $this->uploadsPath, WPAI_PCLZIP_OPT_REPLACE_NEWER, WPAI_PCLZIP_OPT_EXTRACT_DIR_RESTRICTION, $this->uploadsPath, WPAI_PCLZIP_OPT_EXTRACT_WHITELIST_RESTRICTIONS, $allowed_extensions );
				if ( empty( $v_result_list ) || ! is_array( $v_result_list ) && $v_result_list < 1 ) {
					$this->errors->add( 'form-validation', __( 'WP All Import couldn\'t find a file to import inside your ZIP.<br/><br/>Either the .ZIP file is broken, or doesn\'t contain a file with an extension of  XML, CSV, PSV, DAT, or TXT. <br/>Please attempt to unzip your .ZIP file on your computer to ensure it is a valid .ZIP file which can actually be unzipped, and that it contains a file which WP All Import can import.', 'wp-all-import-pro' ) );
				} else {
					$filePath = '';
					if ( ! empty( $v_result_list ) ) {
						foreach ( $v_result_list as $unzipped_file ) {
							if ( $unzipped_file['status'] == 'ok' and preg_match( '%\W(php)$%i', trim( $unzipped_file['stored_filename'] ) ) ) {
								unlink( $unzipped_file['filename'] );
								continue;
							}
							if ( $unzipped_file['status'] == 'ok' and preg_match( '%\W(xml|csv|tsv|txt|dat|psv|json|xls|xlsx|gz)$%i', trim( $unzipped_file['stored_filename'] ) ) and strpos( $unzipped_file['stored_filename'], 'readme.txt' ) === false ) {
								if ( strpos( basename( $unzipped_file['stored_filename'] ), 'WP All Import Template' ) === 0 || strpos( basename( $unzipped_file['stored_filename'] ), 'templates_' ) === 0 ) {
									$templates        = file_get_contents( $unzipped_file['filename'] );
									$decodedTemplates = json_decode( $templates, true );
									$templateOptions  = empty( $decodedTemplates[0] ) ? current( $decodedTemplates ) : $decodedTemplates;
									$this->set_bundle_marker( $templateOptions );
								} else {
									if ( $filePath == '' ) {
										$filePath = $unzipped_file['filename'];
									}
									if ( ! in_array( $unzipped_file['filename'], $bundleFiles ) ) {
										$bundleFiles[ basename( $unzipped_file['filename'] ) ] = $unzipped_file['filename'];
									}
								}
							}
						}
					}

					if ( count( $bundleFiles ) > 1 ) {
						if ( ! empty( $decodedTemplates ) ) {
							foreach ( $decodedTemplates as $cpt => $tpl ) {
								$this->set_bundle_marker( $tpl );
								$fileFormats    = $this->get_xml_file( $bundleFiles[ basename( $tpl[0]['source_file_name'] ) ] );
								$bundle[ $cpt ] = $fileFormats['xml'];
							}
						}
						if ( ! empty( $bundle ) ) {
							$filePath = current( $bundle );
						}
					}

					if ( $this->uploadsPath === false ) {
						$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
					}

					if ( empty( $filePath ) ) {
						$filePath = $this->extract_first_importable_file( $zipfilePath );
						if ( false === $filePath ) {
							$filePath = '';
							$this->errors->add( 'form-validation', __( 'WP All Import couldn\'t find a file to import inside your ZIP.<br/><br/>Either the .ZIP file is broken, or doesn\'t contain a file with an extension of  XML, CSV, PSV, DAT, or TXT. <br/>Please attempt to unzip your .ZIP file on your computer to ensure it is a valid .ZIP file which can actually be unzipped, and that it contains a file which WP All Import can import.', 'wp-all-import-pro' ) );
						}
					}
					// Detect if file is very large
					$source      = array(
						'name' => trim( $this->file ),
						'type' => 'file',
						'path' => $uploads . $this->file,
					);
					$fileFormats = $this->get_xml_file( $filePath );
					$filePath    = $fileFormats['xml'];
				}

				if ( file_exists( $zipfilePath ) ) {
					wp_all_import_remove_source( $zipfilePath, false );
				}
			} elseif ( preg_match( '%\W(csv|txt|dat|psv|tsv)$%i', trim( $this->file ) ) ) {

				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}
				if ( ! @file_exists( $from ) ) {
					$this->errors->add( 'form-validation', __( 'File doesn\'t exist.', 'wp-all-import-pro' ) );
				}

				if ( $this->errors->get_error_codes() ) {
					return $this->errors;
				}

				// copy file in temporary folder
				// hide warning message
				echo '<span style="display:none">';
				copy( $from, $to );
				echo '</span>';
				$filePath = $to;
				$source   = array(
					'name' => trim( $this->file ),
					'type' => 'file',
					'path' => $from,
				);
				// Detect if file is very large
				include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';
				$csv = $this->new_csv_parser(
					array(
						'filename'  => $filePath,
						'targetDir' => $this->uploadsPath,
					)
				); // create chunks
				//wp_all_import_remove_source($filePath, false);
				$filePath           = $csv->xml_path;
				$this->is_csv       = $csv->is_csv;
				$this->root_element = 'node';
			} elseif ( preg_match( '%\W(json)$%i', trim( $this->file ) ) ) {
				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}
				if ( $this->errors->get_error_codes() ) {
					return $this->errors;
				}
				// copy file in temporary folder
				// hide warning message
				echo '<span style="display:none">';
				copy( $from, $to );
				echo '</span>';
				$filePath = $to;
				$source   = array(
					'name' => trim( $this->file ),
					'type' => 'file',
					'path' => $from,
				);
				$json_str = file_get_contents( $filePath );
				$json_str = str_replace( "\xEF\xBB\xBF", '', $json_str );
				$is_json  = wp_all_import_is_json( $json_str );
				if ( is_wp_error( $is_json ) ) {
					$this->errors->add( 'form-validation', $is_json->get_error_message(), 'wp-all-import-pro' );
				} else {
					$xml_data = $this->json_to_xml( json_decode( $json_str, true ) );
					if ( empty( $xml_data ) ) {
						$this->errors->add( 'form-validation', __( 'Can not import this file. JSON to XML conversion failed.', 'wp-all-import-pro' ) );
					} else {
						$jsontmpname = $this->uploadsPath . '/' . wp_all_import_url_title( wp_unique_filename( $this->uploadsPath, str_replace( 'json', 'xml', basename( $filePath ) ) ) );
						file_put_contents( $jsontmpname, $xml_data );
						wp_all_import_remove_source( $filePath, false );
						$filePath = $jsontmpname;
					}
				}
			} elseif ( preg_match( '%\W(sql)$%i', trim( $this->file ) ) ) {

				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}
				if ( $this->errors->get_error_codes() ) {
					return $this->errors;
				}

				// copy file in temporary folder
				// hide warning message
				echo '<span style="display:none">';
				copy( $from, $to );
				echo '</span>';

				$localSQLPath = $to;
				$source       = array(
					'name' => trim( $this->file ),
					'type' => 'file',
					'path' => $from,
				);

				$filePath = $this->parse_sql( $localSQLPath );
				wp_all_import_remove_source( $localSQLPath, false );

			} elseif ( preg_match( '%\W(xls|xlsx)$%i', trim( $this->file ) ) ) {

				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}
				if ( $this->errors->get_error_codes() ) {
					return $this->errors;
				}
				// copy file in temporary folder
				// hide warning message
				echo '<span style="display:none">';
				copy( $from, $to );
				echo '</span>';
				$localXLSPath = $to;
				$source       = array(
					'name' => trim( $this->file ),
					'type' => 'file',
					'path' => $from,
				);
				$filePath = $this->parse_xls( $localXLSPath );
				wp_all_import_remove_source( $localXLSPath, false );
			} else {

				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}
				if ( $this->errors->get_error_codes() ) {
					return $this->errors;
				}

				// copy file in temporary folder
				// hide warning message
				echo '<span style="display:none">';
				copy( $from, $to );
				echo '</span>';

				$source = array(
					'name' => trim( $this->file ),
					'type' => 'file',
					'path' => $from,
				);

				$filePath = $to;

				if ( preg_match( '%\W(gz)$%i', basename( $this->file ) ) ) {
					$fileInfo = wp_all_import_get_gz( $filePath, 0, $this->uploadsPath );
					if ( ! is_wp_error( $fileInfo ) ) {
						wp_all_import_remove_source( $filePath, false );
						$filePath = $fileInfo['localPath'];
					} else {
						$this->errors->add( 'form-validation', $fileInfo->get_error_message() );
					}
				}

				if ( preg_match( '%\W(csv|txt|dat|psv|tsv)$%i', trim( $this->file ) ) or ( ! empty( $fileInfo ) and $fileInfo['type'] == 'csv' ) ) {
					include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';
					$csv = $this->new_csv_parser(
						array(
							'filename'  => $filePath,
							'targetDir' => $this->uploadsPath,
						)
					); // create chunks
					//wp_all_import_remove_source($filePath, false);
					$filePath           = $csv->xml_path;
					$this->is_csv       = $csv->is_csv;
					$this->root_element = 'node';
				}
			}

			if ( $this->errors->get_error_codes() ) {
				return $this->errors;
			}

			$decodedTemplates = empty( $templates ) ? false : json_decode( $templates, true );

			$source['path'] = wp_all_import_get_relative_path( $source['path'] );

			$templateOptions = '';

			if ( is_array( $decodedTemplates ) ) {
				$templateOptions = empty( $decodedTemplates[0] ) ? current( $decodedTemplates ) : $decodedTemplates;
			}

			$options = ( empty( $templateOptions[0]['options'] ) ) ? false : \pmxi_maybe_unserialize( $templateOptions[0]['options'] );

			if ( ! empty( $options['root_element'] ) ) {
				$this->root_element = $options['root_element'];
			}

			return array(
				'filePath'           => $filePath,
				'bundle'             => $bundle,
				'source'             => $source,
				'root_element'       => $this->root_element,
				'is_csv'             => $this->is_csv,
				'template'           => empty( $templateOptions ) ? '' : json_encode( $templateOptions ),
				'templates'          => $templates,
				'post_type'          => ( ! empty( $options ) ) ? $options['custom_type'] : false,
				'taxonomy_type'      => ( ! empty( $options['taxonomy_type'] ) ) ? $options['taxonomy_type'] : false,
				'gravity_form_title' => ( ! empty( $options['gravity_form_title'] ) ) ? $options['gravity_form_title'] : false,
			) + $this->result_details();
		}

		/**
		 * Extract a ZIP archive and locate the importable file inside it.
		 *
		 * @param string $zipPath Local path to the ZIP file.
		 * @return array { filePath, csv_path, source, templates, templateOptions, bundle, bundleFiles }
		 */
		protected function extract_zip( $zipPath ) {
			$result = array(
				'filePath'        => '',
				'csv_path'        => '',
				'templates'       => '',
				'templateOptions' => array(),
				'bundle'          => array(),
				'bundleFiles'     => array(),
			);

			if ( ! class_exists( 'WpaiPclZip' ) ) {
				include_once PMXI_Plugin::ROOT_DIR . '/libraries/wpaipclzip.lib.php';
			}

			$archive            = new WpaiPclZip( $zipPath );
			$allowed_extensions = wp_all_import_get_allowed_zip_extensions();
			$v_result_list      = $archive->extract( WPAI_PCLZIP_OPT_PATH, $this->uploadsPath, WPAI_PCLZIP_OPT_REPLACE_NEWER, WPAI_PCLZIP_OPT_EXTRACT_DIR_RESTRICTION, $this->uploadsPath, WPAI_PCLZIP_OPT_EXTRACT_WHITELIST_RESTRICTIONS, $allowed_extensions );

			if ( empty( $v_result_list ) || ! is_array( $v_result_list ) && $v_result_list < 1 ) {
				$this->errors->add( 'form-validation', __( 'WP All Import couldn\'t find a file to import inside your ZIP.<br/><br/>Either the .ZIP file is broken, or doesn\'t contain a file with an extension of  XML, CSV, PSV, DAT, or TXT. <br/>Please attempt to unzip your .ZIP file on your computer to ensure it is a valid .ZIP file which can actually be unzipped, and that it contains a file which WP All Import can import.', 'wp-all-import-pro' ) );
				return $result;
			}

			$decodedTemplates = null;
			foreach ( $v_result_list as $unzipped_file ) {
				if ( $unzipped_file['status'] == 'ok' and preg_match( '%\W(php)$%i', trim( $unzipped_file['stored_filename'] ) ) ) {
					@unlink( $unzipped_file['filename'] );
					continue;
				}
				if ( $unzipped_file['status'] == 'ok' and preg_match( '%\W(xml|csv|txt|dat|psv|json|xls|xlsx|gz)$%i', trim( $unzipped_file['stored_filename'] ) ) and strpos( $unzipped_file['stored_filename'], 'readme.txt' ) === false ) {
					if ( strpos( basename( $unzipped_file['stored_filename'] ), 'WP All Import Template' ) === 0 || strpos( basename( $unzipped_file['stored_filename'] ), 'templates_' ) === 0 ) {
						$result['templates']       = file_get_contents( $unzipped_file['filename'] );
						$decodedTemplates          = json_decode( $result['templates'], true );
						$result['templateOptions'] = empty( $decodedTemplates[0] ) ? current( $decodedTemplates ) : $decodedTemplates;
						$this->set_bundle_marker( $result['templateOptions'] );
					} else {
						if ( $result['filePath'] == '' ) {
							$result['filePath'] = $unzipped_file['filename'];
						}
						if ( ! in_array( $unzipped_file['filename'], $result['bundleFiles'] ) ) {
							$result['bundleFiles'][ basename( $unzipped_file['filename'] ) ] = $unzipped_file['filename'];
						}
					}
				}
			}

			if ( count( $result['bundleFiles'] ) > 1 ) {
				if ( ! empty( $decodedTemplates ) ) {
					foreach ( $decodedTemplates as $cpt => $tpl ) {
						$this->set_bundle_marker( $tpl );
						$fileFormats              = $this->get_xml_file( $result['bundleFiles'][ basename( $tpl[0]['source_file_name'] ) ] );
						$result['bundle'][ $cpt ] = $fileFormats['xml'];
					}
				}
				if ( ! empty( $result['bundle'] ) ) {
					$result['filePath'] = current( $result['bundle'] );
				}
			}

			if ( $this->uploadsPath === false ) {
				$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
			}

			if ( empty( $result['filePath'] ) ) {
				$result['filePath'] = $this->extract_first_importable_file( $zipPath );
				if ( false === $result['filePath'] ) {
					$result['filePath'] = '';
					$this->errors->add( 'form-validation', __( 'WP All Import couldn\'t find a file to import inside your ZIP.<br/><br/>Either the .ZIP file is broken, or doesn\'t contain a file with an extension of  XML, CSV, PSV, DAT, or TXT. <br/>Please attempt to unzip your .ZIP file on your computer to ensure it is a valid .ZIP file which can actually be unzipped, and that it contains a file which WP All Import can import.', 'wp-all-import-pro' ) );
				}
			}

			if ( ! empty( $result['filePath'] ) ) {
				$fileFormats        = $this->get_xml_file( $result['filePath'] );
				$result['csv_path'] = $fileFormats['csv'];
				$result['filePath'] = $fileFormats['xml'];
			}

			return $result;
		}

		// Writes by basename only: the stored entry name must never decide the directory.
		protected function extract_first_importable_file( $zipPath ) {
			$zip = new \ZipArchive();
			if ( false === $this->uploadsPath || true !== $zip->open( trim( $zipPath ) ) ) {
				return false;
			}

			$filePath = '';
			for ( $i = 0; $i < $zip->numFiles; $i++ ) {
				$fileName = trim( basename( wp_normalize_path( (string) $zip->getNameIndex( $i ) ) ) );
				if ( strpos( $fileName, "\0" ) !== false || ! preg_match( '%\W(xml|csv|txt|dat|psv|json|xls|xlsx|gz)$%i', $fileName ) ) {
					continue;
				}
				$contents = $zip->getFromIndex( $i );
				if ( false !== $contents && false !== file_put_contents( $this->uploadsPath . '/' . $fileName, $contents ) ) {
					$filePath = $this->uploadsPath . '/' . $fileName;
					break;
				}
			}
			$zip->close();

			return $filePath;
		}

		protected function get_xml_file( $filePath ) {
			$csv_path = '';

			if ( preg_match( '%\W(csv|txt|dat|psv|tsv)$%i', trim( $filePath ) ) ) { // If CSV file found in archieve

				if ( $this->uploadsPath === false ) {
					$this->errors->add( 'form-validation', __( 'WP All Import can\'t access your WordPress uploads folder.', 'wp-all-import-pro' ) );
				}

				include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';
				$csv = $this->new_csv_parser(
					array(
						'filename'  => $filePath,
						'targetDir' => $this->uploadsPath,
					)
				); // create chunks

				$csv_path = $filePath;

				$filePath           = $csv->xml_path;
				$this->is_csv       = $csv->is_csv;
				$this->root_element = 'node';

			} elseif ( preg_match( '%\W(json)$%i', trim( $filePath ) ) ) {

				$json_str = file_get_contents( $filePath );
				$json_str = str_replace( "\xEF\xBB\xBF", '', $json_str );
				$is_json  = wp_all_import_is_json( $json_str );

				if ( is_wp_error( $is_json ) ) {
					$this->errors->add( 'form-validation', $is_json->get_error_message(), 'wp-all-import-pro' );
				} else {

					$xml_data = $this->json_to_xml( json_decode( $json_str, true ) );

					if ( empty( $xml_data ) ) {
						$this->errors->add( 'form-validation', __( 'Can not import this file. JSON to XML conversion failed.', 'wp-all-import-pro' ) );
					} else {
						$jsontmpname = $this->uploadsPath . '/' . wp_all_import_url_title( wp_unique_filename( $this->uploadsPath, str_replace( 'json', 'xml', basename( $filePath ) ) ) );
						file_put_contents( $jsontmpname, $xml_data );
						wp_all_import_remove_source( $filePath, false );
						$filePath = $jsontmpname;
					}
				}
			} elseif ( preg_match( '%\W(sql)$%i', trim( $filePath ) ) ) {

				$localSQLPath = $filePath;
				$filePath     = $this->parse_sql( $localSQLPath );
				wp_all_import_remove_source( $localSQLPath, false );
			} elseif ( preg_match( '%\W(xls|xlsx)$%i', trim( $filePath ) ) ) {

				$localXLSPath = $filePath;
				$filePath     = $this->parse_xls( $localXLSPath );
				wp_all_import_remove_source( $localXLSPath, false );

			} elseif ( preg_match( '%\W(gz)$%i', trim( $filePath ) ) ) { // If gz file uploaded

				$fileInfo = wp_all_import_get_gz( $filePath, 0, $this->uploadsPath );

				if ( ! is_wp_error( $fileInfo ) ) {

					$filePath = $fileInfo['localPath'];

					// detect CSV or XML
					if ( $fileInfo['type'] == 'csv' ) { // it is CSV file

						include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportCsvParse.php';
						$csv_path = $filePath;
						$csv      = $this->new_csv_parser(
							array(
								'filename' => $filePath,
								'targeDir' => $this->uploadsPath,
							)
						); // create chunks
						//@unlink($filePath);
						$filePath           = $csv->xml_path;
						$this->is_csv       = $csv->is_csv;
						$this->root_element = 'node';

					}
				} else {
					$this->errors->add( 'form-validation', $fileInfo->get_error_message() );
				}
			}

			return array(
				'csv' => $csv_path,
				'xml' => $filePath,
			);
		}

		protected function keep_4byte_chars() {
			return PMXI_ParseOptions::keep_4byte_chars( $this->parse_options );
		}

		protected function new_csv_parser( $options ) {
			$mode = $this->parse_options[ PMXI_ParseOptions::ESCAPE ];
			if ( PMXI_CsvDialect::AUTO === $mode && null !== $this->bundle_marker ) {
				$mode = $this->bundle_marker;
			}
			$csv = new PMXI_CsvParser(
				$options + array(
					'csv_escape'       => $mode,
					'keep_4byte_chars' => $this->keep_4byte_chars(),
					'import_id'        => $this->import_id,
				)
			);
			$this->csv_dialect = $csv->csv_dialect();
			$this->file_format = 'csv';
			return $csv;
		}

		protected function json_to_xml( $data ) {
			$this->file_format = 'json';
			return wp_all_import_json_to_xml( $data, $this->keep_4byte_chars() );
		}

		/**
		 * A WP All Export bundle names the CSV format it wrote. It decides the format only for
		 * an import set to Automatic; an explicit setting is never overridden.
		 */
		protected function set_bundle_marker( $template ) {
			$options              = ( is_array( $template ) && ! empty( $template[0]['options'] ) ) ? \pmxi_maybe_unserialize( $template[0]['options'] ) : false;
			$this->bundle_marker = PMXI_CsvDialect::marker_of( $options );
		}

		protected function result_details() {
			return array(
				'file_format' => '' === $this->file_format ? 'xml' : $this->file_format,
				'csv_dialect' => $this->csv_dialect,
			);
		}

		protected function parse_sql( $path ) {
			$this->file_format = 'sql';
			include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportSQLParse.php';
			$sql    = new PMXI_SQLParser( $path, $this->uploadsPath );
			$parsed = $sql->parse();

			// The parser writes an empty <data> element for input with no INSERT rows, such as a saved error page.
			$has_rows = false;
			$reader   = new XMLReader();
			if ( @$reader->open( $parsed ) ) {
				while ( @$reader->read() ) {
					if ( XMLReader::ELEMENT === $reader->nodeType && 1 === $reader->depth ) {
						$has_rows = true;
						break;
					}
				}
				$reader->close();
			}

			if ( ! $has_rows ) {
				wp_all_import_remove_source( $parsed, false );
				$this->errors->add( 'form-validation', __( 'WP All Import couldn\'t find any INSERT statements to import in this SQL file.', 'wp-all-import-pro' ) );
				return false;
			}

			return $parsed;
		}

		protected function parse_xls( $path ) {
			include_once PMXI_Plugin::ROOT_DIR . '/libraries/XmlImportXLSParse.php';
			try {
				$this->file_format = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) === 'xls' ? 'xls' : 'xlsx';
				$xls    = new PMXI_XLSParser( $path, $this->uploadsPath, $this->keep_4byte_chars() );
				$parsed = $xls->parse();
			} catch ( \Throwable $e ) {
				$parsed = false;
			}

			if ( empty( $parsed ) ) {
				$this->errors->add( 'form-validation', __( 'Could not parse the XLS/XLSX file.', 'wp-all-import-pro' ) );
				return false;
			}

			return $parsed;
		}

		protected function download_failed( $path ) {
			if ( is_wp_error( $path ) ) {
				$this->errors->add( 'form-validation', $path->get_error_message() );
			} elseif ( ( ! is_string( $path ) || ! file_exists( $path ) ) && pmxi_is_private_ip( $this->file ) ) {
				$this->errors->add( 'form-validation', $this->private_ip_message() );
			} elseif ( ! is_string( $path ) || ! file_exists( $path ) ) {
				$this->errors->add( 'form-validation', __( 'WP All Import was not able to download your file.<br/><br/>Please make sure the URL to your file is valid.<br/>You can test this by pasting it into your browser.<br/>Other reasons for this error can include some server setting on your host restricting access to this particular URL or external URLs in general, or some setting on the server hosting the file you are trying to access preventing your server from accessing it.', 'wp-all-import-pro' ) );
			} else {
				return false;
			}

			return true;
		}

		protected function private_ip_message() {
			return __( 'WP All Import was not able to download your file because its URL points to a private or local network address, which WordPress blocks by default. Download the file and upload it instead, or ask your developer to allow the host with the http_request_host_is_external filter.', 'wp-all-import-pro' );
		}
	}
}
