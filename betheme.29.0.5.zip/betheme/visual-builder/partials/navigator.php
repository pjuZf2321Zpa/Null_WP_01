<div class="mfn-modalbox mfn-navigator mfn-shadow-1">
	<div class="modalbox-header">
		<div class="options-group">
			<div class="modalbox-title-group">
				<span class="modalbox-icon mfn-icon-navigator"></span>
				<div class="modalbox-desc">
					<h4 class="modalbox-title"><?php esc_html_e('Navigator', 'mfn-opts'); ?></h4>
				</div>
			</div>
		</div>
		<div class="options-group">
			<a class="mfn-option-btn mfn-option-blank btn-large btn-navigator-toggle-all" data-tooltip="Expand" data-position="bottom" title="Toggle all" href="#"><span class="mfn-icon mfn-icon-list-collapsed"></span></a>
			<a class="mfn-option-btn mfn-option-blank btn-large btn-modal-close btn-navigator-hide" title="Close" href="#"><span class="mfn-icon mfn-icon-close"></span></a>
		</div>
	</div>
	<div class="modalbox-content" id="mfn-navigator-items">
    <div class="mfn-form">
		<ul class="mfn-sft-nav navigator-content-switcher">
			<li class="active"><a href="#full">Full-Page</a></li>
			<li><a href="#contentonly">Content</a></li>
		</ul>
    </div>
		<ul class="navigator-top-tree"></ul>
    <hr />
		<ul class="navigator-tree"></ul>
    <hr />
		<ul class="navigator-bottom-tree"></ul>
	</div>
</div>



