<?php  
if( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

echo '<div class="panel panel-ai-wrapper" style="display: none;"></div>';