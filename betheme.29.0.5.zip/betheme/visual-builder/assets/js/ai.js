(function($) {
 
var aiChat = {
    apiUrl: 'https://aiapi.muffingroup.com/api/chat',

    uid: 'global', // global - generate sections, uid - uid to edit
    section: false, // new section to replace with generated or choosed one to edit
    last_sections: [],

    usedSectionIds: [],

    mode: 'global', // global, field
    content: '',

    fields: {},
    fieldNames: {},
    fieldTypes: {},

    context_object: null,
    context_title: null,
    context_page_id: null,

    clarificationPending: {},
    verified: false,

    img_format: '4:3',

    globalBrief: {
        page_type: null,
        subject: null,
        color_scheme: null,
        additional_instructions: null
    },

    globalProgressTimer: null,
    globalProgressIndex: 0,

    globalProgressMessages: [
        'Analyzing your request and preparing the next step.',
        'Planning content structure.',
        'Selecting the best sections and layout for your website.',
        'Preparing headlines, descriptions, and calls to action.',
        'Creating images that match the style of your website.',
        'Adjusting colors, typography, and the overall visual style.',
        'Checking the consistency of the content and layout.',
        'Making final improvements and optimizing the page.',
        'Your content is almost ready. Just a moment!'
    ],

    init: function() {

        aiChat.loadLastSections();

        $builder.on("click", ".mfn-button-show-ai-iframe", function (e) {
            e.preventDefault();
            aiChat.section = $(this).closest(".section").attr("data-uid");
            aiChat.uid = 'global';
            aiChat.fieldNames.global = 'global';

            aiChat.last_sections = null;
            aiChat.mode = 'global';
            aiChat.showPanel($(this));
        });

        $(document).on("click", ".mfn-menu-button-show-global-ai", function (e) {
            e.preventDefault();

            aiChat.uid = 'global';
            aiChat.mode = 'global';

            aiChat.fieldNames.global = 'global';

            aiChat.section =
                edited_item &&
                edited_item.uid &&
                edited_item.jsclass === 'section'
                    ? edited_item.uid
                    : false;

            aiChat.showPanel($(this));
        });


        $(document).on('click', '.mfn-ai-chat-form .mfn-ai-chat-context', function(e) {
            e.preventDefault();
            aiChat.showContextModal();
        });

        $(document).on('click', '.mfn-ai-context-page-list li a', function(e) {
            e.preventDefault();

            const pageId = $(this).attr('data-page-id');
            const page = mfn.ai_context_pages?.[pageId];

            if (!page) return;

            aiChat.context_object = page.content || null;
            aiChat.context_title = page.title || null;
            aiChat.context_page_id = pageId;

            $('.mfn-ai-chat-context-wrapper').html(`
                <span class="mfn-ai-chat-context-selected">
                    <a href="#" class="mfn-ai-chat-context">
                        Context: ${page.title}
                    </a>
                    <a href="#" class="mfn-option-btn mfn-ai-chat-context-remove" title="Remove context">
                        <span class="mfn-icon mfn-icon-close"></span>
                    </a>
                </span>
            `);

            $(this).closest('.modal-ai-choose-context').remove();
        });

        $(document).on('click', '.mfn-ai-chat-context-remove', function(e) {
            e.preventDefault();
            e.stopPropagation();

            aiChat.context_object = null;
            aiChat.context_title = null;
            aiChat.context_page_id = null;

            $(this)
                .closest('.mfn-ai-chat-context-wrapper')
                .html(`
                    <a href="#" class="mfn-ai-chat-context">Include context</a>
                `);
        });

        $(document).on("click", ".mfn-button-show-ai-builder", function (e) {
            e.preventDefault();

            const uid = edited_item && edited_item.uid ? String(edited_item.uid) : 'global';

            const fieldName = $(this).closest('.mfn-form-row').attr('data-id') || '';

            aiChat.uid = uid;
            aiChat.fieldNames[uid] = fieldName;

            aiChat.mode = 'field';

            aiChat.showPanel($(this));
        });

        $(document).on('click', '.header-ai .exit-ai-chat', function(e) {
            e.preventDefault();
            $(this).closest('.modal-ai-chat').removeClass('show').hide();

            if( !edited_item ) {
                MfnVbApp.backToWidgets();
                return;
            }

            MfnVbApp.sidebar_refresh();
        });

        $(document).on('click', '.mfn-ai-chat-form .mfn-ai-chat-form-buttons .mfn-ai-chat-image-format', function(e) {
            e.preventDefault();

            if( $(this).hasClass('open') ) {
                $(this).removeClass('open');
                $(document).unbind('click', aiChat.hide_img_format);
            }else{
                $(this).addClass('open');
                $(document).bind('click', aiChat.hide_img_format);
            }
        });

        $(document).on('click', '.mfn-ai-chat-form .mfn-ai-chat-form-buttons .mfn-ai-chat-image-format a', function(e) {
            e.preventDefault();

            if( $(this).hasClass('active') ) return;

            $(this).siblings().removeClass('active');
            $(this).addClass('active');

            aiChat.img_format = $(this).attr('data-format');

            $('.mfn-ai-chat-form .mfn-ai-chat-form-buttons .mfn-ai-chat-image-format .mfn-ai-chat-image-choosen-format').text( $(this).attr('data-format') );

        });

        /*$(document).on('click', '.mfn-ai-chat-form-stop', function(e) {
            e.preventDefault();

            var uid = $(this) .closest('.mfn-ai-chat') .attr('data-ai-uid') || 'global';

            aiChat.stopThinking(uid);
        });*/


        $(document).on('click', '.mfn-clear-ai-history', function(e) {
            e.preventDefault();
            aiChat.clearAiHistory();
        });

        $(document).on('submit', '.mfn-ai-chat-form', function(e) {
            e.preventDefault();
            aiChat.submit($(this));
        });

        $(document).on('click', '.mfn-ai-use-answer', function(e) {
            e.preventDefault();

            var $message = $(this).closest('.mfn-ai-message');
            var $chat = $message.closest('.mfn-ai-chat');
            var uid = $chat.attr('data-ai-uid') || 'global';

            var text = $message .find('.mfn-ai-message-text') .text() .trim();

            aiChat.useAnswer(uid, text);

        });

        $(document).on('click', '.mfn-ai-message-text > ul > li', function(e) {
            e.preventDefault();

            var $item = $(this);
            var $messageText = $item.closest('.mfn-ai-message-text');
            var $chat = $item.closest('.mfn-ai-chat');
            var uid = $chat.attr('data-ai-uid') || 'global';

            $messageText .find('ul li.active') .removeClass('active');

            $item.addClass('active');

            aiChat.useAnswer(uid, $item.text().trim());
        });


        $(document).on('click', '.ai-intro-samples li', function(e) {
            e.preventDefault();

            var $item = $(this);
            var $chat = $item.closest('.mfn-ai-chat');
            var $form = $chat.find('.mfn-ai-chat-form');
            var text = $item.text().trim();

            $form .find('.mfn-ai-chat-input').val(text).trigger('input');

            //$form.trigger('submit');
        });


        $(document).on('click', '.mfn-ai-clear-chat', function(e) {
            e.preventDefault();

            var $chat = $(this).closest('.mfn-ai-chat');
            var uid = $chat.attr('data-ai-uid') || 'global';

            aiChat.clearChat(uid);

        });

        $(document).on('input', '.mfn-ui .mfn-form.mfn-ai-chat-form .mfn-form-control', function() {
            const style = getComputedStyle(this);
            const lineHeight = parseFloat(style.lineHeight);
            const maxHeight = lineHeight * 6;

            this.style.height = 'auto';

            const height = Math.min(
                Math.max(this.scrollHeight, lineHeight),
                maxHeight
            );

            this.style.height = height + 'px';
            this.style.overflowY =
                this.scrollHeight > maxHeight
                    ? 'auto'
                    : 'hidden';
        });

        $(document).on('keydown', '.mfn-ai-chat-input', function(e) {

                if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown' ) {
                    return;
                }

                const $input = $(this);
                const $chat = $input.closest('.mfn-ai-chat');

                if( $input.val().length ) return;

                const prompts = $chat
                    .find('.mfn-ai-message-user .mfn-ai-message-text')
                    .map(function() {
                        return $(this).text().trim();
                    })
                    .get()
                    .filter(Boolean);

                if (!prompts.length) {
                    return;
                }

                let index = $input.data('history-index');

                if (typeof index !== 'number' || Number.isNaN(index) ) {
                    index = prompts.length;
                }

                if (e.key === 'ArrowUp') {

                    if (index <= 0) {
                        return;
                    }

                    e.preventDefault();

                    index--;

                    $input.val(
                        prompts[index]
                    );

                } else {

                    if (index >= prompts.length) {
                        return;
                    }

                    e.preventDefault();

                    index++;

                    if (index >= prompts.length) {

                        $input.val('');

                    } else {

                        $input.val(
                            prompts[index]
                        );
                    }
                }

                $input.data('history-index', index );

                const el = $input[0];

                if (el) {
                    el.selectionStart =
                        el.selectionEnd =
                        el.value.length;
                }
            }
        );

        aiChat.loadUsedSections();

    },

    showContextModal: function() {

        const $modal = $(`
            <div class="mfn-modal modal-ai-choose-context show">
                <div class="mfn-modalbox mfn-form mfn-shadow-1">

                    <div class="modalbox-header">

                        <div class="options-group">
                            <div class="modalbox-title-group">
                                <span class="modalbox-icon mfn-icon-ai-gradient"></span>

                                <div class="modalbox-desc">
                                    <h4 class="modalbox-title">Choose context</h4>
                                    <div>Select a page for the AI to use as a reference when generating new content.</div>
                                </div>
                            </div>
                        </div>

                        <div class="options-group modalbox-search" style="margin-left: auto;">
                            <div class="form-control">
                                <input
                                    class="mfn-form-control mfn-form-input search mfn-search"
                                    type="search"
                                    autocomplete="off"
                                    placeholder="Search page"
                                >
                            </div>
                        </div>

                        <div class="options-group">
                            <a
                                class="mfn-option-btn mfn-option-blank btn-large mfn-ai-context-cancel"
                                title="Close"
                                href="#"
                            >
                                <span class="mfn-icon mfn-icon-close"></span>
                            </a>
                        </div>

                    </div>

                    <div class="modalbox-content">

                        <ul class="mfn-ai-context-page-list">
                            
                        </ul>

                    </div>

                </div>
            </div>
        `);

        $('.mfn-ui').append($modal);

        let searchTimer = null;
        let searchRequest = null;


        const loadPages = function(search = '') {

            const $list = $modal.find('.mfn-ai-context-page-list');

            if (searchRequest) {
                searchRequest.abort();
            }

            $list.addClass('loading');

            searchRequest = $.ajax({
                url: mfnajaxurl,
                type: 'POST',

                data: {
                    action: 'mfngetaicontextpages',
                    'mfn-builder-nonce': mfn.wpnonce,
                    search: search
                },

                success: function(response) {

                    if (
                        !response ||
                        !response.success ||
                        !response.data ||
                        !response.data.pages
                    ) {

                        $list.html(
                            '<li class="no-results">No pages found.</li>'
                        );

                        return;
                    }

                    const pages = response.data.pages;

                    mfn.ai_context_pages ??= {};

                    Object.assign(
                        mfn.ai_context_pages,
                        pages
                    );

                    const entries = Object.entries(pages);

                    if (!entries.length) {

                        $list.html(
                            '<li class="no-results">No pages found.</li>'
                        );

                        return;
                    }

                    const html = entries
                        .map(([id, page]) => {

                            const title = $('<div>')
                                .text(page.title || '')
                                .html();

                            return `
                                <li>
                                    <a href="#" data-page-id="${id}">
                                        ${title}
                                    </a>
                                </li>
                            `;
                        })
                        .join('');

                    $list.html(html);
                },

                error: function(xhr, status) {

                    if (status === 'abort') {
                        return;
                    }

                    $list.html(
                        '<li class="no-results">Could not load pages.</li>'
                    );
                },

                complete: function() {

                    $list.removeClass('loading');
                    searchRequest = null;
                }
            });

        };

        loadPages('');

        $modal.on('input', '.modalbox-search input.search', function() {

            const search = $.trim($(this).val());

            clearTimeout(searchTimer);

            searchTimer = setTimeout(function() {

                loadPages(search);

            }, 300);

        });


        $modal.on('click', '.mfn-ai-context-cancel', function(e) {

            e.preventDefault();

            clearTimeout(searchTimer);

            if (searchRequest) {
                searchRequest.abort();
            }

            $modal.remove();

        });

    },


    clearAiHistory: function() {

        let button = $('.mfn-clear-ai-history');

        if (button.hasClass('loading')) return;

        button.addClass('loading');

        const $modal = $(`
            <div class="mfn-modal modal-confirm mfn-modal-600 show">
                <div class="mfn-modalbox mfn-form mfn-shadow-1">

                    <div class="modalbox-header">
                        <div class="options-group">
                            <div class="modalbox-title-group">
                                <span class="modalbox-icon mfn-icon-delete"></span>

                                <div class="modalbox-desc">
                                    <h4 class="modalbox-title">Clear AI history</h4>
                                </div>
                            </div>
                        </div>

                        <div class="options-group">
                            <a
                                class="mfn-option-btn mfn-option-blank btn-large mfn-ai-history-cancel"
                                title="Close"
                                href="#"
                            >
                                <span class="mfn-icon mfn-icon-close"></span>
                            </a>
                        </div>
                    </div>

                    <div class="modalbox-content">
                        <img
                            class="icon"
                            alt=""
                            src="${mfn.themepath}/muffin-options/svg/warning.svg"
                        >

                        <h3>Are you sure?</h3>

                        <p>
                            Do you want to delete the AI history for <span style="color: var(--mfn-ui-text-color-3)">entire domain?</span>
                        </p>

                        <a
                            class="mfn-btn btn-wide mfn-ai-history-cancel"
                            href="#"
                        >
                            <span class="btn-wrapper">Cancel</span>
                        </a>

                        <a
                            class="mfn-btn btn-wide mfn-btn-red mfn-ai-history-clear"
                            href="#"
                        >
                            <span class="btn-wrapper">Clear history</span>
                        </a>
                    </div>

                </div>
            </div>
        `);

        $('.mfn-ui').append($modal);

        $modal.on('click', '.mfn-ai-history-cancel', function(e) {
            e.preventDefault();

            $modal.remove();
            button.removeClass('loading');
        });

        $modal.on('click', '.mfn-ai-history-clear', function(e) {

            e.preventDefault();

            const $clearButton = $(this);

            if ($clearButton.hasClass('loading')) return;

            $clearButton.addClass('loading');

            $.ajax({
                url: mfnajaxurl,
                data: {
                    action: 'mfnclearaihistory',
                    'mfn-builder-nonce': mfn.wpnonce
                },
                type: 'POST',

                success: function(response) {

                    $('.mfn-ai-chat-content .mfn-ai-chat-messages').empty();

                    $modal.remove();
                },

                error: function() {

                    $clearButton.removeClass('loading');
                },

                complete: function() {

                    button.removeClass('loading');
                }
            });
        });

    },

    hide_img_format: function(e) {
        $('.mfn-ai-chat-form .mfn-ai-chat-form-buttons .mfn-ai-chat-image-format').removeClass('open');
        $(document).unbind('click', aiChat.hide_img_format);
    },



    showPanel: function($button = null) {

        $('.panel').hide();
        $('.header').hide();
        $('.panel-ai-wrapper').show();
        $('.panel-ai-wrapper .mfn-ai-chat').hide();
        $('.header-ai').show();

        if( $('.mfn-visualbuilder .mfn-topbar .topbar-nav nav ul li.active').length ) {
            $('.mfn-visualbuilder .mfn-topbar .topbar-nav nav ul li.active').removeClass('active');
        }

        if (typeof ui_mode !== 'undefined' && ui_mode === 'dev' && $button && $button.length ) {

            $button
                .closest('li')
                .siblings('li')
                .removeClass('active');

            $button
                .closest('li')
                .addClass('active');
        }

        if( aiChat.verified ) {

            aiChat.displayChat($button);

        } else {

            $('.panel-ai-wrapper').addClass('loading');

            aiChat.verifyApi($button);
        }

    },

    verifyApi: async function($button = null) {

        try {

            const response = await fetch(
                'https://aiapi.muffingroup.com/api/verify',
                {
                    method: 'POST',

                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },

                    body: JSON.stringify({
                        license: mfn.license,
                        domain: mfn.domain
                    })
                }
            );

            $('.panel-ai-wrapper').removeClass('loading');

            if (!response.ok) {aiChat.displayChatLocked(); return false; }

            const data = await response.json();

            if (data.status !== 'success') {aiChat.displayChatLocked(); return false; }

            aiChat.verified = true;

            aiChat.displayChat($button);

            return true;

        } catch (error) {

            console.error(
                'AI verification failed:',
                error
            );

            aiChat.displayChatLocked();

            return false;
        }
    },


    displayChatLocked: function() {

        var html = `
            <div class="mfn-ai-chat mfn-ai-chat chat-intro mfn-ai-chat-locked">
      
                <div class="mfn-ai-chat-intro-content">
                    <img
                        width="120"
                        src="${aiChat.escapeAttribute(mfn.themepath)}/visual-builder/assets/svg/others/ai-locked.svg"
                        alt=""
                        loading="lazy"
                    />

                    <h3>Unlock AI Creator</h3>

                    <p>AI Creator relies on external cloud servers and is available for active Subscription plans.<br /><br />
                    Lifetime users can activate full AI functionality with the AI Extension.</p>

                    <a href="https://muffingroup.com/betheme/pricing-ai/?extension" target="_blank" class="mfn-btn mfn-btn-green"><span class="btn-wrapper">Get AI Extension</span></a>

                    <hr />

                    <h4>See How It Works</h4>

                    <a class="ai-chat-video-preview" href="https://www.youtube.com/watch?v=p8R8gUAg9JY" target="_blank" rel="nofollow"><img src="${aiChat.escapeAttribute(mfn.themepath)}/visual-builder/assets/svg/others/ai-video-preview.jpg" alt="" loading="lazy"></a>
                </div>

            </div>
        `;

        $('.panel-ai-wrapper').append(html);
        $('.mfn-ui').addClass( 'mfn-ai-panel mfn-ai-panel-intro' );

    },

    displayChat: function($button = null) {

        const fieldName = aiChat.getFieldName(aiChat.uid);

        if (
            aiChat.mode === 'field' &&
            aiChat.uid !== 'global' &&
            (!$button || !$button.length)
        ) {
            console.warn('AI field mode opened without field button');
            return;
        }


        if (aiChat.mode === 'field' && aiChat.uid !== 'global') {

            const uid = aiChat.uid;

            let $field = $();

            if ($button && $button.length) {

                const $row = $button.closest('.mfn-form-row');

                if ($row.length) {
                    $field = $row.find('.mfn-field-value');
                }
            }

            aiChat.fields[uid] ??= {};
            aiChat.fieldTypes[uid] ??= {};

            if ($field.length) {
                aiChat.fields[uid][fieldName] = $field;
            }

            if (
                edited_item?.type === 'image_gallery' &&
                fieldName === 'ids'
            ) {

                aiChat.fieldTypes[uid][fieldName] = 'gallery';

                $('.header-ai .sidebar-panel-title')
                    .text('AI Gallery Creator');

            } else if ($field.length) {

                if ($field.closest('.mfn-form-row').hasClass('mfn-field-upload')) {

                    aiChat.fieldTypes[uid][fieldName] = 'image';

                    $('.header-ai .sidebar-panel-title')
                        .text('AI Image Creator');

                } else if (
                    $field.closest('.mfn-form-row').find('.html-editor').length
                ) {

                    aiChat.fieldTypes[uid][fieldName] = 'content';

                    $('.header-ai .sidebar-panel-title')
                        .text('AI Content Creator');

                } else {

                    aiChat.fieldTypes[uid][fieldName] = 'text';

                    $('.header-ai .sidebar-panel-title')
                        .text('AI Text Creator');
                }
            }

        } else {

            $('.header-ai .sidebar-panel-title')
                .text('AI Page Creator');

            aiChat.fields.global = {};
            aiChat.fieldTypes.global = {};
        }

        var $chat = aiChat.getChat(aiChat.uid, null, aiChat.mode);

        const hasCurrentMessages = $chat.find('.mfn-ai-message').length > 0;

        const hasSavedHistory = (mfn.ai_history ?.[aiChat.uid] ?.[fieldName] ?.length || 0 ) > 0;

        if ($chat.length) {
            $chat
                .addClass('show')
                .show();

            if (!hasCurrentMessages && !hasSavedHistory) {
                $('.mfn-ui').addClass( 'mfn-ai-panel mfn-ai-panel-intro' );
            } else {
                $('.mfn-ui')
                    .addClass('mfn-ai-panel')
                    .removeClass('mfn-ai-panel-intro');
            }

            aiChat.focus(aiChat.uid);

            return;
        }

        aiChat.open(aiChat.uid, aiChat.mode);

    },

    open: function(uid, mode) {

        uid = uid || 'global';
        mode = mode || aiChat.mode;

        const fieldName =
            aiChat.getFieldName(uid);

        const historyHtml = ( mfn.ai_history?.[uid]?.[fieldName] || [] )

        .map((msg) => {

            const role =
                ['user', 'bot'].includes(msg.role)
                    ? msg.role
                    : 'bot';

            return `
                <div class="mfn-ai-message mfn-ai-message-${role}">
                    ${
                        role === 'bot'
                            ? `<img
                                class="mfn-ai-message-avatar"
                                width="30"
                                src="${aiChat.escapeAttribute(mfn.themepath)}/visual-builder/assets/svg/others/ai-logo.svg"
                                alt=""
                                loading="lazy"
                            >`
                            : ''
                    }

                    <div class="mfn-ai-message-text">
                        ${msg.message}
                    </div>

                    ${
                        role === 'bot' && Number(msg.credits_used || 0) > 0
                            ? `
                                <div class="mfn-ai-message-usage">
                                    ${Number(msg.credits_used).toLocaleString()} AI credits used
                                </div>
                            `
                            : ''
                    }

                </div>
            `;
        })
        .join('');

        var tooltipText = "Copy to prompt";

        var examples = `<ul class="ai-intro-samples">
                <li>Create a bold heading for a fitness studio</li>
                <li>Write a catchy heading for a hotel</li>
                <li>Create a modern heading for an agency</li>
                <li>Write a heading for a new collection</li>
            </ul>`;

        if( uid == 'global' ) {
            examples = `<ul class="ai-intro-samples">
                    <li data-tooltip="${tooltipText}">Create a home page for a florist shop in shades of pink.</li>
                    <li data-tooltip="${tooltipText}">Generate a ‘Contact’ page with a location map, phone number, and email address.</li>
                    <li data-tooltip="${tooltipText}">Create an ‘About’ page featuring a photo of an elderly man with glasses and a timeline describing his medical career.</li>
                </ul>`;
        }else{
            if( aiChat.fieldTypes[uid][fieldName] == 'image' ) {
                examples = `<ul class="ai-intro-samples">
                    <li data-tooltip="${tooltipText}">Modern house surrounded by nature</li>
                    <li data-tooltip="${tooltipText}">Team working in a creative office</li>
                    <li data-tooltip="${tooltipText}">Premium smartwatch product photo</li>
                    <li data-tooltip="${tooltipText}">Luxury hotel at sunset</li>
                </ul>`;
            }else if( aiChat.fieldTypes[uid][fieldName] == 'content' ) {
                examples = `<ul class="ai-intro-samples">
                    <li data-tooltip="${tooltipText}">Write an intro for a travel agency</li>
                    <li data-tooltip="${tooltipText}">Describe our web design services</li>
                    <li data-tooltip="${tooltipText}">Explain the benefits of solar energy</li>
                    <li data-tooltip="${tooltipText}">Write content for a skincare brand</li>
                    <li data-tooltip="${tooltipText}">Describe why customers choose us</li>
                </ul>`;
            }else if( aiChat.fieldTypes[uid][fieldName] == 'gallery' ) {
                examples = `<ul class="ai-intro-samples">
                    <li data-tooltip="${tooltipText}">Create a modern interior gallery</li>
                    <li data-tooltip="${tooltipText}">Create a luxury hotel gallery</li>
                    <li data-tooltip="${tooltipText}">Create a wedding photography gallery</li>
                    <li data-tooltip="${tooltipText}">Showcase modern architecture</li>
                </ul>`;
            }
        }

       var html = `

            <div
                class="mfn-ai-chat mfn-ai-chat-${aiChat.escapeAttribute(uid)}-${aiChat.escapeAttribute(fieldName)} ${!historyHtml.length ? 'chat-intro' : ''}"
                data-ai-uid="${aiChat.escapeAttribute(uid)}"
                data-ai-mode="${aiChat.escapeAttribute(mode)}"
                data-ai-field="${aiChat.escapeAttribute(fieldName)}"
            >
            ${!historyHtml.length ? `
                <div class="mfn-ai-chat-intro-content">
                    <img
                        width="60"
                        src="${aiChat.escapeAttribute(mfn.themepath)}/visual-builder/assets/svg/others/ai-logo.svg"
                        alt=""
                        loading="lazy"
                    />

                    <h3>
                        Hi <span class="username">${mfn.user_name}</span>,
                        <br />
                        How can I help you?
                    </h3>

                    <h5>Examples of queries:</h5>
                    ${examples}
                </div>
                `
            :

            ''

            }

                <div class="mfn-ai-chat-content">
                    <div class="mfn-ai-chat-messages">

                        ${historyHtml}

                    </div>
                </div>

                <div class="mfn-ai-chat-footer">
                    <form class="mfn-ai-chat-form mfn-form">
                        <div class="mfn-ai-chat-form-wrapper">
                            <textarea
                                class="mfn-ai-chat-input mfn-form-control mfn-form-input"
                                placeholder="Type your prompt here"
                                autocomplete="off"
                                rows="1"
                            ></textarea>

                            <div class="mfn-ai-chat-form-buttons">

                            ${ uid === 'global' && mode === 'global'
                                ? `
                                    <div data-tooltip="Choose a page for the AI to use as a reference." data-position="top" class="mfn-ai-chat-context-wrapper">
                                        ${
                                            aiChat.context_title
                                                ? `
                                                    <span class="mfn-ai-chat-context-selected">
                                                        <a href="#" class="mfn-ai-chat-context">
                                                            Context: ${aiChat.context_title}
                                                        </a>
                                                        <a href="#" class="mfn-option-btn mfn-ai-chat-context-remove" title="Remove context">
                                                            <span class="mfn-icon mfn-icon-close"></span>
                                                        </a>
                                                    </span>
                                                `
                                                : `
                                                    <a href="#" class="mfn-ai-chat-context">
                                                        Include context
                                                    </a>
                                                `
                                        }
                                    </div>
                                `
                                : ''
                            }

                            ${ aiChat.fieldTypes[uid][fieldName] == 'image' ? `

                                <div class="mfn-ai-chat-image-format">
                                    <span>Image format: <span class="mfn-ai-chat-image-choosen-format">${aiChat.img_format}</span><span class="mfn-icon mfn-icon-arrow-up"></span></span>
                                    <div class="mfn-ai-chat-image-format-options">
                                        <a ${ aiChat.img_format == '4:3' ? 'class="active"' : '' } href="#" data-format="4:3">4:3</a>
                                        <a ${ aiChat.img_format == '1:1' ? 'class="active"' : '' } href="#" data-format="1:1">1:1</a>
                                        <a ${ aiChat.img_format == '3:4' ? 'class="active"' : '' } href="#" data-format="3:4">3:4</a>
                                        <a ${ aiChat.img_format == '16:9' ? 'class="active"' : '' } href="#" data-format="16:9">16:9</a>
                                        <a ${ aiChat.img_format == '9:16' ? 'class="active"' : '' } href="#" data-format="9:16">9:16</a>
                                    </div>
                                </div>`

                                : ''

                            }

                                <button
                                    type="submit"
                                    class="mfn-btn mfn-btn-blue mfn-ai-chat-form-submit"
                                    aria-label="Send message"
                                >
                                    <i class="fas fa-arrow-up"></i>
                                </button>

                            </div>
                        </div>
                    </form>

                    <div class="mfn-ai-chat-footer-info">
                        AI may make mistakes, so please verify the results.
                    </div>
                </div>
            </div>
        `;

        $('.panel-ai-wrapper').append(html);

        if (uid === 'global' && mode === 'global' && aiChat.context_title) {
            $('.mfn-ai-chat-context').text(
                `Context: ${aiChat.context_title}`
            );
        }

        if(!historyHtml.length) {
            $('.mfn-ui').addClass(
                'mfn-ai-panel mfn-ai-panel-intro'
            );
        }

        aiChat.focus(uid);
    },

    saveHistory: async function(payload) {

        try {

            const saveUid = payload.uid || 'global';

            const fieldName =
                payload.fieldName ||
                aiChat.getFieldName(saveUid) ||
                'global';

            const message = String(payload.message || '');

            const historyItem = {
                uid: saveUid,
                field_name: fieldName,
                conversation_id: payload.conversationId || '',
                role: payload.user,
                message: message,
                type: payload.uid || aiChat.uid || '',
                credits_used: payload.creditsUsed || 0
            };

            const response = await fetch(mfnajaxurl, {
                method: 'POST',
                credentials: 'same-origin',
                body: new URLSearchParams({
                    action: 'mfn_ai_save_chat_history',
                    'mfn-builder-nonce': mfn.wpnonce,
                    pageid: String(mfn.pageid || ''),
                    payload: JSON.stringify(historyItem),
                }),
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                console.warn(
                    'Could not save AI chat history:',
                    data
                );

                return data;
            }

            mfn.ai_history ??= {};
            mfn.ai_history[saveUid] ??= {};
            mfn.ai_history[saveUid][fieldName] ??= [];

            mfn.ai_history[saveUid][fieldName].push({
                role: payload.user,
                message: message,
                credits_used: Number(payload.creditsUsed || 0),
            });

            return data;

        } catch (error) {

            console.warn(
                'AI chat history request failed:',
                error
            );

            return null;
        }
    },

    submit: async function($form) {

        var $chat = $form.closest('.mfn-ai-chat');

        var uid =
            $chat.attr('data-ai-uid') ||
            'global';

        var fieldName =
            aiChat.getFieldName(uid);

        var fieldType =
            aiChat.getFieldType(
                uid,
                fieldName
            );

        var $input = $form.find('.mfn-ai-chat-input');
        var message = $.trim($input.val());

        var field_value = null;

        if (!message) {
            return;
        }

        var apiMessage = message;

        if (aiChat.clarificationPending[uid]) {
            apiMessage = '*** ' + message;
            aiChat.clarificationPending[uid] = false;
        }

        if ($form.hasClass('is-loading')) return;

        aiChat.uid = uid;

        var conversationStorageKey =
            aiChat.getConversationStorageKey(uid);

        var conversationId =
            localStorage.getItem(conversationStorageKey) ||
            aiChat.getConversationId(uid);

        localStorage.setItem(
            conversationStorageKey,
            conversationId
        );

        /*var controller = new AbortController();
        var signal = controller.signal;
        aiChat.abortControllers[uid] = controller;*/

        aiChat.addMessage(uid, 'user', message);

        if (uid === 'global') {

            aiChat.startGlobalProgress(uid);

        } else {

            aiChat.addMessage(
                uid,
                'bot',
                '<div class="dots-typing"><span></span><span></span><span></span></div>'
            );

        }

        $input.val('');
        aiChat.setLoading(uid, true);

        if (aiChat.uid === 'global') {

            if (aiChat.mode === 'global' && aiChat.section && $content.find('.vb-item[data-uid="' + aiChat.section + '"]').length && $content.find('.vb-item[data-uid="' + aiChat.section + '"]').hasClass('section') && !$content.find('.vb-item[data-uid="' + aiChat.section + '"]').hasClass('empty') ) {
                field_value = MfnVbApp.get_form(aiChat.section);
            } else {
                field_value = null;
            }

            aiChat.content = MfnVbApp.get_form();

        } else {
            field_value = aiChat.getFieldValue(uid, fieldName);
        }

        try {

            var itemData = aiChat.getEditedItemData();

            void aiChat.saveHistory({
                conversationId: conversationId,

                uid: uid,
                fieldName: fieldName,
                user: 'user',
                message: message,

                creditsUsed: 0
            });


            if( fieldType == 'content' ) fieldType = 'text';


            var response = await fetch(aiChat.apiUrl, {
                method: 'POST',
                // signal: signal,

                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },

                body: JSON.stringify({
                    prompt: apiMessage,
                    conversation_id: conversationId || null,

                    uid: uid,

                    field_name: fieldName,
                    field_value: field_value,
                    field_type: fieldType == 'content' ? 'text' : fieldType,
                    mode: aiChat.mode,
                    themeversion: mfn.themeversion,
                    content: aiChat.content,
                    page_context:
                        uid === 'global' && aiChat.mode === 'global'
                            ? aiChat.context_object || null
                            : null,

                    site_title: mfn.site_title+ ' - ' +mfn.view_title,
                    page_url: window.location.href,

                    img_format: aiChat.img_format,

                    global_brief:
                        uid === 'global'
                            ? aiChat.globalBrief
                            : null,

                    domain:
                        typeof mfn !== 'undefined'
                            ? mfn.domain
                            : null,

                    license:
                        typeof mfn !== 'undefined'
                            ? mfn.license
                            : null,

                    page_settings: {
                        colors:
                            typeof color_palette !== 'undefined'
                                ? color_palette
                                : null,
                        body_background:
                            mfn?.themeoptions?.['background-body'] || null,

                        text_color:
                            mfn?.themeoptions?.['color-text'] || null,

                        h1_color: mfn?.themeoptions?.['color-h1'] || null,
                        h2_color: mfn?.themeoptions?.['color-h2'] || null,
                        h3_color: mfn?.themeoptions?.['color-h3'] || null,
                        h4_color: mfn?.themeoptions?.['color-h4'] || null,
                        h5_color: mfn?.themeoptions?.['color-h5'] || null,
                        h6_color: mfn?.themeoptions?.['color-h6'] || null,
                        p_lead_color: mfn?.themeoptions?.['color-lead'] || null,
                    },

                    used_section_ids:
                        uid === 'global'
                            ? aiChat.usedSectionIds
                            : [],

                    section_uid: uid === 'global' ? aiChat.section || null : null,

                    last_sections: uid === 'global' && Array.isArray(aiChat.last_sections) ? aiChat.last_sections : [],

                    item_uid: itemData.uid,
                    item_type: itemData.type,
                    item_alias: itemData.alias
                })
            });

            var data = await MfnVbApp.be_layout.images.parseResponse(response);

            const targetSectionUids =
                Array.isArray(data.target_section_uids)
                    ? data.target_section_uids
                    : [];


            if (!response.ok || data.success === false) {

                if (uid === 'global') {
                    aiChat.stopGlobalProgress(uid);
                }

                aiChat.displayApiError(uid, data);

                return;
            }


            if (
                uid === 'global' &&
                data.action === 'clarify'
            ) {

                aiChat.clarificationPending[uid] = true;
                aiChat.stopGlobalProgress(uid);

                if (data.brief) {

                    aiChat.globalBrief = {
                        page_type:
                            data.brief.page_type || null,

                        subject:
                            data.brief.subject || null,

                        color_scheme:
                            data.brief.color_scheme || null,

                        additional_instructions:
                            data.brief.additional_instructions || null
                    };
                }

                var clarification =
                    data.text ||
                    data.message ||
                    'Please provide more details.';

                aiChat.addMessage(
                    uid,
                    'bot',
                    clarification,
                    Number(data.usage?.credits_used || 0)
                );

                void aiChat.saveHistory({
                    conversationId:
                        data.conversation_id ||
                        conversationId,

                    uid: uid,
                    fieldName: fieldName,
                    user: 'bot',
                    message: clarification,

                    creditsUsed: Number(data.usage?.credits_used || 0)
                });

                return;
            }

            if (uid === 'global') {
                await aiChat.finishGlobalProgress(uid);
            }

            if (data.conversation_id) {
                localStorage.setItem(
                    aiChat.getConversationStorageKey(uid),
                    String(data.conversation_id)
                );
            }

            var reply =
                data.reply ||
                data.text ||
                data.message ||
                'No response.';

            /*var historyReply =
                typeof reply === 'string'
                    ? reply
                    : JSON.stringify(reply);


            void aiChat.saveHistory({
                conversationId:
                    data.conversation_id ||
                    conversationId,

                uid: uid,
                user: 'bot',
                message: uid === 'global' ? 'Content updated. Please verify it.' : historyReply
            });*/



                var historyReply;

                if (uid === 'global') {

                    let parsedReply = reply;

                    if (typeof parsedReply === 'string') {
                        try {
                            parsedReply = JSON.parse(parsedReply);
                        } catch (error) {
                            console.error(
                                'Błąd parsowania odpowiedzi do importu:',
                                error
                            );

                            throw new Error(
                                'AI returned invalid page data.'
                            );
                        }
                    }

                    const summary =
                        parsedReply?.summary ||
                        'Content updated. Please verify it.';

                    const replacements =
                        await MfnVbApp.be_layout.images.uploadGeneratedImages(
                            data.images || []
                            // signal
                        );

                    parsedReply =
                        MfnVbApp.be_layout.images.replaceImagePlaceholders(
                            parsedReply,
                            replacements
                        );

                   await aiChat.importGlobalContent(
                        uid,
                        parsedReply,
                        {
                            targetSectionUids: targetSectionUids,
                            placement: data.placement || null,
                            placementIndex:
                                Number.isInteger(data.placement_index)
                                    ? data.placement_index
                                    : null,

                            creditsUsed: Number(data.usage?.credits_used || 0)
                        }
                    );

                   if (uid === 'global' && data.global_scope === 'complete_page' ) {
                        aiChat.globalBrief = {
                            page_type: null,
                            subject: null,
                            color_scheme: null,
                            additional_instructions: null
                        };
                    }

                    if (Array.isArray(data.selected_section_ids)) {

                        aiChat.usedSectionIds = [
                            ...new Set([
                                ...aiChat.usedSectionIds,
                                ...data.selected_section_ids
                            ])
                        ];

                        aiChat.saveUsedSections();

                    }


                    historyReply = summary;
                } else if (fieldType === 'gallery') {

                    const images =
                        Array.isArray(data.images)
                            ? data.images
                            : [];

                    if (!images.length) {
                        throw new Error(
                            'AI did not generate gallery images.'
                        );
                    }

                    const replacements =
                        await MfnVbApp.be_layout.images.uploadGeneratedImages(
                            images
                        );

                    let ids = String(reply || '');

                    Object.keys(replacements).forEach(function(placeholder) {

                        const replacement = replacements[placeholder];

                        ids = ids
                            .split(placeholder)
                            .join(
                                replacement?.attachmentId
                                    ? String(replacement.attachmentId)
                                    : ''
                            );
                    });

                    ids = ids
                        .replace(/mfn-ai-image:\/\/[a-z0-9-]+/gi, '')
                        .split(',')
                        .map(value => value.trim())
                        .filter(Boolean)
                        .join(',');

                    if (!ids) {
                        throw new Error(
                            'Gallery images could not be uploaded.'
                        );
                    }

                    aiChat.useAnswer(
                        uid,
                        ids,
                        fieldName
                    );

                    aiChat.addMessage(
                        uid,
                        'bot',
                        'Gallery images generated and inserted.'
                    );

                    historyReply =
                        'Gallery images generated and inserted.';

                } else if (fieldType === 'image') {

                    const images =
                        Array.isArray(data.images)
                            ? data.images
                            : [];

                    if (!images.length) {
                        throw new Error(
                            'AI did not generate an image.'
                        );
                    }

                    const uploaded =
                        await MfnVbApp.be_layout.images.uploadGeneratedImage(
                            images[0]
                        );

                    aiChat.useAnswer(
                        uid,
                        uploaded.url,
                        fieldName
                    );

                    aiChat.addMessage(
                        uid,
                        'bot',
                        'Image generated and inserted.',
                        Number(data.usage?.credits_used || 0)
                    );

                    historyReply =
                        'Image generated and inserted.';

                } else {

                    if (
                        typeof reply === 'object' &&
                        reply !== null
                    ) {
                        reply = JSON.stringify(
                            reply,
                            null,
                            2
                        );
                    }

                    reply = String(reply);

                    aiChat.addMessage(
                        uid,
                        'bot',
                        reply,
                        Number(data.usage?.credits_used || 0)
                    );

                    historyReply = reply;
                }

                void aiChat.saveHistory({
                    conversationId:
                        data.conversation_id ||
                        conversationId,

                    uid: uid,
                    fieldName: fieldName,
                    user: 'bot',
                    message: historyReply,
                    creditsUsed: Number(data.usage?.credits_used || 0)
                });

        } catch (error) {

            /*if (uid === 'global') {
                aiChat.stopGlobalProgress(uid);
            }

            if (error && error.name === 'AbortError') {
                aiChat.addMessage(
                    uid,
                    'bot',
                    'Generation stopped by user.'
                );
            } else {
                console.error('AI chat error:', error);

                aiChat.addMessage(
                    uid,
                    'bot',
                    'Could not connect to AI API.'
                );
            }*/

            if (uid === 'global') {
                aiChat.stopGlobalProgress(uid);
            }

            console.error('AI chat error:', error);

            aiChat.addMessage(
                uid,
                'bot',
                'Could not connect to AI API.'
            );

        } finally {

            /*if (aiChat.abortControllers[uid] === controller) {
                delete aiChat.abortControllers[uid];
                aiChat.setLoading(uid, false);
            }

            aiChat.focus(uid);*/

            aiChat.setLoading(uid, false);
            aiChat.focus(uid);
        }

    },


    displayApiError: function(uid, data) {

        var message = '';

        switch (data.error_code) {

            case 'no_credits':

                message = `
                    <div class="mfn-ai-error mfn-ai-error-credits">
                        <img
                            width="55"
                            src="${aiChat.escapeAttribute(mfn.themepath)}/visual-builder/assets/svg/others/ai-error-credits.svg"
                            alt=""
                            loading="lazy"
                        >
                        <h4>No AI credits assigned</h4>

                        <p>
                            This domain doesn’t have any AI credits assigned yet. You can assign credits in your <a href="https://muffingroup.com/" target="_blank">client panel</a>
                        </p>

                        <hr />

                        <p>Need more credits?</p>

                        <a
                            href="https://muffingroup.com/betheme/pricing-ai/"
                            target="_blank"
                            class="mfn-btn mfn-btn-blue"
                        >
                            <span class="btn-wrapper">
                                Get AI credits
                            </span>
                        </a>
                    </div>
                `;

                break;


            case 'too_few_credits':

                message = `
                    <div class="mfn-ai-error mfn-ai-error-credits">
                        <img
                            width="55"
                            src="${aiChat.escapeAttribute(mfn.themepath)}/visual-builder/assets/svg/others/ai-error-credits.svg"
                            alt=""
                            loading="lazy"
                        >
                        <h4>Not enough AI credits</h4>

                        <p>
                            You don’t have enough credits to use AI Page Creator. Generating a simple page uses at least 70,000 credits. Make sure you have assigned enough credits to the domain.
                            You can add more credits in your <a target="_blank" href="https://my.muffingroup.com/">client panel</a>.
                        </p>

                        <hr />

                        <p>Need more credits?</p>


                        <a
                            href="https://muffingroup.com/betheme/pricing-ai/"
                            target="_blank"
                            class="mfn-btn mfn-btn-blue"
                        >
                            <span class="btn-wrapper">
                                Get AI credits
                            </span>
                        </a>
                    </div>
                `;

                break;


            case 'authorization_failed':

                message = `
                    <div class="mfn-ai-error">
                        <h4>AI access could not be verified</h4>
                        <p>
                            Please verify your license and website connection.
                        </p>
                    </div>
                `;

                break;


            default:

                message =
                    data.message ||
                    data.text ||
                    data.error ||
                    'Something went wrong. Please try again.';
        }

        aiChat.addMessage(
            uid,
            'bot',
            message
        );
    },

    importGlobalContent: function(
        uid,
        reply,
        operation = {}
    ) {

        const targetSectionUids =
            Array.isArray(operation.targetSectionUids)
                ? operation.targetSectionUids
                : [];

        const placement =
            operation.placement || 'after_selected';

        const placementIndex =
            Number.isInteger(operation.placementIndex)
                ? operation.placementIndex
                : null;

        const creditsUsed =
    Number(operation.creditsUsed || 0);

        return new Promise(function(resolve, reject) {
            // Bezpieczne rozbicie nowej struktury odpowiedzi z AI
            // Bezpieczne upewnienie się, że pracujemy na obiekcie
            let parsed = reply;

            if (typeof reply === 'string') {
                try {
                    parsed = JSON.parse(reply);
                } catch(e) {
                    console.error("Nie udało się sparsować 'reply' w importGlobalContent", e);
                }
            }

            const intent = parsed && parsed.intent ? parsed.intent : 'create';
            const sectionsData = parsed && parsed.sections ? parsed.sections : parsed;
            const summary = parsed && parsed.summary ? parsed.summary : 'Content updated. Please verify it.';

            const sourceSections = Array.isArray(sectionsData)
                ? sectionsData.filter((item) => item && item.jsclass === 'section')
                : [];

            const sourceSectionUids =
                intent === 'edit'
                    ? targetSectionUids.filter(Boolean)
                    : sourceSections
                        .map(section => section.uid)
                        .filter(Boolean);

            $.ajax({
                url: mfnajaxurl,
                data: {
                    action: 'importfromclipboard', // standard import reset uids by default
                    'mfn-builder-nonce': mfn.wpnonce,
                    import: JSON.stringify(sectionsData), // to podmienia uid w sekcjach, gdy intent jest edit musimy je zmapować
                    id: mfn.pageid,
                    type: 'section'
                },
                type: 'POST',
                success: function(response) {

                    if (
                        response &&
                        typeof response === 'object' &&
                        response.success === false
                    ) {
                        var message =
                            response.data &&
                            response.data.message
                                ? response.data.message
                                : 'Content could not be updated.';

                        aiChat.addMessage(
                            uid,
                            'bot',
                            message,
                            creditsUsed
                        );

                        resolve(response);
                        return;
                    }

                    aiChat.addMessage(
                        uid,
                        'bot',
                        summary,
                        creditsUsed
                    );

                    const prepared = MfnVbApp.loadExistedElementsFromObject(response.form || []);
                    const html = response.html;
                    let $insertAnchor = $();

                    mfn.pagedata = Array.isArray(mfn.pagedata) ? mfn.pagedata : [];

                    // --- OBSŁUGA INTENCJI 'EDIT' ---
                    const insertSection = function($sectionHtml) {

                        let $target = $();

                        const getPageSections = function() {
                            return $content.find(
                                '.mcb-section.vb-item'
                            ).not('.empty');
                        };

                        switch (placement) {

                            case 'start': {

                                const $first =
                                    getPageSections().first();

                                if ($first.length) {
                                    $first.before($sectionHtml);
                                } else {
                                    $builder.append($sectionHtml);
                                }

                                break;
                            }

                            case 'end': {

                                const $last =
                                    getPageSections().last();

                                if ($last.length) {
                                    $last.after($sectionHtml);
                                } else {
                                    $builder.append($sectionHtml);
                                }

                                break;
                            }

                            case 'before_selected': {

                                if (aiChat.section) {

                                    $target = $content.find(
                                        '.mcb-section.vb-item[data-uid="' +
                                        aiChat.section +
                                        '"]'
                                    );
                                }

                                if ($target.length) {
                                    $target.before($sectionHtml);
                                } else {
                                    $builder.append($sectionHtml);
                                }

                                break;
                            }

                            case 'after_target': {

                                if (targetSectionUids.length) {

                                    $target = $content.find(
                                        '.mcb-section.vb-item[data-uid="' +
                                        targetSectionUids[0] +
                                        '"]'
                                    );


                                } else if (
                                    Number.isInteger(placementIndex)
                                ) {

                                    $target =
                                        getPageSections().eq(
                                            placementIndex
                                        );
                                }

                                if ($target.length) {
                                    $target.after($sectionHtml);
                                } else {
                                    $builder.append($sectionHtml);
                                }

                                break;
                            }

                            case 'before_target': {

                                if (targetSectionUids.length) {

                                    $target = $content.find(
                                        '.mcb-section.vb-item[data-uid="' +
                                        targetSectionUids[0] +
                                        '"]'
                                    );

                                } else if (
                                    Number.isInteger(placementIndex)
                                ) {

                                    $target =
                                        getPageSections().eq(
                                            placementIndex
                                        );
                                }

                                if ($target.length) {
                                    $target.before($sectionHtml);
                                } else {
                                    $builder.append($sectionHtml);
                                }

                                break;
                            }

                            case 'after_selected':
                            default: {

                                if ($insertAnchor.length) {

                                    // Kolejne wygenerowane sekcje idą po poprzednio wstawionej
                                    $target = $insertAnchor;

                                } else if (aiChat.section) {

                                    // WAŻNE: szukamy również pustego placeholdera
                                    $target = $content.find(
                                        '.section[data-uid="' + aiChat.section + '"]'
                                    ).first();

                                }

                                if ($target.length) {

                                    $target.after($sectionHtml);

                                } else {

                                    // Tylko jeśli naprawdę nie mamy miejsca wskazanego przez użytkownika
                                    const $last = getPageSections().last();

                                    if ($last.length) {
                                        $last.after($sectionHtml);
                                    } else {
                                        $builder.append($sectionHtml);
                                    }
                                }

                                // Następna sekcja ma zostać dodana za właśnie dodaną
                                $insertAnchor = $sectionHtml;

                                break;
                            }
                        }




                        return $sectionHtml;
                    };


                    if (intent === 'edit') {

                        const returnedSections = prepared.filter(
                            (item) => item && item.jsclass === 'section'
                        );

                        const $newHtml = $('<div>').html(html);
                        const $newSections = $newHtml.children();

                        const oldElementUids = new Set();

                        sourceSectionUids.forEach(function(sectionUid) {

                            const $section = $content.find(
                                '.mcb-section.vb-item[data-uid="' + sectionUid + '"]'
                            );

                            oldElementUids.add(sectionUid);

                            $section.find('.vb-item[data-uid]').each(function() {
                                const nestedUid = $(this).attr('data-uid');

                                if (nestedUid) {
                                    oldElementUids.add(nestedUid);
                                }

                            });

                        });

                        sourceSectionUids.forEach(function(oldUid, index) {

                            const newSection = returnedSections[index];
                            const $newSectionHtml = $newSections.eq(index);

                            if (!newSection || !$newSectionHtml.length) {
                                console.warn(
                                    'Nie znaleziono nowej sekcji dla starego UID:',
                                    oldUid
                                );
                                return;
                            }

                            const $oldSection = $content.find(
                                '.mcb-section.vb-item[data-uid="' + oldUid + '"]'
                            );

                            if ($oldSection.length) {

                                // Sekcja istnieje -> normalna podmiana
                                $oldSection.replaceWith($newSectionHtml);

                            } else {

                                console.warn(
                                    'Nie znaleziono starej sekcji w DOM, dodaję jako nową:',
                                    oldUid
                                );

                                // Sekcji już nie ma -> dodajemy jak przy create
                                insertSection($newSectionHtml);
                            }

                        });


                        mfn.pagedata = mfn.pagedata.filter(function(item) {
                            return !oldElementUids.has(item.uid);
                        });


                        mfn.pagedata.push(...prepared);



                    } else {

                        const $newHtml = $('<div>').html(html);
                        const $newSections = $newHtml.children();

                        $newSections.each(function() {
                            insertSection($(this));
                        });


                        $builder.find('.section.empty').remove();

                        mfn.pagedata.push(...prepared);
                    }



                    MfnVbApp.be_layout.emptys.sections();
                    MfnVbApp.be_layout.emptys.wraps();

                    //if ($('body').hasClass('mfn-navigator-active')) be_navigator.show();
                    MfnVbApp.runAjaxElements();

                    resolve(response);

                    const returnedSections = prepared.filter(function(item) {
                        return item && item.jsclass === 'section';
                    });

                    const newSectionUids = returnedSections
                        .map(section => section.uid)
                        .filter(Boolean);

                    aiChat.last_sections =
                        aiChat.getFullSectionsByUids(newSectionUids);

                    aiChat.saveLastSections();

                    MfnVbApp.be_layout.query_loops.find_empty();

                    MfnVbApp.loopAllStyleFields();
                    MfnVbApp.inlineEditor();
                    MfnVbApp.blink();

                    if($content.find('.mfn-section-start').length) {
                        $content.find('body').removeClass('mfn-ui-empty-page');
                        $builder.find('.mfn-section-start').remove();
                    }

                },

                error: function(xhr, status, error) {

                    console.error(
                        'AI content import error:',
                        status,
                        error,
                        xhr
                    );

                    aiChat.addMessage(
                        uid,
                        'bot',
                        'Content was generated, but it could not be imported.'
                    );

                    reject(
                        new Error(
                            error ||
                            'Could not import generated content.'
                        )
                    );
                }

            });
        });
    },

    getFullSectionsByUids: function(uids) {

        return uids
            .map(function(uid) {

                try {

                    const value = MfnVbApp.get_form(uid);

                    if (!value) {
                        return null;
                    }

                    let parsed =
                        typeof value === 'string'
                            ? JSON.parse(value)
                            : value;

                    if (Array.isArray(parsed)) {
                        parsed = parsed.find(function(item) {
                            return (
                                item &&
                                item.jsclass === 'section'
                            );
                        }) || null;
                    }

                    if (
                        !parsed ||
                        parsed.jsclass !== 'section'
                    ) {
                        console.warn(
                            'MfnVbApp.get_form() did not return a section:',
                            uid,
                            parsed
                        );

                        return null;
                    }

                    return parsed;

                } catch (error) {

                    console.error(
                        'Could not prepare full section:',
                        uid,
                        error
                    );

                    return null;
                }

            })
            .filter(Boolean);
    },

    /*stopThinking: function(uid) {
        uid = uid || aiChat.uid || 'global';

        var controller = aiChat.abortControllers[uid];

        if (controller) {
            controller.abort();
        }
    },*/

    addMessage: function(uid, role, text, creditsUsed = 0) {

        if( $('.mfn-ai-message .dots-typing').length ) $('.mfn-ai-message .dots-typing').closest('.mfn-ai-message').remove();
        if( $('.mfn-ai-message.mfn-ai-global-progress-message').length ) $('.mfn-ai-message.mfn-ai-global-progress-message').remove();

        const usageHtml =
            role === 'bot' && creditsUsed > 0
                ? `
                    <div class="mfn-ai-message-usage">
                        ${creditsUsed.toLocaleString()} AI credits used
                    </div>
                `
                : '';

        role = role === 'user'
            ? 'user'
            : 'bot';

        text = text === null || typeof text === 'undefined'
            ? ''
            : String(text);

        var $chat = aiChat.getChat(uid);
        var $messages = $chat.find('.mfn-ai-chat-messages');
        var $scrollContainer = $chat.find('.mfn-ai-chat-content');

        if (!$messages.length) {
            return;
        }

        if ($chat.hasClass('chat-intro')) {
            $chat.removeClass('chat-intro');
            $chat.find('.mfn-ai-chat-intro-content').remove();

            $('.mfn-ui').removeClass('mfn-ai-panel-intro');
        }

        var avatarHtml = '';

        if (
            role === 'bot' &&
            typeof mfn !== 'undefined' &&
            mfn.themepath
        ) {
            avatarHtml = `
                <img
                    class="mfn-ai-message-avatar"
                    width="30"
                    src="${aiChat.escapeAttribute(mfn.themepath)}/visual-builder/assets/svg/others/ai-logo.svg"
                    alt=""
                    loading="lazy"
                />
            `;
        }

        var useButtonHtml = '';

        role += text.includes('dots-typing') ? ' mfn-ai-message-typing' : '';

        var messageHtml = `
            <div class="mfn-ai-message mfn-ai-message-${role}">
                ${avatarHtml}
                <div class="mfn-ai-message-text">${text}</div>
                ${usageHtml}
            </div>
        `;

        var $message = $(messageHtml);

        $messages.append($message);

        if ($scrollContainer.length) {
            $scrollContainer.scrollTop(
                $scrollContainer.prop('scrollHeight')
            );
        }
    },

    setLoading: function(uid, isLoading) {

        var $chat = aiChat.getChat(uid);
        var $form = $chat.find('.mfn-ai-chat-form');
        var $input = $form.find('.mfn-ai-chat-input');
        var $button = $form.find('.mfn-ai-chat-form-submit');

        $form.toggleClass('is-loading', isLoading);

        $button
            .prop('disabled', isLoading)
            .toggleClass('disabled', isLoading);

    },

    focus: function(uid) {
        uid = uid || aiChat.uid || 'global';

        setTimeout(function() {
            var $chat = aiChat.getChat(uid);

            if (!$chat.is(':visible')) {
                return;
            }

            $chat
                .find('.mfn-ai-chat-input')
                .trigger('focus');
        }, 50);
    },

    useAnswer: function(uid, text, fieldName) {

        uid = uid || aiChat.uid || 'global';

        fieldName =
            fieldName ||
            aiChat.getFieldName(uid);

        if( fieldName.includes('css_') ) {


            const $field = $('.mfn-ui .mfn-form .mfn-form-row[data-id="css_advanced_background_image"] .mfn-field-value');

            if (!$field.length) {
                return;
            }

            $field
                .val(text)
                .trigger('change');

            if (
                typeof re_render === 'function' &&
                $field
                    .closest('.mfn-form-row')
                    .hasClass('re_render')
            ) {
                MfnVbApp.re_render(uid);
            }

            if (
                typeof MfnVbApp !== 'undefined' &&
                typeof MfnVbApp.enableBeforeUnload ===
                    'function'
            ) {
                MfnVbApp.enableBeforeUnload();
            }


        }else{


            edited_item.attr ??= {};
            edited_item.attr[fieldName] = text;

            MfnVbApp.re_render();

        }

        /*uid = uid || aiChat.uid || 'global';

        fieldName =
            fieldName ||
            aiChat.getFieldName(uid);

        const $field =
            aiChat.getField(uid, fieldName);

        if (!$field.length) {
            return;
        }

        $field
            .val(text)
            .trigger('input')
            .trigger('change');

        if (
            typeof re_render === 'function' &&
            $field
                .closest('.mfn-form-row')
                .hasClass('re_render')
        ) {
            MfnVbApp.re_render(uid);
        }

        if (
            typeof MfnVbApp !== 'undefined' &&
            typeof MfnVbApp.enableBeforeUnload ===
                'function'
        ) {
            MfnVbApp.enableBeforeUnload();
        }*/
    },

    clearChat: function(uid) {

        uid = uid || 'global';

        aiChat.stopThinking(uid);

        if (uid === 'global') {

            aiChat.globalBrief = {
                page_type: null,
                subject: null,
                color_scheme: null,
                additional_instructions: null
            };
        }


        var $chat = aiChat.getChat(uid);

        $chat.find('.mfn-ai-chat-messages').empty();

        localStorage.removeItem(
            aiChat.getConversationStorageKey(uid)
        );

        $chat.remove();

        if (aiChat.uid === uid) {
            aiChat.open(uid);
        }

        if (uid === 'global') {
            aiChat.clearLastSections();
        }

    },

    getEditedItemData: function() {
        var item =
            typeof edited_item !== 'undefined'
                ? edited_item
                : null;

        return {
            uid:
                item && item.uid
                    ? item.uid
                    : null,

            type:
                item && item.type
                    ? item.type
                    : null,

            alias:
                item && item.alias
                    ? item.alias
                    : null
        };
    },

    getFieldValue: function(uid, fieldName) {

        if( fieldName.includes('css_') ) {

            const $field = aiChat.getField(
                uid,
                fieldName
            );

            if (!$field.length) {
                return '';
            }

            const value = $field.val();

            return value === null ||
                typeof value === 'undefined'
                    ? ''
                    : value;

        }else{

            return edited_item.attr?.[fieldName] || '';

        }

    },

    getFieldName: function(uid) {
        uid = uid || aiChat.uid || 'global';

        if (uid === 'global') {
            return 'global';
        }

        return aiChat.fieldNames[uid] || '';
    },

    getField: function(uid, fieldName) {

        uid = uid || aiChat.uid || 'global';

        fieldName =
            fieldName ||
            aiChat.getFieldName(uid);

        return aiChat.fields?.[uid]?.[fieldName] || $();
    },

    getFieldType: function(uid, fieldName) {

        uid = uid || aiChat.uid || 'global';

        if (uid === 'global') {
            return 'global';
        }

        fieldName =
            fieldName ||
            aiChat.getFieldName(uid);

        return (
            aiChat.fieldTypes?.[uid]?.[fieldName] ||
            'text'
        );
    },

    getChat: function(uid, fieldName, mode) {

        uid = String(uid || 'global');

        fieldName =
            fieldName ||
            aiChat.getFieldName(uid) ||
            '';

        mode = mode || aiChat.mode;

        return $(
            '.panel-ai-wrapper .mfn-ai-chat'
        ).filter(function() {

            return (
                String($(this).attr('data-ai-uid')) === uid &&
                String($(this).attr('data-ai-field') || '') === fieldName &&
                String($(this).attr('data-ai-mode') || '') === mode
            );

        }).first();
    },


    getLastSectionsStorageKey: function() {
        if (
            typeof mfn.pageid === 'undefined' ||
            mfn.pageid === null ||
            mfn.pageid === ''
        ) {
            return null;
        }

        return 'mfn_ai_last_sections_' + String(mfn.pageid);
    },

    loadLastSections: function() {
        var storageKey = aiChat.getLastSectionsStorageKey();

        if (!storageKey) {
            aiChat.last_sections = [];
            return;
        }

        try {
            var storedValue = localStorage.getItem(storageKey);

            if (!storedValue) {
                aiChat.last_sections = [];
                return;
            }

            var parsedValue = JSON.parse(storedValue);

            aiChat.last_sections = Array.isArray(parsedValue)
                ? parsedValue
                : [];
        } catch (error) {
            console.error(
                'Could not load AI last sections from localStorage:',
                error
            );

            aiChat.last_sections = [];
        }
    },

    saveLastSections: function() {
        var storageKey = aiChat.getLastSectionsStorageKey();

        if (!storageKey) {
            return;
        }

        try {
            localStorage.setItem(
                storageKey,
                JSON.stringify(
                    Array.isArray(aiChat.last_sections)
                        ? aiChat.last_sections
                        : []
                )
            );
        } catch (error) {
            console.error(
                'Could not save AI last sections to localStorage:',
                error
            );
        }
    },

    clearLastSections: function() {
        var storageKey = aiChat.getLastSectionsStorageKey();

        if (storageKey) {
            localStorage.removeItem(storageKey);
        }

        aiChat.last_sections = [];
    },

    getConversationStorageKey: function(uid) {
        return 'mfn_ai_' + aiChat.getConversationId(uid);
    },

    escapeAttribute: function(value) {
        return String(value === null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    },



    saveUsedSections: function() {

        localStorage.setItem(
            aiChat.getUsedSectionsStorageKey(),
            JSON.stringify(aiChat.usedSectionIds)
        );

    },

    loadUsedSections: function() {
        var storageKey = aiChat.getUsedSectionsStorageKey();

        if (!storageKey) {
            aiChat.usedSectionIds = [];
            return;
        }

        try {
            var storedValue = localStorage.getItem(storageKey);

            if (!storedValue) {
                aiChat.usedSectionIds = [];
                return;
            }

            var parsedValue = JSON.parse(storedValue);

            aiChat.usedSectionIds = Array.isArray(parsedValue)
                ? parsedValue
                : [];
        } catch (error) {
            console.error(
                'Could not load AI last sections from localStorage:',
                error
            );

            aiChat.usedSectionIds = [];
        }

    },

    getUsedSectionsStorageKey: function() {
        return 'mfn_ai_used_sections_' + String(mfn.pageid);
    },

    getConversationId: function(uid, fieldName) {

        uid = String(uid || 'global');

        fieldName =
            fieldName ||
            aiChat.getFieldName(uid) ||
            'global';

        var current_pageid = String(mfn.pageid);

        var safeUid =
            uid.replace(
                /[^a-zA-Z0-9_-]/g,
                '-'
            );

        var safeFieldName =
            String(fieldName).replace(
                /[^a-zA-Z0-9_-]/g,
                '-'
            );

        var safeDomain =
            mfn.domain.replace(
                /[^a-zA-Z0-9_-]/g,
                '_'
            );

        return (
            'ai_' +
            safeDomain + '_' +
            current_pageid + '_' +
            safeUid + '_' +
            aiChat.mode + '_' +
            safeFieldName
        );
    },

    startGlobalProgress: function(uid) {

        aiChat.stopGlobalProgress();

        aiChat.globalProgressIndex = 0;

        const messages = aiChat.globalProgressMessages;


        aiChat.addMessage(
            uid,
            'bot',
            `
                <div class="mfn-ai-global-progress">
                    <ol class="mfn-ai-global-progress-list">
                        <li class="active">
                            <span class="mfn-ai-global-progress-text">
                                ${messages[0]}
                            </span>

                            <span class="mfn-ai-progress-dots">
                                <span></span>
                                <span></span>
                                <span></span>
                            </span>
                        </li>
                    </ol>
                </div>
            `
        );

        const $chat = aiChat.getChat(uid);

        const $message = $chat
            .find('.mfn-ai-message')
            .last();

        $message.addClass('mfn-ai-global-progress-message');

        const next = function() {

            if (
                aiChat.globalProgressIndex >=
                messages.length - 2
            ) {
                return;
            }

            const delay =
                Math.floor(
                    Math.random() * (16000 - 8000 + 1)
                ) + 8000;

            aiChat.globalProgressTimer = setTimeout(function() {

                aiChat.globalProgressIndex++;

                const $progress = aiChat
                    .getChat(uid)
                    .find('.mfn-ai-global-progress-message');

                if (!$progress.length) {
                    return;
                }

                const $list = $progress.find(
                    '.mfn-ai-global-progress-list'
                );

                $list
                    .find('li.active')
                    .removeClass('active')
                    .find('.mfn-ai-progress-dots')
                    .remove();

                $list.append(`
                    <li class="active">
                        <span class="mfn-ai-global-progress-text">
                            ${messages[aiChat.globalProgressIndex]}
                        </span>

                        <span class="mfn-ai-progress-dots">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </li>
                `);

                const $scrollContainer =
                    $progress.closest('.mfn-ai-chat')
                        .find('.mfn-ai-chat-content');

                if ($scrollContainer.length) {
                    $scrollContainer.scrollTop(
                        $scrollContainer.prop('scrollHeight')
                    );
                }

                next();

            }, delay);
        };

        next();
    },

    finishGlobalProgress: async function(uid) {

        if (aiChat.globalProgressTimer) {
            clearTimeout(aiChat.globalProgressTimer);
            aiChat.globalProgressTimer = null;
        }

        const messages = aiChat.globalProgressMessages;

        const $progress = aiChat
            .getChat(uid)
            .find('.mfn-ai-global-progress-message');

        if ($progress.length) {

            const $list = $progress.find(
                '.mfn-ai-global-progress-list'
            );

            $list
                .find('li.active')
                .removeClass('active')
                .find('.mfn-ai-progress-dots')
                .remove();


            $list.append(`
                <li class="active">
                    <span class="mfn-ai-global-progress-text">
                        ${messages[messages.length - 1]}
                    </span>

                    <span class="mfn-ai-progress-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </li>
            `);

            const $scrollContainer =
                $progress.closest('.mfn-ai-chat')
                    .find('.mfn-ai-chat-content');

            if ($scrollContainer.length) {
                $scrollContainer.scrollTop(
                    $scrollContainer.prop('scrollHeight')
                );
            }
        }

        const delay =
            Math.floor(
                Math.random() * (4000 - 3000 + 1)
            ) + 3000;

        await new Promise(function(resolve) {
            setTimeout(resolve, delay);
        });
    },

    stopGlobalProgress: function(uid) {

        if (aiChat.globalProgressTimer) {
            clearTimeout(aiChat.globalProgressTimer);
            aiChat.globalProgressTimer = null;
        }

        if (uid) {
            aiChat
                .getChat(uid)
                .find('.mfn-ai-global-progress-message')
                .remove();
        } else {
            $('.mfn-ai-global-progress-message').remove();
        }

        aiChat.globalProgressIndex = 0;
    },

};


$(document).on('be:init', function() {

    aiChat.init();

});

})(jQuery);
