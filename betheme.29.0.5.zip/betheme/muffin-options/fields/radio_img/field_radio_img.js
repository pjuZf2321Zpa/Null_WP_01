(function($) {

  /* globals jQuery */

  "use strict";

  function mfnFieldRadioImg() {

    var group = '.form-group.visual-options '; // all field including builder

    $('.mfn-ui').on('click', group + '.form-control li a', function(e) {

      var $li = $(this).closest('li');

      if( $li.closest('.form-group').is('[data-ajax]') ){
        return;
      }

      if($li.find('input').val() != 'custom_tmpl' && $li.find('input').val() != 'custom_tmpl_woo'){
        e.preventDefault();

        $li.siblings('li').removeClass('active').find('input').prop('checked', false);
        $li.addClass('active').find('input').prop('checked', true).trigger('change');

      }

    });

    // theme options - shop - custom template

    if( $('.mfn-ui .shop-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl_woo"]').length ) {
      $('.mfn-ui .shop-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl_woo"]').closest('li').find('a').attr('href', 'edit.php?post_type=template&tab=shop-archive').attr('target', '_blank');
    }

    if( $('.mfn-ui .product-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl_woo"]').length ) {
      $('.mfn-ui .product-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl_woo"]').closest('li').find('a').attr('href', 'edit.php?post_type=template&tab=single-product').attr('target', '_blank');
    }

    if( $('.mfn-ui .header-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').length ) {
      $('.mfn-ui .header-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').closest('li').find('a').attr('href', 'edit.php?post_type=template&tab=header').attr('target', '_blank');
    }

    if( $('.mfn-ui .footer-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').length ) {
      $('.mfn-ui .footer-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').closest('li').find('a').attr('href', 'edit.php?post_type=template&tab=footer').attr('target', '_blank');
    }

    if( $('.mfn-ui .blog-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').length ) {
      $('.mfn-ui .blog-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').closest('li').find('a').attr('href', 'edit.php?post_type=template&tab=archive-post').attr('target', '_blank');
    }

    if( $('.mfn-ui .portfolio-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').length ) {
      $('.mfn-ui .portfolio-layout-visual-choose .form-group.visual-options .form-control li input[value="custom_tmpl"]').closest('li').find('a').attr('href', 'edit.php?post_type=template&tab=archive-portfolio').attr('target', '_blank');
    }
 

  }

  /**
   * $(document).ready
   * Specify a function to execute when the DOM is fully loaded.
   */

  $(function($) {
    mfnFieldRadioImg();
  });

})(jQuery);
