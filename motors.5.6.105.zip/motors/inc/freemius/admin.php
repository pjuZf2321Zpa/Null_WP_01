<?php
// phpcs:ignoreFile

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'motors_freemius_admin_is_enabled' ) ) {
	function motors_freemius_admin_is_enabled() {
		return function_exists( 'motors_fs' );
	}
}

if ( ! function_exists( 'motors_freemius_should_hide_theme_options' ) ) {
	/**
	 * Returns true only when Freemius is enabled and the site has no license at all (not even an expired one).
	 * An expired license still grants access to the Theme Options tab.
	 */
	function motors_freemius_should_hide_theme_options() {
		return motors_freemius_admin_is_enabled() && ! motors_freemius_has_license();
	}
}

if ( ! function_exists( 'motors_freemius_hide_theme_options_filter' ) ) {
	function motors_freemius_hide_theme_options_filter( $hide ) {
		return $hide || motors_freemius_should_hide_theme_options();
	}

	add_filter( 'dashboard_hide_theme_options', 'motors_freemius_hide_theme_options_filter' );
}

if ( ! function_exists( 'motors_freemius_sync_activation_state' ) ) {
	function motors_freemius_sync_activation_state() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return;
		}

		$activation_info = get_site_option( STM_TOKEN_OPTION );

		if ( ! is_array( $activation_info ) ) {
			$activation_info = array();
		}

		if ( ! empty( $activation_info['token'] ) && 'freemius' !== $activation_info['token'] ) {
			return;
		}

		$activation_info['token'] = 'freemius';
		$activation_info['code']  = motors_freemius_license_is_active()
			? esc_html__( 'Freemius license', 'motors' )
			: esc_html__( 'Freemius license required', 'motors' );

		update_site_option( STM_TOKEN_OPTION, $activation_info );
		set_site_transient( STM_TOKEN_CHECKED_OPTION, true, DAY_IN_SECONDS );
	}

	add_action( 'admin_init', 'motors_freemius_sync_activation_state', 0 );
}

if ( ! function_exists( 'motors_freemius_dashboard_url' ) ) {
	function motors_freemius_dashboard_url() {
		return admin_url( 'admin.php?page=stm-admin' );
	}
}

if ( ! function_exists( 'motors_freemius_dashboard_page_load' ) ) {
	function motors_freemius_dashboard_page_load() {
		if ( motors_freemius_admin_is_enabled() ) {
			motors_fs()->_account_page_load();
		}

		add_action( 'admin_head', 'motors_freemius_hide_account_tgmpa_notice' );
	}

	add_action( 'load-toplevel_page_stm-admin', 'motors_freemius_dashboard_page_load' );
}

if ( ! function_exists( 'motors_freemius_redirect_account_page' ) ) {
	function motors_freemius_redirect_account_page() {
		if (
			! is_admin()
			|| 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? 'GET' )
			|| ! isset( $_GET['page'] )
			|| 'stm-admin-account' !== sanitize_key( wp_unslash( $_GET['page'] ) )
		) {
			return;
		}

		wp_safe_redirect( motors_freemius_dashboard_url() );
		exit;
	}

	add_action( 'admin_init', 'motors_freemius_redirect_account_page', 1 );
}

if ( ! function_exists( 'motors_freemius_redirect_theme_options_page' ) ) {
	/**
	 * No longer redirects away from Theme Options — the WP menu always shows the page.
	 * Function kept as a stub to avoid fatal errors if called externally.
	 */
	function motors_freemius_redirect_theme_options_page() {}
}

if ( ! function_exists( 'motors_freemius_remove_theme_options_menu_item' ) ) {
	/**
	 * WP admin menu always shows Theme Options — no removal needed.
	 * Function kept as a stub to avoid fatal errors if called externally.
	 */
	function motors_freemius_remove_theme_options_menu_item() {}
}

if ( ! function_exists( 'motors_freemius_remove_theme_options_admin_bar_item' ) ) {
	/**
	 * Admin bar item always shows — no removal needed.
	 * Function kept as a stub to avoid fatal errors if called externally.
	 */
	function motors_freemius_remove_theme_options_admin_bar_item( $wp_admin_bar ) {}
}

if ( ! function_exists( 'motors_freemius_remove_account_menu_items' ) ) {
	function motors_freemius_remove_account_menu_items() {
		remove_submenu_page( 'stm-admin', 'stm-admin-account' );

		if ( motors_freemius_admin_is_enabled() ) {
			remove_submenu_page( 'stm-admin', motors_fs()->get_slug( 'account' ) );
		}
	}

	add_action( 'admin_menu', 'motors_freemius_remove_account_menu_items', 999 );
}

if ( ! function_exists( 'motors_freemius_hide_account_tgmpa_notice' ) ) {
	function motors_freemius_hide_account_tgmpa_notice() {
		?>
		<style>#setting-error-tgmpa{display:none!important;}</style>
		<?php
	}
}

if ( ! function_exists( 'motors_freemius_admin_assets' ) ) {
	function motors_freemius_admin_assets() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';

		wp_register_style(
			'motors-freemius-admin',
			get_template_directory_uri() . '/assets/css/layouts/admin/freemius-style.css',
			array( 'stm-startup_css' ),
			STM_ADMIN_VERSION,
			'all'
		);

		if ( in_array( $page, array( 'stm-admin', 'stm-admin-demos' ), true ) ) {
			wp_enqueue_style( 'motors-freemius-admin' );
		}

		wp_register_script(
			'motors-freemius-admin',
			get_template_directory_uri() . '/assets/js/admin/freemius-admin.js',
			array( 'jquery' ),
			STM_ADMIN_VERSION,
			true
		);

		wp_localize_script(
			'motors-freemius-admin',
			'motorsFreemiusAdmin',
			array_merge(
				array(
					'importBlocked'  => function_exists( 'motors_freemius_can_import_demos' ) && ! motors_freemius_can_import_demos(),
					'activationHtml' => motors_freemius_get_activation_box_html(),
					'showActivation' => 'stm-admin' === $page,
				),
				motors_freemius_get_admin_script_config()
			)
		);

		wp_enqueue_script( 'motors-freemius-admin' );
	}

	add_action( 'admin_enqueue_scripts', 'motors_freemius_admin_assets', 30 );
}

if ( ! function_exists( 'motors_freemius_has_license' ) ) {
	function motors_freemius_has_license() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return false;
		}

		$fs      = motors_fs();
		$license = method_exists( $fs, '_get_license' ) ? $fs->_get_license() : null;

		return is_object( $license );
	}
}

if ( ! function_exists( 'motors_freemius_get_admin_script_config' ) ) {
	function motors_freemius_get_admin_script_config() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return array();
		}

		$fs = motors_fs();
		$freemius_class = 'Freemius';
		$ajax_url       = class_exists( $freemius_class ) ? $freemius_class::ajax_url( '' ) : admin_url( 'admin-ajax.php' );

		return array(
			'ajaxUrl'            => $ajax_url,
			'moduleId'           => $fs->get_id(),
			'activateAction'     => $fs->get_ajax_action( 'activate_license' ),
			'activateSecurity'   => $fs->get_ajax_security( 'activate_license' ),
			'resendAction'       => $fs->get_ajax_action( 'resend_license_key' ),
			'resendSecurity'     => $fs->get_ajax_security( 'resend_license_key' ),
			'activatingLabel'    => esc_html__( 'Activating license', 'motors' ),
			'sendingLabel'       => esc_html__( 'Sending license key', 'motors' ),
			'resendSuccessText'  => esc_html__( 'License key sent. Please check your inbox.', 'motors' ),
			'updateLicenseLabel' => esc_html__( 'Update License', 'motors' ),
			'updatingLabel'      => esc_html__( 'Updating license', 'motors' ),
			'showLicenseKeyLabel'=> esc_attr__( 'Show license key', 'motors' ),
			'hideLicenseKeyLabel'=> esc_attr__( 'Hide license key', 'motors' ),
		);
	}
}

if ( ! function_exists( 'motors_freemius_format_license_option_label' ) ) {
	function motors_freemius_format_license_option_label( $fs, $license, $is_current = false ) {
		if ( ! is_object( $license ) || ! is_object( $fs ) ) {
			return '';
		}

		$plan       = $fs->_get_plan_by_id( $license->plan_id );
		$plan_title = is_object( $plan ) ? $plan->title : '';
		$quota      = ( 1 == $license->quota )
			? 'Single'
			: ( $license->is_unlimited() ? 'Unlimited' : $license->quota );

		$label = sprintf(
			'%1$s-Site %2$s License - %3$s',
			$quota,
			$plan_title,
			wp_strip_all_tags( $license->get_html_escaped_masked_secret_key() )
		);

		if ( $is_current ) {
			$label .= ' (' . esc_html__( 'Current', 'motors' ) . ')';
		}

		return $label;
	}
}

if ( ! function_exists( 'motors_freemius_get_available_license_options' ) ) {
	function motors_freemius_get_available_license_options() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return array();
		}

		$fs                 = motors_fs();
		$current_license    = method_exists( $fs, '_get_license' ) ? $fs->_get_license() : null;
		$current_license_id = ( is_object( $current_license ) && ! empty( $current_license->id ) ) ? (int) $current_license->id : 0;
		$user               = method_exists( $fs, 'get_user' ) ? $fs->get_user() : null;
		$user_id            = ( is_object( $user ) && ! empty( $user->id ) ) ? (int) $user->id : 0;
		$license_map        = array();

		if ( is_object( $current_license ) && ! empty( $current_license->id ) ) {
			$license_map[ (int) $current_license->id ] = $current_license;
		}

		$fs_accounts  = get_option( 'fs_accounts', array() );
		$all_licenses = is_array( $fs_accounts ) && isset( $fs_accounts['all_licenses'] ) ? $fs_accounts['all_licenses'] : array();
		$module_id    = $fs->get_id();

		if ( is_array( $all_licenses ) && isset( $all_licenses[ $module_id ] ) && is_array( $all_licenses[ $module_id ] ) ) {
			foreach ( $all_licenses[ $module_id ] as $account_license ) {
				if ( ! is_object( $account_license ) || empty( $account_license->id ) ) {
					continue;
				}

				if ( $user_id && (int) $account_license->user_id !== $user_id ) {
					continue;
				}

				$license_map[ (int) $account_license->id ] = $account_license;
			}
		}

		if ( method_exists( $fs, 'get_available_premium_licenses' ) ) {
			foreach ( $fs->get_available_premium_licenses() as $premium_license ) {
				if ( ! is_object( $premium_license ) || empty( $premium_license->id ) ) {
					continue;
				}

				$license_map[ (int) $premium_license->id ] = $premium_license;
			}
		}

		$available = array();

		foreach ( $license_map as $license_id => $premium_license ) {
			$is_current = ( $license_id === $current_license_id );

			$available[] = array(
				'id'         => $license_id,
				'left'       => method_exists( $premium_license, 'left' ) ? $premium_license->left() : 0,
				'is_current' => $is_current,
				'label'      => motors_freemius_format_license_option_label( $fs, $premium_license, $is_current ),
			);
		}

		usort(
			$available,
			function ( $first, $second ) {
				if ( ! empty( $first['is_current'] ) ) {
					return -1;
				}

				if ( ! empty( $second['is_current'] ) ) {
					return 1;
				}

				return $second['left'] - $first['left'];
			}
		);

		return $available;
	}
}

if ( ! function_exists( 'motors_freemius_get_activation_box_html' ) ) {
	function motors_freemius_get_activation_box_html() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return '';
		}

		ob_start();
		motors_freemius_render_activation_box();
		return ob_get_clean();
	}
}

if ( ! function_exists( 'motors_freemius_render_activation_box' ) ) {
	function motors_freemius_render_activation_box() {
		if ( motors_freemius_license_is_active() || motors_freemius_has_license() ) {
			motors_freemius_render_activated_license_box();
			return;
		}

		motors_freemius_render_not_activated_license_box();
	}
}

if ( ! function_exists( 'motors_freemius_render_not_activated_license_box' ) ) {
	function motors_freemius_render_not_activated_license_box() {
		?>
		<div class="stm-admin-theme_activation consulting-freemius-theme-activation">
			<div class="stm-startup-admin-content">
				<div class="stm-admin-box stm-admin-activated stm-admin-freemius-license stm-admin-freemius-license--inactive" id="consulting-freemius-license-activation">
					<div class="stm-admin-freemius-license__top">
						<div class="stm-admin-freemius-license__header stm-admin-freemius-license__text">
							<i class="stmadmin-icon-activation"></i><?php esc_html_e( 'Theme License', 'motors' ); ?>
							<span class="consulting-freemius-status consulting-freemius-status--not-activated"><?php esc_html_e( 'Not activated', 'motors' ); ?></span>
						</div>
					</div>
					<div class="consulting-freemius-activation-body">
						<p class="consulting-freemius-activation-intro"><?php esc_html_e( 'Enter the license key from your purchase confirmation email to activate Motors.', 'motors' ); ?></p>
						<div class="consulting-freemius-activation-form">
							<div class="consulting-freemius-license-input-wrap">
								<i class="stmadmin-icon-key" aria-hidden="true"></i>
								<input type="text" class="consulting-freemius-license-input" placeholder="<?php esc_attr_e( 'xxxxxxxx-xxxx-xxxx-xxxx', 'motors' ); ?>" autocomplete="off" />
							</div>
							<button type="button" class="consulting-freemius-activate-btn" disabled><?php esc_html_e( 'Activate License', 'motors' ); ?></button>
						</div>
						<div class="consulting-freemius-license-message notice notice-error inline" style="display:none;"><p></p></div>
						<button type="button" class="consulting-freemius-resend-toggle" aria-expanded="false">
							<?php esc_html_e( "Can't find your license key?", 'motors' ); ?>
							<span class="consulting-freemius-resend-toggle__chevron" aria-hidden="true"></span>
						</button>
						<div class="consulting-freemius-resend-panel" hidden>
							<p><?php esc_html_e( "Enter the email address you used during the purchase and we'll resend your license key.", 'motors' ); ?></p>
							<div class="consulting-freemius-resend-form">
								<div class="consulting-freemius-email-input-wrap">
									<i class="dashicons dashicons-email-alt" aria-hidden="true"></i>
									<input type="email" class="consulting-freemius-email-input" placeholder="<?php esc_attr_e( 'Email address', 'motors' ); ?>" autocomplete="email" />
								</div>
								<button type="button" class="consulting-freemius-resend-btn" disabled><?php esc_html_e( 'Send License Key', 'motors' ); ?></button>
							</div>
							<div class="consulting-freemius-resend-message notice notice-success inline" style="display:none;"><p></p></div>
							<div class="consulting-freemius-resend-message consulting-freemius-resend-message--error notice notice-error inline" style="display:none;"><p></p></div>
						</div>
					</div>
					<div class="consulting-freemius-activation-footer">
						<span><?php esc_html_e( 'Activation unlocks:', 'motors' ); ?></span>
						<ul>
							<li><?php esc_html_e( 'Demo import', 'motors' ); ?></li>
							<li><?php esc_html_e( 'Premium plugins', 'motors' ); ?></li>
							<li><?php esc_html_e( 'Auto updates', 'motors' ); ?></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'motors_freemius_license_needs_renew' ) ) {
	function motors_freemius_license_needs_renew( $status_slug = '' ) {
		return in_array( $status_slug, array( 'expired', 'cancelled', 'inactive' ), true );
	}
}

if ( ! function_exists( 'motors_freemius_get_renew_url' ) ) {
	function motors_freemius_get_renew_url() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return '';
		}

		$fs      = motors_fs();
		$license = method_exists( $fs, '_get_license' ) ? $fs->_get_license() : null;

		if ( ! is_object( $license ) ) {
			return method_exists( $fs, 'pricing_url' ) ? $fs->pricing_url() : '';
		}

		$subscription = method_exists( $fs, '_get_subscription' ) ? $fs->_get_subscription( $license->id ) : null;

		if ( ! method_exists( $fs, 'checkout_url' ) ) {
			return method_exists( $fs, 'pricing_url' ) ? $fs->pricing_url() : '';
		}

		return $fs->checkout_url(
			is_object( $subscription ) ?
				( 1 == $subscription->billing_cycle ? WP_FS__PERIOD_MONTHLY : WP_FS__PERIOD_ANNUALLY ) :
				WP_FS__PERIOD_LIFETIME,
			false,
			array( 'licenses' => $license->quota )
		);
	}
}

if ( ! function_exists( 'motors_freemius_render_activated_license_box' ) ) {
	function motors_freemius_render_activated_license_box() {
		$fs                 = motors_fs();
		$affix              = $fs->get_unique_affix();
		$license_details    = motors_freemius_license_details();
		$available_licenses = motors_freemius_get_available_license_options();
		$has_other_licenses = ! empty( $available_licenses );
		$show_renew_button  = motors_freemius_license_needs_renew( $license_details['status_slug'] );
		$renew_url          = $show_renew_button ? motors_freemius_get_renew_url() : '';
		$sync_action        = $affix . '_sync_license';
		$dashboard_url      = motors_freemius_dashboard_url();
		$deactivate_confirm = __( 'Deactivating your license will block all premium features, but will enable activating the license on another site. Are you sure you want to proceed?', 'motors' );
		?>
		<div class="stm-admin-theme_activation consulting-freemius-theme-activation">
			<div class="stm-startup-admin-content">
				<div class="stm-admin-box stm-admin-activated stm-admin-freemius-license" id="consulting-freemius-active-license">
					<div class="stm-admin-freemius-license__top">
						<div class="stm-admin-freemius-license__header stm-admin-freemius-license__text">
							<i class="stmadmin-icon-activation"></i><?php esc_html_e( 'Theme License', 'motors' ); ?>
							<span class="consulting-freemius-status consulting-freemius-status--<?php echo esc_attr( $license_details['status_slug'] ); ?>"><?php echo esc_html( $license_details['status'] ); ?></span>
						</div>
						<div class="consulting-freemius-top-actions">
							<form method="post" action="<?php echo esc_url( $dashboard_url ); ?>">
								<input type="hidden" name="fs_action" value="deactivate_license" />
								<?php wp_nonce_field( 'deactivate_license' ); ?>
								<button type="submit" class="consulting-freemius-top-action" onclick="return confirm('<?php echo esc_js( $deactivate_confirm ); ?>')">
									<span class="dashicons dashicons-admin-network" aria-hidden="true"></span><?php esc_html_e( 'Deactivate License', 'motors' ); ?>
								</button>
							</form>
							<span class="consulting-freemius-top-actions__sep" aria-hidden="true">|</span>
							<form method="post" action="<?php echo esc_url( $dashboard_url ); ?>">
								<input type="hidden" name="fs_action" value="<?php echo esc_attr( $sync_action ); ?>" />
								<?php wp_nonce_field( $sync_action ); ?>
								<button type="submit" class="consulting-freemius-top-action">
									<span class="dashicons dashicons-image-rotate" aria-hidden="true"></span><?php esc_html_e( 'Sync', 'motors' ); ?>
								</button>
							</form>
						</div>
					</div>
					<div class="consulting-freemius-license-grid">
						<div class="consulting-freemius-license-cell"><small><?php esc_html_e( 'Plan', 'motors' ); ?></small><strong><?php echo esc_html( $license_details['plan'] ?: '-' ); ?></strong></div>
						<div class="consulting-freemius-license-cell consulting-freemius-license-cell--expiration consulting-freemius-license-cell--<?php echo esc_attr( $license_details['status_slug'] ); ?>"><small><?php esc_html_e( 'Expiration', 'motors' ); ?></small><strong><?php echo esc_html( $license_details['expiration'] ?: '-' ); ?></strong></div>
						<div class="consulting-freemius-license-cell consulting-freemius-license-cell--key">
							<small><?php esc_html_e( 'License Key', 'motors' ); ?></small>
							<?php if ( ! empty( $license_details['license_key_full'] ) ) : ?>
								<div class="consulting-freemius-license-key-value">
									<strong>
										<span class="consulting-freemius-license-key-masked"><?php echo wp_kses_post( $license_details['license_key'] ?: '-' ); ?></span>
										<span class="consulting-freemius-license-key-full" hidden><?php echo esc_html( $license_details['license_key_full'] ); ?></span>
									</strong>
									<button type="button" class="consulting-freemius-license-key-toggle" aria-label="<?php esc_attr_e( 'Show license key', 'motors' ); ?>" aria-pressed="false">
										<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
									</button>
								</div>
							<?php else : ?>
								<strong><?php echo wp_kses_post( $license_details['license_key'] ?: '-' ); ?></strong>
							<?php endif; ?>
						</div>
						<div class="consulting-freemius-license-actions">
							<button type="button" class="consulting-freemius-change-license" aria-expanded="false"><?php esc_html_e( 'Change License', 'motors' ); ?></button>
							<?php if ( $show_renew_button && $renew_url ) : ?>
								<a class="consulting-freemius-renew-license" href="<?php echo esc_url( $renew_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Renew', 'motors' ); ?></a>
							<?php endif; ?>
						</div>
					</div>
					<div class="consulting-freemius-change-panel" hidden>
						<p class="consulting-freemius-change-intro"><?php esc_html_e( 'Please enter the license key that you received in the email right after the purchase:', 'motors' ); ?></p>
						<?php if ( $has_other_licenses ) : ?>
							<div class="consulting-freemius-change-options">
								<div class="consulting-freemius-change-option">
									<input type="radio" name="motors_freemius_license_type_<?php echo esc_attr( $affix ); ?>" value="available" class="consulting-freemius-license-type" checked />
									<div class="consulting-freemius-change-option__content">
										<?php if ( count( $available_licenses ) > 1 ) : ?>
											<div class="consulting-freemius-change-field consulting-freemius-change-field--select">
												<select class="consulting-freemius-licenses-select">
													<?php foreach ( $available_licenses as $available_license ) : ?>
														<option value="<?php echo esc_attr( $available_license['id'] ); ?>"<?php selected( ! empty( $available_license['is_current'] ) ); ?>><?php echo esc_html( $available_license['label'] ); ?></option>
													<?php endforeach; ?>
												</select>
											</div>
										<?php else : ?>
											<div class="consulting-freemius-change-field consulting-freemius-change-field--readonly">
												<i class="stmadmin-icon-key" aria-hidden="true"></i>
												<span class="consulting-freemius-available-license-display" data-license-id="<?php echo esc_attr( $available_licenses[0]['id'] ); ?>"><?php echo esc_html( $available_licenses[0]['label'] ); ?></span>
											</div>
										<?php endif; ?>
									</div>
								</div>
								<div class="consulting-freemius-change-option">
									<input type="radio" name="motors_freemius_license_type_<?php echo esc_attr( $affix ); ?>" value="other" class="consulting-freemius-license-type" />
									<div class="consulting-freemius-change-option__content">
										<div class="consulting-freemius-change-field is-disabled">
											<span class="consulting-freemius-change-field__prefix"><?php esc_html_e( 'Other', 'motors' ); ?></span>
											<i class="stmadmin-icon-key" aria-hidden="true"></i>
											<input type="text" class="consulting-freemius-other-license-input" placeholder="<?php esc_attr_e( 'Enter license key', 'motors' ); ?>" readonly />
										</div>
									</div>
								</div>
							</div>
						<?php else : ?>
							<div class="consulting-freemius-change-option consulting-freemius-change-option--solo">
								<div class="consulting-freemius-change-field">
									<i class="stmadmin-icon-key" aria-hidden="true"></i>
									<input type="text" class="consulting-freemius-other-license-input consulting-freemius-other-license-input--solo" placeholder="<?php esc_attr_e( 'Enter license key', 'motors' ); ?>" />
								</div>
							</div>
						<?php endif; ?>
						<div class="consulting-freemius-change-message notice notice-error inline" style="display:none;"><p></p></div>
						<div class="consulting-freemius-change-actions">
							<button type="button" class="consulting-freemius-change-cancel"><?php esc_html_e( 'Cancel', 'motors' ); ?></button>
							<button type="button" class="consulting-freemius-change-submit<?php echo $has_other_licenses ? ' is-enabled' : ''; ?>"<?php echo $has_other_licenses ? '' : ' disabled'; ?>><?php esc_html_e( 'Update License', 'motors' ); ?></button>
						</div>
					</div>
					<?php if ( ! empty( $license_details['owner'] ) || ! empty( $license_details['email'] ) ) : ?>
						<div class="consulting-freemius-account-footer">
							<?php if ( ! empty( $license_details['owner'] ) ) : ?>
								<span><?php esc_html_e( 'Account:', 'motors' ); ?> <strong><?php echo esc_html( $license_details['owner'] ); ?></strong></span>
							<?php endif; ?>
							<?php if ( ! empty( $license_details['email'] ) ) : ?>
								<span><?php esc_html_e( 'Email:', 'motors' ); ?> <strong><?php echo esc_html( $license_details['email'] ); ?></strong></span>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'motors_freemius_admin_footer' ) ) {
	function motors_freemius_admin_footer() {
		if ( ! motors_freemius_admin_is_enabled() ) {
			return;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';

		if ( 'stm-admin-demos' === $page && ! motors_freemius_can_import_demos() ) {
			motors_freemius_render_import_blocker();
		}
	}

	add_action( 'admin_footer', 'motors_freemius_admin_footer' );
}

if ( ! function_exists( 'motors_freemius_render_import_blocker' ) ) {
	function motors_freemius_render_import_blocker() {
		?>
		<div class="consulting-freemius-import-blocker" id="consulting-freemius-import-blocker">
			<div class="consulting-freemius-import-blocker__modal">
				<button type="button" class="consulting-freemius-import-blocker__close" aria-label="<?php esc_attr_e( 'Close', 'motors' ); ?>"></button>
				<div class="consulting-freemius-import-blocker__icon" aria-hidden="true"></div>
				<h3><?php esc_html_e( 'Active Subscription Required', 'motors' ); ?></h3>
				<p><?php esc_html_e( 'In order to import Starter Sites you must have active subscription!', 'motors' ); ?></p>
				<div class="consulting-freemius-import-blocker__actions">
					<a class="consulting-freemius-import-blocker__renew" href="<?php echo esc_url( motors_freemius_activation_url() ); ?>"><?php esc_html_e( 'Activate License', 'motors' ); ?></a>
					<button type="button" class="consulting-freemius-import-blocker__cancel"><?php esc_html_e( 'Cancel', 'motors' ); ?></button>
				</div>
			</div>
		</div>
		<?php
	}
}
