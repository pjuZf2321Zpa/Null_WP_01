<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>

<div class="wrap stm-admin-wrap stm-admin-start-screen">
	<?php
	STM_Theme_Admin_Pages::get_admin_tabs();
	require_once __DIR__ . '/theme_info.php';
	?>

	<div class="stm-admin-dashboard-bg">
		<div class="stm-admin-dashboard-wrap">
			<div class="stm-admin-left">
				<?php require_once __DIR__ . '/dashboard/changelog.php'; ?>
			</div>
			<div class="stm-admin-right">
			<?php
			$freemius_renderers = array(
				'consulting' => array(
					'is_build'   => 'consulting_is_freemius_build',
					'is_enabled' => 'consulting_freemius_admin_is_enabled',
					'render'     => 'consulting_freemius_render_activation_box',
				),
				'motors'     => array(
					'is_build'   => 'motors_is_freemius_build',
					'is_enabled' => 'motors_freemius_admin_is_enabled',
					'render'     => 'motors_freemius_render_activation_box',
				),
			);
			$theme_slug         = defined( 'STM_THEME_SLUG' ) ? strtolower( (string) STM_THEME_SLUG ) : '';

			if ( ! empty( $theme_slug ) && isset( $freemius_renderers[ $theme_slug ] ) ) {
				$ordered_renderer = array( $theme_slug => $freemius_renderers[ $theme_slug ] );
				unset( $freemius_renderers[ $theme_slug ] );
				$freemius_renderers = array_merge( $ordered_renderer, $freemius_renderers );
			}

			$freemius_rendered = false;

			foreach ( $freemius_renderers as $renderer ) {
				$can_render = ! empty( $renderer['is_build'] )
					&& ! empty( $renderer['is_enabled'] )
					&& ! empty( $renderer['render'] )
					&& function_exists( $renderer['is_build'] )
					&& function_exists( $renderer['is_enabled'] )
					&& function_exists( $renderer['render'] )
					&& call_user_func( $renderer['is_build'] )
					&& call_user_func( $renderer['is_enabled'] );

				if ( $can_render ) {
					call_user_func( $renderer['render'] );
					$freemius_rendered = true;
					break;
				}
			}

			if ( ! $freemius_rendered && apply_filters( 'stm_show_theme_activation', true ) ) {
				require_once __DIR__ . '/dashboard/theme_activation.php';
			}
			require_once __DIR__ . '/dashboard/support_community.php';
			?>
			</div>
		</div>
		<div class="stm-admin-dashboard-banners-wrap">
			<div class="stm-admin-banner">
				<a href="<?php echo esc_url( STM_PREMIUM_PLUGINS ); ?>" target="_blank">
					<img src="<?php echo esc_url( STM_Theme_Info::get_image_url( 'banner_1.png' ) ); ?>" />
				</a>
			</div>
			<div class="stm-admin-banner">
				<a href="<?php echo esc_url( STM_CUSTOMIZATION ); ?>" target="_blank">
					<img src="<?php echo esc_url( STM_Theme_Info::get_image_url( 'banner_2.png' ) ); ?>" />
				</a>
			</div>
			<?php if ( defined( 'STM_BUY_ANOTHER_LICENSE' ) ) : ?>
			<div class="stm-admin-banner">
				<a href="<?php echo esc_url( STM_BUY_ANOTHER_LICENSE ); ?>" target="_blank">
					<img src="<?php echo esc_url( STM_Theme_Info::get_image_url( 'banner_3.png' ) ); ?>" />
				</a>
			</div>
			<?php endif; ?>
		</div>
		<?php require_once __DIR__ . '/parts/developer_access_popup.php'; ?>
	</div>
</div>
