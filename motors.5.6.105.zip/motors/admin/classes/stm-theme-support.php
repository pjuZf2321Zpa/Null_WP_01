<?php

Class STM_Theme_Support
{
	private static $genDevAccessBtnText = 'Generate Access Enabled';
	private static $enableDevAccessBtnText = 'Developer Access Enabled';
	private static $genDevAccessBtnDesc = 'Generates admin access to the website.';
	private static $enableDevAccessBtnDesc = 'Click here to review the access link';
	
	public static function init()
	{
		if ( is_admin() ) {
			add_action( 'wp_ajax_stm_generate_developer_access', [ self::class, 'generate_developer_access' ] );
			add_action( 'wp_ajax_stm_revoke_developer_access', [ self::class, 'revoke_developer_access' ] );
		}
		
		add_action( 'init', [ self::class, 'check_dev_access_query' ], 99999 );
	}
	
	public static function generate_developer_access()
	{
		check_ajax_referer( 'stm_action_developer_access', 'security' );

		if ( !current_user_can( 'manage_options' ) ) {
			wp_send_json( array( 'error' => 'No access', 'code' => 401 ) );
		}
		
		$token = wp_generate_password( 32, false, false );
		$admin_id = self::get_first_admin_id();

		set_transient(
			'stm_developer_access_token',
			array(
				'token_hash' => wp_hash_password( $token ),
				'access_id'  => $admin_id,
			),
			WEEK_IN_SECONDS
		);
			
		wp_send_json( array( 'access_url' => self::get_developer_access_link( $token ), 'btn_text' => self::$enableDevAccessBtnText, 'btn_desc' => self::$enableDevAccessBtnDesc ) );
	}
	
	public static function revoke_developer_access()
	{
		check_ajax_referer( 'stm_action_developer_access', 'security' );
		
		if ( !current_user_can( 'manage_options' ) ) {
			wp_send_json( array( 'error' => 'No access', 'code' => 401 ) );
		}
		
		if ( delete_transient( 'stm_developer_access_token' ) ) {
			wp_send_json( array( 'btn_text' => self::$genDevAccessBtnText, 'btn_desc' => self::$genDevAccessBtnDesc ) );
		}
		
		wp_send_json( array( 'error' => '403 Forbidden', 'code' => 403 ) );
	}
	
	public static function get_developer_access()
	{
		return get_transient( 'stm_developer_access_token' );
	}
	
	public static function get_developer_access_link( $token = null )
	{
		if ( !current_user_can( 'manage_options' ) || !self::get_developer_access() ) {
			return;
		}

		$access = self::get_developer_access();
		if ( null === $token && is_string( $access ) ) {
			$token = $access;
		}

		if ( empty( $token ) ) {
			return;
		}

		$access_id = is_array( $access ) && ! empty( $access['access_id'] ) ? absint( $access['access_id'] ) : self::get_first_admin_id();
		$link = add_query_arg( array( 'dev_access_token' => $token, 'dev_access_id' => $access_id ), admin_url() );
			
		return $link;
	}

	private static function get_first_admin_id()
	{
		$admins = get_users( array( 'fields' => 'ID', 'role' => 'administrator', 'number' => 1 ) );

		return ! empty( $admins ) ? absint( $admins[0] ) : 0;
	}
	
	public static function check_dev_access_query()
	{
		if ( isset( $_GET['dev_access_token'] ) && isset( $_GET['dev_access_id'] ) ) {
			$token = sanitize_text_field( $_GET['dev_access_token'] );
			$accessId = absint( $_GET['dev_access_id'] );
				
			self::signin_developer_access( $token, $accessId );
		}
	}
		
	public static function signin_developer_access( $token, $accessId )
	{
		$access = self::get_developer_access();
		$is_valid = false;

		if ( is_array( $access ) && ! empty( $access['token_hash'] ) && ! empty( $access['access_id'] ) ) {
			$is_valid = wp_check_password( $token, $access['token_hash'] ) && absint( $access['access_id'] ) === absint( $accessId );
		} elseif ( is_string( $access ) ) {
			$is_valid = hash_equals( $access, $token ) && self::get_first_admin_id() === absint( $accessId );
		}

		if ( $is_valid ) {
			if ( $user = get_user_by( 'id', $accessId ) ) {
				wp_clear_auth_cookie();
				wp_set_current_user( $user->ID );
				wp_set_auth_cookie( $user->ID );
				
				if ( is_user_logged_in() ) {
					wp_safe_redirect( admin_url() );
					exit;
				} else {
					die;
				}
			}
		}
	}
}
