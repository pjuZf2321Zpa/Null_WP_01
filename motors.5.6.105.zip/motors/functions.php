<?php
// Product Registration
define( 'MOTORS_THEME', true );

$stm_token_option = get_site_option( 'stm_motors_token', [] );
$stm_token_option['token'] = 'activated';
update_site_option( 'stm_motors_token', $stm_token_option );

define( 'STM_THEME_NAME', 'Motors' );
define( 'STM_THEME_SLUG', 'motors' );
define( 'STM_THEME_CATEGORY', 'Car Dealer, Rental & Listing WordPress theme' );
define( 'STM_ENVATO_ID', '13987211' );
define( 'STM_TOKEN_OPTION', 'stm_motors_token' );
define( 'STM_TOKEN_CHECKED_OPTION', 'stm_motors_token_checked' );
define( 'STM_THEME_SETTINGS_URL', ( ! empty( get_option( 'stm_motors_chosen_template', '' ) ) ) ? 'wpcfto_motors_' . get_option( 'stm_motors_chosen_template', 'car_dealer' ) . '_settings' : 'stm-admin-demos' );
define( 'STM_GENERATE_TOKEN', 'https://docs.stylemixthemes.com/motors-theme-documentation/theme-activation' );

if ( ! function_exists( 'motors_freemius_get_object_property' ) ) {
	function motors_freemius_get_object_property( $object, $property ) {
		if ( ! is_object( $object ) ) {
			return null;
		}

		$object_vars = (array) $object;

		return array_key_exists( $property, $object_vars ) ? $object_vars[ $property ] : null;
	}
}

if ( ! function_exists( 'motors_get_submit_ticket_url' ) ) {
	function motors_get_submit_ticket_url() {
		$item_id     = 14;
		$default_url = add_query_arg(
			array( 'item_id' => $item_id ),
			'https://support.stylemixthemes.com/tickets/new/support'
		);

		// Ticket support is available only for Freemius builds; an empty URL hides the "Submit a ticket" item on the dashboard.
		if ( ! file_exists( get_template_directory() . '/freemius/start.php' ) ) {
			return '';
		}

		$fs_data = get_option( 'fs_accounts' );

		if ( ! is_array( $fs_data ) ) {
			return $default_url;
		}

		$fs_site = $fs_data['theme_sites']['motors-lifetime'] ?? $fs_data['sites']['motors-lifetime'] ?? $fs_data['theme_sites']['motors'] ?? $fs_data['sites']['motors'] ?? null;

		$fs_user_id = motors_freemius_get_object_property( $fs_site, 'user_id' );

		if ( empty( $fs_user_id ) ) {
			return $default_url;
		}

		$fs_user_id = (int) $fs_user_id;
		$fs_user    = $fs_data['users'][ $fs_user_id ] ?? null;

		if ( ! is_object( $fs_user ) ) {
			return $default_url;
		}

		return add_query_arg(
			array(
				'item_id'    => $item_id,
				'fs_id'      => $fs_user_id,
				'fs_email'   => motors_freemius_get_object_property( $fs_user, 'email' ) ?? '',
				'fs_fl_name' => trim(
					( motors_freemius_get_object_property( $fs_user, 'first' ) ?? '' ) . ' ' .
					( motors_freemius_get_object_property( $fs_user, 'last' ) ?? '' )
				),
			),
			'https://support.stylemixthemes.com/fs-ticket/new'
		);
	}
}

define( 'STM_SUBMIT_A_TICKET', motors_get_submit_ticket_url() );
define( 'STM_DEMO_SITE_URL', 'https://motors.stylemixthemes.com/' );
define( 'STM_DOCUMENTATION_URL', 'https://docs.stylemixthemes.com/motors-theme-documentation/' );
define( 'STM_CHANGELOG_URL', 'https://docs.stylemixthemes.com/motors-theme-documentation/changelog' );
define( 'STM_INSTRUCTIONS_URL', 'https://docs.stylemixthemes.com/motors-theme-documentation/theme-activation' );
define( 'STM_INSTALL_VIDEO_URL', 'https://www.youtube.com/watch?v=tJAVpV4l8wE&list=PL3Pyh_1kFGGD0Z7F5Ad7LT6xv5LLYFpWU&index=1&ab_channel=StylemixThemes' );
define( 'STM_VOTE_URL', 'https://stylemixthemes.cnflx.io/boards/motors-car-dealer-rental-classifieds' );
define( 'STM_BUY_ANOTHER_LICENSE', 'https://stylemixthemes.com/motors/' );
define( 'STM_VIDEO_TUTORIALS', 'https://www.youtube.com/playlist?list=PL3Pyh_1kFGGD0Z7F5Ad7LT6xv5LLYFpWU' );
define( 'STM_FACEBOOK_COMMUNITY', 'https://www.facebook.com/groups/motorstheme' );
define( 'STM_TEMPLATE_URI', get_template_directory_uri() );
define( 'STM_TEMPLATE_DIR', get_template_directory() );
define( 'STM_THEME_PREFIX', 'stm' );
define( 'STM_INC_PATH', get_template_directory() . '/inc' );

if ( ! defined( 'MOTORS_DEMO_SITE' ) ) {
	define( 'MOTORS_DEMO_SITE', false );
}

if ( ! defined( 'MOTORS_FREEMIUS_PRODUCT_ID' ) ) {
	define( 'MOTORS_FREEMIUS_PRODUCT_ID', '32800' );
}

if ( ! defined( 'MOTORS_FREEMIUS_PUBLIC_KEY' ) ) {
	define( 'MOTORS_FREEMIUS_PUBLIC_KEY', 'pk_e2778e7c3157e2a166c1e2769094d' );
}

if ( ! function_exists( 'motors_freemius_start_path' ) ) {
	function motors_freemius_start_path() {
		$paths = array(
			get_template_directory() . '/vendor/freemius/start.php',
			get_template_directory() . '/freemius/start.php',
		);

		foreach ( $paths as $path ) {
			if ( file_exists( $path ) ) {
				return $path;
			}
		}

		return '';
	}
}

if ( ! function_exists( 'motors_is_freemius_build' ) ) {
	function motors_is_freemius_build() {
		$freemius_start = motors_freemius_start_path();

		return ! empty( $freemius_start )
			&& (
				file_exists( get_template_directory() . '/.freemius' )
				|| ( ! empty( MOTORS_FREEMIUS_PRODUCT_ID ) && ! empty( MOTORS_FREEMIUS_PUBLIC_KEY ) )
			);
	}
}

if ( ! function_exists( 'motors_freemius_settings' ) ) {
	function motors_freemius_settings() {
		return apply_filters(
			'motors_freemius_settings',
			array(
				'id'               => MOTORS_FREEMIUS_PRODUCT_ID,
				'slug'             => 'motors-lifetime',
				'premium_slug'     => 'motors',
				'type'             => 'theme',
				'public_key'       => MOTORS_FREEMIUS_PUBLIC_KEY,
				'is_premium'       => true,
				'is_premium_only'  => true,
				'has_addons'       => false,
				'has_paid_plans'   => true,
				'is_org_compliant' => false,
				'menu'             => array(
					'slug'       => 'motors-lifetime',
					'first-path' => 'admin.php?page=stm-admin',
					'contact'    => false,
					'support'    => false,
				),
			)
		);
	}
}

if ( ! function_exists( 'motors_freemius_is_configured' ) ) {
	function motors_freemius_is_configured() {
		$settings = motors_freemius_settings();

		return ! empty( $settings['id'] ) && ! empty( $settings['public_key'] );
	}
}

if ( ! function_exists( 'motors_fs' ) && file_exists( get_template_directory() . '/freemius/start.php' ) ) {
	function motors_fs() {
		global $motors_fs;

		if ( ! isset( $motors_fs ) ) {
			require_once get_template_directory() . '/freemius/start.php';

			$motors_fs = fs_dynamic_init(
				array(
					'id'               => '32800',
					'slug'             => 'motors-lifetime',
					'premium_slug'     => 'motors',
					'type'             => 'theme',
					'public_key'       => 'pk_e2778e7c3157e2a166c1e2769094d',
					'is_premium'       => true,
					'is_premium_only'  => true,
					'has_addons'       => false,
					'has_paid_plans'   => true,
					'is_org_compliant' => false,
					'menu'             => array(
						'slug'       => 'motors-lifetime',
						'first-path' => 'admin.php?page=stm-admin',
						'contact'    => false,
						'support'    => false,
					),
				)
			);
		}

		return $motors_fs;
	}

	motors_fs();
	motors_fs()->add_filter( 'connect_url', 'motors_freemius_connect_url' );
	do_action( 'motors_fs_loaded' );
}

if ( ! function_exists( 'motors_freemius_connect_url' ) ) {
	function motors_freemius_connect_url() {
		return admin_url( 'admin.php?page=stm-admin' );
	}
}

if ( ! function_exists( 'motors_freemius_license_expiration_timestamp' ) ) {
	function motors_freemius_license_expiration_timestamp( $expiration ) {
		if ( empty( $expiration ) || ! is_string( $expiration ) ) {
			return false;
		}

		$expiration = trim( $expiration );

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $expiration ) ) {
			$expiration .= ' 23:59:59';
		}

		return strtotime( $expiration );
	}
}

if ( ! function_exists( 'motors_freemius_license_status' ) ) {
	function motors_freemius_license_status() {
		$status = array(
			'label' => esc_html__( 'Unknown', 'motors' ),
			'slug'  => 'unknown',
		);

		if ( ! function_exists( 'motors_fs' ) ) {
			return $status;
		}

		$fs      = motors_fs();
		$license = method_exists( $fs, '_get_license' ) ? $fs->_get_license() : null;

		if ( ! is_object( $license ) ) {
			return $status;
		}

		$status = array(
			'label' => esc_html__( 'Active', 'motors' ),
			'slug'  => 'active',
		);

		$expiration_timestamp = motors_freemius_license_expiration_timestamp( $license->expiration ?? '' );

		if ( false !== $expiration_timestamp && $expiration_timestamp < current_time( 'timestamp' ) ) { // phpcs:ignore
			$status = array(
				'label' => esc_html__( 'Expired', 'motors' ),
				'slug'  => 'expired',
			);
		}

		if ( method_exists( $license, 'is_expired' ) && $license->is_expired() ) {
			$status = array(
				'label' => esc_html__( 'Expired', 'motors' ),
				'slug'  => 'expired',
			);
		} elseif ( method_exists( $license, 'is_cancelled' ) && $license->is_cancelled() ) {
			$status = array(
				'label' => esc_html__( 'Cancelled', 'motors' ),
				'slug'  => 'cancelled',
			);
		} elseif ( method_exists( $license, 'is_active' ) && ! $license->is_active() ) {
			$status = array(
				'label' => esc_html__( 'Inactive', 'motors' ),
				'slug'  => 'inactive',
			);
		} elseif ( ! empty( $license->status ) && 'active' !== strtolower( $license->status ) ) {
			$status = array(
				'label' => ucwords( str_replace( '_', ' ', strtolower( $license->status ) ) ),
				'slug'  => sanitize_html_class( strtolower( str_replace( '_', '-', $license->status ) ) ),
			);
		}

		return $status;
	}
}

if ( ! function_exists( 'motors_freemius_license_is_active' ) ) {
	function motors_freemius_license_is_active() {
		$status = function_exists( 'motors_freemius_license_status' ) ? motors_freemius_license_status() : array();

		return function_exists( 'motors_fs' )
			&& motors_fs()->is__premium_only()
			&& motors_fs()->can_use_premium_code()
			&& ! empty( $status['slug'] )
			&& 'active' === $status['slug'];
	}
}

if ( ! function_exists( 'motors_freemius_can_import_demos' ) ) {
	function motors_freemius_can_import_demos() {
		return ! function_exists( 'motors_fs' ) || motors_freemius_license_is_active();
	}
}

if ( ! function_exists( 'motors_freemius_activation_url' ) ) {
	function motors_freemius_activation_url() {
		return admin_url( 'admin.php?page=stm-admin' );
	}
}

if ( ! function_exists( 'motors_freemius_license_details' ) ) {
	function motors_freemius_license_details() {
		$details = array(
			'plan'             => '',
			'expiration'       => '',
			'license_key'      => '',
			'license_key_full' => '',
			'status'           => esc_html__( 'Unknown', 'motors' ),
			'status_slug'      => 'unknown',
			'owner'            => '',
			'email'            => '',
		);

		if ( ! function_exists( 'motors_fs' ) ) {
			return $details;
		}

		$fs      = motors_fs();
		$license = method_exists( $fs, '_get_license' ) ? $fs->_get_license() : null;
		$user    = method_exists( $fs, 'get_user' ) ? $fs->get_user() : null;

		$details['plan'] = method_exists( $fs, 'get_plan_title' ) ? $fs->get_plan_title() : '';

		if ( is_object( $license ) ) {
			$status                 = motors_freemius_license_status();
			$details['status']      = $status['label'];
			$details['status_slug'] = $status['slug'];

			if ( method_exists( $license, 'is_lifetime' ) && $license->is_lifetime() ) {
				$details['plan']       = esc_html__( 'Lifetime', 'motors' );
				$details['expiration'] = esc_html__( 'No expiration', 'motors' );
			} else {
				$subscription = method_exists( $fs, '_get_subscription' ) ? $fs->_get_subscription( $license->id ) : null;

				if ( is_object( $subscription ) && isset( $subscription->billing_cycle ) ) {
					if ( 12 === (int) $subscription->billing_cycle ) {
						$details['plan'] = esc_html__( 'Annual', 'motors' );
					} elseif ( 1 === (int) $subscription->billing_cycle ) {
						$details['plan'] = esc_html__( 'Monthly', 'motors' );
					}
				} elseif ( empty( $details['plan'] ) || 'premium' === strtolower( $details['plan'] ) ) {
					$details['plan'] = esc_html__( 'Annual', 'motors' );
				}

				if ( ! empty( $license->expiration ) ) {
					$details['expiration'] = date_i18n( get_option( 'date_format' ), strtotime( $license->expiration ) );
				}
			}

			$details['license_key']      = method_exists( $license, 'get_html_escaped_masked_secret_key' ) ? $license->get_html_escaped_masked_secret_key() : '';
			$details['license_key_full'] = ! empty( $license->secret_key ) ? $license->secret_key : '';
		}

		if ( is_object( $user ) ) {
			$details['owner'] = method_exists( $user, 'get_name' ) ? $user->get_name() : '';
			$details['email'] = isset( $user->email ) ? $user->email : '';
		}

		return $details;
	}
}

if ( ! function_exists( 'motors_freemius_redirect_hidden_sdk_page' ) ) {
	function motors_freemius_redirect_hidden_sdk_page() {
		if (
			is_admin()
			&& 'GET' === $_SERVER['REQUEST_METHOD']
			&& isset( $_GET['page'] )
			&& 'motors-lifetime' === sanitize_key( $_GET['page'] )
		) {
			wp_safe_redirect( motors_freemius_activation_url() );
			exit;
		}
	}

	add_action( 'admin_init', 'motors_freemius_redirect_hidden_sdk_page', 1 );
}

if ( ! function_exists( 'motors_freemius_block_demo_import_ajax' ) ) {
	function motors_freemius_block_demo_import_ajax() {
		if ( function_exists( 'motors_fs' ) && ! motors_freemius_can_import_demos() ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Active subscription required to import demos.', 'motors' ),
				),
				403
			);
		}
	}

	add_action( 'wp_ajax_stm_install_plugin', 'motors_freemius_block_demo_import_ajax', 1 );
	add_action( 'wp_ajax_stm_demo_import_content', 'motors_freemius_block_demo_import_ajax', 1 );
}

add_action(
	'admin_notices',
	function () {
		$screen = get_current_screen();
		$check  = get_transient( 'motors_check_core_plugin_update' );

		if ( $check && 'motors_page_stm-admin-plugins' === $screen->base ) {
			echo '<div class="notice notice-warning __envato-market"><p>';
			echo sprintf( '<span class="dashicons dashicons-warning"></span><b style="padding-left: 10px;">%s</b>', esc_html__( 'Please update the plugins right below as well! It is essential to update these plugins for the theme to work properly.', 'motors' ) );
			echo '</p></div>';
		}
	},
	100,
	1
);

add_filter( 'stm_theme_enable_elementor', 'get_motors_theme_enable_elementor' );

function get_motors_theme_enable_elementor() {
	return true;
}

add_filter( 'stm_theme_default_layout', 'get_stm_theme_default_layout' );
function get_stm_theme_default_layout() {
	return 'car_dealer';
}

add_filter( 'stm_theme_default_layout_name', 'get_stm_theme_default_layout_name' );
function get_stm_theme_default_layout_name() {
	return 'car_dealer';
}

add_filter( 'stm_theme_demos', 'motors_get_demos' );
add_filter( 'stm_theme_demo_layout', 'get_stm_theme_demo_layout' );
add_filter( 'stm_theme_plugins', 'get_stm_theme_plugins' );
add_filter( 'stm_theme_layout_plugins', 'get_stm_theme_layout_plugins', 10, 1 );

function get_stm_theme_plugins() {
	return stm_require_plugins_popup( true );
}

function get_stm_theme_demo_layout( $default = '' ) {
	return get_option( 'stm_motors_chosen_template', $default );
}

$is_freemius_activation = function_exists( 'motors_is_freemius_build' ) && motors_is_freemius_build();


if ( is_admin() ) {
	if ( file_exists( get_template_directory() . '/admin/admin.php' ) ) {
		require_once get_template_directory() . '/admin/admin.php';
	}

	if ( file_exists( get_template_directory() . '/inc/freemius/admin.php' ) ) {
		require_once get_template_directory() . '/inc/freemius/admin.php';
	}

	require_once get_template_directory() . '/inc/install_plugin/install_plugin.php';
}

if ( is_admin() && $is_freemius_activation && class_exists( 'STM_Review_Notice' ) ) {
	remove_action( 'anp_popup_items', array( STM_Review_Notice::class, 'stm_review_admin_notice' ) );
}

// Include path.
$inc_path = get_template_directory() . '/inc';

// Widgets path
$widgets_path = $inc_path . '/widgets';

require_once $inc_path . '/mixpanel/init.php';

require_once $inc_path . '/classes/STM_Custom_Colors_Helper.php';
// Custom code and theme main setups
require_once $inc_path . '/setup.php';

// Helpers
require_once $inc_path . '/helpers.php';

// Cron Settings
require_once $inc_path . '/cron.php';

// Enqueue scripts and styles for theme
require_once $inc_path . '/scripts_styles.php';

// Custom code for any outputs modifying
require_once $inc_path . '/custom.php';

// Required plugins for theme
require_once $inc_path . '/tgm/tgm-plugin-registration.php';

// Custom code for any outputs modifying with ajax relation
require_once $inc_path . '/stm-ajax.php';

// Custom code for filter output
require_once $inc_path . '/user-filter.php';

// modals
require_once $inc_path . '/modals.php';

// elementor-pro compatibility
require_once $inc_path . '/theme-builder-elementor-compatibility.php';

// value my car
if ( boolval( apply_filters( 'is_listing', array( 'listing', 'listing_two', 'listing_two_elementor', 'listing_three', 'listing_one_elementor', 'listing_three_elementor', 'listing_four_elementor' ) ) ) ) {
	require_once $inc_path . '/value_my_car/value_my_car.php';
}

// Custom code for woocommerce modifying

if ( stm_is_woocommerce_activated() ) {
	require_once $inc_path . '/woocommerce_setups.php';
}

if ( in_array( get_stm_theme_demo_layout(), array( 'car_rental', 'rental_two', 'car_rental_elementor' ), true ) ) {
	require_once $inc_path . '/woocommerce_setups_rental.php';
}

if ( class_exists( '\ANP\Popup\DefaultHooks' ) && ! $is_freemius_activation ) {
	add_action( 'anp_popup_items', array( \ANP\Popup\DefaultHooks::class, 'checkEnvatoPlugin' ), 10, 1 );
}

add_filter( 'wpcf7_autop_or_not', '__return_false' );

add_action( 'template_redirect', 'stm_redirect_from_loginregister' );
function stm_redirect_from_loginregister() {
	if ( is_user_logged_in() &&
		is_page() &&
		( get_the_ID() === intval( apply_filters( 'motors_vl_get_nuxy_mod', false, 'login_page' ) ) ) &&
		! user_can( get_current_user_id(), 'manage_options' ) ) {

		wp_safe_redirect( add_query_arg( array( 'page' => 'settings' ), stm_get_author_link( '' ) ) );
		exit;
	}
}

add_action(
	'current_screen',
	function () {
		if ( is_admin() ) {
			$current_demo = apply_filters( 'stm_theme_demo_layout', '' );

			if ( class_exists( 'STM_Theme_Info' ) && ! empty( STM_Theme_Info::get_activation_token() ) && ! empty( $current_demo ) && class_exists( 'STM_TGM_Plugins' ) ) {
				$plugins = STM_TGM_Plugins::get_plugins_data( $current_demo );

				if ( is_array( $plugins ) && count( $plugins ) > 0 && array_key_exists( 'has_update', $plugins ) && count( $plugins['has_update'] ) > 0 ) {

					$pl = array_filter(
						$plugins['has_update'],
						function ( $plugin ) {
							if ( in_array( $plugin['slug'], array( 'motors-car-dealership-classified-listings', 'stm-motors-extends' ), true ) ) {
								return $plugin;
							}
						}
					);

					if ( count( $pl ) > 0 ) {
						set_transient( 'motors_check_core_plugin_update', true );

						foreach ( $pl as $plugin ) {
							if ( in_array( $plugin['file_path'], (array) get_option( 'active_plugins', array() ), true ) ) {

								$logo = ( 'motors-car-dealership-classified-listings' === $plugin['slug'] ) ? 'motors_plugin.svg' : 'motors.svg';

								$init_data = array(
									'notice_type'          => 'plugin',
									'notice_title'         => 'New version of ' . $plugin['name'],
									'notice_logo'          => $logo,
									'notice_desc'          => sprintf( 'Update the %1s plugin to %2s version now!', $plugin['name'], $plugin['update_version'] ),
									'notice_btn_one'       => admin_url( 'plugins.php' ),
									'notice_btn_one_title' => 'Update Plugin',
								);

								stm_admin_notices_init( $init_data );
							}
						}
					} else {
						delete_transient( 'motors_check_core_plugin_update' );
					}
				}
			}

			if ( in_array( 'stm_vehicles_listing/stm_vehicles_listing.php', (array) get_option( 'active_plugins', array() ), true ) ) {
				require_once get_template_directory() . '/partials/modals/hard-popup.php';
				$init_data = array(
					'notice_type'          => 'animate-triangle-notice',
					'notice_logo'          => 'attent_triangle.svg',
					'notice_title'         => esc_html__( 'Discover Our New Motors Plugin Page!', 'motors' ),
					'notice_desc'          => esc_html__( 'We\'ve moved our Motors plugin page! Check out the new and improved version.', 'motors' ),
					'notice_btn_one_title' => esc_html__( 'Install & Active', 'motors' ),
					'notice_btn_one'       => 'https://downloads.wordpress.org/plugin/motors-car-dealership-classified-listings.zip',
					'notice_btn_one_class' => 'motors_vl_theme_install_button',
				);

				stm_admin_notices_init( $init_data );
			}
		}
	},
	10,
	1
);

function disable_activate_button_for_motors_old_plugin( $actions, $plugin_file ) {
	$plugin_to_disable = 'stm_vehicles_listing/stm_vehicles_listing.php';
	if ( $plugin_file === $plugin_to_disable && isset( $actions['activate'] ) ) {
		unset( $actions['activate'] );
	}

	return $actions;
}

add_filter( 'plugin_action_links', 'disable_activate_button_for_motors_old_plugin', 10, 2 );