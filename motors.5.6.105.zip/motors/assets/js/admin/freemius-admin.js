(function ($) {
    'use strict';

    var config = window.motorsFreemiusAdmin || {};

    function replaceDashboardActivation() {
        if (!config.showActivation || !config.activationHtml) {
            return;
        }

        var $rightColumn = $('.stm-admin-right');

        if (!$rightColumn.length) {
            return;
        }

        if ($rightColumn.find('#consulting-freemius-license-activation, #consulting-freemius-active-license').length) {
            initInlineLicenseActivation($rightColumn);
            initInlineChangeLicense($rightColumn);
            return;
        }

        $rightColumn.find('.stm-admin-theme_activation').remove();
        $rightColumn.prepend(config.activationHtml);
        initInlineLicenseActivation($rightColumn);
        initInlineChangeLicense($rightColumn);
    }

    function showImportBlocker() {
        $('#consulting-freemius-import-blocker').addClass('is-active');
    }

    function isValidEmail(email) {
        return email.indexOf('@') > -1;
    }

    function parseFreemiusResponse(result) {
        if (result === null || result === undefined || result === '') {
            return { success: false, error: 'Empty response from server.' };
        }

        if (typeof result === 'number' || result === '-1' || result === '0') {
            return { success: false, error: 'Session expired. Please refresh the page and try again.' };
        }

        if (typeof result === 'object') {
            return result;
        }

        if (typeof result === 'string') {
            try {
                return $.parseJSON(result);
            } catch (error) {
                return { success: false, error: result };
            }
        }

        return { success: false, error: 'Unexpected server response.' };
    }

    function getActivationBox($context) {
        return ($context && $context.length ? $context : $(document)).find('#consulting-freemius-license-activation');
    }

    function getActiveLicenseBox($context) {
        return ($context && $context.length ? $context : $(document)).find('#consulting-freemius-active-license');
    }

    function setButtonEnabled($button, enabled) {
        $button.prop('disabled', !enabled);
        $button.toggleClass('is-enabled', enabled);
    }

    function setButtonLoading($button, loading, loadingLabel, defaultLabel) {
        $button.toggleClass('is-loading', loading);
        $button.prop('disabled', loading);
        $button.text(loading ? loadingLabel : defaultLabel);
    }

    function showInlineMessage($message, text) {
        if (!$message.length) {
            return;
        }

        $message.find('p').text(text);
        $message.show();
    }

    function hideInlineMessage($message) {
        if (!$message.length) {
            return;
        }

        $message.hide().find('p').text('');
    }

    function requestLicenseActivation(data, callbacks) {
        $.ajax({
            url: config.ajaxUrl,
            method: 'POST',
            dataType: 'json',
            data: $.extend({
                action: config.activateAction,
                security: config.activateSecurity,
                module_id: config.moduleId,
                is_extensions_tracking_allowed: 1,
                is_diagnostic_tracking_allowed: 1
            }, data),
            success: function (result) {
                var resultObj = parseFreemiusResponse(result);

                if (resultObj.success) {
                    window.location.href = resultObj.next_page || window.location.href;
                    return;
                }

                var errorMessage = resultObj.error && resultObj.error.message ?
                  resultObj.error.message :
                  (resultObj.error || 'License activation failed.');

                if (callbacks && callbacks.error) {
                    callbacks.error(errorMessage);
                }
            },
            error: function (xhr) {
                var errorMessage = 'License activation failed. Please try again.';

                if (xhr.responseText) {
                    var parsed = parseFreemiusResponse(xhr.responseText);

                    if (parsed.error) {
                        errorMessage = parsed.error.message || parsed.error;
                    }
                }

                if (callbacks && callbacks.error) {
                    callbacks.error(errorMessage);
                }
            }
        });
    }

    function initInlineLicenseActivation($context) {
        var $box = getActivationBox($context);

        if (!$box.length || !config.ajaxUrl || !config.activateAction || $box.data('consultingFreemiusActivationInit')) {
            return;
        }

        $box.data('consultingFreemiusActivationInit', true);

        var $licenseInput = $box.find('.consulting-freemius-license-input');
        var $activateButton = $box.find('.consulting-freemius-activate-btn');
        var $licenseMessage = $box.find('.consulting-freemius-license-message');
        var $resendToggle = $box.find('.consulting-freemius-resend-toggle');
        var $resendPanel = $box.find('.consulting-freemius-resend-panel');
        var $emailInput = $box.find('.consulting-freemius-email-input');
        var $resendButton = $box.find('.consulting-freemius-resend-btn');
        var $resendSuccessMessage = $box.find('.consulting-freemius-resend-message.notice-success');
        var $resendErrorMessage = $box.find('.consulting-freemius-resend-message--error');
        var activateLabel = $activateButton.text();
        var resendLabel = $resendButton.text();
        var licenseTimeout = null;

        function updateActivateButtonState() {
            var hasLicenseKey = $.trim($licenseInput.val()).length > 0;
            setButtonEnabled($activateButton, hasLicenseKey && !$activateButton.hasClass('is-loading'));
        }

        function updateResendButtonState() {
            var email = $.trim($emailInput.val());
            setButtonEnabled($resendButton, isValidEmail(email) && !$resendButton.hasClass('is-loading'));
        }

        $licenseInput.on('input propertychange keyup paste', function () {
            clearTimeout(licenseTimeout);
            licenseTimeout = setTimeout(function () {
                hideInlineMessage($licenseMessage);
                updateActivateButtonState();
            }, 150);
        });

        $activateButton.on('click', function (event) {
            event.preventDefault();

            if ($activateButton.prop('disabled') || $activateButton.hasClass('is-loading')) {
                return;
            }

            var licenseKey = $.trim($licenseInput.val());

            if (!licenseKey.length) {
                return;
            }

            hideInlineMessage($licenseMessage);
            setButtonLoading($activateButton, true, config.activatingLabel + '...', activateLabel);

            requestLicenseActivation({ license_key: licenseKey }, {
                error: function (errorMessage) {
                    showInlineMessage($licenseMessage, errorMessage);
                    setButtonLoading($activateButton, false, config.activatingLabel + '...', activateLabel);
                    updateActivateButtonState();
                }
            });
        });

        $resendToggle.on('click', function (event) {
            event.preventDefault();

            var isOpen = $resendToggle.hasClass('is-open');

            $resendToggle.toggleClass('is-open', !isOpen);
            $resendToggle.attr('aria-expanded', !isOpen ? 'true' : 'false');
            $resendPanel.prop('hidden', isOpen);

            if (!isOpen) {
                $emailInput.trigger('focus');
            }
        });

        $emailInput.on('input propertychange keyup paste blur', function () {
            hideInlineMessage($resendSuccessMessage);
            hideInlineMessage($resendErrorMessage);
            updateResendButtonState();
        });

        $resendButton.on('click', function (event) {
            event.preventDefault();

            if ($resendButton.prop('disabled') || $resendButton.hasClass('is-loading')) {
                return;
            }

            var email = $.trim($emailInput.val());

            if (!isValidEmail(email)) {
                return;
            }

            hideInlineMessage($resendSuccessMessage);
            hideInlineMessage($resendErrorMessage);
            setButtonLoading($resendButton, true, config.sendingLabel + '...', resendLabel);

            $.ajax({
                url: config.ajaxUrl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: config.resendAction,
                    security: config.resendSecurity,
                    module_id: config.moduleId,
                    email: email
                },
                success: function (result) {
                    var resultObj = parseFreemiusResponse(result);

                    if (resultObj.success) {
                        showInlineMessage($resendSuccessMessage, config.resendSuccessText);
                        setButtonLoading($resendButton, false, config.sendingLabel + '...', resendLabel);
                        updateResendButtonState();
                        return;
                    }

                    showInlineMessage($resendErrorMessage, resultObj.error || 'Unable to resend the license key.');
                    setButtonLoading($resendButton, false, config.sendingLabel + '...', resendLabel);
                    updateResendButtonState();
                },
                error: function () {
                    showInlineMessage($resendErrorMessage, 'Unable to resend the license key. Please try again.');
                    setButtonLoading($resendButton, false, config.sendingLabel + '...', resendLabel);
                    updateResendButtonState();
                }
            });
        });

        updateActivateButtonState();
        updateResendButtonState();
    }

    function initInlineChangeLicense($context) {
        var $box = getActiveLicenseBox($context);

        if (!$box.length || !config.ajaxUrl || !config.activateAction || $box.data('consultingFreemiusChangeInit')) {
            return;
        }

        $box.data('consultingFreemiusChangeInit', true);

        var $toggleButton = $box.find('.consulting-freemius-change-license');
        var $panel = $box.find('.consulting-freemius-change-panel');
        var $licenseTypes = $box.find('.consulting-freemius-license-type');
        var $licenseSelect = $box.find('.consulting-freemius-licenses-select');
        var $availableDisplay = $box.find('.consulting-freemius-available-license-display');
        var $otherInput = $box.find('.consulting-freemius-other-license-input').not('.consulting-freemius-other-license-input--solo');
        var $otherOption = $otherInput.closest('.consulting-freemius-change-option');
        var $availableOption = $licenseTypes.filter('[value="available"]').closest('.consulting-freemius-change-option');
        var $soloInput = $box.find('.consulting-freemius-other-license-input--solo');
        var $submitButton = $box.find('.consulting-freemius-change-submit');
        var $cancelButton = $box.find('.consulting-freemius-change-cancel');
        var $message = $box.find('.consulting-freemius-change-message');
        var submitLabel = $submitButton.text();
        var hasLicenseTypes = $licenseTypes.length > 0;

        $box.find('.consulting-freemius-license-key-toggle').on('click', function (event) {
            event.preventDefault();

            var $button = $(this);
            var $valueWrap = $button.closest('.consulting-freemius-license-key-value');
            var $masked = $valueWrap.find('.consulting-freemius-license-key-masked');
            var $full = $valueWrap.find('.consulting-freemius-license-key-full');
            var $icon = $button.find('.dashicons');
            var isFullVisible = !$full.prop('hidden');

            if (isFullVisible) {
                $full.prop('hidden', true);
                $masked.prop('hidden', false);
                $icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
                $button.attr('aria-label', config.showLicenseKeyLabel || 'Show license key');
                $button.attr('aria-pressed', 'false');
            } else {
                $full.prop('hidden', false);
                $masked.prop('hidden', true);
                $icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
                $button.attr('aria-label', config.hideLicenseKeyLabel || 'Hide license key');
                $button.attr('aria-pressed', 'true');
            }
        });

        function isOtherLicenseSelected() {
            return hasLicenseTypes && $licenseTypes.filter(':checked').val() === 'other';
        }

        function isAvailableLicenseSelected() {
            return hasLicenseTypes && $licenseTypes.filter(':checked').val() === 'available';
        }

        function closePanel() {
            $panel.prop('hidden', true);
            $toggleButton.removeClass('is-open');
            $toggleButton.attr('aria-expanded', 'false');
            hideInlineMessage($message);
        }

        function openPanel() {
            $panel.prop('hidden', false);
            $toggleButton.addClass('is-open');
            $toggleButton.attr('aria-expanded', 'true');

            if (isOtherLicenseSelected()) {
                $otherInput.prop('readonly', false).trigger('focus');
            } else if ($soloInput.length) {
                $soloInput.trigger('focus');
            }
        }

        function updateSubmitState() {
            var canSubmit = false;

            if ($soloInput.length) {
                canSubmit = $.trim($soloInput.val()).length > 0;
            } else if (isOtherLicenseSelected()) {
                canSubmit = $.trim($otherInput.val()).length > 0;
            } else {
                canSubmit = true;
            }

            setButtonEnabled($submitButton, canSubmit && !$submitButton.hasClass('is-loading'));
        }

        function selectOtherLicenseType(shouldFocus) {
            var $otherRadio = $licenseTypes.filter('[value="other"]');

            if (!$otherRadio.length) {
                return;
            }

            if (!$otherRadio.prop('checked')) {
                $otherRadio.prop('checked', true).trigger('change');
                return;
            }

            if (shouldFocus && $otherInput.length) {
                $otherInput.trigger('focus');
            }
        }

        function selectAvailableLicenseType(shouldFocus) {
            var $availableRadio = $licenseTypes.filter('[value="available"]');

            if (!$availableRadio.length) {
                return;
            }

            if (!$availableRadio.prop('checked')) {
                $availableRadio.prop('checked', true).trigger('change');
                return;
            }

            if (shouldFocus && $licenseSelect.length) {
                $licenseSelect.trigger('focus');
            }
        }

        function updateOtherInputState() {
            if (!$otherInput.length) {
                return;
            }

            var otherSelected = isOtherLicenseSelected();
            var $otherField = $otherInput.closest('.consulting-freemius-change-field');

            $otherInput.prop('disabled', false);
            $otherInput.prop('readonly', !otherSelected);
            $otherField.toggleClass('is-disabled', !otherSelected);

            if (!otherSelected) {
                $otherInput.val('');
            }
        }

        $toggleButton.on('click', function (event) {
            event.preventDefault();

            if ($panel.prop('hidden')) {
                openPanel();
            } else {
                closePanel();
            }
        });

        $cancelButton.on('click', function (event) {
            event.preventDefault();
            closePanel();
        });

        $licenseTypes.on('change', function () {
            updateOtherInputState();
            updateSubmitState();
            hideInlineMessage($message);

            if (isOtherLicenseSelected()) {
                $otherInput.trigger('focus');
            }
        });

        $otherOption.on('mousedown', function (event) {
            if ($(event.target).is('.consulting-freemius-license-type')) {
                return;
            }

            if (!isOtherLicenseSelected()) {
                event.preventDefault();
                selectOtherLicenseType(true);
            }
        });

        $otherInput.on('focus', function () {
            if (!isOtherLicenseSelected()) {
                selectOtherLicenseType(true);
            }
        });

        $availableOption.on('mousedown', function (event) {
            if ($(event.target).is('.consulting-freemius-license-type')) {
                return;
            }

            if (!isAvailableLicenseSelected()) {
                selectAvailableLicenseType(true);
            }
        });

        $licenseSelect.on('mousedown focus', function (event) {
            if (!isAvailableLicenseSelected()) {
                selectAvailableLicenseType(false);
            }
        });

        $otherInput.add($soloInput).on('input propertychange keyup paste', function () {
            hideInlineMessage($message);
            updateSubmitState();
        });

        $licenseSelect.on('change', function () {
            hideInlineMessage($message);
            updateSubmitState();
        });

        $submitButton.on('click', function (event) {
            event.preventDefault();

            if ($submitButton.prop('disabled') || $submitButton.hasClass('is-loading')) {
                return;
            }

            var payload = {};

            if ($soloInput.length) {
                payload.license_key = $.trim($soloInput.val());
            } else if (isOtherLicenseSelected()) {
                payload.license_key = $.trim($otherInput.val());
            } else if ($licenseSelect.length) {
                payload.license_id = $licenseSelect.val();
            } else if ($availableDisplay.length) {
                payload.license_id = $availableDisplay.data('licenseId');
            }

            if (!payload.license_key && !payload.license_id) {
                return;
            }

            hideInlineMessage($message);
            setButtonLoading($submitButton, true, config.updatingLabel + '...', submitLabel);

            requestLicenseActivation(payload, {
                error: function (errorMessage) {
                    showInlineMessage($message, errorMessage);
                    setButtonLoading($submitButton, false, config.updatingLabel + '...', submitLabel);
                    updateSubmitState();
                }
            });
        });

        updateOtherInputState();
        updateSubmitState();
    }

    document.addEventListener('click', function (event) {
        if (!config.importBlocked) {
            return;
        }

        var trigger = event.target.closest && event.target.closest('.stm_demo_import_choices .install');

        if (!trigger) {
            return;
        }

        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        showImportBlocker();
    }, true);

    $(function () {
        replaceDashboardActivation();
        initInlineLicenseActivation();
        initInlineChangeLicense();

        $(document).on('click', '.consulting-freemius-import-blocker__close, .consulting-freemius-import-blocker__cancel', function (event) {
            event.preventDefault();
            $('#consulting-freemius-import-blocker').removeClass('is-active');
        });

        $(document).on('click', '#consulting-freemius-import-blocker', function (event) {
            if (event.target === this) {
                $(this).removeClass('is-active');
            }
        });
    });
})(jQuery);
