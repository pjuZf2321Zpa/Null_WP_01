<?php
/*
* Plugin Name: Smart Manager – WooCommerce Bulk Edit: Products, Orders, Users & More (Spreadsheet)
* Plugin URI: https://www.storeapps.org/product/smart-manager/
* Description: <strong>Pro Version Installed</strong>. The #1 tool for WooCommerce inventory management, stock management, bulk edit, export, delete, duplicate...from one place using an Excel-like sheet editor.
* Version: 8.99.0
* Author: StoreApps
* Author URI: https://www.storeapps.org/
* Text Domain: smart-manager-for-wp-e-commerce
* Domain Path: /languages/
* Requires at least: 6.9
* Tested up to: 7.1
* Requires PHP: 7.2
* WC requires at least: 3.0.0
* WC tested up to: 11.2.1
* Copyright (c) 2010 - 2026 StoreApps. All rights reserved.
* License: GNU General Public License v2.0
* License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'SM_PLUGIN_FILE' ) ) {
	define( 'SM_PLUGIN_FILE', __FILE__ );
}

update_option( '_storeapps_connector_access_token', 'yes', 'yes' );
update_option( '_storeapps_connected', 'yes', 'yes' );
update_option( '_storeapps_connector_status', 1 );

if ( ! class_exists( 'Smart_Manager' ) && file_exists( ( dirname( __FILE__ ) ) . '/class-smart-manager.php' ) ) {
	include_once 'class-smart-manager.php';
}
