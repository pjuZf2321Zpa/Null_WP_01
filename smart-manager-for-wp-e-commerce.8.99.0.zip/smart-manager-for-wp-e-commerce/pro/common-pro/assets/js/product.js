(function (window) {
    function SaCommonProduct() {
        SaCommonManagerPro.call(this);
    }
    SaCommonProduct.prototype = Object.create(SaCommonManagerPro.prototype);
    SaCommonProduct.prototype.constructor = SaCommonProduct;
    //Code to handle after change of batch update field
    jQuery(document).on(this.pluginKey + '_post_format_columns', '#' + this.pluginSlug + '_editor_grid', function () {
        if (window[pluginKey].dashboardKey == 'product' && typeof (window[pluginKey].columnNamesBatchUpdate) != 'undefined') {
            //Code for handling product attribute
            if (typeof (window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']) != 'undefined' && Object.keys(window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['values']).length > 0) {
                let attrObj = window[pluginKey].columnNamesBatchUpdate['custom/product_attributes'];
                let attributes = window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['values'];
                // Code for handling in new UI
                let attributesActions = {}
                let attributesValues = {}
                attributes.forEach((attr) => {
                    let key = attr.hasOwnProperty('key') ? attr.key : ''
                    if (key != '') {
                        let valObj = attr.hasOwnProperty('value') ? attr.value : {}
                        attributesActions[key] = (valObj.hasOwnProperty('lbl')) ? valObj.lbl : ''

                        let values = valObj.hasOwnProperty('val') ? valObj.val : {}

                        if (Object.keys(values).length > 0) {
                            attributesValues[key] = [{ 'key': 'all', 'value': 'All' }]
                            Object.keys(values).forEach((valKey) => {
                                attributesValues[key].push({ 'key': valKey, 'value': values[valKey] })
                            })
                        }
                    }
                })
                window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['actions'] = { ...window[pluginKey].batchUpdateActions['multilist'], ...{ copy_from: _x('copy from', 'Bulk Edit option for WooCommerce product attribute', 'smart-manager-for-wp-e-commerce') } };
                ['set_to', 'copy_from_field'].forEach(prop => delete window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['actions'][prop])
                window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['additionalValues'] = attributesActions
                window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['values'] = attributesValues
                window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['type'] = 'dropdown';
                if (!window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['additionalValues'].hasOwnProperty('custom')) {
                    window[pluginKey].columnNamesBatchUpdate['custom/product_attributes']['additionalValues']['custom'] = 'Custom';
                }
            }
            // Code for adding set_to_regular_price/set_to_sale_price in bulk edit panel.
            if (window[pluginKey].columnNamesBatchUpdate['postmeta/meta_key=_regular_price/meta_value=_regular_price']) {
                window[pluginKey].columnNamesBatchUpdate['postmeta/meta_key=_regular_price/meta_value=_regular_price']['custom_actions'] = { set_to_sale_price: _x('set to sale price', 'bulk edit option for WooCommerce product regular price', 'smart-manager-for-wp-e-commerce') }
            }
            if (window[pluginKey].columnNamesBatchUpdate['postmeta/meta_key=_sale_price/meta_value=_sale_price']) {
                window[pluginKey].columnNamesBatchUpdate['postmeta/meta_key=_sale_price/meta_value=_sale_price']['custom_actions'] = {
                    set_to_regular_price: _x('set to regular price', 'bulk edit option for WooCommerce product sale price', 'smart-manager-for-wp-e-commerce'), set_to_regular_price_and_decrease_by_per: {
                        label: _x('set to regular price and decrease by %', 'bulk edit option for WooCommerce product sale price', 'smart-manager-for-wp-e-commerce'),
                        hide_value: false
                    },
                    set_to_regular_price_and_decrease_by_num: {
                        label: _x('set to regular price and decrease by number', 'bulk edit option for WooCommerce product sale price', 'smart-manager-for-wp-e-commerce'),
                        hide_value: false
                    }
                }
            }
        }
    });

    // Show the stock dependency notice and clear it when the rule no longer applies.
    SaCommonProduct.prototype.showRuleNotice = function (ruleObj) {
        let hadNotice = Boolean(window[pluginKey].bulkEditPanelNotice) || window[pluginKey].dependencyRuleRequired === true;
        window[pluginKey].bulkEditPanelNotice = '';
        window[pluginKey].bulkEditPanelNoticeSettingsLink = '';
        window[pluginKey].dependencyRuleRequired = false;
        let isGlobalStockManagementEnabled = window.smart_manager.isWCStockManagementEnabled === 'yes';

        // Collect all rules across all ruleGroups in DashboardModel.data
        let allRules = [];
        if (typeof DashboardModel !== 'undefined' && DashboardModel.data && Array.isArray(DashboardModel.data.ruleGroups)) {
            DashboardModel.data.ruleGroups.forEach(function (group) {
                if (group && Array.isArray(group.rules)) {
                    allRules = allRules.concat(group.rules);
                }
            });
        }

        // Also include ruleObj if passed directly
        if (ruleObj && typeof ruleObj === 'object') {
            if (Array.isArray(ruleObj.rules)) {
                allRules = allRules.concat(ruleObj.rules);
            }
            let fieldName = ruleObj.field || ruleObj.type;
            if (fieldName) {
                allRules.push({
                    type: fieldName,
                    operator: ruleObj.op || ruleObj.operator,
                    value: ruleObj.value
                });
            }
        }

        // Check if any rule explicitly enables Manage Stock (set_to 'yes')
        let isManageStockEnabledInRule = allRules.some(function (rule) {
            let type = rule.type || rule.field;
            let op = rule.operator || rule.op;
            return type === 'postmeta/meta_key=_manage_stock/meta_value=_manage_stock' &&
                op === 'set_to' &&
                rule.value === 'yes';
        });
        if (isManageStockEnabledInRule) {
            if (hadNotice && typeof m !== 'undefined' && typeof m.redraw === 'function') {
                m.redraw();
            }
            return false;
        }

        // Check if any rule updates Stock Quantity with a non-empty value
        let isStockValuePresent = allRules.some(function (rule) {
            let type = rule.type || rule.field;
            return type === 'postmeta/meta_key=_stock/meta_value=_stock' &&
                rule.value !== null &&
                rule.value !== undefined &&
                String(rule.value).trim() !== '';
        });
        if (!isStockValuePresent) {
            if (hadNotice && typeof m !== 'undefined' && typeof m.redraw === 'function') {
                m.redraw();
            }
            return false;
        }

        // Check if any selected row has manage_stock = 'no'
        let dashboardData = window.smart_manager.currentDashboardData || [];
        let selected_ids = ('undefined' !== typeof (this.getSelectedKeyIds) && "function" === typeof (this.getSelectedKeyIds)) ? this.getSelectedKeyIds() : (('undefined' !== typeof (this.selectedIds) && this.selectedIds.length > 0) ? this.selectedIds : []);
        let selectedRows = dashboardData.filter(
            row => selected_ids.map(String).includes(String(row.posts_id))
        );
        let canShowNotice = (this.selectAll === true) || selectedRows.some(
            row => row.postmeta_meta_key__manage_stock_meta_value__manage_stock === 'no'
        );
        if (canShowNotice) {
            if (isGlobalStockManagementEnabled) {
                window[pluginKey].bulkEditPanelNotice = _x("Updating stock will automatically set 'Manage Stock' to 'Yes'.", 'notification', 'smart-manager-for-wp-e-commerce');
                window[pluginKey].dependencyRuleRequired = true;
            } else {
                window[pluginKey].bulkEditPanelNotice = _x("Store-wide stock tracking is off. Values will save but won’t update inventory.", 'notification', 'smart-manager-for-wp-e-commerce');
                window[pluginKey].bulkEditPanelNoticeSettingsLink = window.smart_manager.WCInventorySettingsURL || '';
            }
            if (typeof m !== 'undefined' && typeof m.redraw === 'function') {
                m.redraw();
            }
            return true;
        }
        if (hadNotice && typeof m !== 'undefined' && typeof m.redraw === 'function') {
            m.redraw();
        }
        return false;
    };

    // Adds the Manage Stock dependency rule when it is not already present.
    SaCommonProduct.prototype.addDependencyRule = function (ruleGroups) {
        if (!Array.isArray(ruleGroups) || !ruleGroups[0] || !ruleGroups[0].rules) {
            return ruleGroups;
        }

        let updatedRuleGroups = JSON.parse(JSON.stringify(ruleGroups));

        let manageStockRuleExists = updatedRuleGroups[0].rules.some(function (rule) {
            return rule.type === 'postmeta/meta_key=_manage_stock/meta_value=_manage_stock';
        });

        if (!manageStockRuleExists) {
            updatedRuleGroups[0].rules.push({
                type: 'postmeta/meta_key=_manage_stock/meta_value=_manage_stock',
                operator: 'set_to',
                value: 'yes'
            });
        }
        return updatedRuleGroups;
    }
    window.SaCommonProduct = SaCommonProduct;
})(window);
