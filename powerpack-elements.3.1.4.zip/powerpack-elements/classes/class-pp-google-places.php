<?php
namespace PowerpackElements\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Google Places reviews, from Places API (Legacy) or Places API (New).
 *
 * Since October 2026 Google no longer lets new Cloud projects enable the
 * legacy API, so a key made since then only works with the new one. Older
 * keys may have either or both. The legacy API is tried first because only
 * it can return the newest reviews ('reviews_sort=newest'); the new API always
 * returns the five most relevant. Whichever API answers is remembered per key,
 * so a new-API key does not pay for a failed legacy call on every refresh.
 *
 * @since 3.1.2
 */
class PP_Google_Places {

	/**
	 * Places API (Legacy).
	 *
	 * @since 3.1.2
	 */
	const API_LEGACY = 'legacy';

	/**
	 * Places API (New).
	 *
	 * @since 3.1.2
	 */
	const API_NEW = 'new';

	/**
	 * Option holding which API the saved key last worked with.
	 *
	 * @since 3.1.2
	 */
	const OPTION = 'pp_google_places_api';

	/**
	 * Place used to verify a key.
	 *
	 * @since 3.1.2
	 */
	const TEST_PLACE_ID = 'ChIJjZwurGTlZzkRLVOKFH8rKYc';

	/**
	 * Get the reviews of a place.
	 *
	 * Reviews are returned in the legacy API's shape whichever API served
	 * them, so cached reviews and the code that renders them stay the same.
	 *
	 * @since 3.1.2
	 * @param string $api_key  Google Places API key.
	 * @param string $place_id Place ID.
	 * @param string $language Language or locale, e.g. 'nl' or 'nl_NL'.
	 * @param string $sort     'most_relevant' or 'newest'. The new API ignores it.
	 * @return array|\WP_Error Up to five review objects.
	 */
	public static function get_reviews( $api_key, $place_id, $language = '', $sort = 'most_relevant' ) {
		$place = self::get_place(
			$api_key,
			$place_id,
			[
				'fields'   => 'reviews',
				'language' => $language,
				'sort'     => $sort,
			]
		);

		return is_wp_error( $place ) ? $place : $place['reviews'];
	}

	/**
	 * Check a key against both APIs.
	 *
	 * Only asks for the place ID, which the new API does not bill for.
	 *
	 * @since 3.1.2
	 * @param string $api_key Google Places API key.
	 * @return string|\WP_Error The API the key works with.
	 */
	public static function verify_key( $api_key ) {
		$place = self::get_place( $api_key, self::TEST_PLACE_ID, [ 'fields' => 'id' ] );

		return is_wp_error( $place ) ? $place : $place['api'];
	}

	/**
	 * Get the API the key last worked with.
	 *
	 * @since 3.1.2
	 * @param string $api_key Google Places API key.
	 * @return string Empty when not known yet.
	 */
	public static function get_known_api( $api_key ) {
		$known = get_option( self::OPTION );

		if ( is_array( $known ) && ! empty( $known['key'] ) && md5( $api_key ) === $known['key'] ) {
			return $known['api'];
		}

		return '';
	}

	/**
	 * Request a place from the API the key works with, falling back to the
	 * other one when the first refuses the key.
	 *
	 * @since 3.1.2
	 * @param string $api_key  Google Places API key.
	 * @param string $place_id Place ID.
	 * @param array  $args     'fields' ('reviews' or 'id'), 'language', 'sort'.
	 * @return array|\WP_Error 'api' and 'reviews'.
	 */
	private static function get_place( $api_key, $place_id, $args ) {
		$known = self::get_known_api( $api_key );
		$apis  = ( self::API_NEW === $known ) ? [ self::API_NEW, self::API_LEGACY ] : [ self::API_LEGACY, self::API_NEW ];

		$place = self::request( $apis[0], $api_key, $place_id, $args );

		// REQUEST_DENIED (legacy) and PERMISSION_DENIED (new) are what an API
		// that is not enabled for the key's project answers with.
		if ( is_wp_error( $place ) && in_array( $place->get_error_code(), [ 'REQUEST_DENIED', 'PERMISSION_DENIED' ], true ) ) {
			$fallback = self::request( $apis[1], $api_key, $place_id, $args );

			if ( is_wp_error( $fallback ) ) {
				// Report the new API's error: new projects cannot enable the
				// legacy one, so that is the one the user can act on.
				return ( self::API_NEW === $apis[1] ) ? $fallback : $place;
			}

			$place = $fallback;
		}

		if ( ! is_wp_error( $place ) && $place['api'] !== $known ) {
			update_option(
				self::OPTION,
				[
					'key' => md5( $api_key ),
					'api' => $place['api'],
				],
				false
			);
		}

		return $place;
	}

	/**
	 * Request a place from one API.
	 *
	 * @since 3.1.2
	 * @param string $api      'legacy' or 'new'.
	 * @param string $api_key  Google Places API key.
	 * @param string $place_id Place ID.
	 * @param array  $args     'fields' ('reviews' or 'id'), 'language', 'sort'.
	 * @return array|\WP_Error 'api' and 'reviews'.
	 */
	private static function request( $api, $api_key, $place_id, $args ) {
		$args = wp_parse_args(
			$args,
			[
				'fields'   => 'reviews',
				'language' => '',
				'sort'     => 'most_relevant',
			]
		);

		if ( self::API_NEW === $api ) {
			$query = [];

			if ( '' !== self::get_language_code( $args['language'] ) ) {
				$query['languageCode'] = self::get_language_code( $args['language'] );
			}

			$response = wp_remote_get(
				add_query_arg( $query, 'https://places.googleapis.com/v1/places/' . rawurlencode( $place_id ) ),
				[
					'timeout' => 30,
					'headers' => [
						'X-Goog-Api-Key'   => $api_key,
						'X-Goog-FieldMask' => $args['fields'],
					],
				]
			);
		} else {
			$query = [
				'key'     => $api_key,
				'placeid' => $place_id,
				'fields'  => ( 'id' === $args['fields'] ) ? 'place_id' : $args['fields'],
			];

			if ( '' !== $args['language'] ) {
				$query['language'] = $args['language'];
			}

			if ( 'reviews' === $args['fields'] ) {
				$query['reviews_sort'] = $args['sort'];
			}

			$response = wp_remote_get(
				add_query_arg( array_map( 'rawurlencode', $query ), 'https://maps.googleapis.com/maps/api/place/details/json' ),
				[ 'timeout' => 30 ]
			);
		}

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ) );

		if ( ! is_object( $body ) ) {
			return new \WP_Error( 'invalid_response', esc_html__( 'Could not reach the Google Places API.', 'powerpack' ) );
		}

		if ( self::API_NEW === $api ) {
			if ( isset( $body->error ) ) {
				$status = ! empty( $body->error->status ) ? $body->error->status : 'http_' . $code;

				return new \WP_Error( $status, ! empty( $body->error->message ) ? $body->error->message : $status );
			}

			return [
				'api'     => self::API_NEW,
				'reviews' => isset( $body->reviews ) ? array_map( [ __CLASS__, 'to_legacy_review' ], $body->reviews ) : [],
			];
		}

		$status = isset( $body->status ) ? $body->status : 'http_' . $code;

		if ( 'OK' !== $status ) {
			return new \WP_Error( $status, ! empty( $body->error_message ) ? $body->error_message : $status );
		}

		return [
			'api'     => self::API_LEGACY,
			'reviews' => isset( $body->result->reviews ) ? $body->result->reviews : [],
		];
	}

	/**
	 * Convert a review from the new API into the legacy API's shape.
	 *
	 * @since 3.1.2
	 * @param object $review Review from Places API (New).
	 * @return object
	 */
	private static function to_legacy_review( $review ) {
		$author = isset( $review->authorAttribution ) ? $review->authorAttribution : new \stdClass();

		return (object) [
			'author_name'               => isset( $author->displayName ) ? $author->displayName : '',
			'author_url'                => isset( $author->uri ) ? $author->uri : '',
			'profile_photo_url'         => isset( $author->photoUri ) ? $author->photoUri : '',
			'rating'                    => isset( $review->rating ) ? $review->rating : 0,
			'relative_time_description' => isset( $review->relativePublishTimeDescription ) ? $review->relativePublishTimeDescription : '',
			'text'                      => isset( $review->text->text ) ? $review->text->text : '',
			'time'                      => isset( $review->publishTime ) ? (int) strtotime( $review->publishTime ) : 0,
		];
	}

	/**
	 * Turn a WordPress locale into a code the new API accepts.
	 *
	 * The legacy API took 'nl_NL' or 'de_DE_formal' as they are; the new one
	 * wants a language tag such as 'nl-NL' and rejects anything else.
	 *
	 * @since 3.1.2
	 * @param string $language Language or locale.
	 * @return string
	 */
	private static function get_language_code( $language ) {
		if ( ! preg_match( '/^([a-zA-Z]{2,3})(?:[_-]([a-zA-Z]{2}|\d{3}))?/', trim( $language ), $matches ) ) {
			return '';
		}

		return empty( $matches[2] ) ? strtolower( $matches[1] ) : strtolower( $matches[1] ) . '-' . strtoupper( $matches[2] );
	}
}
