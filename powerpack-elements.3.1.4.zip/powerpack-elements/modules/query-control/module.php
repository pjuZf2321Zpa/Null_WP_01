<?php
namespace PowerpackElements\Modules\QueryControl;

use PowerpackElements\Base\Module_Base;
use PowerpackElements\Controls\Control_Query as Query;

// Elementor Classes
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Common\Modules\Ajax\Module as Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * \Modules\QueryControl\Module
 *
 * @since  1.4.13.1
 */
class Module extends Module_Base {

	/**
	 * Module constructor.
	 *
	 * @since 1.4.13.1
	 * @param array $args
	 */
	public function __construct() {
		parent::__construct();

		// ACF 5 and up
		if ( class_exists( '\acf' ) && function_exists( 'acf_get_field_groups' ) ) {
			$this->add_component( 'acf', new Types\Acf() );
		}

		// Pods
		if ( function_exists( 'pods' ) ) {
			$this->add_component( 'pods', new Types\Pods() );
		}

		// Toolset
		if ( function_exists( 'wpcf_admin_fields_get_groups' ) ) {
			$this->add_component( 'toolset', new Types\Toolset() );
		}

		$this->add_component( 'posts', new Types\Posts() );
		$this->add_component( 'terms', new Types\Terms() );
		$this->add_component( 'terms-slug', new Types\Terms_Slug() );
		$this->add_component( 'authors', new Types\Authors() );
		$this->add_component( 'users', new Types\Users() );
		$this->add_component( 'templates', new Types\Templates() );
		$this->add_component( 'templates-all', new Types\Templates_All() );
		$this->add_component( 'templates-page', new Types\Templates_Page() );
		$this->add_component( 'templates-section', new Types\Templates_Section() );
		$this->add_component( 'templates-widget', new Types\Templates_Widget() );

		$this->add_actions();
	}

	/**
	 * Get Name
	 *
	 * Get the name of the module
	 *
	 * @since  1.4.13.1
	 * @return string
	 */
	public function get_name() {
		return 'query-control';
	}

	/**
	 * Add Actions
	 *
	 * Registeres actions to Elementor hooks
	 *
	 * @since  1.4.13.1
	 * @return void
	 */
	protected function add_actions() {
		add_action( 'elementor/ajax/register_actions', [ $this, 'register_ajax_actions' ] );
	}

	/**
	 * Calls function depending on ajax query data
	 *
	 * @since  1.4.13.1
	 * @return array
	 */
	public function ajax_call_filter_autocomplete( array $data ) {

		if ( empty( $data['query_type'] ) || empty( $data['q'] ) ) {
			throw new \Exception( 'Bad Request' );
		}

		$results = $this->get_query_component( $data['query_type'] )->get_autocomplete_values( $data );

		return [
			'results' => $results,
		];
	}

	/**
	 * Calls function to get value titles depending on ajax query type
	 *
	 * @since  1.4.13.1
	 * @return array
	 */
	public function ajax_call_control_value_titles( array $request ) {

		if ( empty( $request['query_type'] ) ) {
			throw new \Exception( 'Bad Request' );
		}

		$results = $this->get_query_component( $request['query_type'] )->get_value_titles( $request );

		return $results;
	}

	/**
	 * Get the component for an ajax query type
	 *
	 * Elementor's ajax manager only checks its nonce, so the capability is
	 * checked here before any query runs.
	 *
	 * @since  3.1.3
	 * @param  string $query_type Query type from the request.
	 * @return object
	 */
	private function get_query_component( $query_type ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			throw new \Exception( 'Access Denied' );
		}

		$component = is_string( $query_type ) ? $this->get_component( $query_type ) : null;

		if ( ! $component ) {
			throw new \Exception( 'Bad Request' );
		}

		return $component;
	}

	/**
	 * Register Elementor Ajax Actions
	 *
	 * @since  1.4.13.1
	 * @return array
	 */
	public function register_ajax_actions( $ajax_manager ) {
		$ajax_manager->register_ajax_action( 'pp_query_control_value_titles', [ $this, 'ajax_call_control_value_titles' ] );
		$ajax_manager->register_ajax_action( 'pp_query_control_filter_autocomplete', [ $this, 'ajax_call_filter_autocomplete' ] );
	}
}
