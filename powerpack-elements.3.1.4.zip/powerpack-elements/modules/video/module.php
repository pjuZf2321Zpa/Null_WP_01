<?php
namespace PowerpackElements\Modules\Video;

use PowerpackElements\Base\Module_Base;
use PowerpackElements\Classes\PP_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Module extends Module_Base {
	/**
	 * Video Gallery Data
	 *
	 * @var video_schema_data
	 */
	private $video_schema_data = [];

	private $video_gallery_widgets = [];

	private $widget_ids = [];

	public function __construct() {
		parent::__construct();

		add_action( 'elementor/frontend/after_register_styles', [ $this, 'register_styles' ] );

		// Walking every document's element tree is only worth it when the widget
		// that needs the schema is switched on.
		if ( self::is_widget_active( 'pp-video-gallery' ) ) {
			add_filter( 'elementor/frontend/builder_content_data', [ $this, 'grab_video_gallery_data' ], 10, 2 );
			add_action( 'wp_footer', [ $this, 'print_video_gallery_schema' ] );
		}
	}

	/**
	 * Module is active or not.
	 *
	 * @since 1.3.3
	 *
	 * @access public
	 *
	 * @return bool true|false.
	 */
	public static function is_active() {
		return true;
	}

	/**
	 * Get Module Name.
	 *
	 * @since 1.3.3
	 *
	 * @access public
	 *
	 * @return string Module name.
	 */
	public function get_name() {
		return 'pp-video';
	}

	/**
	 * Get Widgets.
	 *
	 * @since 1.3.3
	 *
	 * @access public
	 *
	 * @return array Widgets.
	 */
	public function get_widgets() {
		return [
			'Video',
			'Video_Gallery',
		];
	}

	/**
	 * Register styles.
	 *
	 * @return void
	 */
	public function register_styles() {
		wp_register_style(
			'widget-pp-video',
			$this->get_css_assets_url( 'widget-video', null, true, true ),
			[],
			POWERPACK_ELEMENTS_VER
		);

		wp_register_style(
			'widget-pp-video-gallery',
			$this->get_css_assets_url( 'widget-video-gallery', null, true, true ),
			[],
			POWERPACK_ELEMENTS_VER
		);
	}

	/**
	 * Collect the Video Gallery widgets in the rendered document.
	 *
	 * Stashes each widget's element data so the schema can be printed in the footer.
	 *
	 * @access public
	 *
	 * @param array $data Elementor builder content data.
	 *
	 * @return array Unmodified builder content data.
	 */
	public function grab_video_gallery_data( $data ) {
		PP_Helper::elementor()->db->iterate_data( $data, function ( $element ) {
			$type = PP_Helper::get_widget_type( $element );

			if ( 'pp-video-gallery' === $type ) {
				$this->video_gallery_widgets[] = $element;
			}

			return $element;
		} );

		return $data;
	}

	/**
	 * The URL of the page being rendered, for use in the schema output.
	 *
	 * The host is taken from the site's own home URL rather than the client
	 * supplied Host header, and the scheme from WordPress rather than a raw
	 * `HTTPS` server variable, which is not set the same way behind every proxy.
	 *
	 * @since 3.1.0
	 * @access private
	 *
	 * @return string Absolute URL of the current request.
	 */
	private function get_current_url() {
		// Prefer the post's own permalink on singular views. REQUEST_URI reflects whatever
		// query string the visitor arrived with, and this URL is published into the page's
		// JSON-LD, so a crafted link would otherwise end up in the structured data a
		// crawler indexes.
		if ( is_singular() ) {
			$permalink = get_permalink();

			if ( $permalink ) {
				return $permalink;
			}
		}

		$home_host = wp_parse_url( home_url(), PHP_URL_HOST );
		$home_port = wp_parse_url( home_url(), PHP_URL_PORT );

		// REQUEST_URI already carries any subdirectory the site is installed in.
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';

		return set_url_scheme( 'http://' . $home_host . ( $home_port ? ':' . $home_port : '' ) . $request_uri );
	}

	/**
	 * Print the ItemList schema for every Video Gallery widget on the page.
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function print_video_gallery_schema() {
		if ( ! empty( $this->video_gallery_widgets ) ) {
			$video_count = 1;
			$item_url    = $this->get_current_url();

			foreach ( $this->video_gallery_widgets as $widget_data ) {
				if ( in_array( $widget_data['id'], $this->widget_ids, true ) ) {
					continue;
				} else {
					$this->widget_ids[] = $widget_data['id'];
				}

				$widget = PP_Helper::elementor()->elements_manager->create_element_instance( $widget_data );

				if ( isset( $widget_data['templateID'] ) ) {
					$type = PP_Helper::get_global_widget_type( $widget_data['templateID'], 1 );
					$element_class = $type->get_class_name();
					try {
						$widget = new $element_class( $widget_data, [] );
					} catch ( \Exception $e ) {
						return null;
					}
				}

				$settings = $widget->get_settings();
				$enable_schema = $settings['enable_schema'];

				// The schema is built from the custom `gallery_videos` repeater, which is not
				// what a YouTube playlist or channel gallery renders. Describing it anyway
				// publishes VideoObjects for videos that are not on the page, pointing at
				// anchors that do not exist.
				if ( isset( $settings['source'] ) && 'custom' !== $settings['source'] ) {
					continue;
				}

				if ( ! empty( $settings['gallery_videos'] ) && 'yes' === $enable_schema ) {
					$video_url = [];
					$schema_thumb = '';

					// Anchors are scoped to the widget and numbered from one within it, matching
					// Video_Gallery::get_schema_item_id(). `position` stays sequential across the
					// whole page because it orders the ItemList, not the DOM.
					$item_index = 0;

					foreach ( $settings['gallery_videos'] as $video ) {
						$has_schema_data = true;
						$item_index++;

						$video_source = $video['video_source'];

						switch ( $video_source ) {
							case 'youtube':
								$video_url = $video['youtube_url'];
								break;

							case 'vimeo':
								$video_url = $video['vimeo_url'];
								break;

							case 'dailymotion':
								$video_url = $video['dailymotion_url'];
								break;

							case 'hosted':
								if ( ! empty( $video['hosted_url'] ) ) {
									$video_url = $video['hosted_url']['url'];
								}
								break;
						}

						$is_custom_thumb = ( 'yes' === $video['custom_thumbnail'] ) ? true : false;

						if ( $is_custom_thumb ) {
							$custom_image = $video['custom_image'];

							if ( ! empty( $custom_image ) && is_array( $custom_image ) ) {
								$schema_thumb = $custom_image['url'];
							}
						} else {
							$schema_image = $video['video_schema_image'];

							if ( ! empty( $schema_image ) && is_array( $schema_image ) ) {
								$schema_thumb = $schema_image['url'];
							}
						}

						$video_schema_title = $video['video_schema_title'];
						$video_schema_description = $video['video_schema_description'];
						$upload_date = new \DateTime( $video['video_schema_upload_date'] );

						if ( '' === $video_schema_title || '' === $video_schema_description || empty( $upload_date ) ) {
							$has_schema_data = false;
						}

						if ( $has_schema_data ) {
							$video_gallery_data    = [
								'@type'        => 'VideoObject',
								'url'          => $item_url . '#pp-video-gallery-item-' . $widget_data['id'] . '-' . $item_index,
								'position'     => $video_count,
								'name'         => $video_schema_title,
								'description'  => $video_schema_description,
								'thumbnailUrl' => $schema_thumb,
								'uploadDate'   => $upload_date->format( 'Y-m-d\TH:i:s\Z' ),
								'contentUrl'   => $video_url,
								'embedUrl'     => $video_url,
							];

							$this->video_schema_data[] = $video_gallery_data;
						}

						$video_count++;
					}
				}
			}
		}

		$videos_data = $this->video_schema_data;

		if ( $videos_data ) {
			$schema_data = [
				'@context'        => 'https://schema.org',
				'@type'           => 'ItemList',
				'itemListElement' => $videos_data,
			];

			PP_Helper::print_json_schema( $schema_data );
		}

		$this->video_schema_data = [];
	}
}
