<?php
namespace PowerpackElements\Modules\Video\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;

// Elementor Classes
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Control_Media;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Embed;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Video Widget
 */
class Video extends Powerpack_Widget {

	/**
	 * Retrieve video widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Video' );
	}

	/**
	 * Retrieve video widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Video' );
	}

	/**
	 * Retrieve video widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Video' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Video' );
	}

	/**
	 * Whether the widget output depends on dynamic content.
	 *
	 * Opts the widget out of Elementor's element cache invalidation.
	 *
	 * @access protected
	 *
	 * @return bool Whether the widget renders dynamic content.
	 */
	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
	 * Retrieve the list of scripts the video widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'jquery-ui-draggable',
				'pp-video',
			];
		}

		$settings = $this->get_settings_for_display();
		$scripts  = [ 'pp-video' ];

		if ( 'yes' === $settings['enable_sticky'] ) {
			array_push( $scripts, 'jquery-ui-draggable' );
		}

		return $scripts;
	}

	/**
	 * Retrieve the list of styles the video widget depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget styles dependencies.
	 */
	public function get_style_depends() {
		return [
			'widget-pp-video',
		];
	}

	/**
	 * Whether the widget renders Elementor's inner wrapper element.
	 *
	 * @access public
	 *
	 * @return bool Whether the inner wrapper should be printed.
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register video widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab */
		$this->register_content_video_controls();
		$this->register_content_thumbnail_controls();
		$this->register_content_play_icon_controls();
		$this->register_content_sticky_controls();

		/* Style Tab */
		$this->register_style_container_controls();
		$this->register_style_overlay_controls();
		$this->register_style_play_icon_controls();
		$this->register_style_lightbox_controls();
		$this->register_style_sticky_controls();
	}

	/**
	 * Register the content tab Video controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_video_controls() {
		/**
		 * Content Tab: Video
		 */
		$this->start_controls_section(
			'section_video',
			[
				'label' => esc_html__( 'Video', 'powerpack' ),
			]
		);

		$this->add_control(
			'video_source',
			[
				'label'   => esc_html__( 'Source', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'youtube',
				'options' => [
					'youtube'     => esc_html__( 'YouTube', 'powerpack' ),
					'vimeo'       => esc_html__( 'Vimeo', 'powerpack' ),
					'dailymotion' => esc_html__( 'Dailymotion', 'powerpack' ),
					'hosted'      => esc_html__( 'Self Hosted', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'youtube_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your YouTube URL', 'powerpack' ),
				'default'     => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'video_source' => 'youtube',
				],
			]
		);

		$this->add_control(
			'vimeo_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your Vimeo URL', 'powerpack' ),
				'default'     => 'https://vimeo.com/235215203',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'video_source' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'dailymotion_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your Dailymotion URL', 'powerpack' ),
				'default'     => 'https://www.dailymotion.com/video/x6tqhqb',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'video_source' => 'dailymotion',
				],
			]
		);

		$this->add_control(
			'insert_url',
			[
				'label'     => esc_html__( 'External URL', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'ai'        => [
					'active' => false,
				],
				'condition' => [
					'video_source' => 'hosted',
				],
			]
		);

		$this->add_control(
			'hosted_url',
			[
				'label'      => esc_html__( 'Choose File', 'powerpack' ),
				'type'       => Controls_Manager::MEDIA,
				'dynamic'    => [
					'active' => true,
					'categories' => [
						TagsModule::MEDIA_CATEGORY,
					],
				],
				'media_type' => 'video',
				'ai'         => [
					'active' => false,
				],
				'condition'  => [
					'video_source' => 'hosted',
					'insert_url'   => '',
				],
			]
		);

		$this->add_control(
			'external_url',
			[
				'label'        => esc_html__( 'URL', 'powerpack' ),
				'type'         => Controls_Manager::URL,
				'autocomplete' => false,
				'options'      => false,
				'label_block'  => true,
				'show_label'   => false,
				'dynamic'      => [
					'active' => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'media_type'   => 'video',
				'placeholder'  => esc_html__( 'Enter your URL', 'powerpack' ),
				'ai'           => [
					'active' => false,
				],
				'condition'    => [
					'video_source' => 'hosted',
					'insert_url'   => 'yes',
				],
			]
		);

		$this->add_control(
			'start_time',
			[
				'label'       => esc_html__( 'Start Time', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Enter start time in seconds', 'powerpack' ),
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'loop' => '',
				],
			]
		);

		$this->add_control(
			'end_time',
			[
				'label'       => esc_html__( 'End Time', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Enter end time in seconds', 'powerpack' ),
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'loop'         => '',
					'video_source' => [ 'youtube', 'hosted' ],
				],
			]
		);

		$this->add_control(
			'aspect_ratio',
			[
				'label'                => esc_html__( 'Aspect Ratio', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					'169' => '16:9',
					'219' => '21:9',
					'916' => '9:16',
					'43'  => '4:3',
					'32'  => '3:2',
					'11'  => '1:1',
				],
				'selectors_dictionary' => [
					'169' => '1.77777', // 16 / 9
					'219' => '2.33333', // 21 / 9
					'43'  => '1.33333', // 4 / 3
					'32'  => '1.5', // 3 / 2
					'11'  => '1', // 1 / 1
					'916' => '0.5625', // 9 / 16
				],
				'default'              => '169',
				'selectors'            => [
					'{{WRAPPER}} .pp-video-container' => 'aspect-ratio: {{VALUE}}',
				],
				'prefix_class' => 'pp-aspect-ratio-',
			]
		);

		$this->add_control(
			'video_options',
			[
				'label'     => esc_html__( 'Video Options', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'preload',
			[
				'label'     => esc_html__( 'Preload', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'auto'     => esc_html__( 'Auto', 'powerpack' ),
					'metadata' => esc_html__( 'Meta data', 'powerpack' ),
					'none'     => esc_html__( 'None', 'powerpack' ),
				],
				'default'   => 'auto',
				'condition' => [
					'video_source' => 'hosted',
				],
			]
		);

		$this->add_control(
			'lightbox',
			[
				'label' => esc_html__( 'Lightbox', 'powerpack' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'powerpack' ),
				'description'  => sprintf(
					/* translators: 1: '<a>' opening tag, 2: '</a>' closing tag. */
					esc_html__( 'Note: Autoplay is affected by %1$s Google’s Autoplay policy %2$s on Chrome browsers.', 'powerpack' ),
					'<a href="https://developers.google.com/web/updates/2017/09/autoplay-policy-changes" target="_blank">',
					'</a>'
				),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'lightbox!' => 'yes',
				],
			]
		);

		$this->add_control(
			'play_on_mobile',
			[
				'label'     => esc_html__( 'Play On Mobile', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'mute',
			[
				'label'        => esc_html__( 'Mute', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'loop',
			[
				'label'     => esc_html__( 'Loop', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'video_source!' => 'dailymotion',
				],
			]
		);

		$this->add_control(
			'controls',
			[
				'label'     => esc_html__( 'Player Controls', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'powerpack' ),
				'label_on'  => esc_html__( 'Show', 'powerpack' ),
				'default'   => 'yes',
				'condition' => [
					'video_source!' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'color',
			[
				'label'     => esc_html__( 'Controls Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'video_source' => [ 'vimeo', 'dailymotion' ],
				],
			]
		);

		$this->add_control(
			'cc_load_policy',
			[
				'label'     => esc_html__( 'Captions', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'video_source' => [ 'youtube' ],
					'controls'     => 'yes',
				],
			]
		);

		$this->add_control(
			'yt_privacy',
			[
				'label'       => esc_html__( 'Privacy Mode', 'powerpack' ),
				'type'        => Controls_Manager::SWITCHER,
				'description' => esc_html__( 'When you turn on privacy mode, YouTube won\'t store information about visitors on your website unless they play the video.', 'powerpack' ),
				'condition'   => [
					'video_source' => 'youtube',
				],
			]
		);

		$this->add_control(
			'rel',
			[
				'label'     => esc_html__( 'Suggested Videos', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''    => esc_html__( 'Current Video Channel', 'powerpack' ),
					'yes' => esc_html__( 'Any Video', 'powerpack' ),
				],
				'condition' => [
					'video_source' => 'youtube',
				],
			]
		);

		// Dailymotion
		$this->add_control(
			'showinfo',
			[
				'label'     => esc_html__( 'Video Info', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'powerpack' ),
				'label_on'  => esc_html__( 'Show', 'powerpack' ),
				'default'   => 'yes',
				'condition' => [
					'video_source' => [ 'dailymotion' ],
				],
			]
		);

		$this->add_control(
			'logo',
			[
				'label'     => esc_html__( 'Logo', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'powerpack' ),
				'label_on'  => esc_html__( 'Show', 'powerpack' ),
				'default'   => 'yes',
				'condition' => [
					'video_source' => [ 'dailymotion' ],
				],
			]
		);

		// Vimeo.
		$this->add_control(
			'vimeo_title',
			[
				'label'     => esc_html__( 'Intro Title', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'powerpack' ),
				'label_on'  => esc_html__( 'Show', 'powerpack' ),
				'default'   => 'yes',
				'condition' => [
					'video_source' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'vimeo_portrait',
			[
				'label'     => esc_html__( 'Intro Portrait', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'powerpack' ),
				'label_on'  => esc_html__( 'Show', 'powerpack' ),
				'default'   => 'yes',
				'condition' => [
					'video_source' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'vimeo_byline',
			[
				'label'     => esc_html__( 'Intro Byline', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'Hide', 'powerpack' ),
				'label_on'  => esc_html__( 'Show', 'powerpack' ),
				'default'   => 'yes',
				'condition' => [
					'video_source' => 'vimeo',
				],
			]
		);

		$this->add_control(
			'aria_label',
			[
				'label'       => esc_html__( 'Accessible Label', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Play video', 'powerpack' ),
				'default'     => '',
				'description' => esc_html__( 'Set an accessible label for screen readers (e.g. "Play product demo video"). Defaults to "Play video".', 'powerpack' ),
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Thumbnail controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_thumbnail_controls() {
		/**
		 * Content Tab: Thumbnail
		 */
		$this->start_controls_section(
			'section_thumbnail',
			[
				'label' => esc_html__( 'Thumbnail', 'powerpack' ),
			]
		);

		$this->add_control(
			'thumbnail_size',
			[
				'label'     => esc_html__( 'Thumbnail Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'maxresdefault',
				'options'   => [
					'maxresdefault' => esc_html__( 'Maximum Resolution', 'powerpack' ),
					'hqdefault'     => esc_html__( 'High Quality', 'powerpack' ),
					'mqdefault'     => esc_html__( 'Medium Quality', 'powerpack' ),
					'sddefault'     => esc_html__( 'Standard Quality', 'powerpack' ),
				],
				'condition' => [
					'video_source' => 'youtube',
				],
			]
		);

		$this->add_control(
			'custom_thumbnail',
			[
				'label'   => esc_html__( 'Custom Thumbnail', 'powerpack' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => '',
			]
		);

		$this->add_control(
			'custom_image',
			[
				'label'     => esc_html__( 'Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'custom_thumbnail' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Play Icon controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_play_icon_controls() {
		/**
		 * Content Tab: Play Icon
		 */
		$this->start_controls_section(
			'section_play_icon_settings',
			[
				'label' => esc_html__( 'Play Icon', 'powerpack' ),
			]
		);

		$this->add_control(
			'play_icon_type',
			[
				'label'       => esc_html__( 'Icon Type', 'powerpack' ),
				'label_block' => false,
				'toggle'      => false,
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'none'  => [
						'title' => esc_html__( 'None', 'powerpack' ),
						'icon'  => 'eicon-ban',
					],
					'icon'  => [
						'title' => esc_html__( 'Icon', 'powerpack' ),
						'icon'  => 'eicon-star',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'powerpack' ),
						'icon'  => 'eicon-image-bold',
					],
				],
				'default'     => 'icon',
			]
		);

		$this->add_control(
			'select_play_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'play_icon',
				'default'          => [
					'value'   => 'fas fa-play-circle',
					'library' => 'fa-solid',
				],
				'recommended'      => [
					'fa-regular' => [
						'play-circle',
					],
					'fa-solid'   => [
						'play',
						'play-circle',
					],
				],
				'condition'        => [
					'play_icon_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'play_icon_image',
			[
				'label'     => esc_html__( 'Select Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'play_icon_type' => 'image',
				],
			]
		);

		$this->add_control(
			'play_icon_glow_effect',
			[
				'label'        => esc_html__( 'Glow Effect', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Sticky Video controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_sticky_controls() {
		/**
		 * Content Tab: Sticky Video
		 */
		$this->start_controls_section(
			'section_sticky',
			[
				'label' => esc_html__( 'Sticky Video', 'powerpack' ),
			]
		);

		$this->add_control(
			'enable_sticky',
			[
				'label'              => esc_html__( 'Sticky Video', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'default'            => '',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'sticky_position',
			[
				'label'        => esc_html__( 'Position', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'bottom_right',
				'options'      => [
					'top_left'     => esc_html__( 'Top Left', 'powerpack' ),
					'top_right'    => esc_html__( 'Top Right', 'powerpack' ),
					'bottom_left'  => esc_html__( 'Bottom Left', 'powerpack' ),
					'bottom_right' => esc_html__( 'Bottom Right', 'powerpack' ),
					'center_left'  => esc_html__( 'Center Left', 'powerpack' ),
					'center_right' => esc_html__( 'Center Right', 'powerpack' ),
				],
				'condition'    => [
					'enable_sticky' => 'yes',
				],
				'prefix_class' => 'pp-video-sticky-',
				'render_type'  => 'template',
			]
		);

		$breakpoints = PP_Helper::elementor()->breakpoints->get_active_breakpoints();

		$hide_sticky_on_options = [];

		foreach ( $breakpoints as $breakpoint_key => $breakpoint ) {
			// This feature is meant for mobile screens.
			if ( 'widescreen' === $breakpoint_key ) {
				continue;
			}

			$hide_sticky_on_options[ $breakpoint_key ] = sprintf(
				/* translators: 1: Breakpoint label, 2: '<' character, 3: Breakpoint value in pixels. */
				esc_html__( '%1$s (%2$s %3$dpx)', 'powerpack' ),
				$breakpoint->get_label(),
				'<',
				$breakpoint->get_value()
			);
		}

		$hide_sticky_on_options['desktop'] = esc_html__( 'Desktop', 'powerpack' );

		$this->add_control(
			'sticky_hide_on',
			[
				'label'              => esc_html__( 'Hide Sticky Video on', 'powerpack' ),
				'type'               => Controls_Manager::SELECT2,
				'multiple'           => true,
				'label_block'        => true,
				'options'            => $hide_sticky_on_options,
				'condition'          => [
					'enable_sticky' => 'yes',
				],
				'render_type'        => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'enable_sticky_close_button',
			[
				'label'     => esc_html__( 'Show Close Button', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_off' => esc_html__( 'No', 'powerpack' ),
				'label_on'  => esc_html__( 'Yes', 'powerpack' ),
				'default'   => 'yes',
				'condition' => [
					'enable_sticky' => 'yes',
				],
			]
		);

		$this->add_control(
			'enable_sticky_info_bar',
			[
				'label'       => esc_html__( 'Show Info Bar', 'powerpack' ),
				'description' => esc_html__( 'Use this option to display the some text below sticky video.', 'powerpack' ),
				'type'        => Controls_Manager::SWITCHER,
				'label_off'   => esc_html__( 'No', 'powerpack' ),
				'label_on'    => esc_html__( 'Yes', 'powerpack' ),
				'default'     => '',
				'condition'   => [
					'enable_sticky' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticky_info_bar_text',
			[
				'label'     => esc_html__( 'Info Bar Text', 'powerpack' ),
				'type'      => Controls_Manager::WYSIWYG,
				'default'   => '<b>Now Playing:</b> PowerPack Sticky Video',
				'rows'      => 2,
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'enable_sticky'          => 'yes',
					'enable_sticky_info_bar' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Container controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_container_controls() {
		/**
		 * Style Tab: Container
		 */
		$this->start_controls_section(
			'section_container_style',
			[
				'label' => esc_html__( 'Container', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'container_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-video-container',
			]
		);

		$this->add_responsive_control(
			'container_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'container_box_shadow',
				'selector' => '{{WRAPPER}} .pp-video-container',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Overlay controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_overlay_controls() {
		/**
		 * Style Tab: Overlay
		 */
		$this->start_controls_section(
			'section_overlay_style',
			[
				'label' => esc_html__( 'Overlay', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_blend_mode',
			[
				'label'     => esc_html__( 'Blend Mode', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => [
					'normal'      => esc_html__( 'Normal', 'powerpack' ),
					'multiply'    => esc_html__( 'Multiply', 'powerpack' ),
					'screen'      => esc_html__( 'Screen', 'powerpack' ),
					'overlay'     => esc_html__( 'Overlay', 'powerpack' ),
					'darken'      => esc_html__( 'Darken', 'powerpack' ),
					'lighten'     => esc_html__( 'Lighten', 'powerpack' ),
					'color-dodge' => esc_html__( 'Color Dodge', 'powerpack' ),
					'color'       => esc_html__( 'Color', 'powerpack' ),
					'hue'         => esc_html__( 'Hue', 'powerpack' ),
					'hard-light'  => esc_html__( 'Hard Light', 'powerpack' ),
					'soft-light'  => esc_html__( 'Soft Light', 'powerpack' ),
					'difference'  => esc_html__( 'Difference', 'powerpack' ),
					'exclusion'   => esc_html__( 'Exclusion', 'powerpack' ),
					'saturation'  => esc_html__( 'Saturation', 'powerpack' ),
					'luminosity'  => esc_html__( 'Luminosity', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-overlay' => 'mix-blend-mode: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_overlay_style' );

		$this->start_controls_tab(
			'tab_overlay_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'overlay_background_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-video-overlay' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'overlay_margin_normal',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-overlay' => 'top: {{SIZE}}px; bottom: {{SIZE}}px; left: {{SIZE}}px; right: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'overlay_opacity_normal',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-overlay' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_overlay_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'overlay_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-video:hover .pp-video-overlay' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'overlay_margin_hover',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-video:hover .pp-video-overlay' => 'top: {{SIZE}}px; bottom: {{SIZE}}px; left: {{SIZE}}px; right: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'overlay_opacity_hover',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video:hover .pp-video-overlay' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Play Icon controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_play_icon_controls() {
		/**
		 * Style Tab: Play Icon
		 */
		$this->start_controls_section(
			'section_play_icon_style',
			[
				'label'     => esc_html__( 'Play Icon', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'play_icon_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 400,
					],
				],
				'default'    => [
					'size' => 80,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-play-icon-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'play_icon_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-play-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_play_icon_style' );

		$this->start_controls_tab(
			'tab_play_icon_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'play_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-video-play-icon'     => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-video-play-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'play_icon_background',
				'label'     => esc_html__( 'Background', 'powerpack' ),
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '{{WRAPPER}} .pp-video-play-icon',
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'      => 'play_icon_text_shadow',
				'label'     => esc_html__( 'Text Shadow', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-video-play-icon',
				'condition' => [
					'play_icon_type'             => 'icon',
					'select_play_icon[value]!'   => '',
					'select_play_icon[library]!' => 'svg',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'play_icon_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'default'     => '',
				'selector'    => '{{WRAPPER}} .pp-video-play-icon',
				'condition'   => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'play_icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-play-icon-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'play_icon_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-play-icon' => 'opacity: {{SIZE}}',
				],
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_play_icon_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'play_icon_hover_color',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'play_icon_hover_background',
				'label'     => esc_html__( 'Background', 'powerpack' ),
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '{{WRAPPER}} .pp-video-play-icon:hover',
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'      => 'play_icon_hover_text_shadow',
				'selector'  => '{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon',
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'play_icon_hover_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'play_icon_hover_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon' => 'opacity: {{SIZE}}',
				],
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'play_icon_hover_animation',
			[
				'label'     => esc_html__( 'Hover Animation', 'powerpack' ),
				'type'      => Controls_Manager::HOVER_ANIMATION,
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'glow_effect_heading',
			[
				'label'     => esc_html__( 'Glow Effect', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'play_icon_glow_effect' => 'yes',
				],
			]
		);

		$this->add_control(
			'glow_color',
			[
				'label'     => esc_html__( 'Glow Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--pp-glow-color: {{VALUE}};',
				],
				'condition' => [
					'play_icon_glow_effect' => 'yes',
				],
			]
		);

		$this->add_control(
			'glow_size',
			[
				'label'      => esc_html__( 'Glow Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min'  => 10,
						'max'  => 80,
						'step' => 1,
					],
					'em' => [
						'min'  => 10,
						'max'  => 50,
						'step' => 0.1,
					],
					'rem' => [
						'min'  => 10,
						'max'  => 50,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-glow-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'play_icon_glow_effect' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Lightbox controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_lightbox_controls() {
		/**
		 * Style Tab: Lightbox
		 */
		$this->start_controls_section(
			'section_lightbox_style',
			[
				'label'     => esc_html__( 'Lightbox', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'lightbox' => 'yes',
				],
			]
		);

		$this->add_control(
			'lightbox_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'#elementor-lightbox-{{ID}}' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'lightbox' => 'yes',
				],
			]
		);

		$this->add_control(
			'lightbox_close_icon_color',
			[
				'label'     => esc_html__( 'Close Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'#elementor-lightbox-{{ID}} .dialog-lightbox-close-button' => 'color: {{VALUE}}',
				],
				'condition' => [
					'lightbox' => 'yes',
				],
			]
		);

		$this->add_control(
			'lightbox_close_icon_color_hover',
			[
				'label'     => esc_html__( 'Close Icon Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'#elementor-lightbox-{{ID}} .dialog-lightbox-close-button:hover' => 'color: {{VALUE}}',
				],
				'separator' => 'after',
				'condition' => [
					'lightbox' => 'yes',
				],
			]
		);

		$this->add_control(
			'lightbox_video_width',
			[
				'label'      => esc_html__( 'Content Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'unit' => '%',
				],
				'range'      => [
					'%' => [
						'min' => 30,
					],
				],
				'selectors'  => [
					'(desktop+)#elementor-lightbox-{{ID}} .elementor-video-container' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'lightbox' => 'yes',
				],
			]
		);

		$this->add_control(
			'lightbox_content_position',
			[
				'label'                => esc_html__( 'Content Position', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					''    => esc_html__( 'Center', 'powerpack' ),
					'top' => esc_html__( 'Top', 'powerpack' ),
				],
				'selectors'            => [
					'#elementor-lightbox-{{ID}} .elementor-video-container' => '{{VALUE}}; transform: translateX(-50%);',
				],
				'selectors_dictionary' => [
					'top' => 'top: 60px',
				],
				'condition'            => [
					'lightbox' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'lightbox_content_animation',
			[
				'label'     => esc_html__( 'Entrance Animation', 'powerpack' ),
				'type'      => Controls_Manager::ANIMATION,
				'condition' => [
					'lightbox' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Sticky Video controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_sticky_controls() {
		/**
		 * Style Tab: Sticky Video
		 */
		$this->start_controls_section(
			'section_sticky_style',
			[
				'label'     => esc_html__( 'Sticky Video', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'enable_sticky' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'sticky_video_width',
			[
				'label'          => esc_html__( 'Video Width', 'powerpack' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', 'em', 'rem', 'custom' ],
				'range'          => [
					'px' => [
						'min' => 100,
						'max' => 800,
					],
					'em' => [
						'min' => 10,
						'max' => 50,
					],
					'rem' => [
						'min' => 10,
						'max' => 50,
					],
				],
				'default'        => [
					'size' => 320,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 250,
					'unit' => 'px',
				],
				'selectors'      => [
					'{{WRAPPER}}.pp-aspect-ratio-169 .pp-video.pp-sticky-apply .pp-video-sticky-wrap,
					{{WRAPPER}}.pp-aspect-ratio-169 .pp-sticky-apply .pp-video-thumb' => 'width: {{SIZE}}{{UNIT}}; height: calc( {{SIZE}}{{UNIT}} * 0.5625 );',
					'{{WRAPPER}}.pp-aspect-ratio-43 .pp-video.pp-sticky-apply .pp-video-sticky-wrap,
					{{WRAPPER}}.pp-aspect-ratio-43 .pp-sticky-apply .pp-video-thumb' => 'width: {{SIZE}}{{UNIT}}; height: calc( {{SIZE}}{{UNIT}} * 0.75 );',
					'{{WRAPPER}}.pp-aspect-ratio-32 .pp-video.pp-sticky-apply .pp-video-sticky-wrap,
					{{WRAPPER}}.pp-aspect-ratio-32 .pp-sticky-apply .pp-video-thumb' => 'width: {{SIZE}}{{UNIT}}; height: calc( {{SIZE}}{{UNIT}} * 0.6666666666666667 );',
					'{{WRAPPER}}.pp-aspect-ratio-916 .pp-video.pp-sticky-apply .pp-video-sticky-wrap,
					{{WRAPPER}}.pp-aspect-ratio-916 .pp-sticky-apply .pp-video-thumb' => 'width: {{SIZE}}{{UNIT}}; height: calc( {{SIZE}}{{UNIT}} * 1.7778 );',
					'{{WRAPPER}}.pp-aspect-ratio-11 .pp-video.pp-sticky-apply .pp-video-sticky-wrap,
					{{WRAPPER}}.pp-aspect-ratio-11 .pp-sticky-apply .pp-video-thumb' => 'width: {{SIZE}}{{UNIT}}; height: calc( {{SIZE}}{{UNIT}} * 1 );',
					'{{WRAPPER}}.pp-aspect-ratio-219 .pp-video.pp-sticky-apply .pp-video-sticky-wrap,
					{{WRAPPER}}.pp-aspect-ratio-219 .pp-sticky-apply .pp-video-thumb' => 'width: {{SIZE}}{{UNIT}}; height: calc( {{SIZE}}{{UNIT}} * 0.42857 );',
				],
				'condition'      => [
					'enable_sticky' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'sticky_video_border',
				'selector' => '{{WRAPPER}} .pp-sticky-apply .pp-video-thumb',
			]
		);

		$this->add_responsive_control(
			'sticky_video_margin',
			[
				'label'       => esc_html__( 'Margin', 'powerpack' ),
				'type'        => Controls_Manager::DIMENSIONS,
				'size_units'  => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'   => [
					'{{WRAPPER}}.pp-video-sticky-top_right .pp-sticky-apply .pp-video-sticky-wrap' => 'top: {{TOP}}{{UNIT}}; inset-inline-end: {{RIGHT}}{{UNIT}};',
					'{{WRAPPER}}.pp-video-sticky-top_left .pp-sticky-apply .pp-video-sticky-wrap' => 'top: {{TOP}}{{UNIT}}; inset-inline-start: {{LEFT}}{{UNIT}};',
					'.admin-bar {{WRAPPER}}.pp-video-sticky-top_left .pp-sticky-apply .pp-video-sticky-wrap,
					.admin-bar {{WRAPPER}}.pp-video-sticky-top_right .pp-sticky-apply .pp-video-sticky-wrap' => 'top: calc( {{TOP}}{{UNIT}} + 32px );',
					'{{WRAPPER}}.pp-video-sticky-bottom_right .pp-sticky-apply .pp-video-sticky-wrap' => 'bottom: {{BOTTOM}}{{UNIT}}; inset-inline-end: {{RIGHT}}{{UNIT}};',
					'{{WRAPPER}}.pp-video-sticky-bottom_left .pp-sticky-apply .pp-video-sticky-wrap' => 'bottom: {{BOTTOM}}{{UNIT}}; inset-inline-start: {{LEFT}}{{UNIT}};',
					'{{WRAPPER}}.pp-video-sticky-center_left .pp-sticky-apply .pp-video-sticky-wrap' => 'inset-inline-start: {{LEFT}}{{UNIT}};',
					'{{WRAPPER}}.pp-video-sticky-center_right .pp-sticky-apply .pp-video-sticky-wrap' => 'inset-inline-end: {{RIGHT}}{{UNIT}};',
				],
				'render_type' => 'template',
				'condition'   => [
					'enable_sticky' => 'yes',
				],
			]
		);

		$this->add_control(
			'heading_sticky_close_button_style',
			[
				'label'     => esc_html__( 'Close Button', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'enable_sticky'              => 'yes',
					'enable_sticky_close_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticky_close_icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-sticky-apply .pp-video-sticky-close' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-sticky-apply .pp-video-sticky-close svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'enable_sticky'              => 'yes',
					'enable_sticky_close_button' => 'yes',
				],
			]
		);
		$this->add_control(
			'sticky_close_icon_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-sticky-apply .pp-video-sticky-close' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'enable_sticky'              => 'yes',
					'enable_sticky_close_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'heading_sticky_info_bar__style',
			[
				'label'     => esc_html__( 'Info Bar', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'enable_sticky'          => 'yes',
					'enable_sticky_info_bar' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticky_info_bar_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-sticky-apply .pp-video-sticky-infobar' => 'color: {{VALUE}};',
				],
				'condition' => [
					'enable_sticky'          => 'yes',
					'enable_sticky_info_bar' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticky_info_bar_bgcolor',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-sticky-apply .pp-video-sticky-infobar' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'enable_sticky'          => 'yes',
					'enable_sticky_info_bar' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'sticky_info_bar_typography',
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '{{WRAPPER}} .pp-sticky-apply .pp-video-sticky-infobar',
				'condition' => [
					'enable_sticky'          => 'yes',
					'enable_sticky_info_bar' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'sticky_info_bar_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-sticky-apply .pp-video-sticky-infobar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'enable_sticky'          => 'yes',
					'enable_sticky_info_bar' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render video widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! $this->get_video_url() ) {
			$this->render_editor_placeholder(
				[
					'title' => esc_html__( 'No video selected!', 'powerpack' ),
					'body'  => esc_html__( 'Choose a video source, then add a video URL or pick a file in the widget settings.', 'powerpack' ),
				]
			);

			return;
		}

		$this->add_render_attribute( [
			'video' => [
				'class' => [ 'pp-video', 'pp-video-type-' . $settings['video_source'] ],
			],
		] );

		if ( 'hosted' === $settings['video_source'] ) {
			// The player is built by the frontend handler from these attributes.
			// Shipping the parameters rather than a rendered element keeps the
			// markup out of the payload and off the handler's '.html()' path.
			$this->add_render_attribute(
				'video',
				[
					'data-hosted-params' => wp_json_encode( (object) $this->get_hosted_params() ),
				]
			);
		}

		if ( 'yes' === $settings['enable_sticky'] ) {
			$sticky_infobar = ( 'yes' === $settings['enable_sticky_info_bar'] ) ? 'pp-sticky-infobar-wrap' : '';

			/**
			 * Filters the scroll threshold at which the sticky video is pinned.
			 *
			 * Read by the frontend handler as an IntersectionObserver threshold.
			 *
			 * @since 3.1.0
			 *
			 * @param int $viewport Percentage of the video that must leave the viewport
			 *                      before it becomes sticky. Accepts 0-100.
			 */
			$viewport = apply_filters( 'pp_sticky_video_viewport', 0 );

			if ( ! empty( $settings['sticky_video_margin'] ) ) {
				$sticky_bottom = ( '' !== $settings['sticky_video_margin']['bottom'] ) ? $settings['sticky_video_margin']['bottom'] : '';
				$this->add_render_attribute( 'video', 'data-sticky-bottom', $sticky_bottom );
			}

			$this->add_render_attribute( 'video', 'class', $sticky_infobar );
			$this->add_render_attribute( 'video', 'data-vs-viewport', $viewport );
		}

		?>
		<div <?php $this->print_render_attribute_string( 'video' ); ?>>
			<?php $this->render_video(); ?>
		</div>
		<?php
	}

	/**
	 * Render video widget as plain content.
	 *
	 * Override the default behavior, by printing the video URL instead of rendering it.
	 *
	 * @since 2.3.0
	 * @access public
	 */
	public function render_plain_content() {
		echo esc_url( $this->get_video_url() );
	}

	/**
	 * Render the video container, player and sticky chrome.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_video() {
		$settings   = $this->get_settings_for_display();
		$video_url  = $this->get_video_embed_url();
		$thumb_size = ( 'youtube' === $settings['video_source'] ) ? $settings['thumbnail_size'] : '';

		$play_label = ! empty( $settings['aria_label'] ) ? $settings['aria_label'] : esc_html__( 'Play video', 'powerpack' );

		$this->add_render_attribute(
			[
				'video-container' => [
					'class' => 'pp-video-container',
				],
				'video-play'      => [
					'class'      => 'pp-video-play',
					'role'       => 'button',
					'tabindex'   => '0',
					'aria-label' => esc_attr( $play_label ),
				],
				'video-player'    => [
					'class'    => 'pp-video-player',
					'data-src' => esc_url( $video_url ),
				],
			]
		);

		if ( 'yes' === $settings['lightbox'] ) {
			$this->add_lightbox_attributes( $video_url );
			$this->add_render_attribute( 'video-play', 'aria-haspopup', 'dialog' );
		} else {
			$this->add_render_attribute( 'video-play', 'data-autoplay', ( 'yes' === $settings['autoplay'] ) ? '1' : '0' );
		}

		$poster = '';

		if ( 'hosted' === $settings['video_source'] ) {
			if ( 'yes' === $settings['custom_thumbnail'] && $settings['custom_image']['url'] ) {
				$poster = $settings['custom_image']['url'];
			}

			$this->add_render_attribute(
				'hosted-video',
				[
					'class'   => 'pp-hosted-video',
					'src'     => esc_url( $video_url ),
					'preload' => $settings['preload'],
					'poster'  => $poster,
				]
			);
		}

		?>
		<div <?php $this->print_render_attribute_string( 'video-container' ); ?>>
			<?php if ( 'yes' === $settings['enable_sticky'] ) { ?>
				<div class="pp-video-sticky-wrap">
			<?php } ?>
			<div <?php $this->print_render_attribute_string( 'video-play' ); ?>>
				<?php
					// Video Overlay
					echo wp_kses_post( $this->render_video_overlay() );
				?>
				<div <?php $this->print_render_attribute_string( 'video-player' ); ?>>
					<?php
						if ( 'hosted' === $settings['video_source'] && ! $poster ) {
							?>
							<video <?php $this->print_render_attribute_string( 'hosted-video' ); ?>></video>
							<?php
						} elseif ( 'hosted' === $settings['video_source'] ) {
							$this->render_video_thumbnail( $poster );
						} else {
							$this->render_video_thumbnail( $this->get_video_thumbnail( $thumb_size ) );
						}

						$this->render_play_icon();
					?>
				</div>
			</div>
			<?php
			if ( 'yes' === $settings['enable_sticky'] ) {
				$this->render_sticky_chrome();
				?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Returns the video URL for the selected source, as the user entered it.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return string Video URL, or an empty string when none is set.
	 */
	protected function get_video_url() {
		$settings = $this->get_settings_for_display();

		if ( 'hosted' === $settings['video_source'] ) {
			return $this->get_hosted_video_url();
		}

		return $settings[ $settings['video_source'] . '_url' ] ?? '';
	}

	/**
	 * Returns the URL the player actually loads.
	 *
	 * For the providers that is the embed URL built from the widget's playback
	 * options; for self hosted video it is the file URL.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return string Player URL, or an empty string when none could be built.
	 */
	protected function get_video_embed_url() {
		$settings = $this->get_settings_for_display();

		if ( 'hosted' === $settings['video_source'] ) {
			return $this->get_hosted_video_url();
		}

		$video_url_src = $this->get_video_url();
		$embed_params  = $this->get_embed_params();
		$embed_options = $this->get_embed_options();

		if ( preg_match( '/youtube\.com\/shorts\/(\w+\s*\/?)*([0-9]+)*(.*)$/i', $video_url_src, $matches ) ) {
			return $this->get_yt_short_embed_url( $matches[1], $embed_params, $embed_options );
		}

		return (string) Embed::get_embed_url( $video_url_src, $embed_params, $embed_options );
	}

	/**
	 * Add the attributes Elementor's lightbox reads off the play control.
	 *
	 * @since 3.1.0
	 * @access private
	 *
	 * @param string $video_url URL the lightbox should open.
	 *
	 * @return void
	 */
	private function add_lightbox_attributes( $video_url ) {
		$settings = $this->get_settings_for_display();

		$lightbox_options = [
			'type'         => 'video',
			'videoType'    => $settings['video_source'],
			'url'          => $video_url,
			'modalOptions' => [
				'id'                       => 'elementor-lightbox-' . $this->get_id(),
				'entranceAnimation'        => $settings['lightbox_content_animation'],
				// Responsive sub-keys only exist once the control has a value for that device.
				'entranceAnimation_tablet' => ! empty( $settings['lightbox_content_animation_tablet'] ) ? $settings['lightbox_content_animation_tablet'] : '',
				'entranceAnimation_mobile' => ! empty( $settings['lightbox_content_animation_mobile'] ) ? $settings['lightbox_content_animation_mobile'] : '',
				'videoAspectRatio'         => $settings['aspect_ratio'] ?? '169',
			],
		];

		if ( 'hosted' === $settings['video_source'] ) {
			$lightbox_options['videoParams'] = $this->get_hosted_params();
		}

		$this->add_render_attribute( 'video-play', 'class', 'pp-video-play-lightbox' );
		$this->add_render_attribute(
			'video-play',
			[
				'data-elementor-open-lightbox' => 'yes',
				'data-elementor-lightbox'      => wp_json_encode( $lightbox_options ),
			]
		);
	}

	/**
	 * Render the close button and info bar shown while the player is pinned.
	 *
	 * @since 3.1.0
	 * @access private
	 *
	 * @return void
	 */
	private function render_sticky_chrome() {
		$settings = $this->get_settings_for_display();

		if ( 'yes' === $settings['enable_sticky_close_button'] ) {
			?>
			<button type="button" class="pp-video-sticky-close" aria-label="<?php esc_attr_e( 'Close video', 'powerpack' ); ?>">
				<?php
				// Icons_Manager renders an inline SVG or a font icon depending on
				// the e_font_icon_svg experiment, so no branch is needed here.
				Icons_Manager::render_icon(
					[
						'value'   => 'fas fa-times',
						'library' => 'fa-solid',
					],
					[
						'class'       => 'pp-sticky-close-icon',
						'aria-hidden' => 'true',
					]
				);
				?>
			</button>
			<?php
		}

		if ( 'yes' === $settings['enable_sticky_info_bar'] && '' !== $settings['sticky_info_bar_text'] ) {
			?>
			<div class="pp-video-sticky-infobar"><?php echo wp_kses_post( $settings['sticky_info_bar_text'] ); ?></div>
			<?php
		}
	}

	/**
	 * Build the embed URL for a YouTube Shorts video.
	 *
	 * @since 2.9.0
	 * @access private
	 *
	 * @param string $video_id      YouTube Shorts video ID.
	 * @param array  $embed_params  Query arguments appended to the embed URL.
	 * @param array  $embed_options Embed options. Supports a 'privacy' key.
	 *
	 * @return string Embed URL.
	 */
	private function get_yt_short_embed_url( $video_id, $embed_params, $embed_options ) {
		if ( 'yes' === $embed_options['privacy'] ) {
			$yt_url = 'https://www.youtube-nocookie.com/embed/' . $video_id;
		} else {
			$yt_url = 'https://www.youtube.com/embed/' . $video_id;
		}
		return add_query_arg( $embed_params, $yt_url );
	}

	/**
	 * Render the video thumbnail image.
	 *
	 * A media library thumbnail is rendered from its attachment so the browser
	 * gets a srcset instead of always downloading the full size file, and so the
	 * alt text the user wrote is not thrown away.
	 *
	 * @since 3.1.0
	 * @access private
	 *
	 * @param string $url Thumbnail URL. Used when there is no attachment to render from.
	 *
	 * @return void
	 */
	private function render_video_thumbnail( $url ) {
		if ( ! $url ) {
			return;
		}

		$settings = $this->get_settings_for_display();

		$attributes = [
			'class'    => 'pp-video-thumb',
			'decoding' => 'async',
			// An autoplaying video shows its poster immediately, so it is not below the fold.
			'loading'  => ( 'yes' === $settings['autoplay'] ) ? 'eager' : 'lazy',
		];

		$is_custom_thumbnail = ( 'yes' === $settings['custom_thumbnail'] );
		$attachment_id       = ( $is_custom_thumbnail && ! empty( $settings['custom_image']['id'] ) ) ? $settings['custom_image']['id'] : 0;

		if ( $attachment_id ) {
			echo wp_get_attachment_image( $attachment_id, 'full', false, $attributes );

			return;
		}

		$attributes['src'] = esc_url( $url );

		// A provider thumbnail is decorative - the play control carries the accessible name.
		$attributes['alt'] = $is_custom_thumbnail ? Control_Media::get_image_alt( $settings['custom_image'] ) : '';

		Utils::print_unescaped_internal_string( '<img ' . Utils::render_html_attributes( $attributes ) . '>' );
	}

	/**
	 * Returns Video Thumbnail.
	 *
	 * @access protected
	 *
	 * @param string $thumb_size YouTube thumbnail size key. Unused by the other sources.
	 *
	 * @return string Thumbnail URL, or an empty string when none could be resolved.
	 */
	protected function get_video_thumbnail( $thumb_size ) {
		$settings = $this->get_settings_for_display();

		$thumb_url = '';
		$video_id  = $this->get_video_id();

		if ( 'yes' === $settings['custom_thumbnail'] ) {
			if ( $settings['custom_image']['url'] ) {
				$thumb_url = $settings['custom_image']['url'];
			}
		} elseif ( 'youtube' === $settings['video_source'] ) {
			if ( $video_id ) {
				$thumb_url = 'https://i.ytimg.com/vi/' . $video_id . '/' . $thumb_size . '.jpg';
			}
		} elseif ( $video_id && in_array( $settings['video_source'], [ 'vimeo', 'dailymotion' ], true ) ) {
			$thumb_url = $this->get_remote_video_thumbnail( $settings['video_source'], $video_id );
		}

		return $thumb_url;
	}

	/**
	 * Returns the thumbnail URL for a provider that has to be asked over HTTP.
	 *
	 * The response is cached per video, because this runs on every render -
	 * including every editor preview - and an uncached miss blocks the page on a
	 * third party API.
	 *
	 * @since 3.1.0
	 * @access private
	 *
	 * @param string $video_source Provider slug. Accepts 'vimeo' or 'dailymotion'.
	 * @param string $video_id     Provider video ID.
	 *
	 * @return string Thumbnail URL, or an empty string when it could not be resolved.
	 */
	private function get_remote_video_thumbnail( $video_source, $video_id ) {
		$cache_key = 'pp_video_thumb_' . md5( $video_source . '|' . $video_id );
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return $cached;
		}

		if ( 'vimeo' === $video_source ) {
			// The .json sibling of this endpoint returns the same data. The .php one
			// returns a serialized payload, and unserializing a third party response
			// is an object injection waiting to happen.
			$endpoint = 'https://vimeo.com/api/v2/video/' . rawurlencode( $video_id ) . '.json';
		} else {
			$endpoint = 'https://api.dailymotion.com/video/' . rawurlencode( $video_id ) . '?fields=thumbnail_url';
		}

		$response = wp_remote_get( $endpoint, [ 'timeout' => 5 ] );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			// Retry sooner than a success, so an outage does not hide thumbnails all day.
			set_transient( $cache_key, '', HOUR_IN_SECONDS );

			return '';
		}

		$body      = json_decode( wp_remote_retrieve_body( $response ), true );
		$thumb_url = '';

		if ( 'vimeo' === $video_source ) {
			if ( ! empty( $body[0]['thumbnail_large'] ) && is_string( $body[0]['thumbnail_large'] ) ) {
				$thumb_url = str_replace( '_640', '_840', $body[0]['thumbnail_large'] );
			}
		} elseif ( ! empty( $body['thumbnail_url'] ) && is_string( $body['thumbnail_url'] ) ) {
			$thumb_url = $body['thumbnail_url'];
		}

		// The URL comes from a third party, so only let a real http(s) URL through.
		$thumb_url = esc_url_raw( $thumb_url, [ 'http', 'https' ] );

		set_transient( $cache_key, $thumb_url, $thumb_url ? DAY_IN_SECONDS : HOUR_IN_SECONDS );

		return $thumb_url;
	}

	/**
	 * Returns Video ID.
	 *
	 * @access protected
	 *
	 * @return string Provider video ID, or an empty string when it could not be parsed.
	 */
	protected function get_video_id() {
		$settings = $this->get_settings_for_display();

		$video_id = '';

		if ( 'youtube' === $settings['video_source'] ) {
			$url = $settings['youtube_url'];

			if ( preg_match( '#(?<=v=|v\/|vi=|vi\/|youtu.be\/)[a-zA-Z0-9_-]{11}#', $url, $matches ) ) {
				$video_id = $matches[0];
			} else {
				if ( preg_match( '/youtube\.com\/shorts\/(\w+\s*\/?)*([0-9]+)*(.*)$/i', $url, $matches ) ) {
					$video_id = $matches[1];
				}
			}
		} elseif ( 'vimeo' === $settings['video_source'] ) {
			$url = $settings['vimeo_url'];

			$video_id = preg_replace( '/[^\/]+[^0-9]|(\/)/', '', rtrim( $url, '/' ) );

		} elseif ( 'dailymotion' === $settings['video_source'] ) {
			$url = $settings['dailymotion_url'];

			if ( preg_match( '/^.+dailymotion.com\/(?:video|swf\/video|embed\/video|hub|swf)\/([^&?]+)/', $url, $matches ) ) {
				$video_id = $matches[1];
			}
		}

		return $video_id;

	}

	/**
	 * Returns the self hosted video URL, with the media fragment appended.
	 *
	 * @since 2.2.7
	 * @access protected
	 *
	 * @return string Video URL, or an empty string when none is set.
	 */
	protected function get_hosted_video_url() {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['insert_url'] ) ) {
			$video_url = $settings['external_url']['url'];
		} else {
			$video_url = $settings['hosted_url']['url'];
		}

		if ( empty( $video_url ) ) {
			return '';
		}

		if ( $settings['start_time'] || $settings['end_time'] ) {
			$video_url .= '#t=';
		}

		if ( $settings['start_time'] ) {
			$video_url .= $settings['start_time'];
		}

		if ( $settings['end_time'] ) {
			$video_url .= ',' . $settings['end_time'];
		}

		return $video_url;
	}

	/**
	 * Returns the attribute map for the self hosted '<video>' element.
	 *
	 * @since 2.2.7
	 * @access protected
	 *
	 * @return array Video element attributes.
	 */
	protected function get_hosted_params() {
		$settings = $this->get_settings_for_display();

		$video_params = [];

		foreach ( [ 'autoplay', 'loop', 'controls' ] as $option_name ) {
			if ( $settings[ $option_name ] ) {
				$video_params[ $option_name ] = '';
			}
		}

		$video_params['controlsList'] = 'nodownload';

		if ( $settings['mute'] ) {
			$video_params['muted'] = 'muted';
		}

		if ( $settings['play_on_mobile'] ) {
			$video_params['playsinline'] = '';
		}

		if ( 'yes' === $settings['custom_thumbnail'] ) {
			if ( $settings['custom_image']['url'] ) {
				$video_params['poster'] = $settings['custom_image']['url'];
			}
		}

		return $video_params;
	}

	/**
	 * Get embed params.
	 *
	 * Retrieve video widget embed parameters.
	 *
	 * @access public
	 *
	 * @return array Video embed parameters.
	 */
	public function get_embed_params() {
		$settings = $this->get_settings_for_display();

		$params = [];

		$params_dictionary = [];

		if ( 'youtube' === $settings['video_source'] ) {
			$params_dictionary = [
				'loop',
				'controls',
				'mute',
				'rel',
				'cc_load_policy',
			];

			if ( $settings['loop'] ) {
				$video_properties = Embed::get_video_properties( $settings['youtube_url'] );

				$params['playlist'] = $video_properties['video_id'];
			}

			$params['autoplay'] = 1;

			if ( $settings['play_on_mobile'] ) {
				$params['playsinline'] = '1';
			}

			$params['wmode'] = 'opaque';

			$params['start'] = (int) $settings['start_time'];

			$params['end'] = (int) $settings['end_time'];
		} elseif ( 'vimeo' === $settings['video_source'] ) {
			$params_dictionary = [
				'loop',
				'mute'           => 'muted',
				'vimeo_title'    => 'title',
				'vimeo_portrait' => 'portrait',
				'vimeo_byline'   => 'byline',
			];

			$params['color'] = str_replace( '#', '', $settings['color'] );

			$params['autopause'] = '0';
			$params['autoplay']  = '1';

			if ( $settings['play_on_mobile'] ) {
				$params['playsinline'] = '1';
			}
		} elseif ( 'dailymotion' === $settings['video_source'] ) {
			$params_dictionary = [
				'controls',
				'mute',
				'showinfo' => 'ui-start-screen-info',
				'logo'     => 'ui-logo',
			];

			$params['ui-highlight'] = str_replace( '#', '', $settings['color'] );

			$params['start'] = (int) $settings['start_time'];

			$params['endscreen-enable'] = '0';
			$params['autoplay']         = 1;

			if ( $settings['play_on_mobile'] ) {
				$params['playsinline'] = '1';
			}
		}

		foreach ( $params_dictionary as $key => $param_name ) {
			$setting_name = $param_name;

			if ( is_string( $key ) ) {
				$setting_name = $key;
			}

			$setting_value = $settings[ $setting_name ] ? '1' : '0';

			$params[ $param_name ] = $setting_value;
		}

		return $params;
	}


	/**
	 * Get embed options.
	 *
	 * @access private
	 *
	 * @return array Video embed options.
	 */
	private function get_embed_options() {
		$settings = $this->get_settings_for_display();

		$embed_options = [];

		if ( 'youtube' === $settings['video_source'] ) {
			$embed_options['privacy'] = $settings['yt_privacy'];
		} elseif ( 'vimeo' === $settings['video_source'] ) {
			$embed_options['start'] = (int) $settings['start_time'];
		}

		return $embed_options;
	}

	/**
	 * Render the video overlay element.
	 *
	 * @access protected
	 *
	 * @return string Overlay markup.
	 */
	protected function render_video_overlay() {
		$this->add_render_attribute( 'overlay', 'class', [
			'pp-media-overlay',
			'pp-video-overlay',
		] );

		return '<div ' . $this->get_render_attribute_string( 'overlay' ) . '></div>';
	}

	/**
	 * Render play icon output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_play_icon() {
		$settings = $this->get_settings_for_display();

		if ( 'none' === $settings['play_icon_type'] ) {
			return;
		}

		$this->add_render_attribute( 'play-icon', 'class', 'pp-video-play-icon' );

		if ( 'yes' === $settings['play_icon_glow_effect'] ) {
			$this->add_render_attribute( 'play-icon', 'class', 'pp-play-icon-glow' );
		}

		if ( ! empty( $settings['play_icon_hover_animation'] ) ) {
			$animation_class = 'elementor-animation-' . $settings['play_icon_hover_animation'];

			$this->add_render_attribute( 'play-icon', 'class', $animation_class );
		}

		if ( 'icon' === $settings['play_icon_type'] ) {
			if ( ! isset( $settings['play_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
				// add old default
				$settings['play_icon'] = 'fa fa-play-circle';
			}

			$has_icon = ! empty( $settings['play_icon'] );

			if ( $has_icon ) {
				$this->add_render_attribute( 'play-icon-i', 'class', $settings['play_icon'] );
				$this->add_render_attribute( 'play-icon-i', 'aria-hidden', 'true' );
			}

			if ( ! $has_icon && ! empty( $settings['select_play_icon']['value'] ) ) {
				$has_icon = true;
			}
			$migrated = isset( $settings['__fa4_migrated']['select_play_icon'] );
			$is_new   = ! isset( $settings['play_icon'] ) && Icons_Manager::is_migration_allowed();
			?>
			<span <?php $this->print_render_attribute_string( 'play-icon' ); ?>>
				<?php
				if ( $is_new || $migrated ) {
					$icon_atts = [ 'aria-hidden' => 'true' ];

					Icons_Manager::render_icon( $settings['select_play_icon'], $icon_atts );
				} elseif ( ! empty( $settings['play_icon'] ) ) {
					?>
					<i <?php $this->print_render_attribute_string( 'play-icon-i' ); ?>></i>
					<?php
				}
				?>
			</span>
			<?php

		} elseif ( 'image' === $settings['play_icon_type'] ) {

			if ( $settings['play_icon_image']['url'] ) {
				?>
				<span <?php $this->print_render_attribute_string( 'play-icon' ); ?>>
					<img src="<?php echo esc_url( $settings['play_icon_image']['url'] ); ?>" alt="" aria-hidden="true">
				</span>
				<?php
			}
		}
	}
}
