;(function($) {

	var PPWooMiniCart = function($scope) {
		this.node      = $scope;
		this.wrap      = $scope.find('.pp-woo-mini-cart-container');
		this.behaviour = this.wrap.data('target');

		this._init();
	};

	PPWooMiniCart.prototype = {
		node: '',
		wrap: '',
		element: '',
		cart: '',
		hideTimer: null,
		behaviour: '',
		isPreview: false,

		_init: function() {
			this.element = this.node.find('.pp-woo-cart-contents');
			this.cart    = this.node.find('.pp-woo-mini-cart-wrap');

			this._bindEvents();
		},

		_bindEvents: function() {
			var self = this;

			// Bound in both modes so Enter and Space work the button. Hover mode
			// deliberately does not open on focus: that dropped the panel over the
			// page on every Tab past the widget, forced keyboard users through
			// every link in it, and reopened it when Escape handed focus back.
			// Only the toggle form: when Show Cart on is None the button is a plain
			// link, and _onClick's preventDefault would stop it navigating.
			this.element.filter('[role="button"]').on('click', $.proxy( this._onClick, this ) );

			// The toggle is a div[role="button"], which gets no click from Enter or
			// Space of its own, and Space scrolls the page unless cancelled. The
			// link form of the button is left to the browser. The synthetic click
			// carries no originalEvent, so _onClick treats it as a keyboard toggle.
			this.element.filter('[role="button"]').on('keydown', function(e) {
				if ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key || 13 === e.which || 32 === e.which ) {
					e.preventDefault();
					$(this).trigger('click');
				}
			});

			if ( 'on-hover' === this.behaviour ) {
				// mouseenter/mouseleave on the container, not mouseover/mouseout on
				// the button. The bubbling pair fired every time the pointer crossed
				// onto one of the button's child spans, which made the panel flicker.
				// Binding to the container also covers the travel from button to panel.
				this.wrap.on('mouseenter', $.proxy( this._showCart, this ));
				this.wrap.on('mouseleave', $.proxy( this._hideCartLater, this ));
			}

			// Close once focus moves to something outside the widget, so an open
			// panel never covers the next focused element. A missing relatedTarget
			// (a click on non-focusable panel text, a removed node, the window losing
			// focus) is left alone; the outside click handler covers pointers.
			this.wrap.on('focusout', function(e) {
				if ( e.relatedTarget && ! $.contains( self.wrap[0], e.relatedTarget ) ) {
					self._hideCartLater();
				}
			});

			this.wrap.on('keydown', function(e) {
				if ( 'Escape' !== e.key && 27 !== e.keyCode ) {
					return;
				}

				if ( self.cart.hasClass('show-mini-cart') ) {
					self._hideCart();
					self.element.trigger('focus');
				}
			});

			if ( this.wrap.hasClass( 'pp-woo-mini-cart-preview' ) ) {
				setTimeout( function() {
					self._togglePreview();
				}, 200 );
			}
		},

		_showCart: function() {
			clearTimeout( this.hideTimer );
			this.cart.addClass('show-mini-cart');
			this.element.attr('aria-expanded', 'true');
		},

		_hideCart: function() {
			clearTimeout( this.hideTimer );
			this.cart.removeClass('show-mini-cart');
			this.element.attr('aria-expanded', 'false');
		},

		// Short grace period so crossing the gap between the button and the panel
		// does not close it mid-travel.
		_hideCartLater: function() {
			var self = this;

			clearTimeout( this.hideTimer );

			this.hideTimer = setTimeout( function() {
				self._hideCart();
			}, 200 );
		},

		/**
		 * Handle a click on the cart button.
		 *
		 * In hover mode a pointer click only opens, since mouseenter has usually
		 * opened the panel already and a toggle would shut it. A keyboard
		 * activation is a synthetic click with no originalEvent and toggles in
		 * both modes.
		 *
		 * @since x.x.x
		 */
		_onClick: function(e) {
			e.preventDefault();

			if ( 'on-hover' === this.behaviour && e.originalEvent && e.originalEvent.detail > 0 ) {
				this._showCart();
				return;
			}

			this._toggleCart();
		},

		_toggleCart: function() {
			if ( this.cart.hasClass('show-mini-cart') ) {
				this._hideCart();
			} else {
				this._showCart();
			}
		},

		_togglePreview: function() {
			if ( ! this.isPreview ) {
				this.isPreview = true;
				this._showCart();
			} else {
				this.isPreview = false;
				this._hideCart();
			}
		},

	};

	/**
	 * Close open mini carts when the click lands outside them.
	 *
	 * Bound once for the document rather than once per widget instance. The
	 * element_ready hook fires again on every editor re-render and there is no
	 * teardown hook here, so a per-instance handler would accumulate for the
	 * whole editing session and keep detached scopes alive.
	 */
	$(document).on('click.ppWooMiniCart', function(e) {
		if ( ! e.which ) {
			return;
		}

		var $open = $('.pp-woo-mini-cart-wrap.show-mini-cart');

		if ( ! $open.length ) {
			return;
		}

		$open.each(function() {
			var $cart      = $(this),
				$container = $cart.closest('.pp-woo-mini-cart-container');

			if ( $container.hasClass('pp-woo-mini-cart-preview') ) {
				return;
			}

			if ( $container.is(e.target) || $container.has(e.target).length ) {
				return;
			}

			$cart.removeClass('show-mini-cart');
			$container.find('.pp-woo-cart-contents').attr('aria-expanded', 'false');
		});
	});

	/**
	 * Keep focus in the panel when an item is removed.
	 *
	 * WooCommerce rebuilds the whole cart list after a removal, which destroys the
	 * remove link that had focus and drops keyboard users back to the top of the
	 * page. Remember which link was used, then focus the one now in its place, or
	 * the empty cart message once nothing is left. Bound once for the document,
	 * like the outside click handler, so editor re-renders do not stack handlers.
	 *
	 * @since x.x.x
	 */
	$(document).on('click.ppWooMiniCart', '.pp-woo-mini-cart-wrap .remove_from_cart_button', function() {
		var $cart = $(this).closest('.pp-woo-mini-cart-wrap');

		$cart.data('ppRemoveIndex', $cart.find('.remove_from_cart_button').index(this));
	});

	$(document.body).on('removed_from_cart.ppWooMiniCart', function() {
		// WooCommerce swaps the fragments in its own removed_from_cart handler.
		// Wait for that to finish.
		setTimeout(function() {
			$('.pp-woo-mini-cart-wrap').each(function() {
				var $cart = $(this),
					index = $cart.data('ppRemoveIndex'),
					$remove,
					$target;

				if ( undefined === index ) {
					return;
				}

				$cart.removeData('ppRemoveIndex');

				if ( document.activeElement && document.activeElement !== document.body ) {
					return;
				}

				$remove = $cart.find('.remove_from_cart_button');

				if ( $remove.length ) {
					$target = $remove.eq( Math.min( index, $remove.length - 1 ) );
				} else {
					// Prefer the empty message so it is read; the title is the fallback
					// for templates that drop it. A multi-selector find() would return
					// them in document order, which puts the title first.
					$target = $cart.find('.woocommerce-mini-cart__empty-message').first();

					if ( ! $target.length ) {
						$target = $cart.find('.pp-woo-mini-cart-title');
					}

					$target.attr('tabindex', '-1');
				}

				$target.trigger('focus');
			});
		});
	});

	var WooMiniCartHandler = function ($scope) {
		new PPWooMiniCart( $scope );
	};

	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/pp-woo-mini-cart.default', WooMiniCartHandler );
	});

})( jQuery );
