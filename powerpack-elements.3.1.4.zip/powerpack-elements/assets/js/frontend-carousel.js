(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class PpCarouselWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						swiperContainer: '.pp-swiper-slider',
						swiperSlide: '.swiper-slide',
					},
					slidesPerView: {
						widescreen: 3,
						desktop: 3,
						laptop: 3,
						tablet_extra: 3,
						tablet: 2,
						mobile_extra: 2,
						mobile: 1
					}
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' ),
					$swiperContainer = this.$element.find( selectors.swiperContainer );

				return {
					$swiperContainer: $swiperContainer,
					// Scoped to the main slider so thumbnail carousel slides are not counted as slides.
					$swiperSlide: $swiperContainer.find( selectors.swiperSlide ),
				};
			}

			getSliderSettings(prop) {
				const sliderSettings = ( undefined !== this.elements.$swiperContainer.data('slider-settings') ) ? this.elements.$swiperContainer.data('slider-settings') : '';

				if ( 'undefined' !== typeof prop && 'undefined' !== sliderSettings[prop] ) {
					return sliderSettings[prop];
				}

				return sliderSettings;
			}

			getSlidesCount() {
				return this.elements.$swiperSlide.length;
			}

			getEffect() {
				return this.getSliderSettings('effect') || 'slide';
			}

			getDeviceSlidesPerView(device) {
				const slidesPerViewKey = 'slides_per_view' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getSliderSettings(slidesPerViewKey) || this.getSettings('slidesPerView')[device]);
			}

			getSlidesPerView(device) {
				if ('slide' === this.getEffect() || 'coverflow' === this.getEffect()) {
					return this.getDeviceSlidesPerView(device);
				}
				return 1;
			}

			getDeviceSlidesToScroll(device) {
				const slidesToScrollKey = 'slides_to_scroll' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getElementSettings(slidesToScrollKey) || 1);
			}

			getSlidesToScroll(device) {
				if ('slide' === this.getEffect()) {
					return this.getDeviceSlidesToScroll(device);
				}
				return 1;
			}

			getSpaceBetween(device) {
				let propertyName = 'space_between';
				if (device && 'desktop' !== device) {
					propertyName += '_' + device;
				}
				// return this.getSliderSettings(propertyName) || '';
				// Swiper adds this to slide positions with +, so a size saved as the string "10"
				// concatenated into a nonsense grid and left the arrows unable to move.
				return parseFloat( elementorFrontend.utils.controls.getResponsiveControlValue(this.getSliderSettings(), 'space_between', 'size', device) ) || 0;
			}

			getSwiperOptions() {
				const sliderSettings = this.getSliderSettings();
				// const swiperOptions = ( undefined !== this.elements.$swiperContainer.data('slider-settings') ) ? this.elements.$swiperContainer.data('slider-settings') : '';

				const swiperOptions = {
					grabCursor:                'yes' === sliderSettings.grab_cursor,
					// initialSlide:               this.getInitialSlide(),
					slidesPerView:              this.getSlidesPerView('desktop'),
					slidesPerGroup:             this.getSlidesToScroll('desktop'),
					spaceBetween:               this.getSpaceBetween(),
					loop:                       'yes' === sliderSettings.loop,
					centeredSlides:             'yes' === sliderSettings.centered_slides,
					speed:                      sliderSettings.speed,
					autoHeight:                 sliderSettings.auto_height,
					effect:                     this.getEffect(),
					watchSlidesVisibility:      true,
					watchSlidesProgress:        true,
					preventClicksPropagation:   false,
					slideToClickedSlide:        true,
					handleElementorBreakpoints: true,
				};

				if ( 'fade' === this.getEffect() ) {
					swiperOptions.fadeEffect = {
						crossFade: true,
					};
				}

				if ( sliderSettings.show_arrows ) {
					var prevEle = ( this.isEdit ) ? '.elementor-swiper-button-prev' : '.swiper-button-prev-' + this.getID();
					var nextEle = ( this.isEdit ) ? '.elementor-swiper-button-next' : '.swiper-button-next-' + this.getID();

					swiperOptions.navigation = {
						prevEl: prevEle,
						nextEl: nextEle,
					};
				}

				if ( sliderSettings.pagination ) {
					var paginationEle = ( this.isEdit ) ? '.swiper-pagination' : '.swiper-pagination-' + this.getID();

					swiperOptions.pagination = {
						el: paginationEle,
						type: sliderSettings.pagination,
						clickable: true
					};
				}

				/*
				 * Opt-in per widget, via `a11y` in data-slider-settings. The a11y module is what makes the
				 * div[role=button] arrows answer Enter and Space — a div does not synthesise
				 * a click from those the way a native button does — and what gives the
				 * pagination bullets a role and a tab stop. It also sets aria-disabled at
				 * either end.
				 *
				 * Swiper's keyboard module rides the same opt-in: it listens on the document,
				 * so enabling it everywhere would let an arrow key pressed anywhere on the
				 * page move every carousel currently on screen.
				 */
				if ( 'yes' === sliderSettings.a11y ) {
					const i18n = this.getI18n();

					swiperOptions.a11y = {
						enabled:                    true,
						prevSlideMessage:           i18n.prevSlide  || 'Previous slide',
						nextSlideMessage:           i18n.nextSlide  || 'Next slide',
						firstSlideMessage:          i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:           i18n.lastSlide  || 'This is the last slide',
						paginationBulletMessage:    i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:          i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						slideRole:                  'group',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide',
					};

					/*
					 * A widget can keep the strings and still turn this off with `keyboard: 'no'`.
					 * The module ignores preventDefault(), so a widget with its own arrow-key
					 * handling (the Image Slider's thumbnails) would move twice per key.
					 */
					if ( 'no' !== sliderSettings.keyboard ) {
						swiperOptions.keyboard = {
							enabled:        true,
							onlyInViewport: true,
						};
					}
				}

				if ('cube' !== this.getEffect()) {
					const breakpointsSettings = {},
					breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

					Object.keys(breakpoints).forEach(breakpointName => {
						breakpointsSettings[breakpoints[breakpointName].value] = {
							slidesPerView: this.getSlidesPerView(breakpointName),
							slidesPerGroup: this.getSlidesToScroll(breakpointName),
						};

						if ( this.getSpaceBetween(breakpointName) ) {
							breakpointsSettings[breakpoints[breakpointName].value].spaceBetween = this.getSpaceBetween(breakpointName);
						}
					});

					swiperOptions.breakpoints = breakpointsSettings;
				}

				if ( !this.isEdit && sliderSettings.autoplay && ! this.isMotionReduced() ) {
					swiperOptions.autoplay = {
						delay: sliderSettings.autoplay_speed,
						disableOnInteraction: !!sliderSettings.pause_on_interaction
					};
				}

				return swiperOptions;
			}

			getI18n() {
				return ( 'undefined' !== typeof ppCarouselScript && ppCarouselScript.i18n )
					? ppCarouselScript.i18n
					: {};
			}

			prefersReducedMotion() {
				return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
			}

			/**
			 * Autoplay and slide animation are decorative, so an explicit system-level
			 * request for reduced motion is always honoured — there is no author opt-out.
			 */
			isMotionReduced() {
				return this.prefersReducedMotion();
			}

			bindEvents() {
				if ( this.elements.$swiperContainer.hasClass('pp-swiper-slider') ) {
					this.initSlider();
				}
			}

			/**
			 * Slides that are off screen have to leave the accessibility tree and the tab order
			 * together. Keying off the active index alone hid slides that were plainly visible
			 * whenever slidesPerView was above one — with the default of three, two of the three
			 * members on screen were erased for screen readers while their links stayed tabbable.
			 * watchSlidesProgress already maintains the class this reads.
			 */
			syncSlideVisibility() {
				const $slides = this.elements.$swiperContainer.find( '.swiper-slide' );

				// Effects such as cube never set the visibility class. Hiding every slide
				// because none is marked visible would be far worse than hiding none.
				const hasVisibilityClass = $slides.filter( '.swiper-slide-visible' ).length > 0;

				$slides.each( function() {
					// A slide is never itself a control, so it should hold no tabindex at all.
					this.removeAttribute( 'tabindex' );

					if ( ! hasVisibilityClass || this.classList.contains( 'swiper-slide-visible' ) ) {
						this.removeAttribute( 'aria-hidden' );
						this.removeAttribute( 'inert' );
					} else {
						this.setAttribute( 'aria-hidden', 'true' );
						// inert is what actually takes the links inside out of the tab order;
						// aria-hidden on its own is what created the mismatch.
						this.setAttribute( 'inert', '' );
					}
				} );
			}

			/**
			 * Announces the slide position, but only where the user asked for the move.
			 */
			announceSlidePosition() {
				if ( ! this.userNavigated ) {
					return;
				}

				this.userNavigated = false;

				const statusFormat = this.getI18n().slideStatus || 'Showing Slide %1$s of %2$s';

				let statusText = statusFormat
					.replace( '%1$s', this.swiper.realIndex + 1 )
					.replace( '%2$s', this.getSlidesCount() );

				/*
				 * Widgets that name their slides say which one is showing: the Image Slider
				 * prints data-image-label from the attachment's alt, falling back to its
				 * caption, and renders the first slide's status with that label already
				 * appended — without this the label would disappear on the first move.
				 * Carousels with nothing meaningful to name announce the position alone.
				 */
				const slideLabel = this.elements.$swiperContainer
					.find( '.swiper-slide-active' )
					.attr( 'data-image-label' );

				if ( slideLabel ) {
					statusText += ': ' + slideLabel;
				}

				/*
				 * [aria-live] and not the class alone: .elementor-screen-only is a plain
				 * visually hidden marker, and slides carry their own (the "(opens in a new
				 * tab)" note on external links), which a bare descendant match overwrites
				 * with the slide count.
				 */
				this.elements.$swiperContainer.find( '.elementor-screen-only[aria-live]' ).text( statusText );
			}

			async initSlider() {
				const elementSettings = this.getElementSettings();

				const Swiper = elementorFrontend.utils.swiper;
    			this.swiper = await new Swiper(this.elements.$swiperContainer, this.getSwiperOptions());

				this.thumbsNav();

				await this.initThumbsCarousel( Swiper );
				this.bindThumbsCarousel();

				/*
				 * params.autoplay.enabled, not the widget setting: it is true only where the
				 * autoplay actually started, so never in the editor and never once reduced
				 * motion has held it back. Swiper's autoplay.start() has no such guard, so a
				 * resume bound on a slider that is not autoplaying would start one.
				 */
				const autoplayStarted = !! ( this.swiper.params.autoplay && this.swiper.params.autoplay.enabled );

				if ( autoplayStarted && 'yes' === elementSettings.pause_on_hover ) {
					this.togglePauseOnHover(true);
				}

				if ( autoplayStarted ) {
					this.togglePauseOnFocus(true);
				}

				if ( 'yes' === elementSettings.equal_height_boxes || 'yes' === elementSettings.equal_height ) {
					this.setEqualHeight();
				}

				this.syncSlideVisibility();

				// Autoplay must not speak. A position announcement answers the user having
				// navigated; on a timer it just interrupts whatever they are reading, every
				// few seconds, for as long as the page is open.
				this.userNavigated = false;

				/*
				 * Swiper emits navigationNext/navigationPrev only after slideNext() has run, by
				 * which time slideChange has already come and gone, so a flag set from those
				 * events was always one move behind and the first arrow press announced
				 * nothing. paginationUpdate was worse: it fires on autoplay moves too. Marking
				 * the intent on the way down, in the capture phase, gets there first.
				 */
				const controls = '.pp-slider-arrow:not(.pp-image-slider-thumbs-arrow), .swiper-pagination-bullet, .pp-image-slider-thumb-item-wrap[role="button"]';

				const markNavigated = ( e ) => {
					const onControl = e.target.closest && e.target.closest( controls );

					if ( 'keydown' === e.type ) {
						const isSliderArrowKey = ( 'ArrowLeft' === e.key || 'ArrowRight' === e.key ) && e.target === this.elements.$swiperContainer[0];
						const isThumbArrowKey  = onControl && [ 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End' ].indexOf( e.key ) > -1;
						const isActivation     = onControl && ( 'Enter' === e.key || ' ' === e.key );

						if ( ! isSliderArrowKey && ! isThumbArrowKey && ! isActivation ) {
							return;
						}
					} else if ( ! onControl ) {
						return;
					}

					this.userNavigated = true;
				};

				this.$element[0].addEventListener( 'pointerdown', markNavigated, true );
				this.$element[0].addEventListener( 'keydown', markNavigated, true );

				// A swipe is deliberate too, and touchEnd lands before the transition.
				this.swiper.on( 'touchEnd', () => {
					this.userNavigated = true;
				} );

				/*
				 * The status region belongs to the widget, so take its id from the DOM rather
				 * than rebuilding it here: a widget that renders no status then leaves its
				 * arrows alone instead of pointing them at an element that does not exist.
				 */
				const statusId = this.elements.$swiperContainer.find( '.elementor-screen-only[aria-live]' ).attr( 'id' );

				if ( statusId ) {
					/*
					 * Swiper points the arrows' aria-controls at the slides wrapper, which is
					 * correct and stays; the status region only describes the result. Swiper
					 * also makes that wrapper a polite live region, which would read the new
					 * slide a second time on top of the status announcement.
					 */
					this.$element.find(
						'.elementor-swiper-button-prev, .elementor-swiper-button-next, ' +
						'.swiper-button-prev-' + this.getID() + ', .swiper-button-next-' + this.getID()
					).attr( 'aria-describedby', statusId );

					this.swiper.$wrapperEl.attr( 'aria-live', 'off' );
				}

				/*
				 * In loop mode Swiper first jumps, unseen, from a duplicate to the matching
				 * real slide, and that jump fires slideChange as well. Announcing there spent
				 * the userNavigated flag on the slide being left, so the status lagged one
				 * slide behind after every wrap.
				 */
				this.swiper.on( 'beforeLoopFix', () => {
					this.isLoopFixing = true;
				} );

				this.swiper.on( 'loopFix', () => {
					this.isLoopFixing = false;
				} );

				this.swiper.on( 'slideChange', function() {
					if ( 'yes' === elementSettings.equal_height_boxes || 'yes' === elementSettings.equal_height ) {
						this.setEqualHeight();
					}

					if ( ! this.isLoopFixing ) {
						this.announceSlidePosition();
					}
				}.bind( this ) );

				// Swiper settles which slides are on screen only once the movement is over.
				this.swiper.on( 'slideChangeTransitionEnd resize breakpoint', () => {
					this.syncSlideVisibility();
				} );

				// Keyboard Navigation. Scoped to the container itself: while it was bound to
				// every descendant, arrow keys pressed inside a slide's own links and text
				// moved the whole carousel out from under the user.
				this.elements.$swiperContainer.on( 'keydown', function( e ) {
					if ( e.target !== e.currentTarget ) return;
					if ( e.key === 'ArrowRight' ) this.swiper.slideNext();
					if ( e.key === 'ArrowLeft' ) this.swiper.slidePrev();
				}.bind( this ) );

				// No Enter/Space handler on the arrows here: Swiper's a11y module, on by default
				// in Elementor's Swiper 8, already moves the slider from those keys. Firing a
				// click as well moved it twice per press wherever the loop was off.

				this.initFancybox();
			}

			thumbsNav() {
				const elementSettings = this.getElementSettings(),
					thumbsNav         = this.$element.find( '.pp-image-slider-thumb-item-wrap' ),
					swiper            = this.swiper,
					scrollToTop       = ( undefined !== this.elements.$swiperContainer.data('scroll-top') ) ? this.elements.$swiperContainer.data('scroll-top') : '';

				// Carousel thumbnails are wired up by initThumbsCarousel()/bindThumbsCarousel() instead.
				if ( this.getThumbsElement().length ) {
					return;
				}

				if ( 'slideshow' === elementSettings.skin ) {
					thumbsNav.removeClass( 'pp-active-slide' ).attr( {
						'aria-current': 'false',
						'tabindex': '-1',
					} );
					thumbsNav.eq( 0 ).addClass( 'pp-active-slide' ).attr( {
						'aria-current': 'true',
						'tabindex': '0',
					} );

					swiper.on( 'slideChange', function () {
						const activeSlide = ( 'yes' === elementSettings.infinite_loop ) ? swiper.realIndex : swiper.activeIndex;

						thumbsNav.removeClass( 'pp-active-slide' ).attr( {
							'aria-current': 'false',
							'tabindex': '-1',
						} );
						thumbsNav.eq( activeSlide ).addClass( 'pp-active-slide' ).attr( {
							'aria-current': 'true',
							'tabindex': '0',
						} );
					} );

					const offset = elementSettings.infinite_loop ? 1 : 0;
					var container = this.elements.$swiperContainer;

					// Scroll to Top follows a click only. From the keyboard it would scroll on
					// every arrow key and carry the focused thumbnail out of view.
					const activateThumb = function( $el, fromKeyboard ) {
						swiper.slideTo( $el.index() + offset, 500 );

						if ( 'yes' === scrollToTop && ! fromKeyboard ) {
							$( 'html, body' ).animate( {
								scrollTop: ( container.offset().top - 50 ) + 'px'
							}, 100 );
						}
					};

					thumbsNav.on( 'click', function() {
						activateThumb( $( this ) );
					} );

					thumbsNav.on( 'keydown', function( e ) {
						const currentIndex = thumbsNav.index( this );
						let targetIndex = -1;

						if ( 'ArrowRight' === e.key || 'ArrowDown' === e.key ) {
							e.preventDefault();
							targetIndex = ( currentIndex + 1 ) % thumbsNav.length;
						} else if ( 'ArrowLeft' === e.key || 'ArrowUp' === e.key ) {
							e.preventDefault();
							targetIndex = ( currentIndex - 1 + thumbsNav.length ) % thumbsNav.length;
						} else if ( 'Home' === e.key ) {
							e.preventDefault();
							targetIndex = 0;
						} else if ( 'End' === e.key ) {
							e.preventDefault();
							targetIndex = thumbsNav.length - 1;
						} else if ( 'Enter' === e.key || ' ' === e.key ) {
							e.preventDefault();
							activateThumb( $( this ), true );
						}

						if ( targetIndex >= 0 ) {
							const $target = thumbsNav.eq( targetIndex );
							$target.trigger( 'focus' );
							activateThumb( $target, true );
						}
					} );
				}
			}

			getThumbsElement() {
				return this.$element.find( '.pp-image-slider-thumbs-slider' );
			}

			getThumbsSettings(prop) {
				const $thumbs = this.getThumbsElement();

				if ( ! $thumbs.length ) {
					return '';
				}

				const thumbsSettings = ( undefined !== $thumbs.data('thumbs-settings') ) ? $thumbs.data('thumbs-settings') : '';

				if ( thumbsSettings && 'undefined' !== typeof prop ) {
					return thumbsSettings[prop];
				}

				return thumbsSettings;
			}

			/**
			 * Thumbnails sit in a narrow column beside the feature image, so they run vertically there.
			 * Once the layout stacks, that column becomes full width and they have to run horizontally.
			 */
			getThumbsDirection() {
				if ( 'vertical' !== this.getThumbsSettings('direction') ) {
					return 'horizontal';
				}

				const stackOn      = this.getThumbsSettings('stack_on') || 'tablet',
					breakpoints    = elementorFrontend.config.responsive.activeBreakpoints,
					fallbackWidths = { tablet: 1024, mobile: 767 },
					stackWidth     = ( breakpoints[stackOn] ) ? breakpoints[stackOn].value : fallbackWidths[stackOn];

				return ( stackWidth && window.innerWidth <= stackWidth ) ? 'horizontal' : 'vertical';
			}

			getThumbsSlidesPerView(device) {
				const key = 'slides_per_view' + ('desktop' === device ? '' : '_' + device);
				return Math.min( this.getSlidesCount(), +this.getThumbsSettings(key) || +this.getThumbsSettings('slides_per_view') || 4 );
			}

			getThumbsSlidesToScroll(device) {
				const key = 'slides_per_group' + ('desktop' === device ? '' : '_' + device);
				return Math.min( this.getSlidesCount(), +this.getThumbsSettings(key) || 1 );
			}

			getThumbsSpaceBetween(device) {
				const key = 'space_between' + ('desktop' === device ? '' : '_' + device),
					value = this.getThumbsSettings(key);

				return ( undefined !== value && '' !== value ) ? +value : +this.getThumbsSettings('space_between') || 0;
			}

			getThumbsOptions() {
				const thumbsSettings = this.getThumbsSettings();

				const thumbsOptions = {
					direction:                  this.getThumbsDirection(),
					slidesPerView:              this.getThumbsSlidesPerView('desktop'),
					slidesPerGroup:             this.getThumbsSlidesToScroll('desktop'),
					spaceBetween:               this.getThumbsSpaceBetween('desktop'),
					watchOverflow:              true,
					watchSlidesVisibility:      true,
					watchSlidesProgress:        true,
					preventClicksPropagation:   false,
					handleElementorBreakpoints: true
				};

				if ( thumbsSettings.free_mode ) {
					// Object form keeps both the legacy and the current Swiper API happy.
					thumbsOptions.freeMode = { enabled: true };
				}

				// Nothing to loop through when every thumbnail already fits, and Swiper duplicates badly there.
				if ( thumbsSettings.loop && this.getSlidesCount() > this.getThumbsSlidesPerView('desktop') ) {
					thumbsOptions.loop = true;
					thumbsOptions.loopedSlides = this.getSlidesCount();
				}

				if ( thumbsSettings.arrows ) {
					thumbsOptions.navigation = {
						prevEl: '.pp-thumbs-button-prev-' + this.getID(),
						nextEl: '.pp-thumbs-button-next-' + this.getID(),
					};
				}

				const breakpointsSettings = {},
					breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

				Object.keys(breakpoints).forEach(breakpointName => {
					breakpointsSettings[breakpoints[breakpointName].value] = {
						slidesPerView:  this.getThumbsSlidesPerView(breakpointName),
						slidesPerGroup: this.getThumbsSlidesToScroll(breakpointName),
						spaceBetween:   this.getThumbsSpaceBetween(breakpointName),
					};
				});

				thumbsOptions.breakpoints = breakpointsSettings;

				/*
				 * Swiper's a11y module runs on this strip by default and, left alone, rewrites
				 * every thumbnail to role="group" aria-label="3 / 8" and relabels the strip
				 * arrows "Previous/Next slide". Null role and label keep the PHP markup, and
				 * the arrow messages are read back from the labels PHP printed.
				 */
				const i18n = this.getI18n(),
					$prevThumbs = this.$element.find( '.pp-thumbs-button-prev-' + this.getID() ),
					$nextThumbs = this.$element.find( '.pp-thumbs-button-next-' + this.getID() );

				thumbsOptions.a11y = {
					enabled:           true,
					slideRole:         null,
					slideLabelMessage: null,
					prevSlideMessage:  $prevThumbs.attr( 'aria-label' ) || i18n.prevSlide || 'Previous slide',
					nextSlideMessage:  $nextThumbs.attr( 'aria-label' ) || i18n.nextSlide || 'Next slide',
					firstSlideMessage: i18n.firstSlide || 'This is the first slide',
					lastSlideMessage:  i18n.lastSlide || 'This is the last slide',
				};

				return thumbsOptions;
			}

			async initThumbsCarousel(Swiper) {
				const $thumbs = this.getThumbsElement();

				if ( ! $thumbs.length ) {
					return;
				}

				this.onThumbsResize = this.onThumbsResize.bind( this );
				this.matchThumbsHeight = this.matchThumbsHeight.bind( this );

				// The markup is rendered for the desktop direction, so correct it before Swiper measures anything.
				this.setThumbsDirectionClass( this.getThumbsDirection() );
				this.matchThumbsHeight();

				this.thumbsSwiper = await new Swiper( $thumbs, this.getThumbsOptions() );

				// The strip only scrolls; the thumbnails' aria-current says which one is showing.
				if ( this.thumbsSwiper.$wrapperEl ) {
					this.thumbsSwiper.$wrapperEl.attr( 'aria-live', 'off' );
				}

				this.observeFeatureImageHeight();

				// Bound by reference rather than by namespace so a re-render cannot unbind its replacement.
				elementorFrontend.elements.$window.on( 'resize', this.onThumbsResize );
			}

			/**
			 * Sole owner of the thumbnail strip's movement. Swiper's thumbs module does the same job, but
			 * running both means two slideTo calls per change, each interrupting the other's animation.
			 */
			bindThumbsCarousel() {
				const mainSwiper = this.swiper,
					thumbsSwiper = this.thumbsSwiper;

				if ( ! mainSwiper || ! thumbsSwiper ) {
					return;
				}

				const scrollToTop = !! this.getThumbsSettings('scroll_top'),
					$container    = this.elements.$swiperContainer;

				this.scrollThumbsIntoView = this.scrollThumbsIntoView.bind( this );
				this.lastThumbRealIndex = mainSwiper.realIndex;

				// Looping duplicates slides, so every copy of the active thumbnail gets highlighted.
				this.syncActiveThumb = () => {
					const slides = thumbsSwiper.slides;

					for ( let index = 0; index < slides.length; index++ ) {
						const isActive = this.getSlideRealIndex( slides[index], index ) === mainSwiper.realIndex;
						$( slides[index] )
							.toggleClass( 'pp-active-slide', isActive )
							.attr( {
								'aria-current': isActive ? 'true' : 'false',
								'tabindex': isActive ? '0' : '-1',
							} );
					}
				};

				this.syncActiveThumb();

				const handleThumbActivation = ( target, fromKeyboard ) => {
					const realIndex = this.getSlideRealIndex( target, $( target ).index() );

					mainSwiper.slideTo(
						mainSwiper.params.loop ? this.getNearestSlideIndex( mainSwiper, realIndex ) : realIndex
					);

					// Click only: from the keyboard it would carry the focused thumbnail out of view.
					if ( scrollToTop && ! fromKeyboard ) {
						$( 'html, body' ).animate( {
							scrollTop: ( $container.offset().top - 50 ) + 'px'
						}, 100 );
					}
				};

				// Delegated, because Swiper rebuilds its loop duplicates whenever a breakpoint changes.
				this.getThumbsElement().on( 'click.ppThumbs', '.swiper-wrapper > .swiper-slide', ( event ) => {
					handleThumbActivation( event.currentTarget );
				} );

				this.getThumbsElement().on( 'keydown.ppThumbs', '.swiper-wrapper > .swiper-slide', ( event ) => {
					const $slides = this.getThumbsElement().find( '.swiper-wrapper > .swiper-slide' );
					const currentIndex = $slides.index( event.currentTarget );
					let targetIndex = -1;

					if ( 'ArrowRight' === event.key || 'ArrowDown' === event.key ) {
						event.preventDefault();
						targetIndex = ( currentIndex + 1 ) % $slides.length;
					} else if ( 'ArrowLeft' === event.key || 'ArrowUp' === event.key ) {
						event.preventDefault();
						targetIndex = ( currentIndex - 1 + $slides.length ) % $slides.length;
					} else if ( 'Home' === event.key ) {
						event.preventDefault();
						targetIndex = 0;
					} else if ( 'End' === event.key ) {
						event.preventDefault();
						targetIndex = $slides.length - 1;
					} else if ( 'Enter' === event.key || ' ' === event.key ) {
						event.preventDefault();
						handleThumbActivation( event.currentTarget, true );
					}

					if ( targetIndex >= 0 ) {
						const $target = $slides.eq( targetIndex );
						$target.trigger( 'focus' );
						handleThumbActivation( $target[0], true );
					}
				} );

				mainSwiper.on( 'slideChange', () => {
					this.syncActiveThumb();
					this.scrollThumbsIntoView();
				});
			}

			getSlideRealIndex(slide, fallback) {
				const realIndex = slide.getAttribute( 'data-swiper-slide-index' );

				return ( null === realIndex ) ? fallback : parseInt( realIndex, 10 );
			}

			/**
			 * DOM position of the slide for a real index. Working in DOM positions rather than real indexes
			 * is what keeps a looping strip travelling the short way instead of unwinding back across
			 * itself. Pass `forward` when following a moving slider: the copy nearest in absolute terms can
			 * sit behind the view once the copies ahead run out, which reads as a backwards lurch.
			 */
			getNearestSlideIndex(swiper, realIndex, forward) {
				const current = swiper.activeIndex,
					slides    = swiper.slides;

				let nearest = -1,
					ahead   = -1,
					behind  = -1;

				for ( let index = 0; index < slides.length; index++ ) {
					if ( this.getSlideRealIndex( slides[index], index ) !== realIndex ) {
						continue;
					}

					if ( index >= current && ( ahead < 0 || index < ahead ) ) {
						ahead = index;
					}

					if ( index <= current && ( behind < 0 || index > behind ) ) {
						behind = index;
					}

					if ( nearest < 0 || Math.abs( index - current ) < Math.abs( nearest - current ) ) {
						nearest = index;
					}
				}

				if ( true === forward && ahead >= 0 ) {
					return ahead;
				}

				if ( false === forward && behind >= 0 ) {
					return behind;
				}

				return ( nearest < 0 ) ? realIndex : nearest;
			}

			/**
			 * Keep the active thumbnail in view, with a one-thumb look-ahead in the direction of travel.
			 */
			scrollThumbsIntoView() {
				const thumbs = this.thumbsSwiper;

				if ( ! thumbs || thumbs.destroyed ) {
					return;
				}

				const realIndex = this.swiper.realIndex,
					total       = this.getSlidesCount(),
					previous    = this.lastThumbRealIndex;

				// Which way the feature image just moved, counted the short way round so that stepping off
				// the end still reads as forward rather than as a jump back to the start.
				let forward;

				if ( undefined !== previous && previous !== realIndex && total > 1 ) {
					forward = ( ( realIndex - previous + total ) % total ) <= total / 2;
				}

				this.lastThumbRealIndex = realIndex;

				const index    = thumbs.params.loop
						? this.getNearestSlideIndex( thumbs, realIndex, forward )
						: realIndex,
					perView    = Math.ceil( thumbs.params.slidesPerView ) || 1,
					maxIndex   = Math.max( thumbs.slides.length - perView, 0 ),
					firstVisible = thumbs.activeIndex,
					lastVisible  = firstVisible + perView - 1;

				let newIndex;

				if ( index >= lastVisible ) {
					newIndex = this.snapThumbIndex( Math.min( index - perView + 2, maxIndex ), true );
				} else if ( index <= firstVisible ) {
					newIndex = this.snapThumbIndex( Math.max( index - 1, 0 ), false );
				} else {
					return;
				}

				// The feature image loops but the strip does not, so wrapping past either end asks the strip
				// to travel its whole length at once. Animating that reads as a lurch, where a jump is over
				// before it registers. Ordinary steps still slide.
				const isJump = Math.abs( newIndex - firstVisible ) > perView;

				thumbs.slideTo( newIndex, isJump ? 0 : undefined );
			}

			/**
			 * Swiper floors every slideTo onto a group boundary, so with more than one thumbnail per scroll
			 * a forward nudge lands short while the mirrored backward one overshoots, and the same step
			 * feels different each way. Round towards the direction of travel so both move alike.
			 */
			snapThumbIndex(index, forward) {
				const thumbs = this.thumbsSwiper,
					group    = thumbs.params.slidesPerGroup || 1;

				if ( group < 2 ) {
					return index;
				}

				const snapped = forward
					? Math.ceil( index / group ) * group
					: Math.floor( index / group ) * group;

				return Math.max( 0, Math.min( snapped, Math.max( thumbs.slides.length - 1, 0 ) ) );
			}

			setThumbsDirectionClass(direction) {
				this.$element.find( '.pp-image-slider-thumbs' )
					.removeClass( 'pp-image-slider-thumbs-horizontal pp-image-slider-thumbs-vertical' )
					.addClass( 'pp-image-slider-thumbs-' + direction );

				if ( 'vertical' !== direction ) {
					this.thumbsMatchedHeight = null;
					this.getThumbsElement().css( 'height', '' );
				}
			}

			/**
			 * The feature image settles its height late — cached images report no layout at handler init, and in
			 * the editor the widget is re-rendered over AJAX. Watching the box keeps the vertical strip in step,
			 * where a one-off measurement leaves it collapsed.
			 */
			observeFeatureImageHeight() {
				if ( 'undefined' === typeof ResizeObserver || ! this.elements.$swiperContainer.length ) {
					return;
				}

				this.thumbsResizeObserver = new ResizeObserver( this.matchThumbsHeight );
				this.thumbsResizeObserver.observe( this.elements.$swiperContainer[0] );
			}

			matchThumbsHeight() {
				if ( ! this.getThumbsSettings('match_height') || 'vertical' !== this.getThumbsDirection() ) {
					return;
				}

				const height = this.elements.$swiperContainer.outerHeight();

				if ( ! height || height === this.thumbsMatchedHeight ) {
					return;
				}

				this.thumbsMatchedHeight = height;
				this.getThumbsElement().css( 'height', height + 'px' );

				if ( ! this.thumbsSwiper ) {
					return;
				}

				// Recalculating mid-transition snaps the strip out of its animation, and a feature image
				// of changing height fires the observer on exactly those frames. Let it settle first.
				if ( this.thumbsSwiper.animating ) {
					this.thumbsSwiper.once( 'transitionEnd', () => {
						if ( this.thumbsSwiper && ! this.thumbsSwiper.destroyed ) {
							this.thumbsSwiper.update();
						}
					});
				} else {
					this.thumbsSwiper.update();
				}
			}

			onThumbsResize() {
				if ( ! this.thumbsSwiper ) {
					return;
				}

				const direction = this.getThumbsDirection();

				if ( direction !== this.thumbsSwiper.params.direction ) {
					this.setThumbsDirectionClass( direction );
					this.thumbsSwiper.changeDirection( direction );
				}

				this.matchThumbsHeight();

				// A breakpoint change can rebuild the loop duplicates, dropping the active highlight with them.
				if ( this.syncActiveThumb ) {
					this.syncActiveThumb();
				}
			}

			togglePauseOnHover(toggleOn) {
				if (toggleOn) {
					this.$element.on({
						mouseenter: () => {
							if (this.swiper && this.swiper.autoplay && this.swiper.autoplay.running) {
								this.swiper.autoplay.stop();
							}
						},
						mouseleave: () => {
							// Focus inside still holds the pause. Resuming here would move the slide
							// on and make it inert, dropping that focus to the body.
							if ( this.$element[0].contains( document.activeElement ) ) {
								return;
							}

							if (this.swiper && this.swiper.autoplay && !this.swiper.autoplay.running) {
								this.swiper.autoplay.start();
							}
						}
					});
				} else {
					this.$element.off('mouseenter mouseleave');
				}
			}

			togglePauseOnFocus(toggleOn) {
				if (toggleOn) {
					this.$element.on({
						focusin: () => {
							if (this.swiper && this.swiper.autoplay && this.swiper.autoplay.running) {
								this.swiper.autoplay.stop();
							}
						},
						focusout: ( e ) => {
							// Moving between two controls inside the widget is not leaving it.
							if ( e.relatedTarget && this.$element[0].contains( e.relatedTarget ) ) {
								return;
							}

							// A pointer still resting on the widget holds the hover pause.
							if ( 'yes' === this.getElementSettings( 'pause_on_hover' ) && this.$element[0].matches( ':hover' ) ) {
								return;
							}

							if (this.swiper && this.swiper.autoplay && !this.swiper.autoplay.running) {
								this.swiper.autoplay.start();
							}
						}
					});
				} else {
					this.$element.off('focusin focusout');
				}
			}

			setEqualHeight() {
				const swiperOptions = this.getSwiperOptions(),
					effect          = swiperOptions.effect,
					activeSlide     = this.elements.$swiperContainer.find( '.swiper-slide-visible' );

				let maxHeight = -1;

				activeSlide.each( function() {
					let containerHeight = $(this).outerHeight();

					if ( maxHeight < containerHeight ) {
						maxHeight = containerHeight;
					}
				});

				activeSlide.each( function() {
					if ( 'coverflow' === effect ) {
						$(this).css({ height: maxHeight } );
					} else {
						$(this).animate({ height: maxHeight }, { duration: 200, easing: 'linear' });
					}
				});
			}

			initFancybox() {
				const sliderId       = this.elements.$swiperContainer.attr( 'id' ),
					fancyboxSettings = this.elements.$swiperContainer.data('fancybox-settings'),
					linkSelector     = '.pp-image-slider-slide-link[data-fancybox="' + sliderId + '"]',
					lightboxSelector = '.pp-swiper-slide:not(.swiper-slide-duplicate) ' + linkSelector;

				// A trigger with no URL makes fancybox open the slide markup itself as
				// inline content and put it back hidden on close, so the slide image
				// disappears. Fancybox binds to [data-fancybox] globally, so those
				// triggers have the attribute dropped rather than merely left unbound —
				// looped slides included, since their clones carry it too.
				$( linkSelector ).filter( function() {
					return ! $( this ).attr( 'data-src' );
				} ).removeAttr( 'data-fancybox' );

				// Elementor's lightbox: links carry elementor-clickable instead of data-fancybox.
				this.elements.$swiperContainer.off( 'click.ppCarouselLightboxFocus' ).on( 'click.ppCarouselLightboxFocus', '.pp-image-slider-slide-link.elementor-clickable', ( event ) => {
					this.returnFocusAfterElementorLightbox( event.currentTarget );
				} );

				if ( $(lightboxSelector).length > 0 ) {
					const escNamespace = 'keydown.ppCarouselLightbox' + this.getID();

					$(lightboxSelector).fancybox( $.extend( true, {}, fancyboxSettings, {
						// With keyboard navigation off, fancybox ignores Esc too, which would
						// leave a keyboard user with no way out of a focus-trapped dialog.
						// Bound on window so fancybox's own document handler, which reads the
						// current slide, has already run before the instance is closed.
						onInit: ( instance ) => {
							if ( fancyboxSettings && false === fancyboxSettings.keyboard ) {
								$( window ).off( escNamespace ).on( escNamespace, ( event ) => {
									if ( 'Escape' === event.key || 'Esc' === event.key ) {
										event.preventDefault();
										instance.close( event );
									}
								} );
							}
						},
						afterClose: ( instance ) => {
							$( window ).off( escNamespace );
							this.restoreLightboxFocus( instance );
						},
					} ) );
				}
			}

			/**
			 * Elementor's lightbox closes itself on Esc but leaves focus on <body>.
			 * Its modal is one shared dialog, so the hide listener removes itself.
			 *
			 * @since x.x.x
			 *
			 * @param {HTMLElement} trigger The link that opened the lightbox.
			 */
			returnFocusAfterElementorLightbox( trigger ) {
				const openLightbox = trigger.getAttribute( 'data-elementor-open-lightbox' );

				if ( this.isEdit || ! elementorFrontend.utils ) {
					return;
				}

				// Same test Elementor uses, so a link that does not open the lightbox
				// never leaves a listener behind for some later one.
				if ( 'no' === openLightbox || ( 'yes' !== openLightbox && ! elementorFrontend.getKitSettings( 'global_image_lightbox' ) ) ) {
					return;
				}

				Promise.resolve( elementorFrontend.utils.lightbox ).then( ( lightbox ) => {
					const modal = lightbox && lightbox.getModal ? lightbox.getModal() : null;

					if ( ! modal || ! modal.on ) {
						return;
					}

					const onHide = () => {
						modal.off( 'hide', onHide );
						this.restoreLightboxFocus( { $trigger: $( trigger ) }, modal.getElements( 'widget' )[0] );
					};

					modal.on( 'hide', onHide );
				} ).catch( () => {} );
			}

			/**
			 * Fancybox puts focus back on the current slide's link, which is inert when
			 * that slide is off screen, so focus silently falls to <body>. Fall back to
			 * the link that opened the lightbox, then to the slider itself.
			 *
			 * @since x.x.x
			 *
			 * @param {Object}      instance Fancybox instance, or an object with $trigger.
			 * @param {HTMLElement} overlay  The closing overlay, if focus may still be in it.
			 */
			restoreLightboxFocus( instance, overlay ) {
				const $trigger = instance && instance.$trigger;

				// afterClose runs before fancybox's own backFocus step.
				setTimeout( () => {
					const active = document.activeElement;

					if ( active && active !== document.body && ! ( overlay && overlay.contains( active ) ) ) {
						return;
					}

					const candidates = [
						$trigger && $trigger[0],
						this.elements.$swiperContainer[0],
					];

					for ( let i = 0; i < candidates.length; i++ ) {
						const el = candidates[ i ];

						if ( ! el || ! document.body.contains( el ) || ( el.closest && el.closest( '[inert]' ) ) ) {
							continue;
						}

						el.focus( { preventScroll: true } );

						if ( document.activeElement === el ) {
							return;
						}
					}
				}, 0 );
			}

			onDestroy() {
				// An own, bound copy once the carousel has initialised; otherwise nothing matches.
				elementorFrontend.elements.$window.off( 'resize', this.onThumbsResize );
				$( window ).off( 'keydown.ppCarouselLightbox' + this.getID() );

				if ( this.thumbsResizeObserver ) {
					this.thumbsResizeObserver.disconnect();
					this.thumbsResizeObserver = null;
				}

				if ( this.thumbsSwiper ) {
					this.thumbsSwiper.destroy( true, true );
					this.thumbsSwiper = null;
				}

				super.onDestroy();
			}
		}

		const widgets = {
			'business-reviews':     [ 'default', 'classic', 'card' ],
			'content-ticker':       '',
			'image-slider':         '',
			'info-box-carousel':    '',
			'logo-carousel':        '',
			'magazine-slider':      '',
			'team-member-carousel': '',
			'woo-categories':       '',
		}

		$.each( widgets, function( widget, skin ) {
			if ( 'object' ===  typeof skin ) {
				$.each( skin, function( index, wSkin ) {
					elementorFrontend.elementsHandler.attachHandler( 'pp-' + widget, PpCarouselWidget, wSkin );
				});
			} else {
				elementorFrontend.elementsHandler.attachHandler( 'pp-' + widget, PpCarouselWidget );
			}
		});
	} );
})(jQuery);