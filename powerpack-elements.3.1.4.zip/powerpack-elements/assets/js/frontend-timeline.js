(function($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class TimelineWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						timeline: '.pp-timeline',
						verticalTimeline: '.pp-timeline-vertical',
						items: '.pp-timeline-vertical .pp-timeline-item',
						swiperSlide: '.pp-timeline-item',
						connector: '.pp-timeline-vertical .pp-timeline-connector',
						progressBar: '.pp-timeline-vertical .pp-timeline-connector-inner',
						markerClass: '.pp-timeline-vertical .pp-timeline-marker-wrapper',
						carousel: '.pp-timeline-horizontal .pp-timeline-items',
						sliderWrap: '.pp-timeline-wrapper',
						sliderNav: '.pp-timeline-navigation',
						status: '.pp-timeline-status',
					},
					slidesToShow: {
						widescreen: 3,
						desktop: 3,
						laptop: 3,
						tablet_extra: 3,
						tablet: 2,
						mobile_extra: 2,
						mobile: 1
					}
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$timeline: this.$element.find( selectors.timeline ),
					$verticalTimeline: this.$element.find( selectors.verticalTimeline ),
					$items: this.$element.find( selectors.items ),
					$swiperSlide: this.$element.find( selectors.swiperSlide ),
					$connector: this.$element.find( selectors.connector ),
					$progressBar: this.$element.find( selectors.progressBar ),
					$markerClass: this.$element.find( selectors.markerClass ),
					$carousel: this.$element.find( selectors.carousel ),
					$sliderWrap: this.$element.find( selectors.sliderWrap ),
					$sliderNav: this.$element.find( selectors.sliderNav ),
				};
			}

			/**
			 * Localized strings for the carousel's accessibility labels.
			 *
			 * @since x.x.x
			 */
			getI18n() {
				return ( typeof ppTimelineScript !== 'undefined' && ppTimelineScript.i18n ) || {};
			}

			getSlidesCount() {
				const selectors = this.getSettings('selectors');
				// Swiper's loop clones are not items of their own.
				const $slides = this.$element.find( selectors.swiperSlide ).not( '.swiper-slide-duplicate' );
				return $slides.length || ( this.elements.$swiperSlide ? this.elements.$swiperSlide.length : 0 );
			}

			getDeviceSlidesPerView(device) {
				const slidesPerViewKey = 'columns' + ('desktop' === device ? '' : '_' + device);
				let spv = +this.getElementSettings(slidesPerViewKey);

				if ( ! spv ) {
					if ( 'widescreen' === device || 'laptop' === device || 'tablet_extra' === device ) {
						spv = +this.getElementSettings('columns');
					} else if ( 'mobile_extra' === device ) {
						spv = +this.getElementSettings('columns_tablet');
					}
				}

				const target = spv || this.getSettings('slidesToShow')[device] || 3;
				const count = this.getSlidesCount();
				return count ? Math.min(count, target) : target;
			}

			getDeviceSlidesToScroll(device) {
				const slidesToScrollKey = 'slides_to_scroll' + ('desktop' === device ? '' : '_' + device);
				let sts = +this.getElementSettings(slidesToScrollKey);

				if ( ! sts ) {
					if ( 'widescreen' === device || 'laptop' === device || 'tablet_extra' === device ) {
						sts = +this.getElementSettings('slides_to_scroll');
					} else if ( 'mobile_extra' === device ) {
						sts = +this.getElementSettings('slides_to_scroll_tablet');
					}
				}

				const target = sts || 1;
				const count = this.getSlidesCount();
				return count ? Math.min(count, target) : target;
			}

			getDeviceSpaceBetween(device) {
				// Elementor can save the size as a string, which Swiper would concatenate.
				return parseFloat( elementorFrontend.utils.controls.getResponsiveControlValue(this.getElementSettings(), 'items_spacing', 'size', device) ) || 0;
			}

			/**
			 * Whether the visitor asked the OS to reduce motion.
			 *
			 * An auto-rotating carousel is exactly the kind of movement that
			 * setting is meant to stop (WCAG 2.2.2).
			 */
			prefersReducedMotion() {
				return window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
			}

			getSwiperOptions() {
				const elementSettings = this.getElementSettings(),
					i18n = this.getI18n();

				const swiperOptions = {
					slidesPerView:              this.getDeviceSlidesPerView('desktop'),
					slidesPerGroup:             this.getDeviceSlidesToScroll('desktop'),
					spaceBetween:               this.getDeviceSpaceBetween(),
					loop:                       'yes' === elementSettings.infinite_loop,
					centeredSlides:             'yes' === elementSettings.center_mode,
					speed:                      elementSettings.slider_speed.size,
					watchSlidesVisibility:      true,
					watchSlidesProgress:        true,
					preventClicksPropagation:   false,
					slideToClickedSlide:        true,
					handleElementorBreakpoints: true,
					// Swiper only reads the *Message keys. Spreading the localized
					// strings in under their own names left every label in English.
					a11y: {
						enabled:                    true,
						prevSlideMessage:           i18n.prevSlide  || 'Previous slide',
						nextSlideMessage:           i18n.nextSlide  || 'Next slide',
						firstSlideMessage:          i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:           i18n.lastSlide  || 'This is the last slide',
						paginationBulletMessage:    i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:          i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						slideRole:                  'group',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide',
					}
				};

				if ( 'yes' === elementSettings.autoplay && ! this.prefersReducedMotion() ) {
					swiperOptions.autoplay = {
						delay: elementSettings.autoplay_speed,
						disableOnInteraction: 'yes' === elementSettings.pause_on_hover,
						pauseOnMouseEnter: 'yes' === elementSettings.pause_on_hover
					};
				}

				const breakpointsSettings = {},
					breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

				Object.keys(breakpoints).forEach(breakpointName => {
					breakpointsSettings[breakpoints[breakpointName].value] = {
						slidesPerView: this.getDeviceSlidesPerView(breakpointName),
						slidesPerGroup: this.getDeviceSlidesToScroll(breakpointName),
					};

					if ( this.getDeviceSpaceBetween(breakpointName) ) {
						breakpointsSettings[breakpoints[breakpointName].value].spaceBetween = this.getDeviceSpaceBetween(breakpointName);
					}
				});

				swiperOptions.breakpoints = breakpointsSettings;

				return swiperOptions;
			}

			updateDirection(currentDeviceMode, elementSettings) {
				const directionMapping = {
					'widescreen': elementSettings.direction_widescreen,
					'desktop': elementSettings.direction,
					'laptop': elementSettings.direction_laptop,
					'tablet_extra': elementSettings.direction_tablet_extra,
					'tablet': elementSettings.direction_tablet,
					'mobile_extra': elementSettings.direction_mobile_extra,
					'mobile': elementSettings.direction_mobile,
				};

				return directionMapping[currentDeviceMode] || elementSettings.direction;
			}

			onElementChange( propertyName ) {
				const elementSettings = this.getElementSettings();

				if ( ! propertyName ) {
					return;
				}

				if ( propertyName.indexOf( 'columns' ) !== -1 ||
				     propertyName.indexOf( 'slides_to_scroll' ) !== -1 ||
				     propertyName.indexOf( 'items_spacing' ) !== -1 ||
				     'layout' === propertyName ||
				     'infinite_loop' === propertyName ||
				     'center_mode' === propertyName ||
				     'autoplay' === propertyName ||
				     'autoplay_speed' === propertyName ||
				     'pause_on_hover' === propertyName ||
				     'dots' === propertyName ||
				     'arrows' === propertyName ||
				     'equal_height' === propertyName
				) {
					if ( 'horizontal' === elementSettings.layout ) {
						const selectors = this.getSettings( 'selectors' );
						if ( this.$element.find( selectors.carousel ).length ) {
							this.initHorizontalLayout();
						}
					} else if ( 'vertical' === elementSettings.layout ) {
						this.destroySwipers();
						this.initVerticalLayout();
					}
					return;
				}

				if ( 'vertical' === elementSettings.layout && propertyName.indexOf( 'direction' ) !== -1 ) {
					const currentDeviceMode = elementorFrontend.getCurrentDeviceMode();
					const elementDirection = this.updateDirection( currentDeviceMode, elementSettings );
					this.updateTimelineDirection( currentDeviceMode, elementDirection );
				}
			}

			bindEvents() {
				const elementSettings = this.getElementSettings();

				if ( 'vertical' === elementSettings.layout ) {
					this.initVerticalLayout();
				} else if ( 'horizontal' === elementSettings.layout ) {
					this.initHorizontalLayout();
				}

				this.setPostsCount(1);

				this.initLoadMore();

				this.initNumberedPagination();

				this.initInfiniteScroll();

				this.initKeyboardControls();

				this.initRevealOnFocus();
			}

			/**
			 * Release everything bound outside this widget's own element.
			 *
			 * The base handler's onDestroy() calls this, so it runs when the
			 * element goes away and between editor re-renders. Without it every
			 * render left behind another window scroll handler, another resize
			 * handler and a live Swiper instance.
			 */
			unbindEvents() {
				const ns = this.getEventNamespace();

				// Two namespaces: jQuery treats "<ns>-infinite" as its own.
				$(window).off( ns ).off( ns + '-infinite' );

				clearTimeout( this.equalHeightTimer );

				this.$element.off( '.ppTimelineAutoplay' );
				this.unbindNavigationIntent();

				this.destroySwipers();
			}

			destroySwipers() {
				[ 'timelineSwiper', 'timelineNavSwiper' ].forEach( ( key ) => {
					const swiper = this[ key ];

					if ( swiper && 'function' === typeof swiper.destroy && ! swiper.destroyed ) {
						swiper.destroy( true, true );
					}

					this[ key ] = null;
				} );
			}

			/**
			 * Make the controls Swiper does not wire up operable by keyboard.
			 *
			 * The navigation markers are focusable divs with role="button" that
			 * Swiper only knows as slides, so Enter and Space did nothing on them.
			 * The arrows are left alone: Swiper's a11y module already binds Enter
			 * and Space on them, and a second handler moved the carousel twice.
			 * Load More is an anchor, which only activates on Enter by itself.
			 */
			initKeyboardControls() {
				this.$element.on( 'keydown', '.pp-timeline-nav-item', ( e ) => {
					if ( 'Enter' !== e.key && ' ' !== e.key && 'Spacebar' !== e.key ) {
						return;
					}

					e.preventDefault();
					this.goToNavItem( e.currentTarget );
				} );

				this.$element.on( 'keydown', '.pp-post-load-more', function(e) {
					if ( ' ' !== e.key && 'Spacebar' !== e.key ) {
						return;
					}

					e.preventDefault();
					$(this).trigger( 'click' );
				} );
			}

			/**
			 * Move the carousel to the card a navigation marker stands for.
			 *
			 * Swiper moves to a clicked marker from its own pointer handlers only:
			 * slideToClickedSlide runs off touchend, and clickedIndex is set there
			 * too. A synthetic click carries neither, so the keyboard drives the
			 * API itself.
			 *
			 * @since x.x.x
			 *
			 * @param {Element} item The navigation marker.
			 */
			goToNavItem( item ) {
				if ( ! this.timelineSwiper ) {
					return;
				}

				const attr  = item.getAttribute( 'data-swiper-slide-index' );
				const index = ( null !== attr ) ? parseInt( attr, 10 ) : $( item ).index();

				if ( isNaN( index ) ) {
					return;
				}

				this.userNavigated = true;

				if ( this.timelineSwiper.params.loop ) {
					this.timelineSwiper.slideToLoop( index );
				} else {
					this.timelineSwiper.slideTo( index );
				}
			}

			/**
			 * Reveal a card as soon as keyboard focus reaches it.
			 *
			 * Cards waiting on their scroll animation are transparent, and a
			 * keyboard user tabbing ahead of the scroll would otherwise focus a
			 * link nobody can see.
			 *
			 * @since x.x.x
			 */
			initRevealOnFocus() {
				this.$element.on( 'focusin', '.pp-timeline-item-hidden', function() {
					$(this).removeClass( 'pp-timeline-item-hidden' ).addClass( 'bounce-in' );
				} );
			}

			/**
			 * An event namespace unique to this widget instance.
			 *
			 * Window-level handlers are bound with it so they can be removed
			 * again in unbindEvents() — without it, every editor re-render and
			 * every AJAX page load left another scroll and resize handler behind.
			 */
			getEventNamespace() {
				return '.ppTimeline' + this.getID();
			}

			initVerticalLayout() {
				const elementSettings = this.getElementSettings(),
					ns = this.getEventNamespace();

				let currentDeviceMode = elementorFrontend.getCurrentDeviceMode(),
					direction = this.updateDirection(currentDeviceMode, elementSettings);

				this.updateTimelineDirection(currentDeviceMode, direction);

				this.window = $(window);

				// Re-entrant: drop any handler from a previous call before binding.
				this.window.off('scroll' + ns + ' resize' + ns);

				this.window.on('resize' + ns, $.proxy(function() {
					currentDeviceMode = elementorFrontend.getCurrentDeviceMode();
					direction = this.updateDirection(currentDeviceMode, elementSettings);

					this.updateTimelineDirection(currentDeviceMode, direction);

					this.winHeight = this.window.height();
					this.scrollTop = this.window.scrollTop();

					this.requestAnimation();
				}, this));

				this.winHeight = this.window.height();
				this.scrollTop = this.window.scrollTop();

				this.window.on('scroll' + ns, $.proxy(function() {
					this.scrollTop = this.window.scrollTop();

					// revealItems() reads .offset() for every item, so it is
					// driven from the rAF callback rather than run per scroll event.
					this.requestAnimation();
				}, this));

				this.requestAnimation();
				this.revealItems();
			}

			initHorizontalLayout() {
				this.initCarousel();
			}

			updateTimelineDirection(deviceMode, elementDirection) {
				if (undefined !== elementDirection) {
					const $timeline = this.elements.$timeline;
					$timeline.removeClass('pp-timeline-left pp-timeline-center pp-timeline-right');
					$timeline.addClass('pp-timeline-' + elementDirection);
				}
			}

			requestAnimation() {
				if (!this.isAnimating) {
					requestAnimationFrame(this.reboot.bind(this));
				}
				this.isAnimating = true;
			}

			revealItems() {
				this.animationClass = 'bounce-in';

				const $hidden = this.elements.$items.filter('.pp-timeline-item-hidden');

				if ( !$hidden.length ) {
					return;
				}

				// Hoisted out of the loop: it was a forced layout per item.
				const threshold = this.scrollTop + ( this.window || $(window) ).outerHeight() * 0.95;

				// Read every offset first, then write — interleaving them made
				// the browser re-layout once per item.
				const toReveal = [];

				$hidden.each((index, item) => {
					if ($(item).offset().top <= threshold) {
						toReveal.push(item);
					}
				});

				if ( toReveal.length ) {
					$(toReveal).removeClass('pp-timeline-item-hidden').addClass(this.animationClass);
				}
			}

			refreshTimelineItems() {
				const selectors = this.getSettings('selectors');

				// Refresh items collection. New items arrive from the server already
				// carrying pp-timeline-item-hidden; the ones already revealed are
				// left as they are rather than being hidden again on every load.
				this.elements.$items = this.$element.find(selectors.items);

				// Reset scroll values
				this.winHeight = $(window).height();
				this.scrollTop = $(window).scrollTop();

				// Trigger reveal — reboot() calls revealItems() for us.
				this.requestAnimation();
			}

			setup() {
				const $timeline  = this.elements.$verticalTimeline;
				const $items     = $timeline.find('.pp-timeline-item');
				const $connector = $timeline.find('.pp-timeline-connector');

				if ( !$items.length || !$connector.length ) {
					return;
				}

				const $firstItem = $items.first();
				const $lastItem  = $items.last();

				if ( !$firstItem.length || !$lastItem.length ) {
					return;
				}

				const $firstMarker = $firstItem.find('.pp-timeline-marker-wrapper');
				const $lastMarker  = $lastItem.find('.pp-timeline-marker-wrapper');

				if ( !$firstMarker.length || !$lastMarker.length ) {
					return;
				}

				const lastMarkerHeight = $lastMarker.outerHeight();

				$connector.css({
					top:
						$firstMarker.offset().top - $firstItem.offset().top,
					bottom:
						( $timeline.offset().top + $timeline.outerHeight() ) -
						$lastMarker.offset().top -
						( lastMarkerHeight / 2 ),
				});
			}

			reboot() {
				this.isAnimating = false;

				if ( this.winHeight !== this.lastWinHeight ) {
					this.setup();
				}

				this.start();

				// Batched into the animation frame with the progress work rather
				// than running on every scroll event.
				this.revealItems();
			}

			start() {
				if ( this.scrollTop !== this.lastScrollTop || this.winHeight !== this.lastWinHeight ) {
					this.lastScrollTop = this.scrollTop;
					this.lastWinHeight = this.winHeight;

					this.progress();
				}

				this.isAnimating = false;
			}

			progress() {
				const win = $(window);
				const selectors = this.getSettings('selectors');
				const $progressBar = this.$element.find(selectors.progressBar);

				if ( !$progressBar.length ) {
					return;
				}

				this.elements.$items.each((index, item) => {
					const $marker = $(item).find(this.elements.$markerClass);

					if ( !$marker.length ) {
						return;
					}

					const markerOffset = $marker.offset();

					if ( !markerOffset ) {
						return;
					}

					if ( markerOffset.top < ( this.window.scrollTop() + win.outerHeight() / 2 ) ) {
						$(item).addClass('pp-timeline-item-active');
					} else {
						$(item).removeClass('pp-timeline-item-active');
					}
				});

				const $lastItem   = this.elements.$items.last();
				const $lastMarker = $lastItem.find('.pp-timeline-marker-wrapper');

				if ( !$lastMarker.length ) {
					return;
				}

				const lastMarkerOffset = $lastMarker.offset();

				if ( !lastMarkerOffset ) {
					return;
				}

				let lastMarkerPos    = lastMarkerOffset.top;
				let lastMarkerHeight = $lastMarker.outerHeight();
				let progressPos      = ( this.window.scrollTop() - $progressBar.offset().top ) + ( win.outerHeight() / 2 );

				if (lastMarkerPos <= (this.window.scrollTop() + win.outerHeight() / 2)) {
					progressPos = lastMarkerPos - $progressBar.offset().top;
				}

				progressPos += lastMarkerHeight / 2;

				$progressBar.css('height', progressPos + 'px');
			}

			/**
			 * Whether the carousel's autoplay actually started.
			 *
			 * params.autoplay.enabled, not the widget setting: it is false where
			 * Autoplay is off and where reduced motion held it back. Swiper's
			 * autoplay.start() has no such guard of its own, so a resume handler
			 * bound on a carousel that is not autoplaying would set one running.
			 *
			 * @since x.x.x
			 */
			isAutoplayActive() {
				const swiper = this.timelineSwiper;

				return !! ( swiper && swiper.autoplay && swiper.params.autoplay && swiper.params.autoplay.enabled );
			}

			/**
			 * @since x.x.x
			 */
			stopAutoplay() {
				if ( this.isAutoplayActive() && this.timelineSwiper.autoplay.running ) {
					this.timelineSwiper.autoplay.stop();
				}
			}

			/**
			 * Resume autoplay only once both the pointer and keyboard focus have left.
			 *
			 * @since x.x.x
			 */
			maybeStartAutoplay() {
				if ( this.isHovered || this.hasFocus || ! this.isAutoplayActive() ) {
					return;
				}

				if ( ! this.timelineSwiper.autoplay.running ) {
					this.timelineSwiper.autoplay.start();
				}
			}

			/**
			 * Pause autoplay on hover and while keyboard focus is inside the widget.
			 *
			 * Pause-on-hover only helps a pointer user; without the focus pair, a
			 * keyboard user tabbing through the cards has the slider move out from
			 * under them mid-read. Both are bound only where autoplay is running.
			 *
			 * @since x.x.x
			 *
			 * @param {Object} elementSettings Widget settings.
			 */
			bindAutoplayPause( elementSettings ) {
				const ns = '.ppTimelineAutoplay';

				this.$element.off( ns );
				this.isHovered = false;
				this.hasFocus  = false;

				if ( ! this.isAutoplayActive() ) {
					return;
				}

				if ( 'yes' === elementSettings.pause_on_hover ) {
					this.$element.on( 'mouseenter' + ns, () => {
						this.isHovered = true;
						this.stopAutoplay();
					} );

					this.$element.on( 'mouseleave' + ns, () => {
						this.isHovered = false;
						this.maybeStartAutoplay();
					} );
				}

				this.$element.on( 'focusin' + ns, () => {
					this.hasFocus = true;
					this.stopAutoplay();
				} );

				this.$element.on( 'focusout' + ns, ( e ) => {
					// Focus moving between two controls inside the widget is not leaving it.
					if ( e.relatedTarget && this.$element[0].contains( e.relatedTarget ) ) {
						return;
					}

					this.hasFocus = false;
					this.maybeStartAutoplay();
				} );
			}

			/**
			 * Remember when a slide change was asked for by the user.
			 *
			 * Only those moves are announced; autoplay moves are not. The flag is
			 * set from a capture-phase listener because Swiper emits its navigation
			 * events after the slide has already changed.
			 *
			 * @since x.x.x
			 */
			bindNavigationIntent() {
				const el = this.$element[0];

				this.unbindNavigationIntent();

				this.navIntentListener = ( e ) => {
					if ( 'keydown' === e.type && 'Enter' !== e.key && ' ' !== e.key && 'Spacebar' !== e.key ) {
						return;
					}

					if ( e.target.closest && e.target.closest( '.pp-slider-arrow, .pp-timeline-nav-item, .swiper-pagination-bullet' ) ) {
						this.userNavigated = true;
					}
				};

				el.addEventListener( 'pointerdown', this.navIntentListener, true );
				el.addEventListener( 'keydown', this.navIntentListener, true );

				const flag  = () => { this.userNavigated = true; };
				const reset = () => { this.userNavigated = false; };

				[ this.timelineSwiper, this.timelineNavSwiper ].forEach( ( swiper ) => {
					if ( swiper ) {
						swiper.on( 'keyPress', flag );
						swiper.on( 'sliderFirstMove', flag );
						swiper.on( 'autoplay', reset );
					}
				} );
			}

			/**
			 * @since x.x.x
			 */
			unbindNavigationIntent() {
				if ( ! this.navIntentListener ) {
					return;
				}

				this.$element[0].removeEventListener( 'pointerdown', this.navIntentListener, true );
				this.$element[0].removeEventListener( 'keydown', this.navIntentListener, true );
				this.navIntentListener = null;
			}

			async initCarousel() {
				const elementSettings = this.getElementSettings(),
					self = this,
					ns   = this.getEventNamespace();

				// Tear down a previous instance before building another one —
				// the editor re-runs this on every settings change.
				this.destroySwipers();

				const selectors = this.getSettings( 'selectors' );
				const $carousel = this.$element.find( selectors.carousel );

				if ( ! $carousel.length ) {
					return;
				}

				this.elements.$carousel = $carousel;
				this.elements.$sliderNav = this.$element.find( selectors.sliderNav );
				this.elements.$swiperSlide = this.$element.find( selectors.swiperSlide );

				// Initialize timeline Swiper
				let swiperOptions = this.getSwiperOptions();

				// Initialize timeline Nav Swiper
				let swiperNavOptions = this.getSwiperOptions();

				// The keyboard module listens on the document. One instance is
				// enough: the controller moves the other, and binding it on both
				// moved the pair twice per key press.
				swiperOptions.keyboard = {
					enabled: true,
					onlyInViewport: true,
				};

				// The navigation items are buttons named by their date. Left to
				// its defaults, Swiper's a11y module re-labels every slide as
				// role="group" "N of M", which wiped both.
				swiperNavOptions.a11y = Object.assign( {}, swiperNavOptions.a11y, {
					slideRole: '',
					slideLabelMessage: null,
					itemRoleDescriptionMessage: null,
				} );

				// Autoplay drives the cards and the controller moves the rail with
				// them; running it on both advanced the pair twice per tick.
				delete swiperNavOptions.autoplay;

				if ( 'yes' === elementSettings.dots ) {
					swiperOptions.pagination = {
						el: `.swiper-pagination-${this.getID()}`,
						type: 'bullets',
						clickable: true
					};
				}

				// The rail has no dots. Its pagination params are left at Swiper's
				// defaults rather than set to false: the a11y module's Enter/Space
				// handler reads params.pagination.bulletClass, and with the object
				// gone it built the selector "." and threw on every arrow key press.

				if ( 'yes' === elementSettings.arrows ) {
					swiperNavOptions.navigation = {
						prevEl: '.swiper-button-prev-' + this.getID(),
						nextEl: '.swiper-button-next-' + this.getID(),
					};
				}

				if ( 'yes' === elementSettings.equal_height ) {
					// Swiper's own init event — the jQuery 'init' handler this
					// used to rely on was never triggered, so the heights were
					// only ever equalised by a later window resize.
					swiperOptions.on = {
						init: () => this.setEqualHeight(),
						slideChangeTransitionEnd: () => this.setEqualHeight(),
					};
				}

				const Swiper = elementorFrontend.utils.swiper;
				this.timelineSwiper    = await new Swiper(this.elements.$carousel, swiperOptions);

				if ( this.elements.$sliderNav && this.elements.$sliderNav.length ) {
					this.timelineNavSwiper = await new Swiper(this.elements.$sliderNav, swiperNavOptions);
				}

				if ( ! this.timelineSwiper ) {
					return;
				}

				// Connect both Swipers so they can control each other
				if ( this.timelineNavSwiper && this.timelineSwiper.controller && this.timelineNavSwiper.controller ) {
					this.timelineSwiper.controller.control = this.timelineNavSwiper;
					this.timelineNavSwiper.controller.control = this.timelineSwiper;
				}

				this.bindAutoplayPause( elementSettings );

				this.bindNavigationIntent();

				const onSlideChange = () => {
					this.syncSlideVisibility();
					this.updateNavCurrent();
					this.announceSlidePosition();
				};

				this.syncSlideVisibility();
				this.updateNavCurrent();

				// The visibility classes are applied after init on some breakpoints.
				setTimeout( () => this.syncSlideVisibility(), 50 );

				[ this.timelineSwiper, this.timelineNavSwiper ].forEach( ( swiper ) => {
					if ( swiper ) {
						swiper.on( 'slideChangeTransitionEnd', onSlideChange );
						swiper.on( 'resize', () => this.syncSlideVisibility() );
					}
				} );

				if ( 'yes' === elementSettings.equal_height ) {
					$(window).off( 'resize' + ns ).on( 'resize' + ns, function () {
						clearTimeout( self.equalHeightTimer );
						self.equalHeightTimer = setTimeout( function () {
							self.setEqualHeight();
						}, 300 );
					} );
				}
			}

			/**
			 * Take off-screen slides and loop clones out of the tab order and the
			 * accessibility tree together.
			 *
			 * inert is what removes the links and navigation markers inside from
			 * the tab order; aria-hidden alone left focus landing on content
			 * nobody could see. Slides are re-queried each time so Swiper's loop
			 * clones, created after the first lookup, are covered too.
			 *
			 * @since x.x.x
			 */
			syncSlideVisibility() {
				[ this.elements.$carousel, this.elements.$sliderNav ].forEach( ( $root ) => {
					if ( ! $root || ! $root.length ) {
						return;
					}

					const $slides = $root.find( '.swiper-slide' );

					// Hiding every slide because none is marked visible would be far
					// worse than hiding none.
					if ( ! $slides.filter( '.swiper-slide-visible' ).length ) {
						return;
					}

					$slides.each( function () {
						if ( this.classList.contains( 'swiper-slide-visible' ) ) {
							this.removeAttribute( 'aria-hidden' );
							this.removeAttribute( 'inert' );
						} else {
							this.setAttribute( 'aria-hidden', 'true' );
							this.setAttribute( 'inert', '' );
						}
					} );
				} );
			}

			/**
			 * Mark the navigation marker of the card now showing as current.
			 *
			 * @since x.x.x
			 */
			updateNavCurrent() {
				if ( ! this.timelineSwiper || ! this.elements.$sliderNav || ! this.elements.$sliderNav.length ) {
					return;
				}

				const current = this.timelineSwiper.realIndex;

				this.elements.$sliderNav.find( '.pp-timeline-nav-item' ).each( function ( index ) {
					const attr       = this.getAttribute( 'data-swiper-slide-index' );
					const slideIndex = null !== attr ? parseInt( attr, 10 ) : index;

					if ( slideIndex === current ) {
						this.setAttribute( 'aria-current', 'true' );
					} else {
						this.removeAttribute( 'aria-current' );
					}
				} );
			}

			/**
			 * Announce the slide position, but only after a move the user asked for.
			 *
			 * Swiper's own live region only speaks from its Enter/Space handler,
			 * so pointer, swipe and marker navigation announced nothing.
			 *
			 * @since x.x.x
			 */
			announceSlidePosition() {
				if ( ! this.userNavigated || ! this.timelineSwiper ) {
					return;
				}

				this.userNavigated = false;

				const format = this.getI18n().slideStatus || 'Showing Slide %1$s of %2$s';

				this.announce(
					format
						.replace( '%1$s', this.timelineSwiper.realIndex + 1 )
						.replace( '%2$s', this.getSlidesCount() )
				);
			}

			/**
			 * Write a message to the widget's status region.
			 *
			 * The region is cleared first so the same message twice in a row is
			 * still announced.
			 *
			 * @since x.x.x
			 *
			 * @param {string} message Text to announce.
			 */
			announce( message ) {
				const $status = this.$element.find( this.getSettings( 'selectors' ).status ).first();

				if ( ! $status.length || ! message ) {
					return;
				}

				clearTimeout( this.announceTimer );
				$status.text( '' );

				this.announceTimer = setTimeout( () => $status.text( message ), 100 );
			}

			/**
			 * Hand keyboard focus to a timeline item.
			 *
			 * Used after AJAX loads, where the control that had focus is replaced
			 * or has nothing left to load.
			 *
			 * @since x.x.x
			 *
			 * @param {jQuery} $item The item to focus.
			 */
			focusItem( $item ) {
				if ( ! $item || ! $item.length ) {
					return;
				}

				let $target = $item.find( '.pp-timeline-card-title' ).first();

				if ( ! $target.length ) {
					$target = $item;
				}

				$target.attr( 'tabindex', '-1' ).one( 'blur', function () {
					$(this).removeAttr( 'tabindex' );
				} );

				$target[0].focus();
			}

			setEqualHeight() {
				// Only when the option is on: this used to run on every resize
				// regardless, stamping fixed pixel heights onto every slide even
				// with Equal Height switched off.
				if ( 'yes' !== this.getElementSettings( 'equal_height' ) ) {
					return;
				}

				const $slides = this.elements.$carousel.find('.swiper-slide');

				if ( !$slides.length ) {
					return;
				}

				// Write pass: clear the heights.
				$slides.css('height', '');

				// Read pass: measure once everything is back to natural height.
				let maxHeight = 0;

				$slides.each(function () {
					const slideHeight = $(this).find('.pp-timeline-card').outerHeight();

					if (slideHeight > maxHeight) {
						maxHeight = slideHeight;
					}
				});

				// Write pass: apply. Splitting the three passes keeps the browser
				// from re-laying-out once per slide.
				$slides.css('height', maxHeight + 'px');
			}

			initNumberedPagination() {
				const self = this;

				// Delegated from this widget's own element: bound to `body` it
				// fired once per Timeline on the page, so a click in one widget
				// paginated every other one too.
				self.$element.on( 'click', '.pp-timeline-pagination-ajax .page-numbers:not(.dots)', function(e) {
					const $posts_scope = $(this).closest( '.elementor-widget-pp-timeline' );

					let $scope = $posts_scope,
						container = $scope.find( '.pp-timeline' ),
						pageID = container.data('page');

					if ( 'main' == container.data( 'query-type' ) ) {
						return;
					}

					e.preventDefault();

					// After the list, not inside it: role="list" may only hold items.
					$scope.find( '.pp-timeline-items' ).first().after( '<div class="pp-post-loader"><div class="pp-loader"></div><div class="pp-loader-overlay"></div></div>' );

					let pageNumber = 1,
						curr = parseInt( $scope.find( '.pp-timeline-pagination .page-numbers.current' ).html() );

					if ( $(this).hasClass( 'next' ) ) {
						pageNumber = curr + 1;
					} else if ( $(this).hasClass( 'prev' ) ) {
						pageNumber = curr - 1;
					} else {
						pageNumber = $(this).html();
					}

					let $args = {
						'page_id':     pageID,
						'widget_id':   self.getID(),
						'filter':      $scope.find( '.pp-filter-current' ).data( 'filter' ),
						'taxonomy':    $scope.find( '.pp-filter-current' ).data( 'taxonomy' ),
						'page_number': pageNumber,
						'ajax_for':    'timeline'
					};

					const scrollTarget = ( $scope.find( '.pp-timeline-wrapper' ).offset().top ) - 30;

					if ( self.prefersReducedMotion() ) {
						window.scrollTo( 0, scrollTarget );
					} else {
						$('html, body').animate({
							scrollTop: scrollTarget
						}, 'slow');
					}

					// The clicked link is replaced along with the pagination, so
					// focus moves to the first item of the new page.
					self.callAjax( self, $args, false, undefined, true );
				} );
			}

			initLoadMore() {
				const self = this;
				this.loadStatus = true;

				self.$element.on( 'click', '.pp-post-load-more', function(e) {
					const $posts_scope = $(this).closest( '.elementor-widget-pp-timeline' );

					e.preventDefault();

					let $scope    = $posts_scope,
						loader    = $scope.find( '.pp-posts-loader' ),
						pageCount = self.getPostsCount(),
						category  = $scope.find( '.pp-filter-current' ).data( 'filter' ),
						taxonomy  = $scope.find( '.pp-filter-current' ).data( 'taxonomy' ),
						pageID    = $scope.find( '.pp-timeline' ).data('page');

					if ( elementorFrontend.isEditMode() ) {
						loader.show();

						return false;
					}

					let $args = {
						'page_id':     pageID,
						'widget_id':   self.getID(),
						'filter':      ( typeof category !== 'undefined' && category ) ? category : '',
						'taxonomy':    ( typeof taxonomy !== 'undefined' && taxonomy ) ? taxonomy : '',
						'page_number': ( pageCount + 1 ),
						'ajax_for':    'timeline'
					};

					self.total = $scope.find( '.pp-timeline-pagination' ).data( 'total' );

					if ( true == self.loadStatus ) {
						if ( pageCount < self.total ) {
							loader.show();
							// The button stays in place while loading: hiding it
							// while it held focus dropped keyboard focus to the page.
							$(this).attr( { 'aria-busy': 'true', 'aria-disabled': 'true' } );
							self.callAjax( self, $args, true, pageCount, true );
							pageCount++;
							self.loadStatus = false;
						}
					}
				} );
			}

			initInfiniteScroll() {
				let self   = this,
					count  = 1,
					ns     = this.getEventNamespace(),
					loader = this.$element.find( '.pp-posts-loader' );

				this.loadStatus = true;

				if ( this.elements.$sliderWrap.hasClass( 'pp-posts-infinite-scroll' ) ) {
					let windowHeight50 = $(window).outerHeight() / 1.25,
						ticking        = false;

					const check = function () {
						ticking = false;

						if ( elementorFrontend.isEditMode() ) {
							loader.show();
							return;
						}

						// Nothing left to fetch — skip the layout read entirely.
						self.total = self.$element.find( '.pp-timeline-pagination' ).data( 'total' );

						if ( true !== self.loadStatus || count >= self.total ) {
							return;
						}

						let $container = self.$element,
							$wrapper   = self.elements.$timeline,
							$lastItem  = $container.find( '.pp-timeline-item:last' );

						if ( !$lastItem.length ) {
							return;
						}

						if ( ( $(window).scrollTop() + windowHeight50 ) < ( $lastItem.offset().top ) ) {
							return;
						}

						let $args = {
							'page_id':     $wrapper.data('page'),
							'widget_id':   self.getID(),
							'filter':      $container.find( '.pp-filter-current' ).data( 'filter' ),
							'taxonomy':    $container.find( '.pp-filter-current' ).data( 'taxonomy' ),
							'page_number': $container.find( '.page-numbers.current' ).next( 'a' ).html(),
							'ajax_for':    'timeline'
						};

						loader.show();
						self.callAjax( self, $args, true );
						count++;
						self.loadStatus = false;
					};

					// Coalesce scroll events into one animation frame: the raw
					// handler ran a forced layout read on every single event.
					$(window).off( 'scroll' + ns + '-infinite' ).on( 'scroll' + ns + '-infinite', function () {
						if ( ticking ) {
							return;
						}

						ticking = true;
						requestAnimationFrame( check );
					} );

					$(window).off( 'resize' + ns + '-infinite' ).on( 'resize' + ns + '-infinite', function () {
						windowHeight50 = $(window).outerHeight() / 1.25;
					} );
				}
			}

			setPostsCount(count) {
				this.$element.find('.pp-post-load-more').attr('data-count', count);
			}

			getPostsCount() {
				return this.$element.find('.pp-post-load-more').data('count');
			}

			callAjax( self, $obj, $append, $count, $moveFocus ) {
				let loader = this.$element.find( '.pp-posts-loader' );

				var that = this;

				$.ajax({
					url: ppTimelineScript.ajax_url,
					data: {
						action:      'pp_get_post',
						page_id:     $obj.page_id,
						widget_id:   $obj.widget_id,
						category:    $obj.filter,
						taxonomy:    $obj.taxonomy,
						page_number: $obj.page_number,
						ajax_for:    $obj.ajax_for,
						nonce:       ppTimelineScript.timeline_nonce,
					},
					dataType: 'json',
					type: 'POST',
					success: function( data ) {
						let $container = self.elements.$sliderWrap,
							$timeline  = $container.find( '.pp-timeline' ),
							// The response carries items only, so it goes inside the
							// items container — appending it to .pp-timeline used to
							// duplicate the connector rail on every Load More.
							sel        = $container.find( '.pp-timeline-items' ).first();

						if ( ! sel.length ) {
							sel = $timeline;
						}

						// Where the new items start, so focus can go to the first of them.
						const itemsBefore = ( true == $append ) ? sel.find( '.pp-timeline-item' ).length : 0;

						let not_found = $container.find( '.pp-posts-empty' );

						not_found.remove();

						if ( $(not_found).length == 0 ) {
							$(data.data.not_found).insertBefore($timeline);
						}

						if ( true == $append ) {
							let html_str = data.data.html;
							sel.append( html_str );
						} else {
							sel.html( data.data.html );
						}

						self.$element.find( '.pp-post-loader' ).remove();

						self.refreshTimelineItems();
						self.setup();

						$container.find( '.pp-timeline-pagination-wrap' ).html( data.data.pagination );

						//	Complete the process 'loadStatus'
						self.loadStatus = true;
						if ( true == $append ) {
							loader.hide();
							$container.find( '.pp-post-load-more' ).show().attr( { 'aria-busy': 'false', 'aria-disabled': 'false' } );
						}

						self.setPostsCount( $obj.page_number );

						// Before the Load More button can be hidden below, so focus
						// is never left on a control that disappears.
						if ( $moveFocus ) {
							self.focusItem( sel.find( '.pp-timeline-item' ).eq( itemsBefore ) );
						}

						if ( true == $append ) {
							self.announce( ppTimelineScript.new_items_loaded );
						} else if ( ppTimelineScript.page_loaded ) {
							self.announce( ppTimelineScript.page_loaded.replace( '%s', $obj.page_number ) );
						}

						$count = $count + 1;

						if ( $count == self.total ) {
							$container.find( '.pp-post-load-more' ).hide();
						}

						self.$element.trigger('posts.rendered', [self.$element]);

						that.initVerticalLayout();
					},
					error: function() {
						// Put the controls back rather than leaving them busy for good.
						self.loadStatus = true;
						loader.hide();
						self.$element.find( '.pp-post-loader' ).remove();
						self.$element.find( '.pp-post-load-more' ).attr( { 'aria-busy': 'false', 'aria-disabled': 'false' } );
					}
				} ).done( function() {
					if ( self.$element.find( '.elementor-invisible' ).length > 0 ) {
						self.$element.find( '.elementor-invisible' ).removeClass( 'elementor-invisible' );
					}
				} );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-timeline', TimelineWidget );
	} );
})(jQuery);
