(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class TableWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						table: '.pp-table',
					},
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$table: this.$element.find( selectors.table ),
				};
			}

			bindEvents() {
				if ( this.$element.hasClass('elementor-widget-pp-table') ) {
					this.initTableSaw();
					this.initSortableA11y();
				}

				this.initTooltips();
			}

			initTableSaw() {
				const elementSettings = this.getElementSettings();

				if ( 'responsive' === elementSettings.table_type ) {

					if ( 'yes' === elementSettings.scrollable && 0 < elementSettings.breakpoint ) {
						if ( $(window).width() >= elementSettings.breakpoint ) {
							this.elements.$table.removeAttr('data-tablesaw-mode');
						}
					}

					$(document).trigger( 'enhance.tablesaw' );
				}

				// Tablesaw rebuilds our header markup — a sort button wrapped around the
				// cell content, and a clone of every header inside every stacked cell.
				// Both have to be repaired before the tooltips are bound.
				this.repairTablesawMarkup();

				this.elements.$table.on(
					'tablesawcreate.ppTable tablesawrefresh.ppTable tablesawcolumns.ppTable',
					() => this.repairTablesawMarkup()
				);
			}

			repairTablesawMarkup() {
				this.unwrapHeaderTooltips();
				this.cleanStackLabels();
			}

			unwrapHeaderTooltips() {
				this.elements.$table.find( 'thead th > .tablesaw-sortable-btn' ).each( function () {
					const $btn = $( this );

					// A tooltip trigger may not live inside a <button>: lift the icon trigger
					// and the description node back out into the <th>.
					$btn.find( '.pp-table-tooltip-icon, .pp-tooltip-container' ).appendTo( $btn.parent() );

					// A text trigger IS the button's content, so the sort button takes the
					// tooltip over: it is already focusable and already named by the header.
					const $textTrigger = $btn.find( '[data-tooltip]' );

					if ( $textTrigger.length && ! $btn.is( '[data-tooltip]' ) ) {
						$btn.attr( {
							'data-tooltip': $textTrigger.attr( 'data-tooltip' ),
							'data-tooltip-content': $textTrigger.attr( 'data-tooltip-content' ),
							'aria-describedby': $textTrigger.attr( 'aria-describedby' ),
						} );

						$textTrigger
							.removeAttr( 'data-tooltip data-tooltip-content aria-describedby tabindex role aria-expanded' )
							.removeClass( 'pp-tooltip-click pp-table-tooptip' );
					}
				} );
			}

			cleanStackLabels() {
				// Stack mode deep-clones each header into every cell, duplicating ids and
				// leaving dead triggers in the tab order.
				this.$element.find( '.tablesaw-cell-label' ).each( function () {
					const $label = $( this );

					$label.find( '.pp-tooltip-container, .pp-table-tooltip-icon' ).remove();

					$label.find( '[data-tooltip], .tooltipstered' )
						.removeAttr( 'data-tooltip data-tooltip-content aria-describedby role tabindex aria-expanded' )
						.removeClass( 'pp-tooltip-click pp-table-tooptip tooltipstered' );

					$label.find( '[id]' ).removeAttr( 'id' );
					$label.removeAttr( 'id' );
				} );
			}

			initSortableA11y() {
				const $table = this.elements.$table;

				if ( ! $table.is( '[data-tablesaw-sortable]' ) ) {
					return;
				}

				const $status = this.$element.find( '.pp-table-sort-status' );

				const announce = ( column, state ) => {
					const template = $status.length ? $status.data( 'sort-' + state ) : '';

					if ( template ) {
						$status.text( String( template ).replace( '%s', column ) );
					}
				};

				// Tablesaw records the sort direction as a class and an arrow drawn in CSS,
				// neither of which reaches assistive technology.
				const syncSortState = ( announceChange ) => {
					$table.find( 'thead th[data-tablesaw-sortable-col]' ).each( function () {
						const $th = $( this );
						let state = 'none';

						if ( $th.hasClass( 'tablesaw-sortable-ascending' ) ) {
							state = 'ascending';
						} else if ( $th.hasClass( 'tablesaw-sortable-descending' ) ) {
							state = 'descending';
						}

						if ( state === $th.attr( 'aria-sort' ) ) {
							return;
						}

						$th.attr( 'aria-sort', state );

						if ( announceChange && 'none' !== state ) {
							const $text = $th.find( '.pp-table-cell-text' ).first();

							announce( ( $text.length ? $text.text() : $th.text() ).trim(), state );
						}
					} );
				};

				// Tablesaw reaches the sorted state by several paths (header button, the
				// switcher dropdown, its own default column), and does not fire an event on
				// all of them — watching the classes it writes catches every one.
				const $head = $table.find( 'thead' );

				if ( $head.length && window.MutationObserver ) {
					this.sortObserver = new MutationObserver( () => syncSortState( true ) );
					this.sortObserver.observe( $head[0], {
						attributeFilter: [ 'class' ],
						attributes: true,
						subtree: true,
					} );
				}

				$table.on( 'tablesaw-sorted.ppTable', () => syncSortState( true ) );
				$table.on( 'tablesawcreate.ppTable', () => syncSortState( false ) );

				syncSortState( false );
			}

			onDestroy() {
				if ( super.onDestroy ) {
					super.onDestroy();
				}

				if ( this.sortObserver ) {
					this.sortObserver.disconnect();
					this.sortObserver = null;
				}
			}

			initTooltips() {
				const elementSettings = this.getElementSettings(),
					elementID         = this.getID(),
					$tooltipElements  = this.$element.find('[data-tooltip]'),
					tooltipArrow      = elementSettings.tooltip_arrow === 'yes',
					tooltipTrigger    = elementSettings.tooltip_trigger || 'hover',
					tooltipAnimation  = elementSettings.tooltip_animation || 'fade',
					tooltipSize       = elementSettings.tooltip_size,
					tooltipZIndex     = elementSettings.tooltip_zindex || 99,
					breakpoints       = elementorFrontend.config.responsive.activeBreakpoints;

				let tooltipClass = `pp-tooltip pp-tooltip-${elementID}`;
				if (['default', 'tiny', 'small', 'large'].includes(tooltipSize)) {
					tooltipClass += ` pp-tooltip-size-${tooltipSize}`;
				}

				const getTooltipPosition = (tooltipOptions) => {
					const windowWidth = window.innerWidth;

					const breakpointPositions = [
						{ bp: breakpoints.widescreen, position: tooltipOptions.position_widescreen },
						{ bp: breakpoints.laptop, position: tooltipOptions.position },
						{ bp: breakpoints.tablet_extra, position: tooltipOptions.position_laptop },
						{ bp: breakpoints.tablet, position: tooltipOptions.position_tablet_extra },
						{ bp: breakpoints.mobile_extra, position: tooltipOptions.position_tablet },
						{ bp: breakpoints.mobile, position: tooltipOptions.position_mobile_extra },
					];

					for (const { bp, position } of breakpointPositions) {
						if (bp && windowWidth > bp.value && position) {
							return position;
						}
					}

					return tooltipOptions.position_mobile || 'top';
				};


				const isClickTooltip = ( 'click' === tooltipTrigger );

				// An editor re-render runs this again; drop the previous pass's Escape handlers.
				$(document).off('keydown.ppTableTooltip-' + elementID);

				$tooltipElements.each(function () {
					const $this         = $(this),
						tooltipOptions  = $this.data('tooltip') || {},
						tooltipPosition = getTooltipPosition(tooltipOptions),
						contentSelector = $this.attr('data-tooltip-content'),
						$source         = contentSelector ? $(contentSelector) : $(),
						tooltipConfig   = {
							// Tooltipster core only binds pointer triggers, so drive
							// open/close ourselves and keep focus and Escape working.
							trigger:         'custom',
							triggerOpen:     isClickTooltip
								? { click: true, tap: true }
								: { mouseenter: true, touchstart: true },
							triggerClose:    isClickTooltip
								? { click: true, tap: true }
								: { mouseleave: true, touchleave: true, originClick: true },
							animation:       tooltipAnimation,
							minWidth:        tooltipOptions.width || 'auto',
							ppclass:         tooltipClass,
							side:            tooltipPosition,
							arrow:           tooltipArrow,
							distance:        tooltipOptions.distance || 10,
							interactive:     true,
							positionTracker: true,
							zIndex:          tooltipZIndex,

							functionReady:   function ( instance, helper ) {
								// aria-expanded belongs to the click disclosure only; a hover
								// tooltip is described by aria-describedby, not expanded.
								if ( isClickTooltip ) {
									$( helper.origin ).attr( 'aria-expanded', 'true' );

									// Park focus in the panel so any links inside are reachable.
									$( helper.tooltip ).attr( 'tabindex', '-1' ).trigger( 'focus' );
								}
							},
							functionAfter:   function ( instance, helper ) {
								if ( isClickTooltip ) {
									$( helper.origin ).attr( 'aria-expanded', 'false' );
								}
							},
						};

					// Keep the in-page node (the aria-describedby target) where it is and hand
					// tooltipster an id-less clone, so the description keeps resolving and no
					// duplicate id ever exists while the tooltip is open.
					if ( $source.length ) {
						tooltipConfig.content = $source.clone().removeAttr('id').removeAttr('role');
					}

					$this.pptooltipster(tooltipConfig);

					const isOpen = () => $this.hasClass('tooltipstered') && $this.pptooltipster('status').open;

					if ( ! isClickTooltip ) {
						// Hover mode: focus is the keyboard equivalent of mouseenter.
						$this.on('focusin.ppTableTooltip', function () {
							$this.pptooltipster('open');
						}).on('focusout.ppTableTooltip', function ( event ) {
							if ( ! event.relatedTarget || ! $this.has( event.relatedTarget ).length ) {
								$this.pptooltipster('close');
							}
						});
					} else if ( ! $this.is('button, a') ) {
						// Click mode on a role="button" element: wire Enter and Space.
						$this.on('keydown.ppTableTooltip', function ( event ) {
							if ( 'Enter' === event.key || ' ' === event.key || 'Spacebar' === event.key ) {
								event.preventDefault();
								$this.trigger('click');
							}
						});
					}

					// Escape dismisses without moving the pointer (WCAG 1.4.13) and
					// returns focus to the trigger.
					$this.on('keydown.ppTableTooltip', function ( event ) {
						if ( 'Escape' === event.key || 'Esc' === event.key ) {
							if ( isOpen() ) {
								event.stopPropagation();
								$this.pptooltipster('close');
							}
						}
					});

					$(document).on('keydown.ppTableTooltip-' + elementID, function ( event ) {
						if ( 'Escape' === event.key || 'Esc' === event.key ) {
							if ( isOpen() ) {
								$this.pptooltipster('close');
								$this.trigger('focus');
							}
						}
					});
				});
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-table', TableWidget );
		elementorFrontend.elementsHandler.attachHandler( 'pp-pricing-table', TableWidget );
	} );
})(jQuery);