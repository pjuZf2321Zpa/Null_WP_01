(function ($) {

	$(window).on( 'elementor/frontend/init', () => {

		class CardSliderWidget extends elementorModules.frontend.handlers.Base {

			getDefaultSettings() {
				return {
					selectors: {
						swiperContainer: '.pp-swiper-slider',
						swiperSlide: '.swiper-slide',
						status: '.pp-card-slider-status',
					},
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings('selectors');

				return {
					$swiperContainer: this.$element.find(selectors.swiperContainer),
					// Read before Swiper adds its loop clones, so this holds the real slides only.
					$swiperSlide: this.$element.find(selectors.swiperSlide),
					$status: this.$element.find(selectors.status),
				};
			}

			getI18n() {
				return ( 'undefined' !== typeof ppCardSliderScript && ppCardSliderScript.i18n )
					? ppCardSliderScript.i18n
					: {};
			}

			getSliderSettings(settingName) {
				const sliderSettings = this.elements.$swiperContainer.data('slider-settings') || {};

				return (typeof settingName !== 'undefined')
					? sliderSettings[settingName]
					: sliderSettings;
			}

			getEffect() {
				return this.getSliderSettings('effect');
			}

			getSwiperOptions() {
				const sliderSettings = this.getSliderSettings();
				const isEditorMode = this.isEdit;
				const widgetId = this.getID();
				const i18n = this.getI18n();

				const swiperOptions = {
					grabCursor: sliderSettings.grab_cursor === 'yes',
					slidesPerView: 1,
					slidesPerGroup: 1,
					loop: sliderSettings.loop === 'yes',
					centeredSlides: sliderSettings.centered_slides === 'yes',
					speed: sliderSettings.speed || 500,
					autoHeight: !!sliderSettings.auto_height,
					effect: this.getEffect(),
					watchSlidesVisibility: true,
					watchSlidesProgress: true,
					preventClicksPropagation: false,
					slideToClickedSlide: true,
					keyboard: {
						enabled: sliderSettings.keyboard === 'yes',
						onlyInViewport: true,
					},
					/*
					 * Swiper reads these under its own option names; the localised strings
					 * use shorter keys, so they have to be mapped one by one or Swiper
					 * falls back to English, and to "1 / 4" as the slide label.
					 */
					a11y: {
						enabled:                    true,
						prevSlideMessage:           i18n.prevSlide || 'Previous slide',
						nextSlideMessage:           i18n.nextSlide || 'Next slide',
						firstSlideMessage:          i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:           i18n.lastSlide || 'This is the last slide',
						paginationBulletMessage:    i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:          i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						slideRole:                  'group',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide',
					},
				};

				/** Pagination */
				if (sliderSettings.pagination) {
					const paginationSelector = isEditorMode ? '.swiper-pagination' : `.swiper-pagination-${widgetId}`;

					swiperOptions.pagination = {
						el: paginationSelector,
						type: sliderSettings.pagination,
						clickable: true,
					};
				}

				/** Autoplay */
				if (!isEditorMode && sliderSettings.autoplay) {
					swiperOptions.autoplay = {
						delay: sliderSettings.autoplay_speed || 3000,
						disableOnInteraction: !!sliderSettings.pause_on_interaction,
					};
				}

				return swiperOptions;
			}

			bindEvents() {
				const elementSettings = this.getElementSettings();

				this.stackOn = elementSettings.responsive_breakpoint;

				if ( this.stackOn !== 'none' ) {
					this.stackIt();
					this.bindResizeEvent();
				}

				this.initSlider();
			}

			/**
			 * Apply breakpoint classes based on Elementor device mode
			 */
			stackIt() {
				if ( this.stackOn == 'none' ) {
					return;
				}

				const breakpoints = elementorFrontend.config.responsive.activeBreakpoints;
				let stackOn = breakpoints[this.stackOn].value;

				if ( window.innerWidth <= stackOn ) {
					this.$element.find('.pp-card-slider').addClass('pp-card-slider-breakpoint-active');
				} else {
					this.$element.find('.pp-card-slider').removeClass('pp-card-slider-breakpoint-active');
				}
			}

			/**
			 * Handle browser resize
			 */
			bindResizeEvent() {
				elementorFrontend.elements.$window.on('resize', this.stackIt.bind(this));
			}

			async initSlider() {
				const Swiper = elementorFrontend.utils.swiper;
				const elementSettings = this.getElementSettings();

				if (!this.elements.$swiperContainer.length) {
					return;
				}

				this.swiper = await new Swiper(
					this.elements.$swiperContainer,
					this.getSwiperOptions()
				);

				this.bindA11y();

				this.setEqualHeight();

				if (elementSettings.open_lightbox !== 'no') {
					this.removeDuplicateLightboxAttributes();
				}
			}

			/**
			 * Everything the slider needs once Swiper is up: tab order, announcements
			 * and the ways the visitor can pause the autoplay.
			 *
			 * @since x.x.x
			 */
			bindA11y() {
				const elementSettings = this.getElementSettings();
				const container = this.elements.$swiperContainer[0];

				this.syncSlideVisibility();

				this.swiper.on( 'slideChangeTransitionEnd', () => {
					this.syncSlideVisibility();
				} );

				// The status region announces every move the user makes; Swiper's polite
				// wrapper would announce the same change a second time.
				this.elements.$swiperContainer.children( '.swiper-wrapper' ).attr( 'aria-live', 'off' );

				/*
				 * Autoplay must not speak: on a timer the announcement interrupts whatever
				 * the visitor is reading, every few seconds. Swiper emits slideChange before
				 * its own click and key handlers return, so the intent is marked on the way
				 * down, in the capture phase.
				 */
				this.userNavigated = false;

				const markNavigated = ( e ) => {
					const onBullet = e.target.closest && e.target.closest( '.swiper-pagination-bullet' );

					if ( 'keydown' === e.type ) {
						// Swiper's keyboard module moves the slider from the arrow keys too.
						const isNavKey = [ 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown' ].indexOf( e.key ) > -1;

						if ( ! isNavKey && ! ( onBullet && ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) ) ) {
							return;
						}
					} else if ( ! onBullet ) {
						return;
					}

					this.userNavigated = true;

					// Swiper stops the autoplay for good here; nothing below may restart it.
					if ( this.swiper.params.autoplay && this.swiper.params.autoplay.disableOnInteraction ) {
						this.autoplayHalted = true;
					}
				};

				container.addEventListener( 'pointerdown', markNavigated, true );
				container.addEventListener( 'keydown', markNavigated, true );

				this.swiper.on( 'touchEnd', () => {
					this.userNavigated = true;
				} );

				this.swiper.on( 'slideChange', () => {
					this.announceSlidePosition();
				} );

				/*
				 * params.autoplay.enabled, not the widget setting: it is false in the editor
				 * and wherever Elementor held the autoplay back for prefers-reduced-motion.
				 * Swiper's autoplay.start() has no such guard, so binding a resume on a
				 * slider that is not autoplaying would set one running.
				 */
				if ( ! this.swiper.autoplay || ! this.swiper.params.autoplay || ! this.swiper.params.autoplay.enabled ) {
					return;
				}

				if ( 'yes' === elementSettings.pause_on_hover ) {
					this.$element.on( {
						mouseenter: () => {
							this.isHovered = true;
							this.stopAutoplay();
						},
						mouseleave: () => {
							this.isHovered = false;
							this.resumeAutoplay();
						},
					} );
				}

				// The keyboard equivalent of the hover pause, bound whenever the autoplay runs.
				this.$element.on( {
					focusin: () => this.stopAutoplay(),
					focusout: ( e ) => {
						if ( ! this.$element[0].contains( e.relatedTarget ) ) {
							this.resumeAutoplay();
						}
					},
				} );
			}

			/**
			 * Only the active slide stays in the accessibility tree and the tab order.
			 * The slides are queried afresh so Swiper's loop clones are covered too, and
			 * inert is what takes the links inside out of the tab order; aria-hidden on
			 * its own leaves focus landing on content nobody can see.
			 *
			 * @since x.x.x
			 */
			syncSlideVisibility() {
				this.elements.$swiperContainer.find( '.swiper-slide' ).each( function () {
					// A slide is never itself a control, so it should hold no tabindex at all.
					this.removeAttribute( 'tabindex' );

					if ( this.classList.contains( 'swiper-slide-active' ) ) {
						this.removeAttribute( 'aria-hidden' );
						this.removeAttribute( 'inert' );
					} else {
						this.setAttribute( 'aria-hidden', 'true' );
						this.setAttribute( 'inert', '' );
					}
				} );
			}

			/**
			 * Announces the slide position, but only where the user asked for the move.
			 *
			 * @since x.x.x
			 */
			announceSlidePosition() {
				if ( ! this.userNavigated || ! this.elements.$status.length ) {
					return;
				}

				this.userNavigated = false;

				const statusFormat = this.getI18n().slideStatus || 'Showing Slide %1$s of %2$s';

				this.elements.$status.text(
					statusFormat
						.replace( '%1$s', this.swiper.realIndex + 1 )
						.replace( '%2$s', this.elements.$swiperSlide.length )
				);
			}

			/**
			 * @since x.x.x
			 */
			stopAutoplay() {
				if ( this.swiper && this.swiper.autoplay && this.swiper.autoplay.running ) {
					this.swiper.autoplay.stop();
				}
			}

			/**
			 * Resumes the autoplay unless something still holds it: the pointer is over
			 * the slider, focus is inside it, or Swiper stopped it on interaction.
			 *
			 * @since x.x.x
			 */
			resumeAutoplay() {
				if ( this.autoplayHalted || this.isHovered || this.$element[0].contains( document.activeElement ) ) {
					return;
				}

				if ( this.swiper && this.swiper.autoplay && ! this.swiper.autoplay.running ) {
					this.swiper.autoplay.start();
				}
			}

			setEqualHeight() {
				let maxSlideHeight = 0;

				this.elements.$swiperSlide.each(function () {
					const slideHeight = $(this).outerHeight();
					if (slideHeight > maxSlideHeight) {
						maxSlideHeight = slideHeight;
					}
				});

				if (maxSlideHeight > 0) {
					this.elements.$swiperContainer.css('height', `${maxSlideHeight + 70}px`);
				}
			}

			removeDuplicateLightboxAttributes() {
				this.$element.find('.pp-card-slider-item.swiper-slide-duplicate').each(function () {
					let lightboxItem = $(this).find('.pp-card-slider-image a');

					lightboxItem.removeAttr( 'data-elementor-open-lightbox data-elementor-lightbox-slideshow data-elementor-lightbox-index' );
					lightboxItem.removeClass( 'elementor-clickable' );
				});
			}
		}

		elementorFrontend.elementsHandler.attachHandler('pp-card-slider', CardSliderWidget);

	});

})(jQuery);
