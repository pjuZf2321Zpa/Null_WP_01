;(function($) {

	'use strict';

	var PPOffcanvasContent = function( $scope ) {

		this.node                   = $scope;
		this.wrap                   = $scope.find('.pp-offcanvas-content-wrap');
		this.cart_wrap              = $scope.find('.pp-offcanvas-cart-container');
		this.content                = $scope.find('.pp-offcanvas-content');
		this.button                 = $scope.find('.pp-offcanvas-toggle');
		this.settings               = this.wrap.data('settings');
		this.scopeUniqueId          = this.getOffcanvasUniqueScopeId( $scope );
		this.toggle_source          = this.settings.toggle_source;
		this.id                     = this.scopeUniqueId;
		this.toggle_id              = this.settings.toggle_id;
		this.toggle_class           = this.settings.toggle_class;
		this.transition             = this.settings.transition;
		this.esc_close              = this.settings.esc_close;
		this.body_click_close       = this.settings.body_click_close;
		this.links_click_close      = this.settings.links_click_close;
		this.editor_preview         = this.settings.editor_preview;
		this.direction              = this.settings.direction;
		this.buttons_position       = this.settings.buttons_position;
		this.open_panel_add_to_cart = this.settings.open_panel_add_to_cart;
		this.duration               = 500;

		this.destroy();
		this.init();
	};

	PPOffcanvasContent.prototype = {
		id: '',
		node: '',
		wrap: '',
		content: '',
		button: '',
		settings: {},
		transition: '',
		duration: 400,
		initialized: false,
		animations: [
			'slide',
			'slide-along',
			'reveal',
			'push',
		],

		init: function () {
			if ( ! this.wrap.length ) {
				return;
			}

			$('html').addClass('pp-offcanvas-content-widget');

			if ( $('.pp-offcanvas-container').length === 0 ) {
				var faProJs = $('#font-awesome-pro-js').length > 0 ? $('#font-awesome-pro-js').attr('src') : false,
					faScript;

				if ( faProJs ) {
					$('#font-awesome-pro-js').remove();
				}
				$('body').wrapInner( '<div class="pp-offcanvas-container" />' );
				this.content.insertBefore('.pp-offcanvas-container');
				$('.pp-offcanvas-' + this.id).removeClass('pp-offcanvas-hide');
				$('.pp-offcanvas-' + this.id).removeAttr('style');

				if ( faProJs ) {
					// Built as a node rather than concatenated into a markup
					// string. The src is read back off the page, but a script tag
					// assembled by string concatenation is a code execution sink
					// by construction, and one quote in that URL would break out
					// of the attribute.
					faScript = document.createElement('script');
					faScript.type = 'text/javascript';
					faScript.id = 'font-awesome-pro-js';
					faScript.src = faProJs;
					document.body.appendChild( faScript );
				}
			}

			if ( this.wrap.find('.pp-offcanvas-content').length > 0 ) {
				if ( $('.pp-offcanvas-container > .pp-offcanvas-' + this.id).length > 0 ) {
					$('.pp-offcanvas-container > .pp-offcanvas-' + this.id).remove();
				}
				if ( $('body > .pp-offcanvas-' + this.id ).length > 0 ) {
					$('body > .pp-offcanvas-' + this.id ).remove();
				}
				$('body').prepend( this.wrap.find('.pp-offcanvas-content') );
				$('.pp-offcanvas-' + this.id).removeClass('pp-offcanvas-hide');
				$('.pp-offcanvas-' + this.id).removeAttr('style');
			}

			this.bindEvents();
		},

		getOffcanvasUniqueScopeId: function( $scope ) {
			var scopeId = $scope.data('id'),
				scopeIdCloned,
				$clones = $( '[data-id="' + scopeId + '"]' );

			if ( ! this.hasMultipleScopeId( scopeId ) ) {
				return scopeId;
			}
			scopeIdCloned = scopeId;

			$clones.each( function( index ) {
				$(this).attr( 'data-pp-offcanvas-index', index );
			});

			scopeId = scopeId + '_' + $scope.data('pp-offcanvas-index');

			$( '#pp-offcanvas-' + scopeIdCloned ).each( function() {
				$( this ).attr( 'id', 'pp-offcanvas-' + scopeId );

				if ( $( this ).hasClass( 'pp-offcanvas-' + scopeIdCloned ) ) {
					$( this ).addClass( 'pp-offcanvas-' + scopeId );
				}
			} );

			// The toggle points at the panel by id, so it has to follow the rename
			// or it ends up referencing an element that no longer exists.
			$scope.find( '[aria-controls="pp-offcanvas-' + scopeIdCloned + '"]' )
				.attr( 'aria-controls', 'pp-offcanvas-' + scopeId );

			return scopeId;
		},

		hasMultipleScopeId : function( scopeId ) {
			var $clones = $( '[data-id="' + scopeId + '"]' );

			if ( 1 === $clones.length ) {
				return false;
			}

			return true;
		},

		/**
		 * Event namespace for this widget's bindings.
		 *
		 * Derived from the widget id, so it is stable across re-inits and one
		 * instance can never unbind another's handlers.
		 */
		getNamespace: function() {
			return '.ppOffcanvas' + this.id;
		},

		destroy: function() {
			var ns = this.getNamespace();

			this.close();

			this.animations.forEach(function( animation ) {
				if ( $('html').hasClass( 'pp-offcanvas-content-' + animation ) ) {
					$('html').removeClass( 'pp-offcanvas-content-' + animation );
				}
			});

			// Elementor re-runs element_ready on every editor re-render, and this
			// constructor calls destroy() before init(). Without the unbinding
			// below every re-render stacked another set of handlers: the toggle
			// ended up firing show() and close() in the same click, so the panel
			// stopped opening at all after the first re-render.
			$(window).off( ns );
			$(document).off( ns );
			$(document.body).off( ns );
			this.setTrigger().off( ns );
			this.getPanel().off( ns );

			if ( this._resizeFrame ) {
				cancelAnimationFrame( this._resizeFrame );
				this._resizeFrame = null;
			}
		},

		setTrigger: function() {
			var $trigger = false;

			if ( this.toggle_source == 'element-id' && this.toggle_id != '' ) {
				$trigger = $( '#' + this.toggle_id );
			} else if ( this.toggle_source == 'element-class' && this.toggle_class != '' ) {
				$trigger = $( '.' + this.toggle_class );
			} else {
				$trigger = this.node.find( '.pp-offcanvas-toggle' );
			}
			
			return $trigger;
		},

		/**
		 * Fire a click from Enter or Space on a div[role="button"].
		 *
		 * Those elements get no synthetic click of their own, and Space scrolls
		 * the page unless the default is cancelled.
		 */
		activateOnKey: function( e ) {
			if ( 13 === e.which || 32 === e.which || 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) {
				e.preventDefault();
				$(this).trigger('click');
			}
		},

		bindEvents: function () {
			var self = this,
				ns = this.getNamespace(),
				$trigger = this.setTrigger();

			if ( $trigger ) {
				$trigger.on('click' + ns, $.proxy( this.toggleContent, this ));
				$trigger.filter('[role="button"], [tabindex]').on('keydown' + ns, this.activateOnKey);

				// element-id / element-class triggers are arbitrary author
				// markup. Give them the disclosure wiring, and make them
				// operable if the author did not use a real control.
				if ( 'element-id' === this.toggle_source || 'element-class' === this.toggle_source ) {
					// The class lets this widget's stylesheet draw the focus ring on
					// a trigger that lives outside the widget.
					$trigger.addClass( 'pp-offcanvas-trigger' ).attr( 'aria-controls', 'pp-offcanvas-' + this.id );

					if ( ! $trigger.is('[aria-expanded]') ) {
						$trigger.attr( 'aria-expanded', 'false' );
					}

					$trigger.not('a, button, input, [role="button"], [tabindex]')
						.attr({ 'role': 'button', 'tabindex': '0' })
						.on('keydown' + ns, this.activateOnKey);
				}
			}

			if( 'yes' === this.open_panel_add_to_cart ) {
				// Listen for the cart actually changing rather than for a click on
				// a button collected at init. That fixed set missed every button
				// added later - AJAX pagination, quick view - and the fixed 1000ms
				// timeout that followed it was a guess at when the fragments would
				// land. These events all fire after the new cart contents are in.
				// show() rather than toggleContent(): adding a second item while
				// the panel was open used to close it.
				$( document.body ).on(
					'added_to_cart' + ns + ' pp_added_to_cart' + ns + ' pp_product_actions_added_to_cart' + ns,
					function() {
						self.show();
					}
				);
			}

			if ( this.cart_wrap.length ) {
				// WooCommerce replaces the whole mini cart through fragments when an
				// item is removed, which destroys the focused remove link. Note which
				// one it was so focus can land on its neighbour afterwards.
				$('body').on( 'click' + ns, '.pp-offcanvas-' + this.id + ' .remove_from_cart_button', function() {
					self._removedIndex = self.getPanel().find('.remove_from_cart_button').index( this );
				});

				// Bound after WooCommerce's own removed_from_cart handler, so the new
				// fragments are already in the page when this runs.
				$( document.body ).on( 'removed_from_cart' + ns + ' wc_fragments_refreshed' + ns, function() {
					self.restoreFocusInPanel();
				});
			}

			$('body').on( 'click' + ns, '.pp-offcanvas-content .pp-offcanvas-close', function(e) {
				// Also stops jQuery falling through to the element's native
				// click() after a keyboard-synthesised one, which would run this
				// handler a second time.
				e.preventDefault();

				if ( self.editor_preview === 'yes' ) {
					self._suppressShow = true;
				}
				self.close();
			});

			// The close button is a div[role="button"], so Enter and Space have
			// to be wired up explicitly - see render_close_button().
			$('body').on( 'keydown' + ns, '.pp-offcanvas-content .pp-offcanvas-close', this.activateOnKey );

			// Nav Menu accordion: indicator-icon click toggles submenu (both trigger modes)
			$('body').on(
				'click' + ns,
				'.pp-offcanvas-' + this.id + ' .pp-offcanvas-menu-accordion .pp-offcanvas-menu-indicator',
				function(e) {
					e.preventDefault();
					e.stopImmediatePropagation();
					self.toggleSubmenu( $(this) );
				}
			);

			// Nav Menu accordion: indicator keyboard activation (Enter/Space)
			$('body').on(
				'keydown' + ns,
				'.pp-offcanvas-' + this.id + ' .pp-offcanvas-menu-accordion .pp-offcanvas-menu-indicator',
				this.activateOnKey
			);

			// Nav Menu accordion: parent-item link click toggles submenu (trigger=item)
			$('body').on(
				'click' + ns,
				'.pp-offcanvas-' + this.id + ' .pp-offcanvas-menu-accordion.pp-offcanvas-menu-trigger-item .pp-offcanvas-menu-item-has-children > a',
				function(e) {
					e.preventDefault();
					e.stopImmediatePropagation();
					self.toggleSubmenu( $(this) );
				}
			);

			// The parent item is an anchor carrying role="button", so Enter
			// already reaches the click handler above natively. Only Space needs
			// wiring - routing Enter through here too would toggle twice.
			$('body').on(
				'keydown' + ns,
				'.pp-offcanvas-' + this.id + ' .pp-offcanvas-menu-accordion.pp-offcanvas-menu-trigger-item .pp-offcanvas-menu-item-has-children > a',
				function(e) {
					if ( 32 === e.which || ' ' === e.key || 'Spacebar' === e.key ) {
						e.preventDefault();
						$(this).trigger('click');
					}
				}
			);

			if ( this.links_click_close === 'yes' ) {
				$('body').on( 'click' + ns, '.pp-offcanvas-content .pp-offcanvas-body a', $.proxy( this.close, this ) );
			}

			if ( this.esc_close === 'yes' && this.editor_preview !== 'yes' ) {
				this.closeESC();
			}
			if ( this.body_click_close === 'yes' && this.editor_preview !== 'yes' ) {
				this.closeClick();
			}
			$(window).on( 'resize' + ns, $.proxy( this._onResize, this ) );

			var prevObserver = this.node.data('pp-offcanvas-preview-observer');
			if ( prevObserver ) {
				prevObserver.disconnect();
				this.node.removeData('pp-offcanvas-preview-observer');
			}

			if ( this.editor_preview === 'yes' ) {
				this.bindEditorPreview();
			}
		},

		bindEditorPreview: function () {
			var self = this;
			var widgetEl = this.node && this.node[0];

			if ( ! widgetEl || typeof MutationObserver === 'undefined' ) {
				return;
			}

			var sync = function () {
				if ( widgetEl.classList.contains('elementor-element-editable') ) {
					if ( ! self._suppressShow ) {
						self.show();
					}
				} else {
					self._suppressShow = false;
					self.close();
				}
			};

			var observer = new MutationObserver(function (mutations) {
				for ( var i = 0; i < mutations.length; i++ ) {
					if ( mutations[i].attributeName === 'class' ) {
						sync();
						return;
					}
				}
			});
			observer.observe( widgetEl, { attributes: true, attributeFilter: ['class'] } );
			this.node.data('pp-offcanvas-preview-observer', observer);

			setTimeout( sync, 0 );
		},

		/**
		 * Open or close the submenu owning the given trigger.
		 *
		 * The trigger is the indicator icon or the parent link depending on the
		 * Submenu Trigger setting, so the state is read back off the item rather
		 * than assumed from whichever element was activated.
		 *
		 * @param {jQuery} $trigger The activated element.
		 */
		toggleSubmenu: function( $trigger ) {
			var $item = $trigger.closest('.pp-offcanvas-menu-item-has-children'),
				isOpen;

			if ( ! $item.length ) {
				return;
			}

			$item.toggleClass('pp-offcanvas-submenu-open');
			isOpen = $item.hasClass('pp-offcanvas-submenu-open');

			$item.children('[aria-expanded]').attr( 'aria-expanded', isOpen ? 'true' : 'false' );
		},

		toggleContent: function(e) {
			e.preventDefault();

			// This widget's own open class, not the global one. Two offcanvas
			// widgets on one page each have to be able to open while the other
			// is open - the global check made the second toggle close instead.
			if ( ! $('html').hasClass('pp-offcanvas-' + this.id + '-open') ) {
				this.show();
			} else {
				this.close();
			}

			this._resize();
		},

		/**
		 * The panel the widget owns, wherever init() has moved it to.
		 */
		getPanel: function() {
			return $('.pp-offcanvas-' + this.id);
		},

		/**
		 * Whether the panel declares itself a modal dialog.
		 *
		 * Only markup that opts in gets the focus handling below, so a widget
		 * whose panel is still a plain container behaves exactly as before.
		 */
		isDialog: function() {
			return 'dialog' === this.getPanel().attr('role');
		},

		show: function() {
			if ( this._closeTimer ) {
				clearTimeout( this._closeTimer );
				this._closeTimer = null;
			}

			this.getPanel().addClass('pp-offcanvas-visible');
			// init animation class.
			$('html').addClass( 'pp-offcanvas-content-' + this.transition );
			$('html').addClass( 'pp-offcanvas-' + this.direction );
			$('html').addClass('pp-offcanvas-open');
			$('html').addClass('pp-offcanvas-' + this.id + '-open');
			$('html').addClass('pp-offcanvas-reset');

			this.button.addClass('pp-is-active');
			this.setExpanded( true );

			this._resize();

			this.setPageInert( true );
			this.adoptCartLiveRegion( true );
			this.trapFocus();
		},

		close: function() {
			var wasOpen = $('html').hasClass('pp-offcanvas-' + this.id + '-open');

			$('html').removeClass('pp-offcanvas-open');
			$('html').removeClass('pp-offcanvas-' + this.id + '-open');

			if ( this._closeTimer ) {
				clearTimeout( this._closeTimer );
			}

			this._closeTimer = setTimeout($.proxy(function () {
				$('html').removeClass('pp-offcanvas-reset');
				$('html').removeClass( 'pp-offcanvas-content-' + this.transition );
				$('html').removeClass( 'pp-offcanvas-' + this.direction );
				this.getPanel().removeClass('pp-offcanvas-visible');
				this._closeTimer = null;
			}, this), 500);

			this.button.removeClass('pp-is-active');
			this.setExpanded( false );

			// Before releaseFocus(): the trigger lives in the page, and an inert
			// element cannot take focus.
			this.setPageInert( false );
			this.adoptCartLiveRegion( false );
			this.releaseFocus( wasOpen );
		},

		/**
		 * Take the page behind an open dialog out of the tab order and the
		 * accessibility tree.
		 *
		 * aria-modal alone is ignored by several mobile screen readers, and the
		 * keydown trap cannot stop focus that has already fallen to <body>. init()
		 * moves every panel out of .pp-offcanvas-container, so the container can go
		 * inert without taking a panel with it. Never in the editor, where it would
		 * make the canvas unclickable.
		 *
		 * @since x.x.x
		 *
		 * @param {boolean} inert Whether the page should be inert.
		 */
		setPageInert: function( inert ) {
			var container = document.querySelector('.pp-offcanvas-container');

			if ( ! container || ! this.isDialog() || ( window.elementorFrontend && elementorFrontend.isEditMode() ) ) {
				return;
			}

			if ( inert ) {
				container.setAttribute( 'inert', '' );
			} else if ( ! /(^|\s)pp-offcanvas-\S+-open(\s|$)/.test( document.documentElement.className ) ) {
				// Only once no other panel is still open.
				container.removeAttribute( 'inert' );
			}
		},

		/**
		 * Move WooCommerce's cart live region into the open panel and back out.
		 *
		 * WooCommerce announces "removed from your cart" through a role="status"
		 * region on <body>. Outside a modal dialog that region is not announced by
		 * every screen reader, and inside the inert page it is not announced at all.
		 *
		 * @since x.x.x
		 *
		 * @param {boolean} intoPanel Whether to move the region into the panel.
		 */
		adoptCartLiveRegion: function( intoPanel ) {
			var $region = $('.widget_shopping_cart_live_region');

			if ( ! this.cart_wrap.length || ! $region.length || ! this.isDialog() ) {
				return;
			}

			$region.appendTo( intoPanel ? this.getPanel() : document.body );
		},

		/**
		 * Put focus back inside the open panel after a cart fragment swap removed
		 * the focused element.
		 *
		 * Lands on the remove link that took the removed one's place, the one
		 * before it if the last item went, then the first focusable element, and
		 * finally the panel itself.
		 *
		 * @since x.x.x
		 */
		restoreFocusInPanel: function() {
			var $panel = this.getPanel(),
				index = this._removedIndex,
				$removes,
				$target;

			this._removedIndex = null;

			if ( ! this.isDialog() || this.editor_preview === 'yes' || ! $panel.length ||
				! $('html').hasClass( 'pp-offcanvas-' + this.id + '-open' ) ||
				$.contains( $panel[0], document.activeElement ) ) {
				return;
			}

			$removes = $panel.find('.remove_from_cart_button');

			if ( null !== index && undefined !== index && $removes.length ) {
				$target = $removes.eq( Math.min( index, $removes.length - 1 ) );
			} else {
				$target = this.getFocusable().first();
			}

			if ( $target.length ) {
				$target.trigger('focus');
			} else {
				$panel.attr( 'tabindex', '-1' ).trigger('focus');
			}
		},

		/**
		 * Mirror the open state onto the toggle's disclosure attribute.
		 *
		 * Only touches a toggle that already declares aria-expanded, so a toggle
		 * that is not a real button does not get given a state it cannot own.
		 */
		setExpanded: function( expanded ) {
			// setTrigger() is the authority on what opens this panel. this.button
			// is scoped to the widget, so an element-id / element-class trigger
			// living elsewhere on the page never had its state updated.
			this.setTrigger().filter('[aria-expanded]').attr( 'aria-expanded', expanded ? 'true' : 'false' );
		},

		/**
		 * Move focus into the dialog and hold it there while it is open.
		 *
		 * Without this the panel opens behind the reading position: init() moves
		 * it to the top of the body, so a keyboard user would have to tab
		 * backwards through the whole page to reach the checkout button.
		 */
		trapFocus: function() {
			var self = this,
				$panel = this.getPanel(),
				alreadyOpen = !! this._returnFocusTo;

			if ( ! this.isDialog() || ! $panel.length ) {
				return;
			}

			// Not in the editor. There the panel is held open for styling rather
			// than opened by the visitor, and pulling focus into the preview
			// iframe every time the widget is selected would take it away from
			// the control the designer just clicked.
			if ( this.editor_preview === 'yes' ) {
				return;
			}

			// Do not overwrite the return target if the panel is already open -
			// the add to cart handler can call show() on an open panel, and by
			// then the active element is inside the dialog.
			if ( ! this._returnFocusTo ) {
				this._returnFocusTo = document.activeElement;
			}

			// The panel animates in, and focusing something still transformed off
			// screen makes the browser scroll to it. Wait for the frame after the
			// visibility class lands.
			// When show() runs on a panel that is already open and holds focus,
			// leave focus where the visitor put it.
			if ( ! alreadyOpen || ! $.contains( $panel[0], document.activeElement ) ) {
				var focusTries = 0,
					focusIn = function() {
						var $focusable = self.getFocusable(),
							target;

						if ( ! $('html').hasClass( 'pp-offcanvas-' + self.id + '-open' ) || $.contains( $panel[0], document.activeElement ) ) {
							return;
						}

						if ( $focusable.length ) {
							target = $focusable[0];
						} else {
							target = $panel.attr('tabindex', '-1')[0];
						}

						target.focus();

						// The panel's visibility transition (and a theme's
						// transition: all on buttons) can leave the target hidden
						// for a moment, which makes focus() a silent no-op.
						if ( document.activeElement !== target && ++focusTries < 20 ) {
							self._focusTimer = setTimeout( focusIn, 50 );
						}
					};

				clearTimeout( this._focusTimer );

				this._focusTimer = setTimeout( focusIn, 50 );
			}

			// Off first, so a second show() does not stack a second trap.
			$panel.off('keydown.ppOffcanvasTrap').on('keydown.ppOffcanvasTrap', function(e) {
				var $focusable, first, last;

				// Esc is not optional once focus is held inside the panel:
				// without it the trap becomes a keyboard trap (WCAG 2.1.2),
				// whatever the Esc to Close setting says. The author can still
				// switch off the document-level handler that closes the panel
				// from anywhere; this one only fires from inside it.
				if ( 'Escape' === e.key || 'Esc' === e.key || 27 === e.keyCode ) {
					e.preventDefault();
					self.close();
					return;
				}

				if ( 'Tab' !== e.key && 9 !== e.keyCode ) {
					return;
				}

				$focusable = self.getFocusable();

				if ( ! $focusable.length ) {
					e.preventDefault();
					return;
				}

				first = $focusable[0];
				last  = $focusable[ $focusable.length - 1 ];

				if ( e.shiftKey && ( e.target === first || e.target === $panel[0] ) ) {
					e.preventDefault();
					last.focus();
				} else if ( ! e.shiftKey && e.target === last ) {
					e.preventDefault();
					first.focus();
				}
			});
		},

		/**
		 * Release the trap and hand focus back to whatever opened the panel.
		 *
		 * @param {boolean} wasOpen Whether the panel was open when close() ran.
		 */
		releaseFocus: function( wasOpen ) {
			var $panel = this.getPanel(),
				returnTo = this._returnFocusTo;

			if ( ! this.isDialog() ) {
				return;
			}

			clearTimeout( this._focusTimer );
			$panel.off('keydown.ppOffcanvasTrap');

			this._returnFocusTo = null;

			// Only pull focus back when the panel really was open and still holds
			// it. close() also runs on init and on every outside click.
			if ( ! wasOpen || ! returnTo || ! $.contains( $panel[0], document.activeElement ) ) {
				return;
			}

			if ( document.body.contains( returnTo ) ) {
				returnTo.focus();
			} else {
				// setTrigger() rather than this.button, so an external
				// element-id / element-class trigger also gets focus back.
				this.setTrigger().first().trigger('focus');
			}
		},

		/**
		 * Tabbable elements inside the panel, in document order.
		 */
		getFocusable: function() {
			return this.getPanel()
				.find('a[href], button, input, select, textarea, [tabindex]')
				.filter(function() {
					return $(this).is(':visible') &&
						! this.disabled &&
						'-1' !== $(this).attr('tabindex');
				});
		},

		closeESC: function() {
			var self = this;

			if ( '' === self.settings.esc_close ) {
				return;
			}

			// menu close on ESC key
			$(document).on('keydown' + this.getNamespace(), function (e) {
				if (e.keyCode === 27) { // ESC
					self.close();
				}
			});
		},

		closeClick: function() {
			var self = this,
				$trigger;

			if ( this.toggle_source == 'element-id' && this.toggle_id != '' ) {
				$trigger = '#' + this.toggle_id;
			} else if ( this.toggle_source == 'element-class' && this.toggle_class != '' ) {
				$trigger = '.' + this.toggle_class;
			} else {
				$trigger = '.pp-offcanvas-toggle';
			}

			$(document).on('click' + this.getNamespace(), function (e) {
				var $target = $(e.target);

				if ( $target.closest('.pp-offcanvas-content, .pp-offcanvas-toggle').length > 0 ||
					$target.closest($trigger).length > 0 ) {
					return;
				}

				// While a dialog is open the page container is inert, and inert
				// elements are skipped by hit testing, so an overlay click lands on
				// <body> or <html> rather than on the container. Those also take
				// ordinary clicks on a closed page, hence the open check.
				if ( $target.is('.pp-offcanvas-container, body, html') && $('html').hasClass( 'pp-offcanvas-' + self.id + '-open' ) ) {
					self.close();
				}
			});
		},

		/**
		 * Throttled entry point for the window resize event.
		 *
		 * _resize() reads five element heights and then writes, so running it
		 * on every resize event forced a layout per event for the whole drag.
		 * Coalesce them into one run per frame. Callers that need the new
		 * height immediately - show(), toggleContent() - still call _resize()
		 * directly.
		 */
		_onResize: function() {
			var self = this;

			if ( this._resizeFrame ) {
				return;
			}

			this._resizeFrame = requestAnimationFrame(function() {
				self._resizeFrame = null;
				self._resize();
			});
		},

		_resize: function() {
			if ( ! this.cart_wrap.length ) {
				return;
			}

			var off_canvas = $('.pp-offcanvas-' + this.id),
				winHeight,
				headerHeight,
				wrapHeight,
				cartTotalHeight,
				cartButtonsHeight,
				cartMessageHeight,
				itemsHeight,
				finalItemsHeight;

			if ( off_canvas && off_canvas.length > 0 ) {
				if ( this.buttons_position === 'bottom' ) {
					winHeight = window.innerHeight;

					off_canvas.find('.pp-offcanvas-inner').css({
						'height': winHeight + 'px',
						'top': 0
					});

					// outerHeight() on an empty set is undefined, and one undefined
					// poisons the sum. The header is absent when it has no close
					// button and no title, and the total and buttons are absent
					// whenever the cart is empty.
					headerHeight = off_canvas.find('.pp-offcanvas-cart-header').outerHeight(true) || 0;
					wrapHeight = off_canvas.find('.pp-offcanvas-wrap').outerHeight() || 0;
					cartTotalHeight = off_canvas.find('.woocommerce-mini-cart__total').outerHeight() || 0;
					cartButtonsHeight = off_canvas.find('.woocommerce-mini-cart__buttons').outerHeight() || 0;
					cartMessageHeight = off_canvas.find('.pp-woo-menu-cart-message').outerHeight() || 0;

					itemsHeight = winHeight - (headerHeight + cartTotalHeight + cartButtonsHeight + cartMessageHeight);

					finalItemsHeight = itemsHeight - ( winHeight - wrapHeight );
					finalItemsHeight += 'px';
				} else {
					finalItemsHeight = 'auto';
				}

				// Write the height as a custom property on the panel rather than
				// building a <style> element and swapping it into <head>. That
				// swap invalidated style for the whole document on every resize
				// event. The property also has to live on the panel rather than
				// on .cart_list itself: WooCommerce replaces the whole of
				// .widget_shopping_cart_content through cart fragments, which
				// would take an inline style on the list with it.
				off_canvas[0].style.setProperty( '--pp-cart-items-height', finalItemsHeight );
			}
		}
	};

	/**
	 * Handler for the Offcanvas Content widget.
	 */
	var OffCanvasContentHandler = function ($scope) {
		var content_wrap = $scope.find('.pp-offcanvas-content-wrap');

		if ( content_wrap.length > 0 ) {
			new PPOffcanvasContent( $scope );
		}
	};

	/**
	 * Handler for the Woo - Off Canvas Cart widget.
	 */
	var WooOffcanvasCartHandler = function ($scope) {
		var container = $scope.find('.pp-offcanvas-cart-container');

		if ( container.length > 0 ) {
			new PPOffcanvasContent( $scope );
		}
	};

	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction( 'frontend/element_ready/pp-offcanvas-content.default', OffCanvasContentHandler );
		elementorFrontend.hooks.addAction( 'frontend/element_ready/pp-woo-offcanvas-cart.default', WooOffcanvasCartHandler );
	});

})(jQuery);