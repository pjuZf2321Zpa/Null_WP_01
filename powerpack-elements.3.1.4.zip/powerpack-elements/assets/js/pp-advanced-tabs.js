(function($) {

	PPAdvancedTabs = function( $scope )
	{
		//this.settings 	= settings;
		this.elem  = $scope;
		// Scope to this widget only, so a nested Advanced Tabs keeps its own handlers and state.
		this.elemClass  = $scope.find('.pp-advanced-tabs').first();
		this.tabs  = this._desktopTabs( this.elemClass );
		this.tabsResponsive  = this._headers( this.elemClass );
		this._init();
	};

	PPAdvancedTabs.prototype = {

		settings	: {},
		elemClass   : '',

		_init: function()
		{
			var win = $(window);

			this.tabs.click($.proxy(this._labelClick, this));
			this.tabs.on('keydown', $.proxy(this._tabsKeydown, this));

			this.tabsResponsive.click($.proxy(this._responsiveLabelClick, this));
			this.tabsResponsive.on('keydown', $.proxy(this._responsiveKeydown, this));

			this._responsiveCollapsed();
			this._syncMode();

			if(this.elem.find('.at-vertical').length > 0) {
				this._resize();
				win.off('resize' + this.elemClass);
				win.on('resize' + this.elemClass, $.proxy(this._resize, this));
			}

			win.on('resize', $.proxy(this._onResize, this));

			this._hashChange();

			$(window).on('hashchange', $.proxy( this._hashChange, this ));
			//$(window).on('resize', $.proxy( this._responsiveCollapsed, this ));
		},

		/**
		 * Desktop tabs (role="tab") of a widget.
		 *
		 * @since x.x.x
		 */
		_desktopTabs: function( wrap )
		{
			return wrap.children('.pp-tabs-labels').children('.pp-advanced-tabs-desktop-title');
		},

		/**
		 * Accordion headers of a widget.
		 *
		 * @since x.x.x
		 */
		_headers: function( wrap )
		{
			return wrap.children('.pp-tabs-panels').children('.pp-tabs-panel').children('.pp-tab-responsive');
		},

		/**
		 * Content panels of a widget.
		 *
		 * @since x.x.x
		 */
		_panels: function( wrap )
		{
			return wrap.children('.pp-tabs-panels').children('.pp-tabs-panel').children('.pp-advanced-tabs-content');
		},

		/**
		 * Whether the visitor asked the OS to reduce motion.
		 *
		 * @since x.x.x
		 */
		_reducedMotion: function()
		{
			return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
		},

		/**
		 * Re-check the tabs/accordion mode once resizing settles.
		 *
		 * @since x.x.x
		 */
		_onResize: function()
		{
			var self = this;

			clearTimeout( this.resizeTimer );
			this.resizeTimer = setTimeout( function() {
				self._syncMode();
			}, 100 );
		},

		/**
		 * Panels are tab panels named by their tab while the tablist is shown, and
		 * regions named by their accordion header once it collapses at a breakpoint.
		 *
		 * @since x.x.x
		 */
		_syncMode: function()
		{
			var self      = this,
				wrap      = this.elemClass,
				tabs      = this._desktopTabs( wrap ),
				headers   = this._headers( wrap ),
				accordion = headers.length > 0 && ! wrap.children('.pp-tabs-labels').is(':visible');

			this._panels( wrap ).each( function() {
				var panel    = $( this ),
					sel      = '[data-index="' + panel.data('index') + '"]',
					labeller = accordion ? headers.filter( sel ) : tabs.filter( sel );

				panel.attr({
					'role'            : accordion ? 'region' : 'tabpanel',
					'aria-labelledby' : labeller.attr('id')
				});
			});
		},

		_hashChange: function()
		{
			var hash = window.location.hash,
				wrap, tabs, headers, id, match, sel, trigger;

			if ( ! hash || hash.length < 2 ) {
				return;
			}

			try {
				id = decodeURIComponent( hash.substring( 1 ) );
			} catch ( err ) {
				return;
			}

			wrap    = this.elemClass;
			tabs    = this._desktopTabs( wrap );
			headers = this._headers( wrap );

			// Match the current IDs, plus the legacy "pp-advanced-tabs-title-<data-index>" links.
			match = tabs.add( headers ).filter( function() {
				return this.id === id || 'pp-advanced-tabs-title-' + $( this ).data('index') === id;
			}).first();

			if ( ! match.length ) {
				return;
			}

			sel     = '[data-index="' + match.data('index') + '"]';
			trigger = tabs.filter( sel ).is(':visible') ? tabs.filter( sel ) : headers.filter( sel );

			if ( ! trigger.hasClass('pp-tab-active') ) {
				trigger.trigger('click');
			}

			// Clear the hash without jumping to the top, so the same link works again.
			if ( window.history && window.history.replaceState ) {
				window.history.replaceState( null, '', window.location.pathname + window.location.search );
			}

			$('html, body').animate({
				scrollTop: ( wrap.offset().top - 50 ) + 'px'
			}, this._reducedMotion() ? 0 : 500 );

			if ( trigger.length ) {
				this._focusWhenLoaded( trigger[0] );
			}
		},

		/**
		 * Focus an element once the page has finished loading. Scripts that wrap the
		 * body during load (e.g. $('body').wrapInner()) re-insert the DOM, which drops
		 * any focus set before that.
		 *
		 * @since x.x.x
		 */
		_focusWhenLoaded: function( el )
		{
			var focus = function() {
				try {
					el.focus({ preventScroll: true });
				} catch ( err ) {
					el.focus();
				}
			};

			if ( 'complete' === document.readyState ) {
				focus();
			} else {
				$(window).one('load', function() {
					setTimeout( focus, 0 );
				});
			}
		},

		/**
		 * Keyboard support for the desktop tab list (WAI-ARIA Tabs pattern).
		 */
		_tabsKeydown: function(e)
		{
			var key      = e.which || e.keyCode,
				current  = $(e.currentTarget),
				tabs     = this.tabs,
				index    = tabs.index(current),
				rtl      = 'rtl' === window.getComputedStyle( current[0] ).direction,
				newIndex = null;

			if ( e.altKey || e.ctrlKey || e.metaKey ) {
				return;
			}

			// Both arrow pairs move in either orientation, Left/Right following the text direction.
			switch (key) {
				case 13: // Enter
				case 32: // Space
					e.preventDefault();
					if ( ! e.originalEvent || ! e.originalEvent.repeat ) {
						current.trigger('click');
					}
					return;
				case 35: // End
					newIndex = tabs.length - 1;
					break;
				case 36: // Home
					newIndex = 0;
					break;
				case 37: // Left arrow
					newIndex = rtl ? index + 1 : index - 1;
					break;
				case 38: // Up arrow
					newIndex = index - 1;
					break;
				case 39: // Right arrow
					newIndex = rtl ? index - 1 : index + 1;
					break;
				case 40: // Down arrow
					newIndex = index + 1;
					break;
				default:
					return;
			}

			if ( null === newIndex ) {
				return;
			}

			e.preventDefault();

			if ( newIndex < 0 ) {
				newIndex = tabs.length - 1;
			} else if ( newIndex >= tabs.length ) {
				newIndex = 0;
			}

			tabs.eq( newIndex ).trigger('focus').trigger('click');
		},

		/**
		 * Keyboard support for the responsive/accordion labels.
		 */
		_responsiveKeydown: function(e)
		{
			var key     = e.which || e.keyCode,
				current = $(e.currentTarget),
				labels  = this.tabsResponsive,
				index   = labels.index(current),
				newIndex = null;

			if ( e.altKey || e.ctrlKey || e.metaKey ) {
				return;
			}

			switch (key) {
				case 13: // Enter
				case 32: // Space
					e.preventDefault();
					if ( ! e.originalEvent || ! e.originalEvent.repeat ) {
						current.trigger('click');
					}
					return;
				case 35: // End
					newIndex = labels.length - 1;
					break;
				case 36: // Home
					newIndex = 0;
					break;
				case 38: // Up arrow
					newIndex = index - 1;
					break;
				case 40: // Down arrow
					newIndex = index + 1;
					break;
				default:
					return;
			}

			if ( null === newIndex ) {
				return;
			}

			e.preventDefault();

			if ( newIndex < 0 ) {
				newIndex = labels.length - 1;
			} else if ( newIndex >= labels.length ) {
				newIndex = 0;
			}

			labels.eq( newIndex ).trigger('focus');
		},

		_labelClick: function(e)
		{
			var label       = $(e.currentTarget),
				index       = label.data('index'),
				sel         = '[data-index="' + index + '"]',
				wrap        = this.elemClass,
				scroll_top  = wrap.data('scroll-top'),
				tabs_wrap   = label.closest('.pp-advanced-tabs-wrapper'),
				panels      = this._panels( wrap ),
				content     = panels.filter( sel );

			// Toggle the responsive icons.
			//allIcons.addClass('fa-plus');
			//icon.removeClass('fa-plus');

			// Scroll for pointer clicks only; arrow keys already keep the focused tab in view.
			if ( tabs_wrap.hasClass('at-vertical') && e.originalEvent ) {
				if ( scroll_top === 'yes' ) {
					$('html, body').animate({
						scrollTop: wrap.offset().top
					}, this._reducedMotion() ? 0 : 500 );
				}
			}

			// Finish any accordion slide and drop the inline display it leaves behind,
			// otherwise that panel stays visible after the layout switches back to tabs.
			panels.stop( true, true ).css('display', '');

			// Toggle the tabs.
			this.tabs.add( this.tabsResponsive ).add( panels ).removeClass('pp-tab-active');
			this.tabs.filter( sel ).add( this.tabsResponsive.filter( sel ) ).add( content ).addClass('pp-tab-active');

			this._syncA11y( wrap, index );

			$(document).trigger('ppe-tabs-switched', [ content ]);
		},

		/**
		 * Keep ARIA state in sync with which tab/panel is active.
		 */
		_syncA11y: function( wrap, index )
		{
			var sel = '[data-index="' + index + '"]';

			// Desktop tabs (role="tab").
			this._desktopTabs( wrap )
				.attr({
					'aria-selected' : 'false',
					'tabindex'      : '-1'
				})
				.filter( sel )
				.attr({
					'aria-selected' : 'true',
					'tabindex'      : '0'
				});

			// Responsive/accordion labels. The open one cannot be collapsed, so it is marked disabled.
			this._headers( wrap )
				.attr( 'aria-expanded', 'false' )
				.removeAttr( 'aria-disabled' )
				.filter( sel )
				.attr({
					'aria-expanded' : 'true',
					'aria-disabled' : 'true'
				});
		},

		_responsiveLabelClick: function(e)
		{
			var self            = this,
				label           = $(e.currentTarget),
				wrap            = this.elemClass,
				index           = label.data('index'),
				sel             = '[data-index="' + index + '"]',
				panels          = this._panels( wrap ),
				content         = panels.filter( sel ),
				activeContent   = panels.filter('.pp-tab-active'),
				activeIndex     = activeContent.data('index'),
				duration        = this._reducedMotion() ? 0 : 'normal';

			// Should we proceed?
			if (index === activeIndex) {
				/* activeContent.slideUp('normal');
				activeContent.removeClass('pp-tab-active');
				this.elemClass.find('.pp-tabs-panels .pp-tabs-label').removeClass('pp-tab-active');
				//$(this.elemClass + ' .pp-tabs-panels .pp-tabs-label').removeClass('pp-tab-active');
				wrap.removeClass('pp-tabs-animation'); */
				return;
			}
			if (wrap.hasClass('pp-tabs-animation')) {
				return;
			}

			// Toggle the icons.
			//allIcons.addClass('fa-plus');
			//icon.removeClass('fa-plus');

			// Run the animations. Each one clears its inline display when done, so the
			// pp-tab-active class alone decides visibility afterwards.
			wrap.addClass('pp-tabs-animation');
			activeContent.slideUp( duration, function() {
				$( this ).css('display', '');
			});

			this.tabs.add( this.tabsResponsive ).add( panels ).removeClass('pp-tab-active');
			this.tabs.filter( sel ).add( this.tabsResponsive.filter( sel ) ).add( content ).addClass('pp-tab-active');
			wrap.removeClass('pp-tabs-animation');
			content.css('display', 'none');

			// Sync ARIA state for both the accordion headers and the desktop tablist.
			this._syncA11y( wrap, index );

			content.slideDown( duration, function(){

				/* wrap.find('.pp-tab-active').removeClass('pp-tab-active');
				wrap.find('.pp-tabs-label[data-index="' + index + '"]').addClass('pp-tab-active');
				content.addClass('pp-tab-active');
				wrap.removeClass('pp-tabs-animation'); */

				content.css('display', '');

				if(label.offset().top < $(window).scrollTop() + 100) {
					$('html, body').animate({ scrollTop: label.offset().top - 100 }, self._reducedMotion() ? 0 : 500, 'swing');
				}

				$(document).trigger('ppe-tabs-switched', [ content ]);
			});
		},

		_resize: function()
		{
			this.elem.find('.at-vertical').each($.proxy(this._resizeVertical, this));
		},

		_resizeVertical: function()
		{
			var wrap    = this.elem.find('.at-vertical'),
				labels  = wrap.find('.pp-tabs-labels'),
				panels  = wrap.find('.pp-tabs-panels');

			panels.css('min-height', labels.height() + 'px');
		},

		_responsiveCollapsed: function()
		{
			if ( $(window).innerWidth() < 769 ) {
				if ( this.settings.responsiveClosed ) {
					this.elemClass.find('.pp-tabs-panels .pp-tabs-label.pp-tab-active').trigger('click');
				}
				this.elemClass.find('.pp-tabs-panels').css('visibility', 'visible');
			}
		}
	};

	var AdvancedTabsHandler = function ($scope, $) {
		new PPAdvancedTabs( $scope, $ );
	};

	$(window).on('elementor/frontend/init', function () {
        if ( elementorFrontend.isEditMode() ) {
			isEditMode = true;
		}

		elementorFrontend.hooks.addAction( 'frontend/element_ready/pp-advanced-tabs.default', AdvancedTabsHandler );
    });

})(jQuery);
