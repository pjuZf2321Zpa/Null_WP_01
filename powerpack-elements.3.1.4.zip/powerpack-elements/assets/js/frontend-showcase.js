(function($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class ShowcaseWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						carousel: '.pp-showcase-preview',
						sliderWrap: '.pp-showcase-preview-wrap',
						item: '.pp-showcase-preview-item',
						navWrap: '.pp-showcase-navigation-items',
						nav: '.pp-showcase-navigation-item-wrap',
						navButton: '.pp-showcase-navigation-item',
						videoPlay: '.pp-showcase .pp-video-play-button',
						status: '.pp-showcase-status',
					},
					slidesPerView: {
						widescreen: 3,
						desktop: 3,
						laptop: 3,
						tablet_extra: 3,
						tablet: 2,
						mobile_extra: 2,
						mobile: 1
					}
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$carousel: this.$element.find( selectors.carousel ),
					$sliderWrap: this.$element.find( selectors.sliderWrap ),
					$item: this.$element.find( selectors.item ),
					$navWrap: this.$element.find( selectors.navWrap ),
					$nav: this.$element.find( selectors.nav ),
					$navButton: this.$element.find( selectors.navButton ),
					$videoPlay: this.$element.find( selectors.videoPlay ),
					$status: this.$element.find( selectors.status ),
				};
			}

			getI18n() {
				return ( 'undefined' !== typeof ppShowcaseScript && ppShowcaseScript.i18n )
					? ppShowcaseScript.i18n
					: {};
			}

			prefersReducedMotion() {
				return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
			}

			/**
			 * Autoplay and slide animation are decorative, so an explicit system-level
			 * request for reduced motion is always honoured — there is no author opt-out.
			 */
			isMotionReduced() {
				return this.prefersReducedMotion();
			}

			getSliderSettings( prop ) {
				const data = this.elements.$carousel.data( 'slider-settings' ) || {};
				return ( prop !== undefined ) ? data[ prop ] : data;
			}

			getSlidesCount() {
				return this.elements.$nav.length;
			}

			getDeviceSlidesPerView( device ) {
				const key = 'nav_items' + ( 'desktop' === device ? '' : '_' + device );
				return Math.min( this.getSlidesCount(), +this.getElementSettings( key ) || this.getSettings( 'slidesPerView' )[ device ] );
			}

			getCurrentNavDirection() {
				const pos       = this.getSliderSettings( 'preview_position' );
				const stackOn   = this.getSliderSettings( 'preview_stack' );
				const breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

				if ( 'top' === pos || 'bottom' === pos ) {
					return 'horizontal';
				}

				if ( stackOn && breakpoints[ stackOn ] ) {
					if ( window.innerWidth <= breakpoints[ stackOn ].value ) {
						return 'horizontal';
					}
				}

				return 'vertical';
			}

			getMainSwiperOptions() {
				const es   = this.getElementSettings();
				const i18n = this.getI18n();

				const swiperOptions = {
					slidesPerView:       1,
					slidesPerGroup:      1,
					loop:                'yes' === es.infinite_loop,
					speed:               this.isMotionReduced() ? 0 : ( es.animation_speed || 600 ),
					autoHeight:          'yes' === es.adaptive_height,
					effect:              es.effect || 'slide',
					watchSlidesProgress: true,
					/*
					 * The a11y module is what makes the pagination bullets focusable
					 * and operable, and what keeps the arrow buttons' disabled state
					 * and messages in sync.
					 */
					a11y: {
						enabled:                    true,
						prevSlideMessage:           i18n.prevSlide  || 'Previous slide',
						nextSlideMessage:           i18n.nextSlide  || 'Next slide',
						firstSlideMessage:          i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:           i18n.lastSlide  || 'This is the last slide',
						paginationBulletMessage:    i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:          i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide',
					},
					keyboard: {
						enabled: true,
						onlyInViewport: true,
					},
				};

				if ( 'fade' === swiperOptions.effect ) {
					swiperOptions.fadeEffect = { crossFade: true };
				}

				if ( 'yes' === es.arrows ) {
					swiperOptions.navigation = {
						prevEl: '.pp-arrow-prev-' + this.getID(),
						nextEl: '.pp-arrow-next-' + this.getID(),
					};
				}

				if ( 'yes' === es.dots ) {
					swiperOptions.pagination = {
						el:        '.swiper-pagination-' + this.getID(),
						type:      'bullets',
						clickable: true,
					};
				}

				// Reduced motion means no self-starting movement at all.
				if ( ! this.isEdit && 'yes' === es.autoplay && ! this.isMotionReduced() ) {
					swiperOptions.autoplay = {
						delay:              es.autoplay_speed || 3000,
						// Was hard-coded false, so autoplay resumed over the visitor.
						disableOnInteraction: 'yes' === es.pause_on_interaction,
						pauseOnMouseEnter:  'yes' === es.pause_on_hover,
					};
				}

				return swiperOptions;
			}

			getNavSwiperOptions() {
				const es         = this.getElementSettings();
				const direction  = this.getCurrentNavDirection();
				const isVertical = 'vertical' === direction;

				const swiperOptions = {
					direction:                direction,
					slidesPerView:            this.getDeviceSlidesPerView( 'desktop' ),
					slidesPerGroup:           1,
					loop:                     'yes' === es.infinite_loop,
					watchSlidesProgress:      true,
					centerInsufficientSlides: 'yes' === es.nav_center_mode,
					// The nav items carry their own button role and name; Swiper's a11y
					// module would relabel them as slides on top of that.
					a11y:                     { enabled: false },
				};

				// Breakpoints apply to horizontal nav only; vertical direction is
				// handled by the destroy/reinit in onResize().
				if ( ! isVertical ) {
					const breakpointsSettings = {};
					const breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

					Object.keys( breakpoints ).forEach( breakpointName => {
						if ( 'widescreen' !== breakpointName ) {
							breakpointsSettings[ breakpoints[ breakpointName ].value ] = {
								slidesPerView:  this.getDeviceSlidesPerView( breakpointName ),
								slidesPerGroup: 1,
							};
						}
					} );

					swiperOptions.breakpoints = breakpointsSettings;
				}

				return swiperOptions;
			}


			bindEvents() {
				const es = this.getElementSettings();

				this.initSlider( 'yes' === es.scrollable_nav );

				this.initFancybox();
				this.initVideo();

				const $tabs = this.$element.closest( '.elementor-widget-n-tabs' );
				if ( $tabs.length ) {
					$tabs.on( 'click', '.e-n-tab-title', () => {
						setTimeout( () => this.refreshSwiper(), 60 );
					} );
					$tabs.on( 'keyup', '.e-n-tab-title', () => {
						setTimeout( () => this.refreshSwiper(), 60 );
					} );
				}

				$( window ).on( 'resize.pp-showcase-' + this.getID(), () => {
					this.onResize();
				} );
			}

			async initSlider( scrollableNav ) {
				const Swiper = elementorFrontend.utils.swiper;

				if ( scrollableNav ) {
					if ( 'vertical' === this.getCurrentNavDirection() ) {
						this.preSetNavHeight();
					} else {
						this.elements.$navWrap.css( 'height', '' );
					}

					this.navSwiper = await new Swiper( this.elements.$navWrap, this.getNavSwiperOptions() );

					const mainOptions  = this.getMainSwiperOptions();
					mainOptions.thumbs = { swiper: this.navSwiper };
					this.swiper        = await new Swiper( this.elements.$carousel, mainOptions );

					this.swiper.on( 'slideChange', () => {
						this.videoStop();
						this.syncNavToMain();
						this.updateNavCurrent( this.swiper.realIndex );
					} );

					this.bindNavButtons();
				} else {
					this.swiper = await new Swiper( this.elements.$carousel, this.getMainSwiperOptions() );
					this.initSliderNav();
				}

				this.swiper.on( 'slideChangeTransitionEnd', () => {
					this.updateSlideA11y();
					this.announceSlide();
				} );

				this.swiper.on( 'resize breakpoint', () => this.updateSlideA11y() );

				this.updateSlideA11y();
				this.bindAutoplayFocusPause();
			}

			/**
			 * Pause autoplay while any control inside the widget holds focus — the
			 * keyboard equivalent of the existing pause-on-hover.
			 */
			bindAutoplayFocusPause() {
				const es = this.getElementSettings();

				if ( ! this.swiper || ! this.swiper.autoplay || 'yes' !== es.autoplay || 'yes' !== es.pause_on_hover ) {
					return;
				}

				// Swiper reports a stop the same way whether we or disableOnInteraction
				// caused it, so the reason is tracked here instead.
				this.autoplayPausedByFocus = false;
				this.autoplayStoppedByUser = false;

				if ( 'yes' === es.pause_on_interaction ) {
					this.$element.on( 'click.pp-showcase', 'a, button, [role="button"], .swiper-pagination-bullet', () => {
						this.autoplayStoppedByUser = true;
					} );
				}

				this.$element.on( 'focusin.pp-showcase', () => {
					if ( this.swiper && this.swiper.autoplay && this.swiper.autoplay.running ) {
						this.swiper.autoplay.stop();
						this.autoplayPausedByFocus = true;
					}
				} );

				this.$element.on( 'focusout.pp-showcase', () => {
					if ( this.autoplayPausedByFocus && ! this.autoplayStoppedByUser && this.swiper && this.swiper.autoplay ) {
						this.swiper.autoplay.start();
					}

					this.autoplayPausedByFocus = false;
				} );
			}

			/**
			 * Keep slides that are scrolled out of view, and Swiper's loop clones,
			 * out of the tab order — otherwise focus lands on links, play buttons and
			 * whole saved templates that nobody can see, and each is announced twice.
			 */
			updateSlideA11y() {
				this.elements.$carousel.find( '.swiper-slide' ).each( function() {
					const isDuplicate = this.classList.contains( 'swiper-slide-duplicate' ),
						isActive      = this.classList.contains( 'swiper-slide-active' ) && ! isDuplicate;

					this.setAttribute( 'aria-hidden', isActive ? 'false' : 'true' );

					$( this ).find( 'a, button, iframe, video, [tabindex]' ).each( function() {
						if ( isActive ) {
							$( this ).removeAttr( 'tabindex' );
						} else {
							$( this ).attr( 'tabindex', '-1' );
						}
					} );
				} );
			}

			/**
			 * Announce the slide change. The navigation buttons, the dots and swiping
			 * all bypass Swiper's own navigation notifications, so nothing else
			 * reports which item is now showing.
			 */
			announceSlide() {
				const $status = this.elements.$status;

				if ( ! $status.length || ! this.swiper ) {
					return;
				}

				const i18n  = this.getI18n(),
					format  = i18n.status || 'Showing %s',
					$button = this.elements.$navButton.eq( this.swiper.realIndex ),
					label   = $.trim( $button.find( '.pp-showcase-navigation-title' ).first().text() )
						|| $button.attr( 'aria-label' )
						|| $.trim( $button.text() );

				if ( '' === label ) {
					return;
				}

				$status.text( format.replace( '%s', label ) );
			}

			/**
			 * Mirror the active state onto the navigation buttons. .pp-active-slide
			 * and .swiper-slide-thumb-active carry it in colour only.
			 */
			updateNavCurrent( index ) {
				this.elements.$navButton.attr( 'aria-current', 'false' );
				this.elements.$navButton.eq( index ).attr( 'aria-current', 'true' );
			}

			/**
			 * Enter and Space activate the navigation items, and Left/Right move
			 * between them as expected of a button group. They carry role="button"
			 * rather than being native buttons, so no key fires a click on its own.
			 */
			bindNavButtons() {
				const $buttons = this.elements.$navButton;

				$buttons.on( 'keydown.pp-showcase', ( e ) => {
					if ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) {
						// Space would scroll the page.
						e.preventDefault();
						$( e.currentTarget ).trigger( 'click' );
						return;
					}

					if ( 'ArrowRight' !== e.key && 'ArrowLeft' !== e.key && 'ArrowUp' !== e.key && 'ArrowDown' !== e.key ) {
						return;
					}

					e.preventDefault();

					const index = $buttons.index( e.currentTarget ),
						forward = ( 'ArrowRight' === e.key || 'ArrowDown' === e.key ),
						next    = forward ? index + 1 : index - 1;

					$buttons.eq( ( next + $buttons.length ) % $buttons.length ).trigger( 'focus' ).trigger( 'click' );
				} );
			}

			syncNavToMain() {
				if ( ! this.navSwiper ) {
					return;
				}

				const target = this.swiper.realIndex;

				if ( this.navSwiper.params.loop ) {
					this.navSwiper.slideToLoop( target );
				} else {
					this.navSwiper.slideTo( target );
				}
			}


			/**
			 * Measure one nav item's natural height by cloning it into an off-canvas
			 * isolated div (same width, no height constraints from the flex parent),
			 * then set the Swiper container height to exactly slidesPerView × itemHeight.
			 * This must be called BEFORE new Swiper() so the container has the right
			 * dimensions from the start.
			 */
			preSetNavHeight() {
				const firstWrap = this.elements.$navWrap.find( '.pp-showcase-navigation-item-wrap' ).first();
				if ( ! firstWrap.length ) {
					return;
				}

				// Clone into an off-canvas div with the same width but NO height constraints,
				// so the measurement reflects the item's true content height.
				const $measure = $( '<div>' ).css( {
					position:    'absolute',
					top:         '-9999px',
					left:        '-9999px',
					visibility:  'hidden',
					width:       this.elements.$navWrap.width() + 'px',
					height:      'auto',
					overflow:    'visible',
					pointerEvents: 'none',
				} ).appendTo( 'body' );

				const $clone = firstWrap.clone().css( {
					height:   'auto',
					position: 'static',
					display:  'block',
				} ).appendTo( $measure );

				const itemH = $clone.outerHeight( true ); // includes margins
				$measure.remove();

				if ( ! itemH ) {
					return;
				}

				const spv = Math.min( this.getSlidesCount(), this.getDeviceSlidesPerView( 'desktop' ) );
				this.elements.$navWrap.css( 'height', itemH * spv + 'px' );
			}

			initSliderNav() {
				const $nav   = this.elements.$nav;
				const swiper = this.swiper;

				$nav.removeClass( 'pp-active-slide' );
				$nav.eq( 0 ).addClass( 'pp-active-slide' );
				this.updateNavCurrent( 0 );

				swiper.on( 'slideChange', () => {
					this.videoStop();
					$nav.removeClass( 'pp-active-slide' );
					$nav.eq( swiper.realIndex ).addClass( 'pp-active-slide' );
					this.updateNavCurrent( swiper.realIndex );
				} );

				$nav.each( ( index, el ) => {
					$( el ).on( 'click', ( e ) => {
						e.preventDefault();
						if ( swiper.params.loop ) {
							swiper.slideToLoop( index );
						} else {
							swiper.slideTo( index );
						}
					} );
				} );

				this.bindNavButtons();
			}

			onResize() {
				const es = this.getElementSettings();

				if ( 'yes' === es.scrollable_nav && this.navSwiper ) {
					const newDirection = this.getCurrentNavDirection();

					if ( this.navSwiper.params.direction !== newDirection ) {
						this.navSwiper.destroy( true, true );
						this.swiper.destroy( true, true );
						this.initSlider( true );
						return;
					}
				}

				this.refreshSwiper();
			}

			refreshSwiper() {
				try {
					if ( this.swiper ) {
						this.swiper.update();
					}
					if ( this.navSwiper ) {
						this.navSwiper.update();
					}
				} catch ( err ) {}
			}

			initFancybox() {
				const showcaseId     = this.elements.$carousel.attr( 'id' ),
					lightboxSelector = '.swiper-slide:not(.swiper-slide-duplicate) .pp-showcase-item-link[data-fancybox="' + showcaseId + '"]';

				if ( $( lightboxSelector ).length > 0 ) {
					$( lightboxSelector ).fancybox( {
						loop: true
					} );
				}
			}

			initVideo() {
				let self = this;
				const videoPlaySelector = this.getSettings( 'selectors' ).videoPlay;

				// The trigger carries role="button", so Enter and Space have to be
				// wired up by hand.
				this.$element.off( 'keydown.ppShowcaseVideo' ).on( 'keydown.ppShowcaseVideo', videoPlaySelector, function( e ) {
					if ( 'Enter' !== e.key && ' ' !== e.key && 'Spacebar' !== e.key ) {
						return;
					}

					// Space would scroll the page.
					e.preventDefault();
					$( this ).trigger( 'click' );
				} );

				// Delegated, so Swiper's loop clones get the same behaviour.
				this.$element.off( 'click.ppShowcaseVideo' ).on( 'click.ppShowcaseVideo', videoPlaySelector, function( e ) {
					e.preventDefault();

					let $button     = $( this ),
						outerWrap   = $button.closest( '.pp-video' ),
						videoPlayer = $button.closest( '.pp-video-play' ).find( '.pp-video-player' );

					self.videoPlay( videoPlayer, outerWrap, $button );
				} );
			}

			videoPlay( selector, outerWrap, $button ) {
				let $iframe    = $( '<iframe/>' ),
					vidSrc     = selector.data( 'src' ),
					videoThumb = outerWrap.find( '.pp-video-thumb-wrap' );

				if ( 0 === selector.find( 'iframe' ).length ) {
					if ( outerWrap.hasClass( 'pp-video-type-youtube' ) || outerWrap.hasClass( 'pp-video-type-vimeo' ) || outerWrap.hasClass( 'pp-video-type-dailymotion' ) ) {
						$iframe.attr( 'src', vidSrc );
					}

					$iframe.attr( 'frameborder', '0' );
					$iframe.attr( 'allowfullscreen', '1' );
					$iframe.attr( 'allow', 'autoplay;encrypted-media;' );

					// An untitled frame is announced as just "frame"; this is the only
					// accessible name the player can have.
					if ( $button && $button.length ) {
						$iframe.attr( 'title', $button.data( 'frame-title' ) || this.getI18n().videoPlayer || 'Video player' );
					}

					videoThumb.hide();
					selector.append( $iframe );

					if ( $button && $button.length ) {
						// The button covers the player it just revealed, so it has to
						// go; focus follows activation into the player.
						$button.attr( 'hidden', true );
						$iframe.attr( 'tabindex', '-1' ).trigger( 'focus' );
					}

					if ( outerWrap.hasClass( 'pp-video-type-hosted' ) ) {
						let hostedVideoHtml = JSON.parse( outerWrap.data( 'hosted-html' ) );

						$iframe.on( 'load', function() {
							let hostedVideoIframe = $iframe.contents().find( 'body' );
							hostedVideoIframe.html( hostedVideoHtml );
							$iframe.contents().find( 'video' ).css( { 'width': '100%', 'height': '100%' } );
							$iframe.contents().find( 'video' ).attr( 'autoplay', 'autoplay' );
						} );
					}
				}
			}

			videoStop() {
				this.elements.$item.each( function() {
					let selector   = $( this ).find( '.pp-video-player' ),
						videoThumb = $( this ).find( '.pp-video-thumb-wrap' ),
						$iframe    = $( this ).find( 'iframe' );

					if ( selector.find( 'iframe' ).length ) {
						$iframe.remove();
						videoThumb.show();
						// The thumbnail is back, so its trigger has to come back too.
						$( this ).find( '.pp-video-play-button' ).removeAttr( 'hidden' );
					}
				} );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-showcase', ShowcaseWidget );
	} );
} )( jQuery );
