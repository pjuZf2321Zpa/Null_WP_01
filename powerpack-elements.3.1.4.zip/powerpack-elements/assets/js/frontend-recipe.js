( function( $ ) {
	'use strict';

	$( window ).on( 'elementor/frontend/init', function() {
		class RecipeWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						printButton: '.pp-recipe-print-button',
						container: '.pp-recipe-container',
					},
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );

				return {
					$printButton: this.$element.find( selectors.printButton ),
					$container: this.$element.find( selectors.container ),
				};
			}

			bindEvents() {
				this.elements.$printButton.on( 'click', this.onPrintClick.bind( this ) );
				this.elements.$printButton.on( 'keydown', this.onPrintKeydown.bind( this ) );
			}

			/**
			 * The print button is a generic element with role="button", so it does not
			 * get Enter/Space activation from the browser the way a real button does.
			 */
			onPrintKeydown( event ) {
				if ( 'Enter' !== event.key && ' ' !== event.key && 'Spacebar' !== event.key ) {
					return;
				}

				if ( event.altKey || event.ctrlKey || event.metaKey ) {
					return;
				}

				// Space scrolls the page on a non-button element.
				event.preventDefault();

				// A held key repeats keydown; open the print dialog once per press.
				if ( event.originalEvent && event.originalEvent.repeat ) {
					return;
				}

				this.printRecipe();
			}

			onPrintClick( event ) {
				event.preventDefault();

				this.printRecipe();
			}

			printRecipe() {
				if ( ! this.elements.$container.length || 'function' !== typeof $.fn.printThis ) {
					return;
				}

				this.elements.$container.printThis( {
					importCSS: true,
					importStyle: true,
					removeInline: false,
				} );

				// printThis moves focus into a detached iframe; hand it back to the trigger.
				this.elements.$printButton.trigger( 'focus' );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-recipe', RecipeWidget );
	} );
} )( jQuery );
