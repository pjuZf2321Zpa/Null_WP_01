(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class AlbumWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						album: '.pp-album',
					},
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$album: this.$element.find( selectors.album ),
				};
			}

			/**
			 * Localised strings, from ppAlbumScript.
			 *
			 * @since x.x.x
			 */
			getI18n() {
				return ( 'undefined' !== typeof ppAlbumScript && ppAlbumScript.i18n ) ? ppAlbumScript.i18n : {};
			}

			/**
			 * The request for reduced motion is always honoured; there is no author opt-out.
			 *
			 * @since x.x.x
			 */
			prefersReducedMotion() {
				return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
			}

			bindEvents() {
				this.bindA11yKeyboardActivation();
				this.initFancybox();
				this.bindElementorLightboxFocus();
			}

			/**
			 * Elementor's lightbox closes itself on Esc but leaves focus on <body>.
			 * Put it back on the album trigger once the shared modal hides.
			 *
			 * @since x.x.x
			 */
			bindElementorLightboxFocus() {
				if ( 'fancybox' === this.getElementSettings( 'lightbox_library' ) || elementorFrontend.isEditMode() ) {
					return;
				}

				this.$element.off( 'click.ppAlbumLightboxFocus' ).on( 'click.ppAlbumLightboxFocus', '.pp-album .elementor-clickable', ( event ) => {
					const trigger = event.currentTarget;

					Promise.resolve( elementorFrontend.utils.lightbox ).then( ( lightbox ) => {
						const modal = lightbox && lightbox.getModal ? lightbox.getModal() : null;

						if ( ! modal || ! modal.on ) {
							return;
						}

						// The modal is one shared dialog, so the listener removes itself.
						const onHide = () => {
							modal.off( 'hide', onHide );

							if ( document.body.contains( trigger ) ) {
								trigger.focus( { preventScroll: true } );
							}
						};

						modal.on( 'hide', onHide );
					} ).catch( () => {} );
				} );
			}

			/**
			 * The triggers are <a role="button">, so Space (and Enter, where there is
			 * no href) has to be wired up here. A native click() reaches both fancybox
			 * and Elementor's document-level lightbox handler.
			 */
			bindA11yKeyboardActivation() {
				this.$element.on( 'keydown.ppAlbum', '.pp-album [role="button"]', ( event ) => {
					if ( 'Enter' === event.key || ' ' === event.key || 'Spacebar' === event.key ) {
						event.preventDefault();
						event.currentTarget.click();
					}
				} );
			}

			initFancybox() {
				const elementSettings = this.getElementSettings();

				if ( 'fancybox' !== elementSettings.lightbox_library ) {
					return;
				}

				const i18n       = this.getI18n(),
					$album       = this.elements.$album,
					buttons      = Array.isArray( elementSettings.toolbar_buttons ) ? elementSettings.toolbar_buttons : [],
					keyboard     = 'yes' === elementSettings.keyboard,
					toolbar      = 'yes' === elementSettings.toolbar,
					reduceMotion = this.prefersReducedMotion();

				$( '[data-fancybox="' + $album.data( 'id' ) + '"]' ).fancybox( {
					loop:             'yes' === elementSettings.loop,
					arrows:           'yes' === elementSettings.arrows,
					infobar:          'yes' === elementSettings.slides_counter,
					keyboard:         keyboard,
					toolbar:          toolbar,
					buttons:          buttons,
					// With no toolbar close button there is nothing to Tab to, so the slide's own one stands in.
					smallBtn:         ! ( toolbar && buttons.includes( 'close' ) ),
					animationEffect:  reduceMotion ? false : elementSettings.lightbox_animation,
					transitionEffect: reduceMotion ? false : elementSettings.transition_effect,
					// Controls that fade out after a few idle seconds take the focused button with them.
					idleTime:         false,
					baseClass:        $album.data( 'fancybox-class' ),
					thumbs: {
						autoStart: 'yes' === elementSettings.thumbs_auto_start,
						axis:      $album.data( 'fancybox-axis' ),
					},
					lang: 'pp',
					i18n: {
						pp: {
							CLOSE:       i18n.close || 'Close',
							NEXT:        i18n.next || 'Next',
							PREV:        i18n.prev || 'Previous',
							PLAY_START:  i18n.playStart || 'Start slideshow',
							PLAY_STOP:   i18n.playStop || 'Pause slideshow',
							FULL_SCREEN: i18n.fullScreen || 'Full screen',
							THUMBS:      i18n.thumbs || 'Thumbnails',
							DOWNLOAD:    i18n.download || 'Download',
							SHARE:       i18n.share || 'Share',
							ZOOM:        i18n.zoom || 'Zoom',
						},
					},
					autoFocus: true,
					trapFocus: true,
					backFocus: true,
					onInit:       ( instance ) => this.onLightboxInit( instance, keyboard ),
					afterLoad:    ( instance, slide ) => this.labelLightboxImage( instance, slide ),
					afterShow:    ( instance ) => this.onLightboxShow( instance ),
					onThumbsShow: ( instance ) => this.labelLightboxThumbs( instance ),
					afterClose:   () => $( window ).off( 'keydown.ppAlbumLightbox' ),
				} );
			}

			/**
			 * Names the dialog, adds the status region and keeps Esc working.
			 *
			 * @since x.x.x
			 */
			onLightboxInit( instance, keyboard ) {
				if ( ! instance || ! instance.$refs || ! instance.$refs.container ) {
					return;
				}

				const $container = instance.$refs.container;

				$container.attr( {
					'aria-modal': 'true',
					'aria-label': this.elements.$album.attr( 'data-dialog-label' ) || this.getI18n().dialogLabel || 'Photo album',
				} );

				this.lightboxOpened  = false;
				this.$lightboxStatus = $( '<div class="elementor-screen-only" role="status" aria-live="polite" aria-atomic="true"></div>' ).appendTo( $container );

				// With keyboard navigation off, fancybox ignores Esc too, which would
				// leave a keyboard user with no way out of a focus-trapped dialog.
				// Bound on window, not document: fancybox's own keydown handler sits
				// on document and reads the instance, so closing it first throws.
				if ( ! keyboard ) {
					$( window ).off( 'keydown.ppAlbumLightbox' ).on( 'keydown.ppAlbumLightbox', ( event ) => {
						if ( 'Escape' === event.key || 'Esc' === event.key ) {
							event.preventDefault();
							instance.close( event );
						}
					} );
				}
			}

			/**
			 * Alt text for a slide, falling back to its position.
			 *
			 * @since x.x.x
			 */
			getImageName( instance, index ) {
				return this.getImageAlt( instance, index ) || this.getPositionText( instance, index );
			}

			/**
			 * @since x.x.x
			 */
			getImageAlt( instance, index ) {
				const slide = instance.group[ index ];

				return slide && slide.opts.$orig ? ( slide.opts.$orig.attr( 'data-alt' ) || '' ) : '';
			}

			/**
			 * @since x.x.x
			 */
			getPositionText( instance, index ) {
				return ( this.getI18n().imageOf || 'Image %1$s of %2$s' )
					.replace( '%1$s', index + 1 )
					.replace( '%2$s', instance.group.length );
			}

			/**
			 * Fancybox builds the slide image without any alt attribute.
			 *
			 * @since x.x.x
			 */
			labelLightboxImage( instance, slide ) {
				if ( 'image' !== slide.type || ! slide.$content ) {
					return;
				}

				// The low-res placeholder shown under the real image is decorative.
				if ( slide.$ghost ) {
					slide.$ghost.attr( 'alt', '' );
				}

				slide.$content.find( '.fancybox-image' ).not( slide.$ghost ).attr( 'alt', this.getImageName( instance, slide.index ) );
			}

			/**
			 * @since x.x.x
			 */
			onLightboxShow( instance ) {
				this.labelLightboxThumbs( instance );

				// Opening already announces the dialog; only announce later moves.
				if ( ! this.lightboxOpened ) {
					this.lightboxOpened = true;
					return;
				}

				if ( ! this.$lightboxStatus ) {
					return;
				}

				const index = instance.currIndex,
					alt     = this.getImageAlt( instance, index ),
					name    = this.getPositionText( instance, index ) + ( alt ? ': ' + alt : '' );

				this.$lightboxStatus.text( ( this.getI18n().status || 'Showing %s' ).replace( '%s', name ) );
			}

			/**
			 * Fancybox's thumbnails are empty links with a background image.
			 *
			 * @since x.x.x
			 */
			labelLightboxThumbs( instance ) {
				const $list = instance.Thumbs && instance.Thumbs.$list;

				if ( ! $list ) {
					return;
				}

				$list.children( 'a' ).each( ( index, thumb ) => {
					thumb.setAttribute( 'aria-label', this.getImageName( instance, index ) );

					if ( index === instance.currIndex ) {
						thumb.setAttribute( 'aria-current', 'true' );
					} else {
						thumb.removeAttribute( 'aria-current' );
					}
				} );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-album', AlbumWidget );
	} );
})(jQuery);
