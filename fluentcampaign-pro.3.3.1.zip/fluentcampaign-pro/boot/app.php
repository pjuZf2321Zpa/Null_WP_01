<?php

use FluentCampaign\App\Core\Application;
use FluentCampaign\App\Hooks\Handlers\ActivationHandler;
use FluentCampaign\App\Hooks\Handlers\DeactivationHandler;
use FluentCampaign\App\Utils\Enqueuer\Enqueue;

return function ($file) {

    register_activation_hook($file, function ($network_wide) {
        (new ActivationHandler)->handle($network_wide);
    });

    add_action('wp_insert_site', function ($new_site) {
        if (function_exists('is_plugin_active_for_network') && is_plugin_active_for_network('fluentcampaign-pro/fluentcampaign-pro.php')) {
            switch_to_blog($new_site->blog_id);
            (new ActivationHandler)->handle(false);
            restore_current_blog();
        }
    });

    register_deactivation_hook($file, function () {
        (new DeactivationHandler)->handle();
    });

    add_action('fluentcrm_loaded', function ($app) use ($file) {

        if (defined('FLUENTCRM_CORE_FRAMEWORK_VERSION') && FLUENTCRM_CORE_FRAMEWORK_VERSION == 3) {
            new Application($app, $file);

            // Core's no-conflict mode dequeues plugin assets whose slug is not listed.
            add_filter('fluent_crm_asset_listed_slugs', function ($slugs) {
                $slugs[] = 'fluentcampaign-pro';
                return $slugs;
            });

            add_action('fluentcrm_loading_app', function () {
                Enqueue::style(
                    'fluentcampaign-pro-app',
                    'admin/app.css',
                    [],
                    FLUENTCAMPAIGN_PLUGIN_VERSION
                );

                // The Reports Calendar tab. Separate from the Messaging bundle,
                // which only loads while that module is on. Older cores have no
                // import map, so the tab is skipped there rather than broken.
                if (defined('FLUENTCRM_MODULE_API') && FLUENTCRM_MODULE_API >= 1) {
                    Enqueue::script(
                        'fluentcampaign-reports',
                        'admin/reports.js',
                        ['fluentcrm_admin_app_boot'],
                        FLUENTCAMPAIGN_PLUGIN_VERSION
                    );
                }
            });

            \FluentCampaign\App\Hooks\Handlers\UpgradationHandler::maybeUpdateDbTables();

            (new \FluentCampaign\App\Modules\Messaging\MessageModule())->init($app);

            add_action('fluentcrm_after_db_migrate', function () {
                \FluentCampaign\App\Modules\Messaging\MessageMigrator::migrate();
            });

            $licenseManager = (new \FluentCampaign\App\Services\PluginManager\FluentLicensing())->register([
                'version'           => FLUENTCAMPAIGN_PLUGIN_VERSION, // Current version of your plugin
                'item_id'           => 7560867, // Product ID from FluentCart
                'settings_key'      => '__fluentcrm_campaign_license',
                'basename'          => 'fluentcampaign-pro/fluentcampaign-pro.php', // Plugin basename (e.g., 'your-plugin/your-plugin.php')
                'api_url'           => 'https://fluentapi.wpmanageninja.com/', // The API URL for license verification. Normally your store URL
                'store_url'         => 'https://wpmanageninja.com/', // Your store URL
                'purchase_url'      => 'https://fluentcrm.com/', // Purchase URL
                'account_url'       => 'https://wpmanageninja.com/account/', // Customer account dashboard
                'support_url'       => 'https://wpmanageninja.com/account/support-tickets/', // Support tickets
                'activate_url'      => admin_url('admin.php?page=fluentcrm-admin#/settings/license_management'),
                'show_check_update' => true,
                'plugin_title'      => 'FluentCRM Pro',
                // Refuse update packages that are not signed by our offline release key.
                // A site owner on a host that cannot verify can opt out in wp-config.php.
                'verify_updates'    => !(defined('FLUENTCAMPAIGN_SKIP_UPDATE_VERIFY') && FLUENTCAMPAIGN_SKIP_UPDATE_VERIFY),
            ]);

            $licenseMessage = $licenseManager->getLicenseMessages();

            if ($licenseMessage) {
                add_action('admin_notices', function () use ($licenseMessage) {
                    $class = 'notice fcrm_notice';
                    $message = $licenseMessage['message'];
                    printf('<div class="%1$s">%2$s</div>', esc_attr($class), wp_kses_post($message));
                });

                add_filter('fluent_crm/dashboard_notices', function ($notices) use ($licenseMessage) {
                    if (!empty($licenseMessage['message'])) {
                        $notices[] = '<div>' . $licenseMessage['message'] . '</div>';
                    }

                    return $notices;
                });
            }
        } else {
            // Installed FluentCRM core is below the required version.
            add_action('admin_notices', function () {
                echo '<div class="notice notice-error"><h3 style="margin: 10px 0 0;">' . esc_html__('FluentCRM Pro is not running', 'fluentcampaign-pro') . '</h3><p>';
                echo sprintf(
                    /* translators: %s is the minimum required FluentCRM version number, e.g. 2.9.0 */
                    esc_html__('FluentCampaign Pro requires FluentCRM version %s or higher. Please update FluentCRM to the latest version to use FluentCampaign Pro.', 'fluentcampaign-pro'),
                    FLUENTCRM_MIN_PRO_VERSION
                );
                echo '</p></div>';
            });
        }
    });
};
