<?php

namespace FluentCampaign\App\Http\Controllers;

use FluentCampaign\App\Models\Sequence;
use FluentCampaign\App\Models\SequenceMail;
use FluentCampaign\App\Models\SequenceTracker;
use FluentCampaign\App\Http\Controllers\Controller;
use FluentCrm\App\Models\Campaign;
use FluentCrm\App\Models\CampaignEmail;
use FluentCrm\App\Models\CampaignUrlMetric;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;
use FluentCrm\Framework\Http\Request\Request;
use FluentCrm\Framework\Validator\ValidationException;
use FluentCampaign\App\Services\ProHelper;

class SequenceController extends Controller
{
    public function sequences(Request $request)
    {
        // fc_campaigns columns. orderBy() throws on names outside ^[a-zA-Z0-9_\.]+$.
        $allowedOrderBy = [
            'id', 'parent_id', 'type', 'title', 'available_urls', 'slug',
            'status', 'template_id', 'email_subject', 'email_pre_header',
            'email_body', 'recipients_count', 'delay', 'utm_status',
            'utm_source', 'utm_medium', 'utm_campaign', 'utm_term',
            'utm_content', 'design_template', 'scheduled_at', 'settings',
            'created_by', 'created_at', 'updated_at',
        ];
        $order = strtoupper((string) $request->get('order'));
        $order = in_array($order, ['ASC', 'DESC'], true) ? $order : 'DESC';
        $orderBy = sanitize_key((string) ($request->get('orderBy') ?: 'id'));
        if (!in_array($orderBy, $allowedOrderBy, true)) {
            $orderBy = 'id';
        }

        $sequences = Sequence::orderBy($orderBy, $order);
        if (!empty($request->get('search'))) {
            $sequences = $sequences->where('title', 'LIKE', '%' . $request->get('search') . '%');
        }
        $sequences = $sequences->paginate();

        $with = $request->get('with', []);
        if (in_array('stats', $with)) {
            foreach ($sequences as $sequence) {
                $sequence->stats = $sequence->stat();
            }
        }

        return $this->sendSuccess(compact('sequences'));
    }

    public function create(Request $request)
    {
        try {
            $data = $this->validate($request->only('title'), [
                'title' => 'required|unique:fc_campaigns',
            ]);

            return $this->sendSuccess([
                'sequence' => Sequence::create($data),
                'message'  => __('Sequence has been created', 'fluentcampaign-pro')
            ]);
        } catch (ValidationException $e) {
            return $this->validationErrors($e);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $data = $this->validate($request->only(['title', 'settings', 'id']), [
                'title' => 'required'
            ]);

            $existing = Sequence::findOrFail($id);

            if (isset($data['settings']) && empty($data['settings'])) {
                unset($data['settings']);
            } else {
                $mailerSettings = Arr::get($data, 'settings.mailer_settings');
                $existingMailerSettings = Arr::get($existing->settings, 'mailer_settings', []);
                if (array_diff($existingMailerSettings, $mailerSettings)) {
                    $data['settings']['mailer_settings'] = $mailerSettings;
                    $sequenceMails = SequenceMail::where('parent_id', $id)->get();
                    foreach ($sequenceMails as $sequenceMail) {
                        $sequenceMail->updateMailerSettings($mailerSettings);
                    }
                }
            }

            $existing->fill($data)->save();

            return $this->sendSuccess([
                'sequence' => $existing,
                'message'  => __('Sequence has been updated', 'fluentcampaign-pro')
            ]);
        } catch (ValidationException $e) {
            return $this->validationErrors($e);
        }
    }

    public function duplicate(Request $request, $id)
    {
        $sequence = Sequence::findOrFail($id);

        $sequenceData = [
            'title'           => sprintf(
                /* translators: %s is the title of the email sequence being duplicated */
                __('[Duplicate] %s', 'fluentcampaign-pro'),
                $sequence->title
            ),
            'settings'        => $sequence->settings,
            'design_template' => $sequence->design_template
        ];

        $createdSequence = Sequence::create($sequenceData);

        $sequenceEmails = SequenceMail::where('parent_id', $id)
            ->orderBy('delay', 'ASC')
            ->get()->toArray();

        foreach ($sequenceEmails as $email) {
            $emailData = Arr::only($email, [
                'title',
                'type',
                'available_urls',
                'status',
                'template_id',
                'email_subject',
                'email_pre_header',
                'email_body',
                'delay',
                'utm_status',
                'utm_source',
                'utm_medium',
                'utm_campaign',
                'utm_term',
                'utm_content',
                'design_template',
                'scheduled_at',
                'settings'
            ]);

            $emailData['template_id'] = intval($emailData['template_id']);

            $emailData = array_filter($emailData);

            $emailData['parent_id'] = $createdSequence->id;

            $createdMail = SequenceMail::create($emailData);

            if ($createdMail->design_template == 'visual_builder') {
                $oldDesign = fluentcrm_get_campaign_meta($email['id'], '_visual_builder_design', true);
                fluentcrm_update_campaign_meta($createdMail->id, '_visual_builder_design', $oldDesign);
            }
        }

        return [
            'sequence' => $createdSequence,
            'message'  => __('The selected email sequence has been duplicated.', 'fluentcampaign-pro')
        ];

    }

    public function sequence(Request $request, $id)
    {
        $sequence = Sequence::find($id);
        $data['sequence'] = $sequence;
        $with = $request->get('with', []);
        if (in_array('sequence_emails', $with)) {
            $sequenceEmails = SequenceMail::where('parent_id', $id)
                ->orderBy('delay', 'ASC')
                ->get();
            if (in_array('email_stats', $with)) {
                $emailIds = $sequenceEmails->pluck('id')->toArray();
                if ($emailIds) {
                    // Batch email stats in a single GROUP BY query
                    $emailStats = fluentCrmDb()->table('fc_campaign_emails')
                        ->select('campaign_id')
                        ->selectRaw('COUNT(*) as total')
                        ->selectRaw("SUM(CASE WHEN status IN ('sent', 'bounced') THEN 1 ELSE 0 END) as sent")
                        ->selectRaw("SUM(CASE WHEN is_open = 1 THEN 1 ELSE 0 END) as views")
                        ->whereIn('campaign_id', $emailIds)
                        ->groupBy('campaign_id')
                        ->get()
                        ->keyBy('campaign_id');

                    // Batch click counts
                    $clickCounts = fluentCrmDb()->table('fc_campaign_url_metrics')
                        ->select('campaign_id')
                        ->selectRaw('COUNT(*) as total')
                        ->where('type', 'click')
                        ->whereIn('campaign_id', $emailIds)
                        ->groupBy('campaign_id')
                        ->get()
                        ->keyBy('campaign_id');

                    // Batch unsubscribe counts
                    $unsubCounts = fluentCrmDb()->table('fc_campaign_url_metrics')
                        ->select('campaign_id')
                        ->selectRaw('COUNT(DISTINCT subscriber_id) as total')
                        ->where('type', 'unsubscribe')
                        ->whereIn('campaign_id', $emailIds)
                        ->groupBy('campaign_id')
                        ->get()
                        ->keyBy('campaign_id');

                    // Batch revenue meta
                    $revenueMeta = fluentCrmDb()->table('fc_meta')
                        ->where('key', '_campaign_revenue')
                        ->where('object_type', 'FluentCrm\App\Models\Campaign')
                        ->whereIn('object_id', $emailIds)
                        ->get()
                        ->keyBy('object_id');

                    foreach ($sequenceEmails as $sequenceEmail) {
                        $stat = $emailStats[$sequenceEmail->id] ?? null;
                        $click = $clickCounts[$sequenceEmail->id] ?? null;
                        $unsub = $unsubCounts[$sequenceEmail->id] ?? null;
                        $revMeta = $revenueMeta[$sequenceEmail->id] ?? null;

                        $revs = false;
                        if ($revMeta && $revMeta->value) {
                            $revenueData = ProHelper::safeUnserialize($revMeta->value);
                            if (is_array($revenueData) || is_object($revenueData)) {
                                $amounts = [];
                                $currencies = [];
                                foreach ((array) $revenueData as $currency => $cents) {
                                    if (is_numeric($cents) && $cents && $currency !== 'orderIds') {
                                        $money = (int) $cents / 100;
                                        $amounts[] = number_format($money, (is_int($money)) ? 0 : 2);
                                        $currencies[] = $currency;
                                    }
                                }
                                if ($amounts && $currencies) {
                                    $revs = [
                                        'total' => implode(' | ', $amounts),
                                        /* translators: %s: currency codes, separated by " | " */
                                        'label' => sprintf(__('Revenue (%s)', 'fluentcampaign-pro'), implode(' | ', $currencies))
                                    ];
                                }
                            }
                        }

                        $sequenceEmail->stats = [
                            'total'         => $stat ? (int) $stat->total : 0,
                            'sent'          => $stat ? (int) $stat->sent : 0,
                            'clicks'        => $click ? (int) $click->total : 0,
                            'views'         => $stat ? (int) $stat->views : 0,
                            'unsubscribers' => $unsub ? (int) $unsub->total : 0,
                            'revenue'       => $revs
                        ];
                    }
                }
            }
            $data['sequence_emails'] = $sequenceEmails;
        }

        return $this->sendSuccess($data);
    }

    public function delete(Request $request, $id)
    {
        $this->deleteSequences([(int)$id]);

        return $this->sendSuccess([
            'message' => __('The email sequence has been deleted.', 'fluentcampaign-pro')
        ]);
    }

    public function subscribe(Request $request, $sequenceId)
    {
        $sequence = Sequence::find($sequenceId);
        if (!$sequence) {
            return $this->sendError([
                'message' => __('Email sequence could not be found', 'fluentcampaign-pro')
            ]);
        }

        // Without an email, subscribe() enrols nobody, so progress never moved and the client
        // looped forever re-posting the same batch.
        if (!SequenceMail::where('parent_id', $sequence->id)->exists()) {
            return $this->sendError([
                'message' => __('Add an email to this sequence before adding contacts.', 'fluentcampaign-pro')
            ], 422);
        }

        $page = (int)$request->get('page', 1);
        $subscribersSettings = [
            'subscribers'         => $request->get('subscribers'),
            'excludedSubscribers' => $request->get('excludedSubscribers'),
            'sending_filter'      => $request->get('sending_filter', 'list_tag'),
            'dynamic_segment'     => $request->get('dynamic_segment'),
            'advanced_filters'    => Helper::parseArrayOrJson($request->get('advanced_filters'))
        ];

        $campaign = new Campaign;

        $data = $campaign->getSubscriberIdsBySegmentSettings($subscribersSettings);

        $subscriberIds = $data['subscriber_ids'];
        $inTotal = count($subscriberIds);
        if (!count($subscriberIds)) {
            return $this->sendError([
                'message' => __('No contacts found based on your selection', 'fluentcampaign-pro')
            ]);
        }

        $alreadySubscriberIds = SequenceTracker::where('campaign_id', $sequenceId)->pluck('subscriber_id')->toArray();

        $subscriberIds = array_diff($subscriberIds, $alreadySubscriberIds);

        $totalSubscribers = count($subscriberIds);

        $processPerRequest = (int) apply_filters('fluent_crm/process_subscribers_per_request', 200);

        $subscriberIds = array_slice($subscriberIds, 0, $processPerRequest);

        $subscribers = Subscriber::whereIn('id', $subscriberIds)->get();

        $sequence->subscribe($subscribers);

        $remaining = $totalSubscribers - count($subscribers);

        if ($remaining <= 0) {
            $remaining = 0;
        }

        return $this->sendSuccess([
            'total'      => $totalSubscribers,
            'remaining'  => $remaining,
            'next_page'  => $page + 1,
            'page_total' => ceil($totalSubscribers / $processPerRequest),
            'in_total'   => $inTotal
        ]);
    }

    public function getSubscribers(Request $request, $sequenceId)
    {
        $search   = $request->getSafe('search',   'sanitize_text_field', '');
        $status   = $request->getSafe('status',   'sanitize_text_field', '');
        $sortType = strtoupper($request->getSafe('sort_type', 'sanitize_text_field', 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $allowedSortBy = ['id', 'created_at', 'status'];
        $sortBy = $request->getSafe('sort_by', 'sanitize_text_field', 'id');
        if (!in_array($sortBy, $allowedSortBy, true)) {
            $sortBy = 'id';
        }

        $query = SequenceTracker::where('campaign_id', $sequenceId)
            ->with('subscriber');

        if ($search) {
            $query->whereHas('subscriber', function ($q) use ($search) {
                $q->searchBy($search);
            });
        }

        if ($status && $status !== 'all') {
            $query->where('status', $status);
        }

        $query->orderBy($sortBy, $sortType);

        return $query->paginate();
    }

    public function deleteSubscribes(Request $request, $sequenceId)
    {
        $trackers = SequenceTracker::where('campaign_id', $sequenceId);
        if ($trackerIds = $request->get('tracker_ids', [])) {
            $trackers->whereIn('id', array_map('intval', (array)$trackerIds));
        } else if ($subscriberIds = $request->get('subscriber_ids', [])) {
            $trackers->whereIn('subscriber_id', array_map('intval', (array)$subscriberIds));
        } else {
            $trackers = null;
        }

        if ($trackers) {
            // Cancel their queued sequence emails first, as the automation action and MCP do;
            // removing only the tracker left an already-scheduled email to be sent anyway.
            $removedSubscriberIds = (clone $trackers)->pluck('subscriber_id')->toArray();
            $sequence = Sequence::find($sequenceId);
            if ($sequence && $removedSubscriberIds) {
                $sequence->unsubscribe($removedSubscriberIds);
            }
            $trackers->delete();
        }

        return [
            'message' => __('The selected contacts have been removed from this email sequence.', 'fluentcampaign-pro')
        ];

    }

    public function subscriberSequences(Request $request, $subscriberId)
    {
        $sequenceTrackers = SequenceTracker::where('subscriber_id', $subscriberId)
            ->with(['sequence', 'last_sequence', 'next_sequence'])
            ->orderBy('id', 'DESC')
            ->paginate();

        return [
            'sequence_trackers' => $sequenceTrackers
        ];
    }

    public function handleBulkAction(Request $request)
    {
        // Only the ids the user selected; there is no "every sequence" mode.
        $sequenceIds = array_map('intval', (array)$request->get('sequence_ids', []));
        $sequenceIds = array_unique(array_filter($sequenceIds));

        if (!$sequenceIds) {
            return $this->sendError([
                'message' => __('Please provide email sequence IDs', 'fluentcampaign-pro')
            ]);
        }

        $this->deleteSequences($sequenceIds);

        return $this->sendSuccess([
            'message' => __('Selected email sequences have been permanently deleted', 'fluentcampaign-pro'),
        ]);
    }

    /**
     * Delete sequences with their emails, queued emails, click metrics, campaign meta and
     * subscriber trackers, then fire fluentcrm_sequence_deleted for each.
     *
     * Shared by single and bulk delete. Bulk delete used to leave the trackers, which cron later
     * marked completed, starting "Email Sequence Completed" automations for a deleted sequence.
     *
     * @param int[] $sequenceIds
     */
    private function deleteSequences(array $sequenceIds)
    {
        Sequence::whereIn('id', $sequenceIds)->delete();
        SequenceTracker::whereIn('campaign_id', $sequenceIds)->delete();

        $sequenceCampaignIds = SequenceMail::whereIn('parent_id', $sequenceIds)->pluck('id')->toArray();
        if ($sequenceCampaignIds) {
            SequenceMail::whereIn('parent_id', $sequenceIds)->delete();
            CampaignEmail::whereIn('campaign_id', $sequenceCampaignIds)->delete();
            CampaignUrlMetric::whereIn('campaign_id', $sequenceCampaignIds)->delete();

            foreach ($sequenceCampaignIds as $sequenceCampaignId) {
                fluentcrm_delete_campaign_meta($sequenceCampaignId, '');
            }
        }

        foreach ($sequenceIds as $sequenceId) {
            do_action('fluentcrm_sequence_deleted', $sequenceId);
        }
    }

    public function reapplySequence(Request $request, $id)
    {
        $sequence = Sequence::findOrFail($id);
        $result = $sequence->reapplySequence();

        if ($result) {
            return [
                'result' => $result,
                'message' => __('Sequences have been re-applied', 'fluentcampaign-pro')
            ];
        }

        return $this->sendError([
            'message' => __('No sequences found to re-apply', 'fluentcampaign-pro')
        ]);
    }
}
