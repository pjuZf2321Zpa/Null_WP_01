<?php

namespace FluentCampaign\App\Http\Controllers;

use FluentCampaign\App\Services\PluginManager\FluentLicensing;
use FluentCampaign\App\Http\Controllers\Controller;
use FluentCrm\Framework\Http\Request\Request;
use FluentCrm\Framework\Support\Arr;

/**
 * License screen endpoints. The raw license key never reaches the browser.
 * The screen ships in FluentCRM core, so response fields may be added but never renamed.
 */
class LicenseController extends Controller
{
    /** Mask character, matching FluentLicensing::getMaskedLicenseKey(). */
    const MASK_CHAR = "\u{2022}";

    public function getStatus(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        $data = $licenseManager->getStatus(true);

        if (is_wp_error($data)) {
            return [
                'status'   => $data->get_error_code(),
                'error'    => true,
                'message'  => $data->get_error_message(),
                // Retained: older core screens read this misspelling.
                'mnessage' => $data->get_error_message(),
            ];
        }

        return $this->formatLicenseData($data, $licenseManager);
    }

    public function saveLicense(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();
        $licenseKey = sanitize_text_field($request->get('license_key'));

        $response = $licenseManager->activate($licenseKey);
        if (is_wp_error($response)) {
            return $this->sendError([
                'message'         => $response->get_error_message(),
                'remote_response' => $response,
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been updated.', 'fluentcampaign-pro')
        ];
    }

    public function deactivateLicense(Request $request)
    {
        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->deactivate();
        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message()
            ]);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been deactivated.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Shape the stored license data for the license screen.
     *
     * @param array $data
     * @param FluentLicensing $licenseManager
     * @return array
     */
    protected function formatLicenseData($data, FluentLicensing $licenseManager)
    {
        $status = Arr::get($data, 'status', 'unregistered');
        $expires = Arr::get($data, 'expires', '');
        $isLifetime = $expires === 'lifetime';

        if (empty($data['renew_url']) && in_array($status, ['expired', 'valid'], true)) {
            $data['renew_url'] = $licenseManager->getRenewUrl();
        }

        $data['purchase_url'] = $licenseManager->getConfig('purchase_url');
        $data['account_url'] = $licenseManager->getConfig('account_url');
        $data['support_url'] = $licenseManager->getConfig('support_url');

        // Fallback for the deactivate response, where the stored option is already deleted.
        $maskedKey = $licenseManager->getMaskedLicenseKey();

        if (!$maskedKey && !empty($data['license_key'])) {
            $maskedKey = $this->maskLicenseKey($data['license_key']);
        }

        $data['license_key_masked'] = $maskedKey;

        if (!empty($data['customer_email_masked'])) {
            $data['customer_email_masked'] = $this->maskEmailDomain($data['customer_email_masked']);
        }
        $data['product_title'] = !empty($data['product_title']) ? $data['product_title'] : $licenseManager->getConfig('plugin_title');
        $data['is_lifetime'] = $isLifetime;
        $data['expires_human'] = '';
        $data['days_remaining'] = null;
        $data['last_checked_human'] = '';

        $remoteGraceDays = (int)Arr::get($data, 'grace_period_days', 0);
        $data['in_grace_period'] = false;
        $data['grace_period_days'] = null;

        if (!$isLifetime && $expires && $expiresAt = strtotime($expires)) {
            $data['expires_human'] = wp_date(get_option('date_format'), $expiresAt);
            $data['days_remaining'] = (int)floor(($expiresAt - time()) / DAY_IN_SECONDS);
            $data = $this->attachGraceData($data, $expiresAt, $status, $remoteGraceDays);
        }

        if (!empty($data['last_checked']) && $lastChecked = strtotime($data['last_checked'])) {
            $data['last_checked_human'] = sprintf(
            /* translators: %s: human readable time difference, e.g. "2 mins" */
                __('%s ago', 'fluentcampaign-pro'),
                human_time_diff($lastChecked)
            );
        }

        // The activation hash is a credential. `license_key` stays masked for older core screens.
        unset($data['activation_hash']);

        if (!empty($data['license_key'])) {
            $data['license_key'] = $maskedKey;
        }

        return $data;
    }

    /**
     * Mask the domain label of an email the store already masked locally. Keeps the TLD.
     *
     * @param string $maskedEmail address as the store reported it
     * @return string
     */
    protected function maskEmailDomain($maskedEmail)
    {
        $at = strrpos($maskedEmail, '@');

        if ($at === false) {
            return $maskedEmail;
        }

        $local = substr($maskedEmail, 0, $at + 1);
        $domain = substr($maskedEmail, $at + 1);
        $dot = strpos($domain, '.');

        if ($dot === false || $dot === 0) {
            return $maskedEmail;
        }

        $label = substr($domain, 0, $dot);
        $suffix = substr($domain, $dot);

        if (strlen($label) < 2 || strpos($label, self::MASK_CHAR) !== false) {
            return $maskedEmail;
        }

        return $local . substr($label, 0, 1) . str_repeat(self::MASK_CHAR, strlen($label) - 1) . $suffix;
    }

    /**
     * Mirrors FluentLicensing::getMaskedLicenseKey() for the case where the
     * stored option is already gone but the key is still in hand.
     *
     * @param string $licenseKey
     * @return string
     */
    protected function maskLicenseKey($licenseKey)
    {
        $length = strlen($licenseKey);

        if ($length <= 8) {
            return str_repeat('•', $length);
        }

        return substr($licenseKey, 0, 4) . str_repeat('•', min($length - 8, 20)) . substr($licenseKey, -4);
    }

    /**
     * Flag a "valid" license past its expiry date as being in the store's grace window.
     * Only the flag is reported, not an end date, since the fallback length is an assumption.
     *
     * @param array $data
     * @param int $expiresAt
     * @param string $status
     * @param int $remoteGraceDays grace length from the store, 0 if none
     * @return array
     */
    protected function attachGraceData($data, $expiresAt, $status, $remoteGraceDays = 0)
    {
        if ($status !== 'valid' || $expiresAt > time()) {
            return $data;
        }

        $graceDays = $remoteGraceDays;

        if ($graceDays < 1) {
            $graceDays = (int)apply_filters('fluent_crm/license_grace_period_days', 15);
        }

        if ($graceDays < 1) {
            return $data;
        }

        $graceEndsAt = $expiresAt + ($graceDays * DAY_IN_SECONDS);

        if ($graceEndsAt <= time()) {
            return $data;
        }

        $data['in_grace_period'] = true;
        $data['grace_period_days'] = $graceDays;

        return $data;
    }
}
