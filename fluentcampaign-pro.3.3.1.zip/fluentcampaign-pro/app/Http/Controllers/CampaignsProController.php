<?php

namespace FluentCampaign\App\Http\Controllers;

use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Services\CampaignEmailSelection;
use FluentCrm\App\Models\Campaign;
use FluentCrm\App\Models\CampaignEmail;
use FluentCrm\App\Models\CampaignUrlMetric;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\Framework\Http\Request\Request;

class CampaignsProController extends Controller
{
    public function resendFailedEmails(Request $request, $campaignId)
    {
        $failedCount = CampaignEmail::where('campaign_id', $campaignId)->where('status', 'failed')->count();

        if (!$failedCount) {
            return $this->sendError([
                'message' => __('No failed campaign emails found', 'fluentcampaign-pro')
            ]);
        }

        $campaign = Campaign::withoutGlobalScopes()->findOrFail($campaignId);

        CampaignEmail::where('campaign_id', $campaignId)->where('status', 'failed')
            ->update([
                'status'       => 'scheduled',
                'note'         => __('Queued for resend after a failed attempt', 'fluentcampaign-pro'),
                'scheduled_at' => current_time('mysql')
            ]);

        $campaign->status = 'working';
        $campaign->save();

        return [
            'message' =>  sprintf(
                /* translators: %d: number of failed emails scheduled to be resent */
                _n('%d email has been scheduled to be resent.', '%d emails have been scheduled to be resent.', $failedCount, 'fluentcampaign-pro'),
                $failedCount
            )
        ];
    }

    /** Resend explicit legacy IDs or process a validated selection in bounded batches. */
    public function resendEmails(Request $request, $campaignId)
    {
        if (array_key_exists('selection', $request->all())) {
            return (new CampaignEmailSelection())->processResend($campaignId, $request->all());
        }
        $campaign = Campaign::withoutGlobalScopes()->findOrFail($campaignId);
        $emailIds = $request->get('email_ids');

        if (!$emailIds) {
            return $this->sendError([
                'message' => __('No emails found', 'fluentcampaign-pro')
            ]);
        }
        $emails = CampaignEmail::where('campaign_id', $campaignId)
            ->with('subscriber')
            ->whereIn('status', ['sent', 'failed'])
            ->whereIn('id', $emailIds)->get();

        if ($emails->isEmpty()) {
            return $this->sendError([
                'message' => __('No emails found', 'fluentcampaign-pro')
            ]);
        }

        foreach ($emails as $email) {
            if (!$email->subscriber) {
                if(count($emails) == 1) {
                    return $this->sendError([
                        'message' => __('The email could not be sent because the contact was not found.', 'fluentcampaign-pro')
                    ]);
                }
                continue;
            }
            if (!$email->email_body) {
                $email->email_body = $campaign->email_body;
            }
            if (!$email->email_body) {
                if(count($emails) == 1) {
                    return $this->sendError([
                        'message' => __('The email could not be sent because its body is empty.', 'fluentcampaign-pro')
                    ]);
                }
                continue;
            }
            $email->status = 'scheduled';
            $email->is_parsed = 0;
            $email->note = __('Manually resent', 'fluentcampaign-pro');
            $email->scheduled_at = current_time('mysql');
            $email->email_address = $email->subscriber->email;
            $email->save();
            do_action('fluentcrm_process_contact_jobs', $email->subscriber);
        }

        return [
            'message' => __('The selected emails have been queued for resend.', 'fluentcampaign-pro')
        ];
    }

    public function resendUnopenedEmails(Request $request, $campaignId)
    {
        $campaign = Campaign::withoutGlobalScopes()->findOrFail($campaignId);

        $emails = CampaignEmail::where('campaign_id', $campaignId)
            ->with('subscriber')
            ->whereIn('status', ['sent', 'failed'])
            ->where('is_open', 0) // unopened emails
            // Only contacts who can still be emailed, as with the per-row Resend: a resent email to
            // an unsubscribed or bounced contact is cancelled, wiping its "sent" record.
            ->whereHas('subscriber', function ($query) {
                $query->where('status', 'subscribed');
            })
            ->get();


        if ($emails->isEmpty()) {
            return $this->sendError([
                'message' => __('No unopened emails found', 'fluentcampaign-pro')
            ]);
        }

        foreach ($emails as $email) {
            if (!$email->subscriber) {
                if(count($emails) == 1) {
                    return $this->sendError([
                        'message' => __('The email could not be sent because the contact was not found.', 'fluentcampaign-pro')
                    ]);
                }
                continue;
            }
            if (!$email->email_body) {
                $email->email_body = $campaign->email_body;
            }
            if (!$email->email_body) {
                if(count($emails) == 1) {
                    return $this->sendError([
                        'message' => __('The email could not be sent because its body is empty.', 'fluentcampaign-pro')
                    ]);
                }
                continue;
            }
            $email->status = 'scheduled';
            $email->is_parsed = 0;
            $email->note = __('Manually resent', 'fluentcampaign-pro');
            $email->scheduled_at = current_time('mysql');
            $email->email_address = $email->subscriber->email;
            $email->save();
            do_action('fluentcrm_process_contact_jobs', $email->subscriber);
        }

        return [
            'message' => __('Unopened emails have been queued for resend.', 'fluentcampaign-pro')
        ];
    }


    /** Preserve legacy activity tagging while supporting selected campaign recipients. */
    public function doTagActions(Request $request, $campaignId)
    {
        if (array_key_exists('selection', $request->all())) {
            return (new CampaignEmailSelection())->processTags($campaignId, $request->all());
        }
        $campaign = Campaign::findOrFail($campaignId);
        if ($campaign->status != 'archived') {
            return $this->sendError([
                'message' => __('You can only do this when the campaign is archived', 'fluentcampaign-pro')
            ]);
        }

        $this->validate($request->all(), [
            'action_type'     => 'required',
            'tags'            => 'required',
            'activity_type'   => 'required',
            'processing_page' => 'required'
        ]);

        $actionType = $request->get('action_type');
        $tags = $request->get('tags');
        $activityType = $request->get('activity_type');
        $linkIds = $request->get('link_ids');

        $processingPage = intval($request->get('processing_page'));
        $limit = apply_filters('fluent_crm/campaign_action_limit', 50);
        $offset = ($processingPage - 1) * $limit;
        $subscriberIds = [];
        $count = false;
        // Let's filter our subscribers
        if ($activityType == 'email_clicked') {
            if(!$linkIds) {
                return $this->sendError([
                    'message' => __('Links are required', 'fluentcampaign-pro')
                ]);
            }

            if ($processingPage == 1) {
                $count = CampaignUrlMetric::where('campaign_id', $campaignId)
                    ->whereIn('url_id', $linkIds)
                    ->distinct()
                    ->count('subscriber_id');
            }

            $subscriberIds = CampaignUrlMetric::where('campaign_id', $campaignId)
                ->select('subscriber_id')
                ->whereIn('url_id', $linkIds)
                ->groupBy('subscriber_id')
                ->orderBy('subscriber_id', 'ASC')
                ->offset($offset)
                ->limit($limit)
                ->get()->pluck('subscriber_id')->toArray();

            $subscribers = Subscriber::whereIn('id', $subscriberIds)
                ->where('status', 'subscribed')
                ->get();
        }
        else if ($activityType == 'email_open' || $activityType == 'email_not_open') {
            $isOpenValue = 0;
            if($activityType == 'email_open') {
                $isOpenValue = 1;
            }

            $campaignEmailQuery = CampaignEmail::where('campaign_id', $campaignId)
                ->select('subscriber_id')
                ->groupBy('subscriber_id')
                ->orderBy('subscriber_id', 'ASC')
                ->where('is_open', $isOpenValue);
            if ($processingPage == 1) {
                $count = CampaignEmail::where('campaign_id', $campaignId)
                    ->where('is_open', $isOpenValue)
                    ->distinct()
                    ->count('subscriber_id');
            }

            $subscriberIds = $campaignEmailQuery->offset($offset)
                ->limit($limit)
                ->get()->pluck('subscriber_id')->toArray();

            $subscribers = Subscriber::whereIn('id', $subscriberIds)
                ->where('status', 'subscribed')
                ->get();
        }
        else {
            return $this->sendError([
                'message' => __('Invalid selection', 'fluentcampaign-pro')
            ]);
        }

        if($actionType == 'add_tags') {
            foreach ($subscribers as $subscriber) {
                $subscriber->attachTags($tags);
            }
        } else if($actionType == 'remove_tags') {
            foreach ($subscribers as $subscriber) {
                $subscriber->detachTags($tags);
            }
        }

        $totalSubscribers = count($subscribers);

        return [
            'processed_page' => $processingPage,
            'processed_contacts' => $totalSubscribers,
            // A full page of ids means there may be more, even if none on it are still subscribed.
            'has_more' => count($subscriberIds) >= $limit,
            'total_count' => $count,
            'subscriber_ids' => $subscriberIds
        ];
    }
}
