<?php

namespace FluentCampaign\App\Http\Controllers;

use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageReceiver;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCrm\App\Services\ReportingHelperTrait;
use FluentCrm\Framework\Http\Request\Request;

class ProReportController extends Controller
{
    // Same bucketing, frequency selection and zero-fill core's own reports use,
    // so the Messaging chart and the Emails chart agree at every range width.
    use ReportingHelperTrait;

    public function getTopCampaigns(Request $request)
    {
        $sortBy = sanitize_text_field($request->get('sort_by', 'open_rate'));
        $limit = intval($request->get('per_page', 10));

        $allowedSorts = ['open_rate', 'click_rate', 'total_sent'];
        $sortBy = in_array($sortBy, $allowedSorts) ? $sortBy : 'open_rate';

        $campaigns = fluentCrmDb()->table('fc_campaigns as c')
            ->select([
                'c.id',
                'c.title',
                'c.updated_at',
            ])
            ->selectRaw('COUNT(ce.id) as total_sent')
            ->selectRaw('SUM(CASE WHEN ce.is_open = 1 THEN 1 ELSE 0 END) / COUNT(ce.id) * 100 as open_rate')
            ->selectRaw('SUM(CASE WHEN ce.click_counter > 0 THEN 1 ELSE 0 END) / COUNT(ce.id) * 100 as click_rate')
            ->join('fc_campaign_emails as ce', 'c.id', '=', 'ce.campaign_id')
            ->where('c.status', 'archived')
            ->where('c.type', 'campaign')
            ->whereIn('ce.status', ['sent', 'bounced'])
            ->groupBy('c.id', 'c.title', 'c.updated_at')
            ->orderBy($sortBy, 'DESC')
            ->limit($limit)
            ->get();

        return $this->sendSuccess([
            'campaigns' => $campaigns,
            'available' => true,
        ]);
    }

    /**
     * Statuses that mean an outbound message left the building, or tried to.
     *
     * A delivery receipt overwrites `status` and only ever walks it forward
     * (Message::DELIVERY_RANK), so a delivered message is no longer `sent`.
     * Counting sends therefore means counting the whole forward set, not
     * `status = 'sent'` — that would report a well-delivered campaign as
     * having sent almost nothing.
     */
    const MESSAGING_SENT = [Message::STATUS_SENT, Message::STATUS_DELIVERED, Message::STATUS_READ];
    const MESSAGING_DELIVERED = [Message::STATUS_DELIVERED, Message::STATUS_READ];

    /**
     * Rows pulled per opt-out scan chunk. The scan is chunked rather than capped:
     * a cap would silently undercount opt-outs on a busy site, which is the one
     * thing a consent figure must not do.
     */
    const OPT_OUT_CANDIDATE_CHUNK = 500;

    /**
     * Stat-card totals for the Messaging report.
     *
     * One range scan with conditional aggregates rather than six counts, in the
     * same shape core's getEmailPerformance() returns so the cards read the
     * same way on both screens.
     */
    public function getMessagingPerformance(Request $request)
    {
        if (!MessageModule::isEnabled()) {
            return $this->sendError([
                'message' => __('Messaging is not enabled on this site.', 'fluentcampaign-pro')
            ], 404);
        }

        $channel = $this->messagingChannel($request);
        list($from, $to) = $this->messagingRange($request);

        $sent = $this->quoteStatuses(self::MESSAGING_SENT);
        $delivered = $this->quoteStatuses(self::MESSAGING_DELIVERED);
        $outbound = Message::DIRECTION_OUTBOUND;
        $inbound = Message::DIRECTION_INBOUND;
        $failed = Message::STATUS_FAILED;

        $totals = $this->messagingScope($channel, $from, $to)
            ->selectRaw("SUM(CASE WHEN direction = '$outbound' AND status IN ($sent) THEN 1 ELSE 0 END) AS sent")
            ->selectRaw("SUM(CASE WHEN direction = '$outbound' AND status IN ($delivered) THEN 1 ELSE 0 END) AS delivered")
            ->selectRaw("SUM(CASE WHEN direction = '$outbound' AND status = '$failed' THEN 1 ELSE 0 END) AS failed")
            ->selectRaw("SUM(CASE WHEN direction = '$inbound' THEN 1 ELSE 0 END) AS received")
            ->first();

        $sentCount = $totals ? (int) $totals->sent : 0;
        $deliveredCount = $totals ? (int) $totals->delivered : 0;
        $failedCount = $totals ? (int) $totals->failed : 0;
        $receivedCount = $totals ? (int) $totals->received : 0;

        // Everything terminal that was attempted outbound. Failures are added
        // rather than assumed to be a subset: a message that failed is not in
        // MESSAGING_SENT, because its status was overwritten.
        $attempted = $sentCount + $failedCount;

        return $this->sendSuccess([
            'stats' => [
                'totals'      => [
                    'attempted' => $attempted,
                    'sent'      => $sentCount,
                    'delivered' => $deliveredCount,
                    'failed'    => $failedCount,
                    'received'  => $receivedCount
                ],
                'percentages' => [
                    'delivered' => $sentCount ? round(($deliveredCount / $sentCount) * 100, 2) : 0,
                    'failed'    => $attempted ? round(($failedCount / $attempted) * 100, 2) : 0
                ]
            ]
        ]);
    }

    /**
     * Time series for the Messaging charts — one zero-filled {date: count} map
     * per requested metric, which is exactly what ChartBuilder iterates.
     *
     * Metrics are requested together rather than one per round trip so the two
     * charts cost two requests instead of four.
     */
    public function getMessagingStats(Request $request)
    {
        if (!MessageModule::isEnabled()) {
            return $this->sendError([
                'message' => __('Messaging is not enabled on this site.', 'fluentcampaign-pro')
            ], 404);
        }

        $channel = $this->messagingChannel($request);
        list($from, $to) = $this->messagingRange($request);

        $frequency = $this->getFrequency($from, $to);
        $period = $this->makeDatePeriod($from, $to, $frequency);
        list($groupBy, $orderBy) = $this->getGroupAndOrder($frequency);

        $requested = array_map('sanitize_text_field', (array) $request->get('metrics', []));
        $available = ['sent', 'failed', 'received', 'opt_outs'];
        $metrics = array_values(array_intersect($available, $requested)) ?: $available;

        $stats = [];

        foreach ($metrics as $metric) {
            if ($metric === 'opt_outs') {
                $stats[$metric] = $this->getResult($period, $this->optOutItems($channel, $from, $to, $frequency));
                continue;
            }

            $query = $this->messagingScope($channel, $from, $to);

            if ($metric === 'sent') {
                $query->where('direction', Message::DIRECTION_OUTBOUND)
                    ->whereIn('status', self::MESSAGING_SENT);
            } elseif ($metric === 'failed') {
                $query->where('direction', Message::DIRECTION_OUTBOUND)
                    ->where('status', Message::STATUS_FAILED);
            } elseif ($metric === 'received') {
                $query->where('direction', Message::DIRECTION_INBOUND);
            }

            $items = $query->select($this->prepareSelect($frequency, 'activity_at'))
                ->groupBy($groupBy)
                ->orderBy($orderBy, 'ASC')
                ->get();

            $stats[$metric] = $this->getResult($period, $items);
        }

        return $this->sendSuccess([
            'stats' => $stats
        ]);
    }

    /**
     * Raw campaign statuses folded into the four the calendar shows.
     *
     * Email (fc_campaigns) and messaging (fc_sms_campaigns) campaigns share one
     * vocabulary, so a single map covers both. Anything in flight — queued,
     * generating recipients, sending, paused — is still "scheduled" from the
     * calendar's point of view: it has a date and has not finished. `active` is
     * a recurring campaign's next run.
     *
     * A status missing from this map is passed through as-is rather than
     * guessed at: the UI only offers the editor for `draft`, so an unknown
     * state must never fold into it.
     */
    const CALENDAR_STATUSES = [
        'draft'             => 'draft',
        'pending'           => 'scheduled',
        'pending-scheduled' => 'scheduled',
        'pre-scheduled'     => 'scheduled',
        'scheduled'         => 'scheduled',
        'scheduling'        => 'scheduled',
        'processing'        => 'scheduled',
        'working'           => 'scheduled',
        'paused'            => 'scheduled',
        'active'            => 'scheduled',
        'archived'          => 'sent',
        'purged'            => 'sent',
        'failed'            => 'failed',
        'cancelled'         => 'cancelled'
    ];

    /**
     * The widest range the calendar asks for is its year view.
     */
    const CALENDAR_MAX_DAYS = 366;

    /**
     * Every campaign dated inside the range, across email and the active
     * messaging channels, for the Reports calendar.
     *
     * A campaign is dated by its scheduled_at, falling back to created_at so an
     * undated draft still lands on the day it was written. Recurring campaigns
     * contribute each email they have produced plus their next pending run.
     *
     * One flat list rather than per-day counts: the heatmap, the month grid and
     * the day drawer are all views of the same rows, and a year of campaigns is
     * small enough to send once.
     */
    public function getCampaignCalendar(Request $request)
    {
        list($from, $to) = $this->messagingRange($request);

        // Clamp rather than trust the client: every row in range is returned.
        $limit = (clone $from)->modify('+' . (self::CALENDAR_MAX_DAYS - 1) . ' days');
        if ($to > $limit) {
            $to = $limit;
        }

        $bounds = [$from->format('Y-m-d 00:00:00'), $to->format('Y-m-d 23:59:59')];

        // COALESCE(scheduled_at, created_at) BETWEEN …, written as two plain
        // range branches so an index on either column stays usable.
        $inRange = function ($query) use ($bounds) {
            $query->whereBetween('scheduled_at', $bounds)
                ->orWhere(function ($undated) use ($bounds) {
                    $undated->whereNull('scheduled_at')
                        ->whereBetween('created_at', $bounds);
                });
        };

        $types = array_map('sanitize_key', (array) $request->get('types', []));
        $wants = function ($type) use ($types) {
            return !$types || in_array($type, $types, true);
        };

        $items = [];

        if ($wants('email')) {
            $rows = fluentCrmDb()->table('fc_campaigns')
                ->select(['id', 'parent_id', 'type', 'title', 'email_subject', 'status', 'recipients_count', 'created_by'])
                ->selectRaw('COALESCE(scheduled_at, created_at) AS calendar_at')
                ->selectRaw("CASE WHEN scheduled_at IS NULL THEN 'created' ELSE 'scheduled' END AS date_source")
                ->where(function ($query) {
                    $query->whereIn('type', ['campaign', 'recurring_mail'])
                        ->orWhere(function ($next) {
                            $next->where('type', 'recurring_campaign')
                                ->where('status', 'active')
                                ->whereNotNull('scheduled_at');
                        });
                })
                ->where($inRange)
                ->get();

            foreach ($rows as $row) {
                $items[] = $this->calendarItem($row, 'email', $row->type);
            }
        }

        $channels = MessageModule::isEnabled() ? array_keys(MessageModule::activeChannels()) : [];
        $channels = array_values(array_filter($channels, $wants));

        if ($channels) {
            $rows = fluentCrmDb()->table('fc_sms_campaigns')
                ->select(['id', 'parent_id', 'type', 'title', 'status', 'recipients_count'])
                ->selectRaw("COALESCE(NULLIF(channel, ''), 'sms') AS channel")
                ->selectRaw('COALESCE(scheduled_at, created_at) AS calendar_at')
                ->selectRaw("CASE WHEN scheduled_at IS NULL THEN 'created' ELSE 'scheduled' END AS date_source")
                ->whereIn('type', fluentCrmAutoProcessSmsCampaignTypes())
                ->whereRaw("COALESCE(NULLIF(channel, ''), 'sms') IN (" . $this->quoteStatuses($channels) . ')')
                ->where($inRange)
                ->get();

            foreach ($rows as $row) {
                $items[] = $this->calendarItem($row, $row->channel, 'campaign');
            }
        }

        usort($items, function ($a, $b) {
            return strcmp($a['date'], $b['date']) ?: $a['id'] - $b['id'];
        });

        $items = $this->enrichCalendarItems($items);

        return $this->sendSuccess([
            'campaigns' => $items
        ]);
    }

    /**
     * @param object $row
     * @param string $type  email | a messaging channel slug
     * @param string $kind  campaign | recurring_mail | recurring_campaign
     */
    protected function calendarItem($row, $type, $kind)
    {
        $status = isset(self::CALENDAR_STATUSES[$row->status]) ? self::CALENDAR_STATUSES[$row->status] : $row->status;

        return [
            'id'          => (int) $row->id,
            'parent_id'   => (int) $row->parent_id,
            'type'        => $type,
            'kind'        => $kind,
            'title'       => $row->title,
            'status'      => $status,
            'raw_status'  => $row->status,
            'date'        => $row->calendar_at,
            'date_source' => $row->date_source,
            'recipients'    => (int) $row->recipients_count,
            'content_title' => $type === 'email' ? (string) $row->email_subject : (string) $row->title,
            '_created_by'   => isset($row->created_by) ? (int) $row->created_by : 0,
        ];
    }

    /**
     * Add the drawer-only subject and sender fields with a fixed number of queries.
     *
     * The year view can return hundreds of campaigns, so subjects, sender meta and
     * WordPress users are resolved as three batches rather than from calendarItem().
     */
    protected function enrichCalendarItems(array $items)
    {
        $emailIds = [];
        $messagingIds = [];
        $creatorIds = [];

        foreach ($items as $item) {
            if ($item['type'] === 'email') {
                $emailIds[] = $item['id'];
                if (in_array($item['kind'], ['recurring_campaign', 'recurring_mail'], true) && $item['_created_by']) {
                    $creatorIds[] = $item['_created_by'];
                }
            } else {
                $messagingIds[] = $item['id'];
            }
        }

        $emailIds = array_values(array_unique($emailIds));
        $messagingIds = array_values(array_unique($messagingIds));

        $subjects = [];
        if ($emailIds) {
            $subjectRows = fluentCrmDb()->table('fc_meta')
                ->select(['object_id', 'value'])
                ->where('object_type', 'FluentCrm\\App\\Models\\Subject')
                ->whereIn('object_id', $emailIds)
                ->orderBy('id', 'ASC')
                ->get();

            foreach ($subjectRows as $subject) {
                if (!isset($subjects[$subject->object_id]) && trim((string) $subject->value) !== '') {
                    $subjects[$subject->object_id] = $subject->value;
                }
            }
        }

        $senderIds = [];
        if ($emailIds || $messagingIds) {
            $senderMeta = fluentCrmDb()->table('fc_meta')
                ->select(['object_id', 'object_type', 'value'])
                ->where(function ($query) use ($emailIds, $messagingIds) {
                    if ($emailIds) {
                        $query->where(function ($email) use ($emailIds) {
                            $email->where('object_type', 'FluentCrm\\App\\Models\\Campaign')
                                ->where('key', '_campaign_sent_by')
                                ->whereIn('object_id', $emailIds);
                        });
                    }

                    if ($messagingIds) {
                        $method = $emailIds ? 'orWhere' : 'where';
                        $query->{$method}(function ($messaging) use ($messagingIds) {
                            $messaging->where('object_type', 'FluentCampaign\\App\\Modules\\SMS\\Models\\SMSCampaign')
                                ->where('key', '_sms_campaign_sent_by')
                                ->whereIn('object_id', $messagingIds);
                        });
                    }
                })
                ->get();

            foreach ($senderMeta as $meta) {
                $channel = $meta->object_type === 'FluentCrm\\App\\Models\\Campaign' ? 'email' : 'messaging';
                $key = $channel . ':' . $meta->object_id;
                $senderIds[$key] = (int) $meta->value;
            }
        }

        $users = $this->getCalendarUsers($senderIds, $creatorIds);

        foreach ($items as &$item) {
            if ($item['type'] === 'email' && isset($subjects[$item['id']])) {
                $item['content_title'] = $subjects[$item['id']];
            }

            $senderKey = ($item['type'] === 'email' ? 'email:' : 'messaging:') . $item['id'];
            $userId = $senderIds[$senderKey] ?? 0;
            $item['sent_by'] = $users[$userId] ?? null;
            $item['sent_by_source'] = $item['sent_by'] ? 'sent' : null;

            if (!$item['sent_by'] && in_array($item['kind'], ['recurring_campaign', 'recurring_mail'], true)) {
                $item['sent_by'] = $users[$item['_created_by']] ?? null;
                $item['sent_by_source'] = $item['sent_by'] ? 'created' : null;
            }

            unset($item['_created_by']);
        }
        unset($item);

        return $items;
    }

    /**
     * Resolve all sender and creator IDs into a user lookup with one query.
     */
    private function getCalendarUsers(array $senderIds, array $creatorIds)
    {
        $userIds = array_values(array_unique(array_filter(array_merge($senderIds, $creatorIds))));
        if (!$userIds) {
            return [];
        }

        $users = [];
        foreach (fluentCrmDb()->table('users')
            ->select(['ID', 'display_name', 'user_email'])
            ->whereIn('ID', $userIds)
            ->get() as $user) {
            $users[(int) $user->ID] = [
                'name'  => $user->display_name,
                'email' => $user->user_email
            ];
        }

        return $users;
    }

    /**
     * Messages inside the range, optionally narrowed to one channel.
     *
     * `activity_at` is the stored generated column COALESCE(sent_at,
     * scheduled_at, created_at) and carries its own index. It is the one axis
     * every series shares: a send is dated when it went out, an inbound when it
     * arrived, and a failure at the moment it was due — so the two charts stay
     * comparable instead of each measuring a different clock.
     *
     * The channel lives on the thread, not the message, so it is reached
     * through whereHas() — the same idiom MessageController::getAllMessages()
     * already uses to scope its status counts. That compiles to a correlated
     * EXISTS rather than a join, which matters here: prepareSelect() emits a
     * bare COUNT(id), and joining fc_message_threads would make `id` ambiguous.
     *
     * @param string $channel '' for every channel
     */
    protected function messagingScope($channel, \DateTime $from, \DateTime $to)
    {
        $query = Message::whereBetween('activity_at', [
            $from->format('Y-m-d'),
            $to->format('Y-m-d 23:59:59')
        ]);

        if ($channel) {
            $query->whereHas('thread', function ($threadQuery) use ($channel) {
                $threadQuery->where('channel', $channel);
            });
        }

        return $query;
    }

    /**
     * Inbound keyword opt-outs in range, as the {date, count} rows getResult()
     * expects.
     *
     * Consent itself carries no timestamp — MessageThread::setConsent() writes
     * it inside withoutTimestamps() on purpose, so a STOP does not shove the
     * thread to the top of the inbox rail — so the figure is derived from the
     * inbound message that caused the opt-out, which is timestamped.
     *
     * That means this counts *inbound keyword opt-outs only*. Opt-outs made
     * from the inbox or a contact profile, and bounced threads, are invisible
     * to it. The card is labelled "Opt-outs (inbound)" for that reason and must
     * not be relabelled "Unsubscribed" without giving consent a timestamp of
     * its own.
     *
     * Each inbound row is classified by the same detector the webhook acts on
     * — MessageReceiver::isOptOutMessage() for SMS,
     * WhatsAppHelper::detectKeywordIntent() for WhatsApp — rather than by rules
     * restated in SQL, so the report agrees with the webhook even on a site
     * that has filtered the keyword lists. The scan is chunked and keeps only
     * per-day counts, so memory stays bounded however wide the range; the
     * charts endpoint is the only caller, and the stat card sums its series.
     *
     * @return object[]
     */
    protected function optOutItems($channel, \DateTime $from, \DateTime $to, $frequency)
    {
        $classifiers = [
            'sms'      => function ($content) {
                return MessageReceiver::isOptOutMessage($content);
            },
            'whatsapp' => function ($content) {
                return WhatsAppHelper::detectKeywordIntent($content) === WhatsAppHelper::INTENT_OPT_OUT;
            }
        ];

        $monthly = $frequency == static::$monthly;
        $counts = [];

        foreach ($classifiers as $scanChannel => $isOptOut) {
            if ($channel && $channel !== $scanChannel) {
                continue;
            }

            $lastId = 0;

            do {
                $rows = $this->messagingScope($scanChannel, $from, $to)
                    ->where('direction', Message::DIRECTION_INBOUND)
                    ->where('id', '>', $lastId)
                    ->orderBy('id', 'ASC')
                    ->limit(self::OPT_OUT_CANDIDATE_CHUNK)
                    ->get(['id', 'content', 'activity_at']);

                foreach ($rows as $row) {
                    $lastId = (int) $row->id;

                    if (!$isOptOut((string) $row->content)) {
                        continue;
                    }

                    // Monthly buckets are keyed by their first day, matching
                    // what prepareSelect() returns for a monthly SQL series.
                    $day = substr((string) $row->activity_at, 0, 10);
                    $key = $monthly ? substr($day, 0, 7) . '-01' : $day;
                    $counts[$key] = ($counts[$key] ?? 0) + 1;
                }
            } while (count($rows) === self::OPT_OUT_CANDIDATE_CHUNK);
        }

        ksort($counts);

        $items = [];
        foreach ($counts as $date => $count) {
            $items[] = (object) ['date' => $date, 'count' => $count];
        }

        return $items;
    }

    /**
     * The channel the report is scoped to, or '' for all of them.
     *
     * Anything unrecognised widens to all channels rather than erroring: a
     * stale bookmark should show the whole picture, not an empty screen.
     */
    protected function messagingChannel(Request $request)
    {
        $channel = sanitize_text_field($request->get('channel', ''));

        return array_key_exists($channel, MessageModule::channels()) ? $channel : '';
    }

    /**
     * @return \DateTime[] [$from, $to]
     */
    protected function messagingRange(Request $request)
    {
        $range = (array) $request->get('date_range', []);

        $from = !empty($range[0]) ? sanitize_text_field($range[0]) : null;
        $to = !empty($range[1]) ? sanitize_text_field($range[1]) : null;

        return [$this->makeFromDate($from), $this->makeToDate($to)];
    }

    /**
     * Status constants for inlining into a CASE expression.
     *
     * The values are class constants, never request input, but they are quoted
     * through the database layer anyway so this cannot become an injection site
     * if someone later makes them configurable.
     */
    protected function quoteStatuses(array $statuses)
    {
        global $wpdb;

        return implode(',', array_map(function ($status) use ($wpdb) {
            return $wpdb->prepare('%s', $status);
        }, $statuses));
    }
}
