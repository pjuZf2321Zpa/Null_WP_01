<?php
/**
 * @var \FluentCrm\Framework\Foundation\Application $app
 */



(new \FluentCampaign\App\Hooks\Handlers\IntegrationHandler())->init();
(new \FluentCampaign\App\Hooks\Handlers\CampaignArchiveFront())->register();
(new \FluentCampaign\App\Hooks\Handlers\CampaignArchiveBlock())->register();
(new \FluentCampaign\App\Hooks\Handlers\FrontendPortalHandler())->register();
(new \FluentCampaign\App\Hooks\Handlers\VisualEmailBuilderHandler())->register();
(new \FluentCampaign\App\Hooks\Handlers\ExtendedSmartCodesHandler())->register();
(new \FluentCampaign\App\Hooks\Handlers\RecurringPostSmartcode())->register();

(new \FluentCampaign\App\Hooks\Handlers\SmartLinkHandler())->register();


// Register WooCommerce driver when AbandonCart fires its driver registration action
add_action('fluent_crm/abandon_cart_register_drivers', function () {
    \FluentCrm\App\Modules\AbandonCart\Drivers\DriverManager::register(
        new \FluentCampaign\App\Modules\AbandonCart\Woo\WooDriver()
    );
});

add_action('init', function () {
    (new \FluentCampaign\App\Hooks\Handlers\DynamicSegment())->init();
}, 1);

/*
 * MCP: register Pro abilities under the `fluent-crm/` namespace on `fluent_crm/mcp_loaded`.
 */
(new \FluentCampaign\App\Modules\MCP\MCPInit())->init();

/*
 * Cleanup actions
 */
$app->addAction('fluentcrm_sequence_email_deleted', 'FluentCampaign\App\Hooks\Handlers\Cleanup@deleteCampaignAssets', 10, 1);
$app->addAction('fluentcrm_sequence_deleted', 'FluentCampaign\App\Hooks\Handlers\Cleanup@deleteSequenceAssets', 10, 1);
$app->addAction('fluentcrm_after_subscribers_deleted', 'FluentCampaign\App\Hooks\Handlers\Cleanup@deleteCommerceItems', 10, 1);
$app->addAction('fluentcrm_after_subscribers_deleted', 'FluentCampaign\App\Hooks\Handlers\Cleanup@deleteMessagingData', 10, 1);

// fluentcrm_scheduled_hourly_tasks
$app->addAction('fluentcrm_scheduled_hourly_tasks', 'FluentCampaign\App\Hooks\Handlers\EmailScheduleHandler@handle');
$app->addAction('fluentcrm_scheduled_maybe_regular_tasks', 'FluentCampaign\App\Hooks\Handlers\EmailScheduleHandler@handle');

// No-op that drains jobs queued by the retired server-side contacts export.
$app->addAction('fluentcrm_prepare_contacts_csv_export_file', function () {
}, 10, 5);

$app->addAction('wp_ajax_fluentcrm_import_funnel', 'FluentCampaign\App\Hooks\Handlers\DataExporter@importFunnel');
$app->addAction('wp_ajax_fluentcrm_import_sequence', 'FluentCampaign\App\Hooks\Handlers\DataExporter@importEmailSequence');
$app->addAction('wp_ajax_fluentcrm_import_template', 'FluentCampaign\App\Hooks\Handlers\DataExporter@importEmailTemplate');
$app->addAction('wp_ajax_fluentcrm_import_email_campaign', 'FluentCampaign\App\Hooks\Handlers\DataExporter@importEmailCampaign');
$app->addAction('wp_ajax_fluentcrm_import_sms_campaign', 'FluentCampaign\App\Hooks\Handlers\DataExporter@importSMSCampaign');


// Export/Import Recurring Campaign
$app->addAction('wp_ajax_fluentcrm_import_recurring_campaigns', 'FluentCampaign\App\Hooks\Handlers\DataExporter@importRecurringCampaign');


$app->addAction('set_user_role', 'FluentCampaign\App\Hooks\Handlers\IntegrationHandler@maybeAutoAlterTags', 11, 2);
$app->addAction('add_user_role', 'FluentCampaign\App\Hooks\Handlers\IntegrationHandler@maybeAutoAlterTags', 11, 2);

$app->addAction('fluent_crm/recurring_mail_created_as_draft', 'FluentCampaign\App\Hooks\Handlers\RecurringCampaignHandler@draftMailCreated', 10, 2);

$app->addAction('wp_ajax_fluent_crm_import_dynamic_segment', 'FluentCampaign\App\Hooks\Handlers\DataExporter@importDynamicSegment');
