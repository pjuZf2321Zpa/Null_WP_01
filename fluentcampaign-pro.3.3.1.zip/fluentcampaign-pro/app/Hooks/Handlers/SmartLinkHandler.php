<?php

namespace FluentCampaign\App\Hooks\Handlers;

use FluentCampaign\App\Models\SmartLink;
use FluentCampaign\App\Services\Funnel\WpUserGuard;
use FluentCampaign\App\Services\ProHelper;
use FluentCrm\Framework\Support\Arr;

class SmartLinkHandler
{

    public function register()
    {
        add_action('fluentcrm_smartlink_clicked', [$this, 'handleClick'], 10, 1);
        // A click from a tracked email carries the email's recipient; the actions apply to them.
        add_action('fluentcrm_smartlink_clicked_direct', [$this, 'handleClick'], 10, 2);

        add_filter('fluent_crm/smartlink_by_short_url', [$this, 'getSmartLinkByShortUrl'], 10, 2);

        add_filter('fluent_crm/has_smartlink', function ($status) {
            return ProHelper::hasSmartLink();
        }, 999);

    }

    public function handleClick($slug, $contact = null)
    {

        if (!ProHelper::hasSmartLink()) {
            return;
        }

        $smartLink = SmartLink::where('short', $slug)->first();

        if (!$smartLink) {
            return;
        }

        if (!$contact) {
            $contact = fluentcrm_get_current_contact();
        }

        if (!$contact) {
            $smartLink->all_clicks = $smartLink->all_clicks + 1;
            $smartLink->save();
            wp_redirect(self::anonymousTargetUrl($smartLink->target_url));
            exit();
        }

        if ($tags = Arr::get($smartLink->actions, 'tags')) {
            $contact->attachTags($tags);
        }

        if ($lists = Arr::get($smartLink->actions, 'lists')) {
            $contact->attachLists($lists);
        }

        if ($removeTags = Arr::get($smartLink->actions, 'remove_tags')) {
            $contact->detachTags($removeTags);
        }

        if ($removeLists = Arr::get($smartLink->actions, 'remove_lists')) {
            $contact->detachLists($removeLists);
        }

        $smartLink->contact_clicks = $smartLink->contact_clicks + 1;
        $smartLink->all_clicks = $smartLink->all_clicks + 1;
        $smartLink->save();

        if (Arr::get($smartLink->actions, 'auto_login') === 'yes') {
            $this->makeAutoLogin($contact);
        }

        $targetUrl = $smartLink->target_url;

        // !== false: a target that starts with a smartcode (position 0) must be parsed too.
        if (strpos($targetUrl, '{{') !== false) {
            // we have smart codes
            $targetUrl = apply_filters('fluent_crm/parse_campaign_email_text', $targetUrl, $contact);
            $targetUrl = preg_replace_callback('/([^&=]*)=([^&]*)/', function ($matches) {
                // Decode first, so a value that was already encoded is not encoded twice. rawurldecode()
                // keeps a literal "+" (ann+shop@example.com) instead of turning it into a space.
                return $matches[1] . '=' . urlencode(rawurldecode($matches[2]));
            }, $targetUrl);
            $targetUrl = esc_url_raw($targetUrl);
        }

        do_action('fluent_crm/smart_link_clicked_by_contact', $smartLink, $contact);

        nocache_headers();
        wp_redirect($targetUrl, 307);
        exit();
    }

    /**
     * Target URL for a visitor who is not a known contact: there is no one to parse smartcodes
     * for, so each one becomes its fallback ({{contact.first_name|there}} -> "there") or nothing.
     * Only the first segment after "|" is the fallback; later ones are modifiers (|urlencode).
     *
     * @param string $targetUrl
     * @return string
     */
    public static function anonymousTargetUrl($targetUrl)
    {
        return preg_replace('/\{\{[^}|]*(?:\|([^}|]*))?[^}]*\}\}/', '$1', (string)$targetUrl);
    }

    public function getSmartLinkByShortUrl($result, $shortUrl)
    {
        if (!ProHelper::hasSmartLink()) {
            return $result;
        }

        $urlParts = wp_parse_url($shortUrl);

        $slug = '';
        // check if we have route query param
        if (isset($urlParts['query'])) {
            parse_str($urlParts['query'], $query);
            if ($query && isset($query['route']) && $query['route'] === 'smart_url' && isset($query['slug'])) {
                $slug = sanitize_text_field($query['slug']);
            } else {
                return $result;
            }
        }

        if (!$slug) {
            return $result;
        }

        return SmartLink::where('short', $slug)->first();
    }

    private function makeAutoLogin($contact)
    {
        if (is_user_logged_in()) {
            return false;
        }

        $user = get_user_by('email', $contact->email);

        if (!$user) {
            return false;
        }

        $willAllowLogin = apply_filters('fluent_crm/will_make_auto_login', did_action('fluent_crm/smart_link_verified'), $contact);
        if (!$willAllowLogin) {
            return false;
        }

        if ($this->isHighLevelUser($user) && !apply_filters('fluent_crm/enable_high_level_auto_login', false, $contact)) {
            return false;
        }

        $currentContact = fluentcrm_get_current_contact();

        if (!$currentContact || $currentContact->id != $contact->id) {
            return false;
        }

        add_filter('authenticate', array($this, 'allowProgrammaticLogin'), 10, 3);    // hook in earlier than other callbacks to short-circuit them
        $user = wp_signon(array(
                'user_login'    => $user->user_login,
                'user_password' => ''
            )
        );
        remove_filter('authenticate', array($this, 'allowProgrammaticLogin'), 10, 3);

        if ($user instanceof \WP_User) {
            wp_set_current_user($user->ID, $user->user_login);
            if (is_user_logged_in()) {
                return true;
            }
        }

        return false;
    }

    public function allowProgrammaticLogin($user, $username, $password)
    {
        return get_user_by('login', $username);
    }

    /**
     * Whether a user is too privileged for smart-link auto-login.
     *
     * publish_posts covers the default staff roles; the admin capabilities also cover custom
     * admin roles that cannot publish posts, so a forwarded email link never logs in an admin.
     */
    private function isHighLevelUser($user)
    {
        if (WpUserGuard::isAdministrator($user)) {
            return true;
        }

        foreach (['publish_posts', 'edit_users', 'promote_users', 'install_plugins'] as $capability) {
            if ($user->has_cap($capability)) {
                return true;
            }
        }

        return false;
    }

}
