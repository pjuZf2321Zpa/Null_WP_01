<?php

namespace FluentCampaign\App\Hooks\Handlers;

use FluentCrm\App\Models\Campaign;
use FluentCrm\App\Models\Meta;
use FluentCrm\App\Services\BlockParser;
use FluentCrm\App\Services\BlockParserHelper;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;

class CampaignArchiveFront
{
    public function register()
    {
        add_shortcode('fluent_crm_campaign_archives', array($this, 'handleShortcode'));
    }

    public function handleShortcode($atts)
    {
        $atts = shortcode_atts(array(
            'ids'    => '',
            'status' => '',
            'limit'  => '',
            'search' => '',
            'layout' => '',
            'columns' => '',
            'excerpt_length' => '',
            'hide_date' => '',
            'hide_excerpt' => '',
            'hide_read_more' => ''
        ), $atts);

        $layout = isset($atts['layout']) && $atts['layout'] === 'card' ? 'card' : 'list';

        // Card-only display options. The hide_* flags are "yes" or "no".
        $card = [
            'columns'        => min(4, max(1, $atts['columns'] === '' ? 3 : intval($atts['columns']))),
            'excerpt_length' => min(100, max(5, $atts['excerpt_length'] === '' ? 25 : intval($atts['excerpt_length']))),
            'hide_date'      => $atts['hide_date'] === 'yes',
            'hide_excerpt'   => $atts['hide_excerpt'] === 'yes',
            'hide_read_more' => $atts['hide_read_more'] === 'yes',
        ];

        $settings = Helper::getExperimentalSettings();
        if ($settings['campaign_archive'] != 'yes') {
            return sprintf('<p class="fc_front_error">%s</p>', __('The email newsletter archive feature is not enabled', 'fluentcampaign-pro'));
        }

        if (isset($_GET['view_newsletter'])) {
            $newsletterHash = sanitize_text_field($_GET['view_newsletter']);
            $campaign = $this->getCampaign($newsletterHash, $settings, $atts);
            if ($campaign) {
                return $this->renderSingleNewsletter($campaign);
            }

            return sprintf('<p class="fc_front_error">%s</p>', __('Email newsletter could not be found', 'fluentcampaign-pro'));
        }

        $campaigns = $this->getRecentCampaigns($settings, $atts);

        if ($campaigns->isEmpty()) {
            return sprintf('<p class="fc_front_error">%s</p>', __('No published email newsletter found', 'fluentcampaign-pro'));
        }

        return $this->renderCampaigns($campaigns, $layout, $card);
    }

    public function getRecentCampaigns($settings, $atts)
    {
        $campaigns = Campaign::orderBy('scheduled_at', 'DESC');
        $maxLimit = 200;
        $max = ($settings['campaign_max_number'] <= 0 || $settings['campaign_max_number'] > $maxLimit) ? $maxLimit : absint($settings['campaign_max_number']);

        $campaignIds = Arr::get($settings, 'campaign_ids');
        $campaignStatus = Arr::get($settings, 'campaign_status');
        $campaignSearch = Arr::get($settings, 'campaign_search');

        // Each shortcode attribute independently overrides its global setting.
        $campShortcodeIds = array_filter(array_map('intval', explode(',', $atts['ids'])));
        if (!empty($campShortcodeIds)) {
            $campaignIds = $campShortcodeIds;
        }

        if (!empty($atts['status'])) {
            $campaignStatus = $atts['status'];
        }

        if (!empty($atts['search'])) {
            $campaignSearch = $atts['search'];
        }

        // intval, not absint: a negative limit falls back to the global setting.
        $shortcodeLimit = intval($atts['limit']);
        if ($shortcodeLimit > 0) {
            $max = min($shortcodeLimit, $maxLimit);
        }

        if (!empty($campaignSearch)) {
            global $wpdb;
            $campaigns->where('title', 'LIKE', '%' . $wpdb->esc_like($campaignSearch) . '%');
        }

        if ($campaignStatus !== 'all') {
            $campaigns->where('status', $campaignStatus);
        }

        if (!empty($campaignIds)) {
            $campaigns->whereIn('id', $campaignIds);
        }

        if ($max) {
            $campaigns->limit($max);
        }
        return $campaigns->get();
    }

    protected function renderCampaigns($campaigns, $layout = 'list', $card = [])
    {
        $card = wp_parse_args($card, [
            'columns'        => 3,
            'excerpt_length' => 25,
            'hide_date'      => false,
            'hide_excerpt'   => false,
            'hide_read_more' => false,
        ]);

        $subscriber = fluentCrmApi('contacts')->getCurrentContact(true, true);

        $urlBase = apply_filters('fluent_crm/newsletter_single_permalink_base', get_the_permalink());

        $newsletters = [];
        foreach ($campaigns as $campaign) {
            $subject = $campaign->email_subject;
            if ($subscriber) {
                $subject = apply_filters('fluent_crm/parse_campaign_email_text', $subject, $subscriber, 'basic');
            }
            $campaignHash = $campaign->getHash();

            $newsletter = [
                'title'          => apply_filters('fluent_crm/newsletter_list_title_single', $subject, $campaign),
                'formatted_date' => gmdate(get_option('date_format'), strtotime($campaign->scheduled_at)),
                'date_time'      => $campaign->scheduled_at,
                'campaign_hash'  => $campaignHash,
                'permalink'      => add_query_arg([
                    'view_newsletter' => $campaignHash
                ], $urlBase)
            ];

            if ($layout === 'card' && !$card['hide_excerpt']) {
                $newsletter['excerpt'] = $this->getCampaignExcerpt($campaign, $subscriber, $card['excerpt_length']);
            }

            $newsletters[] = $newsletter;
        }

        if (!$newsletters) {
            return '';
        }

        $default = $layout === 'card'
            ? FLUENTCAMPAIGN_PLUGIN_PATH . 'app/Views/card_newsletters.php'
            : FLUENTCAMPAIGN_PLUGIN_PATH . 'app/Views/all_newsletters.php';

        $file = apply_filters('fluent_crm/newsletter_archive_template', $default, $layout);

        ob_start();
        // Included once per archive instance; overrides must not declare unguarded functions or classes.
        require $file;
        return ob_get_clean();
    }

    /**
     * Card excerpt from the pre-header, else the body, trimmed to $length words.
     * Bodies with conditional blocks and sources over 64 KiB get no excerpt.
     */
    protected function getCampaignExcerpt($campaign, $subscriber, $length = 25)
    {
        $source = (string) $campaign->email_pre_header;
        $maxSourceBytes = 64 * 1024;
        $isBody = strlen($source) <= $maxSourceBytes && !trim($source);
        if ($isBody) {
            $source = (string) $campaign->email_body;
        }

        if (strlen($source) > $maxSourceBytes) {
            $source = '';
        }

        // Caches only subscriber-neutral text, keyed on a hash of the source.
        $cacheKey = 'archive_excerpt_v1_' . $campaign->id . '_' . (int) $isBody . '_' . $length . '_' . md5($source);
        $excerpt = wp_cache_get($cacheKey, 'fluentcrm');
        if ($excerpt === false) {
            $excerpt = $isBody && Helper::hasConditionOnString($source) ? '' : $source;
            $excerpt = mb_substr(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($excerpt))), 0, $length * 30);
            wp_cache_set($cacheKey, $excerpt, 'fluentcrm', HOUR_IN_SECONDS);
        }

        $excerpt = apply_filters('fluent_crm/parse_campaign_email_text', $excerpt, $subscriber, 'basic');

        // Drop smartcodes the parser left in place, plus any cut off at the end.
        $excerpt = preg_replace(['/(?:{{|##).*?(?:}}|##)/s', '/(?:{{|##)[^{}#]*[}#]?$/'], '', wp_strip_all_tags($excerpt));

        return apply_filters('fluent_crm/newsletter_archive_item_excerpt', wp_trim_words($excerpt, $length, ''), $campaign);
    }

    protected function renderSingleNewsletter($campaign)
    {
        // FluentCRM core without anonymous-viewer rendering (older than this Pro): render as before.
        if (!method_exists(BlockParserHelper::class, 'renderForAnonymousViewer')) {
            return $this->renderSingleNewsletterBody($campaign);
        }

        // The archive is public: tag-restricted sections render as for a visitor with no tags
        // unless the viewer is an identified contact.
        return BlockParserHelper::renderForAnonymousViewer(function () use ($campaign) {
            return $this->renderSingleNewsletterBody($campaign);
        });
    }

    private function renderSingleNewsletterBody($campaign)
    {
        $subscriber = fluentCrmApi('contacts')->getCurrentContact(true, true);

        $subject = $campaign->email_subject;

        $rawTemplates = [
            'raw_html',
            'visual_builder',
            'raw_classic'
        ];

        // The cached body is subscriber-neutral, so conditional content is never cached.
        $campaignBody = (string) $campaign->email_body;
        $hasConditionalContent = Helper::hasConditionOnString($campaignBody);
        $emailBody = $hasConditionalContent ? '' : fluentcrm_get_campaign_meta($campaign->id, '_cached_email_body', true);

        if (!$emailBody) {
            if (in_array($campaign->design_template, $rawTemplates, true)) {
                $emailBody = $campaignBody;
            } else {
                $emailBody = (new BlockParser($subscriber))->parse($campaignBody);
            }
        }

        $emailBody = str_replace(['https://fonts.googleapis.com/css2', 'https://fonts.googleapis.com/css'], 'https://fonts.bunny.net/css', $emailBody);

        // The archive renders for whoever is viewing, so campaign authors only get basic smartcodes.
        if ($subscriber) {
            $emailBody = apply_filters('fluent_crm/parse_campaign_email_text', $emailBody, $subscriber, 'basic');
            $subject = apply_filters('fluent_crm/parse_campaign_email_text', $subject, $subscriber, 'basic');
        }

        $templateConfig = wp_parse_args(Arr::get($campaign->settings, 'template_config', []), Helper::getTemplateConfig($campaign->design_template, false));

        $templateData = [
            'preHeader'   => '',
            'email_body'  => $emailBody,
            'footer_text' => '',
            'config'      => $templateConfig
        ];

        $emailBody = apply_filters(
            'fluent_crm/email-design-template-' . $campaign->design_template,
            $emailBody,
            $templateData,
            $campaign,
            $subscriber
        );

        $emailBody = str_replace(['{{crm_global_email_footer}}', '{{crm_preheader_text}}'], '', $emailBody);

        $urlBase = apply_filters('fluent_crm/newsletter_single_permalink_base', get_the_permalink());
        $newsletter = [
            'title'          => $subject,
            'content'        => $emailBody,
            'formatted_date' => gmdate(get_option('date_format'), strtotime($campaign->scheduled_at)),
            'date_time'      => $campaign->scheduled_at,
            'permalink'      => $urlBase
        ];

        $newsletter = apply_filters('fluent_crm/newsletter_preview_data', $newsletter, $campaign);

        $file = apply_filters('fluent_crm/newsletter_single_template', FLUENTCAMPAIGN_PLUGIN_PATH . 'app/Views/single_newsletter.php');

        ob_start();
        require_once $file;
        return ob_get_clean();
    }

    protected function getCampaign($hash, $settings, $atts)
    {
        $campaignMeta = Meta::where('value', $hash)
            ->where('object_type', 'FluentCrm\App\Models\Campaign')
            ->where('key', '_campaign_hash')
            ->first();

        if (!$campaignMeta) {
            return false;
        }

        $campaignStatus = Arr::get($settings, 'campaign_status');
        $campaignSearch = Arr::get($settings, 'campaign_search', '');

        if (!empty($atts['status'])) {
            $campaignStatus = $atts['status'];
        }

        if (!empty($atts['search'])) {
            $campaignSearch = $atts['search'];
        }

        $campaign = Campaign::where('id', $campaignMeta->object_id);
        if (!empty($campaignStatus) && $campaignStatus !== 'all') {
            $campaign = $campaign->where('status', $campaignStatus);
        }

        if (!empty($campaignSearch)) {
            global $wpdb;
            $campaign->where('title', 'LIKE', '%' . $wpdb->esc_like($campaignSearch) . '%');
        }

        return $campaign->first();
    }
}
