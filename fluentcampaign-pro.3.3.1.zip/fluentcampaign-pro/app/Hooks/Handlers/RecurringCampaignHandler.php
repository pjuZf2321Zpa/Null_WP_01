<?php

namespace FluentCampaign\App\Hooks\Handlers;

use FluentCampaign\App\Models\RecurringCampaign;
use FluentCampaign\App\Models\RecurringMail;
use FluentCampaign\App\Services\RecurringCampaignRunner;
use FluentCrm\App\Models\Campaign;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;

class RecurringCampaignHandler
{
    const PUSH_LOCK = '_fluentcrm_lock_recurring_campaign_push';

    const PUSH_LOCK_TTL = 300;

    /**
     * Post-check times per campaign, saved by commitPostsCheck().
     *
     * @var array<int,int>
     */
    private $postsCheckedAt = [];

    /**
     * Exact CPT eligibility windows from the condition group that qualified each campaign.
     *
     * @var array<int,array<string,array{after:string,before:string}>>
     */
    private $postWindows = [];

    /**
     * Owner token of the push lock held by this runner.
     *
     * @var string
     */
    private $pushLockToken = '';

    public function maybePushNewEmailDraft()
    {
        $nextRunTimeStamp = (int) get_option('_fc_next_recurring_campaign');

        if (!$nextRunTimeStamp) {
            return false;
        }

        if(function_exists('fluentCrmRunTimeCache')) {
            if(fluentCrmRunTimeCache('RecurringCampaignHandler')) {
                return false;
            }

            fluentCrmRunTimeCache('RecurringCampaignHandler', 'yes');
        }

        $currentTimeStamp = current_time('timestamp');

        if ($nextRunTimeStamp - $currentTimeStamp > 2100) {
            return false;
        }

        // Overlapping runners (Action Scheduler, WP-Cron, the send-now loopback) both saw "no email
        // yet" and both created one, mailing the list twice. One runner at a time; a crashed one
        // releases the lock when it expires, and nothing was created, so the next run retries.
        // The token makes the lock this runner's own: a runner that outlived the TTL cannot
        // refresh or release a lock another runner has since taken.
        $this->pushLockToken = wp_generate_uuid4();
        if (!Helper::acquireDbLock(self::PUSH_LOCK, self::PUSH_LOCK_TTL, $this->pushLockToken)) {
            return false;
        }

        try {
            return $this->pushDueCampaigns();
        } finally {
            Helper::deleteDbLock(self::PUSH_LOCK, $this->pushLockToken);
        }
    }

    /**
     * Create the email for every recurring campaign that is due. Runs under PUSH_LOCK.
     *
     * @return bool|void
     */
    private function pushDueCampaigns()
    {
        $compareTime = gmdate('Y-m-d H:i:s', current_time('timestamp') + 2100);
        $campaignBatchLimit = (int)apply_filters('fluent_crm/recurring_campaign_batch_limit', 10);
        if ($campaignBatchLimit < 1) {
            $campaignBatchLimit = 1;
        }

        $campaigns = RecurringCampaign::orderBy('scheduled_at', 'ASC')
            ->where('status', 'active')
            ->where('scheduled_at', '<=', $compareTime)
            ->whereNotNull('scheduled_at')
            ->limit($campaignBatchLimit)
            ->get();

        if ($campaigns->isEmpty()) {
            RecurringCampaignRunner::setCalculatedScheduledAt();
            return false;
        }

        foreach ($campaigns as $campaign) {
            if (!Helper::refreshDbLock(self::PUSH_LOCK, $this->pushLockToken)) {
                return false; // the lock expired and another runner holds it now
            }

            $scheduledAt = $campaign->scheduled_at;
            $runSlot = $campaign->scheduled_at;
            if (!$this->willProcessCampaign($campaign)) {
                $this->commitPostsCheck($campaign);
                // A skipped campaign still advances to its next run.
                $campaign->scheduled_at = RecurringCampaignRunner::getNextScheduledAt($campaign->settings['scheduling_settings'], 7200);
                if(!$campaign->scheduled_at) {
                    $campaign->scheduled_at = NULL;
                }

                $campaign->save();
                continue;
            }

            // The audience count above can be slow on large sites; still ours before creating?
            if (!Helper::refreshDbLock(self::PUSH_LOCK, $this->pushLockToken)) {
                return false;
            }

            $this->commitPostsCheck($campaign);

            $status = 'draft';

            if (Arr::get($campaign->settings, 'scheduling_settings.send_automatically') == 'yes') {
                $status = 'pending-scheduled';
            }

            if (strtotime($scheduledAt) <= current_time('timestamp')) {
                $scheduledAt = current_time('mysql');
            }

            $editionSettings = [
                'mailer_settings'     => Arr::get($campaign->settings, 'mailer_settings', []),
                'subscribers'         => Arr::get($campaign->settings, 'subscribers_settings.subscribers', []),
                'excludedSubscribers' => Arr::get($campaign->settings, 'subscribers_settings.excludedSubscribers', []),
                'sending_filter'      => Arr::get($campaign->settings, 'subscribers_settings.sending_filter', ''),
                'dynamic_segment'     => Arr::get($campaign->settings, 'subscribers_settings.dynamic_segment', ''),
                'advanced_filters'    => Arr::get($campaign->settings, 'subscribers_settings.advanced_filters', ''),
                'template_config'     => Arr::get($campaign->settings, 'template_config', []),
                'footer_settings'     => Arr::get($campaign->settings, 'footer_settings', []),
                // The run this email was created for, even when it is sent late.
                'recurring_slot'      => $runSlot
            ];

            // The key is also an edition marker: an empty map means no CPT condition qualified it.
            $editionSettings['recurring_post_windows'] = isset($this->postWindows[$campaign->id])
                ? $this->postWindows[$campaign->id]
                : [];

            $campaignData = [
                'parent_id'        => $campaign->id,
                /* translators: %s: scheduled date and time of the recurring email */
                'title'            => sprintf(__('Recurring email at %s', 'fluentcampaign-pro'), $scheduledAt),
                'email_subject'    => $campaign->email_subject,
                'email_pre_header' => $campaign->email_pre_header,
                'email_body'       => $campaign->email_body,
                'status'           => $status,
                'template_id'      => $campaign->template_id,
                'utm_status'       => $campaign->utm_status,
                'utm_source'       => $campaign->utm_source,
                'utm_medium'       => $campaign->utm_medium,
                'utm_campaign'     => $campaign->utm_campaign,
                'utm_term'         => $campaign->utm_term,
                'utm_content'      => $campaign->utm_content,
                'scheduled_at'     => $scheduledAt,
                'created_by'       => $campaign->created_by,
                'settings'         => $editionSettings,
                'design_template'  => $campaign->design_template
            ];

            $recurringMail = RecurringMail::create($campaignData);

            $campaign->scheduled_at = RecurringCampaignRunner::getNextScheduledAt($campaign->settings['scheduling_settings'], 7200);
            if(!$campaign->scheduled_at) {
                $campaign->scheduled_at = NULL;
            }

            $campaign->save();

            do_action('fluent_crm/recurring_mail_created', $recurringMail, $campaign);
            if ($recurringMail->status === 'draft') {
                do_action('fluent_crm/recurring_mail_created_as_draft', $recurringMail, $campaign);
            }
        }

        RecurringCampaignRunner::setCalculatedScheduledAt();

        if(function_exists('fluentCrmRunTimeCache')) {
            fluentCrmRunTimeCache('RecurringCampaignHandler', false);
        }
    }

    /**
     * Whether the campaign already has an email for the period of its due run.
     *
     * One email per day, week or month, keyed by the run each email was created for
     * (settings.recurring_slot; older emails fall back to created_at). Weeks start on the
     * campaign's send day. The previous rule,
     * "anything created in the last 18 hours / 6 days / 27 days", skipped a whole run when the
     * last one went out late or the send time was moved earlier.
     *
     * @param RecurringCampaign $campaign
     * @return bool
     */
    public function hasEmailForPeriod($campaign)
    {
        if (!$campaign->scheduled_at) {
            return false;
        }

        $frequency = Arr::get($campaign->settings, 'scheduling_settings.type', 'daily');
        $weekStartsOn = strtolower((string)Arr::get($campaign->settings, 'scheduling_settings.day', 'mon'));
        $periodOf = function ($dateTime) use ($frequency, $weekStartsOn) {
            $timestamp = strtotime($dateTime);
            if ($frequency == 'monthly') {
                return gmdate('Y-m', $timestamp);
            }
            if ($frequency == 'weekly') {
                return self::weekStartingOn($timestamp, $weekStartsOn);
            }
            return gmdate('Y-m-d', $timestamp);
        };
        $period = $periodOf($campaign->scheduled_at);

        $recent = RecurringMail::where('parent_id', $campaign->id)
            ->where('created_at', '>=', gmdate('Y-m-d H:i:s', current_time('timestamp') - 40 * DAY_IN_SECONDS))
            ->get(['id', 'scheduled_at', 'created_at', 'settings']);

        foreach ($recent as $mail) {
            // Emails from before recurring_slot: created_at is when the run made them; scheduled_at
            // can be a later time an admin picked when approving a draft.
            $slot = Arr::get((array)$mail->settings, 'recurring_slot') ?: ($mail->created_at ?: $mail->scheduled_at);
            if ($slot && $periodOf($slot) === $period) {
                return true;
            }
        }

        return false;
    }

    /**
     * The week a time falls in, for weekly campaigns: weeks start on the campaign's send day
     * (not ISO Monday), so moving the send day never makes the next run share a week with the
     * last email.
     *
     * @param int    $timestamp
     * @param string $startDay mon..sun
     * @return string Y-m-d of the week's first day
     */
    private static function weekStartingOn($timestamp, $startDay)
    {
        $days = ['mon' => 1, 'tue' => 2, 'wed' => 3, 'thu' => 4, 'fri' => 5, 'sat' => 6, 'sun' => 7];
        $start = isset($days[$startDay]) ? $days[$startDay] : 1;
        $back = ((int)gmdate('N', $timestamp) - $start + 7) % 7;

        return gmdate('Y-m-d', $timestamp - $back * DAY_IN_SECONDS);
    }

    /**
     * Save the time willProcessCampaign() checked this campaign for new posts.
     *
     * Kept apart from the check: a push that loses its lock during the audience count creates
     * nothing, and must not move the next run's post window past posts it never sent.
     *
     * @param RecurringCampaign $campaign
     */
    public function commitPostsCheck($campaign)
    {
        if (isset($this->postsCheckedAt[$campaign->id])) {
            fluentcrm_update_campaign_meta($campaign->id, '_recurring_posts_checked_at', $this->postsCheckedAt[$campaign->id]);
            unset($this->postsCheckedAt[$campaign->id]);
        }
    }

    public function willProcessCampaign($campaign)
    {
        // A waiting edition (pending-scheduled) blocks the run only when it is due by then: one a
        // user approved for a later date would otherwise make every run before it be skipped.
        $exist = RecurringMail::where('parent_id', $campaign->id)
            ->where(function ($query) use ($campaign) {
                $query->whereIn('status', ['draft', 'processing', 'pre-scheduled', 'scheduled', 'working']);
                $query->orWhere(function ($waiting) use ($campaign) {
                    $waiting->where('status', 'pending-scheduled');
                    if ($campaign->scheduled_at) {
                        $waiting->where(function ($due) use ($campaign) {
                            $due->whereNull('scheduled_at')->orWhere('scheduled_at', '<=', $campaign->scheduled_at);
                        });
                    }
                });
            })
            ->first();

        if ($exist) {
            return false;
        }

        if ($this->hasEmailForPeriod($campaign)) {
            return false;
        }

        $subscribersSettings = [
            'mailer_settings'     => Arr::get($campaign->settings, 'mailer_settings', []),
            'subscribers'         => Arr::get($campaign->settings, 'subscribers_settings.subscribers', []),
            'excludedSubscribers' => Arr::get($campaign->settings, 'subscribers_settings.excludedSubscribers', []),
            'sending_filter'      => Arr::get($campaign->settings, 'subscribers_settings.sending_filter', ''),
            'dynamic_segment'     => Arr::get($campaign->settings, 'subscribers_settings.dynamic_segment', ''),
            'advanced_filters'    => Arr::get($campaign->settings, 'subscribers_settings.advanced_filters', ''),
            'template_config'     => Arr::get($campaign->settings, 'template_config', [])
        ];

        $count = (new Campaign())->getSubscriberIdsCountBySegmentSettings($subscribersSettings);

        if (!$count) {
            return false;
        }

        $conditions = Arr::get($campaign->settings, 'sending_conditions', []);
        $this->postWindows[$campaign->id] = [];

        if (!$conditions) {
            return true;
        }

        $hadCondition = false;

        // Saved by commitPostsCheck() once the push still holds its lock, so the next run's post
        // window starts where this one ends.
        $checkedAt = current_time('timestamp');
        $lastCheckedAt = (int)fluentcrm_get_campaign_meta($campaign->id, '_recurring_posts_checked_at', true);
        $this->postsCheckedAt[$campaign->id] = $checkedAt;

        foreach ($conditions as $conditionBlock) {
            if (empty($conditionBlock)) {
                continue;
            }

            $hadCondition = true;

            $isPassed = true;
            $conditionPostWindows = [];
            foreach ($conditionBlock as $condition) {
                $isPassed = RecurringCampaignRunner::assessCondition($condition, $lastCheckedAt, $checkedAt);
                if (!$isPassed) {
                    break;
                }

                if (Arr::get($condition, 'object_type') === 'cpt') {
                    $postType = sanitize_key(Arr::get($condition, 'object_name'));
                    // Match the smartcode's existing first-condition rule when a type is repeated.
                    if ($postType && !isset($conditionPostWindows[$postType])) {
                        $conditionPostWindows[$postType] = RecurringCampaignRunner::resolveConditionWindow($condition, $lastCheckedAt, $checkedAt);
                    }
                }
            }

            if ($isPassed) {
                $this->postWindows[$campaign->id] = $conditionPostWindows;
                return true;
            }
        }

        if (!$hadCondition) {
            return true;
        }

        return false;
    }

    public function draftMailCreated($recurringMail, $campaign)
    {
        $globalSettings = fluentcrmGetGlobalSettings('business_settings');

        $adminEmail = Arr::get($globalSettings, 'admin_email', '');

        if(!$adminEmail) {
            return;
        }

        $adminEmail = str_replace('{{wp.admin_email}}', get_bloginfo('admin_email'), $adminEmail);

        if(!$adminEmail) {
            return;
        }

        $campaignUrl = fluentcrm_menu_url_base() . 'email/recurring-campaigns/emails/' . $campaign->id . '/history';

        /* translators: %s: site name */
        $subject = sprintf(__('A new draft recurring email is ready to review on %s', 'fluentcampaign-pro'), get_bloginfo('name'));

        /* translators: %s: site name */
        $line1 = sprintf(__('A new draft email for your recurring campaign is ready to review on %s.', 'fluentcampaign-pro'), get_bloginfo('name'));

        $message = '<p style="font-family: Arial, sans-serif; font-size: 16px; line-height: 22px; color: #333333;">' . __('Hello there,', 'fluentcampaign-pro') . '</p>';
        $message .= '<p style="font-family: Arial, sans-serif; font-size: 16px; line-height: 22px; color: #333333;">' . $line1 . '</p>';
        $message .= '<p style="font-family: Arial, sans-serif; font-size: 16px; line-height: 18px; color: #333333;"><b>' . __('Campaign Name:', 'fluentcampaign-pro') . '</b> ' . $campaign->title . '</p>';
        $message .= '<p style="font-family: Arial, sans-serif; font-size: 16px; line-height: 18px; color: #333333;"><b>' . __('Email Subject:', 'fluentcampaign-pro') . '</b> ' . $recurringMail->email_subject . '</p>';
        $message .= '<p style="font-family: Arial, sans-serif; font-size: 16px; line-height: 22px; color: #333333;">' . __('Click the button below to review and approve the campaign:', 'fluentcampaign-pro') . '</p>';
        $message .= '<p style="text-align: center; margin-top: 20px; margin-bottom: 20px;">
                    <a href="' . $campaignUrl . '" target="_blank" style="display: inline-block;color: #ffffff; background-color: #a245ff; font-size: 16px; border-radius: 5px; text-decoration: none; font-weight: normal; font-style: normal; padding: 0.8rem 1rem; border-color: #0072ff;">' . __('Review and Schedule Campaign', 'fluentcampaign-pro') . '</a>
                </p>';

        $headers = array('Content-Type: text/html; charset=UTF-8');
        $message = $this->withTemplate([
            'body'  => $message,
            'show_footer' => true,
            'pre_header' => __('A new draft recurring email is available', 'fluentcampaign-pro')
        ]);

        \wp_mail($adminEmail, $subject, $message, $headers);
    }


    private function withTemplate($data)
    {
        extract($data, EXTR_SKIP);
        $file = apply_filters('fluent_crm/notification_template_file', FLUENTCAMPAIGN_PLUGIN_PATH . 'app/Views/generic_notification.php');

        ob_start();
        require_once $file;
        return ob_get_clean();
    }

}
