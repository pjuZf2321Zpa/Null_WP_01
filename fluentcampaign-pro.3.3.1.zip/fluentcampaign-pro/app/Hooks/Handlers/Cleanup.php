<?php

namespace FluentCampaign\App\Hooks\Handlers;

use FluentCampaign\App\Models\SequenceMail;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\Services\PhoneMatcher;
use FluentCampaign\App\Services\Commerce\Commerce;
use FluentCampaign\App\Services\Commerce\ContactRelationItemsModel;
use FluentCampaign\App\Services\Commerce\ContactRelationModel;
use FluentCrm\App\Models\CampaignEmail;
use FluentCrm\App\Models\CampaignUrlMetric;
use FluentCrm\App\Models\Funnel;
use FluentCrm\Framework\Support\Arr;

class Cleanup
{
    public function deleteSequenceAssets($sequenceId)
    {
        $sequenceEmails = SequenceMail::where('parent_id', $sequenceId)
            ->get();

        SequenceMail::whereIn('id', $sequenceEmails->pluck('id')->toArray())->delete();

        foreach ($sequenceEmails as $sequenceEmail) {
            $this->deleteCampaignAssets($sequenceEmail->id);
        }
    }

    public function deleteCampaignAssets($campaignId)
    {
        // The emails sent for this campaign, by campaign_id (matching the row id deleted an unrelated email).
        CampaignEmail::where('campaign_id', $campaignId)->delete();
        CampaignUrlMetric::where('campaign_id', $campaignId)->delete();
    }

    public function deleteCommerceItems($subscriberIds)
    {
        if (Commerce::getEnabledModules() && Commerce::isMigrated(true)) {
            ContactRelationModel::whereIn('subscriber_id', $subscriberIds)->delete();
            ContactRelationItemsModel::whereIn('subscriber_id', $subscriberIds)->delete();
        }
    }

    /**
     * Delete the SMS/WhatsApp conversations of deleted contacts: their threads and every message.
     *
     * Threads kept the deleted contact's id and were only ever linked when contact_id was empty,
     * so whoever later had that number failed every send with "Subscriber not found". Deleting a
     * contact now removes their conversations, opt-out state included (maintainer's decision).
     *
     * One exception: an opt-out thread whose number another contact still has. A STOP belongs to
     * the number and is filed under the oldest matching contact, so deleting that contact would
     * unblock the others. Such a thread keeps its status, loses its messages, and moves to the
     * oldest remaining contact with the number.
     *
     * @param int[] $subscriberIds
     */
    public function deleteMessagingData($subscriberIds)
    {
        global $wpdb;

        $subscriberIds = array_values(array_filter(array_map('intval', (array)$subscriberIds)));
        if (!$subscriberIds || !$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->prefix . 'fc_message_threads'))) {
            return;
        }

        $threads = $wpdb->get_results(
            "SELECT id, phone_number, status FROM {$wpdb->prefix}fc_message_threads WHERE contact_id IN (" . implode(',', $subscriberIds) . ')'
        );
        if (!$threads) {
            return;
        }

        $threadIds = [];
        $optedOut = [];
        foreach ($threads as $thread) {
            $threadIds[] = (int) $thread->id;
            if ($thread->status !== MessageThread::STATUS_SUBSCRIBED && $thread->phone_number) {
                $optedOut[] = $thread;
            }
        }

        // One contact lookup for every opted-out number, not one table scan per thread.
        $reassign = [];
        $sharers = PhoneMatcher::contactsSharingNumbers(array_map(function ($thread) {
            return $thread->phone_number;
        }, $optedOut));
        foreach ($optedOut as $thread) {
            foreach ($sharers[$thread->phone_number] ?? [] as $contact) {
                if (!in_array((int) $contact->id, $subscriberIds, true)) {
                    $reassign[(int) $thread->id] = (int) $contact->id;
                    break;
                }
            }
        }

        $wpdb->query("DELETE FROM {$wpdb->prefix}fc_messages WHERE thread_id IN (" . implode(',', $threadIds) . ')');

        foreach ($reassign as $threadId => $contactId) {
            $wpdb->update($wpdb->prefix . 'fc_message_threads', ['contact_id' => $contactId], ['id' => $threadId]);
        }

        $deleteIds = array_diff($threadIds, array_keys($reassign));
        if ($deleteIds) {
            $wpdb->query("DELETE FROM {$wpdb->prefix}fc_message_threads WHERE id IN (" . implode(',', array_map('intval', $deleteIds)) . ')');
        }
    }

    public function routingDoiRedirect($config, $subscriber)
    {
        if (Arr::get($config, 'tag_based_redirect') == 'yes' && !empty(Arr::get($config, 'tag_redirects'))) {
            $tagRedirects = Arr::get($config, 'tag_redirects', []);
            $subscriberTags = [];
            foreach ($subscriber->tags as $tag) {
                $subscriberTags[] = $tag->id;
            }

            if (!$subscriberTags) {
                return $config;
            }

            foreach ($tagRedirects as $tagRedirect) {
                $targetTags = Arr::get($tagRedirect, 'field_key', []);
                if (!$targetTags || !array_intersect($subscriberTags, $targetTags)) {
                    continue;
                }

                $targetUrl = Arr::get($tagRedirect, 'field_value', []);

                if (!filter_var($targetUrl, FILTER_VALIDATE_URL)) {
                    continue;
                }

                $config['after_confirmation_type'] = 'redirect';
                $config['after_conf_redirect_url'] = $targetUrl;

                return $config;
            }
        }

        return $config;
    }

    public function syncAutomationSteps($funnel)
    {
        $latestAction = \FluentCrm\App\Models\FunnelSequence::where('funnel_id', $funnel->id)
            ->orderBy('sequence', 'DESC')
            ->first();

        if (!$latestAction) {
            return new \WP_Error('no_action_found', __('No action found to sync', 'fluentcampaign-pro'));
        }

        $nextExecutionTime = gmdate('Y-m-d H:i:s', current_time('timestamp') + 300); // 5 minutes from now

        \FluentCrm\App\Models\FunnelSubscriber::where('funnel_id', $funnel->id)
            ->with(['subscriber'])
            ->where('status', 'completed')
            ->whereHas('subscriber', function ($q) {
                $q->where('status', 'subscribed');
            })
            ->whereHas('last_sequence', function ($q) use ($latestAction) {
                $q->where('action_name', '!=', 'end_this_funnel')
                    ->where('id', '!=', $latestAction->id)
                    ->where('sequence', '<', $latestAction->sequence);
            })
            ->update([
                'status'              => 'active',
                'next_execution_time' => $nextExecutionTime,
                'next_sequence_id'    => NULL,
                'notes'               => 'Re-Synced manually at ' . current_time('mysql')
            ]);

        return true;
    }
}
