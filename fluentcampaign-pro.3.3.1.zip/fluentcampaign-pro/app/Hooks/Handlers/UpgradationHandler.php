<?php

namespace FluentCampaign\App\Hooks\Handlers;

use FluentCampaign\App\Migration\Migrate;

class UpgradationHandler
{
    public static function maybeUpdateDbTables()
    {
        $currentDbVersion = get_option('_fluentcampaign_db_version');

        if (!$currentDbVersion || version_compare($currentDbVersion, FLUENT_CAMPAIGN_DB_VERSION, '<')) {
            Migrate::migrate();
            update_option('_fluentcampaign_db_version', FLUENT_CAMPAIGN_DB_VERSION);
        }
    }
}
