<?php

namespace FluentCampaign\App\Hooks\Handlers;

use FluentCampaign\App\Models\RecurringCampaign;
use FluentCrm\App\Models\Campaign;
use FluentCrm\Framework\Support\Arr;

class RecurringPostSmartcode
{
    /**
     * Resolved standard-post date queries by campaign ID for the current request.
     *
     * @var array<int,array<int,array<string,string|bool>>>
     */
    private $postDateQueries = [];

    public function register()
    {
        add_filter('fluent_crm/latest_post_smartcode_query_args', [$this, 'applyRecurringPostWindow'], 10, 2);
    }

    /**
     * Constrain latest-post smartcodes to the post window that made a recurring campaign eligible.
     *
     * @param array $queryArgs WordPress post query arguments.
     * @param mixed $subscriber Subscriber carrying the current campaign ID.
     * @return array
     */
    public function applyRecurringPostWindow($queryArgs, $subscriber)
    {
        $campaignId = (int)Arr::get($subscriber, 'campaign_id');
        if (!$campaignId) {
            return $queryArgs;
        }

        if (array_key_exists($campaignId, $this->postDateQueries)) {
            $dateQuery = $this->postDateQueries[$campaignId];
        } else {
            $dateQuery = $this->resolveCampaignPostDateQuery($campaignId);
            $this->postDateQueries[$campaignId] = $dateQuery;
        }

        if (!$dateQuery) {
            return $queryArgs;
        }

        $queryArgs['date_query'] = $dateQuery;

        return $queryArgs;
    }

    /**
     * Resolve the standard Post publication window for a recurring campaign or edition.
     *
     * @param int $campaignId Current campaign or recurring-edition ID.
     * @return array<int,array<string,string|bool>>
     */
    private function resolveCampaignPostDateQuery($campaignId)
    {
        $campaign = Campaign::withoutGlobalScope('type')->find($campaignId);
        if (!$campaign) {
            return [];
        }

        if ($campaign->type === 'recurring_mail') {
            $editionSettings = (array)$campaign->settings;
            if (array_key_exists('recurring_post_windows', $editionSettings)) {
                $storedWindow = Arr::get($editionSettings, 'recurring_post_windows.post', []);
                if (Arr::get($storedWindow, 'after') && Arr::get($storedWindow, 'before')) {
                    return [
                        [
                            'after'     => $storedWindow['after'],
                            'inclusive' => false,
                        ],
                        [
                            'before'    => $storedWindow['before'],
                            'inclusive' => true,
                        ],
                    ];
                }

                return [];
            }

            // Editions created before recurring_post_windows retain the rolling-window behavior.
            $campaign = RecurringCampaign::find((int)$campaign->parent_id);
        } elseif ($campaign->type !== 'recurring_campaign') {
            return [];
        }

        if (!$campaign) {
            return [];
        }

        $days = $this->getStandardPostWindow(Arr::get($campaign->settings, 'sending_conditions', []));

        return $days ? [['after' => $days . ' days ago']] : [];
    }

    /**
     * Return the configured publication window for the standard Post condition.
     *
     * @param array $conditionGroups Recurring campaign condition groups.
     * @return int
     */
    private function getStandardPostWindow($conditionGroups)
    {
        foreach ((array)$conditionGroups as $conditions) {
            foreach ((array)$conditions as $condition) {
                if (Arr::get($condition, 'object_type') !== 'cpt' || Arr::get($condition, 'object_name') !== 'post') {
                    continue;
                }

                return absint(Arr::get($condition, 'compare_value'));
            }
        }

        return 0;
    }
}
