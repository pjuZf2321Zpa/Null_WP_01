<?php

namespace FluentCampaign\App\Hooks\Handlers;

class DeactivationHandler
{
    /**
     * Retired messaging job names, still drained by MessageScheduler::register() until 3.4.0.
     * 3.1.x queued them into per-campaign groups (fluent-crm-sms-{id}).
     */
    private $retiredMessagingHooks = [
        'fluentcrm_generate_sms_batch',
        'fluentcrm_send_sms_batch',
        'fluentcrm_send_single_sms',
        'fluentcrm_send_single_message',
    ];

    public function handle()
    {
        wp_clear_scheduled_hook('fluentcrm_check_daily_birthday');
        wp_clear_scheduled_hook('fluentcrm_check_daily_birthday_once');

        $this->cancelMessagingActions();
    }

    /**
     * Cancel every Action Scheduler action the Messaging module can queue, across all groups.
     * Messages already in 'processing' are left for MessageScheduler's health check.
     */
    private function cancelMessagingActions()
    {
        // Action Scheduler ships with FluentCRM core, which may already be deactivated.
        if (!function_exists('\as_unschedule_all_actions')) {
            return;
        }

        $hooks = array_merge([
            'fluentcrm_generate_message_batch',
            'fluentcrm_send_message_batch',
        ], $this->retiredMessagingHooks);

        foreach ($hooks as $hook) {
            as_unschedule_all_actions($hook);
        }
    }
}
