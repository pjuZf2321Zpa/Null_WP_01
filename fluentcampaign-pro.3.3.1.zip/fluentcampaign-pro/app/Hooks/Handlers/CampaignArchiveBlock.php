<?php

namespace FluentCampaign\App\Hooks\Handlers;

use FluentCrm\App\Services\Helper;

/**
 * Gutenberg block for the campaign archive, rendered by CampaignArchiveFront::handleShortcode().
 */
class CampaignArchiveBlock
{
    const SCRIPT_HANDLE = 'fluent-crm-campaign-archives-block';

    public function register()
    {
        add_action('init', [$this, 'registerBlock']);
    }

    /**
     * Register the block only while the Campaign Archive feature is enabled.
     */
    public function registerBlock()
    {
        if (!function_exists('register_block_type') || !Helper::isExperimentalEnabled('campaign_archive')) {
            return;
        }

        add_action('enqueue_block_editor_assets', [$this, 'enqueueEditorAssets']);

        register_block_type('fluent-crm/campaign-archives', [
            'api_version'     => 3,
            'editor_script'   => self::SCRIPT_HANDLE,
            'attributes'      => [
                'ids'     => ['type' => 'string', 'default' => ''],
                'status'  => ['type' => 'string', 'default' => ''],
                'limit'   => ['type' => 'number', 'default' => 0],
                'search'  => ['type' => 'string', 'default' => ''],
                'layout'  => ['type' => 'string', 'default' => 'list'],
                'columns' => ['type' => 'number', 'default' => 3],
                'excerpt_length' => ['type' => 'number', 'default' => 25],
                'hide_date'      => ['type' => 'string', 'default' => 'no'],
                'hide_excerpt'   => ['type' => 'string', 'default' => 'no'],
                'hide_read_more' => ['type' => 'string', 'default' => 'no'],
            ],
            'supports'        => [
                'align'  => ['wide', 'full'],
                'anchor' => true,
                'html'   => false,
            ],
            'render_callback' => [$this, 'renderBlock'],
        ]);
    }

    public function enqueueEditorAssets()
    {
        // A classic script, not Pro's module enqueuer, so it runs after its wp-* dependencies.
        wp_register_script(
            self::SCRIPT_HANDLE,
            FLUENTCAMPAIGN_PLUGIN_URL . 'assets/admin/blocks/campaign-archives.js',
            ['wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render', 'wp-api-fetch'],
            FLUENTCAMPAIGN_PLUGIN_VERSION,
            true
        );

        wp_set_script_translations(self::SCRIPT_HANDLE, 'fluentcampaign-pro');
    }

    /**
     * Render the block; attributes go straight to the shortcode handler, which sanitizes them.
     */
    public function renderBlock($attributes)
    {
        return sprintf(
            '<div %1$s>%2$s</div>',
            get_block_wrapper_attributes(),
            (new CampaignArchiveFront())->handleShortcode($attributes)
        );
    }
}
