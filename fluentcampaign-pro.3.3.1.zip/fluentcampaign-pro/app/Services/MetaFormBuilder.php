<?php

namespace FluentCampaign\App\Services;

use FluentCrm\Framework\Support\Arr;

class MetaFormBuilder
{
    private $fields = [];

    public function addField($field)
    {
        $this->fields[] = $field;
        return $this;
    }

    public function renderFields()
    {
        $fields = $this->fields;
        if(!$fields) {
            return '';
        }
        echo '<table class="form-table"><tbody>';
        foreach ($fields as $field) {
            if($field['type'] == 'select') {
                $this->renderSelect($field);
            }
        }
        echo '</tbody></table>';
    }

    public function renderSelect($field)
    {
        $fieldId = sanitize_key($field['name']);
        $label = '<label for="'.$fieldId.'">'.Arr::get($field, 'label', '').'</label>';
        $optionValues = (array) Arr::get($field, 'value');

        $selects = '';

        foreach (Arr::get($field, 'options', []) as $option) {
            $isSelected = in_array($option['key'], $optionValues);
            $selects .= '<option '.selected( true, $isSelected, false ).' value="'.$option['key'].'">'.$option['title'].'</option>';
        }

        $dataAtts = (array) Arr::get($field, 'data_attributes', []);

        $atts = [
            'name' => $field['name'],
            'class'=> 'fcrm_select '.Arr::get($field, 'class'),
            'id' => $fieldId
        ];

        if(Arr::get($field, 'multi')) {
            $atts['multiple'] = 'multiple';
        }

        $atts = array_unique(array_merge($dataAtts, $atts));

        $attributes = '';
        foreach ($atts as $attKey => $attValue) {
            $attributes .= esc_html($attKey).'="'.esc_html($attValue).'" ';
        }

        $input = '<select '.$attributes.'>'.$selects.'</select>';

        if($description = Arr::get($field, 'desc')) {
            $input .= '<p class="description">'.esc_html($description).'</p>';
        }
        $this->renderFieldBase($label, $input);
    }

    public function renderFieldBase($label, $input)
    {
        ?>
        <tr>
            <th scope="row"><?php echo $label; ?></th>
            <td><?php echo $input; ?></td>
        </tr>
        <?php
    }

    public function initMultiSelect($selector = '', $placeholder = 'Select')
    {
        wp_enqueue_style('choices-css', FLUENTCRM_PLUGIN_URL . 'assets/libs/choices/choices.min.css', [], '10.0.0');
        wp_enqueue_script('choices-js', FLUENTCRM_PLUGIN_URL . 'assets/libs/choices/choices.min.js', ['jquery'], '10.0.0', true);

        // Prints the shared Choices CSS once per page.
        static $choicesInlineStyleBooted = false;

        if (!$choicesInlineStyleBooted) {
            $choicesInlineStyleBooted = true;

            add_action('admin_footer', function () {
                ?>
                <style>
                    .choices {
                        position: relative !important;
                        overflow: visible !important;
                        width: 100%;
                        margin-bottom: 0;
                    }

                    .choices__inner {
                        background-color: #fff;
                        min-height: 36px;
                    }

                    .choices[data-type*='select-multiple'] .choices__list--multiple .choices__item {
                        background-color: #007cba !important;
                        border-color: #007cba !important;
                        color: #fff !important;
                    }

                    .choices__list--multiple {
                        display: block;
                        width: 100%;
                    }

                    .choices[data-type*='select-multiple'] .choices__list--multiple .choices__item.is-highlighted {
                        background-color: #006ba1 !important;
                        border-color: #006ba1 !important;
                        color: #fff !important;
                    }

                    .choices[data-type*='select-multiple'] .choices__list--multiple .choices__button {
                        border-left-color: rgba(255, 255, 255, 0.45) !important;
                    }

                    .choices[data-type*='select-multiple'] .choices__input,
                    .choices[data-type*='select-multiple'] .choices__input--cloned {
                        display: block;
                        min-width: 100% !important;
                        width: 100% !important;
                        max-width: 100% !important;
                    }

                    .choices__list.choices__list--dropdown,
                    .choices__list[aria-expanded] {
                        z-index: 100000 !important;
                    }

                    .choices__list--dropdown .choices__list,
                    .choices__list[aria-expanded] .choices__list {
                        max-height: 360px;
                        overflow-y: auto;
                        overscroll-behavior: contain;
                    }
                </style>
                <?php
            });
        }

        // Prints the Choices bootstrap once per page; each selector only registers its config.
        static $choicesBootstrapBooted = false;

        if (!$choicesBootstrapBooted) {
            $choicesBootstrapBooted = true;

            add_action('admin_footer', function () {
                ?>
                <script>
                    (function ($) {
                        if (window.fcRegisterChoicesMultiSelect) {
                            return;
                        }

                        // With contextNodes, searches only inside the newly added DOM.
                        const findChoicesMultiSelects = function (selector, contextNodes) {
                            if (!contextNodes || !contextNodes.length) {
                                return $(selector);
                            }

                            let matches = $();

                            contextNodes.forEach(function (node) {
                                if (!node || (node.nodeType !== 1 && node.nodeType !== 11)) {
                                    return;
                                }

                                const $node = $(node);

                                if (node.nodeType === 1) {
                                    matches = matches.add($node.filter(selector));
                                }

                                matches = matches.add($node.find(selector));
                            });

                            return matches;
                        };

                        // The original select keeps its name and value, so metabox save handlers are unchanged.
                        const initChoicesMultiSelect = function (selector, placeholder, contextNodes) {
                            findChoicesMultiSelects(selector, contextNodes).each(function () {
                                const select = this;

                                if (select.dataset.fcChoicesInitialized === 'yes') {
                                    return;
                                }

                                select.dataset.fcChoicesInitialized = 'yes';

                                new Choices(select, {
                                    removeItemButton: true,
                                    searchEnabled: true,
                                    searchResultLimit: 10,
                                    renderChoiceLimit: 100,
                                    shouldSort: false,
                                    // Auto positioning breaks the metabox layout.
                                    position: 'bottom',
                                    placeholder: true,
                                    placeholderValue: placeholder,
                                    itemSelectText: '',
                                    noResultsText: '<?php echo esc_js(__('No matching options found', 'fluentcampaign-pro')); ?>',
                                    noChoicesText: '<?php echo esc_js(__('No options available', 'fluentcampaign-pro')); ?>',
                                    allowHTML: false,
                                    resetScrollPosition: true
                                });
                            });
                        };

                        window.fcFindChoicesMultiSelects = findChoicesMultiSelects;
                        window.fcInitChoicesMultiSelect = initChoicesMultiSelect;
                        window.fcChoicesMultiSelectConfigs = window.fcChoicesMultiSelectConfigs || [];

                        // Initializes selects inserted after page load, such as EDD price rows.
                        const setupChoicesMultiSelectObserver = function () {
                            if (window.fcChoicesMultiSelectObserver || !window.MutationObserver) {
                                return;
                            }

                            let queuedAddedNodes = [];
                            let queuedAddedNodesTimer = null;

                            const nodeContainsRegisteredSelector = function (node) {
                                const $node = $(node);

                                return window.fcChoicesMultiSelectConfigs.some(function (config) {
                                    return config.selector && (
                                        (node.nodeType === 1 && $node.is(config.selector)) ||
                                        $node.find(config.selector).length
                                    );
                                });
                            };

                            const queueAddedNode = function (node) {
                                if (!node || (node.nodeType !== 1 && node.nodeType !== 11) || queuedAddedNodes.indexOf(node) !== -1) {
                                    return false;
                                }

                                if (!nodeContainsRegisteredSelector(node)) {
                                    return false;
                                }

                                queuedAddedNodes.push(node);
                                return true;
                            };

                            const flushQueuedAddedNodes = function () {
                                queuedAddedNodesTimer = null;

                                if (!queuedAddedNodes.length) {
                                    return;
                                }

                                const contextNodes = queuedAddedNodes.slice();
                                queuedAddedNodes = [];

                                window.fcChoicesMultiSelectConfigs.forEach(function (config) {
                                    initChoicesMultiSelect(config.selector, config.placeholder, contextNodes);
                                });
                            };

                            const scheduleQueuedAddedNodesFlush = function () {
                                if (queuedAddedNodesTimer) {
                                    return;
                                }

                                queuedAddedNodesTimer = window.setTimeout(flushQueuedAddedNodes, 100);
                            };

                            window.fcChoicesMultiSelectObserver = new MutationObserver(function (mutations) {
                                let hasQueuedNodes = false;

                                mutations.forEach(function (mutation) {
                                    if (!mutation.addedNodes || !mutation.addedNodes.length) {
                                        return;
                                    }

                                    Array.prototype.forEach.call(mutation.addedNodes, function (node) {
                                        hasQueuedNodes = queueAddedNode(node) || hasQueuedNodes;
                                    });
                                });

                                if (hasQueuedNodes) {
                                    scheduleQueuedAddedNodesFlush();
                                }
                            });

                            window.fcChoicesMultiSelectObserver.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                        };

                        let registeredConfigsInitQueued = false;

                        const initRegisteredConfigs = function () {
                            registeredConfigsInitQueued = false;

                            window.fcChoicesMultiSelectConfigs.forEach(function (config) {
                                initChoicesMultiSelect(config.selector, config.placeholder);
                            });

                            setupChoicesMultiSelectObserver();
                        };

                        const scheduleRegisteredConfigsInit = function () {
                            if (registeredConfigsInitQueued) {
                                return;
                            }

                            registeredConfigsInitQueued = true;
                            $(initRegisteredConfigs);
                        };

                        // Called by each initMultiSelect(); stores the config once and schedules init.
                        window.fcRegisterChoicesMultiSelect = function (selector, placeholder) {
                            const configExists = window.fcChoicesMultiSelectConfigs.some(function (config) {
                                return config.selector === selector;
                            });

                            if (!configExists) {
                                window.fcChoicesMultiSelectConfigs.push({
                                    selector: selector,
                                    placeholder: placeholder
                                });
                            }

                            scheduleRegisteredConfigsInit();
                        };
                    })(jQuery);
                </script>
                <?php
            });
        }

        if ($selector) {
            add_action('admin_footer', function () use ($selector, $placeholder) {
                ?>
                <script>
                    window.fcRegisterChoicesMultiSelect('<?php echo esc_js($selector); ?>', '<?php echo esc_js($placeholder); ?>');
                </script>
                <?php
            });
        }
    }
}
