<?php

namespace FluentCampaign\App\Services\PluginManager;

/**
 * Verifies an update package against an Ed25519-signed release manifest before WordPress unzips it.
 * Checks signature, slug, version (no downgrade) and the package sha256.
 */
class UpdateVerifier
{
    /**
     * Release signing keys. Must stay hardcoded, never read from an option, API response or filter.
     * Rotate by shipping the new key alongside the old one before signing with it.
     *
     * @var array<string, string> key id => Ed25519 public key, 64 lowercase hex chars
     */
    const TRUSTED_KEYS = [
        'wpmn-pub-key' => '0b0c3b880d064696f2636d8c72d8e4094303fc6b7907b24ea25a1745f23463c0',
    ];

    /** @var string plugin basename, e.g. fluentcampaign-pro/fluentcampaign-pro.php */
    private $basename;

    /** @var string slug as it appears in the signed manifest */
    private $slug;

    /** @var string currently installed version */
    private $version;

    /** @var callable|null returns a fresh, uncached update object from the licensing API */
    private $freshFetch;

    /** @var callable|null drops this plugin's cached version info */
    private $flushCache;

    /** @var bool one uncached retry per request, no more */
    private $refetched = false;

    public function __construct($basename, $slug, $version, $freshFetch = null, $flushCache = null)
    {
        $this->basename = $basename;
        $this->slug = $slug;
        $this->version = $version;
        $this->freshFetch = $freshFetch;
        $this->flushCache = $flushCache;
    }

    /**
     * Whether a usable release key is compiled in.
     *
     * @return bool
     */
    public static function hasTrustedKeys()
    {
        return (bool) self::trustedKeys();
    }

    /**
     * Whether this server can verify an Ed25519 signature.
     * Fails open: a host can disable the function while core skips the sodium_compat polyfill.
     *
     * @return bool
     */
    public static function isSupported()
    {
        return function_exists('sodium_crypto_sign_verify_detached');
    }

    /**
     * Hook the download gate on every request, since cron and WP-CLI run updates too.
     *
     * @return void
     */
    public function register()
    {
        add_filter('upgrader_pre_download', [$this, 'verifyPackage'], 10, 4);
    }

    /**
     * Verify the manifest, download the package and return the verified file path.
     * A WP_Error aborts the update before extraction.
     *
     * @param bool|string|\WP_Error $reply
     * @param string $package The package URL WordPress is about to download.
     * @param \WP_Upgrader|null $upgrader
     * @param array $hookExtra
     * @return bool|string|\WP_Error Path to the verified file, or an error.
     */
    public function verifyPackage($reply, $package, $upgrader = null, $hookExtra = [])
    {
        if (false !== $reply) {
            return $reply; // Another filter already resolved the download.
        }

        if (empty($hookExtra['plugin']) || $hookExtra['plugin'] !== $this->basename) {
            return $reply; // Not this plugin.
        }

        // Local paths are manual uploads. Every remote URL, http included, must be verified.
        if (!is_string($package) || !preg_match('#^https?://#i', $package)) {
            return $reply;
        }

        // No key or no Ed25519 support: fall back to the normal unsigned download.
        if (!self::hasTrustedKeys() || !self::isSupported()) {
            return $reply;
        }

        $manifest = $this->verifyManifest($this->updateEntry());

        // The cached entry may predate signed proofs, so ask the API once before refusing.
        if (is_wp_error($manifest) && $this->canRefetch()) {
            $manifest = $this->verifyManifest($this->fetchFresh());
        }

        if (is_wp_error($manifest)) {
            return $manifest;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        // Replaces the feedback download_package() would normally emit.
        if (is_object($upgrader) && isset($upgrader->skin) && is_object($upgrader->skin)) {
            $upgrader->skin->feedback('downloading_package', $package);
        }

        $file = download_url($package, 300);

        if (is_wp_error($file)) {
            return $file;
        }

        $actual = hash_file('sha256', $file);

        if (is_string($actual) && hash_equals($manifest['sha256'], $actual)) {
            return $file;
        }

        // The download serves the current release, which a cached manifest may predate.
        // Re-check the same file against a fresh manifest.
        if (is_string($actual) && $this->canRefetch()) {
            $current = $this->verifyManifest($this->fetchFresh());

            if (!is_wp_error($current) && hash_equals($current['sha256'], $actual)) {
                if (is_callable($this->flushCache)) {
                    call_user_func($this->flushCache);
                }

                return $file;
            }
        }

        @unlink($file);

        return $this->reject('hash_mismatch', __('The downloaded update does not match its signature, so it was not installed. Please try again, and contact support if this keeps happening.', 'fluentcampaign-pro'));
    }

    /**
     * Check the signed manifest attached to the update object.
     *
     * @param object|null $update
     * @return array|\WP_Error The decoded manifest, or the reason it was refused.
     */
    private function verifyManifest($update)
    {
        $bytes = $this->proofBytes($update);

        if (is_wp_error($bytes)) {
            return $bytes;
        }

        $manifest = json_decode($bytes['manifest'], true);

        if (!is_array($manifest) || empty($manifest['key_id']) || !is_string($manifest['key_id'])) {
            return $this->reject('manifest_format', __('The update manifest is malformed, so the update was not installed.', 'fluentcampaign-pro'));
        }

        // Verify the raw bytes as received. Re-encoding changes the bytes and breaks the signature.
        if (!$this->verifySignature($bytes['manifest'], $bytes['signature'], $manifest['key_id'])) {
            return $this->reject('bad_signature', __('This update is not signed by WPManageNinja, so it was not installed. Please contact support before installing it by hand.', 'fluentcampaign-pro'));
        }

        if (!isset($manifest['slug']) || $manifest['slug'] !== $this->slug) {
            return $this->reject('slug_mismatch', __('This update package is for a different plugin, so it was not installed.', 'fluentcampaign-pro'));
        }

        if (empty($manifest['version']) || !is_string($manifest['version'])) {
            return $this->reject('manifest_format', __('The update manifest has no version, so the update was not installed.', 'fluentcampaign-pro'));
        }

        // The signed version may be newer than advertised (cached entry) but never older.
        if (!empty($update->new_version) && version_compare($manifest['version'], $update->new_version, '<')) {
            return $this->reject('version_mismatch', __('The offered update is older than the version advertised, so it was not installed.', 'fluentcampaign-pro'));
        }

        // Equal versions stay installable for reinstall and repair.
        if ($this->version && version_compare($manifest['version'], $this->version, '<')) {
            return $this->reject('downgrade', sprintf(
                /* translators: 1: offered version number, 2: installed version number */
                __('The server offered version %1$s, which is older than the installed %2$s, so it was not installed.', 'fluentcampaign-pro'),
                $manifest['version'],
                $this->version
            ));
        }

        if (empty($manifest['sha256']) || !is_string($manifest['sha256']) || !preg_match('/^[a-f0-9]{64}$/i', $manifest['sha256'])) {
            return $this->reject('manifest_format', __('The update manifest has no valid checksum, so the update was not installed.', 'fluentcampaign-pro'));
        }

        $manifest['sha256'] = strtolower($manifest['sha256']);

        return $manifest;
    }

    /**
     * Pull the raw manifest and signature off the update object.
     *
     * @param object|null $update
     * @return array|\WP_Error ['manifest' => raw bytes, 'signature' => base64]
     */
    private function proofBytes($update)
    {
        $manifest = isset($update->manifest) ? $update->manifest : '';
        $signature = isset($update->signature) ? $update->signature : '';

        if (!is_string($manifest) || !is_string($signature) || $manifest === '' || $signature === '') {
            return $this->reject('missing_signature', __('This update was served without a signature, so it was not installed. Please try again later, and contact support if this keeps happening.', 'fluentcampaign-pro'));
        }

        $decoded = base64_decode($manifest, true);

        if ($decoded === false || $decoded === '') {
            return $this->reject('manifest_encoding', __('The update manifest could not be read, so the update was not installed.', 'fluentcampaign-pro'));
        }

        return ['manifest' => $decoded, 'signature' => $signature];
    }

    /**
     * Verify a detached Ed25519 signature over the exact bytes given.
     *
     * @param string $message Exact signed bytes.
     * @param string $sigBase64 Base64 of the 64 byte detached signature.
     * @param string $keyId Key id named by the manifest.
     * @return bool
     */
    private function verifySignature($message, $sigBase64, $keyId)
    {
        if (!self::isSupported()) {
            return false;
        }

        $keys = self::trustedKeys();

        if (!isset($keys[$keyId])) {
            return false;
        }

        $signature = base64_decode($sigBase64, true);

        // Literal 64: SODIUM_CRYPTO_SIGN_BYTES can be undefined on a partially disabled sodium.
        if ($signature === false || strlen($signature) !== 64) {
            return false;
        }

        $publicKey = hex2bin($keys[$keyId]);

        if ($publicKey === false || strlen($publicKey) !== 32) {
            return false;
        }

        try {
            return sodium_crypto_sign_verify_detached($signature, $message, $publicKey);
        } catch (\Exception $e) {
            return false;
        } catch (\Error $e) {
            return false;
        }
    }

    /**
     * The trusted keys, minus any malformed entry.
     *
     * @return array<string, string>
     */
    private static function trustedKeys()
    {
        $keys = [];

        foreach (self::TRUSTED_KEYS as $keyId => $publicKey) {
            if (is_string($publicKey) && preg_match('/^[a-f0-9]{64}$/i', $publicKey)) {
                $keys[$keyId] = strtolower($publicKey);
            }
        }

        return $keys;
    }

    /**
     * The update object our own updater put into the transient.
     *
     * @return object|null
     */
    private function updateEntry()
    {
        $transient = get_site_transient('update_plugins');

        if (is_object($transient) && isset($transient->response[$this->basename]) && is_object($transient->response[$this->basename])) {
            return $transient->response[$this->basename];
        }

        return null;
    }

    /** One uncached call to the licensing API per request, and only if we can. */
    private function canRefetch()
    {
        return !$this->refetched && is_callable($this->freshFetch);
    }

    /**
     * Ask the licensing API directly, bypassing every cache.
     *
     * @return object|null
     */
    private function fetchFresh()
    {
        $this->refetched = true;

        $fresh = call_user_func($this->freshFetch);

        return is_object($fresh) ? $fresh : null;
    }

    /**
     * @param string $code
     * @param string $message
     * @return \WP_Error
     */
    private function reject($code, $message)
    {
        do_action('fluent_crm/update_verification_failed', $this->slug, $code, $message);

        return new \WP_Error('fluent_sl_' . $code, $message);
    }
}
