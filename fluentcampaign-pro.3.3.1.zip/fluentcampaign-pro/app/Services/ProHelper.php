<?php

namespace FluentCampaign\App\Services;

class ProHelper
{
    /**
     * maybe_unserialize() without object instantiation; use for stored, user-influenced values.
     *
     * Same as core Helper::safeUnserialize(), kept here because Pro can run on an older core.
     *
     * @param mixed $value The (possibly serialized) value read from storage.
     * @return mixed stdClass is kept (it has no magic methods, and settings store it for empty
     *               JSON objects); any other class becomes an inert incomplete class.
     */
    public static function safeUnserialize($value)
    {
        if (is_serialized($value)) {
            return @unserialize(trim($value), ['allowed_classes' => ['stdClass']]);
        }

        return $value;
    }

    public static function hasSmartLink()
    {
        $enabled = fluentCrmGetOptionCache('_fcrm_smart_link_status', 604800); // 7 days
        if ($enabled) {
            return $enabled === 'yes';
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'fc_smart_links';
        $query = $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name));
        $status = ($wpdb->get_var($query) == $table_name) ? 'yes' : 'no';
        fluentCrmSetOptionCache('_fcrm_smart_link_status', $status, 604800); // 7 days

        return $status === 'yes';
    }
}
