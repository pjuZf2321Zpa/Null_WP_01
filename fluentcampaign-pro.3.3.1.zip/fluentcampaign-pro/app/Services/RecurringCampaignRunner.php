<?php

namespace FluentCampaign\App\Services;

use FluentCrm\Framework\Support\Arr;
use FluentCampaign\App\Models\RecurringCampaign;

class RecurringCampaignRunner
{

    public static function getNextScheduledAt($schedulingSettings, $cutSeconds = 1800)
    {
        $type = Arr::get($schedulingSettings, 'type');

        $validTypes = ['daily', 'weekly', 'monthly'];

        if (!in_array($type, $validTypes)) {
            return NULL;
        }

        $time = Arr::get($schedulingSettings, 'time', '00:00') . ':00';

        $currentTimeStamp = current_time('timestamp');

        switch ($type) {
            case 'daily':
                $nextDateTime = gmdate('Y-m-d', $currentTimeStamp) . ' ' . $time;
                if ((strtotime($nextDateTime) - $currentTimeStamp) > $cutSeconds) {
                    return $nextDateTime;
                }
                // let's make it to next day
                return gmdate('Y-m-d H:i:s', strtotime($nextDateTime) + 86400);

            case 'weekly':
                $selectedDay = strtolower(Arr::get($schedulingSettings, 'day', 'mon'));
                $currentDay = strtolower(gmdate('D', $currentTimeStamp));

                if ($selectedDay == $currentDay) {
                    // it's today
                    $nextDateTime = gmdate('Y-m-d', $currentTimeStamp) . ' ' . $time; // creates a full date time string at the specified time, if today is 2025-01-01 and time is 15:00, it will be 2025-01-01 15:00:00

                    if (strtotime($nextDateTime) - $currentTimeStamp > $cutSeconds) {
                        // compare the next date time with current timestamp to check if it's after the cut seconds ( 30 minutes )
                        return $nextDateTime; // it's after the 30 minutes
                    }
                }

                // if today is not the selected day, or it's before the cut seconds, we need to find/set the next occurrence of the selected day
                return gmdate('Y-m-d', strtotime('next ' . $selectedDay, $currentTimeStamp)) . ' ' . $time;

            case 'monthly':
                $selectedDay = max(1, absint(Arr::get($schedulingSettings, 'day', '1')));
                $currentDay = (int) gmdate('j', $currentTimeStamp);
                $daysInCurrentMonth = (int) gmdate('t', $currentTimeStamp);
                $clampedCurrentDay = min($selectedDay, $daysInCurrentMonth);

                if ($clampedCurrentDay == $currentDay) {
                    // it's today (or clamped to today for short months)
                    $nextDateTime = gmdate('Y-m-d', $currentTimeStamp) . ' ' . $time;
                    if (strtotime($nextDateTime) - $currentTimeStamp > $cutSeconds) {
                        return $nextDateTime; // it's after the cut seconds
                    }
                } else if ($currentDay < $clampedCurrentDay) {
                    $paddedDay = str_pad($clampedCurrentDay, 2, '0', STR_PAD_LEFT);
                    return gmdate('Y-m-', $currentTimeStamp) . $paddedDay . ' ' . $time;
                }

                $nextMonth = strtotime("first day of next month", $currentTimeStamp);
                $daysInNextMonth = (int) gmdate('t', $nextMonth);
                $clampedNextDay = min($selectedDay, $daysInNextMonth);
                $advanceDay = $clampedNextDay - 1;

                return gmdate('Y-m-d', $nextMonth + ($advanceDay * 86400)) . ' ' . $time;
        }

        return NULL;
    }

    public static function setCalculatedScheduledAt()
    {
        $nextItem = RecurringCampaign::orderBy('scheduled_at', 'ASC')
            ->where('status', 'active')
            ->whereNotNull('scheduled_at')
            ->first();

        if (!$nextItem) {
            update_option('_fc_next_recurring_campaign', false, 'no');
            return;
        }

        update_option('_fc_next_recurring_campaign', strtotime($nextItem->scheduled_at), 'no');
    }

    /**
     * Resolve the exact publication window used by a recurring post condition.
     *
     * @param array $condition
     * @param int $lastCheckedAt Site-local timestamp of the campaign's previous check, or 0
     * @param int|null $now Site-local timestamp of this check
     * @return array{after:string,before:string}
     */
    public static function resolveConditionWindow($condition, $lastCheckedAt = 0, $now = null)
    {
        $now = $now ?: current_time('timestamp');
        $windowStart = $now - (int)$condition['compare_value'] * 86400;

        if ($lastCheckedAt && $lastCheckedAt < $now && abs($windowStart - $lastCheckedAt) <= HOUR_IN_SECONDS) {
            $windowStart = $lastCheckedAt;
        }

        return [
            'after'  => gmdate('Y-m-d H:i:s', $windowStart),
            'before' => gmdate('Y-m-d H:i:s', $now),
        ];
    }

    /**
     * Whether a post of the condition's type was published within its "last N days" window.
     *
     * The window is measured from when the check runs, which drifts with cron: consecutive
     * windows could overlap (a post counted for two editions) or leave a gap (a post never
     * counted). When the window would start within an hour of the previous check, as it does
     * when N days matches the campaign's frequency, it starts exactly at that check instead,
     * so consecutive windows meet. Longer windows (say daily with "within 7 days") keep their
     * meaning.
     *
     * @param array $condition
     * @param int $lastCheckedAt Site-local timestamp of the campaign's previous check, or 0
     * @param int|null $now Site-local timestamp of this check
     * @return bool
     */
    public static function assessCondition($condition, $lastCheckedAt = 0, $now = null)
    {
        $window = self::resolveConditionWindow($condition, $lastCheckedAt, $now);

        if ($condition['object_type'] === 'cpt') {
            $exist = fluentcrmDb()->table('posts')
                ->where('post_type', $condition['object_name'])
                ->where('post_status', 'publish')
                ->where('post_date', '>', $window['after'])
                ->where('post_date', '<=', $window['before'])
                ->first();

            if ($exist) {
                return true;
            }
        }

        return false;
    }
}
