<?php

namespace FluentCampaign\App\Services\DynamicSegments;

use FluentCrm\App\Models\Subscriber;
use FluentCrm\Framework\Support\Arr;

class PMProMembersSegment extends BaseSegment
{

    private $model = null;

    public $slug = 'pmpro_memberships';

    public function getInfo()
    {
        return [
            'id'          => 0,
            'slug'        => $this->slug,
            'is_system'   => true,
            'title'       => __('Paid Memberships Pro Members', 'fluentcampaign-pro'),
            'subtitle'    => __('Subscribed contacts who are also Paid Memberships Pro members', 'fluentcampaign-pro'),
            'description' => __('This segment contains all your subscribed contacts who are also Paid Memberships Pro members', 'fluentcampaign-pro'),
            'settings'    => []
        ];
    }

    public function getCount()
    {
        return $this->getModel()->count();
    }

    public function getModel($segment = [])
    {
        // Callers add limits and cursors to the query; each gets its own copy of the cached one.
        if ($this->model) {
            return clone $this->model;
        }

        $query = Subscriber::where('status', 'subscribed');
        $subQuery = fluentCrmDb()
            ->table('pmpro_memberships_users')
            ->join('fc_subscribers', 'fc_subscribers.user_id', '=', 'pmpro_memberships_users.user_id')
            ->select('pmpro_memberships_users.user_id');

        $this->model = $query->whereIn('user_id', $subQuery);

        return clone $this->model;
    }

    public function getSegmentDetails($segment, $id, $config)
    {
        $segment = $this->getInfo();

        if (Arr::get($config, 'model')) {
            $segment['model'] = $this->getModel($segment);
        }

        if (Arr::get($config, 'subscribers')) {
            $segment['subscribers'] = $this->getSubscribers($config);
        }

        if (Arr::get($config, 'contact_count')) {
            $segment['contact_count'] = $this->getCount();
        }

        return $segment;
    }
}
