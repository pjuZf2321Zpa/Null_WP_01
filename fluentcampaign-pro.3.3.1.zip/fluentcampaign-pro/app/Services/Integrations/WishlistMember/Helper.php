<?php

namespace FluentCampaign\App\Services\Integrations\WishlistMember;

use FluentCrm\Framework\Support\Arr;

class Helper
{
    public static function getMembershipLevels()
    {
        $levels = \wlmapi_get_levels();
        $formattedLevels = [];
        foreach (Arr::get($levels, 'levels.level') as $level) {
            $formattedLevels[] = [
                'id'    => strval($level['id']),
                'title' => $level['name']
            ];
        }

        return $formattedLevels;
    }

    /**
     * Limit a wlm_userlevels query to levels the member actually holds.
     *
     * WishList Member keeps the level row when a level is cancelled or still waiting for approval
     * or email confirmation, and records that in wlm_userlevel_options. Those rows are not members.
     *
     * @param \FluentCrm\Framework\Database\Query\Builder $query on wlm_userlevels
     * @return \FluentCrm\Framework\Database\Query\Builder
     */
    public static function whereLevelHeld($query)
    {
        return $query->whereNotExists(function ($q) {
            $q->select(fluentCrmDb()->raw(1))
                ->from('wlm_userlevel_options')
                ->whereColumn('wlm_userlevel_options.userlevel_id', 'wlm_userlevels.ID')
                ->whereIn('wlm_userlevel_options.option_name', ['cancelled', 'forapproval', 'unconfirmed'])
                ->whereNotIn('wlm_userlevel_options.option_value', ['', '0']);
        });
    }

    public static function getUserLevels($userId)
    {
        $enrollments = self::whereLevelHeld(fluentCrmDb()->table('wlm_userlevels')
            ->select(['level_id'])
            ->where('user_id', $userId))
            ->get();

        $levelIds = [];

        foreach ($enrollments as $enrollment) {
            $levelIds[] = $enrollment->level_id;
        }

        return $levelIds;

    }
}
