<?php

namespace FluentCampaign\App\Services\Integrations\TutorLms;

use FluentCrm\App\Services\Funnel\FunnelHelper;

class Helper
{
    public static function getCourses()
    {
        $courses = get_posts(array(
            'post_type'   => 'courses',
            'numberposts' => -1
        ));

        $formattedCourses = [];
        foreach ($courses as $course) {
            $formattedCourses[] = [
                'id'    => strval($course->ID),
                'title' => $course->post_title
            ];
        }

        return $formattedCourses;
    }

    public static function getLessons($search = '', $includeIds = [])
    {
        global $wpdb;

        $search = sanitize_text_field($search);
        $includeIds = array_filter(array_map('intval', (array)$includeIds));

        $where = [
            'lessons.post_type = %s',
            'topics.post_type = %s',
            'courses.post_type = %s',
            "lessons.post_status != 'trash'"
        ];

        $postTypeParams = [
            tutor()->lesson_post_type,
            tutor()->topics_post_type,
            tutor()->course_post_type
        ];
        $params = $postTypeParams;

        if ($search) {
            $where[] = 'lessons.post_title LIKE %s';
            $params[] = '%' . $wpdb->esc_like($search) . '%';
        }

        $sql = "SELECT lessons.ID, lessons.post_title
            FROM {$wpdb->posts} lessons
            INNER JOIN {$wpdb->posts} topics ON lessons.post_parent = topics.ID
            INNER JOIN {$wpdb->posts} courses ON topics.post_parent = courses.ID
            WHERE " . implode(' AND ', $where) . "
            ORDER BY lessons.post_date DESC
            LIMIT 50";

        $lessons = $wpdb->get_results($wpdb->prepare($sql, $params));

        $formattedLessons = [];
        foreach ($lessons as $lesson) {
            $formattedLessons[$lesson->ID] = [
                'id'    => strval($lesson->ID),
                'title' => $lesson->post_title
            ];
        }

        $missingIds = array_diff($includeIds, array_keys($formattedLessons));
        if ($missingIds) {
            $placeholders = implode(',', array_fill(0, count($missingIds), '%d'));

            $includeSql = "SELECT lessons.ID, lessons.post_title
                FROM {$wpdb->posts} lessons
                INNER JOIN {$wpdb->posts} topics ON lessons.post_parent = topics.ID
                INNER JOIN {$wpdb->posts} courses ON topics.post_parent = courses.ID
                WHERE lessons.post_type = %s
                    AND topics.post_type = %s
                    AND courses.post_type = %s
                    AND lessons.ID IN ({$placeholders})";

            $includedLessons = $wpdb->get_results($wpdb->prepare($includeSql, array_merge($postTypeParams, $missingIds)));

            foreach ($includedLessons as $lesson) {
                $formattedLessons[$lesson->ID] = [
                    'id'    => strval($lesson->ID),
                    'title' => $lesson->post_title
                ];
            }
        }

        return array_values($formattedLessons);
    }

    public static function isInCourses($courseIds, $subscriber)
    {
        if (!$courseIds) {
            return false;
        }

        $userId = $subscriber->getWpUserId();
        if (!$userId) {
            return false;
        }

        // Completed enrollments only, as Tutor's own is_enrolled(): cancelled and unpaid (pending) ones are not.
        $course = fluentCrmDb()->table('posts')
            ->where('post_type', 'tutor_enrolled')
            ->where('post_status', 'completed')
            ->whereIn('post_parent', $courseIds)
            ->where('post_author', $userId)
            ->first();

        if ($course) {
            return true;
        }

        return false;
    }

    public static function isCoursesCompleted($courseIds, $subscriber)
    {
        if (!$courseIds) {
            return false;
        }

        $userId = $subscriber->getWpUserId();
        if (!$userId) {
            return false;
        }

        foreach ($courseIds as $courseId) {
            if (tutor_utils()->is_completed_course($courseId, $userId)) {
                return true;
            }
        }

        return false;
    }

    public static function getUserCourses($userId)
    {
        $courses = fluentCrmDb()->table('posts')
            ->select(['post_parent'])
            ->where('post_type', 'tutor_enrolled')
            ->where('post_status', 'completed')
            ->where('post_author', $userId)
            ->get();

        $courseIds = [];
        foreach ($courses as $course) {
            $courseIds[] = $course->post_parent;
        }

        return $courseIds;
    }

    public static function createContactFromTutor($userId, $tags = [])
    {
        $subscriberData = FunnelHelper::prepareUserData($userId);
        if (empty($subscriberData['email'])) {
            return false;
        }

        $subscriber = FunnelHelper::getSubscriber($subscriberData['email']);

        if (!$subscriber) {
            $subscriberData['source'] = __('Tutor LMS', 'fluentcampaign-pro');
            $subscriber = FunnelHelper::createOrUpdateContact($subscriberData);
        }

        if(!$subscriber) {
            return false;
        }

        if ($tags) {
            $subscriber->attachTags($tags);
        }

        return $subscriber;
    }

    public static function getTriggerSource($triggerName)
    {
        $maps = [
            'tutor_course_complete_after' => 'course',
            'tutor_after_enrolled'     => 'course'
        ];

        return isset($maps[$triggerName]) ? $maps[$triggerName] : false;

    }
}
