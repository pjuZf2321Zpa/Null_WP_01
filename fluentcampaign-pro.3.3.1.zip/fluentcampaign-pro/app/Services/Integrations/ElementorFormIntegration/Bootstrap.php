<?php

namespace FluentCampaign\App\Services\Integrations\ElementorFormIntegration;


class Bootstrap
{
    public function init()
    {

        add_action('init', function () {
            if (!defined('ELEMENTOR_PRO_VERSION')) {
                return;
            }

            if (!class_exists('\ElementorPro\Plugin') || apply_filters('fluent_crm/disable_elementor_form', false)) {
                return;
            }

            $formModule = \ElementorPro\Plugin::instance()->modules_manager->get_modules('forms');

            if (!$formModule) {
                return;
            }

            add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueueEditorFieldSync']);

            $formWidget = new FormWidget();
            // Register the action with form widget
            if (version_compare(ELEMENTOR_PRO_VERSION, '3.5.0', '>')) {
                $formModule->actions_registrar->register($formWidget, $formWidget->get_name());
            } else {
                $formModule->add_form_action($formWidget->get_name(), $formWidget);
            }
        });
    }

    /**
     * Refresh saved mapping rows from current field definitions when the CRM panel opens.
     * Elementor's updateMap preserves local field selections by remote_id.
     */
    public function enqueueEditorFieldSync()
    {
        wp_add_inline_script('elementor-editor', <<<'JS'
jQuery(window).on('elementor:init', function () {
    elementor.channels.editor.on('section:activated', function (sectionName, editor) {
        if (sectionName !== '_ei_section_newsletter') {
            return;
        }

        var control = editor.children.find(function (view) {
            return view.model.get('name') === 'fluentcrm_integration_fields_map';
        });
        if (!control || typeof control.updateMap !== 'function') {
            return;
        }

        var fields = control.model.get('default');
        if (!Array.isArray(fields)) {
            return;
        }

        // Avoid resetting repeater IDs and dirtying unchanged forms on every panel visit.
        var keys = ['remote_id', 'remote_label', 'remote_type', 'remote_required'];
        var currentFields = control.collection.map(function (model) {
            return _.pick(model.attributes, keys);
        });
        if (!_.isEqual(currentFields, fields)) {
            control.updateMap(fields);
        }
    });
});
JS
        );
    }
}
