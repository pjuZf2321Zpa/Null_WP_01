<?php

namespace FluentCampaign\App\Services\Integrations\LearnPress;

use FluentCampaign\App\Services\MetaFormBuilder;
use FluentCrm\App\Models\Tag;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Helper;
use FluentCrm\App\Services\Html\TableBuilder;
use FluentCrm\Framework\Support\Arr;

class LearnPressInit
{
    public function init()
    {
        new LearnPressImporter();

        add_filter('fluentcrm_advanced_filter_options', array($this, 'addAdvancedFilterOptions'), 10, 1);
        add_action('fluentcrm_contacts_filter_learnpress', array($this, 'addAdvancedFilter'), 10, 2);
        add_filter('fluentcrm_ajax_options_product_selector_learnpress_lessons', array($this, 'getLessonOptions'), 10, 3);

        add_filter('fluentcrm_profile_sections', array($this, 'pushCoursesOnProfile'));
        add_filter('fluencrm_profile_section_learnpress_profile_courses', array($this, 'pushCoursesContent'), 10, 2);
        add_filter('fluentcrm_deep_integration_providers', array($this, 'addDeepIntegrationProvider'), 10, 1);


        if (!apply_filters('fluentcrm_disable_integration_metaboxes', false, 'learnpress')) {
            /*
            * Metaboxes
            */
            add_action('add_meta_boxes', array($this, 'addBoxes'));
            add_action('save_post_lp_course', array($this, 'saveMetaBox'));
            add_action('save_post_lp_lesson', array($this, 'saveMetaBox'));

            /*
             * Actions
             */
            add_action('learn-press/user-enrolled-course', array($this, 'courseEnrolled'), 10, 2);
            add_action('learnpress/user/course-enrolled', function ($ref, $courseId, $userId) {
                $this->courseEnrolled($courseId, $userId);
            }, 10, 3);
            // Older LearnPress.
            add_action('learn-press/user-course/finish', array($this, 'courseFinished'), 10, 1);
            // Current LearnPress, passing a UserCourseModel.
            add_action('learn-press/user-course/finished', array($this, 'courseFinished'), 10, 1);
            add_action('learn-press/user-completed-lesson', array($this, 'lessonCompleted'), 10, 3);
        }

    }

    /** Register the completed-lessons advanced filter. */
    public function addAdvancedFilterOptions($groups)
    {
        $groups['learnpress'] = [
            'label'    => __('LearnPress', 'fluentcampaign-pro'),
            'value'    => 'learnpress',
            'children' => [
                [
                    'value'        => 'completed_lessons',
                    'label'        => __('Completed Lessons', 'fluentcampaign-pro'),
                    'type'         => 'selections',
                    'cacheable'    => false,
                    'component'    => 'product_selector',
                    'extended_key' => 'lessons',
                    'is_multiple'  => true
                ]
            ]
        ];

        return $groups;
    }

    /** Apply the same any/all and none-of-selected semantics as LifterLMS lessons. */
    public function addAdvancedFilter($query, $filters)
    {
        foreach ($filters as $filter) {
            $operator = Arr::get($filter, 'operator');
            $lessonIds = array_values(array_unique(array_filter(array_map('intval', (array)Arr::get($filter, 'value', [])), function ($id) {
                return $id > 0;
            })));

            if (Arr::get($filter, 'property') != 'completed_lessons' || !$lessonIds ||
                !in_array($operator, ['in', 'in_all', 'not_in', 'not_in_all'], true)) {
                // An unfinished or unsupported filter must never widen the audience.
                $query->whereIn('id', []);
                continue;
            }

            $completedUsers = $this->getLessonCompletedUsersQuery($lessonIds);
            if (in_array($operator, ['not_in', 'not_in_all'], true)) {
                // Unlinked contacts match an exclusion.
                $query->where(function ($query) use ($completedUsers) {
                    $query->whereNull('user_id')->orWhereNotIn('user_id', $completedUsers);
                });
            } else {
                if ($operator == 'in_all') {
                    // A lesson can occur in multiple courses; count each lesson only once.
                    $completedUsers->groupBy('learnpress_user_items.user_id')
                        ->havingRaw('COUNT(DISTINCT item_id) = ?', [count($lessonIds)]);
                }
                $query->whereIn('user_id', $completedUsers);
            }
        }

        return $query;
    }

    /** Subquery of WP user IDs that completed any of the given lessons. */
    private function getLessonCompletedUsersQuery($lessonIds)
    {
        return fluentCrmDb()->table('learnpress_user_items')
            ->select('learnpress_user_items.user_id')
            ->join('posts', 'posts.ID', '=', 'learnpress_user_items.item_id')
            ->where('posts.post_type', 'lp_lesson')
            ->where('learnpress_user_items.item_type', 'lp_lesson')
            ->where('learnpress_user_items.status', 'completed')
            ->whereIn('learnpress_user_items.item_id', $lessonIds);
    }

    /** Return up to 50 matching lessons plus saved values, including saved trashed lessons. */
    public function getLessonOptions($options, $search, $includeIds)
    {
        global $wpdb;

        $search = sanitize_text_field($search);
        $includeIds = array_filter(array_map('intval', (array)$includeIds), function ($id) {
            return $id > 0;
        });
        $query = fluentCrmDb()->table('posts')
            ->select(['ID', 'post_title'])
            ->where('post_type', 'lp_lesson');
        $searchQuery = clone $query;
        $searchQuery->where('post_status', '!=', 'trash');
        if ($search !== '') {
            $searchQuery->where('post_title', 'LIKE', '%' . $wpdb->esc_like($search) . '%');
        }

        $lessons = $searchQuery->orderBy('post_date', 'DESC')->orderBy('ID', 'DESC')->limit(50)->get();
        $formattedLessons = [];
        foreach ($lessons as $lesson) {
            $formattedLessons[$lesson->ID] = [
                'id'    => strval($lesson->ID),
                'title' => $lesson->post_title
            ];
        }

        // Saved values outside the current search still need labels.
        $missingIds = array_diff($includeIds, array_keys($formattedLessons));
        if ($missingIds) {
            foreach ($query->whereIn('ID', $missingIds)->get() as $lesson) {
                $formattedLessons[$lesson->ID] = [
                    'id'    => strval($lesson->ID),
                    'title' => $lesson->post_title
                ];
            }
        }

        return array_values($formattedLessons);
    }

    public function pushCoursesOnProfile($sections)
    {
        $sections['learnpress_profile_courses'] = [
            'name'    => 'fluentcrm_profile_extended',
            'title'   => __('Courses', 'fluentcampaign-pro'),
            'handler' => 'route',
            'query'   => [
                'handler' => 'learnpress_profile_courses'
            ]
        ];

        return $sections;
    }

    public function pushCoursesContent($content, $subscriber)
    {
        $content['heading'] = __('LearnPress Courses', 'fluentcampaign-pro');

        $userId = $subscriber->user_id;

        if (!$userId) {
            $content['content_html'] = '<p>' . __('No enrolled courses found for this contact', 'fluentcampaign-pro') . '</p>';
            return $content;
        }

        $enrollments = fluentCrmDb()->table('learnpress_user_items')
            ->select(['learnpress_user_items.*', 'posts.post_title'])
            ->where('learnpress_user_items.item_type', 'lp_course')
            ->where('learnpress_user_items.user_id', $subscriber->user_id)
            ->join('posts', 'posts.ID', '=', 'learnpress_user_items.item_id')
            ->orderBy('learnpress_user_items.user_item_id', 'DESC')
            ->get();

        if ($enrollments->isEmpty()) {
            $content['content_html'] = '<p>' . __('No enrolled courses found for this contact', 'fluentcampaign-pro') . '</p>';
            return $content;
        }

        $tableBuilder = new TableBuilder();
        foreach ($enrollments as $enrollment) {
            $tableBuilder->addRow([
                'id'                => $enrollment->item_id,
                'title'             => $enrollment->post_title,
                'status'            => ucfirst($enrollment->status),
                'graduation_status' => ucfirst($enrollment->graduation),
                'started_at'        => date_i18n(get_option('date_format'), strtotime($enrollment->start_time)),
            ]);
        }

        $tableBuilder->setHeader([
            'id'                => __('Course ID', 'fluentcampaign-pro'),
            'title'             => __('Course Name', 'fluentcampaign-pro'),
            'status'            => __('Status', 'fluentcampaign-pro'),
            'graduation_status' => __('Graduation Status', 'fluentcampaign-pro'),
            'started_at'        => __('Started At', 'fluentcampaign-pro'),
        ]);

        $content['content_html'] = $tableBuilder->getHtml();
        return $content;
    }

    public function addBoxes()
    {
        add_meta_box(
            'fluentcrm_lp_course_meta', __('FluentCRM Settings', 'fluentcampaign-pro'), array($this, 'courseMetaBox',
        ), 'lp_course', 'normal', 'default');

        add_meta_box(
            'fluentcrm_lp_lesson_meta', __('FluentCRM Settings', 'fluentcampaign-pro'), array($this, 'lessonMetaBox',
        ), 'lp_lesson', 'normal', 'default');
    }

    public function courseMetaBox($post)
    {
        $settings = [
            'enroll_tags'    => [],
            'completed_tags' => []
        ];

        $crmSettings = get_post_meta($post->ID, '_fcrm_settings', true);
        if ($crmSettings) {
            $settings = wp_parse_args($crmSettings, $settings);
        }

        $tags = Tag::orderBy('title', 'ASC')->get();
        ?>
        <table class="form-table">
            <tr>
                <th><label
                        for="fluentcrm_add_enroll_tags"><?php _e('Apply Tags on course enrollment', 'fluentcampaign-pro'); ?></label>
                </th>
                <td>
                    <input type="hidden" value="yes" name="_has_fcrm"/>
                    <select id="fluentcrm_add_enroll_tags"
                            placeholder="<?php esc_attr_e('Select tags', 'fluentcampaign-pro'); ?>" style="width:100%;"
                            class="fc_multi_select"
                            name="_fcrm[enroll_tags][]" multiple="multiple">
                        <?php foreach ($tags as $tag): ?>
                            <option
                                value="<?php echo $tag->id; ?>" <?php if (in_array($tag->id, $settings['enroll_tags'])) {
                                echo 'selected';
                            } ?> ><?php echo $tag->title; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span
                        class="description"><?php esc_html_e('Apply these tags on course enrollment', 'fluentcampaign-pro'); ?></span>
                </td>
            </tr>
            <tr>
                <th><label
                        for="fluentcrm_add_completed_tags"><?php _e('Apply Tags on course completion', 'fluentcampaign-pro'); ?></label>
                </th>
                <td>
                    <select id="fluentcrm_add_completed_tags"
                            placeholder="<?php esc_attr_e('Select tags', 'fluentcampaign-pro'); ?>" style="width:100%;"
                            class="fc_multi_select"
                            name="_fcrm[completed_tags][]" multiple="multiple">
                        <?php foreach ($tags as $tag): ?>
                            <option
                                value="<?php echo $tag->id; ?>" <?php if (in_array($tag->id, $settings['completed_tags'])) {
                                echo 'selected';
                            } ?> ><?php echo $tag->title; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <span
                        class="description"><?php esc_html_e('Apply these tags on course completion', 'fluentcampaign-pro'); ?></span>
                </td>
            </tr>
        </table>
        <?php
        (new MetaFormBuilder())->initMultiSelect('.fc_multi_select', __('Select tags', 'fluentcampaign-pro'));
    }

    public function lessonMetaBox($post)
    {
        $settings = [
            'completed_tags' => []
        ];

        $crmSettings = get_post_meta($post->ID, '_fcrm_settings', true);
        if ($crmSettings) {
            $settings = wp_parse_args($crmSettings, $settings);
        }

        $tags = Tag::orderBy('title', 'ASC')->get();
        ?>
        <table class="form-table">
            <tr>
                <th><label
                        for="fluentcrm_add_completed_tags"><?php _e('Apply Tags on Lesson Completion', 'fluentcampaign-pro'); ?></label>
                </th>
                <td>
                    <input type="hidden" value="yes" name="_has_fcrm"/>
                    <select id="fluentcrm_add_completed_tags"
                            placeholder="<?php esc_attr_e('Select tags', 'fluentcampaign-pro'); ?>" style="width:100%;"
                            class="fc_multi_select"
                            name="_fcrm[completed_tags][]" multiple="multiple">
                        <?php foreach ($tags as $tag): ?>
                            <option
                                value="<?php echo $tag->id; ?>" <?php if (in_array($tag->id, $settings['completed_tags'])) {
                                echo 'selected';
                            } ?> ><?php echo $tag->title; ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
        </table>
        <?php
        (new MetaFormBuilder())->initMultiSelect('.fc_multi_select', __('Select tags', 'fluentcampaign-pro'));
    }

    public function saveMetaBox($post_id)
    {
        if (!isset($_POST['_has_fcrm']) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || $_POST['post_type'] == 'revision') {
            return;
        }

        if (isset($_POST['_fcrm'])) {
            $data = wp_unslash($_POST['_fcrm']);
        } else {
            $data = array();
        }

        update_post_meta($post_id, '_fcrm_settings', $data);
    }

    public function courseEnrolled($course_id, $user_id)
    {
        $settings = get_post_meta($course_id, '_fcrm_settings', true);

        if (!$settings || empty($settings['enroll_tags'])) {
            return false;
        }

        $contact = Helper::getWPMapUserInfo($user_id);

        $contact['tags'] = $settings['enroll_tags'];

        FunnelHelper::createOrUpdateContact($contact);

        return true;
    }

    public function courseFinished($course)
    {
        $courseId = $course->item_id;
        $userId   = $course->user_id;
        if (!$courseId || !$userId) {
            return false;
        }
        $settings = get_post_meta($courseId, '_fcrm_settings', true);

        if (!$settings || empty($settings['completed_tags'])) {
            return false;
        }

        $contact = Helper::getWPMapUserInfo($userId);

        $contact['tags'] = $settings['completed_tags'];

        FunnelHelper::createOrUpdateContact($contact);

        return true;
    }

    public function lessonCompleted($lessonId, $result, $userId)
    {
        $settings = get_post_meta($lessonId, '_fcrm_settings', true);

        if (!$settings || empty($settings['completed_tags'])) {
            return false;
        }

        $contact = Helper::getWPMapUserInfo($userId);

        $contact['tags'] = $settings['completed_tags'];

        FunnelHelper::createOrUpdateContact($contact);

        return true;
    }
    public function addDeepIntegrationProvider($providers)
    {
        $providers['learnpress'] = [
                'title'       => __('LearnPress', 'fluentcampaign-pro'),
                'sub_title'   => __('With the LearnPress integration, you can track your courses, apply tags automatically and segment your students.', 'fluentcampaign-pro'),
                'type'        => 'lms',
                'is_enabled'  => true,
                'logo'        => fluentCrmMix('images/learnpress.png'),
                'settings'    => null
        ];

        return $providers;
    }
}
