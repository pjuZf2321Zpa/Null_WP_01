<?php

namespace FluentCampaign\App\Services\Integrations\Voxel;

use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Services\Funnel\BaseTrigger;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Funnel\FunnelProcessor;

class VoxelOrderPlacedTrigger extends BaseTrigger
{
    public function __construct()
    {
        $this->triggerName = 'voxel/app-events/products/orders/customer:order_placed';
        $this->priority = 20;
        $this->actionArgNum = 1;
        parent::__construct();
    }

    public function getTrigger()
    {
        return [
            'category'    => __('Voxel', 'fluentcampaign-pro'),
            'label'       => __('Order Placed', 'fluentcampaign-pro'),
            'icon'        => 'el-icon-shopping-cart-1',
            'description' => __('This automation will start when a customer places an order', 'fluentcampaign-pro')
        ];
    }

    public function getFunnelSettingsDefaults()
    {
        return [
            'subscription_status' => 'subscribed'
        ];
    }

    public function getSettingsFields($funnel)
    {
        return [
            'title'     => __('Voxel Order Placed', 'fluentcampaign-pro'),
            'sub_title' => __('This automation will start when a customer places a new order', 'fluentcampaign-pro'),
            'fields'    => [
                'subscription_status'      => [
                    'type'        => 'option_selectors',
                    'option_key'  => 'editable_statuses',
                    'is_multiple' => false,
                    'label'       => __('Subscription Status', 'fluentcampaign-pro'),
                    'placeholder' => __('Select status', 'fluentcampaign-pro')
                ],
                'subscription_status_info' => [
                    'type'       => 'html',
                    'info'       => '<b>' . __('An automated double opt-in email will be sent to new contacts', 'fluentcampaign-pro') . '</b>',
                    'dependency' => [
                        'depends_on' => 'subscription_status',
                        'operator'   => '=',
                        'value'      => 'pending'
                    ]
                ]
            ]
        ];
    }

    public function getFunnelConditionDefaults($funnel)
    {
        return [
            'product_types' => [],
            'run_multiple'       => 'no'
        ];
    }

    public function getConditionFields($funnel)
    {
        return [
            'product_types' => [
                'type'        => 'rest_selector',
                'option_key'  => 'voxel_product_types',
                'is_multiple' => true,
                'label'       => __('Target Product Types', 'fluentcampaign-pro'),
                'help'        => __('Select the product types that start this automation', 'fluentcampaign-pro'),
                'inline_help' => __('Leave blank to run for products in any category', 'fluentcampaign-pro')
            ],
            'run_multiple'       => [
                'type'        => 'yes_no_check',
                'label'       => '',
                'check_label' => __('Allow this event to restart the automation for the same contact', 'fluentcampaign-pro'),
                'inline_help' => __('If enabled, it will restart the automation for a contact who is already in it. Otherwise, the contact will be skipped.', 'fluentcampaign-pro')
            ]
        ];
    }

    public function handle($funnel, $originalArgs)
    {
        $event = $originalArgs[0]; // this now equal to $event in hook

        $orderId = $event->order->get_id(); // Using the getter method instead of direct property access

        $customerId = $event->customer->get_id(); // Using the getter method instead of direct property access

        $user = \Voxel\User::get($customerId);

        $email = $user->get_email(); // Assuming this method exists to get the email


        $subscriber = Subscriber::where('email', $email)->first();

        if (!$subscriber) {
            return;
        }

        $order = \Voxel\Product_Types\Orders\Order::get($orderId);
        if (!$order) {
            return;
        }

        $subscriberData = [
            'email'                => $email,
            'first_name'          => $user->get_first_name(),
            'last_name'           => $user->get_last_name(),
        ];

        $subscriberData = FunnelHelper::maybeExplodeFullName($subscriberData);

        if (!is_email($subscriberData['email'])) {
            return;
        }

        $willProcess = $this->isProcessable($funnel, $order, $subscriberData, $orderId);

        $triggerName = 'voxel_customer_order_placed'; // we modified the trigger name to be more specific

        $willProcess = apply_filters('fluentcrm_funnel_will_process_' . $triggerName, $willProcess, $funnel, $subscriberData, $originalArgs);
        if (!$willProcess) {
            return;
        }

        $subscriberData = wp_parse_args($subscriberData, $funnel->settings);

        $subscriberData['status'] = (!empty($subscriberData['subscription_status'])) ? $subscriberData['subscription_status'] : 'subscribed';
        unset($subscriberData['subscription_status']);

        (new FunnelProcessor())->startFunnelSequence($funnel, $subscriberData, [
            'source_trigger_name' => $triggerName,
            'source_ref_id'       => $orderId
        ]);

    }

    private function isProcessable($funnel, $order, $subscriber, $orderId)
    {
        $conditions = $funnel->conditions;

        if (!empty($conditions['product_types']) && class_exists('\Voxel\Product_Type')) {
            // A cart can hold several product types; any of them may match (reading one row
            // checked whichever item the database returned first).
            $orderProductTypes = fluentCrmDb()->table('vx_order_items')
                ->where('order_id', $orderId)
                ->pluck('product_type')
                ->toArray();

            if (!array_intersect($orderProductTypes, (array)$conditions['product_types'])) {
                return false;
            }
        }

        return true;
    }
}