<?php

namespace FluentCampaign\App\Services\Integrations\Edd;

use FluentCrm\App\Models\FunnelSequence;
use FluentCrm\App\Services\Funnel\BaseBenchMark;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Funnel\FunnelProcessor;
use FluentCrm\Framework\Support\Arr;

class EddSubscriptionActiveBenchmark extends BaseBenchMark
{
    public function __construct()
    {
        $this->triggerName = 'edd_subscription_status_change';
        $this->actionArgNum = 3;
        $this->priority = 20;
        
        parent::__construct();

        add_action('edd_subscription_post_create', array($this, 'handleCreatedActive'), 20, 2);
    }

    /**
     * Complete the goal for a subscription created already active.
     *
     * EDD_Subscription::create() changes the status before the object is set up, so the status
     * change event carries no customer and no product, and handle() could not act on it. The
     * subscription is complete in the database when edd_subscription_post_create fires.
     *
     * @param int $subscriptionId
     * @param array $args
     */
    public function handleCreatedActive($subscriptionId, $args = [])
    {
        if (Arr::get($args, 'status') !== 'active' || !class_exists('\EDD_Subscription')) {
            return;
        }

        $subscription = new \EDD_Subscription($subscriptionId);
        if (!$subscription->id) {
            return;
        }

        $benchmarks = FunnelSequence::where('type', 'benchmark')
            ->where('action_name', $this->triggerName)
            ->whereHas('funnel', function ($query) {
                $query->where('status', 'published');
            })
            ->get();
        foreach ($benchmarks as $benchmark) {
            $this->handle($benchmark, ['pending', 'active', $subscription]);
        }
    }

    public function getBlock()
    {
        return [
            'title'       => __('[EDD] Recurring Subscription Active', 'fluentcampaign-pro'),
            'description' => __('This will run when a subscription becomes active', 'fluentcampaign-pro'),
            'icon' => 'el-icon-check',
            'settings'    => [
                'product_ids'        => [],
                'type'               => 'required',
                'can_enter' => 'yes'
            ]
        ];
    }

    public function getDefaultSettings()
    {
        return [
            'product_ids'        => [],
            'type'               => 'required',
            'can_enter' => 'yes'
        ];
    }

    public function getBlockFields($funnel)
    {
        return [
            'title'     => __('EDD Recurring Subscription Active', 'fluentcampaign-pro'),
            'sub_title' => __('This will run when a subscription becomes active', 'fluentcampaign-pro'),
            'fields'    => [
                'product_ids'        => [
                    'type'        => 'rest_selector',
                    'option_key'  => 'edd_products',
                    'is_multiple' => true,
                    'label'       => __('Target Products', 'fluentcampaign-pro'),
                    'help'        => __('Select the products that complete this goal', 'fluentcampaign-pro'),
                    'inline_help' => __('Leave blank to run for any product purchase', 'fluentcampaign-pro')
                ],
                'type'               => $this->benchmarkTypeField(),
                'can_enter' => $this->canEnterField()
            ]
        ];
    }

    /*
     * @todo: remove at January 2023
     */
    public function canEnterField()
    {
        return [
            'type'        => 'yes_no_check',
            'check_label' => __('Contacts can enter the automation directly at this point. If enabled, any contact who meets this goal will enter here.', 'fluentcampaign-pro'),
            'default_set_value' => 'yes'
        ];
    }


    public function handle($benchMark, $originalArgs)
    {
        $oldStatus = $originalArgs[0];
        $newStatus = $originalArgs[1];
        if ($newStatus != 'active' || $newStatus == $oldStatus) {
            return false;
        }

        $subscription = $originalArgs[2];

        $conditions = (array) $benchMark->settings;

        $customer = $subscription->customer;

        if(!$customer || !$customer->user_id) {
            return false;
        }

        if (!empty($conditions['product_ids'])) {
            if (!in_array($subscription->product_id, $conditions['product_ids'])) {
                return false;
            }
        }

        $subscriberData = FunnelHelper::prepareUserData($customer->user_id);
        $subscriberData['source'] = 'edd';

        if (!is_email($subscriberData['email'])) {
            return false;
        }
        // Never subscribes anyone: an existing contact is used as is, a new one only if the goal
        // lets them in. Older FluentCRM versions without the helper keep the previous upsert.
        if (method_exists(FunnelHelper::class, 'contactForBenchmark')) {
            $subscriber = FunnelHelper::contactForBenchmark($subscriberData, $benchMark);
        } else {
            $subscriberData['status'] = 'subscribed';
            $subscriber = FunnelHelper::createOrUpdateContact($subscriberData);
        }

        if(!$subscriber) {
            return false;
        }

        $funnelProcessor = new FunnelProcessor();
        $funnelProcessor->startFunnelFromSequencePoint($benchMark, $subscriber, []);
    }

}
