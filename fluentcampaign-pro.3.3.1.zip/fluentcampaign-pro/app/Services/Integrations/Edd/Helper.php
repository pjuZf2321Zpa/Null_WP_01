<?php

namespace FluentCampaign\App\Services\Integrations\Edd;

use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Helper as CrmHelper;

class Helper
{
    public static function getProducts()
    {
        // get edd products order by title
        $downloads = get_posts([
            'post_type'   => 'download',
            'numberposts' => -1,
            'orderby'     => 'title',
            'order'       => 'ASC'
        ]);

        $formattedProducts = [];
        foreach ($downloads as $download) {
            $formattedProducts[] = [
                'id'    => strval($download->ID),
                'title' => $download->post_title
            ];
        }

        return $formattedProducts;
    }

    public static function getCategories()
    {
        $categories = get_terms('download_category', array(
            'orderby'    => 'name',
            'order'      => 'asc',
            'hide_empty' => true,
        ));

        $formattedOptions = [];
        foreach ($categories as $category) {
            $formattedOptions[] = [
                'id'    => strval($category->term_id),
                'title' => $category->name
            ];
        }

        return $formattedOptions;
    }

    public static function purchaseTypeOptions()
    {
        return [
            [
                'id'    => 'all',
                'title' => __('Any type of purchase', 'fluentcampaign-pro')
            ],
            [
                'id'    => 'first_purchase',
                'title' => __('Only for first purchase', 'fluentcampaign-pro')
            ],
            [
                'id'    => 'from_second',
                'title' => __('From second purchase', 'fluentcampaign-pro')
            ]
        ];
    }

    /**
     * @param $payment \EDD_Payment
     * @param $conditions
     * @return bool
     */
    public static function isProductIdCategoryMatched($payment, $conditions)
    {
        $purchaseProductIds = [];
        foreach ($payment->cart_details as $item) {
            $purchaseProductIds[] = $item['id'];
        }

        if (!empty($conditions['product_ids'])) {
            if (array_intersect($purchaseProductIds, $conditions['product_ids'])) {
                return true;
            }

            if (empty($conditions['product_categories'])) {
                return false;
            }

        }

        if ($targetCategories = $conditions['product_categories']) {

            $categoryMatch = fluentCrmDb()->table('term_relationships')
                ->join('term_taxonomy', 'term_relationships.term_taxonomy_id', '=', 'term_taxonomy.term_taxonomy_id')
                ->whereIn('term_relationships.object_id', $purchaseProductIds)
                ->whereIn('term_taxonomy.term_id', $targetCategories)
                ->count();

            if (!$categoryMatch) {
                return false;
            }
        }
        return true;
    }

    /**
     * Whether the order matches "first purchase" / "from second purchase".
     *
     * Counts the customer's other paid EDD 3 orders and adds this one. EDD_Customer::purchase_count
     * is recalculated in a deferred cron event, so while a trigger runs it does not include the
     * order being processed, and a second purchase counted as the first.
     *
     * @param \EDD_Payment|\EDD\Orders\Order $payment
     * @param string $purchaseType
     * @return bool
     */
    public static function isPurchaseTypeMatch($payment, $purchaseType)
    {
        if (!$purchaseType) {
            return true;
        }

        $orderId = isset($payment->ID) ? (int)$payment->ID : (int)$payment->id;
        $customerId = (int)$payment->customer_id;

        $purchaseCount = 1;
        if ($customerId) {
            $purchaseCount += (int)edd_count_orders([
                'customer_id' => $customerId,
                'type'        => 'sale',
                'status__in'  => ['complete', 'partially_refunded'],
                'id__not_in'  => [$orderId],
            ]);
        }

        if ($purchaseType == 'from_second') {
            return $purchaseCount >= 2;
        }

        if ($purchaseType == 'first_purchase') {
            return $purchaseCount <= 1;
        }

        return true;
    }

    /**
     * @param $payment \EDD_Payment
     * @return array
     */
    public static function prepareSubscriberData($payment)
    {
        if ($payment->user_id) {
            $subscriberData = FunnelHelper::prepareUserData($payment->user_id);
        } else {
            $subscriberData = [
                'first_name' => $payment->first_name,
                'last_name'  => $payment->last_name,
                'email'      => $payment->email,
                'ip'         => $payment->ip
            ];
        }

        return FunnelHelper::maybeExplodeFullName($subscriberData);
    }

    /**
     * Check whether a subscriber purchased any selected product in EDD 3 orders.
     */
    public static function isProductPurchased($productIds, $subscriber)
    {
        $productIds = array_filter(array_map('absint', (array) $productIds));

        if (!$productIds || !self::isEdd3()) {
            return false;
        }

        $userId = $subscriber->getWpUserId();

        // EDD 3 stores purchases in edd_orders and edd_order_items.
        $ordersQuery = fluentCrmDb()->table('edd_orders')
            ->join('edd_order_items', 'edd_orders.id', '=', 'edd_order_items.order_id')
            ->where('edd_orders.type', 'sale')
            ->whereIn('edd_orders.status', ['processing', 'complete', 'completed', 'partially_refunded'])
            ->whereIn('edd_order_items.product_id', $productIds);

        if ($userId) {
            $ordersQuery = $ordersQuery->where('edd_orders.user_id', $userId);
        }

        if (!$userId) {
            $customer = fluentCrmDb()->table('edd_customers')
                ->where('email', $subscriber->email)
                ->first();

            if (!$customer) {
                return false;
            }

            $ordersQuery = $ordersQuery->where('edd_orders.customer_id', $customer->id);
        }

        return !!$ordersQuery->first();
    }

    public static function getTagsCatsByProductIds($productIds)
    {
        $items = fluentCrmDb()->table('term_relationships')
            ->select(['term_taxonomy.term_id'])
            ->whereIn('term_relationships.object_id', $productIds)
            ->join('term_taxonomy', 'term_taxonomy.term_taxonomy_id', '=', 'term_relationships.term_taxonomy_id')
            ->whereIn('term_taxonomy.taxonomy', ['download_tag', 'download_category'])
            ->get();

        $formattedItems = [];

        foreach ($items as $item) {
            $formattedItems[] = $item->term_id;
        }

        return array_unique($formattedItems);
    }

    public static function getProductName($productId, $priceId = false, $separator = ' - ', $after = '', $disableCache = false)
    {
        $cacheKey = $productId . '_' . $priceId;

        static $names = [];

        if (isset($names[$cacheKey]) && !$disableCache) {
            return $names[$cacheKey];
        }

        $post = get_post($productId);

        if (!$post) {
            $names[$cacheKey] = '';
            return '';
        }

        $title = $post->post_title;

        if ($priceId) {
            $variations = edd_get_variable_prices($productId);
            if ($variations && isset($variations[$priceId]['name'])) {
                $title .= $separator . $variations[$priceId]['name'] . $after;
            }
        }

        $names[$cacheKey] = $title;

        return $names[$cacheKey];
    }

    public static function getSubscriptionLicenseProp($prop, $subscriber, $productId)
    {
        if ($prop == 'has_active_license') {
            return self::hasValidLicense($subscriber, $productId);
        }

        if ($prop == 'has_active_subscription') {
            return self::hasActiveSubscription($subscriber, $productId);
        }
        return false;
    }

    public static function hasValidLicense($subscriber, $productIds)
    {

        if (!defined('EDD_SL_VERSION') || empty($productIds)) {
            return false;
        }

        $userId = $subscriber->getWpUserId();
        if (!$userId) {
            return false;
        }

        $hasLicense = fluentCrmDb()->table('edd_licenses')
            ->where('user_id', $userId)
            ->whereIn('status', ['active', 'inactive'])
            ->whereIn('download_id', $productIds)
            ->first();

        return !!$hasLicense;
    }

    /**
     * Whether the contact has an active EDD Recurring subscription for one of the products, as EDD
     * defines it (EDD_Subscription::is_active()): active, trialling, or cancelled but not expired
     * (and completed when "treat completed as active" is on). Checking status = active only sent
     * trialling and paid-up cancelled subscribers down the "No" branch.
     *
     * @param \FluentCrm\App\Models\Subscriber $subscriber
     * @param int[] $productIds
     * @return bool
     */
    public static function hasActiveSubscription($subscriber, $productIds)
    {
        if (!defined('EDD_RECURRING_VERSION') || empty($productIds) || !class_exists('\EDD_Subscription')) {
            return false;
        }

        $userId = $subscriber->getWpUserId();
        if (!$userId) {
            return false;
        }

        $customer = fluentCrmDb()->table('edd_customers')
            ->where('user_id', $userId)
            ->orWhere('email', $subscriber->email)
            ->first();
        if (!$customer) {
            return false;
        }

        $subscriptionIds = fluentCrmDb()->table('edd_subscriptions')
            ->where('customer_id', $customer->id)
            ->whereIn('status', ['active', 'trialling', 'cancelled', 'completed'])
            ->whereIn('product_id', (array)$productIds)
            ->pluck('id');

        foreach ($subscriptionIds as $subscriptionId) {
            if ((new \EDD_Subscription($subscriptionId))->is_active()) {
                return true;
            }
        }

        return false;
    }

    public static function hasSubscriptionInStatus($subscriber, $productIds, $statuses = ['active'])
    {
        if (!defined('EDD_RECURRING_VERSION') || empty($productIds)) {
            return false;
        }

        $userId = $subscriber->getWpUserId();

        if (!$userId) {
            return false;
        }

        $customer = fluentCrmDb()->table('edd_customers')
            ->where('user_id', $userId)
            ->orWhere('email', $subscriber->email)
            ->first();

        if (!$customer) {
            return false;
        }

        $hasSubscription = fluentCrmDb()->table('edd_subscriptions')
            ->where('customer_id', $customer->id)
            ->whereIn('status', $statuses)
            ->whereIn('product_id', $productIds)
            ->first();

        return !!$hasSubscription;
    }

    public static function isEddTrigger($triggerName)
    {
        $supportedTriggers = [
            'edd_update_payment_status',
            'edd_fc_order_refunded_simulation',
            'edd_update_payment_status',
            'edd_recurring_add_subscription_payment'
        ];

        return in_array($triggerName, $supportedTriggers);
    }

    /**
     * Proxy the shared FluentCRM EDD support check for Pro EDD modules.
     *
     * @return bool
     */
    public static function isEdd3()
    {
        return method_exists(CrmHelper::class, 'isEdd3') && CrmHelper::isEdd3();
    }
}
