<?php

namespace FluentCampaign\App\Services\Integrations\WooCommerce;

use FluentCrm\App\Models\Funnel;
use FluentCrm\App\Services\Funnel\BaseTrigger;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Funnel\FunnelProcessor;
use FluentCrm\Framework\Support\Arr;

class WooOrderSuccessTrigger extends BaseTrigger
{
    public function __construct()
    {
        $this->triggerName = 'woocommerce_order_status_processing';
        $this->priority = 20;
        $this->actionArgNum = 2;
        parent::__construct();

        add_action('woocommerce_order_status_changed', array($this, 'maybeHandlePaidAsCompleted'), 20, 4);
    }

    /**
     * Start "New Order (Processing)" automations for orders that skip Processing.
     *
     * Virtual and downloadable orders go straight to Completed on payment, so the Processing hook
     * never fires for them. The old alias was registered for Completed funnels, not these.
     * An order that was Processing first already started them there.
     *
     * @param int $orderId
     * @param string $from
     * @param string $to
     * @param \WC_Order $order
     */
    public function maybeHandlePaidAsCompleted($orderId, $from, $to, $order = null)
    {
        $order = $order ?: wc_get_order($orderId);
        if (!self::isNewOrderCompleted($from, $to, $order)) {
            return;
        }

        $funnels = Funnel::where('status', 'published')->where('trigger_name', $this->triggerName)->get();
        foreach ($funnels as $funnel) {
            $this->handle($funnel, [$orderId, $order]);
        }
    }

    /**
     * Whether a change to Completed is a new order being paid, which skipped Processing.
     *
     * Only an unpaid new order counts: an admin restoring a cancelled or refunded order, or an
     * importer marking old orders Completed, is not a new order. Subscription renewals are left
     * out as they were before this path existed (the renewal triggers cover them).
     *
     * @param string $from
     * @param string $to
     * @param \WC_Order|false $order
     * @return bool
     */
    public static function isNewOrderCompleted($from, $to, $order)
    {
        if ($to !== 'completed' || !in_array($from, ['pending', 'on-hold', 'checkout-draft', 'failed'], true)) {
            return false;
        }

        if (!$order) {
            return false;
        }

        return !(function_exists('wcs_order_contains_renewal') && wcs_order_contains_renewal($order));
    }

    public function getTrigger()
    {
        return [
            'category'    => __('WooCommerce', 'fluentcampaign-pro'),
            'label'       => __('New Order (Processing)', 'fluentcampaign-pro'),
            'description' => __('This automation starts when a new order reaches Processing or goes directly to Completed', 'fluentcampaign-pro'),
            'icon'        => 'fc-icon-woo_new_order',
        ];
    }

    public function getFunnelSettingsDefaults()
    {
        return [
            'subscription_status' => 'subscribed'
        ];
    }

    public function getSettingsFields($funnel)
    {
        return [
            'title'     => __('New WooCommerce Order (Processing) has been placed', 'fluentcampaign-pro'),
            'sub_title' => __('This automation starts when a new order reaches Processing or goes directly to Completed', 'fluentcampaign-pro'),
            'fields'    => [
                'subscription_status'      => [
                    'type'        => 'option_selectors',
                    'option_key'  => 'editable_statuses',
                    'is_multiple' => false,
                    'label'       => __('Subscription Status', 'fluentcampaign-pro'),
                    'placeholder' => __('Select status', 'fluentcampaign-pro')
                ],
                'subscription_status_info' => [
                    'type'       => 'html',
                    'info'       => '<b>' . __('An automated double opt-in email will be sent to new contacts', 'fluentcampaign-pro') . '</b>',
                    'dependency' => [
                        'depends_on' => 'subscription_status',
                        'operator'   => '=',
                        'value'      => 'pending'
                    ]
                ]
            ]
        ];
    }

    public function getFunnelConditionDefaults($funnel)
    {
        return [
            'product_ids'        => [],
            'product_categories' => [],
            'purchase_type'      => 'all',
            'run_multiple'       => 'no'
        ];
    }

    public function getConditionFields($funnel)
    {
        return [
            'product_ids'        => [
                'type'        => 'rest_selector',
                'option_key'  => 'woo_products',
                'is_multiple' => true,
                'label'       => __('Target Products', 'fluentcampaign-pro'),
                'help'        => __('Select the products this automation will run for', 'fluentcampaign-pro'),
                'inline_help' => __('Leave blank to run for any product purchase', 'fluentcampaign-pro')
            ],
            'product_categories' => [
                'type'        => 'rest_selector',
                'option_key'  => 'woo_categories',
                'is_multiple' => true,
                'label'       => __('Or Target Product Categories', 'fluentcampaign-pro'),
                'help'        => __('Select the product categories this automation will run for', 'fluentcampaign-pro'),
                'inline_help' => __('Leave blank to run for products in any category', 'fluentcampaign-pro')
            ],
            'purchase_type'      => [
                'type'        => 'radio',
                'label'       => __('Purchase Type', 'fluentcampaign-pro'),
                'help'        => __('Select the purchase type', 'fluentcampaign-pro'),
                'options'     => Helper::purchaseTypeOptions(),
                'inline_help' => __('Select the type of purchase this automation should run for', 'fluentcampaign-pro')
            ],
            'run_multiple'       => [
                'type'        => 'yes_no_check',
                'label'       => '',
                'check_label' => __('Allow this event to restart the automation for the same contact', 'fluentcampaign-pro'),
                'inline_help' => __('If enabled, it will restart the automation for a contact who is already in it. Otherwise, the contact will be skipped.', 'fluentcampaign-pro')
            ]
        ];
    }

    public function handle($funnel, $originalArgs)
    {
        $orderId = $originalArgs[0];
        $order = $originalArgs[1];

        $subscriberData = Helper::prepareSubscriberData($order);

        $subscriberData = FunnelHelper::maybeExplodeFullName($subscriberData);

        if (!is_email($subscriberData['email'])) {
            return;
        }

        $willProcess = $this->isProcessable($funnel, $order, $subscriberData);

        $willProcess = apply_filters('fluentcrm_funnel_will_process_' . $this->triggerName, $willProcess, $funnel, $subscriberData, $originalArgs);
        if (!$willProcess) {
            return;
        }

        $subscriberData = wp_parse_args($subscriberData, $funnel->settings);

        $subscriberData['status'] = (!empty($subscriberData['subscription_status'])) ? $subscriberData['subscription_status'] : 'subscribed';
        unset($subscriberData['subscription_status']);

        (new FunnelProcessor())->startFunnelSequence($funnel, $subscriberData, [
            'source_trigger_name' => $this->triggerName,
            'source_ref_id'       => $orderId
        ]);
    }

    private function isProcessable($funnel, $order, $subscriberData)
    {
        $conditions = (array)$funnel->conditions;
        $purchaseType = Arr::get($conditions, 'purchase_type');
        $result = Helper::isPurchaseTypeMatch($order, $purchaseType) && Helper::isProductIdCategoryMatched($order, $conditions);

        if (!$result) {
            return false;
        }

        $subscriber = FunnelHelper::getSubscriber($subscriberData['email']);

        // check run_only_one
        if ($subscriber) {
            $funnelSub = FunnelHelper::ifAlreadyInFunnel($funnel->id, $subscriber->id);
            if ($funnelSub) {
                $multipleRun = Arr::get($conditions, 'run_multiple') == 'yes';
                if ($multipleRun) {
                    if ($funnelSub->source_ref_id == $order->get_id()) {
                        return false;
                    }
                    FunnelHelper::removeSubscribersFromFunnel($funnel->id, [$subscriber->id]);
                }
                return $multipleRun;
            }
        }

        return true;

    }
}
