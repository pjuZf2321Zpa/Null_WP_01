<?php

namespace FluentCampaign\App\Services\Integrations\WooCommerce;

/**
 * Which renewal order started a contact's run of a Woo Subscriptions renewal automation.
 *
 * Every renewal of a subscription has the same subscription id, so with "restart multiple times"
 * a run is tied to the renewal order the hook reported. WCS retries a failed renewal order on a
 * schedule of about a week, and each retry fires the hook again: the order ids are kept in contact
 * meta (it outlives the run, which a restart deletes) so an order seen before never restarts it,
 * while a new renewal order does.
 */
class WcsRenewalRuns
{
    /**
     * The renewal order the hook reported (its second argument), else the subscription's latest.
     *
     * @param \WC_Subscription $subscription
     * @param array            $originalArgs
     * @return int
     */
    public static function renewalOrderId($subscription, array $originalArgs)
    {
        $order = $originalArgs[1] ?? null;
        if (is_object($order) && method_exists($order, 'get_id')) {
            return (int) $order->get_id();
        }
        if (is_numeric($order) && (int) $order > 0) {
            return (int) $order;
        }

        return (int) $subscription->get_last_order('ids', 'renewal');
    }

    /**
     * Whether a contact already in the automation is restarted for this renewal order.
     *
     * The renewal orders that started runs are remembered as a set (see remember()), so a retry
     * of any of them, also after another subscription's renewal restarted the run, is not new.
     *
     * @param object $funnel
     * @param object $funnelSub   the contact's current run
     * @param int    $subscriberId
     * @param int    $renewalOrderId
     */
    public static function isNewRenewal($funnel, $funnelSub, $subscriberId, $renewalOrderId)
    {
        if (!$renewalOrderId) {
            return false;
        }

        $seen = self::seenOrders($funnel->id, $subscriberId);
        if ($seen) {
            return !in_array((int) $renewalOrderId, $seen, true);
        }

        // A run from before this was recorded: an order created before the run started it (or an
        // earlier renewal), so only a renewal order created after the run is new. created_at is
        // site time; the order date is UTC.
        $order = function_exists('wc_get_order') ? wc_get_order($renewalOrderId) : null;
        $orderCreated = ($order && $order->get_date_created()) ? $order->get_date_created()->getTimestamp() : 0;
        $runStarted = $funnelSub->created_at ? strtotime(get_gmt_from_date($funnelSub->created_at) . ' UTC') : 0;

        if ($orderCreated && $runStarted && $orderCreated <= $runStarted) {
            self::remember($funnel->id, $subscriberId, $renewalOrderId);
            return false;
        }

        return true;
    }

    /**
     * Record a renewal order that started (or belongs to) the contact's run. The last 20 are kept,
     * which covers several subscriptions with retries in flight.
     */
    public static function remember($funnelId, $subscriberId, $renewalOrderId)
    {
        if (!$subscriberId || !$renewalOrderId) {
            return;
        }

        $seen = self::seenOrders($funnelId, $subscriberId);
        if (!in_array((int) $renewalOrderId, $seen, true)) {
            $seen[] = (int) $renewalOrderId;
        }

        fluentcrm_update_subscriber_meta($subscriberId, self::metaKey($funnelId), implode(',', array_slice($seen, -20)));
    }

    /**
     * @return int[]
     */
    protected static function seenOrders($funnelId, $subscriberId)
    {
        $value = (string) fluentcrm_get_subscriber_meta($subscriberId, self::metaKey($funnelId), '');

        return array_values(array_filter(array_map('intval', explode(',', $value))));
    }

    protected static function metaKey($funnelId)
    {
        return '_fc_wcs_renewal_run_' . (int) $funnelId;
    }
}
