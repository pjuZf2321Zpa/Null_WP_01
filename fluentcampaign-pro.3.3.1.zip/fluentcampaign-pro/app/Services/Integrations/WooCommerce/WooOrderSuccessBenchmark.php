<?php

namespace FluentCampaign\App\Services\Integrations\WooCommerce;

use FluentCrm\App\Models\FunnelSequence;
use FluentCrm\App\Services\Funnel\BaseBenchMark;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Funnel\FunnelProcessor;
use FluentCrm\Framework\Support\Arr;

class WooOrderSuccessBenchmark extends BaseBenchMark
{
    public function __construct()
    {
        $this->triggerName = 'woocommerce_order_status_processing';
        $this->actionArgNum = 2;
        $this->priority = 20;

        parent::__construct();
        add_action('woocommerce_order_status_changed', array($this, 'maybeHandlePaidAsCompleted'), 20, 4);
    }

    /**
     * Complete "Order Received" goals for orders that go straight to Completed on payment (see
     * WooOrderSuccessTrigger::maybeHandlePaidAsCompleted()).
     *
     * @param int $orderId
     * @param string $from
     * @param string $to
     * @param \WC_Order $order
     */
    public function maybeHandlePaidAsCompleted($orderId, $from, $to, $order = null)
    {
        $order = $order ?: wc_get_order($orderId);
        if (!WooOrderSuccessTrigger::isNewOrderCompleted($from, $to, $order)) {
            return;
        }

        $benchmarks = FunnelSequence::where('type', 'benchmark')
            ->where('action_name', $this->triggerName)
            ->whereHas('funnel', function ($query) {
                $query->where('status', 'published');
            })
            ->get();
        foreach ($benchmarks as $benchmark) {
            $this->handle($benchmark, [$orderId, $order]);
        }
    }

    public function getBlock()
    {
        return [
            'title'       => __('Order Received in WooCommerce', 'fluentcampaign-pro'),
            'description' => __('This will run when a new order is placed with the Processing status', 'fluentcampaign-pro'),
            'icon' => 'fc-icon-woo_purchased',
            'settings'    => [
                'product_ids'        => [],
                'product_categories' => [],
                'purchase_type'      => 'all',
                'type'               => 'required',
                'can_enter' => 'yes'
            ]
        ];
    }

    public function getDefaultSettings()
    {
        return [
            'product_ids'        => [],
            'product_categories' => [],
            'purchase_type'      => '',
            'type'               => 'required',
            'can_enter' => 'yes'
        ];
    }

    public function getBlockFields($funnel)
    {
        return [
            'title'     => __('Order Received in WooCommerce', 'fluentcampaign-pro'),
            'sub_title' => __('This will run when a new order is placed with the Processing status', 'fluentcampaign-pro'),
            'fields'    => [
                'product_ids'        => [
                    'type'        => 'rest_selector',
                    'option_key'  => 'woo_products',
                    'is_multiple'    => true,
                    'label'       => __('Target Products', 'fluentcampaign-pro'),
                    'help'        => __('Select the products that complete this goal', 'fluentcampaign-pro'),
                    'inline_help' => __('Leave blank to run for any product purchase', 'fluentcampaign-pro')
                ],
                'product_categories' => [
                    'type'        => 'rest_selector',
                    'option_key'  => 'woo_categories',
                    'is_multiple'    => true,
                    'label'       => __('Or Target Product Categories', 'fluentcampaign-pro'),
                    'help'        => __('Select the product categories that complete this goal', 'fluentcampaign-pro'),
                    'inline_help' => __('Leave blank to run for products in any category', 'fluentcampaign-pro')
                ],
                'purchase_type'      => [
                    'type'        => 'radio',
                    'label'       => __('Purchase Type', 'fluentcampaign-pro'),
                    'help'        => __('Select the purchase type', 'fluentcampaign-pro'),
                    'options'     => Helper::purchaseTypeOptions(),
                    'inline_help' => __('Select the type of purchase this goal should run for', 'fluentcampaign-pro')
                ],
                'type'               => $this->benchmarkTypeField(),
                'can_enter' => $this->canEnterField()
            ]
        ];
    }

    /*
     * @todo: remove at January 2023
     */
    public function canEnterField()
    {
        return [
            'type'        => 'yes_no_check',
            'check_label' => __('Contacts can enter the automation directly at this point. If enabled, any contact who meets this goal will enter here.', 'fluentcampaign-pro'),
            'default_set_value' => 'yes'
        ];
    }

    public function handle($benchMark, $originalArgs)
    {
        $order = $originalArgs[1];
        $conditions = $benchMark->settings;


        if (!$this->isMatched($conditions, $order)) {
            return; // It's not a match
        }

        $subscriberData = Helper::prepareSubscriberData($order);

        $subscriberData = FunnelHelper::maybeExplodeFullName($subscriberData);

        if (!is_email($subscriberData['email'])) {
            return;
        }

        // Never subscribes anyone: an existing contact is used as is, a new one only if the goal
        // lets them in. Older FluentCRM versions without the helper keep the previous upsert.
        if (method_exists(FunnelHelper::class, 'contactForBenchmark')) {
            $subscriber = FunnelHelper::contactForBenchmark($subscriberData, $benchMark);
        } else {
            $subscriberData['status'] = 'subscribed';
            $subscriber = FunnelHelper::createOrUpdateContact($subscriberData);
        }

        if (!$subscriber) {
            return;
        }

        $funnelProcessor = new FunnelProcessor();
        $funnelProcessor->startFunnelFromSequencePoint($benchMark, $subscriber, [], [
            'benchmark_value'    => intval($order->get_total() * 100), // converted to cents
            'benchmark_currency' => $order->get_currency(),
        ]);
    }

    private function isMatched($conditions, $order)
    {
        $purchaseType = Arr::get($conditions, 'purchase_type');
        return Helper::isPurchaseTypeMatch($order, $purchaseType) && Helper::isProductIdCategoryMatched($order, $conditions);
    }
}
