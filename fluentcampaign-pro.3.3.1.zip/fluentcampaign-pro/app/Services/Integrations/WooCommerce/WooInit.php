<?php

namespace FluentCampaign\App\Services\Integrations\WooCommerce;

use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Services\AutoSubscribe;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\PermissionManager;
use FluentCrm\Framework\Support\Arr;

class WooInit
{
    public function init()
    {
        new \FluentCampaign\App\Services\Integrations\WooCommerce\WooOrderSuccessTrigger();
        new \FluentCampaign\App\Services\Integrations\WooCommerce\WooOrderSuccessBenchmark();
        new \FluentCampaign\App\Services\Integrations\WooCommerce\WooOrderCompletedTrigger();
        new \FluentCampaign\App\Services\Integrations\WooCommerce\WooOrderStatusChangeTrigger();
        new \FluentCampaign\App\Services\Integrations\WooCommerce\WooOrderRefundedTrigger();
        new \FluentCampaign\App\Services\Integrations\WooCommerce\OrderStatusChangeAction();
        new \FluentCampaign\App\Services\Integrations\WooCommerce\AddOrderNoteAction();
        new \FluentCampaign\App\Services\Integrations\WooCommerce\CreateCouponAction();

        /*
         * Dynamically create coupon smartcode for CreateCouponAction
         */
        add_action('fluent_crm/sequence_created_fcrm_create_woo_coupon', function ($createdSequence) {
            $settings = $createdSequence->settings;
            $settings['code_settings']['smart_code'] = '{{woo_coupon.' . $createdSequence->funnel_id . '_' . $createdSequence->id . '}}';
            $createdSequence->settings = $settings;
            $createdSequence->save();
        });

        add_filter('fluent_crm/admin_vars', function ($vars) {
            $vars['woo_currency_sign'] = get_woocommerce_currency_symbol();
            return $vars;
        });

        add_filter('fluent_crm/sales_stats', array($this, 'pushStatus'));

        add_action('woocommerce_new_order', [$this, 'maybeCampaignMeta'], 10, 2);

        add_action('woocommerce_order_status_changed', function ($orderId, $from, $to, $order) {
            if (!$order instanceof \WC_Order) {
                $order = wc_get_order($orderId);
            }

            if (!$order instanceof \WC_Order) {
                return;
            }

            // check if paid statuses
            $paidStatuses = wc_get_is_paid_statuses();
            if (!in_array($to, $paidStatuses)) {
                return;
            }

            $this->maybeRecordPayment($orderId, $order);
        }, 10, 4);

        add_action('add_meta_boxes', array($this, 'maybeAddOrderWidget'), 99, 2);

        add_filter('woocommerce_checkout_fields', array($this, 'addSubscribeBox'), 1, 100);
        add_action('woocommerce_checkout_update_order_meta', array($this, 'maybeSubscriptionChecked'), 99, 2);

        /*
         * Reverse campaign revenue while the deleted order is still readable.
         * HPOS deletes order rows before (or without) touching wp_posts; legacy storage
         * empties the trash through wp_delete_post() without the WooCommerce hook.
         * Exactly one hook per mode: the reversal is not idempotent for records without `orderIds`.
         */
        if (Helper::isWooHposEnabled()) {
            add_action('woocommerce_before_delete_order', array($this, 'updateCampaignRevenue'), 10, 2);
        } else {
            // One accepted argument: WordPress passes a WP_Post second, not an order.
            add_action('before_delete_post', array($this, 'updateCampaignRevenue'), 10, 1);
        }

        (new WooProductAdmin())->init();

        (new DeepIntegration())->init();
        new WooImporter();

        (new AutomationConditions())->init();
        (new WooSmartCodeParse())->init();

        if (defined('WCS_INIT_TIMESTAMP')) {
            new WooSubscriptionStartedTrigger();
            new WooSubscriptionRenewalPaymentTrigger();
            new WooSubscriptionRenewalFailedTrigger();
            new WooSubscriptionExpiredTrigger();
            new WooSubscriptionCancelledTrigger();
            add_filter('fluent_crm/subscriber_top_widgets', array($this, 'pushSubscriptionWidgets'), 10, 2);
        }

        // This class boots on `init` priority 1, after Woo may have already fired `woocommerce_init` (priority 0).
        $hasWooInitFired = did_action('woocommerce_init') > 0;
        $hasBlocksLoadedFired = did_action('woocommerce_blocks_loaded') > 0;

        if ($hasWooInitFired || $hasBlocksLoadedFired) {
            $this->addSubscribeBoxForBlockCheckout();
        }

        if (!$hasWooInitFired) {
            add_action('woocommerce_init', [$this, 'addSubscribeBoxForBlockCheckout']);
        }

        if (!$hasBlocksLoadedFired) {
            add_action('woocommerce_blocks_loaded', [$this, 'addSubscribeBoxForBlockCheckout']);
        }

        add_action('woocommerce_store_api_checkout_update_order_from_request', function ($order, $request) {
            $this->captureBlockCheckoutOptinState($order, $request);
            // Process opt-in here so pending contacts are created before later order-status sync hooks run.
            $this->maybeHandleBlockCheckoutSubscription($order);
        }, 20, 2);

        add_action('woocommerce_store_api_checkout_order_processed', function ($order) {
            $this->maybeCampaignMeta($order->get_id(), $order);
            $this->maybeHandleBlockCheckoutSubscription($order);
        });

        add_action('woocommerce_payment_complete', function ($orderId) {
            // need to update the campaign revenue here for block based checkout
            $order = wc_get_order($orderId);
            if (!$order instanceof \WC_Order) {
                return;
            }

            $this->maybeRecordPayment($orderId, $order);
            $this->maybeHandleBlockCheckoutSubscription($order);
        });
    }

    /**
     * Add WooCommerce sales totals to the FluentCRM dashboard stats list.
     */
    public function pushStatus($stats)
    {
        if (current_user_can('view_woocommerce_reports') || current_user_can('manage_woocommerce') || current_user_can('publish_shop_orders')) {

            $todaySales = $this->getWooSalesByRange($this->getWooDateRange('today'));
            $monthSales = $this->getWooSalesByRange($this->getWooDateRange('month'));

            // The totals come from WooCommerce Analytics only; without its data, no sales cards.
            if ($todaySales === null || $monthSales === null) {
                return $stats;
            }

            $wooStats = [
                [
                    'title'   => __('Sales (Today)', 'fluentcampaign-pro'),
                    'content' => wc_price($todaySales)
                ],
                [
                    'title'   => __('Sales (This Month)', 'fluentcampaign-pro'),
                    'content' => wc_price($monthSales)
                ]
            ];
            $stats = array_merge($stats, $wooStats);
        }
        return $stats;
    }

    /**
     * Build a site-timezone datetime range for today or the month to date.
     */
    private function getWooDateRange($period)
    {
        $currentTimestamp = current_time('timestamp');

        if ($period == 'month') {
            $startDate = gmdate('Y-m-01 00:00:00', $currentTimestamp);
        } else {
            $startDate = gmdate('Y-m-d 00:00:00', $currentTimestamp);
        }

        return [
            'start' => $startDate,
            'end'   => gmdate('Y-m-d 23:59:59', $currentTimestamp)
        ];
    }

    /**
     * Get WooCommerce report statuses with the wc- prefix that wc_order_stats stores.
     */
    private function getWooReportStatuses()
    {
        $statuses = apply_filters('woocommerce_reports_order_statuses', ['completed', 'processing', 'on-hold']);

        if (!$statuses || !is_array($statuses)) {
            $statuses = ['completed', 'processing', 'on-hold'];
        }

        $normalizedStatuses = [];
        foreach ($statuses as $status) {
            $status = sanitize_key($status);

            if (!$status) {
                continue;
            }

            if (strpos($status, 'wc-') !== 0) {
                $status = 'wc-' . $status;
            }

            $normalizedStatuses[] = $status;
        }

        return array_values(array_unique($normalizedStatuses));
    }

    /**
     * Get the configured analytics date column, whitelisted because it is interpolated into SQL.
     */
    private function getWooStatsDateColumn()
    {
        $dateColumn = get_option('woocommerce_date_type', 'date_paid');
        $allowedColumns = ['date_created', 'date_paid', 'date_completed'];

        if (!in_array($dateColumn, $allowedColumns, true)) {
            return 'date_paid';
        }

        return $dateColumn;
    }

    /**
     * Net sales from WooCommerce Analytics (wc_order_stats), in one query.
     *
     * Returns null when Analytics is turned off, missing, has another schema, or has no data: the
     * dashboard then shows no sales cards. Totalling orders any other way (the legacy report reads
     * wp_posts only; the order API loads every order) is wrong on HPOS or too heavy for a page view.
     *
     * @return float|null
     */
    private function getWooSalesByRange(array $range)
    {
        global $wpdb;

        // With Analytics turned off WooCommerce stops syncing wc_order_stats but keeps its rows.
        if (get_option('woocommerce_analytics_enabled', 'yes') === 'no') {
            return null;
        }

        $tableName = $wpdb->prefix . 'wc_order_stats';

        $tableExists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tableName));

        if ($tableExists != $tableName) {
            return null;
        }

        $columns = $wpdb->get_col('DESC ' . $tableName, 0);
        $requiredColumns = ['net_total', 'status', 'date_paid', 'date_completed', 'date_created'];

        if (!$columns || array_diff($requiredColumns, $columns)) {
            return null;
        }

        // The analytics table is empty until Woo has synced it.
        $hasOrderStats = absint($wpdb->get_var('SELECT 1 FROM ' . $tableName . ' LIMIT 1'));
        if (!$hasOrderStats) {
            return null;
        }

        $statuses = $this->getWooReportStatuses();
        if (!$statuses) {
            return null;
        }

        $statusPlaceholders = implode(', ', array_fill(0, count($statuses), '%s'));
        $dateColumn = $this->getWooStatsDateColumn();

        $sql = "SELECT COALESCE(SUM(net_total), 0) FROM {$tableName} WHERE status IN ({$statusPlaceholders}) AND {$dateColumn} >= %s AND {$dateColumn} <= %s";
        $queryParams = array_merge($statuses, [$range['start'], $range['end']]);

        $preparedSql = call_user_func_array([$wpdb, 'prepare'], array_merge([$sql], $queryParams));

        return (float) $wpdb->get_var($preparedSql);
    }

    public function maybeCampaignMeta($orderId, $order)
    {
        if (!isset($_COOKIE['fc_cid'])) {
            return false;
        }

        if (!$order instanceof \WC_Order) {
            $order = wc_get_order($orderId);
        }

        if (!$order instanceof \WC_Order) {
            return false;
        }

        $campaignId = intval($_COOKIE['fc_cid']);
        if ($campaignId) {
            $order->update_meta_data('_fc_cid', $campaignId);
            $order->save();
        }
    }


    /**
     * @param $orderId int
     * @param $order \WC_Order
     */
    public function maybeRecordPayment($orderId, $order)
    {
        $campaignId = $order->get_meta('_fc_cid');

        if ($campaignId) {
            if ($order->get_meta('_fc_revenue_recorded') == 'yes') {
                return;
            }

            $order->update_meta_data('_fc_revenue_recorded', 'yes');
            $order->save();
            $paymentTotal = intval($order->get_total() * 100);
            \FluentCrm\App\Services\Helper::recordCampaignRevenue($campaignId, $paymentTotal, $orderId, $order->get_currency());
        }
    }

    public function maybeAddOrderWidget($postType, $post)
    {
        if (!in_array($postType, ['woocommerce_page_wc-orders', 'shop_order'])) {
            return;
        }

        $hasPermission = apply_filters('fluent_crm/can_view_contact_card_in_plugin', PermissionManager::currentUserCan('fcrm_read_contacts'), 'woo');

        if (!$hasPermission) {
            return;
        }

        if ($postType == 'woocommerce_page_wc-orders') {
            $orderId = $post->get_id(); // for WooCommerce High Performance Order storage
        } else {
            $orderId = $post->ID; // for WordPress post tables $postType = 'shop_order';
        }
        $order = wc_get_order($orderId);

        $userId = $order->get_user_id();
        if (!$userId) {
            $userId = $order->get_billing_email();
        }

        $profileHtml = fluentcrm_get_crm_profile_html($userId, false);

        if (!$profileHtml) {
            return;
        }

        add_meta_box('fluentcrm_woo_order_widget', __('FluentCRM Profile', 'fluentcampaign-pro'), function () use ($profileHtml) {
            echo $profileHtml;
        }, $postType, 'side', 'low');
    }


    /**
     * Subtract a deleted order's recorded total from its campaign's revenue.
     *
     * @param int $orderId Order (legacy: post) ID being deleted.
     * @param \WC_Order|null $order Passed by woocommerce_before_delete_order; null from before_delete_post.
     */
    public function updateCampaignRevenue($orderId, $order = null)
    {
        if (!$order instanceof \WC_Order) {
            // before_delete_post fires for every post type; skip non-orders before loading anything.
            if (!Helper::isWooHposEnabled() && get_post_type($orderId) !== 'shop_order') {
                return;
            }

            $order = wc_get_order($orderId);
        }

        // Refunds and subscriptions carry no campaign revenue of their own.
        if (!$order instanceof \WC_Order || $order->get_type() !== 'shop_order') {
            return;
        }

        $campaignId = intval($order->get_meta('_fc_cid'));
        if (!$campaignId) {
            return;
        }

        // Attributed but unpaid orders never added to the total.
        if ($order->get_meta('_fc_revenue_recorded') != 'yes') {
            return;
        }

        $existing = fluentcrm_get_campaign_meta($campaignId, '_campaign_revenue');
        if (empty($existing) || !is_array($existing->value)) {
            return;
        }

        $currency = strtolower($order->get_currency());
        $orderTotal = intval($order->get_total() * 100);
        $orderId = $order->get_id();

        $currentValue = $existing->value;
        $orderIds = (isset($currentValue['orderIds']) && is_array($currentValue['orderIds']))
            ? $currentValue['orderIds']
            : null;

        if ($orderIds !== null && array_search($orderId, $orderIds) === false) {
            return;
        }

        if (!isset($currentValue[$currency]) || !is_numeric($currentValue[$currency])) {
            return;
        }

        if ($orderIds !== null) {
            $key = array_search($orderId, $orderIds);
            unset($orderIds[$key]);
            $currentValue['orderIds'] = array_values($orderIds);
        }

        $currentValue[$currency] = max(0, $currentValue[$currency] - $orderTotal);

        fluentcrm_update_campaign_meta($campaignId, '_campaign_revenue', $currentValue);
    }

    public function addSubscribeBox($fields)
    {
        $settings = fluentcrm_get_option('woo_checkout_form_subscribe_settings', []);

        if (!$settings || Arr::get($settings, 'status') != 'yes') {
            return $fields;
        }

        if (Arr::get($settings, 'show_only_new') == 'yes') {
            $contact = fluentcrm_get_current_contact();
            if ($contact && $contact->status == 'subscribed') {
                return $fields;
            }
        }

        $heading = Arr::get($settings, 'checkbox_label');

        $defaultValue = \WC()->checkout->get_value('_fc_woo_checkout_subscribe');

        if (Arr::get($settings, 'auto_checked') == 'yes') {
            $defaultValue = '1';
        }

        $ordersFields = Arr::get($fields, 'order', []);

        $checkboxField = [
            '_fc_woo_checkout_subscribe' => array(
                'type'          => 'checkbox',
                'label_class'   => 'fc_woo',
                'class'         => array('input-checkbox', 'fc_subscribe_woo'),
                'label'         => $heading,
                'checked_value' => '1',
                'default'       => $defaultValue
            )
        ];

        // add the checkbox field to the begining of $ordersFields
        $fields['order'] = array_merge($checkboxField, $ordersFields);

        $fields = apply_filters('fluent_crm/woo_checkout_fields', $fields);

        return $fields;
    }

    public function addSubscribeBoxForBlockCheckout()
    {
        static $isRegistered = false;

        if ($isRegistered) {
            return;
        }

        $registerField = null;

        if (function_exists('woocommerce_register_additional_checkout_field')) {
            $registerField = 'woocommerce_register_additional_checkout_field';
        } elseif (function_exists('__experimental_woocommerce_blocks_register_checkout_field')) {
            $registerField = '__experimental_woocommerce_blocks_register_checkout_field';
        }

        if (!$registerField) {
            // Not locked: `woocommerce_blocks_loaded` may make the API available later.
            return;
        }

        $settings = fluentCrmGetFromCache('woo_checkout_form_subscribe_settings', function () {
            return (new AutoSubscribe())->getWooCheckoutSettings();
        }, 86400);

        if (!$settings || Arr::get($settings, 'status') != 'yes') {
            $isRegistered = true;
            return;
        }

        if (Arr::get($settings, 'show_only_new') == 'yes') {
            $contact = fluentcrm_get_current_contact();
            if ($contact && $contact->status == 'subscribed') {
                $isRegistered = true;
                return;
            }
        }

        $isChecked = Arr::get($settings, 'auto_checked') == 'yes';

        add_filter('woocommerce_get_default_value_for_fluent-crm/_fc_woo_checkout_subscribe', function ($value) use ($isChecked) {
            if ($value) {
                return $value;
            }

            // Woo expects checkbox defaults as booleans in checkout fields service.
            return (bool)$isChecked;
        }, 10, 1);

        call_user_func($registerField, array(
            'id'                         => 'fluent-crm/_fc_woo_checkout_subscribe',          // Unique ID (use your theme/plugin namespace)
            'label'                      => Arr::get($settings, 'checkbox_label'),
            'location'                   => apply_filters('fluent_crm/woo_block_checkout_consent_position', 'order'),
            'type'                       => 'checkbox',
            'required'                   => false,
            'sanitize_callback'          => function ($value) {
                return (int) $value;
            },
            'show_in_order_confirmation' => false
        ));

        $isRegistered = true;
    }

    public function maybeSubscriptionChecked($orderId, $postedData)
    {
        $isChecked = Arr::get($postedData, '_fc_woo_checkout_subscribe') == 1;
        do_action('fluent_crm/before_woo_checkout_check', $isChecked, $orderId);

        if (!$isChecked) {
            return false;
        }

        $settings = (new AutoSubscribe())->getWooCheckoutSettings();
        if (!$settings || Arr::get($settings, 'status') != 'yes') {
            return false;
        }

        $order = wc_get_order($orderId);
        if (!$order instanceof \WC_Order) {
            return false;
        }

        return $this->addContactFromOrderOptin($order, $settings);
    }

    protected function maybeHandleBlockCheckoutSubscription($order)
    {
        if (!$order instanceof \WC_Order) {
            return false;
        }

        if ($order->get_meta('_fc_woo_checkout_optin_processed') === 'yes') {
            return true;
        }

        $optinValue = $order->get_meta('_fc_woo_checkout_subscribe', true);

        // Fall back to the Woo additional-fields meta key.
        if ($optinValue === '') {
            $optinValue = $order->get_meta('_wc_other/fluent-crm/_fc_woo_checkout_subscribe', true);
        }

        if ((string)$optinValue !== '1') {
            return false;
        }

        $processed = $this->maybeSubscriptionChecked($order->get_id(), [
            '_fc_woo_checkout_subscribe' => 1
        ]);

        if ($processed) {
            $order->update_meta_data('_fc_woo_checkout_optin_processed', 'yes');
            $order->save();
        }

        return (bool)$processed;
    }

    protected function captureBlockCheckoutOptinState($order, $request)
    {
        if (!$order instanceof \WC_Order) {
            return;
        }

        $additionalFields = [];

        if ($request instanceof \WP_REST_Request) {
            $additionalFields = (array)$request->get_param('additional_fields');
        } elseif (is_array($request)) {
            $additionalFields = (array)Arr::get($request, 'additional_fields', []);
        }

        $rawValue = Arr::get($additionalFields, 'fluent-crm/_fc_woo_checkout_subscribe', null);

        // Missing or empty means unchecked, overwriting any stale draft value.
        $isChecked = in_array($rawValue, [1, '1', true, 'true', 'yes', 'on'], true);

        $order->update_meta_data('_fc_woo_checkout_subscribe', $isChecked ? '1' : '0');
    }

    protected function addContactFromOrderOptin($order, $settings = null)
    {
        if (!$settings) {
            $settings = (new AutoSubscribe())->getWooCheckoutSettings();
        }

        $subscriberData = Helper::prepareSubscriberData($order);

        if ($listId = Arr::get($settings, 'target_list')) {
            $subscriberData['lists'] = [$listId];
        }

        if ($tags = Arr::get($settings, 'target_tags')) {
            $subscriberData['tags'] = $tags;
        }

        $isDoubleOptin = Arr::get($settings, 'double_optin') == 'yes';

        if ($isDoubleOptin) {
            $subscriberData['status'] = 'pending';
        } else {
            $subscriberData['status'] = 'subscribed';
        }

        $subscriberData = apply_filters('fluent_crm/woo_checkout_auto_subscribe_data', $subscriberData, $order);
        $contact = FunnelHelper::createOrUpdateContact($subscriberData);

        if (!$contact) {
            return false;
        }

        // Re-invite non-subscribed contacts; only the confirmation click promotes them.
        if ($isDoubleOptin && $contact->status != 'subscribed') {
            $contact->sendDoubleOptinEmail();
        }

        return true;
    }

    public function pushSubscriptionWidgets($widgets, $subscriber)
    {
        if (!$subscriber->user_id || apply_filters('fluent_crm/disable_woo_subscriptions_widget', false, $subscriber)) {
            return $widgets;
        }

        if (!function_exists('wcs_get_users_subscriptions')) {
            return $widgets;
        }

        $subscriptions = wcs_get_users_subscriptions($subscriber->user_id);

        if (!$subscriptions) {
            return $widgets;
        }

        $html = '<div class="max_height_340"><ul class="fc_full_listed">';

        foreach ($subscriptions as $subscription) {

            $statusName = wcs_get_subscription_status_name($subscription->get_status());

            $items = $subscription->get_items();
            $names = [];
            foreach ($items as $item) {
                $names[] = $item->get_name();
            }

            $name = implode(' & ', $names);

            $pricing = $subscription->get_formatted_order_total();

            $html .= '<li><span style="font-weight: bold;">' . $name . ' <span class="subscription-status status-' . $subscription->get_status() . '">' . $statusName . '</span></span>';

            /* translators: PHP date format for the subscription start date tooltip, see https://www.php.net/manual/datetime.format.php */
            $startDate = sprintf('<time class="%s" title="%s">%s</time>', esc_attr('start_date'), esc_attr(date(__('Y/m/d g:i:s A', 'fluentcampaign-pro'), $subscription->get_time('start_date', 'site'))), esc_html($subscription->get_date_to_display('start_date')));

            /* translators: %s is the subscription start date */
            $html .= '<p style="margin: 5px 0 0;font-size: 12px;color: #5e5d5d;">' . $pricing . '<span class="fc_middot">·</span>' . sprintf(__('Started at: %s', 'fluentcampaign-pro'), $startDate);

            if ($nextDate = $subscription->get_time('next_payment_date', 'site')) {
                /* translators: PHP date format for the next payment date tooltip, see https://www.php.net/manual/datetime.format.php */
                $nextPaymentDate = sprintf('<time class="%s" title="%s">%s</time>', esc_attr('next_payment_date'), esc_attr(date(__('Y/m/d g:i:s A', 'fluentcampaign-pro'), $nextDate)), esc_html($subscription->get_date_to_display('next_payment_date')));
                /* translators: %s is the next subscription payment date */
                $html .= '<span class="fc_middot">·</span>' . sprintf(__('Next Payment: %s', 'fluentcampaign-pro'), $nextPaymentDate);
            }


            $html .= '</p></li>';
        }
        $html .= '</ul></div>';

        $html .= '<style>.subscription-status {font-weight: normal; display: inline-flex;color: #777;background: #e5e5e5;border-radius: 4px;border-bottom: 1px solid rgba(0,0,0,.05);white-space: nowrap;max-width: 100%;padding: 0px 7px; }.subscription-status.status-active { background: #c6e1c6;color: #5b841b;}.status-cancelled{ background: #9d0303;color: white; }.subscription-status.status-expired {background: #bd94af;color: #724663;}.subscription-status.status-pending-cancel {background: #bfbfbf;color: #737373;}</style>';

        $widgets[] = [
            /* translators: %d is the number of WooCommerce subscriptions */
            'title'   => sprintf(__('WooCommerce Subscriptions (%d)', 'fluentcampaign-pro'), count($subscriptions)),
            'content' => $html
        ];

        return $widgets;

    }
}
