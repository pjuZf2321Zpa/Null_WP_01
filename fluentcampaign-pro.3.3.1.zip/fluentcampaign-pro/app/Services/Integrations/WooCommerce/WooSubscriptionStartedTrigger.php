<?php

namespace FluentCampaign\App\Services\Integrations\WooCommerce;

use FluentCrm\App\Services\Funnel\BaseTrigger;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Funnel\FunnelProcessor;
use FluentCrm\Framework\Support\Arr;

class WooSubscriptionStartedTrigger extends BaseTrigger
{
    private const HISTORY_TYPE = 'woo_subscription_activation';

    /**
     * A renewal order paid within this window is the payment that reactivated the subscription.
     * WooCommerce Subscriptions marks the order paid and reactivates it in the same request.
     */
    private const RECENT_PAYMENT_SECONDS = 10 * 60;

    /**
     * Status each subscription had right before it was set to active in this request, keyed by
     * subscription ID. woocommerce_subscription_status_active does not pass the old status, so it
     * is captured on woocommerce_subscription_pre_update_status, which fires before it.
     *
     * @var array<int, string>
     */
    private static $statusBeforeActive = [];

    public function __construct()
    {
        $this->triggerName = 'woocommerce_subscription_status_active';
        $this->priority = 22;
        $this->actionArgNum = 1;
        parent::__construct();

        add_action('woocommerce_subscription_pre_update_status', [self::class, 'rememberStatusBeforeActive'], 10, 3);
        // Forget it once every automation on this trigger has run (status_updated fires after
        // status_active), or when WooCommerce Subscriptions 9.x refuses the change.
        add_action('woocommerce_subscription_status_updated', [self::class, 'forgetStatusBeforeActive'], 999, 1);
        add_action('woocommerce_subscription_unable_to_update_status', [self::class, 'forgetStatusBeforeActive'], 10, 1);
    }

    public static function rememberStatusBeforeActive($oldStatus, $newStatus, $subscription)
    {
        if ($newStatus === 'active' && is_object($subscription)) {
            self::$statusBeforeActive[(int)$subscription->get_id()] = (string)$oldStatus;
        }
    }

    public static function forgetStatusBeforeActive($subscription)
    {
        if (is_object($subscription)) {
            unset(self::$statusBeforeActive[(int)$subscription->get_id()]);
        }
    }

    public function getTrigger()
    {
        return [
            'ribbon'      => 'subscription',
            'category'    => __('WooCommerce', 'fluentcampaign-pro'),
            'label'       => __('Subscription activated', 'fluentcampaign-pro'),
            'icon'        => 'fc-icon-woo_order_complete',
            'description' => __('This automation will start when a WooCommerce subscription begins or its status changes to active.', 'fluentcampaign-pro')
        ];
    }

    public function getFunnelSettingsDefaults()
    {
        return [
            'subscription_status' => 'subscribed'
        ];
    }

    public function getFunnelConditionDefaults($funnel)
    {
        return [
            'product_ids'               => [],
            'run_multiple'              => 'no',
            'restart_same_subscription' => 'no'
        ];
    }

    public function getConditionFields($funnel)
    {
        return [
            'product_ids'  => [
                'type'               => 'rest_selector',
                'option_key'         => 'woo_products',
                'sub_option_key'     => ['subscription', 'variable-subscription'],
                'experimental_cache' => true,
                'is_multiple'        => true,
                'label'              => __('Target Products', 'fluentcampaign-pro'),
                'help'               => __('Select the subscription products that start this automation', 'fluentcampaign-pro'),
                'inline_help'        => __('Leave blank to run for any subscription product', 'fluentcampaign-pro')
            ],
            'run_multiple' => [
                'type'        => 'yes_no_check',
                'label'       => '',
                'check_label' => __('Allow this event to restart the automation for the same contact', 'fluentcampaign-pro'),
                'inline_help' => __('If enabled, it will restart the automation for a contact who is already in it. Otherwise, the contact will be skipped.', 'fluentcampaign-pro')
            ],
            'restart_same_subscription' => [
                'type'        => 'yes_no_check',
                'label'       => '',
                'check_label' => __('Also restart when a paused subscription is resumed', 'fluentcampaign-pro'),
                'inline_help' => __('Applies only when restart is enabled. Restarts when an on-hold subscription is set back to active without a renewal payment. Renewals and recovered payments never restart the automation.', 'fluentcampaign-pro')
            ]
        ];
    }

    public function getSettingsFields($funnel)
    {
        return [
            'title'     => __('Subscription activated', 'fluentcampaign-pro'),
            'sub_title' => __('This automation will start when a WooCommerce subscription starts or its status changes to active', 'fluentcampaign-pro'),
            'fields'    => [
                'subscription_status'      => [
                    'type'        => 'option_selectors',
                    'option_key'  => 'editable_statuses',
                    'is_multiple' => false,
                    'label'       => __('Contact Status', 'fluentcampaign-pro'),
                    'placeholder' => __('Select status', 'fluentcampaign-pro')
                ],
                'subscription_status_info' => [
                    'type'       => 'html',
                    'info'       => '<b>' . __('An automated double opt-in email will be sent to new contacts', 'fluentcampaign-pro') . '</b>',
                    'dependency' => [
                        'depends_on' => 'subscription_status',
                        'operator'   => '=',
                        'value'      => 'pending'
                    ]
                ]
            ]
        ];
    }

    public function handle($funnel, $originalArgs)
    {
        $subscription = $originalArgs[0];

        $userData = FunnelHelper::prepareUserData($subscription->get_user_id());

        if (!$userData || !$this->hasTargetProduct($subscription, $funnel)) {
            return false;
        }

        $subscriber = FunnelHelper::getSubscriber($userData['email']);
        $enrollment = $subscriber ? FunnelHelper::ifAlreadyInFunnel($funnel->id, $subscriber->id) : null;
        $seenIds = $this->getSeenSubscriptionIds($subscriber, $funnel, $enrollment);

        if ($enrollment && !$this->maybeRestartEnrollment($subscription, $funnel, $subscriber, $seenIds)) {
            return false;
        }

        $subscriberData = wp_parse_args($userData, $funnel->settings);

        $subscriberData['status'] = (!empty($subscriberData['subscription_status'])) ? $subscriberData['subscription_status'] : 'subscribed';
        unset($subscriberData['subscription_status']);

        (new FunnelProcessor())->startFunnelSequence($funnel, $subscriberData, [
            'source_trigger_name' => $this->triggerName,
            'source_ref_id'       => $subscription->get_id()
        ]);

        $this->rememberSubscription($subscription, $funnel, $userData['email'], $seenIds);
    }

    /**
     * @param $subscription \WC_Subscription
     * @param $funnel
     * @return bool True when the subscription contains one of the automation's target products.
     */
    private function hasTargetProduct($subscription, $funnel)
    {
        $targetIds = Arr::get((array)$funnel->conditions, 'product_ids');

        $productIds = [];
        /*
         * User may have other subscription active
         */
        foreach ($subscription->get_items() as $line_item) {
            $productIds[] = $line_item->get_product_id();
        }

        if (!$productIds) {
            return false;
        }

        return !$targetIds || (bool)array_intersect($productIds, $targetIds);
    }

    /**
     * Decide whether a contact already in the automation re-enters it, and remove the old enrollment if so.
     *
     * A subscription that already ran this enrollment is skipped: WooCommerce Subscriptions moves it
     * on-hold -> active on every renewal and payment recovery. That was the long-standing behavior
     * before #431. With "restart_same_subscription" enabled, it restarts only when a paused
     * subscription is resumed without a renewal payment (see isPlainResume()).
     *
     * @param $subscription \WC_Subscription
     * @param array $seenIds Subscription IDs that already ran the current enrollment.
     * @return bool
     */
    private function maybeRestartEnrollment($subscription, $funnel, $subscriber, $seenIds)
    {
        $conditions = (array)$funnel->conditions;

        if (Arr::get($conditions, 'run_multiple') != 'yes') {
            return false;
        }

        if (in_array((int)$subscription->get_id(), $seenIds, true)
            && (Arr::get($conditions, 'restart_same_subscription') != 'yes' || !$this->isPlainResume($subscription))) {
            return false;
        }

        FunnelHelper::removeSubscribersFromFunnel($funnel->id, [$subscriber->id]);

        return true;
    }

    /**
     * True when an on-hold subscription was set back to active with no renewal payment involved,
     * for example a store manager resuming a subscription they paused.
     *
     * False for everything else, including when the old status is unknown (a REST API set_status()
     * or a restore from trash skips the pre-update hook), so a missed signal never resends emails:
     * - a renewal order paid just now: a renewal or a recovered failed payment;
     * - a renewal order still unpaid: a grace period after a failed payment, or an open renewal;
     * - pending-cancel -> active: a customer undoing a cancellation before the term ends.
     *
     * @param $subscription \WC_Subscription
     * @return bool
     */
    private function isPlainResume($subscription)
    {
        if ((self::$statusBeforeActive[(int)$subscription->get_id()] ?? '') !== 'on-hold') {
            return false;
        }

        $renewal = $subscription->get_last_order('all', 'renewal');
        if (!$renewal) {
            return true; // Paused and resumed before its first renewal.
        }

        if (!$renewal->is_paid()) {
            return false;
        }

        $paidAt = $renewal->get_date_paid();

        return !$paidAt || (time() - $paidAt->getTimestamp()) >= self::RECENT_PAYMENT_SECONDS;
    }

    /**
     * Subscription IDs that already ran the contact's current enrollment.
     *
     * History is stored per contact and automation, keyed to the enrollment ID. Removing the contact
     * from the automation invalidates it, so the same subscription becomes eligible again.
     * The enrollment's own source_ref_id covers enrollments made before history was recorded.
     *
     * @return int[]
     */
    private function getSeenSubscriptionIds($subscriber, $funnel, $enrollment)
    {
        if (!$enrollment) {
            return [];
        }

        $ids = [];
        $history = $subscriber->getMeta((string)$funnel->id, self::HISTORY_TYPE);
        if (is_array($history) && (int)Arr::get($history, 'enrollment_id') === (int)$enrollment->id) {
            $ids = array_map('intval', (array)Arr::get($history, 'subscription_ids', []));
        }

        if ($enrollment->source_ref_id) {
            $ids[] = (int)$enrollment->source_ref_id;
        }

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * Record the subscription against the enrollment it just started, carrying forward earlier IDs.
     * Nothing is stored when the processor did not create an enrollment for this subscription.
     */
    private function rememberSubscription($subscription, $funnel, $email, $seenIds)
    {
        $subscriber = FunnelHelper::getSubscriber($email);
        $enrollment = $subscriber ? FunnelHelper::ifAlreadyInFunnel($funnel->id, $subscriber->id) : null;

        if (!$enrollment || $enrollment->source_trigger_name !== $this->triggerName
            || (int)$enrollment->source_ref_id !== (int)$subscription->get_id()) {
            return;
        }

        $seenIds[] = (int)$subscription->get_id();
        $subscriber->updateMeta((string)$funnel->id, [
            'enrollment_id'    => (int)$enrollment->id,
            'subscription_ids' => array_values(array_unique($seenIds))
        ], self::HISTORY_TYPE);
    }
}
