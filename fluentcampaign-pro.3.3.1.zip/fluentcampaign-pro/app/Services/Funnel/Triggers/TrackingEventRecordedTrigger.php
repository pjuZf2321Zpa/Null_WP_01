<?php

namespace FluentCampaign\App\Services\Funnel\Triggers;

use FluentCampaign\App\Services\Funnel\Conditions\FunnelConditionHelper;
use FluentCrm\App\Models\EventTracker;
use FluentCrm\App\Services\Funnel\BaseTrigger;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCrm\App\Services\Funnel\FunnelProcessor;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;

class TrackingEventRecordedTrigger extends BaseTrigger
{

    public function __construct()
    {
        $this->triggerName = 'fluent_crm/event_tracked';
        $this->priority = 30;
        $this->actionArgNum = 2;
        parent::__construct();
    }

    public function getTrigger()
    {
        if (!Helper::isExperimentalEnabled('event_tracking')) {
            return false;
        }

        return [
            'category'    => __('CRM', 'fluentcampaign-pro'),
            'label'       => __('Tracking Event Recorded', 'fluentcampaign-pro'),
            'description' => __('This automation will start when a tracking event is recorded for a contact', 'fluentcampaign-pro'),
            'icon'        => 'fc-icon-wp_new_user_signup',
        ];
    }

    public function getSettingsFields($funnel)
    {
        return [
            'title'     => __('Tracking Event Recorded', 'fluentcampaign-pro'),
            'sub_title' => __('This automation will start when a tracking event is recorded for a contact', 'fluentcampaign-pro'),
            'fields'    => [
                'event_key'                => [
                    'label'              => __('Target Event Key', 'fluentcampaign-pro'),
                    'value'              => 'event_tracking_key',
                    'type'               => 'rest_selector',
                    'option_key'         => 'event_tracking_keys',
                    'is_multiple'        => false,
                    'custom_operators'   => [
                        'in'     => 'in',
                        'not_in' => 'not in'
                    ],
                    'creatable'          => true,
                    'experimental_cache' => true,
                    'help'               => __('Select the event key that starts this automation', 'fluentcampaign-pro')
                ],
                'minimum_event_count'      => [
                    'label'       => __('Minimum number of occurrences of the selected event', 'fluentcampaign-pro'),
                    'type'        => 'input-number',
                    'placeholder' => __('Minimum Event Count', 'fluentcampaign-pro'),
                ],
                'subscription_status_info' => [
                    'type' => 'html',
                    'info' => '<p>' . __('This trigger only starts if the contact has the Subscribed status. Otherwise, the automation is skipped.', 'fluentcampaign-pro') . '</p>',
                ]
            ]
        ];
    }

    public function getFunnelSettingsDefaults()
    {
        return [
            'subscription_status' => 'subscribed',
            'event_key'           => '',
            'minimum_event_count' => 1
        ];
    }

    public function getConditionFields($funnel)
    {
        return [
            'value_conditions' => [
                'type'      => 'condition_block_groups',
                'label'     => __('Advanced Event Tracking Conditions (checks all tracking events for the contact)', 'fluentcampaign-pro'),
                'labels'    => [
                    'match_type_all_label' => __('True if all conditions match', 'fluentcampaign-pro'),
                    'match_type_any_label' => __('True if any of the conditions match', 'fluentcampaign-pro'),
                    'data_key_label'       => __('Contact Data', 'fluentcampaign-pro'),
                    'condition_label'      => __('Condition', 'fluentcampaign-pro'),
                    'data_value_label'     => __('Match Value', 'fluentcampaign-pro')
                ],
                'is_open'   => true,
                'groups'    => apply_filters('fluent_crm/event_tracking_condition_groups', []),
                'add_label' => __('Add a condition to check event properties', 'fluentcampaign-pro'),
            ],
            'run_multiple'     => [
                'type'        => 'yes_no_check',
                'label'       => '',
                'check_label' => __('Allow this event to restart the automation for the same contact', 'fluentcampaign-pro'),
                'inline_help' => __('If enabled, the automation will restart for a contact who is already in it. If the contact is still active in this automation, it will not restart.', 'fluentcampaign-pro')
            ]
        ];
    }

    public function getFunnelConditionDefaults($funnel)
    {
        return [
            'value_conditions'   => [[]],
            'run_multiple'       => 'no',
            'dont_run_on_active' => 'yes'
        ];
    }

    public function handle($funnel, $originalArgs)
    {
        if (!Helper::isExperimentalEnabled('event_tracking')) {
            return false;
        }

        $subscriber = $originalArgs[1];

        if ($subscriber->status != 'subscribed') {
            return false;
        }

        if (did_action('fluent_crm/event_tracking_automation_triggered_' . $funnel->id . '_' . $subscriber->id)) {
            return false;
        }

        $trackedEvent = $originalArgs[0];

        $settings = $funnel->settings;

        if (Arr::get($settings, 'event_key') != $trackedEvent->event_key) {
            return false;
        }

        $minimumCount = (int)Arr::get($settings, 'minimum_event_count', 1);
        if ($minimumCount > 1 && $this->occurrenceCount($subscriber->id, $trackedEvent->event_key) < $minimumCount) {
            return false;
        }

        if (!$this->isProcessable($funnel, $subscriber)) {
            return false;
        }

        $subscriberData[] = [
            'email' => $subscriber->email
        ];

        do_action('fluent_crm/event_tracking_automation_triggered_' . $funnel->id . '_' . $subscriber->id, $funnel);

        (new FunnelProcessor())->startFunnelSequence($funnel, $subscriberData, [
            'source_trigger_name' => $this->triggerName,
            'source_ref_id'       => $trackedEvent->id
        ], $subscriber);
    }

    /**
     * How many times the contact has had the event, across every row of the key.
     *
     * The tracker keeps one row per (contact, key, title), and a new row per occurrence for
     * non-repeatable events, so the tracked row's own counter is only part of the total.
     *
     * @param int $subscriberId
     * @param string $eventKey
     * @return int
     */
    private function occurrenceCount($subscriberId, $eventKey)
    {
        return (int)EventTracker::where('subscriber_id', $subscriberId)
            ->where('event_key', $eventKey)
            ->sum('counter');
    }

    private function isProcessable($funnel, $subscriber)
    {
        // Check if the contact is already in the automation and in active status
        $exist = FunnelHelper::ifAlreadyInFunnel($funnel->id, $subscriber->id);
        if ($exist) {
            if ($exist->status == 'active' || Arr::get($funnel->conditions, 'run_multiple') != 'yes') {
                return false;
            }
        }

        $conditionGroups = Arr::get($funnel->conditions, 'value_conditions', []);
        $isConditionMatched = $this->assessConditionGroups($conditionGroups, $subscriber);
        if (!$isConditionMatched) {
            return false;
        }

        if ($exist) {
            FunnelHelper::removeSubscribersFromFunnel($funnel->id, [$subscriber->id]);
        }

        return true;
    }

    private function assessConditionGroups($conditionGroups, $subscriber)
    {
        $conditionGroups = array_filter($conditionGroups);
        if (empty($conditionGroups)) {
            return true;
        }

        foreach ($conditionGroups as $conditions) {
            $result = $this->assesAutomationTriggerConditions($conditions, $subscriber);
            if ($result) {
                return true;
            }
        }

        return false;
    }

    private function assesAutomationTriggerConditions($conditions, $subscriber)
    {
        $formattedGroups = FunnelConditionHelper::formatConditionGroups($conditions);

        foreach ($formattedGroups as $groupName => $group) {
            if ($groupName == 'segment') {
                if (!FunnelConditionHelper::assessSegmentConditions($group, $subscriber)) {
                    return false;
                }
            } else if ($groupName == 'event_tracking') {
                if (!FunnelConditionHelper::assessEventTrackingConditions($group, $subscriber)) {
                    return false;
                }
            }
        }

        return true;
    }
    
}
