<?php

namespace FluentCampaign\App\Services\Funnel\Actions;

use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCrm\App\Services\Funnel\BaseAction;
use FluentCrm\Framework\Support\Arr;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;

class SendCustomSmsAction extends BaseAction
{
    public function __construct()
    {
        $this->actionName = 'send_custom_sms';
        $this->priority = 20;
        parent::__construct();
    }

    public function getBlock()
    {
        return [
            'category' => __('Messaging', 'fluentcampaign-pro'),
            'title'       => __('Send an SMS', 'fluentcampaign-pro'),
            'description' => __('Send an SMS to the contact or a custom number', 'fluentcampaign-pro'),
            'icon' => 'el-icon-chat-line-square',
            'settings'    => [
                'send_sms_to_type' => 'contact',
                'send_sms_custom'  => '',
                'sms_body' => ''
            ]
        ];
    }

    public function getBlockFields()
    {
        return [
            'title'     => __('Create Custom SMS', 'fluentcampaign-pro'),
            'sub_title' => __('Enter the SMS message you want to send', 'fluentcampaign-pro'),
            'fields'    => [
                'send_sms_to_type' => [
                    'type'          => 'radio',
                    'wrapper_class' => 'fc_half_field',
                    'label'         => __('Send SMS to', 'fluentcampaign-pro'),
                    'options'       => [
                        [
                            'id'    => 'contact',
                            'title' => __('Send to the contact', 'fluentcampaign-pro')
                        ],
                        [
                            'id'    => 'custom',
                            'title' => __('Send to Custom Number', 'fluentcampaign-pro')
                        ]
                    ]
                ],
                'send_sms_custom'  => [
                    'wrapper_class' => 'fc_half_field',
                    'type'          => 'input-text',
                    'label'         => __('Send To Number', 'fluentcampaign-pro'),
                    'placeholder'   => __('Custom Contact Number', 'fluentcampaign-pro'),
                    'dependency'    => [
                        'depends_on' => 'send_sms_to_type',
                        'operator'   => '=',
                        'value'      => 'custom'
                    ]
                ],
                'sms_body'  => [
                    'type' => 'input-text-area',
                    'field_type'  => 'textarea',
                    'rows'          => 4,
                    'label'         => __('SMS Body', 'fluentcampaign-pro'),
                    'placeholder'   => __('SMS Body', 'fluentcampaign-pro'),
                    'show_sms_counter' => true,
                ]
            ]
        ];
    }

    public function handle($subscriber, $sequence, $funnelSubscriberId, $funnelMetric)
    {
        $data = $sequence->settings;

        $smsSendToOption = Arr::get($data, 'send_sms_to_type');
        $customContactNumber = Arr::get($data, 'send_sms_custom');
        $smsBody = Arr::get($data, 'sms_body');

        if ($smsSendToOption == 'custom') {
            $contactNumber = $customContactNumber;
        } else {
            $contactNumber = $subscriber->phone;
        }

        if (!$contactNumber || !$smsBody) {
            return;
        }

        if (
            $smsSendToOption !== 'custom' &&
            !MessageThread::contactCanReceive('sms', $subscriber->id)
        ) {
            return;
        }

        // Parse smartcodes in SMS body
        $smsBody = SMSHelper::parseMessageContent($smsBody, $subscriber);

        // Written to the contact's conversation thread and sent in this request.
        MessageScheduler::sendNow(
            LegacyMessage::CHANNEL_SMS,
            $contactNumber,
            $subscriber->id,
            $smsBody,
            ['ref_type' => Message::REF_AUTOMATION]
        );
    }
}
