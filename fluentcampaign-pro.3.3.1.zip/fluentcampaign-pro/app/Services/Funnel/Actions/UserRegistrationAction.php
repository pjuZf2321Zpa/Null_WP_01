<?php

namespace FluentCampaign\App\Services\Funnel\Actions;

use FluentCrm\App\Services\Funnel\BaseAction;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCampaign\App\Services\Funnel\WpUserGuard;
use FluentCrm\App\Services\Libs\Parser\Parser;
use FluentCrm\Framework\Support\Arr;

class UserRegistrationAction extends BaseAction
{
    public function __construct()
    {
        $this->actionName = 'user_registration_action';
        $this->priority = 99;
        parent::__construct();
    }

    public function getBlock()
    {
        return [
            'category'    => __('WordPress', 'fluentcampaign-pro'),
            'title'       => __('Create WordPress User', 'fluentcampaign-pro'),
            'description' => __('Create a WordPress user with a role if no user is registered with the contact\'s email address', 'fluentcampaign-pro'),
            'icon'        => 'fc-icon-create_wp_user',//fluentCrmMix('images/funnel_icons/create_wp_user.svg'),
            'settings'    => [
                'user_role'                    => 'subscriber',
                'send_user_notification_email' => 'no',
                'auto_generate_password'       => 'yes',
                'custom_password'              => '',
                'custom_username'              => '',
                'meta_properties'              => [
                    [
                        'data_key'   => '',
                        'data_value' => ''
                    ]
                ]
            ]
        ];
    }

    public function getBlockFields()
    {

        return [
            'title'     => __('Create WordPress User', 'fluentcampaign-pro'),
            'sub_title' => __('Create a WordPress user with a role if no user is registered with the contact\'s email address', 'fluentcampaign-pro'),
            'fields'    => [
                'user_role'                    => [
                    'type'    => 'select',
                    'label'   => __('User Role', 'fluentcampaign-pro'),
                    'options' => $this->getUserRoles()
                ],
                'auto_generate_password'       => [
                    'type'        => 'yes_no_check',
                    'label'       => __('Password', 'fluentcampaign-pro'),
                    'check_label' => __('Generate Password Automatically', 'fluentcampaign-pro')
                ],
                'custom_password'              => [
                    'type'        => 'input-text-popper',
                    'placeholder' => __('Custom Password', 'fluentcampaign-pro'),
                    'label'       => __('Provide Custom User Password', 'fluentcampaign-pro'),
                    'inline_help' => __('If left blank, an automatically generated password will be used', 'fluentcampaign-pro'),
                    'dependency'  => [
                        'depends_on' => 'auto_generate_password',
                        'operator'   => '=',
                        'value'      => 'no'
                    ]
                ],
                'custom_username'              => [
                    'type'        => 'input-text-popper',
                    'placeholder' => 'Username (Optional)',
                    'label'       => __('Custom Username (optional)', 'fluentcampaign-pro'),
                    'inline_help' => __('If left blank, the email address will be used as the username. If the provided username is not available, the email address will be used instead.', 'fluentcampaign-pro'),
                ],
                'meta_properties'              => [
                    'label'                  => __('User Meta Mapping', 'fluentcampaign-pro'),
                    'type'                   => 'text-value-multi-properties',
                    'data_key_label'         => __('User Meta Key', 'fluentcampaign-pro'),
                    'data_value_label'       => __('User Meta Value', 'fluentcampaign-pro'),
                    'data_value_placeholder' => __('Meta Value', 'fluentcampaign-pro'),
                    'data_key_placeholder'   => __('Meta Key', 'fluentcampaign-pro'),
                    'help'                   => __('Map user meta properties here if needed. This is optional.', 'fluentcampaign-pro'),
                    'value_input_type'       => 'text-popper'
                ],
                'send_user_notification_email' => [
                    'type'        => 'yes_no_check',
                    'label'       => __('User Notification', 'fluentcampaign-pro'),
                    'check_label' => __('Send WordPress user notification email', 'fluentcampaign-pro')
                ]
            ]
        ];
    }

    public function handle($subscriber, $sequence, $funnelSubscriberId, $funnelMetric)
    {

        $user = get_user_by('email', $subscriber->email);
        if ($user) {
            $funnelMetric->notes = __('Skipped because the user already exists', 'fluentcampaign-pro');
            $funnelMetric->save();
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        $settings = $sequence->settings;
        $userRole = Arr::get($settings, 'user_role', 'subscriber');

        if (!$this->isAllowedUserRole($userRole)) {
            $funnelMetric->notes = __('Skipped because the selected WordPress role is not allowed for this action.', 'fluentcampaign-pro');
            $funnelMetric->save();
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        if (Arr::get($settings, 'auto_generate_password') == 'yes' || empty($settings['custom_password'])) {
            $password = wp_generate_password(8);
        } else {
            $password = Parser::parse($settings['custom_password'], $subscriber);
        }

        $userName = sanitize_user($subscriber->email);

        if (!empty($settings['custom_username'])) {

            $customUserName = $settings['custom_username']; //Parser::parse(, $subscriber);

            $customUserName = apply_filters('fluent_crm/parse_campaign_email_text', $customUserName, $subscriber);
            $customUserName = sanitize_user($customUserName);

            if ($customUserName && !username_exists($customUserName)) {
                $userName = $customUserName;
            }
        }

        $userId = wp_create_user($userName, $password, $subscriber->email);

        if (is_wp_error($userId)) {
            /* translators: %s is the error message returned by WordPress */
            $funnelMetric->notes = sprintf(__('Error creating the WordPress user: %s', 'fluentcampaign-pro'), $userId->get_error_message());
            $funnelMetric->save();
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        $user = new \WP_User($userId);
        $user->set_role($userRole);

        $userMetas = [
            'first_name' => $subscriber->first_name,
            'last_name'  => $subscriber->last_name
        ];

        foreach (Arr::get($settings, 'meta_properties', []) as $pair) {
            if (empty($pair['data_key']) || empty($pair['data_value'])) {
                continue;
            }

            $metaKey = sanitize_key($pair['data_key']);
            if (!$metaKey || $this->isProtectedUserMetaKey($metaKey)) {
                continue;
            }

            $userMetas[$metaKey] = Parser::parse($pair['data_value'], $subscriber);
        }

        $userMetas = array_filter($userMetas);
        foreach ($userMetas as $metaKey => $metaValue) {
            update_user_meta($userId, $metaKey, $metaValue);
        }

        if (Arr::get($settings, 'send_user_notification_email') == 'yes') {
            wp_send_new_user_notifications($userId, 'user');
        }

        fluentCrmDb()->table('fc_subscribers')
            ->where('id', $subscriber->id)
            ->update([
                'user_id' => $userId
            ]);
    }

    public function getUserRoles($keyed = false)
    {
        if (!function_exists('get_editable_roles')) {
            require_once(ABSPATH . '/wp-admin/includes/user.php');
        }

        $roles = \get_editable_roles();
        $formattedRoles = [];

        foreach ($roles as $roleKey => $role) {
            if (!$this->isAllowedUserRole($roleKey, $roles)) {
                continue;
            }

            if ($keyed) {
                $formattedRoles[$roleKey] = $role['name'];
            } else {
                $formattedRoles[] = [
                    'id'    => $roleKey,
                    'title' => $role['name']
                ];
            }
        }

        return $formattedRoles;
    }

    protected function isAllowedUserRole($roleKey, $roles = null)
    {
        if (!$roleKey || $roleKey === 'administrator') {
            return false;
        }

        if ($roles === null) {
            if (!function_exists('get_editable_roles')) {
                require_once(ABSPATH . '/wp-admin/includes/user.php');
            }
            $roles = \get_editable_roles();
        }

        if (empty($roles[$roleKey])) {
            return false;
        }

        $blockedCaps = [
            'activate_plugins',
            'create_users',
            'delete_plugins',
            'delete_themes',
            'delete_users',
            'edit_plugins',
            'edit_themes',
            'edit_users',
            'install_plugins',
            'install_themes',
            'manage_options',
            'promote_users',
            'remove_users',
            'switch_themes',
            'unfiltered_html'
        ];

        $roleCaps = array_filter((array) Arr::get($roles[$roleKey], 'capabilities', []));

        return !array_intersect($blockedCaps, array_keys($roleCaps));
    }

    protected function isProtectedUserMetaKey($metaKey)
    {
        return WpUserGuard::isProtectedUserMetaKey($metaKey);
    }

    protected function getProtectedUserMetaKeys()
    {
        return WpUserGuard::protectedUserMetaKeys();
    }

}
