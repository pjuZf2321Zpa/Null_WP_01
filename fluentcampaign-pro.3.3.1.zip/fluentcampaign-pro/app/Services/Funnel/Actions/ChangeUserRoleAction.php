<?php

namespace FluentCampaign\App\Services\Funnel\Actions;

use FluentCrm\App\Services\Funnel\BaseAction;
use FluentCrm\App\Services\Funnel\FunnelHelper;
use FluentCampaign\App\Services\Funnel\WpUserGuard;

class ChangeUserRoleAction extends BaseAction
{
    public function __construct()
    {
        $this->actionName = 'fcrm_change_user_role';
        $this->priority = 99;
        parent::__construct();
    }

    public function getBlock()
    {
        return [
            'category'    => __('WordPress', 'fluentcampaign-pro'),
            'title'       => __('Change WordPress User Role', 'fluentcampaign-pro'),
            'description' => __('Change the role of the WordPress user that has the contact\'s email address', 'fluentcampaign-pro'),
            'icon'        => 'fc-icon-wp_user_role',//fluentCrmMix('images/funnel_icons/wp_user_role.svg'),
            'settings'    => [
                'user_role' => '',
                'replace'   => 'yes'
            ]
        ];
    }

    public function getBlockFields()
    {
        $userRoles = $this->getUserRoles();

        return [
            'title'     => __('Change User Role', 'fluentcampaign-pro'),
            'sub_title' => __('Change connected user role', 'fluentcampaign-pro'),
            'fields'    => [
                'user_role'                    => [
                    'type'    => 'select',
                    'label'   => __('User Role', 'fluentcampaign-pro'),
                    'options' => $userRoles,
                    'inline_help' => __('The selected role will be applied if a user exists with the contact\'s email address', 'fluentcampaign-pro')
                ],
                'replace'       => [
                    'type'        => 'yes_no_check',
                    'label'       => __('Replace Existing Role', 'fluentcampaign-pro'),
                    'check_label' => __('Replace user role', 'fluentcampaign-pro'),
                    'inline_help' => __('If disabled, the selected role will be added to the user\'s existing roles.', 'fluentcampaign-pro')
                ]
            ]
        ];
    }

    public function handle($subscriber, $sequence, $funnelSubscriberId, $funnelMetric)
    {
        $user = get_user_by('email', $subscriber->email);
        if (!$user) {
            $funnelMetric->notes = __('Skipped because no user was found with this email address', 'fluentcampaign-pro');
            $funnelMetric->save();
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        $settings = $sequence->settings;
        $userRole = $settings['user_role'];

        if (!$this->isAllowedUserRole($userRole)) {
            $funnelMetric->notes = __('Skipped because the administrator role cannot be set for security reasons', 'fluentcampaign-pro');
            $funnelMetric->save();
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        if(!$userRole) {
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        if (!function_exists('get_editable_roles')) {
            require_once(ABSPATH . '/wp-admin/includes/user.php');
        }

        $roles = \get_editable_roles();

        if(empty($roles[$userRole])) {
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        $willReplace = $settings['replace'] == 'yes';

        // Replacing would demote an administrator; adding a role takes nothing away.
        if ($willReplace && WpUserGuard::isAdministrator($user)) {
            $funnelMetric->notes = __('Skipped because the user is an administrator, whose role cannot be replaced by an automation', 'fluentcampaign-pro');
            $funnelMetric->save();
            FunnelHelper::changeFunnelSubSequenceStatus($funnelSubscriberId, $sequence->id, 'skipped');
            return false;
        }

        if($willReplace) {
            $user->set_role($userRole);
        } else {
            $user->add_role($userRole);
        }
    }

    public function getUserRoles($keyed = false)
    {
        if (!function_exists('get_editable_roles')) {
            require_once(ABSPATH . '/wp-admin/includes/user.php');
        }

        $roles = \get_editable_roles();

        $formattedRoles = [];
        foreach ($roles as $roleKey => $role) {

            if (!$this->isAllowedUserRole($roleKey, $roles)) {
                continue;
            }

            if ($keyed) {
                $formattedRoles[$roleKey] = $role['name'];
            } else {
                $formattedRoles[] = [
                    'id'    => $roleKey,
                    'title' => $role['name']
                ];
            }

        }
        return $formattedRoles;
    }

    private function isAllowedUserRole($roleKey, $roles = null)
    {
        if (!$roleKey || $roleKey === 'administrator') {
            return false;
        }
        if ($roles === null) {
            if (!function_exists('get_editable_roles')) {
                require_once(ABSPATH . '/wp-admin/includes/user.php');
            }
            $roles = get_editable_roles();
        }
        if (empty($roles[$roleKey])) {
            return false;
        }
        $blockedCaps = ['activate_plugins', 'create_users', 'delete_plugins', 'delete_themes', 'delete_users', 'edit_plugins', 'edit_themes', 'edit_users', 'install_plugins', 'install_themes', 'manage_options', 'promote_users', 'remove_users', 'switch_themes', 'unfiltered_html'];
        $caps = array_filter((array) $roles[$roleKey]['capabilities']);
        return !array_intersect($blockedCaps, array_keys($caps));
    }


}
