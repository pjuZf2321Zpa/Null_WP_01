<?php

namespace FluentCampaign\App\Services\Funnel\Actions;

use FluentCrm\App\Services\Funnel\BaseAction;
use FluentCrm\App\Services\Helper;
use FluentCrm\App\Services\Libs\Parser\Parser;
use FluentCrm\Framework\Support\Arr;

class AddEventTrackerAction extends BaseAction
{
    public function __construct()
    {
        $this->actionName = 'add_contact_event_tracker';
        $this->priority = 30;
        parent::__construct();
    }

    public function getBlock()
    {
        if (!Helper::isExperimentalEnabled('event_tracking')) {
            return false;
        }

        return [
            'category'    => __('CRM', 'fluentcampaign-pro'),
            'title'       => __('Add Event Tracking', 'fluentcampaign-pro'),
            'description' => __('Add Event Tracking for Contact', 'fluentcampaign-pro'),
            'icon'        => 'fc-icon-writing',
            'settings'    => [
                'is_unique' => 'yes',
                'event_key' => '',
                'title'     => '',
                'value'     => ''
            ]
        ];
    }

    public function getBlockFields()
    {
        return [
            'title'     => __('Add Event Tracking to Contact Profile', 'fluentcampaign-pro'),
            'sub_title' => __('Add an event tracking record to the contact profile', 'fluentcampaign-pro'),
            'fields'    => [
                'event_key' => [
                    'type'        => 'input-text',
                    'placeholder' => __('e.g. my_event_key', 'fluentcampaign-pro'),
                    'label'       => __('Event Tracking Key', 'fluentcampaign-pro')
                ],
                'title'     => [
                    'type'          => 'input-text-popper',
                    'smart_codes'   => 'yes',
                    'placeholder'   => __('Human-readable event name', 'fluentcampaign-pro'),
                    'context_codes' => 'yes',
                    'label'         => __('Event Tracking Title', 'fluentcampaign-pro')
                ],
                'value'     => [
                    'label'       => __('Event Value', 'fluentcampaign-pro'),
                    'type'        => 'input-text-popper',
                    'field_type'  => 'textarea',
                    'placeholder' => __('Event details or a numeric value', 'fluentcampaign-pro'),
                ],
                'is_unique' => [
                    'type'        => 'yes_no_check',
                    'label'       => '',
                    'check_label' => __('Keep one record per contact for this event', 'fluentcampaign-pro'),
                    'inline_help' => __('If the contact already has an event with the same key and title, update its value and increase its occurrence count instead of adding a new record.', 'fluentcampaign-pro')
                ]
            ]
        ];
    }

    public function handle($subscriber, $sequence, $funnelSubscriberId, $funnelMetric)
    {
        if (!Helper::isExperimentalEnabled('event_tracking')) {
            return false;
        }

        $settings = $sequence->settings;
        $subscriber->funnel_subscriber_id = $funnelSubscriberId;
        $title = apply_filters('fluent_crm/parse_campaign_email_text', Arr::get($settings, 'title'), $subscriber);
        $value = apply_filters('fluent_crm/parse_campaign_email_text', Arr::get($settings, 'value'), $subscriber);

        $eventAtts = [
            'event_key'  => Arr::get($settings, 'event_key'),
            'title'      => $title,
            'value'      => $value,
            'subscriber' => $subscriber
        ];

        FluentCrmApi('event_tracker')->track($eventAtts, Arr::get($settings, 'is_unique') == 'yes');

        return true;
    }

}
