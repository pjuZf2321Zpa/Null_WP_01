<?php

namespace FluentCampaign\App\Services\Funnel\Conditions;

use FluentCrm\App\Services\Funnel\FunnelProcessor;
use FluentCrm\Framework\Support\Arr;

class FunnelABTesting
{
    protected $priority = 99;

    protected $name = 'funnel_ab_testing';

    public function register()
    {
        add_filter('fluentcrm_funnel_blocks', array($this, 'pushBlock'), $this->priority, 2);
        add_filter('fluentcrm_funnel_block_fields', array($this, 'pushBlockFields'), $this->priority, 2);
        add_action('fluentcrm_funnel_sequence_handle_funnel_ab_testing', array($this, 'handle'), 10, 5);
    }

    public function pushBlock($blocks, $funnel)
    {
        $blocks[$this->name] = [
            'type'             => 'conditional',
            'category'         => __('CRM', 'fluentcampaign-pro'),
            'title'            => __('Split (A/B Testing)', 'fluentcampaign-pro'),
            'description'      => __('Evenly split the contacts or choose how to distribute them', 'fluentcampaign-pro'),
            'element-icon'     => 'Guide',//fluentCrmMix('images/funnel_icons/has_contact_property.svg'),
            'settings'         => [
                'path_a' => '50',
                'path_b' => '50'
            ],
            'reload_on_insert' => true
        ];
        return $blocks;
    }

    public function pushBlockFields($allFields, $funnel)
    {
        $allFields[$this->name] = [
            'title'     => __('Split (A/B Testing)', 'fluentcampaign-pro'),
            'sub_title' => __('Evenly split the contacts or choose how to distribute them', 'fluentcampaign-pro'),
            'fields'    => [
                'path_a' => [
                    'wrapper_class' => 'fc_2col_inline',
                    'label' => __('Contacts assigned to path A (%)', 'fluentcampaign-pro'),
                    'type' => 'input-number'
                ],
                'path_b' => [
                    'wrapper_class' => 'fc_2col_inline',
                    'label' => __('Contacts assigned to path B (%)', 'fluentcampaign-pro'),
                    'type' => 'input-number'
                ]
            ]
        ];
        return $allFields;
    }

    public function handle($subscriber, $sequence, $funnelSubscriberId, $funnelMetric, $processor = null)
    {
        $pathA = (int) Arr::get($sequence->settings, 'path_a', 50);
        $pathB = (int) Arr::get($sequence->settings, 'path_b', 50);

        // A+B equally likely outcomes, so each path gets exactly its share; 0/0 goes to A.
        $rand = ($pathA + $pathB) > 0 ? mt_rand(1, $pathA + $pathB) : 0;
        $isB = $rand > $pathA;

        // Callbacks can bucket per contact instead of using the weighted coin flip.
        $isB = apply_filters('fluent_crm/funnel_ab_test_is_b', $isB, $sequence, $subscriber, $funnelSubscriberId);

        if (!$processor) {
            $processor = new FunnelProcessor();
        }

        $processor->initChildSequences($sequence, $isB, $subscriber, $funnelSubscriberId, $funnelMetric);
    }

}
