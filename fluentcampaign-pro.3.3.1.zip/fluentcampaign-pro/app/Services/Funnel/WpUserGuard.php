<?php

namespace FluentCampaign\App\Services\Funnel;

/**
 * Shared limits for automation actions that change WordPress users.
 *
 * An automation runs for whichever WordPress user owns a contact's email, and can be built by a
 * CRM manager who is not a WordPress administrator. These checks keep such actions from demoting
 * administrators or writing the user meta that holds roles, sessions and credentials.
 */
class WpUserGuard
{
    /**
     * Actions that change WordPress users, and the WordPress capability needed to add or change
     * them in an automation. Registered on FluentCRM's `fluent_crm/funnel_privileged_actions`.
     */
    const PRIVILEGED_ACTIONS = [
        'fcrm_change_user_role'    => 'promote_users',
        'remove_user_role'         => 'promote_users',
        'fcrm_update_user_meta'    => 'promote_users',
        'user_registration_action' => 'promote_users',
    ];

    public static function register()
    {
        add_filter('fluent_crm/funnel_privileged_actions', function ($actions) {
            return array_merge((array) $actions, self::PRIVILEGED_ACTIONS);
        });
    }

    /**
     * Whether the user is a site administrator (or a network super admin on multisite).
     *
     * @param \WP_User $user
     */
    public static function isAdministrator($user)
    {
        return $user && (user_can($user, 'manage_options') || is_super_admin($user->ID));
    }

    /**
     * Whether an automation must not write this user meta key.
     *
     * Compared as WordPress and MySQL will match it: update_metadata() unslashes the key, and
     * the meta_key collation ignores case and accents, so "WP_Capabilities", "wp\_capabilities"
     * and "wp_capabilitiés" all update the real wp_capabilities row.
     */
    public static function isProtectedUserMetaKey($metaKey)
    {
        $metaKey = strtolower(remove_accents(wp_unslash(trim((string) $metaKey))));

        if (in_array($metaKey, self::protectedUserMetaKeys(), true)) {
            return true;
        }

        // Prefixed per site on multisite (wp_2_capabilities).
        return substr($metaKey, -13) === '_capabilities' || substr($metaKey, -11) === '_user_level';
    }

    public static function protectedUserMetaKeys()
    {
        global $wpdb;

        $keys = [
            '_application_passwords',
            'application_passwords',
            'capabilities',
            'dismissed_wp_pointers',
            'session_tokens',
            'user_activation_key',
            'user_level',
            'wp_capabilities',
            'wp_user_level'
        ];

        // The site's real role keys: the table prefix need not end with an underscore.
        foreach (array_unique([$wpdb->prefix, $wpdb->get_blog_prefix(), $wpdb->base_prefix]) as $prefix) {
            $keys[] = strtolower($prefix . 'capabilities');
            $keys[] = strtolower($prefix . 'user_level');
        }

        return $keys;
    }
}
