
<?php
/**
 * @var $atts array
 * @var $post \WP_Post
 * @var $postUrl string
 * @var $settings array
 */
?>

<table class="fce_row fc_latest_post_item <?php echo esc_attr($atts['selectedLayout']); ?>" border="0" cellpadding="0" cellspacing="0" width="100%" style="<?php echo esc_attr($settings['gapStyle']); ?><?php echo esc_attr($settings['itemStyle']); ?>">
    <tbody>
    <tr>
        <td>
            <span class="fc_latest_post_marker"></span>
            <a href="<?php echo esc_url($postUrl); ?>" style="<?php echo esc_attr($settings['titleStyle']); ?>">
                <?php
                // Filters may supply or remove the title.
                $postTitle = get_the_title($post);
                if ( $postTitle ) {
                    echo esc_html($postTitle);
                } else {
                    esc_html_e('(no title)', 'fluentcampaign-pro');
                }
                ?>
            </a>
        </td>
    </tr>
    </tbody>
</table>


