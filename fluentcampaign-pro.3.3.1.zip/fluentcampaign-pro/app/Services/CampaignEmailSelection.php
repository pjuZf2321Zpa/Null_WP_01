<?php

namespace FluentCampaign\App\Services;

use FluentCrm\Framework\Validator\ValidationException;
use FluentCrm\App\Models\Campaign;
use FluentCrm\App\Models\CampaignEmail;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Models\Tag;

/** Resolve campaign-scoped selections and process bounded recipient actions. */
class CampaignEmailSelection
{
    /** Accept objects from REST or JSON from the scalar-only attachment form. */
    public function selection($value)
    {
        if (is_string($value)) {
            $value = json_decode($value, true);
        }
        if (!is_array($value)) {
            $this->invalid();
        }
        return $value;
    }

    /** Resolve selected recipients for completed, sending, or paused regular campaigns. */
    public function query($campaignId, array $selection)
    {
        $campaign = Campaign::findOrFail(absint($campaignId));
        if (!in_array($campaign->status, ['archived', 'working', 'paused'], true)) {
            $this->invalid();
        }
        $mode = $selection['mode'] ?? '';
        if ($mode === 'ids') {
            if (array_diff(array_keys($selection), ['mode', 'email_ids'])) {
                $this->invalid();
            }
            $ids = $this->ids($selection['email_ids'] ?? []);
            $query = CampaignEmail::where('campaign_id', $campaign->id)->whereIn('id', $ids);
            if ($query->count() !== count($ids)) {
                $this->invalid();
            }
            return $query;
        }
        // The filter type must be sent, never defaulted to "all"; Core's scope validates its value.
        if ($mode !== 'matching' || array_diff(array_keys($selection), ['mode', 'filter_type', 'search', 'link_ids']) ||
            !is_string($selection['filter_type'] ?? null) || !is_string($selection['search'] ?? '')) {
            $this->invalid();
        }
        return CampaignEmail::forCampaignRecipients($campaign->id, $selection);
    }

    /** Tag distinct subscribed contacts, advancing past ineligible contacts too. */
    public function processTags($campaignId, array $data)
    {
        if (!in_array($data['action_type'] ?? null, ['add_tags', 'remove_tags'], true)) {
            $this->invalid();
        }
        $tags = $this->ids($data['tags'] ?? []);
        if (Tag::whereIn('id', $tags)->count() !== count($tags)) {
            $this->invalid();
        }
        [$emails, $maxId, $after] = $this->batchQuery($campaignId, $data);
        $contacts = Subscriber::whereIn('id', $emails->select('subscriber_id'));
        $page = $contacts->where('id', '>', $after)->orderBy('id')->limit($this->limit() + 1)->get();
        $hasMore = $page->count() > $this->limit();
        $processed = 0; $skipped = 0;
        foreach ($page->take($this->limit()) as $contact) {
            $after = (int) $contact->id;
            if ($contact->status !== 'subscribed') {
                $skipped++;
                continue;
            }
            if ($data['action_type'] === 'add_tags') {
                $contact->attachTags($tags);
            } else {
                $contact->detachTags($tags);
            }
            $processed++;
        }
        return $this->result($processed, $skipped, $after, $maxId, $hasMore);
    }

    /** Queue one ID-ordered batch outside active sending, without shifting offset pages. */
    public function processResend($campaignId, array $data)
    {
        [$query, $maxId, $after] = $this->batchQuery($campaignId, $data);
        $campaign = Campaign::findOrFail(absint($campaignId));
        if (!in_array($campaign->status, ['archived', 'paused'], true)) {
            $this->invalid();
        }
        $page = $query->with('subscriber')->where('id', '>', $after)->orderBy('id')->limit($this->limit() + 1)->get();
        $hasMore = $page->count() > $this->limit();
        $processed = 0; $skipped = 0;
        foreach ($page->take($this->limit()) as $email) {
            $after = (int) $email->id;
            $body = $email->email_body ?: $campaign->email_body;
            if (!$email->subscriber || $email->subscriber->status !== 'subscribed' ||
                !in_array($email->status, ['sent', 'failed'], true) || !$body) {
                $skipped++;
                continue;
            }
            $email->email_body = $body;
            $email->status = 'scheduled';
            $email->is_parsed = 0;
            $email->note = __('Manually resent', 'fluentcampaign-pro');
            // Mailer due-time queries use the WordPress local clock, as do legacy resends.
            $email->scheduled_at = current_time('mysql');
            $email->email_address = $email->subscriber->email;
            $email->save();
            do_action('fluentcrm_process_contact_jobs', $email->subscriber);
            $processed++;
        }
        return $this->result($processed, $skipped, $after, $maxId, $hasMore);
    }

    /** Freeze the upper email boundary and validate the continuation cursor. */
    private function batchQuery($campaignId, array $data)
    {
        if (array_intersect(['email_ids', 'activity_type', 'link_ids', 'processing_page'], array_keys($data))) {
            $this->invalid();
        }
        $query = $this->query($campaignId, $this->selection($data['selection'] ?? null));
        $after = $this->number($data['after_id'] ?? 0);
        if ($after && !isset($data['max_email_id'])) {
            $this->invalid();
        }
        $maxId = isset($data['max_email_id']) ? $this->number($data['max_email_id']) : (int) (clone $query)->max('id');
        return [$query->where('id', '<=', $maxId), $maxId, $after];
    }

    /** Normalize positive IDs without turning malformed or empty input into all rows. */
    private function ids($values)
    {
        if (!is_array($values) || !$values) {
            $this->invalid();
        }
        $ids = [];
        foreach ($values as $value) {
            $id = $this->number($value);
            if (!$id) {
                $this->invalid();
            }
            $ids[] = $id;
        }
        return array_values(array_unique($ids));
    }

    /** Validate a nonnegative integer from JSON or a submitted form. */
    private function number($value)
    {
        if ((!is_int($value) && !is_string($value)) || !ctype_digit((string) $value) || (float) $value > PHP_INT_MAX) {
            $this->invalid();
        }
        return (int) $value;
    }

    /** Keep existing campaign batch sizing while bounding abusive filter values. */
    private function limit()
    {
        return max(1, min(500, (int) apply_filters('fluent_crm/campaign_action_limit', 50)));
    }

    /** Return acknowledged progress and an action-specific scanned-ID cursor. */
    private function result($processed, $skipped, $after, $maxId, $hasMore)
    {
        return ['processed_count' => $processed, 'skipped_count' => $skipped, 'next_after_id' => $after, 'max_email_id' => $maxId, 'has_more' => $hasMore];
    }

    /** Reject invalid requests with a recoverable REST validation response. */
    private function invalid()
    {
        $message = __('The campaign selection is invalid. Refresh the list and select contacts again.', 'fluentcampaign-pro');
        throw new ValidationException($message, 422, null, ['selection' => [$message]]);
    }
}
