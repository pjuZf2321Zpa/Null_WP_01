<?php if (!apply_filters('fluent_crm/disable_newsletter_archive_css', false)): ?>
<style type="text/css">
    .fc_newsletters_archive.fc_newsletter_cards .fc_newsletter_cards_grid {
        display: grid;
        gap: 24px;
        list-style: none;
        margin: 0;
        padding: 0;
    }
    .fc_newsletters_archive.fc_newsletter_cards_cols_1 .fc_newsletter_cards_grid { grid-template-columns: repeat(1, minmax(0, 1fr)); }
    .fc_newsletters_archive.fc_newsletter_cards_cols_2 .fc_newsletter_cards_grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .fc_newsletters_archive.fc_newsletter_cards_cols_3 .fc_newsletter_cards_grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
    .fc_newsletters_archive.fc_newsletter_cards_cols_4 .fc_newsletter_cards_grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    .fc_newsletters_archive.fc_newsletter_cards .fc_newsletter_card {
        border: 1px solid #e5e7eb;
        padding: 24px;
    }
    .fc_newsletters_archive.fc_newsletter_cards .fc_newsletter_card_title {
        display: block;
        font-size: 22px;
        font-weight: 700;
        line-height: 1.35;
        overflow-wrap: anywhere;
        text-decoration: none;
    }
    .fc_newsletters_archive.fc_newsletter_cards .fc_email_time {
        color: #888;
        display: block;
        font-size: 12px;
        margin-top: 8px;
    }
    .fc_newsletters_archive.fc_newsletter_cards .fc_newsletter_card_excerpt {
        margin: 16px 0;
    }
    @media (max-width: 782px) {
        .fc_newsletters_archive.fc_newsletter_cards .fc_newsletter_cards_grid {
            grid-template-columns: repeat(1, minmax(0, 1fr));
        }
    }
</style>
<?php endif; ?>

<?php
/**
 * @var array $newsletters Array of formatted newsletters.
 * @var \FluentCrm\Framework\Database\Orm\Collection $campaigns Campaign collection.
 * @var string $layout Archive layout name.
 * @var array $card Card options: columns (1-4), excerpt_length, hide_date, hide_excerpt, hide_read_more.
 */
do_action('fluent_crm/before_newsletter_archive', $newsletters, $campaigns);
?>
<div class="fc_newsletters_archive fc_newsletter_cards fc_newsletter_cards_cols_<?php echo esc_attr($card['columns']); ?>">
    <ul class="fc_newsletter_cards_grid">
        <?php foreach ($newsletters as $newsletter): ?>
        <li class="fc_newsletter_card">
            <a class="fc_newsletter_card_title" href="<?php echo esc_url($newsletter['permalink']); ?>"><?php echo esc_html($newsletter['title']); ?></a>
            <?php if (!$card['hide_date']): ?>
            <time datetime="<?php echo esc_attr($newsletter['date_time']); ?>" class="fc_email_time"><?php echo esc_html($newsletter['formatted_date']); ?></time>
            <?php endif; ?>
            <?php if (!empty($newsletter['excerpt'])): ?>
            <p class="fc_newsletter_card_excerpt"><?php echo esc_html($newsletter['excerpt']); ?></p>
            <?php endif; ?>
            <?php if (!$card['hide_read_more']): ?>
            <a class="fc_newsletter_card_more" href="<?php echo esc_url($newsletter['permalink']); ?>"><?php echo esc_html__('Read More', 'fluentcampaign-pro'); ?></a>
            <?php endif; ?>
        </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php
do_action('fluent_crm/after_newsletter_archive', $newsletters, $campaigns);
