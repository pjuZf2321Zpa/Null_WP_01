<?php

namespace FluentCampaign\App\Modules\Messaging;

use FluentCampaign\App\Modules\Messaging\Contracts\ChannelInterface;
use FluentCampaign\App\Utils\Enqueuer\Enqueue;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageHandler;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\SMS\Providers\AWSDriver;
use FluentCampaign\App\Modules\Messaging\SMS\Providers\TwilioDriver;
use FluentCampaign\App\Modules\Messaging\SMS\SMSChannel;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\MetaCloudDriver;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\TwilioWhatsAppDriver;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppChannel;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;

class MessageModule
{
    public function init($app)
    {
        // Must run before anything reads the experimental settings; Helper memoizes them.
        self::copySmsSwitchToModuleSwitch();

        // Registered before the gate: the save that turns the module on runs while it is off. Creates the tables.
        add_action('fluent_crm/experimental_settings_saved', function ($settings) {
            if (Arr::get($settings, 'messaging_module') === 'yes') {
                MessageMigrator::migrate();
            }
        });

        if (!self::isEnabled()) {
            return;
        }

        add_action('init', function () use ($app) {
            $this->register($app);
        });
    }

    /**
     * The module switch. While off, nothing loads and every channel reports inactive.
     */
    public static function isEnabled(): bool
    {
        return Helper::isExperimentalEnabled('messaging_module');
    }

    /**
     * The channels this module ships, keyed by slug. Built once per request.
     *
     * @return ChannelInterface[]
     */
    public static function channels(): array
    {
        static $channels = null;

        if ($channels === null) {
            $channels = [
                'sms'      => new SMSChannel(),
                'whatsapp' => new WhatsAppChannel(),
            ];
        }

        return $channels;
    }

    /**
     * Resolve a channel by slug. Null for an unknown slug; callers must not fall back to another channel.
     */
    public static function channel(string $slug): ?ChannelInterface
    {
        return self::channels()[$slug] ?? null;
    }

    /**
     * @return ChannelInterface[] only the channels the site has switched on
     */
    public static function activeChannels(): array
    {
        return array_filter(self::channels(), function (ChannelInterface $channel) {
            return $channel->isActive();
        });
    }

    /**
     * Enqueue the module's Vue bundle into core's admin app.
     * It must load before admin/app.js so its `fluentcrm_global_routes` filter is registered first.
     *
     * @return void
     */
    private function registerAdminApp()
    {
        add_action('fluentcrm_loading_app', function () {
            // Sites that ran the messaging migration before phone_key existed get it here.
            MessageMigrator::maybeAddPhoneKey();

            // Older cores have no import map or shared/ui.js; skip the UI rather than break the app.
            if (!defined('FLUENTCRM_MODULE_API') || FLUENTCRM_MODULE_API < 1) {
                return;
            }

            Enqueue::script(
                'fluentcampaign-messaging',
                'admin/messaging.js',
                ['fluentcrm_admin_app_boot'],
                FLUENTCAMPAIGN_PLUGIN_VERSION
            );
        });
    }

    public static function isAnyChannelActive(): bool
    {
        return (bool) self::activeChannels();
    }

    /**
     * One-time upgrade: turn the module on when a channel was already enabled.
     * Runs only while `messaging_module` is absent from the experimental settings.
     */
    private static function copySmsSwitchToModuleSwitch(): void
    {
        $settings = get_option('_fluentcrm_experimental_settings', []);

        if (!is_array($settings)) {
            $settings = [];
        }

        if (array_key_exists('messaging_module', $settings)) {
            return;
        }

        $hadChannelOn = fluentcrm_get_option('_fc_sms_enable', 'no') === 'yes'
            || fluentcrm_get_option('_fc_whatsapp_enable', 'no') === 'yes';

        $settings['messaging_module'] = $hadChannelOn ? 'yes' : 'no';

        // Retired keys that nothing reads.
        unset($settings['sms_module'], $settings['whatsapp_module']);

        update_option('_fluentcrm_experimental_settings', $settings, 'yes');
    }

    /**
     * Add per-channel consent status to core's advanced filter "Contact Segment" group.
     * Not gated on the channel being active, so saved segments keep working.
     */
    private function registerConsentFilters()
    {
        add_filter('fluentcrm_advanced_filter_options', function ($groups) {
            if (empty($groups['segment']['children'])) {
                return $groups;
            }

            foreach (self::channels() as $slug => $channel) {
                $groups['segment']['children'][] = [
                    /* translators: %s: channel name, e.g. SMS or WhatsApp */
                    'label'             => sprintf(__('%s Status', 'fluentcampaign-pro'), $channel->getLabel()),
                    'value'             => $slug . '_status',
                    'type'              => 'selections',
                    'options'           => MessageThread::consentStatusLabels(),
                    'is_multiple'       => true,
                    // One status per channel, so only "in" / "not in" operators.
                    'is_singular_value' => true,
                    'help'              => __('A contact with no conversation on this channel counts as subscribed.', 'fluentcampaign-pro')
                ];
            }

            return $groups;
        });

        foreach (array_keys(self::channels()) as $slug) {
            // The query builder is mutated in place.
            add_action('fluent_crm/contacts_filter_segment_' . $slug . '_status', function ($query, $filter) use ($slug) {
                // Same operator handling as core's buildSegmentFilterQuery.
                $inclusive = in_array(Arr::get($filter, 'operator'), ['in', 'contains'], true);

                return MessageThread::applyStatusFilter(
                    $query,
                    $slug,
                    (array) Arr::get($filter, 'value', []),
                    !$inclusive
                );
            }, 10, 2);
        }
    }

    public function register($app)
    {
        // Driver constructors self-register; done before any isActive() gate so settings list them.
        new TwilioDriver();
        new AWSDriver();
        do_action('fluent_crm/register_sms_providers');

        new TwilioWhatsAppDriver();
        new MetaCloudDriver();
        do_action('fluent_crm/register_whatsapp_providers');

        // Routes load whenever the module is on, even with every channel off.
        $app->router->group(function ($router) {
            require_once __DIR__ . '/Http/messaging_api.php';
        });

        add_filter('fluent_crm/admin_vars', function ($adminVars) {
            // sms_enabled / whatsapp_enabled are read by existing screens; `messaging` is channel-agnostic.
            $adminVars['sms_enabled'] = SMSHelper::isActive() ? 'yes' : 'no';
            $adminVars['whatsapp_enabled'] = WhatsAppHelper::isActive() ? 'yes' : 'no';
            $adminVars['messaging'] = [
                'active_channels' => array_keys(self::activeChannels()),
                'channels'        => array_map(function ($channel) {
                    return [
                        'slug'       => $channel->getSlug(),
                        'label'      => $channel->getLabel(),
                        'active'     => $channel->isActive(),
                        'max_length' => $channel->getMaxLength(),
                    ];
                }, array_values(self::channels())),
            ];
            return $adminVars;
        });

        $this->registerConsentFilters();

        // The UI, menus and queue below need at least one active channel.
        if (!self::isAnyChannelActive()) {
            return;
        }

        $this->registerAdminApp();

        // Contact-profile Message tab, after Emails. Its route comes from resources/admin/messaging.js.
        add_filter('fluentcrm_profile_sections', function ($sections) {
            $messages = [
                'subscriber_messages' => [
                    'name'    => 'subscriber_messages',
                    'title'   => __('Message', 'fluentcampaign-pro'),
                    'handler' => 'route'
                ]
            ];

            $offset = array_search('subscriber_emails', array_keys($sections), true);

            if ($offset === false) {
                return $sections + $messages;
            }

            return array_slice($sections, 0, $offset + 1, true)
                + $messages
                + array_slice($sections, $offset + 1, null, true);
        });

        // sidebar menu item
        add_action('fluent_crm/after_core_menu_items', function ($permissions, $isAdmin) {

            $canReadEmails = in_array('fcrm_read_emails', $permissions);
            $canManageTemplates = in_array('fcrm_manage_email_templates', $permissions);

            if (!$canReadEmails && !$canManageTemplates) {
                return;
            }

            $menuPath = $canReadEmails ? 'messaging/inbox' : 'messaging/whatsapp/templates';

            add_submenu_page(
                'fluentcrm-admin',
                __('Messaging', 'fluentcampaign-pro'),
                __('Messaging', 'fluentcampaign-pro'),
                ($isAdmin) ? 'manage_options' : ($canReadEmails ? 'fcrm_read_emails' : 'fcrm_manage_email_templates'),
                'fluentcrm-admin#/' . $menuPath,
                '__return_null'
            );
        }, 9, 2);

        // top menu item
        add_filter('fluent_crm/core_menu_items', function ($items, $permissions, $urlBase = null) {

            $canReadEmails = in_array('fcrm_read_emails', $permissions);
            $canManageTemplates = in_array('fcrm_manage_email_templates', $permissions);

            if (!$canReadEmails && !$canManageTemplates) {
                return $items;
            }

            if (!$urlBase) {
                $urlBase = fluentcrm_menu_url_base();
            }

            $messagingMenu = [
                'key'          => 'messaging',
                'label'        => __('Messaging', 'fluentcampaign-pro'),
                'permalink'    => $urlBase . ($canReadEmails ? 'messaging/inbox' : 'messaging/whatsapp/templates'),
                'layout_class' => 'sms_menu',
            ];

            $subItems = [
                [
                    'key'         => 'messaging_inbox',
                    'label'       => __('Inbox', 'fluentcampaign-pro'),
                    'permalink'   => $urlBase . 'messaging/inbox',
                    'description' => __('Read and reply to every conversation in one place', 'fluentcampaign-pro'),
                    'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.25 3.25H16.75C16.9489 3.25 17.1397 3.32902 17.2803 3.46967C17.421 3.61032 17.5 3.80109 17.5 4V16C17.5 16.1989 17.421 16.3897 17.2803 16.5303C17.1397 16.671 16.9489 16.75 16.75 16.75H3.25C3.05109 16.75 2.86032 16.671 2.71967 16.5303C2.57902 16.3897 2.5 16.1989 2.5 16V4C2.5 3.80109 2.57902 3.61032 2.71967 3.46967C2.86032 3.32902 3.05109 3.25 3.25 3.25ZM16 11.5H12.8703C12.2358 12.8482 10.8672 13.75 9.3125 13.75C7.75781 13.75 6.38922 12.8482 5.75469 11.5H4V15.25H16V11.5ZM4 10H6.875C6.875 11.3462 7.96625 12.25 9.3125 12.25C10.6588 12.25 11.75 11.3462 11.75 10H16V4.75H4V10Z" fill="#525866"/>
                            </svg>'
                ]
            ];

            // Each active channel adds its own campaign entry.
            foreach (self::activeChannels() as $channel) {
                foreach ($channel->getMenuItems($urlBase) as $item) {
                    $subItems[] = $item;
                }
            }

            $subItems[] = [
                'key'         => 'message_templates',
                'label'       => __('Templates', 'fluentcampaign-pro'),
                'permalink'   => $urlBase . 'messaging/whatsapp/templates',
                'description' => __('Browse reusable SMS and WhatsApp message templates', 'fluentcampaign-pro'),
                'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.375 2.5H15.625C15.9702 2.5 16.25 2.77982 16.25 3.125V16.875C16.25 17.2202 15.9702 17.5 15.625 17.5H4.375C4.02982 17.5 3.75 17.2202 3.75 16.875V3.125C3.75 2.77982 4.02982 2.5 4.375 2.5ZM5 3.75V16.25H15V3.75H5ZM6.875 6.25H13.125V7.5H6.875V6.25ZM6.875 9.375H13.125V10.625H6.875V9.375ZM6.875 12.5H10.625V13.75H6.875V12.5Z" fill="#525866"/>
                            </svg>'
            ];

            // Activities is shared across channels, with a channel filter.
            $subItems[] = [
                'key'         => 'message_activities',
                'label'       => __('Activities', 'fluentcampaign-pro'),
                'permalink'   => $urlBase . 'messaging/activities',
                'description' => __('View all messages that have been sent or are scheduled to be sent by FluentCRM', 'fluentcampaign-pro'),
                'icon'        => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.84125 15.25L2.5 17.875V4C2.5 3.80109 2.57902 3.61032 2.71967 3.46967C2.86032 3.32902 3.05109 3.25 3.25 3.25H16.75C16.9489 3.25 17.1397 3.32902 17.2803 3.46967C17.421 3.61032 17.5 3.80109 17.5 4V14.5C17.5 14.6989 17.421 14.8897 17.2803 15.0303C17.1397 15.171 16.9489 15.25 16.75 15.25H5.84125ZM5.32225 13.75H16V4.75H4V14.7887L5.32225 13.75ZM9.25 8.5H10.75V10H9.25V8.5ZM6.25 8.5H7.75V10H6.25V8.5ZM12.25 8.5H13.75V10H12.25V8.5Z" fill="#525866"/>
                            </svg>'
            ];

            if (!$canReadEmails) {
                $subItems = array_values(array_filter($subItems, function ($item) {
                    return $item['key'] === 'message_templates';
                }));
            }

            $messagingMenu['sub_items'] = $subItems;

            $items[] = $messagingMenu;

            return $items;

        }, 10, 3);

        (new MessageScheduler())->register();
        (new MessageHandler())->register();

    }

}
