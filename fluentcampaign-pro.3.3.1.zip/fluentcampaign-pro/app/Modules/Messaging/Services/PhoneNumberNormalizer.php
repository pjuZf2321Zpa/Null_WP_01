<?php

namespace FluentCampaign\App\Modules\Messaging\Services;

/**
 * Normalize a pasted or uploaded phone number to E.164 for one-time audiences.
 *
 * Numbers must be in international format: "+" or "00", then the country code and number.
 * Spaces, dashes, dots and brackets are ignored. National numbers ("(202) 555-0123",
 * "07700 900123") are refused with a message that says how to write them, rather than guessed:
 * converting them needs per-country numbering rules this plugin does not ship.
 */
class PhoneNumberNormalizer
{
    /**
     * @param mixed       $value
     * @param string|null $defaultCountry unused; kept for callers that still pass it
     * @return string E.164, e.g. +12025550123
     */
    public function normalize($value, $defaultCountry = null)
    {
        if (is_array($value) || is_object($value)) {
            throw new \InvalidArgumentException('Phone number must be a scalar value.');
        }

        $value = trim((string) $value);
        if ($value === '') {
            throw new \InvalidArgumentException('Phone number is required.');
        }

        $normalized = preg_replace('/[\s().-]+/', '', $value);

        // 00 is the international call prefix in most countries.
        if (strpos($normalized, '00') === 0) {
            $normalized = '+' . substr($normalized, 2);
        }

        if (!preg_match('/^\+[1-9]\d{7,14}$/', $normalized)) {
            throw new \InvalidArgumentException('Use international format: start with + or 00 and the country code, for example +12025550123.');
        }

        return $normalized;
    }
}
