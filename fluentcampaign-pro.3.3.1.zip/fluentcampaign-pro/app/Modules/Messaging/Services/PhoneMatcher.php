<?php

namespace FluentCampaign\App\Modules\Messaging\Services;

use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCrm\App\Models\Subscriber;

/**
 * Match phone numbers by their digits.
 *
 * Contacts' phones are stored as typed ("+1 (202) 555-1234", "202-555-1234", "12025551234"),
 * while providers send E.164 ("+12025551234"). Exact string matches missed formatted numbers,
 * so a STOP was stored on an orphan thread and the contact kept receiving messages.
 *
 * Two strengths of match:
 * - same digits: used to attach a message to a contact;
 * - same number, also accepting a stored national number (10+ digits) that is the international
 *   one without its country code: used for STOP and opt-out checks, where a wider match can only
 *   stop a message. A change toward subscribed (START, an admin subscribe) uses same digits only,
 *   so it never re-subscribes a different person whose digits happen to end the same.
 */
class PhoneMatcher
{
    /**
     * Characters people type inside phone numbers.
     */
    const SEPARATORS = ['+', '-', ' ', '(', ')', '.'];

    /**
     * Option tracking `fc_message_threads.phone_key`: absent until the column exists,
     * 'filling' while existing rows are being keyed, 'yes' once every row has its key.
     */
    const KEY_STATE_OPTION = '__fluentcrm_messaging_phone_key';

    protected static $keyState = null;

    public static function digits($phone)
    {
        return preg_replace('/\D+/', '', (string) $phone);
    }

    /**
     * The indexed lookup key for a number: its last 10 digits, or all of them when shorter.
     * Numbers that sameNumber() matches always share it, so an exact match on the key finds every
     * candidate; sameNumber() then confirms. '' for numbers too short to match anything.
     */
    public static function lookupKey($phone)
    {
        $digits = self::digits($phone);
        if (strlen($digits) < 7) {
            return '';
        }

        return strlen($digits) >= 10 ? substr($digits, -10) : $digits;
    }

    /**
     * Whether `fc_message_threads.phone_key` exists, so writes must fill it and reads may use it.
     */
    public static function hasKeyColumn($refresh = false)
    {
        if (self::$keyState === null || $refresh) {
            self::$keyState = (string) fluentcrm_get_option(self::KEY_STATE_OPTION, '');
        }

        return in_array(self::$keyState, ['filling', 'yes'], true);
    }

    /**
     * Whether two numbers are the same for consent: equal digits, or one is the other's national
     * form (at least 10 digits, missing a country code of 1-3 digits).
     */
    public static function sameNumber($a, $b)
    {
        $a = self::digits($a);
        $b = self::digits($b);
        if (strlen($a) < 7 || strlen($b) < 7) {
            return false;
        }
        if ($a === $b) {
            return true;
        }

        $short = strlen($a) < strlen($b) ? $a : $b;
        $long = $short === $a ? $b : $a;
        $prefix = strlen($long) - strlen($short);

        return strlen($short) >= 10 && $prefix <= 3 && substr($long, -strlen($short)) === $short;
    }

    /**
     * SQL for a column with the separators removed, for comparing against digits().
     */
    protected static function digitsSql($column)
    {
        $sql = '`' . $column . '`';
        foreach (self::SEPARATORS as $separator) {
            $sql = "REPLACE($sql, '" . esc_sql($separator) . "', '')";
        }
        return $sql;
    }

    /**
     * Contacts whose phone has the same digits as one of $phones, grouped by those digits.
     *
     * @param string[] $phones
     * @return array<string, Subscriber[]> digits => contacts, oldest first
     */
    public static function contactsForNumbers(array $phones)
    {
        $digits = array_values(array_unique(array_filter(array_map([self::class, 'digits'], $phones), function ($d) {
            return strlen($d) >= 7;
        })));

        if (!$digits) {
            return [];
        }

        global $wpdb;
        $placeholders = implode(', ', array_fill(0, count($digits), '%s'));
        $contacts = Subscriber::whereRaw($wpdb->prepare(self::digitsSql('phone') . " IN ($placeholders)", $digits))
            ->orderBy('id', 'ASC')
            ->get();

        $grouped = [];
        foreach ($contacts as $contact) {
            $grouped[self::digits($contact->phone)][] = $contact;
        }

        return $grouped;
    }

    /**
     * Every contact with this number for consent purposes (see sameNumber()), oldest first.
     *
     * @param string $phone
     * @param bool   $exactDigits only contacts with the same digits: for changes toward
     *                            subscribed, where the wider national match could pick another person
     * @return Subscriber[]
     */
    public static function contactsForNumber($phone, $exactDigits = false)
    {
        $digits = self::digits($phone);
        if (strlen($digits) < 7) {
            return [];
        }

        if ($exactDigits) {
            return self::contactsForNumbers([$phone])[$digits] ?? [];
        }

        return self::contactsSharingNumbers([$phone])[$phone] ?? [];
    }

    /**
     * contactsForNumber() for many numbers in one query.
     *
     * A contact stored in national form has the number's digits less a 1-3 digit country code,
     * so those are looked up alongside the full digits; sameNumber() then confirms each match.
     *
     * @param string[] $phones
     * @return array<string, Subscriber[]> requested phone => contacts, oldest first
     */
    public static function contactsSharingNumbers(array $phones)
    {
        $candidates = [];
        foreach ($phones as $phone) {
            $digits = self::digits($phone);
            if (strlen($digits) < 7) {
                continue;
            }
            $candidates[$phone] = [$digits];
            for ($prefix = 1; $prefix <= 3 && strlen($digits) - $prefix >= 10; $prefix++) {
                $candidates[$phone][] = substr($digits, $prefix);
            }
        }

        if (!$candidates) {
            return [];
        }

        $byDigits = self::contactsForNumbers(array_merge(...array_values($candidates)));

        $result = [];
        foreach ($candidates as $phone => $digitsList) {
            $matches = [];
            foreach ($digitsList as $digits) {
                foreach ($byDigits[$digits] ?? [] as $contact) {
                    if (self::sameNumber($contact->phone, $phone)) {
                        $matches[(int) $contact->id] = $contact;
                    }
                }
            }
            if ($matches) {
                ksort($matches);
                $result[$phone] = array_values($matches);
            }
        }

        return $result;
    }

    /**
     * The contact a message from this number belongs to: an exact match, else the oldest contact
     * with the same digits. A national-format guess is not used here, so a message is never filed
     * under the wrong person.
     */
    public static function findContact($phone)
    {
        $phone = trim((string) $phone);
        if ($phone === '') {
            return null;
        }

        if ($exact = Subscriber::where('phone', $phone)->first()) {
            return $exact;
        }

        $contacts = self::contactsForNumbers([$phone])[self::digits($phone)] ?? [];

        return $contacts ? $contacts[0] : null;
    }

    /**
     * Ids of every thread on a channel for this number for consent purposes (see sameNumber()),
     * whichever spelling it was keyed with.
     *
     * @param string $channel
     * @param string $phone
     * @param bool   $exactDigits only threads with the same digits (see contactsForNumber())
     * @return int[]
     */
    public static function threadIdsForNumber($channel, $phone, $exactDigits = false)
    {
        $digits = self::digits($phone);
        if (strlen($digits) < 7) {
            return [];
        }

        global $wpdb;
        $tailMatch = $wpdb->prepare(self::digitsSql('phone_number') . ' LIKE %s', '%' . $wpdb->esc_like(substr($digits, -7)));
        $query = MessageThread::where('channel', $channel);

        if (self::hasKeyColumn()) {
            // Rows not keyed yet fall back to the digit scan, so none is missed while keys are filled.
            $query->where(function ($q) use ($phone, $tailMatch) {
                $q->where('phone_key', self::lookupKey($phone))
                    ->orWhere(function ($q) use ($tailMatch) {
                        $q->whereNull('phone_key')->whereRaw($tailMatch);
                    });
            });
        } else {
            $query->whereRaw($tailMatch);
        }

        $threads = $query->get(['id', 'phone_number']);

        $ids = [];
        foreach ($threads as $thread) {
            $matches = $exactDigits
                ? self::digits($thread->phone_number) === $digits
                : self::sameNumber($thread->phone_number, $phone);
            if ($matches) {
                $ids[] = (int) $thread->id;
            }
        }

        return $ids;
    }

    /**
     * Which of $phones opted out of a channel, by the status on that number's thread.
     *
     * @param string   $channel
     * @param string[] $phones
     * @return array<string, string> digits of the requested phone => blocking status
     */
    public static function blockedNumbers($channel, array $phones)
    {
        $phones = array_values(array_filter($phones, function ($phone) {
            return strlen(self::digits($phone)) >= 7;
        }));
        if (!$phones) {
            return [];
        }

        $query = MessageThread::where('channel', $channel)
            ->where('status', '!=', MessageThread::STATUS_SUBSCRIBED);

        // Without the key column (the module's upgrade has not run yet) every opt-out on the channel is a candidate.
        if (self::hasKeyColumn()) {
            $keys = array_values(array_unique(array_map([self::class, 'lookupKey'], $phones)));
            // A row not keyed yet is still a candidate, so a STOP is never missed while keys are filled.
            $query->where(function ($q) use ($keys) {
                $q->whereIn('phone_key', $keys)->orWhereNull('phone_key');
            });
        }

        $threads = $query->get(['phone_number', 'status']);

        $blocked = [];
        foreach ($phones as $phone) {
            foreach ($threads as $thread) {
                if (self::sameNumber($phone, $thread->phone_number)) {
                    $blocked[self::digits($phone)] = $thread->status;
                    break;
                }
            }
        }

        return $blocked;
    }
}
