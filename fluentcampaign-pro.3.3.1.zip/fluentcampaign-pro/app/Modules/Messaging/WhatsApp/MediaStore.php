<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\MetaCloudDriver;

/**
 * Copy inbound WhatsApp media into uploads while the webhook is handled; provider URLs expire.
 * Files are untrusted: hosts are allowlisted, types allowlisted, size capped, extension from MIME.
 */
class MediaStore
{
    /**
     * Hosts a Meta media download may target (SSRF guard).
     */
    const ALLOWED_HOSTS = [
        'lookaside.fbsbx.com',
        'graph.facebook.com',
        'mmg.whatsapp.net',
        'media.fbcdn.net',
    ];

    const TWILIO_ALLOWED_HOSTS = [
        'api.twilio.com',
    ];

    const TWILIO_REDIRECT_HOSTS = [
        'mms.twiliocdn.com',
    ];

    /**
     * Attachment MIME types Twilio WhatsApp may store; kept narrower than allowedMimeTypes().
     */
    const TWILIO_ALLOWED_MIME_TYPES = [
        'image/jpeg'                                                                    => 'jpg',
        'image/png'                                                                     => 'png',
        'image/webp'                                                                    => 'webp',
        'video/mp4'                                                                     => 'mp4',
        'audio/ogg'                                                                     => 'ogg',
        'audio/opus'                                                                    => 'opus',
        'audio/mpeg'                                                                    => 'mp3',
        'audio/mp3'                                                                     => 'mp3',
        'audio/amr'                                                                     => 'amr',
        'audio/aac'                                                                     => 'aac',
        'application/pdf'                                                               => 'pdf',
        'application/msword'                                                            => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'       => 'docx',
        'application/vnd.ms-excel'                                                      => 'xls',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'              => 'xlsx',
        'application/vnd.ms-powerpoint'                                                 => 'ppt',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation'      => 'pptx',
        'text/vcard'                                                                    => 'vcf',
        'text/x-vcard'                                                                  => 'vcf',
        'application/vcard'                                                             => 'vcf',
    ];

    const DEFAULT_MAX_BYTES = 26214400; // 25 MB

    /**
     * Per-webhook limits on media fetching. Items past a limit keep their provider metadata.
     */
    const DEFAULT_MAX_ITEMS = 5;
    const DEFAULT_TIME_BUDGET = 10; // seconds across media ingestion
    const MAX_REDIRECTS = 3;

    /**
     * Download every media item on an inbound event. A failed item keeps its provider metadata.
     *
     * @param array  $mediaItems Normalized media entries from WhatsAppReceiver.
     * @param string $provider   Provider slug the message arrived on.
     * @return array The same entries, with local file details added where stored.
     */
    public static function ingest(array $mediaItems, string $provider): array
    {
        if (!$mediaItems) {
            return $mediaItems;
        }

        $context = self::providerContext($provider);

        if (!$context) {
            return $mediaItems;
        }

        $maxItems = (int) apply_filters('fluent_crm/whatsapp_media_max_items', self::DEFAULT_MAX_ITEMS);
        $budget   = (float) apply_filters('fluent_crm/whatsapp_media_time_budget', self::DEFAULT_TIME_BUDGET);
        $deadline = microtime(true) + $budget;
        $fetched  = 0;

        foreach ($mediaItems as $index => $item) {
            if ($fetched >= $maxItems || microtime(true) >= $deadline) {
                break;
            }

            if ($provider === 'twilio_whatsapp' && !self::isAllowedTwilioMedia($item)) {
                continue;
            }

            $fetched++;

            $stored = self::storeItem($item, $context, $deadline);

            if ($stored) {
                $mediaItems[$index] = array_merge($item, $stored);
            }
        }

        return $mediaItems;
    }

    /**
     * Build the authentication and URL policy for one supported provider.
     *
     * @return array Provider download context, or an empty array when the
     *               provider is unsupported or its credentials are incomplete.
     */
    protected static function providerContext(string $provider): array
    {
        $settings = WhatsAppHelper::getProviderSettings($provider);

        if ($provider === 'meta_cloud') {
            $token = trim((string) ($settings['access_token'] ?? ''));

            if (!$token) {
                return [];
            }

            return [
                'provider'         => $provider,
                'headers'          => ['Authorization' => 'Bearer ' . $token],
                'allowed_hosts'    => self::ALLOWED_HOSTS,
                'allow_subdomains' => true,
                'resolve_token'    => $token,
            ];
        }

        if ($provider === 'twilio_whatsapp') {
            $accountSid = trim((string) ($settings['account_sid'] ?? ''));
            $authToken  = trim((string) ($settings['auth_token'] ?? ''));

            if (!preg_match('/^AC[0-9a-fA-F]{32}$/', $accountSid) || !$authToken) {
                return [];
            }

            return [
                'provider'         => $provider,
                'headers'          => [
                    'Authorization' => 'Basic ' . base64_encode($accountSid . ':' . $authToken),
                ],
                'allowed_hosts'    => self::TWILIO_ALLOWED_HOSTS,
                'redirect_hosts'   => self::TWILIO_REDIRECT_HOSTS,
                'allow_subdomains' => false,
                'account_sid'      => $accountSid,
            ];
        }

        return [];
    }

    /**
     * Determine whether a Twilio attachment has an approved storage type.
     */
    protected static function isAllowedTwilioMedia(array $item): bool
    {
        $mimeType = strtolower(self::stringValue($item['mime_type'] ?? $item['content_type'] ?? ''));

        return self::isAllowedTwilioMediaMime($mimeType);
    }

    /**
     * Check the declared or transferred MIME type against the Twilio allowlist.
     */
    protected static function isAllowedTwilioMediaMime(string $mimeType): bool
    {
        $mimeType = strtolower(trim($mimeType));

        return isset(self::TWILIO_ALLOWED_MIME_TYPES[$mimeType]);
    }

    /**
     * Fetch one media item into uploads. URL resolution and transfer share one deadline.
     *
     * @return array|null Local file details, or null when it could not be stored.
     */
    protected static function storeItem(array $item, array $context, float $deadline): ?array
    {
        $url          = self::stringValue($item['url'] ?? '');
        $mediaId      = self::stringValue($item['id'] ?? '');
        $mimeType     = self::stringValue($item['mime_type'] ?? $item['content_type'] ?? '');
        $declaredSize = 0;

        // Id-only payloads: resolve a fresh URL and the declared file size.
        if (!$url && $mediaId && !empty($context['resolve_token'])) {
            $resolved = self::resolveMediaUrl($mediaId, $context['resolve_token'], $deadline);

            if ($resolved) {
                $url          = $resolved['url'];
                $mimeType     = $mimeType ?: $resolved['mime_type'];
                $declaredSize = $resolved['file_size'];
            }
        }

        $allowedHosts    = $context['allowed_hosts'] ?? [];
        $allowSubdomains = !isset($context['allow_subdomains']) || (bool) $context['allow_subdomains'];

        if (!$url || !self::isAllowedUrl($url, $allowedHosts, $allowSubdomains)) {
            return null;
        }

        if (($context['provider'] ?? '') === 'twilio_whatsapp'
            && !self::isAllowedTwilioMediaUrl($url, (string) ($context['account_sid'] ?? ''))) {
            return null;
        }

        // Filenames derive from the content digest, so an existing copy can be reused.
        $existing = self::findStoredCopy($item, $mimeType);

        if ($existing) {
            return $existing;
        }

        $maxBytes = (int) apply_filters('fluent_crm/whatsapp_media_max_bytes', self::DEFAULT_MAX_BYTES);

        if (!empty($declaredSize) && $declaredSize > $maxBytes) {
            return null;
        }

        $download = self::download(
            $url,
            $context['headers'] ?? [],
            $allowedHosts,
            $context['redirect_hosts'] ?? [],
            $allowSubdomains,
            $maxBytes,
            $deadline
        );

        if (!$download) {
            return null;
        }

        // The transfer's content type wins over the webhook's declared type.
        if ($download['mime_type']) {
            $mimeType = $download['mime_type'];
        }

        if (($context['provider'] ?? '') === 'twilio_whatsapp'
            && !self::isAllowedTwilioMediaMime($mimeType)) {
            @unlink($download['path']);
            return null;
        }

        $filename = self::buildFilename($item, $mimeType);

        if (!$filename) {
            @unlink($download['path']);
            return null;
        }

        // Re-check with the confirmed MIME type.
        $existing = self::findStoredCopy($item, $mimeType);

        if ($existing) {
            @unlink($download['path']);
            return $existing;
        }

        $placed = self::placeInUploads($download['path'], $filename);

        if (!$placed) {
            @unlink($download['path']);
            return null;
        }

        return [
            'url'         => $placed['url'],
            'stored_path' => $placed['path'],
            'filesize'    => $download['size'],
            'mime_type'   => $mimeType,
            'stored'      => true,
        ];
    }

    /**
     * Stream a media URL to a temp file, following redirects manually.
     * Every hop is re-checked against the allowlist so credentials never reach another host.
     *
     * @return array|null path/size/mime_type of the downloaded file.
     */
    protected static function download(
        string $url,
        array $headers,
        array $allowedHosts,
        array $redirectHosts,
        bool $allowSubdomains,
        int $maxBytes,
        float $deadline
    ): ?array
    {
        if (!function_exists('wp_tempnam')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $configuredTimeout = (float) apply_filters('fluent_crm/whatsapp_media_download_timeout', 15);
        $current = $url;
        $sendCredentials = true;

        for ($hop = 0; $hop <= self::MAX_REDIRECTS; $hop++) {
            // Re-checked every hop, not just the first.
            $isProviderHost = self::isAllowedUrl($current, $allowedHosts, $allowSubdomains);
            $isRedirectHost = self::isAllowedUrl($current, $redirectHosts, false);

            if (!$isProviderHost && !$isRedirectHost) {
                return null;
            }

            // Once a redirect leaves the provider host, credentials are never sent again.
            if (!$isProviderHost) {
                $sendCredentials = false;
            }

            $tmp = wp_tempnam('fc-wa-media');

            if (!$tmp) {
                return null;
            }

            $timeout = self::remainingRequestTimeout($deadline, $configuredTimeout);

            if ($timeout <= 0) {
                @unlink($tmp);
                return null;
            }

            // wp_safe_remote_get() also refuses private and loopback addresses.
            $response = wp_safe_remote_get($current, [
                'timeout'     => $timeout,
                'headers'     => $sendCredentials ? $headers : [],
                'redirection' => 0,
                'stream'      => true,
                'filename'    => $tmp,
            ]);

            if (is_wp_error($response)) {
                @unlink($tmp);
                return null;
            }

            $code = (int) wp_remote_retrieve_response_code($response);

            if (in_array($code, [301, 302, 303, 307, 308], true)) {
                @unlink($tmp);

                $location = self::stringValue(wp_remote_retrieve_header($response, 'location'));

                if (!$location) {
                    return null;
                }

                $current = self::resolveLocation($current, $location);
                continue;
            }

            if ($code !== 200) {
                @unlink($tmp);
                return null;
            }

            $size = (int) @filesize($tmp);

            if (!$size || $size > $maxBytes) {
                @unlink($tmp);
                return null;
            }

            $mimeType = '';
            $headerType = self::stringValue(wp_remote_retrieve_header($response, 'content-type'));

            if ($headerType) {
                $mimeType = trim(explode(';', $headerType)[0]);
            }

            return [
                'path'      => $tmp,
                'size'      => $size,
                'mime_type' => $mimeType,
            ];
        }

        return null;
    }

    /**
     * Turn a Location header into an absolute URL, resolving relative ones against the source host.
     */
    protected static function resolveLocation(string $from, string $location): string
    {
        if (preg_match('#^https?://#i', $location)) {
            return $location;
        }

        $base = wp_parse_url($from);

        // Protocol-relative `//host/path` names a host; the allowlist then judges it.
        if (strpos($location, '//') === 0) {
            return (empty($base['scheme']) ? 'https' : $base['scheme']) . ':' . $location;
        }

        if (empty($base['scheme']) || empty($base['host'])) {
            return '';
        }

        $origin = $base['scheme'] . '://' . $base['host'] . (empty($base['port']) ? '' : ':' . $base['port']);

        if (strpos($location, '/') === 0) {
            return $origin . $location;
        }

        $path = isset($base['path']) ? preg_replace('#/[^/]*$#', '/', $base['path']) : '/';

        return $origin . $path . $location;
    }

    /**
     * Move a downloaded temp file into the uploads directory.
     */
    protected static function placeInUploads(string $tempPath, string $filename): ?array
    {
        $upload = wp_upload_dir();

        if (!empty($upload['error']) || empty($upload['path'])) {
            return null;
        }

        $target = trailingslashit($upload['path']) . $filename;

        // rename() fails across filesystems, so fall back to copy.
        if (!@rename($tempPath, $target)) {
            if (!@copy($tempPath, $target)) {
                return null;
            }

            @unlink($tempPath);
        }

        $perms = defined('FS_CHMOD_FILE') ? FS_CHMOD_FILE : (fileperms(dirname($target)) & 0000666);
        @chmod($target, $perms);

        return [
            'path' => $target,
            'url'  => trailingslashit($upload['url']) . $filename,
        ];
    }

    /**
     * A previously stored copy of the same file. Requires a provider content digest.
     *
     * @return array|null Local file details, or null when nothing matches.
     */
    protected static function findStoredCopy(array $item, string $mimeType): ?array
    {
        $filename = self::buildFilename($item, $mimeType);

        if (!$filename || !self::stringValue($item['sha256'] ?? '')) {
            return null;
        }

        $upload = wp_upload_dir();

        if (!empty($upload['error']) || empty($upload['path'])) {
            return null;
        }

        $path = trailingslashit($upload['path']) . $filename;

        if (!file_exists($path)) {
            return null;
        }

        return [
            'url'         => trailingslashit($upload['url']) . $filename,
            'stored_path' => $path,
            'filesize'    => (int) filesize($path),
            'mime_type'   => $mimeType,
            'stored'      => true,
        ];
    }

    /**
     * Exchange a Meta media id for a temporary download URL, within the shared deadline.
     */
    protected static function resolveMediaUrl(string $mediaId, string $token, float $deadline): ?array
    {
        $endpoint = sprintf(
            'https://graph.facebook.com/%s/%s',
            MetaCloudDriver::GRAPH_API_VERSION,
            rawurlencode($mediaId)
        );

        $timeout = self::remainingRequestTimeout($deadline, 15.0);

        if ($timeout <= 0) {
            return null;
        }

        // No redirects, so the bearer token cannot leave the Graph host.
        $response = wp_safe_remote_get($endpoint, [
            'timeout'     => $timeout,
            'headers'     => ['Authorization' => 'Bearer ' . $token],
            'redirection' => 0,
        ]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);

        if (!is_array($data) || empty($data['url'])) {
            return null;
        }

        return [
            'url'       => self::stringValue($data['url']),
            'mime_type' => self::stringValue($data['mime_type'] ?? ''),
            'file_size' => (int) ($data['file_size'] ?? 0),
        ];
    }

    /**
     * Limit one outbound request to the time left in the media-ingestion budget.
     */
    protected static function remainingRequestTimeout(float $deadline, float $maximum): float
    {
        return max(0.0, min($maximum, $deadline - microtime(true)));
    }

    /**
     * Whether a URL is an https link to an approved provider media host.
     */
    protected static function isAllowedUrl(
        string $url,
        array $allowedHosts = self::ALLOWED_HOSTS,
        bool $allowSubdomains = true
    ): bool
    {
        $parts = wp_parse_url($url);

        if (empty($parts['scheme']) || strtolower($parts['scheme']) !== 'https') {
            return false;
        }

        if (empty($parts['host'])) {
            return false;
        }

        $host = strtolower($parts['host']);

        foreach ($allowedHosts as $allowed) {
            // Exact host, or a true subdomain when allowed; never a lookalike suffix.
            if ($host === $allowed
                || ($allowSubdomains && substr($host, -strlen('.' . $allowed)) === '.' . $allowed)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Accept only Twilio's content representation for this configured account.
     */
    protected static function isAllowedTwilioMediaUrl(string $url, string $accountSid): bool
    {
        if (!$accountSid || !self::isAllowedUrl($url, self::TWILIO_ALLOWED_HOSTS, false)) {
            return false;
        }

        $parts = wp_parse_url($url);

        if (!empty($parts['port']) && (int) $parts['port'] !== 443) {
            return false;
        }

        if (!empty($parts['user']) || !empty($parts['pass'])) {
            return false;
        }

        $path = rawurldecode((string) ($parts['path'] ?? ''));
        $pattern = sprintf(
            '#^/2010-04-01/Accounts/%s/Messages/(?:SM|MM)[0-9a-fA-F]{32}/Media/ME[0-9a-fA-F]{32}/?$#',
            preg_quote($accountSid, '#')
        );

        return (bool) preg_match($pattern, $path);
    }

    /**
     * Build a safe upload filename. The extension comes from the MIME type, never the sender's filename.
     */
    protected static function buildFilename(array $item, string $mimeType): string
    {
        $allowed = self::allowedMimeTypes();
        $mimeKey = strtolower(trim($mimeType));

        if (!isset($allowed[$mimeKey])) {
            return '';
        }

        $stem = self::stringValue($item['filename'] ?? '');
        $stem = $stem ? pathinfo($stem, PATHINFO_FILENAME) : '';
        $stem = sanitize_file_name($stem);
        $stem = $stem !== '' ? substr($stem, 0, 60) : ('whatsapp-' . self::stringValue($item['type'] ?? 'media'));

        // Suffix is a hash of the content digest (stable for findStoredCopy()), else random.
        $digest = self::stringValue($item['sha256'] ?? '');
        $suffix = $digest
            ? substr(hash('sha256', $digest), 0, 12)
            : wp_generate_password(12, false, false);

        return sprintf('%s-%s.%s', $stem, $suffix, $allowed[$mimeKey]);
    }

    /**
     * MIME types accepted from WhatsApp, mapped to the stored extension.
     */
    protected static function allowedMimeTypes(): array
    {
        $types = self::TWILIO_ALLOWED_MIME_TYPES + [
            'video/3gpp'       => '3gp',
            'audio/mp4'        => 'm4a',
            'text/plain'       => 'txt',
        ];

        return (array) apply_filters('fluent_crm/whatsapp_media_allowed_types', $types);
    }

    protected static function stringValue($value): string
    {
        if (is_array($value) || is_object($value)) {
            return '';
        }

        return trim((string) $value);
    }
}
