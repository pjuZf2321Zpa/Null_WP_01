<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\Models\MessageTemplate;

/**
 * Render a variable map (`{"1": "{{contact.first_name|there}}"}`) into Meta's body `components`.
 * Missing or empty variables, header variables and dynamic URL buttons return a readable error.
 */
class TemplateRenderer
{
    /**
     * Build the components array for one subscriber.
     *
     * @param MessageTemplate $template    Approved WhatsApp template row
     * @param array           $variableMap Position => smartcode string, keys "1"..
     * @param object          $subscriber  \FluentCrm\App\Models\Subscriber
     *
     * @return array {components: array, error: string|null}
     */
    public static function render(MessageTemplate $template, array $variableMap, $subscriber, $message = null): array
    {
        if ($unsupported = self::getUnsupportedReason($template)) {
            return self::error($unsupported);
        }

        $positions = $template->getVariablePositions();

        if (!$positions) {
            return ['components' => [], 'error' => null];
        }

        $parameters = [];
        $missing    = [];
        $empty      = [];

        foreach ($positions as $position) {
            $smartcode = trim((string) ($variableMap[(string) $position] ?? $variableMap[$position] ?? ''));

            if ($smartcode === '') {
                $missing[] = '{{' . $position . '}}';
                continue;
            }

            $value = $message ? WhatsAppHelper::applyRecipientSmartCodes($smartcode, $message) : $smartcode;
            $value = $subscriber
                ? WhatsAppHelper::parseMessageContent($value, $subscriber)
                : WhatsAppHelper::stripUnresolvedSmartCodes(wp_strip_all_tags($value));

            // Meta rejects newlines, tabs and 4+ consecutive spaces in parameters.
            $value = trim(preg_replace('/\s+/u', ' ', $value));

            if ($value === '') {
                $empty[] = '{{' . $position . '}}';
                continue;
            }

            $parameters[] = ['type' => 'text', 'text' => $value];
        }

        if ($missing) {
            return self::error(sprintf(
            /* translators: 1: template name, 2: comma-separated variable placeholders */
                __('Template "%1$s" has unmapped variables: %2$s. Map every variable before sending.', 'fluentcampaign-pro'),
                $template->name,
                implode(', ', $missing)
            ));
        }

        if ($empty) {
            return self::error(sprintf(
            /* translators: 1: template name, 2: comma-separated variable placeholders */
                __('Template "%1$s" variables rendered empty for this contact: %2$s. Add a fallback, e.g. {{contact.first_name|there}}.', 'fluentcampaign-pro'),
                $template->name,
                implode(', ', $empty)
            ));
        }

        return [
            'components' => [
                ['type' => 'body', 'parameters' => $parameters],
            ],
            'error'      => null,
        ];
    }

    /**
     * Why this template can never be rendered (header variable or dynamic URL button), or null.
     */
    public static function getUnsupportedReason(MessageTemplate $template): ?string
    {
        if (preg_match('/\{\{\d+\}\}/', (string) $template->header_text)) {
            return sprintf(
            /* translators: %s: template name */
                __('Template "%s" uses a header variable, which campaigns cannot map yet. Choose a template with a static header.', 'fluentcampaign-pro'),
                $template->name
            );
        }

        foreach ((array) $template->buttons as $button) {
            if (strpos((string) ($button['url'] ?? ''), '{{') !== false) {
                return sprintf(
                /* translators: %s: template name */
                    __('Template "%s" uses a dynamic URL button, which campaigns cannot map yet. Choose a template with static buttons.', 'fluentcampaign-pro'),
                    $template->name
                );
            }
        }

        return null;
    }

    protected static function error(string $message): array
    {
        return ['components' => [], 'error' => $message];
    }
}
