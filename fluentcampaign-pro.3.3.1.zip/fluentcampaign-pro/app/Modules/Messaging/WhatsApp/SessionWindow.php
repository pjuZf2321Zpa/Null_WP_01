<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;


/**
 * WhatsApp's 24-hour customer-service window, derived from messages: open while an inbound
 * message exists in the last 24 hours. Outside it only approved templates are accepted.
 */
class SessionWindow
{
    const DURATION = 86400; // 24 hours, per Meta's customer-service window

    /**
     * Per-request memo of lastInboundAt(); webhooks call forget() after storing an inbound row.
     *
     * @var array<int, string|null> keyed by thread id
     */
    protected static $lastInboundCache = [];

    /**
     * Drop the memoized timestamp for a thread after a new inbound message.
     */
    public static function forget(int $threadId): void
    {
        unset(self::$lastInboundCache[$threadId]);
    }

    /**
     * A contact's WhatsApp thread id, or 0 when they have none.
     */
    protected static function threadIdForContact(int $contactId): int
    {
        $thread = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::forContact($contactId, 'whatsapp');

        return $thread ? (int) $thread->id : 0;
    }

    public static function isOpenForContact(int $contactId): bool
    {
        return self::isOpen(self::threadIdForContact($contactId));
    }

    public static function getStatsForContact(int $contactId): array
    {
        return self::getStats(self::threadIdForContact($contactId));
    }

    public static function forgetContact(int $contactId): void
    {
        self::forget(self::threadIdForContact($contactId));
    }

    /**
     * Timestamp of the thread's most recent inbound message.
     *
     * @param int $threadId fc_message_threads row id
     */
    public static function lastInboundAt(int $threadId): ?string
    {
        if (!$threadId) {
            return null;
        }

        if (!array_key_exists($threadId, self::$lastInboundCache)) {
            $row = \FluentCampaign\App\Modules\Messaging\Models\Message::where('thread_id', $threadId)
                ->where('direction', 'inbound')
                ->orderBy('created_at', 'DESC')
                ->first();

            self::$lastInboundCache[$threadId] = $row ? $row->created_at : null;
        }

        return self::$lastInboundCache[$threadId];
    }

    public static function isOpen(int $threadId): bool
    {
        $last = self::lastInboundAt($threadId);

        if (!$last) {
            return false;
        }

        // created_at is WP-local time, so compare against the WP-local clock.
        return (strtotime($last) + self::DURATION) > current_time('timestamp');
    }

    /**
     * When the current window closes, or null when none is open.
     */
    public static function expiresAt(int $threadId): ?string
    {
        $last = self::lastInboundAt($threadId);

        if (!$last) {
            return null;
        }

        $expires = strtotime($last) + self::DURATION;

        // The epoch is already WP-local; gmdate() formats it without shifting.
        return $expires > current_time('timestamp') ? gmdate('Y-m-d H:i:s', $expires) : null;
    }

    /**
     * Which message form the channel should use for this contact right now.
     *
     * @return string 'session' (free-form) or 'template'
     */
    public static function getRecommendedMessageType(int $threadId): string
    {
        return self::isOpen($threadId) ? 'session' : 'template';
    }

    /**
     * Summary for the contact profile panel.
     */
    public static function getStats(int $threadId): array
    {
        $last = self::lastInboundAt($threadId);
        $open = $last && (strtotime($last) + self::DURATION) > current_time('timestamp');

        $expiresAt = $open ? gmdate('Y-m-d H:i:s', strtotime($last) + self::DURATION) : null;

        return [
            'has_active_session' => $open,
            'last_inbound_at'    => $last,
            'expires_at'         => $expiresAt,
            // Offset-qualified copies of the site-local strings above.
            'last_inbound_at_iso' => WhatsAppHelper::toIso($last),
            'expires_at_iso'      => WhatsAppHelper::toIso($expiresAt),
            'inbound_count'      => $threadId
                ? (int) \FluentCampaign\App\Modules\Messaging\Models\Message::where('thread_id', $threadId)
                    ->where('direction', 'inbound')
                    ->count()
                : 0,
        ];
    }
}
