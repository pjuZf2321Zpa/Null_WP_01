<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp\Http\Controllers;

use FluentCampaign\App\Modules\Messaging\WhatsApp\MediaStore;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\WhatsAppDriverManager;
use FluentCampaign\App\Modules\Messaging\WhatsApp\SessionWindow;
use FluentCampaign\App\Modules\Messaging\WhatsApp\TemplateProviderScope;
use FluentCampaign\App\Modules\Messaging\WhatsApp\TemplateRenderer;
use FluentCampaign\App\Modules\Messaging\WhatsApp\TemplateValidator;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppSender;
use FluentCampaign\App\Modules\Messaging\Contracts\TemplateApiInterface;
use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\Models\MessageTemplate;
use FluentCrm\App\Http\Controllers\Controller;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\Framework\Request\Request;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;

/**
 * WhatsApp template catalogue (list, sync, submit, delete) and the contact profile's message history.
 */
class WhatsAppTemplateController extends Controller
{
    /**
     * The configured provider driver, when it supports templates at all.
     */
    protected function templateDriver(): ?TemplateApiInterface
    {
        $driver = WhatsAppDriverManager::getDriver(WhatsAppHelper::getCurrentProvider());

        return $driver instanceof TemplateApiInterface ? $driver : null;
    }

    public function index(Request $request)
    {
        $requestedChannel = sanitize_key($request->get('channel', 'whatsapp'));
        $channel = in_array($requestedChannel, ['all', 'sms', 'whatsapp'], true) ? $requestedChannel : 'whatsapp';

        $currentProvider = WhatsAppHelper::getCurrentProvider();
        $providerLabels  = $this->providerLabels();
        $approvedOnly    = (bool) $request->get('approved_only');
        $search          = sanitize_text_field($request->get('search', ''));
        $perPage         = absint($request->get('per_page'));
        $page            = absint($request->get('page'));
        $status          = sanitize_text_field($request->get('status', ''));

        if ($approvedOnly) {
            $channel = 'whatsapp';
        }

        $activeChannels = $this->activeTemplateChannels();

        if (!$activeChannels || ($channel !== 'all' && !in_array($channel, $activeChannels, true))) {
            return $this->channelDisabledResponse();
        }

        $queryChannels = $channel === 'all' ? $activeChannels : [$channel];
        $query = $this->templateIndexQuery($queryChannels, $approvedOnly, $currentProvider, $status, $search)
            ->orderBy('id', 'DESC');

        $shouldPaginate = $request->exists('channel') || $search || $status || $perPage || $page;

        if ($shouldPaginate) {
            $perPage = $perPage ? min($perPage, 100) : 20;
            $page = $page ?: 1;
            $templates = $query->paginate($perPage, ['*'], 'page', $page);
            $this->decorateTemplates($templates->items(), $currentProvider, $providerLabels);
        } else {
            $templates = $query->get();
            $this->decorateTemplates($templates, $currentProvider, $providerLabels);
        }

        $statusCountQuery = $this->templateIndexQuery($queryChannels, $approvedOnly, $currentProvider, $status, $search)
            ->selectRaw('status, COUNT(*) as count');

        // One grouped count instead of four separate COUNT queries.
        $statusCounts = $statusCountQuery->groupBy('status')->pluck('count', 'status');
        $currentProviderMeta = TemplateProviderScope::meta($currentProvider, $currentProvider, $providerLabels);
        $templateMeta = $this->templateIndexMeta($queryChannels, $approvedOnly, $currentProvider, $status, $search);

        return $this->sendSuccess([
            'templates'         => $templates,
            'supports_sync'     => (bool) $this->templateDriver(),
            'current_provider'  => $currentProvider,
            'current_provider_label' => $currentProviderMeta['provider_label'],
            'provider_labels'   => $providerLabels,
            'last_synced_at'    => $templateMeta['last_synced_at'],
            'has_inactive_provider_templates' => $templateMeta['has_inactive_provider_templates'],
            'counts'            => [
                'total'    => (int) $statusCounts->sum(),
                'approved' => (int) $statusCounts->get(MessageTemplate::STATUS_APPROVED, 0),
                'pending'  => (int) $statusCounts->get(MessageTemplate::STATUS_PENDING, 0),
                'rejected' => (int) $statusCounts->get(MessageTemplate::STATUS_REJECTED, 0),
            ],
        ]);
    }

    /**
     * Shared template query, so rows, counts and metadata apply the same filters.
     */
    protected function templateIndexQuery(
        array $channels,
        bool $approvedOnly,
        string $currentProvider,
        string $status = '',
        string $search = ''
    ) {
        $query = MessageTemplate::query();

        $query->whereIn('channel', $channels);

        if ($status) {
            $query->where('status', strtoupper($status));
        }

        if ($approvedOnly) {
            $query->approved()->where('provider', $currentProvider);
        }

        $this->applyTemplateSearch($query, $search);

        return $query;
    }

    /**
     * Dataset-level values for the template list, computed across all pages.
     */
    protected function templateIndexMeta(
        array $channels,
        bool $approvedOnly,
        string $currentProvider,
        string $status = '',
        string $search = ''
    ): array {
        if (!in_array('whatsapp', $channels, true)) {
            return [
                'last_synced_at' => '',
                'has_inactive_provider_templates' => false,
            ];
        }

        $lastSyncedAt = (string) $this->templateIndexQuery($channels, $approvedOnly, $currentProvider, $status, $search)
            ->where('channel', 'whatsapp')
            ->max('last_synced_at');

        $inactiveProviderQuery = $this->templateIndexQuery($channels, $approvedOnly, $currentProvider, $status, $search)
            ->where('channel', 'whatsapp');

        if ($currentProvider) {
            $inactiveProviderQuery->where(function ($query) use ($currentProvider) {
                $query->whereNull('provider')
                    ->orWhere('provider', '')
                    ->orWhere('provider', '!=', $currentProvider);
            });
        }

        return [
            'last_synced_at' => $lastSyncedAt,
            'has_inactive_provider_templates' => $inactiveProviderQuery->exists(),
        ];
    }

    /**
     * Apply search across the fields visible in the template table.
     */
    protected function applyTemplateSearch($query, string $search): void
    {
        if (!$search) {
            return;
        }

        global $wpdb;

        $like = '%' . $wpdb->esc_like($search) . '%';

        $query->where(function ($query) use ($like) {
            $query->where('name', 'LIKE', $like)
                ->orWhere('category', 'LIKE', $like)
                ->orWhere('status', 'LIKE', $like)
                ->orWhere('provider', 'LIKE', $like)
                ->orWhere('body_text', 'LIKE', $like);
        });
    }

    protected function activeTemplateChannels(): array
    {
        return array_values(array_filter(['sms', 'whatsapp'], function ($channel) {
            $templateChannel = MessageModule::channel($channel);

            return $templateChannel && $templateChannel->isActive();
        }));
    }

    protected function isTemplateChannelActive(string $channel): bool
    {
        return in_array($channel, $this->activeTemplateChannels(), true);
    }

    protected function channelDisabledResponse()
    {
        return $this->sendError([
            'message' => __('The selected messaging channel is not enabled.', 'fluentcampaign-pro'),
        ]);
    }

    /**
     * Attach the same provider/selectability metadata to full and paged rows.
     */
    protected function decorateTemplates($templates, string $currentProvider, array $providerLabels): void
    {
        foreach ($templates as $template) {
            if ($template->channel === 'sms') {
                $template->setAttribute('provider_label', __('SMS', 'fluentcampaign-pro'));
                $template->setAttribute('is_current_provider', true);
                $template->setAttribute('is_selectable', true);
                $template->setAttribute('disabled_reason', '');
            } else {
                foreach (TemplateProviderScope::meta((string) $template->provider, $currentProvider, $providerLabels) as $key => $value) {
                    $template->setAttribute($key, $value);
                }
            }
        }
    }

    protected function providerLabels(): array
    {
        $labels = [];

        foreach (WhatsAppHelper::getApiOptions()['providers'] ?? [] as $provider => $definition) {
            $labels[$provider] = $definition['label'] ?? ucwords(str_replace('_', ' ', $provider));
        }

        return $labels;
    }

    /**
     * Pull the provider catalogue into fc_message_templates, matched on (channel, provider, name, language).
     * Templates gone at the provider are marked DISABLED, not deleted.
     */
    public function sync(Request $request)
    {
        if (!$this->isTemplateChannelActive('whatsapp')) {
            return $this->channelDisabledResponse();
        }

        $driver = $this->templateDriver();

        if (!$driver) {
            return $this->sendError([
                'message' => __('The selected WhatsApp provider does not support templates.', 'fluentcampaign-pro'),
            ]);
        }

        $provider = WhatsAppHelper::getCurrentProvider();
        $result   = $driver->fetchTemplates(WhatsAppHelper::getProviderSettings($provider));

        if (($result['status'] ?? '') !== 'success') {
            return $this->sendError(['message' => $result['message'] ?: __('Could not reach the provider.', 'fluentcampaign-pro')]);
        }

        $now  = current_time('mysql');
        $seen = [];

        // Existing rows keyed by (name, language).
        $existing = MessageTemplate::forChannel('whatsapp')
            ->where('provider', $provider)
            ->get()
            ->keyBy(function ($template) {
                return $template->name . '|' . $template->language;
            });

        foreach ($result['data'] as $row) {
            $name = sanitize_text_field($row['name'] ?? '');

            if (!$name) {
                continue;
            }

            $language = sanitize_text_field($row['language'] ?? 'en_US');
            $parsed   = $this->parseComponents($row['components'] ?? []);
            $identity = $name . '|' . $language;

            $seen[$identity] = true;

            $data = [
                'channel'              => 'whatsapp',
                'provider'             => $provider,
                'name'                 => $name,
                'language'             => $language,
                'category'             => sanitize_text_field($row['category'] ?? ''),
                'status'               => strtoupper(sanitize_text_field($row['status'] ?? MessageTemplate::STATUS_PENDING)),
                'header_text'          => $parsed['header'],
                'body_text'            => $parsed['body'],
                'footer_text'          => $parsed['footer'],
                'buttons'              => $parsed['buttons'],
                'provider_template_id' => sanitize_text_field($row['id'] ?? ''),
                'rejection_reason'     => sanitize_text_field($row['reason'] ?? ''),
                'last_synced_at'       => $now,
            ];

            if (isset($existing[$identity])) {
                $existing[$identity]->update($data);
            } else {
                MessageTemplate::create($data);
            }
        }

        // Disable local rows the provider no longer lists, per (name, language).
        $staleIds = [];
        foreach ($existing as $identity => $template) {
            if (!isset($seen[$identity])) {
                $staleIds[] = $template->id;
            }
        }

        if ($staleIds) {
            MessageTemplate::whereIn('id', $staleIds)
                ->update(['status' => MessageTemplate::STATUS_DISABLED, 'last_synced_at' => $now]);
        }

        return $this->sendSuccess([
            'message' => sprintf(
            /* translators: %d: number of templates synced */
                _n('%d template synced.', '%d templates synced.', count($seen), 'fluentcampaign-pro'),
                count($seen)
            ),
            'synced'  => count($seen),
        ]);
    }

    /**
     * Meta returns a component array; flatten it into our columns.
     */
    protected function parseComponents(array $components): array
    {
        $out = ['header' => '', 'body' => '', 'footer' => '', 'buttons' => []];

        foreach ($components as $component) {
            $type = strtoupper($component['type'] ?? '');

            if ($type === 'HEADER' && strtoupper($component['format'] ?? 'TEXT') === 'TEXT') {
                $out['header'] = (string) ($component['text'] ?? '');
            } elseif ($type === 'BODY') {
                $out['body'] = (string) ($component['text'] ?? '');
            } elseif ($type === 'FOOTER') {
                $out['footer'] = (string) ($component['text'] ?? '');
            } elseif ($type === 'BUTTONS') {
                $out['buttons'] = $component['buttons'] ?? [];
            }
        }

        return $out;
    }

    /**
     * Validate and submit a new template for approval.
     */
    public function store(Request $request)
    {
        $channel = sanitize_key($request->get('channel', 'whatsapp')) === 'sms' ? 'sms' : 'whatsapp';

        if (!$this->isTemplateChannelActive($channel)) {
            return $this->channelDisabledResponse();
        }

        if ($channel === 'sms') {
            return $this->storeSmsTemplate($request);
        }

        $payload = [
            'name'        => sanitize_key($request->get('name', '')),
            'language'    => sanitize_text_field($request->get('language', 'en_US')),
            'category'    => strtoupper(sanitize_text_field($request->get('category', 'MARKETING'))),
            'header_text' => sanitize_text_field($request->get('header_text', '')),
            'body_text'   => sanitize_textarea_field($request->get('body_text', '')),
            'footer_text' => sanitize_text_field($request->get('footer_text', '')),
            'buttons'     => (array) $request->get('buttons', []),
            'variables'   => (array) $request->get('variables', []),
        ];

        $check = TemplateValidator::validate($payload);

        if ($check['errors']) {
            return $this->sendError([
                'message' => __('This template cannot be submitted yet.', 'fluentcampaign-pro'),
                'errors'  => $check['errors'],
            ]);
        }

        $driver = $this->templateDriver();

        if (!$driver) {
            return $this->sendError([
                'message' => __('The selected WhatsApp provider does not support templates.', 'fluentcampaign-pro'),
            ]);
        }

        $provider = WhatsAppHelper::getCurrentProvider();

        $result = $driver->submitTemplate([
            'name'      => $payload['name'],
            'language'  => $payload['language'],
            'category'  => $payload['category'],
            'header'    => $payload['header_text'],
            'body'      => $payload['body_text'],
            'footer'    => $payload['footer_text'],
            'buttons'   => $payload['buttons'],
            'variables' => $payload['variables'],
        ], WhatsAppHelper::getProviderSettings($provider));

        if (($result['status'] ?? '') !== 'success') {
            return $this->sendError(['message' => $result['message']]);
        }

        $template = MessageTemplate::create(array_merge($payload, [
            'channel'              => 'whatsapp',
            'provider'             => $provider,
            'language'             => sanitize_text_field($result['data']['language'] ?? $payload['language']),
            'status'               => strtoupper($result['data']['status'] ?? MessageTemplate::STATUS_PENDING),
            'provider_template_id' => sanitize_text_field($result['data']['id'] ?? ''),
            'last_synced_at'       => current_time('mysql'),
            'created_by'           => get_current_user_id(),
        ]));

        return $this->sendSuccess([
            'message'  => __('Template submitted for provider review. Use Sync Templates to check its status.', 'fluentcampaign-pro'),
            'template' => $template,
            'warnings' => $check['warnings'],
        ]);
    }

    /**
     * Create a local SMS template; approved immediately since there is no provider review.
     */
    protected function storeSmsTemplate(Request $request)
    {
        $name = sanitize_text_field($request->get('name', ''));
        $body = sanitize_textarea_field($request->get('body_text', ''));
        $nameLength = function_exists('mb_strlen') ? mb_strlen($name) : strlen($name);
        $bodyLength = function_exists('mb_strlen') ? mb_strlen($body) : strlen($body);
        $errors = [];

        if (!$name) {
            $errors[] = __('Template name is required.', 'fluentcampaign-pro');
        } elseif ($nameLength > 192) {
            $errors[] = __('Template name must be 192 characters or fewer.', 'fluentcampaign-pro');
        }

        if (!$body) {
            $errors[] = __('SMS body is required.', 'fluentcampaign-pro');
        } elseif ($bodyLength > 1600) {
            $errors[] = __('SMS body must be 1600 characters or fewer.', 'fluentcampaign-pro');
        }

        // DISABLED rows do not reserve their name.
        $nameTaken = !$errors && MessageTemplate::forChannel('sms')
            ->where('name', $name)
            ->where('status', '!=', MessageTemplate::STATUS_DISABLED)
            ->exists();

        if ($nameTaken) {
            $errors[] = __('An SMS template with this name already exists.', 'fluentcampaign-pro');
        }

        if ($errors) {
            return $this->sendError([
                'message' => __('This SMS template cannot be saved yet.', 'fluentcampaign-pro'),
                'errors'  => $errors,
            ]);
        }

        $template = MessageTemplate::create([
            'channel'              => 'sms',
            'provider'             => '',
            'name'                 => $name,
            'language'             => 'en',
            'category'             => '',
            'status'               => MessageTemplate::STATUS_APPROVED,
            'header_text'          => '',
            'body_text'            => $body,
            'footer_text'          => '',
            'buttons'              => [],
            'variables'            => [],
            'provider_template_id' => '',
            'rejection_reason'     => '',
            'created_by'           => get_current_user_id(),
        ]);

        return $this->sendSuccess([
            'message'  => __('SMS template saved.', 'fluentcampaign-pro'),
            'template' => $template,
            'warnings' => [],
        ]);
    }

    /**
     * Validate without submitting — powers the composer's live checks.
     */
    public function validateTemplate(Request $request)
    {
        if (!$this->isTemplateChannelActive('whatsapp')) {
            return $this->channelDisabledResponse();
        }

        return $this->sendSuccess(TemplateValidator::validate([
            'name'        => $request->get('name', ''),
            'body_text'   => $request->get('body_text', ''),
            'header_text' => $request->get('header_text', ''),
            'footer_text' => $request->get('footer_text', ''),
            'buttons'     => (array) $request->get('buttons', []),
            'variables'   => (array) $request->get('variables', []),
        ]));
    }

    public function destroy(Request $request, $id)
    {
        $template = MessageTemplate::whereIn('channel', ['sms', 'whatsapp'])->find((int) $id);

        if (!$template) {
            return $this->sendError(['message' => __('Template not found.', 'fluentcampaign-pro')]);
        }

        if (!$this->isTemplateChannelActive($template->channel)) {
            return $this->channelDisabledResponse();
        }

        if ($template->channel === 'whatsapp') {
            // Remove at the provider first.
            $driver = WhatsAppDriverManager::getDriver((string) $template->provider);
            if ($driver instanceof TemplateApiInterface && $template->provider_template_id) {
                $deleteResult = $driver->deleteTemplate(
                    $template->name,
                    WhatsAppHelper::getProviderSettings($template->provider),
                    (string) $template->provider_template_id,
                    (string) $template->language
                );

                if (($deleteResult['status'] ?? '') !== 'success') {
                    return $this->sendError([
                        'message' => $deleteResult['message'] ?: __('Could not delete the template at the provider.', 'fluentcampaign-pro'),
                    ]);
                }
            }
        }

        // Templates referenced by messages are kept as DISABLED; others are hard-deleted.
        if (\FluentCampaign\App\Modules\Messaging\Models\Message::usingTemplate($template->id)->exists()) {
            $template->update(['status' => MessageTemplate::STATUS_DISABLED]);

            if ($template->channel === 'sms') {
                return $this->sendSuccess([
                    'message' => __('Template kept locally as disabled because sent messages reference it.', 'fluentcampaign-pro'),
                ]);
            }

            return $this->sendSuccess([
                'message' => __('Template removed from the provider. It was kept locally as disabled because sent messages reference it.', 'fluentcampaign-pro'),
            ]);
        }

        $template->delete();

        return $this->sendSuccess(['message' => __('Template deleted.', 'fluentcampaign-pro')]);
    }

    /**
     * A contact's WhatsApp history for the profile panel, with stats and session state.
     * Oldest first by default (the chat loads the last page); the table asks for order=desc.
     */
    public function subscriberMessages(Request $request, $id)
    {
        $id = (int) $id;

        $order = strtolower((string) $request->get('order', 'asc')) === 'desc' ? 'DESC' : 'ASC';

        $perPage = (int) $request->get('per_page', 20);
        $perPage = ($perPage > 0 && $perPage <= 200) ? $perPage : 20;

        // No thread means an empty history.
        $thread = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::forContact($id, 'whatsapp');

        $query = $this->applyMessageFilter(
            \FluentCampaign\App\Modules\Messaging\Models\Message::where('thread_id', $thread ? $thread->id : 0),
            (string) $request->get('filter_type', '')
        );

        // Order by the displayed timestamp; id keeps the order stable.
        $messages = $query
            ->orderByRaw('COALESCE(sent_at, created_at) ' . $order)
            ->orderBy('id', $order)
            ->paginate($perPage);

        // Mapped to the field names the profile chat renders.
        foreach ($messages->items() as $message) {
            $meta = $message->meta;

            $message->timestamp       = WhatsAppHelper::toIso($message->sent_at ?: $message->created_at);
            $message->media           = $this->messageMedia($message);
            $message->message_content = $message->content;
            $message->message_type    = !empty($meta['template_id']) || !empty($meta['template_name']) ? 'template' : 'text';
            $message->template_name   = isset($meta['template_name']) ? $meta['template_name'] : '';
        }

        return $this->sendSuccess([
            'messages' => $messages,
            'stats'    => $this->messageStats($id),
            'session'  => SessionWindow::getStatsForContact((int) $id),
        ]);
    }

    /**
     * Narrow the history to a stat card or table filter. Unknown or empty means everything.
     */
    protected function applyMessageFilter($query, string $filter)
    {
        switch ($filter) {
            case 'sent':
                return $query->where('direction', 'outbound')->whereNotNull('sent_at');

            case 'received':
                return $query->where('direction', 'inbound');

            case 'campaign':
                return $query->where('ref_type', 'campaign');

            case 'custom':
                return $query->where(function ($sub) {
                    return $sub->whereNull('ref_type')->orWhere('ref_type', '!=', 'campaign');
                });

            case 'read':
                // Read receipts live in status.
                return $query->where('status', 'read');

            default:
                return $query;
        }
    }

    /**
     * A message's attachments as a plain list, unpacked from the stored provider settings.
     * Twilio documents fall back to message_content for the filename.
     */
    protected function messageMedia($message): array
    {
        $meta = $message->meta;

        $attachments = isset($meta['attachments']) && is_array($meta['attachments'])
            ? $meta['attachments']
            : [];

        if (!$attachments) {
            return [];
        }

        $media = [];

        foreach ($attachments as $item) {
            if (!is_array($item)) {
                continue;
            }

            $url      = (string) ($item['url'] ?? '');
            $mimeType = (string) ($item['mime_type'] ?? $item['content_type'] ?? '');
            $filename = (string) ($item['filename'] ?? '');

            $normalizedMime = strtolower($mimeType);
            $expectedExtension = MediaStore::TWILIO_ALLOWED_MIME_TYPES[$normalizedMime] ?? '';
            $isDocument = strpos($normalizedMime, 'application/') === 0
                || in_array($normalizedMime, ['text/vcard', 'text/x-vcard'], true);

            if (!$filename && $isDocument && $expectedExtension) {
                $bodyFilename = sanitize_file_name(wp_basename((string) $message->message_content));

                if (strtolower(pathinfo($bodyFilename, PATHINFO_EXTENSION)) === $expectedExtension) {
                    $filename = $bodyFilename;
                }
            }

            $media[] = [
                'type'      => (string) ($item['type'] ?? ''),
                // Only locally stored URLs; provider links expire.
                'url'       => !empty($item['stored']) ? $url : '',
                'mime_type' => $mimeType,
                'filename'  => $filename,
                'caption'   => (string) ($item['caption'] ?? ''),
                'filesize'  => (int) ($item['filesize'] ?? 0),
                'stored'    => !empty($item['stored']),
            ];
        }

        return $media;
    }

    /**
     * The five counters behind the profile stat cards.
     */
    protected function messageStats(int $id): array
    {
        $thread = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::forContact($id, 'whatsapp');

        $baseQuery = \FluentCampaign\App\Modules\Messaging\Models\Message::where('thread_id', $thread ? $thread->id : 0);

        return [
            'total'    => (clone $baseQuery)->count(),
            'sent'     => (clone $baseQuery)->where('direction', 'outbound')->whereNotNull('sent_at')->count(),
            'received' => (clone $baseQuery)->where('direction', 'inbound')->count(),
            'campaign' => (clone $baseQuery)->where('ref_type', 'campaign')->count(),
            'read'     => (clone $baseQuery)->where(function ($query) {
                return $query->where('status', 'read');
            })->count(),
        ];
    }

    /**
     * Count the WhatsApp messages shown in the contact profile stats panel.
     */
    public function subscriberStats(Request $request, $id)
    {
        $subscriber = Subscriber::find((int) $id);

        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Contact not found.', 'fluentcampaign-pro'),
                'code'    => 404,
            ]);
        }

        return $this->sendSuccess(['stats' => $this->messageStats((int) $id)]);
    }

    /**
     * Whether the 24-hour window is open for this contact, and until when.
     */
    public function subscriberSession(Request $request, $id)
    {
        return $this->sendSuccess(['session' => SessionWindow::getStatsForContact((int) $id)]);
    }

    /**
     * Send a one-off WhatsApp message from the profile panel.
     * Free-form text is refused outside the 24-hour window (Meta error 131047).
     */
    public function sendCustomMessage(Request $request, $id)
    {
        if (!WhatsAppHelper::isActive()) {
            return $this->sendError([
                'message' => __('WhatsApp is not active.', 'fluentcampaign-pro')
            ], 409);
        }

        $subscriber = Subscriber::find((int) $id);

        if (!$subscriber) {
            return $this->sendError(['message' => __('Contact not found.', 'fluentcampaign-pro')]);
        }

        if (empty($subscriber->phone)) {
            return $this->sendError(['message' => __('This contact has no phone number.', 'fluentcampaign-pro')]);
        }

        if (!MessageThread::contactCanReceive('whatsapp', $subscriber->id)) {
            return $this->sendError([
                'message' => __('This contact has not opted in to WhatsApp.', 'fluentcampaign-pro'),
            ]);
        }

        $type     = sanitize_key($request->get('message_type', 'session'));
        $provider = WhatsAppHelper::getCurrentProvider();
        $driver   = WhatsAppDriverManager::getDriver($provider);

        if (!$driver) {
            return $this->sendError(['message' => __('WhatsApp provider is not configured.', 'fluentcampaign-pro')]);
        }

        if ($type === 'template') {
            // Only the current provider's templates; language pins the variant when given.
            $templateQuery = MessageTemplate::forChannel('whatsapp')->approved()
                ->where('provider', $provider)
                ->where('name', sanitize_text_field($request->get('template_name', '')));

            if ($language = sanitize_text_field($request->get('template_language', ''))) {
                $templateQuery->where('language', $language);
            }

            $template = $templateQuery->first();

            if (!$template) {
                return $this->sendError(['message' => __('Pick an approved template.', 'fluentcampaign-pro')]);
            }

            if (!$driver instanceof TemplateApiInterface) {
                return $this->sendError(['message' => __('This provider does not support templates.', 'fluentcampaign-pro')]);
            }

            $rendered = TemplateRenderer::render(
                $template,
                (array) $request->get('template_variables', []),
                $subscriber
            );

            if ($rendered['error']) {
                return $this->sendError(['message' => $rendered['error']], 422);
            }

            $result = WhatsAppSender::sendTemplate(
                $subscriber->phone,
                $template->name,
                $template->language,
                $rendered['components'],
                $provider,
                (string) $template->provider_template_id
            );
            $body = $template->body_text;
        } else {
            if (!SessionWindow::isOpenForContact((int) $id)) {
                return $this->sendError([
                    'message' => __('The 24-hour reply window is closed for this contact. Send an approved template instead.', 'fluentcampaign-pro'),
                ]);
            }

            $body   = sanitize_textarea_field($request->get('message', ''));
            $result = WhatsAppSender::send(
                $subscriber->phone,
                WhatsAppHelper::parseMessageContent($body, $subscriber),
                $provider
            );
        }

        $succeeded = ($result['status'] ?? '') === 'success';

        $record = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::recordOutbound(
            'whatsapp',
            $subscriber->phone,
            $subscriber->id,
            $body,
            $result,
            [
                'ref_type'    => 'custom',
                'template_id' => isset($template) ? $template->id : null
            ]
        );

        if (!$succeeded) {
            return $this->sendError(['message' => $result['message'] ?? __('Send failed.', 'fluentcampaign-pro')]);
        }

        // The panel reconciles its optimistic bubble by this row's id.
        $record->timestamp = WhatsAppHelper::toIso($record->sent_at ?: $record->created_at);
        $record->media     = $this->messageMedia($record);

        return $this->sendSuccess([
            'message'    => __('Message sent.', 'fluentcampaign-pro'),
            'wa_message' => $record,
        ]);
    }
}
