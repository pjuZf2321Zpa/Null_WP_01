<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\WhatsAppDriverManager;

class WhatsAppSender
{
    public static function send(string $to, string $message, ?string $provider = null): array
    {
        if (!WhatsAppHelper::isActive()) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => __('WhatsApp messaging is not enabled.', 'fluentcampaign-pro'),
                'response'    => null,
            ];
        }

        if (!$provider) {
            $provider = WhatsAppHelper::getCurrentProvider();
        }

        $settings         = WhatsAppHelper::getProviderSettings($provider);
        $providerInstance = WhatsAppDriverManager::getDriver($provider);

        if ($providerInstance) {
            return $providerInstance->send($to, $message, $settings);
        }

        return [
            'status'      => 'error',
            'status_code' => 0,
            /* translators: %s: provider key */
            'message'     => sprintf(__('The WhatsApp provider "%s" is not available.', 'fluentcampaign-pro'), $provider),
            'response'    => null,
        ];
    }

    /**
     * Send an approved template through the configured provider; errors if it has no template support.
     *
     * @param string $to           E.164 phone number
     * @param string $templateName Provider-side template name
     * @param string $language     Template language code, e.g. 'en_US'
     * @param array  $components   Meta components array (may be empty)
     */
    public static function sendTemplate(string $to, string $templateName, string $language, array $components, ?string $provider = null, string $providerTemplateId = ''): array
    {
        if (!WhatsAppHelper::isActive()) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                'message'     => __('WhatsApp messaging is not enabled.', 'fluentcampaign-pro'),
                'response'    => null,
            ];
        }

        if (!$provider) {
            $provider = WhatsAppHelper::getCurrentProvider();
        }

        $settings         = WhatsAppHelper::getProviderSettings($provider);
        $providerInstance = WhatsAppDriverManager::getDriver($provider);

        if (!$providerInstance) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                /* translators: %s: provider key */
                'message'     => sprintf(__('The WhatsApp provider "%s" is not available.', 'fluentcampaign-pro'), $provider),
                'response'    => null,
            ];
        }

        if (!method_exists($providerInstance, 'sendTemplate')) {
            return [
                'status'      => 'error',
                'status_code' => 0,
                /* translators: %s: provider key */
                'message'     => sprintf(__('The WhatsApp provider "%s" does not support template messages.', 'fluentcampaign-pro'), $provider),
                'response'    => null,
            ];
        }

        return $providerInstance->sendTemplate($to, $templateName, $language, $components, $settings, $providerTemplateId);
    }
}
