<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp\Models;

use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;

/**
 * WhatsApp-scoped view of `fc_sms_campaigns`: reads are scoped and inserts forced to `channel = 'whatsapp'`.
 * Do not override OBJECT_TYPE; meta, labels and pivots share MessageCampaign::OBJECT_TYPE.
 */
class WhatsAppCampaign extends MessageCampaign
{
    public static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->channel = self::CHANNEL_WHATSAPP;
        });

        // Global scopes are per class, so MessageCampaign still sees every channel.
        static::addGlobalScope('channel', function ($builder) {
            $builder->where('channel', self::CHANNEL_WHATSAPP);
        });
    }
}
