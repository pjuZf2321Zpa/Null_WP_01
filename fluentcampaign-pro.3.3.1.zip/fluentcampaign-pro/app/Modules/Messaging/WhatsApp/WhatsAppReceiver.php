<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\Models\Message;

class WhatsAppReceiver
{
    /**
     * Handle incoming Twilio WhatsApp webhook.
     *
     * Expected Twilio form POST shape, sanitized by MessageHandler before it gets here:
     *
     * Text:
     * SmsSid=SM...&SmsStatus=received&From=whatsapp:+15551234567&
     * To=whatsapp:+15557654321&WaId=15551234567&ProfileName=Jane%20Contact&
     * Body=Hello&MessageType=text&NumMedia=0
     *
     * Reply:
     * MessageSid=SM...&OriginalRepliedMessageSid=SM...&
     * OriginalRepliedMessageSender=whatsapp:+15557654321&Forwarded=false&
     * FrequentlyForwarded=false&Body=This%20is%20a%20reply
     *
     * Media/document:
     * MessageSid=MM...&Body=Caption%20or%20filename&MessageType=image&
     * NumMedia=1&MediaUrl0=https://api.twilio.com/.../Media/ME...&
     * MediaContentType0=image/jpeg
     *
     * ChannelMetadata may also contain context.ProfileName and context.WaId.
     *
     * @param array $bodyData Sanitized POST data from the webhook.
     * @return bool False when required fields are missing, true otherwise.
     */
    public static function handleTwilioWebhook(array $bodyData = []): bool
    {
        $event = self::normalizeTwilioPayload($bodyData);

        if (!$event['from'] || ($event['body'] === '' && empty($event['media']))) {
            return false;
        }

        $intent = WhatsAppHelper::detectKeywordIntent($event['body']);

        if ($intent) {
            // Store the body as typed, not the case-folded keyword.
            WhatsAppHelper::processIncomingMessage($event['from'], $event['to'], $event['body'], $event);

            $handled = ($intent === WhatsAppHelper::INTENT_OPT_OUT)
                ? WhatsAppHelper::optOut($event['from'], $event)
                : WhatsAppHelper::optIn($event['from'], $event);

            return (bool) $handled;
        }

        WhatsAppHelper::processIncomingMessage($event['from'], $event['to'], $event['body'], $event);
        return true;
    }

    public static function normalizeTwilioPayload(array $bodyData = []): array
    {
        $metadata = self::decodeTwilioChannelMetadata($bodyData['ChannelMetadata'] ?? '');
        $context  = is_array($metadata['data']['context'] ?? null) ? $metadata['data']['context'] : [];

        $messageSid = self::firstNonEmpty($bodyData, ['MessageSid', 'SmsMessageSid', 'SmsSid']);
        $from       = self::normalizeTwilioAddress($bodyData['From'] ?? '');
        $to         = self::normalizeTwilioAddress($bodyData['To'] ?? '');
        $body       = isset($bodyData['Body']) && !is_array($bodyData['Body']) ? trim((string) $bodyData['Body']) : '';
        $waId       = self::firstNonEmpty($bodyData, ['WaId']);

        if (!$waId && !empty($context['WaId']) && !is_array($context['WaId'])) {
            $waId = trim((string) $context['WaId']);
        }

        $profileName = self::firstNonEmpty($bodyData, ['ProfileName']);
        if (!$profileName && !empty($context['ProfileName']) && !is_array($context['ProfileName'])) {
            $profileName = (string) $context['ProfileName'];
        }

        $forwarded = self::firstNonEmpty($bodyData, ['Forwarded']);
        if ($forwarded === '' && isset($context['Forwarded']) && !is_array($context['Forwarded'])) {
            $forwarded = (string) $context['Forwarded'];
        }

        $frequentlyForwarded = self::firstNonEmpty($bodyData, ['FrequentlyForwarded']);
        if ($frequentlyForwarded === '' && isset($context['FrequentlyForwarded']) && !is_array($context['FrequentlyForwarded'])) {
            $frequentlyForwarded = (string) $context['FrequentlyForwarded'];
        }

        $messageType = self::firstNonEmpty($bodyData, ['MessageType']);
        if (!$messageType) {
            $messageType = ((int) ($bodyData['NumMedia'] ?? 0) > 0) ? 'media' : 'text';
        }

        return [
            'provider'             => 'twilio_whatsapp',
            'provider_message_id'  => $messageSid,
            'message_sid'          => $messageSid,
            'sms_sid'              => self::firstNonEmpty($bodyData, ['SmsSid']),
            'sms_message_sid'      => self::firstNonEmpty($bodyData, ['SmsMessageSid']),
            'sms_status'           => self::firstNonEmpty($bodyData, ['SmsStatus']),
            'account_sid'          => self::firstNonEmpty($bodyData, ['AccountSid']),
            'from'                 => $from,
            'to'                   => $to,
            'body'                 => $body,
            'message_type'         => strtolower($messageType),
            'profile_name'         => rawurldecode($profileName),
            'wa_id'                => $waId,
            'external_user_id'     => self::firstNonEmpty($bodyData, ['ExternalUserId']),
            'num_segments'         => (int) ($bodyData['NumSegments'] ?? 0),
            'num_media'            => (int) ($bodyData['NumMedia'] ?? 0),
            'referral_num_media'   => (int) ($bodyData['ReferralNumMedia'] ?? 0),
            'media'                => self::extractTwilioMedia($bodyData),
            'reply_to'             => [
                'message_sid' => self::firstNonEmpty($bodyData, ['OriginalRepliedMessageSid']),
                'sender'      => self::normalizeTwilioAddress($bodyData['OriginalRepliedMessageSender'] ?? ''),
            ],
            'forwarded'            => self::twilioBoolean($forwarded),
            'frequently_forwarded' => self::twilioBoolean($frequentlyForwarded),
            'channel_metadata'     => $metadata,
        ];
    }

    /**
     * Answer Meta's GET verification challenge, or 403 on a verify-token mismatch.
     */
    public static function handleMetaWebhookVerification(): void
    {
        $mode        = sanitize_text_field($_GET['hub_mode'] ?? '');
        $verifyToken = sanitize_text_field($_GET['hub_verify_token'] ?? '');
        // Echoed byte-for-byte (Meta compares exactly), and only after the verify token matches.
        $challenge = isset($_GET['hub_challenge']) ? wp_unslash($_GET['hub_challenge']) : '';

        $savedSettings = WhatsAppHelper::getProviderSettings('meta_cloud');
        $savedToken    = trim((string) ($savedSettings['verify_token'] ?? ''));

        if ($mode === 'subscribe' && $savedToken && hash_equals($savedToken, $verifyToken)) {
            status_header(200);
            echo $challenge;
            exit;
        }

        status_header(403);
        echo 'Forbidden';
        exit;
    }

    /**
     * Handle a Meta Cloud API webhook POST: apply delivery receipts, then store inbound messages and keyword opt-in/out.
     *
     * Envelope: entry[].changes[].value.{metadata, contacts[], messages[], statuses[]}.
     *
     * @param array $bodyData Decoded JSON body from Meta's webhook.
     * @return bool Always true after processing.
     */
    public static function handleMetaWebhook(array $bodyData = []): bool
    {
        $events = self::normalizeMetaPayload($bodyData);

        foreach ($events['statuses'] as $status) {
            $messageId      = sanitize_text_field($status['provider_message_id'] ?? '');
            $deliveryStatus = sanitize_text_field($status['delivery_status'] ?? '');
            if ($messageId && $deliveryStatus) {
                $record = Message::where('provider_message_id', $messageId)
                    ->whereHas('thread', function ($query) {
                        $query->where('channel', 'whatsapp');
                    })
                    ->first();

                if (!$record) {
                    continue;
                }

                $meta = is_array($record->meta) ? $record->meta : [];

                // The state goes in `status`; its timestamp goes in `meta`.
                $meta['delivery_status'] = $deliveryStatus;

                $update = [];

                if ($deliveryStatus === 'delivered') {
                    $meta['delivered_at'] = current_time('mysql');
                    $update['status'] = Message::STATUS_DELIVERED;
                } elseif ($deliveryStatus === 'read') {
                    $meta['read_at'] = current_time('mysql');
                    $update['status'] = Message::STATUS_READ;
                } elseif ($deliveryStatus === 'failed') {
                    $update['status'] = Message::STATUS_FAILED;
                    if (!empty($status['errors'])) {
                        $meta['error_message'] = wp_json_encode($status['errors']);
                    }
                }

                // Out-of-order receipts must not move the status backwards.
                if (
                    isset($update['status'], Message::DELIVERY_RANK[$update['status']], Message::DELIVERY_RANK[$record->status]) &&
                    Message::DELIVERY_RANK[$update['status']] <= Message::DELIVERY_RANK[$record->status]
                ) {
                    unset($update['status']);
                }

                $update['meta'] = \maybe_serialize($meta);

                Message::where('id', $record->id)->update($update);

                if (in_array($deliveryStatus, ['delivered', 'read'], true)) {
                    // WhatsApp funnel benchmarks listen on these.
                    do_action('fluent_crm/whatsapp_message_' . $deliveryStatus, Message::find($record->id));
                }
            }
        }

        foreach ($events['messages'] as $event) {
            if (empty($event['from']) || ($event['body'] === '' && empty($event['media']))) {
                continue;
            }

            $intent = WhatsAppHelper::detectKeywordIntent($event['body']);

            if ($intent) {
                // Store the body as typed.
                WhatsAppHelper::processIncomingMessage($event['from'], $event['to'], $event['body'], $event);

                if ($intent === WhatsAppHelper::INTENT_OPT_OUT) {
                    WhatsAppHelper::optOut($event['from'], $event);
                } else {
                    WhatsAppHelper::optIn($event['from'], $event);
                }

                continue;
            }

            WhatsAppHelper::processIncomingMessage($event['from'], $event['to'], $event['body'], $event);
        }

        return true;
    }

    public static function normalizeMetaPayload(array $bodyData = []): array
    {
        $normalized = [
            'messages' => [],
            'statuses' => [],
        ];

        foreach ((array) ($bodyData['entry'] ?? []) as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            foreach ((array) ($entry['changes'] ?? []) as $change) {
                if (!is_array($change)) {
                    continue;
                }

                $value = isset($change['value']) && is_array($change['value']) ? $change['value'] : [];
                if (!$value) {
                    continue;
                }

                $metadata   = isset($value['metadata']) && is_array($value['metadata']) ? $value['metadata'] : [];
                $contactMap = self::metaContactMap((array) ($value['contacts'] ?? []));

                foreach ((array) ($value['statuses'] ?? []) as $status) {
                    if (!is_array($status)) {
                        continue;
                    }

                    $normalized['statuses'][] = self::normalizeMetaStatus($status, $metadata, $entry, $change);
                }

                foreach ((array) ($value['messages'] ?? []) as $message) {
                    if (!is_array($message)) {
                        continue;
                    }

                    $normalized['messages'][] = self::normalizeMetaMessage($message, $metadata, $contactMap, $entry, $change);
                }
            }
        }

        return $normalized;
    }

    protected static function normalizeMetaStatus(array $status, array $metadata, array $entry, array $change): array
    {
        return [
            'provider'            => 'meta_cloud',
            'provider_message_id' => self::stringValue($status['id'] ?? '') ?: null,
            'message_sid'         => self::stringValue($status['id'] ?? ''),
            'delivery_status'     => self::stringValue($status['status'] ?? ''),
            'recipient_id'        => self::normalizeMetaPhone($status['recipient_id'] ?? ''),
            'timestamp'           => self::stringValue($status['timestamp'] ?? ''),
            'conversation'        => isset($status['conversation']) && is_array($status['conversation']) ? $status['conversation'] : [],
            'pricing'             => isset($status['pricing']) && is_array($status['pricing']) ? $status['pricing'] : [],
            'errors'              => isset($status['errors']) && is_array($status['errors']) ? $status['errors'] : [],
            'metadata'            => $metadata,
            'waba_id'             => self::stringValue($entry['id'] ?? ''),
            'field'               => self::stringValue($change['field'] ?? ''),
        ];
    }

    protected static function normalizeMetaMessage(array $message, array $metadata, array $contactMap, array $entry, array $change): array
    {
        $type    = self::stringValue($message['type'] ?? 'unknown');
        $fromRaw = self::stringValue($message['from'] ?? '');
        $waId    = self::stringValue($contactMap[$fromRaw]['wa_id'] ?? $fromRaw);

        $event = [
            'provider'            => 'meta_cloud',
            'provider_message_id' => self::stringValue($message['id'] ?? '') ?: null,
            'message_sid'         => self::stringValue($message['id'] ?? ''),
            'from'                => self::normalizeMetaPhone($fromRaw),
            'to'                  => self::normalizeMetaPhone($metadata['display_phone_number'] ?? ''),
            'body'                => '',
            'message_type'        => $type,
            'profile_name'        => self::stringValue($contactMap[$fromRaw]['profile_name'] ?? ''),
            'wa_id'               => $waId,
            'timestamp'           => self::stringValue($message['timestamp'] ?? ''),
            'metadata'            => $metadata,
            'waba_id'             => self::stringValue($entry['id'] ?? ''),
            'field'               => self::stringValue($change['field'] ?? ''),
            'media'               => [],
            'reply_to'            => self::normalizeMetaContext($message['context'] ?? []),
            'referral'            => isset($message['referral']) && is_array($message['referral']) ? $message['referral'] : [],
            'errors'              => isset($message['errors']) && is_array($message['errors']) ? $message['errors'] : [],
        ];

        switch ($type) {
            case 'text':
                $event['body'] = self::stringValue($message['text']['body'] ?? '');
                break;

            case 'image':
            case 'audio':
            case 'video':
            case 'document':
            case 'sticker':
                $media = isset($message[$type]) && is_array($message[$type]) ? $message[$type] : [];
                $event['media'][] = self::normalizeMetaMedia($type, $media);
                $event['body']    = self::metaMediaBody($type, $media);
                break;

            case 'button':
                $button = isset($message['button']) && is_array($message['button']) ? $message['button'] : [];
                $event['button'] = $button;
                $event['body']   = self::stringValue($button['text'] ?? $button['payload'] ?? '');
                break;

            case 'interactive':
                $interactive = isset($message['interactive']) && is_array($message['interactive']) ? $message['interactive'] : [];
                $event['interactive'] = $interactive;
                $event['body']        = self::metaInteractiveBody($interactive);
                break;

            case 'location':
                $location = isset($message['location']) && is_array($message['location']) ? $message['location'] : [];
                $event['location'] = $location;
                $event['body']     = self::metaLocationBody($location);
                break;

            case 'contacts':
                $contacts = isset($message['contacts']) && is_array($message['contacts']) ? $message['contacts'] : [];
                $event['contacts'] = $contacts;
                $event['body']     = sprintf('%d contact(s)', count($contacts));
                break;

            case 'reaction':
                $reaction = isset($message['reaction']) && is_array($message['reaction']) ? $message['reaction'] : [];
                $event['reaction'] = $reaction;
                $event['body']     = self::stringValue($reaction['emoji'] ?? '') ?: 'reaction message';
                break;

            case 'order':
                $order = isset($message['order']) && is_array($message['order']) ? $message['order'] : [];
                $event['order'] = $order;
                $event['body']  = self::metaOrderBody($order);
                break;

            case 'system':
                $system = isset($message['system']) && is_array($message['system']) ? $message['system'] : [];
                $event['system'] = $system;
                $event['body']   = self::stringValue($system['body'] ?? $system['type'] ?? 'system');
                break;

            case 'unsupported':
                // Body left empty so handleMetaWebhook() drops it; Meta sends these stubs (error 131051) with albums.
                break;

            default:
                $event['body'] = self::stringValue($message[$type]['body'] ?? $type);
                $event['payload'] = $message[$type] ?? [];
                break;
        }

        return $event;
    }

    protected static function metaContactMap(array $contacts): array
    {
        $map = [];

        foreach ($contacts as $contact) {
            if (!is_array($contact)) {
                continue;
            }

            $waId = self::stringValue($contact['wa_id'] ?? '');
            if (!$waId) {
                continue;
            }

            $map[$waId] = [
                'wa_id'        => $waId,
                'profile_name' => self::stringValue($contact['profile']['name'] ?? ''),
            ];
        }

        return $map;
    }

    protected static function normalizeMetaContext($context): array
    {
        if (!is_array($context)) {
            return [];
        }

        return array_filter([
            'message_sid' => self::stringValue($context['id'] ?? ''),
            'sender'      => self::normalizeMetaPhone($context['from'] ?? ''),
            'forwarded'   => isset($context['forwarded']) ? (bool) $context['forwarded'] : null,
            'referred_product' => isset($context['referred_product']) && is_array($context['referred_product'])
                ? $context['referred_product']
                : [],
        ], function ($value) {
            return $value !== '' && $value !== [] && $value !== null;
        });
    }

    protected static function normalizeMetaMedia(string $type, array $media): array
    {
        return array_filter([
            'type'         => $type,
            'id'           => self::stringValue($media['id'] ?? ''),
            // Short-lived download link; MediaStore replaces it with the local URL.
            'url'          => self::stringValue($media['url'] ?? ''),
            'mime_type'    => self::stringValue($media['mime_type'] ?? ''),
            'content_type' => self::stringValue($media['mime_type'] ?? ''),
            'sha256'       => self::stringValue($media['sha256'] ?? ''),
            'caption'      => self::stringValue($media['caption'] ?? ''),
            'filename'     => self::stringValue($media['filename'] ?? ''),
            'animated'     => isset($media['animated']) ? (bool) $media['animated'] : null,
        ], function ($value) {
            return $value !== '' && $value !== null;
        });
    }

    protected static function metaMediaBody(string $type, array $media): string
    {
        $body = self::stringValue($media['caption'] ?? '');
        if ($body) {
            return $body;
        }

        $filename = self::stringValue($media['filename'] ?? '');
        if ($filename) {
            return $filename;
        }

        return $type . ' message';
    }

    protected static function metaInteractiveBody(array $interactive): string
    {
        $interactiveType = self::stringValue($interactive['type'] ?? '');

        if ($interactiveType === 'button_reply') {
            return self::stringValue($interactive['button_reply']['title'] ?? $interactive['button_reply']['id'] ?? '');
        }

        if ($interactiveType === 'list_reply') {
            return self::stringValue($interactive['list_reply']['title'] ?? $interactive['list_reply']['id'] ?? '');
        }

        return $interactiveType ?: 'interactive message';
    }

    protected static function metaLocationBody(array $location): string
    {
        $name = self::stringValue($location['name'] ?? '');
        if ($name) {
            return $name;
        }

        $address = self::stringValue($location['address'] ?? '');
        if ($address) {
            return $address;
        }

        $lat = self::stringValue($location['latitude'] ?? '');
        $lng = self::stringValue($location['longitude'] ?? '');

        return trim($lat . ', ' . $lng, ', ');
    }

    protected static function metaOrderBody(array $order): string
    {
        $catalogId = self::stringValue($order['catalog_id'] ?? '');
        $itemCount = isset($order['product_items']) && is_array($order['product_items'])
            ? count($order['product_items'])
            : 0;

        if ($catalogId || $itemCount) {
            return trim(sprintf('Order %s %d item(s)', $catalogId, $itemCount));
        }

        return 'order message';
    }

    protected static function normalizeMetaPhone($phone): string
    {
        if (is_array($phone) || is_object($phone)) {
            return '';
        }

        $phone = preg_replace('/\D+/', '', (string) $phone);

        return $phone ? '+' . $phone : '';
    }

    protected static function decodeTwilioChannelMetadata($metadata): array
    {
        if (!is_string($metadata) || trim($metadata) === '') {
            return [];
        }

        $decoded = json_decode($metadata, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            return [];
        }

        return $decoded;
    }

    protected static function extractTwilioMedia(array $bodyData): array
    {
        $media = [];
        $count = max(0, (int) ($bodyData['NumMedia'] ?? 0));

        for ($i = 0; $i < $count; $i++) {
            $urlKey  = 'MediaUrl' . $i;
            $typeKey = 'MediaContentType' . $i;

            if (empty($bodyData[$urlKey]) || is_array($bodyData[$urlKey])) {
                continue;
            }

            $media[] = [
                'index'        => $i,
                'url'          => (string) $bodyData[$urlKey],
                'content_type' => empty($bodyData[$typeKey]) || is_array($bodyData[$typeKey]) ? '' : (string) $bodyData[$typeKey],
            ];
        }

        return $media;
    }

    protected static function normalizeTwilioAddress($address): string
    {
        if (is_array($address) || is_object($address)) {
            return '';
        }

        $address = trim((string) $address);
        $address = preg_replace('/^whatsapp:/i', '', $address);

        if ($address !== '' && $address[0] !== '+' && preg_match('/^\d+$/', $address)) {
            $address = '+' . $address;
        }

        return $address;
    }

    protected static function firstNonEmpty(array $data, array $keys): string
    {
        foreach ($keys as $key) {
            if (!empty($data[$key]) && !is_array($data[$key]) && !is_object($data[$key])) {
                return trim((string) $data[$key]);
            }
        }

        return '';
    }

    protected static function stringValue($value): string
    {
        if (is_array($value) || is_object($value)) {
            return '';
        }

        return trim((string) $value);
    }

    protected static function twilioBoolean($value)
    {
        if ($value === '' || $value === null || is_array($value) || is_object($value)) {
            return null;
        }

        $value = strtolower(trim((string) $value));

        if ($value === 'true' || $value === '1') {
            return true;
        }

        if ($value === 'false' || $value === '0') {
            return false;
        }

        return null;
    }
}
