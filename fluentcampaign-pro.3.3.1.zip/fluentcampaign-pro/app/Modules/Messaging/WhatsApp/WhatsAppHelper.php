<?php

namespace FluentCampaign\App\Modules\Messaging\WhatsApp;

use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\WhatsAppDriverManager;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Services\Libs\Parser\Parser;
use FluentCrm\Framework\Support\Arr;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;

class WhatsAppHelper
{
    const WHATSAPP_WEBHOOK_KEY_OPTION = '_fc_whatsapp_webhook_key';

    // Intents returned by detectKeywordIntent().
    const INTENT_OPT_OUT = 'opt_out';
    const INTENT_OPT_IN  = 'opt_in';

    /**
     * Per-request memo of getSettings(); cleared by clearSettingsCache() when settings are saved.
     */
    protected static $settingsCache = null;

    public static function clearSettingsCache(): void
    {
        self::$settingsCache = null;
    }

    public static function getSettings(): array
    {
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        $settings = [];

        $settings['enabled']           = fluentcrm_get_option('_fc_whatsapp_enable', 'no');
        $settings['whatsapp_provider'] = fluentcrm_get_option('_fc_whatsapp_provider', '');

        $providerApiOptions = self::getApiOptions();

        // Do not memoize before drivers are registered.
        if (empty($providerApiOptions['providers'])) {
            return $settings;
        }

        foreach ($providerApiOptions['providers'] as $providerName => $options) {
            $current = fluentcrm_get_option("_fc_whatsapp_{$providerName}_settings", []);
            if (is_array($current) && !empty($current)) {
                $settings[$providerName] = $current;
            } else {
                foreach ($options['fields'] as $key => $value) {
                    $settings[$providerName][$key] = $value['default'] ?? '';
                }
            }
        }

        self::$settingsCache = $settings;

        return $settings;
    }

    public static function isActive(): bool
    {
        if (!MessageModule::isEnabled()) {
            return false;
        }

        $settings = self::getSettings();
        return !empty($settings['enabled']) && $settings['enabled'] === 'yes';
    }

    public static function applyRecipientSmartCodes($content, $message): string
    {
        $recipient = self::oneTimeRecipientContext($message);
        if (!$recipient) {
            return (string) $content;
        }

        return strtr((string) $content, [
            '{{recipient.full_name}}'      => (string) Arr::get($recipient, 'full_name', ''),
            '{{ recipient.full_name }}'    => (string) Arr::get($recipient, 'full_name', ''),
            '{{recipient.phone_number}}'   => (string) Arr::get($recipient, 'phone_number', ''),
            '{{ recipient.phone_number }}' => (string) Arr::get($recipient, 'phone_number', '')
        ]);
    }

    public static function stripUnresolvedSmartCodes($content): string
    {
        return trim(preg_replace('/({{|##)\s*[^}#]+?\s*(}}|##)/', '', (string) $content));
    }

    public static function oneTimeRecipientContext($message): array
    {
        if (is_object($message) && method_exists($message, 'oneTimeRecipientContext')) {
            return $message->oneTimeRecipientContext();
        }

        $meta = is_object($message) && is_array($message->meta) ? $message->meta : [];
        $recipient = Arr::get($meta, 'one_time_recipient', []);

        return is_array($recipient) ? $recipient : [];
    }

    public static function getCurrentProvider(): string
    {
        return (string) (self::getSettings()['whatsapp_provider'] ?? '');
    }

    public static function getAllowedProviders(): array
    {
        return WhatsAppDriverManager::getSlugs();
    }

    public static function getProviderSettings(string $provider): array
    {
        $all = self::getSettings();
        return $all[$provider] ?? [];
    }

    public static function getApiOptions(): array
    {
        $providerDefinitions = [];
        foreach (WhatsAppDriverManager::getAll() as $slug => $driver) {
            $providerDefinitions[$slug] = [
                'label'  => $driver->getLabel(),
                'fields' => $driver->getFields(),
            ];
        }

        $providerOptions = [];
        foreach ($providerDefinitions as $key => $def) {
            $providerOptions[$key] = $def['label'] ?? ucfirst(str_replace('_', ' ', $key));
        }

        $providerSelect = [
            'type'    => 'select',
            'label'   => __('WhatsApp Provider', 'fluentcampaign-pro'),
            'options' => $providerOptions,
            'default' => array_key_first($providerOptions) ?: '',
        ];

        return [
            'whatsapp_providers' => $providerSelect,
            'providers'          => $providerDefinitions,
        ];
    }

    public static function getWhatsAppWebhookUrl(string $provider, bool $create = false): string
    {
        if (!$provider) {
            return '';
        }

        $key = fluentcrm_get_option(self::WHATSAPP_WEBHOOK_KEY_OPTION, '');
        if (!$key && $create) {
            $key = wp_generate_uuid4();
            fluentcrm_update_option(self::WHATSAPP_WEBHOOK_KEY_OPTION, $key);
        }

        return $key && is_string($key) ? add_query_arg([
            FLUENTCRM_EXTERNAL_URL_PARAM => '1',
            'route'                      => 'webhook',
            'handler'                    => 'whatsapp',
            'provider'                   => $provider,
            'hash'                       => $key,
        ], site_url('/')) : '';
    }

    public static function verifyWebhookHash(string $hash, string $provider): bool
    {
        if (!$hash || !is_string($hash) || strlen($hash) < 16 || !$provider) {
            return false;
        }

        $hashInDb = fluentcrm_get_option(self::WHATSAPP_WEBHOOK_KEY_OPTION, '');

        if (!$hashInDb || !is_string($hashInDb)) {
            return false;
        }

        return hash_equals($hashInDb, $hash);
    }

    public static function verifyTwilioSignature(string $authToken, array $postData = []): bool
    {
        $signature = isset($_SERVER['HTTP_X_TWILIO_SIGNATURE'])
            ? sanitize_text_field(wp_unslash($_SERVER['HTTP_X_TWILIO_SIGNATURE']))
            : '';

        // Fail closed without an auth token and signature; the URL hash alone is not enough.
        if (!$authToken || !$signature) {
            return false;
        }

        $url = self::getCurrentRequestUrl();
        if (!$url) {
            return false;
        }

        $postData = wp_unslash($postData);
        ksort($postData);

        $data = $url;
        foreach ($postData as $key => $value) {
            if (is_array($value) || is_object($value)) {
                continue;
            }
            $data .= $key . (string) $value;
        }

        $expected = base64_encode(hash_hmac('sha1', $data, $authToken, true));

        return hash_equals($expected, $signature);
    }

    /**
     * Verify Meta's raw-body HMAC signature. Accepts `sha256=` or legacy `sha1=`, by prefix.
     */
    public static function verifyMetaSignature(string $appSecret, string $rawBody, string $signature): bool
    {
        if (!$appSecret || !$rawBody || !$signature) {
            return false;
        }

        if (strpos($signature, 'sha256=') === 0) {
            $algo = 'sha256';
        } elseif (strpos($signature, 'sha1=') === 0) {
            $algo = 'sha1';
        } else {
            return false;
        }

        $expected = $algo . '=' . hash_hmac($algo, $rawBody, $appSecret);

        return hash_equals($expected, $signature);
    }

    protected static function getCurrentRequestUrl(): string
    {
        // Twilio signs the exact URL; sanitizing would break the HMAC, so only unslash.
        $host = isset($_SERVER['HTTP_HOST']) ? wp_unslash($_SERVER['HTTP_HOST']) : '';
        $uri  = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';

        if (!$host || !$uri) {
            return '';
        }

        // Honor X-Forwarded-Proto behind a TLS-terminating proxy.
        $forwardedProto = isset($_SERVER['HTTP_X_FORWARDED_PROTO'])
            ? strtolower(trim(explode(',', wp_unslash($_SERVER['HTTP_X_FORWARDED_PROTO']))[0]))
            : '';

        if ($forwardedProto === 'https' || $forwardedProto === 'http') {
            $scheme = $forwardedProto;
        } else {
            $scheme = is_ssl() ? 'https' : 'http';
        }

        return $scheme . '://' . $host . $uri;
    }

    /**
     * Turn a stored site-local 'Y-m-d H:i:s' (or DateTime) into an offset-qualified ISO 8601 string.
     */
    public static function toIso($value): ?string
    {
        if (!$value) {
            return null;
        }

        if ($value instanceof \DateTimeInterface) {
            return $value->format('c');
        }

        if (!is_string($value)) {
            return null;
        }

        $date = date_create_immutable($value, wp_timezone());

        return $date ? $date->format('c') : null;
    }

    /**
     * Find the contact for a provider E.164 number, tolerating formatted stored phones.
     * Exact match first, then a full digits-only comparison over a last-four-digits prefilter.
     */
    public static function findSubscriberByPhone(string $phone): ?Subscriber
    {
        // Shared with SMS: exact match first, then by digits.
        return \FluentCampaign\App\Modules\Messaging\Services\PhoneMatcher::findContact($phone);
    }

    /**
     * Keywords that unsubscribe a contact from WhatsApp, matched by detectKeywordIntent().
     */
    public static function getOptOutKeywords(): array
    {
        return (array) apply_filters('fluent_crm/whatsapp_opt_out_keywords', [
            'stop',
            'stopall',
            'unsubscribe',
            'quit',
            'cancel',
            'end',
            'revoke',
            'opt out',
            'optout',
        ]);
    }

    /**
     * Keywords that (re)subscribe a contact to WhatsApp.
     */
    public static function getOptInKeywords(): array
    {
        return (array) apply_filters('fluent_crm/whatsapp_opt_in_keywords', [
            'start',
            'unstop',
            'subscribe',
            'resubscribe',
            'resume',
            'opt in',
            'optin',
        ]);
    }

    /**
     * Words stripped before a message is compared against the keyword lists.
     */
    public static function getKeywordFillerWords(): array
    {
        return (array) apply_filters('fluent_crm/whatsapp_keyword_filler_words', [
            'please', 'pls', 'plz', 'now', 'again', 'me', 'my', 'all', 'the',
            'this', 'to', 'from', 'i', 'want', 'sending', 'send', 'message',
            'messages', 'msg', 'msgs', 'update', 'updates', 'sms', 'whatsapp',
            'texts', 'text', 'thanks', 'thank', 'you', 'immediately', 'everything',
        ]);
    }

    /**
     * Resolve the opt-in/opt-out intent of an inbound message.
     * After lowercasing and removing punctuation and filler words, the rest must equal a keyword.
     *
     * @return string self::INTENT_OPT_OUT, self::INTENT_OPT_IN, or '' for no match.
     */
    public static function detectKeywordIntent(string $body): string
    {
        $normalized = strtolower(trim($body));
        $normalized = preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $normalized);
        $normalized = trim((string) preg_replace('/\s+/u', ' ', (string) $normalized));

        if ($normalized === '') {
            return '';
        }

        $words = explode(' ', $normalized);

        // Messages over six words are never treated as commands.
        if (count($words) > 6) {
            return '';
        }

        $filler = array_map('strtolower', self::getKeywordFillerWords());
        $core   = implode(' ', array_values(array_diff($words, $filler)));

        if ($core === '') {
            return '';
        }

        $sets = [
            self::INTENT_OPT_OUT => self::getOptOutKeywords(),
            self::INTENT_OPT_IN  => self::getOptInKeywords(),
        ];

        foreach ($sets as $intent => $keywords) {
            foreach ($keywords as $keyword) {
                if ($core === strtolower(trim((string) $keyword))) {
                    return $intent;
                }
            }
        }

        return '';
    }

    /**
     * The reply sent back after a keyword opt-out.
     */
    public static function getOptOutConfirmationMessage(): string
    {
        return (string) apply_filters(
            'fluent_crm/whatsapp_opt_out_confirmation_message',
            __('You have been unsubscribed. Reply START to receive updates again.', 'fluentcampaign-pro')
        );
    }

    /**
     * Send the opt-out confirmation directly; the scheduler would refuse an unsubscribed contact.
     */
    protected static function sendOptOutConfirmation($subscriber, string $phone, array $data = []): void
    {
        if (!apply_filters('fluent_crm/whatsapp_send_opt_out_confirmation', true, $subscriber, $data)) {
            return;
        }

        $message = trim(self::getOptOutConfirmationMessage());

        if (!$message || !self::isActive()) {
            return;
        }

        // Reply to the sending number, not the stored phone, which may be formatted differently.
        $result    = WhatsAppSender::send($phone, $message);
        $succeeded = ($result['status'] ?? '') === 'success';

        \FluentCampaign\App\Modules\Messaging\Models\MessageThread::recordOutbound(
            'whatsapp',
            $phone,
            $subscriber->id,
            $message,
            $result,
            ['ref_type' => 'opt-out-reply']
        );
    }

    public static function optOut(string $phone, array $data = []): bool
    {
        if (!$phone) {
            return false;
        }

        $subscriber = self::findSubscriberByPhone($phone);
        $changed = !$subscriber || MessageThread::contactStatus('whatsapp', $subscriber->id) !== MessageThread::STATUS_UNSUBSCRIBED;

        if (!MessageThread::setConsent('whatsapp', $phone, MessageThread::STATUS_UNSUBSCRIBED, $subscriber ? $subscriber->id : null)) {
            return false;
        }

        // Consent is stored for unknown numbers too; hooks and confirmation need a contact.
        // A repeated STOP or a provider retry changes nothing, so it fires and sends nothing again.
        if ($subscriber && $changed) {
            do_action('fluent_crm/contact_whatsapp_unsubscribed', $subscriber, $data);

            self::sendOptOutConfirmation($subscriber, $phone, $data);
        }

        return true;
    }

    public static function optIn(string $phone, array $data = []): bool
    {
        if (!$phone) {
            return false;
        }

        $subscriber = self::findSubscriberByPhone($phone);
        $changed = !$subscriber || MessageThread::contactStatus('whatsapp', $subscriber->id) !== MessageThread::STATUS_SUBSCRIBED;

        if (!MessageThread::setConsent('whatsapp', $phone, MessageThread::STATUS_SUBSCRIBED, $subscriber ? $subscriber->id : null)) {
            return false;
        }

        if ($subscriber && $changed) {
            do_action('fluent_crm/contact_whatsapp_subscribed', $subscriber, $data);
        }

        return true;
    }

    public static function processIncomingMessage(string $from, string $to, string $body, array $data = []): bool
    {
        $media = isset($data['media']) && is_array($data['media']) ? $data['media'] : [];

        if (!$from || ($body === '' && empty($media))) {
            return false;
        }

        // May be null; messages from unknown numbers are still stored.
        $subscriber = self::findSubscriberByPhone($from);

        $providerMessageId = $data['provider_message_id']
            ?? $data['message_sid']
            ?? $data['MessageSid']
            ?? $data['SmsMessageSid']
            ?? $data['SmsSid']
            ?? '';

        // Dedupe provider webhook retries before writing anything.
        if ($providerMessageId) {
            $existing = Message::with(['thread'])
                ->where('provider_message_id', $providerMessageId)
                ->whereHas('thread', function ($query) {
                    $query->where('channel', 'whatsapp');
                })
                ->first();

            if ($existing) {
                if ($existing->thread) {
                    self::rememberSenderProfile($existing->thread, $data);
                }

                return true;
            }
        }

        // Provider media links expire within minutes, so download now.
        if ($media) {
            $data['media'] = MediaStore::ingest($media, (string) ($data['provider'] ?? ''));
        }

        $thread = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::findOrCreateFor('whatsapp', $from, [
            'contact_id'   => $subscriber ? $subscriber->id : null,
            'initiated_by' => 'user'
        ]);

        if (!$thread) {
            return false;
        }

        self::rememberSenderProfile($thread, $data);

        $meta = ['settings' => self::formatIncomingMessageSettings($from, $to, $data)];

        if (!empty($data['media'])) {
            $meta['attachments'] = $data['media'];
        }

        $record = $thread->recordMessage([
            'direction'           => 'inbound',
            'content'             => $body,
            'provider_message_id' => $providerMessageId ?: null,
            'ref_type'            => 'incoming',
            'status'              => 'received',
            'meta'                => $meta
        ]);

        // This message reopens the 24-hour window; clear the memoized lookup.
        SessionWindow::forget($thread->id);

        /**
         * A WhatsApp message was received.
         *
         * The messaging module ships no inbound trigger — WhatsApp and SMS
         * expose actions only — so this is purely an extension point for
         * third-party code that wants to react to inbound messages.
         *
         * @param Message         $record     The stored inbound message
         * @param Subscriber|null $subscriber The contact who sent it, or null
         *                                    when the number is not in the CRM.
         *                                    Listeners must handle null — an
         *                                    unknown sender is the common case
         *                                    for a first contact.
         * @param array           $data       Raw provider payload
         */
        do_action('fluent_crm/whatsapp_message_received', $record, $subscriber, $data);

        return true;
    }

    /**
     * Store the sender's profile name and wa_id on the thread meta for the Inbox rail.
     */
    protected static function rememberSenderProfile(MessageThread $thread, array $data): void
    {
        $profileName = !empty($data['profile_name']) ? sanitize_text_field($data['profile_name']) : '';
        $waId = !empty($data['wa_id']) ? sanitize_text_field($data['wa_id']) : '';

        if ($profileName === '' && $waId === '') {
            return;
        }

        $meta = $thread->meta;
        $changed = false;

        if ($profileName !== '' && ($meta['profile_name'] ?? '') !== $profileName) {
            $meta['profile_name'] = $profileName;
            $changed = true;
        }

        if ($waId !== '' && ($meta['wa_id'] ?? '') !== $waId) {
            $meta['wa_id'] = $waId;
            $changed = true;
        }

        if (!$changed) {
            return;
        }

        $thread->meta = $meta;

        MessageThread::withoutTimestamps(function () use ($thread) {
            $thread->save();
        });
    }

    protected static function formatIncomingMessageSettings(string $from, string $to, array $data): array
    {
        return array_filter([
            'from'                   => $from,
            'to'                     => $to,
            'provider'               => $data['provider'] ?? 'unknown',
            'profile_name'           => $data['profile_name'] ?? '',
            'wa_id'                  => $data['wa_id'] ?? '',
            'message_type'           => $data['message_type'] ?? '',
            'sms_status'             => $data['sms_status'] ?? '',
            'delivery_status'        => $data['delivery_status'] ?? '',
            'account_sid'            => $data['account_sid'] ?? '',
            'external_user_id'       => $data['external_user_id'] ?? '',
            'timestamp'              => $data['timestamp'] ?? '',
            'metadata'               => isset($data['metadata']) && is_array($data['metadata']) ? $data['metadata'] : [],
            'waba_id'                => $data['waba_id'] ?? '',
            'field'                  => $data['field'] ?? '',
            'num_segments'           => $data['num_segments'] ?? null,
            'num_media'              => $data['num_media'] ?? null,
            'media'                  => isset($data['media']) && is_array($data['media']) ? $data['media'] : [],
            'reply_to'               => isset($data['reply_to']) && is_array($data['reply_to']) ? $data['reply_to'] : [],
            'referral'               => isset($data['referral']) && is_array($data['referral']) ? $data['referral'] : [],
            'button'                 => isset($data['button']) && is_array($data['button']) ? $data['button'] : [],
            'interactive'            => isset($data['interactive']) && is_array($data['interactive']) ? $data['interactive'] : [],
            'location'               => isset($data['location']) && is_array($data['location']) ? $data['location'] : [],
            'contacts'               => isset($data['contacts']) && is_array($data['contacts']) ? $data['contacts'] : [],
            'reaction'               => isset($data['reaction']) && is_array($data['reaction']) ? $data['reaction'] : [],
            'order'                  => isset($data['order']) && is_array($data['order']) ? $data['order'] : [],
            'system'                 => isset($data['system']) && is_array($data['system']) ? $data['system'] : [],
            'errors'                 => isset($data['errors']) && is_array($data['errors']) ? $data['errors'] : [],
            'forwarded'              => $data['forwarded'] ?? null,
            'frequently_forwarded'   => $data['frequently_forwarded'] ?? null,
            'channel_metadata'       => isset($data['channel_metadata']) && is_array($data['channel_metadata']) ? $data['channel_metadata'] : [],
            'raw_provider_event_ids' => array_filter([
                'message_sid'     => $data['message_sid'] ?? '',
                'sms_sid'         => $data['sms_sid'] ?? '',
                'sms_message_sid' => $data['sms_message_sid'] ?? '',
            ]),
        ], function ($value) {
            return $value !== '' && $value !== [] && $value !== null;
        });
    }

    /**
     * Parse message content with subscriber smartcodes for WhatsApp delivery.
     * Delegates to the shared Parser then strips HTML for plain-text output.
     */
    public static function parseMessageContent(string $content, $subscriber): string
    {
        $content = Parser::parse($content, $subscriber);
        $content = apply_filters('fluent_crm/parse_whatsapp_smartcode', $content, $subscriber);

        return self::sanitizeParsedMessageContent($content);
    }

    protected static function sanitizeParsedMessageContent(string $content): string
    {
        $content = preg_replace_callback(
            '/<a[^>]*href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/is',
            function ($matches) {
                $url   = trim($matches[1]);
                $label = trim(wp_strip_all_tags($matches[2]));
                return ($label === '' || $label === $url) ? $url : $label . ' (' . $url . ')';
            },
            $content
        );

        $content = preg_replace('/<\s*br\s*\/?>/i', "\n", $content);
        $content = preg_replace('/<\/(p|div|li|h[1-6]|tr)>/i', "\n", $content);
        $content = wp_strip_all_tags($content);
        $content = html_entity_decode($content, ENT_QUOTES, 'UTF-8');
        $content = preg_replace('/({{|##).*?(}}|##)/', '', $content);
        $content = preg_replace('/[ \t\x{00A0}]+/u', ' ', $content);
        $content = preg_replace("/[ \t]*\n[ \t]*/", "\n", $content);
        $content = preg_replace("/\n{3,}/", "\n\n", $content);

        return trim($content);
    }
}
