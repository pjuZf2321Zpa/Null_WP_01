<?php

namespace FluentCampaign\App\Modules\Messaging\Contracts;

/**
 * Drivers whose provider has an approval-based template catalogue.
 * Methods return ['status' => 'success'|'error', 'message' => string, 'data' => mixed] and never throw.
 *
 * @see \FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\MetaCloudDriver
 */
interface TemplateApiInterface
{
    /**
     * Fetch the provider's full template catalogue as provider-shaped rows under `data`.
     *
     * @param array $settings Saved provider settings
     */
    public function fetchTemplates(array $settings): array;

    /**
     * Look up one template's current approval state.
     *
     * @param array $settings Saved provider settings
     */
    public function fetchTemplateStatus(string $name, array $settings): array;

    /**
     * Submit a new template for approval.
     *
     * @param array $template name, language, category, header, body, footer,
     *                        buttons[], variables[] with sample values
     * @param array $settings Saved provider settings
     */
    public function submitTemplate(array $template, array $settings): array;

    /**
     * Remove a template from the provider.
     *
     * @param array $settings Saved provider settings
     */
    public function deleteTemplate(string $name, array $settings, string $providerTemplateId = '', string $language = ''): array;

    /**
     * Send an approved template message; works outside the 24-hour window.
     *
     * @param string $to         E.164 phone number
     * @param array  $components Provider-shaped component array with resolved
     *                           variable values
     * @param array  $settings   Saved provider settings
     */
    public function sendTemplate(string $to, string $templateName, string $language, array $components, array $settings, string $providerTemplateId = ''): array;
}
