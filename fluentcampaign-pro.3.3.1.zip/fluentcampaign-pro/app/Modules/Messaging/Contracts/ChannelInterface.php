<?php

namespace FluentCampaign\App\Modules\Messaging\Contracts;

/**
 * A messaging channel (SMS, WhatsApp): renders and sends messages. Consent lives on MessageThread, not here.
 * Channels always exist in MessageModule::channels(); gate behaviour on isActive().
 *
 * @see \FluentCampaign\App\Modules\Messaging\MessageModule::channel()
 */
interface ChannelInterface
{
    /**
     * Stable slug stored in the `channel` column, e.g. 'sms', 'whatsapp'.
     */
    public function getSlug(): string;

    /**
     * Human-readable name for UI labels, logs and failure notes.
     */
    public function getLabel(): string;

    /**
     * Whether the channel is configured and switched on.
     */
    public function isActive(): bool;

    /**
     * Maximum body length the channel accepts, in characters.
     */
    public function getMaxLength(): int;

    /**
     * Render a stored message body for one subscriber, resolving smartcodes.
     *
     * @param string $content    Raw body as stored on the campaign or message
     * @param object $subscriber FluentCrm\App\Models\Subscriber
     */
    public function parseMessageContent(string $content, $subscriber): string;

    /**
     * Dispatch a message through this channel's configured provider.
     *
     * @param string      $to       E.164 formatted phone number
     * @param string      $message  Rendered body
     * @param string|null $provider Provider slug; null uses the configured one
     *
     * @return array {status: 'success'|'error', status_code: int,
     *                message: string, response: mixed,
     *                provider_message_id?: string}
     */
    public function send(string $to, string $message, ?string $provider = null): array;

    /**
     * Send one queued fc_messages row, choosing the message form. Must return an error shape, not throw.
     *
     * @param object $message    fc_messages row (Message model), thread loaded
     * @param object $subscriber \FluentCrm\App\Models\Subscriber
     * @param string $to         Resolved destination phone number
     *
     * @return array {status: 'success'|'error', status_code: int,
     *                message: string, response: mixed,
     *                provider_message_id?: string}
     */
    public function sendQueued($message, $subscriber, string $to): array;

    /**
     * Admin menu entries for fluent_crm/core_menu_items. Only called for active channels.
     *
     * @param string $urlBase Admin URL prefix, e.g. ".../admin.php?page=fluentcrm-admin#/"
     * @return array<int, array<string, string>>
     */
    public function getMenuItems(string $urlBase): array;

    /**
     * Channel-specific hooks after a successful send; the scheduler fires fluent_crm/{channel}_sent.
     *
     * @param object $message fc_messages row (Message model)
     */
    public function onSent($message, array $result): void;

    /**
     * Channel-specific hooks after a failed send.
     *
     * @param object $message fc_messages row (Message model)
     */
    public function onFailed($message, string $error): void;
}
