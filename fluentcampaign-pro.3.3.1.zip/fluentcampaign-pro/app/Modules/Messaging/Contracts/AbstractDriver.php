<?php

namespace FluentCampaign\App\Modules\Messaging\Contracts;

/**
 * Base for every provider driver. Third-party drivers extend AbstractSMSDriver or AbstractWhatsAppDriver instead.
 */
abstract class AbstractDriver
{
    /**
     * Unique provider slug, also the settings option key prefix, e.g. 'twilio', 'meta_cloud'.
     */
    abstract public function getSlug(): string;

    /**
     * Label shown in the Settings provider dropdown.
     */
    abstract public function getLabel(): string;

    /**
     * Settings fields keyed by slug; each has type (text|password|select|checkbox), label, sub_label, required, default, options.
     */
    abstract public function getFields(): array;

    /**
     * Send a message.
     *
     * @param string $to       E.164 formatted phone number (e.g. +12125551234)
     * @param string $message  Message body text
     * @param array  $settings Saved provider settings for this provider (from DB)
     *
     * @return array {
     *   status: 'success'|'error',
     *   status_code: int,
     *   message: string,
     *   response: mixed,
     *   provider_message_id?: string
     * }
     */
    abstract public function send(string $to, string $message, array $settings): array;

    /**
     * Whether the provider receives inbound messages via webhook (shows a webhook URL in settings).
     */
    public function hasWebhook(): bool
    {
        return false;
    }

    /**
     * Message returned on a successful send.
     */
    protected function getSuccessMessage(): string
    {
        return 'Message sent successfully';
    }

    /**
     * Execute a cURL request with connect/total timeouts and return a normalised response array.
     * The total timeout passes through `fluent_crm/message_send_timeout` (capped by MessageScheduler::dispatch()).
     *
     * @param array $options     cURL option constants → values
     * @param int   $successCode Expected HTTP success code
     * @return array
     */
    protected function executeCurl(array $options, int $successCode = 200): array
    {
        $ch = curl_init();
        $options = $options + [
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 30,
        ];

        $options[CURLOPT_TIMEOUT] = max(1, (int) apply_filters(
            'fluent_crm/message_send_timeout',
            $options[CURLOPT_TIMEOUT],
            $this->getSlug()
        ));

        $options[CURLOPT_CONNECTTIMEOUT] = min(
            $options[CURLOPT_CONNECTTIMEOUT],
            $options[CURLOPT_TIMEOUT]
        );

        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            return [
                'status'      => 'error',
                'status_code' => 0,
                /* translators: %s: technical error returned by the HTTP request */
                'message'     => sprintf(__('The provider request failed: %s', 'fluentcampaign-pro'), $error),
                'response'    => null,
            ];
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== $successCode) {
            return [
                'status'      => 'error',
                'status_code' => $httpCode,
                'message'     => __('The provider returned an unexpected response.', 'fluentcampaign-pro'),
                'response'    => $response,
            ];
        }

        return [
            'status'      => 'success',
            'status_code' => $httpCode,
            'message'     => $this->getSuccessMessage(),
            'response'    => $response,
        ];
    }
}
