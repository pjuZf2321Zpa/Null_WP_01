<?php

namespace FluentCampaign\App\Modules\Messaging;

use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\Services\PhoneMatcher;

class MessageMigrator
{
    /**
     * Option marking the one-time consent backfill as done.
     */
    const CONSENT_BACKFILL_OPTION = '__fluentcrm_messaging_consent_backfilled';

    /**
     * Needs FluentCRM booted: the data steps use its helpers and tables.
     */
    public static function migrate($isForced = false)
    {
        self::migrateTables($isForced);
        self::backfillThreadConsent();
        self::maybeAddPhoneKey();
    }

    /**
     * The schema alone, which needs nothing from FluentCRM.
     */
    public static function migrateTables($isForced = false)
    {
        // Threads first; every message points at one.
        self::migrateMessageThreadsTable();
        self::migrateMessagesTable();
        self::migrateSMSMessagesTable($isForced);
        self::migrateSMSCampaignsTable($isForced);
        self::migrateMessageTemplatesTable($isForced);
    }

    /**
     * One row per conversation: a phone number on a channel.
     */
    public static function migrateMessageThreadsTable()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_message_threads';
        $indexPrefix = $wpdb->prefix . 'fc_mt_';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            // identity_idx keeps one thread per (channel, phone_number) under concurrent webhooks.
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `contact_id` BIGINT UNSIGNED NULL,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'sms',
                `phone_number` VARCHAR(20) NOT NULL,
                `phone_key` VARCHAR(20) NULL,
                `status` VARCHAR(20) NOT NULL DEFAULT 'subscribed',
                `initiated_by` VARCHAR(20) NOT NULL DEFAULT 'user',
                `last_seen_id` BIGINT UNSIGNED NULL,
                `last_message_id` BIGINT UNSIGNED NULL,
                `has_unread` TINYINT(1) NOT NULL DEFAULT 0,
                `unread_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `meta` LONGTEXT NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                UNIQUE KEY `{$indexPrefix}identity_idx` (`channel`, `phone_number`),
                INDEX `{$indexPrefix}contact_idx` (`contact_id`, `channel`),
                INDEX `{$indexPrefix}phone_key_idx` (`channel`, `phone_key`),
                INDEX `{$indexPrefix}rail_idx` (`updated_at`)
            ) $charsetCollate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    /**
     * One row per inbound or outbound message on any channel.
     */
    public static function migrateMessagesTable()
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_messages';
        $indexPrefix = $wpdb->prefix . 'fc_msg_';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            // activity_at stores COALESCE(sent_at, scheduled_at, created_at) for ordering.
            // It must be DATETIME with no nullability clause: MariaDB rejects `STORED NULL`,
            // and a bare TIMESTAMP would be promoted to NOT NULL.
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `thread_id` BIGINT UNSIGNED NOT NULL,
                `direction` VARCHAR(20) NOT NULL DEFAULT 'outbound',
                `content` TEXT NULL,
                `ref_id` BIGINT UNSIGNED NULL,
                `ref_type` VARCHAR(50) NULL,
                `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
                `provider_message_id` VARCHAR(100) NULL,
                `scheduled_at` TIMESTAMP NULL,
                `sent_at` TIMESTAMP NULL,
                `meta` LONGTEXT NULL,
                `created_by` BIGINT UNSIGNED NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                `activity_at` DATETIME GENERATED ALWAYS AS (COALESCE(`sent_at`, `scheduled_at`, `created_at`)) STORED,
                INDEX `{$indexPrefix}thread_idx` (`thread_id`, `id`),
                INDEX `{$indexPrefix}provider_idx` (`provider_message_id`),
                INDEX `{$indexPrefix}status_idx` (`status`, `scheduled_at`),
                INDEX `{$indexPrefix}ref_idx` (`ref_type`, `ref_id`),
                INDEX `{$indexPrefix}queue_idx` (`ref_id`, `id`),
                INDEX `{$indexPrefix}activity_idx` (`activity_at`)
            ) $charsetCollate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    public static function migrateSMSMessagesTable($isForced = false)
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_sms_messages';
        $indexPrefix = $wpdb->prefix . 'fc_sms_msg';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table || $isForced) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `campaign_id` BIGINT UNSIGNED NULL,
                `sms_type` VARCHAR(50) NULL DEFAULT 'campaign',
                `subscriber_id` BIGINT UNSIGNED NULL,
                `mobile_number` VARCHAR(20) NULL,
                `click_counter` INT UNSIGNED NULL DEFAULT 0,
                `message_content` TEXT,
                `status` VARCHAR(50) NOT NULL DEFAULT 'pending',
                `delivery_status` VARCHAR(50) NULL DEFAULT 'queued',
                `notes` TEXT NULL,
                `provider_message_id` VARCHAR(100) NULL,
                `settings` LONGTEXT NULL,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'sms',
                `scheduled_at` TIMESTAMP NULL,
                `sent_at` TIMESTAMP NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                INDEX `{$indexPrefix}_campaign_id_idx` (`campaign_id`),
                INDEX `{$indexPrefix}_status_idx` (`status`),
                INDEX `{$indexPrefix}_scheduled_at_idx` (`scheduled_at`),
                INDEX `{$indexPrefix}_provider_msg_idx` (`provider_message_id`, `channel`)
            ) $charsetCollate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }

        // Add channel column to existing installs
        if ($wpdb->get_var("SHOW COLUMNS FROM `$table` LIKE 'channel'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD `channel` VARCHAR(20) NOT NULL DEFAULT 'sms' AFTER `settings`");
        }

        // Add composite index for webhook provider_message_id lookups if missing
        $indexName = $indexPrefix . '_provider_msg_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$indexName'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD INDEX `$indexName` (`provider_message_id`, `channel`)");
        }

        // Columns added for WhatsApp; template_id references fc_message_templates.
        $newColumns = [
            'direction'    => "ALTER TABLE `$table` ADD `direction` VARCHAR(20) NOT NULL DEFAULT 'outbound' AFTER `channel`",
            'delivered_at' => "ALTER TABLE `$table` ADD `delivered_at` TIMESTAMP NULL AFTER `sent_at`",
            'read_at'      => "ALTER TABLE `$table` ADD `read_at` TIMESTAMP NULL AFTER `delivered_at`",
            'template_id'  => "ALTER TABLE `$table` ADD `template_id` BIGINT UNSIGNED NULL AFTER `campaign_id`",
        ];

        foreach ($newColumns as $column => $sql) {
            if ($wpdb->get_var("SHOW COLUMNS FROM `$table` LIKE '$column'") === null) {
                $wpdb->query($sql);
            }
        }

        // Index for the latest inbound message per contact and channel.
        $oldWindowIndex = $indexPrefix . '_sub_channel_dir_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$oldWindowIndex'") !== null) {
            $wpdb->query("ALTER TABLE `$table` DROP INDEX `$oldWindowIndex`");
        }

        $windowIndex = $indexPrefix . '_session_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$windowIndex'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD INDEX `$windowIndex` (`subscriber_id`, `channel`, `direction`, `created_at`)");
        }
    }

    /**
     * Templates for every messaging channel, discriminated by `channel`.
     */
    public static function migrateMessageTemplatesTable($isForced = false)
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_message_templates';
        $indexPrefix = $wpdb->prefix . 'fc_msg_tpl';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table || $isForced) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'whatsapp',
                `name` VARCHAR(192) NOT NULL,
                `language` VARCHAR(20) NOT NULL DEFAULT 'en_US',
                `category` VARCHAR(50) NULL,
                `status` VARCHAR(20) NOT NULL DEFAULT 'PENDING',
                `header_text` VARCHAR(255) NULL,
                `body_text` TEXT NOT NULL,
                `footer_text` VARCHAR(255) NULL,
                `buttons` LONGTEXT NULL,
                `variables` LONGTEXT NULL,
                `provider` VARCHAR(50) NULL,
                `provider_template_id` VARCHAR(192) NULL,
                `rejection_reason` TEXT NULL,
                `last_synced_at` TIMESTAMP NULL,
                `created_by` BIGINT UNSIGNED NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                UNIQUE INDEX `{$indexPrefix}_identity_idx` (`channel`, `provider`, `name`, `language`),
                INDEX `{$indexPrefix}_channel_status_idx` (`channel`, `status`)
            ) $charsetCollate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }

    public static function migrateSMSCampaignsTable($isForced = false)
    {
        global $wpdb;

        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'fc_sms_campaigns';
        $indexPrefix = $wpdb->prefix . 'fc_sms_camp';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table || $isForced) {
            $sql = "CREATE TABLE $table (
                `id` BIGINT UNSIGNED NOT NULL PRIMARY KEY AUTO_INCREMENT,
                `parent_id` BIGINT UNSIGNED NULL,
                `type` VARCHAR(50) NOT NULL DEFAULT 'campaign',
                `title` VARCHAR(192) NOT NULL,
                `slug` VARCHAR(192) NOT NULL,
                `status` VARCHAR(50) NOT NULL DEFAULT 'draft',
                `message_content` TEXT NOT NULL,
                `sender_number` VARCHAR(20) NULL,
                `recipients_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `sent_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `failed_count` INT UNSIGNED NOT NULL DEFAULT 0,
                `delay` INT UNSIGNED NULL DEFAULT 0,
                `scheduled_at` TIMESTAMP NULL,
                `settings` LONGTEXT NULL,
                `channel` VARCHAR(20) NOT NULL DEFAULT 'sms',
                `created_by` BIGINT UNSIGNED NULL,
                `created_at` TIMESTAMP NULL,
                `updated_at` TIMESTAMP NULL,
                INDEX `{$indexPrefix}_status_idx` (`status`),
                INDEX `{$indexPrefix}_scheduled_at_idx` (`scheduled_at`),
                INDEX `{$indexPrefix}_type_idx` (`type`),
                INDEX `{$indexPrefix}_type_channel_idx` (`type`, `channel`)
            ) $charsetCollate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }

        // Add channel column to existing installs
        if ($wpdb->get_var("SHOW COLUMNS FROM `$table` LIKE 'channel'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD `channel` VARCHAR(20) NOT NULL DEFAULT 'sms' AFTER `settings`");
        }

        // Add composite index for channel-filtered campaign list queries if missing
        $channelIndexName = $indexPrefix . '_type_channel_idx';
        if ($wpdb->get_var("SHOW INDEX FROM `$table` WHERE Key_name = '$channelIndexName'") === null) {
            $wpdb->query("ALTER TABLE `$table` ADD INDEX `$channelIndexName` (`type`, `channel`)");
        }
    }

    /**
     * One-time copy of non-subscribed `fc_subscribers.sms_status` onto SMS threads.
     * WhatsApp is not migrated: its legacy default `whatsapp_unsubscribed` cannot be told from a real opt-out.
     * Contacts without a phone are skipped, since a thread is identified by its number.
     */
    public static function backfillThreadConsent()
    {
        global $wpdb;

        if (fluentcrm_get_option(self::CONSENT_BACKFILL_OPTION) === 'yes') {
            return;
        }

        $subscribers = $wpdb->prefix . 'fc_subscribers';
        $threads = $wpdb->prefix . 'fc_message_threads';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW COLUMNS FROM `$subscribers` LIKE 'sms_status'") === null) {
            fluentcrm_update_option(self::CONSENT_BACKFILL_OPTION, 'yes');
            return;
        }

        // Unrecognised values become unsubscribed, never consent.
        $statusCase = $wpdb->prepare(
            "CASE s.sms_status WHEN 'sms_bounced' THEN %s WHEN 'sms_pending' THEN %s ELSE %s END",
            MessageThread::STATUS_BOUNCED,
            MessageThread::STATUS_PENDING,
            MessageThread::STATUS_UNSUBSCRIBED
        );

        $notSubscribed = "s.phone IS NOT NULL AND s.phone <> '' AND s.sms_status IS NOT NULL AND s.sms_status <> 'sms_subscribed'";

        // Skip numbers longer than phone_number (20); truncation would file consent under another number.
        $insertable = $notSubscribed . " AND CHAR_LENGTH(s.phone) <= 20";

        // Consent-only threads (hidden from the rail), timestamped from the contact so the rail order is kept.
        // Existing threads are left to the UPDATE below.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO `$threads`
                    (`contact_id`,`channel`,`phone_number`,`status`,`initiated_by`,`has_unread`,`unread_count`,`created_at`,`updated_at`)
                 SELECT s.id, 'sms', s.phone, $statusCase, %s, 0, 0,
                        COALESCE(s.created_at, %s), COALESCE(s.created_at, %s)
                 FROM `$subscribers` s
                 WHERE $insertable",
                MessageThread::INITIATED_BY_SYSTEM,
                current_time('mysql'),
                current_time('mysql')
            )
        );

        // Existing subscribed threads take the opt-out; an existing opt-out is never relaxed.
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "UPDATE `$threads` t
             JOIN `$subscribers` s ON s.id = t.contact_id
             SET t.status = $statusCase
             WHERE t.channel = 'sms'
               AND t.status = '" . MessageThread::STATUS_SUBSCRIBED . "'
               AND $notSubscribed"
        );

        // The INSERT above cannot compute keys in SQL; key those rows now if the column exists.
        if (PhoneMatcher::hasKeyColumn(true)) {
            self::fillPhoneKeys();
        }

        fluentcrm_update_option(self::CONSENT_BACKFILL_OPTION, 'yes');
    }

    /**
     * Add and fill `fc_message_threads.phone_key` (see PhoneMatcher::lookupKey()), the indexed key
     * consent checks look numbers up by. Kept out of the plugin's DB version, since most sites never
     * use messaging: it runs with the module's own migration and when the messaging app loads.
     * Resumable: a fill cut short by the time budget carries on at the next call.
     */
    public static function maybeAddPhoneKey()
    {
        if (fluentcrm_get_option(PhoneMatcher::KEY_STATE_OPTION) === 'yes') {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'fc_message_threads';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            return;
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW COLUMNS FROM `$table` LIKE 'phone_key'") === null) {
            $indexName = $wpdb->prefix . 'fc_mt_phone_key_idx';
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $added = $wpdb->query(
                "ALTER TABLE `$table`
                    ADD COLUMN `phone_key` VARCHAR(20) NULL AFTER `phone_number`,
                    ADD INDEX `$indexName` (`channel`, `phone_key`)"
            );

            if ($added === false) {
                return;
            }
        }

        fluentcrm_update_option(PhoneMatcher::KEY_STATE_OPTION, 'filling');
        PhoneMatcher::hasKeyColumn(true);

        if (self::fillPhoneKeys()) {
            fluentcrm_update_option(PhoneMatcher::KEY_STATE_OPTION, 'yes');
        }
    }

    /**
     * Key every thread whose `phone_key` is not set yet, in id order.
     *
     * @param int $budget seconds to spend before stopping
     * @return bool true when no unkeyed row is left
     */
    public static function fillPhoneKeys($budget = 10)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'fc_message_threads';
        $deadline = microtime(true) + $budget;
        $lastId = 0;

        do {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT id, phone_number FROM `$table` WHERE id > %d AND phone_key IS NULL ORDER BY id ASC LIMIT 500",
                $lastId
            ));

            if (!$rows) {
                return true;
            }

            $cases = [];
            $ids = [];
            foreach ($rows as $row) {
                $ids[] = (int) $row->id;
                $cases[] = $wpdb->prepare('WHEN %d THEN %s', $row->id, PhoneMatcher::lookupKey($row->phone_number));
            }
            $lastId = end($ids);

            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query(
                "UPDATE `$table` SET phone_key = CASE id " . implode(' ', $cases) . " END
                 WHERE id IN (" . implode(',', $ids) . ")"
            );
        } while (microtime(true) < $deadline);

        return false;
    }

    public static function dropTable()
    {
        global $wpdb;

        $tables = [
            $wpdb->prefix . 'fc_sms_messages',
            $wpdb->prefix . 'fc_sms_campaigns'
        ];

        foreach ($tables as $table) {
            if ($wpdb->get_var("SHOW TABLES LIKE '$table'") == $table) {
                $wpdb->query("DROP TABLE IF EXISTS $table");
            }
        }
    }
}
