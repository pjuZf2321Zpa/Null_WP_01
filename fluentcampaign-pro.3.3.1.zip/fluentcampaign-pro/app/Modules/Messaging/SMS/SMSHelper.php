<?php

namespace FluentCampaign\App\Modules\Messaging\SMS;

use FluentCampaign\App\Modules\Messaging\Services\PhoneMatcher;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Services\Libs\Parser\Parser;
use FluentCrm\Framework\Support\Arr;

class SMSHelper
{
    const SMS_WEBHOOK_KEY_OPTION = '_fc_sms_webhook_key';

    /**
     * Per-request memo of getSettings(); cleared by clearSettingsCache() when settings are saved.
     */
    protected static $settingsCache = null;

    public static function clearSettingsCache()
    {
        self::$settingsCache = null;
    }

    public static function getSettings()
    {
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        $settings = [];

        $is_enabled = fluentcrm_get_option('_fc_sms_enable', 'no');

        $current_provider = fluentcrm_get_option('_fc_sms_provider', '');

        $settings['enabled'] = $is_enabled;
        $settings['sms_provider'] = $current_provider;

        $provider_api_options = self::getApiOptions();

        // Do not memoize before drivers are registered.
        if (empty($provider_api_options['providers'])) {
            return $settings;
        }

        foreach ($provider_api_options['providers'] as $provider_name => $options) {
            $current_settings = fluentcrm_get_option("_fc_sms_{$provider_name}_settings", []);
            if (is_array($current_settings) && !empty($current_settings)) {
                $settings[$provider_name] = $current_settings;
            } else {
                foreach ($options['fields'] as $key => $value) {
                    $settings[$provider_name][$key] = $value['default'] ?? '';
                }
            }
        }

        self::$settingsCache = $settings;

        return $settings;
    }

    public static function getCurrentProvider()
    {
        return self::getSettings()['sms_provider'] ?? '';
    }

    public static function getAllowedProviders()
    {
        return Providers\SMSDriverManager::getSlugs();
    }

    public static function twilioSettings()
    {
        $settings = self::getSettings();
        return [
            'twilio_account_sid' => $settings['twilio']['account_sid'] ?? '',
            'twilio_auth_token' => $settings['twilio']['auth_token'] ?? '',
            'twilio_from_number' => $settings['twilio']['from_number'] ?? ''
        ];
    }

    public static function awsEumSettings()
    {
        $settings = self::getSettings();
        return [
            'aws_eum_access_key' => $settings['aws_end_user_message']['access_key_id'] ?? '',
            'aws_eum_secret_key' => $settings['aws_end_user_message']['secret_access_key'] ?? '',
            'aws_eum_region' => $settings['aws_end_user_message']['region'] ?? 'us-east-1',
            'aws_eum_sender_id' => $settings['aws_end_user_message']['sender_id'] ?? ''
        ];
    }

    public static function clickSendSettings()
    {
        $settings = self::getSettings();
        return [
            'clicksend_username' => $settings['click_send']['username'] ?? '',
            'clicksend_api_key' => $settings['click_send']['api_key'] ?? '',
            'clicksend_from_number' => $settings['click_send']['from_number'] ?? ''
        ];
    }

    public static function isActive()
    {
        if (!MessageModule::isEnabled()) {
            return false;
        }

        $settings = self::getSettings();

        return !empty($settings['enabled']) && $settings['enabled'] === 'yes';
    }

    public static function applyRecipientSmartCodes($content, $message)
    {
        $recipient = self::oneTimeRecipientContext($message);
        if (!$recipient) {
            return (string) $content;
        }

        return strtr((string) $content, [
            '{{recipient.full_name}}'      => (string) Arr::get($recipient, 'full_name', ''),
            '{{ recipient.full_name }}'    => (string) Arr::get($recipient, 'full_name', ''),
            '{{recipient.phone_number}}'   => (string) Arr::get($recipient, 'phone_number', ''),
            '{{ recipient.phone_number }}' => (string) Arr::get($recipient, 'phone_number', '')
        ]);
    }

    public static function stripUnresolvedSmartCodes($content)
    {
        return trim(preg_replace('/({{|##)\s*[^}#]+?\s*(}}|##)/', '', (string) $content));
    }

    public static function oneTimeRecipientContext($message)
    {
        if (is_object($message) && method_exists($message, 'oneTimeRecipientContext')) {
            return $message->oneTimeRecipientContext();
        }

        $meta = is_object($message) && is_array($message->meta) ? $message->meta : [];
        $recipient = Arr::get($meta, 'one_time_recipient', []);

        return is_array($recipient) ? $recipient : [];
    }

    // Saved settings for any provider, including custom ones.
    public static function getProviderSettings($provider)
    {
        $all = self::getSettings();
        return $all[$provider] ?? [];
    }

    public static function getApiOptions()
    {
        $provider_definitions = [];
        foreach (Providers\SMSDriverManager::getAll() as $slug => $provider) {
            $provider_definitions[$slug] = [
                'label'  => $provider->getLabel(),
                'fields' => $provider->getFields(),
            ];
        }

        $provider_options = [];
        foreach ($provider_definitions as $key => $def) {
            $provider_options[$key] = $def['label'] ?? ucfirst(str_replace('_', ' ', $key));
        }

        $provider_select = [
            'type'    => 'select',
            'label'   => __('SMS Provider', 'fluentcampaign-pro'),
            'options' => $provider_options,
            'default' => array_key_first($provider_options) ?: '',
        ];

        if (empty($provider_select['default']) || !isset($provider_select['options'][$provider_select['default']])) {
            $first = array_key_first($provider_select['options'] ?? []);
            if ($first) {
                $provider_select['default'] = $first;
            }
        }

        return [
            'sms_providers' => $provider_select,
            'providers'     => $provider_definitions,
        ];
    }


    public static function verifyWebhookHash($hash, $provider, $url)
    {
        if (!$hash || !is_string($hash) || strlen($hash) < 16 || !$provider) {
            return false;
        }

        $hashInDb = fluentcrm_get_option(self::SMS_WEBHOOK_KEY_OPTION, '');

        if (!$hashInDb || !is_string($hashInDb)) {
            return false;
        }

        return hash_equals($hashInDb, $hash);
    }

    public static function getSMSWebhookUrl($provider, $create = false)
    {
        if (!$provider) {
            return '';
        }

        $key = fluentcrm_get_option(self::SMS_WEBHOOK_KEY_OPTION, '');
        if (!$key && $create) {
            $key = wp_generate_uuid4();
            fluentcrm_update_option(self::SMS_WEBHOOK_KEY_OPTION, $key);
        }

        return $key && is_string($key) ? add_query_arg([
            FLUENTCRM_EXTERNAL_URL_PARAM => '1',
            'route'                      => 'webhook',
            'handler'                    => 'sms_webhook',
            'provider'                   => $provider,
            'hash'                       => $key,
        ], site_url('/')) : '';
    }

    /**
     * Record a STOP on the number's thread. Hooks and the confirmation need a contact.
     */
    public static function optOut($phone, $data = [])
    {
        if (!$phone) {
            return false;
        }

        // The reply is the number's decision: it covers every contact with this number, however stored.
        $contacts = MessageThread::setNumberConsent('sms', $phone, MessageThread::STATUS_UNSUBSCRIBED);
        if ($contacts === null) {
            return false;
        }

        foreach ($contacts as $index => $subscriber) {
            // One confirmation to the number; Twilio sends its own STOP/START compliance reply.
            if ($index === 0 && ($data['provider'] ?? '') !== 'twilio') {
                self::queueStatusConfirmationMessage($subscriber, 'opt_out', $data);
            }

            do_action('fluent_crm/contact_sms_unsubscribed', $subscriber, $data);
        }

        return true;
    }

    public static function optIn($phone, $data = [])
    {
        if (!$phone) {
            return false;
        }

        // The reply is the number's decision: it covers every contact with this number, however stored.
        $contacts = MessageThread::setNumberConsent('sms', $phone, MessageThread::STATUS_SUBSCRIBED);
        if ($contacts === null) {
            return false;
        }

        foreach ($contacts as $index => $subscriber) {
            // One confirmation to the number; Twilio sends its own STOP/START compliance reply.
            if ($index === 0 && ($data['provider'] ?? '') !== 'twilio') {
                self::queueStatusConfirmationMessage($subscriber, 'opt_in', $data);
            }

            do_action('fluent_crm/contact_sms_subscribed', $subscriber, $data);
        }

        return true;
    }

    /**
     * `ref_type` for automated opt-in/opt-out confirmations; scopes the retry dedupe.
     */
    const CONFIRMATION_REF_TYPE = 'status_confirmation';

    protected static function queueStatusConfirmationMessage($subscriber, $event, $data = [])
    {
        global $wpdb;

        // Twilio sends its own STOP/START compliance reply.
        if(($data['provider'] ?? '') === 'twilio') {
            return false;
        }

        if (!$subscriber || !$subscriber->phone) {
            return false;
        }

        $incomingMessageSid = $data['MessageSid'] ?? $data['SmsSid'] ?? $data['SmsMessageSid'] ?? '';
        $note = $event === 'opt_out' ? 'sms opt-out confirmation' : 'sms opt-in confirmation';

        // Webhook retry dedupe: the inbound SID is stored in the confirmation's meta.
        if ($incomingMessageSid) {
            $existingMessage = Message::where('ref_type', self::CONFIRMATION_REF_TYPE)
                ->where('meta', 'like', '%' . $wpdb->esc_like($incomingMessageSid) . '%')
                ->whereHas('thread', function ($query) use ($subscriber) {
                    $query->where('contact_id', $subscriber->id);
                })
                ->first();

            if ($existingMessage) {
                return $existingMessage;
            }
        }

        if ($event === 'opt_out') {
            $messageContent = __('You have been unsubscribed. Reply START to resubscribe.', 'fluentcampaign-pro');
            $messageContent = apply_filters('fluent_crm/sms_opt_out_confirmation_message', $messageContent, $subscriber, $data);
        } else {
            $messageContent = __('You have been subscribed. Reply STOP to unsubscribe.', 'fluentcampaign-pro');
            $messageContent = apply_filters('fluent_crm/sms_opt_in_confirmation_message', $messageContent, $subscriber, $data);
        }

        if (!$messageContent) {
            return false;
        }

        $smsMessage = MessageThread::queueOutbound(
            LegacyMessage::CHANNEL_SMS,
            $subscriber->phone,
            $subscriber->id,
            $messageContent,
            [
                'ref_type' => self::CONFIRMATION_REF_TYPE,
                // The inbound SID here is what the retry dedupe above matches.
                'meta'     => [
                    'notes'                => $note,
                    'provider'             => $data['provider'] ?? (self::getCurrentProvider() ?: 'unknown'),
                    'event'                => $event,
                    'incoming_message_sid' => $incomingMessageSid,
                ]
            ]
        );

        if (!$smsMessage) {
            return false;
        }

        MessageScheduler::dispatch($smsMessage->id);

        return $smsMessage;
    }

    public static function processIncomingMessage($from, $to, $body, $data = [])
    {
        if (!$from || !$to || !$body) {
            return false;
        }

        // May be null; messages from unknown numbers are still stored.
        $subscriber = PhoneMatcher::findContact($from);

        $providerMessageId = $data['MessageSid'] ?? $data['SmsSid'] ?? $data['SmsMessageSid'] ?? '';

        // Dedupe provider webhook retries.
        if ($providerMessageId && \FluentCampaign\App\Modules\Messaging\Models\MessageThread::hasProviderMessage($providerMessageId, 'sms')) {
            return true;
        }

        // The thread is keyed on `From`; `$to` is the business number.
        $thread = \FluentCampaign\App\Modules\Messaging\Models\MessageThread::findOrCreateFor('sms', $from, [
            'contact_id'   => $subscriber ? $subscriber->id : null,
            'initiated_by' => 'user'
        ]);

        if (!$thread) {
            return false;
        }

        $thread->recordMessage([
            'direction'           => 'inbound',
            'content'             => $body,
            'provider_message_id' => $providerMessageId ?: null,
            'ref_type'            => 'incoming',
            'status'              => 'received',
            'meta'                => [
                'settings' => [
                    'from'     => $from,
                    'to'       => $to,
                    'provider' => $data['provider'] ?? 'unknown',
                ]
            ]
        ]);

        return true;
    }

    /**
     * Parse SMS content with the shared smartcode parser, resolve deferred CRM link codes, and convert to plain text.
     * Do not add a separate SMS allowlist here without updating the picker and parser together.
     *
     * @param string $content
     * @param \FluentCrm\App\Models\Subscriber $subscriber
     * @return string
     */
    public static function parseMessageContent($content, $subscriber)
    {
        $content = Parser::parse((string)$content, $subscriber);
        $content = self::parseDeferredCrmSmartCodes($content, $subscriber);
        $content = apply_filters('fluent_crm/parse_sms_smartcode', $content, $subscriber);

        return self::sanitizeParsedMessageContent($content);
    }

    /**
     * Resolve the unsubscribe/manage-subscription smartcodes that Parser::parse() leaves for the email pipeline.
     *
     * @param string $content
     * @param \FluentCrm\App\Models\Subscriber $subscriber
     * @return string
     */
    protected static function parseDeferredCrmSmartCodes($content, $subscriber)
    {
        if (!$subscriber instanceof Subscriber) {
            return $content;
        }

        return preg_replace_callback(
            '/({{|##)\s*crm\.(unsubscribe_url|manage_subscription_url|unsubscribe_html|manage_subscription_html)(.*?)\s*(}}|##)/',
            function ($matches) use ($subscriber) {
                // The SMS goes to the contact's own phone, and opt-out links must keep working.
                return Parser::parseCrmValue($matches[0], $subscriber, 'credential');
            },
            $content
        );
    }

    /**
     * Convert parsed output to plain text: links become "Label (url)", HTML and unresolved smartcodes are removed.
     *
     * @param string $content
     * @return string
     */
    protected static function sanitizeParsedMessageContent($content)
    {
        $content = preg_replace_callback(
            '/<a[^>]*href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/is',
            function ($matches) {
                $url = trim($matches[1]);
                $label = trim(wp_strip_all_tags($matches[2]));

                if ($label === '' || $label === $url) {
                    return $url;
                }

                return $label . ' (' . $url . ')';
            },
            (string)$content
        );

        $content = preg_replace('/<\s*br\s*\/?>/i', "\n", $content);
        $content = preg_replace('/<\/(p|div|li|h[1-6]|tr)>/i', "\n", $content);
        $content = wp_strip_all_tags($content);
        $content = html_entity_decode($content, ENT_QUOTES, 'UTF-8');
        $content = preg_replace('/({{|##).*?(}}|##)/', '', $content);
        $content = preg_replace('/[ \t\x{00A0}]+/u', ' ', $content);
        $content = preg_replace("/[ \t]*\n[ \t]*/", "\n", $content);
        $content = preg_replace("/\n{3,}/", "\n\n", $content);

        return trim($content);
    }
}
