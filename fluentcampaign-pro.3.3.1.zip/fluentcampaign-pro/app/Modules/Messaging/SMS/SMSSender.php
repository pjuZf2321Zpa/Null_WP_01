<?php

namespace FluentCampaign\App\Modules\Messaging\SMS;

use FluentCampaign\App\Modules\Messaging\SMS\Providers\SMSDriverManager;

class SMSSender
{
    public static function send($to, $message, $provider = null)
    {
        if (!SMSHelper::isActive()) {
            return false;
        }

        if (!$provider) {
            $provider = SMSHelper::getCurrentProvider();
        }

        $settings         = SMSHelper::getProviderSettings($provider);
        $providerInstance = SMSDriverManager::getDriver($provider);

        if ($providerInstance) {
            return $providerInstance->send($to, $message, $settings);
        }

        return [
            'status'      => 'error',
            'status_code' => 0,
            /* translators: %s: provider key */
            'message'     => sprintf(__('The SMS provider "%s" is not available.', 'fluentcampaign-pro'), $provider),
            'response'    => null,
        ];
    }

}
