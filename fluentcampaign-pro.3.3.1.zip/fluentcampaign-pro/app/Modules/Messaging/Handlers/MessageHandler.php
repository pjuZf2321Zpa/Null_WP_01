<?php

namespace FluentCampaign\App\Modules\Messaging\Handlers;

use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;
use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceMeta;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppReceiver;
use FluentCrm\Framework\Support\Arr;


class MessageHandler
{
    public function register()
    {
        add_action('fluentcrm_webhook_to_sms_webhook', [$this, 'handleProviderWebhook']);
        add_action('fluentcrm_webhook_to_whatsapp', [$this, 'handleWhatsAppWebhook']);
        // register() already runs on `init`, so check the request directly.
        $this->handleLegacyTwilioWebhook();
    }

    /**
     * Answer the retired pre-3.2.0 Twilio webhook URL with 410.
     */
    public function handleLegacyTwilioWebhook()
    {
        $isFluentCrm = isset($_GET['fluentcrm']) ? $this->sanitizeRequestValue($_GET['fluentcrm']) : '';
        $provider = isset($_GET['fc_s_webhook']) ? $this->sanitizeRequestValue($_GET['fc_s_webhook']) : '';

        if ($isFluentCrm !== '1' || $provider !== 'twilio') {
            return;
        }

        $this->rejectWebhook('twilio', 410, 'This webhook URL has been retired. Update the Twilio webhook URL to the one shown in FluentCRM Settings > SMS > Twilio.');
    }

    /**
     * Handle WhatsApp provider webhooks; only WhatsApp provider slugs are accepted.
     *
     * @param array $requestData Query/form data passed by ExternalPages.
     */
    public function handleWhatsAppWebhook($requestData = [])
    {
        $this->handleProviderWebhook($requestData, 'whatsapp');
    }

    /**
     * Verify and dispatch a provider webhook from core's ExternalPages router.
     * Only providers of the given channel are accepted.
     *
     * @param array  $requestData Query/form data passed by ExternalPages.
     * @param string $channel     Which channel's providers are accepted: 'sms' or 'whatsapp'.
     */
    public function handleProviderWebhook($requestData = [], $channel = 'sms')
    {
        $provider = isset($_GET['provider']) ? $this->sanitizeRequestValue($_GET['provider']) : '';
        $hash = isset($_GET['hash']) ? $this->sanitizeRequestValue($_GET['hash']) : '';

        if (!$provider) {
            $provider = $this->sanitizeRequestValue(Arr::get($requestData, 'provider', ''));
        }

        if (!$hash) {
            $hash = $this->sanitizeRequestValue(Arr::get($requestData, 'hash', ''));
        }

        if (!$provider) {
            $this->rejectWebhook($provider, 400, 'Missing provider');
        }

        $isWhatsApp = ($channel === 'whatsapp');

        $allowed_providers = $isWhatsApp
            ? WhatsAppHelper::getAllowedProviders()
            : SMSHelper::getAllowedProviders();

        if (!in_array($provider, $allowed_providers, true)) {
            $this->rejectWebhook($provider, 400, 'Invalid provider');
        }

        if (!$hash) {
            $this->rejectWebhook($provider, 400, 'Missing hash');
        }

        // Each channel stores its webhook hash under its own option.
        $hashValid = $isWhatsApp
            ? WhatsAppHelper::verifyWebhookHash($hash, $provider)
            : SMSHelper::verifyWebhookHash($hash, $provider, '');

        if (!$hashValid) {
            $this->rejectWebhook($provider, 403, 'Invalid hash');
        }


        // Meta's GET verification challenge has no body to sign.
        if ($provider === 'meta_cloud' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
            WhatsAppReceiver::handleMetaWebhookVerification();
            exit;
        }


        $rawInput = $this->getRawInput();

        $signatureCheck = $this->verifyProviderSignature($provider, $rawInput);

        if ($signatureCheck !== true) {

            // The response stays generic; the detail goes only to the action.
            $this->rejectWebhook($provider, 403, 'Invalid provider signature', $signatureCheck);
        }

        $bodyData = $this->getWebhookPayload($provider, $rawInput);

        switch ($provider) {
            case 'twilio':
                MessageReceiver::handleTwilioWebhook($bodyData);
                break;

            case 'twilio_whatsapp':
                WhatsAppReceiver::handleTwilioWebhook($bodyData);
                break;

            case 'meta_cloud':
                WhatsAppReceiver::handleMetaWebhook($bodyData);
                break;

            default:
                MessageReceiver::handleCustomProviderWebhook($provider, $bodyData);
                break;
        }

        echo 'OK';
        exit;
    }

    /**
     * Reject a webhook request and fire `fluent_crm/messaging_webhook_rejected` with the reason.
     *
     * @param string $provider Provider slug, empty when it was the missing piece.
     * @param int    $status   HTTP status to send.
     * @param string $reason   Human-readable reason, also sent as the body.
     * @param string $detail   Extra context for the action only, never the response.
     */
    private function rejectWebhook($provider, $status, $reason, $detail = '')
    {
        /**
         * A provider webhook was rejected before reaching a receiver.
         *
         * @param string $reason   Why it was rejected.
         * @param string $provider Provider slug from the request.
         * @param int    $status   HTTP status being returned.
         */
        do_action('fluent_crm/messaging_webhook_rejected', $reason, $provider, $status, $detail);

        status_header($status);
        echo esc_html($reason);
        exit;
    }

    private function sanitizeRequestValue($value)
    {
        if (is_array($value) || is_object($value)) {
            return '';
        }

        return sanitize_text_field(wp_unslash((string) $value));
    }

    private function getRawInput()
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            return '';
        }

        // Form posts are already in $_POST; the raw body is only needed for JSON (Meta HMAC).
        if (!empty($_POST)) {
            return '';
        }

        $rawInput = file_get_contents('php://input');

        return is_string($rawInput) ? $rawInput : '';
    }

    /**
     * Check the provider's payload signature. Returns true, or a reason string on failure.
     *
     * @return true|string
     */
    private function verifyProviderSignature($provider, $rawInput)
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            return true;
        }

        if ($provider === 'twilio_whatsapp') {
            $settings = WhatsAppHelper::getProviderSettings('twilio_whatsapp');
            $authToken = trim((string) ($settings['auth_token'] ?? ''));

            if (!$authToken) {
                return 'twilio_whatsapp auth token is not configured';
            }

            if (!WhatsAppHelper::verifyTwilioSignature($authToken, $_POST)) {
                return 'X-Twilio-Signature did not match the configured auth token';
            }

            return true;
        }

        if ($provider === 'meta_cloud') {
            $settings = WhatsAppHelper::getProviderSettings('meta_cloud');
            $appSecret = trim((string) ($settings['app_secret'] ?? ''));

            // Prefer X-Hub-Signature-256; fall back to sha1 when a proxy drops it.
            $signature = $this->readHeader('X-Hub-Signature-256');

            if (!$signature) {
                $signature = $this->readHeader('X-Hub-Signature');
            }

            if (!$appSecret) {
                return 'meta_cloud app secret is not configured in WhatsApp settings';
            }

            if (!$signature) {
                return 'neither X-Hub-Signature-256 nor X-Hub-Signature reached PHP — check the server/proxy header pass-through';
            }

            if (!$rawInput) {
                return 'request body was empty or already consumed before the handler ran';
            }

            if (!WhatsAppHelper::verifyMetaSignature($appSecret, $rawInput, $signature)) {
                return 'signature did not match the configured app secret — confirm it is the App Secret of the Meta app that owns this webhook subscription';
            }

            return true;
        }

        return true;
    }

    /**
     * Read a request header, falling back to getallheaders() for FastCGI/proxy setups.
     *
     * @param string $name Header name in canonical form, e.g. X-Hub-Signature-256.
     * @return string Sanitized header value, or '' when absent.
     */
    private function readHeader($name)
    {
        $serverKey = 'HTTP_' . strtoupper(str_replace('-', '_', $name));

        if (!empty($_SERVER[$serverKey])) {
            return sanitize_text_field(wp_unslash($_SERVER[$serverKey]));
        }

        if (!function_exists('getallheaders')) {
            return '';
        }

        $headers = getallheaders();

        if (!is_array($headers)) {
            return '';
        }

        foreach ($headers as $key => $value) {
            if (strcasecmp($key, $name) === 0 && !is_array($value)) {
                return sanitize_text_field(wp_unslash((string) $value));
            }
        }

        return '';
    }

    private function getWebhookPayload($provider, $rawInput = '')
    {
        $requestMethod = $_SERVER['REQUEST_METHOD'] ?? '';
        $contentType   = $_SERVER['CONTENT_TYPE'] ?? '';
        $bodyData      = [];

        if ($requestMethod !== 'POST') {
            return [];
        }

        if (!empty($_POST)) {
            return $this->sanitizePayload(wp_unslash($_POST), $provider);
        }

        if (!$rawInput) {
            return [];
        }

        if (stripos($contentType, 'application/json') !== false) {
            $decoded = json_decode($rawInput, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $bodyData = $decoded;
            }
        }

        if (empty($bodyData)) {
            parse_str($rawInput, $bodyData);
            $bodyData = wp_unslash($bodyData);
        }

        return $this->sanitizePayload($bodyData, $provider);
    }

    private function sanitizePayload($payload, $provider = '')
    {
        if (!is_array($payload)) {
            return [];
        }

        $payload = map_deep($payload, 'sanitize_textarea_field');

        if (!in_array($provider, ['twilio', 'twilio_whatsapp'], true)) {
            return $payload;
        }

        foreach (['From', 'To', 'MessageSid', 'SmsSid', 'SmsMessageSid'] as $key) {
            if (!empty($payload[$key]) && !is_array($payload[$key])) {
                $payload[$key] = sanitize_text_field($payload[$key]);
            }
        }

        if (isset($payload['Body']) && !is_array($payload['Body'])) {
            $payload['Body'] = sanitize_textarea_field($payload['Body']);
        }

        return $payload;
    }

    /**
     * Turn a campaign's audience into queued message rows, in chunks within a time budget.
     * Resumes from the last subscriber id seen, stored as the campaign's `gen` cursor.
     *
     * @param int $campaignId
     */
    public function handleGenerateBatch($campaignId)
    {
        if (!MessageModule::isAnyChannelActive()) {
            return;
        }

        $smsCampaign = MessageCampaign::find($campaignId);

        if (!$smsCampaign) {
            return;
        }

        if (!in_array($smsCampaign->status, ['pending-scheduled', 'processing'])) {
            return;
        }

        if ($smsCampaign->status == 'pending-scheduled') {
            // Do not overwrite a concurrent unschedule (draft) with processing.
            $claimed = MessageCampaign::where('id', $campaignId)
                ->where('status', 'pending-scheduled')
                ->update([
                    'status'     => 'processing',
                    'updated_at' => current_time('mysql')
                ]);

            if (!$claimed) {
                return;
            }

            $smsCampaign->status = 'processing';

            if ($smsCampaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
                do_action('fluent_crm/whatsapp_campaign_processing_start', $smsCampaign);
            } else {
                do_action('fluent_crm/sms_campaign_processing_start', $smsCampaign);
            }
        }

        // Liveness stamp read by the health check.
        MessageCampaign::where('id', $campaignId)->update([
            'updated_at' => current_time('mysql')
        ]);

        if (fluentCrmIsMemoryExceeded()) {
            MessageScheduler::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaignId, time() + 10);
            return;
        }

        $perChunk = (int) apply_filters('fluent_crm/message_process_subscribers_per_request', 200);
        $perChunk = (int) apply_filters_deprecated(
            'fluent_crm/sms_process_subscribers_per_request',
            [$perChunk],
            '3.2.0',
            'fluent_crm/message_process_subscribers_per_request'
        );

        if ($perChunk < 1) {
            $perChunk = 200;
        }

        if (Arr::get($smsCampaign->settings, 'sending_filter') === 'one_time') {
            $this->handleGenerateOneTimeBatch($smsCampaign);
            return;
        }

        $subscribersModel = $smsCampaign->getSubscribersModel($smsCampaign->settings);

        if (!$subscribersModel) {
            // No valid audience selection.
            $smsCampaign->status = 'archived';
            $smsCampaign->save();
            return;
        }

        $startedAt = time();
        $budget    = (int) apply_filters('fluent_crm/message_scheduler_max_processing_seconds', 20);
        $cursor    = MessageCampaign::getCursor($campaignId)['gen'];
        $audienceFinished = false;

        while (true) {
            // reorder() replaces any inherited order (dynamic segments use id DESC).
            $subscribers = (clone $subscribersModel)
                ->where('id', '>', $cursor)
                ->reorder('id', 'ASC')
                ->limit($perChunk)
                ->get();

            if ($subscribers->isEmpty()) {
                $audienceFinished = true;
                break;
            }

            // Stop if the campaign was unscheduled during the query.
            if (!MessageCampaign::where('id', $campaignId)->where('status', 'processing')->exists()) {
                return;
            }

            $smsCampaign->subscribe($subscribers, [
                'status'       => 'scheduling',
                'scheduled_at' => $smsCampaign->getScheduledAt(),
                'sms_type'     => 'campaign',
            ], true);

            // An unschedule may race subscribe(); remove what this worker created.
            if (!MessageCampaign::where('id', $campaignId)->where('status', 'processing')->exists()) {
                Message::forCampaign($campaignId)
                    ->where('status', Message::STATUS_SCHEDULING)
                    ->delete();
                return;
            }

            // Advance by subscribers seen, not rows inserted; subscribe() skips some.
            $cursor = (int) $subscribers->last()->id;
            MessageCampaign::setCursor($campaignId, 'gen', $cursor);

            if ($subscribers->count() < $perChunk) {
                $audienceFinished = true;
                break;
            }

            if ((time() - $startedAt) >= $budget || fluentCrmIsMemoryExceeded()) {
                break;
            }
        }

        if (!$audienceFinished) {
            MessageScheduler::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaignId);
            return;
        }

        $this->finalizeGeneratedCampaign($campaignId);
    }

    protected function handleGenerateOneTimeBatch(MessageCampaign $smsCampaign)
    {
        $campaignId = (int) $smsCampaign->id;
        $batchId = OneTimeAudienceMeta::getActiveBatchId($smsCampaign);

        if (!$batchId) {
            $this->failGeneration($campaignId, 'One-time audience is missing an active batch.');
            return;
        }

        if (!OneTimeAudienceMeta::hasConfirmedConsent($smsCampaign)) {
            $this->failGeneration($campaignId, 'One-time audience consent has not been confirmed for this channel.');
            return;
        }

        $query = OneTimeAudienceMeta::messageBatchQuery($campaignId, $batchId)
            ->where('status', Message::STATUS_SCHEDULING);

        if (!(clone $query)->exists()) {
            $this->failGeneration($campaignId, 'One-time audience has no queued recipients.');
            return;
        }

        // Stop if the campaign was unscheduled.
        if (!MessageCampaign::where('id', $campaignId)->where('status', 'processing')->exists()) {
            return;
        }

        (clone $query)->update([
            'content'      => $smsCampaign->message_content,
            'scheduled_at' => $smsCampaign->getScheduledAt(),
            'updated_at'   => current_time('mysql')
        ]);

        if (!MessageCampaign::where('id', $campaignId)->where('status', 'processing')->exists()) {
            Message::forCampaign($campaignId)
                ->where('status', Message::STATUS_SCHEDULING)
                ->delete();
            return;
        }

        $this->finalizeGeneratedCampaign($campaignId);
    }

    protected function finalizeGeneratedCampaign($campaignId)
    {
        $finalized = MessageCampaign::where('id', $campaignId)
            ->where('status', 'processing')
            ->update([
                'status'     => 'scheduled',
                'updated_at' => current_time('mysql')
            ]);

        if (!$finalized) {
            Message::forCampaign($campaignId)
                ->where('status', Message::STATUS_SCHEDULING)
                ->delete();
            return;
        }

        Message::forCampaign($campaignId)
            ->where('status', Message::STATUS_SCHEDULING)
            ->update([
                'status' => Message::STATUS_SCHEDULED
            ]);

        $smsCampaign = MessageCampaign::find($campaignId);
        if (!$smsCampaign) {
            return;
        }

        $smsCampaign->maybeDeleteDuplicates();
        $smsCampaign->updateRecipientsCount($smsCampaign->getMessageCount());

        // Hand off to sending at the campaign's send time; get_gmt_from_date() needs the raw string.
        $scheduledAt = $smsCampaign->getAttributes()['scheduled_at'] ?? null;

        $sendAt = $scheduledAt
            ? max(time(), (int) get_gmt_from_date($scheduledAt, 'U'))
            : time();

        MessageScheduler::scheduleCampaignAction('fluentcrm_send_message_batch', $campaignId, $sendAt);
    }

    protected function failGeneration($campaignId, $reason)
    {
        MessageCampaign::where('id', (int) $campaignId)
            ->whereIn('status', ['pending-scheduled', 'processing'])
            ->update([
                'status'     => MessageCampaign::STATUS_FAILED,
                'updated_at' => current_time('mysql')
            ]);

        fluentcrm_update_sms_campaign_meta((int) $campaignId, '_one_time_generation_error', sanitize_text_field($reason));
        MessageScheduler::clearPendingCampaignActions((int) $campaignId);
    }

}
