<?php

namespace FluentCampaign\App\Modules\Messaging\Handlers;

use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;

class MessageReceiver
{

    public static function handleAwsEumMessages($data)
    {
        
    }

    /**
     * SMS opt-out keywords, matched as the whole message.
     *
     * Twilio's default list (STOP, STOPALL, UNSUBSCRIBE, CANCEL, END, QUIT, REVOKE, OPTOUT): a
     * contact who sends one is blocked by Twilio itself, so FluentCRM must record the same opt-out.
     * Twilio does not treat a keyword inside a longer message ("STOP please") as an opt-out, and
     * neither does this.
     *
     * @return string[] lowercase keywords
     */
    public static function optOutKeywords()
    {
        $keywords = ['stop', 'stopall', 'unsubscribe', 'cancel', 'end', 'quit', 'revoke', 'optout'];

        /**
         * Filter the SMS opt-out keywords (lowercase, whole-message match).
         *
         * @param string[] $keywords
         */
        $keywords = apply_filters('fluent_crm/sms_opt_out_keywords', $keywords);

        return array_map('strtolower', (array)$keywords);
    }

    /**
     * Whether an inbound SMS is an opt-out request.
     *
     * @param string $body
     * @return bool
     */
    public static function isOptOutMessage($body)
    {
        return in_array(self::normalizeKeyword($body), self::optOutKeywords(), true);
    }

    /**
     * Lowercase a message and strip surrounding spaces and punctuation, so "Stop." matches "stop".
     *
     * @param string $body
     * @return string
     */
    public static function normalizeKeyword($body)
    {
        $body = strtolower(trim((string)$body));

        return (string)preg_replace('/^[\p{P}\p{S}\s]+|[\p{P}\p{S}\s]+$/u', '', $body);
    }

    /**
     * Handle incoming Twilio webhook
     * 
     * @param array $bodyData The sanitized POST data from the webhook
     */
    public static function handleTwilioWebhook($bodyData = [])
    {
        $from = $bodyData['From'] ?? '';
        $to = $bodyData['To'] ?? '';
        $body = isset($bodyData['Body']) ? trim($bodyData['Body']) : '';
        $provider = 'twilio';
        $bodyData['provider'] = $provider;

        if ($from && $to && $body) {

            $body_norm = self::normalizeKeyword($body);

            $isOptOut = self::isOptOutMessage($body);

            if ($isOptOut) {
                // Store the inbound message before updating consent.
                SMSHelper::processIncomingMessage($from, $to, $body, $bodyData);

                $handled = SMSHelper::optOut($from, $bodyData);

                // Inline TwiML reply only when consent could not be recorded.
                self::respondToTwilio($handled ? '' : 'You have been unsubscribed. Reply START to resubscribe.');
                exit;
            }

            $isOptIn = in_array($body_norm, ['start', 'subscribe', 'unstop'], true);

            if ($isOptIn) {
                SMSHelper::processIncomingMessage($from, $to, $body, $bodyData);

                $handled = SMSHelper::optIn($from, $bodyData);

                self::respondToTwilio($handled ? '' : 'You have been subscribed. Reply STOP to unsubscribe.');
                exit;
            }

            SMSHelper::processIncomingMessage($from, $to, $body, $bodyData);

            return true;
        }

        return false;
    }

    protected static function respondToTwilio($message = '')
    {
        header('Content-Type: text/xml');
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<Response>';
        if ($message) {
            echo '<Message>' . esc_html($message) . '</Message>';
        }
        echo '</Response>';
    }

    /**
     * Handle custom provider webhook
     *
     * @param string $provider The provider name
     * @param array $bodyData The sanitized POST data from the webhook
     */
    public static function handleCustomProviderWebhook($provider, $bodyData = [])
    {
        /**
         * Allow custom providers to handle their webhooks
         *
         * @param array $bodyData The webhook data
         * @param string $provider The provider name
         */
        do_action('fluent_crm_sms_custom_provider_webhook', $bodyData, $provider);
        do_action("fluent_crm_sms_{$provider}_webhook", $bodyData);

        return true;
    }

}
