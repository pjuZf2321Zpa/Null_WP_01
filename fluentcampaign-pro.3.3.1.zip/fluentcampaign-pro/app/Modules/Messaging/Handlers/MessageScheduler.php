<?php

namespace FluentCampaign\App\Modules\Messaging\Handlers;

use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceMeta;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Support\Arr;

/**
 * The outbound message queue over `fc_messages`.
 * Channel, destination number and contact come from the message's thread.
 */
class MessageScheduler
{
    /**
     * Rows pulled per SELECT inside the send loop. Time and memory, not the chunk, end an action.
     */
    protected $sendingPerChunk = 200;

    /**
     * Seconds an action may spend sending; kept under Action Scheduler's 30s runner limit.
     */
    protected $maximumProcessingTime = 20;

    /**
     * Seconds before a continuation action is due.
     * Zero lets the same Action Scheduler pass pick it up. Filter: `fluent_crm/message_next_action_delay`.
     */
    const NEXT_ACTION_DELAY = 0;


    protected $sentCount = 0;
    protected $startingTimeStamp;

    public function __construct()
    {
        $sendingPerChunk = (int) $this->applyFilterWithOldName(
            'fluent_crm/message_scheduler_chunk_size',
            'fluent_crm/sms_scheduler_chunk_size',
            $this->sendingPerChunk
        );

        if ($sendingPerChunk > 0) {
            $this->sendingPerChunk = $sendingPerChunk;
        }

        $maximumProcessingTime = (int) $this->applyFilterWithOldName(
            'fluent_crm/message_scheduler_max_processing_seconds',
            'fluent_crm/sms_scheduler_max_processing_seconds',
            $this->maximumProcessingTime
        );

        if ($maximumProcessingTime > 0) {
            $this->maximumProcessingTime = $maximumProcessingTime;
        }
    }

    /**
     * Apply the current filter, then the deprecated legacy name.
     */
    protected function applyFilterWithOldName($current, $legacy, $value)
    {
        $value = apply_filters($current, $value, $this);

        return apply_filters_deprecated($legacy, [$value, $this], '3.2.0', $current);
    }



    /**
     * Action Scheduler group for all module actions.
     */
    const ACTION_GROUP = 'fluent-crm-messaging';

    /**
     * Queue one campaign action, replacing any pending copy of it.
     * Action Scheduler's unique flag is hook-wide, so the duplicate is cancelled manually.
     */
    public static function scheduleCampaignAction($hook, $campaignId, $timestamp = null)
    {
        $campaignId = (int) $campaignId;

        if ($timestamp === null) {
            $timestamp = time() + max(0, (int) apply_filters('fluent_crm/message_next_action_delay', self::NEXT_ACTION_DELAY));
        }

        as_unschedule_all_actions($hook, [$campaignId], self::ACTION_GROUP);

        as_schedule_single_action($timestamp, $hook, [$campaignId], self::ACTION_GROUP);
    }

    /**
     * Cancel every queued generation and sending action for one campaign, and clear its cursor.
     */
    public static function clearPendingCampaignActions($campaignId) 
    {
        $campaignId = (int) $campaignId;

        foreach (['fluentcrm_generate_message_batch', 'fluentcrm_send_message_batch'] as $hook) {
            as_unschedule_all_actions($hook, [$campaignId], self::ACTION_GROUP);
        }

        // Pre-3.2.0 actions use a per-campaign group. An empty hook is required to cancel a whole group.
        as_unschedule_all_actions('', [], 'fluent-crm-sms-' . $campaignId);

        MessageCampaign::clearCursor($campaignId);
    }

    /**
     * Atomically claim a queued message; only the worker whose update succeeds may send it.
     */
    public static function claimMessage($messageId)
    {
        return (bool) fluentCrmDb()->table('fc_messages')
            ->where('id', (int) $messageId)
            ->whereIn('status', Message::CLAIMABLE)
            ->update([
                'status'     => Message::STATUS_PROCESSING,
                'updated_at' => current_time('mysql')
            ]);
    }

    /**
     * Return messages stuck in `processing` to `pending`.
     *
     * @param int $maxAgeSeconds How long a claim may go unresolved.
     * @param int $campaignId    Limit to one campaign, or 0 to sweep all outbound.
     * @return int Rows returned to the queue.
     */
    public static function resetStuckProcessingMessages($maxAgeSeconds, $campaignId = 0)
    {
        $threshold = date('Y-m-d H:i:s', current_time('timestamp') - (int) $maxAgeSeconds);

        $query = $campaignId
            ? Message::forCampaign((int) $campaignId)
            : Message::where('direction', Message::DIRECTION_OUTBOUND);

        // updated_at must not change: the health check reads it as the last claim time.
        return (int) $query->where('status', Message::STATUS_PROCESSING)
            ->where('updated_at', '<', $threshold)
            ->update([
                'status' => Message::STATUS_PENDING
            ]);
    }

    /**
     * Register the module's Action Scheduler hooks.
     */
    public function register()
    {
        add_action('fluentcrm_generate_message_batch', [(new MessageHandler()), 'handleGenerateBatch']);
        add_action('fluentcrm_send_message_batch', [$this, 'handleSendBatch']);

        // Retired job names, kept until 3.4.0 to drain actions queued before the upgrade.
        add_action('fluentcrm_generate_sms_batch', function ($campaignId = 0) {
            (new MessageHandler())->handleGenerateBatch($campaignId);
        });

        add_action('fluentcrm_send_sms_batch', function ($campaignId = 0) {
            $this->handleSendBatch($campaignId);
        });

        add_action('fluentcrm_send_single_sms', [$this, 'handleSendSingleMessage']);
        add_action('fluentcrm_send_single_message', [$this, 'handleSendSingleMessage']);

        add_action('fluentcrm_scheduled_five_minute_tasks', [$this, 'handleHealthCheck']);
        add_action('fluentcrm_scheduled_hourly_tasks', [$this, 'handleHealthCheck']);
    }

    /**
     * Send a single queued message by ID.
     *
     * @param int $messageId
     */
    public function handleSendSingleMessage($messageId)
    {
        if (!$this->isSystemOk()) {
            return;
        }

        $smsMessage = Message::with(['thread', 'thread.subscriber'])->find($messageId);

        if (!$smsMessage) {
            return;
        }

        if (!in_array($smsMessage->status, Message::CLAIMABLE)) {
            return;
        }

        if (!self::claimMessage($smsMessage->id)) {
            return; // Another runner already claimed this message
        }

        $this->deliverMessage($smsMessage);

        $this->logSentCount();
    }

    /**
     * Send one campaign's queued messages until the time or memory budget runs out.
     * The cursor is stored on the campaign, so actions carry only the campaign id.
     *
     * @param int $campaignId
     */
    public function handleSendBatch($campaignId)
    {
        if (!$this->isSystemOk()) {
            return;
        }

        $campaign = MessageCampaign::find($campaignId);

        if (!$campaign) {
            return;
        }

        if (in_array($campaign->status, ['paused', 'cancelled', 'draft', 'archived'])) {
            return;
        }

        if ($campaign->status == 'scheduled' && strtotime($campaign->scheduled_at) <= current_time('timestamp')) {
            $campaign->status = 'working';
            $campaign->save();
        }

        if (!in_array($campaign->status, ['working', 'scheduled'])) {
            return;
        }

        self::resetStuckProcessingMessages($this->maximumProcessingTime + 30, $campaignId);

        $cursor         = MessageCampaign::getCursor($campaignId)['send'];
        $claimedThisRun = 0;
        $stoppedEarly   = false;

        while (true) {
            $messages = Message::forCampaign($campaignId)
                ->where('id', '>', $cursor)
                ->whereIn('status', Message::CLAIMABLE)
                ->where('scheduled_at', '<=', current_time('mysql'))
                ->with(['thread', 'thread.subscriber'])
                ->orderBy('id', 'ASC')
                ->limit($this->sendingPerChunk)
                ->get();

            if ($messages->isEmpty()) {
                break;
            }

            foreach ($messages as $message) {
                $cursor = $message->id;

                if (self::claimMessage($message->id)) {
                    $claimedThisRun++;
                    $this->deliverMessage($message);
                }

                if ($this->outOfTimeOrMemory()) {
                    $stoppedEarly = true;
                    break;
                }
            }

            // Persisted per chunk, not per message.
            MessageCampaign::setCursor($campaignId, 'send', $cursor);

            if ($stoppedEarly) {
                break;
            }
        }

        $this->logSentCount();

        if ($stoppedEarly) {
            self::scheduleCampaignAction('fluentcrm_send_message_batch', $campaignId);
            return;
        }

        if (!$claimedThisRun) {
            // Another worker owns the remaining rows; rewind in case it releases them.
            MessageCampaign::setCursor($campaignId, 'send', 0);
        }

        $this->finishOrRetryLater($campaignId);
    }



    /**
     * Re-arm campaigns whose generation or sending stalled. Runs at most every 5 minutes.
     */
    public function handleHealthCheck()
    {
        if (!MessageModule::isAnyChannelActive()) {
            return;
        }

        $lastRun = fluentCrmGetOptionCache('_fcrm_sms_health_check_last', 360);
        if ($lastRun && (time() - $lastRun) < 300) {
            return;
        }
        fluentCrmSetOptionCache('_fcrm_sms_health_check_last', time(), 360);

        $now = current_time('timestamp');

        // Release abandoned claims first so the queries below see them as pending.
        $recovered = self::resetStuckProcessingMessages(600);
        if ($recovered) {
            Helper::debugLog('SMS Health Check', 'Returned ' . $recovered . ' abandoned messages to the queue');
        }

        // --- Recovery 1: stuck generation ---
        // Each generation batch stamps the campaign's updated_at, which serves as the liveness test.
        $genStuckThreshold  = date('Y-m-d H:i:s', $now - 600);  // not updated for 10 min
        $pastScheduleTime   = date('Y-m-d H:i:s', $now - 300);  // scheduled_at >5 min ago

        $stuckGenCampaigns = MessageCampaign::whereIn('status', ['processing', 'pending-scheduled'])
            ->whereIn('type', ['campaign', 'automation'])
            ->where('scheduled_at', '<', $pastScheduleTime)
            ->where(function ($q) use ($genStuckThreshold) {
                // A campaign still `pending-scheduled` past its send time never started.
                $q->where('status', 'pending-scheduled')
                    ->orWhere('updated_at', '<', $genStuckThreshold);
            })
            ->get(['id', 'status']);

        foreach ($stuckGenCampaigns as $campaign) {
            Helper::debugLog('SMS Health Check', 'Recovering stuck generation for campaign #' . $campaign->id . ' (status: ' . $campaign->status . ')');
            self::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaign->id);
        }

        // --- Recovery 2: stuck sending ---
        // Due messages exist but no message row has been touched for ten minutes.
        $sendStuckThreshold = date('Y-m-d H:i:s', $now - 600);
        $currentTime        = date('Y-m-d H:i:s', $now);

        $stuckSendCampaigns = MessageCampaign::whereIn('status', ['working', 'scheduled'])
            ->whereIn('type', ['campaign', 'automation'])
            ->where('scheduled_at', '<', $pastScheduleTime)
            ->whereHas('messages', function ($q) use ($currentTime) {
                $q->whereIn('status', [Message::STATUS_PENDING, Message::STATUS_SCHEDULED])
                    ->where('scheduled_at', '<=', $currentTime);
            })
            ->whereDoesntHave('messages', function ($q) use ($sendStuckThreshold) {
                $q->where('updated_at', '>', $sendStuckThreshold);
            })
            ->get(['id']);

        foreach ($stuckSendCampaigns as $campaign) {
            Helper::debugLog('SMS Health Check', 'Recovering stuck send for campaign #' . $campaign->id);
            self::scheduleCampaignAction('fluentcrm_send_message_batch', $campaign->id);
        }

        self::archiveCompletedCampaigns();
    }

    /**
     * When no ready messages remain: schedule for the next future message, archive, or wait on in-flight rows.
     */
    private function finishOrRetryLater($campaignId)
    {
        $nextMessage = Message::forCampaign($campaignId)
            ->whereIn('status', Message::CLAIMABLE)
            ->where('scheduled_at', '>', current_time('mysql'))
            ->orderBy('scheduled_at', 'ASC')
            ->first(['id', 'scheduled_at']);

        if ($nextMessage) {
            // get_gmt_from_date() needs the raw site-local string. Never sooner than 30s.
            self::scheduleCampaignAction(
                'fluentcrm_send_message_batch',
                $campaignId,
                max(time() + 30, (int) get_gmt_from_date($nextMessage->rawDate('scheduled_at'), 'U'))
            );

            return;
        }

        if (Message::forCampaign($campaignId)->whereIn('status', Message::UNFINISHED)->count()) {
            return;
        }

        $campaign = MessageCampaign::find($campaignId);

        if (!$campaign || !in_array($campaign->status, ['working', 'scheduled'])) {
            return;
        }

        MessageCampaign::where('id', $campaignId)->update([
            'status'     => 'archived',
            'updated_at' => current_time('mysql')
        ]);

        MessageCampaign::clearCursor($campaignId);

        $campaign = MessageCampaign::find($campaignId);

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_archived', $campaign);
        } else {
            do_action('fluent_crm/sms_campaign_archived', $campaign);
        }
    }

    /**
     * Whether the queue may run now. Also starts the time budget.
     */
    private function isSystemOk()
    {
        if (!MessageModule::isAnyChannelActive()) {
            return false;
        }

        $disabled = $this->applyFilterWithOldName(
            'fluent_crm/disable_message_processing',
            'fluent_crm/disable_sms_processing',
            false
        );

        if ($disabled) {
            return false;
        }

        $this->startingTimeStamp = time();

        if (memory_get_usage(true) >= (fluentCrmGetMemoryLimit() * 0.9)) {
            Helper::debugLog('SMS Scheduler Memory Exceeded', 'Memory Limit: ' . fluentCrmGetMemoryLimit() . ' | Current Usage: ' . memory_get_usage(true));
            return false;
        }

        return true;
    }

    /**
     * Send a single claimed message to its thread's number and record the outcome.
     */
    protected function deliverMessage($smsMessage)
    {
        try {
            $thread = $smsMessage->thread;

            if (!$thread) {
                $this->markFailed($smsMessage, 'Message has no conversation thread');
                return;
            }

            // The contact a message is about: recorded on the message for alerts to a custom
            // number, otherwise the thread's contact.
            $meta = is_array($smsMessage->meta) ? $smsMessage->meta : [];
            $subscriber = !empty($meta['render_contact_id'])
                ? (Subscriber::find((int) $meta['render_contact_id']) ?: $thread->subscriber)
                : $thread->subscriber;

            $phoneNumber = $thread->phone_number ?: ($subscriber ? $subscriber->phone : null);

            if (!$phoneNumber) {
                $this->markFailed($smsMessage, 'No valid phone number');
                return;
            }

            if (!$subscriber && !$this->isAuthorizedOneTimeMessage($smsMessage, $thread)) {
                $this->markFailed($smsMessage, 'Subscriber not found');
                return;
            }

            $channelSlug = $thread->channel ?: LegacyMessage::CHANNEL_SMS;
            $channel     = MessageModule::channel($channelSlug);

            // Never fall back to SMS for an unknown channel; that would breach consent.
            if (!$channel) {
                $this->markFailed($smsMessage, 'Unknown message channel: ' . $channelSlug);
                return;
            }

            // Consent is enforced only for the contact's own saved number; custom target numbers are sent.
            // The one exemption is the opt-out confirmation itself: it is queued after consent is
            // already withdrawn and would otherwise always be refused. The check reads the event
            // from meta, which a manual resend does not copy, so a resent copy is gated normally.
            if (
                $subscriber &&
                $subscriber->phone &&
                $phoneNumber === $subscriber->phone &&
                !$this->isOptOutConfirmation($smsMessage)
            ) {
                if (!MessageThread::contactCanReceive($channelSlug, $subscriber->id)) {
                    $this->markFailed(
                        $smsMessage,
                        'Contact is not subscribed for ' . $channel->getLabel()
                    );
                    return;
                }
            }

            $result = $channel->sendQueued($smsMessage, $subscriber, $phoneNumber);

            if ($result && isset($result['status']) && $result['status'] === 'success') {
                $this->markSent($smsMessage, $result);
                Helper::debugLog($channel->getLabel() . ' Sent', 'Phone: ' . $phoneNumber . ' | Message: ' . $smsMessage->id . ' | Result: ' . wp_json_encode($result));
                $this->sentCount++;
                $channel->onSent($smsMessage, $result);
            } else {
                Helper::debugLog($channel->getLabel() . ' Send Failed', 'Phone: ' . $phoneNumber . ' | Message: ' . $smsMessage->id . ' | Result: ' . wp_json_encode($result));
                $errorMessage = isset($result['message']) ? $result['message'] : 'Unknown error';
                $this->markFailed($smsMessage, $errorMessage);
                $channel->onFailed($smsMessage, $errorMessage);
            }

        } catch (\Exception $e) {
            $this->markFailed($smsMessage, $e->getMessage());
            Helper::debugLog('SMS Send Exception', $e->getMessage(), 'error');
        }
    }

    /**
     * Whether the message is the system's own opt-out confirmation, as queued by
     * SMSHelper: the status-confirmation ref type with an `opt_out` event in meta.
     */
    protected function isOptOutConfirmation($smsMessage)
    {
        if ($smsMessage->ref_type !== SMSHelper::CONFIRMATION_REF_TYPE) {
            return false;
        }

        $meta = is_array($smsMessage->meta) ? $smsMessage->meta : [];

        return Arr::get($meta, 'event') === 'opt_out';
    }

    protected function isAuthorizedOneTimeMessage($smsMessage, MessageThread $thread)
    {
        $recipient = SMSHelper::oneTimeRecipientContext($smsMessage);
        if (!$recipient || !$smsMessage->ref_id || $smsMessage->ref_type !== Message::REF_CAMPAIGN) {
            return false;
        }

        if ($thread->status !== 'subscribed') {
            return false;
        }

        if ((string) ($recipient['phone_number'] ?? '') !== (string) $thread->phone_number) {
            return false;
        }

        $campaign = MessageCampaign::find((int) $smsMessage->ref_id);
        if (!$campaign || Arr::get($campaign->settings, 'sending_filter') !== 'one_time') {
            return false;
        }

        if (($thread->channel ?: LegacyMessage::CHANNEL_SMS) !== ($campaign->channel ?: LegacyMessage::CHANNEL_SMS)) {
            return false;
        }

        return OneTimeAudienceMeta::hasConfirmedConsent($campaign)
            && OneTimeAudienceMeta::getActiveBatchId($campaign) === (string) ($recipient['batch_id'] ?? '');
    }

    /**
     * Whether the time budget or 90% of the memory limit has been reached.
     */
    protected function outOfTimeOrMemory()
    {
        return (time() - $this->startingTimeStamp) >= $this->maximumProcessingTime
            || memory_get_usage(true) >= (fluentCrmGetMemoryLimit() * 0.9);
    }


    /**
     * Mark SMS as sent.
     */
    protected function markSent($smsMessage, $result)
    {
        $updateData = [
            'status'     => Message::STATUS_SENT,
            'sent_at'    => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];

        if (isset($result['provider_message_id'])) {
            $updateData['provider_message_id'] = $result['provider_message_id'];
        }

        Message::where('id', $smsMessage->id)->update($updateData);

        if ($smsMessage->ref_id) {
            MessageCampaign::where('id', $smsMessage->ref_id)
                ->increment('sent_count');
        }

        // Sync the model with the query-builder update before the hook fires.
        foreach ($updateData as $field => $value) {
            $smsMessage->{$field} = $value;
        }

        $channelSlug = ($smsMessage->thread ? $smsMessage->thread->channel : '') ?: LegacyMessage::CHANNEL_SMS;

        do_action('fluent_crm/' . $channelSlug . '_sent', $smsMessage, $result);
    }

    /**
     * Mark SMS as failed.
     */
    protected function markFailed($smsMessage, $errorMessage)
    {
        // Merged into existing meta so queue-time values survive.
        $meta = is_array($smsMessage->meta) ? $smsMessage->meta : [];
        $meta['error_message'] = $errorMessage;

        Message::where('id', $smsMessage->id)->update([
            'status'     => Message::STATUS_FAILED,
            'meta'       => \maybe_serialize($meta),
            'updated_at' => current_time('mysql')
        ]);

        if ($smsMessage->ref_id) {
            MessageCampaign::where('id', $smsMessage->ref_id)
                ->increment('failed_count');
        }

        $smsMessage->status = Message::STATUS_FAILED;
        $smsMessage->meta = $meta;

        $channelSlug = ($smsMessage->thread ? $smsMessage->thread->channel : '') ?: LegacyMessage::CHANNEL_SMS;

        do_action('fluent_crm/' . $channelSlug . '_failed', $smsMessage, $errorMessage);
    }

    /**
     * Parse message content with subscriber data.
     *
     * @deprecated Use SMSHelper::parseMessageContent() directly.
     */
    public function parseMessageContent($content, $subscriber)
    {
        return SMSHelper::parseMessageContent($content, $subscriber);
    }



    /**
     * Log sent count.
     */
    protected function logSentCount()
    {
        if ($this->sentCount > 0) {
            Helper::debugLog('SMS Sent Count', $this->sentCount . ' SMS messages sent');
        }
    }

    /**
     * Mark completed SMS campaigns as archived.
     */
    public static function archiveCompletedCampaigns()
    {
        $smsCampaigns = MessageCampaign::whereIn('status', ['working', 'scheduled'])
            ->whereDoesntHave('messages', function ($query) {
                $query->whereIn('status', array_merge(Message::UNFINISHED, ['draft']));
                return $query;
            })
            ->withoutGlobalScope('type')
            ->whereIn('type', ['campaign', 'automation'])
            ->where('scheduled_at', '<', date('Y-m-d H:i:s', current_time('timestamp') - 300))
            ->get();

        if (!$smsCampaigns->isEmpty()) {
            MessageCampaign::whereIn('id', array_unique($smsCampaigns->pluck('id')->toArray()))
                ->withoutGlobalScope('type')
                ->update([
                    'status' => 'archived'
                ]);

            foreach ($smsCampaigns as $smsCampaign) {
                MessageCampaign::clearCursor($smsCampaign->id);
                if ($smsCampaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
                    do_action('fluent_crm/whatsapp_campaign_archived', $smsCampaign);
                } else {
                    do_action('fluent_crm/sms_campaign_archived', $smsCampaign);
                }
            }

            return true;
        }

        return false;
    }

    /**
     * Seconds a provider call may take inline. A timed-out send is marked failed and not retried,
     * because the provider may still have accepted it and a duplicate is worse than a false failure.
     */
    const INLINE_SEND_TIMEOUT = 5;

    /**
     * Write a message and send it in this request. Returns the row after the attempt.
     *
     * @param string $channel sms|whatsapp
     * @param string $phone the number to message
     * @param int|null $contactId
     * @param string $body rendered message body
     * @param array $extra ref_type, ref_id, template_id, meta
     * @return Message|null null when the number is unusable
     */
    public static function sendNow(string $channel, string $phone, $contactId, string $body, array $extra = [])
    {
        $message = MessageThread::queueOutbound($channel, $phone, $contactId, $body, $extra);

        if (!$message) {
            return null;
        }

        static::dispatch($message->id);

        return Message::find($message->id) ?: $message;
    }

    /**
     * Send one already-written message in this request through handleSendSingleMessage().
     *
     * @param int $messageId
     */
    public static function dispatch($messageId): void
    {
        $messageId = (int) $messageId;

        if (!$messageId) {
            return;
        }

        // Cap the provider timeout for inline sends; a lower site value is kept.
        $inlineTimeout = max(1, (int) apply_filters('fluent_crm/message_inline_send_timeout', self::INLINE_SEND_TIMEOUT));

        $capTimeout = function ($timeout) use ($inlineTimeout) {
            return min((int) $timeout, $inlineTimeout);
        };

        add_filter('fluent_crm/message_send_timeout', $capTimeout, 99);

        try {
            (new static())->handleSendSingleMessage($messageId);
        } finally {
            remove_filter('fluent_crm/message_send_timeout', $capTimeout, 99);
        }
    }
}
