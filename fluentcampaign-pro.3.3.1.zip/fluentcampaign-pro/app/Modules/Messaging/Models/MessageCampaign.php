<?php

namespace FluentCampaign\App\Modules\Messaging\Models;

use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceMeta;
use FluentCrm\App\Models\Label;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCrm\App\Models\Meta;
use FluentCrm\App\Models\Model;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Models\TermRelation;
use FluentCrm\App\Services\ContactsQuery;
use FluentCrm\Framework\Support\Arr;
use FluentCampaign\App\Modules\Messaging\MessageModule;
use FluentCampaign\App\Services\ProHelper;

/**
 * @property int $id
 * @property int|null $parent_id
 * @property string $type
 * @property string $title
 * @property string $slug
 * @property string $status
 * @property string $message_content
 * @property string|null $sender_number
 * @property int $recipients_count
 * @property int $sent_count
 * @property int $failed_count
 * @property int|null $delay
 * @property string|null $scheduled_at
 * @property array|null $settings
 * @property int|null $created_by
 * @property string $created_at
 * @property string $updated_at
 */
class MessageCampaign extends Model
{
    protected $table = 'fc_sms_campaigns';

    /**
     * Recipient generation could not complete; the reason is stored in `_one_time_generation_error` meta.
     */
    const STATUS_FAILED = 'failed';

    protected $fillable = [
        'parent_id',
        'type', // [ 'campaign', 'custom-sms', 'automation' ..]
        'title',
        'slug',
        'status',  // [ 'draft', 'pending-scheduled', 'processing', 
        'message_content',
        'sender_number',
        'recipients_count',
        'sent_count',
        'failed_count',
        'delay',
        'scheduled_at',
        'settings',
        'channel',       // 'sms' | 'whatsapp'
        'created_by'
    ];

    protected $casts = [
        'id' => 'integer',
        'parent_id' => 'integer',
        'recipients_count' => 'integer',
        'sent_count' => 'integer',
        'failed_count' => 'integer',
        'delay' => 'integer',
        'created_by' => 'integer'
    ];

    protected $dates = [
        'scheduled_at',
        'created_at',
        'updated_at'
    ];

    // Type constants
    const TYPE_SMS = 'sms';

    // Channel constants
    const CHANNEL_SMS      = 'sms';
    const CHANNEL_WHATSAPP = 'whatsapp';

    /**
     * Discriminator stored in fc_meta, fc_term_relations and fc_subscriber_pivot for this model.
     * Persisted data frozen at the original class name and hardcoded in the free plugin's
     * fluentcrm_get_sms_campaign_meta(). Never replace with self::class.
     */
    const OBJECT_TYPE = 'FluentCampaign\App\Modules\SMS\Models\SMSCampaign';

    /**
     * Option-name prefix for each campaign's generate/send resume cursor (not autoloaded).
     * The cursor is only an optimisation; per-message claims prevent duplicate sends.
     */
    const CURSOR_OPTION_PREFIX = '_fc_message_cursor_';


    /**
     * @return array{gen:int,send:int}
     */
    public static function getCursor($campaignId): array
    {
        $cursor = get_option(self::CURSOR_OPTION_PREFIX . (int) $campaignId, []);

        if (!is_array($cursor)) {
            $cursor = [];
        }

        return [
            'gen'  => isset($cursor['gen']) ? (int) $cursor['gen'] : 0,
            'send' => isset($cursor['send']) ? (int) $cursor['send'] : 0,
        ];
    }

    /**
     * @param string $phase gen|send
     */
    public static function setCursor($campaignId, string $phase, $id): void
    {
        $cursor = self::getCursor($campaignId);
        $cursor[$phase] = (int) $id;

        update_option(self::CURSOR_OPTION_PREFIX . (int) $campaignId, $cursor, 'no');
    }

    /**
     * Delete the cursor option. Call on archive, unschedule and delete.
     */
    public static function clearCursor($campaignId): void
    {
        delete_option(self::CURSOR_OPTION_PREFIX . (int) $campaignId);
    }



    protected static $type = 'campaign';

    /**
     * Resolve this campaign's channel. Empty means SMS; an unknown value throws.
     *
     * @return \FluentCampaign\App\Modules\Messaging\Contracts\ChannelInterface
     * @throws \InvalidArgumentException
     */
    public function resolveChannel()
    {
        $slug = $this->channel ?: self::CHANNEL_SMS;

        $channel = MessageModule::channel($slug);

        if (!$channel) {
            throw new \InvalidArgumentException(
                'Unknown message channel for campaign ' . $this->id . ': ' . $slug
            );
        }

        return $channel;
    }

    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $model->status = $model->status ?: 'draft';
            $model->type = $model->type ?: self::$type;
            $model->slug = $model->slug ?: sanitize_title($model->title, '', 'preview');
            $model->created_by = $model->created_by ?: get_current_user_id();
            $model->settings = $model->settings ?: [
                'subscribers' => [
                    [
                        'list' => 'all',
                        'tag'  => 'all'
                    ]
                ],
                'excludedSubscribers' => [
                    [
                        'list' => null,
                        'tag'  => null
                    ]
                ],
                'sending_filter'    => 'list_tag',
                'dynamic_segment'  => [
                    'id'   => '',
                    'slug' => ''
                ],
                'advanced_filters' => [
                    []
                ],
                'sending_type'     => 'instant',
                'is_transactional' => 'no'
            ];
        });
    }

    /**
     * This campaign's messages in fc_messages, matched on both ref_id and ref_type.
     */
    public function messages()
    {
        return $this->hasMany(Message::class, 'ref_id', 'id')
            ->whereIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
    }

    /**
     * The `ref_type` for this campaign's messages: automation, or campaign for every other type.
     */
    public function messageRefType()
    {
        return $this->type === 'automation' ? Message::REF_AUTOMATION : Message::REF_CAMPAIGN;
    }

    /**
     * Scope for filtering by status
     */
    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope for filtering by type
     */
    public function scopeByType($query, $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Scope for filtering by date range
     */
    public function scopeByDateRange($query, $startDate, $endDate = null)
    {
        $query->where('created_at', '>=', $startDate);
        
        if ($endDate) {
            $query->where('created_at', '<=', $endDate);
        }

        return $query;
    }

    public function setSettingsAttribute($settings)
    {
        $this->attributes['settings'] = \maybe_serialize($settings);
    }

    public function getSettingsAttribute($settings)
    {
        return ProHelper::safeUnserialize($settings);
    }

    /**
     * Get success rate percentage
     */
    public function getSuccessRateAttribute()
    {
        if ($this->sent_count === 0) {
            return 0;
        }

        $successCount = $this->sent_count - $this->failed_count;
        return round(($successCount / $this->sent_count) * 100, 2);
    }

    /**
     * Get failure rate percentage
     */
    public function getFailureRateAttribute()
    {
        if ($this->sent_count === 0) {
            return 0;
        }

        return round(($this->failed_count / $this->sent_count) * 100, 2);
    }

    /**
     * Get progress percentage
     */
    public function getProgressAttribute()
    {
        if ($this->recipients_count === 0) {
            return 0;
        }

        return round(($this->sent_count / $this->recipients_count) * 100, 2);
    }

    /**
     * Get remaining recipients count
     */
    public function getRemainingCountAttribute()
    {
        return max(0, $this->recipients_count - $this->sent_count);
    }

    /**
     * Get truncated message content
     */
    public function getShortMessageAttribute($length = 100)
    {
        if (!$this->message_content) {
            return null;
        }

        if (strlen($this->message_content) <= $length) {
            return $this->message_content;
        }

        return substr($this->message_content, 0, $length) . '...';
    }

    /**
     * Get message character count
     */
    public function getMessageLengthAttribute()
    {
        return strlen($this->message_content ?? '');
    }

    /**
     * Get estimated SMS segments per message
     */
    public function getEstimatedSegmentsAttribute()
    {
        $length = $this->getMessageLengthAttribute();
        
        if ($length <= 160) {
            return 1;
        }

        // For multipart SMS, each segment can contain 153 characters
        return ceil($length / 153);
    }

    /**
     * Get total estimated segments for all recipients
     */
    public function getTotalEstimatedSegmentsAttribute()
    {
        return $this->getEstimatedSegmentsAttribute() * $this->recipients_count;
    }

    /**
     * Increment sent count
     */
    public function incrementSentCount($amount = 1)
    {
        $this->increment('sent_count', $amount);
        return $this;
    }

    /**
     * Increment failed count
     */
    public function incrementFailedCount($amount = 1)
    {
        $this->increment('failed_count', $amount);
        return $this;
    }

    /**
     * Update recipients count
     */
    public function updateRecipientsCount($count)
    {
        $this->update(['recipients_count' => $count]);
        return $this;
    }

    /**
     * Generate unique slug
     */
    public function generateSlug($title)
    {
        $slug = sanitize_title($title);
        $originalSlug = $slug;
        $counter = 1;

        while (static::where('slug', $slug)->where('id', '!=', $this->id ?? 0)->exists()) {
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    /**
     * Static method to create SMS campaign
     */
    public static function createCampaign($data)
    {
        $campaign = new static();
        
        $slug = $campaign->generateSlug($data['title']);

        return static::create([
            'parent_id' => $data['parent_id'] ?? null,
            'type' => $data['type'] ?? self::TYPE_SMS,
            'title' => $data['title'],
            'slug' => $slug,
            'status' => $data['status'] ?? 'draft',
            'message_content' => $data['message_content'],
            'sender_number' => $data['sender_number'] ?? null,
            'recipients_count' => $data['recipients_count'] ?? 0,
            'delay' => $data['delay'] ?? 0,
            'scheduled_at' => $data['scheduled_at'] ?? null,
            'settings' => $data['settings'] ?? [],
            'created_by' => $data['created_by'] ?? get_current_user_id()
        ]);
    }

    /**
     * Get campaign statistics
     */
    public function getStatistics()
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'status' => $this->status,
            'recipients_count' => $this->recipients_count,
            'sent_count' => $this->sent_count,
            'failed_count' => $this->failed_count,
            'success_rate' => $this->getSuccessRateAttribute(),
            'failure_rate' => $this->getFailureRateAttribute(),
            'progress' => $this->getProgressAttribute(),
            'remaining_count' => $this->getRemainingCountAttribute(),
            'message_length' => $this->getMessageLengthAttribute(),
            'estimated_segments' => $this->getEstimatedSegmentsAttribute(),
            'total_estimated_segments' => $this->getTotalEstimatedSegmentsAttribute(),
            'created_at' => $this->created_at,
            'scheduled_at' => $this->scheduled_at
        ];
    }

    public function getSubscriberIdsCountBySegmentSettings($settings, $status = 'subscribed')
    {
        $model = $this->getSubscribersModel($settings);
        if ($model) {
            return $model->count();
        }

        return 0;
    }

    public function getSubscribersModel($settings = false)
    {
        if (!$settings) {
            $settings = $this->settings;
        }

        $filterType = Arr::get($settings, 'sending_filter', 'list_tag');

        if ($filterType == 'list_tag') {
            $channel = $this->resolveChannel();

            $subscriberModel = $this->getSubscribeIdsByListModel($settings['subscribers'], $channel->getSlug());
            if ($excludeItems = Arr::get($settings, 'excludedSubscribers')) {
                $formattedExcludedItems = [];
                foreach ($excludeItems as $item) {
                    if (empty($item['list']) && empty($item['tag'])) {
                        continue;
                    }
                    $formattedExcludedItems[] = $item;
                }

                if ($formattedExcludedItems) {
                    $excludedModel = $this->getSubscribeIdsByListModel($formattedExcludedItems, $channel->getSlug());
                    $excludedModel->select('id');
                    $subscriberModel->whereNotIn('id', $excludedModel->getQuery());
                }
            }

            return $subscriberModel;
        }

        if ($filterType == 'dynamic_segment') {
            $segmentSettings = Arr::get($settings, 'dynamic_segment', []);
            $segmentSettings['offset'] = 0;
            $segmentSettings['limit'] = false;

            /**
             * Filter the dynamic segment details based on the segment slug.
             *
             * This filter allows you to modify the details of a dynamic segment.
             *
             * @param array  The details of the dynamic segment.
             * @param int $segmentSettings ['id']      The ID of the segment.
             * @param array {
             *     Additional context for the segment.
             *
             * @type bool  Whether to include the model in the context.
             * }
             *
             * @return array Modified segment details.
             * @since 2.5.93
             *
             */
            $segmentDetails = apply_filters('fluentcrm_dynamic_segment_' . $segmentSettings['slug'], [], $segmentSettings['id'], [
                'model' => true
            ]);

            if (!empty($segmentDetails['model'])) {
                $model = $segmentDetails['model'];

                MessageThread::applyConsentFilter($model, $this->resolveChannel()->getSlug());

                return $model;
            }

            return null;
        }

        if ($filterType == 'advanced_filters') {
            $query = new ContactsQuery([
                'with'               => [],
                'filter_type'        => 'advanced',
                'contact_status'     => 'subscribed',
                'filters_groups_raw' => $settings['advanced_filters']
            ]);

            return MessageThread::applyConsentFilter($query->getModel(), $this->resolveChannel()->getSlug());
        }

        return null;
    }

    /**
     * @param array  $items   list/tag selection groups
     * @param string $channel channel slug the audience is being built for
     * @param int|false $limit
     * @param int    $offset
     */
    public function getSubscribeIdsByListModel($items, $channel = 'sms', $limit = false, $offset = 0)
    {
        $query = MessageThread::applyConsentFilter(Subscriber::query(), $channel);

        $queryGroups = [];

        $willSkip = false;

        $hasListFilter = false;
        $tagIds = [];
        foreach ($items as $item) {
            $listId = Arr::get($item, 'list');
            $tagId = Arr::get($item, 'tag');

            // As in the email builder: a single empty side means 'all'; a row with both empty is skipped.
            if (!$listId && !$tagId) {
                continue;
            }
            if (!$listId) {
                $listId = 'all';
            }
            if (!$tagId) {
                $tagId = 'all';
            }

            if ($listId == 'all' && $tagId == 'all') {
                $willSkip = true;
            } else if ($listId == 'all') {
                $queryGroups[] = ['tag_id' => $tagId];
                $tagIds[] = $tagId;
            } else if ($tagId == 'all') {
                $hasListFilter = true;
                $queryGroups[] = ['list_id' => $listId];
            } else {
                $hasListFilter = true;
                $tagIds[] = $tagId;
                $queryGroups[] = [
                    'list_id' => $listId,
                    'tag_id'  => $tagId
                ];
            }
        }

        if (!$willSkip && !$hasListFilter && !$queryGroups && !$tagIds) {
            // Fail closed when no valid targeting row exists.
            $query->whereRaw('1 = 0');
        } else if (!$willSkip && !$hasListFilter && $tagIds) {
            $query->filterByTags($tagIds);
        } else if (!$willSkip && $queryGroups) {
            $query->where(function ($innerQuery) use ($queryGroups) {
                $type = 'where';
                foreach ($queryGroups as $queryGroup) {
                    $innerQuery->{$type}(function ($q) use ($queryGroup, $innerQuery) {
                        foreach ($queryGroup as $type => $id) {
                            if ($type == 'tag_id') {
                                $q->whereIn('id', function ($query) use ($id) {
                                    return $this->getSubQueryForListOrTagFilter($query, [$id], 'tags', 'FluentCrm\App\Models\Tag');
                                });
                            } else if ($type == 'list_id') {
                                $q->whereIn('id', function ($query) use ($id) {
                                    return $this->getSubQueryForListOrTagFilter($query, [$id], 'lists', 'FluentCrm\App\Models\Lists');
                                });
                            }
                        }
                    });

                    $type = 'orWhere';
                }
            });
        }

        if ($limit) {
            $query->limit($limit)->offset($offset);
        }

        return $query;
    }

    private function getSubQueryForListOrTagFilter($query, $ids, $table, $objectType)
    {
        $prefix = 'fc_';

        return $query->from($prefix . $table)
                     ->join(
                         $prefix . 'subscriber_pivot',
                         $prefix . 'subscriber_pivot.object_id',
                         '=',
                         $prefix . $table . '.id'
                     )
                     ->where($prefix . 'subscriber_pivot.object_type', $objectType)
                     ->whereIn($prefix . $table . '.id', $ids)
                     ->groupBy($prefix . 'subscriber_pivot.subscriber_id')
                     ->select($prefix . 'subscriber_pivot.subscriber_id');
    }

    /**
     * Queue campaign messages for subscribers in bulk via MessageThread::recordMessages().
     * Returns only the ids a row was actually written for.
     *
     * @param array $subscriberIds
     * @param array $smsArgs status, scheduled_at, settings
     * @param bool $isModel if the $subscriberIds is collection or not
     * @return array subscriber ids a message row was created for
     */
    public function subscribe($subscriberIds, $smsArgs = [], $isModel = false)
    {
        if ($isModel) {
            $subscribers = $subscriberIds;
        } else {
            $subscribers = \FluentCrm\App\Models\Subscriber::whereIn('id', $subscriberIds)->get();
        }

        $channelObject = $this->resolveChannel();
        $channel       = $channelObject->getSlug();

        $subscriberIdsInBatch = [];
        foreach ($subscribers as $subscriber) {
            $subscriberIdsInBatch[] = $subscriber->id;
        }

        $blocked = MessageThread::blockedContactIds($channel, $subscriberIdsInBatch);

        $meta = [];
        if (isset($smsArgs['settings']) && is_array($smsArgs['settings'])) {
            $meta['settings'] = $smsArgs['settings'];
        }

        $refType = $this->messageRefType();

        // Keyed by subscriber id so recordMessages() reports which contacts got a row.
        $items = [];

        foreach ($subscribers as $subscriber) {
            if (isset($blocked[(int) $subscriber->id])) {
                continue;
            }

            if (empty($subscriber->phone)) {
                continue;
            }

            $items[$subscriber->id] = [
                'channel'      => $channel,
                'phone'        => $subscriber->phone,
                'contact_id'   => $subscriber->id,
                'direction'    => Message::DIRECTION_OUTBOUND,
                'content'      => $this->message_content,
                'ref_id'       => $this->id,
                'ref_type'     => $refType,
                'status'       => isset($smsArgs['status']) ? $smsArgs['status'] : $this->status,
                'scheduled_at' => isset($smsArgs['scheduled_at']) ? $smsArgs['scheduled_at'] : null,
                'meta'         => $meta
            ];
        }

        $subscribedIds = $items ? MessageThread::recordMessages($items) : [];

        $messageCount = $this->getMessageCount();
        if ($messageCount != $this->recipients_count) {
            $this->recipients_count = $messageCount;
            $this->save();
        }

        return $subscribedIds;
    }

    /**
     * Remove one or more subscribers from the SMS campaign
     * @param array $subscriberIds
     * @return bool
     */
    public function unsubscribe($subscriberIds)
    {
        $threadIds = MessageThread::whereIn('contact_id', (array) $subscriberIds)
            ->pluck('id')
            ->toArray();

        if (!$threadIds) {
            return 0;
        }

        $result = $this->messages()->whereIn('thread_id', $threadIds)->delete();

        $this->recipients_count = $this->messages()->count();
        $this->save();

        return $result;
    }

    /**
     * Get the total count of SMS messages for this campaign
     * @return int
     */
    public function getMessageCount()
    {
        return $this->messages()->count();
    }

    public function deleteCampaignData()
    {
        self::clearCursor($this->id);

        $this->messages()->delete();

        Meta::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->delete();

        return $this;
    }

    public function labelsTerm()
    {
        return $this->belongsToMany(
            Label::class,
            'fc_term_relations',
            'object_id',
            'term_id'
        )->wherePivot('object_type', self::OBJECT_TYPE);
    }

    public function getFormattedLabels()
    {
        $labels = $this->labels();
        return $labels->map(function ($label) {
            return [
                'id'    => $label->id,
                'slug'  => $label->slug,
                'title' => $label->title,
                'color' => $label->settings['color'] ?? ''
            ];
        });
    }

    public function labels()
    {
        $labelIds = TermRelation::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->pluck('term_id')
            ->toArray();

        if (empty($labelIds)) {
            return Label::whereRaw('1 = 0')->get();
        }

        return Label::whereIn('id', $labelIds)->get();
    }

    public function attachLabels($labelIds)
    {
        $labelIds = is_array($labelIds) ? $labelIds : [$labelIds];
        $labelIds = array_values(array_unique(array_filter(array_map('intval', $labelIds))));

        if (empty($labelIds)) {
            return $this;
        }

        $existingLabelIds = TermRelation::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->pluck('term_id')
            ->map(function ($id) {
                return (int)$id;
            })
            ->toArray();

        $newLabelIds = array_diff($labelIds, $existingLabelIds);

        foreach ($newLabelIds as $labelId) {
            TermRelation::create([
                'object_id'   => $this->id,
                'object_type' => self::OBJECT_TYPE,
                'term_id'     => $labelId
            ]);
        }

        return $this;
    }

    public function detachLabels($labelIds)
    {
        $labelIds = is_array($labelIds) ? $labelIds : [$labelIds];
        $labelIds = array_values(array_unique(array_filter(array_map('intval', $labelIds))));

        if (empty($labelIds)) {
            return $this;
        }

        TermRelation::where('object_id', $this->id)
            ->where('object_type', self::OBJECT_TYPE)
            ->whereIn('term_id', $labelIds)
            ->delete();

        return $this;
    }

    /**
     * The campaign's scheduled_at, which every message shares.
     */
    public function getScheduledAt()
    {
        // The raw string: the $dates cast returns a DateTime, which prepare() writes as ''.
        return $this->getAttributes()['scheduled_at'] ?? null;
    }


    public function maybeDeleteDuplicates() // sms campaign duplicates messages
    {
        // Duplicates are grouped by thread, which also catches contacts sharing a number.
        $duplicates = fluentCrmDb()->table('fc_messages')
                                   ->where('ref_id', $this->id)
                                   ->whereIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION])
                                   ->select([fluentCrmDb()->raw('MIN(`id`) AS min_id'), 'thread_id', fluentCrmDb()->raw('COUNT(thread_id) as count')])
                                   ->groupBy('thread_id')
                                   ->havingRaw('COUNT(thread_id) > ?', [1])
                                   ->get();

        if ($duplicates->isEmpty()) {
            return $this;
        }

        $threadIds = [];
        $exceptIds = [];
        foreach ($duplicates as $duplicate) {
            $threadIds[] = $duplicate->thread_id;
            $exceptIds[] = $duplicate->min_id;
        }

        fluentCrmDb()->table('fc_messages')
                     ->where('ref_id', $this->id)
                     ->whereIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION])
                     ->whereIn('thread_id', $threadIds)
                     ->whereNotIn('id', $exceptIds)
                     ->delete();

        $messageCount = $this->getMessageCount();
        if ($messageCount != $this->recipients_count) {
            $this->recipients_count = $messageCount;
            $this->save();
        }

        return $this;
    }
}
