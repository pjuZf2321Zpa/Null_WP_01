<?php

namespace FluentCampaign\App\Modules\Messaging\Models;

use FluentCrm\App\Models\Model;
use FluentCampaign\App\Services\ProHelper;

/**
 * One inbound or outbound message on a thread. The channel is read from the thread.
 *
 * @package FluentCrm\App\Models
 */
class Message extends Model
{
    protected $table = 'fc_messages';

    protected $guarded = ['id'];

    protected $searchable = [
        'content'
    ];

    protected $casts = [
        'id'         => 'integer',
        'thread_id'  => 'integer',
        'ref_id'     => 'integer',
        'created_by' => 'integer'
    ];

    protected $dates = [
        'scheduled_at',
        'sent_at',
        'created_at',
        'updated_at'
    ];

    const DIRECTION_INBOUND = 'inbound';
    const DIRECTION_OUTBOUND = 'outbound';

    /**
     * `ref_type` values whose `ref_id` is an fc_sms_campaigns id.
     */
    const REF_CAMPAIGN = 'campaign';
    const REF_AUTOMATION = 'automation';

    /**
     * `ref_type` for a message an operator composed in the inbox.
     */
    const REF_INBOX = 'inbox';

    /**
     * Queue states (scheduling, scheduled, pending, processing), then terminal states.
     */
    const STATUS_SCHEDULING = 'scheduling';
    const STATUS_SCHEDULED = 'scheduled';
    const STATUS_PENDING = 'pending';
    const STATUS_PROCESSING = 'processing';
    const STATUS_SENT = 'sent';
    const STATUS_DELIVERED = 'delivered';
    const STATUS_READ = 'read';
    const STATUS_FAILED = 'failed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_RECEIVED = 'received';

    /**
     * Delivery receipt rank; Meta receipts can arrive out of order and must not move status backwards.
     */
    const DELIVERY_RANK = [
        self::STATUS_SENT      => 1,
        self::STATUS_DELIVERED => 2,
        self::STATUS_READ      => 3
    ];

    /**
     * Statuses of a message that went out. WhatsApp receipts move `sent` on to `delivered` and
     * `read` in the same column, so "sent" counts and filters must include them.
     */
    const SENT_STATUSES = [self::STATUS_SENT, self::STATUS_DELIVERED, self::STATUS_READ];

    /**
     * Statuses of a message that reached the recipient's device.
     */
    const DELIVERED_STATUSES = [self::STATUS_DELIVERED, self::STATUS_READ];

    /**
     * Statuses a runner may claim once `scheduled_at` has passed.
     */
    const CLAIMABLE = [self::STATUS_PENDING, self::STATUS_SCHEDULED];

    /**
     * Statuses that mean a campaign still has work outstanding.
     */
    const UNFINISHED = [
        self::STATUS_SCHEDULING,
        self::STATUS_PENDING,
        self::STATUS_SCHEDULED,
        self::STATUS_PROCESSING
    ];

    /**
     * Messages of one campaign or automation, matched on both ref_id and ref_type.
     *
     * @param int $campaignId
     */
    public function scopeForCampaign($query, $campaignId)
    {
        return $query->where('ref_id', (int) $campaignId)
            ->whereIn('ref_type', [self::REF_CAMPAIGN, self::REF_AUTOMATION]);
    }

    /**
     * Messages whose serialized meta references a template id (LIKE over the blob; not for hot paths).
     * Only matches the integer form, so a miss means "probably unused", not proof.
     *
     * @param int $templateId
     */
    public function scopeUsingTemplate($query, $templateId)
    {
        global $wpdb;

        $needle = 's:11:"template_id";i:' . (int) $templateId . ';';

        return $query->where('meta', 'LIKE', '%' . $wpdb->esc_like($needle) . '%');
    }

    /**
     * The stored string of a date column, instead of the DateTime the `$dates` cast returns.
     *
     * @param string $column
     * @return string|null
     */
    public function rawDate($column)
    {
        $value = $this->getAttributes()[$column] ?? null;

        return ($value === null || $value === '') ? null : (string) $value;
    }

    /**
     * `meta` is PHP-serialized, like MessageThread::meta.
     */
    public function setMetaAttribute($meta)
    {
        $this->attributes['meta'] = \maybe_serialize($meta);
    }

    public function getMetaAttribute($meta)
    {
        $meta = ProHelper::safeUnserialize($meta);

        return is_array($meta) ? $meta : [];
    }

    public function oneTimeRecipientContext()
    {
        $recipient = $this->meta['one_time_recipient'] ?? [];

        return is_array($recipient) ? $recipient : [];
    }

    public function thread()
    {
        return $this->belongsTo(MessageThread::class, 'thread_id', 'id');
    }

    public function scopeInbound($query)
    {
        return $query->where('direction', self::DIRECTION_INBOUND);
    }

    /**
     * Conversation order on COALESCE(sent_at, scheduled_at, created_at); must match the rail's sort.
     */
    public function scopeConversationOrder($query, $direction = 'ASC')
    {
        return $query->orderByRaw('COALESCE(sent_at, scheduled_at, created_at) ' . ($direction === 'DESC' ? 'DESC' : 'ASC'));
    }
}
