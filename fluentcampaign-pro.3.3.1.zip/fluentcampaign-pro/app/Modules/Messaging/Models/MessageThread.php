<?php

namespace FluentCampaign\App\Modules\Messaging\Models;

use FluentCrm\App\Models\Model;
use FluentCrm\App\Models\Subscriber;
use FluentCampaign\App\Modules\Messaging\Services\PhoneMatcher;
use FluentCampaign\App\Services\ProHelper;

/**
 * One conversation, keyed on channel and phone number.
 * `contact_id` is nullable: a thread can exist before its number is a contact.
 *
 * @package FluentCrm\App\Models
 */
class MessageThread extends Model
{
    /**
     * Consent vocabulary for `status`, channel-neutral.
     */
    const STATUS_SUBSCRIBED = 'subscribed';
    const STATUS_UNSUBSCRIBED = 'unsubscribed';
    const STATUS_PENDING = 'pending';
    const STATUS_BOUNCED = 'bounced';

    /**
     * `initiated_by` for a consent-only thread. The inbox rail hides these until a message lands.
     */
    const INITIATED_BY_SYSTEM = 'system';

    protected $table = 'fc_message_threads';

    protected $guarded = ['id'];

    protected $searchable = [
        'phone_number'
    ];

    protected $casts = [
        'id'              => 'integer',
        'contact_id'      => 'integer',
        'last_seen_id'    => 'integer',
        'last_message_id' => 'integer',
        'has_unread'      => 'integer',
        'unread_count'    => 'integer'
    ];

    public static function boot()
    {
        parent::boot();

        // Consent checks look threads up by phone_key; see PhoneMatcher::lookupKey().
        // Existing rows are keyed by MessageMigrator::fillPhoneKeys(), so an update only re-keys a changed number.
        static::saving(function ($model) {
            if (PhoneMatcher::hasKeyColumn() && (!$model->exists || $model->isDirty('phone_number'))) {
                $model->phone_key = PhoneMatcher::lookupKey($model->phone_number);
            }
        });
    }

    /**
     * `meta` is PHP-serialized; the framework's 'array' cast is JSON and must not be used.
     */
    public function setMetaAttribute($meta)
    {
        $this->attributes['meta'] = \maybe_serialize($meta);
    }

    public function getMetaAttribute($meta)
    {
        $meta = ProHelper::safeUnserialize($meta);

        return is_array($meta) ? $meta : [];
    }

    /**
     * Consent statuses with display labels, keyed by stored value.
     */
    public static function consentStatusLabels(): array
    {
        return [
            self::STATUS_SUBSCRIBED   => __('Subscribed', 'fluentcampaign-pro'),
            self::STATUS_UNSUBSCRIBED => __('Unsubscribed', 'fluentcampaign-pro'),
            self::STATUS_PENDING      => __('Pending', 'fluentcampaign-pro'),
            self::STATUS_BOUNCED      => __('Bounced', 'fluentcampaign-pro')
        ];
    }

    /**
     * The consent values an operator or a provider may set.
     */
    public static function consentStatuses(): array
    {
        return array_keys(self::consentStatusLabels());
    }

    /**
     * Whether a contact may be messaged on a channel.
     * No thread means subscribed; any non-subscribed thread on the channel blocks it.
     */
    public static function contactCanReceive(string $channel, $contactId): bool
    {
        return static::contactStatus($channel, $contactId) === self::STATUS_SUBSCRIBED;
    }

    /**
     * The consent a contact holds on a channel: a blocking status if any, else subscribed.
     */
    public static function contactStatus(string $channel, $contactId): string
    {
        if (!$contactId) {
            return self::STATUS_SUBSCRIBED;
        }

        $blocking = static::where('contact_id', (int) $contactId)
            ->where('channel', $channel)
            ->where('status', '!=', self::STATUS_SUBSCRIBED)
            ->value('status');

        if ($blocking) {
            return $blocking;
        }

        // A STOP belongs to the number: it also covers a contact who shares it, or whose phone
        // is stored formatted while the provider's thread is keyed in E.164.
        $phone = Subscriber::where('id', (int) $contactId)->value('phone');
        if ($phone) {
            $byNumber = PhoneMatcher::blockedNumbers($channel, [$phone]);
            if ($byNumber) {
                return reset($byNumber);
            }
        }

        return self::STATUS_SUBSCRIBED;
    }

    /**
     * Whether a bare number may be messaged on a channel. An empty number returns true.
     */
    public static function numberCanReceive(string $channel, $phone): bool
    {
        $phone = trim((string) $phone);

        if ($phone === '') {
            return true;
        }

        return !PhoneMatcher::blockedNumbers($channel, [$phone]);
    }

    /**
     * The subset of $contactIds that may not be messaged on a channel, in one query.
     *
     * @return array<int, true> keyed by contact id, for isset() lookups
     */
    public static function blockedContactIds(string $channel, array $contactIds): array
    {
        $contactIds = array_values(array_unique(array_filter(array_map('intval', $contactIds))));

        if (!$contactIds) {
            return [];
        }

        $rows = static::whereIn('contact_id', $contactIds)
            ->where('channel', $channel)
            ->where('status', '!=', self::STATUS_SUBSCRIBED)
            ->get(['contact_id']);

        $blocked = [];

        foreach ($rows as $row) {
            $blocked[(int) $row->contact_id] = true;
        }

        // Number-level opt-outs (see contactStatus()).
        $phones = Subscriber::whereIn('id', $contactIds)->whereNotNull('phone')->where('phone', '!=', '')->pluck('phone', 'id')->toArray();
        if ($phones) {
            $blockedNumbers = PhoneMatcher::blockedNumbers($channel, array_values($phones));
            foreach ($phones as $contactId => $phone) {
                if (isset($blockedNumbers[PhoneMatcher::digits($phone)])) {
                    $blocked[(int) $contactId] = true;
                }
            }
        }

        return $blocked;
    }

    /**
     * Narrow a Subscriber query to the contacts a channel may message.
     *
     * @param mixed $query a Subscriber query/builder
     */
    public static function applyConsentFilter($query, string $channel)
    {
        return static::applyStatusFilter($query, $channel, [self::STATUS_SUBSCRIBED]);
    }

    /**
     * Narrow a Subscriber query to contacts whose channel consent is (or, negated, is not) in $statuses.
     * Matches contactStatus(): subscribed means no non-subscribed thread on the channel.
     *
     * @param mixed $query    a Subscriber query/builder
     * @param array $statuses consent values from consentStatuses()
     * @param bool  $negate   match the contacts this would otherwise exclude
     */
    public static function applyStatusFilter($query, string $channel, array $statuses, bool $negate = false)
    {
        global $wpdb;

        $statuses = array_values(array_intersect(static::consentStatuses(), $statuses));

        // No recognised status matches nobody, even when negated, so a filter never widens an audience.
        if (!$statuses) {
            return $query->whereRaw('1 = 0');
        }

        $threads = $wpdb->prefix . 'fc_message_threads';
        $subscribers = $wpdb->prefix . 'fc_subscribers';

        $threadsOf = "SELECT 1 FROM `$threads` fc_consent
                      WHERE fc_consent.contact_id = `$subscribers`.`id`
                        AND fc_consent.channel = %s";

        $clauses = [];
        $args = [];

        $blocking = array_values(array_diff($statuses, [self::STATUS_SUBSCRIBED]));

        if ($blocking) {
            $placeholders = implode(', ', array_fill(0, count($blocking), '%s'));
            $clauses[] = "EXISTS ($threadsOf AND fc_consent.status IN ($placeholders))";
            $args = array_merge($args, [$channel], $blocking);
        }

        if (in_array(self::STATUS_SUBSCRIBED, $statuses, true)) {
            $clauses[] = "NOT EXISTS ($threadsOf AND fc_consent.status <> %s)";
            $args = array_merge($args, [$channel, self::STATUS_SUBSCRIBED]);
        }

        $sql = '(' . implode(' OR ', $clauses) . ')';

        return $query->whereRaw($wpdb->prepare($negate ? "NOT $sql" : $sql, $args));
    }

    /**
     * Record a consent decision the number itself made (an SMS STOP or START reply).
     *
     * Stored on every thread for the number, whichever spelling it was keyed with, and on the own
     * threads of every contact with that number (compared by digits), so a formatted or shared
     * number is covered.
     *
     * @return \FluentCrm\App\Models\Subscriber[]|null the contacts with this number; null when nothing was stored
     */
    public static function setNumberConsent(string $channel, $phone, string $status)
    {
        // The wide national-suffix match reaches numbers that only end the same. Blocking with it
        // is safe; lifting with it is only safe when this exact number is the one that opted out,
        // so a START from a different number never re-subscribes someone else's STOP.
        $exactDigits = $status === self::STATUS_SUBSCRIBED && !static::exactNumberOptedOut($channel, $phone);
        $contacts = PhoneMatcher::contactsForNumber($phone, $exactDigits);

        $thread = static::findOrCreateFor($channel, $phone, [
            'contact_id'   => $contacts ? $contacts[0]->id : null,
            'initiated_by' => self::INITIATED_BY_SYSTEM
        ]);

        if (!$thread) {
            return null;
        }

        $contactIds = array_map(function ($contact) {
            return (int) $contact->id;
        }, $contacts);
        $threadIds = array_values(array_unique(array_merge([(int) $thread->id], PhoneMatcher::threadIdsForNumber($channel, $phone, $exactDigits))));

        // Consent is not activity; leave `updated_at`, which sorts the rail.
        static::withoutTimestamps(function () use ($threadIds, $channel, $contactIds, $status) {
            static::whereIn('id', $threadIds)->update(['status' => $status]);
            if ($contactIds) {
                static::whereIn('contact_id', $contactIds)->where('channel', $channel)->update(['status' => $status]);
            }
        });

        if ($status !== self::STATUS_SUBSCRIBED) {
            if ($contactIds) {
                $threadIds = array_merge($threadIds, static::whereIn('contact_id', $contactIds)->where('channel', $channel)->pluck('id')->toArray());
            }
            static::cancelQueuedOutbound($threadIds, $status);
        }

        return $contacts;
    }

    /**
     * Whether a thread with exactly these digits holds a blocking status on the channel, i.e.
     * this number itself opted out (not one that only shares its last digits).
     */
    protected static function exactNumberOptedOut(string $channel, $phone): bool
    {
        $threadIds = PhoneMatcher::threadIdsForNumber($channel, $phone, true);
        if (!$threadIds) {
            return false;
        }

        return static::whereIn('id', $threadIds)
            ->where('status', '!=', self::STATUS_SUBSCRIBED)
            ->exists();
    }

    /**
     * Cancel the outbound messages still waiting to be sent on these threads, after an opt-out.
     *
     * Messages the runner already claimed (processing) are with the provider and are left alone.
     * Callers queue the opt-out confirmation afterwards, so it is not cancelled.
     *
     * @param int[]  $threadIds
     * @param string $status the consent status that caused it, kept on each message
     * @return int number of messages cancelled
     */
    public static function cancelQueuedOutbound(array $threadIds, string $status): int
    {
        $threadIds = array_values(array_unique(array_filter(array_map('intval', $threadIds))));
        if (!$threadIds) {
            return 0;
        }

        $messages = Message::whereIn('thread_id', $threadIds)
            ->where('direction', Message::DIRECTION_OUTBOUND)
            ->whereIn('status', [Message::STATUS_SCHEDULING, Message::STATUS_SCHEDULED, Message::STATUS_PENDING])
            ->get(['id', 'meta']);

        foreach ($messages as $message) {
            $meta = is_array($message->meta) ? $message->meta : [];
            $meta['error_message'] = sprintf('Cancelled: the recipient is %s', $status);

            Message::where('id', $message->id)
                ->whereIn('status', [Message::STATUS_SCHEDULING, Message::STATUS_SCHEDULED, Message::STATUS_PENDING])
                ->update([
                    'status'     => Message::STATUS_CANCELLED,
                    'meta'       => \maybe_serialize($meta),
                    'updated_at' => current_time('mysql')
                ]);
        }

        return count($messages);
    }

    /**
     * Record a consent decision for a number on a channel.
     *
     * Messages go to a number, so consent belongs to it: the decision is stored for every contact
     * with that number (see setNumberConsent()), and also on $contactId's own threads.
     *
     * @return bool whether the decision now holds for $contactId (or the number, without one)
     */
    public static function setConsent(string $channel, $phone, string $status, $contactId = null): bool
    {
        $contacts = static::setNumberConsent($channel, $phone, $status);
        if ($contacts === null) {
            return false;
        }

        if ($contactId) {
            static::withoutTimestamps(function () use ($channel, $contactId, $status) {
                static::where('contact_id', (int) $contactId)->where('channel', $channel)->update(['status' => $status]);
            });

            return static::contactStatus($channel, $contactId) === $status;
        }

        return true;
    }

    public function messages()
    {
        return $this->hasMany(Message::class, 'thread_id', 'id');
    }

    /**
     * The contact, when there is one.
     */
    public function subscriber()
    {
        return $this->belongsTo(Subscriber::class, 'contact_id', 'id');
    }

    /**
     * An existing thread for the same number stored in another format.
     *
     * Providers deliver E.164 ("+13035550100") while contacts' phones are stored as typed
     * ("+1 (303) 555-0100"), so the inbound and outbound sides used to open two threads and
     * WhatsApp's 24-hour window was checked on the one with no inbound message. A thread with the
     * same digits is the same number. A national-format match (missing the country code) is used
     * only when that thread already belongs to this contact, so two people are never merged.
     *
     * @param string $channel
     * @param string $phone
     * @param int $contactId
     * @return static|null
     */
    private static function findSameNumberThread($channel, $phone, $contactId = 0)
    {
        $ids = PhoneMatcher::threadIdsForNumber($channel, $phone);
        if (!$ids) {
            return null;
        }

        $threads = static::whereIn('id', $ids)->orderBy('id', 'ASC')->get();
        $digits = PhoneMatcher::digits($phone);

        foreach ($threads as $thread) {
            if (PhoneMatcher::digits($thread->phone_number) === $digits) {
                return $thread;
            }
        }

        if ($contactId) {
            foreach ($threads as $thread) {
                if ((int) $thread->contact_id === $contactId) {
                    return $thread;
                }
            }
        }

        return null;
    }

    /**
     * Find the thread for a number on a channel, creating it if needed.
     * The unique (channel, phone_number) index resolves concurrent creates. An existing contact_id is never overwritten.
     *
     * @param string $channel
     * @param string $phone
     * @param array $attrs contact_id, initiated_by
     * @return static|null null only when the number is unusable
     */
    public static function findOrCreateFor($channel, $phone, array $attrs = [])
    {
        $channel = $channel ?: 'sms';
        $phone = trim((string) $phone);

        if ($phone === '') {
            return null;
        }

        $thread = static::where('channel', $channel)->where('phone_number', $phone)->first();

        if (!$thread) {
            $thread = static::findSameNumberThread($channel, $phone, !empty($attrs['contact_id']) ? (int) $attrs['contact_id'] : 0);
        }

        if (!$thread) {
            try {
                $thread = static::create([
                    'contact_id'   => !empty($attrs['contact_id']) ? (int) $attrs['contact_id'] : null,
                    'channel'      => $channel,
                    'phone_number' => $phone,
                    'status'       => 'subscribed',
                    'initiated_by' => !empty($attrs['initiated_by']) ? $attrs['initiated_by'] : 'user',
                    'has_unread'   => 0,
                    'unread_count' => 0,
                    'created_at'   => current_time('mysql'),
                    'updated_at'   => current_time('mysql')
                ]);
            } catch (\Exception $e) {
                // Lost the insert race; use the winner's row.
                $thread = static::where('channel', $channel)->where('phone_number', $phone)->first();
            }
        }

        // A thread left pointing at a contact deleted before its conversations were cleaned up.
        if ($thread && $thread->contact_id && !empty($attrs['contact_id']) && (int) $thread->contact_id !== (int) $attrs['contact_id']
            && !Subscriber::where('id', $thread->contact_id)->exists()) {
            $thread->claimOrphanContact((int) $attrs['contact_id'], [(int) $thread->contact_id]);
        }

        if ($thread && !$thread->contact_id && !empty($attrs['contact_id'])) {
            $thread->contact_id = (int) $attrs['contact_id'];

            // Linking is not activity; leave `updated_at`, which sorts the rail.
            static::withoutTimestamps(function () use ($thread) {
                $thread->save();
            });
        }

        return $thread;
    }

    /**
     * Atomically claim an unlinked or dangling thread for a contact, keeping `updated_at`.
     *
     * @param int $contactId
     * @param array $staleContactIds contact ids known to be deleted
     * @return bool true when this call performed the link
     */
    public function claimOrphanContact($contactId, array $staleContactIds = [])
    {
        $contactId = (int) $contactId;

        if (!$this->id || !$contactId) {
            return false;
        }

        $staleContactIds = array_values(array_filter(array_map('intval', $staleContactIds)));

        $affected = static::where('id', (int) $this->id)
            ->where(function ($query) use ($staleContactIds) {
                $query->whereNull('contact_id');

                if ($staleContactIds) {
                    $query->orWhereIn('contact_id', $staleContactIds);
                }
            })
            ->update([
                'contact_id' => $contactId,
                'updated_at' => $this->updated_at
            ]);

        if ($affected) {
            $this->contact_id = $contactId;
            $this->syncOriginalAttribute('contact_id');
        }

        return (bool) $affected;
    }

    /**
     * The thread for a contact on a channel, if one exists.
     *
     * @param int $contactId
     * @param string $channel
     * @return static|null
     */
    public static function forContact($contactId, $channel)
    {
        if (!$contactId) {
            return null;
        }

        return static::where('contact_id', (int) $contactId)
            ->where('channel', $channel)
            ->first();
    }

    /**
     * Append one message to this thread through recordMessages().
     *
     * @param array $attrs Message attributes
     * @return Message|null
     */
    public function recordMessage(array $attrs)
    {
        $messageIds = [];
        $written = static::recordMessages([
            array_merge($attrs, ['thread_id' => $this->id])
        ], $messageIds);

        if (!$written || empty($messageIds[0])) {
            return null;
        }

        $message = Message::find($messageIds[0]);

        $this->refresh();

        return $message;
    }

    /**
     * Resolve or create a thread id for every (channel, phone) pair in bulk.
     * INSERT IGNORE on the unique (channel, phone_number) index prevents duplicate threads.
     *
     * @param array $pairs list of ['channel' => , 'phone' => , 'contact_id' => ,
     *                     'initiated_by' => ]
     * @return array map of "channel|phone" => thread id
     */
    public static function resolveThreadIds(array $pairs)
    {
        global $wpdb;

        $wanted = [];

        foreach ($pairs as $pair) {
            $phone = trim((string) ($pair['phone'] ?? ''));

            if ($phone === '') {
                continue;
            }

            $channel = !empty($pair['channel']) ? $pair['channel'] : 'sms';
            $key = $channel . '|' . $phone;

            if (!isset($wanted[$key])) {
                $wanted[$key] = [
                    'channel'      => $channel,
                    'phone'        => $phone,
                    'contact_id'   => !empty($pair['contact_id']) ? (int) $pair['contact_id'] : null,
                    'initiated_by' => !empty($pair['initiated_by']) ? $pair['initiated_by'] : 'admin'
                ];
            } elseif (!$wanted[$key]['contact_id'] && !empty($pair['contact_id'])) {
                $wanted[$key]['contact_id'] = (int) $pair['contact_id'];
            }
        }

        if (!$wanted) {
            return [];
        }

        $table = $wpdb->prefix . 'fc_message_threads';
        $now = current_time('mysql');

        $inserts = [];
        $lookups = [];
        $withKey = PhoneMatcher::hasKeyColumn();

        foreach ($wanted as $item) {
            // prepare() has no NULL placeholder, so NULL is emitted as a literal.
            $contactId = $item['contact_id'] ? (string) $item['contact_id'] : 'NULL';

            $inserts[] = '(' . $contactId . ',' . $wpdb->prepare(
                '%s,%s,%s,%s,0,0,%s,%s',
                $item['channel'],
                $item['phone'],
                'subscribed',
                $item['initiated_by'],
                $now,
                $now
            ) . ($withKey ? $wpdb->prepare(',%s', PhoneMatcher::lookupKey($item['phone'])) : '') . ')';

            $lookups[] = $wpdb->prepare('(%s,%s)', $item['channel'], $item['phone']);
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "INSERT IGNORE INTO `$table`
                (`contact_id`,`channel`,`phone_number`,`status`,`initiated_by`,`has_unread`,`unread_count`,`created_at`,`updated_at`" . ($withKey ? ',`phone_key`' : '') . ")
             VALUES " . implode(',', $inserts)
        );

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $found = $wpdb->get_results(
            "SELECT id, channel, phone_number, contact_id FROM `$table`
             WHERE (channel, phone_number) IN (" . implode(',', $lookups) . ")"
        );

        $map = [];
        $backfill = [];

        foreach ($found as $thread) {
            $key = $thread->channel . '|' . $thread->phone_number;
            $map[$key] = (int) $thread->id;

            // Link contactless threads; an existing link is never rewritten.
            if ($thread->contact_id === null && !empty($wanted[$key]['contact_id'])) {
                $backfill[(int) $wanted[$key]['contact_id']][] = (int) $thread->id;
            }
        }

        foreach ($backfill as $contactId => $ids) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE `$table` SET contact_id = %d
                     WHERE contact_id IS NULL AND id IN (" . implode(',', array_map('intval', $ids)) . ")",
                    $contactId
                )
            );
        }

        return $map;
    }

    /**
     * Recompute updated_at, last_message_id and unread counts for the given threads.
     * Call after any bulk insert/delete of messages or after stamping `sent_at`. The read cursor is not touched.
     *
     * @param array $threadIds
     */
    public static function syncCaches(array $threadIds)
    {
        global $wpdb;

        $threadIds = array_values(array_unique(array_filter(array_map('intval', $threadIds))));

        if (!$threadIds) {
            return;
        }

        $ids = implode(',', $threadIds);
        $threads = $wpdb->prefix . 'fc_message_threads';
        $messages = $wpdb->prefix . 'fc_messages';

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "UPDATE `$threads` t
             SET t.updated_at = COALESCE((
                     SELECT MAX(COALESCE(m.sent_at, m.scheduled_at, m.created_at))
                     FROM `$messages` m WHERE m.thread_id = t.id
                 ), t.updated_at),
                 t.last_message_id = (
                     SELECT m.id FROM `$messages` m
                     WHERE m.thread_id = t.id
                     ORDER BY COALESCE(m.sent_at, m.scheduled_at, m.created_at) DESC, m.id DESC
                     LIMIT 1
                 ),
                 t.unread_count = (
                     SELECT COUNT(*) FROM `$messages` m
                     WHERE m.thread_id = t.id
                       AND m.direction = 'inbound'
                       AND m.id > COALESCE(t.last_seen_id, 0)
                 ),
                 t.has_unread = (
                     SELECT COUNT(*) > 0 FROM `$messages` m
                     WHERE m.thread_id = t.id
                       AND m.direction = 'inbound'
                       AND m.id > COALESCE(t.last_seen_id, 0)
                 )
             WHERE t.id IN ($ids)"
        );
    }

    /**
     * Whether a message with the provider's id already exists, for webhook retry dedupe.
     *
     * @param string $providerMessageId
     * @return bool
     */
    public static function hasProviderMessage($providerMessageId, $channel = null)
    {
        if (!$providerMessageId) {
            return false;
        }

        $query = Message::where('provider_message_id', $providerMessageId);

        // Provider ids are only unique per channel. Null channel means any channel.
        if ($channel) {
            $query->whereHas('thread', function ($thread) use ($channel) {
                $thread->where('channel', $channel);
            });
        }

        return $query->exists();
    }

    /**
     * Bulk-insert messages, resolving threads and syncing caches. The only writer to fc_messages.
     * Items with an unusable number are skipped; only returned keys were written.
     * `mark_read` or `created_by` advances the thread's read cursor.
     *
     * @param array $items thread identity plus complete message attributes
     * @param array|null $messageIds receives a map of item key to inserted id
     * @return array the keys of $items a row was inserted for
     */
    public static function recordMessages(array $items, &$messageIds = null)
    {
        global $wpdb;

        $messageIds = [];

        if (!$items) {
            return [];
        }

        $unresolved = array_filter($items, function ($item) {
            return empty($item['thread_id']);
        });
        $threadIds = $unresolved ? static::resolveThreadIds($unresolved) : [];

        if (!$threadIds && count($unresolved) === count($items)) {
            return [];
        }

        $now = current_time('mysql');
        $values = [];
        $written = [];
        $writtenRows = [];
        $touched = [];

        foreach ($items as $key => $item) {
            $threadId = !empty($item['thread_id']) ? (int) $item['thread_id'] : 0;

            if (!$threadId) {
                $phone = trim((string) ($item['phone'] ?? ''));
                $channel = !empty($item['channel']) ? $item['channel'] : 'sms';
                $mapKey = $channel . '|' . $phone;

                if ($phone === '' || !isset($threadIds[$mapKey])) {
                    continue;
                }

                $threadId = $threadIds[$mapKey];
            }

            $touched[$threadId] = $threadId;

            $values[] = '(' . implode(',', [
                (string) $threadId,
                self::sqlValue(!empty($item['direction']) ? $item['direction'] : Message::DIRECTION_OUTBOUND),
                self::sqlValue(isset($item['content']) ? $item['content'] : ''),
                self::sqlValue(!empty($item['ref_id']) ? (int) $item['ref_id'] : null, 'int'),
                self::sqlValue(!empty($item['ref_type']) ? $item['ref_type'] : null),
                self::sqlValue(!empty($item['status']) ? $item['status'] : 'pending'),
                self::sqlValue(!empty($item['provider_message_id']) ? $item['provider_message_id'] : null),
                self::sqlValue(!empty($item['scheduled_at']) ? $item['scheduled_at'] : null),
                self::sqlValue(!empty($item['sent_at']) ? $item['sent_at'] : null),
                self::sqlValue(isset($item['meta']) ? \maybe_serialize($item['meta']) : null),
                self::sqlValue(!empty($item['created_by']) ? (int) $item['created_by'] : null, 'int'),
                self::sqlValue(array_key_exists('created_at', $item) ? $item['created_at'] : $now),
                self::sqlValue(array_key_exists('updated_at', $item) ? $item['updated_at'] : $now)
            ]) . ')';

            $written[] = $key;
            $writtenRows[] = [
                'key' => $key,
                'thread_id' => $threadId,
                'mark_read' => !empty($item['mark_read']) || !empty($item['created_by'])
            ];
        }

        if (!$values) {
            return [];
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $inserted = $wpdb->query(
            "INSERT INTO `{$wpdb->prefix}fc_messages`
                (`thread_id`,`direction`,`content`,`ref_id`,`ref_type`,`status`,
                 `provider_message_id`,`scheduled_at`,`sent_at`,`meta`,`created_by`,
                 `created_at`,`updated_at`)
             VALUES " . implode(',', $values)
        );

        if ($inserted === false) {
            return [];
        }

        $firstMessageId = (int) $wpdb->insert_id;
        $readCursors = [];

        foreach ($writtenRows as $offset => $row) {
            $messageId = $firstMessageId + $offset;
            $messageIds[$row['key']] = $messageId;

            if ($row['mark_read']) {
                $threadId = $row['thread_id'];
                $readCursors[$threadId] = max($readCursors[$threadId] ?? 0, $messageId);
            }
        }

        if ($readCursors) {
            $cases = [];

            foreach ($readCursors as $threadId => $messageId) {
                $cases[] = $wpdb->prepare(
                    'WHEN %d THEN GREATEST(COALESCE(last_seen_id, 0), %d)',
                    $threadId,
                    $messageId
                );
            }

            $readThreadIds = implode(',', array_map('intval', array_keys($readCursors)));

            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query(
                "UPDATE `{$wpdb->prefix}fc_message_threads`
                 SET last_seen_id = CASE id " . implode(' ', $cases) . " ELSE last_seen_id END
                 WHERE id IN ($readThreadIds)"
            );
        }

        static::syncCaches(array_values($touched));

        return $written;
    }

    /**
     * One value for a bulk VALUES list. Nulls are emitted as a literal NULL.
     *
     * @param mixed $value
     * @param string $kind str|int
     * @return string
     */
    protected static function sqlValue($value, $kind = 'str')
    {
        global $wpdb;

        if ($value === null) {
            return 'NULL';
        }

        if ($kind === 'int') {
            return (string) (int) $value;
        }

        return $wpdb->prepare('%s', $value);
    }

    /**
     * Search by number, or by the linked contact's name or email.
     */
    public function scopeSearchBy($query, $search)
    {
        if (!$search) {
            return $query;
        }

        global $wpdb;
        $search = '%' . $wpdb->esc_like($search) . '%';

        return $query->where(function ($query) use ($search) {
            $query->where('phone_number', 'LIKE', $search)
                ->orWhereHas('subscriber', function ($q) use ($search) {
                    $q->where('first_name', 'LIKE', $search)
                        ->orWhere('last_name', 'LIKE', $search)
                        ->orWhere('email', 'LIKE', $search);
                });
        });
    }

    /**
     * Record the outcome of a direct send onto its conversation thread.
     *
     * @param string $channel  sms|whatsapp
     * @param string $phone    the number actually messaged
     * @param int|null $contactId
     * @param string $body     rendered message
     * @param array $result    the channel's send result
     * @param array $extra     ref_type, template_id, and anything for meta
     * @return Message|null
     */
    public static function recordOutbound(string $channel, string $phone, $contactId, string $body, array $result, array $extra = [])
    {
        $thread = static::findOrCreateFor($channel, $phone, [
            'contact_id' => $contactId,
            'initiated_by' => 'admin'
        ]);

        if (!$thread) {
            return null;
        }

        $succeeded = ($result['status'] ?? '') === 'success';

        $meta = isset($extra['meta']) && is_array($extra['meta']) ? $extra['meta'] : [];

        if (!$succeeded) {
            $meta['error_message'] = $result['message'] ?? '';
        }

        if (!empty($extra['template_id'])) {
            $meta['template_id'] = (int) $extra['template_id'];
        }

        if (!empty($extra['template_name'])) {
            $meta['template_name'] = $extra['template_name'];
        }

        return $thread->recordMessage([
            'direction'           => 'outbound',
            'content'             => $body,
            'ref_type'            => isset($extra['ref_type']) ? $extra['ref_type'] : 'custom',
            'ref_id'              => isset($extra['ref_id']) ? $extra['ref_id'] : null,
            // Null, not '', so `provider_message_id IS NULL` still matches.
            'provider_message_id' => !empty($result['provider_message_id']) ? $result['provider_message_id'] : null,
            'status'              => $succeeded ? 'sent' : 'failed',
            'sent_at'             => $succeeded ? current_time('mysql') : null,
            'created_by'          => get_current_user_id() ?: null,
            'meta'                => $meta
        ]);
    }

    /**
     * Queue one outbound message on its thread.
     * The returned fc_messages id is what callers pass to `fluentcrm_send_single_sms`.
     *
     * @param string $channel sms|whatsapp
     * @param string $phone the number to message
     * @param int|null $contactId
     * @param string $body rendered message body
     * @param array $extra ref_type, ref_id, scheduled_at, template_id, meta
     * @return Message|null null when the number is unusable
     */
    public static function queueOutbound(string $channel, string $phone, $contactId, string $body, array $extra = [])
    {
        $thread = static::findOrCreateFor($channel, $phone, [
            'contact_id'   => $contactId,
            'initiated_by' => 'admin'
        ]);

        if (!$thread) {
            return null;
        }

        $meta = isset($extra['meta']) && is_array($extra['meta']) ? $extra['meta'] : [];

        if (!empty($extra['template_id'])) {
            $meta['template_id'] = (int) $extra['template_id'];
        }

        return $thread->recordMessage([
            'direction'    => Message::DIRECTION_OUTBOUND,
            'content'      => $body,
            'ref_type'     => isset($extra['ref_type']) ? $extra['ref_type'] : null,
            'ref_id'       => isset($extra['ref_id']) ? $extra['ref_id'] : null,
            'status'       => isset($extra['status']) ? $extra['status'] : Message::STATUS_PENDING,
            'scheduled_at' => isset($extra['scheduled_at']) ? $extra['scheduled_at'] : current_time('mysql'),
            'meta'         => $meta
        ]);
    }
}
