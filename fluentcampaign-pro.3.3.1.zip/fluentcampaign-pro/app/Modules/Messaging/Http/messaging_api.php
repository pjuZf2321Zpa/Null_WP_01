<?php
/**
 * Every Messaging route, registered when the Message module is on.
 * Shared routes live under `messaging/` and take `?channel=`; only WhatsApp-specific routes use `whatsapp/`.
 *
 * @var $router FluentCrm\Framework\Http\Router
 */

use FluentCampaign\App\Modules\Messaging\Http\Controllers\MessageController;
use FluentCampaign\App\Modules\Messaging\Http\Controllers\MessageMigrationController;
use FluentCampaign\App\Modules\Messaging\Http\Controllers\MessageThreadController;
use FluentCampaign\App\Modules\Messaging\Http\Policies\InboxPolicy;
use FluentCampaign\App\Modules\Messaging\Http\Policies\MessagePolicy;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Http\Controllers\WhatsAppTemplateController;
use FluentCrm\App\Http\Policies\SettingsPolicy;

// Conversation inbox: threads and their messages.
$router->prefix('messaging/threads')->withPolicy(InboxPolicy::class)->group(function ($router) {
    $router->get('/', [MessageThreadController::class, 'index']);
    // Registered before the {id} routes so a literal segment is never read as an id.
    $router->get('/recipients', [MessageThreadController::class, 'recipients']);
    // Creates a thread; non-GET requires fcrm_manage_emails via InboxPolicy::verifyRequest().
    $router->post('/', [MessageThreadController::class, 'store']);
    $router->get('/{id}/messages', [MessageThreadController::class, 'messages'])->int('id');
    $router->post('/{id}/messages', [MessageThreadController::class, 'sendMessage'])->int('id');
    $router->post('/{id}/seen', [MessageThreadController::class, 'markSeen'])->int('id');
    // Thread-scoped consent, so contactless numbers can be opted out too.
    $router->post('/{id}/consent', [MessageThreadController::class, 'updateConsent'])->int('id');
    // Attach a CRM contact to a conversation.
    $router->post('/{id}/contact', [MessageThreadController::class, 'linkContact'])->int('id');
});

// Legacy fc_sms_messages migration: status for progress, migrate called repeatedly until done.
$router->prefix('messaging/migration')->withPolicy(SettingsPolicy::class)->group(function ($router) {
    $router->get('/', [MessageMigrationController::class, 'status']);
    $router->post('/migrate', [MessageMigrationController::class, 'migrate']);
});

// Campaigns, activities and per-contact history for every channel; channel comes from `?channel=` or the thread.
$router->prefix('messaging')->withPolicy(MessagePolicy::class)->group(function ($router) {
    // Per-contact history and sending, scoped by ?channel=
    $router->get('/subscribers/{id}/logs', [MessageController::class, 'getLogs'])->int('id');
    $router->post('/subscribers/{id}/send', [MessageController::class, 'sendCustomSMS'])->int('id');
    $router->get('/subscribers/{id}/stats', [MessageController::class, 'getStats'])->int('id');
    // Consent lives on threads, not on core's contact properties.
    $router->get('/subscribers/{id}/consent', [MessageController::class, 'getConsent'])->int('id');
    $router->post('/subscribers/{id}/consent', [MessageController::class, 'updateConsent'])->int('id');

    // Campaign routes
    $router->get('/campaigns', [MessageController::class, 'campaigns']);
    $router->post('/campaigns', [MessageController::class, 'create']);
    $router->get('/campaigns/{id}', [MessageController::class, 'campaign'])->int('id');
    $router->put('/campaigns/{id}', [MessageController::class, 'update']);
    $router->put('/campaigns/{id}/update-labels', [MessageController::class, 'updateLabels'])->int('id');
    $router->post('/campaigns/estimated-contacts', [MessageController::class, 'getContactEstimation']);
    $router->get('/campaigns/{id}/estimated-recipients-count', [MessageController::class, 'getRecipientsCount'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/upload', [MessageController::class, 'uploadOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/paste', [MessageController::class, 'pasteOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/process', [MessageController::class, 'processOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/one-time-audience/activate', [MessageController::class, 'activateOneTimeAudience'])->int('id');
    $router->get('/campaigns/{id}/one-time-audience/recipients', [MessageController::class, 'getOneTimeAudienceRecipients'])->int('id');
    $router->get('/campaigns/{id}/one-time-audience', [MessageController::class, 'getOneTimeAudience'])->int('id');
    $router->delete('/campaigns/{id}/one-time-audience', [MessageController::class, 'clearOneTimeAudience'])->int('id');
    $router->post('/campaigns/{id}/schedule', [MessageController::class, 'schedule'])->int('id');
    $router->post('/campaigns/{id}/pause', [MessageController::class, 'pauseCampaign'])->int('id');
    $router->post('/campaigns/{id}/resume', [MessageController::class, 'resumeCampaign'])->int('id');
    $router->post('/campaigns/{id}/unschedule', [MessageController::class, 'unSchedule'])->int('id');
    $router->post('/campaigns/do-bulk-action', [MessageController::class, 'handleBulkAction']);
    $router->get('/campaigns/{id}/status', [MessageController::class, 'getCampaignStatus'])->int('id');
    $router->get('/campaigns/{id}/recipients', [MessageController::class, 'getCampaignRecipients'])->int('id');
    $router->post('/campaigns/{id}/tag-actions', [MessageController::class, 'doTagActions'])->int('id');
    $router->get('/campaigns/{id}/processing-stat', [MessageController::class, 'processingStat'])->int('id');
    $router->post('/campaigns/{id}/duplicate', [MessageController::class, 'duplicateCampaign'])->int('id');
    $router->delete('/campaigns/{id}', [MessageController::class, 'delete'])->int('id');

    // The Activities list: every message, any channel
    $router->get('/messages', [MessageController::class, 'getAllMessages']);
    $router->delete('/messages', [MessageController::class, 'deleteMessages']);
    $router->post('/messages/{id}/resend', [MessageController::class, 'resendMessage'])->int('id');
});

// WhatsApp template catalogue and per-contact history. MessagePolicy has per-method checks for the writes.
$router->prefix('whatsapp')->withPolicy(MessagePolicy::class)->group(function ($router) {
    $router->get('/templates', [WhatsAppTemplateController::class, 'index']);
    $router->post('/templates', [WhatsAppTemplateController::class, 'store']);
    $router->post('/templates/sync', [WhatsAppTemplateController::class, 'sync']);
    $router->post('/templates/validate', [WhatsAppTemplateController::class, 'validateTemplate']);
    $router->delete('/templates/{id}', [WhatsAppTemplateController::class, 'destroy'])->int('id');

    $router->get('/subscribers/{id}/messages', [WhatsAppTemplateController::class, 'subscriberMessages'])->int('id');
    $router->get('/subscribers/{id}/stats', [WhatsAppTemplateController::class, 'subscriberStats'])->int('id');
    $router->get('/subscribers/{id}/session', [WhatsAppTemplateController::class, 'subscriberSession'])->int('id');
    $router->post('/subscribers/{id}/send', [WhatsAppTemplateController::class, 'sendCustomMessage'])->int('id');
});
