<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Policies;

use FluentCrm\App\Http\Policies\BasePolicy;
use FluentCrm\Framework\Http\Request\Request;

/**
 * REST permissions for the conversation inbox: GET needs `fcrm_read_emails`, writes need `fcrm_manage_emails`.
 * Not gated on an active channel, so history stays readable with every channel off.
 *
 * @package FluentCampaign\App\Modules\Messaging\Http\Policies
 */
class InboxPolicy extends BasePolicy
{
    /**
     * @param Request $request
     * @return bool
     */
    public function verifyRequest(Request $request)
    {
        if ($this->requestMethod($request) == 'GET') {
            return $this->currentUserCan('fcrm_read_emails');
        }

        return $this->currentUserCan('fcrm_manage_emails');
    }

    /**
     * POST /messaging/threads/{id}/consent: needs the same capability as consent on a contact profile.
     *
     * @param Request $request
     * @return bool
     */
    public function updateConsent(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_contacts');
    }

    /**
     * POST /messaging/threads/{id}/contact: needs both contact and inbox write capabilities.
     *
     * @param Request $request
     * @return bool
     */
    public function linkContact(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_contacts') && $this->currentUserCan('fcrm_manage_emails');
    }

    /**
     * Recipient search exposes contact data, so it needs the write capability.
     *
     * @param Request $request
     * @return bool
     */
    public function recipients(Request $request)
    {
        return $this->currentUserCan('fcrm_manage_emails');
    }
}
