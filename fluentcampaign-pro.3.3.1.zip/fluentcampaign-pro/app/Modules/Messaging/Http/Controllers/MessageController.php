<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Controllers;

use FluentCampaign\App\Modules\Messaging\Services\PhoneMatcher;
use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Modules\Messaging\Handlers\MessageScheduler;
use FluentCampaign\App\Modules\Messaging\Models\LegacyMessage;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageCampaign;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceImporter;
use FluentCampaign\App\Modules\Messaging\Services\OneTimeAudienceMeta;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCrm\App\Models\Label;
use FluentCrm\App\Models\Meta;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Models\TermRelation;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Http\Request\Request;
use FluentCrm\Framework\Support\Arr;

class MessageController extends Controller
{
    public function campaigns(Request $request)
    {
        $search = sanitize_text_field($request->get('searchBy'));
        $status = $request->get('statuses');
        $order = $request->get('sort_type') ?: 'DESC';
        // orderBy() throws on column names outside ^[a-zA-Z0-9_\.]+$.
        $allowedOrderBy = [
            'id', 'parent_id', 'type', 'title', 'slug', 'status', 'message_content',
            'sender_number', 'recipients_count', 'sent_count', 'failed_count', 'delay',
            'scheduled_at', 'settings', 'channel', 'created_by', 'created_at', 'updated_at',
        ];
        $orderBy = sanitize_key((string) ($request->get('sort_by') ?: 'id'));
        if (!in_array($orderBy, $allowedOrderBy, true)) {
            $orderBy = 'id';
        }
        $with = $request->get('with', []);
        $labels = $request->get('labels', []);
        $channel = sanitize_key($request->get('channel', ''));

        $campaignQuery = MessageCampaign::when($status, function ($query) use ($status) {
                    return $query->whereIn('status', $status);
                })->where('type', 'campaign')
                  ->when($search, function ($query) use ($search) {
                      global $wpdb;
                      return $query->where('title', 'LIKE', '%' . $wpdb->esc_like($search) . '%');
                  })
                  ->when($channel, function ($query) use ($channel) {
                      return $query->where('channel', $channel);
                  })
                  ->orderBy($orderBy, ($order == 'ASC') ? 'ASC' : 'DESC');

        if (!empty($labels)) {
            $campaignQuery->whereHas('labelsTerm', function ($query) use ($labels) {
                $query->whereIn('term_id', $labels);
            });
        }

        $campaigns = $campaignQuery->paginate();

        if (in_array('stats', $with)) {
            // Load next-step meta and labels for the whole page at once.
            $campaignIds = [];
            foreach ($campaigns as $campaign) {
                $campaignIds[] = $campaign->id;
            }

            $nextSteps = Meta::where('object_type', MessageCampaign::OBJECT_TYPE)
                ->where('key', '_next_config_step')
                ->whereIn('object_id', $campaignIds)
                ->get()
                ->keyBy('object_id');

            $termRelations = TermRelation::where('object_type', MessageCampaign::OBJECT_TYPE)
                ->whereIn('object_id', $campaignIds)
                ->get()
                ->groupBy('object_id');

            $termIds = $termRelations->flatten()->pluck('term_id')->unique()->values()->all();
            $labelsById = [];
            if ($termIds) {
                foreach (Label::whereIn('id', $termIds)->get() as $label) {
                    $labelsById[$label->id] = $label;
                }
            }

            foreach ($campaigns as $campaign) {
                $meta = $nextSteps->get($campaign->id);
                $campaign->next_step = $meta ? $meta->value : false;

                $campaignLabels = [];
                foreach ($termRelations->get($campaign->id, []) as $relation) {
                    if ($label = $labelsById[$relation->term_id] ?? null) {
                        $campaignLabels[] = [
                            'id'    => $label->id,
                            'slug'  => $label->slug,
                            'title' => $label->title,
                            'color' => $label->settings['color'] ?? ''
                        ];
                    }
                }
                $campaign->labels = $campaignLabels;
            }
        }

        return [
            'campaigns' => $campaigns
        ];
    }
    public function campaign(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        /**
         * Determine the sms campaign data in FluentCRM.
         *
         * This filter allows modification of the sms campaign data before it is used.
         *
         * @since 2.6.51
         *
         * @param array $campaign The sms campaign data.
         */

        $campaign->server_time = current_time('mysql');
        $this->attachGenerationError($campaign);

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            $campaign = apply_filters('fluent_crm/whatsapp_campaign_data', $campaign);
        } else {
            $campaign = apply_filters('fluent_crm/sms_campaign_data', $campaign);
        }

        return $this->sendSuccess([
            'campaign' => $campaign
        ]);
    }
    public function create(Request $request)
    {
        $data = $this->validate($request->all(), [
            'title' => 'required',
            'message_content' => 'required'
        ]);

        $data['title'] = sanitize_text_field($data['title']);
        //Allow only links, no other HTML
        $data['message_content'] = wp_kses($data['message_content'], [
            'a' => [
                'href' => [],
                'title' => [],
                'target' => []
            ]
        ]);

        // Only user-editable columns; channel is validated separately.
        $data = Arr::only($data, ['title', 'message_content', 'sender_number', 'delay', 'scheduled_at', 'settings']);
        $data['type'] = 'campaign';
        $data['channel'] = $this->resolveChannel($request);

        $campaign = MessageCampaign::create($data);

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_created', $campaign);
        } else {
            do_action('fluent_crm/sms_campaign_created', $campaign);
        }

        return $this->sendSuccess([
            'campaign' => $campaign,
            'message' => __('SMS campaign created successfully', 'fluentcampaign-pro')
        ]);
    }

    public function update(Request $request, $id)
    {
        $data = $this->validate($request->all(), [
            "title" => "required",
            "message_content" => "required"
        ]);

        $data['title'] = sanitize_text_field($data['title']);
        //Allow only links, no other HTML
        $data['message_content'] = wp_kses($data['message_content'], [
            'a' => [
                'href' => [],
                'title' => [],
                'target' => []
            ]
        ]);

        $updateData = Arr::only($data, [
            'title',
            'message_content'
        ]);

        if (!empty($data['settings'])) {
            $updateData['settings'] = $data['settings'];
        }

        $campaign = MessageCampaign::findOrFail($id);

        $campaign->fill($updateData)->save();

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_updated', $campaign);
        } else {
            do_action('fluent_crm/sms_campaign_updated', $campaign);
        }

        $nextStep = Arr::get($data, 'next_step');

        if ($nextStep) {
            fluentcrm_update_sms_campaign_meta($id, '_next_config_step', $nextStep);
        }

        return $this->sendSuccess([
            'campaign' => $campaign,
            'message' => __('SMS campaign updated successfully', 'fluentcampaign-pro')
        ]);
    }

    /**
     * Get SMS logs for a specific subscriber
     *
     * @param Request $request
     * @param int $subscriberId
     */
    public function getLogs(Request $request, $subscriberId)
    {
        $subscriber = Subscriber::find($subscriberId);
        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Contact not found', 'fluentcampaign-pro'), 
                'code' => 404
            ]);
        }

        $perPage = $request->get('per_page', 20);
        $page = $request->get('page', 1);
        $filter = $request->get('filter', 'all');
        $order = $request->get('order', 'asc');
        $channel = $this->resolveChannel($request);

        $thread = MessageThread::forContact($subscriberId, $channel);

        // No thread means an empty history.
        $query = Message::where('thread_id', $thread ? $thread->id : 0);

        if ($filter !== 'all') {
            $query = $this->applyLogFilter($query, $filter);
        }

        // Same order as the thread view; id keeps the order stable.
        $direction = $order === 'desc' ? 'DESC' : 'ASC';
        $query->orderByRaw('COALESCE(sent_at, scheduled_at, created_at) ' . $direction)
            ->orderBy('id', $direction);

        $logs = $query->paginate($perPage, ['*'], 'page', $page);

        // Mapped to the field names the profile tab renders.
        $formattedLogs = [];
        foreach ($logs->items() as $log) {
            $when = $log->rawDate('sent_at') ?: ($log->rawDate('scheduled_at') ?: $log->rawDate('created_at'));

            $row = $log->toArray();

            // Raw strings, since toArray() serializes $dates as objects the browser cannot parse.
            $row['sent_at']    = $log->rawDate('sent_at');
            $row['scheduled_at'] = $log->rawDate('scheduled_at');
            $row['created_at'] = $log->rawDate('created_at');
            $row['updated_at'] = $log->rawDate('updated_at');

            $row['message']    = $log->content;
            $row['from']       = $thread ? $thread->phone_number : '';
            $row['date']       = $when ? date('m/d/Y', strtotime($when)) : '';
            $row['time']       = $when ? date('H:i', strtotime($when)) : '';
            $row['_date_time'] = $when;
            $row['type']       = $this->logType($log);

            $formattedLogs[] = $row;
        }

        return [
            'logs' => [
                'data' => $formattedLogs,
                'total' => $logs->total(),
                'per_page' => $logs->perPage(),
                'current_page' => $logs->currentPage(),
                'last_page' => $logs->lastPage()
            ]
        ];
    }

    /**
     * Send SMS to a subscriber
     *
     * @param Request $request
     * @param int $subscriberId
     */
    public function sendCustomSMS(Request $request, $contactId)
    {
        if (!SMSHelper::isActive()) {
            return $this->sendError([
                'message' => __('SMS module is not enabled', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        $subscriber = Subscriber::find($contactId);
        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Contact not found', 'fluentcampaign-pro'),
                'code' => 404
            ]);
        }

        $message = $request->get('message');
        if (!$message) {
            return $this->sendError([
                'message' => __('Message is required', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        $phoneNumber = $subscriber->phone;
        if (!$phoneNumber) {
            return $this->sendError([
                'message' => __('This contact does not have a phone number', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        if (!MessageThread::contactCanReceive('sms', $subscriber->id)) {
            return $this->sendError([
                'message' => __('This contact is not subscribed for SMS.', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        if (strlen($message) > 1600) { // Allow up to 10 SMS segments
            return $this->sendError([
                /* translators: %s: maximum message length, for example 1,600 */
                'message' => sprintf(__('The message is too long. The maximum length is %s characters.', 'fluentcampaign-pro'), number_format_i18n(1600)),
                'code' => 400
            ]);
        }

        $fromNumber = $request->get('from_number');
        $type = 'custom_sms';

        try { 

            $recipientName = trim((string) $subscriber->full_name) ?: $phoneNumber;

            $smsCampaign = MessageCampaign::create([
                /* translators: %s: contact name, or phone number when the name is empty */
                'title' => sprintf(__('Custom SMS to %s', 'fluentcampaign-pro'), $recipientName),
                'subscriber_id' => $contactId,
                'mobile_number' => $phoneNumber,
                'message_content' => $message,
                'type' => $type,
                'status' => LegacyMessage::STATUS_PENDING,
                'scheduled_at' => current_time('mysql'),
            ]);

            $smsMessage = MessageScheduler::sendNow(
                LegacyMessage::CHANNEL_SMS,
                $phoneNumber,
                $contactId,
                $message,
                [
                    'ref_type' => $smsCampaign->messageRefType(),
                    'ref_id'   => $smsCampaign->id
                ]
            );

            if (!$smsMessage) {
                return $this->sendError([
                    'message' => __('Failed to prepare SMS for sending', 'fluentcampaign-pro')
                ]);
            }

            $smsCampaign->recipients_count = 1;
            $smsCampaign->save();

            return $this->sendMessageOutcome(
                $smsMessage,
                __('SMS has been sent.', 'fluentcampaign-pro')
            );
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('Something went wrong while sending SMS', 'fluentcampaign-pro')
            ]);
        }

        

    }

    /**
     * A contact's consent status on one channel, and whether they can be messaged.
     */
    public function getConsent(Request $request, $subscriberId)
    {
        $subscriber = Subscriber::find($subscriberId);

        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Contact not found', 'fluentcampaign-pro')
            ], 404);
        }

        $channel = $this->resolveChannel($request);

        return [
            'consent' => [
                'status'   => MessageThread::contactStatus($channel, $subscriber->id),
                'can_send' => !empty($subscriber->phone)
                    && MessageThread::contactCanReceive($channel, $subscriber->id)
            ]
        ];
    }

    /**
     * Record an operator's consent decision for a contact on one channel.
     */
    public function updateConsent(Request $request, $subscriberId)
    {
        $subscriber = Subscriber::find($subscriberId);

        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Contact not found', 'fluentcampaign-pro')
            ], 404);
        }

        if (empty($subscriber->phone)) {
            return $this->sendError([
                'message' => __('This contact has no phone number, so there is no conversation to record consent on.', 'fluentcampaign-pro')
            ], 400);
        }

        $status = $request->getSafe('status', 'sanitize_text_field', '');

        if (!in_array($status, MessageThread::consentStatuses(), true)) {
            return $this->sendError([
                'message' => __('Value is not valid', 'fluentcampaign-pro')
            ], 422);
        }

        $channel = $this->resolveChannel($request);

        if (!MessageThread::setConsent($channel, $subscriber->phone, $status, $subscriber->id)) {
            return $this->sendError([
                'message' => __('Consent could not be recorded for this number.', 'fluentcampaign-pro')
            ], 400);
        }

        do_action('fluent_crm/contact_' . $channel . '_' . ($status === MessageThread::STATUS_SUBSCRIBED ? 'subscribed' : 'unsubscribed'), $subscriber, [
            'source' => 'admin'
        ]);

        // Consent belongs to the number, so contacts sharing it changed too.
        $sharedWith = max(0, count(PhoneMatcher::contactsForNumber($subscriber->phone)) - 1);
        $message = $sharedWith
            ? sprintf(
                /* translators: %d: number of other contacts with the same phone number */
                _n('Status updated. %d other contact shares this number and was updated too.', 'Status updated. %d other contacts share this number and were updated too.', $sharedWith, 'fluentcampaign-pro'),
                $sharedWith
            )
            : __('Status updated', 'fluentcampaign-pro');

        return [
            'message'     => $message,
            'shared_with' => $sharedWith,
            'consent'     => [
                'status'   => $status,
                'can_send' => $status === MessageThread::STATUS_SUBSCRIBED
            ]
        ];
    }

    public function getStats(Request $request, $subscriberId)
    {
        $subscriber = Subscriber::find($subscriberId);
        if (!$subscriber) {
            return $this->sendError([
                'message' => __('Contact not found', 'fluentcampaign-pro'),
                'code' => 404
            ]);
        }

        $channel = $this->resolveChannel($request);

        $thread = MessageThread::forContact($subscriberId, $channel);

        // Thread id 0 matches nothing, so no thread yields zeros.
        $base = Message::where('thread_id', $thread ? $thread->id : 0);

        return [
            'stats' => [
                'total_messages' => (clone $base)->count(),
                'campaign_messages' => (clone $base)->where('ref_type', Message::REF_CAMPAIGN)->count(),
                'automation_messages' => (clone $base)->where('ref_type', Message::REF_AUTOMATION)->count(),
                // Outbound that is not a campaign or automation.
                'custom_sms' => (clone $base)
                    ->where('direction', Message::DIRECTION_OUTBOUND)
                    ->where(function ($query) {
                        $query->whereNull('ref_type')
                            ->orWhereNotIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
                    })
                    ->count(),
                'sent_messages' => (clone $base)->whereIn('status', Message::SENT_STATUSES)->count(),
                'delivered_messages' => (clone $base)->whereIn('status', Message::DELIVERED_STATUSES)->count(),
                'failed_messages' => (clone $base)->where('status', Message::STATUS_FAILED)->count(),
                'pending_messages' => (clone $base)->whereIn('status', Message::UNFINISHED)->count(),
                'last_sent' => (clone $base)
                    ->whereNotNull('sent_at')
                    ->orderBy('sent_at', 'desc')
                    ->value('sent_at')
            ]
        ];
    }

    /**
     * Map the profile tab's legacy sms_type filter onto fc_messages columns.
     */
    protected function applyLogFilter($query, $filter)
    {
        if ($filter === LegacyMessage::TYPE_CAMPAIGN || $filter === LegacyMessage::TYPE_AUTOMATION) {
            return $query->where('ref_type', $filter);
        }

        if ($filter === 'incoming') {
            return $query->where('direction', Message::DIRECTION_INBOUND);
        }

        // custom_sms and anything unrecognised: outbound with no campaign or automation.
        return $query->where('direction', Message::DIRECTION_OUTBOUND)
            ->where(function ($query) {
                $query->whereNull('ref_type')
                    ->orWhereNotIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
            });
    }

    /**
     * The legacy `sms_type` for a message, used by the profile tab.
     */
    protected function logType($message)
    {
        if ($message->direction === Message::DIRECTION_INBOUND) {
            return 'incoming';
        }

        if (in_array($message->ref_type, [Message::REF_CAMPAIGN, Message::REF_AUTOMATION], true)) {
            return $message->ref_type;
        }

        return LegacyMessage::TYPE_CUSTOM_SMS;
    }

    /**
     * The request's `channel` (sms or whatsapp); anything else falls back to sms.
     *
     * @param Request $request
     * @return string
     */
    private function resolveChannel(Request $request)
    {
        $channel = sanitize_key((string) $request->get('channel', ''));

        return in_array($channel, [LegacyMessage::CHANNEL_SMS, LegacyMessage::CHANNEL_WHATSAPP], true)
            ? $channel
            : LegacyMessage::CHANNEL_SMS;
    }


    public function getContactEstimation(Request $request)
    {
        $start_time = microtime(true);

        $filterType = $request->get('sending_filter', 'list_tag');

        $subscribersSettings = [
            'sending_filter' => $filterType
        ];

        if ($filterType == 'list_tag') {
            $subscribersSettings['subscribers'] = $request->get('subscribers', []);
            $subscribersSettings['excludedSubscribers'] = $request->get('excludedSubscribers', []);
        } else if ($filterType == 'dynamic_segment') {
            $subscribersSettings['dynamic_segment'] = $request->get('dynamic_segment', []);
        } else if ($filterType == 'advanced_filters') {
            $subscribersSettings['advanced_filters'] = Helper::parseArrayOrJson($request->get('advanced_filters'));
        } else {
            return [
                'count' => 0
            ];
        }

        // The channel decides which consent applies to the count.
        $campaign = new MessageCampaign();
        $campaign->channel = $this->resolveChannel($request);

        $count = $campaign->getSubscriberIdsCountBySegmentSettings($subscribersSettings);

        return [
            'count'          => $count,
            'execution_time' => microtime(true) - $start_time
        ];
    }

    public function getRecipientsCount(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::withoutGlobalScope('type')->findOrFail($campaignId);
        $preProcessedStatuses = [
            'draft',
            'processing',
            'pending-scheduled'
        ];

        if (Arr::get($campaign->settings, 'sending_filter') === 'one_time') {
            return [
                'estimated_count' => (int) Arr::get($campaign->settings, 'one_time_audience.accepted_count', $campaign->recipients_count)
            ];
        }

        if (in_array($campaign->status, $preProcessedStatuses)) {
            $count = $campaign->getSubscribersModel()->count();
        } else {
            $count = $campaign->recipients_count;
        }

        return [
            'estimated_count' => $count
        ];
    }

    public function uploadOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be changed while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $result = (new OneTimeAudienceImporter())->startUpload($campaign, $request->file('file'));
        } catch (\LengthException $e) {
            return $this->sendError(['message' => $e->getMessage()], 413);
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'import_session' => $result
        ]);
    }

    public function pasteOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be changed while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $result = (new OneTimeAudienceImporter())->startPaste($campaign, (string) $request->get('content', ''));
        } catch (\LengthException $e) {
            return $this->sendError(['message' => $e->getMessage()], 413);
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'import_session' => $result
        ]);
    }

    public function processOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be processed while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $result = (new OneTimeAudienceImporter())->process($campaign, $request->all());
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'import_session' => $result
        ]);
    }

    public function activateOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be activated while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        try {
            $audience = (new OneTimeAudienceImporter())->activate(
                $campaign,
                $request->getSafe('token', 'sanitize_text_field', ''),
                $request->get('confirm_consent') === true || $request->get('confirm_consent') === 'true'
            );
        } catch (\Exception $e) {
            return $this->sendError(['message' => $e->getMessage()], 422);
        }

        return $this->sendSuccess([
            'audience' => $audience,
            'campaign' => MessageCampaign::findOrFail($campaignId)
        ]);
    }

    public function getOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        return $this->sendSuccess([
            'audience' => (new OneTimeAudienceImporter())->audience($campaign)
        ]);
    }

    public function getOneTimeAudienceRecipients(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);
        $import = OneTimeAudienceMeta::getImportSession($campaign->id);
        $settings = OneTimeAudienceMeta::getAudienceSettings($campaign);
        $batchId = (string) (Arr::get($import, 'batch_id') ?: Arr::get($settings, 'active_batch_id', ''));

        if (!$batchId) {
            return $this->sendSuccess([
                'recipients' => [
                    'data'         => [],
                    'total'        => 0,
                    'per_page'     => 50,
                    'current_page' => 1,
                    'last_page'    => 1
                ]
            ]);
        }

        $page = max(1, (int) $request->get('page', 1));
        $perPage = min(100, max(10, (int) $request->get('per_page', 50)));
        $query = OneTimeAudienceMeta::messageBatchQuery($campaign->id, $batchId)
            ->orderBy('id', 'ASC');
        $total = (int) $query->count();
        $rows = $query->offset(($page - 1) * $perPage)
            ->limit($perPage)
            ->get(['id', 'thread_id', 'meta']);

        $threadIds = [];
        foreach ($rows as $row) {
            $threadIds[] = (int) $row->thread_id;
        }

        $threads = $threadIds
            ? MessageThread::whereIn('id', array_values(array_unique($threadIds)))->get()->keyBy('id')
            : [];

        $items = [];
        foreach ($rows as $row) {
            $thread = $threads ? $threads->get((int) $row->thread_id) : null;
            $meta = is_array($row->meta) ? $row->meta : [];
            $recipient = Arr::get($meta, 'one_time_recipient', []);
            $recipient = is_array($recipient) ? $recipient : [];

            $items[] = [
                'id'           => (int) $row->id,
                'phone_number' => $thread ? (string) $thread->phone_number : (string) Arr::get($recipient, 'phone_number', ''),
                'full_name'    => (string) Arr::get($recipient, 'full_name', ''),
                'contact_id'   => $thread ? (int) $thread->contact_id : 0
            ];
        }

        return $this->sendSuccess([
            'recipients' => [
                'data'         => $items,
                'total'        => $total,
                'per_page'     => $perPage,
                'current_page' => $page,
                'last_page'    => max(1, (int) ceil($total / $perPage))
            ]
        ]);
    }

    public function clearOneTimeAudience(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status !== 'draft') {
            return $this->sendError([
                'message' => __('Audience can only be cleared while the campaign is a draft.', 'fluentcampaign-pro')
            ], 422);
        }

        return $this->sendSuccess([
            'audience' => (new OneTimeAudienceImporter())->clear($campaign),
            'campaign' => MessageCampaign::findOrFail($campaignId)
        ]);
    }

    public function schedule(Request $request, $campaignId)
    {
        $scheduleAt = $request->get('scheduled_at');
        $smsCampaign = MessageCampaign::findOrFail($campaignId);

        if (Arr::get($smsCampaign->settings, 'sending_filter') === 'one_time') {
            if (!OneTimeAudienceMeta::hasConfirmedConsent($smsCampaign)) {
                return $this->sendError([
                    'message' => __('Please confirm consent for the one-time audience before scheduling.', 'fluentcampaign-pro')
                ], 422);
            }

            if (($smsCampaign->channel ?: LegacyMessage::CHANNEL_SMS) === LegacyMessage::CHANNEL_WHATSAPP && !(int) Arr::get($smsCampaign->settings, 'template_id')) {
                return $this->sendError([
                    'message' => __('One-time WhatsApp campaigns require an approved template.', 'fluentcampaign-pro')
                ], 422);
            }
        }

        if ($smsCampaign->status != 'draft') {
            return $this->sendError([
                'message' => __('Campaign is not in draft status. Please reload the page.', 'fluentcampaign-pro')
            ], 422);
        }

        if ($smsCampaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_status_active', $smsCampaign);
        } else {
            do_action('fluent_crm/sms_campaign_status_active', $smsCampaign);
        }

        // Clear actions left from an earlier schedule.
        MessageScheduler::clearPendingCampaignActions($campaignId);

        if($scheduleAt) {
            $sendingType = $request->get('sending_type', 'schedule');

            // Only plain scheduling is supported.
            if ($sendingType != 'schedule') {
                return $this->sendError([
                    'message' => __('Unsupported sending type', 'fluentcampaign-pro')
                ], 422);
            }

            $scheduleAt = $this->normalizeScheduleDateTime($scheduleAt);
            if (!$scheduleAt) {
                return $this->sendError([
                    'message' => __('Invalid schedule date', 'fluentcampaign-pro')
                ], 422);
            }

            $settings = $smsCampaign->settings;
            $settings['sending_type'] = 'schedule';

            $data = [
                'status'           => 'pending-scheduled',
                'updated_at'       => fluentCrmTimestamp(),
                'scheduled_at'     => $scheduleAt,
                'recipients_count' => 0,
                'settings'         => maybe_serialize($settings)
            ];

            $message = __('The campaign has been scheduled.', 'fluentcampaign-pro');
            MessageCampaign::where('id', $campaignId)->update($data);

            // scheduled_at is site-local; Action Scheduler needs UTC. Generate five minutes early.
            $generateAt = max(time(), (int) get_gmt_from_date($scheduleAt, 'U') - 300);
            MessageScheduler::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaignId, $generateAt);

        } else {

            $message = __('Campaign is starting now', 'fluentcampaign-pro');

            $settings = $smsCampaign->settings;
            $settings['sending_type'] = 'instant';

            $data = [
                'status'           => 'pending-scheduled',
                'updated_at'       => fluentCrmTimestamp(),
                'scheduled_at'     => date('Y-m-d H:i:s', current_time('timestamp')), // send immediately
                'recipients_count' => 0,
                'settings'         => maybe_serialize($settings)
            ];

            MessageCampaign::where('id', $campaignId)->update($data);
        }

        fluentcrm_update_sms_campaign_meta($smsCampaign->id, '_sms_campaign_sent_by', get_current_user_id());

        $smsCampaign = MessageCampaign::findOrFail($campaignId);

        if ($scheduleAt) {
            if ($smsCampaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
                do_action('fluent_crm/whatsapp_campaign_scheduled', $smsCampaign, $smsCampaign->scheduled_at);
            } else {
                do_action('fluent_crm/sms_campaign_scheduled', $smsCampaign, $smsCampaign->scheduled_at);
            }
        } else {
            MessageScheduler::scheduleCampaignAction('fluentcrm_generate_message_batch', $campaignId);
        }

        return $this->sendSuccess([
            'campaign'          => $smsCampaign,
            'message'           => $message,
            'current_timestamp' => fluentCrmTimestamp()
        ]);
    }

    /**
     * Build the response for an inline send from the message's final status.
     *
     * @param \FluentCampaign\App\Modules\Messaging\Models\Message $message the row after the attempt
     * @param string $successMessage
     * @param array $extra additional payload
     */
    private function sendMessageOutcome($message, $successMessage, $extra = [])
    {
        if ($message->status === Message::STATUS_FAILED) {
            $meta = is_array($message->meta) ? $message->meta : [];

            return $this->sendError(array_merge($extra, [
                'message' => Arr::get($meta, 'error_message')
                    ?: __('The message could not be sent.', 'fluentcampaign-pro')
            ]), 422);
        }

        // Still claimable: the message stays queued for another worker.
        if (in_array($message->status, Message::CLAIMABLE, true)) {
            return $this->sendSuccess(array_merge($extra, [
                'message' => __('Queued. It will be sent as soon as its queue worker runs.', 'fluentcampaign-pro')
            ]));
        }

        return $this->sendSuccess(array_merge($extra, [
            'message' => $successMessage
        ]));
    }

    /**
     * Normalize mixed datetime inputs into mysql datetime string.
     *
     * Accepts unix timestamps, mysql datetime strings, and ISO-8601 strings.
     *
     * @param mixed $value
     * @return string|null
     */
    private function normalizeScheduleDateTime($value)
    {
        if (is_numeric($value)) {
            $timestamp = (int)$value;
            return $timestamp ? wp_date('Y-m-d H:i:s', $timestamp, wp_timezone()) : null;
        }

        if (!is_string($value)) {
            return null;
        }

        $value = sanitize_text_field($value);
        if (!$value) {
            return null;
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value)) {
            return $value;
        }

        $timestamp = strtotime($value);
        if ($timestamp === false) {
            return null;
        }

        return wp_date('Y-m-d H:i:s', $timestamp, wp_timezone());
    }

    public function pauseCampaign(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        if ($campaign->status != 'working') {
            return $this->sendError([
                'message' => __('You can only pause a campaign that is in the "Working" state. Please reload this page.', 'fluentcampaign-pro')
            ]);
        }

        $campaign->status = 'paused';
        $campaign->save();

        Message::forCampaign($campaign->id)
                     ->whereIn('status', [Message::STATUS_SCHEDULED, Message::STATUS_PENDING, Message::STATUS_SCHEDULING])
                     ->update([
                         'status' => 'paused'
                     ]);

        return [
            'message'  => __('Campaign has been successfully marked as paused', 'fluentcampaign-pro'),
            'campaign' => $campaign
        ];
    }

    public function resumeCampaign(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        if ($campaign->status != 'paused') {
            return $this->sendError([
                'message' => __('You can only resume a campaign that is in the "paused" state. Please reload this page.', 'fluentcampaign-pro')
            ]);
        }

        $campaign->status = 'working';
        $campaign->save();

        Message::forCampaign($campaign->id)
                     ->where('status', 'paused')
                     ->update([
                         'status'       => Message::STATUS_SCHEDULED,
                         'scheduled_at' => current_time('mysql')
                     ]);

        // Clear old pending actions before starting a fresh send chain.
        MessageScheduler::clearPendingCampaignActions($campaign->id);

        MessageScheduler::scheduleCampaignAction('fluentcrm_send_message_batch', $campaign->id);

        return [
            'message'  => __('Campaign has been successfully resumed', 'fluentcampaign-pro'),
            'campaign' => $campaign
        ];
    }

    public function duplicateCampaign(Request $request, $id)
    {
        $oldCampaign = MessageCampaign::findOrFail($id);
        $settings = is_array($oldCampaign->settings) ? $oldCampaign->settings : [];
        $opensAtAudienceStep = Arr::get($settings, 'sending_filter') === 'one_time';

        if ($opensAtAudienceStep) {
            unset($settings['one_time_audience']);
            $settings['sending_filter'] = 'list_tag';
        }

        $newCampaign = [
            'title'            => sprintf(
                /* translators: %s is the title of the campaign being duplicated */
                __('[Duplicate] %s', 'fluentcampaign-pro'),
                $oldCampaign->title
            ),
            'message_content'  => $oldCampaign->message_content,
            'status'           => 'draft',
            'created_by'       => get_current_user_id(),
            'settings'         => $settings,
            'sender_number'    => $oldCampaign->sender_number,
            // Copy the channel explicitly; the column default is 'sms'.
            'channel'          => $oldCampaign->channel ?: LegacyMessage::CHANNEL_SMS
        ];
        $labelIds = $oldCampaign->getFormattedLabels()->pluck('id')->toArray();

        $campaign = MessageCampaign::create($newCampaign);
        $campaign->attachLabels($labelIds);

        if ($opensAtAudienceStep) {
            fluentcrm_update_sms_campaign_meta($campaign->id, '_next_config_step', 1);
            $campaign->next_step = 1;
        }

        if ($campaign->channel === MessageCampaign::CHANNEL_WHATSAPP) {
            do_action('fluent_crm/whatsapp_campaign_duplicated', $campaign, $oldCampaign);
        } else {
            do_action('fluent_crm/sms_campaign_duplicated', $campaign, $oldCampaign);
        }

        return [
            'campaign' => $campaign,
            'message'  => __('Campaign has been successfully duplicated', 'fluentcampaign-pro')
        ];

    }

    public function unSchedule(Request $request, $id)
    {
        $campaign = MessageCampaign::findOrFail($id);

        // A failed generation is also returned to draft from here so the audience can be fixed.
        $validStatuses = [
            'scheduled',
            'pending-scheduled',
            'processing',
            MessageCampaign::STATUS_FAILED
        ];

        if (!in_array($campaign->status, $validStatuses)) {
            return $this->sendError([
                'message' => __('You can only unschedule a campaign that is in the "scheduled" state. Please reload this page.', 'fluentcampaign-pro')
            ]);
        }

        if ($campaign->status == 'processing' && strtotime($campaign->scheduled_at) < current_time('timestamp')) {
            return $this->sendError([
                'message' => __('You can only unschedule a campaign that is in the "scheduled" state. Please reload this page.', 'fluentcampaign-pro')
            ]);
        }

        // Set draft before clearing actions, so a running generator sees the new status at its next check.
        $campaign->status = 'draft';
        $campaign->save();
        MessageScheduler::clearPendingCampaignActions($campaign->id);

        // Delete only queued messages; sent/failed rows are kept as history.
        Message::forCampaign($campaign->id)
                     ->whereIn('status', [Message::STATUS_SCHEDULED, Message::STATUS_SCHEDULING, Message::STATUS_PENDING])
                     ->delete();

        return [
            'message' => __('The campaign has been unscheduled and returned to draft.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Get all SMS messages with pagination and filtering
     *
     * @param  Request  $request
     *
     * @return array
     */
    public function getAllMessages(Request $request)
    {
        global $wpdb;

        $perPage = $request->get('per_page', 10);
        $page = $request->get('page', 1);
        $search = $request->getSafe('search', 'sanitize_text_field', '');
        $channel = sanitize_key($request->get('channel', ''));

        // Comma-joined multi-selects; unknown values are dropped.
        $statusFilter = array_values(array_intersect(
            array_filter(array_map('sanitize_key', explode(',', (string) $request->get('status', '')))),
            [
                LegacyMessage::STATUS_PENDING,
                LegacyMessage::STATUS_SENT,
                LegacyMessage::STATUS_DELIVERED,
                LegacyMessage::STATUS_FAILED,
                LegacyMessage::STATUS_CANCELLED,
                LegacyMessage::STATUS_RECEIVED,
            ]
        ));

        $typeFilter = array_values(array_intersect(
            array_filter(array_map('sanitize_key', explode(',', (string) $request->get('sms_type', '')))),
            [
                LegacyMessage::TYPE_CAMPAIGN,
                LegacyMessage::TYPE_AUTOMATION,
                LegacyMessage::TYPE_CUSTOM_SMS,
                LegacyMessage::TYPE_BROADCAST,
                'incoming',
            ]
        ));

        $isRealChannel = in_array($channel, [LegacyMessage::CHANNEL_SMS, LegacyMessage::CHANNEL_WHATSAPP], true);

        // The channel lives on the thread.
        $channelScope = function ($query) use ($channel) {
            $query->where('channel', $channel);
        };

        $query = Message::with(['thread', 'thread.subscriber'])
            // `activity_at` is the indexed form of COALESCE(sent_at, scheduled_at, created_at).
            ->orderBy('activity_at', 'DESC')
            ->orderBy('id', 'DESC');

        if ($isRealChannel) {
            $query->whereHas('thread', $channelScope);
        }

        if ($statusFilter) {
            $query->whereIn('status', $statusFilter);
        }

        if ($typeFilter) {
            $this->applyTypeFilter($query, $typeFilter);
        }

        if ($search) {
            // The subscriber scope escapes its own input.
            $like = '%' . $wpdb->esc_like($search) . '%';
            $query->where(function ($q) use ($like, $search) {
                $q->where('content', 'LIKE', $like)
                    ->orWhereHas('thread', function ($threadQuery) use ($like, $search) {
                        $threadQuery->where('phone_number', 'LIKE', $like)
                            ->orWhereHas('subscriber', function ($subscriberQuery) use ($search) {
                                $subscriberQuery->searchBy($search);
                            });
                    });
            });
        }

        $messages = $query->paginate($perPage, ['*'], 'page', $page);

        // Status counts for the filter dropdown, scoped to the list's channel.
        $statusCountQuery = Message::selectRaw('status, COUNT(*) as count')
            ->whereNotNull('status');
        if ($isRealChannel) {
            $statusCountQuery->whereHas('thread', $channelScope);
        }
        $statusCounts = $statusCountQuery
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();

        $allowedStatuses = [
            LegacyMessage::STATUS_PENDING,
            LegacyMessage::STATUS_SENT,
            LegacyMessage::STATUS_DELIVERED,
            LegacyMessage::STATUS_FAILED,
            LegacyMessage::STATUS_CANCELLED,
            LegacyMessage::STATUS_RECEIVED
        ];

        $statuses = [];
        foreach ($allowedStatuses as $allowedStatus) {
            if (!isset($statusCounts[$allowedStatus])) {
                continue;
            }

            $statuses[] = [
                'value' => $allowedStatus,
                'label' => ucwords(str_replace('_', ' ', $allowedStatus)),
                'count' => (int)$statusCounts[$allowedStatus]
            ];
        }

        return [
            'sms' => [
                'data' => $this->formatActivityRows($messages->items()),
                'total' => $messages->total(),
                'per_page' => $messages->perPage(),
                'current_page' => $messages->currentPage(),
                'last_page' => $messages->lastPage(),
                'from' => $messages->firstItem(),
                'to' => $messages->lastItem(),
                'next_page_url' => $messages->nextPageUrl(),
                'prev_page_url' => $messages->previousPageUrl()
            ],
            'statuses' => $statuses
        ];
    }

    /**
     * Map the activity list's legacy `sms_type` filter onto direction and `ref_type`.
     */
    protected function applyTypeFilter($query, array $typeFilter)
    {
        $refTypes = array_values(array_intersect(
            $typeFilter,
            [LegacyMessage::TYPE_CAMPAIGN, LegacyMessage::TYPE_AUTOMATION]
        ));

        $wantsIncoming = in_array('incoming', $typeFilter, true);

        // custom_sms and broadcast: outbound with no campaign or automation.
        $wantsCustom = (bool) array_intersect(
            $typeFilter,
            [LegacyMessage::TYPE_CUSTOM_SMS, LegacyMessage::TYPE_BROADCAST]
        );

        return $query->where(function ($query) use ($refTypes, $wantsIncoming, $wantsCustom) {
            if ($refTypes) {
                $query->orWhereIn('ref_type', $refTypes);
            }

            if ($wantsIncoming) {
                $query->orWhere('direction', Message::DIRECTION_INBOUND);
            }

            if ($wantsCustom) {
                $query->orWhere(function ($query) {
                    $query->where('direction', Message::DIRECTION_OUTBOUND)
                        ->where(function ($query) {
                            $query->whereNull('ref_type')
                                ->orWhereNotIn('ref_type', [Message::REF_CAMPAIGN, Message::REF_AUTOMATION]);
                        });
                });
            }
        });
    }

    /**
     * Shape one page of messages for the activity table, loading campaign titles in one query.
     *
     * @param array $rows Message models
     * @return array
     */
    protected function formatActivityRows($rows)
    {
        $campaignIds = [];
        foreach ($rows as $row) {
            if ($row->ref_id && in_array($row->ref_type, [Message::REF_CAMPAIGN, Message::REF_AUTOMATION], true)) {
                $campaignIds[(int) $row->ref_id] = (int) $row->ref_id;
            }
        }

        $campaigns = [];
        if ($campaignIds) {
            foreach (MessageCampaign::withoutGlobalScope('type')->whereIn('id', $campaignIds)->get(['id', 'title']) as $campaign) {
                $campaigns[(int) $campaign->id] = ['title' => $campaign->title];
            }
        }

        $formatted = [];

        foreach ($rows as $row) {
            $thread = $row->thread;

            $formatted[] = [
                'id'              => (int) $row->id,
                'message_content' => $row->content,
                'mobile_number'   => $thread ? $thread->phone_number : '',
                'channel'         => $thread ? $thread->channel : LegacyMessage::CHANNEL_SMS,
                'sms_type'        => $this->logType($row),
                'status'          => $row->status,
                'direction'       => $row->direction,
                // Raw strings; serialized DateTime objects are unparseable in the browser.
                'sent_at'         => $row->rawDate('sent_at'),
                'scheduled_at'    => $row->rawDate('scheduled_at'),
                'created_at'      => $row->rawDate('created_at'),
                'subscriber_id'   => $thread && $thread->contact_id ? (int) $thread->contact_id : null,
                'subscriber'      => $thread && $thread->subscriber ? $thread->subscriber : null,
                'campaign'        => isset($campaigns[(int) $row->ref_id]) ? $campaigns[(int) $row->ref_id] : null
            ];
        }

        return $formatted;
    }

    /**
     * Delete multiple SMS messages
     *
     * @param Request $request
     */
    public function deleteMessages(Request $request)
    {
        $ids = $request->get('ids', []);
        
        if (empty($ids)) {
            return $this->sendError([
                'message' => __('Select at least one message to delete.', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        // Collect thread ids so their caches can be recomputed after the delete.
        $threadIds = Message::whereIn('id', $ids)->pluck('thread_id')->toArray();

        $deleted = Message::whereIn('id', $ids)->delete();

        MessageThread::syncCaches($threadIds);

        return $this->sendSuccess([
            'message' => sprintf(
                /* translators: %d: number of messages deleted */
                _n('%d message deleted.', '%d messages deleted.', $deleted, 'fluentcampaign-pro'),
                $deleted
            ),
            'deleted_count' => $deleted
        ]);
    }

    /**
     * Resend a specific SMS message
     *
     * @param Request $request
     * @param int $message_id
     */
    public function resendMessage(Request $request, $id)
    {
        $originalMessage = Message::with(['thread'])->find($id);

        if (!$originalMessage) {
            return $this->sendError([
                'message' => __('The message was not found.', 'fluentcampaign-pro'),
                'code' => 404
            ]);
        }

        $thread = $originalMessage->thread;

        if (!$thread) {
            return $this->sendError([
                'message' => __('The conversation was not found.', 'fluentcampaign-pro'),
                'code' => 404
            ]);
        }

        // Opt-in/opt-out confirmations are system compliance replies tied to the
        // consent change that produced them; they are not admin content to resend.
        if ($originalMessage->ref_type === SMSHelper::CONFIRMATION_REF_TYPE) {
            return $this->sendError([
                'message' => __('Opt-in and opt-out confirmations cannot be resent.', 'fluentcampaign-pro'),
                'code'    => 422
            ]);
        }

        // Resend to the thread's number, not the contact's current one.
        $phoneNumber = $thread->phone_number;
        if (!$phoneNumber) {
            return $this->sendError([
                'message' => __('This conversation does not have a phone number.', 'fluentcampaign-pro'),
                'code' => 400
            ]);
        }

        // A number or contact that opted out is not messaged again, whichever thread it is on.
        $resendChannel = $thread->channel ?: LegacyMessage::CHANNEL_SMS;
        if (
            !MessageThread::numberCanReceive($resendChannel, $phoneNumber) ||
            ($thread->contact_id && !MessageThread::contactCanReceive($resendChannel, $thread->contact_id))
        ) {
            return $this->sendError([
                'message' => __('This recipient has opted out of these messages, so the message cannot be resent.', 'fluentcampaign-pro'),
                'code'    => 422
            ]);
        }

        $messageContent = (string) $originalMessage->content;
        if (strlen($messageContent) > 1600) {
            return $this->sendError([
                /* translators: %s: maximum message length, for example 1,600 */
                'message' => sprintf(__('The original message is too long to resend. The maximum length is %s characters.', 'fluentcampaign-pro'), number_format_i18n(1600)),
                'code' => 400
            ]);
        }

        // Keep the WhatsApp template so the resend works outside the 24-hour window.
        $copiedMetaKeys = ['template_id', 'settings'];

        // Automation smartcodes resolve through the funnel subscriber.
        if ($originalMessage->ref_type === Message::REF_AUTOMATION) {
            $copiedMetaKeys[] = 'funnel_subscriber_id';
        }

        try {
            // The resend is a new message on the same thread.
            $newMessage = MessageThread::queueOutbound(
                $thread->channel ?: LegacyMessage::CHANNEL_SMS,
                $phoneNumber,
                $thread->contact_id,
                $messageContent,
                [
                    'ref_type' => $originalMessage->ref_type,
                    'ref_id'   => $originalMessage->ref_id,
                    'meta'     => array_intersect_key(
                        is_array($originalMessage->meta) ? $originalMessage->meta : [],
                        array_flip($copiedMetaKeys)
                    )
                ]
            );

            if (!$newMessage) {
                return $this->sendError([
                    'message' => __('Failed to queue SMS for resending', 'fluentcampaign-pro'),
                    'code' => 500
                ]);
            }

            MessageScheduler::dispatch($newMessage->id);

            $newMessage = Message::find($newMessage->id) ?: $newMessage;

            return $this->sendMessageOutcome(
                $newMessage,
                __('Message has been resent.', 'fluentcampaign-pro'),
                ['new_message_id' => $newMessage->id]
            );
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('Failed to queue SMS for resending', 'fluentcampaign-pro'),
                'code' => 500
            ]);
        }
    }

    public function handleBulkAction(Request $request)
    {
        $actionName = $request->getSafe('action_name', 'sanitize_text_field', '');
        // Only the ids the user selected; there is no "every campaign in the channel" mode.
        $requestedCampaignIds = $request->get('campaign_ids', []);
        $campaignIds = array_values(array_unique(array_filter(array_map(
            'intval',
            is_array($requestedCampaignIds) ? $requestedCampaignIds : []
        ))));

        if (!$campaignIds) {
            return $this->sendError([
                'message' => __('Please provide campaign IDs', 'fluentcampaign-pro')
            ]);
        }

        if ($actionName == 'apply_labels') {
            $newLabels = array_values(array_unique(array_filter(array_map(
                'intval',
                (array) $request->get('labels', [])
            ))));

            if (!$newLabels) {
                return $this->sendError([
                    'message' => __('Please provide labels', 'fluentcampaign-pro')
                ]);
            }

            $campaigns = MessageCampaign::whereIn('id', $campaignIds)->get();

            foreach ($campaigns as $campaign) {
                $campaign->attachLabels($newLabels);
            }

            return $this->sendSuccess([
                'message' => __('Labels have been applied successfully', 'fluentcampaign-pro'),
            ]);

        }

        if ($actionName == 'delete_campaigns') {
            $campaigns = MessageCampaign::whereIn('id', $campaignIds)->get();
            foreach ($campaigns as $campaign) {
                $campaignId = $campaign->id;
                MessageScheduler::clearPendingCampaignActions($campaignId);
                $channel = $campaign->channel ?: MessageCampaign::CHANNEL_SMS;
                $campaign->deleteCampaignData();
                $campaign->delete();
                do_action('fluent_crm/' . $channel . '_campaign_deleted', $campaignId);
            }

            return $this->sendSuccess([
                'message' => __('Selected campaigns have been permanently deleted', 'fluentcampaign-pro'),
            ]);
        }

        return $this->sendError([
            'message' => __('Invalid bulk action', 'fluentcampaign-pro')
        ]);
    }

    public function updateLabels(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);
        $action = $request->getSafe('action', 'sanitize_key', 'detach');
        $labelIds = $request->get('label_ids', []);

        if (!is_array($labelIds)) {
            $labelIds = [$labelIds];
        }

        $labelIds = array_values(array_unique(array_filter(array_map('intval', $labelIds))));

        if (!$labelIds) {
            return $this->sendError([
                'message' => __('Please provide labels', 'fluentcampaign-pro')
            ]);
        }

        if ($action === 'detach') {
            $campaign->detachLabels($labelIds);
        } else {
            $campaign->attachLabels($labelIds);
        }

        return $this->sendSuccess([
            'message' => __('Labels have been updated', 'fluentcampaign-pro')
        ]);
    }

    public function getCampaignStatus(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::whereIn('type', ['campaign', 'automation'])
            ->findOrFail($campaignId);

        if ($campaign->status == 'processing' || $campaign->status == 'pending-scheduled') {
            return [
                'current_timestamp' => fluentCrmTimestamp(),
                'stat'              => [],
                'campaign'          => $campaign,
                'sent_count'        => 0,
                'analytics'         => [],
                'subject_analytics' => []
            ];
        }
        if ($campaign->status == 'scheduled' && $campaign->scheduled_at) {
            if (strtotime($campaign->scheduled_at) < strtotime(current_time('mysql'))) {
                $campaign->status = 'working';
                $campaign->save();
            }
        }

        $analytics = [];

        $sentCount = Message::forCampaign($campaignId)
                                  ->whereIn('status', Message::SENT_STATUSES)
                                  ->count();


        if ($campaign->status == 'archived') {

            if (isset($analytics['open']) && $analytics['open']['total'] > $sentCount) {
                $analytics['open']['total'] = $sentCount;
            }

            if (isset($analytics['click']) && $analytics['click']['total'] > $sentCount) {
                $analytics['click']['total'] = $sentCount;
            }

        }

        $stat = Message::forCampaign($campaignId)
                             ->select('status', fluentCrmDb()->raw('count(*) as total'))
                             ->groupBy('status')
                             ->get();

        $CampaignSentBy = $this->getCampaignSentData($campaign->id);
        $campaign->sent_by = $CampaignSentBy;
        $this->attachGenerationError($campaign);

        return $this->sendSuccess([
            'current_timestamp' => fluentCrmTimestamp(),
            'stat'              => $stat,
            'campaign'          => $campaign,
            'sent_count'        => $sentCount,
            'analytics'         => $analytics,
        ], 200);


    }

    /**
     * Expose why recipient generation failed, as `generation_error`, on a failed campaign.
     * MessageHandler::failGeneration() stores the reason in campaign meta.
     */
    private function attachGenerationError(MessageCampaign $campaign)
    {
        if ($campaign->status !== MessageCampaign::STATUS_FAILED) {
            return;
        }

        $campaign->generation_error = (string) fluentcrm_get_sms_campaign_meta(
            $campaign->id,
            '_one_time_generation_error',
            true
        );
    }

    public function getCampaignRecipients(Request $request, $campaignId)
    {
        global $wpdb;

        $filterType = $request->get('filter_type');
        $search = $request->getSafe('search', 'sanitize_text_field');

        // The contact is loaded through the thread and exposed as `subscriber` below.
        $smsQuery = Message::with(['thread', 'thread.subscriber'])->forCampaign($campaignId);

        if ($search) {
            $searchLike = '%' . $wpdb->esc_like($search) . '%';
            $smsQuery->whereHas('thread', function ($threadQuery) use ($search, $searchLike) {
                $threadQuery->where('phone_number', 'LIKE', $searchLike)
                    ->orWhereHas('subscriber', function ($q) use ($search) {
                        $q->searchBy($search);
                    });
            });
        }

        $filterType = in_array($filterType, ['click', 'failed', 'sent', 'delivered']) ? $filterType : '';

        if ($filterType == 'failed') {
            $smsQuery = $smsQuery->where('status', Message::STATUS_FAILED);
        } else if ($filterType == 'sent') {
            $smsQuery = $smsQuery->whereIn('status', Message::SENT_STATUSES);
        } else if ($filterType == 'delivered') {
            $smsQuery = $smsQuery->whereIn('status', Message::DELIVERED_STATUSES);
        }

        $smsQuery = $smsQuery->orderBy('created_at', 'DESC');

        $smsMessages = $smsQuery->paginate();

        foreach ($smsMessages->items() as $recipient) {
            $thread = $recipient->thread;
            $subscriber = $thread ? $thread->subscriber : null;
            $recipientMeta = is_array($recipient->meta) ? $recipient->meta : [];
            $oneTimeRecipient = Arr::get($recipientMeta, 'one_time_recipient', []);
            $oneTimeRecipient = is_array($oneTimeRecipient) ? $oneTimeRecipient : [];

            $recipient->subscriber = $subscriber;
            $recipient->subscriber_id = $subscriber ? (int) $subscriber->id : null;
            $recipient->recipient_name = $subscriber ? $subscriber->full_name : (string) Arr::get($oneTimeRecipient, 'full_name', '');
            $recipient->recipient_email = $subscriber ? $subscriber->email : '';
            $recipient->recipient_phone = $thread ? $thread->phone_number : (string) Arr::get($oneTimeRecipient, 'phone_number', '');
            $recipient->subscriber_photo = $subscriber ? $subscriber->photo : '';
            $recipient->one_time_recipient = $oneTimeRecipient ?: null;
            $recipient->created_at = $recipient->rawDate('created_at');
        }

        return $this->sendSuccess([
            'recipients'  => $smsMessages,
            'failed_counts' => Message::forCampaign($campaignId)->where('status', Message::STATUS_FAILED)->count()
        ]);
    }

    private function getCampaignSentData($campaignId)
    {
        $campaignSentById = fluentcrm_get_sms_campaign_meta($campaignId, '_sms_campaign_sent_by', true);
        $user = get_userdata($campaignSentById);
        if($user) {
            return $user->display_name . ' (' . $user->user_email . ')';
        }
        return false;
    }

    public function processingStat(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::whereIn('type', fluentCrmAutoProcessSmsCampaignTypes())
            ->findOrFail($campaignId);

        if ($campaign->status != 'processing') {
            return [
                'reload'   => true,
                'campaign' => $campaign
            ];
        }

        $completedCount = Message::forCampaign($campaignId)
            ->whereIn('status', [Message::STATUS_SENT, Message::STATUS_DELIVERED, Message::STATUS_FAILED])
            ->count();

        if (!$campaign->recipients_count || $campaign->recipients_count < $completedCount) {
            $campaign->recipients_count = $completedCount;
        }

        $sendingType = '';
        if (!empty($campaign->settings) && is_array($campaign->settings)) {
            $sendingType = $campaign->settings['sending_type'] ?? '';
        }

        return [
            'reload'            => false,
            'campaign'          => $campaign,
            'didRun'            => false,
            'scheduling_method' => $sendingType
        ];
    }
    public function doTagActions(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);

        if ($campaign->status != 'archived') {
            return $this->sendError([
                'message' => __('You can only do this when the campaign is archived', 'fluentcampaign-pro')
            ]);
        }

        $this->validate($request->all(), [
            'action_type'     => 'required',
            'tags'            => 'required',
            'activity_type'   => 'required',
            'processing_page' => 'required|integer'
        ]);

        $actionType = $request->get('action_type');
        $tags = $request->get('tags');
        $activityType = $request->get('activity_type');

        $processingPage = intval($request->get('processing_page'));
        $limit = apply_filters('fluent_crm/sms_campaign_action_limit', 50);
        $offset = ($processingPage - 1) * $limit;
        $count = false;

        // The campaign's audience is the set of threads it messaged.
        $smsQuery = Message::forCampaign($campaignId)
            ->select('thread_id')
            ->groupBy('thread_id')
            ->orderBy('thread_id', 'ASC');

        if ($activityType == 'sms_sent') {
            $smsQuery->whereIn('status', Message::SENT_STATUSES);
        } else if ($activityType == 'sms_failed') {
            $smsQuery->where('status', Message::STATUS_FAILED);
        } else if ($activityType == 'sms_delivered') {
            $smsQuery->whereIn('status', Message::DELIVERED_STATUSES);
        } else if ($activityType != 'all_recipients') {
            return $this->sendError([
                'message' => __('Invalid activity type selection', 'fluentcampaign-pro')
            ]);
        }

        if ($processingPage == 1) {
            $countQuery = clone $smsQuery;
            $count = $countQuery->distinct()->count('thread_id');
        }

        $threadIds = $smsQuery->offset($offset)
            ->limit($limit)
            ->get()->pluck('thread_id')->toArray();

        // Contactless threads have nobody to tag.
        $subscriberIds = $threadIds
            ? MessageThread::whereIn('id', $threadIds)->whereNotNull('contact_id')->pluck('contact_id')->toArray()
            : [];

        $subscribers = Subscriber::whereIn('id', $subscriberIds)
            ->where('status', 'subscribed')
            ->get();

        if ($actionType == 'add_tags') {
            foreach ($subscribers as $subscriber) {
                $subscriber->attachTags($tags);
            }
        } else if ($actionType == 'remove_tags') {
            foreach ($subscribers as $subscriber) {
                $subscriber->detachTags($tags);
            }
        }

        $totalSubscribers = count($subscribers);

        return [
            'processed_page'     => $processingPage,
            'processed_contacts' => $totalSubscribers,
            // A full page of threads means there may be more, even if nobody on it was tagged.
            'has_more'           => count($threadIds) >= $limit,
            'total_count'        => $count,
        ];
    }

    public function delete(Request $request, $campaignId)
    {
        $campaign = MessageCampaign::findOrFail($campaignId);
        MessageScheduler::clearPendingCampaignActions($campaignId);
        $channel = $campaign->channel ?: MessageCampaign::CHANNEL_SMS;
        $campaign->deleteCampaignData();
        $campaign->delete();
        do_action('fluent_crm/' . $channel . '_campaign_deleted', $campaignId);

        return $this->send([
            'success' => true
        ]);
    }
}
