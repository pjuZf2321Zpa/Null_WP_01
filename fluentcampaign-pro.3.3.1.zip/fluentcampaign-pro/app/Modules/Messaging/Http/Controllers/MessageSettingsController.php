<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Controllers;

use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Modules\Messaging\SMS\SMSHelper;
use FluentCampaign\App\Modules\Messaging\MessageMigrator;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCrm\App\Services\Helper;
use FluentCrm\Framework\Http\Request\Request;
use FluentCrm\Framework\Support\Arr;

class MessageSettingsController extends Controller
{
    public function getSettings()
    {
        $settings = SMSHelper::getSettings();
        $options = SMSHelper::getApiOptions();
        $smsWebhook = null;

        if (!empty($settings['sms_provider']) && Arr::get($settings, 'enabled') === 'yes') {
            $smsWebhook = $this->getSMSWebhook($settings['sms_provider']);
        }

        return [
            'settings'    => $this->maskSecrets($settings, Arr::get($options, 'providers', [])),
            'options'     => $options,
            'sms_webhook' => $smsWebhook,
        ];
    }

    public function saveSettings(Request $request)
    {
        $prevSettings = SMSHelper::getSettings();

        $settings = $request->get('settings', []);
        $smsProvider = trim((string) Arr::get($settings, 'sms_provider', ''));
        $isEnabled = Arr::get($settings, 'enabled') === 'yes';

        $providerApiOptions = SMSHelper::getApiOptions();
        $providerDefinitions = Arr::get($providerApiOptions, 'providers', []);

        if ($isEnabled) {
            if (!$smsProvider || !isset($providerDefinitions[$smsProvider])) {
                return $this->sendError([
                    'message' => __('Please select an SMS provider before enabling the SMS module', 'fluentcampaign-pro')
                ]);
            }

            $providerFields = Arr::get($providerDefinitions, $smsProvider . '.fields', []);
            $providerSettings = Arr::get($settings, $smsProvider, []);
            if (!is_array($providerSettings)) {
                $providerSettings = [];
            }

            $missingRequiredFields = [];
            foreach ($providerFields as $fieldKey => $field) {
                if (empty($field['required'])) {
                    continue;
                }

                $value = Arr::get($providerSettings, $fieldKey);
                $isMissing = $value === null || $value === '';

                if (is_string($value)) {
                    $isMissing = trim($value) === '';
                } elseif (is_array($value)) {
                    $filledValues = array_filter($value, function ($item) {
                        if (is_string($item)) {
                            return trim($item) !== '';
                        }
                        return $item !== null && $item !== '';
                    });
                    $isMissing = empty($filledValues);
                }

                if ($isMissing) {
                    $missingRequiredFields[] = Arr::get($field, 'label', $fieldKey);
                }
            }

            if ($missingRequiredFields) {
                return $this->sendError([
                    'message' => __('Please provide all required SMS provider credentials before enabling the SMS module', 'fluentcampaign-pro'),
                    'required_fields' => $missingRequiredFields
                ]);
            }

            MessageMigrator::migrate();
        }

        $enabledValue = $isEnabled ? 'yes' : 'no';
        fluentcrm_update_option('_fc_sms_enable', $enabledValue);
        fluentcrm_update_option('_fc_sms_provider', $smsProvider);

        foreach ($providerDefinitions as $providerName => $options) {
            $providerSettings = Arr::get($settings, $providerName, []);
            if (!is_array($providerSettings)) {
                $providerSettings = [];
            }

            $toSave = [];
            $fields = Arr::get($options, 'fields', []);
            foreach ($fields as $fieldKey => $field) {
                $defaultValue = Arr::get($field, 'default', '');
                $value = Arr::get($providerSettings, $fieldKey, $defaultValue);

                if (is_string($value)) {
                    $value = trim($value);
                } elseif (is_scalar($value)) {
                    $value = (string) $value;
                }

                $toSave[$fieldKey] = $this->keepStoredSecret($value, Arr::get($prevSettings, $providerName . '.' . $fieldKey, ''));
            }

            fluentcrm_update_option('_fc_sms_' . $providerName . '_settings', $toSave);
        }

        SMSHelper::clearSettingsCache();

        if ((string) fluentcrm_get_option('_fc_sms_enable', 'no') !== $enabledValue) {
            return $this->sendError([
                'message' => __('SMS settings could not be saved completely. Please try again.', 'fluentcampaign-pro')
            ], 500);
        }

        $smsWebhook = null;
        if ($isEnabled && $smsProvider) {
            $smsWebhook = $this->getSMSWebhook($smsProvider, true);
        }

        return [
            'message'     => __('Settings have been saved successfully', 'fluentcampaign-pro'),
            'reload'      => Arr::get($prevSettings, 'enabled') !== $enabledValue,
            'sms_webhook' => $smsWebhook,
        ];
    }

    private function getSMSWebhook($provider, $createKey = false)
    {
        $webhookUrl = SMSHelper::getSMSWebhookUrl($provider, $createKey);
        if (!$webhookUrl) {
            return null;
        }

        $providerLabel = ucwords(str_replace('_', ' ', $provider));
        $providerOptions = Arr::get(SMSHelper::getApiOptions(), 'providers.' . $provider, []);

        return [
            'object_type' => 'webhook_' . $provider,
            'value'       => [
                /* translators: %s: SMS provider name, e.g. Twilio */
                'name'                => sprintf(__('%s SMS Webhook', 'fluentcampaign-pro'), Arr::get($providerOptions, 'label', $providerLabel)),
                'sms_provider'        => $provider,
                'sms_webhook_enabled' => true,
                'type'                => 'sms_webhook',
                'url'                 => $webhookUrl,
            ],
        ];
    }

    public function disable()
    {
        $prevSettings = SMSHelper::getSettings();

        fluentcrm_update_option('_fc_sms_enable', 'no');
        SMSHelper::clearSettingsCache();

        return [
            'message' => __('SMS has been disabled successfully', 'fluentcampaign-pro'),
            'reload' => $prevSettings['enabled'] !== 'no'
        ];
    }

    public function getWhatsAppSettings()
    {
        $settings = WhatsAppHelper::getSettings();
        $options  = WhatsAppHelper::getApiOptions();

        $whatsappWebhook = null;
        if (!empty($settings['whatsapp_provider']) && Arr::get($settings, 'enabled') === 'yes') {
            $whatsappWebhook = $this->getWhatsAppWebhook($settings['whatsapp_provider']);
        }

        return [
            'settings'         => $this->maskSecrets($settings, Arr::get($options, 'providers', [])),
            'options'          => $options,
            'whatsapp_webhook' => $whatsappWebhook,
        ];
    }

    public function saveWhatsAppSettings(Request $request)
    {
        $settings         = $request->get('settings', []);
        $whatsappProvider = trim((string) Arr::get($settings, 'whatsapp_provider', ''));
        $isEnabled        = Arr::get($settings, 'enabled') === 'yes';
        $wasEnabled       = (string) fluentcrm_get_option('_fc_whatsapp_enable', 'no');
        $prevSettings     = WhatsAppHelper::getSettings();

        $providerApiOptions  = WhatsAppHelper::getApiOptions();
        $providerDefinitions = Arr::get($providerApiOptions, 'providers', []);

        if ($isEnabled) {
            if (!$whatsappProvider || !isset($providerDefinitions[$whatsappProvider])) {
                return $this->sendError([
                    'message' => __('Please select a WhatsApp provider before enabling the WhatsApp module', 'fluentcampaign-pro'),
                ]);
            }

            $providerFields   = Arr::get($providerDefinitions, $whatsappProvider . '.fields', []);
            $providerSettings = Arr::get($settings, $whatsappProvider, []);
            if (!is_array($providerSettings)) {
                $providerSettings = [];
            }

            $missingRequiredFields = [];
            foreach ($providerFields as $fieldKey => $field) {
                if (empty($field['required'])) {
                    continue;
                }
                $value     = Arr::get($providerSettings, $fieldKey);
                $isMissing = $value === null || $value === '';

                if (is_string($value)) {
                    $isMissing = trim($value) === '';
                } elseif (is_array($value)) {
                    $filledValues = array_filter($value, function ($item) {
                        if (is_string($item)) {
                            return trim($item) !== '';
                        }
                        return $item !== null && $item !== '';
                    });
                    $isMissing = empty($filledValues);
                }

                if ($isMissing) {
                    $missingRequiredFields[] = Arr::get($field, 'label', $fieldKey);
                }
            }

            if ($missingRequiredFields) {
                return $this->sendError([
                    'message'         => __('Please provide all required WhatsApp provider credentials', 'fluentcampaign-pro'),
                    'required_fields' => $missingRequiredFields,
                ]);
            }

            MessageMigrator::migrate();
        }

        $enabledValue = $isEnabled ? 'yes' : 'no';
        fluentcrm_update_option('_fc_whatsapp_enable', $enabledValue);

        fluentcrm_update_option('_fc_whatsapp_provider', $whatsappProvider);

        foreach ($providerDefinitions as $providerName => $options) {
            $providerSettings = Arr::get($settings, $providerName, []);
            if (!is_array($providerSettings)) {
                $providerSettings = [];
            }

            $toSave = [];
            foreach (Arr::get($options, 'fields', []) as $fieldKey => $field) {
                $value          = Arr::get($providerSettings, $fieldKey, $field['default'] ?? '');
                $value          = is_string($value) ? trim($value) : (string) $value;
                $toSave[$fieldKey] = $this->keepStoredSecret($value, Arr::get($prevSettings, $providerName . '.' . $fieldKey, ''));
            }

            fluentcrm_update_option('_fc_whatsapp_' . $providerName . '_settings', $toSave);
        }

        WhatsAppHelper::clearSettingsCache();

        if ((string) fluentcrm_get_option('_fc_whatsapp_enable', 'no') !== $enabledValue) {
            return $this->sendError([
                'message' => __('WhatsApp settings could not be saved completely. Please try again.', 'fluentcampaign-pro'),
            ], 500);
        }

        $whatsappWebhook = null;
        if ($isEnabled && $whatsappProvider) {
            $whatsappWebhook = $this->getWhatsAppWebhook($whatsappProvider, true);
        }

        return [
            'message'          => __('WhatsApp settings saved successfully', 'fluentcampaign-pro'),
            // Toggling the channel changes server-built menus, so the client reloads.
            'reload'           => $wasEnabled !== $enabledValue,
            'settings'         => $this->maskSecrets(WhatsAppHelper::getSettings(), $providerDefinitions),
            'options'          => WhatsAppHelper::getApiOptions(),
            'whatsapp_webhook' => $whatsappWebhook,
        ];
    }

    private function getWhatsAppWebhook(string $provider, bool $createKey = false): ?array
    {
        $webhookUrl = WhatsAppHelper::getWhatsAppWebhookUrl($provider, $createKey);
        if (!$webhookUrl) {
            return null;
        }

        $providerOptions = Arr::get(WhatsAppHelper::getApiOptions(), 'providers.' . $provider, []);
        $providerLabel   = Arr::get($providerOptions, 'label', ucwords(str_replace('_', ' ', $provider)));

        return [
            'object_type' => 'webhook_' . $provider,
            'value'       => [
                /* translators: %s: WhatsApp provider name, e.g. Twilio WhatsApp */
                'name'                     => sprintf(__('%s WhatsApp Webhook', 'fluentcampaign-pro'), $providerLabel),
                'whatsapp_provider'        => $provider,
                'whatsapp_webhook_enabled' => true,
                'type'                     => 'whatsapp_webhook',
                'url'                      => $webhookUrl,
            ],
        ];
    }

    /**
     * Replaces each provider's password-type fields with `****` and the last 4 characters,
     * so provider tokens never reach the browser. The save methods keep the stored value
     * when the mask comes back (see keepStoredSecret()).
     */
    private function maskSecrets(array $settings, array $providerDefinitions): array
    {
        foreach ($providerDefinitions as $providerName => $options) {
            foreach (Arr::get($options, 'fields', []) as $fieldKey => $field) {
                $value = Arr::get($settings, $providerName . '.' . $fieldKey);
                if (Arr::get($field, 'type') !== 'password' || !is_string($value) || $value === '') {
                    continue;
                }
                $settings[$providerName][$fieldKey] = '****' . (strlen($value) > 8 ? substr($value, -4) : '');
            }
        }

        return $settings;
    }

    /** A masked value from the settings form means "unchanged": keep the stored one. */
    private function keepStoredSecret($value, $storedValue)
    {
        if (is_string($value) && strpos($value, '****') === 0) {
            return $storedValue;
        }

        return $value;
    }
}
