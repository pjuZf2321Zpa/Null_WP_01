<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Controllers;

use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Modules\Messaging\Contracts\TemplateApiInterface;
use FluentCampaign\App\Modules\Messaging\Models\Message;
use FluentCampaign\App\Modules\Messaging\Models\MessageTemplate;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\WhatsApp\TemplateRenderer;
use FluentCampaign\App\Modules\Messaging\WhatsApp\Providers\WhatsAppDriverManager;
use FluentCampaign\App\Modules\Messaging\WhatsApp\WhatsAppHelper;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\Framework\Http\Request\Request;

/**
 * Messaging Inbox endpoints: the conversation rail, thread view and thread actions.
 *
 * @package FluentCrm\App\Http\Controllers
 */
class MessageThreadController extends Controller
{
    /**
     * Rows per page when the caller does not ask.
     */
    const PER_PAGE = 25;

    /**
     * Maximum page size a caller may request.
     */
    const MAX_PER_PAGE = 100;

    /**
     * Maximum recipient search results.
     */
    const RECIPIENT_LIMIT = 20;

    /**
     * Minimum digits before the recipient search queries contact phone numbers.
     */
    const RECIPIENT_PHONE_SEARCH_MIN_LENGTH = 3;

    /**
     * Conversations for the rail, newest activity first.
     *
     * @param Request $request
     * @return array
     */
    public function index(Request $request)
    {
        $query = MessageThread::query()->with(['subscriber']);

        $channel = sanitize_text_field($request->get('channel', ''));
        if ($channel) {
            $query->where('channel', $channel);
        }

        $search = sanitize_text_field($request->get('search', ''));
        if ($search) {
            $query->searchBy($search);
        }

        // Hide consent-only threads until they have a message.
        $query->where(function ($q) {
            $q->whereNotNull('last_message_id')
                ->orWhere('initiated_by', '!=', MessageThread::INITIATED_BY_SYSTEM);
        });

        if ($request->get('unread_only')) {
            $query->where('unread_count', '>', 0);
        }

        // Keyset cursor: rows strictly after the given thread in rail order.
        $before = MessageThread::find($request->getSafe('before', 'intval', 0));
        if ($before) {
            $query->where(function ($q) use ($before) {
                $q->where('updated_at', '<', $before->updated_at)
                    ->orWhere(function ($q) use ($before) {
                        $q->where('updated_at', $before->updated_at)->where('id', '<', $before->id);
                    });
            });
        }

        // `updated_at` is the newest message time; id breaks ties for the cursor.
        $threadsPage = $query->orderBy('updated_at', 'DESC')
            ->orderBy('id', 'DESC')
            ->paginate(self::perPage($request));

        $rows = $threadsPage->items();

        $lastIds = array_filter(array_map(function ($row) {
            return (int) $row->last_message_id;
        }, $rows));

        $previews = [];

        if ($lastIds) {
            foreach (Message::whereIn('id', $lastIds)->get() as $message) {
                $previews[(int) $message->id] = $message;
            }
        }

        $lastInbound = $this->lastInboundMap($rows);

        $formatted = [];
        foreach ($rows as $row) {
            $previewId = (int) $row->last_message_id;
            $preview = isset($previews[$previewId]) ? $previews[$previewId] : null;
            $formatted[] = $this->formatThread($row, $preview, false, [
                'last_inbound_at' => isset($lastInbound[(int) $row->id]) ? $lastInbound[(int) $row->id] : null
            ]);
        }

        return [
            'conversations' => $formatted,
            'total'         => $threadsPage->total(),
            'per_page'      => $threadsPage->perPage(),
            'current_page'  => $threadsPage->currentPage(),
            'has_more'      => $threadsPage->currentPage() * $threadsPage->perPage() < $threadsPage->total()
        ];
    }

    /**
     * Messages in one thread, oldest first. `before` pages backwards from a message id.
     *
     * @param Request $request
     * @param int $id
     * @return array
     */
    public function messages(Request $request, $id)
    {
        $thread = MessageThread::with(['subscriber'])->findOrFail($id);

        $perPage = self::perPage($request);
        $before = $request->getSafe('before', 'intval', 0);

        $query = Message::where('thread_id', $thread->id);

        if ($before) {
            $query->where('id', '<', $before);
        }

        // Take the newest page, then reverse to oldest first.
        $messages = $query->conversationOrder('DESC')
            ->orderBy('id', 'DESC')
            ->limit($perPage)
            ->get()
            ->reverse()
            ->values();

        $oldest = $messages->first();

        return [
            'messages' => array_map([$this, 'formatMessage'], $messages->all()),
            'has_more' => $oldest ? Message::where('thread_id', $thread->id)
                ->where('id', '<', $oldest->id)->exists() : false,
            'thread'   => $this->formatThread($thread, null, true)
        ];
    }

    /**
     * Send a free-form message into a thread. The row is written before the send, then updated.
     * Not named send(): that would override Controller::send() with an incompatible signature.
     *
     * @param Request $request
     * @param int $id
     * @return array|\WP_REST_Response
     */
    public function sendMessage(Request $request, $id)
    {
        $thread = MessageThread::findOrFail($id);

        // A number or contact that opted out is not messaged again, as on every other send path.
        if (
            !MessageThread::numberCanReceive($thread->channel, $thread->phone_number) ||
            ($thread->contact_id && !MessageThread::contactCanReceive($thread->channel, $thread->contact_id))
        ) {
            return $this->sendError([
                'message' => __('This recipient has opted out of these messages, so the message cannot be sent.', 'fluentcampaign-pro')
            ], 422);
        }

        if (sanitize_key($request->get('message_type', 'text')) === 'template') {
            return $this->sendThreadTemplateMessage($request, $thread);
        }

        $content = trim((string) $request->get('content', ''));

        if ($content === '') {
            return $this->sendError(['message' => __('Write a message first.', 'fluentcampaign-pro')], 422);
        }

        // WhatsApp free-form text is only allowed inside the 24-hour session window.
        $session = $this->sessionState($thread);

        if ($thread->channel === 'whatsapp' && empty($session['has_active_session'])) {
            return $this->sendError([
                'message' => __('This WhatsApp conversation is outside its 24-hour window, so only an approved template can be sent.', 'fluentcampaign-pro')
            ], 409);
        }

        $channel = $this->resolveChannel($thread->channel);

        if (!$channel) {
            return $this->sendError([
                'message' => __('Sending is not available. Check that FluentCampaign Pro is active and this channel is configured.', 'fluentcampaign-pro')
            ], 409);
        }

        $message = $thread->recordMessage([
            'direction'  => Message::DIRECTION_OUTBOUND,
            'content'    => $content,
            'ref_type'   => 'inbox',
            'status'     => 'pending',
            'created_by' => get_current_user_id(),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ]);

        $result = $channel->send($thread->phone_number, $content);

        $succeeded = ($result['status'] ?? '') === 'success';

        $message->status = $succeeded ? 'sent' : 'failed';
        $message->sent_at = $succeeded ? current_time('mysql') : null;

        if (!empty($result['provider_message_id'])) {
            $message->provider_message_id = $result['provider_message_id'];
        }

        if (!$succeeded) {
            $message->meta = ['error_message' => $result['message'] ?? ''];
        }

        $message->save();
        MessageThread::syncCaches([$thread->id]);

        if (!$succeeded) {
            return $this->sendError([
                'message' => $result['message'] ?: __('The message could not be sent.', 'fluentcampaign-pro'),
                'sent_message' => $this->formatMessage($message)
            ], 422);
        }

        return [
            'sent_message' => $this->formatMessage($message),
            'message'      => __('Message sent.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Send an approved WhatsApp template to a thread's number, with or without a contact.
     *
     * @param Request $request
     * @param MessageThread $thread
     * @return array|\WP_REST_Response
     */
    protected function sendThreadTemplateMessage(Request $request, MessageThread $thread)
    {
        if ($thread->channel !== 'whatsapp') {
            return $this->sendError([
                'message' => __('Templates can only be sent to WhatsApp conversations.', 'fluentcampaign-pro')
            ], 422);
        }

        if (trim((string) $thread->phone_number) === '') {
            return $this->sendError([
                'message' => __('This conversation has no phone number.', 'fluentcampaign-pro')
            ], 422);
        }

        if (!$this->resolveChannel($thread->channel)) {
            return $this->sendError([
                'message' => __('Sending is not available. Check that FluentCampaign Pro is active and this channel is configured.', 'fluentcampaign-pro')
            ], 409);
        }

        $provider = WhatsAppHelper::getCurrentProvider();
        $templateName = sanitize_text_field($request->get('template_name', ''));
        $language = sanitize_text_field($request->get('template_language', ''));

        if ($language === '') {
            $language = sanitize_text_field($request->get('language', ''));
        }

        $templateQuery = MessageTemplate::forChannel('whatsapp')->approved()
            ->where('provider', $provider)
            ->where('name', $templateName);

        if ($language !== '') {
            $templateQuery->where('language', $language);
        }

        $template = $templateQuery->first();

        if (!$template) {
            return $this->sendError([
                'message' => __('Pick an approved template.', 'fluentcampaign-pro')
            ], 422);
        }

        $driver = WhatsAppDriverManager::getDriver($provider);

        if (!$driver instanceof TemplateApiInterface) {
            return $this->sendError([
                'message' => __('This provider does not support templates.', 'fluentcampaign-pro')
            ], 409);
        }

        $rendered = TemplateRenderer::render(
            $template,
            (array) $request->get('template_variables', []),
            $thread->subscriber
        );

        if ($rendered['error']) {
            return $this->sendError(['message' => $rendered['error']], 422);
        }

        $settings = WhatsAppHelper::getProviderSettings($provider);
        $result = $driver->sendTemplate(
            $thread->phone_number,
            $template->name,
            $template->language,
            $rendered['components'],
            $settings,
            (string) $template->provider_template_id
        );

        $succeeded = ($result['status'] ?? '') === 'success';
        $meta = [
            'template_id'   => (int) $template->id,
            'template_name' => $template->name,
        ];

        if (!$succeeded) {
            $meta['error_message'] = $result['message'] ?? '';
        }

        $message = $thread->recordMessage([
            'direction'           => Message::DIRECTION_OUTBOUND,
            'content'             => (string) $template->body_text,
            'ref_type'            => Message::REF_INBOX,
            'provider_message_id' => !empty($result['provider_message_id']) ? $result['provider_message_id'] : null,
            'status'              => $succeeded ? Message::STATUS_SENT : Message::STATUS_FAILED,
            'sent_at'             => $succeeded ? current_time('mysql') : null,
            'created_by'          => get_current_user_id(),
            'meta'                => $meta
        ]);

        if (!$succeeded) {
            return $this->sendError([
                'message'      => !empty($result['message']) ? $result['message'] : __('The message could not be sent.', 'fluentcampaign-pro'),
                'sent_message' => $this->formatMessage($message)
            ], 422);
        }

        return [
            'sent_message' => $this->formatMessage($message),
            'message'      => __('Message sent.', 'fluentcampaign-pro')
        ];
    }

    /**
     * The active channel for a slug, or null.
     */
    protected function resolveChannel($slug)
    {
        if (!class_exists('\FluentCampaign\App\Modules\Messaging\MessageModule')) {
            return null;
        }

        $channel = \FluentCampaign\App\Modules\Messaging\MessageModule::channel($slug);

        return ($channel && $channel->isActive()) ? $channel : null;
    }

    /**
     * Recipients for a new conversation: matching contacts, plus the term itself when phone-shaped.
     * Each carries `existing_thread_id` so the dialog can open an existing conversation.
     *
     * @param Request $request
     * @return array|\WP_REST_Response
     */
    public function recipients(Request $request)
    {
        $channelSlug = sanitize_key($request->get('channel', ''));
        $channel = $this->resolveChannel($channelSlug);

        if (!$channel) {
            return $this->sendError([
                'message' => __('This channel is not available. Check that FluentCampaign Pro is active and the channel is configured.', 'fluentcampaign-pro')
            ], 409);
        }

        $search = trim(sanitize_text_field($request->get('search', '')));
        $searchDigits = preg_replace('/\D+/', '', $search);

        $direct = $this->directNumber($search);
        $phoneTerms = $this->phoneSearchTerms($search, $direct);

        global $wpdb;

        $phoneLikes = array_map(function ($term) use ($wpdb) {
            return '%' . $wpdb->esc_like($term) . '%';
        }, $phoneTerms);

        $query = Subscriber::whereNotNull('phone')
            ->where('phone', '!=', '');

        if ($search !== '') {
            if (strlen($searchDigits) < self::RECIPIENT_PHONE_SEARCH_MIN_LENGTH) {
                return ['contacts' => [], 'direct' => null];
            }

            $query->where(function ($subQuery) use ($phoneLikes) {
                foreach (array_values($phoneLikes) as $index => $phoneLike) {
                    if ($index === 0) {
                        $subQuery->where('phone', 'LIKE', $phoneLike);
                    } else {
                        $subQuery->orWhere('phone', 'LIKE', $phoneLike);
                    }
                }
            });
        }

        $subscribers = $query
            ->orderBy('id', 'DESC')
            ->limit(self::recipientLimit($request))
            ->get();

        $blocked = MessageThread::blockedContactIds($channelSlug, array_map(function ($subscriber) {
            return $subscriber->id;
        }, $subscribers->all()));

        $numbers = [];
        foreach ($subscribers as $subscriber) {
            $numbers[] = $subscriber->phone;
        }

        if ($direct) {
            $numbers[] = $direct;
        }

        $numbers = array_merge($numbers, $phoneTerms);

        $threadMap = $this->threadIdsForNumbers($channelSlug, $numbers);
        $directThreadId = 0;

        if ($direct) {
            foreach ($this->phoneSearchTerms($search, $direct) as $term) {
                if (isset($threadMap[$term])) {
                    $directThreadId = (int) $threadMap[$term];
                    break;
                }
            }
        }

        $contacts = [];
        foreach ($subscribers as $subscriber) {
            $contacts[] = [
                'id'                 => (int) $subscriber->id,
                'full_name'          => $subscriber->full_name,
                'email'              => $subscriber->email,
                'phone'              => $subscriber->phone,
                'photo'              => $subscriber->photo,
                // The scheduler refuses sends to contacts not subscribed on this channel.
                'can_send'           => !isset($blocked[(int) $subscriber->id]),
                'consent_status'     => isset($blocked[(int) $subscriber->id])
                    ? MessageThread::STATUS_UNSUBSCRIBED
                    : MessageThread::STATUS_SUBSCRIBED,
                'existing_thread_id' => isset($threadMap[$subscriber->phone]) ? $threadMap[$subscriber->phone] : 0
            ];
        }

        return [
            'contacts' => $contacts,
            'direct'   => $direct ? [
                'phone_number'       => $direct,
                'existing_thread_id' => $directThreadId
            ] : null
        ];
    }

    /**
     * The search term as a phone number, or null. No country code is added.
     *
     * @param string $value
     * @return string|null
     */
    protected function directNumber($value)
    {
        $value = trim((string) $value);

        if ($value === '') {
            return null;
        }

        if (!preg_match('/^[\d\s()+.\-]+$/', $value)) {
            return null;
        }

        $number = preg_replace('/[\s().-]+/', '', $value);

        return preg_match('/^\+?\d{6,20}$/', $number) ? $number : null;
    }

    /**
     * Search terms that can represent the same phone number.
     *
     * @param string $search
     * @param string|null $phoneNumber
     * @return array
     */
    protected function phoneSearchTerms($search, $phoneNumber = null)
    {
        $terms = [trim((string) $search)];
        $digits = preg_replace('/\D+/', '', (string) $search);

        if ($digits) {
            $terms[] = $digits;
        }

        if ($phoneNumber) {
            $terms[] = $phoneNumber;
            $terms[] = preg_replace('/\D+/', '', $phoneNumber);
        }

        return array_values(array_unique(array_filter($terms)));
    }

    /**
     * Existing thread ids for a set of numbers on one channel, in one query.
     *
     * @param string $channel
     * @param array $numbers
     * @return array phone number => thread id
     */
    protected function threadIdsForNumbers($channel, array $numbers)
    {
        $numbers = array_values(array_unique(array_filter($numbers)));

        if (!$numbers) {
            return [];
        }

        $map = [];

        $threads = MessageThread::where('channel', $channel)
            ->whereIn('phone_number', $numbers)
            ->get();

        foreach ($threads as $thread) {
            $map[$thread->phone_number] = (int) $thread->id;
        }

        return $map;
    }

    /**
     * Create an empty conversation for a number with no thread on the channel; 409 if one exists.
     *
     * @param Request $request
     * @return array|\WP_REST_Response
     */
    public function store(Request $request)
    {
        $channelSlug = sanitize_key($request->get('channel', ''));

        if (!$this->resolveChannel($channelSlug)) {
            return $this->sendError([
                'message' => __('Sending is not available. Check that FluentCampaign Pro is active and this channel is configured.', 'fluentcampaign-pro')
            ], 409);
        }

        $contactId = $request->getSafe('contact_id', 'intval', 0);
        $subscriber = null;

        if ($contactId) {
            $subscriber = Subscriber::find($contactId);

            if (!$subscriber) {
                return $this->sendError(['message' => __('Contact not found.', 'fluentcampaign-pro')], 404);
            }

            // The number comes from the contact record, never from the request.
            $phone = trim((string) $subscriber->phone);

            if ($phone === '') {
                return $this->sendError([
                    'message' => __('This contact has no phone number.', 'fluentcampaign-pro')
                ], 422);
            }
        } else {
            $phone = $this->directNumber(sanitize_text_field($request->get('phone_number', '')));

            if (!$phone) {
                return $this->sendError([
                    'message' => __('Enter a valid phone number.', 'fluentcampaign-pro')
                ], 422);
            }
        }

        $thread = $this->createNewThreadForConversation($channelSlug, $phone, $subscriber);

        if (is_array($thread)) {
            return $this->duplicateThreadError((int) $thread['thread_id']);
        }

        if (!$thread) {
            return $this->sendError([
                'message' => __('The conversation could not be started.', 'fluentcampaign-pro')
            ], 422);
        }

        return [
            'thread_id'   => (int) $thread->id,
            'thread'      => $this->formatThread($thread, null, true),
            'send_status' => 'not_sent',
            'message'     => __('Conversation opened.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Record a consent decision for a thread's number, with or without a contact.
     *
     * @param Request $request
     * @param int $id thread id
     */
    public function updateConsent(Request $request, $id)
    {
        $thread = MessageThread::find((int) $id);

        if (!$thread) {
            return $this->sendError([
                'message' => __('Conversation not found.', 'fluentcampaign-pro')
            ], 404);
        }

        $status = $request->getSafe('status', 'sanitize_text_field', '');

        if (!in_array($status, MessageThread::consentStatuses(), true)) {
            return $this->sendError([
                'message' => __('Value is not valid', 'fluentcampaign-pro')
            ], 422);
        }

        if (!MessageThread::setConsent($thread->channel, $thread->phone_number, $status, $thread->contact_id)) {
            return $this->sendError([
                'message' => __('Consent could not be recorded for this number.', 'fluentcampaign-pro')
            ], 400);
        }

        if ($thread->contact_id) {
            $subscriber = Subscriber::find($thread->contact_id);

            if ($subscriber) {
                do_action('fluent_crm/contact_' . $thread->channel . '_' . ($status === MessageThread::STATUS_SUBSCRIBED ? 'subscribed' : 'unsubscribed'), $subscriber, [
                    'source' => 'admin'
                ]);
            }
        }

        return [
            'message' => __('Status updated', 'fluentcampaign-pro'),
            'status'  => $status
        ];
    }

    /**
     * Attach an existing contact to a conversation. Never creates a contact.
     *
     * @param Request $request
     * @param int $id thread id
     * @return array|\WP_REST_Response
     */
    public function linkContact(Request $request, $id)
    {
        $thread = MessageThread::find((int) $id);

        if (!$thread) {
            return $this->sendError([
                'message' => __('Conversation not found.', 'fluentcampaign-pro')
            ], 404);
        }

        $contactId = $request->getSafe('contact_id', 'intval', 0);

        if (!$contactId) {
            return $this->sendError([
                'message' => __('Please provide a valid contact.', 'fluentcampaign-pro')
            ], 422);
        }

        $contact = Subscriber::find($contactId);

        if (!$contact) {
            return $this->sendError([
                'message' => __('Contact could not be found.', 'fluentcampaign-pro')
            ], 404);
        }

        $contactPhone = $this->directNumber($contact->phone);
        $threadPhone = $this->directNumber($thread->phone_number);

        if (!$contactPhone || !$threadPhone || $contactPhone !== $threadPhone) {
            return $this->sendError([
                'message' => __('This contact does not match the conversation phone number.', 'fluentcampaign-pro')
            ], 422);
        }

        $staleContactIds = [];

        if ($thread->contact_id) {
            $linkedContact = Subscriber::find((int) $thread->contact_id);

            if (!$linkedContact) {
                // A deleted contact leaves a dangling id; recover by claiming it.
                $staleContactIds[] = (int) $thread->contact_id;
            } elseif ((int) $linkedContact->id !== (int) $contact->id) {
                return $this->sendError([
                    'message' => __('This conversation is already linked to another contact.', 'fluentcampaign-pro')
                ], 409);
            }
        }

        if (!$thread->contact_id || $staleContactIds) {
            $linked = $thread->claimOrphanContact((int) $contact->id, $staleContactIds);

            if (!$linked) {
                $fresh = MessageThread::find((int) $id);

                if (!$fresh || (int) $fresh->contact_id !== (int) $contact->id) {
                    return $this->sendError([
                        'message' => __('This conversation is already linked to another contact.', 'fluentcampaign-pro')
                    ], 409);
                }
            }

            if ($linked) {
                /**
                 * A conversation has been attached to a CRM contact.
                 *
                 * @param MessageThread $thread
                 * @param Subscriber $contact
                 */
                do_action('fluent_crm/messaging_thread_contact_linked', $thread, $contact);
            }
        }

        $thread = MessageThread::with(['subscriber'])->find((int) $id);

        return [
            'thread'  => $this->formatThread($thread, null, true),
            'message' => __('Conversation linked to contact.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Create a new thread, or return the existing thread id when one already exists.
     * Unlike findOrCreateFor(), a lost insert race is reported as a duplicate.
     *
     * @param string $channelSlug
     * @param string $phone
     * @param Subscriber|null $subscriber
     * @return MessageThread|array|null MessageThread on success, ['thread_id' => int] on duplicate
     */
    protected function createNewThreadForConversation($channelSlug, $phone, $subscriber)
    {
        $existing = MessageThread::where('channel', $channelSlug)
            ->where('phone_number', $phone)
            ->first();

        if ($existing) {
            return ['thread_id' => (int) $existing->id];
        }

        try {
            return MessageThread::create([
                'contact_id'   => $subscriber ? (int) $subscriber->id : null,
                'channel'      => $channelSlug,
                'phone_number' => $phone,
                'status'       => 'subscribed',
                'initiated_by' => 'admin',
                'has_unread'   => 0,
                'unread_count' => 0,
                'created_at'   => gmdate('Y-m-d H:i:s'),
                'updated_at'   => gmdate('Y-m-d H:i:s')
            ]);
        } catch (\Exception $e) {
            $winner = MessageThread::where('channel', $channelSlug)
                ->where('phone_number', $phone)
                ->first();

            if ($winner) {
                return ['thread_id' => (int) $winner->id];
            }

            throw $e;
        }
    }

    /**
     * Standard duplicate-conversation refusal payload.
     *
     * @param int $threadId
     * @return \WP_REST_Response
     */
    protected function duplicateThreadError($threadId)
    {
        return $this->sendError([
            'message'   => __('This number already has a conversation on this channel. Open it from the list instead.', 'fluentcampaign-pro'),
            'thread_id' => (int) $threadId
        ], 409);
    }

    /**
     * Mark a thread read up to its newest message.
     *
     * @param Request $request
     * @param int $id
     * @return array
     */
    public function markSeen(Request $request, $id)
    {
        $thread = MessageThread::findOrFail($id);

        $newestId = (int) Message::where('thread_id', $thread->id)->max('id');

        $thread->last_seen_id = $newestId;
        $thread->has_unread = 0;
        $thread->unread_count = 0;

        // Reading is not activity; leave `updated_at`, which sorts the rail.
        MessageThread::withoutTimestamps(function () use ($thread) {
            $thread->save();
        });

        return [
            'thread_id'    => (int) $thread->id,
            'last_seen_id' => $newestId,
            'message'      => __('Conversation marked as read.', 'fluentcampaign-pro')
        ];
    }

    /**
     * Requested page size, clamped to 1..MAX_PER_PAGE.
     *
     * @param Request $request
     * @return int
     */
    protected static function perPage(Request $request)
    {
        $perPage = $request->getSafe('per_page', 'intval', self::PER_PAGE);

        return max(1, min($perPage, self::MAX_PER_PAGE));
    }

    /**
     * Recipient picker page size, bounded to the short list the drawer shows.
     *
     * @param Request $request
     * @return int
     */
    protected static function recipientLimit(Request $request)
    {
        $perPage = $request->getSafe('per_page', 'intval', 15);

        return max(1, min($perPage, self::RECIPIENT_LIMIT));
    }

    /**
     * Last inbound message time for each WhatsApp thread on a page, in one grouped query.
     * Inbound messages have no sent_at/scheduled_at, so MAX(created_at) matches conversation order.
     *
     * @param array $threads MessageThread rows
     * @return array thread id => last inbound timestamp
     */
    protected function lastInboundMap($threads)
    {
        $ids = [];
        foreach ($threads as $thread) {
            if ($thread->channel === 'whatsapp') {
                $ids[] = (int) $thread->id;
            }
        }

        if (!$ids) {
            return [];
        }

        $rows = Message::whereIn('thread_id', $ids)
            ->inbound()
            ->select('thread_id')
            ->selectRaw('MAX(created_at) AS last_inbound_at')
            ->groupBy('thread_id')
            ->get();

        $map = [];
        foreach ($rows as $row) {
            $map[(int) $row->thread_id] = $row->last_inbound_at;
        }

        return $map;
    }

    /**
     * Rail/thread payload.
     *
     * @param MessageThread $thread
     * @param Message|null $preview last message, when the caller has one
     * @param bool $withContactDetail include lists and tags for the context panel
     * @return array
     */
    protected function formatThread($thread, $preview = null, $withContactDetail = false, array $resolved = [])
    {
        $subscriber = $thread->subscriber;
        $meta = $thread->meta;

        $payload = [
            'id'           => (int) $thread->id,
            'channel'      => $thread->channel,
            'phone_number' => $thread->phone_number,
            'profile_name' => isset($meta['profile_name']) ? $meta['profile_name'] : '',
            'wa_id'        => isset($meta['wa_id']) ? $meta['wa_id'] : '',
            'status'       => $thread->status,
            'unread_count' => isset($thread->unread_count) ? (int) $thread->unread_count : 0,
            'updated_at'   => $this->asDateString($thread->updated_at),
            'session'      => $this->sessionState($thread, $resolved),
            'subscriber'   => null,
            'last_message' => null
        ];

        if ($subscriber) {
            $payload['subscriber'] = [
                'id'         => (int) $subscriber->id,
                'full_name'  => $subscriber->full_name,
                'email'      => $subscriber->email,
                'phone'      => $subscriber->phone,
                'photo'      => $subscriber->photo,
                'status'     => $subscriber->status
            ];

            if ($withContactDetail) {
                $payload['subscriber']['lists'] = $subscriber->lists->pluck('title')->all();
                $payload['subscriber']['tags'] = $subscriber->tags->pluck('title')->all();
            }
        }

        if ($preview) {
            $payload['last_message'] = [
                'text'         => $this->previewText($preview),
                'direction'    => $preview->direction,
                'status'       => $preview->status,
                'message_type' => $this->messageType($preview),
                'created_at'   => $this->asDateString($preview->created_at)
            ];
        }

        return $payload;
    }

    /**
     * @param Message $message
     * @return array
     */
    protected function formatMessage($message)
    {
        $meta = $message->meta;

        return [
            'id'            => (int) $message->id,
            'thread_id'     => (int) $message->thread_id,
            'direction'     => $message->direction,
            'message_type'  => $this->messageType($message),
            'content'       => $message->content,
            'template_name' => isset($meta['template_name']) ? $meta['template_name'] : '',
            'media'         => isset($meta['attachments']) && is_array($meta['attachments']) ? $meta['attachments'] : [],
            'status'        => $message->status,
            'error_message' => isset($meta['error_message']) ? $meta['error_message'] : '',
            'created_at'    => $this->asDateString($message->sent_at ?: ($message->scheduled_at ?: $message->created_at))
        ];
    }

    /**
     * Format a date or DateTime as a `Y-m-d H:i:s` string for JSON responses.
     */
    protected function asDateString($value)
    {
        if (!$value) {
            return null;
        }

        if ($value instanceof \DateTimeInterface) {
            return $value->format('Y-m-d H:i:s');
        }

        return (string) $value;
    }

    /**
     * Derived message type: media, template or text.
     */
    protected function messageType($message)
    {
        $meta = $message->meta;

        if (!empty($meta['attachments'])) {
            return 'media';
        }

        if (!empty($meta['template_id']) || !empty($meta['template_name'])) {
            return 'template';
        }

        return 'text';
    }

    /**
     * One-line preview for the rail.
     */
    protected function previewText($message)
    {
        $meta = $message->meta;

        if (empty($message->content) && !empty($meta['attachments'][0])) {
            $first = $meta['attachments'][0];

            return isset($first['caption']) && $first['caption']
                ? $first['caption']
                : (isset($first['filename']) ? $first['filename'] : '');
        }

        return (string) $message->content;
    }

    /**
     * WhatsApp's 24-hour session window from the latest inbound message. SMS is always open.
     */
    protected function sessionState($thread, array $resolved = [])
    {
        if ($thread->channel !== 'whatsapp') {
            return ['has_active_session' => true, 'expires_at' => null];
        }

        // A resolved null means no inbound message, so array_key_exists rather than isset.
        if (array_key_exists('last_inbound_at', $resolved)) {
            $lastInbound = $resolved['last_inbound_at'];
        } else {
            $lastInbound = Message::where('thread_id', $thread->id)
                ->inbound()
                ->conversationOrder('DESC')
                ->value('created_at');
        }

        if (!$lastInbound) {
            return ['has_active_session' => false, 'expires_at' => null];
        }

        // created_at is WP-local time, so compare against the WP-local clock.
        $expires = strtotime($lastInbound) + DAY_IN_SECONDS;
        $open = $expires > current_time('timestamp');

        return [
            'has_active_session' => $open,
            'expires_at'         => $open ? gmdate('Y-m-d H:i:s', $expires) : gmdate('Y-m-d H:i:s', $expires)
        ];
    }
}
