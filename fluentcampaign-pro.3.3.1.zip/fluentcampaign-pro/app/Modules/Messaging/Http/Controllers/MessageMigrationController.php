<?php

namespace FluentCampaign\App\Modules\Messaging\Http\Controllers;

use FluentCampaign\App\Http\Controllers\Controller;
use FluentCampaign\App\Modules\Messaging\Models\MessageThread;
use FluentCampaign\App\Modules\Messaging\Services\PhoneMatcher;
use FluentCrm\Framework\Http\Request\Request;

/**
 * Batched, cursor-driven migration of `fc_sms_messages` into `fc_message_threads` and `fc_messages`.
 * Temporary: once every install has migrated, delete this file, MigrationBanner.vue and its placements,
 * the `messaging/migration` routes, their test manifest entries and the banner styles.
 *
 * @see \FluentCampaign\App\Modules\Messaging\MessageMigrator::migrateMessageThreadsTable()
 * @see \FluentCampaign\App\Modules\Messaging\MessageMigrator::migrateMessagesTable()
 */
class MessageMigrationController extends Controller
{


    /**
     * Progress record, stored in fc_meta as an option.
     *
     * Shape: ['status' => pending|running|complete, 'last_id' => int,
     *         'migrated' => int, 'threads' => int, 'started_at' => string,
     *         'completed_at' => string]
     */
    const OPTION = '_fc_message_migration';

    /**
     * Rows per batch.
     */
    const BATCH_SIZE = 2000;

    /**
     * Seconds one request may keep migrating batches; under the default 30s max_execution_time.
     */
    const REQUEST_BUDGET = 15;

    /**
     * Legacy `sms_type` values that map to `ref_type`; anything else leaves it null.
     */
    protected static $refTypes = ['campaign', 'automation'];


    /**
     * Progress for the migration notice.
     */
    public function status()
    {
        return ['migration' => self::getStatus()];
    }

    /**
     * Migrate batches until the request budget is spent. The browser calls again until `done`.
     */
    public function migrate(Request $request)
    {
        $batchSize = (int) $request->get('batch_size', self::BATCH_SIZE);
        $batchSize = max(10, min($batchSize, 5000));

        $deadline = microtime(true) + self::REQUEST_BUDGET;

        do {
            $result = self::migrateBatch($batchSize);
        } while (empty($result['done']) && microtime(true) < $deadline);

        return [
            'done'      => !empty($result['done']),
            'migration' => self::getStatus(),
        ];
    }

    /**
     * The legacy table name. It may not exist; check isAvailable().
     */
    public static function sourceTable()
    {
        global $wpdb;

        return $wpdb->prefix . 'fc_sms_messages';
    }

    public static function isAvailable()
    {
        global $wpdb;

        $table = self::sourceTable();

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $wpdb->get_var("SHOW TABLES LIKE '$table'") === $table;
    }

    /**
     * Total, migrated and remaining legacy rows.
     */
    public static function getStatus()
    {
        global $wpdb;

        if (!self::isAvailable()) {
            return ['total' => 0, 'migrated' => 0, 'remaining' => 0];
        }

        $state = self::getState();
        $table = self::sourceTable();

        return [
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            'total'     => (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table`"),
            'migrated'  => (int) $state['migrated'],
            'remaining' => (int) $wpdb->get_var(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $wpdb->prepare("SELECT COUNT(*) FROM `$table` WHERE id > %d", $state['last_id'])
            ),
        ];
    }

    /**
     * Option flag set once the site has nothing left to migrate.
     */
    const DONE_OPTION = '_fc_message_migration_done';

    /**
     * @return bool
     */
    public static function isMigrated()
    {
        return fluentcrm_get_option(self::DONE_OPTION) === 'yes';
    }

    /**
     * Record that this site has nothing left to migrate.
     */
    public static function markMigrated()
    {
        fluentcrm_update_option(self::DONE_OPTION, 'yes');

        $state = self::getState();
        $state['status'] = 'complete';
        $state['completed_at'] = $state['completed_at'] ?: gmdate('Y-m-d H:i:s');

        self::putState($state);
    }





    /**
     * Migrate one batch. Inserts and the cursor advance share a transaction, so a re-run is safe.
     *
     * @param int|null $batchSize
     * @return array
     */
    public static function migrateBatch($batchSize = null)
    {
        global $wpdb;

        if (!self::isAvailable()) {
            return ['done' => true, 'moved' => 0];
        }

        $batchSize = $batchSize ? (int) $batchSize : self::BATCH_SIZE;
        $state = self::getState();
        $table = self::sourceTable();

        $rows = $wpdb->get_results(
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->prepare(
                "SELECT * FROM `$table` WHERE id > %d ORDER BY id ASC LIMIT %d",
                $state['last_id'],
                $batchSize
            )
        );

        if (!$rows) {
            self::markMigrated();

            return ['done' => true, 'moved' => 0];
        }

        if ($state['status'] !== 'running') {
            $state['status'] = 'running';
            $state['started_at'] = $state['started_at'] ?: gmdate('Y-m-d H:i:s');
        }

        fluentCrmDb()->beginTransaction();

        try {
            $threadIds = self::resolveThreads($rows, $state);

            self::insertMessages($rows, $threadIds, $state);

            $last = end($rows);
            $state['last_id'] = (int) $last->id;

            // Mark complete as soon as nothing is left past the cursor.
            $finished = !$wpdb->get_var(
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $wpdb->prepare("SELECT id FROM `$table` WHERE id > %d LIMIT 1", $state['last_id'])
            );

            if ($finished) {
                $state['status'] = 'complete';
                $state['completed_at'] = $state['completed_at'] ?: gmdate('Y-m-d H:i:s');
            }

            self::putState($state);

            if ($finished) {
                fluentcrm_update_option(self::DONE_OPTION, 'yes');
            }

            fluentCrmDb()->commit();
        } catch (\Exception $e) {
            fluentCrmDb()->rollBack();

            throw $e;
        }

        // Not getStatus(), which runs two COUNT(*) scans.
        return ['done' => $finished, 'moved' => count($rows)];
    }

    /**
     * Resolve or create every (channel, phone_number) thread a batch needs, in bulk.
     *
     * @return array map of "channel|phone" => thread id
     */
    protected static function resolveThreads(array $rows, array &$state)
    {
        global $wpdb;

        $threads = $wpdb->prefix . 'fc_message_threads';

        // First row per conversation supplies the thread's initiator and timestamps.
        $wanted = [];
        foreach ($rows as $row) {
            $phone = trim((string) $row->mobile_number);

            if ($phone === '') {
                continue;
            }

            $key = ($row->channel ? $row->channel : 'sms') . '|' . $phone;

            if (!isset($wanted[$key])) {
                $wanted[$key] = $row;
            }
        }

        if (!$wanted) {
            return [];
        }

        $pairs = [];
        foreach (array_keys($wanted) as $key) {
            list($channel, $phone) = explode('|', $key, 2);
            $pairs[] = $wpdb->prepare('(%s,%s)', $channel, $phone);
        }
        $pairsSql = implode(',', $pairs);

        $insertRows = [];
        $withKey = PhoneMatcher::hasKeyColumn();
        foreach ($wanted as $key => $row) {
            list($channel, $phone) = explode('|', $key, 2);

            $initiatedBy = ($row->direction === 'inbound') ? 'user' : 'admin';

            $values = [
                self::sqlVal($row->subscriber_id, 'int'),
                self::sqlVal($channel, 'str'),
                self::sqlVal($phone, 'str'),
                self::sqlVal('subscribed', 'str'),
                self::sqlVal($initiatedBy, 'str'),
                '0',
                self::sqlVal($row->created_at, 'ts'),
                self::sqlVal($row->updated_at, 'ts')
            ];
            if ($withKey) {
                $values[] = self::sqlVal(PhoneMatcher::lookupKey($phone), 'str');
            }

            $insertRows[] = '(' . implode(',', $values) . ')';
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->query(
            "INSERT IGNORE INTO `$threads`
                (`contact_id`,`channel`,`phone_number`,`status`,`initiated_by`,`has_unread`,`created_at`,`updated_at`" . ($withKey ? ',`phone_key`' : '') . ")
             VALUES " . implode(',', $insertRows)
        );

        $state['threads'] += (int) $wpdb->rows_affected;

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $found = $wpdb->get_results(
            "SELECT id, channel, phone_number, contact_id FROM `$threads`
             WHERE (channel, phone_number) IN ($pairsSql)"
        );

        $map = [];
        $backfill = [];
        foreach ($found as $thread) {
            $key = $thread->channel . '|' . $thread->phone_number;
            $map[$key] = (int) $thread->id;

            // Link contactless threads; never overwrite an existing link.
            if ($thread->contact_id === null && !empty($wanted[$key]->subscriber_id)) {
                $backfill[(int) $wanted[$key]->subscriber_id][] = (int) $thread->id;
            }
        }

        foreach ($backfill as $contactId => $ids) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE `$threads` SET contact_id = %d
                     WHERE contact_id IS NULL AND id IN (" . implode(',', array_map('intval', $ids)) . ")",
                    $contactId
                )
            );
        }

        return $map;
    }

    /**
     * Insert a batch's messages in one statement. Rows without a usable number are skipped.
     */
    protected static function insertMessages(array $rows, array $threadIds, array &$state)
    {
        $items = [];

        foreach ($rows as $row) {
            $phone = trim((string) $row->mobile_number);

            if ($phone === '') {
                continue;
            }

            $key = ($row->channel ? $row->channel : 'sms') . '|' . $phone;

            if (!isset($threadIds[$key])) {
                continue;
            }

            $refType = in_array($row->sms_type, self::$refTypes, true) ? $row->sms_type : null;

            $items[] = [
                'thread_id'          => $threadIds[$key],
                'direction'          => $row->direction ? $row->direction : 'outbound',
                'content'            => $row->message_content,
                'ref_id'             => $row->campaign_id,
                'ref_type'           => $refType,
                'status'             => $row->status ? $row->status : 'pending',
                'provider_message_id' => $row->provider_message_id,
                'scheduled_at'       => $row->scheduled_at,
                'sent_at'            => $row->sent_at,
                'meta'               => self::buildMeta($row),
                'created_at'         => $row->created_at,
                'updated_at'         => $row->updated_at,
                // Outbound rows advance the read cursor, like a live reply.
                'mark_read'          => $row->direction !== 'inbound'
            ];
        }

        if (!$items) {
            return;
        }

        $written = MessageThread::recordMessages($items);
        $state['migrated'] += count($written);
    }

    /**
     * Legacy fields with no column in fc_messages, kept in meta.
     */
    protected static function buildMeta($row)
    {
        return array_filter([
            'legacy_id'       => (int) $row->id,
            'legacy_sms_type' => $row->sms_type,
            'delivery_status' => $row->delivery_status,
            'notes'           => $row->notes,
            'click_counter'   => $row->click_counter ? (int) $row->click_counter : null,
            'template_id'     => $row->template_id ? (int) $row->template_id : null,
            'delivered_at'    => $row->delivered_at,
            'read_at'         => $row->read_at,
            'settings'        => $row->settings ? self::maybeJson($row->settings) : null
        ], function ($value) {
            return $value !== null && $value !== '';
        });
    }

    /**
     * One value for a bulk VALUES list. Nulls are emitted as a literal NULL.
     *
     * @param mixed  $value
     * @param string $kind int|str|ts
     * @return string
     */
    protected static function sqlVal($value, $kind = 'str')
    {
        global $wpdb;

        if ($value === null || ($kind !== 'str' && $value === '')) {
            return 'NULL';
        }

        if ($kind === 'int') {
            return $value ? (string) (int) $value : 'NULL';
        }

        return $wpdb->prepare('%s', $value);
    }

    /**
     * Decode legacy settings when they are JSON; otherwise keep the original string.
     */
    protected static function maybeJson($value)
    {
        $decoded = json_decode($value, true);

        return (json_last_error() === JSON_ERROR_NONE) ? $decoded : $value;
    }


    protected static function getState()
    {
        $stored = fluentcrm_get_option(self::OPTION, []);

        if (!is_array($stored)) {
            $stored = [];
        }

        return wp_parse_args($stored, [
            'status'       => 'pending',
            'last_id'      => 0,
            'migrated'     => 0,
            'threads'      => 0,
            'started_at'   => '',
            'completed_at' => ''
        ]);
    }

    protected static function putState(array $state)
    {
        fluentcrm_update_option(self::OPTION, $state);
    }

}
