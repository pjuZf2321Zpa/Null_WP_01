<?php

namespace FluentCampaign\App\Modules\MCP\Tools;

use FluentCampaign\App\Models\Sequence;
use FluentCampaign\App\Models\SequenceMail;
use FluentCampaign\App\Models\SequenceTracker;
use FluentCrm\App\Models\CampaignEmail;
use FluentCrm\App\Models\CampaignUrlMetric;
use FluentCrm\App\Models\Subscriber;
use FluentCrm\App\Modules\MCP\Helpers\MCPHelper;
use FluentCrm\App\Services\ContactsQuery;
use FluentCrm\App\Services\PermissionManager;
use FluentCampaign\App\Services\ProHelper;

/**
 * Pro sequence tools: list-sequences, get-sequence, manage-sequence-subscribers.
 * Writes delegate to Sequence::subscribe() and Sequence::unsubscribe().
 */
class SequenceTools
{
    // -----------------------------------------------------------------
    // list-sequences
    // -----------------------------------------------------------------

    public static function listSequences($params)
    {
        $params = (array) $params;

        MCPHelper::paginationFromInput($params);

        $search    = sanitize_text_field((string) ($params['search'] ?? ''));
        // Every fc_campaigns column; orderBy() throws on names outside ^[a-zA-Z0-9_\.]+$.
        $allowedSortBy = [
            'id', 'parent_id', 'type', 'title', 'available_urls', 'slug',
            'status', 'template_id', 'email_subject', 'email_pre_header',
            'email_body', 'recipients_count', 'delay', 'utm_status',
            'utm_source', 'utm_medium', 'utm_campaign', 'utm_term',
            'utm_content', 'design_template', 'scheduled_at', 'settings',
            'created_by', 'created_at', 'updated_at',
        ];
        $sortBy    = sanitize_key((string) ($params['sort_by'] ?? 'id'));
        if (!in_array($sortBy, $allowedSortBy, true)) {
            $sortBy = 'id';
        }
        $sortType  = strtoupper(sanitize_text_field((string) ($params['sort_type'] ?? 'DESC')));
        $sortType  = in_array($sortType, ['ASC', 'DESC'], true) ? $sortType : 'DESC';
        $withStats = !isset($params['include_stats']) ? true : (bool) $params['include_stats'];

        $query = Sequence::orderBy($sortBy, $sortType);
        if ($search !== '') {
            global $wpdb;
            $like = '%' . $wpdb->esc_like($search) . '%';
            $query->where('title', 'LIKE', $like);
        }

        $paginated = $query->paginate();

        $sequenceList = $paginated->items();

        $emailCountMap     = [];
        $subscriberCountMap = [];
        if ($withStats && $sequenceList) {
            $pageIds = array_map(function ($s) { return (int) $s->id; }, $sequenceList);

            $emailCountMap = SequenceMail::selectRaw('parent_id, COUNT(*) as cnt')
                ->whereIn('parent_id', $pageIds)
                ->groupBy('parent_id')
                ->pluck('cnt', 'parent_id')
                ->toArray();

            $subscriberCountMap = SequenceTracker::selectRaw('campaign_id, COUNT(*) as cnt')
                ->whereIn('campaign_id', $pageIds)
                ->groupBy('campaign_id')
                ->pluck('cnt', 'campaign_id')
                ->toArray();
        }

        $items = [];
        foreach ($sequenceList as $sequence) {
            $row = [
                'id'         => (int) $sequence->id,
                'title'      => $sequence->title,
                'status'     => $sequence->status,
                'created_at' => MCPHelper::toIso8601($sequence->created_at),
                'updated_at' => MCPHelper::toIso8601($sequence->updated_at),
            ];
            if ($withStats) {
                $row['stats'] = [
                    'emails'      => (int) ($emailCountMap[$sequence->id] ?? 0),
                    'subscribers' => (int) ($subscriberCountMap[$sequence->id] ?? 0),
                    'revenue'     => null,
                ];
            }
            $items[] = $row;
        }

        return [
            'items'    => $items,
            'total'    => (int) $paginated->total(),
            'page'     => (int) $paginated->currentPage(),
            'per_page' => (int) $paginated->perPage(),
            'pages'    => (int) $paginated->lastPage(),
        ];
    }

    // -----------------------------------------------------------------
    // get-sequence
    // -----------------------------------------------------------------

    public static function getSequence($params)
    {
        $params = (array) $params;
        $sequenceId = (int) ($params['sequence_id'] ?? 0);
        if (!$sequenceId) {
            return MCPHelper::error('invalid_param', 'sequence_id is required');
        }

        $sequence = Sequence::find($sequenceId);
        if (!$sequence) {
            return MCPHelper::error('not_found', 'Sequence not found', ['sequence_id' => $sequenceId]);
        }

        $includeEmailStats = !isset($params['include_email_stats']) ? true : (bool) $params['include_email_stats'];

        // Bodies are opt-in, via include_bodies or include=["bodies"].
        $includeArr = (array) ($params['include'] ?? []);
        $includeBodies = !empty($params['include_bodies']) || in_array('bodies', $includeArr, true);

        $emails = SequenceMail::where('parent_id', $sequenceId)
            ->orderBy('delay', 'ASC')
            ->get();

        $emailStatsMap = [];
        if ($includeEmailStats && $emails->isNotEmpty()) {
            $emailIds = $emails->pluck('id')->toArray();

            $totals = CampaignEmail::selectRaw('campaign_id, COUNT(*) as cnt')
                ->whereIn('campaign_id', $emailIds)
                ->groupBy('campaign_id')
                ->pluck('cnt', 'campaign_id')->toArray();

            $sent = CampaignEmail::selectRaw('campaign_id, COUNT(*) as cnt')
                ->whereIn('campaign_id', $emailIds)
                ->whereIn('status', ['sent', 'bounced'])
                ->groupBy('campaign_id')
                ->pluck('cnt', 'campaign_id')->toArray();

            $clicks = CampaignUrlMetric::selectRaw('campaign_id, COUNT(*) as cnt')
                ->whereIn('campaign_id', $emailIds)
                ->where('type', 'click')
                ->groupBy('campaign_id')
                ->pluck('cnt', 'campaign_id')->toArray();

            $opens = CampaignEmail::selectRaw('campaign_id, COUNT(*) as cnt')
                ->whereIn('campaign_id', $emailIds)
                ->where('is_open', 1)
                ->groupBy('campaign_id')
                ->pluck('cnt', 'campaign_id')->toArray();

            $unsubs = CampaignUrlMetric::selectRaw('campaign_id, COUNT(DISTINCT subscriber_id) as cnt')
                ->whereIn('campaign_id', $emailIds)
                ->where('type', 'unsubscribe')
                ->groupBy('campaign_id')
                ->pluck('cnt', 'campaign_id')->toArray();

            foreach ($emailIds as $eid) {
                $emailStatsMap[$eid] = [
                    'total'         => (int) ($totals[$eid] ?? 0),
                    'sent'          => (int) ($sent[$eid] ?? 0),
                    'clicks'        => (int) ($clicks[$eid] ?? 0),
                    'views'         => (int) ($opens[$eid] ?? 0),
                    'unsubscribers' => (int) ($unsubs[$eid] ?? 0),
                    'revenue'       => false,
                ];
            }
        }

        $emailsOut = [];
        foreach ($emails as $email) {
            // settings.timings holds the display unit; the `delay` column is in seconds.
            $settings = is_array($email->settings) ? $email->settings : (array) ProHelper::safeUnserialize($email->settings);
            $timings  = $settings['timings'] ?? [];
            $unit     = isset($timings['delay_unit']) && $timings['delay_unit'] !== ''
                ? sanitize_key((string) $timings['delay_unit'])
                : self::secondsToUnit((int) $email->delay);

            $row = [
                'id'              => (int) $email->id,
                'title'           => $email->title,
                'delay_seconds'   => (int) $email->delay,
                'delay'           => isset($timings['delay']) && $timings['delay'] !== ''
                    ? (int) $timings['delay']
                    : self::secondsToValue((int) $email->delay, $unit),
                'delay_unit'      => $unit,
                'email_subject'   => $email->email_subject,
                'email_pre_header' => $email->email_pre_header,
                'design_template' => $email->design_template,
                'status'          => $email->status,
            ];
            if ($includeBodies) {
                $body = (string) $email->email_body;
                $row['body_html'] = $body;
                $row['body_text'] = MCPHelper::htmlToText($body);
            }
            if ($includeEmailStats && isset($emailStatsMap[$email->id])) {
                $row['stats'] = $emailStatsMap[$email->id];
            }
            $emailsOut[] = $row;
        }

        $subscribersCount = SequenceTracker::where('campaign_id', $sequenceId)->count();

        return [
            'id'                => (int) $sequence->id,
            'title'             => $sequence->title,
            'status'            => $sequence->status,
            'settings'          => is_array($sequence->settings) ? $sequence->settings : [],
            'subscribers_count' => (int) $subscribersCount,
            'emails'            => $emailsOut,
            'created_at'        => MCPHelper::toIso8601($sequence->created_at),
            'updated_at'        => MCPHelper::toIso8601($sequence->updated_at),
        ];
    }

    /**
     * Pick the best human unit for a delay measured in seconds.
     */
    private static function secondsToUnit($seconds)
    {
        if ($seconds <= 0) return 'minutes';
        if ($seconds % 86400 === 0) return 'days';
        if ($seconds % 3600  === 0) return 'hours';
        return 'minutes';
    }

    private static function secondsToValue($seconds, $unit)
    {
        switch ($unit) {
            case 'days':    return (int) round($seconds / 86400);
            case 'hours':   return (int) round($seconds / 3600);
            case 'minutes':
            default:        return (int) round($seconds / 60);
        }
    }

    // -----------------------------------------------------------------
    // manage-sequence-subscribers
    // -----------------------------------------------------------------

    public static function manageSubscribers($params)
    {
        $params = (array) $params;
        $sequenceId = (int) ($params['sequence_id'] ?? 0);
        $action     = sanitize_key((string) ($params['action'] ?? ''));

        if (!$sequenceId) {
            return MCPHelper::error('invalid_param', 'sequence_id is required');
        }
        if (!in_array($action, ['subscribe', 'unsubscribe'], true)) {
            return MCPHelper::error('invalid_param', 'Invalid action');
        }
        if ($action === 'unsubscribe' && !PermissionManager::currentUserCan('fcrm_manage_email_delete')) {
            return MCPHelper::error('forbidden', 'You do not have permission to remove subscribers from sequences.');
        }

        $sequence = Sequence::find($sequenceId);
        if (!$sequence) {
            return MCPHelper::error('not_found', 'Sequence not found', ['sequence_id' => $sequenceId]);
        }

        $cap = (int) apply_filters('fluent_crm/mcp_bulk_cap', 5000, 'manage-sequence-subscribers');

        $contactIds = isset($params['contact_ids']) ? array_filter(array_map('intval', (array) $params['contact_ids'])) : [];
        $filter     = $params['filter'] ?? null;
        $dryRun     = !empty($params['dry_run']);

        if (!$contactIds && !$filter) {
            return MCPHelper::error('invalid_param', 'Provide contact_ids or filter');
        }

        $matchedTotal = 0;
        if (!$contactIds) {
            $validation = MCPHelper::validateUniversalFilter((array) $filter);
            if (is_wp_error($validation)) {
                return $validation;
            }
            $args = MCPHelper::buildContactsQueryArgs((array) $filter);
            $args['with'] = [];
            $cq = new ContactsQuery($args);
            MCPHelper::applyDateFilters($cq, (array) $filter);
            $query = $cq->getModel();
            $matchedTotal = (int) $query->count();
            // Dry runs still report the matched count when over cap.
            if ($matchedTotal > $cap && !$dryRun) {
                return MCPHelper::error('cap_reached', 'Too many contacts match the filter', [
                    'max'     => $cap,
                    'matched' => $matchedTotal,
                ]);
            }
            $contactIds = array_map('intval', $query->limit($cap)->pluck('id')->toArray());
        } else {
            $matchedTotal = count($contactIds);
            if ($matchedTotal > $cap && !$dryRun) {
                return MCPHelper::error('cap_reached', 'Too many contact_ids in a single call', [
                    'max'     => $cap,
                    'matched' => $matchedTotal,
                ]);
            }
        }

        $excludeIds = isset($params['exclude_contact_ids'])
            ? array_filter(array_map('intval', (array) $params['exclude_contact_ids']))
            : [];
        if ($excludeIds) {
            $contactIds = array_diff($contactIds, $excludeIds);
        }

        $exceedsCap = $matchedTotal > $cap;

        // Over-cap dry runs return null estimates.
        if ($dryRun && $exceedsCap) {
            return [
                'ok'                  => true,
                'dry_run'             => true,
                'action'              => $action,
                'matched_contacts'    => $matchedTotal,
                'cap'                 => $cap,
                'exceeds_cap'         => true,
                'batches_required'    => (int) ceil($matchedTotal / max(1, $cap)),
                'would_enroll'        => null,
                'already_enrolled'    => null,
                'would_unsubscribe'   => null,
                'note'                => 'Dry run: match exceeds the per-call cap. Enroll estimates unavailable for over-cap previews. Apply by passing contact_ids in batches.',
            ];
        }

        // Caps the IN() list size.
        $contactIdsForLookup = array_slice(array_values($contactIds), 0, $cap);

        // A cancelled tracker is not an enrolment, but the admin's subscribe action skips it too,
        // so those contacts are reported separately instead of being re-enrolled.
        $alreadyEnrolledIds = [];
        $cancelledIds       = [];
        $trackers = SequenceTracker::where('campaign_id', $sequenceId)
            ->whereIn('subscriber_id', $contactIdsForLookup)
            ->get(['subscriber_id', 'status']);
        foreach ($trackers as $tracker) {
            if ($tracker->status === 'cancelled') {
                $cancelledIds[] = (int) $tracker->subscriber_id;
            } else {
                $alreadyEnrolledIds[] = (int) $tracker->subscriber_id;
            }
        }
        $alreadyEnrolledIds = array_values(array_unique($alreadyEnrolledIds));
        $cancelledIds       = array_values(array_diff(array_unique($cancelledIds), $alreadyEnrolledIds));
        $newIds             = array_values(array_diff($contactIdsForLookup, $alreadyEnrolledIds, $cancelledIds));
        $cancelledNote      = $cancelledIds
            ? 'previously_cancelled contacts were unsubscribed from this sequence before and are not re-enrolled, as in the FluentCRM admin.'
            : null;

        if ($dryRun) {
            return [
                'ok'                  => true,
                'dry_run'             => true,
                'action'              => $action,
                'matched_contacts'    => $matchedTotal,
                'cap'                 => $cap,
                'exceeds_cap'         => false,
                'batches_required'    => 1,
                'would_enroll'        => $action === 'subscribe' ? count($newIds) : 0,
                'already_enrolled'    => count($alreadyEnrolledIds),
                'previously_cancelled' => count($cancelledIds),
                'would_unsubscribe'   => $action === 'unsubscribe' ? count($alreadyEnrolledIds) : 0,
                'note'                => trim('Dry run: nothing was changed. Re-run without dry_run=true to commit. ' . $cancelledNote),
            ];
        }

        $contactIds = $contactIdsForLookup;

        if ($action === 'subscribe') {
            $enrolledNow = 0;
            if ($newIds) {
                $subscribers = Subscriber::whereIn('id', array_values($newIds))->get();
                $sequence->subscribe($subscribers);
                $enrolledNow = count($subscribers);
            }

            return array_filter([
                'ok'                   => true,
                'action'               => 'subscribe',
                'matched_contacts'     => count($contactIds),
                'enrolled_now'         => $enrolledNow,
                'already_enrolled'     => count($alreadyEnrolledIds),
                'previously_cancelled' => count($cancelledIds),
                'note'                 => $cancelledNote,
            ], function ($value) {
                return $value !== null;
            });
        }

        // Only active enrolments are removed; this also cancels their scheduled emails.
        if ($alreadyEnrolledIds) {
            $sequence->unsubscribe($alreadyEnrolledIds);
        }

        return [
            'ok'      => true,
            'action'  => 'unsubscribe',
            'removed' => count($alreadyEnrolledIds),
        ];
    }
}
