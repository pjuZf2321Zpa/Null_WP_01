<?php

namespace FluentCampaign\App\Modules\MCP;

/**
 * Bootstrap for Pro's MCP abilities, registered in the core `fluent-crm/` namespace
 * once FluentCRM fires `fluent_crm/mcp_loaded`.
 */
class MCPInit
{
    public function init()
    {
        (new ToolkitInstaller())->init();

        add_action('fluent_crm/mcp_loaded', [$this, 'registerProAbilities']);
        add_filter('fluent_crm/mcp_ability_names', [$this, 'addAbilityNames']);
    }

    public function registerProAbilities()
    {
        if (!function_exists('wp_register_ability')) {
            return;
        }

        ProAbilitiesRegistrar::register();
    }

    public function addAbilityNames($names)
    {
        $names = is_array($names) ? $names : [];
        return array_merge($names, array_keys(ProAbilitiesRegistrar::getDefinitions()));
    }
}
