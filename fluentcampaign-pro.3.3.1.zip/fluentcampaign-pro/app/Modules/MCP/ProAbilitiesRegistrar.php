<?php

namespace FluentCampaign\App\Modules\MCP;

use FluentCampaign\App\Modules\MCP\Tools\SequenceTools;
use FluentCrm\App\Modules\MCP\AbilitiesRegistrar;
use FluentCrm\App\Modules\MCP\Helpers\MCPHelper;
use FluentCrm\App\Services\PermissionManager;

/**
 * Pro ability definitions. Registered after `fluent_crm/mcp_loaded` so they
 * land in the same `fluent-crm/` namespace as core tools.
 */
class ProAbilitiesRegistrar
{
    public static function getDefinitions()
    {
        return [
            'fluent-crm/list-sequences' => [
                'label'       => 'List Sequences',
                'description' => 'List email sequences (drip campaigns); stats (emails, subscribers, revenue) inline by default.',
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'search'        => ['type' => 'string', 'description' => 'Matches title.'],
                        'sort_by'       => ['type' => 'string', 'enum' => ['id', 'title', 'created_at', 'updated_at'], 'default' => 'id'],
                        'sort_type'     => ['type' => 'string', 'enum' => ['ASC', 'DESC'], 'default' => 'DESC'],
                        'include_stats' => ['type' => 'boolean', 'default' => true],
                        'page'          => ['type' => 'integer', 'default' => 1],
                        'per_page'      => ['type' => 'integer', 'default' => 15, 'description' => 'Max 100.'],
                    ],
                ],
                'execute_callback'    => [SequenceTools::class, 'listSequences'],
                'permission_callback' => function () {
                    return self::requireCap('fcrm_read_emails');
                },
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true, 'openWorldHint' => false],
            ],

            'fluent-crm/get-sequence' => [
                'label'       => 'Get Sequence',
                'description' => 'Email sequence details with emails inline. Bodies only with include_bodies=true (large sequences fill context).',
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'sequence_id'           => ['type' => 'integer'],
                        'include_bodies'        => ['type' => 'boolean', 'default' => false, 'description' => 'Add each email\'s body_html + body_text.'],
                        'include_email_stats'   => ['type' => 'boolean', 'default' => true],
                    ],
                    'required' => ['sequence_id'],
                ],
                'execute_callback'    => [SequenceTools::class, 'getSequence'],
                'permission_callback' => function () {
                    return self::requireCap('fcrm_read_emails');
                },
                'annotations' => ['readonly' => true, 'destructive' => false, 'idempotent' => true, 'openWorldHint' => false],
            ],

            'fluent-crm/manage-sequence-subscribers' => [
                'label'       => 'Manage Sequence Subscribers',
                'description' => 'Subscribe/unsubscribe up to 5000 contacts to an email sequence. contact_ids OR filter; if contact_ids is non-empty, filter is ignored. subscribe is idempotent (reports already_enrolled). unsubscribe cancels their scheduled emails; needs fcrm_manage_email_delete. Preview with dry_run=true.',
                'input_schema' => [
                    'type'       => 'object',
                    'properties' => [
                        'sequence_id'         => ['type' => 'integer'],
                        'action'              => ['type' => 'string', 'enum' => ['subscribe', 'unsubscribe']],
                        'contact_ids'         => ['type' => 'array', 'items' => ['type' => 'integer'], 'description' => 'Explicit ids; OR filter.'],
                        'filter'              => ['type' => 'object', 'description' => 'Same keys/validation as list-contacts (emails, tags, lists, statuses, contact_type, search, created_*, advanced_filters).'],
                        'exclude_contact_ids' => ['type' => 'array', 'items' => ['type' => 'integer'], 'description' => 'Ids to drop from the resolved set.'],
                        'dry_run'             => ['type' => 'boolean', 'default' => false, 'description' => 'Returns matched_contacts, would_enroll / would_unsubscribe, already_enrolled; no writes. Over the cap, matched_contacts stays the real count but would_enroll, would_unsubscribe and already_enrolled are null; apply via contact_ids batches.'],
                    ],
                    'required' => ['sequence_id', 'action'],
                ],
                'execute_callback'    => [SequenceTools::class, 'manageSubscribers'],
                'permission_callback' => function () {
                    return self::requireCap('fcrm_manage_emails');
                },
                // subscribe schedules sequence emails; unsubscribe cancels them. Re-subscribing reports already_enrolled.
                'annotations' => ['readonly' => false, 'destructive' => true, 'idempotent' => true, 'openWorldHint' => true],
            ],

        ];
    }

    /**
     * Ability permission check. Uses the free plugin's explanatory forbidden error when it has
     * one (FluentCRM 3.2.6+); older versions get the plain boolean.
     *
     * @return bool|\WP_Error
     */
    private static function requireCap($cap)
    {
        if (method_exists(MCPHelper::class, 'requireAnyCap')) {
            return MCPHelper::requireAnyCap([$cap]);
        }

        return PermissionManager::currentUserCan($cap);
    }

    /**
     * Wrap an execute callback with the free plugin's wrapper (meta.schema_version, exception
     * handling) when it is public, as in FluentCRM 3.2.6+.
     */
    private static function wrap($name, $callback)
    {
        if (is_callable([AbilitiesRegistrar::class, 'wrapExecuteCallback'])) {
            return AbilitiesRegistrar::wrapExecuteCallback($name, $callback);
        }

        return $callback;
    }

    public static function register()
    {
        foreach (self::getDefinitions() as $name => $definition) {
            $args = [
                'label'               => $definition['label'],
                'description'         => $definition['description'],
                'category'            => 'fluent-crm',
                'execute_callback'    => self::wrap($name, $definition['execute_callback']),
                'permission_callback' => $definition['permission_callback'],
                'meta'                => [
                    'show_in_rest' => true,
                    'mcp'          => [
                        'public' => true,
                    ],
                ],
            ];

            if (!empty($definition['input_schema'])) {
                $args['input_schema'] = $definition['input_schema'];
            }

            if (!empty($definition['annotations'])) {
                $args['meta']['annotations'] = $definition['annotations'];
            }

            wp_register_ability($name, $args);
        }
    }
}
