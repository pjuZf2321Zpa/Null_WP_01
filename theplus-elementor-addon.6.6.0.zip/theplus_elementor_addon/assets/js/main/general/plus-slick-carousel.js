/*slick carousel*/( function( $ ) {
	"use strict";
	var WidgetThePlusHandler = function ($scope, $) {
		var wid_sec=$scope.parents('section.elementor-element,.e-container,.e-con');
		if(wid_sec.find('.list-carousel-slick').length>0){
			var carousel_elem = $scope.find('.list-carousel-slick').eq(0);
				if (carousel_elem.length > 0) {
					if(!carousel_elem.hasClass("done-carousel")){
						theplus_carousel_list();
					}
				}
		}
		};
	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/global', WidgetThePlusHandler);
	});
})(jQuery);
function theplus_carousel_list(data_widget=''){	
	var $=jQuery;
	$('.list-carousel-slick').each(function() {
			var $self=$(this);
            //flexbox mobile
            var responsive_Device = $("body").data("elementor-device-mode");
            if("mobile" === responsive_Device){
                $self.closest('.e-container,.e-con').css('flex-wrap','unset');
            }
			var $uid=$self.data("id");
			var slider_direction=$self.data("slider_direction");
			var slide_speed=$self.data("slide_speed");
			var default_active_slide=$self.data("default_active_slide");
			var slider_desktop_column=$self.data("slider_desktop_column");
			var steps_slide=$self.data("steps_slide");
			var slide_fade_inout=$self.data("slide_fade_inout");
			var slider_padding=$self.data("slider_padding");
			var prev_arrow = '';			
			var next_arrow = '';
			
			var slider_draggable=$self.data("slider_draggable");
			var multi_drag=$self.data("multi_drag");
			var slider_infinite=$self.data("slider_infinite");
			var slider_pause_hover=$self.data("slider_pause_hover");
			var slider_adaptive_height=$self.data("slider_adaptive_height");
			var slider_animation=$self.data("slider_animation");
			
			var slider_autoplay=false;
			if(!elementorFrontend.isEditMode()){
				var slider_autoplay=$self.data("slider_autoplay");                
			}

			var autoplay_speed=$self.data("autoplay_speed");
			var slider_rows=$self.data("slider_rows");
			
			var slider_center_mode=$self.data("slider_center_mode");
			var center_padding=$self.data("center_padding");
			var scale_center_slide=$self.data("scale_center_slide");
			var scale_normal_slide=$self.data("scale_normal_slide");
			var opacity_normal_slide=$self.data("opacity_normal_slide");
			
			var slider_dots=$self.data("slider_dots");
			var slider_dots_style=$self.data("slider_dots_style");
			var tablet_slider_dots_style=$self.data("tablet_slider_dots_style");
			var mobile_slider_dots_style=$self.data("mobile_slider_dots_style");
			
			var slider_arrows=$self.data("slider_arrows");
			var slider_arrows_style=$self.data("slider_arrows_style");
			var tablet_slider_arrows_style=$self.data("tablet_slider_arrows_style");
			var mobile_slider_arrows_style=$self.data("mobile_slider_arrows_style");
			var arrows_position=$self.data("arrows_position");
			var tablet_arrows_position=$self.data("tablet_arrows_position");
			var mobile_arrows_position=$self.data("mobile_arrows_position");
			
			var slider_responsive_tablet=$self.data("slider_responsive_tablet");
			var slider_tablet_column=$self.data("slider_tablet_column");
			var tablet_steps_slide=$self.data("tablet_steps_slide");
			var tablet_center_mode=$self.data("tablet_center_mode");
			var tablet_center_padding=$self.data("tablet_center_padding");
			var tablet_slider_draggable=$self.data("tablet_slider_draggable");
			var tablet_slider_infinite=$self.data("tablet_slider_infinite");
			var tablet_slider_autoplay=$self.data("tablet_slider_autoplay");
			var tablet_autoplay_speed=$self.data("tablet_autoplay_speed");
			var tablet_slider_dots=$self.data("tablet_slider_dots");
			var tablet_slider_arrows=$self.data("tablet_slider_arrows");
			var tablet_slider_rows=$self.data("tablet_slider_rows");
			var tablet_center_mode=$self.data("tablet_center_mode");
			var tablet_center_padding=$self.data("tablet_center_padding");
			
			
			var slider_responsive_mobile=$self.data("slider_responsive_mobile");
			var mobile_slider_draggable=$self.data("mobile_slider_draggable");
			var mobile_slider_infinite=$self.data("mobile_slider_infinite");
			var mobile_slider_autoplay=$self.data("mobile_slider_autoplay");
			var mobile_autoplay_speed=$self.data("mobile_autoplay_speed");
			
			
			var slider_mobile_column=$self.data("slider_mobile_column");
			var mobile_steps_slide=$self.data("mobile_steps_slide");
			var mobile_center_mode=$self.data("mobile_center_mode");
			var mobile_center_padding=$self.data("mobile_center_padding");
			var mobile_slider_dots=$self.data("mobile_slider_dots");
			var mobile_slider_arrows=$self.data("mobile_slider_arrows");
			var mobile_slider_rows=$self.data("mobile_slider_rows");
			var mobile_center_mode=$self.data("mobile_center_mode");
			var mobile_center_padding=$self.data("mobile_center_padding");
			
			var testimonial_style=$self.data("testimonial-style");
			var slide_mouse_scroll=$self.data("slide_mouse_scroll");
			
			let data = $self[0].dataset;
			let parsedData = data && data.result ? JSON.parse(data.result) : '';

			var getDIrection = parsedData.carousel_direction,
				rtlVal = false;
			if( 'rtl' === getDIrection ){
				rtlVal = true;
			}

			if(steps_slide=='1'){
				steps_slide=='1';
			}else{
				steps_slide=slider_desktop_column;
			}
			if(tablet_steps_slide=='1'){
				tablet_steps_slide=='1';
			}else{
				tablet_steps_slide=slider_tablet_column;
			}
			if(slider_responsive_tablet!='yes'){
				tablet_slider_draggable=slider_draggable;
				tablet_slider_infinite=slider_infinite;
				tablet_slider_autoplay=slider_autoplay;
				tablet_autoplay_speed=autoplay_speed;
				tablet_slider_dots=slider_dots;
				tablet_slider_arrows=slider_arrows;
				tablet_slider_rows=slider_rows;
				tablet_center_mode=slider_center_mode;
				tablet_center_padding=center_padding;
			}
			if(slider_responsive_mobile!='yes'){
				mobile_slider_draggable=slider_draggable;
				mobile_slider_infinite=slider_infinite;
				mobile_slider_autoplay=slider_autoplay;
				mobile_autoplay_speed=autoplay_speed;
				mobile_slider_dots=slider_dots;
				mobile_slider_arrows=slider_arrows;
				mobile_slider_rows=slider_rows;
				mobile_center_mode=slider_center_mode;
				mobile_center_padding=center_padding;
			}
			
            if( slider_responsive_mobile == 'yes' ){
                var getdevice = jQuery('body').data('elementor-device-mode');
                if( getdevice == 'mobile'){
                    slider_rows = mobile_slider_rows;
                }
            }

			if(mobile_steps_slide=='1'){
				mobile_steps_slide=='1';
			}else{
				mobile_steps_slide=slider_mobile_column;
			}
			
			// Desktop
			if(slider_arrows_style=='style-1'){
				var prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+slider_arrows_style+'">Previous</button>';
				var next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+slider_arrows_style+'">Next</button>';
			}

			if(slider_arrows_style=='style-2'){
				var prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+slider_arrows_style+'"><span class="icon-wrap"></span>Previous</button>';
				var next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+slider_arrows_style+'"><span class="icon-wrap"></span>Next</button>';
			}

			if(slider_arrows_style=='style-3' || slider_arrows_style=='style-4' ){
				var prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+slider_arrows_style+' '+arrows_position+'">Previous</button>';
				var next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+slider_arrows_style+' '+arrows_position+'">Next</button>';
			}

			if(slider_arrows_style=='style-5'){
				var prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+slider_arrows_style+'"><span class="icon-wrap"></span>Previous</button>';
				var next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+slider_arrows_style+'"><span class="icon-wrap"></span>Next</button>';
			}

			if(slider_arrows_style=='style-6'){
				var prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+slider_arrows_style+'"><span class="icon-wrap"><i class="fas fa-long-arrow-alt-left" aria-hidden="true"></i></span>Previous</button>';
				var next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+slider_arrows_style+'"><span class="icon-wrap"><i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></span>Next</button>';
			}

			// Tablet
			if(responsive_Device === 'tablet'){
				if(tablet_slider_arrows_style=='style-1'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+tablet_slider_arrows_style+'">Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+tablet_slider_arrows_style+'">Next</button>';
				}
				if(tablet_slider_arrows_style=='style-2'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+tablet_slider_arrows_style+'"><span class="icon-wrap"></span>Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+tablet_slider_arrows_style+'"><span class="icon-wrap"></span>Next</button>';
				}
				if(tablet_slider_arrows_style=='style-3' || tablet_slider_arrows_style=='style-4' ){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+tablet_slider_arrows_style+' '+tablet_arrows_position+'">Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+tablet_slider_arrows_style+' '+tablet_arrows_position+'">Next</button>';
				}
				if(tablet_slider_arrows_style=='style-5'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+tablet_slider_arrows_style+'"><span class="icon-wrap"></span>Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+tablet_slider_arrows_style+'"><span class="icon-wrap"></span>Next</button>';
				}
				if(tablet_slider_arrows_style=='style-6'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+tablet_slider_arrows_style+'"><span class="icon-wrap"><i class="fas fa-long-arrow-alt-left" aria-hidden="true"></i></span>Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+tablet_slider_arrows_style+'"><span class="icon-wrap"><i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></span>Next</button>';
				}
			}

			// Mobile
			if(responsive_Device === 'mobile'){
				if(mobile_slider_arrows_style=='style-1'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+mobile_slider_arrows_style+'">Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+mobile_slider_arrows_style+'">Next</button>';
				}
				if(mobile_slider_arrows_style=='style-2'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+mobile_slider_arrows_style+'"><span class="icon-wrap"></span>Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+mobile_slider_arrows_style+'"><span class="icon-wrap"></span>Next</button>';
				}
				if(mobile_slider_arrows_style=='style-3' || mobile_slider_arrows_style=='style-4' ){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+mobile_slider_arrows_style+' '+mobile_arrows_position+'">Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+mobile_slider_arrows_style+' '+mobile_arrows_position+'">Next</button>';
				}
				if(mobile_slider_arrows_style=='style-5'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+mobile_slider_arrows_style+'"><span class="icon-wrap"></span>Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+mobile_slider_arrows_style+'"><span class="icon-wrap"></span>Next</button>';
				}
				if(mobile_slider_arrows_style=='style-6'){
					prev_arrow='<button role="tab" type="button" class="slick-nav slick-prev '+mobile_slider_arrows_style+'"><span class="icon-wrap"><i class="fas fa-long-arrow-alt-left" aria-hidden="true"></i></span>Previous</button>';
					next_arrow='<button role="tab" type="button" class="slick-nav slick-next '+mobile_slider_arrows_style+'"><span class="icon-wrap"><i class="fas fa-long-arrow-alt-right" aria-hidden="true"></i></span>Next</button>';
				}
			}

			if(default_active_slide==undefined){
				default_active_slide=0;
			}

			var args = {dots: slider_dots,
				vertical: slider_direction,	
				fade:slide_fade_inout,
				arrows: slider_arrows,
				infinite: slider_infinite,										
				speed: slide_speed,
				initialSlide: default_active_slide,
				adaptiveHeight: slider_adaptive_height,
				autoplay: slider_autoplay,
				cssEase: slider_animation,
				autoplaySpeed: autoplay_speed,
				pauseOnHover: slider_pause_hover,
				centerMode: slider_center_mode,
				centerPadding: center_padding+'px',
				prevArrow: prev_arrow,
				nextArrow: next_arrow,
				slidesToShow: slider_desktop_column,
				slidesToScroll: steps_slide,
				draggable:slider_draggable,
				swipeToSlide:multi_drag,
				dotsClass:slider_dots_style,
				rows : slider_rows,
				rtl : rtlVal,
				responsive: [
					{
						breakpoint: 1024,
						settings: {
							dots: tablet_slider_dots,
							arrows: tablet_slider_arrows,
							infinite: tablet_slider_infinite,
							autoplay: tablet_slider_autoplay,
							cssEase: slider_animation,
							autoplaySpeed: tablet_autoplay_speed,
							draggable:tablet_slider_draggable,
							swipe: tablet_slider_draggable,
							rows : tablet_slider_rows,
							slidesToShow: slider_tablet_column,
							slidesToScroll: tablet_steps_slide,
							centerMode: tablet_center_mode,
							centerPadding: tablet_center_padding+'px',
                            dotsClass:tablet_slider_dots_style,

						}
					},
					{
						breakpoint: 768,
						settings: {
							dots: mobile_slider_dots,								
							arrows: mobile_slider_arrows,
							infinite: mobile_slider_infinite,
							autoplay: mobile_slider_autoplay,
							cssEase: slider_animation,
							autoplaySpeed: mobile_autoplay_speed,
							draggable:mobile_slider_draggable,
							swipe: mobile_slider_draggable,
							rows : mobile_slider_rows,
							slidesToShow: slider_mobile_column,
							slidesToScroll: mobile_steps_slide,
							centerMode: mobile_center_mode,
							centerPadding: mobile_center_padding+'px',
                            dotsClass:mobile_slider_dots_style,
						}
					}
				]
			}
            
			if(!$(this).hasClass("done-carousel") && !$self.hasClass('theplus-insta-grid')){
				var $track = $('> .post-inner-loop',this);
				$track.slick(args);
				// setTimeout(function(){
					$(".slick-dots.style-2 li").each(function(){
						if($(this).find("svg").length==0){
							$(this).append('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 16 16" preserveAspectRatio="none"><circle cx="8" cy="8" r="6.215"></circle></svg>');
						}
					});
				// }, 1000);
				$(this).addClass("done-carousel");
				if(slider_autoplay){
					tpaeAddCarouselPauseToggle($self, $track);
				}
				tpaeFixCarouselDotAria($track);
				tpaeObserveCarouselDotAria($track);
				if(slide_mouse_scroll==true && slide_mouse_scroll!=undefined){

					$('.'+$uid+' > .post-inner-loop').mousewheel(function(e) {
						e.preventDefault();
						if (e.deltaY < 0) {
							$('.'+$uid+' > .post-inner-loop').slick("slickNext");
							} else {
							$('.'+$uid+' > .post-inner-loop').slick("slickPrev");
						}
					});
				}
			}else if(!$(this).hasClass("done-carousel") && $self.hasClass('theplus-insta-grid') && data_widget!='' && data_widget=='instagram'){
				if($('.'+$uid+' > .post-inner-loop').find('.theplus-insta-feed').length > 0){
					var $instaTrack = $('> .post-inner-loop',this);
					$instaTrack.slick(args);
					$(this).addClass("done-carousel");
					setTimeout(function(){
						$(".slick-dots.style-2 li").each(function(){
							if($(this).find("svg").length==0){
								$(this).append('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 16 16" preserveAspectRatio="none"><circle cx="8" cy="8" r="6.215"></circle></svg>');
							}
						});
					}, 1000);
					if(slider_autoplay){
						tpaeAddCarouselPauseToggle($self, $instaTrack);
					}
					tpaeFixCarouselDotAria($instaTrack);
					tpaeObserveCarouselDotAria($instaTrack);
				}
			}
		
			var carousel_bg_conn = $(this).data("carousel-bg-conn");
			if(carousel_bg_conn !='' && carousel_bg_conn!= undefined){
				if($("#"+carousel_bg_conn).length > 0){
					$('> .post-inner-loop',this).on('beforeChange', function(event, slick, currentSlide, nextSlide){
						var active_bg = $("#"+carousel_bg_conn+' .bg-carousel-slide');
						active_bg.removeClass('bg-active-slide');
						if(active_bg.length > nextSlide){
							active_bg.eq(nextSlide).addClass('bg-active-slide');
						}else{
							var bg_total = active_bg.length;
							var c = nextSlide % bg_total;
							active_bg.eq(c).addClass('bg-active-slide');
						}
					});
				}
			}
			
			var connection = $(this).data("connection");
			if(connection !='' && connection!= undefined && $("#"+connection).length > 0){
				$('> .post-inner-loop',this).on('beforeChange', function(event, slick, currentSlide, nextSlide){
					
					if($('.theplus-carousel-remote .tp-carousel-dots').length){
						if($('.theplus-carousel-remote').data("connection") === connection){
							$(".tp-carousel-dots").find(".tp-carodots-item").removeClass('active default-active').addClass('inactive');
							var inc = nextSlide + 1;
							$(".tp-carousel-dots").find(".tp-carodots-item:nth-child("+inc+")").addClass('active');
						}						
					}
					
					if(!$("#"+connection).find('.tp-process-steps-wrapper[data-index="'+parseInt(nextSlide)+'"]').hasClass("active")){
						var con__event = $("#"+connection).data("eventtype");
						if(con__event=='con_pro_click'){							
							$("#"+connection).find('.tp-process-steps-wrapper[data-index="'+parseInt(nextSlide)+'"]').trigger("click");
						}else if(con__event=='con_pro_hover'){
							$("#"+connection).find('.tp-process-steps-wrapper[data-index="'+parseInt(nextSlide)+'"]').trigger("mouseenter");
						}
						$("#"+connection).find('.tp-process-steps-wrapper').removeClass("active");
						$("#"+connection).find('.tp-process-steps-wrapper[data-index="'+parseInt(nextSlide)+'"]').addClass("active");
					}
				});
			}
			
			
			if((slider_center_mode===true && slider_center_mode !=undefined) || (mobile_center_mode===true && mobile_center_mode !=undefined) || (tablet_center_mode===true && tablet_center_mode !=undefined)){
				$('> .post-inner-loop',this).on('beforeChange', function (event, slick, currentSlide, nextSlide) {
					var 
						direction,
						slideCountZeroBased = slick.slideCount - 1;

					if (nextSlide == currentSlide) {
						direction = "same";

					} else if (Math.abs(nextSlide - currentSlide) == 1) {
						direction = (nextSlide - currentSlide > 0) ? "right" : "left";

					} else {
						direction = (nextSlide - currentSlide > 0) ? "left" : "right";
					}
					
					if (direction == 'right') {
						$('.slick-cloned[data-slick-index="' + (nextSlide + slideCountZeroBased + 1) + '"]', this).addClass('scc-animate');
					}

					if (direction == 'left') {
						$('.slick-cloned[data-slick-index="' + (nextSlide - slideCountZeroBased - 1) + '"]', this).addClass('scc-animate');
					}
				});

				$('> .post-inner-loop',this).on('afterChange', function (event, slick, currentSlide, nextSlide) {
					$('.scc-animate', this).removeClass('scc-animate');
					$('.scc-animate', this).removeClass('scc-animate');
				});
			}
	});
}

/**
 * Move a connected carousel to a given slide, keeping the request alive
 * across an in-flight transition.
 *
 * Slick's slideHandler returns early while `animating` is true and
 * `waitForAnimate` is on (its default), so a slickGoTo issued during a
 * transition is silently dropped. Connected accordions, tabs, steps and
 * info boxes therefore lose every switch a visitor makes inside the
 * slide-speed window - on a 1500ms carousel that is most ordinary clicks -
 * and the two elements stay out of sync until a later click happens to
 * land while the track is idle.
 *
 * Remembering the last requested index on the track and replaying it once
 * the transition ends keeps the carousel on whatever the visitor chose
 * last. The replay is deferred by a tick because slick fires afterChange
 * before it clears `animating`, so a synchronous retry would be dropped
 * for the same reason. Rapid clicks collapse to the final index rather
 * than queueing a slide per click.
 *
 * Also guards the track being absent or not yet slick-initialised, which
 * otherwise throws out of the caller's click handler.
 *
 * @since 6.5.2
 */
function tpae_carousel_goto( $track, index ) {
	var $ = jQuery;

	if ( ! $track || ! $track.length || ! $track[0].slick ) {
		return;
	}

	index = parseInt( index, 10 );

	if ( isNaN( index ) || index < 0 ) {
		return;
	}

	if ( true !== $track[0].slick.animating ) {
		if ( $track.slick( 'slickCurrentSlide' ) !== index ) {
			$track.slick( 'slickGoTo', index );
		}

		return;
	}

	$track.data( 'tpaePendingSlide', index );

	if ( ! $track.data( 'tpaePendingBound' ) ) {
		$track.data( 'tpaePendingBound', true );

		$track.on( 'afterChange.tpaePending', function() {
			var pending = $track.data( 'tpaePendingSlide' );

			$track.data( 'tpaePendingSlide', null );

			if ( null === pending || undefined === pending ) {
				return;
			}

			setTimeout( function() {
				tpae_carousel_goto( $track, pending );
			}, 0 );
		});
	}
}

function accordion_tabs_connection(tab_index,connection){
	var $=jQuery;
	if(connection!='' && $("."+connection).length==1){
		tpae_carousel_goto($('.'+connection+' > .post-inner-loop'), tab_index-1);
	}
}

/*
 * T5/T6 (reports/widget-test/testimonial): Slick's own dots markup sets
 * aria-selected="true" on the active tab but leaves it absent (not "false")
 * on every inactive one, and never wires aria-labelledby from a slide panel
 * back to the dot that controls it. Runs once after init and again after
 * every slide change, since Slick rebuilds this markup on each transition.
 * Mirrors the identical fix in Free's copy of this file.
 */
function tpaeFixCarouselDotAria( $track ) {
	var $ = jQuery;
	var $dots = $track.closest(".list-carousel-slick").find(".slick-dots > li > button");
	$dots.each( function() {
		var $dot = $( this );
		if ( "true" !== $dot.attr( "aria-selected" ) && "false" !== $dot.attr( "aria-selected" ) ) {
			$dot.attr( "aria-selected", "false" );
		}
		if ( ! $dot.attr( "id" ) ) {
			$dot.attr( "id", $dot.attr( "aria-controls" ) + "-tab" );
		}
		var $panel = $( "#" + $dot.attr( "aria-controls" ) );
		if ( $panel.length && ! $panel.attr( "aria-labelledby" ) ) {
			$panel.attr( "aria-labelledby", $dot.attr( "id" ) );
		}
	});
}

/*
 * Binding a jQuery "afterChange" listener on the slick track turned out
 * unreliable in testing -- it does not fire for every transition path
 * (autoplay tick vs. dot click vs. arrow key each go through slightly
 * different internal Slick code). A MutationObserver watching the dots'
 * own aria-selected attribute is robust to that: it reacts to the actual
 * DOM change Slick makes (setting the new active dot's aria-selected to
 * "true"), regardless of what triggered it. The re-entrancy guard exists
 * because tpaeFixCarouselDotAria() itself sets aria-selected on the
 * *other* dots, which would otherwise re-trigger this same observer.
 * Mirrors the identical fix in Free's copy of this file.
 */
function tpaeObserveCarouselDotAria( $track ) {
	if ( ! ( "MutationObserver" in window ) ) {
		return;
	}
	var $dotsContainer = $track.closest(".list-carousel-slick").find(".slick-dots").get(0);
	if ( ! $dotsContainer ) {
		return;
	}
	var handling = false;
	var observer = new MutationObserver( function() {
		if ( handling ) {
			return;
		}
		handling = true;
		tpaeFixCarouselDotAria( $track );
		handling = false;
	});
	observer.observe( $dotsContainer, { attributes: true, attributeFilter: [ "aria-selected" ], subtree: true } );
}

/*
 * WCAG 2.2.2 (Pause, Stop, Hide), Level A: these carousels autoplay with no
 * way to stop it, and slider_pause_hover being 'no' (the shipped default for
 * several widgets) means even hover doesn't help -- and hover has no
 * keyboard/touch equivalent anyway. Every widget that shares this init
 * function gets a real pause/play toggle when autoplay is resolved true,
 * rather than fixing this per widget. Visually hidden until it takes
 * keyboard focus, so existing layouts render unchanged for sighted mouse
 * users -- same shape as the Video Player pause control shipped on v6.5.2.
 * Mirrors the identical fix in Free's copy of this file (Free's version has
 * no responsive/tablet/mobile autoplay split, so it only needs one call
 * site; this file has two, per the two .slick() init branches above).
 */
function tpaeAddCarouselPauseToggle( $self, $track ) {
	var $ = jQuery;
	if ( $self.find(".tpae-carousel-pause-toggle").length > 0 ) {
		return;
	}
	tpaeEnsureCarouselPauseToggleStyle();

	/*
	 * Labels come from the globals Free's generator prints (translatable via
	 * tpebl). A plain JS string cannot go through WordPress translation
	 * functions; the English fallback keeps the control usable if the inline
	 * script is absent.
	 */
	var pausedLabel = ( "undefined" !== typeof theplus_carousel_play ) ? theplus_carousel_play : "Play automatic slideshow";
	var playingLabel = ( "undefined" !== typeof theplus_carousel_pause ) ? theplus_carousel_pause : "Pause automatic slideshow";
	var $btn = $( '<button type="button" class="tpae-carousel-pause-toggle" aria-pressed="false" aria-label="' + playingLabel + '">&#10073;&#10073;</button>' );

	$btn.on( "click", function() {
		var isPaused = "true" === $btn.attr("aria-pressed");
		if ( isPaused ) {
			$track.slick("slickPlay");
			$btn.attr( "aria-pressed", "false" ).attr( "aria-label", playingLabel ).html("&#10073;&#10073;");
		} else {
			$track.slick("slickPause");
			$btn.attr( "aria-pressed", "true" ).attr( "aria-label", pausedLabel ).html("&#9654;");
		}
	});

	/*
	 * Appended to a new zero-height, relatively-positioned anchor rather than
	 * setting position:relative on the carousel itself. .slick-dots inside it is
	 * position:absolute, so making the carousel a positioning context would
	 * re-anchor the dots and move them on any site where the carousel was static.
	 */
	var $anchor = $( '<div class="tpae-carousel-pause-anchor"></div>' );
	$self.prepend( $anchor );
	$anchor.append( $btn );
}

function tpaeEnsureCarouselPauseToggleStyle() {
	var $ = jQuery;
	if ( $("#tpae-carousel-pause-toggle-style").length > 0 ) {
		return;
	}
	$( "<style>", { id: "tpae-carousel-pause-toggle-style" } ).text(
		".tpae-carousel-pause-anchor{position:relative;height:0}" +
		".tpae-carousel-pause-toggle{position:absolute;top:8px;right:8px;z-index:9;" +
		"width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);" +
		"white-space:nowrap;border:0;background:rgba(0,0,0,.6);color:#fff;cursor:pointer;" +
		"font-size:14px;line-height:1;border-radius:3px;}" +
		".tpae-carousel-pause-toggle:focus{width:auto;height:auto;padding:6px 10px;margin:0;" +
		"overflow:visible;clip:auto;outline:2px solid #fff;outline-offset:2px;}"
	).appendTo("head");
}
