( function ( $ ) {
	'use strict';
	$(document).ready(function(){
		plus_reveal_animation();
	});
}( jQuery ));
function plus_reveal_animation(){
	'use strict';
	var $=jQuery;
	$('.pt-plus-reveal').each(function() {
		var b=$(this);
		var uid=b.data('reveal-id');
		var color_1=b.data('effect-color-1');
		var color_2=b.data('effect-color-2');
		/* Both colours are pasted into a <style> tag, so anything that is not a plain CSS colour could close the tag and inject markup. */
		var tpIsColor=function(c){ return typeof c === 'string' && ! /[<>{};]/.test(c) && ! ( window.CSS && CSS.supports && ! CSS.supports( 'color', c ) ); };
		if ( ! tpIsColor(color_1) ) { color_1 = ''; }
		if ( ! tpIsColor(color_2) ) { color_2 = ''; }
		$('head').append("<style type='text/css'>."+uid+".animated::before{background: "+color_2+";}."+uid+".animated::after{background: "+color_1+";}</style>");
		b.waypoint(function(direction) {
			if( direction === 'down'){
				if(b.hasClass("animated")){
					b.hasClass("animated");
					}else{
					b.addClass("animated");
				}
			}
		}, {triggerOnce: true,  offset: '85%' } );
	});
}