<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$postid = get_the_ID();
?>
<?php if ( $display_post_category == 'yes' ) { ?>
	<div class="post-metro-category-top">
		<?php // Security: sanitize_file_name() - $post_category_style is an Elementor SELECT value with no server-side option-list validation; this was a raw include() (LFI via ../ traversal). ?>
		<?php include THEPLUS_WSTYLES . 'dynamic-listing/dl-category-' . sanitize_file_name( $post_category_style ) . '.php'; ?>
	</div>
<?php } ?>
<div class="post-metro-content">
	<?php require THEPLUS_WSTYLES . 'dynamic-listing/post-meta-title.php'; ?>
	<?php if ( ! empty( $display_excerpt ) && $display_excerpt == 'yes' && get_the_excerpt() ) { ?>
		<div class="post-hover-content">
			<?php include THEPLUS_WSTYLES . 'dynamic-listing/get-excerpt.php'; ?>
		</div>
	<?php } ?>
	<?php if ( ! empty( $display_post_meta ) && $display_post_meta == 'yes' ) { ?>
		<?php include THEPLUS_WSTYLES . 'dynamic-listing/dl-post-meta-' . sanitize_file_name( $post_meta_tag_style ) . '.php'; ?>
	<?php } ?>
	<?php
	if ( $the_button != '' ) {
		echo $the_button;
	}
	?>
</div>
