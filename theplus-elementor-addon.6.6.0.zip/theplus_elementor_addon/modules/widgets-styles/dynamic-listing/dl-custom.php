<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
if ( ! empty( $template_id ) ) {
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="blog-list-content">		
	<?php
	global $tp_render_loop, $wp_query, $tp_index;
	++$tp_index;

	$tp_old_query = $wp_query;

	/*
	 * post_type is NOT optional here. WP_Query defaults it to 'post', so
	 * new WP_Query( array( 'p' => $id ) ) returns ZERO rows for any other
	 * type -- measured in the lab: post found, page EMPTY, product EMPTY.
	 * This skin renders products, so the query it swapped into $wp_query
	 * was empty on every single item, and any dynamic tag in the template
	 * that reads the loop saw nothing.
	 *
	 * Resolved from the post itself rather than 'any', which silently
	 * excludes post types registered with exclude_from_search.
	 */
	/*
	 * Runs once per grid item (N items = N of these). The extra flags below
	 * don't change what this query returns -- it already targets exactly one
	 * known post id -- they just stop WP_Query from doing work that result
	 * can never need: a SQL_CALC_FOUND_ROWS pass, a sticky-post reorder, and
	 * a meta/term cache-priming pass sized for a real listing query instead
	 * of a single row.
	 */
	$new_query = new \WP_Query(
		array(
			'p'                      => get_the_ID(),
			'post_type'              => get_post_type( get_the_ID() ),
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
		)
	);

	$wp_query = $new_query;

	$pid = get_the_ID();

	$template_id = apply_filters( 'Dynamic_Listing_template', $template_id, $pid, $tp_index );
	$template_id = get_current_ID( $template_id );

	$tp_render_loop = get_the_ID() . ',' . $template_id;

	/*
	 * The template id arrives from $_POST['option'] via the nopriv pagination and
	 * search-filter handlers, which -- unlike their eight siblings -- do not run it
	 * through tp_check_decrypt_key(). A truthiness check alone let an anonymous
	 * caller name ANY post id and have Elementor render it, disclosing drafts,
	 * private posts and password-protected content.
	 *
	 * This is the guard already used at class-tp-wp-quickview.php:103. Only
	 * published templates render.
	 */
	if ( ! $template_id || 'publish' !== get_post_status( (int) $template_id ) ) {
		return;
	}

	$return         = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $template_id, true );
	$tp_render_loop = false;
	$wp_query       = $tp_old_query;

	echo $return;
	include THEPLUS_WSTYLES . 'dynamic-listing/blog-skeleton.php';
	?>
		</div>
	</article>
	<?php
} else {
	echo esc_html__( 'Select a Template', 'theplus' );
}
?>
