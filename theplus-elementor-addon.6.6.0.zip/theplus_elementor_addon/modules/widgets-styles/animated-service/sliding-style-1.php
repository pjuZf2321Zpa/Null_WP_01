<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="tp-sb-image">
	<img src="<?php echo esc_url( $featured_image ); ?>">
</div>
<div class="asb-content" >
	<?php echo $list_title . $list_sub_title . $description . $loop_button; ?>
</div>
