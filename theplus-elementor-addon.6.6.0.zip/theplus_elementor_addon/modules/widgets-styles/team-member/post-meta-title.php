<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! isset( $post_title_tag ) && empty( $post_title_tag ) ) {
	$post_title_tag = 'h3';
}

$tmTitle = '';
if ( 'repeater' === $selctSource ) {
	$tmTitle = ! empty( $item['memberTitle'] ) ? $item['memberTitle'] : '';
} else {
	$tmTitle = get_the_title();
}

?>

<<?php echo theplus_validate_html_tag( $post_title_tag ); ?> class="post-title">
	<?php
	/*
	 * WID-A-007: was `empty( $disable_link ) && 'yes' !== $disable_link` --
	 * disable_link is a SWITCHER control (only '' or 'yes'), so both
	 * clauses tested the same thing and the && was a no-op. Simplified,
	 * no behavioural change.
	 *
	 * TM2 (widget-test/team-member, Medium): added !empty( $member_url ) --
	 * this wrapped in <a href="..."> whenever disable_link wasn't 'yes',
	 * regardless of whether a URL was actually configured. A repeater
	 * member with no customUrl still got an anchor with an empty href,
	 * one of the "links that go nowhere" the audit measured. disable_link's
	 * own opt-out behaviour is unchanged.
	 */
	if ( 'yes' !== $disable_link && ! empty( $member_url ) ) {
		?> <a href="<?php echo esc_url( $member_url ); ?>"> <?php
	}

	echo esc_html( $tmTitle );

	if ( 'yes' !== $disable_link && ! empty( $member_url ) ) { ?>
		</a>
	<?php } ?>
</<?php echo theplus_validate_html_tag( $post_title_tag ); ?>>
