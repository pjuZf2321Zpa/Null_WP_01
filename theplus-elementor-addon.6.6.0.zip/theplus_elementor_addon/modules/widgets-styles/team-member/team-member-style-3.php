<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$postid = get_the_ID();

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="team-list-content">
		<div class="post-content-image">
			<?php
			/*
			 * TM2 (widget-test/team-member, Medium, Pro side): see
			 * team-member-style-1.php for the full note -- added
			 * !empty( $member_url ) so this doesn't wrap with an empty href
			 * when a repeater member has no configured URL.
			 */
			?>
			<?php if ( empty( $disable_link ) && $disable_link != 'yes' && ! empty( $member_url ) ) { ?>
				<a rel="<?php echo esc_attr( $member_urlNofollow ); ?>" href="<?php echo esc_url( $member_url ); ?>" target="<?php echo esc_attr( $member_urlBlank ); ?>">
				<?php
			}
				require THEPLUS_WSTYLES . 'team-member/format-image.php';

			if ( empty( $disable_link ) && $disable_link != 'yes' && ! empty( $member_url ) ) {
				?>
				</a> <?php } ?>
		</div>		
		<div class="post-content-bottom">
			<div class="content-table">
				<div class="table-cell">
					<?php require THEPLUS_WSTYLES . 'team-member/post-meta-title.php'; ?>
				</div>
				<div class="table-cell">
					<?php
					if ( ! empty( $team_social_contnet ) && ! empty( $display_social_icon ) && $display_social_icon == 'yes' ) {
						echo $team_social_contnet;
					}
					?>
				</div>
			</div>
			<?php
			if ( ! empty( $designation ) && ! empty( $display_designation ) && $display_designation == 'yes' ) {
				echo $designation;
			}
			?>
		</div>
	<?php
		require THEPLUS_WSTYLES . 'dynamic-listing/blog-skeleton.php'; 
	?>
	</div>
</article>
