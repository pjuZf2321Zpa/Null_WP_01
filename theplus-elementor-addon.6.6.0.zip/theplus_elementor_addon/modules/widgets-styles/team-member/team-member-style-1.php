<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$postid = get_the_ID();

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="team-list-content">
		<div class="post-content-image">
			<?php
			/*
			 * TM2 (widget-test/team-member, Medium, Pro side): this was wrapped
			 * in <a> whenever disable_link wasn't 'yes', regardless of whether
			 * a URL was actually configured -- a repeater member with no
			 * customUrl still got href="" plus a pointless target/rel. Added
			 * !empty( $member_url ) alongside the existing disable_link check;
			 * disable_link's own behaviour (an explicit opt-out) is unchanged.
			 */
			?>
			<?php if ( empty( $disable_link ) && $disable_link != 'yes' && ! empty( $member_url ) ) { ?>
				<a rel="<?php echo esc_attr( $member_urlNofollow ); ?>" href="<?php echo esc_url( $member_url ); ?>" target="<?php echo esc_attr( $member_urlBlank ); ?>">
				<?php
			}

				require THEPLUS_WSTYLES . 'team-member/format-image.php';

			if ( empty( $disable_link ) && $disable_link != 'yes' && ! empty( $member_url ) ) {
				?>
				</a>
				<?php
			}

			if ( ! empty( $team_social_contnet ) && ! empty( $display_social_icon ) && $display_social_icon == 'yes' ) {
				echo $team_social_contnet;
			}
			?>
		</div>		
		<div class="post-content-bottom">			
			<?php
				require THEPLUS_WSTYLES . 'team-member/post-meta-title.php';

			if ( ! empty( $designation ) && ! empty( $display_designation ) && $display_designation == 'yes' ) {
				echo $designation;
			}
			?>
		</div>		
	<?php
		require THEPLUS_WSTYLES . 'dynamic-listing/blog-skeleton.php'; 
	?>
	</div>
</article>
