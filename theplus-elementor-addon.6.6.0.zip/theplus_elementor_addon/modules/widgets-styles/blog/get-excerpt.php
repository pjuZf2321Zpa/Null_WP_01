<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="entry-content">
	<p><?php echo esc_html( theplus_excerpt( $post_excerpt_count ) ); ?></p>
</div>
