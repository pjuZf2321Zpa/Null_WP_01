<?php

use Elementor\Core\DynamicTags\Tag;
use Elementor\Modules\DynamicTags\Module;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Plus Addons Dynamic Tag - ACF Field
 *
 * Provides a dynamic tag for Elementor to output an ACF field value.
 *
 * @since 6.4.5
 */
class ThePlus_Dynamic_Tag_ACF_Text extends Tag {

	/**
	 * ACF field types whose value can be printed as text.
	 *
	 * @since 6.5.1
	 * @var array
	 */
	const SUPPORTED_TYPES = array(
		'text',
		'textarea',
		'number',
		'range',
		'email',
		'url',
		'password',
		'wysiwyg',
		'select',
		'checkbox',
		'radio',
		'button_group',
		'true_false',
		'date_picker',
		'date_time_picker',
		'time_picker',
		'color_picker',
	);

    /**
     * Unique dynamic tag name used internally by Elementor.
     *
     * @since 6.4.5
     * @return string
     */
	public function get_name(): string {
		return 'plus-tag-acf-text';
	}

    /**
     * Label shown in Elementor Dynamic Tags list.
     *
     * @since 6.4.5
     * @return string
     */
	public function get_title(): string {
		return esc_html__( 'ACF Field', 'theplus' );
	}

    /**
     * Registers the group under which this tag will appear.
     *
     * @since 6.4.5
     * @return array
     */
	public function get_group(): array {
		return [ 'plus-opt-acf' ];
	}

    /**
     * Defines the category type (Text) for this dynamic tag.
     *
     * @since 6.4.5
     * @return array
     */
	public function get_categories(): array {
		return [
			Module::TEXT_CATEGORY,
		];
	}

    /**
     * Indicates that settings panel should be shown (even if empty).
     *
     * @since 6.4.5
     * @return bool
     */
	public function is_settings_required(): bool {
		return true;
	}

    /**
     * Register controls for this dynamic tag.
     *
     * @since 6.4.5
     * @return void
     */
	protected function register_controls(): void {

		$this->add_control(
			'acf_source',
			[
				'label'   => esc_html__( 'Source', 'theplus' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post',
				'options' => [
					'post'   => esc_html__( 'Post', 'theplus' ),
					'author' => esc_html__( 'Post Author', 'theplus' ),
				],
			]
		);

		// Existing Field Selector
		$this->add_control(
			'acf_field_key',
			[
				'label'  => esc_html__( 'Key', 'theplus' ),
				'type'   => Controls_Manager::SELECT,
				'groups' => ThePlus_ACF_Tag_Helper::get_field_options( self::SUPPORTED_TYPES ),
				'description' => wp_kses_post(
					sprintf(
						'<p class="tp-controller-label-text"><i>%s</i></p>',
						esc_html__( 'Select the ACF field you want to display.', 'theplus' )
					),
				),
			]
		);
	}

    /**
     * Get ACF field groups and their text-safe fields.
     *
     * @since 6.4.5
     * @return void
     */
    /**
     * Render the dynamic selected ACF field on frontend.
     *
     * Gets the current selected ACF field and prints its value.
     *
     * @since 6.4.5
     * @return void
     */
	public function render(): void {

		$settings   = $this->get_settings_for_display();
		$field_name = $settings['acf_field_key'] ?? '';
		$source     = $settings['acf_source'] ?? 'post';

		if ( empty( $field_name ) || ! function_exists( 'get_field' ) ) {
			return;
		}

		$value = '';

		if ( 'author' === $source ) {

			// Resolve author across author archive, singular post, and fallback to current user.
			$author_id = 0;

			// The post being rendered wins, so a loop card resolves its own author.
			$post_id = absint( get_the_ID() );

			if ( $post_id ) {
				$author_id = (int) get_post_field( 'post_author', $post_id );
			}

			if ( ! $author_id && is_author() ) {
				$author_id = (int) get_queried_object_id();
			}

			if ( ! $author_id ) {
				$author_id = get_current_user_id();
			}

			if ( $author_id ) {
				$value = ThePlus_ACF_Tag_Helper::get_value( $field_name, 'user_' . $author_id );
			}
		} else {
			$value = ThePlus_ACF_Tag_Helper::get_value( $field_name );
		}

		if ( empty( $value ) ) {
			return;
		}

		// Handle array values (checkbox, select, etc.)
		if ( is_array( $value ) ) {
			$value = implode( ', ', array_map( 'wp_kses_post', $value ) );
		} elseif ( is_object( $value ) ) {
			return; 
		}

		echo wp_kses_post( (string) $value );
	}
}
