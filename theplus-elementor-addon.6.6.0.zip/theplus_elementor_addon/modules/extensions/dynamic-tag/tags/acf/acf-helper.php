<?php
/**
 * Shared ACF helpers for the Plus Addons dynamic tags.
 *
 * Discovery used to stop at the top level, so fields nested in an ACF Group never
 * appeared, and the object was resolved archive-first, so a loop card read the term.
 *
 * @link       https://posimyth.com/
 * @since      6.5.1
 *
 * @package    ThePlus
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'ThePlus_ACF_Tag_Helper' ) ) {

	/**
	 * Field discovery and value resolution shared by every Plus ACF dynamic tag.
	 *
	 * @since 6.5.1
	 */
	class ThePlus_ACF_Tag_Helper {

		/**
		 * Separator addressing a field nested in a Group, e.g. "meta_group/inner_image".
		 * Top level fields keep their plain ACF name, so saved values still work.
		 *
		 * @since 6.5.1
		 * @var string
		 */
		const PATH_SEPARATOR = '/';

		/**
		 * Field types that only structure the admin screen and hold no value.
		 *
		 * @since 6.5.1
		 * @var array
		 */
		const LAYOUT_TYPES = array( 'tab', 'accordion', 'message' );

		/**
		 * Container types whose children are addressable as a single value. Repeater and
		 * Flexible Content are excluded: their children only exist per row.
		 *
		 * @since 6.5.1
		 * @var array
		 */
		const NESTED_TYPES = array( 'group' );

		/**
		 * Per request memo, keyed by the requested types. Elementor registers controls on
		 * the front end too, once per rendered widget.
		 *
		 * @since 6.5.1
		 * @var array
		 */
		protected static $options_cache = array();

		/**
		 * Build an Elementor control 'groups' array of every ACF field of the given types.
		 *
		 * @since 6.5.1
		 *
		 * @param array $types ACF field types to collect, e.g. array( 'image' ).
		 *
		 * @return array Elementor SELECT control groups.
		 */
		public static function get_field_options( array $types ): array {

			if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
				return array();
			}

			$cache_key = implode( ',', $types );

			if ( isset( self::$options_cache[ $cache_key ] ) ) {
				return self::$options_cache[ $cache_key ];
			}

			$field_groups = acf_get_field_groups();

			if ( empty( $field_groups ) || ! is_array( $field_groups ) ) {
				return array();
			}

			$groups = array();

			foreach ( $field_groups as $field_group ) {

				if ( empty( $field_group['key'] ) || empty( $field_group['title'] ) ) {
					continue;
				}

				$fields = acf_get_fields( $field_group['key'] );

				if ( empty( $fields ) || ! is_array( $fields ) ) {
					continue;
				}

				$options = self::collect_fields( $fields, $types );

				if ( ! empty( $options ) ) {
					$groups[] = array(
						'label'   => esc_html( $field_group['title'] ),
						'options' => $options,
					);
				}
			}

			self::$options_cache[ $cache_key ] = $groups;

			return $groups;
		}

		/**
		 * Walk a field list, descending into Group fields, and collect matching entries.
		 *
		 * @since 6.5.1
		 *
		 * @param array  $fields       Fields from acf_get_fields() or a 'sub_fields' array.
		 * @param array  $types        ACF field types to collect.
		 * @param string $path_prefix  Accumulated parent path, empty at the top level.
		 * @param string $label_prefix Accumulated parent label, empty at the top level.
		 *
		 * @return array Map of stored value => human readable label.
		 */
		protected static function collect_fields( array $fields, array $types, string $path_prefix = '', string $label_prefix = '' ): array {

			$options = array();

			foreach ( $fields as $field ) {

				if ( empty( $field['type'] ) || in_array( $field['type'], self::LAYOUT_TYPES, true ) ) {
					continue;
				}

				if ( empty( $field['name'] ) || empty( $field['label'] ) ) {
					continue;
				}

				$path  = ( '' === $path_prefix ) ? $field['name'] : $path_prefix . self::PATH_SEPARATOR . $field['name'];
				$label = ( '' === $label_prefix ) ? $field['label'] : $label_prefix . ' → ' . $field['label'];

				if ( in_array( $field['type'], self::NESTED_TYPES, true ) ) {

					if ( ! empty( $field['sub_fields'] ) && is_array( $field['sub_fields'] ) ) {
						$options += self::collect_fields( $field['sub_fields'], $types, $path, $label );
					}

					continue;
				}

				if ( in_array( $field['type'], $types, true ) ) {
					$options[ $path ] = $label;
				}
			}

			return $options;
		}

		/**
		 * Resolve the object an ACF value should be read from.
		 *
		 * The rendered post wins whenever it differs from the queried post, which is the
		 * case inside a loop skin, an Elementor loop item or a per card popup template.
		 *
		 * @since 6.5.1
		 *
		 * @return mixed Post ID, WP_Term, "user_{id}" string, or false when nothing resolves.
		 */
		public static function get_object_id() {

			$rendered_post_id = absint( get_the_ID() );
			$queried_id       = absint( get_queried_object_id() );

			// Inside a loop / popup template the rendered post is not the queried object.
			if ( $rendered_post_id && $rendered_post_id !== $queried_id ) {
				return $rendered_post_id;
			}

			if ( is_tax() || is_category() || is_tag() ) {
				$term = get_queried_object();

				if ( $term instanceof WP_Term ) {
					return $term;
				}
			}

			if ( is_author() && $queried_id ) {
				return 'user_' . $queried_id;
			}

			if ( $rendered_post_id ) {
				return $rendered_post_id;
			}

			return $queried_id ? $queried_id : false;
		}

		/**
		 * Read an ACF value, following a Group path when the selector contains one.
		 *
		 * @since 6.5.1
		 *
		 * @param string $selector  Field name, or "parent/child" path for a nested field.
		 * @param mixed  $object_id Object to read from. Resolved automatically when null.
		 *
		 * @return mixed Field value, or null when it cannot be read.
		 */
		public static function get_value( string $selector, $object_id = null ) {

			if ( '' === $selector || ! function_exists( 'get_field' ) ) {
				return null;
			}

			if ( null === $object_id ) {
				$object_id = self::get_object_id();
			}

			if ( false === $object_id ) {
				return null;
			}

			$path = explode( self::PATH_SEPARATOR, $selector );
			$root = array_shift( $path );

			$value = get_field( $root, $object_id );

			foreach ( $path as $segment ) {

				if ( ! is_array( $value ) || ! array_key_exists( $segment, $value ) ) {
					return null;
				}

				$value = $value[ $segment ];
			}

			return $value;
		}

		/**
		 * Normalise any of ACF's image return formats into an Elementor image array.
		 *
		 * ACF returns an array, an attachment ID or a URL depending on the Return Format.
		 *
		 * @since 6.5.1
		 *
		 * @param mixed $image Raw ACF image value.
		 *
		 * @return array Elementor image array, empty when the value is unusable.
		 */
		public static function to_image_array( $image ): array {

			if ( is_array( $image ) && ! empty( $image['ID'] ) ) {
				return array(
					'id'  => (int) $image['ID'],
					'url' => isset( $image['url'] ) ? $image['url'] : wp_get_attachment_url( (int) $image['ID'] ),
				);
			}

			// A nested read can surface the WP style key instead of ACF's.
			if ( is_array( $image ) && ! empty( $image['id'] ) ) {
				return array(
					'id'  => (int) $image['id'],
					'url' => isset( $image['url'] ) ? $image['url'] : wp_get_attachment_url( (int) $image['id'] ),
				);
			}

			if ( is_numeric( $image ) ) {
				$url = wp_get_attachment_url( (int) $image );

				return $url ? array(
					'id'  => (int) $image,
					'url' => $url,
				) : array();
			}

			if ( is_string( $image ) && '' !== $image ) {
				$id = attachment_url_to_postid( $image );

				return array(
					'id'  => $id ? $id : null,
					'url' => $image,
				);
			}

			return array();
		}
	}
}
