<?php
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

wp_register_ability('tpaep/tpaep-blog-listout', [
'label' => __('Blog Listout (Pro)', 'theplus'),
    'description' => __('Adds The Plus "Blog Listout" widget (tp-blog-listout) to an Elementor container with full professional layouts and query options.', 'theplus'),
    'category' => 'tpae',
    'input_schema' => ['type' => 'object', 'properties' => [
        'post_id'        => ['type' => 'integer', 'description' => 'Elementor page/post ID'],
        'parent_id'      => ['type' => 'string',  'description' => 'Target Elementor container ID'],
        'position'       => ['type' => 'integer', 'description' => 'Insert position (-1 = append)', 'default' => -1],
        'blogs_post_listing' => ['type' => 'string', 'description' => 'Post Listing Types', 'enum' => ['archive_listing', 'page_listing', 'related_post']],
        'related_post_by' => ['type' => 'string', 'description' => 'Related Post Type', 'enum' => ['category', 'tags', 'both']],
        'style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'smart-loop-builder']],
        'layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['grid', 'masonry', 'metro', 'carousel']],
        'content_alignment' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['left', 'center']],
        'content_alignment_3' => ['type' => 'string', 'description' => 'Content Alignment', 'enum' => ['left', 'right', 'left-right']],
        'style_layout' => ['type' => 'string', 'description' => 'Style Layout', 'enum' => ['style-1', 'style-2']],
        'column_min_height' => ['type' => 'object', 'description' => 'Minimum Height'],
        'content_html' => ['type' => 'string', 'description' => 'HTML'],
        'content_css' => ['type' => 'string', 'description' => 'CSS'],
        'display_posts' => ['type' => 'number', 'description' => 'Maximum Post Display'],
        'post_offset' => ['type' => 'number', 'description' => 'Offset Posts'],
        'post_category' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Select Category (values are site-specific; read the live list with the tpae/tpae-widget-schema ability)'],
        'post_tags' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Select Tags (values are site-specific; read the live list with the tpae/tpae-widget-schema ability)'],
        'ex_cat' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Exclude Category (values are site-specific; read the live list with the tpae/tpae-widget-schema ability)'],
        'ex_tag' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Exclude Tags (values are site-specific; read the live list with the tpae/tpae-widget-schema ability)'],
        'post_order_by' => ['type' => 'string', 'description' => 'Order By', 'enum' => ['none', 'ID', 'author', 'title', 'name', 'date', 'modified', 'rand', 'comment_count', 'menu_order']],
        'post_order' => ['type' => 'string', 'description' => 'Order', 'enum' => ['DESC', 'ASC']],
        'desktop_column' => ['type' => 'string', 'description' => 'Desktop Column', 'enum' => ['2', '3', '4', '5', '6', '12']],
        'tablet_column' => ['type' => 'string', 'description' => 'Tablet Column', 'enum' => ['2', '3', '4', '5', '6', '12']],
        'mobile_column' => ['type' => 'string', 'description' => 'Mobile Column', 'enum' => ['2', '3', '4', '5', '6', '12']],
        'metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6']],
        'metro_style_3' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'custom']],
        'metro_custom_col_3' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_4' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['style-1', 'style-2', 'style-3', 'custom']],
        'metro_custom_col_4' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_5' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['style-1', 'custom']],
        'metro_custom_col_5' => ['type' => 'string', 'description' => 'Custom Layout'],
        'metro_style_6' => ['type' => 'string', 'description' => 'Metro Style', 'enum' => ['style-1', 'custom']],
        'metro_custom_col_6' => ['type' => 'string', 'description' => 'Custom Layout'],
        'responsive_tablet_metro' => ['type' => 'string', 'description' => 'Tablet Responsive', 'enum' => ['yes', 'no']],
        'tablet_metro_column' => ['type' => 'string', 'description' => 'Metro Column', 'enum' => ['3', '4', '5', '6']],
        'tablet_metro_style_3' => ['type' => 'string', 'description' => 'Tablet Metro Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'custom']],
        'metro_custom_col_tab' => ['type' => 'string', 'description' => 'Custom Layout'],
        'columns_gap' => ['type' => 'object', 'description' => 'Column Spacing'],
        'filter_category' => ['type' => 'string', 'description' => 'Category Wise Filter', 'enum' => ['yes', 'no']],
        'filter_category_align' => ['type' => 'string', 'description' => 'Filter Alignment', 'enum' => ['left', 'center', 'right']],
        'TaxonomyType' => ['type' => 'string', 'description' => 'Select Taxonomy (values are site-specific; read the live list with the tpae/tpae-widget-schema ability)'],
        'filter_type' => ['type' => 'string', 'description' => 'Filter Type', 'enum' => ['normal', 'ajax_base']],
        'filter_search_type' => ['type' => 'string', 'description' => 'Search Type', 'enum' => ['term_id', 'slug']],
        'all_filter_category_switch' => ['type' => 'string', 'description' => 'All Filter', 'enum' => ['yes', 'no']],
        'all_filter_category' => ['type' => 'string', 'description' => 'Category Text'],
        'filter_style' => ['type' => 'string', 'description' => 'Category Filter Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4']],
        'filter_hover_style' => ['type' => 'string', 'description' => 'Filter Hover Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4']],
        'post_extra_option' => ['type' => 'string', 'description' => 'Post Loading Options', 'enum' => ['none', 'pagination', 'load_more', 'lazy_load']],
        'pagination_next' => ['type' => 'string', 'description' => 'Pagination Next'],
        'pagination_prev' => ['type' => 'string', 'description' => 'Pagination Previous'],
        'pagination_color' => ['type' => 'string', 'description' => 'Pagination Text Color'],
        'pagination_hover_color' => ['type' => 'string', 'description' => 'Pagination Hover Color'],
        'load_more_btn_text' => ['type' => 'string', 'description' => 'Button Text'],
        'tp_loading_text' => ['type' => 'string', 'description' => 'Loading Text'],
        'loaded_posts_text' => ['type' => 'string', 'description' => 'All Posts Loaded Text'],
        'load_more_post' => ['type' => 'number', 'description' => 'More posts on click/scroll'],
        'load_more_border' => ['type' => 'string', 'description' => 'Load More Border', 'enum' => ['yes', 'no']],
        'load_more_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['solid', 'dashed', 'dotted', 'groove', 'inset', 'outset', 'ridge']],
        'load_more_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'load_more_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'load_more_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'load_more_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'load_more_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'load_more_color' => ['type' => 'string', 'description' => 'Text Color'],
        'loaded_posts_color' => ['type' => 'string', 'description' => 'Loaded Post Text Color'],
        'loading_spin_color' => ['type' => 'string', 'description' => 'Color'],
        'loading_spin_size' => ['type' => 'object', 'description' => 'Size'],
        'loading_spin_border_size' => ['type' => 'object', 'description' => 'Border Size'],
        'load_more_color_hover' => ['type' => 'string', 'description' => 'Text Hover Color'],
        'loading_options' => ['type' => 'string', 'description' => 'Loading Options', 'enum' => ['default', 'skeleton']],
        'tp_list_preloader' => ['type' => 'string', 'description' => 'Preloader', 'enum' => ['yes', 'no']],
        'tp_list_preloader_hw' => ['type' => 'object', 'description' => 'Width'],
        'tp_list_preloader_size' => ['type' => 'object', 'description' => 'Border Size'],
        'tp_list_preloader_color' => ['type' => 'string', 'description' => 'Color'],
        'display_title_limit' => ['type' => 'string', 'description' => 'Title Limit', 'enum' => ['yes', 'no']],
        'display_title_by' => ['type' => 'string', 'description' => 'Limit on', 'enum' => ['char', 'word']],
        'display_title_input' => ['type' => 'number', 'description' => 'Title Count'],
        'display_title_3_dots' => ['type' => 'string', 'description' => 'Display Dots', 'enum' => ['yes', 'no']],
        'filter_url' => ['type' => 'string', 'description' => 'URL Enable', 'enum' => ['yes', 'no']],
        'post_title_tag' => ['type' => 'string', 'description' => 'Title Tag', 'enum' => ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'p', 'span']],
        'featured_image_type' => ['type' => 'string', 'description' => 'Featured Image Type', 'enum' => ['full', 'grid', 'custom']],
        'title_desc_word_break' => ['type' => 'string', 'description' => 'Word Break', 'enum' => ['break-all', 'keep-all', 'normal']],
        'display_post_category' => ['type' => 'string', 'description' => 'Display Category Post', 'enum' => ['yes', 'no']],
        'post_category_style' => ['type' => 'string', 'description' => 'Style', 'enum' => ['style-1', 'style-2']],
        'display_post_category_all' => ['type' => 'string', 'description' => 'Display All Category', 'enum' => ['yes', 'no']],
        'display_excerpt' => ['type' => 'string', 'description' => 'Display Content', 'enum' => ['yes', 'no']],
        'post_excerpt_count' => ['type' => 'number', 'description' => 'Count'],
        'show_post_date' => ['type' => 'string', 'description' => 'Date & Time', 'enum' => ['yes', 'no']],
        'show_post_author' => ['type' => 'string', 'description' => 'Author Name', 'enum' => ['yes', 'no']],
        'show_read_time' => ['type' => 'string', 'description' => 'Read Time', 'enum' => ['yes', 'no']],
        'display_thumbnail' => ['type' => 'string', 'description' => 'Display Image Size', 'enum' => ['yes', 'no']],
        'display_post_meta' => ['type' => 'string', 'description' => 'Display Post Meta', 'enum' => ['yes', 'no']],
        'post_meta_tag_style' => ['type' => 'string', 'description' => 'Post Meta Tag', 'enum' => ['style-1', 'style-2', 'style-3']],
        'author_prefix' => ['type' => 'string', 'description' => 'Author Prefix'],
        'display_post_meta_date' => ['type' => 'string', 'description' => 'Display Date', 'enum' => ['yes', 'no']],
        'date_type' => ['type' => 'string', 'description' => 'Type', 'enum' => ['post_published', 'post_modified']],
        'display_post_meta_author' => ['type' => 'string', 'description' => 'Display Author', 'enum' => ['yes', 'no']],
        'display_post_meta_author_pic' => ['type' => 'string', 'description' => 'Display Author Picture', 'enum' => ['yes', 'no']],
        'display_button' => ['type' => 'string', 'description' => 'Button', 'enum' => ['yes', 'no']],
        'button_style' => ['type' => 'string', 'description' => 'Button Style', 'enum' => ['style-7', 'style-8', 'style-9']],
        'button_text' => ['type' => 'string', 'description' => 'Text'],
        'button_icon_style' => ['type' => 'string', 'description' => 'Icon Font', 'enum' => ['', 'font_awesome', 'icon_mind']],
        'button_icon' => ['type' => 'string', 'description' => 'Icon'],
        'button_icons_mind' => ['type' => 'string', 'description' => 'Icon Library', 'enum' => ['', 'iconsmind-A-Z', 'iconsmind-Aa', 'iconsmind-Add-Bag', 'iconsmind-Add-Basket', 'iconsmind-Add-Cart', 'iconsmind-Add-File', 'iconsmind-Add-SpaceAfterParagraph', 'iconsmind-Add-SpaceBeforeParagraph', 'iconsmind-Add-User', 'iconsmind-Add-UserStar', 'iconsmind-Add-Window', 'iconsmind-Add', 'iconsmind-Address-Book', 'iconsmind-Address-Book2', 'iconsmind-Administrator', 'iconsmind-Aerobics-2', 'iconsmind-Aerobics-3', 'iconsmind-Aerobics', 'iconsmind-Affiliate', 'iconsmind-Aim', 'iconsmind-Air-Balloon', 'iconsmind-Airbrush', 'iconsmind-Airship', 'iconsmind-Alarm-Clock', 'iconsmind-Alarm-Clock2', 'iconsmind-Alarm', 'iconsmind-Alien-2', 'iconsmind-Alien', 'iconsmind-Aligator', 'iconsmind-Align-Center', 'iconsmind-Align-JustifyAll', 'iconsmind-Align-JustifyCenter', 'iconsmind-Align-JustifyLeft', 'iconsmind-Align-JustifyRight', 'iconsmind-Align-Left', 'iconsmind-Align-Right', 'iconsmind-Alpha', 'iconsmind-Ambulance', 'iconsmind-AMX', 'iconsmind-Anchor-2', 'iconsmind-Anchor', 'iconsmind-Android-Store', 'iconsmind-Android', 'iconsmind-Angel-Smiley', 'iconsmind-Angel', 'iconsmind-Angry', 'iconsmind-Apple-Bite', 'iconsmind-Apple-Store', 'iconsmind-Apple', 'iconsmind-Approved-Window', 'iconsmind-Aquarius-2', 'iconsmind-Aquarius', 'iconsmind-Archery-2', 'iconsmind-Archery', 'iconsmind-Argentina', 'iconsmind-Aries-2', 'iconsmind-Aries', 'iconsmind-Army-Key', 'iconsmind-Arrow-Around', 'iconsmind-Arrow-Back3', 'iconsmind-Arrow-Back', 'iconsmind-Arrow-Back2', 'iconsmind-Arrow-Barrier', 'iconsmind-Arrow-Circle', 'iconsmind-Arrow-Cross', 'iconsmind-Arrow-Down', 'iconsmind-Arrow-Down2', 'iconsmind-Arrow-Down3', 'iconsmind-Arrow-DowninCircle', 'iconsmind-Arrow-Fork', 'iconsmind-Arrow-Forward', 'iconsmind-Arrow-Forward2', 'iconsmind-Arrow-From', 'iconsmind-Arrow-Inside', 'iconsmind-Arrow-Inside45', 'iconsmind-Arrow-InsideGap', 'iconsmind-Arrow-InsideGap45', 'iconsmind-Arrow-Into', 'iconsmind-Arrow-Join', 'iconsmind-Arrow-Junction', 'iconsmind-Arrow-Left', 'iconsmind-Arrow-Left2', 'iconsmind-Arrow-LeftinCircle', 'iconsmind-Arrow-Loop', 'iconsmind-Arrow-Merge', 'iconsmind-Arrow-Mix', 'iconsmind-Arrow-Next', 'iconsmind-Arrow-OutLeft', 'iconsmind-Arrow-OutRight', 'iconsmind-Arrow-Outside', 'iconsmind-Arrow-Outside45', 'iconsmind-Arrow-OutsideGap', 'iconsmind-Arrow-OutsideGap45', 'iconsmind-Arrow-Over', 'iconsmind-Arrow-Refresh', 'iconsmind-Arrow-Refresh2', 'iconsmind-Arrow-Right', 'iconsmind-Arrow-Right2', 'iconsmind-Arrow-RightinCircle', 'iconsmind-Arrow-Shuffle', 'iconsmind-Arrow-Squiggly', 'iconsmind-Arrow-Through', 'iconsmind-Arrow-To', 'iconsmind-Arrow-TurnLeft', 'iconsmind-Arrow-TurnRight', 'iconsmind-Arrow-Up', 'iconsmind--Arrow-Up2', 'iconsmind-Arrow-Up3', 'iconsmind-Arrow-UpinCircle', 'iconsmind-Arrow-XLeft', 'iconsmind-Arrow-XRight', 'iconsmind-Ask', 'iconsmind-Assistant', 'iconsmind-Astronaut', 'iconsmind-At-Sign', 'iconsmind-ATM', 'iconsmind-Atom', 'iconsmind-Audio', 'iconsmind-Auto-Flash', 'iconsmind-Autumn', 'iconsmind-Baby-Clothes', 'iconsmind-Baby-Clothes2', 'iconsmind-Baby-Cry', 'iconsmind-Baby', 'iconsmind-Back2', 'iconsmind-Back-Media', 'iconsmind-Back-Music', 'iconsmind-Back', 'iconsmind-Background', 'iconsmind-Bacteria', 'iconsmind-Bag-Coins', 'iconsmind-Bag-Items', 'iconsmind-Bag-Quantity', 'iconsmind-Bag', 'iconsmind-Bakelite', 'iconsmind-Ballet-Shoes', 'iconsmind-Balloon', 'iconsmind-Banana', 'iconsmind-Band-Aid', 'iconsmind-Bank', 'iconsmind-Bar-Chart', 'iconsmind-Bar-Chart2', 'iconsmind-Bar-Chart3', 'iconsmind-Bar-Chart4', 'iconsmind-Bar-Chart5', 'iconsmind-Bar-Code', 'iconsmind-Barricade-2', 'iconsmind-Barricade', 'iconsmind-Baseball', 'iconsmind-Basket-Ball', 'iconsmind-Basket-Coins', 'iconsmind-Basket-Items', 'iconsmind-Basket-Quantity', 'iconsmind-Bat-2', 'iconsmind-Bat', 'iconsmind-Bathrobe', 'iconsmind-Batman-Mask', 'iconsmind-Battery-0', 'iconsmind-Battery-25', 'iconsmind-Battery-50', 'iconsmind-Battery-75', 'iconsmind-Battery-100', 'iconsmind-Battery-Charge', 'iconsmind-Bear', 'iconsmind-Beard-2', 'iconsmind-Beard-3', 'iconsmind-Beard', 'iconsmind-Bebo', 'iconsmind-Bee', 'iconsmind-Beer-Glass', 'iconsmind-Beer', 'iconsmind-Bell-2', 'iconsmind-Bell', 'iconsmind-Belt-2', 'iconsmind-Belt-3', 'iconsmind-Belt', 'iconsmind-Berlin-Tower', 'iconsmind-Beta', 'iconsmind-Betvibes', 'iconsmind-Bicycle-2', 'iconsmind-Bicycle-3', 'iconsmind-Bicycle', 'iconsmind-Big-Bang', 'iconsmind-Big-Data', 'iconsmind-Bike-Helmet', 'iconsmind-Bikini', 'iconsmind-Bilk-Bottle2', 'iconsmind-Billing', 'iconsmind-Bing', 'iconsmind-Binocular', 'iconsmind-Bio-Hazard', 'iconsmind-Biotech', 'iconsmind-Bird-DeliveringLetter', 'iconsmind-Bird', 'iconsmind-Birthday-Cake', 'iconsmind-Bisexual', 'iconsmind-Bishop', 'iconsmind-Bitcoin', 'iconsmind-Black-Cat', 'iconsmind-Blackboard', 'iconsmind-Blinklist', 'iconsmind-Block-Cloud', 'iconsmind-Block-Window', 'iconsmind-Blogger', 'iconsmind-Blood', 'iconsmind-Blouse', 'iconsmind-Blueprint', 'iconsmind-Board', 'iconsmind-Bodybuilding', 'iconsmind-Bold-Text', 'iconsmind-Bone', 'iconsmind-Bones', 'iconsmind-Book', 'iconsmind-Bookmark', 'iconsmind-Books-2', 'iconsmind-Books', 'iconsmind-Boom', 'iconsmind-Boot-2', 'iconsmind-Boot', 'iconsmind-Bottom-ToTop', 'iconsmind-Bow-2', 'iconsmind-Bow-3', 'iconsmind-Bow-4', 'iconsmind-Bow-5', 'iconsmind-Bow-6', 'iconsmind-Bow', 'iconsmind-Bowling-2', 'iconsmind-Bowling', 'iconsmind-Box2', 'iconsmind-Box-Close', 'iconsmind-Box-Full', 'iconsmind-Box-Open', 'iconsmind-Box-withFolders', 'iconsmind-Box', 'iconsmind-Boy', 'iconsmind-Bra', 'iconsmind-Brain-2', 'iconsmind-Brain-3', 'iconsmind-Brain', 'iconsmind-Brazil', 'iconsmind-Bread-2', 'iconsmind-Bread', 'iconsmind-Bridge', 'iconsmind-Brightkite', 'iconsmind-Broke-Link2', 'iconsmind-Broken-Link', 'iconsmind-Broom', 'iconsmind-Brush', 'iconsmind-Bucket', 'iconsmind-Bug', 'iconsmind-Building', 'iconsmind-Bulleted-List', 'iconsmind-Bus-2', 'iconsmind-Bus', 'iconsmind-Business-Man', 'iconsmind-Business-ManWoman', 'iconsmind-Business-Mens', 'iconsmind-Business-Woman', 'iconsmind-Butterfly', 'iconsmind-Button', 'iconsmind-Cable-Car', 'iconsmind-Cake', 'iconsmind-Calculator-2', 'iconsmind-Calculator-3', 'iconsmind-Calculator', 'iconsmind-Calendar-2', 'iconsmind-Calendar-3', 'iconsmind-Calendar-4', 'iconsmind-Calendar-Clock', 'iconsmind-Calendar', 'iconsmind-Camel', 'iconsmind-Camera-2', 'iconsmind-Camera-3', 'iconsmind-Camera-4', 'iconsmind-Camera-5', 'iconsmind-Camera-Back', 'iconsmind-Camera', 'iconsmind-Can-2', 'iconsmind-Can', 'iconsmind-Canada', 'iconsmind-Cancer-2', 'iconsmind-Cancer-3', 'iconsmind-Cancer', 'iconsmind-Candle', 'iconsmind-Candy-Cane', 'iconsmind-Candy', 'iconsmind-Cannon', 'iconsmind-Cap-2', 'iconsmind-Cap-3', 'iconsmind-Cap-Smiley', 'iconsmind-Cap', 'iconsmind-Capricorn-2', 'iconsmind-Capricorn', 'iconsmind-Car-2', 'iconsmind-Car-3', 'iconsmind-Car-Coins', 'iconsmind-Car-Items', 'iconsmind-Car-Wheel', 'iconsmind-Car', 'iconsmind-Cardigan', 'iconsmind-Cardiovascular', 'iconsmind-Cart-Quantity', 'iconsmind-Casette-Tape', 'iconsmind-Cash-Register', 'iconsmind-Cash-register2', 'iconsmind-Castle', 'iconsmind-Cat', 'iconsmind-Cathedral', 'iconsmind-Cauldron', 'iconsmind-CD-2', 'iconsmind-CD-Cover', 'iconsmind-CD', 'iconsmind-Cello', 'iconsmind-Celsius', 'iconsmind-Chacked-Flag', 'iconsmind-Chair', 'iconsmind-Charger', 'iconsmind-Check-2', 'iconsmind-Check', 'iconsmind-Checked-User', 'iconsmind-Checkmate', 'iconsmind-Checkout-Bag', 'iconsmind-Checkout-Basket', 'iconsmind-Checkout', 'iconsmind-Cheese', 'iconsmind-Cheetah', 'iconsmind-Chef-Hat', 'iconsmind-Chef-Hat2', 'iconsmind-Chef', 'iconsmind-Chemical-2', 'iconsmind-Chemical-3', 'iconsmind-Chemical 4', 'iconsmind-Chemical-5', 'iconsmind-Chemical', 'iconsmind-Chess-Board', 'iconsmind-Chess', 'iconsmind-Chicken', 'iconsmind-Chile', 'iconsmind-Chimney', 'iconsmind-China', 'iconsmind-Chinese-Temple', 'iconsmind-Chip', 'iconsmind-Chopsticks-2', 'iconsmind-Chopsticks', 'iconsmind-Christmas-Ball', 'iconsmind-Christmas-Bell', 'iconsmind-Christmas-Candle', 'iconsmind-Christmas-Hat', 'iconsmind-Christmas-Sleigh', 'iconsmind-Christmas-Snowman', 'iconsmind-Christmas-Sock', 'iconsmind-Christmas-Tree', 'iconsmind-Christmas', 'iconsmind-Chrome', 'iconsmind-Chrysler-Building', 'iconsmind-Cinema', 'iconsmind-Circular-Point', 'iconsmind-City-Hall', 'iconsmind-Clamp', 'iconsmind-Clapperboard-Close', 'iconsmind-Clapperboard-Open', 'iconsmind-Claps', 'iconsmind-Clef', 'iconsmind-Clinic', 'iconsmind-Clock-2', 'iconsmind-Clock-3', 'iconsmind-Clock-4', 'iconsmind-Clock-Back', 'iconsmind-Clock-Forward', 'iconsmind-Clock', 'iconsmind-Close-Window', 'iconsmind-Close', 'iconsmind-Clothing-Store', 'iconsmind-Cloud--', 'iconsmind-Cloud-', 'iconsmind-Cloud-Camera', 'iconsmind-Cloud-Computer', 'iconsmind-Cloud-Email', 'iconsmind-Cloud-Hail', 'iconsmind-Cloud-Laptop', 'iconsmind-Cloud-Lock', 'iconsmind-Cloud-Moon', 'iconsmind-Cloud-Music', 'iconsmind-Cloud-Picture', 'iconsmind-Cloud-Rain', 'iconsmind-Cloud-Remove', 'iconsmind-Cloud-Secure', 'iconsmind-Cloud-Settings', 'iconsmind-Cloud-Smartphone', 'iconsmind-Cloud-Snow', 'iconsmind-Cloud-Sun', 'iconsmind-Cloud-Tablet', 'iconsmind-Cloud-Video', 'iconsmind-Cloud-Weather', 'iconsmind-Cloud', 'iconsmind-Clouds-Weather', 'iconsmind-Clouds', 'iconsmind-Clown', 'iconsmind-CMYK', 'iconsmind-Coat', 'iconsmind-Cocktail', 'iconsmind-Coconut', 'iconsmind-Code-Window', 'iconsmind-Coding', 'iconsmind-Coffee-2', 'iconsmind-Coffee-Bean', 'iconsmind-Coffee-Machine', 'iconsmind-Coffee-toGo', 'iconsmind-Coffee', 'iconsmind-Coffin', 'iconsmind-Coin', 'iconsmind-Coins-2', 'iconsmind-Coins-3', 'iconsmind-Coins', 'iconsmind-Colombia', 'iconsmind-Colosseum', 'iconsmind-Column-2', 'iconsmind-Column-3', 'iconsmind-Column', 'iconsmind-Comb-2', 'iconsmind-Comb', 'iconsmind-Communication-Tower', 'iconsmind-Communication-Tower2', 'iconsmind-Compass-2', 'iconsmind-Compass-3', 'iconsmind-Compass-4', 'iconsmind-Compass-Rose', 'iconsmind-Compass', 'iconsmind-Computer-2', 'iconsmind-Computer-3', 'iconsmind-Computer-Secure', 'iconsmind-Computer', 'iconsmind-Conference', 'iconsmind-Confused', 'iconsmind-Conservation', 'iconsmind-Consulting', 'iconsmind-Contrast', 'iconsmind-Control-2', 'iconsmind-Control', 'iconsmind-Cookie-Man', 'iconsmind-Cookies', 'iconsmind-Cool-Guy', 'iconsmind-Cool', 'iconsmind-Copyright', 'iconsmind-Costume', 'iconsmind-Couple-Sign', 'iconsmind-Cow', 'iconsmind-CPU', 'iconsmind-Crane', 'iconsmind-Cranium', 'iconsmind-Credit-Card', 'iconsmind-Credit-Card2', 'iconsmind-Credit-Card3', 'iconsmind-Cricket', 'iconsmind-Criminal', 'iconsmind-Croissant', 'iconsmind-Crop-2', 'iconsmind-Crop-3', 'iconsmind-Crown-2', 'iconsmind-Crown', 'iconsmind-Crying', 'iconsmind-Cube-Molecule', 'iconsmind-Cube-Molecule2', 'iconsmind-Cupcake', 'iconsmind-Cursor-Click', 'iconsmind-Cursor-Click2', 'iconsmind-Cursor-Move', 'iconsmind-Cursor-Move2', 'iconsmind-Cursor-Select', 'iconsmind-Cursor', 'iconsmind-D-Eyeglasses', 'iconsmind-D-Eyeglasses2', 'iconsmind-Dam', 'iconsmind-Danemark', 'iconsmind-Danger-2', 'iconsmind-Danger', 'iconsmind-Dashboard', 'iconsmind-Data-Backup', 'iconsmind-Data-Block', 'iconsmind-Data-Center', 'iconsmind-Data-Clock', 'iconsmind-Data-Cloud', 'iconsmind-Data-Compress', 'iconsmind-Data-Copy', 'iconsmind-Data-Download', 'iconsmind-Data-Financial', 'iconsmind-Data-Key', 'iconsmind-Data-Lock', 'iconsmind-Data-Network', 'iconsmind-Data-Password', 'iconsmind-Data-Power', 'iconsmind-Data-Refresh', 'iconsmind-Data-Save', 'iconsmind-Data-Search', 'iconsmind-Data-Security', 'iconsmind-Data-Settings', 'iconsmind-Data-Sharing', 'iconsmind-Data-Shield', 'iconsmind-Data-Signal', 'iconsmind-Data-Storage', 'iconsmind-Data-Stream', 'iconsmind-Data-Transfer', 'iconsmind-Data-Unlock', 'iconsmind-Data-Upload', 'iconsmind-Data-Yes', 'iconsmind-Data', 'iconsmind-David-Star', 'iconsmind-Daylight', 'iconsmind-Death', 'iconsmind-Debian', 'iconsmind-Dec', 'iconsmind-Decrase-Inedit', 'iconsmind-Deer-2', 'iconsmind-Deer', 'iconsmind-Delete-File', 'iconsmind-Delete-Window', 'iconsmind-Delicious', 'iconsmind-Depression', 'iconsmind-Deviantart', 'iconsmind-Device-SyncwithCloud', 'iconsmind-Diamond', 'iconsmind-Dice-2', 'iconsmind-Dice', 'iconsmind-Digg', 'iconsmind-Digital-Drawing', 'iconsmind-Diigo', 'iconsmind-Dinosaur', 'iconsmind-Diploma-2', 'iconsmind-Diploma', 'iconsmind-Direction-East', 'iconsmind-Direction-North', 'iconsmind-Direction-South', 'iconsmind-Direction-West', 'iconsmind-Director', 'iconsmind-Disk', 'iconsmind-Dj', 'iconsmind-DNA-2', 'iconsmind-DNA-Helix', 'iconsmind-DNA', 'iconsmind-Doctor', 'iconsmind-Dog', 'iconsmind-Dollar-Sign', 'iconsmind-Dollar-Sign2', 'iconsmind-Dollar', 'iconsmind-Dolphin', 'iconsmind-Domino', 'iconsmind-Door-Hanger', 'iconsmind-Door', 'iconsmind-Doplr', 'iconsmind-Double-Circle', 'iconsmind-Double-Tap', 'iconsmind-Doughnut', 'iconsmind-Dove', 'iconsmind-Down-2', 'iconsmind-Down-3', 'iconsmind-Down-4', 'iconsmind-Down', 'iconsmind-Download-2', 'iconsmind-Download-fromCloud', 'iconsmind-Download-Window', 'iconsmind-Download', 'iconsmind-Downward', 'iconsmind-Drag-Down', 'iconsmind-Drag-Left', 'iconsmind-Drag-Right', 'iconsmind-Drag-Up', 'iconsmind-Drag', 'iconsmind-Dress', 'iconsmind-Drill-2', 'iconsmind-Drill', 'iconsmind-Drop', 'iconsmind-Dropbox', 'iconsmind-Drum', 'iconsmind-Dry', 'iconsmind-Duck', 'iconsmind-Dumbbell', 'iconsmind-Duplicate-Layer', 'iconsmind-Duplicate-Window', 'iconsmind-DVD', 'iconsmind-Eagle', 'iconsmind-Ear', 'iconsmind-Earphones-2', 'iconsmind-Earphones', 'iconsmind-Eci-Icon', 'iconsmind-Edit-Map', 'iconsmind-Edit', 'iconsmind-Eggs', 'iconsmind-Egypt', 'iconsmind-Eifel-Tower', 'iconsmind-eject-2', 'iconsmind-Eject', 'iconsmind-El-Castillo', 'iconsmind-Elbow', 'iconsmind-Electric-Guitar', 'iconsmind-Electricity', 'iconsmind-Elephant', 'iconsmind-Email', 'iconsmind-Embassy', 'iconsmind-Empire-StateBuilding', 'iconsmind-Empty-Box', 'iconsmind-End2', 'iconsmind-End-2', 'iconsmind-End', 'iconsmind-Endways', 'iconsmind-Engineering', 'iconsmind-Envelope-2', 'iconsmind-Envelope', 'iconsmind-Environmental-2', 'iconsmind-Environmental-3', 'iconsmind-Environmental', 'iconsmind-Equalizer', 'iconsmind-Eraser-2', 'iconsmind-Eraser-3', 'iconsmind-Eraser', 'iconsmind-Error-404Window', 'iconsmind-Euro-Sign', 'iconsmind-Euro-Sign2', 'iconsmind-Euro', 'iconsmind-Evernote', 'iconsmind-Evil', 'iconsmind-Explode', 'iconsmind-Eye-2', 'iconsmind-Eye-Blind', 'iconsmind-Eye-Invisible', 'iconsmind-Eye-Scan', 'iconsmind-Eye-Visible', 'iconsmind-Eye', 'iconsmind-Eyebrow-2', 'iconsmind-Eyebrow-3', 'iconsmind-Eyebrow', 'iconsmind-Eyeglasses-Smiley', 'iconsmind-Eyeglasses Smiley2', 'iconsmind-Face-Style', 'iconsmind-Face-Style2', 'iconsmind-Face-Style3', 'iconsmind-Face-Style4', 'iconsmind-Face-Style5', 'iconsmind-Face-Style6', 'iconsmind-Facebook-2', 'iconsmind-Facebook', 'iconsmind-Factory-2', 'iconsmind-Factory', 'iconsmind-Fahrenheit', 'iconsmind-Family-Sign', 'iconsmind-Fan', 'iconsmind-Farmer', 'iconsmind-Fashion', 'iconsmind-Favorite-Window', 'iconsmind-Fax', 'iconsmind-Feather', 'iconsmind-Feedburner', 'iconsmind-Female-2', 'iconsmind-Female-Sign', 'iconsmind-Female', 'iconsmind-File-Block', 'iconsmind-File-Bookmark', 'iconsmind-File-Chart', 'iconsmind-File-Clipboard', 'iconsmind-File-ClipboardFileText', 'iconsmind-File-ClipboardTextImage', 'iconsmind-File-Cloud', 'iconsmind-File-Copy', 'iconsmind-File-Copy2', 'iconsmind-File-CSV', 'iconsmind-File-Download', 'iconsmind-File-Edit', 'iconsmind-File-Excel', 'iconsmind-File-Favorite', 'iconsmind-File-Fire', 'iconsmind-File-Graph', 'iconsmind-File-Hide', 'iconsmind-File-Horizontal', 'iconsmind-File-HorizontalText', 'iconsmind-File-HTML', 'iconsmind-File-JPG', 'iconsmind-File-Link', 'iconsmind-File-Loading', 'iconsmind-File-Lock', 'iconsmind-File-Love', 'iconsmind-File-Music', 'iconsmind-File-Network', 'iconsmind-File-Pictures', 'iconsmind-File-Pie', 'iconsmind-File-Presentation', 'iconsmind-File-Refresh', 'iconsmind-File-Search', 'iconsmind-File-Settings', 'iconsmind-File-Share', 'iconsmind-File-TextImage', 'iconsmind-File-Trash', 'iconsmind-File-TXT', 'iconsmind-File-Upload', 'iconsmind-File-Video', 'iconsmind-File-Word', 'iconsmind-File-Zip', 'iconsmind-File', 'iconsmind-Files', 'iconsmind-Film-Board', 'iconsmind-Film-Cartridge', 'iconsmind-Film-Strip', 'iconsmind-Film-Video', 'iconsmind-Film', 'iconsmind-Filter-2', 'iconsmind-Filter', 'iconsmind-Financial', 'iconsmind-Find-User', 'iconsmind-Finger-DragFourSides', 'iconsmind-Finger-DragTwoSides', 'iconsmind-Finger-Print', 'iconsmind-Finger', 'iconsmind-Fingerprint-2', 'iconsmind-Fingerprint', 'iconsmind-Fire-Flame', 'iconsmind-Fire-Flame2', 'iconsmind-Fire-Hydrant', 'iconsmind-Fire-Staion', 'iconsmind-Firefox', 'iconsmind-Firewall', 'iconsmind-First-Aid', 'iconsmind-First', 'iconsmind-Fish-Food', 'iconsmind-Fish', 'iconsmind-Fit-To', 'iconsmind-Fit-To2', 'iconsmind-Five-Fingers', 'iconsmind-Five-FingersDrag', 'iconsmind-Five-FingersDrag2', 'iconsmind-Five-FingersTouch', 'iconsmind-Flag-2', 'iconsmind-Flag-3', 'iconsmind-Flag-4', 'iconsmind-Flag-5', 'iconsmind-Flag-6', 'iconsmind-Flag', 'iconsmind-Flamingo', 'iconsmind-Flash-2', 'iconsmind-Flash-Video', 'iconsmind-Flash', 'iconsmind-Flashlight', 'iconsmind-Flask-2', 'iconsmind-Flask', 'iconsmind-Flick', 'iconsmind-Flickr', 'iconsmind-Flowerpot', 'iconsmind-Fluorescent', 'iconsmind-Fog-Day', 'iconsmind-Fog-Night', 'iconsmind-Folder-Add', 'iconsmind-Folder-Archive', 'iconsmind-Folder-Binder', 'iconsmind-Folder-Binder2', 'iconsmind-Folder-Block', 'iconsmind-Folder-Bookmark', 'iconsmind-Folder-Close', 'iconsmind-Folder-Cloud', 'iconsmind-Folder-Delete', 'iconsmind-Folder-Download', 'iconsmind-Folder-Edit', 'iconsmind-Folder-Favorite', 'iconsmind-Folder-Fire', 'iconsmind-Folder-Hide', 'iconsmind-Folder-Link', 'iconsmind-Folder-Loading', 'iconsmind-Folder-Lock', 'iconsmind-Folder-Love', 'iconsmind-Folder-Music', 'iconsmind-Folder-Network', 'iconsmind-Folder-Open', 'iconsmind-Folder-Open2', 'iconsmind-Folder-Organizing', 'iconsmind-Folder-Pictures', 'iconsmind-Folder-Refresh', 'iconsmind-Folder-Remove', 'iconsmind-Folder-Search', 'iconsmind-Folder-Settings', 'iconsmind-Folder-Share', 'iconsmind-Folder-Trash', 'iconsmind-Folder-Upload', 'iconsmind-Folder-Video', 'iconsmind-Folder-WithDocument', 'iconsmind-Folder-Zip', 'iconsmind-Folder', 'iconsmind-Folders', 'iconsmind-Font-Color', 'iconsmind-Font-Name', 'iconsmind-Font-Size', 'iconsmind-Font-Style', 'iconsmind-Font-StyleSubscript', 'iconsmind-Font-StyleSuperscript', 'iconsmind-Font-Window', 'iconsmind-Foot-2', 'iconsmind-Foot', 'iconsmind-Football-2', 'iconsmind-Football', 'iconsmind-Footprint-2', 'iconsmind-Footprint-3', 'iconsmind-Footprint', 'iconsmind-Forest', 'iconsmind-Fork', 'iconsmind-Formspring', 'iconsmind-Formula', 'iconsmind-Forsquare', 'iconsmind-Forward', 'iconsmind-Fountain-Pen', 'iconsmind-Four-Fingers', 'iconsmind-Four-FingersDrag', 'iconsmind-Four-FingersDrag2', 'iconsmind-Four-FingersTouch', 'iconsmind-Fox', 'iconsmind-Frankenstein', 'iconsmind-French-Fries', 'iconsmind-Friendfeed', 'iconsmind-Friendster', 'iconsmind-Frog', 'iconsmind-Fruits', 'iconsmind-Fuel', 'iconsmind-Full-Bag', 'iconsmind-Full-Basket', 'iconsmind-Full-Cart', 'iconsmind-Full-Moon', 'iconsmind-Full-Screen', 'iconsmind-Full-Screen2', 'iconsmind-Full-View', 'iconsmind-Full-View2', 'iconsmind-Full-ViewWindow', 'iconsmind-Function', 'iconsmind-Funky', 'iconsmind-Funny-Bicycle', 'iconsmind-Furl', 'iconsmind-Gamepad-2', 'iconsmind-Gamepad', 'iconsmind-Gas-Pump', 'iconsmind-Gaugage-2', 'iconsmind-Gaugage', 'iconsmind-Gay', 'iconsmind-Gear-2', 'iconsmind-Gear', 'iconsmind-Gears-2', 'iconsmind-Gears', 'iconsmind-Geek-2', 'iconsmind-Geek', 'iconsmind-Gemini-2', 'iconsmind-Gemini', 'iconsmind-Genius', 'iconsmind-Gentleman', 'iconsmind-Geo--', 'iconsmind-Geo-', 'iconsmind-Geo-Close', 'iconsmind-Geo-Love', 'iconsmind-Geo-Number', 'iconsmind-Geo-Star', 'iconsmind-Geo', 'iconsmind-Geo2--', 'iconsmind-Geo2-', 'iconsmind-Geo2-Close', 'iconsmind-Geo2-Love', 'iconsmind-Geo2-Number', 'iconsmind-Geo2-Star', 'iconsmind-Geo2', 'iconsmind-Geo3--', 'iconsmind-Geo3-', 'iconsmind-Geo3-Close', 'iconsmind-Geo3 Love', 'iconsmind-Geo3-Number', 'iconsmind-Geo3-Star', 'iconsmind-Geo3', 'iconsmind-Gey', 'iconsmind-Gift-Box', 'iconsmind-Giraffe', 'iconsmind-Girl', 'iconsmind-Glass-Water', 'iconsmind-Glasses-2', 'iconsmind-Glasses-3', 'iconsmind-Glasses', 'iconsmind-Global-Position', 'iconsmind-Globe-2', 'iconsmind-Globe', 'iconsmind-Gloves', 'iconsmind-Go-Bottom', 'iconsmind-Go-Top', 'iconsmind-Goggles', 'iconsmind-Golf-2', 'iconsmind-Golf', 'iconsmind-Google-Buzz', 'iconsmind-Google-Drive', 'iconsmind-Google-Play', 'iconsmind-Google-Plus', 'iconsmind-Google', 'iconsmind-Gopro', 'iconsmind-Gorilla', 'iconsmind-Gowalla', 'iconsmind-Grave', 'iconsmind-Graveyard', 'iconsmind-Greece', 'iconsmind-Green-Energy', 'iconsmind-Green-House', 'iconsmind-Guitar', 'iconsmind-Gun-2', 'iconsmind-Gun-3', 'iconsmind-Gun', 'iconsmind-Gymnastics', 'iconsmind-Hair-2', 'iconsmind-Hair-3', 'iconsmind-Hair-4', 'iconsmind-Hair', 'iconsmind-Half-Moon', 'iconsmind-Halloween-HalfMoon', 'iconsmind-Halloween-Moon', 'iconsmind-Hamburger', 'iconsmind-Hammer', 'iconsmind-Hand-Touch', 'iconsmind-Hand-Touch2', 'iconsmind-Hand-TouchSmartphone', 'iconsmind-Hand', 'iconsmind-Hands', 'iconsmind-Handshake', 'iconsmind-Hanger', 'iconsmind-Happy', 'iconsmind-Hat-2', 'iconsmind-Hat', 'iconsmind-Haunted-House', 'iconsmind-HD-Video', 'iconsmind-HD', 'iconsmind-HDD', 'iconsmind-Headphone', 'iconsmind-Headphones', 'iconsmind-Headset', 'iconsmind-Heart-2', 'iconsmind-Heart', 'iconsmind-Heels-2', 'iconsmind-Heels', 'iconsmind-Height-Window', 'iconsmind-Helicopter-2', 'iconsmind-Helicopter', 'iconsmind-Helix-2', 'iconsmind-Hello', 'iconsmind-Helmet-2', 'iconsmind-Helmet-3', 'iconsmind-Helmet', 'iconsmind-Hipo', 'iconsmind-Hipster-Glasses', 'iconsmind-Hipster-Glasses2', 'iconsmind-Hipster-Glasses3', 'iconsmind-Hipster-Headphones', 'iconsmind-Hipster-Men', 'iconsmind-Hipster-Men2', 'iconsmind-Hipster-Men3', 'iconsmind-Hipster-Sunglasses', 'iconsmind-Hipster-Sunglasses2', 'iconsmind-Hipster-Sunglasses3', 'iconsmind-Hokey', 'iconsmind-Holly', 'iconsmind-Home-2', 'iconsmind-Home-3', 'iconsmind-Home-4', 'iconsmind-Home-5', 'iconsmind-Home-Window', 'iconsmind-Home', 'iconsmind-Homosexual', 'iconsmind-Honey', 'iconsmind-Hong-Kong', 'iconsmind-Hoodie', 'iconsmind-Horror', 'iconsmind-Horse', 'iconsmind-Hospital-2', 'iconsmind-Hospital', 'iconsmind-Host', 'iconsmind-Hot-Dog', 'iconsmind-Hotel', 'iconsmind-Hour', 'iconsmind-Hub', 'iconsmind-Humor', 'iconsmind-Hurt', 'iconsmind-Ice-Cream', 'iconsmind-ICQ', 'iconsmind-ID-2', 'iconsmind-ID-3', 'iconsmind-ID-Card', 'iconsmind-Idea-2', 'iconsmind-Idea-3', 'iconsmind-Idea-4', 'iconsmind-Idea-5', 'iconsmind-Idea', 'iconsmind-Identification-Badge', 'iconsmind-ImDB', 'iconsmind-Inbox-Empty', 'iconsmind-Inbox-Forward', 'iconsmind-Inbox-Full', 'iconsmind-Inbox-Into', 'iconsmind-Inbox-Out', 'iconsmind-Inbox-Reply', 'iconsmind-Inbox', 'iconsmind-Increase-Inedit', 'iconsmind-Indent-FirstLine', 'iconsmind-Indent-LeftMargin', 'iconsmind-Indent-RightMargin', 'iconsmind-India', 'iconsmind-Info-Window', 'iconsmind-Information', 'iconsmind-Inifity', 'iconsmind-Instagram', 'iconsmind-Internet-2', 'iconsmind-Internet-Explorer', 'iconsmind-Internet-Smiley', 'iconsmind-Internet', 'iconsmind-iOS-Apple', 'iconsmind-Israel', 'iconsmind-Italic-Text', 'iconsmind-Jacket-2', 'iconsmind-Jacket', 'iconsmind-Jamaica', 'iconsmind-Japan', 'iconsmind-Japanese-Gate', 'iconsmind-Jeans', 'iconsmind-Jeep-2', 'iconsmind-Jeep', 'iconsmind-Jet', 'iconsmind-Joystick', 'iconsmind-Juice', 'iconsmind-Jump-Rope', 'iconsmind-Kangoroo', 'iconsmind-Kenya', 'iconsmind-Key-2', 'iconsmind-Key-3', 'iconsmind-Key-Lock', 'iconsmind-Key', 'iconsmind-Keyboard', 'iconsmind-Keyboard3', 'iconsmind-Keypad', 'iconsmind-King-2', 'iconsmind-King', 'iconsmind-Kiss', 'iconsmind-Knee', 'iconsmind-Knife-2', 'iconsmind-Knife', 'iconsmind-Knight', 'iconsmind-Koala', 'iconsmind-Korea', 'iconsmind-Lamp', 'iconsmind-Landscape-2', 'iconsmind-Landscape', 'iconsmind-Lantern', 'iconsmind-Laptop-2', 'iconsmind-Laptop-3', 'iconsmind-Laptop-Phone', 'iconsmind-Laptop-Secure', 'iconsmind-Laptop-Tablet', 'iconsmind-Laptop', 'iconsmind-Laser', 'iconsmind-Last-FM', 'iconsmind-Last', 'iconsmind-Laughing', 'iconsmind-Layer-1635', 'iconsmind-Layer-1646', 'iconsmind-Layer-Backward', 'iconsmind-Layer-Forward', 'iconsmind-Leafs-2', 'iconsmind-Leafs', 'iconsmind-Leaning-Tower', 'iconsmind-Left--Right', 'iconsmind-Left--Right3', 'iconsmind-Left-2', 'iconsmind-Left-3', 'iconsmind-Left-4', 'iconsmind-Left-ToRight', 'iconsmind-Left', 'iconsmind-Leg-2', 'iconsmind-Leg', 'iconsmind-Lego', 'iconsmind-Lemon', 'iconsmind-Len-2', 'iconsmind-Len-3', 'iconsmind-Len', 'iconsmind-Leo-2', 'iconsmind-Leo', 'iconsmind-Leopard', 'iconsmind-Lesbian', 'iconsmind-Lesbians', 'iconsmind-Letter-Close', 'iconsmind-Letter-Open', 'iconsmind-Letter-Sent', 'iconsmind-Libra-2', 'iconsmind-Libra', 'iconsmind-Library-2', 'iconsmind-Library', 'iconsmind-Life-Jacket', 'iconsmind-Life-Safer', 'iconsmind-Light-Bulb', 'iconsmind-Light-Bulb2', 'iconsmind-Light-BulbLeaf', 'iconsmind-Lighthouse', 'iconsmind-Like-2', 'iconsmind-Like', 'iconsmind-Line-Chart', 'iconsmind-Line-Chart2', 'iconsmind-Line-Chart3', 'iconsmind-Line-Chart4', 'iconsmind-Line-Spacing', 'iconsmind-Line-SpacingText', 'iconsmind-Link-2', 'iconsmind-Link', 'iconsmind-Linkedin-2', 'iconsmind-Linkedin', 'iconsmind-Linux', 'iconsmind-Lion', 'iconsmind-Livejournal', 'iconsmind-Loading-2', 'iconsmind-Loading-3', 'iconsmind-Loading-Window', 'iconsmind-Loading', 'iconsmind-Location-2', 'iconsmind-Location', 'iconsmind-Lock-2', 'iconsmind-Lock-3', 'iconsmind-Lock-User', 'iconsmind-Lock-Window', 'iconsmind-Lock', 'iconsmind-Lollipop-2', 'iconsmind-Lollipop-3', 'iconsmind-Lollipop', 'iconsmind-Loop', 'iconsmind-Loud', 'iconsmind-Loudspeaker', 'iconsmind-Love-2', 'iconsmind-Love-User', 'iconsmind-Love-Window', 'iconsmind-Love', 'iconsmind-Lowercase-Text', 'iconsmind-Luggafe-Front', 'iconsmind-Luggage-2', 'iconsmind-Macro', 'iconsmind-Magic-Wand', 'iconsmind-Magnet', 'iconsmind-Magnifi-Glass', 'iconsmind-Magnifi-Glass2', 'iconsmind-Mail-2', 'iconsmind-Mail-3', 'iconsmind-Mail-Add', 'iconsmind-Mail-Attachement', 'iconsmind-Mail-Block', 'iconsmind-Mail-Delete', 'iconsmind-Mail-Favorite', 'iconsmind-Mail-Forward', 'iconsmind-Mail-Gallery', 'iconsmind-Mail-Inbox', 'iconsmind-Mail-Link', 'iconsmind-Mail-Lock', 'iconsmind-Mail-Love', 'iconsmind-Mail-Money', 'iconsmind-Mail-Open', 'iconsmind-Mail-Outbox', 'iconsmind-Mail-Password', 'iconsmind-Mail-Photo', 'iconsmind-Mail-Read', 'iconsmind-Mail-Removex', 'iconsmind-Mail-Reply', 'iconsmind-Mail-ReplyAll', 'iconsmind-Mail-Search', 'iconsmind-Mail-Send', 'iconsmind-Mail-Settings', 'iconsmind-Mail-Unread', 'iconsmind-Mail-Video', 'iconsmind-Mail-withAtSign', 'iconsmind-Mail-WithCursors', 'iconsmind-Mail', 'iconsmind-Mailbox-Empty', 'iconsmind-Mailbox-Full', 'iconsmind-Male-2', 'iconsmind-Male-Sign', 'iconsmind-Male', 'iconsmind-MaleFemale', 'iconsmind-Man-Sign', 'iconsmind-Management', 'iconsmind-Mans-Underwear', 'iconsmind-Mans-Underwear2', 'iconsmind-Map-Marker', 'iconsmind-Map-Marker2', 'iconsmind-Map-Marker3', 'iconsmind-Map', 'iconsmind-Map2', 'iconsmind-Marker-2', 'iconsmind-Marker-3', 'iconsmind-Marker', 'iconsmind-Martini-Glass', 'iconsmind-Mask', 'iconsmind-Master-Card', 'iconsmind-Maximize-Window', 'iconsmind-Maximize', 'iconsmind-Medal-2', 'iconsmind-Medal-3', 'iconsmind-Medal', 'iconsmind-Medical-Sign', 'iconsmind-Medicine-2', 'iconsmind-Medicine-3', 'iconsmind-Medicine', 'iconsmind-Megaphone', 'iconsmind-Memory-Card', 'iconsmind-Memory-Card2', 'iconsmind-Memory-Card3', 'iconsmind-Men', 'iconsmind-Menorah', 'iconsmind-Mens', 'iconsmind-Metacafe', 'iconsmind-Mexico', 'iconsmind-Mic', 'iconsmind-Microphone-2', 'iconsmind-Microphone-3', 'iconsmind-Microphone-4', 'iconsmind-Microphone-5', 'iconsmind-Microphone-6', 'iconsmind-Microphone-7', 'iconsmind-Microphone', 'iconsmind-Microscope', 'iconsmind-Milk-Bottle', 'iconsmind-Mine', 'iconsmind-Minimize-Maximize-Close-Window', 'iconsmind-Minimize-Window', 'iconsmind-Minimize', 'iconsmind-Mirror', 'iconsmind-Mixer', 'iconsmind-Mixx', 'iconsmind-Money-2', 'iconsmind-Money-Bag', 'iconsmind-Money-Smiley', 'iconsmind-Money', 'iconsmind-Monitor-2', 'iconsmind-Monitor-3', 'iconsmind-Monitor-4', 'iconsmind-Monitor-5', 'iconsmind-Monitor-Analytics', 'iconsmind-Monitor-Laptop', 'iconsmind-Monitor-phone', 'iconsmind-Monitor-Tablet', 'iconsmind-Monitor-Vertical', 'iconsmind-Monitor', 'iconsmind-Monitoring', 'iconsmind-Monkey', 'iconsmind-Monster', 'iconsmind-Morocco', 'iconsmind-Motorcycle', 'iconsmind-Mouse-2', 'iconsmind-Mouse-3', 'iconsmind-Mouse-4', 'iconsmind-Mouse-Pointer', 'iconsmind-Mouse', 'iconsmind-Moustache-Smiley', 'iconsmind-Movie-Ticket', 'iconsmind-Movie', 'iconsmind-Mp3-File', 'iconsmind-Museum', 'iconsmind-Mushroom', 'iconsmind-Music-Note', 'iconsmind-Music-Note2', 'iconsmind-Music-Note3', 'iconsmind-Music-Note4', 'iconsmind-Music-Player', 'iconsmind-Mustache-2', 'iconsmind-Mustache-3', 'iconsmind-Mustache-4', 'iconsmind-Mustache-5', 'iconsmind-Mustache-6', 'iconsmind-Mustache-7', 'iconsmind-Mustache-8', 'iconsmind-Mustache', 'iconsmind-Mute', 'iconsmind-Myspace', 'iconsmind-Navigat-Start', 'iconsmind-Navigate-End', 'iconsmind-Navigation-LeftWindow', 'iconsmind-Navigation-RightWindow', 'iconsmind-Nepal', 'iconsmind-Netscape', 'iconsmind-Network-Window', 'iconsmind-Network', 'iconsmind-Neutron', 'iconsmind-New-Mail', 'iconsmind-New-Tab', 'iconsmind-Newspaper-2', 'iconsmind-Newspaper', 'iconsmind-Newsvine', 'iconsmind-Next2', 'iconsmind-Next-3', 'iconsmind-Next-Music', 'iconsmind-Next', 'iconsmind-No-Battery', 'iconsmind-No-Drop', 'iconsmind-No-Flash', 'iconsmind-No-Smoking', 'iconsmind-Noose', 'iconsmind-Normal-Text', 'iconsmind-Note', 'iconsmind-Notepad-2', 'iconsmind-Notepad', 'iconsmind-Nuclear', 'iconsmind-Numbering-List', 'iconsmind-Nurse', 'iconsmind-Office-Lamp ', 'iconsmind-Office', 'iconsmind-Oil', 'iconsmind-Old-Camera', 'iconsmind-Old-Cassette', 'iconsmind-Old-Clock', 'iconsmind-Old-Radio', 'iconsmind-Old-Sticky', 'iconsmind-Old-Sticky2', 'iconsmind-Old-Telephone', 'iconsmind-Old-TV', 'iconsmind-On-Air', 'iconsmind-On-Off-2', 'iconsmind-On-Off-3', 'iconsmind-On-off', 'iconsmind-One-Finger', 'iconsmind-One-FingerTouch', 'iconsmind-One-Window', 'iconsmind-Open-Banana', 'iconsmind-Open-Book', 'iconsmind-Opera-House', 'iconsmind-Opera', 'iconsmind-Optimization', 'iconsmind-Orientation-2', 'iconsmind-Orientation-3', 'iconsmind-Orientation', 'iconsmind-Orkut', 'iconsmind-Ornament', 'iconsmind-Over-Time', 'iconsmind-Over-Time2', 'iconsmind-Owl', 'iconsmind-Pac-Man', 'iconsmind-Paint-Brush', 'iconsmind-Paint-Bucket', 'iconsmind-Paintbrush', 'iconsmind-Palette', 'iconsmind-Palm-Tree', 'iconsmind-Panda', 'iconsmind-Panorama', 'iconsmind-Pantheon', 'iconsmind-Pantone', 'iconsmind-Pants', 'iconsmind-Paper-Plane', 'iconsmind-Paper', 'iconsmind-Parasailing', 'iconsmind-Parrot', 'iconsmind-Password-2shopping', 'iconsmind-Password-Field', 'iconsmind-Password-shopping', 'iconsmind-Password', 'iconsmind-pause-2', 'iconsmind-Pause', 'iconsmind-Paw', 'iconsmind-Pawn', 'iconsmind-Paypal', 'iconsmind-Pen-2', 'iconsmind-Pen-3', 'iconsmind-Pen-4', 'iconsmind-Pen-5', 'iconsmind-Pen-6', 'iconsmind-Pen', 'iconsmind-Pencil-Ruler', 'iconsmind-Pencil', 'iconsmind-Penguin', 'iconsmind-Pentagon', 'iconsmind-People-onCloud', 'iconsmind-Pepper-withFire', 'iconsmind-Pepper', 'iconsmind-Petrol', 'iconsmind-Petronas-Tower', 'iconsmind-Philipines', 'iconsmind-Phone-2', 'iconsmind-Phone-3', 'iconsmind-Phone-3G', 'iconsmind-Phone-4G', 'iconsmind-Phone-Simcard', 'iconsmind-Phone-SMS', 'iconsmind-Phone-Wifi', 'iconsmind-Phone', 'iconsmind-Photo-2', 'iconsmind-Photo-3', 'iconsmind-Photo-Album', 'iconsmind-Photo-Album2', 'iconsmind-Photo-Album3', 'iconsmind-Photo', 'iconsmind-Photos', 'iconsmind-Physics', 'iconsmind-Pi', 'iconsmind-Piano', 'iconsmind-Picasa', 'iconsmind-Pie-Chart', 'iconsmind-Pie-Chart2', 'iconsmind-Pie-Chart3', 'iconsmind-Pilates-2', 'iconsmind-Pilates-3', 'iconsmind-Pilates', 'iconsmind-Pilot', 'iconsmind-Pinch', 'iconsmind-Ping-Pong', 'iconsmind-Pinterest', 'iconsmind-Pipe', 'iconsmind-Pipette', 'iconsmind-Piramids', 'iconsmind-Pisces-2', 'iconsmind-Pisces', 'iconsmind-Pizza-Slice', 'iconsmind-Pizza', 'iconsmind-Plane-2', 'iconsmind-Plane', 'iconsmind-Plant', 'iconsmind-Plasmid', 'iconsmind-Plaster', 'iconsmind-Plastic-CupPhone', 'iconsmind-Plastic-CupPhone2', 'iconsmind-Plate', 'iconsmind-Plates', 'iconsmind-Plaxo', 'iconsmind-Play-Music', 'iconsmind-Plug-In', 'iconsmind-Plug-In2', 'iconsmind-Plurk', 'iconsmind-Pointer', 'iconsmind-Poland', 'iconsmind-Police-Man', 'iconsmind-Police-Station', 'iconsmind-Police-Woman', 'iconsmind-Police', 'iconsmind-Polo-Shirt', 'iconsmind-Portrait', 'iconsmind-Portugal', 'iconsmind-Post-Mail', 'iconsmind-Post-Mail2', 'iconsmind-Post-Office', 'iconsmind-Post-Sign', 'iconsmind-Post-Sign2ways', 'iconsmind-Posterous', 'iconsmind-Pound-Sign', 'iconsmind-Pound-Sign2', 'iconsmind-Pound', 'iconsmind-Power-2', 'iconsmind-Power-3', 'iconsmind-Power-Cable', 'iconsmind-Power-Station', 'iconsmind-Power', 'iconsmind-Prater', 'iconsmind-Present', 'iconsmind-Presents', 'iconsmind-Press', 'iconsmind-Preview', 'iconsmind-Previous', 'iconsmind-Pricing', 'iconsmind-Printer', 'iconsmind-Professor', 'iconsmind-Profile', 'iconsmind-Project', 'iconsmind-Projector-2', 'iconsmind-Projector', 'iconsmind-Pulse', 'iconsmind-Pumpkin', 'iconsmind-Punk', 'iconsmind-Punker', 'iconsmind-Puzzle', 'iconsmind-QIK', 'iconsmind-QR-Code', 'iconsmind-Queen-2', 'iconsmind-Queen', 'iconsmind-Quill-2', 'iconsmind-Quill-3', 'iconsmind-Quill', 'iconsmind-Quotes-2', 'iconsmind-Quotes', 'iconsmind-Radio', 'iconsmind-Radioactive', 'iconsmind-Rafting', 'iconsmind-Rain-Drop', 'iconsmind-Rainbow-2', 'iconsmind-Rainbow', 'iconsmind-Ram', 'iconsmind-Razzor-Blade', 'iconsmind-Receipt-2', 'iconsmind-Receipt-3', 'iconsmind-Receipt-4', 'iconsmind-Receipt', 'iconsmind-Record2', 'iconsmind-Record-3', 'iconsmind-Record-Music', 'iconsmind-Record', 'iconsmind-Recycling-2', 'iconsmind-Recycling', 'iconsmind-Reddit', 'iconsmind-Redirect', 'iconsmind-Redo', 'iconsmind-Reel', 'iconsmind-Refinery', 'iconsmind-Refresh-Window', 'iconsmind-Refresh', 'iconsmind-Reload-2', 'iconsmind-Reload-3', 'iconsmind-Reload', 'iconsmind-Remote-Controll', 'iconsmind-Remote-Controll2', 'iconsmind-Remove-Bag', 'iconsmind-Remove-Basket', 'iconsmind-Remove-Cart', 'iconsmind-Remove-File', 'iconsmind-Remove-User', 'iconsmind-Remove-Window', 'iconsmind-Remove', 'iconsmind-Rename', 'iconsmind-Repair', 'iconsmind-Repeat-2', 'iconsmind-Repeat-3', 'iconsmind-Repeat-4', 'iconsmind-Repeat-5', 'iconsmind-Repeat-6', 'iconsmind-Repeat-7', 'iconsmind-Repeat', 'iconsmind-Reset', 'iconsmind-Resize', 'iconsmind-Restore-Window', 'iconsmind-Retouching', 'iconsmind-Retro-Camera', 'iconsmind-Retro', 'iconsmind-Retweet', 'iconsmind-Reverbnation', 'iconsmind-Rewind', 'iconsmind-RGB', 'iconsmind-Ribbon-2', 'iconsmind-Ribbon-3', 'iconsmind-Ribbon', 'iconsmind-Right-2', 'iconsmind-Right-3', 'iconsmind-Right-4', 'iconsmind-Right-ToLeft', 'iconsmind-Right', 'iconsmind-Road-2', 'iconsmind-Road-3', 'iconsmind-Road', 'iconsmind-Robot-2', 'iconsmind-Robot', 'iconsmind-Rock-andRoll', 'iconsmind-Rocket', 'iconsmind-Roller', 'iconsmind-Roof', 'iconsmind-Rook', 'iconsmind-Rotate-Gesture', 'iconsmind-Rotate-Gesture2', 'iconsmind-Rotate-Gesture3', 'iconsmind-Rotation-390', 'iconsmind-Rotation', 'iconsmind-Router-2', 'iconsmind-Router', 'iconsmind-RSS', 'iconsmind-Ruler-2', 'iconsmind-Ruler', 'iconsmind-Running-Shoes', 'iconsmind-Running', 'iconsmind-Safari', 'iconsmind-Safe-Box', 'iconsmind-Safe-Box2', 'iconsmind-Safety-PinClose', 'iconsmind-Safety-PinOpen', 'iconsmind-Sagittarus-2', 'iconsmind-Sagittarus', 'iconsmind-Sailing-Ship', 'iconsmind-Sand-watch', 'iconsmind-Sand-watch2', 'iconsmind-Santa-Claus', 'iconsmind-Santa-Claus2', 'iconsmind-Santa-onSled', 'iconsmind-Satelite-2', 'iconsmind-Satelite', 'iconsmind-Save-Window', 'iconsmind-Save', 'iconsmind-Saw', 'iconsmind-Saxophone', 'iconsmind-Scale', 'iconsmind-Scarf', 'iconsmind-Scissor', 'iconsmind-Scooter-Front', 'iconsmind-Scooter', 'iconsmind-Scorpio-2', 'iconsmind-Scorpio', 'iconsmind-Scotland', 'iconsmind-Screwdriver', 'iconsmind-Scroll-Fast', 'iconsmind-Scroll', 'iconsmind-Scroller-2', 'iconsmind-Scroller', 'iconsmind-Sea-Dog', 'iconsmind-Search-onCloud', 'iconsmind-Search-People', 'iconsmind-secound', 'iconsmind-secound2', 'iconsmind-Security-Block', 'iconsmind-Security-Bug', 'iconsmind-Security-Camera', 'iconsmind-Security-Check', 'iconsmind-Security-Settings', 'iconsmind-Security-Smiley', 'iconsmind-Securiy-Remove', 'iconsmind-Seed', 'iconsmind-Selfie', 'iconsmind-Serbia', 'iconsmind-Server-2', 'iconsmind-Server', 'iconsmind-Servers', 'iconsmind-Settings-Window', 'iconsmind-Sewing-Machine', 'iconsmind-Sexual', 'iconsmind-Share-onCloud', 'iconsmind-Share-Window', 'iconsmind-Share', 'iconsmind-Sharethis', 'iconsmind-Shark', 'iconsmind-Sheep', 'iconsmind-Sheriff-Badge', 'iconsmind-Shield', 'iconsmind-Ship-2', 'iconsmind-Ship', 'iconsmind-Shirt', 'iconsmind-Shoes-2', 'iconsmind-Shoes-3', 'iconsmind-Shoes', 'iconsmind-Shop-2', 'iconsmind-Shop-3', 'iconsmind-Shop-4', 'iconsmind-Shop', 'iconsmind-Shopping-Bag', 'iconsmind-Shopping-Basket', 'iconsmind-Shopping-Cart', 'iconsmind-Short-Pants', 'iconsmind-Shoutwire', 'iconsmind-Shovel', 'iconsmind-Shuffle-2', 'iconsmind-Shuffle-3', 'iconsmind-Shuffle-4', 'iconsmind-Shuffle', 'iconsmind-Shutter', 'iconsmind-Sidebar-Window', 'iconsmind-Signal', 'iconsmind-Singapore', 'iconsmind-Skate-Shoes', 'iconsmind-Skateboard-2', 'iconsmind-Skateboard', 'iconsmind-Skeleton', 'iconsmind-Ski', 'iconsmind-Skirt', 'iconsmind-Skrill', 'iconsmind-Skull', 'iconsmind-Skydiving', 'iconsmind-Skype', 'iconsmind-Sled-withGifts', 'iconsmind-Sled', 'iconsmind-Sleeping', 'iconsmind-Sleet', 'iconsmind-Slippers', 'iconsmind-Smart', 'iconsmind-Smartphone-2', 'iconsmind-Smartphone-3', 'iconsmind-Smartphone-4', 'iconsmind-Smartphone-Secure', 'iconsmind-Smartphone', 'iconsmind-Smile', 'iconsmind-Smoking-Area', 'iconsmind-Smoking-Pipe', 'iconsmind-Snake', 'iconsmind-Snorkel', 'iconsmind-Snow-2', 'iconsmind-Snow-Dome', 'iconsmind-Snow-Storm', 'iconsmind-Snow', 'iconsmind-Snowflake-2', 'iconsmind-Snowflake-3', 'iconsmind-Snowflake-4', 'iconsmind-Snowflake', 'iconsmind-Snowman', 'iconsmind-Soccer-Ball', 'iconsmind-Soccer-Shoes', 'iconsmind-Socks', 'iconsmind-Solar', 'iconsmind-Sound-Wave', 'iconsmind-Sound', 'iconsmind-Soundcloud', 'iconsmind-Soup', 'iconsmind-South-Africa', 'iconsmind-Space-Needle', 'iconsmind-Spain', 'iconsmind-Spam-Mail', 'iconsmind-Speach-Bubble', 'iconsmind-Speach-Bubble2', 'iconsmind-Speach-Bubble3', 'iconsmind-Speach-Bubble4', 'iconsmind-Speach-Bubble5', 'iconsmind-Speach-Bubble6', 'iconsmind-Speach-Bubble7', 'iconsmind-Speach-Bubble8', 'iconsmind-Speach-Bubble9', 'iconsmind-Speach-Bubble10', 'iconsmind-Speach-Bubble11', 'iconsmind-Speach-Bubble12', 'iconsmind-Speach-Bubble13', 'iconsmind-Speach-BubbleAsking', 'iconsmind-Speach-BubbleComic', 'iconsmind-Speach-BubbleComic2', 'iconsmind-Speach-BubbleComic3', 'iconsmind-Speach-BubbleComic4', 'iconsmind-Speach-BubbleDialog', 'iconsmind-Speach-Bubbles', 'iconsmind-Speak-2', 'iconsmind-Speak', 'iconsmind-Speaker-2', 'iconsmind-Speaker', 'iconsmind-Spell-Check', 'iconsmind-Spell-CheckABC', 'iconsmind-Spermium', 'iconsmind-Spider', 'iconsmind-Spiderweb', 'iconsmind-Split-FourSquareWindow', 'iconsmind-Split-Horizontal', 'iconsmind-Split-Horizontal2Window', 'iconsmind-Split-Vertical', 'iconsmind-Split-Vertical2', 'iconsmind-Split-Window', 'iconsmind-Spoder', 'iconsmind-Spoon', 'iconsmind-Sport-Mode', 'iconsmind-Sports-Clothings1', 'iconsmind-Sports-Clothings2', 'iconsmind-Sports-Shirt', 'iconsmind-Spot', 'iconsmind-Spray', 'iconsmind-Spread', 'iconsmind-Spring', 'iconsmind-Spurl', 'iconsmind-Spy', 'iconsmind-Squirrel', 'iconsmind-SSL', 'iconsmind-St-BasilsCathedral', 'iconsmind-St-PaulsCathedral', 'iconsmind-Stamp-2', 'iconsmind-Stamp', 'iconsmind-Stapler', 'iconsmind-Star-Track', 'iconsmind-Star', 'iconsmind-Starfish', 'iconsmind-Start2', 'iconsmind-Start-3', 'iconsmind-Start-ways', 'iconsmind-Start', 'iconsmind-Statistic', 'iconsmind-Stethoscope', 'iconsmind-stop--2', 'iconsmind-Stop-Music', 'iconsmind-Stop', 'iconsmind-Stopwatch-2', 'iconsmind-Stopwatch', 'iconsmind-Storm', 'iconsmind-Street-View', 'iconsmind-Street-View2', 'iconsmind-Strikethrough-Text', 'iconsmind-Stroller', 'iconsmind-Structure', 'iconsmind-Student-Female', 'iconsmind-Student-Hat', 'iconsmind-Student-Hat2', 'iconsmind-Student-Male', 'iconsmind-Student-MaleFemale', 'iconsmind-Students', 'iconsmind-Studio-Flash', 'iconsmind-Studio-Lightbox', 'iconsmind-Stumbleupon', 'iconsmind-Suit', 'iconsmind-Suitcase', 'iconsmind-Sum-2', 'iconsmind-Sum', 'iconsmind-Summer', 'iconsmind-Sun-CloudyRain', 'iconsmind-Sun', 'iconsmind-Sunglasses-2', 'iconsmind-Sunglasses-3', 'iconsmind-Sunglasses-Smiley', 'iconsmind-Sunglasses-Smiley2', 'iconsmind-Sunglasses-W', 'iconsmind-Sunglasses-W2', 'iconsmind-Sunglasses-W3', 'iconsmind-Sunglasses', 'iconsmind-Sunrise', 'iconsmind-Sunset', 'iconsmind-Superman', 'iconsmind-Support', 'iconsmind-Surprise', 'iconsmind-Sushi', 'iconsmind-Sweden', 'iconsmind-Swimming-Short', 'iconsmind-Swimming', 'iconsmind-Swimmwear', 'iconsmind-Switch', 'iconsmind-Switzerland', 'iconsmind-Sync-Cloud', 'iconsmind-Sync', 'iconsmind-Synchronize-2', 'iconsmind-Synchronize', 'iconsmind-T-Shirt', 'iconsmind-Tablet-2', 'iconsmind-Tablet-3', 'iconsmind-Tablet-Orientation', 'iconsmind-Tablet-Phone', 'iconsmind-Tablet-Secure', 'iconsmind-Tablet-Vertical', 'iconsmind-Tablet', 'iconsmind-Tactic', 'iconsmind-Tag-2', 'iconsmind-Tag-3', 'iconsmind-Tag-4', 'iconsmind-Tag-5', 'iconsmind-Tag', 'iconsmind-Taj-Mahal', 'iconsmind-Talk-Man', 'iconsmind-Tap', 'iconsmind-Target-Market', 'iconsmind-Target', 'iconsmind-Taurus-2', 'iconsmind-Taurus', 'iconsmind-Taxi-2', 'iconsmind-Taxi-Sign', 'iconsmind-Taxi', 'iconsmind-Teacher', 'iconsmind-Teapot', 'iconsmind-Technorati', 'iconsmind-Teddy-Bear', 'iconsmind-Tee-Mug', 'iconsmind-Telephone-2', 'iconsmind-Telephone', 'iconsmind-Telescope', 'iconsmind-Temperature-2', 'iconsmind-Temperature-3', 'iconsmind-Temperature', 'iconsmind-Temple', 'iconsmind-Tennis-Ball', 'iconsmind-Tennis', 'iconsmind-Tent', 'iconsmind-Test-Tube', 'iconsmind-Test-Tube2', 'iconsmind-Testimonal', 'iconsmind-Text-Box', 'iconsmind-Text-Effect', 'iconsmind-Text-HighlightColor', 'iconsmind-Text-Paragraph', 'iconsmind-Thailand', 'iconsmind-The-WhiteHouse', 'iconsmind-This-SideUp', 'iconsmind-Thread', 'iconsmind-Three-ArrowFork', 'iconsmind-Three-Fingers', 'iconsmind-Three-FingersDrag', 'iconsmind-Three-FingersDrag2', 'iconsmind-Three-FingersTouch', 'iconsmind-Thumb', 'iconsmind-Thumbs-DownSmiley', 'iconsmind-Thumbs-UpSmiley', 'iconsmind-Thunder', 'iconsmind-Thunderstorm', 'iconsmind-Ticket', 'iconsmind-Tie-2', 'iconsmind-Tie-3', 'iconsmind-Tie-4', 'iconsmind-Tie', 'iconsmind-Tiger', 'iconsmind-Time-Backup', 'iconsmind-Time-Bomb', 'iconsmind-Time-Clock', 'iconsmind-Time-Fire', 'iconsmind-Time-Machine', 'iconsmind-Time-Window', 'iconsmind-Timer-2', 'iconsmind-Timer', 'iconsmind-To-Bottom', 'iconsmind-To-Bottom2', 'iconsmind-To-Left', 'iconsmind-To-Right', 'iconsmind-To-Top', 'iconsmind-To-Top2', 'iconsmind-Token', 'iconsmind-Tomato', 'iconsmind-Tongue', 'iconsmind-Tooth-2', 'iconsmind-Tooth', 'iconsmind-Top-ToBottom', 'iconsmind-Touch-Window', 'iconsmind-Tourch', 'iconsmind-Tower-2', 'iconsmind-Tower-Bridge', 'iconsmind-Tower', 'iconsmind-Trace', 'iconsmind-Tractor', 'iconsmind-traffic-Light', 'iconsmind-Traffic-Light2', 'iconsmind-Train-2', 'iconsmind-Train', 'iconsmind-Tram', 'iconsmind-Transform-2', 'iconsmind-Transform-3', 'iconsmind-Transform-4', 'iconsmind-Transform', 'iconsmind-Trash-withMen', 'iconsmind-Tree-2', 'iconsmind-Tree-3', 'iconsmind-Tree-4', 'iconsmind-Tree-5', 'iconsmind-Tree', 'iconsmind-Trekking', 'iconsmind-Triangle-ArrowDown', 'iconsmind-Triangle-ArrowLeft', 'iconsmind-Triangle-ArrowRight', 'iconsmind-Triangle-ArrowUp', 'iconsmind-Tripod-2', 'iconsmind-Tripod-andVideo', 'iconsmind-Tripod-withCamera', 'iconsmind-Tripod-withGopro', 'iconsmind-Trophy-2', 'iconsmind-Trophy', 'iconsmind-Truck', 'iconsmind-Trumpet', 'iconsmind-Tumblr', 'iconsmind-Turkey', 'iconsmind-Turn-Down', 'iconsmind-Turn-Down2', 'iconsmind-Turn-DownFromLeft', 'iconsmind-Turn-DownFromRight', 'iconsmind-Turn-Left', 'iconsmind-Turn-Left3', 'iconsmind-Turn-Right', 'iconsmind-Turn-Right3', 'iconsmind-Turn-Up', 'iconsmind-Turn-Up2', 'iconsmind-Turtle', 'iconsmind-Tuxedo', 'iconsmind-TV', 'iconsmind-Twister', 'iconsmind-Twitter-2', 'iconsmind-Twitter', 'iconsmind-Two-Fingers', 'iconsmind-Two-FingersDrag', 'iconsmind-Two-FingersDrag2', 'iconsmind-Two-FingersScroll', 'iconsmind-Two-FingersTouch', 'iconsmind-Two-Windows', 'iconsmind-Type-Pass', 'iconsmind-Ukraine', 'iconsmind-Umbrela', 'iconsmind-Umbrella-2', 'iconsmind-Umbrella-3', 'iconsmind-Under-LineText', 'iconsmind-Undo', 'iconsmind-United-Kingdom', 'iconsmind-United-States', 'iconsmind-University-2', 'iconsmind-University', 'iconsmind-Unlike-2', 'iconsmind-Unlike', 'iconsmind-Unlock-2', 'iconsmind-Unlock-3', 'iconsmind-Unlock', 'iconsmind-Up--Down', 'iconsmind-Up--Down3', 'iconsmind-Up-2', 'iconsmind-Up-3', 'iconsmind-Up-4', 'iconsmind-Up', 'iconsmind-Upgrade', 'iconsmind-Upload-2', 'iconsmind-Upload-toCloud', 'iconsmind-Upload-Window', 'iconsmind-Upload', 'iconsmind-Uppercase-Text', 'iconsmind-Upward', 'iconsmind-URL-Window', 'iconsmind-Usb-2', 'iconsmind-Usb-Cable', 'iconsmind-Usb', 'iconsmind-User', 'iconsmind-Ustream', 'iconsmind-Vase', 'iconsmind-Vector-2', 'iconsmind-Vector-3', 'iconsmind-Vector-4', 'iconsmind-Vector-5', 'iconsmind-Vector', 'iconsmind-Venn-Diagram', 'iconsmind-Vest-2', 'iconsmind-Vest', 'iconsmind-Viddler', 'iconsmind-Video-2', 'iconsmind-Video-3', 'iconsmind-Video-4', 'iconsmind-Video-5', 'iconsmind-Video-6', 'iconsmind-Video-GameController', 'iconsmind-Video-Len', 'iconsmind-Video-Len2', 'iconsmind-Video-Photographer', 'iconsmind-Video-Tripod', 'iconsmind-Video', 'iconsmind-Vietnam', 'iconsmind-View-Height', 'iconsmind-View-Width', 'iconsmind-Vimeo', 'iconsmind-Virgo-2', 'iconsmind-Virgo', 'iconsmind-Virus-2', 'iconsmind-Virus-3', 'iconsmind-Virus', 'iconsmind-Visa', 'iconsmind-Voice', 'iconsmind-Voicemail', 'iconsmind-Volleyball', 'iconsmind-Volume-Down', 'iconsmind-Volume-Up', 'iconsmind-VPN', 'iconsmind-Wacom-Tablet', 'iconsmind-Waiter', 'iconsmind-Walkie-Talkie', 'iconsmind-Wallet-2', 'iconsmind-Wallet-3', 'iconsmind-Wallet', 'iconsmind-Warehouse', 'iconsmind-Warning-Window', 'iconsmind-Watch-2', 'iconsmind-Watch-3', 'iconsmind-Watch', 'iconsmind-Wave-2', 'iconsmind-Wave', 'iconsmind-Webcam', 'iconsmind-weight-Lift', 'iconsmind-Wheelbarrow', 'iconsmind-Wheelchair', 'iconsmind-Width-Window', 'iconsmind-Wifi-2', 'iconsmind-Wifi-Keyboard', 'iconsmind-Wifi', 'iconsmind-Wind-Turbine', 'iconsmind-Windmill', 'iconsmind-Window-2', 'iconsmind-Window', 'iconsmind-Windows-2', 'iconsmind-Windows-Microsoft', 'iconsmind-Windows', 'iconsmind-Windsock', 'iconsmind-Windy', 'iconsmind-Wine-Bottle', 'iconsmind-Wine-Glass', 'iconsmind-Wink', 'iconsmind-Winter-2', 'iconsmind-Winter', 'iconsmind-Wireless', 'iconsmind-Witch-Hat', 'iconsmind-Witch', 'iconsmind-Wizard', 'iconsmind-Wolf', 'iconsmind-Woman-Sign', 'iconsmind-WomanMan', 'iconsmind-Womans-Underwear', 'iconsmind-Womans-Underwear2', 'iconsmind-Women', 'iconsmind-Wonder-Woman', 'iconsmind-Wordpress', 'iconsmind-Worker-Clothes', 'iconsmind-Worker', 'iconsmind-Wrap-Text', 'iconsmind-Wreath', 'iconsmind-Wrench', 'iconsmind-X-Box', 'iconsmind-X-ray', 'iconsmind-Xanga', 'iconsmind-Xing', 'iconsmind-Yacht', 'iconsmind-Yahoo-Buzz', 'iconsmind-Yahoo', 'iconsmind-Yelp', 'iconsmind-Yes', 'iconsmind-Ying-Yang', 'iconsmind-Youtube', 'iconsmind-Z-A', 'iconsmind-Zebra', 'iconsmind-Zombie', 'iconsmind-Zoom-Gesture', 'iconsmind-Zootool']],
        'before_after' => ['type' => 'string', 'description' => 'Icon Position', 'enum' => ['after', 'before']],
        'icon_spacing' => ['type' => 'object', 'description' => 'Icon Spacing'],
        'tpaep_theme_builder' => ['type' => 'string', 'description' => 'tpaep_theme_builder'],
        'post_meta_color' => ['type' => 'string', 'description' => 'Post Meta Color'],
        'post_meta_color_hover' => ['type' => 'string', 'description' => 'Post Meta Color'],
        'post_meta_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'blog_card_layout' => ['type' => 'string', 'description' => 'Layout', 'enum' => ['yes', 'no']],
        'wrap_flex_direction' => ['type' => 'string', 'description' => 'Layout Direction', 'enum' => ['column', 'row', 'column-reverse', 'row-reverse']],
        'tp_row_one_width' => ['type' => 'object', 'description' => 'Image Box'],
        'tp_row_two_width' => ['type' => 'object', 'description' => 'Content Box'],
        'tp_content_alignment' => ['type' => 'string', 'description' => 'Text Alignment', 'enum' => ['left', 'center', 'right']],
        'tp_item_content_alignment' => ['type' => 'string', 'description' => 'Layout Alignment', 'enum' => ['flex-start', 'center', 'flex-end']],
        'wrap_gap' => ['type' => 'object', 'description' => 'Item Gap'],
        'tp_absolute_layout' => ['type' => 'string', 'description' => 'Layout Position', 'enum' => ['yes', 'no']],
        'tp_top_card' => ['type' => 'object', 'description' => 'Left/Right'],
        'tp_bottom_card' => ['type' => 'object', 'description' => 'bottom'],
        'tp_width_card' => ['type' => 'object', 'description' => 'Width'],
        'content_direction' => ['type' => 'string', 'description' => 'Content Direction', 'enum' => ['row', 'row-reverse', 'column', 'column-reverse']],
        'content_vertical_justify' => ['type' => 'string', 'description' => 'Vertical Alignment', 'enum' => ['flex-start', 'center', 'flex-end', 'space-between', 'space-around']],
        'blog_content_padding' => ['type' => 'object', 'description' => 'Padding'],
        'blog_content_margin' => ['type' => 'object', 'description' => 'Margin'],
        'blog_border_post' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'blog_content_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'blog_meta_layout_post' => ['type' => 'string', 'description' => 'Meta Layout', 'enum' => ['yes', 'no']],
        'meta_flex_direction' => ['type' => 'string', 'description' => 'Meta Direction', 'enum' => ['row', 'row-reverse', 'column', 'column-reverse']],
        'meta_align_items' => ['type' => 'string', 'description' => 'Meta Align', 'enum' => ['flex-start', 'center', 'flex-end']],
        'meta_gap' => ['type' => 'object', 'description' => 'Item Gap'],
        'tp_meta_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'tp_meta_border_r' => ['type' => 'object', 'description' => 'Border Radius'],
        'date_overflow' => ['type' => 'string', 'description' => 'Date Position', 'enum' => ['yes', 'no']],
        'category_date_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'date_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'date_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'overflow_date_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'meta_overflow' => ['type' => 'string', 'description' => 'Author Position', 'enum' => ['yes', 'no']],
        'category_meta_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'meta_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'meta_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'overflow_meta_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'post_tima_overflow' => ['type' => 'string', 'description' => 'Post Time Position', 'enum' => ['yes', 'no']],
        'category_post_time_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'post_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'post_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'overflow_post_time_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'button_overflow' => ['type' => 'string', 'description' => 'Button Absolute', 'enum' => ['yes', 'no']],
        'button_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'button_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'blog_category_post' => ['type' => 'string', 'description' => 'Category Post', 'enum' => ['yes', 'no']],
        'category_style_margin_tb' => ['type' => 'object', 'description' => 'Top/Bottom Spacing'],
        'category_style_margin_lr' => ['type' => 'object', 'description' => 'Left/Right Spacing'],
        'category_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'category_color' => ['type' => 'string', 'description' => 'Color'],
        'category_hover_color' => ['type' => 'string', 'description' => 'Color'],
        'category_2_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color'],
        'category_border' => ['type' => 'string', 'description' => 'Border', 'enum' => ['yes', 'no']],
        'category_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['solid', 'dashed', 'dotted', 'groove', 'inset', 'outset', 'ridge']],
        'box_category_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'category_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'category_border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'category_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'category_border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        's_title_pg' => ['type' => 'object', 'description' => 'Padding'],
        'title_margin' => ['type' => 'object', 'description' => 'Margin'],
        'title_color' => ['type' => 'string', 'description' => 'Color'],
        'title_hover_color' => ['type' => 'string', 'description' => 'Color'],
        'title_boxhover_color' => ['type' => 'string', 'description' => 'Title Color'],
        's_excerpt_content_pg' => ['type' => 'object', 'description' => 'Padding'],
        'excerpt_margin' => ['type' => 'object', 'description' => 'Margin'],
        'excerpt_color' => ['type' => 'string', 'description' => 'Content Color'],
        'excerpt_hover_color' => ['type' => 'string', 'description' => 'Content Color'],
        'content_between_space' => ['type' => 'object', 'description' => 'Content Space'],
        'blog_featured_image_width' => ['type' => 'object', 'description' => 'Image width'],
        'blog_featured_image_height' => ['type' => 'object', 'description' => 'Image Height'],
        'hover_image_style' => ['type' => 'string', 'description' => 'Image Hover Effect', 'enum' => ['none', 'style-1']],
        'featured_image_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'tpae_enable_overlay' => ['type' => 'string', 'description' => 'Enable Overlay', 'enum' => ['yes', 'no']],
        'tpae_overlay_color' => ['type' => 'string', 'description' => 'Overlay Color'],
        'full_image_size' => ['type' => 'string', 'description' => 'Full Image', 'enum' => ['yes', 'no']],
        'full_image_size_min_height' => ['type' => 'object', 'description' => 'Image Height'],
        'button_padding' => ['type' => 'object', 'description' => 'Padding'],
        'btn_text_color' => ['type' => 'string', 'description' => 'Text Color'],
        'button_border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['none', 'solid', 'dotted', 'dashed', 'groove']],
        'button_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'button_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'button_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'btn_text_hover_color' => ['type' => 'string', 'description' => 'Text Hover Color'],
        'button_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color'],
        'button_hover_radius' => ['type' => 'object', 'description' => 'Hover Border Radius'],
        'filter_category_padding' => ['type' => 'object', 'description' => 'Padding'],
        'filter_category_marign' => ['type' => 'object', 'description' => 'Margin'],
        'filters_text_color' => ['type' => 'string', 'description' => 'Filters Text Color'],
        'filter_category_color' => ['type' => 'string', 'description' => 'Category Filter Color'],
        'filter_category_4_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'filter_category_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'filter_category_hover_color' => ['type' => 'string', 'description' => 'Category Filter Color'],
        'filter_category_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'filter_border_hover_color' => ['type' => 'string', 'description' => 'Hover Border Color'],
        'category_count_color' => ['type' => 'string', 'description' => 'Category Count Color'],
        'category_count_bg_color' => ['type' => 'string', 'description' => 'Count Background Color'],
        'content_inner_padding' => ['type' => 'object', 'description' => 'Padding'],
        'box_border' => ['type' => 'string', 'description' => 'Box Border', 'enum' => ['yes', 'no']],
        'border_style' => ['type' => 'string', 'description' => 'Border Style', 'enum' => ['solid', 'dashed', 'dotted', 'groove', 'inset', 'outset', 'ridge']],
        'box_border_width' => ['type' => 'object', 'description' => 'Border Width'],
        'box_border_color' => ['type' => 'string', 'description' => 'Border Color'],
        'border_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'box_border_hover_color' => ['type' => 'string', 'description' => 'Border Color'],
        'border_hover_radius' => ['type' => 'object', 'description' => 'Border Radius'],
        'carousel_unique_id' => ['type' => 'string', 'description' => 'Unique Carousel ID'],
        'slider_direction' => ['type' => 'string', 'description' => 'Slider Mode', 'enum' => ['horizontal', 'vertical']],
        'carousel_direction' => ['type' => 'string', 'description' => 'Slide Direction', 'enum' => ['ltr', 'rtl']],
        'slide_speed' => ['type' => 'object', 'description' => 'Slide Speed'],
        'slider_desktop_column' => ['type' => 'string', 'description' => 'Desktop Columns', 'enum' => ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']],
        'steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_padding' => ['type' => 'object', 'description' => 'Slide Padding'],
        'slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'multi_drag' => ['type' => 'string', 'description' => 'Multi Drag', 'enum' => ['yes', 'no']],
        'slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'slider_pause_hover' => ['type' => 'string', 'description' => 'Pause On Hover', 'enum' => ['yes', 'no']],
        'slider_adaptive_height' => ['type' => 'string', 'description' => 'Adaptive Height', 'enum' => ['yes', 'no']],
        'slider_animation' => ['type' => 'string', 'description' => 'Animation Type', 'enum' => ['ease', 'linear']],
        'slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed'],
        'slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color'],
        'dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color'],
        'dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color'],
        'dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color'],
        'dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding'],
        'hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['top-right', 'bottm-left', 'bottom-center', 'bottom-right']],
        'arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color'],
        'arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color'],
        'arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color'],
        'arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color'],
        'outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'slider_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'center_padding' => ['type' => 'object', 'description' => 'Center Padding'],
        'slider_center_effects' => ['type' => 'string', 'description' => 'Center Slide Effects', 'enum' => ['none', 'scale', 'shadow']],
        'scale_center_slide' => ['type' => 'object', 'description' => 'Center Slide Scale'],
        'scale_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Scale'],
        'opacity_normal_slide' => ['type' => 'object', 'description' => 'Normal Slide Opacity'],
        'slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'slide_row_top_space' => ['type' => 'object', 'description' => 'Row Top Space'],
        'slider_tablet_column' => ['type' => 'string', 'description' => 'Tablet Columns', 'enum' => ['1', '2', '3', '4', '5', '6', '7', '8']],
        'tablet_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_tablet' => ['type' => 'string', 'description' => 'Responsive Tablet', 'enum' => ['yes', 'no']],
        'tablet_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'tablet_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'tablet_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'tablet_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed'],
        'tablet_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'tablet_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color'],
        'tablet_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color'],
        'tablet_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color'],
        'tablet_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color'],
        'tablet_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding'],
        'tablet_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'tablet_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'tablet_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['top-right', 'bottm-left', 'bottom-center', 'bottom-right']],
        'tablet_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color'],
        'tablet_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color'],
        'tablet_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color'],
        'tablet_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color'],
        'tablet_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'tablet_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'tablet_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'tablet_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'tablet_center_padding' => ['type' => 'object', 'description' => 'Center Padding'],
        'slider_mobile_column' => ['type' => 'string', 'description' => 'Mobile Columns', 'enum' => ['1', '2', '3', '4', '5', '6']],
        'mobile_steps_slide' => ['type' => 'string', 'description' => 'Next Previous', 'enum' => ['1', '2']],
        'slider_responsive_mobile' => ['type' => 'string', 'description' => 'Responsive Mobile', 'enum' => ['yes', 'no']],
        'mobile_slider_draggable' => ['type' => 'string', 'description' => 'Draggable', 'enum' => ['yes', 'no']],
        'mobile_slider_infinite' => ['type' => 'string', 'description' => 'Infinite Mode', 'enum' => ['yes', 'no']],
        'mobile_slider_autoplay' => ['type' => 'string', 'description' => 'Autoplay', 'enum' => ['yes', 'no']],
        'mobile_autoplay_speed' => ['type' => 'object', 'description' => 'Autoplay Speed'],
        'mobile_slider_dots' => ['type' => 'string', 'description' => 'Show Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_dots_style' => ['type' => 'string', 'description' => 'Dots Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6', 'style-7']],
        'mobile_dots_border_color' => ['type' => 'string', 'description' => 'Dots Border Color'],
        'mobile_dots_bg_color' => ['type' => 'string', 'description' => 'Dots Background Color'],
        'mobile_dots_active_border_color' => ['type' => 'string', 'description' => 'Dots Active Border Color'],
        'mobile_dots_active_bg_color' => ['type' => 'string', 'description' => 'Dots Active Background Color'],
        'mobile_dots_top_padding' => ['type' => 'object', 'description' => 'Dots Top Padding'],
        'mobile_hover_show_dots' => ['type' => 'string', 'description' => 'On Hover Dots', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows' => ['type' => 'string', 'description' => 'Show Arrows', 'enum' => ['yes', 'no']],
        'mobile_slider_arrows_style' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['style-1', 'style-2', 'style-3', 'style-4', 'style-5', 'style-6']],
        'mobile_arrows_position' => ['type' => 'string', 'description' => 'Arrows Style', 'enum' => ['top-right', 'bottm-left', 'bottom-center', 'bottom-right']],
        'mobile_arrow_bg_color' => ['type' => 'string', 'description' => 'Arrow Background Color'],
        'mobile_arrow_icon_color' => ['type' => 'string', 'description' => 'Arrow Icon Color'],
        'mobile_arrow_hover_bg_color' => ['type' => 'string', 'description' => 'Arrow Hover Background Color'],
        'mobile_arrow_hover_icon_color' => ['type' => 'string', 'description' => 'Arrow Hover Icon Color'],
        'mobile_outer_section_arrow' => ['type' => 'string', 'description' => 'Outer Content Arrow', 'enum' => ['yes', 'no']],
        'mobile_hover_show_arrow' => ['type' => 'string', 'description' => 'On Hover Arrow', 'enum' => ['yes', 'no']],
        'mobile_slider_rows' => ['type' => 'string', 'description' => 'Number Of Rows', 'enum' => ['1', '2', '3']],
        'mobile_center_mode' => ['type' => 'string', 'description' => 'Center Mode', 'enum' => ['yes', 'no']],
        'mobile_center_padding' => ['type' => 'object', 'description' => 'Center Padding'],
        'pnf_padding' => ['type' => 'object', 'description' => 'Padding'],
        'pnf_color' => ['type' => 'string', 'description' => 'Color'],
        'pnf_br' => ['type' => 'object', 'description' => 'Border Radius'],
        'messy_column' => ['type' => 'string', 'description' => 'Messy Columns', 'enum' => ['yes', 'no']],
        'desktop_column_1' => ['type' => 'object', 'description' => 'Column 1'],
        'desktop_column_2' => ['type' => 'object', 'description' => 'Column 2'],
        'desktop_column_3' => ['type' => 'object', 'description' => 'Column 3'],
        'desktop_column_4' => ['type' => 'object', 'description' => 'Column 4'],
        'desktop_column_5' => ['type' => 'object', 'description' => 'Column 5'],
        'desktop_column_6' => ['type' => 'object', 'description' => 'Column 6'],
        'settings'       => ['type' => 'object',  'description' => 'Raw Elementor control key/value pairs to merge. Also accepts Group Control settings.']
    ], 'required' => ['post_id', 'parent_id'], 'additionalProperties' => false],
    'output_schema' => ['type' => 'object', 'properties' => [
        'element_id'  => ['type' => 'string'],
        'widget_type' => ['type' => 'string'],
        'post_id'     => ['type' => 'integer'],
    ]],
    'execute_callback'    => 'tpaep_mcp_theplus_pro_blog_listout_ability',
    'permission_callback' => 'tpaep_mcp_theplus_pro_blog_listout_permission',
    'meta' => ['show_in_rest' => true, 'mcp' => ['public' => true, 'type' => 'tool']],
]);

function tpaep_mcp_theplus_pro_blog_listout_permission(?array $input = null): bool {
    if (!current_user_can('edit_posts')) { return false; }
    $post_id = absint($input['post_id'] ?? 0);
    if ($post_id > 0 && !current_user_can('edit_post', $post_id)) { return false; }
    return true;
}

function tpaep_mcp_theplus_pro_blog_listout_ability(array $input) {
    if (!tpaep_mcp_has_elementor()) { return new WP_Error('elementor_missing', __('Elementor must be active.', 'theplus')); }
    $widget_type = 'tp-blog-listout';
    if (!tpaep_mcp_has_registered_widget($widget_type)) { return new WP_Error('widget_missing', __('The Plus Blog Listout widget is not registered.', 'theplus')); }
    $post_id   = absint($input['post_id'] ?? 0);
    $parent_id = sanitize_text_field((string)($input['parent_id'] ?? ''));
    $position  = intval($input['position'] ?? -1);
    if ($post_id <= 0 || $parent_id === '') { return new WP_Error('missing_params', __('post_id and parent_id are required.', 'theplus')); }
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) { return new WP_Error('invalid_post', __('Target post was not found.', 'theplus')); }
    $page_data = tpaep_mcp_get_elementor_page_data($post_id);
    if (is_wp_error($page_data)) { return $page_data; }

$settings = [];
    if (isset($input['blogs_post_listing'])) { $settings['blogs_post_listing'] = sanitize_text_field($input['blogs_post_listing']); }
    if (isset($input['related_post_by'])) { $settings['related_post_by'] = sanitize_text_field($input['related_post_by']); }
    if (isset($input['style'])) { $settings['style'] = sanitize_text_field($input['style']); }
    if (isset($input['layout'])) { $settings['layout'] = sanitize_text_field($input['layout']); }
    if (isset($input['content_alignment'])) { $settings['content_alignment'] = sanitize_text_field($input['content_alignment']); }
    if (isset($input['content_alignment_3'])) { $settings['content_alignment_3'] = sanitize_text_field($input['content_alignment_3']); }
    if (isset($input['style_layout'])) { $settings['style_layout'] = sanitize_text_field($input['style_layout']); }
    if (isset($input['column_min_height'])) { $settings['column_min_height'] = $input['column_min_height']; }
    if (isset($input['content_html'])) { $settings['content_html'] = sanitize_text_field($input['content_html']); }
    if (isset($input['content_css'])) { $settings['content_css'] = sanitize_text_field($input['content_css']); }
    if (isset($input['display_posts'])) { $settings['display_posts'] = sanitize_text_field($input['display_posts']); }
    if (isset($input['post_offset'])) { $settings['post_offset'] = sanitize_text_field($input['post_offset']); }
    if (isset($input['post_category'])) { $settings['post_category'] = tpaep_mcp_sanitize_widget_setting_value($input['post_category']); }
    if (isset($input['post_tags'])) { $settings['post_tags'] = tpaep_mcp_sanitize_widget_setting_value($input['post_tags']); }
    if (isset($input['ex_cat'])) { $settings['ex_cat'] = tpaep_mcp_sanitize_widget_setting_value($input['ex_cat']); }
    if (isset($input['ex_tag'])) { $settings['ex_tag'] = tpaep_mcp_sanitize_widget_setting_value($input['ex_tag']); }
    if (isset($input['post_order_by'])) { $settings['post_order_by'] = sanitize_text_field($input['post_order_by']); }
    if (isset($input['post_order'])) { $settings['post_order'] = sanitize_text_field($input['post_order']); }
    if (isset($input['desktop_column'])) { $settings['desktop_column'] = sanitize_text_field($input['desktop_column']); }
    if (isset($input['tablet_column'])) { $settings['tablet_column'] = sanitize_text_field($input['tablet_column']); }
    if (isset($input['mobile_column'])) { $settings['mobile_column'] = sanitize_text_field($input['mobile_column']); }
    if (isset($input['metro_column'])) { $settings['metro_column'] = sanitize_text_field($input['metro_column']); }
    if (isset($input['metro_style_3'])) { $settings['metro_style_3'] = sanitize_text_field($input['metro_style_3']); }
    if (isset($input['metro_custom_col_3'])) { $settings['metro_custom_col_3'] = sanitize_text_field($input['metro_custom_col_3']); }
    if (isset($input['metro_style_4'])) { $settings['metro_style_4'] = sanitize_text_field($input['metro_style_4']); }
    if (isset($input['metro_custom_col_4'])) { $settings['metro_custom_col_4'] = sanitize_text_field($input['metro_custom_col_4']); }
    if (isset($input['metro_style_5'])) { $settings['metro_style_5'] = sanitize_text_field($input['metro_style_5']); }
    if (isset($input['metro_custom_col_5'])) { $settings['metro_custom_col_5'] = sanitize_text_field($input['metro_custom_col_5']); }
    if (isset($input['metro_style_6'])) { $settings['metro_style_6'] = sanitize_text_field($input['metro_style_6']); }
    if (isset($input['metro_custom_col_6'])) { $settings['metro_custom_col_6'] = sanitize_text_field($input['metro_custom_col_6']); }
    if (isset($input['responsive_tablet_metro'])) { $settings['responsive_tablet_metro'] = sanitize_text_field($input['responsive_tablet_metro']); }
    if (isset($input['tablet_metro_column'])) { $settings['tablet_metro_column'] = sanitize_text_field($input['tablet_metro_column']); }
    if (isset($input['tablet_metro_style_3'])) { $settings['tablet_metro_style_3'] = sanitize_text_field($input['tablet_metro_style_3']); }
    if (isset($input['metro_custom_col_tab'])) { $settings['metro_custom_col_tab'] = sanitize_text_field($input['metro_custom_col_tab']); }
    if (isset($input['columns_gap'])) { $settings['columns_gap'] = $input['columns_gap']; }
    if (isset($input['filter_category'])) { $settings['filter_category'] = sanitize_text_field($input['filter_category']); }
    if (isset($input['filter_category_align'])) { $settings['filter_category_align'] = sanitize_text_field($input['filter_category_align']); }
    if (isset($input['TaxonomyType'])) { $settings['TaxonomyType'] = sanitize_text_field($input['TaxonomyType']); }
    if (isset($input['filter_type'])) { $settings['filter_type'] = sanitize_text_field($input['filter_type']); }
    if (isset($input['filter_search_type'])) { $settings['filter_search_type'] = sanitize_text_field($input['filter_search_type']); }
    if (isset($input['all_filter_category_switch'])) { $settings['all_filter_category_switch'] = sanitize_text_field($input['all_filter_category_switch']); }
    if (isset($input['all_filter_category'])) { $settings['all_filter_category'] = sanitize_text_field($input['all_filter_category']); }
    if (isset($input['filter_style'])) { $settings['filter_style'] = sanitize_text_field($input['filter_style']); }
    if (isset($input['filter_hover_style'])) { $settings['filter_hover_style'] = sanitize_text_field($input['filter_hover_style']); }
    if (isset($input['post_extra_option'])) { $settings['post_extra_option'] = sanitize_text_field($input['post_extra_option']); }
    if (isset($input['pagination_next'])) { $settings['pagination_next'] = sanitize_text_field($input['pagination_next']); }
    if (isset($input['pagination_prev'])) { $settings['pagination_prev'] = sanitize_text_field($input['pagination_prev']); }
    if (isset($input['pagination_color'])) { $settings['pagination_color'] = sanitize_text_field($input['pagination_color']); }
    if (isset($input['pagination_hover_color'])) { $settings['pagination_hover_color'] = sanitize_text_field($input['pagination_hover_color']); }
    if (isset($input['load_more_btn_text'])) { $settings['load_more_btn_text'] = sanitize_text_field($input['load_more_btn_text']); }
    if (isset($input['tp_loading_text'])) { $settings['tp_loading_text'] = sanitize_text_field($input['tp_loading_text']); }
    if (isset($input['loaded_posts_text'])) { $settings['loaded_posts_text'] = sanitize_text_field($input['loaded_posts_text']); }
    if (isset($input['load_more_post'])) { $settings['load_more_post'] = sanitize_text_field($input['load_more_post']); }
    if (isset($input['load_more_border'])) { $settings['load_more_border'] = sanitize_text_field($input['load_more_border']); }
    if (isset($input['load_more_border_style'])) { $settings['load_more_border_style'] = sanitize_text_field($input['load_more_border_style']); }
    if (isset($input['load_more_border_width'])) { $settings['load_more_border_width'] = $input['load_more_border_width']; }
    if (isset($input['load_more_border_color'])) { $settings['load_more_border_color'] = sanitize_text_field($input['load_more_border_color']); }
    if (isset($input['load_more_border_radius'])) { $settings['load_more_border_radius'] = $input['load_more_border_radius']; }
    if (isset($input['load_more_border_hover_color'])) { $settings['load_more_border_hover_color'] = sanitize_text_field($input['load_more_border_hover_color']); }
    if (isset($input['load_more_border_hover_radius'])) { $settings['load_more_border_hover_radius'] = $input['load_more_border_hover_radius']; }
    if (isset($input['load_more_color'])) { $settings['load_more_color'] = sanitize_text_field($input['load_more_color']); }
    if (isset($input['loaded_posts_color'])) { $settings['loaded_posts_color'] = sanitize_text_field($input['loaded_posts_color']); }
    if (isset($input['loading_spin_color'])) { $settings['loading_spin_color'] = sanitize_text_field($input['loading_spin_color']); }
    if (isset($input['loading_spin_size'])) { $settings['loading_spin_size'] = $input['loading_spin_size']; }
    if (isset($input['loading_spin_border_size'])) { $settings['loading_spin_border_size'] = $input['loading_spin_border_size']; }
    if (isset($input['load_more_color_hover'])) { $settings['load_more_color_hover'] = sanitize_text_field($input['load_more_color_hover']); }
    if (isset($input['loading_options'])) { $settings['loading_options'] = sanitize_text_field($input['loading_options']); }
    if (isset($input['tp_list_preloader'])) { $settings['tp_list_preloader'] = sanitize_text_field($input['tp_list_preloader']); }
    if (isset($input['tp_list_preloader_hw'])) { $settings['tp_list_preloader_hw'] = $input['tp_list_preloader_hw']; }
    if (isset($input['tp_list_preloader_size'])) { $settings['tp_list_preloader_size'] = $input['tp_list_preloader_size']; }
    if (isset($input['tp_list_preloader_color'])) { $settings['tp_list_preloader_color'] = sanitize_text_field($input['tp_list_preloader_color']); }
    if (isset($input['display_title_limit'])) { $settings['display_title_limit'] = sanitize_text_field($input['display_title_limit']); }
    if (isset($input['display_title_by'])) { $settings['display_title_by'] = sanitize_text_field($input['display_title_by']); }
    if (isset($input['display_title_input'])) { $settings['display_title_input'] = sanitize_text_field($input['display_title_input']); }
    if (isset($input['display_title_3_dots'])) { $settings['display_title_3_dots'] = sanitize_text_field($input['display_title_3_dots']); }
    if (isset($input['filter_url'])) { $settings['filter_url'] = sanitize_text_field($input['filter_url']); }
    if (isset($input['post_title_tag'])) { $settings['post_title_tag'] = sanitize_text_field($input['post_title_tag']); }
    if (isset($input['featured_image_type'])) { $settings['featured_image_type'] = sanitize_text_field($input['featured_image_type']); }
    if (isset($input['title_desc_word_break'])) { $settings['title_desc_word_break'] = sanitize_text_field($input['title_desc_word_break']); }
    if (isset($input['display_post_category'])) { $settings['display_post_category'] = sanitize_text_field($input['display_post_category']); }
    if (isset($input['post_category_style'])) { $settings['post_category_style'] = sanitize_text_field($input['post_category_style']); }
    if (isset($input['display_post_category_all'])) { $settings['display_post_category_all'] = sanitize_text_field($input['display_post_category_all']); }
    if (isset($input['display_excerpt'])) { $settings['display_excerpt'] = sanitize_text_field($input['display_excerpt']); }
    if (isset($input['post_excerpt_count'])) { $settings['post_excerpt_count'] = sanitize_text_field($input['post_excerpt_count']); }
    if (isset($input['show_post_date'])) { $settings['show_post_date'] = sanitize_text_field($input['show_post_date']); }
    if (isset($input['show_post_author'])) { $settings['show_post_author'] = sanitize_text_field($input['show_post_author']); }
    if (isset($input['show_read_time'])) { $settings['show_read_time'] = sanitize_text_field($input['show_read_time']); }
    if (isset($input['display_thumbnail'])) { $settings['display_thumbnail'] = sanitize_text_field($input['display_thumbnail']); }
    if (isset($input['display_post_meta'])) { $settings['display_post_meta'] = sanitize_text_field($input['display_post_meta']); }
    if (isset($input['post_meta_tag_style'])) { $settings['post_meta_tag_style'] = sanitize_text_field($input['post_meta_tag_style']); }
    if (isset($input['author_prefix'])) { $settings['author_prefix'] = sanitize_text_field($input['author_prefix']); }
    if (isset($input['display_post_meta_date'])) { $settings['display_post_meta_date'] = sanitize_text_field($input['display_post_meta_date']); }
    if (isset($input['date_type'])) { $settings['date_type'] = sanitize_text_field($input['date_type']); }
    if (isset($input['display_post_meta_author'])) { $settings['display_post_meta_author'] = sanitize_text_field($input['display_post_meta_author']); }
    if (isset($input['display_post_meta_author_pic'])) { $settings['display_post_meta_author_pic'] = sanitize_text_field($input['display_post_meta_author_pic']); }
    if (isset($input['display_button'])) { $settings['display_button'] = sanitize_text_field($input['display_button']); }
    if (isset($input['button_style'])) { $settings['button_style'] = sanitize_text_field($input['button_style']); }
    if (isset($input['button_text'])) { $settings['button_text'] = sanitize_text_field($input['button_text']); }
    if (isset($input['button_icon_style'])) { $settings['button_icon_style'] = sanitize_text_field($input['button_icon_style']); }
    if (isset($input['button_icon'])) { $settings['button_icon'] = sanitize_text_field($input['button_icon']); }
    if (isset($input['button_icons_mind'])) { $settings['button_icons_mind'] = sanitize_text_field($input['button_icons_mind']); }
    if (isset($input['before_after'])) { $settings['before_after'] = sanitize_text_field($input['before_after']); }
    if (isset($input['icon_spacing'])) { $settings['icon_spacing'] = $input['icon_spacing']; }
    if (isset($input['tpaep_theme_builder'])) { $settings['tpaep_theme_builder'] = sanitize_text_field($input['tpaep_theme_builder']); }
    if (isset($input['post_meta_color'])) { $settings['post_meta_color'] = sanitize_text_field($input['post_meta_color']); }
    if (isset($input['post_meta_color_hover'])) { $settings['post_meta_color_hover'] = sanitize_text_field($input['post_meta_color_hover']); }
    if (isset($input['post_meta_border_color'])) { $settings['post_meta_border_color'] = sanitize_text_field($input['post_meta_border_color']); }
    if (isset($input['blog_card_layout'])) { $settings['blog_card_layout'] = sanitize_text_field($input['blog_card_layout']); }
    if (isset($input['wrap_flex_direction'])) { $settings['wrap_flex_direction'] = $input['wrap_flex_direction']; }
    if (isset($input['tp_row_one_width'])) { $settings['tp_row_one_width'] = $input['tp_row_one_width']; }
    if (isset($input['tp_row_two_width'])) { $settings['tp_row_two_width'] = $input['tp_row_two_width']; }
    if (isset($input['tp_content_alignment'])) { $settings['tp_content_alignment'] = $input['tp_content_alignment']; }
    if (isset($input['tp_item_content_alignment'])) { $settings['tp_item_content_alignment'] = $input['tp_item_content_alignment']; }
    if (isset($input['wrap_gap'])) { $settings['wrap_gap'] = $input['wrap_gap']; }
    if (isset($input['tp_absolute_layout'])) { $settings['tp_absolute_layout'] = sanitize_text_field($input['tp_absolute_layout']); }
    if (isset($input['tp_top_card'])) { $settings['tp_top_card'] = $input['tp_top_card']; }
    if (isset($input['tp_bottom_card'])) { $settings['tp_bottom_card'] = $input['tp_bottom_card']; }
    if (isset($input['tp_width_card'])) { $settings['tp_width_card'] = $input['tp_width_card']; }
    if (isset($input['content_direction'])) { $settings['content_direction'] = $input['content_direction']; }
    if (isset($input['content_vertical_justify'])) { $settings['content_vertical_justify'] = $input['content_vertical_justify']; }
    if (isset($input['blog_content_padding'])) { $settings['blog_content_padding'] = $input['blog_content_padding']; }
    if (isset($input['blog_content_margin'])) { $settings['blog_content_margin'] = $input['blog_content_margin']; }
    if (isset($input['blog_border_post'])) { $settings['blog_border_post'] = sanitize_text_field($input['blog_border_post']); }
    if (isset($input['blog_content_border_radius'])) { $settings['blog_content_border_radius'] = $input['blog_content_border_radius']; }
    if (isset($input['blog_meta_layout_post'])) { $settings['blog_meta_layout_post'] = sanitize_text_field($input['blog_meta_layout_post']); }
    if (isset($input['meta_flex_direction'])) { $settings['meta_flex_direction'] = sanitize_text_field($input['meta_flex_direction']); }
    if (isset($input['meta_align_items'])) { $settings['meta_align_items'] = $input['meta_align_items']; }
    if (isset($input['meta_gap'])) { $settings['meta_gap'] = $input['meta_gap']; }
    if (isset($input['tp_meta_inner_padding'])) { $settings['tp_meta_inner_padding'] = $input['tp_meta_inner_padding']; }
    if (isset($input['tp_meta_border_r'])) { $settings['tp_meta_border_r'] = $input['tp_meta_border_r']; }
    if (isset($input['date_overflow'])) { $settings['date_overflow'] = sanitize_text_field($input['date_overflow']); }
    if (isset($input['category_date_inner_padding'])) { $settings['category_date_inner_padding'] = $input['category_date_inner_padding']; }
    if (isset($input['date_style_margin_tb'])) { $settings['date_style_margin_tb'] = $input['date_style_margin_tb']; }
    if (isset($input['date_style_margin_lr'])) { $settings['date_style_margin_lr'] = $input['date_style_margin_lr']; }
    if (isset($input['overflow_date_br'])) { $settings['overflow_date_br'] = $input['overflow_date_br']; }
    if (isset($input['meta_overflow'])) { $settings['meta_overflow'] = sanitize_text_field($input['meta_overflow']); }
    if (isset($input['category_meta_inner_padding'])) { $settings['category_meta_inner_padding'] = $input['category_meta_inner_padding']; }
    if (isset($input['meta_style_margin_tb'])) { $settings['meta_style_margin_tb'] = $input['meta_style_margin_tb']; }
    if (isset($input['meta_style_margin_lr'])) { $settings['meta_style_margin_lr'] = $input['meta_style_margin_lr']; }
    if (isset($input['overflow_meta_br'])) { $settings['overflow_meta_br'] = $input['overflow_meta_br']; }
    if (isset($input['post_tima_overflow'])) { $settings['post_tima_overflow'] = sanitize_text_field($input['post_tima_overflow']); }
    if (isset($input['category_post_time_inner_padding'])) { $settings['category_post_time_inner_padding'] = $input['category_post_time_inner_padding']; }
    if (isset($input['post_style_margin_tb'])) { $settings['post_style_margin_tb'] = $input['post_style_margin_tb']; }
    if (isset($input['post_style_margin_lr'])) { $settings['post_style_margin_lr'] = $input['post_style_margin_lr']; }
    if (isset($input['overflow_post_time_br'])) { $settings['overflow_post_time_br'] = $input['overflow_post_time_br']; }
    if (isset($input['button_overflow'])) { $settings['button_overflow'] = sanitize_text_field($input['button_overflow']); }
    if (isset($input['button_style_margin_tb'])) { $settings['button_style_margin_tb'] = $input['button_style_margin_tb']; }
    if (isset($input['button_style_margin_lr'])) { $settings['button_style_margin_lr'] = $input['button_style_margin_lr']; }
    if (isset($input['blog_category_post'])) { $settings['blog_category_post'] = sanitize_text_field($input['blog_category_post']); }
    if (isset($input['category_style_margin_tb'])) { $settings['category_style_margin_tb'] = $input['category_style_margin_tb']; }
    if (isset($input['category_style_margin_lr'])) { $settings['category_style_margin_lr'] = $input['category_style_margin_lr']; }
    if (isset($input['category_inner_padding'])) { $settings['category_inner_padding'] = $input['category_inner_padding']; }
    if (isset($input['category_color'])) { $settings['category_color'] = sanitize_text_field($input['category_color']); }
    if (isset($input['category_hover_color'])) { $settings['category_hover_color'] = sanitize_text_field($input['category_hover_color']); }
    if (isset($input['category_2_border_hover_color'])) { $settings['category_2_border_hover_color'] = sanitize_text_field($input['category_2_border_hover_color']); }
    if (isset($input['category_border'])) { $settings['category_border'] = sanitize_text_field($input['category_border']); }
    if (isset($input['category_border_style'])) { $settings['category_border_style'] = sanitize_text_field($input['category_border_style']); }
    if (isset($input['box_category_border_width'])) { $settings['box_category_border_width'] = $input['box_category_border_width']; }
    if (isset($input['category_border_color'])) { $settings['category_border_color'] = sanitize_text_field($input['category_border_color']); }
    if (isset($input['category_border_radius'])) { $settings['category_border_radius'] = $input['category_border_radius']; }
    if (isset($input['category_border_hover_color'])) { $settings['category_border_hover_color'] = sanitize_text_field($input['category_border_hover_color']); }
    if (isset($input['category_border_hover_radius'])) { $settings['category_border_hover_radius'] = $input['category_border_hover_radius']; }
    if (isset($input['s_title_pg'])) { $settings['s_title_pg'] = $input['s_title_pg']; }
    if (isset($input['title_margin'])) { $settings['title_margin'] = $input['title_margin']; }
    if (isset($input['title_color'])) { $settings['title_color'] = sanitize_text_field($input['title_color']); }
    if (isset($input['title_hover_color'])) { $settings['title_hover_color'] = sanitize_text_field($input['title_hover_color']); }
    if (isset($input['title_boxhover_color'])) { $settings['title_boxhover_color'] = sanitize_text_field($input['title_boxhover_color']); }
    if (isset($input['s_excerpt_content_pg'])) { $settings['s_excerpt_content_pg'] = $input['s_excerpt_content_pg']; }
    if (isset($input['excerpt_margin'])) { $settings['excerpt_margin'] = $input['excerpt_margin']; }
    if (isset($input['excerpt_color'])) { $settings['excerpt_color'] = sanitize_text_field($input['excerpt_color']); }
    if (isset($input['excerpt_hover_color'])) { $settings['excerpt_hover_color'] = sanitize_text_field($input['excerpt_hover_color']); }
    if (isset($input['content_between_space'])) { $settings['content_between_space'] = $input['content_between_space']; }
    if (isset($input['blog_featured_image_width'])) { $settings['blog_featured_image_width'] = $input['blog_featured_image_width']; }
    if (isset($input['blog_featured_image_height'])) { $settings['blog_featured_image_height'] = $input['blog_featured_image_height']; }
    if (isset($input['hover_image_style'])) { $settings['hover_image_style'] = sanitize_text_field($input['hover_image_style']); }
    if (isset($input['featured_image_radius'])) { $settings['featured_image_radius'] = $input['featured_image_radius']; }
    if (isset($input['tpae_enable_overlay'])) { $settings['tpae_enable_overlay'] = sanitize_text_field($input['tpae_enable_overlay']); }
    if (isset($input['tpae_overlay_color'])) { $settings['tpae_overlay_color'] = sanitize_text_field($input['tpae_overlay_color']); }
    if (isset($input['full_image_size'])) { $settings['full_image_size'] = sanitize_text_field($input['full_image_size']); }
    if (isset($input['full_image_size_min_height'])) { $settings['full_image_size_min_height'] = $input['full_image_size_min_height']; }
    if (isset($input['button_padding'])) { $settings['button_padding'] = $input['button_padding']; }
    if (isset($input['btn_text_color'])) { $settings['btn_text_color'] = sanitize_text_field($input['btn_text_color']); }
    if (isset($input['button_border_style'])) { $settings['button_border_style'] = sanitize_text_field($input['button_border_style']); }
    if (isset($input['button_border_width'])) { $settings['button_border_width'] = $input['button_border_width']; }
    if (isset($input['button_border_color'])) { $settings['button_border_color'] = sanitize_text_field($input['button_border_color']); }
    if (isset($input['button_radius'])) { $settings['button_radius'] = $input['button_radius']; }
    if (isset($input['btn_text_hover_color'])) { $settings['btn_text_hover_color'] = sanitize_text_field($input['btn_text_hover_color']); }
    if (isset($input['button_border_hover_color'])) { $settings['button_border_hover_color'] = sanitize_text_field($input['button_border_hover_color']); }
    if (isset($input['button_hover_radius'])) { $settings['button_hover_radius'] = $input['button_hover_radius']; }
    if (isset($input['filter_category_padding'])) { $settings['filter_category_padding'] = $input['filter_category_padding']; }
    if (isset($input['filter_category_marign'])) { $settings['filter_category_marign'] = $input['filter_category_marign']; }
    if (isset($input['filters_text_color'])) { $settings['filters_text_color'] = sanitize_text_field($input['filters_text_color']); }
    if (isset($input['filter_category_color'])) { $settings['filter_category_color'] = sanitize_text_field($input['filter_category_color']); }
    if (isset($input['filter_category_4_border_color'])) { $settings['filter_category_4_border_color'] = sanitize_text_field($input['filter_category_4_border_color']); }
    if (isset($input['filter_category_radius'])) { $settings['filter_category_radius'] = $input['filter_category_radius']; }
    if (isset($input['filter_category_hover_color'])) { $settings['filter_category_hover_color'] = sanitize_text_field($input['filter_category_hover_color']); }
    if (isset($input['filter_category_hover_radius'])) { $settings['filter_category_hover_radius'] = $input['filter_category_hover_radius']; }
    if (isset($input['filter_border_hover_color'])) { $settings['filter_border_hover_color'] = sanitize_text_field($input['filter_border_hover_color']); }
    if (isset($input['category_count_color'])) { $settings['category_count_color'] = sanitize_text_field($input['category_count_color']); }
    if (isset($input['category_count_bg_color'])) { $settings['category_count_bg_color'] = sanitize_text_field($input['category_count_bg_color']); }
    if (isset($input['content_inner_padding'])) { $settings['content_inner_padding'] = $input['content_inner_padding']; }
    if (isset($input['box_border'])) { $settings['box_border'] = sanitize_text_field($input['box_border']); }
    if (isset($input['border_style'])) { $settings['border_style'] = sanitize_text_field($input['border_style']); }
    if (isset($input['box_border_width'])) { $settings['box_border_width'] = $input['box_border_width']; }
    if (isset($input['box_border_color'])) { $settings['box_border_color'] = sanitize_text_field($input['box_border_color']); }
    if (isset($input['border_radius'])) { $settings['border_radius'] = $input['border_radius']; }
    if (isset($input['box_border_hover_color'])) { $settings['box_border_hover_color'] = sanitize_text_field($input['box_border_hover_color']); }
    if (isset($input['border_hover_radius'])) { $settings['border_hover_radius'] = $input['border_hover_radius']; }
    if (isset($input['carousel_unique_id'])) { $settings['carousel_unique_id'] = sanitize_text_field($input['carousel_unique_id']); }
    if (isset($input['slider_direction'])) { $settings['slider_direction'] = sanitize_text_field($input['slider_direction']); }
    if (isset($input['carousel_direction'])) { $settings['carousel_direction'] = sanitize_text_field($input['carousel_direction']); }
    if (isset($input['slide_speed'])) { $settings['slide_speed'] = $input['slide_speed']; }
    if (isset($input['slider_desktop_column'])) { $settings['slider_desktop_column'] = sanitize_text_field($input['slider_desktop_column']); }
    if (isset($input['steps_slide'])) { $settings['steps_slide'] = sanitize_text_field($input['steps_slide']); }
    if (isset($input['slider_padding'])) { $settings['slider_padding'] = $input['slider_padding']; }
    if (isset($input['slider_draggable'])) { $settings['slider_draggable'] = sanitize_text_field($input['slider_draggable']); }
    if (isset($input['multi_drag'])) { $settings['multi_drag'] = sanitize_text_field($input['multi_drag']); }
    if (isset($input['slider_infinite'])) { $settings['slider_infinite'] = sanitize_text_field($input['slider_infinite']); }
    if (isset($input['slider_pause_hover'])) { $settings['slider_pause_hover'] = sanitize_text_field($input['slider_pause_hover']); }
    if (isset($input['slider_adaptive_height'])) { $settings['slider_adaptive_height'] = sanitize_text_field($input['slider_adaptive_height']); }
    if (isset($input['slider_animation'])) { $settings['slider_animation'] = sanitize_text_field($input['slider_animation']); }
    if (isset($input['slider_autoplay'])) { $settings['slider_autoplay'] = sanitize_text_field($input['slider_autoplay']); }
    if (isset($input['autoplay_speed'])) { $settings['autoplay_speed'] = $input['autoplay_speed']; }
    if (isset($input['slider_dots'])) { $settings['slider_dots'] = sanitize_text_field($input['slider_dots']); }
    if (isset($input['slider_dots_style'])) { $settings['slider_dots_style'] = sanitize_text_field($input['slider_dots_style']); }
    if (isset($input['dots_border_color'])) { $settings['dots_border_color'] = sanitize_text_field($input['dots_border_color']); }
    if (isset($input['dots_bg_color'])) { $settings['dots_bg_color'] = sanitize_text_field($input['dots_bg_color']); }
    if (isset($input['dots_active_border_color'])) { $settings['dots_active_border_color'] = sanitize_text_field($input['dots_active_border_color']); }
    if (isset($input['dots_active_bg_color'])) { $settings['dots_active_bg_color'] = sanitize_text_field($input['dots_active_bg_color']); }
    if (isset($input['dots_top_padding'])) { $settings['dots_top_padding'] = $input['dots_top_padding']; }
    if (isset($input['hover_show_dots'])) { $settings['hover_show_dots'] = sanitize_text_field($input['hover_show_dots']); }
    if (isset($input['slider_arrows'])) { $settings['slider_arrows'] = sanitize_text_field($input['slider_arrows']); }
    if (isset($input['slider_arrows_style'])) { $settings['slider_arrows_style'] = sanitize_text_field($input['slider_arrows_style']); }
    if (isset($input['arrows_position'])) { $settings['arrows_position'] = sanitize_text_field($input['arrows_position']); }
    if (isset($input['arrow_bg_color'])) { $settings['arrow_bg_color'] = sanitize_text_field($input['arrow_bg_color']); }
    if (isset($input['arrow_icon_color'])) { $settings['arrow_icon_color'] = sanitize_text_field($input['arrow_icon_color']); }
    if (isset($input['arrow_hover_bg_color'])) { $settings['arrow_hover_bg_color'] = sanitize_text_field($input['arrow_hover_bg_color']); }
    if (isset($input['arrow_hover_icon_color'])) { $settings['arrow_hover_icon_color'] = sanitize_text_field($input['arrow_hover_icon_color']); }
    if (isset($input['outer_section_arrow'])) { $settings['outer_section_arrow'] = sanitize_text_field($input['outer_section_arrow']); }
    if (isset($input['hover_show_arrow'])) { $settings['hover_show_arrow'] = sanitize_text_field($input['hover_show_arrow']); }
    if (isset($input['slider_center_mode'])) { $settings['slider_center_mode'] = sanitize_text_field($input['slider_center_mode']); }
    if (isset($input['center_padding'])) { $settings['center_padding'] = $input['center_padding']; }
    if (isset($input['slider_center_effects'])) { $settings['slider_center_effects'] = sanitize_text_field($input['slider_center_effects']); }
    if (isset($input['scale_center_slide'])) { $settings['scale_center_slide'] = $input['scale_center_slide']; }
    if (isset($input['scale_normal_slide'])) { $settings['scale_normal_slide'] = $input['scale_normal_slide']; }
    if (isset($input['opacity_normal_slide'])) { $settings['opacity_normal_slide'] = $input['opacity_normal_slide']; }
    if (isset($input['slider_rows'])) { $settings['slider_rows'] = sanitize_text_field($input['slider_rows']); }
    if (isset($input['slide_row_top_space'])) { $settings['slide_row_top_space'] = $input['slide_row_top_space']; }
    if (isset($input['slider_tablet_column'])) { $settings['slider_tablet_column'] = sanitize_text_field($input['slider_tablet_column']); }
    if (isset($input['tablet_steps_slide'])) { $settings['tablet_steps_slide'] = sanitize_text_field($input['tablet_steps_slide']); }
    if (isset($input['slider_responsive_tablet'])) { $settings['slider_responsive_tablet'] = sanitize_text_field($input['slider_responsive_tablet']); }
    if (isset($input['tablet_slider_draggable'])) { $settings['tablet_slider_draggable'] = sanitize_text_field($input['tablet_slider_draggable']); }
    if (isset($input['tablet_slider_infinite'])) { $settings['tablet_slider_infinite'] = sanitize_text_field($input['tablet_slider_infinite']); }
    if (isset($input['tablet_slider_autoplay'])) { $settings['tablet_slider_autoplay'] = sanitize_text_field($input['tablet_slider_autoplay']); }
    if (isset($input['tablet_autoplay_speed'])) { $settings['tablet_autoplay_speed'] = $input['tablet_autoplay_speed']; }
    if (isset($input['tablet_slider_dots'])) { $settings['tablet_slider_dots'] = sanitize_text_field($input['tablet_slider_dots']); }
    if (isset($input['tablet_slider_dots_style'])) { $settings['tablet_slider_dots_style'] = sanitize_text_field($input['tablet_slider_dots_style']); }
    if (isset($input['tablet_dots_border_color'])) { $settings['tablet_dots_border_color'] = sanitize_text_field($input['tablet_dots_border_color']); }
    if (isset($input['tablet_dots_bg_color'])) { $settings['tablet_dots_bg_color'] = sanitize_text_field($input['tablet_dots_bg_color']); }
    if (isset($input['tablet_dots_active_border_color'])) { $settings['tablet_dots_active_border_color'] = sanitize_text_field($input['tablet_dots_active_border_color']); }
    if (isset($input['tablet_dots_active_bg_color'])) { $settings['tablet_dots_active_bg_color'] = sanitize_text_field($input['tablet_dots_active_bg_color']); }
    if (isset($input['tablet_dots_top_padding'])) { $settings['tablet_dots_top_padding'] = $input['tablet_dots_top_padding']; }
    if (isset($input['tablet_hover_show_dots'])) { $settings['tablet_hover_show_dots'] = sanitize_text_field($input['tablet_hover_show_dots']); }
    if (isset($input['tablet_slider_arrows'])) { $settings['tablet_slider_arrows'] = sanitize_text_field($input['tablet_slider_arrows']); }
    if (isset($input['tablet_slider_arrows_style'])) { $settings['tablet_slider_arrows_style'] = sanitize_text_field($input['tablet_slider_arrows_style']); }
    if (isset($input['tablet_arrows_position'])) { $settings['tablet_arrows_position'] = sanitize_text_field($input['tablet_arrows_position']); }
    if (isset($input['tablet_arrow_bg_color'])) { $settings['tablet_arrow_bg_color'] = sanitize_text_field($input['tablet_arrow_bg_color']); }
    if (isset($input['tablet_arrow_icon_color'])) { $settings['tablet_arrow_icon_color'] = sanitize_text_field($input['tablet_arrow_icon_color']); }
    if (isset($input['tablet_arrow_hover_bg_color'])) { $settings['tablet_arrow_hover_bg_color'] = sanitize_text_field($input['tablet_arrow_hover_bg_color']); }
    if (isset($input['tablet_arrow_hover_icon_color'])) { $settings['tablet_arrow_hover_icon_color'] = sanitize_text_field($input['tablet_arrow_hover_icon_color']); }
    if (isset($input['tablet_outer_section_arrow'])) { $settings['tablet_outer_section_arrow'] = sanitize_text_field($input['tablet_outer_section_arrow']); }
    if (isset($input['tablet_hover_show_arrow'])) { $settings['tablet_hover_show_arrow'] = sanitize_text_field($input['tablet_hover_show_arrow']); }
    if (isset($input['tablet_slider_rows'])) { $settings['tablet_slider_rows'] = sanitize_text_field($input['tablet_slider_rows']); }
    if (isset($input['tablet_center_mode'])) { $settings['tablet_center_mode'] = sanitize_text_field($input['tablet_center_mode']); }
    if (isset($input['tablet_center_padding'])) { $settings['tablet_center_padding'] = $input['tablet_center_padding']; }
    if (isset($input['slider_mobile_column'])) { $settings['slider_mobile_column'] = sanitize_text_field($input['slider_mobile_column']); }
    if (isset($input['mobile_steps_slide'])) { $settings['mobile_steps_slide'] = sanitize_text_field($input['mobile_steps_slide']); }
    if (isset($input['slider_responsive_mobile'])) { $settings['slider_responsive_mobile'] = sanitize_text_field($input['slider_responsive_mobile']); }
    if (isset($input['mobile_slider_draggable'])) { $settings['mobile_slider_draggable'] = sanitize_text_field($input['mobile_slider_draggable']); }
    if (isset($input['mobile_slider_infinite'])) { $settings['mobile_slider_infinite'] = sanitize_text_field($input['mobile_slider_infinite']); }
    if (isset($input['mobile_slider_autoplay'])) { $settings['mobile_slider_autoplay'] = sanitize_text_field($input['mobile_slider_autoplay']); }
    if (isset($input['mobile_autoplay_speed'])) { $settings['mobile_autoplay_speed'] = $input['mobile_autoplay_speed']; }
    if (isset($input['mobile_slider_dots'])) { $settings['mobile_slider_dots'] = sanitize_text_field($input['mobile_slider_dots']); }
    if (isset($input['mobile_slider_dots_style'])) { $settings['mobile_slider_dots_style'] = sanitize_text_field($input['mobile_slider_dots_style']); }
    if (isset($input['mobile_dots_border_color'])) { $settings['mobile_dots_border_color'] = sanitize_text_field($input['mobile_dots_border_color']); }
    if (isset($input['mobile_dots_bg_color'])) { $settings['mobile_dots_bg_color'] = sanitize_text_field($input['mobile_dots_bg_color']); }
    if (isset($input['mobile_dots_active_border_color'])) { $settings['mobile_dots_active_border_color'] = sanitize_text_field($input['mobile_dots_active_border_color']); }
    if (isset($input['mobile_dots_active_bg_color'])) { $settings['mobile_dots_active_bg_color'] = sanitize_text_field($input['mobile_dots_active_bg_color']); }
    if (isset($input['mobile_dots_top_padding'])) { $settings['mobile_dots_top_padding'] = $input['mobile_dots_top_padding']; }
    if (isset($input['mobile_hover_show_dots'])) { $settings['mobile_hover_show_dots'] = sanitize_text_field($input['mobile_hover_show_dots']); }
    if (isset($input['mobile_slider_arrows'])) { $settings['mobile_slider_arrows'] = sanitize_text_field($input['mobile_slider_arrows']); }
    if (isset($input['mobile_slider_arrows_style'])) { $settings['mobile_slider_arrows_style'] = sanitize_text_field($input['mobile_slider_arrows_style']); }
    if (isset($input['mobile_arrows_position'])) { $settings['mobile_arrows_position'] = sanitize_text_field($input['mobile_arrows_position']); }
    if (isset($input['mobile_arrow_bg_color'])) { $settings['mobile_arrow_bg_color'] = sanitize_text_field($input['mobile_arrow_bg_color']); }
    if (isset($input['mobile_arrow_icon_color'])) { $settings['mobile_arrow_icon_color'] = sanitize_text_field($input['mobile_arrow_icon_color']); }
    if (isset($input['mobile_arrow_hover_bg_color'])) { $settings['mobile_arrow_hover_bg_color'] = sanitize_text_field($input['mobile_arrow_hover_bg_color']); }
    if (isset($input['mobile_arrow_hover_icon_color'])) { $settings['mobile_arrow_hover_icon_color'] = sanitize_text_field($input['mobile_arrow_hover_icon_color']); }
    if (isset($input['mobile_outer_section_arrow'])) { $settings['mobile_outer_section_arrow'] = sanitize_text_field($input['mobile_outer_section_arrow']); }
    if (isset($input['mobile_hover_show_arrow'])) { $settings['mobile_hover_show_arrow'] = sanitize_text_field($input['mobile_hover_show_arrow']); }
    if (isset($input['mobile_slider_rows'])) { $settings['mobile_slider_rows'] = sanitize_text_field($input['mobile_slider_rows']); }
    if (isset($input['mobile_center_mode'])) { $settings['mobile_center_mode'] = sanitize_text_field($input['mobile_center_mode']); }
    if (isset($input['mobile_center_padding'])) { $settings['mobile_center_padding'] = $input['mobile_center_padding']; }
    if (isset($input['pnf_padding'])) { $settings['pnf_padding'] = $input['pnf_padding']; }
    if (isset($input['pnf_color'])) { $settings['pnf_color'] = sanitize_text_field($input['pnf_color']); }
    if (isset($input['pnf_br'])) { $settings['pnf_br'] = $input['pnf_br']; }
    if (isset($input['messy_column'])) { $settings['messy_column'] = sanitize_text_field($input['messy_column']); }
    if (isset($input['desktop_column_1'])) { $settings['desktop_column_1'] = $input['desktop_column_1']; }
    if (isset($input['desktop_column_2'])) { $settings['desktop_column_2'] = $input['desktop_column_2']; }
    if (isset($input['desktop_column_3'])) { $settings['desktop_column_3'] = $input['desktop_column_3']; }
    if (isset($input['desktop_column_4'])) { $settings['desktop_column_4'] = $input['desktop_column_4']; }
    if (isset($input['desktop_column_5'])) { $settings['desktop_column_5'] = $input['desktop_column_5']; }
    if (isset($input['desktop_column_6'])) { $settings['desktop_column_6'] = $input['desktop_column_6']; }

    $settings = tpaep_mcp_merge_widget_settings($settings, $input['settings'] ?? []);
    $widget = [
        'id'         => tpaep_mcp_generate_elementor_element_id(),
        'elType'     => 'widget',
        'widgetType' => $widget_type,
        'isInner'    => false,
        'settings'   => $settings,
        'elements'   => [],
    ];
    if (!tpaep_mcp_insert_elementor_element($page_data, $parent_id, $widget, $position)) { return new WP_Error('parent_not_found', __('Parent container not found.', 'theplus')); }
    $save_result = tpaep_mcp_save_elementor_page_data($post_id, $page_data);
    if (is_wp_error($save_result)) { return $save_result; }
    return ['element_id' => $widget['id'], 'widget_type' => $widget_type, 'post_id' => $post_id];
}
