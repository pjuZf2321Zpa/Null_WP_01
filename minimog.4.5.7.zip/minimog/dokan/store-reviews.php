<?php
/**
 * The Template for displaying all reviews.
 *
 * @package       dokan
 * @package       dokan - 2014 1.0
 *
 * @theme-version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$store_user      = get_userdata( get_query_var( 'author' ) );
$store_info      = dokan_get_store_info( $store_user->ID );
$map_location    = isset( $store_info['location'] ) ? esc_attr( $store_info['location'] ) : '';
$layout          = get_theme_mod( 'store_layout', 'left' );
$container_class = Minimog_Site_Layout::instance()->get_container_class( Minimog::setting( 'single_store_site_layout' ) );

get_header( 'shop' );
?>
<div id="page-content" class="page-content">
	<div class="<?php echo esc_attr( $container_class ); ?>">

		<?php dokan_get_template_part( 'store-header' ); ?>

		<div class="row">

			<?php Minimog_Sidebar::instance()->render( 'left' ); ?>

			<div id="page-main-content" class="page-main-content">

				<?php dokan_get_template_part( 'custom/store-tabs' ); ?>

				<div class="dokan-store-wrap layout-<?php echo esc_attr( $layout ); ?>">
					<div id="dokan-primary" class="dokan-single-store">
						<div id="dokan-content" class="store-review-wrap woocommerce" role="main">
							<?php
							/**
							 * This template is only reachable through the Dokan Pro Store Reviews module,
							 * but stay defensive: a Pro deactivation must not fatal the store page.
							 *
							 * `review` is resolved by the Dokan Pro container through `__get()`, which has
							 * no matching `__isset()`, so `isset()` would report false even when the
							 * service exists. Read the property and null check the result instead.
							 */
							$dokan_template_reviews = function_exists( 'dokan_pro' ) ? dokan_pro()->review : null;

							/**
							 * Template files run in the global scope, so keep these prefixed: plain
							 * `$post_type`, `$status` and `$comments` would clobber WordPress globals.
							 */
							if ( is_object( $dokan_template_reviews ) ) :
								$minimog_review_post_type = 'product';
								$minimog_review_limit     = 20;
								$minimog_review_status    = '1';
								$minimog_review_comments  = $dokan_template_reviews->comment_query( $store_user->ID, $minimog_review_post_type, $minimog_review_limit, $minimog_review_status );
								?>

								<div id="reviews">
									<div id="comments">

										<?php do_action( 'dokan_review_tab_before_comments' ); ?>

										<h2 class="headline"><?php esc_html_e( 'Vendor Review', 'minimog' ); ?></h2>

										<ol class="commentlist">
											<?php
											/**
											 * Comment list markup rendered by Dokan Pro. Running it through
											 * `wp_kses_post()` would silently drop attributes the module
											 * relies on, so print the trusted plugin output as is.
											 */
											// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
											echo $dokan_template_reviews->render_store_tab_comment_list( $minimog_review_comments, $store_user->ID );
											?>
										</ol>

									</div>
								</div>

								<?php
								$dokan_modules = dokan_pro()->module;

								// Pagination markup rendered by Dokan Pro, printed as is like the comment list above.
								// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
								if ( is_object( $dokan_modules ) && $dokan_modules->is_active( 'store_reviews' ) ) {
									echo $dokan_template_reviews->review_pagination( $store_user->ID, $minimog_review_post_type, $minimog_review_limit, $minimog_review_status );
								} else {
									// Read-only pagination argument, no state change.
									$minimog_review_pagenum = isset( $_REQUEST['pagenum'] ) ? absint( wp_unslash( $_REQUEST['pagenum'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

									echo $dokan_template_reviews->review_pagination_with_query( $store_user->ID, $minimog_review_post_type, $minimog_review_limit, $minimog_review_status, $minimog_review_pagenum );
								}
								// phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
							<?php else : ?>
								<p class="dokan-info"><?php esc_html_e( 'No review found!', 'minimog' ); ?></p>
							<?php endif; ?>
						</div><!-- #content .site-content -->
					</div><!-- .dokan-single-store -->
				</div><!-- .dokan-store-wrap -->
			</div>

			<?php Minimog_Sidebar::instance()->render( 'right' ); ?>

		</div>
	</div>
</div>

<?php get_footer( 'shop' ); ?>
