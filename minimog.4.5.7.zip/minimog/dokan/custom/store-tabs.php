<?php
/**
 * The Template for displaying store tabs
 *
 * @theme-version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

$store_user = dokan()->vendor->get( get_query_var( 'author' ) );
$store_tabs = dokan_get_store_tabs( $store_user->get_id() );

if ( empty( $store_tabs ) ) {
	return;
}

global $wp;
$current_url = isset( $wp->request ) ? home_url( $wp->request ) : '';
?>
<div id="dokan-store-tabs-wrap" class="dokan-store-tabs-wrap">
	<div class="dokan-store-tabs">
		<ul class="dokan-list-inline">
			<?php
			// Template files run in the global scope, so a plain `$tab` would clobber a WordPress global.
			foreach ( $store_tabs as $minimog_store_tab ) :
				if ( empty( $minimog_store_tab['url'] ) ) {
					continue;
				}

				$minimog_tab_classes = array( 'store-tab-item' );

				if ( rtrim( $minimog_store_tab['url'], '/' ) === $current_url ) {
					$minimog_tab_classes[] = 'active';
				}
				?>
				<li class="<?php echo esc_attr( implode( ' ', $minimog_tab_classes ) ); ?>">
					<a href="<?php echo esc_url( $minimog_store_tab['url'] ); ?>"><?php echo esc_html( $minimog_store_tab['title'] ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>
