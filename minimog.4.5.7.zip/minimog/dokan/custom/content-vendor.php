<?php
/**
 * The template for displaying vendor content within loops
 *
 * @package Minimog/Dokan/Templates
 * @version 1.0.0
 *
 * @var array $args Template arguments, holds the `seller` WP_User.
 */

defined( 'ABSPATH' ) || exit;

$seller = $args['seller'];

/**
 * @var \WeDevs\Dokan\Vendor\Vendor $vendor
 */
$vendor            = dokan()->vendor->get( $seller->ID );
$store_banner_id   = $vendor->get_banner_id();
$store_name        = $vendor->get_shop_name();
$store_url         = $vendor->get_shop_url();
$store_rating      = $vendor->get_rating();
$is_store_featured = $vendor->is_featured();
$store_phone       = $vendor->get_phone();
$store_email       = $vendor->get_email();
$store_info        = dokan_get_store_info( $seller->ID );
$store_address     = dokan_get_seller_short_address( $seller->ID, false );

$store_banner_width   = 480;
$store_banner_height  = 308;
$store_default_banner = MINIMOG_THEME_ASSETS_URI . '/dokan/default-store-cover.jpg';
$store_banner_url     = $store_default_banner;
$store_banner_alt     = $store_name;

if ( $store_banner_id ) {
	$store_cropped_banner = Minimog_Image::get_attachment_url_by_id(
		array(
			'id'   => $store_banner_id,
			'size' => $store_banner_width . 'x' . $store_banner_height,
		)
	);

	// The resizer returns an empty url when the source file cannot be read.
	$store_banner_url = ! empty( $store_cropped_banner ) ? $store_cropped_banner : $store_default_banner;

	$banner_image_alt = get_post_meta( $store_banner_id, '_wp_attachment_image_alt', true );
	$store_banner_alt = '' !== $banner_image_alt ? $banner_image_alt : $store_name;
}

$show_store_open_close    = dokan_get_option( 'store_open_close', 'dokan_appearance', 'on' );
$dokan_store_time_enabled = isset( $store_info['dokan_store_time_enabled'] ) ? $store_info['dokan_store_time_enabled'] : '';
?>
<div class="grid-item dokan-single-seller <?php echo ( ! $store_banner_id ) ? 'no-banner-img' : ''; ?>">
	<div class="store-wrapper">
		<div class="store-header">
			<div class="store-banner">
				<a href="<?php echo esc_url( $store_url ); ?>">
					<div class="store-banner-bg">
						<img src="<?php echo esc_url( $store_banner_url ); ?>"
							alt="<?php echo esc_attr( $store_banner_alt ); ?>"
							width="<?php echo esc_attr( $store_banner_width ); ?>"
							height="<?php echo esc_attr( $store_banner_height ); ?>"
							loading="lazy"/>
					</div>
				</a>
			</div>
			<div class="store-badges">
				<?php if ( $is_store_featured ) : ?>
					<div class="store-badge hot featured-label">
						<span><?php esc_html_e( 'Featured', 'minimog' ); ?></span></div>
				<?php endif ?>

				<?php do_action( 'dokan_seller_listing_after_featured', $seller, $store_info ); ?>

				<?php if ( 'on' === $show_store_open_close && 'yes' === $dokan_store_time_enabled ) : ?>
					<?php if ( dokan_is_store_open( $seller->ID ) ) { ?>
						<div class="store-badge is-opening dokan-store-is-open-close-status dokan-store-is-open-status"
							title="<?php esc_attr_e( 'Store is Open', 'minimog' ); ?>">
							<span><?php esc_html_e( 'Open', 'minimog' ); ?></span></div>
					<?php } else { ?>
						<div class="store-badge is-closed dokan-store-is-open-close-status dokan-store-is-closed-status"
							title="<?php esc_attr_e( 'Store is Closed', 'minimog' ); ?>">
							<span><?php esc_html_e( 'Closed', 'minimog' ); ?></span></div>
					<?php } ?>
				<?php endif; ?>
			</div>
		</div>
		<div class="store-info">
			<div class="store-main-info">
				<div class="seller-avatar">
					<a href="<?php echo esc_url( $store_url ); ?>">
						<img src="<?php echo esc_url( $vendor->get_avatar() ); ?>"
							alt="<?php echo esc_attr( $store_name ); ?>"
							width="150" height="150" loading="lazy">
					</a>
				</div>
				<h2 class="store-name">
					<a href="<?php echo esc_url( $store_url ); ?>"><?php echo esc_html( $store_name ); ?></a>
					<?php do_action( 'dokan_store_list_loop_after_store_name', $vendor ); ?>
				</h2>
			</div>

			<?php if ( ! empty( $store_rating['count'] ) ) : ?>
				<?php $store_rating_display = number_format_i18n( $store_rating['rating'], 1 ); ?>
				<div class="dokan-seller-rating"
					<?php /* translators: %s: store rating out of 5. */ ?>
					title="<?php printf( esc_attr__( 'Rated %s out of 5', 'minimog' ), esc_attr( $store_rating_display ) ); ?>">
					<?php echo wp_kses_post( dokan_generate_ratings( $store_rating['rating'], 5 ) ); ?>
					<p class="rating">
						<?php
						/* translators: %s: store rating out of 5. */
						printf( esc_html__( '%s out of 5', 'minimog' ), esc_html( $store_rating_display ) );
						?>
					</p>
				</div>
			<?php endif; ?>

			<?php if ( ! dokan_is_vendor_info_hidden( 'address' ) && $store_address ) : ?>
				<?php
				$allowed_tags = array(
					'span' => array(
						'class' => array(),
					),
					'br'   => array(),
				);
				?>
				<p class="store-address"><?php echo wp_kses( $store_address, $allowed_tags ); ?></p>
			<?php endif; ?>

			<?php if ( ! dokan_is_vendor_info_hidden( 'phone' ) && $store_phone ) { ?>
				<p class="store-phone"><?php echo esc_html( $store_phone ); ?></p>
			<?php } ?>

			<?php if ( ! dokan_is_vendor_info_hidden( 'email' ) && $store_email ) { ?>
				<p class="store-email">
					<a class="link-transition-02"
						href="mailto:<?php echo esc_attr( antispambot( $store_email ) ); ?>"><?php echo esc_html( antispambot( $store_email ) ); ?></a>
				</p>
			<?php } ?>

			<?php do_action( 'dokan_seller_listing_after_store_data', $seller, $store_info ); ?>
		</div>
	</div>
</div>
