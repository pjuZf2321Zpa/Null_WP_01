<?php
/**
 * The Template for displaying vendor policies.
 *
 * @theme-version 3.4.0
 */

defined( 'ABSPATH' ) || exit;

$store_user      = dokan()->vendor->get( get_query_var( 'author' ) );
$store_info      = $store_user->get_shop_info();
$layout          = get_theme_mod( 'store_layout', 'left' );
$container_class = Minimog_Site_Layout::instance()->get_container_class( Minimog::setting( 'single_store_site_layout' ) );

$toggles = array(
	'store_shipping_policy' => array(
		'title'   => apply_filters( 'minimog/dokan/vendor_policies/shipping/title', __( 'Shipping Policy', 'minimog' ) ),
		'content' => isset( $store_info['store_shipping_policy'] ) ? $store_info['store_shipping_policy'] : '',
	),
	'store_refund_policy'   => array(
		'title'   => apply_filters( 'minimog/dokan/vendor_policies/refund/title', __( 'Refund Policy', 'minimog' ) ),
		'content' => isset( $store_info['store_refund_policy'] ) ? $store_info['store_refund_policy'] : '',
	),
	'store_return_policy'   => array(
		'title'   => apply_filters( 'minimog/dokan/vendor_policies/return/title', __( 'Cancellation / Return / Exchange Policy', 'minimog' ) ),
		'content' => isset( $store_info['store_return_policy'] ) ? $store_info['store_return_policy'] : '',
	),
);

get_header( 'shop' );
?>
<div id="page-content" class="page-content">
	<div class="<?php echo esc_attr( $container_class ); ?>">

		<?php dokan_get_template_part( 'store-header' ); ?>

		<div class="row">

			<?php Minimog_Sidebar::instance()->render( 'left' ); ?>

			<div id="page-main-content" class="page-main-content">

				<?php dokan_get_template_part( 'custom/store-tabs' ); ?>

				<div class="dokan-store-wrap layout-<?php echo esc_attr( $layout ); ?>">
					<div id="dokan-primary" class="dokan-single-store">
						<div id="dokan-content" class="vendor-policies" role="main">
							<div class="minimog-accordion-style-01">
								<div class="minimog-accordion" data-multi-open="1">
									<?php
									$toggle_active   = ! Minimog::is_handheld();
									$section_classes = array( 'accordion-section' );

									if ( $toggle_active ) {
										$section_classes[] = 'active';
									}

									foreach ( $toggles as $key => $toggle ) :
										if ( empty( $toggle['title'] ) || empty( $toggle['content'] ) ) {
											continue;
										}
										?>
										<div class="<?php echo esc_attr( implode( ' ', $section_classes ) ); ?>"
											id="tab-<?php echo esc_attr( $key ); ?>" role="tabpanel"
											aria-labelledby="tab-title-<?php echo esc_attr( $key ); ?>">
											<div class="accordion-header">
												<div class="accordion-title-wrapper">
													<h4 class="accordion-title"
														id="tab-title-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $toggle['title'] ); ?></h4>
												</div>
												<div class="accordion-icons">
													<span class="accordion-icon opened-icon">
														<i class="far fa-angle-down" aria-hidden="true"></i>
													</span>
													<span class="accordion-icon closed-icon">
														<i class="far fa-angle-up" aria-hidden="true"></i>
													</span>
												</div>
											</div>
											<div class="accordion-content"
												<?php if ( $toggle_active ) : ?>
													style="display:block;"
												<?php endif; ?>
											>
												<?php
												/**
												 * Sanitized with `wp_kses_post()` on save, then rendered through the
												 * standard content pipeline so the shortcodes and embeds a vendor
												 * has already stored keep working.
												 *
												 * @see \Minimog\Dokan\Vendor_Policies::save_store_policies_data()
												 */
												// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
												echo apply_filters( 'the_content', $toggle['content'] );
												?>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							</div>
						</div><!-- #content .site-content -->
					</div><!-- .dokan-single-store -->
				</div><!-- .dokan-store-wrap -->
			</div>

			<?php Minimog_Sidebar::instance()->render( 'right' ); ?>

		</div>
	</div>
</div>

<?php get_footer( 'shop' ); ?>
