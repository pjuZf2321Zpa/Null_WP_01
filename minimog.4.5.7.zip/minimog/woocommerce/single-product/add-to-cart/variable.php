<?php
/**
 * Variable product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/variable.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 11.1.0
 *
 * @theme-version 4.5.1
 */

defined( 'ABSPATH' ) || exit;

global $product;

$attribute_keys  = array_keys( $attributes );
$variations_json = wp_json_encode( $available_variations );
$variations_attr = function_exists( 'wc_esc_json' ) ? wc_esc_json( $variations_json ) : _wp_specialchars( $variations_json, ENT_QUOTES, 'UTF-8', true );

/**
 * WooCommerce keeps two spare renders of the whole gallery for its own variation script to restore from:
 * a <template> printed below, and an inline script assigning the same markup to
 * window.wc_variation_gallery_defaults, added just before this template loads. The theme serves that script
 * from its own build, which restores the gallery from the copies the gallery template already writes, so
 * neither snapshot has a reader here.
 *
 * Both come back for anyone who turns the core markup back on, because the core script reads them to restore
 * a form that was loaded after the page itself, a quick view modal for instance. It reads the <template>
 * first and falls back to the global, so they only stay useful together.
 *
 * Decided here rather than beside the <template> so that a variable product with nothing in stock, which
 * never reaches that markup, still drops the inline copy WooCommerce has already left behind.
 *
 * The filter is the one Frontend::get_available_variation_gallery() asks per variation, and it is passed
 * null where that one passes the variation: what is being decided here belongs to the product as a whole.
 */
$minimog_keep_core_gallery_html = false;

if ( class_exists( '\Minimog\Woo\Variation_Gallery\Frontend' ) ) {
	/**
	 * Asked on the same terms as the filter in Frontend::get_available_variation_gallery(), which keeps the
	 * per variation markup. Gating this one on is_core_gallery_available() as well meant a store that had
	 * opted out of WooCommerce's variation gallery kept that markup and lost the snapshot beside it, which
	 * is exactly the half-and-half state the filter exists to avoid. Whether the snapshot can be rendered
	 * at all is what function_exists() answers.
	 */
	$minimog_keep_core_gallery_html = function_exists( 'wc_get_product_gallery_html' )
		&& apply_filters( 'minimog/variation_gallery/keep_core_html', false, null, $product );

	if ( ! $minimog_keep_core_gallery_html ) {
		\Minimog\Woo\Variation_Gallery\Frontend::instance()->drop_core_gallery_snapshot( $product );
	}
}

do_action( 'woocommerce_before_add_to_cart_form' ); ?>

<form class="variations_form cart" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype='multipart/form-data' data-product_id="<?php echo absint( $product->get_id() ); ?>" data-product_variations="<?php echo $variations_attr; // WPCS: XSS ok. ?>">
	<?php do_action( 'woocommerce_before_variations_form' ); ?>

	<?php if ( empty( $available_variations ) && false !== $available_variations ) : ?>
		<p class="stock out-of-stock"><?php echo esc_html( apply_filters( 'woocommerce_out_of_stock_message', __( 'This product is currently out of stock and unavailable.', 'minimog' ) ) ); ?></p>
	<?php else : ?>
		<table class="variations" cellspacing="0" role="presentation">
			<tbody>
				<?php foreach ( $attributes as $attribute_name => $options ) : ?>
					<tr>
						<td class="label"><label for="<?php echo esc_attr( sanitize_title( $attribute_name ) ); ?>"><?php echo wc_attribute_label( $attribute_name ); // WPCS: XSS ok. ?></label></td>
						<td class="value">
							<?php
								wc_dropdown_variation_attribute_options(
									array(
										'options'   => $options,
										'attribute' => $attribute_name,
										'product'   => $product,
									)
								);
								/**
								 * Filters the reset variation button.
								 *
								 * @since 2.5.0
								 *
								 * @param string  $button The reset variation button HTML.
								 */
								echo end( $attribute_keys ) === $attribute_name ? wp_kses_post( apply_filters( 'woocommerce_reset_variations_link', '<a class="reset_variations" href="#" aria-label="' . esc_attr__( 'Clear options', 'minimog' ) . '">' . esc_html__( 'Clear', 'minimog' ) . '</a>' ) ) : '';
							?>
							<?php do_action( 'minimog/product_variation_attribute/label/after', $attribute_name ); ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<div class="reset_variations_alert screen-reader-text" role="alert" aria-live="polite" aria-relevant="all"></div>
		<?php if ( $minimog_keep_core_gallery_html ) : ?>
			<template class="wc-product-gallery-default-template"><?php echo wc_get_product_gallery_html( $product ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></template>
		<?php endif; ?>
		<?php do_action( 'woocommerce_after_variations_table' ); ?>

		<div class="single_variation_wrap">
			<?php
				/**
				 * Hook: woocommerce_before_single_variation.
				 */
				do_action( 'woocommerce_before_single_variation' );

				/**
				 * Hook: woocommerce_single_variation. Used to output the cart button and placeholder for variation data.
				 *
				 * @since 2.4.0
				 * @hooked woocommerce_single_variation - 10 Empty div for variation data.
				 * @hooked woocommerce_single_variation_add_to_cart_button - 20 Qty and cart button.
				 */
				do_action( 'woocommerce_single_variation' );

				/**
				 * Hook: woocommerce_after_single_variation.
				 */
				do_action( 'woocommerce_after_single_variation' );
			?>
		</div>
	<?php endif; ?>

	<?php do_action( 'woocommerce_after_variations_form' ); ?>
</form>

<?php
do_action( 'woocommerce_after_add_to_cart_form' );
