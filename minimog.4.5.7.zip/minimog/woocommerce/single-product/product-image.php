<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 11.1.0
 *
 * @theme-version 4.5.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

$attachment_ids = $product->get_gallery_image_ids();

/**
 * $product->get_image_id() rather than get_post_thumbnail_id(): since WooCommerce 10.8 the
 * variation gallery is rendered through this very template, with the variation images swapped in
 * over the woocommerce_product_get_image_id and woocommerce_product_get_gallery_image_ids filters
 * (wc_apply_product_image_overrides()). The post thumbnail never passes those filters, so that
 * render put the parent product image in the featured slot instead of the variation's own.
 *
 * It also reads the product itself rather than the global $post, so the template no longer depends
 * on whoever set that up before rendering it.
 */
$thumbnail_id = (int) $product->get_image_id();

if ( $thumbnail_id ) {
	array_unshift( $attachment_ids, $thumbnail_id );
}

if ( empty( $attachment_ids ) ) {
	/**
	 * wc_placeholder_img() rather than a hand-built tag: it emits width and height, so the slot
	 * is reserved before the file arrives, and it runs the woocommerce_placeholder_img filter
	 * that other extensions hook into.
	 *
	 * The size argument matters. It was left at the default, woocommerce_thumbnail, so the
	 * single product page rendered a catalogue-sized placeholder inside a full-width gallery
	 * slot. WooCommerce core passes woocommerce_single here.
	 *
	 * alt="" because the placeholder carries nothing the product title does not already say.
	 */
	echo apply_filters( 'woocommerce_single_product_image_html', wc_placeholder_img( 'woocommerce_single', array( 'alt' => '' ) ), $product->get_id() );

	return;
}

$is_quick_view = apply_filters( 'minimog/quick_view/is_showing', false );

$wrapper_classes = 'woo-single-gallery woocommerce-product-gallery';

$feature_style = Minimog_Woo::instance()->get_single_product_images_style();

if ( true === $is_quick_view ) {
	$feature_style = 'slider-02';
}

$wrapper_classes .= " feature-style-$feature_style";

$open_gallery = apply_filters( 'minimog/single_product/open_gallery', true );
if ( $open_gallery ) {
	$wrapper_classes .= ' has-light-gallery';
}

wc_get_template( "single-product/product-image-{$feature_style}.php", [
	'thumbnail_id'     => $thumbnail_id,
	'attachment_ids'   => $attachment_ids,
	'is_quick_view'    => $is_quick_view,
	'wrapper_classes'  => $wrapper_classes,
	'main_image_size'  => Minimog_Woo::instance()->get_single_product_image_size_by_feature_style( $feature_style, $is_quick_view ),
	'open_gallery'     => $open_gallery,
] );
