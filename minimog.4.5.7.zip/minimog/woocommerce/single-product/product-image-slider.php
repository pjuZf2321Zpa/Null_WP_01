<?php
/**
 * @package Minimog
 * @since   1.0.0
 * @version 4.5.3
 */
defined( 'ABSPATH' ) || exit;

global $post, $product;

$is_vertical_slider = Minimog_Woo::instance()->get_product_setting( 'single_product_slider_vertical' );
$is_vertical_slider = $args['vertical_slider'] ?? $is_vertical_slider;

/**
 * A vertical thumbs strip eats a third of a narrow screen, so on small screens it is laid out as a
 * horizontal strip instead (CSS: .thumbs-slider-horizontal-on-{device}, Swiper: data-vertical-{device}).
 * The Horizontal Thumbnails On option says how far up that goes: 'mobile' switches below 768px,
 * 'tablet' below 992px as well, where the gallery still shares the row with the summary (col-md-*)
 * and its column is narrow. Pass 'vertical_slider_mobile' => '1' to keep the strip vertical on every
 * screen (the Feature Product widget does, it has its own responsive gallery width).
 *
 * The option names the theme's devices, Swiper names its own: the theme's mobile (below 768px) is
 * Swiper's tablet (576-767px) and everything under it, the theme's tablet (768-991px) is Swiper's
 * tablet_extra. data-vertical-{device}="0" cascades down to the smaller devices.
 */
$is_vertical_slider_mobile = $args['vertical_slider_mobile'] ?? '0';

$horizontal_on                = Minimog_Woo::instance()->get_single_product_slider_horizontal_on();
$horizontal_on_swiper_devices = array(
	'mobile' => 'tablet',
	'tablet' => 'tablet-extra',
);

$show_gallery = '1';
$show_gallery = $args['show_gallery'] ?? $show_gallery;

$looped_slides = 3;
$slider_loop   = false; // Disable loop mode to avoid duplicate items on light gallery.

if ( true === $is_quick_view ) {
	$is_vertical_slider = '0';
}

$number_attachments = count( $attachment_ids );

$wrapper_classes .= ' has-thumbs-slider';
$wrapper_classes .= '1' === $is_vertical_slider ? ' thumbs-slider-vertical' : ' thumbs-slider-horizontal';

if ( '1' === $is_vertical_slider && '1' !== $is_vertical_slider_mobile ) {
	$wrapper_classes .= " thumbs-slider-horizontal-on-{$horizontal_on}";
}

$output = Minimog_Woo::instance()->get_product_image_slider_slide_html( $attachment_ids, [
	'thumbnail_id'    => $thumbnail_id,
	'open_gallery'    => $open_gallery,
	'main_image_size' => $main_image_size,
] );
?>
	<div class="<?php echo esc_attr( $wrapper_classes ); ?>">
		<?php
		$main_slider_settings = [
			'data-items-desktop'  => 1,
			'data-gutter-desktop' => 10,
			'data-nav'            => '1',
			'data-simulate-touch' => ! $open_gallery,
		];

		if ( $slider_loop ) {
			$main_slider_settings['data-loop'] = '1';

			if ( '1' === $is_vertical_slider ) {
				$main_slider_settings['data-looped-slides'] = $looped_slides;
			}
		}
		?>
		<div class="tm-swiper minimog-main-swiper nav-style-02" <?php echo Minimog_Helper::slider_args_to_html_attr( $main_slider_settings ); ?>>
			<div class="swiper-inner">
				<div class="swiper">
					<div class="swiper-wrapper">
						<?php echo '' . $output['main_slides_html']; ?>
					</div>
				</div>
			</div>
		</div>

		<?php if ( '1' === $show_gallery ) { ?>
			<?php
			$thumb_slider_settings = [
				'data-slide-to-clicked-slide' => '1',
				'data-free-mode'              => '1',
				'data-items-desktop'          => 'auto',
				'data-gutter-desktop'         => 10,
			];

			if ( $slider_loop ) {
				$thumb_slider_settings['data-looped-slides'] = $looped_slides;
			}

			if ( '1' === $is_vertical_slider ) {
				$thumb_slider_settings['data-vertical'] = '1';

				if ( '1' !== $is_vertical_slider_mobile ) {
					// Horizontal from this Swiper device down, vertical above it; see the device mapping at the top.
					$thumb_slider_settings[ 'data-vertical-' . $horizontal_on_swiper_devices[ $horizontal_on ] ] = '0';
				}
			}
			?>
			<div class="minimog-thumbs-swiper-wrap">
				<div
					class="tm-swiper minimog-thumbs-swiper" <?php echo Minimog_Helper::slider_args_to_html_attr( $thumb_slider_settings ); ?>>
					<div class="swiper-inner">
						<div class="swiper">
							<div class="swiper-wrapper">
								<?php echo '' . $output['thumb_slides_html']; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
<?php
/*
 * The copy of the original gallery the variation script swaps back to. Written for any product built on
 * WooCommerce's variable product - a variable subscription among them - since their forms carry the same
 * variation data; matching the type name alone left those without a copy, and so without the swap.
 */
if ( $product instanceof WC_Product_Variable ) :
	?>
	<div class="gallery-main-slides-o-html display-none" style="display: none"><?php echo $output['main_slides_html']; ?></div>
	<div class="gallery-thumb-slides-o-html display-none" style="display: none"><?php echo $output['thumb_slides_html']; ?></div>
<?php endif;
