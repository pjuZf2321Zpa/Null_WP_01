<?php
/**
 * Compact add to cart button for product widget cards
 *
 * The link WooCommerce renders in a product loop, minus the shop archive's tooltip
 * wrapper ( loop/add-to-cart.php ). WooCommerce only enqueues wc-add-to-cart.js where
 * "AJAX add to cart buttons on archives" is on, and the cart drawer is no archive, so
 * the theme's own endpoint takes the click instead
 * ( assets/js/modules/woo/fly-cart.js ).
 *
 * @package  Minimog
 * @since    4.5.3
 * @version  4.5.3
 */

defined( 'ABSPATH' ) || exit;

/** @var WC_Product $product */
global $product;

if ( ! is_a( $product, 'WC_Product' ) ) {
	return;
}

/**
 * False for variable, grouped and external products. The first two need a choice made
 * on their own page before anything can go in the cart, and an external product is
 * bought from its seller, so all three get a plain link - to that page, or to the
 * seller - carrying whatever label WooCommerce picks for them: Select options, View
 * products, Buy product.
 *
 * It is not the whole answer, though. A product type can report support and still need
 * choosing - WPC Product Bundles says so unconditionally for every bundle - so the
 * class below goes through the same filter WooCommerce's does, where those extensions
 * already know to take it away again.
 */
$can_add_over_ajax = $product->supports( 'ajax_add_to_cart' ) && $product->is_purchasable() && $product->is_in_stock();

$add_to_cart_url = $product->add_to_cart_url();

/**
 * add_to_cart_url() hangs ?add-to-cart= off the URI of the request it runs in, and this
 * card is rendered inside the template_lazyload AJAX request - so the link would point
 * at that endpoint, nonce and all, and a middle click would add the product and then
 * show the customer raw JSON. Rebuild it against the product's own page.
 */
if ( $product->is_purchasable() && false !== strpos( $add_to_cart_url, 'add-to-cart=' ) ) {
	$add_to_cart_url = add_query_arg( 'add-to-cart', $product->get_id(), $product->get_permalink() );
}

$defaults = array(
	'quantity'   => 1,
	'class'      => implode(
		' ',
		array_filter(
			array(
				'button',
				'product_type_' . $product->get_type(),
				$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
				$can_add_over_ajax ? 'ajax_add_to_cart' : '',
			)
		)
	),
	'attributes' => array(
		'data-product_id'  => $product->get_id(),
		'data-product_sku' => $product->get_sku(),
		'aria-label'       => $product->add_to_cart_description(),
		// As WooCommerce marks it: nofollow only where the link does something rather
		// than lead somewhere.
		'rel'              => $product->get_permalink() !== $add_to_cart_url ? 'nofollow' : '',
	),
);

/**
 * The filter a product loop runs, so a per-product minimum quantity still applies
 * ( framework/woocommerce/product-quantity-select.php ).
 */
$args = apply_filters( 'woocommerce_loop_add_to_cart_args', $defaults, $product );

if ( isset( $args['attributes']['aria-label'] ) ) {
	$args['attributes']['aria-label'] = wp_strip_all_tags( $args['attributes']['aria-label'] );
}

/**
 * An anchor that adds to the cart where it stands, rather than leading anywhere, is a
 * button to anyone not looking at it. WooCommerce says so on the same terms
 * ( woocommerce_template_loop_add_to_cart() ) bar one: it also wants its archive AJAX
 * option on, and this button goes over AJAX either way. With "redirect to the cart
 * after an add" on, the click does end in a new page, and it stays a link.
 *
 * Not put in the attributes here. Whether the anchor is still that button is only known
 * once the extensions have filtered the link, so the role goes on below, on the anchor
 * that kept the class - which leaves nothing to take back off one that did not, and no
 * way to take off a role an extension gave an anchor of its own.
 */
$acts_as_button = $can_add_over_ajax && 'yes' !== get_option( 'woocommerce_cart_redirect_after_add' );

/**
 * The label is wrapped in a span because the .updating-icon utility hides it while the
 * spinner shows ( assets/scss/elements/_buttons.scss ).
 */
$add_to_cart_link = apply_filters(
	'woocommerce_loop_add_to_cart_link',
	sprintf(
		'<a href="%s" data-quantity="%s" class="%s" %s><span>%s</span></a>',
		esc_url( $add_to_cart_url ),
		esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
		esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
		isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
		esc_html( $product->add_to_cart_text() )
	),
	$product,
	$args
);

/**
 * Whatever still carries the class once every extension has had its say becomes the
 * theme's own marker. Two things fall out of doing it here rather than upfront:
 * an extension that strips ajax_add_to_cart because its product is not ready to be
 * bought in one click - WPC Product Bundles does exactly that for a bundle holding
 * variable or optional items - takes the theme's button down with it; and no
 * ajax_add_to_cart is left in the page for WooCommerce's own script to bind, so the
 * click is never handled twice.
 */
// Parse attributes so a matching product slug, label or data attribute stays intact.
// These helpers also work on the theme's minimum supported WordPress version.
$link_parts = wp_html_split( $add_to_cart_link );

foreach ( $link_parts as $part_index => $link_part ) {
	$attributes = wp_kses_attr_parse( $link_part );

	if ( false === $attributes ) {
		continue;
	}

	$is_ajax_button = false;

	foreach ( $attributes as $attribute_index => $attribute ) {
		if ( preg_match( '/^(class\s*=\s*)(["\']?)(.*?)\2(\s*)$/is', $attribute, $matches ) ) {
			$classes                        = preg_replace(
				'/(^|[\t\n\f\r ])ajax_add_to_cart(?=$|[\t\n\f\r ])/',
				'$1minimog-add-to-cart-ajax',
				$matches[3]
			);
			$is_ajax_button                 = $is_ajax_button || $classes !== $matches[3];
			$attributes[ $attribute_index ] = $matches[1] . $matches[2] . $classes . $matches[2] . $matches[4];
		}
	}

	/**
	 * The anchor that kept the class is the theme's button, and says so - unless it has
	 * been given a role already, with a value or bare. Slipped in right behind the tag's
	 * name, which the parser hands over with the whitespace that follows it, so every
	 * other byte of the tag stays as it came. Not ahead of the closing bracket: the
	 * parser takes the "/" that ends an unquoted last value - href=/product/x/> - for
	 * part of that bracket, and a role put in between would cut it off the value.
	 */
	if ( $acts_as_button && $is_ajax_button && preg_match( '/^<a[\s>]/i', $link_part ) && ! preg_grep( '/^role(?:\s|=|$)/i', $attributes ) ) {
		array_splice( $attributes, 1, 0, array( 'role="button" ' ) );
	}

	$link_parts[ $part_index ] = implode( '', $attributes );
}

$add_to_cart_link = implode( '', $link_parts );

echo $add_to_cart_link; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
