<?php
/**
 * Page title
 */

defined( 'ABSPATH' ) || exit;

$heading_text = '';

if ( Minimog_Woo::instance()->is_shop() ) {
	// pll__() to match Minimog_Title_Bar::render_title(), which reads the same setting; without
	// it a Polylang site showed the translated string in the title bar and the raw one here.
	$heading_text = pll__( Minimog::setting( 'product_archive_title_bar_title' ) );
} elseif ( Minimog_Woo::instance()->is_product_taxonomy() ) {
	$heading_text = single_cat_title( '', false );
} else {
	$heading_text = get_the_title();
}

/**
 * On the standard and fill title bar layouts, Minimog_Title_Bar::render_title() already prints
 * this exact text as the page <h1>. Emitting another one here left the archive with two <h1>
 * elements holding identical content, so step down to <h2> whenever the title bar covers it.
 */
printf(
	'<%1$s class="page-title">%2$s</%1$s>',
	esc_attr( Minimog_Title_Bar::instance()->is_rendering_heading() ? 'h2' : 'h1' ),
	// Same allowlist the title bar applies, so `Shop <span>now</span>` keeps working.
	wp_kses(
		$heading_text,
		array(
			'span' => array( 'class' => array() ),
			'mark' => array( 'class' => array() ),
		)
	)
);
