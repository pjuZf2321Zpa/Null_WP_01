<?php
/**
 * Pagination - Show numbered pagination for catalog pages
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/pagination.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.5.6
 */

defined( 'ABSPATH' ) || exit;

$pagination_type = Minimog::setting( 'shop_archive_pagination_type' );

$total   = isset( $total ) ? $total : wc_get_loop_prop( 'total_pages' );
$current = isset( $current ) ? $current : wc_get_loop_prop( 'current_page' );
if ( ! isset( $base ) || ! isset( $format ) ) {
	$archive_pagination = Minimog_Woo::instance()->get_archive_pagination_base_format();
	$base               = isset( $base ) ? $base : $archive_pagination['base'];
	$format             = isset( $format ) ? $format : $archive_pagination['format'];
}
?>
<nav class="woocommerce-pagination" data-type="<?php echo esc_attr( $pagination_type ); ?>">
	<?php if ( in_array( $pagination_type, [ 'load-more', 'infinite' ], true ) ) : ?>
		<?php if ( $total > $current ): ?>
			<?php
			// `base` may carry the page part as `%_%` (see get_archive_pagination_base_format()).
			$load_more_url = str_replace( array( '%_%', '%#%' ), array( $format, $current + 1 ), $base );
			?>
			<?php
			/**
			 * A real link, not a button: this is the only route to page 2 and beyond, so with a
			 * <button> search engines could reach nothing past the first page of the catalogue.
			 * Each paginated URL renders its own link to the next one, so the whole archive stays
			 * reachable by following the chain.
			 *
			 * The click handlers already call preventDefault() and read `data-url`, so behaviour
			 * is unchanged; `href` only exists for crawlers and middle-click / open-in-new-tab.
			 */
			?>
			<a href="<?php echo esc_url( $load_more_url ); ?>" data-url="<?php echo esc_url( $load_more_url ); ?>" class="button shop-load-more-button" rel="next">
				<span class="button-text"><?php esc_html_e( 'Load more', 'minimog' ); ?></span>
			</a>
		<?php endif; ?>
	<?php else: ?>
		<?php if ( $total > 1 ) : ?>
			<?php
			echo paginate_links(
				apply_filters(
					'woocommerce_pagination_args',
					array( // WPCS: XSS ok.
						'base'      => $base,
						'format'    => $format,
						'add_args'  => false,
						'current'   => max( 1, $current ),
						'total'     => $total,
						'prev_text' => is_rtl() ? '&rarr;' : '&larr;',
						'next_text' => is_rtl() ? '&larr;' : '&rarr;',
						'type'      => 'list',
						'end_size'  => 3,
						'mid_size'  => 3,
					)
				)
			);
			?>
		<?php endif; ?>
	<?php endif; ?>
</nav>
