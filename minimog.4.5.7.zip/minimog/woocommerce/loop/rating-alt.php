<?php
/**
 * Loop Rating
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/loop/rating.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! wc_review_ratings_enabled() ) {
	return;
}

$average_rating = $product->get_average_rating();
?>
<div class="reviews-wrap">
	<?php echo wc_get_rating_html( $average_rating ); // WordPress.XSS.EscapeOutput.OutputNotEscaped. ?>

	<?php
	$review_count = $product->get_review_count();

	$_rating_text = sprintf( '(%1$s)', '<span class="count">' . esc_html( $review_count ) . '</span>' );
	$_rating_text = '<div class="review-count">' . $_rating_text . '</div>';

	echo $_rating_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped.
	?>
</div>
