<?php
/**
 * Cart drawer product recommendations
 *
 * Fetched over AJAX through the template_lazyload endpoint, which has no template
 * whitelist and is reachable by any visitor holding the public nonce. The option
 * guard below therefore has to live here, not only at the call site.
 *
 * @package  Minimog
 * @since    4.4.0
 * @version  4.5.3
 */

defined( 'ABSPATH' ) || exit;

$recommendations = \Minimog\Woo\Fly_Cart_Recommendations::instance();

if ( ! $recommendations->is_enabled() ) {
	return;
}

$recommended_products = $recommendations->get_products();

if ( empty( $recommended_products ) ) {
	return;
}

$recommendations_heading = $recommendations->get_heading();

$show_add_to_cart = $recommendations->is_add_to_cart_enabled();

// This runs inside a full front-end request, so leave the product global as we found it.
$previous_global_product = isset( $GLOBALS['product'] ) ? $GLOBALS['product'] : null;
?>
<?php if ( ! empty( $recommendations_heading ) ) : ?>
	<h3 class="fly-cart-recommendations-title"><?php echo esc_html( $recommendations_heading ); ?></h3>
<?php endif; ?>

<ul class="product_list_widget">
	<?php
	foreach ( $recommended_products as $recommended_product ) :
		$post_object = get_post( $recommended_product->get_id() );

		if ( ! $post_object ) {
			continue;
		}

		// the_permalink() in the card template needs the post global, the rest needs the product one.
		setup_postdata( $GLOBALS['post'] = $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found
		$GLOBALS['product'] = $recommended_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		wc_get_template(
			'custom/content-widget-product.php',
			array(
				'show_rating'      => false,
				/**
				 * Not show_buttons: that one prints a combined variation dropdown, which
				 * asks get_available_variations() of every variable product on the panel
				 * and has to fit its options into a card of about 150px.
				 */
				'show_buttons'     => false,
				'show_add_to_cart' => $show_add_to_cart,
			)
		);
	endforeach;

	wp_reset_postdata();
	$GLOBALS['product'] = $previous_global_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	?>
</ul>
