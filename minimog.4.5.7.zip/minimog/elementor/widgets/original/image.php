<?php

namespace Minimog_Elementor;

defined( 'ABSPATH' ) || exit;

class Modify_Widget_Image extends Modify_Base {

	/**
	 * Elementor 3.19.0 moved the Image widget's `align` control from the Content tab (`section_image`) to the
	 * Style tab (`section_style_image`), and 3.34.0 switched it to logical `start` / `end` values with its own
	 * RTL-aware `selectors_dictionary` for pages saved with the old `left` / `right` values.
	 */
	const ALIGN_MOVED_VERSION = '3.19.0';

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		if ( version_compare( ELEMENTOR_VERSION, self::ALIGN_MOVED_VERSION, '>=' ) ) {
			return; // Elementor handles the alignment itself; see ALIGN_MOVED_VERSION.
		}

		add_action( 'elementor/element/image/section_image/before_section_end', [
			$this,
			'before_end_section_image',
		] );
	}

	/**
	 * Map the `left` / `right` alignment to `start` / `end` so it follows the text direction.
	 *
	 * @param \Elementor\Widget_Base $element The edited element.
	 */
	public function before_end_section_image( $element ) {
		$element->update_responsive_control( 'align', [
			'selectors_dictionary' => [
				'left'  => 'start',
				'right' => 'end',
			],
		] );
	}
}

Modify_Widget_Image::instance()->initialize();
