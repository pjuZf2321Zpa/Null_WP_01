<?php

namespace Minimog_Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Minimog\Woo\Curcy_Multi_Currency;

defined( 'ABSPATH' ) || exit;

class Widget_Currency_Switcher extends Base {

	public function get_name() {
		return 'tm-currency-switcher';
	}

	public function get_title() {
		return __( 'Currency Switcher', 'minimog' );
	}

	public function get_icon_part() {
		return 'eicon-sync';
	}

	public function get_keywords() {
		return [ 'currency', 'woocommerce', 'switcher' ];
	}

	public function get_style_depends() {
		if ( ! class_exists( Curcy_Multi_Currency::class ) ) {
			return [];
		}

		Curcy_Multi_Currency::instance()->register_flag_style();

		return [ Curcy_Multi_Currency::FLAG_STYLE_HANDLE ];
	}

	protected function register_controls() {
		$this->add_content_section();

		$this->add_style_section();
	}

	private function add_content_section() {
		$this->start_controls_section( 'currency_section', [
			'label' => __( 'Currency Switcher', 'minimog' ),
		] );

		/**
		 * Values match the Curcy_Multi_Currency::DISPLAY_* constants. They are spelled out here
		 * because the widget is registered even when the Multi Currency plugin is not active.
		 */
		$this->add_control( 'display_type', [
			'label'       => __( 'Display', 'minimog' ),
			'type'        => Controls_Manager::SELECT,
			'description' => __( 'Flags are provided by the CURCY - WooCommerce Multi Currency plugin.', 'minimog' ),
			'options'     => [
				'code'      => __( 'Currency Code', 'minimog' ),
				'flag'      => __( 'Flag', 'minimog' ),
				'flag-code' => __( 'Flag + Currency Code', 'minimog' ),
			],
			'default'     => 'code',
		] );

		$this->add_control( 'x_direction', [
			'label'   => __( 'Directions', 'minimog' ),
			'type'    => Controls_Manager::CHOOSE,
			'options' => [
				'down' => [
					'title' => __( 'Down', 'minimog' ),
					'icon'  => 'eicon-arrow-down',
				],
				'up'   => [
					'title' => __( 'Up', 'minimog' ),
					'icon'  => 'eicon-arrow-up',
				],
			],
			'default' => 'down',
			'toggle'  => false,
		] );

		$this->add_control( 'y_direction', [
			'label'      => __( 'Direction', 'minimog' ),
			'type'       => Controls_Manager::CHOOSE,
			'options'    => [
				'left'  => [
					'title' => __( 'Left', 'minimog' ),
					'icon'  => 'eicon-arrow-left',
				],
				'right' => [
					'title' => __( 'Right', 'minimog' ),
					'icon'  => 'eicon-arrow-right',
				],
			],
			'default'    => 'left',
			'toggle'     => false,
			'show_label' => false,
		] );

		$this->end_controls_section();
	}

	private function add_style_section() {
		$this->start_controls_section( 'currency_style_section', [
			'label' => __( 'Currency Switcher', 'minimog' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		// Flag.
		$this->add_control( 'flag_style_hr', [
			'label'     => __( 'Flag', 'minimog' ),
			'type'      => Controls_Manager::HEADING,
			'condition' => [ 'display_type!' => 'code' ],
		] );

		$this->add_responsive_control( 'flag_width', [
			'label'      => __( 'Width', 'minimog' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 12,
					'max' => 60,
				],
			],
			'condition'  => [ 'display_type!' => 'code' ],
			'selectors'  => [
				/**
				 * The plugin sprite is a fixed 60x40 box scaled by a transform, so the width is
				 * expressed as a scale the stylesheet derives every other flag size from.
				 */
				'{{WRAPPER}}' => '--currency-flag-scale: calc({{SIZE}} / 60);',
			],
		] );

		$this->add_responsive_control( 'flag_spacing', [
			'label'      => __( 'Spacing', 'minimog' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 0,
					'max' => 40,
				],
			],
			'condition'  => [ 'display_type' => 'flag-code' ],
			'selectors'  => [
				'body:not(.rtl) {{WRAPPER}} .currency-flag' => 'margin-right: {{SIZE}}{{UNIT}};',
				'body.rtl {{WRAPPER}} .currency-flag'       => 'margin-left: {{SIZE}}{{UNIT}};',
			],
		] );

		// Active Item.
		$this->add_control( 'active_item_style_hr', [
			'label' => __( 'Active Item', 'minimog' ),
			'type'  => Controls_Manager::HEADING,
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'active_item',
			'selector' => '{{WRAPPER}} .menu-item-has-children>a',
		] );

		$this->start_controls_tabs( 'active_item_style_tabs' );

		$this->start_controls_tab( 'active_item_style_normal_tab', [
			'label' => __( 'Normal', 'minimog' ),
		] );

		$this->add_control( 'active_item_color', [
			'label'     => __( 'Color', 'minimog' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .menu-item-has-children>a' => 'color: {{VALUE}};',
			],
		] );

		$this->end_controls_tab();

		$this->start_controls_tab( 'active_item_style_hover_tab', [
			'label' => __( 'Hover', 'minimog' ),
		] );

		$this->add_control( 'active_item_hover_color', [
			'label'     => __( 'Color', 'minimog' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .menu-item-has-children>a:hover' => 'color: {{VALUE}};',
			],
		] );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		// List Items.
		$this->add_control( 'list_items_style_hr', [
			'label'     => __( 'List Items', 'minimog' ),
			'type'      => Controls_Manager::HEADING,
			'separator' => 'before',
		] );

		$this->add_responsive_control( 'list_items_wrapper_min_width', [
			'label'      => __( 'Wrapper Min Width', 'minimog' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 170,
					'max' => 500,
				],
			],
			'selectors'  => [
				'{{WRAPPER}} .currency-switcher-menu .sub-menu' => 'min-width: {{SIZE}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'list_items_wrapper_padding', [
			'label'      => __( 'Padding', 'minimog' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%', 'em' ],
			'selectors'  => [
				'body:not(.rtl) {{WRAPPER}} .currency-switcher-menu .sub-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				'body.rtl {{WRAPPER}} .currency-switcher-menu .sub-menu'       => 'padding: {{TOP}}{{UNIT}} {{LEFT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{RIGHT}}{{UNIT}};',
			],
		] );

		$this->add_control( 'list_items_wrapper_bg_color', [
			'label'     => __( 'Wrapper Background Color', 'minimog' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .currency-switcher-menu .sub-menu' => 'background-color: {{VALUE}};',
			],
		] );

		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'sub_item',
			'selector' => '{{WRAPPER}} .sub-menu a',
		] );

		$this->start_controls_tabs( 'sub_item_style_tabs' );

		$this->start_controls_tab( 'sub_item_style_normal_tab', [
			'label' => __( 'Normal', 'minimog' ),
		] );

		$this->add_control( 'sub_item_color', [
			'label'     => __( 'Color', 'minimog' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .sub-menu a' => 'color: {{VALUE}} !important;',
			],
		] );

		$this->add_control( 'sub_item_bg_color', [
			'label'     => __( 'Background Color', 'minimog' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .sub-menu a' => 'background-color: {{VALUE}};',
			],
		] );

		$this->end_controls_tab();

		$this->start_controls_tab( 'sub_item_style_hover_tab', [
			'label' => __( 'Hover', 'minimog' ),
		] );

		$this->add_control( 'sub_item_hover_color', [
			'label'     => __( 'Color', 'minimog' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .sub-menu a:hover' => 'color: {{VALUE}} !important;',
			],
		] );

		$this->add_control( 'sub_item_hover_bg_color', [
			'label'     => __( 'Background Color', 'minimog' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				'{{WRAPPER}} .sub-menu a:hover' => 'background-color: {{VALUE}};',
			],
		] );

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		if ( ! class_exists( Curcy_Multi_Currency::class ) ) {
			return;
		}

		$curcy = Curcy_Multi_Currency::instance();

		if ( ! $curcy->is_enabled() ) {
			return;
		}

		$settings = $this->get_settings_for_display();

		$classes = [
			'currency-switcher-menu-wrap',
			'curcy',
			'currency-switcher-menu-wrap--elementor',
			'currency-switcher-menu-wrap--' . $settings['x_direction'],
			'currency-switcher-menu-wrap--' . $settings['y_direction'],
		];

		$this->add_render_attribute( 'wrapper', 'class', $classes );
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php $curcy->print_menu( $settings['display_type'] ); ?>
		</div>
		<?php
	}
}
