<?php

namespace Minimog_Elementor;

use WPML_Elementor_Module_With_Items;

defined( 'ABSPATH' ) || exit;

class Translate_Widget_Testimonial_Carousel extends WPML_Elementor_Module_With_Items {

	/**
	 * Repeater field id
	 *
	 * @return string
	 */
	public function get_items_field() {
		return 'slides';
	}

	/**
	 * Repeater items field id
	 *
	 * @return array List inner fields translatable.
	 */
	public function get_fields() {
		return [
			'title',
			'content',
			'name',
			'position',
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'title':
				return __( 'Testimonial Carousel: Title', 'minimog' );

			case 'name':
				return __( 'Testimonial Carousel: Name', 'minimog' );

			case 'content':
				return __( 'Testimonial Carousel: Content', 'minimog' );

			case 'position':
				return __( 'Testimonial Carousel: Position', 'minimog' );

			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'name':
			case 'title':
			case 'position':
				return 'LINE';

			case 'content':
				return 'AREA';

			default:
				return '';
		}
	}
}
