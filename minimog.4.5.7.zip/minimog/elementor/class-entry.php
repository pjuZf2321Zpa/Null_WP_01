<?php

namespace Minimog_Elementor;

defined( 'ABSPATH' ) || exit;

/**
 * Main Elementor Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class Entry {

	/**
	 * Minimum Elementor Version
	 *
	 * Hard floor: below this the theme's Elementor integration is skipped entirely.
	 * 3.5.0 is the real API floor - it introduced the `elementor/widgets/register`,
	 * `elementor/controls/register` and `elementor/dynamic_tags/register` hooks plus
	 * the `register()` manager methods this integration is built on.
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_VERSION = '3.5.0';

	/**
	 * Recommended Elementor version.
	 *
	 * Soft floor: raises a `notice-warning` on every admin page load. The notice is
	 * marked `is-dismissible` but the dismissal is never persisted, so it comes back
	 * on the next page load.
	 *
	 * Do NOT bump this to whatever Elementor version ships in the bundle. The notice
	 * text reads "requires ... or greater", which would be untrue for anyone above
	 * MINIMUM_VERSION, and it would push customers on Elementor 3.x into an upgrade to
	 * 4.x that also demands WP 6.8. Raise it only as a deliberate support decision,
	 * together with reworking the notice copy and making the dismissal stick.
	 *
	 * @since 1.0.0
	 *
	 * @var string
	 */
	const RECOMMENDED_VERSION = '3.7.5';

	/**
	 * Minimum Elementor Pro Version
	 *
	 * Soft floor: only raises an admin notice when Elementor Pro is active.
	 * Same caveat as RECOMMENDED_VERSION - bumping this nags every existing customer
	 * still on an older Elementor Pro.
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_PRO_VERSION = '3.3.7';

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * The real constructor to initialize
	 *
	 * @since  1.0.0
	 *
	 * @access public
	 */
	public function initialize() {
		// Check if Elementor installed and activated.
		if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );

			return;
		}

		if ( version_compare( ELEMENTOR_VERSION, self::RECOMMENDED_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_recommend_version' ] );
		}

		// Check for required Elementor version.
		if ( version_compare( ELEMENTOR_VERSION, self::MINIMUM_VERSION, '<' ) ) {
			return;
		}

		// Notice if Elementor Pro used but low version.
		if ( defined( 'ELEMENTOR_PRO_VERSION' ) && version_compare( ELEMENTOR_PRO_VERSION, self::MINIMUM_PRO_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_pro_version' ] );
		}

		add_action( 'elementor/theme/register_locations', [ $this, 'register_theme_locations' ] );

		add_action( 'after_switch_theme', [ $this, 'add_cpt_support' ] );

		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'enqueue_editor_styles' ] );
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );

		// Runs before the Design System Sync module's own hook, which sits at the default priority.
		add_action( 'wp_enqueue_scripts', [ $this, 'skip_empty_design_system_sync' ], 9 );

		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/class-template-api.php' );
		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/class-fonts.php' );
		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/module-query.php' );
		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/class-control-init.php' );
		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/class-widget-utils.php' );
		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/class-widget-init.php' );
		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/class-wc-compatible.php' );

		/**
		 * WPML supported.
		 */
		minimog_require_file_once( MINIMOG_ELEMENTOR_DIR . '/wpml/class-wpml-translatable-nodes.php' );
	}

	/**
	 * Stop Elementor 4.x rebuilding the Design System Sync stylesheet on every front-end request.
	 *
	 * `Stylesheet_Manager::enqueue()` guards only on `file_exists()`. When the site has nothing
	 * to sync - no Atomic colour variables and no synced typography classes, which is every site
	 * still built with v3 widgets - `parse_content()` returns an empty string, so
	 * `Files\Base::update_file()` takes the `delete()` branch and the file is never written.
	 * `update()` then re-adds the meta straight after. The result is a DELETE plus an INSERT on
	 * `wp_options` for every uncached page view, and a deadlock on that row as soon as two
	 * requests overlap.
	 *
	 * Removing the module's front-end hook in that exact case costs nothing: the stylesheet it
	 * would enqueue is empty. Every other path is left untouched - if the file already exists, if
	 * there is anything to sync, or if the module internals are not shaped as expected, Elementor
	 * runs exactly as it does today.
	 *
	 * Upstream bug, worth reporting to Elementor - remove this once they guard the regeneration.
	 */
	public function skip_empty_design_system_sync() {
		$stylesheet_manager = '\Elementor\Modules\DesignSystemSync\Classes\Stylesheet_Manager';
		$variables_provider = '\Elementor\Modules\DesignSystemSync\Classes\Variables_Provider';
		$classes_provider   = '\Elementor\Modules\DesignSystemSync\Classes\Classes_Provider';

		if ( ! class_exists( $stylesheet_manager ) || ! class_exists( $variables_provider ) || ! class_exists( $classes_provider ) ) {
			return;
		}

		/*
		 * Anything unexpected in Elementor's internals must leave its behaviour alone rather than
		 * take the site down, so none of the probing below escapes this method.
		 */
		try {
			// isset() rather than a property read, so a half-booted Elementor cannot emit a notice.
			if ( ! isset( \Elementor\Plugin::$instance->modules_manager ) ) {
				return;
			}

			$module = \Elementor\Plugin::$instance->modules_manager->get_modules( 'design-system-sync' );

			if ( ! $module || ! method_exists( $module, 'enqueue_sync_stylesheet' ) ) {
				return;
			}

			// Already generated - Elementor will simply enqueue it, there is nothing to skip.
			if ( file_exists( ( new $stylesheet_manager() )->get_path() ) ) {
				return;
			}

			// The same two inputs `parse_content()` builds the stylesheet from.
			if ( ! empty( $variables_provider::get_synced_color_css_entries() ) ) {
				return;
			}

			if ( ! empty( $classes_provider::get_synced_typography_css_entries() ) ) {
				return;
			}
		} catch ( \Throwable $e ) {
			return;
		}

		remove_action( 'wp_enqueue_scripts', [ $module, 'enqueue_sync_stylesheet' ] );
	}

	public function enqueue_editor_styles() {
		wp_enqueue_style( 'minimog-elementor-editor', MINIMOG_ELEMENTOR_ASSETS . '/css/editor.css', array(), MINIMOG_THEME_VERSION );
	}

	public function enqueue_editor_scripts() {
		wp_enqueue_script( 'minimog-elementor-editor', MINIMOG_ELEMENTOR_ASSETS . '/js/editor.js', [
			//'jquery',
			'backbone-marionette',
			'elementor-common',
			'elementor-editor-modules',
			'elementor-editor-document',
		], MINIMOG_THEME_VERSION, true );
	}

	/**
	 * @param \ElementorPro\Modules\ThemeBuilder\Classes\Locations_Manager $elementor_theme_manager
	 *
	 * Register theme locations
	 */
	public function register_theme_locations( $elementor_theme_manager ) {
		$elementor_theme_manager->register_location( 'header' );
		$elementor_theme_manager->register_location( 'footer' );
		$elementor_theme_manager->register_location( 'single' );
		$elementor_theme_manager->register_location( 'archive' );
	}

	/**
	 * Enable default Elementor Editor for custom post type.
	 */
	public function add_cpt_support() {
		// If exists, assign to $cpt_support var.
		$cpt_support = get_option( 'elementor_cpt_support' );

		// Check if option DOESN'T exist in db.
		if ( ! $cpt_support ) {
			// Create array of our default supported post types.
			$cpt_support = [
				'page',
				'post',
				'ic_mega_menu',
			];
			update_option( 'elementor_cpt_support', $cpt_support );
		} else {
			if ( ! in_array( 'ic_mega_menu', $cpt_support ) ) {
				$cpt_support[] = 'ic_mega_menu';
				update_option( 'elementor_cpt_support', $cpt_support );
			}
		}
	}

	/**
	 * Warning when the site doesn't have Elementor installed or activated.
	 */
	public function admin_notice_missing_main_plugin() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			'%1$s requires %2$s to be installed and activated.',
			'<strong>' . MINIMOG_THEME_NAME . '</strong>',
			'<strong>Elementor</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function admin_notice_recommend_version() {
		minimog_notice_required_plugin_version( 'Elementor', self::RECOMMENDED_VERSION );
	}

	public function admin_notice_minimum_pro_version() {
		minimog_notice_required_plugin_version( 'Elementor Pro', self::MINIMUM_PRO_VERSION );
	}
}

Entry::instance()->initialize();
