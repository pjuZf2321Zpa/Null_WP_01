<?php

namespace Minimog\Dokan;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Single_Product' ) ) {
	class Single_Product {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			/**
			 * Move this tab from Main Tabs to Linked Product Tabs.
			 */
			remove_action( 'woocommerce_product_tabs', 'dokan_set_more_from_seller_tab', 10 );
			add_filter( 'minimog/product/linked_products_tabs', array( $this, 'add_more_from_seller_tab' ), 10 );

			add_action( 'wp', array( $this, 'wp_init' ), 99 );

			/**
			 * Change hook position
			 *
			 * @see \WeDevs\DokanPro\Modules\ReportAbuse\SingleProduct::add_report_button()
			 */
			minimog_remove_filters_for_anonymous_class( 'woocommerce_single_product_summary', 'WeDevs\DokanPro\Modules\ReportAbuse\SingleProduct', 'add_report_button', 100 );
		}

		public function add_more_from_seller_tab( $tabs ) {
			if ( function_exists( 'check_more_seller_product_tab' ) && check_more_seller_product_tab()
				&& '1' === \Minimog::setting( 'single_product_related_enable' )
				&& 'in_linked_product_tabs' === \Minimog::setting( 'single_product_related_position' )
			) {
				$tabs['more_seller_product'] = array(
					'title'    => __( 'More products', 'minimog' ),
					'priority' => 99,
					'callback' => array( $this, 'output_more_products_from_seller' ),
				);
			}

			return $tabs;
		}

		public function wp_init() {
			if ( '1' === \Minimog::setting( 'single_product_related_enable' )
				&& 'below_product_tabs' === \Minimog::setting( 'single_product_related_position' )
			) {
				add_action( 'woocommerce_after_single_product', array( $this, 'output_more_products_from_seller' ), 15 );
			}
		}

		/**
		 * Show more products from the current seller.
		 *
		 * Also used as a WooCommerce product tab callback, which calls it with ( $key, $tab ).
		 *
		 * @see   dokan_get_more_products_from_seller()
		 *
		 * @param int|string $seller_id      Seller ID, or the tab key when called as a tab callback.
		 * @param int|array  $posts_per_page Number of products, or the tab args when called as a tab callback.
		 *
		 * @global object    $post
		 *
		 * @return void
		 */
		public function output_more_products_from_seller( $seller_id = 0, $posts_per_page = 6 ) {
			global $post;

			if ( ! $post instanceof \WP_Post ) {
				return;
			}

			if ( 0 === $seller_id || 'more_seller_product' === $seller_id ) {
				$seller_id = $post->post_author;
			}

			if ( ! is_int( $posts_per_page ) ) {
				$posts_per_page = apply_filters( 'dokan_get_more_products_per_page', 6 );
			}

			/**
			 * `author` and `post__not_in` are WP_Query arguments, not documented `wc_get_products()`
			 * query vars, so query the posts first and hydrate the products afterwards.
			 */
			$query = new \WP_Query(
				array(
					'post_type'           => 'product',
					'post_status'         => 'publish',
					'posts_per_page'      => $posts_per_page,
					'orderby'             => 'rand',
					'post__not_in'        => array( $post->ID ),
					'author'              => $seller_id,
					'ignore_sticky_posts' => true,
					'no_found_rows'       => true,
					'fields'              => 'ids',
				)
			);

			$seller_products = array_filter( array_map( 'wc_get_product', $query->posts ) );

			dokan_get_template(
				'custom/single-product/seller-products.php',
				array(
					'seller_products' => $seller_products,
				)
			);
		}
	}

	Single_Product::instance()->initialize();
}
