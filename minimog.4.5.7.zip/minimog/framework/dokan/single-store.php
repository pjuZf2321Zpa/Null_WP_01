<?php

namespace Minimog\Dokan;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Single_Store' ) ) {
	class Single_Store {

		const SIDEBAR_NAME        = 'sidebar-store';
		const STORE_BANNER_WIDTH  = 1340;
		const STORE_BANNER_HEIGHT = 390;

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_action( 'minimog/register_sidebars', array( $this, 'register_store_sidebar' ) );

			add_filter( 'minimog/title_bar/type', array( $this, 'title_bar_type' ) );

			add_filter( 'minimog/page_sidebar/single_width', array( $this, 'set_sidebar_single_width' ) );
			add_filter( 'minimog/page_sidebar/single_offset', array( $this, 'set_sidebar_single_offset' ) );
			add_filter(
				'minimog/page_sidebar/class',
				array(
					$this,
					'add_sidebar_css_class',
				)
			); // Different style for sidebar.
			add_filter( 'minimog/page_sidebar/1', array( $this, 'set_sidebar_primary' ) );
			add_filter( 'minimog/page_sidebar/position', array( $this, 'set_sidebar_position' ) );
			add_action( 'minimog/page_sidebar/after_content', array( $this, 'add_default_sidebar_widgets' ) );

			/**
			 * Note: the Dokan store product search + sort bar is intentionally left in place. It is
			 * rendered by `Product\Hooks::store_products_orderby()` on `dokan_store_profile_frame_after`
			 * and styled by the theme in `scss/extensions/.../dokan/frontend/_single-store.scss`.
			 *
			 * @see \WeDevs\Dokan\Product\Hooks::store_products_orderby()
			 */

			add_filter( 'dokan_store_banner_default_width', array( $this, 'update_banner_width' ) );
			add_filter( 'dokan_store_banner_default_height', array( $this, 'update_banner_height' ) );
			add_filter( 'dokan_admin_localize_script', array( $this, 'update_banner_size' ) );

			add_filter( 'dokan_profile_social_fields', array( $this, 'update_store_social_fields' ) );

			/**
			 * Note: do not force `$query->is_home = false` on `pre_get_posts` for store pages.
			 * It makes the store page 404.
			 */
		}

		/**
		 * Register the store sidebar so shop owners can put their own widgets in it.
		 *
		 * When it holds no widget the Dokan default store widgets are printed instead.
		 *
		 * @see self::add_default_sidebar_widgets()
		 *
		 * @param array $defaults Shared `register_sidebar()` arguments.
		 *
		 * @return void
		 */
		public function register_store_sidebar( $defaults ) {
			register_sidebar(
				array_merge(
					$defaults,
					array(
						'id'          => self::SIDEBAR_NAME,
						'name'        => esc_html__( 'Vendor Store Sidebar', 'minimog' ),
						'description' => esc_html__( 'Add widgets here. Leave it empty to show the Dokan default store widgets.', 'minimog' ),
					)
				)
			);
		}

		public function update_banner_width() {
			return self::STORE_BANNER_WIDTH;
		}

		public function update_banner_height() {
			return self::STORE_BANNER_HEIGHT;
		}

		/**
		 * Update Store Banner size when add vendor in admin
		 *
		 * @see \WeDevs\Dokan\Assets::get_admin_localized_scripts()
		 *
		 * @param $settings
		 *
		 * @return mixed
		 */
		public function update_banner_size( $settings ) {
			if ( isset( $settings['store_banner_dimension'] ) ) {
				if ( isset( $settings['store_banner_dimension']['width'] ) ) {
					$settings['store_banner_dimension']['width'] = self::STORE_BANNER_WIDTH;
				}

				if ( isset( $settings['store_banner_dimension']['height'] ) ) {
					$settings['store_banner_dimension']['height'] = self::STORE_BANNER_HEIGHT;
				}
			}

			return $settings;
		}

		/**
		 * Normalise the Dokan social icons for the theme store header.
		 *
		 * Dokan mixes two formats in the `icon` key: bare Font Awesome names such as
		 * `facebook-square`, and complete class strings such as `fa-brands fa-threads`. Store
		 * templates print it as `fab fa-{icon}`, so the second format renders a broken
		 * `fab fa-fa-brands fa-threads` class. On top of that the theme ships Font Awesome 5.15,
		 * which has no glyph for the newest brands.
		 *
		 * `icon` keeps the bare-name format Dokan documents, so a child theme still printing
		 * `fab fa-{icon}` gets the same glyph it used to, and a ready to print `class` is added
		 * for the theme store header.
		 *
		 * @param array $socials Social field key => settings.
		 *
		 * @return array
		 */
		public function update_store_social_fields( $socials ) {
			// Square variants swapped for the plain ones, plus a fallback for brands Font Awesome 5 lacks.
			$class_overrides = array(
				'fb'        => 'fab fa-facebook-f',
				'twitter'   => 'fab fa-twitter',
				'pinterest' => 'fab fa-pinterest-p',
				'linkedin'  => 'fab fa-linkedin-in',
				'youtube'   => 'fab fa-youtube',
				'threads'   => 'fas fa-at',
			);

			foreach ( $socials as $social => $setting ) {
				$class = isset( $class_overrides[ $social ] ) ? $class_overrides[ $social ] : '';

				if ( '' === $class ) {
					$icon = isset( $setting['icon'] ) ? trim( (string) $setting['icon'] ) : '';

					// Dokan ships a few icons as a full class string, e.g. `fa-brands fa-threads`.
					if ( false !== strpos( $icon, 'fa-' ) ) {
						$parts = preg_split( '/\s+/', $icon );
						$icon  = preg_replace( '/^fa-/', '', (string) end( $parts ) );
					}

					$class = '' !== $icon ? 'fab fa-' . $icon : 'fas fa-link';
				}

				// Keep `icon` in sync with `class` so both spellings resolve to the same glyph.
				$parts = preg_split( '/\s+/', $class );

				$socials[ $social ]['icon']  = preg_replace( '/^fa-/', '', (string) end( $parts ) );
				$socials[ $social ]['class'] = $class;
			}

			return $socials;
		}

		public function title_bar_type( $type ) {
			if ( dokan_is_store_page() ) {
				return \Minimog_Title_Bar::DEFAULT_MINIMAL_TYPE;
			}

			return $type;
		}

		public function set_sidebar_primary( $sidebar ) {
			if ( dokan_is_store_page() ) {
				return self::SIDEBAR_NAME;
			}

			return $sidebar;
		}

		public function set_sidebar_position( $position ) {
			if ( dokan_is_store_page() ) {
				$new_position = get_theme_mod( 'store_layout', 'left' );

				return $new_position;
			}

			return $position;
		}

		public function set_sidebar_single_width( $width ) {
			if ( dokan_is_store_page() ) {
				$new_width = \Minimog::setting( 'store_page_single_sidebar_width' );

				if ( isset( $new_width['width'] ) && '' !== $new_width['width'] ) {
					return $new_width['width'];
				}
			}

			return $width;
		}

		public function set_sidebar_single_offset( $offset ) {
			if ( dokan_is_store_page() ) {
				$new_offset = \Minimog::setting( 'store_page_single_sidebar_offset' );

				if ( isset( $new_offset['width'] ) && '' !== $new_offset['width'] ) {
					/**
					 * Redux - Unit is included in dimensions type
					 * return $new_offset['width'] . 'px';
					 */
					return $new_offset['width'];
				}
			}

			return $offset;
		}

		public function add_sidebar_css_class( $classes ) {
			if ( dokan_is_store_page() ) {
				$sidebar_style = \Minimog::setting( 'store_page_sidebar_style' );

				if ( ! empty( $sidebar_style ) ) {
					$classes[] = 'style-' . $sidebar_style;
				}
			}

			return $classes;
		}

		/**
		 * Print the Dokan default store widgets when the store sidebar holds none.
		 *
		 * `minimog/page_sidebar/after_content` fires once per rendered sidebar, so bail out unless
		 * this is the store sidebar itself, otherwise a page showing a second sidebar would print
		 * the Dokan widgets twice.
		 *
		 * @see store-sidebar.php
		 *
		 * @param string $name Sidebar being rendered.
		 *
		 * @return void
		 */
		public function add_default_sidebar_widgets( $name = '' ) {
			if ( self::SIDEBAR_NAME !== $name || ! dokan_is_store_page() ) {
				return;
			}

			if ( is_active_sidebar( self::SIDEBAR_NAME ) ) {
				return;
			}

			$store_user   = dokan()->vendor->get( get_query_var( 'author' ) );
			$map_location = $store_user->get_location();

			dokan_store_category_widget();

			if ( ! empty( $map_location ) ) {
				dokan_store_location_widget();
			}

			dokan_store_time_widget();
			dokan_store_contact_widget();
		}
	}

	Single_Store::instance()->initialize();
}
