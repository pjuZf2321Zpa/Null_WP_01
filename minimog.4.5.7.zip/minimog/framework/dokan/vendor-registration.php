<?php

namespace Minimog\Dokan;

defined( 'ABSPATH' ) || exit;

class Vendor_Registration {
	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		add_action( 'minimog/modal_user_register/after_form_fields', array( $this, 'add_extra_fields_for_seller' ) );

		add_filter( 'minimog/user_register/errors', array( $this, 'validate_registration' ), 10, 3 );

		/**
		 * The register modal only prints the name fields when WooCommerce is configured to ask for
		 * them. Drop them from the Dokan required list otherwise, or vendor registration can never
		 * pass Dokan's own validation.
		 *
		 * @see \WeDevs\Dokan\Registration::validate_registration()
		 */
		add_filter( 'dokan_seller_registration_required_fields', array( $this, 'filter_required_fields' ) );

		// Runs after Dokan's own callback on the same filter, which sits at the default priority.
		add_filter( 'woocommerce_new_customer_data', array( $this, 'keep_vendor_names' ), 20 );

		/**
		 * The vendor role, the user nicename and the default store settings are handled by Dokan
		 * itself. `wc_create_new_customer()` fires both `woocommerce_new_customer_data` and
		 * `woocommerce_created_customer`, which Dokan hooks. Duplicating that work here overwrote
		 * Dokan's store settings and fired `dokan_new_seller_created` a second time, which sent the
		 * admin two "new vendor registered" emails per signup.
		 *
		 * @see \WeDevs\Dokan\Registration::set_new_vendor_names()
		 * @see \WeDevs\Dokan\Registration::save_vendor_info()
		 */
	}

	/**
	 * Keep the vendor first and last name a child theme register form supplied.
	 *
	 * Dokan reads them from `fname` / `lname` only and blanks them when those inputs are missing.
	 * Minimog_Login_Register also accepts `first_name` / `last_name` so a child theme can override
	 * the register template, so put those values back when Dokan cleared them.
	 *
	 * @see \WeDevs\Dokan\Registration::set_new_vendor_names()
	 *
	 * @param array $data Customer data about to reach `wp_insert_user()`.
	 *
	 * @return array
	 */
	public function keep_vendor_names( $data ) {
		if ( ! isset( $data['role'] ) || 'seller' !== $data['role'] ) {
			return $data;
		}

		// Nonce is verified by Minimog_Login_Register before the registration runs.
		$post_data = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( empty( $data['first_name'] ) && ! empty( $post_data['first_name'] ) ) {
			$data['first_name'] = sanitize_text_field( $post_data['first_name'] );
		}

		if ( empty( $data['last_name'] ) && ! empty( $post_data['last_name'] ) ) {
			$data['last_name'] = sanitize_text_field( $post_data['last_name'] );
		}

		return $data;
	}

	public function add_extra_fields_for_seller() {
		$store_base_url = trailingslashit( home_url( dokan_get_option( 'custom_store_url', 'dokan_general', 'store' ) ) );
		?>
		<div class="form-group form-user-role form-radio-inline">
			<label for="ip_reg_role_customer" class="form-label-radio">
				<input type="radio" name="role" value="customer" checked
						id="ip_reg_role_customer"/><?php esc_html_e( 'I am a customer', 'minimog' ); ?>
			</label>
			<label for="ip_reg_role_seller" class="form-label-radio">
				<input type="radio" name="role" value="seller"
						id="ip_reg_role_seller"/><?php esc_html_e( 'I am a vendor', 'minimog' ); ?>
			</label>
		</div>

		<div class="form-group show-if-seller display-none">
			<label for="ip_reg_company_name" class="form-label"><?php esc_html_e( 'Shop Name', 'minimog' ); ?></label>
			<input type="text" class="form-control form-input" name="shopname" id="ip_reg_company_name"
					required="required"
					placeholder="<?php esc_attr_e( 'Shop Name', 'minimog' ); ?>"/>
		</div>

		<div class="form-group show-if-seller display-none">
			<label for="ip_reg_seller_url" class="form-label"><?php esc_html_e( 'Shop URL', 'minimog' ); ?></label>
			<input type="text" class="form-control form-input" name="shopurl" id="ip_reg_seller_url"
					placeholder="<?php esc_attr_e( 'Shop URL', 'minimog' ); ?>"
					required="required"
			/>
			<small><?php echo esc_url( $store_base_url ); ?><strong id="ip_reg-url-alart"></strong></small>
		</div>

		<div class="form-group show-if-seller display-none">
			<label for="ip_reg_shop_phone" class="form-label"><?php esc_html_e( 'Phone Number', 'minimog' ); ?></label>
			<input type="text" class="form-control form-input" name="phone" id="ip_reg_shop_phone"
					required="required"
					placeholder="<?php esc_attr_e( 'Phone Number', 'minimog' ); ?>"/>
		</div>
		<?php
	}

	/**
	 * Drop the fields the register modal never renders from the Dokan required list.
	 *
	 * @param array $fields Required field name => error message.
	 *
	 * @return array
	 */
	public function filter_required_fields( $fields ) {
		if ( ! $this->has_name_fields() ) {
			unset( $fields['fname'], $fields['lname'] );
		}

		return $fields;
	}

	/**
	 * Whether the register modal renders the first/last name inputs.
	 *
	 * @return bool
	 */
	protected function has_name_fields() {
		return 'yes' === get_option( 'woocommerce_registration_input_name_enable', 'yes' );
	}

	/**
	 * @param \WP_Error $errors     Registration errors collected so far.
	 * @param string    $user_login User login.
	 * @param string    $email      User email.
	 *
	 * @return \WP_Error
	 */
	public function validate_registration( $errors, $user_login, $email ) {
		// Nonce is verified by Minimog_Login_Register before this filter runs.
		$post_data = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$allowed_roles = apply_filters( 'dokan_register_user_role', array( 'customer', 'seller' ) );
		$role          = isset( $post_data['role'] ) ? sanitize_text_field( $post_data['role'] ) : '';

		// Is the role name allowed, or is the user trying to manipulate it?
		if ( '' !== $role && ! in_array( $role, $allowed_roles, true ) ) {
			$errors->add( 'role-error', esc_html__( 'Cheating, eh?', 'minimog' ) );

			return $errors;
		}

		if ( 'seller' !== $role ) {
			return $errors;
		}

		$required_fields = array(
			'phone'    => esc_html__( 'Please enter your phone number.', 'minimog' ),
			'shopname' => esc_html__( 'Please provide a shop name.', 'minimog' ),
		);

		if ( $this->has_name_fields() ) {
			$required_fields['fname'] = esc_html__( 'Please enter your first name.', 'minimog' );
			$required_fields['lname'] = esc_html__( 'Please enter your last name.', 'minimog' );
		}

		foreach ( $required_fields as $field => $msg ) {
			$value = isset( $post_data[ $field ] ) ? trim( sanitize_text_field( $post_data[ $field ] ) ) : '';

			if ( '' === $value ) {
				$errors->add( "$field-error", $msg );
			}
		}

		$shop_url = isset( $post_data['shopurl'] ) ? trim( sanitize_text_field( $post_data['shopurl'] ) ) : '';

		if ( '' === $shop_url ) {
			$errors->add( 'shopurl-error', esc_html__( 'Please provide a shop url.', 'minimog' ) );
		} elseif ( ! $this->is_store_url_available( $shop_url ) ) {
			$errors->add( 'shopurl-error', esc_html__( 'The shop url is not available', 'minimog' ) );
		}

		return $errors;
	}

	/**
	 * Check the availability of shop name.
	 *
	 * @param string $url_slug Shop slug, already unslashed.
	 *
	 * @return bool
	 */
	public function is_store_url_available( $url_slug ) {
		$url_slug = sanitize_text_field( $url_slug );
		$check    = true;
		$user     = get_user_by( 'slug', $url_slug );

		if ( false !== $user ) {
			$check = false;
		}

		// Check if a customer wants to migrate, their username should be available.
		if ( is_user_logged_in() && dokan_is_user_customer( get_current_user_id() ) ) {
			$current_user = wp_get_current_user();

			if ( $user && $current_user->user_nicename === $user->user_nicename ) {
				$check = true;
			}
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Read-only availability check, nonce handled by the calling form.
		if ( is_admin() && isset( $_POST['vendor_id'] ) ) {
			$vendor = get_user_by( 'id', absint( $_POST['vendor_id'] ) );

			if ( $vendor && $user && $vendor->user_nicename === $user->user_nicename ) {
				$check = true;
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $check;
	}
}

Vendor_Registration::instance()->initialize();
