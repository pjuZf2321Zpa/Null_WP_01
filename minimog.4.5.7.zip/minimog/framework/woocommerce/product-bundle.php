<?php

namespace Minimog\Woo;

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'WPCleverWoosb' ) ) {
	class Product_Bundle extends \WPCleverWoosb {

		protected static $instance = null;

		/**
		 * Product types to exclude from bundled items list. Fallback when Helper::get_types() not available.
		 *
		 * @var array
		 */
		protected static $types = array( 'bundle', 'woosb', 'composite', 'grouped', 'woosg', 'external' );

		const MINIMUM_PLUGIN_VERSION   = '8.4.6';
		const RECOMMEND_PLUGIN_VERSION = '8.6.4';

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Init self constructor to avoid auto call parent::__construct
		 * This make code run twice times.
		 */
		public function __construct() {
			// Parent's show_bundled_price() uses $this->helper; set it so parent method works.
			if ( function_exists( 'WPCleverWoosb_Helper' ) ) {
				$this->helper = \WPCleverWoosb_Helper();
			}
		}

		public function initialize() {
			if ( ! $this->is_activate() ) {
				return;
			}

			if ( defined( 'WOOSB_VERSION' ) ) {
				if ( version_compare( WOOSB_VERSION, self::RECOMMEND_PLUGIN_VERSION, '<' ) ) {
					add_action( 'admin_notices', array( $this, 'admin_notice_recommend_plugin_version' ) );
				}

				if ( version_compare( WOOSB_VERSION, self::MINIMUM_PLUGIN_VERSION, '<' ) ) {
					return;
				}
			}

			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );

			minimog_remove_filters_for_anonymous_class( 'woocommerce_woosb_add_to_cart', 'WPCleverWoosb', 'add_to_cart_form' );
			add_action( 'woocommerce_woosb_add_to_cart', array( $this, 'add_to_cart_form' ) );

			// After the plugin's own cart_item_edit ( priority 10 ), see cart_item_edit_fallback().
			// woosb 8.7.0+ prints the link itself, the fallback would show it twice.
			if ( defined( 'WOOSB_VERSION' ) && version_compare( WOOSB_VERSION, '8.7.0', '<' ) ) {
				add_action( 'woocommerce_after_cart_item_name', array( $this, 'cart_item_edit_fallback' ), 11, 2 );
			}
		}

		/**
		 * Plugin bug workaround ( woosb < 8.7.0 ): in cart context the bundle's items are rebuilt
		 * from the cart selection, so chosen variations have type "variation" and has_variables()
		 * returns false — the plugin then skips its cart edit link for variable-only bundles.
		 * Render the same link here when the plugin skipped it but the bundle is editable.
		 * Fixed upstream in 8.7.0 ( reads the stored bundle instead ), so only hooked before that.
		 *
		 * @param array  $cart_item     Cart item data.
		 * @param string $cart_item_key Cart item key.
		 */
		public function cart_item_edit_fallback( $cart_item, $cart_item_key ) {
			if ( \WPCleverWoosb_Helper::get_setting( 'edit_link', 'no' ) !== 'yes' ) {
				return;
			}

			if ( empty( $cart_item['woosb_ids'] ) || empty( $cart_item['data'] ) || ! is_a( $cart_item['data'], 'WC_Product_Woosb' ) ) {
				return;
			}

			$product = $cart_item['data'];

			// The plugin already printed its link for these.
			if ( $product->has_optional() || $product->has_variables() ) {
				return;
			}

			$has_variation_item = false;

			foreach ( (array) $product->get_items() as $item ) {
				if ( empty( $item['id'] ) ) {
					continue;
				}

				$item_product = wc_get_product( $item['id'] );

				if ( $item_product && $item_product->is_type( 'variation' ) ) {
					$has_variation_item = true;
					break;
				}
			}

			if ( ! $has_variation_item ) {
				return;
			}

			// Mirror the plugin's link markup and filters exactly.
			// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound, WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
			$edit_url = apply_filters(
				'woosb_cart_item_edit_url',
				add_query_arg(
					array(
						'edit' => base64_encode( $cart_item['woosb_ids'] ),
						'key'  => $cart_item_key,
					),
					$product->get_permalink()
				),
				$cart_item,
				$cart_item_key
			);

			$edit_label = method_exists( 'WPCleverWoosb_Helper', 'localization' ) ? \WPCleverWoosb_Helper::localization( 'cart_item_edit', esc_html__( 'Edit', 'minimog' ) ) : esc_html__( 'Edit', 'minimog' );
			$edit_link  = ' <a class="woosb-cart-item-edit" href="' . esc_url( $edit_url ) . '">' . esc_html( $edit_label ) . '</a>';

			echo apply_filters( 'woosb_cart_item_edit_link', $edit_link, $cart_item, $cart_item_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above; filter kept for plugin parity.
			// phpcs:enable
		}

		public function is_activate() {
			return class_exists( 'WPCleverWoosb' );
		}

		public function frontend_scripts() {
			$min = \Minimog_Enqueue::instance()->get_min_suffix();
			$rtl = \Minimog_Enqueue::instance()->get_rtl_suffix();

			wp_dequeue_style( 'woosb-frontend' );

			wp_register_style( 'minimog-wc-product-bundle', MINIMOG_THEME_URI . "/assets/css/wc/product-bundle{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
			wp_enqueue_style( 'minimog-wc-product-bundle' );
		}

		public function admin_notice_recommend_plugin_version() {
			minimog_notice_required_plugin_version( 'WPC Product Bundles for WooCommerce', self::RECOMMEND_PLUGIN_VERSION );
		}

		public function get_types() {
			return class_exists( 'WPCleverWoosb_Helper' ) ? \WPCleverWoosb_Helper::get_types() : self::$types;
		}

		/**
		 * Render a data-attributes string from a [ key => value ] map.
		 * Mirrors \WPCleverWoosb_Helper::data_attributes() so filtered attrs
		 * ( woosb_products_attrs / woosb_item_attrs ) print identically.
		 *
		 * @param array $attrs Attribute map, keys without the "data-" prefix.
		 *
		 * @return string Escaped HTML attributes string.
		 */
		public function get_data_attributes_html( $attrs ) {
			$html = array();

			foreach ( (array) $attrs as $attr_key => $attr_value ) {
				$html[] = 'data-' . sanitize_title( str_replace( 'data-', '', (string) $attr_key ) ) . '="' . esc_attr( $attr_value ) . '"';
			}

			return implode( ' ', $html );
		}

		/**
		 * Whether a bundled product can be bought, checked the way the plugin checks it.
		 *
		 * Newer woosb builds (8.7.7 has it, 8.7.3 does not) run WC_Product::is_purchasable()
		 * inside their "bundled context" and through the woosb_bundled_is_purchasable filter,
		 * so a plugin that blocks a product on its own page (password protection...) can still
		 * allow it inside a bundle. Older builds only have the WooCommerce check.
		 *
		 * @param \WC_Product $product Bundled product.
		 * @param string      $context Where the check happens, as the plugin names it: 'display', 'validation', 'price'...
		 *
		 * @return bool
		 * @see \WPCleverWoosb_Helper::is_purchasable()
		 */
		public function is_item_purchasable( $product, $context = 'display' ) {
			if ( method_exists( '\WPCleverWoosb_Helper', 'is_purchasable' ) ) {
				return \WPCleverWoosb_Helper::is_purchasable( $product, $context );
			}

			return $product->is_purchasable();
		}

		public function add_to_cart_form() {
			/**
			 * @var \WC_Product
			 */ global $product;

			if ( ! $product || ! $product->is_type( 'woosb' ) ) {
				return;
			}

			if ( $product->has_variables() ) {
				wp_enqueue_script( 'wc-add-to-cart-variation' );
			}

			do_action( 'woosb_before_add_to_cart_form', $product ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WPC plugin hook.

			$position = \WPCleverWoosb_Helper::get_setting( 'bundled_position', 'above' );
			$can_show = apply_filters( 'woosb_show_bundled', true, $product->get_id() );

			if ( 'above' === $position && $can_show ) {
				$this->minimog_show_bundled();
			}

			/**
			 * Cart-item edit flow ( plugin "edit_link" setting ): the cart page links back here with
			 * ?edit=<base64 ids>&key=<cart item key>; submitting must update that cart item, not add a new one.
			 *
			 * @see \WPCleverWoosb::add_to_cart_form()
			 */
			// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			$edit_link = \WPCleverWoosb_Helper::get_setting( 'edit_link', 'no' ) === 'yes';
			$edit_ids  = isset( $_GET['edit'] ) ? explode( ',', base64_decode( sanitize_text_field( wp_unslash( $_GET['edit'] ) ) ) ) : array();
			$edit_key  = isset( $_GET['key'] ) ? sanitize_key( wp_unslash( $_GET['key'] ) ) : '';
			// phpcs:enable

			$edit_item = $edit_link && ! empty( $edit_ids ) && ! empty( $edit_key ) && isset( WC()->cart ) ? WC()->cart->get_cart_item( $edit_key ) : false;

			if ( $edit_item && ( $product->has_optional() || $product->has_variables() ) ) {
				$product_id  = $product->get_id();
				$quantity    = ! empty( $edit_item['quantity'] ) ? $edit_item['quantity'] : 1;
				$update_text = method_exists( 'WPCleverWoosb_Helper', 'localization' ) ? \WPCleverWoosb_Helper::localization( 'cart_item_update', esc_html__( 'Update', 'minimog' ) ) : esc_html__( 'Update', 'minimog' );

				echo '<form class="cart" action="' . esc_url( wc_get_cart_url() ) . '" method="post" enctype="multipart/form-data">';
				echo '<input type="hidden" name="woosb_ids" class="woosb-ids woosb-ids-' . esc_attr( $product_id ) . '" value=""/>';
				echo '<input type="hidden" name="woosb_update" value="' . esc_attr( $edit_key ) . '"/>';
				echo '<input type="hidden" name="quantity" value="' . esc_attr( $quantity ) . '"/>';
				echo '<button type="submit" name="add-to-cart" value="' . esc_attr( $product_id ) . '" class="single_add_to_cart_button button alt">' . esc_html( $update_text ) . '</button>';
				echo '</form>';
			} else {
				wc_get_template( 'single-product/add-to-cart/simple.php' );
			}

			if ( 'below' === $position && $can_show ) {
				$this->minimog_show_bundled();
			}

			do_action( 'woosb_after_add_to_cart_form', $product ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WPC plugin hook.
		}

		/**
		 * @param \WC_Product_Woosb $product
		 *
		 * @see \WPCleverWoosb::show_bundled()
		 */
		function minimog_show_bundled( $product = null ) {
			if ( ! $product ) {
				global $product;
			}

			if ( ! $product || ! is_a( $product, 'WC_Product_Woosb' ) ) {
				return;
			}

			$items = $product->get_items();

			if ( empty( $items ) ) {
				return;
			}

			// Item quantities pre-filled from the plugin's cart-edit link ( ?edit=<base64 "id/key/qty" list> ).
			// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			$edit_ids = isset( $_GET['edit'] ) ? explode( ',', base64_decode( sanitize_text_field( wp_unslash( $_GET['edit'] ) ) ) ) : array();
			// phpcs:enable

			$order                 = 1;
			$product_id            = $product->get_id();
			$fixed_price           = $product->is_fixed_price();
			$has_variables         = $product->has_variables();
			$has_optional          = $product->has_optional();
			$discount_amount       = $product->get_discount_amount();
			$discount_percentage   = $product->get_discount_percentage();
			$exclude_unpurchasable = $product->exclude_unpurchasable();
			$total_limit           = get_post_meta( $product_id, 'woosb_total_limits', true ) === 'on';
			$total_min             = get_post_meta( $product_id, 'woosb_total_limits_min', true );
			$total_max             = get_post_meta( $product_id, 'woosb_total_limits_max', true );
			$whole_min             = get_post_meta( $product_id, 'woosb_limit_whole_min', true ) ?: 1;
			$whole_max             = get_post_meta( $product_id, 'woosb_limit_whole_max', true ) ?: '-1';
			$layout                = get_post_meta( $product_id, 'woosb_layout', true ) ?: 'unset';
			$layout                = $layout !== 'unset' ? $layout : \WPCleverWoosb_Helper::get_setting( 'layout', 'list' );
			$bundled_price         = \WPCleverWoosb_Helper()->get_setting( 'bundled_price', 'price' );
			$products_class        = apply_filters( 'woosb_products_class', 'woosb-products woosb-products-layout-' . $layout, $product );
			$products_attrs        = apply_filters(
				'woosb_products_attrs',
				array(
					'discount-amount'       => $discount_amount,
					'discount'              => $discount_percentage,
					'fixed-price'           => $fixed_price ? 'yes' : 'no',
					'price'                 => wc_get_price_to_display( $product ),
					'price-suffix'          => htmlentities( $product->get_price_suffix() ),
					'variables'             => $has_variables ? 'yes' : 'no',
					'optional'              => $has_optional ? 'yes' : 'no',
					'min'                   => $whole_min,
					'max'                   => $whole_max,
					'total-min'             => $total_limit && $total_min ? $total_min : 0,
					'total-max'             => $total_limit && $total_max ? $total_max : '-1',
					'exclude-unpurchasable' => $exclude_unpurchasable ? 'yes' : 'no',
				),
				$product
			);

			do_action( 'woosb_before_wrap', $product );

			echo '<div class="woosb-wrap woosb-bundled" data-id="' . esc_attr( $product_id ) . '">';

			if ( $before_text = apply_filters( 'woosb_before_text', get_post_meta( $product_id, 'woosb_before_text', true ), $product_id ) ) {
				echo '<div class="woosb-before-text woosb-text">' . wp_kses_post( do_shortcode( $before_text ) ) . '</div>';
			}

			do_action( 'woosb_before_table', $product );
			?>
			<div class="<?php echo esc_attr( $products_class ); ?>" <?php echo $this->get_data_attributes_html( $products_attrs ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_data_attributes_html(). ?>>
				<?php
				// store global $product.
				$global_product    = $product;
				$global_product_id = $product_id;

				foreach ( $items as $key => $item ) {
					if ( ! empty( $item['id'] ) ) {
						/**
						 * @var \WC_Product_Variable $product
						 */
						$product = wc_get_product( $item['id'] );

						if ( ! $product || in_array( $product->get_type(), $this->get_types(), true ) ) {
							continue;
						}

						if ( apply_filters( 'woosb_item_exclude', false, $product, $global_product ) ) {
							continue;
						}

						$item_qty = isset( $item['qty'] ) ? (float) $item['qty'] : 1;
						$item_min = ! empty( $item['min'] ) ? (float) $item['min'] : 0;
						$item_max = ! empty( $item['max'] ) ? (float) $item['max'] : 10000;
						$optional = ! empty( $item['optional'] );

						if ( ! empty( $edit_ids ) ) {
							foreach ( $edit_ids as $edit_id ) {
								if ( false !== strpos( $edit_id, '/' . $key ) ) {
									$edit_id_arr = explode( '/', $edit_id );
									$item_qty    = isset( $edit_id_arr[2] ) ? (float) $edit_id_arr[2] : 1;
								}
							}
						}

						if ( $optional ) {
							if ( ( $max_purchase = $product->get_max_purchase_quantity() ) && ( $max_purchase > 0 ) && ( $max_purchase < $item_max ) ) {
								// get_max_purchase_quantity can return -1
								$item_max = $max_purchase;
							}

							if ( $item_qty < $item_min ) {
								$item_qty = $item_min;
							}

							if ( ( $item_max > $item_min ) && ( $item_qty > $item_max ) ) {
								$item_qty = $item_max;
							}
						}

						$item_class = 'product woosb-item-product woosb-product woosb-product-type-' . $product->get_type();

						if ( $optional ) {
							$item_class .= ' woosb-product-optional';
						}

						if ( ! apply_filters( 'woosb_item_visible', true, $product, $global_product_id ) ) {
							$item_class .= ' woosb-product-hidden';
						}

						if ( ( ! $product->is_type( 'variable' ) && ( ! $product->is_in_stock() || ! $product->has_enough_stock( $item_qty ) || ! $this->is_item_purchasable( $product ) ) ) || ( $product->is_type( 'variable' ) && ! $product->child_is_in_stock() && ! $product->child_is_on_backorder() ) ) {
							if ( ! apply_filters( 'woosb_allow_unpurchasable_qty', false ) ) {
								$item_qty = 0;
							}

							$item_class .= ' woosb-product-unpurchasable';
						}

						$quantity_input_html = '';
						if ( $optional ) {
							ob_start();
							?>
							<?php if ( ( $product->is_in_stock() && ( $product->is_type( 'variable' ) || $this->is_item_purchasable( $product ) ) ) || apply_filters( 'woosb_allow_unpurchasable_qty', false ) ) { ?>
								<div class="woosb-quantity">
									<?php
									woocommerce_quantity_input(
										array(
											'input_value' => $item_qty,
											'min_value'   => $item_min,
											'max_value'   => $item_max,
											'woosb_qty'   => array(
												'input_value' => $item_qty,
												'min_value'   => $item_min,
												'max_value'   => $item_max,
											),
											'classes'     => apply_filters(
												'woosb_qty_classes',
												array(
													'input-text',
													'woosb-qty',
													'woosb_qty',
													'qty',
													'text',
												)
											),
											'input_name'  => 'woosb_qty_' . $order,
										// compatible with WPC Product Quantity
										),
										$product
									);
									?>
								</div>
							<?php } else { ?>
								<div class="woosb-quantity woosb-quantity-disabled">
									<input type="number" class="input-text qty text" value="0" disabled/>
								</div>
							<?php } ?>
							<?php
							$quantity_input_html = ob_get_clean();
						}

						do_action( 'woosb_above_item', $product, $global_product, $order );

						$has_link   = apply_filters( 'woosb_item_has_link', $product->is_visible(), $product ) && ( \WPCleverWoosb_Helper()->get_setting( 'bundled_link', 'yes' ) !== 'no' );
						$item_price = \WPCleverWoosb_Helper::get_price_to_display( $product );
						$item_attrs = apply_filters(
							'woosb_item_attrs',
							array(
								'key'          => $key,
								'name'         => $product->get_name(),
								'id'           => $product->is_type( 'variable' ) ? 0 : $item['id'],
								'price'        => $item_price,
								'o_price'      => $item_price,
								'price-suffix' => htmlentities( $product->get_price_suffix() ),
								'stock'        => $product->get_max_purchase_quantity(),
								'qty'          => $item_qty,
								'order'        => $order,
							),
							$product,
							$global_product,
							$order
						);
						?>
						<div class="<?php echo esc_attr( apply_filters( 'woosb_item_class', $item_class, $product, $global_product, $order ) ); ?>" <?php echo $this->get_data_attributes_html( $item_attrs ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in get_data_attributes_html(). ?>>
							<?php do_action( 'woosb_before_item', $product, $global_product, $order ); ?>

							<?php if ( \WPCleverWoosb_Helper()->get_setting( 'bundled_thumb', 'yes' ) !== 'no' ) { ?>
								<div class="woosb-thumb">
									<?php
									if ( $has_link ) {
										echo '<a ' . ( \WPCleverWoosb_Helper::get_setting( 'bundled_link', 'yes' ) === 'yes_popup' ? 'class="woosq-link no-ajaxy" data-id="' . $item['id'] . '" data-context="woosb"' : '' ) . ' href="' . esc_url( $product->get_permalink() ) . '" ' . ( \WPCleverWoosb_Helper::get_setting( 'bundled_link', 'yes' ) === 'yes_blank' ? 'target="_blank"' : '' ) . '>';
									}
									?>
									<?php
									/**
									 * Disabled variation image changed.
									 * Because it's not support properly image size.
									 * Move img out of div to make js disabled.
									 */
									?>
									<!--<div class="woosb-thumb-ori"></div>
									<div class="woosb-thumb-new"></div>-->
									<?php
									$product_image = \Minimog_Woo::instance()->get_product_image( $product, \Minimog_Woo::instance()->get_loop_product_image_size() );
									echo apply_filters( 'woosb_item_thumbnail', $product_image, $product );
									?>

									<?php
									if ( $has_link ) {
										echo '</a>';
									}
									?>
								</div><!-- /woosb-thumb -->
							<?php } ?>

							<div class="woosb-product-info">
								<div class="woosb-product-main-info">
									<div class="woosb-title-wrap">
										<?php
										do_action( 'woosb_before_item_name', $product );

										echo '<h3 class="woosb-title post-title-2-rows">';

										if ( ( \WPCleverWoosb_Helper()->get_setting( 'bundled_qty', 'yes' ) === 'yes' ) && ! $optional ) {
											echo apply_filters( 'woosb_item_qty', esc_html( $item['qty'] ) . ' × ', $item['qty'], $product );
										}

										$item_name    = '';
										$product_name = apply_filters( 'woosb_item_product_name', $product->get_name(), $product );

										if ( $has_link ) {
											$item_name .= '<a ' . ( \WPCleverWoosb_Helper::get_setting( 'bundled_link', 'yes' ) === 'yes_popup' ? 'class="woosq-link no-ajaxy" data-id="' . esc_attr( $item['id'] ) . '" data-context="woosb"' : '' ) . ' href="' . esc_url( $product->get_permalink() ) . '" ' . ( \WPCleverWoosb_Helper::get_setting( 'bundled_link', 'yes' ) === 'yes_blank' ? 'target="_blank"' : '' ) . '>';
										}

										if ( $product->is_type( 'variable' ) || ( $product->is_in_stock() && $product->has_enough_stock( $item_qty ) ) ) {
											$item_name .= $product_name;
										} else {
											$item_name .= '<s>' . $product_name . '</s>';
										}

										if ( $has_link ) {
											$item_name .= '</a>';
										}

										echo apply_filters( 'woosb_item_name', $item_name, $product, $global_product, $order );
										echo '</h3>';

										do_action( 'woosb_after_item_name', $product );

										if ( $bundled_price === 'price_under_name' || $bundled_price === 'subtotal_under_name' ) {
											self::show_bundled_price( $bundled_price, $fixed_price, $discount_percentage, $product, $item );
										}

										if ( \WPCleverWoosb_Helper::get_setting( 'bundled_description', 'no' ) === 'yes' ) {
											echo '<div class="woosb-description">' . apply_filters( 'woosb_item_description', $product->get_short_description(), $product ) . '</div>';
										}
										?>
									</div>

									<?php if ( $bundled_price === 'price' || $bundled_price === 'subtotal' ) { ?>
										<?php self::show_bundled_price( $bundled_price, $fixed_price, $discount_percentage, $product, $item ); ?>
									<?php } ?>
								</div>
								<div class="woosb-product-cart">
									<?php if ( $product->is_type( 'variable' ) ) : ?>
										<div class="minimog-variation-select-wrap">
											<?php
											$allowed_terms = ! empty( $item['terms'] ) && is_array( $item['terms'] ) ? $item['terms'] : array();

											if ( \WPCleverWoosb_Helper::get_setting( 'variations_selector', 'default' ) === 'woovr' && class_exists( 'WPClever_Woovr' ) ) {
												\WPClever_Woovr::woovr_variations_form( $product, false, 'woosb', $allowed_terms );
											} else {
												\Minimog_Woo::instance()->get_product_variation_dropdown_html(
													$product,
													array(
														'show_label'    => false,
														'show_price'    => false,
														'allowed_terms' => $allowed_terms,
													)
												);

												$attributes           = $product->get_variation_attributes();
												$available_variations = $product->get_available_variations();
												$variations_json      = wp_json_encode( $available_variations );
												$variations_attr      = function_exists( 'wc_esc_json' ) ? wc_esc_json( $variations_json ) : _wp_specialchars( $variations_json, ENT_QUOTES, 'UTF-8', true );

												if ( is_array( $attributes ) && ( count( $attributes ) > 0 ) ) {
													$total_attrs = count( $attributes );
													$loop_count  = 0;

													echo '<div class="variations_form" data-product_id="' . absint( $product->get_id() ) . '" data-product_variations="' . esc_attr( $variations_attr ) . '">';
													echo '<div class="variations">';

													foreach ( $attributes as $attribute_name => $options ) {
														++$loop_count;

														$attribute_key   = sanitize_title( $attribute_name );
														$restricted_attr = ! empty( $allowed_terms[ $attribute_key ] );

														// Limit selectable options to the terms allowed for this bundled item.
														if ( $restricted_attr ) {
															$options = array_values( array_intersect( $allowed_terms[ $attribute_key ], $options ) );
														}
														?>
														<div class="variation">
															<div class="label">
																<?php echo esc_html( wc_attribute_label( $attribute_name ) ); ?>
															</div>
															<div class="select">
																<?php
																$attr     = 'attribute_' . sanitize_title( $attribute_name );
																$selected = isset( $_REQUEST[ $attr ] ) ? wc_clean( stripslashes( urldecode( $_REQUEST[ $attr ] ) ) ) : $product->get_variation_default_attribute( $attribute_name );

																if ( $restricted_attr ) {
																	if ( $selected && ! in_array( $selected, $options, true ) ) {
																		$selected = '';
																	}

																	if ( ! $selected && 1 === count( $options ) ) {
																		$selected = $options[0];
																	}
																}
																wc_dropdown_variation_attribute_options(
																	array(
																		'options'          => $options,
																		'attribute'        => $attribute_name,
																		'product'          => $product,
																		'selected'         => $selected,
																		'show_option_none' => wc_attribute_label( $attribute_name ),
																	)
																);
																?>
															</div>
															<?php if ( $loop_count === $total_attrs ) : ?>
																<?php echo '<div class="reset">' . apply_filters( 'woocommerce_reset_variations_link', '<a class="reset_variations" href="#">' . esc_html__( 'Clear', 'minimog' ) . '</a>' ) . '</div>'; ?>
															<?php endif; ?>
														</div>
														<?php
													}

													echo '</div>';
													echo '</div>';

													if ( \WPCleverWoosb_Helper::get_setting( 'bundled_description', 'no' ) === 'yes' ) {
														echo '<div class="woosb-variation-description"></div>';
													}
												}
											}

											do_action( 'woosb_after_item_variations', $product );
											?>
										</div>
									<?php endif; ?>
									<?php echo '' . $quantity_input_html; ?>
									<?php echo '<div class="woosb-availability">' . wp_kses_post( wc_get_stock_html( $product ) ) . '</div>'; ?>
								</div>
							</div>
							<?php do_action( 'woosb_after_item', $product, $global_product, $order ); ?>
						</div>
						<?php
						do_action( 'woosb_under_item', $product, $global_product, $order );
					} elseif ( ! empty( $item['text'] ) ) {
						$item_class = 'woosb-item-text';

						if ( ! empty( $item['type'] ) ) {
							$item_class .= ' woosb-item-text-type-' . $item['type'];
						}

						echo '<div class="' . esc_attr( apply_filters( 'woosb_item_text_class', $item_class, $item, $global_product, $order ) ) . '">';

						if ( empty( $item['type'] ) || ( $item['type'] === 'none' ) ) {
							echo wp_kses_post( $item['text'] );
						} else {
							$text_tag = tag_escape( $item['type'] );
							$text_tag = $text_tag ? $text_tag : 'div';

							echo '<' . $text_tag . '>' . wp_kses_post( $item['text'] ) . '</' . $text_tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- tag_escape()'d tag, kses'd content.
						}

						echo '</div>';
					}

					++$order;
				}

				// Restore global $product.
				$product    = $global_product;
				$product_id = $global_product_id;
				?>
			</div>
			<?php
			if ( ! $fixed_price && ( $has_variables || $has_optional ) ) {
				echo '<div class="woosb-summary woosb-text"><span class="woosb-total"></span>';

				if ( $has_optional ) {
					echo '<span class="woosb-count"></span>';
				}

				echo '</div>';
			}

			echo '<div class="woosb-alert woosb-text" style="display: none"></div>';

			do_action( 'woosb_after_table', $product );

			if ( $after_text = apply_filters( 'woosb_after_text', get_post_meta( $product_id, 'woosb_after_text', true ), $product_id ) ) {
				echo '<div class="woosb-after-text woosb-text">' . wp_kses_post( do_shortcode( $after_text ) ) . '</div>';
			}

			echo '</div>';

			do_action( 'woosb_after_wrap', $product );
		}
	}

	Product_Bundle::instance()->initialize();
}

