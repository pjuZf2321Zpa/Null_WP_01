<?php

namespace Minimog\Woo;

defined( 'ABSPATH' ) || exit;

/**
 * Compatible with CURCY - WooCommerce Multi Currency plugin.
 *
 * @see https://wordpress.org/plugins/woo-multi-currency/
 */
class Curcy_Multi_Currency {

	/**
	 * Switcher display modes, shared with the `header_currency_switcher_display` option
	 * and with the Currency Switcher Elementor widget.
	 */
	const DISPLAY_CODE      = 'code';
	const DISPLAY_FLAG      = 'flag';
	const DISPLAY_FLAG_CODE = 'flag-code';

	/**
	 * Colour defaults of the plugin Design tab.
	 *
	 * The theme reskins the plugin currency bar, which would also bury whatever is picked there.
	 * A colour is handed over to the stylesheet only once it differs from these, so an untouched
	 * Design tab keeps the theme skin and a deliberate choice is honoured.
	 *
	 * @see \WOOMULTI_CURRENCY_Data::__construct()
	 */
	const DESIGN_COLOR_DEFAULTS = [
		'text_color'               => '#fff',
		'background_color'         => '#212121',
		'main_color'               => '#f78080',
		'expand_button_color'      => '#cccccc',
		'expand_button_background' => '#999999',
		'expand_button_opacity'    => 0.2,
	];

	/**
	 * Handle the plugin registers its flag sprite under.
	 *
	 * @see WOOMULTI_CURRENCY_Frontend_Design::front_end_script()
	 */
	const FLAG_STYLE_HANDLE = 'wmc-flags';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ], 5 );
		add_action( 'wp_enqueue_scripts', [ $this, 'add_currency_bar_styles' ], 20 );

		add_filter( 'minimog/top_bar/components/currency_switcher/output', [ $this, 'get_currency_switcher_html' ] );
		add_filter( 'minimog/header/components/currency_switcher/output', [ $this, 'get_currency_switcher_html' ] );
	}

	/**
	 * Check whether the plugin activated
	 *
	 * @return boolean true if plugin activated
	 */
	public function is_activated() {
		return class_exists( 'WOOMULTI_CURRENCY' );
	}

	/**
	 * Settings holder of the plugin.
	 *
	 * @return \WOOMULTI_CURRENCY_Data|null NULL when the plugin is not available.
	 */
	public function get_plugin_settings() {
		if ( ! class_exists( 'WOOMULTI_CURRENCY_Data' ) ) {
			return null;
		}

		return \WOOMULTI_CURRENCY_Data::get_ins();
	}

	public function frontend_scripts() {
		$this->register_flag_style();

		if ( self::DISPLAY_CODE !== $this->get_display() ) {
			wp_enqueue_style( self::FLAG_STYLE_HANDLE );
		}
	}

	/**
	 * The flag sprite ships with the plugin, but the plugin enqueues it only while printing one
	 * of its own switchers. Register it under the same handle so the theme markup can ask for it
	 * without loading the sprite twice.
	 */
	public function register_flag_style() {
		if ( ! defined( 'WOOMULTI_CURRENCY_CSS' ) || wp_style_is( self::FLAG_STYLE_HANDLE, 'registered' ) ) {
			return;
		}

		$file    = defined( 'WP_DEBUG' ) && WP_DEBUG ? 'flags-64.css' : 'flags-64.min.css';
		$version = defined( 'WOOMULTI_CURRENCY_VERSION' ) ? WOOMULTI_CURRENCY_VERSION : MINIMOG_THEME_VERSION;

		wp_register_style( self::FLAG_STYLE_HANDLE, WOOMULTI_CURRENCY_CSS . $file, null, $version );
	}

	/**
	 * Hand the colours picked in Multi Currency > Design to the theme stylesheet, which styles the
	 * plugin currency bar with selectors the plugin inline CSS cannot outweigh.
	 *
	 * @see MINIMOG_THEME_DIR/assets/scss/extensions/assets/css/wc/multi-currency.scss
	 */
	public function add_currency_bar_styles() {
		$variables = $this->get_currency_bar_variables();

		if ( empty( $variables ) ) {
			return;
		}

		$declarations = '';

		foreach ( $variables as $name => $value ) {
			$declarations .= $name . ':' . $value . ';';
		}

		wp_add_inline_style( 'minimog-wc-multi-currency', '.woocommerce-multi-currency.wmc-sidebar{' . $declarations . '}' );
	}

	/**
	 * Custom properties for the currency bar, holding only the colours that were actually changed
	 * in Multi Currency > Design. The stylesheet keeps the theme colour as the fallback of each.
	 *
	 * @return array Custom property name => colour.
	 */
	public function get_currency_bar_variables() {
		$settings = $this->get_plugin_settings();

		if ( empty( $settings ) ) {
			return [];
		}

		$defaults  = self::DESIGN_COLOR_DEFAULTS;
		$variables = [];

		$background = $this->normalize_color( $settings->get_background_color() );
		$text       = $this->normalize_color( $settings->get_text_color() );
		$main       = $this->normalize_color( $settings->get_main_color() );

		$colors = [
			'--minimog-wmc-bg'           => [ $background, $defaults['background_color'] ],
			'--minimog-wmc-active-bg'    => [ $main, $defaults['main_color'] ],
			/**
			 * The plugin falls back to the main colour when no hover colour is set, so both are
			 * measured against the main colour default.
			 */
			'--minimog-wmc-hover-bg'     => [ $settings->get_hover_color(), $defaults['main_color'] ],
			'--minimog-wmc-expand-color' => [ $settings->get_param( 'expand_button_color' ), $defaults['expand_button_color'] ],
		];

		foreach ( $colors as $name => $color ) {
			list( $value, $default ) = $color;

			$value = $this->normalize_color( $value );

			if ( '' !== $value && $value !== $this->normalize_color( $default ) ) {
				$variables[ $name ] = $value;
			}
		}

		/**
		 * The theme text colours are picked for the theme backgrounds, so once a background comes
		 * from the Design tab the text has to come from there too - otherwise the theme red would
		 * sit on whatever colour the shop picked. The plugin paints every row with the one text
		 * colour, so the plain row and the selected one both read it.
		 */
		$text_changed = '' !== $text && $text !== $this->normalize_color( $defaults['text_color'] );

		if ( '' !== $text ) {
			if ( $text_changed || isset( $variables['--minimog-wmc-bg'] ) ) {
				$variables['--minimog-wmc-text'] = $text;
			}

			if ( $text_changed || isset( $variables['--minimog-wmc-active-bg'] ) ) {
				$variables['--minimog-wmc-active-text'] = $text;
			}
		}

		$expand_background = $this->normalize_color( $settings->get_param( 'expand_button_background' ) );
		$expand_opacity    = $settings->get_param( 'expand_button_opacity' );

		// An empty opacity is an untouched field rather than a transparent button.
		$expand_opacity = '' === $expand_opacity ? (float) $defaults['expand_button_opacity'] : (float) $expand_opacity;
		$expand_changed = $expand_background !== $this->normalize_color( $defaults['expand_button_background'] )
			|| $expand_opacity !== (float) $defaults['expand_button_opacity'];

		if ( '' !== $expand_background && $expand_changed ) {
			// The same eight digit hex the plugin builds for its expand button.
			$variables['--minimog-wmc-expand-bg'] = $expand_background . sprintf( '%02x', $expand_opacity * 255 );
		}

		return $variables;
	}

	/**
	 * @param string $color Colour to normalise.
	 *
	 * @return string Lowercase six or eight digit hex, empty when the value is not a hex colour.
	 *                Comparing normalised values keeps #fff and #ffffff from reading as a change.
	 */
	private function normalize_color( $color ) {
		if ( ! is_string( $color ) || ! preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $color ) ) {
			return '';
		}

		$hex = strtolower( substr( $color, 1 ) );

		if ( strlen( $hex ) <= 4 ) {
			$expanded = '';

			foreach ( str_split( $hex ) as $digit ) {
				$expanded .= $digit . $digit;
			}

			$hex = $expanded;
		}

		return '#' . $hex;
	}

	/**
	 * Display mode of the header and top bar switchers.
	 *
	 * @return string One of the DISPLAY_* modes.
	 */
	public function get_display() {
		$display = apply_filters( 'minimog/currency_switcher/display', \Minimog::setting( 'header_currency_switcher_display' ) );

		return $this->sanitize_display( $display );
	}

	/**
	 * @param string $display Display mode to validate.
	 *
	 * @return string One of the DISPLAY_* modes.
	 */
	public function sanitize_display( $display ) {
		$modes = [ self::DISPLAY_CODE, self::DISPLAY_FLAG, self::DISPLAY_FLAG_CODE ];

		return in_array( $display, $modes, true ) ? $display : self::DISPLAY_CODE;
	}

	public function get_currency_switcher_html( $html ) {
		$switcher = $this->get_switcher_html();

		return '' !== $switcher ? $switcher : $html;
	}

	/**
	 * @param string $display Optional. Display mode, defaults to the theme option.
	 *
	 * @return string Empty string when the plugin is off.
	 */
	public function get_switcher_html( $display = '' ) {
		if ( ! $this->is_enabled() ) {
			return '';
		}

		ob_start();
		?>
		<div class="currency-switcher-menu-wrap curcy">
			<?php $this->print_menu( $display ); ?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Whether the plugin is active and its currency switching is turned on.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		$settings = $this->get_plugin_settings();

		return ! empty( $settings ) && ! empty( $settings->get_enable() );
	}

	/**
	 * Print the switcher menu itself, without the wrapper.
	 *
	 * @param string $display Optional. Display mode, defaults to the theme option.
	 */
	public function print_menu( $display = '' ) {
		if ( ! $this->is_enabled() ) {
			return;
		}

		$settings         = $this->get_plugin_settings();
		$display          = '' !== $display ? $this->sanitize_display( $display ) : $this->get_display();
		$current_currency = $settings->get_current_currency();
		$links            = $settings->get_links();
		$currency_names   = get_woocommerce_currencies();
		?>
		<ul class="menu currency-switcher-menu woo-multi-currency-menu">
			<li class="menu-item-has-children">
				<a href="#">
					<?php $this->print_item_content( $current_currency, $display, true ); ?>
				</a>
				<ul class="sub-menu">
					<?php foreach ( $links as $code => $link ) : ?>
						<?php
						if ( $code === $current_currency ) {
							continue;
						}

						if ( empty( $currency_names[ $code ] ) ) {
							continue;
						}
						?>
						<li>
							<?php
							/**
							 * `wmc-currency-redirect` and `data-currency` are what the plugin script
							 * listens on, so the switcher keeps working when "Switch currency by JS"
							 * ( the cache compatible mode ) is turned on.
							 *
							 * @see woocommerce-multi-currency-switcher.js
							 */
							?>
							<a href="<?php echo esc_url( $link ); ?>" class="currency-switcher-link wmc-currency-redirect" data-currency="<?php echo esc_attr( $code ); ?>" rel="nofollow">
								<?php $this->print_item_content( $code, $display ); ?>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		</ul>
		<?php
	}

	/**
	 * @param string $currency_code Currency code, eg. USD.
	 * @param string $display       One of the DISPLAY_* modes.
	 * @param bool   $is_current    Whether it is the currently selected currency.
	 */
	private function print_item_content( $currency_code, $display, $is_current = false ) {
		if ( self::DISPLAY_CODE !== $display ) {
			$this->print_flag( $currency_code );
		}

		if ( self::DISPLAY_FLAG === $display ) {
			// The flag alone carries no text, keep the code for screen readers.
			printf( '<span class="screen-reader-text">%s</span>', esc_html( $currency_code ) );

			return;
		}

		$class = $is_current ? 'current-currency-text' : 'currency-text';

		printf( '<span class="%1$s">%2$s</span>', esc_attr( $class ), esc_html( $currency_code ) );
	}

	/**
	 * Print the flag of a currency, either the image uploaded in
	 * Multi Currency > Currency Options or the flag from the plugin sprite.
	 *
	 * @param string $currency_code Currency code, eg. USD.
	 */
	public function print_flag( $currency_code ) {
		$settings = $this->get_plugin_settings();

		if ( empty( $settings ) ) {
			return;
		}

		$country      = $settings->get_country_data( $currency_code );
		$country_code = ! empty( $country['code'] ) ? strtolower( $country['code'] ) : 'unknown';
		$currencies   = $settings->get_list_currencies();
		$custom_flag  = ! empty( $currencies[ $currency_code ]['flag'] ) ? $currencies[ $currency_code ]['flag'] : '';

		echo '<span class="currency-flag">';

		if ( '' !== $custom_flag ) {
			printf(
				'<img class="wmc-currency-custom-flag wmc-custom-flag-%1$s" src="%2$s" alt="" />',
				esc_attr( $country_code ),
				esc_url( $custom_flag )
			);
		} else {
			printf( '<i class="vi-flag-64 flag-%s" aria-hidden="true"></i>', esc_attr( $country_code ) );
		}

		echo '</span>';
	}
}

Curcy_Multi_Currency::instance()->initialize();
