<?php

namespace Minimog\Woo;

defined( 'ABSPATH' ) || exit;

class Cache_Controller {

	/**
	 * Taxonomies whose filter widget counts the theme caches in wc_layered_nav_counts_{taxonomy}.
	 * WooCommerce invalidates the attribute ones itself, and the brand one on its own save paths;
	 * these are the theme's to clear on every path.
	 *
	 * @see \Minimog_WC_Widget_Base::persist_nav_counts_cache()
	 */
	const NAV_COUNTS_TAXONOMIES = array( 'product_cat', 'product_tag', 'product_brand' );

	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		/**
		 * Fires after a WooCommerce system status tool has been executed.
		 *
		 * @param array $tool Details about the tool that has been executed.
		 */
		add_action( 'woocommerce_system_status_tool_executed', array( $this, 'system_status_tool_executed' ) );

		add_action( 'woocommerce_delete_product_transients', array( $this, 'delete_product_transients' ) );

		// Term assignments and status changes made through WordPress directly ( Quick Edit, REST,
		// importers ) do not always pass through the WooCommerce data store, which is what fires
		// woocommerce_delete_product_transients.
		add_action( 'set_object_terms', array( $this, 'delete_nav_counts_on_term_change' ), 10, 6 );
		add_action( 'deleted_term_relationships', array( $this, 'delete_nav_counts_on_term_removal' ), 10, 3 );
		add_action( 'transition_post_status', array( $this, 'delete_nav_counts_on_status_change' ), 10, 3 );
	}

	public function system_status_tool_executed( $tool ) {
		$action_id = $tool['id'];

		switch ( $action_id ) {
			case 'clear_transients':
				/**
				 * @see \Minimog_WC_Widget_Base::get_filtered_term_product_counts()
				 */
				$nav_counts_transients = minimog_get_transient_like( 'wc_layered_nav_counts' );
				if ( ! empty( $nav_counts_transients ) ) {
					foreach ( $nav_counts_transients as $transient ) {
						delete_transient( $transient );
					}
				}

				// The lookup above reads wp_options; with a persistent object cache the transients
				// live elsewhere, so the theme's own keys are deleted by name as well.
				foreach ( self::NAV_COUNTS_TAXONOMIES as $taxonomy ) {
					delete_transient( 'wc_layered_nav_counts_' . sanitize_title( $taxonomy ) );
				}
				break;
			case 'regenerate_thumbnails':
				\Minimog_Attachment::instance()->delete_all_cropped_info();
				break;
		}
	}

	public function delete_product_transients() {
		/**
		 * @see Product_Category::get_min_price()
		 */
		delete_transient( 'minimog_product_category_min_price' );

		/**
		 * @see \Minimog_Woo::get_product_ids_best_selling()
		 */
		delete_transient( 'minimog_product_ids_best_selling' );

		/**
		 * @see \Minimog_Woo::get_product_ids_best_selling()
		 */
		delete_transient( 'minimog_product_ids_new_arrivals' );

		$this->queue_delete_nav_counts();
	}

	/**
	 * A product's terms changed. Any product taxonomy can sit in the main query that the cached
	 * counts were computed for ( a tag filter narrows the category counts, and the other way
	 * round ), so a change in any of them drops both caches.
	 *
	 * @param int    $object_id
	 * @param array  $terms
	 * @param array  $tt_ids
	 * @param string $taxonomy
	 * @param bool   $append
	 * @param array  $old_tt_ids
	 */
	public function delete_nav_counts_on_term_change( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ) {
		if ( ! in_array( $taxonomy, get_object_taxonomies( 'product' ), true ) ) {
			return;
		}

		$new_ids = array_map( 'intval', (array) $tt_ids );
		$old_ids = array_map( 'intval', (array) $old_tt_ids );
		sort( $new_ids );
		sort( $old_ids );

		if ( ! $append && $new_ids === $old_ids ) {
			return;
		}

		$this->queue_delete_nav_counts();
	}

	/**
	 * Terms were taken off an object, as wp_delete_post() does for a product removed outside the
	 * WooCommerce data store, where nothing else the theme listens to fires.
	 *
	 * @param int    $object_id
	 * @param array  $tt_ids
	 * @param string $taxonomy
	 */
	public function delete_nav_counts_on_term_removal( $object_id, $tt_ids, $taxonomy ) {
		if ( empty( $tt_ids ) || ! in_array( $taxonomy, get_object_taxonomies( 'product' ), true ) ) {
			return;
		}

		$this->queue_delete_nav_counts();
	}

	/**
	 * A product was published, unpublished or trashed. Only published products are counted, so a
	 * move between two other statuses ( the auto-draft of "Add New", draft to pending ) changes nothing.
	 *
	 * @param string   $new_status
	 * @param string   $old_status
	 * @param \WP_Post $post
	 */
	public function delete_nav_counts_on_status_change( $new_status, $old_status, $post ) {
		if ( $new_status === $old_status || 'product' !== get_post_type( $post ) ) {
			return;
		}

		if ( 'publish' !== $new_status && 'publish' !== $old_status ) {
			return;
		}

		$this->queue_delete_nav_counts();
	}

	/**
	 * Drop the cached filter widget counts, on shutdown so that a bulk change costs one deletion.
	 *
	 * @param string|array|null $taxonomies Defaults to every taxonomy the theme caches.
	 */
	protected function queue_delete_nav_counts( $taxonomies = null ) {
		$taxonomies = $taxonomies ? (array) $taxonomies : self::NAV_COUNTS_TAXONOMIES;
		$keys       = array();

		foreach ( $taxonomies as $taxonomy ) {
			$keys[] = 'wc_layered_nav_counts_' . sanitize_title( $taxonomy );
		}

		if ( class_exists( '\WC_Cache_Helper' ) && method_exists( '\WC_Cache_Helper', 'queue_delete_transient' ) ) {
			\WC_Cache_Helper::queue_delete_transient( $keys );

			return;
		}

		foreach ( $keys as $key ) {
			delete_transient( $key );
		}
	}
}

Cache_Controller::instance()->initialize();
