<?php

namespace Minimog\Woo;

defined( 'ABSPATH' ) || exit;

/**
 * Product recommendations shown inside the cart drawer.
 *
 * Pure helper: the markup lives in cart/fly-cart.php ( the shell ) and
 * cart/fly-cart-recommendations.php ( the list, fetched over AJAX ).
 */
class Fly_Cart_Recommendations {

	const DEFAULT_LIMIT = 10;

	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function is_enabled() {
		return '1' === \Minimog::setting( 'shopping_cart_drawer_recommendations_enable' );
	}

	/**
	 * Below the desktop breakpoint the panel becomes a horizontal strip inside the cart
	 * body, which not every store wants taking up room next to the cart items.
	 */
	public function is_enabled_on_mobile() {
		return '1' === \Minimog::setting( 'shopping_cart_drawer_recommendations_mobile_enable' );
	}

	/**
	 * A button on every card competes with the drawer's own checkout button, which is
	 * why the panel first shipped without one. It is on by default now, drawn as an
	 * outline so as not to; stores that would rather not have it can turn it off.
	 */
	public function is_add_to_cart_enabled() {
		return '1' === \Minimog::setting( 'shopping_cart_drawer_recommendations_add_to_cart_enable' );
	}

	public function get_limit() {
		$limit = absint( \Minimog::setting( 'shopping_cart_drawer_recommendations_limit' ) );

		return $limit > 0 ? $limit : self::DEFAULT_LIMIT;
	}

	public function get_heading() {
		$heading = trim( (string) \Minimog::setting( 'shopping_cart_drawer_recommendations_title' ) );

		if ( '' === $heading ) {
			$heading = __( 'You might like', 'minimog' );
		}

		return apply_filters( 'minimog/cart_drawer/recommendations/heading', $heading );
	}

	/**
	 * @return \WC_Product[]
	 */
	public function get_products() {
		if ( ! $this->is_enabled() || ! function_exists( 'WC' ) || is_null( WC()->cart ) ) {
			return array();
		}

		$limit   = $this->get_limit();
		$in_cart = $this->get_cart_product_ids();

		/**
		 * A cart line holding a variation is filed under its parent. WooCommerce itself
		 * drops a variation that is in the cart from the cross-sells it works out, but an
		 * ID handed in afterwards - woocommerce_cart_crosssell_ids, the filter below - never
		 * passes that check, and the parent's ID alone would leave it on the list.
		 */
		$exclude = array_values( array_unique( array_merge( $in_cart, $this->get_cart_variation_ids() ) ) );
		$ids     = $this->collect_ids( $limit, $in_cart, $exclude );

		/**
		 * Filter the candidate product IDs before they are turned into products.
		 * Whatever is returned still goes through the visibility / stock filtering below,
		 * so a callback only needs to care about which products to suggest.
		 */
		$ids = apply_filters( 'minimog/cart_drawer/recommendations/product_ids', $ids, $limit, $in_cart );

		return $this->ids_to_products( $ids, $limit, $exclude );
	}

	/**
	 * Parent product IDs currently in the cart. Used both as the seed for related
	 * products and, with the variations' own IDs next to them, as the exclusion list
	 * ( never suggest what is already in the cart ).
	 *
	 * @return int[]
	 */
	protected function get_cart_product_ids() {
		$ids = array();

		foreach ( WC()->cart->get_cart() as $cart_item ) {
			if ( ! empty( $cart_item['product_id'] ) ) {
				$ids[] = (int) $cart_item['product_id'];
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * IDs of the variations currently in the cart. Only ever part of the exclusion list:
	 * related products are looked up by the parent.
	 *
	 * @return int[]
	 */
	protected function get_cart_variation_ids() {
		$ids = array();

		foreach ( WC()->cart->get_cart() as $cart_item ) {
			if ( ! empty( $cart_item['variation_id'] ) ) {
				$ids[] = (int) $cart_item['variation_id'];
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Cross-sells of the cart, topped up with related products of each cart item,
	 * then with the store best sellers so the panel is never empty ( an empty cart
	 * has no cross-sells at all, and that is exactly when a suggestion is worth most ).
	 *
	 * @param int        $limit   How many products the panel shows.
	 * @param int[]      $in_cart Parent product IDs in the cart - what related products are looked up for.
	 * @param int[]|null $exclude IDs never to suggest. Defaults to $in_cart.
	 *
	 * @return int[]
	 */
	protected function collect_ids( $limit, $in_cart, $exclude = null ) {
		if ( null === $exclude ) {
			$exclude = $in_cart;
		}

		/**
		 * Read the cart directly instead of woocommerce_cross_sell_display():
		 * that core function bails out on checkout and renders a template itself.
		 */
		$ids = array_map( 'intval', (array) WC()->cart->get_cross_sells() );
		$ids = array_values( array_diff( $ids, $exclude ) );

		if ( count( $ids ) < $limit ) {
			foreach ( $in_cart as $cart_product_id ) {
				if ( count( $ids ) >= $limit ) {
					break;
				}

				// The parents, not $exclude: related products are never variations, so a
				// variation's ID keeps nothing out here - it only goes into the key
				// WooCommerce caches the lookup under, and splits that cache by variation.
				$related = wc_get_related_products( $cart_product_id, $limit, array_merge( $in_cart, $ids ) );
				$ids     = array_unique( array_merge( $ids, array_map( 'intval', (array) $related ) ) );
			}
		}

		if ( count( $ids ) < $limit ) {
			$best_selling = \Minimog_Woo::instance()->get_product_ids_best_selling();
			$ids          = array_unique( array_merge( $ids, array_map( 'intval', (array) $best_selling ) ) );
		}

		return array_values( array_diff( $ids, $exclude ) );
	}

	/**
	 * @return \WC_Product[]
	 */
	protected function ids_to_products( $ids, $limit, $exclude ) {
		$products          = array();
		$seen              = array();
		$hide_out_of_stock = 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' );

		foreach ( (array) $ids as $id ) {
			if ( count( $products ) >= $limit ) {
				break;
			}

			$id = (int) $id;

			/**
			 * De-duplicate here rather than upstream so it also covers IDs coming back from
			 * the woocommerce_cart_crosssell_ids and recommendations/product_ids filters,
			 * which both run after any dedupe the cart itself does.
			 */
			if ( in_array( $id, $seen, true ) || in_array( $id, $exclude, true ) ) {
				continue;
			}

			$seen[] = $id;

			$product = wc_get_product( $id );

			if ( ! wc_products_array_filter_visible( $product ) ) {
				continue;
			}

			if ( $hide_out_of_stock && ! $product->is_in_stock() ) {
				continue;
			}

			$products[] = $product;
		}

		return $products;
	}
}
