<?php

namespace Minimog\Woo;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Avatar_Upload' ) ) {
	class Avatar_Upload {

		protected static $instance = null;

		static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ] );

			//add_action( 'after_switch_theme', [ $this, 'allows_customer_upload_avatar' ], 10, 2 );

			if ( class_exists( 'Metronet_Profile_Picture' ) ) {
				add_action( 'minimog/myaccount/after_avatar', [ $this, 'upload_icon' ], 5 );
				add_action( 'minimog/myaccount/before_info', [ $this, 'user_profile' ], 5 );

				add_action( 'wp_ajax_minimog_upload_avatar', [ $this, 'ajax_upload_avatar' ] );
				add_action( 'wp_ajax_minimog_remove_avatar', [ $this, 'ajax_remove_avatar' ] );
			}
		}

		/**
		 * @param string    $old_name
		 * @param \WP_Theme $old_theme
		 */
		public function allows_customer_upload_avatar( $old_name, $old_theme ) {
			$allowed_roles_to_upload_files = [
				'subscriber',
				'customer',
			];

			if ( ! empty( $allowed_roles_to_upload_files ) ) {
				foreach ( $allowed_roles_to_upload_files as $role ) {
					$wp_role = get_role( $role );

					if ( $wp_role instanceof \WP_Role ) {
						$wp_role->add_cap( 'upload_files', true );
					}
				}
			}
		}

		public function frontend_scripts() {
			wp_dequeue_script( 'mpp_gutenberg_tabs' );

			$min = \Minimog_Enqueue::instance()->get_min_suffix();

			wp_register_script( 'minimog-avatar-upload', MINIMOG_THEME_URI . "/assets/js/woo/avatar-upload{$min}.js", [
				'minimog-script',
			], MINIMOG_THEME_VERSION, true );

			if ( is_account_page() && is_user_logged_in() ) {
				wp_enqueue_script( 'minimog-avatar-upload' );

				$js_variables = [
					'update_avatar_nonce' => wp_create_nonce( 'minimog-update-user-avatar' ),
				];

				wp_localize_script( 'minimog-avatar-upload', '$minimogUpload', $js_variables );
			}
		}

		/**
		 * Gets a post id for the user - Creates a post if a post doesn't exist
		 *
		 * @param int $user_id User ID of   the user.
		 *
		 * @return int post_id
		 */
		private function get_user_post_id( $user_id = 0 ) {
			$user = get_user_by( 'id', $user_id );

			// Get/Create Profile Picture Post.
			$posts = get_posts( [
				'post_type'   => 'mt_pp',
				'author'      => $user_id,
				'post_status' => 'publish',
			] );

			if ( ! $posts ) {
				$post_id = wp_insert_post( [
					'post_author' => $user_id,
					'post_type'   => 'mt_pp',
					'post_status' => 'publish',
					'post_title'  => $user->data->display_name,
				] );
			} else {
				$post    = end( $posts );
				$post_id = $post->ID;
			}

			return $post_id;
		}

		public function user_profile() {
			?>
			<div class="minimog-user-profile">
				<form action="" method="post" class="minimog-user-profile__form" enctype="multipart/form-data">
					<input type="file" accept="image/*" name="user_avatar" class="tm_user_avatar hidden">

					<div class="minimog-user-profile__action">
						<a href="#" class="upload_avatar">
							<span class="action-icon"><i class="far fa-upload"></i></span>
							<span class="action-text"><?php esc_html_e( 'Upload', 'minimog' ) ?></span>
						</a>
						<a href="#" class="remove_avatar">
							<span class="action-icon"><i class="far fa-trash-alt"></i></span>
							<span class="action-text"><?php esc_html_e( 'Remove', 'minimog' ) ?></span>
						</a>
					</div>
				</form>
			</div>
			<?php
		}

		public function upload_icon() {
			?>
			<a href="#" class="btn-toggle-avatar-upload-menu"
			   aria-label="<?php esc_attr_e( 'Upload', 'minimog' ); ?>"><i class="far fa-camera"></i></a>
			<?php
		}

		public function ajax_remove_avatar() {
			if ( ! check_ajax_referer( 'minimog-update-user-avatar' ) ) {
				wp_die();
			}

			if ( ! is_user_logged_in() ) {
				wp_die();
			}

			// Never trust client-supplied IDs: always act on the current user's own profile-picture post.
			$user_id = get_current_user_id();
			$post_id = $this->get_user_post_id( $user_id );

			if ( 0 === $post_id || 0 === $user_id ) {
				wp_die();
			}

			update_user_option( $user_id, 'metronet_image_id', 0 );
			delete_post_meta( $post_id, '_thumbnail_id' );

			$avatar_url = MINIMOG_THEME_IMAGE_URI . '/person.png';

			wp_send_json( [
				'success' => 1,
				'data'    => $avatar_url,
			] );
		}

		public function ajax_upload_avatar() {
			if ( ! check_ajax_referer( 'minimog-update-user-avatar' ) ) {
				wp_die();
			}

			if ( ! is_user_logged_in() ) {
				wp_die();
			}

			// Never trust client-supplied IDs: always act on the current user's own profile-picture post.
			$user_id = get_current_user_id();
			$post_id = $this->get_user_post_id( $user_id );

			// Restrict avatar uploads to image files only. The accept="image/*" hint is client-side
			// and not enforced by media_handle_upload, so limit the allowed types server-side while
			// still respecting whatever image types the site permits.
			$image_mimes = array();
			foreach ( get_allowed_mime_types() as $ext => $mime ) {
				if ( 0 === strpos( $mime, 'image/' ) ) {
					$image_mimes[ $ext ] = $mime;
				}
			}

			$overrides = array(
				'test_form' => false,
				'mimes'     => $image_mimes,
			);

			$media_id = media_handle_upload( 'user_avatar', $post_id, array(), $overrides );

			$response = array();

			if ( ! is_wp_error( $media_id ) ) {
				update_user_option( $user_id, 'metronet_post_id', $post_id );
				update_user_option( $user_id, 'metronet_image_id', $media_id );

				set_post_thumbnail( $post_id, $media_id );

				$avatar_url = \Minimog_Image::get_the_post_thumbnail_url( [
					'post_id' => $post_id,
					'size'    => '100x100',
				] );

				$response['success'] = 1;
				$response['data']    = $avatar_url;

			} else {
				$response['success'] = 0;
			}

			wp_send_json( $response );
		}
	}

	Avatar_Upload::instance()->initialize();
}
