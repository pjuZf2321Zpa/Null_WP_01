<?php

namespace Minimog\Woo;

defined( 'ABSPATH' ) || exit;

class Enqueue {

	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		// Disable woocommerce all styles.
		add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'update_checkout_script' ], 20 );
		add_filter( 'woocommerce_get_asset_url', [ $this, 'update_wc_scripts_src' ], 9999, 2 );

		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ] );

		add_filter( 'minimog/ajax/refresh_nonce', array( $this, 'refresh_nonce' ) );
	}

	/**
	 * Refresh WooCommerce nonces printed in $minimogWoo.
	 *
	 * @param array $nonces
	 *
	 * @return array
	 * @see \Minimog_AJAX::refresh_nonce()
	 */
	public function refresh_nonce( $nonces ) {
		$nonces['$minimogWoo'] = array(
			'apply_coupon_nonce'  => wp_create_nonce( 'apply-coupon' ),
			'remove_coupon_nonce' => wp_create_nonce( 'remove-coupon' ),
		);

		return $nonces;
	}

	/**
	 * Load scripts and style in admin area
	 *
	 * @return void
	 * @since 1.0.0
	 *
	 */
	public function admin_scripts( $hook ) {
		$screen = get_current_screen();

		if ( in_array( $hook, [ 'post-new.php', 'post.php' ], true ) && 'product' === $screen->post_type ) {
			wp_enqueue_style( 'minimog-product-admin', MINIMOG_THEME_ASSETS_URI . '/admin/css/product-edit.min.css' );
			wp_enqueue_script( 'minimog-product-admin', MINIMOG_THEME_ASSETS_URI . '/admin/js/product.js', [ 'jquery' ], MINIMOG_THEME_VERSION, true );
		}
	}

	public function update_checkout_script() {
		/**
		 * Compatible with FunnelKit Checkout plugin.
		 * Somehow this script not enqueue when updated src, so do not update it in that case.
		 */
		if ( class_exists( '\WFACP_Core' ) ) {
			/*if ( \WFACP_Core()->public->is_checkout_override() ) {
				return;
			}*/

			return;
		}

		$min = \Minimog_Enqueue::instance()->get_min_suffix();
		/**
		 * Used edition version for better performance.
		 * Replace src instead dequeue to avoid missing scripts depends on it.
		 */
		$new_wc_checkout = MINIMOG_THEME_URI . "/assets/js/woo/checkout{$min}.js";
		\Minimog_Enqueue::instance()->update_handle_src( 'wc-checkout', $new_wc_checkout );
	}

	public function frontend_scripts() {
		$min = \Minimog_Enqueue::instance()->get_min_suffix();
		$rtl = \Minimog_Enqueue::instance()->get_rtl_suffix();

		// Remove prettyPhoto, default light box of woocommerce.
		wp_dequeue_script( 'prettyPhoto' );
		wp_dequeue_script( 'prettyPhoto-init' );
		wp_dequeue_style( 'woocommerce_prettyPhoto_css' );

		/**
		 * Dequeue style in compare
		 * Also all third party.
		 */
		wp_dequeue_style( 'hint' );

		/**
		 * Dequeue style in compare / wishlist...
		 */
		wp_dequeue_style( 'perfect-scrollbar-wpc' );

		// Check Pincode/Zipcode Shipping plugin.
		if ( class_exists( 'WPCC' ) ) {
			wp_dequeue_style( 'WPCC_front_style' );
			wp_enqueue_style( 'minimog-wpcc', MINIMOG_THEME_URI . "/assets/css/wc/check-pincode-zipcode{$min}.css", null, MINIMOG_THEME_VERSION );
		}

		if ( Compare::instance()->is_activate() ) {
			wp_dequeue_style( 'woosc-frontend' );

			wp_register_style( 'minimog-wc-compare', MINIMOG_THEME_URI . "/assets/css/wc/compare{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
			wp_enqueue_style( 'minimog-wc-compare' );
		}

		if ( Wishlist::instance()->is_activate() ) {
			wp_dequeue_style( 'woosw-feather' ); // Old version.
			wp_dequeue_style( 'woosw-icons' ); // New version.
			wp_dequeue_style( 'woosw-frontend' );

			wp_register_style( 'minimog-wc-wishlist', MINIMOG_THEME_URI . "/assets/css/wc/wishlist{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
			wp_enqueue_style( 'minimog-wc-wishlist' );

			wp_register_script( 'minimog-wc-wishlist', MINIMOG_THEME_URI . "/assets/js/woo/wishlist{$min}.js", [
				'jquery',
				'woosw-frontend',
			], MINIMOG_THEME_VERSION, true );
			wp_enqueue_script( 'minimog-wc-wishlist' );
		}

		if ( Product_Bought_Together::instance()->is_activate() ) {
			wp_dequeue_style( 'woobt-frontend' );

			wp_register_style( 'minimog-wc-bought-together', MINIMOG_THEME_URI . "/assets/css/wc/bought-together{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
			wp_enqueue_style( 'minimog-wc-bought-together' );
		}

		if ( Notification::instance()->is_activate() ) {
			wp_dequeue_style( 'wpcsn' );

			wp_register_style( 'minimog-wc-notification', MINIMOG_THEME_URI . "/assets/css/wc/notification{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
			wp_enqueue_style( 'minimog-wc-notification' );
		}

		if ( Sales_Countdown_Timer::instance()->is_activate() ) {
			wp_register_style( 'minimog-wc-sale-countdown-timer', MINIMOG_THEME_URI . "/assets/css/wc/sale-countdown-timer{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
			wp_enqueue_style( 'minimog-wc-sale-countdown-timer' );
		}

		if ( defined( 'WOOMULTI_CURRENCY_VERSION' ) ) {
			wp_register_style( 'minimog-wc-multi-currency', MINIMOG_THEME_URI . "/assets/css/wc/multi-currency{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
			wp_enqueue_style( 'minimog-wc-multi-currency' );
		}

		// Swatches.
		wp_dequeue_style( 'isw-frontend' );

		wp_register_style( 'minimog-wc-frontend', MINIMOG_THEME_URI . "/assets/css/wc/frontend{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
		wp_register_style( 'minimog-wc-my-account', MINIMOG_THEME_URI . "/assets/css/wc/my-account{$rtl}{$min}.css", null, MINIMOG_THEME_VERSION );
		wp_register_script( 'minimog-wc-general', MINIMOG_THEME_URI . "/assets/js/woo/general{$min}.js", [
			'jquery',
			'minimog-script', // Run after main script to use Helpers.
			'js-cookie',
		], MINIMOG_THEME_VERSION, true );

		wp_register_script( 'minimog-wc-my-account', MINIMOG_THEME_URI . "/assets/js/woo/my-account{$min}.js", [ 'jquery' ], MINIMOG_THEME_VERSION, true );
		wp_register_script( 'minimog-wc-cart', MINIMOG_THEME_URI . "/assets/js/woo/cart{$min}.js", [
			'jquery',
			'minimog-modal',
			'wc-country-select',
			'wc-address-i18n',
		], MINIMOG_THEME_VERSION, true );
		wp_register_script( 'minimog-wc-coupon', MINIMOG_THEME_URI . "/assets/js/woo/coupon{$min}.js", [
			'jquery',
			'minimog-modal',
			'minimog-wc-general',
		], MINIMOG_THEME_VERSION, true );
		wp_register_script( 'minimog-wc-product', MINIMOG_THEME_URI . "/assets/js/woo/single{$min}.js", [
			'jquery',
			'wc-add-to-cart-variation',
		], MINIMOG_THEME_VERSION, true );
		wp_register_script( 'minimog-wc-questions', MINIMOG_THEME_URI . "/assets/js/woo/product-questions{$min}.js", [
			'jquery',
		], MINIMOG_THEME_VERSION, true );

		/**
		 * Since WC 7.8.0 wc-cart-fragments handle removed from global enqueue.
		 */
		$fly_cart_depends = [
			'jquery',
			'wc-cart-fragments',
			'minimog-quantity-button',
			// Carries $minimogWoo: the drawer reads the add to cart behaviour off it, and
			// the recommendations panel the endpoint it posts to.
			'minimog-wc-general',
		];

		if ( '1' === \Minimog::setting( 'shopping_cart_countdown_enable' ) ) {
			$fly_cart_depends[] = 'minimog-countdown-timer';
		}

		$coupon_enable = wc_coupons_enabled();

		if ( $coupon_enable ) {
			$fly_cart_depends[] = 'minimog-wc-coupon';
		}

		wp_register_script( 'minimog-wc-fly-cart', MINIMOG_THEME_URI . "/assets/js/woo/fly-cart{$min}.js", $fly_cart_depends, MINIMOG_THEME_VERSION, true );

		/**
		 * The URL goes through the filter WooCommerce runs it through for
		 * wc_add_to_cart_params, so a store that sends its customers somewhere other than
		 * the cart after an add still does - but only where the script reads it, which is
		 * with "redirect to the cart after an add" on. WooCommerce passes null for the
		 * product there and so must this, and on a store with the archive AJAX option off
		 * the filter has so far only ever been handed a real product: a callback that
		 * takes that for granted would bring down every page.
		 */
		$cart_redirect_after_add = get_option( 'woocommerce_cart_redirect_after_add' );
		$cart_url                = wc_get_cart_url();

		if ( 'yes' === $cart_redirect_after_add ) {
			$cart_url = apply_filters( 'woocommerce_add_to_cart_redirect', $cart_url, null );
		}

		$woo_variables = array(
			'wc_ajax_url'               => \WC_AJAX::get_endpoint( '%%endpoint%%' ),
			'apply_coupon_nonce'        => wp_create_nonce( 'apply-coupon' ),
			'remove_coupon_nonce'       => wp_create_nonce( 'remove-coupon' ),
			'is_checkout'               => is_checkout(),
			'add_to_cart_behaviour'     => \Minimog::setting( 'add_to_cart_behaviour' ),
			/**
			 * WooCommerce localizes both of these on wc-add-to-cart.js, which it only
			 * enqueues where the archive AJAX option is on - so the cart drawer, which
			 * adds to the cart either way, has to be told separately.
			 */
			'cart_url'                  => $cart_url,
			'cart_redirect_after_add'   => $cart_redirect_after_add,
			/**
			 * Here rather than on the panel's markup, which a child theme may be overriding
			 * from before these existed - and a failed add would then say nothing at all.
			 */
			'recommendation_added_text' => __( 'Added to cart', 'minimog' ),
			'recommendation_error_text' => __( 'Sorry, that could not be added to your cart. Please try again.', 'minimog' ),
		);
		wp_localize_script( 'minimog-wc-general', '$minimogWoo', $woo_variables );

		wp_enqueue_style( 'minimog-wc-frontend' );

		if ( '1' === \Minimog::setting( 'shop_quick_view_enable' ) ) {
			wp_enqueue_script( 'minimog-modal' );

			if ( 'toggles' === \Minimog_Woo::instance()->get_product_setting( 'single_product_tabs_style' ) ) {
				wp_enqueue_script( 'minimog-accordion' );
			}

			/**
			 * Enable ajax add to cart variation in Quick View popup on all pages.
			 */
			wp_enqueue_script( 'wc-add-to-cart-variation' );

			// Quick view need change quantity.
			wp_enqueue_script( 'minimog-quantity-button' );

			wp_enqueue_script( 'minimog-nice-select' );

			if ( '1' === \Minimog::setting( 'shop_quick_view_light_gallery_enable' ) ) {
				wp_enqueue_style( 'lightgallery' );
				wp_enqueue_script( 'lightgallery' );
			}
		}

		wp_enqueue_script( 'minimog-wc-general' );

		/**
		 * Calculate Shipping for Fly Cart
		 * Don't used WC()->cart->needs_shipping()
		 * because scripts won't load when cart empty
		 **/
		if ( 'yes' === get_option( 'woocommerce_enable_shipping_calc' ) && wc_shipping_enabled() ) {
			// Optional for better select.
			wp_enqueue_script( 'selectWoo' );
			wp_enqueue_style( 'select2' );

			// Required.
			wp_enqueue_script( 'wc-country-select' );
		}

		if ( ! is_checkout() ) {
			wp_enqueue_script( 'minimog-wc-fly-cart' );
		}

		if ( \Minimog_Woo::instance()->is_product_archive() ) {
			wp_enqueue_script( 'minimog-nice-select' );
			wp_enqueue_script( 'minimog-common-archive' );

			// Product categories carousel + any shop-loop slider.
			\Minimog_Enqueue::instance()->enqueue_swiper();
		}

		if ( is_account_page() ) {
			wp_enqueue_style( 'minimog-wc-my-account' );
			wp_enqueue_script( 'minimog-wc-my-account' );
		}

		if ( is_cart() ) {
			wp_dequeue_script( 'wc-cart' );

			wp_enqueue_script( 'minimog-wc-coupon' );
			wp_enqueue_script( 'minimog-wc-cart' );
			wp_enqueue_script( 'minimog-quantity-button' );
		}

		if ( is_checkout() ) {
			wp_enqueue_script( 'minimog-wc-coupon' );
			wp_enqueue_script( 'minimog-wc-cart' );
		}

		if ( is_product() ) {
			// Product image gallery slider + related / up-sells / recently-viewed carousels.
			\Minimog_Enqueue::instance()->enqueue_swiper();

			if ( 'toggles' === \Minimog_Woo::instance()->get_product_setting( 'single_product_tabs_style' ) ) {
				wp_enqueue_script( 'minimog-accordion' );
			}

			// We don't need this script because we use modal form.
			wp_dequeue_script( 'comment-reply' );

			wp_enqueue_style( 'lightgallery' );
			wp_enqueue_script( 'lightgallery' );
			wp_enqueue_script( 'minimog-quantity-button' );
			wp_enqueue_script( 'minimog-tab-panel' );
			wp_enqueue_script( 'minimog-modal' );
			wp_enqueue_script( 'spritespin' ); // Product 360.
			wp_enqueue_script( 'readmore' ); // For collapsed content & comments.

			/**
			 * Used for quantity select.
			 */
			wp_enqueue_script( 'minimog-nice-select' );

			wp_enqueue_script( 'minimog-wc-product' );
			wp_enqueue_script( 'minimog-wc-questions' );

			$single_product_variables = array(
				'featureStyle'           => \Minimog_Woo::instance()->get_single_product_images_style(),
				'singleProductStickyBar' => \Minimog::setting( 'single_product_sticky_bar_enable' ),
				'i18n'                   => [
					'filesSelected' => sprintf( esc_html__( '%s files selected', 'minimog' ), '{count}' ),
					'readMore'      => esc_html__( 'Read more', 'minimog' ),
					'readLess'      => esc_html__( 'Read less', 'minimog' ),
				],
			);
			wp_localize_script( 'minimog-wc-product', '$minimogProductSingle', $single_product_variables );
		}
	}

	/**
	 * Used edition version for better performance.
	 * Replace src instead dequeue to avoid missing scripts depends on it.
	 * Priority 99 to run after plugins.
	 *
	 * @version 2.8.0 Update src via wc asset filter instead of update src $wp_scripts->queue to avoid src can't update
	 *          on some ways.
	 */
	public function update_wc_scripts_src( $path, $file ) {
		$min = \Minimog_Enqueue::instance()->get_min_suffix();

		switch ( $file ) :
			case "assets/js/frontend/add-to-cart-variation{$min}.js": // wc-add-to-cart-variation.
				return MINIMOG_THEME_URI . "/assets/js/woo/add-to-cart-variation{$min}.js";
				break;
			case "assets/js/frontend/cart-fragments{$min}.js": // wc-cart-fragments.
				return MINIMOG_THEME_URI . "/assets/js/woo/cart-fragments{$min}.js";
				break;
			case "assets/js/frontend/single-product{$min}.js": // wc-single-product.
				return MINIMOG_THEME_URI . "/assets/js/woo/single-product{$min}.js";
				break;
		endswitch;

		return $path;
	}
}

Enqueue::instance()->initialize();
