<?php

namespace Minimog\Woo;

defined( 'ABSPATH' ) || exit;

class Product_Bought_Together {

	protected static $instance = null;

	/**
	 * @var \WPCleverWoobt $woobt
	 */
	public $woobt;

	const MINIMUM_PLUGIN_VERSION   = '7.5.1';
	const RECOMMEND_PLUGIN_VERSION = '8.0.0';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		if ( ! $this->is_activate() ) {
			return;
		}

		if ( defined( 'WOOBT_VERSION' ) ) {
			if ( version_compare( WOOBT_VERSION, self::RECOMMEND_PLUGIN_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_recommend_plugin_version' ] );
			}

			if ( version_compare( WOOBT_VERSION, self::MINIMUM_PLUGIN_VERSION, '<' ) ) {
				return;
			}
		}

		$this->woobt = \WPCleverWoobt::instance();

		add_action( 'woobt_wrap_before', [ $this, 'add_wrap_tag_open' ] );
		add_action( 'woobt_wrap_after', [ $this, 'add_wrap_tag_close' ] );

		add_filter('woobt_products_class', [$this, 'products_class']);

		/**
		 * The "before text" is printed once inside the theme's own .woobt-header (see add_wrap_tag_open).
		 * Blank the value the plugin would print again inside .woobt-body so it isn't duplicated in the DOM.
		 */
		add_filter( 'woobt_before_text', '__return_empty_string', 99 );
	}

	public function add_wrap_tag_open($product) {
		if ( ! $product ) {
			global $product;

			if ( $product ) {
				$product_id = $product->get_id();
			}
		} else {
			if ( is_a( $product, 'WC_Product' ) ) {
				$product_id = $product->get_id();
			}

			if ( is_numeric( $product ) ) {
				$product_id = absint( $product );
				$product    = wc_get_product( $product_id );
			}
		}

		/**
		 * Resolve the before-text exactly as the plugin does ( product -> rule -> default, plus the
		 * woobt_before_text filter ). Lift the suppressor registered in initialize() — which blanks the
		 * plugin's duplicate copy inside .woobt-body — only for this read so the header gets the real value.
		 */
		remove_filter( 'woobt_before_text', '__return_empty_string', 99 );
		$before_text = apply_filters( 'woobt_before_text', $this->woobt->get_text( $product, 'before' ), $product_id );
		add_filter( 'woobt_before_text', '__return_empty_string', 99 );

		ob_start();
		?>
		<div class="woobt-header">
			<h6 class="woobt-block-heading"><?php esc_html_e( 'Frequently Bought Together', 'minimog' ); ?></h6>
			<?php if ( $before_text ) : ?>
				<div class="woobt-before-text woobt-text"><?php echo do_shortcode( stripslashes( $before_text ) ) ?></div>
			<?php endif; ?>
		</div>
		<div class="woobt-body">
		<?php
		echo ob_get_clean();
	}

	public function add_wrap_tag_close() {
		echo '</div>';
	}

	public function products_class($classes) {
		$classes .= ' product';

		return $classes;
	}

	public function is_activate() {
		return class_exists( 'WPCleverWoobt' );
	}

	public function admin_notice_recommend_plugin_version() {
		minimog_notice_required_plugin_version( 'Frequently Bought Together for WooCommerce', self::RECOMMEND_PLUGIN_VERSION );
	}

}

Product_Bought_Together::instance()->initialize();
