<?php

namespace Minimog\Woo\Variation_Gallery;

defined( 'ABSPATH' ) || exit;

class Backend {

	protected static $instance = null;

	/**
	 * Answer of is_core_gallery_available(), which every gallery read asks for. Null until first asked.
	 *
	 * @var bool|null
	 */
	protected static $core_gallery_available = null;

	const META_KEY = 'gallery_images';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		if ( self::is_core_gallery_available() ) {
			/**
			 * WooCommerce 10.9 added a variation gallery field of its own, directly under the variation
			 * image, and 11.1 made it permanent. Printing the theme field alongside it left two controls
			 * labelled "Variation gallery" in the same row, saving to two different places, only one of
			 * which the storefront ever read. WooCommerce owns the field from here on; galleries built with
			 * the theme field keep working, because Frontend feeds them into the property WooCommerce reads.
			 */
			add_action( 'woocommerce_save_product_variation', array( $this, 'retire_theme_gallery' ), 20, 2 );

			/**
			 * The classic admin is not the only place a gallery is written, and while the theme key is still
			 * there the bridge in Frontend fills every empty WooCommerce gallery from it, so a gallery
			 * cleared through the REST API or an import would come straight back. WooCommerce marks the
			 * variation as its own at the REST point too, though only for the extension meta it inherited;
			 * at the import and the data store it marks nothing, and these handlers stand alone.
			 */
			add_filter( 'woocommerce_rest_pre_insert_product_variation_object', array( $this, 'retire_theme_gallery_on_rest' ), 20, 2 );
			add_action( 'woocommerce_product_import_inserted_product_object', array( $this, 'retire_theme_gallery_on_import' ), 20, 2 );
			add_action( 'woocommerce_product_object_updated_props', array( $this, 'retire_theme_gallery_on_props' ), 20, 2 );

			return;
		}

		add_action( 'woocommerce_save_product_variation', [ $this, 'save_product_variation' ], 10, 2 );
		add_action( 'woocommerce_product_after_variable_attributes', [
			$this,
			'output_variation_gallery_html',
		], 10, 3 );

		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ] );
	}

	/**
	 * Whether WooCommerce shows a variation gallery field of its own.
	 *
	 * Always true from WooCommerce 11.1, where the feature lost its switch. Between 10.9 and 11.0 it follows
	 * the store setting - off unless the store turned it on, bar the small cohort 11.0 opted in by itself -
	 * and below 10.9 the class is simply absent.
	 *
	 * @return bool
	 */
	public static function is_core_gallery_available() {
		if ( null !== self::$core_gallery_available ) {
			return self::$core_gallery_available;
		}

		self::$core_gallery_available = self::resolve_core_gallery_available();

		return self::$core_gallery_available;
	}

	/**
	 * @return bool
	 */
	protected static function resolve_core_gallery_available() {
		if ( ! class_exists( '\Automattic\WooCommerce\Internal\VariationGallery\Package' ) ) {
			return false;
		}

		/**
		 * Answered the three ways Automattic\WooCommerce\Packages::get_enabled_packages() answers it, since
		 * that is what decides whether anything registers the WooCommerce field at all: a store opting out
		 * through this option has the package dropped however Package::is_enabled() replies, and a store
		 * opting in has it loaded without that question being asked.
		 *
		 * Either only parts company with is_enabled() on WooCommerce 10.9 to 11.0, where the feature was
		 * still a setting: off for everyone on 10.9 unless the store turned it on, and on 11.0 off unless
		 * the store turned it on or fell inside the one in twenty WooCommerce opted in by itself. Reading
		 * the option first is what keeps a store that opted out from being left with no gallery field at
		 * all, and a store that opted in early from being shown two.
		 */
		$option_value = get_option( \Automattic\WooCommerce\Internal\VariationGallery\Package::ENABLE_OPTION_NAME, '' );

		if ( 'no' === $option_value ) {
			return false;
		}

		if ( 'yes' === $option_value ) {
			return true;
		}

		return \Automattic\WooCommerce\Internal\VariationGallery\Package::is_enabled();
	}

	/**
	 * Drop the theme meta once a variation has been saved through the WooCommerce gallery field.
	 *
	 * The bridge filter in Frontend only fills in where WooCommerce has no images, so without this a
	 * gallery emptied in the WooCommerce field would come straight back from the old theme meta.
	 *
	 * This runs on the hook that fires after the variation has been written, so a save that fails partway
	 * leaves the old meta where it is. WooCommerce checks the variation save nonce before either hook.
	 *
	 * @param int $variation_id
	 * @param int $loop
	 */
	public function retire_theme_gallery( $variation_id, $loop ) {
		// Indexed only once it is known to be an array: PHP reads an offset of a string happily enough, and
		// a scalar posted under this key would then compare as an empty submission and take the gallery.
		// WooCommerce tests the offset alone, and reads that same submission as a variation with no images
		// at all, so the old meta surviving it is what is left to rebuild from.
		if ( ! isset( $_POST['variable_gallery_image_ids'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			|| ! is_array( $_POST['variable_gallery_image_ids'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			|| ! isset( $_POST['variable_gallery_image_ids'][ $loop ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		$posted = array_values( wp_parse_id_list( wp_unslash( $_POST['variable_gallery_image_ids'][ $loop ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		/**
		 * Retire the old meta only once WooCommerce is holding the result of this very submission, rather
		 * than trusting that it is. WooCommerce writes the first ID of that field as the variation image
		 * and the rest as its gallery, so the two compared say whether the field was really consumed: if
		 * anything else posted this key, or WooCommerce did not apply it, the old gallery stays where it
		 * is and the storefront keeps rendering it.
		 *
		 * The cost of checking is a gallery cleared here not sticking when something else rewrites the
		 * images during the same save, which resurrects it on the next page load. Keeping images that
		 * should have gone is the better way round to be wrong.
		 */
		$expected_image   = (int) ( $posted[0] ?? 0 );
		$expected_gallery = array_values( array_slice( $posted, 1 ) );
		$actual_image     = (int) get_post_thumbnail_id( $variation_id );
		$actual_gallery   = array_values( wp_parse_id_list( get_post_meta( $variation_id, Frontend::CORE_META_KEY, true ) ) );

		if ( $expected_image !== $actual_image || $expected_gallery !== $actual_gallery ) {
			return;
		}

		delete_post_meta( $variation_id, self::META_KEY );
	}

	/**
	 * The REST API writes a variation gallery whenever the request carries one, empty list included - but
	 * only where the endpoint that took the request knows the field.
	 *
	 * WooCommerce builds this hook name out of the post type alone, and both variations controllers share
	 * that post type, so the wc/v2 one fires this filter too while knowing nothing about galleries. A
	 * request sending gallery_image_ids to wc/v2 arrives here with the field unread, and retiring the old
	 * meta on the strength of the field merely being present left that variation with a gallery under
	 * neither key.
	 *
	 * The meta is dropped on the object rather than in the database, so it goes with the same save: a save
	 * that fails partway leaves the old gallery where it is.
	 *
	 * @param \WC_Product_Variation $variation
	 * @param \WP_REST_Request      $request
	 *
	 * @return \WC_Product_Variation
	 */
	public function retire_theme_gallery_on_rest( $variation, $request ) {
		if ( ! $variation instanceof \WC_Product_Variation
			|| ! $request instanceof \WP_REST_Request
			|| ! isset( $request['gallery_image_ids'] ) ) {
			return $variation;
		}

		if ( ! $this->rest_request_writes_gallery( $variation, $request ) ) {
			return $variation;
		}

		/**
		 * Nothing further has to be checked against the database, unlike the classic admin: the meta is
		 * dropped on the object, so it is written by the same save that writes the gallery. A save that
		 * fails writes neither.
		 */
		$variation->delete_meta_data( self::META_KEY );

		return $variation;
	}

	/**
	 * Whether this request is one WooCommerce takes a variation gallery from.
	 *
	 * A list with images in it answers for itself. This filter closes the very step that reads the request,
	 * so whatever the variation is holding by the time it runs either came from this request or was there
	 * beforehand: a gallery drawn from the IDs that were sent is proof the field was read, and a variation
	 * still holding nothing is proof it was not. Reading in edit context is what makes the question
	 * answerable, since the bridge in Frontend fills the view context and would otherwise answer with the
	 * very meta being decided on here. The IDs sent are a superset rather than a match because a controller
	 * is free to leave the variation image out of the gallery it keeps, which the wc/v3 one does.
	 *
	 * The endpoint is asked as well. WordPress builds the arguments of a route out of the item schema of the
	 * controller behind it, dropping only the read-only ones, so those arguments are a faithful list of what
	 * that controller accepts: gallery_image_ids is registered on every writable wc/v3 variation route and
	 * on no wc/v2 one. Asking the endpoint rather than the API version is also what keeps this answer right
	 * for a later namespace, or for someone else's controller inheriting the field.
	 *
	 * Neither question is enough alone. A declared argument is a declaration and nothing more, and the item
	 * schema is keyed on the post type, so anything filtering the field into it without going on to read the
	 * field reaches wc/v2 the same way the hook itself does. An empty list, on the other hand, leaves
	 * nothing to recognise: a variation holding no gallery afterwards looks the same whether the empty list
	 * was applied or ignored, and there the declaration is all there is to go on.
	 *
	 * A batch row is the case with no endpoint behind it. WooCommerce serves /variations/batch by building a
	 * bare request per row and handing it straight to its own controller, so the row carries neither route
	 * nor arguments, and an empty list falls back to the variation: a staged change to the gallery property
	 * is proof that some controller read the field, whichever one it was.
	 *
	 * What that last question misses is a batch row clearing a gallery which only ever lived in the theme
	 * meta, since setting an empty list over an empty WooCommerce gallery changes no property and stages
	 * nothing. Those images stay for the bridge in Frontend to serve again, as they already do in the case
	 * retire_theme_gallery_on_props() documents. Keeping images that should have gone is the better way
	 * round to be wrong, which is why the questions are asked this way round: a field the schema stops
	 * declaring leaves a cleared gallery unretired, where trusting the declaration alone loses one.
	 *
	 * @param \WC_Product_Variation $variation
	 * @param \WP_REST_Request      $request
	 *
	 * @return bool
	 */
	protected function rest_request_writes_gallery( $variation, $request ) {
		$requested  = array_values( wp_parse_id_list( $request['gallery_image_ids'] ) );
		$attributes = $request->get_attributes();

		/**
		 * The route is asked first, and its answer is final. A dispatched request always carries the
		 * arguments of its route, empty though they may be, and WordPress builds those out of the item
		 * schema of the controller behind it: gallery_image_ids is declared on every writable wc/v3
		 * variation route and on no wc/v2 one, so the declaration says exactly whether the field was read.
		 *
		 * Asked after the staged test, it never got the chance on the case that matters most. The wc/v3
		 * controller takes the variation image back out of the gallery it keeps, so a request naming
		 * nothing but that image stages an empty gallery - a legitimate clear, which the staged test read
		 * as proof the field went unread, leaving the old theme gallery to reappear.
		 */
		if ( isset( $attributes['args'] ) ) {
			return isset( $attributes['args']['gallery_image_ids'] );
		}

		/**
		 * No route to appeal to. WooCommerce serves /variations/batch by building a bare request per row
		 * and handing it to its own controller, so the row carries no arguments and the variation has to
		 * answer for itself: a gallery drawn from the IDs that were sent is proof the field was read, and
		 * a staged change to the property says the same where the list was empty.
		 */
		if ( ! empty( $requested ) ) {
			$staged = array_values( wp_parse_id_list( $variation->get_gallery_image_ids( 'edit' ) ) );

			return ! empty( $staged ) && ! array_diff( $staged, $requested );
		}

		return array_key_exists( 'gallery_image_ids', $variation->get_changes() );
	}

	/**
	 * A CSV import writes a gallery whenever the row carries an Images column.
	 *
	 * WooCommerce has to be holding a gallery of its own before the old meta goes. An emptied Images column
	 * is not the merchant asking for no gallery here: the exporter reads the gallery in edit context, where
	 * the bridge in Frontend does not apply, so a gallery living only in the theme meta is missing from the
	 * file to begin with and returns as an empty column on the next import. Retiring on that would lose the
	 * gallery on a plain export, edit, re-import round trip, through the WooCommerce admin, with nothing to
	 * warn the merchant. Where a gallery WooCommerce was really holding is cleared, the data store reports
	 * the removal and retire_theme_gallery_on_props() acts on it instead.
	 *
	 * That other handler does not make this one redundant. A row rewriting a gallery to the value it already
	 * held reports nothing at all, because the data store counts a prop as updated only where the write
	 * succeeded and update_post_meta() answers false for the value already in the row. The theme meta left
	 * behind sits idle while WooCommerce holds a gallery of its own, but Frontend reads the theme key first
	 * on a WooCommerce that has no gallery field, so a store dropping back to one would see it again.
	 *
	 * @param \WC_Product $product
	 * @param array       $data Parsed row.
	 */
	public function retire_theme_gallery_on_import( $product, $data ) {
		if ( ! $product instanceof \WC_Product_Variation || ! isset( $data['raw_gallery_image_ids'] ) ) {
			return;
		}

		if ( ! $this->variation_owns_gallery( $product->get_id() ) ) {
			return;
		}

		delete_post_meta( $product->get_id(), self::META_KEY );
	}

	/**
	 * Whether WooCommerce is holding a gallery of its own for this variation.
	 *
	 * The gallery slot alone, not the variation image: an import row whose first image landed and whose
	 * gallery images did not is exactly the case the caller is guarding against, and the variation image
	 * would answer yes to it. IDs that resolved to nothing are dropped for the same reason, since a failed
	 * import leaves zeroes behind in that slot.
	 *
	 * @param int $variation_id
	 *
	 * @return bool
	 */
	protected function variation_owns_gallery( $variation_id ) {
		$gallery_ids = wp_parse_id_list( get_post_meta( $variation_id, Frontend::CORE_META_KEY, true ) );

		return ! empty( array_filter( $gallery_ids ) );
	}

	/**
	 * Anything else that writes the gallery through the CRUD API, which the data store reports here.
	 *
	 * What this misses is every write the data store has nothing to report. A prop is counted as updated
	 * only where update_post_meta() succeeded, and that answers false for the value already in the row, so
	 * an empty gallery set over an empty one and a gallery rewritten to the value it already held both pass
	 * through in silence. The first leaves the bridge in Frontend serving images that were meant to go, and
	 * there is no hook that would catch it; the second is what retire_theme_gallery_on_import() is for.
	 *
	 * @param \WC_Product $product
	 * @param array       $updated_props
	 */
	public function retire_theme_gallery_on_props( $product, $updated_props ) {
		/**
		 * The data store reports this prop only when it actually wrote or removed the row, so the write
		 * landing is the very thing being reported and there is nothing further to verify.
		 */
		if ( $product instanceof \WC_Product_Variation && in_array( 'gallery_image_ids', (array) $updated_props, true ) ) {
			delete_post_meta( $product->get_id(), self::META_KEY );
		}
	}

	public function output_variation_gallery_html( $loop, $variation_data, $variation ) {
		$variation_id = absint( $variation->ID );

		/**
		 * The gallery the shop actually renders, not just the theme key. A store that moved its galleries
		 * over to the WooCommerce field and then dropped back to a WooCommerce without one keeps its images
		 * under the WooCommerce key, and this field would otherwise sit empty over a gallery still on show,
		 * with no way to edit or clear it.
		 */
		$gallery_images = Frontend::instance()->get_variation_gallery_ids( $variation_id );
		$gallery_ids    = implode( ',', $gallery_images );
		$has_images     = ! empty( $gallery_images );
		?>
		<div data-product_variation_id="<?php echo esc_attr( $variation_id ) ?>" class="form-row form-row-full minimog-variation-gallery-wrapper<?php if ( $has_images ): ?> gallery-has-images<?php endif; ?>">
			<label><?php esc_html_e( 'Variation gallery', 'minimog' ); ?></label>
			<input type="hidden" class="minimog-variation-gallery-ids" name="minimog_variation_gallery[<?php echo esc_attr( $loop ) ?>]" value="<?php echo esc_attr( $gallery_ids ); ?>">
			<div class="minimog-variation-gallery-content">
				<div class="minimog-variation-gallery-images">
					<?php
					foreach ( $gallery_images as $image_id ) :
						$image = wp_get_attachment_image_src( $image_id );

						// Skip an image that has since been deleted from the library rather than reading
						// offset 0 of the false this returns for it.
						if ( empty( $image[0] ) ) {
							continue;
						}
						?>
						<div class="minimog-variation-gallery-thumbnail" style="background-image: url(<?php echo esc_url( $image[0] ); ?>)"></div>
					<?php endforeach; ?>
					<button class="minimog-add-variation-gallery-image" aria-label="<?php esc_attr_e( 'Add variation gallery images', 'minimog' ); ?>">
						<span class="dashicons dashicons-plus-alt2"></span></button>
				</div>
			</div>
			<div class="minimog-clear-variation-gallery-image">
				<a href="#"><?php esc_html_e( 'Clear gallery', 'minimog' ); ?></a>
			</div>
		</div>
		<?php
	}

	public function save_product_variation( $variation_id, $loop ) {
		// Only act on rows where this field was actually printed. Testing the outer key alone let a save
		// coming from anywhere else - a bulk edit, a plugin - clear the gallery it never showed, and the
		// array check keeps a scalar posted under this key from reading as row zero.
		if ( ! isset( $_POST['minimog_variation_gallery'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			|| ! is_array( $_POST['minimog_variation_gallery'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			|| ! isset( $_POST['minimog_variation_gallery'][ $loop ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		// Reduced to a plain ID list rather than kept as posted. The same value is written to WooCommerce's
		// own key below, and its data store explodes that key without casting what comes out, so anything
		// else left in there would reach WC_Product_Variation::get_gallery_image_ids() as it stands.
		$gallery_ids = implode( ',', array_filter( wp_parse_id_list( wp_unslash( $_POST['minimog_variation_gallery'][ $loop ] ) ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		// Nothing of ours and nothing inherited: writing here would leave an empty row on every variation
		// in the store to record a gallery that was never there.
		if ( '' === $gallery_ids
			&& ! metadata_exists( 'post', $variation_id, self::META_KEY )
			&& empty( Frontend::instance()->get_variation_gallery_ids( $variation_id ) ) ) {
			return;
		}

		/**
		 * Written every time from here on, an emptied field included. The row itself is what marks this
		 * field as the owner of the variation's gallery, so an empty value reads as "the merchant cleared
		 * it" rather than "fall back to whatever WooCommerce holds", which is what deleting the row means.
		 */
		update_post_meta( $variation_id, self::META_KEY, $gallery_ids );

		/**
		 * Keep WooCommerce's own key in step. This field is the editor while WooCommerce has none of its
		 * own, and the two stores have to agree, or switching the WooCommerce feature back on - or moving
		 * to a WooCommerce that has it - would show a gallery that was cleared here, or hide one set here.
		 */
		if ( '' === $gallery_ids ) {
			delete_post_meta( $variation_id, Frontend::CORE_META_KEY );
		} else {
			update_post_meta( $variation_id, Frontend::CORE_META_KEY, $gallery_ids );
		}
	}

	public function admin_scripts() {
		global $post, $pagenow;

		if ( $post && ( 'product' === get_post_type( $post->ID ) && ( 'post.php' === $pagenow || 'post-new.php' === $pagenow ) ) ) {
			wp_enqueue_media();
			wp_enqueue_script( 'minimog-wc-variation-gallery', MINIMOG_THEME_ASSETS_URI . '/admin/js/variation-gallery.js', [ 'jquery' ], MINIMOG_THEME_VERSION, true );
		}
	}
}

Backend::instance()->initialize();
