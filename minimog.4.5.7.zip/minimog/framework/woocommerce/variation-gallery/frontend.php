<?php

namespace Minimog\Woo\Variation_Gallery;

defined( 'ABSPATH' ) || exit;

class Frontend {

	protected static $instance = null;

	const META_KEY = 'gallery_images';

	/**
	 * Where WooCommerce keeps a variation gallery, from WooCommerce 10.9 on. Same shape as META_KEY: a
	 * comma separated list of attachment IDs.
	 */
	const CORE_META_KEY = '_product_image_gallery';

	/**
	 * The only template that writes the copy of the original gallery the variation script restores from.
	 */
	const SNAPSHOT_TEMPLATE = 'single-product/product-image-slider.php';

	/**
	 * Class of the copy of the original gallery the slider template writes for a variable product - what the
	 * variation script swaps back to, and so the one sign that a piece of gallery markup came from that
	 * template rather than from the carousel or grid one.
	 */
	const SNAPSHOT_MARKER = 'gallery-main-slides-o-html';

	/**
	 * IDs of the products that template has written it for, this request.
	 *
	 * @var array
	 */
	protected static $snapshot_products = array();

	/**
	 * Handle WooCommerce hangs its variation script on. The theme swaps the file behind it rather than
	 * dequeueing it, so anything attached to the handle still goes out with the page.
	 */
	const CORE_SCRIPT_HANDLE = 'wc-add-to-cart-variation';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		add_filter( 'woocommerce_available_variation', [ $this, 'get_available_variation_gallery' ], 90, 3 );

		/**
		 * Note which products the gallery template writes its restore copy for. That copy is what the
		 * variation script swaps back to, and only single-product/product-image-slider.php writes it, so
		 * watching the template load answers per render what the configured style can only guess at - and
		 * it keeps answering for a child theme that overrides the file, since the name is what is matched.
		 */
		add_action( 'woocommerce_before_template_part', array( $this, 'note_gallery_snapshot' ), 10, 1 );

		/**
		 * WooCommerce 10.9 gave every variation a gallery of its own, and 11.1 turned it on for all stores.
		 * Folding the theme meta into that property leaves one list for both sides to read: the gallery field
		 * WooCommerce shows in the admin lists images added with the theme's old field, and anything calling
		 * $variation->get_gallery_image_ids() sees them too. The storefront is left out of that, for the
		 * reason bridge_theme_gallery_image_ids() gives.
		 *
		 * Priority 20 leaves WooCommerce's own shim for the Additional Variation Images plugin ahead of the
		 * theme meta, since that one runs at priority 10.
		 */
		if ( Backend::is_core_gallery_available() ) {
			add_filter( 'woocommerce_product_variation_get_gallery_image_ids', array( $this, 'bridge_theme_gallery_image_ids' ), 20, 2 );
		}
	}

	/**
	 * Count a render of the slider gallery template for the product it was rendered for.
	 *
	 * A count rather than a flag, because WooCommerce renders the same template itself, once per variation
	 * holding a WooCommerce gallery, inside WC_Product_Variable::get_available_variation() - to hand the
	 * markup over in gallery_images_html. Taken at face value that marked a bundled item, a loop card or an
	 * Elementor product widget as having a gallery copy beside it, and slides were built for a form nothing
	 * could swap. Each of those renders is paid back in forget_gallery_snapshot() when its markup arrives,
	 * so what stays counted is the render of a gallery that is on the page.
	 *
	 * Renders inside the add to cart form are not counted at all: the page's own gallery goes out on
	 * woocommerce_before_single_product_summary, before the form, while everything WooCommerce renders from
	 * woocommerce_variable_add_to_cart() - the wc_variation_gallery_defaults snapshot, the <template> copy,
	 * and the per variation renders of a form on its own page - is a copy for its script, not a gallery.
	 * forget_gallery_snapshot() leaves those alone too, so the two stay in step.
	 *
	 * @param string $template_name
	 */
	public function note_gallery_snapshot( $template_name ) {
		if ( self::SNAPSHOT_TEMPLATE !== $template_name || $this->is_add_to_cart_render() ) {
			return;
		}

		$product = isset( $GLOBALS['product'] ) ? $GLOBALS['product'] : null;

		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		$product_id = $product->get_id();

		self::$snapshot_products[ $product_id ] = isset( self::$snapshot_products[ $product_id ] )
			? self::$snapshot_products[ $product_id ] + 1
			: 1;
	}

	/**
	 * Take back the count of one render of the slider template that was WooCommerce's, not the page's.
	 *
	 * Asked from the woocommerce_available_variation filter when the variation arrives carrying
	 * gallery_images_html. That markup exists only because WooCommerce rendered the gallery template a moment
	 * earlier for this product, whatever images it rendered ( a variation gallery identical to the parent's
	 * leaves no other trace ) - and it is only taken back when the markup carries the slider template's own
	 * copy, since on a Carousel or Grid store WooCommerce's render went through that layout's template and
	 * added nothing to the count, while a layout of its own may have loaded the slider template and did.
	 *
	 * @param int    $product_id
	 * @param string $core_html  The gallery_images_html WooCommerce handed over.
	 */
	protected function forget_gallery_snapshot( $product_id, $core_html ) {
		if ( empty( self::$snapshot_products[ $product_id ] )
			|| ! is_string( $core_html )
			|| false === strpos( $core_html, self::SNAPSHOT_MARKER ) ) {
			return;
		}

		--self::$snapshot_products[ $product_id ];

		if ( self::$snapshot_products[ $product_id ] < 1 ) {
			unset( self::$snapshot_products[ $product_id ] );
		}
	}

	/**
	 * Whether the add to cart form is being rendered - woocommerce_variable_add_to_cart(), or whatever a
	 * swatches plugin puts in its place on that action.
	 *
	 * @return bool
	 */
	protected function is_add_to_cart_render() {
		return doing_action( 'woocommerce_variable_add_to_cart' );
	}

	/**
	 * Drop the inline copy of the product gallery WooCommerce leaves for its own variation script.
	 *
	 * woocommerce_variable_add_to_cart() renders the whole gallery a second time and hands it to the page as
	 * window.wc_variation_gallery_defaults[ product id ], right before loading the add to cart template. The
	 * theme's build of that script restores the gallery from the copies the gallery template already writes,
	 * so this one is never read, and being JSON encoded it costs more than the markup it holds.
	 *
	 * Only the entry belonging to this product goes, leaving anything else attached to the handle alone.
	 *
	 * @param \WC_Product $product
	 */
	public function drop_core_gallery_snapshot( $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		$scripts = wp_scripts();
		$before  = $scripts->get_data( self::CORE_SCRIPT_HANDLE, 'before' );

		if ( empty( $before ) || ! is_array( $before ) ) {
			return;
		}

		$product_key = '[' . $product->get_id() . ']';
		$kept        = array();

		foreach ( $before as $inline_script ) {
			if ( is_string( $inline_script )
				&& false !== strpos( $inline_script, 'wc_variation_gallery_defaults' )
				&& false !== strpos( $inline_script, $product_key ) ) {
				continue;
			}

			$kept[] = $inline_script;
		}

		if ( count( $kept ) !== count( $before ) ) {
			$scripts->add_data( self::CORE_SCRIPT_HANDLE, 'before', $kept );
		}
	}

	/**
	 * Serve the theme's own variation gallery where WooCommerce has none of its own.
	 *
	 * Everywhere the request is admin or REST - admin-ajax included, so the storefront's own load more
	 * handler is bridged too, and pays the cost below for products carrying theme-meta galleries - and not
	 * the storefront page render, where get_gallery_ids() does the same fallback.
	 * WC_Product_Variable::get_available_variation() reads this property and, finding it filled, renders
	 * single-product/product-image.php for that variation and hands the markup over in gallery_images_html -
	 * which get_available_variation_gallery() drops again, unread. Answering here bought a whole gallery
	 * render per variation for nothing: 4.8 ms and 15 KB of markup apiece, measured on a six image gallery,
	 * on every load of a product carrying galleries the merchant built with the theme's old field.
	 *
	 * @param array                 $gallery_image_ids Image IDs WooCommerce resolved.
	 * @param \WC_Product_Variation $variation
	 *
	 * @return array
	 */
	public function bridge_theme_gallery_image_ids( $gallery_image_ids, $variation ) {
		if ( ! empty( $gallery_image_ids )
			|| ! $variation instanceof \WC_Product_Variation
			|| ! $this->is_bridged_context() ) {
			return $gallery_image_ids;
		}

		$theme_ids = $this->get_theme_gallery_ids( $variation->get_id() );

		if ( empty( $theme_ids ) ) {
			return $theme_ids;
		}

		/**
		 * WooCommerce's field shows the variation image first and, on save, writes whatever stands first
		 * back as that image. It puts the image there itself when the list does not hold it; but the theme's
		 * storefront always let a gallery hold that image further down, and served that way the first
		 * gallery image took its place on the first save. So the image is left out here: in WooCommerce's
		 * model the gallery is what follows the variation image, and in view context get_image_id() is the
		 * one the field will show - the variation's own, or the parent's where it has none.
		 */
		$image_id = (int) $variation->get_image_id();

		return array_values( array_diff( array_map( 'intval', $theme_ids ), array( $image_id ) ) );
	}

	/**
	 * Whether this request reads a variation gallery through the WooCommerce property rather than through
	 * the theme's own reader.
	 *
	 * The gallery field WooCommerce prints in the variations metabox reads the property in view context, and
	 * so does the wc/v3 REST response, and both have to list images added with the theme's old field: a REST
	 * client reading a variation and writing it back would otherwise send an empty gallery and clear one
	 * that only ever lived in the theme meta. The storefront has get_gallery_ids() for that. is_admin() is
	 * also true on admin-ajax, so a storefront handler served that way - load more - reads through the
	 * bridge as well; the output is the same, only WooCommerce's render for gallery_images_html is paid.
	 *
	 * Asked per call rather than at registration, because REST_REQUEST is defined on parse_request, long
	 * after this class is loaded.
	 *
	 * @return bool
	 */
	protected function is_bridged_context() {
		if ( is_admin() ) {
			return true;
		}

		/**
		 * WordPress 5.6 is what this theme supports, and wp_is_rest_endpoint() arrived in 6.5 - worth asking
		 * for where it exists, since it answers for a REST request dispatched from inside a page load too,
		 * which the constant knows nothing about.
		 */
		if ( function_exists( 'wp_is_rest_endpoint' ) ) {
			return wp_is_rest_endpoint();
		}

		return defined( 'REST_REQUEST' ) && REST_REQUEST;
	}

	/**
	 * @param array                 $settings
	 * @param \WC_Product           $product
	 * @param \WC_Product_Variation $variation
	 *
	 * @return array
	 */
	public function get_available_variation_gallery( $settings, $product, $variation ) {
		/**
		 * WooCommerce 10.9 and above render single-product/product-image.php once per variation that owns a
		 * gallery and hand the markup over in this key, which ends up inline in the data-product_variations
		 * attribute of the page. The theme serves WooCommerce's variation script from its own build, and that
		 * build rebuilds the gallery from the two keys set below, so the core markup is never read: dropping
		 * it took 12 KB per variation off a product measured with a four image variation gallery.
		 *
		 * Return true from the filter to keep the markup, for anyone running WooCommerce's own script.
		 *
		 * @param bool                       $keep
		 * @param \WC_Product_Variation|null $variation The variation the markup belongs to. Null where the
		 *                                              same filter is asked once for the product as a
		 *                                              whole, which single-product/add-to-cart/variable.php
		 *                                              does for the two snapshots it decides.
		 * @param \WC_Product                $product
		 */
		$core_html = isset( $settings['gallery_images_html'] ) ? $settings['gallery_images_html'] : '';

		if ( ! apply_filters( 'minimog/variation_gallery/keep_core_html', false, $variation, $product ) ) {
			unset( $settings['gallery_images_html'] );
		}

		// See forget_gallery_snapshot(): that render counted as a gallery on the page until now.
		if ( '' !== $core_html && $product instanceof \WC_Product && ! $this->is_add_to_cart_render() ) {
			$this->forget_gallery_snapshot( $product->get_id(), $core_html );
		}

		$open_gallery  = apply_filters( 'minimog/single_product/open_gallery', true );
		$is_quick_view = apply_filters( 'minimog/quick_view/is_showing', false );
		$feature_style = $is_quick_view ? 'slider-02' : $this->get_product_images_style( $product );

		if ( ! $this->layout_swaps_gallery( $feature_style, $product ) ) {
			return $settings;
		}

		$this->prime_theme_gallery_images( $product );

		$gallery_ids = $this->get_gallery_ids( $variation );

		if ( ! empty( $gallery_ids ) ) {
			if ( ! empty( $settings['image_id'] ) ) {
				array_unshift( $gallery_ids, absint( $settings['image_id'] ) );
			}

			$gallery_ids = array_unique( $gallery_ids );

			$variation_gallery_output = \Minimog_Woo::instance()->get_product_image_slider_slide_html( $gallery_ids, [
				'product'         => $product,
				'thumbnail_id'    => 0,
				'open_gallery'    => $open_gallery,
				'main_image_size' => \Minimog_Woo::instance()->get_single_product_image_size_by_feature_style( $feature_style, $is_quick_view ),
			] );

			$settings['variation_gallery_main_slides_html']  = $variation_gallery_output['main_slides_html'];
			$settings['variation_gallery_thumb_slides_html'] = $variation_gallery_output['thumb_slides_html'];
		}

		return $settings;
	}

	/**
	 * Whether the gallery this page is about to render can swap its slides for a variation's own.
	 *
	 * Only single-product/product-image-slider.php writes the copy of the original gallery that the
	 * variation script restores from, and it only writes it for a variable product; without that copy the
	 * script leaves the gallery alone. So on the Carousel and Grid layouts, and in the quick view, which
	 * renders through slider-02, the slides built below would be sent to the page and never read - the same
	 * dead weight this filter drops WooCommerce's own copy for, a few KB per variation holding a gallery.
	 *
	 * @param string           $feature_style The product images style this render will use.
	 * @param \WC_Product|null $product       The product whose variation form is being rendered, when known.
	 *
	 * @return bool
	 */
	protected function layout_swaps_gallery( $feature_style, $product = null ) {
		$product_id = $product instanceof \WC_Product ? $product->get_id() : 0;

		/**
		 * Three ways of answering the one question: will the copy the variation script restores from be on
		 * the page beside this form?
		 *
		 * The render itself is the authority, and it has already happened by the time this runs - the
		 * gallery goes out on woocommerce_before_single_product_summary, the form inside the summary after
		 * it. That alone would rest on the two keeping that order, so the product this page is actually
		 * showing counts too, where the style says a slider gallery is what it will get. Neither applies
		 * inside a get_variation lookup, which renders no gallery at all, so there the style answers alone.
		 *
		 * What all three turn down is the case this is for: a variation form rendered away from the main
		 * gallery - an up-sell list, a bundle, an Elementor product widget - which has no copy beside it
		 * whatever the store is set to, and was being handed slide markup nothing could use.
		 */
		$swaps = ! empty( self::$snapshot_products[ $product_id ] )
			|| ( 'slider' === $feature_style && ( $this->is_product_being_viewed( $product ) || $this->is_variation_lookup() ) );

		/**
		 * Filter whether the theme builds variation gallery slides for this product.
		 *
		 * Return true for a layout of your own that renders the .gallery-main-slides-o-html copy the
		 * variation script restores from.
		 *
		 * @param bool             $swaps
		 * @param string           $feature_style
		 * @param \WC_Product|null $product
		 */
		return apply_filters( 'minimog/variation_gallery/layout_swaps_gallery', $swaps, $feature_style, $product );
	}

	/**
	 * Whether this product is the one the page is built around, rather than one listed on it.
	 *
	 * @param \WC_Product|null $product
	 *
	 * @return bool
	 */
	protected function is_product_being_viewed( $product ) {
		if ( ! $product instanceof \WC_Product || ! function_exists( 'is_product' ) || ! is_product() ) {
			return false;
		}

		return get_queried_object_id() === $product->get_id();
	}

	/**
	 * Whether this request is WooCommerce resolving a single variation.
	 *
	 * Asked of the hook rather than the query string: WooCommerce serves that lookup over its own
	 * ?wc-ajax= endpoint and over admin-ajax alike, and a caching or security plugin filtering
	 * woocommerce_ajax_get_endpoint moves it between them.
	 *
	 * @return bool
	 */
	protected function is_variation_lookup() {
		return doing_action( 'wc_ajax_get_variation' )
			|| doing_action( 'wp_ajax_woocommerce_get_variation' )
			|| doing_action( 'wp_ajax_nopriv_woocommerce_get_variation' );
	}

	/**
	 * The product images style this product renders with.
	 *
	 * Minimog_Woo::get_single_product_images_style() answers for the page being served, out of a global the
	 * theme fills from the post meta of whatever is_singular() names - so it is blind to a product's own
	 * override wherever that product is not the page: the wc-ajax get_variation lookup, which runs on the
	 * front page query, is the case that matters here, since a product overridden to Slider would otherwise
	 * be read as the store default and lose its slides. Read the product's own setting first.
	 *
	 * @param \WC_Product $product
	 *
	 * @return string
	 */
	protected function get_product_images_style( $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return \Minimog_Woo::instance()->get_single_product_images_style();
		}

		$options = get_post_meta( $product->get_id(), 'insight_product_options', true );
		$options = is_string( $options ) && '' !== $options ? maybe_unserialize( $options ) : $options;

		if ( is_array( $options ) && ! empty( $options['single_product_images_style'] ) ) {
			return $options['single_product_images_style'];
		}

		return \Minimog::setting( 'single_product_images_style' );
	}

	/**
	 * Gallery image IDs of a variation, whichever field they were added with.
	 *
	 * @param int $variation_id
	 *
	 * @return array
	 */
	public function get_variation_gallery_ids( $variation_id ) {
		/**
		 * Only the WooCommerce field is read through the variation object, so the legacy path answers from
		 * the two meta keys and leaves the object unloaded. This is asked once per row of the variations
		 * metabox, where that load is the whole cost of the field.
		 */
		if ( ! Backend::is_core_gallery_available() ) {
			return $this->get_legacy_gallery_ids( $variation_id );
		}

		$variation = wc_get_product( $variation_id );

		return $variation instanceof \WC_Product_Variation
			? $this->get_gallery_ids( $variation )
			: $this->get_theme_gallery_ids( $variation_id );
	}

	/**
	 * @param \WC_Product_Variation $variation
	 *
	 * @return array
	 */
	protected function get_gallery_ids( $variation ) {
		$variation_id = $variation->get_id();

		if ( ! Backend::is_core_gallery_available() ) {
			return $this->get_legacy_gallery_ids( $variation_id );
		}

		/**
		 * WooCommerce's own field first and the theme meta behind it, which is the order
		 * bridge_theme_gallery_image_ids() puts them in as well. Done here rather than left to that filter
		 * because the filter stands aside on the storefront, and asking the property first is what keeps
		 * WooCommerce's shim for the Additional Variation Images plugin in the answer.
		 */
		$gallery_ids = $this->clean_ids( (array) $variation->get_gallery_image_ids() );

		return empty( $gallery_ids ) ? $this->get_theme_gallery_ids( $variation_id ) : $gallery_ids;
	}

	/**
	 * Fetch in one pass the attachments behind every gallery on this product that still lives in the theme
	 * meta.
	 *
	 * WooCommerce loads the images of a variable product in one go before building its variations, in
	 * ProductUtil::prime_image_caches(), and it reads the very property the bridge stands aside from here -
	 * so galleries held in the theme meta are missing from that pass, and their images would be fetched one
	 * at a time as each variation renders. Measured on a three variation product carrying six images apiece:
	 * 14 queries against 24.
	 *
	 * Once per product per request, and only for what is left over: _prime_post_caches() drops whatever is
	 * already cached, so a store whose galleries have all moved across to WooCommerce pays one pass over
	 * variation meta that this point in the request has in memory already.
	 *
	 * @param \WC_Product $product
	 */
	protected function prime_theme_gallery_images( $product ) {
		static $primed = array();

		if ( ! Backend::is_core_gallery_available() || ! $product instanceof \WC_Product_Variable ) {
			return;
		}

		/**
		 * Worth doing only where the whole set is about to be rendered. A get_variation lookup resolves one
		 * variation, and there is nothing to save by fetching the images of its siblings.
		 *
		 * Asked of the hook rather than the query string: WooCommerce serves that lookup over its own
		 * ?wc-ajax= endpoint and over admin-ajax alike, and a caching or security plugin filtering
		 * woocommerce_ajax_get_endpoint moves it between them.
		 */
		if ( $this->is_variation_lookup() ) {
			return;
		}

		$product_id = $product->get_id();

		if ( isset( $primed[ $product_id ] ) ) {
			return;
		}

		$primed[ $product_id ] = true;

		$children = $product->get_children();

		if ( empty( $children ) ) {
			return;
		}

		/**
		 * One query for whatever is left. WooCommerce primes the variation meta itself before building the
		 * variations of a variable product, so on that path this call finds everything cached and costs
		 * nothing; it earns its keep on the paths that reach this filter without that priming, where
		 * reading one child at a time would otherwise be a query apiece.
		 */
		update_meta_cache( 'post', $children );

		$image_ids = array();

		foreach ( $children as $child_id ) {
			$image_ids = array_merge( $image_ids, $this->get_theme_gallery_ids( $child_id ) );
		}

		if ( ! empty( $image_ids ) ) {
			_prime_post_caches( array_unique( $image_ids ) );
		}
	}

	/**
	 * Gallery image IDs on a WooCommerce that has no variation gallery field of its own.
	 *
	 * The theme key comes first, then WooCommerce's own. That second read is for the store which once ran
	 * WooCommerce 10.9 or later, moved its galleries across to the WooCommerce field, and has since dropped
	 * back to a WooCommerce without one: those galleries would go missing otherwise, because the theme meta
	 * is retired as each variation moves across.
	 *
	 * @param int $variation_id
	 *
	 * @return array
	 */
	protected function get_legacy_gallery_ids( $variation_id ) {
		/**
		 * A row under the theme key, an empty one included, means the theme field owns this variation: an
		 * empty value there is a gallery the merchant cleared in that field, not one to inherit from
		 * somewhere else. Emptiness alone cannot say both.
		 */
		if ( metadata_exists( 'post', $variation_id, self::META_KEY ) ) {
			return $this->get_theme_gallery_ids( $variation_id );
		}

		return $this->get_ids_from_meta( $variation_id, self::CORE_META_KEY );
	}

	/**
	 * Gallery image IDs held by the theme's own variation gallery field.
	 *
	 * @param int $variation_id
	 *
	 * @return array
	 */
	public function get_theme_gallery_ids( $variation_id ) {
		return $this->get_ids_from_meta( $variation_id, self::META_KEY );
	}

	/**
	 * @param int    $variation_id
	 * @param string $meta_key Holding a comma separated list of attachment IDs.
	 *
	 * @return array
	 */
	protected function get_ids_from_meta( $variation_id, $meta_key ) {
		$gallery_ids = get_post_meta( $variation_id, $meta_key, true );

		if ( is_string( $gallery_ids ) && '' !== $gallery_ids ) {
			$gallery_ids = explode( ',', $gallery_ids );
		}

		return is_array( $gallery_ids ) ? $this->clean_ids( $gallery_ids ) : array();
	}

	protected function clean_ids( $ids ) {
		return array_values( array_filter( array_map( 'absint', $ids ) ) );
	}
}

Frontend::instance()->initialize();
