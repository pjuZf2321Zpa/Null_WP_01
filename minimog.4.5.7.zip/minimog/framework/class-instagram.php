<?php
/**
 * https://developers.facebook.com/docs/instagram-basic-display-api/guides/
 */
defined( 'ABSPATH' ) || exit;

class Minimog_Instagram {

	private static $api_token = null;

	protected static $instance = null;

	const ACCESS_TOKEN_URL = 'https://minimog-wp.gitbook.io/minimog-ecommerce-wordpress-theme/theme-options/instagram';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		// Refresh token every 29 days
		add_action( 'minimog_monthly_tasks', array( $this, 'refresh_access_token' ) );
	}

	public function get_access_token() {
		if ( null === self::$api_token ) {
			self::$api_token = Minimog::setting( 'instagram_access_token' );
		}

		return self::$api_token;
	}

	public function refresh_access_token() {
		$access_token = $this->get_access_token();

		if ( empty( $access_token ) ) {
			return new WP_Error( 'no_access_token', esc_html__( 'No access token', 'minimog' ) );
		}

		$data = wp_remote_get( 'https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token=' . $access_token );
		$data = wp_remote_retrieve_body( $data );
		$data = json_decode( $data, true );

		if ( isset( $data['error'] ) ) {
			return new WP_Error( 'access_token_refresh', $data['error']['message'] );
		}

		if ( empty( $data['access_token'] ) ) {
			return new WP_Error( 'access_token_refresh', esc_html__( 'No access token received', 'minimog' ) );
		}

		$new_access_token = $data['access_token'];

		$redux_options = get_option( 'minimog_options' );

		if ( ! empty( $redux_options ) && is_array( $redux_options ) ) {
			$redux_options['instagram_access_token'] = $new_access_token;
			update_option( 'minimog_options', $redux_options );
		} else {
			set_theme_mod( 'instagram_access_token', $new_access_token );
		}

		return $new_access_token;
	}

	/**
	 * Get user data
	 *
	 * @param string|null $access_token Access token, defaults to the one from Theme Options.
	 *
	 * @return WP_Error|array Either a user array with id and username, or an array with an error key.
	 */
	public function get_user( $access_token = null ) {
		$access_token = ! empty( $access_token ) ? $access_token : $this->get_access_token();

		if ( empty( $access_token ) ) {
			return new WP_Error( 'no_access_token', esc_html__( 'No access token', 'minimog' ) );
		}

		$transient_key = $this->get_user_transient_key( $access_token );
		$user          = get_transient( $transient_key );

		// Anything but an array, a miss or a polluted cache entry, is fetched again.
		if ( ! is_array( $user ) ) {
			$url  = add_query_arg(
				array(
					'fields'       => 'id,username',
					'access_token' => $access_token,
				),
				'https://graph.instagram.com/me'
			);
			$data = wp_remote_retrieve_body( wp_remote_get( $url ) );
			$user = ! empty( $data ) ? json_decode( $data, true ) : null;

			// A response that is neither a usable user nor an Instagram error is treated as an error.
			if ( ! $this->is_valid_user( $user ) && ! isset( $user['error']['message'] ) ) {
				$user = $this->build_error_response( esc_html__( 'No user data received', 'minimog' ) );
			}

			/**
			 * An error response is cached too, for a short time, so a dead token
			 * does not cost an Instagram request on every page view.
			 */
			$expiration = $this->is_valid_user( $user ) ? MONTH_IN_SECONDS : HOUR_IN_SECONDS;

			set_transient( $transient_key, $user, $expiration );
		}

		return $user;
	}

	/**
	 * Transient name for the cached user lookup of a token.
	 *
	 * The token is hashed: option names are limited to 191 characters and a raw token
	 * makes the name longer than that, so the transient could never be read back.
	 *
	 * @param string $access_token
	 *
	 * @return string
	 */
	private function get_user_transient_key( $access_token ) {
		return 'minimog_instagram_user_' . md5( $access_token );
	}

	/**
	 * Whether a user lookup response can be used to fetch media.
	 *
	 * @param mixed $user
	 *
	 * @return bool
	 */
	private function is_valid_user( $user ) {
		return is_array( $user ) && ! isset( $user['error'] ) && ! empty( $user['username'] );
	}

	/**
	 * Build a response in the shape Instagram uses for errors.
	 *
	 * @param string $message
	 *
	 * @return array
	 */
	private function build_error_response( $message ) {
		return array(
			'error' => array(
				'message' => $message,
			),
		);
	}

	/**
	 * Fetch photos from Instagram API
	 *
	 * @param string $access_token
	 *
	 * @return array
	 */
	public function fetch_media( $access_token ) {
		$url = add_query_arg(
			array(
				'fields'       => 'id,caption,media_type,media_url,permalink,thumbnail_url,timestamp',
				'access_token' => $access_token,
			),
			'https://graph.instagram.com/me/media'
		);

		$remote = wp_remote_retrieve_body( wp_remote_get( $url ) );
		$data   = json_decode( $remote, true );
		$images = array();

		if ( isset( $data['error'] ) ) {
			return new WP_Error( 'instagram_error', $data['error']['message'] );
		} elseif ( ! empty( $data['data'] ) ) {
			foreach ( $data['data'] as $media ) {
				$images[] = array(
					'id'      => $media['id'],
					'date'    => date( 'U', strtotime( $media['timestamp'] ) ),
					// Convert ISO 8601 to unixtimestamp for sorting by date.
					'type'    => $media['media_type'],
					'caption' => isset( $media['caption'] ) ? $media['caption'] : $media['id'],
					'link'    => $media['permalink'],
					'images'  => array(
						'thumbnail' => ! empty( $media['thumbnail_url'] ) ? $media['thumbnail_url'] : $media['media_url'],
						'original'  => $media['media_url'],
					),
				);
			}
		}

		return array(
			'images' => $images,
			'paging' => isset( $data['paging'] ) ? $data['paging'] : false,
		);
	}

	/**
	 * Get Instagram images
	 *
	 * @param int $limit
	 *
	 * @return array|WP_Error
	 */
	public function get_images( $limit = 12, $access_token = null ) {
		$access_token = ! empty( $access_token ) ? $access_token : $this->get_access_token();

		if ( empty( $access_token ) ) {
			return new WP_Error( 'instagram_no_access_token', esc_html__( 'No access token', 'minimog' ) );
		}

		$user = $this->get_user( $access_token );

		if ( is_wp_error( $user ) ) {
			return $user;
		}

		if ( ! $this->is_valid_user( $user ) ) {
			$message = isset( $user['error']['message'] ) ? $user['error']['message'] : esc_html__( 'No user data received', 'minimog' );

			return new WP_Error( 'instagram_access_token_expired', $message );
		}

		/**
		 * Cache $images
		 */
		$transient_key = 'minimog_instagram_photos_' . sanitize_title_with_dashes( $user['username'] . '__' . $limit );
		$images        = get_transient( $transient_key );

		if ( false === $images || empty( $images ) ) {
			$images = array();
			$next   = false;

			while ( count( $images ) < $limit ) {
				if ( ! $next ) {
					$fetched = $this->fetch_media( $access_token );
				} else {
					$fetched = $this->fetch_media( $next );
				}

				if ( is_wp_error( $fetched ) ) {
					if ( empty( $images ) ) {
						/**
						 * The token stopped working after its user lookup was cached. Replace that
						 * cache with a short-lived error so the media request is not retried on every view.
						 */
						set_transient(
							$this->get_user_transient_key( $access_token ),
							$this->build_error_response( $fetched->get_error_message() ),
							HOUR_IN_SECONDS
						);

						return $fetched;
					}

					break;
				}

				$images = array_merge( $images, $fetched['images'] );
				$next   = $fetched['paging'] ? $fetched['paging']['cursors']['after'] : false;

				if ( ! $next ) {
					break;
				}
			}

			if ( ! empty( $images ) ) {
				set_transient( $transient_key, $images, HOUR_IN_SECONDS * 2 );
			}
		}

		if ( ! empty( $images ) ) {
			return $images;
		} else {
			return new WP_Error( 'instagram_no_images', esc_html__( 'Instagram did not return any images.', 'minimog' ) );
		}
	}

	/**
	 * Get the markup shown in place of an Instagram widget when the feed can not be loaded.
	 *
	 * Only users who can edit content see it, and it points them to the Instagram Simulator
	 * widgets; visitors get nothing, so an expired token never leaks an API message on the site.
	 *
	 * @param WP_Error $error The error returned by get_images().
	 *
	 * @return string
	 */
	public function get_error_notice( $error ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return '';
		}

		$message = is_wp_error( $error ) ? $error->get_error_message() : '';

		return sprintf(
			'<div class="minimog-instagram-notice"><p>%1$s</p><p>%2$s</p></div>',
			esc_html( $message ),
			esc_html__( 'The Instagram widgets that fetch photos with an access token are deprecated. Please use the Instagram Simulator widgets instead.', 'minimog' )
		);
	}

	/**
	 * Get the output of a photo
	 *
	 * @param array $media Image Data
	 *
	 * @return string
	 */
	public function get_image( $media ) {
		if ( ! is_array( $media ) ) {
			return '';
		}

		$classes = array(
			'minimog-image',
			'minimog-instagram-image',
		);

		$caption = is_array( $media['caption'] ) && isset( $media['caption']['text'] ) ? $media['caption']['text'] : $media['caption'];

		$image_attributes = array(
			'loading' => 'lazy',
			'src'     => $media['images']['thumbnail'],
			'alt'     => $caption,
		);

		$item_classes = array(
			'instagram-item-link',
		);

		$image = \Minimog_Image::build_img_tag( $image_attributes );
		$image = \Minimog_Image::build_lazy_img_tag( $image, 100, 100 );

		return sprintf(
			'<div class="%s">
					<a href="%s" class="%s" target="_blank" rel="nofollow">
						<span class="icon"><i class="fab fa-instagram"></i></span>
						%s
					</a>
				</div>',
			esc_attr( implode( ' ', $classes ) ),
			esc_url( $media['link'] ),
			esc_attr( implode( ' ', $item_classes ) ),
			$image
		);
	}
}

Minimog_Instagram::instance()->initialize();
