<?php
/**
 * AJAX Event Handlers for frontend
 * Using instead of wp_ajax to avoid some wrong conditions like is_admin()
 *
 * @see \WC_AJAX
 */

defined( 'ABSPATH' ) || exit;

class Minimog_AJAX {
	/**
	 * Hook in ajax handlers.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'define_ajax' ), 0 );
		add_action( 'template_redirect', array( __CLASS__, 'do_ajax' ), 0 );

		add_action( 'minimog_ajax_refresh_nonce', array( __CLASS__, 'refresh_nonce' ) );
	}

	/**
	 * Get Ajax Endpoint.
	 *
	 * @param string $request Optional.
	 *
	 * @return string
	 */
	public static function get_endpoint( $request = '' ) {
		return esc_url_raw( apply_filters( 'minimog/ajax/get_endpoint', add_query_arg( 'minimog-ajax', $request, remove_query_arg( array(
			'remove_item',
			'add-to-cart',
			'added-to-cart',
			'order_again',
			'_wpnonce',
		), home_url( '/', 'relative' ) ) ), $request ) );
	}

	/**
	 * Set WC AJAX constant and headers.
	 */
	public static function define_ajax() {
		// phpcs:disable
		if ( ! empty( $_GET['minimog-ajax'] ) ) {
			minimog_maybe_define_constant( 'DOING_AJAX', true );
			minimog_maybe_define_constant( 'WC_DOING_AJAX', true );
			if ( ! WP_DEBUG || ( WP_DEBUG && ! WP_DEBUG_DISPLAY ) ) {
				@ini_set( 'display_errors', 0 ); // Turn off display_errors during AJAX events to prevent malformed JSON.
			}
			$GLOBALS['wpdb']->hide_errors();
		}
		// phpcs:enable
	}

	/**
	 * Send headers for Ajax Requests.
	 */
	private static function send_ajax_headers() {
		if ( ! headers_sent() ) {
			send_origin_headers();
			send_nosniff_header();
			if ( function_exists( 'wc_nocache_headers' ) ) {
				wc_nocache_headers();
			} else {
				nocache_headers();
			}
			header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
			header( 'X-Robots-Tag: noindex' );
			status_header( 200 );
		} elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			headers_sent( $file, $line );
			trigger_error( "send_ajax_headers cannot set headers - headers already sent by {$file} on line {$line}", E_USER_NOTICE ); // @codingStandardsIgnoreLine
		}
	}

	/**
	 * Check for Ajax request and fire action.
	 */
	public static function do_ajax() {
		global $wp_query;

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( ! empty( $_GET['minimog-ajax'] ) ) {
			$wp_query->set( 'minimog-ajax', sanitize_text_field( wp_unslash( $_GET['minimog-ajax'] ) ) );
		}

		$action = $wp_query->get( 'minimog-ajax' );

		if ( $action ) {
			self::send_ajax_headers();
			$action = sanitize_text_field( $action );
			do_action( 'minimog_ajax_' . $action );
			wp_die();
		}
		// phpcs:enable
	}

	/**
	 * Send fresh security nonces to the front-end.
	 *
	 * Full-page caches (server or plugin) may serve visitors an HTML copy whose
	 * embedded nonces have already expired (a nonce lives 12-24 hours). When a
	 * request signed with such a nonce is rejected (403), the front-end calls
	 * this endpoint (never cached) to get valid nonces and retries the request.
	 *
	 * Two kinds of nonces are refreshed:
	 * - globals: properties of JS objects printed via wp_localize_script(),
	 *   e.g. $minimog.nonce.
	 * - fields: hidden form inputs printed via wp_nonce_field(), keyed by the
	 *   input name, e.g. user_login_nonce.
	 *
	 * @see assets/js/modules/helpers.js
	 */
	public static function refresh_nonce() {
		$globals = array(
			'$minimog' => array(
				'nonce' => wp_create_nonce( 'minimog-security' ),
			),
		);

		/**
		 * Filters the JS global nonces refreshed for the front-end.
		 *
		 * Keys are the names of the global JS objects registered via
		 * wp_localize_script(); values are arrays of property => nonce.
		 *
		 * @param array $globals
		 */
		$globals = apply_filters( 'minimog/ajax/refresh_nonce', $globals );

		/**
		 * Filters the form field nonces refreshed for the front-end.
		 *
		 * Keys are the names of hidden inputs printed via wp_nonce_field();
		 * values are the fresh nonces.
		 *
		 * @param array $fields
		 */
		$fields = apply_filters( 'minimog/ajax/refresh_nonce_fields', array() );

		wp_send_json_success( array(
			'globals' => $globals,
			'fields'  => $fields,
		) );
	}
}

Minimog_AJAX::init();
