<?php
defined( 'ABSPATH' ) || exit;

/**
 * Plugin installation and activation for WordPress themes
 */
class Minimog_Register_Plugins {

	const GOOGLE_DRIVER_API = 'AIzaSyDXOs0Bxx-uBEA4fH4fzgoHtl64g0RWv-g';

	public function __construct() {
		add_filter( 'insight_core_tgm_plugins', array( $this, 'register_required_plugins' ) );

		add_filter( 'insight_core_compatible_plugins', array( $this, 'register_compatible_plugins' ) );

		// Override update package URLs for bundled premium plugins.
		// Prevents "Update package not available" when plugins have their own
		// update checker that requires a license key (e.g. WPC plugins).
		// Uses upgrader_package_options to inject the correct package URL
		// right before WordPress downloads it, bypassing PUC interference.
		add_filter( 'upgrader_package_options', array( $this, 'override_bundled_plugin_package' ) );
	}

	public function register_required_plugins( $plugins ) {
		/*
		 * Array of plugin arrays. Required keys are name and slug.
		 * If the source is NOT from the .org repo, then source is also required.
		 */
		$new_plugins = array(
			array(
				'name'        => 'Insight Core',
				'description' => 'Core functions for WordPress theme',
				'slug'        => 'insight-core',
				'logo'        => 'insight',
				'source'      => $this->get_plugin_google_driver_url( '1yqn_qJTkbrbRCQQoQgWRIppMLmBx97TO' ),
				'version'     => '2.8.4',
				'required'    => true,
			),
			array(
				'name'        => 'Redux Framework',
				'description' => 'Build better sites in WordPress fast',
				'slug'        => 'redux-framework',
				'logo'        => 'redux-framework',
				'required'    => true,
			),
			array(
				'name'        => 'Elementor',
				'description' => 'The Elementor Website Builder has it all: drag and drop page builder, pixel perfect design, mobile responsive editing, and more.',
				'slug'        => 'elementor',
				'logo'        => 'elementor',
				'required'    => true,
			),
			array(
				'name'        => 'Thememove Addons For Elementor',
				'description' => 'Additional functions for Elementor',
				'slug'        => 'tm-addons-for-elementor',
				'logo'        => 'insight',
				'source'      => $this->get_plugin_google_driver_url( '1HPKaI5nUpbMxwDsuqOhnY2uLcXNEHJIT' ),
				'version'     => '2.1.2',
				'required'    => true,
			),
			array(
				'name'        => 'WPForms',
				'description' => 'Beginner friendly WordPress contact form plugin. Use our Drag & Drop form builder to create your WordPress forms',
				'slug'        => 'wpforms-lite',
				'logo'        => 'wpforms-lite',
			),
			array(
				'name'        => 'WooCommerce',
				'description' => 'An eCommerce toolkit that helps you sell anything. Beautifully.',
				'slug'        => 'woocommerce',
				'logo'        => 'woocommerce',
			),
			array(
				'name'        => 'Insight Swatches',
				'description' => 'Allows you set a style for each attribute variation as color, image, or label on product page.',
				'slug'        => 'insight-swatches',
				'logo'        => 'insight',
				'source'      => $this->get_plugin_google_driver_url( '1CPYAIyTRCzThJJosm4Y88rX3PD9lhRJn' ),
				'version'     => '1.8.1',
			),
			array(
				'name'        => 'Insight Product Brands',
				'description' => 'Add brands for products',
				'slug'        => 'insight-product-brands',
				'logo'        => 'insight',
				'source'      => $this->get_plugin_google_driver_url( '182mSvi_dDcYPGkI2pMQlet-qYRiP9cE4' ),
				'version'     => '1.5.0',
			),
			array(
				'name'        => 'Conditional Discounts for WooCommerce',
				'description' => 'This plugin is a simple yet advanced WooCommerce dynamic discount plugin ideal for all types of deals.',
				'slug'        => 'woo-advanced-discounts',
				'logo'        => 'woo-advanced-discounts',
			),
			array(
				'name'        => 'Sales Countdown Timer (Premium)',
				'description' => 'Create a sense of urgency with a countdown to the beginning or end of sales, store launch or other events for higher conversions.',
				'slug'        => 'sctv-sales-countdown-timer',
				'logo'        => 'sctv-sales-countdown-timer',
				'source'      => $this->get_plugin_google_driver_url( '1tGOwx3iRCbjuTQUfG5Fz10nHOQdvhQSA' ),
				'version'     => '1.1.11',
			),
			array(
				'name'        => 'WPC Smart Compare for WooCommerce (Premium)',
				'description' => 'Allows your visitors to compare some products of your shop.',
				'slug'        => 'woo-smart-compare-premium',
				'logo'        => 'woo-smart-compare',
				'source'      => $this->get_plugin_google_driver_url( '1stVl3PxbhkYMGxeXHJ0726sjXtJPfw9c' ),
				'version'     => '6.7.0',
			),
			array(
				'name'        => 'WPC Smart Wishlist for WooCommerce (Premium)',
				'description' => 'Allows your visitors save products for buy later.',
				'slug'        => 'woo-smart-wishlist-premium',
				'logo'        => 'woo-smart-wishlist',
				'source'      => $this->get_plugin_google_driver_url( '1o7Np-XI-gRcOBoHsLenAOFhbMVwYb8Ab' ),
				'version'     => '6.2.0',
			),
			array(
				'name'        => 'WPC Frequently Bought Together for WooCommerce (Premium)',
				'description' => 'Increase your sales with personalized product recommendations',
				'slug'        => 'woo-bought-together-premium',
				'logo'        => 'woo-bought-together-premium',
				'source'      => $this->get_plugin_google_driver_url( '1f7uw8SYDJJQpMD74YxgImFc45MmzpchD' ),
				'version'     => '8.0.2',
			),
			array(
				'name'        => 'WPC Product Bundles for WooCommerce (Premium)',
				'description' => 'This plugin helps you bundle a few products, offer them at a discount and watch the sales go up.',
				'slug'        => 'woo-product-bundle-premium',
				'logo'        => 'woo-product-bundle-premium',
				'source'      => $this->get_plugin_google_driver_url( '1B0aAQVxovvb3U8Uz16J2m69BKi5i6SJk' ),
				'version'     => '8.7.8',
			),
			array(
				'name'        => 'WPC Product Tabs for WooCommerce (Premium)',
				'description' => 'Allows adding custom tabs to your products and provide your buyers with extra details for boosting customers’ confidence in the items.',
				'slug'        => 'wpc-product-tabs-premium',
				'logo'        => 'wpc-product-tabs-premium',
				'source'      => $this->get_plugin_google_driver_url( '1sSlJIHgEvc6QAK9p93PE-oXLeEohrr94' ),
				'version'     => '4.4.0',
			),
			array(
				'name'        => 'Shoppable Images',
				'description' => 'Easily add \'shoppable images\' (images with hotspots) to your website or store',
				'slug'        => 'mabel-shoppable-images-lite',
				'logo'        => 'mabel-shoppable-images-lite',
			),
		);

		return array_merge( $plugins, $new_plugins );
	}

	public function register_compatible_plugins( $plugins ) {
		/**
		 * Each Item should have 'compatible'
		 * 'compatible': set be "true" to work correctly
		 */
		$new_plugins = array(
			array(
				'name'        => 'Multi Currency for WooCommerce (Premium)',
				'description' => 'Allows to display prices and accepts payments in multiple currencies.',
				'slug'        => 'woocommerce-multi-currency',
				'logo'        => 'woocommerce-multi-currency',
				'source'      => $this->get_plugin_google_driver_url( '1KJMW6eZ4fJrcbFxpSHN_oYLcE0TyVe9p' ),
				'version'     => '2.4.6',
				'compatible'  => true,
			),
			array(
				'name'        => 'WPC Smart Notification for WooCommerce (Premium)',
				'description' => 'Increase trust, credibility, and sales with smart notifications.',
				'slug'        => 'wpc-smart-notification-premium',
				'logo'        => 'wpc-smart-notification',
				'source'      => $this->get_plugin_google_driver_url( '1jSk_OHGjWrQ8qNVox1irSqA7pO-4HRg2' ),
				'version'     => '2.5.4',
				'compatible'  => true,
			),
			array(
				'name'        => 'Revolution Slider',
				'description' => 'This plugin helps beginner-and mid-level designers WOW their clients with pro-level visuals. You’ll be able to create anything you can imagine, not just amazing, responsive sliders.',
				'slug'        => 'revslider',
				'logo'        => 'revslider',
				'source'      => $this->get_plugin_google_driver_url( '11KuN-KAINjsrw6zXrrU4WWlm2z2RMbAx' ),
				'version'     => '6.8.1',
				'compatible'  => true,
			),
			array(
				'name'        => 'WordPress Social Login',
				'description' => 'Allows your visitors to login, comment and share with Facebook, Google, Apple, Twitter, LinkedIn etc using customizable buttons.',
				'slug'        => 'miniorange-login-openid',
				'logo'        => 'miniorange-login-openid',
				'compatible'  => true,
			),
			array(
				'name'        => 'User Profile Picture',
				'description' => 'Allows your visitors upload their avatar with the native WP uploader.',
				'slug'        => 'metronet-profile-picture',
				'logo'        => 'metronet-profile-picture',
				'compatible'  => true,
			),
			array(
				'name'        => 'DCO Comment Attachment',
				'description' => 'Allows your visitors to attach files with their comments.',
				'slug'        => 'dco-comment-attachment',
				'logo'        => 'dco-comment-attachment',
				'compatible'  => true,
			),
			array(
				'name'        => 'hCaptcha for WordPress',
				'description' => 'Add captcha to protects user privacy, rewards websites, and helps companies get their data labeled. Help build a better web.',
				'slug'        => 'hcaptcha-for-forms-and-more',
				'logo'        => 'hcaptcha-for-forms-and-more',
				'compatible'  => true,
			),
		);

		return array_merge( $plugins, $new_plugins );
	}

	public function get_plugin_google_driver_url( $file_id ) {
		return "https://www.googleapis.com/drive/v3/files/{$file_id}?alt=media&key=" . self::GOOGLE_DRIVER_API;
	}

	/**
	 * Get bundled plugin sources keyed by plugin file path (e.g. "slug/main-file.php").
	 *
	 * @return array Associative array of plugin_file_path => google_drive_url.
	 */
	private function get_bundled_plugin_sources() {
		static $sources = null;

		if ( null !== $sources ) {
			return $sources;
		}

		$sources     = array();
		$all_plugins = array_merge(
			$this->register_required_plugins( array() ),
			$this->register_compatible_plugins( array() )
		);

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$installed_plugins = get_plugins();

		foreach ( $all_plugins as $plugin ) {
			if ( empty( $plugin['source'] ) || empty( $plugin['slug'] ) ) {
				continue;
			}

			// Find the installed plugin file path matching this slug.
			foreach ( $installed_plugins as $file_path => $data ) {
				if ( strpos( $file_path, $plugin['slug'] . '/' ) === 0 ) {
					$sources[ $file_path ] = $plugin['source'];
					break;
				}
			}
		}

		return $sources;
	}

	/**
	 * Override the download package URL for bundled premium plugins.
	 *
	 * Fires via 'upgrader_package_options' right before WordPress downloads
	 * the plugin zip. This cannot be overridden by the plugin's own PUC
	 * update checker, solving the "Update package not available" error.
	 *
	 * @param array $options Package options including 'package' URL and 'hook_extra'.
	 *
	 * @return array Modified options with the correct package URL.
	 */
	public function override_bundled_plugin_package( $options ) {
		// Only act on plugin updates.
		if ( empty( $options['hook_extra']['plugin'] ) ) {
			return $options;
		}

		$plugin_file = $options['hook_extra']['plugin'];
		$sources     = $this->get_bundled_plugin_sources();

		if ( isset( $sources[ $plugin_file ] ) ) {
			$options['package'] = $sources[ $plugin_file ];
		}

		return $options;
	}
}

new Minimog_Register_Plugins();
