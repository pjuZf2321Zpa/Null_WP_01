<?php
defined( 'ABSPATH' ) || exit;

class Minimog_Captcha_Turnstile extends Minimog_Captcha_Provider {

	public function get_id(): string {
		return 'turnstile';
	}

	public function get_name(): string {
		return 'Cloudflare Turnstile';
	}

	public function get_response_field(): string {
		return 'cf-turnstile-response';
	}

	public function enqueue_scripts() {
		wp_enqueue_script(
			'minimog-cloudflare-turnstile',
			'https://challenges.cloudflare.com/turnstile/v0/api.js?onload=minimogCaptchaOnload&render=explicit',
			array( 'minimog-captcha' ),
			null, // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- external API, no cache-busting wanted.
			true
		);
	}

	public function render_widget( string $form_id ) {
		// No 'cf-turnstile' class: another plugin loading api.js in implicit mode
		// would auto-claim the container. We render explicitly by our own class.
		printf(
			'<div class="minimog-captcha-widget" data-theme="%s" data-size="%s" data-form-id="%s"></div>',
			esc_attr( Minimog::setting( 'captcha_theme' ) ),
			esc_attr( Minimog::setting( 'captcha_size' ) ),
			esc_attr( $form_id )
		);
	}

	public function verify( string $form_id ) {
		$response = $this->get_token();

		if ( '' === $response ) {
			return new WP_Error( 'captcha_missing', __( 'Please complete the captcha', 'minimog' ) );
		}

		$result = $this->remote_verify(
			'https://challenges.cloudflare.com/turnstile/v0/siteverify',
			array(
				'secret'   => $this->get_secret_key(),
				'response' => $response,
				'remoteip' => $this->get_remote_ip(),
			)
		);

		if ( is_wp_error( $result ) || empty( $result['success'] ) ) {
			return new WP_Error( 'captcha_invalid', __( 'The captcha verification failed', 'minimog' ) );
		}

		return true;
	}
}
