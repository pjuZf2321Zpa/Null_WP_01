<?php
defined( 'ABSPATH' ) || exit;

class Minimog_Captcha_Recaptcha_V3 extends Minimog_Captcha_Provider {

	public function get_id(): string {
		return 'recaptcha_v3';
	}

	public function get_name(): string {
		return 'Google reCAPTCHA v3';
	}

	public function get_response_field(): string {
		return 'g-recaptcha-response';
	}

	public function enqueue_scripts() {
		wp_enqueue_script(
			'minimog-google-recaptcha-v3',
			'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $this->get_site_key() ),
			array( 'minimog-captcha' ),
			null, // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- external API, no cache-busting wanted.
			true
		);
	}

	public function render_widget( string $form_id ) {
		// Token is filled by MinimogCaptcha.execute() right before each submit —
		// v3 tokens are short-lived, rendering one at page load would expire.
		printf(
			'<input type="hidden" name="g-recaptcha-response" class="minimog-recaptcha-v3-token" data-form-id="%s" />',
			esc_attr( $form_id )
		);
	}

	public function verify( string $form_id ) {
		$response = $this->get_token();

		if ( '' === $response ) {
			return new WP_Error( 'captcha_missing', __( 'Captcha verification failed. Please try again.', 'minimog' ) );
		}

		$result = $this->remote_verify(
			'https://www.google.com/recaptcha/api/siteverify',
			array(
				'secret'   => $this->get_secret_key(),
				'response' => $response,
				'remoteip' => $this->get_remote_ip(),
			)
		);

		if ( is_wp_error( $result ) || empty( $result['success'] ) ) {
			return new WP_Error( 'captcha_invalid', __( 'The captcha verification failed', 'minimog' ) );
		}

		// v3 responses always carry both fields — their absence means the keys
		// are the wrong type (v2) and score-based protection is silently off.
		if ( ! isset( $result['score'], $result['action'] ) ) {
			return new WP_Error( 'captcha_invalid', __( 'The captcha verification failed', 'minimog' ) );
		}

		// Fail closed on malformed responses: on PHP 8 a non-numeric score
		// string would compare as greater than the float threshold and pass.
		if ( ! is_numeric( $result['score'] ) ) {
			return new WP_Error( 'captcha_invalid', __( 'The captcha verification failed', 'minimog' ) );
		}

		$score = (float) $result['score'];

		if ( $score < 0 || $score > 1 ) {
			return new WP_Error( 'captcha_invalid', __( 'The captcha verification failed', 'minimog' ) );
		}

		// Expected action derived server-side from the form id — client-sent
		// action values cannot be trusted.
		$expected_action = 'minimog_' . $form_id;

		if ( $result['action'] !== $expected_action ) {
			return new WP_Error( 'captcha_action_mismatch', __( 'Captcha action mismatch', 'minimog' ) );
		}

		$score_threshold = floatval( Minimog::setting( 'recaptcha_v3_score_threshold', 0.5 ) );

		if ( $score < $score_threshold ) {
			// Score appended for support debugging.
			return new WP_Error(
				'captcha_low_score',
				sprintf(
					/* translators: %s: reCAPTCHA score. */
					__( 'Captcha verification failed. You appear to be a bot. (%s)', 'minimog' ),
					$score
				)
			);
		}

		return true;
	}
}
