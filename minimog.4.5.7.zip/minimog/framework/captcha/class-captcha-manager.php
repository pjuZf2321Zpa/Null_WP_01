<?php
defined( 'ABSPATH' ) || exit;

class Minimog_Captcha_Manager {

	/**
	 * Reuse-ticket lifetime in seconds — sized for slow 3DS challenges
	 * (bank app round-trips can take more than two minutes).
	 */
	const TOKEN_CACHE_TTL = 600;

	protected static $instance = null;

	/**
	 * @var Minimog_Captcha_Provider|null
	 */
	protected $provider = null;

	/**
	 * Exact ticket key computed when this request's checkout token verified.
	 * Stored because later hooks must not recompute it: when a guest chooses
	 * "Create account", WC creates and logs the user in before
	 * woocommerce_checkout_order_processed, which would change the identity
	 * part of the key.
	 *
	 * @var string
	 */
	protected $checkout_ticket_key = '';

	/**
	 * Whether this request intends to / began creating an order. Set by three
	 * fail-closed markers: end of checkout validation (primary), the
	 * woocommerce_create_order filter, and woocommerce_checkout_create_order.
	 *
	 * @var bool
	 */
	protected $checkout_order_created = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		/**
		 * The $minimog_options global is populated on 'init': by Minimog_Redux at
		 * priority 9 on the frontend, by Redux::create_redux() at priority 10 in
		 * admin/admin-ajax requests → run setup at 11 so both paths are covered.
		 * Still early enough for every verify hook: WC form handlers run on
		 * wp_loaded, wc-ajax and wp-comments-post.php fire after init.
		 */
		add_action( 'init', array( $this, 'setup' ), 11 );
	}

	public function setup() {
		// hCaptcha plugin active → Minimog_Hcaptcha handles captcha, skip built-in system.
		if ( class_exists( 'HCaptcha\Main' ) ) {
			return;
		}

		$provider_id = Minimog::setting( 'captcha_provider' );

		if ( empty( $provider_id ) || 'none' === $provider_id ) {
			return;
		}

		$this->provider = $this->create_provider( $provider_id );

		if ( ! $this->provider || ! $this->provider->is_configured() ) {
			return;
		}

		if ( ! file_exists( __DIR__ . '/class-captcha-forms.php' ) ) {
			return;
		}

		require_once __DIR__ . '/class-captcha-forms.php';
		Minimog_Captcha_Forms::instance()->initialize( $this );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'flag_order_creation_intent' ), PHP_INT_MAX, 2 );
		add_filter( 'woocommerce_create_order', array( $this, 'flag_order_creation_filter' ), 0 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'flag_order_creation' ), 1 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'clear_checkout_token_cache' ) );
	}

	/**
	 * PRIMARY fail-closed marker. Runs at the very end of checkout validation
	 * and mirrors WC's own gate for attempting order creation: no validation
	 * errors, no error notices, not an update-totals request. Flagging here —
	 * BEFORE WC dispatches the woocommerce_create_order filter — closes the
	 * fatal-inside-the-filter-chain gap: a plugin callback at a negative or
	 * earlier-registered priority that saves an order and terminates would
	 * stop the chain before any in-chain marker.
	 *
	 * The legit two-phase defer keeps its ticket: gateways abort by adding an
	 * error notice during validation, which leaves this flag unset.
	 *
	 * @param array    $data   Posted checkout data.
	 * @param WP_Error $errors Validation errors collected so far.
	 */
	public function flag_order_creation_intent( $data, $errors ) {
		if ( is_wp_error( $errors ) && $errors->has_errors() ) {
			return;
		}

		if ( function_exists( 'wc_notice_count' ) && wc_notice_count( 'error' ) > 0 ) {
			return;
		}

		if ( ! empty( $data['woocommerce_checkout_update_totals'] ) ) {
			return;
		}

		$this->checkout_order_created = true;
	}

	/**
	 * Defense-in-depth marker: WC's official short-circuit lets extensions
	 * return an order id from this filter, skipping the rest of create_order()
	 * — including the woocommerce_checkout_create_order action below. Filter
	 * chains run every callback when no one fatals, so this also flags order
	 * attempts reached through paths that skipped checkout validation.
	 * Value passes through untouched.
	 *
	 * @param mixed $order_id Value being filtered (null unless an extension
	 *                        short-circuits order creation).
	 *
	 * @return mixed
	 */
	public function flag_order_creation_filter( $order_id ) {
		$this->checkout_order_created = true;

		return $order_id;
	}

	/**
	 * Defense-in-depth marker on the regular path: fires before the order is
	 * saved. WC persists the order and then runs extension hooks before
	 * woocommerce_checkout_order_processed — a callback fataling in that
	 * window would leave a saved order with the "processed" signal never
	 * firing.
	 */
	public function flag_order_creation() {
		$this->checkout_order_created = true;
	}

	/**
	 * @param string $id Provider id from theme options.
	 *
	 * @return Minimog_Captcha_Provider|null
	 */
	protected function create_provider( string $id ) {
		$map = array(
			'recaptcha_v2' => array( 'class-captcha-recaptcha-v2.php', 'Minimog_Captcha_Recaptcha_V2' ),
			'recaptcha_v3' => array( 'class-captcha-recaptcha-v3.php', 'Minimog_Captcha_Recaptcha_V3' ),
			'turnstile'    => array( 'class-captcha-turnstile.php', 'Minimog_Captcha_Turnstile' ),
		);

		if ( ! isset( $map[ $id ] ) || ! file_exists( __DIR__ . '/' . $map[ $id ][0] ) ) {
			return null;
		}

		require_once __DIR__ . '/' . $map[ $id ][0];

		return new $map[ $id ][1]();
	}

	public function get_provider() {
		return $this->provider;
	}

	/**
	 * Whether captcha is enabled for a form.
	 * Redux multi-checkbox stores [ 'login' => '1', 'register' => '0', ... ].
	 *
	 * @param string $form_id Form identifier.
	 */
	public function is_form_enabled( string $form_id ): bool {
		$enabled_forms = Minimog::setting( 'captcha_forms' );

		return is_array( $enabled_forms ) && ! empty( $enabled_forms[ $form_id ] );
	}

	/**
	 * Render the captcha widget for a form.
	 *
	 * @param string $form_id Form identifier.
	 */
	public function render_captcha( string $form_id ) {
		if ( ! $this->provider || ! $this->is_form_enabled( $form_id ) ) {
			return;
		}

		$this->provider->render_widget( $form_id );
	}

	/**
	 * Verify captcha for a form.
	 *
	 * Checkout: some gateways run a two-phase flow (tokenization/3DS aborts the first
	 * request with a marker notice, then resubmits the SAME form data) → the same
	 * single-use token (v2/Turnstile) passes through verification twice and the second
	 * pass is guaranteed to fail. Solution: a DEFERRED single reuse ticket, keyed by
	 * token hash + visitor identity — issued on shutdown only when the request never
	 * intended to create an order (see maybe_issue_reuse_ticket and the fail-closed
	 * markers in setup), claimed atomically exactly once by the gateway's resubmit.
	 *
	 * @param string $form_id Form identifier.
	 *
	 * @return true|WP_Error
	 */
	public function verify_captcha( string $form_id ) {
		if ( ! $this->provider || ! $this->is_form_enabled( $form_id ) ) {
			return true; // Captcha not enabled for this form → pass.
		}

		$use_cache = ( 'checkout' === $form_id );
		$token     = $use_cache ? $this->provider->get_token() : '';
		$cache_key = '' !== $token ? $this->get_token_cache_key( $form_id, $token ) : '';

		if ( '' !== $cache_key && $this->claim_reuse_ticket( $cache_key ) ) {
			return true;
		}

		$result = $this->provider->verify( $form_id );

		if ( '' !== $cache_key && true === $result ) {
			/*
			 * Do NOT issue the reuse ticket here: this request is still running
			 * and may take seconds inside the payment gateway — a parallel
			 * request with the same token could claim the ticket meanwhile and
			 * both would produce orders. The ticket is issued on shutdown, and
			 * only when the request ended without ever STARTING an order — that
			 * covers the gateway defer (tokenization/3DS) as well as ordinary
			 * validation failures; either way at most one extra pass exists.
			 */
			$this->checkout_ticket_key = $cache_key;

			add_action( 'shutdown', array( $this, 'maybe_issue_reuse_ticket' ) );
		}

		return $result;
	}

	/**
	 * Issue the single reuse ticket at request end — but only for requests
	 * that verified a checkout token and finished without ever starting an
	 * order. A checkout that reached order creation never issues a ticket,
	 * even if a later callback fataled before woocommerce_checkout_order_processed.
	 */
	public function maybe_issue_reuse_ticket() {
		if ( $this->checkout_order_created || '' === $this->checkout_ticket_key ) {
			return;
		}

		$this->create_reuse_ticket( $this->checkout_ticket_key );
	}

	/**
	 * Store one reuse ticket for the gateway two-phase resubmit (tokenization/
	 * 3DS aborts the first request, then silently resubmits the same form
	 * data — the same single-use token must pass validation once more).
	 *
	 * Tickets live in wp_options but are managed with direct queries on
	 * purpose: get_option()/delete_option() would pollute the notoptions/
	 * options object caches with unbounded token-hash names, and the claim
	 * must be arbitrated by the database. The value is the expiry timestamp.
	 *
	 * @param string $cache_key Ticket option name.
	 */
	protected function create_reuse_ticket( string $cache_key ) {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- atomic ticket store, must bypass option caches.
		// Garbage-collect expired tickets from abandoned checkouts while here.
		// esc_like(): underscores are single-char wildcards in LIKE — unescaped
		// they could match (and delete) foreign options.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %d",
				$wpdb->esc_like( 'minimog_captcha_ok_' ) . '%',
				time()
			)
		);

		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$wpdb->options} ( option_name, option_value, autoload ) VALUES ( %s, %d, 'no' )
				ON DUPLICATE KEY UPDATE option_value = VALUES( option_value )",
				$cache_key,
				time() + self::TOKEN_CACHE_TTL
			)
		);
		// phpcs:enable
	}

	/**
	 * Atomically claim the reuse ticket: the DELETE's affected-rows count is
	 * the arbiter, so concurrent requests racing on one ticket get exactly
	 * one winner; the expiry check lives in the same predicate.
	 *
	 * @param string $cache_key Ticket option name.
	 */
	protected function claim_reuse_ticket( string $cache_key ): bool {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- atomic single-winner claim.
		$claimed = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value >= %d",
				$cache_key,
				time()
			)
		);
		// phpcs:enable

		return (bool) $claimed;
	}

	/**
	 * Remove a ticket unconditionally (expired or not).
	 *
	 * @param string $cache_key Ticket option name.
	 */
	protected function delete_reuse_ticket( string $cache_key ) {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- see create_reuse_ticket().
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s",
				$cache_key
			)
		);
		// phpcs:enable
	}

	/**
	 * Cache key bound to the visitor so a verified token cannot be replayed
	 * from another session. The WC session id is cookie-bound and survives
	 * mid-checkout IP changes (mobile networks during a 3DS challenge) — IP
	 * is only the fallback when no session exists.
	 *
	 * @param string $form_id Form identifier.
	 * @param string $token   Captcha token from the request.
	 */
	protected function get_token_cache_key( string $form_id, string $token ): string {
		$identity = '';

		if ( function_exists( 'WC' ) && WC()->session ) {
			$identity = (string) WC()->session->get_customer_id();
		}

		if ( '' === $identity ) {
			$identity = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		}

		return 'minimog_captcha_ok_' . md5( $form_id . '|' . $token . '|' . $identity . '|' . get_current_user_id() );
	}

	/**
	 * Order created → no reuse ticket must exist for this token: suppress the
	 * shutdown issuance and drop any row from an earlier aborted attempt.
	 */
	public function clear_checkout_token_cache() {
		$this->checkout_order_created = true;

		// The key remembered at verify time — recomputing it here would use
		// the freshly created/logged-in customer identity and miss the row.
		if ( '' !== $this->checkout_ticket_key ) {
			$this->delete_reuse_ticket( $this->checkout_ticket_key );

			return;
		}

		if ( ! $this->provider ) {
			return;
		}

		$token = $this->provider->get_token();

		if ( '' !== $token ) {
			$this->delete_reuse_ticket( $this->get_token_cache_key( 'checkout', $token ) );
		}
	}

	public function enqueue_scripts() {
		if ( ! $this->provider ) {
			return;
		}

		$min = Minimog_Enqueue::instance()->get_min_suffix();

		wp_register_script( 'minimog-captcha', MINIMOG_THEME_URI . "/assets/js/captcha{$min}.js", array( 'jquery' ), MINIMOG_THEME_VERSION, true );

		wp_localize_script(
			'minimog-captcha',
			'minimogCaptchaConfig',
			array(
				'provider' => $this->provider->get_id(),
				'siteKey'  => $this->provider->get_site_key(),
			)
		);

		wp_enqueue_script( 'minimog-captcha' );

		// Provider api.js depends on 'minimog-captcha' so window.minimogCaptchaOnload
		// exists when its onload callback fires.
		$this->provider->enqueue_scripts();
	}
}

Minimog_Captcha_Manager::instance()->initialize();
