<?php
defined( 'ABSPATH' ) || exit;

class Minimog_Captcha_Forms {

	protected static $instance = null;

	/**
	 * @var Minimog_Captcha_Manager|null
	 */
	protected $manager = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize( Minimog_Captcha_Manager $manager ) {
		$this->manager = $manager;

		// Theme modal forms (AJAX). Same hooks as Minimog_Hcaptcha — captcha
		// verification runs after each handler's nonce check, merged into WP_Error.
		add_action( 'minimog/modal_user_login/after_form_fields', array( $this, 'render_login' ) );
		add_action( 'minimog/modal_user_register/after_form_fields', array( $this, 'render_register' ) );
		add_action( 'minimog/modal_user_lost_password/after_form_fields', array( $this, 'render_lost_password' ) );
		add_filter( 'minimog/user_login/errors', array( $this, 'verify_login' ) );
		add_filter( 'minimog/user_register/errors', array( $this, 'verify_register' ) );
		add_filter( 'minimog/user_reset_password/errors', array( $this, 'verify_lost_password' ) );

		// WooCommerce checkout.
		add_action( 'woocommerce_review_order_before_submit', array( $this, 'render_checkout' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'verify_checkout' ), 10, 2 );

		// Comments: product review + blog comment.
		add_action( 'comment_form_after_fields', array( $this, 'render_comment' ) );
		add_action( 'comment_form_logged_in_after', array( $this, 'render_comment' ) );
		add_filter( 'preprocess_comment', array( $this, 'verify_comment' ) );

		// WooCommerce My Account login/register/lost password.
		add_action( 'woocommerce_login_form', array( $this, 'render_wc_login' ) );
		add_action( 'woocommerce_register_form', array( $this, 'render_wc_register' ) );
		add_action( 'woocommerce_lostpassword_form', array( $this, 'render_wc_lost_password' ) );
		add_filter( 'woocommerce_process_login_errors', array( $this, 'verify_wc_login' ) );
		add_filter( 'woocommerce_process_registration_errors', array( $this, 'verify_wc_register' ) );
		add_action( 'lostpassword_post', array( $this, 'verify_wc_lost_password' ) );

		// Product questions.
		add_action( 'minimog/product_question/after_form_fields', array( $this, 'render_question' ) );
		add_filter( 'minimog/product_question/errors', array( $this, 'verify_question' ) );
	}

	public function render_login() {
		$this->manager->render_captcha( 'login' );
	}

	public function render_register() {
		$this->manager->render_captcha( 'register' );
	}

	public function render_lost_password() {
		$this->manager->render_captcha( 'lost_password' );
	}

	public function render_checkout() {
		$this->manager->render_captcha( 'checkout' );
	}

	public function render_comment() {
		$form_id = ( 'product' === get_post_type() ) ? 'review' : 'comment';

		$this->manager->render_captcha( $form_id );
	}

	public function render_wc_login() {
		$this->manager->render_captcha( 'wc_login' );
	}

	public function render_wc_register() {
		$this->manager->render_captcha( 'wc_register' );
	}

	public function render_wc_lost_password() {
		$this->manager->render_captcha( 'wc_lost_password' );
	}

	public function render_question() {
		$this->manager->render_captcha( 'question' );
	}

	public function verify_login( $errors ) {
		return $this->add_error_if_failed( $errors, 'login' );
	}

	public function verify_register( $errors ) {
		return $this->add_error_if_failed( $errors, 'register' );
	}

	public function verify_lost_password( $errors ) {
		return $this->add_error_if_failed( $errors, 'lost_password' );
	}

	/**
	 * @param array    $data   Posted checkout data.
	 * @param WP_Error $errors Checkout validation errors.
	 */
	public function verify_checkout( $data, $errors ) {
		/*
		 * Gateway pre-validation AJAX (e.g. Stripe wc-ajax=wc_stripe_frontend_request)
		 * runs checkout validation outside the real submit — verifying here would
		 * consume the single-use token and the real submit would then fail.
		 */
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- request-type detection only.
		$wc_ajax = isset( $_GET['wc-ajax'] ) ? sanitize_text_field( wp_unslash( $_GET['wc-ajax'] ) ) : '';

		if ( '' !== $wc_ajax && 'checkout' !== $wc_ajax ) {
			return;
		}

		// Express payment buttons (Apple Pay / Google Pay / PayPal button) place
		// orders without rendering the checkout form → no widget, no token.
		if ( $this->is_express_checkout() ) {
			return;
		}

		$result = $this->manager->verify_captcha( 'checkout' );

		if ( is_wp_error( $result ) ) {
			$errors->add( 'captcha_error', $result->get_error_message() );
		}
	}

	/**
	 * @param array $commentdata Comment data.
	 *
	 * @return array
	 */
	public function verify_comment( $commentdata ) {
		/*
		 * Skip admin-side replies and cron. is_admin() also covers admin-ajax,
		 * including the product question flow (minimog_add_comment), which runs
		 * its own verification via minimog/product_question/errors.
		 */
		if ( is_admin() || wp_doing_cron() ) {
			return $commentdata;
		}

		// REST/XML-RPC clients authenticate on their own and cannot solve a
		// captcha; anonymous comment creation is disabled there by default.
		if ( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) ) {
			return $commentdata;
		}

		// Skip pingbacks/trackbacks — no human, no widget; captcha would kill them all.
		if ( ! empty( $commentdata['comment_type'] ) && ! in_array( $commentdata['comment_type'], array( 'comment', 'review' ), true ) ) {
			return $commentdata;
		}

		// Trusted users bypass.
		if ( current_user_can( 'moderate_comments' ) ) {
			return $commentdata;
		}

		$post_type = get_post_type( $commentdata['comment_post_ID'] );
		$form_id   = ( 'product' === $post_type ) ? 'review' : 'comment';

		$result = $this->manager->verify_captcha( $form_id );

		if ( is_wp_error( $result ) ) {
			wp_die(
				'<p>' . esc_html( $result->get_error_message() ) . '</p>',
				esc_html__( 'Captcha Error', 'minimog' ),
				array(
					'back_link' => true,
					'response'  => 403,
				)
			);
		}

		return $commentdata;
	}

	public function verify_wc_login( $errors ) {
		return $this->add_error_if_failed( $errors, 'wc_login' );
	}

	public function verify_wc_register( $errors ) {
		return $this->add_error_if_failed( $errors, 'wc_register' );
	}

	/**
	 * 'lostpassword_post' also fires for the wp-login.php form (no widget there)
	 * → only verify requests coming from the WC My Account form.
	 *
	 * @param WP_Error $errors Passed by object handle — added errors block the reset.
	 */
	public function verify_wc_lost_password( $errors ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- presence check only, WC validates its own nonce.
		if ( ! isset( $_POST['wc_reset_password'] ) ) {
			return;
		}

		$this->add_error_if_failed( $errors, 'wc_lost_password' );
	}

	public function verify_question( $errors ) {
		return $this->add_error_if_failed( $errors, 'question' );
	}

	/**
	 * Detect express-pay checkout requests. Markers per gateway:
	 * Stripe / WooPayments payment request buttons post `payment_request_type` or
	 * `express_payment_type` (Apple Pay / Google Pay / Link); PayPal Payments
	 * smart buttons post `funding_source`. Limited to known gateway ids;
	 * filterable for gateway-specific edge cases.
	 */
	protected function is_express_checkout(): bool {
		// Kill-switch: stores without express payment buttons disable the skip
		// entirely, removing the spoofable client-marker path altogether.
		if ( ! Minimog::setting( 'captcha_checkout_skip_express' ) ) {
			return false;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- detection only, WC already validated its own nonce.
		$payment_method = isset( $_POST['payment_method'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) ) : '';
		$has_marker     = isset( $_POST['payment_request_type'] ) || isset( $_POST['express_payment_type'] ) || isset( $_POST['funding_source'] );
		// phpcs:enable

		$is_express = false;

		/*
		 * The markers are client-sent and spoofable — only honor them when the
		 * claimed gateway is a known express-capable one AND actually enabled on
		 * this store, so the bypass is closed on every store not running these
		 * gateways. Sites can tighten the residual case via the filter below.
		 */
		if ( $has_marker && in_array( $payment_method, array( 'stripe', 'woocommerce_payments', 'ppcp-gateway' ), true ) && function_exists( 'WC' ) ) {
			$available_gateways = WC()->payment_gateways()->get_available_payment_gateways();
			$is_express         = isset( $available_gateways[ $payment_method ] );
		}

		return (bool) apply_filters( 'minimog/captcha/is_express_checkout', $is_express, $payment_method );
	}

	/**
	 * @param WP_Error $errors  Error collection.
	 * @param string   $form_id Form identifier.
	 *
	 * @return WP_Error
	 */
	protected function add_error_if_failed( $errors, string $form_id ) {
		$result = $this->manager->verify_captcha( $form_id );

		if ( is_wp_error( $result ) ) {
			$errors->add( 'captcha_error', $result->get_error_message() );
		}

		return $errors;
	}
}
