<?php
defined( 'ABSPATH' ) || exit;

abstract class Minimog_Captcha_Provider {

	/**
	 * Provider ID (recaptcha_v2, recaptcha_v3, turnstile)
	 *
	 * @return string
	 */
	abstract public function get_id(): string;

	/**
	 * Provider display name
	 *
	 * @return string
	 */
	abstract public function get_name(): string;

	/**
	 * POST field name carrying the captcha token (e.g. g-recaptcha-response).
	 *
	 * @return string
	 */
	abstract public function get_response_field(): string;

	public function get_site_key(): string {
		return (string) Minimog::setting( $this->get_id() . '_site_key' );
	}

	public function get_secret_key(): string {
		return (string) Minimog::setting( $this->get_id() . '_secret_key' );
	}

	public function is_configured(): bool {
		return '' !== $this->get_site_key() && '' !== $this->get_secret_key();
	}

	/**
	 * Token sent by the client in the current request.
	 * The manager uses it to cache verification results per token
	 * (two-phase checkout flows re-validate the same single-use token).
	 *
	 * @return string
	 */
	public function get_token(): string {
		return $this->get_post_value( $this->get_response_field() );
	}

	/**
	 * Enqueue the provider JS API.
	 * Must declare [ 'minimog-captcha' ] as dependency so the onload callback
	 * (window.minimogCaptchaOnload) exists before the api.js fires it.
	 *
	 * @return void
	 */
	abstract public function enqueue_scripts();

	/**
	 * Render the captcha widget HTML.
	 *
	 * @param string $form_id Unique form identifier (login, register, checkout...).
	 *
	 * @return void
	 */
	abstract public function render_widget( string $form_id );

	/**
	 * Server-side verification.
	 * Receives $form_id so the expected action (reCAPTCHA v3) is derived
	 * server-side instead of trusting client-sent data.
	 *
	 * @param string $form_id Unique form identifier.
	 *
	 * @return true|WP_Error
	 */
	abstract public function verify( string $form_id );

	/**
	 * Call the provider siteverify endpoint.
	 * wp_safe_remote_post blocks redirects to internal hosts.
	 *
	 * @param string $url  Verify endpoint URL.
	 * @param array  $body Request body.
	 *
	 * @return array|WP_Error
	 */
	protected function remote_verify( string $url, array $body ) {
		$response = wp_safe_remote_post(
			$url,
			array(
				'timeout' => 15,
				'body'    => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) ) {
			return new WP_Error( 'captcha_bad_response', __( 'The captcha verification failed', 'minimog' ) );
		}

		return $data;
	}

	/**
	 * Read a token value from POST.
	 * The captcha token itself is the proof of humanity; host forms carry their own nonces.
	 *
	 * @param string $key POST field name.
	 *
	 * @return string
	 */
	protected function get_post_value( string $key ): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}

	protected function get_remote_ip(): string {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}
}
