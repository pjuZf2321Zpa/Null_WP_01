<?php
defined( 'ABSPATH' ) || exit;

class Minimog_Captcha_Recaptcha_V2 extends Minimog_Captcha_Provider {

	public function get_id(): string {
		return 'recaptcha_v2';
	}

	public function get_name(): string {
		return 'Google reCAPTCHA v2';
	}

	public function get_response_field(): string {
		return 'g-recaptcha-response';
	}

	public function enqueue_scripts() {
		// onload=minimogCaptchaOnload renders widgets once api.js is ready —
		// document.ready timing is not guaranteed for external scripts.
		// Prefixed handle: CF7 and others register 'google-recaptcha' with their
		// own URL/render mode — a shared handle would keep the first registration.
		wp_enqueue_script(
			'minimog-google-recaptcha',
			'https://www.google.com/recaptcha/api.js?onload=minimogCaptchaOnload&render=explicit',
			array( 'minimog-captcha' ),
			null, // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- external API, no cache-busting wanted.
			true
		);
	}

	public function render_widget( string $form_id ) {
		// No 'g-recaptcha' class: another plugin loading api.js in implicit mode
		// would auto-claim the container. We render explicitly by our own class.
		printf(
			'<div class="minimog-captcha-widget" data-theme="%s" data-size="%s" data-form-id="%s"></div>',
			esc_attr( Minimog::setting( 'captcha_theme' ) ),
			esc_attr( Minimog::setting( 'captcha_size' ) ),
			esc_attr( $form_id )
		);
	}

	public function verify( string $form_id ) {
		$response = $this->get_token();

		if ( '' === $response ) {
			return new WP_Error( 'captcha_missing', __( 'Please complete the captcha', 'minimog' ) );
		}

		$result = $this->remote_verify(
			'https://www.google.com/recaptcha/api/siteverify',
			array(
				'secret'   => $this->get_secret_key(),
				'response' => $response,
				'remoteip' => $this->get_remote_ip(),
			)
		);

		if ( is_wp_error( $result ) || empty( $result['success'] ) ) {
			return new WP_Error( 'captcha_invalid', __( 'The captcha verification failed', 'minimog' ) );
		}

		return true;
	}
}
