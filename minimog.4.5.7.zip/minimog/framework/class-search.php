<?php
defined( 'ABSPATH' ) || exit;

class Minimog_Search {

	protected static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function initialize() {
		add_action( 'minimog_ajax_minimog_search', array( $this, 'ajax_search' ) );

		if ( ! is_admin() ) {
			add_action( 'pre_get_posts', array( $this, 'alter_search_loop' ), 1 );
			add_filter( 'pre_get_posts', array( $this, 'search_filter' ) );
			add_filter( 'pre_get_posts', array( $this, 'empty_search_filter' ) );
		}
	}

	public function get_category_query() {
		return '_cat';
	}

	/**
	 * AJAX live search for the search popup, respecting the configured search scope.
	 *
	 * Products (when the scope is "product") are handled by the WooCommerce handler with
	 * its product-specific features; this covers the post / page / all scopes, and renders
	 * mixed product/post results for the "all" scope.
	 *
	 * @see \Minimog\Woo\Ajax_Handlers::search_products()
	 */
	public function ajax_search() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public, read-only search.
		$content_type = Minimog::setting( 'search_page_filter' );
		$search_terms = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$number       = max( 1, intval( Minimog::setting( 'section_popup_search_number_results' ) ) );

		$query_args = array(
			's'                   => $search_terms,
			'posts_per_page'      => $number,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);

		if ( in_array( $content_type, array( 'post', 'page', 'product' ), true ) ) {
			$query_args['post_type'] = $content_type;
		}

		// Narrow by the selected category only for the "post" scope, where the dropdown uses the
		// native "category" taxonomy. In the "all" scope that slug cannot map cleanly to products
		// (they use "product_cat"), so applying it would filter posts but silently not products.
		$cat_query = $this->get_category_query();
		if ( 'post' === $content_type && ! empty( $_GET[ $cat_query ] ) ) {
			$query_args['category_name'] = sanitize_text_field( wp_unslash( $_GET[ $cat_query ] ) );
		}

		// Exclude products hidden from search whenever products can appear in the results,
		// mirroring the search page and the dedicated product search handler.
		if ( in_array( $content_type, array( 'all', 'product' ), true ) && Minimog_Woo::instance()->is_activated() ) {
			$product_visibility_terms = wc_get_product_visibility_term_ids();
			$exclude_terms            = array( $product_visibility_terms['exclude-from-search'] );

			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
				$exclude_terms[] = $product_visibility_terms['outofstock'];
			}

			$query_args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => $exclude_terms,
					'operator' => 'NOT IN',
				),
			);
		}

		$search_query = new WP_Query( $query_args );

		$template = '';

		if ( $search_query->have_posts() ) {
			$woo_active = Minimog_Woo::instance()->is_activated();

			// Bucket results by post type so each type gets its own clearly separated group.
			$buckets = array();
			$order   = array();

			while ( $search_query->have_posts() ) {
				$search_query->the_post();
				$post_type = get_post_type();

				ob_start();
				if ( 'product' === $post_type && $woo_active ) {
					minimog_load_template( 'content-search-product' );
				} else {
					minimog_load_template( 'content-search-rest' );
				}
				$item = ob_get_clean();

				if ( ! isset( $buckets[ $post_type ] ) ) {
					$buckets[ $post_type ] = '';
					$order[]               = $post_type;
				}

				$buckets[ $post_type ] .= $item;
			}

			// Show products first, then posts, pages and any other types below them.
			$preferred_order = array( 'product', 'post', 'page' );
			$sorted_order    = array();
			foreach ( $preferred_order as $preferred_type ) {
				if ( in_array( $preferred_type, $order, true ) ) {
					$sorted_order[] = $preferred_type;
				}
			}
			foreach ( $order as $found_type ) {
				if ( ! in_array( $found_type, $sorted_order, true ) ) {
					$sorted_order[] = $found_type;
				}
			}
			$order = $sorted_order;

			// Only label the groups when more than one post type is present (e.g. the "all" scope).
			$show_group_titles = count( $order ) > 1;

			ob_start();
			foreach ( $order as $post_type ) {
				$post_type_object = get_post_type_object( $post_type );
				$group_title      = $post_type_object ? $post_type_object->labels->name : $post_type;
				$is_product_group = ( 'product' === $post_type && $woo_active );

				$group_class = 'popup-search-group popup-search-group--' . $post_type;
				if ( ! $is_product_group ) {
					$group_class .= ' minimog-blog minimog-blog-caption-style-04';
				}

				echo '<div class="' . esc_attr( $group_class ) . '">';

				if ( $show_group_titles ) {
					echo '<h3 class="popup-search-group-title">' . esc_html( $group_title ) . '</h3>';
				}

				if ( $is_product_group ) {
					wc_get_template( 'custom/before-shop-loop-grid.php' );
					echo $buckets[ $post_type ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from already-escaped loop templates.
					wc_get_template( 'custom/after-shop-loop-grid.php' );
				} else {
					echo '<div class="popup-search-rest-grid">' . $buckets[ $post_type ] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from already-escaped loop templates.
				}

				echo '</div>';
			}
			$template = ob_get_clean();
		}

		wp_reset_postdata();

		$response = array(
			'template' => $template,
			'found'    => $search_query->post_count,
		);

		wp_send_json_success( $response );
		// phpcs:enable
	}

	/**
	 * @param WP_Query $query Query instance.
	 */
	public function alter_search_loop( $query ) {
		if ( $query->is_main_query() && $query->is_search() ) {
			$number_results = Minimog::setting( 'search_page_number_results' );
			$query->set( 'posts_per_page', $number_results );
		}
	}

	/**
	 * @param WP_Query $query Query instance.
	 *
	 * @return WP_Query $query
	 *
	 * Apply filters to the search query.
	 * Determines if we only want to display posts/pages and changes the query accordingly
	 */
	public function search_filter( $query ) {
		if ( $query->is_main_query() && $query->is_search ) {
			$post_type = Minimog::setting( 'search_page_filter' );

			if ( ! empty( $post_type ) && 'all' !== $post_type ) {
				$query->set( 'post_type', $post_type );

				$cat_query = $this->get_category_query();

				if ( ! empty( $_GET[ $cat_query ] ) ) {
					$search_in_cat = sanitize_text_field( $_GET[ $cat_query ] );

					switch ( $post_type ) :
						case 'post':
							$taxonomy_name = 'category';
							break;
						case 'product':
							$taxonomy_name = 'product_cat';
							break;
					endswitch;

					if ( ! empty( $taxonomy_name ) ) {
						$query->set( 'tax_query', array(
							array(
								'taxonomy' => $taxonomy_name,
								'field'    => 'slug',
								'terms'    => array( $search_in_cat ),
							),
						) );
					}
				}
				
				// Ignore hidden products from search page.
				if ( 'product' === $post_type ) {
					$product_visibility_terms  = wc_get_product_visibility_term_ids();
					$product_visibility_not_in = [
						$product_visibility_terms['exclude-from-search'],
					];

					$tax_query = $query->get( 'tax_query' );
					if ( is_array( $tax_query ) ) {
						// Append terms if exist instead of add new tax query.

						$appended = false;
						foreach ( $tax_query as $key => $tax_query_term ) {
							if ( is_array( $tax_query_term ) && ! empty( $tax_query_term['taxonomy'] ) && 'product_visibility' === $tax_query_term['taxonomy'] && 'term_taxonomy_id' === $tax_query_term['field'] && 'NOT IN' === $tax_query_term['operator'] ) {
								$new_terms               = array_merge( $tax_query_term['terms'], $product_visibility_not_in );
								$tax_query_term['terms'] = $new_terms;
								$tax_query[ $key ]       = $tax_query_term;

								$appended = true;
								break;
							}
						}

						if ( false === $appended ) {
							$tax_query[] = array(
								'taxonomy' => 'product_visibility',
								'field'    => 'term_taxonomy_id',
								'terms'    => $product_visibility_not_in,
								'operator' => 'NOT IN',
							);
						}
					} else {
						$tax_query   = array();
						$tax_query[] = array(
							'taxonomy' => 'product_visibility',
							'field'    => 'term_taxonomy_id',
							'terms'    => $product_visibility_not_in,
							'operator' => 'NOT IN',
						);
					}
					$query->set( 'tax_query', $tax_query );
				}
			}
		}

		return $query;
	}

	/**
	 * Make wordpress respect the search template on an empty search
	 *
	 * @param \WP_Query $query
	 *
	 * @return \WP_Query $query
	 */
	public function empty_search_filter( $query ) {
		if ( isset( $_GET['s'] ) && empty( $_GET['s'] ) && $query->is_main_query() ) {
			$query->is_search = true;
			$query->is_home   = false;
		}

		return $query;
	}
}

Minimog_Search::instance()->initialize();
