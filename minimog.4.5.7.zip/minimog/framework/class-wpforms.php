<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Minimog_WPForms' ) ) {
	class Minimog_WPForms {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			if ( ! $this->is_activate() ) {
				return;
			}

			add_action( 'wpforms_wp_footer', [ $this, 'fix_duplicate_assets' ], 9999 );
			// Priority 5 so this lands before WPForms' own init_style_settings(), see update_option().
			add_action( 'init', [ $this, 'update_option' ], 5 );
			add_filter( 'wpforms_frontend_container_class', [ $this, 'update_frontend_container_class' ] );

			// Runs after WPForms enqueues its Elementor preview assets on the default priority.
			add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'drop_orphaned_elementor_themes_script' ], 20 );

			add_filter( 'wpforms_frontend_strings', [ $this, 'fix_override_validate_string' ] );
		}

		public function is_activate() {
			return defined( 'WPFORMS_VERSION' );
		}

		public function fix_duplicate_assets() {
			/**
			 * The plugin had prefixed validate asset
			 * Then dequeue to enqueue standard asset.
			 */
			if ( wp_script_is( 'wpforms-validation' ) ) {
				wp_deregister_script( 'wpforms-validation' );
				wp_dequeue_script( 'wpforms-validation' );

				wp_enqueue_script( 'validate' );
			}
		}

		/**
		 * Drop WPForms' `wpforms-elementor-themes` handle when its dependency is missing.
		 *
		 * WPForms enqueues that script with a hard dependency on `wpforms-elementor-modern`, but
		 * only registers the dependency when its `is_modern_widget()` is true, which requires
		 * `disable-css === 1`. This theme deliberately runs WPForms on "Base styling only"
		 * ( `disable-css = 2`, see update_option() ) so it can style forms itself through the
		 * `.minimog-wpforms` container class, which leaves that dependency permanently
		 * unregistered.
		 *
		 * WordPress already refuses to print a script whose dependencies are missing, so the
		 * script has never loaded. Since WP 6.9.1 it also logs a `_doing_it_wrong()` notice for it
		 * on every Elementor editor preview load. Removing the orphaned handle silences the notice
		 * and changes nothing else.
		 *
		 * Deliberately narrow: the moment WPForms registers the dependency, or stops enqueueing
		 * the handle, this becomes a no-op. Upstream bug, worth reporting to WPForms.
		 */
		public function drop_orphaned_elementor_themes_script() {
			if ( ! wp_script_is( 'wpforms-elementor-themes', 'registered' ) ) {
				return;
			}

			if ( wp_script_is( 'wpforms-elementor-modern', 'registered' ) ) {
				return;
			}

			wp_dequeue_script( 'wpforms-elementor-themes' );
			wp_deregister_script( 'wpforms-elementor-themes' );
		}

		/**
		 * Fix WP Form override some form validate messages.
		 *
		 * @param array $strings
		 *
		 * @return array $string
		 * @see \WPForms_Frontend::get_strings()
		 *
		 */
		public function fix_override_validate_string( $strings ) {
			$validate_messages = Minimog_Login_Register::instance()->get_form_validate_messages()['simple'];

			if ( isset( $strings['val_required'] ) ) {
				$strings['val_required'] = $validate_messages['required'];
			}

			if ( isset( $strings['val_email'] ) ) {
				$strings['val_email'] = $validate_messages['email'];
			}

			if ( isset( $strings['val_number'] ) ) {
				$strings['val_number'] = $validate_messages['number'];
			}

			return $strings;
		}

		/**
		 * Seed a fresh install with the form styling mode the theme is built around.
		 *
		 * The theme styles WPForms itself - see update_frontend_container_class() and the
		 * `.minimog-wpforms` rules in assets/scss/elementor/widgets/_wpforms.scss - which needs
		 * "Base styling only" ( `disable-css = 2` ). WPForms' own default is `1`, "Base and form
		 * theme styling", which loads its full stylesheet over the theme's.
		 *
		 * This has to beat WPForms' `init_style_settings()`. That method is hooked on `init` at
		 * the default priority and unconditionally writes `wpforms_settings` to record its
		 * modern-markup flags - with no `disable-css` key. Once it lands the option exists, so
		 * seeding afterwards ( this ran on `admin_init` until now ) never fired: the
		 * `false === $settings` guard could not be true any more, and every new site quietly fell
		 * back to WPForms' full stylesheet. WPForms merges into whatever is already stored, so
		 * writing first is enough - it keeps the value and adds its own keys alongside.
		 *
		 * Deliberately limited to sites with no `wpforms_settings` at all. An existing install
		 * keeps rendering exactly as it does today, and a merchant's own choice is never
		 * overwritten.
		 */
		public function update_option() {
			if ( false !== get_option( 'wpforms_settings' ) ) {
				return;
			}

			// Written as a literal: assigning an index onto `false` is deprecated as of PHP 8.1.
			update_option( 'wpforms_settings', [ 'disable-css' => 2 ] ); // 2 = Base styling only.
		}

		public function update_frontend_container_class( $classes ) {
			$settings = get_option( 'wpforms_settings' );

			if ( isset( $settings['disable-css'] ) && $settings['disable-css'] == 2 ) {
				$classes[] = 'minimog-wpforms';
			}

			return $classes;
		}

		public static function get_forms() {
			static $forms_list = [];

			$forms_list[0] = esc_html__( 'Select a form', 'minimog' );

			if ( ! function_exists( 'wpforms' ) ) {
				return $forms_list;
			}

			$forms = wpforms()->form->get();

			if ( ! empty( $forms ) ) {
				foreach ( $forms as $form ) {
					$forms_list[ $form->ID ] = mb_strlen( $form->post_title ) > 100 ? mb_substr( $form->post_title, 0, 97 ) . '...' : $form->post_title;
				}
			}

			return $forms_list;
		}
	}

	Minimog_WPForms::instance()->initialize();
}
