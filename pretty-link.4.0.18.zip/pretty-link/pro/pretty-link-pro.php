<?php

/**
 * Pretty Links Pro loader.
 *
 * Not a standalone WP plugin — this file is require'd by Lite's bootstrap
 * when the `pro/` directory is present in the install. The Lite build's
 * distignore strips this file, so its absence in the Lite download is the
 * gate.
 *
 * Pro owns its own PSR-4 autoloader. Lite does NOT map `PrettyLinks\Pro\`
 * in its composer.json so Lite stays blind to Pro's class graph even when
 * somebody calls class_exists('PrettyLinks\Pro\...') on a Lite-only
 * install (the call fails fast instead of trying to include a missing
 * file from Lite's classmap).
 *
 * Registers on `prli_loaded` — Lite doesn't reference Pro's Bootstrap
 * class directly.
 *
 * @package PrettyLinksPro
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

spl_autoload_register(
    static function (string $class): void {
        $prefix = 'PrettyLinks\\Pro\\';
        if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
            return;
        }
        $relative = substr($class, strlen($prefix));
        $file     = __DIR__ . '/src/' . str_replace('\\', '/', $relative) . '.php';
        if (is_file($file)) {
            require_once $file;
        }
    }
);

require_once __DIR__ . '/legacy-shims.php';

add_action(
    'prli_loaded',
    static function ($container): void {
        (new \PrettyLinks\Pro\Bootstrap())->load($container);
    }
);
