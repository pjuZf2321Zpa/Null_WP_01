<?php

/**
 * Legacy v3 Pro API function shims.
 *
 * Global 3.x Pro template tags kept so themes and snippets written against
 * v3 Pro keep working after upgrading to v4. They live in Pro because the
 * shortcodes they render are Pro-only; on Lite they don't exist, as in v3.
 *
 * DEPRECATED as of 4.0.0. Every shim calls _deprecated_function() so
 * WP_DEBUG logs each use.
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('the_social_buttons_bar')) {
    /**
     * V3 Pro template tag: echo the social buttons bar for the current post.
     *
     * Deprecated. Prefer `echo do_shortcode('[social_buttons_bar]')`.
     */
    function the_social_buttons_bar(): void
    {
        _deprecated_function('the_social_buttons_bar', '4.0.0', '[social_buttons_bar] shortcode');
        echo do_shortcode('[social_buttons_bar]');
    }
}

// Hook shim: v3 Pro fired the unified `prli-redirect-header` action (no args)
// in the <head> of every Pro redirect template, Pretty Bar included. v4 Pro
// fires separate per-type actions instead. Re-fire the v3 hook from each so
// code hooked to the unified action keeps working. Registered with 0 accepted
// args to match v3's no-arg signature; the per-type actions pass $link as arg
// 1, which we deliberately ignore. Pretty Bar's head action is
// `prli-pretty-bar-head` (AbstractTemplate::renderHead()).
// Loop-local var (unset below); underscore prefix avoids clashing with anything.
foreach (['prli_cloak_head', 'prli_metarefresh_head', 'prli_javascript_redirect_head', 'prli-pretty-bar-head'] as $_prli_head_action) {
    add_action($_prli_head_action, static function (): void {
        do_action('prli-redirect-header');
    }, 10, 0);
}
unset($_prli_head_action);

if (!function_exists('the_prettylink')) {
    /**
     * V3 Pro template tag: echo the pretty link for the current post.
     *
     * Deprecated. Prefer `echo do_shortcode('[post-pretty-link]')` or
     * reading the `_pretty-link` post meta directly via the v4 REST API.
     */
    function the_prettylink(): void
    {
        _deprecated_function('the_prettylink', '4.0.0', '[post-pretty-link] shortcode');
        echo do_shortcode('[post-pretty-link]');
    }
}

// Shortcode shim: v3 Pro's `[tweetbadge]` rendered a Twitter badge. The feature
// relied on X API v1.1 endpoints that were shut down in 2023, so it can't be
// restored. The tag is still registered so existing post content containing
// `[tweetbadge]` renders empty instead of showing literal bracket text.
add_shortcode('tweetbadge', static fn (): string => '');
