<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Providers;

use PrettyLinks\GroundLevel\Container\Container;
use PrettyLinks\GroundLevel\Container\ServiceProvider;
use PrettyLinks\Pro\PublicLinks\Service as PublicLinksService;
use PrettyLinks\Pro\SocialButtons\Service as SocialButtonsService;
use PrettyLinks\Repositories\Links;

/**
 * Visitor-facing link surfaces: the public (anonymous) link-creation service
 * and the social-share buttons service. Both read links through the core
 * Links repository.
 */
class PublicLinksServiceProvider extends ServiceProvider
{
    /**
     * Service definitions registered with the container.
     *
     * @return array<int, array{id: string, lifecycle: string, closure: \Closure|null, eager: bool}>
     */
    public function services(): array
    {
        return [
            $this->service(
                SocialButtonsService::class,
                self::SINGLETON,
                static function (Container $c): SocialButtonsService {
                    return new SocialButtonsService($c->get(Links::class));
                }
            ),

            $this->service(
                PublicLinksService::class,
                self::SINGLETON,
                static function (Container $c): PublicLinksService {
                    return new PublicLinksService($c->get(Links::class));
                }
            ),
        ];
    }
}
