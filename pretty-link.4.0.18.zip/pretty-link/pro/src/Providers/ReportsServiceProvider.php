<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Providers;

use PrettyLinks\GroundLevel\Container\Container;
use PrettyLinks\GroundLevel\Container\ServiceProvider;
use PrettyLinks\Pro\Reports\Conversions as ConversionsReport;
use PrettyLinks\Pro\Reports\CustomReports as CustomReportsService;
use PrettyLinks\Pro\Reports\SplitTest as SplitTestReport;
use PrettyLinks\Pro\Repositories\Reports as ReportsRepo;
use PrettyLinks\Repositories\LinkMetas;
use PrettyLinks\Repositories\Links;

/**
 * Pro analytics primitives: conversion attribution, the split-test report,
 * the custom (multi-link) reports service, and the custom-report
 * definitions repository. All are stateless helpers consumed by the Pro
 * REST report controllers.
 */
class ReportsServiceProvider extends ServiceProvider
{
    /**
     * Service definitions registered with the container.
     *
     * @return array<int, array{id: string, lifecycle: string, closure: \Closure|null, eager: bool}>
     */
    public function services(): array
    {
        return [
            // Conversion attribution primitive — Pro-only query helper.
            // Stateless; reads `prli_clicks` (+ `prli_clicks_rotations` for the
            // split-test variant) using $wpdb.
            $this->service(
                ConversionsReport::class,
                self::SINGLETON,
                static function (): ConversionsReport {
                    return new ConversionsReport();
                }
            ),

            // Split-test analytics primitive — Pro-only query helper that backs
            // the per-link Split Test Report. Stateless; reads `prli_clicks`
            // JOIN `prli_clicks_rotations` and the link's rotation/meta config.
            $this->service(
                SplitTestReport::class,
                self::SINGLETON,
                static function (Container $c): SplitTestReport {
                    return new SplitTestReport(
                        $c->get(Links::class),
                        $c->get(LinkMetas::class)
                    );
                }
            ),

            // Custom Reports analytics primitive — Pro-only query helper that
            // backs the multi-link reports surface. Stateless; reads
            // `prli_clicks` + `prli_links` using $wpdb.
            $this->service(
                CustomReportsService::class,
                self::SINGLETON,
                static function (): CustomReportsService {
                    return new CustomReportsService();
                }
            ),

            // Custom report definitions (`prli_reports` + `prli_report_links`).
            // Stateless; reads and writes through $wpdb.
            $this->service(
                ReportsRepo::class,
                self::SINGLETON,
                static function (): ReportsRepo {
                    return new ReportsRepo();
                }
            ),
        ];
    }
}
