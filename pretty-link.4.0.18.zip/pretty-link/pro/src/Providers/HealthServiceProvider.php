<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Providers;

use PrettyLinks\GroundLevel\Container\Container;
use PrettyLinks\GroundLevel\Container\ServiceProvider;
use PrettyLinks\Pro\Health\EmailDigest as HealthEmailDigest;
use PrettyLinks\Pro\Health\HealthChecker;
use PrettyLinks\Pro\Health\Scheduler as HealthScheduler;
use PrettyLinks\Pro\Options\Store as OptionsStore;

/**
 * Link-health subsystem: the checker that probes link targets, the cron
 * scheduler that drives periodic checks, and the email digest that reports
 * results.
 */
class HealthServiceProvider extends ServiceProvider
{
    /**
     * Service definitions registered with the container.
     *
     * @return array<int, array{id: string, lifecycle: string, closure: \Closure|null, eager: bool}>
     */
    public function services(): array
    {
        return [
            $this->service(
                HealthChecker::class,
                self::SINGLETON,
                static function (): HealthChecker {
                    return new HealthChecker();
                }
            ),

            $this->service(
                HealthScheduler::class,
                self::SINGLETON,
                static function (Container $c): HealthScheduler {
                    return new HealthScheduler($c->get(OptionsStore::class));
                }
            ),

            $this->service(
                HealthEmailDigest::class,
                self::SINGLETON,
                static function (Container $c): HealthEmailDigest {
                    return new HealthEmailDigest($c->get(OptionsStore::class));
                }
            ),
        ];
    }
}
