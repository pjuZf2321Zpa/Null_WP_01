<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Providers;

use PrettyLinks\GroundLevel\Container\Container;
use PrettyLinks\GroundLevel\Container\ServiceProvider;
use PrettyLinks\Pro\AutoCreate\AutoCreator;
use PrettyLinks\Pro\Licensing\UpdateChecker;
use PrettyLinks\Pro\Options\Store as OptionsStore;
use PrettyLinks\Pro\Redirect\MuPluginInstaller;
use PrettyLinks\Pro\Repositories\Categories as CategoriesRepo;
use PrettyLinks\Pro\Repositories\Tags as TagsRepo;
use PrettyLinks\Repositories\LinkMetas;
use PrettyLinks\Repositories\Links;

/**
 * Cross-cutting Pro infrastructure: options store, the plugin updater, the
 * mu-plugin installer, the core repositories shared across feature areas, and
 * the auto-creator. Everything else depends on one of these, so this provider
 * is registered first.
 */
class CoreServiceProvider extends ServiceProvider
{
    /**
     * Service definitions registered with the container.
     *
     * @return array<int, array{id: string, lifecycle: string, closure: \Closure|null, eager: bool}>
     */
    public function services(): array
    {
        return [
            $this->service(
                OptionsStore::class,
                self::SINGLETON,
                static function (): OptionsStore {
                    return new OptionsStore();
                }
            ),

            // Main plugin updater. Lives on the Pro side because WP.org prohibits
            // plugin updaters in hosted plugins — Lite installs without Pro rely
            // on the normal WordPress.org update mechanism.
            $this->service(
                UpdateChecker::class,
                self::SINGLETON,
                static function (): UpdateChecker {
                    return new UpdateChecker();
                }
            ),

            $this->service(
                MuPluginInstaller::class,
                self::SINGLETON,
                static function (): MuPluginInstaller {
                    // PRLI_PATH/PRLI_URL, not the container's BASE_PATH/BASE_URL:
                    // this branch standardised on the constants (pro/src/Admin/
                    // Assets.php already moved), and they are the same
                    // plugin_dir_path()/plugin_dir_url() values without the
                    // container round-trip.
                    return new MuPluginInstaller(PRLI_PATH, PRLI_URL);
                }
            ),

            $this->service(
                Links::class,
                self::SINGLETON,
                static function (): Links {
                    return new Links();
                }
            ),

            $this->service(
                LinkMetas::class,
                self::SINGLETON,
                static function (): LinkMetas {
                    return new LinkMetas();
                }
            ),

            $this->service(
                CategoriesRepo::class,
                self::SINGLETON,
                static function (): CategoriesRepo {
                    return new CategoriesRepo();
                }
            ),

            $this->service(
                TagsRepo::class,
                self::SINGLETON,
                static function (): TagsRepo {
                    return new TagsRepo();
                }
            ),

            $this->service(
                AutoCreator::class,
                self::SINGLETON,
                static function (Container $c): AutoCreator {
                    return new AutoCreator(
                        $c->get(OptionsStore::class),
                        $c->get(Links::class)
                    );
                }
            ),
        ];
    }
}
