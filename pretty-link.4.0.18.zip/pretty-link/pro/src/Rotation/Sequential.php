<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Rotation;

use PrettyLinks\Options\Store as LiteOptionsStore;
use PrettyLinks\Redirect\ClickWriter;

/**
 * Round-robin rotation. Tracks position via an atomic MySQL INSERT … ON DUPLICATE KEY
 * UPDATE in wp_options so concurrent requests cannot read the same counter value.
 *
 * The counter only moves for hits that survive the click filters. This runs
 * inside `prli_target_url`, well before `ClickWriter` gets to drop bots,
 * excluded IPs and repeat visits inside the dedup window, so advancing
 * unconditionally let crawlers eat round-robin slots and skew the split.
 */
class Sequential implements RotationStrategy
{
    /**
     * Whether click tracking is on for the link being rotated.
     *
     * A link with tracking off has no click filters to fail, so every hit is a
     * real hit as far as the round-robin is concerned. Without this the counter
     * would freeze at the first slot for all bot / excluded-IP traffic on such a
     * link, which is worse than the bug being fixed.
     *
     * @var boolean
     */
    private bool $tracked;

    /**
     * Build the strategy for one link.
     *
     * @param boolean $tracked Whether click tracking is on for this link, after
     *                         the `prli_track_link` filter.
     */
    public function __construct(bool $tracked = true)
    {
        $this->tracked = $tracked;
    }

    /**
     * Picks the next rotation row round-robin, advancing an atomic counter.
     *
     * @param  integer                          $linkId    Link ID being rotated.
     * @param  array<int, array<string, mixed>> $rotations Rows from prli_link_rotations.
     * @return array<string, mixed>|null
     */
    public function pick(int $linkId, array $rotations): ?array
    {
        global $wpdb;

        $count = count($rotations);
        if ($count === 0) {
            return null;
        }

        $optKey = 'prli_rot_pos_' . $linkId;

        // Hits the click filters will discard get served the URL at the current
        // position but must not move it on, or a crawler pass silently
        // reorders the rotation for real visitors. With tracking off there are no
        // filters to fail, so every hit advances.
        $advance = !$this->tracked
            || !(new ClickWriter($wpdb, new LiteOptionsStore()))->isRequestFiltered($linkId);

        if ($advance) {
            // Atomic increment: MySQL evaluates option_value + 1 before any other
            // connection can read the same value, so each request advances the
            // counter without a read-modify-write race.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- INSERT … ON DUPLICATE KEY UPDATE has no get_option()/update_option() equivalent; expressing this counter through the options API reintroduces the read-modify-write race, and the object cache must not answer for it.
            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$wpdb->options} (option_name, option_value, autoload)
                     VALUES (%s, 1, 'no')
                     ON DUPLICATE KEY UPDATE option_value = option_value + 1",
                    $optKey
                )
            );
        }

        // Read straight from the row, NOT get_option(): the raw query above
        // never primed the options cache, so on a persistent object cache
        // get_option() would return a stale (or absent) value and hand every
        // visitor the same position.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Deliberate read-through of the row just written by the raw INSERT above; get_option() would serve a stale value from an object cache the raw write never primed.
        $pos = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
                $optKey
            )
        );
        // A filtered hit reads the counter without having claimed a slot, so it
        // is served whatever the last real visitor got. That is the useful
        // answer for the case that matters most here — a dedup-window retry gets
        // the same URL as the click it is repeating.
        $idx = $pos > 0 ? ($pos - 1) % $count : 0;
        $row = array_values($rotations)[$idx] ?? null;

        return is_array($row) ? $row : null;
    }
}
