<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Rotation;

/**
 * Strategy interface for link rotation modes.
 */
interface RotationStrategy
{
    /**
     * Pick the next rotation row for the given link.
     *
     * @param  integer                          $linkId    Link ID being rotated.
     * @param  array<int, array<string, mixed>> $rotations Rows from prli_link_rotations.
     * @return array<string, mixed>|null The chosen rotation row, or null on no-op.
     */
    public function pick(int $linkId, array $rotations): ?array;
}
