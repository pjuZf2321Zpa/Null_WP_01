<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Licensing;

defined('ABSPATH') || exit;

use PrettyLinks\Licensing\ProState;

/**
 * Host-plugin update glue for the new licenses server.
 *
 * Update checks and package downloads for the main plugin are owned by
 * ground-level-mothership's UpdateService, armed by the `Update URI: pretty-link`
 * header (which routes WP's check to the `update_plugins_pretty-link` filter).
 * This class only adds the Pretty Links-specific bits GL doesn't:
 *
 *   - enriches the "View details" modal via the `pretty-link_plugin_information`
 *     filter GL fires (author, homepage, WP compatibility),
 *   - clears WP's update caches on edition change so the new edition's package
 *     is re-resolved on the next check, and
 *   - refuses any wp.org-supplied package for our slug on a Pro install, so a
 *     Lite ZIP can never overwrite Pro (#729). See rejectForeignPackage().
 *
 * It lives on the Pro side because WP.org prohibits self-hosted updaters in
 * hosted plugins; Lite (with the `Update URI` header stripped at build) updates
 * through WordPress.org as usual.
 */
class UpdateChecker
{
    /**
     * The host plugin's `plugin_basename()`, as it appears in the
     * `update_plugins` transient. Pro shares this file with the wp.org Lite
     * plugin, which is the whole reason {@see self::rejectForeignPackage()}
     * has to exist.
     *
     * @var string
     */
    public const PLUGIN_SLUG = 'pretty-link/pretty-link.php';

    /**
     * Register the WP hooks.
     */
    public function register(): void
    {
        add_filter('pretty-link_plugin_information', [$this, 'enrichPluginInformation'], 10, 3);
        add_action('prli_plugin_edition_changed', [$this, 'clearUpdateTransients']);
        // GL's onLicenseRevoked doesn't touch WP's plugin-update cache, and on a
        // Pro build edition() can't detect the revoke (it falls back to
        // PRLI_EDITION once the activation transient is deleted), so clear the
        // cache straight off the revoke actions — otherwise a lapsed site keeps
        // advertising the Pro update until WP's next twice-daily check.
        add_action('prli_license_expired', [$this, 'clearUpdateTransients']);
        add_action('prli_license_invalidated', [$this, 'clearUpdateTransients']);

        // Runs last so it sees whatever GL's `update_plugins_pretty-link`
        // filter and core's wp.org pass have each put in the transient.
        add_filter('pre_set_site_transient_update_plugins', [$this, 'rejectForeignPackage'], 20);
    }

    /**
     * Enrich the host plugin's "View details" modal. ground-level-mothership's
     * UpdateService builds the base object from the licenses API (name, version,
     * last_updated, download_link, description) then runs this filter so the
     * plugin can add details the API doesn't carry.
     *
     * @param  object      $info    The plugin information object GL assembled.
     * @param  object|null $product Product data from the licenses API. Unused.
     * @param  object|null $version Version data from the licenses API. Unused.
     * @return object
     */
    public function enrichPluginInformation($info, $product = null, $version = null)
    {
        global $wp_version;

        if (!is_object($info)) {
            return $info;
        }

        $info->slug     = 'pretty-link';
        $info->author   = '<a href="https://prettylinks.com">Pretty Links</a>';
        $info->homepage = 'https://prettylinks.com';
        // Pin compatibility to the running WP version so the modal never shows
        // a scary "untested with your version" banner for a first-party plugin.
        $info->requires = $wp_version;
        $info->tested   = $wp_version;

        return $info;
    }

    /**
     * Drops any update row for the host plugin that WordPress.org supplied.
     *
     * Pretty Links Pro installs into the same `pretty-link/pretty-link.php`
     * file as the free wp.org plugin. Whenever core sees a newer version on
     * wp.org for that slug it writes the *Lite* package into the transient
     * itself — and once `$updates->response[$file]` is set, core `continue`s
     * past the `update_plugins_pretty-link` filter entirely, so GL never gets
     * to correct it. Running the update then overwrites Pro with Lite and
     * takes `pro/` with it (#729).
     *
     * The `Update URI` header currently keeps wp.org quiet for this slug, so
     * in practice the row should never appear on a Pro install. That is a
     * remote server's behaviour, not an invariant this plugin controls, which
     * is exactly why the guard is worth keeping: if wp.org ever answers for
     * the slug again, the wrong package is silently destructive. develop had
     * this guard; the mothership migration dropped it.
     *
     * THE GUARANTEE, stated plainly, because it is narrower than develop's and
     * that is deliberate. develop was fail-closed: it fetched the licensed
     * package itself, so "no licensed package" was a fact it knew, and it
     * unset the row on any such failure — "no unlicensed package of any origin
     * can overwrite Pro". This one is host-keyed: "no wordpress.org-hosted
     * package can overwrite Pro". It removes a row only when the package host
     * is wordpress.org, and leaves alone a licensed package, an empty package
     * (which cannot install anything anyway, and which the edition-mismatch
     * notice relies on having a row to attach to), and every Lite install.
     *
     * Host-keyed rather than fail-closed because GL now owns the update check
     * and this filter no longer knows what a licensed package *should* be. A
     * fail-closed rule would have to encode that, and the only available
     * definition is GL's download-host allowlist — which is itself fail-closed
     * with no filter registered anywhere, so the day the licensing server
     * serves a package from a CDN not on that list, Pro updates would stop
     * silently and look identical to an expired licence. The wp.org ZIP is
     * #729's actual payload and the only one that is destructive, so that is
     * what this refuses.
     *
     * If GL ever exposes "this row came from us", tighten this to fail-closed.
     *
     * @param  mixed $transient The `update_plugins` site transient.
     * @return mixed
     */
    public function rejectForeignPackage($transient)
    {
        if (!is_object($transient) || !isset($transient->response) || !is_array($transient->response)) {
            return $transient;
        }

        if (!isset($transient->response[self::PLUGIN_SLUG])) {
            return $transient;
        }

        // On Lite, wp.org IS the correct source. Only Pro must refuse it.
        if (!ProState::isProInstalled()) {
            return $transient;
        }

        $row     = $transient->response[self::PLUGIN_SLUG];
        $package = is_object($row) ? (string) ($row->package ?? '') : '';

        if ($package === '' || !self::isWordPressOrgPackage($package)) {
            return $transient;
        }

        unset($transient->response[self::PLUGIN_SLUG]);

        return $transient;
    }

    /**
     * Whether a package URL is served by WordPress.org.
     *
     * Matches the host exactly or as a subdomain, so `downloads.wordpress.org`
     * and `wordpress.org` both count while a lookalike such as
     * `wordpress.org.example.com` does not.
     *
     * @param  string $package The package URL from an update row.
     * @return boolean
     */
    private static function isWordPressOrgPackage(string $package): bool
    {
        $host = strtolower((string) wp_parse_url($package, PHP_URL_HOST));

        if ($host === '') {
            return false;
        }

        return $host === 'wordpress.org' || substr($host, -14) === '.wordpress.org';
    }

    /**
     * Clear WP's plugin-update cache when the active edition changes or the
     * license is revoked, so the correct package (or none) is re-resolved by
     * ground-level-mothership on the next check rather than waiting for the
     * cache to expire. Hooked to actions that may pass an argument; ignored.
     */
    public function clearUpdateTransients(): void
    {
        delete_site_transient('update_plugins');
    }
}
