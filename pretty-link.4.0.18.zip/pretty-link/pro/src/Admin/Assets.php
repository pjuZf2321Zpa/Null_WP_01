<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Admin;

use PrettyLinks\Admin\Assets as LiteAssets;
use PrettyLinks\Admin\Page as LitePage;
use PrettyLinks\Admin\Pages\AddNew as LiteAddNewPage;
use PrettyLinks\Admin\Pages\Clicks as LiteClicksPage;
use PrettyLinks\Admin\Pages\Links as LiteLinksPage;
use PrettyLinks\Admin\Pages\Options as LiteOptionsPage;
use PrettyLinks\Admin\Pages\PayLinks as LitePayLinksPage;
use PrettyLinks\Pro\Admin\Pages\Categories;
use PrettyLinks\Pro\Admin\Pages\CustomReports;
use PrettyLinks\Pro\Admin\Pages\SplitTestReport;
use PrettyLinks\Pro\Admin\Pages\Tags;

/**
 * Pretty Links Pro admin asset enqueue.
 *
 * Pro bundles live in `pro/assets/js/build/<name>.{js,asset.php}` and
 * `pro/assets/css/build/<name>.css`. They mount into placeholder divs that
 * the Lite page renders unconditionally, so the bundle can no-op cleanly
 * if the target element is missing (e.g. Pro deactivated mid-session).
 *
 * Each Pro bundle reads `window.prliAdmin` directly. For pages that ALSO
 * have a Lite bundle (e.g. Click History) the Lite enqueue layer already
 * localizes `prliAdmin`, so we skip it. For Pro-only pages (e.g. Split
 * Test Reports) there is no Lite bundle on the page — the
 * `PRO_ONLY_PAGES` set below picks those up so we localize `prliAdmin`
 * ourselves via `LiteAssets::bootstrapData()` (the public bootstrap
 * builder, identical shape).
 *
 * @var array<string, string>
 */
class Assets
{
    /**
     * Admin page slug → Pro bundle handle(s) map. Mirrors the Lite map in
     * `PrettyLinks\Admin\Assets::BUNDLES` but only for pages that have a
     * Pro extension. Keyed by slug because hook suffixes embed the
     * translated menu title (see `LitePage::slugFromHook()`). Each bundle is
     * enqueued IN ADDITION to the Lite bundle for the same page. Values may
     * be a single handle string or an array of handles for pages that need
     * multiple Pro bundles.
     *
     * @var array<string, string|list<string>>
     */
    private const BUNDLES = [
        LiteClicksPage::SLUG     => 'clicks-pro-extras',
        // SplitTestReport registers with an EMPTY parent (it's hidden from
        // the menu, reached via the Links row action).
        SplitTestReport::SLUG    => 'split-test-report',
        CustomReports::SLUG      => 'custom-reports',
        // Pro-only primary bundles — the page registers pro-side and has
        // no Lite counterpart. Lives at pro/assets/js/build/<name>.js.
        Categories::SLUG         => 'categories',
        Tags::SLUG               => 'tags',
        // Lite renders the Links list / Pay Links list via the same
        // `LinksApp` component. The Pro `links-pro-extras` bundle hydrates
        // the row-action slot (Split Test Report anchor) for
        // split-test-enabled rows on each of those pages.
        LiteLinksPage::SLUG      => 'links-pro-extras',
        LitePayLinksPage::SLUG   => 'links-pro-extras',
        // Lite renders the link add / edit form on the same Add New hook
        // (an `id` query param flips the form into edit mode). The Pro
        // `link-form-pro-extras` bundle mounts the split-test config panel
        // into the slot inside the form's Pro tab.
        LiteAddNewPage::SLUG     => 'link-form-pro-extras',
        // Options page gets its Pro sections (Public / Pretty Bar /
        // Replacements / Auto-Create / QR / Health / Social) plus the
        // URL-formatting Pro field group from `options-pro-sections`, and
        // the Bookmarklet / Duplicate / MU-dispatch tool cards from
        // `tools-pro-extras` (the Tools section now lives under Options).
        LiteOptionsPage::SLUG    => [
            'options-pro-sections',
            'tools-pro-extras',
        ],
    ];

    /**
     * Slugs of Pro-only pages (no Lite bundle on the same page). For
     * these we must localize `prliAdmin` ourselves because
     * `PrettyLinks\Admin\Assets::enqueue()` short-circuits with no
     * bundle to attach the localization to.
     *
     * @var array<int, string>
     */
    private const PRO_ONLY_PAGES = [
        SplitTestReport::SLUG,
        CustomReports::SLUG,
        Categories::SLUG,
        Tags::SLUG,
    ];

    /**
     * Bundles for a hook, accounting for the Lite "links list first" setting.
     *
     * That setting (#820) moves which screen renders where: the parent slug
     * shows the links list, the Dashboard moves to its own hidden slug, and
     * the links list keeps a hidden slug of its own so deep links survive.
     * Only the parent slug needs special handling: the hidden Dashboard and
     * Links slugs are plain BUNDLES entries. Without it the split-test row
     * action silently stops rendering on the links list.
     *
     * @param  string $hookSuffix The current admin page hook suffix.
     * @return array<int, string>
     */
    private static function bundlesFor(string $hookSuffix): array
    {
        $slug = LitePage::slugFromHook($hookSuffix);
        if ($slug === LitePage::SLUG) {
            return LitePage::linksListIsFirst() ? ['links-pro-extras'] : [];
        }
        return isset(self::BUNDLES[$slug]) ? (array) self::BUNDLES[$slug] : [];
    }

    /**
     * Enqueue the Pro bundle (if any) registered for the current admin
     * hook. Reuses the bootstrap data localized for the Lite bundle on
     * the same page — no Pro-specific global is added.
     *
     * @param string $hookSuffix The current admin page hook suffix.
     *
     * @return void
     */
    public static function enqueue(string $hookSuffix): void
    {
        $bundles = self::bundlesFor($hookSuffix);
        if ($bundles === []) {
            return;
        }
        $basePath = PRLI_PATH;
        $baseUrl  = PRLI_URL;

        foreach ($bundles as $bundle) {
            self::enqueueBundle((string) $bundle, $hookSuffix, $basePath, $baseUrl);
        }
    }

    /**
     * Register and enqueue a single Pro bundle and its dependencies.
     *
     * @param string $bundle     The bundle handle/slug to enqueue.
     * @param string $hookSuffix The current admin page hook suffix.
     * @param string $basePath   Absolute filesystem path to the plugin base.
     * @param string $baseUrl    Public URL to the plugin base.
     *
     * @return void
     */
    private static function enqueueBundle(string $bundle, string $hookSuffix, string $basePath, string $baseUrl): void
    {
        // Pro bundles consume `@shared` via the `prli-shared` external
        // exactly like Lite — register the shared library first so it
        // loads before the Pro bundle and `prliAdmin` lands on the right
        // <script> tag (see LiteAssets::enqueueSharedLibrary()).
        LiteAssets::enqueueSharedLibrary($basePath, $baseUrl);

        $jsRel    = "pro/assets/js/build/{$bundle}.js";
        $cssRel   = "pro/assets/css/build/{$bundle}.css";
        $assetRel = "pro/assets/js/build/{$bundle}.asset.php";
        $assetAbs = $basePath . $assetRel;

        $asset = is_file($assetAbs) ? require $assetAbs : null;
        $deps  = is_array($asset) && isset($asset['dependencies']) && is_array($asset['dependencies'])
            ? $asset['dependencies']
            : ['wp-element', 'wp-components', 'wp-i18n', 'wp-api-fetch', 'wp-data'];
        if (!in_array(LiteAssets::SHARED_HANDLE, $deps, true)) {
            $deps[] = LiteAssets::SHARED_HANDLE;
        }
        $version = is_array($asset) && isset($asset['version']) ? (string) $asset['version'] : \PrettyLinks\Bootstrap::version();

        $handle = 'prli-admin-pro-' . $bundle;

        if (is_file($basePath . $jsRel)) {
            wp_enqueue_script(
                $handle,
                $baseUrl . $jsRel,
                $deps,
                $version,
                true
            );
            wp_set_script_translations($handle, 'pretty-link-pro');
        }

        if (is_file($basePath . $cssRel)) {
            wp_enqueue_style(
                $handle,
                $baseUrl . $cssRel,
                ['wp-components', LiteAssets::SHARED_HANDLE],
                $version
            );
        }

        if (in_array($bundle, ['clicks-pro-extras', 'link-form-pro-extras'], true)) {
            LiteAssets::enqueueFlagIcons($basePath, $baseUrl);
        }

        // Pro-only page: no Lite bundle ran on this hook, so `prliAdmin`
        // hasn't been localized onto the shared handle yet. Attach the
        // standard bootstrap shape so the shared-bundle's bootstrap.js
        // reader sees the data when it evaluates.
        if (in_array(LitePage::slugFromHook($hookSuffix), self::PRO_ONLY_PAGES, true) && is_file($basePath . $jsRel)) {
            wp_localize_script(
                LiteAssets::SHARED_HANDLE,
                'prliAdmin',
                LiteAssets::bootstrapData($bundle)
            );
        }
    }
}
