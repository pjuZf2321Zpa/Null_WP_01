<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Admin\Pages;

use PrettyLinks\Admin\Page;

/**
 * Pretty Links → Tags admin page. Pro-only. Data table lives in Lite.
 */
class Tags
{
    public const SLUG = 'pretty-link-tags';

    /**
     * Register the Tags submenu page.
     *
     * @return string The page hook suffix.
     */
    public static function register(): string
    {
        return (string) add_submenu_page(
            Page::SLUG,
            esc_html__('Tags', 'pretty-link-pro'),
            esc_html__('Tags', 'pretty-link-pro'),
            Page::capability(),
            self::SLUG,
            [self::class, 'render'],
            50
        );
    }

    /**
     * Render the Tags admin page container.
     *
     * @return void
     */
    public static function render(): void
    {
        echo '<div class="wrap">'
           . '<div id="prli-notices-app"></div>'
           . '<div id="prli-admin-root" data-page="tags"></div>'
           . '</div>';
    }
}
