<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Admin\Pages;

use PrettyLinks\Admin\Page;

/**
 * Pretty Links → Categories admin page. Pro-only. Data tables live in
 * Lite (populated by the migrator) so category assignments survive a
 * Pro deactivation.
 */
class Categories
{
    public const SLUG = 'pretty-link-categories';

    /**
     * Register the Categories submenu page.
     *
     * @return string The page hook suffix.
     */
    public static function register(): string
    {
        return (string) add_submenu_page(
            Page::SLUG,
            esc_html__('Categories', 'pretty-link-pro'),
            esc_html__('Categories', 'pretty-link-pro'),
            Page::capability(),
            self::SLUG,
            [self::class, 'render'],
            45
        );
    }

    /**
     * Render the Categories admin page container.
     *
     * @return void
     */
    public static function render(): void
    {
        echo '<div class="wrap">'
           . '<div id="prli-notices-app"></div>'
           . '<div id="prli-admin-root" data-page="categories"></div>'
           . '</div>';
    }
}
