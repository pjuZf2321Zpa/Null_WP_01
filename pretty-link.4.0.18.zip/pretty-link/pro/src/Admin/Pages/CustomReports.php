<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Admin\Pages;

use PrettyLinks\Admin\Page;

/**
 * Pretty Links → Custom Reports admin page (Pro).
 *
 * Single React app with internal view routing — list / new / edit / display.
 * Mirrors v3's `?page=plp-reports` surface: named multi-link reports with
 * optional goal link, showing per-source clicks / uniques / conversions.
 *
 * Visible as a Pro submenu under the Pretty Links parent. Unlike
 * `SplitTestReport` this one is a top-level Pro feature (user-visible
 * even without a link pre-selected), so we don't bury it behind a
 * per-link entry point.
 *
 * Stays registered in `count` (Simple) tracking mode so the page doesn't
 * just vanish (#926). Custom Reports need per-click rows (VUIDs for
 * uniques, timestamps for conversions), so in that mode the React app
 * shows a notice pointing at the Tracking mode setting instead.
 */
class CustomReports
{
    public const SLUG = 'pretty-link-custom-reports';

    /**
     * Register the submenu.
     *
     * @return string The page hook suffix.
     */
    public static function register(): string
    {
        return (string) add_submenu_page(
            Page::SLUG,
            esc_html__('Custom Reports', 'pretty-link-pro'),
            esc_html__('Custom Reports', 'pretty-link-pro'),
            Page::capability(),
            self::SLUG,
            [self::class, 'render'],
            55
        );
    }

    /**
     * Render the Custom Reports admin page container.
     *
     * @return void
     */
    public static function render(): void
    {
        echo '<div class="wrap">'
           . '<div id="prli-notices-app"></div>'
           . '<div id="prli-admin-root" data-page="custom-reports"></div>'
           . '</div>';
    }
}
