<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Admin\Pages;

defined('ABSPATH') || exit;

use PrettyLinks\Admin\Page;
use PrettyLinks\Repositories\Links;

/**
 * Pretty Links → Split Test Report admin page (Pro).
 *
 * Per-link split-test report (variants table, time-series chart,
 * conversion stats) rendered at `?page=pretty-link-split-test&link_id=N`.
 *
 * Hidden from the admin menu — the canonical drill-in path is the
 * "Split Test Report" row action on the Lite Links list (rendered by
 * `pro/src-js/links-pro-extras/index.js` for split-test-enabled rows).
 * The page is registered with `null` as the parent slug so it stays
 * URL-reachable for that row action without appearing in any menu.
 *
 * Hidden entirely when tracking is in `count` mode — split-test reporting
 * needs per-click rows (variant URL is recorded in `prli_clicks_rotations`
 * keyed off `prli_clicks.id`), so the page would mislead in count mode.
 */
class SplitTestReport
{
    public const SLUG = 'pretty-link-split-test';

    /**
     * Register the page. Passes `null` as the parent slug so WordPress
     * registers the page handler + URL routing but doesn't add a menu
     * entry. Returns the hook suffix or `null` when the page is hidden
     * in `count` tracking mode.
     */
    public static function register(): ?string
    {
        if (self::isHidden()) {
            return null;
        }

        $hook = (string) add_submenu_page(
            '',
            esc_html__('Split Test Report', 'pretty-link-pro'),
            '',
            Page::capability(),
            self::SLUG,
            [self::class, 'render']
        );
        // '' parent keeps the page out of the visible menu while keeping it URL-reachable.
        // WP's get_admin_page_title() only searches $menu when parent is empty, so it never
        // finds this page's title — leaving $title null and triggering a PHP deprecation in
        // admin-header.php. Pre-set $title on load-* before admin-header.php runs instead.
        add_action('load-' . $hook, static function (): void {
            // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Deliberate pre-set of the admin page title for a hidden ('' parent) page so admin-header.php does not hit a PHP deprecation.
            $GLOBALS['title'] = 'Split Test Report';
        });
        return $hook;
    }

    /**
     * Render the Split Test Report admin page container.
     *
     * @return void
     */
    public static function render(): void
    {
        echo '<div class="wrap">'
           . '<div id="prli-notices-app"></div>'
           . '<div id="prli-admin-root" data-page="split-test-report"></div>'
           . '</div>';
    }

    /**
     * Whether the page is hidden because tracking is in `count` mode.
     *
     * @return boolean True when tracking mode is `count`.
     */
    private static function isHidden(): bool
    {
        return Links::isCountMode();
    }
}
