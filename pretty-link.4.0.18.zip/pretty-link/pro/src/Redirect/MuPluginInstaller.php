<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Redirect;

use PrettyLinks\Pro\Options\Store as ProOptionsStore;
use PrettyLinks\Redirect\Engine;

/**
 * Optional MU-plugin that dispatches pretty-link redirects earlier in the
 * WordPress lifecycle (before `init`), bypassing the bulk of plugin and theme
 * loading for the hot path.
 *
 * Drops a file into wp-content/mu-plugins/ when enabled. Idempotent.
 *
 * Pro-only: this is the "redirect turbo mode" that ships with Pretty Links
 * Pro. Lite has no knowledge of it — the toggle, endpoint, and self-heal
 * hook are all registered from Pro's Bootstrap.
 */
class MuPluginInstaller
{
    private const FILENAME = '00000001-pretty-link-dispatch.php';

    /**
     * Revision stamped into the drop-in's `Version:` header, for humans reading
     * the file. NOT what drives refreshing — see fingerprint().
     *
     * @var string
     */
    public const STUB_VERSION = '4.0.10';

    /**
     * Option holding the fingerprint of the currently-installed drop-in.
     *
     * @var string
     */
    private const VERSION_OPTION = 'prli_mu_dispatch_stub_version';

    /**
     * Option holding the cheap template identity (mtime + size) that produced the
     * currently-installed drop-in. Separate from the fingerprint so the
     * nothing-changed path costs two stat() calls instead of a file read.
     *
     * @var string
     */
    private const TEMPLATE_OPTION = 'prli_mu_dispatch_tpl_stamp';

    /**
     * Absolute filesystem path to the plugin base.
     *
     * @var string
     */
    private string $basePath;

    /**
     * Public URL to the plugin base.
     *
     * @var string
     */
    private string $baseUrl;

    /**
     * Store the plugin base path and URL.
     *
     * @param string $basePath Absolute filesystem path to the plugin base.
     * @param string $baseUrl  Public URL to the plugin base.
     */
    public function __construct(string $basePath, string $baseUrl)
    {
        $this->basePath = $basePath;
        $this->baseUrl  = $baseUrl;
    }

    /**
     * Write the dispatch mu-plugin stub into the mu-plugins directory.
     *
     * @return boolean True on success, false on failure.
     */
    public function install(): bool
    {
        $dir = $this->muDir();
        if (!wp_mkdir_p($dir)) {
            return false;
        }
        $path = $dir . '/' . self::FILENAME;
        $code = $this->generateStub();

        // Write beside the live file and rename over it. file_put_contents()
        // truncates in place, so a request arriving mid-write could load an
        // empty or half-written dispatcher and fatal before the stub's own
        // try/catch is even entered — and this now runs automatically on
        // upgrades, not just when an admin flips the toggle. rename() within one
        // directory is atomic, so a concurrent request sees either the old file
        // or the new one.
        $tmp     = $path . '.' . getmypid() . '.tmp';
        $written = file_put_contents($tmp, $code);
        if ($written === false || $written !== strlen($code)) {
            if (file_exists($tmp)) {
                wp_delete_file($tmp);
            }
            return false;
        }
        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- A failed rename is handled on the next line; the warning adds nothing.
        if (!@rename($tmp, $path)) {
            if (file_exists($tmp)) {
                wp_delete_file($tmp);
            }
            return false;
        }

        update_option(self::VERSION_OPTION, $this->fingerprint($code));
        update_option(self::TEMPLATE_OPTION, $this->templateStamp());
        return true;
    }

    /**
     * Content fingerprint of a rendered drop-in.
     *
     * The refresh check compares fingerprints rather than a hand-maintained
     * version constant, for two reasons.
     *
     * First, correctness on upgrades: `upgrader_process_complete` fires in a
     * request that still has the PRE-upgrade class in memory, so comparing
     * against the loaded `STUB_VERSION` constant reports the old file as current
     * and nothing is rewritten. The new template is already on disk by then, so
     * hashing what generateStub() produces sees the change immediately.
     *
     * Second, it removes a footgun: nobody has to remember to bump a constant
     * when they edit the template.
     *
     * @param string $code Rendered drop-in source.
     *
     * @return string
     */
    private function fingerprint(string $code): string
    {
        return md5($code);
    }

    /**
     * Rewrite the drop-in when it is missing or built from an older template.
     *
     * Without this the file written the day turbo mode was switched on runs
     * forever, across every plugin update — so dispatcher fixes reach only
     * sites that happen to toggle the setting off and on again.
     *
     * Runs on `admin_init`, on front-end `init`, and after any plugin upgrade.
     * The front-end hook matters for a site whose admin is rarely visited: an
     * auto-update lands via cron, and without it the stale dispatcher keeps
     * serving until someone loads wp-admin. Cheap: one autoloaded option read
     * unless turbo mode is on, and the template is only rendered and hashed when
     * the drop-in is actually present.
     *
     * @return void
     */
    public function maybeRefresh(): void
    {
        if (!(new ProOptionsStore())->get('mu_dispatch')) {
            // Setting off but the drop-in still on disk: a teardown that failed
            // silently. Confirmed in the field (HS #884065) — the same account
            // had one site tear down correctly and another not, with nothing in
            // the admin revealing it. Left alone, that file serves every
            // redirect on a site whose owner believes the feature is off, and
            // once refresh exists it would be the ONE state never reached:
            // enabled sites self-heal on upgrade, orphans freeze forever. So an
            // orphan is removed here rather than merely skipped.
            if ($this->isInstalled()) {
                self::removeIfExists();
            }
            return;
        }
        if (!$this->isInstalled()) {
            $this->install();
            return;
        }
        // Cheap gate first. Rendering and hashing the ~1,000-line template on
        // every front-end request just to learn nothing changed is a per-request
        // disk read added by a performance feature. The template's mtime and size
        // move whenever it is edited or a new one is deployed — including the
        // pre-upgrade-class case, since the file on disk is already the new one —
        // so two stat() calls answer the common case.
        $templateStamp = $this->templateStamp();
        if ((string) get_option(self::TEMPLATE_OPTION, '') === $templateStamp) {
            return;
        }

        // Template moved. Hash the rendered result before rewriting, because
        // mtime changes for reasons that don't change content (a redeploy, a
        // touch) and there is no point rewriting the drop-in for those. Compares
        // against the template as it exists on disk right now, so this is correct
        // even when called from a request holding pre-upgrade code.
        if (get_option(self::VERSION_OPTION) !== $this->fingerprint($this->generateStub())) {
            $this->install();
            return;
        }

        // Same content, new mtime. Record the new template identity so the cheap
        // gate catches it next time instead of re-hashing on every request.
        update_option(self::TEMPLATE_OPTION, $templateStamp);
    }

    /**
     * Cheap identity for the bundled template: its mtime and size.
     *
     * Stored alongside the content fingerprint so the common "nothing changed"
     * case costs two `stat()` calls instead of a file read, a `strtr` and an
     * md5. Not a substitute for the fingerprint — it says "the template file has
     * not been touched", which is sufficient to skip, but never sufficient to
     * conclude the installed drop-in is correct.
     *
     * @return string
     */
    private function templateStamp(): string
    {
        $path = __DIR__ . '/mu-plugin-template.php.stub';
        return 'tpl:' . (string) @filemtime($path) . ':' . (string) @filesize($path);
    }

    /**
     * Remove the dispatch mu-plugin stub if present.
     *
     * @return boolean True on success, false on failure.
     */
    public function uninstall(): bool
    {
        return self::removeIfExists();
    }

    /**
     * Delete the mu-plugin stub file if it exists.
     *
     * @return boolean True when the file is absent or removed.
     */
    public static function removeIfExists(): bool
    {
        $dir  = defined('WPMU_PLUGIN_DIR') ? (string) WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins';
        $path = $dir . '/' . self::FILENAME;
        delete_option(self::VERSION_OPTION);
        delete_option(self::TEMPLATE_OPTION);
        if (!file_exists($path)) {
            return true;
        }
        // Removal has to be re-checked: wp_delete_file() returns void, so a
        // cast on its return value is always false.
        wp_delete_file($path);
        return !file_exists($path);
    }

    /**
     * Whether the dispatch mu-plugin stub is currently installed.
     *
     * @return boolean True when the stub file exists.
     */
    public function isInstalled(): bool
    {
        return file_exists($this->muDir() . '/' . self::FILENAME);
    }

    /**
     * Self-heal after a mu-plugin dispatch crash.
     *
     * The stub's top-level try/catch writes `prli_mu_dispatch_error` when it
     * catches a Throwable. On the next front-end request, the main plugin
     * loads normally on `init` and this runs at priority 0: remove the
     * mu-plugin file, flip the `mu_dispatch` setting back off, and delete
     * the trigger flag. Silent — the crash detail is only in the PHP error
     * log when WP_DEBUG_LOG is on.
     */
    public static function maybeSelfHeal(): void
    {
        if (empty(get_option('prli_mu_dispatch_error'))) {
            return;
        }
        self::removeIfExists();
        (new ProOptionsStore())->set('mu_dispatch', false);
        delete_option('prli_mu_dispatch_error');
    }

    /**
     * Resolve the mu-plugins directory path.
     *
     * @return string Absolute path to the mu-plugins directory.
     */
    private function muDir(): string
    {
        if (defined('WPMU_PLUGIN_DIR')) {
            return (string) WPMU_PLUGIN_DIR;
        }
        return WP_CONTENT_DIR . '/mu-plugins';
    }

    /**
     * Build the mu-plugin stub contents from the bundled template.
     *
     * @return string The rendered mu-plugin PHP source.
     */
    private function generateStub(): string
    {
        $template = (string) file_get_contents(__DIR__ . '/mu-plugin-template.php.stub');
        $basename = plugin_basename($this->basePath . 'pretty-link.php');
        // Edition is baked in (per-build slug, can't change at
        // runtime). Version is NOT baked in — the mu-plugin reads it
        // from the main plugin file's `Version:` header via
        // get_file_data() on every request, so the mu-plugin doesn't
        // go stale when the plugin is updated and the user never has
        // to reinstall it.
        $edition      = defined('PRLI_EDITION')
            ? (string) PRLI_EDITION
            : 'pretty-link-lite';
        $editionLabel = ucwords(str_replace('-', ' ', $edition));
        // No geo-endpoint placeholder: the dispatcher no longer makes an
        // outbound geo call. It reads the shared cache and queues anything it
        // can't answer for GeoBackfillJob.
        return strtr($template, [
            '%%PRLI_PLUGIN_BASENAME%%' => $basename,
            '%%PRLI_EDITION_LABEL%%'   => $editionLabel,
            '%%PRLI_STUB_VERSION%%'    => self::STUB_VERSION,
            // Var_export so apostrophes (and any future specials) stay valid
            // inside the stub's single-quoted concat — raw injection of the
            // constant value terminates the string early (#861 Paul follow-up).
            '%%PRLI_SLUG_CHAR_CLASS%%' => var_export(Engine::SLUG_CHAR_CLASS, true),
        ]);
    }
}
