<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Repositories;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching
// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_key
// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_value
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter
// Custom plugin tables (prli_*): table names interpolated from $wpdb->prefix (trusted),
// user values bind through $wpdb->prepare(). No caching: these tables are the source
// of truth for click/redirect data and must read-through. "meta_key"/"meta_value" here
// refer to our own prli_link_metas table, not wp_postmeta.

/**
 * Repository for link category terms backed by the prli_categories table.
 */
class Categories
{
    /**
     * Bulk lookup of category name/id pairs for a set of link ids.
     * Returns `[linkId => [{id, name}, …]]`, alphabetized by name.
     * Unknown link ids are omitted from the result — callers seed their
     * own default shape if they want one row per id.
     *
     * @param  int[] $linkIds The link ids to look up categories for.
     * @return array<int, array<int, array{id:int, name:string}>>
     */
    public function namesForLinks(array $linkIds): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $linkIds))));
        if (!$ids) {
            return [];
        }
        global $wpdb;
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $sql = "SELECT lt.link_id, c.id AS term_id, c.name
                   FROM {$wpdb->prefix}prli_link_terms lt
                   INNER JOIN {$wpdb->prefix}prli_categories c ON c.id = lt.term_id
                  WHERE lt.taxonomy = 'category'
                    AND lt.link_id IN ({$placeholders})
                  ORDER BY c.name ASC";
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql interpolates only the prli_link_terms/prli_categories table names and the generated %d placeholder list; the link ids are bound here by $wpdb->prepare().
        $rows = (array) $wpdb->get_results($wpdb->prepare($sql, ...$ids), ARRAY_A);
        $out  = [];
        foreach ($rows as $row) {
            $lid         = (int) $row['link_id'];
            $out[$lid][] = [
                'id'   => (int) $row['term_id'],
                'name' => (string) $row['name'],
            ];
        }
        return $out;
    }

    /**
     * Return all categories with their link counts, ordered by name.
     *
     * @return array<int, array<string, mixed>>
     */
    public function all(): array
    {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT c.id, c.name, c.slug, c.description, c.parent_id,
                    COALESCE(lt.cnt, 0) AS count
             FROM {$wpdb->prefix}prli_categories c
             LEFT JOIN (
               SELECT term_id, COUNT(*) AS cnt
               FROM {$wpdb->prefix}prli_link_terms
               WHERE taxonomy = 'category'
               GROUP BY term_id
             ) lt ON lt.term_id = c.id
             ORDER BY c.name ASC",
            ARRAY_A
        ) ?: [];
        return array_map([self::class, 'hydrate'], $rows);
    }

    /**
     * Create a new category from the given data.
     *
     * @param  array<string, mixed> $data The category fields (name, slug, description, parent_id).
     * @return array<string, mixed>
     */
    public function create(array $data): array
    {
        global $wpdb;
        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            return ['error' => 'name_required'];
        }
        $row = [
            'name'        => $name,
            'slug'        => (string) ($data['slug'] ?? sanitize_title($name)),
            'description' => (string) ($data['description'] ?? ''),
            'parent_id'   => isset($data['parent_id']) ? (int) $data['parent_id'] : null,
            'count'       => 0,
        ];
        $wpdb->insert($wpdb->prefix . 'prli_categories', $row);
        $row['id'] = (int) $wpdb->insert_id;
        return self::hydrate($row);
    }

    /**
     * Update an existing category by id with the given fields.
     *
     * @param  integer              $id   The category id to update.
     * @param  array<string, mixed> $data The category fields to patch.
     * @return array<string, mixed>|null
     */
    public function update(int $id, array $data): ?array
    {
        global $wpdb;
        $patch = [];
        foreach (['name', 'slug', 'description', 'parent_id'] as $key) {
            if (array_key_exists($key, $data)) {
                $patch[$key] = $key === 'parent_id' ? (int) $data[$key] : (string) $data[$key];
            }
        }
        if (!$patch) {
            return null;
        }
        $wpdb->update($wpdb->prefix . 'prli_categories', $patch, ['id' => $id]);
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}prli_categories WHERE id = %d", $id),
            ARRAY_A
        );
        return is_array($row) ? self::hydrate($row) : null;
    }

    /**
     * Delete a category by id and detach it from any links.
     *
     * @param  integer $id The category id to delete.
     * @return boolean
     */
    public function delete(int $id): bool
    {
        global $wpdb;
        $wpdb->delete(
            $wpdb->prefix . 'prli_link_terms',
            [
                'term_id'  => $id,
                'taxonomy' => 'category',
            ]
        );
        return (bool) $wpdb->delete($wpdb->prefix . 'prli_categories', ['id' => $id]);
    }

    /**
     * Return the category with the given slug, creating it if it doesn't exist.
     * Used by the CSV importer to resolve slug strings to IDs without requiring
     * the user to pre-create every category.
     *
     * @param  string $slug The category slug to find or create.
     * @param  string $name Optional display name used when creating a new category.
     * @return array<string, mixed>
     */
    public function findOrCreateBySlug(string $slug, string $name = ''): array
    {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, name, slug, description, parent_id FROM {$wpdb->prefix}prli_categories WHERE slug = %s LIMIT 1",
                $slug
            ),
            ARRAY_A
        );
        if (is_array($row)) {
            return self::hydrate(array_merge(['count' => 0], $row));
        }
        return $this->create([
            'name' => $name !== '' ? $name : $slug,
            'slug' => $slug,
        ]);
    }

    /**
     * Normalize a raw database row into the category array shape.
     *
     * @param  array<string, mixed> $row The raw database row.
     * @return array<string, mixed>
     */
    private static function hydrate(array $row): array
    {
        return [
            'id'          => (int) $row['id'],
            'name'        => (string) $row['name'],
            'slug'        => (string) $row['slug'],
            'description' => (string) ($row['description'] ?? ''),
            'parent_id'   => $row['parent_id'] !== null ? (int) $row['parent_id'] : null,
            'count'       => (int) ($row['count'] ?? 0),
        ];
    }
}
