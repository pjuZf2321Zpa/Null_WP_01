<?php

/**
 * Broken Links email digest template.
 *
 * Variables provided by EmailDigest::run():
 *
 * @var array<int, array<string, mixed>> $brokenLinks
 * @var string                            $siteName
 * @var string                            $adminUrl
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
// Email template — variables are local to this included file, not globals.
?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr(get_bloginfo('language')); ?>">
<head>
<meta charset="<?php echo esc_attr(get_option('blog_charset')); ?>">
<title><?php echo esc_html($siteName); ?> &mdash; <?php esc_html_e('Broken Links Report', 'pretty-link-pro'); ?></title>
<style type="text/css">
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #1d2327; background: #f6f7f7; margin: 0; padding: 24px; }
.prli-email-wrap { max-width: 720px; margin: 0 auto; background: #fff; border: 1px solid #dcdcde; border-radius: 4px; padding: 24px; }
.prli-email-header { border-bottom: 1px solid #dcdcde; padding-bottom: 12px; margin-bottom: 18px; }
.prli-email-header h1 { font-size: 18px; margin: 0 0 4px; }
.prli-email-header p { margin: 0; color: #50575e; font-size: 13px; }
.prli-email-table { width: 100%; border-collapse: collapse; margin-top: 12px; }
.prli-email-table th, .prli-email-table td { text-align: left; padding: 8px 10px; border-bottom: 1px solid #f0f0f1; font-size: 13px; vertical-align: top; }
.prli-email-table th { background: #f6f7f7; font-weight: 600; color: #1d2327; }
.prli-email-table a { color: #2271b1; text-decoration: none; }
.prli-status { font-weight: 600; color: #b32d2e; }
.prli-email-note { color: #646970; font-size: 12px; margin-top: -4px; }
.prli-email-footer { margin-top: 18px; padding-top: 12px; border-top: 1px solid #dcdcde; color: #646970; font-size: 12px; }
</style>
</head>
<body>
<div class="prli-email-wrap">
    <div class="prli-email-header">
        <h1><?php echo esc_html($siteName); ?></h1>
        <p><?php esc_html_e('Broken Links Report', 'pretty-link-pro'); ?></p>
    </div>

    <p>
        <?php
        printf(
            // phpcs:ignore Squiz.Commenting.InlineComment.NotCapital,Squiz.Commenting.InlineComment.InvalidEndChar -- translators comment must stay verbatim for i18n tooling.
            // translators: %d: number of broken links
            esc_html(_n(
                'Pretty Links has detected %d broken link on your site.',
                'Pretty Links has detected %d broken links on your site.',
                count($brokenLinks),
                'pretty-link-pro'
            )),
            (int) count($brokenLinks)
        );
        ?>
    </p>

    <p class="prli-email-note">
        <?php esc_html_e('These targets returned a not-found response on more than one check. If a link works in your browser, its destination may simply block automated checks — open it to edit it, then switch on "Exclude from link health checks" to stop reporting it.', 'pretty-link-pro'); ?>
    </p>

    <table class="prli-email-table" role="presentation">
        <thead>
            <tr>
                <th><?php esc_html_e('Name', 'pretty-link-pro'); ?></th>
                <th><?php esc_html_e('Pretty URL', 'pretty-link-pro'); ?></th>
                <th><?php esc_html_e('Target URL', 'pretty-link-pro'); ?></th>
                <th><?php esc_html_e('Status', 'pretty-link-pro'); ?></th>
                <th><?php esc_html_e('Last Checked', 'pretty-link-pro'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($brokenLinks as $row) :
                $linkId      = (int) ($row['id'] ?? 0);
                $name        = (string) ($row['name'] ?? '');
                $slug        = (string) ($row['slug'] ?? '');
                $url         = (string) ($row['url'] ?? '');
                $statusCode  = (string) ($row['status_code'] ?? '');
                $lastChecked = (string) ($row['last_checked'] ?? '');
                $editUrl     = $adminUrl . $linkId;
                $prettyUrl   = \PrettyLinks\Helpers\LinkUrl::build($slug);
                ?>
                <tr>
                    <td><a href="<?php echo esc_url($editUrl); ?>"><?php echo esc_html($name !== '' ? $name : $slug); ?></a></td>
                    <td><a href="<?php echo esc_url($prettyUrl); ?>"><?php echo esc_html($prettyUrl); ?></a></td>
                    <td><a href="<?php echo esc_url($url); ?>"><?php echo esc_html($url); ?></a></td>
                    <td class="prli-status"><?php echo $statusCode === '0' ? esc_html__('Domain not found', 'pretty-link-pro') : esc_html($statusCode !== '' ? $statusCode : '0'); ?></td>
                    <td><?php echo esc_html($lastChecked); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="prli-email-footer">
        <?php
        printf(
            // phpcs:ignore Squiz.Commenting.InlineComment.NotCapital,Squiz.Commenting.InlineComment.InvalidEndChar -- translators comment must stay verbatim for i18n tooling.
            // translators: %s: site name
            esc_html__('This report was sent automatically by Pretty Links on %s.', 'pretty-link-pro'),
            esc_html($siteName)
        );
        ?>
    </div>
</div>
</body>
</html>
