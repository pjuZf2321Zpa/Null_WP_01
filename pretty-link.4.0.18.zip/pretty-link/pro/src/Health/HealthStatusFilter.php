<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Health;

use PrettyLinks\Repositories\Links;

// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_key
// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_value
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter
// Custom plugin tables (prli_*): table names interpolated from $wpdb->prefix (trusted),
// user values bind through $wpdb->prepare(). No caching: these tables are the source
// of truth for click/redirect data and must read-through. "meta_key"/"meta_value" here
// refer to our own prli_link_metas table, not wp_postmeta.

/**
 * Contributes health-status WHERE fragments to the shared
 * `prli_links_query_clauses` filter. Owns the SQL shape of the
 * "broken" bucket — Bootstrap wires the hook, this class provides the
 * clause.
 *
 * Canonical on `health_status` = `'inactive'` (v3 meta shape). A link
 * with no `health_status` row has never been probed — matching v3, it
 * is not counted as broken.
 */
class HealthStatusFilter
{
    /**
     * Appends the "broken" health-status WHERE fragment to the query clauses.
     *
     * @param  array{0: array<int, string>, 1: array<int, mixed>} $clauses Query clauses as a [where, params] tuple.
     * @param  array<string, mixed>                               $args    Query arguments, may include the 'health' filter.
     * @return array{0: array<int, string>, 1: array<int, mixed>}
     */
    public function apply(array $clauses, array $args): array
    {
        $health = (string) ($args['health'] ?? '');
        if ($health !== 'broken') {
            return $clauses;
        }
        global $wpdb;
        [$where, $params] = $clauses;
        $metas            = $wpdb->prefix . 'prli_link_metas';
        $where[]          = "id IN (
            SELECT link_id FROM {$metas}
            WHERE meta_key = 'health_status' AND meta_value = 'inactive'
        )";
        return [$where, $params];
    }

    /**
     * Number of links the "Broken" tab lists: the same query the tab runs
     * (`health = broken`, status any, non-PrettyPay), so trashed links, pay
     * links and orphan metas never inflate the "Broken (N)" label.
     */
    public static function brokenCount(): int
    {
        $result = (new Links())->search([
            'health'    => 'broken',
            'status'    => 'any',
            'prettypay' => 0,
            'per_page'  => 1,
            'fields'    => ['id'],
        ]);
        return (int) $result['total'];
    }
}
