<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\Onboarding;

/**
 * Turns on the Pro features a user queued in Lite's onboarding wizard.
 *
 * Lite's wizard asks through the `prli_onboarding_drain_feature` filter once
 * the license is active; this owns the mapping from its feature ids to Pro's
 * options, so Lite never writes `prlipro_options`.
 */
class QueuedFeatures
{
    /**
     * Features whose switch is its own option row rather than a
     * `prlipro_options` key. Pro reads these as truthy, defaulting on.
     */
    private const STANDALONE = [
        'options-pretty-bar' => 'prlipro_prettybar_active',
    ];

    /**
     * Feature id → `prlipro_options` keys. Matches v3's enable_disable_feature.
     */
    private const OPTION_KEYS = [
        'options-replacements' => [
            'keyword_replacement_is_on' => true,
            'url_replacement_is_on'     => true,
        ],
        'options-link-health'  => ['enable_link_health' => true],
        'options-autocreate'   => ['autocreate_enable' => true],
        'link-form-qr'         => ['generate_qr_codes' => true],
    ];

    /**
     * `prli_onboarding_drain_feature` callback.
     *
     * @param  boolean $enabled   Whether an earlier callback already turned it on.
     * @param  string  $featureId The queued feature id.
     * @return boolean True when a toggle flipped.
     */
    public static function drain(bool $enabled, string $featureId): bool
    {
        return self::enable($featureId) || $enabled;
    }

    /**
     * Enable a Pro feature by writing the corresponding option key(s).
     *
     * @param  string $featureId Pro feature id.
     * @return boolean True when any known toggle flipped.
     */
    public static function enable(string $featureId): bool
    {
        if (isset(self::STANDALONE[$featureId])) {
            $option = self::STANDALONE[$featureId];
            if ((bool) get_option($option, true)) {
                return false;
            }
            update_option($option, 1);
            return true;
        }

        if (!isset(self::OPTION_KEYS[$featureId])) {
            return false;
        }

        $opts = get_option('prlipro_options', []);
        if (!is_array($opts)) {
            $opts = [];
        }
        $changed = false;
        foreach (self::OPTION_KEYS[$featureId] as $key => $value) {
            if (($opts[$key] ?? null) !== $value) {
                $opts[$key] = $value;
                $changed    = true;
            }
        }
        if ($changed) {
            update_option('prlipro_options', $opts);
        }
        return $changed;
    }
}
