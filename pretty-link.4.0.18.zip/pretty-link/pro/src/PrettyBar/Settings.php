<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\PrettyBar;

// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_key
// phpcs:disable WordPress.DB.SlowDBQuery.slow_db_query_meta_value
// phpcs:disable PluginCheck.Security.DirectDB.UnescapedDBParameter
// Custom plugin tables (prli_*): table names interpolated from $wpdb->prefix (trusted),
// user values bind through $wpdb->prepare(). No caching: these tables are the source
// of truth for click/redirect data and must read-through. "meta_key"/"meta_value" here
// refer to our own prli_link_metas table, not wp_postmeta.
use PrettyLinks\Pro\Options\Store as OptionsStore;

/**
 * Read helpers for Pretty Bar settings.
 *
 * Storage keeps the v3 key names, all on Pro-owned rows:
 *   - `prlipro_prettybar_active` — standalone wp_option row
 *   - `prlipro_options.prettybar_image_url`        (logo URL)
 *   - `prlipro_options.prettybar_title_limit`      (shared v3 char caps; Classic fallbacks 25/30/30, modern 60/140/60)
 *   - `prlipro_options.prettybar_desc_limit`
 *   - `prlipro_options.prettybar_link_limit`
 *   - `prlipro_options.prettybar_hide_attrib_link`
 *   - `prlipro_options.prettybar_attrib_url`
 *
 * v3 kept the logo URL, char caps and the Classic colour/toggle keys in
 * Lite's `prli_options`; the Pro migrator's `copy_prettybar_options` step
 * copies them into `prlipro_options` once on upgrade.
 *
 * The 4.0 live editor adds a single extra key:
 *   - `prlipro_options.prettybar_logo_attachment_id` — WP Media attachment ID
 *     for the shared logo. Sibling to the URL key; the latter is kept in
 *     sync on save (resolved URL) so the Classic template keeps rendering
 *     the same image.
 *
 * Per-template settings live under the nested `prettybar_templates` key
 * on `prlipro_options`. Each template supplies its own defaults via its
 * static `defaults()` method and Settings::forTemplate merges the saved
 * values on top.
 */
final class Settings
{
    public const ACTIVE_OPTION = 'prlipro_prettybar_active';

    /**
     * Returns the shared Pretty Bar settings common to all templates.
     *
     * @return array<string, mixed>
     */
    public static function shared(): array
    {
        $pro    = new OptionsStore();
        $attrib = (string) $pro->getPro('prettybar_attrib_url', '');
        if ($attrib === '') {
            $attrib = 'https://prettylinks.com';
        }
        $logoId  = (int) $pro->getPro('prettybar_logo_attachment_id', 0);
        $logoUrl = (string) $pro->getPro('prettybar_image_url', '');
        // Resolve attachment URL when the ID is set — it's the canonical
        // source in 4.0. Fall back to the v3 string key otherwise so
        // legacy installs keep rendering.
        if ($logoId > 0) {
            $resolved = wp_get_attachment_url($logoId);
            if (is_string($resolved) && $resolved !== '') {
                $logoUrl = $resolved;
            }
        }
        return [
            'active'             => (bool) get_option(self::ACTIVE_OPTION, true),
            'logo_attachment_id' => $logoId,
            'logo_url'           => $logoUrl,
            'hide_attribution'   => (bool) $pro->getPro('prettybar_hide_attrib_link', false),
            'attribution_url'    => $attrib,
        ];
    }

    /**
     * Returns the saved settings for a template merged over its defaults.
     *
     * @param string               $templateId The template identifier.
     * @param array<string, mixed> $defaults   Defaults supplied by the template.
     *
     * @return array<string, mixed>
     */
    public static function forTemplate(string $templateId, array $defaults): array
    {
        $store     = new OptionsStore();
        $templates = $store->getPro('prettybar_templates', []);
        $tpl       = is_array($templates) && isset($templates[$templateId]) && is_array($templates[$templateId])
            ? $templates[$templateId]
            : [];
        return array_merge($defaults, $tpl);
    }

    /**
     * Whether any link on the site is still using the v3-style Classic
     * Pretty Bar (redirect_type=prettybar with no prettybar_template
     * meta). Drives two conditional UI surfaces:
     *
     *   - The per-link template dropdown exposes "Classic" only when this
     *     specific link currently uses it (computed by the link form),
     *     but we also use this site-wide flag to gate the admin-page
     *     section entirely.
     *   - The Options → Pretty Bar page shows its Classic settings block
     *     only when this returns true.
     *
     * Fresh 4.0 installs always return false — Classic settings stay
     * invisible until a legacy link exists.
     */
    public static function hasLegacyLinks(): bool
    {
        global $wpdb;
        $links = $wpdb->prefix . 'prli_links';
        $metas = $wpdb->prefix . 'prli_link_metas';
        // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Only $links/$metas are interpolated, both plugin-owned table names built from $wpdb->prefix; the query takes no input at all, so there is nothing to bind. These tables have no WP API, and the flag gates admin UI so it must reflect the current rows.
        $exists = (int) $wpdb->get_var(
            "SELECT EXISTS (
                SELECT 1 FROM {$links} l
                LEFT JOIN {$metas} m
                  ON m.link_id = l.id AND m.meta_key = 'prettybar_template'
                WHERE l.redirect_type = 'prettybar'
                  AND l.deleted_at IS NULL
                  AND (m.meta_value IS NULL OR m.meta_value = '')
            )"
        );
        // phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $exists === 1;
    }
}
