<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\PrettyBar\Templates;

use PrettyLinks\Pro\PrettyBar\Settings;

/**
 * Modern "Bottom bar" — same content layout as the top bar, docked to
 * the bottom of the viewport. Suits sites whose branding sits at the top
 * of their target pages (top-anchored Pretty Bar would collide).
 */
final class BottomBarTemplate extends AbstractTemplate
{
    public const ID = 'bottom-bar';

    /**
     * Returns the default settings for the Bottom bar template.
     *
     * @return array<string, mixed>
     */
    public static function defaults(): array
    {
        return array_merge(self::sharedDefaults(), [
            // Dark slate gradient with cyan accent — pairs well with
            // light destination pages by providing strong contrast at
            // the fold. Strong shadow lifts it off the iframe.
            'bgType'       => 'gradient',
            'bgColor'      => '#0f172a',
            'bgColor2'     => '#1e293b',
            'bgAngle'      => 180,
            'textColor'    => '#f8fafc',
            'accentColor'  => '#22d3ee',
            'ctaTextColor' => '#0f172a',
            'shadow'       => 'strong',
            'height'       => 'standard',
            'showShare'    => true,
            'showDismiss'  => true,
        ]);
    }

    /**
     * Returns the template's unique identifier.
     *
     * @return string
     */
    public function id(): string
    {
        return self::ID;
    }

    /**
     * Returns the template's human-readable label.
     *
     * @return string
     */
    public function label(): string
    {
        return __('Bottom bar', 'pretty-link-pro');
    }

    /**
     * Returns the resolved settings for this template.
     *
     * @return array<string, mixed>
     */
    public function settings(): array
    {
        return Settings::forTemplate(self::ID, self::defaults());
    }

    /**
     * Renders the Bottom bar document.
     *
     * @param array<string, mixed> $link     Link row.
     * @param string               $target   Resolved outbound URL.
     * @param array<string, mixed> $settings Resolved template settings.
     *
     * @return void
     */
    public function render(array $link, string $target, array $settings): void
    {
        $shared = Settings::shared();
        $title  = (string) ($link['name'] ?? 'Pretty Link');

        $this->emitHead($link, $title, $this->rootCss($settings));

        $heightClass = 'prli-pb--' . preg_replace('/[^a-z]/', '', (string) ($settings['height'] ?? 'standard'));

        echo '<body class="prli-pb prli-pb-bottom ' . esc_attr($heightClass) . '">';
        do_action('prli-pretty-bar-header', $link);
        echo '<iframe class="prli-pb-frame" src="' . esc_url($target) . '" title="' . esc_attr($title) . '"></iframe>';

        echo '<footer class="prli-pb-bar" role="complementary">';

        $logo = $this->logoImg($shared, $title);
        if ($logo !== '') {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- logoImg() returns a pre-escaped <img> tag.
            echo '<div class="prli-pb-logo">' . $logo . '</div>';
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- metaBlock() and actionsBlock() return pre-escaped HTML.
        echo $this->metaBlock($link, $target, $settings, false) . $this->actionsBlock($link, $target, $settings, $shared);

        echo '</footer>';
        if (!empty($settings['showDismiss'])) {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- dismissScript() returns a static inline <script> literal.
            echo $this->dismissScript();
        }
        do_action('prli-pretty-bar-footer', $link);
        echo '</body></html>';
    }
}
