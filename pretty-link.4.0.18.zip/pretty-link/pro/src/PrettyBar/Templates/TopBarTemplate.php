<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\PrettyBar\Templates;

use PrettyLinks\Pro\PrettyBar\Settings;

/**
 * Modern "Top bar" — a clean horizontal strip anchored to the top of the
 * viewport. Iframe fills the rest of the screen. Default for new Pretty
 * Bar links in 4.0.
 */
final class TopBarTemplate extends AbstractTemplate
{
    public const ID = 'top-bar';

    /**
     * Returns the default settings for the Top bar template.
     *
     * @return array<string, mixed>
     */
    public static function defaults(): array
    {
        return array_merge(self::sharedDefaults(), [
            // Soft sky→blue gradient sweeping left→right (90°) with navy
            // text and an indigo share CTA. Friendly on light destination
            // pages and still readable — deep-slate text clears AA at
            // both gradient stops.
            'bgType'       => 'gradient',
            'bgColor'      => '#e0f2fe', // Sky-100.
            'bgColor2'     => '#93c5fd', // Blue-300.
            'bgAngle'      => 90,
            'textColor'    => '#0f172a', // Slate-900.
            'accentColor'  => '#4f46e5', // Indigo-600.
            'ctaTextColor' => '#ffffff',
            'shadow'       => 'soft',
            'height'       => 'standard',
            'showShare'    => true,
            'showDismiss'  => true,
        ]);
    }

    /**
     * Returns the template's unique identifier.
     *
     * @return string
     */
    public function id(): string
    {
        return self::ID;
    }

    /**
     * Returns the template's human-readable label.
     *
     * @return string
     */
    public function label(): string
    {
        return __('Top bar', 'pretty-link-pro');
    }

    /**
     * Returns the resolved settings for this template.
     *
     * @return array<string, mixed>
     */
    public function settings(): array
    {
        return Settings::forTemplate(self::ID, self::defaults());
    }

    /**
     * Renders the Top bar document.
     *
     * @param array<string, mixed> $link     Link row.
     * @param string               $target   Resolved outbound URL.
     * @param array<string, mixed> $settings Resolved template settings.
     *
     * @return void
     */
    public function render(array $link, string $target, array $settings): void
    {
        $shared = Settings::shared();
        $title  = (string) ($link['name'] ?? 'Pretty Link');

        $this->emitHead($link, $title, $this->rootCss($settings));

        $heightClass = 'prli-pb--' . preg_replace('/[^a-z]/', '', (string) ($settings['height'] ?? 'standard'));

        echo '<body class="prli-pb prli-pb-top ' . esc_attr($heightClass) . '">';
        do_action('prli-pretty-bar-header', $link);
        echo '<header class="prli-pb-bar">';

        $logo = $this->logoImg($shared, $title);
        if ($logo !== '') {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- logoImg() returns a pre-escaped <img> tag.
            echo '<div class="prli-pb-logo">' . $logo . '</div>';
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- metaBlock() and actionsBlock() return pre-escaped HTML.
        echo $this->metaBlock($link, $target, $settings, false) . $this->actionsBlock($link, $target, $settings, $shared);

        echo '</header>';
        echo '<iframe class="prli-pb-frame" src="' . esc_url($target) . '" title="' . esc_attr($title) . '"></iframe>';
        if (!empty($settings['showDismiss'])) {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- dismissScript() returns a static inline <script> literal.
            echo $this->dismissScript();
        }
        do_action('prli-pretty-bar-footer', $link);
        echo '</body></html>';
    }
}
