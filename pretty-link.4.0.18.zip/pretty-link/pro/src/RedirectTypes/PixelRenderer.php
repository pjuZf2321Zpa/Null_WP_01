<?php

declare(strict_types=1);

namespace PrettyLinks\Pro\RedirectTypes;

/**
 * Tracking-pixel redirect type. The URL is meant to be called (often embedded
 * somewhere) purely so the click gets logged — there's no actual redirect and
 * no real response body. Byte-for-byte parity with v3: empty text/html body,
 * 200 OK, request terminates.
 */
final class PixelRenderer
{
    /**
     * `prli_handle_redirect_type` filter callback.
     *
     * @param boolean              $handled Whether the redirect was already handled.
     * @param array<string, mixed> $link    Link row.
     * @param string               $target  Resolved outbound URL.
     * @param integer              $status  HTTP status code.
     * @param string               $type    The link redirect_type value.
     *
     * @return boolean Whether the redirect was handled.
     */
    public function filter(bool $handled, array $link, string $target, int $status, string $type): bool
    {
        unset($link, $target, $status);
        if ($handled || $type !== 'pixel') {
            return $handled;
        }
        if (!headers_sent()) {
            http_response_code(200);
            header('Content-Type: text/html', true);
        }
        exit;
    }
}
