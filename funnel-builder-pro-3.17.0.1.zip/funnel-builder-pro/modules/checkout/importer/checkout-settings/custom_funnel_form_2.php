<?php
$product_field  = WFACP_Common::get_product_field();
$advanced_field = WFACP_Common::get_advanced_fields();
$settings       = array(
	'show_on_next_step' => array(
		'single_step' => array(
			'billing_email'       => 'false',
			'billing_first_name'  => 'false',
			'billing_last_name'   => 'false',
			'address'             => 'false',
			'shipping-address'    => 'false',
			'billing_phone'       => 'false',
			'shipping_calculator' => 'false',
		),
	),
);

$customizer_data = array(
	'wfacp_form'                  => array(
		'wfacp_form_section_embed_forms_2_disable_steps_bar' => true,
		'wfacp_form_section_embed_forms_2_select_type'    => 'tab',
		'wfacp_form_section_breadcrumb_0_step_text'       => __( 'Shipping', 'woocommerce' ),
		'wfacp_form_section_breadcrumb_1_step_text'       => __( 'Payment', 'woocommerce' ),
		'wfacp_form_section_text_below_placeorder_btn'    => __( '* 100% Secure &amp; Safe Payments *', 'woofunnels-aero-checkout' ),
		'wfacp_form_section_embed_forms_2_step_alignment' => 'center',
		'wfacp_form_section_embed_forms_2_step_form_max_width' => '664',
		'wfacp_form_section_embed_forms_2_form_border_type' => 'none',
		'wfacp_form_form_fields_1_embed_forms_2_billing_address_1' => 'wfacp-col-left-half',
		'wfacp_form_form_fields_1_embed_forms_2_billing_city' => 'wfacp-col-left-half',
		'wfacp_form_form_fields_1_embed_forms_2_billing_postcode' => 'wfacp-col-left-third',
		'wfacp_form_form_fields_1_embed_forms_2_billing_country' => 'wfacp-col-left-third',
		'wfacp_form_form_fields_1_embed_forms_2_billing_state' => 'wfacp-col-left-third',
		'wfacp_form_form_fields_1_embed_forms_2_shipping_address_1' => 'wfacp-col-left-half',
		'wfacp_form_form_fields_1_embed_forms_2_shipping_city' => 'wfacp-col-left-half',
		'wfacp_form_form_fields_1_embed_forms_2_shipping_postcode' => 'wfacp-col-left-third',
		'wfacp_form_form_fields_1_embed_forms_2_shipping_country' => 'wfacp-col-left-third',
		'wfacp_form_form_fields_1_embed_forms_2_shipping_state' => 'wfacp-col-left-third',
		'wfacp_form_form_fields_1_embed_forms_2_billing_first_name' => 'wfacp-col-left-half',
		'wfacp_form_form_fields_1_embed_forms_2_billing_last_name' => 'wfacp-col-left-half',
		'wfacp_order_summary_section_embed_forms_2_order_summary_hide_img' => true,
		'wfacp_form_section_embed_forms_2_sec_heading_color' => '#333',
		'wfacp_form_section_embed_forms_2_heading_fs'     => array(
			'desktop'      => '20',
			'tablet'       => '20',
			'mobile'       => '14',
			'desktop-unit' => 'px',
			'tablet-unit'  => 'px',
			'mobile-unit'  => 'px',
		),
	),
	'wfacp_form_product_switcher' => array(
		'wfacp_form_product_switcher_section_embed_forms_2_product_switcher_bg_color'   => '#f7f7f7',
		'wfacp_form_product_switcher_section_embed_forms_2_product_switcher_text_color' => '#4d4c4f',
	),
);

$steps = array(
	'single_step' => array(
		'name'          => __( 'Step 1', 'woofunnels-aero-checkout' ),
		'slug'          => 'single_step',
		'friendly_name' => __( 'Single Step Checkout', 'woofunnels-aero-checkout' ),
		'active'        => 'yes',
	),
	'two_step'    => array(
		'name'          => __( 'Step 2', 'woofunnels-aero-checkout' ),
		'slug'          => 'two_step',
		'friendly_name' => __( 'Two Step Checkout', 'woofunnels-aero-checkout' ),
		'active'        => 'yes',
	),
	'third_step'  => array(
		'name'          => __( 'Step 3', 'woofunnels-aero-checkout' ),
		'slug'          => 'third_step',
		'friendly_name' => __( 'Three Step Checkout', 'woofunnels-aero-checkout' ),
		'active'        => 'no',
	),
);

$pageLayout = array(
	'steps'                       => $steps,
	'fieldsets'                   => array(
		'single_step' => array(
			array(
				'name'        => __( 'Contact Information', 'woofunnels-aero-checkout' ),
				'class'       => '',
				'sub_heading' => '',
				'fields'      => array(
					array(
						'label'        => __( 'Email', 'woocommerce' ),
						'required'     => 'true',
						'type'         => 'email',
						'class'        => array( 0 => 'form-row-wide' ),
						'validate'     => array( 0 => 'email' ),
						'autocomplete' => 'email',
						'priority'     => '110',
						'id'           => 'billing_email',
						'field_type'   => 'billing',
						'placeholder'  => '',
					),
					array(
						'label'        => __( 'First name', 'woocommerce' ),
						'required'     => 'true',
						'class'        => array( 0 => 'form-row-first' ),
						'autocomplete' => 'given-name',
						'priority'     => '10',
						'type'         => 'text',
						'id'           => 'billing_first_name',
						'field_type'   => 'billing',
						'placeholder'  => '',
					),
					array(
						'label'        => __( 'Last name', 'woocommerce' ),
						'required'     => 'true',
						'class'        => array( 0 => 'form-row-last' ),
						'autocomplete' => 'family-name',
						'priority'     => '20',
						'type'         => 'text',
						'id'           => 'billing_last_name',
						'field_type'   => 'billing',
						'placeholder'  => '',
					),
					array(
						'label'        => __( 'Phone', 'woocommerce' ),
						'type'         => 'tel',
						'class'        => array( 'form-row-wide' ),
						'id'           => 'billing_phone',
						'field_type'   => 'billing',
						'validate'     => array( 'phone' ),
						'placeholder'  => '',
						'autocomplete' => 'tel',
						'priority'     => 100,
					),
				),
			),
			array(
				'name'        => __( 'Billing Details', 'woofunnels-aero-checkout' ),
				'class'       => '',
				'sub_heading' => '',
				'fields'      => array(
					WFACP_Common::get_single_address_fields(),
					WFACP_Common::get_single_address_fields( 'shipping' ),
				),
			),
			array(
				'name'        => __( 'Your Product', 'woofunnels-aero-checkout' ),
				'class'       => 'wfacp_product_switcher',
				'sub_heading' => '',
				'html_fields' => array(
					'product_switching' => 'true',
				),
				'fields'      => array(
					$product_field['product_switching'],

				),
			),

		),
		'two_step'    => array(
			array(
				'name'        => __( 'Shipping Method', 'woocommerce' ),
				'class'       => '',
				'sub_heading' => '',
				'html_fields' => array( 'shipping_calculator' => true ),
				'fields'      => array(
					isset( $advanced_field['shipping_calculator'] ) ? $advanced_field['shipping_calculator'] : array(),
				),
			),
			array(
				'name'        => __( 'Order summary', 'woocommerce' ),
				'class'       => 'wfacp_order_summary_box',
				'sub_heading' => '',
				'html_fields' => array(
					'order_coupon'  => 'true',
					'order_summary' => 'true',
				),
				'fields'      => array(
					$advanced_field['order_coupon'],
					$advanced_field['order_summary'],
				),
			),
		),
	),
	'product_settings'            => array(
		'coupons'                             => '',
		'enable_coupon'                       => 'false',
		'disable_coupon'                      => 'false',
		'hide_quantity_switcher'              => 'false',
		'enable_delete_item'                  => 'false',
		'hide_product_image'                  => 'false',
		'is_hide_additional_information'      => 'true',
		'additional_information_title'        => WFACP_Common::get_default_additional_information_title(),
		'hide_quick_view'                     => 'true',
		'hide_you_save'                       => 'true',
		'hide_best_value'                     => 'false',
		'best_value_product'                  => '',
		'best_value_text'                     => __( 'Best Value', 'woofunnels-aero-checkout' ),
		'best_value_position'                 => 'above',
		'enable_custom_name_in_order_summary' => 'false',
		'autocomplete_enable'                 => 'false',
		'autocomplete_google_key'             => '',
		'preferred_countries_enable'          => 'false',
		'preferred_countries'                 => '',
		'product_switcher_template'           => 'default',
	),
	'have_coupon_field'           => 'true',
	'have_billing_address'        => 'true',
	'have_shipping_address'       => 'true',
	'have_billing_address_index'  => '5',
	'have_shipping_address_index' => '6',
	'enabled_product_switching'   => 'yes',
	'have_shipping_method'        => 'true',
	'current_step'                => 'two_step',
);


$product_settings                     = array();
$product_settings['settings']         = $pageLayout['product_settings'];
$product_settings['products']         = array();
$product_settings['default_products'] = array();

return array(
	'default_customizer_value'       => $customizer_data,
	'page_layout'                    => $pageLayout,
	'page_settings'                  => $settings,
	'wfacp_product_switcher_setting' => $product_settings,
);
