<?php
if ( ! class_exists( 'WFACP_Template_Importer' ) ) {
	#[AllowDynamicProperties]
	class WFACP_Template_Importer {

		private static $instance = null;
		private static $importer = array();

		private function __construct() {
		}

		public static function get_error_message( $code ) {
			$messages = array(
				'license-or-domain-invalid' => __( 'This site does not have access to template library.  To get access activate the license. For any further help contact support.', 'woofunnels-aero-checkout' ),
				'license-not-provided'      => __( 'This site does not have access to template library.  To get access activate the license. For any further help contact support.', 'woofunnels-aero-checkout' ),
				'unauthorized-access'       => sprintf( __( 'Please check if you have valid license key. <a href=%s target="_blank">Go to Licenses</a>', 'woofunnels-aero' ), esc_url( admin_url( 'admin.php?page=woofunnels' ) ) ),
				'template-not-exists'       => __( 'Template not available in cloud library. Please contact support.', 'woofunnels-aero-checkout' ),
			);
			if ( isset( $messages[ $code ] ) ) {
				return $messages[ $code ];
			}

			return $code;
		}

		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public static function register( $builder, $importer ) {
			if ( ! isset( self::$importer[ $builder ] ) ) {
				self::$importer[ $builder ] = $importer;
			}
		}

		/**
		 * @param $aero_id
		 * @param $builder
		 * @param $slug
		 *
		 * @return bool
		 */
		public function import( $aero_id, $builder, $slug, $is_multi = 'no' ) {

			// divi5 falls back to divi importer if no dedicated divi5 importer is registered
			$importer_key = $builder;
			if ( 'divi5' === $builder && ! isset( self::$importer['divi5'] ) && isset( self::$importer['divi'] ) ) {
				$importer_key = 'divi';
			}

			if ( isset( self::$importer[ $importer_key ] ) && self::$importer[ $importer_key ] ) {

				$importer = self::$importer[ $importer_key ];

				do_action( 'wfacp_template_import', $aero_id, $builder, $slug, $is_multi );
				if ( method_exists( $importer, 'import_child' ) ) {

					$status = $importer->import_child( $aero_id, $slug, $is_multi );
				} else {

					$status = $importer->import( $aero_id, $slug, $is_multi );
				}

				return $status;
			}

			if ( $builder == 'elementor' ) {
				if ( ( ! version_compare( get_bloginfo( 'version' ), '5.0', '>=' ) && ( version_compare( ELEMENTOR_VERSION, '2.8.0', '>=' ) ) ) ) {
					$message = sprintf( esc_html__( 'Elementor requires WordPress version %s+. please update the WordPress version to import the template.', 'woofunnels-aero-checkout' ), '5.0' );

					return array( 'error' => $message );
				}
			}
			if ( $builder == 'divi' || $builder == 'divi5' ) {
				$response = WFACP_Common::check_builder_status( 'divi' );
				if ( ! empty( $response['error'] ) ) {
					$message = $response['error'];
				}

				return array( 'error' => $message );

			}

			return false;
		}

		/**
		 * @param $aero_id
		 * @param $builder
		 * @param $slug
		 *
		 * @return array||null
		 */
		public function export( $aero_id, $builder, $slug ) {
			if ( isset( self::$importer[ $builder ] ) && self::$importer[ $builder ] instanceof WFACP_Import_Export ) {
				$importer    = self::$importer[ $builder ];
				$export_data = $importer->export( $aero_id, $builder, $slug );

				return $export_data;
			}

			return null;
		}

		public function get_importer( $builder ) {
			if ( isset( self::$importer[ $builder ] ) && self::$importer[ $builder ] instanceof WFACP_Import_Export ) {
				return self::$importer[ $builder ];
			}

			return null;
		}

		public function get_domain() {
			global $sitepress;
			$domain = site_url();

			if ( isset( $sitepress ) && ! is_null( $sitepress ) ) {
				$default_language = $sitepress->get_default_language();
				$domain           = $sitepress->convert_url( $sitepress->get_wp_api()->get_home_url(), $default_language );
			}

			// Check if Polylang is active
			if ( function_exists( 'pll_default_language' ) && function_exists( 'pll_home_url' ) ) {
				// Get the default language
				$default_language = pll_default_language();
				// Get the home URL in the default language
				$domain = pll_home_url( $default_language );
			}

			/**
			 * Get woofunnels plugins data from the options
			 * consider multisite setups
			 */
			if ( is_multisite() ) {
				/**
				 * Check if sitewide installed, if yes then get the plugin info from primary site
				 */
				$active_plugins = get_site_option( 'active_sitewide_plugins', array() );

				if ( is_array( $active_plugins ) && defined( 'WFFN_PRO_PLUGIN_BASENAME' ) && ( in_array( WFFN_PRO_PLUGIN_BASENAME, apply_filters( 'active_plugins', $active_plugins ), true ) || array_key_exists( WFFN_PRO_PLUGIN_BASENAME, apply_filters( 'active_plugins', $active_plugins ) ) ) ) {
					$domain = get_site_url( get_network()->site_id );
				} elseif ( is_array( $active_plugins ) && in_array( WFACP_PLUGIN_BASENAME, apply_filters( 'active_plugins', $active_plugins ), true ) || array_key_exists( WFACP_PLUGIN_BASENAME, apply_filters( 'active_plugins', $active_plugins ) ) ) {
					$domain = get_site_url( get_network()->site_id );
				}
			}

			$domain = str_replace( array( 'https://', 'http://' ), '', $domain );
			$domain = trim( $domain, '/' );

			return $domain;
		}

		/**
		 * Import template remotely.
		 *
		 * @return mixed
		 */
		public function get_remote_template( $template_id, $builder ) {
			if ( empty( $template_id ) || empty( $builder ) ) {
				return '';
			}
			$funnel_step = 'wc_checkout';

			$safe_builder     = sanitize_file_name( $builder );
			$safe_template_id = sanitize_file_name( $template_id );

			$template_file_path = $safe_builder . '/' . $funnel_step . '/' . $safe_template_id;
			$defined_wffn       = defined( 'WFFN_TEMPLATE_UPLOAD_DIR' );
			$full_path          = WFFN_TEMPLATE_UPLOAD_DIR . $template_file_path . '.json';
			$file_exist         = ( $defined_wffn ) ? file_exists( $full_path ) : false;

			if ( $defined_wffn && $file_exist ) {
				$real_upload_dir = realpath( WFFN_TEMPLATE_UPLOAD_DIR );
				$real_file_path  = realpath( $full_path );
				if ( false === $real_upload_dir || false === $real_file_path || 0 !== strpos( $real_file_path, $real_upload_dir ) ) {
					return '';
				}
				$content = file_get_contents( $full_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents
				wp_delete_file( $full_path );

				return array(
					'success' => true,
					'data'    => $content,
				);
			}

			$license = $this->get_license_key();
			if ( empty( $license ) && class_exists( 'WFFN_Pro_Core' ) ) {
				$license = WFFN_Pro_Core()->support->get_license_key();
			}
			$requestBody = array(
				'step'            => $funnel_step,
				'domain'          => $this->get_domain(),
				'license'         => $license,
				'template'        => $template_id,
				'builder'         => $builder,
				'builder_version' => WFACP_Common::get_builder_version( $builder ),
				'version'         => 4,
				'locale'          => get_locale(),

			);

			if ( 'elementor' === $builder && class_exists( 'WFFN_Common' ) ) {
				$requestBody['elementor_container'] = WFFN_Common::is_elementor_container_active() ? 'active' : 'inactive';
			}

			$requestBody = wp_json_encode( $requestBody );

			$endpoint_url = $this->get_template_api_url();
			$response     = wp_remote_post(
				$endpoint_url,
				array(
					'body'    => $requestBody,
					'timeout' => 30,
					'headers' => array(
						'content-type' => 'application/json',
					),
				)
			);

			if ( $response instanceof WP_Error ) {
				return false;
			}

			$response = json_decode( $response['body'], true );
			if ( ! is_array( $response ) ) {
				return array( 'error' => __( 'Server Down', 'woofunnels-aero-checkout' ) );
			}

			if ( isset( $response['error'] ) ) {
				return array( 'error' => self::get_error_message( $response['error'] ) );
			}
			$checkout_data = $response[ $funnel_step ];

			if ( empty( $checkout_data ) ) {
				return array( 'error' => __( 'No Template found', 'woofunnels-aero-checkout' ) );
			}

			return array(
				'success' => true,
				'data'    => $checkout_data,
			);
		}

		/**
		 * Get license key.
		 *
		 * @return mixed
		 */
		public function get_license_key() {
			$licenseKey = false;

			/**
			 * Get woofunnels plugins data from the options
			 * consider multisite setups
			 */
			if ( is_multisite() ) {
				/**
				 * Check if sitewide installed, if yes then get the plugin info from primary site
				 */
				$active_plugins = get_site_option( 'active_sitewide_plugins', array() );

				if ( is_array( $active_plugins ) && in_array( WFACP_PLUGIN_BASENAME, apply_filters( 'active_plugins', $active_plugins ), true ) || array_key_exists( WFACP_PLUGIN_BASENAME, apply_filters( 'active_plugins', $active_plugins ) ) ) {
					$woofunnels_data = get_blog_option( get_network()->site_id, 'woofunnels_plugins_info', array() );
				} else {
					$woofunnels_data = get_option( 'woofunnels_plugins_info', array() );
				}
			} else {
				$woofunnels_data = get_option( 'woofunnels_plugins_info' );
			}
			if ( is_array( $woofunnels_data ) && count( $woofunnels_data ) > 0 ) {

				foreach ( $woofunnels_data as $key => $license ) {
					if ( is_array( $license ) && isset( $license['activated'] ) && $license['activated'] && $key === sha1( WFACP_PLUGIN_BASENAME ) ) {

						$licenseKey = $license['data_extra']['api_key'];
						break;
					}
				}
			}

			return $licenseKey;
		}

		public function get_software_title() {
			return WFACP_FULL_NAME;
		}

		public function get_template_api_url() {
			return 'http://gettemplates.funnelkit.com/';
		}

		public static function update_import_page_settings( $aero_id, $import_page_settings ) {
			if ( ! empty( $import_page_settings ) ) {
				$page_settings = WFACP_Common::get_page_settings( $aero_id );

				foreach ( $import_page_settings as $key => $setting ) {
					$page_settings[ $key ] = $import_page_settings[ $key ];
				}
				update_post_meta( $aero_id, '_wfacp_page_settings', $page_settings );
			}
		}
	}

	WFACP_Core::register( 'importer', WFACP_Template_Importer::get_instance() );
}
