<?php
defined( 'ABSPATH' ) || exit;

/**
 * Elementor template library local source.
 *
 * Elementor template library local source handler class is responsible for
 * handling local Elementor templates saved by the user locally on his site.
 *
 * @since 1.0.0
 */

if ( ! class_exists( 'WFACP_Oxy_Importer' ) ) {
	#[AllowDynamicProperties]
	class WFACP_Oxy_Importer {
		private $slug            = '';
		private $post_id         = 0;
		private $settings_file   = '';
		private $builder         = 'oxy';
		public $delete_page_meta = true;

		public function __construct() {
		}


		public function import( $aero_id, $slug, $is_multi = 'no' ) {//phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedParameter
			$this->slug    = $slug;
			$this->post_id = $aero_id;

			$this->update_product_switcher_settings();

			$templates = WFACP_Core()->template_loader->get_templates( $this->builder );
			if ( isset( $templates[ $slug ]['settings_file'] ) ) {
				$this->settings_file = $templates[ $slug ]['settings_file'];
			}

			if ( $templates[ $slug ] && isset( $templates[ $slug ]['build_from_scratch'] ) ) {
				update_post_meta( $aero_id, WFACP_Common::oxy_get_meta_prefix( 'ct_other_template' ), '-1' );
				$this->save_data( $aero_id );

				return array( 'status' => true );
			}

			$data = WFACP_Core()->importer->get_remote_template( $slug, 'oxy' );

			if ( isset( $data['error'] ) ) {
				return $data;
			}

			$content = $data['data'];
			require_once WFACP_PLUGIN_DIR . '/includes/class-wfacp-content-validator.php'; //phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingCustomConstant
			if ( ! empty( $content ) && ! WFACP_Content_Validator::contains_dangerous_tags( $content ) && ! WFACP_Content_Validator::contains_php_code( $content ) ) {
				$oxy_setting = get_post_meta( $aero_id, '_wfacp_post_id', true );
				if ( empty( $oxy_setting ) ) {
					$oxy_setting = array( 'max-width' => '' );
					update_post_meta( $aero_id, WFACP_Common::oxy_get_meta_prefix( 'ct_page_settings' ), $oxy_setting );
				}
				update_post_meta( $aero_id, WFACP_Common::oxy_get_meta_prefix( 'ct_other_template' ), '-1' );

				/* Translation for gutenburg  Start */

				$translation_list = WFACP_Common::get_translation_field_aero_checkout_domain();
				$translation_list = array_filter(
					$translation_list,
					function ( $key, $val ) {
						return ! ( $key === $val );
					},
					ARRAY_FILTER_USE_BOTH
				);

				foreach ( $translation_list as $key => $value ) {
					if ( false !== strpos( $content, $key ) ) {
						$content = str_replace( $key, $value, $content );
					}
				}

				$translation_list = WFACP_Common::get_translation_field_funnel_buider_domain();

				$translation_list = array_filter(
					$translation_list,
					function ( $key, $val ) {
						return ! ( $key === $val );
					},
					ARRAY_FILTER_USE_BOTH
				);

				foreach ( $translation_list as $key => $value ) {
					if ( false !== strpos( $content, $key ) ) {
						$content = str_replace( $key, $value, $content );
					}
				}

				/* End */

				/**
				 * Re-sign shortcodes with this site's oxygen_private_key (mirrors Oxygen's save flow).
				 *
				 * The helper keeps every element in the template intact; on a Lite version
				 * that predates it the import stays a plain passthrough, which is the
				 * behaviour Oxygen templates had before re-signing was introduced.
				 */
				if ( method_exists( 'WFFN_Common', 'oxy_resign_shortcodes' ) ) {
					$content = WFFN_Common::oxy_resign_shortcodes( $content );
				}

				// Write both prefixed and bare meta keys (oxy_get_meta_prefix may add an underscore).
				$meta_key = WFACP_Common::oxy_get_meta_prefix( 'ct_builder_shortcodes' );
				update_post_meta( $aero_id, $meta_key, $content );
				if ( 'ct_builder_shortcodes' !== $meta_key ) {
					update_post_meta( $aero_id, 'ct_builder_shortcodes', $content );
				}
				WFACP_Common::update_label_meta( $aero_id, $content );
				$this->clear_oxy_page_cache_css( $aero_id );
				$this->save_data( $this->post_id );

				return array( 'status' => true );
			}

			return array( 'status' => true );
		}


		public function update_product_switcher_settings() {
			if ( false !== strpos( $this->slug, 'oxy_' ) ) {
				$pageProductSetting = array(
					'coupons'                             => '',
					'enable_coupon'                       => 'false',
					'disable_coupon'                      => 'false',
					'hide_quantity_switcher'              => 'false',
					'enable_delete_item'                  => 'false',
					'hide_product_image'                  => 'false',
					'is_hide_additional_information'      => 'true',
					'additional_information_title'        => WFACP_Common::get_default_additional_information_title(),
					'hide_quick_view'                     => 'false',
					'hide_you_save'                       => 'true',
					'hide_best_value'                     => 'false',
					'best_value_product'                  => '',
					'best_value_text'                     => __( 'Best Value', 'woofunnels-aero-checkout' ),
					'best_value_position'                 => 'above',
					'enable_custom_name_in_order_summary' => 'false',
					'autocomplete_enable'                 => 'false',
					'autocomplete_google_key'             => '',
					'preferred_countries_enable'          => 'false',
					'preferred_countries'                 => '',
					'product_switcher_template'           => 'default',
				);

				$product_settings                     = array();
				$product_settings['settings']         = $pageProductSetting;
				$product_settings['products']         = array();
				$product_settings['default_products'] = array();
				if ( is_array( $product_settings ) && count( $product_settings ) > 0 ) {
					update_post_meta( $this->post_id, '_wfacp_product_switcher_setting', $product_settings );
				}
			}
		}

		private function save_data( $post_id, $content = '' ) {//phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedParameter
			if ( true === $this->delete_page_meta ) {
				$this->delete_template_data( $post_id );
			}

			if ( ! empty( $this->settings_file ) ) {
				$file_path = __DIR__ . '/checkout-settings/' . $this->settings_file;
				WFACP_Common::import_checkout_settings( $post_id, $file_path );
			}
		}

		private function delete_template_data( $post_id ) {
			WFACP_Common::delete_page_layout( $post_id );
		}

		public function clear_oxy_page_cache_css( $post_id ) {

			if ( function_exists( 'oxygen_vsb_cache_universal_css' ) && function_exists( 'oxygen_vsb_delete_css_file' ) && get_option( 'oxygen_vsb_universal_css_cache' ) == 'true' ) {
				/**
				 * generate universal css when oxygen cache setting is enabled and delete previous css
				 */
				oxygen_vsb_delete_css_file( $post_id );
				oxygen_vsb_cache_universal_css();
			} elseif ( function_exists( 'oxygen_vsb_cache_page_css' ) ) {

				/**
				 * generate oxygen css
				 */
				oxygen_vsb_cache_page_css( $post_id );
			}
		}
	}

	if ( class_exists( 'WFACP_Template_Importer' ) ) {

		WFACP_Template_Importer::register( 'oxy', new WFACP_OXY_Importer() );
	}
}
