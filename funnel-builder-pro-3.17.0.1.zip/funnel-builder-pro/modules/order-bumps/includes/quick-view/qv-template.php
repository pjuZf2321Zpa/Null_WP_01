<?php

/**
 * ========================
 * Quick View Template
 * ========================
 **/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	return;
}
global $product;

/**
 * Silence the third-party single-product furniture BEFORE this file registers anything of its own.
 *
 * The quick view renders real WooCommerce add-to-cart templates, so every plugin that decorates a
 * product page renders into the bump's modal too — see WFOB_Public::get_quick_view_suppressed_hooks()
 * for what is lifted and why the in-form hooks are left alone. Restored at the bottom of this file;
 * the ordering matters, because the add_action() calls below target two of the same hooks and must
 * survive.
 */
WFOB_Core()->public->suppress_quick_view_hooks();

add_action( 'wfob_qv_summary', 'woocommerce_template_single_title', 5 );
add_action(
	'wfob_qv_summary',
	function () {
		echo '<div class=wfob_qv_title_wrap>';
		echo '<div class="wfob_qv-close wfob_qv"></div>';
	},
	4
);
add_action(
	'wfob_qv_summary',
	function () {
		echo '</div>';
	},
	6
);
// add_action( 'wfob_qv_summary', 'woocommerce_template_single_rating', 10 );
add_action( 'wfob_qv_summary', 'woocommerce_template_single_price', 10 );
// add_action( 'wfacp_before_button', 'woocommerce_template_single_excerpt', 20 );
add_action( 'wfob_qv_summary', array( WFOB_Core()->public, 'woocommerce_template_single_add_to_cart' ), 25 );


remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
add_action( 'wfob_woocommerce_simple_add_to_cart', array( WFOB_Core()->public, 'woocommerce_simple_add_to_cart' ) );
add_action( 'woocommerce_single_variation', array( WFOB_Core()->public, 'woocommerce_single_variation_add_to_cart_button' ), 20 );
add_action(
	'woocommerce_before_add_to_cart_form',
	function () {
		global $product;
		if ( ! $product instanceof WC_Product ) {
			return;
		}
		$cart_key = $product->get_meta( 'wfob_cart_key', true );
		if ( ! empty( $cart_key ) ) {
			$item = WC()->cart->get_cart_item( $cart_key );
			if ( isset( $item['wfob_variable_attributes'] ) ) {
				foreach ( $item['wfob_variable_attributes'] as $a_name => $a_val ) {
					$_REQUEST[ $a_name ] = $a_val;
				}
			}
		}
	}
);
add_action(
	'wfob_qv_images',
	function () {
		include_once __DIR__ . '/images/product-image.php';
	},
	20
);


global $wfob_product;

if ( ! is_null( $wfob_product ) ) {
	add_action( 'wfob_woocommerce_variable_add_to_cart', array( WFOB_Core()->public, 'woocommerce_simple_add_to_cart' ) );
	add_action( 'wfob_woocommerce_variable-subscription_add_to_cart', array( WFOB_Core()->public, 'woocommerce_subscription_add_to_cart' ) );

} else {
	add_action( 'wfob_woocommerce_variable_add_to_cart', array( WFOB_Core()->public, 'woocommerce_variable_add_to_cart' ) );
	add_action( 'wfob_woocommerce_variable-subscription_add_to_cart', array( WFOB_Core()->public, 'woocommerce_variable_subscription_add_to_cart' ) );
}
add_filter(
	'woocommerce_single_product_flexslider_enabled',
	function () {
		return true;
	}
);

add_action(
	'woocommerce_before_variations_form',
	function () {
		global $wfob_item_data;
		echo "<input type='hidden' value='" . esc_attr( $wfob_item_data['item_key'] ) . "' name='wfob_item_key' class='wfob_quick_view_item_key'>";
	}
);
add_action(
	'woocommerce_before_add_to_cart_button',
	function () {
		global $wfob_item_data;
		echo "<input type='hidden' value='" . esc_attr( $wfob_item_data['item_key'] ) . "' name='wfob_item_key'  class='wfob_quick_view_item_key'>";
	}
);
?>

<div id="wfob_qr_model_wrap" class="wfob_qv-inner-modal" data-item-key="<?php echo esc_attr( $item_key ); ?>" data-cart-key="<?php echo esc_attr( $cart_key ); ?>">
	<div class="wfob_qv-container1 woocommerce single-product">
		<div class="wfob_qv-top-panel">

			<div class="wfob_qv-preloader wfob_qv-mpl">
				<div class="wfob_qv-speeding-wheel"></div>
			</div>
		</div>
		<div class="wfob_qv-main1">
			<div id="product-<?php echo $product->get_id(); ?>" <?php post_class( 'product wfob_qv_sec' ); ?>>
				<div class="wfob_qr_wrap">
					<div class="wfob_qv-images">
						<?php do_action( 'wfob_qv_images' ); ?>
					</div>
					<div class="wfob_qv-summary">

						<?php
						/**
						 * @todo
						 * Using our custom hook display only few content
						 * some themes like flatsome changes the normal behaviour of components
						 */
						?>
						<?php do_action( 'wfob_qv_summary' ); ?>
					</div>

					<div class="wfob_clear"></div>
				</div>
			</div>

		</div>

	</div>
	<div class="wfob_option_btn"><?php _e( 'Choose an option', 'woocommerce' ); ?></div>
</div>

<?php
/* The modal markup is built — hand the furniture hooks back the way we found them. */
WFOB_Core()->public->restore_quick_view_hooks();