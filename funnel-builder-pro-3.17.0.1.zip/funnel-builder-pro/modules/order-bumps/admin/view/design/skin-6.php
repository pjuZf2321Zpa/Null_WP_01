<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


?>

<div class="wfob_bump_r_outer_wrap wfob_layout_6" v-if="selected_layout=='layout_6'">
	<div v-bind:class="get_wrapper_class('<?php echo esc_attr( $product_key ); ?>','wfob_wrapper wfob_bump wfob_clear')">
		<div class="wfob_outer">
			<div class="wfob_Box wfob_skin_wrap">
				<div class="wfob_contentBox wfob_clear">

					<div class="wfob_pro_img_wrap" v-if="true==enable_featured_image('<?php echo esc_attr( $product_key ); ?>') && 'left'==get_featured_image_position('<?php echo esc_attr( $product_key ); ?>')" v-bind:style="get_image_width('<?php echo esc_attr( $product_key ); ?>')">
						<?php require __DIR__ . '/skin-product-image.php'; ?>
					</div>
					<div class="wfob_pro_txt_wrap">


						<div class="wfob_bgBox_table">
							<div class="wfob_bgBox_tablecell wfob_check_container">
								<label for="" class="wfob_title" v-html="<?php echo 'model.product_' . esc_attr( $product_key ) . '_title'; ?>"></label>
								<input type="checkbox" id="<?php echo esc_attr( $product_key ); ?>" data-value="" class="wfob_checkbox wfob_bump_product wfob-switch">
								<label for="<?php echo esc_attr( $product_key ); ?>"><span class="sw"></span></label>
							</div>
						</div>

						<div class="wfob_l3_l_desc" v-html="get_product_description('<?php echo esc_attr( $product_key ); ?>')"></div>


						<div class="wfob_bgBox_tablecell wfob_price_container" v-if="model.enable_price=='1'">
							<div class="wfob_price">
								<?php

								if ( in_array( $wc_product->get_type(), WFOB_Common::get_subscription_product_type() ) ) {
									$subs_price = WFOB_Common::get_subscription_price( $wc_product, $price_data );
									echo wc_price( $subs_price );
								} elseif ( ( round( $price_data['price'], 2 ) !== round( $price_data['regular_org'], 2 ) ) ) {
										echo wc_format_sale_price( $price_data['regular_org'], $price_data['price'] );
								} else {
									echo wc_price( $price_data['price'] );
								}


								?>
							</div>
						</div>


						<?php
						if ( isset( $data['variable'] ) ) {
							printf( "<a href='#' class='wfob_qv-button var_product' qv-id='%d' qv-var-id='%d'>%s</a>", 0, 0, __( 'Choose an option', 'woocommerce' ) );
						}
						?>

					</div>

					<div class="wfob_pro_img_wrap" v-if="true==enable_featured_image('<?php echo esc_attr( $product_key ); ?>') && 'right'==get_featured_image_position('<?php echo esc_attr( $product_key ); ?>')" v-bind:style="get_image_width('<?php echo esc_attr( $product_key ); ?>')">
						<?php require __DIR__ . '/skin-product-image.php'; ?>

					</div>


				</div>
			</div>
		</div>
	</div>
</div>
