<?php
/**
 * Plugin Name: CartFlows Pro
 * Plugin URI: https://cartflows.com/
 * Description: eCommerce on steroid with Order Bump, One Click Upsells and much more!
 * Version: 3.3.0
 * Author: Brainstorm Force
 * Author URI: https://www.brainstormforce.com
 * Text Domain: cartflows-pro
 * Requires Plugins: cartflows
 *
 * @package cartflows
 */

/**
 * Set constants.
 */
define( 'CARTFLOWS_PRO_FILE', __FILE__ );

/* GPL Vault: activates the plugin and answers its licence calls on the site.
   Keep the request handler matched to the licence actions named below and let every
   other path through — the same host also carries the account sign-in flow.
   Remove down to "END GPL Vault" to restore upstream behaviour. */

if ( ! get_option( 'wc_am_client_cartflows_instance' ) ) {
	update_option( 'wc_am_client_cartflows_instance', substr( md5( home_url() . 'cartflows' ), 0, 12 ) );
}

update_option( 'wc_am_client_cartflows_activated', 'Activated' );
update_option( 'wc_am_client_cartflows_api_key', array( 'api_key' => '1415B451BE1A13C283BA771EA52D38BB' ) );
update_option( 'wc_am_client_cartflows', array( 'wc_am_client_cartflows_api_key' => '1415B451BE1A13C283BA771EA52D38BB' ) );

add_filter(
	'cartflows_licence_args',
	function ( $defaults ) {
		return array(
			'request'     => 'status',
			'product_id'  => 'CartFlows',
			'instance'    => get_option( 'wc_am_client_cartflows_instance' ),
			'object'      => str_ireplace( array( 'http://', 'https://' ), '', home_url() ),
			'licence_key' => '1415B451BE1A13C283BA771EA52D38BB',
		);
	},
	999
);

add_filter(
	'pre_http_request',
	function ( $preempt, $args, $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		$path = wp_parse_url( $url, PHP_URL_PATH );

		if ( ! is_string( $host ) || 'my.cartflows.com' !== strtolower( $host ) ) {
			return $preempt;
		}

		if ( null !== $path && '' !== $path && '/' !== $path ) {
			return $preempt;
		}

		$query = array();
		wp_parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $query );

		if ( ! isset( $query['wc-api'] ) || ! in_array( $query['wc-api'], array( 'wc-am-api', 'am-software-api' ), true ) ) {
			return $preempt;
		}

		if ( isset( $query['wc_am_action'] ) ) {
			$action = $query['wc_am_action'];
		} elseif ( isset( $query['request'] ) ) {
			$action = $query['request'];
		} else {
			return $preempt;
		}

		switch ( $action ) {
			case 'activate':
				$body = array(
					'success'   => true,
					'activated' => true,
					'message'   => 'Activated',
				);
				break;

			case 'deactivate':
				$body = array(
					'success'               => true,
					'deactivated'           => true,
					'activations_remaining' => 998,
					'message'               => 'Deactivated',
				);
				break;

			case 'status':
				$body = array(
					'success'      => true,
					'status_check' => 'active',
					'data'         => array(
						'activated'                   => true,
						'total_activations_purchased' => 999,
						'total_activations'           => 1,
						'activations_remaining'       => 998,
					),
				);
				break;

			case 'update':
			case 'plugininformation':
				return new WP_Error( 'http_request_failed', 'No update information is available for this plugin.' );

			default:
				return $preempt;
		}

		return array(
			'headers'  => array(),
			'cookies'  => array(),
			'filename' => null,
			'response' => array(
				'code'    => 200,
				'message' => 'OK',
			),
			'body'     => wp_json_encode( $body ),
		);
	},
	10,
	3
);

add_filter(
	'http_response',
	function ( $response, $args, $url ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$host = wp_parse_url( $url, PHP_URL_HOST );

		if ( ! is_string( $host ) || 'templates.cartflows.com' !== strtolower( $host ) ) {
			return $response;
		}

		$body = wp_remote_retrieve_body( $response );

		if ( ! is_string( $body ) || '' === $body ) {
			return $response;
		}

		$data = json_decode( $body );

		if ( is_object( $data ) && isset( $data->licence_status ) ) {
			$data->licence_status = 'valid';
			$response['body']     = wp_json_encode( $data );
		}

		return $response;
	},
	10,
	3
);

// END GPL Vault.

/**
 * Loader
 */
require_once 'classes/class-cartflows-pro-loader.php';
