<?php
/**
 * CartFlows Pro — Abilities API Loader
 *
 * Bootstraps the WordPress Abilities API integration for CartFlows Pro.
 * Gracefully degrades when the Abilities API (WordPress 6.9+) is not available.
 *
 * @package cartflows-pro
 * @since   2.2.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// -------------------------------------------------------
// Constants
// -------------------------------------------------------

if ( ! defined( 'CARTFLOWS_PRO_ABILITY_API' ) ) {
	/**
	 * Indicates CartFlows Pro has Abilities API support compiled in.
	 *
	 * @since 2.2.2
	 */
	define( 'CARTFLOWS_PRO_ABILITY_API', true );
}

if ( ! defined( 'CARTFLOWS_PRO_ABILITY_API_NAMESPACE' ) ) {
	/**
	 * Namespace prefix used for all CartFlows Pro ability names.
	 *
	 * @since 2.2.2
	 */
	define( 'CARTFLOWS_PRO_ABILITY_API_NAMESPACE', 'cartflows-pro/' );
}

// -------------------------------------------------------
// Guard — only proceed when the Abilities API is available
// -------------------------------------------------------

if ( ! function_exists( 'wp_register_ability' ) || ! class_exists( 'WP_Ability' ) ) {
	// WordPress < 6.9 — abilities system not present; plugin continues normally.
	return;
}

// -------------------------------------------------------
// Load ability classes
// -------------------------------------------------------

require_once CARTFLOWS_PRO_DIR . 'abilities/class-cartflows-pro-ability-runtime.php';
require_once CARTFLOWS_PRO_DIR . 'abilities/class-cartflows-pro-ability-config.php';

// -------------------------------------------------------
// Wire hooks
// -------------------------------------------------------

/**
 * Register CartFlows Pro ability category.
 *
 * Fires on wp_abilities_api_categories_init — before abilities are registered.
 *
 * @since 2.2.2
 */
add_action(
	'wp_abilities_api_categories_init',
	function () {
		$runtime = new Cartflows_Pro_Ability_Runtime();
		$runtime->register_categories();
	}
);

/**
 * Register all CartFlows Pro abilities.
 *
 * Fires on wp_abilities_api_init — after categories are registered.
 *
 * @since 2.2.2
 */
add_action(
	'wp_abilities_api_init',
	function () {
		$runtime = new Cartflows_Pro_Ability_Runtime();
		$runtime->register();
	}
);
