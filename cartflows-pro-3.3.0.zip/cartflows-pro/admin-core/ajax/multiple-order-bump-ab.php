<?php
/**
 * Order Bump A/B Split Test — AJAX controller.
 *
 * Implements the 10 locked AJAX actions for CF-1154 Phase 2. Replaces the Phase 1
 * stub file (multiple-order-bump-ab-stubs.php). Every handler is a single
 * read-modify-write of the wcf-order-bumps postmeta on the checkout step.
 *
 * @since 3.1.3
 * @package CartFlowsPro
 */

namespace CartflowsProAdmin\AdminCore\Ajax;

// Direct file access guard.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use CartflowsProAdmin\AdminCore\Inc\AdminHelper;

/**
 * Class MultipleOrderBumpAb.
 *
 * Each public method matches a wp_ajax_cartflows_pro_<method> action registered
 * by AjaxBase::init_ajax_events(). All writes go through the helpers at the
 * bottom of this file so the read-modify-write pattern and CSS cache bust stay
 * consistent across all 10 endpoints.
 *
 * @since 3.1.3
 */
class MultipleOrderBumpAb extends AjaxBase {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register the 10 A/B AJAX actions so AjaxBase wires up wp_ajax_* hooks + nonces.
	 *
	 * @return void
	 */
	public function register_ajax_events() {
		// One entry per locked AJAX action (report.html §5 mapping table).
		$ajax_events = array(
			'create_order_bump_variation',
			'clone_order_bump_variation',
			'start_order_bump_ab_test',
			'pause_order_bump_ab_test',
			'save_order_bump_ab_traffic',
			'archive_order_bump_variation',
			'delete_order_bump_variation',
			'declare_order_bump_ab_winner',
			'restore_archive_order_bump_variation',
			'delete_archive_order_bump_variation',
		);
		// Base class adds the wp_ajax_* hooks and localises the nonces onto cartflows_admin_localized_vars.
		$this->init_ajax_events( $ajax_events );
	}

	// ----------------------------------------------------------------------
	// Public AJAX handlers
	// ----------------------------------------------------------------------

	/**
	 * Turn a plain bump into the control of a new A/B test + seed first variant from the control's payload.
	 *
	 * @return void
	 */
	public function create_order_bump_variation() {
		// Common guard returns the validated step id; bail-out responses live inside the helper.
		$step_id = $this->guard( 'create_order_bump_variation' );
		// The plain bump that becomes the control is identified by ob_id in the POST payload.
		$control_ob_id = $this->post_string( 'ob_id' );
		if ( '' === $control_ob_id ) {
			$this->fail( 'no-post-data' );
		}
		// Read + write happens in one place so the CSS cache bust and JSON response stay consistent.
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $control_ob_id ) {
				// Locate the bump that will be promoted to control.
				$control_idx = $this->find_index( $bumps, $control_ob_id );
				if ( null === $control_idx ) {
					return null;
				}
				// Build the variant payload by cloning the control entry's fields verbatim.
				$variant_id            = $this->generate_id( $this->collect_ids( $bumps ) );
				$variant_payload       = $bumps[ $control_idx ];
				$variant_payload['id'] = $variant_id;
				// Suffix the title so admins can tell the variant apart at a glance.
				$variant_payload['title'] = $variant_payload['title'] . __( ' Variant', 'cartflows-pro' );
				// Variant links back to its control via wcf-control-ob and joins the same A/B test.
				$variant_payload['wcf-control-ob'] = $control_ob_id;
				$variant_payload['ab-test']        = true;
				// Reset variant's own A/B-state fields so it does not look like another control.
				$variant_payload['ab-test-start']               = false;
				$variant_payload['ab-test-ui']                  = false;
				$variant_payload['ab-test-variations']          = array();
				$variant_payload['ab-test-archived-variations'] = array();
				$variant_payload['ab-winner-ob']                = '';
				$variant_payload['wcf-winner-ob']               = '';
				// Stamp the control entry with the A/B group state and the 50/50 traffic split.
				$bumps[ $control_idx ]['ab-test']            = true;
				$bumps[ $control_idx ]['ab-test-start']      = false;
				$bumps[ $control_idx ]['ab-test-ui']         = true;
				$bumps[ $control_idx ]['ab-test-variations'] = array(
					array(
						'id'      => $control_ob_id,
						'traffic' => 50,
					),
					array(
						'id'      => $variant_id,
						'traffic' => 50,
					),
				);
				// Append the new variant entry to the wcf-order-bumps array.
				array_push( $bumps, $variant_payload );
				return $bumps;
			}
		);
	}

	/**
	 * Clone an existing variant within the same A/B group (traffic=0 for the newcomer).
	 *
	 * @return void
	 */
	public function clone_order_bump_variation() {
		$step_id       = $this->guard( 'clone_order_bump_variation' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		$source_ob_id  = $this->post_string( 'source_ob_id' );
		if ( '' === $control_ob_id || '' === $source_ob_id ) {
			$this->fail( 'no-post-data' );
		}
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $control_ob_id, $source_ob_id ) {
				// Locate the source variant/control we are cloning from.
				$source_idx = $this->find_index( $bumps, $source_ob_id );
				if ( null === $source_idx ) {
					return null;
				}
				// Locate the control entry where ab-test-variations lives.
				$control_idx = $this->find_index( $bumps, $control_ob_id );
				if ( null === $control_idx ) {
					return null;
				}
				// Generate a fresh id and build the new variant payload from the source's data.
				$new_id            = $this->generate_id( $this->collect_ids( $bumps ) );
				$payload           = $bumps[ $source_idx ];
				$payload['id']     = $new_id;
				$payload['title']  = $payload['title'] . __( ' Clone', 'cartflows-pro' );
				$payload['status'] = false;
				// Variant linkage is always to the SAME control as the source, never to the source itself.
				$payload['wcf-control-ob'] = $control_ob_id;
				$payload['ab-test']        = true;
				// Reset transient A/B-state fields that should not propagate to the clone.
				$payload['ab-test-start']               = false;
				$payload['ab-test-ui']                  = false;
				$payload['ab-test-variations']          = array();
				$payload['ab-test-archived-variations'] = array();
				$payload['ab-winner-ob']                = '';
				$payload['wcf-winner-ob']               = '';
				// Append to wcf-order-bumps.
				array_push( $bumps, $payload );
				// Register the variant in the control's variations list with traffic=0 (admin will rebalance later).
				$variations                                  = isset( $bumps[ $control_idx ]['ab-test-variations'] ) ? (array) $bumps[ $control_idx ]['ab-test-variations'] : array();
				$variations[]                                = array(
					'id'      => $new_id,
					'traffic' => 0,
				);
				$bumps[ $control_idx ]['ab-test-variations'] = $variations;
				return $bumps;
			}
		);
	}

	/**
	 * Flip ab-test-start = true on the control entry to start the running test.
	 *
	 * @return void
	 */
	public function start_order_bump_ab_test() {
		$step_id       = $this->guard( 'start_order_bump_ab_test' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		if ( '' === $control_ob_id ) {
			$this->fail( 'no-post-data' );
		}
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $control_ob_id ) {
				$idx = $this->find_index( $bumps, $control_ob_id );
				if ( null === $idx ) {
					return null;
				}
				// Single boolean flip — frontend will start splitting traffic on the next visit.
				$bumps[ $idx ]['ab-test-start'] = true;
				return $bumps;
			}
		);
	}

	/**
	 * Flip ab-test-start = false on the control entry to pause the running test.
	 *
	 * @return void
	 */
	public function pause_order_bump_ab_test() {
		$step_id       = $this->guard( 'pause_order_bump_ab_test' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		if ( '' === $control_ob_id ) {
			$this->fail( 'no-post-data' );
		}
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $control_ob_id ) {
				$idx = $this->find_index( $bumps, $control_ob_id );
				if ( null === $idx ) {
					return null;
				}
				// Single boolean flip — frontend will stop honouring the cookie's assigned variant.
				$bumps[ $idx ]['ab-test-start'] = false;
				return $bumps;
			}
		);
	}

	/**
	 * Save the rebalanced traffic % per variation. Sum must equal 100.
	 *
	 * @return void
	 */
	public function save_order_bump_ab_traffic() {
		$step_id       = $this->guard( 'save_order_bump_ab_traffic' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		// variations arrives as a JSON-encoded array of {id, traffic}.
		// Nonce + capability validated in guard() above; sanitisation happens per-field on the decoded payload.
		$raw_variations = isset( $_POST['variations'] ) ? wp_unslash( $_POST['variations'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( '' === $control_ob_id || '' === $raw_variations || ! is_string( $raw_variations ) ) {
			$this->fail( 'no-post-data' );
		}
		// Decode + shape-check the variations payload before writing.
		$decoded = json_decode( $raw_variations, true );
		if ( ! is_array( $decoded ) || 0 === count( $decoded ) ) {
			$this->fail( 'no-post-data' );
		}
		// Re-build a sanitised variations array so nothing arbitrary is persisted.
		$sanitised = array();
		$total     = 0;
		// At this point $decoded is guaranteed to be an array (checked above) — coerce for PHPStan's flow analysis.
		$decoded_arr = (array) $decoded;
		foreach ( $decoded_arr as $entry ) {
			if ( ! is_array( $entry ) || empty( $entry['id'] ) ) {
				continue;
			}
			$traffic     = isset( $entry['traffic'] ) ? max( 0, min( 100, intval( $entry['traffic'] ) ) ) : 0;
			$sanitised[] = array(
				'id'      => sanitize_text_field( (string) $entry['id'] ),
				'traffic' => $traffic,
			);
			$total      += $traffic;
		}
		// Reject if the admin sent a sum that does not equal 100 — auto-balance hook should prevent this client-side.
		if ( 100 !== $total ) {
			wp_send_json_error( array( 'message' => __( 'Traffic must sum to 100%.', 'cartflows-pro' ) ) );
		}
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $control_ob_id, $sanitised ) {
				$idx = $this->find_index( $bumps, $control_ob_id );
				if ( null === $idx ) {
					return null;
				}
				$bumps[ $idx ]['ab-test-variations'] = $sanitised;
				return $bumps;
			}
		);
	}

	/**
	 * Move a variant payload into ab-test-archived-variations and remove it from the active list.
	 *
	 * @return void
	 */
	public function archive_order_bump_variation() {
		$step_id       = $this->guard( 'archive_order_bump_variation' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		$ob_id         = $this->post_string( 'ob_id' );
		if ( '' === $control_ob_id || '' === $ob_id ) {
			$this->fail( 'no-post-data' );
		}
		// Variants cannot archive the control — that would end the test; caller should declare a winner instead.
		if ( $control_ob_id === $ob_id ) {
			wp_send_json_error( array( 'message' => __( 'Cannot archive the control bump.', 'cartflows-pro' ) ) );
		}
		// Archive is a soft removal — `false` keeps the archived entry recoverable via restore. Delete passes `true`.
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $step_id, $control_ob_id, $ob_id ) {
				return $this->delete_variation( $bumps, $control_ob_id, $ob_id, false, $step_id );
			}
		);
	}

	/**
	 * Hard-remove a variant from wcf-order-bumps. If the deleted entry was the control, promote next variant.
	 *
	 * @return void
	 */
	public function delete_order_bump_variation() {
		$step_id       = $this->guard( 'delete_order_bump_variation' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		$ob_id         = $this->post_string( 'ob_id' );
		if ( '' === $control_ob_id || '' === $ob_id ) {
			$this->fail( 'no-post-data' );
		}
		// Delete is a hard removal — `true` flags the archived entry so restore-archived will treat it accordingly.
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $step_id, $control_ob_id, $ob_id ) {
				return $this->delete_variation( $bumps, $control_ob_id, $ob_id, true, $step_id );
			}
		);
	}

	/**
	 * Promote the winner and end the A/B test. Losers move into the winner's archived list.
	 *
	 * @return void
	 */
	public function declare_order_bump_ab_winner() {
		$step_id       = $this->guard( 'declare_order_bump_ab_winner' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		$winner_ob_id  = $this->post_string( 'winner_ob_id' );
		if ( '' === $control_ob_id || '' === $winner_ob_id ) {
			$this->fail( 'no-post-data' );
		}
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $step_id, $control_ob_id, $winner_ob_id ) {
				$control_idx = $this->find_index( $bumps, $control_ob_id );
				$winner_idx  = $this->find_index( $bumps, $winner_ob_id );
				if ( null === $control_idx || null === $winner_idx ) {
					return null;
				}
				// Carry the control's existing archived list across to the winner (if winner differs from control).
				$archived_carry = isset( $bumps[ $control_idx ]['ab-test-archived-variations'] ) ? (array) $bumps[ $control_idx ]['ab-test-archived-variations'] : array();
				// Collect every other A/B-test participant (current control + variants) — they become losers.
				$participant_ids   = array( $control_ob_id );
				$active_variations = isset( $bumps[ $control_idx ]['ab-test-variations'] ) ? (array) $bumps[ $control_idx ]['ab-test-variations'] : array();
				foreach ( $active_variations as $v ) {
					if ( ! empty( $v['id'] ) && ! in_array( $v['id'], $participant_ids, true ) ) {
						$participant_ids[] = $v['id'];
					}
				}
				// Archive every loser — push_archive_entry stamps wcf-winner-ob on each snapshot itself.
				foreach ( $participant_ids as $pid ) {
					if ( $pid === $winner_ob_id ) {
						continue;
					}
					$p_idx = $this->find_index( $bumps, $pid );
					if ( null !== $p_idx ) {
						$archived_carry = $this->push_archive_entry( $archived_carry, $bumps[ $p_idx ], false, $winner_ob_id, $step_id );
					}
				}
				// Clear A/B state on the winner so it survives as a plain bump after the test ends.
				$bumps[ $winner_idx ]['ab-test']                     = false;
				$bumps[ $winner_idx ]['ab-test-start']               = false;
				$bumps[ $winner_idx ]['ab-test-ui']                  = false;
				$bumps[ $winner_idx ]['ab-test-variations']          = array();
				$bumps[ $winner_idx ]['wcf-control-ob']              = '';
				$bumps[ $winner_idx ]['wcf-winner-ob']               = '';
				$bumps[ $winner_idx ]['ab-winner-ob']                = $winner_ob_id;
				$bumps[ $winner_idx ]['ab-test-archived-variations'] = $archived_carry;
				// Remove every loser entry from wcf-order-bumps; the winner is the only survivor.
				$survivors = array();
				foreach ( $bumps as $entry ) {
					if ( ! empty( $entry['id'] ) && $entry['id'] === $winner_ob_id ) {
						$survivors[] = $entry;
						continue;
					}
					if ( ! empty( $entry['id'] ) && in_array( $entry['id'], $participant_ids, true ) ) {
						continue;
					}
					$survivors[] = $entry;
				}
				return array_values( $survivors );
			}
		);
	}

	/**
	 * Pull an archived variation back into the active variations list.
	 *
	 * @return void
	 */
	public function restore_archive_order_bump_variation() {
		$step_id       = $this->guard( 'restore_archive_order_bump_variation' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		$ob_id         = $this->post_string( 'ob_id' );
		if ( '' === $control_ob_id || '' === $ob_id ) {
			$this->fail( 'no-post-data' );
		}
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $control_ob_id, $ob_id ) {
				$control_idx = $this->find_index( $bumps, $control_ob_id );
				if ( null === $control_idx ) {
					return null;
				}
				$archived = isset( $bumps[ $control_idx ]['ab-test-archived-variations'] ) ? (array) $bumps[ $control_idx ]['ab-test-archived-variations'] : array();
				// Locate the archived entry to restore.
				$archive_entry = null;
				foreach ( $archived as $a_idx => $a ) {
					if ( ! empty( $a['id'] ) && $a['id'] === $ob_id ) {
						$archive_entry = $a;
						unset( $archived[ $a_idx ] );
						break;
					}
				}
				if ( null === $archive_entry ) {
					return null;
				}
				// Rebuild a usable bump entry from the archived payload — defaults fill the gaps. Global namespace class.
				$default_meta = \Cartflows_Pro_Order_Bump_Meta::get_instance()->get_default_meta();
				$defaults     = array();
				foreach ( $default_meta as $key => $info ) {
					$defaults[ $key ] = isset( $info['default'] ) ? $info['default'] : '';
				}
				$restored                   = array_merge( $defaults, isset( $archive_entry['payload'] ) && is_array( $archive_entry['payload'] ) ? $archive_entry['payload'] : array() );
				$restored['id']             = $ob_id;
				$restored['wcf-control-ob'] = $control_ob_id;
				$restored['ab-test']        = true;
				$restored['ab-test-start']  = false;
				$restored['ab-test-ui']     = false;
				$restored['wcf-winner-ob']  = '';
				$restored['title']          = isset( $archive_entry['title'] ) ? (string) $archive_entry['title'] : ( $restored['title'] ?? '' );
				$bumps[]                    = $restored;
				// Add the variant back to the active variations list with traffic=0 (admin will rebalance).
				$variations                                  = isset( $bumps[ $control_idx ]['ab-test-variations'] ) ? (array) $bumps[ $control_idx ]['ab-test-variations'] : array();
				$variations[]                                = array(
					'id'      => $ob_id,
					'traffic' => 0,
				);
				$bumps[ $control_idx ]['ab-test-variations'] = $variations;
				$bumps[ $control_idx ]['ab-test-archived-variations'] = array_values( $archived );
				return $bumps;
			}
		);
	}

	/**
	 * Hard-remove an entry from ab-test-archived-variations (no restore possible afterwards).
	 *
	 * @return void
	 */
	public function delete_archive_order_bump_variation() {
		$step_id       = $this->guard( 'delete_archive_order_bump_variation' );
		$control_ob_id = $this->post_string( 'control_ob_id' );
		$ob_id         = $this->post_string( 'ob_id' );
		if ( '' === $control_ob_id || '' === $ob_id ) {
			$this->fail( 'no-post-data' );
		}
		$this->mutate(
			$step_id,
			function ( $bumps ) use ( $control_ob_id, $ob_id ) {
				$control_idx = $this->find_index( $bumps, $control_ob_id );
				if ( null === $control_idx ) {
					return null;
				}
				$archived = isset( $bumps[ $control_idx ]['ab-test-archived-variations'] ) ? (array) $bumps[ $control_idx ]['ab-test-archived-variations'] : array();
				$filtered = array();
				foreach ( $archived as $a ) {
					if ( ! empty( $a['id'] ) && $a['id'] === $ob_id ) {
						continue;
					}
					$filtered[] = $a;
				}
				$bumps[ $control_idx ]['ab-test-archived-variations'] = $filtered;
				return $bumps;
			}
		);
	}

	// ----------------------------------------------------------------------
	// Private helpers — keep every handler small and consistent.
	// ----------------------------------------------------------------------

	/**
	 * Shared request guard — capability + nonce + step_id sanitisation.
	 *
	 * @param string $action Action slug used to derive the nonce key.
	 * @return int Validated step post id; never returns 0 because guard exits on failure.
	 */
	private function guard( $action ) {
		// Capability gate — same check used everywhere else in the OB feature.
		if ( ! current_user_can( 'cartflows_manage_flows_steps' ) ) {
			$this->fail( 'permission' );
		}
		// Nonce gate — AjaxBase already created the nonce keyed `cartflows_pro_<action>`.
		if ( ! check_ajax_referer( 'cartflows_pro_' . $action, 'security', false ) ) {
			$this->fail( 'nonce' );
		}
		// Step id is the only input shared by every A/B action.
		$step_id = isset( $_POST['step_id'] ) ? intval( wp_unslash( $_POST['step_id'] ) ) : 0;
		if ( $step_id <= 0 ) {
			$this->fail( 'no-post-data' );
		}
		// Post type gate — MultipleOrderBump checks this on every one of its handlers.
		// Without it these ten actions write wcf-order-bumps meta onto any post id.
		if ( CARTFLOWS_STEP_POST_TYPE !== get_post_type( $step_id ) ) {
			$this->fail( 'no-post-data' );
		}
		return $step_id;
	}

	/**
	 * Read wcf-order-bumps, hand it to $mutator, write the result, bust the dynamic CSS cache, respond.
	 *
	 * The mutator receives the current bumps array and returns the new one. Returning null means "no
	 * change — abort with a generic failure" so handler code can use null as an early-out signal.
	 *
	 * @param int      $step_id Step post id.
	 * @param callable $mutator Function( array $bumps ): ?array.
	 * @return void
	 */
	private function mutate( $step_id, $mutator ) {
		// Read current state — empty array is a valid starting point.
		$bumps = get_post_meta( $step_id, 'wcf-order-bumps', true );
		if ( ! is_array( $bumps ) ) {
			$bumps = array();
		}
		// Apply the mutation; null signals an unrecoverable validation error.
		$next = $mutator( $bumps );
		if ( ! is_array( $next ) ) {
			$this->fail( 'no-post-data' );
		}
		// Single read-modify-write — keeps partial-state issues impossible.
		update_post_meta( $step_id, 'wcf-order-bumps', $next );
		// Bust the dynamic CSS cache so the next render rebuilds styles for any new/changed bumps.
		AdminHelper::clear_current_step_css( $step_id );
		// Standard success envelope — JS hook reads response.data.order_bumps to update Redux.
		wp_send_json_success(
			array(
				'order_bumps' => $next,
			)
		);
	}

	/**
	 * Locate a bump entry's index by its id.
	 *
	 * @param array<int, array<string, mixed>> $bumps Array of bump entries.
	 * @param string                           $ob_id Order bump id.
	 * @return int|null Index in the array or null if not found.
	 */
	private function find_index( $bumps, $ob_id ) {
		foreach ( $bumps as $idx => $entry ) {
			// Each bump entry's 'id' is always a string in this codebase; guard then compare.
			if ( ! is_array( $entry ) ) {
				continue;
			}
			if ( ! isset( $entry['id'] ) ) {
				continue;
			}
			if ( $this->scalar_str( $entry['id'] ) === (string) $ob_id ) {
				return $idx;
			}
		}
		return null;
	}

	/**
	 * Safely coerce a mixed value to string. Non-scalars become an empty string.
	 *
	 * @param mixed $value Value to coerce.
	 * @return string
	 */
	private function scalar_str( $value ) {
		return is_scalar( $value ) ? (string) $value : '';
	}


	/**
	 * Shared mutation for both archive and delete AJAX handlers — direct mirror of Step A/B's
	 * Cartflows_Pro_Ab_Test_Meta::delete_variation() (modules/ab-test/classes/class-cartflows-pro-ab-test-meta.php:97).
	 *
	 * Inlines promotion + variation removal + traffic rebalance so the whole mutation lives in one
	 * place, exactly like Step A/B. The single state re-stamp at the bottom (ab-test=true,
	 * ab-test-ui=true, ab-test-start=false) is the canonical Step A/B behaviour: the test
	 * persists in a paused state when no opponents remain, so the admin can resume by adding
	 * new variations later.
	 *
	 * @param array<int, array<string, mixed>> $bumps         Current bumps array.
	 * @param string                           $control_ob_id Control id of the A/B group.
	 * @param string                           $ob_id         Bump id to remove (may equal control id).
	 * @param bool                             $delete_data   True for hard-delete, false for archive.
	 * @param int                              $step_id       Step id, threaded to push_archive_entry for stats snapshot.
	 * @return array<int, array<string, mixed>>|null Mutated bumps array, or null on bad input.
	 */
	private function delete_variation( $bumps, $control_ob_id, $ob_id, $delete_data, $step_id = 0 ) {
		$idx  = $this->find_index( $bumps, $control_ob_id );
		$vidx = $this->find_index( $bumps, $ob_id );
		if ( null === $idx || null === $vidx ) {
			return null;
		}
		$vars    = is_array( $bumps[ $idx ]['ab-test-variations'] ?? null ) ? $bumps[ $idx ]['ab-test-variations'] : array();
		$archive = is_array( $bumps[ $idx ]['ab-test-archived-variations'] ?? null ) ? $bumps[ $idx ]['ab-test-archived-variations'] : array();
		$victim  = $bumps[ $vidx ];
		// Lone control deletion — no variants to promote, nowhere to archive. Just remove the entry.
		if ( $control_ob_id === $ob_id && ! isset( $vars[1] ) ) {
			array_splice( $bumps, $vidx, 1 );
			return array_values( $bumps );
		}
		// Control deletion with surviving variants — promote the first non-control variant inline.
		if ( $control_ob_id === $ob_id ) {
			$new_id  = $this->scalar_str( $vars[1]['id'] ?? '' );
			$new_idx = $this->find_index( $bumps, $new_id );
			if ( null === $new_idx ) {
				return null;
			}
			$bumps[ $new_idx ]['wcf-control-ob'] = '';
			foreach ( $bumps as $i => $e ) {
				if ( $e['wcf-control-ob'] === $control_ob_id && ( $e['id'] ?? '' ) !== $new_id ) {
					$bumps[ $i ]['wcf-control-ob'] = $new_id;
				}
			}
			$idx = $new_idx;
		}
		// Only soft archives leave a trace; hard-delete removes the variant with no archived entry.
		if ( ! $delete_data ) {
			$archive = $this->push_archive_entry( $archive, $victim, $delete_data, '', $step_id );
		}
		// Remove victim from active variations + rebalance traffic 50/50 (mirror Step A/B lines 166-185).
		if ( count( $vars ) > 1 ) {
			foreach ( $vars as $vi => $v ) {
				if ( ( $v['id'] ?? '' ) === $ob_id ) {
					array_splice( $vars, $vi, 1 );
					break;
				}
			}
			$traffic = array( 50, 50 );
			foreach ( $vars as $vi => $v ) {
				$vars[ $vi ]['traffic'] = $traffic[ $vi ] ?? 0;
			}
		}
		// Splice victim from bumps + re-find idx (splice may have shifted it).
		array_splice( $bumps, $vidx, 1 );
		$final_id = $control_ob_id === $ob_id ? $this->scalar_str( $vars[0]['id'] ?? '' ) : $control_ob_id;
		$idx      = $this->find_index( $bumps, $final_id );
		// Single state re-stamp (mirror Step A/B lines 188-192) — the test persists, paused.
		if ( null !== $idx ) {
			$bumps[ $idx ]['ab-test']                     = true;
			$bumps[ $idx ]['ab-test-ui']                  = true;
			$bumps[ $idx ]['ab-test-start']               = false;
			$bumps[ $idx ]['ab-test-variations']          = array_values( $vars );
			$bumps[ $idx ]['ab-test-archived-variations'] = array_values( $archive );
		}
		return array_values( $bumps );
	}

	/**
	 * Build an archive entry from a bump's payload using the Step A/B archive schema.
	 * Owns the "every loser snapshot carries wcf-winner-ob" invariant — when the caller passes a
	 * winner id, the field is stamped onto the payload snapshot here, so the rule cannot be
	 * broken by call-site reordering or a new caller forgetting to stamp.
	 *
	 * Read the funnel counters for a specific bump from `wcf-order-bump-ab-stats` and return a snapshot.
	 * Derives the control id from the bump (variant → wcf-control-ob, control → its own id, standalone → its own id)
	 * so the lookup key matches what the listeners wrote.
	 *
	 * @param int                  $step_id Step id whose stats postmeta we read.
	 * @param array<string, mixed> $bump    Bump payload — the variant being archived.
	 * @return array{impressions:int,initiated:int,conversions:int}
	 */
	private function snapshot_stats_for_bump( $step_id, $bump ) {
		$empty = array(
			'impressions' => 0,
			'initiated'   => 0,
			'conversions' => 0,
		);
		if ( $step_id <= 0 ) {
			return $empty;
		}
		$bump_id = $this->scalar_str( $bump['id'] ?? '' );
		if ( '' === $bump_id ) {
			return $empty;
		}
		$control_id = isset( $bump['wcf-control-ob'] ) ? $this->scalar_str( $bump['wcf-control-ob'] ) : '';
		if ( '' === $control_id ) {
			$control_id = $bump_id;
		}
		$stats = get_post_meta( $step_id, 'wcf-order-bump-ab-stats', true );
		if ( ! is_array( $stats ) || ! isset( $stats[ $control_id ][ $bump_id ] ) || ! is_array( $stats[ $control_id ][ $bump_id ] ) ) {
			return $empty;
		}
		$row = $stats[ $control_id ][ $bump_id ];
		return array(
			'impressions' => isset( $row['impressions'] ) ? (int) $row['impressions'] : 0,
			'initiated'   => isset( $row['initiated'] ) ? (int) $row['initiated'] : 0,
			'conversions' => isset( $row['conversions'] ) ? (int) $row['conversions'] : 0,
		);
	}

	/**
	 * Build an archive entry from a bump's payload using the Step A/B archive schema.
	 * Owns the "every loser snapshot carries wcf-winner-ob" invariant — when the caller passes a
	 * winner id, the field is stamped onto the payload snapshot here, so the rule cannot be
	 * broken by call-site reordering or a new caller forgetting to stamp.
	 *
	 * @param array<int, array<string, mixed>> $archived      Current archived list.
	 * @param array<string, mixed>             $bump          Full bump payload being archived.
	 * @param bool                             $deleted       True = hard-delete, false = soft archive.
	 * @param string                           $winner_ob_id  When non-empty, stamps wcf-winner-ob on the snapshot.
	 * @param int                              $step_id       Step id, used to snapshot the variant's current stats.
	 * @return array<int, array<string, mixed>> Updated archived list with the new entry pushed.
	 */
	private function push_archive_entry( $archived, $bump, $deleted, $winner_ob_id = '', $step_id = 0 ) {
		$now = current_time( 'mysql' );
		// Stamp the winner pointer on the snapshot when one is supplied — declare-winner is the sole user.
		if ( '' !== $winner_ob_id ) {
			$bump['wcf-winner-ob'] = $winner_ob_id;
		}
		// Capture the variant's funnel counters at archive time so the admin UI has a frozen history snapshot.
		$stats_snapshot = $this->snapshot_stats_for_bump( $step_id, $bump );
		$entry          = array(
			'id'       => $this->scalar_str( $bump['id'] ?? '' ),
			'title'    => $this->scalar_str( $bump['title'] ?? '' ),
			'note'     => '',
			'deleted'  => (bool) $deleted,
			'raw_date' => $now,
			'date'     => $now,
			// Funnel counters frozen at archive time — rendered by the ArchivedVariations accordion.
			'stats'    => $stats_snapshot,
			// Store the full payload so restore() can reconstitute the bump entry with its original fields.
			'payload'  => $bump,
		);
		// Mirror Step A/B lines 159-163: deletes append (chronological); archives prepend (most-recent-first).
		if ( $deleted ) {
			$archived[] = $entry;
		} else {
			array_unshift( $archived, $entry );
		}
		return $archived;
	}

	/**
	 * POST helper — returns a sanitised string for the given key (empty when missing).
	 *
	 * @param string $key POST key to read.
	 * @return string
	 */
	private function post_string( $key ) {
		// Nonce verified upstream in guard() before any caller uses this helper.
		if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return '';
		}
		// Nonce checked in guard() before this is called.
		return sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Generate a fresh bump/variant id, avoiding ids already in use.
	 *
	 * @param array<int, string> $existing Ids already taken on this step.
	 * @return string
	 */
	private function generate_id( $existing = array() ) {
		/*
		 * Was three hex characters — a 4096-value space with no collision check, on ids that
		 * every lookup matches on. Eight characters, and where the caller can supply the ids
		 * already in play we re-roll rather than hoping.
		 */
		$taken = array_map( 'strval', $existing );

		for ( $attempt = 0; $attempt < 10; $attempt++ ) {
			$id = substr( md5( (string) wp_rand() ), 2, 8 );

			if ( ! in_array( $id, $taken, true ) ) {
				return $id;
			}
		}

		return substr( md5( uniqid( (string) wp_rand(), true ) ), 2, 8 );
	}

	/**
	 * Collect every id already used by a bump list, including its variations.
	 *
	 * @param array<int, array<string, mixed>> $bumps Bump entries.
	 * @return array<int, string>
	 */
	private function collect_ids( $bumps ) {

		$ids = array();

		foreach ( (array) $bumps as $bump ) {
			if ( ! is_array( $bump ) ) {
				continue;
			}

			if ( isset( $bump['id'] ) && is_scalar( $bump['id'] ) ) {
				$ids[] = (string) $bump['id'];
			}

			foreach ( array( 'ab-test-variations', 'ab-test-archived-variations' ) as $list ) {
				foreach ( (array) ( isset( $bump[ $list ] ) ? $bump[ $list ] : array() ) as $variation ) {
					if ( is_array( $variation ) && isset( $variation['id'] ) && is_scalar( $variation['id'] ) ) {
						$ids[] = (string) $variation['id'];
					}
				}
			}
		}

		return $ids;
	}

	/**
	 * Send a JSON error using the standard CartFlows error message bag and stop the request.
	 *
	 * @param string $type Error type key recognised by AjaxErrors.
	 * @return void
	 */
	private function fail( $type ) {
		wp_send_json_error( array( 'message' => $this->get_error_msg( $type ) ) );
	}
}
