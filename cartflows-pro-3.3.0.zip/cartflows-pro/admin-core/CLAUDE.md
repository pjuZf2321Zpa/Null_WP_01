# Module: admin-core

The Pro plugin's admin backend: `cartflows-pro/v1` REST controllers, `wp_ajax_cartflows_pro_*` handlers, and the filters that inject Pro data into the free plugin's React admin app.

Read `architecture.md` in this folder before changing this module.

## Rules

- **File paths are derived from class names by the autoloader** (lowercase + hyphenate). A new controller whose file isn't kebab-case-of-class-name silently fails to load. `pro-admin-loader.php:61-69`
- **New controllers must be added to the init registry array**, not just created — `register_routes()` / `register_ajax_events()` are never discovered. `admin-core/api/api-init.php:68-73`, `admin-core/ajax/ajax-init.php:67-73`
- Every AJAX action's nonce is `cartflows_pro_<method_name>`, generated from the method name. Renaming a handler renames both the action and the nonce key JS reads. `admin-core/ajax/ajax-base.php:76`
- Nonces are only localized for users with `cartflows_manage_flows_steps` — for anyone else the `*_nonce` key is **absent**, not empty. `admin-core/ajax/ajax-base.php:70`
- **A new order-bump setting is dropped unless registered in `order_bump_default_meta()`**, and it must carry a `['sanitize']` filter name. `admin-core/ajax/multiple-order-bump.php:113-117`
- `save_order_bump_ab_traffic` rejects any payload whose `traffic` values don't sum to exactly 100. `admin-core/ajax/multiple-order-bump-ab.php:279-282`
- AI/FBT endpoints return **HTTP 200 with `success: false`** for expected failures; `WP_Error` only for hard errors. Callers checking only HTTP status treat "no product found" as success. `admin-core/api/ob-ai-suggest.php:193-202`
- `GlobalSettingsPro::save_pro_global_settings` only understands the `offer` and `permalink` tabs — any other tab falls into `default:` and silently discards the POST. `admin-core/inc/global-settings-pro.php:85-128`

## Gotchas

- **`save_order_bump_settings` always returns `wp_send_json_error`, even on success.** `$response_data` is built with `'success' => true` but shipped through the error envelope, so JS must read `response.data.success`, not `response.success`. `get_current_order_bump` does the mirror image — its "no data" branch is sent via `wp_send_json_success`. `admin-core/ajax/multiple-order-bump.php:145,462-470`
- **Three different response envelopes coexist for the same feature** — `MultipleOrderBump` uses the misspelled key `messsage`, `MultipleOrderBumpAb` uses `message`, and two handlers use bare `wp_send_json` with a `status`/`text` shape. A shared JS error handler cannot exist. `admin-core/ajax/multiple-order-bump.php:67`, `multiple-order-bump-ab.php:790`
- **The A/B controller has no `CARTFLOWS_STEP_POST_TYPE` check at all** — `guard()` validates cap + nonce + `step_id > 0` only, while the older controller checks post type on six handlers. Any authorized user can write `wcf-order-bumps` meta onto an arbitrary post ID via the ten A/B actions. `admin-core/ajax/multiple-order-bump-ab.php:511-527`
- **The A/B path also bypasses the sanitization whitelist entirely** — `mutate()` writes whatever the mutator returns, while the non-A/B path filters every key through the default-meta list. Two different default-meta sources are in play, so a restored variant can end up with a different key set than a fresh bump. `admin-core/ajax/multiple-order-bump-ab.php:540-560,441`
- Bump/variant IDs are **3 hex characters** with no collision check — a 4096-value space, and every lookup matches on it. `admin-core/ajax/multiple-order-bump.php:951`
- **`method_exists( 'AdminHelper', … )` is always false** — an unqualified string resolves to `\AdminHelper`, not the imported class, so the "new" branch is dead and both saves go through the legacy path, contradicting the "Remove after two updates" comment. `admin-core/inc/global-settings-pro.php:99,119`
- **`enqueue_pro_admin_app` mutates WordPress's internal dependency graph**, pushing onto a registered script's `deps` array so the Pro app loads before the free handles. The `priority 20` is load-bearing. If the free plugin renames a handle or changes its enqueue priority, the Pro filters register too late and the editor renders without Pro fields — with no error. `admin-core/inc/admin-hooks.php:132-139,77`
- The date range in `add_flow_analytics_data` **deliberately** mixes `current_time()` and `gmdate()` — the comment records that `gmdate()` alone drops today's data when the site timezone is ahead of UTC. Easy to "simplify" back into a bug. `admin-core/inc/admin-hooks.php:171-175`
- **Including `cartflows-license-log.php` performs a blocking 15-second remote POST as a constructor side effect**, and the ordering inside it is load-bearing: the real API key must be used for the request, then masked before the view renders it. `admin-core/inc/cartflows-license-log.php:114,45-48,81-100`
- `add_debugger_styles` enqueues `debugger.css` on **every** admin page with no screen check. `admin-core/inc/admin-hooks.php:75,147-149`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `npm run lint-js && composer lint && composer phpstan`
