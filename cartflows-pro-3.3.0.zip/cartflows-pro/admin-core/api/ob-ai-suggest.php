<?php
/**
 * CartFlows Order Bump — AI Suggest endpoint.
 *
 * Mode 2: the admin asks for a recommendation, gets one product with a
 * plain-language reason, and decides whether to keep it. Nothing is saved here —
 * the existing form POST persists the choice only if the admin confirms it.
 *
 * The product payload deliberately matches ObProductData's shape so the editor can
 * reuse the render path it already has for a hand-picked product.
 *
 * @package CartFlows Pro
 */

namespace CartflowsProAdmin\AdminCore\Api;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use CartflowsProAdmin\AdminCore\Api\ApiBase;

/**
 * Class ObAiSuggest.
 *
 * @since x.x.x
 */
class ObAiSuggest extends ApiBase {

	/**
	 * Route base.
	 *
	 * @var string
	 */
	protected $rest_base = '/admin/ob-ai-suggest/';

	/**
	 * How many candidates are considered before one is chosen.
	 *
	 * @var int
	 */
	const SHORTLIST = 20;

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since x.x.x
	 */
	private static $instance = null;

	/**
	 * Initiator
	 *
	 * @since x.x.x
	 * @return self Initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register API routes.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function register_routes() {

		register_rest_route(
			$this->get_api_namespace(),
			$this->rest_base . '(?P<id>[\d]+)',
			array(
				'args'   => array(
					'id' => array(
						'description' => __( 'Checkout step ID.', 'cartflows-pro' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_suggestion' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						// phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- REST arg name, not a WP_Query param.
						'exclude' => array(
							'default'           => '',
							'sanitize_callback' => array( $this, 'sanitize_ids' ),
						),
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			)
		);

		register_rest_route(
			$this->get_api_namespace(),
			'/admin/ob-ai-copy/(?P<id>[\d]+)',
			array(
				'args' => array(
					'id' => array(
						'description' => __( 'Checkout step ID.', 'cartflows-pro' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'generate_copy' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'field'      => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
						),
						// Sent from the editor rather than read from saved meta: the
						// admin may be mid-edit, so the screen is the source of truth.
						'mode'       => array(
							'default'           => 'manual',
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
						),
						'product_id' => array(
							'default'           => 0,
							'type'              => 'integer',
							'sanitize_callback' => 'absint',
						),
						'pool_ids'   => array(
							'default'           => '',
							'sanitize_callback' => array( $this, 'sanitize_ids' ),
						),
						'tone'       => array(
							'default'           => '',
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);
	}

	/**
	 * Write one order bump text field with AI.
	 *
	 * Returns the text for the admin to keep or regenerate; nothing is saved here.
	 *
	 * @since x.x.x
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function generate_copy( $request ) {

		if ( ! wcf()->is_woo_active ) {
			return new \WP_Error( 'cartflows_rest_cannot_call', __( 'Sorry, WooCommerce need to be installed & activated to call API.', 'cartflows-pro' ) );
		}

		if ( ! class_exists( 'Cartflows_Pro_Order_Bump_Ai_Copy' ) ) {
			return new \WP_Error( 'cartflows_rest_no_writer', __( 'AI writing is unavailable.', 'cartflows-pro' ) );
		}

		$step_id = absint( $request->get_param( 'id' ) );
		$step    = get_post( $step_id );

		if ( ! $step instanceof \WP_Post || 'checkout' !== get_post_meta( $step_id, 'wcf-step-type', true ) ) {
			return new \WP_Error( 'cartflows_rest_invalid_step', __( 'This is not a checkout step.', 'cartflows-pro' ), array( 'status' => 404 ) );
		}

		$field = sanitize_key( strval( $request->get_param( 'field' ) ) );

		if ( ! \Cartflows_Pro_Order_Bump_Ai_Copy::is_supported_field( $field ) ) {
			return new \WP_Error( 'cartflows_rest_bad_field', __( 'That field cannot be written automatically.', 'cartflows-pro' ), array( 'status' => 400 ) );
		}

		$result = \Cartflows_Pro_Order_Bump_Ai_Copy::get_instance()->generate(
			$step_id,
			$field,
			array(
				'mode'       => sanitize_key( strval( $request->get_param( 'mode' ) ) ),
				'product_id' => absint( $request->get_param( 'product_id' ) ),
				'pool_ids'   => (array) $request->get_param( 'pool_ids' ),
				'tone'       => sanitize_text_field( strval( $request->get_param( 'tone' ) ) ),
			)
		);

		// A failure here is expected traffic, not a broken request: the admin just needs
		// to know what to do next, so it comes back as a readable message.
		if ( is_wp_error( $result ) ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'field'   => $field,
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				)
			);
		}

		return rest_ensure_response(
			array(
				'success'    => true,
				'field'      => $field,
				'variations' => $result['variations'],
				'usage'      => $result['usage'],
			)
		);
	}

	/**
	 * Only users who may edit funnel steps can ask for a suggestion.
	 *
	 * @since x.x.x
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return \WP_Error|bool
	 */
	public function get_item_permissions_check( $request ) {

		if ( ! current_user_can( 'cartflows_manage_flows_steps' ) ) {
			return new \WP_Error( 'cartflows_rest_cannot_view', __( 'Sorry, you cannot list resources.', 'cartflows-pro' ), array( 'status' => rest_authorization_required_code() ) );
		}

		return true;
	}

	/**
	 * Normalize a CSV or array of IDs into a unique positive int list.
	 *
	 * @since x.x.x
	 * @param mixed $value Raw param value.
	 * @return int[]
	 */
	public function sanitize_ids( $value ) {

		if ( is_array( $value ) ) {
			$raw = $value;
		} elseif ( is_scalar( $value ) ) {
			$raw = explode( ',', (string) $value );
		} else {
			return array();
		}

		$ids = array();
		foreach ( $raw as $item ) {
			if ( is_scalar( $item ) ) {
				$id = absint( $item );
				if ( $id > 0 ) {
					$ids[] = $id;
				}
			}
		}

		return array_slice( array_values( array_unique( $ids ) ), 0, 50 );
	}

	/**
	 * Recommend one Order Bump product for a checkout step.
	 *
	 * @since x.x.x
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_suggestion( $request ) {

		if ( ! wcf()->is_woo_active ) {
			return new \WP_Error( 'cartflows_rest_cannot_call', __( 'Sorry, WooCommerce need to be installed & activated to call API.', 'cartflows-pro' ) );
		}

		if ( ! class_exists( 'Cartflows_Pro_Product_Relevance' ) ) {
			return new \WP_Error( 'cartflows_rest_no_engine', __( 'The product relevance engine is unavailable.', 'cartflows-pro' ) );
		}

		$step_id = absint( $request->get_param( 'id' ) );
		$step    = get_post( $step_id );

		if ( ! $step instanceof \WP_Post || 'checkout' !== get_post_meta( $step_id, 'wcf-step-type', true ) ) {
			return new \WP_Error( 'cartflows_rest_invalid_step', __( 'This is not a checkout step.', 'cartflows-pro' ), array( 'status' => 404 ) );
		}

		// A store checkout sells whatever is in the visitor's cart, so it has no products
		// of its own. That is not an error — suggestions just come from the catalog.
		$sources = $this->get_step_product_ids( $step_id );

		$engine = \Cartflows_Pro_Product_Relevance::get_instance();

		// Never suggest a product the checkout already sells, or one already bumped here.
		$exclude = array_merge(
			$sources,
			$this->get_configured_bump_products( $step_id ),
			(array) $request->get_param( 'exclude' )
		);
		$exclude = array_values( array_unique( array_map( 'absint', $exclude ) ) );

		$shortlist = $engine->get_related_products( $sources, 'order_bump', self::SHORTLIST, $exclude );

		$chosen = $this->pick( $shortlist, $sources, $step_id );

		if ( empty( $chosen ) ) {
			return rest_ensure_response(
				array(
					'success' => false,
					'message' => __( 'No suitable product was found. Try adding more products to your catalog.', 'cartflows-pro' ),
				)
			);
		}

		$tier = $engine->get_signal_tier( $sources );

		return rest_ensure_response(
			array(
				'success'       => true,
				'product'       => $this->format_product( $chosen['id'] ),
				'reason'        => $this->build_reason( $chosen, $tier, ! empty( $sources ) ),
				'confidence'    => $this->build_confidence( $chosen, $tier ),
				'tier'          => $tier,
				'match_percent' => $chosen['match_percent'],
				'basis'         => $chosen['source'],
			)
		);
	}

	/**
	 * Choose one candidate from the shortlist and re-validate it.
	 *
	 * The filter is the seam an LLM-backed pick would slot into. Whatever it returns is
	 * re-checked against live stock, because a suggestion the admin cannot actually save
	 * is worse than no suggestion.
	 *
	 * @since x.x.x
	 * @param array<int, array<string, mixed>> $shortlist Ranked candidates.
	 * @param int[]                            $sources   Checkout product IDs.
	 * @param int                              $step_id   Checkout step ID.
	 * @return array{id:int, score:float, source:string, match_percent:float}|array{} Empty when none survive.
	 */
	private function pick( $shortlist, $sources, $step_id ) {

		if ( empty( $shortlist ) ) {
			return array();
		}

		$engine = \Cartflows_Pro_Product_Relevance::get_instance();

		$chosen = apply_filters( 'cartflows_pro_ai_ob_pick', $shortlist[0], $shortlist, $sources, $step_id );

		// Honour the filter only if it handed back a usable candidate.
		if ( is_array( $chosen ) && ! empty( $chosen['id'] ) && $engine->is_offerable( absint( $chosen['id'] ) ) ) {
			return $this->normalize_candidate( $chosen );
		}

		foreach ( $shortlist as $candidate ) {
			if ( ! empty( $candidate['id'] ) && $engine->is_offerable( absint( $candidate['id'] ) ) ) {
				return $this->normalize_candidate( $candidate );
			}
		}

		return array();
	}

	/**
	 * Coerce a candidate into a definite shape.
	 *
	 * The `cartflows_pro_ai_ob_pick` filter is third-party territory, so nothing about
	 * the array it returns can be assumed beyond an ID we have already validated.
	 *
	 * @since x.x.x
	 * @param array<string, mixed> $candidate Raw candidate.
	 * @return array{id:int, score:float, source:string, match_percent:float}
	 */
	private function normalize_candidate( $candidate ) {

		return array(
			'id'            => isset( $candidate['id'] ) ? absint( $candidate['id'] ) : 0,
			'score'         => isset( $candidate['score'] ) && is_numeric( $candidate['score'] ) ? (float) $candidate['score'] : 0.0,
			'source'        => isset( $candidate['source'] ) && is_scalar( $candidate['source'] ) ? (string) $candidate['source'] : '',
			'match_percent' => isset( $candidate['match_percent'] ) && is_numeric( $candidate['match_percent'] ) ? (float) $candidate['match_percent'] : 0.0,
		);
	}

	/**
	 * Products this checkout step sells.
	 *
	 * @since x.x.x
	 * @param int $step_id Checkout step ID.
	 * @return int[]
	 */
	private function get_step_product_ids( $step_id ) {

		$products = wcf()->utils->get_selected_checkout_products( $step_id );
		$ids      = array();

		if ( is_array( $products ) ) {
			foreach ( $products as $row ) {
				$id = is_array( $row ) && isset( $row['product'] ) ? absint( $row['product'] ) : 0;
				if ( $id ) {
					$ids[] = $id;
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Products already configured on this step's order bumps, pool entries included.
	 *
	 * @since x.x.x
	 * @param int $step_id Checkout step ID.
	 * @return int[]
	 */
	private function get_configured_bump_products( $step_id ) {

		$bumps = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-order-bumps' );
		$ids   = array();

		if ( ! is_array( $bumps ) ) {
			return $ids;
		}

		foreach ( $bumps as $bump ) {
			if ( ! is_array( $bump ) ) {
				continue;
			}
			if ( ! empty( $bump['product'] ) ) {
				$ids[] = absint( $bump['product'] );
			}
			if ( ! empty( $bump['ai_product_pool'] ) && is_array( $bump['ai_product_pool'] ) ) {
				foreach ( $bump['ai_product_pool'] as $row ) {
					$id = is_array( $row ) && isset( $row['id'] ) ? absint( $row['id'] ) : absint( $row );
					if ( $id ) {
						$ids[] = $id;
					}
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * A plain-language reason the admin can judge.
	 *
	 * Wording follows the signal that actually won, so the admin is never told a pick is
	 * backed by purchase history when it is really a catalog guess.
	 *
	 * @since x.x.x
	 * @param array{id:int, score:float, source:string, match_percent:float} $chosen      Chosen candidate.
	 * @param string                                                         $tier        rich | thin | cold.
	 * @param bool                                                           $has_sources Whether the step sells a fixed product.
	 * @return string
	 */
	private function build_reason( $chosen, $tier, $has_sources = true ) {

		$source  = $chosen['source'];
		$percent = (int) round( $chosen['match_percent'] );

		// A store checkout has no fixed product, so wording that refers to one would be a lie.
		if ( ! $has_sources ) {
			return 'recent' === $source
				? __( 'One of your newest products. This checkout has no fixed product, so suggestions come from your catalog.', 'cartflows-pro' )
				: __( 'One of your best sellers. This checkout has no fixed product, so suggestions come from your catalog.', 'cartflows-pro' );
		}

		switch ( $source ) {
			case 'affinity':
				return $percent > 0
					/* translators: %d: match strength as a percentage. */
					? sprintf( __( 'Customers who bought your checkout product often bought this too — a %d%% match on your order history.', 'cartflows-pro' ), $percent )
					: __( 'Customers who bought your checkout product often bought this one too.', 'cartflows-pro' );

			case 'cosine':
				return __( 'This closely matches your checkout product’s description and category.', 'cartflows-pro' );

			case 'both':
				return $percent > 0
					/* translators: %d: match strength as a percentage. */
					? sprintf( __( 'This is both frequently bought alongside your checkout product and a close match to it — %d%% overall.', 'cartflows-pro' ), $percent )
					: __( 'This is both frequently bought alongside your checkout product and a close match to it.', 'cartflows-pro' );

			case 'category':
				return __( 'A popular product that complements your checkout product and sits in a sensible price range.', 'cartflows-pro' );

			case 'popular':
				return __( 'One of your best sellers, which makes it a safe add-on.', 'cartflows-pro' );

			case 'recent':
				return __( 'One of your newest products. There isn’t enough order history yet for a stronger signal.', 'cartflows-pro' );

			default:
				return 'cold' === $tier
					? __( 'Chosen from your catalog. There isn’t enough order history yet for a stronger signal.', 'cartflows-pro' )
					: __( 'A relevant match for your checkout product.', 'cartflows-pro' );
		}
	}

	/**
	 * How much to trust the pick: high, medium or low.
	 *
	 * @since x.x.x
	 * @param array{id:int, score:float, source:string, match_percent:float} $chosen Chosen candidate.
	 * @param string                                                         $tier   rich | thin | cold.
	 * @return string
	 */
	private function build_confidence( $chosen, $tier ) {

		$source = $chosen['source'];

		// Catalog fallbacks carry no evidence about this pairing, whatever the tier says.
		if ( in_array( $source, array( 'category', 'popular', 'recent', 'pool' ), true ) ) {
			return 'low';
		}

		if ( 'rich' === $tier && in_array( $source, array( 'affinity', 'both' ), true ) ) {
			return 'high';
		}

		return 'medium';
	}

	/**
	 * Build the product payload, matching ObProductData so the editor can reuse it.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return array<string, mixed>
	 */
	private function format_product( $product_id ) {

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return array();
		}

		$admin_helper = \Cartflows_Pro_Admin_Helper::get_instance();
		$product_data = $admin_helper::get_products_label( array( $product_id ) );

		$product_image = get_the_post_thumbnail_url( $product_id );
		if ( empty( $product_image ) ) {
			$product_image = esc_url_raw( CARTFLOWS_PRO_URL . 'assets/images/image-placeholder.png' );
		}

		if ( isset( $product_data[0]['original_price'] ) ) {
			$price_data                       = \Cartflows_Pro_Order_Bump_Product::get_instance()->get_taxable_product_price( $product, $product_data[0]['original_price'], 0 );
			$product_data[0]['display_price'] = '<span class="wcf-normal-price">' . wc_price( $price_data['product_price'] ) . '</span>';
		}

		return array(
			'product'       => $product_data,
			'desc_text'     => $product->get_short_description() . '<br>' . "\r\n{{product_price}}",
			'product_image' => $product_image,
		);
	}
}
