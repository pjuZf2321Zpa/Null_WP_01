<?php
/**
 * CartFlows Frequently Bought Together REST endpoint.
 *
 * Frontend-facing read endpoint that returns product recommendations for the
 * given products. Ranking lives in Cartflows_Pro_Product_Relevance — the shared
 * engine Order Bump also uses — so this class is only the HTTP layer: request
 * validation, the day-long response cache, and the display payload.
 *
 * @package CartFlows
 */

namespace CartflowsProAdmin\AdminCore\Api;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use CartflowsProAdmin\AdminCore\Api\ApiBase;

/**
 * Class FrequentlyBoughtTogether.
 */
class FrequentlyBoughtTogether extends ApiBase {

	/**
	 * Route base.
	 *
	 * @var string
	 */
	protected $rest_base = '/frequently-bought-together/';

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since 2.2.5
	 */
	private static $instance = null;

	/**
	 * Initiator
	 *
	 * @since 2.2.5
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register API routes.
	 *
	 * @since 2.2.5
	 * @return void
	 */
	public function register_routes() {

		$namespace = $this->get_api_namespace();
		$route     = '/' . ltrim( $this->rest_base, '/' );

		register_rest_route(
			$namespace,
			$route,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_recommendations' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
					'args'                => array(
						'product_ids' => array(
							'required'          => true,
							'sanitize_callback' => array( $this, 'sanitize_product_ids' ),
							'validate_callback' => static function ( $value ) {
								return ! empty( $value );
							},
						),
						'limit'       => array(
							'default'           => 5,
							'sanitize_callback' => 'absint',
						),
						'context'     => array(
							'default'           => 'fbt',
							'sanitize_callback' => 'sanitize_key',
						),
						// phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- REST arg name, not a WP_Query param.
						'exclude'     => array(
							'default'           => '',
							'sanitize_callback' => array( $this, 'sanitize_product_ids' ),
						),
						'force'       => array(
							'default'           => false,
							'sanitize_callback' => 'rest_sanitize_boolean',
						),
					),
				),
			)
		);
	}

	/**
	 * Public read access — recommendations expose only catalog data.
	 *
	 * @since 2.2.5
	 * @param \WP_REST_Request $request Request object.
	 * @return bool|\WP_Error
	 */
	public function get_items_permissions_check( $request ) {
		if ( ! current_user_can( 'cartflows_manage_settings' ) ) {
			return new \WP_Error(
				'cartflows_rest_cannot_manage',
				__( 'Sorry, you are not allowed to manage frequently bought together settings.', 'cartflows-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}

		// Auto Suggest is a Pro feature, so an inactive licence must not reach the engine.
		if ( ! cartflows_pro_is_active_license() ) {
			return new \WP_Error(
				'cartflows_rest_licence_inactive',
				__( 'Activate your CartFlows Pro licence to use Auto Suggest.', 'cartflows-pro' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}

		return true;
	}

	/**
	 * Normalize the product_ids param (CSV or array) into a unique int list.
	 *
	 * @since 2.2.5
	 * @param mixed $value Raw param value.
	 * @return int[]
	 */
	public function sanitize_product_ids( $value ) {
		if ( is_array( $value ) ) {
			$raw = $value;
		} elseif ( is_scalar( $value ) ) {
			$raw = explode( ',', (string) $value );
		} else {
			return array();
		}

		$ids = array();
		foreach ( $raw as $item ) {
			if ( is_scalar( $item ) ) {
				$id = absint( $item );
				if ( $id > 0 ) {
					$ids[] = $id;
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Return recommended products for the requested product IDs.
	 *
	 * @since 2.2.5
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function get_recommendations( $request ) {

		$product_ids = $this->sanitize_product_ids( $request->get_param( 'product_ids' ) );
		$limit_param = $request->get_param( 'limit' );
		$limit       = is_numeric( $limit_param ) ? max( 1, absint( $limit_param ) ) : 5;
		$context     = $this->sanitize_context( $request->get_param( 'context' ) );
		$exclude_ids = array_slice( $this->sanitize_product_ids( $request->get_param( 'exclude' ) ), 0, 50 );
		$force       = (bool) $request->get_param( 'force' );

		if ( empty( $product_ids ) || ! class_exists( 'Cartflows_Pro_Product_Affinity' ) || ! class_exists( 'Cartflows_Pro_Product_Relevance' ) ) {
			return rest_ensure_response(
				array(
					'success'  => true,
					'products' => array(),
					'message'  => __( 'No recommendations found.', 'cartflows-pro' ),
				)
			);
		}

		// Key varies by source products, context, exclusions, product edits, and affinity recomputes.
		$source_id = (int) $product_ids[0];
		$cache_key = 'cartflows_fbt_recs_' . md5( implode( ',', $product_ids ) . '|' . $context . '|' . implode( ',', $exclude_ids ) . '|' . get_post_modified_time( 'U', true, $source_id ) . '|' . get_option( 'cartflows_fbt_last_computed', '' ) );

		$pool = $force ? false : get_transient( $cache_key );
		if ( ! is_array( $pool ) ) {
			$pool = \Cartflows_Pro_Product_Relevance::get_instance()->get_related_products( $product_ids, $context, max( 20, $limit * 4 ), $exclude_ids );
			set_transient( $cache_key, $pool, DAY_IN_SECONDS );
		}

		$products = array();
		$sources  = array();
		foreach ( $pool as $item ) {
			if ( count( $products ) >= $limit ) {
				break;
			}
			$formatted = $this->format_product( (int) $item['id'] );
			if ( ! empty( $formatted ) ) {
				$formatted['source']        = $item['source'];
				$formatted['match_percent'] = $item['match_percent'];
				$products[]                 = $formatted;
				$sources[]                  = (string) $item['source'];
			}
		}

		$counts = array_count_values( $sources );
		arsort( $counts );

		return rest_ensure_response(
			array(
				'success'  => true,
				'products' => $products,
				'basis'    => empty( $counts ) ? '' : (string) key( $counts ),
			)
		);
	}

	/**
	 * Whitelist the requested suggestion context.
	 *
	 * @since x.x.x
	 * @param mixed $value Raw context param.
	 * @return string
	 */
	private function sanitize_context( $value ) {
		$context = is_string( $value ) ? $value : 'fbt';
		return in_array( $context, array( 'fbt', 'crosssell', 'upsell' ), true ) ? $context : 'fbt';
	}

	/**
	 * Build the display payload for a single recommended product.
	 *
	 * @since 2.2.5
	 * @param int $product_id Product ID.
	 * @return array<string,mixed>
	 */
	private function format_product( $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product instanceof \WC_Product || 'publish' !== $product->get_status() || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			return array();
		}

		return array(
			'id'          => $product_id,
			'name'        => wp_strip_all_tags( $product->get_name() ),
			'price_html'  => wp_kses_post( $product->get_price_html() ),
			'price'       => (float) wc_get_price_to_display( $product ),
			'image'       => wp_get_attachment_image_url( (int) $product->get_image_id(), 'woocommerce_thumbnail' ),
			'permalink'   => esc_url_raw( $product->get_permalink() ),
			'add_to_cart' => esc_url_raw( $product->add_to_cart_url() ),
			'type'        => $product->get_type(),
		);
	}
}
