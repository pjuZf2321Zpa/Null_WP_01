---
module: admin-core
---

# admin-core

## Responsibility

The Pro plugin's admin-side backend: it registers the `cartflows-pro/v1` REST controllers, the `wp_ajax_cartflows_pro_*` handlers, and the filters that inject Pro data (order bumps, offer next-steps, flow analytics, licence status, Pro global-settings fields) into the free plugin's React admin app. It owns reading and writing `wcf-order-bumps` postmeta and the admin JSON envelopes.

Ownership stops at business logic — pricing, relevance ranking, A/B runtime, analytics queries and default-meta schemas all live in `modules/` and `classes/`. Nothing here renders frontend output.

## Why it is this way

Pro has no admin app of its own; it contributes data and fields to the free plugin's React app, which is why `enqueue_pro_admin_app` reaches into WordPress's script registry to force itself ahead of the free handles rather than declaring a normal dependency.

The order-bump surface is served by two controllers that write the *same* postmeta through different paths: `MultipleOrderBump` filters every key through a default-meta whitelist and checks post type, while `MultipleOrderBumpAb` does neither. That split is historical rather than intentional, and it is the single most important thing to know before touching either.
