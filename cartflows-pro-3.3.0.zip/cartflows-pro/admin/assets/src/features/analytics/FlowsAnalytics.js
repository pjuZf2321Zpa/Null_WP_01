import { useEffect, useState, useCallback } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Button, Skeleton, Text, toast } from '@bsf/force-ui';
import { decode } from 'html-entities';
import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import apiFetch from '@wordpress/api-fetch';

import TotalPageViews from '@ProFeatures/dashboard/graphs/TotalPageViews';
import OfferRevenue from '@ProFeatures/dashboard/graphs/OfferRevenue';
import TotalRevenue from '@Features/dashboard/graphs/TotalRevenue';
import TotalOrders from '@Features/dashboard/graphs/TotalOrders';
import AverageOrderValue from '@ProFeatures/dashboard/graphs/AverageOrderValue';
import BumpOfferRevenue from '@ProFeatures/dashboard/graphs/BumpOfferRevenue';
import RevenuePerVisit from '@ProFeatures/dashboard/graphs/RevenuePerVisit';
import RevenuePerUniqueVisitor from '@ProFeatures/dashboard/graphs/RevenuePerUniqueVisitor';

import StatsCard, {
	STATS_TABPANEL_ID,
} from '@Features/analytics/common/StatsCard';
import AnalyticsHeader from '@Features/analytics/common/AnalyticsHeader';
import NoComparisonNote from '@ProFeatures/analytics/common/NoComparisonNote';
import FunnelsTable from '@ProFeatures/analytics/tables/FunnelsTable';
import { usePublishedFlows } from '@ProHooks/usePublishedFlows';
import {
	calculateTrend,
	getComparisonRangeLabel,
	getRangeLabel,
	hasComparisonBaseline,
	getDatesInRange,
	getComparisonPeriodOptions,
	toLocalYMD,
} from '@ProUtils/analytics-helpers';

/**
 * Funnel analytics screen — registered on the free plugin's analytics slot.
 *
 * @return {Object} Funnel analytics content.
 */
function FlowsAnalytics() {
	const [ { analyticsData }, dispatch ] = useSettingsStateValue();
	const flowStats = analyticsData?.flow_stats || {};
	const comparisonMetrics = flowStats?.comparison || [];
	const flowsConversions = analyticsData?.flow_stats?.flows_conversions;

	const [ currentTab, setCurrentTab ] = useState( 'total_visitors' );
	const [ dateRange, setDateRange ] = useState();
	const [ loading, setLoading ] = useState( true );
	const [ selectedFlow, setSelectedFlow ] = useState( {
		value: '',
		label: __( 'All Funnels', 'cartflows-pro' ),
	} );
	const [ comparisonPeriod, setComparisonPeriod ] =
		useState( 'previous-period' );

	// Track the current date range separately for API calls.
	const [ currentDateRange, setCurrentDateRange ] = useState( {
		from: null,
		to: null,
	} );

	const { flows, loading: flowsLoading } = usePublishedFlows();

	// Map stat graph types to comparison metric keys.
	const getComparisonKey = useCallback( ( graphType ) => {
		const keyMap = {
			total_visitors: 'total_visits',
			total_orders: 'total_orders',
			total_revenue: 'total_revenue_raw',
			avg_revenue: 'avg_order_value_raw',
			bump_revenue: 'total_bump_revenue_raw',
			offer_revenue: 'total_offers_revenue_raw',
			per_visit_revenue: 'revenue_per_visit_raw',
			per_unique_visitor_revenue: 'revenue_per_unique_visitor_raw',
		};
		return keyMap[ graphType ];
	}, [] );

	const fetchAnalytics = (
		dateFrom,
		dateTo,
		flowId = '',
		comparisonType = 'previous-period'
	) => {
		setLoading( true );

		const formData = new window.FormData();
		formData.append( 'date_to', dateTo );
		formData.append( 'date_from', dateFrom );

		if ( flowId ) {
			formData.append( 'flow_id', flowId );
		}

		formData.append( 'comparison_range_type', comparisonType );

		formData.append( 'screen_type', 'funnels' );
		formData.append( 'action', 'cartflows_get_all_flows_stats' );
		formData.append(
			'security',
			cartflows_admin.get_all_flows_stats_nonce
		);

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} )
			.then( ( response ) => {
				// A failed request (stale nonce) resolves without flow_stats — storing it crashes the charts.
				if ( response?.data?.flow_stats ) {
					dispatch( {
						type: 'SET_ANALYTICS_DATA',
						analyticsData: response.data,
					} );
				} else {
					toast.error(
						__(
							'Could not refresh analytics. Please reload the page and try again.',
							'cartflows-pro'
						)
					);
				}
				setLoading( false );
			} )
			.catch( () => {
				toast.error(
					__(
						'Could not load analytics. Check your connection and try again.',
						'cartflows-pro'
					)
				);
				setLoading( false );
			} );
	};

	const setRange = function () {
		const date_to = new Date();
		const date_from = new Date();
		date_from.setDate( date_from.getDate() - 7 );
		setDateRange( getDatesInRange( date_from, date_to ) );
	};

	const stats = [
		{
			name: __( 'Total Visitors', 'cartflows-pro' ),
			stat: flowStats?.total_visits ?? 0,
			stat_raw: null,
			tooltip: __(
				'This shows the total number of times people visited any step in your funnel.',
				'cartflows-pro'
			),
			graphType: 'total_visitors',
		},
		{
			name: __( 'Total Orders', 'cartflows-pro' ),
			stat: flowStats?.total_orders ?? 0,
			stat_raw: null,
			tooltip: __(
				'This shows the total number of orders placed through your CartFlows checkout pages.',
				'cartflows-pro'
			),
			graphType: 'total_orders',
		},
		{
			name: __( 'Total Revenue', 'cartflows-pro' ),
			stat: flowStats?.total_revenue ?? 0,
			stat_raw: flowStats?.total_revenue_raw ?? 0,
			tooltip: __(
				'This shows the total amount of money earned from all steps combined.',
				'cartflows-pro'
			),
			graphType: 'total_revenue',
		},
		{
			name: __( 'Avg. Order Value', 'cartflows-pro' ),
			stat: flowStats?.avg_order_value ?? 0,
			stat_raw: flowStats?.avg_order_value_raw ?? 0,
			tooltip: __(
				'Average value of each order (Total Revenue / Total Orders).',
				'cartflows-pro'
			),
			graphType: 'avg_revenue',
		},
		{
			name: __( 'Bump Revenue', 'cartflows-pro' ),
			stat: flowStats?.total_bump_revenue ?? 0,
			stat_raw: flowStats?.total_bump_revenue_raw ?? 0,
			tooltip: __(
				'This shows the total amount of money earned from all order bump offers.',
				'cartflows-pro'
			),
			graphType: 'bump_revenue',
		},
		{
			name: __( 'Offer Revenue', 'cartflows-pro' ),
			stat: flowStats?.total_offers_revenue ?? 0,
			stat_raw: flowStats?.total_offers_revenue_raw ?? 0,
			tooltip: __(
				'This shows the total amount of money earned from your Upsell and Downsell offers.',
				'cartflows-pro'
			),
			graphType: 'offer_revenue',
		},
		{
			name: __( 'Revenue Per Visit', 'cartflows-pro' ),
			stat: flowStats?.revenue_per_visit ?? 0,
			stat_raw: flowStats?.revenue_per_visit_raw ?? 0,
			tooltip: __(
				'Revenue per each visit (Total Revenue / Total Visitors).',
				'cartflows-pro'
			),
			graphType: 'per_visit_revenue',
		},
		{
			name: __( 'Revenue Per Customer', 'cartflows-pro' ),
			stat: flowStats?.revenue_per_unique_visitor ?? 0,
			stat_raw: flowStats?.revenue_per_unique_visitor_raw ?? 0,
			tooltip: __(
				'Average revenue per unique paying customer (Total Revenue / Unique Customers).',
				'cartflows-pro'
			),
			graphType: 'per_unique_visitor_revenue',
		},
	];

	const renderGraphs = function () {
		let graph = '';
		if ( ! dateRange ) {
			setRange();
		}
		switch ( currentTab ) {
			case 'total_visitors':
				graph = (
					<TotalPageViews
						dateRange={ dateRange }
						analyticsData={ analyticsData }
					/>
				);
				break;
			case 'total_revenue':
				graph = <TotalRevenue dateRange={ dateRange } />;
				break;
			case 'total_orders':
				graph = <TotalOrders dateRange={ dateRange } />;
				break;
			case 'offer_revenue':
				graph = (
					<OfferRevenue
						dateRange={ dateRange }
						analyticsData={ analyticsData }
					/>
				);
				break;
			case 'avg_revenue':
				graph = <AverageOrderValue dateRange={ dateRange } />;
				break;
			case 'bump_revenue':
				graph = <BumpOfferRevenue dateRange={ dateRange } />;
				break;
			case 'per_visit_revenue':
				graph = <RevenuePerVisit dateRange={ dateRange } />;
				break;
			case 'per_unique_visitor_revenue':
				graph = <RevenuePerUniqueVisitor dateRange={ dateRange } />;
				break;
			default:
				graph = (
					<TotalPageViews
						dateRange={ dateRange }
						analyticsData={ analyticsData }
					/>
				);
				break;
		}
		return graph;
	};

	const handleDateSubmit = function ( date ) {
		const date_from = new Date( date.startDate );
		const date_to = new Date( date.endDate );

		setDateRange( getDatesInRange( date_from, date_to ) );

		const date_from_str = toLocalYMD( date_from );
		const date_to_str = toLocalYMD( date_to );

		setCurrentDateRange( { from: date_from_str, to: date_to_str } );

		fetchAnalytics(
			date_from_str,
			date_to_str,
			selectedFlow.value,
			comparisonPeriod
		);
	};

	// Initial load — only runs once on mount.
	useEffect( () => {
		const date_to = new Date();
		const date_from = new Date();
		date_from.setDate( date_from.getDate() - 7 );

		setDateRange( getDatesInRange( date_from, date_to ) );

		const date_from_str = toLocalYMD( date_from );
		const date_to_str = toLocalYMD( date_to );

		setCurrentDateRange( { from: date_from_str, to: date_to_str } );

		fetchAnalytics( date_from_str, date_to_str, '', comparisonPeriod );
	}, [ dispatch ] );

	// Refetch graphs when the selected funnel changes.
	useEffect( () => {
		if ( ! currentDateRange.from || ! currentDateRange.to ) {
			return;
		}

		fetchAnalytics(
			currentDateRange.from,
			currentDateRange.to,
			selectedFlow.value,
			comparisonPeriod
		);
	}, [ selectedFlow ] );

	// Refetch when the comparison period changes.
	useEffect( () => {
		if ( ! currentDateRange.from || ! currentDateRange.to ) {
			return;
		}

		fetchAnalytics(
			currentDateRange.from,
			currentDateRange.to,
			selectedFlow.value,
			comparisonPeriod
		);
	}, [ comparisonPeriod ] );

	const currentDate = new Date();
	const toDate = toLocalYMD( currentDate );
	currentDate.setDate( currentDate.getDate() - 7 );
	const fromDate = toLocalYMD( currentDate );

	const comparisonPeriodOptions = getComparisonPeriodOptions( __ );

	const hasNoData =
		0 === ( flowStats?.total_visits ?? 0 ) &&
		0 === ( flowStats?.total_orders ?? 0 );

	// Offer the widen-range shortcut only while it would actually widen anything.
	const selectedRangeDays =
		currentDateRange.from && currentDateRange.to
			? Math.round(
					( new Date( currentDateRange.to ) -
						new Date( currentDateRange.from ) ) /
						86400000
			  ) + 1
			: 7;
	const canWidenRange = selectedRangeDays < 30;

	// The API returns every funnel regardless of flow_id — scope the table to the selected one client-side.
	const isFunnelScoped = '' !== selectedFlow.value;
	const scopedFlowsConversions =
		isFunnelScoped && flowsConversions
			? Object.values( flowsConversions ).filter(
					( flow ) =>
						String( flow?.flow_id ) === String( selectedFlow.value )
			  )
			: flowsConversions;

	// An empty baseline would paint every card "New" — say it once in the header instead.
	const hasComparisonData = hasComparisonBaseline( comparisonMetrics );
	const comparisonLabel = getComparisonRangeLabel(
		currentDateRange.from,
		currentDateRange.to,
		comparisonPeriod
	);
	const showNoComparisonNote =
		analyticsData && ! loading && ! hasNoData && ! hasComparisonData;

	const activeStat = stats.find( ( s ) => s.graphType === currentTab );
	const chartLabel = sprintf(
		/* translators: 1: metric name, 2: formatted date range */
		__( '%1$s by day, %2$s', 'cartflows-pro' ),
		activeStat?.name || __( 'Total Visitors', 'cartflows-pro' ),
		getRangeLabel(
			currentDateRange.from || fromDate,
			currentDateRange.to || toDate
		)
	);

	return (
		<>
			<section aria-labelledby="section-1-title">
				<div className="p-6 rounded-xl bg-background-primary shadow-sm flex flex-col gap-3 justify-center h-full">
					<AnalyticsHeader
						title={ __( 'Funnel Analytics', 'cartflows-pro' ) }
						selectedFlow={ selectedFlow }
						onFlowChange={ setSelectedFlow }
						flowOptions={ flows }
						flowsLoading={ flowsLoading }
						dateValue={ {
							endDate: currentDateRange.to || toDate,
							startDate: currentDateRange.from || fromDate,
						} }
						onDateChange={ handleDateSubmit }
						comparisonPeriod={ comparisonPeriod }
						onComparisonPeriodChange={ setComparisonPeriod }
						comparisonPeriodOptions={ comparisonPeriodOptions }
					/>
					{ showNoComparisonNote && (
						<NoComparisonNote comparisonLabel={ comparisonLabel } />
					) }
					<div className="p-3 flex flex-col gap-3 bg-background-secondary rounded-lg">
						<div className="wcf-analytics--stats-tabs-container">
							<div className="wcf-analytics--stats-tabs m-0">
								<div
									role="tablist"
									aria-busy={ loading }
									className={ `gap-3 grid grid-cols-2 md:grid-cols-4 w-full box-border transition-opacity ${
										loading
											? 'opacity-50 animate-pulse pointer-events-none'
											: ''
									}` }
								>
									{ stats.map( ( item ) => {
										const comparisonKey = getComparisonKey(
											item.graphType
										);
										const comparisonValue =
											comparisonMetrics?.[
												comparisonKey
											] || 0;
										const trend = hasComparisonData
											? {
													...calculateTrend(
														item?.stat_raw !== null
															? item?.stat_raw
															: item?.stat,
														comparisonValue
													),
													baselineLabel:
														comparisonLabel,
													isCurrency:
														item?.stat_raw !== null,
											  }
											: {
													percentage: 0,
													isIncrease: true,
											  };

										return (
											<StatsCard
												key={ item.name }
												item={ item }
												isActive={
													currentTab ===
													item.graphType
												}
												onClick={ () =>
													setCurrentTab(
														item.graphType
													)
												}
												trend={ trend }
											/>
										);
									} ) }
								</div>
							</div>
						</div>

						<div className="bg-background-primary rounded-lg shadow-sm">
							{ ( loading || ! analyticsData ) && (
								<Skeleton
									variant="rectangular"
									className="h-[305px] w-full rounded"
								/>
							) }
							{ analyticsData && ! loading && hasNoData && (
								<div className="flex flex-col items-center justify-center gap-2 h-[305px] text-center px-4">
									<Text size={ 16 } weight={ 600 }>
										{ __(
											'No visits recorded for this period yet',
											'cartflows-pro'
										) }
									</Text>
									<Text
										size={ 14 }
										weight={ 400 }
										color="secondary"
									>
										{ canWidenRange
											? __(
													'Analytics appear once your funnel pages get visits. Try a wider date range, or check back after your store gets traffic.',
													'cartflows-pro'
											  )
											: __(
													'Analytics appear once your funnel pages get visits. Check back after your store gets traffic.',
													'cartflows-pro'
											  ) }
									</Text>
									{ canWidenRange && (
										<Button
											variant="primary"
											size="sm"
											className="mt-2"
											onClick={ () => {
												const endDate = new Date();
												const startDate = new Date();
												startDate.setDate(
													startDate.getDate() - 30
												);
												handleDateSubmit( {
													startDate,
													endDate,
												} );
											} }
										>
											{ __(
												'View Last 30 Days',
												'cartflows-pro'
											) }
										</Button>
									) }
								</div>
							) }
							{ analyticsData && ! loading && ! hasNoData && (
								<div
									className="wcf-analytics--tab-content"
									role="tabpanel"
									id={ STATS_TABPANEL_ID }
									aria-labelledby={ `wcf-analytics-tab-${ currentTab }` }
								>
									<div role="group" aria-label={ chartLabel }>
										{ renderGraphs() }
									</div>
								</div>
							) }
						</div>
					</div>
				</div>

				<FunnelsTable
					flowsConversions={ scopedFlowsConversions }
					loading={ loading }
					title={ isFunnelScoped ? decode( selectedFlow.label ) : '' }
					isScoped={ isFunnelScoped }
				/>
			</section>
		</>
	);
}

export default FlowsAnalytics;
