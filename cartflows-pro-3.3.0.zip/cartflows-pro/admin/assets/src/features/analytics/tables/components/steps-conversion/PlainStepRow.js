import { buildMetricCells } from '@Features/analytics/shared/ab-data';
import NoteIcon from './NoteIcon';
import StepRow from './StepRow';

function PlainStepRow( { rowKey, flow } ) {
	const stats = flow?.visits;
	const label = stats?.title || flow?.title || flow?.name || '-';
	return (
		<StepRow
			rowKey={ rowKey }
			label={
				<>
					<span>{ label }</span>
					<NoteIcon note={ stats?.note } />
				</>
			}
			cells={ buildMetricCells( stats, flow?.type ) }
		/>
	);
}

export default PlainStepRow;
