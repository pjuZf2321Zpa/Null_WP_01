import { Table } from '@bsf/force-ui';
import analyticsEmptyFunnel from '@Images/analytics-empty-funnel.png';
import { HEADERS } from './constants';

function EmptyStateRow( { title, subtitle } ) {
	return (
		<Table.Row>
			<Table.Cell colSpan={ HEADERS.length } className="py-12">
				<div className="flex flex-col items-center gap-3">
					<img
						src={ analyticsEmptyFunnel }
						alt=""
						width="78"
						height="72"
					/>
					<div className="flex flex-col items-center gap-1">
						<p className="text-lg font-semibold text-text-primary m-0">
							{ title }
						</p>
						<p className="text-sm text-text-tertiary m-0">
							{ subtitle }
						</p>
					</div>
				</div>
			</Table.Cell>
		</Table.Row>
	);
}

export default EmptyStateRow;
