import { Badge } from '@bsf/force-ui';
import { buildMetricCells } from '@Features/analytics/shared/ab-data';
import NoteIcon from './NoteIcon';
import StepRow from './StepRow';

function AbArchivedRow( { rowKey, flow, variation } ) {
	return (
		<StepRow
			rowKey={ rowKey }
			rowClass="bg-background-secondary"
			label={
				<div className="flex items-center gap-2 pl-6">
					<span>{ variation?.title || '-' }</span>
					{ variation?.archived_date && (
						<Badge
							label={ variation.archived_date }
							size="xs"
							variant="inverse"
							type="rounded"
							disableHover
						/>
					) }
					<NoteIcon note={ variation?.note } />
				</div>
			}
			cells={ buildMetricCells( variation, flow?.type, true ) }
		/>
	);
}

export default AbArchivedRow;
