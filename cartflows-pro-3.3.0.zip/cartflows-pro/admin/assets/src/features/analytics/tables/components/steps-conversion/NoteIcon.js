import { Tooltip } from '@bsf/force-ui';
import { HelpCircle } from 'lucide-react';

function NoteIcon( { note } ) {
	if ( ! note ) {
		return null;
	}
	return (
		<Tooltip content={ note } placement="top" arrow>
			<HelpCircle className="w-3.5 h-3.5 text-text-tertiary" />
		</Tooltip>
	);
}

export default NoteIcon;
