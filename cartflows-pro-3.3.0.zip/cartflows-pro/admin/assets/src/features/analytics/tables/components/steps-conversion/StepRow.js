import { Table } from '@bsf/force-ui';
import MetricCells from './MetricCells';

function StepRow( { rowKey, label, cells, rowClass = '' } ) {
	return (
		<Table.Row className={ rowClass }>
			<Table.Cell className="whitespace-nowrap font-medium">
				<div className="flex items-center gap-2">{ label }</div>
			</Table.Cell>
			<MetricCells cells={ cells } rowKey={ rowKey } />
		</Table.Row>
	);
}

export default StepRow;
