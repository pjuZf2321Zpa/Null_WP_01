import { useMemo } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Table, Title } from '@bsf/force-ui';
import useAbAccordion from '@Features/analytics/shared/useAbAccordion';
import { HEADERS } from './components/steps-conversion/constants';
import EmptyStateRow from './components/steps-conversion/EmptyStateRow';
import renderStepEntry from './components/steps-conversion/renderStepEntry';

function StepsConversionTable( { flowStats, selectedFlow } ) {
	const stepsVisits = flowStats?.steps_conversion?.visits || [];
	const [ expanded, toggle ] = useAbAccordion();

	const rows = useMemo(
		() =>
			stepsVisits.flatMap( ( flow, idx ) =>
				renderStepEntry( flow, idx, expanded, toggle )
			),
		[ stepsVisits, expanded, toggle ]
	);

	const renderBody = () => {
		if ( ! selectedFlow.value ) {
			return (
				<EmptyStateRow
					title={ __(
						'Select a funnel to view step conversions',
						'cartflows-pro'
					) }
					subtitle={ __(
						'See how visitors move through your funnels and convert at each step.',
						'cartflows-pro'
					) }
				/>
			);
		}
		if ( ! stepsVisits?.length ) {
			return (
				<EmptyStateRow
					title={ __( 'No data available', 'cartflows-pro' ) }
					subtitle={ __(
						'There is no conversion data for the selected funnel and date range.',
						'cartflows-pro'
					) }
				/>
			);
		}
		return rows;
	};

	return (
		<div className="mt-8 bg-background-primary rounded-xl shadow-sm p-6">
			<Title
				size="sm"
				tag="h2"
				title={
					flowStats?.steps_conversion?.flow_name ||
					__( 'Funnel Name', 'cartflows-pro' )
				}
				className="[&_h2]:text-text-primary mb-4"
			/>
			<div className="overflow-x-auto">
				<Table className="min-w-full">
					<Table.Head>
						{ HEADERS.map( ( h ) => (
							<Table.HeadCell key={ h }>{ h }</Table.HeadCell>
						) ) }
					</Table.Head>
					<Table.Body>{ renderBody() }</Table.Body>
				</Table>
			</div>
		</div>
	);
}

export default StepsConversionTable;
