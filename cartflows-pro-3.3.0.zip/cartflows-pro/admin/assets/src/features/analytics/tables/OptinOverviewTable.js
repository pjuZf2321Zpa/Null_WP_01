import { useMemo } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import parse from 'html-react-parser';
import { Table, Title } from '@bsf/force-ui';
import analyticsEmptyFunnel from '@Images/analytics-empty-overview.png';

function OptinOverviewTable( { optinFlowConversions } ) {
	// Memoize the table to only re-render when optinFlowConversions changes
	const optinTable = useMemo( () => {
		return (
			optinFlowConversions &&
			Object.values( optinFlowConversions ).map( ( optin, idx ) => (
				<Table.Row key={ optin?.step_id || idx }>
					<Table.Cell className="whitespace-nowrap font-medium">
						{ parse( optin?.flow_title || '(no title)' ) }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ parse( optin?.step_title || '(no title)' ) }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ optin?.optin_form }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap !hidden">
						{ optin?.popup }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap !hidden">
						{ optin?.lead_magnets }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ optin?.conversion_rate + '%' }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap !hidden">
						{ optin?.date_time }
					</Table.Cell>
				</Table.Row>
			) )
		);
	}, [ optinFlowConversions ] );

	const renderOptinTableBody = () => {
		if (
			! optinFlowConversions ||
			Object.keys( optinFlowConversions ).length === 0
		) {
			return (
				<Table.Row>
					<Table.Cell colSpan={ 4 } className="py-12">
						<div className="flex flex-col items-center gap-3">
							<img
								src={ analyticsEmptyFunnel }
								alt=""
								width="78"
								height="72"
							/>
							<div className="flex flex-col items-center gap-1">
								<p className="text-lg font-semibold text-text-primary m-0">
									{ __(
										'View how visitors convert across opt-in step.',
										'cartflows-pro'
									) }
								</p>
								<p className="text-sm text-text-tertiary m-0">
									{ __(
										'Analytics data will appear here once your funnels start receiving traffic.',
										'cartflows-pro'
									) }
								</p>
							</div>
						</div>
					</Table.Cell>
				</Table.Row>
			);
		}
		return optinTable;
	};

	return (
		<div className="mt-8 bg-background-primary rounded-xl shadow-sm p-6">
			<Title
				size="sm"
				tag="h2"
				title={ __( 'Overview', 'cartflows-pro' ) }
				className="[&_h2]:text-text-primary mb-4"
			/>
			<div className="overflow-x-auto">
				<Table className="min-w-full">
					<Table.Head>
						<Table.HeadCell>
							{ __( 'Funnel Name', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell>
							{ __( 'Opt-in Step', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell>
							{ __( 'Opt-in Form', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="!hidden">
							{ __( 'Popup', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="!hidden">
							{ __( 'Lead Magnets', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell>
							{ __( 'Conversion Rate', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="!hidden">
							{ __( 'Date & Time', 'cartflows-pro' ) }
						</Table.HeadCell>
					</Table.Head>
					<Table.Body>{ renderOptinTableBody() }</Table.Body>
				</Table>
			</div>
		</div>
	);
}

export default OptinOverviewTable;
