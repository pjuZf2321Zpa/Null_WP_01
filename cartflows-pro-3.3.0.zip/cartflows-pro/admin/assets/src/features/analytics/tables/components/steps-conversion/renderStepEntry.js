import { getAbEntries } from '@Features/analytics/shared/ab-data';
import PlainStepRow from './PlainStepRow';
import AbParentRow from './AbParentRow';
import AbVariationRow from './AbVariationRow';
import AbArchivedRow from './AbArchivedRow';

export default function renderStepEntry( flow, idx, expanded, onToggle ) {
	const parentKey = flow?.id || `step-${ idx }`;
	const { variations, archived, isAbStep } = getAbEntries( flow );

	if ( ! isAbStep ) {
		return [
			<PlainStepRow
				key={ parentKey }
				rowKey={ parentKey }
				flow={ flow }
			/>,
		];
	}

	const isExpanded = expanded.has( parentKey );
	const rows = [
		<AbParentRow
			key={ parentKey }
			rowKey={ parentKey }
			flow={ flow }
			isExpanded={ isExpanded }
			onToggle={ () => onToggle( parentKey ) }
		/>,
	];

	if ( ! isExpanded ) {
		return rows;
	}

	variations.forEach( ( [ stepId, variation ], vIdx ) => {
		const k = `${ parentKey }-ab-${ stepId }`;
		rows.push(
			<AbVariationRow
				key={ k }
				rowKey={ k }
				flow={ flow }
				stepId={ stepId }
				variation={ variation }
				vIdx={ vIdx }
			/>
		);
	} );

	archived.forEach( ( [ stepId, variation ] ) => {
		const k = `${ parentKey }-arc-${ stepId }`;
		rows.push(
			<AbArchivedRow
				key={ k }
				rowKey={ k }
				flow={ flow }
				variation={ variation }
			/>
		);
	} );

	return rows;
}
