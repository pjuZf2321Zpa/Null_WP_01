import { Badge } from '@bsf/force-ui';
import {
	buildMetricCells,
	getVariationPill,
} from '@Features/analytics/shared/ab-data';
import NoteIcon from './NoteIcon';
import StepRow from './StepRow';

function AbVariationRow( { rowKey, flow, stepId, variation, vIdx } ) {
	const pill = getVariationPill( stepId, flow?.id, vIdx );
	return (
		<StepRow
			rowKey={ rowKey }
			rowClass="bg-background-secondary"
			label={
				<div className="flex items-center gap-2 pl-6">
					<span>{ variation?.title || '-' }</span>
					<Badge
						label={ pill.label }
						size="xs"
						variant={ pill.variant }
						type="rounded"
						disableHover
					/>
					<NoteIcon note={ variation?.note } />
				</div>
			}
			cells={ buildMetricCells( variation, flow?.type, true ) }
		/>
	);
}

export default AbVariationRow;
