import { Table } from '@bsf/force-ui';

function MetricCells( { cells, rowKey } ) {
	return cells.map( ( cell, i ) => (
		<Table.Cell
			key={ `${ rowKey }-c-${ i }` }
			className="whitespace-nowrap"
		>
			{ cell }
		</Table.Cell>
	) );
}

export default MetricCells;
