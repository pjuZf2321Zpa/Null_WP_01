import { useMemo } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import parse from 'html-react-parser';
import { Table, Title, Badge } from '@bsf/force-ui';
import analyticsEmptyProduct from '@Images/analytics-empty-product.png';

function ProductConversionTable( { flowStats, selectedFlow } ) {
	const productConversions = flowStats?.products || [];

	const renderProductTypeBadge = ( productType ) => {
		if ( ! productType ) {
			return null;
		}

		return (
			<Badge
				label={ productType }
				size="xs"
				type="pill"
				variant="neutral"
				className="capitalize"
				disableHover
			/>
		);
	};

	// Memoize the product conversions table
	const productConversionsTable = useMemo( () => {
		return (
			productConversions &&
			productConversions.map( ( product, idx ) => {
				const datarow = [
					product?.total_orders ? product?.total_orders : '0',
					product?.conversions ? product?.conversions : '0',
					product?.conversion_rate
						? product?.conversion_rate + ' %'
						: '0 %',
					parse( product?.revenue ),
				];

				return (
					<Table.Row key={ product?.product_id || idx }>
						<Table.Cell className="whitespace-nowrap font-medium">
							<div className="flex items-center gap-2">
								<span>
									{ product?.product_title ||
										product?.name ||
										'-' }
								</span>
								{ product?.product_type &&
									renderProductTypeBadge(
										product.product_type
									) }
							</div>
						</Table.Cell>
						{ datarow.map( ( dataitem, index ) => (
							<Table.Cell
								className="whitespace-nowrap"
								key={ index }
							>
								{ dataitem }
							</Table.Cell>
						) ) }
					</Table.Row>
				);
			} )
		);
	}, [ productConversions ] );

	// Render function for product table body content
	const renderProductTableBody = () => {
		if ( ! selectedFlow.value ) {
			return (
				<Table.Row>
					<Table.Cell colSpan={ 5 } className="py-12">
						<div className="flex flex-col items-center gap-3">
							<img
								src={ analyticsEmptyProduct }
								alt=""
								width="86"
								height="72"
							/>
							<div className="flex flex-col items-center gap-1">
								<p className="text-lg font-semibold text-text-primary m-0">
									{ __(
										'Select a funnel to view product conversions',
										'cartflows-pro'
									) }
								</p>
								<p className="text-sm text-text-tertiary m-0">
									{ __(
										'Product conversion metrics for items sold through your funnels will appear here.',
										'cartflows-pro'
									) }
								</p>
							</div>
						</div>
					</Table.Cell>
				</Table.Row>
			);
		}

		if ( ! productConversions || productConversions.length === 0 ) {
			return (
				<Table.Row>
					<Table.Cell colSpan={ 5 } className="py-12">
						<div className="flex flex-col items-center gap-3">
							<img
								src={ analyticsEmptyProduct }
								alt=""
								width="86"
								height="72"
							/>
							<div className="flex flex-col items-center gap-1">
								<p className="text-lg font-semibold text-text-primary m-0">
									{ __(
										'No data available',
										'cartflows-pro'
									) }
								</p>
								<p className="text-sm text-text-tertiary m-0">
									{ __(
										'There are no product conversion records for the selected filters.',
										'cartflows-pro'
									) }
								</p>
							</div>
						</div>
					</Table.Cell>
				</Table.Row>
			);
		}

		return productConversionsTable;
	};

	return (
		<div className="mt-8 bg-background-primary rounded-xl shadow-sm p-6">
			<Title
				size="sm"
				tag="h2"
				title={ __( 'Product Details', 'cartflows-pro' ) }
				className="[&_h2]:text-text-primary mb-4"
			/>
			<div className="overflow-x-auto">
				<Table className="min-w-full">
					<Table.Head>
						<Table.HeadCell>
							{ __( 'Product Name', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell>
							{ __( 'No. of Orders', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell>
							{ __( 'Conversions', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell>
							{ __( 'Conversion Rate', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell>
							{ __( 'Revenue', 'cartflows-pro' ) }
						</Table.HeadCell>
					</Table.Head>
					<Table.Body>{ renderProductTableBody() }</Table.Body>
				</Table>
			</div>
		</div>
	);
}

export default ProductConversionTable;
