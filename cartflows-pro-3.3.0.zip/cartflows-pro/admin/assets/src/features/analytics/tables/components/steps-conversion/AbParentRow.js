import { __ } from '@wordpress/i18n';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { buildMetricCells } from '@Features/analytics/shared/ab-data';
import NoteIcon from './NoteIcon';
import StepRow from './StepRow';

function AbParentRow( { rowKey, flow, isExpanded, onToggle } ) {
	const stats = flow?.visits;
	const label = stats?.title || flow?.title || flow?.name || '-';
	const Chevron = isExpanded ? ChevronDown : ChevronRight;

	return (
		<StepRow
			rowKey={ rowKey }
			label={
				<button
					type="button"
					className="flex items-center gap-2 bg-transparent border-0 p-0 cursor-pointer text-text-primary"
					onClick={ onToggle }
					aria-expanded={ isExpanded }
					aria-label={
						isExpanded
							? __( 'Collapse variations', 'cartflows-pro' )
							: __( 'Expand variations', 'cartflows-pro' )
					}
				>
					<Chevron className="w-4 h-4 text-text-tertiary" />
					<span>{ label }</span>
					<NoteIcon note={ stats?.note } />
				</button>
			}
			cells={ buildMetricCells( stats, flow?.type ) }
		/>
	);
}

export default AbParentRow;
