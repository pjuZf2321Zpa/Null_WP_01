import { __ } from '@wordpress/i18n';

export const HEADERS = [
	__( 'Steps', 'cartflows-pro' ),
	__( 'Total Visits', 'cartflows-pro' ),
	__( 'Unique Visits', 'cartflows-pro' ),
	__( 'Conversions', 'cartflows-pro' ),
	__( 'Conversion Rate', 'cartflows-pro' ),
	__( 'Revenue', 'cartflows-pro' ),
];
