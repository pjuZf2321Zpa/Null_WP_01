import { useMemo } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import parse from 'html-react-parser';
import { Table, Text, Title } from '@bsf/force-ui';
import analyticsEmptyFunnels from '@Images/analytics-empty-funnels.png';
import { formatPercent } from '@Features/analytics/common/format';

// Numbers read faster right-aligned with fixed-width digits.
const NUM_CELL = 'whitespace-nowrap text-right tabular-nums';

function FunnelsTable( {
	flowsConversions,
	loading = false,
	title = '',
	isScoped = false,
} ) {
	// Memoize the table to only re-render when flowsConversions changes
	const funnelsTable = useMemo( () => {
		if ( ! flowsConversions ) {
			return null;
		}
		// Active funnels first so 0-visit rows don't bury the real data.
		const sorted = Object.values( flowsConversions ).sort(
			( a, b ) =>
				( b?.conversions || 0 ) - ( a?.conversions || 0 ) ||
				( b?.total_visits || 0 ) - ( a?.total_visits || 0 )
		);
		return sorted.map( ( flow, idx ) => (
			<Table.Row key={ flow?.flow_id || idx }>
				<Table.Cell className="whitespace-nowrap font-medium">
					{ parse( flow?.flow_title || '(no title)' ) }
				</Table.Cell>
				<Table.Cell className={ NUM_CELL }>
					{ flow?.total_visits }
				</Table.Cell>
				<Table.Cell className={ NUM_CELL }>
					{ flow?.unique_visits }
				</Table.Cell>
				<Table.Cell className={ NUM_CELL }>
					{ flow?.conversions }
				</Table.Cell>
				<Table.Cell className={ NUM_CELL }>
					{ formatPercent( flow?.conversion_rate ) }
				</Table.Cell>
				<Table.Cell className={ NUM_CELL }>
					{ parse( flow?.revenue ) }
				</Table.Cell>
			</Table.Row>
		) );
	}, [ flowsConversions ] );

	return (
		<div className="mt-8 bg-background-primary rounded-xl shadow-sm p-6">
			<Title
				size="sm"
				tag="h2"
				title={ title || __( 'All Funnels', 'cartflows-pro' ) }
				className="[&_h2]:text-text-primary mb-4"
			/>
			<div
				aria-busy={ loading }
				className={ `transition-opacity ${
					loading
						? 'opacity-50 animate-pulse pointer-events-none'
						: ''
				}` }
			>
				<Table className="min-w-full">
					<Table.Head>
						<Table.HeadCell>
							{ __( 'Funnel Name', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="text-right">
							{ __( 'Total Visits', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="text-right">
							{ __( 'Unique Visits', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="text-right">
							{ __( 'Conversions', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="text-right">
							{ __( 'Conversion Rate', 'cartflows-pro' ) }
						</Table.HeadCell>
						<Table.HeadCell className="text-right">
							{ __( 'Revenue', 'cartflows-pro' ) }
						</Table.HeadCell>
					</Table.Head>
					<Table.Body>
						{ ! flowsConversions ||
						Object.keys( flowsConversions ).length === 0 ? (
							<Table.Row>
								<Table.Cell colSpan={ 6 } className="py-12">
									<div className="flex flex-col items-center gap-3">
										<img
											src={ analyticsEmptyFunnels }
											alt=""
											width="78"
											height="72"
										/>
										<div className="flex flex-col items-center gap-1 text-center">
											<Text size={ 18 } weight={ 600 }>
												{ isScoped
													? __(
															'No data for this funnel in the selected period',
															'cartflows-pro'
													  )
													: __(
															'Find all the funnel analytics here',
															'cartflows-pro'
													  ) }
											</Text>
											<Text
												size={ 14 }
												weight={ 400 }
												color="tertiary"
											>
												{ isScoped
													? __(
															'Try a wider date range or switch back to All Funnels.',
															'cartflows-pro'
													  )
													: __(
															'Set up funnels to start tracking their performance and view analytics here.',
															'cartflows-pro'
													  ) }
											</Text>
										</div>
									</div>
								</Table.Cell>
							</Table.Row>
						) : (
							funnelsTable
						) }
					</Table.Body>
				</Table>
			</div>
		</div>
	);
}

export default FunnelsTable;
