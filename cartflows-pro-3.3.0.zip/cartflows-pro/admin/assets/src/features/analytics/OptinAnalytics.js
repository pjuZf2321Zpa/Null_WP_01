import { useEffect, useState, useMemo, useCallback } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Skeleton } from '@bsf/force-ui';
import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import apiFetch from '@wordpress/api-fetch';

import OptinTotalSubmissions from '@ProFeatures/dashboard/graphs/OptinTotalSubmissions';
import OptinConversionRate from '@ProFeatures/dashboard/graphs/OptinConversionRate';
import OptinListGrowth from '@ProFeatures/dashboard/graphs/OptinListGrowth';

import StatsCard, {
	STATS_TABPANEL_ID,
} from '@Features/analytics/common/StatsCard';
import NoComparisonNote from '@ProFeatures/analytics/common/NoComparisonNote';
import AnalyticsHeader from '@Features/analytics/common/AnalyticsHeader';
import OptinOverviewTable from '@ProFeatures/analytics/tables/OptinOverviewTable';
import { usePublishedFlows } from '@ProHooks/usePublishedFlows';
import {
	calculateTrend,
	getComparisonRangeLabel,
	getDatesInRange,
	hasComparisonBaseline,
	getComparisonPeriodOptions,
	toLocalYMD,
} from '@ProUtils/analytics-helpers';

/**
 * Opt-in analytics screen — registered on the free plugin's analytics slot.
 *
 * @return {Object} Opt-in analytics content.
 */
function OptinAnalytics() {
	const [ { analyticsData }, dispatch ] = useSettingsStateValue();
	const optinConversionsAnalytics = analyticsData?.flow_stats;
	const optinFlowConversions =
		analyticsData?.flow_stats?.optin_flow_conversions;
	const comparisonMetrics = analyticsData?.flow_stats?.comparison || [];
	const [ currentTab, setCurrentTab ] = useState( 'total_submissions' );
	const [ dateRange, setDateRange ] = useState();
	const [ loading, setLoading ] = useState( true );
	const [ selectedFlow, setSelectedFlow ] = useState( {
		value: '',
		label: __( 'All Funnels', 'cartflows-pro' ),
	} );
	const [ comparisonPeriod, setComparisonPeriod ] =
		useState( 'previous-period' );

	// Track the current date range separately for API calls.
	const [ currentDateRange, setCurrentDateRange ] = useState( {
		from: null,
		to: null,
	} );

	const [ isInitialLoadComplete, setIsInitialLoadComplete ] =
		useState( false );

	const { flows, loading: flowsLoading } = usePublishedFlows();

	// Map stat graph types to comparison metric keys.
	const getComparisonKey = useCallback( ( graphType ) => {
		const keyMap = {
			total_submissions: 'total_submissions',
			conversion_rate: 'conversion_rate',
		};
		return keyMap[ graphType ];
	}, [] );

	const fetchAnalytics = useCallback(
		(
			dateFrom,
			dateTo,
			flowId = '',
			comparisonType = 'previous-period'
		) => {
			setLoading( true );

			const formData = new window.FormData();
			formData.append( 'date_to', dateTo );
			formData.append( 'date_from', dateFrom );

			if ( flowId ) {
				formData.append( 'flow_id', flowId );
			}

			formData.append( 'comparison_range_type', comparisonType );

			formData.append( 'screen_type', 'optins' );
			formData.append( 'action', 'cartflows_get_all_flows_stats' );
			formData.append(
				'security',
				cartflows_admin.get_all_flows_stats_nonce
			);

			apiFetch( {
				url: cartflows_admin.ajax_url,
				method: 'POST',
				body: formData,
			} ).then( ( response ) => {
				// A failed request (stale nonce) resolves without flow_stats — storing it crashes the charts.
				if ( response?.data?.flow_stats ) {
					dispatch( {
						type: 'SET_ANALYTICS_DATA',
						analyticsData: response.data,
					} );
				}
				setLoading( false );
			} );
		},
		[ dispatch ]
	);

	const handleDateSubmit = useCallback(
		( { startDate, endDate } ) => {
			const date_from = new Date( startDate );
			const date_to = new Date( endDate );

			setDateRange( getDatesInRange( date_from, date_to ) );

			const date_from_str = toLocalYMD( date_from );
			const date_to_str = toLocalYMD( date_to );

			setCurrentDateRange( { from: date_from_str, to: date_to_str } );

			fetchAnalytics(
				date_from_str,
				date_to_str,
				selectedFlow.value,
				comparisonPeriod
			);
		},
		[ selectedFlow.value, fetchAnalytics, comparisonPeriod ]
	);

	const stats = useMemo(
		() => [
			{
				name: __( 'Total Submissions', 'cartflows-pro' ),
				stat: optinConversionsAnalytics?.total_submissions ?? 0,
				tooltip: __(
					'This shows the total opt-in form submissions.',
					'cartflows-pro'
				),
				graphType: 'total_submissions',
			},
			{
				name: __( 'Conversion Rate', 'cartflows-pro' ),
				stat: optinConversionsAnalytics?.conversion_rate ?? 0,
				tooltip: __(
					'This shows the percentage of visitors who completed the opt-in.',
					'cartflows-pro'
				),
				graphType: 'conversion_rate',
			},
		],
		[ selectedFlow.value, optinConversionsAnalytics ]
	);

	const renderGraphs = useCallback(
		function () {
			if ( ! dateRange ) {
				return null;
			}
			switch ( currentTab ) {
				case 'total_submissions':
					return <OptinTotalSubmissions dateRange={ dateRange } />;
				case 'conversion_rate':
					return <OptinConversionRate dateRange={ dateRange } />;
				case 'list_growth':
					return <OptinListGrowth dateRange={ dateRange } />;
				default:
					return <OptinTotalSubmissions dateRange={ dateRange } />;
			}
		},
		[ currentTab, dateRange ]
	);

	// Initial load — only runs once on mount.
	useEffect( () => {
		const date_to = new Date();
		const date_from = new Date();
		date_from.setDate( date_from.getDate() - 7 );

		setDateRange( getDatesInRange( date_from, date_to ) );

		const date_from_str = toLocalYMD( date_from );
		const date_to_str = toLocalYMD( date_to );

		setCurrentDateRange( { from: date_from_str, to: date_to_str } );

		fetchAnalytics( date_from_str, date_to_str, '', comparisonPeriod );
		setIsInitialLoadComplete( true );
	}, [] );

	// Refetch graphs when the selected funnel changes.
	useEffect( () => {
		if (
			! isInitialLoadComplete ||
			! currentDateRange.from ||
			! currentDateRange.to
		) {
			return;
		}

		fetchAnalytics(
			currentDateRange.from,
			currentDateRange.to,
			selectedFlow.value,
			comparisonPeriod
		);
	}, [ selectedFlow.value, isInitialLoadComplete ] );

	// Refetch when the comparison period changes.
	useEffect( () => {
		if (
			! isInitialLoadComplete ||
			! currentDateRange.from ||
			! currentDateRange.to
		) {
			return;
		}

		fetchAnalytics(
			currentDateRange.from,
			currentDateRange.to,
			selectedFlow.value,
			comparisonPeriod
		);
	}, [ comparisonPeriod ] );

	const currentDate = new Date();
	const toDate = toLocalYMD( currentDate );
	currentDate.setDate( currentDate.getDate() - 7 );
	const fromDate = toLocalYMD( currentDate );

	const comparisonPeriodOptions = getComparisonPeriodOptions( __ );

	// An empty baseline would paint every card "New" — say it once in the header instead.
	const hasComparisonData = hasComparisonBaseline( comparisonMetrics );
	const comparisonLabel = getComparisonRangeLabel(
		currentDateRange.from,
		currentDateRange.to,
		comparisonPeriod
	);
	const showNoComparisonNote =
		Boolean( analyticsData ) && ! loading && ! hasComparisonData;

	return (
		<>
			<section aria-labelledby="section-1-title h-full">
				<div className="p-6 rounded-xl bg-background-primary shadow-sm flex flex-col gap-3 justify-center h-full">
					<AnalyticsHeader
						title={ __( 'Opt-in Analytics', 'cartflows-pro' ) }
						selectedFlow={ selectedFlow }
						onFlowChange={ setSelectedFlow }
						flowOptions={ flows }
						flowsLoading={ flowsLoading }
						dateValue={ {
							endDate: toDate,
							startDate: fromDate,
						} }
						onDateChange={ handleDateSubmit }
						comparisonPeriod={ comparisonPeriod }
						onComparisonPeriodChange={ setComparisonPeriod }
						comparisonPeriodOptions={ comparisonPeriodOptions }
					/>
					{ showNoComparisonNote && (
						<NoComparisonNote comparisonLabel={ comparisonLabel } />
					) }
					<div className="p-3 flex flex-col gap-3 bg-background-secondary rounded-lg">
						<div className="wcf-analytics--stats-tabs-container">
							<div className="wcf-analytics--stats-tabs m-0">
								<div
									role="tablist"
									aria-busy={ loading }
									className="gap-3 grid grid-cols-2 md:grid-cols-4 w-full box-border"
								>
									{ stats.map( ( item ) => {
										const comparisonKey = getComparisonKey(
											item.graphType
										);
										const comparisonValue =
											comparisonMetrics?.[
												comparisonKey
											] || 0;
										const trend = hasComparisonData
											? {
													...calculateTrend(
														item.stat,
														comparisonValue
													),
													baselineLabel:
														comparisonLabel,
											  }
											: {
													percentage: 0,
													isIncrease: true,
											  };

										const statSuffix =
											item.graphType === 'conversion_rate'
												? '%'
												: '';

										return (
											<StatsCard
												key={ item.name }
												item={ item }
												isActive={
													currentTab ===
													item.graphType
												}
												onClick={ () =>
													setCurrentTab(
														item.graphType
													)
												}
												trend={ trend }
												statSuffix={ statSuffix }
											/>
										);
									} ) }
								</div>
							</div>
						</div>

						<div className="bg-background-primary rounded-lg shadow-sm">
							{ ( loading || ! analyticsData ) && (
								<Skeleton
									variant="rectangular"
									className="h-64 w-full rounded"
								/>
							) }
							{ analyticsData && ! loading && (
								<div
									className="wcf-analytics--tab-content"
									role="tabpanel"
									id={ STATS_TABPANEL_ID }
									aria-labelledby={ `wcf-analytics-tab-${ currentTab }` }
								>
									{ renderGraphs() }
								</div>
							) }
						</div>
					</div>
				</div>

				<OptinOverviewTable
					optinFlowConversions={ optinFlowConversions }
				/>
			</section>
		</>
	);
}

export default OptinAnalytics;
