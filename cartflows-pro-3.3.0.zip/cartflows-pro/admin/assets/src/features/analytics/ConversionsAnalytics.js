import { useEffect, useState, useMemo, useCallback } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Skeleton } from '@bsf/force-ui';
import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import apiFetch from '@wordpress/api-fetch';

import TotalPageViews from '@ProFeatures/dashboard/graphs/TotalPageViews';
import TotalOrders from '@Features/dashboard/graphs/TotalOrders';
import LaptopConversions from '@ProFeatures/dashboard/graphs/LaptopConversions';
import MobileConversions from '@ProFeatures/dashboard/graphs/MobileConversions';
import TotalConversions from '@ProFeatures/dashboard/graphs/TotalConversions';
import BumpConversions from '@ProFeatures/dashboard/graphs/BumpConversions';
import OfferConversions from '@ProFeatures/dashboard/graphs/OfferConversions';

import StatsCard, {
	STATS_TABPANEL_ID,
} from '@Features/analytics/common/StatsCard';
import NoComparisonNote from '@ProFeatures/analytics/common/NoComparisonNote';
import AnalyticsHeader from '@Features/analytics/common/AnalyticsHeader';
import StepsConversionTable from '@ProFeatures/analytics/tables/StepsConversionTable';
import ProductConversionTable from '@ProFeatures/analytics/tables/ProductConversionTable';
import { usePublishedFlows } from '@ProHooks/usePublishedFlows';
import {
	calculateTrend,
	getComparisonRangeLabel,
	getDatesInRange,
	hasComparisonBaseline,
	getComparisonPeriodOptions,
	toLocalYMD,
} from '@ProUtils/analytics-helpers';

/**
 * Conversions analytics screen — registered on the free plugin's analytics slot.
 *
 * @return {Object} Conversions analytics content.
 */
function ConversionsAnalytics() {
	const [ { analyticsData }, dispatch ] = useSettingsStateValue();
	const flowStats = analyticsData?.flow_stats || {};
	const comparisonMetrics = flowStats?.comparison || [];
	const [ dateRange, setDateRange ] = useState();
	const [ loading, setLoading ] = useState( true );
	const [ currentTab, setCurrentTab ] = useState( 'total_visitors' );
	const [ selectedFlow, setSelectedFlow ] = useState( {
		value: '',
		label: __( 'All Funnels', 'cartflows-pro' ),
	} );
	const [ comparisonPeriod, setComparisonPeriod ] =
		useState( 'previous-period' );

	// Track current date range for API calls.
	const [ currentDateRange, setCurrentDateRange ] = useState( {
		from: null,
		to: null,
	} );

	const [ isInitialLoadComplete, setIsInitialLoadComplete ] =
		useState( false );

	const { flows, loading: flowsLoading } = usePublishedFlows();

	// Map stat graph types to comparison metric keys.
	const getComparisonKey = useCallback( ( graphType ) => {
		const keyMap = {
			total_visitors: 'total_visits',
			total_conversions: 'total_conversions',
			total_bump_conversions: 'total_bump_conversions',
			offer_conversions: 'total_offer_conversions',
			laptop_conversion_rate: 'total_desktop_conversions',
			mobile_conversion_rate: 'total_mobile_conversions',
		};
		return keyMap[ graphType ];
	}, [] );

	const fetchAnalytics = useCallback(
		( dateFrom, dateTo, flowId, comparisonType = 'previous-period' ) => {
			setLoading( true );
			const formData = new window.FormData();

			formData.append( 'date_to', dateTo );
			formData.append( 'date_from', dateFrom );

			if ( flowId ) {
				formData.append( 'flow_id', flowId );
			}

			formData.append( 'comparison_range_type', comparisonType );

			formData.append( 'screen_type', 'conversions' );
			formData.append( 'action', 'cartflows_get_all_flows_stats' );
			formData.append(
				'security',
				cartflows_admin.get_all_flows_stats_nonce
			);

			apiFetch( {
				url: cartflows_admin.ajax_url,
				method: 'POST',
				body: formData,
			} )
				.then( ( response ) => {
					// A failed request (stale nonce) resolves without flow_stats — storing it crashes the charts.
					if ( response?.data?.flow_stats ) {
						dispatch( {
							type: 'SET_ANALYTICS_DATA',
							analyticsData: response.data,
						} );
					}
					setLoading( false );
				} )
				.catch( () => {
					setLoading( false );
				} );
		},
		[ dispatch ]
	);

	const handleDateSubmit = useCallback(
		( { startDate, endDate } ) => {
			const date_from_str = toLocalYMD( startDate );
			const date_to_str = toLocalYMD( endDate );

			setDateRange( getDatesInRange( startDate, endDate ) );
			setCurrentDateRange( { from: date_from_str, to: date_to_str } );

			fetchAnalytics(
				date_from_str,
				date_to_str,
				selectedFlow.value,
				comparisonPeriod
			);
		},
		[ selectedFlow.value, fetchAnalytics, comparisonPeriod ]
	);

	// Initial load — only runs once on mount.
	useEffect( () => {
		const date_to = new Date();
		const date_from = new Date();
		date_from.setDate( date_from.getDate() - 7 );

		setDateRange( getDatesInRange( date_from, date_to ) );

		const date_from_str =
			date_from.getFullYear() +
			'-' +
			String( date_from.getMonth() + 1 ).padStart( 2, '0' ) +
			'-' +
			String( date_from.getDate() ).padStart( 2, '0' );
		const date_to_str =
			date_to.getFullYear() +
			'-' +
			String( date_to.getMonth() + 1 ).padStart( 2, '0' ) +
			'-' +
			String( date_to.getDate() ).padStart( 2, '0' );

		setCurrentDateRange( { from: date_from_str, to: date_to_str } );

		fetchAnalytics( date_from_str, date_to_str, '', comparisonPeriod );
		setIsInitialLoadComplete( true );
	}, [] );

	// Refetch graphs when the selected funnel changes.
	useEffect( () => {
		if (
			! isInitialLoadComplete ||
			! currentDateRange.from ||
			! currentDateRange.to
		) {
			return;
		}

		fetchAnalytics(
			currentDateRange.from,
			currentDateRange.to,
			selectedFlow.value,
			comparisonPeriod
		);
	}, [ selectedFlow.value, isInitialLoadComplete ] );

	// Refetch when the comparison period changes.
	useEffect( () => {
		if (
			! isInitialLoadComplete ||
			! currentDateRange.from ||
			! currentDateRange.to
		) {
			return;
		}

		fetchAnalytics(
			currentDateRange.from,
			currentDateRange.to,
			selectedFlow.value,
			comparisonPeriod
		);
	}, [ comparisonPeriod ] );

	const currentDate = new Date();
	const toDate = toLocalYMD( currentDate );
	currentDate.setDate( currentDate.getDate() - 7 );
	const fromDate = toLocalYMD( currentDate );

	const comparisonPeriodOptions = getComparisonPeriodOptions( __ );

	const stats = useMemo(
		() => [
			{
				name: __( 'Total Visitors', 'cartflows-pro' ),
				stat: flowStats?.total_visits ? flowStats?.total_visits : 0,
				tooltip: __(
					'This shows the total number of visitors for the selected funnel/s.',
					'cartflows-pro'
				),
				graphType: 'total_visitors',
			},
			{
				name: __( 'Total Conversions', 'cartflows-pro' ),
				stat: flowStats?.total_conversions
					? flowStats?.total_conversions
					: 0,
				tooltip: __(
					'This shows the total conversions for the selected funnel.',
					'cartflows-pro'
				),
				graphType: 'total_conversions',
			},
			{
				name: __( 'Bump Conversions', 'cartflows-pro' ),
				stat: flowStats?.total_bump_conversions
					? flowStats?.total_bump_conversions
					: 0,
				tooltip: __(
					'This shows the order bump conversions for the selected funnel.',
					'cartflows-pro'
				),
				graphType: 'total_bump_conversions',
			},
			{
				name: __( 'Offer Conversions', 'cartflows-pro' ),
				stat: flowStats?.total_offer_conversions
					? flowStats?.total_offer_conversions
					: 0,
				tooltip: __(
					'This shows the total offer conversions from Upsell and Downsell combined for the selected funnel.',
					'cartflows-pro'
				),
				graphType: 'offer_conversions',
			},
			{
				name: __( 'Laptop Conversions', 'cartflows-pro' ),
				stat: flowStats?.total_desktop_conversions
					? flowStats?.total_desktop_conversions
					: 0,
				tooltip: __(
					'This shows the orders completed on large-screen devices (over 1024px).',
					'cartflows-pro'
				),
				graphType: 'laptop_conversion_rate',
			},
			{
				name: __( 'Mobile Conversions', 'cartflows-pro' ),
				stat: flowStats?.total_mobile_conversions
					? flowStats?.total_mobile_conversions
					: 0,
				tooltip: __(
					'This shows orders completed on mobile and small-screen devices (under 1024px).',
					'cartflows-pro'
				),
				graphType: 'mobile_conversion_rate',
			},
		],
		[ selectedFlow.value, flowStats ]
	);

	const renderGraphs = useCallback(
		function () {
			if ( ! dateRange ) {
				return null;
			}

			switch ( currentTab ) {
				case 'total_visitors':
					return (
						<TotalPageViews
							dateRange={ dateRange }
							analyticsData={ analyticsData }
						/>
					);
				case 'total_conversions':
					return <TotalConversions dateRange={ dateRange } />;
				case 'total_bump_conversions':
					return <BumpConversions dateRange={ dateRange } />;
				case 'offer_conversions':
					return <OfferConversions dateRange={ dateRange } />;
				case 'laptop_conversion_rate':
					return <LaptopConversions dateRange={ dateRange } />;
				case 'mobile_conversion_rate':
					return <MobileConversions dateRange={ dateRange } />;
				default:
					return <TotalOrders dateRange={ dateRange } />;
			}
		},
		[ currentTab, dateRange, analyticsData ]
	);

	// An empty baseline would paint every card "New" — say it once in the header instead.
	const hasComparisonData = hasComparisonBaseline( comparisonMetrics );
	const comparisonLabel = getComparisonRangeLabel(
		currentDateRange.from,
		currentDateRange.to,
		comparisonPeriod
	);
	const showNoComparisonNote =
		Boolean( analyticsData ) && ! loading && ! hasComparisonData;

	return (
		<>
			<section aria-labelledby="section-1-title h-full">
				<div className="p-6 rounded-xl bg-background-primary shadow-sm flex flex-col gap-3 justify-center h-full">
					<AnalyticsHeader
						title={ __( 'Conversions Analytics', 'cartflows-pro' ) }
						selectedFlow={ selectedFlow }
						onFlowChange={ setSelectedFlow }
						flowOptions={ flows }
						flowsLoading={ flowsLoading }
						dateValue={ {
							endDate: toDate,
							startDate: fromDate,
						} }
						onDateChange={ handleDateSubmit }
						comparisonPeriod={ comparisonPeriod }
						onComparisonPeriodChange={ setComparisonPeriod }
						comparisonPeriodOptions={ comparisonPeriodOptions }
					/>
					{ showNoComparisonNote && (
						<NoComparisonNote comparisonLabel={ comparisonLabel } />
					) }
					<div className="p-3 flex flex-col gap-3 bg-background-secondary rounded-lg">
						<div className="wcf-analytics--stats-tabs-container">
							<div className="wcf-analytics--stats-tabs m-0">
								<div
									role="tablist"
									aria-busy={ loading }
									className="gap-3 grid grid-cols-2 md:grid-cols-4 w-full box-border"
								>
									{ stats.map( ( item ) => {
										const comparisonKey = getComparisonKey(
											item.graphType
										);
										const comparisonValue =
											comparisonMetrics?.[
												comparisonKey
											] || 0;
										const trend = hasComparisonData
											? {
													...calculateTrend(
														item.stat,
														comparisonValue
													),
													baselineLabel:
														comparisonLabel,
											  }
											: {
													percentage: 0,
													isIncrease: true,
											  };

										return (
											<StatsCard
												key={ item.name }
												item={ item }
												isActive={
													currentTab ===
													item.graphType
												}
												onClick={ () =>
													setCurrentTab(
														item.graphType
													)
												}
												trend={ trend }
											/>
										);
									} ) }
								</div>
							</div>
						</div>

						<div className="bg-background-primary rounded-lg shadow-sm">
							{ ( loading || ! analyticsData ) && (
								<Skeleton
									variant="rectangular"
									className="h-64 w-full rounded"
								/>
							) }
							{ analyticsData && ! loading && (
								<div
									className="wcf-analytics--tab-content"
									role="tabpanel"
									id={ STATS_TABPANEL_ID }
									aria-labelledby={ `wcf-analytics-tab-${ currentTab }` }
								>
									{ renderGraphs() }
								</div>
							) }
						</div>
					</div>
				</div>

				<StepsConversionTable
					flowStats={ flowStats }
					selectedFlow={ selectedFlow }
				/>

				<ProductConversionTable
					flowStats={ flowStats }
					selectedFlow={ selectedFlow }
				/>
			</section>
		</>
	);
}

export default ConversionsAnalytics;
