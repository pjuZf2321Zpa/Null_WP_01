import { __, sprintf } from '@wordpress/i18n';
import { Text } from '@bsf/force-ui';

/**
 * Header note shown when the comparison period has no activity, replacing per-card "New" chips.
 *
 * @param {Object} props                 Component props.
 * @param {string} props.comparisonLabel Formatted comparison range, or '' when unknown.
 * @return {Object} Note element.
 */
function NoComparisonNote( { comparisonLabel } ) {
	return (
		<Text size={ 12 } weight={ 400 } color="secondary">
			{ comparisonLabel
				? sprintf(
						/* translators: %s: comparison date range */
						__(
							'No comparable data for %s — trends appear once the previous period has activity.',
							'cartflows-pro'
						),
						comparisonLabel
				  )
				: __(
						'No comparable data for the previous period — trends appear once it has activity.',
						'cartflows-pro'
				  ) }
		</Text>
	);
}

export default NoComparisonNote;
