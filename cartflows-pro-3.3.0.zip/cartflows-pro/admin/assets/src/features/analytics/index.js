import { addFilter } from '@wordpress/hooks';
import { SettingsStateProvider } from '@App/providers/SettingsStateProvider';
import { isProPlan } from '@ProUtils/plan';
import FlowsAnalytics from './FlowsAnalytics';
import ConversionsAnalytics from './ConversionsAnalytics';
import OptinAnalytics from './OptinAnalytics';

// Free's settings reducer reads `cartflows_admin` at module scope — undefined while this bundle evaluates — so keep a minimal local store.
const analyticsInitialState = {
	analyticsData: null,
	publishedFlows: null,
};

const analyticsReducer = ( state, action ) => {
	switch ( action.type ) {
		case 'SET_ANALYTICS_DATA':
			return { ...state, analyticsData: action.analyticsData };
		case 'SET_PUBLISHED_FLOWS':
			return { ...state, publishedFlows: action.publishedFlows };
		default:
			return state;
	}
};

/**
 * Wrap a screen in a bundle-local settings store — free's provider context
 * can't cross the bundle boundary.
 *
 * @param {Function} Component Screen component to wrap.
 * @return {Function} Wrapped component.
 */
const withSettingsState = ( Component ) =>
	function WithSettingsState( props ) {
		return (
			<SettingsStateProvider
				initialState={ analyticsInitialState }
				reducer={ analyticsReducer }
			>
				<Component { ...props } />
			</SettingsStateProvider>
		);
	};

// Wrap once at module scope — a fresh wrapper per filter run changes the component identity and React remounts (and refetches) on every parent render.
const FlowsAnalyticsWithState = withSettingsState( FlowsAnalytics );
const ConversionsAnalyticsWithState = withSettingsState( ConversionsAnalytics );
const OptinAnalyticsWithState = withSettingsState( OptinAnalytics );

addFilter(
	'cartflows.analytics.pages',
	'cartflows-pro/analytics/pages',
	( pages ) => {
		if ( ! isProPlan() ) {
			return pages;
		}
		return {
			...pages,
			flows: FlowsAnalyticsWithState,
			conversion: ConversionsAnalyticsWithState,
			optin: OptinAnalyticsWithState,
		};
	}
);
