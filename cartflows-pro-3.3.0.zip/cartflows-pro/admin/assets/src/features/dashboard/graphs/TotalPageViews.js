import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactNumber,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

/**
 * Total page views chart for the dashboard Overview.
 *
 * @param {Object} props               Component props.
 * @param {Array}  props.dateRange     Dates to plot on the X axis.
 * @param {Object} props.analyticsData Analytics data from the free plugin store.
 * @return {Object} Line chart of funnel visits.
 */
function TotalPageViews( { dateRange, analyticsData } ) {
	const totalVisits = analyticsData?.flow_stats?.visits_by_date || [];

	const data = dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = totalVisits.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			visits: visitData ? Number( visitData?.total_visits ) : 0,
		};
	} );

	return (
		<LineChart
			data={ data }
			dataKeys={ [ 'visits' ] }
			xAxisDataKey="date"
			yAxisDataKey="visits"
			colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
			showXAxis={ true }
			showYAxis={ true }
			yAxisTickFormatter={ compactNumber }
			chartWidth="100%"
			chartHeight={ 305 }
		/>
	);
}

export default TotalPageViews;
