import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactCurrency,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

function RevenuePerVisit( props ) {
	const [ { analyticsData } ] = useSettingsStateValue();

	const revenuePerVisitByDate =
		analyticsData && analyticsData.flow_stats.revenue_per_visit_by_date
			? analyticsData.flow_stats.revenue_per_visit_by_date
			: [];

	const data = props.dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = revenuePerVisitByDate.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			revenue_per_visit: visitData
				? Number( visitData.revenue_per_visit )
				: 0,
		};
	} );

	return (
		<div>
			<LineChart
				data={ data }
				dataKeys={ [ 'revenue_per_visit' ] }
				xAxisDataKey="date"
				yAxisDataKey="revenue_per_visit"
				colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
				showXAxis={ true }
				showYAxis={ true }
				yAxisTickFormatter={ compactCurrency }
				chartWidth="100%"
				chartHeight={ 305 }
			/>
		</div>
	);
}

export default RevenuePerVisit;
