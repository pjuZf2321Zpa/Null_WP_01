import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactCurrency,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

function AverageOrderValue( props ) {
	const [ { analyticsData } ] = useSettingsStateValue();

	const avgOrderValueByDate =
		analyticsData && analyticsData.flow_stats.avg_order_value_by_date
			? analyticsData.flow_stats.avg_order_value_by_date
			: [];

	const data = props.dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = avgOrderValueByDate.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			avg_order_value: visitData
				? Number( visitData.avg_order_value )
				: 0,
		};
	} );

	return (
		<div>
			<LineChart
				data={ data }
				dataKeys={ [ 'avg_order_value' ] }
				xAxisDataKey="date"
				yAxisDataKey="avg_order_value"
				colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
				showXAxis={ true }
				showYAxis={ true }
				yAxisTickFormatter={ compactCurrency }
				chartWidth="100%"
				chartHeight={ 305 }
			/>
		</div>
	);
}

export default AverageOrderValue;
