import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactNumber,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

function OptinTotalSubmissions( props ) {
	const [ { analyticsData } ] = useSettingsStateValue();
	const totalSubmissions =
		analyticsData && analyticsData?.flow_stats?.submissions_by_date
			? analyticsData?.flow_stats?.submissions_by_date
			: [];

	const data = props.dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = totalSubmissions.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			submissions: visitData ? Number( visitData.submissions ) : 0,
		};
	} );

	return (
		<div>
			<LineChart
				data={ data }
				dataKeys={ [ 'submissions' ] }
				xAxisDataKey="date"
				yAxisDataKey="submissions"
				colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
				showXAxis={ true }
				showYAxis={ true }
				yAxisTickFormatter={ compactNumber }
				chartWidth="100%"
				chartHeight={ 305 }
			/>
		</div>
	);
}

export default OptinTotalSubmissions;
