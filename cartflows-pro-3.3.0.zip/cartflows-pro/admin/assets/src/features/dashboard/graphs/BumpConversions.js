import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactNumber,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

function BumpConversions( props ) {
	const [ { analyticsData } ] = useSettingsStateValue();
	const totalBumpConversions =
		analyticsData && analyticsData?.flow_stats?.bump_conversions_by_date
			? analyticsData?.flow_stats?.bump_conversions_by_date
			: [];

	const data = props.dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = totalBumpConversions.find(
			( conversion ) => conversion.OrderDate === date
		);
		return {
			date: formattedDate,
			bumpConversions: visitData
				? Number( visitData.bump_conversions )
				: 0,
		};
	} );

	return (
		<div>
			<LineChart
				data={ data }
				dataKeys={ [ 'bumpConversions' ] }
				xAxisDataKey="date"
				yAxisDataKey="bumpConversions"
				colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
				showXAxis={ true }
				showYAxis={ true }
				yAxisTickFormatter={ compactNumber }
				chartWidth="100%"
				chartHeight={ 305 }
			/>
		</div>
	);
}

export default BumpConversions;
