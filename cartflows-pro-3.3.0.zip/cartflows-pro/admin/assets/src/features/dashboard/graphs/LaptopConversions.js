import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactNumber,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

function LaptopConversions( props ) {
	const [ { analyticsData } ] = useSettingsStateValue();
	const totalVisits =
		analyticsData && analyticsData?.flow_stats?.desktop_conversions_by_date
			? analyticsData?.flow_stats?.desktop_conversions_by_date
			: [];

	const data = props.dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = totalVisits.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			desktopConversions: visitData
				? Number( visitData.desktop_conversions )
				: 0,
		};
	} );

	return (
		<div>
			<LineChart
				data={ data }
				dataKeys={ [ 'desktopConversions' ] }
				xAxisDataKey="date"
				yAxisDataKey="desktopConversions"
				colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
				showXAxis={ true }
				showYAxis={ true }
				yAxisTickFormatter={ compactNumber }
				chartWidth="100%"
				chartHeight={ 305 }
			/>
		</div>
	);
}

export default LaptopConversions;
