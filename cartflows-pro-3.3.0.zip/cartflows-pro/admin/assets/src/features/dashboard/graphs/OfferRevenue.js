import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactCurrency,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

/**
 * Offer revenue chart for the dashboard Overview.
 *
 * @param {Object} props               Component props.
 * @param {Array}  props.dateRange     Dates to plot on the X axis.
 * @param {Object} props.analyticsData Analytics data from the free plugin store.
 * @return {Object} Line chart of upsell/downsell/bump revenue.
 */
function OfferRevenue( { dateRange, analyticsData } ) {
	const totalOfferRevenue =
		analyticsData?.flow_stats?.offer_revenue_by_date || [];

	const data = dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = totalOfferRevenue.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			offer_revenue: visitData ? Number( visitData.offer_revenue ) : 0,
		};
	} );

	return (
		<LineChart
			data={ data }
			dataKeys={ [ 'offer_revenue' ] }
			xAxisDataKey="date"
			yAxisDataKey="offer_revenue"
			colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
			showXAxis={ true }
			showYAxis={ true }
			yAxisTickFormatter={ compactCurrency }
			chartWidth="100%"
			chartHeight={ 305 }
		/>
	);
}

export default OfferRevenue;
