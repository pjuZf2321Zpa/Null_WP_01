import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactCurrency,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

function BumpOfferRevenue( props ) {
	const [ { analyticsData } ] = useSettingsStateValue();

	const bumpRevenueByDate =
		analyticsData && analyticsData.flow_stats.bump_revenue_by_date
			? analyticsData.flow_stats.bump_revenue_by_date
			: [];

	const data = props.dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = bumpRevenueByDate.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			bump_revenue: visitData ? Number( visitData.bump_revenue ) : 0,
		};
	} );

	return (
		<div>
			<LineChart
				data={ data }
				dataKeys={ [ 'bump_revenue' ] }
				xAxisDataKey="date"
				yAxisDataKey="bump_revenue"
				colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
				showXAxis={ true }
				showYAxis={ true }
				yAxisTickFormatter={ compactCurrency }
				chartWidth="100%"
				chartHeight={ 305 }
			/>
		</div>
	);
}

export default BumpOfferRevenue;
