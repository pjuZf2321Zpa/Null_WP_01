import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import { LineChart } from '@bsf/force-ui';
import { CHART_BRAND_PRIMARY } from '@Features/dashboard/graphs/chart-tokens';
import {
	compactNumber,
	formatChartDate,
} from '@Features/dashboard/graphs/chart-formatters';

function OptinListGrowth( props ) {
	const [ { analyticsData } ] = useSettingsStateValue();

	const totalOfferRevenue =
		analyticsData && analyticsData.flow_stats.optin_conversion_rate_by_date
			? analyticsData.flow_stats.optin_conversion_rate_by_date
			: [];

	const data = props.dateRange.map( ( date ) => {
		const formattedDate = formatChartDate( date );
		const visitData = totalOfferRevenue.find(
			( visit ) => visit.OrderDate === date
		);
		return {
			date: formattedDate,
			conversions: visitData ? Number( visitData.conversions ) : 0,
		};
	} );

	return (
		<div>
			<LineChart
				data={ data }
				dataKeys={ [ 'conversions' ] }
				xAxisDataKey="date"
				yAxisDataKey="conversions"
				colors={ [ { stroke: CHART_BRAND_PRIMARY } ] }
				showXAxis={ true }
				showYAxis={ true }
				yAxisTickFormatter={ compactNumber }
				chartWidth="100%"
				chartHeight={ 305 }
			/>
		</div>
	);
}

export default OptinListGrowth;
