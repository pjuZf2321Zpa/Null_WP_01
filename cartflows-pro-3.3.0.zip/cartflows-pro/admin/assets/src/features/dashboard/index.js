/**
 * Dashboard Pro registrations.
 * Hooks Pro dashboard components into the free plugin admin app.
 */
import { addFilter } from '@wordpress/hooks';
import { isProPlan } from '@ProUtils/plan';
import TotalPageViews from './graphs/TotalPageViews';
import OfferRevenue from './graphs/OfferRevenue';
import TopPerformingFunnelsTable from './TopPerformingFunnelsTable';

addFilter(
	'cartflows.dashboard.graphs',
	'cartflows-pro/dashboard/graphs',
	( graphs ) => {
		if ( ! isProPlan() ) {
			return graphs;
		}
		return {
			...graphs,
			total_views: { component: TotalPageViews },
			offer_revenue: { component: OfferRevenue },
		};
	}
);

addFilter(
	'cartflows.dashboard.topPerformingFunnels',
	'cartflows-pro/dashboard/top-performing-funnels',
	( current ) => ( isProPlan() ? TopPerformingFunnelsTable : current )
);
