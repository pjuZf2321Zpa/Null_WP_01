import { useMemo } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import parse from 'html-react-parser';
import { Table } from '@bsf/force-ui';
import dashboardTopFunnels from '@Images/dashboard-top-funnels.png';

/**
 * Top performing funnels table for the dashboard.
 *
 * @param {Object} props                      Component props.
 * @param {Object} props.topPerformingFunnels Funnel stats keyed by flow, from the free plugin store.
 * @return {Object} Funnels stats table.
 */
function TopPerformingFunnelsTable( { topPerformingFunnels } ) {
	// Memoize the table to only re-render when topPerformingFunnels changes
	const topPerformingFunnelsTable = useMemo( () => {
		return (
			topPerformingFunnels &&
			Object.values( topPerformingFunnels ).map( ( flow, idx ) => (
				<Table.Row key={ flow?.flow_id || idx }>
					<Table.Cell className="whitespace-nowrap font-medium">
						{ parse( flow?.flow_title || '(no title)' ) }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ flow?.total_visits }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ flow?.unique_visits }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ flow?.conversions }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ flow?.conversion_rate + '%' }
					</Table.Cell>
					<Table.Cell className="whitespace-nowrap">
						{ parse( flow?.revenue ) }
					</Table.Cell>
				</Table.Row>
			) )
		);
	}, [ topPerformingFunnels ] );

	const renderTableBody = () => {
		if (
			! topPerformingFunnels ||
			Object.keys( topPerformingFunnels ).length === 0
		) {
			return (
				<Table.Row>
					<Table.Cell colSpan={ 6 } className="py-12">
						<div className="flex flex-col items-center gap-3">
							<img
								src={ dashboardTopFunnels }
								alt=""
								width="78"
								height="72"
							/>
							<div className="flex flex-col items-center gap-1">
								<p className="text-lg font-semibold text-text-primary m-0">
									{ __(
										'Find top performing funnels here',
										'cartflows-pro'
									) }
								</p>
								<p className="text-sm text-text-tertiary m-0">
									{ __(
										'Once you set up funnels, come back here to top performing funnels',
										'cartflows-pro'
									) }
								</p>
							</div>
						</div>
					</Table.Cell>
				</Table.Row>
			);
		}
		return topPerformingFunnelsTable;
	};

	return (
		<div className="overflow-x-auto">
			<Table className="min-w-full">
				<Table.Head>
					<Table.HeadCell>
						{ __( 'Funnel Name', 'cartflows-pro' ) }
					</Table.HeadCell>
					<Table.HeadCell>
						{ __( 'Total Visits', 'cartflows-pro' ) }
					</Table.HeadCell>
					<Table.HeadCell>
						{ __( 'Unique Visits', 'cartflows-pro' ) }
					</Table.HeadCell>
					<Table.HeadCell>
						{ __( 'Conversions', 'cartflows-pro' ) }
					</Table.HeadCell>
					<Table.HeadCell>
						{ __( 'Conversion Rate', 'cartflows-pro' ) }
					</Table.HeadCell>
					<Table.HeadCell>
						{ __( 'Revenue', 'cartflows-pro' ) }
					</Table.HeadCell>
				</Table.Head>
				<Table.Body>{ renderTableBody() }</Table.Body>
			</Table>
		</div>
	);
}

export default TopPerformingFunnelsTable;
