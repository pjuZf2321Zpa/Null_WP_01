import { useState } from '@wordpress/element';
import { useStateValue } from '@Utils/StateProvider';
import { __, sprintf } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import OrderBumpRepeater from './OrderBumpRepeater';
// A/B group component — replaces the plain row when the entry is a running A/B control.
import { OrderBumpAbGroup } from './ab-test';
import OrderBumpSkeleton from '@StepEditor/components/steps-page/OrderBumpSkeleton';
import { ReactSortable } from 'react-sortablejs';
import { DocField } from '@Fields';
import { Plus } from 'lucide-react';
import { Container, Input, Button, Text, toast } from '@bsf/force-ui';

function MultiOrderBump( {
	orderBumps: orderBumpsProp,
	stepId: stepIdProp,
	flowId: flowIdProp,
	pageSettings: pageSettingsProp,
	onChange,
	onEditClick,
	hideDocLink = false,
	hideAddControl = false,
} = {} ) {
	const [ stepState, dispatchStep ] = useStateValue();
	const isControlled = Array.isArray( orderBumpsProp );

	const options = isControlled ? null : stepState?.options;
	const step_id = isControlled ? stepIdProp : stepState?.step_id;
	const flow_id = isControlled ? flowIdProp : stepState?.flow_id;
	const page_settings = isControlled
		? pageSettingsProp
		: stepState?.page_settings;
	const dispatch = isControlled
		? ( action ) => onChange?.( action )
		: dispatchStep;

	const [ title, setTitle ] = useState();
	const [ errorMsg, setErrorMsg ] = useState( '' );
	const defaultBtnText = __( 'Add', 'cartflows-pro' );

	// Single source of truth for "which bump's inline settings panel is currently open".
	// Seed from ?ob_id=… so the cog on the step-listing page opens the panel in one step.
	const [ openObSettingsId, setOpenObSettingsId ] = useState(
		new URLSearchParams( window.location.search ).get( 'ob_id' ) || ''
	);
	// Passing the same id closes the panel; keep ?ob_id= in sync via history.replaceState.
	const toggleObSettings = ( ob_id ) => {
		setOpenObSettingsId( ( prev ) => {
			const next = prev === ob_id ? '' : ob_id;
			const url = new URL( window.location.href );
			const current = url.searchParams.get( 'ob_id' ) || '';
			if ( next === current ) {
				return next;
			}
			if ( next ) {
				url.searchParams.set( 'ob_id', next );
			} else {
				url.searchParams.delete( 'ob_id' );
			}
			window.history.replaceState( null, '', url.toString() );
			return next;
		} );
	};

	const [ addButton, setAddButton ] = useState( {
		button_text: defaultBtnText,
		is_processing: false,
	} );

	const { button_text, is_processing } = addButton;

	if (
		! isControlled &&
		( null === options || 'undefined' === page_settings )
	) {
		return <OrderBumpSkeleton />;
	}

	const allSetting = page_settings;
	const OrderBumps = isControlled
		? orderBumpsProp
		: options[ 'wcf-order-bumps' ];

	// ReactSortable indexes its `list` 1:1 with its rendered children. If we return null
	// for variant entries inside the map, the list/children counts diverge and react-sortablejs
	// crashes on `null.props` in its internal Children traversal. Filter variants OUT at the
	// data layer so the array passed to ReactSortable contains only the rows we actually render.
	const SortableBumps = Array.isArray( OrderBumps )
		? OrderBumps.filter( ( ob ) => ! ob?.[ 'wcf-control-ob' ] )
		: OrderBumps;

	const length = OrderBumps ? Object.keys( OrderBumps ).length : 0;

	const obDesign = page_settings?.settings?.[ 'multiple-order-bump-design' ];

	const addNewOrderBump = function ( e ) {
		e.preventDefault();

		if ( 'undefined' !== typeof title ) {
			setErrorMsg( '' );

			setAddButton( {
				button_text: __( 'Adding…', 'cartflows-pro' ),
				is_processing: true,
			} );

			const order_bump_data = {
				title,
				id: Math.random().toString( 36 ).substring( 2, 5 ),
			};

			const formData = new window.FormData();

			formData.append( 'action', 'cartflows_pro_add_order_bump' );
			formData.append( 'security', cartflows_admin.add_order_bump_nonce );
			formData.append( 'ob_id', order_bump_data.id );
			formData.append( 'post_id', flow_id );
			formData.append( 'step_id', step_id );
			formData.append( 'title', title );

			apiFetch( {
				url: cartflows_admin.ajax_url,
				method: 'POST',
				body: formData,
			} ).then( ( response ) => {
				if ( response.success ) {
					dispatch( {
						type: 'UPDATE_ORDER_BUMP',
						name: 'wcf-order-bumps',
						order_bumps: response.data.order_bumps,
					} );
					setTitle( '' );

					setAddButton( {
						button_text: defaultBtnText,
						is_processing: false,
					} );
					toast.success( __( 'Order bump added!', 'cartflows-pro' ) );
				}
				e.target.blur();
			} );
		} else {
			setErrorMsg(
				__( 'Please enter the order bump title', 'cartflows-pro' )
			);
			e.target.blur();
		}
	};

	const updateOBList = () => {
		const obs = isControlled
			? orderBumpsProp
			: options[ 'wcf-order-bumps' ];
		if ( ! obs ) {
			return;
		}
		const new_obs = [];
		Object.keys( obs ).map( ( i ) => {
			new_obs.push( obs[ i ].id );
			return '';
		} );

		const ajaxData = new window.FormData();
		ajaxData.append( 'action', 'cartflows_pro_reorder_order_bumps' );
		ajaxData.append(
			'security',
			cartflows_admin.reorder_order_bumps_nonce
		);
		ajaxData.append( 'step_id', step_id );
		ajaxData.append( 'sorted_obs', new_obs );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: ajaxData,
		} ).then( () => {} );
	};

	return (
		<>
			<Container
				containerType="flex"
				direction="column"
				gap="sm"
				className="wcf-multiple-order-bumps--wrapper"
			>
				{ length > 0 && (
					<div className="wcf-multiple-order-bumps border border-solid border-border-subtle sm:mx-0 sm:rounded-lg">
						<Container
							containerType="flex"
							direction="row"
							className="wcf-multiple-order-bumps__header border-x-0 border-t-0 border-b-0.5 border-solid border-border-subtle bg-background-secondary px-6 py-3 gap-2 text-left sm:rounded-t-lg"
						>
							<Text
								as="span"
								size="sm"
								weight={ 500 }
								className="wcf-column wcf-column--title flex-1 min-w-0"
							>
								{ __( 'Title', 'cartflows-pro' ) }
							</Text>
							<Text
								as="span"
								size="sm"
								weight={ 500 }
								className="wcf-column wcf-column--status w-28 shrink-0"
							>
								{ __( 'At Checkout', 'cartflows-pro' ) }
							</Text>
							<Text
								as="span"
								size="sm"
								weight={ 500 }
								className="wcf-column wcf-column--actions w-36 shrink-0 text-right"
							>
								{ __( 'Actions', 'cartflows-pro' ) }
							</Text>
						</Container>
						<div
							className={ `wcf-multiple-order-bumps__content sm:rounded-b-lg${
								openObSettingsId ? '' : ' overflow-hidden'
							}` }
						>
							{ OrderBumps && (
								<>
									<ReactSortable
										list={ SortableBumps }
										setList={ ( newState ) => {
											// `newState` is the reordered list WITHOUT variants. Merge variant entries back in,
											// keeping each variant directly after its control so the persisted order is stable.
											const reordered = [];
											newState.forEach( ( ob ) => {
												reordered.push( ob );
												if (
													ob?.[ 'ab-test' ] &&
													Array.isArray(
														ob[
															'ab-test-variations'
														]
													)
												) {
													ob[
														'ab-test-variations'
													].forEach( ( v ) => {
														const variant =
															OrderBumps.find(
																( o ) =>
																	o.id ===
																		v.id &&
																	o[
																		'wcf-control-ob'
																	] === ob.id
															);
														if ( variant ) {
															reordered.push(
																variant
															);
														}
													} );
												}
											} );
											dispatch( {
												type: 'SET_OB',
												obs: reordered,
												fieldName: 'wcf-order-bumps',
												step_id,
												flow_id,
											} );
										} }
										swapThreshold={ 0.8 }
										direction={ 'vertical' }
										animation={ 150 }
										handle={ '.wcf-order-bump' }
										filter={
											'.wcf-order-bump__action, .wcf_order_bump__status, .wcf-order-bump__data-title a'
										}
										preventOnFilter={ false }
									>
										{ SortableBumps.map( ( ob_data ) => {
											// Phase 1.6 fix 1: only group when there is real test data — i.e. ab-test is true
											// AND ab-test-variations is a non-empty array. A control flagged ab-test=true with an
											// empty variations array falls back to the plain OrderBumpRepeater row.
											const abVariations =
												ob_data[ 'ab-test-variations' ];
											if (
												ob_data[ 'ab-test' ] &&
												Array.isArray( abVariations ) &&
												abVariations.length > 0
											) {
												return (
													<OrderBumpAbGroup
														key={ ob_data.id }
														controlBump={ ob_data }
														allBumps={ OrderBumps }
														stepId={ step_id }
														flowId={ flow_id }
														dispatch={
															isControlled
																? dispatch
																: undefined
														}
														onEditClick={
															onEditClick
														}
														openObSettingsId={
															openObSettingsId
														}
														toggleObSettings={
															toggleObSettings
														}
													/>
												);
											}
											return (
												<OrderBumpRepeater
													key={ ob_data.id }
													flow_id={ flow_id }
													step_id={ step_id }
													data={ ob_data }
													title={ ob_data.title }
													settings={
														allSetting?.settings?.[
															'multiple-order-bump'
														]
													}
													design_settings={ obDesign }
													callback={ updateOBList }
													dispatch={
														isControlled
															? dispatch
															: undefined
													}
													onEditClick={ onEditClick }
													openObSettingsId={
														openObSettingsId
													}
													toggleObSettings={
														toggleObSettings
													}
												/>
											);
										} ) }
									</ReactSortable>
								</>
							) }
						</div>
					</div>
				) }
				{ length === 0 && (
					<div className="border border-border-subtle border-solid bg-gray-25 rounded-md px-5 py-5 text-sm text-text-secondary text-center">
						{ __( 'Create an order bump.', 'cartflows-pro' ) }
					</div>
				) }
				{ ! hideAddControl && (
					<Container
						containerType="flex"
						gap="sm"
						className="wcf-multiple-order-bumps__add-new mt-5"
					>
						<div className="flex-1 flex flex-col gap-1">
							<Input
								size="md"
								value={ title || '' }
								onChange={ setTitle }
								placeholder={ __(
									'Enter order bump name',
									'cartflows-pro'
								) }
								error={ !! errorMsg }
								className="focus:!ring-0 focus:!ring-offset-0"
							/>
							{ errorMsg && (
								<span className="text-sm font-normal text-brand-500">
									{ errorMsg }
								</span>
							) }
						</div>
						<Button
							variant="outline"
							icon={ <Plus className="w-4 h-4 stroke-1" /> }
							iconPosition="left"
							loading={ is_processing }
							disabled={ is_processing }
							onClick={ addNewOrderBump }
							className="wcf-add-new-order-bump font-normal h-fit"
						>
							{ button_text }
						</Button>
					</Container>
				) }
			</Container>
			{ ! hideDocLink && (
				<DocField
					content={ sprintf(
						// translators: %1$s: link html start, %2$s: link html end
						__(
							'For more information about order bump settings please %1$sClick here.%2$s',
							'cartflows-pro'
						),
						'<a href="https://cartflows.com/docs/how-to-add-order-bumps-to-woocommerce-sales-funnel" class="text-brand-500 hover:text-brand-600 no-underline" target="_blank">',
						'</a>'
					) }
				/>
			) }
		</>
	);
}

export default MultiOrderBump;
