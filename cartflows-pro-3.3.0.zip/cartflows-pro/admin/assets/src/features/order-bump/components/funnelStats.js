// Stats lookup helpers — `options.ob_ab_stats` is injected into the REST /step-data response by
// `Cartflows_Pro_Order_Bump_Ab_Factory::inject_stats_into_step_data()` and folded into Redux state
// by SET_STEP_DATA. Shape: { [control_id]: { [vid]: { impressions, initiated, conversions } } }.
// Standalone bumps use a self-referencing key: [ob_id][ob_id]. A/B variants use [control_id][variant_id].
import { useStateValue } from '@Utils/StateProvider';

// Default row shape returned when no stats exist for a (control, vid) pair.
const ZERO = { impressions: 0, initiated: 0, conversions: 0 };

/**
 * Hook — returns the stats blob from Redux. Reactive to step-data refetches.
 *
 * @return {Object} Stats blob keyed by control id → variant id.
 */
export const useStatsBlob = () => {
	const [ stepState ] = useStateValue();
	const blob = stepState?.options?.ob_ab_stats;
	return blob && 'object' === typeof blob ? blob : {};
};

/**
 * Get the funnel row for a bump entry. Variants → wcf-control-ob; controls/standalone → own id.
 *
 * @param {Object} bump      Bump entry from wcf-order-bumps.
 * @param {Object} statsBlob Stats blob from useStatsBlob() — callers pass it in to keep this helper pure.
 * @return {{ impressions: number, initiated: number, conversions: number }} Funnel counters; zeros when no data.
 */
export const getStatsForBump = ( bump, statsBlob = {} ) => {
	if ( ! bump || ! bump.id ) {
		return { ...ZERO };
	}
	const controlId = bump[ 'wcf-control-ob' ]
		? bump[ 'wcf-control-ob' ]
		: bump.id;
	const row = statsBlob[ controlId ]?.[ bump.id ];
	if ( ! row || 'object' !== typeof row ) {
		return { ...ZERO };
	}
	return {
		impressions: parseInt( row.impressions || 0, 10 ),
		initiated: parseInt( row.initiated || 0, 10 ),
		conversions: parseInt( row.conversions || 0, 10 ),
	};
};

/**
 * Compute the conversion rate (conversions ÷ impressions × 100). Returns null when no data.
 *
 * @param {{ impressions: number, conversions: number }} stats Stats row.
 * @return {number|null} CR percentage or null when impressions = 0.
 */
export const computeCr = ( stats ) => {
	if ( ! stats || ! stats.impressions ) {
		return null;
	}
	return ( stats.conversions / stats.impressions ) * 100;
};

/**
 * Decide the current "winner" inside an A/B test. Picks the variant with the highest CR among
 * those whose impressions cleared the sanity threshold. Returns null when nothing qualifies.
 *
 * @param {string}        controlId           Control bump id.
 * @param {Array<object>} variations          control's ab-test-variations — list of { id, traffic }.
 * @param {Object}        statsBlob           Stats blob from useStatsBlob().
 * @param {number}        impressionThreshold Min impressions to be eligible (default 30).
 * @return {string|null} Winning variant id, or null.
 */
export const pickCurrentLeader = (
	controlId,
	variations,
	statsBlob = {},
	impressionThreshold = 30
) => {
	if ( ! Array.isArray( variations ) || ! variations.length ) {
		return null;
	}
	let leaderId = null;
	let leaderCr = -1;
	for ( const v of variations ) {
		if ( ! v || ! v.id ) {
			continue;
		}
		const row = statsBlob[ controlId ]?.[ v.id ];
		if ( ! row ) {
			continue;
		}
		const imp = parseInt( row.impressions || 0, 10 );
		const conv = parseInt( row.conversions || 0, 10 );
		if ( imp < impressionThreshold ) {
			continue;
		}
		const cr = ( conv / imp ) * 100;
		if ( cr > leaderCr ) {
			leaderCr = cr;
			leaderId = v.id;
		}
	}
	return leaderId;
};

export default { useStatsBlob, getStatsForBump, computeCr, pickCurrentLeader };
