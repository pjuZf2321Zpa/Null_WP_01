import { useRef, useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { Button } from '@bsf/force-ui';
import { ChevronRight, LayoutTemplate } from 'lucide-react';
import { Tooltip } from '@Fields';
import OrderBumpSkinPickerDrawer from './OrderBumpSkinPickerDrawer';
import './OrderBumpSkinPicker.scss';

/**
 * OrderBumpSkinPicker
 *
 * Styles-tab row that replaces the old "Order Bump Skin" dropdown, opening a
 * drawer of live previews so a skin can be seen before it is applied.
 *
 * @param {Object} props           Component props.
 * @param {Object} props.data      Field config from the PHP field map.
 * @param {string} props.value     Currently applied skin value.
 * @param {Object} props.orderBump The bump being edited, used to render previews.
 * @return {JSX.Element} The rendered field row.
 */
function OrderBumpSkinPicker( { data, value, orderBump } ) {
	const [ isOpen, setIsOpen ] = useState( false );
	const triggerRef = useRef( null );

	const labelId = `${ data.name }-label`;
	const valueId = `${ data.name }-value`;

	/**
	 * Opens and closes the drawer, restoring focus to the trigger on close.
	 *
	 * @param {boolean} next Next open state.
	 */
	const toggleDrawer = ( next ) => {
		setIsOpen( next );

		// Force UI only auto-restores focus when the overlay owns its own trigger.
		if ( ! next ) {
			window.requestAnimationFrame( () => triggerRef.current?.focus() );
		}
	};

	const options = data?.options || [];
	const selected = options.find( ( option ) => option.value === value );
	const selectedLabel = selected
		? selected.label
		: __( 'Select a skin', 'cartflows-pro' );

	const applySkin = ( skin ) => {
		// Mirrors SelectField's contract — ObInputEvents reads detail.name / detail.value.
		const syntheticEvent = { target: { value: skin, name: data.name } };

		document.dispatchEvent(
			new CustomEvent( 'wcf:select:change', {
				bubbles: true,
				detail: {
					e: syntheticEvent,
					name: data.name,
					value: skin,
				},
			} )
		);
	};

	return (
		<div className="wcf-field wcf-ob-skin-picker text-left">
			<div className="wcf-field__data flex items-center justify-between gap-2.5">
				{ data?.label && (
					<div
						className="wcf-field__data--label text-sm font-medium text-text-primary"
						id={ labelId }
					>
						{ /* No htmlFor: the control is a button, not the hidden input. */ }
						<span>{ data.label }</span>
						{ data?.tooltip && <Tooltip text={ data.tooltip } /> }
					</div>
				) }

				<div className="wcf-field__data--content w-[300px]">
					{ /* Hidden input keeps the field readable from the DOM by name. */ }
					<input
						type="hidden"
						id={ data.name }
						name={ data.name }
						value={ value || '' }
						readOnly
					/>
					<Button
						ref={ triggerRef }
						variant="outline"
						size="sm"
						className="wcf-ob-skin-picker__trigger w-full justify-between"
						icon={
							<ChevronRight className="text-field-placeholder" />
						}
						iconPosition="right"
						onClick={ () => toggleDrawer( true ) }
						aria-haspopup="dialog"
						aria-expanded={ isOpen }
						aria-labelledby={ `${ labelId } ${ valueId }` }
					>
						<span className="flex items-center gap-1.5">
							<LayoutTemplate
								className="size-4 shrink-0"
								strokeWidth={ 1.8 }
							/>
							<span id={ valueId } className="font-normal">
								{ selectedLabel }
							</span>
						</span>
					</Button>
				</div>
			</div>

			<OrderBumpSkinPickerDrawer
				open={ isOpen }
				setOpen={ toggleDrawer }
				options={ options }
				value={ value }
				orderBump={ orderBump }
				onSelect={ applySkin }
			/>
		</div>
	);
}

export default OrderBumpSkinPicker;
