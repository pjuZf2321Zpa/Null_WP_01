// Custom "A/B in browser window" glyph — lucide has no A/B icon; drawn to match lucide conventions.
const AbTestIcon = ( { className = '', ...props } ) => (
	<svg
		xmlns="http://www.w3.org/2000/svg"
		viewBox="0 0 24 24"
		fill="none"
		stroke="currentColor"
		strokeWidth="2"
		strokeLinecap="round"
		strokeLinejoin="round"
		className={ className }
		aria-hidden="true"
		{ ...props }
	>
		<rect x="2" y="3" width="20" height="18" rx="2.5" />
		<path d="M2 7.5h20" />
		<path d="M5.5 5.25h.01" />
		<path d="M8 5.25h.01" />
		<path d="M10.5 5.25h.01" />
		<path d="M15 5.25h3.5" />
		<path d="m4.75 18 3-7.25 3 7.25" />
		<path d="M5.9 15.5h3.7" />
		<path d="m14 10.75-2.5 7.25" />
		<path d="M15.25 10.75V18" />
		<path d="M15.25 10.75h2.4a1.8 1.8 0 0 1 0 3.6h-2.4" />
		<path d="M15.25 14.35h2.75a1.83 1.83 0 0 1 0 3.65h-2.75" />
	</svg>
);

export default AbTestIcon;
