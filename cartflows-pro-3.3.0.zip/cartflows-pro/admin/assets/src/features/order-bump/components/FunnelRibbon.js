// Shared funnel ribbon: renders Impressions → Initiated → Conversions + CR pill under any bump row.
// Used by both the A/B group rows and standalone (non-A/B) bump rows — same data shape, A/B-only
// affordances (winner badge) gated by props.
import { __, sprintf } from '@wordpress/i18n';
import { Container, Text, Badge, Tooltip } from '@bsf/force-ui';
import { HelpCircle } from 'lucide-react';

// CR below this percentage gets the warning tone — prompts the admin that the offer may underperform.
const LOW_CR_THRESHOLD = 5;

// Pure helper: turn (impressions, conversions) into a 1-decimal percentage string, "—" when no data.
const computeCrLabel = ( impressions, conversions ) => {
	if ( ! impressions || impressions <= 0 ) {
		return '—';
	}
	const pct = ( conversions / impressions ) * 100;
	return `${ pct.toFixed( 1 ) }%`;
};

/**
 * Renders the funnel ribbon under a bump row.
 *
 * @param {Object}  props
 * @param {number}  props.impressions Count of visitors who saw the bump.
 * @param {number}  props.initiated   Count of visitors who accepted the bump into cart.
 * @param {number}  props.conversions Count of orders placed with the bump in line items.
 * @param {boolean} props.isWinner    Currently-leading variant inside an A/B group; styles CR pill emphatically.
 */
const FunnelRibbon = ( {
	impressions = 0,
	initiated = 0,
	conversions = 0,
	isWinner = false,
} ) => {
	// CR is the headline metric — drop-off math (Imp→Init, Init→Conv) lives in tooltip enhancements; not in MVP.
	const crLabel = computeCrLabel( impressions, conversions );
	const crNumeric = impressions > 0 ? ( conversions / impressions ) * 100 : 0;
	const isLowCr = impressions > 0 && crNumeric < LOW_CR_THRESHOLD;

	// Nested sub-card inside the row (not a full-width band) so the stats visually belong to the bump above.
	const wrapperClass =
		'wcf-ob-funnel-ribbon py-2 px-4 mx-6 rounded-md border border-solid border-border-subtle bg-background-secondary';

	// Winner gets a saturated green pill + ring; low CR uses the yellow Force UI variant (closest to "warning orange" in the design tokens).
	// TODO: No Force UI prop for emphasized "winner" state — using className to layer a ring on top of the green pill.
	const hasData = impressions > 0;
	let crVariant = 'green';
	if ( ! hasData ) {
		crVariant = 'neutral';
	} else if ( ! isWinner && isLowCr ) {
		crVariant = 'yellow';
	}
	const winnerClass = isWinner ? 'ring-1 ring-support-success' : '';

	// Localised CR-pill label — appends "winner" tag when isWinner so the leading variant is unmistakable.
	let crLabelText = sprintf(
		/* translators: %s: conversion rate percentage */
		__( 'Conversion Rate %s', 'cartflows-pro' ),
		crLabel
	);
	if ( isWinner ) {
		crLabelText = sprintf(
			/* translators: %s: conversion rate percentage */
			__( 'Conversion Rate %s · winner', 'cartflows-pro' ),
			crLabel
		);
	} else if ( ! hasData ) {
		// A dash reads like broken data — say plainly that nothing is recorded yet.
		crLabelText = __( 'No data yet', 'cartflows-pro' );
	}

	return (
		<Container
			containerType="flex"
			align="center"
			gap="xl"
			className={ wrapperClass }
		>
			{ /* Impressions cell */ }
			<Container containerType="flex" align="center" gap="xs">
				<Tooltip
					content={ __(
						'Visitors who saw this bump.',
						'cartflows-pro'
					) }
					placement="top"
					arrow
				>
					<HelpCircle className="w-3.5 h-3.5 text-text-tertiary cursor-pointer" />
				</Tooltip>
				<Text
					size={ 12 }
					weight={ 500 }
					className="tracking-wider text-text-secondary"
				>
					{ __( 'Impressions', 'cartflows-pro' ) }
				</Text>
				<Text size={ 12 } weight={ 500 } className="text-text-primary">
					{ impressions }
				</Text>
			</Container>

			{ /* Funnel separator — Force UI Text rendering a chevron glyph. */ }
			<Text size={ 14 } className="text-text-tertiary">
				{ '›' }
			</Text>

			{ /* Initiated cell */ }
			<Container containerType="flex" align="center" gap="xs">
				<Tooltip
					content={ __(
						'Visitors who added this bump to their cart.',
						'cartflows-pro'
					) }
					placement="top"
					arrow
				>
					<HelpCircle className="w-3.5 h-3.5 text-text-tertiary cursor-pointer" />
				</Tooltip>
				<Text
					size={ 12 }
					weight={ 500 }
					className="tracking-wider text-text-secondary"
				>
					{ __( 'Initiated', 'cartflows-pro' ) }
				</Text>
				<Text size={ 12 } weight={ 500 } className="text-text-primary">
					{ initiated }
				</Text>
			</Container>

			<Text size={ 14 } className="text-text-tertiary">
				{ '›' }
			</Text>

			{ /* Conversions cell */ }
			<Container containerType="flex" align="center" gap="xs">
				<Tooltip
					content={ __(
						'Orders placed that include this bump.',
						'cartflows-pro'
					) }
					placement="top"
					arrow
				>
					<HelpCircle className="w-3.5 h-3.5 text-text-tertiary cursor-pointer" />
				</Tooltip>
				<Text
					size={ 12 }
					weight={ 500 }
					className="tracking-wider text-text-secondary"
				>
					{ __( 'Conversions', 'cartflows-pro' ) }
				</Text>
				<Text size={ 12 } weight={ 500 } className="text-text-primary">
					{ conversions }
				</Text>
			</Container>

			{ /* CR pill — pushed to the right via auto-margin wrapper. */ }
			<Container
				containerType="flex"
				align="center"
				gap="xs"
				className="ml-auto"
			>
				<Tooltip
					content={ __(
						'Percentage of impressions that became orders.',
						'cartflows-pro'
					) }
					placement="top"
					arrow
				>
					<HelpCircle className="w-3.5 h-3.5 text-text-tertiary cursor-pointer" />
				</Tooltip>
				<Badge
					label={ crLabelText }
					variant={ crVariant }
					type="pill"
					size="xs"
					className={ winnerClass }
					disableHover
				/>
			</Container>
		</Container>
	);
};

export default FunnelRibbon;
