import { useEffect } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Badge, Drawer, Text, toast } from '@bsf/force-ui';
import { Check } from 'lucide-react';
import OrderBumpSkinPreview from './OrderBumpSkinPreview';

const DESCRIPTION_ID = 'wcf-ob-skin-picker-description';

/**
 * OrderBumpSkinPickerDrawer
 *
 * Side drawer listing every registered skin as a live preview of the bump being
 * edited. Selecting one writes only the `style` key, exactly as the old dropdown
 * did, so custom colours and borders are left untouched.
 *
 * @param {Object}   props           Component props.
 * @param {boolean}  props.open      Whether the drawer is visible.
 * @param {Function} props.setOpen   Setter called with the next open state.
 * @param {Array}    props.options   Skin options as `[ { value, label, description } ]`.
 * @param {string}   props.value     Currently applied skin value.
 * @param {Object}   props.orderBump The bump being edited, used to render previews.
 * @param {Function} props.onSelect  Called with the chosen skin value.
 * @return {JSX.Element} The rendered drawer.
 */
function OrderBumpSkinPickerDrawer( {
	open,
	setOpen,
	options = [],
	value,
	orderBump,
	onSelect,
} ) {
	const title = __( 'Choose a skin', 'cartflows-pro' );

	useEffect( () => {
		const panel = document.querySelector(
			'.wcf-ob-skin-picker__drawer-panel'
		);

		if ( ! open || ! panel ) {
			return;
		}

		// Force UI hardcodes aria-label="drawer" on the dialog node and accepts no override.
		panel.setAttribute( 'aria-label', title );

		const description = panel.querySelector(
			'.wcf-ob-skin-picker__drawer-description'
		);

		// Force UI wires no aria-describedby, so the subtitle needs an id of its own.
		if ( description ) {
			description.id = DESCRIPTION_ID;
			panel.setAttribute( 'aria-describedby', DESCRIPTION_ID );
		}
	}, [ open, title ] );

	const handleSelect = ( option ) => {
		if ( option.value !== value ) {
			onSelect( option.value );

			toast.success(
				sprintf(
					/* translators: %s: skin name, e.g. "Style 3". */
					__( '%s applied', 'cartflows-pro' ),
					option.label
				),
				{
					description: __(
						'Save settings to publish the new layout.',
						'cartflows-pro'
					),
				}
			);
		}

		setOpen( false );
	};

	return (
		<Drawer
			open={ open }
			setOpen={ setOpen }
			className="wcf-ob-skin-picker__drawer"
			design="simple"
			position="right"
			exitOnEsc
			exitOnClickOutside
			scrollLock
		>
			<Drawer.Panel className="wcf-ob-skin-picker__drawer-panel">
				<Drawer.Header className="wcf-ob-skin-picker__drawer-header flex items-start justify-between gap-3">
					<div>
						<Drawer.Title className="text-lg text-text-primary">
							{ title }
						</Drawer.Title>
						<Drawer.Description className="wcf-ob-skin-picker__drawer-description mt-1 text-text-secondary">
							{ __(
								'Applying only changes the layout. You can switch back anytime.',
								'cartflows-pro'
							) }
						</Drawer.Description>
					</div>
					<Drawer.CloseButton />
				</Drawer.Header>
				<Drawer.Body className="overflow-x-hidden">
					{ /* TODO: No Force UI equivalent — a selectable card wrapping arbitrary preview markup. */ }
					<ul className="grid grid-cols-1 md:grid-cols-2 gap-4 list-none m-0 p-0">
						{ options.map( ( option ) => {
							const isSelected = option.value === value;

							return (
								<li key={ option.value } className="m-0">
									<button
										type="button"
										aria-pressed={ isSelected }
										onClick={ () => handleSelect( option ) }
										className={ `wcf-ob-skin-picker__tile w-full h-full p-0 box-border flex flex-col items-stretch rounded-lg cursor-pointer text-left border border-solid overflow-hidden bg-background-primary transition-colors ${
											isSelected
												? 'border-brand-500'
												: 'border-border-subtle hover:border-border-strong'
										}` }
									>
										{ /* inert keeps the preview's own controls out of the tab order. */ }
										<span
											className="wcf-ob-skin-picker__preview-region flex flex-1 items-center justify-center box-border p-4 bg-background-secondary"
											inert=""
											aria-hidden="true"
										>
											<span className="wcf-ob-skin-picker__preview block w-full">
												<OrderBumpSkinPreview
													orderBump={ {
														...orderBump,
														style: option.value,
													} }
													cbId={ `wcf-ob-skin-preview-cb-${ option.value }` }
													interactive={ false }
												/>
											</span>
										</span>

										<span className="flex items-start justify-between gap-2 box-border p-4 bg-background-primary">
											{ /* min-w-0 lets the description shrink instead of pushing the badge out. */ }
											<span className="flex flex-col gap-0.5 min-w-0">
												<Text
													size={ 14 }
													weight={ 600 }
													color="primary"
												>
													{ option.label }
												</Text>
												{ option.description && (
													<Text
														size={ 12 }
														weight={ 400 }
														color="secondary"
													>
														{ option.description }
													</Text>
												) }
											</span>
											{ isSelected && (
												<Badge
													label={ __(
														'Applied',
														'cartflows-pro'
													) }
													type="pill"
													variant="neutral"
													size="xs"
													icon={
														<Check className="size-3" />
													}
													disableHover
													className="shrink-0 self-center bg-brand-50 text-brand-600"
												/>
											) }
										</span>
									</button>
								</li>
							);
						} ) }
					</ul>
				</Drawer.Body>
			</Drawer.Panel>
			{ /* Backdrop is a sibling of the Panel here, unlike Dialog. */ }
			<Drawer.Backdrop />
		</Drawer>
	);
}

export default OrderBumpSkinPickerDrawer;
