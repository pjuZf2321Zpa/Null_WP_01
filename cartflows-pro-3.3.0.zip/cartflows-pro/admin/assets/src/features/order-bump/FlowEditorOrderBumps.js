import { StateProvider, useStateValue } from '@Utils/StateProvider';
import { ConfirmDialogProvider } from '@Alert/ConfirmDialog';
import { Toaster } from '@bsf/force-ui';
import reducer from '@ProStore/reducer';
import InlineOrderBumps from './InlineOrderBumps';

/**
 * Inline order-bump manager for the checkout step card on the steps page —
 * fills the free plugin's cartflows.flowEditor.orderBumps slot.
 *
 * @param {Object}   props
 * @param {number}   props.stepId           Checkout step ID.
 * @param {number}   props.flowId           Flow ID.
 * @param {Array}    props.initialBumps     Bumps from the flow-data API.
 * @param {Function} [props.onCountChange]  Bump-count change callback.
 * @param {Function} [props.onEditNavigate] Opens a bump's editor screen.
 * @return {Object} Inline order bumps list.
 */
function FlowEditorOrderBumps( props ) {
	// Read free's live store before overlaying — SET_FLOW_DATA flattens per-step stats here.
	const [ freeState ] = useStateValue();

	return (
		<StateProvider
			reducer={ reducer }
			initialState={ {
				step_id: props.stepId,
				flow_id: props.flowId,
				options: {
					ob_ab_stats: freeState?.options?.ob_ab_stats || {},
				},
				page_settings: null,
				current_ob: null,
			} }
		>
			<ConfirmDialogProvider>
				<InlineOrderBumps { ...props } />
				<Toaster />
			</ConfirmDialogProvider>
		</StateProvider>
	);
}

export default FlowEditorOrderBumps;
