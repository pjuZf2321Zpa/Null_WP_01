import { Fragment, useState } from '@wordpress/element';
import { useStateValue } from '@Utils/StateProvider';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { toast, Button, Text } from '@bsf/force-ui';
import { X } from 'lucide-react';
import OrderBumpTwoColumnSkeleton from './skeletons/OrderBumpTwoColumnSkeleton';
import { conditions } from './Helper';
import { RenderFields } from '@Fields';
import AiWriteButton from '@ProComponents/ai/AiWriteButton';

// Text fields that can be authored/regenerated with AI.
const AI_FIELDS = [ 'title_text', 'desc_text', 'checkbox_label', 'hl_text' ];

function OrderBumpContent() {
	const [ { page_settings, current_ob, step_id }, dispatch ] =
		useStateValue();

	// The field generating now, plus a per-field counter that remounts it to re-seed applied text.
	const [ generating, setGenerating ] = useState( '' );
	const [ refreshKeys, setRefreshKeys ] = useState( {} );
	// Variations per field, shown for the admin to pick from — never auto-applied.
	const [ suggestions, setSuggestions ] = useState( {} );

	const writeWithAi = ( fieldName ) => () => {
		if ( generating ) {
			return;
		}

		setGenerating( fieldName );

		apiFetch( {
			path: `/cartflows-pro/v1/admin/ob-ai-copy/${ step_id }`,
			method: 'POST',
			data: {
				field: fieldName,
				// Editor mode 'auto' maps to the copy endpoint's placeholder mode 'pool'.
				mode: 'auto' === current_ob?.product_mode ? 'pool' : 'manual',
				product_id: Number( current_ob?.product?.[ 0 ]?.value ) || 0,
				pool_ids: Array.isArray( current_ob?.ai_product_pool )
					? current_ob.ai_product_pool.map( ( p ) =>
							Number( p.value )
					  )
					: [],
				tone: '',
			},
		} )
			.then( ( res ) => {
				if (
					res?.success &&
					Array.isArray( res.variations ) &&
					res.variations.length
				) {
					setSuggestions( ( prev ) => ( {
						...prev,
						[ fieldName ]: res.variations,
					} ) );
					return;
				}
				toast.error(
					res?.message ||
						__( 'Could not generate text.', 'cartflows-pro' )
				);
			} )
			.catch( ( err ) => {
				toast.error(
					err?.message ||
						__(
							'Something went wrong. Please try again.',
							'cartflows-pro'
						)
				);
			} )
			.finally( () => setGenerating( '' ) );
	};

	// Apply the picked variation to its field and clear that field's picker.
	const applySuggestion = ( fieldName, text ) => {
		dispatch( { type: 'SET_OB_OPTION', name: fieldName, value: text } );
		window.wcfUnsavedChanges = true;

		// The description is TinyMCE-backed — set content in place instead of remounting the editor.
		const descEditor =
			'desc_text' === fieldName && window.tinymce
				? window.tinymce.get( 'wcf-order-bump-desc-editor' )
				: null;
		if ( descEditor ) {
			descEditor.setContent( text );
		} else {
			// Plain-text fields: bump the key so the field remounts and re-seeds.
			setRefreshKeys( ( prev ) => ( {
				...prev,
				[ fieldName ]: ( prev[ fieldName ] || 0 ) + 1,
			} ) );
		}
		dismissSuggestions( fieldName );
	};

	const dismissSuggestions = ( fieldName ) => {
		setSuggestions( ( prev ) => {
			const next = { ...prev };
			delete next[ fieldName ];
			return next;
		} );
	};

	if ( null === page_settings || 'undefined' === page_settings ) {
		return <OrderBumpTwoColumnSkeleton />;
	}

	const obsettings = page_settings?.settings[ 'multiple-order-bump-content' ];

	return (
		<div className="wcf-order-bump-content-tab">
			<div className="wcf-order-bump-content-tab__settings space-y-6">
				{ Object.keys( obsettings.fields ).map( ( field ) => {
					const data = obsettings.fields[ field ];

					const value = current_ob[ data.name ];
					const isActive = conditions.isActiveControl(
						data,
						current_ob
					);

					const renderedField = (
						<RenderFields
							data={ data }
							value={ value }
							isActive={ isActive }
							field={ field }
							options={ current_ob }
							displayAs="div"
							tabName="order-bump-content"
							fieldSize="sm"
						/>
					);

					if ( isActive && AI_FIELDS.includes( data.name ) ) {
						const busy = generating === data.name;
						const fieldSuggestions = suggestions[ data.name ];
						return (
							<div
								key={ `${ field }-${
									refreshKeys[ data.name ] || 0
								}` }
								className="wcf-ob-ai-field relative"
							>
								<div className="absolute right-0 top-0 z-10">
									<AiWriteButton
										regenerate={ !! fieldSuggestions }
										loading={ busy }
										disabled={ !! generating }
										onGenerate={ writeWithAi( data.name ) }
									/>
								</div>
								{ renderedField }
								{ fieldSuggestions && (
									/* TODO: No Force UI equivalent — suggestion picker panel (ported verbatim from cartflows PR #2471). */
									<div className="wcf-ob-ai-suggestions mt-2 flex flex-col gap-2 rounded-lg border border-solid border-border-subtle bg-background-secondary p-3">
										<div className="flex items-center justify-between">
											<Text
												size={ 12 }
												weight={ 600 }
												color="tertiary"
												className="uppercase tracking-wide"
											>
												{ __(
													'Pick a suggestion',
													'cartflows-pro'
												) }
											</Text>
											<Button
												type="button"
												variant="ghost"
												size="xs"
												icon={
													<X className="size-3.5" />
												}
												onClick={ () =>
													dismissSuggestions(
														data.name
													)
												}
												aria-label={ __(
													'Dismiss suggestions',
													'cartflows-pro'
												) }
											/>
										</div>
										{ fieldSuggestions.map(
											( text, idx ) => (
												/* TODO: No Force UI equivalent — multiline text option row (ported verbatim from cartflows PR #2471). */
												<button
													key={ idx }
													type="button"
													onClick={ () =>
														applySuggestion(
															data.name,
															text
														)
													}
													className="w-full cursor-pointer rounded-md border border-solid border-border-subtle bg-background-primary px-3 py-2 text-left text-sm font-normal text-text-primary hover:border-brand-500 hover:bg-brand-25"
												>
													{ text }
												</button>
											)
										) }
									</div>
								) }
							</div>
						);
					}

					return <Fragment key={ field }>{ renderedField }</Fragment>;
				} ) }
			</div>
		</div>
	);
}

export default OrderBumpContent;
