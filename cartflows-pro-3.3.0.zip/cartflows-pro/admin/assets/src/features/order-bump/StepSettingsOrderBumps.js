import { ConfirmDialogProvider } from '@Alert/ConfirmDialog';
import { Toaster } from '@bsf/force-ui';
import MultiOrderBump from './MultiOrderBump';

/**
 * Order Bumps tab for the step settings screen — fills the free plugin's
 * cartflows.stepSettings.orderBumps slot; reads free's store via the shared context.
 *
 * @return {Object} Order bumps manager.
 */
function StepSettingsOrderBumps() {
	return (
		<ConfirmDialogProvider>
			<MultiOrderBump />
			<Toaster />
		</ConfirmDialogProvider>
	);
}

export default StepSettingsOrderBumps;
