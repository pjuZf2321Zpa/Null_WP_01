import { useState, useEffect, createRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { useStateValue } from '@Utils/StateProvider';
import { validateTitleField } from '@ProUtils/validate';
import OrderBumpPagesRoute from './OrderBumpPagesRoute';
import useConfirm from '@Alert/ConfirmDialog';
// Surface D · Funnel ribbon under every plain (non-A/B) bump row.
import FunnelRibbon from './components/FunnelRibbon';
import { getStatsForBump, useStatsBlob } from './components/funnelStats';
// AJAX hook is reused so the create-variation call shares the exact same wiring used inside the A/B group.
import { useOrderBumpAb, useScrollObIntoView } from './hooks';
import {
	Container,
	Badge,
	Button,
	Tooltip,
	Switch,
	Loader,
	Input,
	toast,
} from '@bsf/force-ui';
import { SquarePen, Trash2, Copy, CircleAlert, PenLine } from 'lucide-react';
import AbTestIcon from './components/AbTestIcon';

function OrderBumpRepeater( props ) {
	const {
		flow_id,
		step_id,
		data,
		callback,
		dispatch: dispatchProp,
		onEditClick,
		// Lifted state from MultiOrderBump — keeps a single open panel across the whole list.
		openObSettingsId = '',
		toggleObSettings,
	} = props;

	const [ {}, dispatchStore ] = useStateValue();
	const dispatch = dispatchProp || dispatchStore;
	// Funnel stats blob (from REST step-data response, folded into Redux options.ob_ab_stats).
	const statsBlob = useStatsBlob();
	const funnelStats = getStatsForBump( data, statsBlob );
	const [ status, setStatus ] = useState( data.status );

	const [ statusProcess, setStatusProcess ] = useState( false );
	const [ actionProcess, setActionProcess ] = useState( '' );

	const [ editTitle, setEditTitle ] = useState( false );
	const [ savingState, setSavingState ] = useState( false );
	const newTitleInput = createRef();

	useEffect( () => {
		if ( editTitle ) {
			newTitleInput.current?.focus();
		}
	}, [ editTitle ] );

	// True only when the shared parent state has selected THIS bump's settings panel.
	const isSettingsOpen = openObSettingsId === data.id;

	useScrollObIntoView( isSettingsOpen, data.id );

	const confirm = useConfirm();
	// CF-1154 Phase 1.7d: shared A/B AJAX wrapper so the kebab on plain rows fires the same create-variation call used inside the A/B group.
	const ab = useOrderBumpAb();

	// Handler for the "A/B Split Test" kebab item — turns this plain bump into the control of a fresh A/B test.
	const startAbSplitTest = async () => {
		const result = await ab.createVariation( {
			stepId: step_id,
			ob_id: data.id,
		} );
		if ( result?.success ) {
			// Refresh the entire wcf-order-bumps array in Redux so the plain row re-renders as part of an A/B group on next tick.
			dispatch( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success(
				__( 'A/B test variation created!', 'cartflows-pro' )
			);
		}
	};

	useEffect( () => {
		setStatus( status );
	}, [ status, isSettingsOpen ] );

	let ob_title = data.title;

	const editTitleEvent = function ( e ) {
		e.preventDefault();
		setEditTitle( true );
	};

	const cancelNewTitleEvent = function ( e ) {
		e.preventDefault();

		setEditTitle( false );
	};

	const saveNewTitleEvent = function ( ob_id ) {
		setSavingState( true );

		const new_ob_title = newTitleInput.current.value,
			formData = new window.FormData();

		formData.append( 'action', 'cartflows_pro_update_order_bump_title' );
		formData.append(
			'security',
			cartflows_admin.update_order_bump_title_nonce
		);
		formData.append( 'step_id', step_id );
		formData.append( 'new_title', new_ob_title );
		formData.append( 'ob_id', ob_id );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( () => {
			dispatch( {
				type: 'SET_OB_TITLE',
				title: new_ob_title,
				name: 'wcf-order-bumps',
				ob_id,
			} );
			setSavingState( false );
			setEditTitle( false );
			toast.success( __( 'Order bump title updated!', 'cartflows-pro' ) );
		} );
	};

	const getOBName = function () {
		if ( '' === ob_title ) {
			ob_title = __( '(no title)', 'cartflows-pro' );
		}

		let editable_title = validateTitleField(
			ob_title,
			cartflows_admin.title_length.max,
			cartflows_admin.title_length.display_length
		);
		let edit_title_btns = (
			<Tooltip
				content={ __( 'Edit Order Bump Name', 'cartflows-pro' ) }
				placement="bottom"
			>
				<Button
					variant="ghost"
					size="xs"
					icon={ <PenLine className="w-3 h-3 stroke-1" /> }
					onClick={ editTitleEvent }
					className="wcf-ob-header__title--edit"
				/>
			</Tooltip>
		);

		if ( editTitle ) {
			editable_title = (
				<Input
					size="sm"
					ref={ newTitleInput }
					defaultValue={ ob_title }
					className="new-step-title focus:!ring-0 focus:!ring-offset-0 !h-8 [&>input]:!h-8 [&>input]:!min-h-8 [&>input]:!py-1"
				/>
			);

			edit_title_btns = (
				<>
					<Button
						variant="primary"
						size="xs"
						loading={ savingState }
						onClick={ () => saveNewTitleEvent( data.id ) }
					>
						{ __( 'Save', 'cartflows-pro' ) }
					</Button>
					<Button
						variant="secondary"
						size="xs"
						onClick={ cancelNewTitleEvent }
					>
						{ __( 'Cancel', 'cartflows-pro' ) }
					</Button>
				</>
			);
		}

		return (
			<>
				<span className="wcf-ob-header__title--text">
					{ editable_title }
				</span>
				<span className="wcf-ob-header__title--buttons flex gap-2">
					{ edit_title_btns }
				</span>
			</>
		);
	};

	const obStatus = function ( ob_id ) {
		setStatusProcess( true );
		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_pro_update_order_bump_status' );
		formData.append(
			'security',
			cartflows_admin.update_order_bump_status_nonce
		);
		formData.append( 'ob_id', ob_id );
		formData.append( 'post_id', flow_id );
		formData.append( 'step_id', step_id );
		formData.append( 'ob_status', ! status );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( () => {
			dispatch( {
				type: 'SET_OB_STATUS',
				name: 'wcf-order-bumps',
				newStatus: ! status,
				ob_id,
			} );
			setStatus( ! status );
			setStatusProcess( false );
			toast.success(
				! status
					? __( 'Order bump enabled!', 'cartflows-pro' )
					: __( 'Order bump disabled!', 'cartflows-pro' )
			);
		} );
	};

	const removeOrderBump = async function ( ob_id ) {
		const isconfirm = await confirm( {
			title: __( 'Delete Order Bump', 'cartflows-pro' ),
			description: __(
				'Do you really want to delete this order bump permanently?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Delete', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );

		if ( ! isconfirm ) {
			return;
		}

		setActionProcess( 'delete' );
		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_pro_delete_order_bump' );
		formData.append( 'security', cartflows_admin.delete_order_bump_nonce );
		formData.append( 'ob_id', ob_id );
		formData.append( 'post_id', flow_id );
		formData.append( 'step_id', step_id );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( response ) => {
			if ( response.success ) {
				dispatch( {
					type: 'REMOVE_ORDER_BUMP',
					name: 'wcf-order-bumps',
					ob_id,
				} );
				setActionProcess( '' );
				toast.success( __( 'Order bump deleted!', 'cartflows-pro' ) );
			}
		} );
	};

	const cloneOrderBump = ( ob_id ) => {
		const formData = new window.FormData();
		setActionProcess( 'clone' );
		formData.append( 'action', 'cartflows_pro_clone_order_bump' );
		formData.append( 'security', cartflows_admin.clone_order_bump_nonce );
		formData.append( 'ob_id', ob_id );
		formData.append( 'step_id', step_id );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( response ) => {
			if ( response.success ) {
				// Snapshot row ids before the list re-renders so the fresh clone can be diffed out.
				const prevIds = Array.from(
					document.querySelectorAll( '[data-ob-id]' )
				).map( ( el ) => el.dataset.obId );
				dispatch( {
					type: 'UPDATE_ORDER_BUMP',
					name: 'wcf-order-bumps',
					order_bumps: response.data.order_bumps,
				} );
				setActionProcess( '' );
				toast.success( __( 'Order bump cloned!', 'cartflows-pro' ) );
				setTimeout( () => {
					const newRow = Array.from(
						document.querySelectorAll( '[data-ob-id]' )
					).find( ( el ) => ! prevIds.includes( el.dataset.obId ) );
					if ( ! newRow ) {
						return;
					}
					newRow.scrollIntoView( {
						behavior: 'smooth',
						block: 'center',
					} );
					newRow.classList.add( 'bg-brand-25' );
					setTimeout(
						() => newRow.classList.remove( 'bg-brand-25' ),
						2000
					);
				}, 100 );
			}
		} );
	};

	const showOBSettings = function ( ob_id ) {
		if ( 'function' === typeof onEditClick ) {
			onEditClick( ob_id );
			return;
		}
		// Single setter from MultiOrderBump — toggles inside that one state so every row reacts.
		// Scrolling is handled by the isSettingsOpen effect above, after the panel has rendered.
		toggleObSettings?.( ob_id );
	};

	return (
		<>
			{ /* TODO: No Force UI equivalent — sortable bump row wrapper */ }
			<div
				className={ `wcf-order-bump-item scroll-mt-16 border-0 border-t border-border-subtle border-solid first:border-t-0 last:rounded-b-lg ${
					isSettingsOpen ? 'border-l-2 border-l-brand-500' : ''
				}` }
				data-ob-id={ data.id }
			>
				<div
					className={ `wcf-order-bump pb-5 transition-colors duration-500 ${
						isSettingsOpen ? 'bg-brand-25' : ''
					}` }
					onDragEnd={ callback }
				>
					<Container
						containerType="flex"
						align="center"
						className="wcf-order-bump__content-wrapper relative p-6 text-sm gap-2"
					>
						<div className="wcf-order-bump__data wcf-column--product flex-1 min-w-0">
							{
								<div className="wcf-order-bump__data-title flex items-center gap-2 min-h-8">
									<span className="text-sm font-medium text-text-primary flex gap-2 justify-center items-center min-h-8">
										{ getOBName() }
									</span>

									{ '' === data.product && (
										<Badge
											label={ __(
												'No product',
												'cartflows-pro'
											) }
											variant="warning"
											icon={
												<CircleAlert className="w-4 h-4" />
											}
											size="xs"
										/>
									) }
								</div>
							}
						</div>
						<Container
							containerType="flex"
							gap="xs"
							className="wcf_order_bump__status w-28 shrink-0"
						>
							<Switch
								value={ status }
								size="sm"
								label={ {
									heading: status
										? __( 'Active', 'cartflows-pro' )
										: __( 'Inactive', 'cartflows-pro' ),
								} }
								onChange={ () => obStatus( data.id ) }
								disabled={ statusProcess }
							/>

							{ statusProcess && (
								<Loader size="sm" variant="primary" />
							) }
						</Container>

						<Container
							containerType="flex"
							justify="end"
							align="center"
							gap="xs"
							className="wcf-order-bump__action wcf-column--actions w-36 shrink-0"
						>
							<Tooltip
								content={ __(
									'Duplicate Order Bump',
									'cartflows-pro'
								) }
								placement="bottom"
							>
								<Button
									variant="ghost"
									size="xs"
									icon={
										'clone' === actionProcess ? (
											<Loader size="sm" />
										) : (
											<Copy className="w-4 h-4 stroke-1" />
										)
									}
									onClick={ () => cloneOrderBump( data.id ) }
									className="wcf-clone-bump-button"
								/>
							</Tooltip>
							<Tooltip
								content={ __(
									'Edit Order Bump',
									'cartflows-pro'
								) }
								placement="bottom"
							>
								<Button
									variant="ghost"
									size="xs"
									icon={
										<SquarePen className="w-4 h-4 stroke-1" />
									}
									onClick={ () => showOBSettings( data.id ) }
									className={ `wcf-setting-bump-button ${
										isSettingsOpen
											? '!bg-brand-50 !text-brand-500'
											: ''
									}` }
								/>
							</Tooltip>
							<Tooltip
								content={ __(
									'Delete Order Bump',
									'cartflows-pro'
								) }
								placement="bottom"
							>
								<Button
									variant="ghost"
									size="xs"
									icon={
										'delete' === actionProcess ? (
											<Loader size="sm" />
										) : (
											<Trash2 className="w-4 h-4 stroke-1" />
										)
									}
									onClick={ () => removeOrderBump( data.id ) }
									className="wcf-remove-order-bump-button"
								/>
							</Tooltip>
							<Tooltip
								content={ __(
									'Start A/B Test',
									'cartflows-pro'
								) }
								placement="bottom"
							>
								<Button
									variant="ghost"
									size="xs"
									icon={
										<AbTestIcon className="w-4 h-4 stroke-1" />
									}
									onClick={ startAbSplitTest }
									aria-label={ __(
										'Start A/B Test',
										'cartflows-pro'
									) }
									className="wcf-start-ab-test-button"
								/>
							</Tooltip>
						</Container>
					</Container>
					{ /* Surface D · Inline funnel ribbon — under every plain bump row, no A/B context. */ }
					<FunnelRibbon
						impressions={ funnelStats.impressions }
						initiated={ funnelStats.initiated }
						conversions={ funnelStats.conversions }
					/>
				</div>
				{ /* Current Order bmp settings in tab */ }
				{ isSettingsOpen && <OrderBumpPagesRoute ob_id={ data.id } /> }
			</div>
		</>
	);
}

export default OrderBumpRepeater;
