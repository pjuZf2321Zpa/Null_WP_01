import { useStateValue } from '@Utils/StateProvider';
import OrderBumpTwoColumnSkeleton from './skeletons/OrderBumpTwoColumnSkeleton';
import { conditions } from './Helper';
import { SectionHeadingField, RenderFields } from '@Fields';
import OrderBumpSkinPicker from './components/OrderBumpSkinPicker';

function OrderBumpDesign() {
	const [ { page_settings, current_ob } ] = useStateValue();

	if ( null === page_settings || 'undefined' === page_settings ) {
		return <OrderBumpTwoColumnSkeleton />;
	}

	const obDesign = page_settings?.settings[ 'multiple-order-bump-design' ];

	/**
	 * Renders one field row.
	 *
	 * The `picker` marker is handled here rather than in the shared RenderFields
	 * registry because that registry lives in the free plugin, and the picker
	 * needs the whole bump to render its previews. The field keeps `type` of
	 * `select` so the legacy admin, which shares the PHP map, still renders it.
	 *
	 * @param {string} key   React key for the row.
	 * @param {Object} data  Field config from the PHP field map.
	 * @param {string} field Field slug, used for the row's CSS class.
	 * @return {JSX.Element} The rendered row.
	 */
	const renderField = ( key, data, field ) => {
		const value = current_ob[ data.name ];
		const isActive = conditions.isActiveControl( data, current_ob );

		if ( 'skin' === data.picker ) {
			return (
				<div
					key={ key }
					className={ `wcf-ob-design-tab--row wcf-field-row-${ field } mb-4 last:mb-0 ${
						! isActive ? 'hidden' : ''
					}` }
				>
					<OrderBumpSkinPicker
						data={ data }
						value={ value }
						orderBump={ current_ob }
					/>
				</div>
			);
		}

		return (
			<RenderFields
				key={ key }
				data={ data }
				value={ value }
				isActive={ isActive }
				field={ field }
				displayAs="div"
				tabName="ob-design"
				fieldSize="sm"
			/>
		);
	};

	return (
		<div className="wcf-order-bump-design-tab">
			<div className="wcf-order-bump-design-tab__settings">
				{ obDesign &&
					Object.keys( obDesign.fields ).map( ( field ) => {
						const sectionData = obDesign.fields[ field ];
						let dynamicRowClass = '';

						if ( 'borders' === sectionData.id ) {
							dynamicRowClass = 'grid grid-cols-4 gap-x-2';
						}
						if ( 'shadow' === sectionData.id ) {
							dynamicRowClass = 'grid grid-cols-4 gap-x-2';
						}

						return sectionData.section_fields ? (
							<div
								key={ field }
								className={ `wcf-order-bump-design-tab--${ sectionData.id }-section ${ dynamicRowClass } border border-border-subtle rounded-md mb-5` }
							>
								<div className="wcf-order-bump-deign-tab--heading-section col-span-full">
									<SectionHeadingField
										label={ sectionData.title }
										labelClass="block text-base font-semibold text-text-primary mb-5"
									/>
								</div>

								{ Object.keys( sectionData.section_fields ).map(
									( sectionField ) =>
										renderField(
											sectionField,
											sectionData.section_fields[
												sectionField
											],
											sectionField
										)
								) }
							</div>
						) : (
							<div
								key={ field }
								className={ `wcf-order-bump-design-tab--section mb-5` }
							>
								{ renderField(
									sectionData.name,
									sectionData,
									sectionData.name
								) }
							</div>
						);
					} ) }
			</div>
		</div>
	);
}

export default OrderBumpDesign;
