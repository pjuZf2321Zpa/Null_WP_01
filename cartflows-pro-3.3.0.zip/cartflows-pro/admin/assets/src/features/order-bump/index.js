import { addFilter } from '@wordpress/hooks';
import { isPlusProPlan } from '@ProUtils/plan';
import StepSettingsOrderBumps from './StepSettingsOrderBumps';
import FlowEditorOrderBumps from './FlowEditorOrderBumps';
import { saveOrderBumpSettings } from './hooks/useOrderBump';

addFilter(
	'cartflows.stepSettings.orderBumps',
	'cartflows-pro/order-bump/step-settings',
	( current ) => ( isPlusProPlan() ? StepSettingsOrderBumps : current )
);

addFilter(
	'cartflows.stepSettings.orderBumpsSave',
	'cartflows-pro/order-bump/step-settings-save',
	( current ) => ( isPlusProPlan() ? saveOrderBumpSettings : current )
);

addFilter(
	'cartflows.flowEditor.orderBumps',
	'cartflows-pro/order-bump/flow-editor',
	( current ) => ( isPlusProPlan() ? FlowEditorOrderBumps : current )
);
