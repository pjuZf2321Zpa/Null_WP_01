import { useEffect } from '@wordpress/element';
import './OrderBumpPreview.scss';
import { useStateValue } from '@Utils/StateProvider';
import OrderBumpSkinPreview from './components/OrderBumpSkinPreview';

/**
 * OrderBumpPreview
 *
 * Live preview shown above the Order Bump tabs. Owns the sticky-on-scroll
 * behaviour and the bump data lookup; the skin markup itself lives in
 * OrderBumpSkinPreview so the skin picker can render the same renderer.
 *
 * @return {JSX.Element} The preview wrapper.
 */
function OrderBumpPreview() {
	const [ { current_ob } ] = useStateValue();

	// Scroll to top fix the preview section
	useEffect( () => {
		const OB_wrapper = document.getElementById(
			'wcf-order-bump-preview-wrapper'
		);

		if ( ! OB_wrapper ) {
			return;
		}

		const sticky_offset = OB_wrapper.offsetTop - 25;

		// Named so the cleanup can actually detach it; addEventListener returns undefined.
		const scrollCallBack = () => {
			OB_wrapper.classList.toggle(
				'sticky',
				window.pageYOffset > sticky_offset
			);
		};

		window.addEventListener( 'scroll', scrollCallBack );

		return () => {
			window.removeEventListener( 'scroll', scrollCallBack );
		};
	}, [] );
	// Scroll to top fix the preview section

	return (
		<div
			id="wcf-order-bump-preview-wrapper"
			className="wcf-order-bump-preview-wrapper"
		>
			<OrderBumpSkinPreview orderBump={ current_ob } />
		</div>
	);
}

export default OrderBumpPreview;
