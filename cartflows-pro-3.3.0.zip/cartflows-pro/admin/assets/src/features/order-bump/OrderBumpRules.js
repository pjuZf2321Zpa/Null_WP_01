import { useState } from '@wordpress/element';
import { useStateValue } from '@Utils/StateProvider';
import { __ } from '@wordpress/i18n';
import OrderBumpRulesSkeleton from './skeletons/OrderBumpRulesSkeleton';
import { ToggleField, DocField } from '@Fields';
import OBRuleRepeater from './OBRuleRepeater';
import { ReactSortable } from 'react-sortablejs';
import {
	ChevronUpIcon,
	ChevronDownIcon,
	PlusIcon,
} from '@heroicons/react/24/outline';
import { Badge, Button } from '@bsf/force-ui';

// 6-dot drag handle matching the Force UI design system.
const DragHandleIcon = ( props ) => (
	<svg
		width="20"
		height="20"
		viewBox="0 0 20 20"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
		aria-hidden="true"
		{ ...props }
	>
		<circle cx="7" cy="5" r="1.25" fill="currentColor" />
		<circle cx="7" cy="10" r="1.25" fill="currentColor" />
		<circle cx="7" cy="15" r="1.25" fill="currentColor" />
		<circle cx="13" cy="5" r="1.25" fill="currentColor" />
		<circle cx="13" cy="10" r="1.25" fill="currentColor" />
		<circle cx="13" cy="15" r="1.25" fill="currentColor" />
	</svg>
);

function OrderBumpRules() {
	const [ { options, current_ob }, dispatch ] = useStateValue();

	const [ ruleGroupDisplay, setRuleGroupDisplay ] = useState( {
		ruleGroupId: '',
		isOpen: false,
	} );

	const { ruleGroupId, isOpen } = ruleGroupDisplay;

	if ( null === options || 'undefined' === current_ob ) {
		return <OrderBumpRulesSkeleton />;
	}

	const conditions = current_ob.rules;

	if ( 'undefined' === typeof conditions ) {
		return (
			<DocField
				content={ __(
					'Please Update the CartFlows Pro to the latest version to use the conditional order bump feature.',
					'cartflows-pro'
				) }
			/>
		);
	}

	const addNewGroup = () => {
		const newGroup = {
			group_id: Math.random().toString( 36 ).substring( 2, 5 ),
			rules: [
				{
					rule_id: Math.random().toString( 36 ).substring( 2, 5 ),
					condition: 'cart_item',
					operator: '',
					value: '',
				},
			],
		};

		dispatch( {
			type: 'ADD_NEW_OB_GROUP',
			name: 'rules',
			newGroup,
		} );
	};

	const addNewRule = ( group_id ) => {
		const newRule = {
			rule_id: Math.random().toString( 36 ).substring( 2, 5 ),
			condition: 'cart_item',
			operator: '',
			value: '',
		};

		dispatch( {
			type: 'ADD_NEW_OB_RULE',
			name: 'rules',
			newRule,
			group_id,
		} );
	};

	const showRules = function ( event ) {
		const group_id = event.target.getAttribute( 'data-group_id' );

		setRuleGroupDisplay( {
			ruleGroupId: group_id,
			isOpen: ruleGroupId === group_id && isOpen ? false : true,
		} );
	};

	const hideButton = function () {
		const button = document.getElementsByClassName(
			'wcf-order-bumps-rules--or_group__button'
		)[ 0 ];
		button.setAttribute( 'style', 'display:none' );
	};

	const showButton = function () {
		const button = document.getElementsByClassName(
			'wcf-order-bumps-rules--or_group__button'
		)[ 0 ];

		button.setAttribute( 'style', 'display:inline-block' );
	};

	return (
		<div className="wcf-order-bumps-rules-page">
			<div className="wcf-order-bumps-rules-page--enable_option">
				<ToggleField
					name="is_rule"
					value={ current_ob.is_rule }
					label={ __(
						'Enable conditional order bump ',
						'cartflows-pro'
					) }
					tooltip={ __(
						'By enabling this option, you can create the conditions to display the order bump.',
						'cartflows-pro'
					) }
				/>
			</div>
			{ /* Saved-while-disabled bumps store rules=[] — without this the tab renders blank. */ }
			{ 'yes' === current_ob.is_rule &&
				conditions &&
				0 === conditions.length && (
					<div className="wcf-order-bumps-rules--or_group__button mt-8">
						<Button
							variant="outline"
							size="md"
							icon={ <PlusIcon className="w-4 h-4 stroke-2" /> }
							iconPosition="left"
							className="wcf-order-bumps-rules--or_group_button !bg-brand-25 !text-brand-600 !outline-brand-300 hover:!bg-brand-50 hover:!outline-brand-300"
							onClick={ addNewGroup }
						>
							{ __( 'Add Conditions Group', 'cartflows-pro' ) }
						</Button>
					</div>
				) }
			{ 'yes' === current_ob.is_rule &&
				conditions &&
				conditions.length > 0 && (
					<div className="mt-8">
						<ReactSortable
							id="wcf-order-bump-sortable-wrapper"
							className="wcf-order-bump--sortable-wrapper flex flex-col gap-4"
							list={ conditions }
							setList={ ( newState ) =>
								dispatch( {
									type: 'SET_OB_RULES_GROUPS',
									groups: newState,
									fieldName: 'rules',
								} )
							}
							swapThreshold={ 0.8 }
							direction={ 'vertical' }
							animation={ 150 }
							handle={
								'.wcf-order-bumps-rules-page--group_wrapper'
							}
							filter={
								'.wcf-order-bumps-rules--rule_fields, .wcf-order-bumps-rules--rule_actions, .wcf-field wcf-select-option, .wcf-order-bumps-rules--add-rule__repeater .wcf-button.wcf-button--secondary, .wcf-field__data--content, .wcf-order-bumps-rules-page--group_wrapper__footer, .wcf-checkout-rules--group_header__right'
							}
							preventOnFilter={ false }
							onStart={ hideButton }
							onEnd={ showButton }
						>
							{ conditions.map( ( group, g_index ) => {
								const group_id = group.group_id;
								const rules = group.rules;

								return (
									<div
										className="wcf-order-bumps-rules-page--group_wrapper"
										key={ group_id }
									>
										<div
											// No overflow clipping here, or it cuts off the dropdowns inside.
											className="wcf-order-bumps-rules--group border border-solid border-cartflows-border rounded-md shadow-sm bg-background-primary"
											data-group-id={ group_id }
										>
											<input
												type="hidden"
												name={ `rules[${ g_index }][group_id]` }
												value={ group_id }
											/>
											<div className="wcf-order-bumps-rules--group-header bg-background-primary p-4 flex items-center justify-between gap-4">
												<div className="wcf-order-bumps-rules--group_header__left flex gap-4 items-center">
													<div className="wcf-order-bumps-rule--sortable-toggle flex cursor-move text-text-tertiary hover:text-text-secondary">
														<DragHandleIcon />
													</div>
													<span className="wcf-group-header--text font-sm font-normal text-text-tertiary">
														{ __(
															'Show this order bump if following conditions are true',
															'cartflows-pro'
														) }
													</span>
												</div>
												<div className="wcf-order-bumps-rules--group_header__right flex gap-2 items-center">
													{ ruleGroupId ===
														group_id && isOpen ? (
														<ChevronUpIcon
															className="w-4 h-4 stroke-1 text-text-tertiary hover:text-text-secondary cursor-pointer"
															aria-hidden="true"
															onClick={
																showRules
															}
															data-group_id={
																group_id
															}
														/>
													) : (
														<ChevronDownIcon
															className="w-4 h-4 stroke-1 text-text-tertiary hover:text-text-secondary cursor-pointer"
															aria-hidden="true"
															onClick={
																showRules
															}
															data-group_id={
																group_id
															}
														/>
													) }
												</div>
											</div>
											<div
												id={ `wcf-order-bumps-rules--group-${ group_id }` }
												className={ `p-4 bg-background-secondary border-t border-solid border-border-subtle border-0 rounded-b-md ${
													ruleGroupId === group_id &&
													isOpen
														? 'visible'
														: 'hidden'
												}` }
											>
												<div className="wcf-order-bumps-rules--group_rules--wrapper flex flex-col gap-4">
													{ rules.length !== 0 && (
														<OBRuleRepeater
															rules={ rules }
															group_id={
																group_id
															}
															g_index={ g_index }
															groups_length={
																conditions.length
															}
														/>
													) }
												</div>
												<div className="wcf-order-bumps-rules--add-rule__repeater flex mt-4">
													<Button
														variant="link"
														size="sm"
														icon={
															<PlusIcon className="w-4 h-4 stroke-2" />
														}
														iconPosition="left"
														className="wcf-order-bumps-rules--add-rule__button hover:!no-underline"
														onClick={ () =>
															addNewRule(
																group_id
															)
														}
													>
														{ __(
															'Add Condition',
															'cartflows-pro'
														) }
													</Button>
												</div>
											</div>
										</div>
										<div className="wcf-order-bumps-rules-page--group_wrapper__footer">
											<div className="wcf-order-bumps-rules--or_group relative my-4">
												<div
													className="absolute inset-0 flex items-center"
													aria-hidden="true"
												>
													<div className="w-full border-t border-border-subtle border-dashed" />
												</div>
												<div className="relative flex justify-center">
													<Badge
														variant="neutral"
														type="rounded"
														size="xs"
														label={ __(
															'OR',
															'cartflows-pro'
														) }
														className="wcf-order-bumps-rules--or_group__text"
													/>
												</div>
											</div>

											{ parseInt( g_index ) + 1 ===
												conditions.length && (
												<div className="wcf-order-bumps-rules--or_group__button mt-4">
													<Button
														variant="outline"
														size="md"
														icon={
															<PlusIcon className="w-4 h-4 stroke-2" />
														}
														iconPosition="left"
														className="wcf-order-bumps-rules--or_group_button !bg-brand-25 !text-brand-600 !outline-brand-300 hover:!bg-brand-50 hover:!outline-brand-300"
														onClick={ addNewGroup }
													>
														{ __(
															'Add Conditions Group',
															'cartflows-pro'
														) }
													</Button>
												</div>
											) }
										</div>
									</div>
								);
							} ) }
						</ReactSortable>
					</div>
				) }
		</div>
	);
}

export default OrderBumpRules;
