import { useEffect, useState } from '@wordpress/element';
import { useStateValue } from '@Utils/StateProvider';
import { __, _n, sprintf } from '@wordpress/i18n';
import OrderBumpProductSkeleton from './skeletons/OrderBumpProductSkeleton';
import './OrderBumpProduct.scss';
import { conditions } from './Helper';
import apiFetch from '@wordpress/api-fetch';
import parse from 'html-react-parser';
import {
	Button,
	Tabs,
	Alert,
	Tooltip,
	Badge,
	Text,
	Input,
	Select,
	toast,
} from '@bsf/force-ui';
import {
	Sparkles,
	Check,
	X,
	Info,
	Lock,
	Minus,
	Plus,
	Percent,
	Ban,
	DollarSign,
	Ticket,
} from 'lucide-react';
import { useAi } from '@ProComponents/ai/useAi';

import {
	NumberField,
	SelectFieldWithIcon,
	ProductField,
	RenderFields,
	CouponField,
} from '@Fields';

// Format a raw amount the way the WooCommerce store does (symbol position, separators,
// decimals) using the localized price-format parts; falls back to a plain symbol prefix.
const formatMoney = ( amount ) => {
	const fmt = cartflows_admin.woo_currency_format || {};
	const symbol = fmt.symbol ?? cartflows_admin.woo_currency ?? '';
	const decimals = Number.isInteger( fmt.decimals ) ? fmt.decimals : 2;
	const decimalSep = fmt.decimal_sep ?? '.';
	const thousandSep = fmt.thousand_sep ?? '';

	const num = ( parseFloat( amount ) || 0 ).toFixed( decimals );
	const parts = num.split( '.' );
	if ( thousandSep ) {
		parts[ 0 ] = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, thousandSep );
	}
	const value = parts.join( decimalSep );

	switch ( fmt.position ) {
		case 'right':
			return value + symbol;
		case 'left_space':
			return symbol + ' ' + value;
		case 'right_space':
			return value + ' ' + symbol;
		default:
			return symbol + value;
	}
};

function OrderBumpProduct() {
	const [ { page_settings, current_ob, step_id }, dispatch ] =
		useStateValue();
	const [ obProduct, setObProduct ] = useState(
		current_ob?.product?.[ 0 ] ? current_ob.product[ 0 ] : ''
	);

	const [ showDeletedProductMessage, setShowDeletedProductMessage ] =
		useState( false );

	const [ isAdding, setIsAdding ] = useState( false );

	const { ensureConnected } = useAi();

	// Mode comes from current_ob so it survives tab remounts; the toggle dispatches it.
	const mode = current_ob?.product_mode ? current_ob.product_mode : 'manual';
	const [ suggestion, setSuggestion ] = useState( null );
	const [ isSuggesting, setIsSuggesting ] = useState( false );

	const aiPool = Array.isArray( current_ob?.ai_product_pool )
		? current_ob.ai_product_pool
		: [];

	// Pool size the backend needs before AI Auto has a real choice; matches get_ai_pool_health.
	const poolMinimum = Number( current_ob?.ai_pool_health?.minimum ) || 3;

	const modeOptions = [
		{ slug: 'manual', text: __( 'Manual', 'cartflows-pro' ) },
		{
			slug: 'auto',
			text: __( 'AI Auto', 'cartflows-pro' ),
			tooltip: __(
				'AI automatically shows each visitor the most relevant product from your pool, based on what is in their cart at checkout.',
				'cartflows-pro'
			),
		},
	];

	const handleAiSuggest = () => {
		if ( ! ensureConnected() || isSuggesting ) {
			return;
		}

		setIsSuggesting( true );
		setSuggestion( null );

		// Pass the selected product too so a suggestion never repeats it.
		const exclude = obProduct?.value ? Number( obProduct.value ) : '';

		apiFetch( {
			path: `/cartflows-pro/v1/admin/ob-ai-suggest/${ step_id }?exclude=${ exclude }`,
		} )
			.then( ( res ) => {
				if ( res?.success && res.product ) {
					setSuggestion( res );
					return;
				}
				toast.error(
					res?.message ||
						__( 'No suitable product was found.', 'cartflows-pro' )
				);
			} )
			.catch( ( err ) => {
				toast.error(
					err?.message ||
						__( 'Could not fetch a suggestion.', 'cartflows-pro' )
				);
			} )
			.finally( () => setIsSuggesting( false ) );
	};

	const acceptSuggestion = () => {
		// Guard the payload — an empty product array would store product: undefined and crash on the next mount.
		if ( suggestion?.product?.product?.[ 0 ]?.value ) {
			dispatch( { type: 'ADD_OB_PRODUCT', product: suggestion.product } );
			window.wcfUnsavedChanges = true;
			toast.success(
				__( 'Product added to the order bump.', 'cartflows-pro' )
			);
		}
		setSuggestion( null );
	};

	// Relevance badge for a suggestion: green match % when scored, else a gray fallback label.
	let suggestionBadge = null;
	if ( suggestion?.match_percent > 0 ) {
		suggestionBadge = {
			variant: 'green',
			label: sprintf(
				/* translators: %s: relevance match as a percentage, e.g. "85%". */
				__( '%s match', 'cartflows-pro' ),
				Math.round( suggestion.match_percent ) + '%'
			),
		};
	} else if ( [ 'popular', 'category' ].includes( suggestion?.basis ) ) {
		suggestionBadge = {
			variant: 'neutral',
			label: __( 'Popular in your store', 'cartflows-pro' ),
		};
	} else if ( 'recent' === suggestion?.basis ) {
		suggestionBadge = {
			variant: 'neutral',
			label: __( 'New', 'cartflows-pro' ),
		};
	}

	const productSettings =
		page_settings?.settings[ 'multiple-order-bump-product' ];

	const discount_types = [
		{
			value: '',
			label: __( 'No Discount', 'cartflows-pro' ),
			icon: <Ban className="w-5 h-5" />,
		},
		{
			value: 'discount_percent',
			label: __( 'Percentage off', 'cartflows-pro' ),
			icon: <Percent className="w-5 h-5" />,
		},
		{
			value: 'discount_price',
			label: __( 'Price off', 'cartflows-pro' ),
			icon: <DollarSign className="w-5 h-5" />,
		},
		{
			value: 'coupon',
			label: __( 'Coupon', 'cartflows-pro' ),
			icon: <Ticket className="w-5 h-5" />,
		},
	];

	const calculateDiscountvalue = function () {
		const discount_type = current_ob.discount_type,
			discount_value = parseFloat( current_ob.discount_value ),
			original_price = parseFloat( obProduct.original_price );

		let custom_price = 0;

		if ( 'discount_percent' === discount_type ) {
			if ( discount_value > 0 ) {
				custom_price =
					original_price - ( original_price * discount_value ) / 100;
			}
		} else if ( 'discount_price' === discount_type ) {
			if ( discount_value > 0 ) {
				custom_price = original_price - discount_value;
			}
		}

		obProduct.sell_price = custom_price.toFixed( 2 );
	};
	if ( '' !== obProduct ) {
		calculateDiscountvalue();
	}

	const setObOption = function ( name, value ) {
		dispatch( { type: 'SET_OB_OPTION', name, value } );
		window.wcfUnsavedChanges = true;
	};

	const isPercentDiscount = 'discount_percent' === current_ob.discount_type;

	// A sale price shows only for a configured percent/price discount landing in [0, base):
	// allows a valid 100%-off (sell_price 0) while excluding coupon / no-discount leftover values.
	const hasManualDiscount =
		'' !== obProduct &&
		( 'discount_percent' === current_ob.discount_type ||
			'discount_price' === current_ob.discount_type ) &&
		parseFloat( current_ob.discount_value ) > 0 &&
		parseFloat( obProduct.sell_price ) >= 0 &&
		parseFloat( obProduct.sell_price ) <
			parseFloat( obProduct.original_price );

	// Mirror the manual card's price display for each pool row: the discount base (raw,
	// default-variation price from the server) struck through with the computed sale price
	// when a percent/price discount is configured.
	const getRowPriceDisplay = function ( product ) {
		const base = parseFloat( product.original_price ) || 0;
		const value = parseFloat( product.discount_value );
		const isValueDiscount =
			'discount_percent' === product.discount_type ||
			'discount_price' === product.discount_type;

		let sale = 0;
		if ( isValueDiscount && value > 0 ) {
			sale =
				'discount_percent' === product.discount_type
					? base - ( base * value ) / 100
					: base - value;
		}

		// Show a sale only for a configured percent/price discount landing in [0, base): allows a
		// valid 100%-off (sale 0) while excluding coupon / no-discount rows with a leftover value.
		const hasDiscount =
			isValueDiscount && value > 0 && sale >= 0 && sale < base;
		return {
			original: formatMoney( base ),
			sale: hasDiscount ? formatMoney( sale ) : '',
			hasDiscount,
			isCoupon: 'coupon' === product.discount_type,
		};
	};

	const removeProduct = function () {
		dispatch( {
			type: 'REMOVE_OB_PRODUCT',
			product: '',
		} );
		window.wcfUnsavedChanges = true;
		setObProduct( '' );
	};

	// Select a product straight from the search results (one-step add).
	const handleSelectProduct = function ( product ) {
		const product_id = product?.value;

		if (
			isAdding ||
			'active' !== cartflows_admin.woocommerce_status ||
			! product_id
		) {
			return;
		}

		setIsAdding( true );
		apiFetch( {
			path: `/cartflows-pro/v1/admin/ob-product-data/${ product_id }`,
		} )
			.then( ( data ) => {
				if ( ! data?.product?.[ 0 ]?.value ) {
					toast.error(
						__(
							'That product could not be added.',
							'cartflows-pro'
						)
					);
					return;
				}
				dispatch( { type: 'ADD_OB_PRODUCT', product: data } );
				window.wcfUnsavedChanges = true;
			} )
			.catch( ( err ) => {
				toast.error(
					err?.message ||
						__(
							'Could not add the product. Please try again.',
							'cartflows-pro'
						)
				);
			} )
			.finally( () => setIsAdding( false ) );
	};

	const setPool = function ( pool ) {
		dispatch( {
			type: 'SET_OB_OPTION',
			name: 'ai_product_pool',
			value: pool,
		} );
		window.wcfUnsavedChanges = true;
	};

	const handleAddToPool = function ( product ) {
		if ( ! product?.value ) {
			return;
		}
		const id = Number( product.value );
		if ( aiPool.some( ( p ) => Number( p.value ) === id ) ) {
			toast.error(
				sprintf(
					/* translators: %s: product name. */
					__( '%s is already in the pool.', 'cartflows-pro' ),
					product.label
				)
			);
			return;
		}
		setPool( [
			...aiPool,
			{
				value: product.value,
				label: product.label,
				product_image: product.product_image,
				original_price: product.original_price,
				quantity: 1,
				discount_type: '',
				discount_value: '',
				discount_coupon: [],
			},
		] );
	};

	const handleRemoveFromPool = function ( id ) {
		setPool( aiPool.filter( ( p ) => Number( p.value ) !== id ) );
	};

	useEffect( () => {
		const product = current_ob?.product?.[ 0 ];

		// Update product state directly — if undefined, this will set it to ''
		setObProduct( product || '' );

		if ( ! product || product?.is_deleted ) {
			setShowDeletedProductMessage( true );
		} else {
			setShowDeletedProductMessage( false );
		}
	}, [ current_ob ] );

	if ( null === page_settings || 'undefined' === page_settings ) {
		return <OrderBumpProductSkeleton />;
	}

	const sectionLabel = ( label ) => (
		<Text
			as="div"
			size={ 12 }
			weight={ 600 }
			color="tertiary"
			className="uppercase tracking-wide"
		>
			{ label }
		</Text>
	);

	return (
		<div className="wcf-order-bump-product-tab space-y-5">
			<input type="hidden" name="product_mode" value={ mode } />

			<div className="wcf-ob-mode-selector flex items-center justify-between">
				<Tabs.Group
					activeItem={ mode }
					size="sm"
					variant="rounded"
					width="auto"
					iconPosition="right"
					onChange={ ( { value } ) => {
						dispatch( {
							type: 'SET_OB_OPTION',
							name: 'product_mode',
							value: value.slug,
						} );
						window.wcfUnsavedChanges = true;
						setSuggestion( null );
					} }
				>
					{ modeOptions.map( ( option ) => (
						<Tabs.Tab
							key={ option.slug }
							slug={ option.slug }
							text={ option.text }
							type="button"
							icon={
								option.tooltip ? (
									<Tooltip
										content={ option.tooltip }
										placement="top"
										arrow
									>
										<span className="inline-flex">
											<Info className="size-3.5 cursor-help" />
										</span>
									</Tooltip>
								) : null
							}
						/>
					) ) }
				</Tabs.Group>

				{ 'auto' === mode && (
					<Badge
						size="sm"
						type="pill"
						variant={
							aiPool.length < poolMinimum ? 'red' : 'neutral'
						}
						label={ sprintf(
							/* translators: %d: number of products in the AI pool. */
							_n(
								'Pool: %d product',
								'Pool: %d products',
								aiPool.length,
								'cartflows-pro'
							),
							aiPool.length
						) }
					/>
				) }
			</div>

			{ /* Kept mounted (hidden in Manual) so pool inputs stay in the save FormData. */ }
			<div
				className={ `wcf-ob-ai-pool space-y-5${
					'auto' === mode ? '' : ' hidden'
				}` }
			>
				{ sectionLabel( __( 'Product pool', 'cartflows-pro' ) ) }

				{ /* TODO: No Force UI equivalent — pool table with embedded @Fields inputs (ported verbatim from cartflows PR #2471). */ }
				<div className="wcf-ob-pool flex flex-col gap-1 border border-solid border-border-subtle rounded-lg p-2">
					{ 0 === aiPool.length ? (
						<>
							<input
								type="hidden"
								name="ai_product_pool[]"
								value=""
							/>
							<div className="text-center text-sm font-normal text-text-secondary py-6">
								{ __(
									'No products in the pool yet. Search below to add the first one.',
									'cartflows-pro'
								) }
							</div>
						</>
					) : (
						<>
							<div className="wcf-ob-pool-header flex items-center gap-3 px-2 pb-1 text-xs font-medium text-text-tertiary uppercase tracking-wide">
								<span className="flex-1 min-w-0">
									{ __( 'Product', 'cartflows-pro' ) }
								</span>
								<span className="w-20 shrink-0">
									{ __( 'Quantity', 'cartflows-pro' ) }
								</span>
								<span className="w-72 shrink-0">
									{ __( 'Discount', 'cartflows-pro' ) }
								</span>
								<span className="w-6 shrink-0" />
							</div>
							{ aiPool.map( ( product, index ) => {
								const rowDiscountType =
									product.discount_type || '';
								const rowPrice = getRowPriceDisplay( product );
								return (
									<div
										key={ product.value }
										className="wcf-ob-pool-row flex items-start gap-3 p-2 rounded-md hover:bg-background-secondary"
									>
										<input
											type="hidden"
											name={ `ai_product_pool[${ index }][id]` }
											value={ product.value }
										/>
										<div className="flex items-center gap-3 flex-1 min-w-0">
											<img
												src={
													product.product_image
														? product.product_image
														: cartflows_admin.image_placeholder
												}
												alt={ product.label }
												className="w-9 h-9 rounded-md object-contain shrink-0 border border-solid border-border-subtle"
											/>
											<div className="min-w-0">
												<div className="text-sm font-medium text-text-primary truncate">
													{ parse(
														String( product.label )
													) }
												</div>
												<div className="text-xs font-normal text-text-tertiary flex items-center gap-1.5">
													<Text
														as="span"
														size={ 12 }
														weight={ 400 }
														color="tertiary"
													>{ `#${ product.value }` }</Text>
													<Text
														as="span"
														size={ 12 }
														weight={ 400 }
														color="tertiary"
														aria-hidden="true"
													>
														·
													</Text>
													<Text
														as="span"
														size={ 12 }
														weight={ 400 }
														color="tertiary"
														className={
															rowPrice.hasDiscount
																? 'line-through'
																: ''
														}
													>
														{ rowPrice.original }
													</Text>
													{ rowPrice.hasDiscount && (
														<Text
															as="span"
															size={ 12 }
															weight={ 500 }
															color="primary"
														>
															{ rowPrice.sale }
														</Text>
													) }
												</div>
												{ rowPrice.isCoupon && (
													<Text
														as="span"
														size={ 12 }
														color="secondary"
														className="block mt-0.5"
													>
														{ __(
															'Coupon will apply on checkout page',
															'cartflows-pro'
														) }
													</Text>
												) }
											</div>
										</div>

										<div className="wcf-ob-pool-row__qty w-20 shrink-0">
											<NumberField
												id=""
												name={ `ai_product_pool[${ index }][quantity]` }
												class="input-field !w-full !m-0"
												value={ product.quantity ?? 1 }
												min="1"
											/>
										</div>

										<div className="wcf-ob-pool-row__discount w-72 shrink-0 flex items-start gap-2">
											<SelectFieldWithIcon
												name={ `ai_product_pool[${ index }][discount_type]` }
												value={ rowDiscountType }
												class="!m-0"
												options={ discount_types }
											/>

											{ 'coupon' !== rowDiscountType ? (
												<NumberField
													id=""
													class="input-field !w-16 !m-0"
													name={ `ai_product_pool[${ index }][discount_value]` }
													value={
														'' === rowDiscountType
															? ''
															: product.discount_value
													}
													readonly={
														'' === rowDiscountType
															? 'readonly'
															: ''
													}
													placeholder={
														'' === rowDiscountType
															? ''
															: '0'
													}
													min={ '1' }
													step={ 'any' }
												/>
											) : (
												<CouponField
													wrapperClass="w-48"
													fieldClass="!border-l-0 !rounded-r-md !rounded-l-none"
													name={ `ai_product_pool[${ index }][discount_coupon]` }
													placeholder={ __(
														'Search for a coupon',
														'cartflows-pro'
													) }
													multiple={ false }
													allow_clear={ true }
													value={
														product.discount_coupon
													}
												/>
											) }
										</div>

										<Button
											type="button"
											variant="ghost"
											size="xs"
											icon={ <X className="size-4" /> }
											onClick={ () =>
												handleRemoveFromPool(
													Number( product.value )
												)
											}
											aria-label={ __(
												'Remove from pool',
												'cartflows-pro'
											) }
										/>
									</div>
								);
							} ) }
						</>
					) }
				</div>

				<ProductField
					key={ `pool-search-${ aiPool.length }` }
					name=""
					desc=""
					field="pool-search"
					value=""
					allowed_products=""
					include_products="braintree-subscription, braintree-variable-subscription"
					excluded_products="grouped"
					excluded_product_ids={ aiPool.map( ( p ) =>
						Number( p.value )
					) }
					placeholder={ __(
						'Search products to add to the pool',
						'cartflows-pro'
					) }
					onChangeCB={ handleAddToPool }
					sectionClass="w-full"
				/>

				<Alert
					variant="info"
					design="inline"
					className="shadow-none"
					title={ __( 'How this works', 'cartflows-pro' ) }
					content={ sprintf(
						/* translators: %d: minimum number of products for the AI pool. */
						_n(
							'At runtime, AI picks the most relevant product from this pool for each visitor. Add at least %d product to give it a real choice.',
							'At runtime, AI picks the most relevant product from this pool for each visitor. Add at least %d products to give it a real choice.',
							poolMinimum,
							'cartflows-pro'
						),
						poolMinimum
					) }
				/>
			</div>

			{ /* Kept mounted (hidden in AI Auto) so its inputs stay in the save FormData. */ }
			<div
				className={ `wcf-ob-manual space-y-4${
					'auto' === mode ? ' hidden' : ''
				}` }
			>
				{ sectionLabel( __( 'Selected product', 'cartflows-pro' ) ) }

				{ '' === obProduct ? (
					<>
						<input type="hidden" name={ `product` } />
						{ /* TODO: No Force UI equivalent — dashed empty-state placeholder (ported verbatim from cartflows PR #2471). */ }
						<div className="flex flex-col items-center gap-2 border border-dashed border-border-subtle rounded-lg p-6 text-center text-sm font-normal text-text-secondary">
							<Lock className="size-6 text-text-tertiary" />
							{ __(
								'No product selected yet. Search below, or let AI pick one for you.',
								'cartflows-pro'
							) }
						</div>
					</>
				) : (
					<>
						{ showDeletedProductMessage && (
							<div className="border border-brand-500 bg-brand-25 text-center text-brand-500 text-xs font-normal rounded-md p-5 mb-5">
								{ __(
									'The product previously added as an Order Bump has been deleted. Please add a new product.',
									'cartflows-pro'
								) }
							</div>
						) }
						{ /* TODO: No Force UI equivalent — selected-product media card. */ }
						<div className="wcf-ob-product-selection--selected-product border border-solid border-border-subtle rounded-xl p-5">
							<input
								type="hidden"
								name={ `product` }
								value={ obProduct.value ? obProduct.value : '' }
							/>
							<input
								type="hidden"
								name={ `discount_type` }
								value={ current_ob.discount_type || '' }
							/>
							<div className="flex items-start gap-4">
								<img
									src={
										obProduct.product_image
											? obProduct.product_image
											: cartflows_admin.image_placeholder
									}
									alt={ obProduct.label }
									className="wcf-ob-product-image size-[60px] rounded-lg object-contain shrink-0 border border-solid border-border-subtle bg-background-secondary p-1"
								/>
								<div className="flex-1 min-w-0">
									<div className="flex items-start justify-between gap-3">
										<div className="wcf-ob-product-selection--product-title min-w-0">
											<div
												className="wcf-ob-product-repeater-field__title text-base font-semibold text-text-primary truncate"
												data-product_id={
													obProduct.value
												}
											>
												{ parse(
													String( obProduct?.label )
												) }
											</div>
											<div className="wcf-ob-product-repeater-field__reg-price flex items-center gap-1.5 mt-1">
												<Text
													as="span"
													size={ 14 }
													weight={ 400 }
													color="secondary"
													className={ `wcf-ob-product--reg-price ${
														hasManualDiscount
															? 'line-through'
															: ''
													}` }
												>
													{ formatMoney(
														obProduct.original_price
													) }
												</Text>
												{ hasManualDiscount && (
													<Text
														as="span"
														size={ 14 }
														weight={ 500 }
														color="primary"
														className="wcf-ob-product--sale-price"
													>
														{ formatMoney(
															obProduct.sell_price
														) }
													</Text>
												) }
											</div>
											{ current_ob.discount_type ===
												'coupon' && (
												<Text
													as="span"
													size={ 12 }
													color="secondary"
													className="coupon-message block mt-0.5"
												>
													{ __(
														'Coupon will apply on checkout page',
														'cartflows-pro'
													) }
												</Text>
											) }
										</div>
										<Button
											type="button"
											variant="outline"
											size="sm"
											destructive
											onClick={ removeProduct }
											className="wcf-delete-product-item shrink-0"
										>
											{ __( 'Remove', 'cartflows-pro' ) }
										</Button>
									</div>

									<div className="flex flex-wrap items-start gap-8 mt-6">
										<div className="wcf-ob-product-selection--product-qty flex flex-col gap-2">
											{ sectionLabel(
												__(
													'Quantity',
													'cartflows-pro'
												)
											) }
											{ /* TODO: No Force UI equivalent — segmented quantity stepper. */ }
											<div className="flex items-stretch w-fit h-8 box-border border border-solid border-border-subtle rounded-lg overflow-hidden [&>button]:h-full">
												<Button
													type="button"
													variant="ghost"
													size="sm"
													icon={
														<Minus className="size-4" />
													}
													onClick={ () =>
														setObOption(
															'quantity',
															Math.max(
																1,
																( parseInt(
																	current_ob.quantity
																) || 1 ) - 1
															)
														)
													}
													disabled={
														'no' ===
															current_ob.display_quantity_field ||
														( parseInt(
															current_ob.quantity
														) || 1 ) <= 1
													}
													className="rounded-none bg-background-secondary"
													aria-label={ __(
														'Decrease quantity',
														'cartflows-pro'
													) }
												/>
												<input
													type="number"
													name={ `quantity` }
													value={
														current_ob.quantity
													}
													min="1"
													readOnly={
														'no' ===
														current_ob.display_quantity_field
													}
													onChange={ ( e ) =>
														setObOption(
															'quantity',
															e.target.value
														)
													}
													onBlur={ ( e ) =>
														setObOption(
															'quantity',
															Math.max(
																1,
																parseInt(
																	e.target
																		.value
																) || 1
															)
														)
													}
													className="w-14 m-0 p-0 text-center text-sm font-medium text-text-primary bg-background-primary border-0 border-x border-solid border-border-subtle focus:ring-0 outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
												/>
												<Button
													type="button"
													variant="ghost"
													size="sm"
													icon={
														<Plus className="size-4" />
													}
													onClick={ () =>
														setObOption(
															'quantity',
															( parseInt(
																current_ob.quantity
															) || 1 ) + 1
														)
													}
													disabled={
														'no' ===
														current_ob.display_quantity_field
													}
													className="rounded-none bg-background-secondary"
													aria-label={ __(
														'Increase quantity',
														'cartflows-pro'
													) }
												/>
											</div>
										</div>

										<div className="wcf-ob-product-selection--product-discount flex flex-col gap-2">
											{ sectionLabel(
												__(
													'Discount type',
													'cartflows-pro'
												)
											) }
											<div className="flex items-stretch">
												<div className="w-44">
													<Select
														size="sm"
														value={
															current_ob.discount_type ||
															'original'
														}
														onChange={ ( value ) =>
															setObOption(
																'discount_type',
																'original' ===
																	value
																	? ''
																	: value
															)
														}
													>
														<Select.Button
															className={ `bg-background-secondary relative hover:z-10 focus:z-10${
																current_ob.discount_type
																	? ' rounded-r-none'
																	: ''
															}` }
															render={ () => {
																const selectedType =
																	discount_types.find(
																		( t ) =>
																			t.value ===
																			( current_ob.discount_type ||
																				'' )
																	);
																return (
																	<span className="flex items-center gap-1.5 [&>svg]:size-4">
																		{
																			selectedType?.icon
																		}
																		{
																			selectedType?.label
																		}
																	</span>
																);
															} }
														/>
														<Select.Options className="z-999999">
															{ discount_types.map(
																( type ) => (
																	<Select.Option
																		key={
																			type.value ||
																			'original'
																		}
																		value={
																			type.value ||
																			'original'
																		}
																	>
																		<span className="flex items-center gap-1.5 [&>svg]:size-4">
																			{
																				type.icon
																			}
																			{
																				type.label
																			}
																		</span>
																	</Select.Option>
																)
															) }
														</Select.Options>
													</Select>
												</div>

												{ '' ===
													current_ob.discount_type && (
													<input
														type="hidden"
														name={ `discount_value` }
														value=""
													/>
												) }
												{ [
													'discount_percent',
													'discount_price',
												].includes(
													current_ob.discount_type
												) && (
													<Input
														type="number"
														size="sm"
														name={ `discount_value` }
														value={
															current_ob.discount_value
														}
														onChange={ ( value ) =>
															setObOption(
																'discount_value',
																isPercentDiscount &&
																	Number(
																		value
																	) > 100
																	? 100
																	: value
															)
														}
														placeholder="0"
														min={ 1 }
														max={
															isPercentDiscount
																? 100
																: undefined
														}
														step="any"
														suffix={
															<span className="text-sm text-text-tertiary">
																{ current_ob.discount_type ===
																'discount_percent'
																	? '%'
																	: cartflows_admin.woo_currency }
															</span>
														}
														className="w-28 -ml-px [&>input]:rounded-l-none"
													/>
												) }
												{ 'coupon' ===
													current_ob.discount_type && (
													<CouponField
														wrapperClass="w-48"
														fieldClass="!border-l-0 !rounded-r-md !rounded-l-none !h-8 box-border"
														size="sm"
														name={
															'discount_coupon'
														}
														placeholder={ __(
															'Search for a coupon',
															'cartflows-pro'
														) }
														multiple={ false }
														allow_clear={ true }
														value={
															current_ob.discount_coupon
														}
													/>
												) }
											</div>
										</div>
									</div>

									{ [
										'discount_percent',
										'discount_price',
									].includes( current_ob.discount_type ) && (
										<Alert
											variant="warning"
											design="inline"
											className="shadow-none mt-5"
											content={ __(
												'This discount is applied only on the checkout page. The price shown elsewhere stays the original.',
												'cartflows-pro'
											) }
										/>
									) }
								</div>
							</div>
						</div>
					</>
				) }

				<div className="flex justify-center">
					<Button
						type="button"
						variant="outline"
						size="sm"
						icon={ <Sparkles className="size-4" /> }
						iconPosition="left"
						onClick={ handleAiSuggest }
						disabled={ isSuggesting }
						loading={ isSuggesting }
						className="text-text-secondary wcf-ob-ai-suggest-button"
					>
						{ isSuggesting
							? __( 'Finding the best product…', 'cartflows-pro' )
							: __(
									'Let AI Suggest a Product',
									'cartflows-pro'
							  ) }
					</Button>
				</div>

				{ suggestion && (
					/* TODO: No Force UI equivalent — suggestion media card with actions (ported verbatim from cartflows PR #2471). */
					<div className="wcf-ob-ai-suggestion flex items-start gap-3 border border-solid border-border-subtle rounded-lg p-3">
						<img
							src={
								suggestion.product?.product_image
									? suggestion.product.product_image
									: cartflows_admin.image_placeholder
							}
							alt={
								suggestion.product?.product?.[ 0 ]?.label || ''
							}
							className="w-10 h-10 rounded-md object-contain shrink-0 border border-solid border-border-subtle"
						/>
						<div className="min-w-0 flex-1 space-y-1">
							<div className="flex items-center gap-2 flex-wrap">
								<span className="text-sm font-medium text-text-primary truncate">
									{ parse(
										String(
											suggestion.product?.product?.[ 0 ]
												?.label || ''
										)
									) }
								</span>
								{ suggestionBadge && (
									<Badge
										size="xs"
										type="pill"
										variant={ suggestionBadge.variant }
										label={ suggestionBadge.label }
									/>
								) }
							</div>
							{ suggestion.product?.product?.[ 0 ]?.value && (
								<div className="flex items-center gap-1.5 text-xs font-normal text-text-tertiary">
									<Text
										as="span"
										size={ 12 }
										weight={ 400 }
										color="tertiary"
									>{ `#${ suggestion.product.product[ 0 ].value }` }</Text>
									<Text
										as="span"
										size={ 12 }
										weight={ 400 }
										color="tertiary"
									>
										·
									</Text>
									<Text
										as="span"
										size={ 12 }
										weight={ 400 }
										color="tertiary"
									>
										{ formatMoney(
											suggestion.product.product[ 0 ]
												.original_price
										) }
									</Text>
								</div>
							) }
							{ suggestion.reason && (
								<p className="text-xs font-normal text-text-secondary m-0">
									{ suggestion.reason }
								</p>
							) }
						</div>
						<div className="flex items-center gap-2 shrink-0">
							<Button
								type="button"
								variant="primary"
								size="sm"
								icon={ <Check className="size-4" /> }
								iconPosition="left"
								onClick={ acceptSuggestion }
							>
								{ __( 'Accept', 'cartflows-pro' ) }
							</Button>
							<Button
								type="button"
								variant="outline"
								size="sm"
								icon={ <X className="size-4" /> }
								iconPosition="left"
								onClick={ () => setSuggestion( null ) }
							>
								{ __( 'Ignore', 'cartflows-pro' ) }
							</Button>
						</div>
					</div>
				) }

				{ /* TODO: No Force UI equivalent — labeled divider (ported verbatim from cartflows PR #2471). */ }
				<div className="flex items-center gap-2.5 !my-6 text-text-tertiary text-xs font-semibold uppercase tracking-wide">
					<span className="flex-1 h-px bg-border-subtle" />
					{ __( 'Or search manually', 'cartflows-pro' ) }
					<span className="flex-1 h-px bg-border-subtle" />
				</div>

				<ProductField
					key={ `ob-search-${ obProduct?.value || 'none' }` }
					name=""
					desc=""
					field="product-search"
					value=""
					allowed_products=""
					include_products="braintree-subscription, braintree-variable-subscription"
					excluded_products="grouped"
					placeholder={ __( 'Search products…', 'cartflows-pro' ) }
					onChangeCB={ handleSelectProduct }
					sectionClass="wcf-ob-product-selection-field__add-new w-full"
				/>
			</div>

			{ productSettings &&
				productSettings.fields &&
				Object.keys( productSettings.fields ).length > 0 && (
					<div className="wcf-ob-global-settings space-y-1 pt-2">
						{ sectionLabel(
							__( 'Display Options', 'cartflows-pro' )
						) }
						<div className="flex">
							<table className="w-full">
								<tbody>
									{ Object.keys( productSettings.fields ).map(
										( field ) => {
											const data =
													productSettings.fields[
														field
													],
												name = data.name,
												value = current_ob[ name ];

											const isActive =
												conditions.isActiveControl(
													data,
													current_ob
												);

											return (
												<RenderFields
													key={ field }
													data={ data }
													value={ value }
													isActive={ isActive }
													field={ field }
												/>
											);
										}
									) }
								</tbody>
							</table>
						</div>
					</div>
				) }
		</div>
	);
}

export default OrderBumpProduct;
