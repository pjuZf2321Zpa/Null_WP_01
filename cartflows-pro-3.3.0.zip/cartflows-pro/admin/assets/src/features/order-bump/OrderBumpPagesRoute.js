import { useState, useEffect } from '@wordpress/element';
import { useStateValue } from '@Utils/StateProvider';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import OrderBumpProductSkeleton from './skeletons/OrderBumpProductSkeleton';
import OrderBumpTwoColumnSkeleton from './skeletons/OrderBumpTwoColumnSkeleton';
import OrderBumpSettingSkeleton from './skeletons/OrderBumpSettingSkeleton';
import OrderBumpRulesSkeleton from './skeletons/OrderBumpRulesSkeleton';
import OrderBumpDesign from './OrderBumpDesign';
import OrderBumpProduct from './OrderBumpProduct';
import OrderBumpContent from './OrderBumpContent';
import OrderBumpRules from './OrderBumpRules';
import ObInputEvents from './ObInputEvents';
import { Container, Tabs } from '@bsf/force-ui';
import OrderBumpPreview from './OrderBumpPreview.js';
import {
	SlidersHorizontal,
	LayoutGrid,
	Paintbrush,
	AlignLeft,
} from 'lucide-react';
import useConfirm from '@Alert/ConfirmDialog';
import { useOrderBumpSave } from './hooks/useOrderBump';

function OrderBumpPagesRoute( props ) {
	const [ { step_id, options, current_ob }, dispatch ] = useStateValue();
	const [ currentTab, setCurrentTab ] = useState( 'product' );
	const query = new URLSearchParams( window.location.search );
	const ob_id = props.ob_id;

	const tab = query.get( 'obtab' );
	const confirm = useConfirm();
	const { saveOrderBump } = useOrderBumpSave();
	ObInputEvents();

	const tabs = [
		{
			name: __( 'Product', 'cartflows-pro' ),
			slug: 'product',
			icon: <LayoutGrid className={ `w-18 h-18 stroke-2` } />,
		},
		{
			name: __( 'Content', 'cartflows-pro' ),
			slug: 'content',
			icon: <AlignLeft className={ `w-18 h-18 stroke-2` } />,
		},
		{
			name: __( 'Styles', 'cartflows-pro' ),
			slug: 'styles',
			icon: <Paintbrush className={ `w-18 h-18 stroke-2` } />,
		},
		{
			name: __( 'Conditions', 'cartflows-pro' ),
			slug: 'conditions',
			icon: <SlidersHorizontal className={ `w-18 h-18 stroke-2` } />,
		},
	];

	const getCurrentOBData = function () {
		const formData = new window.FormData();

		formData.append( 'action', 'cartflows_pro_get_current_order_bump' );
		formData.append(
			'security',
			cartflows_admin.get_current_order_bump_nonce
		);
		formData.append( 'ob_id', ob_id );
		formData.append( 'step_id', step_id );
		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( response ) => {
			if ( response.data.success ) {
				dispatch( {
					type: 'SET_CURRENT_OB',
					current_ob: response.data.current_ob,
					ob_id,
				} );
			}
		} );
	};

	const getStepData = function () {
		apiFetch( {
			path: `/cartflows/v1/admin/step-data/${ step_id }`,
		} ).then( ( data ) => {
			if ( data.billing_fields ) {
				const billing_fields = Object.entries(
					data.billing_fields.fields
				).map( ( [ key, value ] ) => ( {
					...value,
					key,
				} ) );

				data.billing_fields = billing_fields;
			}
			if ( data.shipping_fields ) {
				const shipping_fields = Object.entries(
					data.shipping_fields.fields
				).map( ( [ key, value ] ) => ( {
					...value,
					key,
				} ) );

				data.shipping_fields = shipping_fields;
			}

			// Add the data into the data layer
			dispatch( {
				type: 'SET_STEP_DATA',
				data,
			} );
		} );
	};

	useEffect( () => {
		const getData = async () => {
			getCurrentOBData();
			if ( null === options || 'undefined' === options ) {
				getStepData();
			}
		};

		getData();

		return () => {};
	}, [] );

	// Show the skeleton while the new bump's data is in-flight too — without this, switching from
	// one open panel to another renders empty until the AJAX completes, which looks unresponsive.
	const isLoadingThisBump =
		null === current_ob ||
		'undefined' === current_ob ||
		( current_ob && ob_id !== current_ob.id );
	if ( isLoadingThisBump ) {
		let skeleton = '';

		switch ( tab ) {
			case 'design':
				skeleton = <OrderBumpTwoColumnSkeleton />;
				break;
			case 'product':
				skeleton = <OrderBumpProductSkeleton />;
				break;
			case 'settings':
				skeleton = <OrderBumpSettingSkeleton />;
				break;
			case 'content':
				skeleton = <OrderBumpTwoColumnSkeleton />;
				break;
			case 'conditions':
				skeleton = <OrderBumpRulesSkeleton />;
				break;
			default:
				skeleton = <OrderBumpProductSkeleton />;
				break;
		}

		return (
			<>
				<Container
					containerType="flex"
					direction="column"
					className="wcf-page-wrapper wcf-order-bump-page-wrapper"
				>
					{ skeleton }
				</Container>
			</>
		);
	}

	const get_route_page = function () {
		let route_page = <h1>404 Not Found</h1>;

		switch ( currentTab ) {
			case 'styles':
				route_page = <OrderBumpDesign />;
				break;
			case 'product':
				route_page = <OrderBumpProduct />;
				break;
			case 'content':
				route_page = <OrderBumpContent />;
				break;
			case 'conditions':
				route_page = <OrderBumpRules />;
				break;
			default:
				route_page = <OrderBumpProduct />;
				break;
		}

		return <>{ route_page }</>;
	};

	const confirmUnsavedChanges = async function () {
		if ( window.wcfUnsavedChanges ) {
			const isconfirm = await confirm( {
				title: __( 'Save Changes', 'cartflows-pro' ),
				description: __(
					'You have made changes. Do you want to save the changes?',
					'cartflows-pro'
				),
				actionBtnText: __( 'Save', 'cartflows-pro' ),
				cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
				onConfirm: saveOrderBump,
			} );

			return isconfirm;
		}

		return false; // No changes found.So don't save anything.
	};

	const changeTab = async function ( tabSlug ) {
		if ( tabSlug === currentTab ) {
			setCurrentTab( tabSlug );
			return;
		}
		const isSave = await confirmUnsavedChanges();
		if ( ! isSave ) {
			setCurrentTab( tabSlug );
		}
		window.wcfUnsavedChanges = false;
	};

	return (
		<Container
			containerType="flex"
			direction="column"
			gap="md"
			className="wcf-order-bump-page-wrapper p-6 rounded-b-lg"
		>
			{ /* TODO: No Force UI equivalent — legend + dotted canvas preview frame (design 1f) */ }
			<div className="wcf-order-bump-content-tab__preview relative mt-2 rounded-lg border border-solid border-border-subtle p-8 bg-[#FBFBFC] bg-[radial-gradient(#DFE2E7_1px,transparent_1px)] [background-size:16px_16px]">
				<span className="absolute -top-[9px] left-4 rounded-full bg-background-primary px-2.5 text-xs font-semibold uppercase tracking-wider text-text-tertiary">
					{ __( 'Preview', 'cartflows-pro' ) }
				</span>
				<div className="[&_.wcf-bump-order-wrap]:!m-0">
					<OrderBumpPreview />
				</div>
			</div>
			<Tabs.Group
				variant="underline"
				size="sm"
				width="full"
				activeItem={ currentTab }
				onChange={ ( { value } ) => changeTab( value.slug ) }
				className="wcf-order-bump--tabs-wrapper"
			>
				{ tabs.map( ( ob_tab ) => (
					<Tabs.Tab
						key={ ob_tab.slug }
						slug={ ob_tab.slug }
						text={ ob_tab.name }
						icon={ ob_tab.icon }
						className="!py-2.5"
					/>
				) ) }
			</Tabs.Group>
			{ get_route_page() }
		</Container>
	);
}

export default OrderBumpPagesRoute;
