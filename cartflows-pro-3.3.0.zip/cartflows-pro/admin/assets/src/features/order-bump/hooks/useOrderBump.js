import { useCallback } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { useStateValue } from '@Utils/StateProvider';

/**
 * Save the open order bump's settings from the step-settings form DOM.
 *
 * @param {Object}   ctx           Save context.
 * @param {number}   ctx.flowId    Flow ID.
 * @param {number}   ctx.stepId    Step ID.
 * @param {Object}   ctx.currentOb Currently open order bump (null saves nothing).
 * @param {Function} ctx.dispatch  Store dispatch used to refresh the bump.
 * @param {Function} ctx.onStatus  Receives PROCESSING / SAVED / RESET.
 * @return {Promise<boolean>} Whether the save succeeded.
 */
export function saveOrderBumpSettings( {
	flowId,
	stepId,
	currentOb,
	dispatch,
	onStatus = () => {},
} ) {
	onStatus( 'PROCESSING' );

	const obForm = document.querySelector(
		'.wcf-slide-out-panel--form, .wcf-step-settings-view'
	);

	if ( ! obForm ) {
		onStatus( 'RESET' );
		return Promise.resolve( false );
	}

	if ( ! currentOb ) {
		onStatus( 'SAVED' );
		return Promise.resolve( true );
	}

	// Sync TinyMCE content back to its textarea before reading the form.
	if ( typeof tinymce !== 'undefined' ) {
		const editor = tinymce.get( 'wcf-order-bump-desc-editor' );
		if ( editor ) {
			editor.save();
		}
	}

	const formData = new window.FormData( obForm );
	const ob_id = currentOb.id;

	formData.append( 'action', 'cartflows_pro_save_order_bump_settings' );
	formData.append(
		'security',
		cartflows_admin.save_order_bump_settings_nonce
	);
	formData.append( 'post_id', flowId );
	formData.append( 'step_id', stepId );
	formData.append( 'ob_id', ob_id );

	return apiFetch( {
		url: cartflows_admin.ajax_url,
		method: 'POST',
		body: formData,
	} )
		.then( ( response ) => {
			if ( ! response.data?.success ) {
				onStatus( 'RESET' );
				return false;
			}

			const fetchFormData = new window.FormData();
			fetchFormData.append(
				'action',
				'cartflows_pro_get_current_order_bump'
			);
			fetchFormData.append(
				'security',
				cartflows_admin.get_current_order_bump_nonce
			);
			fetchFormData.append( 'ob_id', ob_id );
			fetchFormData.append( 'step_id', stepId );

			return apiFetch( {
				url: cartflows_admin.ajax_url,
				method: 'POST',
				body: fetchFormData,
			} ).then( ( fetchResponse ) => {
				if (
					fetchResponse.data?.success &&
					fetchResponse.data?.current_ob
				) {
					dispatch( {
						type: 'SET_CURRENT_OB',
						current_ob: fetchResponse.data.current_ob,
						ob_id,
					} );
				}

				onStatus( 'SAVED' );
				window.wcfUnsavedChanges = false;
				return true;
			} );
		} )
		.catch( ( error ) => {
			console.error( error );
			onStatus( 'RESET' );
			return false;
		} );
}

/**
 * Hook flavour for components living inside the order-bump store island.
 *
 * @return {Object} { saveOrderBump }
 */
export const useOrderBumpSave = () => {
	const [ { flow_id, step_id, current_ob }, dispatch ] = useStateValue();

	const saveOrderBump = useCallback(
		() =>
			saveOrderBumpSettings( {
				flowId: flow_id,
				stepId: step_id,
				currentOb: current_ob,
				dispatch,
			} ),
		[ flow_id, step_id, current_ob, dispatch ]
	);

	return { saveOrderBump };
};
