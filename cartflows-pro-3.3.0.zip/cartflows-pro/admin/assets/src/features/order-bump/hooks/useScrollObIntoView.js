import { useEffect } from '@wordpress/element';

const SETTLE_MS = 200;
const MAX_RETRIES = 3;

/**
 * Scrolls a bump row to the top once its settings panel opens.
 * Re-scrolls after scrolling settles so trackpad inertia or late panel content can't leave it off-target.
 *
 * @param {boolean} isOpen Whether this row's settings panel is open.
 * @param {string}  obId   Order bump id (matches the row's data-ob-id).
 */
export function useScrollObIntoView( isOpen, obId ) {
	useEffect( () => {
		if ( ! isOpen ) {
			return;
		}
		let retries = 0;
		let settleTimer;
		const getRow = () =>
			document.querySelector( `[data-ob-id="${ obId }"]` );
		const isAligned = ( row ) => {
			const marginTop =
				parseFloat( window.getComputedStyle( row ).scrollMarginTop ) ||
				0;
			return Math.abs( row.getBoundingClientRect().top - marginTop ) < 4;
		};
		const stop = () => {
			clearTimeout( settleTimer );
			window.removeEventListener( 'scroll', onScroll );
		};
		const scroll = () => {
			const row = getRow();
			if ( ! row ) {
				return stop();
			}
			row.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			settleTimer = setTimeout( onSettled, SETTLE_MS );
		};
		const onSettled = () => {
			const row = getRow();
			if ( ! row || isAligned( row ) || retries >= MAX_RETRIES ) {
				return stop();
			}
			retries++;
			scroll();
		};
		// Any scroll (ours or user inertia) resets the settle timer; we re-check once it goes quiet.
		const onScroll = () => {
			clearTimeout( settleTimer );
			settleTimer = setTimeout( onSettled, SETTLE_MS );
		};
		window.addEventListener( 'scroll', onScroll, { passive: true } );
		const startTimer = setTimeout( scroll, 300 );
		return () => {
			clearTimeout( startTimer );
			stop();
		};
	}, [ isOpen, obId ] );
}
