// One named export per locked AJAX action — every method is a thin apiFetch+FormData wrapper.
import { useCallback } from '@wordpress/element';
// apiFetch is the same network primitive used throughout the OB admin code.
import apiFetch from '@wordpress/api-fetch';

// Helper that builds a FormData with the standard step + nonce pair used by every OB action.
const buildFormData = ( action, nonceKey, extra = {} ) => {
	// Construct the FormData browser native — mirrors the existing OB pattern.
	const formData = new window.FormData();
	// Standard action key consumed by WordPress wp_ajax_* handlers.
	formData.append( 'action', action );
	// Nonce is read off the localised cartflows_admin global at the configured key.
	formData.append( 'security', cartflows_admin[ nonceKey ] );
	// Append everything else verbatim — caller decides field names.
	Object.entries( extra ).forEach( ( [ key, value ] ) => {
		formData.append( key, value );
	} );
	// Return the prepared body to the caller.
	return formData;
};

// Helper that runs the AJAX POST against the localised ajax_url.
const post = ( body ) =>
	apiFetch( {
		url: cartflows_admin.ajax_url,
		method: 'POST',
		body,
	} );

/**
 * useOrderBumpAb — exposes 10 named methods, one per locked A/B AJAX action.
 *
 * Each method returns the raw apiFetch promise so callers can await it
 * and read `result.success` / `result.data.order_bumps`.
 *
 * @return {Object} Map of API methods.
 */
export const useOrderBumpAb = () => {
	// create_order_bump_variation — starts an A/B test on a plain bump.
	const createVariation = useCallback(
		( { stepId, ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_create_order_bump_variation',
					'create_order_bump_variation_nonce',
					{ step_id: stepId, ob_id }
				)
			),
		[]
	);

	// clone_order_bump_variation — adds another variant under an existing control.
	const cloneVariation = useCallback(
		( { stepId, control_ob_id, source_ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_clone_order_bump_variation',
					'clone_order_bump_variation_nonce',
					{ step_id: stepId, control_ob_id, source_ob_id }
				)
			),
		[]
	);

	// start_order_bump_ab_test — flips ab-test-start=true on the control entry.
	const startAbTest = useCallback(
		( { stepId, control_ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_start_order_bump_ab_test',
					'start_order_bump_ab_test_nonce',
					{ step_id: stepId, control_ob_id }
				)
			),
		[]
	);

	// pause_order_bump_ab_test — flips ab-test-start=false.
	const pauseAbTest = useCallback(
		( { stepId, control_ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_pause_order_bump_ab_test',
					'pause_order_bump_ab_test_nonce',
					{ step_id: stepId, control_ob_id }
				)
			),
		[]
	);

	// save_order_bump_ab_traffic — writes the rebalanced traffic % per variant.
	const saveTraffic = useCallback(
		( { stepId, control_ob_id, variations } ) =>
			post(
				buildFormData(
					'cartflows_pro_save_order_bump_ab_traffic',
					'save_order_bump_ab_traffic_nonce',
					{
						step_id: stepId,
						control_ob_id,
						variations: JSON.stringify( variations ),
					}
				)
			),
		[]
	);

	// archive_order_bump_variation — moves a variant into ab-test-archived-variations.
	const archiveVariation = useCallback(
		( { stepId, control_ob_id, ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_archive_order_bump_variation',
					'archive_order_bump_variation_nonce',
					{ step_id: stepId, control_ob_id, ob_id }
				)
			),
		[]
	);

	// delete_order_bump_variation — removes a variant entry; promotes next if control was deleted.
	const deleteVariation = useCallback(
		( { stepId, control_ob_id, ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_delete_order_bump_variation',
					'delete_order_bump_variation_nonce',
					{ step_id: stepId, control_ob_id, ob_id }
				)
			),
		[]
	);

	// declare_order_bump_ab_winner — promotes winner + archives losers + ends the test.
	const declareWinner = useCallback(
		( { stepId, control_ob_id, winner_ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_declare_order_bump_ab_winner',
					'declare_order_bump_ab_winner_nonce',
					{ step_id: stepId, control_ob_id, winner_ob_id }
				)
			),
		[]
	);

	// restore_archive_order_bump_variation — pulls an archived entry back into the active list.
	const restoreArchived = useCallback(
		( { stepId, control_ob_id, ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_restore_archive_order_bump_variation',
					'restore_archive_order_bump_variation_nonce',
					{ step_id: stepId, control_ob_id, ob_id }
				)
			),
		[]
	);

	// delete_archive_order_bump_variation — hard-removes from the archived list.
	const deleteArchived = useCallback(
		( { stepId, control_ob_id, ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_delete_archive_order_bump_variation',
					'delete_archive_order_bump_variation_nonce',
					{ step_id: stepId, control_ob_id, ob_id }
				)
			),
		[]
	);

	// Reuses of existing OB actions — kept here so the A/B group never reaches into other hooks.
	const toggleBumpStatus = useCallback(
		( { stepId, flowId, ob_id, currentStatus } ) =>
			post(
				buildFormData(
					'cartflows_pro_update_order_bump_status',
					'update_order_bump_status_nonce',
					{
						step_id: stepId,
						post_id: flowId,
						ob_id,
						ob_status: ! currentStatus,
					}
				)
			),
		[]
	);

	// Reuse of existing OB clone action — keeps the inline icon working inside A/B context too.
	const cloneBump = useCallback(
		( { stepId, ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_clone_order_bump',
					'clone_order_bump_nonce',
					{ step_id: stepId, ob_id }
				)
			),
		[]
	);

	// Reuse of existing OB delete action — same reason as cloneBump above.
	const deleteBump = useCallback(
		( { stepId, flowId, ob_id } ) =>
			post(
				buildFormData(
					'cartflows_pro_delete_order_bump',
					'delete_order_bump_nonce',
					{ step_id: stepId, post_id: flowId, ob_id }
				)
			),
		[]
	);

	// Return the full method set — every method returns the apiFetch promise unchanged.
	return {
		createVariation,
		cloneVariation,
		startAbTest,
		pauseAbTest,
		saveTraffic,
		archiveVariation,
		deleteVariation,
		declareWinner,
		restoreArchived,
		deleteArchived,
		toggleBumpStatus,
		cloneBump,
		deleteBump,
	};
};
