// Single source of truth for every A/B toast message — keeps strings out of the JSX.
import { useMemo } from '@wordpress/element';
// i18n is required — every string passes through __ so translations work.
import { __ } from '@wordpress/i18n';

/**
 * useOrderBumpAbToasts — returns memoised toast-string builders.
 *
 * Each method is a pure function that returns the translated string.
 * Components call e.g. `toast.success( toasts.variationAdded() )`.
 *
 * @return {Object} Map of string builders.
 */
export const useOrderBumpAbToasts = () => {
	// useMemo ensures we don't recreate the object on every render.
	return useMemo(
		() => ( {
			// Fired after Start Split Test succeeds.
			splitStarted: () => __( 'Split test started!', 'cartflows-pro' ),
			// Fired after Stop Split Test succeeds.
			splitStopped: () => __( 'Split test stopped!', 'cartflows-pro' ),
			// Fired after the first variant is created via the "A/B Split Test" menu item.
			variationAdded: () =>
				__( 'A/B test variation created!', 'cartflows-pro' ),
			// Fired after a clone-variation completes successfully.
			variationCloned: () => __( 'Variation cloned!', 'cartflows-pro' ),
			// Fired after Archive Variation succeeds.
			variationArchived: () =>
				__( 'Variation archived!', 'cartflows-pro' ),
			// Fired after Delete Variation succeeds.
			variationDeleted: () => __( 'Variation deleted!', 'cartflows-pro' ),
			// Fired after Declare Winner succeeds.
			winnerDeclared: () =>
				__( 'Winner declared successfully!', 'cartflows-pro' ),
			// Fired after Save Settings in the traffic split modal succeeds.
			trafficSaved: () =>
				__( 'Split test traffic saved!', 'cartflows-pro' ),
			// Fired after Restore in the archived list succeeds.
			archiveRestored: () =>
				__( 'Archived variation restored!', 'cartflows-pro' ),
			// Fired after Delete in the archived list succeeds.
			archiveDeleted: () =>
				__(
					'Archived variation deleted permanently!',
					'cartflows-pro'
				),
			// Reused for the inline status toggle inside an A/B context.
			statusUpdated: ( isEnabled ) =>
				isEnabled
					? __( 'Order bump enabled!', 'cartflows-pro' )
					: __( 'Order bump disabled!', 'cartflows-pro' ),
			// Reused for the inline duplicate icon.
			bumpCloned: () => __( 'Order bump cloned!', 'cartflows-pro' ),
			// Reused for the inline delete icon.
			bumpDeleted: () => __( 'Order bump deleted!', 'cartflows-pro' ),
		} ),
		[]
	);
};
