// Pure traffic-balance hook — keeps the sum of all values at exactly 100.
import { useState, useCallback, useMemo } from '@wordpress/element';

// Helper that clamps any input value into the 0..100 range and returns an integer.
const clamp = ( value ) => {
	const num = parseInt( value, 10 );
	if ( Number.isNaN( num ) ) {
		return 0;
	}
	return Math.max( 0, Math.min( 100, num ) );
};

// Helper that converts the initial variations array into a {id: traffic} map.
const variationsToValues = ( variations ) => {
	const map = {};
	( variations || [] ).forEach( ( v ) => {
		map[ v.id ] = clamp( v.traffic );
	} );
	return map;
};

/**
 * useOrderBumpAbTraffic — keeps the per-id traffic map in local state.
 * Implementation mirrors Step A/B's AbSettingSliders.js auto-balancer:
 * when one value changes, the delta is distributed across the remaining ids
 * so the total always lands at 100.
 *
 * @param {Array<{id: string, traffic: number}>} initialVariations
 * @return {Object} Hook public surface.
 */
export const useOrderBumpAbTraffic = ( initialVariations ) => {
	// Internal state — the working map of {id: traffic}.
	const [ values, setValues ] = useState( () =>
		variationsToValues( initialVariations )
	);

	// reset is exposed so the dialog can re-seed values when it reopens.
	const reset = useCallback( ( nextVariations ) => {
		setValues( variationsToValues( nextVariations ) );
	}, [] );

	// handleChange runs when an input fires onChange — id is the bump id being edited.
	const handleChange = useCallback( ( changedId, rawValue ) => {
		// Normalise the user input to an integer in 0..100.
		const next = clamp( rawValue );
		setValues( ( prev ) => {
			const otherIds = Object.keys( prev ).filter(
				( k ) => k !== changedId
			);
			if ( 0 === otherIds.length ) {
				return { ...prev, [ changedId ]: next };
			}
			// Scale the other inputs proportionally to what they held before so their
			// relative spread is preserved. Fall back to an even split only when the
			// others were all zero (avoids division by zero).
			const remaining = 100 - next;
			const oldOthersTotal = otherIds.reduce(
				( s, id ) => s + ( prev[ id ] ?? 0 ),
				0
			);
			const scaled = otherIds.map( ( id ) =>
				oldOthersTotal > 0
					? Math.floor(
							( ( prev[ id ] ?? 0 ) * remaining ) / oldOthersTotal
					  )
					: Math.floor( remaining / otherIds.length )
			);
			// Give the rounding leftover one unit at a time to the first ids in order.
			const leftover = remaining - scaled.reduce( ( s, v ) => s + v, 0 );
			const updated = { ...prev, [ changedId ]: next };
			otherIds.forEach( ( id, i ) => {
				updated[ id ] = scaled[ i ] + ( i < leftover ? 1 : 0 );
			} );
			return updated;
		} );
	}, [] );

	// total is exposed so the dialog can show "Current total: N%" + disable Save until 100.
	const total = useMemo(
		() =>
			Object.values( values ).reduce( ( sum, n ) => sum + ( n || 0 ), 0 ),
		[ values ]
	);

	// Return the hook surface — values + handlers consumed by TrafficSplitDialog.
	return {
		values,
		handleChange,
		reset,
		total,
	};
};
