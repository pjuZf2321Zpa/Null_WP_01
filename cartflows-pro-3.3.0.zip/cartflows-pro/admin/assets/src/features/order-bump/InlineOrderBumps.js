import { useState, useEffect, useCallback } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { Dialog, Button, Input, toast } from '@bsf/force-ui';
import { Plus, Info } from 'lucide-react';
import MultiOrderBump from './MultiOrderBump';

/**
 * InlineOrderBumps — mounts the MultiOrderBump list UI inline on the
 * funnel steps page. Owns local bumps state seeded from props and replays
 * the same dispatch action shapes the step-settings reducer handles.
 *
 * @param {Object}   props
 * @param {number}   props.stepId           - Checkout step post ID.
 * @param {number}   props.flowId           - Flow/funnel post ID.
 * @param {Array}    props.initialBumps     - Bumps array from flow-data API.
 * @param {Function} [props.onCountChange]  - Notifies parent when count changes.
 * @param {Function} [props.onEditNavigate] - Opens a bump's editor (free routes it).
 */
function InlineOrderBumps( {
	stepId,
	flowId,
	initialBumps,
	onCountChange,
	onEditNavigate,
} ) {
	const [ bumps, setBumps ] = useState(
		Array.isArray( initialBumps ) ? initialBumps : []
	);
	const [ isAddOpen, setIsAddOpen ] = useState( false );
	const [ newTitle, setNewTitle ] = useState( '' );
	const [ addError, setAddError ] = useState( '' );
	const [ isAdding, setIsAdding ] = useState( false );

	useEffect( () => {
		if ( Array.isArray( initialBumps ) ) {
			setBumps( initialBumps );
		}
	}, [ initialBumps ] );

	useEffect( () => {
		onCountChange?.( bumps.length );
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [ bumps.length ] );

	const dispatch = useCallback( ( action ) => {
		if ( ! action || 'object' !== typeof action ) {
			return;
		}
		switch ( action.type ) {
			case 'UPDATE_ORDER_BUMP':
				if ( Array.isArray( action.order_bumps ) ) {
					setBumps( action.order_bumps );
				}
				break;
			case 'SET_OB':
				if ( Array.isArray( action.obs ) ) {
					setBumps( action.obs );
				}
				break;
			case 'SET_OB_STATUS':
				setBumps( ( prev ) =>
					prev.map( ( ob ) =>
						ob.id === action.ob_id
							? { ...ob, status: action.newStatus }
							: ob
					)
				);
				break;
			case 'SET_OB_TITLE':
				setBumps( ( prev ) =>
					prev.map( ( ob ) =>
						ob.id === action.ob_id
							? { ...ob, title: action.title }
							: ob
					)
				);
				break;
			case 'REMOVE_ORDER_BUMP':
				setBumps( ( prev ) =>
					prev.filter( ( ob ) => ob.id !== action.ob_id )
				);
				break;
			case 'SET_OB_PRODUCT':
				setBumps( ( prev ) =>
					prev.map( ( ob ) =>
						ob.id === action.ob_id
							? { ...ob, product: action.product }
							: ob
					)
				);
				break;
			default:
				break;
		}
	}, [] );

	const handleEditClick = useCallback(
		( ob_id ) => {
			onEditNavigate?.( ob_id );
		},
		[ onEditNavigate ]
	);

	const closeAddDialog = () => {
		if ( isAdding ) {
			return;
		}
		setIsAddOpen( false );
		setNewTitle( '' );
		setAddError( '' );
	};

	const submitAdd = () => {
		const title = ( newTitle || '' ).trim();
		if ( '' === title ) {
			setAddError(
				__( 'Please enter the order bump title', 'cartflows-pro' )
			);
			return;
		}

		setAddError( '' );
		setIsAdding( true );

		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_pro_add_order_bump' );
		formData.append( 'security', cartflows_admin.add_order_bump_nonce );
		const obId =
			window.crypto && 'function' === typeof window.crypto.randomUUID
				? window.crypto.randomUUID()
				: Math.random().toString( 36 ).slice( 2, 12 ) +
				  Math.random().toString( 36 ).slice( 2, 12 );
		formData.append( 'ob_id', obId );
		formData.append( 'post_id', flowId );
		formData.append( 'step_id', stepId );
		formData.append( 'title', title );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} )
			.then( ( response ) => {
				if ( response?.success ) {
					dispatch( {
						type: 'UPDATE_ORDER_BUMP',
						name: 'wcf-order-bumps',
						order_bumps: response.data.order_bumps,
					} );
					toast.success( __( 'Order bump added!', 'cartflows-pro' ) );
					setIsAddOpen( false );
					setNewTitle( '' );
				} else {
					setAddError(
						__( 'Failed to add order bump.', 'cartflows-pro' )
					);
				}
			} )
			.catch( () => {
				setAddError(
					__( 'Failed to add order bump.', 'cartflows-pro' )
				);
			} )
			.finally( () => {
				setIsAdding( false );
			} );
	};

	return (
		<>
			<MultiOrderBump
				orderBumps={ bumps }
				stepId={ stepId }
				flowId={ flowId }
				pageSettings={ null }
				onChange={ dispatch }
				onEditClick={ handleEditClick }
				hideDocLink={ true }
				hideAddControl={ true }
			/>
			<button
				type="button"
				onClick={ () => setIsAddOpen( true ) }
				className="wcf-add-order-bump-trigger w-full mt-2.5 py-2.5 flex items-center justify-center gap-1 border border-solid border-border-subtle rounded-lg bg-transparent text-sm font-medium text-text-secondary hover:text-text-primary hover:border-border-strong cursor-pointer"
			>
				<Plus className="w-4 h-4 stroke-2" />
				{ __( 'Add Order Bump', 'cartflows-pro' ) }
			</button>
			<Dialog
				open={ isAddOpen }
				setOpen={ ( open ) => {
					if ( ! open ) {
						closeAddDialog();
					}
				} }
				exitOnClickOutside={ false }
			>
				<Dialog.Panel className="sm:max-w-lg w-full">
					<Dialog.Backdrop />
					<Dialog.Header className="flex items-center justify-between !space-y-0">
						<Dialog.Title>
							{ __( 'Order Bump', 'cartflows-pro' ) }
						</Dialog.Title>
						<Dialog.CloseButton />
					</Dialog.Header>
					<Dialog.Body>
						<label
							htmlFor="wcf-add-order-bump-title"
							className="block text-sm font-medium text-text-primary mb-2"
						>
							{ __( 'Order Bump Name', 'cartflows-pro' ) }
						</label>
						<Input
							id="wcf-add-order-bump-title"
							type="text"
							size="md"
							value={ newTitle }
							onChange={ ( value ) => {
								setNewTitle( value );
								if ( addError ) {
									setAddError( '' );
								}
							} }
							placeholder={ __(
								'Enter Order Bump name',
								'cartflows-pro'
							) }
							error={ !! addError }
							onKeyDown={ ( e ) => {
								if ( 'Enter' === e.key && ! isAdding ) {
									e.preventDefault();
									submitAdd();
								}
							} }
						/>
						<p className="flex items-center gap-1 text-xs font-normal text-text-tertiary mt-2 m-0">
							<Info className="w-3.5 h-3.5 stroke-2" />
							{ __(
								'Configure product and settings after creation.',
								'cartflows-pro'
							) }
						</p>
						{ addError && (
							<p className="text-sm font-normal text-brand-500 mt-2 m-0">
								{ addError }
							</p>
						) }
					</Dialog.Body>
					<Dialog.Footer className="flex gap-3 justify-end">
						<Button
							variant="outline"
							size="md"
							onClick={ closeAddDialog }
							disabled={ isAdding }
						>
							{ __( 'Cancel', 'cartflows-pro' ) }
						</Button>
						<Button
							variant="primary"
							size="md"
							onClick={ submitAdd }
							loading={ isAdding }
							disabled={ isAdding }
						>
							{ __( 'Add Order Bump', 'cartflows-pro' ) }
						</Button>
					</Dialog.Footer>
				</Dialog.Panel>
			</Dialog>
		</>
	);
}

export default InlineOrderBumps;
