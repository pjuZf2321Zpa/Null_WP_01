// Single bump row used inside an A/B group — visual parity with the existing OB row.
import { useState, useEffect, createRef } from '@wordpress/element';
// i18n needed for all visible strings (tooltips, aria-labels).
import { __ } from '@wordpress/i18n';
// apiFetch for the inline title save — same pattern as OrderBumpRepeater.
import apiFetch from '@wordpress/api-fetch';
// Title validation helper is already used across the codebase for the same purpose.
import { validateTitleField } from '@ProUtils/validate';
// Force UI primitives only — no raw divs/spans in this row's layout.
import {
	Container,
	Button,
	Tooltip,
	Switch,
	Loader,
	Input,
	Badge,
	toast,
} from '@bsf/force-ui';
// Lucide icons match the exact icons used in OrderBumpRepeater so visuals are identical.
import { SquarePen, Trash2, Copy, CircleAlert, PenLine } from 'lucide-react';
// Role-aware kebab menu lives next to the inline action icons in the actions column.
import OrderBumpAbActionMenu from './OrderBumpAbActionMenu';
// Three badge wrappers — one is rendered based on the row's role.
import ControlBadge from './ControlBadge';
import VariantBadge from './VariantBadge';
import WinnerBadge from './WinnerBadge';
// Funnel ribbon (impressions → initiated → conversions + CR pill) rendered under each A/B row.
import FunnelRibbon from '../../components/FunnelRibbon';
import { getStatsForBump, useStatsBlob } from '../../components/funnelStats';
import { useScrollObIntoView } from '../../hooks';

// Single A/B row — supports four roles (plain/control/variant/winner) toggled by the `role` prop.
const OrderBumpAbRow = ( {
	// The bump entry from wcf-order-bumps — contains id, title, product, status, etc.
	bump,
	// Row context drives the badge and the action menu items.
	role = 'plain',
	// 1-based variant index used only when role === 'variant' to label "Variation-N".
	variantNumber = 1,
	// Traffic % stored on ab-test-variations[i].traffic — shown next to the title in A/B context.
	traffic,
	// Step post id — needed for the inline title-save AJAX call.
	stepId,
	// Dispatch from the parent state provider — used to update local Redux on title save.
	dispatch,
	// Click handler for inline duplicate action (the small icon button — also handles "Duplicate" in plain rows).
	onDuplicateClick,
	// Click handler for inline settings/edit action (the cog icon).
	onSettingsClick,
	// Whether this row's inline settings panel is currently open — drives the cog's active highlight.
	isSettingsOpen = false,
	// Click handler for inline delete action (the trash icon — also handles "Delete" in plain rows).
	onDeleteClick,
	// Menu item callback — fires from "A/B Split Test" on a plain row.
	onMenuStartAb,
	// Menu item callback — fires from "Declare as Winner" in control/variant rows.
	onMenuDeclareWinner,
	// Menu item callback — fires from "Archive Variation" in variant rows.
	onMenuArchive,
	// Status toggle handler — flips the bump's `status` field via AJAX.
	onStatusToggle,
	// Per-row processing flags so the inline icons can show their loaders.
	statusProcess,
	actionProcess,
	// Read-only flag — hides the inline icons + the kebab when set.
	readOnly = false,
	// True when this row is the currently-leading variant in its A/B test — drives the green "winner" CR pill.
	isWinner = false,
} ) => {
	// Funnel stats for this row — read once per render from the Redux step state.
	const statsBlob = useStatsBlob();
	const funnelStats = getStatsForBump( bump, statsBlob );
	// Local state for inline title edit toggle — mirrors OrderBumpRepeater's editTitle pattern.
	const [ editTitle, setEditTitle ] = useState( false );
	// Local saving flag drives the "Save" button's loader.
	const [ savingState, setSavingState ] = useState( false );
	// Ref into the title input so the save click can read its value.
	const newTitleInput = createRef();

	useEffect( () => {
		if ( editTitle ) {
			newTitleInput.current?.focus();
		}
	}, [ editTitle ] );

	useScrollObIntoView( isSettingsOpen, bump.id );

	// Pick the badge component based on role so the JSX below stays flat.
	const RoleBadge = ( () => {
		if ( 'control' === role ) {
			return <ControlBadge />;
		}
		if ( 'variant' === role ) {
			return <VariantBadge number={ variantNumber } />;
		}
		if ( 'winner' === role ) {
			return <WinnerBadge />;
		}
		return null;
	} )();

	// Click handler for the pencil icon — switches the title to an editable input.
	const onEditTitleClick = ( e ) => {
		e.preventDefault();
		setEditTitle( true );
	};

	// Click handler for the Cancel button next to the input — reverts back to the text view.
	const onCancelTitle = ( e ) => {
		e.preventDefault();
		setEditTitle( false );
	};

	// Click handler for the Save button — POSTs the new title via the existing rename AJAX.
	const onSaveTitle = () => {
		// Block double-clicks while the save is in-flight.
		if ( savingState ) {
			return;
		}
		// Capture the typed value once — setSavingState below triggers a re-render that detaches
		// the createRef() instance, so any later `newTitleInput.current` read would be null.
		const newTitle = newTitleInput.current?.value || '';
		// Build the FormData using the same shape OrderBumpRepeater uses.
		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_pro_update_order_bump_title' );
		formData.append(
			'security',
			cartflows_admin.update_order_bump_title_nonce
		);
		formData.append( 'step_id', stepId );
		formData.append( 'new_title', newTitle );
		formData.append( 'ob_id', bump.id );
		// Mark saving so the button shows its loader.
		setSavingState( true );
		// Same POST shape used everywhere else in the OB feature.
		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( () => {
			// Update the local store so the new title shows up immediately.
			dispatch?.( {
				type: 'SET_OB_TITLE',
				name: 'wcf-order-bumps',
				title: newTitle,
				ob_id: bump.id,
			} );
			// Clear the in-flight flag and exit edit mode.
			setSavingState( false );
			setEditTitle( false );
			toast.success( __( 'Order bump title updated!', 'cartflows-pro' ) );
		} );
	};

	// Pre-compute the editable title chunk so the JSX below stays scannable.
	const ob_title =
		'' === bump.title ? __( '(no title)', 'cartflows-pro' ) : bump.title;
	// Use the existing helper to truncate over-long titles consistently with other OB UI.
	const display_title = validateTitleField(
		ob_title,
		cartflows_admin.title_length.max,
		cartflows_admin.title_length.display_length
	);

	// Variant rows are indented to mirror the mockup's nested layout.
	// Same column layout as OrderBumpRepeater: flex-1 title / w-28 status / w-36 actions.
	// Hierarchy is conveyed by the A/B group's orange left accent border + the Variation-N badge —
	// no extra outer padding so the row stays inside the panel's column widths (Phase 1.6 fix 3).
	return (
		<div
			className={ `wcf-order-bump wcf-order-bump--ab wcf-order-bump--${ role } scroll-mt-16 pb-5 border-b border-border-subtle border-solid border-0 last:border-0 transition-colors duration-500 ${
				isSettingsOpen ? 'bg-brand-25' : ''
			}` }
			data-ob-id={ bump.id }
		>
			<Container
				containerType="flex"
				align="center"
				className="wcf-order-bump__content-wrapper relative p-6 text-sm gap-2"
			>
				<div className="wcf-order-bump__data wcf-column--product flex-1 min-w-0">
					<div className="wcf-order-bump__data-title flex items-center gap-2 min-h-8">
						<span className="text-sm font-medium text-text-primary flex gap-2 justify-center items-center min-h-8">
							{ ! editTitle && (
								<span className="wcf-ob-header__title--text">
									{ display_title }
								</span>
							) }
							{ editTitle && (
								<Input
									size="sm"
									ref={ newTitleInput }
									defaultValue={ ob_title }
									className="new-step-title focus:!ring-0 focus:!ring-offset-0 !h-8 [&>input]:!h-8 [&>input]:!min-h-8 [&>input]:!py-1"
								/>
							) }
							{ ! editTitle && '' === bump.product && (
								<Badge
									label={ __(
										'No product',
										'cartflows-pro'
									) }
									variant="warning"
									icon={ <CircleAlert className="w-4 h-4" /> }
									size="xs"
								/>
							) }
							<span className="wcf-ob-header__title--buttons flex gap-2">
								{ ! editTitle && ! readOnly && (
									<Tooltip
										content={ __(
											'Edit Order Bump Name',
											'cartflows-pro'
										) }
										placement="bottom"
									>
										<Button
											variant="ghost"
											size="xs"
											icon={
												<PenLine className="w-3 h-3 stroke-1" />
											}
											onClick={ onEditTitleClick }
											className="wcf-ob-header__title--edit"
										/>
									</Tooltip>
								) }
								{ editTitle && (
									<>
										<Button
											variant="primary"
											size="xs"
											loading={ savingState }
											onClick={ onSaveTitle }
										>
											{ __( 'Save', 'cartflows-pro' ) }
										</Button>
										<Button
											variant="secondary"
											size="xs"
											onClick={ onCancelTitle }
										>
											{ __( 'Cancel', 'cartflows-pro' ) }
										</Button>
									</>
								) }
							</span>
							{ ! editTitle && RoleBadge }
							{ ! editTitle && undefined !== traffic && (
								<span className="text-xs text-text-tertiary ml-2">
									{ __( 'Traffic:', 'cartflows-pro' ) }{ ' ' }
									<b className="text-text-primary">
										{ traffic }%
									</b>
								</span>
							) }
						</span>
					</div>
				</div>
				<Container
					containerType="flex"
					gap="xs"
					className="wcf_order_bump__status w-28 shrink-0"
				>
					<Switch
						value={ !! bump.status }
						size="sm"
						label={ {
							heading: bump.status
								? __( 'Active', 'cartflows-pro' )
								: __( 'Inactive', 'cartflows-pro' ),
						} }
						onChange={ () => onStatusToggle?.( bump.id ) }
						disabled={ !! statusProcess || readOnly }
					/>
					{ statusProcess && <Loader size="sm" variant="primary" /> }
				</Container>
				<Container
					containerType="flex"
					justify="end"
					align="center"
					gap="xs"
					className="wcf-order-bump__action wcf-column--actions w-36 shrink-0"
				>
					{ ! readOnly && (
						<>
							<Tooltip
								content={ __(
									'Duplicate Order Bump',
									'cartflows-pro'
								) }
								placement="bottom"
							>
								<Button
									variant="ghost"
									size="xs"
									icon={
										'clone' === actionProcess ? (
											<Loader size="sm" />
										) : (
											<Copy className="w-4 h-4 stroke-1" />
										)
									}
									onClick={ () =>
										onDuplicateClick?.( bump.id )
									}
									className="wcf-clone-bump-button"
								/>
							</Tooltip>
							<Tooltip
								content={ __(
									'Edit Order Bump',
									'cartflows-pro'
								) }
								placement="bottom"
							>
								<Button
									variant="ghost"
									size="xs"
									icon={
										<SquarePen className="w-4 h-4 stroke-1" />
									}
									onClick={ () =>
										onSettingsClick?.( bump.id )
									}
									className={ `wcf-setting-bump-button ${
										isSettingsOpen
											? '!bg-brand-50 !text-brand-500'
											: ''
									}` }
								/>
							</Tooltip>
							<Tooltip
								content={ __(
									'Delete Variation',
									'cartflows-pro'
								) }
								placement="bottom"
							>
								<Button
									variant="ghost"
									size="xs"
									icon={
										'delete' === actionProcess ? (
											<Loader size="sm" />
										) : (
											<Trash2 className="w-4 h-4 stroke-1" />
										)
									}
									onClick={ () => onDeleteClick?.( bump.id ) }
									className="wcf-remove-order-bump-button"
								/>
							</Tooltip>
							<OrderBumpAbActionMenu
								role={ role }
								onStartAb={ onMenuStartAb }
								onDeclareWinner={ onMenuDeclareWinner }
								onArchive={ onMenuArchive }
							/>
						</>
					) }
				</Container>
			</Container>
			{ /* Surface A · Inline funnel ribbon — always under each A/B row (control + variant). */ }
			<FunnelRibbon
				impressions={ funnelStats.impressions }
				initiated={ funnelStats.initiated }
				conversions={ funnelStats.conversions }
				isWinner={ isWinner }
			/>
		</div>
	);
};

// Default export keeps OrderBumpAbGroup's import line short.
export default OrderBumpAbRow;
