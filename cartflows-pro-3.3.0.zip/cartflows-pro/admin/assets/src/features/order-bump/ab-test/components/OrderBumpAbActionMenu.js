// Role-aware A/B actions — direct icon button for a single action, kebab dropdown for several.
// Phase 1.7 fix 2: Duplicate and Delete items removed — those actions already exist as inline icons
// (clone + trash) in the row's action column. This menu holds only A/B-specific actions that have
// no inline equivalent: A/B Split Test (plain), Declare Winner (control/variant), Archive (variant).
// i18n is required because every menu item label must be translatable.
import { __ } from '@wordpress/i18n';
// Force UI primitives — DropdownMenu is the locked menu primitive, Button is the trigger.
import { DropdownMenu, Button, Tooltip } from '@bsf/force-ui';
import { EllipsisVertical, Archive, Trophy } from 'lucide-react';
import AbTestIcon from '../../components/AbTestIcon';

// Role-aware action menu (plain | control | variant).
const OrderBumpAbActionMenu = ( {
	// Row role decides which items appear.
	role = 'plain',
	// Callback fired when admin clicks "A/B Split Test" on a plain row.
	onStartAb,
	// Callback fired when admin clicks Declare as Winner.
	onDeclareWinner,
	// Callback fired when admin clicks Archive Variation.
	onArchive,
} ) => {
	// Build the visible action list once — its length decides direct button vs kebab.
	const items = [];
	if ( 'plain' === role ) {
		items.push( {
			key: 'start',
			label: __( 'Start A/B Test', 'cartflows-pro' ),
			icon: AbTestIcon,
			onClick: onStartAb,
			className: 'wcf-ob-ab-action-menu__start',
		} );
	}
	// Declare Winner is only meaningful while an A/B test is running on this group.
	if ( 'control' === role || 'variant' === role ) {
		items.push( {
			key: 'winner',
			label: __( 'Declare as Winner', 'cartflows-pro' ),
			icon: Trophy,
			onClick: onDeclareWinner,
			className: 'wcf-ob-ab-action-menu__winner',
		} );
	}
	// Archive is variant-only — the control of a running test cannot be archived without ending the test.
	if ( 'variant' === role ) {
		items.push( {
			key: 'archive',
			label: __( 'Archive Variation', 'cartflows-pro' ),
			icon: Archive,
			onClick: onArchive,
			className: 'wcf-ob-ab-action-menu__archive',
		} );
	}

	if ( 0 === items.length ) {
		return null;
	}

	// Single action — render it as a direct icon button, same pattern as the row's inline actions.
	if ( 1 === items.length ) {
		const item = items[ 0 ];
		const Icon = item.icon;
		return (
			<Tooltip content={ item.label } placement="bottom">
				<Button
					variant="ghost"
					size="xs"
					icon={ <Icon className="w-4 h-4 stroke-1" /> }
					onClick={ item.onClick }
					aria-label={ item.label }
					className={ item.className }
				/>
			</Tooltip>
		);
	}

	// Render the dropdown using the exact compound pattern already used by StepActionMenu.js.
	return (
		<DropdownMenu placement="bottom-end" className="wcf-ob-ab-action-menu">
			<DropdownMenu.Trigger>
				<Button
					variant="ghost"
					size="xs"
					icon={
						<EllipsisVertical
							className="w-4 h-4 stroke-1"
							aria-hidden="true"
						/>
					}
					aria-label={ __( 'More Options', 'cartflows-pro' ) }
				/>
			</DropdownMenu.Trigger>
			<DropdownMenu.ContentWrapper className="z-20">
				<DropdownMenu.Content
					size="sm"
					className="wcf-ob-ab-action-menu__dropdown"
				>
					<DropdownMenu.List>
						{ items.map( ( item ) => {
							const Icon = item.icon;
							return (
								<DropdownMenu.Item
									key={ item.key }
									onClick={ item.onClick }
									className={ `${ item.className } hover:!bg-brand-25 hover:!text-brand-600` }
								>
									<Icon className="w-4 h-4" />
									{ item.label }
								</DropdownMenu.Item>
							);
						} ) }
					</DropdownMenu.List>
				</DropdownMenu.Content>
			</DropdownMenu.ContentWrapper>
		</DropdownMenu>
	);
};

// Default export — keeps the import shape consistent across the ab-test/ folder.
export default OrderBumpAbActionMenu;
