// Collapsible "Archived Variations" panel rendered at the bottom of an A/B group.
import { useState } from '@wordpress/element';
// i18n for the header label including the count suffix.
import { __, sprintf } from '@wordpress/i18n';
// Layout primitive for the archived-item list container.
import { Container } from '@bsf/force-ui';
// Chevron icon flips when the accordion toggles.
import { ChevronDown } from 'lucide-react';
// Single-row presenter, kept in its own file for clarity and testability.
import ArchivedVariationItem from './ArchivedVariationItem';

// Renders the archived list shared row. Optionally hosts a `trailing` action node aligned right.
const ArchivedVariations = ( {
	// Array of archived entries — shape per Step archive schema {id, title, note, deleted, raw_date, date}.
	items = [],
	// Restore handler — passed straight through to each row item.
	onRestore,
	// Delete handler — passed straight through to each row item.
	onDelete,
	// Right-aligned action rendered on the shared header row (e.g. "+ Add Variation").
	trailing = null,
} ) => {
	const [ open, setOpen ] = useState( false );
	const count = Array.isArray( items ) ? items.length : 0;
	const hasItems = count > 0;

	// Nothing to render if there are no archived items and no trailing slot to host.
	if ( ! hasItems && ! trailing ) {
		return null;
	}

	return (
		// No border-t — the last A/B row's border-b already draws this divider.
		<div className="wcf-ob-ab-archived">
			<div className="flex items-center justify-between px-6 py-3">
				{ hasItems ? (
					<button
						type="button"
						onClick={ () => setOpen( ( o ) => ! o ) }
						aria-expanded={ open }
						className="wcf-ob-ab-archived__trigger inline-flex items-center gap-1.5 text-xs font-medium text-text-secondary hover:text-text-primary bg-transparent border-0 p-0 cursor-pointer"
					>
						<span>
							{ sprintf(
								/* translators: %d is the number of archived variations. */
								__(
									'Archived Variations (%d)',
									'cartflows-pro'
								),
								count
							) }
						</span>
						<ChevronDown
							className={ `w-4 h-4 transition-transform ${
								open ? 'rotate-180' : ''
							}` }
						/>
					</button>
				) : (
					<span className="wcf-ob-ab-archived__placeholder" />
				) }
				{ trailing }
			</div>
			{ hasItems && open && (
				<div className="wcf-ob-ab-archived__content px-6 pb-3">
					<Container containerType="flex" direction="column" gap="xs">
						{ items.map( ( item ) => (
							<ArchivedVariationItem
								key={ item.id }
								item={ item }
								onRestore={ onRestore }
								onDelete={ onDelete }
							/>
						) ) }
					</Container>
				</div>
			) }
		</div>
	);
};

// Default export keeps consumer imports terse.
export default ArchivedVariations;
