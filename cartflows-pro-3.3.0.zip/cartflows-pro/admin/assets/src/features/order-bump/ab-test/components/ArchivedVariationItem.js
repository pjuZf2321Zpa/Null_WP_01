// Single archived variation row — shown inside ArchivedVariations Accordion.
// i18n for the Restore / Delete labels and the loser tag.
import { __, sprintf } from '@wordpress/i18n';
// Force UI primitives only — no raw markup per project rules.
import { Container, Text, Button, Badge } from '@bsf/force-ui';

// Pre-snapshot archives (before Surface C landed) have no `stats` field — render "—" for the funnel.
const formatStat = ( value ) =>
	'number' === typeof value && value >= 0 ? String( value ) : '—';

// CR % from a snapshot — '—' when impressions = 0 or stats absent (backward-compat with old archives).
const formatCr = ( stats ) => {
	if ( ! stats || ! stats.impressions ) {
		return '—';
	}
	return `${ ( ( stats.conversions / stats.impressions ) * 100 ).toFixed(
		1
	) }%`;
};

// Renders one archived variation entry (loser or deleted).
const ArchivedVariationItem = ( {
	// One archived entry — shape {id, title, note, deleted, raw_date, date} (mirrors Step archive schema).
	item,
	// Click handler — restores this entry back into ab-test-variations.
	onRestore,
	// Click handler — hard-removes this entry from ab-test-archived-variations.
	onDelete,
} ) => {
	// Pull the visible fields out so the JSX stays terse and easy to scan.
	const { id, title, note, deleted, date, stats } = item || {};
	// Surface C · funnel snapshot frozen at archive time; only render when present so old archives stay clean.
	const hasStats = stats && 'object' === typeof stats;
	const statsLine = hasStats
		? sprintf(
				/* translators: 1: impressions, 2: initiated, 3: conversions, 4: conversion rate */
				__(
					'Impressions %1$s · Initiated %2$s · Conversions %3$s · Conversion Rate %4$s',
					'cartflows-pro'
				),
				formatStat( stats.impressions ),
				formatStat( stats.initiated ),
				formatStat( stats.conversions ),
				formatCr( stats )
		  )
		: '';

	// Render a flex row with text on the left and the two action buttons on the right.
	return (
		<Container
			containerType="flex"
			align="center"
			justify="between"
			gap="sm"
			className="wcf-ob-ab-archived-item py-2"
		>
			<Container
				containerType="flex"
				direction="column"
				gap="xs"
				className="min-w-0 flex-1"
			>
				<Container containerType="flex" align="center" gap="xs">
					<Text
						as="span"
						size="sm"
						weight={ 500 }
						className="text-text-primary truncate"
					>
						{ title || __( '(no title)', 'cartflows-pro' ) }
					</Text>
					{ deleted && (
						<Badge
							label={ __( 'Deleted', 'cartflows-pro' ) }
							variant="red"
							type="pill"
							size="xxs"
						/>
					) }
				</Container>
				{ ( note || date ) && (
					<Text as="span" size="xs" className="text-text-tertiary">
						{ note ? `${ note } · ` : '' }
						{ date || '' }
					</Text>
				) }
				{ /* Surface C · funnel snapshot frozen at archive time. */ }
				{ statsLine && (
					<Text
						as="span"
						size="xs"
						className="text-text-secondary wcf-ob-ab-archived-item__stats"
					>
						{ statsLine }
					</Text>
				) }
			</Container>
			<Container containerType="flex" align="center" gap="xs">
				{ /* Restore is only meaningful if the entry was not previously hard-deleted from the test. */ }
				{ ! deleted && (
					<Button
						variant="outline"
						size="xs"
						onClick={ () => onRestore?.( id ) }
						className="wcf-ob-ab-archived-item__restore"
					>
						{ __( 'Restore', 'cartflows-pro' ) }
					</Button>
				) }
				<Button
					variant="outline"
					size="xs"
					onClick={ () => onDelete?.( id ) }
					className="wcf-ob-ab-archived-item__delete"
				>
					{ __( 'Delete', 'cartflows-pro' ) }
				</Button>
			</Container>
		</Container>
	);
};

// Default export — consistent with the rest of the ab-test components.
export default ArchivedVariationItem;
