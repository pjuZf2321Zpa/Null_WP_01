// Tiny wrapper so every "Variation-N" pill is rendered identically.
// sprintf builds the "Variation-%d" label so translators can change the format.
import { __, sprintf } from '@wordpress/i18n';
// Force UI Badge is the locked primitive for inline status pills.
import { Badge } from '@bsf/force-ui';

// Number prop is 1-based — mirrors Step A/B InnerStep.js:339-349 where var_badge_count is the same.
const VariantBadge = ( { number } ) => (
	<Badge
		// translators: %d is the variation index (1-based) shown to the admin.
		label={ sprintf( __( 'Variation-%d', 'cartflows-pro' ), number ) }
		variant="inverse"
		type="pill"
		size="xs"
	/>
);

// Default export keeps call sites terse and consistent with sibling badges.
export default VariantBadge;
