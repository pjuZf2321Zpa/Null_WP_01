// Split-Test header bar that sits above the control + variant rows inside an A/B group.
import { useState } from '@wordpress/element';
// i18n needed for every visible string.
import { __ } from '@wordpress/i18n';
// Force UI primitives — Container is the locked layout primitive (no raw flex divs).
import { Container, Button, Badge, Tooltip, Text } from '@bsf/force-ui';
import { Settings } from 'lucide-react';

// Header bar — left side shows "Split Test" label + status badge, right side has Start/Stop + settings.
const OrderBumpAbHead = ( {
	// Whether the A/B test is currently running — drives the badge + the Start/Stop label.
	abTestStart,
	// Click handler for the Start/Stop link — flips ab-test-start on the control.
	onToggle,
	// Click handler for the settings gear — opens the TrafficSplitDialog.
	onOpenSettings,
} ) => {
	// Local loading state lets us show "Starting…" / "Stopping…" without bubbling state up.
	const [ toggling, setToggling ] = useState( false );

	// Click handler runs the async toggle and clears the loading state afterwards.
	const handleToggle = async () => {
		// Prevent double-clicks while a toggle request is in flight.
		if ( toggling ) {
			return;
		}
		// Set the local flag so the label flips to the "…" variant immediately.
		setToggling( true );
		// Wait for the parent's async work (AJAX) before clearing the flag.
		try {
			await onToggle?.();
		} finally {
			// Always clear the flag — even on error — so the button stays usable.
			setToggling( false );
		}
	};

	// Pre-compute the label so the JSX stays scannable — split into two flat ternaries.
	const togglingLabel = abTestStart
		? __( 'Stopping…', 'cartflows-pro' )
		: __( 'Starting…', 'cartflows-pro' );
	const idleLabel = abTestStart
		? __( 'Stop Split Test', 'cartflows-pro' )
		: __( 'Start Split Test', 'cartflows-pro' );
	const toggleLabel = toggling ? togglingLabel : idleLabel;

	// Render the header. Phase 1.7 fix 1: wrap the Force UI Container in an outer block-level <div>
	// because Force UI Container with containerType="flex" inside a flex-column parent does not respect
	// the parent's width constraints — its computed width overflowed the panel by ~50px. The outer
	// <div> establishes a block-formatting context that constrains the inner flex layout to 100% width.
	return (
		<div className="wcf-ob-ab-head w-full block bg-background-secondary border-0 border-b border-solid border-border-subtle">
			<Container
				containerType="flex"
				align="center"
				justify="between"
				className="px-6 py-2.5"
			>
				<Container containerType="flex" align="center" gap="xs">
					<Text as="span" size="sm" weight={ 500 }>
						{ __( 'Split Test', 'cartflows-pro' ) }
					</Text>
					<Badge
						label={
							abTestStart
								? __( 'RUNNING', 'cartflows-pro' )
								: __( 'PAUSED', 'cartflows-pro' )
						}
						variant={ abTestStart ? 'green' : 'neutral' }
						type="pill"
						size="xs"
					/>
				</Container>
				<Container containerType="flex" align="center" gap="sm">
					<Button
						variant="link"
						size="sm"
						loading={ toggling }
						onClick={ handleToggle }
						disabled={ toggling }
						className={
							abTestStart
								? 'wcf-ob-ab-head__stop !text-brand-500 hover:!text-brand-600'
								: 'wcf-ob-ab-head__start !text-support-success hover:!text-support-success-hover'
						}
					>
						{ toggleLabel }
					</Button>
					<Tooltip
						content={ __( 'Split Test Settings', 'cartflows-pro' ) }
						placement="bottom"
					>
						<Button
							variant="ghost"
							size="xs"
							icon={ <Settings className="w-4 h-4 stroke-1" /> }
							onClick={ onOpenSettings }
							className="wcf-ob-ab-head__settings"
							aria-label={ __(
								'Split Test Settings',
								'cartflows-pro'
							) }
						/>
					</Tooltip>
				</Container>
			</Container>
		</div>
	);
};

// Default export keeps imports terse at the OrderBumpAbGroup call site.
export default OrderBumpAbHead;
