// Tiny wrapper for the "Winner" pill shown on a bump that won an A/B test.
// i18n is required so the "Winner" label can be translated.
import { __ } from '@wordpress/i18n';
// Force UI Badge is the locked primitive for inline status pills.
import { Badge } from '@bsf/force-ui';
// TrophyIcon visually anchors the winner state (mirrors Step A/B "Declare as Winner" trophy icon).
import { TrophyIcon } from '@heroicons/react/24/outline';

// Locked visual: green pill + trophy icon, so winners stand out at a glance in the bump list.
const WinnerBadge = () => (
	<Badge
		label={ __( 'Winner', 'cartflows-pro' ) }
		variant="green"
		type="pill"
		size="xs"
		icon={ <TrophyIcon className="w-3 h-3" /> }
	/>
);

// Default export — same convention as Control/Variant badge siblings.
export default WinnerBadge;
