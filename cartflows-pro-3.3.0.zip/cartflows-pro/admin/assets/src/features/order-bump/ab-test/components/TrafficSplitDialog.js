// Force UI Dialog that hosts the two Input[type=number,suffix=%] traffic editors.
import { useState, useEffect, useMemo } from '@wordpress/element';
// i18n for every visible string.
import { __, sprintf } from '@wordpress/i18n';
// Force UI primitives only — Dialog, Input, Button, Container, Text, toast.
import { Dialog, Input, Button, Container, Text, toast } from '@bsf/force-ui';
// Pure auto-balance hook keeps the math out of the JSX.
import { useOrderBumpAbTraffic } from '../../hooks';
// Same badge wrappers used in the rows so the modal stays visually consistent.
import ControlBadge from './ControlBadge';
import VariantBadge from './VariantBadge';

// Traffic Split Settings dialog — variations array drives the inputs.
const TrafficSplitDialog = ( {
	// Dialog open flag — controlled by the parent (header settings click).
	open,
	// Setter for `open` — same controlled pattern used by other Force UI dialogs.
	setOpen,
	// Variations array — shape [{ id, traffic }] keyed by bump id; index 0 is control.
	variations = [],
	// Lookup of bump titles by id so each row can show its human label next to the input.
	titlesById = {},
	// onSave receives the rebalanced [{id, traffic}] array; parent fires the AJAX.
	onSave,
} ) => {
	// Local processing flag flips the Save button into a loading state.
	const [ saving, setSaving ] = useState( false );

	// Auto-balance hook owns the per-variation traffic values + the change handler.
	const { values, handleChange, total, reset } =
		useOrderBumpAbTraffic( variations );

	// Reset the hook's internal values whenever the dialog reopens with fresh data.
	useEffect( () => {
		if ( open ) {
			reset( variations );
		}
	}, [ open, variations, reset ] );

	// Compute the list rendered inside the modal once per re-render for clarity.
	const rows = useMemo(
		() =>
			variations.map( ( v, idx ) => ( {
				id: v.id,
				traffic: values[ v.id ] ?? v.traffic ?? 0,
				title:
					titlesById[ v.id ] || __( '(no title)', 'cartflows-pro' ),
				role: 0 === idx ? 'control' : 'variant',
				variantNumber: idx,
			} ) ),
		[ variations, values, titlesById ]
	);

	// Helper that closes the dialog without firing any save logic.
	const onCancel = () => {
		setOpen( false );
	};

	// Save handler runs the parent callback and waits for its async result.
	const onSaveClick = async () => {
		// Block double-saves.
		if ( saving ) {
			return;
		}
		// Validate the sum — defensive check; the hook should already keep it at 100.
		if ( 100 !== total ) {
			toast.error( __( 'Traffic must sum to 100%.', 'cartflows-pro' ) );
			return;
		}
		// Flip the loader on.
		setSaving( true );
		// Build the array the parent expects — same shape it passed in but with updated traffic.
		const next = variations.map( ( v ) => ( {
			id: v.id,
			traffic: values[ v.id ] ?? v.traffic ?? 0,
		} ) );
		// Run the parent's async save; close the dialog only if it succeeded.
		try {
			const ok = await onSave?.( next );
			if ( false !== ok ) {
				setOpen( false );
			}
		} finally {
			setSaving( false );
		}
	};

	// Render the Force UI Dialog with the panel + title + body + footer.
	return (
		<Dialog open={ open } setOpen={ setOpen } exitOnClickOutside exitOnEsc>
			<Dialog.Panel className="!p-3 !gap-4">
				<Dialog.Backdrop />
				<div className="flex flex-col gap-3 p-2 min-w-0">
					<div className="flex items-center justify-between">
						<Dialog.Title className="!text-lg">
							{ __( 'Split Test Settings', 'cartflows-pro' ) }
						</Dialog.Title>
						<Dialog.CloseButton />
					</div>
					<Text
						as="span"
						size="xs"
						className="text-text-tertiary uppercase tracking-wide"
					>
						{ __( 'Traffic Distribution', 'cartflows-pro' ) }
					</Text>
					<Container
						containerType="flex"
						direction="column"
						gap="xs"
						className="wcf-ob-ab-traffic-list"
					>
						{ rows.map( ( row ) => (
							<Container
								key={ row.id }
								containerType="flex"
								align="center"
								justify="between"
								gap="sm"
								className="wcf-ob-ab-traffic-row py-2"
							>
								<Container
									containerType="flex"
									align="center"
									gap="xs"
									className="min-w-0"
								>
									<Text
										as="span"
										size="sm"
										weight={ 500 }
										className="text-text-primary truncate"
									>
										{ row.title }
									</Text>
									{ 'control' === row.role && (
										<ControlBadge />
									) }
									{ 'variant' === row.role && (
										<VariantBadge
											number={ row.variantNumber }
										/>
									) }
								</Container>
								<Input
									type="number"
									size="sm"
									min={ 0 }
									max={ 100 }
									value={ String( row.traffic ) }
									suffix="%"
									onChange={ ( val ) =>
										handleChange( row.id, val )
									}
									className="wcf-ob-ab-traffic-input w-[120px]"
								/>
							</Container>
						) ) }
					</Container>
					<Text as="span" size="xs" className="text-text-tertiary">
						{ sprintf(
							// translators: %d is the current total of all traffic % fields.
							__(
								'Current total: %1$d%% (must equal 100%%)',
								'cartflows-pro'
							),
							total
						) }
					</Text>
				</div>
				<Dialog.Footer className="!p-2 flex gap-3 justify-end">
					<Button
						variant="outline"
						size="md"
						onClick={ onCancel }
						disabled={ saving }
					>
						{ __( 'Cancel', 'cartflows-pro' ) }
					</Button>
					<Button
						variant="primary"
						size="md"
						onClick={ onSaveClick }
						loading={ saving }
						disabled={ saving || 100 !== total }
					>
						{ saving
							? __( 'Saving…', 'cartflows-pro' )
							: __( 'Save Settings', 'cartflows-pro' ) }
					</Button>
				</Dialog.Footer>
			</Dialog.Panel>
		</Dialog>
	);
};

// Default export — keeps imports terse where this dialog is mounted.
export default TrafficSplitDialog;
