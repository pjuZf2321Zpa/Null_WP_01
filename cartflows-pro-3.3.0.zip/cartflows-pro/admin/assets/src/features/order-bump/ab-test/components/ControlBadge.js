// Tiny wrapper so the "Control" pill stays visually identical everywhere it appears.
// i18n is required because the locked label "Control" must be translatable.
import { __ } from '@wordpress/i18n';
// Force UI Badge is the only primitive we use — no raw markup per project rules.
import { Badge } from '@bsf/force-ui';

// Locked visual: variant="blue", type="pill", size="xs" (mirrors Step A/B InnerStep.js:328-333).
const ControlBadge = () => (
	<Badge
		label={ __( 'Control', 'cartflows-pro' ) }
		variant="blue"
		type="pill"
		size="xs"
	/>
);

// Default export keeps imports terse at call sites.
export default ControlBadge;
