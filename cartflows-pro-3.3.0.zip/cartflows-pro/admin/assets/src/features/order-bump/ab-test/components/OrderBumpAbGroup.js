// Orchestrator — the "A/B group" slot rendered in place of a single OB row.
import { useState, useMemo } from '@wordpress/element';
// i18n for the small inline messages owned by this component.
import { __ } from '@wordpress/i18n';
// useStateValue is the project's Redux-like store hook — needed as a dispatch fallback (Phase 1.6 fix 2).
import { useStateValue } from '@Utils/StateProvider';
// useConfirm is the same destructive-action confirm pattern used by OrderBumpRepeater.
import useConfirm from '@Alert/ConfirmDialog';
// Force UI toast primitive — group container itself is a raw <div> (Phase 1.7 fix 4).
import { toast } from '@bsf/force-ui';
// Plus icon for the "Add Variation" affordance (see the group's bottom bar).
import { Plus } from 'lucide-react';
// Hooks live in the shared admin-core hooks directory per the locked plan.
import { useOrderBumpAb, useOrderBumpAbToasts } from '../../hooks';
// All sibling presentational components.
import OrderBumpAbHead from './OrderBumpAbHead';
import OrderBumpAbRow from './OrderBumpAbRow';
// Computes current leader (highest CR above the impression threshold) for the winner-pill highlight on the row.
import { pickCurrentLeader, useStatsBlob } from '../../components/funnelStats';
import ArchivedVariations from './ArchivedVariations';
import TrafficSplitDialog from './TrafficSplitDialog';
import DeclareWinnerDialog from './DeclareWinnerDialog';
// OrderBumpPagesRoute is the inline settings page used as a fallback when no onEditClick is provided (Phase 1.6 fix 4).
import OrderBumpPagesRoute from '../../OrderBumpPagesRoute';

// Renders one A/B group inside the bump list — receives the control entry and resolves sibling variants from `allBumps`.
const OrderBumpAbGroup = ( {
	// The control bump entry — ab-test === true and holds the test state.
	controlBump,
	// Full wcf-order-bumps array — used to look up sibling variant entries by id.
	allBumps = [],
	// Step post id needed by every AJAX action.
	stepId,
	// Flow post id passed through for the delete/status calls that need it.
	flowId,
	// Dispatch from the parent state provider — used to update Redux on each AJAX response.
	dispatch,
	// Edit click handler from MultiOrderBump — opens the OB settings page.
	onEditClick,
	// Lifted state from MultiOrderBump — keeps a single open panel across the whole list.
	openObSettingsId = '',
	toggleObSettings,
} ) => {
	// Local UI state — dialog open flags only; data state lives in the parent Redux.
	const [ trafficOpen, setTrafficOpen ] = useState( false );
	const [ winnerOpen, setWinnerOpen ] = useState( false );
	// The variation id awaiting winner confirmation, captured when the menu item is clicked.
	const [ pendingWinnerVid, setPendingWinnerVid ] = useState( null );
	// Per-row processing flags so the inline icons can show their loaders.
	const [ statusBusy, setStatusBusy ] = useState( {} );
	const [ actionBusy, setActionBusy ] = useState( {} );
	// Dispatch fallback — Phase 1.6 fix 2. MultiOrderBump passes dispatch=undefined in non-controlled
	// mode, so without this fallback every dispatchToUse() silently no-ops and Redux never updates.
	const [ , dispatchStore ] = useStateValue();
	// Funnel stats blob (from REST step-data response, folded into Redux options.ob_ab_stats).
	const statsBlob = useStatsBlob();
	const dispatchToUse = dispatch || dispatchStore;

	// AJAX wrapper hook — one method per locked AJAX action.
	const ab = useOrderBumpAb();
	// Localised toast strings — single source of truth.
	const toasts = useOrderBumpAbToasts();
	// Destructive-action confirm dialog wrapper.
	const confirm = useConfirm();

	// Pull active variations from the control bump entry.
	const variations = useMemo(
		() =>
			Array.isArray( controlBump?.[ 'ab-test-variations' ] )
				? controlBump[ 'ab-test-variations' ]
				: [],
		[ controlBump ]
	);
	// Pull archived variations from the control bump entry.
	const archived = useMemo(
		() =>
			Array.isArray( controlBump?.[ 'ab-test-archived-variations' ] )
				? controlBump[ 'ab-test-archived-variations' ]
				: [],
		[ controlBump ]
	);

	// Build a lookup of bump entries by id so we can render rows by walking `variations`.
	const bumpsById = useMemo( () => {
		const map = {};
		( allBumps || [] ).forEach( ( b ) => {
			map[ b.id ] = b;
		} );
		return map;
	}, [ allBumps ] );

	// Build a lookup of titles by id for the traffic dialog labels.
	const titlesById = useMemo( () => {
		const map = {};
		variations.forEach( ( v ) => {
			map[ v.id ] = bumpsById[ v.id ]?.title || '';
		} );
		return map;
	}, [ variations, bumpsById ] );

	// Track whether the test is currently running so the head and rows can react.
	const abTestStart = !! controlBump?.[ 'ab-test-start' ];

	// Helper that toggles a per-id flag in either of the busy maps.
	const setBusy = ( target, id, value ) => {
		const setter = 'status' === target ? setStatusBusy : setActionBusy;
		setter( ( prev ) => ( { ...prev, [ id ]: value } ) );
	};

	// Status toggle — reuses the existing OB status AJAX so the variant is treated as a normal bump.
	const onStatusToggle = ( ob_id ) => {
		setBusy( 'status', ob_id, true );
		ab.toggleBumpStatus( {
			stepId,
			flowId,
			ob_id,
			currentStatus: !! bumpsById[ ob_id ]?.status,
		} )
			.then( ( result ) => {
				if ( result?.success ) {
					dispatchToUse( {
						type: 'SET_OB_STATUS',
						name: 'wcf-order-bumps',
						newStatus: ! bumpsById[ ob_id ]?.status,
						ob_id,
					} );
					toast.success(
						toasts.statusUpdated( ! bumpsById[ ob_id ]?.status )
					);
				}
			} )
			.finally( () => setBusy( 'status', ob_id, false ) );
	};

	// Inline delete icon — Phase 1.7 fix 2: inside an A/B group, the trash button always deletes
	// via the variation-aware AJAX so the control's `ab-test-variations` stays in sync. The plain
	// row outside this group still uses the original cartflows_pro_delete_order_bump path.
	const onInlineDelete = async ( ob_id ) => {
		const ok = await confirm( {
			title: __( 'Delete Variation', 'cartflows-pro' ),
			description: __(
				'Do you really want to delete this variation permanently?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Delete', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );
		if ( ! ok ) {
			return;
		}
		setBusy( 'action', ob_id, 'delete' );
		const result = await ab.deleteVariation( {
			stepId,
			control_ob_id: controlBump.id,
			ob_id,
		} );
		if ( result?.success ) {
			dispatchToUse( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success( toasts.variationDeleted() );
		}
		setBusy( 'action', ob_id, false );
	};

	// Inline duplicate icon — Phase 1.7 fix 2: inside an A/B group, the clone button always uses
	// the variation-aware clone so the new entry is automatically linked under the same control.
	const onInlineDuplicate = ( ob_id ) => {
		setBusy( 'action', ob_id, 'clone' );
		ab.cloneVariation( {
			stepId,
			control_ob_id: controlBump.id,
			source_ob_id: ob_id,
		} )
			.then( ( result ) => {
				if ( result?.success ) {
					// Snapshot row ids before the list re-renders so the fresh clone can be diffed out.
					const prevIds = Array.from(
						document.querySelectorAll( '[data-ob-id]' )
					).map( ( el ) => el.dataset.obId );
					dispatchToUse( {
						type: 'UPDATE_ORDER_BUMP',
						name: 'wcf-order-bumps',
						order_bumps: result.data.order_bumps,
					} );
					toast.success( toasts.variationCloned() );
					setTimeout( () => {
						const newRow = Array.from(
							document.querySelectorAll( '[data-ob-id]' )
						).find(
							( el ) => ! prevIds.includes( el.dataset.obId )
						);
						if ( ! newRow ) {
							return;
						}
						newRow.scrollIntoView( {
							behavior: 'smooth',
							block: 'center',
						} );
						newRow.classList.add( 'bg-brand-25' );
						setTimeout(
							() => newRow.classList.remove( 'bg-brand-25' ),
							2000
						);
					}, 100 );
				}
			} )
			.finally( () => setBusy( 'action', ob_id, false ) );
	};

	// Inline settings icon — Phase 1.6 fix 4. Mirror OrderBumpRepeater.showOBSettings():
	// prefer the parent-supplied onEditClick callback; otherwise call the lifted setter so
	// only one bump's inline panel is open across the whole list at a time.
	const onInlineSettings = ( ob_id ) => {
		if ( 'function' === typeof onEditClick ) {
			onEditClick( ob_id );
			return;
		}
		// Scrolling is handled by the row's isSettingsOpen effect, after the panel has rendered.
		toggleObSettings?.( ob_id );
	};

	// Menu item — Archive Variation. Mirrors Step A/B's archive-variation confirmation.
	const onMenuArchive = async ( ob_id ) => {
		const ok = await confirm( {
			title: __( 'Archive Variation', 'cartflows-pro' ),
			description: __(
				'Do you want to archive this variation? You can restore it later.',
				'cartflows-pro'
			),
			actionBtnText: __( 'Archive', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );
		if ( ! ok ) {
			return;
		}
		const result = await ab.archiveVariation( {
			stepId,
			control_ob_id: controlBump.id,
			ob_id,
		} );
		if ( result?.success ) {
			dispatchToUse( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success( toasts.variationArchived() );
		}
	};

	// Menu item — Declare as Winner. Captures the vid and opens the confirmation modal.
	const onMenuDeclareWinner = ( ob_id ) => {
		setPendingWinnerVid( ob_id );
		setWinnerOpen( true );
	};

	// Confirm handler for the winner modal — actually fires the AJAX.
	const onConfirmDeclareWinner = async () => {
		if ( ! pendingWinnerVid ) {
			return false;
		}
		const result = await ab.declareWinner( {
			stepId,
			control_ob_id: controlBump.id,
			winner_ob_id: pendingWinnerVid,
		} );
		if ( result?.success ) {
			dispatchToUse( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success( toasts.winnerDeclared() );
			setPendingWinnerVid( null );
			return true;
		}
		return false;
	};

	// Header — Start / Stop split test.
	const onToggleAbTest = async () => {
		const result = abTestStart
			? await ab.pauseAbTest( { stepId, control_ob_id: controlBump.id } )
			: await ab.startAbTest( { stepId, control_ob_id: controlBump.id } );
		if ( result?.success ) {
			dispatchToUse( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success(
				abTestStart ? toasts.splitStopped() : toasts.splitStarted()
			);
		}
	};

	// Header — open traffic settings modal.
	const onOpenSettings = () => {
		setTrafficOpen( true );
	};

	// Traffic dialog save — fires the dedicated save_order_bump_ab_traffic AJAX.
	const onTrafficSave = async ( nextVariations ) => {
		const result = await ab.saveTraffic( {
			stepId,
			control_ob_id: controlBump.id,
			variations: nextVariations,
		} );
		if ( result?.success ) {
			dispatchToUse( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success( toasts.trafficSaved() );
			return true;
		}
		return false;
	};

	// Archived list — restore handler.
	const onRestoreArchived = async ( ob_id ) => {
		const result = await ab.restoreArchived( {
			stepId,
			control_ob_id: controlBump.id,
			ob_id,
		} );
		if ( result?.success ) {
			dispatchToUse( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success( toasts.archiveRestored() );
		}
	};

	// Archived list — delete handler.
	const onDeleteArchived = async ( ob_id ) => {
		const ok = await confirm( {
			title: __( 'Delete Archived Variation', 'cartflows-pro' ),
			description: __(
				'Do you want to delete this archived variation permanently?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Delete', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );
		if ( ! ok ) {
			return;
		}
		const result = await ab.deleteArchived( {
			stepId,
			control_ob_id: controlBump.id,
			ob_id,
		} );
		if ( result?.success ) {
			dispatchToUse( {
				type: 'UPDATE_ORDER_BUMP',
				name: 'wcf-order-bumps',
				order_bumps: result.data.order_bumps,
			} );
			toast.success( toasts.archiveDeleted() );
		}
	};

	// Title used in the Declare Winner modal — captured at open time.
	const winnerTitle = pendingWinnerVid
		? bumpsById[ pendingWinnerVid ]?.title || ''
		: '';

	// Render the whole group as one container that visually replaces a single OB row.
	// Phase 1.6 fix 4: also render OrderBumpPagesRoute as a sibling when local obid state is set.
	// Phase 1.7 fix 4: switch outer wrapper from Force UI Container (flex) to a plain block <div> so
	// the inner head/row widths inherit correctly from the parent panel — and apply card-style
	// segregation (rounded border + margin + shadow + orange left accent) to clearly group the
	// control + variation rows the way Steps A/B does.
	return (
		<>
			<div className="wcf-ob-ab-group block rounded-lg overflow-hidden border border-solid border-border-subtle border-l-2 !border-l-brand-500 bg-background-primary shadow-sm m-4">
				<OrderBumpAbHead
					abTestStart={ abTestStart }
					onToggle={ onToggleAbTest }
					onOpenSettings={ onOpenSettings }
				/>
				{ ( () => {
					// Compute the current leader once per render — passed as `isWinner` to each row below.
					const leaderId = pickCurrentLeader(
						controlBump?.id,
						variations,
						statsBlob
					);
					return variations.map( ( v, idx ) => {
						const bump = bumpsById[ v.id ];
						if ( ! bump ) {
							return null;
						}
						const isControl = 0 === idx;
						return (
							<OrderBumpAbRow
								key={ v.id }
								bump={ bump }
								role={ isControl ? 'control' : 'variant' }
								variantNumber={ idx }
								traffic={ v.traffic }
								stepId={ stepId }
								dispatch={ dispatchToUse }
								statusProcess={ !! statusBusy[ v.id ] }
								actionProcess={ actionBusy[ v.id ] || '' }
								onStatusToggle={ onStatusToggle }
								onDuplicateClick={ onInlineDuplicate }
								onSettingsClick={ onInlineSettings }
								isSettingsOpen={ openObSettingsId === v.id }
								onDeleteClick={ onInlineDelete }
								onMenuDeclareWinner={ () =>
									onMenuDeclareWinner( v.id )
								}
								onMenuArchive={ () => onMenuArchive( v.id ) }
								isWinner={ leaderId === v.id }
							/>
						);
					} );
				} )() }
				<ArchivedVariations
					items={ archived }
					onRestore={ onRestoreArchived }
					onDelete={ onDeleteArchived }
					trailing={
						<button
							type="button"
							onClick={ () =>
								onInlineDuplicate( controlBump.id )
							}
							disabled={
								'clone' === actionBusy[ controlBump.id ]
							}
							className="wcf-ob-ab-add-variation inline-flex items-center gap-1 text-xs font-medium text-brand-500 hover:text-brand-600 bg-transparent border-0 px-2 py-1 rounded cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed hover:bg-brand-25"
						>
							<Plus className="w-4 h-4" />
							{ __( 'Add Variation', 'cartflows-pro' ) }
						</button>
					}
				/>
				<TrafficSplitDialog
					open={ trafficOpen }
					setOpen={ setTrafficOpen }
					variations={ variations }
					titlesById={ titlesById }
					onSave={ onTrafficSave }
				/>
				<DeclareWinnerDialog
					open={ winnerOpen }
					setOpen={ setWinnerOpen }
					winningTitle={ winnerTitle }
					onConfirm={ onConfirmDeclareWinner }
					controlId={ controlBump?.id }
					variations={ variations }
					bumpsById={ bumpsById }
					pendingWinnerId={ pendingWinnerVid }
					statsBlob={ statsBlob }
				/>
			</div>
			{ openObSettingsId &&
				variations.some( ( v ) => v.id === openObSettingsId ) && (
					<OrderBumpPagesRoute
						key={ openObSettingsId }
						ob_id={ openObSettingsId }
					/>
				) }
		</>
	);
};

// Default export — keeps MultiOrderBump's branch import line short.
export default OrderBumpAbGroup;
