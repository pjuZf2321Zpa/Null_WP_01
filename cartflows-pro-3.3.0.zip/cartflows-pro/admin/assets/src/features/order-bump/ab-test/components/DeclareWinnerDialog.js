// Confirmation dialog for the destructive "Declare as Winner" action — Surface B from the mockup.
// Renders a side-by-side comparison of every participant (control + variants) with funnel stats
// so the admin picks a winner with data, not blind.
import { useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { Dialog, Button, Container, Text, Badge } from '@bsf/force-ui';
import { TrophyIcon } from '@heroicons/react/24/outline';
import { getStatsForBump, computeCr } from '../../components/funnelStats';

// Sanity threshold — variants with fewer impressions don't qualify for the auto-recommendation.
const IMPRESSION_THRESHOLD = 30;

// Format CR as "24.3%" or "—" when there's no data yet.
const formatCr = ( cr ) => ( null === cr ? '—' : `${ cr.toFixed( 1 ) }%` );

// Lift = (variant_cr - control_cr) / control_cr × 100. Returns null when not computable.
const computeLift = ( variantCr, controlCr ) => {
	if ( null === variantCr || null === controlCr || controlCr <= 0 ) {
		return null;
	}
	return ( ( variantCr - controlCr ) / controlCr ) * 100;
};

// Renders a single comparison card per participant. Force UI Container + Text + Badge only.
const ComparisonCard = ( {
	bump,
	role,
	isWinner,
	isPendingWinner,
	statsBlob,
} ) => {
	const stats = getStatsForBump( bump, statsBlob );
	const cr = computeCr( stats );

	// Card visual: green ring + tinted background when the variant is the chosen winner; else neutral border.
	// TODO: No Force UI prop for a "card-with-highlight" state — using className on Container.
	const cardClass = isPendingWinner
		? 'wcf-ob-cmp-card p-4 rounded-md border border-solid border-support-success bg-support-success-bg'
		: 'wcf-ob-cmp-card p-4 rounded-md border border-solid border-border-subtle bg-background-secondary';

	// Role badge: Control (blue) | Variation-N (inverse/dark) | Winner (green) when chosen.
	let roleLabel = '';
	let roleVariant = 'neutral';
	if ( isPendingWinner ) {
		roleLabel = __( '★ Winner', 'cartflows-pro' );
		roleVariant = 'green';
	} else if ( 'control' === role ) {
		roleLabel = __( 'Control', 'cartflows-pro' );
		roleVariant = 'blue';
	} else {
		roleLabel = role;
		roleVariant = 'inverse';
	}

	return (
		<Container
			containerType="flex"
			direction="column"
			gap="sm"
			className={ cardClass }
		>
			<Container
				containerType="flex"
				align="center"
				justify="between"
				gap="xs"
			>
				<Text
					as="span"
					size={ 14 }
					weight={ 600 }
					className="text-text-primary truncate"
				>
					{ bump?.title || __( '(no title)', 'cartflows-pro' ) }
				</Text>
				<Badge
					label={ roleLabel }
					variant={ roleVariant }
					type="pill"
					size="xs"
					disableHover
				/>
			</Container>
			<Container containerType="flex" direction="column" gap="xxs">
				<StatRow
					labelText={ __( 'Impressions', 'cartflows-pro' ) }
					value={ stats.impressions }
				/>
				<StatRow
					labelText={ __( 'Initiated', 'cartflows-pro' ) }
					value={ stats.initiated }
				/>
				<StatRow
					labelText={ __( 'Conversions', 'cartflows-pro' ) }
					value={ stats.conversions }
				/>
				<StatRow
					labelText={ __( 'Conversion Rate', 'cartflows-pro' ) }
					value={ formatCr( cr ) }
					emphasis={ isPendingWinner ? 'success' : 'default' }
				/>
			</Container>
			{ isWinner && ! isPendingWinner && (
				<Text size={ 12 } className="text-support-success">
					{ __( 'Currently leading', 'cartflows-pro' ) }
				</Text>
			) }
		</Container>
	);
};

// Single label / value row inside a card — Force UI Text only.
const StatRow = ( { labelText, value, emphasis = 'default' } ) => {
	const valueClass =
		'success' === emphasis ? 'text-support-success' : 'text-text-primary';
	return (
		<Container
			containerType="flex"
			align="center"
			justify="between"
			gap="xs"
		>
			<Text as="span" size={ 12 } className="text-text-tertiary">
				{ labelText }
			</Text>
			<Text as="span" size={ 12 } weight={ 600 } className={ valueClass }>
				{ value }
			</Text>
		</Container>
	);
};

// Main dialog — accepts the full A/B context so it can render every participant's stats.
const DeclareWinnerDialog = ( {
	open,
	setOpen,
	winningTitle = '',
	onConfirm,
	// New props (Surface B): full A/B context lets the dialog render the comparison grid.
	controlId,
	variations = [],
	bumpsById = {},
	pendingWinnerId = null,
	statsBlob = {},
} ) => {
	const [ confirming, setConfirming ] = useState( false );

	const onCancel = () => setOpen( false );

	const onConfirmClick = async () => {
		if ( confirming ) {
			return;
		}
		setConfirming( true );
		try {
			const ok = await onConfirm?.();
			if ( false !== ok ) {
				setOpen( false );
			}
		} finally {
			setConfirming( false );
		}
	};

	// Compute the control's CR up-front — used for the "Lift over control" footnote.
	const controlBump = bumpsById?.[ controlId ];
	const controlCr = controlBump
		? computeCr( getStatsForBump( controlBump, statsBlob ) )
		: null;

	// Compute lift for the pending winner so the footer can show "+X%" vs control.
	let pendingLift = null;
	if ( pendingWinnerId && pendingWinnerId !== controlId ) {
		const pendingBump = bumpsById?.[ pendingWinnerId ];
		if ( pendingBump ) {
			pendingLift = computeLift(
				computeCr( getStatsForBump( pendingBump, statsBlob ) ),
				controlCr
			);
		}
	}

	// Sum impressions across the test for the header line.
	let totalImpressions = 0;
	variations.forEach( ( v ) => {
		const b = bumpsById?.[ v?.id ];
		if ( b ) {
			totalImpressions += getStatsForBump( b, statsBlob ).impressions;
		}
	} );

	// Find current leader (highest CR with sufficient sample) — shows the system recommendation.
	let recommendedId = null;
	let recommendedCr = -1;
	variations.forEach( ( v ) => {
		const b = bumpsById?.[ v?.id ];
		if ( ! b ) {
			return;
		}
		const s = getStatsForBump( b, statsBlob );
		if ( s.impressions < IMPRESSION_THRESHOLD ) {
			return;
		}
		const cr = computeCr( s ) || 0;
		if ( cr > recommendedCr ) {
			recommendedCr = cr;
			recommendedId = v.id;
		}
	} );

	return (
		<Dialog open={ open } setOpen={ setOpen } exitOnClickOutside={ false }>
			<Dialog.Panel className="!p-3 !gap-4 !w-[640px] !max-w-[90vw]">
				<Dialog.Backdrop />
				<div className="flex gap-2.5 p-2">
					<TrophyIcon
						className="w-6 h-6 text-support-success shrink-0 mt-0.5"
						aria-hidden="true"
					/>
					<div className="flex flex-col gap-1.5 flex-1 min-w-0">
						<div className="flex items-center justify-between">
							<Dialog.Title className="!text-lg">
								{ __( 'Declare Winner', 'cartflows-pro' ) }
							</Dialog.Title>
							<Dialog.CloseButton />
						</div>
						<Text
							as="span"
							size={ 14 }
							className="text-text-secondary"
						>
							{ sprintf(
								/* translators: %s is the winning variation's title. */
								__(
									'Do you want to declare “%s” as the winner? The other variations will be moved to Archived Variations and the test will end.',
									'cartflows-pro'
								),
								winningTitle
							) }
						</Text>
						<Text
							as="span"
							size={ 12 }
							className="text-text-tertiary"
						>
							{ sprintf(
								/* translators: 1: total impressions across the test, 2: system-recommended variant name or "—". */
								__(
									'Total visitors: %1$s · System recommendation: %2$s',
									'cartflows-pro'
								),
								totalImpressions,
								recommendedId
									? bumpsById?.[ recommendedId ]?.title ||
											recommendedId
									: __(
											'not enough data yet',
											'cartflows-pro'
									  )
							) }
						</Text>
					</div>
				</div>

				{ /* Surface B · Comparison grid — one card per participant. Force UI Container only. */ }
				<Container
					containerType="grid"
					gap="sm"
					className="grid-cols-1 sm:grid-cols-2 p-2"
				>
					{ variations.map( ( v, idx ) => {
						const bump = bumpsById?.[ v?.id ];
						if ( ! bump ) {
							return null;
						}
						const role =
							0 === idx
								? 'control'
								: sprintf(
										/* translators: %d is the variant index (1-based) */
										__( 'Variation-%d', 'cartflows-pro' ),
										idx
								  );
						return (
							<ComparisonCard
								key={ v.id }
								bump={ bump }
								role={ role }
								isWinner={ recommendedId === v.id }
								isPendingWinner={ pendingWinnerId === v.id }
								statsBlob={ statsBlob }
							/>
						);
					} ) }
				</Container>

				{ null !== pendingLift && (
					<Text size={ 12 } className="text-text-tertiary px-2">
						{ sprintf(
							/* translators: %s is the % lift over control (e.g. "+35.8%"). */
							__( 'Lift over control: %s', 'cartflows-pro' ),
							`${
								pendingLift > 0 ? '+' : ''
							}${ pendingLift.toFixed( 1 ) }%`
						) }
					</Text>
				) }

				<Dialog.Footer className="!p-2 flex gap-3 justify-end">
					<Button
						variant="outline"
						size="md"
						onClick={ onCancel }
						disabled={ confirming }
					>
						{ __( 'Cancel', 'cartflows-pro' ) }
					</Button>
					<Button
						variant="primary"
						size="md"
						onClick={ onConfirmClick }
						loading={ confirming }
						disabled={ confirming }
					>
						{ confirming
							? __( 'Declaring…', 'cartflows-pro' )
							: sprintf(
									/* translators: %s is the winning variation's title. */
									__(
										'Declare %s as Winner',
										'cartflows-pro'
									),
									winningTitle
							  ) }
					</Button>
				</Dialog.Footer>
			</Dialog.Panel>
		</Dialog>
	);
};

export default DeclareWinnerDialog;
