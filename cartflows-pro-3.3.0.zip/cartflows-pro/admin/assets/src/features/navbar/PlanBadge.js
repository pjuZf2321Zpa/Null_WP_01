import ProBadge from '@CTA/ProBadge';

/**
 * Active plan badge (PRO / PLUS / STARTER) for the navbar slot.
 *
 * @return {Object} Plan badge.
 */
function PlanBadge() {
	const plan = window.cartflows_admin?.cf_pro_type || 'pro';

	return <ProBadge label={ plan.toUpperCase() } />;
}

export default PlanBadge;
