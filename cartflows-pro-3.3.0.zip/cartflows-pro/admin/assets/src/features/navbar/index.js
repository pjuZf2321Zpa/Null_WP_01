import { addFilter } from '@wordpress/hooks';
import { isProActive } from '@ProUtils/plan';
import LicenseBadge from './LicenseBadge';
import PlanBadge from './PlanBadge';

addFilter(
	'cartflows.navbar.licenseBadge',
	'cartflows-pro/navbar/license-badge',
	( current ) => ( isProActive() ? LicenseBadge : current )
);

addFilter(
	'cartflows.navbar.planBadge',
	'cartflows-pro/navbar/plan-badge',
	( current ) => ( isProActive() ? PlanBadge : current )
);
