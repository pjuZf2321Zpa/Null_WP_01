import { __ } from '@wordpress/i18n';
import { Badge, Button } from '@bsf/force-ui';

/**
 * License status badge for the free plugin's top navbar slot.
 *
 * @param {Object}   props                       Component props.
 * @param {string}   props.licenseStatus         License status from the free settings store.
 * @param {Function} props.onOpenLicenseSettings Opens the license settings tab.
 * @return {Object} License badge button.
 */
function LicenseBadge( { licenseStatus, onOpenLicenseSettings } ) {
	const isLicensed = 'Activated' === licenseStatus;

	return (
		<Button
			variant="ghost"
			className="p-0 hover:bg-transparent focus:[box-shadow:none] [box-shadow:none]"
			onClick={ ( e ) => {
				if ( isLicensed ) {
					return;
				}
				onOpenLicenseSettings( e );
			} }
			icon={
				<Badge
					label={
						isLicensed
							? __( 'Licensed', 'cartflows-pro' )
							: __( 'Unlicensed', 'cartflows-pro' )
					}
					size="xs"
					variant={ isLicensed ? 'green' : 'red' }
				/>
			}
		/>
	);
}

export default LicenseBadge;
