import apiFetch from '@wordpress/api-fetch';
import { __ } from '@wordpress/i18n';

const post = ( formData ) =>
	apiFetch( {
		url: cartflows_admin.ajax_url,
		method: 'POST',
		body: formData,
	} );

/**
 * Build the canvas A/B variation node action handlers.
 * Free injects confirm/toast/loader so dialogs render in its bundle.
 *
 * @param {Object}   ctx           Handler context.
 * @param {Object}   ctx.data      Node data (step_id, flow_id, control_id).
 * @param {Function} ctx.confirm   Free confirm dialog.
 * @param {Function} ctx.setLoader Node loader setter.
 * @param {Object}   ctx.toast     Free toast API.
 * @return {Object} { clone, delete, winner, archived } click handlers.
 */
export function createAbVariationActions( {
	data,
	confirm,
	setLoader,
	toast,
} ) {
	const cloneStep = async ( e ) => {
		e.preventDefault();

		// eslint-disable-next-line @wordpress/no-unused-vars-before-return -- currentTarget is unusable after await.
		const action = e.currentTarget.getAttribute( 'data-action' );

		const isconfirm = await confirm( {
			title: __( 'Duplicate Variation', 'cartflows-pro' ),
			description: __(
				'Do you want to duplicate this variation? Are you sure?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Yes', 'cartflows-pro' ),
			cancelBtnText: __( 'No', 'cartflows-pro' ),
		} );

		if ( ! isconfirm ) {
			return;
		}

		setLoader( true );

		const formData = new window.FormData();
		formData.append( 'action', action );
		formData.append(
			'security',
			cartflows_admin.wcf_clone_ab_test_step_nonce
		);
		formData.append( 'step_id', data?.step_id );
		formData.append( 'post_id', data?.flow_id );
		formData.append( 'control_id', data?.control_id );
		window.wcfAction = 'cloneABTestStep';

		post( formData )
			.then( () => {
				window.location.reload();
			} )
			.catch( ( error ) => {
				console.error( 'Clone Step failed:', error );
				setLoader( false );
			} );
	};

	const deleteStep = async ( e ) => {
		e.preventDefault();

		// eslint-disable-next-line @wordpress/no-unused-vars-before-return -- currentTarget is unusable after await.
		const action = e.currentTarget.getAttribute( 'data-action' );

		const isconfirm = await confirm( {
			title: __( 'Delete Variation', 'cartflows-pro' ),
			description: __(
				'Do you want to delete this variation? Are you sure?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Yes', 'cartflows-pro' ),
			cancelBtnText: __( 'No', 'cartflows-pro' ),
		} );

		if ( ! isconfirm ) {
			return;
		}

		setLoader( true );

		const formData = new window.FormData();
		formData.append( 'action', action );
		formData.append(
			'security',
			cartflows_admin.wcf_delete_ab_test_step_nonce
		);
		formData.append( 'step_id', data?.step_id );
		formData.append( 'post_id', data?.flow_id );
		formData.append( 'control_id', data?.control_id );
		window.wcfAction = 'deleteABTestStep';

		post( formData )
			.then( () => {
				window.location.reload();
			} )
			.catch( ( error ) => {
				console.error( 'Delete step failed:', error );
				setLoader( false );
			} );
	};

	const declareWinner = async ( e ) => {
		e.preventDefault();

		const isconfirm = await confirm( {
			title: __( 'Declare Winner', 'cartflows-pro' ),
			description: __(
				'Do you want to declare this step as winner? Are you sure?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Declare Winner', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );

		if ( ! isconfirm ) {
			return;
		}

		setLoader( true );

		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_declare_ab_test_winner' );
		formData.append(
			'security',
			cartflows_admin.wcf_declare_ab_test_winner_nonce
		);
		formData.append( 'step_id', data?.step_id );
		formData.append( 'flow_id', data?.flow_id );
		window.wcfAction = 'winnerStep';

		post( formData )
			.then( () => {
				toast.success(
					__( 'Winner declared successfully!', 'cartflows-pro' )
				);
				window.location.reload();
			} )
			.catch( ( error ) => {
				console.error( 'Declare AB Test Winner failed:', error );
				toast.error(
					__(
						'Failed to declare winner. Please try again.',
						'cartflows-pro'
					)
				);
				setLoader( false );
			} );
	};

	const archivedStep = async ( e ) => {
		e.preventDefault();

		const isconfirm = await confirm( {
			title: __( 'Archive Variation', 'cartflows-pro' ),
			description: __(
				'Do you want to archive this variation? Are you sure?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Yes', 'cartflows-pro' ),
			cancelBtnText: __( 'No', 'cartflows-pro' ),
		} );

		if ( ! isconfirm ) {
			return;
		}

		setLoader( true );

		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_archive_ab_test_step' );
		formData.append(
			'security',
			cartflows_admin.wcf_archive_ab_test_step_nonce
		);
		formData.append( 'step_id', data?.step_id );
		formData.append( 'post_id', data?.flow_id );
		window.wcfAction = 'archiveStep';

		post( formData )
			.then( () => {
				window.location.reload();
			} )
			.catch( ( error ) => {
				console.error( 'Archiving step failed:', error );
				setLoader( false );
			} );
	};

	return {
		clone: cloneStep,
		delete: deleteStep,
		winner: declareWinner,
		archived: archivedStep,
	};
}
