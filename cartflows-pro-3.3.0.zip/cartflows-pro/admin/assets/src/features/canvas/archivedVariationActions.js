import apiFetch from '@wordpress/api-fetch';
import { __ } from '@wordpress/i18n';

const post = ( payload ) =>
	apiFetch( {
		url: cartflows_admin.ajax_url,
		method: 'POST',
		body: payload,
	} );

const baseForm = ( { action, nonce, stepId, flowId, controlId } ) => {
	const fd = new window.FormData();
	fd.append( 'action', action );
	fd.append( 'security', nonce );
	fd.append( 'step_id', stepId );
	fd.append( 'flow_id', flowId );
	fd.append( 'control_id', controlId );
	return fd;
};

// Confirm → AJAX → toast → reload; mirrors the list view's ArchivedInnerStep.
const runAction = async ( {
	confirm,
	toast,
	title,
	description,
	actionText,
	payload,
	successText,
	errorText,
} ) => {
	const ok = await confirm( {
		title,
		description,
		actionBtnText: actionText,
		cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
	} );
	if ( ! ok ) {
		return false;
	}
	return post( payload )
		.then( () => {
			toast.success( successText );
			window.location.reload();
		} )
		.catch( () => {
			toast.error( errorText );
		} );
};

export const restoreVariation = ( ctx ) =>
	runAction( {
		...ctx,
		title: __( 'Restore Archived Variation', 'cartflows-pro' ),
		description: __(
			'Do you want to restore this archived variation? Are you sure?',
			'cartflows-pro'
		),
		actionText: __( 'Restore', 'cartflows-pro' ),
		payload: baseForm( {
			action: 'cartflows_restore_archive_ab_test_variation',
			nonce: cartflows_admin.wcf_restore_archive_ab_test_variation_nonce,
			stepId: ctx.stepId,
			flowId: ctx.flowId,
			controlId: ctx.controlId,
		} ),
		successText: __( 'Variation restored.', 'cartflows-pro' ),
		errorText: __(
			'Failed to restore variation. Please try again.',
			'cartflows-pro'
		),
	} );

export const softDeleteVariation = ( ctx ) =>
	runAction( {
		...ctx,
		title: __( 'Trash Archived Variation', 'cartflows-pro' ),
		description: __(
			'This action will trash this archived variation and its analytics data permanently. Do you want to delete this archived variation?',
			'cartflows-pro'
		),
		actionText: __( 'Trash', 'cartflows-pro' ),
		payload: baseForm( {
			action: 'cartflows_delete_archive_ab_test_variation',
			nonce: cartflows_admin.wcf_delete_archive_ab_test_variation_nonce,
			stepId: ctx.stepId,
			flowId: ctx.flowId,
			controlId: ctx.controlId,
		} ),
		successText: __( 'Variation moved to trash.', 'cartflows-pro' ),
		errorText: __(
			'Failed to delete variation. Please try again.',
			'cartflows-pro'
		),
	} );

export const hideVariation = ( ctx ) => {
	const fd = new window.FormData();
	fd.append( 'action', 'cartflows_hide_archive_ab_test_variation' );
	fd.append(
		'security',
		cartflows_admin.hide_archive_ab_test_variation_nonce
	);
	fd.append( 'step_id', ctx.stepId );

	return runAction( {
		...ctx,
		title: __( 'Hide Archived Variation', 'cartflows-pro' ),
		description: __(
			'This action will hide this archived variation from the list of steps, but its analytics will be visible. Do you want to hide this archived variation?',
			'cartflows-pro'
		),
		actionText: __( 'Hide', 'cartflows-pro' ),
		payload: fd,
		successText: __( 'Variation hidden.', 'cartflows-pro' ),
		errorText: __(
			'Failed to hide variation. Please try again.',
			'cartflows-pro'
		),
	} );
};

export const permanentDeleteVariation = ( ctx ) =>
	runAction( {
		...ctx,
		title: __( 'Trash Archived Variation', 'cartflows-pro' ),
		description: __(
			'This action will delete this archived variation and its analytics data permanently. Do you want to delete this archived variation?',
			'cartflows-pro'
		),
		actionText: __( 'Delete', 'cartflows-pro' ),
		payload: baseForm( {
			action: 'cartflows_permanent_delete_archive_ab_test_variation',
			nonce: cartflows_admin.permanent_delete_archive_ab_test_variation_nonce,
			stepId: ctx.stepId,
			flowId: ctx.flowId,
			controlId: ctx.controlId,
		} ),
		successText: __( 'Variation permanently deleted.', 'cartflows-pro' ),
		errorText: __(
			'Failed to delete variation. Please try again.',
			'cartflows-pro'
		),
	} );

export const ACTION_BY_SLUG = {
	restore: restoreVariation,
	delete: softDeleteVariation,
	hide: hideVariation,
	deleteArch: permanentDeleteVariation,
};
