import { addFilter } from '@wordpress/hooks';
import { isProPlan, isProActive } from '@ProUtils/plan';
import { createAbVariationActions } from './abVariationActions';
import { ACTION_BY_SLUG } from './archivedVariationActions';
import { cloneStepRequest } from './cloneStep';

addFilter(
	'cartflows.canvas.abNodeActions',
	'cartflows-pro/canvas/ab-node-actions',
	( current ) => ( isProPlan() ? createAbVariationActions : current )
);

addFilter(
	'cartflows.canvas.archivedVariationActions',
	'cartflows-pro/canvas/archived-variation-actions',
	( current ) => ( isProPlan() ? ACTION_BY_SLUG : current )
);

addFilter(
	'cartflows.canvas.cloneStepRequest',
	'cartflows-pro/canvas/clone-step',
	( current ) => ( isProActive() ? cloneStepRequest : current )
);
