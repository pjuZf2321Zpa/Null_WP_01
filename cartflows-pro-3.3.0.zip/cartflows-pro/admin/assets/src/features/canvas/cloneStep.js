import apiFetch from '@wordpress/api-fetch';

/**
 * Fire the clone-step AJAX without a confirm dialog (Cmd/Ctrl+D path).
 *
 * @param {Object} args
 * @param {number} args.stepId
 * @param {number} args.flowId
 * @param {string} [args.action='cartflows_clone_step']
 * @param {number} [args.controlId]                     Required when cloning an AB variation.
 * @return {Promise} apiFetch promise.
 */
export function cloneStepRequest( {
	stepId,
	flowId,
	action = 'cartflows_clone_step',
	controlId,
} ) {
	let nonce = cartflows_admin.clone_step_nonce;
	const formData = new window.FormData();
	if ( 'cartflows_clone_ab_test_step' === action ) {
		nonce = cartflows_admin.wcf_clone_ab_test_step_nonce;
		formData.append( 'control_id', controlId );
	}
	formData.append( 'action', action );
	formData.append( 'security', nonce );
	formData.append( 'step_id', stepId );
	formData.append( 'post_id', flowId );

	window.wcfAction = 'cloneStep';
	return apiFetch( {
		url: cartflows_admin.ajax_url,
		method: 'POST',
		body: formData,
	} );
}
