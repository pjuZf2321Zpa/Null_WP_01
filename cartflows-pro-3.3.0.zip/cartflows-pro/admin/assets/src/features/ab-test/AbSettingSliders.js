import { useState } from '@wordpress/element';
import { validateTitleField } from '@ProUtils/validate';
import { Input, Label } from '@bsf/force-ui';

function AbSettingSliders( props ) {
	const { abVariations } = props;

	const initialAllValues = {};

	abVariations.map( ( step ) => {
		initialAllValues[ step.id ] = parseInt( step.traffic );
		return '';
	} );

	const [ allValues, setAllValues ] = useState( initialAllValues );

	const updateOtherVariations = function ( currentID, currentValue ) {
		currentID = parseInt( currentID );
		currentValue = parseInt( currentValue );

		let currentDiff = allValues[ currentID ] - currentValue;

		const tempData = {};
		abVariations.map( ( step ) => {
			const variationId = parseInt( step.id );

			if ( currentID === variationId ) {
				tempData[ variationId ] = currentValue;
			} else {
				let newValue = allValues[ variationId ] + currentDiff;

				if ( newValue < 0 ) {
					currentDiff = newValue;
					newValue = 0;
				} else if ( newValue > 100 ) {
					currentDiff = newValue - 100;
					newValue = 100;
				} else {
					currentDiff = 0;
				}

				tempData[ variationId ] = newValue;
			}

			return '';
		} );

		setAllValues( tempData );
	};

	return (
		<>
			{ abVariations &&
				abVariations.map( ( step ) => {
					const variationId = step.id;
					const title = step.title;

					return (
						<div
							className="wcf-traffic-field pb-5"
							data-id={ step.id }
							key={ step.id }
						>
							<Label
								className="wcf-step-name w-40 mr-4"
								tag="span"
								size="sm"
								title={ title }
							>
								{ validateTitleField( title, 20, 15 ) }
							</Label>
							<div
								className="wcf-traffic-slider-wrap flex items-center gap-3 flex-1"
								data-variation-id={ step.id }
							>
								{ /* TODO: No Force UI equivalent — wcf-traffic-range */ }
								<div
									className={ `wcf-traffic-range wcf-traffic-range-${ step.id } flex-1` }
								>
									<input
										type="range"
										value={ allValues[ variationId ] }
										onChange={ ( e ) => {
											updateOtherVariations(
												variationId,
												e.target.value
											);
										} }
									/>
								</div>
								<div
									className={ `wcf-traffic-value wcf-traffic-value-${ step.id } shrink-0` }
								>
									<Input
										type="number"
										name={ `wcf_ab_settings[traffic][${ step.id }][value]` }
										value={ String(
											allValues[ variationId ]
										) }
										size="sm"
										suffix="%"
										className="w-20"
										onChange={ ( val ) => {
											updateOtherVariations(
												variationId,
												val
											);
										} }
									/>
								</div>
							</div>
						</div>
					);
				} ) }
		</>
	);
}

export default AbSettingSliders;
