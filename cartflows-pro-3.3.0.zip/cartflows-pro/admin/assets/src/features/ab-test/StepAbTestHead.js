import { useState } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { toast } from '@bsf/force-ui';
import AbSettingPopup from './AbSettingPopup';
import {
	EllipsisVerticalIcon,
	Cog6ToothIcon,
} from '@heroicons/react/24/outline';

function StepAbTestHead( props ) {
	const {
		flow_id,
		control_id,
		step_id,
		abvariations,
		ab_test_start,
		compact = false,
	} = props;

	const [ popup, showPopup ] = useState( false );

	const [ split_text, setSplitText ] = useState(
		ab_test_start
			? __( 'Stop Split Test', 'cartflows-pro' )
			: __( 'Start Split Test', 'cartflows-pro' )
	);

	const [ splitClass, setsplitClass ] = useState(
		ab_test_start
			? 'wcf-stop-split-test text-brand-500 hover:text-brand-700 cursor-pointer'
			: 'wcf-start-split-test text-support-success hover:text-support-success'
	);

	const [ enableSplitTest, SetEnableSplitTest ] = useState( false );

	const abTest = function ( event ) {
		event.preventDefault();

		// If enableSplitTest is true that means one ajax call is in progress, so stop another from happening.
		if ( enableSplitTest ) {
			console.log( 'One process of A/B split test is ongoing.' );
			return;
		}

		if ( ab_test_start ) {
			setsplitClass( 'wcf-start-split-test' );
			setSplitText( __( 'Stopping…', 'cartflows-pro' ) );
		} else {
			setsplitClass( 'wcf-stop-split-test' );
			setSplitText( __( 'Starting…', 'cartflows-pro' ) );
		}

		// Set processing flag to true to indicate the process has started.
		SetEnableSplitTest( true );

		const formData = new window.FormData();

		formData.append( 'action', 'cartflows_start_ab_test' );
		formData.append( 'security', cartflows_admin.wcf_start_ab_test_nonce );
		formData.append( 'step_id', step_id );
		formData.append( 'flow_id', flow_id );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( () => {
			// Set processing flag to false to indicate the process has ended.
			SetEnableSplitTest( false );

			toast.success(
				ab_test_start
					? __( 'Split test stopped!', 'cartflows-pro' )
					: __( 'Split test started!', 'cartflows-pro' )
			);

			// Indicate to the user to that the page is reloading.
			setSplitText( __( 'Reloading…', 'cartflows-pro' ) );

			// Reload to populate the A/B test variations.
			window.location.reload();
		} );
	};

	const abtestSettings = function ( e ) {
		e.preventDefault();
		showPopup( ! popup );
	};

	const closePopup = function () {
		showPopup( false );
	};

	return (
		<div className="wcf-ab-test-head w-full p-4 bg-background-primary flex justify-between items-center border-0 border-b border-solid border-border-subtle rounded-t-lg box-border">
			<div className="wcf-step-left-content flex items-center gap-3">
				<div className="wcf-steps--sortable-toggle flex cursor-move text-text-tertiary">
					<EllipsisVerticalIcon
						className="w-5 h-5 stroke-1"
						aria-hidden="true"
					/>
					<EllipsisVerticalIcon
						className="w-5 h-5 stroke-1 -ml-3.5"
						aria-hidden="true"
					/>
				</div>
				<span
					className={ `wcf-ab-test-title ${
						compact
							? 'font-semibold text-sm'
							: 'font-bold text-base'
					}` }
				>
					{ __( 'Split Test', 'cartflows-pro' ) }
				</span>
			</div>
			<div className="wcf-steps-action-buttons flex gap-3 items-center">
				<a
					href="#"
					className={ `wcf-action-button font-semibold ${
						compact ? 'text-sm ' : ''
					}no-underline ${ splitClass }` }
					title={ split_text }
					data-id={ control_id }
					onClick={ abTest }
				>
					<span>{ split_text }</span>
				</a>
				<a
					href="#"
					className="wcf-settings-split-test wcf-action-button text-text-tertiary hover:text-brand-500"
					title={ `${ __(
						'Split Test Settings',
						'cartflows-pro'
					) }` }
					onClick={ abtestSettings }
				>
					<Cog6ToothIcon
						className={ `w-5 h-5 stroke-1 ${
							enableSplitTest ? 'animate-spin text-brand-500' : ''
						}` }
						aria-hidden="true"
					/>
				</a>
			</div>

			{ popup && (
				<AbSettingPopup
					abvariations={ abvariations }
					flow_id={ flow_id }
					step_id={ step_id }
					control_id={ control_id }
					closeCallback={ closePopup }
				/>
			) }
		</div>
	);
}

export default StepAbTestHead;
