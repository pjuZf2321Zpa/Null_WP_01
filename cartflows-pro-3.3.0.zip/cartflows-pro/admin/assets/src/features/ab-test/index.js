import { addFilter } from '@wordpress/hooks';
import { isProPlan } from '@ProUtils/plan';
import { ConfirmDialogProvider } from '@Alert/ConfirmDialog';
import { Toaster } from '@bsf/force-ui';
import StepAbTestHead from './StepAbTestHead';
import ArchivedSteps from './ArchivedSteps';
import { createStepAbActions } from './stepAbActions';

const AbTestHead = ( props ) => (
	<ConfirmDialogProvider>
		<StepAbTestHead { ...props } />
		<Toaster />
	</ConfirmDialogProvider>
);

const AbTestArchivedSteps = ( props ) => (
	<ConfirmDialogProvider>
		<ArchivedSteps { ...props } />
		<Toaster />
	</ConfirmDialogProvider>
);

addFilter(
	'cartflows.flowEditor.abTestHead',
	'cartflows-pro/ab-test/head',
	( current ) => ( isProPlan() ? AbTestHead : current )
);

addFilter(
	'cartflows.flowEditor.abTestArchivedSteps',
	'cartflows-pro/ab-test/archived-steps',
	( current ) => ( isProPlan() ? AbTestArchivedSteps : current )
);

addFilter(
	'cartflows.flowEditor.abActions',
	'cartflows-pro/ab-test/actions',
	( current ) => ( isProPlan() ? createStepAbActions : current )
);
