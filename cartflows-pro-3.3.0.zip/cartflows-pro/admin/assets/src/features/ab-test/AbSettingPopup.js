import { useState, useRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import './AbSettingPopup.scss';
import apiFetch from '@wordpress/api-fetch';
import AbSettingSliders from './AbSettingSliders';
import { Dialog, Button, toast } from '@bsf/force-ui';

function AbSettingPopup( props ) {
	const { flow_id, step_id, abvariations, closeCallback } = props;
	const [ isSaving, setIsSaving ] = useState( false );
	const [ btnText, setBtnText ] = useState(
		__( 'Save Settings', 'cartflows-pro' )
	);
	const formRef = useRef( null );

	const saveAbSettings = function ( event ) {
		event.preventDefault();
		setIsSaving( true );
		setBtnText( __( 'Saving..', 'cartflows-pro' ) );
		const formData = new window.FormData( event.target );

		const object = {};
		formData.forEach( function ( value, key ) {
			object[ key ] = value;
		} );
		const json = JSON.stringify( object );

		formData.append( 'formdata', json );

		formData.append( 'action', 'cartflows_save_ab_test_setting' );
		formData.append(
			'security',
			cartflows_admin.save_ab_test_setting_nonce
		);
		formData.append( 'step_id', step_id );
		formData.append( 'flow_id', flow_id );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} )
			.then( () => {
				toast.success(
					__( 'Split test settings saved!', 'cartflows-pro' )
				);
				setBtnText( __( 'Reloading..', 'cartflows-pro' ) );
				window.location.reload();
			} )
			.catch( () => {
				setIsSaving( false );
				setBtnText( __( 'Save Settings', 'cartflows-pro' ) );
				toast.error(
					__( 'Failed to save split test settings.', 'cartflows-pro' )
				);
			} );
	};

	return (
		<Dialog
			open={ true }
			setOpen={ ( isOpen ) => {
				if ( ! isOpen ) {
					closeCallback();
				}
			} }
			design="footer-divided"
			exitOnClickOutside
			exitOnEsc
		>
			<Dialog.Portal>
				<Dialog.Panel className="max-w-xl gap-0">
					<Dialog.Backdrop />
					<Dialog.Header className="flex items-center justify-between px-6 pt-5 pb-0">
						<Dialog.Title>
							{ __( 'Split Test Testing', 'cartflows-pro' ) }
						</Dialog.Title>
						<Dialog.CloseButton />
					</Dialog.Header>
					<Dialog.Body className="px-6 py-4">
						<form
							ref={ formRef }
							id="wcf-ab-settings-form"
							onSubmit={ saveAbSettings }
						>
							<div className="text-sm font-medium text-field-label mb-3">
								{ __( 'Traffic', 'cartflows-pro' ) }
							</div>
							<div className="rounded-md border border-border-subtle bg-background-primary text-sm font-medium text-text-primary">
								<AbSettingSliders
									abVariations={ abvariations }
								/>
							</div>
						</form>
					</Dialog.Body>
					<Dialog.Footer className="px-6 py-4">
						<Button
							variant="outline"
							size="sm"
							onClick={ closeCallback }
						>
							{ __( 'Cancel', 'cartflows-pro' ) }
						</Button>
						<Button
							variant="primary"
							size="sm"
							type="submit"
							form="wcf-ab-settings-form"
							loading={ isSaving }
							disabled={ isSaving }
						>
							{ btnText }
						</Button>
					</Dialog.Footer>
				</Dialog.Panel>
			</Dialog.Portal>
		</Dialog>
	);
}

export default AbSettingPopup;
