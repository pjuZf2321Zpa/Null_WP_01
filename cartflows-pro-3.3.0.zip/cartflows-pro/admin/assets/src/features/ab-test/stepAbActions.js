import apiFetch from '@wordpress/api-fetch';
import { __ } from '@wordpress/i18n';

const post = ( formData ) =>
	apiFetch( {
		url: cartflows_admin.ajax_url,
		method: 'POST',
		body: formData,
	} );

/**
 * Build the step A/B action handlers consumed by free's StepActionMenu.
 * Free injects its own confirm/toast/loader so the dialogs and toasts
 * render in the free bundle's providers.
 *
 * @param {Object}   ctx           Handler context.
 * @param {number}   ctx.stepId    Step ID.
 * @param {number}   ctx.flowId    Flow ID.
 * @param {Function} ctx.confirm   Free confirm dialog.
 * @param {Function} ctx.setLoader Row loader setter.
 * @param {Object}   ctx.toast     Free toast API.
 * @return {Object} { abtest, winner, archived } click handlers.
 */
export function createStepAbActions( {
	stepId,
	flowId,
	confirm,
	setLoader,
	toast,
} ) {
	const abtest = ( e ) => {
		e.preventDefault();

		setLoader( true );

		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_create_ab_test_variation' );
		formData.append(
			'security',
			cartflows_admin.wcf_create_ab_test_variation_nonce
		);
		formData.append( 'step_id', stepId );
		formData.append( 'flow_id', flowId );
		window.wcfAction = 'abtestStep';

		post( formData ).then( () => {
			toast.success(
				__( 'A/B test variation created!', 'cartflows-pro' )
			);
			window.location.reload();
			setLoader( false );
		} );
	};

	const winner = async ( e ) => {
		e.preventDefault();

		const isconfirm = await confirm( {
			title: __( 'Declare Winner', 'cartflows-pro' ),
			description: __(
				'Do you want to declare this step as winner? Are you sure?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Declare Winner', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );

		if ( ! isconfirm ) {
			return;
		}

		setLoader( true );
		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_declare_ab_test_winner' );
		formData.append(
			'security',
			cartflows_admin.wcf_declare_ab_test_winner_nonce
		);
		formData.append( 'step_id', stepId );
		formData.append( 'flow_id', flowId );
		window.wcfAction = 'winnerStep';

		post( formData )
			.then( () => {
				toast.success(
					__( 'Winner declared successfully!', 'cartflows-pro' )
				);
				window.location.reload();
				setLoader( false );
			} )
			.catch( ( error ) => {
				console.error( 'Declare A/B test winner failed:', error );
				toast.error(
					__(
						'Failed to declare winner. Please try again.',
						'cartflows-pro'
					)
				);
				setLoader( false );
			} );
	};

	const archived = async ( e ) => {
		e.preventDefault();

		const isconfirm = await confirm( {
			title: __( 'Archive Step', 'cartflows-pro' ),
			description: __(
				'Do you want to archive this step? Are you sure?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Archive', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );

		if ( ! isconfirm ) {
			return;
		}

		setLoader( true );
		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_archive_ab_test_step' );
		formData.append(
			'security',
			cartflows_admin.wcf_archive_ab_test_step_nonce
		);
		formData.append( 'step_id', stepId );
		formData.append( 'post_id', flowId );
		window.wcfAction = 'archiveStep';

		post( formData ).then( () => {
			toast.success(
				__( 'Step archived successfully!', 'cartflows-pro' )
			);
			window.location.reload();
			setLoader( false );
		} );
	};

	return { abtest, winner, archived };
}
