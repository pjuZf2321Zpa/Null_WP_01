import { addFilter } from '@wordpress/hooks';
import { isProActive } from '@ProUtils/plan';
import LicenseSetting from './LicenseSetting';
import CheckoutLinkGenerator from './settings-tabs/CheckoutLinkGenerator';
import OfferSettings from './OfferSettings';
import GeneralProFields from './GeneralProFields';
import PermalinkProFields from './PermalinkProFields';

addFilter(
	'cartflows.settings.license',
	'cartflows-pro/settings/license',
	( current ) => ( isProActive() ? LicenseSetting : current )
);

addFilter(
	'cartflows.settings.checkoutLinkGenerator',
	'cartflows-pro/settings/checkout-link-generator',
	( current ) => ( isProActive() ? CheckoutLinkGenerator : current )
);

addFilter(
	'cartflows.settings.offer',
	'cartflows-pro/settings/offer',
	( current ) => ( isProActive() ? OfferSettings : current )
);

addFilter(
	'cartflows.settings.generalProFields',
	'cartflows-pro/settings/general-pro-fields',
	( current ) => ( isProActive() ? GeneralProFields : current )
);

addFilter(
	'cartflows.settings.permalinkProFields',
	'cartflows-pro/settings/permalink-pro-fields',
	( current ) => ( isProActive() ? PermalinkProFields : current )
);
