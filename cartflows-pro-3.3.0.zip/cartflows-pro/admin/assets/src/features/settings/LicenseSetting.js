import { useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { Input, Button, Title } from '@bsf/force-ui';
import {
	KeyIcon,
	LockOpenIcon,
	ArrowPathIcon,
} from '@heroicons/react/24/outline';
import { useSettingsValue } from '@Utils/SettingsProvider';
import parse from 'html-react-parser';

/**
 * LicenseSetting component — Force-UI migrated license tab UI.
 *
 * @return {JSX.Element} The rendered license setting panel.
 */
function LicenseSetting() {
	const [ { license_status }, setSettingsStatus ] = useSettingsValue();

	const isLicenseActivated = license_status && 'Activated' === license_status;

	const [ licenseKey, setLicenseKey ] = useState( '' );
	const [ licenseErrors, setLicenseErrors ] = useState( false );
	const [ isProcessing, setIsProcessing ] = useState( false );
	const [ isActivated, setIsActivated ] = useState( isLicenseActivated );

	const handleActivate = ( event ) => {
		event.preventDefault();

		setLicenseErrors( false );

		if ( ! isActivated && '' === licenseKey.trim() ) {
			setLicenseErrors(
				__( 'Please enter a valid license key!', 'cartflows-pro' )
			);
			return;
		}

		setIsProcessing( true );

		const isDeactivating = isActivated;
		const ajax_action = isDeactivating
			? 'cartflows_deactivate_license'
			: 'cartflows_activate_license';
		const ajax_nonce = isDeactivating
			? cartflows_admin.license_deactivation_nonce
			: cartflows_admin.license_activation_nonce;

		const formData = new window.FormData();
		formData.append( 'action', ajax_action );
		formData.append( 'license_key', licenseKey );
		formData.append( 'security', ajax_nonce );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( data ) => {
			setIsProcessing( false );

			if ( data.success ) {
				if ( ! isDeactivating ) {
					setIsActivated( true );
					setSettingsStatus( {
						status: 'UPDATE_LICENSE_STATUS',
						license_status: 'Activated',
					} );
				} else {
					setIsActivated( false );
					setLicenseKey( '' );
					setSettingsStatus( {
						status: 'UPDATE_LICENSE_STATUS',
						license_status: 'Deactivated',
					} );
				}
			} else {
				const msg = data.data?.error || data.data || '';
				setLicenseErrors(
					msg ||
						__(
							'Unknown error occurred while activating the license.',
							'cartflows-pro'
						)
				);
			}
		} );
	};

	return (
		<div className="wcf-license-setting">
			<div className="flex flex-col gap-4 max-w-[637px]">
				{ /* Lock icon box */ }
				<div className="w-10 h-10 flex items-center justify-center border border-solid border-gray-300 rounded bg-background-primary p-2">
					<LockOpenIcon className="w-7 h-7 text-text-secondary" />
				</div>

				{ /* Title + description */ }
				<Title
					tag="h2"
					size="md"
					title={ __( 'Your License', 'cartflows-pro' ) }
					description={ parse(
						sprintf(
							// translators: %1$s: link html open, %2$s: link html close
							__(
								'Activate %1$sCartflows Pro%2$s addon to get professional support and automatic updates from your WordPress dashboard. Please enter your valid license key below to activate Cartflows Pro!',
								'cartflows-pro'
							),
							`<a href="${ window.getUtmUrl(
								'https://cartflows.com/',
								{
									utm_campaign: 'license',
								}
							) }" target="_blank" rel="noreferrer" class="text-brand-500 underline font-medium hover:text-brand-600">`,
							'</a>'
						)
					) }
					className="pb-2 [&_h2]:text-text-primary [&>p]:!text-text-secondary [&>p]:!text-sm"
				/>

				{ /* Input + Activate button + help link */ }
				<div className="flex flex-col gap-2.5">
					<div className="flex gap-2 items-start">
						<div className="flex-1">
							<Input
								prefix={ <KeyIcon /> }
								placeholder={
									isActivated
										? '**************************'
										: __(
												'Paste your license key here',
												'cartflows-pro'
										  )
								}
								value={ licenseKey }
								onChange={ ( val ) => setLicenseKey( val ) }
								size="md"
								disabled={ isActivated }
								error={ !! licenseErrors }
							/>
						</div>
						<Button
							variant={ isActivated ? 'primary' : 'outline' }
							size="md"
							onClick={ handleActivate }
							disabled={ isProcessing }
							className={
								isActivated
									? 'bg-support-error hover:bg-support-error border-support-error hover:border-support-error'
									: '!bg-brand-25 !border-brand-300 !text-brand-500 hover:!bg-brand-50 hover:!border-brand-400'
							}
							icon={
								isProcessing ? (
									<ArrowPathIcon className="animate-spin" />
								) : null
							}
							iconPosition="left"
						>
							{ isActivated
								? __( 'Deactivate', 'cartflows-pro' )
								: __( 'Activate', 'cartflows-pro' ) }
						</Button>
					</div>

					{ /* Error message */ }
					{ licenseErrors && (
						<p className="text-sm text-support-error">
							{ parse( licenseErrors ) }
						</p>
					) }

					{ /* Need help? link */ }
					<a
						href={ window.getUtmUrl(
							'https://cartflows.com/support/',
							{
								utm_campaign: 'license',
							}
						) }
						target="_blank"
						rel="noreferrer"
						className="text-sm font-semibold text-brand-500 hover:text-brand-600 no-underline w-fit"
					>
						{ __( 'Need help?', 'cartflows-pro' ) }
					</a>
				</div>
			</div>
		</div>
	);
}

export default LicenseSetting;
