import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import SettingTable from '@Admin/features/settings/SettingTable';

/**
 * Offer (Order) tab content — renders the pro-defined offer fields through
 * free's SettingTable so markup and the FormData save path stay identical.
 *
 * @return {JSX.Element|null} The rendered offer settings table.
 */
function OfferSettings() {
	const [ { globaldata } ] = useSettingsStateValue();
	const settings = globaldata?.settings?.offer;

	if ( ! settings?.fields ) {
		return null;
	}

	return <SettingTable settings={ settings } meta_key="" />;
}

export default OfferSettings;
