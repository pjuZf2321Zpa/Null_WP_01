import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import SettingTable from '@Admin/features/settings/SettingTable';

/**
 * Pro fields for the General settings tab (pre-checkout offer, PayPal
 * reference transactions) — rendered through free's SettingTable so markup
 * and the FormData save path stay identical.
 *
 * @return {JSX.Element|null} The rendered pro rows for the General tab.
 */
function GeneralProFields() {
	const [ { globaldata } ] = useSettingsStateValue();
	const fields = globaldata?.settings?.general?.fields || {};

	const proFields = Object.fromEntries(
		Object.entries( fields ).filter( ( [ , field ] ) => field.is_pro )
	);

	if ( ! Object.keys( proFields ).length ) {
		return null;
	}

	return (
		<SettingTable
			settings={ { fields: proFields } }
			meta_key="_cartflows_common"
		/>
	);
}

export default GeneralProFields;
