import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';
import SettingTable from '@Admin/features/settings/SettingTable';

/**
 * Pro fields for the Permalink settings tab (A/B test permalink override) —
 * rendered through free's SettingTable so markup and the FormData save path
 * stay identical.
 *
 * @return {JSX.Element|null} The rendered pro rows for the Permalink tab.
 */
function PermalinkProFields() {
	const [ { globaldata } ] = useSettingsStateValue();
	const fields = globaldata?.settings?.permalink?.fields || {};

	const proFields = Object.fromEntries(
		Object.entries( fields ).filter( ( [ , field ] ) => field.is_pro )
	);

	if ( ! Object.keys( proFields ).length ) {
		return null;
	}

	return <SettingTable settings={ { fields: proFields } } meta_key="" />;
}

export default PermalinkProFields;
