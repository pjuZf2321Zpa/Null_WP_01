import {
	useState,
	useEffect,
	useCallback,
	useMemo,
	useRef,
} from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { __ } from '@wordpress/i18n';
import {
	ClipboardIcon,
	CheckIcon,
	ArrowPathIcon,
} from '@heroicons/react/24/outline';
import { Button } from '@bsf/force-ui';
import { TextField, Select2Field } from '@Fields';

// Ordered list of address sub-fields rendered inside each address card.
const ADDRESS_FIELD_ORDER = {
	billing: [
		'billing_country',
		'billing_address_2',
		'billing_address_1',
		'billing_city',
		'billing_state',
		'billing_postcode',
	],
	shipping: [
		'shipping_country',
		'shipping_address_2',
		'shipping_address_1',
		'shipping_city',
		'shipping_state',
		'shipping_postcode',
	],
};

// Minimum characters before firing a product/coupon search — matches the
// existing ProductField pattern in admin-legacy-core.
const SEARCH_MIN_CHARS = 3;

/**
 * Search WooCommerce products via the shared `cartflows_json_search_products`
 * AJAX action. Fires only when the user types at least SEARCH_MIN_CHARS.
 *
 * @param {string} term Search input.
 * @return {Promise<Array>} Resolves to an array of `{ value, label, ... }` objects.
 */
const searchProducts = ( term ) => {
	if ( ! term || term.length < SEARCH_MIN_CHARS ) {
		return Promise.resolve( [] );
	}
	const formData = new window.FormData();
	formData.append( 'action', 'cartflows_json_search_products' );
	formData.append(
		'security',
		window.cartflows_admin?.json_search_products_nonce || ''
	);
	formData.append( 'term', term );
	return apiFetch( {
		url: window.cartflows_admin?.ajax_url,
		method: 'POST',
		body: formData,
	} ).catch( () => [] );
};

/**
 * Search WooCommerce coupons via `cartflows_json_search_coupons`.
 *
 * @param {string} term Search input.
 * @return {Promise<Array>} Resolves to an array of `{ value, label }` objects.
 */
const searchCoupons = ( term ) => {
	if ( ! term || term.length < SEARCH_MIN_CHARS ) {
		return Promise.resolve( [] );
	}
	const formData = new window.FormData();
	formData.append( 'action', 'cartflows_json_search_coupons' );
	formData.append(
		'security',
		window.cartflows_admin?.json_search_coupons_nonce || ''
	);
	formData.append( 'term', term );
	return apiFetch( {
		url: window.cartflows_admin?.ajax_url,
		method: 'POST',
		body: formData,
	} ).catch( () => [] );
};

/**
 * CheckoutLinkGenerator - A tool to visually build pre-populated checkout URLs.
 *
 * Displayed in CartFlows → Settings → Checkout Links (Pro only).
 *
 * @param {Object}      root0
 * @param {number|null} root0.preSelectedStepId
 * @param {boolean}     root0.isStoreCheckout   True when rendered inside a store checkout step.
 */
function CheckoutLinkGenerator( {
	preSelectedStepId = null,
	isStoreCheckout = false,
} ) {
	const [ steps, setSteps ] = useState( [] );
	const [ selectedStepId, setSelectedStepId ] = useState(
		preSelectedStepId || ''
	);
	const [ baseUrl, setBaseUrl ] = useState( '' );
	const [ fields, setFields ] = useState( [] );
	const [ fieldValues, setFieldValues ] = useState( {} );
	const [ selectedFields, setSelectedFields ] = useState( [] );
	const [ selectedCoupon, setSelectedCoupon ] = useState( null );
	const [ selectedProducts, setSelectedProducts ] = useState( [] );
	const [ loadingSteps, setLoadingSteps ] = useState( true );
	const [ copied, setCopied ] = useState( false );

	// Cache /fields responses per step_id — re-selecting a step reads from here.
	// Seeded from the server-side inlined map (window.cartflows_admin.checkout_link_fields)
	// so the editor step-settings context renders without a REST round-trip.
	const fieldsCache = useRef( {
		...( window.cartflows_admin?.checkout_link_fields || {} ),
	} );
	const [ refreshingFields, setRefreshingFields ] = useState( false );
	const [ refreshedAt, setRefreshedAt ] = useState( 0 );

	// Apply a fields payload to component state and mark it cached.
	const applyFields = useCallback( ( stepId, data ) => {
		fieldsCache.current[ stepId ] = data;
		setFields( data );
		const newValues = {};
		data.forEach( ( f ) => {
			newValues[ f.id ] = '';
		} );
		setFieldValues( newValues );
		setSelectedFields( [] );
	}, [] );

	// Fetch all checkout steps on mount.
	useEffect( () => {
		apiFetch( {
			path: '/cartflows-pro/v1/admin/checkout-link-data/steps',
		} )
			.then( ( data ) => {
				setSteps( data );
				setLoadingSteps( false );
				if ( preSelectedStepId ) {
					const match = data.find(
						( s ) => s.id === parseInt( preSelectedStepId, 10 )
					);
					if ( match ) {
						setBaseUrl( match.permalink );
					}
				}
			} )
			.catch( () => setLoadingSteps( false ) );
	}, [] );

	// Fetch fields whenever selected step changes; served from cache when
	// possible (either inlined by the server or fetched earlier in the session).
	useEffect( () => {
		if ( ! selectedStepId ) {
			setFields( [] );
			setFieldValues( {} );
			setSelectedFields( [] );
			setBaseUrl( '' );
			return;
		}

		const step = steps.find(
			( s ) => s.id === parseInt( selectedStepId, 10 )
		);
		if ( step ) {
			setBaseUrl( step.permalink );
		}

		const cached = fieldsCache.current[ selectedStepId ];
		if ( cached ) {
			applyFields( selectedStepId, cached );
			return;
		}

		apiFetch( {
			path: `/cartflows-pro/v1/admin/checkout-link-data/fields/${ selectedStepId }`,
		} )
			.then( ( data ) => applyFields( selectedStepId, data ) )
			.catch( () => {} );
	}, [ selectedStepId, applyFields ] );

	// Force-refresh the cached fields for the current step. Used when a custom
	// checkout field was added mid-session and the inlined snapshot is stale.
	const refreshFields = () => {
		if ( ! selectedStepId || refreshingFields ) {
			return;
		}
		setRefreshingFields( true );
		apiFetch( {
			path: `/cartflows-pro/v1/admin/checkout-link-data/fields/${ selectedStepId }`,
		} )
			.then( ( data ) => {
				applyFields( selectedStepId, data );
				setRefreshedAt( Date.now() );
			} )
			.finally( () => setRefreshingFields( false ) );
	};

	// Hide the "Synced" indicator after a short delay so it acts as
	// transient feedback rather than persistent chrome.
	useEffect( () => {
		if ( ! refreshedAt ) {
			return;
		}
		const timer = setTimeout( () => setRefreshedAt( 0 ), 2000 );
		return () => clearTimeout( timer );
	}, [ refreshedAt ] );

	// All country→states data, sourced from the country field returned by the API.
	const countriesStates = useMemo( () => {
		const countryField = fields.find( ( f ) => f.type === 'country' );
		return countryField?.states || {};
	}, [ fields ] );

	// Derive grouped options for the multiselect.
	// Address fields are collapsed into a single "Billing Address" /
	// "Shipping Address" entry; all other fields remain as individual options.
	const fieldOptions = useMemo( () => {
		const buildGroup = ( section, sectionLabel ) => {
			const hasAddressFields = fields.some(
				( f ) => f.section === section && f.group === 'address'
			);
			const nonAddressOptions = fields
				.filter(
					( f ) => f.section === section && f.group !== 'address'
				)
				.map( ( f ) => ( { label: f.label, value: f.id, section } ) );

			return {
				label: sectionLabel,
				options: [
					...( hasAddressFields
						? [
								{
									label:
										sectionLabel +
										' ' +
										__( 'Address', 'cartflows-pro' ),
									value: `__${ section }_address__`,
									type: 'address_group',
									section,
								},
						  ]
						: [] ),
					...nonAddressOptions,
				],
			};
		};

		return [
			buildGroup( 'billing', __( 'Billing', 'cartflows-pro' ) ),
			buildGroup( 'shipping', __( 'Shipping', 'cartflows-pro' ) ),
		].filter( ( g ) => g.options.length > 0 );
	}, [ fields ] );

	// Build the generated URL from selected fields and values.
	const generatedUrl = useCallback( () => {
		if ( ! baseUrl || ! selectedStepId ) {
			return '';
		}

		const params = [];

		// Regular (non-address) fields.
		selectedFields
			.filter( ( opt ) => opt.type !== 'address_group' )
			.forEach( ( opt ) => {
				const val = fieldValues[ opt.value ];
				if ( val && val.trim() !== '' ) {
					params.push(
						`${ encodeURIComponent(
							opt.value
						) }=${ encodeURIComponent( val ) }`
					);
				}
			} );

		// Address section fields — iterate in defined order.
		selectedFields
			.filter( ( opt ) => opt.type === 'address_group' )
			.forEach( ( opt ) => {
				( ADDRESS_FIELD_ORDER[ opt.section ] || [] ).forEach(
					( fieldId ) => {
						const val = fieldValues[ fieldId ];
						if ( val && val.trim() !== '' ) {
							params.push(
								`${ encodeURIComponent(
									fieldId
								) }=${ encodeURIComponent( val ) }`
							);
						}
					}
				);
			} );

		if ( selectedCoupon?.value ) {
			params.push(
				`coupon=${ encodeURIComponent( selectedCoupon.value ) }`
			);
		}

		if ( selectedProducts.length > 0 ) {
			const productIds = selectedProducts
				.map( ( p ) => p.value )
				.join( ',' );
			params.push(
				`wcf-add-to-cart=${ encodeURIComponent( productIds ) }`
			);
		}

		if ( params.length === 0 ) {
			return baseUrl;
		}

		const separator = baseUrl.includes( '?' ) ? '&' : '?';
		return `${ baseUrl }${ separator }${ params.join( '&' ) }`;
	}, [
		baseUrl,
		selectedStepId,
		selectedFields,
		fieldValues,
		selectedCoupon,
		selectedProducts,
	] );

	// When an address group is deselected, clear its sub-field values.
	const handleFieldsChange = ( val ) => {
		const next = val || [];
		const removed = selectedFields.filter(
			( opt ) =>
				opt.type === 'address_group' &&
				! next.find( ( n ) => n.value === opt.value )
		);
		if ( removed.length > 0 ) {
			const cleared = {};
			removed.forEach( ( opt ) => {
				( ADDRESS_FIELD_ORDER[ opt.section ] || [] ).forEach(
					( fieldId ) => {
						cleared[ fieldId ] = '';
					}
				);
			} );
			setFieldValues( ( prev ) => ( { ...prev, ...cleared } ) );
		}
		setSelectedFields( next );
	};

	/**
	 * Render the structured address card for a section ('billing' | 'shipping').
	 *
	 * Country is a full-country dropdown. State is a dropdown when the selected
	 * country has known states, or a plain text input otherwise. All other
	 * sub-fields are plain text inputs.
	 *
	 * @param {string} section 'billing' or 'shipping'.
	 * @return {JSX.Element} Address card element.
	 */
	const renderAddressSection = ( section ) => {
		const countryFieldId = `${ section }_country`;
		const stateFieldId = `${ section }_state`;
		const selectedCountry = fieldValues[ countryFieldId ] || '';
		// Mirror WC checkout: missing entry → text input, empty entry → hidden.
		const rawStates = selectedCountry
			? countriesStates[ selectedCountry ]
			: undefined;
		const statesForCountry = rawStates || {};
		const useTextState = selectedCountry && rawStates === undefined;
		const hideStateRow =
			rawStates !== undefined &&
			Object.keys( statesForCountry ).length === 0;

		const sectionLabel =
			section === 'billing'
				? __( 'Billing Address', 'cartflows-pro' )
				: __( 'Shipping Address', 'cartflows-pro' );

		const subFields = ( ADDRESS_FIELD_ORDER[ section ] || [] )
			.map( ( fieldId ) => fields.find( ( f ) => f.id === fieldId ) )
			.filter( Boolean );

		// Shared classes for all inputs in the address card (select + text),
		// sized to match Force UI Input size="md".
		const inputClass =
			'block w-full rounded-md border border-border-subtle bg-white px-3.5 py-2.5 text-sm text-text-primary focus:outline-none focus:ring-1 focus:ring-border-strong';
		const selectClass = inputClass;

		return (
			<div
				key={ section }
				className="mt-4 rounded-lg border border-border-subtle overflow-hidden"
			>
				{ /* Card header with bottom separator */ }
				<div className="px-4 py-3 bg-background-secondary border-b border-border-subtle">
					<span className="text-sm font-semibold text-text-primary">
						{ sectionLabel }
					</span>
				</div>

				{ /* Field rows separated by subtle dividers */ }
				<div className="divide-y divide-border-subtle">
					{ subFields.map( ( fieldDef ) => {
						const fieldId = fieldDef.id;
						const isCountry = fieldDef.type === 'country';
						const isState = fieldId === stateFieldId;

						if ( isState && hideStateRow ) {
							return null;
						}

						return (
							<div
								key={ fieldId }
								className="flex items-center gap-4 px-4 py-3"
							>
								<label
									htmlFor={ `wcf_clg_${ fieldId }` }
									className="w-36 shrink-0 text-sm text-text-secondary"
								>
									{ fieldDef.label }
								</label>
								<div className="flex-1 min-w-0">
									{ isCountry && (
										<select
											id={ `wcf_clg_${ fieldId }` }
											className={ `${ selectClass } max-w-full` }
											value={
												fieldValues[ fieldId ] || ''
											}
											onChange={ ( e ) => {
												handleValueChange(
													fieldId,
													e.target.value
												);
												// Reset state when country changes.
												handleValueChange(
													stateFieldId,
													''
												);
											} }
										>
											<option value="">
												{ __(
													'Select Country',
													'cartflows-pro'
												) }
											</option>
											{ Object.entries(
												fieldDef.options
											).map( ( [ code, name ] ) => (
												<option
													key={ code }
													value={ code }
												>
													{ name }
												</option>
											) ) }
										</select>
									) }
									{ isState && useTextState && (
										<input
											type="text"
											id={ `wcf_clg_${ fieldId }` }
											name={ `wcf_clg_${ fieldId }` }
											className={ inputClass }
											value={
												fieldValues[ fieldId ] || ''
											}
											placeholder={ __(
												'Enter State / County',
												'cartflows-pro'
											) }
											onChange={ ( e ) =>
												handleValueChange(
													fieldId,
													e.target.value
												)
											}
										/>
									) }
									{ isState && ! useTextState && (
										<select
											id={ `wcf_clg_${ fieldId }` }
											className={ `${ selectClass } max-w-full disabled:opacity-50 disabled:cursor-not-allowed` }
											value={
												fieldValues[ fieldId ] || ''
											}
											disabled={ ! selectedCountry }
											onChange={ ( e ) =>
												handleValueChange(
													fieldId,
													e.target.value
												)
											}
										>
											<option value="">
												{ ! selectedCountry
													? __(
															'Select a country first',
															'cartflows-pro'
													  )
													: __(
															'Select State',
															'cartflows-pro'
													  ) }
											</option>
											{ Object.entries(
												statesForCountry
											).map( ( [ code, name ] ) => (
												<option
													key={ code }
													value={ code }
												>
													{ name }
												</option>
											) ) }
										</select>
									) }
									{ ! isCountry && ! isState && (
										<input
											type="text"
											id={ `wcf_clg_${ fieldId }` }
											name={ `wcf_clg_${ fieldId }` }
											className={ inputClass }
											value={
												fieldValues[ fieldId ] || ''
											}
											placeholder={ __(
												'Enter value',
												'cartflows-pro'
											) }
											onChange={ ( e ) =>
												handleValueChange(
													fieldId,
													e.target.value
												)
											}
										/>
									) }
								</div>
							</div>
						);
					} ) }
				</div>
			</div>
		);
	};

	const handleCopy = () => {
		const url = generatedUrl();
		if ( ! url ) {
			return;
		}
		if ( window.navigator.clipboard ) {
			window.navigator.clipboard.writeText( url ).then( () => {
				setCopied( true );
				setTimeout( () => setCopied( false ), 2000 );
			} );
		} else {
			// Fallback for non-secure (HTTP) contexts.
			const textarea = document.createElement( 'textarea' );
			textarea.value = url;
			textarea.style.position = 'fixed';
			textarea.style.opacity = '0';
			document.body.appendChild( textarea );
			textarea.select();
			document.execCommand( 'copy' );
			document.body.removeChild( textarea );
			setCopied( true );
			setTimeout( () => setCopied( false ), 2000 );
		}
	};

	const handleValueChange = ( fieldId, value ) => {
		setFieldValues( ( prev ) => ( { ...prev, [ fieldId ]: value } ) );
	};

	/**
	 * Render a label + input row for a selected field.
	 *
	 * Country fields render a <select> populated from the WC countries list
	 * returned by the REST API. All other fields render a plain text input.
	 *
	 * @param {string} fieldId The field key used as the URL parameter name.
	 * @param {string} label   Human-readable field label.
	 * @param {string} section Field section — 'billing' or 'shipping'.
	 * @return {JSX.Element} A form row element.
	 */
	const renderFieldRow = ( fieldId, label, section ) => {
		const fieldDef = fields.find( ( f ) => f.id === fieldId );
		const isCountry =
			fieldDef?.type === 'country' &&
			fieldDef?.options &&
			Object.keys( fieldDef.options ).length > 0;

		return (
			<div
				key={ fieldId }
				className="wcf-field__data flex items-center gap-6 py-5 border-0"
			>
				<div className="wcf-field__data--content-left flex-[0_0_35%]">
					<label
						htmlFor={ `wcf_clg_${ fieldId }` }
						className="text-sm font-medium text-text-primary"
					>
						{ label }
					</label>
					{ section && (
						<span className="block text-xs text-text-secondary mt-0.5">
							{ section === 'billing'
								? __( 'Billing', 'cartflows-pro' )
								: __( 'Shipping', 'cartflows-pro' ) }
						</span>
					) }
				</div>
				<div
					className={ `wcf-field__data--content-right flex-1 ${
						preSelectedStepId ? '' : '!ml-5'
					}` }
				>
					{ isCountry ? (
						<select
							id={ `wcf_clg_${ fieldId }` }
							name={ `wcf_clg_${ fieldId }` }
							className="input-field !pl-3.5 !pr-6 !py-2.5 !text-sm font-normal !rounded-md text-text-primary !border-border-subtle w-full"
							value={ fieldValues[ fieldId ] || '' }
							onChange={ ( e ) =>
								handleValueChange( fieldId, e.target.value )
							}
						>
							<option value="">
								{ __( 'Select Country', 'cartflows-pro' ) }
							</option>
							{ Object.entries( fieldDef.options ).map(
								( [ code, name ] ) => (
									<option key={ code } value={ code }>
										{ name }
									</option>
								)
							) }
						</select>
					) : (
						<TextField
							name={ `wcf_clg_${ fieldId }` }
							id={ `wcf_clg_${ fieldId }` }
							value={ fieldValues[ fieldId ] || '' }
							placeholder={ __( 'Enter value', 'cartflows-pro' ) }
							onChangeCB={ ( val ) =>
								handleValueChange( fieldId, val )
							}
							sectionClass="!p-0"
							wrapperClass="block w-full"
						/>
					) }
				</div>
			</div>
		);
	};

	// Message shown inside the picker when there's nothing to display —
	// prompts the user to type before showing "no results".
	const asyncNoOptions = ( { inputValue } ) => {
		if ( ! inputValue || inputValue.length < SEARCH_MIN_CHARS ) {
			return __( 'Type to search…', 'cartflows-pro' );
		}
		return __( 'No results found', 'cartflows-pro' );
	};

	return (
		<div className="wcf-checkout-link-generator">
			{ /* Step Selector — hidden when a step is pre-selected (e.g. from step settings) */ }
			{ ! preSelectedStepId && (
				<div className="wcf-field__data flex items-start gap-6 mb-6">
					<div className="wcf-field__data--content-left flex-[0_0_35%]">
						<label className="text-sm font-medium text-text-primary">
							{ __( 'Checkout Step', 'cartflows-pro' ) }
						</label>
						<p className="text-sm font-normal text-text-secondary mt-2">
							{ __(
								'Choose the checkout page to build a link for.',
								'cartflows-pro'
							) }
						</p>
					</div>
					<div className="wcf-field__data--content-right flex-1">
						{ loadingSteps ? (
							<div className="animate-pulse h-9 bg-background-secondary rounded-md w-full" />
						) : (
							<select
								className="input-field !pl-3 !pr-6 !py-2 !text-sm font-normal !rounded-md text-text-primary !border-border-subtle w-full"
								value={ selectedStepId }
								onChange={ ( e ) =>
									setSelectedStepId( e.target.value )
								}
							>
								<option value="">
									{ __(
										'— Select a Step —',
										'cartflows-pro'
									) }
								</option>
								{ steps.map( ( step ) => (
									<option key={ step.id } value={ step.id }>
										{ step.title }
									</option>
								) ) }
							</select>
						) }
					</div>
				</div>
			) }

			{ selectedStepId && (
				<>
					<hr className="border-0 border-t border-solid border-border-subtle mb-6" />

					{ /* Single grouped multiselect for billing + shipping */ }
					<div className="wcf-field__data flex items-start gap-6 mb-2">
						<div className="wcf-field__data--content-left flex-[0_0_35%]">
							<div className="flex items-center gap-1">
								<label className="text-sm font-medium text-text-primary">
									{ __( 'Select Fields', 'cartflows-pro' ) }
								</label>
								<Button
									variant="ghost"
									size="xs"
									icon={
										<ArrowPathIcon
											className={
												refreshingFields
													? 'animate-spin'
													: ''
											}
										/>
									}
									onClick={ refreshFields }
									disabled={ refreshingFields }
									aria-label={ __(
										'Refresh field list',
										'cartflows-pro'
									) }
									title={ __(
										'Refresh field list (picks up newly added custom checkout fields).',
										'cartflows-pro'
									) }
								/>
								{ refreshedAt > 0 && (
									<span
										role="status"
										aria-live="polite"
										className="text-xs font-medium text-support-success transition-opacity"
									>
										{ __( 'Synced', 'cartflows-pro' ) }
									</span>
								) }
							</div>
							<p className="text-sm font-normal text-text-secondary mt-2">
								{ __(
									'Select the checkout fields to include in the URL.',
									'cartflows-pro'
								) }
							</p>
						</div>
						<div className="wcf-field__data--content-right flex-1">
							<Select2Field
								name="wcf_clg_fields"
								isMulti={ true }
								isSearchable={ true }
								options={ fieldOptions }
								value={ selectedFields }
								placeholder={ __(
									'Select fields…',
									'cartflows-pro'
								) }
								onChangeCB={ handleFieldsChange }
								className="!m-0"
							/>
						</div>
					</div>

					{ /* Value inputs for selected fields */ }
					{ selectedFields.length > 0 && (
						<div className="mb-4 border-t border-border-subtle pb-4">
							{ selectedFields
								.filter(
									( opt ) => opt.type !== 'address_group'
								)
								.map( ( opt ) =>
									renderFieldRow(
										opt.value,
										opt.label,
										opt.section
									)
								) }
							{ selectedFields
								.filter(
									( opt ) => opt.type === 'address_group'
								)
								.map( ( opt ) =>
									renderAddressSection( opt.section )
								) }
						</div>
					) }

					<hr className="border-0 border-t border-solid border-border-subtle mb-4" />

					{ /* Coupon — searched on demand */ }
					<div className="wcf-field__data flex items-start gap-6 mb-6">
						<div className="wcf-field__data--content-left flex-[0_0_35%]">
							<label className="text-sm font-medium text-text-primary">
								{ __( 'Coupon', 'cartflows-pro' ) }
							</label>
							<p className="text-sm font-normal text-text-secondary mt-2">
								{ __(
									'Search a coupon to apply at checkout.',
									'cartflows-pro'
								) }
							</p>
						</div>
						<div className="wcf-field__data--content-right flex-1">
							<Select2Field
								name="wcf_clg_coupon"
								isSearchable={ true }
								value={ selectedCoupon }
								placeholder={ __(
									'Type at least 3 characters to search…',
									'cartflows-pro'
								) }
								onChangeCB={ ( val ) =>
									setSelectedCoupon( val || null )
								}
								attr={ {
									loadOptions: searchCoupons,
									defaultOptions: false,
									noOptionsMessage: asyncNoOptions,
								} }
							/>
						</div>
					</div>

					{ /* Select Products — store checkout only */ }
					{ isStoreCheckout && (
						<>
							<hr className="border-0 border-t border-solid border-border-subtle mb-4" />
							<div className="wcf-field__data flex items-start gap-6 mb-6">
								<div className="wcf-field__data--content-left flex-[0_0_35%]">
									<label className="text-sm font-medium text-text-primary">
										{ __(
											'Select Products',
											'cartflows-pro'
										) }
									</label>
									<p className="text-sm font-normal text-text-secondary mt-2">
										{ __(
											'Search products to add to the cart when this checkout link is visited. Selected products will be added to the cart automatically when the link is opened.',
											'cartflows-pro'
										) }
									</p>
								</div>
								<div className="wcf-field__data--content-right flex-1">
									<Select2Field
										name="wcf_clg_products"
										isMulti={ true }
										isSearchable={ true }
										value={ selectedProducts }
										placeholder={ __(
											'Type at least 3 characters to search…',
											'cartflows-pro'
										) }
										onChangeCB={ ( val ) =>
											setSelectedProducts( val || [] )
										}
										attr={ {
											loadOptions: searchProducts,
											defaultOptions: false,
											noOptionsMessage: asyncNoOptions,
										} }
									/>
								</div>
							</div>
						</>
					) }

					<hr className="border-0 border-t border-solid border-border-subtle mb-6" />

					{ /* Checkout URL */ }
					<div className="wcf-field__data flex items-start gap-6 mb-4">
						<div className="wcf-field__data--content-left flex-[0_0_35%]">
							<label className="text-sm font-medium text-text-primary">
								{ __( 'Checkout URL', 'cartflows-pro' ) }
							</label>
						</div>
						<div className="wcf-field__data--content-right flex-1">
							<textarea
								className="w-full input-field font-mono !text-xs !text-text-secondary !py-3 !px-3 !border-border-subtle !rounded-md bg-background-secondary"
								rows={ 4 }
								readOnly
								value={ generatedUrl() }
							/>
						</div>
					</div>

					{ /* Copy URL Button */ }
					<div className="flex justify-end">
						<Button
							type="button"
							variant="outline"
							size="sm"
							icon={
								copied ? (
									<CheckIcon className="w-4 h-4" />
								) : (
									<ClipboardIcon className="w-4 h-4" />
								)
							}
							iconPosition="left"
							onClick={ handleCopy }
						>
							{ copied
								? __( 'Copied!', 'cartflows-pro' )
								: __( 'Copy URL', 'cartflows-pro' ) }
						</Button>
					</div>
				</>
			) }
		</div>
	);
}

export default CheckoutLinkGenerator;
