/**
 * Upgrade notice Pro registration.
 * Turns free's "Upgrade to PRO" nudge into a license-activation CTA when the license is inactive.
 */
import { __ } from '@wordpress/i18n';
import { addFilter } from '@wordpress/hooks';
import { isProActive, isLicenseActivated } from '@ProUtils/plan';

addFilter(
	'cartflows.upgradeNotice.content',
	'cartflows-pro/upgrade-notice/content',
	( notice ) => {
		const isAnalyticsScreen =
			'analytics' ===
			new URLSearchParams( window.location.search ).get( 'path' );
		if ( ! isProActive() || isLicenseActivated() || ! isAnalyticsScreen ) {
			return notice;
		}

		// Keep free's page-specific copy — only the CTA swaps to license activation.
		return {
			...notice,
			ctaLabel: __( 'Activate License', 'cartflows-pro' ),
			ctaHref: window.cartflows_admin?.license_popup_url,
		};
	}
);
