import { __ } from '@wordpress/i18n';
import { Button, Text, Container } from '@bsf/force-ui';
import { RotateCcw } from 'lucide-react';

function StepsAnalyticsFooter( { onReset, isResetting } ) {
	return (
		<Container
			containerType="flex"
			justify="between"
			align="center"
			gap="none"
		>
			<Text as="p" size={ 13 } color="secondary" className="m-0">
				<Text
					as="span"
					size={ 13 }
					weight={ 500 }
					className="text-brand-500"
				>
					{ __( 'Note:', 'cartflows-pro' ) }
				</Text>{ ' ' }
				{ __(
					'The orders which are placed by the admins are not considered while calculating the analytics.',
					'cartflows-pro'
				) }
			</Text>
			<Button
				variant="outline"
				size="sm"
				onClick={ onReset }
				loading={ isResetting }
				disabled={ isResetting }
				icon={
					<RotateCcw
						className={ `w-4 h-4${
							isResetting ? ' animate-spin' : ''
						}` }
						strokeWidth={ 2 }
					/>
				}
				iconPosition="left"
			>
				{ isResetting
					? __( 'Resetting', 'cartflows-pro' )
					: __( 'Reset Analytics', 'cartflows-pro' ) }
			</Button>
		</Container>
	);
}

export default StepsAnalyticsFooter;
