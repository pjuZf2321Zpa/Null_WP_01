import { addFilter } from '@wordpress/hooks';
import { isProPlan } from '@ProUtils/plan';
import StepsAnalyticsProView from './StepsAnalyticsProView';

addFilter(
	'cartflows.flowEditor.stepsAnalytics',
	'cartflows-pro/flow-editor/steps-analytics',
	( current ) => ( isProPlan() ? StepsAnalyticsProView : current )
);
