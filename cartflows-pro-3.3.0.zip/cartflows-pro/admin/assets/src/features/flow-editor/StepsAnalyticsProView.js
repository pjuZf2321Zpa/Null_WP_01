import { useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';
import { formatDateWithoutTimezone } from '@ProUtils/date';
import StepsAnalyticsHeader from '@Features/flow-editor/components/steps-page/StepsAnalyticsHeader';
import StepsAnalyticsKpis from '@Features/flow-editor/components/steps-page/StepsAnalyticsKpis';
import StepsAnalyticsTable from '@Features/flow-editor/components/steps-page/StepsAnalyticsTable';
import StepsAnalyticsFooter from '@ProFeatures/flow-editor/StepsAnalyticsFooter';

/**
 * Real per-step analytics view for the flow editor / store checkout screen.
 *
 * @param {Object}   props                   Component props.
 * @param {Function} props.onBack            Returns to the steps list.
 * @param {number}   props.flowId            Current flow ID.
 * @param {Object}   props.flowAnalytics     Analytics data from the free editor store.
 * @param {Function} props.onAnalyticsChange Stores refetched analytics in the free editor store.
 * @return {Object} Steps analytics view.
 */
function StepsAnalyticsProView( {
	onBack,
	flowId,
	flowAnalytics,
	onAnalyticsChange,
} ) {
	const today = new Date();
	const weekAgo = new Date();
	weekAgo.setDate( today.getDate() - 7 );
	const [ fromDate, setFromDate ] = useState( weekAgo );
	const [ toDate, setToDate ] = useState( today );
	const [ loadingAnalytics, setLoadingAnalytics ] = useState( false );
	const [ isResetting, setIsResetting ] = useState( false );

	const revenue = flowAnalytics?.revenue;
	const allSteps = flowAnalytics?.all_steps;
	const totalVisitors =
		allSteps?.reduce(
			( sum, step ) => sum + ( Number( step.visits?.total_visits ) || 0 ),
			0
		) || 0;

	const handleDateRangeChange = ( { startDate, endDate } ) => {
		setFromDate( startDate );
		setToDate( endDate );
		if ( ! startDate || ! endDate ) {
			return;
		}
		setLoadingAnalytics( true );
		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_pro_set_visit_data' );
		formData.append( 'security', cartflows_admin.set_visit_data_nonce );
		formData.append( 'flow_id', flowId );
		formData.append( 'date_from', formatDateWithoutTimezone( startDate ) );
		formData.append( 'date_to', formatDateWithoutTimezone( endDate ) );
		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( data ) => {
			setLoadingAnalytics( false );
			onAnalyticsChange( data );
		} );
	};

	const handleReset = () => {
		setIsResetting( true );
		const formData = new window.FormData();
		formData.append( 'action', 'cartflows_pro_reset_flow_analytics' );
		formData.append(
			'security',
			cartflows_admin.reset_flow_analytics_nonce
		);
		formData.append( 'flow_id', flowId );
		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( () => {
			setIsResetting( false );
			window.location.reload();
		} );
	};

	return (
		<>
			<StepsAnalyticsHeader
				fromDate={ fromDate }
				toDate={ toDate }
				onBack={ onBack }
				onDateChange={ handleDateRangeChange }
				showDateFilter={ true }
			/>
			<StepsAnalyticsKpis
				revenue={ revenue }
				totalVisitors={ totalVisitors }
				loading={ loadingAnalytics }
			/>
			<StepsAnalyticsTable allSteps={ allSteps } />
			<StepsAnalyticsFooter
				onReset={ handleReset }
				isResetting={ isResetting }
			/>
		</>
	);
}

export default StepsAnalyticsProView;
