import { addFilter } from '@wordpress/hooks';
import { isProActive } from '@ProUtils/plan';
import ProductOptions from './ProductOptions';
import DynamicOffers from './DynamicOffers';
import { createCustomFieldActions } from './customFieldActions';
import { createOptinFieldActions } from './optinFieldActions';

addFilter(
	'cartflows.stepSettings.productOptions',
	'cartflows-pro/step-settings/product-options',
	( current ) => ( isProActive() ? ProductOptions : current )
);

addFilter(
	'cartflows.stepSettings.dynamicOffers',
	'cartflows-pro/step-settings/dynamic-offers',
	( current ) => ( isProActive() ? DynamicOffers : current )
);

addFilter(
	'cartflows.stepSettings.customFieldActions',
	'cartflows-pro/step-settings/custom-field-actions',
	( current ) => ( isProActive() ? createCustomFieldActions : current )
);

addFilter(
	'cartflows.stepSettings.optinFieldActions',
	'cartflows-pro/step-settings/optin-field-actions',
	( current ) => ( isProActive() ? createOptinFieldActions : current )
);
