import { __ } from '@wordpress/i18n';
import { Trash2 } from 'lucide-react';
import { Badge, Button } from '@bsf/force-ui';
import { useStateValue } from '@Utils/StateProvider';
import {
	SelectField,
	TextField,
	ProductField,
	NumberField,
	CouponField,
	SearchSelectField,
	MultiText,
	OrderBumpField,
} from '@Fields';
import parse from 'html-react-parser';
function RuleRepeater( { rules, group_id, g_index, groups_length } ) {
	const [ { page_settings }, dispatch ] = useStateValue();

	const rule_settings = page_settings?.settings.rules;
	const conditions_select = rule_settings?.conditions;

	const removeRule = ( event ) => {
		const rule_id = event.target.getAttribute( 'rule_id' );

		if ( group_id && rule_id ) {
			dispatch( {
				type: 'REMOVE_RULE',
				name: 'wcf-checkout-rules',
				rule_id,
				group_id,
			} );
		}
	};

	const valueFields = function ( fields, r_index, rule_data ) {
		const value = rule_data.value;

		let rendorfields = '';
		const name = `wcf-checkout-rules[${ g_index }][rules][${ r_index }][value]`;

		return (
			fields &&
			fields?.map( ( field ) => {
				switch ( field.type ) {
					case 'multitext':
						rendorfields = (
							<MultiText
								name={ `${ name }` }
								value={ value }
								fields={ field.fields }
							/>
						);
						break;

					case 'text':
						rendorfields = (
							<TextField
								name={ `${ name }` }
								value={ value }
								placeholder={ field.placeholder }
								tooltip={ field.tooltip }
								contentClass="w-full"
							/>
						);
						break;

					case 'select2':
						rendorfields = (
							<SearchSelectField
								name={ `${ name }[]` }
								value={ value }
								placeholder={ field.placeholder }
								tooltip={ field.tooltip }
								options={ field.options }
								isMulti={ field.isMulti }
								isSearchable={ field?.enable_search }
								sectionClass={ 'col-span-full' }
							/>
						);
						break;

					case 'number':
						rendorfields = (
							<NumberField
								name={ name }
								value={ value }
								min={ 0 }
								placeholder={ field.placeholder }
								tooltip={ field.tooltip }
							/>
						);
						break;

					case 'coupon':
						if (
							'exist' === rule_data.operator ||
							'not_exist' === rule_data.operator
						) {
							rendorfields = (
								<SelectField
									name={ name }
									options={ [
										{
											label: 'in parent order',
											value: 'parent_order',
										},
									] }
									sectionClass={ 'col-span-full' }
								/>
							);
						} else {
							rendorfields = (
								<CouponField
									name={ name }
									placeholder={ field.placeholder }
									tooltip={ field.tooltip }
									value={ value }
									isMulti={ field.isMulti }
									sectionClass={ 'col-span-full' }
								/>
							);
						}
						break;

					case 'product':
						rendorfields = (
							<ProductField
								name={ name }
								placeholder={ field.placeholder }
								tooltip={ field.tooltip }
								value={ value }
								isMulti={ field.isMulti }
								sectionClass={ 'col-span-full' }
								showLabelOnly={ true }
							/>
						);
						break;

					case 'order_bump':
						rendorfields = (
							<OrderBumpField
								name={ name }
								placeholder={ field.placeholder }
								tooltip={ field.tooltip }
								value={ value }
								isMulti={ field.isMulti }
								sectionClass={ 'col-span-full' }
							/>
						);
						break;
				}
				return rendorfields;
			} )
		);
	};

	const removeRuleIcon = function ( rules_length, rule_id ) {
		if ( 1 === rules_length && 1 === groups_length ) {
			return '';
		}
		return (
			<Button
				variant="ghost"
				size="xs"
				icon={
					<Trash2 className="w-4 h-4 stroke-2 text-text-tertiary" />
				}
				className="!p-1 hover:!bg-background-secondary [&_svg]:hover:text-brand-700"
				onClick={ ( e ) => {
					e.currentTarget.setAttribute( 'rule_id', rule_id );
					removeRule( {
						target: e.currentTarget,
					} );
				} }
				rule_id={ rule_id }
			/>
		);
	};

	const getRuleFieldsClassName = ( fields = [] ) => {
		const hasWideField = fields.some( ( field ) =>
			[ 'product', 'order_bump', 'select2', 'coupon' ].includes(
				field.type
			)
		);

		return (
			'wcf-checkout-rules--rule_fields ' +
			'flex flex-col justify-center items-end sm:grid gap-3 w-full ' +
			( hasWideField ? 'sm:grid-cols-2' : 'sm:grid-cols-3' )
		);
	};

	return (
		<>
			{ rules.map( ( rule, r_index ) => {
				const rule_id = rule?.rule_id;
				const rule_data = rules[ r_index ];
				const rule_field_data =
					rule_settings?.field_data[ rule_data.condition ];
				// Fall back to the first available operator when the saved
				// value is empty (e.g. newly added rule). The legacy native
				// <select> auto-selected the first option; Force UI's <Select>
				// renders blank for empty values, so resolve here instead.
				const operatorOptions = rule_field_data?.operator || [];
				const resolvedOperator =
					rule_data.operator || operatorOptions[ 0 ]?.value || '';
				const replaceOperator = String( resolvedOperator )
					.replace( /</g, '&lt;' )
					.replace( />/g, '&gt;' );
				const ruleFieldsClassName = getRuleFieldsClassName(
					rule_field_data?.fields
				);
				return (
					<>
						{ 0 !== r_index && (
							<div className="wcf-checkout-rules--group_rules__condition-label">
								<div className="wcf--condition-label__and_group relative">
									<div
										className="absolute inset-0 flex items-center"
										aria-hidden="true"
									>
										<div className="w-full border-t border-border-subtle border-dashed" />
									</div>
									<div className="relative flex justify-center">
										<Badge
											variant="neutral"
											type="rounded"
											size="xs"
											label={ __(
												'AND',
												'cartflows-pro'
											) }
											className="wcf--condition-label__and_group__text"
										/>
									</div>
								</div>
							</div>
						) }
						<div
							className="wcf-checkout-rules--group_rules flex gap-3 items-center"
							data-rule-id={ rule_id }
							key={ rule_id }
						>
							<input
								type="hidden"
								name={ `wcf-checkout-rules[${ g_index }][rules][${ r_index }][rule_id]` }
								value={ rule_id }
							/>

							<div className={ ruleFieldsClassName }>
								<SelectField
									name={ `wcf-checkout-rules[${ g_index }][rules][${ r_index }][condition]` }
									wrapperClass="block"
									options={ conditions_select }
									onSelect={ () => {
										dispatch( {
											type: 'RESET_RULE_VALUE',
											name: 'wcf-checkout-rules',
											group_id,
											rule_id,
										} );
									} }
									value={ rule_data.condition }
									sectionClass="w-full sm:!w-auto"
								/>

								<SelectField
									name={ `wcf-checkout-rules[${ g_index }][rules][${ r_index }][operator]` }
									wrapperClass="block"
									options={ rule_field_data?.operator }
									value={ parse( replaceOperator ) }
									sectionClass="w-full sm:!w-auto"
								/>

								{ valueFields(
									rule_field_data?.fields,
									r_index,
									rule_data
								) }
							</div>
							<div className="wcf-checkout-rules--rule_actions">
								{ removeRuleIcon( rules.length, rule_id ) }
							</div>
						</div>
					</>
				);
			} ) }
		</>
	);
}

export default RuleRepeater;
