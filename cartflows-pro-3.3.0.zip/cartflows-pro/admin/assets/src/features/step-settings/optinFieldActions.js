import apiFetch from '@wordpress/api-fetch';
import { __ } from '@wordpress/i18n';

/**
 * Build the optin custom-field editor handlers consumed by free's
 * OptinFormFields. Free injects dispatch/toast/state so store updates
 * and toasts stay in its bundle.
 *
 * @param {Object}   ctx               Handler context.
 * @param {number}   ctx.stepId        Optin step ID.
 * @param {Function} ctx.dispatch      Free editor store dispatch.
 * @param {Object}   ctx.toast         Free force-ui toast instance.
 * @param {Array}    ctx.billingFields Current billing fields.
 * @param {Object}   ctx.options       Step options.
 * @return {Object} { removeField, addNewField }.
 */
export function createOptinFieldActions( {
	stepId,
	dispatch,
	toast,
	billingFields,
	options,
} ) {
	const addNewField = ( event, closePopup, setText ) => {
		event.preventDefault();

		const type = document.getElementsByClassName( 'wcf-cpf-type' )[ 0 ],
			label = document.getElementsByClassName( 'wcf-cpf-label' )[ 0 ],
			field_id = document.getElementsByClassName( 'wcf-cpf-name' )[ 0 ],
			_default =
				document.getElementsByClassName( 'wcf-cpf-default' )[ 0 ],
			placeholder = document.getElementsByClassName(
				'wcf-cpf-placeholder'
			)[ 0 ],
			minValue = document.getElementsByClassName( 'wcf-cpf-min' )[ 0 ],
			maxValue = document.getElementsByClassName( 'wcf-cpf-max' )[ 0 ],
			_options =
				document.getElementsByClassName( 'wcf-cpf-options' )[ 0 ],
			minDate =
				document.getElementsByClassName( 'wcf-cpf-min-date' )[ 0 ],
			maxDate =
				document.getElementsByClassName( 'wcf-cpf-max-date' )[ 0 ],
			width = document.getElementsByClassName( 'wcf-cpf-width' )[ 0 ],
			show_in_email = document.getElementsByClassName(
				'wcf-cpf-show-in-email'
			)[ 1 ],
			required =
				document.getElementsByClassName( 'wcf-cpf-required' )[ 1 ],
			dateInputField =
				document.getElementsByClassName( 'wcf-cpf-date-input' )[ 0 ],
			dateInputValue = dateInputField ? dateInputField.value : '';

		if ( '' === label.value ) {
			const span = document.createElement( 'span' );
			span.className = 'text-xs text-brand-500';
			span.textContent = __( 'Label is required field', 'cartflows-pro' );
			document
				.querySelector( '.wcf-cpf-label' )
				.insertAdjacentElement( 'afterend', span );
			label.focus();
			setText( __( 'Add New Field', 'cartflows-pro' ) );
			return false;
		}

		const formData = new FormData();

		formData.append( 'add_to', 'billing' );
		formData.append( 'type', type ? type.value : '' );
		formData.append( 'label', label ? label.value : '' );
		formData.append( 'name', field_id ? field_id.value : '' );
		formData.append( 'default', _default ? _default.value : '' );
		formData.append( 'placeholder', placeholder ? placeholder.value : '' );
		formData.append( 'options', _options ? _options.value : '' );
		formData.append( 'min', minValue ? minValue.value : '' );
		formData.append( 'max', maxValue ? maxValue.value : '' );
		formData.append( 'width', width ? width.value : '' );
		formData.append( 'min_date', minDate ? minDate.value : '' );
		formData.append( 'max_date', maxDate ? maxDate.value : '' );
		formData.append(
			'show_in_email',
			show_in_email ? show_in_email.value : ''
		);
		formData.append(
			'date_input',
			dateInputValue ? dateInputValue : 'datetime-local'
		);
		formData.append( 'required', required ? required.value : '' );
		formData.append( 'action', 'cartflows_pro_prepare_custom_field' );
		formData.append(
			'security',
			cartflows_admin.prepare_custom_field_nonce
		);

		formData.append( 'post_id', stepId );
		formData.append( 'save_field_name', 'wcf-optin-fields-' );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( response ) => {
			if ( response.success ) {
				const response_data = response.data;
				const field_data = response_data.field_data;

				if ( 'billing' === response_data.add_to ) {
					billingFields.push( field_data );

					const fields = options[ 'wcf-optin-fields-billing' ];
					fields[ response_data.new_field.key ] =
						response_data.new_field;

					dispatch( {
						type: 'SET_OPTION',
						name: 'wcf-optin-fields-billing',
						value: fields,
					} );

					dispatch( {
						type: 'SET_FIELDS',
						field_type: 'billing',
						fields: billingFields,
					} );
				}
				toast.success( __( 'Custom field added!', 'cartflows-pro' ) );
			}
			closePopup();
		} );
	};

	const removeField = ( event ) => {
		event.preventDefault();
		const formData = new FormData();

		const data_key = event.target.getAttribute( 'data-key' );
		const data_type = event.target.getAttribute( 'data-type' );

		formData.append( 'action', 'cartflows_pro_delete_custom_field' );
		formData.append(
			'security',
			cartflows_admin.delete_custom_field_nonce
		);
		formData.append( 'post_id', stepId );
		formData.append( 'key', data_key );
		formData.append( 'type', data_type );
		formData.append( 'step', 'optin' );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( data ) => {
			if ( data.status ) {
				dispatch( {
					type: 'SET_FIELDS',
					field_type: 'billing',
					fields: billingFields.filter(
						( field ) => field.key !== data_key
					),
				} );
				toast.success( __( 'Custom field deleted!', 'cartflows-pro' ) );
			}
		} );
	};

	return { removeField, addNewField };
}
