import apiFetch from '@wordpress/api-fetch';
import { __, sprintf } from '@wordpress/i18n';

/**
 * Build the checkout custom-field editor handlers consumed by free's
 * CheckoutFormSection. Free injects confirm/dispatch/state so the dialog
 * and store updates stay in its bundle.
 *
 * @param {Object}   ctx                Handler context.
 * @param {number}   ctx.stepId         Checkout step ID.
 * @param {Function} ctx.dispatch       Free editor store dispatch.
 * @param {Function} ctx.confirm        Free confirm dialog.
 * @param {Array}    ctx.billingFields  Current billing fields.
 * @param {Array}    ctx.shippingFields Current shipping fields.
 * @param {Object}   ctx.options        Step options.
 * @return {Object} { removeField, addNewField }.
 */
export function createCustomFieldActions( {
	stepId,
	dispatch,
	confirm,
	billingFields,
	shippingFields,
	options,
} ) {
	const removeField = async ( event, setDeleteCpfField ) => {
		event.preventDefault();
		const isconfirm = await confirm( {
			title: __( 'Delete Field', 'cartflows-pro' ),
			description: __(
				'Are you really want to delete field?',
				'cartflows-pro'
			),
			actionBtnText: __( 'Delete', 'cartflows-pro' ),
			cancelBtnText: __( 'Cancel', 'cartflows-pro' ),
		} );
		if ( ! isconfirm ) {
			return;
		}
		const formData = new FormData();
		const data_key = event.target.getAttribute( 'data-key' );
		const data_type = event.target.getAttribute( 'data-type' );
		setDeleteCpfField( data_key );
		formData.append( 'action', 'cartflows_pro_delete_custom_field' );
		formData.append(
			'security',
			cartflows_admin.delete_custom_field_nonce
		);
		formData.append( 'post_id', stepId );
		formData.append( 'key', data_key );
		formData.append( 'type', data_type );
		formData.append( 'step', 'checkout' );
		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( data ) => {
			if ( data.status ) {
				dispatch( {
					type: 'SET_FIELDS',
					field_type: 'billing',
					fields: billingFields.filter( ( f ) => f.key !== data_key ),
				} );
				dispatch( {
					type: 'SET_FIELDS',
					field_type: 'shipping',
					fields: shippingFields.filter(
						( f ) => f.key !== data_key
					),
				} );
				setDeleteCpfField( '' );
			}
		} );
	};

	const addNewField = ( event, closePopup, setText ) => {
		event.preventDefault();
		const add_to = document.getElementsByClassName( 'wcf-cpf-add_to' )[ 0 ],
			type = document.getElementsByClassName( 'wcf-cpf-type' )[ 0 ],
			label = document.getElementsByClassName( 'wcf-cpf-label' )[ 0 ],
			field_id = document.getElementsByClassName( 'wcf-cpf-name' )[ 0 ],
			minValue = document.getElementsByClassName( 'wcf-cpf-min' )[ 0 ],
			maxValue = document.getElementsByClassName( 'wcf-cpf-max' )[ 0 ],
			_default =
				document.getElementsByClassName( 'wcf-cpf-default' )[ 0 ],
			placeholder = document.getElementsByClassName(
				'wcf-cpf-placeholder'
			)[ 0 ],
			_options =
				document.getElementsByClassName( 'wcf-cpf-options' )[ 0 ],
			minDate =
				document.getElementsByClassName( 'wcf-cpf-min-date' )[ 0 ],
			maxDate =
				document.getElementsByClassName( 'wcf-cpf-max-date' )[ 0 ],
			width = document.getElementsByClassName( 'wcf-cpf-width' )[ 0 ],
			show_in_email = document.getElementsByClassName(
				'wcf-cpf-show-in-email'
			)[ 0 ],
			required =
				document.getElementsByClassName( 'wcf-cpf-required' )[ 0 ],
			optimized =
				document.getElementsByClassName( 'wcf-cpf-optimized' )[ 0 ],
			dateInputField =
				document.getElementsByClassName( 'wcf-cpf-date-input' )[ 0 ],
			dateInputValue = dateInputField ? dateInputField.value : '',
			fileSize =
				document.getElementsByClassName( 'wcf-cpf-file-size' )[ 0 ],
			acceptedFileTypes = document.getElementsByClassName(
				'wcf-cpf-accepted-file-types'
			)[ 0 ];

		if ( '' === label.value ) {
			const span = document.createElement( 'span' );
			span.className = 'text-xs text-brand-500';
			span.textContent = __( 'Label is required field', 'cartflows-pro' );
			document
				.querySelector( '.wcf-cpf-label' )
				.insertAdjacentElement( 'afterend', span );
			label.focus();
			setText( __( 'Add New Field', 'cartflows-pro' ) );
			return '';
		}

		const allowedFileExtensions = [
			'jpg',
			'jpeg',
			'png',
			'gif',
			'webp',
			'ico',
			'pdf',
			'mp3',
			'm4a',
			'ogg',
			'wav',
			'mp4',
			'm4v',
			'mov',
			'wmv',
			'avi',
			'mpg',
			'ogv',
			'3gp',
			'3g2',
		];
		if ( acceptedFileTypes && acceptedFileTypes.value.trim() ) {
			const inputExts = acceptedFileTypes.value
				.split( ',' )
				.map( ( ext ) => ext.trim().toLowerCase() )
				.filter( ( ext ) => ext );
			const invalidExts = inputExts.filter(
				( ext ) => ! allowedFileExtensions.includes( ext )
			);
			if ( invalidExts.length ) {
				const existingError = document.querySelector(
					'.wcf-cpf-accepted-file-types + .wcf-cpf-error'
				);
				if ( existingError ) {
					existingError.remove();
				}
				const errorSpan = document.createElement( 'span' );
				errorSpan.className = 'wcf-cpf-error text-xs text-brand-500';
				errorSpan.textContent = sprintf(
					/* translators: %s: invalid extensions */
					__( 'Invalid file type(s): %s', 'cartflows-pro' ),
					invalidExts.join( ', ' )
				);
				acceptedFileTypes.insertAdjacentElement(
					'afterend',
					errorSpan
				);
				acceptedFileTypes.focus();
				setText( __( 'Add New Field', 'cartflows-pro' ) );
				return '';
			}
		}

		const formData = new FormData();
		formData.append( 'add_to', add_to ? add_to.value : '' );
		formData.append( 'type', type ? type.value : '' );
		formData.append( 'label', label ? label.value : '' );
		formData.append( 'name', field_id ? field_id.value : '' );
		formData.append( 'default', _default ? _default.value : '' );
		formData.append( 'min', minValue ? minValue.value : '' );
		formData.append( 'max', maxValue ? maxValue.value : '' );
		formData.append( 'placeholder', placeholder ? placeholder.value : '' );
		formData.append( 'min_date', minDate ? minDate.value : '' );
		formData.append( 'max_date', maxDate ? maxDate.value : '' );
		formData.append( 'options', _options ? _options.value : '' );
		formData.append(
			'date_input',
			dateInputValue ? dateInputValue : 'datetime-local'
		);
		formData.append( 'width', width ? width.value : '' );
		formData.append( 'required', required ? required.value : '' );
		formData.append(
			'show_in_email',
			show_in_email ? show_in_email.value : ''
		);
		formData.append( 'optimized', optimized ? optimized.value : '' );
		formData.append( 'file_size', fileSize ? fileSize.value : '5' );
		formData.append(
			'accepted_file_types',
			acceptedFileTypes ? acceptedFileTypes.value : ''
		);
		formData.append( 'action', 'cartflows_pro_prepare_custom_field' );
		formData.append(
			'security',
			cartflows_admin.prepare_custom_field_nonce
		);
		formData.append( 'post_id', stepId );
		formData.append( 'save_field_name', 'wcf_field_order_' );

		apiFetch( {
			url: cartflows_admin.ajax_url,
			method: 'POST',
			body: formData,
		} ).then( ( response ) => {
			if ( response.success ) {
				const response_data = response.data;
				const field_data = response_data.field_data;
				if ( 'billing' === response_data.add_to ) {
					billingFields.push( field_data );
					const fields = options.wcf_field_order_billing;
					fields[ response_data.new_field.key ] =
						response_data.new_field;
					dispatch( {
						type: 'SET_OPTION',
						name: 'wcf_field_order_billing',
						value: fields,
					} );
					dispatch( {
						type: 'SET_FIELDS',
						field_type: 'billing',
						fields: billingFields,
					} );
				}
				if ( 'shipping' === response_data.add_to ) {
					shippingFields.push( field_data );
					const fields = options.wcf_field_order_shipping;
					fields[ response_data.new_field.key ] =
						response_data.new_field;
					dispatch( {
						type: 'SET_OPTION',
						name: 'wcf_field_order_shipping',
						value: fields,
					} );
					dispatch( {
						type: 'SET_FIELDS',
						field_type: 'shipping',
						fields: shippingFields,
					} );
				}
			}
			closePopup();
		} );
	};

	return { removeField, addNewField };
}
