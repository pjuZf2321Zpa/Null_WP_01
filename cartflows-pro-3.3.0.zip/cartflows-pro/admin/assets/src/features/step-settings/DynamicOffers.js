import { useState } from '@wordpress/element';
import { useStateValue } from '@Utils/StateProvider';
import RuleSkeleton from '@StepEditor/components/steps-page/RuleSkeleton';
import RuleRepeater from '@ProFeatures/step-settings/RuleRepeater';
import { ConfirmDialogProvider } from '@Alert/ConfirmDialog';
import { ReactSortable } from 'react-sortablejs';
import { __ } from '@wordpress/i18n';
import { ChevronUp, ChevronDown, Plus } from 'lucide-react';
import { Badge, Button, Toaster } from '@bsf/force-ui';
import { SelectField, DocField, ToggleField } from '@Fields';

// 6-dot drag handle matching the Force UI design system.
const DragHandleIcon = ( props ) => (
	<svg
		width="20"
		height="20"
		viewBox="0 0 20 20"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
		aria-hidden="true"
		{ ...props }
	>
		<circle cx="7" cy="5" r="1.25" fill="currentColor" />
		<circle cx="7" cy="10" r="1.25" fill="currentColor" />
		<circle cx="7" cy="15" r="1.25" fill="currentColor" />
		<circle cx="13" cy="5" r="1.25" fill="currentColor" />
		<circle cx="13" cy="10" r="1.25" fill="currentColor" />
		<circle cx="13" cy="15" r="1.25" fill="currentColor" />
	</svg>
);

function DynamicOffersContent() {
	const [ { step_data, step_id, options }, dispatch ] = useStateValue();
	const [ ruleGroupDisplay, setRuleGroupDisplay ] = useState( {
		ruleGroupId: '',
		isOpen: false,
	} );

	const { ruleGroupId, isOpen } = ruleGroupDisplay;

	if ( null === options ) {
		return <RuleSkeleton />;
	}
	const conditions = options[ 'wcf-checkout-rules' ];

	if ( 'undefined' === typeof conditions ) {
		return (
			<DocField
				content={ __(
					'Please Update the CartFlows Pro to the latest version to use the dynamic offers feature.',
					'cartflows-pro'
				) }
			/>
		);
	}

	const addNewGroup = () => {
		const newGroup = {
			group_id: Math.random().toString( 36 ).substring( 2, 5 ),
			rules: [
				{
					rule_id: Math.random().toString( 36 ).substring( 2, 5 ),
					condition: 'cart_item',
					operator: '',
					value: '',
				},
			],
		};

		dispatch( {
			type: 'ADD_NEW_GROUP',
			name: 'wcf-checkout-rules',
			newGroup,
		} );
	};

	const addNewRule = ( group_id ) => {
		const newRule = {
			rule_id: Math.random().toString( 36 ).substring( 2, 5 ),
			condition: 'cart_item',
			operator: '',
			value: '',
		};

		dispatch( {
			type: 'ADD_NEW_RULE',
			name: 'wcf-checkout-rules',
			newRule,
			group_id,
		} );
	};

	const showRules = function ( event ) {
		const group_id = event.target.getAttribute( 'data-group_id' );

		setRuleGroupDisplay( {
			ruleGroupId: group_id,
			isOpen: ruleGroupId === group_id && isOpen ? false : true,
		} );
	};

	const hideButton = function () {
		const button = document.getElementsByClassName(
			'wcf-checkout-rules--or_group__button'
		)[ 0 ];
		button.setAttribute( 'style', 'display:none' );
	};

	const showButton = function () {
		const button = document.getElementsByClassName(
			'wcf-checkout-rules--or_group__button'
		)[ 0 ];

		button.setAttribute( 'style', 'display:inline-block' );
	};

	return (
		<div className="wcf-checkout-rules-page">
			<div className="wcf-checkout-rules-page--enable_option">
				<ToggleField
					name="wcf-checkout-rules-option"
					value={ options[ 'wcf-checkout-rules-option' ] }
					label={ __( 'Enable Dynamic Offers', 'cartflows-pro' ) }
					tooltip={ __(
						'Turn this on to set up rules that decide when visitors should be redirected to a special offer or the next step.',
						'cartflows-pro'
					) }
					fullWidth={ true }
				/>
			</div>
			{ 'yes' === options[ 'wcf-checkout-rules-option' ] &&
				conditions && (
					<div className="mt-8">
						<ReactSortable
							id="wcf-checkout-rules-sortable-wrapper"
							className="wcf-checkout-rules--sortable-wrapper flex flex-col gap-4"
							list={ conditions }
							setList={ ( newState ) =>
								dispatch( {
									type: 'SET_RULES_GROUPS',
									groups: newState,
									fieldName: 'wcf-checkout-rules',
									step_id,
								} )
							}
							swapThreshold={ 0.8 }
							direction={ 'vertical' }
							animation={ 150 }
							handle={ '.wcf-checkout-rules--group' }
							filter={
								'.wcf-checkout-rules--rule_fields, .wcf-checkout-rules--rule_actions, .wcf-field.wcf-select-option, .wcf-checkout-rules--add-rule__repeater .wcf-button.wcf-button--secondary, .wcf-field__data--content, .wcf-checkout-rules-page--group_wrapper__footer, .wcf-checkout-rules--group_header'
							}
							preventOnFilter={ false }
							onStart={ hideButton }
							onEnd={ showButton }
						>
							{ conditions.map( ( group, g_index ) => {
								const group_id = group.group_id;
								const rules = group.rules;
								return (
									<div
										className="wcf-checkout-rules-page--group_wrapper"
										key={ group_id }
									>
										<div
											// No overflow clipping here, or it cuts off the dropdowns inside.
											className="wcf-checkout-rules--group border border-solid border-cartflows-border rounded-md shadow-sm bg-background-primary"
											data-group-id={ group_id }
										>
											<input
												type="hidden"
												name={ `wcf-checkout-rules[${ g_index }][group_id]` }
												value={ group_id }
											/>

											<div className="wcf-checkout-rules--group-header wcf-redirection-step bg-background-primary p-4 flex items-center justify-between flex-wrap gap-4">
												<div className="wcf-checkout-rules--group-header__left flex gap-4 items-center">
													<div className="wcf-checkout-rule--sortable-toggle flex cursor-move text-text-tertiary hover:text-text-secondary">
														<DragHandleIcon />
													</div>

													<div className="border border-solid border-cartflows-border rounded-md shadow-sm flex items-center gap-4 px-3 h-10 bg-background-primary">
														<div className="text-sm font-normal text-text-tertiary whitespace-nowrap">
															{ __(
																'Redirect to:',
																'cartflows-pro'
															) }
														</div>
														<SelectField
															name={ `wcf-checkout-rules[${ g_index }][step_id]` }
															class="w-full !max-w-full min-h-[2rem] h-auto input-field !text-sm !font-medium !rounded-none !text-text-primary !border-none focus:ring-0 focus:!border-none focus:!shadow-none !outline-0 !outline-none !m-0 !p-0 !placeholder-text-tertiary"
															value={
																group.step_id
															}
															placeholder={ __(
																'Search for step…',
																'cartflows-pro'
															) }
															options={
																step_data.step_lists
															}
															overrideCss={ true }
														/>
													</div>
													<div className="text-sm font-normal text-text-tertiary">
														{ __(
															'If the following conditions are true',
															'cartflows-pro'
														) }
													</div>
												</div>
												<div className="wcf-checkout-rules--group-header__right flex gap-2 items-center">
													{ ruleGroupId ===
														group_id && isOpen ? (
														<ChevronUp
															className="w-4 h-4 stroke-1 text-text-tertiary hover:text-text-secondary cursor-pointer"
															aria-hidden="true"
															onClick={
																showRules
															}
															data-group_id={
																group_id
															}
														/>
													) : (
														<ChevronDown
															className="w-4 h-4 stroke-1 text-text-tertiary hover:text-text-secondary cursor-pointer"
															aria-hidden="true"
															onClick={
																showRules
															}
															data-group_id={
																group_id
															}
														/>
													) }
												</div>
											</div>
											<div
												id={ `wcf-checkout-rules--group-${ group_id }` }
												className={ `p-4 bg-background-secondary border-t border-solid border-border-subtle border-0 rounded-b-md ${
													ruleGroupId === group_id &&
													isOpen
														? 'visible'
														: 'hidden'
												}` }
											>
												<div className="wcf-checkout-rules--group-rules__wrapper flex flex-col gap-4">
													{ rules.length !== 0 && (
														<RuleRepeater
															rules={ rules }
															group_id={
																group_id
															}
															g_index={ g_index }
															groups_length={
																conditions.length
															}
														/>
													) }
												</div>

												<div className="wcf-checkout-rules--add-rule__repeater flex mt-4">
													<Button
														variant="link"
														size="sm"
														icon={
															<Plus className="w-4 h-4 stroke-2" />
														}
														iconPosition="left"
														className="wcf-checkout-rules--add-rule__button hover:!no-underline"
														onClick={ () =>
															addNewRule(
																group_id
															)
														}
													>
														{ __(
															'Add Condition',
															'cartflows-pro'
														) }
													</Button>
												</div>
											</div>
										</div>
										<div className="wcf-checkout-rules-page--group_wrapper__footer">
											<div className="wcf-checkout-rules--or-group relative my-4">
												<div
													className="absolute inset-0 flex items-center"
													aria-hidden="true"
												>
													<div className="w-full border-t border-border-subtle border-dashed" />
												</div>
												<div className="relative flex justify-center">
													<Badge
														variant="neutral"
														type="rounded"
														size="xs"
														label={ __(
															'OR',
															'cartflows-pro'
														) }
														className="wcf-checkout-rules--or_group__text"
													/>
												</div>
											</div>

											{ parseInt( g_index ) + 1 ===
												conditions.length && (
												<div className="wcf-checkout-rules--or_group__button mt-4">
													<Button
														variant="outline"
														size="md"
														icon={
															<Plus className="w-4 h-4 stroke-2" />
														}
														iconPosition="left"
														className="wcf-checkout-rules--or_group_button !bg-brand-25 !text-brand-600 !outline-brand-300 hover:!bg-brand-50 hover:!outline-brand-300"
														onClick={ addNewGroup }
													>
														{ __(
															'Add Dynamic Offer',
															'cartflows-pro'
														) }
													</Button>
												</div>
											) }
										</div>
									</div>
								);
							} ) }
						</ReactSortable>
					</div>
				) }

			{ 'yes' === options[ 'wcf-checkout-rules-option' ] && (
				<div className="wcf-checkout-rules--default-step border border-solid border-cartflows-border rounded-md shadow-sm bg-background-primary p-4 flex items-center justify-between gap-4 mt-8">
					<div className="wcf-checkout-rules--default-step__left border border-solid border-cartflows-border rounded-md shadow-sm flex items-center gap-4 px-3 h-10 bg-background-primary">
						<div className="text-sm font-normal text-text-tertiary whitespace-nowrap">
							{ __( 'Redirect to:', 'cartflows-pro' ) }
						</div>
						<SelectField
							name={ `wcf-checkout-rules-default-step` }
							class="w-full !max-w-full min-h-[2rem] h-auto input-field !text-sm !font-medium !rounded-none !text-text-primary !border-none focus:ring-0 focus:!border-none focus:!shadow-none !outline-0 !outline-none !m-0 !p-0 !placeholder-text-tertiary"
							value={
								options[ 'wcf-checkout-rules-default-step' ]
							}
							placeholder={ __(
								'Search for default step…',
								'cartflows-pro'
							) }
							options={ step_data.step_lists }
							overrideCss={ true }
						/>
					</div>

					<div className="text-sm font-normal text-text-tertiary">
						{ __(
							'If all of the above conditions failed.',
							'cartflows-pro'
						) }
					</div>
				</div>
			) }
		</div>
	);
}

/**
 * Dynamic Offers tab — fills the free plugin's
 * cartflows.stepSettings.dynamicOffers slot; reads free's store via the shared context.
 *
 * @return {Object} Dynamic offers rule builder.
 */
function DynamicOffers() {
	return (
		<ConfirmDialogProvider>
			<DynamicOffersContent />
			<Toaster />
		</ConfirmDialogProvider>
	);
}

export default DynamicOffers;
