import { __ } from '@wordpress/i18n';
import parse from 'html-react-parser';
import { Switch, RadioButton, Label, Toaster } from '@bsf/force-ui';
import { Info } from 'lucide-react';
import { useStateValue } from '@Utils/StateProvider';
import { ConfirmDialogProvider } from '@Alert/ConfirmDialog';

function ProductOptionsContent() {
	const [ { options, page_settings }, dispatch ] = useStateValue();

	const enableProductOptions =
		'yes' === options[ 'wcf-enable-product-options' ];
	const productOptionType = options[ 'wcf-product-options' ] || 'force-all';
	const enableVariation = 'yes' === options[ 'wcf-enable-product-variation' ];
	const variationOption =
		options[ 'wcf-product-variation-options' ] || 'inline';
	const enableQuantity = 'yes' === options[ 'wcf-enable-product-quantity' ];

	// Desc sourced from section settings registered via PHP (page_settings).
	const desc = page_settings?.settings?.[ 'product-options' ]?.desc || null;

	const setOption = ( name, value ) => {
		dispatch( { type: 'SET_OPTION', name, value } );
	};

	return (
		<div className="flex flex-col">
			<div className="flex items-center justify-between py-5">
				<Label
					htmlFor="wcf-enable-product-options-switch"
					size="sm"
					className="font-medium text-text-primary"
				>
					{ __( 'Enable Product Options', 'cartflows-pro' ) }
				</Label>
				<Switch
					id="wcf-enable-product-options-switch"
					value={ enableProductOptions }
					onChange={ ( checked ) =>
						setOption(
							'wcf-enable-product-options',
							checked ? 'yes' : 'no'
						)
					}
				/>
			</div>
			<input
				type="hidden"
				name="wcf-enable-product-options"
				value={ enableProductOptions ? 'yes' : 'no' }
			/>

			{ enableProductOptions && (
				<div className="flex flex-col gap-2 pb-5 border-b border-border-subtle border-solid border-0">
					<Label
						tag="p"
						size="sm"
						className="font-medium text-text-primary"
					>
						{ __( 'Enable Conditions', 'cartflows-pro' ) }
					</Label>
					<RadioButton.Group
						gapClassName="gap-1.5"
						value={ productOptionType }
						onChange={ ( val ) =>
							setOption( 'wcf-product-options', val )
						}
						style="simple"
						size="sm"
						vertical
						className="w-full"
					>
						<RadioButton.Button
							value="force-all"
							reversePosition
							minWidth={ false }
							buttonWrapperClasses="w-full !pr-2.5 !py-0"
							label={ {
								heading: __(
									'Restrict user to purchase all products',
									'cartflows-pro'
								),
							} }
						/>
						<RadioButton.Button
							value="single-selection"
							reversePosition
							minWidth={ false }
							buttonWrapperClasses="w-full !pr-2.5 !py-0"
							label={ {
								heading: __(
									'Let user select one product from all options',
									'cartflows-pro'
								),
							} }
						/>
						<RadioButton.Button
							value="multiple-selection"
							reversePosition
							minWidth={ false }
							buttonWrapperClasses="w-full !pr-2.5 !py-0"
							label={ {
								heading: __(
									'Let user select multiple products from all options',
									'cartflows-pro'
								),
							} }
						/>
					</RadioButton.Group>
				</div>
			) }
			<input
				type="hidden"
				name="wcf-product-options"
				value={ productOptionType }
			/>

			<div className="flex items-center justify-between py-5">
				<Label
					htmlFor="wcf-enable-product-variation-switch"
					size="sm"
					className="font-medium text-text-primary"
				>
					{ __( 'Enable Variations', 'cartflows-pro' ) }
				</Label>
				<Switch
					id="wcf-enable-product-variation-switch"
					value={ enableVariation }
					onChange={ ( checked ) =>
						setOption(
							'wcf-enable-product-variation',
							checked ? 'yes' : 'no'
						)
					}
				/>
			</div>
			<input
				type="hidden"
				name="wcf-enable-product-variation"
				value={ enableVariation ? 'yes' : 'no' }
			/>

			{ enableVariation && (
				<div className="flex flex-col gap-2 pb-5 border-b border-border-subtle border-solid border-0">
					<RadioButton.Group
						gapClassName="gap-1.5"
						value={ variationOption }
						onChange={ ( val ) =>
							setOption( 'wcf-product-variation-options', val )
						}
						style="simple"
						size="sm"
						vertical
						className="w-full"
					>
						<RadioButton.Button
							value="inline"
							reversePosition
							minWidth={ false }
							buttonWrapperClasses="w-full !pr-2.5 !py-0"
							label={ {
								heading: __(
									'Show variations inline',
									'cartflows-pro'
								),
							} }
						/>
						<RadioButton.Button
							value="popup"
							reversePosition
							minWidth={ false }
							buttonWrapperClasses="w-full !pr-2.5 !py-0"
							label={ {
								heading: __(
									'Show variations in popup',
									'cartflows-pro'
								),
							} }
						/>
					</RadioButton.Group>
				</div>
			) }
			<input
				type="hidden"
				name="wcf-product-variation-options"
				value={ variationOption }
			/>

			<div className="flex items-center justify-between py-5 !pb-0">
				<Label
					htmlFor="wcf-enable-product-quantity-switch"
					size="sm"
					className="font-medium text-text-primary"
				>
					{ __( 'Enable Quantity', 'cartflows-pro' ) }
				</Label>
				<Switch
					id="wcf-enable-product-quantity-switch"
					value={ enableQuantity }
					onChange={ ( checked ) =>
						setOption(
							'wcf-enable-product-quantity',
							checked ? 'yes' : 'no'
						)
					}
				/>
			</div>
			<input
				type="hidden"
				name="wcf-enable-product-quantity"
				value={ enableQuantity ? 'yes' : 'no' }
			/>

			{ desc && (
				<div className="flex items-start gap-1 text-sm font-normal text-text-tertiary mt-2">
					<Info className="w-4 h-4 shrink-0 mt-px text-icon-secondary" />
					<span>{ parse( desc ) }</span>
				</div>
			) }
		</div>
	);
}

/**
 * Product Options section — fills the free plugin's
 * cartflows.stepSettings.productOptions slot; reads free's store via the shared context.
 *
 * @return {Object} Product options controls.
 */
function ProductOptions() {
	return (
		<ConfirmDialogProvider>
			<ProductOptionsContent />
			<Toaster />
		</ConfirmDialogProvider>
	);
}

export default ProductOptions;
