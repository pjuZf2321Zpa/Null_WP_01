import { useEffect } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { useSettingsStateValue } from '@App/providers/SettingsStateProvider';

/**
 * Custom hook to fetch published flows for analytics filters.
 *
 * Fetches flows from the server via AJAX only if not already in state.
 * Uses global state to memoize flows across all analytics pages.
 * Returns an array of flow options with 'All Funnels' as the first option.
 *
 * @since 2.2.0
 * @return {Object} { flows, loading, error }
 */
export const usePublishedFlows = () => {
	const [ { publishedFlows }, dispatch ] = useSettingsStateValue();

	useEffect( () => {
		// Only fetch if not already loaded or loading
		if (
			publishedFlows &&
			( publishedFlows.data || publishedFlows.loading )
		) {
			return;
		}

		const fetchFlows = async () => {
			// Set loading state
			dispatch( {
				type: 'SET_PUBLISHED_FLOWS',
				publishedFlows: {
					data: null,
					loading: true,
					error: null,
				},
			} );

			try {
				const formData = new window.FormData();
				formData.append( 'action', 'cartflows_get_published_flows' );
				formData.append(
					'security',
					cartflows_admin.get_published_flows_nonce
				);

				const response = await apiFetch( {
					url: cartflows_admin.ajax_url,
					method: 'POST',
					body: formData,
				} );

				if ( response && response.data && response.data.flows ) {
					const flowOptions = [
						{
							value: '',
							label: __( 'All Funnels', 'cartflows-pro' ),
						},
						...response.data.flows.map( ( flow ) => ( {
							value: flow.flow_id,
							label: flow.flow_title,
						} ) ),
					];

					dispatch( {
						type: 'SET_PUBLISHED_FLOWS',
						publishedFlows: {
							data: flowOptions,
							loading: false,
							error: null,
						},
					} );
				}
			} catch ( err ) {
				console.error( 'Error fetching flows:', err );
				dispatch( {
					type: 'SET_PUBLISHED_FLOWS',
					publishedFlows: {
						data: [
							{
								value: '',
								label: __( 'All Funnels', 'cartflows-pro' ),
							},
						],
						loading: false,
						error: err,
					},
				} );
			}
		};

		fetchFlows();
	}, [ dispatch, publishedFlows ] );

	// Return default values if not yet loaded
	const flows = publishedFlows?.data || [
		{ value: '', label: __( 'All Funnels', 'cartflows-pro' ) },
	];
	const loading = publishedFlows?.loading || false;
	const error = publishedFlows?.error || null;

	return { flows, loading, error };
};
