import { useContext, createContext } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { toast } from '@bsf/force-ui';

// Version-skew fallback: an older free plugin never publishes an AI context.
const FallbackContext = createContext( {
	isConnected: false,
	isLoading: false,
	connect: () => {},
	ensureConnected: () => {
		toast.error(
			__(
				'Update the CartFlows plugin to use AI features.',
				'cartflows-pro'
			)
		);
		return false;
	},
} );

// Lazy read: free publishes its AiContext on window after this bundle evaluates.
const sharedContext = () => window.cartflows?.aiContext || FallbackContext;

/**
 * Access free's shared AI connection state (connect dialog, ensureConnected gate).
 *
 * @return {{isConnected: boolean, isLoading: boolean, connect: Function, ensureConnected: Function}} AI context value.
 */
export const useAi = () => useContext( sharedContext() );
