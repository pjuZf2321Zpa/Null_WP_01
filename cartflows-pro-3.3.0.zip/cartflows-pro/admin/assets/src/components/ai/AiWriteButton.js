import { __ } from '@wordpress/i18n';
import { Button, Tooltip, toast } from '@bsf/force-ui';
import { Sparkles, RefreshCw } from 'lucide-react';
import { useAi } from './useAi';

/**
 * Reusable "Write with AI" / "Regenerate" trigger. Gates on AI connection, then
 * runs onGenerate (or a placeholder toast until the AI backend is wired).
 *
 * @param {Object}   props
 * @param {string}   [props.label]      - Button text.
 * @param {string}   [props.tooltip]    - Optional hover tooltip.
 * @param {boolean}  [props.regenerate] - Use the regenerate icon instead of Sparkles.
 * @param {Function} [props.onGenerate] - Real generation handler; falls back to a placeholder toast.
 * @param {boolean}  [props.loading]    - Show the button's loading state.
 * @param {boolean}  [props.disabled]   - Disable the button (e.g. while a request is in flight).
 */
const AiWriteButton = ( {
	label,
	tooltip,
	regenerate = false,
	onGenerate,
	loading = false,
	disabled = false,
} ) => {
	const { ensureConnected } = useAi();

	const handleClick = () => {
		if ( disabled || loading || ! ensureConnected() ) {
			return;
		}
		if ( 'function' === typeof onGenerate ) {
			onGenerate();
			return;
		}
		toast.success(
			__( 'AI copy generation coming soon.', 'cartflows-pro' )
		);
	};

	const icon = regenerate ? (
		<RefreshCw className="size-3.5" />
	) : (
		<Sparkles className="size-3.5" />
	);

	const button = (
		<Button
			type="button"
			variant="ghost"
			size="xs"
			icon={ icon }
			iconPosition="left"
			onClick={ handleClick }
			loading={ loading }
			disabled={ disabled }
			className="!text-text-secondary"
		>
			{ label ||
				( regenerate
					? __( 'Regenerate', 'cartflows-pro' )
					: __( 'Write with AI', 'cartflows-pro' ) ) }
		</Button>
	);

	if ( tooltip ) {
		return (
			<Tooltip content={ tooltip } placement="top" arrow>
				<span className="inline-flex">{ button }</span>
			</Tooltip>
		);
	}

	return button;
};

export default AiWriteButton;
