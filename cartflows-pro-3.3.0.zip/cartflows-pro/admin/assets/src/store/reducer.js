// Pro slice of free's editor reducer — free's copy reads cartflows_admin at module scope.
const reducer = ( state, action ) => {
	switch ( action.type ) {
		case 'SET_OPTION': {
			const newOptions = state.options || {};
			newOptions[ action.name ] = action.value;
			return { ...state, options: newOptions };
		}
		case 'SET_STEP_DATA':
			return {
				...state,
				step_data: action.data,
				options: action.data.options,
				page_settings: action.data.page_settings,
				custom_fields: action.data.custom_fields,
			};
		case 'UPDATE_OPTIONS':
			return { ...state, options: action.options };
		case 'UPDATE_ORDER_BUMP': {
			state.options[ action.name ] = action.order_bumps;
			return { ...state };
		}
		case 'REMOVE_ORDER_BUMP': {
			state.options[ action.name ] = state.options[ action.name ].filter(
				( ob ) => ob.id !== action.ob_id
			);
			return { ...state };
		}
		case 'SET_CURRENT_OB': {
			const obIndex = (
				state.options?.[ 'wcf-order-bumps' ] || []
			).findIndex( ( ob ) => ob.id === action.ob_id );
			if ( -1 !== obIndex ) {
				state.options[ 'wcf-order-bumps' ][ obIndex ] =
					action.current_ob;
			}
			return {
				...state,
				ob_id: action.ob_id,
				current_ob: action.current_ob,
			};
		}
		case 'SET_OB': {
			state.options[ action.fieldName ] = action.obs;
			return { ...state };
		}
		case 'SET_OB_TITLE': {
			const idx = state.options[ action.name ].findIndex(
				( ob ) => ob.id === action.ob_id
			);
			if ( -1 !== idx ) {
				state.options[ action.name ][ idx ].title = action.title;
			}
			return { ...state };
		}
		case 'SET_OB_STATUS': {
			const idx = state.options[ action.name ].findIndex(
				( ob ) => ob.id === action.ob_id
			);
			if ( -1 !== idx ) {
				state.options[ action.name ][ idx ].status = action.newStatus;
			}
			return { ...state };
		}
		case 'SET_OB_OPTION': {
			const newOb = state.current_ob || {};
			newOb[ action.name ] = action.value;
			return { ...state, current_ob: newOb };
		}
		case 'SET_OB_PRODUCT': {
			const bumps = state.options?.[ 'wcf-order-bumps' ] || [];
			const idx = bumps.findIndex( ( ob ) => ob.id === action.ob_id );
			if ( -1 !== idx ) {
				bumps[ idx ].product = action.product;
			}
			return { ...state };
		}
		case 'SET_OB_RULES_GROUPS': {
			state.current_ob[ action.fieldName ] = action.groups;
			return { ...state };
		}
		case 'ADD_NEW_OB_RULE': {
			const groups = state.current_ob[ action.name ];
			if ( groups && action.group_id ) {
				for ( const group of groups ) {
					if ( action.group_id === group.group_id ) {
						group.rules.push( action.newRule );
						break;
					}
				}
				state.current_ob[ action.name ] = groups;
			}
			return { ...state };
		}
		case 'REMOVE_OB_RULE': {
			const groups = state.current_ob[ action.name ];
			for ( let i = 0; i < groups.length; i++ ) {
				if ( action.group_id === groups[ i ].group_id ) {
					const rules = groups[ i ].rules;
					for ( let j = 0; j < rules.length; j++ ) {
						if ( rules[ j ].rule_id === action.rule_id ) {
							groups[ i ].rules.splice( j, 1 );
							break;
						}
					}
					if ( 0 === groups[ i ].rules.length ) {
						groups.splice( i, 1 );
					}
				}
			}
			state.current_ob[ action.name ] = groups;
			return { ...state };
		}
		case 'RESET_OB_RULE_VALUE': {
			const groups = state.current_ob[ action.name ];
			for ( const group of groups ) {
				if ( action.group_id === group.group_id ) {
					for ( const rule of group.rules ) {
						if ( action.rule_id === rule.rule_id ) {
							rule.value = '';
							break;
						}
					}
					break;
				}
			}
			state.current_ob[ action.name ] = groups;
			return { ...state };
		}
		case 'ADD_NEW_GROUP': {
			const groups = state.options[ action.name ];
			if ( groups ) {
				groups.push( action.newGroup );
				state.options[ action.name ] = groups;
			}
			return { ...state };
		}
		case 'ADD_NEW_RULE': {
			const groups = state.options[ action.name ];
			if ( groups && action.group_id ) {
				for ( const group of groups ) {
					if ( action.group_id === group.group_id ) {
						group.rules.push( action.newRule );
						break;
					}
				}
				state.options[ action.name ] = groups;
			}
			return { ...state };
		}
		case 'REMOVE_RULE': {
			const groups = state.options[ action.name ];
			for ( let i = 0; i < groups.length; i++ ) {
				if ( action.group_id === groups[ i ].group_id ) {
					const rules = groups[ i ].rules;
					for ( let j = 0; j < rules.length; j++ ) {
						if ( rules[ j ].rule_id === action.rule_id ) {
							groups[ i ].rules.splice( j, 1 );
							break;
						}
					}
					if ( 0 === groups[ i ].rules.length ) {
						groups.splice( i, 1 );
					}
				}
			}
			state.options[ action.name ] = groups;
			return { ...state };
		}
		case 'RESET_RULE_VALUE': {
			const groups = state.options[ action.name ];
			for ( const group of groups ) {
				if ( action.group_id === group.group_id ) {
					for ( const rule of group.rules ) {
						if ( action.rule_id === rule.rule_id ) {
							rule.value = '';
							// A new condition may invalidate the operator too.
							rule.operator = '';
							break;
						}
					}
					break;
				}
			}
			state.options[ action.name ] = groups;
			return { ...state };
		}
		case 'SET_RULES_GROUPS': {
			state.options[ action.fieldName ] = action.groups;
			return { ...state };
		}
		default:
			return state;
	}
};

export default reducer;
