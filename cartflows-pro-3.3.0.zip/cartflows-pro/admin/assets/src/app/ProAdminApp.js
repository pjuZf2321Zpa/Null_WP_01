/**
 * CartFlows Pro admin app entry.
 * Registers Pro components into the free plugin admin via @wordpress/hooks.
 */
import '@ProFeatures/dashboard';
import '@ProFeatures/navbar';
import '@ProFeatures/analytics';
import '@ProFeatures/flow-editor';
import '@ProFeatures/order-bump';
import '@ProFeatures/ab-test';
import '@ProFeatures/canvas';
import '@ProFeatures/step-settings';
import '@ProFeatures/settings';
import '@ProFeatures/upgrade-notice';
