/**
 * Format a Date as YYYY-MM-DD in local time.
 *
 * @param {Date} dateObj Date to format.
 * @return {string} Formatted date.
 */
export function formatDateWithoutTimezone( dateObj ) {
	const year = dateObj.getFullYear();
	const month = String( dateObj.getMonth() + 1 ).padStart( 2, '0' );
	const day = String( dateObj.getDate() ).padStart( 2, '0' );
	return `${ year }-${ month }-${ day }`;
}
