/**
 * Calculate trend percentage and direction
 *
 * @param {number} currentValue    - Current period value
 * @param {number} comparisonValue - Comparison period value
 * @return {Object} - { percentage: number, isIncrease: boolean }
 */
export const calculateTrend = ( currentValue, comparisonValue ) => {
	const hasBaseline =
		comparisonValue && comparisonValue !== 0 && comparisonValue !== '0.00';

	// Zero baseline with real activity now — percentage is meaningless, flag as new.
	if ( ! hasBaseline && Number( currentValue ) > 0 ) {
		return { percentage: null, isIncrease: true, isNew: true };
	}

	if ( ! hasBaseline || comparisonValue === currentValue ) {
		return { percentage: 0, isIncrease: true };
	}

	// Calculate percentage change: ((current - previous) / previous) * 100
	const percentageChange =
		( ( currentValue - comparisonValue ) / comparisonValue ) * 100;
	const magnitude = Math.abs( percentageChange );
	// Ceil turned a 99.2% drop into "100%"; round instead, keep a decimal for small moves.
	const roundedPercentage =
		magnitude < 10
			? Math.round( magnitude * 10 ) / 10
			: Math.round( magnitude );

	return {
		percentage: roundedPercentage,
		isIncrease: percentageChange >= 0,
		baselineValue: Number( comparisonValue ),
	};
};

/**
 * Parse YYYY-MM-DD as a local date (`new Date( ymd )` would parse as UTC and shift the day).
 *
 * @param {string} ymd Date string.
 * @return {Date} Local-midnight Date.
 */
export const parseYMD = ( ymd ) => {
	const [ y, m, d ] = String( ymd ).split( '-' ).map( Number );
	return new Date( y, m - 1, d );
};

/**
 * Resolve the comparison window for a date range as a human-readable label.
 *
 * @param {string} from           Current range start (YYYY-MM-DD).
 * @param {string} to             Current range end (YYYY-MM-DD).
 * @param {string} comparisonType 'previous-period' | 'previous-year'.
 * @return {string} Label like "Jun 1 – Jun 30, 2026", or '' when the range is unknown.
 */
export const getComparisonRangeLabel = ( from, to, comparisonType ) => {
	if ( ! from || ! to ) {
		return '';
	}
	const start = parseYMD( from );
	const end = parseYMD( to );

	if ( 'previous-year' === comparisonType ) {
		start.setFullYear( start.getFullYear() - 1 );
		end.setFullYear( end.getFullYear() - 1 );
	} else {
		const days = Math.round( ( end - start ) / 86400000 ) + 1;
		end.setTime( start.getTime() );
		end.setDate( start.getDate() - 1 );
		start.setDate( start.getDate() - days );
	}

	return formatDateRangeLabel( start, end );
};

/**
 * Format two local Dates as a locale-aware range label, e.g. "Jul 14 – Jul 27, 2026".
 *
 * @param {Date} start Range start.
 * @param {Date} end   Range end.
 * @return {string} Formatted range.
 */
export const formatDateRangeLabel = ( start, end ) => {
	const fmt = ( date, withYear ) =>
		date.toLocaleDateString( undefined, {
			month: 'short',
			day: 'numeric',
			...( withYear ? { year: 'numeric' } : {} ),
		} );
	return `${ fmt( start, false ) } – ${ fmt( end, true ) }`;
};

/**
 * Format a YYYY-MM-DD range as a locale-aware label; '' when either side is missing.
 *
 * @param {string} from Range start (YYYY-MM-DD).
 * @param {string} to   Range end (YYYY-MM-DD).
 * @return {string} Formatted range.
 */
export const getRangeLabel = ( from, to ) => {
	if ( ! from || ! to ) {
		return '';
	}
	return formatDateRangeLabel( parseYMD( from ), parseYMD( to ) );
};

/**
 * Whether any comparison-period metric is non-zero (an empty baseline would flag every card "New").
 *
 * @param {Object|Array} comparisonMetrics Comparison metrics keyed by metric name.
 * @return {boolean} True when at least one metric has activity.
 */
export const hasComparisonBaseline = ( comparisonMetrics ) =>
	Object.values( comparisonMetrics || {} ).some(
		( value ) => Number( value ) > 0
	);

/**
 * Format a Date as YYYY-MM-DD in local time (toISOString shifts the day in non-UTC zones).
 *
 * @param {Date} date - Date to format.
 * @return {string} - Local date string.
 */
export const toLocalYMD = ( date ) => {
	const month = String( date.getMonth() + 1 ).padStart( 2, '0' );
	const day = String( date.getDate() ).padStart( 2, '0' );
	return `${ date.getFullYear() }-${ month }-${ day }`;
};

/**
 * Get dates in a range
 *
 * @param {Date} startDate - Start date
 * @param {Date} endDate   - End date
 * @return {Array} - Array of date strings in ISO format
 */
export const getDatesInRange = ( startDate, endDate ) => {
	const date = new Date( startDate.getTime() );
	const dates = [];
	while ( date <= endDate ) {
		dates.push( toLocalYMD( date ) );
		date.setDate( date.getDate() + 1 );
	}
	return dates;
};

/**
 * Get comparison period options
 *
 * @param {Function} __ - Translation function
 * @return {Array} - Array of comparison period options
 */
export const getComparisonPeriodOptions = ( __ ) => [
	{
		value: 'previous-period',
		label: __( 'Previous Period', 'cartflows-pro' ),
	},
	{
		value: 'previous-year',
		label: __( 'Previous Year', 'cartflows-pro' ),
	},
];
