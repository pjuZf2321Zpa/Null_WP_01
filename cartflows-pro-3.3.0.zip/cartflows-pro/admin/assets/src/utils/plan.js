/**
 * Plan helpers — read the free plugin's localized vars at call time,
 * because the pro bundle executes before `cartflows_admin` is printed.
 */

export const isProActive = () => !! window.cartflows_admin?.is_pro;

export const isLicenseActivated = () =>
	'Activated' === window.cartflows_admin?.license_status;

// Plan helpers gate paid features, so an unlicensed pro install must fall back to free's upgrade nudge.
export const isProPlan = () =>
	isProActive() &&
	isLicenseActivated() &&
	'pro' === window.cartflows_admin?.cf_pro_type;

export const isPlusProPlan = () =>
	isProActive() &&
	isLicenseActivated() &&
	[ 'plus', 'pro' ].includes( window.cartflows_admin?.cf_pro_type );
