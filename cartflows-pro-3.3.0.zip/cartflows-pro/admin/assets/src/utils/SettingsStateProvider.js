import { useContext, useReducer } from '@wordpress/element';

// Lazy read: free publishes its StateContext on window after this bundle evaluates.
const sharedContext = () => window.cartflows.settingsStateContext;

// Wrap a pro subtree and provide a data layer on free's shared context.
export const SettingsStateProvider = ( {
	reducer,
	initialState,
	children,
} ) => {
	const StateContext = sharedContext();

	return (
		<StateContext.Provider value={ useReducer( reducer, initialState ) }>
			{ children }
		</StateContext.Provider>
	);
};

// Get information from the data layer.
export const useSettingsStateValue = () => useContext( sharedContext() );
