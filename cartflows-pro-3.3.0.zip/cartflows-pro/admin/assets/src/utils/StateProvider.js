import { useContext, useReducer } from '@wordpress/element';

// Lazy read: free publishes its StateContext on window after this bundle evaluates.
const sharedContext = () => window.cartflows.editorStateContext;

// Wrap a pro subtree and provide a data layer on free's shared context.
export const StateProvider = ( { reducer, initialState, children } ) => {
	const StateContext = sharedContext();

	return (
		<StateContext.Provider value={ useReducer( reducer, initialState ) }>
			{ children }
		</StateContext.Provider>
	);
};

// Get information from the data layer.
export const useStateValue = () => useContext( sharedContext() );
