import { decode } from 'html-entities';

/**
 * Truncate and decode a title for display.
 *
 * @param {string} title          Raw title.
 * @param {number} max_length     Length that triggers truncation.
 * @param {number} display_length Visible length after truncation.
 * @return {string} Decoded, possibly truncated title.
 */
export function validateTitleField( title, max_length, display_length ) {
	const validatedTitle =
		title?.length > max_length
			? title.substring( 0, display_length ) + '...'
			: title;
	return decode( validatedTitle );
}
