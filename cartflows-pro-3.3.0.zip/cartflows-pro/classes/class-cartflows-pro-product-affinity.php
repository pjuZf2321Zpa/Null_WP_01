<?php
/**
 * CartFlows Product Affinity — "Frequently Bought Together" engine.
 *
 * Precomputes product-pair affinity (market-basket / co-occurrence with lift)
 * from historical WooCommerce orders into a custom table via Action Scheduler,
 * and exposes a keyed read API for the frontend recommendation widget.
 *
 * @package CartFlows
 * @since   2.2.5
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Affinity.
 */
class Cartflows_Pro_Product_Affinity {

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since 2.2.5
	 */
	private static $instance = null;

	/**
	 * Schema version — bump to trigger a table migration.
	 *
	 * @var string
	 */
	const DB_VERSION = '1.0.0';

	/**
	 * Recurring recompute hook name.
	 *
	 * @var string
	 */
	const HOOK_RECOMPUTE = 'cartflows_fbt_recompute';

	/**
	 * Single per-batch processing hook name.
	 *
	 * @var string
	 */
	const HOOK_PROCESS_BATCH = 'cartflows_fbt_process_batch';

	/**
	 * Finalize (scoring + prune) hook name.
	 *
	 * @var string
	 */
	const HOOK_FINALIZE = 'cartflows_fbt_finalize';

	/**
	 * Initiator
	 *
	 * @since 2.2.5
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 2.2.5
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'maybe_create_table' ) );
		add_action( 'admin_init', array( $this, 'schedule_events' ) );

		add_action( self::HOOK_RECOMPUTE, array( $this, 'start_recompute' ) );
		add_action( self::HOOK_PROCESS_BATCH, array( $this, 'process_batch' ) );
		add_action( self::HOOK_FINALIZE, array( $this, 'finalize' ) );
	}

	/**
	 * Whether the feature is enabled.
	 *
	 * @since 2.2.5
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) apply_filters( 'cartflows_fbt_enabled', wcf()->is_woo_active );
	}

	/**
	 * Fully-qualified affinity table name.
	 *
	 * @since 2.2.5
	 * @return string
	 */
	public static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'cartflows_product_affinity';
	}

	// -------------------------------------------------------------------------
	// Schema
	// -------------------------------------------------------------------------

	/**
	 * Create or migrate the affinity table when the schema version changes.
	 *
	 * @since 2.2.5
	 * @return void
	 */
	public function maybe_create_table() {
		if ( self::DB_VERSION === get_option( 'cartflows_fbt_db_version' ) ) {
			return;
		}

		global $wpdb;

		$table           = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			product_id bigint(20) unsigned NOT NULL,
			related_id bigint(20) unsigned NOT NULL,
			support int(10) unsigned NOT NULL DEFAULT 0,
			score float NOT NULL DEFAULT 0,
			updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY product_related (product_id, related_id),
			KEY product_score (product_id, score)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( 'cartflows_fbt_db_version', self::DB_VERSION );
	}

	// -------------------------------------------------------------------------
	// Scheduling
	// -------------------------------------------------------------------------

	/**
	 * Register (or clear) the recurring recompute action based on feature state.
	 *
	 * @since 2.2.5
	 * @return void
	 */
	public function schedule_events() {
		if ( ! function_exists( 'as_schedule_recurring_action' ) || wp_installing() ) {
			return;
		}

		if ( ! self::is_enabled() ) {
			if ( function_exists( 'as_unschedule_all_actions' ) ) {
				as_unschedule_all_actions( self::HOOK_RECOMPUTE );
			}
			return;
		}

		if ( false === as_next_scheduled_action( self::HOOK_RECOMPUTE ) ) {
			as_schedule_recurring_action( time() + HOUR_IN_SECONDS, DAY_IN_SECONDS, self::HOOK_RECOMPUTE, array(), 'cartflows' );
		}
	}

	// -------------------------------------------------------------------------
	// Computation pipeline
	// -------------------------------------------------------------------------

	/**
	 * Write a batch-pipeline log line (gated on WP_DEBUG or a filter).
	 *
	 * @since 2.2.5
	 * @param string $message Message to log.
	 * @param string $level   Severity label (info|warning|error).
	 * @return void
	 */
	private function log( $message, $level = 'info' ) {
		if ( ! apply_filters( 'cartflows_fbt_enable_logging', defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			return;
		}

		if ( class_exists( 'Cartflows_Logger' ) ) {
			Cartflows_Logger::get_instance()->log( sprintf( '[FBT] %s', $message ), $level );
		}
	}

	/**
	 * Batch size — orders processed per Action Scheduler step.
	 *
	 * @since 2.2.5
	 * @return int
	 */
	private function get_batch_size() {
		return max( 1, (int) apply_filters( 'cartflows_fbt_batch_size', 200 ) );
	}

	/**
	 * Read an option as a non-negative integer.
	 *
	 * @since 2.2.5
	 * @param string $key Option name.
	 * @return int
	 */
	private function get_int_option( $key ) {
		$value = get_option( $key, 0 );
		return is_numeric( $value ) ? (int) $value : 0;
	}

	/**
	 * Compute the lift score for a product pair.
	 *
	 * Lift = (pair x total) / (support_a x support_b); values above 1 mean the
	 * pair co-occurs more than chance, which cancels out bestseller bias.
	 *
	 * @since 2.2.5
	 * @param int $pair_support Orders containing both products.
	 * @param int $total_orders Total orders analyzed.
	 * @param int $support_a    Orders containing product A.
	 * @param int $support_b    Orders containing product B.
	 * @return float
	 */
	public static function calculate_lift( $pair_support, $total_orders, $support_a, $support_b ) {
		if ( $support_a <= 0 || $support_b <= 0 || $total_orders <= 0 ) {
			return 0.0001;
		}

		$lift = ( $pair_support * $total_orders ) / ( $support_a * $support_b );

		return max( 0.0001, $lift );
	}

	/**
	 * Minimum co-occurrence count for a pair to be kept.
	 *
	 * @since 2.2.5
	 * @return int
	 */
	private function get_min_support() {
		return max( 1, (int) apply_filters( 'cartflows_fbt_min_support', 2 ) );
	}

	/**
	 * Lower bound for the orders window (GMT MySQL datetime).
	 *
	 * @since 2.2.5
	 * @return string
	 */
	private function get_lookback_date() {
		$months = max( 1, (int) apply_filters( 'cartflows_fbt_lookback_months', 12 ) );
		return gmdate( 'Y-m-d H:i:s', (int) strtotime( "-{$months} months" ) );
	}

	/**
	 * Reset staging state and truncate the table for a full recompute.
	 *
	 * @since 2.2.5
	 * @return void
	 */
	public function start_recompute() {
		if ( ! self::is_enabled() || ! function_exists( 'as_enqueue_async_action' ) ) {
			$this->log( 'start_recompute aborted: feature disabled or Action Scheduler unavailable.', 'warning' );
			return;
		}

		$this->log( 'start_recompute: beginning full recompute.' );

		$this->maybe_create_table();

		global $wpdb;
		$table = self::get_table_name();

		//phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "TRUNCATE TABLE $table" );

		if ( '' !== $wpdb->last_error ) {
			$this->log( 'start_recompute: TRUNCATE failed — ' . $wpdb->last_error, 'error' );
		}

		update_option( 'cartflows_fbt_offset', 0, false );
		update_option( 'cartflows_fbt_order_count', 0, false );
		update_option( 'cartflows_fbt_support_map', array(), false );

		as_enqueue_async_action( self::HOOK_PROCESS_BATCH, array(), 'cartflows' );
		$this->log( 'start_recompute: staging reset, first batch enqueued.' );
	}

	/**
	 * Process one batch of orders — accumulate pair counts and product supports.
	 *
	 * @since 2.2.5
	 * @return void
	 */
	public function process_batch() {
		if ( ! self::is_enabled() || ! function_exists( 'wc_get_orders' ) ) {
			$this->log( 'process_batch aborted: feature disabled or WooCommerce unavailable.', 'warning' );
			return;
		}

		$offset     = $this->get_int_option( 'cartflows_fbt_offset' );
		$batch_size = $this->get_batch_size();

		$this->log( sprintf( 'process_batch: fetching orders at offset %d (batch size %d).', $offset, $batch_size ) );

		$order_ids = wc_get_orders(
			array(
				'status'       => array( 'wc-completed', 'wc-processing' ),
				'date_created' => '>=' . strtotime( $this->get_lookback_date() ),
				'limit'        => $batch_size,
				'offset'       => $offset,
				'orderby'      => 'ID',
				'order'        => 'ASC',
				'return'       => 'ids',
			)
		);

		if ( empty( $order_ids ) || ! is_array( $order_ids ) ) {
			$this->log( sprintf( 'process_batch: no orders at offset %d, enqueuing finalize.', $offset ) );
			as_enqueue_async_action( self::HOOK_FINALIZE, array(), 'cartflows' );
			return;
		}

		$this->log( sprintf( 'process_batch: fetched %d orders at offset %d.', count( $order_ids ), $offset ) );

		$support_map = get_option( 'cartflows_fbt_support_map', array() );
		$support_map = is_array( $support_map ) ? $support_map : array();
		$pair_counts = array();
		$processed   = 0;

		foreach ( $order_ids as $order_id ) {
			/**
			 * Narrow the loop var — wc_get_orders() was called with return=ids.
			 *
			 * @var int|string $order_id
			 */
			$order = wc_get_order( $order_id );
			if ( ! $order instanceof WC_Order ) {
				$this->log( sprintf( 'process_batch: skipping order %d — not a WC_Order.', (int) $order_id ), 'warning' );
				continue;
			}

			$product_ids = $this->get_order_product_ids( $order );
			if ( count( $product_ids ) < 2 ) {
				++$processed;
				continue;
			}

			foreach ( $product_ids as $pid ) {
				$current             = ( isset( $support_map[ $pid ] ) && is_numeric( $support_map[ $pid ] ) ) ? (int) $support_map[ $pid ] : 0;
				$support_map[ $pid ] = $current + 1;
			}

			$this->accumulate_pairs( $product_ids, $pair_counts );
			++$processed;
		}

		$this->log( sprintf( 'process_batch: processed %d orders, %d distinct pairs accumulated.', $processed, count( $pair_counts ) ) );

		$this->flush_pairs( $pair_counts );

		update_option( 'cartflows_fbt_support_map', $support_map, false );
		update_option( 'cartflows_fbt_offset', $offset + $batch_size, false );
		update_option( 'cartflows_fbt_order_count', $this->get_int_option( 'cartflows_fbt_order_count' ) + $processed, false );

		if ( count( $order_ids ) < $batch_size ) {
			$this->log( 'process_batch: last batch complete, enqueuing finalize.' );
			as_enqueue_async_action( self::HOOK_FINALIZE, array(), 'cartflows' );
		} else {
			$this->log( sprintf( 'process_batch: enqueuing next batch at offset %d.', $offset + $batch_size ) );
			as_enqueue_async_action( self::HOOK_PROCESS_BATCH, array(), 'cartflows' );
		}
	}

	/**
	 * Extract the unique, purchasable parent product IDs from an order.
	 *
	 * @since 2.2.5
	 * @param WC_Order $order Order object.
	 * @return int[]
	 */
	private function get_order_product_ids( $order ) {
		$product_ids = array();

		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			$product_id = $item->get_product_id();
			if ( $product_id > 0 ) {
				$product_ids[ $product_id ] = $product_id;
			}
		}

		return array_values( array_map( 'intval', $product_ids ) );
	}

	/**
	 * Increment in-memory pair counts for every unordered pair in a basket.
	 *
	 * @since 2.2.5
	 * @param int[]                                      $product_ids Distinct product IDs in one order.
	 * @param array<string,array{a:int,b:int,count:int}> $pair_counts Accumulator, passed by reference.
	 * @return void
	 */
	private function accumulate_pairs( $product_ids, &$pair_counts ) {
		sort( $product_ids );
		$total = count( $product_ids );

		for ( $i = 0; $i < $total; $i++ ) {
			for ( $j = $i + 1; $j < $total; $j++ ) {
				$a   = $product_ids[ $i ];
				$b   = $product_ids[ $j ];
				$key = $a . '-' . $b;

				if ( isset( $pair_counts[ $key ] ) ) {
					++$pair_counts[ $key ]['count'];
				} else {
					$pair_counts[ $key ] = array(
						'a'     => $a,
						'b'     => $b,
						'count' => 1,
					);
				}
			}
		}
	}

	/**
	 * Upsert accumulated pair counts into the table (both directions per pair).
	 *
	 * @since 2.2.5
	 * @param array<string,array{a:int,b:int,count:int}> $pair_counts Accumulated pairs.
	 * @return void
	 */
	private function flush_pairs( $pair_counts ) {
		if ( empty( $pair_counts ) ) {
			$this->log( 'flush_pairs: nothing to flush.' );
			return;
		}

		global $wpdb;

		$table = self::get_table_name();
		$now   = current_time( 'mysql', true );
		$rows  = array();
		$args  = array();

		foreach ( $pair_counts as $pair ) {
			$rows[] = '(%d,%d,%d,%s)';
			$rows[] = '(%d,%d,%d,%s)';
			array_push( $args, $pair['a'], $pair['b'], $pair['count'], $now );
			array_push( $args, $pair['b'], $pair['a'], $pair['count'], $now );
		}

		$chunks = array_chunk( $rows, 100 );
		$offset = 0;

		$this->log( sprintf( 'flush_pairs: upserting %d pair rows in %d chunk(s).', count( $rows ), count( $chunks ) ) );

		foreach ( $chunks as $index => $chunk ) {
			$chunk_args = array_slice( $args, $offset, count( $chunk ) * 4 );
			$offset    += count( $chunk ) * 4;
			$values     = implode( ',', $chunk );

			//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$result = $wpdb->query(
				$wpdb->prepare(
					"INSERT INTO $table (product_id, related_id, support, updated_at)
					VALUES $values
					ON DUPLICATE KEY UPDATE support = support + VALUES(support), updated_at = VALUES(updated_at)",
					$chunk_args
				)
			);
			//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare

			if ( false === $result ) {
				$this->log( sprintf( 'flush_pairs: chunk %d upsert failed — %s', (int) $index, $wpdb->last_error ), 'error' );
			}
		}
	}

	/**
	 * Prune weak pairs and compute the lift score for the survivors.
	 *
	 * @since 2.2.5
	 * @return void
	 */
	public function finalize() {
		if ( ! self::is_enabled() ) {
			$this->log( 'finalize aborted: feature disabled.', 'warning' );
			return;
		}

		global $wpdb;

		$table       = self::get_table_name();
		$min_support = $this->get_min_support();
		$total       = max( 1, $this->get_int_option( 'cartflows_fbt_order_count' ) );
		$support_map = get_option( 'cartflows_fbt_support_map', array() );
		$support_map = is_array( $support_map ) ? $support_map : array();

		$this->log( sprintf( 'finalize: starting — total orders %d, min support %d.', $total, $min_support ) );

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE support < %d", $min_support ) );
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

		if ( false === $deleted ) {
			$this->log( 'finalize: prune query failed — ' . $wpdb->last_error, 'error' );
		} else {
			$this->log( sprintf( 'finalize: pruned %d weak pair rows.', (int) $deleted ) );
		}

		$chunk     = 1000;
		$row_count = 0;
		$scored    = 0;

		do {
			//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
			$rows = $wpdb->get_results(
				$wpdb->prepare( "SELECT id, product_id, related_id, support FROM $table WHERE score = 0 LIMIT %d", $chunk ),
				ARRAY_A
			);
			//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

			if ( '' !== $wpdb->last_error ) {
				$this->log( 'finalize: unscored-rows query failed — ' . $wpdb->last_error, 'error' );
				break;
			}

			if ( empty( $rows ) ) {
				break;
			}

			$row_count = count( $rows );

			foreach ( $rows as $row ) {
				$pid       = (int) $row['product_id'];
				$rid       = (int) $row['related_id'];
				$pair      = (int) $row['support'];
				$support_a = ( isset( $support_map[ $pid ] ) && is_numeric( $support_map[ $pid ] ) ) ? (int) $support_map[ $pid ] : 0;
				$support_b = ( isset( $support_map[ $rid ] ) && is_numeric( $support_map[ $rid ] ) ) ? (int) $support_map[ $rid ] : 0;

				$score = self::calculate_lift( $pair, $total, $support_a, $support_b );

				//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$updated = $wpdb->update(
					$table,
					array( 'score' => $score ),
					array( 'id' => (int) $row['id'] ),
					array( '%f' ),
					array( '%d' )
				);
				//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

				if ( false === $updated ) {
					$this->log( sprintf( 'finalize: score update failed for row %d — %s', (int) $row['id'], $wpdb->last_error ), 'error' );
					continue;
				}

				++$scored;
			}
		} while ( $row_count === $chunk );

		$this->log( sprintf( 'finalize: scored %d pair rows.', $scored ) );

		delete_option( 'cartflows_fbt_offset' );
		delete_option( 'cartflows_fbt_order_count' );
		delete_option( 'cartflows_fbt_support_map' );
		update_option( 'cartflows_fbt_last_computed', time(), false );

		if ( function_exists( 'wp_cache_flush_group' ) ) {
			wp_cache_flush_group( 'cartflows_fbt' );
		}

		$this->log( 'finalize: recompute complete, staging options cleared and cache flushed.' );
	}

	// -------------------------------------------------------------------------
	// Read API
	// -------------------------------------------------------------------------

	/**
	 * Get precomputed related product IDs for a single product, best first.
	 *
	 * @since 2.2.5
	 * @param int   $product_id Source product ID.
	 * @param int   $limit      Max results.
	 * @param int[] $exclude    Related IDs to leave out at the query level.
	 * @return array<int,array{id:int,score:float,support:int}>
	 */
	public static function get_related_products( $product_id, $limit = 5, $exclude = array() ) {
		$product_id = absint( $product_id );
		$limit      = max( 1, absint( $limit ) );
		$exclude    = array_values( array_filter( array_map( 'absint', (array) $exclude ) ) );

		if ( ! $product_id ) {
			return array();
		}

		$cache_key = 'related_' . $product_id . '_' . $limit . ( $exclude ? '_' . md5( implode( ',', $exclude ) ) : '' );
		$cached    = wp_cache_get( $cache_key, 'cartflows_fbt' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;
		$table = self::get_table_name();

		$where_exclude = $exclude ? ' AND related_id NOT IN (' . implode( ',', array_fill( 0, count( $exclude ), '%d' ) ) . ')' : '';
		$params        = array_merge( array( $product_id ), $exclude, array( $limit ) );

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- Placeholder count is dynamic (NOT IN list) and matches $params at runtime.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT related_id, score, support FROM $table WHERE product_id = %d{$where_exclude} ORDER BY score DESC, support DESC LIMIT %d",
				$params
			),
			ARRAY_A
		);
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber

		$results = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$results[] = array(
					'id'      => (int) $row['related_id'],
					'score'   => (float) $row['score'],
					'support' => (int) $row['support'],
				);
			}
		}

		wp_cache_set( $cache_key, $results, 'cartflows_fbt', HOUR_IN_SECONDS );

		return $results;
	}
}

if ( function_exists( 'WC' ) ) {
	Cartflows_Pro_Product_Affinity::get_instance();
}
