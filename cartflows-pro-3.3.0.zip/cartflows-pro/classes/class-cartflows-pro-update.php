<?php
/**
 * Update Compatibility
 *
 * @package CartFlows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'Cartflows_Pro_Update' ) ) :

	/**
	 * CartFlows Update initial setup
	 *
	 * @since 1.0.0
	 */
	class Cartflows_Pro_Update {

		/**
		 * Class instance.
		 *
		 * @access private
		 * @var Cartflows_Pro_Update $instance Class instance.
		 */
		private static $instance;

		/**
		 * Initiator
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Whether the embeddings sync was already kicked in this request.
		 *
		 * @var bool
		 * @since x.x.x
		 */
		private static $embeddings_sync_kicked = false;

		/**
		 *  Constructor
		 */
		public function __construct() {
			add_action( 'admin_init', __CLASS__ . '::init' );

			// Core option hook, so the kick needs nothing from the free plugin's auth code.
			add_action( 'add_option_cartflows_auth', __CLASS__ . '::kick_embeddings_sync_after_auth' );
		}

		/**
		 * Init
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public static function init() {

			do_action( 'cartflows_pro_update_before' );

			self::maybe_kick_ai_scheduled_actions();
			self::maybe_kick_embeddings_after_auth();

			// Get auto saved version number.
			$saved_version = get_option( 'cartflows-pro-version', false );

			// Update auto saved version number.
			if ( ! $saved_version ) {
				update_option( 'cartflows-pro-version', CARTFLOWS_PRO_VER );

				// Nothing on a fresh install can predate analytics, so open the window now rather than guessing later.
				Cartflows_Pro_Admin::get_instance()->start_instant_checkout_tracking_window();
				return;
			}

			// If equals then return.
			if ( version_compare( $saved_version, CARTFLOWS_PRO_VER, '=' ) ) {
				return;
			}

			// Update to older version than 1.5.5 version.
			if ( version_compare( $saved_version, '1.5.5', '<' ) ) {
				self::v_1_5_5();
			}

			if ( version_compare( $saved_version, '1.7.0', '<' ) ) {
				update_option( 'wcf_order_bump_migrated', 'no' );
			}

			// For older order bump beta only.
			if ( '1.7.0-beta-1' === $saved_version ) {
				if ( function_exists( 'as_enqueue_async_action' ) ) {
					as_enqueue_async_action( 'cartflows_beta_migrate_order_bump_format' );
					update_option( 'wcf-beta-order-bump-page', 1 );
				}
			}

			if ( version_compare( $saved_version, '1.9.0', '<' ) ) {
				$common_settings = get_option( '_cartflows_common', array() );

				if ( ! isset( $common_settings['pre_checkout_offer'] ) || ( isset( $common_settings['pre_checkout_offer'] ) && empty( $common_settings['pre_checkout_offer'] ) ) ) {
					// Set Pre-checkout offer enabled for older users.
					$common_settings['pre_checkout_offer'] = 'enable';
					update_option( '_cartflows_common', $common_settings );
				}

				update_option( 'wcf_pre_checkout_offer_styles_migrated', 'no' );
			}

			// Update required license key to lowercase. Can be removed after 3 major update.
			if ( version_compare( $saved_version, '1.11.1', '<' ) ) {

				$api_key      = get_option( 'wc_am_client_CartFlows_api_key' );
				$api_key_data = get_option( 'wc_am_client_CartFlows' );

				// Take backup of options.
				update_option(
					'cartflows_license_backup_data',
					array(
						'wc_am_client_cartflows_api_key' => $api_key,
						'wc_am_client_cartflows'         => $api_key_data,
					)
				);

				delete_option( 'wc_am_client_CartFlows_api_key' );
				delete_option( 'wc_am_client_CartFlows' );

				// delete_option() already drops these from the options cache; a global
				// wp_cache_flush() here evicted every other plugin's cache as well.

				if ( $api_key_data ) {

					$new_data = array(
						'wc_am_client_cartflows_api_key' => isset( $api_key_data['wc_am_client_CartFlows_api_key'] ) ? $api_key_data['wc_am_client_CartFlows_api_key'] : $api_key_data['wc_am_client_cartflows_api_key'],
					);

					update_option( 'wc_am_client_cartflows', $new_data );
				}

				if ( $api_key ) {
					update_option( 'wc_am_client_cartflows_api_key', $api_key );
				}
			}

			if ( version_compare( $saved_version, '1.11.7', '<' ) ) {
				update_option( 'wcf_show_flow_analytics_notice', 'yes' );
			}
			// Take the adoption snapshot before the version bump, while the pre-upgrade state is still what we see.
			Cartflows_Pro_Admin::get_instance()->snapshot_instant_checkout_adoption();

			// Update auto saved version number.
			update_option( 'cartflows-pro-version', CARTFLOWS_PRO_VER );

			do_action( 'cartflows_pro_update_after' );
		}

		/**
		 * Run the FBT recompute and product embeddings sync actions immediately,
		 * once ever after install/update, so their data isn't delayed until the first recurring run.
		 *
		 * @since x.x.x
		 * @return void
		 */
		public static function maybe_kick_ai_scheduled_actions() {

			if ( ! function_exists( 'as_enqueue_async_action' ) || wp_installing() ) {
				return;
			}

			if ( 'yes' === get_option( 'cartflows_pro_ai_actions_initial_compute_done' ) ) {
				return;
			}

			$fbt_enabled        = class_exists( 'Cartflows_Pro_Product_Affinity' ) && Cartflows_Pro_Product_Affinity::is_enabled();
			$embeddings_enabled = class_exists( 'Cartflows_Pro_Product_Embeddings_Controller' ) && Cartflows_Pro_Product_Embeddings_Controller::is_enabled();

			// Don't stamp the flag while WooCommerce is inactive, so the kick still fires once it activates.
			if ( ! $fbt_enabled && ! $embeddings_enabled ) {
				return;
			}

			if ( $fbt_enabled ) {
				as_enqueue_async_action( Cartflows_Pro_Product_Affinity::HOOK_RECOMPUTE, array(), 'cartflows' );
			}

			if ( $embeddings_enabled ) {
				self::kick_embeddings_sync();
			}

			update_option( 'cartflows_pro_ai_actions_initial_compute_done', 'yes', false );
		}

		/**
		 * Re-anchor the recurring embeddings sync and run one pass right away.
		 * Also runs on auth success, when the token that the sync needs finally exists.
		 *
		 * @since x.x.x
		 * @return bool Whether the sync is now queued.
		 */
		public static function kick_embeddings_sync() {

			// Both the update path and the auth fail-safe can land in one request; one kick is enough.
			if ( self::$embeddings_sync_kicked ) {
				return true;
			}

			if ( ! function_exists( 'as_enqueue_async_action' ) || wp_installing() ) {
				return false;
			}

			if ( ! class_exists( 'Cartflows_Pro_Product_Embeddings_Controller' ) || ! Cartflows_Pro_Product_Embeddings_Controller::is_enabled() ) {
				return false;
			}

			$controller = Cartflows_Pro_Product_Embeddings_Controller::get_instance();

			// Restart the 2-hour cadence from now, then queue the immediate pass after it so it survives the reschedule.
			$controller->clear_schedule();
			$controller->schedule_events();

			as_enqueue_async_action( Cartflows_Pro_Product_Embeddings_Controller::HOOK_SYNC, array(), 'cartflows' );

			self::$embeddings_sync_kicked = true;

			return true;
		}

		/**
		 * Fail-safe for sites that were already connected before the option hook
		 * could fire — kicks the sync once when a token exists but never triggered one.
		 *
		 * @since x.x.x
		 * @return void
		 */
		public static function maybe_kick_embeddings_after_auth() {

			if ( 'yes' === get_option( 'cartflows_pro_embeddings_auth_kick_done' ) ) {
				return;
			}

			// The raw option is the token store, so this holds on any free-plugin version.
			if ( empty( get_option( 'cartflows_auth' ) ) ) {
				return;
			}

			self::kick_embeddings_sync_after_auth();
		}

		/**
		 * Kick the sync for a freshly saved token and record that it happened,
		 * so the admin_init fail-safe never repeats it.
		 *
		 * @since x.x.x
		 * @return void
		 */
		public static function kick_embeddings_sync_after_auth() {

			// Don't stamp the flag while WooCommerce is inactive, so the fail-safe still fires once it activates.
			if ( ! self::kick_embeddings_sync() ) {
				return;
			}

			update_option( 'cartflows_pro_embeddings_auth_kick_done', 'yes', false );
		}

		/**
		 * Offer orders option.
		 *
		 * @since 1.5.5
		 * @return void
		 */
		public static function v_1_5_5() {

			/* Backward compatible option */
			$old_data = array(
				'separate_offer_orders' => 'merge',
			);

			Cartflows_Helper::update_admin_settings_option( '_cartflows_offer_global_settings', $old_data, false );
		}
	}

	/**
	 * Kicking this off by calling 'get_instance()' method
	 */
	Cartflows_Pro_Update::get_instance();

endif;
