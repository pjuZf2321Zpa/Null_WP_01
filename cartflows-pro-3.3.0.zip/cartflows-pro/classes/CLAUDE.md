# Module: classes

Pro's bootstrap and cross-cutting service layer: constants, the free-plugin gate, the module include list, and the shared singletons the modules reach through `wcf_pro()`.

Read `architecture.md` in this folder before changing this module.

## Rules

- **Nothing here loads before `cartflows_init` and CartFlows ≥ `CARTFLOWS_PRO_REQ_CF_VER`** — anything hooking `plugins_loaded` at priority < 100 cannot assume Pro classes exist. `class-cartflows-pro-loader.php:217,224`
- `wcf_pro()->utils/options/session/wc_common` are only assigned inside `load_helper_files_components()`, and `assets_vars` is not populated until `wp_loaded` — reading it earlier yields `null`. `class-cartflows-pro-loader.php:287-290,233`
- **A gateway registered via `cartflows_offer_supported_payment_gateways` must live inside `CARTFLOWS_PRO_DIR`, `WP_PLUGIN_DIR` or `WPMU_PLUGIN_DIR` (symlinked plugin folders included), must be declared by that same file, and must expose `public static get_instance()` plus `process_offer_payment()` and `is_api_refund()`** — `is_api_refund()` is in the contract because `class-cartflows-pro-refund.php:144,346` call it unguarded, and the factory must be public and static because `call_user_func()` fatals otherwise. The class name itself is not constrained: third-party gateways ship their own file, namespace and class name. Every rejection is logged once per request by `log_gateway_rejection()`; never narrow this to Pro's own directory again. `class-cartflows-pro-gateways.php:130-175`
- **`process_offer_refund()` is deliberately NOT in that contract** — bundled `bacs` and `cod` never implement it because their `is_api_refund()` is `false`, so requiring it would lock both out of offers entirely. The single call site guards with `is_callable()` instead, and a gateway that reports API refunds without the method fails the refund with the ordinary "Refund unsuccessful" response. `class-cartflows-pro-refund.php:144`
- **Offer pricing must never trust a request-supplied product ID** — run it through `validate_offer_product_id()`, which accepts only the configured product or one of its variations. `class-cartflows-pro-utils.php:247-271`
- Use `cartflows_woocommerce_order_review()`, never `woocommerce_order_review()` directly — the wrapper dispatches to the multistep and instant-checkout templates. `class-cartflows-pro-functions.php:216-218`
- The `cartflows_is_active_session` filter **can only deny access, never grant it** — it is applied only inside the `if ( $is_active )` branch. `class-cartflows-pro-session.php:317-319`
- `cartflows_session_data_expire_time` is clamped to 5–120 minutes regardless of what the filter returns. `class-cartflows-pro-session.php:110`
- **`cartflows_get_specific_stats` is public, so `get_cartflows_pro_stats()` must never assume the buckets exist** — it normalises `plugin_data['cartflows']` and its `numeric_values` / `boolean_values` sub-arrays before merging. On PHP 8 an unguarded `array_merge( null, … )` is a `TypeError`, and the payload builds on `init` priority 99 during ordinary visitor requests, so that would be a storefront fatal rather than an admin notice. `class-cartflows-pro-admin.php:95,1071-1122`
- **`cf_analytics_flags` is read-modify-write with no locking**, in the free plugin's `Cartflows_Helper::set_analytics_flag()` and shared by ten Pro call sites — two concurrent requests can lose one flag. Tolerable for one-shot milestones that retry, but never store anything there that must not be lost. `class-cartflows-pro-admin.php:952,988,1016,1019,1027`
- **`Cartflows_Pro_Product_Affinity::calculate_lift()` must never return `0`** — it floors at `0.0001` because `finalize()` pages unscored rows with `WHERE score = 0`. A real zero makes that loop never terminate. `class-cartflows-pro-product-affinity.php:237,528`

## Gotchas

- **`doing_it_wrong_trigger_error` is disabled site-wide, unconditionally** — every plugin's and core's `_doing_it_wrong()` warning is suppressed for the whole site once Pro is active. Debugging unrelated code silently loses signal. `class-cartflows-pro-loader.php:154`
- **`update_session()` reads a cookie it just tried to set.** When the cookie is absent it calls `set_session()` then immediately dereferences `$_COOKIE`, but `setcookie()` does not populate `$_COOKIE` in the same request — so `$key` is `''` and session data is written to a shared transient. `class-cartflows-pro-session.php:121-126`
- `Cartflows_Pro_Session::get_session()` **returns nothing** — it assigns `$data` and falls off the end. Callers wanting data must use `get_data()`. `class-cartflows-pro-session.php:196-203`
- **`array_filter()` on a possibly-undefined variable wedges the migration batch** — a checkout step with no recognised widget reaches the call with the variable unset (PHP 8 `TypeError`), the migrated flag is never written, and Action Scheduler re-queues the same batch forever. `class-cartflows-pro-action-schedular.php:265,182`
- **Explicit load-order requirement, comment-documented**: the analytics helper registry must load *after* the five `analytics-helper/` classes. Reordering breaks `wcf_pro_analytics()`. The relevance engine carries the same kind of note. `class-cartflows-pro-loader.php:483,428`
- **Pro reaches into the free plugin's hook table** to remove `redirect_to_thankyou_page`. If the free plugin renames that method or changes the priority, the removal silently no-ops and shoppers land on the WooCommerce thank-you page instead of the upsell. `class-cartflows-pro-frontend.php:72`
- Same pattern against the vendored licence library — if `$wcam_lib` is null, a stray "API Key" admin menu appears. `class-cartflows-pro-licence.php:121-122`
- **`wp_cache_flush()` — a full object-cache wipe — on three ordinary paths**: version upgrade, licence deactivate, and licence activate. On Redis/Memcached this evicts every other plugin's cache. `class-cartflows-pro-update.php:132`, `class-cartflows-pro-licence.php:364,449`
- `load_gateway()` can return `false`, yet four call sites chain `->` straight onto it — a missing or filtered-out gateway turns the `nopriv` token endpoint into a fatal. `class-cartflows-pro-gateways.php:163,173,265-266`
- The gateway availability check is **commented out** with the reason recorded ("making issue with Mollie Bank Transfer Gateway"), so every supported gateway file is included on every `wp_loaded` regardless of whether the store uses it. `class-cartflows-pro-gateways.php:94-107`
- **Referer query strings are merged *over* the order identifiers** in `may_be_append_query_string()`, so a crafted referer can overwrite `wcf-order` / `wcf-key` / `wcf-sk` in the generated next-step URL. The function is already flagged for deletion. `class-cartflows-pro-utils.php:817,796`
- **The affinity table is TRUNCATEd at the start of every daily recompute**, so FBT recommendations are empty for the whole duration of the batch pipeline, every day. `class-cartflows-pro-product-affinity.php:281`
- A filter callback that terminates the request: `fetch_meta_value()` is hooked to a filter but calls `check_ajax_referer()` + `wp_send_json_error()`. Applying that filter outside AJAX kills the page. `class-cartflows-pro-default-meta.php:49,80-83`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
