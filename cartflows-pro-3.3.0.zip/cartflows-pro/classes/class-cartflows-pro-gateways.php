<?php
/**
 * Cartflows Gateways.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Gateways.
 */
class Cartflows_Pro_Gateways {

	/**
	 * Member Variable
	 *
	 * @var instance
	 */
	private static $instance;

	/**
	 * Member Variable
	 *
	 * @var instance
	 */
	public $gateway_obj = array();

	/**
	 * Gateway keys already logged as rejected in this request.
	 *
	 * @var array<string, bool>
	 */
	private $logged_rejections = array();

	/**
	 *  Initiator
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		// Off-site gateways that recompute their return redirect on "init" (Mollie, PaymentModule.php)
		// only see our listeners if the integrations are already loaded, so load them before init:10.
		add_action( 'init', array( $this, 'load_required_integrations' ), 5 );

		// Retained as a safety net for gateways registered after init; load_gateway() is idempotent.
		add_action( 'wp_loaded', array( $this, 'load_required_integrations' ), 20 );

		add_action( 'wp_ajax_nopriv_cartflows_front_create_express_checkout_token', array( $this, 'generate_express_checkout_token' ), 10 );
		add_action( 'wp_ajax_cartflows_front_create_express_checkout_token', array( $this, 'generate_express_checkout_token' ), 10 );

		add_action( 'wp_ajax_nopriv_cartflows_front_create_ppec_paypal_checkout_token', array( $this, 'generate_ppec_paypal_checkout_token' ), 10 );
		add_action( 'wp_ajax_cartflows_front_create_ppec_paypal_checkout_token', array( $this, 'generate_ppec_paypal_checkout_token' ), 10 );

		/**
		 * Paypal Standard API calls response and process billing agreement creation
		 */
		add_action( 'woocommerce_api_cartflows_paypal', array( $this, 'maybe_handle_paypal_api_call' ) );

		/**
		 * Paypal Express API calls response and process billing agreement creation
		 */
		add_action( 'woocommerce_api_cartflows_ppec_paypal', array( $this, 'maybe_handle_ppec_paypal_api_call' ) );

		$this->load_payment_gateway_notices();

		/**
		 *  Add actions and filters for Angelleye.
		 */
		do_action( 'cartflows_add_offer_payment_gateway_actions' );

	}

	/**
	 * Function to register any notices which are related to payment gateways.
	 *
	 * @since x.x.x
	 *
	 * @return void
	 */
	public function load_payment_gateway_notices() {
		add_filter( 'cartflows_admin_notices', array( $this, 'add_payment_gateways_not_supported_notice' ) );
	}

	/**
	 * Load required gateways.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function load_required_integrations() {

		$gateways = $this->get_supported_gateways();

		/*
		@TODO Get the active payment gateways from DB or from any other function as below function is making issue with Mollie Bank Transfer Gateway.
		$available_payment_methods = array_keys( WC()->payment_gateways->get_available_payment_gateways() );
		*/

		if ( is_array( $gateways ) ) {

			foreach ( $gateways as $key => $gateway ) {
				/** Condition commented out for loading gateways files.
				* if ( in_array( $key, $available_payment_methods, true ) ) {
				* $this->load_gateway( $key );
				*/
				$this->load_gateway( $key );
			}
		}
	}

	/**
	 * Load Gateway.
	 *
	 * @param string $type gateway type.
	 * @since 1.0.0
	 * @return object|false Gateway instance, or false when it cannot be loaded.
	 */
	public function load_gateway( $type ) {

		$gateways = $this->get_supported_gateways();

		if ( ! isset( $gateways[ $type ] ) ) {
			return false;
		}

		$temp_gateway = $gateways[ $type ];
		$class_name   = $temp_gateway['class'];

		// Validated and instantiated earlier in this request.
		if ( isset( $this->gateway_obj[ $class_name ] ) ) {
			return $this->gateway_obj[ $class_name ];
		}

		$gateway_path      = isset( $temp_gateway['path'] ) ? $temp_gateway['path'] : CARTFLOWS_PRO_DIR . 'modules/gateways/class-cartflows-pro-gateway-' . $temp_gateway['file'];
		$real_gateway_path = realpath( $gateway_path );

		if ( false === $real_gateway_path || ! is_file( $real_gateway_path ) ) {
			$this->log_gateway_rejection( $type, 'gateway file was not found', $gateway_path );
			return false;
		}

		// Prevent LFI: the file must live inside CartFlows Pro or an installed plugin.
		if ( ! $this->is_allowed_gateway_path( $gateway_path, $real_gateway_path ) ) {
			$this->log_gateway_rejection( $type, 'gateway file is outside the plugin directories', $real_gateway_path );
			return false;
		}

		include_once $real_gateway_path;

		// Prevent class injection: the class must be the one this file declares.
		if ( ! $this->is_gateway_class_declared_by( $class_name, $real_gateway_path ) ) {
			$this->log_gateway_rejection( $type, 'class "' . $class_name . '" is not an offer gateway declared by that file', $real_gateway_path );
			return false;
		}

		$gateway = call_user_func( array( $class_name, 'get_instance' ) );

		if ( ! is_object( $gateway ) ) {
			$this->log_gateway_rejection( $type, 'get_instance() did not return a gateway object', $real_gateway_path );
			return false;
		}

		$this->gateway_obj[ $class_name ] = $gateway;

		return $gateway;
	}

	/**
	 * Directories a gateway file is allowed to be loaded from.
	 *
	 * Both the raw and the resolved form of each root are kept, so a gateway plugin
	 * symlinked into wp-content/plugins is still recognised. CartFlows Pro's own
	 * directory is listed because Pro is loaded from outside WP_PLUGIN_DIR on
	 * symlinked and path-loaded installs.
	 *
	 * @since x.x.x
	 * @return array<int, string> Normalised paths, each with a trailing slash.
	 */
	private function get_allowed_gateway_roots() {

		$roots = array( CARTFLOWS_PRO_DIR, WP_PLUGIN_DIR );

		if ( defined( 'WPMU_PLUGIN_DIR' ) ) {
			$roots[] = WPMU_PLUGIN_DIR;
		}

		$allowed = array();

		foreach ( $roots as $root ) {
			$allowed[] = trailingslashit( wp_normalize_path( $root ) );

			$real_root = realpath( $root );

			if ( false !== $real_root ) {
				$allowed[] = trailingslashit( wp_normalize_path( $real_root ) );
			}
		}

		return array_unique( $allowed );
	}

	/**
	 * Resolve '.' and '..' without following symlinks, so traversal is still caught.
	 *
	 * @since x.x.x
	 * @param string $path Path to fold.
	 * @return string
	 */
	private function normalize_gateway_path( $path ) {

		$path     = wp_normalize_path( $path );
		$prefix   = 0 === strpos( $path, '/' ) ? '/' : '';
		$resolved = array();

		foreach ( explode( '/', $path ) as $segment ) {

			if ( '' === $segment || '.' === $segment ) {
				continue;
			}

			if ( '..' === $segment ) {
				array_pop( $resolved );
				continue;
			}

			$resolved[] = $segment;
		}

		return $prefix . implode( '/', $resolved );
	}

	/**
	 * Check whether a gateway file sits inside an allowed directory.
	 *
	 * @since x.x.x
	 * @param string $gateway_path      Path as registered.
	 * @param string $real_gateway_path Resolved path of the gateway file.
	 * @return bool
	 */
	private function is_allowed_gateway_path( $gateway_path, $real_gateway_path ) {

		$candidates = array(
			wp_normalize_path( $real_gateway_path ),
			$this->normalize_gateway_path( $gateway_path ),
		);

		foreach ( $this->get_allowed_gateway_roots() as $allowed_root ) {
			foreach ( $candidates as $candidate ) {
				if ( 0 === strpos( $candidate, $allowed_root ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Check that the registered class is the offer gateway the loaded file declares.
	 *
	 * Registering the name of some other class that already exists must not be enough
	 * to get it instantiated, so the class is matched back to the file it came from.
	 *
	 * @since x.x.x
	 * @param string $class_name        Registered gateway class name.
	 * @param string $real_gateway_path Resolved path of the gateway file.
	 * @return bool
	 */
	private function is_gateway_class_declared_by( $class_name, $real_gateway_path ) {

		if ( ! class_exists( $class_name, false ) ) {
			return false;
		}

		// The duck-typed gateway contract the offer charge and the refund path rely on.
		foreach ( array( 'get_instance', 'process_offer_payment', 'is_api_refund' ) as $required_method ) {
			if ( ! method_exists( $class_name, $required_method ) ) {
				return false;
			}
		}

		try {
			$reflection = new ReflectionClass( $class_name );
			$factory    = $reflection->getMethod( 'get_instance' );
		} catch ( ReflectionException $e ) {
			return false;
		}

		// method_exists() also matches non-static and non-public, which call_user_func() fatals on.
		if ( ! $factory->isStatic() || ! $factory->isPublic() ) {
			return false;
		}

		$declaring_file = $reflection->getFileName();

		return false !== $declaring_file && realpath( $declaring_file ) === $real_gateway_path;
	}

	/**
	 * Log why a gateway was not loaded.
	 *
	 * A rejected gateway makes the offer charge fail with no gateway error of its own,
	 * so the reason has to be recorded or it reads as a payment gateway problem.
	 *
	 * @since x.x.x
	 * @param string $type   Gateway key.
	 * @param string $reason Why it was rejected.
	 * @param string $path   Gateway file path involved.
	 * @return void
	 */
	private function log_gateway_rejection( $type, $reason, $path ) {

		// load_required_integrations() runs on every wp_loaded, so log each key once.
		if ( isset( $this->logged_rejections[ $type ] ) ) {
			return;
		}

		$this->logged_rejections[ $type ] = true;

		wcf()->logger->log( 'Offer gateway "' . $type . '" not loaded: ' . $reason . ' - ' . $path );
	}

	/**
	 * Generates express checkout token
	 *
	 * @since 1.0.0
	 * @return void.
	 */
	public function generate_express_checkout_token() {
		$gateway = $this->load_gateway( 'paypal' );

		if ( $gateway ) {
			$gateway->generate_express_checkout_token();
		}
	}

	/**
	 * Generates express checkout token
	 *
	 * @since 1.0.0
	 * @return void.
	 */
	public function generate_ppec_paypal_checkout_token() {
		$gateway = $this->load_gateway( 'ppec_paypal' );

		if ( $gateway ) {
			$gateway->generate_express_checkout_token();
		}
	}

	/**
	 * Get Supported Gateways.
	 *
	 * @since 1.0.0
	 * @return array $supported_gateways Updated Supported payment gateways.
	 */
	public function get_supported_gateways() {

		// Default square version that we require for the CartFlows.
		$wc_square_version = '2.9.1';

		if ( function_exists( 'wc_square' ) ) {
			$wc_square_version = wc_square()->get_version();
		}

		// Return true if greater than 3.0.0 else retur false.
		$is_latest_square = version_compare( $wc_square_version, '3.0.0', '>=' );

		$supported_gateways = array(
			'bacs'                          => array(
				'file'  => 'bacs.php',
				'class' => 'Cartflows_Pro_Gateway_Bacs',
			),
			'cod'                           => array(
				'file'  => 'cod.php',
				'class' => 'Cartflows_Pro_Gateway_Cod',
			),
			'stripe'                        => array(
				'file'  => 'stripe.php',
				'class' => 'Cartflows_Pro_Gateway_Stripe',
			),
			'cpsw_stripe'                   => array(
				'file'  => 'cpsw-stripe.php',
				'class' => 'Cartflows_Pro_Gateway_Cpsw_Stripe',
			),
			'paypal'                        => array(
				'file'  => 'paypal-standard.php',
				'class' => 'Cartflows_Pro_Gateway_Paypal_Standard',
			),
			'ppec_paypal'                   => array(
				'file'  => 'paypal-express.php',
				'class' => 'Cartflows_Pro_Gateway_Paypal_Express',
			),
			'ppcp-gateway'                  => array(
				'file'  => 'paypal-payments.php',
				'class' => 'Cartflows_Pro_Gateway_Paypal_Payments',
			),
			'authorize_net_cim_credit_card' => array(
				'file'  => 'authorize-net.php',
				'class' => 'Cartflows_Pro_Gateway_Authorize_Net',
			),
			'mollie_wc_gateway_creditcard'  => array(
				'file'  => 'mollie-credit-card.php',
				'class' => 'Cartflows_Pro_Gateway_Mollie_Credit_Card',
			),
			'mollie_wc_gateway_ideal'       => array(
				'file'  => 'mollie-ideal.php',
				'class' => 'Cartflows_Pro_Gateway_Mollie_Ideal',
			),
			'square_credit_card'            => array(
				'file'  => $is_latest_square ? 'square.php' : 'square-old.php',
				'class' => $is_latest_square ? 'Cartflows_Pro_Gateway_Square' : 'Cartflows_Pro_Gateway_Square_old',
			),
			'woocommerce_payments'          => array(
				'file'  => 'woocommerce-payments.php',
				'class' => 'Cartflows_Pro_Gateway_Woocommerce_Payments',
			),
			'cppw_paypal'                   => array(
				'file'  => 'cppw-paypal.php',
				'class' => 'Cartflows_Pro_Gateway_Cppw_Paypal',
			),
			'cpsw_stripe_element'           => array(
				'file'  => 'cpsw-stripe-element.php',
				'class' => 'Cartflows_Pro_Gateway_Cpsw_Stripe_Element',
			),
		);

		return apply_filters( 'cartflows_offer_supported_payment_gateways', $supported_gateways );

	}

	/**
	 * Handles paypal API call
	 *
	 * @since 1.0.0
	 * @return void.
	 */
	public function maybe_handle_paypal_api_call() {

		$gateway = $this->load_gateway( 'paypal' );

		if ( $gateway ) {
			$gateway->create_billing_agreement();
			$gateway->process_api_calls();
		}
	}

	/**
	 * Handles ppec_paypal API call
	 *
	 * @since 1.0.0
	 * @return void.
	 */
	public function maybe_handle_ppec_paypal_api_call() {

		$gateway = $this->load_gateway( 'ppec_paypal' );

		if ( $gateway ) {
			$gateway->create_billing_agreement();
			$gateway->process_api_calls();
		}
	}

	/**
	 * Add Payment Gateway not supported notices.
	 *
	 * @since x.x.x
	 * @param array $notices Notices array.
	 * @return array $notices The modified array of notices for the non-supported gateways.
	 */
	public function add_payment_gateways_not_supported_notice( $notices = array() ) {
		$payment_gateway_notice = $this->prepare_gateway_not_supported_notices();

		if ( ! empty( $payment_gateway_notice ) ) {
			$notices[] = $payment_gateway_notice;
		}

		return $notices;
	}

	/**
	 * Prepare the gateway not supported notices to display in-plugin notice.
	 *
	 * @since x.x.x
	 *
	 * @return string $notice The modified and prepared notice for the non supported gateways.
	 */
	public function prepare_gateway_not_supported_notices() {

		$notice                 = '';
		$current_flow_steps     = array();
		$available_gateways     = array();
		$not_supported_gateways = array();

		// Get current funnel ID.
		$flow_id = isset( $_GET['flow_id'] ) ? intval( $_GET['flow_id'] ) : 0; //phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// Return if flow ID is not set.
		if ( empty( $flow_id ) ) {
			return $notice;
		}

		// Get steps of currently selected/opened flow.
		$current_flow_steps = wcf()->flow->get_steps( $flow_id );

		if (
			is_plugin_active( 'woocommerce/woocommerce.php' ) && ! empty( $current_flow_steps )
		) {
			$show_notice = false;

			// Display the notice only for the offer steps such as upsell/downsell.
			foreach ( $current_flow_steps as $step ) {
				if ( 'upsell' === $step['type'] || 'downsell' === $step['type'] ) {
					$show_notice = true;
				}
			}

			// Get supported gateways of CartFlows.
			$supported_gateways = $this->get_supported_gateways();

			// Get the available gateways installed and activated on the website.
			$woo_available_gateways = WC()->payment_gateways->get_available_payment_gateways();

			if ( ! empty( $woo_available_gateways ) && is_array( $woo_available_gateways ) ) {
				foreach ( $woo_available_gateways as $key => $value ) {
					// Some gateways (e.g. Stripe sub-methods like Alipay/Klarna/Affirm) leave method_title empty.
					// Fall back to the customer-facing title, then the gateway id, so the notice never shows blanks.
					$label = ! empty( $value->method_title ) ? $value->method_title : ( ! empty( $value->title ) ? $value->title : $value->id );

					if ( ! empty( $label ) ) {
						$available_gateways[ $key ]['method_title'] = $label;
					}
				}
			}

			if ( $show_notice && $supported_gateways && ! empty( $available_gateways ) && is_array( $available_gateways ) ) {

				foreach ( $available_gateways as $gateway => $gateway_details ) {
					if ( ! array_key_exists( $gateway, $supported_gateways ) ) {
						$not_supported_gateways[] = $gateway_details['method_title'];
					}
				}

				if ( ! empty( $not_supported_gateways ) && is_array( $not_supported_gateways ) ) {
					$not_supported_gateways = implode( ', ', $not_supported_gateways );
					$notice                 = '<div class="wcf-payment-gateway-notice--text"><p class="text-sm text-yellow-700 m-0">' . wp_kses_post(
						sprintf(
						/* translators: %1$s: payment gateway names, %2$s: link start, %3$s: link end */
							__( 'CartFlows Upsell/Downsell offer does not support the %1$s payment gateway. Please find the supported payment gateways %2$shere%3$s.', 'cartflows-pro' ),
							'<span class="capitalize">' . esc_html( $not_supported_gateways ) . '</span>',
							'<span class="font-medium"><a href="https://cartflows.com/docs/supported-payment-gateways-by-cartflows/" class="text-yellow-700 underline" target="_blank" rel="noreferrer">',
							'</a></span>'
						)
					) . '</p></div>';
				}
			}
		}

		// Return the notice string.
		return $notice;

	}
}

/**
 *  Prepare if class 'Cartflows_Pro_Gateways' exist.
 *  Kicking this off by calling 'get_instance()' method
 */
Cartflows_Pro_Gateways::get_instance();
