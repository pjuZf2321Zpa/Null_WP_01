---
module: classes
---

# classes

## Responsibility

Pro's bootstrap and cross-cutting service layer: it defines constants, gates on the free CartFlows plugin, includes every `modules/` loader in a fixed order, and owns the shared singletons the modules call through `wcf_pro()` — session/cookie state, offer step-graph navigation, the payment-gateway registry, licensing, telemetry pixels, migrations, and the FBT affinity table.

Ownership stops at feature behaviour: order bumps, upsell/downsell rendering, checkout, analytics reports and gateway adapters all live in `modules/`. All step/flow/post-meta primitives belong to the free plugin, which this module extends rather than replaces.

## Why it is this way

Pro is an extension that has to reach inside a plugin it does not control. That is why three separate places `remove_filter`/`remove_action` against the free plugin's or a vendor library's registered callbacks by exact method and priority — there is no supported hook for what they need, and each silently no-ops if the other side moves.

The include list is hand-ordered with two comment-documented "must load after" constraints, because several classes register filters that later classes depend on already being attached.
