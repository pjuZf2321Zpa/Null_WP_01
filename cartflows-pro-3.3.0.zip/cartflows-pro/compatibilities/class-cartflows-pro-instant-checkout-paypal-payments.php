<?php
/**
 * WooCommerce PayPal Payments inside the Instant Checkout popup.
 *
 * Compatibility of Plugin: WooCommerce PayPal Payments
 * Plugin URI: https://woocommerce.com/products/woocommerce-paypal-payments/
 *
 * @package cartflows-pro
 * @since x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Puts the PayPal button container into the popup's checkout.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Instant_Checkout_Paypal_Payments {

	/**
	 * Single instance of the class.
	 *
	 * @var Cartflows_Pro_Instant_Checkout_Paypal_Payments|null
	 */
	protected static $instance;

	/**
	 * Whether PayPal is rendering its product-page button right now.
	 *
	 * The product-support filter also gates Pay Later messages, which must keep rendering.
	 *
	 * @var bool
	 */
	private $in_product_button = false;

	/**
	 * Output-buffer level of the buffer stripping SDK v6's product wrapper, or 0 when none is open.
	 *
	 * @var int
	 */
	private $v6_buffer_level = 0;

	/**
	 * SDK v6's express wrapper, exactly as SdkV6Manager::render_wrapper() prints it.
	 *
	 * @var string
	 */
	const V6_PRODUCT_WRAPPER = '#<div class="ppc-button-wrapper">\s*<div id="ppc-button-ppcp-gateway-v6"></div>\s*</div>#';

	/**
	 * Main instance.
	 *
	 * @since x.x.x
	 * @return Cartflows_Pro_Instant_Checkout_Paypal_Payments
	 */
	public static function get_instance() {
		if ( ! self::$instance instanceof self ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since x.x.x
	 */
	public function __construct() {
		add_filter( 'woocommerce_paypal_payments_checkout_button_renderer_hook', array( $this, 'anchor_checkout_button' ) );
		add_filter( 'woocommerce_paypal_payments_product_supports_payment_request_button', array( $this, 'hide_product_button' ) );

		// Before PayPal's own `wp` callback (priority 10), so these land ahead of its button at priority 31.
		add_action( 'wp', array( $this, 'track_product_button' ), 5 );

		// After SDK v6 registers its render hooks (priority 10), to see whether it skipped the checkout.
		add_action( 'wp', array( $this, 'plan_v6_checkout_wrapper' ), 20 );
	}

	/**
	 * Mark the stretch of the product summary where PayPal renders its button.
	 *
	 * PayPal adds the button at priority 31 and Pay Later messages at 30, on the same hook.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function track_product_button() {

		$hook = (string) apply_filters( 'woocommerce_paypal_payments_single_product_renderer_hook', 'woocommerce_single_product_summary' );

		add_action( $hook, array( $this, 'start_product_button' ), 31 );
		add_action( $hook, array( $this, 'end_product_button' ), 32 );
	}

	/**
	 * PayPal's product-page button is about to render.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function start_product_button() {
		$this->in_product_button = true;

		// SDK v6 never reads the product-support filter, so its wrapper is stripped from this stretch instead.
		if ( $this->is_popup_page() && null !== $this->v6_manager() && ob_start( array( $this, 'strip_v6_product_wrapper' ) ) ) {
			$this->v6_buffer_level = ob_get_level();
		}
	}

	/**
	 * PayPal's product-page button has rendered.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function end_product_button() {
		$this->in_product_button = false;

		// Only our own buffer: if another plugin opened one on top, ours is flushed at shutdown, still through the callback.
		if ( $this->v6_buffer_level && ob_get_level() === $this->v6_buffer_level ) {
			ob_end_flush();
		}

		$this->v6_buffer_level = 0;
	}

	/**
	 * Remove SDK v6's product-page wrapper from the buffered product summary.
	 *
	 * It shares #ppc-button-ppcp-gateway-v6 with the popup's container, and v6 draws into the first one.
	 *
	 * @since x.x.x
	 * @param string $buffer Output PayPal printed at its button's priority.
	 * @return string
	 */
	public function strip_v6_product_wrapper( $buffer ) {
		return (string) preg_replace( self::V6_PRODUCT_WRAPPER, '', (string) $buffer );
	}

	/**
	 * Arrange SDK v6's checkout wrapper for the popup when v6 skipped it.
	 *
	 * SDK v6 decides on `wp` from WC()->cart->needs_payment(), before Buy Now has put the product in the cart.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function plan_v6_checkout_wrapper() {

		if ( ! class_exists( 'Cartflows_Pro_Instant_Checkout' ) || ! Cartflows_Pro_Instant_Checkout::is_instant_request() ) {
			return;
		}

		if ( null === $this->v6_manager() || $this->v6_renders_checkout() ) {
			return;
		}

		add_action( 'woocommerce_checkout_after_order_review', array( $this, 'render_v6_checkout_wrapper' ) );
	}

	/**
	 * Print SDK v6's checkout wrapper and gateway rows into the popup's checkout.
	 *
	 * Checked again here, now that the cart holds the product, so v6's own location setting still applies.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function render_v6_checkout_wrapper() {

		if ( ! $this->v6_renders_checkout() ) {
			return;
		}

		$this->call_v6( 'render_wrapper' );
		$this->call_v6( 'render_gateway_wrappers' );
	}

	/**
	 * Whether SDK v6 renders its checkout buttons for the current cart.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private function v6_renders_checkout() {

		$places = $this->call_v6( 'determine_render_places' );

		return is_array( $places ) && ! empty( $places['checkout'] );
	}

	/**
	 * PayPal Payments' SDK v6 manager, or null when the store runs SDK v5.
	 *
	 * PayPal registers the service only while its v6 feature flag is on.
	 *
	 * @since x.x.x
	 * @return object|null
	 */
	private function v6_manager() {

		if ( ! class_exists( '\WooCommerce\PayPalCommerce\PPCP' ) ) {
			return null;
		}

		// container() throws when PayPal's bootstrap bailed out, e.g. on PHP below 7.4 or without WooCommerce.
		try {
			$container = \WooCommerce\PayPalCommerce\PPCP::container();
		} catch ( \Throwable $error ) {
			return null;
		}

		if ( ! method_exists( $container, 'has' ) || ! method_exists( $container, 'get' ) || ! $container->has( 'sdk-v6.manager' ) ) {
			return null;
		}

		$manager = $container->get( 'sdk-v6.manager' );

		return is_object( $manager ) ? $manager : null;
	}

	/**
	 * Call one of SDK v6's manager methods, when v6 is running and has it.
	 *
	 * @since x.x.x
	 * @param string $method Manager method name.
	 * @return mixed Its return value, or null.
	 */
	private function call_v6( $method ) {

		$manager = $this->v6_manager();

		if ( null === $manager ) {
			return null;
		}

		$callback = array( $manager, $method );

		return is_callable( $callback ) ? call_user_func( $callback ) : null;
	}

	/**
	 * Whether the popup is set up on the product page being rendered.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private function is_popup_page() {
		return class_exists( 'Cartflows_Pro_Instant_Checkout' ) && Cartflows_Pro_Instant_Checkout::get_instance()->is_set_up_on_page();
	}

	/**
	 * Move the checkout button container onto a hook the popup's render fires.
	 *
	 * The popup renders over wc-ajax, and payment.php skips woocommerce_review_order_after_payment during AJAX.
	 *
	 * @since x.x.x
	 * @param string $hook Action the container renders on.
	 * @return string
	 */
	public function anchor_checkout_button( $hook ) {

		if ( ! class_exists( 'Cartflows_Pro_Instant_Checkout' ) || ! Cartflows_Pro_Instant_Checkout::is_instant_request() ) {
			return $hook;
		}

		return 'woocommerce_checkout_after_order_review';
	}

	/**
	 * Drop the product-page button where the popup runs PayPal in checkout context, but keep Pay Later.
	 *
	 * Both containers share #ppc-button-ppcp-gateway, and the checkout button renders into the first one on the page.
	 *
	 * @since x.x.x
	 * @param bool $enabled Whether the product-page button renders.
	 * @return bool
	 */
	public function hide_product_button( $enabled ) {

		// Not wp_script_is(): a block theme renders this button before wp_enqueue_scripts runs.
		if ( $this->in_product_button && $this->is_popup_page() ) {
			return false;
		}

		return $enabled;
	}
}

Cartflows_Pro_Instant_Checkout_Paypal_Payments::get_instance();
