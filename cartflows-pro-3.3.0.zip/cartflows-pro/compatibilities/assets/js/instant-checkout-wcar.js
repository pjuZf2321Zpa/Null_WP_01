/**
 * Instant Checkout - Cart Abandonment Recovery bridge.
 *
 * WCAR's tracking script never loads in the popup (it renders through a wc-ajax request), so this
 * posts the popup's email to WCAR's own capture action, making an abandoned popup recoverable, and
 * renders WCAR's GDPR opt-out inside the popup. No-op unless the shim localized wcfInstantWcar.
 *
 * @package
 */
( function ( $ ) {
	'use strict';

	const cfg = window.wcfInstantWcar;

	if ( ! cfg || ! cfg.ajaxurl ) {
		return;
	}

	const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
	let optedOut = false;
	let phoneConsented = false;
	let saveTimer = null;

	const $overlay = () => $( '.wcf-icp-overlay' );

	const email = () => {
		const $field = $overlay().find( '#billing_email' );
		return $field.length ? String( $field.val() || '' ).trim() : '';
	};

	// The consent flag records permission to text the number; it never gates capturing it, matching WCAR.
	const phoneConsent = () =>
		$overlay().find( '#gdpr_phone_consent' ).is( ':checked' );

	const phone = () =>
		String( $overlay().find( '#billing_phone' ).val() || '' );

	const phoneCountryCode = () => {
		const $form = $overlay();
		return String(
			$form.find( '#billing_phone_country_code' ).val() ||
				$form.find( '#shipping_phone_country_code' ).val() ||
				''
		);
	};

	const FIELD_MAP = {
		billing_first_name: 'wcf_name',
		billing_last_name: 'wcf_surname',
		billing_company: 'wcf_billing_company',
		billing_address_1: 'wcf_billing_address_1',
		billing_address_2: 'wcf_billing_address_2',
		billing_city: 'wcf_city',
		billing_state: 'wcf_billing_state',
		billing_postcode: 'wcf_billing_postcode',
		billing_country: 'wcf_country',
		shipping_first_name: 'wcf_shipping_first_name',
		shipping_last_name: 'wcf_shipping_last_name',
		shipping_company: 'wcf_shipping_company',
		shipping_address_1: 'wcf_shipping_address_1',
		shipping_address_2: 'wcf_shipping_address_2',
		shipping_city: 'wcf_shipping_city',
		shipping_state: 'wcf_shipping_state',
		shipping_postcode: 'wcf_shipping_postcode',
		shipping_country: 'wcf_shipping_country',
		order_comments: 'wcf_order_comments',
	};

	const payload = () => {
		const $form = $overlay();
		const data = {
			action: 'cartflows_save_cart_abandonment_data',
			security: cfg.saveNonce,
			wcf_email: email(),
			wcf_phone: phone(),
			wcf_phone_country_code: phoneCountryCode(),
			wcf_post_id: cfg.checkoutId || 0,
		};
		Object.keys( FIELD_MAP ).forEach( ( id ) => {
			data[ FIELD_MAP[ id ] ] = String(
				$form.find( '#' + id ).val() || ''
			);
		} );
		if ( cfg.showPhoneGdpr ) {
			data.wcf_gdpr_phone_consent = phoneConsent() ? 'on' : '';
		}
		return data;
	};

	// The popup's Buy Now cart is already live, so WCAR builds the row from WC()->cart server-side.
	const capture = () => {
		if ( optedOut || ! EMAIL.test( email() ) ) {
			return;
		}
		$.post( cfg.ajaxurl, payload() );
	};

	const scheduleCapture = () => {
		window.clearTimeout( saveTimer );
		saveTimer = window.setTimeout( capture, 500 );
	};

	// GDPR opt-out notice inside the popup, mirroring WCAR's own checkout block.
	const showGdprNotice = () => {
		if ( ! cfg.showGdpr || optedOut ) {
			return;
		}
		const $row = $overlay().find( '#billing_email' ).closest( '.form-row' );
		if ( ! $row.length || $overlay().find( '.wcf-icp-wcar-gdpr' ).length ) {
			return;
		}
		const $notice = $(
			'<div class="wcf-icp-wcar-gdpr"><small><span class="wcf-icp-wcar-gdpr-msg"></span> <a href="#" class="wcf-icp-wcar-gdpr-skip"></a></small></div>'
		);
		$notice.find( '.wcf-icp-wcar-gdpr-msg' ).html( cfg.gdprMessage || '' );
		$notice.find( '.wcf-icp-wcar-gdpr-skip' ).text( cfg.noThanks || '' );
		$row.after( $notice );
	};

	// Phone-consent checkbox after the phone field, mirroring WCAR Pro's own checkout checkbox.
	const showPhoneGdprNotice = () => {
		if ( ! cfg.showPhoneGdpr ) {
			return;
		}
		const $row = $overlay().find( '#billing_phone' ).closest( '.form-row' );
		// Dedupe on the id, not the wrapper: if anything (e.g. WCAR Pro) already placed a consent box in
		// the overlay, defer to it rather than adding a second control that shares #gdpr_phone_consent.
		if (
			! $row.length ||
			$overlay().find( '#gdpr_phone_consent' ).length
		) {
			return;
		}
		// No name attribute: the checkbox is read by id and its state is re-applied on re-open below, so it
		// need not (and should not) ride in the order POST.
		const $block = $(
			'<div class="wcf-icp-wcar-phone-gdpr"><small><input type="checkbox" id="gdpr_phone_consent" value="on" aria-labelledby="wcf-icp-wcar-phone-gdpr-msg"> <span class="wcf-icp-wcar-phone-gdpr-msg" id="wcf-icp-wcar-phone-gdpr-msg"></span></small></div>'
		);
		$block
			.find( '.wcf-icp-wcar-phone-gdpr-msg' )
			.html( cfg.phoneGdprMessage || '' );
		// The module's field-restore skips checkboxes, so re-apply a prior consent ourselves on re-open.
		$block.find( '#gdpr_phone_consent' ).prop( 'checked', phoneConsented );
		$row.after( $block );
	};

	const skipGdpr = ( event ) => {
		event.preventDefault();
		window.clearTimeout( saveTimer );
		// Only opt out and confirm once WCAR actually deleted the row; a stale-nonce 403 must not tell
		// the shopper they're unsubscribed while the row survives and the cron still emails them.
		$.post( cfg.ajaxurl, {
			action: 'cartflows_skip_cart_tracking_gdpr',
			security: cfg.gdprNonce,
		} ).done( () => {
			optedOut = true;
			$overlay()
				.find( '.wcf-icp-wcar-gdpr' )
				.empty()
				.append(
					$( '<small></small>' ).text( cfg.afterNoThanks || '' )
				);
		} );
	};

	// Inject both GDPR notices; each is a no-op if its field is missing or the notice already exists.
	const renderNotices = () => {
		showGdprNotice();
		showPhoneGdprNotice();
	};

	$( document.body )
		.on(
			'blur change',
			'.wcf-icp-overlay form.checkout :input',
			scheduleCapture
		)
		.on( 'change', '.wcf-icp-overlay #gdpr_phone_consent', function () {
			phoneConsented = this.checked;
		} )
		.on( 'click', '.wcf-icp-wcar-gdpr-skip', skipGdpr )
		.on( 'wcf_instant_checkout_opened', ( event, $ov ) => {
			// Prefer the nonces the uncached popup just rendered over the ones localized onto a product
			// page that may have been full-page cached with a value now older than the nonce tick.
			const $scope = $ov && $ov.length ? $ov : $overlay();
			const save = $scope.find( '.wcf-icp-wcar-save-nonce' ).val();
			const gdpr = $scope.find( '.wcf-icp-wcar-gdpr-nonce' ).val();
			if ( save ) {
				cfg.saveNonce = save;
			}
			if ( gdpr ) {
				cfg.gdprNonce = gdpr;
			}
			// Fields are in the overlay by now (fired after the form is adopted and the layout built),
			// so inject the notices here instead of watching the whole document for changes.
			renderNotices();
			// Capture on open (email may be prefilled) and on every checkout refresh, since a bump tick
			// or coupon lives outside the field selector and only blur/change reached the row before.
			scheduleCapture();
		} )
		.on( 'updated_checkout', () => {
			renderNotices();
			scheduleCapture();
		} )
		.on( 'wcf_instant_checkout_closed', () => {
			// The popup handed the cart back; drop any pending capture so it cannot refresh the row
			// against the just-restored (possibly empty) cart, which WCAR would read as a delete.
			window.clearTimeout( saveTimer );
		} );
} )( jQuery );
