---
module: compatibilities
---

# compatibilities

## Responsibility

Holds one self-registering shim per third-party plugin (AffiliateWP, WooCommerce Multi-Currency, WooPayments, Astra Pro, WC Product Bundles, Power Coupons, Cart Abandonment Recovery). Each file adapts CartFlows Pro's own filters and actions to that vendor's API.

Ownership stops at the adapter layer: the module never defines CartFlows behaviour itself — it only re-points, converts, or re-prices values the core modules produce — and it does not decide when it loads. The `class_exists`/`defined` gate lives in the Pro loader.

## Why it is this way

Splitting the vendor gate from the file means each shim can assume its third party is present and skip defensive checks, at the cost that including one directly is unsafe. That trade is why every file self-instantiates: there is no separate init step to get wrong.

The bundle shim is the one place where ordering is a money question rather than a rendering one — WC Product Bundles validates only inside `add_bundle_to_order()`, which runs after capture, so the pre-charge validation and the scoped stock-check filter both exist to close that window.

Two shims adapt vendors into the Instant Checkout popup rather than the standard checkout: Power Coupons (re-anchors its drawer) and Cart Abandonment Recovery. The WCAR shim exists because WCAR's tracking script prints on the checkout page via `wp_footer`, which never runs for the popup (a wc-ajax JSON render on a product page); the shim instead enqueues a small bridge on the product page that posts the shopper's email to WCAR's *own* capture action with a self-minted nonce, so WCAR builds the abandonment row, sets `wcf_session_id`, and clears it on order exactly as for a normal checkout. (The loader-gate timing that makes this fire is a gotcha in `CLAUDE.md`.)
