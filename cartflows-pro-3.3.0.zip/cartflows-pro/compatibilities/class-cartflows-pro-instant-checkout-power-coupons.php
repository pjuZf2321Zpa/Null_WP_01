<?php
/**
 * Power Coupons.
 *
 * Compatibility of Plugin: Power Coupons (drawer) inside the Instant Checkout popup.
 * Plugin URI: https://cartflows.com/
 *
 * @package cartflows-pro
 * @since 3.2.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Bridges the Power Coupons drawer into the Instant Checkout popup.
 *
 * Power Coupons anchors its trigger on woocommerce_review_order_before_payment, which the popup never fires;
 * this shim re-anchors it to a firing hook outside the payment fragment, moves it into the coupon slot, and lifts the drawer above the overlay.
 *
 * @since 3.2.1
 */
class Cartflows_Pro_Instant_Checkout_Power_Coupons {

	/**
	 * Single instance of the class.
	 *
	 * @var Cartflows_Pro_Instant_Checkout_Power_Coupons|null
	 */
	protected static $instance;

	/**
	 * Main instance. Ensures only one instance of the class is loaded.
	 *
	 * @return Cartflows_Pro_Instant_Checkout_Power_Coupons
	 */
	public static function get_instance() {
		if ( ! self::$instance instanceof self ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wc_ajax_wcf_instant_open', array( $this, 'anchor_trigger' ), 5 );
		add_action( 'wp_enqueue_scripts', array( $this, 'bridge_drawer_into_popup' ), 20 );
	}

	/**
	 * Add Power Coupons' own drawer trigger to the popup render.
	 *
	 * Re-anchored to woocommerce_checkout_after_customer_details — a firing hook outside the payment fragment WooCommerce rebuilds on every totals refresh, so the trigger renders once and survives.
	 * Reusing Power Coupons' own callback keeps its show-on-checkout gate; the hook is added only inside this request, so it never reaches a normal checkout.
	 *
	 * @return void
	 */
	public function anchor_trigger() {
		if ( ! class_exists( '\Power_Coupons\Controllers\Checkout_Drawer_Controller' ) ) {
			return;
		}

		$callback = array( \Power_Coupons\Controllers\Checkout_Drawer_Controller::get_instance(), 'render_drawer_button' );

		if ( false === has_action( 'woocommerce_review_order_before_payment', $callback ) ) {
			return;
		}

		add_action( 'woocommerce_checkout_after_customer_details', $callback, 20 );
	}

	/**
	 * Settle the drawer into the popup: move its trigger into the coupon slot and lift it above the overlay.
	 *
	 * The z-index bump keeps the drawer over the popup; the trigger stays hidden until the script re-homes it into the coupon slot so it never flashes.
	 *
	 * @return void
	 */
	public function bridge_drawer_into_popup() {
		if ( ! wp_style_is( 'wcf-icp', 'enqueued' ) || ! wp_style_is( 'power-coupons-drawer', 'enqueued' ) ) {
			return;
		}

		// 1000001 must clear the .wcf-icp-overlay z-index in modules/instant-checkout/assets/css/instant-checkout-base.css.
		$css  = '#power-coupons-drawer{z-index:1000001}';
		$css .= '.wcf-icp-overlay .power-coupons-drawer-trigger-wrapper{display:none}';
		$css .= '.wcf-icp-overlay [data-wcf-icp-coupon] .power-coupons-drawer-trigger-wrapper{display:revert}';
		// The trigger is a full-width card action; win over the coupon-card button rules that size the inline Apply button.
		$css .= '.wcf-icp-overlay [data-wcf-icp-coupon] .power-coupons-view-coupons-btn{inline-size:100%;width:100%}';
		// Space it off the coupon field above and drop Power Coupons' lift-on-hover so it stays put.
		$css .= '.wcf-icp-overlay [data-wcf-icp-coupon] .power-coupons-drawer-trigger-wrapper{margin:12px 0 0}';
		$css .= '.wcf-icp-overlay [data-wcf-icp-coupon] .power-coupons-view-coupons-btn:hover{transform:none;box-shadow:none;opacity:1}';
		wp_add_inline_style( 'power-coupons-drawer', $css );

		if ( wp_script_is( 'wcf-icp', 'enqueued' ) ) {
			wp_add_inline_script( 'wcf-icp', $this->relocation_script() );
		}
	}

	/**
	 * Script that moves the drawer trigger into the popup's coupon slot once the popup is built.
	 *
	 * @return string
	 */
	private function relocation_script() {
		return <<<'JS'
( function ( $ ) {
	$( document.body ).on( 'updated_checkout', function () {
		var $overlay = $( '.wcf-icp-overlay' );
		if ( ! $overlay.length ) {
			return;
		}
		var $slot = $overlay.find( '[data-wcf-icp-coupon]' );
		if ( ! $slot.length || $slot.find( '.power-coupons-drawer-trigger-wrapper' ).length ) {
			return;
		}
		var $trigger = $overlay.find( '.power-coupons-drawer-trigger-wrapper' ).first();
		if ( $trigger.length ) {
			$slot.append( $trigger ).prop( 'hidden', false );
		}
	} );
}( jQuery ) );
JS;
	}
}

/* Kick off the shim. */
Cartflows_Pro_Instant_Checkout_Power_Coupons::get_instance();
