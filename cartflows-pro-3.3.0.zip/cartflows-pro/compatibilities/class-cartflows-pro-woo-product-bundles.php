<?php
/**
 * WooCommerce Product Bundles.
 *
 * Compatibility for Plugin: WooCommerce Product Bundles
 * Plugin URI: https://woocommerce.com/products/product-bundles/
 *
 * Provides bundle product support for CartFlows Pro Upsell and Downsell steps.
 * This class is the single source of truth for all WooCommerce Product Bundles
 * integration logic. It is only loaded when WooCommerce Product Bundles is active.
 *
 * @package cartflows-pro
 * @since 2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Woo_Product_Bundles.
 *
 * Handles WooCommerce Product Bundles compatibility for CartFlows Pro offer steps
 * (Upsell and Downsell). Provides static helper methods and hooks into CartFlows
 * filters and actions to centralise all bundle-specific logic.
 *
 * @since 2.2.0
 */
class Cartflows_Pro_Woo_Product_Bundles {

	/**
	 * Single instance of the class.
	 *
	 * @var Cartflows_Pro_Woo_Product_Bundles
	 * @since 2.2.0
	 */
	protected static $instance;

	/**
	 * Main Cartflows_Pro_Woo_Product_Bundles Instance.
	 *
	 * Ensures only one instance of Cartflows_Pro_Woo_Product_Bundles is loaded.
	 *
	 * @since 2.2.0
	 * @return Cartflows_Pro_Woo_Product_Bundles
	 */
	public static function get_instance() {
		if ( ! self::$instance instanceof self ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 2.2.0
	 */
	public function __construct() {
		// Admin: Make bundle products searchable and selectable in the product selector.
		add_filter( 'cartflows_supported_product_types_for_search', array( $this, 'add_bundle_product_type' ) );

		// Frontend: Inject bundle metadata into the localized JS object on offer pages.
		add_filter( 'cartflows_offer_js_localize', array( $this, 'add_bundle_localize_data' ) );

		// Frontend: Enqueue the bundle price update script on offer pages.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_bundle_scripts' ) );

		// Pricing: Override the default min bundle price with the actual configured price during offer acceptance.
		add_filter( 'cartflows_pro_bundle_offer_price', array( $this, 'calculate_configured_bundle_price' ), 10, 2 );
	}

	// -------------------------------------------------------------------------
	// Hook Callbacks
	// -------------------------------------------------------------------------

	/**
	 * Add 'bundle' to the list of searchable product types in the admin product selector.
	 *
	 * Hooks into the CartFlows free plugin's `cartflows_supported_product_types_for_search`
	 * filter so bundle products appear in the upsell/downsell product search dropdown.
	 *
	 * @since 2.2.0
	 * @param array<int, string> $types Array of supported product type slugs.
	 * @return array<int, string>
	 */
	public function add_bundle_product_type( $types ) {
		$types[] = 'bundle';
		return $types;
	}

	/**
	 * Add bundle-specific data to the cartflows_offer localized JS object.
	 *
	 * Allows the frontend JS to know whether the current offer product is a bundle
	 * and whether it requires user input (i.e. has configurable options).
	 *
	 * @since 2.2.0
	 * @param array<string, mixed> $localize Localized data array for cartflows_offer JS object.
	 * @return array<string, mixed>
	 */
	public function add_bundle_localize_data( $localize ) {
		if ( empty( $localize['product_id'] ) ) {
			return $localize;
		}

		$product = wc_get_product( $localize['product_id'] );

		if ( $product && $product->is_type( 'bundle' ) ) {
			$localize['is_bundle'] = true;
		}

		return $localize;
	}

	/**
	 * Enqueue the bundle price update script on CartFlows offer pages.
	 *
	 * Only runs on upsell/downsell offer step pages whose offer product is a bundle, so
	 * non-bundle offers do not pay for the WC Product Bundles add-to-cart script. Depends
	 * on the main CartFlows Pro frontend script and the WC Product Bundles add-to-cart
	 * script so that the bundle JS object is available when the price listener fires.
	 *
	 * @since 2.2.0
	 * @return void
	 */
	public function enqueue_bundle_scripts() {
		if ( ! _is_wcf_base_offer_type() ) {
			return;
		}

		global $post;

		/*
		 * Skip only when the step's offer product is positively known not to be a bundle.
		 * If it cannot be resolved (flow test mode substitutes a random product) we fail
		 * open and still enqueue, so an offer page never loses its price handling.
		 */
		if ( $post instanceof WP_Post ) {
			$offer_product = self::get_step_offer_product( $post->ID );

			if ( $offer_product && ! self::is_bundle_product( $offer_product ) ) {
				return;
			}
		}

		/**
		 * Utils accessor — cast for the type checker since the loader property is untyped.
		 *
		 * @var Cartflows_Pro_Utils $utils
		 */
		$utils  = wcf_pro()->utils;
		$js_url = $utils->get_js_url( 'bundle-offer' );

		wp_enqueue_script(
			'wcf-pro-bundle-offer',
			$js_url,
			array( 'jquery', 'wcf-pro-frontend-global', 'wc-add-to-cart-bundle' ),
			CARTFLOWS_PRO_VER,
			true
		);
	}

	// -------------------------------------------------------------------------
	// Pricing Helpers
	// -------------------------------------------------------------------------

	/**
	 * Filter callback: return the actual configured bundle price instead of the minimum price.
	 *
	 * Hooked into `cartflows_pro_bundle_offer_price`. When the offer acceptance AJAX request
	 * is active, the bundle form fields are available in $_POST via WC_PB_Cart. We extract
	 * the posted configuration and calculate the actual user-configured total. If no bundle
	 * form data is posted (e.g. frontend display, tracking, shortcodes), we return the
	 * original min price unchanged so that `bundle-offer.js` can update the display dynamically.
	 *
	 * @since 2.2.0
	 * @param float             $price   Default (minimum) bundle price.
	 * @param WC_Product_Bundle $product Bundle product object.
	 * @return float Actual configured price if form data is posted, otherwise the original min price.
	 */
	public function calculate_configured_bundle_price( $price, $product ) {
		$bundle_configuration = self::get_posted_bundle_configuration( $product );
		if ( empty( $bundle_configuration ) ) {
			// No bundle form data posted — frontend display or non-AJAX context.
			return $price;
		}
		return self::calculate_bundle_price_from_configuration( $product, $bundle_configuration );
	}

	/**
	 * Calculate the actual bundle price for a given user configuration.
	 *
	 * Iterates through the bundle configuration — skipping unselected optional items and
	 * non-individually-priced items — and sums up the actual prices of selected items
	 * (using the variation price when a variable child has a specific variation selected,
	 * and applying any per-item WC PB discounts). Mirrors the pricing logic in
	 * WC_PB_Order::add_bundle_to_order().
	 *
	 * For statically-priced bundles (no individually-priced items), the container price
	 * already represents the full bundle price and is returned as-is.
	 *
	 * @since 2.2.0
	 * @param WC_Product_Bundle                $product              Bundle product object.
	 * @param array<int, array<string, mixed>> $bundle_configuration Bundle configuration array from get_posted_bundle_configuration().
	 * @return float Calculated bundle total for the given configuration.
	 */
	public static function calculate_bundle_price_from_configuration( $product, $bundle_configuration ) {
		if ( ! self::is_bundle_product( $product ) ) {
			return (float) $product->get_price();
		}

		// Statically-priced bundles: container price is the full total.
		if ( ! $product->contains( 'priced_individually' ) ) {
			return (float) $product->get_price();
		}

		// Container base price (often 0 for fully individually-priced bundles).
		$total         = (float) $product->get_price();
		$bundled_items = $product->get_bundled_items();

		foreach ( $bundled_items as $bundled_item_id => $bundled_item ) {
			$config = isset( $bundle_configuration[ $bundled_item_id ] ) ? $bundle_configuration[ $bundled_item_id ] : array();

			// Skip optional items the user did not check.
			if ( $bundled_item->is_optional() ) {
				if ( ! isset( $config['optional_selected'] ) || 'yes' !== $config['optional_selected'] ) {
					continue;
				}
			}

			// Non-individually-priced items are included in the container price.
			if ( ! $bundled_item->is_priced_individually() ) {
				continue;
			}

			$qty = isset( $config['quantity'] ) ? absint( $config['quantity'] ) : $bundled_item->get_quantity( 'default' );
			if ( 0 === $qty ) {
				continue;
			}

			// Use the variation product if the child is variable and a variation was selected.
			$child_product = $bundled_item->product;
			if ( ! empty( $config['variation_id'] ) ) {
				$variable_types = array( 'variable', 'variable-subscription' );
				if ( in_array( $child_product->get_type(), $variable_types, true ) ) {
					$variation = wc_get_product( absint( $config['variation_id'] ) );
					if ( $variation ) {
						$child_product = $variation;
					}
				}
			}

			// Apply bundled item discount (matches WC_PB_Order::add_bundle_to_order() logic).
			$discount = $bundled_item->get_discount();
			if ( $discount ) {
				$base_price = $bundled_item->is_discount_allowed_on_sale_price()
					? (float) $child_product->get_price()
					: (float) $child_product->get_regular_price();
				$item_price = $base_price * ( 1.0 - (float) $discount / 100.0 );
			} else {
				$item_price = (float) $child_product->get_price();
			}

			$total += $item_price * $qty;
		}

		return $total;
	}

	// -------------------------------------------------------------------------
	// Static Helpers — called from upsell/downsell markup and orders classes
	// -------------------------------------------------------------------------

	/**
	 * Check whether the given product is a WooCommerce Product Bundle.
	 *
	 * Centralises the guard check (product type + plugin active) that was previously
	 * duplicated across 6 locations in the codebase.
	 *
	 * @since 2.2.0
	 * @param WC_Product|false|null $product WooCommerce product object.
	 * @return bool True if the product is a bundle and WC Product Bundles is active.
	 * @phpstan-assert-if-true WC_Product_Bundle $product
	 */
	public static function is_bundle_product( $product ) {
		return $product && $product->is_type( 'bundle' ) && function_exists( 'WC_PB' );
	}

	/**
	 * Get the offer product configured on an upsell/downsell step.
	 *
	 * Reads the step's own `wcf-offer-product` meta rather than trusting a posted product
	 * ID, so callers always act on the product that will actually be charged and added to
	 * the order.
	 *
	 * @since 2.2.0
	 * @param int $step_id Offer step ID.
	 * @return WC_Product|false Product object, or false when it cannot be resolved.
	 */
	public static function get_step_offer_product( $step_id ) {
		/**
		 * Options helper singleton — declared via magic accessor on the loader.
		 *
		 * @var Cartflows_Pro_Default_Meta $options
		 */
		$options = wcf_pro()->options;

		/**
		 * The 'wcf-offer-product' meta is stored as an array of product IDs even though the shared helper's docblock says string.
		 *
		 * @var array<int, int|string>|string|false $offer_product
		 */
		$offer_product = $options->get_offers_meta_value( absint( $step_id ), 'wcf-offer-product' );
		$product_id    = is_array( $offer_product ) && isset( $offer_product[0] ) ? absint( $offer_product[0] ) : 0;

		if ( ! $product_id ) {
			return false;
		}

		$product = wc_get_product( $product_id );

		return $product ? $product : false;
	}

	/**
	 * Validate a posted bundle configuration before the offer is charged.
	 *
	 * WC PB validates the configuration itself inside WC_PB_Order::add_bundle_to_order(),
	 * but that only runs after the gateway has captured, and it reports failure by returning
	 * a WP_Error. Running the same validation up front lets the offer fail cleanly instead of
	 * charging a customer for a bundle that cannot be written to the order.
	 *
	 * `throw_exception` is forced on so WC PB re-throws instead of pushing a customer-facing
	 * `wc_add_notice()` into the session during what is an AJAX request.
	 *
	 * The 'add-to-order' context deliberately matches the one add_bundle_to_order() uses, so
	 * this can never reject a configuration that the later add would have accepted. WC PB skips
	 * bundled-item stock checks in that context, so `validate_bundled_items_stock()` is attached
	 * for the duration of this call to cover them — otherwise an out-of-stock child could be
	 * sold through an offer and drive its stock negative.
	 *
	 * Non-bundle products pass through untouched.
	 *
	 * @since 2.2.0
	 * @param WC_Product|false|null            $product              Offer product object.
	 * @param int                              $qty                  Offer quantity.
	 * @param array<int, array<string, mixed>> $bundle_configuration Bundle configuration array.
	 * @return true|WP_Error True when the configuration is usable, WP_Error describing the problem otherwise.
	 */
	public static function validate_bundle_configuration( $product, $qty, $bundle_configuration ) {
		if ( ! self::is_bundle_product( $product ) ) {
			return true;
		}

		// Older WC PB releases predate this validator; treat them as "nothing to check".
		if ( ! method_exists( WC_PB()->cart, 'validate_bundle_configuration' ) ) {
			return true;
		}

		/*
		 * Attached only around our own validation call so the bundled-item stock check applies
		 * to offer acceptance without changing WC PB's behaviour for anything else that adds a
		 * bundle to an order (a shop manager editing an order by hand, for instance).
		 */
		add_filter( 'woocommerce_add_to_order_bundle_validation', array( __CLASS__, 'validate_bundled_items_stock' ), 10, 3 );

		try {
			$is_valid = WC_PB()->cart->validate_bundle_configuration(
				$product,
				max( 1, absint( $qty ) ),
				$bundle_configuration,
				array(
					'context'         => 'add-to-order',
					'throw_exception' => true,
				)
			);
		} catch ( Exception $e ) {
			return new WP_Error( 'cartflows_pro_invalid_bundle_configuration', $e->getMessage() );
		} finally {
			remove_filter( 'woocommerce_add_to_order_bundle_validation', array( __CLASS__, 'validate_bundled_items_stock' ), 10 );
		}

		if ( ! $is_valid ) {
			return new WP_Error(
				'cartflows_pro_invalid_bundle_configuration',
				__( 'Please review the options selected for this bundle and try again.', 'cartflows-pro' )
			);
		}

		return true;
	}

	/**
	 * Validate the stock of the items inside a bundle being offered.
	 *
	 * WC PB runs its bundled-item stock check only in the 'add-to-cart' context, so an offer
	 * (which uses 'add-to-order') would otherwise accept a bundle containing an out-of-stock
	 * child and push that child's stock negative. This runs WC PB's own stock manager — already
	 * populated with the posted configuration — so quantities, repeated products and backorder
	 * settings are handled by WC PB rather than re-implemented here.
	 *
	 * @since 2.2.0
	 * @param bool                $is_valid      Whether the configuration is valid so far.
	 * @param mixed               $product_id    Bundle product ID.
	 * @param WC_PB_Stock_Manager $bundled_stock Stock manager holding the configured child items.
	 * @return bool
	 * @throws Exception When a bundled item cannot satisfy the requested quantity.
	 */
	public static function validate_bundled_items_stock( $is_valid, $product_id, $bundled_stock ) {
		if ( ! $is_valid || ! is_object( $bundled_stock ) || ! method_exists( $bundled_stock, 'validate_stock' ) ) {
			return $is_valid;
		}

		return $bundled_stock->validate_stock(
			array(
				'context'         => 'add-to-cart',
				'throw_exception' => true,
			)
		);
	}

	/**
	 * Extract the posted bundle configuration from $_POST.
	 *
	 * Delegates to WC_PB_Cart::get_posted_bundle_configuration() which reads
	 * the bundle form fields (bundle_quantity_*, bundle_variation_id_*, etc.)
	 * directly from the $_POST superglobal. Returns an empty array if the product
	 * is not a bundle or if WC Product Bundles is not active.
	 *
	 * @since 2.2.0
	 * @param WC_Product|false|null $product WooCommerce product object.
	 * @return array<int, array<string, mixed>> Bundle configuration array, or empty array.
	 */
	public static function get_posted_bundle_configuration( $product ) {
		if ( ! self::is_bundle_product( $product ) ) {
			return array();
		}
		return WC_PB()->cart->get_posted_bundle_configuration( $product );
	}

	/**
	 * Add a bundle product to a WooCommerce order.
	 *
	 * Delegates to WC_PB_Order::add_bundle_to_order(), which natively forwards top-level
	 * $args to WC_Order::add_product() for the container line item, and per-child 'args'
	 * inside the configuration array to WC_Order::add_product() for each bundled child
	 * (see the docblock on WC_PB_Order::add_bundle_to_order()).
	 *
	 * When a CartFlows offer discount applies, we set the container's discounted subtotal/total
	 * on $args and zero out each bundled child's args so the container carries the whole
	 * charged amount and the order line-item sum matches the amount captured by the gateway.
	 *
	 * @since 2.2.0
	 * @param WC_Product_Bundle                      $product              Bundle product object.
	 * @param WC_Order|WP_Error|array<string, mixed> $order                WooCommerce order object.
	 * @param int                                    $qty                  Quantity to add.
	 * @param array<int, array<string, mixed>>       $bundle_configuration Bundle configuration array from get_posted_bundle_configuration().
	 * @param array<string, mixed>                   $charged_totals       Optional. { subtotal, total } that the customer is being charged for this bundle offer (post-discount, qty-multiplied, pre-tax).
	 * @return int|WP_Error Order item ID of the container line, or WP_Error when WC PB rejects the configuration. Callers must check with is_wp_error().
	 */
	public static function add_bundle_to_order( $product, $order, $qty, $bundle_configuration, $charged_totals = array() ) {
		$args = array( 'configuration' => $bundle_configuration );

		if ( ! empty( $charged_totals ) ) {
			$args['subtotal'] = isset( $charged_totals['subtotal'] ) ? $charged_totals['subtotal'] : 0;
			$args['total']    = isset( $charged_totals['total'] ) ? $charged_totals['total'] : 0;

			// Zero each bundled child so the container line carries the full charged amount.
			foreach ( $args['configuration'] as $item_id => $item_config ) {
				$item_config['args']               = array(
					'subtotal'     => 0,
					'total'        => 0,
					'subtotal_tax' => 0,
					'total_tax'    => 0,
				);
				$args['configuration'][ $item_id ] = $item_config;
			}
		}

		return WC_PB()->order->add_bundle_to_order( $product, $order, $qty, $args );
	}
}

/**
 * Prepare if class 'Cartflows_Pro_Woo_Product_Bundles' exist.
 * Kicking this off by calling 'get_instance()' method.
 */
Cartflows_Pro_Woo_Product_Bundles::get_instance();
