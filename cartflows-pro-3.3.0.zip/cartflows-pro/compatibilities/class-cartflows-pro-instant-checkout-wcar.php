<?php
/**
 * WooCommerce Cart Abandonment Recovery.
 *
 * Compatibility of Plugin: WooCommerce Cart Abandonment Recovery (WCAR) with the Instant Checkout popup.
 * Plugin URI: https://cartflows.com/
 *
 * @package cartflows-pro
 * @since x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Bridges the Instant Checkout popup into WooCommerce Cart Abandonment Recovery.
 *
 * WCAR tracks abandonment with a script printed on the checkout page; the popup renders through a
 * wc-ajax request on a product page, so that script never loads. This shim enqueues a small bridge
 * on the product page that posts the shopper's email to WCAR's own capture action (with a self-minted
 * nonce), so an abandoned popup produces a recovery record exactly as a normal checkout would.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Instant_Checkout_Wcar {

	/**
	 * Single instance of the class.
	 *
	 * @var Cartflows_Pro_Instant_Checkout_Wcar|null
	 */
	protected static $instance;

	/**
	 * Main instance. Ensures only one instance of the class is loaded.
	 *
	 * @return Cartflows_Pro_Instant_Checkout_Wcar
	 */
	public static function get_instance() {
		if ( ! self::$instance instanceof self ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_bridge' ), 20 );
		add_action( 'woocommerce_after_order_notes', array( $this, 'print_popup_nonces' ) );

		// WCAR's own new_order clear is skipped (the order is still `pending`, which its default
		// wcf_ca_excludes_orders filters out) and its thankyou clear never runs (the funnel thank-you
		// step fires no woocommerce_thankyou action), so run its clear when the order reaches a sale.
		add_action( 'woocommerce_order_status_changed', array( $this, 'clear_on_order' ), 10, 3 );
	}

	/**
	 * Clear the abandonment row once the popup's own order reaches a completed-sale status.
	 *
	 * Fires once, on the first move into a status WCAR treats as a sale (its own wcf_ca_excludes_orders
	 * list), and delegates to WCAR so a recovered order is still marked and its stats/webhooks fire.
	 * Only for orders carrying the popup's marker, so an unrelated order can't consume a live row.
	 *
	 * @param int    $order_id   Order that changed status.
	 * @param string $old_status Status moved from, no wc- prefix.
	 * @param string $new_status Status moved to, no wc- prefix.
	 * @return void
	 */
	public function clear_on_order( $order_id, $old_status, $new_status ) {

		if ( ! class_exists( 'Cartflows_Ca_Tracking' ) || ! class_exists( 'Cartflows_Ca_Helper' ) || ! class_exists( 'Cartflows_Pro_Instant_Checkout' ) ) {
			return;
		}

		$helper   = Cartflows_Ca_Helper::get_instance();
		$tracking = Cartflows_Ca_Tracking::get_instance();

		// Guard the WCAR methods by name too — a rename must not fatal on every order status change store-wide.
		if ( ! is_object( $helper ) || ! is_object( $tracking )
			|| ! method_exists( $helper, 'get_acceptable_order_statuses' )
			|| ! method_exists( $tracking, 'delete_cart_abandonment_data' ) ) {
			return;
		}

		// Only the first transition into a clearing status, so a later change can't re-run the clear.
		$clearing = $helper->get_acceptable_order_statuses();

		if ( ! is_array( $clearing ) || ! in_array( $new_status, $clearing, true ) || in_array( $old_status, $clearing, true ) ) {
			return;
		}

		$order = wc_get_order( $order_id );

		if ( ! $order instanceof WC_Order || empty( $order->get_meta( Cartflows_Pro_Instant_Checkout::ORDER_META ) ) ) {
			return;
		}

		// Matches the row by the WC session's wcf_session_id and marks a recovered order; the order id
		// selects the order whose status just changed.
		$tracking->delete_cart_abandonment_data( $order_id );
	}

	/**
	 * Print fresh capture nonces into the popup's own (uncached) checkout HTML.
	 *
	 * The nonces localized on the product page can be served stale from a full-page cache; the popup
	 * renders through wc-ajax, so a nonce printed here is always current and the bridge prefers it.
	 * Gated to the popup request, so a normal (cacheable) checkout is untouched.
	 *
	 * @return void
	 */
	public function print_popup_nonces() {

		if ( ! class_exists( 'Cartflows_Pro_Instant_Checkout' ) || ! Cartflows_Pro_Instant_Checkout::is_instant_request() ) {
			return;
		}

		if ( ! function_exists( 'wcf_ca' ) || empty( wcf_ca()->utils ) || ! wcf_ca()->utils->is_cart_abandonment_tracking_enabled() ) {
			return;
		}

		printf(
			'<input type="hidden" class="wcf-icp-wcar-save-nonce" value="%s" /><input type="hidden" class="wcf-icp-wcar-gdpr-nonce" value="%s" />',
			esc_attr( wp_create_nonce( 'cartflows_save_cart_abandonment_data' ) ),
			esc_attr( wp_create_nonce( 'cartflows_skip_cart_tracking_gdpr' ) )
		);
	}

	/**
	 * Enqueue the capture bridge on an Instant Checkout product page when WCAR tracking is live.
	 *
	 * Gated the same way the Buy Now button is, plus WCAR's own skip conditions, since WCAR's
	 * enqueue-time gate never runs for the popup.
	 *
	 * @return void
	 */
	public function enqueue_bridge() {

		// The module enqueues its Buy Now script only on a supported product with a resolved step, so
		// piggyback that exact gate (which also covers is_supported_product() and non-ajax) rather than
		// re-deriving has_active_flows() / is_product() / step-not-zero here.
		if ( ! class_exists( 'Cartflows_Pro_Instant_Checkout' ) || ! wp_script_is( 'wcf-icp', 'enqueued' ) ) {
			return;
		}

		// utils is null until WCAR finishes loading (WC missing, or tables not created), yet the loader
		// class and wcf_ca() already exist, so guard the dereference or every product page fatals.
		if ( ! function_exists( 'wcf_ca' ) || empty( wcf_ca()->utils ) || ! wcf_ca()->utils->is_cart_abandonment_tracking_enabled() ) {
			return;
		}

		if ( isset( $_COOKIE['wcf_ca_skip_track_data'] ) || $this->is_ignored_role() ) {
			return;
		}

		// Resolve the step from the product (as the button does) for the recovery-link target.
		$step_id = absint( Cartflows_Pro_Instant_Checkout::resolve_step_id( get_queried_object_id() ) );

		// Honour WCAR's own per-checkout exclude filter, keyed on that step.
		if ( apply_filters( 'woo_ca_exclude_specific_checkout_page', false, $step_id ) ) {
			return;
		}

		$script = CARTFLOWS_PRO_DIR . 'compatibilities/assets/js/instant-checkout-wcar.js';

		wp_enqueue_script(
			'wcf-icp-wcar',
			CARTFLOWS_PRO_URL . 'compatibilities/assets/js/instant-checkout-wcar.js',
			array( 'jquery' ),
			(string) ( file_exists( $script ) ? filemtime( $script ) : CARTFLOWS_PRO_VER ),
			true
		);

		// Phone GDPR is a licensed WCAR Pro feature; mirror its own gate so the popup never shows consent
		// UI the real checkout wouldn't, and read the message with a false default to get WCAR's own copy.
		$phone_gdpr = function_exists( 'wcar_pro_is_active_license' ) && wcar_pro_is_active_license()
			&& 'on' === wcf_ca()->utils->wcar_get_option( 'wcf_ca_phone_gdpr_status' );

		wp_localize_script(
			'wcf-icp-wcar',
			'wcfInstantWcar',
			array(
				'ajaxurl'          => admin_url( 'admin-ajax.php' ),
				'saveNonce'        => wp_create_nonce( 'cartflows_save_cart_abandonment_data' ),
				'gdprNonce'        => wp_create_nonce( 'cartflows_skip_cart_tracking_gdpr' ),
				'showGdpr'         => wcf_ca()->utils->is_gdpr_enabled(),
				'gdprMessage'      => wcf_ca()->utils->wcar_get_option( 'wcf_ca_gdpr_message' ),
				'showPhoneGdpr'    => $phone_gdpr,
				'phoneGdprMessage' => $phone_gdpr ? (string) wcf_ca()->utils->wcar_get_option( 'wcf_ca_phone_gdpr_message', false ) : '',
				'noThanks'         => __( 'No Thanks', 'cartflows-pro' ),
				'afterNoThanks'    => __( 'You won\'t receive further emails from us, thank you!', 'cartflows-pro' ),
				'checkoutId'       => $step_id,
			)
		);
	}

	/**
	 * Whether the current user's role is in WCAR's ignored-users list.
	 *
	 * @return bool
	 */
	private function is_ignored_role() {

		$ignored = get_option( 'wcf_ca_ignore_users' );

		if ( empty( $ignored ) || ! is_array( $ignored ) ) {
			return false;
		}

		$roles = wp_get_current_user()->roles;
		$role  = array_shift( $roles );

		return ! empty( $role ) && in_array( $role, $ignored, true );
	}
}

/* Kick off the shim. */
Cartflows_Pro_Instant_Checkout_Wcar::get_instance();
