// Free-plugin styles are compiled and enqueued by the free build — skip them here.
module.exports = function () {
	return 'export default {};';
};
