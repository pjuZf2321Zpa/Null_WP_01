/**
 * CartFlows Pro - Bundle Offer Price Update Handler
 *
 * Listens for WooCommerce Product Bundles price recalculation events on CartFlows
 * upsell/downsell offer pages and updates the displayed offer price accordingly.
 *
 * Mirrors the variation price update pattern in frontend.js (wcf_offer_variation_shortcode).
 *
 * @package
 * @since 2.2.0
 */

( function ( $ ) {
	'use strict';

	/**
	 * Read the offer discount from the localized data.
	 *
	 * @return {Object|null} { type, value } for a usable discount, otherwise null.
	 */
	const get_offer_discount = function () {
		if ( 'undefined' === typeof cartflows_offer ) {
			return null;
		}

		const type = cartflows_offer.discount_type;
		const value = parseFloat( cartflows_offer.discount_value );

		if (
			! isFinite( value ) ||
			value <= 0 ||
			( 'discount_percent' !== type && 'discount_price' !== type )
		) {
			return null;
		}

		return { type, value };
	};

	/**
	 * Apply an offer discount to an amount, never returning less than zero.
	 *
	 * @param {number}      amount   Amount to discount.
	 * @param {Object|null} discount Discount returned by get_offer_discount().
	 * @return {number} Discounted amount.
	 */
	const apply_offer_discount = function ( amount, discount ) {
		if ( ! discount ) {
			return amount;
		}

		const discounted =
			'discount_percent' === discount.type
				? amount - ( amount * discount.value ) / 100
				: amount - discount.value;

		return discounted > 0 ? discounted : 0;
	};

	/**
	 * Format an amount using the store's WooCommerce currency settings.
	 *
	 * wc_pb_price_format() ships with the 'wc-add-to-cart-bundle' script this file depends
	 * on, and honours currency position, separators, decimals and trim-zeros. The manual
	 * fallback only runs if that script is ever unavailable.
	 *
	 * @param {number} amount Amount to format.
	 * @return {string} Price HTML.
	 */
	const format_offer_price = function ( amount ) {
		if ( 'function' === typeof window.wc_pb_price_format ) {
			return window.wc_pb_price_format( amount );
		}

		const symbol =
			'undefined' !== typeof cartflows_offer
				? cartflows_offer.currency_symbol
				: '';

		return (
			'<span class="woocommerce-Price-amount amount">' +
			symbol +
			amount.toFixed( 2 ) +
			'</span>'
		);
	};

	/**
	 * Restore any attribute select that WC PB cleared even though its variation resolved.
	 *
	 * WC Product Bundles can auto-resolve single-option variable child products and, as a
	 * side-effect of its recalculation cycle, reset the visible <select> to the placeholder
	 * while keeping the resolved ID in the matching hidden 'bundle_variation_id_*' field.
	 * The value is restored silently — without triggering 'change' — so we do not re-enter
	 * the WC PB resolution loop.
	 *
	 * @param {Object} $bundle_form The bundle form jQuery object.
	 */
	const restore_resolved_selects = function ( $bundle_form ) {
		$bundle_form
			.find( 'input[name^="bundle_variation_id_"]' )
			.each( function () {
				if ( ! $( this ).val() ) {
					return; // Variation not resolved yet — nothing to restore.
				}

				const nameMatch = $( this )
					.attr( 'name' )
					.match( /bundle_variation_id_(\d+)/ );

				if ( ! nameMatch ) {
					return;
				}

				// Anchor on the end of the name: a '*=' match would also pick up other
				// bundled items whose IDs merely end with these digits (1 vs 11).
				$bundle_form
					.find( 'select[name$="_' + nameMatch[ 1 ] + '"]' )
					.each( function () {
						if ( ! $( this ).val() ) {
							const savedVal = $( this ).data(
								'wcf_bundle_saved_val'
							);

							if ( savedVal ) {
								$( this ).val( savedVal );
							}
						}
					} );
			} );
	};

	/**
	 * Update the offer price display for the current bundle configuration.
	 *
	 * The server discounts pre-tax prices and then re-applies tax for display, so the
	 * discount is applied to the ex-tax total and the displayed total is scaled by the same
	 * ratio. Using totals.price directly would subtract a flat discount from a tax-inclusive
	 * figure and show more than the customer is actually charged.
	 *
	 * @param {Object} $bundle_form The bundle form jQuery object.
	 * @param {Object} bundle       Bundle object supplied by WC Product Bundles.
	 */
	const update_offer_price = function ( $bundle_form, bundle ) {
		const $price_inner = $( '.wcf-offer-price .wcf-offer-price-inner' );

		if ( ! $price_inner.length ) {
			return;
		}

		// Keep the server-rendered markup so it can be put back verbatim whenever the
		// configuration is not purchasable.
		if ( undefined === $price_inner.data( 'wcf_server_price_html' ) ) {
			$price_inner.data( 'wcf_server_price_html', $price_inner.html() );
		}

		/*
		 * While required options are unset WC PB reports a zero total and marks its
		 * add-to-cart button 'disabled'. Restore the server-rendered price (the bundle's
		 * minimum) rather than showing a total for a configuration that cannot be bought —
		 * with a flat discount that would otherwise render as a negative amount. This also
		 * covers a configuration that was valid and has since been reset, where leaving the
		 * last rendered total on screen would advertise a price the offer will refuse.
		 */
		if (
			$bundle_form
				.find( '.bundle_add_to_cart_button' )
				.hasClass( 'disabled' )
		) {
			$price_inner
				.html( $price_inner.data( 'wcf_server_price_html' ) )
				.show();
			return;
		}

		const totals = bundle.price_data.totals;
		const display_total = parseFloat( totals.price );

		if ( ! isFinite( display_total ) ) {
			return;
		}

		/*
		 * The server applies the offer discount to the raw product price, which is
		 * tax-inclusive when the store enters prices with tax and tax-exclusive otherwise.
		 * Discount the matching WC PB total so a flat discount is not subtracted from a
		 * differently-taxed figure, then scale the displayed total by the same ratio.
		 */
		const prices_include_tax =
			!! window.wc_bundle_params &&
			'yes' === window.wc_bundle_params.prices_include_tax;

		const raw_total = parseFloat(
			prices_include_tax ? totals.price_incl_tax : totals.price_excl_tax
		);
		const discount_base = isFinite( raw_total ) ? raw_total : display_total;

		const discounted_base = apply_offer_discount(
			discount_base,
			get_offer_discount()
		);

		const ratio = discount_base > 0 ? discounted_base / discount_base : 0;
		const custom_price = display_total * ratio;

		// Same markup as the product_price() shortcode, so offer step styling applies.
		let price_html = '';

		if ( display_total !== custom_price ) {
			price_html +=
				'<span class="wcf-regular-price del">' +
				format_offer_price( display_total ) +
				'</span>';
			price_html +=
				'<span class="wcf-discount-price">' +
				format_offer_price( custom_price ) +
				'</span>';
		} else {
			price_html +=
				'<span class="wcf-regular-price">' +
				format_offer_price( custom_price ) +
				'</span>';
		}

		// The shortcode renders the flat-shipping disclosure inside this element; the fee is
		// still charged, so carry it across instead of discarding it.
		const $shipping = $price_inner.find( '.wcf-offer-shipping-fee' );

		if ( $shipping.length ) {
			price_html += $shipping.prop( 'outerHTML' );
		}

		$price_inner.html( price_html ).show();
	};

	/**
	 * Save a bundled attribute select's value whenever the user changes it, so it can be
	 * restored if a later recalculation clears it.
	 */
	$( document ).on(
		'change',
		'.bundle_form select[name^="bundle_attribute_"]',
		function () {
			if ( $( this ).val() !== '' ) {
				$( this ).data( 'wcf_bundle_saved_val', $( this ).val() );
			}
		}
	);

	/**
	 * Handle the end of each WC Product Bundles recalculation cycle: restore any cleared
	 * selects, then refresh the offer price for the resulting configuration.
	 */
	$( document ).on(
		'woocommerce-product-bundle-updated-totals',
		'.bundle_form .bundle_data',
		function ( event, bundle ) {
			const $bundle_form = $( this ).closest( '.bundle_form' );

			restore_resolved_selects( $bundle_form );

			if (
				! bundle ||
				! bundle.price_data ||
				! bundle.price_data.totals
			) {
				return;
			}

			update_offer_price( $bundle_form, bundle );
		}
	);
} )( jQuery );
