# Module: bricks

Pro's Bricks integration: seven offer elements, nine `{wcf_*}` dynamic-data tags, extra controls on the free checkout element, and default Bricks content seeded on offer-step creation.

Read `architecture.md` in this folder before changing this module.

## Rules

- **A new element must be added to `get_module_list()` and live at `modules/bricks/elements/<file>.php`** — registration iterates that hardcoded list and builds the path by concatenation, so a file dropped in `elements/` is never registered. `class-cartflows-pro-bricks-elements-loader.php:60-69,116-119`
- **Never `new Cartflows_Pro_Bricks_Elements_Loader()`** — its constructor is `public` (unlike the other two singletons) and adds hooks directly, so a second instantiation double-registers them. `class-cartflows-pro-bricks-elements-loader.php:45-52`
- Every control must declare a `group` that `set_control_groups()` actually registers — the variation element violates its own rule. `elements/class-cartflows-pro-bricks-offer-product-variation.php:80,132-137`
- **Nestable child `name` values must match the elements' `$name` properties** — the layout hardcodes five of them, so renaming any `$name` silently breaks the default layout. `elements/class-cartflows-pro-bricks-upsell-layout.php:79,113,128`
- New dynamic tags must be added to `dynamic_tags_pro()`, not just `parse_tag()` — the value getter gates on the registered slug list. `class-cartflows-pro-bricks-dynamic-data.php:188-193`
- The checkout controls hook at **priority 98**; anything later that replaces rather than merges the array drops them. `elements/class-cartflows-pro-bricks-checkout-form-extended.php:60-61`
- **New wrapper styles must be written for both class schemes** — the element path emits `.cartflows-pro-bricks__offer-*`, the dynamic-tag path emits `.cartflows-bricks-offer-*`, and the CSS pairs them selector-by-selector. `widgets-css/frontend.css:7-8`

## Gotchas

- **The upsell/downsell flexslider enqueue is dead code** — it runs on `init` where the main query has not run, so `get_the_ID()` is `false` and the branch never fires. Product-image galleries depend on some other path enqueuing flexslider. `class-cartflows-pro-bricks-elements-loader.php:46,103-115`
- **`cartflows-pro-bricks-style` is enqueued unconditionally on `init`** — on every front-end *and* admin request, regardless of whether the page uses Bricks. `class-cartflows-pro-bricks-elements-loader.php:101`
- `init` priority **999** is an undocumented ordering requirement: Bricks must have booted its element registry first, and lowering it makes the guard fail and silently skip all seven elements. `class-cartflows-pro-bricks-elements-loader.php:46,96-98`
- Bricks constants are used with **no `defined()` guard** — if the saved page builder is `bricks-builder` while the theme is inactive, creating an offer step hits undefined constants. `class-cartflows-pro-bricks-elements-loader.php:132-142`
- Seed JSON failure is swallowed: a missing importer file leaves `json_decode('')` returning `null`, which is still written to post meta — an empty Bricks page rather than no seeding. `class-cartflows-pro-bricks-elements-loader.php:131,137-142`
- **Dynamic tag modifiers break parsing** — the `:` suffix is stripped for the lookup but the *unstripped* tag is passed on, so `{wcf_product_title:something}` passes validation and then prints the raw tag string. `class-cartflows-pro-bricks-dynamic-data.php:189,196`
- `parse_tag()` returns `null` when the offer product is empty, so the render filter hands back `null` instead of the string it was given — a broken filter contract, not just an empty render. `class-cartflows-pro-bricks-dynamic-data.php:136-138`
- **Offer accept/reject tags return `'?class=wcf-up-offer-yes'`, not URLs**, and the default layout feeds them straight into a button link. Anything that URL-normalizes or escapes that value kills the accept/reject buttons. `class-cartflows-pro-bricks-dynamic-data.php:166-170`
- **`dynamic_filters()` registers closures on every invocation and never removes them** — with two checkout elements on a page, the later one's settings win for *all* checkout meta reads for the rest of the request, including reads outside the element. `elements/class-cartflows-pro-bricks-checkout-form-extended.php:235-243`
- Product name, description and short description are concatenated into markup **unescaped**. `class-cartflows-pro-bricks-dynamic-data.php:142-145`
- `class-cartflows-pro-bricks-checkout-form-extended.php` is the **only file in the module without the `ABSPATH` guard**, and it self-instantiates. `elements/class-cartflows-pro-bricks-checkout-form-extended.php:1-13,330`
- Two of the variation element's four controls declare a group the element never registers, so their settings are unreachable in the builder panel; and the quantity element's `alignment` CSS targets an **Elementor** class the render never emits. `elements/class-cartflows-pro-bricks-offer-product-variation.php:80`, `elements/class-cartflows-pro-bricks-offer-product-quantity.php:76`
- Variation styling CSS only covers the dynamic-tag class, with no element-path counterpart — unlike every other pair in the file, so the variation *element* renders unstyled. `widgets-css/frontend.css:26,54`
- Elements define no `render_builder()`, so the builder canvas executes the live shortcodes; every element's docblock notes this fallback. `elements/class-cartflows-pro-bricks-offer-product-title.php:118-122`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan`
