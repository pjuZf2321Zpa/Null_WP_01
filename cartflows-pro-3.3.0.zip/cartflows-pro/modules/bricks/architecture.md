---
module: bricks
---

# bricks

## Responsibility

Registers CartFlows Pro's Bricks-builder integration: seven offer/upsell `\Bricks\Element` subclasses (product title/price/description/image/quantity/variation plus a nestable layout), nine `{wcf_*}` dynamic-data tags, extra controls injected into the free plugin's `bricks-checkout-form` element, and default Bricks page content seeded on upsell/downsell step creation.

Ownership stops at Bricks-side registration and markup wrappers — the actual offer data and HTML come from the offer shortcodes, and checkout behaviour is only nudged via `cartflows_checkout_meta_*` filters.

## Why it is this way

There are **two parallel render paths** — the element path and the dynamic-tag path — and they emit different CSS class schemes, which is why the stylesheet pairs selectors rather than sharing them. Missing one half of a pair is the most common way styling silently disappears here.

Element registration sits at `init` priority 999 because Bricks builds its own element registry on `init`, and the checkout extension works by registering closures on free-plugin meta filters that it never removes.
