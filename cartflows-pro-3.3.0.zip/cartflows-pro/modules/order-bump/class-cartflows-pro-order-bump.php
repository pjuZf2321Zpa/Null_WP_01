<?php
/**
 * Order Bump module loader.
 *
 * Mirrors the layout of modules/ab-test/class-cartflows-pro-ab-test.php — defines a DIR
 * constant, eagerly requires the module's classes, and kicks off via get_instance().
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Module-scoped path constant — used by every include below and by checkout-markup.php for OB dynamic CSS.
define( 'CARTFLOWS_PRO_ORDER_BUMP_DIR', CARTFLOWS_PRO_DIR . 'modules/order-bump/' );

/**
 * Order Bump module bootstrap.
 *
 * @since 3.1.3
 */
class Cartflows_Pro_Order_Bump {


	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Loads schema + frontend + rules classes that previously lived in modules/checkout/.
	 * Wrapped in the existing Plus/Pro feature guard to preserve the original gating.
	 */
	public function __construct() {

		// Schema lives here as the new single source of truth for the OB field map.
		require_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-meta.php';

		// Skin registry — feeds the admin skin picker and names the front-end template.
		require_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-skins.php';

		// Frontend product + visibility rules are gated to Plus/Pro plans — same as before.
		if ( defined( 'CARTFLOWS_PRO_PLUGIN_TYPE' ) && in_array( CARTFLOWS_PRO_PLUGIN_TYPE, array( 'plus', 'pro' ), true ) ) {
			require_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-product.php';
			require_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-rules.php';
			// CF-1154 Phase 3.2: A/B factory — variant resolution, cookie pinning, impression/conversion counters.
			require_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-ab-factory.php';
			// AI Auto — resolves a bump's product per visitor from the admin's pool.
			require_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-ai-resolver.php';
			// AI copy generation for the bump's visitor-facing text.
			require_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-ai-copy.php';
		}
	}
}

/**
 * Kick off the module immediately on file include.
 */
Cartflows_Pro_Order_Bump::get_instance();
