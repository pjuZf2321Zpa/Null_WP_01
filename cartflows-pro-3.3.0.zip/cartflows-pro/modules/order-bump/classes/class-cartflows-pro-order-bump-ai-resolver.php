<?php
/**
 * Order Bump — AI Auto product resolver.
 *
 * Mode 3: instead of one static product, the admin defines a pool and the
 * most relevant member is chosen per visitor from what is in their cart.
 *
 * Two properties matter more than the choice itself:
 *
 * 1. STABILITY. The bump array is re-read from post meta on the render pass, on every
 *    update_order_review fragment refresh, on add-to-cart and again when the order is
 *    validated. Resolving independently on each of those would let a visitor be shown
 *    product A, have product B added, and then fail validation. So a pick is computed
 *    once, stored in the WC session against a signature of the cart, and reused — and
 *    once the visitor has accepted the bump it is locked outright.
 *
 * 2. COST. Ranking runs through the embeddings re-rank, which reads and scores the whole
 *    embeddings table per source product. That must never happen more than once per
 *    session per cart state, which is exactly what the stored pick guarantees.
 *
 * @package CartFlows
 * @since   x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Order_Bump_Ai_Resolver.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Order_Bump_Ai_Resolver {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * WC session key holding the per-bump picks.
	 *
	 * @var string
	 */
	const SESSION_KEY = 'wcf_ai_ob_picks';

	/**
	 * The product_mode value this resolver owns.
	 *
	 * @var string
	 */
	const MODE = 'auto';

	/**
	 * Per-request memo, so the three meta-load points don't each re-read the session.
	 *
	 * @var array<string, array{product_id:int, row:array<string, mixed>, static?:bool}>
	 */
	private $memo = array();

	/**
	 * Initiator.
	 *
	 * @since x.x.x
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Resolve every AI Auto row in a set of order bumps.
	 *
	 * Rows in any other mode are returned untouched, so this is safe to call on the
	 * raw meta wherever it is loaded.
	 *
	 * @since x.x.x
	 * @param int                              $checkout_id Checkout step ID.
	 * @param array<int, array<string, mixed>> $bumps       Order bump rows.
	 * @return array<int, array<string, mixed>> Same shape as the input.
	 */
	public function resolve_bumps( $checkout_id, $bumps ) {

		if ( empty( $bumps ) ) {
			return $bumps;
		}

		foreach ( $bumps as $index => $bump ) {
			if ( $this->is_auto( $bump ) ) {
				$bumps[ $index ] = $this->resolve_one( $checkout_id, $bump );
			}
		}

		return $bumps;
	}

	/**
	 * Whether a bump row is in AI Auto mode.
	 *
	 * @since x.x.x
	 * @param mixed $bump Bump row.
	 * @return bool
	 */
	public function is_auto( $bump ) {
		return is_array( $bump ) && isset( $bump['product_mode'] ) && self::MODE === $bump['product_mode'];
	}

	/**
	 * Put a chosen product onto a single AI Auto bump row.
	 *
	 * Leaves `product` empty when nothing in the pool can be sold, which the existing
	 * render and cart guards already treat as "no bump" — the visitor sees nothing
	 * rather than something broken.
	 *
	 * @since x.x.x
	 * @param int                  $checkout_id Checkout step ID.
	 * @param array<string, mixed> $bump        Bump row.
	 * @return array<string, mixed>
	 */
	private function resolve_one( $checkout_id, $bump ) {

		$ob_id = isset( $bump['id'] ) && is_scalar( $bump['id'] ) ? (string) $bump['id'] : '';

		if ( '' === $ob_id ) {
			return $bump;
		}

		$key = $checkout_id . ':' . $ob_id;

		if ( ! isset( $this->memo[ $key ] ) ) {
			$this->memo[ $key ] = $this->choose( $key, $ob_id, $bump );
		}

		$chosen = $this->memo[ $key ];

		if ( empty( $chosen['product_id'] ) ) {
			// Nothing sellable and no usable static product — suppress the bump.
			$bump['product'] = '';
			return $bump;
		}

		if ( ! empty( $chosen['static'] ) ) {
			// Pool exhausted: the bump's own configured product, image and discount stand.
			return $bump;
		}

		return $this->apply_row( $bump, $chosen['product_id'], $chosen['row'] );
	}

	/**
	 * Decide which pool member this visitor should see.
	 *
	 * @since x.x.x
	 * @param string               $key   Session store key (checkout_id:ob_id).
	 * @param string               $ob_id Order bump ID.
	 * @param array<string, mixed> $bump  Bump row.
	 * @return array{product_id:int, row:array<string, mixed>, static?:bool}
	 */
	private function choose( $key, $ob_id, $bump ) {

		$empty = array(
			'product_id' => 0,
			'row'        => array(),
		);

		if ( ! class_exists( 'Cartflows_Pro_Product_Relevance' ) ) {
			return $empty;
		}

		$engine    = Cartflows_Pro_Product_Relevance::get_instance();
		$pool      = $this->pool_index( $bump );
		$static    = isset( $bump['product'] ) ? absint( $bump['product'] ) : 0;
		$signature = $this->cart_signature();

		// 1. Already in the cart: the accepted line is the source of truth and never moves.
		// Map the cart line (which may be a variation) back to its pool key so variable
		// products lock too, and honour an accepted static fallback (not a pool member).
		$locked = $this->locked_product_id( $ob_id );
		if ( $locked ) {
			$locked_key = $this->pool_key_for( $locked, $pool );
			if ( $locked_key && $engine->is_offerable( $locked_key ) ) {
				return array(
					'product_id' => $locked_key,
					'row'        => $pool[ $locked_key ],
				);
			}
			if ( $static && ( $locked === $static || $this->parent_of( $locked ) === $static ) && $engine->is_offerable( $static ) ) {
				return array(
					'product_id' => $static,
					'row'        => array(),
					'static'     => true,
				);
			}
		}

		// 2. A pick was already shown this session — keep it stable so the product the
		// visitor saw is the product they accept, as long as it can still be sold.
		$stored = $this->get_stored( $key );
		if ( isset( $stored['product_id'] ) ) {
			$stored_id = absint( $stored['product_id'] );

			if ( 0 === $stored_id ) {
				// Negative cache: nothing was sellable for this exact cart, so don't
				// re-sweep the pool on every fragment refresh of the same cart.
				if ( isset( $stored['cart_hash'] ) && $stored['cart_hash'] === $signature ) {
					return $empty;
				}
			} elseif ( $engine->is_offerable( $stored_id ) ) {
				if ( isset( $pool[ $stored_id ] ) ) {
					return array(
						'product_id' => $stored_id,
						'row'        => $pool[ $stored_id ],
					);
				}
				if ( $stored_id === $static ) {
					return array(
						'product_id' => $stored_id,
						'row'        => array(),
						'static'     => true,
					);
				}
			}
		}

		// 3. First pick for this cart, or the stored one is gone: sweep, rank, store.
		$rows = $this->eligible_rows( $bump );

		if ( empty( $rows ) ) {
			if ( $static && $engine->is_offerable( $static ) ) {
				$this->set_stored( $key, $static, $signature );
				$this->log( sprintf( 'ob %s: pool exhausted, using static product %d.', $ob_id, $static ) );
				return array(
					'product_id' => $static,
					'row'        => array(),
					'static'     => true,
				);
			}
			$this->set_stored( $key, 0, $signature );
			$this->log( sprintf( 'ob %s: nothing sellable, bump suppressed.', $ob_id ) );
			return $empty;
		}

		$product_id = $this->rank( $rows );

		if ( ! $product_id ) {
			// No ranking signal — first sellable row not already in the cart, admin order.
			$product_id = $this->first_non_cart( $rows );
			if ( ! $product_id ) {
				$this->set_stored( $key, 0, $signature );
				$this->log( sprintf( 'ob %s: every sellable pool row is already in the cart, suppressed.', $ob_id ) );
				return $empty;
			}
			$this->log( sprintf( 'ob %s: no ranking signal, using pool row %d.', $ob_id, $product_id ) );
		}

		$this->set_stored( $key, $product_id, $signature );

		return array(
			'product_id' => $product_id,
			'row'        => $rows[ $product_id ],
		);
	}

	/**
	 * Pool rows keyed by configured product ID, without any offerability checks.
	 *
	 * The cheap half of eligible_rows(): it parses the pool so a cached pick can be
	 * confirmed present and validated with a single is_offerable() call, rather than
	 * sweeping every row.
	 *
	 * @since x.x.x
	 * @param array<string, mixed> $bump Bump row.
	 * @return array<int, array<string, mixed>>
	 */
	private function pool_index( $bump ) {

		$pool = isset( $bump['ai_product_pool'] ) && is_array( $bump['ai_product_pool'] ) ? $bump['ai_product_pool'] : array();
		$out  = array();

		foreach ( $pool as $row ) {
			// Tolerate the pre-#1297 shape where a pool entry was a bare product ID.
			$row        = is_array( $row ) ? $row : array( 'id' => $row );
			$product_id = isset( $row['id'] ) ? absint( $row['id'] ) : 0;

			if ( $product_id && ! isset( $out[ $product_id ] ) ) {
				$out[ $product_id ] = $row;
			}
		}

		return $out;
	}

	/**
	 * Rank the eligible pool members and return the best product ID.
	 *
	 * Affinity and embeddings are both keyed on parent products, while a pool row may
	 * name a specific variation. So ranking happens on parents and the winner is mapped
	 * back to the variation the admin actually configured.
	 *
	 * @since x.x.x
	 * @param array<int, array<string, mixed>> $rows Eligible rows, keyed by configured product ID.
	 * @return int Chosen product ID, 0 when nothing scored.
	 */
	private function rank( $rows ) {

		if ( ! class_exists( 'Cartflows_Pro_Product_Relevance' ) ) {
			return 0;
		}

		$sources = $this->cart_source_ids();

		if ( empty( $sources ) ) {
			return 0;
		}

		// parent product id => configured product ids, first one wins on a tie.
		$by_parent = array();
		foreach ( array_keys( $rows ) as $product_id ) {
			$parent = $this->parent_of( $product_id );
			if ( ! isset( $by_parent[ $parent ] ) ) {
				$by_parent[ $parent ] = array();
			}
			$by_parent[ $parent ][] = (int) $product_id;
		}

		$ranked = Cartflows_Pro_Product_Relevance::get_instance()->get_related_products(
			$sources,
			'order_bump',
			count( $by_parent ),
			$sources,
			array_keys( $by_parent )
		);

		foreach ( $ranked as $item ) {
			$parent = (int) $item['id'];
			if ( isset( $by_parent[ $parent ] ) ) {
				return (int) reset( $by_parent[ $parent ] );
			}
		}

		return 0;
	}

	/**
	 * Pool rows whose configured product can actually be sold right now.
	 *
	 * Keyed by product ID and kept in the admin's ordering, because that order is the
	 * documented fallback when there is no signal to rank on.
	 *
	 * @since x.x.x
	 * @param array<string, mixed> $bump Bump row.
	 * @return array<int, array<string, mixed>>
	 */
	private function eligible_rows( $bump ) {

		if ( ! class_exists( 'Cartflows_Pro_Product_Relevance' ) ) {
			return array();
		}

		$engine = Cartflows_Pro_Product_Relevance::get_instance();
		$out    = array();


		foreach ( $this->pool_index( $bump ) as $product_id => $row ) {
			// The configured variation itself has to be sellable, not merely its parent.
			if ( $engine->is_offerable( $product_id ) ) {
				$out[ $product_id ] = $row;
			}
		}

		return $out;
	}

	/**
	 * Copy the winning pool row's own settings onto the bump.
	 *
	 * Quantity and discount are read from the bump root by prepare_ob_data(), not from
	 * the pool, so without this every AI Auto bump would quietly price at the bump-level
	 * defaults instead of what the admin configured for that product.
	 *
	 * @since x.x.x
	 * @param array<string, mixed> $bump       Bump row.
	 * @param int                  $product_id Chosen product ID.
	 * @param array<string, mixed> $row        Winning pool row.
	 * @return array<string, mixed>
	 */
	private function apply_row( $bump, $product_id, $row ) {

		$bump['product'] = $product_id;

		if ( isset( $row['quantity'] ) ) {
			$bump['quantity'] = max( 1, absint( $row['quantity'] ) );
		}

		foreach ( array( 'discount_type', 'discount_value', 'discount_coupon' ) as $key ) {
			if ( isset( $row[ $key ] ) ) {
				$bump[ $key ] = $row[ $key ];
			}
		}

		// A stored product_image with no media-library pick behind it was derived from
		// whichever product was configured earlier. The product now changes per visitor,
		// so leaving it pinned shows one product's photo beside another's name and price.
		// Clearing it lets get_order_bump_image() fall back to the chosen product's own
		// thumbnail; a deliberate media pick (product_img_obj) is left alone.
		if ( empty( $bump['product_img_obj'] ) ) {
			$bump['product_image'] = '';
		}

		return $bump;
	}

	/**
	 * The product ID this bump already put in the cart, if any.
	 *
	 * @since x.x.x
	 * @param string $ob_id Order bump ID.
	 * @return int
	 */
	private function locked_product_id( $ob_id ) {

		if ( ! $this->cart_available() ) {
			return 0;
		}

		foreach ( WC()->cart->get_cart() as $item ) {
			if ( empty( $item['cartflows_bump'] ) || ! isset( $item['ob_id'] ) || (string) $item['ob_id'] !== $ob_id ) {
				continue;
			}
			$variation_id = isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0;
			return $variation_id > 0 ? $variation_id : absint( $item['product_id'] );
		}

		return 0;
	}

	/**
	 * Parent product IDs of the cart, excluding anything a bump put there.
	 *
	 * @since x.x.x
	 * @return int[]
	 */
	private function cart_source_ids() {

		if ( ! $this->cart_available() ) {
			return array();
		}

		$ids = array();

		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['cartflows_bump'] ) ) {
				continue;
			}
			$product_id = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
			if ( $product_id ) {
				$ids[] = $product_id;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * A signature of the cart that a pick is valid for.
	 *
	 * Bump-added items are excluded deliberately: accepting the bump mutates the cart,
	 * and if that changed the signature the pick would be recomputed, potentially to a
	 * different product, orphaning the line item the visitor just accepted.
	 *
	 * @since x.x.x
	 * @return string
	 */
	private function cart_signature() {

		if ( ! $this->cart_available() ) {
			return '';
		}

		$parts = array();

		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['cartflows_bump'] ) ) {
				continue;
			}
			$product_id   = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
			$variation_id = isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0;
			$parts[]      = $product_id . '-' . $variation_id;
		}

		sort( $parts );

		return md5( implode( '|', $parts ) );
	}

	/**
	 * Read the stored pick for a bump.
	 *
	 * @since x.x.x
	 * @param string $key Session store key (checkout_id:ob_id).
	 * @return array<string, mixed>
	 */
	private function get_stored( $key ) {

		if ( ! $this->session_available() ) {
			return array();
		}

		$picks = WC()->session->get( self::SESSION_KEY );

		return is_array( $picks ) && isset( $picks[ $key ] ) && is_array( $picks[ $key ] ) ? $picks[ $key ] : array();
	}

	/**
	 * Store a pick against the cart signature it was made for.
	 *
	 * @since x.x.x
	 * @param string $key        Session store key (checkout_id:ob_id).
	 * @param int    $product_id Chosen product ID (0 for a suppression / negative cache).
	 * @param string $signature  Cart signature.
	 * @return void
	 */
	private function set_stored( $key, $product_id, $signature ) {

		if ( ! $this->session_available() ) {
			return;
		}

		$picks = WC()->session->get( self::SESSION_KEY );
		$picks = is_array( $picks ) ? $picks : array();

		$picks[ $key ] = array(
			'product_id' => (int) $product_id,
			'cart_hash'  => (string) $signature,
		);

		WC()->session->set( self::SESSION_KEY, $picks );
	}

	/**
	 * The product ID a posted bump payload is allowed to name for an AI Auto bump.
	 *
	 * The checkout accepts a posted product ID so a visitor can pick a variation. For a
	 * resolved bump that would otherwise let any product in the store be added at this
	 * bump's discount, so the posted value is only honoured when it is the pick itself
	 * or one of its variations.
	 *
	 * @since x.x.x
	 * @param string $ob_id  Order bump ID.
	 * @param int    $posted Posted product ID.
	 * @param int    $picked The resolved product ID.
	 * @return int The ID that may be used.
	 */
	public function validate_posted_product( $ob_id, $posted, $picked ) {

		$posted = absint( $posted );
		$picked = absint( $picked );

		if ( ! $posted || $posted === $picked ) {
			return $picked;
		}

		if ( $this->parent_of( $posted ) === $picked || $this->parent_of( $posted ) === $this->parent_of( $picked ) ) {
			return $posted;
		}

		$this->log( sprintf( 'ob %s: rejected posted product %d, not part of the resolved pick %d.', $ob_id, $posted, $picked ), 'warning' );

		return $picked;
	}

	/**
	 * Parent product ID for a variation, or the ID itself.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return int
	 */
	private function parent_of( $product_id ) {

		$product_id = absint( $product_id );
		$parent     = wp_get_post_parent_id( $product_id );

		return $parent ? (int) $parent : $product_id;
	}

	/**
	 * Map a cart line's product ID to the pool key it belongs to.
	 *
	 * A variable pool product is configured by its parent ID but sits in the cart as a
	 * variation, so a direct lookup never matches; fall back to the parent.
	 *
	 * @since x.x.x
	 * @param int                              $product_id Cart line product/variation ID.
	 * @param array<int, array<string, mixed>> $pool       Pool index.
	 * @return int Pool key, or 0 when the product is not a pool member.
	 */
	private function pool_key_for( $product_id, $pool ) {

		$product_id = absint( $product_id );

		if ( isset( $pool[ $product_id ] ) ) {
			return $product_id;
		}

		$parent = $this->parent_of( $product_id );

		return isset( $pool[ $parent ] ) ? $parent : 0;
	}

	/**
	 * First eligible pool row whose product is not already in the cart.
	 *
	 * The no-signal fallback must not offer a product the visitor already has, or accepting
	 * the bump adds a second discounted line of it.
	 *
	 * @since x.x.x
	 * @param array<int, array<string, mixed>> $rows Eligible rows, keyed by product ID.
	 * @return int Product ID, or 0 when every eligible row is already in the cart.
	 */
	private function first_non_cart( $rows ) {

		$cart = $this->cart_source_ids();

		if ( empty( $cart ) ) {
			return (int) key( $rows );
		}

		foreach ( array_keys( $rows ) as $product_id ) {
			if ( ! in_array( $this->parent_of( $product_id ), $cart, true ) && ! in_array( (int) $product_id, $cart, true ) ) {
				return (int) $product_id;
			}
		}

		return 0;
	}

	/**
	 * Whether the WC cart is usable in this request.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private function cart_available() {
		return function_exists( 'WC' ) && WC()->cart instanceof WC_Cart;
	}

	/**
	 * Whether the WC session is usable in this request.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private function session_available() {
		return function_exists( 'WC' ) && WC()->session instanceof WC_Session;
	}

	/**
	 * Write a diagnostic line.
	 *
	 * @since x.x.x
	 * @param string $message Message.
	 * @param string $level   info|warning|error.
	 * @return void
	 */
	private function log( $message, $level = 'info' ) {

		if ( ! apply_filters( 'cartflows_pro_ai_ob_log', defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			return;
		}

		//phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( sprintf( '[CartFlows AI Order Bump] [%s] %s', strtoupper( $level ), $message ) );
	}
}
