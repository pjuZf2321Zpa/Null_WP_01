<?php
/**
 * Order Bump skin registry.
 *
 * Single source of truth for the skins an Order Bump can use. The registered key
 * is the persisted `style` value and also names the front-end template.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Order_Bump_Skins.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Order_Bump_Skins {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Absolute path of the front-end template that renders a skin.
	 *
	 * @param string $skin Skin key.
	 * @return string
	 */
	public function get_template_path( $skin ) {
		return CARTFLOWS_PRO_ORDER_BUMP_DIR . 'templates/bump-order/wcf-bump-order-' . $skin . '.php';
	}

	/**
	 * Returns the registered skins, keyed by their persisted `style` value.
	 *
	 * Entries without a readable template are dropped, so the picker can never
	 * offer a skin that would render as an empty wrapper on the checkout.
	 *
	 * @return array<string, array{label: string, description: string}>
	 */
	public function get_skins() {

		$skins = array(
			'style-1' => array(
				'label'       => __( 'Style 1', 'cartflows-pro' ),
				'description' => __( 'Checkbox bar on top, content below.', 'cartflows-pro' ),
			),
			'style-2' => array(
				'label'       => __( 'Style 2', 'cartflows-pro' ),
				'description' => __( 'Headline first, checkbox at the bottom.', 'cartflows-pro' ),
			),
			'style-3' => array(
				'label'       => __( 'Style 3', 'cartflows-pro' ),
				'description' => __( 'Everything in a single row.', 'cartflows-pro' ),
			),
			'style-4' => array(
				'label'       => __( 'Style 4', 'cartflows-pro' ),
				'description' => __( 'Add button instead of a checkbox.', 'cartflows-pro' ),
			),
			'style-5' => array(
				'label'       => __( 'Style 5', 'cartflows-pro' ),
				'description' => __( 'Stacked text, checkbox below.', 'cartflows-pro' ),
			),
		);

		/**
		 * Filters the Order Bump skins offered by the admin skin picker.
		 *
		 * A skin is only offered once a template exists for it at
		 * templates/bump-order/wcf-bump-order-{key}.php.
		 *
		 * @since x.x.x
		 *
		 * @param array<string, array{label: string, description: string}> $skins Skins keyed by `style` value.
		 */
		$filtered = apply_filters( 'cartflows_pro_order_bump_skins', $skins );

		/**
		 * A filter can hand back any type regardless of what it was given.
		 *
		 * @var mixed $filtered
		 */

		if ( ! is_array( $filtered ) ) {
			return $skins;
		}

		$normalized = array();

		foreach ( $filtered as $value => $skin ) {

			// A numeric key means the skin was appended rather than keyed, e.g. `$skins[] = 'style-6'`.
			if ( ! is_string( $value ) || '' === $value ) {
				continue;
			}

			// A registered skin without a template would render as an empty wrapper.
			if ( ! is_readable( $this->get_template_path( $value ) ) ) {
				continue;
			}

			$label       = is_array( $skin ) && isset( $skin['label'] ) && is_string( $skin['label'] ) ? $skin['label'] : '';
			$description = is_array( $skin ) && isset( $skin['description'] ) && is_string( $skin['description'] ) ? $skin['description'] : '';

			$normalized[ $value ] = array(
				'label'       => '' !== $label ? $label : $value,
				'description' => $description,
			);
		}

		return $normalized;
	}

	/**
	 * Returns the skins shaped as the `options` array the admin fields expect.
	 *
	 * @return array<int, array{value: string, label: string, description: string}>
	 */
	public function get_skin_options() {

		$options = array();

		foreach ( $this->get_skins() as $value => $skin ) {
			$options[] = array(
				'value'       => $value,
				'label'       => $skin['label'],
				'description' => $skin['description'],
			);
		}

		return $options;
	}

	/**
	 * Whether the given value is a registered skin with a usable template.
	 *
	 * @param string $skin Skin value to check.
	 * @return bool
	 */
	public function is_valid_skin( $skin ) {
		return is_string( $skin ) && array_key_exists( $skin, $this->get_skins() );
	}
}
