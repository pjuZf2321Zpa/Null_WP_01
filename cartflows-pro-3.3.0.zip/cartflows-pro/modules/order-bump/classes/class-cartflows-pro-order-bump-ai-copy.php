<?php
/**
 * Order Bump — AI copy generation.
 *
 * Writes the visitor-facing text on an order bump: its title, description,
 * highlight ribbon and checkbox label.
 *
 * The prompt itself lives on the credit server, keyed by type (`order_bump_title`
 * and friends). This class only gathers the product context, names the type, and
 * cleans what comes back — it deliberately does not build a prompt, so wording can
 * change server-side without shipping a plugin release.
 *
 * Two modes, because a bump does not always show a fixed product:
 *   - manual: one product is configured, so the copy can name it.
 *   - pool:   the product is chosen per visitor at runtime, so the copy is written
 *             once around {{product_name}} / {{product_price}} tokens, which
 *             get_single_order_bump_markup() substitutes against whichever product
 *             was picked.
 *
 * Every call costs the merchant credits, so nothing is generated speculatively.
 * Nothing is saved either — variations are returned for the admin to choose from,
 * and the existing form POST persists the choice only if they keep it.
 *
 * @package CartFlows
 * @since   x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Order_Bump_Ai_Copy.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Order_Bump_Ai_Copy {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Tokens the order bump renderer substitutes at display time.
	 *
	 * Anything outside this set would reach the visitor as literal braces, so
	 * generated copy is validated against it. Kept in sync with the $to_replace
	 * list in Cartflows_Pro_Order_Bump_Product::get_single_order_bump_markup().
	 *
	 * @var array<int, string>
	 */
	const TOKENS = array( 'product_name', 'product_price', 'product_desc', 'quantity' );

	/**
	 * Initiator.
	 *
	 * @since x.x.x
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * The order bump fields this class can write.
	 *
	 * `max` is the character budget sent to the server, which does the enforcing.
	 * Token-free copy is trimmed to it here as a backstop; copy holding a token is
	 * left alone, since what a shopper sees depends on the product substituted in.
	 *
	 * @since x.x.x
	 * @return array<string, array{label:string, max:int, type:string}>
	 */
	public static function get_fields() {

		return array(
			'title_text'     => array(
				'label' => __( 'Title', 'cartflows-pro' ),
				'max'   => 60,
				'type'  => 'order_bump_title',
			),
			'desc_text'      => array(
				'label' => __( 'Description', 'cartflows-pro' ),
				'max'   => 240,
				'type'  => 'order_bump_description',
			),
			'hl_text'        => array(
				'label' => __( 'Highlight text', 'cartflows-pro' ),
				'max'   => 40,
				'type'  => 'order_bump_highlight',
			),
			'checkbox_label' => array(
				'label' => __( 'Checkbox label', 'cartflows-pro' ),
				'max'   => 60,
				'type'  => 'order_bump_checkbox_label',
			),
		);
	}

	/**
	 * Whether a field name is one we know how to write.
	 *
	 * @since x.x.x
	 * @param string $field Field name.
	 * @return bool
	 */
	public static function is_supported_field( $field ) {
		return array_key_exists( $field, self::get_fields() );
	}

	/**
	 * The credit-server route that writes the copy.
	 *
	 * Sits alongside `cartflows/generate/embeddings` under the same controller, so
	 * it authenticates with the token the embeddings sync already uses. Filterable
	 * because the contract belongs to the credit server, not this plugin.
	 *
	 * @since x.x.x
	 * @return string
	 */
	public static function get_route() {
		return (string) apply_filters( 'cartflows_pro_ai_copy_route', 'cartflows/generate/content' );
	}

	/**
	 * Write one order bump field, returning several variations to choose from.
	 *
	 * @since x.x.x
	 * @param int                  $step_id Checkout step ID, for context.
	 * @param string               $field   One of self::get_fields().
	 * @param array<string, mixed> $args    Optional. Accepts 'mode' ('manual' or 'pool', default manual), 'product_id' for manual mode, 'pool_ids' (int[]) for pool mode, and 'tone' as an optional hint.
	 * @return array{variations:string[], usage:array<string, mixed>}|WP_Error
	 */
	public function generate( $step_id, $field, $args = array() ) {

		if ( ! self::is_supported_field( $field ) ) {
			return new WP_Error( 'cartflows_unsupported_field', __( 'That field cannot be written automatically.', 'cartflows-pro' ) );
		}

		if ( ! class_exists( 'CartFlows_Ai_Utils' ) ) {
			return new WP_Error( 'cartflows_no_transport', __( 'AI features are unavailable. Please update the CartFlows plugin.', 'cartflows-pro' ) );
		}

		$mode   = isset( $args['mode'] ) && 'pool' === $args['mode'] ? 'pool' : 'manual';
		$inputs = $this->build_inputs( $step_id, $field, $mode, $args );

		// Without a product or a pool the server has nothing to describe.
		if ( empty( $inputs['product_name'] ) && empty( $inputs['pool_products'] ) ) {
			return 'pool' === $mode
				? new WP_Error( 'cartflows_empty_pool', __( 'Add products to the pool before writing its copy.', 'cartflows-pro' ) )
				: new WP_Error( 'cartflows_no_product', __( 'Choose a product before writing its copy.', 'cartflows-pro' ) );
		}

		$fields  = self::get_fields();
		$payload = array(
			'type'   => $fields[ $field ]['type'],
			'inputs' => $inputs,
		);

		$payload = (array) apply_filters( 'cartflows_pro_ai_copy_payload', $payload, $field, $mode, $step_id );

		$response = CartFlows_Ai_Utils::get_instance()->send_api_request( $payload, self::get_route(), 30 );
		$result   = $this->parse( $response, $field );

		if ( 'pool' === $mode && is_array( $result ) ) {
			$result['variations'] = $this->drop_named_products(
				$result['variations'],
				$this->pool_product_names( isset( $args['pool_ids'] ) ? (array) $args['pool_ids'] : array() )
			);

			if ( empty( $result['variations'] ) ) {
				return new WP_Error( 'cartflows_pool_copy_named', __( 'The generated copy named a specific product, which does not work for a rotating pool. Try again.', 'cartflows-pro' ) );
			}
		}

		return $result;
	}

	/**
	 * Drop variations that name one of the pool's products.
	 *
	 * Pool copy is stored once while the product is chosen per visitor, so a
	 * variation naming a pool member is shown beside a different product. The server
	 * prompt asks for `{{product_name}}` instead, but a model that names the product
	 * anyway would otherwise produce copy that misdescribes what is on offer.
	 *
	 * @since x.x.x
	 * @param string[] $variations Generated variations.
	 * @param string[] $names      Pool product names.
	 * @return string[]
	 */
	private function drop_named_products( $variations, $names ) {

		$names = array_filter( $names );

		if ( empty( $names ) ) {
			return $variations;
		}

		$kept = array();

		foreach ( $variations as $text ) {
			$named = false;

			foreach ( $names as $name ) {
				/*
				 * Lookarounds rather than \b: a name edged by punctuation — "(Combo) Kit",
				 * "+Extras" — has no word boundary to match there, so \b would silently
				 * never fire on exactly the names most in need of catching. These assert
				 * on the surrounding text instead, and still keep a product called "Cap"
				 * from matching inside "capacity".
				 */
				if ( preg_match( '/(?<!\w)' . preg_quote( $name, '/' ) . '(?!\w)/iu', $text ) ) {
					$named = true;
					break;
				}
			}

			if ( ! $named ) {
				$kept[] = $text;
			}
		}

		return $kept;
	}

	/**
	 * Names of the products configured in the pool.
	 *
	 * @since x.x.x
	 * @param array<int, mixed> $ids Product IDs.
	 * @return string[]
	 */
	private function pool_product_names( $ids ) {

		$names = array();

		foreach ( $ids as $id ) {
			$product = wc_get_product( absint( $id ) );

			if ( $product instanceof WC_Product ) {
				$names[] = $this->plain( $product->get_name() );
			}
		}

		return $names;
	}

	/**
	 * Gather the product context the server prompt expects.
	 *
	 * @since x.x.x
	 * @param int                  $step_id Checkout step ID.
	 * @param string               $field   Field being written.
	 * @param string               $mode    manual|pool.
	 * @param array<string, mixed> $args    Caller arguments.
	 * @return array<string, mixed>
	 */
	private function build_inputs( $step_id, $field, $mode, $args ) {

		$fields = self::get_fields();

		$inputs = array(
			'mode'              => $mode,
			'max_length'        => $fields[ $field ]['max'],
			'checkout_products' => $this->get_checkout_product_names( $step_id ),
		);

		if ( 'pool' === $mode ) {
			$inputs['pool_products'] = $this->describe_products( isset( $args['pool_ids'] ) ? (array) $args['pool_ids'] : array() );
		} else {
			$product = wc_get_product( isset( $args['product_id'] ) ? absint( $args['product_id'] ) : 0 );

			if ( $product instanceof WC_Product ) {
				$inputs['product_name']        = $this->plain( $product->get_name() );
				$inputs['product_price']       = $this->format_price( $product );
				$inputs['product_description'] = $this->clamp_plain( $this->plain( (string) $product->get_short_description() ), 300 );
				$inputs['product_categories']  = $this->get_category_names( (int) $product->get_id() );
			}
		}

		if ( ! empty( $args['tone'] ) ) {
			$inputs['tone'] = sanitize_text_field( strval( $args['tone'] ) );
		}

		// Empty values only add noise to the prompt, and the server skips them anyway.
		return array_filter(
			$inputs,
			static function ( $value ) {
				return '' !== $value && null !== $value;
			}
		);
	}

	/**
	 * Turn the transport response into clean variations, or an actionable error.
	 *
	 * Messages here are read by an admin mid-task, so each says what to do next
	 * rather than what failed internally.
	 *
	 * @since x.x.x
	 * @param array<string, mixed>|WP_Error $response Transport response.
	 * @param string                        $field    Field being written.
	 * @return array{variations:string[], usage:array<string, mixed>}|WP_Error
	 */
	private function parse( $response, $field ) {

		if ( is_wp_error( $response ) ) {
			// Only a missing/invalid token means "not connected". Surface real transport
			// failures (timeout, DNS, SSL) so a connected admin isn't sent to reconnect.
			$code = $response->get_error_code();
			if ( 'no_auth_token' === $code || 'invalid_auth_token' === $code ) {
				return new WP_Error( 'cartflows_not_connected', __( 'Connect your CartFlows account to use AI features.', 'cartflows-pro' ) );
			}
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$body = is_array( $body ) ? $body : array();

		$error = $this->map_error( $code, $body );

		if ( $error instanceof WP_Error ) {
			return $error;
		}

		$variations = $this->sanitize_variations( isset( $body['content'] ) ? $body['content'] : array(), $field );

		if ( empty( $variations ) ) {
			return new WP_Error( 'cartflows_empty_response', __( 'The AI service returned nothing usable. Try again.', 'cartflows-pro' ) );
		}

		return array(
			'variations' => $variations,
			'usage'      => isset( $body['usage'] ) && is_array( $body['usage'] ) ? $body['usage'] : array(),
		);
	}

	/**
	 * Map a credit-server failure onto something an admin can act on.
	 *
	 * @since x.x.x
	 * @param int                  $code HTTP status code.
	 * @param array<string, mixed> $body Decoded response body.
	 * @return WP_Error|null Null when the response is a success.
	 */
	private function map_error( $code, $body ) {

		// Token problems come back with a code rather than a status alone.
		$server_code = isset( $body['code'] ) && is_scalar( $body['code'] ) ? (string) $body['code'] : '';

		$auth_codes = array( 'token_not_found', 'no_auth', 'invalid_token', 'user_verification_failed', 'license_verification_failed' );

		if ( in_array( $server_code, $auth_codes, true ) || 401 === $code || 403 === $code ) {
			return new WP_Error( 'cartflows_not_connected', __( 'Your CartFlows account could not be verified. Reconnect it and try again.', 'cartflows-pro' ) );
		}

		if ( 429 === $code ) {
			return new WP_Error( 'cartflows_rate_limited', __( 'You have reached your AI usage limit for now. Try again shortly.', 'cartflows-pro' ) );
		}

		if ( 404 === $code ) {
			return new WP_Error( 'cartflows_route_missing', __( 'AI writing is not available for your account yet.', 'cartflows-pro' ) );
		}

		// 422 carries either the model's "not enough information" answer or a
		// validation failure naming the offending fields.
		if ( ! empty( $body['error'] ) && is_scalar( $body['error'] ) ) {
			return new WP_Error( 'cartflows_ai_error', sanitize_text_field( (string) $body['error'] ) );
		}

		if ( 200 !== $code ) {
			$message = isset( $body['message'] ) && is_scalar( $body['message'] ) ? sanitize_text_field( (string) $body['message'] ) : '';

			return new WP_Error(
				'cartflows_bad_response',
				'' !== $message
					? $message
					/* translators: %d: HTTP status code. */
					: sprintf( __( 'The AI service returned an unexpected response (%d). Please try again.', 'cartflows-pro' ), $code )
			);
		}

		return null;
	}

	/**
	 * Clean each returned variation and drop anything unusable.
	 *
	 * @since x.x.x
	 * @param mixed  $content Raw `content` value from the server.
	 * @param string $field   Field being written.
	 * @return string[]
	 */
	private function sanitize_variations( $content, $field ) {

		// A bare string is accepted as a one-variation answer.
		$raw = is_array( $content ) ? $content : array( $content );
		$out = array();

		foreach ( $raw as $candidate ) {
			if ( ! is_scalar( $candidate ) ) {
				continue;
			}

			$text = $this->clean( (string) $candidate, $field );

			if ( '' !== $text && ! in_array( $text, $out, true ) ) {
				$out[] = $text;
			}
		}

		return $out;
	}

	/**
	 * Strip, unwrap and length-check one variation.
	 *
	 * Model output is untrusted input: it lands in a field an admin saves and a
	 * storefront renders, so no markup survives and unsupported tokens are removed
	 * rather than shown to a shopper as literal braces.
	 *
	 * @since x.x.x
	 * @param string $text  Raw generated text.
	 * @param string $field Field being written.
	 * @return string
	 */
	private function clean( $text, $field ) {

		$fields = self::get_fields();
		$max    = isset( $fields[ $field ]['max'] ) ? (int) $fields[ $field ]['max'] : 120;

		$text = $this->plain( $text );

		// Models like to wrap a single answer in quotes despite being told not to.
		$text = trim( $text, " \t\"'“”‘’" );

		$text = $this->strip_unknown_tokens( $text );
		$text = $this->fit( $text, $max );

		return sanitize_text_field( $text );
	}

	/**
	 * Remove any {{token}} the renderer would not substitute.
	 *
	 * @since x.x.x
	 * @param string $text Text to check.
	 * @return string
	 */
	private function strip_unknown_tokens( $text ) {

		$allowed = self::TOKENS;

		$text = (string) preg_replace_callback(
			'/\{\{\s*([a-zA-Z_]+)\s*\}\}/',
			static function ( $matches ) use ( $allowed ) {
				$name = strtolower( $matches[1] );

				return in_array( $name, $allowed, true ) ? '{{' . $name . '}}' : '';
			},
			$text
		);

		// Removing a token can leave doubled spaces or a dangling connective.
		$text = (string) preg_replace( '/\s+/', ' ', $text );

		return trim( $text, " \t,;:-" );
	}

	/**
	 * Bring a variation inside its budget without breaking a token.
	 *
	 * The budget describes what a shopper sees, and a token is far shorter stored
	 * than rendered, so the raw length is the wrong measure. Copy containing tokens
	 * is therefore never cut — the server already enforced the budget, and cutting
	 * risks slicing `{{product_price}}` into `{{product_pri`.
	 *
	 * @since x.x.x
	 * @param string $text Text to fit.
	 * @param int    $max  Character budget.
	 * @return string
	 */
	private function fit( $text, $max ) {

		// Case-insensitive so this holds on its own: strip_unknown_tokens() lowercases
		// every token it keeps, but relying on that ordering means a {{Product_Name}}
		// reaching here directly would be invisible and get cut like plain text.
		if ( preg_match( '/\{\{[a-z_]+\}\}/i', $text ) ) {
			return $text;
		}

		return $this->clamp_plain( $text, $max );
	}

	/**
	 * Trim token-free text to a budget, preferring a word boundary.
	 *
	 * @since x.x.x
	 * @param string $text  Text to trim.
	 * @param int    $limit Maximum characters.
	 * @return string
	 */
	private function clamp_plain( $text, $limit ) {

		if ( mb_strlen( $text ) <= $limit ) {
			return $text;
		}

		$cut = mb_substr( $text, 0, $limit );
		// WP core polyfills mb_strlen/mb_substr but not mb_strrpos; fall back on mbstring-less hosts.
		$space = function_exists( 'mb_strrpos' ) ? mb_strrpos( $cut, ' ' ) : strrpos( $cut, ' ' );

		// Only fall back to a hard cut if trimming to a word would lose too much.
		if ( false !== $space && $space > (int) ( $limit * 0.6 ) ) {
			$cut = mb_substr( $cut, 0, $space );
		}

		return rtrim( $cut, ' ,;:-' );
	}

	/**
	 * Name and price for each product, for the pool context.
	 *
	 * @since x.x.x
	 * @param array<int, mixed> $ids Product IDs.
	 * @return string
	 */
	private function describe_products( $ids ) {

		$parts = array();

		foreach ( $ids as $id ) {
			$product = wc_get_product( absint( $id ) );

			if ( $product instanceof WC_Product ) {
				$parts[] = $this->plain( $product->get_name() ) . ' (' . $this->format_price( $product ) . ')';
			}
		}

		return implode( ', ', array_unique( $parts ) );
	}

	/**
	 * Display price as plain text.
	 *
	 * @since x.x.x
	 * @param WC_Product $product Product.
	 * @return string
	 */
	private function format_price( $product ) {
		return $this->plain( (string) wc_price( (float) wc_get_price_to_display( $product ) ) );
	}

	/**
	 * Reduce text to a single readable line: no markup, no entities, no line breaks.
	 *
	 * Used on both sides. Prompt inputs need it because WooCommerce stores this text
	 * encoded — `wc_price()` renders the currency symbol as `&#8377;` and titles
	 * routinely hold `&amp;` — and the model quotes back whatever it is given.
	 * Generated text needs it because it lands in a field a storefront renders.
	 *
	 * @since x.x.x
	 * @param string $text Raw text.
	 * @return string
	 */
	private function plain( $text ) {

		$text = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, get_bloginfo( 'charset' ) );

		// Decoding can expose markup that was stored encoded, so strip once more.
		$text = wp_strip_all_tags( $text );

		// A decoded `&nbsp;` is a non-breaking space; keep the text plainly spaced.
		$text = str_replace( "\xc2\xa0", ' ', $text );

		return trim( (string) preg_replace( '/\s+/', ' ', $text ) );
	}

	/**
	 * Comma-separated category names for a product.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return string
	 */
	private function get_category_names( $product_id ) {

		$names = (array) wc_get_product_terms( $product_id, 'product_cat', array( 'fields' => 'names' ) );

		return $this->plain( implode( ', ', array_map( 'strval', $names ) ) );
	}

	/**
	 * Comma-separated names of what the checkout step sells.
	 *
	 * Empty for a store checkout, which sells whatever is in the visitor's cart.
	 *
	 * @since x.x.x
	 * @param int $step_id Checkout step ID.
	 * @return string
	 */
	private function get_checkout_product_names( $step_id ) {

		$products = wcf()->utils->get_selected_checkout_products( $step_id );
		$names    = array();

		if ( is_array( $products ) ) {
			foreach ( $products as $row ) {
				$id      = is_array( $row ) && isset( $row['product'] ) ? absint( $row['product'] ) : 0;
				$product = $id ? wc_get_product( $id ) : null;

				if ( $product instanceof WC_Product ) {
					$names[] = $this->plain( $product->get_name() );
				}
			}
		}

		return implode( ', ', array_unique( $names ) );
	}
}
