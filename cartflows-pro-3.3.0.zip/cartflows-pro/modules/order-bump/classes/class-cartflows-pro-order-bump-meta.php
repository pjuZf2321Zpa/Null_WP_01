<?php
/**
 * Order Bump field schema.
 *
 * Single source of truth for the wcf-order-bumps default field map. Lives inside
 * the order-bump module per CF-1154 Phase 2; the legacy method on
 * Cartflows_Pro_Checkout_Default_Meta::order_bump_default_meta() delegates here
 * so existing call sites continue to work unchanged.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Order_Bump_Meta.
 *
 * Holds the field map used by every OB CRUD path (add / clone / save / read).
 * The A/B-related fields at the bottom of the map carry meaning only when the
 * MultipleOrderBumpAb handlers populate them; the schema simply guarantees that
 * every wcf-order-bumps entry has the keys present with sensible defaults.
 *
 * @since 3.1.3
 */
class Cartflows_Pro_Order_Bump_Meta {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Valid order bump display positions.
	 *
	 * Single source of truth: the render buckets, the admin dropdown and the write-path
	 * validation all read this, so adding a position is a one-line change.
	 *
	 * @since x.x.x
	 * @return array<int, string>
	 */
	public static function get_valid_positions() {
		return array(
			'before-checkout',
			'after-customer',
			'above-order-summary',
			'after-order',
			'after-payment',
		);
	}

	/**
	 * Coerce a position to a valid slug, falling back to the schema default.
	 *
	 * @since x.x.x
	 * @param mixed $position Position slug.
	 * @return string
	 */
	public static function sanitize_position( $position ) {
		return is_string( $position ) && in_array( $position, self::get_valid_positions(), true ) ? $position : 'after-order';
	}

	/**
	 * Returns the full default field map for a single wcf-order-bumps entry.
	 *
	 * Existing OB fields are unchanged. Eight new keys at the bottom support
	 * the A/B Split Testing feature: ab-test, ab-test-start, ab-test-ui,
	 * ab-test-variations, ab-test-archived-variations, ab-winner-ob (on the
	 * control entry) and wcf-control-ob, wcf-winner-ob (on variant entries).
	 *
	 * @return array<string, array{default: mixed, sanitize: string}>
	 */
	public function get_default_meta() {

		// Existing OB schema — kept verbatim from the original Cartflows_Pro_Checkout_Default_Meta location.
		$order_bump_fields = array(
			'id'                          => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'title'                       => array(
				'default'  => __( 'no title', 'cartflows-pro' ),
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'status'                      => array(
				'default'  => false,
				'sanitize' => 'FILTER_VALIDATE_BOOLEAN',
			),
			'product'                     => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_NUMBER_INT',
			),
			'product_mode'                => array(
				'default'  => 'manual',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'ai_product_pool'             => array(
				'default'  => array(),
				'sanitize' => 'FILTER_SANITIZE_AI_POOL',
			),
			'quantity'                    => array(
				'default'  => 1,
				'sanitize' => 'FILTER_SANITIZE_NUMBER_INT',
			),
			'default_state'               => array(
				'default'  => 'no',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'display_quantity_field'      => array(
				'default'  => 'no',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'discount_type'               => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'discount_value'              => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_NUMBER_FLOAT',
			),
			'discount_coupon'             => array(
				'default'  => array(),
				'sanitize' => 'FILTER_SANITIZE_ARRAY',
			),
			'enable_show_image'           => array(
				'default'  => 'yes',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'ob_image_position'           => array(
				'default'  => 'left',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'ob_image_width'              => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_NUMBER_INT',
			),
			'product_image'               => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_URL',
			),
			'product_img_obj'             => array(
				'default'  => '',
				'sanitize' => 'FILTER_CARTFLOWS_OB_IMAGE',
			),
			'position'                    => array(
				'default'  => 'after-order',
				// Validated against get_valid_positions() on save.
				'sanitize' => 'FILTER_SANITIZE_OB_POSITION',
			),
			'checkbox_label'              => array(
				'default'  => __( 'Yes, I will take it!', 'cartflows-pro' ),
				'sanitize' => 'FILTER_WP_KSES_POST',
			),
			'action_element'              => array(
				'default'  => 'checkbox',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'title_text'                  => array(
				'default'  => __( 'Here is Great Offer!', 'cartflows-pro' ),
				'sanitize' => 'FILTER_WP_KSES_POST',
			),
			'hl_text'                     => array(
				'default'  => __( 'One Time Offer', 'cartflows-pro' ),
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'desc_text'                   => array(
				'default'  => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut, quod hic expedita consectetur vitae nulla sint adipisci cupiditate at.', 'cartflows-pro' ),
				'sanitize' => 'FILTER_WP_KSES_POST',
			),
			'replace_product'             => array(
				'default'  => 'no',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'next_step'                   => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_NUMBER_INT',
			),
			'style'                       => array(
				'default'  => 'style-1',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'border_style'                => array(
				'default'  => 'inherit',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'box_border_radius'           => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'box_border_width'            => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'box_shadow_color'            => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'box_shadow_horizontal'       => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'box_shadow_vertical'         => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'box_shadow_blur'             => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'box_shadow_spread'           => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'show_image_mobile'           => array(
				'default'  => 'yes',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'show_arrow'                  => array(
				'default'  => 'no',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'show_animation'              => array(
				'default'  => 'no',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'border_color'                => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'bg_color'                    => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'label_color'                 => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'title_text_color'            => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'label_bg_color'              => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'desc_text_color'             => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'hl_text_color'               => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'button_text_color'           => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'button_text_hover_color'     => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'button_color'                => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'button_hover_color'          => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'button_border_width'         => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'button_border_radius'        => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'button_border_style'         => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'button_border_color'         => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'width'                       => array(
				'default'  => '100',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'label_border_style'          => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'label_border_width'          => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'label_border_radius'         => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'label_border_color'          => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_COLOR',
			),
			'rules'                       => array(
				'default'  => array(
					array(
						'group_id' => substr( md5( (string) wp_rand() ), 2, 3 ),
						'rules'    => array(
							array(
								'rule_id'   => substr( md5( (string) wp_rand() ), 2, 3 ),
								'condition' => 'cart_item',
								'operator'  => '',
								'value'     => '',
							),
						),
					),
				),
				'sanitize' => 'FILTER_SANITIZE_RULES',
			),
			'is_rule'                     => array(
				'default'  => 'no',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),

			// CF-1154 Phase 2.2: A/B Split Test fields. Semantics:
			// - ab-test/ab-test-start/ab-test-ui/ab-test-variations/ab-test-archived-variations/ab-winner-ob
			// live on the CONTROL entry and drive the A/B group rendering + lifecycle.
			// - wcf-control-ob and wcf-winner-ob live on the VARIANT entries and reverse-link to the control.
			// - ab-test is shared (true on every participant entry of the same test).
			// Sanitisation for the array fields is handled by the new MultipleOrderBumpAb handlers because the
			// shape is too rich for the existing FILTER_SANITIZE_* dispatch (array of {id, traffic} or
			// {id, title, note, deleted, raw_date, date}). FILTER_DEFAULT is a safe no-op pass-through.
			'ab-test'                     => array(
				'default'  => false,
				'sanitize' => 'FILTER_VALIDATE_BOOLEAN',
			),
			'ab-test-start'               => array(
				'default'  => false,
				'sanitize' => 'FILTER_VALIDATE_BOOLEAN',
			),
			'ab-test-ui'                  => array(
				'default'  => false,
				'sanitize' => 'FILTER_VALIDATE_BOOLEAN',
			),
			'ab-test-variations'          => array(
				'default'  => array(),
				'sanitize' => 'FILTER_DEFAULT',
			),
			'ab-test-archived-variations' => array(
				'default'  => array(),
				'sanitize' => 'FILTER_DEFAULT',
			),
			'ab-winner-ob'                => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'wcf-control-ob'              => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
			'wcf-winner-ob'               => array(
				'default'  => '',
				'sanitize' => 'FILTER_SANITIZE_STRING',
			),
		);

		return $order_bump_fields;
	}
}
