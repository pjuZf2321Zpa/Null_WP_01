<?php
/**
 * Order Bump A/B Split Test — frontend factory.
 *
 * Resolves which variant to render for a given control bump, manages the per-visitor
 * cookie that pins assignment for 30 days, and writes impression + conversion counters
 * to the `wcf-order-bump-ab-stats` postmeta on the checkout step.
 *
 * Public surface mirrors the Step A/B factory (modules/ab-test/classes/class-cartflows-pro-ab-test-factory.php)
 * so the two A/B systems stay structurally consistent. Cookie semantics (30-day, HttpOnly,
 * SameSite=Lax) reuse the locked flag set from that file too.
 *
 * @package CartFlowsPro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Order_Bump_Ab_Factory.
 *
 * @since 3.1.3
 */
class Cartflows_Pro_Order_Bump_Ab_Factory {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Per-request memo of `[step_id][control_ob_id] => merged_bump_payload` so impressions are
	 * counted once per request even when get_sorted_order_bumps() runs multiple times.
	 *
	 * @var array<string, array<string, array<string, mixed>>>
	 */
	private $request_memo = array();

	/**
	 * Singleton accessor.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Funnel: impression (cookie pin) → initiated (bump accepted, in cart) → conversion (order placed).
	 * `wcf_after_order_bump_process` stamps `initiated`; `woocommerce_checkout_order_processed` stamps
	 * `conversions` after walking the placed order's line items. The two stages keep cart-abandonment
	 * separable from real revenue.
	 *
	 * @return void
	 */
	public function __construct() {
		add_action( 'wcf_after_order_bump_process', array( $this, 'record_initiated_from_hook' ), 20, 1 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'record_conversions_from_order' ), 20, 1 );
		// Inject stats alongside the rest of the step settings the React admin already fetches via REST.
		add_filter( 'cartflows_admin_checkout_step_data', array( $this, 'inject_stats_into_step_data' ), 10, 2 );
	}

	/**
	 * Append the step's `wcf-order-bump-ab-stats` postmeta to the existing REST step-data response
	 * under `options.ob_ab_stats`. The React reducer already merges `data.options` into Redux, so the
	 * stats become reachable via `stepState.options.ob_ab_stats` without any extra HTTP call or
	 * global localized variable.
	 *
	 * @param array<string, mixed> $data    Step data being returned by /cartflows/v1/admin/step-data/{id}.
	 * @param int                  $step_id Checkout step id the response is for.
	 * @return array<string, mixed>
	 */
	public function inject_stats_into_step_data( $data, $step_id ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$stats = get_post_meta( $step_id, 'wcf-order-bump-ab-stats', true );
		// Ensure `options` exists then append the stats blob — empty object when no data.
		if ( ! isset( $data['options'] ) || ! is_array( $data['options'] ) ) {
			$data['options'] = array();
		}
		$data['options']['ob_ab_stats'] = is_array( $stats ) ? $stats : array();
		return $data;
	}

	/**
	 * Increment the `initiated` counter when a bump is accepted at checkout (cart-add event).
	 * Pre-checked bumps auto-trigger this on first render so initiated == impression for them — intended.
	 *
	 * @param array<string, mixed> $ob_data Order bump data from the accept handler.
	 * @return void
	 */
	public function record_initiated_from_hook( $ob_data ) {
		// Same POST guard the parent handler uses — count only true accept/replace events, not toggle-offs.
		$action = isset( $_POST['_wcf_bump_product_action'] ) ? sanitize_text_field( wp_unslash( $_POST['_wcf_bump_product_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( 'add_bump_product' !== $action && 'replace_bump_product' !== $action ) {
			return;
		}
		if ( ! is_array( $ob_data ) || empty( $ob_data['ob_id'] ) || empty( $ob_data['checkout_id'] ) ) {
			return;
		}
		$step_id = is_scalar( $ob_data['checkout_id'] ) ? intval( $ob_data['checkout_id'] ) : 0;
		$ob_id   = is_scalar( $ob_data['ob_id'] ) ? (string) $ob_data['ob_id'] : '';
		if ( $step_id <= 0 || '' === $ob_id ) {
			return;
		}
		// Resolve the A/B control id when this bump is part of a running test; fall back to the bump's
		// own id so standalone bumps still get counted (self-referencing key in stats).
		$control_ob_id = $this->resolve_control_id( $step_id, $ob_id );
		if ( '' === $control_ob_id ) {
			$control_ob_id = $ob_id;
		}
		$vid = $this->get_cookie_value( $step_id, $control_ob_id );
		if ( '' === $vid ) {
			$vid = $ob_id;
		}
		$this->increment_stat( $step_id, $control_ob_id, $vid, 'initiated' );
	}

	/**
	 * Find the A/B control id for a given bump id on a step. Variants point at their control via
	 * wcf-control-ob; controls flag themselves with ab-test=true. Returns '' when the bump isn't part
	 * of any A/B test (so callers can early-exit).
	 *
	 * @param int    $step_id Checkout step id.
	 * @param string $ob_id   Bump id to resolve.
	 * @return string Control id for the test this bump belongs to, or '' when none.
	 */
	private function resolve_control_id( $step_id, $ob_id ) {
		$bumps = get_post_meta( $step_id, 'wcf-order-bumps', true );
		if ( ! is_array( $bumps ) ) {
			return '';
		}
		foreach ( $bumps as $entry ) {
			if ( ! is_array( $entry ) || empty( $entry['id'] ) || $entry['id'] !== $ob_id ) {
				continue;
			}
			if ( ! empty( $entry['wcf-control-ob'] ) ) {
				return (string) $entry['wcf-control-ob'];
			}
			if ( ! empty( $entry['ab-test'] ) ) {
				return $ob_id;
			}
			return '';
		}
		return '';
	}

	/**
	 * Resolve the bump payload to render for an A/B control — owns BOTH the variant pick AND
	 * the variant-over-control merge so callers receive a ready-to-render array.
	 *
	 * - Admin users bypass A/B → returns the control's own entry unchanged.
	 * - Control with no active variations → returns the control's own entry unchanged.
	 * - First visit: picks by weighted traffic, sets the 30-day cookie, records an impression.
	 * - Revisit: honours the cookie (falls back to a re-pick if the cookied variant is no longer valid).
	 * - When the resolved variant differs from the control: merges the variant's payload over the control
	 *   via wp_parse_args(variant, control) so variant fields win and missing keys fall back to control.
	 *
	 * Centralising the merge here means the rule "variant fields override control fields" is owned by
	 * the factory; every future render path that needs a resolved bump gets the same correct payload.
	 *
	 * @param int                              $step_id        Checkout step post id.
	 * @param string                           $control_ob_id  The A/B group's control bump id.
	 * @param array<int, array<string, mixed>> $all_bumps      Full wcf-order-bumps array for the step.
	 * @return array<string, mixed> Resolved bump payload (control entry or variant-merged-over-control).
	 */
	public function resolve_variant( $step_id, $control_ob_id, $all_bumps ) {
		$control_entry = $this->find_bump( $all_bumps, $control_ob_id );
		if ( null === $control_entry ) {
			return array();
		}
		// Admin exclusion guard — mirror class-cartflows-pro-ab-test-markup.php:52-54.
		if ( $this->is_admin_excluded() ) {
			return $control_entry;
		}
		// Per-request memo prevents duplicate impressions when get_sorted_order_bumps() runs multiple times.
		$memo_key = 'step-' . $step_id;
		if ( isset( $this->request_memo[ $memo_key ][ $control_ob_id ] ) ) {
			return $this->request_memo[ $memo_key ][ $control_ob_id ];
		}
		$variations = $this->get_variations( $control_entry );
		if ( empty( $variations ) ) {
			// Non-A/B bump path — still record one impression per request under a self-referencing key
			// (`stats[ob_id][ob_id]`). Memo above already gates against double-counting on the same request.
			$this->increment_impression( $step_id, $control_ob_id, $control_ob_id );
			$this->request_memo[ $memo_key ][ $control_ob_id ] = $control_entry;
			return $control_entry;
		}
		$cookie_value = $this->get_cookie_value( $step_id, $control_ob_id );
		if ( '' !== $cookie_value && $this->is_valid_variation( $cookie_value, $variations ) ) {
			$resolved_id = $cookie_value;
		} else {
			$resolved_id = $this->choose_display_variation( $variations, $control_ob_id );
			$this->set_cookie_value( $step_id, $control_ob_id, $resolved_id );
			// First-time pin: record an impression for the assigned variant.
			$this->increment_impression( $step_id, $control_ob_id, $resolved_id );
		}
		// Resolved variant IS the control → no merge needed.
		if ( $resolved_id === $control_ob_id ) {
			$this->request_memo[ $memo_key ][ $control_ob_id ] = $control_entry;
			return $control_entry;
		}
		// Resolved a non-control variant → merge variant payload over control.
		$variant_entry = $this->find_bump( $all_bumps, $resolved_id );
		if ( null === $variant_entry ) {
			$this->request_memo[ $memo_key ][ $control_ob_id ] = $control_entry;
			return $control_entry;
		}
		/**
		 * Variant payload merged onto the control's defaults.
		 *
		 * @var array<string, mixed> $merged
		 */
		$merged = wp_parse_args( $variant_entry, $control_entry );
		$this->request_memo[ $memo_key ][ $control_ob_id ] = $merged;
		return $merged;
	}

	/**
	 * Weighted random pick — mirror of Cartflows_Pro_Ab_Test_Factory::choose_display_variation() at :338-356.
	 *
	 * @param array<int, array{id: string, traffic: int|string}> $variations    Variations list from the control bump.
	 * @param string                                             $fallback_id   Returned when no slot matches (defensive).
	 * @return string Picked variation id.
	 */
	public function choose_display_variation( $variations, $fallback_id ) {
		$rand_num    = wp_rand( 0, 100 );
		$measurement = 0;
		foreach ( $variations as $variation ) {
			if ( ! is_array( $variation ) || empty( $variation['id'] ) ) {
				continue;
			}
			$traffic = max( 0, min( 100, intval( $variation['traffic'] ) ) );
			if ( $rand_num >= $measurement && $rand_num <= ( $measurement + $traffic ) ) {
				return (string) $variation['id'];
			}
			$measurement += $traffic;
		}
		return $fallback_id;
	}

	/**
	 * Read the existing `_wcf_bump_products` order meta (already populated by checkout-markup.php
	 * at order placement) and increment the conversion counter for every bump that made it in.
	 * Each key in that meta IS the bump id the visitor was actually shown — which equals the resolved
	 * variant id after the factory's variant-over-control merge — so the key doubles as our `vid`.
	 * Using existing meta avoids polluting order line items with extra admin-visible custom keys.
	 *
	 * @param int $order_id Order id passed by woocommerce_checkout_order_processed.
	 * @return void
	 */
	public function record_conversions_from_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof \WC_Order ) {
			return;
		}
		$step_id_raw = $order->get_meta( '_wcf_checkout_id' );
		$step_id     = is_scalar( $step_id_raw ) ? intval( $step_id_raw ) : 0;
		if ( $step_id <= 0 ) {
			return;
		}
		$bump_products = $order->get_meta( '_wcf_bump_products' );
		if ( ! is_array( $bump_products ) || empty( $bump_products ) ) {
			return;
		}
		foreach ( array_keys( $bump_products ) as $ob_id ) {
			$ob_id_str = (string) $ob_id;
			if ( '' === $ob_id_str ) {
				continue;
			}
			// Fall back to the bump's own id for standalone (non-A/B) bumps so every purchased bump counts.
			$control_ob_id = $this->resolve_control_id( $step_id, $ob_id_str );
			if ( '' === $control_ob_id ) {
				$control_ob_id = $ob_id_str;
			}
			// The ob_id stored in _wcf_bump_products is the rendered (post-merge) variant id; use it as the vid.
			$this->increment_stat( $step_id, $control_ob_id, $ob_id_str, 'conversions' );
		}
	}

	/**
	 * Locate a bump entry by id within the wcf-order-bumps array.
	 *
	 * @param array<int, array<string, mixed>> $bumps wcf-order-bumps array.
	 * @param string                           $id    Bump id to locate.
	 * @return array<string, mixed>|null Entry or null if absent.
	 */
	private function find_bump( $bumps, $id ) {
		foreach ( $bumps as $entry ) {
			if ( is_array( $entry ) && ! empty( $entry['id'] ) && $entry['id'] === $id ) {
				return $entry;
			}
		}
		return null;
	}

	/**
	 * Return the active variations list when the given control entry is running an A/B test.
	 *
	 * @param array<string, mixed> $control_entry Bump entry already confirmed to be a control.
	 * @return array<int, array{id: string, traffic: int|string}>
	 */
	private function get_variations( $control_entry ) {
		if ( empty( $control_entry['ab-test'] ) || empty( $control_entry['ab-test-start'] ) ) {
			return array();
		}
		return isset( $control_entry['ab-test-variations'] ) && is_array( $control_entry['ab-test-variations'] ) ? $control_entry['ab-test-variations'] : array();
	}

	/**
	 * Confirm a candidate id is in the active variations list (cookie may hold a stale variant).
	 *
	 * @param string                                             $candidate_id Id from the cookie.
	 * @param array<int, array{id: string, traffic: int|string}> $variations   Current variations list.
	 * @return bool
	 */
	private function is_valid_variation( $candidate_id, $variations ) {
		foreach ( $variations as $v ) {
			if ( is_array( $v ) && ! empty( $v['id'] ) && (string) $v['id'] === $candidate_id ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Read the per-visitor cookie. Empty string when not set.
	 *
	 * @param int    $step_id        Checkout step id.
	 * @param string $control_ob_id  Control bump id (cookie key suffix).
	 * @return string
	 */
	private function get_cookie_value( $step_id, $control_ob_id ) {
		$name = CARTFLOWS_OB_AB_TEST_COOKIE . $step_id . '-' . $control_ob_id;
		if ( isset( $_COOKIE[ $name ] ) ) { // phpcs:ignore WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___COOKIE
			return sanitize_text_field( wp_unslash( $_COOKIE[ $name ] ) ); // phpcs:ignore WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___COOKIE
		}
		return '';
	}

	/**
	 * Write the per-visitor cookie. 30-day expiry, HttpOnly, SameSite=Lax — mirror Step A/B set_step_cookie() at :180-199.
	 *
	 * @param int    $step_id        Checkout step id.
	 * @param string $control_ob_id  Control bump id.
	 * @param string $variant_id     Resolved variant id to pin.
	 * @return void
	 */
	private function set_cookie_value( $step_id, $control_ob_id, $variant_id ) {
		$name = CARTFLOWS_OB_AB_TEST_COOKIE . $step_id . '-' . $control_ob_id;
		// WordPress always defines COOKIEPATH (wp-includes/default-constants.php); empty string falls back to "/" in setcookie itself.
		$cookiepath  = defined( 'COOKIEPATH' ) ? COOKIEPATH : '/';
		$expire_time = time() + ( 30 * 24 * 60 * MINUTE_IN_SECONDS );
		setcookie( // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.cookies_setcookie
			$name,
			$variant_id,
			array(
				'expires'  => $expire_time,
				'path'     => $cookiepath,
				'domain'   => COOKIE_DOMAIN,
				'secure'   => CARTFLOWS_HTTPS,
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}

	/**
	 * Admin exclusion — logged-in users with manage capability bypass A/B routing entirely.
	 *
	 * @return bool
	 */
	private function is_admin_excluded() {
		return is_user_logged_in() && current_user_can( 'cartflows_manage_flows_steps' );
	}

	/**
	 * Increment an impression for the assigned variant.
	 *
	 * @param int    $step_id        Checkout step id.
	 * @param string $control_ob_id  Control bump id.
	 * @param string $variant_id     Variant id being shown.
	 * @return void
	 */
	private function increment_impression( $step_id, $control_ob_id, $variant_id ) {
		$this->increment_stat( $step_id, $control_ob_id, $variant_id, 'impressions' );
	}

	/**
	 * Read-modify-write a single counter on the wcf-order-bump-ab-stats postmeta.
	 *
	 * @param int    $step_id        Checkout step id.
	 * @param string $control_ob_id  Control bump id (outer key).
	 * @param string $variant_id     Variant id (inner key).
	 * @param string $field          Counter field — 'impressions', 'initiated', or 'conversions'.
	 * @return void
	 */
	private function increment_stat( $step_id, $control_ob_id, $variant_id, $field ) {
		$stats = get_post_meta( $step_id, 'wcf-order-bump-ab-stats', true );
		if ( ! is_array( $stats ) ) {
			$stats = array();
		}
		if ( ! isset( $stats[ $control_ob_id ] ) || ! is_array( $stats[ $control_ob_id ] ) ) {
			$stats[ $control_ob_id ] = array();
		}
		if ( ! isset( $stats[ $control_ob_id ][ $variant_id ] ) || ! is_array( $stats[ $control_ob_id ][ $variant_id ] ) ) {
			$stats[ $control_ob_id ][ $variant_id ] = array(
				'impressions' => 0,
				'initiated'   => 0,
				'conversions' => 0,
			);
		}
		$current = isset( $stats[ $control_ob_id ][ $variant_id ][ $field ] ) ? (int) $stats[ $control_ob_id ][ $variant_id ][ $field ] : 0;
		$stats[ $control_ob_id ][ $variant_id ][ $field ] = $current + 1;
		update_post_meta( $step_id, 'wcf-order-bump-ab-stats', $stats );
	}
}

Cartflows_Pro_Order_Bump_Ab_Factory::get_instance();
