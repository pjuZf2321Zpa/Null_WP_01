---
module: order-bump
---

# order-bump

## Responsibility

Owns the entire order-bump feature on a CartFlows checkout step: the field schema for the `wcf-order-bumps` postmeta, the skin registry that names the render templates, per-visitor product resolution (manual, AI-pool, or A/B variant), visibility rules, the render markup and dynamic CSS, and the two AJAX handlers that mutate the WooCommerce cart when a shopper toggles a bump.

Ownership stops at the cart line: once a bump product is in the cart it is ordinary WooCommerce stock. The admin UI, the `_wcf_bump_products` order-meta writer, the A/B sanitising handlers, and the relevance/embeddings engine all live outside this module.

## Why it is this way

Skins are a registry rather than a hardcoded list because the persisted `style` value doubles as a template filename. Keeping the two together in `Cartflows_Pro_Order_Bump_Skins` means a skin cannot be offered in the admin without a template behind it, and the renderer has one place to ask whether a persisted style is still usable.

Three resolution layers — AI pool, then A/B variant, then template — mutate the same bump row before it is rendered. `load_order_bumps()` exists as the single read point so those layers cannot disagree between render, add-to-cart and validation; the A/B factory's raw `get_post_meta()` is the one place that contract is broken.

The A/B stats count impressions per request rather than per visitor, because the counter sits in the render path and a WooCommerce checkout re-renders its fragments on every field change. That is a deliberate simplification with a real consequence for any rate computed from those numbers.
