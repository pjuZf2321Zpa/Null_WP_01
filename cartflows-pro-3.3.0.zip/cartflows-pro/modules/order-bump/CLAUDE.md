# Module: order-bump

The order-bump feature on a checkout step: the `wcf-order-bumps` field schema, per-visitor product resolution (manual / AI-pool / A/B), visibility rules, render markup and CSS, and the two cart-mutating AJAX handlers.

Read `architecture.md` in this folder before changing this module.

## Rules

- **A skin is only usable once `templates/bump-order/wcf-bump-order-{style}.php` exists** — the registry drops registered skins whose template is unreadable, and the renderer falls back to `style-1` for any style that is not a valid skin, so a missing template degrades instead of rendering an empty wrapper. Register skins through `cartflows_pro_order_bump_skins`; ship the template in the same change. `classes/class-cartflows-pro-order-bump-skins.php`, `classes/class-cartflows-pro-order-bump-product.php:806-813`
- **`wcf-order-bumps` must be read through `load_order_bumps()`** — documented as the single place the raw meta is read, precisely so AI-Auto resolution cannot disagree between render, add-to-cart and validation. The A/B factory bypasses it with a raw `get_post_meta()`. `classes/class-cartflows-pro-order-bump-product.php:183-207`
- **`is_order_bump_visble()` takes a raw bump row, not `prepare_ob_data()` output** — it reads `is_rule`, `rules` and `product`, none of which the prepared array contains. `classes/class-cartflows-pro-order-bump-rules.php:51-63`
- **A posted `product_id` must go through `validate_posted_product()`** — without it any store product can be posted into `_bump_offer_data` and bought at this bump's discount. `classes/class-cartflows-pro-order-bump-product.php:936-961`
- AI copy accepts only the four fields in `get_fields()`, and generated `{{token}}`s only the four in `TOKENS`, which must stay in sync with the renderer's replacement list — unknown tokens are stripped. `classes/class-cartflows-pro-order-bump-ai-copy.php:55,80-104`
- **Only `Cartflows_Pro_Order_Bump_Meta` always loads**; everything else is gated to `plus`/`pro`. Referencing the other five classes on another plugin type is a fatal. `class-cartflows-pro-order-bump.php:52-64`
- `add_pre_checked_order_bumps()` deliberately no-ops during AJAX. `classes/class-cartflows-pro-order-bump-product.php:1613`

## Gotchas

- **`get_sorted_order_bumps()` is a getter that mutates the cart** — it removes cart items for now-invisible bumps, can add a bump product, and refreshes the checkout transient. Any caller that "just wants the list" performs cart writes and impression counting. `classes/class-cartflows-pro-order-bump-product.php:317-362`
- **Bump discount pricing only applies on AJAX requests** — on a plain page load the `custom_price` cart-item data is never pushed onto the product, so the shopper is charged full price. `classes/class-cartflows-pro-order-bump-product.php:1335-1337`
- `prepare_ob_data()` reads `$_POST['_bump_offer_qty']` from the global request, so an unrelated POST on the page can set the quantity of a pre-checked bump. `classes/class-cartflows-pro-order-bump-product.php:1534`
- **Conditional display rules are silently bypassed for pre-checked bumps** — the prepared array has no `is_rule` key, so the first guard returns `true` unconditionally and a rule-hidden pre-checked bump still lands in the cart. `classes/class-cartflows-pro-order-bump-product.php:1622-1624`, `classes/class-cartflows-pro-order-bump-rules.php:53`
- Both AJAX handlers `return;` on nonce failure instead of erroring, so admin-ajax replies `0` and the JS sees a success-shaped empty response. `classes/class-cartflows-pro-order-bump-product.php:892-894,1029-1031`
- **A/B impressions are counted per HTTP request, not per visitor** — every `update_order_review` fragment refresh is another impression, so any conversion rate computed from the stats is deflated by the number of checkout refreshes. `classes/class-cartflows-pro-order-bump-ab-factory.php:183-193`
- `increment_stat()` is an unguarded read-modify-write on postmeta, so concurrent checkouts on the same step lose counts. `classes/class-cartflows-pro-order-bump-ab-factory.php:405-422`
- **The variant pin is written with `setcookie()` from inside the render path** — if headers are already sent the pin silently fails and the visitor is re-assigned (and re-counted) next request. `classes/class-cartflows-pro-order-bump-ab-factory.php:201,356-373`
- **Explicit ordering constraint, commented**: the dynamic-bump filter is hooked at priority `499` because "for wc ajax actions to filter it's value user priority before 499". `classes/class-cartflows-pro-order-bump-product.php:48-49`
- **Workaround comment** — the wrapper carries a `data-update-time` attribute solely because "Woo does not replace fragment if found same". Removing it stops order bumps re-rendering after a payment-method change. `classes/class-cartflows-pro-order-bump-product.php:583-588`
- Three singletons hold mutable per-request state that survives across calls, and `Cartflows_Pro_Order_Bump_Rules::$ob_product_id` is **static**, set per-bump inside the visibility check while cart-item helpers read it — a stale value leaks if those helpers are called directly. `classes/class-cartflows-pro-order-bump-rules.php:29,63,169`
- Schema default is `style-1` while the renderer's inline default is `style-2`. `classes/class-cartflows-pro-order-bump-meta.php:162-165` vs `classes/class-cartflows-pro-order-bump-product.php:628`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
