---
module: optin
---

# optin

## Responsibility

CartFlows Pro's opt-in step add-on. It bootstraps three singletons and, in practice, does exactly two things: surface opt-in **custom billing fields** on the WooCommerce order-admin screen and in WooCommerce order emails, and enqueue the opt-in front-end CSS/JS (plus a Divi-specific stylesheet).

Ownership stops at presentation and asset loading: it neither renders the opt-in form, defines the fields, nor writes any of the meta it reads — `_wcf_optin_id`, `wcf_fields_billing`, `wcf-optin-fields-billing`, `wcf-optin-enable-custom-fields` all belong to the free core plugin.

## Why it is this way

The module is a pure consumer of a four-meta-key contract owned by another plugin, and its working surface is much smaller than its file layout suggests: two of its three classes are empty scaffolding named after behaviour they do not implement, and half of its largest class is dead code.

The admin and email paths deliberately apply *different* visibility rules — the email path additionally requires `show_in_email`, the admin path does not — which is the one intentional asymmetry worth knowing.
