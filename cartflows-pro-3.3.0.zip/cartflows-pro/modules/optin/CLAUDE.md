# Module: optin

Pro's opt-in step add-on. In practice it does two things: surface opt-in custom billing fields on the WooCommerce order-admin screen and in order emails, and enqueue the opt-in front-end assets.

Read `architecture.md` in this folder before changing this module.

## Rules

- `CARTFLOWS_PRO_DIR` / `CARTFLOWS_PRO_URL` must be defined before this file is included, and it must be included **exactly once** — the constants are defined with bare `define()` and no guard. `class-cartflows-pro-optin.php:12-13`
- **Never construct these classes with `new`** — all four constructors are `public` while the classes are singletons, so a second instantiation double-registers every hook. `class-cartflows-pro-optin-markup.php:38-48`
- Anything firing `cartflows_optin_scripts` must do so with a valid global `$post` — it is the only unguarded property access in the file. `class-cartflows-pro-optin-markup.php:155-158`
- The order must carry `_wcf_optin_id` meta or nothing renders; both public callbacks bail on it. `class-cartflows-pro-optin-markup.php:76-80,117-121`
- **A custom field is only emailed if it is present consistently in three places** — the key in `wcf-optin-fields-billing`, `$data['custom']` truthy in `wcf_fields_billing`, and `show_in_email` truthy, plus the enable flag. **The admin-order path deliberately drops the `show_in_email` condition**, so admin and email visibility diverge by design. `class-cartflows-pro-optin-markup.php:85-91,134`
- Custom field values are read from order meta under an **underscore-prefixed** key (`'_' . $field`), so whoever saves the field must use that convention. `class-cartflows-pro-optin-markup.php:94,135`
- `wcf-optin-fields-billing` keys are `billing_`-prefixed while `wcf_fields_billing` keys are not — the two namespaces are bridged at one line. `class-cartflows-pro-optin-markup.php:202`

## Gotchas

- **`optin_fields()` is dead code that would fatal if re-enabled** — it uses two variables that are never defined and calls a method that does not exist on the class. Its `add_filter` is commented out; uncommenting it produces a `Call to undefined method` on every opt-in page render. The code looks maintained but has never executed. `class-cartflows-pro-optin-markup.php:240-243,56`
- `optin_default_fields()` is likewise unregistered and depends on free-plugin symbols this module does not load. **Both "field modification" methods are inert**, so opt-in `required` flags are not enforced here despite appearances. `class-cartflows-pro-optin-markup.php:55,188-192`
- **Two of the three required classes are empty shells** with empty constructors and an unused private static, instantiated for nothing. The file names promise meta-box behaviour that does not exist — a reader will hunt for opt-in meta registration here and find none. `class-cartflows-pro-optin-default-meta.php:38-40`, `class-cartflows-pro-optin-meta-data.php:29,45-47`
- **Requiring a file is a hook-registration side effect**, so `add_filter`/`add_action` timing is determined by *when the module file is included*, not by any hook. Moving the include changes whether WooCommerce hooks register in time. `class-cartflows-pro-optin.php:44-46`
- `$divi_status` is **public, sticky, and set from inside an enqueue callback** — only ever set to `true` and never reset, so on a singleton a second invocation keeps the Divi stylesheet enqueued even in a non-Divi context. `class-cartflows-pro-optin-markup.php:33,160`
- **Every docblock in the module says "Checkout"** — copy-paste from the checkout module, so grepping for either surfaces the other. `class-cartflows-pro-optin.php:3`
- Email field values are passed through **unescaped** while the admin path wraps the identical values in `esc_html()`; the asymmetry relies entirely on WooCommerce escaping the email meta table downstream. `class-cartflows-pro-optin-markup.php:92-95` vs `:135`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan`
