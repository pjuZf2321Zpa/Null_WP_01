<?php
/**
 * Smart Login
 *
 * @package CartFlows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! defined( 'CARTFLOWS_PRO_SMART_LOGIN_DIR' ) ) {
	define( 'CARTFLOWS_PRO_SMART_LOGIN_DIR', CARTFLOWS_PRO_DIR . 'modules/smart-login/' );
}

if ( ! defined( 'CARTFLOWS_PRO_SMART_LOGIN_URL' ) ) {
	define( 'CARTFLOWS_PRO_SMART_LOGIN_URL', CARTFLOWS_PRO_URL . 'modules/smart-login/' );
}

/**
 * Initial Setup
 *
 * @since 2.2.2
 */
class Cartflows_Pro_Smart_Login {

	/**
	 * Member Variable
	 *
	 * @var object instance
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 2.2.2
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor function that initializes required actions and hooks.
	 *
	 * @since 2.2.2
	 */
	public function __construct() {
		require_once CARTFLOWS_PRO_SMART_LOGIN_DIR . 'classes/class-cartflows-pro-smart-login-default-meta.php';
		require_once CARTFLOWS_PRO_SMART_LOGIN_DIR . 'classes/class-cartflows-pro-smart-login-meta-data.php';
		require_once CARTFLOWS_PRO_SMART_LOGIN_DIR . 'classes/class-cartflows-pro-smart-login-markup.php';
	}
}

Cartflows_Pro_Smart_Login::get_instance();
