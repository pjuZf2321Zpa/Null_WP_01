<?php
/**
 * Smart Login modal template.
 *
 * Rendered once in the footer on checkout steps where Smart Login is
 * enabled in overlay mode and the user is a guest. JS toggles
 * visibility via the [hidden] attribute and `body.wcf-smart-login-open`,
 * and switches between the login / forgot views via the modal's
 * `data-view` attribute.
 *
 * @package CartFlows_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wcf-smart-login-overlay" hidden></div>
<div class="wcf-smart-login-modal" role="dialog" aria-modal="true"
	aria-labelledby="wcf-smart-login-title" data-view="login" hidden>
	<div class="wcf-smart-login-modal__header">
		<h2 id="wcf-smart-login-title" class="wcf-smart-login-modal__title">
			<span data-view-title="login"><?php esc_html_e( 'Login', 'cartflows-pro' ); ?></span>
			<span data-view-title="forgot"><?php esc_html_e( 'Lost your password?', 'cartflows-pro' ); ?></span>
		</h2>
		<button type="button" class="wcf-smart-login-modal__close"
				aria-label="<?php esc_attr_e( 'Close', 'cartflows-pro' ); ?>">&times;</button>
	</div>

	<form class="wcf-smart-login-modal__form" data-form="login" data-view-only="login">
		<div class="wcf-smart-login-modal__error" role="alert" hidden></div>
		<div class="wcf-smart-login-modal__field">
			<label for="wcf-smart-login-email"><?php esc_html_e( 'Username or email', 'cartflows-pro' ); ?></label>
			<input type="text" id="wcf-smart-login-email" name="email" class="wcf-smart-login-email" autocomplete="username" required />
		</div>
		<div class="wcf-smart-login-modal__field">
			<label for="wcf-smart-login-password"><?php esc_html_e( 'Password', 'cartflows-pro' ); ?></label>
			<input type="password" id="wcf-smart-login-password" name="password" class="wcf-smart-login-password" autocomplete="current-password" required />
		</div>
		<div class="wcf-smart-login-modal__row">
			<label class="wcf-smart-login-modal__remember">
				<input type="checkbox" name="rememberme" /> <?php esc_html_e( 'Remember me', 'cartflows-pro' ); ?>
			</label>
			<button type="button" class="wcf-smart-login-modal__forgot-link"><?php esc_html_e( 'Lost your password?', 'cartflows-pro' ); ?></button>
		</div>
		<div class="wcf-smart-login-modal__field">
			<button type="submit" class="wcf-smart-login-modal__submit button alt"><?php esc_html_e( 'Login', 'cartflows-pro' ); ?></button>
		</div>
	</form>

	<form class="wcf-smart-login-modal__form" data-form="forgot" data-view-only="forgot">
		<div class="wcf-smart-login-modal__error" role="alert" hidden></div>
		<div class="wcf-smart-login-modal__success" role="status" hidden></div>
		<div class="wcf-smart-login-modal__field">
			<label for="wcf-smart-login-forgot-email"><?php esc_html_e( 'Username or email', 'cartflows-pro' ); ?></label>
			<input type="text" id="wcf-smart-login-forgot-email" name="email" class="wcf-smart-login-forgot-email" autocomplete="username" required />
		</div>
		<div class="wcf-smart-login-modal__field">
			<button type="submit" class="wcf-smart-login-modal__submit button alt"><?php esc_html_e( 'Reset Password', 'cartflows-pro' ); ?></button>
		</div>
		<div class="wcf-smart-login-modal__row">
			<button type="button" class="wcf-smart-login-modal__back-link"><?php esc_html_e( 'Back to Login', 'cartflows-pro' ); ?></button>
		</div>
	</form>
</div>
