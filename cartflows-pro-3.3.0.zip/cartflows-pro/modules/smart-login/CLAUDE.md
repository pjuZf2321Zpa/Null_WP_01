# Module: smart-login

The per-checkout-step "returning customer" login overlay: two settings, the modal markup and its dynamic CSS, a rate-limited lost-password endpoint, and the post-reset redirect.

Read `architecture.md` in this folder before changing this module.

## Rules

- The JS is inert unless the free plugin's localize filter carries `smart_login` — the IIFE returns immediately when it is absent or `enabled !== 'yes'`. `classes/class-cartflows-pro-smart-login-markup.php:241`, `assets/js/wcf-smart-login.js:14-16`
- **Modal markup renders only for `form-style === 'overlay'`, but assets are enqueued for any enabled style** — "enqueued ⇒ modal exists" is false, and `bindModalEvents` silently bails. `classes/class-cartflows-pro-smart-login-markup.php:289,92`
- Consumers of `cartflows_pro_smart_login_modal_html` must stay inside the hand-built kses allow-list — `<select>`, `<textarea>`, and unlisted attributes are stripped silently with no error. `classes/class-cartflows-pro-smart-login-markup.php:311-360`
- `render_modal` and `add_frontend_localize_scripts` read **global `$post`** via an argument-less step check; `enqueue_scripts` does **not** do that check and relies entirely on the enqueue hook firing only on checkout steps. `classes/class-cartflows-pro-smart-login-markup.php:226,276,85-94`
- `handle_lost_password` requires nonce `wcf-smart-login-lost-password` in POST field `security`; the **login** submit uses a different nonce, `woocommerce-login`, verified by the free plugin. `classes/class-cartflows-pro-smart-login-markup.php:382,245`
- The post-reset redirect URL must be same-host **and** resolve via `url_to_postid()` to a CartFlows step — pretty permalinks off means it is silently dropped. `classes/class-cartflows-pro-smart-login-markup.php:465-486`

## Gotchas

- **Dynamic CSS never busts on a design change** — it is cached in post meta and only regenerated when `CARTFLOWS_ASSETS_VERSION` differs; nothing here deletes that meta. Editing a step's colours leaves the modal on the old palette. It is also a post-meta **write on a front-end GET** for anonymous visitors. `classes/class-cartflows-pro-smart-login-markup.php:116-126`
- **`redirect_after_password_reset` calls `exit` inside a WooCommerce action** at priority 10, so every callback registered after it on that action — core's and any third party's — never runs on a Smart-Login-initiated reset. `classes/class-cartflows-pro-smart-login-markup.php:517-518,72`
- **Two consumers race for one piece of user meta** — `_wcf_smart_login_redirect` is consumed-and-deleted by both the reset redirect and the login redirect. Whichever fires first wins; the other sees an empty string. It has no expiry, so an abandoned reset leaves it on the user row indefinitely. `classes/class-cartflows-pro-smart-login-markup.php:38,409,511,543`
- Filter priority `9998` is a deliberate ordering hack with **no comment** — anything at 9999+ silently wins, and "cleaning up" the magic number breaks the post-reset return. `classes/class-cartflows-pro-smart-login-markup.php:69`
- **A comment contradicts the code it labels**: "Only nopriv: logged-in users do not need lost-password" is immediately followed by registering *both* `wp_ajax_nopriv_` and `wp_ajax_`. The priv path then short-circuits with a fake success, so a logged-in caller gets `success: true` and no email. `classes/class-cartflows-pro-smart-login-markup.php:65-67,378-380`
- **Rate-limit counters are consumed before all limits are checked** — the per-email transient is incremented *before* the per-IP limit is evaluated, so an IP-throttled attacker still burns a victim's budget and a legitimate user on that IP is locked out of their own reset. Counters are never cleared on success. `classes/class-cartflows-pro-smart-login-markup.php:440,448`
- **`includes/smart-login-dynamic-css.php` is included by the checkout CSS pipeline, not by this module**, and inherits that caller's locals — with design settings off it emits invalid declarations like `color: ;`. Renaming a local in the *caller* silently changes this file's output. `includes/smart-login-dynamic-css.php:20-22,30-40`
- The `suppressObserver` one-shot flag can be consumed by any unrelated `class` mutation on the watched node, and the whole mechanism depends on the free plugin's `wcf-show` class name — an unversioned cross-plugin DOM contract. `assets/js/wcf-smart-login.js:48,199-213`
- **Overlay mode hides the login UI with `!important` on the body class**, so if the JS fails to load the visitor has *no* login surface at all — CSS has removed the fallback. `assets/css/wcf-smart-login.css:15-18`
- The forgot-password submit is disabled on success and only re-enabled by `setView()` or `closeModal()`, so a mistyped email means the user must close or switch views to retry. `assets/js/wcf-smart-login.js:446`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `npm run lint-js && composer lint && composer phpstan`
