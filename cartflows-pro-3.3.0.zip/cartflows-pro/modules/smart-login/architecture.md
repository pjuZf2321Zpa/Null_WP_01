---
module: smart-login
---

# smart-login

## Responsibility

Owns the CartFlows Pro per-checkout-step "returning customer" login surface: two admin settings (`wcf-smart-login-enable`, `wcf-smart-login-form-style`), the server-rendered overlay modal markup plus its assets and per-step dynamic CSS, a rate-limited lost-password AJAX endpoint, and the post-reset redirect back to the originating step.

Ownership stops at authentication itself: the login POST goes to the **free** plugin's `wcf_woocommerce_login` handler, password reset is WooCommerce's, and email-existence detection is the free plugin's DOM signal. This module only observes and reskins those.

## Why it is this way

Almost all of the module's correctness lives in contracts it does not own — a free-plugin AJAX handler and CSS class it reverse-engineers, a CSS partial included by an external pipeline via inherited locals, a WooCommerce action it terminates with `exit`, and a magic filter priority.

Overlay mode hides the free plugin's own login UI with `!important` so the two surfaces cannot both appear. The consequence is that a JS failure leaves no login surface at all, rather than degrading to the original.
