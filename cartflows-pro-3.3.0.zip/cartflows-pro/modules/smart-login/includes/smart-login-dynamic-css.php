<?php
/**
 * Smart Login modal dynamic CSS partial.
 *
 * Included from the checkout dynamic CSS pipeline. Inherits the variables
 * already in scope ($checkout_id, $output, $submit_*, $button_*).
 *
 * Applies per-step design-settings values (padding, font, height, colors)
 * so the modal button matches the other checkout submit buttons. Global
 * colour defaults are handled via CSS variables in wcf-smart-login.css.
 *
 * @package cartflows-pro
 * @since 2.2.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! isset( $checkout_id ) || ! isset( $output ) ) {
	return;
}

if ( 'yes' !== wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-smart-login-enable' ) ) {
	return;
}

// Ensure all variables are defined; checkout-pro-dynamic-css.php only sets these
// when advanced design settings are enabled.
$submit_color              = isset( $submit_color ) ? $submit_color : '';
$submit_bg_color           = isset( $submit_bg_color ) ? $submit_bg_color : '';
$submit_border_color       = isset( $submit_border_color ) ? $submit_border_color : '';
$submit_tb_padding         = isset( $submit_tb_padding ) ? $submit_tb_padding : '';
$submit_lr_padding         = isset( $submit_lr_padding ) ? $submit_lr_padding : '';
$submit_button_height      = isset( $submit_button_height ) ? $submit_button_height : '';
$button_font_family        = isset( $button_font_family ) ? $button_font_family : '';
$button_font_weight        = isset( $button_font_weight ) ? $button_font_weight : '';
$submit_hover_color        = isset( $submit_hover_color ) ? $submit_hover_color : '';
$submit_bg_hover_color     = isset( $submit_bg_hover_color ) ? $submit_bg_hover_color : '';
$submit_border_hover_color = isset( $submit_border_hover_color ) ? $submit_border_hover_color : '';

$output .= "
	.wcf-smart-login-modal .wcf-smart-login-modal__submit {
		color: {$submit_color};
		background: {$submit_bg_color};
		border-color: {$submit_border_color};
		padding-top: {$submit_tb_padding}px;
		padding-bottom: {$submit_tb_padding}px;
		padding-left: {$submit_lr_padding}px;
		padding-right: {$submit_lr_padding}px;
		min-height: {$submit_button_height};
		font-family: {$button_font_family};
		font-weight: {$button_font_weight};
	}
	.wcf-smart-login-modal .wcf-smart-login-modal__submit:hover {
		color: {$submit_hover_color};
		background-color: {$submit_bg_hover_color};
		border-color: {$submit_border_hover_color};
	}
";
