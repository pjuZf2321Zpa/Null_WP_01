<?php
/**
 * Smart Login meta data (Advanced tab fields).
 *
 * @package cartflows-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Adds Smart Login fields to the checkout step Advanced tab.
 *
 * @since 2.2.2
 */
class Cartflows_Pro_Smart_Login_Meta_Data {

	/**
	 * Instance
	 *
	 * @var Cartflows_Pro_Smart_Login_Meta_Data $instance class instance.
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 2.2.2
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 2.2.2
	 */
	public function __construct() {
		add_filter( 'cartflows_admin_checkout_settings_fields', array( $this, 'add_smart_login_fields' ), 11, 1 );
	}

	/**
	 * Register Smart Login Advanced-tab fields.
	 *
	 * @since 2.2.2
	 *
	 * @param array $settings settings.
	 * @return array Modified settings.
	 */
	public function add_smart_login_fields( $settings ) {

		$settings['settings']['advanced']['fields']['wcf-smart-login-enable'] = array(
			'type'         => 'toggle',
			'label'        => __( 'Enable Smart Login', 'cartflows-pro' ),
			'name'         => 'wcf-smart-login-enable',
			'is_fullwidth' => true,
		);

		$settings['settings']['advanced']['fields']['wcf-smart-login-form-style'] = array(
			'type'          => 'select',
			'label'         => __( 'Login Form Style', 'cartflows-pro' ),
			'name'          => 'wcf-smart-login-form-style',
			'display_align' => 'vertical',
			'options'       => array(
				array(
					'value' => 'overlay',
					'label' => __( 'Overlay', 'cartflows-pro' ),
				),
				array(
					'value' => 'inline',
					'label' => __( 'Inline', 'cartflows-pro' ),
				),
			),
			'conditions'    => array(
				'fields' => array(
					array(
						'name'     => 'wcf-smart-login-enable',
						'operator' => '===',
						'value'    => 'yes',
					),
				),
			),
		);

		return $settings;
	}
}

/**
 * Kicking this off by calling 'get_instance()' method.
 */
Cartflows_Pro_Smart_Login_Meta_Data::get_instance();
