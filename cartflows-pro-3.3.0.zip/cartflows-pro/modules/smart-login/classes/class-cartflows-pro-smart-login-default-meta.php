<?php
/**
 * Smart Login default post meta.
 *
 * @package cartflows-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Smart Login default meta setup.
 *
 * @since 2.2.2
 */
class Cartflows_Pro_Smart_Login_Default_Meta {

	/**
	 * Instance
	 *
	 * @var object $instance class instance.
	 */
	private static $instance;

	/**
	 * Initiator
	 *
	 * @since 2.2.2
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 2.2.2
	 */
	public function __construct() {
		add_filter( 'cartflows_checkout_meta_options', array( $this, 'meta_fields' ), 11, 2 );
	}

	/**
	 * Add Smart Login default meta fields to checkout meta options.
	 *
	 * @since 2.2.2
	 *
	 * @param array $fields  checkout fields.
	 * @param int   $post_id post ID.
	 * @return array Modified fields.
	 */
	public function meta_fields( $fields, $post_id ) {

		if ( ! cartflows_pro_is_active_license() && is_admin() ) {
			return $fields;
		}

		$fields['wcf-smart-login-enable'] = array(
			'default'  => 'no',
			'sanitize' => 'FILTER_SANITIZE_STRING',
		);

		$fields['wcf-smart-login-form-style'] = array(
			'default'  => 'overlay',
			'sanitize' => 'FILTER_SANITIZE_STRING',
		);

		return $fields;
	}
}

/**
 * Kicking this off by calling 'get_instance()' method.
 */
Cartflows_Pro_Smart_Login_Default_Meta::get_instance();
