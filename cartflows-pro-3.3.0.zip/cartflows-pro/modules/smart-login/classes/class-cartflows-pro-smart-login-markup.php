<?php
/**
 * Smart Login Markup
 *
 * @package CartFlows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Handles Smart Login asset enqueue and AJAX handlers.
 *
 * @since 2.2.2
 */
class Cartflows_Pro_Smart_Login_Markup {

	/**
	 * Member Variable
	 *
	 * @var object instance
	 */
	private static $instance;

	/**
	 * AJAX action used for the lost-password handler.
	 *
	 * @var string
	 */
	const LOST_PASSWORD_ACTION = 'cartflows_pro_smart_login_lost_password';

	/**
	 * User-meta key for the post-reset redirect URL.
	 *
	 * @var string
	 */
	const REDIRECT_META_KEY = '_wcf_smart_login_redirect';

	/**
	 * Initiator
	 *
	 * @since 2.2.2
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 *
	 * @since 2.2.2
	 */
	public function __construct() {
		add_action( 'cartflows_checkout_scripts', array( $this, 'enqueue_scripts' ) );
		add_filter( 'global_cartflows_js_localize', array( $this, 'add_frontend_localize_scripts' ), 10, 1 );

		// Render the modal markup once in the footer (overlay mode, guests only).
		add_action( 'wp_footer', array( $this, 'render_modal' ), 5 );

		// Only nopriv: logged-in users do not need lost-password.
		add_action( 'wp_ajax_nopriv_' . self::LOST_PASSWORD_ACTION, array( $this, 'handle_lost_password' ) );
		add_action( 'wp_ajax_' . self::LOST_PASSWORD_ACTION, array( $this, 'handle_lost_password' ) );

		add_filter( 'woocommerce_login_redirect', array( $this, 'login_redirect_to_checkout' ), 9998, 2 );

		// After WooCommerce processes a password reset, redirect back to the originating checkout step.
		add_action( 'woocommerce_customer_reset_password', array( $this, 'redirect_after_password_reset' ), 10, 1 );
	}

	/**
	 * Enqueue Smart Login scripts and styles.
	 *
	 * @since 2.2.2
	 * @return void
	 */
	public function enqueue_scripts() {

		global $post;

		if ( ! $post ) {
			return;
		}

		$step_id       = $post->ID;
		$smart_enabled = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-smart-login-enable' );

		if ( 'yes' !== $smart_enabled || is_user_logged_in() ) {
			return;
		}

		wp_enqueue_script(
			'wcf-smart-login',
			CARTFLOWS_PRO_SMART_LOGIN_URL . 'assets/js/wcf-smart-login.js',
			array( 'jquery' ),
			CARTFLOWS_PRO_VER,
			true
		);

		wp_enqueue_style(
			'wcf-smart-login',
			CARTFLOWS_PRO_SMART_LOGIN_URL . 'assets/css/wcf-smart-login.css',
			array(),
			CARTFLOWS_PRO_VER
		);

		// The modal renders in <body> — outside `.wcf-embed-checkout-form` — so the
		// checkout's scoped CSS variables (button colour, field colour, etc.) do not
		// reach it. Mirror the relevant design tokens onto `.wcf-smart-login-modal`.
		// Cached per-step against the assets version, mirroring the pattern used by
		// `Cartflows_Pro_Checkout_Markup::generate_style()`.
		$cached_style   = get_post_meta( $step_id, 'wcf-smart-login-dynamic-css', true );
		$cached_version = get_post_meta( $step_id, 'wcf-smart-login-dynamic-css-version', true );

		$style       = is_string( $cached_style ) ? $cached_style : '';
		$css_version = is_string( $cached_version ) ? $cached_version : '';

		if ( '' === $style || CARTFLOWS_ASSETS_VERSION !== $css_version ) {
			$style = $this->generate_style( $step_id );
			update_post_meta( $step_id, 'wcf-smart-login-dynamic-css', $style );
			update_post_meta( $step_id, 'wcf-smart-login-dynamic-css-version', CARTFLOWS_ASSETS_VERSION );
		}

		if ( '' !== $style ) {
			wp_add_inline_style( 'wcf-smart-login', $style );
		}
	}

	/**
	 * Generate the Smart Login modal dynamic CSS for a step.
	 *
	 * Reads the same meta values as the checkout dynamic CSS so the modal
	 * inherits per-step branding (button colour, field colour, etc.). Falls
	 * back to instant-checkout's hardcoded primary (`#111`) when the step is
	 * using the instant-checkout layout and no per-step primary is set, so
	 * the modal stays visually consistent with the form behind it.
	 *
	 * @since 2.2.2
	 *
	 * @param int $step_id Current CartFlows step ID.
	 * @return string CSS rule block, or empty string when there is nothing to output.
	 */
	public function generate_style( $step_id ) {

		$primary_color = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-primary-color' );

		// Instant-checkout layout sets `--wcf-primary-color: #111` in static CSS
		// (see assets/css/checkout-template.css). When the step uses that layout
		// and the user has not customised the primary colour, mirror that default
		// so the modal does not fall back to the global `#f16334`.
		if ( empty( $primary_color ) && Cartflows_Pro_Helper::is_instant_layout_enabled() ) {
			$primary_color = '#111';
		}

		$advanced = 'yes' === wcf()->options->get_checkout_meta_value( $step_id, 'wcf-advance-options-fields' );

		$btn_bg       = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-submit-bg-color', $primary_color ) : $primary_color;
		$btn_bg_hover = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-submit-bg-hover-color', $primary_color ) : $primary_color;
		$btn_color    = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-submit-color' ) : '';
		$btn_hover    = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-submit-hover-color' ) : '';

		$field_bg     = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-field-bg-color' ) : '';
		$field_border = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-field-border-color' ) : '';
		$field_color  = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-field-color' ) : '';
		$field_height = $advanced ? wcf()->options->get_checkout_meta_value( $step_id, 'wcf-input-field-size' ) : '';

		$lines = array();

		if ( ! empty( $primary_color ) ) {
			$lines[] = '--wcf-primary-color:' . esc_attr( $primary_color ) . ';';
		}

		if ( ! empty( $btn_bg ) ) {
			$lines[] = '--wcf-btn-bg-color:' . esc_attr( $btn_bg ) . ';';
			$lines[] = '--wcf-btn-bg-hover-color:' . esc_attr( ! empty( $btn_bg_hover ) ? $btn_bg_hover : $btn_bg ) . ';';
		}

		if ( ! empty( $btn_color ) ) {
			$lines[] = '--wcf-btn-text-color:' . esc_attr( $btn_color ) . ';';
			$lines[] = '--wcf-btn-hover-text-color:' . esc_attr( ! empty( $btn_hover ) ? $btn_hover : $btn_color ) . ';';
		}

		if ( ! empty( $field_bg ) ) {
			$lines[] = '--wcf-field-bg-color:' . esc_attr( $field_bg ) . ';';
		}

		if ( ! empty( $field_border ) ) {
			$lines[] = '--wcf-field-border-color:' . esc_attr( $field_border ) . ';';
		}

		if ( ! empty( $field_color ) ) {
			$lines[] = '--wcf-field-text-color:' . esc_attr( $field_color ) . ';';
		}

		if ( ! empty( $field_height ) ) {
			$lines[] = '--wcf-field-min-height:' . esc_attr( $field_height ) . ';';
		}

		if ( empty( $lines ) ) {
			return '';
		}

		return '.wcf-smart-login-modal{' . implode( '', $lines ) . '}';
	}

	/**
	 * Add Smart Login config to the cartflows JS localize object.
	 *
	 * @since 2.2.2
	 * @param array $localize Existing localize data.
	 * @return array Modified localize data.
	 */
	public function add_frontend_localize_scripts( $localize ) {

		global $post;

		if ( ! $post || is_user_logged_in() ) {
			return $localize;
		}

		// is_step_post_type() checks $post->post_type with no argument.
		if ( ! wcf()->utils->is_step_post_type() ) {
			return $localize;
		}

		$step_id = $post->ID;

		// Cache repeated meta lookups for this step.
		$smart_enabled = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-smart-login-enable' );

		if ( 'yes' !== $smart_enabled ) {
			return $localize;
		}

		$form_style = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-smart-login-form-style' );

		$localize['smart_login'] = array(
			'enabled'             => $smart_enabled,
			'mode'                => $form_style,
			'lost_password_nonce' => wp_create_nonce( 'wcf-smart-login-lost-password' ),
			'login_nonce'         => wp_create_nonce( 'woocommerce-login' ),
			'ajax_url'            => admin_url( 'admin-ajax.php' ),
			'actions'             => array(
				'lost_password' => self::LOST_PASSWORD_ACTION,
			),
		);

		return $localize;
	}

	/**
	 * Render the Smart Login modal markup in the footer.
	 *
	 * Bails on non-step requests, when Smart Login is disabled for the
	 * current step, when the form style is not `overlay`, or when the
	 * visitor is logged in. The captured template HTML is passed
	 * through the `cartflows_pro_smart_login_modal_html` filter to
	 * allow downstream customization.
	 *
	 * @since 2.2.2
	 * @return void
	 */
	public function render_modal() {

		global $post;

		if ( ! $post || is_user_logged_in() ) {
			return;
		}

		// is_step_post_type() checks $post->post_type with no argument.
		if ( ! wcf()->utils->is_step_post_type() ) {
			return;
		}

		$step_id       = $post->ID;
		$smart_enabled = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-smart-login-enable' );

		if ( 'yes' !== $smart_enabled ) {
			return;
		}

		$form_style = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-smart-login-form-style' );

		if ( 'overlay' !== $form_style ) {
			return;
		}

		ob_start();
		require CARTFLOWS_PRO_SMART_LOGIN_DIR . 'templates/login-modal.php';
		$html = (string) ob_get_clean();

		/**
		 * Filter the rendered Smart Login modal HTML.
		 *
		 * @since 2.2.2
		 *
		 * @param string $html    Captured modal markup.
		 * @param int    $step_id Current CartFlows step ID.
		 */
		$filtered_html = apply_filters( 'cartflows_pro_smart_login_modal_html', $html, $step_id );

		// `wp_kses_post` does not allow `<form>` / `<input>` / `<button>` tags
		// in the "post" context, so build a custom allow-list that preserves
		// the modal's interactive structure while still escaping anything
		// unexpected returned by filter consumers.
		$allowed           = wp_kses_allowed_html( 'post' );
		$allowed['form']   = array(
			'class'          => true,
			'data-form'      => true,
			'data-view-only' => true,
		);
		$allowed['input']  = array(
			'type'         => true,
			'id'           => true,
			'name'         => true,
			'class'        => true,
			'autocomplete' => true,
			'required'     => true,
			'value'        => true,
		);
		$allowed['button'] = array(
			'type'       => true,
			'class'      => true,
			'aria-label' => true,
		);
		$allowed['label']  = array(
			'for'   => true,
			'class' => true,
		);
		$allowed['div']    = array_merge(
			isset( $allowed['div'] ) ? $allowed['div'] : array(),
			array(
				'role'            => true,
				'aria-modal'      => true,
				'aria-labelledby' => true,
				'data-view'       => true,
				'hidden'          => true,
				'data-view-title' => true,
			)
		);
		$allowed['span']   = array_merge(
			isset( $allowed['span'] ) ? $allowed['span'] : array(),
			array(
				'data-view-title' => true,
			)
		);
		$allowed['h2']     = array_merge(
			isset( $allowed['h2'] ) ? $allowed['h2'] : array(),
			array(
				'id'    => true,
				'class' => true,
			)
		);

		echo wp_kses( $filtered_html, $allowed );
	}

	/**
	 * Handle the lost password AJAX request.
	 *
	 * Returns a generic success message in all paths to prevent email
	 * enumeration. Applies per-email and per-IP rate limiting before
	 * triggering retrieve_password().
	 *
	 * @since 2.2.2
	 * @return void
	 */
	public function handle_lost_password() {

		$generic_message = __( 'If an account exists for that username or email, a password reset link has been sent.', 'cartflows-pro' );

		// Logged-in users do not need this flow.
		if ( is_user_logged_in() ) {
			wp_send_json_success( array( 'message' => $generic_message ) );
		}

		if ( ! check_ajax_referer( 'wcf-smart-login-lost-password', 'security', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed.', 'cartflows-pro' ) ), 403 );
		}

		$identifier = isset( $_POST['email'] ) ? sanitize_text_field( wp_unslash( $_POST['email'] ) ) : '';

		if ( '' === $identifier ) {
			wp_send_json_error( array( 'message' => __( 'Please enter your username or email address.', 'cartflows-pro' ) ) );
		}

		$user = is_email( $identifier )
			? get_user_by( 'email', sanitize_email( $identifier ) )
			: get_user_by( 'login', $identifier );

		// Rate-limit per-email + per-IP keyed off resolved email (so username + email share a bucket); on hit, return neutral success to hide throttling.
		$rate_key = ( $user instanceof \WP_User && ! empty( $user->user_email ) )
			? $user->user_email
			: strtolower( $identifier );

		if ( ! $this->is_within_rate_limits( $rate_key ) ) {
			wp_send_json_success( array( 'message' => $generic_message ) );
		}

		// Stash the checkout URL only for a known user; URL is validated for same-host AND CartFlows step.
		$checkout_url = isset( $_POST['checkout_url'] ) ? esc_url_raw( (string) wp_unslash( $_POST['checkout_url'] ) ) : '';

		if ( $user instanceof \WP_User && $checkout_url && $this->is_valid_checkout_redirect( $checkout_url ) ) {
			update_user_meta( $user->ID, self::REDIRECT_META_KEY, esc_url_raw( $checkout_url ) );
		}

		if ( $user instanceof \WP_User ) {
			// Trigger password retrieval (accepts username or email); discard result and always return the generic success.
			retrieve_password( $user->user_login );
		}

		wp_send_json_success( array( 'message' => $generic_message ) );
	}

	/**
	 * Check rate limits for the lost-password endpoint.
	 *
	 * Per-email: 3 requests per 15 minutes.
	 * Per-IP:    10 requests per hour.
	 *
	 * @since 2.2.2
	 *
	 * @param string $email Sanitized email address being requested.
	 * @return bool True when the request is within all limits.
	 */
	private function is_within_rate_limits( $email ) {

		$email_key  = 'cf_pro_smart_login_pwd_' . md5( strtolower( $email ) );
		$email_hits = intval( get_transient( $email_key ) );

		if ( $email_hits >= 3 ) {
			return false;
		}

		set_transient( $email_key, $email_hits + 1, 15 * MINUTE_IN_SECONDS );

		// REMOTE_ADDR is required to throttle by client IP; only its hash is stored, never the raw value.
		// phpcs:ignore WordPressVIPMinimum.Variables.ServerVariables.UserControlledHeaders, WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___SERVER__REMOTE_ADDR__
		$remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$ip_key      = 'cf_pro_smart_login_pwd_ip_' . md5( $remote_addr );
		$ip_hits     = intval( get_transient( $ip_key ) );

		if ( $ip_hits >= 10 ) {
			return false;
		}

		set_transient( $ip_key, $ip_hits + 1, HOUR_IN_SECONDS );

		return true;
	}

	/**
	 * Validate that the supplied URL points to a checkout step on the same host.
	 *
	 * @since 2.2.2
	 *
	 * @param string $url Candidate redirect URL.
	 * @return bool True when the URL is safe to store as a post-reset redirect.
	 */
	private function is_valid_checkout_redirect( $url ) {

		$parsed = wp_parse_url( $url );
		$home   = wp_parse_url( home_url() );

		if ( empty( $parsed['host'] ) || empty( $home['host'] ) ) {
			return false;
		}

		if ( $parsed['host'] !== $home['host'] ) {
			return false;
		}

		// phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.url_to_postid_url_to_postid -- VIP cache wrapper not available outside VIP environments.
		$post_id = url_to_postid( $url );

		if ( ! $post_id ) {
			return false;
		}

		return wcf()->utils->is_step_post_type( get_post_type( $post_id ) );
	}

	/**
	 * After a successful password reset via WooCommerce, redirect the user
	 * back to the originating checkout step (when one was stored and it is
	 * still a valid CartFlows step on the same host).
	 *
	 * @since 2.2.2
	 *
	 * @param \WP_User|mixed $user User whose password was reset.
	 * @return void
	 */
	public function redirect_after_password_reset( $user ) {

		if ( ! $user instanceof \WP_User ) {
			return;
		}

		$stored_meta  = get_user_meta( $user->ID, self::REDIRECT_META_KEY, true );
		$checkout_url = is_string( $stored_meta ) ? $stored_meta : '';

		if ( '' === $checkout_url ) {
			return;
		}

		delete_user_meta( $user->ID, self::REDIRECT_META_KEY );

		if ( ! $this->is_valid_checkout_redirect( $checkout_url ) ) {
			return;
		}

		wp_safe_redirect( esc_url_raw( $checkout_url ) );
		exit;
	}

	/**
	 * Redirect back to the checkout page after password reset login.
	 *
	 * @since 2.2.2
	 * @param string         $redirect Redirect URL.
	 * @param \WP_User|mixed $user     Logged-in user object.
	 * @return string Modified redirect URL.
	 */
	public function login_redirect_to_checkout( $redirect, $user ) {

		if ( ! $user instanceof \WP_User ) {
			return $redirect;
		}

		$stored_meta  = get_user_meta( $user->ID, self::REDIRECT_META_KEY, true );
		$checkout_url = is_string( $stored_meta ) ? $stored_meta : '';

		if ( '' === $checkout_url ) {
			return $redirect;
		}

		// Always clear the stored value once consumed.
		delete_user_meta( $user->ID, self::REDIRECT_META_KEY );

		// Re-validate on read: same host AND a CartFlows step post.
		if ( ! $this->is_valid_checkout_redirect( $checkout_url ) ) {
			return function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : $redirect;
		}

		return esc_url_raw( $checkout_url );
	}
}

Cartflows_Pro_Smart_Login_Markup::get_instance();
