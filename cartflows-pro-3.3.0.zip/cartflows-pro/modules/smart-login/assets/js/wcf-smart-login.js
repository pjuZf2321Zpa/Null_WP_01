/**
 * CartFlows Pro Smart Login
 *
 * Handles detecting returning users by email on checkout,
 * and providing Overlay / Inline login.
 *
 * The modal markup is rendered server-side (see modules/smart-login/templates/login-modal.php
 * hooked on wp_footer). This script only wires up behavior — it does not build DOM.
 */

( function ( $, config ) {
	'use strict';

	if ( ! config || 'yes' !== config.enabled ) {
		return;
	}

	/**
	 * Static selectors for elements rendered by PHP / present on the page.
	 */
	const SELECTORS = {
		emailField: '#billing_email',
		loginSection: '.wcf-customer-login-section',
		overlay: '.wcf-smart-login-overlay',
		modal: '.wcf-smart-login-modal',
		closeBtn: '.wcf-smart-login-modal__close',
		loginForm: '[data-form="login"]',
		forgotForm: '[data-form="forgot"]',
		forgotLink: '.wcf-smart-login-modal__forgot-link',
		backLink: '.wcf-smart-login-modal__back-link',
	};

	const wcfSmartLogin = {
		/**
		 * Cached previously-focused element, restored on modal close.
		 */
		_lastFocused: null,

		/**
		 * MutationObserver instance for the inline login section.
		 */
		_observer: null,

		/**
		 * When true, observer callbacks are ignored — used to avoid feedback
		 * loops when this module mutates the watched node itself.
		 */
		suppressObserver: false,

		/**
		 * Initialize the Smart Login module.
		 */
		init() {
			// In overlay mode, add a body class so CSS can keep the inline
			// login section hidden without relying solely on JS timing.
			if ( 'overlay' === config.mode ) {
				$( 'body' ).addClass( 'wcf-smart-login-overlay-mode' );
				this.bindLoginLinkOverride();
			}

			this.bindModalEvents();
			this.observeLoginSection();

			// Re-attach the observer when WooCommerce re-renders the checkout
			// (the watched node may have been replaced).
			const self = this;
			$( document.body ).on( 'updated_checkout', function () {
				self.observeLoginSection();
			} );
		},

		/**
		 * Bind all modal event handlers once. The modal markup is server-rendered
		 * and persistent in the DOM, so we never need to rebind on open.
		 */
		bindModalEvents() {
			const $modal = $( SELECTORS.modal );

			if ( ! $modal.length ) {
				return;
			}

			const self = this;
			const $overlay = $( SELECTORS.overlay );

			$overlay.on( 'click', function () {
				self.closeModal();
			} );

			$modal.on( 'click', SELECTORS.closeBtn, function () {
				self.closeModal();
			} );

			$modal.on( 'click', SELECTORS.forgotLink, function ( e ) {
				e.preventDefault();
				self.setView( 'forgot' );
				$modal
					.find( SELECTORS.forgotForm )
					.find( 'input[name="email"]' )
					.trigger( 'focus' );
			} );

			$modal.on( 'click', SELECTORS.backLink, function ( e ) {
				e.preventDefault();
				self.setView( 'login' );
				$modal
					.find( SELECTORS.loginForm )
					.find( 'input[name="password"]' )
					.trigger( 'focus' );
			} );

			$modal.on( 'submit', SELECTORS.loginForm, function ( e ) {
				e.preventDefault();
				self.submitLogin( e );
			} );

			$modal.on( 'submit', SELECTORS.forgotForm, function ( e ) {
				e.preventDefault();
				self.submitForgotPassword( e );
			} );

			// Focus trap.
			$modal.on( 'keydown', function ( e ) {
				if ( 'Tab' !== e.key ) {
					return;
				}
				const focusable = $modal
					.find(
						'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex="0"]:not([disabled])'
					)
					.filter( ':visible' );
				if ( ! focusable.length ) {
					return;
				}
				const first = focusable.first();
				const last = focusable.last();
				// eslint-disable-next-line @wordpress/no-global-active-element
				if ( e.shiftKey && $( document.activeElement ).is( first ) ) {
					e.preventDefault();
					last.trigger( 'focus' );
				} else if (
					! e.shiftKey &&
					// eslint-disable-next-line @wordpress/no-global-active-element
					$( document.activeElement ).is( last )
				) {
					e.preventDefault();
					first.trigger( 'focus' );
				}
			} );
		},

		/**
		 * Override the free plugin's click handler on .wcf-customer-login-url
		 * so that clicking the login link opens our modal instead of the
		 * free plugin's inline slide-down section.
		 *
		 * The selector pair also covers WooCommerce's native "Returning customer?"
		 * toggle, which is the only login link present on the legacy one-column,
		 * two-column and two-step layouts (those render via raw
		 * [woocommerce_checkout] and never emit the wcf-prefixed wrapper).
		 */
		bindLoginLinkOverride() {
			const self = this;
			const triggerSelector =
				'.wcf-customer-login-url, .woocommerce-form-login-toggle a.showlogin';
			$( document.body )
				.off( 'click.wcf_smart_login_url', triggerSelector )
				.on(
					'click.wcf_smart_login_url',
					triggerSelector,
					function ( e ) {
						e.preventDefault();
						self.openModal();
					}
				);
		},

		/**
		 * Watch .wcf-customer-login-section for the 'wcf-show' class that the
		 * free plugin adds when an existing email is detected.
		 */
		observeLoginSection() {
			const self = this;
			const $section = $( SELECTORS.loginSection );

			if ( ! $section.length ) {
				return;
			}

			// Disconnect any prior observer (the watched node may have been
			// replaced by a checkout fragment update).
			if ( self._observer ) {
				self._observer.disconnect();
			}

			self._observer = new window.MutationObserver( function (
				mutations
			) {
				if ( self.suppressObserver ) {
					self.suppressObserver = false;
					return;
				}

				let i;
				for ( i = 0; i < mutations.length; i++ ) {
					if ( 'class' !== mutations[ i ].attributeName ) {
						continue;
					}

					if ( $section.hasClass( 'wcf-show' ) ) {
						const email = $( SELECTORS.emailField ).val();
						// Suppress observer for the upcoming DOM mutation we trigger.
						self.suppressObserver = true;
						self.onEmailCheckResult( true, email );
					}

					break;
				}
			} );

			self._observer.observe( $section[ 0 ], {
				attributes: true,
				attributeFilter: [ 'class' ],
			} );
		},

		/**
		 * Called when the email check result is available.
		 *
		 * @param {boolean} emailExists Whether the entered email belongs to a registered user.
		 */
		onEmailCheckResult( emailExists ) {
			if ( ! emailExists ) {
				return;
			}

			if ( 'overlay' === config.mode ) {
				this.suppressInlineSection();
			}
		},

		/**
		 * In overlay mode, cancel any in-progress slideDown animation and
		 * remove the wcf-show class. The CSS rule on body.wcf-smart-login-overlay-mode
		 * ensures the section stays hidden regardless of animation timing.
		 */
		suppressInlineSection() {
			// stop( clearQueue, jumpToEnd ) — false = stay at current position, don't flash.
			$( SELECTORS.loginSection )
				.stop( true, false )
				.removeClass( 'wcf-show' )
				.attr( 'hidden', 'hidden' );
		},

		/**
		 * Switch the visible view inside the modal.
		 *
		 * @param {string} view Either 'login' or 'forgot'.
		 */
		setView( view ) {
			const $modal = $( SELECTORS.modal );
			// CSS handles showing/hiding the [data-view-title] spans based on
			// this attribute — no per-span JS toggling needed.
			$modal.attr( 'data-view', view );
			// Reset error/success messaging when changing views.
			$modal
				.find(
					'.wcf-smart-login-modal__error, .wcf-smart-login-modal__success'
				)
				.text( '' )
				.attr( 'hidden', 'hidden' );
			$modal
				.find( '.wcf-smart-login-modal__submit' )
				.prop( 'disabled', false );
		},

		/**
		 * Open the (already rendered) overlay login modal.
		 */
		openModal() {
			const $modal = $( SELECTORS.modal );
			const $overlay = $( SELECTORS.overlay );

			// Bail if the PHP-rendered modal isn't on the page.
			if ( ! $modal.length || ! $overlay.length ) {
				return;
			}

			// Cache the element that had focus so we can restore it on close.
			// eslint-disable-next-line @wordpress/no-global-active-element
			this._lastFocused = document.activeElement || null;

			// Reset to login view with clean state.
			this.setView( 'login' );

			// Pre-fill email from billing field into both forms.
			const email = $( SELECTORS.emailField ).val() || '';
			$modal
				.find( SELECTORS.loginForm )
				.find( 'input[name="email"]' )
				.val( email );
			$modal
				.find( SELECTORS.forgotForm )
				.find( 'input[name="email"]' )
				.val( email );

			// Show overlay + modal.
			$overlay.removeAttr( 'hidden' );
			$modal.removeAttr( 'hidden' );
			$( 'body' ).addClass( 'wcf-smart-login-open' );

			// Focus the password field since email is pre-filled.
			$modal
				.find( SELECTORS.loginForm )
				.find( 'input[name="email"]' )
				.trigger( 'focus' );

			// Close on Escape.
			const self = this;
			$( document ).on( 'keydown.wcf_smart_login', function ( e ) {
				if ( 'Escape' === e.key ) {
					self.closeModal();
				}
			} );
		},

		/**
		 * Submit the login form via the existing free-plugin AJAX handler.
		 *
		 * @param {Event} e Submit event.
		 */
		submitLogin( e ) {
			const $form = $( e.currentTarget );
			const $error = $form.find( '.wcf-smart-login-modal__error' );
			const $submit = $form.find( '.wcf-smart-login-modal__submit' );

			const email = $form.find( 'input[name="email"]' ).val();
			const password = $form.find( 'input[name="password"]' ).val();
			const remember = $form
				.find( 'input[name="rememberme"]' )
				.is( ':checked' );

			$error.text( '' ).attr( 'hidden', 'hidden' );
			$submit.prop( 'disabled', true );

			// wcf_woocommerce_login verifies the 'woocommerce-login' nonce.
			// Prefer the Pro-rendered config.login_nonce, fall back to the free
			// plugin's globally-exposed cartflows.woocommerce_login_nonce.
			const nonce =
				config.login_nonce ||
				( 'undefined' !== typeof window.cartflows &&
					window.cartflows.woocommerce_login_nonce ) ||
				'';
			if ( ! nonce ) {
				// eslint-disable-next-line no-console
				console.warn( 'CartFlows Smart Login: missing login nonce' );
			}
			const loginAction =
				config.actions && config.actions.login
					? config.actions.login
					: 'wcf_woocommerce_login';
			const ajaxUrl =
				config.ajax_url ||
				( 'undefined' !== typeof window.cartflows &&
					window.cartflows.ajax_url ) ||
				'';

			$.ajax( {
				url: ajaxUrl,
				type: 'POST',
				data: {
					action: loginAction,
					security: nonce,
					email,
					password,
					rememberme: remember ? 1 : 0,
				},
				success( response ) {
					// The free plugin's wcf_woocommerce_login handler returns
					// { success: true, data: { success: bool, error: string } }.
					if ( response.data && response.data.success ) {
						window.location.reload();
					} else {
						const msg =
							response.data && response.data.error
								? response.data.error
								: '';
						$error.text( msg ).removeAttr( 'hidden' );
						$submit.prop( 'disabled', false );
					}
				},
				error() {
					// Server-rendered fallback message lives inside the error node.
					$error.removeAttr( 'hidden' );
					$submit.prop( 'disabled', false );
				},
			} );
		},

		/**
		 * Submit the forgot password form.
		 *
		 * @param {Event} e Submit event.
		 */
		submitForgotPassword( e ) {
			const $form = $( e.currentTarget );
			const $error = $form.find( '.wcf-smart-login-modal__error' );
			const $success = $form.find( '.wcf-smart-login-modal__success' );
			const $submit = $form.find( '.wcf-smart-login-modal__submit' );

			const email = $form.find( 'input[name="email"]' ).val();

			$error.text( '' ).attr( 'hidden', 'hidden' );
			$success.text( '' ).attr( 'hidden', 'hidden' );
			$submit.prop( 'disabled', true );

			const lostPasswordAction =
				config.actions && config.actions.lost_password
					? config.actions.lost_password
					: 'cartflows_pro_smart_login_lost_password';
			const ajaxUrl =
				config.ajax_url ||
				( 'undefined' !== typeof window.cartflows &&
					window.cartflows.ajax_url ) ||
				'';

			$.ajax( {
				url: ajaxUrl,
				type: 'POST',
				data: {
					action: lostPasswordAction,
					security: config.lost_password_nonce,
					email,
					checkout_url: window.location.href,
				},
				success( response ) {
					if ( response.success ) {
						const msg =
							response.data && response.data.message
								? response.data.message
								: '';
						if ( msg ) {
							$success.text( msg );
						}
						$success.removeAttr( 'hidden' );
						$submit.prop( 'disabled', true );
					} else {
						const msg =
							response.data && response.data.message
								? response.data.message
								: '';
						if ( msg ) {
							$error.text( msg );
						}
						$error.removeAttr( 'hidden' );
						$submit.prop( 'disabled', false );
					}
				},
				error() {
					$error.removeAttr( 'hidden' );
					$submit.prop( 'disabled', false );
				},
			} );
		},

		/**
		 * Close and hide the modal and overlay.
		 */
		closeModal() {
			const $modal = $( SELECTORS.modal );
			const $overlay = $( SELECTORS.overlay );

			$modal.attr( 'hidden', 'hidden' );
			$overlay.attr( 'hidden', 'hidden' );
			$( 'body' ).removeClass( 'wcf-smart-login-open' );
			$( document ).off( 'keydown.wcf_smart_login' );

			// Reset error/success messages so they don't flash on next open.
			$modal
				.find(
					'.wcf-smart-login-modal__error, .wcf-smart-login-modal__success'
				)
				.text( '' )
				.attr( 'hidden', 'hidden' );
			$modal
				.find( '.wcf-smart-login-modal__submit' )
				.prop( 'disabled', false );

			// Restore focus to the element that had it before opening, if it
			// is still in the DOM and focusable.
			const prev = this._lastFocused;
			this._lastFocused = null;
			if (
				prev &&
				'function' === typeof prev.focus &&
				document.body.contains( prev )
			) {
				try {
					prev.focus();
				} catch ( err ) {
					// Silently ignore — element may have become unfocusable.
				}
			}
		},
	};

	$( function () {
		wcfSmartLogin.init();
	} );
} )(
	jQuery,
	'undefined' !== typeof cartflows && cartflows.smart_login
		? cartflows.smart_login
		: null
);
