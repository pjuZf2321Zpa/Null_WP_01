# Module: offer

Shared base layer for upsell/downsell offer steps: frontend assets and localized payload, the accept/reject pipeline, offer product shortcodes, admin meta fields, the Subscriptions bridge, and parent↔child order linking.

Read `architecture.md` in this folder before changing this module.

## Rules

- **`offer_accepted()` requires a fully-populated `$extra_data`; no key is guarded** — `order_id`, `order_key`, `product_id`, `variation_id`, `input_qty`, `template_type` and `action` are all read unguarded. `classes/class-cartflows-pro-base-offer-markup.php:276-281,468`
- **`template_type` must be exactly `'upsell'`; anything else is treated as a downsell.** The string is also concatenated into the dynamic `cartflows_{$step_type}_offer_accepted` hook, so a typo silently creates a hook nobody listens to. `classes/class-cartflows-pro-base-offer-markup.php:477-486`
- `order_key` must match the order or the offer is refused, **before any charge**. `classes/class-cartflows-pro-base-offer-markup.php:253-261`
- The `cartflows_offer_js_localize` filter **cannot change identity fields** — `order_id`, `order_key`, `step_id` are re-asserted after the filter. `classes/class-cartflows-pro-base-offer-markup.php:210-215`
- Only `variation_id` and `input_qty` are honoured from the stored offer-product order meta; all other keys are ignored by design. `classes/class-cartflows-pro-base-offer-markup.php:266-272`
- **Only the nonce for the active step type is localized** — JS that assumes both upsell and downsell pairs exist breaks. `classes/class-cartflows-pro-base-offer-markup.php:164-171`
- Negative-priced and out-of-stock offers are hard-refused before charging; a zero/empty price short-circuits the gateway and is treated as a **successful** charge. `classes/class-cartflows-pro-base-offer-markup.php:368-409,454-456`
- `get_next_step_id_for_skip_offer()` only accepts `upsell` or `thankyou` as a forward target, so a `downsell` immediately after a skipped offer is never selected. `classes/class-cartflows-pro-base-offer-markup.php:647`
- `filter_values()` rewrites `wcf-offer-product` into three possible shapes (numeric array, associative admin payload, or `''`) — consumers of the admin meta filter must handle all three. `classes/class-cartflows-pro-base-offer-meta-data.php:62-81`

## Gotchas

- **The duplicate-submission lock leaks on three early-return paths.** The 60 s transient is deleted on the normal path and on bundle-validation failure, but not on already-purchased, out-of-stock, or negative-price. A customer hitting an out-of-stock offer is locked out of it for 60 seconds with "Offer is already being processed." `classes/class-cartflows-pro-base-offer-markup.php:295,545,447,359,386,408`
- **The back-button double-purchase guard reads a meta value this module never persists.** The only writer calls `update_meta_data()` with **no `$order->save()`**, and runs *after* the product has already been added. The only real duplicate protection is the 60 s transient. `classes/class-cartflows-pro-base-offer-markup.php:306,671-676,512`
- **`product_price()` leaks a global price filter on its early-return path** — `woocommerce_price_trim_zeros` is added before the "product missing" bail and removed only at the end. When the offer product is trashed, trailing zeros are stripped from every price for the rest of the request. `classes/class-cartflows-pro-base-offer-shortcodes.php:150-154,212`
- Shortcodes clobber `global $product` with `null` instead of restoring it, so anything rendered afterwards sees `null` rather than the prior value. `classes/class-cartflows-pro-base-offer-shortcodes.php:361,383`
- **Cross-request static product cache with no key** — a second offer step in the same request (or an admin preview) gets the first step's product, and the populate loop overwrites `$products` each iteration so multi-product offer meta collapses to the last entry. `classes/class-cartflows-pro-base-offer-shortcodes.php:32-39,474-507`
- Dynamic CSS is invalidated only by asset version, never by a settings change — edited offer design settings can render with stale CSS. `classes/class-cartflows-pro-base-offer-markup.php:84-91`
- `body_class` is registered from inside `wp_enqueue_scripts`, working only because the template calls `wp_head()` before `body_class()`. Any template emitting `<body>` earlier loses the instant-layout styling. `classes/class-cartflows-pro-base-offer-markup.php:75`
- **`full_subscription_cancellation()` installs a global filter and never removes it** — for the rest of the request *every* subscription cancellation, not just the offer's, skips pending-cancel. `classes/class-cartflows-pro-offer-subscriptions.php:236-239`
- **Offer acceptance can silently log a guest in** — `create_new_customer()` calls `wp_set_current_user()` and sets an auth cookie mid-request, changing capability checks for everything afterwards. `classes/class-cartflows-pro-offer-subscriptions.php:219-221`
- `Cartflows_Helper` and `Cartflows_Pro_Helper` are used interchangeably for the same instant-layout check **within one method** — if they ever disagree, the admin shows a Design tab with no fields behind it. `classes/class-cartflows-pro-base-offer-meta-data.php:129,144`
- `override_woo_variable_template()` outranks theme template overrides on offer pages, with no filter to opt out. `classes/class-cartflows-pro-base-offer-shortcodes.php:73,626-630`
- Stock is **validated** on acceptance but never decremented — the `@todo` is still open. `classes/class-cartflows-pro-base-offer-markup.php:491`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
