---
module: offer
---

# offer

## Responsibility

The shared base layer for upsell and downsell offer steps: it owns the offer step's frontend assets and localized JS payload, the accept/reject processing pipeline (`offer_accepted()` / `offer_rejected()`), the offer product shortcodes, the admin meta and settings field definitions, the WooCommerce Subscriptions bridge for offered products, and the admin order-screen linking between parent and child offer orders.

Ownership stops at the AJAX boundary and the persistence layer: the actual `wp_ajax_*` handlers and nonce verification live in `modules/upsell` and `modules/downsell`, the gateway charge lives in `wcf_pro()->gateways`, and adding the product to the order lives in `modules/orders`.

## Why it is this way

This is a base class consumed by two subclasses across an AJAX boundary, with a **payment charge in the middle**. That is why order-key validation, the stock and price refusals, and the duplicate-submission lock all sit before the gateway call rather than being distributed.

The contract that matters — required `$extra_data` keys, the exact `template_type` strings, which localize fields a filter may not touch, and which of the two duplicate-purchase mechanisms actually works — is nowhere stated in code, and is contradicted by the unsaved purchase-marker meta.
