<?php
/**
 * AI Initialization.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Order Bump Product
 *
 * @since x.x.x
 */
class Cartflows_Pro_Ai_Init {

	/**
	 * Member Variable
	 *
	 * @var self|null
	 */
	protected static $instance;

	/**
	 *  Initiator
	 * 
	 * @return object instance
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 *  Constructor
	 */
	public function __construct() {
		if ( ! apply_filters( 'cartflows_ai_auth_enabled', true ) ) {
			return;
		}
		add_filter( 'cartflows_content_generation_auth_token', array( $this, 'get_auth_token' ) );
	}

	/**
	 * Get auth token.
	 *
	 * @since x.x.x
	 * @return string
	 */
	public function get_auth_token() {
		// Get license class instance.
		$cartflows_license_instance = cartflows_pro_license_instance();

		// Get license Key.
		$data        = get_option( 'wc_am_client_' . $cartflows_license_instance->product_id . '_api_key', array() );
		$api_key_raw = is_array( $data ) && isset( $data['api_key'] ) ? $data['api_key'] : '';
		$license_key = is_string( $api_key_raw ) ? $api_key_raw : '';

		return $license_key;
	}
}


/**
 *  Kicking this off by calling 'get_instance()' method
 */
Cartflows_Pro_Ai_Init::get_instance();
