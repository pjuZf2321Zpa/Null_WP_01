# Module: gateways

Per-gateway adapters that charge a one-click offer off-session against the credential captured at checkout, and refund those offer transactions.

Read `architecture.md` in this folder before changing this module.

## Rules

**The contract is duck-typed — there is no interface or abstract class.** `Cartflows_Pro_Gateway` is only a helper base, and most gateway classes do not extend it.

- **Every registered gateway class must expose `get_instance()`, `public $key`, `process_offer_payment( $order, $product ): bool`, and `is_api_refund(): bool`.** The refund path calls `is_api_refund()` on the result of `load_gateway()` **with no falsy guard** — a missing method or unsupported method id is a fatal, not a graceful skip. `classes/class-cartflows-pro-refund.php:138-142`
- If `is_api_refund()` is `true`, you must implement `process_offer_refund( $order, $offer_data )`. `class-cartflows-pro-gateway-stripe.php:36,674`
- **`$key` must equal the WooCommerce payment-method id exactly** — `get_wc_gateway()` does an unguarded `$gateways[$this->key]`, and hook names are built from it. `class-cartflows-pro-gateway-stripe.php:295-302,67`
- Load order is fixed: api-base → `class-cartflows-pro-gateway.php` → helpers → concrete gateway. The helper includes happen inside the constructor, triggered only by the bootstrap call at the bottom of that file. `class-cartflows-pro-gateway.php:46,119-126`
- `Cartflows_Pro_Api_Base` subclasses must set `$request_uri` and pass a `stdClass` carrying `->path`, `->method`, `->body`. `class-cartflows-pro-api-base.php:303,338,366`
- **Offer AJAX endpoints are `nopriv`; ownership is proven with `order_key`.** There is no `current_user_can()` anywhere in the module. `class-cartflows-pro-gateway-stripe.php:105`
- The offer-confirmation nonce action is **caller-supplied** — pass the wrong `action` string and the charge silently fails closed. `class-cartflows-pro-gateway-stripe.php:318`

## Gotchas

- **`Cartflows_Pro_Gateway::get_instance()` at the bottom of `class-cartflows-pro-gateway.php:126` looks harmless and is not** — it is what runs `load_files()` and therefore what defines the three helper classes. Delete it and every helper-extending gateway fatals on `extends`.
- **Stock is only reduced for Square.** The stock-reduction hook exists in the two Square files only; the generic path has just a `@todo reduce_stock();` comment. Accepted offers on Stripe, PayPal, Authorize.Net and WooPayments never decrement stock. `class-cartflows-pro-gateway-square.php:79`
- **BACS auto-approves** — `process_offer_payment()` returns `true` unconditionally, with no payment verification. `class-cartflows-pro-gateway-bacs.php:123-126`
- **PayPal caches the billing agreement on the singleton and ignores its `$order` argument**, so two orders in one request means the second gets the first's token. The NVP helper's `$parameters` array likewise accumulates across API calls and is never reset. `class-cartflows-pro-gateway-paypal-standard.php:36,813-816`, `class-cartflows-pro-paypal-gateway-helper.php:36`
- **Mollie iDEAL's `nopriv` handler never calls `key_is_valid()`** before writing offer meta, while its credit-card twin does — any guest can write offer-product meta to an arbitrary order id. `class-cartflows-pro-gateway-mollie-ideal.php:160-184`
- **Documented ordering**: "Make sure that setting fingerprint is performed after setting metadata because metadata will override any values you set before." Reorder and the fingerprint is lost. `class-cartflows-pro-gateway-woocommerce-payments.php:561`
- A `remove_filter` at priority `999` requires an exact priority match; if the target filter's priority ever changes this becomes a silent no-op and the order status is overwritten. `class-cartflows-pro-gateway-paypal-standard.php:195`
- `1 === did_action(...)` **exact-count equality** on two actions — if either fires twice, the post-payment redirect silently stops happening. `class-cartflows-pro-gateway-stripe.php:262`
- Square's refund `idempotency_key` is just the order id, so a **second partial refund on the same order silently returns the first refund** instead of issuing a new one. `class-cartflows-pro-gateway-square.php:453`
- `get_request_user_agent()` returns `''` with unreachable code after it — every outbound request from the base sends an empty User-Agent. `class-cartflows-pro-api-base.php:425-428`
- Authorize.Net's duplicate-profile recovery keys on **regex-extracting an error code from an exception message**; a message-format change silently disables it. `class-cartflows-pro-gateway-authorize-net.php:172-206`
- Nonce naming trap: the element AJAX action is `wcf_cpsw_create_payment_element_intent` while its nonce action is `wcf_cpsw_create_element_payment_intent` — same words, different order. `class-cartflows-pro-gateway-cpsw-stripe-element.php:60,129`
- Zero-price guard differs between siblings (`>=` vs `===`), so negative prices pass the CPSW check. `class-cartflows-pro-gateway-stripe.php:118` vs `class-cartflows-pro-gateway-cpsw-stripe.php:155`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
