---
module: gateways
---

# gateways

## Responsibility

Owns the per-gateway adapters that let CartFlows charge a one-click upsell/downsell offer **off-session** against the payment credential captured during the original checkout, and refund those offer transactions. Each file adapts one WooCommerce payment gateway: force tokenization at checkout, create or confirm the offer charge, persist offer transaction meta, and copy payment meta onto child/subscription orders.

Ownership stops at *which* gateway to load and *when* (the registry), *when* to charge (the offer module), order and status mutation (`modules/orders`), and the third-party gateway plugins themselves.

## Why it is this way

The adapter contract is duck-typed. There is no interface and no abstract class stating that a gateway must expose four specific members, so the refund path fatals rather than skipping when one is missing. That is the single most important thing to know before adding a gateway.

Behaviour also varies per gateway in ways that look like bugs but are each a separate history: stock reduces only for Square, BACS auto-approves without verification, and PayPal memoizes its token on the singleton. Several hard ordering constraints — the `get_instance()` bootstrap, fingerprint-after-metadata, the priority-999 `remove_filter`, the exact-count `did_action` — break silently rather than loudly.
