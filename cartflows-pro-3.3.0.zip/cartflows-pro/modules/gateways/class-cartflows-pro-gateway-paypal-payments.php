<?php
/**
 * Paypal Gateway.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Gateway_Paypal_Payments.
 */
class Cartflows_Pro_Gateway_Paypal_Payments extends Cartflows_Pro_Paypal_Gateway_helper {

	/**
	 * Member Variable
	 *
	 * @var instance
	 */
	private static $instance;

	/**
	 * Key name variable
	 *
	 * @var key
	 */
	public $key = 'ppcp-gateway';

	/**
	 * Refund supported
	 *
	 * @var is_api_refund
	 */
	public $is_api_refund = true;

	/**
	 *  Initiator
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		define( 'CARTFLOWS_PAYPAL_PAYMENTS_API_URL', 'https://api-m.paypal.com' );
		define( 'CARTFLOWS_PAYPAL_PAYMENTS_SANDBOX_API_URL', 'https://api-m.sandbox.paypal.com' );

		add_filter( 'woocommerce_paypal_refund_request', array( $this, 'offer_refund_request_data' ), 10, 4 );

		add_action( 'cartflows_offer_subscription_created', array( $this, 'add_subscription_payment_meta_for_paypal' ), 10, 3 );

		add_action( 'cartflows_offer_child_order_created_' . $this->key, array( $this, 'store_required_meta_keys_for_refund' ), 10, 3 );

		add_action( 'wp_ajax_wcf_create_paypal_payments_order', array( $this, 'create_paypal_order' ) );
		add_action( 'wp_ajax_nopriv_wcf_create_paypal_payments_order', array( $this, 'create_paypal_order' ) );

		add_action( 'wp_ajax_wcf_capture_paypal_order', array( $this, 'capture_paypal_order' ) );
		add_action( 'wp_ajax_nopriv_wcf_capture_paypal_order', array( $this, 'capture_paypal_order' ) );
	}

	/**
	 * Retrieves token for payment.
	 *
	 * @param object $order order details.
	 *
	 * @return string
	 */
	public function get_token( $order ) {

		$token = '';
		// Check for the expired token.
		$expired = true;

		$bearer = get_option( '_transient_ppcp-paypal-bearerppcp-bearer' );

		// Check if the bearer token exists and is stored as a valid JSON string.
		if ( ! empty( $bearer ) && is_string( $bearer ) ) {
			$bearer_data = json_decode( $bearer );
			
			// Validate that the decoded data is an object and contains the expected properties.
			// This ensures PHPStan type safety and guards against malformed or unexpected data.
			if ( $bearer_data instanceof stdClass &&
				isset( $bearer_data->access_token, $bearer_data->created, $bearer_data->expires_in ) &&
				is_string( $bearer_data->access_token ) &&
				is_int( $bearer_data->created ) &&
				is_int( $bearer_data->expires_in )
			) {
				// Calculate the absolute expiration timestamp.
				$expiry_time = $bearer_data->created + $bearer_data->expires_in;
				if ( time() < $expiry_time ) {
					// If the current time is still before the expiry time,
					// consider the token valid and mark it as not expired.
					$token   = $bearer_data->access_token;
					$expired = false;
				}
			}
		}

		// Generate new token if token does not exists.
		if ( empty( $token ) || $expired ) {
			$payment_env = $order->get_meta( '_ppcp_paypal_payment_mode' );

			// Retrieve plugin settings and shared PayPal configuration data from the database.
			$ppcp_settings    = get_option( 'woocommerce-ppcp-settings', array() );
			$ppcp_data_common = get_option( 'woocommerce-ppcp-data-common', array() );
	
			// Ensure we're working with arrays.
			$ppcp_settings    = is_array( $ppcp_settings ) ? $ppcp_settings : array();
			$ppcp_data_common = is_array( $ppcp_data_common ) ? $ppcp_data_common : array();

			// Get credentials with fallback.
			$client_id    = ! empty( $ppcp_settings['client_id'] ) ? $ppcp_settings['client_id'] : ( isset( $ppcp_data_common['client_id'] ) ? $ppcp_data_common['client_id'] : '' );
			$secret_key   = ! empty( $ppcp_settings['client_secret'] ) ? $ppcp_settings['client_secret'] : ( isset( $ppcp_data_common['client_secret'] ) ? $ppcp_data_common['client_secret'] : '' );
			$api_url_base = 'sandbox' === $payment_env ? CARTFLOWS_PAYPAL_PAYMENTS_SANDBOX_API_URL : CARTFLOWS_PAYPAL_PAYMENTS_API_URL;
			$url          = $api_url_base . '/v1/oauth2/token?grant_type=client_credentials';
			$args         = array(
				'method'  => 'POST',
				'headers' => array(
					// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
					'Authorization' => 'Basic ' . base64_encode( $client_id . ':' . $secret_key ),
				),
			);

			$response = wp_safe_remote_get( $url, $args );

			if ( ! is_wp_error( $response ) ) {
				$res_body = json_decode( $response['body'] );
				$token    = $res_body->access_token;
			}
		}

		return $token;
	}

	/**
	 * Checks the paypal payment mode.
	 *
	 * @param object $order WC Order.
	 *
	 * @return string Payment mode.
	 */
	public function get_ppcp_meta( $order ) {

		$paypal_settings = get_option( 'woocommerce-ppcp-settings' );

		$gateway_environment = $order->get_meta( '_ppcp_paypal_payment_mode' ) ? $order->get_meta( '_ppcp_paypal_payment_mode' ) : '';

		return array(
			'environment'    => $order->get_meta( '_ppcp_paypal_payment_mode' ),
			'api_base_url'   => 'sandbox' === $gateway_environment ? CARTFLOWS_PAYPAL_PAYMENTS_SANDBOX_API_URL : CARTFLOWS_PAYPAL_PAYMENTS_API_URL,
			'intent'         => $order->get_meta( '_ppcp_paypal_intent' ),
			'merchant_email' => $paypal_settings['merchant_email'],
			'merchant_id'    => $paypal_settings['merchant_id'],
			'invoice_prefix' => $paypal_settings['prefix'],
		);
	}

	/**
	 * Charge the offer by capturing the PayPal order created for this step.
	 *
	 * Runs inside offer_accepted(), so the capture only happens once the session,
	 * duplicate-submission lock, already-purchased, stock, price and bundle checks
	 * have all passed. Capturing from a separate earlier request bypassed every one
	 * of them and left the customer charged with no order whenever one of them failed.
	 *
	 * @param WC_Order $order order data.
	 * @param array    $product product data.
	 * @return bool
	 */
	public function process_offer_payment( $order, $product ) {

		$step_id = isset( $product['step_id'] ) ? intval( $product['step_id'] ) : 0;

		if ( ! $step_id ) {
			wcf()->logger->log( 'PayPal Payments : Offer step ID missing, cannot capture. Order: ' . $order->get_id() );
			return false;
		}

		// A capture already recorded for this exact step is reused so a retry never charges
		// twice. The key carries the step ID because a value left behind by an earlier offer
		// in the same funnel would otherwise be read as payment for this one.
		$txn_id = $order->get_meta( $this->get_offer_txn_meta_key( $order, $step_id ) );

		if ( empty( $txn_id ) ) {
			$txn_id = $this->capture_offer_payment( $order, $step_id );
		}

		if ( empty( $txn_id ) ) {
			wcf()->logger->log( 'PayPal Payments : Offer payment not captured. Order: ' . $order->get_id() . ' Step: ' . $step_id );
			return false;
		}

		$this->store_offer_transaction( $order, array( 'id' => $txn_id ), $product );

		return true;
	}

	/**
	 * Meta key holding the captured offer transaction ID for one offer step.
	 *
	 * @param WC_Order $order order object.
	 * @param int      $step_id offer step ID.
	 * @return string
	 */
	public function get_offer_txn_meta_key( $order, $step_id ) {

		return 'cartflows_offer_paypal_txn_id_' . $order->get_id() . '_' . $step_id;
	}

	/**
	 * Capture the PayPal order created for this offer step.
	 *
	 * @param WC_Order $order order object.
	 * @param int      $step_id offer step ID.
	 * @return string captured transaction ID, empty string when the capture did not complete.
	 */
	public function capture_offer_payment( $order, $step_id ) {

		$order_id        = $order->get_id();
		$paypal_order_id = $order->get_meta( 'cartflows_paypal_order_id_' . $order_id );

		if ( empty( $paypal_order_id ) || ! is_string( $paypal_order_id ) ) {
			wcf()->logger->log( "No PayPal order to capture for the offer. Order: {$order_id}" );
			return '';
		}

		$api_base_url = 'sandbox' === $order->get_meta( '_ppcp_paypal_payment_mode' ) ? CARTFLOWS_PAYPAL_PAYMENTS_SANDBOX_API_URL : CARTFLOWS_PAYPAL_PAYMENTS_API_URL;

		$capture_args = array(
			'method'  => 'POST',
			'headers' => array(
				'Authorization'                 => 'Bearer ' . $this->get_token( $order ),
				'Content-Type'                  => 'application/json',
				'Prefer'                        => 'return=representation',
				'PayPal-Partner-Attribution-Id' => 'Wcf_Woo_PPCP',
			),
		);

		$captured_resp = wp_remote_get( $api_base_url . '/v2/checkout/orders/' . $paypal_order_id . '/capture', $capture_args );

		if ( is_wp_error( $captured_resp ) ) {

			wcf()->logger->log(
				"Order Created but not captured. For WC-Order: {$order_id}, Error: " .
				wp_json_encode( $captured_resp->get_error_message() )
			);

			return '';
		}

		$resp_body = json_decode( wp_remote_retrieve_body( $captured_resp ) );

		if ( is_object( $resp_body ) && isset( $resp_body->status ) && 'COMPLETED' === $resp_body->status ) {

			$txn_id = $this->get_capture_id_from_response( $resp_body );

		} else {

			// The money may already be at PayPal: a capture taken by a build that captured
			// outside this pipeline, or a retry. PayPal itself is asked for the capture ID
			// rather than trusting stored meta, so the offer completes instead of stranding
			// a charge that has no order.
			$txn_id = $this->get_captured_txn_id( $order, $paypal_order_id, $api_base_url, $resp_body );
		}

		if ( empty( $txn_id ) ) {

			wcf()->logger->log(
				"PayPal offer order is not captured. Order: {$order_id}, Response: " .
				wp_json_encode( $resp_body )
			);

			return '';
		}

		// Recorded before the order is built so a failure further down the offer pipeline
		// leaves a retry able to find the capture instead of charging the customer again.
		$order->update_meta_data( $this->get_offer_txn_meta_key( $order, $step_id ), $txn_id );
		$order->save();

		wcf()->logger->log( "Order Created and captured. Order: {$order_id}" );

		return $txn_id;
	}

	/**
	 * Read the capture ID out of a PayPal orders API response.
	 *
	 * @param mixed $resp_body decoded PayPal response.
	 * @return string capture ID, empty string when the response carries none.
	 */
	public function get_capture_id_from_response( $resp_body ) {

		if ( ! is_object( $resp_body ) || ! isset( $resp_body->purchase_units[0]->payments->captures[0]->id ) ) {
			return '';
		}

		return (string) $resp_body->purchase_units[0]->payments->captures[0]->id;
	}

	/**
	 * Ask PayPal for the capture already taken against an order it refused to capture again.
	 *
	 * @param WC_Order $order order object.
	 * @param string   $paypal_order_id PayPal order ID.
	 * @param string   $api_base_url PayPal API base URL.
	 * @param mixed    $resp_body decoded response of the refused capture.
	 * @return string capture ID, empty string when nothing was captured.
	 */
	public function get_captured_txn_id( $order, $paypal_order_id, $api_base_url, $resp_body ) {

		if ( ! $this->is_already_captured_response( $resp_body ) ) {
			return '';
		}

		$response = wp_remote_get(
			$api_base_url . '/v2/checkout/orders/' . $paypal_order_id,
			array(
				'method'  => 'GET',
				'headers' => array(
					'Authorization'                 => 'Bearer ' . $this->get_token( $order ),
					'Content-Type'                  => 'application/json',
					'PayPal-Partner-Attribution-Id' => 'Wcf_Woo_PPCP',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			wcf()->logger->log( 'Could not read the already captured PayPal order. Order: ' . $order->get_id() . ', Error: ' . wp_json_encode( $response->get_error_message() ) );
			return '';
		}

		$body = json_decode( wp_remote_retrieve_body( $response ) );

		if ( ! is_object( $body ) || ! isset( $body->status ) || 'COMPLETED' !== $body->status ) {
			return '';
		}

		return $this->get_capture_id_from_response( $body );
	}

	/**
	 * Check whether PayPal refused a capture because the order was captured already.
	 *
	 * @param mixed $resp_body decoded PayPal response.
	 * @return bool
	 */
	public function is_already_captured_response( $resp_body ) {

		if ( ! is_object( $resp_body ) || ! isset( $resp_body->details ) || ! is_array( $resp_body->details ) ) {
			return false;
		}

		foreach ( $resp_body->details as $detail ) {
			if ( isset( $detail->issue ) && 'ORDER_ALREADY_CAPTURED' === $detail->issue ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Capture PayPal Order for PayPal Payments Gateway.
	 *
	 * @return json
	 */
	public function create_paypal_order() {

		$nonce = isset( $_POST['_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'wcf_create_paypal_order' ) ) {
			wp_send_json_error( array( 'message' => __( 'Nonce verification failed', 'cartflows-pro' ) ) );
		}

		$data        = array();
		$step_id     = isset( $_POST['step_id'] ) ? intval( $_POST['step_id'] ) : 0;
		$flow_id     = isset( $_POST['flow_id'] ) ? intval( $_POST['flow_id'] ) : 0;
		$order_id    = isset( $_POST['order_id'] ) ? sanitize_text_field( wp_unslash( $_POST['order_id'] ) ) : 0;
		$order_key   = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';
		$session_key = isset( $_COOKIE[ CARTFLOWS_SESSION_COOKIE . $flow_id ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ CARTFLOWS_SESSION_COOKIE . $flow_id ] ) ) : ''; //phpcs:ignore WordPressVIPMinimum.Variables.RestrictedVariables.cache_constraints___COOKIE

		$order = wc_get_order( $order_id );

		// Verify order ownership via order_key.
		if ( ! $order instanceof WC_Order || ! $order->key_is_valid( $order_key ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid order', 'cartflows-pro' ) ) );
			return;
		}

		// Refuse before the customer is sent to PayPal at all. Approving a payment for an
		// offer that can no longer be completed is what leaves a capture with no order.
		if ( ! $this->has_valid_offer_session( $step_id ) ) {
			wp_send_json(
				array(
					'result'  => 'fail',
					'message' => __( 'Session expired.', 'cartflows-pro' ),
				)
			);
		}

		$variation_id = '';
		$input_qty    = '';
		$invoice_id   = '';

		$args = array(
			'step_id'        => $step_id,
			'flow_id'        => $flow_id,
			'order_id'       => $order_id,
			'order_key'      => $order_key,
			'order_currency' => wcf_pro()->wc_common->get_currency( $order ),
			'ppcp_data'      => $this->get_ppcp_meta( $order ),
		);

		$token = $this->get_token( $order );

		if ( isset( $_POST['variation_id'] ) && ! empty( $_POST['variation_id'] ) ) {
			$variation_id = intval( $_POST['variation_id'] );
		}
		if ( isset( $_POST['input_qty'] ) && ! empty( $_POST['input_qty'] ) ) {
			$input_qty = intval( $_POST['input_qty'] );
		}

		$offer_product = wcf_pro()->utils->get_offer_data( $step_id, $variation_id, $input_qty, $order_id );

		if ( isset( $offer_product['price'] ) && ( floatval( 0 ) === floatval( $offer_product['price'] )
				|| '' === trim( $offer_product['price'] ) ) ) {

			wcf()->logger->log(
				"Cannot create PayPal Payments Order. The selected product's price is zero. Order: {$order_id}"
			);

			wp_send_json(
				array(
					'result'  => 'fail',
					'message' => __( 'Cannot make the Payment for Zero value product', 'cartflows-pro' ),
				)
			);
		} else {

			$data = array(
				'intent'              => $args['ppcp_data']['intent'],
				'purchase_units'      => $this->get_purchase_units( $order, $offer_product, $args ),
				'application_context' => array(
					'user_action'  => 'CONTINUE',
					'landing_page' => 'LOGIN',
					'brand_name'   => html_entity_decode( get_bloginfo( 'name' ), ENT_NOQUOTES, 'UTF-8' ),
					'return_url'   => $this->get_return_or_cancel_url( $args, $session_key ),
					'cancel_url'   => $this->get_return_or_cancel_url( $args, $session_key, true ),
				),
				'payment_method'      => array(
					'payee_preferred' => 'UNRESTRICTED',
					'payer_selected'  => 'PAYPAL',
				),
				'payment_instruction' => array(
					'disbursement_mode' => 'INSTANT',
					'platform_fees'     => array(
						array(
							'amount' => array(
								'currency_code' => $order->get_currency(),
								'value'         => wcf_float_to_string( $offer_product['unit_price_tax'] ),
							),
						),
					),
				),

			);

			$arguments = array(
				'method'  => 'POST',
				'headers' => array(
					'Content-Type'                  => 'application/json',
					'Authorization'                 => 'Bearer ' . $token,
					'PayPal-Partner-Attribution-Id' => 'Wcf_Woo_PPCP',
				),
				'body'    => wp_json_encode( $data ),
			);

			// Refer https://developer.paypal.com/docs/api/orders/v2/ documentation to generate create order endpoint.
			$url = $args['ppcp_data']['api_base_url'] . '/v2/checkout/orders';

			$ppcp_resp = wp_remote_get( $url, $arguments );

			if ( is_wp_error( $ppcp_resp ) ) {

				$json_response = array(
					'status'          => false,
					'message'         => $ppcp_resp->get_error_message(),
					'paypal_order_id' => '',
					'redirect_url'    => '',
					'response'        => $ppcp_resp,
				);

				wcf()->logger->log(
					"PayPal order is not created. Order: {$order_id}, Error: " .
					wp_json_encode( $ppcp_resp->get_error_message() )
				);

				return wp_send_json( $json_response );

			} else {

				$retrived_body = wp_remote_retrieve_body( $ppcp_resp );

				$response = json_decode( $retrived_body );

				$json_response = array(
					'result'          => false,
					'message'         => __( 'PayPal order is not created', 'cartflows-pro' ),
					'paypal_order_id' => '',
					'redirect_url'    => '',
					'response'        => $response,
				);

				if ( isset( $response->status ) && 'CREATED' === $response->status ) {

					$approve_link = $response->links[1]->href;

					// Update Order Creared ID (PayPal Order ID) in the order.
					$order->update_meta_data( 'cartflows_paypal_order_id_' . $order->get_id(), $response->id );
					$order->save();

					wcf()->logger->log(
						"Order Created for WC-Order: {$order_id}"
					);

					$json_response = array(
						'status'          => 'success',
						'message'         => __( 'Order created successfully', 'cartflows-pro' ),
						'paypal_order_id' => $response->id,
						'redirect'        => $approve_link,
						'response'        => $response,
					);

				}
			}

			return wp_send_json( $json_response );
		}
	}

	/**
	 * Validate an offer before the browser asks for the PayPal payment to be taken.
	 *
	 * Deprecated: kept so an offer page rendered before an update still resolves. The
	 * capture itself now runs inside process_offer_payment(), behind the offer checks,
	 * and this endpoint no longer moves money.
	 *
	 * @return void
	 */
	public function capture_paypal_order() {

		$nonce = isset( $_POST['_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'wcf_capture_paypal_order' ) ) {
			wp_send_json_error( array( 'message' => __( 'Nonce verification failed', 'cartflows-pro' ) ) );
		}

		$step_id   = isset( $_POST['step_id'] ) ? intval( $_POST['step_id'] ) : 0;
		$order_id  = isset( $_POST['order_id'] ) ? sanitize_text_field( wp_unslash( $_POST['order_id'] ) ) : 0;
		$order_key = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';

		$order = wc_get_order( $order_id );

		// Verify order ownership via order_key.
		if ( ! $order instanceof WC_Order || ! $order->key_is_valid( $order_key ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid order', 'cartflows-pro' ) ) );
			return;
		}

		if ( ! $this->has_valid_offer_session( $step_id ) ) {
			wp_send_json(
				array(
					'status'  => 'failed',
					'message' => __( 'Session expired.', 'cartflows-pro' ),
				)
			);
		}

		wp_send_json(
			array(
				'status'  => 'success',
				'message' => __( 'Offer is ready to be processed', 'cartflows-pro' ),
			)
		);
	}

	/**
	 * Check that the CartFlows session behind an offer step is still valid.
	 *
	 * @param int $step_id offer step ID.
	 * @return bool
	 */
	public function has_valid_offer_session( $step_id ) {

		if ( ! $step_id ) {
			return false;
		}

		$flow_id = wcf()->utils->get_flow_id_from_step_id( $step_id );

		if ( ! $flow_id ) {
			return false;
		}

		return wcf_pro()->session->has_valid_session( $flow_id );
	}

	/**
	 * Create purchase unite for create order.
	 *
	 * @param object $order WC Order.
	 * @param array  $offer_product upsell/downsell product.
	 * @param object $args Posted and payment gateway setting data.
	 *
	 * @return array $purchase_unit.
	 */
	public function get_purchase_units( $order, $offer_product, $args ) {

		$invoice_id = $args['ppcp_data']['invoice_prefix'] . '-wcf-' . $args['order_id'] . '_' . $args['step_id'];

		$purchase_unit = array(
			'reference_id' => 'default',
			'amount'       => array(
				'currency_code' => $args['order_currency'],
				'value'         => wcf_float_to_string( $offer_product['total'] ),
				'breakdown'     => $this->get_item_breakdown( $order, $offer_product ),
			),
			/* translators: %s order id. */
			'description'  => sprintf( __( 'One Time Offer - %s', 'cartflows-pro' ), $order->get_id() ),
			'items'        => array(
				$this->add_offer_item_data( $order, $offer_product ),
			),
			'payee'        => array(
				'email_address' => $args['ppcp_data']['merchant_email'],
				'merchant_id'   => $args['ppcp_data']['merchant_id'],
			),
			'shipping'     => array(
				'name' => array(
					'full_name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
				),
			),
			'custom_id'    => $invoice_id,
			'invoice_id'   => $invoice_id,
		);

		return array( $purchase_unit );
	}

	/**
	 * Create breakdown for item amount.
	 *
	 * @param object $order WC Order.
	 * @param array  $offer_product upsell/downsell product.
	 *
	 * @return array $breakdown item amount breakdown.
	 */
	public function get_item_breakdown( $order, $offer_product ) {

		$breakdown = array();

		$breakdown['item_total'] = array(
			'currency_code' => wcf_pro()->wc_common->get_currency( $order ),
			'value'         => wcf_float_to_string( $offer_product['total'] ),
		);

		if ( ! empty( $offer_product['amount_diff'] ) ) {
			$breakdown['discount'] = array(
				'currency_code' => wcf_pro()->wc_common->get_currency( $order ),
				'value'         => wcf_float_to_string( $offer_product['amount_diff'] ),
			);
		}

		if ( ! empty( $offer_product['shipping_fee'] ) ) {
			$breakdown['shipping'] = array(
				'currency_code' => wcf_pro()->wc_common->get_currency( $order ),
				'value'         => wcf_float_to_string( $offer_product['shipping_fee_tax'] ),
			);
		}

		return $breakdown;
	}

	/**
	 * Add product's item data.
	 *
	 * @param object $order WC Order.
	 * @param array  $offer_product upsell/downsell product.
	 *
	 * @return array $offer_items item data.
	 */
	public function add_offer_item_data( $order, $offer_product ) {

		$product_desc = wp_strip_all_tags( $offer_product['desc'] );

		// Truncate the description to match the max allowed length by PayPal that is of 127 chars.
		$product_desc = ( strlen( $product_desc ) > 125 ) ? substr( $product_desc, 0, 125 ) . '..' : $product_desc;

		$offer_items = array(
			'name'        => $offer_product['name'],
			'unit_amount' => array(
				'currency_code' => wcf_pro()->wc_common->get_currency( $order ),
				'value'         => wcf_float_to_string( $offer_product['unit_price'] ),
			),
			'quantity'    => $offer_product['qty'],
			'description' => $product_desc,
		);

		return $offer_items;
	}

	/**
	 * Get return url.
	 *
	 * @param array  $args required arguments.
	 * @param string $session_key session key.
	 * @param bool   $cancel key for action.
	 *
	 * @return string
	 */
	public function get_return_or_cancel_url( $args, $session_key, $cancel = false ) {

		$url = get_permalink( $args['step_id'] );

		$args = array(
			'wcf-order' => $args['order_id'],
			'wcf-key'   => $args['order_key'],
			'wcf-sk'    => $session_key,
		);

		if ( $cancel ) {
			$args['wcf-ppcp-cancel'] = true;
		} else {
			$args['wcf-ppcp-return'] = true;
		}

		return add_query_arg( $args, $url );
	}

	/**
	 * Is gateway support offer refund
	 *
	 * @return bool
	 */
	public function is_api_refund() {

		return $this->is_api_refund;
	}

	/**
	 * Store Offer Trxn Charge.
	 *
	 * @param WC_Order $order    The order that is being paid for.
	 * @param Object   $response The response that is send from the payment gateway.
	 * @param array    $product  Product data.
	 */
	public function store_offer_transaction( $order, $response, $product ) {

		wcf()->logger->log( 'PayPal Payments : Store Offer Transaction :: Transaction ID = ' . $response['id'] . ' Captured' );

		$order->update_meta_data( 'cartflows_offer_txn_resp_' . $product['step_id'], $response['id'] );
		$order->save();
	}

	/**
	 * Modify argument for offer refund
	 *
	 * @param array  $request request.
	 * @param object $order the order object.
	 * @param string $amount refund amount.
	 * @param string $reason refund reason.
	 *
	 * @return object
	 */
	public function offer_refund_request_data( $request, $order, $amount, $reason ) {
		//phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['cartflows_refund'] ) ) {

			$payment_method = $order->get_payment_method();

			if ( $this->key === $payment_method ) {

				if ( isset( $_POST['transaction_id'] ) && ! empty( $_POST['transaction_id'] ) ) {
					$request['TRANSACTIONID'] = sanitize_text_field( wp_unslash( $_POST['transaction_id'] ) );
				}
			}
		}

		return $request;
		//phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Process offer refund.
	 *
	 * @param WC_Order $order order data.
	 * @param array    $offer_data offer data.
	 *
	 * @return bool
	 */
	public function process_offer_refund( $order, $offer_data ) {

		$order_id       = $offer_data['order_id'];
		$transaction_id = $offer_data['transaction_id'];
		$refund_amount  = $offer_data['refund_amount'];
		$refund_reason  = $offer_data['refund_reason'];

		$response = false;

		$gateway = $this->get_wc_gateway();

		if ( $this->is_api_refund ) {
			$result = $gateway->process_refund( $order->get_id(), $refund_amount, $refund_reason );

			if ( is_wp_error( $result ) ) {
				wcf()->logger->log( "Paypal offer refund failed. Order: {$order_id}, Error: " . wcf_print_r( $result->get_error_message(), true ) );
			} elseif ( $result ) {
				$response = $result;
			}
		}

		return $response;
	}

	/**
	 * Get WooCommerce payment geteways.
	 *
	 * @return array
	 */
	public function get_wc_gateway() {

		global $woocommerce;

		$gateways = $woocommerce->payment_gateways->payment_gateways();

		return $gateways[ $this->key ];
	}

	/**
	 * Setup the Payment data for Paypal Automatic Subscription.
	 *
	 * @param WC_Subscription $subscription An instance of a subscription object.
	 * @param object          $order Object of order.
	 * @param array           $offer_product array of offer product.
	 */
	public function add_subscription_payment_meta_for_paypal( $subscription, $order, $offer_product ) {
		if ( 'ppcp-gateway' === $order->get_payment_method() ) {

			$subscription->update_meta_data( '_ppcp_paypal_order_id', $order->get_meta( '_ppcp_paypal_order_id', true ) );
			$subscription->update_meta_data( 'payment_token_id', $order->get_meta( 'payment_token_id', true ) );
			$subscription->save();
		}
	}

	/**
	 * Save required keys in child order for refund purpose.
	 *
	 * @param object $parent_order parent order object.
	 * @param object $child_order child order object.
	 * @param string $transaction_id child order trandaction id.
	 */
	public function store_required_meta_keys_for_refund( $parent_order, $child_order, $transaction_id ) {
		if ( ! empty( $transaction_id ) ) {

			$paypal_order_id = $parent_order->get_meta( 'cartflows_paypal_order_id_' . $parent_order->get_id() );

			$child_order->update_meta_data( '_ppcp_paypal_order_id', $paypal_order_id );
			$child_order->update_meta_data( '_ppcp_paypal_intent', 'CAPTURE' );
			$child_order->save();
		}
	}
}

/**
 *  Prepare if class 'Cartflows_Pro_Gateway_Paypal_Payments' exist.
 *  Kicking this off by calling 'get_instance()' method
 */
Cartflows_Pro_Gateway_Paypal_Payments::get_instance();
