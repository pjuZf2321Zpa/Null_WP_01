<?php
/**
 * Frequently Bought Together — Pro module loader.
 *
 * Mirrors the free plugin's Cartflows_Fbt shape: defines a module-scoped DIR
 * constant, requires each Pro-side class from a single entry point, and boots
 * via get_instance(). No data helpers here — those live in the free plugin's
 * Cartflows_Fbt class; Pro only decorates the UI via filters/actions.
 *
 * @package cartflows
 * @since   3.1.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Bail out if the free plugin's FBT data class isn't loaded — Pro has nothing to decorate.
if ( ! class_exists( 'Cartflows_Fbt' ) ) {
	return;
}

/**
 * FBT Pro module bootstrap.
 *
 * @since 3.1.4
 */
class Cartflows_Pro_Fbt {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — defines constants + loads the module's Pro-side classes.
	 */
	public function __construct() {
		$this->define_constants();
		$this->load_files();
	}

	/**
	 * Defines the module's path constant.
	 *
	 * @return void
	 */
	public function define_constants() {
		define( 'CARTFLOWS_PRO_FBT_DIR', CARTFLOWS_PRO_DIR . 'modules/frequently-bought-together/' );
		define( 'CARTFLOWS_PRO_FBT_URL', CARTFLOWS_PRO_URL . 'modules/frequently-bought-together/' );
	}

	/**
	 * Requires the sub-classes that make up the module.
	 *
	 * @return void
	 */
	public function load_files() {

		// Extension bootstrap — filters/actions that decorate the free plugin's panel + widget.
		require_once CARTFLOWS_PRO_FBT_DIR . 'classes/class-cartflows-pro-fbt-extend.php';

		// Linked Products drawer — "Auto Suggest" buttons + drawer scaffold on the Linked Products tab.
		require_once CARTFLOWS_PRO_FBT_DIR . 'classes/class-cartflows-pro-fbt-linked-ai.php';

		// Guided setup — spotlight tour over the FBT panel, once per user.
		require_once CARTFLOWS_PRO_FBT_DIR . 'classes/class-cartflows-pro-fbt-tour.php';
	}
}

Cartflows_Pro_Fbt::get_instance();
