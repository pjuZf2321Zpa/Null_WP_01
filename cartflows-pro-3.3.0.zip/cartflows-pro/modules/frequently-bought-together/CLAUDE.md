# Module: frequently-bought-together

Pro-side decoration of the free plugin's FBT feature: extra source values, the real Auto Suggest hero in place of the upgrade wall, Linked Products buttons + drawer shell, and a once-per-user setup tour.

Read `architecture.md` in this folder before changing this module.

## Rules

- The free plugin's `Cartflows_Fbt` class must already be loaded when this file is required, or the whole module silently no-ops. `class-cartflows-pro-fbt.php:19-21`
- Boot only through `get_instance()` — the constructor is public and `define_constants()` uses bare `define()`. `class-cartflows-pro-fbt.php:52-65`
- `define_constants()` must run before `load_files()`, which builds every `require_once` path from the constant. `class-cartflows-pro-fbt.php:53-54,75-81`
- All three class files self-instantiate at the bottom — requiring a file registers hooks as a side effect. `class-cartflows-pro-fbt-extend.php:110`
- `cartflows_fbt_ai_pane_html` must be applied with **2 args** (default HTML, context array). `class-cartflows-pro-fbt-extend.php:57`
- **The free plugin must keep registering its admin script under the handle `wcf-fbt-admin`** — the tour script declares it as a hard dependency. `class-cartflows-pro-fbt-tour.php:102`
- The `progress` i18n string must keep both `{{current}}` and `{{total}}` placeholders. `class-cartflows-pro-fbt-tour.php:120-121`
- The free plugin must fire `cartflows_fbt_admin_assets_enqueued` only inside its own product-screen check — the Pro callback performs **no screen guard of its own**. `class-cartflows-pro-fbt-tour.php:66,74-82`
- `driver.js` / `driver.css` are vendored verbatim and marked "do not edit". `assets/js/driver.js:2`

## Gotchas

- **`GATE_STEP = 1` is a hardcoded index coupled to PHP step order** — it must line up with the "Turn the widget on" step, the second entry of `get_steps()`. Reordering or inserting a PHP step silently moves the Next-button lock onto the wrong step. `assets/js/fbt-tour.js:27`, `class-cartflows-pro-fbt-tour.php:153-160`
- Step selectors are **duplicated across the PHP/JS boundary**, and all of them are free-plugin or WooCommerce DOM — a markup rename in either place breaks the tour with no error. `class-cartflows-pro-fbt-tour.php:154`, `assets/js/fbt-tour.js:11-18`
- **Free's licence check is knowingly wrong and Pro compensates**: "Free cannot render the licence wall itself — its check reads the raw status string, which is truthy even when deactivated." Remove this filter and a deactivated licence gets the working Auto Suggest hero. `class-cartflows-pro-fbt-extend.php:80-82`
- **The metabox is force-expanded by class manipulation, deliberately not by clicking** — clicking `.handlediv` would POST `closed-postboxes` and overwrite the user's saved preference. `assets/js/fbt-tour.js:115-117`
- **`scrollIntoView()` is banned here** — `.panel-wrap` is `overflow:hidden` with a huge `scrollHeight`, so scrolling it blanks the panel; the code scrolls `window` manually instead. `assets/js/fbt-tour.js:159-177`
- A persistent scroll listener pins the panel for the tour's lifetime, attached in `drive()` and released in `teardown()` — that ordering is called out explicitly. `assets/js/fbt-tour.js:203-224,470,430`
- Hidden elements must still resolve — returning `null` for a hidden target makes driver mislabel the step "Done". `assets/js/fbt-tour.js:325-327`
- **driver hooks must be on `popover`, not the step** — "driver ignores step-level ones"; moving them breaks all navigation silently. `assets/js/fbt-tour.js:337`
- A `setTimeout` redraw after `drive()` exists because the first draw lands while the container is still settling and `refresh()` keeps the stale geometry. Removing it leaves the spotlight cut-out misaligned. `assets/js/fbt-tour.js:527-533`
- Both `onDestroyStarted` and `onDestroyed` call `teardown()`, which is idempotent **only** because a flag is cleared before the AJAX write — dropping that reset fires duplicate writes. `assets/js/fbt-tour.js:509-522,437-440`
- The drawer scaffold is deliberately rendered in `admin_footer`, not the WC tab panel, so it can use `position: fixed` and not inherit `display:none`. `class-cartflows-pro-fbt-linked-ai.php:92-95`
- Buttons are rendered below WC's fields and **repositioned by JS that lives in the free plugin** — the server-side DOM position is not the final one. `class-cartflows-pro-fbt-linked-ai.php:58-61`
- Two action classes each appear twice (empty state and footer), so any handler must bind to both instances. `class-cartflows-pro-fbt-linked-ai.php:132-141`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `npm run lint-js && composer lint && composer phpstan`
