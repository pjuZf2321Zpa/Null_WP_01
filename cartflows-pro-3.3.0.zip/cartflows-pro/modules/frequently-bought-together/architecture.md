---
module: frequently-bought-together
---

# frequently-bought-together

## Responsibility

Pro-side decoration of the free plugin's Frequently Bought Together feature: it appends Pro source values, swaps the free upgrade-wall pane for the real Auto Suggest hero, adds "Auto Suggest" buttons and an empty drawer shell on WooCommerce's Linked Products tab, and runs a once-per-user driver.js setup tour over the FBT panel.

Ownership stops at markup, asset loading, and a single `tour_seen` user-meta flag — all FBT data, settings persistence, and the AI AJAX endpoints live in the free plugin and in WooCommerce's own linked-products save flow.

## Why it is this way

This is a decorator whose every contract points outward: a free-plugin class that must pre-exist, two free-plugin filters and one free-plugin action, a script handle owned by free, and a set of WooCommerce/free DOM selectors split across PHP and JS.

The licence-wall override exists because free's own check reads a raw status string that stays truthy after deactivation — Pro is papering over a documented defect in the other plugin, which is why removing that filter has a security-shaped consequence rather than a cosmetic one.
