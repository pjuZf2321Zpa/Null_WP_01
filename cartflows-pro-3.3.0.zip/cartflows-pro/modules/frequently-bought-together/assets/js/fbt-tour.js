/* global wcf_fbt_tour */
/**
 * Frequently Bought Together — guided setup launcher.
 *
 * Drives a driver.js spotlight tour over the FBT product panel. Steps and copy
 * come from PHP via wcf_fbt_tour; this file only sequences them.
 */
( function ( $ ) {
	'use strict';

	const TAB = 'li.cartflows_fbt_tab';
	const METABOX = '#woocommerce-product-data';
	const TOGGLE = '#_cartflows_fbt_enabled';
	const TOGGLE_LABEL = '.wcf-fbt-toggle-label';
	const PANEL_WRAP = '.panel-wrap.product_data';
	const MANUAL_TAB = '.wcf-fbt-sub-tab[data-mode="manual"]';
	const NEXT_BTN = '.driver-popover-next-btn';
	const DISABLED = 'driver-popover-btn-disabled';

	const POLL = 100;
	const WAIT_TIMEOUT = 2000;
	const STABLE_TIMEOUT = 1500;
	const SETTLE_DELAY = 400;
	const REFRESH_DELAY = 350;

	// "Turn the widget on" — the tour holds here until the user flips it themselves.
	const GATE_STEP = 1;

	let tour = null;
	let autoRan = false;
	let active = false;
	let navigating = false;
	let writeSeenOnEnd = true;
	let gateActive = false;
	let atLastStep = false;
	let $previousTab = null;

	/**
	 * Resolves once test() passes, or rejects when the timeout elapses.
	 *
	 * @param {Function} test    Predicate, re-run every POLL ms.
	 * @param {number}   timeout Milliseconds to keep trying.
	 * @return {Promise} Settles when the predicate passes or time runs out.
	 */
	function waitFor( test, timeout ) {
		return new Promise( function ( resolve, reject ) {
			let waited = 0;

			const tick = function () {
				if ( test() ) {
					resolve();
					return;
				}

				waited += POLL;

				if ( waited >= timeout ) {
					reject();
					return;
				}

				setTimeout( tick, POLL );
			};

			tick();
		} );
	}

	/**
	 * Predicate that passes once the element's top has held steady.
	 *
	 * @param {string} selector Element to watch.
	 * @return {Function} Predicate for waitFor().
	 */
	function stableTop( selector ) {
		let last = null;
		let settled = 0;

		return function () {
			const el = document.querySelector( selector );
			const top = el
				? Math.round( el.getBoundingClientRect().top )
				: null;

			settled = null !== top && top === last ? settled + 1 : 0;
			last = top;

			return settled >= 2;
		};
	}

	/**
	 * The driver.js factory from the vendored IIFE build, if it loaded.
	 *
	 * @return {Function|null} Factory function or null.
	 */
	function getFactory() {
		return window.driver && window.driver.js
			? window.driver.js.driver
			: null;
	}

	/**
	 * Expands the Product data metabox when the user has it collapsed.
	 *
	 * @return {void}
	 */
	function openMetabox() {
		const $box = $( METABOX );

		if ( ! $box.hasClass( 'closed' ) ) {
			return;
		}

		// Clicking .handlediv would POST closed-postboxes and overwrite the user's own preference.
		$box.removeClass( 'closed' );
		$box.find( '.handlediv' ).attr( 'aria-expanded', 'true' );
	}

	/**
	 * Whether the FBT tab is present and on screen for this product type.
	 *
	 * WooCommerce shows it for simple and variable products only.
	 *
	 * @return {boolean} True when the tour has something to point at.
	 */
	function tabReady() {
		const $tab = $( TAB );
		return $tab.length > 0 && $tab.is( ':visible' );
	}

	/**
	 * Activates the Frequently Bought Together tab so the panel is on screen.
	 *
	 * @return {void}
	 */
	function openFbtTab() {
		$( TAB ).children( 'a' ).first().trigger( 'click' );
	}

	/**
	 * Brings a step's target back on screen before it gets highlighted.
	 *
	 * Needed going backwards as well as forwards: choosing Auto Suggest hides the
	 * manual pane, which is where the product picker lives.
	 *
	 * @param {string} selector Target selector.
	 * @return {void}
	 */
	function revealTarget( selector ) {
		if ( $( selector ).is( ':visible' ) ) {
			return;
		}

		openFbtTab();
		$( MANUAL_TAB ).first().trigger( 'click' );
	}

	/**
	 * Scrolls the page so the element is centred, without touching containers.
	 *
	 * scrollIntoView() scrolls every scrollable ancestor, and .panel-wrap is
	 * overflow:hidden with a huge scrollHeight — scrolling it blanks the panel.
	 *
	 * @param {Element} el Target element.
	 * @return {void}
	 */
	function scrollPageTo( el ) {
		const rect = el.getBoundingClientRect();
		const top =
			window.scrollY +
			rect.top -
			window.innerHeight / 2 +
			rect.height / 2;

		window.scrollTo( 0, Math.max( 0, Math.round( top ) ) );
	}

	/**
	 * Undoes any scrolling applied to the metabox container.
	 *
	 * @return {boolean} True when something had to be reset.
	 */
	function resetPanelScroll() {
		let changed = false;

		$( PANEL_WRAP ).each( function () {
			if ( this.scrollTop ) {
				this.scrollTop = 0;
				changed = true;
			}
		} );

		return changed;
	}

	/**
	 * Holds the metabox container at the top for as long as the tour runs.
	 *
	 * @param {boolean} on Whether to pin.
	 * @return {void}
	 */
	function pinPanelScroll( on ) {
		$( PANEL_WRAP ).off( 'scroll.wcfFbtTour' );

		if ( ! on ) {
			return;
		}

		$( PANEL_WRAP ).on( 'scroll.wcfFbtTour', function () {
			if ( ! this.scrollTop ) {
				return;
			}

			// Putting the container back moves the target, so re-measure the cut-out.
			this.scrollTop = 0;

			window.requestAnimationFrame( function () {
				if ( tour ) {
					tour.refresh();
				}
			} );
		} );
	}

	/**
	 * Whether the Enable Widget box is ticked.
	 *
	 * @return {boolean} True when the widget is on.
	 */
	function widgetEnabled() {
		return $( TOGGLE ).is( ':checked' );
	}

	/**
	 * Whether the user can actually get at the Enable Widget switch.
	 *
	 * @return {boolean} True when the switch is on screen.
	 */
	function toggleReachable() {
		return $( TOGGLE_LABEL ).is( ':visible' );
	}

	/**
	 * Locks or unlocks the Next button, reusing driver's own disabled class.
	 *
	 * @param {boolean} locked Whether to lock it.
	 * @return {void}
	 */
	function lockNext( locked ) {
		$( NEXT_BTN )
			.toggleClass( DISABLED, locked )
			.attr( 'aria-disabled', locked ? 'true' : 'false' );
	}

	/**
	 * Locks the Next button while the gated step waits on the user.
	 *
	 * @param {boolean} gated Whether the current step is the gated one.
	 * @return {void}
	 */
	function syncGate( gated ) {
		gateActive = gated;

		if ( $( NEXT_BTN ).length ) {
			lockNext( gated && ! widgetEnabled() );
		}
	}

	/**
	 * Records the tour as seen so it does not auto-start again for this user.
	 *
	 * @return {void}
	 */
	function markSeen() {
		if ( ! wcf_fbt_tour.ajax_url || ! wcf_fbt_tour.nonce ) {
			return;
		}

		$.post( wcf_fbt_tour.ajax_url, {
			action: 'cartflows_pro_fbt_tour_seen',
			nonce: wcf_fbt_tour.nonce,
		} );
	}

	/**
	 * Reveals the destination, then hops — one hop at a time.
	 *
	 * The lock matters: without it every click during the wait queues another hop
	 * and the tour can skip straight past the last step.
	 *
	 * @param {string}   selector Destination step's target.
	 * @param {Function} move     Driver call that performs the hop.
	 * @return {void}
	 */
	function navigate( selector, move ) {
		if ( navigating ) {
			return;
		}

		navigating = true;
		lockNext( true );
		revealTarget( selector );

		const hop = function () {
			navigating = false;
			move();
		};

		waitFor( function () {
			return $( selector ).is( ':visible' );
		}, WAIT_TIMEOUT ).then( hop, hop );
	}

	/**
	 * Maps the localized steps onto driver.js step objects.
	 *
	 * @param {Array} steps Localized step definitions.
	 * @return {Array} driver.js steps.
	 */
	function buildSteps( steps ) {
		return steps.map( function ( step, index ) {
			const config = {
				element() {
					// Hidden is not missing — a hidden target must still resolve, or
					// driver mislabels this step "Done".
					return document.querySelector( step.selector );
				},
				popover: {
					title: step.title,
					description: step.content,
					side: step.side,
					align: step.align,
				},
			};

			// Both hooks have to live on popover — driver ignores step-level ones.
			if ( index < steps.length - 1 ) {
				config.popover.onNextClick = function () {
					// Turning the widget on is the user's call, so hold here for them.
					if (
						GATE_STEP === index &&
						toggleReachable() &&
						! widgetEnabled()
					) {
						return;
					}

					navigate( steps[ index + 1 ].selector, function () {
						if ( tour ) {
							tour.moveNext();
						}
					} );
				};
			}

			if ( index > 0 ) {
				config.popover.onPrevClick = function () {
					navigate( steps[ index - 1 ].selector, function () {
						if ( tour ) {
							tour.movePrevious();
						}
					} );
				};
			}

			return config;
		} );
	}

	/**
	 * Builds and drives the tour.
	 *
	 * @param {boolean} force Ignore the seen flag and skip recording it (replay).
	 * @return {void}
	 */
	function start( force ) {
		const factory = getFactory();
		const steps = wcf_fbt_tour.steps || [];

		// Replay lands here directly, so the product-type check belongs here too.
		if ( active || ! factory || ! steps.length || ! tabReady() ) {
			return;
		}

		writeSeenOnEnd = ! force;
		atLastStep = false;
		navigating = false;
		active = true;

		// Remembered so an early dismissal can put the editor back where it was.
		$previousTab = $( '.product_data_tabs li.active' ).first();

		openMetabox();

		// Open the panel up front: while the tour runs driver blocks WooCommerce's
		// own tab handler, so a user clicking the tab would get nothing.
		openFbtTab();

		// Showing the panel changes the page height and the browser re-anchors the
		// scroll, so wait for the target to settle before driver measures it.
		waitFor( stableTop( steps[ 0 ].selector ), STABLE_TIMEOUT ).then(
			function () {
				drive( factory, steps );
			},
			abortStart
		);
	}

	/**
	 * Unwinds a tour that never got as far as being displayed.
	 *
	 * @return {void}
	 */
	function abortStart() {
		writeSeenOnEnd = false;
		teardown();
	}

	/**
	 * Releases everything the tour took hold of. Safe to call more than once —
	 * every close path funnels through here.
	 *
	 * @return {void}
	 */
	function teardown() {
		active = false;
		navigating = false;
		tour = null;
		pinPanelScroll( false );

		// Dismissed part-way through: hand the editor back the tab it was on.
		if ( ! atLastStep ) {
			restorePreviousTab();
		}

		if ( writeSeenOnEnd ) {
			writeSeenOnEnd = false;
			markSeen();
		}
	}

	/**
	 * Switches back to whichever product data tab was open before the tour.
	 *
	 * @return {void}
	 */
	function restorePreviousTab() {
		if (
			! $previousTab ||
			! $previousTab.length ||
			$previousTab.is( TAB )
		) {
			return;
		}

		$previousTab.children( 'a' ).first().trigger( 'click' );
		$previousTab = null;
	}

	/**
	 * Creates the driver instance and starts it.
	 *
	 * @param {Function} factory driver.js factory.
	 * @param {Array}    steps   Localized step definitions.
	 * @return {void}
	 */
	function drive( factory, steps ) {
		// Pinned only now, so an abandoned wait never leaves a listener attached.
		pinPanelScroll( true );

		// Reset before measuring — centring against a scrolled container is off by
		// however far it had been scrolled.
		resetPanelScroll();

		const first = document.querySelector( steps[ 0 ].selector );
		if ( first ) {
			scrollPageTo( first );
		}

		tour = factory( {
			steps: buildSteps( steps ),
			showProgress: steps.length > 1,
			allowClose: true,
			allowScroll: false,
			skipMissingElement: true,
			stagePadding: 6,
			// Keep a gap so a popover never lands on the control it points at.
			popoverOffset: 14,
			popoverClass: 'wcf-fbt-tour-popover',
			nextBtnText: wcf_fbt_tour.i18n.next,
			prevBtnText: wcf_fbt_tour.i18n.back,
			doneBtnText: wcf_fbt_tour.i18n.done,
			// Without this driver falls back to its own untranslated counter.
			progressText: wcf_fbt_tour.i18n.progress,
			onPopoverRender() {
				const index = tour ? tour.getActiveIndex() : -1;

				// Recomputed every render, so stepping back clears it again.
				atLastStep = index === steps.length - 1;

				syncGate( GATE_STEP === index );

				// driver scrolls each target into view, which shifts the container too.
				if ( resetPanelScroll() && tour ) {
					tour.refresh();
				}
			},
			// ✕, Escape and overlay clicks arrive here. driver only fires onDestroyed
			// while it still has an active element, so tear down here as well.
			onDestroyStarted() {
				const current = tour;

				teardown();

				if ( current ) {
					current.destroy();
				}
			},
			onDestroyed() {
				teardown();
			},
		} );

		tour.drive();

		// The first draw lands while the container is still settling, and refresh()
		// keeps the stale geometry — re-entering the step redraws it clean.
		setTimeout( function () {
			if ( tour && 0 === tour.getActiveIndex() ) {
				tour.moveTo( 0 );
			}
		}, REFRESH_DELAY );
	}

	/**
	 * Adds the replay control to the panel header.
	 *
	 * @return {void}
	 */
	function addReplayButton() {
		// The title row is already a flex row with a gap.
		const $header = $( '.wcf-fbt-header-title' );

		if (
			! $header.length ||
			$header.find( '.wcf-fbt-tour-replay' ).length
		) {
			return;
		}

		$( '<button/>', {
			type: 'button',
			class: 'wcf-fbt-tour-replay',
			text: '?',
			title: wcf_fbt_tour.i18n.replay,
			'aria-label': wcf_fbt_tour.i18n.replay,
		} )
			.on( 'click', function () {
				start( true );
			} )
			.appendTo( $header );
	}

	/**
	 * Auto-starts the tour for users who have not seen it yet.
	 *
	 * @return {void}
	 */
	function maybeAutoStart() {
		if ( autoRan || wcf_fbt_tour.seen ) {
			return;
		}

		autoRan = true;

		// A spotlight is pointless in a tab the user cannot see, and driver draws
		// its overlay on an animation frame, which browsers pause while hidden.
		whenTabVisible( function () {
			openMetabox();

			waitFor( tabReady, WAIT_TIMEOUT ).then(
				function () {
					start( false );
				},
				function () {}
			);
		} );
	}

	/**
	 * Runs the callback now if the tab is on screen, otherwise when it next is.
	 *
	 * @param {Function} run Callback.
	 * @return {void}
	 */
	function whenTabVisible( run ) {
		if ( 'hidden' !== document.visibilityState ) {
			run();
			return;
		}

		$( document ).one( 'visibilitychange.wcfFbtTour', function () {
			whenTabVisible( run );
		} );
	}

	function init() {
		if ( 'undefined' === typeof wcf_fbt_tour ) {
			return;
		}

		addReplayButton();

		// Unlock the gated step the moment the user turns the widget on.
		$( document ).on( 'change', TOGGLE, function () {
			if ( gateActive ) {
				syncGate( true );
			}
		} );

		// Starting at DOM ready gets the scroll reset by TinyMCE and metabox init.
		if ( 'complete' === document.readyState ) {
			setTimeout( maybeAutoStart, SETTLE_DELAY );
		} else {
			$( window ).on( 'load', function () {
				setTimeout( maybeAutoStart, SETTLE_DELAY );
			} );
		}
	}

	$( init );
} )( jQuery );
