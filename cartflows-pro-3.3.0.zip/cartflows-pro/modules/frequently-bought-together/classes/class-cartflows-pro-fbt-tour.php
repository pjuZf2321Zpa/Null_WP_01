<?php
/**
 * Frequently Bought Together — guided setup tour.
 *
 * Hooks the free plugin's `cartflows_fbt_admin_assets_enqueued` action to add a
 * driver.js spotlight tour over the FBT product panel, shown once per user.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Fbt_Tour.
 *
 * @since 3.1.4
 */
class Cartflows_Pro_Fbt_Tour {

	/**
	 * User meta flag set once the tour has been completed or dismissed.
	 *
	 * @var string
	 */
	const SEEN_META_KEY = 'cartflows_pro_fbt_tour_seen';

	/**
	 * Nonce action for the "mark as seen" request.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'cartflows_pro_fbt_tour';

	/**
	 * Capability required to see the tour — matches the rest of the Pro FBT admin.
	 *
	 * @var string
	 */
	const CAPABILITY = 'cartflows_manage_flows_steps';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Registers the asset hook and the seen-flag AJAX handler.
	 */
	public function __construct() {
		add_action( 'cartflows_fbt_admin_assets_enqueued', array( $this, 'enqueue_tour_assets' ) );
		add_action( 'wp_ajax_cartflows_pro_fbt_tour_seen', array( $this, 'ajax_mark_seen' ) );
	}

	/**
	 * Enqueues driver.js plus the tour launcher on the product edit screen.
	 *
	 * The free plugin fires this action inside its own `product` screen check, so
	 * the screen guard is already handled — only the capability needs checking.
	 *
	 * @return void
	 */
	public function enqueue_tour_assets() {

		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		// The guided setup is Pro's own, and its last step sells Auto Suggest — don't
		// ship it, or load driver.js, until the licence is active.
		if ( ! cartflows_pro_is_active_license() ) {
			return;
		}

		$assets_url = CARTFLOWS_PRO_FBT_URL . 'assets/';

		wp_enqueue_style( 'cartflows-pro-driver', $assets_url . 'css/driver.css', array(), CARTFLOWS_PRO_VER );

		wp_enqueue_style( 'wcf-fbt-tour', $assets_url . 'css/fbt-tour.css', array( 'cartflows-pro-driver' ), CARTFLOWS_PRO_VER );

		wp_enqueue_script( 'cartflows-pro-driver', $assets_url . 'js/driver.js', array(), CARTFLOWS_PRO_VER, true );

		// Depends on the free plugin's handle so the launcher runs after the panel is wired.
		wp_enqueue_script(
			'wcf-fbt-tour',
			$assets_url . 'js/fbt-tour.js',
			array( 'jquery', 'cartflows-pro-driver', 'wcf-fbt-admin' ),
			CARTFLOWS_PRO_VER,
			true
		);

		wp_localize_script(
			'wcf-fbt-tour',
			'wcf_fbt_tour',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( self::NONCE_ACTION ),
				'seen'     => $this->has_seen_tour(),
				'steps'    => $this->get_steps(),
				'i18n'     => array(
					'next'     => __( 'Next', 'cartflows-pro' ),
					'back'     => __( 'Back', 'cartflows-pro' ),
					'done'     => __( 'Done', 'cartflows-pro' ),
					'replay'   => __( 'Replay the setup guide', 'cartflows-pro' ),
					/* translators: {{current}} and {{total}} are step numbers filled in by the tour — keep both placeholders. */
					'progress' => __( '{{current}} of {{total}}', 'cartflows-pro' ),
				),
			)
		);
	}

	/**
	 * Whether the current user has already completed or dismissed the tour.
	 *
	 * @return bool
	 */
	public function has_seen_tour() {
		return ! empty( get_user_meta( get_current_user_id(), self::SEEN_META_KEY, true ) );
	}

	/**
	 * The guided setup steps, in order.
	 *
	 * Selectors follow WooCommerce's product data markup — tab key `cartflows_fbt`
	 * renders as `li.cartflows_fbt_tab`.
	 *
	 * @return array<int, array<string, string>>
	 */
	public function get_steps() {
		return array(
			array(
				'selector' => 'li.cartflows_fbt_tab',
				'title'    => __( 'Set up Frequently Bought Together', 'cartflows-pro' ),
				'content'  => __( 'Suggest companion products right on this product\'s page to lift your average order value.', 'cartflows-pro' ),
				'side'     => 'right',
				'align'    => 'start',
			),
			array(
				'selector' => '.wcf-fbt-toggle-label',
				'title'    => __( 'Turn the widget on', 'cartflows-pro' ),
				'content'  => __( 'Use this switch to activate the widget for this product. Your settings stay saved even if you disable it later.', 'cartflows-pro' ),
				// Sits to the left so the popover never covers the switch itself.
				'side'     => 'left',
				'align'    => 'center',
			),
			array(
				'selector' => '.wcf-fbt-picker-search',
				'title'    => __( 'Pick companion products', 'cartflows-pro' ),
				'content'  => __( 'Search and add products from your catalog, then drag to reorder them. The top item appears first in the widget.', 'cartflows-pro' ),
				'side'     => 'bottom',
				'align'    => 'start',
			),
			array(
				'selector' => '.wcf-fbt-sub-tab[data-mode="ai"]',
				'title'    => __( 'Or let Auto Suggest pick', 'cartflows-pro' ),
				'content'  => __( 'CartFlows analyses your order history and catalog to suggest products customers actually buy together.', 'cartflows-pro' ),
				'side'     => 'bottom',
				'align'    => 'start',
			),
		);
	}

	/**
	 * Marks the tour as seen for the current user.
	 *
	 * @return void
	 */
	public function ajax_mark_seen() {

		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized user.', 'cartflows-pro' ) ), 403 );
		}

		$user_id = get_current_user_id();
		if ( 0 === $user_id ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized user.', 'cartflows-pro' ) ), 403 );
		}

		update_user_meta( $user_id, self::SEEN_META_KEY, 1 );

		wp_send_json_success();
	}
}

Cartflows_Pro_Fbt_Tour::get_instance();
