<?php
/**
 * Frequently Bought Together — Pro extension bootstrap.
 *
 * Hooks into the free plugin's Cartflows_Fbt filters/actions to replace the
 * upgrade-wall placeholders with the real Auto Suggest UI.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Fbt_Extend.
 *
 * @since 3.1.4
 */
class Cartflows_Pro_Fbt_Extend {

	/**
	 * Pro-only source values appended to Free's whitelist via cartflows_fbt_source_values.
	 *
	 * @var array<int, string>
	 */
	const SOURCE_VALUES = array( 'ai', 'mixed' );

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Register the filter + action callbacks that extend the free-plugin UI.
	 */
	public function __construct() {

		// Source whitelist: append Pro-only 'ai' + 'mixed' to Free's default.
		add_filter( 'cartflows_fbt_source_values', array( $this, 'filter_source_values' ) );

		// Admin — swap Free's upgrade-wall pane for the real Generate hero once connected.
		add_filter( 'cartflows_fbt_ai_pane_html', array( $this, 'filter_ai_pane_html' ), 10, 2 );

	}

	/**
	 * Appends Pro-only 'ai' + 'mixed' to Free's source whitelist.
	 *
	 * @param mixed $values Current whitelist from the filter chain (may be non-array via 3rd-party filter).
	 * @return array<int, string>
	 */
	public function filter_source_values( $values ) {
		return array_values( array_unique( array_merge( is_array( $values ) ? $values : array(), self::SOURCE_VALUES ) ) );
	}

	/**
	 * Replaces the free-tier upgrade wall with the real Auto Suggest hero (Generate suggestions).
	 *
	 * @param string               $default_html Free plugin's default markup.
	 * @param array<string, mixed> $ctx          Product context (product_id, settings).
	 * @return string
	 */
	public function filter_ai_pane_html( $default_html, $ctx ) {

		// Auto Suggest is Pro-only. Free cannot render the licence wall itself — its
		// check reads the raw status string, which is truthy even when deactivated —
		// so Pro, which knows the real state, supplies the prompt.
		if ( ! cartflows_pro_is_active_license() ) {
			return '<div class="wcf-fbt-ai-hero">'
				. '<div class="wcf-fbt-ai-hero-icon" aria-hidden="true">&#x2728;</div>'
				. '<h4>' . esc_html__( 'Activate your licence to use Auto Suggest', 'cartflows-pro' ) . '</h4>'
				. '<p>' . esc_html__( 'Auto Suggest recommends products customers are likely to buy together. Activate your CartFlows Pro licence to switch it on.', 'cartflows-pro' ) . '</p>'
				. '<a href="' . esc_url( admin_url( 'admin.php?page=cartflows&path=settings&tab=license' ) ) . '" class="button button-primary wcf-fbt-upgrade-cta">'
				. esc_html__( 'Activate License', 'cartflows-pro' )
				. '</a>'
				. '</div>';
		}

		// Free plugin ships Cartflows_Ai_Auth from 3.1+. Fall back to the Connect card
		// on older Free builds where the class isn't loaded so we don't fatal.
		if ( ! class_exists( 'Cartflows_Ai_Auth' ) || ! Cartflows_Ai_Auth::get_instance()->get_auth_status() ) {
			return $default_html;
		}

		return '<div class="wcf-fbt-ai-hero">'
			. '<div class="wcf-fbt-ai-hero-icon" aria-hidden="true">&#x2728;</div>'
			. '<h4>' . esc_html__( 'Auto Suggest Products', 'cartflows-pro' ) . '</h4>'
			. '<p>' . esc_html__( 'Automatically suggest relevant products that customers are likely to buy with this product.', 'cartflows-pro' ) . '</p>'
			. '<button type="button" class="button button-primary wcf-fbt-generate">' . esc_html__( 'Generate suggestions', 'cartflows-pro' ) . '</button>'
			. '</div>';
	}

}

Cartflows_Pro_Fbt_Extend::get_instance();
