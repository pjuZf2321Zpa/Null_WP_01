<?php
/**
 * Frequently Bought Together — Linked Products AI drawer host.
 *
 * Adds a "Auto Suggest" button next to each of WooCommerce's native Linked
 * Products fields (Upsells + Cross-sells) and renders an empty drawer scaffold
 * that fbt-admin.js populates from the shared AI AJAX endpoints.
 *
 * WC's own markup, meta keys (`_upsell_ids`, `_crosssell_ids`), and save flow
 * are untouched — this class only appends product IDs into WC's Select2 fields
 * via the drawer's Accept action.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Cartflows_Pro_Fbt_Linked_Ai.
 *
 * @since 3.1.4
 */
class Cartflows_Pro_Fbt_Linked_Ai {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Registers the Linked Products tab hook.
	 */
	public function __construct() {
		add_action( 'woocommerce_product_options_related', array( $this, 'render_buttons' ) );
		add_action( 'admin_footer-post.php', array( $this, 'render_drawer_scaffold' ) );
		add_action( 'admin_footer-post-new.php', array( $this, 'render_drawer_scaffold' ) );
	}

	/**
	 * Renders the two "Auto Suggest" buttons inside the Linked Products tab.
	 *
	 * The hook fires after WC's own upsell + crosssell Select2 fields, so the
	 * buttons land immediately below them. JS moves each button next to its
	 * matching field on init.
	 *
	 * @return void
	 */
	public function render_buttons() {

		global $post;
		if ( ! isset( $post->ID ) ) {
			return;
		}
		if ( ! current_user_can( 'cartflows_manage_flows_steps' ) ) {
			return;
		}
		// Auto Suggest is Pro-only — offer no entry point without an active licence.
		if ( ! cartflows_pro_is_active_license() ) {
			return;
		}

		echo '<div class="wcf-fbt-linked-buttons" data-product-id="' . esc_attr( (string) absint( $post->ID ) ) . '">';
		echo '<button type="button" class="button button-secondary button-small wcf-fbt-suggest-ai" data-context="upsell" data-target-select="upsell_ids">';
		echo '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m12 3-1.9 5.8L4 10l6.1 1.9L12 18l1.9-6.1L20 10l-6.1-1.9L12 3z"/></svg>';
		echo '<span>' . esc_html__( 'Auto Suggest', 'cartflows-pro' ) . '</span>';
		echo '</button>';
		echo '<button type="button" class="button button-secondary button-small wcf-fbt-suggest-ai" data-context="crosssell" data-target-select="crosssell_ids">';
		echo '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m12 3-1.9 5.8L4 10l6.1 1.9L12 18l1.9-6.1L20 10l-6.1-1.9L12 3z"/></svg>';
		echo '<span>' . esc_html__( 'Auto Suggest', 'cartflows-pro' ) . '</span>';
		echo '</button>';
		echo '</div>';
	}

	/**
	 * Renders the drawer scaffold once at the admin footer.
	 *
	 * Kept out of the WC tab panel so it can use position:fixed cleanly and
	 * doesn't inherit any `display: none` from an inactive tab.
	 *
	 * @return void
	 */
	public function render_drawer_scaffold() {

		$screen = get_current_screen();
		if ( ! $screen || 'product' !== $screen->id ) {
			return;
		}
		if ( ! current_user_can( 'cartflows_manage_flows_steps' ) ) {
			return;
		}
		// No drawer without an active licence — its buttons are gated the same way.
		if ( ! cartflows_pro_is_active_license() ) {
			return;
		}

		echo '<div class="wcf-fbt-drawer-root" hidden>';
		echo '<div class="wcf-fbt-drawer-backdrop" tabindex="-1"></div>';
		echo '<aside class="wcf-fbt-drawer" role="dialog" aria-modal="true" aria-labelledby="wcf-fbt-drawer-title">';
		echo '<header class="wcf-fbt-drawer-header">';
		echo '<div>';
		echo '<h3 id="wcf-fbt-drawer-title" class="wcf-fbt-drawer-title"></h3>';
		echo '<p class="wcf-fbt-drawer-meta"></p>';
		echo '</div>';
		echo '<button type="button" class="wcf-fbt-drawer-close" aria-label="' . esc_attr__( 'Close', 'cartflows-pro' ) . '">';
		echo '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';
		echo '</button>';
		echo '</header>';
		echo '<div class="wcf-fbt-drawer-body"></div>';
		echo '<div class="wcf-fbt-drawer-empty" role="status">';
		echo '<span class="wcf-fbt-drawer-empty-icon" aria-hidden="true">';
		echo '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="m5 12 5 5L20 7"/></svg>';
		echo '</span>';
		echo '<h4 class="wcf-fbt-drawer-empty-title">' . esc_html__( "You're all set", 'cartflows-pro' ) . '</h4>';
		echo '<p class="wcf-fbt-drawer-empty-desc">' . esc_html__( 'Every product suggestions has been reviewed. Regenerate for a fresh batch, or cancel to close this panel.', 'cartflows-pro' ) . '</p>';
		echo '<div class="wcf-fbt-drawer-empty-actions">';
		echo '<button type="button" class="button button-primary wcf-fbt-btn wcf-fbt-btn-sm wcf-fbt-drawer-regen">' . esc_html__( 'Regenerate', 'cartflows-pro' ) . '</button>';
		echo '<button type="button" class="button wcf-fbt-btn wcf-fbt-btn-sm wcf-fbt-drawer-done">' . esc_html__( 'Cancel', 'cartflows-pro' ) . '</button>';
		echo '</div>';
		echo '</div>';
		echo '<footer class="wcf-fbt-drawer-footer">';
		echo '<button type="button" class="button wcf-fbt-btn wcf-fbt-btn-sm wcf-fbt-drawer-regen">';
		echo '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99"/></svg>';
		echo ' <span>' . esc_html__( 'Regenerate all', 'cartflows-pro' ) . '</span>';
		echo '</button>';
		echo '<button type="button" class="button button-primary wcf-fbt-btn wcf-fbt-btn-sm wcf-fbt-drawer-done">' . esc_html__( 'Done', 'cartflows-pro' ) . '</button>';
		echo '</footer>';
		echo '</aside>';
		echo '</div>';
	}
}

Cartflows_Pro_Fbt_Linked_Ai::get_instance();
