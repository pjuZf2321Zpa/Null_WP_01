---
module: instant-checkout
---

# instant-checkout

## Responsibility

Owns the Buy Now popup: a WooCommerce checkout, for a CartFlows checkout step, rendered over a single-product page without leaving it. The module owns the button on the product page, the two `wc-ajax` endpoints that open and close the dialog, the layout registry and its templates, the popup's own design settings, the cart it borrows while the dialog is up, and the order marker that says a purchase came through it.

Ownership stops at the checkout itself. Nothing about fields, gateways, totals, coupons, order bumps or offers is reimplemented here — the popup puts the request into a checkout-step context and lets `[cartflows_checkout]` produce the same markup a funnel step would, then moves the result into a layout. Anything the popup appears to do to the checkout is WooCommerce or CartFlows doing it.

This is not the free plugin's "Instant Checkout" *layout* (`wcf-checkout-layout`, `modules/checkout/classes/layouts/` in free), which styles a funnel's own checkout page. Two features, similar names, no shared code.

## Why it is this way

**The checkout is produced, not built.** `Render::get_checkout_html()` swaps the global post for the checkout step, forces `woocommerce_is_checkout`, and runs the shortcode. Every alternative — cloning templates, calling `woocommerce_checkout()` directly, assembling fields — forks behaviour that gateways, the field editor and every CartFlows checkout setting already depend on. The cost is that the module has to enter and leave a foreign context carefully, which is what most of the render class is.

**Totals are server-authoritative.** The dialog only ever displays what an `update_checkout` fragment returned. A popup that computed its own totals would be a second source of truth for the number a shopper is charged, and product pages are commonly full-page cached, so their markup cannot be trusted as input either. The layout slug is read from the AJAX response for the same reason.

**The form shell is pre-bound, then adopted.** `render_form_shell()` prints an empty `form.checkout` and `form.checkout_coupon` into the product page footer so `checkout.js` and each gateway bind their DOM-ready handlers to real nodes. On open, the fetched markup's children are *moved into* those bound nodes rather than replacing them. Re-binding after injection was tried and fails for gateways that only bind once.

**The popup borrows the cart rather than modelling a purchase.** Buy Now empties the cart, adds the product, and keeps a snapshot; dismissing restores it. This is what lets the real checkout be real — there is no separate basket to keep in step. The consequence is that the module must know exactly which lines it put there, which is what the session backup's `popup` map records, and it must hand the cart back the way WooCommerce would, not the way a plain array assignment would.

**Which funnel Buy Now opens is a per-product choice, separate from the Add to Cart redirect.** Both read the funnel selected on the product's CartFlows tab, which free owns. Tying them together meant a merchant who wanted a product-specific popup also got a redirected Add to Cart button. Each has its own opt-out instead: free's redirect checkbox, and this module's, rendered through free's `cartflows_product_tab_after_flow_field` hook so free never has to know about Instant Checkout. Both default to on, so stores that never touch them behave exactly as before.

**The open endpoint carries no nonce.** A nonce printed onto a full-page-cached product page serves stale and every open 403s. Same-origin checks stand in, and every value that decides what is bought is re-derived server-side: the product ID must resolve to the posted step, the variation must be a child of the parent, and the posted `add-to-cart` is overwritten with the validated ID. The endpoints the popup calls in turn — order bumps, the Checkout Offer — keep their own nonces, minted into the uncached open response.

**Layouts are a registry.** Layout was hardcoded in four places when there was one layout; adding a second meant copying the placement logic and the bugs with it. The registry keeps the load-bearing invariants — form adoption, clipped rather than hidden panes, bump processing, cart safety — in shared code, so a layout can only change placement. An unknown slug resolves to the default at read time, because flow meta also arrives from imports and the abilities API.

## Boundaries

- The checkout step, its fields and its settings belong to CartFlows free and the Pro checkout module.
- Order bumps belong to `modules/order-bump/`; this module only re-anchors where they render and swaps the variation picker for one that works without the Quick View modal.
- Third-party adaptation belongs in `compatibilities/` — the Cart Abandonment Recovery, Power Coupons and Product Bundles shims are there, not here. What stays in this module is only what is about the popup itself: which button the dialog opens from, and how the cart it borrows is handed back. Product Bundles is the case that tests the line, because the popup has to know its button markup and its cart-item contract while everything about bundle *pricing* and *orders* stays in the shim.
