/**
 * Instant Checkout popup.
 *
 * Opens the funnel's checkout in a dialog on the product page. The dialog holds WooCommerce's own
 * markup, so checkout.js keeps ownership of validation, totals refresh and order submission.
 *
 * @package
 * @since 3.1.4
 */

/* global woocommerce_params, instantCheckout */
( function ( $ ) {
	'use strict';

	const FOCUSABLE =
		'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"]), iframe';

	// Fields the Contact step owns; the phone's dial-code select (Cart Abandonment Recovery's row
	// partner) travels with the phone or it is left orphaned at half width in the Address step.
	const CONTACT_FIELDS = [
		'billing_phone_country_code_field',
		'billing_phone_field',
		'billing_email_field',
	];

	// Everything else: billing rows, shipping, order notes and the coupon block.
	const ADDRESS_FIELDS =
		'.woocommerce-billing-fields .form-row, .woocommerce-shipping-fields, .woocommerce-additional-fields, #ship-to-different-address, .checkout_coupon, .wcf-custom-coupon-field';

	// What each server-named field group maps to in WooCommerce's markup; selectors run in order.
	const FIELD_GROUPS = {
		contact: CONTACT_FIELDS.map( ( id ) => '#' + id ).concat( [
			'.woocommerce-account-fields',
		] ),
		address: [ ADDRESS_FIELDS ],
		payment: [ '.woocommerce-checkout-payment' ],
	};

	// PayPal Payments' buttons stand in for Place Order. They sit outside the payment block, so a
	// totals refresh keeps them, and their iframes remount if moved once drawn.
	// SDK v6 prints the same containers with a -v6 suffix, plus a card-button row.
	const PAY_BUTTONS =
		'.ppc-button-wrapper, #ppc-button-ppcp-applepay, #ppc-button-ppcp-googlepay, #ppc-button-ppcp-applepay-v6, #ppc-button-ppcp-googlepay-v6, #ppc-button-ppcp-card-button-gateway-v6';

	// WooCommerce's own Place Order, before and after it moves to the pay row. PayPal's card fields
	// print a hidden second #place_order one level deeper in the same block; never match that one.
	const PLACE_ORDER =
		'.form-row.place-order > #place_order, .wcf-icp-pay-actions > #place_order';

	const DEFAULT_LAYOUT = 'two-pane';

	const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

	// The applied-coupon "remove" link, delegated by both cart.js and checkout.js.
	const COUPON_LINK = 'a.woocommerce-remove-coupon';

	// English fallbacks so a missing localize script never leaves the button permanently dead.
	const FALLBACK_I18N = {
		fieldRequired: 'Enter your %s.',
		fieldInvalid: 'Enter a valid %s.',
		stepStatus: 'Step %1$s of %2$s: %3$s',
		chooseOptions: 'Please choose the product options first.',
		buttonDisabled:
			"This product can't be bought yet — check the options above.",
		generic: 'Something went wrong. Please try again.',
		placingOrder: 'Placing your order…',
		fbtDropped:
			'We could not add %s to this order, so your total is lower than shown.',
		fbtDroppedUnnamed:
			'Some products could not be added, so your total is lower than shown.',
		fbtChooseOptions:
			'Please choose an option for the selected products, or untick them.',
	};

	const i18n = ( key ) => {
		const strings =
			( 'undefined' !== typeof instantCheckout &&
				instantCheckout.i18n ) ||
			{};

		return strings[ key ] || FALLBACK_I18N[ key ] || '';
	};

	// The field name is passed through untouched; a translator decides how it reads inside the sentence.
	const i18nf = ( key, value ) => i18n( key ).replace( '%s', value );

	// Where Two Pane stops being two panes; kept in step with the same query in layout-two-pane.css.
	const NARROW = '(max-width: 720px)';

	// Countries whose postcode is digits and nothing else; see NUMERIC_POSTCODE_COUNTRIES in PHP.
	const numericPostcodes = () =>
		( 'undefined' !== typeof instantCheckout &&
			instantCheckout.numericPostcodes ) ||
		[];

	/**
	 * Layout strategies, keyed by the slug the server sends with the popup.
	 *
	 * The server describes each layout and the generic code arranges the checkout from that. A
	 * strategy adds behaviour beyond that: overrides for `placement` (step slug → selectors),
	 * `summaryTarget` ('slot', 'payment' or a selector) and `couponTarget`, plus three hooks each
	 * called with `{ $overlay, $form, steps, config }`: `onBuilt`, `onStepChange( ctx, slug, index,
	 * isLast )` and `onUpdatedCheckout`. Missing keys inherit the two-pane defaults below; register
	 * via `window.wcfInstantCheckout.registerLayout( slug, strategy )`.
	 */
	const BASE_LAYOUT = {
		placement: null,
		summaryTarget: null,
		couponTarget: '[data-wcf-icp-coupon]',
		onBuilt() {},

		/**
		 * Re-arrange the payment step after it is (re)built.
		 *
		 * @param {Object}  ctx    Layout context.
		 * @param {string}  slug   Step now shown.
		 * @param {number}  index  Its index.
		 * @param {boolean} isLast Whether it is the last step.
		 */
		onStepChange( ctx, slug, index, isLast ) {
			if ( isLast ) {
				this.arrange( ctx );
			}
		},

		/**
		 * Re-arrange the payment step after a totals refresh replaced the payment block.
		 *
		 * @param {Object} ctx Layout context.
		 */
		onUpdatedCheckout( ctx ) {
			this.arrange( ctx );
		},

		/**
		 * Order the payment step: payment methods, then Back / Place Order.
		 *
		 * The payment block is replaced wholesale on every totals refresh, so the Back / Place Order
		 * row lives below it instead, where PayPal's buttons can share it. A refresh mints a fresh
		 * #place_order; move it into the row and drop stale copies so the id is never duplicated. The
		 * terms/privacy notice sits directly above the button.
		 *
		 * @param {Object} ctx Layout context.
		 */
		arrange( ctx ) {
			const $pane = ctx.$overlay.find(
				'.wcf-icp-step[data-step="payment"]'
			);
			const $actions = $pane.find( '.wcf-icp-pay-actions' );

			if ( ! $actions.length ) {
				return;
			}

			const $block = $pane.find( '.woocommerce-checkout-payment' );
			const $freshPlace = $block.find(
				'.form-row.place-order > #place_order'
			);

			if ( $freshPlace.length ) {
				$actions.children( '#place_order' ).not( $freshPlace ).remove();
				$actions.append( $freshPlace );
			}

			// PayPal's card fields keep their own #place_order in a wrapper inside the payment block, which
			// comes first on the page; PayPal hides and clicks document.querySelector( '#place_order' ), so
			// the wrapper goes after ours. It holds only that button, never the card-field iframes.
			const $freshCards = $block.find( '#ppcp-hosted-fields' );

			if ( $freshCards.length ) {
				$actions
					.children( '#ppcp-hosted-fields' )
					.not( $freshCards )
					.remove();
				$actions.append( $freshCards );
			}

			// Only when it isn't there yet: re-inserting the row would remount PayPal's iframes in it.
			if ( ! $actions.parent().is( $pane ) ) {
				$actions.appendTo( $pane );
			}

			// Like #place_order, the terms/privacy wrapper is in the payment block: a refresh
			// brings a fresh copy, so keep it, drop stale copies, place it above the button.
			// WooCommerce skips an unchanged fragment, so no fresh copy means the moved one is current.
			const $freshTerms = $block.find(
				'.woocommerce-terms-and-conditions-wrapper'
			);

			if ( $freshTerms.length ) {
				$pane
					.find( '.woocommerce-terms-and-conditions-wrapper' )
					.not( $freshTerms )
					.remove();

				$freshTerms.insertBefore( $actions );
			}

			// The blocked-payment note is printed under the button, so lifting the row leaves it behind.
			if ( $freshPlace.length ) {
				$pane
					.find( '.wcf-icp-pay-blocked' )
					.not( $block.find( '.wcf-icp-pay-blocked' ) )
					.remove();
			}

			$pane.find( '.wcf-icp-pay-blocked' ).insertAfter( $actions );
		},
	};

	const LAYOUTS = {
		'two-pane': {},
		quickbuy: {},
	};

	window.wcfInstantCheckout = {
		layouts: LAYOUTS,

		/**
		 * Register a strategy for a layout added through the PHP filter.
		 *
		 * @param {string} slug     Layout slug.
		 * @param {Object} strategy Overrides for BASE_LAYOUT.
		 */
		registerLayout( slug, strategy ) {
			LAYOUTS[ slug ] = strategy || {};
		},
	};

	const InstantCheckout = {
		$overlay: null,
		$opener: null,
		loading: false,
		step: '',
		steps: [],
		fields: {},

		// Postcode verdicts the server has given, keyed country|value; null while one is being asked for.
		postcodes: {},
		postcodeRequests: {},
		layout: null,
		config: null,
		ctx: null,
		bumping: false,
		stepId: 0,
		ajaxUrl: '',
		bumpNonce: '',
		qtyNonce: '',
		restoreXhr: null,
		submitObserver: null,
		pageNoticeObserver: null,
		totalsInFlight: 0,
		backLabel: '',
		suspendedCouponHandlers: null,

		/**
		 * Bind the product page and dialog handlers.
		 */
		init() {
			this.inheritButtonStyle();
			this.watchBuyNowState();
			this.guardBoundForm();

			$( document.body )
				.on( 'click', '.wcf-icp-buy-now', this.onBuyNow.bind( this ) )
				.on(
					'click',
					'.wcf-icp-close, .wcf-icp-overlay',
					this.onDismiss.bind( this )
				)
				.on( 'click', '[data-wcf-icp-next]', this.onNext.bind( this ) )
				.on( 'click', '.wcf-icp-back', this.onBack.bind( this ) )
				.on( 'click', '.wcf-icp-pill-button', this.onPill.bind( this ) )
				.on(
					'click',
					'.wcf-icp-total-toggle',
					this.onTotalToggle.bind( this )
				)
				.on(
					'focusout',
					'.wcf-icp-overlay .wcf-icp-step .form-row :input',
					this.onFieldBlur.bind( this )
				)
				.on(
					'input',
					'.wcf-icp-overlay #coupon_code.has-error',
					this.onCouponEdit.bind( this )
				)
				.on(
					'input change',
					'.wcf-icp-overlay .form-row.wcf-icp-has-error :input',
					this.onErrorRowEdit.bind( this )
				)
				.on(
					'change',
					'.wcf-icp-overlay #billing_country, .wcf-icp-overlay #shipping_country',
					this.onCountryChange.bind( this )
				)
				.on(
					'change',
					'.wcf-icp-overlay .wcf-icp-summary input[name^="shipping_method"], .wcf-icp-overlay .wcf-icp-summary select.shipping_method',
					this.onShippingMethodChange.bind( this )
				)
				.on(
					'input',
					'.wcf-icp-overlay .form-row.wcf-icp-invalid :input',
					this.onInvalidEdit.bind( this )
				)
				.on(
					'change focusout',
					'.wcf-icp-overlay .form-row.wcf-icp-invalid :input',
					this.onInvalidRecheck.bind( this )
				)
				.on(
					'change',
					'.wcf-icp-overlay .wcf-bump-order-cb',
					this.onBump.bind( this )
				)
				.on(
					'change',
					'.wcf-icp-overlay .wcf-icp-bump-attr',
					this.onBumpVariation.bind( this )
				)
				.on(
					'click',
					'.wcf-icp-overlay .wcf-ob-qty-selection-btn',
					this.onBumpQty.bind( this )
				)
				.on(
					'change',
					'.wcf-icp-overlay select.shipping_method, .wcf-icp-overlay input[name^="shipping_method"]',
					this.onShippingChange.bind( this )
				);

			$( document ).on( 'keydown', this.onKeydown.bind( this ) );

			// Rotating a phone can put the rail back beside the form, where nothing would reopen it.
			$( window ).on( 'resize orientationchange', () => {
				if ( this.$overlay ) {
					this.syncRailPanel();
				}
			} );

			// A reload or tab close never reaches close(), so hand the cart back on pagehide — the
			// last point a request can be sent, and only sendBeacon survives it.
			window.addEventListener( 'pagehide', this.onPageHide.bind( this ) );

			// WooCommerce prepends server-side field errors (postcode, state, gateway) to
			// form.checkout, outside every pane, so route the shopper to the step that owns them.
			$( document.body ).on(
				'checkout_error',
				this.onCheckoutError.bind( this )
			);

			// WooCommerce swaps the whole payment block on every totals refresh, taking the
			// Back / Place Order row with it — rebuild the row whenever that step is on screen.
			$( document.body ).on( 'updated_checkout', () => {
				if ( ! this.$overlay || ! this.layout ) {
					return;
				}

				if ( this.isLastStep() ) {
					this.wirePayRow();
				}

				this.layout.onUpdatedCheckout( this.ctx );
			} );

			// WooCommerce greys out only the payment block while totals refresh, and Place Order sits
			// outside it in the pay row, so block the row for the life of each totals request.
			$( document )
				.on( 'ajaxSend', ( event, xhr, settings ) =>
					this.onTotalsRequest( settings, 1 )
				)
				.on( 'ajaxComplete', ( event, xhr, settings ) =>
					this.onTotalsRequest( settings, -1 )
				);

			// PayPal Payments announces each container it forces visible.
			$( document ).on( 'ppcp-shown', this.onPayPalShown.bind( this ) );
		},

		/**
		 * Drop the inline display:block PayPal forces on its SDK v6 button stack while the row hides it.
		 * That block beats PayPal's own flex column, so PayPal, Venmo and Pay Later touched.
		 *
		 * @since x.x.x
		 * @param {Object} event jQuery event.
		 * @param {Object} data  PayPal's payload; `element` is the container it showed.
		 */
		onPayPalShown( event, data ) {
			const element = data && data.element;

			if (
				! this.$overlay ||
				! element ||
				'ppc-button-ppcp-gateway-v6' !== element.id ||
				! $.contains( this.$overlay[ 0 ], element )
			) {
				return;
			}

			if ( 'block' === element.style.getPropertyValue( 'display' ) ) {
				element.style.removeProperty( 'display' );
			}
		},

		/**
		 * Lock the pay row while a totals refresh is in flight, as WooCommerce blocks the payment block.
		 *
		 * Counted, because a new refresh aborts the previous one, and that abort completes after the new send.
		 *
		 * @param {Object} settings jQuery AJAX settings.
		 * @param {number} delta    1 when a request starts, -1 when one ends.
		 */
		onTotalsRequest( settings, delta ) {
			if (
				! settings ||
				'string' !== typeof settings.url ||
				-1 === settings.url.indexOf( 'update_order_review' )
			) {
				return;
			}

			this.totalsInFlight = Math.max( 0, this.totalsInFlight + delta );

			// A class, not blockUI: blockUI writes an inline position onto a static row and leaves
			// `position: static` behind on unblock, which beats QuickBuy's pinned mobile row.
			if ( this.$overlay ) {
				this.$overlay
					.find( '.wcf-icp-pay-actions' )
					.toggleClass(
						'wcf-icp-is-refreshing',
						this.totalsInFlight > 0
					);
			}
		},

		/**
		 * Give Buy Now the same classes the theme put on Add to cart.
		 *
		 * Themes style the add-to-cart button by its own class, not `.button`, so copying the sibling's
		 * classes matches both heights with no per-theme CSS. Staying `type="button"` keeps it from
		 * submitting; it does let the variation script toggle `disabled` — wanted, no Buy Now for an
		 * unavailable variation.
		 */
		inheritButtonStyle() {
			$( '.wcf-icp-buy-now' ).each( function () {
				const $button = $( this );
				const $reference = $button
					.closest( 'form.cart' )
					.find( '.single_add_to_cart_button' )
					.first();

				if ( ! $reference.length ) {
					return;
				}

				// `disabled` is skipped because it is state, not style, and copying it once at init
				// would strand Buy Now for any vendor that clears the class by a narrower selector.
				// bundle_add_to_cart_button is skipped because Product Bundles binds a delegated click
				// handler to it on .bundle_data, which alerts when the button is disabled.
				$reference
					.attr( 'class' )
					.split( /\s+/ )
					.forEach( ( name ) => {
						if (
							name &&
							'disabled' !== name &&
							'bundle_add_to_cart_button' !== name
						) {
							$button.addClass( name );
						}
					} );
			} );
		},

		/**
		 * Keep Buy Now's disabled *attribute* in step with its disabled *class*.
		 *
		 * Buy Now carries the theme's add-to-cart classes, so WooCommerce's variation script marks it
		 * directly and Product Bundles marks it by position — as a class only, never the attribute.
		 * Without the attribute the button looks greyed out but still dispatches clicks, and those
		 * reach WooCommerce's form-delegated handler, which answers with `window.alert()` for an
		 * unavailable variation. A genuinely disabled button dispatches nothing, so one observer
		 * covers every product type. Product Bundles' own alert is stopped earlier and separately, by
		 * inheritButtonStyle() not copying bundle_add_to_cart_button; it is not delegated on the form.
		 *
		 * The class is watched rather than either vendor's events: Product Bundles fires
		 * validation-status-changed before it toggles the class, and WooCommerce fires
		 * found_variation for unpurchasable variations too, so both read the wrong state.
		 * Only ever mirrors an observed class, so a vendor script that never runs changes nothing.
		 */
		watchBuyNowState() {
			if ( 'undefined' === typeof window.MutationObserver ) {
				return;
			}

			$( '.wcf-icp-buy-now' ).each( function () {
				const $button = $( this );
				let wasDisabled = null;

				// Setting the property leaves the class alone, so this cannot re-trigger itself.
				// setLoading() writes the class list too, and its callback reaches us a microtask later,
				// so the spinner has to count as blocking or we would re-enable mid-request.
				const sync = () => {
					const disabled = $button.hasClass( 'disabled' );

					$button.prop(
						'disabled',
						disabled || $button.hasClass( 'wcf-icp-loading' )
					);

					// Transitions track the vendor's class alone. Were the spinner counted here too, the
					// clear that follows setLoading( false ) would land a microtask after notify() has
					// written the failure message, and delete the only explanation the shopper gets.
					if ( ! disabled && true === wasDisabled ) {
						$button
							.closest( 'form.cart' )
							.find( '.wcf-icp-notice-inline' )
							.remove();
					}

					wasDisabled = disabled;
				};

				new window.MutationObserver( sync ).observe( this, {
					attributes: true,
					attributeFilter: [ 'class' ],
				} );

				sync();
			} );
		},

		/**
		 * Show a message on the product page, beside the button that produced it.
		 *
		 * @param {Object} $button Button the message belongs to.
		 * @param {string} message Message to show.
		 * @param {Object} $target Element to show it in; defaults to the button's form.
		 */
		showInlineNotice( $button, message, $target ) {
			const $host =
				$target && $target.length
					? $target
					: $button.closest( 'form.cart' );

			$host.find( '.wcf-icp-notice-inline' ).remove();
			$( '<div class="wcf-icp-notice-inline" role="alert" />' )
				.text( message )
				.appendTo( $host );
		},

		/**
		 * The wc-ajax endpoint URL for a given action.
		 *
		 * @param {string} action Endpoint name.
		 * @return {string} Absolute URL.
		 */
		endpoint( action ) {
			let template = '';

			if (
				'undefined' !== typeof wc_checkout_params &&
				wc_checkout_params.wc_ajax_url
			) {
				template = wc_checkout_params.wc_ajax_url;
			} else if (
				'undefined' !== typeof woocommerce_params &&
				woocommerce_params.wc_ajax_url
			) {
				template = woocommerce_params.wc_ajax_url;
			}

			return template.toString().replace( '%%endpoint%%', action );
		},

		/**
		 * Collect the product form as a nested object.
		 *
		 * An object (not a serialized string) so the server can wc_clean() it without a urlencoded
		 * round trip. Array-shaped names are unpacked to any depth (quantity[child_id], and gift
		 * cards' recipients[0][email]) since a literal bracketed key is truncated by PHP's parser.
		 *
		 * @param {Object} $form      The add-to-cart form.
		 * @param {string} fallbackId Product ID to fall back to.
		 * @return {Object} Field map.
		 */
		collectForm( $form, fallbackId ) {
			const fields = {};

			$.each( $form.serializeArray(), function ( index, field ) {
				const parts = field.name.match( /^([^[]+)((?:\[[^\]]*\])+)$/ );

				if ( ! parts ) {
					fields[ field.name ] = field.value;
					return;
				}

				const path = [ parts[ 1 ] ].concat(
					parts[ 2 ]
						.match( /\[[^\]]*\]/g )
						.map( ( seg ) => seg.slice( 1, -1 ) )
				);

				let node = fields;

				path.forEach( ( rawKey, i ) => {
					const key =
						'' === rawKey ? Object.keys( node ).length : rawKey;

					if ( i === path.length - 1 ) {
						node[ key ] = field.value;
						return;
					}

					if ( 'object' !== typeof node[ key ] ) {
						node[ key ] = {};
					}

					node = node[ key ];
				} );
			} );

			// serializeArray() skips buttons, and simple products carry add-to-cart on the submit button.
			if ( ! fields[ 'add-to-cart' ] ) {
				fields[ 'add-to-cart' ] =
					$form.find( '[name="add-to-cart"]' ).val() || fallbackId;
			}

			return fields;
		},

		/**
		 * Handle a Buy Now click.
		 *
		 * @param {Object} event Click event.
		 */
		onBuyNow( event ) {
			event.preventDefault();

			// The button carries the theme's add-to-cart classes, so stop the click reaching other
			// plugins bound to those — including on the early returns below where it isn't disabled.
			event.stopPropagation();

			if ( this.loading ) {
				return;
			}

			// A dismissal's cart restore may still be in flight; wait rather than race it for the
			// session. currentTarget is only readable while the event is live, hence the stand-in.
			if ( this.restoreXhr && 'pending' === this.restoreXhr.state() ) {
				const currentTarget = event.currentTarget;

				this.restoreXhr.always( () =>
					this.onBuyNow( {
						preventDefault() {},
						stopPropagation() {},
						currentTarget,
					} )
				);
				return;
			}

			const $button = $( event.currentTarget );

			// Scope to the clicked button's own form; Astra renders a second one in its sticky bar.
			let $form = $button.closest( 'form.cart' );

			if ( ! $form.length ) {
				$form = $( 'form.cart' ).first();
			}

			// Every stale message goes, whichever form or widget holds it, before any guard below adds
			// its own. The observer clears only on a vendor disabled true->false transition, which a
			// notify() failure never produces, so this is the one place those get cleared — and being
			// synchronous and shopper-initiated, it cannot race the response that writes the next one.
			$( '.wcf-icp-notice-inline' ).remove();

			// Something already decided this purchase is not ready. The fallback for when the class is
			// there but the property is not: no MutationObserver, or a third party that only styles.
			if ( $button.hasClass( 'disabled' ) ) {
				this.showInlineNotice( $button, i18n( 'buttonDisabled' ) );
				return;
			}

			// Variable products need a variation chosen first.
			const $variationId = $form.find( 'input[name="variation_id"]' );

			if ( $variationId.length && ! parseInt( $variationId.val(), 10 ) ) {
				this.showInlineNotice( $button, i18n( 'chooseOptions' ) );
				$form.trigger( 'wcf-icp-variation-required' );
				return;
			}

			const productId = $button.data( 'product-id' );

			// The Frequently Bought Together widget's inputs carry no name, so they never reach
			// collectForm(); free exposes this reader instead. Absent on an older free — no companions.
			const fbt =
				'function' === typeof window.wcfFbt?.getSelection
					? window.wcfFbt.getSelection( productId )
					: null;

			// Ticked but no variation chosen is an unanswered question, not a companion to drop quietly.
			if ( fbt && fbt.unresolved > 0 ) {
				const $widget = $(
					'.wcf-fbt-widget[data-source-id="' + productId + '"]'
				).first();

				// Anchored to the widget: it is outside form.cart on three of its four placements, and
				// the main product's found_variation clears everything inside that form.
				this.showInlineNotice(
					$button,
					i18n( 'fbtChooseOptions' ),
					$widget.length ? $widget : null
				);

				$widget.one( 'change', () =>
					$widget.find( '.wcf-icp-notice-inline' ).remove()
				);

				return;
			}

			const data = {
				step_id: $button.data( 'step-id' ),
				product_id: productId,
				product_form: this.collectForm( $form, productId ),
			};

			// Sibling of product_form: that array is replayed into $_POST for WC's add-to-cart handler,
			// where these keys could collide with a product add-on's own fields.
			if ( fbt && fbt.items.length ) {
				data.fbt = { items: fbt.items };
			}

			this.setLoading( $button, true );

			$.ajax( {
				type: 'POST',
				url: this.endpoint( 'wcf_instant_open' ),
				data,
				dataType: 'json',
			} )
				.done( this.onOpened.bind( this, $button ) )
				.fail( this.onFailed.bind( this, $button ) );
		},

		/**
		 * Inject and reveal the returned checkout.
		 *
		 * @param {Object} $button  The clicked button.
		 * @param {Object} response Endpoint response.
		 */
		onOpened( $button, response ) {
			this.setLoading( $button, false );

			if (
				! response ||
				! response.success ||
				! response.data ||
				! response.data.html
			) {
				this.notify(
					response && response.data ? response.data.message : '',
					$button
				);
				return;
			}

			this.stepId = response.data.step_id;
			this.ajaxUrl = response.data.ajax_url || '';
			this.bumpNonce = response.data.bump_nonce || '';
			this.qtyNonce = response.data.qty_nonce || '';

			// wc_checkout_params was localized into a product page that may have been served from a
			// full-page cache, so its nonces can be older than the shopper's session. These were
			// minted by the request that just rendered this dialog.
			if (
				response.data.checkout_nonces &&
				'undefined' !== typeof window.wc_checkout_params
			) {
				$.extend(
					window.wc_checkout_params,
					response.data.checkout_nonces
				);
			}

			// Same staleness problem as the nonces above: the Checkout Offer's script reads these off the global
			// `cartflows` object, which is printed into a product page that may be served from a full-page cache.
			if (
				response.data.offer_nonces &&
				'undefined' !== typeof window.cartflows
			) {
				$.extend( window.cartflows, response.data.offer_nonces );
			}

			this.$opener = $button;

			// Clear a previous popup without restoring — the cart the server just built stays.
			this.close( false );

			this.$overlay = $( '<div class="wcf-icp-overlay" />' )
				.append( response.data.html )
				.appendTo( document.body );

			// Layout comes from the response, not the product page, which may be a stale cached copy.
			const slug =
				String( response.data.layout || '' ).replace(
					/[^a-z0-9_-]/gi,
					''
				) || DEFAULT_LAYOUT;

			this.config = response.data;
			this.layout = $.extend( {}, BASE_LAYOUT, LAYOUTS[ slug ] || {} );
			this.readSteps( response.data.steps );
			this.$overlay.addClass( 'wcf-icp-layout-' + slug );

			// Only then does the Field Editor's per-field width apply; see instant-checkout-base.css.
			if ( response.data.fields_custom ) {
				this.$overlay.addClass( 'wcf-icp-fields-custom' );
			}

			// The product page may be cached with a different layout's stylesheet; load the one the
			// response actually chose so the markup isn't styled by a stale layout's CSS.
			this.ensureLayoutStylesheet( response.data.stylesheet_url );

			this.suspendCartCouponHandlers();

			this.adoptBoundForm();
			this.adoptCouponForm();

			this.ctx = {
				$overlay: this.$overlay,
				$form: this.$overlay.find( 'form.checkout' ),
				steps: this.steps,
				config: this.config,
			};

			this.placeSummary();
			this.placeCoupon();

			// Build steps before the first refresh so gateways mount into their final position —
			// moving Stripe's iframe inside .woocommerce-checkout-payment afterwards would remount it.
			this.buildSteps();
			this.setPostcodeKeyboards();
			this.syncRailPanel();
			this.watchSubmitState();
			this.watchPageNotices();
			this.layout.onBuilt( this.ctx );

			// Restore what the previous dismissal kept, and resume where it left off.
			if ( this.savedFields ) {
				this.savedFields.forEach( ( field ) => {
					const $field = this.$overlay
						.find( '[name="' + field.name + '"]' )
						.not( ':checkbox, :radio' );

					// Overwrites, never fills blanks: WooCommerce prefills these from the stored address, so
					// a returning shopper's every field is already non-empty and would be skipped.
					if ( $field.length && $field.val() !== field.value ) {
						$field.val( field.value ).trigger( 'change' );
					}
				} );

				this.goTo( this.savedStep );
			}

			// Kept for wirePayRow() to rebuild Back after WooCommerce replaces the payment block.
			this.backLabel = this.$overlay.find( '.wcf-icp-back' ).text();

			$( document.body ).addClass( 'wcf-icp-open' );

			$( document.body ).trigger( 'update_checkout' );

			this.focusFirst();

			// Buy Now swapped the cart server-side; refresh theme header carts still showing the old one.
			$( document.body ).trigger( 'wc_fragment_refresh' );

			// After buildSteps(), whose showStep() clears this region.
			this.noticeDropped( response.data.fbt_dropped );

			$( document.body ).trigger( 'wcf_instant_checkout_opened', [
				this.$overlay,
			] );
		},

		/**
		 * Name the Frequently Bought Together companions the cart refused.
		 *
		 * The widget already showed their price, so the lower total needs an explanation.
		 *
		 * @param {Array} dropped Refused companions from the open response.
		 */
		noticeDropped( dropped ) {
			if ( ! Array.isArray( dropped ) || ! dropped.length ) {
				return;
			}

			const names = dropped
				.map( ( item ) =>
					item && item.name ? String( item.name ) : ''
				)
				.filter( ( name ) => '' !== name );

			if ( ! names.length ) {
				this.showNotice( i18n( 'fbtDroppedUnnamed' ) );
				return;
			}

			this.showNotice(
				i18n( 'fbtDropped' ).replace( '%s', () => names.join( ', ' ) )
			);
		},

		/**
		 * Ensure the layout stylesheet the response chose is the one loaded.
		 *
		 * The product page enqueues a layout stylesheet server-side and can be full-page cached, so after
		 * a merchant switches layouts the cached page keeps the old CSS while the AJAX sends the new markup.
		 *
		 * @param {string} url Versionless URL of the layout stylesheet from the response.
		 */
		ensureLayoutStylesheet( url ) {
			if ( ! url ) {
				return;
			}

			const $existing = $( '#wcf-icp-layout-css' );
			const current = $existing.length
				? String( $existing.attr( 'href' ) ).split( '?' )[ 0 ]
				: '';

			if ( current === url ) {
				return;
			}

			$existing.remove();
			$( '<link>', {
				rel: 'stylesheet',
				id: 'wcf-icp-layout-css',
				href: url,
			} ).appendTo( 'head' );
		},

		/**
		 * Drop a submit-time rejection once the shopper edits the field it named.
		 *
		 * @since x.x.x
		 * @param {Object} event Input event.
		 */
		onInvalidEdit( event ) {
			$( event.target )
				.attr( 'aria-invalid', null )
				.removeAttr( 'aria-describedby' )
				.closest( '.form-row' )
				.removeClass( 'wcf-icp-invalid' )
				.find( '.checkout-inline-error-message' )
				.remove();
		},

		/**
		 * Put aria-invalid back after checkout.js clears it on a field only the server rejected.
		 *
		 * @since x.x.x
		 * @param {Object} event Change or focusout event.
		 */
		onInvalidRecheck( event ) {
			const $field = $( event.target );

			// Deferred so it lands after checkout.js's own handler, whichever order the two were bound in.
			window.setTimeout( () => {
				const $row = $field.closest( '.form-row' );

				if ( ! $row.hasClass( 'wcf-icp-invalid' ) ) {
					return;
				}

				const $note = $row.find( '.wcf-icp-field-error' );

				$field.attr( 'aria-invalid', 'true' );

				if ( $note.length ) {
					$field.attr( 'aria-describedby', $note.attr( 'id' ) );
				}
			}, 0 );
		},

		/**
		 * The field's own visible label, without the required or optional marker.
		 *
		 * @since x.x.x
		 * @param {Object} $field Field to name.
		 * @return {string} Label text, or an empty string when the row carries none.
		 */
		labelOf( $field ) {
			const $label = $field
				.closest( '.form-row' )
				.find( 'label' )
				.first()
				.clone();

			$label.find( '.required, .optional' ).remove();

			return $.trim( $label.text() );
		},

		/**
		 * Give WooCommerce's submit errors the treatment the Continue path already applies.
		 *
		 * @since x.x.x
		 * @return {Object} field: the first field WooCommerce rejected; loose: messages naming no field.
		 */
		flagCheckoutErrors() {
			const o = this.$overlay;
			const loose = [];
			let $first = null;

			o.find( '.form-row.wcf-icp-invalid' )
				.removeClass( 'wcf-icp-invalid' )
				.find( '[aria-invalid]' )
				.attr( 'aria-invalid', null );

			o.find( '.woocommerce-NoticeGroup-checkout li' ).each(
				( index, el ) => {
					const $field = $(
						document.getElementById(
							$( el ).attr( 'data-id' ) || ''
						)
					);

					// Gateway and cart problems name no field, so the dialog's own region carries them.
					if ( ! $field.length ) {
						const loner = $.trim( $( el ).text() );

						if ( loner ) {
							loose.push( loner );
						}
						return;
					}

					const $row = $field.closest( '.form-row' );

					$row.addClass( 'wcf-icp-invalid' );
					$field.attr( 'aria-invalid', 'true' );

					// Woo composes "Billing ZIP Code" server-side while the form calls it ZIP Code.
					const $named = $( el ).find( 'strong' ).first();
					const label = this.labelOf( $field );

					if ( label && $named.length ) {
						$named.text( label );
					}

					// Its own copy under the field is dropped the moment the field blurs, so carry the text.
					this.setFieldError( $field, $.trim( $( el ).text() ) );

					if ( ! $first ) {
						$first = $field;
					}
				}
			);

			// Woo hangs its summary on form.checkout, outside every pane, so it would otherwise
			// follow the shopper onto steps that own none of it and never clear.
			o.find( '.woocommerce-NoticeGroup-checkout' ).remove();

			return { field: $first, loose };
		},

		/**
		 * Send the shopper to the step holding the first field WooCommerce rejected.
		 */
		onCheckoutError() {
			if ( ! this.$overlay ) {
				return;
			}

			const paneOf = ( el ) =>
				$( el ).closest( '.wcf-icp-step' ).data( 'step' ) || '';
			const errors = this.flagCheckoutErrors();
			const $first = errors.field;

			// Gateway errors name no field; fall back to whatever WooCommerce marked invalid.
			const slug = $first
				? paneOf( $first )
				: paneOf(
						this.$overlay.find( '.woocommerce-invalid' ).first()
				  );

			if ( slug && slug !== this.step ) {
				this.goTo( slug );
			}

			// goTo() empties the notice region, so the fieldless messages go in after any move.
			if ( errors.loose.length ) {
				this.showNotice( errors.loose );
			}

			// scroll_to_notices() scrolls the page, frozen by body.wcf-icp-open — move the dialog's scroller.
			this.$overlay
				.find( '.wcf-icp-flow, .wcf-icp-dialog' )
				.add( this.$overlay )
				.scrollTop( 0 );

			if ( $first ) {
				$first.trigger( 'focus' );
			}
		},

		/**
		 * Hand the cart back when the page goes away with the dialog still open.
		 */
		onPageHide() {
			if ( ! this.$overlay || ! this.stepId ) {
				return;
			}

			const url = this.endpoint( 'wcf_instant_close' );

			if ( window.navigator && window.navigator.sendBeacon ) {
				window.navigator.sendBeacon( url );
			} else {
				$.ajax( { type: 'POST', url, async: false } );
			}

			this.stepId = 0;
		},

		/**
		 * Report a failed open.
		 *
		 * @param {Object} $button The clicked button.
		 * @param {Object} jqXHR   Failed request.
		 */
		onFailed( $button, jqXHR ) {
			this.setLoading( $button, false );

			let message = '';

			if ( jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.data ) {
				message = jqXHR.responseJSON.data.message;
			}

			this.notify( message, $button );
		},

		/**
		 * Surface a message on the product page.
		 *
		 * $opener is only set by a successful open and never reset, so it can point at a different
		 * button than the one just clicked — a page can carry two, such as Astra's sticky bar.
		 *
		 * @param {string} message Message to show.
		 * @param {Object} $button Button the message belongs to; falls back to the last opener.
		 */
		notify( message, $button ) {
			const $target =
				$button && $button.length
					? $button
					: this.$opener || $( '.wcf-icp-buy-now' ).first();

			this.showInlineNotice( $target, message || i18n( 'generic' ) );
		},

		/**
		 * Take the step list from the server, or reconstruct it from the template.
		 *
		 * The three-group fallback keeps a response missing the list opening a working popup.
		 *
		 * @param {Array} steps Step definitions from the response.
		 */
		readSteps( steps ) {
			this.steps = [];
			this.fields = {};
			this.postcodes = {};
			this.postcodeRequests = {};

			if ( Array.isArray( steps ) ) {
				steps.forEach( ( step ) => {
					if ( ! step || ! step.slug ) {
						return;
					}

					this.steps.push( String( step.slug ) );
					this.fields[ step.slug ] = Array.isArray( step.fields )
						? step.fields
						: [];
				} );
			}

			if ( this.steps.length ) {
				return;
			}

			// Defensive fallback only. Reconstructing from pills is unsafe (a layout with non-field-group
			// slugs like QuickBuy's 'details' builds empty panes), so use the always-valid three groups.
			[ 'contact', 'address', 'payment' ].forEach( ( slug ) => {
				this.steps.push( slug );
				this.fields[ slug ] = [ slug ];
			} );
		},

		/**
		 * Where the review table goes for this layout.
		 *
		 * @return {string} 'slot', 'payment' or a selector.
		 */
		summaryTarget() {
			return (
				this.layout.summaryTarget ||
				( this.config && this.config.summary_target ) ||
				'slot'
			);
		},

		/**
		 * Selectors for the fields a step owns.
		 *
		 * @param {string} slug Step slug.
		 * @return {Array} Selectors, in placement order.
		 */
		selectorsFor( slug ) {
			const placement = this.layout.placement || {};

			if ( placement[ slug ] ) {
				return placement[ slug ];
			}

			return ( this.fields[ slug ] || [] ).reduce(
				( selectors, group ) =>
					selectors.concat( FIELD_GROUPS[ group ] || [] ),
				[]
			);
		},

		/**
		 * Is the shopper on the final step?
		 *
		 * @return {boolean} Whether the current step is the last one.
		 */
		isLastStep() {
			return this.steps.indexOf( this.step ) === this.steps.length - 1;
		},

		/**
		 * Move the order review table into the layout's summary slot.
		 *
		 * Moving (not cloning) keeps fragment refresh working — it replaces the table by selector
		 * wherever it lives. Layouts showing the table inside the last step leave it for buildSteps().
		 */
		placeSummary() {
			if ( ! this.$overlay ) {
				return;
			}

			const target = this.summaryTarget();

			if ( 'payment' === target ) {
				return;
			}

			const $summary = this.$overlay.find(
				'slot' === target ? '[data-wcf-icp-summary]' : target
			);

			// first() so a layout emitting a second review table can't put two in the rail.
			const $table = this.$overlay
				.find( '.woocommerce-checkout-review-order-table' )
				.first();

			if ( $summary.length && $table.length ) {
				$summary.append( $table );
			}
		},

		/**
		 * Move the coupon block into the layout's coupon slot.
		 *
		 * The coupon block is its own <form> beside form.checkout, so it needs a slot outside the
		 * checkout form to avoid nested forms. The toggle link and form are separate siblings; both
		 * must move or the link ends up pointing at a form elsewhere.
		 */
		placeCoupon() {
			if ( ! this.$overlay ) {
				return;
			}

			const $coupon = this.$overlay.find(
				'.woocommerce-form-coupon-toggle, .checkout_coupon, .wcf-custom-coupon-field'
			);
			const $slot = this.$overlay.find( this.layout.couponTarget );

			if ( $coupon.length && $slot.length ) {
				$slot.append( $coupon ).prop( 'hidden', false );
			}
		},

		/**
		 * Keep WooCommerce's empty-cart reply from replacing the bound form when the popup was closed at send time.
		 * Anything that fires update_checkout on an empty cart (Modern Cart closing its drawer) gets a session-expired fragment for form.woocommerce-checkout.
		 *
		 * @since x.x.x
		 */
		guardBoundForm() {
			$.ajaxPrefilter( ( options ) => {
				if (
					! /wc-ajax=update_order_review/.test( options.url || '' )
				) {
					return;
				}

				const previous = options.dataFilter;
				const sentWhileOpen = $( document.body ).hasClass(
					'wcf-icp-open'
				);

				options.dataFilter = ( data, type ) => {
					const reply = previous ? previous( data, type ) : data;

					// A request the open popup sent wants WooCommerce's own reply, including the expired-session notice.
					if ( sentWhileOpen || 'string' !== typeof reply ) {
						return reply;
					}

					try {
						const parsed = JSON.parse( reply );

						if (
							parsed &&
							parsed.fragments &&
							parsed.fragments[ 'form.woocommerce-checkout' ]
						) {
							delete parsed.fragments[
								'form.woocommerce-checkout'
							];
							return JSON.stringify( parsed );
						}
					} catch ( error ) {
						return reply;
					}

					return reply;
				};
			} );
		},

		/**
		 * Move the fetched checkout into the form node WooCommerce already bound to.
		 *
		 * checkout.js and every gateway bind directly to `form.checkout` captured on DOM ready, so a
		 * form arriving later over AJAX has no handlers and Place Order does a native POST. The server
		 * prints an empty form up front for those handlers; move the fetched contents into that same
		 * node so every bound handler survives.
		 */
		adoptBoundForm() {
			const $bound = $( 'form.checkout[data-wcf-icp-form]' );
			const $fetched = this.$overlay
				.find( 'form.checkout' )
				.not( '[data-wcf-icp-form]' );

			if ( ! $bound.length || ! $fetched.length ) {
				return;
			}

			$bound.append( $fetched.children() ).removeAttr( 'hidden' );
			$fetched.replaceWith( $bound );
			$bound.closest( '.wcf-icp-form-shell' ).removeAttr( 'hidden' );
		},

		/**
		 * Same swap for the coupon form, its own <form> beside the checkout.
		 *
		 * checkout.js binds its submit on DOM ready too, so a fetched coupon form's Apply does a native
		 * POST that reloads and loses filled fields. Left collapsed on adopt — `a.showcoupon` reveals it.
		 */
		adoptCouponForm() {
			const $bound = $(
				'form.checkout_coupon[data-wcf-icp-coupon-form]'
			);
			const $fetched = this.$overlay
				.find( 'form.checkout_coupon' )
				.not( '[data-wcf-icp-coupon-form]' );

			if ( ! $bound.length || ! $fetched.length ) {
				return;
			}

			$bound.append( $fetched.children() ).removeAttr( 'hidden' ).hide();
			$fetched.replaceWith( $bound );
		},

		/**
		 * Group the checkout's fields into the layout's steps.
		 *
		 * Rows are moved, not duplicated, so there stays one input per field and WooCommerce's own
		 * validation and serialization are untouched.
		 */
		buildSteps() {
			const $form = this.$overlay.find( 'form.checkout' );

			if ( ! $form.length ) {
				return;
			}

			// Panes live inside the form so every field stays serialized by checkout.js; the dialog
			// body would put them outside the form.
			const $panes = {};

			this.steps.forEach( ( slug ) => {
				$panes[ slug ] = $( '<div class="wcf-icp-step" />' )
					.attr( 'data-step', slug )
					.appendTo( $form );
			} );

			// Move in step order so an earlier step claims its fields before a later step's broader
			// selector sweeps them up (contact's phone/email are billing rows too); within a step,
			// selectors run in listed order so Cart Abandonment Recovery's fields are captured first.
			this.steps.forEach( ( slug ) => {
				this.selectorsFor( slug ).forEach( ( selector ) => {
					$form.find( selector ).appendTo( $panes[ slug ] );
				} );
			} );

			// Layouts without a summary slot show the review table in the payment step (a strategy may
			// reposition it).
			const last = this.steps[ this.steps.length - 1 ];

			if ( 'payment' === this.summaryTarget() && $panes[ last ] ) {
				const $table = this.$overlay
					.find( '.woocommerce-checkout-review-order-table' )
					.first();
				const $paymentBlock = $panes[ last ].find(
					'.woocommerce-checkout-payment'
				);

				if ( $table.length && $paymentBlock.length ) {
					$table.insertBefore( $paymentBlock );
				} else if ( $table.length ) {
					$table.appendTo( $panes[ last ] );
				}
			}

			// CartFlows' four single-page bump positions collapse onto the two matching steps:
			// customer details or the pay screen.
			$.each( this.bumpPositions(), ( positionClass, slug ) => {
				const $bumps = $form.find(
					'.wcf-all-bump-order-wrap.' + positionClass
				);

				if ( ! $bumps.length || ! $panes[ slug ] ) {
					return;
				}

				const $payment = $panes[ slug ].find(
					'.woocommerce-checkout-payment'
				);

				// An offer has to be seen before the pay button, not after it.
				if ( $payment.length ) {
					$bumps.insertBefore( $payment );
				} else {
					$bumps.appendTo( $panes[ slug ] );
				}
			} );

			// The pay row exists before the first refresh so PayPal's buttons render straight into it
			// beside Back; wirePayRow() adds Back and arrange() moves each fresh #place_order in.
			if (
				$panes.payment &&
				$panes.payment.find( '.woocommerce-checkout-payment' ).length
			) {
				$( '<div class="wcf-icp-pay-actions" />' )
					.append( $form.find( PAY_BUTTONS ) )
					.appendTo( $panes.payment );
			}

			// checkout.js init() ran against the empty shell, so these toggles never got their state
			// and opened expanded. Ship-to is delegated, so re-firing change suffices; #createaccount
			// was bound to nodes captured then, so remake it here or account fields stay open.
			const $shipToggle = $form.find(
				'#ship-to-different-address-checkbox'
			);

			if ( $shipToggle.length ) {
				$shipToggle.trigger( 'change' );
			}

			const $createAccount = $form.find( '#createaccount' );

			if ( $createAccount.length ) {
				$createAccount.on( 'change', () => {
					const isChecked = $createAccount.is( ':checked' );

					$form.find( 'div.create-account' ).toggle( isChecked );

					// Matches WooCommerce: never carry an autofilled password into a just-opened section.
					if ( isChecked ) {
						$form.find( '#account_password' ).val( '' );
					}
				} );

				$createAccount.trigger( 'change' );
			}

			this.gateVariationBumps();

			this.goTo( this.steps[ 0 ] );
		},

		/**
		 * Lock every variable bump's checkbox until a full, in-stock variation is chosen.
		 *
		 * A variable bump would otherwise post its parent ID and the server would silently pick a
		 * default variation; the shopper must choose here, so the box stays disabled until they do.
		 */
		gateVariationBumps() {
			this.$overlay
				.find( '.wcf-icp-bump-variations' )
				.each( ( index, element ) => {
					const $wrap = $( element );
					const $cb = this.bumpCheckbox( $wrap.data( 'ob-id' ) );
					const match = this.matchBumpVariation( $wrap );

					// A product with default attributes opens pre-selected: commit that variation so a first
					// check posts its ID, not the parent the server would only guess a default variation for.
					if ( match ) {
						this.commitBumpVariation( $wrap, $cb, match );
					} else {
						$cb.prop( 'checked', false ).prop( 'disabled', true );
					}
				} );
		},

		/**
		 * Write a resolved variation into a bump's checkbox so the add handler posts the right ID.
		 *
		 * @param {Object} $wrap The `.wcf-icp-bump-variations` wrapper.
		 * @param {Object} $cb   The bump checkbox.
		 * @param {Object} match The resolved variation ( has variation_id ).
		 */
		commitBumpVariation( $wrap, $cb, match ) {
			$cb.attr(
				'data-ob_data',
				JSON.stringify( {
					ob_id: String( $wrap.data( 'ob-id' ) ),
					product_id: match.variation_id,
					variation_id: match.variation_id,
				} )
			);
			$wrap.removeClass( 'is-incomplete' );
		},

		/**
		 * The checkbox that owns a given order bump.
		 *
		 * @param {string} obId Order bump ID.
		 * @return {Object} jQuery checkbox.
		 */
		bumpCheckbox( obId ) {
			return this.$overlay.find(
				'.wcf-bump-order-cb[name="wcf-bump-order-cb-' + obId + '"]'
			);
		},

		/**
		 * Resolve the variation a bump's dropdowns currently point at.
		 *
		 * @param {Object} $wrap The `.wcf-icp-bump-variations` wrapper.
		 * @return {Object|null} The matching in-stock variation, or null when the choice is incomplete.
		 */
		matchBumpVariation( $wrap ) {
			const variations = $wrap.data( 'variations' ) || [];
			const chosen = {};
			let complete = true;

			$wrap.find( '.wcf-icp-bump-attr' ).each( function () {
				const name =
					$( this ).data( 'attribute_name' ) ||
					$( this ).attr( 'name' );
				const value = $( this ).val();

				if ( ! value ) {
					complete = false;
				}

				chosen[ name ] = value;
			} );

			if ( ! complete ) {
				return null;
			}

			// WooCommerce stores '' for an attribute a variation accepts any value of.
			return (
				variations.find(
					( variation ) =>
						variation.in_stock &&
						Object.keys( chosen ).every( ( name ) => {
							const attr = variation.attributes[ name ];
							return '' === attr || attr === chosen[ name ];
						} )
				) || null
			);
		},

		/**
		 * Commit a bump's variation choice to its checkbox, or lock the box while it is incomplete.
		 *
		 * The existing add handler reads the variation from the checkbox's data-ob_data, so writing
		 * the resolved ID there is all it takes; a change while already added replaces the cart item.
		 *
		 * @param {Object} event Change event from an attribute dropdown.
		 */
		onBumpVariation( event ) {
			const $wrap = $( event.currentTarget ).closest(
				'.wcf-icp-bump-variations'
			);
			const $cb = this.bumpCheckbox( $wrap.data( 'ob-id' ) );

			if ( ! $cb.length ) {
				return;
			}

			const base = {
				ob_id: String( $wrap.data( 'ob-id' ) ),
				product_id: parseInt( $wrap.data( 'product-id' ), 10 ),
			};
			const match = this.matchBumpVariation( $wrap );
			const wasChecked = $cb.is( ':checked' );

			if ( match ) {
				this.commitBumpVariation( $wrap, $cb, match );
				$cb.prop( 'disabled', false );

				// Already in the cart: swap the old variation for the new one in one request.
				if ( wasChecked ) {
					this.sendBump( $cb, 'replace_bump_product' );
				}

				return;
			}

			// Incomplete or unavailable: point the box back at the parent and lock it.
			$cb.attr( 'data-ob_data', JSON.stringify( base ) );
			$wrap.addClass( 'is-incomplete' );

			if ( wasChecked ) {
				$cb.prop( 'checked', false );
				this.sendBump( $cb, 'remove_bump_product', {
					disableAfter: true,
				} );
			} else {
				$cb.prop( 'disabled', true );
			}
		},

		/**
		 * Which step each order-bump position lands in.
		 *
		 * Fallback only; the server sends the real map. All five collapse onto the pay step — see
		 * Cartflows_Pro_Instant_Checkout_Layout::get_bump_positions() for why.
		 *
		 * @return {Object} Position class → step slug.
		 */
		bumpPositions() {
			if ( this.config && this.config.bump_positions ) {
				return this.config.bump_positions;
			}

			const pay = this.steps[ this.steps.length - 1 ];

			return {
				'wcf-before-checkout': pay,
				'wcf-after-customer': pay,
				'wcf-above-order-summary': pay,
				'wcf-after-order': pay,
				'wcf-after-payment': pay,
			};
		},

		/**
		 * Show one step.
		 *
		 * Inactive steps are clipped, not display:none, so jQuery's :visible stays true for their
		 * fields — checkout.js derives has_full_address from `.address-field.validate-required:visible`,
		 * which the server uses to decide whether to calculate shipping.
		 *
		 * @param {string} slug Step to show.
		 */
		goTo( slug ) {
			const o = this.$overlay;

			if ( ! o || -1 === this.steps.indexOf( slug ) ) {
				return;
			}

			this.step = slug;

			o.find( '.wcf-icp-step' ).each( function () {
				const isActive = $( this ).data( 'step' ) === slug;
				$( this ).toggleClass( 'is-active', isActive );
				this.inert = ! isActive;
			} );

			const index = this.steps.indexOf( slug );

			o.find( '.wcf-icp-pill' ).each( function ( pillIndex ) {
				$( this )
					.toggleClass( 'is-active', pillIndex === index )
					.toggleClass( 'is-done', pillIndex < index )
					.find( '.wcf-icp-pill-button' )
					.attr( 'aria-current', pillIndex === index ? 'step' : null )

					// Only a future step is out of reach; the current one stays focusable so a screen reader announces it.
					.prop( 'disabled', pillIndex > index );
			} );

			const $pill = o.find( '.wcf-icp-pill' ).eq( index );

			o.find( '[data-wcf-icp-heading]' ).text( $pill.data( 'heading' ) );
			o.find( '[data-wcf-icp-sub]' ).text( $pill.data( 'sub' ) );

			// The row is a set of tabs rather than a meter, so the position is said outright for screen readers.
			o.find( '[data-wcf-icp-step-status]' ).text(
				i18n( 'stepStatus' )
					.replace( '%1$s', index + 1 )
					.replace( '%2$s', this.steps.length )
					.replace(
						'%3$s',
						$pill.find( '.wcf-icp-pill-label' ).text()
					)
			);

			const isLast = index === this.steps.length - 1;
			const $back = o
				.find( '.wcf-icp-back' )
				.prop( 'hidden', 0 === index );

			// The last step submits through WooCommerce's #place_order, so hide Next there.
			o.find( '[data-wcf-icp-next]' )
				.text( $pill.data( 'next' ) || '' )
				.prop( 'hidden', isLast );

			// Back and #place_order start in different containers; move Back onto the pay row on the
			// last step (wrapped, to keep terms text out of the flex row) and back to the nav otherwise.
			if ( isLast ) {
				this.wirePayRow();
			} else {
				o.find( '.wcf-icp-nav' )
					.prop( 'hidden', false )
					.prepend( $back );
			}

			o.find( '.wcf-icp-flow, .wcf-icp-dialog' ).add( o ).scrollTop( 0 );
			this.clearNotice();

			this.layout.onStepChange( this.ctx, slug, index, isLast );
		},

		/**
		 * Put Back on the same row as Place Order.
		 *
		 * Runs on entering payment and after every totals refresh, which replaces the payment block
		 * wholesale (and this wrapper) — so Back is rebuilt from the label captured at open.
		 */
		wirePayRow() {
			const o = this.$overlay;
			const $place = o.find( PLACE_ORDER );

			if ( ! $place.length ) {
				return;
			}

			let $back = o.find( '.wcf-icp-back' );

			if ( ! $back.length ) {
				$back = $(
					'<button type="button" class="wcf-icp-back" />'
				).text( this.backLabel );
			}

			let $actions = o.find( '.wcf-icp-pay-actions' );

			if ( ! $actions.length ) {
				$actions = $( '<div class="wcf-icp-pay-actions" />' )
					.insertBefore( $place )
					.append( $place );
			}

			$actions.prepend( $back.prop( 'hidden', false ) );
			o.find( '.wcf-icp-nav' ).prop( 'hidden', true );

			// buildSteps() already made the row, so #place_order is moved in here too: a registered layout may replace the hooks that call arrange().
			BASE_LAYOUT.arrange( this.ctx );
		},

		/**
		 * Advance if the current step's fields are valid.
		 */
		onNext() {
			// Clicking Continue is what blurs the postcode, so its answer is usually still in the air.
			const pending = this.pendingPostcode();

			if ( pending ) {
				pending.always( () => this.onNext() );
				return;
			}

			if ( ! this.validateStep() ) {
				return;
			}

			const next = this.steps[ this.steps.indexOf( this.step ) + 1 ];

			if ( ! next ) {
				return;
			}

			// Address changes drive shipping and tax, so refresh totals leaving the address step.
			const $pane = this.$overlay.find(
				'.wcf-icp-step[data-step="' + this.step + '"]'
			);

			if ( $pane.find( '.address-field' ).length ) {
				$( document.body ).trigger( 'update_checkout' );
			}

			this.goTo( next );
			this.focusFirst();
		},

		/**
		 * Go back one step.
		 */
		onBack() {
			const previous = this.steps[ this.steps.indexOf( this.step ) - 1 ];

			if ( previous ) {
				this.goTo( previous );
				this.focusFirst();
			}
		},

		/**
		 * Refresh totals when a shipping rate is picked outside form.checkout.
		 *
		 * WooCommerce only watches shipping inputs inside the form, and the summary slot is outside it.
		 *
		 * @since x.x.x
		 * @param {Object} event Change event.
		 */
		onShippingChange( event ) {
			// Inside the form, WooCommerce's own handler already refreshes.
			if ( $( event.target ).closest( 'form.checkout' ).length ) {
				return;
			}

			$( document.body ).trigger( 'update_checkout' );
		},

		/**
		 * Add or remove an order bump.
		 *
		 * The funnel checkout script that normally owns this isn't loaded on a product page, so call
		 * wcf_bump_order_process directly and refresh via update_checkout instead of its fragments.
		 *
		 * @param {Object} event Change event.
		 */
		onBump( event ) {
			const $cb = $( event.currentTarget );
			const checked = $cb.is( ':checked' );

			this.sendBump(
				$cb,
				checked ? 'add_bump_product' : 'remove_bump_product',
				{ onFail: () => $cb.prop( 'checked', ! checked ) }
			);
		},

		/**
		 * Post a bump add / remove / replace and refresh the totals.
		 *
		 * The funnel checkout script that normally owns this isn't loaded on a product page, so call
		 * wcf_bump_order_process directly and refresh via update_checkout instead of its fragments.
		 *
		 * @param {Object} $cb    The bump checkbox, carrying the offer in data-ob_data.
		 * @param {string} action add_bump_product | remove_bump_product | replace_bump_product.
		 * @param {Object} [opts] onFail: undo callback on failure; disableAfter: keep the box locked when done.
		 */
		sendBump( $cb, action, opts ) {
			const offer = $cb.attr( 'data-ob_data' );
			const options = opts || {};

			if ( this.bumping || ! offer || ! this.bumpNonce ) {
				return;
			}

			const failed = () => {
				if ( options.onFail ) {
					options.onFail();
				}
				this.showNotice( i18n( 'generic' ) );
			};

			this.bumping = true;
			$cb.prop( 'disabled', true );

			// The bump guard is global, so lock every variation dropdown too: changing one mid-request
			// would advance the UI while its replace is dropped, leaving the row and the choice out of step.
			const $attrs = this.$overlay.find( '.wcf-icp-bump-attr' );
			$attrs.prop( 'disabled', true );

			$.ajax( {
				type: 'POST',
				url: this.ajaxUrl,
				data: {
					action: 'wcf_bump_order_process',
					security: this.bumpNonce,
					_wcf_checkout_id: this.stepId,
					_wcf_bump_product_action: action,
					_bump_offer_data: offer,
				},
			} )
				.done( ( response ) => {
					// The endpoint bails with a bare '0' rather than an error; treat that as a failure.
					if ( ! response || '0' === response ) {
						failed();
						return;
					}

					$( document.body ).trigger( 'update_checkout' );
				} )
				.fail( failed )
				.always( () => {
					this.bumping = false;
					// A cleared variation leaves nothing to add, so the box stays locked.
					$cb.prop( 'disabled', !! options.disableAfter );
					$attrs.prop( 'disabled', false );
				} );
		},

		/**
		 * Step a bump's quantity up or down.
		 *
		 * The funnel script that owns the +/- buttons isn't loaded here, so adjust the field and push the
		 * new quantity to the cart ourselves — only for a bump already in the cart, as WooCommerce does.
		 *
		 * @param {Object} event Click event from a +/- button.
		 */
		onBumpQty( event ) {
			event.preventDefault();

			if ( this.bumping ) {
				return;
			}

			const $btn = $( event.currentTarget );
			const $input = $btn
				.closest( '.wcf-ob-qty-selection-wrap' )
				.find( '.wcf-order-bump-quantity-updater' );
			const min = parseInt( $input.attr( 'min' ), 10 ) || 1;
			const current = parseInt( $input.val(), 10 ) || min;
			const next = $btn.hasClass( 'wcf-ob-qty-increment' )
				? current + 1
				: Math.max( min, current - 1 );

			$input.val( next );

			const $cb = $btn
				.closest( '.wcf-bump-order-wrap' )
				.find( '.wcf-bump-order-cb' );

			// The quantity only reaches the cart once the offer is in it; otherwise the field just remembers it.
			if ( $cb.is( ':checked' ) ) {
				this.updateBumpQty( $cb, next );
			}
		},

		/**
		 * Push a checked bump's new quantity to the cart and refresh the totals.
		 *
		 * @param {Object} $cb      The bump checkbox, carrying the offer in data-ob_data.
		 * @param {number} quantity The quantity to set.
		 */
		updateBumpQty( $cb, quantity ) {
			const offer = $cb.attr( 'data-ob_data' );

			if ( this.bumping || ! offer || ! this.qtyNonce ) {
				return;
			}

			this.bumping = true;

			// Lock the variation dropdowns for the request; changing one mid-flight would rewrite data-ob_data while its replace is dropped by the guard.
			const $attrs = this.$overlay.find( '.wcf-icp-bump-attr' );
			$attrs.prop( 'disabled', true );

			$.ajax( {
				type: 'POST',
				// The handler reads the step from wcf_checkout_id; on a product page nothing else supplies it.
				url: this.ajaxUrl + '?wcf_checkout_id=' + this.stepId,
				data: {
					action: 'wcf_update_order_bump_qty',
					security: this.qtyNonce,
					_wcf_bump_product_action: 'add_bump_product',
					_bump_offer_data: offer,
					_bump_offer_qty: quantity,
				},
			} )
				.done( ( response ) => {
					if ( ! response || '0' === response ) {
						this.showNotice( i18n( 'generic' ) );
						return;
					}

					$( document.body ).trigger( 'update_checkout' );
				} )
				.fail( () => this.showNotice( i18n( 'generic' ) ) )
				.always( () => {
					this.bumping = false;
					$attrs.prop( 'disabled', false );
				} );
		},

		/**
		 * Open or close the summary behind QuickBuy's pinned total.
		 *
		 * @since x.x.x
		 * @param {Object} event Click event.
		 */
		onTotalToggle( event ) {
			const $toggle = $( event.currentTarget );
			const open = 'true' !== $toggle.attr( 'aria-expanded' );

			$toggle.attr( 'aria-expanded', open ? 'true' : 'false' );
			$toggle
				.closest( '.wcf-icp-total' )
				.find( '.wcf-icp-total-panel' )
				.prop( 'hidden', ! open );
		},

		/**
		 * Jump to a completed step from its pill.
		 *
		 * @param {Object} event Click event.
		 */
		onPill( event ) {
			const slug = $( event.currentTarget )
				.closest( '.wcf-icp-pill' )
				.data( 'step' );

			if (
				this.steps.indexOf( slug ) < this.steps.indexOf( this.step )
			) {
				this.goTo( slug );
			}
		},

		/**
		 * Validate the visible step.
		 *
		 * Uses WooCommerce's contract (`.validate-required`, `.woocommerce-invalid`) so error styling
		 * keeps working, and only checks `:visible` rows — WooCommerce hides rows it doesn't want
		 * filled (account, alternate shipping), and checking them would strand the shopper off screen.
		 *
		 * @return {boolean} Whether the step may be left.
		 */
		validateStep() {
			const $pane = this.$overlay.find(
				'.wcf-icp-step[data-step="' + this.step + '"]'
			);
			let $firstInvalid = null;

			$pane.find( '.form-row:visible' ).each( ( index, row ) => {
				const $field = this.markRow( $( row ) );

				if ( $field && ! $firstInvalid ) {
					$firstInvalid = $field;
				}
			} );

			if ( $firstInvalid ) {
				$firstInvalid.trigger( 'focus' );
				return false;
			}

			return true;
		},

		/**
		 * Test one row against the contract WooCommerce marked it with.
		 *
		 * @since x.x.x
		 * @param {Object} $row   Row to test.
		 * @param {Object} $field Its first real field.
		 * @return {string} Which i18n key names the failure, or an empty string when the row is fine.
		 */
		rowFailure( $row, $field ) {
			const value = $.trim( String( $field.val() || '' ) );

			if ( $row.hasClass( 'validate-required' ) && '' === value ) {
				return 'fieldRequired';
			}

			if (
				$row.hasClass( 'validate-email' ) &&
				'' !== value &&
				! EMAIL_PATTERN.test( value )
			) {
				return 'fieldInvalid';
			}

			// No client rule exists for a postcode, so the server's last answer for this value stands in.
			if (
				$row.hasClass( 'validate-postcode' ) &&
				false === this.postcodes[ this.postcodeKey( $field ) ]
			) {
				return 'fieldInvalid';
			}

			return '';
		},

		/**
		 * The country a postcode field is being judged against.
		 *
		 * @since x.x.x
		 * @param {Object} $field Postcode field.
		 * @return {string} Country code, or an empty string.
		 */
		countryOf( $field ) {
			const id = String( $field.attr( 'id' ) || '' );

			return String(
				$( '#' + id.replace( /postcode$/, 'country' ) ).val() || ''
			);
		},

		/**
		 * Cache key for one postcode: the same digits pass in one country and fail in the next.
		 *
		 * @since x.x.x
		 * @param {Object} $field Postcode field.
		 * @return {string} Key into the answered-postcode cache.
		 */
		postcodeKey( $field ) {
			return (
				this.countryOf( $field ) +
				'|' +
				$.trim( String( $field.val() || '' ) )
			);
		},

		/**
		 * Ask the server whether a postcode is valid, once per country and value.
		 *
		 * @since x.x.x
		 * @param {Object} $field Postcode field.
		 */
		checkPostcode( $field ) {
			const value = $.trim( String( $field.val() || '' ) );
			const key = this.postcodeKey( $field );

			// An empty box belongs to the required check, and an answered one needs no second ask.
			if ( '' === value || undefined !== this.postcodes[ key ] ) {
				return;
			}

			// Null means asking: the row reads as fine until the answer lands, never as failed.
			this.postcodes[ key ] = null;

			const id = String( $field.attr( 'id' ) || '' );

			this.postcodeRequests[ id ] = $.ajax( {
				type: 'POST',
				url: this.endpoint( 'wcf_instant_postcode' ),
				data: { postcode: value, country: this.countryOf( $field ) },
			} )
				.done( ( response ) => {
					if ( ! response || ! response.success || ! response.data ) {
						delete this.postcodes[ key ];
						return;
					}

					this.postcodes[ key ] = !! response.data.valid;

					// The shopper may have typed on since; only judge the row still holding this value.
					if ( key === this.postcodeKey( $field ) ) {
						this.markRow( $field.closest( '.form-row' ) );
					}
				} )
				.fail( () => {
					// Unanswered, so a later blur may ask again rather than the row staying unjudged.
					delete this.postcodes[ key ];
				} )
				.always( () => {
					delete this.postcodeRequests[ id ];
				} );
		},

		/**
		 * The postcode request the current step is still waiting on, if any.
		 *
		 * @since x.x.x
		 * @return {Object|null} In-flight request, or null.
		 */
		pendingPostcode() {
			const ids = Object.keys( this.postcodeRequests );

			return ids.length ? this.postcodeRequests[ ids[ 0 ] ] : null;
		},

		/**
		 * Re-judge the postcode when the country changes under it.
		 *
		 * @since x.x.x
		 * @param {Object} event Change event.
		 */
		onCountryChange( event ) {
			const id = String( $( event.target ).attr( 'id' ) || '' ).replace(
				/country$/,
				'postcode'
			);
			const $field = $( '#' + id );

			if ( ! $field.length ) {
				return;
			}

			this.setPostcodeKeyboard( $field );
			this.markRow( $field.closest( '.form-row' ) );
			this.checkPostcode( $field );
		},

		/**
		 * Recalculate totals when a shipping method is picked in a summary placed outside the form.
		 *
		 * @since x.x.x
		 * @param {Object} event Change event.
		 */
		onShippingMethodChange( event ) {
			// WooCommerce already handles a method that still sits inside form.checkout.
			if ( $( event.target ).closest( 'form.checkout' ).length ) {
				return;
			}

			$( document.body ).trigger( 'update_checkout' );
		},

		/**
		 * Collapse the rail's panel only where its disclosure is on screen to reopen it.
		 *
		 * The panel ships without `hidden`: a wide rail has no bar, and a panel hidden there would be
		 * out of the accessibility tree while plainly visible.
		 *
		 * @since x.x.x
		 */
		syncRailPanel() {
			const $toggle = this.$overlay.find(
				'.wcf-icp-rail .wcf-icp-total-toggle'
			);

			if ( ! $toggle.length ) {
				return;
			}

			const collapsed =
				window.matchMedia( NARROW ).matches &&
				'true' !== $toggle.attr( 'aria-expanded' );

			this.$overlay
				.find( '.wcf-icp-rail .wcf-icp-total-panel' )
				.prop( 'hidden', collapsed );
		},

		/**
		 * Offer a keypad only where every character a postcode may hold is on one.
		 *
		 * A numeric keypad carries no letters and no separators, so a country whose format allows
		 * either would be left unable to enter a valid postcode at all.
		 *
		 * @since x.x.x
		 * @param {Object} $field Postcode field.
		 */
		setPostcodeKeyboard( $field ) {
			const numeric =
				numericPostcodes().indexOf( this.countryOf( $field ) ) > -1;

			// Removed rather than set to text: absent is already the ordinary keyboard.
			$field.attr( 'inputmode', numeric ? 'numeric' : null );
		},

		/**
		 * Set the keypad on every postcode field the popup holds.
		 *
		 * @since x.x.x
		 */
		setPostcodeKeyboards() {
			this.$overlay
				.find( '.form-row.validate-postcode' )
				.each( ( index, row ) => {
					this.setPostcodeKeyboard(
						$( row )
							.find( 'input' )
							.not( '[type="hidden"]' )
							.first()
					);
				} );
		},

		/**
		 * Put one row into or out of its error state.
		 *
		 * @since x.x.x
		 * @param {Object} $row Row to mark.
		 * @return {Object|null} The field when the row fails, otherwise null.
		 */
		markRow( $row ) {
			const $field = $row
				.find( 'input, select, textarea' )
				.not( '[type="hidden"]' )
				.first();

			if ( ! $field.length ) {
				return null;
			}

			const failure = this.rowFailure( $row, $field );

			$row.toggleClass( 'woocommerce-invalid', !! failure );
			$field.attr( 'aria-invalid', failure ? 'true' : null );
			this.setFieldError(
				$field,
				failure ? i18nf( failure, this.labelOf( $field ) ) : ''
			);

			return failure ? $field : null;
		},

		/**
		 * Drop a rejected coupon's mark once the shopper edits the code.
		 *
		 * @since x.x.x
		 * @param {Object} event Input event.
		 */
		onCouponEdit( event ) {
			$( event.target )
				.removeClass( 'has-error' )
				.removeAttr( 'aria-invalid' )
				.removeAttr( 'aria-describedby' )
				.closest( '.form-row' )
				.find( '.coupon-error-notice' )
				.remove();
		},

		/**
		 * Test a field as the shopper leaves it, rather than holding every problem until they press on.
		 *
		 * @since x.x.x
		 * @param {Object} event Focusout event.
		 */
		onFieldBlur( event ) {
			const $row = $( event.target ).closest( '.form-row' );

			// submit_error() blurs every field on the form, so rows WooCommerce keeps hidden would
			// be marked before the shopper has ever seen them — the same rows validateStep() skips.
			if ( ! $row.is( ':visible' ) ) {
				return;
			}

			// The postcode's rule is the server's, so leaving the field is what goes and asks for it.
			if ( $row.hasClass( 'validate-postcode' ) ) {
				this.checkPostcode( $( event.target ) );
			}

			// A server rejection outlives the client rules, which think a non-empty field is fine.
			if ( ! $row.hasClass( 'wcf-icp-invalid' ) ) {
				this.markRow( $row );
			}
		},

		/**
		 * Re-test a row the shopper is correcting, so its message goes the moment it is satisfied.
		 *
		 * @since x.x.x
		 * @param {Object} event Input or change event.
		 */
		onErrorRowEdit( event ) {
			this.markRow( $( event.target ).closest( '.form-row' ) );
		},

		/**
		 * Put a message under one field, or take it away.
		 *
		 * @since x.x.x
		 * @param {Object} $field  Field the message belongs to.
		 * @param {string} message Message text; an empty string removes it.
		 */
		setFieldError( $field, message ) {
			const id = $field.attr( 'id' );
			const errorId = id ? id + '-wcf-icp-error' : '';
			const $row = $field.closest( '.form-row' );
			let $note = $row.find( '.wcf-icp-field-error' );

			if ( ! message ) {
				$note.remove();
				$row.removeClass( 'wcf-icp-has-error' );
				$field.removeAttr( 'aria-describedby' );
				return;
			}

			if ( ! $note.length ) {
				$note = $( '<p class="wcf-icp-field-error" />' )
					.attr( 'id', errorId )
					.appendTo( $row );
			}

			// The row is tagged by us as well: checkout.js strips woocommerce-invalid the moment the
			// shopper types, which would stop the row being watched before its message is re-tested.
			$row.addClass( 'wcf-icp-has-error' );

			$field.attr( 'aria-describedby', errorId );
			$note.text( message );

			// checkout.js points the attribute at its own copy, and its pass can run after this one.
			window.setTimeout( () => {
				if ( $row.find( '.wcf-icp-field-error' ).length ) {
					$field.attr( 'aria-describedby', errorId );
				}
			}, 0 );
		},

		/**
		 * Show one or more messages inside the dialog.
		 *
		 * @param {string|Array} message Message, or the list of messages, to show.
		 */
		showNotice( message ) {
			const messages = Array.isArray( message ) ? message : [ message ];

			this.$overlay
				.find( '.wcf-icp-notices' )
				.empty()
				.append(
					messages.map(
						( text ) =>
							$( '<div class="wcf-icp-notice" />' ).text(
								text
							)[ 0 ]
					)
				);
		},

		/**
		 * Watch the page under the overlay for errors PayPal Payments writes there while the dialog is open.
		 *
		 * @since x.x.x
		 */
		watchPageNotices() {
			if ( this.pageNoticeObserver ) {
				this.pageNoticeObserver.disconnect();
				this.pageNoticeObserver = null;
			}

			if ( ! window.MutationObserver ) {
				return;
			}

			// The body, not the notice wrappers: SDK v6 falls back to .woocommerce or the body when a page has none.
			this.pageNoticeObserver = new window.MutationObserver(
				this.adoptPageNotices.bind( this )
			);

			this.pageNoticeObserver.observe( document.body, {
				childList: true,
				subtree: true,
			} );
		},

		/**
		 * Show error lines added behind the overlay in the dialog's own message region.
		 *
		 * @since x.x.x
		 * @param {MutationRecord[]} records Changes since the last call.
		 */
		adoptPageNotices( records ) {
			if ( ! this.$overlay ) {
				return;
			}

			const overlay = this.$overlay[ 0 ];
			const lines = new Set();

			// Only added nodes, so errors the page already showed stay put, and lines added to an old list still count.
			records.forEach( ( record ) =>
				record.addedNodes.forEach( ( node ) => {
					if ( 1 !== node.nodeType || overlay.contains( node ) ) {
						return;
					}

					if ( node.matches( 'ul.woocommerce-error' ) ) {
						$( node )
							.children( 'li' )
							.each( ( i, li ) => lines.add( li ) );
					} else if ( node.matches( 'ul.woocommerce-error > li' ) ) {
						lines.add( node );
					}
				} )
			);

			// Checked after the cheap scan: this runs on every change on the page, including each totals refresh.
			if ( ! lines.size ) {
				return;
			}

			// Only PayPal's: nothing else should be lifted out of the page and into the checkout.
			const method = String(
				this.$overlay
					.find( 'input[name="payment_method"]:checked' )
					.val() || ''
			);

			if ( 0 !== method.indexOf( 'ppcp-' ) ) {
				return;
			}

			const messages = [];

			lines.forEach( ( li ) => {
				const text = $.trim( $( li ).text() );
				const list = li.parentNode;

				if ( text ) {
					messages.push( text );
				}

				$( li ).remove();

				if ( list && ! $( list ).children().length ) {
					$( list ).remove();
				}
			} );

			if ( ! messages.length ) {
				return;
			}

			this.showNotice( messages );

			this.$overlay
				.find( '.wcf-icp-flow, .wcf-icp-dialog' )
				.add( this.$overlay )
				.scrollTop( 0 );
		},

		/**
		 * Clear the dialog's message region.
		 */
		clearNotice() {
			this.$overlay.find( '.wcf-icp-notices' ).empty();

			// A refresh can hang a fresh summary on the form, which belongs to no step either.
			this.$overlay.find( '.woocommerce-NoticeGroup-checkout' ).remove();
		},

		/**
		 * Toggle the button's loading state.
		 *
		 * @param {Object}  $button   Button element.
		 * @param {boolean} isLoading Whether the request is in flight.
		 */
		setLoading( $button, isLoading ) {
			this.loading = isLoading;

			// Clear both the live lookup and the captured node, so a theme re-render can't reinsert the
			// original with its spinner still spinning; match on the class to skip variation-disabled ones.
			const $targets = isLoading
				? $button
				: $( '.wcf-icp-buy-now.wcf-icp-loading' ).add( $button );

			// Modern Cart binds its add-to-cart to single_add_to_cart_button, which ours carries, and clears its
			// busy class only on success — a failed request leaves our button spinning with the label hidden.
			$targets
				.removeClass(
					'moderncart-loading is-moderncart-loading loading'
				)
				.toggleClass( 'wcf-icp-loading', isLoading )
				.prop( 'disabled', isLoading );
		},

		/**
		 * Is WooCommerce placing the order right now?
		 *
		 * checkout.js marks form.checkout `processing` during wc-ajax=checkout and prepends any decline
		 * message into that node, which close() would empty.
		 *
		 * @return {boolean} Whether a submit is in flight.
		 */
		isProcessing() {
			return (
				!! this.$overlay &&
				this.$overlay.find( 'form.checkout' ).hasClass( 'processing' )
			);
		},

		/**
		 * Watch the class isProcessing() reads, so the button answers whoever sets it.
		 *
		 * checkout.js adds `processing` after its own validation and the offer's veto, and takes it off
		 * again on a decline — an event of our own would have to guess at all three.
		 */
		watchSubmitState() {
			const form = this.$overlay.find( 'form.checkout' ).get( 0 );

			if ( ! form || ! window.MutationObserver ) {
				return;
			}

			// A rebuild without a close in between would otherwise leave the previous one watching.
			if ( this.submitObserver ) {
				this.submitObserver.disconnect();
			}

			this.submitObserver = new window.MutationObserver(
				this.syncSubmitState.bind( this )
			);
			this.submitObserver.observe( form, {
				attributes: true,
				attributeFilter: [ 'class' ],
			} );
		},

		/**
		 * Put the pressed button into its waiting state, and take it back out on a decline.
		 *
		 * WooCommerce's own spinner is centred on the whole form, which on a long step is off screen,
		 * and it leaves the button reading Place Order and genuinely pressable.
		 */
		syncSubmitState() {
			const $place = this.$overlay.find( PLACE_ORDER );

			if ( ! $place.length ) {
				return;
			}

			const busy = this.isProcessing();
			const idle = $place.data( 'wcfIcpIdle' );

			// Only the transitions are ours. Writing `disabled` on every class change would re-enable
			// the button S1 switches off when no gateway can take payment.
			if ( busy === !! idle ) {
				return;
			}

			const isInput = $place.is( 'input' );

			if ( busy ) {
				$place.data( 'wcfIcpIdle', {
					label: isInput ? $place.val() : $place.html(),
					disabled: !! $place.prop( 'disabled' ),
				} );

				if ( isInput ) {
					$place.val( i18n( 'placingOrder' ) );
				} else {
					$place.text( i18n( 'placingOrder' ) );
				}
			} else {
				if ( isInput ) {
					$place.val( idle.label );
				} else {
					$place.html( idle.label );
				}

				$place.removeData( 'wcfIcpIdle' );
			}

			$place
				.toggleClass( 'wcf-icp-is-placing', busy )
				// Whatever the button was before the submit is what it goes back to.
				.prop( 'disabled', busy ? true : idle.disabled )
				.attr( 'aria-busy', busy ? 'true' : null );
		},

		/**
		 * Is the Checkout Offer interrupting the submit?
		 *
		 * The offer returns false from checkout_place_order before checkout.js marks the form
		 * `processing`, so isProcessing() cannot see it, and the modal is printed outside the overlay —
		 * closing underneath it would leave it standing over an emptied form.
		 *
		 * @return {boolean} Whether the offer modal is on screen.
		 */
		offerIsOpen() {
			return $( 'html' ).hasClass( 'wcf-pre-checkout-offer-open' );
		},

		/**
		 * Close on the ✕ or a click on the backdrop, unless the order is being placed or the offer is up.
		 *
		 * @param {Object} event Click event.
		 */
		onDismiss( event ) {
			if (
				$( event.target ).is( '.wcf-icp-overlay' ) ||
				$( event.target ).closest( '.wcf-icp-close' ).length
			) {
				event.preventDefault();

				if ( ! this.isProcessing() && ! this.offerIsOpen() ) {
					this.close();
				}
			}
		},

		/**
		 * Escape closes unless the order is being placed or the offer is up; Tab is trapped inside
		 * whichever of the two is on top.
		 *
		 * @param {Object} event Keydown event.
		 */
		onKeydown( event ) {
			if ( ! this.$overlay ) {
				return;
			}

			if ( 'Escape' === event.key ) {
				if ( ! this.isProcessing() && ! this.offerIsOpen() ) {
					this.close();
				}
				return;
			}

			if ( 'Tab' !== event.key ) {
				return;
			}

			const $offer = this.offerIsOpen()
				? $( '.wcf-pre-checkout-offer-wrapper.open' )
				: $();

			// Inactive steps are inert but still :visible, and focusing an inert node is a no-op.
			const $items = ( $offer.length ? $offer : this.$overlay )
				.find( FOCUSABLE )
				.filter( ':visible' )
				.filter( ( index, el ) => ! el.closest( '[inert]' ) );

			if ( ! $items.length ) {
				return;
			}

			const first = $items.get( 0 );
			const last = $items.get( $items.length - 1 );
			const active = first.ownerDocument.activeElement;

			// The offer is a sibling of the overlay, so Tab walks straight out of it into the checkout
			// behind and never reaches the wrap points below. Pull focus back in instead.
			if ( $offer.length && ! $offer[ 0 ].contains( active ) ) {
				event.preventDefault();
				( event.shiftKey ? last : first ).focus();
				return;
			}

			if ( event.shiftKey && active === first ) {
				event.preventDefault();
				last.focus();
			} else if ( ! event.shiftKey && active === last ) {
				event.preventDefault();
				first.focus();
			}
		},

		/**
		 * Focus the first field in the dialog.
		 */
		focusFirst() {
			if ( ! this.$overlay ) {
				return;
			}

			// Scope to the active step; the rail comes first in the DOM, so an unscoped search would
			// land on the coupon link instead of the first field.
			const $pane = this.$overlay.find( '.wcf-icp-step.is-active' );

			( $pane.length ? $pane : this.$overlay )
				.find( FOCUSABLE )
				.filter( ':visible' )
				.filter( ( index, el ) => ! el.closest( '[inert]' ) )
				.first()
				.trigger( 'focus' );
		},

		/**
		 * Take cart.js's remove-coupon handler off the page for as long as the dialog is up.
		 *
		 * cart.js delegates that link on `document` and its handler reloads the page whenever there
		 * is no cart form — which there never is on a product page, so removing a coupon inside the
		 * popup would navigate away from it. checkout.js delegates the same link on `document.body`,
		 * closer to the link, so the handler the popup actually wants still runs.
		 *
		 * jQuery cannot remove one plugin's delegated handler by name, so the handlers are copied out
		 * of the event store first and put back by restoreCartCouponHandlers() on close. That keeps
		 * the blast radius — every delegated click handler for that selector, whoever registered it —
		 * to the window the dialog is open, instead of the rest of the page's life.
		 */
		suspendCartCouponHandlers() {
			if ( this.suspendedCouponHandlers ) {
				return;
			}

			const store = $._data ? $._data( document, 'events' ) : null;
			const clicks = store && store.click ? store.click : [];

			// $.grep returns a new array, which matters: off() below mutates the live one.
			this.suspendedCouponHandlers = $.grep(
				clicks,
				( entry ) => COUPON_LINK === entry.selector
			);

			$( document ).off( 'click', COUPON_LINK );
		},

		/**
		 * Put back whatever suspendCartCouponHandlers() removed.
		 */
		restoreCartCouponHandlers() {
			if ( ! this.suspendedCouponHandlers ) {
				return;
			}

			this.suspendedCouponHandlers.forEach( ( entry ) => {
				$( document ).on(
					entry.namespace ? 'click.' + entry.namespace : 'click',
					COUPON_LINK,
					entry.data,
					entry.handler
				);
			} );

			this.suspendedCouponHandlers = null;
		},

		/**
		 * Tear the dialog down and hand focus back to the button that opened it.
		 *
		 * @param {boolean} restoreCart Whether to hand the pre-popup cart back. True for a
		 *                              shopper dismissal; false when clearing a previous
		 *                              overlay while opening a new one.
		 */
		close( restoreCart = true ) {
			if ( ! this.$overlay ) {
				return;
			}

			// The form goes back to the page still bound; the observer would outlive the popup.
			if ( this.submitObserver ) {
				this.submitObserver.disconnect();
				this.submitObserver = null;
			}

			if ( this.pageNoticeObserver ) {
				this.pageNoticeObserver.disconnect();
				this.pageNoticeObserver = null;
			}

			this.restoreCartCouponHandlers();

			// Buy Now emptied the cart into this popup; a dismissal must hand the original back.
			if ( restoreCart && this.stepId ) {
				this.restoreXhr = $.ajax( {
					type: 'POST',
					url: this.endpoint( 'wcf_instant_close' ),
				} ).always( () => {
					// The cart changed twice behind the theme's back — on open and again here.
					$( document.body ).trigger( 'wc_fragment_refresh' );
				} );
				this.stepId = 0;
			}

			// Return the pre-bound forms to the page, not destroy them — WooCommerce and gateway
			// handlers on these nodes must survive a re-open.
			const $bound = this.$overlay.find(
				'form.checkout[data-wcf-icp-form], form.checkout_coupon[data-wcf-icp-coupon-form]'
			);

			// Emptying the shell below discards everything typed; save it so a re-open isn't blank.
			// Visible fields only: a re-open mints its own nonce and markers, so never carry those back.
			if ( restoreCart ) {
				this.savedFields = $bound
					.find( ':input' )
					.not(
						'[type="hidden"], [type="password"], [name^="woocommerce-"]'
					)
					.serializeArray();
				this.savedStep = this.step;
			}

			if ( $bound.length ) {
				$bound
					.empty()
					.attr( 'hidden', 'hidden' )
					.appendTo( document.body );
			}

			this.$overlay.remove();
			this.$overlay = null;
			this.step = '';
			this.steps = [];
			this.fields = {};
			this.postcodes = {};
			this.postcodeRequests = {};
			this.layout = null;
			this.config = null;
			this.ctx = null;

			// Popup closed, nothing spins: clear any Buy Now a re-render left marked loading.
			if ( ! this.loading ) {
				this.setLoading(
					$( '.wcf-icp-buy-now.wcf-icp-loading' ),
					false
				);
			}

			$( document.body )
				.removeClass( 'wcf-icp-open' )
				.trigger( 'wcf_instant_checkout_closed' );

			if ( this.$opener ) {
				// The opener may have been re-rendered away; fall back to a live Buy Now for focus.
				const opener = this.$opener[ 0 ];

				( document.contains( opener )
					? this.$opener
					: $( '.wcf-icp-buy-now' ).first()
				).trigger( 'focus' );
			}
		},
	};

	$( function () {
		InstantCheckout.init();
	} );
} )( jQuery );
