<?php
/**
 * Instant Checkout AJAX endpoints.
 *
 * Registered on wc-ajax, not a custom REST namespace, which is excluded from is_request('frontend') and would have no cart or session.
 *
 * @package cartflows-pro
 * @since 3.1.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Handles the popup's server calls.
 *
 * @since 3.1.4
 */
class Cartflows_Pro_Instant_Checkout_Ajax {

	/**
	 * Ceiling on companions accepted from one request, so a crafted list cannot queue product lookups.
	 */
	const FBT_MAX_ITEMS = 50;

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Cart contents captured before the popup took the cart over.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	private $cart_backup = array();

	/**
	 * Coupon codes captured with the cart contents.
	 *
	 * @var array<int, string>
	 */
	private $coupon_backup = array();

	/**
	 * The source product's own cart line ID — its variation when the product is variable.
	 *
	 * @var int
	 */
	private $main_line_id = 0;

	/**
	 * Companions the Frequently Bought Together widget could not add, for the dialog to report.
	 *
	 * @var array<int, array{id: int, name: string, reason: string}>
	 */
	private $fbt_dropped = array();

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wc_ajax_wcf_instant_open', array( $this, 'open' ) );
		add_action( 'wc_ajax_wcf_instant_close', array( $this, 'close' ) );
		add_action( 'wc_ajax_wcf_instant_postcode', array( $this, 'postcode' ) );
	}

	/**
	 * Open the popup: add the chosen product, then return the rendered checkout.
	 *
	 * @return void
	 */
	public function open() {

		$this->require_same_origin();

		// Only open is gated; close must still hand back the cart of a popup that was open when the licence lapsed.
		if ( ! cartflows_pro_is_active_license() ) {
			wp_send_json_error( array( 'message' => __( 'This product is not available for Instant Checkout.', 'cartflows-pro' ) ) );
		}

		$request = $this->get_validated_request();

		if ( empty( $request['step_id'] ) ) {
			wp_send_json_error( array( 'message' => __( 'This product is not available for Instant Checkout.', 'cartflows-pro' ) ) );
		}

		$step_id = $request['step_id'];
		$added   = $this->add_product_to_cart( $request['product_id'] );

		if ( is_wp_error( $added ) ) {
			wp_send_json_error( array( 'message' => $added->get_error_message() ) );
		}

		// The hooked pre-check-add bails under wc-ajax; add them here so default-checked bumps are in the cart when the popup opens.
		if ( class_exists( 'Cartflows_Pro_Order_Bump_Product' ) ) {
			Cartflows_Pro_Order_Bump_Product::get_instance()->add_pre_checked_order_bumps_to_cart( $step_id );
		}

		// Resolved once and handed to both the renderer and the client, so markup and behaviour agree.
		$layout = Cartflows_Pro_Instant_Checkout_Layouts::get_instance()->get_layout_for_step( $step_id );
		$html   = Cartflows_Pro_Instant_Checkout_Render::get_instance()->render( $step_id, $layout );

		if ( '' === $html ) {
			// The popup never opens on this path either — hand the cart back, as a rejected add does.
			$this->restore_cart( $this->cart_backup, $this->coupon_backup );

			wp_send_json_error( array( 'message' => __( 'The checkout could not be loaded. Please try again.', 'cartflows-pro' ) ) );
		}

		// Kept for the popup session: dismissing calls wcf_instant_close, which hands this exact cart back, coupons included.
		Cartflows_Pro_Instant_Checkout::set_session_backup( $this->cart_backup, $this->coupon_backup );

		// Carried in the session so the later wc-ajax=checkout order attributes back to this popup.
		Cartflows_Pro_Instant_Checkout::set_session_step( $step_id );

		// Bump nonce rides with the popup, not the full-page-cached product page which would serve it stale. See render_button().
		//
		// checkout.js's own nonces have the same problem: they come from wc_checkout_params, which *is* localized on that page, so a
		// cached copy hands every visitor the nonces minted when it was generated. Once those expire the in-dialog totals refresh and
		// coupon field start failing. Minted here and overwritten client-side, they stay as fresh as the markup they act on.
		wp_send_json_success(
			array_merge(
				array(
					'html'            => $html,
					'step_id'         => $step_id,
					'fbt_dropped'     => $this->fbt_dropped,
					'ajax_url'        => admin_url( 'admin-ajax.php' ),
					// Drives .wcf-icp-fields-custom, which gates the Field Editor's column widths. CartFlows emits
					// wcf-column-* classes with the editor off too, so the popup must not act on them then.
					'fields_custom'   => function_exists( '_is_wcf_meta_custom_checkout' ) && _is_wcf_meta_custom_checkout( $step_id ),
					'bump_nonce'      => wp_create_nonce( 'wcf_bump_order_process' ),
					'qty_nonce'       => wp_create_nonce( 'wcf_update_order_bump_qty' ),
					'offer_nonces'    => array(
						'wcf_pre_checkout_offer_nonce' => wp_create_nonce( 'wcf_pre_checkout_offer' ),
						'wcf_pre_checkout_validate_form_nonce' => wp_create_nonce( 'wcf_pre_checkout_validate_form' ),
					),
					'checkout_nonces' => array(
						'update_order_review_nonce' => wp_create_nonce( 'update-order-review' ),
						'apply_coupon_nonce'        => wp_create_nonce( 'apply-coupon' ),
						'remove_coupon_nonce'       => wp_create_nonce( 'remove-coupon' ),
					),
				),
				$layout->get_client_config()
			)
		);
	}

	/**
	 * Close the popup: hand back the cart captured when it opened.
	 *
	 * Without this, dismissing leaves the shopper with only the Buy Now product — original cart and coupons gone.
	 *
	 * @return void
	 */
	public function close() {

		$this->require_same_origin();

		Cartflows_Pro_Instant_Checkout::restore_session_backup();

		// Dismissal ends the popup's ownership: a left-behind step_id keeps every render filter live on the store's own cart.
		Cartflows_Pro_Instant_Checkout::clear_session_state();

		wp_send_json_success();
	}

	/**
	 * Answer whether a postcode is valid for a country.
	 *
	 * WooCommerce has no client-side postcode rule, so a bad ZIP clears the step that owns it and is
	 * only caught at submit. Asking the server is the only way to get the same verdict submit will
	 * give: is_postcode() carries the per-country patterns and ends in a filter merchants can extend.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function postcode() {

		$this->require_same_origin();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Deliberate: see get_validated_request(). Reads two posted strings, touches no cart or session, and answers only true or false.
		$postcode = isset( $_POST['postcode'] ) ? wc_clean( wp_unslash( $_POST['postcode'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- As above.
		$country = isset( $_POST['country'] ) ? wc_clean( wp_unslash( $_POST['country'] ) ) : '';

		$postcode = is_string( $postcode ) ? $postcode : '';
		$country  = is_string( $country ) ? $country : '';

		// An empty box is the required check's business, not this one.
		$valid = '' === $postcode || WC_Validation::is_postcode( $postcode, $country );

		wp_send_json_success( array( 'valid' => $valid ) );
	}

	/**
	 * Validate the requested step and confirm it may be opened.
	 *
	 * The step must be the one this product resolves to, which also proves it is published, a checkout step, and on a feature-enabled funnel.
	 *
	 * @return array<string, int> Step and product IDs, both 0 when the request is not allowed.
	 */
	private function get_validated_request() {

		$denied = array(
			'step_id'    => 0,
			'product_id' => 0,
		);

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Deliberate: see render_button(). Product pages are cached, so a nonce cannot be embedded there. The request is constrained by resolve_step_id() below and only ever touches the caller's own session, matching core's nonce-free wc-ajax=add_to_cart.
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- As above.
		$step_id = isset( $_POST['step_id'] ) ? absint( $_POST['step_id'] ) : 0;

		if ( ! $product_id || ! $step_id ) {
			return $denied;
		}

		$product = wc_get_product( $product_id );

		if ( ! $product || ! Cartflows_Pro_Instant_Checkout::is_supported_product( $product ) ) {
			return $denied;
		}

		if ( Cartflows_Pro_Instant_Checkout::resolve_step_id( $product_id ) !== $step_id ) {
			return $denied;
		}

		return array(
			'step_id'    => $step_id,
			'product_id' => $product_id,
		);
	}

	/**
	 * Confirm a posted variation really belongs to the validated parent product.
	 *
	 * @param int        $product_id   Validated parent product ID.
	 * @param int|string $variation_id Posted variation ID.
	 * @return int Variation ID, or 0 when it is not a child of the parent.
	 */
	private function get_validated_variation_id( $product_id, $variation_id ) {

		$variation_id = absint( $variation_id );

		if ( ! $variation_id ) {
			return 0;
		}

		$product = wc_get_product( $product_id );

		if ( ! $product || ! in_array( $variation_id, array_map( 'absint', $product->get_children() ), true ) ) {
			return 0;
		}

		return $variation_id;
	}

	/**
	 * Stop a request that did not come from a page on this site.
	 *
	 * @since x.x.x
	 * @return void
	 */
	private function require_same_origin() {

		if ( ! $this->is_same_origin_request() ) {
			wp_send_json_error( array( 'message' => __( 'This request could not be verified.', 'cartflows-pro' ) ), 403 );
		}
	}

	/**
	 * Reject cross-site requests.
	 *
	 * No nonce (full-page-cached product page would serve it stale), so check origin: Sec-Fetch-Site can't be spoofed by page script and Origin rides cross-site POSTs. `same-site` is rejected (trusts subdomains).
	 * Referer from $_SERVER is the pre-2019 fallback — wp_get_referer()/wp_get_raw_referer() prefer $_REQUEST['_wp_http_referer'], which a cross-site form can set to this host.
	 *
	 * @return bool
	 */
	private function is_same_origin_request() {

		$fetch_site = isset( $_SERVER['HTTP_SEC_FETCH_SITE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_SEC_FETCH_SITE'] ) ) : '';

		if ( '' !== $fetch_site ) {
			return in_array( $fetch_site, array( 'same-origin', 'none' ), true );
		}

		$origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) ) : '';

		if ( '' !== $origin ) {
			return self::is_own_host( $origin );
		}

		$referer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';

		return '' !== $referer && self::is_own_host( $referer );
	}

	/**
	 * Does a URL point at this site's own host?
	 *
	 * Host only, as wp_validate_redirect() compares — scheme is left out because a proxied store can serve https while home_url() records http.
	 *
	 * @param string $url URL to compare.
	 * @return bool
	 */
	private static function is_own_host( $url ) {

		$host = wp_parse_url( $url, PHP_URL_HOST );

		if ( ! is_string( $host ) ) {
			return false;
		}

		return strtolower( $host ) === strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	}

	/**
	 * Add the validated product to a cart holding only this purchase.
	 *
	 * The product form is forwarded to WC_Form_Handler::add_to_cart_action(), which dispatches by type via woocommerce_add_to_cart_handler — so every product type works without type-specific code.
	 *
	 * @param int $product_id Server-validated product ID.
	 * @return true|WP_Error
	 */
	private function add_product_to_cart( $product_id ) {

		// Cart is guaranteed: wc_ajax dispatches from template_redirect where is_request('frontend') already ran wc_load_cart() (REST is excluded, hence not a REST route).
		$fields = $this->get_product_form_fields();

		if ( empty( $fields['add-to-cart'] ) ) {
			return new WP_Error( 'wcf_instant_bad_request', __( 'The product could not be identified.', 'cartflows-pro' ) );
		}

		// Force the validated product: add_to_cart_action() reads add-to-cart unchecked, so the client's value could validate one product and buy another, bypassing is_supported_product() and the opt-in.
		$fields['add-to-cart'] = $product_id;
		$fields['product_id']  = $product_id;

		if ( isset( $fields['variation_id'] ) ) {
			$fields['variation_id'] = $this->get_validated_variation_id( $product_id, is_scalar( $fields['variation_id'] ) ? (string) $fields['variation_id'] : '' );
		}

		// The source product's own line ID, which FBT needs to tell the main row from a companion. Taken
		// from the validated field, not from the cart afterwards: bundles add more than one line.
		$validated_variation = isset( $fields['variation_id'] ) && is_scalar( $fields['variation_id'] ) ? absint( $fields['variation_id'] ) : 0;
		$this->main_line_id  = $validated_variation > 0 ? $validated_variation : $product_id;

		// A leftover backup means the last popup was abandoned without close firing; restore it first so this open snapshots the real cart, not the abandoned popup's.
		Cartflows_Pro_Instant_Checkout::restore_session_backup();

		// A cart parked by an earlier purchase is still the shopper's, so take it back before snapshotting — otherwise this
		// popup snapshots a cart without it and the park is overwritten with the poorer copy.
		Cartflows_Pro_Instant_Checkout::consume_parked_cart();

		// Buy Now owns the cart, but snapshot first so a rejected add can hand it back — empty_cart() clears applied_coupons too.
		$this->cart_backup   = WC()->cart->get_cart();
		$this->coupon_backup = WC()->cart->get_applied_coupons();

		WC()->cart->empty_cart( false );

		// add_to_cart_action() redirects and exits on success; neutralise both routes, including CartFlows' priority-99 handler into the funnel.
		add_filter( 'woocommerce_add_to_cart_redirect', '__return_false', PHP_INT_MAX );
		add_filter( 'option_woocommerce_cart_redirect_after_add', array( $this, 'disable_cart_redirect' ), PHP_INT_MAX );

		$request_backup = $_REQUEST; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Snapshot restored below.
		$post_backup    = $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Snapshot restored below.

		$_REQUEST = $fields;
		$_POST    = $fields;

		WC_Form_Handler::add_to_cart_action( false );

		$_REQUEST = $request_backup;
		$_POST    = $post_backup;

		remove_filter( 'woocommerce_add_to_cart_redirect', '__return_false', PHP_INT_MAX );
		remove_filter( 'option_woocommerce_cart_redirect_after_add', array( $this, 'disable_cart_redirect' ), PHP_INT_MAX );

		if ( WC()->cart->is_empty() ) {
			$this->restore_cart( $this->cart_backup, $this->coupon_backup );

			return new WP_Error( 'wcf_instant_not_added', $this->get_first_error_notice() );
		}

		// Before the coupons below, so a coupon restricted to a companion still validates, and before the
		// wc_clear_notices() after them, so "added to your cart" does not surface inside the dialog.
		$this->add_fbt_extras( $product_id );

		// empty_cart() dropped the coupons; auto-apply plugins run once per request so they won't re-add before render, but the checkout request will — charging a total the popup never showed. Re-apply here.
		foreach ( $this->coupon_backup as $coupon_code ) {
			WC()->cart->apply_coupon( $coupon_code );
		}

		// Clear WC's "added to your cart" notice, or the checkout render prints it inside the dialog with a View cart button leading out of the popup.
		wc_clear_notices();

		return true;
	}

	/**
	 * Hand a snapshotted cart back after a rejected add.
	 *
	 * The popup never opens here, so restore the pre-Buy Now cart. calculate_totals() re-persists it — WC saves from woocommerce_after_calculate_totals and empty_cart() destroyed the stored copy.
	 *
	 * @param array<string, mixed> $contents Cart contents captured before emptying.
	 * @param array<int, string>   $coupons  Coupon codes captured before emptying.
	 * @return void
	 */
	private function restore_cart( $contents, $coupons ) {

		// No early return on an empty snapshot: the render-failure caller runs with the popup's own
		// products in the cart, so "nothing to restore" still means emptying it.
		WC()->cart->set_cart_contents( $contents );
		WC()->cart->set_applied_coupons( $coupons );
		WC()->cart->calculate_totals();

		// On the render-failure caller the add and the pre-checked bumps have both already fired
		// woocommerce_add_to_cart, so WC has written the popup-only cart to user meta and nothing above
		// updates it. On the rejected-add caller nothing was added, and this is a no-change rewrite.
		Cartflows_Pro_Instant_Checkout::sync_persistent_cart();
	}

	/**
	 * Force the post-add cart redirect off for this request.
	 *
	 * @return string
	 */
	public function disable_cart_redirect() {
		return 'no';
	}

	/**
	 * Companions posted alongside the product form by the Frequently Bought Together widget.
	 *
	 * A sibling of product_form, never inside it: that array is replayed into the superglobals for
	 * WC's add-to-cart handler, where these keys could collide with a product add-on's own fields.
	 *
	 * @return array<int, array{id: int, qty: int}>
	 */
	private function get_fbt_items() {

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- See get_validated_request() for why this endpoint carries no nonce.
		$posted = isset( $_POST['fbt']['items'] ) ? wc_clean( wp_unslash( $_POST['fbt']['items'] ) ) : array();

		if ( ! is_array( $posted ) ) {
			return array();
		}

		$items = array();
		$seen  = array();

		foreach ( $posted as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['id'] ) || ! is_scalar( $item['id'] ) ) {
				continue;
			}

			$id = absint( $item['id'] );

			// The main product is already in the cart; posted back as a companion it skips every rule in
			// build_add_queue() and merges into that line, setting a quantity the product form never sent.
			if ( $id <= 0 || $id === $this->main_line_id || isset( $seen[ $id ] ) ) {
				continue;
			}

			$seen[ $id ] = true;

			$items[] = array(
				'id'  => $id,
				'qty' => isset( $item['qty'] ) && is_scalar( $item['qty'] ) ? max( 1, absint( $item['qty'] ) ) : 1,
			);

			// The widget caps its own list; this only stops a crafted request queueing product lookups.
			if ( count( $items ) >= self::FBT_MAX_ITEMS ) {
				break;
			}
		}

		return $items;
	}

	/**
	 * Add the widget's companions alongside the product the popup was opened for.
	 *
	 * Must run while the popup owns the cart and before set_session_backup() snapshots it — that
	 * snapshot is what makes these lines popup-owned, so they are handed back on abandon with no
	 * tracking of their own. Moved after it, track_popup_cart_item() stops being a no-op and the
	 * quantities are subtracted twice.
	 *
	 * Free owns every rule about which companion may be added; this only decides what to do with the
	 * ones it refuses, which is to drop them and tell the shopper rather than block the sale.
	 *
	 * @param int $source_id The validated source product ID.
	 * @return void
	 */
	private function add_fbt_extras( $source_id ) {

		$items = $this->get_fbt_items();

		if ( empty( $items ) ) {
			return;
		}

		// Degrade rather than fatal when Pro runs against a free build without the shared builder.
		if ( ! class_exists( 'Cartflows_Fbt_Frontend' ) || ! method_exists( 'Cartflows_Fbt_Frontend', 'build_add_queue' ) ) {
			return;
		}

		// Always separate lines: the popup has no way to remove one, so the bundle key's cascade has no
		// trigger here except a replace-main order bump, where it would delete companions unasked.
		//
		// That bump (pre-checked + is_replace, non-store-checkout only) removes the Buy Now product and
		// leaves the companions, deliberately: the shopper ticked them, and nothing here may un-tick for
		// them. Their _wcf_fbt_parent_id stays too — it marks a line the widget sold, which is still true,
		// and the revenue query never asks whether the parent is in the order.
		$resolved = Cartflows_Fbt_Frontend::get_instance()->build_add_queue( $items, $this->main_line_id, $source_id, '' );

		foreach ( $resolved['queue'] as $entry ) {
			$added = WC()->cart->add_to_cart(
				$entry['product_id'],
				$entry['quantity'],
				$entry['variation_id'],
				$entry['attributes'],
				$entry['cart_item_data']
			);

			if ( $added ) {
				continue;
			}

			$refused = wc_get_product( $entry['variation_id'] > 0 ? $entry['variation_id'] : $entry['product_id'] );

			$resolved['rejected'][] = array(
				'id'     => (int) $entry['product_id'],
				'name'   => $refused instanceof WC_Product ? $refused->get_name() : '',
				'reason' => $this->get_last_error_notice(),
			);
		}

		$this->fbt_dropped = $this->configured_drops( $resolved['rejected'], $source_id );
	}

	/**
	 * Keep only the drops the shopper could have chosen.
	 *
	 * The open endpoint carries no nonce, so echoing a name for every ID a request names would
	 * enumerate the catalogue — drafts included, since wc_get_product() does not filter by status.
	 * A configured companion's name is already public in the widget's own markup.
	 *
	 * @param array<int, array{id: int, name: string, reason: string}> $dropped   Rejected companions.
	 * @param int                                                      $source_id The source product ID.
	 * @return array<int, array{id: int, name: string, reason: string}>
	 */
	private function configured_drops( $dropped, $source_id ) {

		if ( empty( $dropped ) || ! class_exists( 'Cartflows_Fbt' ) ) {
			return array();
		}

		$settings = Cartflows_Fbt::get_settings( $source_id );
		$allowed  = array_map( 'absint', $settings['product_ids'] );
		$kept     = array();

		foreach ( $dropped as $drop ) {
			$product = wc_get_product( $drop['id'] );
			$parent  = $product instanceof WC_Product_Variation ? (int) $product->get_parent_id() : (int) $drop['id'];

			if ( in_array( (int) $drop['id'], $allowed, true ) || in_array( $parent, $allowed, true ) ) {
				$kept[] = $drop;
			}
		}

		return $kept;
	}

	/**
	 * The product form's fields, minus the request plumbing.
	 *
	 * The superglobals are repopulated from this for WC and product-type extensions. Posted as a nested object, not a serialized string, so sanitising before parsing can't strip percent-encoded octets; forwarded whole after wc_clean() rather than pattern-matched.
	 *
	 * @return array<string, mixed>
	 */
	private function get_product_form_fields() {

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- See get_validated_request() for why this endpoint carries no nonce.
		$posted = isset( $_POST['product_form'] ) ? wc_clean( wp_unslash( $_POST['product_form'] ) ) : array();

		if ( ! is_array( $posted ) ) {
			return array();
		}

		/**
		 * Request plumbing that must never reach add-to-cart handling.
		 *
		 * @since x.x.x
		 * @param array<string> $reserved Field names dropped from the forwarded product form.
		 */
		$reserved = apply_filters(
			'cartflows_pro_instant_checkout_reserved_form_fields',
			array( 'wc-ajax', 'action', '_wpnonce', '_wp_http_referer', 'woocommerce-process-checkout-nonce' )
		);

		$reserved = array_filter( (array) $reserved, 'is_string' );

		$fields = array();

		foreach ( $posted as $key => $value ) {

			// Everything else passes: a prefix allowlist silently dropped add-ons, subscription plans and per-item options. Safe — add_product_to_cart() forces add-to-cart/product_id and revalidates variation_id after this.
			if ( is_string( $key ) && ! in_array( $key, $reserved, true ) ) {
				$fields[ $key ] = $value;
			}
		}

		return $fields;
	}

	/**
	 * First WooCommerce error notice, used to report why an add-to-cart failed.
	 *
	 * @return string
	 */
	private function get_first_error_notice() {

		$notices = wc_get_notices( 'error' );
		wc_clear_notices();

		if ( ! empty( $notices ) && isset( $notices[0]['notice'] ) ) {
			return wp_strip_all_tags( (string) $notices[0]['notice'] );
		}

		return __( 'This product could not be added to the cart.', 'cartflows-pro' );
	}

	/**
	 * The newest queued error, for a failure inside a loop.
	 *
	 * Companions are added one at a time onto a queue that free's validators may already have written
	 * to, so the first notice can belong to an earlier product. The queue is left alone — the caller
	 * clears it once, after the coupons.
	 *
	 * @return string
	 */
	private function get_last_error_notice() {

		$notices = wc_get_notices( 'error' );
		$last    = empty( $notices ) ? array() : end( $notices );

		if ( isset( $last['notice'] ) ) {
			return wp_strip_all_tags( (string) $last['notice'] );
		}

		return __( 'This product could not be added to the cart.', 'cartflows-pro' );
	}
}
