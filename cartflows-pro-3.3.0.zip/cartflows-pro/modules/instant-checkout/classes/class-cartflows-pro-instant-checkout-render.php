<?php
/**
 * Instant Checkout renderer.
 *
 * Gives the request a checkout-step context and lets WC and CartFlows produce the checkout as on a funnel step. Nothing is reimplemented here.
 *
 * @package cartflows-pro
 * @since 3.1.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Builds the popup markup.
 *
 * @since 3.1.4
 */
class Cartflows_Pro_Instant_Checkout_Render {

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Post that was global before the context swap, restored afterwards.
	 *
	 * @var WP_Post|null
	 */
	private $previous_post = null;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Render the popup for a checkout step.
	 *
	 * @param int                                        $step_id Checkout step ID.
	 * @param Cartflows_Pro_Instant_Checkout_Layout|null $layout  Layout to render with. Resolved from the
	 *                                                        step when omitted; the AJAX endpoint passes
	 *                                                        the one it sends to the client so both agree.
	 * @return string Modal markup, or an empty string when the checkout could not be produced.
	 */
	public function render( $step_id, $layout = null ) {

		$step_id = absint( $step_id );

		if ( ! $this->enter_context( $step_id ) ) {
			return '';
		}

		$checkout = $this->get_checkout_html();

		$this->exit_context();

		if ( '' === $checkout ) {
			return '';
		}

		// Rendered on a product page, so the step page that starts the flow session never loads; without it offer steps meet the order with "Your session is expired". Same session a checkout step opens — see Cartflows_Pro_Frontend::set_flow_session().
		$flow_id = absint( get_post_meta( $step_id, 'wcf-flow-id', true ) );

		if ( $flow_id ) {
			wcf_pro()->session->set_session(
				$flow_id,
				array(
					'flow_id' => $flow_id,
					'steps'   => get_post_meta( $flow_id, 'wcf-steps', true ),
				)
			);
		}

		if ( ! $layout instanceof Cartflows_Pro_Instant_Checkout_Layout ) {
			$layout = Cartflows_Pro_Instant_Checkout_Layouts::get_instance()->get_layout_for_step( $step_id );
		}

		return $this->render_template( $layout, $checkout, $flow_id );
	}

	/**
	 * Wrap a rendered checkout in a layout's template.
	 *
	 * Runs after the checkout is produced, so tests can exercise a template with a stub form and no WC session.
	 *
	 * @param Cartflows_Pro_Instant_Checkout_Layout $layout   Layout whose template to render.
	 * @param string                                $checkout Rendered checkout markup.
	 * @param int                                   $flow_id  Flow the popup belongs to; 0 skips the funnel's own settings.
	 * @return string
	 */
	public function render_template( Cartflows_Pro_Instant_Checkout_Layout $layout, $checkout, $flow_id = 0 ) {

		// A third-party layout with a missing file must not blank the popup: fall back to the default layout wholesale so template and steps stay consistent.
		if ( ! is_readable( $layout->get_template_path() ) ) {
			$layout = Cartflows_Pro_Instant_Checkout_Layouts::get_instance()->get_layout( '' );
		}

		$steps    = $layout->get_steps();
		$initials = self::get_store_initials();
		$logo     = self::get_store_logo( absint( $flow_id ) );
		$cart     = self::get_cart_summary();
		$template = $layout->get_template_path();

		ob_start();
		include $template;
		return (string) ob_get_clean();
	}

	/**
	 * The cart for a layout's summary: line items, the bar's figures and the totals behind it.
	 *
	 * @return array{items_html: string, lead_html: string, rows_html: string}
	 */
	private static function get_cart_summary() {

		return array(
			'items_html' => Cartflows_Pro_Instant_Checkout::render_strip_items(),
			'lead_html'  => Cartflows_Pro_Instant_Checkout::render_total_lead(),
			'rows_html'  => Cartflows_Pro_Instant_Checkout::render_total_rows(),
		);
	}

	/**
	 * The identity mark's logo: the funnel's own upload, else the theme's Site Logo.
	 *
	 * Empty when neither is set, which is the template's cue to fall back to the store initials.
	 *
	 * @param int $flow_id Flow the popup belongs to.
	 * @return string
	 */
	private static function get_store_logo( $flow_id ) {

		$custom = $flow_id ? wcf()->options->get_flow_meta_value( $flow_id, Cartflows_Pro_Instant_Checkout::LOGO_META, '' ) : '';

		if ( is_string( $custom ) && '' !== trim( $custom ) ) {
			$custom = sprintf(
				'<img src="%1$s" alt="%2$s" />',
				esc_url( $custom ),
				esc_attr( (string) get_bloginfo( 'name' ) )
			);
		} else {
			$custom = '';
		}

		// Matches free's instant-checkout header, which prefers the funnel's upload and falls back to the theme's logo.
		$logo = '' !== $custom ? $custom : (string) get_custom_logo();

		return (string) apply_filters( 'cartflows_pro_instant_checkout_logo', $logo, $flow_id );
	}

	/**
	 * Up to two initials from the store name, for the identity mark.
	 *
	 * @return string
	 */
	private static function get_store_initials() {

		$words    = preg_split( '/\s+/', (string) get_bloginfo( 'name' ), -1, PREG_SPLIT_NO_EMPTY );
		$initials = '';

		if ( is_array( $words ) ) {
			foreach ( array_slice( $words, 0, 2 ) as $word ) {
				$initials .= mb_substr( $word, 0, 1 );
			}
		}

		$initials = '' !== $initials ? $initials : 'S';

		// WP polyfills mb_substr but not mb_strtoupper, so hosts without mbstring need the ASCII fallback (non-ASCII initials pass through unchanged).
		return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $initials ) : strtoupper( $initials );
	}

	/**
	 * Render the CartFlows checkout for the step now in context.
	 *
	 * @return string
	 */
	private function get_checkout_html() {

		add_filter( 'woocommerce_is_checkout', array( $this, 'force_is_checkout' ), 9999 );

		// Single column: the popup supplies its own two-pane layout. Also keeps the Modern Checkout class from adding a collapsed mobile summary (duplicate review table and coupon field) and rewrapping the payment section.
		add_filter( 'cartflows_checkout_meta_wcf-checkout-layout', array( $this, 'force_single_column' ), 9999 );

		// Product Options lists the step's own products, which the popup never puts in its Buy Now cart, and its script never loads on a product page.
		add_filter( 'cartflows_checkout_meta_wcf-enable-product-options', array( $this, 'disable_product_options' ), 9999 );

		// Stamps the form so tag_order() distinguishes this order from a later normal checkout. Same hook as _wcf_checkout_id, outside update_order_review so a totals refresh can't drop it.
		add_action( 'woocommerce_after_order_notes', array( $this, 'print_order_marker' ), 99 );

		// Funnel fields CartFlows emits from before_checkout_shortcode_actions(), called directly by shortcode_load_data() rather than the action fired below.
		add_action( 'woocommerce_after_order_notes', array( $this, 'print_funnel_fields' ), 99 );

		// Also from before_checkout_shortcode_actions(): the step's Place Order label with total. Without it re-open checkout.js skips the correcting fragment as unchanged, so the button total disagrees with the rail.
		add_filter( 'woocommerce_order_button_text', array( Cartflows_Checkout_Markup::get_instance(), 'place_order_button_text' ), 99 );

		// The Quick View modal a variable bump's link opens needs checkout.js, which the popup never loads; render inline dropdowns instead.
		// Scoped to this one render because the popup only opens on product pages, where the totals refresh carries no wcf_checkout_id and so never re-renders the bump card.
		add_filter( 'cartflows_pro_ob_choose_variation_html', array( 'Cartflows_Pro_Instant_Checkout', 'render_bump_variation_field' ), 10, 4 );

		// Fires the action funnel checkout steps fire, so order bumps, field customisations and product options register against this render.
		do_action( 'cartflows_checkout_before_shortcode', $this->get_step_id() );

		$html = do_shortcode( '[cartflows_checkout]' );

		remove_filter( 'cartflows_pro_ob_choose_variation_html', array( 'Cartflows_Pro_Instant_Checkout', 'render_bump_variation_field' ), 10 );
		remove_filter( 'woocommerce_order_button_text', array( Cartflows_Checkout_Markup::get_instance(), 'place_order_button_text' ), 99 );
		remove_action( 'woocommerce_after_order_notes', array( $this, 'print_funnel_fields' ), 99 );
		remove_action( 'woocommerce_after_order_notes', array( $this, 'print_order_marker' ), 99 );
		remove_filter( 'cartflows_checkout_meta_wcf-enable-product-options', array( $this, 'disable_product_options' ), 9999 );
		remove_filter( 'cartflows_checkout_meta_wcf-checkout-layout', array( $this, 'force_single_column' ), 9999 );
		remove_filter( 'woocommerce_is_checkout', array( $this, 'force_is_checkout' ), 9999 );

		// An empty cart makes WC_Shortcode_Checkout::checkout() return no form — the bare wrapper CartFlows also checks for.
		if ( false === strpos( $html, 'woocommerce-checkout' ) ) {
			return '';
		}

		return $html;
	}

	/**
	 * Print the field that proves an order was submitted by the popup.
	 *
	 * Server-side, not added by the popup's JS, so no DOM rewrite between open and Place order can lose it.
	 *
	 * @return void
	 */
	public function print_order_marker() {

		printf(
			'<input type="hidden" class="input-hidden" name="%1$s" value="%2$s">',
			esc_attr( Cartflows_Pro_Instant_Checkout::ORDER_META ),
			esc_attr( (string) $this->get_step_id() )
		);
	}

	/**
	 * Print the funnel fields that make the order visible to CartFlows.
	 *
	 * Without these, _is_wcf_doing_checkout_ajax() is false for the wc-ajax=checkout, so no checkout ID resolves — no attribution, analytics, bump refresh or webhook step ID. Printed rather than via before_checkout_shortcode_actions(), which would also swap the coupon form and re-add billing/shipping.
	 *
	 * @return void
	 */
	public function print_funnel_fields() {

		$step_id = $this->get_step_id();
		$flow_id = absint( get_post_meta( $step_id, 'wcf-flow-id', true ) );

		printf(
			'<input type="hidden" class="input-hidden _wcf_flow_id" name="_wcf_flow_id" value="%1$s"><input type="hidden" class="input-hidden _wcf_checkout_id" name="_wcf_checkout_id" value="%2$s">',
			esc_attr( (string) $flow_id ),
			esc_attr( (string) $step_id )
		);
	}

	/**
	 * Force is_checkout() true for this request only.
	 *
	 * Without it every gateway suppresses its fields, gating payment_fields() and script enqueues on is_checkout().
	 *
	 * @param bool $is_checkout Incoming value.
	 * @return bool
	 */
	public function force_is_checkout( $is_checkout ) {
		return true;
	}

	/**
	 * Render the checkout as a single column inside the popup.
	 *
	 * @param string $layout Configured checkout layout.
	 * @return string
	 */
	public function force_single_column( $layout ) {
		return 'one-column';
	}

	/**
	 * Switch Product Options off inside the popup.
	 *
	 * @since x.x.x
	 * @param string $enabled Configured value, 'yes' or 'no'.
	 * @return string
	 */
	public function disable_product_options( $enabled ) {
		return 'no';
	}

	/**
	 * Step currently in context.
	 *
	 * @return int
	 */
	public function get_step_id() {

		$post = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;

		return $post instanceof WP_Post ? absint( $post->ID ) : 0;
	}

	/**
	 * Make the request look like it is on the funnel's checkout step.
	 *
	 * CartFlows resolves checkout context from the global post — _is_wcf_checkout_type() and _get_wcf_checkout_id() read it directly, unfilterable. Swapping it is how Store Checkout replaces the WC checkout page, so the whole pipeline works unchanged.
	 *
	 * @param int $step_id Checkout step ID.
	 * @return bool True when the context was applied.
	 */
	private function enter_context( $step_id ) {

		$step = get_post( $step_id );

		if ( ! $step instanceof WP_Post || CARTFLOWS_STEP_POST_TYPE !== $step->post_type ) {
			return false;
		}

		$this->previous_post = isset( $GLOBALS['post'] ) && $GLOBALS['post'] instanceof WP_Post ? $GLOBALS['post'] : null;

		$GLOBALS['post'] = $step; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Mirrors Cartflows_Global_Checkout::override_global_checkout(); restored in exit_context().

		return true;
	}

	/**
	 * Restore the global post.
	 *
	 * @return void
	 */
	private function exit_context() {

		if ( $this->previous_post instanceof WP_Post ) {
			$GLOBALS['post'] = $this->previous_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restoring the value saved in enter_context().
		} else {
			unset( $GLOBALS['post'] );
		}

		$this->previous_post = null;
	}
}
