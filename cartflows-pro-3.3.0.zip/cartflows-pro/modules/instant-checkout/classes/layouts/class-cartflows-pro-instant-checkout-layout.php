<?php
/**
 * Instant Checkout layout base.
 *
 * Describes how the popup is arranged (template, stylesheet, step field groups, summary placement);
 * checkout behaviour is shared by every layout and lives in the module's core classes.
 *
 * @package cartflows-pro
 * @since x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Contract every popup layout implements.
 *
 * Third parties extend this and return an instance from `cartflows_pro_instant_checkout_layouts`.
 * Keeping the three field groups (contact, address, payment) needs no JS; the popup script arranges
 * the checkout from the step definitions the server hands it.
 *
 * @since x.x.x
 *
 * @phpstan-type Instant_Checkout_Step array{slug: string, number: string, label: string, heading: string, sub: string, next_label: string}
 */
abstract class Cartflows_Pro_Instant_Checkout_Layout {

	/**
	 * Field groups a step can be composed from.
	 *
	 * @var array<int, string>
	 */
	const FIELD_GROUPS = array( 'contact', 'address', 'payment' );

	/**
	 * Regions every layout template must render, as CSS selectors.
	 *
	 * Nodes the popup script binds to; a missing one breaks shared behaviour, not just the look.
	 *
	 * @var array<int, string>
	 */
	const SHARED_REGIONS = array(
		'.wcf-icp-dialog[role="dialog"]',
		'.wcf-icp-close',
		'.wcf-icp-flow',
		'[data-wcf-icp-heading]',
		'[data-wcf-icp-sub]',
		'.wcf-icp-notices',
		'.wcf-icp-body',
		'.wcf-icp-nav > .wcf-icp-back',
		'.wcf-icp-nav > [data-wcf-icp-next]',
		'.wcf-icp-pill[data-step][data-heading][data-sub][data-next]',
		'.wcf-icp-pill-button',
		'[data-wcf-icp-coupon]',
	);

	/**
	 * Slug stored in flow meta and used for asset file names. Lowercase letters, digits and hyphens.
	 *
	 * @return string
	 */
	abstract public function get_slug();

	/**
	 * Name shown in the layout picker.
	 *
	 * @return string
	 */
	abstract public function get_label();

	/**
	 * The steps the popup walks through, in order.
	 *
	 * @return array<int, Instant_Checkout_Step>
	 */
	abstract public function get_steps();

	/**
	 * Field groups each step owns, keyed by step slug.
	 *
	 * Each of `contact`, `address`, `payment` appears once, with `payment` last so Place Order ends the flow.
	 *
	 * @return array<string, array<int, string>>
	 */
	abstract public function get_step_fields();

	/**
	 * One-line description for the picker and the abilities API.
	 *
	 * @return string
	 */
	public function get_description() {
		return '';
	}

	/**
	 * Thumbnail shown in the layout picker. Empty for none.
	 *
	 * @return string
	 */
	public function get_thumbnail_url() {
		return '';
	}

	/**
	 * Absolute path of the template that renders the popup shell.
	 *
	 * @return string
	 */
	public function get_template_path() {
		return CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . 'templates/' . $this->get_slug() . '.php';
	}

	/**
	 * Absolute path of the layout's stylesheet, or an empty string when it has none.
	 *
	 * @return string
	 */
	public function get_stylesheet() {

		$file = CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . 'assets/css/layout-' . $this->get_slug() . '.css';

		return file_exists( $file ) ? $file : '';
	}

	/**
	 * URL of the layout's stylesheet.
	 *
	 * Derived from the path for anything inside the plugins directory; layouts shipped from a theme
	 * override this.
	 *
	 * @return string
	 */
	public function get_stylesheet_url() {

		$file = $this->get_stylesheet();

		return '' === $file ? '' : plugins_url( basename( $file ), $file );
	}

	/**
	 * Which step each CartFlows order-bump position lands in.
	 *
	 * All five single-page positions collapse onto the pay step; see the note on the return below.
	 *
	 * @return array<string, string>
	 */
	public function get_bump_positions() {

		$steps = $this->get_steps();
		$last  = end( $steps );
		$first = isset( $steps[0] ) ? $steps[0]['slug'] : '';
		$pay   = is_array( $last ) ? $last['slug'] : $first;

		// All five collapse onto the pay step: they name regions of a single-page checkout the stepped pane
		// has no equivalent for — on two-pane the order summary sits in the rail, outside every step.
		return array(
			'wcf-before-checkout'     => $pay,
			'wcf-after-customer'      => $pay,
			'wcf-above-order-summary' => $pay,
			'wcf-after-order'         => $pay,
			'wcf-after-payment'       => $pay,
		);
	}

	/**
	 * Where the order review table goes.
	 *
	 * `slot` appends it to `[data-wcf-icp-summary]`; `payment` places it above the payment methods.
	 *
	 * @return string
	 */
	public function get_summary_target() {
		return 'slot';
	}

	/**
	 * Is this layout unavailable on the current plan?
	 *
	 * Gated layouts are left out of the picker and treated as unknown when read back.
	 *
	 * @return bool
	 */
	public function is_gated() {
		return false;
	}

	/**
	 * Extra design fields this layout offers. Reserved; not read by the settings screen yet.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public function get_design_fields() {
		return array();
	}

	/**
	 * Selectors the rendered template must contain.
	 *
	 * @return array<int, string>
	 */
	public function get_required_regions() {
		return self::SHARED_REGIONS;
	}

	/**
	 * Everything the popup script needs to arrange this layout.
	 *
	 * Sent with the popup HTML, not the product page, which is often full-page cached and can't be trusted to know the layout.
	 *
	 * @return array<string, mixed>
	 */
	final public function get_client_config() {

		$fields = $this->get_step_fields();
		$steps  = array();

		foreach ( $this->get_steps() as $step ) {
			$slug    = $step['slug'];
			$steps[] = array_merge( $step, array( 'fields' => isset( $fields[ $slug ] ) ? $fields[ $slug ] : array() ) );
		}

		return array(
			'layout'         => $this->get_slug(),
			'steps'          => $steps,
			'bump_positions' => $this->get_bump_positions(),
			'summary_target' => $this->get_summary_target(),
			'stylesheet_url' => $this->get_stylesheet_url(),
		);
	}
}
