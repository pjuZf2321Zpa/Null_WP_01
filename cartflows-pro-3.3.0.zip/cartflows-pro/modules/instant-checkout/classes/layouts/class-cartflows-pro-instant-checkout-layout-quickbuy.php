<?php
/**
 * Instant Checkout — QuickBuy layout.
 *
 * @package cartflows-pro
 * @since x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * A compact single column for narrow viewports: one details step, then payment.
 *
 * Summary is a fixed strip under the header; the full review table sits above the payment methods.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Instant_Checkout_Layout_Quickbuy extends Cartflows_Pro_Instant_Checkout_Layout {

	/**
	 * Slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'quickbuy';
	}

	/**
	 * Label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'QuickBuy', 'cartflows-pro' );
	}

	/**
	 * Description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Compact single-column popup with a two-step flow: details, then payment.', 'cartflows-pro' );
	}

	/**
	 * Thumbnail.
	 *
	 * @return string
	 */
	public function get_thumbnail_url() {
		return CARTFLOWS_PRO_INSTANT_CHECKOUT_URL . 'assets/images/layout-quickbuy.svg';
	}

	/**
	 * Steps.
	 *
	 * The labelled stepper already says which step this is, so the heading names the step and nothing more.
	 *
	 * @return array<int, array{slug: string, number: string, label: string, heading: string, sub: string, next_label: string}>
	 */
	public function get_steps() {

		return array(
			array(
				'slug'       => 'details',
				'number'     => '1',
				'label'      => __( 'Details', 'cartflows-pro' ),
				'heading'    => __( 'Your details', 'cartflows-pro' ),
				'sub'        => __( 'Contact and delivery, in one step.', 'cartflows-pro' ),
				'next_label' => __( 'Continue to payment', 'cartflows-pro' ),
			),
			array(
				'slug'       => 'payment',
				'number'     => '2',
				'label'      => __( 'Payment', 'cartflows-pro' ),
				'heading'    => __( 'Payment', 'cartflows-pro' ),
				'sub'        => __( 'Choose how you\'d like to pay.', 'cartflows-pro' ),
				'next_label' => '',
			),
		);
	}

	/**
	 * Field groups per step.
	 *
	 * @return array<string, array<int, string>>
	 */
	public function get_step_fields() {

		return array(
			'details' => array( 'contact', 'address' ),
			'payment' => array( 'payment' ),
		);
	}

	/**
	 * Required regions: the shared set plus the header, progress bar and the summary slot.
	 *
	 * @return array<int, string>
	 */
	public function get_required_regions() {

		return array_merge(
			parent::get_required_regions(),
			array(
				'.wcf-icp-header',
				'.wcf-icp-progress',
				'[data-wcf-icp-summary]',
			)
		);
	}
}
