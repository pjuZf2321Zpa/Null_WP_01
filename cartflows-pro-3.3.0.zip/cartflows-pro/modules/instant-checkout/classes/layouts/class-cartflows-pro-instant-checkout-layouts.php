<?php
/**
 * Instant Checkout layout registry.
 *
 * @package cartflows-pro
 * @since x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Knows every registered layout and which one a funnel uses.
 *
 * Every layout-meta read goes through here, so an unknown slug always resolves to the default instead of rendering nothing.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Instant_Checkout_Layouts {

	/**
	 * Layout used when none is chosen or the chosen one is unknown.
	 *
	 * @var string
	 */
	const DEFAULT_SLUG = 'two-pane';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Every registered layout, built-ins first.
	 *
	 * Third parties add via `cartflows_pro_instant_checkout_layouts`. Only base instances are kept, keyed
	 * by slug; built-ins can't be removed, so the default is always available to fall back to.
	 *
	 * @return array<string, Cartflows_Pro_Instant_Checkout_Layout>
	 */
	public function get_layouts() {

		require_once __DIR__ . '/class-cartflows-pro-instant-checkout-layout-two-pane.php';
		require_once __DIR__ . '/class-cartflows-pro-instant-checkout-layout-quickbuy.php';

		$built_in = array(
			new Cartflows_Pro_Instant_Checkout_Layout_Two_Pane(),
			new Cartflows_Pro_Instant_Checkout_Layout_Quickbuy(),
		);

		$layouts = array();

		foreach ( $built_in as $layout ) {
			$layouts[ $layout->get_slug() ] = $layout;
		}

		/**
		 * Register additional Instant Checkout layouts.
		 *
		 * Not memoised: resolved fresh each call so a layout registered late (on any hook before the
		 * popup renders) is still seen.
		 *
		 * @since x.x.x
		 *
		 * @param array<string, Cartflows_Pro_Instant_Checkout_Layout> $layouts Layouts keyed by slug.
		 */
		$filtered = apply_filters( 'cartflows_pro_instant_checkout_layouts', $layouts );

		if ( is_array( $filtered ) ) {
			foreach ( $filtered as $layout ) {
				if ( $layout instanceof Cartflows_Pro_Instant_Checkout_Layout && ! isset( $layouts[ $layout->get_slug() ] ) ) {
					$layouts[ $layout->get_slug() ] = $layout;
				}
			}
		}

		return $layouts;
	}

	/**
	 * Layouts a merchant can pick: registered and not gated.
	 *
	 * @return array<string, Cartflows_Pro_Instant_Checkout_Layout>
	 */
	public function get_selectable_layouts() {

		return array_filter(
			$this->get_layouts(),
			function ( $layout ) {
				return ! $layout->is_gated();
			}
		);
	}

	/**
	 * The layout for a slug, or the default when the slug is unknown or gated.
	 *
	 * Anything that isn't a selectable layout's slug resolves to the default, so callers never null-check.
	 *
	 * @param mixed $slug Layout slug.
	 * @return Cartflows_Pro_Instant_Checkout_Layout
	 */
	public function get_layout( $slug ) {

		$selectable = $this->get_selectable_layouts();
		$default    = $this->get_layouts()[ self::DEFAULT_SLUG ];

		if ( is_string( $slug ) && isset( $selectable[ $slug ] ) ) {
			$layout = $selectable[ $slug ];

			// A layout whose template file is missing must fall back here, not in the renderer alone:
			// the client config and the enqueued stylesheet are chosen from this same resolution, so
			// falling back only at render time would ship the default markup with the wrong config and CSS.
			return is_readable( $layout->get_template_path() ) ? $layout : $default;
		}

		return $default;
	}

	/**
	 * The layout a funnel has chosen.
	 *
	 * Read raw and validated here: the meta can arrive from imports and the abilities API, which bypass the settings sanitizer.
	 *
	 * @param int $flow_id Flow ID.
	 * @return Cartflows_Pro_Instant_Checkout_Layout
	 */
	public function get_layout_for_flow( $flow_id ) {

		return $this->get_layout( get_post_meta( absint( $flow_id ), Cartflows_Pro_Instant_Checkout::LAYOUT_META, true ) );
	}

	/**
	 * The layout a checkout step's popup renders with.
	 *
	 * @param int $step_id Checkout step ID.
	 * @return Cartflows_Pro_Instant_Checkout_Layout
	 */
	public function get_layout_for_step( $step_id ) {

		$step_id = absint( $step_id );
		$flow_id = absint( get_post_meta( $step_id, 'wcf-flow-id', true ) );
		$slug    = $this->get_layout_for_flow( $flow_id )->get_slug();

		/**
		 * Override the popup layout for one checkout step.
		 *
		 * @since x.x.x
		 *
		 * @param string $slug    Layout slug chosen on the funnel.
		 * @param int    $step_id Checkout step ID.
		 */
		$slug = apply_filters( 'cartflows_pro_instant_checkout_layout', $slug, $step_id );

		return $this->get_layout( $slug );
	}
}
