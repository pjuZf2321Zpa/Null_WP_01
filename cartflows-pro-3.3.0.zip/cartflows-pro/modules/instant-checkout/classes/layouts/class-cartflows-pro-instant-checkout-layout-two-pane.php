<?php
/**
 * Instant Checkout — Two Pane layout.
 *
 * @package cartflows-pro
 * @since x.x.x
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * The original popup: an order-summary rail beside a three-step flow.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Instant_Checkout_Layout_Two_Pane extends Cartflows_Pro_Instant_Checkout_Layout {

	/**
	 * Slug.
	 *
	 * @return string
	 */
	public function get_slug() {
		return 'two-pane';
	}

	/**
	 * Label.
	 *
	 * @return string
	 */
	public function get_label() {
		return __( 'Two Pane', 'cartflows-pro' );
	}

	/**
	 * Description.
	 *
	 * @return string
	 */
	public function get_description() {
		return __( 'Order summary rail beside a three-step flow: contact, address, payment.', 'cartflows-pro' );
	}

	/**
	 * Thumbnail.
	 *
	 * @return string
	 */
	public function get_thumbnail_url() {
		return CARTFLOWS_PRO_INSTANT_CHECKOUT_URL . 'assets/images/layout-two-pane.svg';
	}

	/**
	 * Steps.
	 *
	 * Contact first so email and phone are captured up front, which makes an abandoned popup recoverable.
	 *
	 * @return array<int, array{slug: string, number: string, label: string, heading: string, sub: string, next_label: string}>
	 */
	public function get_steps() {

		return array(
			array(
				'slug'       => 'contact',
				'number'     => '1',
				'label'      => __( 'Contact', 'cartflows-pro' ),
				'heading'    => __( 'Contact details', 'cartflows-pro' ),
				'sub'        => __( 'Enter your mobile & email to continue', 'cartflows-pro' ),
				'next_label' => __( 'Continue to address', 'cartflows-pro' ),
			),
			array(
				'slug'       => 'address',
				'number'     => '2',
				'label'      => __( 'Address', 'cartflows-pro' ),
				'heading'    => __( 'Shipping address', 'cartflows-pro' ),
				'sub'        => __( 'Where should we send your order?', 'cartflows-pro' ),
				'next_label' => __( 'Continue to payment', 'cartflows-pro' ),
			),
			array(
				'slug'       => 'payment',
				'number'     => '3',
				'label'      => __( 'Payment', 'cartflows-pro' ),
				'heading'    => __( 'Payment', 'cartflows-pro' ),
				'sub'        => __( 'Choose how you\'d like to pay', 'cartflows-pro' ),
				'next_label' => '',
			),
		);
	}

	/**
	 * Field groups per step.
	 *
	 * @return array<string, array<int, string>>
	 */
	public function get_step_fields() {

		return array(
			'contact' => array( 'contact' ),
			'address' => array( 'address' ),
			'payment' => array( 'payment' ),
		);
	}

	/**
	 * Required regions: the shared set plus the rail.
	 *
	 * @return array<int, string>
	 */
	public function get_required_regions() {

		return array_merge(
			parent::get_required_regions(),
			array( '.wcf-icp-rail', '[data-wcf-icp-summary]', '.wcf-icp-connector' )
		);
	}
}
