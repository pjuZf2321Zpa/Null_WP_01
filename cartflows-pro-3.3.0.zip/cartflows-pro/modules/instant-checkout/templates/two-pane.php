<?php
/**
 * Instant Checkout popup shell — Two Pane layout.
 *
 * A fixed summary rail beside a stepped flow pane. The checkout markup is passed through untouched
 * (form.checkout, #order_review, #place_order, the nonce) so checkout.js and the gateways stay bound;
 * the regions the popup script binds to are listed in Cartflows_Pro_Instant_Checkout_Layout::SHARED_REGIONS.
 *
 * @package cartflows-pro
 * @since 3.1.4
 *
 * @var string                                                                            $checkout Rendered checkout markup.
 * @var array<int, array<string, string>>                                                 $steps    Step definitions: slug, number, label, heading, sub, next_label.
 * @var string                                                                            $initials Store initials, the identity mark's last resort.
 * @var string                                                                            $logo     Identity mark logo markup; empty when neither a custom nor a theme logo is set.
 * @var Cartflows_Pro_Instant_Checkout_Layout                                             $layout   Layout being rendered.
 * @var array{items_html: string, lead_html: string, rows_html: string}                   $cart     Cart summary; this layout uses the lead for its collapsed rail.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wcf-icp-dialog" role="dialog" aria-modal="true" aria-labelledby="wcf-icp-heading">

	<aside class="wcf-icp-rail">
		<div class="wcf-icp-store<?php echo '' !== $logo ? ' wcf-icp-store-has-logo' : ''; ?>">
			<span class="wcf-icp-store-mark<?php echo '' !== $logo ? ' wcf-icp-store-mark-logo' : ''; ?>" aria-hidden="true">
				<?php
				// Already escaped where it is built; get_custom_logo() returns theme markup.
				echo '' !== $logo ? wp_kses_post( $logo ) : esc_html( $initials );
				?>
			</span>
			<span class="wcf-icp-store-text">
				<span class="wcf-icp-store-name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
				<span class="wcf-icp-store-tag">
					<svg class="wcf-icp-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z"/><path d="M9 12l2 2 4-4"/></svg>
					<?php esc_html_e( 'Secured checkout', 'cartflows-pro' ); ?>
				</span>
			</span>
		</div>

		<div class="wcf-icp-total">
			<button type="button" class="wcf-icp-total-toggle" aria-expanded="false" aria-controls="wcf-icp-rail-panel">
				<?php echo wp_kses_post( $cart['lead_html'] ); ?>
				<span class="wcf-icp-total-more">
					<?php esc_html_e( 'Order summary', 'cartflows-pro' ); ?>
					<svg class="wcf-icp-total-chevron" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 9l6 6 6-6"/></svg>
				</span>
			</button>

			<?php // Not hidden here: the panel only collapses where the bar is on screen, which syncRailPanel() decides. ?>
			<div class="wcf-icp-total-panel" id="wcf-icp-rail-panel">
				<div class="wcf-icp-card">
					<div class="wcf-icp-card-label"><?php esc_html_e( 'Order summary', 'cartflows-pro' ); ?></div>
					<div class="wcf-icp-summary" data-wcf-icp-summary></div>
				</div>

				<div class="wcf-icp-card wcf-icp-card-coupon" data-wcf-icp-coupon hidden></div>
			</div>
		</div>
	</aside>

	<div class="wcf-icp-flow">

		<div class="wcf-icp-steps">
			<p class="wcf-icp-sr-only" aria-live="polite" data-wcf-icp-step-status>
				<?php
				printf(
					/* translators: %1$s: current step number, %2$s: how many steps there are, %3$s: the step's name. */
					esc_html__( 'Step %1$s of %2$s: %3$s', 'cartflows-pro' ),
					1,
					count( $steps ),
					esc_html( $steps[0]['label'] )
				);
				?>
			</p>

			<ol class="wcf-icp-pills" role="list" aria-label="<?php esc_attr_e( 'Checkout progress', 'cartflows-pro' ); ?>">
				<?php foreach ( $steps as $index => $step ) : ?>
					<?php if ( $index > 0 ) : ?>
						<li class="wcf-icp-connector" aria-hidden="true"></li>
					<?php endif; ?>
					<li
						class="wcf-icp-pill<?php echo 0 === $index ? ' is-active' : ''; ?>"
						data-step="<?php echo esc_attr( $step['slug'] ); ?>"
						data-heading="<?php echo esc_attr( $step['heading'] ); ?>"
						data-sub="<?php echo esc_attr( $step['sub'] ); ?>"
						data-next="<?php echo esc_attr( $step['next_label'] ); ?>"
					>
						<button type="button" class="wcf-icp-pill-button" <?php echo 0 === $index ? 'aria-current="step"' : 'disabled'; ?>>
							<span class="wcf-icp-pill-num" aria-hidden="true"><?php echo esc_html( $step['number'] ); ?></span>
							<span class="wcf-icp-pill-label"><?php echo esc_html( $step['label'] ); ?></span>
						</button>
					</li>
				<?php endforeach; ?>
			</ol>
			<button type="button" class="wcf-icp-close" aria-label="<?php esc_attr_e( 'Close checkout', 'cartflows-pro' ); ?>">
				<svg class="wcf-icp-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg>
			</button>
		</div>

		<h2 id="wcf-icp-heading" class="wcf-icp-heading" data-wcf-icp-heading><?php echo esc_html( $steps[0]['heading'] ); ?></h2>
		<p class="wcf-icp-sub" data-wcf-icp-sub><?php echo esc_html( $steps[0]['sub'] ); ?></p>

		<div class="wcf-icp-notices" role="status" aria-live="polite"></div>

		<div class="wcf-icp-body">
			<?php
			// Already escaped by WooCommerce's and CartFlows' templates; escaping again breaks the form.
			echo $checkout; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>

		<div class="wcf-icp-nav">
			<button type="button" class="wcf-icp-back" hidden><?php esc_html_e( 'Back', 'cartflows-pro' ); ?></button>
			<button type="button" class="wcf-icp-next" data-wcf-icp-next><?php echo esc_html( $steps[0]['next_label'] ); ?></button>
		</div>
	</div>

</div>
