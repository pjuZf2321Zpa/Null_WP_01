<?php
/**
 * Instant Checkout popup shell — QuickBuy layout.
 *
 * A single narrow column with a stepped flow. The checkout markup is passed through untouched so
 * checkout.js and the gateways stay bound to it; the coupon form is a sibling <form> of form.checkout.
 *
 * @package cartflows-pro
 * @since x.x.x
 *
 * @var string                                                                            $checkout Rendered checkout markup.
 * @var array<int, array<string, string>>                                                 $steps    Step definitions: slug, number, label, heading, sub, next_label.
 * @var string                                                                            $initials Store initials (unused by this layout).
 * @var string                                                                            $logo     Identity mark logo markup; empty when neither a custom nor a theme logo is set.
 * @var Cartflows_Pro_Instant_Checkout_Layout                                             $layout   Layout being rendered.
 * @var array{items_html: string, lead_html: string, rows_html: string}                   $cart     Cart summary; this layout uses the lead for its pinned bar.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wcf-icp-dialog" role="dialog" aria-modal="true" aria-labelledby="wcf-icp-heading">

	<header class="wcf-icp-header">
		<div class="wcf-icp-brand<?php echo '' !== $logo ? ' wcf-icp-brand-has-logo' : ''; ?>">
			<?php if ( '' !== $logo ) : ?>
				<span class="wcf-icp-brand-logo" aria-hidden="true"><?php echo wp_kses_post( $logo ); ?></span>
			<?php else : ?>
				<span class="wcf-icp-brand-dot" aria-hidden="true"></span>
			<?php endif; ?>
			<span class="wcf-icp-brand-name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
		</div>
		<button type="button" class="wcf-icp-close" aria-label="<?php esc_attr_e( 'Close checkout', 'cartflows-pro' ); ?>">
			<svg class="wcf-icp-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg>
		</button>
	</header>

	<p class="wcf-icp-sr-only" aria-live="polite" data-wcf-icp-step-status>
		<?php
		printf(
			/* translators: %1$s: current step number, %2$s: how many steps there are, %3$s: the step's name. */
			esc_html__( 'Step %1$s of %2$s: %3$s', 'cartflows-pro' ),
			1,
			count( $steps ),
			esc_html( $steps[0]['label'] )
		);
		?>
	</p>

	<ol class="wcf-icp-pills wcf-icp-progress" role="list" aria-label="<?php esc_attr_e( 'Checkout progress', 'cartflows-pro' ); ?>">
		<?php foreach ( $steps as $index => $step ) : ?>
			<li
				class="wcf-icp-pill<?php echo 0 === $index ? ' is-active' : ''; ?>"
				data-step="<?php echo esc_attr( $step['slug'] ); ?>"
				data-heading="<?php echo esc_attr( $step['heading'] ); ?>"
				data-sub="<?php echo esc_attr( $step['sub'] ); ?>"
				data-next="<?php echo esc_attr( $step['next_label'] ); ?>"
			>
				<button type="button" class="wcf-icp-pill-button" <?php echo 0 === $index ? 'aria-current="step"' : 'disabled'; ?>>
					<span class="wcf-icp-pill-num" aria-hidden="true"><?php echo esc_html( $step['number'] ); ?></span>
					<span class="wcf-icp-pill-label"><?php echo esc_html( $step['label'] ); ?></span>
				</button>
			</li>
		<?php endforeach; ?>
	</ol>

	<div class="wcf-icp-total">
		<button type="button" class="wcf-icp-total-toggle" aria-expanded="false" aria-controls="wcf-icp-total-panel">
			<?php echo wp_kses_post( $cart['lead_html'] ); ?>
			<span class="wcf-icp-total-more">
				<?php esc_html_e( 'Order summary', 'cartflows-pro' ); ?>
				<svg class="wcf-icp-total-chevron" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 9l6 6 6-6"/></svg>
			</span>
		</button>

		<div class="wcf-icp-total-panel" id="wcf-icp-total-panel" hidden>
			<?php // The review table lands here, so the panel shows the same summary the other layouts do. ?>
			<div class="wcf-icp-summary" data-wcf-icp-summary></div>

			<div class="wcf-icp-card wcf-icp-card-coupon" data-wcf-icp-coupon hidden></div>
		</div>
	</div>

	<div class="wcf-icp-flow">

		<h2 id="wcf-icp-heading" class="wcf-icp-heading" data-wcf-icp-heading><?php echo esc_html( $steps[0]['heading'] ); ?></h2>
		<p class="wcf-icp-sub" data-wcf-icp-sub><?php echo esc_html( $steps[0]['sub'] ); ?></p>

		<div class="wcf-icp-notices" role="status" aria-live="polite"></div>

		<div class="wcf-icp-body">
			<?php
			// Already escaped by WooCommerce's and CartFlows' templates; escaping again breaks the form.
			echo $checkout; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>

		<div class="wcf-icp-nav">
			<button type="button" class="wcf-icp-back" hidden><?php esc_html_e( 'Back', 'cartflows-pro' ); ?></button>
			<button type="button" class="wcf-icp-next" data-wcf-icp-next><?php echo esc_html( $steps[0]['next_label'] ); ?></button>
		</div>

		<p class="wcf-icp-lock">
			<svg class="wcf-icp-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
			<?php esc_html_e( 'Your payment is secured & encrypted', 'cartflows-pro' ); ?>
		</p>
	</div>
</div>
