<?php
/**
 * Instant Checkout module loader.
 *
 * Only this file loads every request; heavier classes load on demand via maybe_load_classes().
 *
 * @package cartflows-pro
 * @since 3.1.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR', CARTFLOWS_PRO_DIR . 'modules/instant-checkout/' );
define( 'CARTFLOWS_PRO_INSTANT_CHECKOUT_URL', CARTFLOWS_PRO_URL . 'modules/instant-checkout/' );

// Layout base and registry load with the bootstrap — settings screen, enqueue and abilities API all need them; third-party layouts extend the base.
require_once CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . 'classes/layouts/class-cartflows-pro-instant-checkout-layout.php';
require_once CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . 'classes/layouts/class-cartflows-pro-instant-checkout-layouts.php';

/**
 * Instant Checkout module bootstrap.
 *
 * @since 3.1.4
 */
class Cartflows_Pro_Instant_Checkout {

	/**
	 * Flow meta key that enables the feature for a funnel.
	 *
	 * Read with get_post_meta(), not get_flow_meta_value(), which discards falsy explicit defaults.
	 *
	 * @var string
	 */
	const ENABLE_META = 'wcf-icp';

	/**
	 * Flow meta key holding the popup layout slug.
	 *
	 * Always read through Cartflows_Pro_Instant_Checkout_Layouts, which validates the slug.
	 *
	 * @var string
	 */
	const LAYOUT_META = 'wcf-icp-layout';

	/**
	 * Countries whose postcode WooCommerce accepts as digits and nothing else.
	 *
	 * Read off WC_Validation::is_postcode(). A numeric keypad offers no letters and no separators,
	 * so anywhere a format allows one - US ZIP+4, JP, PL, GB - it would make a valid postcode
	 * impossible to type. Only patterns that are purely [0-9] are safe to put a keypad in front of.
	 *
	 * @since x.x.x
	 * @var array<int, string>
	 */
	const NUMERIC_POSTCODE_COUNTRIES = array(
		'AT',
		'BA',
		'BE',
		'CH',
		'DE',
		'EE',
		'ES',
		'FI',
		'FR',
		'HU',
		'IT',
		'LI',
		'NO',
		'SI',
	);

	/**
	 * Flow meta key holding the button label.
	 *
	 * Its own setting rather than cartflows_add_to_cart_text, which free's woo-dynamic-flow
	 * already uses to relabel the native Add to cart button on the same product page.
	 *
	 * @var string
	 */
	const BUTTON_TEXT_META = 'wcf-icp-button-text';

	/**
	 * Flow meta key holding the identity mark's custom logo URL.
	 *
	 * Empty falls back to the theme's Site Logo, then to the store's initials.
	 *
	 * @var string
	 */
	const LOGO_META = 'wcf-icp-logo';

	/**
	 * Product meta key: whether Buy Now uses the product's own funnel.
	 *
	 * 'no' falls back to Store Checkout; missing means yes, so products saved before this setting keep working.
	 *
	 * @since x.x.x
	 * @var string
	 */
	const PRODUCT_USE_FLOW_META = 'cartflows_instant_checkout_use_flow';

	/**
	 * Option holding the flow IDs that have the feature enabled.
	 *
	 * Maintained incrementally on toggle so the frontend never runs a meta query.
	 *
	 * @var string
	 */
	const ACTIVE_FLOWS_OPTION = '_cartflows_instant_flows';

	/**
	 * Modern Cart release that stops its slide-out opening on top of the popup.
	 *
	 * @since x.x.x
	 * @var string
	 */
	const MODERN_CART_MIN_VERSION = '1.1.0';

	/**
	 * Contrast ratio WCAG 2.2 asks of body-sized text.
	 *
	 * @var float
	 */
	const AA_CONTRAST = 4.5;

	/**
	 * Contrast a derived shade aims for, so a rounded reading never lands under AA.
	 *
	 * @var float
	 */
	const AA_TARGET = 4.6;

	/**
	 * WooCommerce session key holding the popup's state.
	 *
	 * The order is created in a separate wc-ajax=checkout request, so the step is carried in the session.
	 *
	 * @var string
	 */
	const SESSION_KEY = 'wcf_instant_state';

	/**
	 * Order meta holding the step the popup ran, and the name of the form field that proves it.
	 *
	 * One constant for both: tag_order() trusts the order meta only when the posted field matches it.
	 *
	 * @var string
	 */
	const ORDER_META = '_wcf_instant_checkout';

	/**
	 * Session key holding the kept cart between a paid order and its thank-you page.
	 *
	 * @var string
	 */
	const RESTORE_KEY = 'wcf_instant_restore';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance;

	/**
	 * The Checkout Offer's modal markup, captured during the asset pass.
	 *
	 * Rendered there because it needs the step as the global post, which the enqueue pass already establishes.
	 *
	 * @var string
	 */
	private $offer_modal = '';

	/**
	 * Whether a checkout context window is open, so a pause inside it knows to resume.
	 *
	 * @since x.x.x
	 * @var bool
	 */
	private $checkout_forced = false;

	/**
	 * Whether the head script-print window is the one holding the checkout context open.
	 *
	 * @since x.x.x
	 * @var bool
	 */
	private $print_window_opened = false;

	/**
	 * Checkout step resolved for the product page currently being rendered.
	 *
	 * Resolved once and reused by the button renderer, so resolution never runs twice per request.
	 *
	 * @var int
	 */
	private $step_id = 0;

	/**
	 * Design settings, mapped to the CSS custom property each one drives.
	 *
	 * Deliberately minimal — colours plus a base font size; everything else stays fixed at the mockup values.
	 *
	 * @var array<string, string>
	 */
	private static $design_settings = array(
		'wcf-icp-primary-color'  => '--wcf-icp-primary',
		'wcf-icp-heading-color'  => '--wcf-icp-heading',
		'wcf-icp-text-color'     => '--wcf-icp-text',
		'wcf-icp-bg-color'       => '--wcf-icp-bg',
		'wcf-icp-rail-bg-color'  => '--wcf-icp-rail-bg',
		'wcf-icp-base-font-size' => '--wcf-icp-font-size',
	);

	/**
	 * Initiator.
	 *
	 * @return self
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {

		add_filter( 'cartflows_flow_meta_options', array( $this, 'add_flow_meta_fields' ), 10, 1 );
		add_filter( 'cartflows_admin_flow_settings', array( $this, 'add_flow_settings' ), 10, 2 );

		// Keep the active-flow list in step with the toggle without ever querying on the frontend.
		add_action( 'added_post_meta', array( $this, 'sync_active_flows' ), 10, 3 );
		add_action( 'updated_post_meta', array( $this, 'sync_active_flows' ), 10, 3 );
		add_action( 'deleted_post_meta', array( $this, 'sync_active_flows' ), 10, 3 );
		add_action( 'before_delete_post', array( $this, 'remove_active_flow' ), 10, 1 );

		// On `wp`, not `wp_enqueue_scripts`: the checkout context must exist before gateways enqueue their is_checkout()-gated scripts, or card fields never mount.
		add_action( 'wp', array( $this, 'maybe_setup_product_page' ) );

		// The per-product opt-out sits under the funnel field in free's CartFlows product tab.
		add_action( 'cartflows_product_tab_after_flow_field', array( $this, 'render_product_flow_option' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_flow_option' ) );
		add_action( 'wp_loaded', array( $this, 'maybe_load_classes' ) );

		// On the always-loaded bootstrap: the order is created by wc-ajax=checkout, a different request from the popup open.
		add_action( 'woocommerce_checkout_create_order', array( $this, 'tag_order' ), 10, 1 );

		// State is released on payment success, not order creation: a declined card leaves an order behind with nothing bought.
		add_filter( 'woocommerce_payment_successful_result', array( $this, 'release_state_after_payment' ), 10, 2 );
		add_filter( 'woocommerce_checkout_no_payment_needed_redirect', array( $this, 'release_state_after_payment' ), 10, 2 );

		// After wc_clear_cart_after_payment() at 20: emptying the cart ahead of it nulls order_awaiting_payment, the session
		// key it reads to clean up after a gateway that paid without one. Later than every redirect here, too, so the park
		// is never spent on a request that never renders.
		add_action( 'template_redirect', array( $this, 'restore_cart_after_order' ), 25 );

		// Also on the bootstrap: the order-bump endpoint never loads this module's own classes.
		add_action( 'woocommerce_add_to_cart', array( $this, 'track_popup_cart_item' ), 10, 3 );

		// Keep the QuickBuy summary's line-item list in step with the cart (order bumps add/remove rows).
		add_filter( 'woocommerce_update_order_review_fragments', array( $this, 'add_strip_fragment' ) );

		// Also on the bootstrap: the button is minted by the open render and again by every totals refresh, two different requests.
		add_filter( 'woocommerce_order_button_html', array( $this, 'block_order_button' ), 99 );

		// WooCommerce's apology names the shopper's state for what is nearly always a store setting.
		add_filter( 'woocommerce_no_available_payment_methods_message', array( $this, 'explain_no_payment_methods' ), 99 );

		// Same two requests build the totals table, so the pending rows are hooked here rather than in the render.
		add_action( 'woocommerce_review_order_before_order_total', array( $this, 'print_pending_total_rows' ) );

		// The review table carries no product image; add one without disturbing what the cell already holds.
		add_filter( 'woocommerce_cart_item_name', array( $this, 'add_item_thumbnail' ), 20, 3 );

		// "× 2" reads as arithmetic in a summary, so the popup names the number instead.
		add_filter( 'woocommerce_checkout_cart_item_quantity', array( $this, 'label_item_quantity' ), 20, 3 );

		// A discounted line says what it would have cost, as the product page does.
		add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'add_item_compare_price' ), 20, 3 );

		// A coupon row says what it did, with the code beside it as a tag rather than inside a sentence.
		add_filter( 'woocommerce_cart_totals_coupon_label', array( $this, 'label_coupon_row' ), 20, 2 );
		add_filter( 'woocommerce_cart_totals_coupon_html', array( $this, 'style_coupon_amount' ), 20, 3 );

		// Which codes the shopper typed, so auto-applied promotions keep whatever presentation they ship with.
		add_action( 'woocommerce_applied_coupon', array( $this, 'remember_entered_coupon' ) );
		add_action( 'woocommerce_removed_coupon', array( $this, 'forget_entered_coupon' ) );
		add_filter( 'pre_option_woocommerce_tax_total_display', array( $this, 'itemize_pending_tax' ) );
	}

	/**
	 * Name a total the shopper has not been shown yet, rather than leaving the row out.
	 *
	 * Without this the summary reads Subtotal, Total, both the same, and the figure moves once an
	 * address resolves shipping and tax.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function print_pending_total_rows() {

		if ( ! self::owns_checkout() ) {
			return;
		}

		if ( self::is_shipping_pending() ) {
			printf(
				'<tr class="woocommerce-shipping-totals shipping wcf-icp-pending-row"><th>%1$s</th><td>%2$s</td></tr>',
				wp_kses_post( self::get_shipping_package_label() ),
				wp_kses_post( self::get_pending_total_html() )
			);
		}

		if ( self::is_tax_pending() ) {
			printf(
				'<tr class="tax-total wcf-icp-pending-row"><th>%1$s</th><td>%2$s</td></tr>',
				esc_html( WC()->countries->tax_or_vat() ),
				wp_kses_post( self::get_pending_total_html() )
			);
		}
	}

	/**
	 * Draw no tax row of WooCommerce's own while tax is pending, so the pending pair can sit in order.
	 *
	 * The itemized display draws one row per resolved tax, and a pending tax has resolved none.
	 *
	 * @since x.x.x
	 * @param mixed $value Short-circuited option value.
	 * @return mixed 'itemized' while tax is pending, otherwise the stored setting.
	 */
	public function itemize_pending_tax( $value ) {

		if ( ! self::owns_checkout() || ! self::is_tax_pending() ) {
			return $value;
		}

		return 'itemized';
	}

	/**
	 * What WooCommerce would have called this shipment, so the pending row is not renamed on resolve.
	 *
	 * @since x.x.x
	 * @return string
	 */
	private static function get_shipping_package_label() {

		// Core's own default for a single package; run through its filter so a rename reaches both states.
		$label = _x( 'Shipment', 'shipping packages', 'cartflows-pro' );

		return (string) apply_filters( 'woocommerce_shipping_package_name', $label, '', array(), 1 );
	}

	/**
	 * Whether the order needs shipping that WooCommerce is not ready to show.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private static function is_shipping_pending() {

		if ( ! function_exists( 'WC' ) || ! WC()->cart instanceof WC_Cart ) {
			return false;
		}

		return WC()->cart->needs_shipping() && ! WC()->cart->show_shipping();
	}

	/**
	 * Whether tax applies but no address has been given to work it out from.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private static function is_tax_pending() {

		if ( ! function_exists( 'WC' ) || ! WC()->cart instanceof WC_Cart || ! self::has_customer() || ! wc_tax_enabled() ) {
			return false;
		}

		if ( WC()->cart->display_prices_including_tax() ) {
			return false;
		}

		return '' === (string) WC()->customer->get_taxable_address()[0];
	}

	/**
	 * The stand-in shown in place of a total that no address has resolved yet.
	 *
	 * @since x.x.x
	 * @return string
	 */
	private static function get_pending_total_html() {

		return '<span class="wcf-icp-pending">' . esc_html__( 'Calculated at next step', 'cartflows-pro' ) . '</span>';
	}

	/**
	 * Switch Place Order off when the order needs paying and no gateway can take it.
	 *
	 * @since x.x.x
	 * @param string $html Button markup, as WooCommerce or another plugin has left it.
	 * @return string
	 */
	public function block_order_button( $html ) {

		$html = (string) $html;

		if ( ! self::owns_checkout() || ! self::is_payment_blocked() ) {
			return $html;
		}

		// Late filter, so a gateway may already have replaced the button with its own disabled markup.
		if ( false === strpos( $html, 'aria-disabled' ) ) {
			$html = (string) preg_replace( '/<(button|input)\b/i', '<$1 disabled aria-disabled="true"', $html, 1 );
		}

		return $html . self::get_payment_blocked_note();
	}

	/**
	 * Whether the checkout being rendered belongs to the popup.
	 *
	 * The open render runs before the session is stamped, so the endpoint counts too.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private static function owns_checkout() {

		if ( self::is_instant_request() ) {
			return true;
		}

		$state = self::get_session_state();

		return ! empty( $state['step_id'] );
	}

	/**
	 * Whether the cart needs paying and no gateway is available to pay with.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	public static function is_payment_blocked() {

		if ( ! function_exists( 'WC' ) || ! WC()->cart instanceof WC_Cart ) {
			return false;
		}

		if ( ! WC()->cart->needs_payment() ) {
			return false;
		}

		return empty( WC()->payment_gateways()->get_available_payment_gateways() );
	}

	/**
	 * The line under a switched-off Place Order: why that button in particular cannot be pressed.
	 * The notice above it carries the explanation, so this says only what the button's state means.
	 *
	 * @since x.x.x
	 * @return string
	 */
	private static function get_payment_blocked_note() {

		$note = sprintf(
			'<p class="wcf-icp-pay-blocked">%1$s</p>',
			esc_html__( 'Payment is unavailable, so this button is switched off.', 'cartflows-pro' )
		);

		return (string) apply_filters( 'cartflows_pro_instant_checkout_payment_blocked_note', $note );
	}

	/**
	 * Replace WooCommerce's apology where the popup owns the checkout and no gateway is switched on.
	 * A gateway that is on but unavailable here is a location problem, and keeps core's own wording.
	 *
	 * @since x.x.x
	 * @param string $message WooCommerce's own message.
	 * @return string
	 */
	public function explain_no_payment_methods( $message ) {

		// Gateways that are on but reach no further than this cart are a location problem, which core's own wording already names.
		if ( ! self::owns_checkout() || ! self::has_customer() || self::store_has_payment_gateway() ) {
			return $message;
		}

		// The other string behind this filter asks for an address, which is sound advice; leave it.
		if ( empty( WC()->customer->get_billing_country() ) ) {
			return $message;
		}

		$replacement = sprintf(
			'<strong class="wcf-icp-nopay-title">%1$s</strong><span>%2$s</span><span>%3$s</span>',
			esc_html__( 'This store can’t take payment yet', 'cartflows-pro' ),
			esc_html__( 'No payment methods are switched on, so your order can’t be completed right now. Nothing has been charged and your cart is saved.', 'cartflows-pro' ),
			esc_html__( 'Contact the store to place this order directly, or try again shortly.', 'cartflows-pro' )
		);

		return (string) apply_filters( 'cartflows_pro_instant_checkout_no_payment_message', $replacement, $message );
	}

	/**
	 * Whether the store has at least one payment gateway switched on.
	 *
	 * Reads the enabled flag rather than availability, which is cart-dependent and meaningless in admin.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private static function store_has_payment_gateway() {

		if ( ! function_exists( 'WC' ) ) {
			return true;
		}

		foreach ( WC()->payment_gateways()->payment_gateways() as $gateway ) {
			if ( isset( $gateway->enabled ) && 'yes' === $gateway->enabled ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Active Modern Cart version when it is too old to sit alongside the popup.
	 *
	 * Empty when Modern Cart is inactive or new enough, so callers have nothing to warn about.
	 *
	 * @since x.x.x
	 * @return string
	 */
	private static function outdated_modern_cart_version() {

		if ( ! defined( 'MODERNCART_VER' ) ) {
			return '';
		}

		$version = constant( 'MODERNCART_VER' );

		if ( ! is_string( $version ) || '' === $version ) {
			return '';
		}

		return version_compare( $version, self::MODERN_CART_MIN_VERSION, '<' ) ? $version : '';
	}

	/**
	 * Replace the QuickBuy summary's line items on every totals refresh, while the popup owns the session.
	 *
	 * @param array<string, string> $fragments Order-review fragments keyed by selector.
	 * @return array<string, string>
	 */
	public function add_strip_fragment( $fragments ) {

		$state = self::get_session_state();

		if ( ! empty( $state['step_id'] ) && is_array( $fragments ) ) {
			$fragments['.wcf-icp-strip-items'] = self::render_strip_items();
			$fragments['.wcf-icp-total-lead']  = self::render_total_lead();
			$fragments['.wcf-icp-total-rows']  = self::render_total_rows();
		}

		return $fragments;
	}

	/**
	 * The figures on QuickBuy's pinned bar: the order total and how many items it covers.
	 *
	 * @since x.x.x
	 * @return string
	 */
	public static function render_total_lead() {

		$cart  = function_exists( 'WC' ) ? WC()->cart : null;
		$total = $cart instanceof WC_Cart ? $cart->get_total() : '';
		$count = $cart instanceof WC_Cart ? $cart->get_cart_contents_count() : 0;

		ob_start();
		echo '<span class="wcf-icp-total-lead" data-wcf-icp-total-lead>';
		echo '<span class="wcf-icp-total-amount">' . wp_kses_post( is_string( $total ) ? $total : '' ) . '</span>';
		printf(
			'<span class="wcf-icp-total-count">%s</span>',
			esc_html(
				sprintf(
					/* translators: %s: number of items in the cart. */
					_n( '%s item', '%s items', $count, 'cartflows-pro' ),
					number_format_i18n( $count )
				)
			)
		);
		echo '</span>';

		return (string) ob_get_clean();
	}

	/**
	 * The totals behind the bar: the same lines the summary table carries, including the pending pair.
	 *
	 * @since x.x.x
	 * @return string
	 */
	public static function render_total_rows() {

		$cart = function_exists( 'WC' ) ? WC()->cart : null;

		if ( ! $cart instanceof WC_Cart ) {
			return '<div class="wcf-icp-total-rows" data-wcf-icp-total-rows></div>';
		}

		$row = static function ( $label, $value, $pending = false ) {
			printf(
				'<div class="wcf-icp-total-row%1$s"><span>%2$s</span><span>%3$s</span></div>',
				esc_attr( $pending ? ' is-pending' : '' ),
				esc_html( $label ),
				wp_kses_post( $value )
			);
		};

		ob_start();
		echo '<div class="wcf-icp-total-rows" data-wcf-icp-total-rows>';

		$row( __( 'Subtotal', 'cartflows-pro' ), $cart->get_cart_subtotal() );

		if ( self::is_shipping_pending() ) {
			$row( self::get_shipping_package_label(), self::get_pending_total_html(), true );
		} elseif ( $cart->needs_shipping() && $cart->show_shipping() ) {
			$row( self::get_shipping_package_label(), wc_price( (float) $cart->get_shipping_total() ) );
		}

		if ( self::is_tax_pending() ) {
			$row( WC()->countries->tax_or_vat(), self::get_pending_total_html(), true );
		} elseif ( wc_tax_enabled() && ! $cart->display_prices_including_tax() && (float) $cart->get_taxes_total() > 0 ) {
			$row( WC()->countries->tax_or_vat(), wc_price( (float) $cart->get_taxes_total() ) );
		}

		echo '</div>';

		return (string) ob_get_clean();
	}

	/**
	 * Remember a coupon the shopper entered into the form.
	 *
	 * Auto-applied promotions reach the cart through the same action, so the posted field is what
	 * separates them: only the form sends one, and only its coupon gets the popup's own presentation.
	 *
	 * @since x.x.x
	 * @param string $code Coupon code.
	 * @return void
	 */
	public function remember_entered_coupon( $code ) {

		if ( ! self::owns_checkout() || ! self::has_session() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WC_AJAX::apply_coupon() checks the form's nonce before firing this.
		if ( ! isset( $_POST['coupon_code'] ) ) {
			return;
		}

		$state = self::get_session_state();
		$codes = isset( $state['coupons'] ) && is_array( $state['coupons'] ) ? $state['coupons'] : array();
		$code  = wc_format_coupon_code( (string) $code );

		if ( ! in_array( $code, $codes, true ) ) {
			$codes[] = $code;
		}

		$state['coupons'] = $codes;

		WC()->session->set( self::SESSION_KEY, $state );
	}

	/**
	 * Forget a coupon once it is off the cart again.
	 *
	 * @since x.x.x
	 * @param string $code Coupon code.
	 * @return void
	 */
	public function forget_entered_coupon( $code ) {

		if ( ! self::has_session() ) {
			return;
		}

		$state = self::get_session_state();

		if ( empty( $state['coupons'] ) || ! is_array( $state['coupons'] ) ) {
			return;
		}

		$state['coupons'] = array_values( array_diff( $state['coupons'], array( wc_format_coupon_code( (string) $code ) ) ) );

		WC()->session->set( self::SESSION_KEY, $state );
	}

	/**
	 * Did the shopper enter this code, rather than a promotion applying itself?
	 *
	 * @since x.x.x
	 * @param string $code Coupon code.
	 * @return bool
	 */
	private static function is_entered_coupon( $code ) {

		$state = self::get_session_state();
		$codes = isset( $state['coupons'] ) && is_array( $state['coupons'] ) ? $state['coupons'] : array();

		return in_array( wc_format_coupon_code( (string) $code ), $codes, true );
	}

	/**
	 * Show the discount an entered coupon gave, and leave the control to the card below.
	 *
	 * @since x.x.x
	 * @param string $html            Row value markup.
	 * @param mixed  $coupon          Coupon the row belongs to.
	 * @param string $discount_amount Just the amount, without the remove control.
	 * @return string
	 */
	public function style_coupon_amount( $html, $coupon = null, $discount_amount = '' ) {

		if ( ! self::owns_checkout() || ! $coupon instanceof WC_Coupon || ! self::is_entered_coupon( $coupon->get_code() ) ) {
			return (string) $html;
		}

		return '<span class="wcf-icp-discount">' . $discount_amount . '</span>';
	}

	/**
	 * Name what a coupon row is, and show its code as a tag rather than inside a sentence.
	 *
	 * @since x.x.x
	 * @param string $label  Row label.
	 * @param mixed  $coupon Coupon the row belongs to.
	 * @return string
	 */
	public function label_coupon_row( $label, $coupon = null ) {

		if ( ! self::owns_checkout() || ! $coupon instanceof WC_Coupon || ! self::is_entered_coupon( $coupon->get_code() ) ) {
			return (string) $label;
		}

		$code = $coupon->get_code();

		return sprintf(
			'%1$s<span class="wcf-icp-coupon-code" data-code="%4$s"><span class="wcf-icp-coupon-code-text">%2$s</span><a href="%3$s" class="woocommerce-remove-coupon wcf-icp-coupon-remove" data-coupon="%4$s" aria-label="%5$s">&times;</a></span>',
			esc_html__( 'Discount', 'cartflows-pro' ),
			esc_html( $code ),
			esc_url( add_query_arg( 'remove_coupon', rawurlencode( $code ), wc_get_checkout_url() ) ),
			esc_attr( $code ),
			esc_attr(
				sprintf(
					/* translators: %s: the coupon code the shopper entered. */
					__( 'Remove %s coupon', 'cartflows-pro' ),
					wc_format_coupon_code( $code )
				)
			)
		);
	}

	/**
	 * Prefix a cart line's name with its product image.
	 *
	 * Only the name is wrapped: the quantity and the item meta the same cell carries are left alone.
	 *
	 * @since x.x.x
	 * @param string               $name          Product name markup.
	 * @param array<string, mixed> $cart_item     Cart item.
	 * @param string               $cart_item_key Cart item key.
	 * @return string
	 */
	public function add_item_thumbnail( $name, $cart_item = array(), $cart_item_key = '' ) {

		if ( ! self::owns_checkout() ) {
			return (string) $name;
		}

		$product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;

		if ( ! $product instanceof WC_Product ) {
			return (string) $name;
		}

		$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image( 'woocommerce_gallery_thumbnail' ), $cart_item, $cart_item_key );

		return '<span class="wcf-icp-item"><span class="wcf-icp-item-thumb" aria-hidden="true">'
			. wp_kses_post( is_string( $thumbnail ) ? $thumbnail : '' )
			. '</span><span class="wcf-icp-item-name">' . wp_kses_post( (string) $name ) . '</span></span>';
	}

	/**
	 * Name the quantity rather than printing it as a multiplication.
	 *
	 * @since x.x.x
	 * @param string               $html          Quantity markup.
	 * @param array<string, mixed> $cart_item     Cart item.
	 * @param string               $cart_item_key Cart item key.
	 * @return string
	 */
	public function label_item_quantity( $html, $cart_item = array(), $cart_item_key = '' ) {

		if ( ! self::owns_checkout() ) {
			return (string) $html;
		}

		$quantity = isset( $cart_item['quantity'] ) ? absint( $cart_item['quantity'] ) : 0;

		return sprintf(
			'<strong class="product-quantity">%s</strong>',
			esc_html(
				sprintf(
					/* translators: %s: how many of this product are in the cart. */
					__( 'Qty %s', 'cartflows-pro' ),
					number_format_i18n( $quantity )
				)
			)
		);
	}

	/**
	 * Say what a discounted line would have cost, beside what it does.
	 *
	 * Keyed on the product's own regular price, so a sale, a bump's custom price and a coupon that
	 * marks a line down all read the same way, and a line at full price gains nothing.
	 *
	 * @since x.x.x
	 * @param string               $subtotal      Line subtotal markup.
	 * @param array<string, mixed> $cart_item     Cart item.
	 * @param string               $cart_item_key Cart item key.
	 * @return string
	 */
	public function add_item_compare_price( $subtotal, $cart_item = array(), $cart_item_key = '' ) {

		// A blanked subtotal leaves nothing to strike through.
		if ( ! self::owns_checkout() || '' === trim( wp_strip_all_tags( (string) $subtotal ) ) ) {
			return (string) $subtotal;
		}

		$product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;

		if ( ! $product instanceof WC_Product || ! WC()->cart instanceof WC_Cart ) {
			return (string) $subtotal;
		}

		$regular  = (float) $product->get_regular_price();
		$quantity = isset( $cart_item['quantity'] ) ? absint( $cart_item['quantity'] ) : 0;

		if ( $quantity < 1 || $regular <= 0 || $regular <= (float) $product->get_price() ) {
			return (string) $subtotal;
		}

		$now = self::get_line_total_at_price( $product, (float) $product->get_price(), $quantity );
		$was = self::get_line_total_at_price( $product, $regular, $quantity );

		// A subtotal a plugin re-aggregated (a bundle container) no longer matches the line's own price.
		if ( $was <= 0 || abs( $now - self::get_cart_line_total( $cart_item ) ) > 0.05 ) {
			return (string) $subtotal;
		}

		// WooCommerce's own formatter, so the struck figure carries the same wording a screen reader hears elsewhere.
		return (string) wc_format_sale_price( wc_price( $was ), (string) $subtotal );
	}

	/**
	 * What a line would come to at a given unit price, taxed the way every other total here is.
	 *
	 * @since x.x.x
	 * @param WC_Product $product  Product on the line.
	 * @param float      $price    Unit price to total up.
	 * @param int        $quantity How many.
	 * @return float
	 */
	private static function get_line_total_at_price( $product, $price, $quantity ) {

		if ( ! $product->is_taxable() ) {
			return (float) $price * $quantity;
		}

		$args = array(
			'qty'   => $quantity,
			'price' => $price,
		);

		return WC()->cart instanceof WC_Cart && WC()->cart->display_prices_including_tax()
			? (float) wc_get_price_including_tax( $product, $args )
			: (float) wc_get_price_excluding_tax( $product, $args );
	}

	/**
	 * What the cart itself charged for a line, taxed the way every other total here is.
	 *
	 * @since x.x.x
	 * @param array<string, mixed> $cart_item Cart item.
	 * @return float
	 */
	private static function get_cart_line_total( $cart_item ) {

		$total = isset( $cart_item['line_subtotal'] ) && is_numeric( $cart_item['line_subtotal'] ) ? (float) $cart_item['line_subtotal'] : 0.0;

		if ( WC()->cart instanceof WC_Cart && WC()->cart->display_prices_including_tax() && isset( $cart_item['line_subtotal_tax'] ) && is_numeric( $cart_item['line_subtotal_tax'] ) ) {
			$total += (float) $cart_item['line_subtotal_tax'];
		}

		return $total;
	}

	/**
	 * The QuickBuy summary as one row per cart line — thumbnail, name x qty, line price.
	 *
	 * @return string
	 */
	public static function render_strip_items() {

		$cart = function_exists( 'WC' ) ? WC()->cart : null;

		ob_start();
		echo '<div class="wcf-icp-strip-items" data-wcf-icp-strip-items>';

		if ( $cart instanceof WC_Cart ) {
			foreach ( $cart->get_cart() as $key => $item ) {
				// Never filtered with a null default: a callback type-hinting WC_Product would fatal the
				// whole update_order_review response, and the isset check already covers a missing key.
				if ( ! isset( $item['data'] ) ) {
					continue;
				}

				// Same filters, and the same guards, as the review order table one pane over — without them
				// this strip disagrees with it about which lines exist, what they are called and what they cost.
				$product  = apply_filters( 'woocommerce_cart_item_product', $item['data'], $item, $key );
				$quantity = isset( $item['quantity'] ) ? absint( $item['quantity'] ) : 0;

				if ( ! $product instanceof WC_Product || ! $product->exists() || $quantity <= 0 ) {
					continue;
				}

				if ( ! apply_filters( 'woocommerce_checkout_cart_item_visible', true, $item, $key ) ) {
					continue;
				}

				$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image( 'woocommerce_gallery_thumbnail' ), $item, $key );
				// Filtered off an empty default rather than WooCommerce's 'cart_item': this row is a div in a
				// grid, not a table row, so importing that class invites unrelated theme rules onto the strip.
				$row_class = apply_filters( 'woocommerce_cart_item_class', '', $item, $key );
				$row_class = is_string( $row_class ) ? trim( $row_class ) : '';
				$name      = apply_filters( 'woocommerce_cart_item_name', $product->get_name(), $item, $key );
				$subtotal  = apply_filters( 'woocommerce_cart_item_subtotal', $cart->get_product_subtotal( $product, $quantity ), $item, $key );

				echo '<div class="' . esc_attr( trim( 'wcf-icp-strip-row ' . $row_class ) ) . '">';
				echo '<div class="wcf-icp-strip-thumb" aria-hidden="true">' . wp_kses_post( is_string( $thumbnail ) ? $thumbnail : '' ) . '</div>';
				echo '<div class="wcf-icp-strip-name">' . wp_kses_post( is_string( $name ) ? $name : $product->get_name() ) . ' <span class="wcf-icp-strip-qty">&times;&nbsp;' . esc_html( (string) $quantity ) . '</span></div>';
				echo '<div class="wcf-icp-strip-line-price">' . wp_kses_post( is_string( $subtotal ) ? $subtotal : (string) $cart->get_product_subtotal( $product, $quantity ) ) . '</div>';
				echo '</div>';
			}
		}

		echo '</div>';

		return (string) ob_get_clean();
	}

	/**
	 * Swap a variable bump's "Choose a variation" modal link for inline attribute dropdowns.
	 *
	 * The popup never loads checkout.js, so the Quick View modal can't open. Instead the shopper
	 * picks attributes here and instant-checkout.js resolves the variation client-side from the
	 * embedded data, then writes it into the bump checkbox the existing add handler already reads.
	 *
	 * @param string     $html       Original modal-trigger markup.
	 * @param WC_Product $product    Bump product.
	 * @param string     $ob_id      Order bump ID.
	 * @param int|string $product_id Configured (parent) product ID.
	 * @return string
	 */
	public static function render_bump_variation_field( $html, $product, $ob_id, $product_id ) {

		if ( ! $product instanceof WC_Product_Variable ) {
			return $html;
		}

		$attributes = $product->get_variation_attributes();

		if ( empty( $attributes ) ) {
			return $html;
		}

		$variations = array();

		foreach ( $product->get_available_variations( 'array' ) as $variation ) {
			if ( ! is_array( $variation ) ) {
				continue;
			}

			$variations[] = array(
				'variation_id' => absint( $variation['variation_id'] ),
				'attributes'   => is_array( $variation['attributes'] ) ? $variation['attributes'] : array(),
				'in_stock'     => (bool) $variation['is_in_stock'],
			);
		}

		ob_start();
		echo '<div class="wcf-icp-bump-variations is-incomplete" data-ob-id="' . esc_attr( (string) $ob_id ) . '" data-product-id="' . esc_attr( (string) $product_id ) . '" data-variations="' . esc_attr( (string) wp_json_encode( $variations ) ) . '">';

		foreach ( $attributes as $attribute_name => $options ) {
			$label = wc_attribute_label( $attribute_name, $product );
			echo '<label class="wcf-icp-bump-variation-row">';
			echo '<span class="wcf-icp-bump-variation-label">' . esc_html( $label ) . '</span>';
			wc_dropdown_variation_attribute_options(
				array(
					'options'          => $options,
					'attribute'        => $attribute_name,
					'product'          => $product,
					'name'             => 'attribute_' . sanitize_title( $attribute_name ),
					'class'            => 'wcf-icp-bump-attr',
					/* translators: %s: attribute name. */
					'show_option_none' => sprintf( __( 'Choose %s', 'cartflows-pro' ), $label ),
				)
			);
			echo '</label>';
		}

		echo '</div>';

		return (string) ob_get_clean();
	}

	/**
	 * Is a WooCommerce session available to read or write?
	 *
	 * @return bool
	 */
	private static function has_session() {
		return function_exists( 'WC' ) && WC()->session instanceof WC_Session;
	}

	/**
	 * Is a WooCommerce customer available to read an address from?
	 *
	 * @since x.x.x
	 * @return bool
	 */
	private static function has_customer() {
		return function_exists( 'WC' ) && WC()->customer instanceof WC_Customer;
	}

	/**
	 * Popup state for the current session.
	 *
	 * Empty when no session exists, so programmatic order creation (CLI, cron, importers) is a no-op.
	 *
	 * @return array<string, mixed>
	 */
	public static function get_session_state() {

		if ( ! self::has_session() ) {
			return array();
		}

		$state = WC()->session->get( self::SESSION_KEY );

		return is_array( $state ) ? $state : array();
	}

	/**
	 * Keep the pre-popup cart so a dismissed popup can hand it back.
	 *
	 * Product objects are stripped as WC's own session storage does; the close endpoint rehydrates them.
	 *
	 * @param array<string, array<string, mixed>> $contents Cart contents captured before the popup took over.
	 * @param array<int, string>                  $coupons  Applied coupon codes captured with them.
	 * @return void
	 */
	public static function set_session_backup( $contents, $coupons ) {

		if ( ! self::has_session() ) {
			return;
		}

		foreach ( $contents as &$item ) {
			unset( $item['data'] );
		}
		unset( $item );

		$state                = self::get_session_state();
		$state['cart_backup'] = array(
			'contents' => $contents,
			'coupons'  => $coupons,
			// The lines the popup owns. Taken here because the cart holds only the Buy Now product at this point.
			'popup'    => self::get_cart_quantities(),
		);

		WC()->session->set( self::SESSION_KEY, $state );
	}

	/**
	 * Quantity of every line now in the cart, keyed by cart item key.
	 *
	 * @return array<string, int>
	 */
	private static function get_cart_quantities() {

		$quantities = array();

		foreach ( WC()->cart->get_cart() as $key => $item ) {
			$quantities[ (string) $key ] = is_array( $item ) && isset( $item['quantity'] ) ? (int) $item['quantity'] : 0;
		}

		return $quantities;
	}

	/**
	 * Record a line the popup added after it opened, so restore can take it back out.
	 *
	 * Order bumps go in through CartFlows' own endpoint rather than through this module, so the line is claimed from the add itself
	 * instead of being re-derived on dismiss — by then the cart no longer says who put it there.
	 *
	 * @param string $cart_item_key Key of the line just added.
	 * @param int    $product_id    Product added.
	 * @param int    $quantity      Quantity added.
	 * @return void
	 */
	public function track_popup_cart_item( $cart_item_key, $product_id = 0, $quantity = 0 ) {

		if ( ! self::has_session() || ! self::is_popup_owned_request() ) {
			return;
		}

		$state  = self::get_session_state();
		$backup = self::get_session_backup();

		if ( empty( $state['step_id'] ) || null === $backup ) {
			return;
		}

		$owned = isset( $backup['popup'] ) && is_array( $backup['popup'] ) ? $backup['popup'] : array();
		$key   = (string) $cart_item_key;

		$owned[ $key ] = ( isset( $owned[ $key ] ) ? (int) $owned[ $key ] : 0 ) + max( 0, (int) $quantity );

		$backup['popup']      = $owned;
		$state['cart_backup'] = $backup;

		WC()->session->set( self::SESSION_KEY, $state );
	}

	/**
	 * Is the current request one the open popup is driving?
	 *
	 * This module's own endpoints, plus the order-bump and Checkout Offer endpoints the popup calls directly — between them the
	 * only ways a line reaches the cart while the dialog is up. The posted marker is accepted too, for anything that submits the
	 * adopted form. A line missed here is not subtracted on dismiss, so the shopper keeps something they never paid for.
	 *
	 * @return bool
	 */
	private static function is_popup_owned_request() {

		if ( self::is_instant_request() ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Routing key and marker only; each endpoint verifies its own nonce.
		$action = isset( $_POST['action'] ) ? sanitize_text_field( wp_unslash( $_POST['action'] ) ) : '';

		if ( in_array( $action, array( 'wcf_bump_order_process', 'wcf_update_order_bump_qty', 'wcf_add_to_cart' ), true ) ) {
			return true;
		}

		$state = self::get_session_state();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- As above.
		$posted = isset( $_POST[ self::ORDER_META ] ) ? absint( $_POST[ self::ORDER_META ] ) : 0;

		return 0 !== $posted && isset( $state['step_id'] ) && absint( $state['step_id'] ) === $posted;
	}

	/**
	 * The cart kept when the popup opened, or null when no popup session is active.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function get_session_backup() {

		$state = self::get_session_state();

		return isset( $state['cart_backup'] ) && is_array( $state['cart_backup'] ) ? $state['cart_backup'] : null;
	}

	/**
	 * Forget the kept cart.
	 *
	 * @return void
	 */
	public static function clear_session_backup() {

		if ( ! self::has_session() ) {
			return;
		}

		$state = self::get_session_state();

		unset( $state['cart_backup'] );

		WC()->session->set( self::SESSION_KEY, $state );
	}

	/**
	 * Cart contents with a popup's own lines taken back out.
	 *
	 * Quantity is subtracted rather than the line dropped outright, because a shopper who adds the Buy Now product again outside
	 * the popup lands on the same cart item key — dropping it would take their own line with it.
	 *
	 * @param array<mixed, mixed> $contents Cart contents to subtract from. Read back from the session on some paths, so untyped.
	 * @param array<mixed, mixed> $owned    Quantity the popup contributed, keyed by cart item key. Same.
	 * @return array<int|string, array<string, mixed>>
	 */
	private static function subtract_popup_lines( $contents, $owned ) {

		$lines = array_filter( $contents, 'is_array' );

		foreach ( $owned as $key => $quantity ) {

			$key = (string) $key;

			if ( ! isset( $lines[ $key ] ) ) {
				continue;
			}

			$remaining = ( isset( $lines[ $key ]['quantity'] ) ? (int) $lines[ $key ]['quantity'] : 0 ) - absint( $quantity );

			if ( $remaining > 0 ) {
				$lines[ $key ]['quantity'] = $remaining;
			} else {
				unset( $lines[ $key ] );
			}
		}

		return $lines;
	}

	/**
	 * Hand the kept cart back, then forget it.
	 *
	 * Each line is rehydrated as WC's get_cart_from_session() does; lines whose product is gone are dropped.
	 *
	 * @return void
	 */
	public static function restore_session_backup() {

		$backup = self::get_session_backup();

		if ( null === $backup ) {
			return;
		}

		self::clear_session_backup();

		$stored  = isset( $backup['contents'] ) && is_array( $backup['contents'] ) ? $backup['contents'] : array();
		$coupons = isset( $backup['coupons'] ) && is_array( $backup['coupons'] ) ? $backup['coupons'] : array();

		// Whatever the popup did not put in the cart, the shopper added after abandoning it, so it stays. Its own lines come back out.
		$contents = isset( $backup['popup'] ) ? self::subtract_popup_lines( WC()->cart->get_cart(), (array) $backup['popup'] ) : array();

		// Coupons go back to the snapshot: the pre-popup cart is handed back as it was, so a coupon applied or removed inside the
		// popup does not survive it. The known gap is a coupon the shopper applied elsewhere after abandoning a popup — there is
		// nothing on the cart to say who applied it, and the snapshot is the safer of the two guesses.

		WC()->cart->empty_cart( false );

		WC()->cart->set_cart_contents( $contents );

		foreach ( $stored as $key => $item ) {

			if ( ! is_array( $item ) || isset( $contents[ $key ] ) ) {
				continue;
			}

			$variation_id = isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0;
			$product_id   = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
			$product      = wc_get_product( $variation_id ? $variation_id : $product_id );

			if ( ! $product || ! $product->exists() ) {
				continue;
			}

			// The same filter WC_Cart_Session::get_cart_from_session() runs, because plugins that keep an item's real price in its cart item data restore it here and nowhere else — Product Bundles has no calculate-totals hook to fall back on.
			$restored = apply_filters( 'woocommerce_get_cart_item_from_session', array_merge( $item, array( 'data' => $product ) ), $item, $key );

			// A callback that drops the product object would fatal the totals run; WC repairs the same case rather than trusting the filter.
			if ( ! isset( $restored['data'] ) || ! $restored['data'] instanceof WC_Product ) {
				$restored['data'] = $product;
			}

			$contents[ $key ] = $restored;

			// Set inside the loop as WC does: a child line's callback resolves its container by reading the live cart, so the container has to be in it already.
			WC()->cart->set_cart_contents( $contents );
		}

		WC()->cart->set_applied_coupons( array_unique( array_map( 'strval', $coupons ) ) );

		// woocommerce_cart_loaded_from_session is deliberately not fired: both callers run at
		// template_redirect, where WC already fired it at wp_loaded, and listeners that treat it as a
		// cart-load event would run twice. Orphan cleanup that misses here runs on the next page load.
		WC()->cart->calculate_totals();

		self::sync_persistent_cart();
	}

	/**
	 * Write the cart as it now stands to the persistent cart.
	 *
	 * WooCommerce refreshes `_woocommerce_persistent_cart_{blog}` only from its add/remove/quantity
	 * hooks, none of which a set_cart_contents() restore fires, so every path that hands a cart back
	 * has to do it explicitly. Left stale, a logged-in shopper's emptied session cart falls through
	 * to user meta on the next request and the popup's products reappear.
	 *
	 * Constructing the session object registers nothing — WC_Cart_Session does that in init().
	 *
	 * @return void
	 */
	public static function sync_persistent_cart() {

		if ( ! class_exists( 'WC_Cart_Session' ) || ! WC()->cart instanceof WC_Cart ) {
			return;
		}

		$cart_session = new WC_Cart_Session( WC()->cart );
		$cart_session->persistent_cart_update();
	}

	/**
	 * Record which step the popup is running.
	 *
	 * @param int $step_id Checkout step ID.
	 * @return void
	 */
	public static function set_session_step( $step_id ) {

		if ( ! self::has_session() ) {
			return;
		}

		$state            = self::get_session_state();
		$state['step_id'] = absint( $step_id );

		WC()->session->set( self::SESSION_KEY, $state );
	}

	/**
	 * Clear the popup state.
	 *
	 * @return void
	 */
	public static function clear_session_state() {

		if ( ! self::has_session() ) {
			return;
		}

		WC()->session->set( self::SESSION_KEY, null );
	}

	/**
	 * Mark orders that came through the popup.
	 *
	 * Stores the resolved step ID on the order object (not update_post_meta) so it is written once and stays correct under HPOS.
	 *
	 * Two signals must agree: the session proves the popup opened for a step this product resolves to (unforgeable),
	 * and the posted field proves this order is the popup's — the session outlives a dismissed popup, so alone it would stamp unrelated later orders.
	 *
	 * @param WC_Order $order Order being created.
	 * @return void
	 */
	public function tag_order( $order ) {

		$state   = self::get_session_state();
		$step_id = isset( $state['step_id'] ) ? absint( $state['step_id'] ) : 0;

		if ( ! $step_id ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WC_Checkout::process_checkout() verifies woocommerce-process-checkout-nonce before this action fires.
		$posted = isset( $_POST[ self::ORDER_META ] ) ? absint( $_POST[ self::ORDER_META ] ) : 0;

		if ( $posted !== $step_id ) {
			return;
		}

		$order->update_meta_data( self::ORDER_META, (string) $step_id );
	}

	/**
	 * Hand the kept cart back once the popup's order is paid for, or needs no payment.
	 *
	 * On the filters WooCommerce applies only after process_payment() returns success, or for a zero-total order. Clearing from
	 * tag_order() instead released the kept cart at order *creation* — after a declined card the order existed, nothing was
	 * bought, and the shopper's cart was already unrecoverable.
	 *
	 * @param mixed        $passthrough Filter value, returned untouched.
	 * @param int|WC_Order $order       Order ID or order object, depending on the filter.
	 * @return mixed
	 */
	public function release_state_after_payment( $passthrough, $order ) {

		$order = $order instanceof WC_Order ? $order : wc_get_order( absint( $order ) );

		// Only the popup's own orders: an unrelated order placed in this session must not consume a live popup's kept cart.
		if ( $order instanceof WC_Order && ! empty( $order->get_meta( self::ORDER_META ) ) ) {

			// Buy Now borrowed the cart and the order holds only what it sold, so the rest still has to go back. It cannot
			// be handed back here: every thank-you page empties the cart before rendering. Park it for that page instead,
			// and still clear the popup state now so nothing treats the next request as popup-owned.
			$backup = self::get_session_backup();

			// Kept as its own entry rather than merged into any earlier one: each belongs to a different order, and only
			// its own order says whether its lines were sold. Nothing to hand back means nothing to park.
			if ( null !== $backup && ! empty( $backup['contents'] ) ) {
				$parks    = self::get_parked_carts();
				$contents = is_array( $backup['contents'] ) ? $backup['contents'] : array();

				// This snapshot was the live cart, and an unconsumed park's order still had its own line sitting in it.
				// That line belongs to that order, not the shopper, so it does not get parked a second time here.
				foreach ( $parks as $earlier ) {
					$contents = self::subtract_popup_lines( $contents, (array) ( isset( $earlier['popup'] ) ? $earlier['popup'] : array() ) );
				}

				if ( ! empty( $contents ) ) {
					$parks[] = array(
						'contents'  => $contents,
						'popup'     => isset( $backup['popup'] ) ? $backup['popup'] : array(),
						'order_id'  => $order->get_id(),
						'parked_at' => time(),
					);

					WC()->session->set( self::RESTORE_KEY, $parks );
				}
			}

			self::clear_session_state();
		}

		return $passthrough;
	}

	/**
	 * Carts parked by finished popup orders, oldest first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function get_parked_carts() {

		$parks = self::has_session() ? WC()->session->get( self::RESTORE_KEY ) : array();

		if ( ! is_array( $parks ) || empty( $parks ) ) {
			return array();
		}

		return $parks;
	}

	/**
	 * Has this park's order finished deciding itself?
	 *
	 * @param array<string, mixed> $park Parked cart.
	 * @return bool
	 */
	private static function park_is_ready( $park ) {

		$order = wc_get_order( isset( $park['order_id'] ) ? absint( $park['order_id'] ) : 0 );

		$waited = time() - absint( isset( $park['parked_at'] ) ? $park['parked_at'] : 0 );

		// Wait while payment is in flight — a redirect gateway reaches the success filter on its way out — but not forever:
		// abandoned at the gateway, an order sits pending for good wherever hold-stock is off.
		return ! ( $order instanceof WC_Order && $order->has_status( array( 'pending', 'checkout-draft' ) ) && $waited < HOUR_IN_SECONDS );
	}

	/**
	 * Hand the kept cart back on the first ordinary page.
	 *
	 * Never on a page some other component owns: a cart handed back there is emptied or replaced as that page renders, and
	 * the park is spent for nothing. The copy waits instead — it costs the shopper a click, not their cart.
	 *
	 * @return void
	 */
	public function restore_cart_after_order() {

		if ( ! self::has_session() || empty( WC()->session->get( self::RESTORE_KEY ) ) ) {
			return;
		}

		// The store checkout is the one step that keeps the shopper's own cart: preconfigured_cart_data() skips it rather
		// than installing the step's products, and it says "your cart is currently empty" when there is nothing to sell.
		// So it is the one step where the hand-back belongs.
		$store_step = self::get_checkout_step_id( self::get_store_checkout_flow_id() );

		// Tested before everything below, because CartFlows makes is_checkout() true on any checkout step.
		$on_store_checkout = $store_step > 0 && is_singular( CARTFLOWS_STEP_POST_TYPE ) && get_queried_object_id() === $store_step;

		// Everywhere else another component is already deciding what the cart holds: the remaining steps empty it on the
		// way past or install their own at wp:1, WooCommerce owns checkout, pay and order-received, and the order details
		// shortcode empties wherever it is placed.
		if ( ! $on_store_checkout && ( is_singular( CARTFLOWS_STEP_POST_TYPE ) || is_checkout()
			|| null !== filter_input( INPUT_GET, 'wcf-order', FILTER_SANITIZE_NUMBER_INT ) ) ) {
			return;
		}

		self::consume_parked_cart();
	}

	/**
	 * Hand back the cart a paid popup order borrowed.
	 *
	 * Also called as the next popup opens, so a shopper who never came back to the site still gets it, and a second Buy Now
	 * cannot park an empty cart over it.
	 *
	 * @return bool Whether a parked cart was handed back.
	 */
	public static function consume_parked_cart() {

		if ( ! self::has_session() ) {
			return false;
		}

		$parks = self::get_parked_carts();

		if ( empty( $parks ) ) {
			return false;
		}

		// A popup is live — in another tab, or this request. It owns the cart, and its own close or order hands it back.
		if ( null !== self::get_session_backup() ) {
			return false;
		}

		$ready   = array();
		$waiting = array();

		foreach ( $parks as $park ) {
			if ( self::park_is_ready( $park ) ) {
				$ready[] = $park;
			} else {
				$waiting[] = $park;
			}
		}

		if ( empty( $ready ) ) {
			return false;
		}

		WC()->session->set( self::RESTORE_KEY, $waiting );

		self::merge_parked_lines( $ready );

		return true;
	}

	/**
	 * Put parked lines back alongside whatever the cart holds now.
	 *
	 * @param array<int, array<string, mixed>> $parks Parked carts whose orders have finished.
	 * @return void
	 */
	private static function merge_parked_lines( $parks ) {

		$contents = WC()->cart->get_cart();

		foreach ( $parks as $park ) {

			$order = wc_get_order( isset( $park['order_id'] ) ? absint( $park['order_id'] ) : 0 );

			// Only a sale empties the cart. Declined at a redirect gateway, or abandoned there and aged past the grace
			// hour, the shopper never reached a thank-you page and the popup's own lines are still sitting in it.
			$sold = $order instanceof WC_Order && ! $order->has_status( array( 'pending', 'checkout-draft', 'failed', 'cancelled' ) );

			if ( ! $sold ) {
				$contents = self::subtract_popup_lines( $contents, (array) ( isset( $park['popup'] ) ? $park['popup'] : array() ) );
			}

			foreach ( (array) ( isset( $park['contents'] ) ? $park['contents'] : array() ) as $key => $line ) {

				if ( ! is_array( $line ) ) {
					continue;
				}

				// Added rather than compared: these lines left the cart when the popup took it, so anything under the same
				// key arrived afterwards and is the shopper's own.
				if ( isset( $contents[ $key ]['quantity'] ) ) {
					$contents[ $key ]['quantity'] += isset( $line['quantity'] ) ? absint( $line['quantity'] ) : 0;
					continue;
				}

				$variation_id = isset( $line['variation_id'] ) ? absint( $line['variation_id'] ) : 0;
				$product      = wc_get_product( $variation_id ? $variation_id : ( isset( $line['product_id'] ) ? absint( $line['product_id'] ) : 0 ) );

				if ( $product && $product->exists() ) {
					$line['data']     = $product;
					$contents[ $key ] = $line;
				}
			}
		}

		// Whatever the shopper has applied since has to be carried over by hand: empty_cart() clears coupons whichever way
		// it is called. The parked ones are not handed back — a sold order has spent them, and set_applied_coupons() skips
		// the validation apply_coupon() does, so a code that only qualified against the popup's cart would fail at checkout.
		$coupons = WC()->cart->get_applied_coupons();

		WC()->cart->empty_cart( false );

		// Rehydrated the way restore_session_backup() does, because this is the third path that hands a cart back:
		// a parked line's own pricing lives in its cart item data and only this filter puts it back.
		$primed = array();

		WC()->cart->set_cart_contents( $primed );

		foreach ( $contents as $key => $line ) {

			if ( ! isset( $line['data'] ) || ! $line['data'] instanceof WC_Product ) {
				continue;
			}

			$restored = apply_filters( 'woocommerce_get_cart_item_from_session', $line, $line, $key );

			// A callback that drops the product object would fatal the totals run; WC repairs the same case.
			if ( ! isset( $restored['data'] ) || ! $restored['data'] instanceof WC_Product ) {
				$restored['data'] = $line['data'];
			}

			$primed[ $key ] = $restored;

			// Set inside the loop as WC does: a child line's callback resolves its container by reading the live cart.
			WC()->cart->set_cart_contents( $primed );
		}

		WC()->cart->set_applied_coupons( $coupons );
		WC()->cart->calculate_totals();

		self::sync_persistent_cart();
	}

	/**
	 * Whether the popup is set up on the product page being rendered.
	 *
	 * Decided on `wp`, so it already holds where a block theme renders the page body before `wp_enqueue_scripts`.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	public function is_set_up_on_page() {
		return 0 !== $this->step_id;
	}

	/**
	 * Prepare the product page when a Buy Now button applies to it.
	 *
	 * Gated first on a single autoloaded option, so stores without the feature pay only that read.
	 *
	 * @return void
	 */
	public function maybe_setup_product_page() {

		// The order-bump Quick View calls wp() inside its AJAX handler, turning is_product() true mid-request; the Buy Now button belongs on a real product page view, never an AJAX render.
		if ( wp_doing_ajax() || ! self::has_active_flows() || ! is_product() ) {
			return;
		}

		// An inactive licence stops new popups only; post-purchase and cart-restore hooks stay live so in-flight sessions finish cleanly.
		if ( ! cartflows_pro_is_active_license() ) {
			return;
		}

		$product = wc_get_product( get_queried_object_id() );

		if ( ! $product || ! self::is_supported_product( $product ) ) {
			return;
		}

		$this->step_id = self::resolve_step_id( $product->get_id() );

		if ( ! $this->step_id ) {
			return;
		}

		// Three windows so the body between them still reads as a product page: enqueue, the head script print (WC localizes wc_checkout_params there), and wp_footer (Stripe queues scripts there).
		add_action( 'wp_enqueue_scripts', array( $this, 'open_checkout_context' ), -PHP_INT_MAX );
		add_action( 'wp_enqueue_scripts', array( $this, 'close_checkout_context' ), PHP_INT_MAX );
		add_action( 'wp_print_scripts', array( $this, 'open_print_context' ), -PHP_INT_MAX );
		add_action( 'wp_print_scripts', array( $this, 'close_print_context' ), PHP_INT_MAX );
		add_action( 'wp_footer', array( $this, 'force_checkout_context' ), -PHP_INT_MAX );
		add_action( 'wp_print_footer_scripts', array( $this, 'close_checkout_context' ), PHP_INT_MAX );

		// Modern Cart builds its drawer on wp_footer and hides the checkout button when is_checkout() is true, so it is stepped out of the footer window while its footer renders.
		add_action( 'moderncart_slide_out_footer_before', array( $this, 'pause_checkout_context' ), -PHP_INT_MAX );
		add_action( 'moderncart_slide_out_footer_after', array( $this, 'resume_checkout_context' ), PHP_INT_MAX );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// The Checkout Offer's modal, script and localized data are all bound to the checkout step page, which the popup never loads. Priority 99 mirrors where the offer prints itself there.
		if ( self::step_has_checkout_offer( $this->step_id ) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_offer' ), 11 );
			add_action( 'wp_footer', array( $this, 'print_checkout_offer' ), 99 );
		}

		// Printed before checkout.js DOM-ready init so WC and gateways bind to this node; the popup adopts it. See render_form_shell().
		add_action( 'wp_footer', array( $this, 'render_form_shell' ) );

		// checkout.js fires update_checkout on load when is_checkout is '1'; on an empty product-page cart WC returns a session-expired fragment that replaces the pre-bound shell. The popup updates itself on open, so suppress the page-load one.
		add_filter( 'woocommerce_get_script_data', array( $this, 'suppress_page_load_update' ), 10, 2 );

		// woocommerce_after_add_to_cart_button survives Astra's product-summary rewiring. Product Bundles fires it after .bundle_wrap (button on its own line), so use its in-wrapper hook to sit beside Add to cart.
		if ( $product->is_type( 'bundle' ) ) {
			add_action( 'woocommerce_bundles_add_to_cart_button', array( $this, 'render_button' ), 20 );
		} else {
			add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'render_button' ), 9 );
		}
	}

	/**
	 * Enqueue the Checkout Offer's script and styles, and capture its modal.
	 *
	 * Everything the offer reads — _is_wcf_checkout_type(), the global post's ID, _get_wcf_checkout_id() —
	 * is unfilterable, so the step stands in as the global post for the length of this pass.
	 *
	 * @return void
	 */
	public function enqueue_checkout_offer() {

		$step = get_post( $this->step_id );

		if ( ! $step instanceof WP_Post || CARTFLOWS_STEP_POST_TYPE !== $step->post_type || ! class_exists( 'Cartflows_Pre_Checkout_Offer_Product' ) ) {
			return;
		}

		$previous = isset( $GLOBALS['post'] ) && $GLOBALS['post'] instanceof WP_Post ? $GLOBALS['post'] : null;

		$GLOBALS['post'] = $step; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Mirrors Cartflows_Global_Checkout::override_global_checkout(); restored below.

		try {
			$buffer = ob_get_level();

			ob_start();
			Cartflows_Pre_Checkout_Offer_Product::get_instance()->wcf_add_pre_checkout_offer_modal( '' );
			$this->offer_modal = (string) ob_get_clean();

			$dynamic_css = $this->get_checkout_offer_css();
		} finally {
			// Restored even if the offer's renderer throws: leaving the step installed would make _is_wcf_checkout_type() true at
			// wp_footer, where the offer's own priority-99 callback would then print a second modal with the same element IDs.
			if ( $previous instanceof WP_Post ) {
				$GLOBALS['post'] = $previous; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restoring the value saved above.
			} else {
				unset( $GLOBALS['post'] );
			}

			while ( ob_get_level() > $buffer ) {
				ob_end_clean();
			}
		}

		if ( '' === $this->offer_modal ) {
			return;
		}

		wp_enqueue_style(
			'wcf-icp-offer',
			Cartflows_Pro_Utils::get_instance()->get_css_url( 'instant-checkout-offer' ),
			array(),
			CARTFLOWS_PRO_VER
		);

		if ( '' !== $dynamic_css ) {
			wp_add_inline_style( 'wcf-icp-offer', $dynamic_css );
		}

		wp_enqueue_script(
			'wcf-pro-pre-checkout',
			Cartflows_Pro_Utils::get_instance()->get_js_url( 'pre-checkout' ),
			array( 'jquery', 'jquery-ui-dialog' ),
			CARTFLOWS_PRO_VER,
			true
		);

		// The product page never prints CartFlows' global `cartflows` object, which this script reads. Only the two cacheable keys
		// are baked in; its nonces ride with the popup's own AJAX response instead, as the bump and checkout nonces already do —
		// see Cartflows_Pro_Instant_Checkout_Ajax::open(). Merged rather than assigned, so a page that does print it keeps its keys.
		wp_add_inline_script(
			'wcf-pro-pre-checkout',
			'window.cartflows = Object.assign( window.cartflows || {}, ' . wp_json_encode( self::get_offer_localize_data() ) . ' );',
			'before'
		);
	}

	/**
	 * The keys the Checkout Offer's script reads that are safe to bake into a cached page.
	 *
	 * Nothing session-specific belongs here — see the caller. Its own method so the invariant can be pinned by a test.
	 *
	 * @return array<string, string>
	 */
	private static function get_offer_localize_data() {
		return array(
			'ajax_url'         => admin_url( 'admin-ajax.php', 'relative' ),
			'add_to_cart_text' => __( 'Processing...', 'cartflows-pro' ),
		);
	}

	/**
	 * The offer's colour settings as CSS, from the same partial the checkout page renders.
	 *
	 * Only the offer's own block, so none of the checkout page's other dynamic rules reach the popup.
	 *
	 * @return string
	 */
	private function get_checkout_offer_css() {

		$partial = CARTFLOWS_PRO_CHECKOUT_DIR . 'includes/pre-checkout-offer-dynamic-css.php';

		if ( ! is_readable( $partial ) ) {
			return '';
		}

		$checkout_id = $this->step_id;
		$options     = wcf()->options;

		// Validated at output, not just save: step meta also arrives raw from funnel imports and the abilities API, where a colour
		// with `;}` could close the rule and inject markup into the inline <style>. Same gate as get_design_css().
		$colour = static function ( $value ) {
			$hex = sanitize_hex_color( is_string( $value ) ? trim( $value ) : '' );

			return is_string( $hex ) ? $hex : '';
		};

		// A font stack reaches the same inline <style> by the same untrusted path, so it needs the same gate:
		// anything but the characters a family list is made of would close the declaration.
		$font = static function ( $value ) {
			$stack = preg_replace( '/[^A-Za-z0-9 ,\'"_-]/', '', is_string( $value ) ? $value : '' );

			return is_string( $stack ) ? trim( $stack ) : '';
		};

		$output           = '';
		$primary_color    = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-primary-color' ) );
		$base_font_family = $font( $options->get_checkout_meta_value( $checkout_id, 'wcf-base-font-family' ) );

		$pre_checkout_bg_color       = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-bg-color' ) );
		$pre_checkout_model_bg_color = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-model-bg-color' ) );
		$pre_checkout_title_color    = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-title-color' ) );
		$pre_checkout_subtitle_color = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-subtitle-color' ) );
		$pre_checkout_desc_color     = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-desc-color' ) );

		$navbar_color = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-navbar-color' ) );
		$button_color = $colour( $options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-button-color' ) );

		$pre_checkout_navbar_color = ! empty( $navbar_color ) ? $navbar_color : $primary_color;
		$pre_checkout_button_color = ! empty( $button_color ) ? $button_color : $primary_color;

		include $partial;

		return (string) $output;
	}

	/**
	 * Print the Checkout Offer's modal captured during the asset pass.
	 *
	 * @return void
	 */
	public function print_checkout_offer() {

		// Already escaped by the offer's own template; escaping again would break its markup.
		echo $this->offer_modal; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Begin the checkout context for the enqueue pass, ahead of every other wp_enqueue_scripts callback.
	 * WC's load_scripts() and each gateway's payment_scripts() gate on is_checkout(); loading gateways here lets lazy ones register.
	 *
	 * @return void
	 */
	public function open_checkout_context() {

		$this->force_checkout_context();

		WC()->payment_gateways()->get_available_payment_gateways();
	}

	/**
	 * Make is_checkout() true until close_checkout_context() runs.
	 * Opened on wp_print_scripts and wp_footer, where WC localizes wc_checkout_params and gateways queue scripts (Stripe's payment_scripts).
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function force_checkout_context() {

		$this->checkout_forced = true;

		add_filter( 'woocommerce_is_checkout', array( $this, 'force_is_checkout' ), 9999 );
	}

	/**
	 * Open the checkout context for a script print, unless the footer window already holds it open.
	 * A plugin calling wp_print_scripts() inside that window must not close it early.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function open_print_context() {

		if ( $this->checkout_forced ) {
			return;
		}

		$this->print_window_opened = true;

		$this->force_checkout_context();
	}

	/**
	 * Close the checkout context only if open_print_context() opened it.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function close_print_context() {

		if ( ! $this->print_window_opened ) {
			return;
		}

		$this->print_window_opened = false;

		$this->close_checkout_context();
	}

	/**
	 * End the checkout context after the last callback of its pass.
	 * The page body, template_redirect and shutdown (page caches) all see a product page.
	 *
	 * @return void
	 */
	public function close_checkout_context() {

		$this->checkout_forced = false;

		remove_filter( 'woocommerce_is_checkout', array( $this, 'force_is_checkout' ), 9999 );
	}

	/**
	 * Step out of an open checkout context for a section that must read as a product page.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function pause_checkout_context() {

		remove_filter( 'woocommerce_is_checkout', array( $this, 'force_is_checkout' ), 9999 );
	}

	/**
	 * Step back into the checkout context paused by pause_checkout_context(), if one was open.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function resume_checkout_context() {

		if ( $this->checkout_forced ) {
			add_filter( 'woocommerce_is_checkout', array( $this, 'force_is_checkout' ), 9999 );
		}
	}

	/**
	 * The forced answer for is_checkout(), a named callback so removing it never touches another plugin's own true filter.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	public function force_is_checkout() {
		return true;
	}

	/**
	 * Can this product be bought through the popup?
	 *
	 * External is rejected by name, because it points off-site. Grouped needs no test of its own: a grouped parent carries no price,
	 * so is_purchasable() is already false for it. Every other type is handled by forwarding the product form to WC's add-to-cart handler.
	 *
	 * @param WC_Product $product Product object.
	 * @return bool
	 */
	public static function is_supported_product( $product ) {

		if ( $product->is_type( 'external' ) ) {
			return false;
		}

		return $product->is_purchasable();
	}

	/**
	 * Load the on-demand classes for an Instant Checkout request.
	 *
	 * @return void
	 */
	public function maybe_load_classes() {

		if ( ! self::is_instant_request() ) {
			return;
		}

		require_once CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . 'classes/class-cartflows-pro-instant-checkout-render.php';
		require_once CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . 'classes/class-cartflows-pro-instant-checkout-ajax.php';

		Cartflows_Pro_Instant_Checkout_Ajax::get_instance();
	}

	/**
	 * Is the current request one of this module's own AJAX calls?
	 *
	 * Also suppresses the Smart Login overlay, which would otherwise open nested inside the popup.
	 *
	 * @return bool
	 */
	public static function is_instant_request() {

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading the routing key only; each endpoint validates its own request.
		$action = isset( $_GET['wc-ajax'] ) ? sanitize_text_field( wp_unslash( $_GET['wc-ajax'] ) ) : '';

		return 0 === strpos( $action, 'wcf_instant_' );
	}

	/**
	 * Enqueue the popup assets and the design settings.
	 *
	 * @return void
	 */
	public function enqueue_assets() {

		$layout = Cartflows_Pro_Instant_Checkout_Layouts::get_instance()->get_layout_for_step( $this->step_id );
		$theme  = get_template();

		// Stylesheets chain through dependencies so order is always base → layout → theme → layout-theme.
		$previous = 'wcf-icp';

		wp_enqueue_style(
			'wcf-icp',
			CARTFLOWS_PRO_INSTANT_CHECKOUT_URL . 'assets/css/instant-checkout-base.css',
			array(),
			self::get_asset_version( 'assets/css/instant-checkout-base.css' )
		);

		// The bump rules from the checkout stylesheet, scoped to the popup, so bumps look exactly as on the checkout page across every style.
		wp_enqueue_style(
			'wcf-icp-bump',
			Cartflows_Pro_Utils::get_instance()->get_css_url( 'instant-checkout-bump' ),
			array( $previous ),
			CARTFLOWS_PRO_VER
		);
		$previous = 'wcf-icp-bump';

		// The bump checkbox tick is a cartflows-icon glyph; the product page skips CartFlows' frontend styles, so declare the face here or the ticked box renders blank.
		if ( defined( 'CARTFLOWS_URL' ) ) {
			$icon_font = CARTFLOWS_URL . 'assets/fonts/cartflows-icon.woff';
			wp_add_inline_style( 'wcf-icp-bump', '@font-face{font-family:cartflows-icon;src:url("' . esc_url( $icon_font ) . '") format("woff");font-weight:normal;font-style:normal;font-display:block;}' );
		}

		$layout_css = $layout->get_stylesheet();

		if ( '' !== $layout_css && file_exists( $layout_css ) ) {
			wp_enqueue_style(
				'wcf-icp-layout',
				$layout->get_stylesheet_url(),
				array( $previous ),
				self::get_file_version( $layout_css )
			);
			$previous = 'wcf-icp-layout';
		}

		// Optional per-theme compat stylesheet, named after the template dir, loaded only when that theme is active. get_template() is a WP-sanitised bare dir name.
		$theme_compat = 'assets/css/instant-checkout-' . $theme . '.css';

		if ( file_exists( CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . $theme_compat ) ) {
			wp_enqueue_style(
				'wcf-icp-theme',
				CARTFLOWS_PRO_INSTANT_CHECKOUT_URL . $theme_compat,
				array( $previous ),
				self::get_asset_version( $theme_compat )
			);
			$previous = 'wcf-icp-theme';
		}

		// Same idea for a rule set that only one layout needs on one theme.
		$layout_theme = 'assets/css/layout-' . $layout->get_slug() . '-' . $theme . '.css';

		if ( file_exists( CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . $layout_theme ) ) {
			wp_enqueue_style(
				'wcf-icp-layout-theme',
				CARTFLOWS_PRO_INSTANT_CHECKOUT_URL . $layout_theme,
				array( $previous ),
				self::get_asset_version( $layout_theme )
			);
		}

		wp_enqueue_script(
			'wcf-icp',
			CARTFLOWS_PRO_INSTANT_CHECKOUT_URL . 'assets/js/instant-checkout.js',
			array( 'jquery' ),
			self::get_asset_version( 'assets/js/instant-checkout.js' ),
			true
		);

		// wc-checkout is registered but only auto-enqueued on is_checkout(); enqueue it manually — WC then localizes wc_checkout_params for it.
		wp_enqueue_script( 'wc-checkout' );

		// Gateways enqueue the saved-card script from payment_fields(), which the popup runs over wc-ajax; without it Stripe reads the unticked "new card" radio as a saved card and never creates one.
		foreach ( WC()->payment_gateways()->get_available_payment_gateways() as $gateway ) {
			if ( $gateway->supports( 'tokenization' ) ) {
				$gateway->tokenization_script();
				break;
			}
		}

		wp_localize_script(
			'wcf-icp',
			'instantCheckout',
			array(
				'i18n'             => array(
					/* translators: %s: the field's own visible label, for example Email address. */
					'fieldRequired'     => __( 'Enter your %s.', 'cartflows-pro' ),
					/* translators: %s: the field's own visible label, for example Email address. */
					'fieldInvalid'      => __( 'Enter a valid %s.', 'cartflows-pro' ),
					/* translators: %1$s: current step number, %2$s: how many steps there are, %3$s: the step's name. */
					'stepStatus'        => __( 'Step %1$s of %2$s: %3$s', 'cartflows-pro' ),
					'chooseOptions'     => __( 'Please choose the product options first.', 'cartflows-pro' ),
					'buttonDisabled'    => __( 'This product can\'t be bought yet — check the options above.', 'cartflows-pro' ),
					'generic'           => __( 'Something went wrong. Please try again.', 'cartflows-pro' ),
					'placingOrder'      => __( 'Placing your order…', 'cartflows-pro' ),
					/* translators: %s: comma-separated product names. */
					'fbtDropped'        => __( 'We could not add %s to this order, so your total is lower than shown.', 'cartflows-pro' ),
					'fbtDroppedUnnamed' => __( 'Some products could not be added, so your total is lower than shown.', 'cartflows-pro' ),
					'fbtChooseOptions'  => __( 'Please choose an option for the selected products, or untick them.', 'cartflows-pro' ),
				),
				/**
				 * Countries whose postcode field may show a numeric keypad.
				 *
				 * Narrow this to match a site that has narrowed woocommerce_validate_postcode; a
				 * country left in here whose postcode is not purely digits cannot be typed on a phone.
				 *
				 * @since x.x.x
				 * @param array<int, string> $countries Country codes.
				 */
				'numericPostcodes' => apply_filters( 'cartflows_pro_instant_checkout_numeric_postcodes', self::NUMERIC_POSTCODE_COUNTRIES ),
			)
		);

		wp_add_inline_style( 'wcf-icp', $this->get_design_css() );
	}

	/**
	 * Design settings as CSS custom properties scoped to the popup.
	 *
	 * Six variables emitted inline — too little to justify the checkout module's dynamic-CSS machinery.
	 *
	 * @return string
	 */
	private function get_design_css() {

		$flow_id  = absint( wcf()->utils->get_flow_id_from_step_id( $this->step_id ) );
		$defaults = self::get_design_defaults();
		$rules    = '';
		$resolved = array();

		foreach ( self::get_design_properties() as $key => $property ) {

			$default = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
			$value   = wcf()->options->get_flow_meta_value( $flow_id, $key, $default );

			if ( ! is_scalar( $value ) ) {
				$value = $default;
			}

			if ( 'wcf-icp-base-font-size' === $key ) {
				$size  = absint( $value );
				$value = ( $size > 0 ? $size : absint( $default ) ) . 'px';
			} else {
				// Validated at output, not just save: flow meta also arrives raw from funnel imports and the abilities API, where a colour with `;}` could break out of the rule and inject markup.
				$hex   = sanitize_hex_color( (string) $value );
				$value = is_string( $hex ) && '' !== $hex ? $hex : $default;
			}

			$rules .= $property . ':' . $value . ';';

			$resolved[ $key ] = $value;
		}

		return '.wcf-icp-overlay{' . $rules . self::get_readable_primary_rules( $resolved ) . '}';
	}

	/**
	 * How well white text reads on this flow's primary colour.
	 *
	 * @since x.x.x
	 * @param int $flow_id Flow being edited.
	 * @return float
	 */
	private static function get_primary_contrast( $flow_id ) {

		$defaults = self::get_design_defaults();
		$default  = isset( $defaults['wcf-icp-primary-color'] ) ? $defaults['wcf-icp-primary-color'] : '#0084d6';
		$value    = wcf()->options->get_flow_meta_value( $flow_id, 'wcf-icp-primary-color', $default );
		$hex      = sanitize_hex_color( is_scalar( $value ) ? (string) $value : $default );

		return self::contrast_ratio( array( 255, 255, 255 ), self::hex_to_rgb( is_string( $hex ) && '' !== $hex ? $hex : $default ) );
	}

	/**
	 * Derive readable shades of the merchant's primary colour for the places it carries text.
	 *
	 * The colour itself is never overridden. Filled surfaces and primary-coloured text each get the
	 * nearest shade of it that reaches AA, so a merchant's pick stays theirs and stays legible.
	 *
	 * @since x.x.x
	 * @param array<string, string> $resolved Design values as they were written to the rule.
	 * @return string
	 */
	private static function get_readable_primary_rules( $resolved ) {

		$defaults = self::get_design_defaults();
		$pick     = static function ( $key ) use ( $resolved, $defaults ) {
			return isset( $resolved[ $key ] ) ? $resolved[ $key ] : ( isset( $defaults[ $key ] ) ? $defaults[ $key ] : '#ffffff' );
		};

		$primary = self::hex_to_rgb( $pick( 'wcf-icp-primary-color' ) );
		$heading = self::hex_to_rgb( $pick( 'wcf-icp-heading-color' ) );
		$white   = array( 255, 255, 255 );

		// Primary-coloured text sits on the popup background in one layout and the accent rail in the other.
		$ink = self::shift_to_contrast(
			$primary,
			array( self::hex_to_rgb( $pick( 'wcf-icp-bg-color' ) ), self::hex_to_rgb( $pick( 'wcf-icp-rail-bg-color' ) ) ),
			self::AA_TARGET
		);

		// A pale primary reads better under dark text than under white, so try both before moving the fill.
		$on_primary = self::contrast_ratio( $heading, $primary ) > self::contrast_ratio( $white, $primary ) ? $heading : $white;
		$cta        = $primary;

		if ( self::contrast_ratio( $on_primary, $primary ) < self::AA_CONTRAST ) {
			$on_primary = $white;
			$cta        = self::shift_to_contrast( $primary, array( $white ), self::AA_TARGET );
		}

		return '--wcf-icp-primary-ink:' . self::rgb_to_hex( $ink ) . ';'
			. '--wcf-icp-primary-cta:' . self::rgb_to_hex( $cta ) . ';'
			. '--wcf-icp-on-primary:' . self::rgb_to_hex( $on_primary ) . ';';
	}

	/**
	 * Step a colour away from its backgrounds until it reaches the wanted contrast against all of them.
	 *
	 * @since x.x.x
	 * @param array<int, int>             $rgb         Colour to move.
	 * @param array<int, array<int, int>> $backgrounds Backgrounds it has to read against.
	 * @param float                       $ratio       Contrast to reach.
	 * @return array<int, int>
	 */
	private static function shift_to_contrast( $rgb, $backgrounds, $ratio ) {

		$sum = 0.0;

		foreach ( $backgrounds as $background ) {
			$sum += self::relative_luminance( $background );
		}

		$lighten = count( $backgrounds ) > 0 && ( $sum / count( $backgrounds ) ) < 0.5;

		// Capped: a colour that cannot reach the target returns as close as it got, never an endless loop.
		for ( $step = 0; $step < 40; $step++ ) {

			$reached = true;

			foreach ( $backgrounds as $background ) {
				if ( self::contrast_ratio( $rgb, $background ) < $ratio ) {
					$reached = false;
					break;
				}
			}

			if ( $reached ) {
				return $rgb;
			}

			foreach ( $rgb as $index => $channel ) {
				$rgb[ $index ] = $lighten
					? (int) min( 255, round( $channel + ( ( 255 - $channel ) * 0.07 ) + 1 ) )
					: (int) max( 0, round( $channel * 0.93 ) );
			}
		}

		return $rgb;
	}

	/**
	 * WCAG relative luminance.
	 *
	 * @since x.x.x
	 * @param array<int, int> $rgb Colour channels.
	 * @return float
	 */
	private static function relative_luminance( $rgb ) {

		$linear = array();

		foreach ( $rgb as $channel ) {
			$part     = $channel / 255;
			$linear[] = $part <= 0.03928 ? $part / 12.92 : pow( ( $part + 0.055 ) / 1.055, 2.4 );
		}

		return ( 0.2126 * $linear[0] ) + ( 0.7152 * $linear[1] ) + ( 0.0722 * $linear[2] );
	}

	/**
	 * WCAG contrast ratio between two colours.
	 *
	 * @since x.x.x
	 * @param array<int, int> $first  First colour.
	 * @param array<int, int> $second Second colour.
	 * @return float
	 */
	public static function contrast_ratio( $first, $second ) {

		$one = self::relative_luminance( $first );
		$two = self::relative_luminance( $second );

		return ( max( $one, $two ) + 0.05 ) / ( min( $one, $two ) + 0.05 );
	}

	/**
	 * Split a hex colour into channels, accepting the three digit form.
	 *
	 * @since x.x.x
	 * @param string $hex Hex colour, with or without the hash.
	 * @return array<int, int>
	 */
	public static function hex_to_rgb( $hex ) {

		$hex = ltrim( (string) $hex, '#' );

		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}

		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return array( 0, 0, 0 );
		}

		return array(
			(int) hexdec( substr( $hex, 0, 2 ) ),
			(int) hexdec( substr( $hex, 2, 2 ) ),
			(int) hexdec( substr( $hex, 4, 2 ) ),
		);
	}

	/**
	 * Join channels back into a hex colour.
	 *
	 * @since x.x.x
	 * @param array<int, int> $rgb Colour channels.
	 * @return string
	 */
	private static function rgb_to_hex( $rgb ) {
		return sprintf( '#%02x%02x%02x', $rgb[0], $rgb[1], $rgb[2] );
	}

	/**
	 * Asset version that changes when the file does.
	 *
	 * The plugin version is static between releases, so alone it serves a stale stylesheet after any change.
	 *
	 * @param string $relative_path Path within the module directory.
	 * @return string
	 */
	private static function get_asset_version( $relative_path ) {
		return self::get_file_version( CARTFLOWS_PRO_INSTANT_CHECKOUT_DIR . $relative_path );
	}

	/**
	 * Asset version for a file anywhere on disk, for layout stylesheets registered by other plugins.
	 *
	 * @param string $file Absolute path.
	 * @return string
	 */
	private static function get_file_version( $file ) {

		if ( ! file_exists( $file ) ) {
			return CARTFLOWS_PRO_VER;
		}

		return CARTFLOWS_PRO_VER . '.' . (string) filemtime( $file );
	}

	/**
	 * Print the empty forms WooCommerce binds to on DOM ready.
	 *
	 * WC binds submit, payment and validation directly to form.checkout / form.checkout_coupon once on DOM ready, inside checkout.js's closure so they can't be re-pointed; every gateway binds the same way.
	 * An AJAX-fetched form has no handlers and falls back to a native POST off the page, so print both nodes up front and move the fetched contents into them.
	 *
	 * @return void
	 */
	public function render_form_shell() {

		if ( ! $this->step_id ) {
			return;
		}

		printf(
			'<div class="wcf-icp-form-shell" hidden><form name="checkout" method="post" class="checkout woocommerce-checkout" action="%1$s" enctype="multipart/form-data" data-wcf-icp-form="1"></form><form class="checkout_coupon woocommerce-form-coupon" method="post" data-wcf-icp-coupon-form="1"></form></div>',
			esc_url( wc_get_checkout_url() )
		);
	}

	/**
	 * Keep checkout.js from firing update_checkout on product-page load.
	 *
	 * @param array<string, mixed>|false $params Script data.
	 * @param string                     $handle Script handle.
	 * @return array<string, mixed>|false
	 */
	public function suppress_page_load_update( $params, $handle ) {

		if ( ! $this->step_id ) {
			return $params;
		}

		if ( 'wc-checkout' === $handle && is_array( $params ) ) {
			$params['is_checkout'] = '0';
		}

		return $params;
	}

	/**
	 * Render the Buy Now button.
	 *
	 * No nonce: product pages are full-page cached, so a baked-in nonce serves stale. The popup emits its own nonce in the modal HTML instead, as WC does for the checkout nonce.
	 *
	 * @return void
	 */
	public function render_button() {

		global $product;

		if ( ! $product instanceof WC_Product || ! $this->step_id ) {
			return;
		}

		// Own label, because free's woo-dynamic-flow relabels the native button with cartflows_add_to_cart_text.
		$flow_id = absint( get_post_meta( $this->step_id, 'wcf-flow-id', true ) );
		$label   = $flow_id ? wcf()->options->get_flow_meta_value( $flow_id, self::BUTTON_TEXT_META, self::get_default_button_text() ) : '';

		if ( ! is_string( $label ) || '' === trim( $label ) ) {
			$label = self::get_default_button_text();
		}

		// Print WC's own add-to-cart classes so the first paint matches; JS inheritButtonStyle() only adds theme extras, else the button resizes on load.
		$element_class = function_exists( 'wc_wp_theme_get_element_class_name' ) ? wc_wp_theme_get_element_class_name( 'button' ) : '';
		$element_class = $element_class ? ' ' . $element_class : '';

		printf(
			// wcf-mc-buy-now keeps Modern Cart's own add-to-cart guard (brainstormforce/modern-cart#217) matching this button after the wcf-icp- rename.
			'<button type="button" class="wcf-icp-buy-now wcf-mc-buy-now single_add_to_cart_button button alt%4$s" data-step-id="%1$s" data-product-id="%2$s" aria-haspopup="dialog">%3$s<span class="wcf-icp-spinner" aria-hidden="true"></span></button>',
			esc_attr( (string) $this->step_id ),
			esc_attr( (string) $product->get_id() ),
			esc_html( apply_filters( 'cartflows_pro_instant_checkout_button_text', $label, $product ) ),
			esc_attr( $element_class )
		);
	}

	/**
	 * Label the Buy Now button carries when the funnel has not set its own.
	 *
	 * @return string
	 */
	public static function get_default_button_text() {
		return __( 'Buy Now', 'cartflows-pro' );
	}

	/**
	 * Does this checkout step run a Checkout Offer?
	 *
	 * Both the global switch and the step's own toggle must be on, as the offer itself requires.
	 *
	 * @param int $step_id Checkout step ID.
	 * @return bool
	 */
	public static function step_has_checkout_offer( $step_id ) {

		$step_id = absint( $step_id );

		if ( ! $step_id || ! class_exists( 'Cartflows_Helper' ) ) {
			return false;
		}

		$common = Cartflows_Helper::get_common_settings();

		if ( ! is_array( $common ) || 'enable' !== ( isset( $common['pre_checkout_offer'] ) ? $common['pre_checkout_offer'] : '' ) ) {
			return false;
		}

		return 'yes' === get_post_meta( $step_id, 'wcf-pre-checkout-offer', true );
	}

	/**
	 * Register the flow meta defaults and their sanitizers.
	 *
	 * @param array<string, array<string, string>> $flow_meta Flow meta schema.
	 * @return array<string, array<string, string>>
	 */
	public function add_flow_meta_fields( $flow_meta ) {

		$flow_meta[ self::ENABLE_META ] = array(
			'default'  => 'no',
			'sanitize' => 'FILTER_SANITIZE_STRING',
		);

		// Registering the key here is also what carries it through funnel export and import.
		$flow_meta[ self::LAYOUT_META ] = array(
			'default'  => Cartflows_Pro_Instant_Checkout_Layouts::DEFAULT_SLUG,
			'sanitize' => 'FILTER_SANITIZE_STRING',
		);

		$flow_meta[ self::BUTTON_TEXT_META ] = array(
			'default'  => self::get_default_button_text(),
			'sanitize' => 'FILTER_SANITIZE_STRING',
		);

		$flow_meta[ self::LOGO_META ] = array(
			'default'  => '',
			'sanitize' => 'FILTER_SANITIZE_URL',
		);

		$defaults = self::get_design_defaults();

		foreach ( $defaults as $key => $default ) {
			$flow_meta[ $key ] = array(
				'default'  => $default,
				'sanitize' => 'wcf-icp-base-font-size' === $key ? 'FILTER_SANITIZE_NUMBER_INT' : 'FILTER_SANITIZE_COLOR',
			);
		}

		return $flow_meta;
	}

	/**
	 * Add the Instant Checkout section to the funnel settings screen.
	 *
	 * @param array<string, mixed> $settings Flow settings sections.
	 * @param int                  $flow_id  Flow ID.
	 * @return array<string, mixed>
	 */
	public function add_flow_settings( $settings, $flow_id ) {

		// Unlicensed: leave free's locked placeholder in this slot. No is_admin() — flow-data loads over REST.
		if ( ! cartflows_pro_is_active_license() ) {
			return $settings;
		}

		$flow_id  = absint( $flow_id );
		$registry = Cartflows_Pro_Instant_Checkout_Layouts::get_instance();

		$condition = array(
			'relation' => 'and',
			'fields'   => array(
				array(
					'name'     => self::ENABLE_META,
					'operator' => '===',
					'value'    => 'yes',
				),
			),
		);

		$layout_options = array();

		foreach ( $registry->get_selectable_layouts() as $layout ) {
			$layout_options[] = array(
				'value' => $layout->get_slug(),
				'label' => $layout->get_label(),
				'image' => $layout->get_thumbnail_url(),
			);
		}

		$fields = array(
			self::ENABLE_META => array(
				'type'         => 'toggle',
				'label'        => __( 'Enable Instant Checkout', 'cartflows-pro' ),
				'name'         => self::ENABLE_META,
				'value'        => get_post_meta( $flow_id, self::ENABLE_META, true ),
				'desc'         => __( 'Adds a "Buy Now" button that opens this funnel\'s checkout, order bumps, and offers in a popup. Buy Now replaces the shopper\'s cart with that product, restoring the original only if they close the popup.', 'cartflows-pro' ),
				'is_fullwidth' => true,
			),
			self::LAYOUT_META => array(
				'type'          => 'select_card',
				'label'         => __( 'Popup Layout', 'cartflows-pro' ),
				'name'          => self::LAYOUT_META,
				'value'         => $registry->get_layout_for_flow( $flow_id )->get_slug(),
				'options'       => $layout_options,
				'layout'        => 'horizontal',
				'display_radio' => true,
				'conditions'    => $condition,
			),
		);

		// Utilities come from the free admin's Tailwind build; without them this degrades to plain text, still readable.
		if ( ! self::store_has_payment_gateway() ) {
			$fields['wcf-icp-no-gateway'] = array(
				'type'         => 'heading',
				'label'        => __( 'No payment method is enabled', 'cartflows-pro' ),
				'desc'         => sprintf(
					/* translators: %1$s: opening anchor tag to the WooCommerce payments settings, %2$s: closing anchor tag. */
					__( 'Instant Checkout cannot take an order until at least one gateway is switched on, and Place Order stays disabled for shoppers until it is. %1$sOpen WooCommerce payment settings%2$s.', 'cartflows-pro' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) . '" target="_blank" rel="noopener noreferrer">',
					'</a>'
				),
				'sectionClass' => 'text-left p-3 rounded-md border border-solid border-alert-border-danger bg-alert-background-danger',
				'labelClass'   => 'block text-sm font-semibold text-text-primary',
				'descClass'    => 'text-sm font-normal text-text-secondary mt-1',
				'conditions'   => $condition,
			);
		}

		$outdated_modern_cart = self::outdated_modern_cart_version();

		if ( '' !== $outdated_modern_cart ) {
			$fields['wcf-icp-modern-cart'] = array(
				'type'       => 'alert',
				'variant'    => 'warning',
				'label'      => sprintf(
					/* translators: %s: lowest Modern Cart version Instant Checkout supports. */
					__( 'Modern Cart %s is required.', 'cartflows-pro' ),
					self::MODERN_CART_MIN_VERSION
				),
				'desc'       => sprintf(
					/* translators: %1$s: active Modern Cart version, %2$s: lowest supported version, %3$s: opening anchor tag to the plugins screen, %4$s: closing anchor tag. */
					__( 'Modern Cart %1$s is active. Instant Checkout needs %2$s or newer, otherwise the Modern Cart slide-out opens on top of the popup. %3$sUpdate Modern Cart%4$s.', 'cartflows-pro' ),
					esc_html( $outdated_modern_cart ),
					self::MODERN_CART_MIN_VERSION,
					'<a href="' . esc_url( admin_url( 'plugins.php' ) ) . '" target="_blank" rel="noopener noreferrer">',
					'</a>'
				),
				'conditions' => $condition,
			);
		}

		$fields[ self::BUTTON_TEXT_META ] = array(
			'type'          => 'text',
			'label'         => __( 'Button Text', 'cartflows-pro' ),
			'name'          => self::BUTTON_TEXT_META,
			'value'         => wcf()->options->get_flow_meta_value( $flow_id, self::BUTTON_TEXT_META, self::get_default_button_text() ),
			'default'       => self::get_default_button_text(),
			'display_align' => 'vertical',
			'conditions'    => $condition,
		);

		$fields[ self::LOGO_META ] = array(
			'type'          => 'image-selector',
			'label'         => __( 'Custom Logo', 'cartflows-pro' ),
			'name'          => self::LOGO_META,
			'value'         => wcf()->options->get_flow_meta_value( $flow_id, self::LOGO_META, '' ),
			'isNameArray'   => true,
			'objName'       => 'wcf_icp_logo',
			'tooltip'       => __( 'Shown as the popup\'s identity mark. Leave empty to use the theme\'s Site Logo, or the store initials when it has none.', 'cartflows-pro' ),
			'display_align' => 'vertical',
			'conditions'    => $condition,
		);

		$labels = array(
			'wcf-icp-primary-color'  => __( 'Primary Color', 'cartflows-pro' ),
			'wcf-icp-heading-color'  => __( 'Heading Color', 'cartflows-pro' ),
			'wcf-icp-text-color'     => __( 'Text Color', 'cartflows-pro' ),
			'wcf-icp-bg-color'       => __( 'Popup Background Color', 'cartflows-pro' ),
			'wcf-icp-rail-bg-color'  => __( 'Accent Background Color', 'cartflows-pro' ),
			'wcf-icp-base-font-size' => __( 'Base Font Size (px)', 'cartflows-pro' ),
		);

		$fields['wcf-icp-design-heading'] = array(
			'type'       => 'heading',
			'label'      => __( 'Design', 'cartflows-pro' ),
			'conditions' => $condition,
		);

		if ( self::get_primary_contrast( $flow_id ) < self::AA_CONTRAST ) {
			$fields['wcf-icp-primary-contrast'] = array(
				'type'         => 'heading',
				'label'        => __( 'Primary Color will be darkened on buttons', 'cartflows-pro' ),
				'desc'         => __( 'White text is hard to read on the Primary Color you picked, so buttons and links will use a slightly darker shade of it. Everything else keeps your color exactly. Pick a darker color to use it everywhere.', 'cartflows-pro' ),
				'sectionClass' => 'text-left p-3 rounded-md border border-solid border-alert-border-info bg-alert-background-info',
				'labelClass'   => 'block text-sm font-semibold text-text-primary',
				'descClass'    => 'text-sm font-normal text-text-secondary mt-1',
				'conditions'   => $condition,
			);
		}

		foreach ( self::get_design_defaults() as $key => $default ) {
			$fields[ $key ] = array(
				'type'       => 'wcf-icp-base-font-size' === $key ? 'number' : 'color-picker',
				'label'      => isset( $labels[ $key ] ) ? $labels[ $key ] : '',
				'name'       => $key,
				'value'      => wcf()->options->get_flow_meta_value( $flow_id, $key, $default ),
				'default'    => $default,
				'conditions' => $condition,
			);
		}

		$settings['instant-checkout'] = array(
			'title'    => __( 'Instant Checkout', 'cartflows-pro' ),
			'slug'     => 'instant_checkout',
			'fields'   => $fields,
			'priority' => 15,
		);

		return $settings;
	}

	/**
	 * Design setting defaults, keyed by meta key.
	 *
	 * @return array<string, string>
	 */
	public static function get_design_defaults() {
		return array(
			'wcf-icp-primary-color'  => '#0084D6',
			'wcf-icp-heading-color'  => '#1E1E1E',
			'wcf-icp-text-color'     => '#4A4A4A',
			'wcf-icp-bg-color'       => '#FFFFFF',
			'wcf-icp-rail-bg-color'  => '#F6F7F9',
			'wcf-icp-base-font-size' => '15',
		);
	}

	/**
	 * Map of design meta keys to the CSS custom property each one sets.
	 *
	 * @return array<string, string>
	 */
	public static function get_design_properties() {
		return self::$design_settings;
	}

	/**
	 * Is Instant Checkout enabled for a funnel?
	 *
	 * @param int $flow_id Flow ID.
	 * @return bool
	 */
	public static function is_enabled_for_flow( $flow_id ) {

		$flow_id = absint( $flow_id );

		if ( ! $flow_id ) {
			return false;
		}

		return 'yes' === get_post_meta( $flow_id, self::ENABLE_META, true );
	}

	/**
	 * Flow IDs that currently have the feature enabled.
	 *
	 * @return array<int>
	 */
	public static function get_active_flows() {

		$flows = get_option( self::ACTIVE_FLOWS_OPTION, array() );

		return is_array( $flows ) ? array_map( 'absint', $flows ) : array();
	}

	/**
	 * Is the feature enabled on at least one funnel?
	 *
	 * The frontend gate — one autoloaded option read, free on stores without the feature.
	 *
	 * @return bool
	 */
	public static function has_active_flows() {
		return ! empty( self::get_active_flows() );
	}

	/**
	 * Print the "use this funnel for Instant Checkout" checkbox in the product's CartFlows tab.
	 *
	 * @since x.x.x
	 * @param int $product_id Product being edited.
	 * @return void
	 */
	public function render_product_flow_option( $product_id ) {

		// A settings entry point, so it follows the licence gate; the stored value is kept either way.
		if ( ! cartflows_pro_is_active_license() ) {
			return;
		}

		woocommerce_wp_checkbox(
			array(
				'id'          => self::PRODUCT_USE_FLOW_META,
				'value'       => 'no' === get_post_meta( absint( $product_id ), self::PRODUCT_USE_FLOW_META, true ) ? 'no' : 'yes',
				'label'       => __( 'Use for Instant Checkout', 'cartflows-pro' ),
				'description' => __( 'Open this funnel\'s checkout from the Buy Now button. Applies only when Instant Checkout is on for the funnel. When unticked, Buy Now uses Store Checkout if Instant Checkout is on there.', 'cartflows-pro' ),
			)
		);

		// Tells the save handler this form carried the checkbox, since an unticked one is not posted.
		echo '<input type="hidden" name="' . esc_attr( self::PRODUCT_USE_FLOW_META ) . '_present" value="1">';
	}

	/**
	 * Save the per-product Instant Checkout checkbox.
	 *
	 * @since x.x.x
	 * @param int $post_id Product ID.
	 * @return void
	 */
	public function save_product_flow_option( $post_id ) {

		$nonce = isset( $_POST['woocommerce_meta_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['woocommerce_meta_nonce'] ) ) : '';

		// Only WooCommerce's own product form, and only when it rendered the checkbox, may change the flag.
		if ( ! wp_verify_nonce( $nonce, 'woocommerce_save_data' ) || ! isset( $_POST[ self::PRODUCT_USE_FLOW_META . '_present' ] ) ) {
			return;
		}

		// The nonce is shared by every WooCommerce edit screen, so it does not prove the user may edit this product.
		if ( ! current_user_can( 'edit_product', absint( $post_id ) ) ) {
			return;
		}

		$product = wc_get_product( absint( $post_id ) );

		if ( ! $product ) {
			return;
		}

		$product->update_meta_data( self::PRODUCT_USE_FLOW_META, isset( $_POST[ self::PRODUCT_USE_FLOW_META ] ) ? 'yes' : 'no' );
		$product->save();
	}

	/**
	 * Resolve the checkout step a product's Buy Now button should open.
	 *
	 * A funnel on the product's CartFlows tab wins if enabled and not opted out, else the Store Checkout funnel if enabled. 0 (no button) when neither qualifies.
	 *
	 * @param int $product_id Product ID.
	 * @return int Checkout step ID, or 0.
	 */
	public static function resolve_step_id( $product_id ) {

		$product = wc_get_product( absint( $product_id ) );

		if ( ! $product ) {
			return 0;
		}

		// Opting the product out skips its funnel, so Buy Now falls back to Store Checkout.
		$product_flow_id = 'no' === $product->get_meta( self::PRODUCT_USE_FLOW_META ) ? 0 : absint( $product->get_meta( 'cartflows_redirect_flow_id' ) );

		$flow_ids = array(
			$product_flow_id,
			self::get_store_checkout_flow_id(),
		);

		foreach ( $flow_ids as $flow_id ) {

			if ( ! self::is_enabled_for_flow( $flow_id ) ) {
				continue;
			}

			$step_id = self::get_checkout_step_id( $flow_id );

			if ( $step_id ) {
				return $step_id;
			}
		}

		return 0;
	}

	/**
	 * The Store Checkout funnel, or 0 when the merchant switched Store Checkout off.
	 *
	 * `_cartflows_store_checkout` keeps its ID after toggle-off — the disabled state lives in `_cartflows_common`, so both must agree. Mirrors Cartflows_Global_Checkout.
	 *
	 * @return int Flow ID, or 0.
	 */
	private static function get_store_checkout_flow_id() {

		$common = get_option( '_cartflows_common', array() );
		$common = is_array( $common ) ? $common : array();

		// Absent means never saved, which CartFlows treats as enabled.
		$override = isset( $common['override_global_checkout'] ) ? $common['override_global_checkout'] : 'enable';

		if ( 'enable' !== $override || empty( $common['global_checkout'] ) ) {
			return 0;
		}

		return absint( get_option( '_cartflows_store_checkout', 0 ) );
	}

	/**
	 * First usable checkout step in a funnel.
	 *
	 * Skips unpublished or disabled steps, so a funnel with no live checkout resolves to nothing.
	 *
	 * @param int $flow_id Flow ID.
	 * @return int Step ID, or 0.
	 */
	public static function get_checkout_step_id( $flow_id ) {

		$steps = get_post_meta( absint( $flow_id ), 'wcf-steps', true );

		if ( ! is_array( $steps ) ) {
			return 0;
		}

		foreach ( $steps as $step ) {

			if ( ! isset( $step['id'], $step['type'] ) || 'checkout' !== $step['type'] ) {
				continue;
			}

			$step_id = absint( $step['id'] );

			if ( 'publish' !== get_post_status( $step_id ) ) {
				continue;
			}

			if ( 'yes' === get_post_meta( $step_id, 'wcf-disable-step', true ) ) {
				continue;
			}

			return $step_id;
		}

		return 0;
	}

	/**
	 * Keep the active-flow option in step with the toggle.
	 *
	 * Updated incrementally, not re-queried, so a toggle costs one option write and no post query.
	 *
	 * @param int|array<int> $meta_id  Meta ID, or IDs when a meta row is deleted.
	 * @param int            $post_id  Post ID the meta belongs to.
	 * @param string         $meta_key Meta key that changed.
	 * @return void
	 */
	public function sync_active_flows( $meta_id, $post_id, $meta_key ) {

		if ( self::ENABLE_META !== $meta_key ) {
			return;
		}

		$post_id = absint( $post_id );

		if ( CARTFLOWS_FLOW_POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}

		$flows = self::get_active_flows();
		$index = array_search( $post_id, $flows, true );

		if ( self::is_enabled_for_flow( $post_id ) ) {
			if ( false === $index ) {
				$flows[] = $post_id;
			}
		} elseif ( false !== $index ) {
			unset( $flows[ $index ] );
		}

		update_option( self::ACTIVE_FLOWS_OPTION, array_values( $flows ), true );
	}

	/**
	 * Drop a deleted funnel from the active-flow option.
	 *
	 * @param int $post_id Post ID being deleted.
	 * @return void
	 */
	public function remove_active_flow( $post_id ) {

		$post_id = absint( $post_id );

		if ( CARTFLOWS_FLOW_POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}

		$flows = self::get_active_flows();
		$index = array_search( $post_id, $flows, true );

		if ( false === $index ) {
			return;
		}

		unset( $flows[ $index ] );

		update_option( self::ACTIVE_FLOWS_OPTION, array_values( $flows ), true );
	}
}

Cartflows_Pro_Instant_Checkout::get_instance();
