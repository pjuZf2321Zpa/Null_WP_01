# Module: product-embeddings

One embedding vector per published product: change capture into a queue, batched sync to the credit server, gzip+base64 storage in its own table, and cosine similarity.

Read `architecture.md` in this folder before changing this module.

## Rules

- **The `cartflows_product_embeddings_content` filter must be deterministic.** The same assembled string feeds both the `md5()` change detection and the embedded text, so a filter injecting a timestamp or random value re-embeds the whole catalog every 2 hours and burns credits. `classes/…-checksum.php:69,84`, `classes/…-controller.php:200`
- **Changing `cartflows_product_embeddings_interval` after the action exists has no effect** — scheduling only happens when none is scheduled, and it never reschedules. Call `clear_schedule()` first. `classes/…-controller.php:125,136`
- `cartflows_product_embeddings_enabled` returning `false` only takes effect inside `admin_init` — disabling on a front-end-only request leaves the recurring action live. `classes/…-controller.php:112,72`
- Interval is floored at `HOUR_IN_SECONDS`, `max_chars` at 1000, `backfill_limit` at 50 — smaller values are silently ignored. `classes/…-controller.php:93,277,149`
- `get_similar_products()` calls the DB class with **no `class_exists` guard**, unlike the loader — calling it without the loader having run is a fatal. `classes/…-similarity.php:105`
- A filter on `cartflows_fbt_ranked_recommendations` must return the full `{id, score, source, match_percent}` shape; `combine_scores()` rebuilds entries and discards whatever the previous callback produced. `classes/…-loader.php:114,101`
- **Schema changes require bumping `DB_VERSION`** — `maybe_create_table()` short-circuits on a version match and never runs `dbDelta` otherwise. `classes/…-db.php:37,86-88`

## Gotchas

- **The table and the cron are both created only in `admin_init`.** There is no activation hook, so on a site where nobody loads wp-admin the table never exists. If the action was scheduled earlier and the table is later dropped, the queue runs in cron context against a missing table — silent `$wpdb` errors, every candidate looks "changed", every product re-embeds. `classes/…-db.php:65`, `classes/…-controller.php:72`
- **Products whose content resolves to an empty string are queued forever** — they land in neither the process nor the delete set, so the ID survives every run, never gets a row, and the backfill query re-runs on every sync indefinitely. `classes/…-controller.php:196-198,343-344`
- **The credit-server response is matched back by text, strictly.** Any server-side normalisation (trim, encoding, unicode) makes the strict comparison fail, the vector is dropped, the product is marked failed and re-queued — permanently, with credits spent on each retry. PHP array keys also coerce numeric-string texts to ints. `classes/…-controller.php:318-327`
- **The embedded text is truncated but the checksum is not**, which contradicts the module's own stated invariant that "a matching checksum guarantees the stored vector is current". Two products identical up to 20 000 chars store different checksums but identical vectors. `classes/…-controller.php:275-284`, `classes/…-checksum.php:81-85`
- Byte/char mismatch in that same truncation — `strlen()` measures bytes but `mb_substr()` cuts characters, so multibyte content is sent at up to ~4× the intended byte budget. `classes/…-controller.php:279-280`
- **`QUEUE_LIMIT` silently drops the oldest IDs.** Once backfill is marked done a dropped product already has a row, so it is never returned again — its vector stays permanently stale with no recovery path. A bulk import of >1000 products triggers this. `classes/…-actions.php:152-153`
- **Similarity search is an unbounded full-table scan by default** (`scan_limit` defaults to 0 = no limit), called once per source product, on a front-end request. `classes/…-similarity.php:112-113`, `classes/…-loader.php:91-99`
- **The similarity cache is never invalidated** — an hour-long `wp_cache_set` with no matching delete in `upsert()` or `delete()`. `classes/…-similarity.php:132`
- **The blended score is overridden by a hard pin** — after sorting, the single highest raw-cosine product is unconditionally moved to position 0, so setting the cosine weight to 0 does *not* remove cosine's influence. `classes/…-loader.php:160-172`
- Loader boot is order-dependent and one-shot: the constructor returns early without WooCommerce, but `get_instance()` has already cached the dead instance and the file self-instantiates at include time. `classes/…-loader.php:38-52,211`
- Two global options are read-modify-written with no lock, and `update_queue()` writes back a snapshot taken at the start of the run — overwriting anything enqueued mid-run. `classes/…-controller.php:164,342-347`
- **Price is part of the checksum**, so every sale-price start/end re-embeds the product at credit cost despite carrying no semantic signal. `classes/…-checksum.php:52`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
