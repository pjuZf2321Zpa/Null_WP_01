<?php
/**
 * CartFlows Product Embeddings — batch generator.
 *
 * Drains the change queue (plus any products still missing an embedding) on a
 * recurring 2-hour Action Scheduler job, generates vectors in batches of 50 via
 * the StarterTemplates credit server, stores them, and re-queues failures.
 *
 * @package CartFlows
 * @since   x.x.x
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Embeddings_Controller.
 */
class Cartflows_Pro_Product_Embeddings_Controller {

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since x.x.x
	 */
	private static $instance = null;

	/**
	 * Recurring sync hook name.
	 *
	 * @var string
	 */
	const HOOK_SYNC = 'cartflows_product_embeddings_sync';

	/**
	 * Maximum products per credit-server request.
	 *
	 * @var int
	 */
	const BATCH_SIZE = 50;

	/**
	 * Option flag recording that the one-time full backfill has finished.
	 *
	 * @var string
	 */
	const BACKFILL_DONE_OPTION = 'cartflows_product_embeddings_backfill_done';

	/**
	 * Initiator
	 *
	 * @since x.x.x
	 * @return self Initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since x.x.x
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'schedule_events' ) );
		add_action( self::HOOK_SYNC, array( $this, 'process_queue' ) );
	}

	/**
	 * Whether the feature is enabled.
	 *
	 * @since x.x.x
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) apply_filters( 'cartflows_product_embeddings_enabled', function_exists( 'WC' ) );
	}

	/**
	 * Recurring interval in seconds (default 2 hours).
	 *
	 * @since x.x.x
	 * @return int
	 */
	public static function get_interval() {
		return max( HOUR_IN_SECONDS, (int) apply_filters( 'cartflows_product_embeddings_interval', 2 * HOUR_IN_SECONDS ) );
	}

	/**
	 * Credit-server route for embedding generation.
	 *
	 * @since x.x.x
	 * @return string
	 */
	public static function get_route() {
		return (string) apply_filters( 'cartflows_product_embeddings_route', 'cartflows/generate/embeddings' );
	}

	/**
	 * Register (or clear) the recurring sync action based on feature state.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function schedule_events() {
		if ( ! function_exists( 'as_schedule_recurring_action' ) || wp_installing() ) {
			return;
		}

		// Remove the orphaned legacy backfill action (no callback since backfill moved inline).
		as_unschedule_all_actions( 'cartflows_embeddings_backfill' );

		if ( ! self::is_enabled() ) {
			$this->clear_schedule();
			return;
		}

		if ( false === as_next_scheduled_action( self::HOOK_SYNC ) ) {
			as_schedule_recurring_action( time() + self::get_interval(), self::get_interval(), self::HOOK_SYNC, array(), 'cartflows' );
		}
	}

	/**
	 * Unschedule the recurring sync action.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function clear_schedule() {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::HOOK_SYNC );
		}
	}

	/**
	 * Backfill batch size — products pulled per run until the initial fill completes.
	 *
	 * @since x.x.x
	 * @return int
	 */
	private function get_backfill_limit() {
		return max( self::BATCH_SIZE, (int) apply_filters( 'cartflows_product_embeddings_backfill_limit', 3 * self::BATCH_SIZE ) );
	}

	/**
	 * Drain the queue: classify, delete removed products, embed changed ones.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function process_queue() {
		if ( ! self::is_enabled() || ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$db         = Cartflows_Pro_Product_Embeddings_DB::get_instance();
		$queue      = Cartflows_Pro_Product_Embeddings_Actions::get_queue();
		$candidates = $queue;

		if ( ! get_option( self::BACKFILL_DONE_OPTION ) ) {
			$missing = $db->get_products_without_embeddings( $this->get_backfill_limit() );

			if ( empty( $missing ) ) {
				update_option( self::BACKFILL_DONE_OPTION, 1, false );
			} else {
				$candidates = array_merge( $candidates, $missing );
			}
		}

		$candidates = array_values( array_unique( array_map( 'intval', $candidates ) ) );

		if ( empty( $candidates ) ) {
			return;
		}

		$to_process = array();
		$to_delete  = array();

		foreach ( $candidates as $product_id ) {
			$product = wc_get_product( $product_id );

			if ( ! $product instanceof WC_Product || 'publish' !== $product->get_status() ) {
				$to_delete[] = $product_id;
				continue;
			}

			$checksum = Cartflows_Pro_Product_Embeddings_Checksum::generate( $product_id );

			if ( '' === $checksum ) {
				continue;
			}

			if ( $checksum !== $db->get_checksum( $product_id ) ) {
				$to_process[ $product_id ] = $checksum;
			}
		}

		foreach ( $to_delete as $product_id ) {
			$db->delete( $product_id );
		}

		$failed = $this->generate_and_store( $to_process, $db );

		$this->update_queue( $queue, $to_process, $to_delete, $failed );

		$this->log(
			sprintf(
				'sync: %d candidates, %d embedded, %d failed, %d deleted.',
				count( $candidates ),
				count( $to_process ) - count( $failed ),
				count( $failed ),
				count( $to_delete )
			)
		);
	}

	/**
	 * Embed the changed products in batches of 50 and store the vectors.
	 *
	 * @since x.x.x
	 * @param array<int,string>                   $to_process Map of product_id => checksum.
	 * @param Cartflows_Pro_Product_Embeddings_DB $db         Storage instance.
	 * @return int[] Product IDs that failed to embed.
	 */
	private function generate_and_store( $to_process, $db ) {
		$failed = array();

		foreach ( array_chunk( $to_process, self::BATCH_SIZE, true ) as $chunk ) {
			$mapping = array();

			foreach ( $chunk as $product_id => $checksum ) {
				$mapping[ $product_id ] = $this->build_text( $product_id );
			}

			$mapping = array_filter( $mapping, 'strlen' );

			if ( empty( $mapping ) ) {
				continue;
			}

			$vectors = $this->get_embeddings( $mapping );

			if ( is_wp_error( $vectors ) ) {
				$this->log( 'sync: batch request failed — ' . $vectors->get_error_message(), 'error' );
				$failed = array_merge( $failed, array_keys( $mapping ) );
				continue;
			}

			foreach ( array_keys( $mapping ) as $product_id ) {
				$vector = isset( $vectors[ $product_id ] ) && is_array( $vectors[ $product_id ] ) ? $vectors[ $product_id ] : array();

				if ( empty( $vector ) || ! $db->upsert( $product_id, $vector, $chunk[ $product_id ] ) ) {
					$failed[] = $product_id;
				}
			}
		}

		return array_values( array_unique( array_map( 'intval', $failed ) ) );
	}

	/**
	 * Build the token-limited text sent to the embedding endpoint for a product.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return string
	 */
	private function build_text( $product_id ) {
		// get_content() applies the same truncation the checksum is taken over, so the two
		// can no longer disagree about what was embedded.
		return Cartflows_Pro_Product_Embeddings_Checksum::get_content( $product_id );
	}

	/**
	 * Send a product => text mapping to the credit server and return vectors.
	 *
	 * @since x.x.x
	 * @param array<int,string> $mapping Map of product_id => text.
	 * @return array<int,float[]>|WP_Error Map of product_id => vector, or error.
	 */
	private function get_embeddings( $mapping ) {
		if ( ! class_exists( 'CartFlows_Ai_Utils' ) ) {
			return new WP_Error( 'no_transport', __( 'AI transport is unavailable.', 'cartflows-pro' ) );
		}

		$response = CartFlows_Ai_Utils::get_instance()->send_api_request( array( 'mapping' => $mapping ), self::get_route(), 60 );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 !== $code ) {
			return new WP_Error( 'bad_response', sprintf( 'Credit server returned HTTP %d.', $code ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) || ! isset( $body['processed'] ) || ! is_array( $body['processed'] ) ) {
			return new WP_Error( 'bad_payload', __( 'Unexpected embedding response payload.', 'cartflows-pro' ) );
		}

		$vectors = array();

		// Server keys 'processed' by the input text, so map each back to its product ID.
		foreach ( $body['processed'] as $text => $vector ) {
			if ( ! is_array( $vector ) ) {
				continue;
			}

			foreach ( array_keys( $mapping, $text, true ) as $product_id ) {
				$vectors[ (int) $product_id ] = array_map( 'floatval', $vector );
			}
		}

		return $vectors;
	}

	/**
	 * Rebuild the queue: drop everything handled this run, keep failures.
	 *
	 * @since x.x.x
	 * @param int[]             $original   Queue as read at the start of the run.
	 * @param array<int,string> $to_process Products attempted this run.
	 * @param int[]             $to_delete  Products removed this run.
	 * @param int[]             $failed     Products that failed to embed.
	 * @return void
	 */
	private function update_queue( $original, $to_process, $to_delete, $failed ) {
		$handled   = array_merge( array_keys( $to_process ), $to_delete );
		$remaining = array_diff( $original, $handled );
		$remaining = array_merge( $remaining, $failed );

		Cartflows_Pro_Product_Embeddings_Actions::set_queue( $remaining );
	}

	/**
	 * Write a sync log line (gated on WP_DEBUG or a filter).
	 *
	 * @since x.x.x
	 * @param string $message Message to log.
	 * @param string $level   Severity label (info|warning|error).
	 * @return void
	 */
	private function log( $message, $level = 'info' ) {
		if ( ! apply_filters( 'cartflows_product_embeddings_enable_logging', defined( 'WP_DEBUG' ) && WP_DEBUG ) ) {
			return;
		}
		//phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( sprintf( '[CartFlows Product Embeddings] [%s] %s', strtoupper( $level ), $message ) );
	}
}
