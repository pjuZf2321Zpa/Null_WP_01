---
module: product-embeddings
---

# product-embeddings

## Responsibility

Owns the full lifecycle of one embedding vector per published WooCommerce product: capturing product changes into a queue, batching them to the StarterTemplates credit server on a recurring Action Scheduler job, storing gzip+base64 vectors in its own `{prefix}cartflows_product_embeddings` table, and computing cosine similarity from them.

Ownership stops at the recommendation UI — it only contributes a re-ranked list through the `cartflows_fbt_ranked_recommendations` filter and never decides what the FBT engine displays. It also does not own the embedding model or the HTTP transport, which are delegated to the AI utils.

## Why it is this way

The design rests on one invariant: the same assembled content feeds both the checksum and the embedding request, so a matching checksum proves the stored vector is current. That is what makes the sync cheap — most products are skipped without an API call.

The truncation in `build_text()` already breaks that invariant, and the text-keyed round-trip across the credit-server boundary is the other place where a small change on the far side costs credits on every retry. Both are worth understanding before touching the content filter or the batch size.
