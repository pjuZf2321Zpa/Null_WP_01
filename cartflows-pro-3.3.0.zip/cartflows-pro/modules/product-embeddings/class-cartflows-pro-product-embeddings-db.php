<?php
/**
 * CartFlows Product Embeddings — storage layer.
 *
 * Owns the custom table that holds one vector per WooCommerce product,
 * keyed by product ID, alongside the content checksum used for change
 * detection. Vectors are gzip-compressed + base64-encoded on write.
 *
 * @package CartFlows
 * @since   x.x.x
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Embeddings_DB.
 */
class Cartflows_Pro_Product_Embeddings_DB {

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since x.x.x
	 */
	private static $instance = null;

	/**
	 * Schema version — bump to trigger a table migration.
	 *
	 * @var string
	 */
	const DB_VERSION = '1.0.0';

	/**
	 * Option key that records the installed schema version.
	 *
	 * @var string
	 */
	const DB_VERSION_OPTION = 'cartflows_product_embeddings_db_version';

	/**
	 * Initiator
	 *
	 * @since x.x.x
	 * @return self Initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since x.x.x
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'maybe_create_table' ) );
	}

	/**
	 * Fully-qualified embeddings table name.
	 *
	 * @since x.x.x
	 * @return string
	 */
	public static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'cartflows_product_embeddings';
	}

	/**
	 * Create or migrate the embeddings table when the schema version changes.
	 *
	 * @since x.x.x
	 * @return void
	 */
	public function maybe_create_table() {
		if ( self::DB_VERSION === get_option( self::DB_VERSION_OPTION ) ) {
			return;
		}

		global $wpdb;

		$table           = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			product_id bigint(20) unsigned NOT NULL,
			embedding longtext NOT NULL,
			checksum varchar(32) NOT NULL DEFAULT '',
			updated_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			UNIQUE KEY product_id (product_id),
			KEY checksum (checksum)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * Insert or update the embedding + checksum for a product.
	 *
	 * @since x.x.x
	 * @param int     $product_id Product ID.
	 * @param float[] $embedding  Embedding vector.
	 * @param string  $checksum   Content checksum the vector was generated from.
	 * @return bool True on success.
	 */
	public function upsert( $product_id, $embedding, $checksum ) {
		$product_id = absint( $product_id );

		if ( ! $product_id || ! is_array( $embedding ) || empty( $embedding ) ) {
			return false;
		}

		$compressed = self::compress( $embedding );

		if ( '' === $compressed ) {
			return false;
		}

		global $wpdb;

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->query(
			$wpdb->prepare(
				'INSERT INTO ' . self::get_table_name() . ' (product_id, embedding, checksum, updated_at)
				VALUES (%d, %s, %s, %s)
				ON DUPLICATE KEY UPDATE embedding = VALUES(embedding), checksum = VALUES(checksum), updated_at = VALUES(updated_at)',
				$product_id,
				$compressed,
				(string) $checksum,
				current_time( 'mysql', true )
			)
		);
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

		return false !== $result;
	}

	/**
	 * Get the stored checksum for a product, or empty string if none.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return string
	 */
	public function get_checksum( $product_id ) {
		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return '';
		}

		global $wpdb;

		$table = self::get_table_name();

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$checksum = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT checksum FROM $table WHERE product_id = %d",
				$product_id
			)
		);
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

		return is_string( $checksum ) ? $checksum : '';
	}

	/**
	 * Get the decoded embedding vector for a product.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return float[] Empty array when no embedding is stored.
	 */
	public function get_embedding( $product_id ) {
		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return array();
		}

		global $wpdb;

		$table = self::get_table_name();

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$raw = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT embedding FROM $table WHERE product_id = %d",
				$product_id
			)
		);
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

		return is_string( $raw ) ? self::decompress( $raw ) : array();
	}

	/**
	 * Delete the stored embedding for a product.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return bool True on success.
	 */
	public function delete( $product_id ) {
		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return false;
		}

		global $wpdb;

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete( self::get_table_name(), array( 'product_id' => $product_id ), array( '%d' ) );
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		return false !== $result;
	}

	/**
	 * Get published product IDs that have no stored embedding yet (backfill source).
	 *
	 * @since x.x.x
	 * @param int $limit Maximum IDs to return.
	 * @return int[]
	 */
	public function get_products_without_embeddings( $limit ) {
		$limit = max( 1, absint( $limit ) );

		global $wpdb;

		$table = self::get_table_name();

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p
				LEFT JOIN $table e ON e.product_id = p.ID
				WHERE p.post_type = 'product' AND p.post_status = 'publish' AND e.product_id IS NULL
				ORDER BY p.ID ASC
				LIMIT %d",
				$limit
			)
		);
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

		return is_array( $ids ) ? array_map( 'intval', $ids ) : array();
	}

	/**
	 * Bulk-load decoded embeddings, keyed by product ID.
	 *
	 * @since x.x.x
	 * @param int[] $exclude Product IDs to skip.
	 * @param int   $limit   Maximum rows to load (0 = no limit).
	 * @return array<int,float[]> Map of product_id => vector.
	 */
	public function get_all_embeddings( $exclude = array(), $limit = 0 ) {
		$exclude = array_values( array_filter( array_map( 'absint', (array) $exclude ) ) );
		$limit   = absint( $limit );

		global $wpdb;

		$query  = 'SELECT product_id, embedding FROM ' . self::get_table_name();
		$params = array();

		if ( ! empty( $exclude ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$query       .= ' WHERE product_id NOT IN (' . $placeholders . ')';
			$params       = $exclude;
		}

		$query .= ' ORDER BY product_id ASC';

		if ( $limit > 0 ) {
			$query   .= ' LIMIT %d';
			$params[] = $limit;
		}

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = empty( $params )
			? $wpdb->get_results( $query, ARRAY_A )
			: $wpdb->get_results( $wpdb->prepare( $query, $params ), ARRAY_A );
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

		$out = array();

		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$vector = self::decompress( (string) $row['embedding'] );
				if ( ! empty( $vector ) ) {
					$out[ (int) $row['product_id'] ] = $vector;
				}
			}
		}

		return $out;
	}

	/**
	 * Compress an embedding vector to a storable string (gzip + base64).
	 *
	 * @since x.x.x
	 * @param float[] $embedding Embedding vector.
	 * @return string Empty string on failure.
	 */
	public static function compress( $embedding ) {
		$json = wp_json_encode( array( 'content' => array_values( $embedding ) ) );

		if ( false === $json ) {
			return '';
		}

		$compressed = gzcompress( $json, 9 );

		if ( false === $compressed ) {
			return '';
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		return base64_encode( $compressed );
	}

	/**
	 * Decompress a stored embedding string back into a vector.
	 *
	 * @since x.x.x
	 * @param string $raw Stored (gzip + base64) value.
	 * @return float[] Empty array on failure.
	 */
	public static function decompress( $raw ) {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		$decoded = base64_decode( $raw, true );

		if ( false === $decoded ) {
			return array();
		}

		$json = gzuncompress( $decoded );

		if ( false === $json ) {
			return array();
		}

		$data = json_decode( $json, true );

		if ( ! is_array( $data ) || ! isset( $data['content'] ) || ! is_array( $data['content'] ) ) {
			return array();
		}

		return array_map( 'floatval', $data['content'] );
	}
}
