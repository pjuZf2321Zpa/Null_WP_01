<?php
/**
 * CartFlows Product Embeddings — content + checksum builder.
 *
 * Assembles the product text that gets embedded and the md5 checksum used to
 * detect real changes. The same assembled content feeds both the checksum and
 * the embedding request, so a matching checksum guarantees the stored vector
 * is current.
 *
 * @package CartFlows
 * @since   x.x.x
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Embeddings_Checksum.
 */
class Cartflows_Pro_Product_Embeddings_Checksum {

	/**
	 * Build the embeddable text for a product.
	 *
	 * Combines title, descriptions, SKU, price, categories and attributes so the
	 * checksum reacts to the product fields that actually matter for similarity.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return string Empty string when the product cannot be loaded.
	 */
	public static function get_content( $product_id ) {
		$product_id = absint( $product_id );

		if ( ! $product_id || ! function_exists( 'wc_get_product' ) ) {
			return '';
		}

		$product = wc_get_product( $product_id );

		if ( ! $product instanceof WC_Product ) {
			return '';
		}

		$parts = array(
			$product->get_name(),
			$product->get_short_description(),
			$product->get_description(),
			$product->get_sku(),
			(string) $product->get_price(),
			self::get_terms_text( $product_id, 'product_cat' ),
			self::get_terms_text( $product_id, 'product_tag' ),
			self::get_attributes_text( $product ),
		);

		$content = implode( "\n", array_filter( array_map( 'trim', $parts ) ) );
		$content = wp_strip_all_tags( $content );

		/**
		 * Filter the assembled product content used for embeddings + checksum.
		 *
		 * @since x.x.x
		 * @param string     $content    Assembled, tag-stripped content.
		 * @param int        $product_id Product ID.
		 * @param WC_Product $product    Product object.
		 */
		$content = apply_filters( 'cartflows_product_embeddings_content', $content, $product_id, $product );
		$content = ! empty( $content ) ? trim( $content ) : '';

		/*
		 * Truncate here rather than in the controller. The checksum used to hash the full
		 * content while only the truncated text was embedded, so two products identical up
		 * to the cutoff stored different checksums against identical vectors — and an edit
		 * past the cutoff forced a pointless re-embed. mb_strlen() to match mb_substr():
		 * strlen() counts bytes, so multibyte content was sent well over the intended size.
		 */
		$max_chars = max( 1000, (int) apply_filters( 'cartflows_product_embeddings_max_chars', 20000 ) );

		if ( mb_strlen( $content ) > $max_chars ) {
			$content = (string) mb_substr( $content, 0, $max_chars );
		}

		return $content;
	}

	/**
	 * Generate the checksum for a product's current content.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return string md5 hash, or empty string when there is no content.
	 */
	public static function generate( $product_id ) {
		$content = self::get_content( $product_id );

		return '' === $content ? '' : md5( $content );
	}

	/**
	 * Whether a product's content differs from the checksum last stored.
	 *
	 * @since x.x.x
	 * @param int    $product_id     Product ID.
	 * @param string $stored_checksum Checksum currently stored for the product.
	 * @return bool
	 */
	public static function has_changed( $product_id, $stored_checksum ) {
		$current = self::generate( $product_id );

		if ( '' === $current ) {
			return false;
		}

		return $current !== (string) $stored_checksum;
	}

	/**
	 * Comma-separated term names for a product taxonomy.
	 *
	 * @since x.x.x
	 * @param int    $product_id Product ID.
	 * @param string $taxonomy   Taxonomy slug.
	 * @return string
	 */
	private static function get_terms_text( $product_id, $taxonomy ) {
		$names = wp_get_post_terms( $product_id, $taxonomy, array( 'fields' => 'names' ) );

		if ( is_wp_error( $names ) || ! is_array( $names ) ) {
			return '';
		}

		return implode( ', ', array_map( 'strval', $names ) );
	}

	/**
	 * Flattened "name: value" text for a product's attributes.
	 *
	 * @since x.x.x
	 * @param WC_Product $product Product object.
	 * @return string
	 */
	private static function get_attributes_text( $product ) {
		$lines = array();

		foreach ( $product->get_attributes() as $attribute ) {
			if ( ! $attribute instanceof WC_Product_Attribute ) {
				continue;
			}

			$name   = wc_attribute_label( $attribute->get_name() );
			$values = $attribute->is_taxonomy()
				? wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'names' ) )
				: $attribute->get_options();

			if ( is_array( $values ) && ! empty( $values ) ) {
				$lines[] = $name . ': ' . implode( ', ', array_map( 'strval', $values ) );
			}
		}

		return implode( "\n", $lines );
	}
}
