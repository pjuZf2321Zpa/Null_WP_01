<?php
/**
 * CartFlows Product Embeddings — cosine similarity search.
 *
 * Ranks products by vector cosine similarity against a source product, the same
 * scoring SureRank Pro uses for link suggestions. Feeds the "Frequently Bought
 * Together" engine with a semantic signal alongside purchase-history affinity.
 *
 * @package CartFlows
 * @since   x.x.x
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Embeddings_Similarity.
 */
class Cartflows_Pro_Product_Embeddings_Similarity {

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since x.x.x
	 */
	private static $instance = null;

	/**
	 * Initiator
	 *
	 * @since x.x.x
	 * @return self Initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Cosine similarity between two vectors.
	 *
	 * @since x.x.x
	 * @param float[] $vec_a First vector.
	 * @param float[] $vec_b Second vector.
	 * @return float Score between -1 and 1.
	 */
	public function cosine_similarity( $vec_a, $vec_b ) {
		$dot_product = 0.0;
		$norm_a      = 0.0;
		$norm_b      = 0.0;

		foreach ( $vec_a as $i => $val_a ) {
			$val_b        = isset( $vec_b[ $i ] ) ? (float) $vec_b[ $i ] : 0.0;
			$dot_product += (float) $val_a * $val_b;
			$norm_a      += (float) $val_a ** 2;
			$norm_b      += $val_b ** 2;
		}

		if ( 0.0 === $norm_a || 0.0 === $norm_b ) {
			return 0.0;
		}

		return $dot_product / ( sqrt( $norm_a ) * sqrt( $norm_b ) );
	}

	/**
	 * Convert a cosine score (-1..1) to a 0..100 percentage.
	 *
	 * @since x.x.x
	 * @param float $cosine_score Cosine score.
	 * @return float
	 */
	public function similarity_percentage( $cosine_score ) {
		return round( ( (float) $cosine_score + 1 ) / 2 * 100, 2 );
	}

	/**
	 * Get the products most similar to a source product, best match first.
	 *
	 * @since x.x.x
	 * @param int $product_id Source product ID.
	 * @param int $limit      Maximum matches to return.
	 * @return array<int,array{id:int,score:float}> Sorted by score descending.
	 */
	public function get_similar_products( $product_id, $limit ) {
		$product_id = absint( $product_id );
		$limit      = max( 1, absint( $limit ) );

		if ( ! $product_id ) {
			return array();
		}

		$cache_key = 'similar_' . $product_id . '_' . $limit;
		$cached    = wp_cache_get( $cache_key, 'cartflows_product_embeddings' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$db     = Cartflows_Pro_Product_Embeddings_DB::get_instance();
		$source = $db->get_embedding( $product_id );

		if ( empty( $source ) ) {
			return array();
		}

		$scan_limit = max( 0, (int) apply_filters( 'cartflows_product_embeddings_similarity_scan_limit', 0 ) );
		$others     = $db->get_all_embeddings( array( $product_id ), $scan_limit );

		$scored = array();
		foreach ( $others as $id => $vector ) {
			$scored[] = array(
				'id'    => (int) $id,
				'score' => $this->cosine_similarity( $source, $vector ),
			);
		}

		usort(
			$scored,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		$scored = array_slice( $scored, 0, $limit );

		wp_cache_set( $cache_key, $scored, 'cartflows_product_embeddings', HOUR_IN_SECONDS );

		return $scored;
	}
}
