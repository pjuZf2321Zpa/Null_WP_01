<?php
/**
 * Index file
 *
 * @package CartFlows
 * @since x.x.x
 */

/* Silence is golden, and we agree. */
