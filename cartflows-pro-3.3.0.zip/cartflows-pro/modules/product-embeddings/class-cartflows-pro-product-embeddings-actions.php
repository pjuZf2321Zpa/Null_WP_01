<?php
/**
 * CartFlows Product Embeddings — change capture.
 *
 * Hooks WooCommerce product create/update/delete and pushes changed product
 * IDs into a capped queue option. The queue is drained later by the recurring
 * batch job; nothing is embedded inline.
 *
 * @package CartFlows
 * @since   x.x.x
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Embeddings_Actions.
 */
class Cartflows_Pro_Product_Embeddings_Actions {

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since x.x.x
	 */
	private static $instance = null;

	/**
	 * Option name holding the pending-change queue (array of product IDs).
	 *
	 * @var string
	 */
	const QUEUE_OPTION = 'cartflows_product_embeddings_queue';

	/**
	 * Maximum IDs retained in the queue.
	 *
	 * @var int
	 */
	const QUEUE_LIMIT = 1000;

	/**
	 * Initiator
	 *
	 * @since x.x.x
	 * @return self Initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since x.x.x
	 */
	public function __construct() {
		add_action( 'wp_after_insert_post', array( $this, 'handle_product_change' ), 10, 3 );
		add_action( 'before_delete_post', array( $this, 'handle_product_delete' ), 10, 1 );
		add_action( 'wp_trash_post', array( $this, 'handle_product_delete' ), 10, 1 );
	}

	/**
	 * Queue a product on create/update.
	 *
	 * @since x.x.x
	 * @param int          $post_id Post ID.
	 * @param WP_Post|null $post    Post object.
	 * @param bool         $update  Whether this is an update (unused, kept for hook signature).
	 * @return void
	 */
	public function handle_product_change( $post_id, $post = null, $update = false ) {
		unset( $update );

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! $this->should_track( $post_id, $post ) ) {
			return;
		}

		self::enqueue( $post_id );
	}

	/**
	 * Queue a product on trash/delete so its vector is cleaned up on the next run.
	 *
	 * @since x.x.x
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function handle_product_delete( $post_id ) {
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( 'product' !== get_post_type( $post_id ) ) {
			return;
		}

		self::enqueue( $post_id );
	}

	/**
	 * Whether a post should be tracked (published product).
	 *
	 * @since x.x.x
	 * @param int          $post_id Post ID.
	 * @param WP_Post|null $post    Post object.
	 * @return bool
	 */
	private function should_track( $post_id, $post ) {
		$post = $post instanceof WP_Post ? $post : get_post( $post_id );

		if ( ! $post instanceof WP_Post ) {
			return false;
		}

		if ( 'product' !== $post->post_type ) {
			return false;
		}

		return 'publish' === $post->post_status;
	}

	/**
	 * Add a product ID to the change queue (deduped, capped).
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return void
	 */
	public static function enqueue( $product_id ) {
		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return;
		}

		$queue   = self::get_queue();
		$queue[] = $product_id;
		$queue   = array_values( array_unique( array_map( 'intval', $queue ) ) );

		if ( count( $queue ) > self::QUEUE_LIMIT ) {
			$queue = array_slice( $queue, -self::QUEUE_LIMIT );
		}

		self::set_queue( $queue );
	}

	/**
	 * Read the current change queue.
	 *
	 * @since x.x.x
	 * @return int[]
	 */
	public static function get_queue() {
		$queue = get_option( self::QUEUE_OPTION, array() );

		return is_array( $queue ) ? array_values( array_map( 'intval', $queue ) ) : array();
	}

	/**
	 * Overwrite the change queue.
	 *
	 * @since x.x.x
	 * @param int[] $queue Product IDs.
	 * @return void
	 */
	public static function set_queue( $queue ) {
		$queue = ! empty( $queue ) ? array_values( array_unique( array_map( 'intval', $queue ) ) ) : array();

		update_option( self::QUEUE_OPTION, $queue, false );
	}
}
