<?php
/**
 * CartFlows Product Embeddings — module loader.
 *
 * Wires the storage, change-capture and batch-generation classes together.
 * Only boots when WooCommerce is active.
 *
 * @package CartFlows
 * @since   x.x.x
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Embeddings_Loader.
 */
class Cartflows_Pro_Product_Embeddings_Loader {

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since x.x.x
	 */
	private static $instance = null;

	/**
	 * Initiator
	 *
	 * @since x.x.x
	 * @return self Initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since x.x.x
	 */
	public function __construct() {
		if ( ! function_exists( 'WC' ) ) {
			return;
		}

		$dir = CARTFLOWS_PRO_DIR . 'modules/product-embeddings/';

		require_once $dir . 'class-cartflows-pro-product-embeddings-db.php';
		require_once $dir . 'class-cartflows-pro-product-embeddings-checksum.php';
		require_once $dir . 'class-cartflows-pro-product-embeddings-actions.php';
		require_once $dir . 'class-cartflows-pro-product-embeddings-controller.php';
		require_once $dir . 'class-cartflows-pro-product-embeddings-similarity.php';

		Cartflows_Pro_Product_Embeddings_DB::get_instance();
		Cartflows_Pro_Product_Embeddings_Actions::get_instance();
		Cartflows_Pro_Product_Embeddings_Controller::get_instance();

		add_filter( 'cartflows_fbt_ranked_recommendations', array( $this, 'rank_recommendations' ), 10, 4 );
	}

	/**
	 * Re-rank FBT recommendations by blending affinity with semantic (cosine) similarity.
	 *
	 * Returns the affinity-only ranking untouched when embeddings are unavailable.
	 *
	 * @since x.x.x
	 * @param array<int,array{id:int,score:float,source:string,match_percent:float}> $ranked      Affinity-only ranking from CartFlows.
	 * @param array<int,float>                                                       $affinity    Map of product_id => summed lift score.
	 * @param int[]                                                                  $product_ids Source product IDs.
	 * @param int                                                                    $fetch       Max matches to fetch per product.
	 * @return array<int,array{id:int,score:float,source:string,match_percent:float}>
	 */
	public function rank_recommendations( $ranked, $affinity, $product_ids, $fetch ) {
		if ( ! class_exists( 'Cartflows_Pro_Product_Embeddings_Similarity' ) ) {
			return $ranked;
		}

		$product_ids = array_map( 'intval', (array) $product_ids );
		$exclude     = array_flip( $product_ids );
		$fetch       = max( 1, (int) $fetch );
		$cosine      = array();

		foreach ( $product_ids as $product_id ) {
			foreach ( Cartflows_Pro_Product_Embeddings_Similarity::get_instance()->get_similar_products( $product_id, $fetch ) as $match ) {
				$rid = (int) $match['id'];
				if ( isset( $exclude[ $rid ] ) ) {
					continue;
				}
				$cosine[ $rid ] = isset( $cosine[ $rid ] ) ? max( $cosine[ $rid ], (float) $match['score'] ) : (float) $match['score'];
			}
		}

		return $this->combine_scores( (array) $affinity, $cosine );
	}

	/**
	 * Merge affinity + cosine signals into one ranked list, best match first.
	 *
	 * Each signal is min-max normalized to 0..1 so their different scales combine
	 * fairly, then blended with filterable weights. The single strongest semantic
	 * match is pinned to the top so the highest match always leads.
	 *
	 * @since x.x.x
	 * @param array<int,float> $affinity Map of product_id => summed lift score.
	 * @param array<int,float> $cosine   Map of product_id => best cosine score.
	 * @return array<int,array{id:int,score:float,source:string,match_percent:float}> Ranked entries, highest relevance first.
	 */
	private function combine_scores( $affinity, $cosine ) {
		$w_cosine   = (float) apply_filters( 'cartflows_fbt_cosine_weight', 0.6 );
		$w_affinity = (float) apply_filters( 'cartflows_fbt_affinity_weight', 0.4 );

		$norm_affinity = $this->normalize_scores( $affinity );
		$norm_cosine   = $this->normalize_scores( $cosine );

		$total_weight = $w_cosine + $w_affinity;
		$ids          = array_unique( array_merge( array_keys( $affinity ), array_keys( $cosine ) ) );
		$combined     = array();

		foreach ( $ids as $id ) {
			$cosine_contrib   = $w_cosine * ( isset( $norm_cosine[ $id ] ) ? $norm_cosine[ $id ] : 0.0 );
			$affinity_contrib = $w_affinity * ( isset( $norm_affinity[ $id ] ) ? $norm_affinity[ $id ] : 0.0 );
			$score            = $cosine_contrib + $affinity_contrib;

			$has_cosine   = isset( $cosine[ $id ] );
			$has_affinity = isset( $affinity[ $id ] );

			if ( $has_cosine && $has_affinity ) {
				$source = 'both';
			} elseif ( $has_cosine ) {
				$source = 'cosine';
			} else {
				$source = 'affinity';
			}

			$percent = $total_weight > 0.0 ? ( $score / $total_weight ) * 100 : 0.0;

			$combined[] = array(
				'id'            => (int) $id,
				'score'         => $score,
				'source'        => $source,
				'match_percent' => (float) round( $percent, 2 ),
			);
		}

		usort(
			$combined,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		if ( ! empty( $cosine ) ) {
			$top_keys  = array_keys( $cosine, max( $cosine ), true );
			$top_match = (int) reset( $top_keys );

			foreach ( $combined as $index => $item ) {
				if ( $item['id'] === $top_match ) {
					unset( $combined[ $index ] );
					array_unshift( $combined, $item );
					break;
				}
			}
			$combined = array_values( $combined );
		}

		return $combined;
	}

	/**
	 * Min-max normalize a score map to the 0..1 range.
	 *
	 * @since x.x.x
	 * @param array<int,float> $scores Map of product_id => score.
	 * @return array<int,float>
	 */
	private function normalize_scores( $scores ) {
		if ( empty( $scores ) ) {
			return array();
		}

		$max = max( $scores );
		$min = min( $scores );

		if ( $max <= 0.0 ) {
			return array();
		}

		$range = $max - $min;

		if ( $range <= 0.0 ) {
			return array_fill_keys( array_keys( $scores ), 1.0 );
		}

		$normalized = array();
		foreach ( $scores as $id => $value ) {
			$normalized[ $id ] = ( $value - $min ) / $range;
		}

		return $normalized;
	}
}

Cartflows_Pro_Product_Embeddings_Loader::get_instance();
