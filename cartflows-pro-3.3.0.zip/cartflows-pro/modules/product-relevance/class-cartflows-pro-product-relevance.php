<?php
/**
 * CartFlows Product Relevance — shared recommendation engine.
 *
 * Ranks the products most related to a set of source products by blending
 * purchase-history affinity (Cartflows_Pro_Product_Affinity) with semantic
 * similarity — the latter contributed by the embeddings module through the
 * `cartflows_fbt_ranked_recommendations` filter — then applies the
 * offerability and price rules a storefront needs and falls back to catalog
 * signals when a store has no purchase history yet.
 *
 * Extracted verbatim from the Frequently Bought Together REST controller so a
 * second consumer can reuse the same rules rather than reimplement them.
 *
 * This class performs NO capability checks and NO input sanitisation beyond an
 * empty-input guard: callers own authorization and are expected to pass clean
 * integer IDs. It is also uncached — callers on a hot path must memoize.
 *
 * @package CartFlows
 * @since   x.x.x
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Cartflows_Pro_Product_Relevance.
 *
 * @since x.x.x
 */
class Cartflows_Pro_Product_Relevance {

	/**
	 * Instance
	 *
	 * @access private
	 * @var self|null Class object.
	 * @since x.x.x
	 */
	private static $instance = null;

	/**
	 * Initiator
	 *
	 * @since x.x.x
	 * @return self Initialized object of class.
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Build the ranked candidate pool: affinity + embeddings first, then fallbacks.
	 *
	 * @since x.x.x
	 * @param int[]  $product_ids Source product IDs.
	 * @param string $context     fbt | crosssell | upsell | order_bump.
	 * @param int    $fetch       Pool size to aim for.
	 * @param int[]  $exclude_ids Product IDs to leave out of the results entirely.
	 * @param int[]  $restrict_to Closed candidate set. When given, results are ranked WITHIN it and the
	 *                            catalog fallbacks are skipped — the set is the whole universe.
	 * @return array<int,array{id:int,score:float,source:string,match_percent:float}>
	 */
	public function get_related_products( $product_ids, $context, $fetch, $exclude_ids = array(), $restrict_to = array() ) {

		if ( ! is_array( $product_ids ) ) {
			return array();
		}

		$product_ids = array_values( array_filter( array_map( 'absint', $product_ids ) ) );
		$fetch       = max( 1, (int) $fetch );
		$restrict_to = array_values( array_filter( array_map( 'absint', (array) $restrict_to ) ) );

		/*
		 * No source products — a store checkout sells whatever is in the visitor's cart,
		 * so there is nothing to measure relevance against. Rank on catalog signals
		 * instead of returning nothing, which is the honest answer rather than a dead end.
		 */
		if ( empty( $product_ids ) ) {
			$excluded_only = array_flip( array_values( array_filter( array_map( 'absint', (array) $exclude_ids ) ) ) );

			return empty( $restrict_to )
				? $this->fallback_candidates( array(), $context, $excluded_only, $fetch )
				: $this->rank_within_set( array(), $restrict_to, array(), $excluded_only, $fetch, $context, 0.0 );
		}

		/*
		 * Search depth. Unrestricted callers want exactly $fetch ranked candidates. A
		 * restricted caller uses the ranked list only to harvest scores for its own
		 * closed set, so the list has to run deeper than $fetch or pool members simply
		 * never appear in it — a pool of 10 asked for 1 result would score nothing.
		 */
		$depth = empty( $restrict_to )
			? $fetch
			: max( $fetch, (int) apply_filters( 'cartflows_pro_relevance_pool_search_depth', 200 ) );

		$affinity = array();
		$seen     = array_flip( $product_ids );
		$excluded = array_flip( $exclude_ids );

		foreach ( $product_ids as $product_id ) {
			foreach ( Cartflows_Pro_Product_Affinity::get_related_products( $product_id, $depth, $exclude_ids ) as $related ) {
				$rid = (int) $related['id'];
				if ( isset( $seen[ $rid ] ) ) {
					continue;
				}
				$affinity[ $rid ] = isset( $affinity[ $rid ] ) ? $affinity[ $rid ] + (float) $related['score'] : (float) $related['score'];
			}
		}

		$ranked = (array) apply_filters( 'cartflows_fbt_ranked_recommendations', $this->rank_by_affinity( $affinity ), $affinity, $product_ids, $depth );

		$source_price = $this->get_source_price( $product_ids, $context );

		// A closed set is ranked from the set outwards, never by filtering a global list.
		if ( ! empty( $restrict_to ) ) {
			return $this->rank_within_set( $ranked, $restrict_to, $seen, $excluded, $fetch, $context, $source_price );
		}

		$pool = array();

		foreach ( $ranked as $item ) {
			if ( count( $pool ) >= $fetch ) {
				break;
			}
			$id = isset( $item['id'] ) ? (int) $item['id'] : 0;
			// $excluded is checked here too: the ranked list comes back through a filter that
			// can inject candidates the affinity query never saw, and those must still honour
			// the caller's exclusions.
			if ( isset( $seen[ $id ] ) || isset( $excluded[ $id ] ) || isset( $seen[ wp_get_post_parent_id( $id ) ] ) || ! $this->is_offerable( $id ) ) {
				continue;
			}
			// Upsell is a hard price rule for every stage; fbt/crosssell bands only fallbacks.
			if ( 'upsell' === $context && ! $this->passes_price_band( $this->display_price( $id ), $source_price, 'upsell' ) ) {
				continue;
			}
			$seen[ $id ] = 1;
			$pool[]      = array(
				'id'            => $id,
				'score'         => (float) $item['score'],
				'source'        => (string) $item['source'],
				'match_percent' => (float) $item['match_percent'],
			);
		}

		if ( count( $pool ) < $fetch ) {
			$pool = array_merge( $pool, $this->fallback_candidates( $product_ids, $context, $seen + $excluded, $fetch - count( $pool ) ) );
		}

		// Upsell dead end: nothing clears the price rule (e.g. the source is the dearest product), so relax it — relevant-but-cheaper beats an empty answer.
		if ( 'upsell' === $context && empty( $pool ) ) {
			foreach ( $ranked as $item ) {
				if ( count( $pool ) >= $fetch ) {
					break;
				}
				$id = isset( $item['id'] ) ? (int) $item['id'] : 0;
				if ( isset( $seen[ $id ] ) || isset( $excluded[ $id ] ) || isset( $seen[ wp_get_post_parent_id( $id ) ] ) || ! $this->is_offerable( $id ) ) {
					continue;
				}
				$seen[ $id ] = 1;
				$pool[]      = array(
					'id'            => $id,
					'score'         => (float) $item['score'],
					'source'        => (string) $item['source'],
					'match_percent' => (float) $item['match_percent'],
				);
			}
			// The fbt banding only prioritises, never rejects, so this stage cannot come back empty.
			if ( count( $pool ) < $fetch ) {
				$pool = array_merge( $pool, $this->fallback_candidates( $product_ids, 'fbt', $seen + $excluded, $fetch - count( $pool ) ) );
			}
		}

		return $pool;
	}

	/**
	 * Rank a closed candidate set, best match first.
	 *
	 * Walks the caller's set rather than the ranked list, so every eligible member is
	 * considered whether or not it earned a score. Members with no signal keep their
	 * given order at the bottom under the 'pool' source, which means a caller that
	 * needs one product always gets a defensible answer instead of an empty array it
	 * cannot distinguish from "nothing is eligible".
	 *
	 * @since x.x.x
	 * @param array<int,mixed> $ranked       Ranked candidates harvested for their scores.
	 * @param int[]            $set          The closed candidate set, in the caller's own order.
	 * @param array<int,mixed> $seen         Source product IDs, which are never suggested back.
	 * @param array<int,mixed> $excluded     Caller exclusions.
	 * @param int              $fetch        Maximum results.
	 * @param string           $context      fbt | crosssell | upsell | order_bump.
	 * @param float            $source_price Price the upsell band is measured against.
	 * @return array<int,array{id:int,score:float,source:string,match_percent:float}>
	 */
	private function rank_within_set( $ranked, $set, $seen, $excluded, $fetch, $context, $source_price ) {

		$scores = array();
		foreach ( $ranked as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['id'] ) ) {
				continue;
			}
			$scores[ (int) $item['id'] ] = $item;
		}

		$out = array();
		foreach ( array_values( array_unique( $set ) ) as $position => $id ) {
			if ( isset( $seen[ $id ] ) || isset( $excluded[ $id ] ) || isset( $seen[ wp_get_post_parent_id( $id ) ] ) ) {
				continue;
			}
			if ( ! $this->is_offerable( $id ) ) {
				continue;
			}
			// Upsell's band is a hard rule at every stage, closed set included — otherwise
			// restricting the candidates would quietly buy an exemption from it.
			if ( 'upsell' === $context && ! $this->passes_price_band( $this->display_price( $id ), $source_price, 'upsell' ) ) {
				continue;
			}

			$hit = isset( $scores[ $id ] ) ? $scores[ $id ] : array();

			$out[] = array(
				'id'            => (int) $id,
				'score'         => isset( $hit['score'] ) ? (float) $hit['score'] : 0.0,
				'source'        => isset( $hit['source'] ) ? (string) $hit['source'] : 'pool',
				'match_percent' => isset( $hit['match_percent'] ) ? (float) $hit['match_percent'] : 0.0,
				'_position'     => $position,
			);
		}

		// Score descending, and the caller's own ordering as a stable tie-break —
		// usort is only guaranteed stable from PHP 8.0 and this plugin supports 7.2.
		usort(
			$out,
			static function ( $a, $b ) {
				if ( $a['score'] === $b['score'] ) {
					return $a['_position'] <=> $b['_position'];
				}
				return $b['score'] <=> $a['score'];
			}
		);

		$out = array_slice( $out, 0, $fetch );

		foreach ( $out as $index => $row ) {
			unset( $out[ $index ]['_position'] );
		}

		return $out;
	}

	/**
	 * The price a candidate's band is measured against.
	 *
	 * A product-page context has one obvious source. An Order Bump is judged against a
	 * whole cart, where "the first item" is arbitrary — the dearest line is what a
	 * complement should be proportionate to, so a £5 add-on beside a £500 item doesn't
	 * drag the band down with it.
	 *
	 * @since x.x.x
	 * @param int[]  $source_ids Source product IDs.
	 * @param string $context    fbt | crosssell | upsell | order_bump.
	 * @return float
	 */
	private function get_source_price( $source_ids, $context ) {

		if ( empty( $source_ids ) ) {
			return 0.0;
		}

		if ( 'order_bump' !== $context ) {
			return $this->display_price( (int) $source_ids[0] );
		}

		$prices = array();
		foreach ( $source_ids as $product_id ) {
			$prices[] = $this->display_price( $product_id );
		}

		return (float) max( $prices );
	}

	/**
	 * The product categories a candidate is compared against.
	 *
	 * Mirrors get_source_price(): product-page contexts judge against the first source
	 * only — long-standing behaviour the FBT widget depends on — while an Order Bump is
	 * judged against the whole cart, so every line's categories count.
	 *
	 * @since x.x.x
	 * @param int[]  $source_ids Source product IDs.
	 * @param string $context    fbt | crosssell | upsell | order_bump.
	 * @return array<int,bool> Term IDs as keys, for array_intersect_key.
	 */
	private function get_source_terms( $source_ids, $context ) {

		if ( empty( $source_ids ) ) {
			return array();
		}

		$scope = 'order_bump' === $context ? $source_ids : array( (int) $source_ids[0] );
		$terms = array();

		foreach ( $scope as $product_id ) {
			$terms = array_merge( $terms, wc_get_product_term_ids( $product_id, 'product_cat' ) );
		}

		return array_fill_keys( array_map( 'intval', array_unique( $terms ) ), true );
	}

	/**
	 * How much signal actually backs a recommendation for these products.
	 *
	 * Lets consumers word their reasoning honestly: 'rich' means real purchase history,
	 * 'thin' means we are mostly leaning on semantics, 'cold' means catalog guesswork.
	 *
	 * @since x.x.x
	 * @param int[] $source_ids Source product IDs.
	 * @return string One of 'rich', 'thin', 'cold'.
	 */
	public function get_signal_tier( $source_ids ) {

		$source_ids = array_values( array_filter( array_map( 'absint', (array) $source_ids ) ) );

		if ( empty( $source_ids ) ) {
			return 'cold';
		}

		$rich_threshold = max( 1, (int) apply_filters( 'cartflows_pro_relevance_rich_threshold', 5 ) );
		$best_rows      = 0;
		$has_embedding  = false;

		/*
		 * The strongest single source, not the total. Summing would let a big cart of
		 * poorly-connected products out-score one product with real history, so the tier
		 * would be reporting cart size as evidence.
		 */
		foreach ( $source_ids as $product_id ) {
			if ( class_exists( 'Cartflows_Pro_Product_Affinity' ) ) {
				$best_rows = max( $best_rows, count( Cartflows_Pro_Product_Affinity::get_related_products( $product_id, $rich_threshold ) ) );
			}

			if ( ! $has_embedding ) {
				$has_embedding = $this->has_embedding( $product_id );
			}

			// Nothing further can change the answer.
			if ( $best_rows >= $rich_threshold ) {
				return 'rich';
			}
		}

		return ( $best_rows > 0 || $has_embedding ) ? 'thin' : 'cold';
	}

	/**
	 * Whether a product has a stored embedding.
	 *
	 * Deliberately a bounded existence query rather than
	 * Cartflows_Pro_Product_Embeddings_DB::get_embedding(), which is uncached and would
	 * pull and decompress a full vector just to answer yes or no.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	private function has_embedding( $product_id ) {

		if ( ! class_exists( 'Cartflows_Pro_Product_Embeddings_DB' ) ) {
			return false;
		}

		global $wpdb;

		$table = Cartflows_Pro_Product_Embeddings_DB::get_table_name();

		//phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM $table WHERE product_id = %d LIMIT 1",
				absint( $product_id )
			)
		);
		//phpcs:enable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching

		return ! empty( $found );
	}

	/**
	 * Fill the pool from catalog signals when purchase history runs dry.
	 *
	 * Bestsellers are split into a banded/context-matched bucket ('category') and
	 * the remainder ('popular'); newest products ('recent') guarantee a non-empty
	 * answer on zero-sales stores. Upsell keeps its price rule on every stage.
	 *
	 * @since x.x.x
	 * @param int[]            $source_ids Source product IDs.
	 * @param string           $context    fbt | crosssell | upsell | order_bump.
	 * @param array<int,mixed> $seen       IDs the queries must never return (source + pool + caller exclusions).
	 * @param int              $need       How many more items to add.
	 * @return array<int,array{id:int,score:float,source:string,match_percent:float}>
	 */
	private function fallback_candidates( $source_ids, $context, $seen, $need ) {

		$source_price = $this->get_source_price( $source_ids, $context );
		$source_terms = $this->get_source_terms( $source_ids, $context );
		$primary      = array();
		$rest         = array();

		foreach ( $this->query_product_ids( 'popularity', 40, array_keys( $seen ) ) as $id ) {
			if ( isset( $seen[ $id ] ) || isset( $seen[ wp_get_post_parent_id( $id ) ] ) || ! $this->is_offerable( $id ) ) {
				continue;
			}
			$in_band    = $this->passes_price_band( $this->display_price( $id ), $source_price, $context );
			$shares_cat = (bool) array_intersect_key( array_flip( wc_get_product_term_ids( $id, 'product_cat' ) ), $source_terms );

			if ( 'upsell' === $context ) {
				// Leave out-of-band products unseen so the last-resort stage can still offer them.
				if ( ! $in_band ) {
					continue;
				}
				// Upsell prefers same-need upgrades: same category first.
				if ( $shares_cat ) {
					$primary[] = $id;
				} else {
					$rest[] = $id;
				}
			} elseif ( $in_band && ! $shares_cat ) {
				// Complements usually live in a different category.
				$primary[] = $id;
			} else {
				$rest[] = $id;
			}
			$seen[ $id ] = 1;
		}

		$out = array();
		foreach ( array(
			'category' => $primary,
			'popular'  => $rest,
		) as $source => $ids ) {
			foreach ( $ids as $id ) {
				if ( count( $out ) >= $need ) {
					return $out;
				}
				$out[] = array(
					'id'            => $id,
					'score'         => 0.0,
					'source'        => $source,
					'match_percent' => 0.0,
				);
			}
		}

		// Final guarantee for zero-sales stores: latest products.
		foreach ( $this->query_product_ids( 'date', 20, array_keys( $seen ) ) as $id ) {
			if ( count( $out ) >= $need ) {
				break;
			}
			if ( isset( $seen[ $id ] ) || isset( $seen[ wp_get_post_parent_id( $id ) ] ) || ! $this->is_offerable( $id ) ) {
				continue;
			}
			// Last resort keeps the upsell rule that matters — pricier than the source — but drops the band ceiling.
			if ( 'upsell' === $context && $this->display_price( $id ) <= $source_price ) {
				continue;
			}
			$seen[ $id ] = 1;
			$out[]       = array(
				'id'            => $id,
				'score'         => 0.0,
				'source'        => 'recent',
				'match_percent' => 0.0,
			);
		}

		return $out;
	}

	/**
	 * Bounded catalog query returning published product IDs.
	 *
	 * @since x.x.x
	 * @param string $orderby popularity | date.
	 * @param int    $limit   Max IDs.
	 * @param int[]  $exclude Product IDs to leave out at the query level.
	 * @return int[]
	 */
	private function query_product_ids( $orderby, $limit, $exclude ) {
		$ids = wc_get_products(
			array(
				'status'  => 'publish',
				'limit'   => $limit,
				'orderby' => $orderby,
				'order'   => 'DESC',
				// phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- Bounded query; exclusion must happen at the SQL level.
				'exclude' => $exclude,
				'return'  => 'ids',
			)
		);
		return is_array( $ids ) ? array_map( 'absint', $ids ) : array();
	}

	/**
	 * A candidate the widget can actually sell: visible, buyable, in stock, and
	 * (for variable/variation types) resolvable to a fully-specified variation.
	 *
	 * Public because consumers re-check a chosen product against live stock after
	 * their own selection step — stock moves between ranking and rendering.
	 *
	 * @since x.x.x
	 * @param int $product_id Candidate product ID.
	 * @return bool
	 */
	public function is_offerable( $product_id ) {

		$product = wc_get_product( $product_id );
		if ( ! $product instanceof WC_Product || 'publish' !== $product->get_status() || ! $product->is_purchasable() || ! $product->is_in_stock() || ! $product->is_visible() ) {
			return false;
		}

		if ( ! in_array( $product->get_type(), array( 'simple', 'variable', 'variation' ), true ) ) {
			return false;
		}

		// An "Any …" attribute can't be resolved by the widget's flat select.
		if ( $product instanceof WC_Product_Variation ) {
			return ! in_array( '', $product->get_variation_attributes(), true );
		}

		if ( $product instanceof WC_Product_Variable ) {
			foreach ( $product->get_available_variations( 'objects' ) as $variation ) {
				if ( $variation instanceof WC_Product_Variation && $variation->is_purchasable() && $variation->is_in_stock() && ! in_array( '', $variation->get_variation_attributes(), true ) ) {
					return true;
				}
			}
			return false;
		}

		return true;
	}

	/**
	 * Context price rule. Upsell = above the source; complements = around it.
	 *
	 * @since x.x.x
	 * @param float  $price        Candidate display price.
	 * @param float  $source_price Source display price.
	 * @param string $context      fbt | crosssell | upsell.
	 * @return bool
	 */
	private function passes_price_band( $price, $source_price, $context ) {
		if ( $source_price <= 0 ) {
			return true;
		}
		if ( 'upsell' === $context ) {
			return $price >= 1.1 * $source_price && $price <= 3 * $source_price;
		}
		return $price >= 0.25 * $source_price && $price <= 1.5 * $source_price;
	}

	/**
	 * Display price for a product ID, 0 when unavailable.
	 *
	 * @since x.x.x
	 * @param int $product_id Product ID.
	 * @return float
	 */
	private function display_price( $product_id ) {
		$product = wc_get_product( $product_id );
		return $product instanceof WC_Product ? (float) wc_get_price_to_display( $product ) : 0.0;
	}

	/**
	 * Rank recommendations by purchase-history affinity alone, best match first.
	 *
	 * This is the default ranking. The embeddings module re-ranks it with
	 * semantic similarity through `cartflows_fbt_ranked_recommendations`; when
	 * that module is inactive the affinity order stands.
	 *
	 * @since x.x.x
	 * @param array<int,float> $affinity Map of product_id => summed lift score.
	 * @return array<int,array{id:int,score:float,source:string,match_percent:float}> Ranked entries, highest relevance first.
	 */
	private function rank_by_affinity( $affinity ) {
		if ( empty( $affinity ) ) {
			return array();
		}

		arsort( $affinity );
		$max    = max( $affinity );
		$ranked = array();

		foreach ( $affinity as $id => $score ) {
			$percent  = $max > 0.0 ? ( (float) $score / $max ) * 100 : 0.0;
			$ranked[] = array(
				'id'            => (int) $id,
				'score'         => (float) $score,
				'source'        => 'affinity',
				'match_percent' => (float) round( $percent, 2 ),
			);
		}

		return $ranked;
	}
}
