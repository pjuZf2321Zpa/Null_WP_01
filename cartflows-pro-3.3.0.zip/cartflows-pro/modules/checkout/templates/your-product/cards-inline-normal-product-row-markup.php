<?php
/**
 * Cards Inline - Normal ptoduct row for cards template.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

echo wp_kses_post( $highlight_data['html_markup'] );

?>
<div class="wcf-item">
	<?php

	if ( 'single-selection' === $selection_type || 'multiple-selection' === $selection_type ) {

		if ( 'single-selection' === $selection_type ) { // single selection.
			include CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-radio-selector.php';
		} else { // multiple selection.
			include CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-checkbox-selector.php';
		}
	}

	require CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-image.php';
	?>
	<div class="wcf-item-content-options">
		<?php
		require CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-title.php';
		if ( $data['variable'] && isset( $type ) && 'popup' === $type ) {
			include CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-variation-popup-selector.php';
		}
		require CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-subtext.php';
		if ( 'cards-inline' === $selected_skin ) { 
			?>
			<div class="wcf-display-qty">Qty:<span class="selected_quantity"> 1 </span></div>
			<span class="wcf-qty-separator">|</span>
			<?php 
		} 
		require CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-price.php';
		?>
	</div>
	<div class="wcf-item-quantity">
	<?php
		require CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/your-product/item-quantity.php';

		
	?>
	</div>
</div>
<?php

