<?php
/**
 * Checkout markup.
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Checkout Markup
 *
 * @since 1.0.0
 */
class Cartflows_Pro_Checkout_Markup {



	/**
	 * Member Variable
	 *
	 * @var object instance
	 */
	private static $instance;

	/**
	 * Member Variable
	 *
	 * @var is_divi_enabled
	 */
	public $divi_status = false;

	/* Start-Pro-Feature */
	/**
	 * Preferred countries list for reordering.
	 *
	 * @since 2.3.0
	 * @var array<int, string>
	 */
	private $preferred_countries = array();
	/* End-Pro-Feature */

	/**
	 *  Initiator
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 *  Constructor
	 */
	public function __construct() {

		$this->include_required_class();

		add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'save_checkout_fields' ), 10, 2 );

		/* Scripts */
		add_action( 'cartflows_checkout_scripts', array( $this, 'checkout_order_scripts' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'load_compatibility_scripts_for_pro' ), 102 );

		/** Filter
		add_filter( 'cartflows_checkout_layout_template', array( $this, 'include_checkout_template' ), 10, 1 ); */

		add_action( 'cartflows_checkout_form_before', array( $this, 'two_step_actions' ), 10, 1 );

		add_action( 'cartflows_checkout_after_configure_cart', array( $this, 'after_configure_cart' ), 10, 1 );

		/* Start-Pro-Feature */
		add_action( 'cartflows_checkout_after_configure_cart', array( $this, 'setup_preferred_countries' ), 15, 1 );

		add_action( 'cartflows_wp', array( $this, 'maybe_expire_checkout' ) );
		add_action( 'template_redirect', array( $this, 'maybe_expire_embedded_checkout' ) );
		add_action( 'woocommerce_checkout_process', array( $this, 'block_expired_order_submission' ) );
		add_action( 'woocommerce_store_api_cart_errors', array( $this, 'block_expired_store_api_checkout' ) );
		add_action( 'cartflows_admin_save_step_meta', array( $this, 'sync_order_limit_window' ) );
		add_action( 'cartflows_offer_child_order_created', array( $this, 'attribute_replacement_order' ), 10, 2 );
		/* End-Pro-Feature */

		add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'display_billing_custom_order_meta' ), 10, 1 );
		add_action( 'woocommerce_admin_order_data_after_shipping_address', array( $this, 'display_shipping_custom_order_meta' ), 10, 1 );

		add_filter( 'woocommerce_email_order_meta_fields', array( $this, 'custom_woo_email_order_meta_fields' ), 10, 3 );

		add_filter( 'global_cartflows_js_localize', array( $this, 'add_frontend_localize_scripts' ) );

		add_filter( 'woocommerce_form_field_hidden', array( $this, 'wcf_form_field_hidden' ), 10, 4 );

		add_action( 'cartflows_checkout_before_shortcode', array( $this, 'add_products_using_url' ), 10 );

		add_action( 'cartflows_checkout_before_shortcode', array( $this, 'apply_url_coupon' ), 30 ); // Execute this action after the above action to avoid applying the coupon early.

		add_filter( 'cartflows_selected_checkout_products', array( $this, 'update_the_checkout_products_data' ), 10, 2 );

		add_filter( 'cartflows_skip_configure_cart', array( $this, 'skip_cart_configuration' ), 10, 2 );
	}

	/**
	 * Skip the cart configuration when product is added from URL.
	 *
	 * @param bool $skip_cart is skip cart.
	 * @param int  $checkout_id checkout id.
	 */
	public function skip_cart_configuration( $skip_cart, $checkout_id ) {

		if ( ! empty( $_GET['wcf-add-to-cart'] ) ) { //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			WC()->cart->empty_cart();
			$skip_cart = true;
		}

		return $skip_cart;
	}

	/**
	 * Add the product in cart through URL.
	 *
	 * @return void
	 */
	public function add_products_using_url() {

		$url_products = apply_filters( 'cartflows_add_to_cart_products_from_url', true );

		if ( $url_products ) {

			$products = isset( $_GET['wcf-add-to-cart'] ) ? explode( ',', sanitize_text_field( wp_unslash( $_GET['wcf-add-to-cart'] ) ) ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$quantity = isset( $_GET['wcf-qty'] ) ? explode( ',', sanitize_text_field( wp_unslash( $_GET['wcf-qty'] ) ) ) : array(); //phpcs:ignore WordPress.Security.NonceVerification.Recommended

			$checkout_id = _get_wcf_checkout_id();

			if ( ! empty( $products ) ) {
				foreach ( $products as $key => $product_id ) {

					$product_id = wcf_pro()->utils->get_variable_variation_product_id( $product_id );

					$product = wc_get_product( $product_id );

					if ( $product ) {
						$product_qunatity = isset( $quantity[ $key ] ) && ! empty( $quantity[ $key ] ) ? $quantity[ $key ] : 1;
						WC()->cart->add_to_cart( $product_id, $product_qunatity );
					}
				}

				Cartflows_Checkout_Markup::get_instance()->set_active_checkout_cookie_data( $checkout_id );
			}
		}
	}

	/**
	 * Merge product options array with checkout products.
	 *
	 * @param array $products products.
	 * @param int   $checkout_id checkout id.
	 */
	public function update_the_checkout_products_data( $products, $checkout_id ) {

		$products_options = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-enable-product-options' );

		if ( 'yes' === $products_options && $products ) {

			$products_data             = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-product-options-data' );
			$products_option_condition = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-product-options' );

			foreach ( $products as $key => $data ) {

				$unique_key = $data['unique_id'];

				if ( $unique_key && isset( $products_data[ $unique_key ] ) ) {
					$products[ $key ] = wp_parse_args( $products_data[ $unique_key ], $data );
				}

				if ( ! isset( $products_data[ $unique_key ]['add_to_cart'] ) && 'single-selection' === $products_option_condition ) {
					$products[ $key ]['add_to_cart'] = 'no';
				}
			}

			$cart_value = array_column( $products, 'add_to_cart' );

			if ( ! in_array( 'yes', $cart_value, true ) ) {
				$products[0]['add_to_cart'] = 'yes';
			}
		}

		return $products;
	}

	/**
	 * Apply the coupon if available in url.
	 */
	public function apply_url_coupon() {

		$url_coupon = apply_filters( 'cartflows_apply_coupon_from_url', true );

		if ( $url_coupon ) {

			$coupon = isset( $_GET['coupon'] ) ? sanitize_text_field( wp_unslash( $_GET['coupon'] ) ) : false; //phpcs:ignore WordPress.Security.NonceVerification.Recommended

			if ( $coupon ) {
				if ( WC()->cart->has_discount( $coupon ) ) {
					return;
				}
				WC()->cart->apply_coupon( $coupon );
			}
		}
	}

	/**
	 * Two Step Layout Actions.
	 *
	 * @param int $checkout_id checkout id.
	 * @since 1.1.9
	 */
	public function two_step_actions( $checkout_id ) {

		$checkout_layout = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-layout' );

		if ( 'two-step' == $checkout_layout ) {
			add_action( 'cartflows_add_before_main_section', array( $this, 'get_checkout_form_note' ), 10, 1 );

			add_action( 'woocommerce_checkout_before_customer_details', array( $this, 'add_two_step_first_step_wrapper' ), 13 );

			add_action( 'cartflows_add_before_main_section', array( $this, 'add_two_step_second_step_wrapper' ), 11 );

			add_action( 'cartflows_add_before_main_section', array( $this, 'add_two_step_nav_menu' ), 12, 1 );

			add_action( 'woocommerce_checkout_after_customer_details', array( $this, 'add_two_step_next_btn' ), 12 );

			add_action( 'woocommerce_checkout_after_customer_details', array( $this, 'add_two_step_closing_div' ), 13 );

			add_action( 'cartflows_add_after_main_section', array( $this, 'add_two_step_closing_div' ), 14 );
		}
	}

	/**
	 * Hidden Field Actions.
	 *
	 * @param string $field field.
	 * @param string $key key.
	 * @param array  $args args.
	 * @param string $value value.
	 *
	 * @since 1.1.9
	 */
	public function wcf_form_field_hidden( $field = '', $key = '', $args = array(), $value = '' ) {
		$field = '<input type="hidden" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" class="input-hidden" /> ';
		return $field;
	}

	/**
	 * Send custom fields in the order email.
	 *
	 * @param array  $fields of fields.
	 * @param string $sent_to_admin domain name to send.
	 * @param object $order of order details.
	 */
	public function custom_woo_email_order_meta_fields( $fields, $sent_to_admin, $order ) {

		// Return if order not found.
		if ( ! $order ) {
			return $fields;
		}

		$order_id    = $order->get_id();
		$checkout_id = $order->get_meta( '_wcf_checkout_id' );

		if ( ! $checkout_id ) {
			return $fields;
		}

		// Get custom fields.
		$custom_fields = get_post_meta( $checkout_id, 'wcf-custom-checkout-fields', true );

		if ( 'yes' === $custom_fields ) {
			// Billing Fields & Values.
			$billing_fields = get_post_meta( $checkout_id, 'wcf_field_order_billing', true );

			if ( empty( $billing_fields ) ) {
				$billing_fields = get_post_meta( $checkout_id, 'wcf_fields_billing', true );
			}
			if ( is_array( $billing_fields ) ) {
				foreach ( $billing_fields as $field => $data ) {
					if ( ( isset( $data['custom'] ) && $data['custom'] ) && ( isset( $data['show_in_email'] ) && $data['show_in_email'] ) ) {
						$fields[ $field ] = array(
							'label' => $data['label'],
							'value' => $order->get_meta( '_' . $field ),
						);
					}
				}
			}

			// Shipping Fields & Values.
			$shipping_fields = get_post_meta( $checkout_id, 'wcf_field_order_shipping', true );

			if ( empty( $shipping_fields ) ) {
				$shipping_fields = get_post_meta( $checkout_id, 'wcf_fields_shipping', true );
			}
			if ( is_array( $shipping_fields ) ) {
				foreach ( $shipping_fields as $field => $data ) {
					if ( ( isset( $data['custom'] ) && $data['custom'] ) && ( isset( $data['show_in_email'] ) && $data['show_in_email'] ) ) {
						$fields[ $field ] = array(
							'label' => $data['label'],
							'value' => $order->get_meta( '_' . $field ),
						);
					}
				}
			}
		}

		return $fields;
	}

	/**
	 * After configure cart.
	 *
	 * @param int $checkout_id checkout id.
	 */
	public function after_configure_cart( $checkout_id ) {

		// Don't add the coupon if cart is empty.
		if ( WC()->cart->is_empty() ) {
			return;
		}

		$discount_coupon = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-discount-coupon' );

		if ( is_array( $discount_coupon ) && ! empty( $discount_coupon ) ) {
			$discount_coupon = reset( $discount_coupon );
		}

		if ( ! empty( $discount_coupon ) ) {
			$show_coupon_msg = apply_filters( 'cartflows_show_applied_coupon_message', true );

			if ( ! $show_coupon_msg ) {
				add_filter( 'woocommerce_coupon_message', '__return_empty_string' );
			}

			WC()->cart->add_discount( $discount_coupon );

			if ( ! $show_coupon_msg ) {
				remove_filter( 'woocommerce_coupon_message', '__return_empty_string' );
			}
		}
	}

	/**
	 *  Add markup classes
	 *
	 * @return void
	 */
	public function include_required_class() {

		include_once CARTFLOWS_PRO_CHECKOUT_DIR . 'classes/class-cartflows-pre-checkout-offer-product.php';
		include_once CARTFLOWS_PRO_CHECKOUT_DIR . 'classes/class-cartflows-pro-product-options.php';
		include_once CARTFLOWS_PRO_CHECKOUT_DIR . 'classes/class-cartflows-pro-checkout-tab-animation.php';
		include_once CARTFLOWS_PRO_CHECKOUT_DIR . 'classes/class-cartflows-pro-checkout-rules.php';

		/* Start-Plus-Feature */
		if ( defined( 'CARTFLOWS_PRO_PLUGIN_TYPE' ) && in_array( CARTFLOWS_PRO_PLUGIN_TYPE, array( 'plus', 'pro' ), true ) && defined( 'CARTFLOWS_PRO_ORDER_BUMP_DIR' ) ) {
			// CF-1154 Phase 2: OB product + rules classes moved to modules/order-bump/ and are loaded by their own module bootstrap; the includes below remain as a defensive no-op safety net.
			include_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-product.php';
			include_once CARTFLOWS_PRO_ORDER_BUMP_DIR . 'classes/class-cartflows-pro-order-bump-rules.php';
		}
		/* End-Plus-Feature */
	}

	/**
	 * Load shortcode scripts.
	 *
	 * @return void
	 */
	public function checkout_order_scripts() {

		global $post;

		if ( Cartflows_Compatibility::get_instance()->is_divi_enabled() ||
			Cartflows_Compatibility::get_instance()->is_divi_builder_enabled( $post->ID )
		) {
			$this->divi_status = true;
		}

		wp_enqueue_style( 'wcf-pro-checkout', wcf_pro()->utils->get_css_url( 'checkout-styles' ), '', CARTFLOWS_PRO_VER );
		wp_enqueue_style( 'wcf-pro-multistep-checkout', wcf_pro()->utils->get_css_url( 'multistep-checkout' ), '', CARTFLOWS_PRO_VER );

		wp_enqueue_script(
			'wcf-pro-checkout',
			wcf_pro()->utils->get_js_url( 'checkout' ),
			array( 'jquery' ),
			CARTFLOWS_PRO_VER,
			true
		);

		$checkout_id = $post->ID;

		$pre_checkout_offer = get_post_meta( $checkout_id, 'wcf-pre-checkout-offer', true );

		if ( 'yes' === $pre_checkout_offer ) {
			wp_enqueue_script(
				'wcf-pro-pre-checkout',
				wcf_pro()->utils->get_js_url( 'pre-checkout' ),
				array( 'jquery', 'jquery-ui-dialog' ),
				CARTFLOWS_PRO_VER,
				true
			);
		}

		wp_enqueue_style( 'dashicons' );

		$style = get_post_meta( $checkout_id, 'wcf-pro-dynamic-css', true );

		$css_version = get_post_meta( $checkout_id, 'wcf-pro-dynamic-css-version', true );

		if ( empty( $style ) || CARTFLOWS_ASSETS_VERSION !== $css_version ) {
			$style = $this->generate_style();
			update_post_meta( $checkout_id, 'wcf-pro-dynamic-css', $style );
			update_post_meta( $checkout_id, 'wcf-pro-dynamic-css-version', CARTFLOWS_ASSETS_VERSION );
		}

		wp_add_inline_style( 'wcf-pro-checkout', $style );
	}

	/**
	 * Load compatibility scripts.
	 *
	 * @return void
	 */
	public function load_compatibility_scripts_for_pro() {

		if ( ! _is_wcf_checkout_type() ) {
			return;
		}

		// Add DIVI Compatibility css if DIVI theme is enabled.
		if ( $this->divi_status ) {
			wp_enqueue_style( 'wcf-checkout-styles-divi', wcf_pro()->utils->get_css_url( 'checkout-styles-divi' ), '', CARTFLOWS_PRO_VER );
		}
	}

	/**
	 * Generate styles.
	 *
	 * @return string
	 */
	public function generate_style() {

		if ( ! _is_wcf_checkout_type() ) {
			return;
		}

		global $post;

		$checkout_id = $post->ID;

		$output = '';

		$enable_design_setting = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-enable-design-settings' );

		$output .= $this->order_bump_dynamic_css( $checkout_id );

		/* Pre-checkout offer*/
		$is_pre_checkut_upsell = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer' );

		$primary_color    = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-primary-color' );
		$base_font_family = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-base-font-family' );

		if ( 'yes' === $is_pre_checkut_upsell ) {
			$pre_checkout_bg_color       = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-bg-color' );
			$pre_checkout_model_bg_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-model-bg-color' );
			$pre_checkout_title_color    = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-title-color' );
			$pre_checkout_subtitle_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-subtitle-color' );
			$pre_checkout_desc_color     = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-desc-color' );

			$navbar_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-navbar-color' );
			$button_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-pre-checkout-offer-button-color' );

			$pre_checkout_navbar_color = ! empty( $navbar_color ) ? $navbar_color : $primary_color;
			$pre_checkout_button_color = ! empty( $button_color ) ? $button_color : $primary_color;

			include CARTFLOWS_PRO_CHECKOUT_DIR . 'includes/pre-checkout-offer-dynamic-css.php';
		}
		/* Pre-checkout offer*/

		if ( 'yes' !== $enable_design_setting ) {
			return $output;
		}

		/* For single product quick view lightbox popup*/
		$r = '';
		$g = '';
		$b = '';

		$submit_tb_padding = '';
		$submit_lr_padding = '';

		$field_heading_color = '';
		$field_color         = '';
		$field_input_size    = '';
		$field_label_color   = '';
		$field_bg_color      = '';
		$field_border_color  = '';
		$field_tb_padding    = '';
		$field_lr_padding    = '';

		$input_font_family = '';
		$input_font_weight = '';

		$submit_button_height      = '';
		$submit_color              = '';
		$submit_bg_color           = $primary_color;
		$submit_border_color       = $primary_color;
		$submit_hover_color        = '';
		$submit_bg_hover_color     = $primary_color;
		$submit_border_hover_color = $primary_color;
		$section_heading_color     = $primary_color;
		$section_bg_color          = $primary_color;

		$is_advance_option = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-advance-options-fields' );

		$button_font_family  = '';
		$button_font_weight  = '';
		$heading_font_family = '';
		$heading_font_weight = '';
		$base_font_family    = $base_font_family;

		$hl_bg_color = '';

		if ( 'yes' == $is_advance_option ) {
			// Buttons, inputs, title : size, font, color, width options.
			$section_heading_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-heading-color' );

			$section_bg_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-section-bg-color' );

			$field_heading_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-field-heading-color' );

			$submit_tb_padding = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-tb-padding' );

			$submit_lr_padding = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-lr-padding' );

			$field_input_size = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-input-field-size' );

			$field_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-field-color' );

			$field_label_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-field-label-color' );

			$field_bg_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-field-bg-color' );

			$field_border_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-field-border-color' );

			$field_tb_padding = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-field-tb-padding' );

			$field_lr_padding = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-field-lr-padding' );

			$submit_button_height = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-input-button-size' );

			$submit_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-color' );

			$submit_bg_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-bg-color', $primary_color );

			$submit_border_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-border-color', $primary_color );

			$submit_hover_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-hover-color' );

			$submit_bg_hover_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-bg-hover-color', $primary_color );

			$submit_border_hover_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-submit-border-hover-color', $primary_color );

			// Font and weight options.
			$button_font_family = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-button-font-family' );

			$button_font_weight = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-button-font-weight' );

			$input_font_family = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-input-font-family' );

			$input_font_weight = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-input-font-weight' );

			$heading_font_family = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-heading-font-family' );

			$heading_font_weight = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-heading-font-weight' );

			$hl_bg_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-hl-bg-color' );

		}

		if ( isset( $primary_color ) ) {
			list($r, $g, $b) = sscanf( $primary_color, '#%02x%02x%02x' );
		}

		$enable_product_options = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-enable-product-options' );
		$product_option         = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-product-options' );
		$variation_option       = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-product-variation-options' );

		// Remove margin for perticular product variation option.
		if ( 'force-all' == $product_option && 'popup' == $variation_option ) {
			$output .= '.wcf-product-option-wrap .wcf-qty-options .wcf-qty-row .wcf-item-choose-options{
				margin: 5px 0 0 0px;
			}';
		}
		// Remove margin for perticular product variation option.

		// Highlight products styles.
		$yp_text_color      = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-yp-text-color' );
		$yp_bg_color        = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-yp-bg-color' );
		$yp_hl_text_color   = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-yp-hl-text-color' );
		$yp_hl_bg_color     = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-yp-hl-bg-color' );
		$yp_hl_border_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-yp-hl-border-color' );
		$yp_flag_text_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-yp-hl-flag-text-color' );
		$yp_flag_bg_color   = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-yp-hl-flag-bg-color' );

		// Bump Order.
		$bump_border_style         = '';
		$bump_border_color         = '';
		$bump_bg_color             = '';
		$bump_label_color          = '';
		$bump_label_bg_color       = '';
		$bump_desc_text_color      = '';
		$bump_hl_text_color        = '';
		$bump_blinking_arrow_color = '';

		/*
		 * Two step Layout
		 */

		// Get checkout page layout.
		$checkout_layout = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-layout' );

		if ( 'two-step' === $checkout_layout ) {

			$checkout_note_enabled = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-box-note', false );

			$step_two_width = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-two-step-section-width' );

			$two_step_box_text_color = '';

			$two_step_box_bg_color = '';

			$two_step_section_border = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-two-step-section-border' );

			if ( 'yes' == $checkout_note_enabled ) {
				$two_step_box_text_color = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-box-note-text-color', '' );
				$two_step_box_bg_color   = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-box-note-bg-color', $primary_color );
			}
		}
		/* Two step Layout */

		// Override CSS vars for product options.
		$output     .= '.wcf-product-option-wrap {';
			$output .= ! empty( $yp_text_color ) ? '--wcf-yp-text-color: ' . $yp_text_color . ';' : '';
			$output .= ! empty( $yp_bg_color ) ? '--wcf-yp-bg-color: ' . $yp_bg_color . ';' : '';
			$output .= ! empty( $yp_hl_text_color ) ? '--wcf-yp-hl-text-color: ' . $yp_hl_text_color . ';' : '';
			$output .= ! empty( $yp_hl_bg_color ) ? '--wcf-yp-hl-bg-color: ' . $yp_hl_bg_color . ';' : '';
			$output .= ! empty( $yp_hl_border_color ) ? '--wcf-yp-hl-border-color: ' . $yp_hl_border_color . ';' : '';
			$output .= ! empty( $yp_flag_text_color ) ? '--wcf-yp-hl-flag-text-color: ' . $yp_flag_text_color . ';' : '';
			$output .= ! empty( $yp_flag_bg_color ) ? '--wcf-yp-hl-flag-bg-color: ' . $yp_flag_bg_color . ';' : '';
		$output     .= '}';

		if ( $this->divi_status ) {

			include CARTFLOWS_PRO_CHECKOUT_DIR . 'includes/checkout-pro-dynamic-divi-css.php';

		} else {

			include CARTFLOWS_PRO_CHECKOUT_DIR . 'includes/checkout-pro-dynamic-css.php';
		}

		return $output;
	}

		/**
		 * To generate the dynamic css for multiple order bumps.
		 *
		 * @param  int $checkout_id checkout id.
		 */
	public function order_bump_dynamic_css( $checkout_id ) {

		$multi_ob = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-order-bumps' );
		$ob_css   = '';

		if ( empty( $multi_ob ) && 'yes' !== get_post_meta( $checkout_id, 'wcf-order-bump-migrated', true ) && 'yes' === wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-order-bump' ) ) {

			$multi_ob          = array();
			$product_image     = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-order-bump-image' );
			$show_image_mobile = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-show-bump-image-mobile' );
			$show_image_mobile = 'yes' === $show_image_mobile ? 'no' : 'yes';

			$old_ob = array(
				'status'            => true,
				'enable_show_image' => ! empty( $product_image ) ? 'yes' : 'no',
				'ob_image_position' => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-image-position' ),
				'ob_image_width'    => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-image-width' ),
				'show_image_mobile' => $show_image_mobile,
				'style'             => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-order-bump-style' ),
				'border_color'      => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-border-color' ),
				'border_style'      => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-border-style' ),
				'bg_color'          => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-bg-color' ),
				'label_color'       => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-label-color' ),
				'label_bg_color'    => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-label-bg-color' ),
				'desc_text_color'   => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-desc-text-color' ),
				'hl_text_color'     => wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-bump-hl-text-color' ),
			);
			array_push( $multi_ob, $old_ob );
		}

		if ( is_array( $multi_ob ) && ! empty( $multi_ob ) ) {

			$default_meta    = Cartflows_Pro_Checkout_Default_Meta::get_instance()->order_bump_default_meta();
			$ob_default_meta = array();
			foreach ( $default_meta as $key => $value ) {
				$ob_default_meta[ $key ] = $value['default'];
			}

			foreach ( $multi_ob as $index => $order_bump_data ) {

				if ( ! $order_bump_data['status'] ) {
					continue;
				}

				$order_bump_data         = wp_parse_args( $order_bump_data, $ob_default_meta );
				$ob_id                   = isset( $order_bump_data['id'] ) ? $order_bump_data['id'] : '';
				$bump_border_style_value = isset( $order_bump_data['style'] ) ? $order_bump_data['style'] : 'style-1';

				// Define bump order layout.
				if ( 'inherit' !== $bump_border_style_value ) {
					$bump_border_style = $order_bump_data['border_style'];
				}

				if ( in_array( $order_bump_data['style'], array( 'style-1', 'style-2', 'style-3', 'style-4', 'style-5' ), true ) && 'inherit' === $bump_border_style ) {
					$bump_border_style = 'solid';
				}

				// Get bump order styling values.
				$order_bump_position    = isset( $order_bump_data['position'] ) ? $order_bump_data['position'] : 'after-order';
				$bump_border_color      = isset( $order_bump_data['border_color'] ) ? $order_bump_data['border_color'] : '';
				$bump_bg_color          = isset( $order_bump_data['bg_color'] ) ? $order_bump_data['bg_color'] : '';
				$bump_box_border_width  = isset( $order_bump_data['box_border_width'] ) ? $order_bump_data['box_border_width'] : '';
				$bump_box_border_radius = isset( $order_bump_data['box_border_radius'] ) ? $order_bump_data['box_border_radius'] : '';

				$bump_box_shadow_color      = isset( $order_bump_data['box_shadow_color'] ) ? $order_bump_data['box_shadow_color'] : '';
				$bump_box_shadow_horizontal = isset( $order_bump_data['box_shadow_horizontal'] ) ? $order_bump_data['box_shadow_horizontal'] : '';
				$bump_box_shadow_vertical   = isset( $order_bump_data['box_shadow_vertical'] ) ? $order_bump_data['box_shadow_vertical'] : '';
				$bump_box_shadow_blur       = isset( $order_bump_data['box_shadow_blur'] ) ? $order_bump_data['box_shadow_blur'] : '';
				$bump_box_shadow_spread     = isset( $order_bump_data['box_shadow_spread'] ) ? $order_bump_data['box_shadow_spread'] : '';

				$bump_label_color = isset( $order_bump_data['label_color'] ) ? $order_bump_data['label_color'] : '';

				if ( in_array( $order_bump_data['style'], array( 'style-3', 'style-4' ), true ) ) {
					$bump_label_color = isset( $order_bump_data['title_text_color'] ) ? $order_bump_data['title_text_color'] : '';
				}

				$bump_label_bg_color = isset( $order_bump_data['label_bg_color'] ) ? $order_bump_data['label_bg_color'] : '';

				$bump_desc_text_color = isset( $order_bump_data['desc_text_color'] ) ? $order_bump_data['desc_text_color'] : '';

				$bump_hl_text_color = isset( $order_bump_data['hl_text_color'] ) ? $order_bump_data['hl_text_color'] : '';

				$bump_button_text_color = isset( $order_bump_data['button_text_color'] ) ? $order_bump_data['button_text_color'] : '';
				$bump_button_color      = isset( $order_bump_data['button_color'] ) ? $order_bump_data['button_color'] : '';

				$bump_button_hover_color      = isset( $order_bump_data['button_hover_color'] ) ? $order_bump_data['button_hover_color'] : '';
				$bump_button_text_hover_color = isset( $order_bump_data['button_text_hover_color'] ) ? $order_bump_data['button_text_hover_color'] : '';

				$bump_button_border_width  = isset( $order_bump_data['button_border_width'] ) ? $order_bump_data['button_border_width'] : '';
				$bump_button_border_style  = isset( $order_bump_data['button_border_style'] ) ? $order_bump_data['button_border_style'] : '';
				$bump_button_border_color  = isset( $order_bump_data['button_border_color'] ) ? $order_bump_data['button_border_color'] : '';
				$bump_button_border_radius = isset( $order_bump_data['button_border_radius'] ) ? $order_bump_data['button_border_radius'] : '';

				$bump_blinking_arrow_color = '';

				$enabled_bump_image        = isset( $order_bump_data['enable_show_image'] ) ? $order_bump_data['enable_show_image'] : 'no';
				$bump_image_position       = isset( $order_bump_data['ob_image_position'] ) ? $order_bump_data['ob_image_position'] : 'left';
				$bump_image_width          = isset( $order_bump_data['ob_image_width'] ) ? $order_bump_data['ob_image_width'] : '';
				$enabled_bump_image_mobile = isset( $order_bump_data['show_image_mobile'] ) ? $order_bump_data['show_image_mobile'] : 'yes';

				$bump_width = isset( $order_bump_data['width'] ) ? $order_bump_data['width'] : '100';

				$label_border_style  = isset( $order_bump_data['label_border_style'] ) ? $order_bump_data['label_border_style'] : 'solid';
				$label_border_width  = isset( $order_bump_data['label_border_width'] ) ? $order_bump_data['label_border_width'] : 'solid';
				$label_border_radius = isset( $order_bump_data['label_border_radius'] ) ? $order_bump_data['label_border_radius'] : 'solid';

				$label_border_color = isset( $order_bump_data['label_border_color'] ) ? $order_bump_data['label_border_color'] : '';

				$bump_title_color = isset( $order_bump_data['title_text_color'] ) ? $order_bump_data['title_text_color'] : '';

				if ( 'inherit' === $label_border_style && 'style-5' === $order_bump_data['style'] ) {
					$label_border_style = '';
				} else {
					$label_border_style = 'solid';
				}

				if ( in_array( $order_bump_data['style'], array( 'style-4', 'style-5' ), true ) && 'inherit' === $bump_button_border_style ) {
					$bump_button_border_style = '';
				}

				// CF-1154 Phase 2: dynamic CSS template was relocated into modules/order-bump/.
				include CARTFLOWS_PRO_ORDER_BUMP_DIR . 'includes/order-bump-dynamic-css.php';

			}
		}

		return $ob_css;
	}

	/**
	 * Save checkout fields.
	 *
	 * @param int   $order_id order id.
	 * @param array $posted posted data.
	 * @return void
	 */
	public function save_checkout_fields( $order_id, $posted ) {
		/*
		 * Build the accepted-bump list from the cart rather than from the posted hidden
		 * field. The same method populates that field when the checkout renders, so the
		 * shape is unchanged — but the customer no longer chooses the contents. The rules
		 * engine, webhooks and analytics all read the meta this writes.
		 *
		 * The cart is still populated here: woocommerce_checkout_update_order_meta fires
		 * inside create_order(), before WooCommerce empties it.
		 */
		$order_bumps = Cartflows_Pro_Order_Bump_Product::get_instance()->get_existing_bump_products_data();

		if ( ! empty( $order_bumps ) ) {

			$ob_data = array();

			foreach ( $order_bumps as $key => $order_bump ) {

				if ( is_array( $order_bump ) ) {
					foreach ( $order_bump as $data_key => $data ) {
						$ob_data[ sanitize_text_field( $key ) ][ sanitize_text_field( $data_key ) ] = sanitize_text_field( $data );
					}
				}
			}

			$order = wc_get_order( $order_id );

			if ( ! $order instanceof WC_Order ) {
				return;
			}

			if ( $order ) {
				$order->update_meta_data( '_wcf_bump_products', $ob_data );
				$order->save();

				$bump_product_ids = array_column( $ob_data, 'id' );

				foreach ( $order->get_items() as $item_id => $item ) {
					$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
					if ( in_array( (string) $product_id, array_map( 'strval', $bump_product_ids ), true ) ) {
						wc_add_order_item_meta( $item_id, '_cartflows_order_bump', 'yes' );
					}
				}
			}
		}
	}

	/**
	 * Save checkout fields.
	 *
	 * @param string $layout_style layout style.
	 * @return link
	 */
	public function include_checkout_template( $layout_style ) {

		if ( ( 'two-step' === $layout_style ) || ( 'one-column' === $layout_style ) ) {
			return CARTFLOWS_PRO_CHECKOUT_DIR . 'templates/embed/checkout-template-simple.php';
		}

		return $layout_style;
	}

	/**
	 * Display Two Step Nav Menu.
	 *
	 * @param string $layout_style layout style.
	 * @return markup
	 */
	public function add_two_step_nav_menu( $layout_style ) {

		if ( 'two-step' === $layout_style ) {
			// Get Checkout ID.
			global $post;

			$checkout_id = false;

			if ( _is_wcf_checkout_type() ) {
				$checkout_id = $post->ID;
			} elseif ( is_admin() && isset( $_POST['id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing

				$checkout_id = intval( $_POST['id'] );// phpcs:ignore WordPress.Security.NonceVerification.Missing
			}

			if ( ! $checkout_id ) {
				return;
			}

			// Get/Set default values.
			$is_note_enabled         = '';
			$checkout_note           = '';
			$step_one_title          = '';
			$step_one_sub_title      = '';
			$step_two_title          = '';
			$step_two_sub_title      = '';
			$two_step_section_border = '';

			// Get default values from the default meta to show if the advance option is not enabled.
			$all_fields = Cartflows_Default_Meta::get_instance()->get_checkout_fields( $checkout_id );

			$step_one_title     = $all_fields['wcf-checkout-step-one-title']['default'];
			$step_one_sub_title = $all_fields['wcf-checkout-step-one-sub-title']['default'];
			$step_two_title     = $all_fields['wcf-checkout-step-two-title']['default'];
			$step_two_sub_title = $all_fields['wcf-checkout-step-two-sub-title']['default'];

			// Get the values form the applied settings.
			// Get step titles.
			$step_one_title     = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-step-one-title', '' );
			$step_one_sub_title = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-step-one-sub-title', '' );
			$step_two_title     = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-step-two-title', '' );
			$step_two_sub_title = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-step-two-sub-title', '' );

			$two_step_section_border = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-two-step-section-border' );

			$two_step_html = '';

				$two_step_html .= "<div class='wcf-embed-checkout-form-nav wcf-border-" . esc_attr( $two_step_section_border ) . " '>";

				$two_step_html             .= "<ul class='wcf-embed-checkout-form-steps'>";
					$two_step_html         .= "<div class='steps step-one wcf-current'>";
						$two_step_html     .= "<a href='#customer_details'>";
							$two_step_html .= "<div class='step-number'>1</div>";

							$two_step_html .= "<div class='step-heading'>";

								$two_step_html .= "<div class='step-name'>" . esc_html( $step_one_title ) . '</div>';
								$two_step_html .= "<div class='step-sub-name'>" . esc_html( $step_one_sub_title ) . '</div>';

							$two_step_html .= '</div>';

						$two_step_html .= '</a>';
					$two_step_html     .= '</div>';

					$two_step_html         .= "<div class='steps step-two'>";
						$two_step_html     .= "<a href='#wcf-order-wrap'>";
							$two_step_html .= "<div class='step-number'>2</div>";

								$two_step_html .= "<div class='step-heading'>";

									$two_step_html .= "<div class='step-name'>" . esc_html( $step_two_title ) . '</div>';
									$two_step_html .= "<div class='step-sub-name'>" . esc_html( $step_two_sub_title ) . '</div>';

								$two_step_html .= '</div>';

						$two_step_html .= '</a>';
					$two_step_html     .= '</div>';

				$two_step_html .= '</ul>';
			$two_step_html     .= '</div>';

			echo wp_kses_post( $two_step_html );
		}

		return $layout_style;
	}

	/**
	 * Display Two Step note box.
	 *
	 * @param string $layout_style layout style.
	 * @return void
	 */
	public function get_checkout_form_note( $layout_style ) {

		// Get Checkout ID.
		$checkout_id = false;

		global $post;

		if ( $post ) {
			$checkout_id = $post->ID;
		} elseif ( is_admin() && isset( $_POST['id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing

			$checkout_id = intval( $_POST['id'] );// phpcs:ignore WordPress.Security.NonceVerification
		}

		if ( ! $checkout_id ) {
			return;
		}

		$is_note_enabled = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-box-note', false );

		if ( 'yes' == $is_note_enabled ) {

			$checkout_note = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-box-note-text', '' );

			$two_step_note = '';

			$two_step_note .= "<div class='wcf-embed-checkout-form-note'>";

			$two_step_note .= '<p>' . wp_kses_post( $checkout_note ) . '</p>';

			$two_step_note .= '</div>';

			echo wp_kses_post( $two_step_note );
		}
	}

	/**
	 * Display Two Step Nav Next Button.
	 */
	public function add_two_step_next_btn() {

		global $post;

		$checkout_id = false;

		if ( _is_wcf_checkout_type() ) {
			$checkout_id = $post->ID;
		} elseif ( is_admin() && isset( $_POST['id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing

			$checkout_id = intval( $_POST['id'] );//phpcs:ignore WordPress.Security.NonceVerification
		}

		if ( ! $checkout_id ) {
			return;
		}

		$checkout_layout = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-layout' );

		$button_title = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-offer-button-title', '' );

		$button_sub_title = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-checkout-offer-button-sub-title', '' );

		if ( 'two-step' === $checkout_layout ) {
			$two_step_next_btn_html = '';

			$two_step_next_btn_html .= '<div class="wcf-embed-checkout-form-nav-btns">';

				$two_step_next_btn_html     .= '<a href="#wcf-order-wrap" class="button wcf-next-button" >';
					$two_step_next_btn_html .= '<span class="wcf-next-button-content">';

			if ( '' != $button_title ) {
						$two_step_next_btn_html     .= '<span class="wcf-next-button-icon-wrap">';
							$two_step_next_btn_html .= '<span class="dashicons dashicons-arrow-right-alt"></span>';
							$two_step_next_btn_html .= '<span class="wcf-button-text">' . esc_html( $button_title ) . '</span>';
						$two_step_next_btn_html     .= '</span>';
			}

			if ( '' != $button_sub_title ) {
						$two_step_next_btn_html .= '<span class="wcf-button-sub-text">' . esc_html( $button_sub_title ) . '</span>';
			}
					$two_step_next_btn_html .= '</span>';
				$two_step_next_btn_html     .= '</a>';

			$two_step_next_btn_html .= '</div>';

			echo wp_kses_post( $two_step_next_btn_html );
		}
	}

	/**
	 * Display billing custom field data on order page
	 *
	 * @param obj $order Order object.
	 * @return void
	 */
	public function display_billing_custom_order_meta( $order ) {

		if ( ! $order ) {
			return;
		}

		$checkout_id = $order->get_meta( '_wcf_checkout_id' );

		/* Custom Field To Do */
		$custom_fields = get_post_meta( $checkout_id, 'wcf-custom-checkout-fields', true );

		if ( 'yes' === $custom_fields ) {
			$output = '';

			$billing_fields = get_post_meta( $checkout_id, 'wcf_fields_billing', true );
			if ( is_array( $billing_fields ) ) {
				foreach ( $billing_fields as $field => $data ) {
					if ( isset( $data['custom'] ) && $data['custom'] ) {
						$output .= '<p><strong>' . $data['label'] . ':</strong> ' . $order->get_meta( '_' . $field ) . '</p>';
					}
				}
			}

			if ( '' !== $output ) {
				$output = '<h3>' . __( 'Billing Custom Fields', 'cartflows-pro' ) . '</h3>' . $output;
			}

			echo wp_kses_post( $output );
		}
	}

	/**
	 * Display shipping custom field data on order page
	 *
	 * @param obj $order Order object.
	 * @return void
	 */
	public function display_shipping_custom_order_meta( $order ) {

		if ( ! $order ) {
			return;
		}

		$order_id    = $order->get_id();
		$checkout_id = $order->get_meta( '_wcf_checkout_id' );

		/* Custom Field To Do */
		$custom_fields = get_post_meta( $checkout_id, 'wcf-custom-checkout-fields', true );

		if ( 'yes' === $custom_fields ) {
			$output = '';

			$shipping_fields = get_post_meta( $checkout_id, 'wcf_fields_shipping', true );
			if ( is_array( $shipping_fields ) ) {
				foreach ( $shipping_fields as $field => $data ) {
					if ( isset( $data['custom'] ) && $data['custom'] ) {
						$output .= '<p><strong>' . $data['label'] . ':</strong> ' . $order->get_meta( '_' . $field ) . '</p>';
					}
				}
			}

			if ( '' !== $output ) {
				$output = '<h3>' . __( 'Shipping Custom Fields', 'cartflows-pro' ) . '</h3>' . $output;
			}

			echo wp_kses_post( $output );
		}
	}

	/**
	 * Add second step opening dev
	 *
	 * @since 1.1.9
	 */
	public function add_two_step_second_step_wrapper() {
		echo "<div class='wcf-two-step-wrap'> ";
	}

	/**
	 * Add first step opening dev
	 *
	 * @since X.X.X
	 */
	public function add_two_step_first_step_wrapper() {
		echo '<div class="wcf-checkout-fields-wrapper">';
	}

	/**
	 * Add Startng & closing dev
	 *
	 * @since 1.1.9
	 */
	public function add_two_step_closing_div() {
		echo '</div> ';
	}


	/**
	 * Add localize variables.
	 *
	 * @since 1.1.5
	 * @param array $localize settings.
	 * @return array $localize settings.
	 */
	public function add_frontend_localize_scripts( $localize ) {

		$localize['allow_autocomplete_zipcode'] = apply_filters( 'cartflows_autocomplete_zip_data', 'no' );
		$localize['add_to_cart_text']           = __( 'Processing...', 'cartflows-pro' );
		$localize['wcf_refresh_checkout']       = apply_filters( 'cartflows_checkout_trigger_update_order_review', false );

		return $localize;
	}
	/* Start-Pro-Feature */

	/**
	 * Read preferred countries meta and register WooCommerce country filters.
	 *
	 * Called on `cartflows_checkout_after_configure_cart` (priority 15).
	 * Registers the reorder filter only when the feature is enabled and
	 * at least one preferred country is configured.
	 *
	 * @since 2.3.0
	 * @param int $checkout_id The current checkout step post ID.
	 * @return void
	 */
	public function setup_preferred_countries( $checkout_id ) {

		$enabled = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-enable-preferred-countries' );

		if ( 'yes' !== $enabled ) {
			return;
		}

		$preferred = wcf()->options->get_checkout_meta_value( $checkout_id, 'wcf-preferred-countries' );

		if ( empty( $preferred ) || ! is_array( $preferred ) ) {
			return;
		}

		$this->preferred_countries = $preferred;

		add_filter( 'woocommerce_countries_allowed_countries', array( $this, 'reorder_preferred_countries' ), 10, 1 );
		add_filter( 'woocommerce_countries_shipping_countries', array( $this, 'reorder_preferred_countries' ), 10, 1 );
		add_filter( 'option_woocommerce_ship_to_countries', array( $this, 'handle_ship_to_countries_option' ), 10, 1 );
	}

	/**
	 * Reorder countries array so that preferred countries appear at the top.
	 *
	 * Uses `array_merge` so the preferred codes are listed first; WooCommerce
	 * renders the `<select>` dropdown in array order, which is all that is needed.
	 *
	 * @since 2.3.0
	 * @param array<string, string> $countries Associative array of country codes => country names.
	 * @return array<string, string> Reordered countries array.
	 */
	public function reorder_preferred_countries( $countries ) {

		$top_countries = array();

		foreach ( $this->preferred_countries as $code ) {
			$code = trim( $code );
			if ( isset( $countries[ $code ] ) ) {
				$top_countries[ $code ] = $countries[ $code ];
			}
		}

		if ( empty( $top_countries ) ) {
			return $countries;
		}

		return array_merge( $top_countries, $countries );
	}

	/**
	 * Force WooCommerce to use the allowed-countries list when "Ship to all countries" is set.
	 *
	 * When the WooCommerce "Ship to" option is `'all'`, `get_shipping_countries()` bypasses
	 * the `woocommerce_countries_shipping_countries` filter. Returning an empty string here
	 * makes WooCommerce fall back to the specific allowed-countries list so our reorder filter
	 * is respected.
	 *
	 * @since 2.3.0
	 * @param string $status The current value of the `woocommerce_ship_to_countries` option.
	 * @return string Modified status value.
	 */
	public function handle_ship_to_countries_option( $status ) {

		if ( 'all' === $status ) {
			return '';
		}

		return $status;
	}

	/**
	 * Redirect visitors away from an expired checkout step.
	 *
	 * @since 2.3.0
	 * @param int $step_id current step ID.
	 * @return void
	 */
	public function maybe_expire_checkout( $step_id ) {

		$step_id = absint( $step_id );

		if ( 'checkout' !== get_post_meta( $step_id, 'wcf-step-type', true ) ) {
			return;
		}

		$flow_id = absint( get_post_meta( $step_id, 'wcf-flow-id', true ) );

		// The Store Checkout is never expired — closing it would block the whole store.
		$store_checkout_flow = absint( get_option( '_cartflows_store_checkout' ) );
		if ( $store_checkout_flow && $store_checkout_flow === $flow_id ) {
			return;
		}

		if ( wcf()->flow->is_flow_testmode( $flow_id ) ) {
			return;
		}

		$reason = $this->get_expiry_reason( $step_id );

		if ( false === $reason ) {
			return;
		}

		// Flow managers still see the page, with a notice instead of the redirect.
		if ( is_user_logged_in() && current_user_can( 'cartflows_manage_flows_steps' ) ) {
			// This CartFlows hook fires on every checkout render, including the empty-cart state.
			add_action( 'cartflows_checkout_form_before', array( $this, 'render_expiry_preview_notice' ) );
			return;
		}

		$this->redirect_expired_checkout( $step_id, $reason );
	}

	/**
	 * Get the reason this checkout is expired, if any.
	 *
	 * @since 2.3.0
	 * @param int $step_id step ID.
	 * @return string|false 'date', 'order_limit', or false when the checkout is open.
	 */
	public function get_expiry_reason( $step_id ) {

		if ( 'yes' === wcf()->options->get_checkout_meta_value( $step_id, 'wcf-expire-after-date' ) && $this->is_expiry_date_passed( $step_id ) ) {
			return 'date';
		}

		if ( 'yes' === wcf()->options->get_checkout_meta_value( $step_id, 'wcf-expire-after-orders' ) ) {
			$threshold = absint( wcf()->options->get_checkout_meta_value( $step_id, 'wcf-expire-orders-threshold' ) );

			if ( $threshold >= 1 && $this->is_order_limit_reached( $step_id, $threshold ) ) {
				return 'order_limit';
			}
		}

		return false;
	}

	/**
	 * Check whether the configured expiry date & time has passed.
	 *
	 * @since 2.3.0
	 * @param int $step_id step ID.
	 * @return bool
	 */
	public function is_expiry_date_passed( $step_id ) {

		$cutoff = wcf()->options->get_checkout_meta_value( $step_id, 'wcf-expire-date' );

		if ( ! is_string( $cutoff ) ) {
			return false;
		}

		// Tolerates single-digit month/day/hour and a seconds suffix; anything else keeps the feature inert.
		if ( ! preg_match( '/^(\d{4})-(\d{1,2})-(\d{1,2})(?: (\d{1,2}):(\d{2})(?::\d{2})?)?$/', trim( $cutoff ), $parts ) ) {
			return false;
		}

		// A date-only value keeps the checkout open through that whole day.
		$year   = absint( $parts[1] );
		$month  = absint( $parts[2] );
		$day    = absint( $parts[3] );
		$hour   = isset( $parts[4] ) ? absint( $parts[4] ) : 23;
		$minute = isset( $parts[5] ) ? absint( $parts[5] ) : 59;

		// Impossible calendar values (month 13, hour 24, ...) keep the feature inert.
		if ( ! checkdate( $month, $day, $year ) || $hour > 23 || $minute > 59 ) {
			return false;
		}

		$cutoff = sprintf( '%04d-%02d-%02d %02d:%02d', $year, $month, $day, $hour, $minute );

		$now = wp_date( 'Y-m-d H:i' );

		// Lexicographic compare is chronologically correct for this fixed format.
		return is_string( $now ) && $now > $cutoff;
	}

	/**
	 * Check whether this checkout has reached its configured order limit.
	 *
	 * @since 2.3.0
	 * @param int $step_id step ID.
	 * @param int $threshold configured order limit.
	 * @return bool
	 */
	public function is_order_limit_reached( $step_id, $threshold ) {

		// Counted live on every check: refunds/cancellations/deletions reopen automatically and clones
		// never inherit a stale "closed" state, because there is no cached state to go stale.
		return $this->get_placed_orders_count( $step_id, $threshold ) >= $threshold;
	}

	/**
	 * Count orders placed through this checkout step, capped at the threshold.
	 *
	 * @since 2.3.0
	 * @param int $step_id step ID.
	 * @param int $threshold configured order limit.
	 * @return int
	 */
	protected function get_placed_orders_count( $step_id, $threshold ) {

		// A/B arms share one budget: count orders attributed to any step in the group.
		$group_ids = array_map( 'strval', $this->get_ab_group_step_ids( $step_id ) );

		$args = array(
			'meta_query' => array( //phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Meta-based order lookup, same pattern as free plugin's flow order queries.
				array(
					'key'     => '_wcf_checkout_id',
					'value'   => $group_ids,
					'compare' => 'IN',
				),
			),
			'status'     => $this->get_counted_order_statuses( $step_id ),
			'return'     => 'ids',
			'limit'      => $threshold,
		);

		// Only orders placed after the toggle was enabled count toward the limit.
		$started = absint( get_post_meta( $step_id, '_wcf_expiry_orders_started', true ) );

		// The admin save path stamps the window; if the toggle was enabled some other way, stamp it now.
		if ( ! $started ) {
			$started = time();
			update_post_meta( $step_id, '_wcf_expiry_orders_started', $started );
		}

		$args['date_created'] = '>' . $started;

		$order_ids = wc_get_orders( $args );

		return is_array( $order_ids ) ? count( $order_ids ) : 0;
	}

	/**
	 * Start or end the order-counting window when the order-limit toggle changes.
	 *
	 * @since 2.3.0
	 * @param int $step_id saved step ID.
	 * @return void
	 */
	public function sync_order_limit_window( $step_id ) {

		$step_id = absint( $step_id );

		if ( 'checkout' !== get_post_meta( $step_id, 'wcf-step-type', true ) ) {
			return;
		}

		$enabled = 'yes' === wcf()->options->get_checkout_meta_value( $step_id, 'wcf-expire-after-orders' );
		$started = absint( get_post_meta( $step_id, '_wcf_expiry_orders_started', true ) );

		if ( $enabled && ! $started ) {
			// Freshly enabled: only orders placed from this moment count toward the limit.
			update_post_meta( $step_id, '_wcf_expiry_orders_started', time() );
		} elseif ( ! $enabled && $started ) {
			// Disabled: end the campaign so re-enabling starts a fresh window.
			delete_post_meta( $step_id, '_wcf_expiry_orders_started' );
		}
	}

	/**
	 * Redirect an expired checkout to its configured URL.
	 *
	 * @since 2.3.0
	 * @param int    $step_id step ID.
	 * @param string $reason expiry reason, 'date' or 'order_limit'.
	 * @return void
	 */
	public function redirect_expired_checkout( $step_id, $reason ) {

		nocache_headers();
		wp_redirect( esc_url_raw( $this->get_expiry_redirect_url( $step_id, $reason ) ) ); //phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- Merchant-configured destination may be external; wp_safe_redirect would rewrite it to admin_url. Same treatment as the free plugin's thank-you page redirect.
		exit;
	}

	/**
	 * Resolve the redirect destination for an expired checkout.
	 *
	 * @since 2.3.0
	 * @param int    $step_id step ID.
	 * @param string $reason expiry reason, 'date' or 'order_limit'.
	 * @return string
	 */
	public function get_expiry_redirect_url( $step_id, $reason ) {

		$meta_key  = 'date' === $reason ? 'wcf-expire-date-redirect-url' : 'wcf-expire-orders-redirect-url';
		$saved_url = wcf()->options->get_checkout_meta_value( $step_id, $meta_key );
		$saved_url = is_string( $saved_url ) ? trim( $saved_url ) : '';

		if ( '' !== $saved_url && 0 === strpos( $saved_url, '/' ) ) {
			// Site-relative path.
			$saved_url = home_url( $saved_url );
		} elseif ( '' !== $saved_url && ! preg_match( '#^https?://#i', $saved_url ) && false === strpos( $saved_url, ':' ) ) {
			// Bare domain without a scheme; other schemes are left to fail validation below.
			$saved_url = 'https://' . $saved_url;
		}

		$url = '' !== $saved_url ? wp_http_validate_url( $saved_url ) : false;

		// An expired checkout must never render — fall back to the homepage.
		if ( ! $url ) {
			$url = home_url( '/' );
		}

		$url = apply_filters( 'cartflows_pro_checkout_expiry_redirect_url', $url, $step_id, $reason );

		// Redirecting to this same step (any scheme or query string) would loop forever.
		if ( $this->is_same_host_and_path( $url, (string) get_permalink( $step_id ) ) ) {
			$url = home_url( '/' );
		}

		return $url;
	}

	/**
	 * Check whether a redirect target points back at the step URL, ignoring scheme and extra query args.
	 *
	 * @since 2.3.0
	 * @param string $target redirect target URL.
	 * @param string $step_url the step's own permalink.
	 * @return bool
	 */
	protected function is_same_host_and_path( $target, $step_url ) {

		$target_parts = wp_parse_url( $target );
		$step_parts   = wp_parse_url( $step_url );

		if ( ! is_array( $target_parts ) || ! is_array( $step_parts ) || ! isset( $target_parts['host'], $step_parts['host'] ) ) {
			return false;
		}

		if ( 0 !== strcasecmp( $target_parts['host'], $step_parts['host'] ) ) {
			return false;
		}

		// Normalize percent-encoding and case so encoded variants of the same path still match.
		$target_path = untrailingslashit( strtolower( rawurldecode( isset( $target_parts['path'] ) ? $target_parts['path'] : '/' ) ) );
		$step_path   = untrailingslashit( strtolower( rawurldecode( isset( $step_parts['path'] ) ? $step_parts['path'] : '/' ) ) );

		if ( $target_path !== $step_path ) {
			return false;
		}

		// Plain permalinks identify the step by query args — the target must carry them all to be a loop.
		if ( isset( $step_parts['query'] ) ) {
			parse_str( $step_parts['query'], $step_args );
			parse_str( isset( $target_parts['query'] ) ? $target_parts['query'] : '', $target_args );

			foreach ( $step_args as $key => $value ) {
				if ( ! isset( $target_args[ $key ] ) || $target_args[ $key ] !== $value ) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Carry checkout attribution onto the child order when an upsell replaces the main order.
	 *
	 * @since 2.3.0
	 * @param WC_Order|mixed $parent_order cancelled parent order.
	 * @param WC_Order|mixed $child_order replacement offer order.
	 * @return void
	 */
	public function attribute_replacement_order( $parent_order, $child_order ) {

		if ( ! $parent_order instanceof WC_Order || ! $child_order instanceof WC_Order ) {
			return;
		}

		// Only replace-main-order offers cancel the parent; the child is then the real sale to count.
		if ( 'cancelled' !== $parent_order->get_meta( '_cartflows_main_order_status' ) ) {
			return;
		}

		// One replacement per parent — later offer children of the same visit must not add extra counts.
		if ( 'yes' === $parent_order->get_meta( '_wcf_expiry_replacement_attributed' ) ) {
			return;
		}

		$checkout_id = absint( $parent_order->get_meta( '_wcf_checkout_id' ) );

		if ( $checkout_id && ! $child_order->get_meta( '_wcf_checkout_id' ) ) {
			$child_order->update_meta_data( '_wcf_checkout_id', (string) $checkout_id );
			$child_order->save();
			$parent_order->update_meta_data( '_wcf_expiry_replacement_attributed', 'yes' );
			$parent_order->save();
		}
	}

	/**
	 * Stop order submission from a checkout that expired after the page was loaded.
	 *
	 * @since 2.3.0
	 * @return void
	 */
	public function block_expired_order_submission() {

		if ( $this->is_submission_expired() ) {
			wc_add_notice( __( 'Sorry, this checkout is no longer accepting orders.', 'cartflows-pro' ), 'error' );
		}
	}

	/**
	 * Block Store API (Checkout Block) submissions for an expired checkout.
	 *
	 * @since 2.3.0
	 * @param WP_Error|mixed $errors cart errors collection.
	 * @return void
	 */
	public function block_expired_store_api_checkout( $errors ) {

		if ( $errors instanceof WP_Error && $this->is_submission_expired() ) {
			$errors->add( 'cartflows_checkout_expired', __( 'Sorry, this checkout is no longer accepting orders.', 'cartflows-pro' ) );
		}
	}

	/**
	 * Check whether the current submission belongs to an expired, enforceable checkout.
	 *
	 * @since 2.3.0
	 * @return bool
	 */
	protected function is_submission_expired() {

		// Cart item meta is server-side state; the client-supplied POST field is only a fallback.
		$checkout_id = $this->get_checkout_id_from_cart();

		if ( ! $checkout_id ) {
			$checkout_id = absint( wcf()->utils->get_checkout_id_from_post_data() );
		}

		if ( ! $checkout_id ) {
			return false;
		}

		$flow_id = absint( get_post_meta( $checkout_id, 'wcf-flow-id', true ) );

		$store_checkout_flow = absint( get_option( '_cartflows_store_checkout' ) );
		if ( $store_checkout_flow && $store_checkout_flow === $flow_id ) {
			return false;
		}

		if ( wcf()->flow->is_flow_testmode( $flow_id ) ) {
			return false;
		}

		// No capability bypass here: a closed checkout takes no orders from anyone outside test mode.
		return false !== $this->get_expiry_reason( $checkout_id );
	}

	/**
	 * Enforce expiry for a checkout embedded on a regular page via the checkout shortcode.
	 *
	 * @since 2.3.0
	 * @return void
	 */
	public function maybe_expire_embedded_checkout() {

		if ( ! is_singular() ) {
			return;
		}

		global $post;

		// Step pages are handled on the cartflows_wp hook.
		if ( ! $post instanceof WP_Post || CARTFLOWS_STEP_POST_TYPE === $post->post_type ) {
			return;
		}

		if ( false === strpos( $post->post_content, '[cartflows_checkout' ) ) {
			return;
		}

		if ( preg_match( '/\[cartflows_checkout[^\]]*\bid=["\']?(\d+)/', $post->post_content, $matches ) ) {
			$this->maybe_expire_checkout( absint( $matches[1] ) );
		}
	}

	/**
	 * Resolve the checkout step ID from CartFlows cart item meta.
	 *
	 * @since 2.3.0
	 * @return int
	 */
	protected function get_checkout_id_from_cart() {

		if ( ! function_exists( 'WC' ) || ! WC()->cart instanceof WC_Cart ) {
			return 0;
		}

		foreach ( WC()->cart->get_cart_contents() as $cart_item ) {
			if ( isset( $cart_item['wcf_product_data']['wcf_checkout_id'] ) ) {
				return absint( $cart_item['wcf_product_data']['wcf_checkout_id'] );
			}
		}

		return 0;
	}

	/**
	 * Get the order statuses that count toward a checkout's order limit.
	 *
	 * @since 2.3.0
	 * @param int $step_id step ID.
	 * @return array<int, string>
	 */
	protected function get_counted_order_statuses( $step_id ) {

		return apply_filters( 'cartflows_pro_checkout_expiry_order_statuses', array( 'processing', 'completed', 'on-hold', 'wcf-main-order' ), $step_id );
	}

	/**
	 * Get all step IDs sharing this step's A/B test group (control, active and archived variations).
	 *
	 * @since 2.3.0
	 * @param int $step_id step ID.
	 * @return array<int, int>
	 */
	protected function get_ab_group_step_ids( $step_id ) {

		$step_id = absint( $step_id );
		$ids     = array( $step_id );

		if ( ! get_post_meta( $step_id, 'wcf-ab-test', true ) ) {
			return $ids;
		}

		$control_id = absint( get_post_meta( $step_id, 'wcf-control-step', true ) );
		$control_id = $control_id ? $control_id : $step_id;
		$ids[]      = $control_id;

		$flow_id    = absint( get_post_meta( $step_id, 'wcf-flow-id', true ) );
		$flow_steps = get_post_meta( $flow_id, 'wcf-steps', true );

		if ( is_array( $flow_steps ) ) {
			foreach ( $flow_steps as $flow_step ) {
				if ( ! is_array( $flow_step ) || ! isset( $flow_step['id'] ) || absint( $flow_step['id'] ) !== $control_id ) {
					continue;
				}

				foreach ( array( 'ab-test-variations', 'ab-test-archived-variations' ) as $list_key ) {
					$variations = isset( $flow_step[ $list_key ] ) ? $flow_step[ $list_key ] : array();

					if ( ! is_array( $variations ) ) {
						continue;
					}

					foreach ( $variations as $variation ) {
						if ( is_array( $variation ) && isset( $variation['id'] ) ) {
							$ids[] = absint( $variation['id'] );
						}
					}
				}
			}
		}

		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * Show flow managers a notice that this checkout is closed for visitors.
	 *
	 * @since 2.3.0
	 * @return void
	 */
	public function render_expiry_preview_notice() {

		echo '<div class="wcf-checkout-expiry-notice" style="margin:0 0 20px;padding:12px 16px;border-left:4px solid #d63638;background:#fcf0f1;color:#1d2327;">';
		echo esc_html__( 'Checkout Expiry: This checkout is currently closed for new orders. You are seeing it because you can manage flows.', 'cartflows-pro' );
		echo '</div>';
	}

	/* End-Pro-Feature */

}

/**
 *  Kicking this off by calling 'get_instance()' method
 */
Cartflows_Pro_Checkout_Markup::get_instance();
