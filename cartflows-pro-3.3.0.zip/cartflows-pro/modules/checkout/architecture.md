---
module: checkout
---

# checkout

## Responsibility

Owns everything CartFlows Pro adds **on top of** the free checkout step: the Pro layouts (two-step, multistep), the "Your Products" product-options selector and its cart AJAX, the pre-checkout offer modal, checkout expiry (date and order-limit), preferred-country reordering, URL add-to-cart and coupon, Pro dynamic CSS, and the post-purchase conditional-redirection rules engine.

Ownership stops at the cart and order themselves — it never creates orders or renders the base checkout form. Order-bump product, rules, meta and CSS were moved out to `modules/order-bump` and are only *consumed* here.

## Why it is this way

The module layers onto a checkout it does not own, so most of its behaviour is expressed as hook surgery at hand-tuned priorities rather than as API calls — removing and re-homing three WooCommerce callbacks for the multistep layout, and winning the fragment filter at `99999`.

Three request-scoped static caches exist to avoid re-reading step configuration on every AJAX refresh. Two of them ignore or discard their cache key, which is safe only under the unwritten assumption of one checkout step per request.
