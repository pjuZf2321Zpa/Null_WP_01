# Module: checkout

Everything Pro adds on top of the free checkout step: Pro layouts, the product-options selector, the pre-checkout offer modal, checkout expiry, URL add-to-cart/coupon, Pro dynamic CSS, and the post-purchase redirection rules engine.

Read `architecture.md` in this folder before changing this module.

## Rules

- The `cartflows_checkout_next_step_id` filter's handler assumes `$order` is a real `WC_Order` — `set_order_data()` dereferences `get_items()` with no guard. `classes/class-cartflows-pro-checkout-rules.php:53,167`
- `wcf-checkout-rules` meta must be an array of groups each with `rules` and `step_id`; it is `foreach`-ed with no `is_array()` check. `classes/class-cartflows-pro-checkout-rules.php:85-87`
- `get_group_rules_result()` reads condition data **only** from the static `self::$order_data`, so callers must call `set_order_data()` first. `classes/class-cartflows-pro-checkout-rules.php:94,225`
- **Every product-options AJAX action rejects by `return`ing with no body at all** (admin-ajax then emits `0`), not a JSON error — `option[unique_id]` must match a configured row and the product/variation pair must be the configured product or its direct parent/child. `classes/class-cartflows-pro-product-options.php:365-410`
- `wcf_add_cart_single_product` takes `product_id`/`variation_id` from **top-level** `$_POST`, not from `option[]` — sending only `option[product_id]` fails validation. `classes/class-cartflows-pro-product-options.php:1519-1521`
- **`wcf_woo_quick_view` has no nonce and no capability check.** `classes/class-cartflows-pro-product-options.php:1206-1212`
- `wcf-expire-date` must match `Y-m-d[ H:i[:s]]` — any other string silently keeps the checkout open. `classes/class-cartflows-pro-checkout-markup.php:1343-1358`
- A checkout in the Store Checkout flow, or in a flow in test mode, is never expired and never blocked at submit. `classes/class-cartflows-pro-checkout-markup.php:1275-1285`

## Gotchas

- **Request-lifetime static cache of the redirect decision** — a second invocation of the filter in the same request returns the first order's step regardless of the new order. `self::$order_data = null` wipes the order cache but *not* the step cache. `classes/class-cartflows-pro-checkout-rules.php:36,70,125,131`
- **Static product-config cache ignores its own argument** — `get_all_main_products( $post_id )` populates once per request and returns it for every subsequent id. Since that array is what validation runs against, a second checkout id in the same request is validated against the first checkout's products. `classes/class-cartflows-pro-product-options.php:283-285`
- **Quick-view AJAX re-runs the main WP query** (`wp( 'p=…' )` inside admin-ajax), mutating global `$wp_query`/`$post` for everything after it, then echoes unescaped output. Combined with the missing nonce above, any product's markup is retrievable and global query state is clobbered. `classes/class-cartflows-pro-product-options.php:1226,1233`
- **A filter with a destructive side effect** — `skip_cart_configuration()` is hooked to `cartflows_skip_configure_cart` and calls `empty_cart()`. Anything that merely *evaluates* that filter while `wcf-add-to-cart` is in the URL empties the cart. `classes/class-cartflows-pro-checkout-markup.php:102,111-115`
- **Documented ordering requirement**: `apply_url_coupon` sits at priority 30 with the comment "Execute this action after the above action to avoid applying the coupon early", where `add_products_using_url` is at 10. Re-prioritising either breaks URL coupons. `classes/class-cartflows-pro-checkout-markup.php:96-98`
- Frontend GETs perform post-meta writes — dynamic CSS on cache miss, and the order-limit counter stamps a start marker during a read-path expiry check. Concurrent first hits race on the stamp. `classes/class-cartflows-pro-checkout-markup.php:414-421,1409-1414`
- **A global WooCommerce option is rewritten for the rest of the request** — `woocommerce_ship_to_countries` returns `''` when it was `'all'`, purely so the reorder filter takes effect. `classes/class-cartflows-pro-checkout-markup.php:1240-1257`
- Order-bump order meta is written from **unverified POST** with the nonce check explicitly suppressed, and that same meta is what the rules engine's `order_bump` condition trusts. `classes/class-cartflows-pro-checkout-markup.php:814-855`
- Pre-checkout custom price only re-applies during AJAX, so a non-AJAX totals recalculation loses the discounted offer price. `classes/class-cartflows-pre-checkout-offer-product.php:480-482`
- A by-reference validator clobbers the caller's posted data on nonce failure — it assigns `$data = array( 'error' => … )` before responding. `classes/class-cartflows-pre-checkout-offer-product.php:143-163`
- Multistep layout removes `woocommerce_checkout_payment`, `woocommerce_order_review` and `woocommerce_checkout_login_form` and re-adds them on CartFlows-owned hooks, with the fragment filter at priority `99999` to guarantee it wins. `classes/layout/class-cartflows-pro-multistep-checkout.php:136-156,48`
- A cross-module include is called a "defensive no-op safety net" in one place while the CSS path includes from `CARTFLOWS_PRO_ORDER_BUMP_DIR` unconditionally — checkout CSS generation fatals if the order-bump module is absent. `classes/class-cartflows-pro-checkout-markup.php:363-368,798-799`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
