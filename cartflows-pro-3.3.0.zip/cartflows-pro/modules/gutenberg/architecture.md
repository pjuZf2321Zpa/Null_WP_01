---
module: gutenberg
---

# gutenberg

## Responsibility

Owns CartFlows Pro's Gutenberg surface: it registers the eight `wcfpb/*` offer blocks (yes/no link and button, product title/description/price/quantity/variation/image), generates and prints their frontend CSS and Google-font tags, and injects Pro-only panels and attributes into the free plugin's `wcfb/checkout-form` block.

Ownership stops at rendering — every block's markup comes from `[cartflows_offer_product_*]` shortcodes owned elsewhere, and all checkout-form behaviour is delegated back to free CartFlows through `cartflows_checkout_meta_*` filters. It does not own the free plugin's block, its JS globals, or the vendored Spectra components it copies in.

## Why it is this way

This module is a **vendored Spectra fork**. `src/components` and `src/controls` are copied from Ultimate Addons for Gutenberg, and correct maintenance depends on a manual patch procedure recorded in `readme.txt` — which has already silently failed in the shipped bundle, leaving a module-level reference to a Spectra global.

The frontend pipeline has a strict `wp` → `wp_head:80` → `wp_head:120` → `wp_footer:1000` ordering over accumulated static state, and the "deprecated" CSS copy step in the build is still required by the editor registration.
