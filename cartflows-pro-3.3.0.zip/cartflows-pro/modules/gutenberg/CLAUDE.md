# Module: gutenberg

Pro's Gutenberg surface: eight `wcfpb/*` offer blocks, their frontend CSS and font tags, and the Pro panels injected into the free plugin's `wcfb/checkout-form` block.

Read `architecture.md` in this folder before changing this module.

## Rules

- **Block JS registration is gated on step type; PHP registration is not.** Moving saved block content to a step of a different type yields "block not supported" in the editor while still rendering on the frontend. `src/blocks/offer-yes-no-button/block.js:18-22` vs `dist/blocks/offer-product-title/class-cartflows-pro-gb-block-product-title.php:43`
- `add_pro_checkout_form_attributes()` assumes the free plugin's array shape with no `isset` guard — a payload missing that key is a fatal. `classes/class-cartflows-pro-init-blocks.php:80`
- **Every offer block must carry `block_id`** — the render callback interpolates it into the CSS class unguarded, matched against CSS keyed on the same value. `dist/blocks/offer-product-title/class-cartflows-pro-gb-block-product-title.php:274`
- **CSS generation must complete before `wp_head`** — `generate_assets()` runs on `wp` and only then hooks the printers at `wp_head:80`, `wp_head:120` and `wp_footer:1000`. Anything changing block content after `wp` gets no CSS. `classes/class-cartflows-pro-gb-helper.php:121-130`
- The build must be run **from the module directory** — every path resolves from `process.cwd()`. `scripts/paths.js:9`
- **Vendored Spectra sync has a mandatory manual patch step**: after re-copying `src/components` and `src/controls`, un-lazy the component CSS and rewrite `renderIcon.js` to use `cf_blocks_info.wcf_svg_icons`. `readme.txt:19-20`
- Webpack aliases (`@Controls`, `@Components`, `@CFProBlocks`, `@Attributes`) are the only supported import paths, and the lazy-CSS rule keys on the literal style tag id `uagb-editor-styles`. `gutenberg-webpack-config.js:25-28,42`

## Gotchas

- **The readme's required patch is not applied — the shipped bundle reads an undefined Spectra global.** Four files still reference `uagb_blocks_info`, and one of them destructures it at *module level*, which survives into `build/blocks.js`. Unless something else defines that global, evaluating the bundle throws a ReferenceError and takes out the whole Pro block editor script. `src/components/typography/font-typography.js:10`, `src/controls/renderIcon.js:13-16`
- **`migrateBorderAttributes` is called with the wrong arity, so it erases legacy borders instead of migrating them.** With `attributes` defaulting to `{}` every check is false and `setAttributes` is `undefined`, but the reset lines still run — so the user's legacy border settings are wiped on first editor open. `src/controls/generateAttributes.js:162,166,179`, `src/blocks/offer-yes-no-button/edit.js:43-66`
- **Fetched HTML is persisted into post content and never refreshed.** `jQuery.ajax` fires from inside the `withSelect` mapper — a function the data layer re-runs on every store change — guarded only by an attribute set *after* the response lands. Once saved, the editor preview is frozen forever and changing the offer product never updates it. `src/blocks/offer-product-title/edit.js:67-93`
- `setAttributes` is called **during render**, not in an effect, alongside direct `element.innerHTML =` writes — React "cannot update while rendering" warnings and DOM churn on every sidebar keystroke. `src/blocks/pro-checkout-form/block.js:86,82-84`
- **Static filter closures read shared mutable state at run time and are never removed** — with two checkout-form blocks on a page, all filters registered by the first resolve against the second's settings, and each pass stacks another duplicate closure. `dist/blocks/cartflows-pro-gb-checkout-form-extend/class-cartflows-pro-checkout-form.php:69,118`
- **Two filters differ only by a transposed prefix** — `cfp_post_for_stylesheet` vs `cpf_post_for_stylesheet`. A caller hooking the documented-looking name silently affects only one of the two paths. `classes/class-cartflows-pro-init-blocks.php:229`, `classes/class-cartflows-pro-gb-helper.php:225`
- **Both asset-enqueue loops are dead** — `get_block_assets()` returns an unconditionally empty array, and CSS handles are never registered anyway, so adding a `css_assets` entry would silently no-op. `classes/class-cartflows-pro-block-config.php:544-549`
- A **hardcoded path into WooCommerce's plugin folder** for flexslider — a 404 if WooCommerce lives in a non-default directory. `classes/class-cartflows-pro-init-blocks.php:296`
- **A "deprecated, delete this" build step is still load-bearing** — it copies `style-blocks.css` to `blocks.style.css`, which the editor still registers. Removing it strips all editor block styling. `scripts/generate-assets-files.js:44-49`
- Four vendored Spectra control files are dead **and** would not work if re-enabled — their logic matches `uagb/` block names while these blocks are `wcfpb/`. `src/controls/autoBlockRecovery.js:12`, `src/controls/isInvalid.js:8`
- `addBlockEditorDynamicStyles` wraps its body in a `setTimeout` with **no delay argument** and clones Spectra-named style tags into the preview iframe — styling depends on a zero-delay macrotask winning a race against the iframe mount. `src/controls/addBlockEditorDynamicStyles.js:4,110-149`
- `getPreviewType` calls an `__experimental` method behind an optional chain that guards the *store* being absent but not the *method* — a WP version with one and not the other throws inside a hook every block imports. `src/controls/getPreviewType.js:9`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `npm run lint-js && composer lint && composer phpstan`
