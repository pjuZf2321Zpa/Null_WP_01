# Module: tracking

Funnel analytics: recording visits/conversions into two custom tables from a public REST endpoint, and reading them back — joined against WooCommerce orders — into the dashboard payloads.

Read `architecture.md` in this folder before changing this module.

## Rules

- **The registry must be included after all six helper classes** — its constructor calls `get_instance()` on each, and the file self-instantiates at include time. Including it earlier is a fatal. `class-cartflows-pro-analytics-helper-registry.php:90-95,415`
- **Everything downstream must go through `wcf_pro_analytics()`**, not `new`/`get_instance()` on the helpers — two of them have no bottom-of-file instantiation and exist only because the registry created them. `class-cartflows-pro-analytics-helper-registry.php:440-442`
- **`fetch_visits()` returns two incompatible groupings depending on an optional `$screen_type`.** `get_products_analytics()` needs step_id-grouped rows (call it with **no** `$screen_type`); `process_visits()` needs date-grouped rows (call it with `'funnels'`/`'conversions'`). Passing the wrong one silently produces meaningless data. `class-cartflows-pro-analytics-db.php:403-405`, `analytics-helper/class-cartflows-pro-analytics-products.php:50-51`
- **Zero-state builders must mirror the populated builder's output shape exactly** — parent `revenue` is `wc_price()` HTML while per-variation `revenue` is the raw string `'0.00'`. Change one side and the dashboard renders currency HTML in one branch and bare numbers in the other. `class-cartflows-pro-analytics-conversions.php:329-333`
- **Changing the table schema requires deleting the `cartflows_database_tables_created` option** — `create_db_tables()` returns early when it is `'yes'`, so `dbDelta` never re-runs on upgrade. `class-cartflows-pro-analytics-db.php:51-53`
- `calculate_comparison_dates()` **throws** on unparseable or inverted ranges, and none of its three callers catch it. `class-cartflows-pro-analytics-helper-registry.php:388-390`
- **`remove_zero_values()` drops zero days entirely**, so every `*_by_date` payload is sparse — consumers cannot assume one entry per day in range. `class-cartflows-pro-analytics-helper-registry.php:311-322`

## Gotchas

- **The REST write endpoint is unauthenticated and lets a caller mark any visit converted.** `permission_callback => '__return_true'`; a nonce is minted and localized but never verified, and the decoded `visit_id` is used as both the SET value and the WHERE key of a raw `$wpdb->update`. Any client can forge visits and flip arbitrary `conversion` rows to `yes`. `class-cartflows-pro-analytics-tracking.php:76,101,241-252`
- **Ordering requirement, uncommented**: `save_conversion_data()` must run before `save_visit()` — the conversion is attributed to the *previous* step from the cookie, so reversing the calls changes which cookie generation is read. `class-cartflows-pro-analytics-tracking.php:144-145`
- `add_localize_vars()` dereferences `$post` with no guard and is registered for **all** non-admin requests — a fatal on any front-end request where `$post` is null. `class-cartflows-pro-analytics-tracking.php:346-347,56-58`
- **`get_earnings()['checkout_sale']` reports only the last order processed** — `$checkout_total` is *assigned*, not accumulated, inside the order loop, yet returned as a flow-level total. `class-cartflows-pro-analytics-db.php:501,595`
- **The two `get_gross_sale_by_flows()` branches sum different columns** — `wc_order_stats.total_sales` under HPOS vs `postmeta._order_total` on legacy. Same API, different revenue definition (net-of-refunds vs gross), plus a 60-second cache that makes the discrepancy sticky. `class-cartflows-pro-analytics-reports.php:219,252,279`
- Inconsistent HPOS guarding — the DB class wraps the call in `class_exists()`, the reports class does not, so the latter is fatal if WooCommerce is deactivated while that path runs. `class-cartflows-pro-analytics-db.php:93` vs `class-cartflows-pro-analytics-reports.php:217`
- **Nested `$wpdb->prepare()`** — the flow filter is prepared into a fragment and the whole string prepared again, so any `%` surviving the inner substitution is reinterpreted by the outer call. `analytics-helper/class-cartflows-pro-analytics-calculations.php:887,895`
- Three defensive blocks exist purely to absorb callers who got the grouping contract wrong, and each says so: a step-less flow returns `array()` because a flat assoc array "confuses the foreach loops"; non-object rows are skipped to protect "against legacy callers that returned scalar empty-state shapes". `class-cartflows-pro-analytics-db.php:394-401`, `analytics-helper/class-cartflows-pro-analytics-calculations.php:1171-1182`
- `'previous-year'` comparison **ignores the selected range** (always `-1 year → today`) while `'previous-period'` is range-relative, so comparison KPIs are not apples-to-apples between the two modes. `class-cartflows-pro-analytics-helper-registry.php:376-382`
- Optin payload key names don't match their contents — `submissions_by_date` is built from conversions, and one populated array is never returned. `analytics-helper/class-cartflows-pro-analytics-optin.php:195,224-227`
- The `wc-wcf-main-order` status list is hardcoded in **five** places with no filter and no shared constant. `class-cartflows-pro-analytics-db.php:209,284`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
