---
module: tracking
---

# tracking

## Responsibility

Owns CartFlows Pro's funnel analytics: recording visits and conversions into two custom tables (`{prefix}cartflows_visits`, `{prefix}cartflows_visits_meta`) from a public REST endpoint, and reading them back — joined against WooCommerce orders — into the shaped payloads the analytics dashboard screens consume.

Ownership stops at the table boundary and the `cartflows_home_page_analytics` filter: it does not own flow/step definitions, order data, the admin UI, or the JS that calls the endpoint.

## Why it is this way

The read path is split across six helper classes behind one registry accessor, which is why the include order is load-bearing and why `wcf_pro_analytics()` is the only supported entry point.

The sharpest edge is `fetch_visits()`: an optional `$screen_type` argument switches the SQL `GROUP BY` between step-grouped and date-grouped rows, and two different consumers each require one of those shapes. Nothing in the signature says so, and three separate defensive blocks downstream exist purely to absorb callers who got it wrong.
