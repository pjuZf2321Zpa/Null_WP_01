---
module: beaver-builder
---

# beaver-builder

## Responsibility

Owns the Beaver Builder integration surface for CartFlows Pro: eight offer-page BB modules (yes/no button and link, product title/description/price/image/quantity/variation), plus Pro-only option sections (Two Step, Product Options) injected into the free plugin's `cartflows-bb-checkout-form` module.

Ownership stops at markup wrappers and generated CSS — all actual offer content is delegated to `[cartflows_offer_*]` shortcodes owned elsewhere, and all checkout behaviour is delegated back to `cartflows_checkout_meta_*` filters owned by the free plugin.

## Why it is this way

Behaviour here is dominated by **invisible preconditions** rather than by the code: a Plus/Pro gate, a `cartflows_step`-only frontend gate, a settings-page-only admin gate, an upsell/downsell enabled flag, a priority-1010 ordering requirement, a request-lifetime static step-type cache, and a hook whose only caller lives in a different plugin.

Settings reach the checkout through anonymous filter closures that cannot be removed and are never scoped to the render, which is why they leak to every later reader in the request.
