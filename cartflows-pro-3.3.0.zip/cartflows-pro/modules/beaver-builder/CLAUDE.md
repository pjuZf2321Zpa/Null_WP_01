# Module: beaver-builder

Pro's Beaver Builder surface: eight offer-page BB modules, plus Pro-only option sections injected into the free plugin's checkout-form module.

Read `architecture.md` in this folder before changing this module.

## Rules

- Pro BB modules register **only** when the plugin is Plus/Pro; the extend files load regardless. `class-cartflows-pro-bb-modules-loader.php:41-46`
- Frontend registration requires a `cartflows_step` post in `global $post` **and** `FLBuilder` loaded; admin registration happens only on `?page=fl-builder-settings`. A module missing from that screen is this gate, not a bug. `class-cartflows-pro-bb-modules-loader.php:87-101,113`
- Adding a module requires the slug in `get_module_list()` **and** a directory + file named exactly `<slug>/<slug>.php` — the loader `include_once`s that path blindly, so a mismatch is a fatal, not a skip. `class-cartflows-pro-bb-modules-loader.php:63-77,124-133`
- `Cartflows_Pro_BB_Helper` must exist before any module class is constructed, and it is loaded only inside `modules_extend_files()` under a `class_exists( 'FLBuilder' )` guard. `class-cartflows-pro-bb-modules-loader.php:142-147`
- **The checkout extension must run after the free plugin registers its form** — it hooks `fl_builder_register_settings_form` at priority **1010** and acts only on the free module's id. `cartflows-pro-bb-checkout-form-extend/cartflows-pro-bb-checkout-form-extend.php:32,202`
- The Pro option filters only apply if the free plugin fires `cartflows_bb_checkout_options_filters` with a settings object — **no caller in Pro fires it**. `cartflows-pro-bb-checkout-form-extend/cartflows-pro-bb-checkout-form-extend.php:31,44`
- Offer modules are enabled only when WooCommerce is active and the step is `upsell`/`downsell` (or the BB settings page). `cartflows-pro-bb-offer-product-image/cartflows-pro-bb-offer-product-image.php:28`

## Gotchas

- **Undefined variables produce an empty offer link** — the accept/reject links are assigned only inside the upsell/downsell branch then read unconditionally, and the module is deliberately enabled when step type is empty, so the path is reachable: PHP 8 warning plus `href=""`. `cartflows-pro-bb-offer-action-button/cartflows-pro-bb-offer-action-button.php:113-124`
- **Request-lifetime static cache that cannot be flushed** — `$step_type` is populated once from `get_the_id()` and never reset, so whatever post is current at the *first* module construction decides `enabled` for every module. An empty first read silently disables all eight. `classes/class-cartflows-pro-bb-helper.php:34-41`
- **Anonymous closures permanently override checkout meta** — they cannot be `remove_filter`'d, they stack on repeated invocation, and they override those metas for *all* later readers in the request, not just the BB render. `cartflows-pro-bb-checkout-form-extend/cartflows-pro-bb-checkout-form-extend.php:89-99`
- `get_the_ID()` is called inside a filter callback, ignoring the node/settings passed in — correctness depends on global post context at hook time. `cartflows-pro-bb-checkout-form-extend/cartflows-pro-bb-checkout-form-extend.php:46`
- **Unguarded `$post->ID` in CSS generation**, running under `fl_builder_render_css` — BB regenerates cached CSS in contexts where `$post` may be null, and there is no null check anywhere in the file. `includes/frontend-css.php:10,22-25`
- **The settings object is mutated in place during CSS render** — colours are overwritten with converted values and `style` is rewritten to `'gradient'`, so anything reading those properties later in the request sees transformed values. `cartflows-pro-bb-offer-action-button/includes/frontend.css.php:13-16,33-35`
- A **dead, divergent duplicate** of the settings JS is referenced nowhere and contains an HTML comment inside JS that would be a syntax error if it ever executed. Editing it changes nothing. `cartflows-pro-bb-checkout-form-extend/js/settings-js.php:20`
- `bb_checkout_form_js()` returns `$js` unmodified yet is registered on `fl_builder_render_js`. `cartflows-pro-bb-checkout-form-extend/cartflows-pro-bb-checkout-form-extend.php:671-674`
- `CartFlows_Pro_BB_Optin_Form_Extend::init()` has an **empty body** but is required and instantiated — the optin BB form has no Pro extension despite the file existing. `cartflows-pro-bb-optin-form-extend/cartflows-pro-bb-optin-form-extend.php:28-29`
- Two `setTimeout( ..., 20 )` calls re-trigger resize and gallery zoom after a variation image swap — slow image decode outside that window leaves flexslider mis-sized. `cartflows-pro-bb-offer-product-image/js/frontend.js:135-140`
- **Module JS ignores its own node scope** — handlers select document-wide despite `this.nodeClass`, so two instances on one page double-bind and each drives the other's gallery. `cartflows-pro-bb-offer-product-image/js/frontend.js:38,52`
- `cartflows_bb_parse_color_to_hex` handles only `rgba(...)`; a plain `rgb(...)` falls through and is returned as `rgb(0,0,0)`, then fed to a brightness adjuster — producing broken gradient CSS. `classes/class-cartflows-pro-bb-helper.php:140-150`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan`
