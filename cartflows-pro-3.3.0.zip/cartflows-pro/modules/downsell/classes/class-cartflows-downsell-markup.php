<?php
/**
 * Downsell markup
 *
 * @package cartflows
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Checkout Markup
 *
 * @since 1.0.0
 */
class Cartflows_Downsell_Markup extends Cartflows_Pro_Base_Offer_Markup {


	/**
	 * Member Variable
	 *
	 * @var object instance
	 */
	private static $instance;

	/**
	 *  Initiator
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 *  Constructor
	 */
	public function __construct() {

		add_action( 'wp_ajax_wcf_downsell_accepted', array( $this, 'process_downsell_accepted' ) );
		add_action( 'wp_ajax_nopriv_wcf_downsell_accepted', array( $this, 'process_downsell_accepted' ) );

		add_action( 'wp_ajax_wcf_downsell_rejected', array( $this, 'process_downsell_rejected' ) );
		add_action( 'wp_ajax_nopriv_wcf_downsell_rejected', array( $this, 'process_downsell_rejected' ) );

	}

	/**
	 * Process down sell acceptance.
	 */
	public function process_downsell_accepted() {

		$nonce = isset( $_POST['_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'wcf_downsell_accepted' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'cartflows-pro' ) ) );
		}

		$offer_action = isset( $_POST['offer_action'] ) ? sanitize_text_field( wp_unslash( $_POST['offer_action'] ) ) : '';
		$step_id      = isset( $_POST['step_id'] ) ? intval( $_POST['step_id'] ) : 0;
		$product_id   = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
		$order_id     = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
		$order_key    = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';

		// Validate order ownership — order_key must match the actual order.
		$order = wc_get_order( $order_id );
		if ( ! ( $order instanceof \WC_Order ) || $order->get_order_key() !== $order_key ) {
			wp_send_json(
				array(
					'status'   => 'failed',
					'redirect' => '#',
					'message'  => __( 'Invalid order.', 'cartflows-pro' ),
				)
			);
		}

		// Validate session for non-admin users.
		if ( $step_id ) {
			$flow_id = wcf()->utils->get_flow_id_from_step_id( $step_id );
			$session = wcf_pro()->session;
			if ( $flow_id && null !== $session && ! $session->has_valid_session( $flow_id ) ) {
				wp_send_json(
					array(
						'status'   => 'failed',
						'redirect' => '#',
						'message'  => __( 'Session expired.', 'cartflows-pro' ),
					)
				);
			}
		}

		$variation_id = '';
		$input_qty    = '';

		if ( isset( $_POST['variation_id'] ) ) {
			$variation_id = intval( $_POST['variation_id'] );
		}

		if ( isset( $_POST['input_qty'] ) && ! empty( $_POST['input_qty'] ) ) {
			$input_qty = intval( $_POST['input_qty'] );
		}

		/*
		 * Bundle offers: resolve the offer product from the step's own meta rather than the
		 * posted product_id, so the configuration is read for the product that will actually
		 * be charged and added to the order. A posted variation_id belongs to a bundled child,
		 * not to the offer product itself.
		 */
		$bundle_product = class_exists( 'Cartflows_Pro_Woo_Product_Bundles' )
			? Cartflows_Pro_Woo_Product_Bundles::get_step_offer_product( $step_id )
			: false;

		$is_bundle_offer = $bundle_product && Cartflows_Pro_Woo_Product_Bundles::is_bundle_product( $bundle_product );

		if ( $is_bundle_offer ) {
			$variation_id = '';
		}

		// Extract bundle configuration from POST data (delegated to the central compatibility class).
		$bundle_configuration = $is_bundle_offer
			? Cartflows_Pro_Woo_Product_Bundles::get_posted_bundle_configuration( $bundle_product )
			: array();

		$result = array(
			'status'   => 'failed',
			'redirect' => '#',
			'message'  => __( 'Order does not exist', 'cartflows-pro' ),
		);

		if ( $order_id && $product_id ) {

			$result = array(
				'status'   => 'failed',
				'redirect' => '#',
				'message'  => __( 'Downsell Payment Failed', 'cartflows-pro' ),
			);

			$order = wc_get_order( $order_id );

			$extra_data = array(
				'order_id'             => $order_id,
				'product_id'           => $product_id,
				'variation_id'         => $variation_id,
				'input_qty'            => $input_qty,
				'order_key'            => $order_key,
				'template_type'        => 'downsell',
				'action'               => 'wcf_downsell_accepted',
				'bundle_configuration' => $bundle_configuration,
			);

			$result = $this->offer_accepted( $step_id, $extra_data, $result );

			// Track first downsell accepted event.
			if ( isset( $result['status'] ) && 'failed' !== $result['status'] ) {
				Cartflows_Helper::set_analytics_flag( 'first_downsell_accepted' );
			}
		}

		// send json.
		wp_send_json( $result );
	}

	/**
	 * Process down sell rejected.
	 */
	public function process_downsell_rejected() {

		$nonce = isset( $_POST['_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'wcf_downsell_rejected' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'cartflows-pro' ) ) );
		}

		$step_id   = isset( $_POST['step_id'] ) ? intval( $_POST['step_id'] ) : 0;
		$order_id  = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
		$order_key = isset( $_POST['order_key'] ) ? sanitize_text_field( wp_unslash( $_POST['order_key'] ) ) : '';

		// Validate session for non-admin users.
		if ( $step_id ) {
			$flow_id = wcf()->utils->get_flow_id_from_step_id( $step_id );
			$session = wcf_pro()->session;
			if ( $flow_id && null !== $session && ! $session->has_valid_session( $flow_id ) ) {
				wp_send_json(
					array(
						'status'   => 'failed',
						'redirect' => '#',
						'message'  => __( 'Session expired.', 'cartflows-pro' ),
					)
				);
			}
		}

		$result = array(
			'status'   => 'failed',
			'redirect' => '#',
			'message'  => __( 'Current Step Not Found', 'cartflows-pro' ),
		);

		if ( $step_id ) {

			$result = array(
				'status'   => 'failed',
				'redirect' => '#',
				'message'  => __( 'Order does not exist', 'cartflows-pro' ),
			);

			if ( $order_id ) {

				$extra_data = array(
					'action'        => 'offer_rejected',
					'order_id'      => $order_id,
					'order_key'     => $order_key,
					'template_type' => 'downsell',
				);

				$result = $this->offer_rejected( $step_id, $extra_data, $result );
			}
		}

		// send json.
		wp_send_json( $result );
	}
}

/**
 *  Kicking this off by calling 'get_instance()' method
 */
Cartflows_Downsell_Markup::get_instance();
