---
module: elementor
---

# elementor

## Responsibility

Owns the Elementor integration for CartFlows **Pro**: registering the eight offer-page widgets (upsell/downsell) and injecting Pro-only control sections (two-step checkout, product options) into the **free** plugin's `checkout-form` widget.

Ownership stops at markup and control definitions — all actual offer rendering is delegated to `[cartflows_offer_*]` shortcodes defined outside this module, and the `cartflows-widgets` Elementor category, the `checkout-form` widget itself, and the hook that drives the Pro filters all live in the free CartFlows plugin.

## Why it is this way

The module's hardest constraints are invisible at the call site: a three-way slug ↔ filename ↔ class-name convention enforced only by a runtime fatal, and an exact dependency on control-section IDs owned by a *different plugin*.

Settings reach the shortcodes through static state read lazily by filter closures, which is what makes two checkout-form widgets on one page cross-contaminate. PHPCS exclusion means no tooling backstops any of it.
