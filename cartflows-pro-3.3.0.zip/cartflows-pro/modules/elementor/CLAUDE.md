# Module: elementor

Pro's Elementor integration: the eight offer widgets (upsell/downsell) and the Pro-only control sections injected into the free plugin's `checkout-form` widget.

Read `architecture.md` in this folder before changing this module.

## Rules

- **A widget slug must satisfy three separate conventions at once** or registration fatals: file at `widgets/class-cartflows-pro-el-{slug}.php`, class `Cartflows_Pro_` + `ucwords` of the slug with `-`→`_`, and a `public static is_enable( $step_type )` called unguarded. `class-cartflows-pro-el-widgets-loader.php:119,182-186`
- **`get_name()` is independent of the list slug** — `offer-action-button` maps to a class named for that slug but `get_name()` returns `offer-yes-no-button`. Renaming the list entry to match would break the class lookup. `class-cartflows-pro-el-offer-action-button.php:56`
- Every widget must return `array( 'cartflows-widgets' )` from `get_categories()` — a category registered by the **free** plugin, not here. `class-cartflows-pro-el-offer-action-button.php:100`
- Widgets only register on `cartflows_step` posts, and all eight offer widgets additionally require an `upsell`/`downsell` step **and** active WooCommerce. `class-cartflows-pro-el-widgets-loader.php:161-169`
- **Pro control-section callbacks are bound to exact free-plugin section IDs** (`…/section_general_fields/after_section_end` and `…/section_payment_style_fields/after_section_end`). Renaming a control section in the free plugin silently drops all Pro checkout controls. `class-cartflows-pro-el-checkout-form-extend.php:72-80`
- `dynamic_filters()` reads `self::$settings[ $setting_name ]` with no `isset()`, so removing a control from the free checkout widget produces notices rather than a graceful skip. `class-cartflows-pro-el-checkout-form-extend.php:730,747-751`
- The Elementor ≥ 3.5.0 branch is duplicated — hook name (`register` vs `widgets_registered`) and method name (`register` vs `register_widget_type`) must stay in sync. `class-cartflows-pro-el-widgets-loader.php:42,178`

## Gotchas

- **Static-state last-write-wins across widget instances** — every registered closure reads `self::$settings` at filter-execution time, so with two checkout-form widgets on one page both sets of filters resolve against whichever ran last. The first widget's settings are silently discarded. `class-cartflows-pro-el-checkout-form-extend.php:672,736`
- **The licence gate applies to widgets but not to control injection** — `widget_extend_files()` is called outside the Plus/Pro block, so Two Step and Product Options controls appear in the editor on **every** licence tier. `class-cartflows-pro-el-widgets-loader.php:39-50`
- **`content_template()` bakes server-rendered shortcode output into the Backbone editor template** — the shortcode is evaluated once when the editor loads, so the live preview shows frozen HTML from the editor request context, not the offer product. `class-cartflows-pro-el-offer-product-image.php:299`
- **Undefined variable when step type drifts** — the accept/reject links are defined only inside an upsell/downsell branch but used unconditionally on the next line, so rendering on any other step type emits a warning and an empty `href`. `class-cartflows-pro-el-offer-action-button.php:598-602`
- `wp_enqueue_style`/`wp_enqueue_script` are called **from inside the widget-registration hook**, not an enqueue hook, so frontend CSS and flexslider load only as a side effect of registration. `class-cartflows-pro-el-widgets-loader.php:127,137-144`
- `wp_enqueue_script( 'flexslider' )` uses a handle this module never registers, relying on WooCommerce having done so — with no `wp_script_is` check. `class-cartflows-pro-el-widgets-loader.php:144`
- `global $post` is dereferenced without a guard in a **public** method; the `isset()` check lives only in the caller. `class-cartflows-pro-el-widgets-loader.php:131-133,161`
- Editor controls are gated on saved post meta read at **registration** time, so toggling Product Options in CartFlows settings does not update the Elementor panel until a full editor reload. `class-cartflows-pro-el-checkout-form-extend.php:303,419`
- A dead file is kept in the require list — `CartFlows_Pro_Optin_Form_Extend` has an empty constructor and registers no hooks, and its class name uses a different capitalisation from every sibling. `class-cartflows-pro-el-optin-form-extend.php:24-60`
- **The entire module is excluded from PHPCS**, so none of the above is caught by lint. `phpcs.xml.dist:33`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer phpstan` (PHPCS excludes this module)
