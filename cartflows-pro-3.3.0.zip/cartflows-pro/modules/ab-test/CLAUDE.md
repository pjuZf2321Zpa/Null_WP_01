# Module: ab-test

The full split-test lifecycle: admin mutations of `wcf-steps` and the per-step A/B meta, plus front-end variation assignment (cookie stickiness, weighted pick, redirect or in-place swap).

Read `architecture.md` in this folder before changing this module.

## Rules

- **Never call `run_ab_test()` / `choose_display_variation()` without checking `is_ab_test_enable()` first** — the constructor only populates `$all_variations` when the meta is truthy, and the chooser then `foreach`es it unguarded. `classes/class-cartflows-pro-ab-test-factory.php:97-111,343`
- **Step IDs inside `wcf-steps` must be stored as integers.** The factory matches with strict `===` against an int-cast id; a string ID means the test silently never runs. The codebase is not self-consistent here — several handlers compare without casting. `classes/class-cartflows-pro-ab-test-factory.php:102,218`
- **The control step must not carry `wcf-control-step` meta** — the factory treats empty as "I am the control", and both promotion paths explicitly delete it. A control with that meta set redirects to itself. `classes/class-cartflows-pro-ab-test-meta.php:156,544`
- A new AJAX action must register its nonce in the correct list: pre-existing actions derive it as the `wcf_`-prefixed name with underscores→dashes, while three migrated actions use a literal `cartflows_` prefix. The wrong list yields a silent "Security check failed." `classes/class-cartflows-pro-ab-test-meta.php:86-101`
- Every AJAX entry point requires `cartflows_manage_flows_steps` **plus** a nonce, in that order. `classes/class-cartflows-pro-ab-test-meta.php:234-240`
- **Traffic weights must sum to 100** — the chooser walks a cumulative window against `wp_rand( 0, 100 )` and falls through to the control, so an under-100 sum silently over-serves the control. `classes/class-cartflows-pro-ab-test-factory.php:340-355`

## Gotchas

- **Global mutation of WordPress query state**: `$GLOBALS['posts'][0]`, `$wp_the_query->post`, `$post` and `$wcf_step` are all overwritten. The comment states the `wcf_step` swap exists so views and conversions track against the variation — so anything that cached `$GLOBALS['wcf_step']` before `cartflows_wp` records against the wrong one. This is a hard ordering requirement. `classes/class-cartflows-pro-ab-test-factory.php:370-383`
- **Two mutually exclusive delivery modes with different control flow** — with content override on, execution continues in-process; otherwise `wp_safe_redirect()` + `die()`. Every hook after `cartflows_wp` runs in one mode and never in the other, purely on a settings toggle. `classes/class-cartflows-pro-ab-test-factory.php:297-310`
- **Deleting or archiving a variation reassigns already-bucketed visitors mid-test**, contaminating results — the cookie is validated against the live variation list and silently rewritten. `classes/class-cartflows-pro-ab-test-factory.php:239-246`
- The cookie is written during `cartflows_wp`; if any output has been emitted the header fails and the visitor is re-bucketed on **every** page view, with no error. `classes/class-cartflows-pro-ab-test-factory.php:187-198`
- **Archived steps redirect forever** — `delete_variation` deliberately writes `wcf-control-step` onto every archived variation, and restore only deletes `wcf-winner-step`, not `wcf-control-step`. `classes/class-cartflows-pro-ab-test-meta.php:149-153,754`
- **Traffic split is silently reset to 50/50 on any deletion**, and variations beyond index 1 are forced to `0` traffic with no admin notice. `classes/class-cartflows-pro-ab-test-meta.php:192-201`
- Step entries are replaced **wholesale** with a 3-key array, dropping any data another module stored on that flow-step entry. `classes/class-cartflows-pro-ab-test-meta.php:135-139,536-540`
- `array_splice` on the array being iterated, without `break` — the element after a removed one is skipped. `classes/class-cartflows-pro-ab-test-meta.php:184-189`
- **Admins are excluded from the whole front-end path**, so a test appears broken when verified while logged in. `classes/class-cartflows-pro-ab-test-markup.php:52-54`
- A migration constraint is written down: the three migrated nonce names are kept verbatim from the free plugin, which owned these handlers until now. Renaming them breaks free-plugin JS that still posts them. `classes/class-cartflows-pro-ab-test-meta.php:91`
- The weighted-selection window test is inclusive on **both** ends, so each cumulative boundary belongs to two variations and is always awarded to the earlier one — a 50/50 split is not exactly 50/50. `classes/class-cartflows-pro-ab-test-factory.php:347`

## After changes

- Boundary, rule, or reasoning changed? Update `architecture.md` in the same change.
- Not for internal refactors that change nothing a caller can observe.
- New architectural decision? Add an ADR under `docs/decisions/`.
- Run: `composer lint && composer phpstan && composer test`
