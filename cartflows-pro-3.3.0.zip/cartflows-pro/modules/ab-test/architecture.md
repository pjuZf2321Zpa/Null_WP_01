---
module: ab-test
---

# ab-test

## Responsibility

Owns the full lifecycle of CartFlows split tests: the admin-side mutations of the flow's `wcf-steps` meta and the per-step `wcf-ab-test` / `wcf-control-step` / `wcf-winner-step` meta (eleven AJAX handlers), and the front-end variation assignment — cookie-based stickiness, weighted random pick, and the redirect or in-place content swap.

Ownership stops at step cloning, the `wcf_get_ab_test()` accessor, analytics recording (it only sets flags), and all admin UI/JS — the module only emits nonces into localized vars.

## Why it is this way

Correctness rests on invariants that live in **post meta**, not in code: which step is the control (encoded as the *absence* of `wcf-control-step`), that IDs are integers, that traffic sums to 100, and that archived steps intentionally redirect forever.

The front end forks between "redirect and die" and "swap four WordPress globals in place" on a settings toggle, which is why the global swap carries an explicit comment — it exists so views and conversions attribute to the variation rather than the control.
