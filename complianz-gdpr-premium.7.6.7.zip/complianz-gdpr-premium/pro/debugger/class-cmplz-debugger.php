<?php
/**
 * CMPLZ Debugger — core class.
 *
 * @package Complianz
 */

defined( 'ABSPATH' ) || die();

/**
 * Debug overlay controller.
 */
class CMPLZ_Debugger {

	/**
	 * Singleton instance.
	 *
	 * @var CMPLZ_Debugger|null
	 */
	private static $instance = null;

	/**
	 * Get or create the singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — registers WordPress hooks.
	 */
	private function __construct() {
		add_action( 'wp_head', array( $this, 'output_interceptor' ), 1 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Active only for users who can manage Complianz, AND either SCRIPT_DEBUG is true
	 * or ?cmplz_debug=1 is present. Auth is always required — SCRIPT_DEBUG alone is
	 * not sufficient so anonymous visitors never see the debugger.
	 */
	public static function is_active(): bool {
		if ( ! function_exists( 'cmplz_user_can_manage' ) || ! cmplz_user_can_manage() ) {
			return false;
		}
		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
			return true;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only debug flag, no state change.
		if ( isset( $_GET['cmplz_debug'] ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Determine which GCM template Complianz is outputting.
	 * Returns 'none' if GCM is disabled or Complianz does not manage the template.
	 *
	 * @return array
	 */
	private function get_active_template(): array {
		if ( ! function_exists( 'cmplz_consent_mode' ) || ! cmplz_consent_mode() ) {
			return array(
				'name'   => 'none',
				'source' => 'none',
			);
		}

		$config_by_complianz = cmplz_get_option( 'configuration_by_complianz' );
		if ( 'yes' !== $config_by_complianz ) {
			// User manages GCM themselves; Complianz fires update events but not the template.
			return array(
				'name'   => 'user-custom',
				'source' => 'user',
			);
		}

		$stats = cmplz_get_option( 'compile_statistics' );

		if ( 'google-analytics' === $stats ) {
			$basic = cmplz_get_option( 'gtag-basic-consent-mode' ) === 'yes';
			return array(
				'name'   => $basic ? 'gtag-consent-mode-basic' : 'gtag-consent-mode',
				'source' => 'complianz',
			);
		}

		if ( 'google-tag-manager' === $stats ) {
			$use_template = cmplz_get_option( 'cmplz-tm-template' ) === 'yes';
			$suffix       = $use_template ? '-template' : '';
			// Loader free variant when Site Kit owns the container.
			if ( function_exists( 'cmplz_google_site_kit_owns_tagmanager' ) && cmplz_google_site_kit_owns_tagmanager() ) {
				return array(
					'name'   => "sitekit-tag-manager-consent-mode$suffix",
					'source' => 'complianz',
				);
			}
			return array(
				'name'   => "google-tag-manager-consent-mode$suffix",
				'source' => 'complianz',
			);
		}

		if ( 'gtg' === $stats ) {
			$gtg_backend = cmplz_get_option( 'compile_statistics_more_info_gtg' );
			return array(
				'name'   => 'google-tag-manager' === $gtg_backend
					? 'gtg-tag-manager-consent-mode'
					: 'gtg-consent-mode',
				'source' => 'complianz',
			);
		}

		return array(
			'name'   => 'none',
			'source' => 'none',
		);
	}

	/**
	 * Output the interceptor inline at the very top of <head> so it wraps
	 * dataLayer and gtag before any GCM template fires.
	 */
	public function output_interceptor(): void {
		$file = CMPLZ_PATH . 'pro/debugger/js/gcm-interceptor.js';
		if ( ! file_exists( $file ) ) {
			return;
		}
		echo '<script id="cmplz-gcm-interceptor">' . "\n";
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.Security.EscapeOutput.OutputNotEscaped
		echo file_get_contents( $file );
		echo "\n" . '</script>' . "\n";
	}

	/**
	 * Enqueue debugger styles and scripts.
	 */
	public function enqueue_assets(): void {
		$base = CMPLZ_URL . 'pro/debugger/';
		$ver  = CMPLZ_VERSION;

		wp_enqueue_style( 'cmplz-debugger', $base . 'css/cmplz-debugger.css', array(), $ver );

		// gcm-interceptor is already inlined; the remaining modules load in footer.
		wp_enqueue_script( 'cmplz-tag-detector', $base . 'js/tag-detector.js', array(), $ver, true );
		wp_enqueue_script( 'cmplz-tab-gcm-status', $base . 'js/tab-gcm-status.js', array( 'cmplz-tag-detector' ), $ver, true );
		wp_enqueue_script( 'cmplz-tab-sequence', $base . 'js/tab-sequence.js', array(), $ver, true );
		wp_enqueue_script( 'cmplz-tab-tcf', $base . 'js/tab-tcf.js', array(), $ver, true );
		wp_enqueue_script( 'cmplz-tab-cookies', $base . 'js/tab-cookies.js', array(), $ver, true );
		wp_enqueue_script(
			'cmplz-debugger',
			$base . 'js/cmplz-debugger.js',
			array( 'cmplz-tab-gcm-status', 'cmplz-tab-sequence', 'cmplz-tab-tcf', 'cmplz-tab-cookies' ),
			$ver,
			true
		);

		// Attach to the FIRST enqueued script so cmplzDebugConfig is defined before
		// any tab module executes. wp_localize_script outputs inline JS right before
		// its target script tag, so attaching to cmplz-tag-detector (first in footer)
		// guarantees availability for all subsequent modules.
		$template = $this->get_active_template();
		wp_localize_script(
			'cmplz-tag-detector',
			'cmplzDebugConfig',
			array(
				'gcmEnabled'     => function_exists( 'cmplz_consent_mode' ) && cmplz_consent_mode(),
				'templateName'   => $template['name'],
				'templateSource' => $template['source'],
				'statsProvider'  => function_exists( 'cmplz_get_option' ) ? cmplz_get_option( 'compile_statistics' ) : '',
			)
		);
	}
}
