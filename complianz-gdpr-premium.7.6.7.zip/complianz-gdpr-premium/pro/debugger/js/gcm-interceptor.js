/**
 * GCM Interceptor — inlined in <head> at priority 1.
 *
 * Must run before any GCM template or GTM snippet fires.
 * Wraps window.dataLayer.push and intercepts known Complianz DOM events.
 * All captured signals land in window.CmplzDebugger.timeline[].
 *
 * If a GCM template already pushed entries before this script ran, those are
 * replayed retroactively and flagged with retroactive:true in the timeline.
 */
( function () {
	const T0 = Date.now();

	window.CmplzDebugger = window.CmplzDebugger || {
		timeline: [],
		tags: null, // set by tag-detector.js
		_t0: T0,
	};

	const db = window.CmplzDebugger;

	function ts() {
		return Date.now() - T0;
	}

	function safeClone( obj ) {
		try {
			return JSON.parse( JSON.stringify( obj ) );
		} catch ( e ) {
			return String( obj );
		}
	}

	// ── Core item processor ────────────────────────────────────────────────────
	// Used both by the wrapped push (live) and the retroactive replay (pre-interceptor).
	function processItem( item, retroactive ) {
		const entryTs = retroactive ? 0 : ts();

		if (
			typeof item === 'object' &&
			item !== null &&
			typeof item[ 0 ] !== 'undefined'
		) {
			// Arguments-like object pushed by gtag()
			if ( item[ 0 ] === 'consent' ) {
				db.timeline.push( {
					type: 'gtag-consent',
					call: item[ 1 ], // 'default' or 'update'
					params: safeClone( item[ 2 ] || {} ),
					ts: entryTs,
					retroactive,
				} );
			} else if ( item[ 0 ] === 'set' ) {
				db.timeline.push( {
					type: 'gtag-set',
					key: item[ 1 ],
					value: safeClone( item[ 2 ] ),
					ts: entryTs,
					retroactive,
				} );
			} else if ( item[ 0 ] === 'config' ) {
				db.timeline.push( {
					type: 'gtag-config',
					tag: item[ 1 ],
					ts: entryTs,
					retroactive,
				} );
			} else if ( item[ 0 ] === 'js' ) {
				db.timeline.push( {
					type: 'gtag-js',
					ts: entryTs,
					retroactive,
				} );
			}
		} else if ( typeof item === 'object' && item !== null && item.event ) {
			// Plain object pushed by GTM
			db.timeline.push( {
				type: 'datalayer-event',
				event: item.event,
				data: safeClone( item ),
				ts: entryTs,
				retroactive,
			} );
		}
	}

	// ── Wrap dataLayer.push ────────────────────────────────────────────────────
	window.dataLayer = window.dataLayer || [];

	// Replay any entries that were pushed before this script loaded.
	// This happens when a GCM template fires at the same or higher wp_head priority.
	const preExisting = window.dataLayer.slice();
	preExisting.forEach( function ( item ) {
		processItem( item, true );
	} );

	const _origPush = window.dataLayer.push.bind( window.dataLayer );

	window.dataLayer.push = function () {
		for ( let i = 0; i < arguments.length; i++ ) {
			processItem( arguments[ i ], false );
		}
		return _origPush.apply( window.dataLayer, arguments );
	};

	// ── Intercept Complianz DOM events ─────────────────────────────────────────
	const cmplzEvents = [
		'cmplz_cookie_warning_loaded',
		'cmplz_before_categories_consent',
		'cmplz_fire_categories',
		'cmplz_revoke',
	];

	cmplzEvents.forEach( function ( name ) {
		document.addEventListener(
			name,
			function ( e ) {
				db.timeline.push( {
					type: 'cmplz-event',
					event: name,
					detail: safeClone( e.detail || {} ),
					ts: ts(),
				} );
			},
			true
		); // capture phase — fire before any other listener
	} );

	// ── Record page-load marker ────────────────────────────────────────────────
	db.timeline.push( { type: 'page-load', ts: 0 } );

	// ── Record DOMContentLoaded ────────────────────────────────────────────────
	document.addEventListener( 'DOMContentLoaded', function () {
		db.timeline.push( { type: 'dom-ready', ts: ts() } );
	} );
} )();
