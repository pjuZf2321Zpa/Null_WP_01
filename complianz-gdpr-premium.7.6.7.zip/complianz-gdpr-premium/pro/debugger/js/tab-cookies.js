/**
 * Tab 4 — Cookies & Config
 *
 * Shows all cmplz_* cookies and the full window.complianz config object.
 */
( function () {
	window.CmplzDebugger = window.CmplzDebugger || { timeline: [], gtg: null };

	function sectionTitle( t ) {
		return '<div class="cmplz-dbg-section-title">' + t + '</div>';
	}

	function row( label, value, cls ) {
		return (
			'<div class="cmplz-dbg-row">' +
			'<span class="cmplz-dbg-label">' +
			label +
			'</span>' +
			'<span class="cmplz-dbg-value ' +
			( cls || '' ) +
			'">' +
			value +
			'</span>' +
			'</div>'
		);
	}

	function getCookies() {
		const result = {};
		document.cookie.split( ';' ).forEach( function ( part ) {
			const idx = part.indexOf( '=' );
			if ( idx === -1 ) {
				return;
			}
			const key = part.substring( 0, idx ).trim();
			const value = part.substring( idx + 1 ).trim();
			if (
				key.indexOf( 'cmplz' ) === 0 ||
				key.indexOf( 'CMPLZ' ) === 0
			) {
				result[ key ] = decodeURIComponent( value );
			}
		} );
		return result;
	}

	function parseCmplzCookie( value ) {
		// cmplz_{region} stores JSON like: {"categories":{"statistics":"granted","marketing":"denied"},"version":"1"}
		try {
			const obj = JSON.parse( value );
			return obj;
		} catch ( e ) {
			return null;
		}
	}

	window.CmplzDebugger.renderCookies = function ( container ) {
		let html = '';
		const cfg = window.complianz || {};
		const cookies = getCookies();
		const cookieKeys = Object.keys( cookies );

		// ── Complianz cookies ─────────────────────────────────────────────────────
		html += sectionTitle(
			'Complianz Cookies (' + cookieKeys.length + ' found)'
		);

		if ( cookieKeys.length === 0 ) {
			html +=
				'<div class="cmplz-dbg-empty">No cmplz_* cookies found. The user has not interacted with the banner yet.</div>';
		} else {
			cookieKeys.forEach( function ( key ) {
				const raw = cookies[ key ];
				const parsed = parseCmplzCookie( raw );

				html += '<div class="cmplz-dbg-cookie">';
				html += '<div class="cmplz-dbg-cookie-name">' + key + '</div>';

				if ( parsed && parsed.categories ) {
					// Render consent categories inline
					Object.keys( parsed.categories ).forEach( function ( cat ) {
						const state = parsed.categories[ cat ];
						const cls = state === 'granted' ? 'ok' : 'err';
						html +=
							'<div style="display:flex;justify-content:space-between;font-size:10px;padding:2px 0;">' +
							'<span style="color:var(--cmplz-dbg-muted);">' +
							cat +
							'</span>' +
							'<span class="cmplz-dbg-value ' +
							cls +
							'">' +
							state +
							'</span>' +
							'</div>';
					} );
					if ( parsed.version ) {
						html +=
							'<div style="color:var(--cmplz-dbg-muted);font-size:9px;margin-top:4px;">version: ' +
							parsed.version +
							'</div>';
					}
				} else {
					html +=
						'<div class="cmplz-dbg-cookie-value">' + raw + '</div>';
				}

				html += '</div>';
			} );
		}

		// ── window.complianz config ───────────────────────────────────────────────
		html += sectionTitle( 'window.complianz Config' );

		const configKeys = Object.keys( cfg );
		if ( configKeys.length === 0 ) {
			html +=
				'<div class="cmplz-dbg-empty">window.complianz not available. complianz.js may not be loaded (Path B site).</div>';
		} else {
			configKeys.forEach( function ( key ) {
				let val = cfg[ key ];
				if ( typeof val === 'object' && val !== null ) {
					val = JSON.stringify( val );
				}
				html += row( key, String( val ), '' );
			} );
		}

		// ── Other relevant cookies ────────────────────────────────────────────────
		const allCookies = {};
		document.cookie.split( ';' ).forEach( function ( part ) {
			const idx = part.indexOf( '=' );
			if ( idx === -1 ) {
				return;
			}
			const k = part.substring( 0, idx ).trim();
			const v = part.substring( idx + 1 ).trim();
			if (
				k.indexOf( '_ga' ) === 0 ||
				k.indexOf( '_gid' ) === 0 ||
				k.indexOf( '_gcl' ) === 0
			) {
				allCookies[ k ] = decodeURIComponent( v );
			}
		} );

		const gaKeys = Object.keys( allCookies );
		if ( gaKeys.length > 0 ) {
			html += sectionTitle(
				'Google Analytics Cookies (' + gaKeys.length + ' found)'
			);
			gaKeys.forEach( function ( k ) {
				html +=
					'<div class="cmplz-dbg-cookie">' +
					'<div class="cmplz-dbg-cookie-name">' +
					k +
					'</div>' +
					'<div class="cmplz-dbg-cookie-value">' +
					allCookies[ k ] +
					'</div>' +
					'</div>';
			} );
			if ( gaKeys.length > 0 ) {
				html +=
					'<div style="color:var(--cmplz-dbg-yellow);font-size:10px;margin-top:6px;">' +
					'GA cookies present. Verify these were set only after consent was granted.' +
					'</div>';
			}
		}

		container.innerHTML = html;
	};
} )();
