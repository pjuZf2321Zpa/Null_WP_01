/**
 * Tag Detector — detects which Google tag products are loaded and infers GTG.
 *
 * Detection is entirely browser-side: window globals + dataLayer timeline
 * captured by gcm-interceptor.js. No plugin settings are consulted.
 *
 * Results are stored in window.CmplzDebugger.tags and consumed by tab-gcm-status.js.
 */
( function () {
	window.CmplzDebugger = window.CmplzDebugger || { timeline: [], tags: null };

	// Script domains that indicate a standard (non-proxied) Google tag setup.
	const THIRD_PARTY_HOSTNAMES = [
		'www.googletagmanager.com',
		'googletagmanager.com',
		'www.google-analytics.com',
		'google-analytics.com',
	];

	function isThirdPartyGoogleResource( url ) {
		try {
			const u = new URL( url );
			return THIRD_PARTY_HOSTNAMES.some( function ( h ) {
				return u.hostname === h;
			} );
		} catch ( e ) {
			return false;
		}
	}

	function detect() {
		const tl = window.CmplzDebugger.timeline || [];

		// ── GTM ───────────────────────────────────────────────────────────────────
		// google_tag_manager is keyed by container ID when GTM loads.
		const gtmIds =
			window.google_tag_manager &&
			typeof window.google_tag_manager === 'object'
				? Object.keys( window.google_tag_manager ).filter(
						function ( k ) {
							return k.startsWith( 'GTM-' );
						}
				  )
				: [];
		const gtm = gtmIds.length > 0;

		// ── GA4 / gtag.js ─────────────────────────────────────────────────────────
		// window.gtag is defined by gtag.js. Supplement with timeline in case the
		// script loaded before the window reference was stable at detect() time.
		const ga4FromWindow = typeof window.gtag === 'function';
		const ga4FromTimeline = tl.some( function ( e ) {
			return e.type === 'gtag-js' || e.type === 'gtag-config';
		} );
		const ga4 = ga4FromWindow || ga4FromTimeline;

		// Collect all tag IDs passed to gtag('config', id) — G-*, AW-*, DC-*, etc.
		const configIds = tl
			.filter( function ( e ) {
				return e.type === 'gtag-config' && e.tag;
			} )
			.map( function ( e ) {
				return e.tag;
			} )
			.filter( function ( id, i, arr ) {
				return arr.indexOf( id ) === i; // dedupe
			} );

		// ── UA / GA3 ──────────────────────────────────────────────────────────────
		// analytics.js sets window.ga (or the name in GoogleAnalyticsObject).
		const ua =
			typeof window.ga === 'function' || !! window.GoogleAnalyticsObject;

		// ── Third-party check (for GTG inference) ─────────────────────────────────
		const thirdPartyUrls = [];

		if (
			window.PerformanceObserver ||
			( performance && performance.getEntriesByType )
		) {
			performance.getEntriesByType( 'resource' ).forEach( function ( e ) {
				if (
					e.initiatorType === 'script' ||
					e.initiatorType === 'xmlhttprequest' ||
					e.initiatorType === 'fetch'
				) {
					if ( isThirdPartyGoogleResource( e.name ) ) {
						thirdPartyUrls.push( e.name );
					}
				}
			} );
		}

		// GTG inferred: a Google tag is running but all traffic stays first-party.
		const anyTagActive = gtm || ga4 || ua;
		const gtgInferred = anyTagActive && thirdPartyUrls.length === 0;

		let reason;
		if ( ! anyTagActive ) {
			reason = 'No Google tag (gtag/GTM/UA) detected on this page';
		} else if ( gtgInferred ) {
			reason =
				'Google tag active — no third-party Google domains found, first-party proxy (GTG) inferred';
		} else {
			reason = 'Standard third-party Google tag (no GTG)';
		}

		window.CmplzDebugger.tags = {
			gtm,
			gtmIds,
			ga4,
			configIds, // all gtag config tag IDs (G-*, AW-*, DC-*, …)
			ua,
			gtgInferred,
			thirdPartyUrls,
			reason,
		};
	}

	// Run after all resources have loaded.
	if ( document.readyState === 'complete' ) {
		detect();
	} else {
		window.addEventListener( 'load', function () {
			// Small delay so late-injected scripts appear in PerformanceResourceTiming.
			setTimeout( detect, 500 );
		} );
	}
} )();
