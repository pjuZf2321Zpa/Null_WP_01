/**
 * Tab 1 — GCM Status
 *
 * window.cmplzDebugConfig (wp_localize_script) is the authoritative source for
 * GCM status — some templates (e.g. GTM template) don't emit page-level signals,
 * so we cannot rely on dataLayer interception alone.
 *
 * CmplzDebugger.timeline supplements with captured runtime signals.
 */
( function () {
	window.CmplzDebugger = window.CmplzDebugger || { timeline: [], gtg: null };

	// Template display labels
	const TEMPLATE_LABELS = {
		'gtag-consent-mode': 'gtag-consent-mode.js  (Advanced, GA)',
		'gtag-consent-mode-basic': 'gtag-consent-mode-basic.js  (GA)',
		'google-tag-manager-consent-mode':
			'google-tag-manager-consent-mode.js  (GTM)',
		'google-tag-manager-consent-mode-template':
			'google-tag-manager-consent-mode-template.js  (GTM)',
		'gtg-consent-mode': 'GTG + GA  (Google Tag Gateway, Google Analytics)',
		'gtg-tag-manager-consent-mode':
			'GTG + GTM  (Google Tag Gateway, Google Tag Manager)',
		'sitekit-tag-manager-consent-mode':
			'Site Kit + GTM  (Site Kit loads the container)',
		'sitekit-tag-manager-consent-mode-template':
			'Site Kit + GTM  (Site Kit loads the container, template)',
		'user-custom': 'User-managed  (custom template)',
		none: 'None',
	};

	// Templates where consent default is handled INSIDE the GTM container,
	// not via a page-level gtag() call — so our interceptor won't see a default signal.
	const GTM_CONTAINER_DEFAULT = [
		'google-tag-manager-consent-mode-template',
		'sitekit-tag-manager-consent-mode-template',
	];

	function row( label, value, cls ) {
		return (
			'<div class="cmplz-dbg-row">' +
			'<span class="cmplz-dbg-label">' +
			label +
			'</span>' +
			'<span class="cmplz-dbg-value ' +
			( cls || '' ) +
			'">' +
			value +
			'</span>' +
			'</div>'
		);
	}

	function sectionTitle( t ) {
		return '<div class="cmplz-dbg-section-title">' + t + '</div>';
	}

	window.CmplzDebugger.renderGcmStatus = function ( container ) {
		const db = window.CmplzDebugger;
		const cfg = window.complianz || {};
		const tl = db.timeline || [];
		// Read lazily — cmplzDebugConfig is defined after this module loads
		const phpCfg = window.cmplzDebugConfig || {};

		const gcmEnabled = !! phpCfg.gcmEnabled;
		const templateName = phpCfg.templateName || 'none';
		const templateSource = phpCfg.templateSource || 'none';
		const statsProvider = phpCfg.statsProvider || '';

		// Runtime signals from interceptor (supplementary)
		const defaultCall = tl.find( function ( e ) {
			return e.type === 'gtag-consent' && e.call === 'default';
		} );
		const updateCall = tl.find( function ( e ) {
			return e.type === 'gtag-consent' && e.call === 'update';
		} );
		const adsRedact = tl.find( function ( e ) {
			return e.type === 'gtag-set' && e.key === 'ads_data_redaction';
		} );
		const urlPass = tl.find( function ( e ) {
			return e.type === 'gtag-set' && e.key === 'url_passthrough';
		} );
		const tagsInfo = db.tags || {};

		const defaultIsInsideGtm =
			GTM_CONTAINER_DEFAULT.indexOf( templateName ) !== -1;

		// Check if the Complianz GTM template bridge is wired (window.addConsentUpdateListener exists)
		const gtmBridgeActive =
			typeof window.addConsentUpdateListener === 'function';

		const templateLabel = TEMPLATE_LABELS[ templateName ] || templateName;

		let html = '';

		// ── Complianz config ─────────────────────────────────────────────────────
		html += sectionTitle( 'Complianz Config' );
		let consentTypeCls;
		if ( cfg.consenttype === 'optin' ) {
			consentTypeCls = 'info';
		} else if ( cfg.consenttype === 'optout' ) {
			consentTypeCls = 'warn';
		} else {
			consentTypeCls = 'ok';
		}
		html += row( 'Consent Type', cfg.consenttype || '—', consentTypeCls );
		html += row( 'Region', cfg.region || '—', 'teal' );
		html += row(
			'GEO IP',
			cfg.geoip ? 'enabled' : 'disabled',
			cfg.geoip ? 'ok' : 'warn'
		);
		html += row(
			'TCF Active',
			cfg.tcf_active ? 'yes' : 'no',
			cfg.tcf_active ? 'ok' : ''
		);
		html += row( 'Store Consent', cfg.store_consent ? 'yes' : 'no', '' );
		html += row(
			'Cookie Expiry',
			cfg.cookie_expiry ? cfg.cookie_expiry + ' days' : '—',
			''
		);
		html += row(
			'Force Stats',
			cfg.forceEnableStats ? 'yes' : 'no',
			cfg.forceEnableStats ? 'warn' : ''
		);
		html += row( 'Plugin Version', cfg.version || '—', '' );

		// ── GCM status (PHP-authoritative) ───────────────────────────────────────
		html += sectionTitle( 'Google Consent Mode' );
		html += row(
			'GCM Enabled',
			gcmEnabled ? 'YES' : 'NO',
			gcmEnabled ? 'ok' : 'err'
		);

		// Template source — key distinction
		let sourceLabel = '—';
		let sourceCls = '';
		if ( templateSource === 'complianz' ) {
			sourceLabel = 'Complianz template';
			sourceCls = 'ok';
		} else if ( templateSource === 'user' ) {
			sourceLabel = 'User-managed  (Complianz fires update events only)';
			sourceCls = 'warn';
		} else if ( templateSource === 'none' ) {
			sourceLabel = gcmEnabled ? 'Unknown' : 'N/A';
			sourceCls = '';
		}
		html += row( 'Template Source', sourceLabel, sourceCls );
		html += row(
			'Active Template',
			gcmEnabled ? templateLabel : '—',
			gcmEnabled ? 'info' : ''
		);

		if ( statsProvider ) {
			html += row( 'Stats Provider', statsProvider, '' );
		}

		// ── Runtime signals ───────────────────────────────────────────────────────
		html += sectionTitle( 'Runtime Signals  (intercepted)' );

		// Default signal row — context-aware
		let defaultValue, defaultCls;
		if ( defaultCall ) {
			defaultValue = defaultCall.retroactive
				? 'captured  (pre-interceptor — fired before debugger loaded)'
				: 'captured  (+' + defaultCall.ts + 'ms)';
			defaultCls = defaultCall.retroactive ? 'info' : 'ok';
		} else if ( defaultIsInsideGtm ) {
			defaultValue = 'Inside GTM container  (not page-level)';
			defaultCls = 'info';
		} else if ( ! gcmEnabled ) {
			defaultValue = 'GCM not enabled';
			defaultCls = '';
		} else {
			defaultValue = 'not captured  (interceptor may have loaded late)';
			defaultCls = 'warn';
		}
		html += row( 'consent default', defaultValue, defaultCls );

		// Update signal row
		let updateValue;
		if ( updateCall ) {
			updateValue = 'captured  (+' + updateCall.ts + 'ms)';
		} else if ( gcmEnabled ) {
			updateValue = 'not yet  (interact with banner)';
		} else {
			updateValue = '—';
		}
		let updateCls;
		if ( updateCall ) {
			updateCls = 'ok';
		} else if ( gcmEnabled ) {
			updateCls = 'warn';
		} else {
			updateCls = '';
		}
		html += row( 'consent update', updateValue, updateCls );

		html += row(
			'ads_data_redaction',
			adsRedact ? String( adsRedact.value ) : '—',
			adsRedact ? 'ok' : ''
		);
		html += row(
			'url_passthrough',
			urlPass ? String( urlPass.value ) : '—',
			urlPass ? 'ok' : ''
		);

		// GTM template bridge
		if ( GTM_CONTAINER_DEFAULT.includes( templateName ) ) {
			html += row(
				'GTM bridge (addConsentUpdateListener)',
				gtmBridgeActive ? 'ready' : 'not found',
				gtmBridgeActive ? 'ok' : 'err'
			);
		}

		// ── Tag detection (browser-side) ─────────────────────────────────────────
		html += sectionTitle( 'Tag Detection  (browser)' );

		// GTM
		const gtmLabel = tagsInfo.gtm
			? 'YES' +
			  ( tagsInfo.gtmIds && tagsInfo.gtmIds.length
					? '  — ' + tagsInfo.gtmIds.join( ', ' )
					: '' )
			: 'not detected';
		html += row( 'Google Tag Manager', gtmLabel, tagsInfo.gtm ? 'ok' : '' );

		// GA4 / gtag.js
		const ga4Ids =
			tagsInfo.configIds &&
			tagsInfo.configIds.filter( function ( id ) {
				return id.startsWith( 'G-' );
			} );
		const ga4Label = tagsInfo.ga4
			? 'YES' +
			  ( ga4Ids && ga4Ids.length ? '  — ' + ga4Ids.join( ', ' ) : '' )
			: 'not detected';
		html += row( 'GA4  (gtag.js)', ga4Label, tagsInfo.ga4 ? 'ok' : '' );

		// UA / GA3
		html += row(
			'Universal Analytics  (GA3)',
			tagsInfo.ua ? 'YES' : 'not detected',
			tagsInfo.ua ? 'ok' : ''
		);

		// Other gtag config IDs (Ads, Floodlight, etc.)
		const otherIds =
			tagsInfo.configIds &&
			tagsInfo.configIds.filter( function ( id ) {
				return ! id.startsWith( 'G-' );
			} );
		if ( otherIds && otherIds.length ) {
			html += row( 'Other tag IDs', otherIds.join( ', ' ), 'teal' );
		}

		// Delivery / GTG inference
		const anyTagActive = tagsInfo.gtm || tagsInfo.ga4 || tagsInfo.ua;
		let deliveryLabel, deliveryCls;
		if ( ! anyTagActive ) {
			deliveryLabel = '—  (no tag detected)';
			deliveryCls = '';
		} else if ( tagsInfo.gtgInferred ) {
			deliveryLabel = 'First-party proxy  (GTG inferred)';
			deliveryCls = 'ok';
		} else {
			deliveryLabel = 'Third-party  (standard, no GTG)';
			deliveryCls = 'warn';
		}
		html += row( 'Delivery', deliveryLabel, deliveryCls );

		if ( tagsInfo.thirdPartyUrls && tagsInfo.thirdPartyUrls.length ) {
			html += row(
				'Third-party domain  (evidence against GTG)',
				tagsInfo.thirdPartyUrls[ 0 ],
				'warn'
			);
		}

		// ── Default consent state (if captured) ──────────────────────────────────
		if (
			defaultCall &&
			defaultCall.params &&
			Object.keys( defaultCall.params ).length
		) {
			html += sectionTitle( 'Captured Default Consent State' );
			html += '<div class="cmplz-dbg-consent-grid">';
			Object.keys( defaultCall.params ).forEach( function ( k ) {
				const val = defaultCall.params[ k ];
				const cls = val === 'granted' ? 'granted' : 'denied';
				html +=
					'<div class="cmplz-dbg-consent-cell ' +
					cls +
					'">' +
					'<div class="cmplz-dbg-cell-key">' +
					k.replace( /_/g, ' ' ) +
					'</div>' +
					'<div class="cmplz-dbg-cell-val">' +
					val +
					'</div>' +
					'</div>';
			} );
			html += '</div>';
		} else if ( defaultIsInsideGtm && gcmEnabled ) {
			html += sectionTitle( 'Default Consent State' );
			html +=
				'<div style="color:var(--cmplz-dbg-muted);font-size:11px;padding:6px 0;">' +
				'Default state is configured inside your GTM container via the Complianz GTM template tag. ' +
				"Use GTM's Preview mode or the Sequence tab (after banner interaction) to inspect consent values." +
				'</div>';
		}

		container.innerHTML = html;
	};
} )();
