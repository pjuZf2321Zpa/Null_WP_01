/**
 * Complianz GCM Debugger — main entry point.
 *
 * Builds the toggle button (bottom-left) and slide-in panel (top-right),
 * wires up tab navigation, and delegates rendering to the tab modules.
 */
( function () {
	const TABS = [
		{
			id: 'gcm',
			label: 'GCM Status',
			render( el ) {
				window.CmplzDebugger.renderGcmStatus( el );
			},
		},
		{
			id: 'sequence',
			label: 'U+C Seq.',
			render( el ) {
				window.CmplzDebugger.renderSequence( el );
			},
		},
		{
			id: 'tcf',
			label: 'TCF',
			render( el ) {
				window.CmplzDebugger.renderTcf( el );
			},
		},
		{
			id: 'cookies',
			label: 'Cookies',
			render( el ) {
				window.CmplzDebugger.renderCookies( el );
			},
		},
	];

	let activeTab = 'gcm';
	let panelEl = null;
	let toggleBtnEl = null;
	const paneEls = {};
	const tabEls = {};
	let isOpen = false;

	// ── Build DOM ──────────────────────────────────────────────────────────────
	function build() {
		// Toggle button
		toggleBtnEl = document.createElement( 'button' );
		toggleBtnEl.id = 'cmplz-debug-toggle';
		toggleBtnEl.innerHTML =
			'<span class="cmplz-dbg-dot"></span> Complianz Debug Tool';
		toggleBtnEl.setAttribute( 'aria-label', 'Open Complianz Debug Tool' );
		toggleBtnEl.setAttribute( 'aria-controls', 'cmplz-debug-panel' );
		toggleBtnEl.setAttribute( 'aria-expanded', 'false' );
		toggleBtnEl.setAttribute( 'aria-haspopup', 'dialog' );
		toggleBtnEl.addEventListener( 'click', toggle );
		document.body.appendChild( toggleBtnEl );

		// Panel — aria-hidden keeps it invisible to screen readers when closed
		// (CSS uses transform, not display:none, so the DOM is always present)
		panelEl = document.createElement( 'div' );
		panelEl.id = 'cmplz-debug-panel';
		panelEl.setAttribute( 'role', 'dialog' );
		panelEl.setAttribute( 'aria-label', 'Complianz Debug Tool' );
		panelEl.setAttribute( 'aria-modal', 'true' );
		panelEl.setAttribute( 'aria-hidden', 'true' );

		const cfg = window.complianz || {};

		// Header
		panelEl.innerHTML =
			'<div class="cmplz-dbg-header">' +
			'<div>' +
			'<span class="cmplz-dbg-header-title">Complianz Debugger</span>' +
			'<span class="cmplz-dbg-header-version">v' +
			( cfg.version || '—' ) +
			'</span>' +
			'</div>' +
			'<div class="cmplz-dbg-header-actions">' +
			'<button class="cmplz-dbg-refresh" id="cmplz-dbg-refresh-btn" aria-label="Refresh current tab"><span class="cmplz-dbg-refresh-icon" aria-hidden="true">&#8635;</span> Refresh</button>' +
			'<button class="cmplz-dbg-close" id="cmplz-dbg-close-btn" aria-label="Close Complianz Debug Tool">&#10005;</button>' +
			'</div>' +
			'</div>';

		// Tab bar
		const tabBar = document.createElement( 'div' );
		tabBar.className = 'cmplz-dbg-tabs';
		tabBar.setAttribute( 'role', 'tablist' );
		tabBar.setAttribute( 'aria-label', 'Debugger navigation' );
		TABS.forEach( function ( tab ) {
			const btn = document.createElement( 'div' );
			btn.className =
				'cmplz-dbg-tab' +
				( tab.id === activeTab ? ' cmplz-dbg-active' : '' );
			btn.textContent = tab.label;
			btn.id = 'cmplz-dbg-tab-' + tab.id;
			btn.setAttribute( 'data-tab', tab.id );
			btn.setAttribute( 'role', 'tab' );
			// Only the active tab is in the Tab order; arrow keys navigate the rest.
			btn.setAttribute( 'tabindex', tab.id === activeTab ? '0' : '-1' );
			btn.setAttribute(
				'aria-selected',
				tab.id === activeTab ? 'true' : 'false'
			);
			btn.setAttribute( 'aria-controls', 'cmplz-dbg-pane-' + tab.id );
			btn.addEventListener( 'click', function () {
				activateTab( tab.id );
			} );
			btn.addEventListener( 'keydown', function ( e ) {
				const scrollKeys = [
					'ArrowUp',
					'ArrowDown',
					'ArrowLeft',
					'ArrowRight',
					'Home',
					'End',
					' ',
				];
				if ( scrollKeys.indexOf( e.key ) !== -1 ) {
					e.preventDefault();
				}
				const tabIds = TABS.map( function ( t ) {
					return t.id;
				} );
				const idx = tabIds.indexOf( tab.id );
				let target = -1;
				if ( e.key === 'ArrowRight' ) {
					target = ( idx + 1 ) % tabIds.length;
				} else if ( e.key === 'ArrowLeft' ) {
					target = ( idx - 1 + tabIds.length ) % tabIds.length;
				} else if ( e.key === 'Home' ) {
					target = 0;
				} else if ( e.key === 'End' ) {
					target = tabIds.length - 1;
				} else if ( e.key === 'Enter' ) {
					activateTab( tab.id );
					return;
				}
				if ( e.key === 'ArrowDown' ) {
					if ( paneEls[ activeTab ] ) {
						paneEls[ activeTab ].scrollBy( 0, 60 );
					}
				} else if ( e.key === 'ArrowUp' ) {
					if ( paneEls[ activeTab ] ) {
						paneEls[ activeTab ].scrollBy( 0, -60 );
					}
				} else if ( target !== -1 ) {
					activateTab( tabIds[ target ] );
					if ( tabEls[ tabIds[ target ] ] ) {
						tabEls[ tabIds[ target ] ].focus();
					}
				}
			} );
			tabBar.appendChild( btn );
			tabEls[ tab.id ] = btn;
		} );
		panelEl.appendChild( tabBar );

		// Pane container
		const paneContainer = document.createElement( 'div' );
		paneContainer.className = 'cmplz-dbg-panes';

		TABS.forEach( function ( tab ) {
			const pane = document.createElement( 'div' );
			pane.id = 'cmplz-dbg-pane-' + tab.id;
			pane.className =
				'cmplz-dbg-pane' +
				( tab.id === activeTab ? ' cmplz-dbg-active' : '' );
			pane.setAttribute( 'role', 'tabpanel' );
			pane.setAttribute( 'aria-labelledby', 'cmplz-dbg-tab-' + tab.id );
			pane.setAttribute(
				'aria-hidden',
				tab.id === activeTab ? 'false' : 'true'
			);
			pane.setAttribute( 'data-pane', tab.id );
			paneContainer.appendChild( pane );
			paneEls[ tab.id ] = pane;
		} );

		panelEl.appendChild( paneContainer );
		document.body.appendChild( panelEl );

		panelEl
			.querySelector( '#cmplz-dbg-refresh-btn' )
			.addEventListener( 'click', function () {
				const btn = this;
				btn.classList.add( 'cmplz-dbg-spinning' );
				btn.addEventListener( 'animationend', function handler() {
					btn.classList.remove( 'cmplz-dbg-spinning' );
					btn.removeEventListener( 'animationend', handler );
				} );
				renderTab( activeTab );
			} );

		panelEl
			.querySelector( '#cmplz-dbg-close-btn' )
			.addEventListener( 'click', close );

		// Keyboard: Escape closes panel; Tab is trapped inside while open
		document.addEventListener( 'keydown', function ( e ) {
			if ( ! isOpen ) {
				return;
			}
			if ( e.key === 'Escape' ) {
				close();
				return;
			}
			if ( e.key === 'Tab' ) {
				const focusable = getFocusableEls();
				if ( focusable.length === 0 ) {
					return;
				}
				const first = focusable[ 0 ];
				const last = focusable[ focusable.length - 1 ];
				const active = panelEl.ownerDocument.activeElement;
				if ( e.shiftKey && active === first ) {
					e.preventDefault();
					last.focus();
				} else if ( ! e.shiftKey && active === last ) {
					e.preventDefault();
					first.focus();
				}
			}
		} );
	}

	// ── Focus trap ─────────────────────────────────────────────────────────────
	function getFocusableEls() {
		return Array.from(
			panelEl.querySelectorAll( 'button, [tabindex="0"]' )
		).filter( function ( el ) {
			return ! el.disabled && el.offsetParent !== null;
		} );
	}

	// ── Tab management ─────────────────────────────────────────────────────────
	function activateTab( id ) {
		if ( tabEls[ activeTab ] ) {
			tabEls[ activeTab ].classList.remove( 'cmplz-dbg-active' );
			tabEls[ activeTab ].setAttribute( 'aria-selected', 'false' );
			tabEls[ activeTab ].setAttribute( 'tabindex', '-1' );
		}
		if ( paneEls[ activeTab ] ) {
			paneEls[ activeTab ].classList.remove( 'cmplz-dbg-active' );
			paneEls[ activeTab ].setAttribute( 'aria-hidden', 'true' );
		}

		activeTab = id;

		if ( tabEls[ id ] ) {
			tabEls[ id ].classList.add( 'cmplz-dbg-active' );
			tabEls[ id ].setAttribute( 'aria-selected', 'true' );
			tabEls[ id ].setAttribute( 'tabindex', '0' );
		}
		if ( paneEls[ id ] ) {
			paneEls[ id ].classList.add( 'cmplz-dbg-active' );
			paneEls[ id ].setAttribute( 'aria-hidden', 'false' );
		}

		renderTab( id );
	}

	function renderTab( id ) {
		const tab = TABS.find( function ( t ) {
			return t.id === id;
		} );
		const pane = paneEls[ id ];
		if ( ! tab || ! pane ) {
			return;
		}
		try {
			tab.render( pane );
		} catch ( e ) {
			pane.innerHTML =
				'<div style="color:var(--cmplz-dbg-red);font-size:11px;padding:12px 0;">' +
				'Render error: ' +
				e.message +
				'</div>';
		}
	}

	// ── Open / close ───────────────────────────────────────────────────────────
	function open() {
		isOpen = true;
		panelEl.classList.add( 'cmplz-dbg-visible' );
		panelEl.setAttribute( 'aria-hidden', 'false' );
		toggleBtnEl.classList.add( 'cmplz-dbg-open' );
		toggleBtnEl.setAttribute( 'aria-expanded', 'true' );
		toggleBtnEl.setAttribute( 'aria-label', 'Close Complianz Debug Tool' );
		renderTab( activeTab );
		// Move focus into the panel — close button is the first logical stop
		const closeBtn = panelEl.querySelector( '#cmplz-dbg-close-btn' );
		if ( closeBtn ) {
			closeBtn.focus();
		}
	}

	function close() {
		isOpen = false;
		panelEl.classList.remove( 'cmplz-dbg-visible' );
		panelEl.setAttribute( 'aria-hidden', 'true' );
		toggleBtnEl.classList.remove( 'cmplz-dbg-open' );
		toggleBtnEl.setAttribute( 'aria-expanded', 'false' );
		toggleBtnEl.setAttribute( 'aria-label', 'Open Complianz Debug Tool' );
		// Return focus to the element that opened the panel
		toggleBtnEl.focus();
	}

	function toggle() {
		if ( isOpen ) {
			close();
		} else {
			open();
		}
	}

	// ── Init ───────────────────────────────────────────────────────────────────
	function init() {
		if ( document.readyState === 'loading' ) {
			document.addEventListener( 'DOMContentLoaded', build );
		} else {
			build();
		}
	}

	init();
} )();
