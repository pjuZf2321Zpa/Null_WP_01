/**
 * Tab 3 — TCF Status
 *
 * Queries the CMP (window.__tcfapi) for TC data and renders
 * CMP metadata, purpose consents, and vendor consent summary.
 */
( function () {
	window.CmplzDebugger = window.CmplzDebugger || { timeline: [], gtg: null };

	const TCF_PURPOSES = {
		1: 'Store and/or access information on a device',
		2: 'Use limited data to select advertising',
		3: 'Create profiles for personalised advertising',
		4: 'Use profiles to select personalised advertising',
		5: 'Create profiles to personalise content',
		6: 'Use profiles to select personalised content',
		7: 'Measure advertising performance',
		8: 'Measure content performance',
		9: 'Understand audiences through statistics',
		10: 'Develop and improve services',
		11: 'Use limited data to select content',
	};

	function row( label, value, cls ) {
		return (
			'<div class="cmplz-dbg-row">' +
			'<span class="cmplz-dbg-label">' +
			label +
			'</span>' +
			'<span class="cmplz-dbg-value ' +
			( cls || '' ) +
			'">' +
			value +
			'</span>' +
			'</div>'
		);
	}

	function sectionTitle( t ) {
		return '<div class="cmplz-dbg-section-title">' + t + '</div>';
	}

	function renderTcData( container, tcData ) {
		let html = '';

		// ── CMP info ─────────────────────────────────────────────────────────────
		html += sectionTitle( 'CMP Info' );
		html += row(
			'TCF Active (Complianz)',
			window.complianz && window.complianz.tcf_active ? 'yes' : 'no',
			window.complianz && window.complianz.tcf_active ? 'ok' : 'warn'
		);
		html += row( 'TCF Version', tcData.tcfPolicyVersion || '—', '' );
		html += row( 'CMP ID', tcData.cmpId || '—', '' );
		html += row( 'CMP Version', tcData.cmpVersion || '—', '' );
		html += row(
			'GDPR Applies',
			tcData.gdprApplies ? 'yes' : 'no',
			tcData.gdprApplies ? 'warn' : ''
		);
		html += row(
			'Is Service-Specific',
			tcData.isServiceSpecific ? 'yes' : 'no',
			''
		);
		html += row(
			'Purpose One Treatment',
			tcData.purposeOneTreatment ? 'yes' : 'no',
			''
		);
		html += row( 'Publisher CC', tcData.publisherCC || '—', '' );

		// ── TC String ─────────────────────────────────────────────────────────────
		html += sectionTitle( 'TC String' );
		const tcString = tcData.tcString || '';
		html += row(
			'TC String',
			tcString ? tcString.substring( 0, 30 ) + '…' : 'not available',
			tcString ? 'teal' : 'err'
		);

		// ── Purpose consents ──────────────────────────────────────────────────────
		html += sectionTitle( 'Purpose Consents' );
		const purposes = tcData.purpose && tcData.purpose.consents;
		if ( purposes ) {
			let purposeHtml = '';
			Object.keys( TCF_PURPOSES ).forEach( function ( id ) {
				const granted = purposes[ id ];
				purposeHtml +=
					'<div class="cmplz-dbg-purpose">' +
					'<span class="cmplz-dbg-purpose-id">' +
					id +
					'</span>' +
					'<span class="cmplz-dbg-purpose-name">' +
					TCF_PURPOSES[ id ] +
					'</span>' +
					'<span class="cmplz-dbg-purpose-state ' +
					( granted ? 'ok' : 'err' ) +
					'">' +
					( granted ? 'Y' : 'N' ) +
					'</span>' +
					'</div>';
			} );
			html += purposeHtml;
		} else {
			html +=
				'<div class="cmplz-dbg-empty">Purpose consents not available.</div>';
		}

		// ── Vendor consents ───────────────────────────────────────────────────────
		html += sectionTitle( 'Vendor Consents' );
		const vendors = tcData.vendor && tcData.vendor.consents;
		if ( vendors ) {
			const grantedCount = Object.keys( vendors ).filter( function ( k ) {
				return vendors[ k ];
			} ).length;
			const totalCount = Object.keys( vendors ).length;
			html += row(
				'Vendors with consent',
				grantedCount + ' / ' + totalCount,
				grantedCount > 0 ? 'ok' : 'err'
			);
		} else {
			html +=
				'<div class="cmplz-dbg-empty">Vendor consents not available.</div>';
		}

		container.innerHTML = html;
	}

	window.CmplzDebugger.renderTcf = function ( container ) {
		if ( ! window.__tcfapi ) {
			container.innerHTML =
				sectionTitle( 'TCF Status' ) +
				'<div style="color:var(--cmplz-dbg-yellow);font-size:11px;padding:8px 0;">' +
				'window.__tcfapi not found. TCF is not active on this page.' +
				'</div>' +
				( window.complianz && window.complianz.tcf_active
					? '<div style="color:var(--cmplz-dbg-red);font-size:11px;">Note: complianz.tcf_active = true but __tcfapi is missing. Check TCF initialization.</div>'
					: '' );
			return;
		}

		container.innerHTML =
			'<div class="cmplz-dbg-empty">Loading TCF data…</div>';

		window.__tcfapi( 'getTCData', 2, function ( tcData, success ) {
			if ( ! success || ! tcData ) {
				container.innerHTML =
					'<div style="color:var(--cmplz-dbg-red);font-size:11px;padding:8px 0;">Failed to retrieve TCF data from __tcfapi.</div>';
				return;
			}
			renderTcData( container, tcData );
		} );
	};
} )();
