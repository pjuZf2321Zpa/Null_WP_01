/**
 * Tab 2 — U+C Sequence Timeline
 *
 * Renders a color-coded chronological timeline of GCM consent signals
 * and Complianz DOM events. Flags late consent updates.
 */
( function () {
	window.CmplzDebugger = window.CmplzDebugger || { timeline: [], gtg: null };

	// A consent update is "late" if it fires after gtag('js') or gtag('config') —
	// meaning the tag had already started executing in denied/cookie-less mode.
	function isLate( updateTs, tl ) {
		const configOrJs = tl.filter( function ( e ) {
			return (
				( e.type === 'gtag-config' || e.type === 'gtag-js' ) &&
				e.ts < updateTs
			);
		} );
		return configOrJs.length > 0;
	}

	function paramsToHtml( params ) {
		if ( ! params || typeof params !== 'object' ) {
			return '';
		}
		return Object.keys( params )
			.map( function ( k ) {
				const val = params[ k ];
				let cls;
				if ( val === 'granted' ) {
					cls = 'granted';
				} else if ( val === 'denied' ) {
					cls = 'denied';
				} else {
					cls = '';
				}
				return k + ': <span class="' + cls + '">' + val + '</span>';
			} )
			.join( '  ' );
	}

	function renderItem( entry, late ) {
		let typeClass = '';
		let labelClass = '';
		let label = '';
		let paramsHtml = '';

		if ( entry.type === 'page-load' ) {
			typeClass = '';
			labelClass = '';
			label = 'Page load (interceptor ready)';
		} else if ( entry.type === 'dom-ready' ) {
			typeClass = '';
			labelClass = '';
			label = 'DOMContentLoaded';
		} else if (
			entry.type === 'gtag-consent' &&
			entry.call === 'default'
		) {
			typeClass = 'consent-default';
			labelClass = 'consent-default';
			label = "gtag('consent', 'default', {...})";
			paramsHtml = paramsToHtml( entry.params );
		} else if ( entry.type === 'gtag-consent' && entry.call === 'update' ) {
			const lateMark = late
				? '<span class="cmplz-dbg-late-badge">LATE</span>'
				: '';
			typeClass = late ? 'late-signal' : 'consent-update';
			labelClass = late ? 'late-signal' : 'consent-update';
			label = "gtag('consent', 'update', {...})" + lateMark;
			paramsHtml = paramsToHtml( entry.params );
		} else if ( entry.type === 'gtag-js' ) {
			typeClass = '';
			labelClass = '';
			label = "gtag('js', new Date())  — tag execution start";
		} else if ( entry.type === 'gtag-config' ) {
			typeClass = '';
			labelClass = 'info';
			label = "gtag('config', '" + ( entry.tag || '?' ) + "')";
		} else if ( entry.type === 'gtag-set' ) {
			typeClass = '';
			labelClass = '';
			label =
				"gtag('set', '" +
				entry.key +
				"', " +
				JSON.stringify( entry.value ) +
				')';
		} else if ( entry.type === 'cmplz-event' ) {
			typeClass = 'cmplz-event';
			labelClass = 'cmplz-event';
			label = entry.event;
			if ( entry.detail && Object.keys( entry.detail ).length ) {
				paramsHtml = JSON.stringify( entry.detail );
			}
		} else if ( entry.type === 'datalayer-event' ) {
			typeClass = '';
			labelClass = '';
			label = "dataLayer.push({ event: '" + entry.event + "' })";
		} else {
			return '';
		}

		const timeLabel = entry.retroactive
			? '<span title="Fired before interceptor loaded">(pre-interceptor)</span>'
			: '+' + ( entry.ts || 0 ) + 'ms';

		return (
			'<div class="cmplz-dbg-tl-item ' +
			typeClass +
			( entry.retroactive ? ' cmplz-dbg-retroactive' : '' ) +
			'">' +
			'<div class="cmplz-dbg-tl-time">' +
			timeLabel +
			'</div>' +
			'<div class="cmplz-dbg-tl-label ' +
			labelClass +
			'">' +
			label +
			'</div>' +
			( paramsHtml
				? '<div class="cmplz-dbg-tl-params">' + paramsHtml + '</div>'
				: '' ) +
			'</div>'
		);
	}

	window.CmplzDebugger.renderSequence = function ( container ) {
		const tl = ( window.CmplzDebugger.timeline || [] ).slice();
		// Read lazily — defined after this module loads
		const phpCfg = window.cmplzDebugConfig || {};

		const templateName = phpCfg.templateName || 'none';
		const gcmEnabled = !! phpCfg.gcmEnabled;

		// For the GTM template, consent default lives inside the GTM container and is
		// set via GTM's async bundle — it may appear as a captured dataLayer signal
		// once GTM loads, or not at all if GTM isn't fully configured.
		const isGtmTemplate =
			templateName === 'google-tag-manager-consent-mode-template' ||
			templateName === 'google-tag-manager-consent-mode' ||
			templateName === 'sitekit-tag-manager-consent-mode-template' ||
			templateName === 'sitekit-tag-manager-consent-mode';

		// Filter to signal-relevant entries only
		const relevant = tl.filter( function ( e ) {
			return (
				[
					'page-load',
					'dom-ready',
					'gtag-consent',
					'gtag-js',
					'gtag-config',
					'gtag-set',
					'cmplz-event',
					'datalayer-event',
				].indexOf( e.type ) !== -1
			);
		} );

		const defaultEntry = tl.find( function ( e ) {
			return e.type === 'gtag-consent' && e.call === 'default';
		} );
		const updateEntry = tl.find( function ( e ) {
			return e.type === 'gtag-consent' && e.call === 'update';
		} );
		const updateIsLate = updateEntry ? isLate( updateEntry.ts, tl ) : false;

		let html = '';

		// ── Summary banner ──────────────────────────────────────────────────────
		function banner( bg, border, color, content ) {
			return (
				'<div style="background:' +
				bg +
				';border:1px solid ' +
				border +
				';border-radius:4px;' +
				'padding:8px 10px;margin-bottom:12px;color:' +
				color +
				';font-size:11px;line-height:1.6;">' +
				content +
				'</div>'
			);
		}

		if ( ! defaultEntry && isGtmTemplate && gcmEnabled ) {
			// Expected state for GTM template — not an error
			html += banner(
				'rgba(137,180,250,.08)',
				'var(--cmplz-dbg-blue)',
				'var(--cmplz-dbg-blue)',
				'<strong>GTM template active.</strong> The consent default is configured inside your GTM ' +
					'container via the Complianz GTM template tag — it is not a page-level signal and may ' +
					'not appear here. Once you interact with the banner the <code>cmplz_fire_categories</code> ' +
					'event fires and the update signal travels through <code>addConsentUpdateListener</code> ' +
					"into GTM, which then calls <code>gtag('consent', 'update')</code>."
			);
		} else if ( ! defaultEntry && ! gcmEnabled ) {
			html += banner(
				'rgba(99,99,99,.1)',
				'var(--cmplz-dbg-border)',
				'var(--cmplz-dbg-muted)',
				'GCM is not enabled in the wizard — no consent signals expected.'
			);
		} else if ( ! defaultEntry ) {
			html += banner(
				'rgba(243,139,168,.1)',
				'var(--cmplz-dbg-red)',
				'var(--cmplz-dbg-red)',
				'No GCM default signal captured. The interceptor may have loaded after the GCM template, ' +
					'or GCM is not configured. Reload the page and check again.'
			);
		} else if ( updateIsLate ) {
			html += banner(
				'rgba(243,139,168,.1)',
				'var(--cmplz-dbg-red)',
				'var(--cmplz-dbg-red)',
				"<strong>Late consent update detected.</strong> <code>gtag('consent', 'update')</code> " +
					"fired after <code>gtag('js')</code> or <code>gtag('config')</code> — the tag had " +
					'already executed in denied/cookieless mode before consent was known. ' +
					"<a class ='debugger-link' href='https://complianz.io/google-tag-gateway/?utm_source=cmplz_premium&utm_medium=debugger' target='_blank'>Read more</a>"
			);
		} else if ( updateEntry ) {
			html += banner(
				'rgba(166,227,161,.08)',
				'var(--cmplz-dbg-green)',
				'var(--cmplz-dbg-green)',
				'U+C sequence OK — consent update fired before tag execution.'
			);
		} else {
			// defaultEntry present, no update yet
			html += banner(
				'rgba(249,226,175,.08)',
				'var(--cmplz-dbg-yellow)',
				'var(--cmplz-dbg-yellow)',
				'Default signal captured. Interact with the banner to trigger the update signal.'
			);
		}

		if ( relevant.length === 0 ) {
			html +=
				'<div class="cmplz-dbg-empty">No timeline entries yet. Reload the page to record signals from the start.</div>';
			container.innerHTML = html;
			return;
		}

		// ── GTM template: note that consent update is invisible to page interceptor ─
		// GTM's Complianz tag calls GTM's internal updateConsentState sandboxed API,
		// not the page-level gtag() — so it will never appear in this timeline.
		// Show an informational note instead of a false-positive warning.
		if ( isGtmTemplate && gcmEnabled && ! updateEntry ) {
			const userAcceptFired = tl.find( function ( e ) {
				return (
					e.type === 'cmplz-event' &&
					e.event === 'cmplz_fire_categories' &&
					e.detail &&
					e.detail.categories &&
					e.detail.categories.length > 1
				);
			} );
			if ( userAcceptFired ) {
				html += banner(
					'rgba(137,180,250,.08)',
					'var(--cmplz-dbg-blue)',
					'var(--cmplz-dbg-blue)',
					"<strong>GTM consent update runs inside the GTM sandbox</strong> — it uses GTM's internal " +
						'<code>updateConsentState</code> API which is not visible to this page-level interceptor. ' +
						'To verify the update signal, use <strong>GTM Preview mode</strong> and check the ' +
						'Consent tab, or install the ' +
						'<strong>Google Tag Assistant Chrome extension</strong>.'
				);
			}
		}

		html += '<div class="cmplz-dbg-timeline">';
		relevant.forEach( function ( entry ) {
			const late =
				entry.type === 'gtag-consent' && entry.call === 'update'
					? updateIsLate
					: false;
			html += renderItem( entry, late );
		} );
		html += '</div>';

		container.innerHTML = html;
	};
} )();
