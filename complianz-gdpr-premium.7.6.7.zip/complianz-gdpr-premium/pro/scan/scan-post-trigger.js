// phpcs:disable Squiz.Commenting.FileComment
/* global cmplzScan */

function cmplzShowScanError( btn, message ) {
	const existing = btn.parentNode.querySelector( '.cmplz-scan-error' );
	if ( existing ) {
		existing.remove();
	}
	const el = document.createElement( 'span' );
	el.className = 'cmplz-scan-error';
	el.textContent = message;
	btn.parentNode.insertBefore( el, btn.nextSibling );
	setTimeout( function () {
		if ( el.parentNode ) {
			el.remove();
		}
	}, 4000 );
}

document.addEventListener( 'click', function ( e ) {
	const btn = e.target.closest( '.cmplz-scan-post-btn' );
	if ( ! btn ) {
		return;
	}

	const errorEl = btn.parentNode.querySelector( '.cmplz-scan-error' );
	if ( errorEl ) {
		errorEl.remove();
	}

	const originalText = btn.textContent;
	btn.disabled = true;
	btn.textContent = cmplzScan.scanning;

	fetch( cmplzScan.restUrl + '/scan/post', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
			'X-WP-Nonce': cmplzScan.wpNonce,
		},
		body: JSON.stringify( { post_id: parseInt( btn.dataset.postId, 10 ) } ),
	} )
		.then( function ( r ) {
			return r.json();
		} )
		.then( function ( data ) {
			if ( data.queued ) {
				const statusEl = btn.previousElementSibling;
				if (
					statusEl &&
					statusEl.classList.contains( 'cmplz-scan-status' )
				) {
					statusEl.className =
						'cmplz-scan-status cmplz-scan-status--queued';
					statusEl.textContent = cmplzScan.inProgress;
				}
			} else if ( data.error_code ) {
				const msg =
					cmplzScan.errors && cmplzScan.errors[ data.error_code ]
						? cmplzScan.errors[ data.error_code ]
						: data.error_code;
				cmplzShowScanError( btn, msg );
			}
			btn.textContent = originalText;
			btn.disabled = false;
		} )
		.catch( function () {
			btn.textContent = originalText;
			btn.disabled = false;
		} );
} );
