<?php
defined( 'ABSPATH' ) or die( 'you do not have access to this page!' );

if ( ! class_exists( 'cmplz_records_of_consent' ) ) {
	class cmplz_records_of_consent {
		private static $_this;
		function __construct() {
			if ( isset( self::$_this ) ) {
				wp_die(
					sprintf(
						'%s is a singleton class and you cannot create a second instance.',
						get_class( $this )
					)
				);
			}
			self::$_this = $this;
			add_filter( 'cmplz_do_action', array( $this, 'get_records_of_consent_data' ), 10, 3 );
		}

		static function this() {
			return self::$_this;
		}



		/**
		 * Get a list of processors
		 *
		 * @param array           $data
		 * @param string          $action
		 * @param WP_REST_Request $request
		 *
		 * @return []
		 */
		public function get_records_of_consent_data( $data, $action, $request ) {
			if ( ! cmplz_user_can_manage() ) {
				return array();
			}
			if ( $action === 'get_records_of_consent' ) {
				$data     = $request->get_params();
				$per_page = $data['per_page'] ?? 10;
				$page     = $data['page'] ?? 1;
				$search   = $data['search'] ?? false;
				$order    = $data['order'] ?? 'ASC';
				$orderby  = $data['orderBy'] ?? 'id';
				$offset   = $per_page * ( $page - 1 );
				$regions  = cmplz_get_regions( false, 'full' );
				// convert key value array to array of objects with id and label
				$regions   = array_map(
					function ( $id, $label ) {
						return (object) array(
							'value' => $id,
							'label' => $label,
						);
					},
					array_keys( $regions ),
					$regions
				);
				$regions[] = array(
					'value' => '',
					'label' => __( 'Select a region', 'complianz-gdpr' ),
				);
				$args      = array(
					'start_date' => strtotime( '-1 week' ),
					'order'      => $order,
					'orderby'    => $orderby,
					'offset'     => $offset,
					'search'     => $search,
				);
				$records   = $this->get_consent_records( $args );
				$total     = $this->get_consent_records( $args, true );
				if ( ! is_array( $records ) ) {
					$records = array();
				}
				$banner_version_cache = array();
				// convert unix timestamp to date
				// convert the array key to an 'id'
				foreach ( $records as $key => $record ) {
					$id = $record['ID'];
					unset( $record['ID'] );
					$record['id']   = $id;
					$unix           = $record['time'];
					$record['time'] = date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $unix );
					if ( empty( $record['poc_url'] ) ) {
						$file_data = $this->get_poc_for_record( $unix, $record['region'] );
						if ( $file_data ) {
							$record['poc_url'] = $file_data['url'];
						}
					}
					// make path relative
					$record['poc_url'] = str_replace( trailingslashit( cmplz_upload_url( 'snapshots' ) ), '', $record['poc_url'] );

					$banner_id = (int) $record['cookiebanner_id'];
					if ( ! isset( $banner_version_cache[ $banner_id ] ) ) {
						$banner                             = cmplz_get_cookiebanner( $banner_id );
						$banner_version_cache[ $banner_id ] = $banner ? $banner->banner_version : 0;
					}
					$record['banner_version'] = $banner_version_cache[ $banner_id ];

					$records[ $key ] = $record;
				}
				// strip key from the array
				$records = empty( $records ) ? array() : array_values( $records );
				$data    = array(
					'records'      => $records,
					'totalRecords' => $total,
					'regions'      => $regions,
					'download_url' => cmplz_upload_url( 'snapshots' ),
				);
			} elseif ( $action === 'delete_records_of_consent' ) {
				$records = $request->get_param( 'records' );
				foreach ( $records as $record ) {
					$this->delete_record( $record['id'] );
				}
			} elseif ( $action === 'get_record_of_consent_pdf_url' ) {
				$record_id = (int) $request->get_param( 'id' );
				$data      = $this->generate_record_proof_pdf( $record_id );
			} elseif ( $action === 'export_records_of_consent' ) {
				$data       = $request->get_params();
				$dateStart  = $data['startDate'] ?? false;
				$dateEnd    = $data['endDate'] ?? false;
				$statusOnly = $data['statusOnly'] ?? false;
				$data       = $this->run_export_roc_to_csv( $dateStart, $dateEnd, $statusOnly );
			}
			return $data;
		}

		/**
		 * Export all records in the current selection to a csv file
		 */
		public function run_export_roc_to_csv( $dateStart, $dateEnd, $statusOnly = false ) {
			$page_batch = 100;
			if ( ! cmplz_user_can_manage() ) {
				return array();
			}

			$offset = get_option( 'cmplz_current_poc_export_offset' ) ?: 0;
			if ( $statusOnly ) {
				$progress = get_option( 'cmplz_current_poc_export_progress' ) ?: 100;
				$total    = 1;
			} else {
				if ( $offset === 0 ) {
					// cleanup old file
					$file = $this->filepath();
					if ( file_exists( $file ) ) {
						unlink( $file );
					}
				}

				$args = array(
					'number'     => $page_batch,
					'offset'     => $offset * $page_batch,
					'start_date' => strtotime( $dateStart ),
					'end_date'   => strtotime( $dateEnd ),
				);
				++$offset;

				$pages_completed = ( $offset ) * $page_batch;
				update_option( 'cmplz_roc_export_args', $args, false );
				update_option( 'cmplz_current_poc_export_offset', $offset, false );
				$total = $this->get_consent_records( $args, true );
				if ( $total > 0 ) {
					$data       = $this->get_consent_records( $args );
					$add_header = $offset == 1;
					$this->create_csv_file( $data, $add_header );
					$progress = 100 * ( $pages_completed / $total );
					$progress = $progress > 100 ? 100 : $progress;
				} else {
					$progress = 100;
				}
				update_option( 'cmplz_current_poc_export_progress', $progress, false );
			}

			if ( $progress === 100 ) {
				delete_option( 'cmplz_current_poc_export_offset' );
				delete_option( 'cmplz_roc_export_args' );
			}
			return array(
				'progress'   => round( $progress, 0 ),
				'exportLink' => $this->fileurl(),
				'noData'     => $total == 0,
			);
		}

		/**
		 * create csv file from array
		 *
		 * @param array $data
		 * @param bool  $add_header
		 * @throws Exception
		 */
		private function create_csv_file( $data, $add_header = true ) {
			$delimiter = ',';
			$enclosure = '"';
			$escape    = '\\';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$upload_dir = cmplz_upload_dir();

			// generate random filename for storage
			if ( ! get_option( 'cmplz_roc_file_name' ) ) {
				$token = bin2hex( random_bytes( 18 ) );
				update_option( 'cmplz_roc_file_name', $token, false );
			}
			$filename = get_option( 'cmplz_roc_file_name' );

			// set the path
			$file = $upload_dir . $filename . '.csv';
			// 'a' creates file if not existing, otherwise appends.
			$csv_handle = fopen( $file, 'a' );

			// create a line with headers
			if ( $add_header ) {
				$headers = $this->parse_headers_from_array( $data );
				fputcsv( $csv_handle, $headers, $delimiter, $enclosure, $escape );
			}

			if ( is_array( $data ) ) {
				$data = array_map( array( $this, 'localize_date' ), $data );

				foreach ( $data as $line ) {
					$line = array_map( 'sanitize_text_field', $line );
					fputcsv( $csv_handle, $line, $delimiter, $enclosure, $escape );
				}
			}
			fclose( $csv_handle );
		}

		/**
		 * Get headers from an array
		 *
		 * @param array $array
		 *
		 * @return array|bool
		 */
		private function parse_headers_from_array( $array ) {
			if ( ! isset( $array[0] ) ) {
				return array();
			}
			$array                                   = $array[0];
			$array[ __( 'Date', 'complianz-gdpr' ) ] = 1;
			return array_keys( $array );
		}

		/**
		 * Get a localized date for this row
		 *
		 * @param $row
		 *
		 * @return mixed
		 */
		public function localize_date( $row ) {
			if ( isset( $row['time'] ) ) {
				$row['nice_time'] = sprintf( '%s at %s', date( str_replace( 'F', 'M', get_option( 'date_format' ) ), $row['time'] ), date( get_option( 'time_format' ), $row['time'] ) );
			}
			return $row;
		}

		/**
		 * Get a filepath
		 *
		 * @return string
		 */
		private function filepath() {
			return untrailingslashit( cmplz_upload_dir() . get_option( 'cmplz_roc_file_name' ) . '.csv' );
		}

		/**
		 * Get a file URL
		 *
		 * @return string
		 */
		private function fileurl() {
			if ( file_exists( $this->filepath() ) ) {
				return untrailingslashit( cmplz_upload_url() . get_option( 'cmplz_roc_file_name' ) . '.csv' );
			}
			return '';
		}

		/**
		 * The last pdf in time before this record is the one belonging to this record.
		 * The next pdf in time after the poc belongs to the next record
		 * If there are no other records between these two pdf's in time, we can delete the pdf.
		 *
		 * @param int $id
		 */
		public function delete_record( $id ) {
			global $wpdb;
			$delete_file = true;
			$record_id   = (int) $id;
			$record      = $wpdb->get_row( "select * from {$wpdb->prefix}cmplz_statistics where ID = $record_id" );
			if ( $record ) {
				$poc_url = $record->poc_url;
				if ( ! empty( $poc_url ) ) {
					// get count of other records with this url
					$other_records_count = $wpdb->get_var( $wpdb->prepare( "select count(*) from {$wpdb->prefix}cmplz_statistics where ID != %s AND poc_url = %s", $record_id, $poc_url ) );
					if ( $other_records_count > 0 ) {
						$delete_file = false;
					}

					if ( $delete_file ) {
						$url       = cmplz_upload_url( 'snapshots' );
						$file_name = str_replace( $url, '', $poc_url );
						COMPLIANZ::$proof_of_consent->delete_snapshot( $file_name );
					}
				}

				$wpdb->delete(
					$wpdb->prefix . 'cmplz_statistics',
					array( 'ID' => $record_id )
				);
			}
		}

		/**
		 * Get poc pdf file belonging to this record
		 *
		 * @param int    $record_time_stamp
		 * @param string $region
		 * @return false|array
		 */
		public function get_poc_for_record( $record_time_stamp, $region ) {
			if ( empty( $region ) ) {
				$region = COMPLIANZ::$company->get_default_region();
			}
			$args = array(
				'number'     => 1,
				'start_date' => 0,
				'end_date'   => $record_time_stamp,
				'region'     => $region,
			);

			$files = COMPLIANZ::$proof_of_consent->get_cookie_snapshot_list( $args );
			if ( empty( $files ) ) {
				// try again, with a larger range
				$args['end_date'] = $record_time_stamp + 24 * HOUR_IN_SECONDS;
				$files            = COMPLIANZ::$proof_of_consent->get_cookie_snapshot_list( $args );
				if ( empty( $files ) ) {
					return false;
				}
			}

			$file = reset( $files );
			if ( $file ) {
				$upload_dir  = cmplz_upload_dir();
				$upload_url  = cmplz_upload_url();
				$file['url'] = str_replace( $upload_dir, $upload_url, $file['path'] );
				return $file;
			}
			return false;
		}

		/**
		 * @param int    $record_time_stamp
		 * @param string $region
		 *
		 * @return false|array
		 */
		public function get_next_poc( $record_time_stamp, $region ) {
			if ( empty( $region ) ) {
				$region = COMPLIANZ::$company->get_default_region();
			}
			$args = array(
				'number'     => 1,
				'order'      => 'ASC',
				'start_date' => $record_time_stamp,
				'region'     => $region,
			);

			$files = COMPLIANZ::$proof_of_consent->get_cookie_snapshot_list( $args );
			if ( isset( $files[0] ) ) {
				$file        = $files[0];
				$upload_dir  = cmplz_upload_dir();
				$upload_url  = cmplz_upload_url();
				$file['url'] = str_replace( $upload_dir, $upload_url, $file['path'] );
				return $file;
			}

			return false;
		}

		/**
		 * Add the latest snapshot file to all users who haven't been updated since the last cookie policy snapshot generation was scheduled.
		 *
		 * @param int|bool $generation_scheduled_time //time at which moment the new pdf was scheduled to be generated in the next 24 hours
		 */
		public function update_users_without_snapshot( $generation_scheduled_time ) {
			// if it's forced, don't update
			if ( ! $generation_scheduled_time ) {
				return;
			}
			$generation_scheduled_time = (int) $generation_scheduled_time;
			$regions                   = cmplz_get_regions();
			foreach ( $regions as $region ) {
				// get last poc pdf file, counting back from now.
				$file = COMPLIANZ::$records_of_consent->get_poc_for_record( time(), $region );
				// file has path, url, file, time
				if ( $file ) {
					// for all users without a file since generation update time, set this file
					global $wpdb;
					$sql = $wpdb->prepare( "UPDATE {$wpdb->prefix}cmplz_statistics SET poc_url = %s where poc_url='' AND region = %s AND time>=%s", $file['url'], $region, $generation_scheduled_time );
					$wpdb->query( $sql );
				}
			}
		}

		/**
		 * @param array $args
		 * @param bool  $count
		 *
		 * @return array|false
		 */
		public function get_consent_records( $args = array(), $count = false ) {
			$defaults = array(
				'number'     => false,
				'offset'     => 0,
				'order'      => 'DESC',
				'orderby'    => 'time',
				'start_date' => 0,
				'end_date'   => false,
				'search'     => false,
			);

			$args = wp_parse_args( array_filter( $args ), $defaults );
			global $wpdb;
			// add 24 hours to end_date, because it's the start of that day.
			if ( $args['end_date'] ) {
				$args['end_date'] = $args['end_date'] + 24 * HOUR_IN_SECONDS;
			}
			$where  = " where time> '0' ";
			$where .= $args['end_date'] ? $wpdb->prepare( ' AND time> %s AND time < %s', $args['start_date'], $args['end_date'] ) : '';
			$where .= $args['search'] ? $wpdb->prepare( ' AND (ID=%d OR region=%s OR consenttype=%s)', $args['search'], $args['search'], $args['search'] ) : '';
			$total  = 0;
			if ( $count ) {
				$total = $wpdb->get_var( "SELECT count(*) from {$wpdb->prefix}cmplz_statistics $where" );
			}
			if ( ! $count ) {
				$limit     = (int) $args['number'];
				$orderby   = sanitize_title( $args['orderby'] );
				$order     = sanitize_title( $args['order'] );
				$limit     = $limit > 0 ? $limit : 10;
				$offset    = (int) $args['offset'];
				$limit_sql = "limit $limit offset $offset";
				$sql       = "SELECT * from {$wpdb->prefix}cmplz_statistics $where ORDER BY $orderby $order " . $limit_sql;
				$records   = $wpdb->get_results( $sql );
				$records   = json_decode( json_encode( $records ), true );
				if ( empty( $records ) ) {
					return false;
				}

				return $records;
			}

			return $total;
		}

		/**
		 * Generate a per-user proof-of-consent PDF for a single consent record,
		 * using the same format as the shared snapshot (policy + settings) with
		 * the consent record data added as an extra section.
		 *
		 * @param int $record_id
		 * @return array
		 */
		public function generate_record_proof_pdf( int $record_id ): array {
			if ( ! cmplz_user_can_manage() ) {
				return array( 'success' => false );
			}

			global $wpdb;
			$record = $wpdb->get_row(
				$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cmplz_statistics WHERE ID = %d", $record_id ),
				ARRAY_A
			);

			if ( ! $record ) {
				return array( 'success' => false );
			}

			$region    = ! empty( $record['region'] ) ? $record['region'] : COMPLIANZ::$company->get_default_region();
			$banner_id = (int) ( $record['cookiebanner_id'] ?: cmplz_get_default_banner_id() );
			$banner    = cmplz_get_cookiebanner( $banner_id );
			$settings  = $banner ? array_merge( $banner->get_front_end_settings(), $banner->get_html_settings() ) : array();

			// -- Intro: same text as shared snapshot + consent record section appended --
			$intro = '<h1>' . __( 'Proof of Consent', 'complianz-gdpr' ) . '</h1>'
					. '<p>' . cmplz_sprintf(
						__( 'This document was generated to show efforts made to comply with privacy legislation. This document will contain the Cookie Policy and the cookie consent settings to proof consent for the time and region specified below. For more information about this document, please go to %1$shttps://complianz.io/consent%2$s.', 'complianz-gdpr' ),
						'<a target="_blank" href="https://complianz.io/consent">',
						'</a>'
					) . '</p>'
					. $this->build_consent_record_section( $record );

			// -- Settings section: same format as shared snapshot --
			$settings_html = $this->build_settings_section( $settings );

			// -- Full document HTML using the same template as generate_pdf --
			$load_css      = cmplz_get_option( 'use_document_css' );
			$css           = $load_css ? file_get_contents( CMPLZ_PATH . 'assets/css/document.css' ) : '';
			$document_html = $intro
							. COMPLIANZ::$document->get_document_html( 'cookie-statement', $region )
							. $settings_html;

			$document_html = apply_filters( 'cmplz_cookie_policy_snapshot_html', $document_html, true );
			$document_html = str_replace( 'cmplz-service-hidden', '', $document_html );
			$document_html = preg_replace( '/<input type="checkbox".*?>/', '', $document_html );
			$document_html = preg_replace( '/<span class="cmplz-fmail-domain">.*?<\/span>/', '', $document_html );

			$html = '<style>
				' . $css . '
				#cmplz-datarequest-form, #cmplz-manage-consent-container-nojavascript, #cmplz-tcf-vendor-container { display:none; }
				body { font-family: sans; margin-top:100px; color:#000; }
				h2 { font-size:12pt; }
				h3 { font-size:12pt; }
				h4 { font-size:10pt; font-weight:bold; }
				.center { text-align:center; }
				#cmplz-tcf-buttons-template, #cmplz-tcf-vendor-template, #cmplz-tcf-type-template { display:none !important; }
			</style>
			<body id="cmplz-document">' . $document_html . '</body>';

			// -- mPDF setup: identical to generate_pdf --
			require_once CMPLZ_PATH . '/assets/vendor/autoload.php';
			$save_dir  = cmplz_upload_dir( 'poc-records' );
			$save_url  = cmplz_upload_url( 'poc-records' );
			$temp_dir  = cmplz_upload_dir( 'snapshots/tmp' );
			$mpdf_args = apply_filters(
				'cmplz_mpdf_args',
				array(
					'setAutoTopMargin'  => 'stretch',
					'autoMarginPadding' => 5,
					'margin_left'       => 20,
					'margin_right'      => 20,
					'margin_top'        => 30,
					'margin_bottom'     => 30,
					'margin_header'     => 30,
					'margin_footer'     => 10,
					'tempDir'           => $temp_dir,
				)
			);

			$mpdf = new Mpdf\Mpdf( $mpdf_args );
			$mpdf->SetDisplayMode( 'fullpage' );
			$mpdf->SetTitle( __( 'Proof of Consent', 'complianz-gdpr' ) );
			$date        = date_i18n( get_option( 'date_format' ), time() );
			$footer_text = get_bloginfo( 'name' ) . ' ' . __( 'Proof of Consent', 'complianz-gdpr' ) . ' ' . $date;
			$mpdf->SetFooter( $footer_text );
			$mpdf->WriteHTML( $html );

			$filename = sanitize_file_name( get_bloginfo( 'name' ) . '-' . $region . '-proof-of-consent-record-' . $record_id . '.pdf' );
			$mpdf->Output( $save_dir . $filename, 'F' );

			return array( 'url' => trailingslashit( $save_url ) . $filename );
		}

		/**
		 * Build the consent record section in the same <ul><li>key => value</li></ul> style
		 * as the settings section used in the shared snapshot.
		 *
		 * @param array $record Row from cmplz_statistics.
		 * @return string HTML
		 */
		private function build_consent_record_section( array $record ): string {
			$datetime = date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $record['time'] );

			$category_labels = array(
				'functional'   => __( 'Functional', 'complianz-gdpr' ),
				'preferences'  => __( 'Preferences', 'complianz-gdpr' ),
				'statistics'   => __( 'Statistics', 'complianz-gdpr' ),
				'marketing'    => __( 'Marketing', 'complianz-gdpr' ),
				'do_not_track' => __( 'DNT/GPC', 'complianz-gdpr' ),
				'no_choice'    => __( 'No Choice', 'complianz-gdpr' ),
				'no_warning'   => __( 'No Warning', 'complianz-gdpr' ),
			);
			$accepted        = array();
			foreach ( $category_labels as $key => $label ) {
				if ( isset( $record[ $key ] ) && (int) $record[ $key ] === 1 ) {
					$accepted[] = $label;
				}
			}

			$rows = array(
				__( 'User ID (cmplz_ID)', 'complianz-gdpr' ) => esc_html( $record['ID'] ),
				__( 'Date & Time', 'complianz-gdpr' )  => esc_html( $datetime ),
				__( 'Consent Type', 'complianz-gdpr' ) => esc_html( $record['consenttype'] ),
				__( 'Region', 'complianz-gdpr' )       => esc_html( $record['region'] ),
				__( 'IP Address', 'complianz-gdpr' )   => esc_html( $record['ip'] ),
				__( 'Categories Accepted', 'complianz-gdpr' ) => esc_html( $accepted ? implode( ', ', $accepted ) : __( 'None', 'complianz-gdpr' ) ),
				__( 'Services Consented To', 'complianz-gdpr' ) => esc_html( $record['services'] ?: '—' ),
			);

			$rows_html = '';
			foreach ( $rows as $key => $value ) {
				$rows_html .= '<tr><td style="width:40%;padding:4px 8px;border:1px solid #ccc;font-weight:bold;">' . esc_html( $key ) . '</td>'
							. '<td style="padding:4px 8px;border:1px solid #ccc;">' . esc_html( $value ) . '</td></tr>';
			}

			return '<div><h1>' . __( 'Consent Record', 'complianz-gdpr' ) . '</h1>'
				. '<table style="width:100%;border-collapse:collapse;font-size:10pt;">' . $rows_html . '</table></div>';
		}

		/**
		 * Build the cookie consent settings section in the same format as the shared snapshot.
		 *
		 * @param array $settings Banner front-end + html settings.
		 * @return string HTML
		 */
		private function build_settings_section( array $settings ): string {
			$skip = array(
				'use_custom_cookie_css',
				'logo',
				'custom_css_amp',
				'static',
				'set_cookies',
				'position',
				'a_b_testing',
				'a_b_testing_buttons',
				'title',
				'privacy_link',
				'nonce',
				'url',
				'current_policy_id',
				'type',
				'layout',
				'use_custom_css',
				'custom_css',
				'banner_width',
				'colorpalette_background',
				'colorpalette_text',
				'colorpalette_toggles',
				'colorpalette_border_radius',
				'border_width',
				'store_consent',
				'cookie_domain',
				'set_cookies_on_root',
				'placeholdertext',
				'css_file',
				'page_links',
				'tm_categories',
				'cookie_path',
				'colorpalette_button_accept',
				'colorpalette_button_deny',
				'colorpalette_button_settings',
				'buttons_border_radius',
				'prefix',
				'user_banner_id',
				'locale',
			);

			if ( isset( $settings['categories'] ) && is_array( $settings['categories'] ) ) {
				$settings['categories'] = implode( ', ', $settings['categories'] );
			}
			unset( $settings['readmore_url'] );
			$settings = apply_filters( 'cmplz_cookie_policy_snapshot_settings', $settings );

			$rows_html = '';
			foreach ( $settings as $key => $value ) {
				if ( in_array( $key, $skip, true ) ) {
					continue;
				}
				if ( is_array( $value ) ) {
					$value = implode( ', ', array_filter( array_values( $value ), 'is_string' ) );
				}
				$rows_html .= '<tr><td style="width:40%;padding:4px 8px;border:1px solid #ccc;font-weight:bold;">' . esc_html( $key ) . '</td>'
							. '<td style="padding:4px 8px;border:1px solid #ccc;">' . esc_html( (string) $value ) . '</td></tr>';
			}

			return '<div><h1>' . __( 'Cookie consent settings', 'complianz-gdpr' ) . '</h1>'
				. '<table style="width:100%;border-collapse:collapse;font-size:10pt;">' . $rows_html . '</table></div>';
		}
	}
} //class closure
