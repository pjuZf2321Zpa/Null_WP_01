
<div class="cmplz-categories cmplz-tcf">

	<div class="cmplz-category cmplz-statistics">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php esc_html_e( 'Statistics', 'complianz-gdpr' ); ?></div>
			<div class='cmplz-always-active'></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

	<div class="cmplz-category cmplz-marketing">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php esc_html_e( 'Marketing', 'complianz-gdpr' ); ?></div>
			<div class='cmplz-always-active'></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

	<div class="cmplz-category cmplz-features">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php esc_html_e( 'Features', 'complianz-gdpr' ); ?></div>
			<div class='cmplz-always-active'><?php esc_html_e( 'Always active', 'complianz-gdpr' ); ?></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

	<div class="cmplz-category cmplz-specialfeatures">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php esc_html_e( 'Special features', 'complianz-gdpr' ); ?></div>
			<div class='cmplz-always-active'></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

	<div class="cmplz-category cmplz-specialpurposes">
		<div class="cmplz-category-header">
			<div class="cmplz-title"><?php esc_html_e( 'Special purposes', 'complianz-gdpr' ); ?></div>
			<div class='cmplz-always-active'><?php esc_html_e( 'Always active', 'complianz-gdpr' ); ?></div>
			<p class="cmplz-description"></p>
		</div>
	</div>

</div>
