<div class="cmplz-tcf-category-expl">
	<p><?php esc_html_e( 'On our site we use the following purposes:', 'complianz-gdpr' ); ?></p>

	<div class="cmplz-dropdown">
		<div><h4 class="cmplz-tcf-expl-header statistics-purposes "><?php esc_html_e( 'Statistics', 'complianz-gdpr' ); ?></h4></div>
		<p class="cmplz-tcf-expl-desc statistics-purposes "></p>
	</div>

	<div class="cmplz-dropdown">
		<div><h4 class="cmplz-tcf-expl-header marketing-purposes "><?php esc_html_e( 'Marketing', 'complianz-gdpr' ); ?></h4></div>
		<p class="cmplz-tcf-expl-desc marketing-purposes "></p>
	</div>

	<div class="cmplz-dropdown">
		<div>
			<h4 class="cmplz-tcf-expl-header features "><?php esc_html_e( 'Features', 'complianz-gdpr' ); ?></h4>
			<p class="cmplz-tcf-active"><?php esc_html_e( 'Always active', 'complianz-gdpr' ); ?></p>
		</div>
		<p class="cmplz-tcf-expl-desc features "></p>
	</div>

	<div class="cmplz-dropdown">
		<div>
			<h4 class="cmplz-tcf-expl-header specialFeatures "><?php esc_html_e( 'Special features', 'complianz-gdpr' ); ?></h4>
		</div>
		<p class="cmplz-tcf-expl-desc specialFeatures "></p>
	</div>

	<div class="cmplz-dropdown">
		<div>
			<h4 class="cmplz-tcf-expl-header specialPurposes "><?php esc_html_e( 'Special purposes', 'complianz-gdpr' ); ?></h4>
			<p class="cmplz-tcf-active"><?php esc_html_e( 'Always active', 'complianz-gdpr' ); ?></p>
		</div>
		<p class="cmplz-tcf-expl-desc specialPurposes "></p>
	</div>
	<a class="cmplz-btn cmplz-manage-settings cookie-statement tcf" role="button" href="{url}#cmplz-manage-consent-container"><?php esc_html_e( 'Manage vendors', 'complianz-gdpr' ); ?></a>
	<a class="cmplz-tcf-purposes-readmore" target="_blank" rel="noopener noreferrer nofollow" href="https://cookiedatabase.org/tcf/purposes" aria-label="<?php esc_attr_e( 'Read more about TCF purposes on Cookie Database', 'complianz-gdpr' ); ?>"><?php esc_html_e( 'Read more about these purposes', 'complianz-gdpr' ); ?></a>
</div>
