<?php
defined( 'ABSPATH' ) || die( 'you do not have access to this page!' );

/**
 * The TCF language codes used for the vendor list purposes translation files.
 *
 * @return array
 */
function cmplz_tcf_languages(): array {
	return array( 'sq', 'gl', 'eu', 'bs', 'ar', 'bg', 'ca', 'cs', 'cy', 'da', 'de', 'el', 'en', 'es', 'et', 'fi', 'fr', 'he', 'hi', 'hr', 'hu', 'id', 'is', 'it', 'ja', 'ka', 'ko', 'lt', 'lv', 'mk', 'ms', 'mt', 'nl', 'no', 'pl', 'pt-br', 'pt-pt', 'ro', 'ru', 'sk', 'sl', 'sr-cyrl', 'sr-latn', 'sv', 'sw', 'th', 'tl', 'tr', 'uk', 'vi', 'zh', 'zh-hant' );
}
