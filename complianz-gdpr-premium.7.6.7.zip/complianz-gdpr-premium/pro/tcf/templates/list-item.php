<div class="cmplz-tcf-{type}-container cmplz-tcf-checkbox-container cmplz-tcf-list-item">
	{type_name} | <?php /* translators: %s: number of vendors */ echo esc_html( sprintf( __( 'Used by %s vendors', 'complianz-gdpr' ), '{type_count}' ) ); ?><a href="#" class="cmplz-tcf-toggle cmplz-tcf-rm"><span class="screen-reader-text"><?php /* translators: %s: feature or purpose name */ echo esc_html( sprintf( __( 'Show details for %s', 'complianz-gdpr' ), '{type_name}' ) ); ?></span></a>
	<div id="cmplz-tcf-{type}-{type_id}-desc" class="cmplz-tcf-type-description">
		<div class="cmplz-tcf-type-desc__text">{type_description}</div>
		<div class="cmplz-tcf-type-desc__example-title"><?php esc_html_e( 'Example', 'complianz-gdpr' ); ?></div>
		<div class="cmplz-tcf-type-desc__example">{type_example}</div>
	</div>
</div>
