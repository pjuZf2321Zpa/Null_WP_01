<?php // phpcs:ignore Squiz.Commenting.FileComment.Missing
defined( 'ABSPATH' ) || die( 'you do not have access to this page!' );
require_once __DIR__ . '/tcf-languages.php';
/**
 * Vendorlist updates from:
 * https://github.com/InteractiveAdvertisingBureau/GDPR-Transparency-and-Consent-Framework/blob/master/TCFv2/IAB%20Tech%20Lab%20-%20Consent%20string%20and%20vendor%20list%20formats%20v2.md#the-global-vendor-list
 * https://vendor-list.consensu.org/v2/vendor-list.json
 * Translations: https://register.consensu.org/Translation
 *
 * CCPA vendorlist:
 * https://tools.iabtechlab.com/login?returnUrl=%2Flspa
 */

/**
 * Drop in for TCF integration
 */
$debug = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? time() : '';

/**
 * Conditionally initialize
 */
add_action( 'plugins_loaded', 'cmplz_tcf_admin_init', 10 );
add_action( 'cmplz_before_save_options', 'cmplz_tcf_change_settings', 10, 5 );
add_filter( 'cmplz_banner_fields', 'cmplz_add_tcf_fields', 10 );
add_filter( 'cmplz_fields', 'cmplz_adjust_fields_for_tcf', 1000 );
add_action( 'cmplz_every_week_hook', 'cmplz_update_json_files' );
add_action( 'admin_init', 'cmplz_tcf_reset_cache' );


function cmplz_tcf_reset_cache() {
	// allow cache override.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Cache override parameter, no sensitive data processed
	if ( isset( $_GET['cmplz_nocache'] ) ) {
		delete_option( 'cmplz_vendorlist_downloaded_once' );
		delete_option( 'cmplz_vendorlist_permission_error' );
	}
}

/**
 * Check if there is a known write permission error for the vendor list upload directory.
 *
 * @return bool
 */
function cmplz_tcf_has_permission_error(): bool {
	return (bool) get_option( 'cmplz_vendorlist_permission_error', false );
}


function cmplz_tcf_admin_init() {
	$tcf_active = cmplz_iab_is_enabled();

	cmplz_tcf_handle_license_state_transition( $tcf_active );

	if ( $tcf_active ) {
		cmplz_tcf_register_admin_filters();
	}
}

/**
 * Detect transitions in TCF license state (valid↔invalid) and
 * regenerate banner cache when a change is found.
 *
 * @param bool $current Whether TCF is currently active.
 */
function cmplz_tcf_handle_license_state_transition( bool $current ) {
	$previous = get_option( 'cmplz_tcf_license_active', null );

	if ( null === $previous ) {
		// First run: record current state without triggering a resave.
		update_option( 'cmplz_tcf_license_active', $current, false );
		return;
	}

	if ( (bool) $previous !== $current ) {
		update_option( 'cmplz_tcf_license_active', $current, false );
		cmplz_resave_all_banners();
	}
}

/**
 * Register admin-only filters that require an active TCF license.
 */
function cmplz_tcf_register_admin_filters() {
	add_filter( 'cmplz_cookie_policy_snapshot_html', 'cmplz_tcf_adjust_cookie_policy_snapshot_html' );
	add_filter( 'cmplz_warning_types', 'cmplz_tcf_warnings_types' );
	add_filter( 'auto_update_plugin', 'cmplz_tcf_override_auto_updates', 100, 2 );
}

/**
 * If TCF is enabled, force auto updates to on for Complianz itself.
 *
 * @param mixed  $update Whether to update the plugin, as decided by WordPress.
 * @param object $item   The update offer for the plugin being evaluated.
 *
 * @return mixed
 */
function cmplz_tcf_override_auto_updates( $update, $item ) {
	// Skip if debug enabled.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		return $update;
	}

	if ( is_multisite() ) {
		$option = get_site_option( 'auto_update_plugins' );
	} else {
		$option = get_option( 'auto_update_plugins' );
	}

	if ( ! is_array( $option ) ) {
		$option = array();
	}

	if ( isset( $item->slug ) && strpos( $item->slug, 'complianz-gpdr-premium' ) !== false && ! in_array( CMPLZ_PLUGIN, $option, true ) ) {
		$option[] = CMPLZ_PLUGIN;

		if ( is_multisite() ) {
			update_site_option( 'auto_update_plugins', $option );
		} else {
			update_option( 'auto_update_plugins', $option );
		}
	}

	return $update;
}

/**
 * Check if the cmp files are missing
 *
 * @return bool
 */
function cmplz_tcf_cmp_files_missing() {
	$upload_dir = cmplz_upload_dir( 'cmp/vendorlist/' );
	return ! file_exists( $upload_dir . 'vendor-list.json' );
}
/**
 * Add TCF-specific warning types.
 *
 * @param array $warnings
 * @return array
 */
function cmplz_tcf_warnings_types( $warnings ) {
	$warnings += array(
		'cmp-file-error' => array(
			'plus_one'           => true,
			'warning_condition'  => 'NOT get_value_uses_ad_cookies_personalized==no',
			'success_conditions' => array(
				'NOT cmplz_tcf_cmp_files_missing',
			),
			'dismissible'        => false,
			'urgent'             => cmplz_tcf_has_permission_error() ? __(
				'The folder wp-content/uploads/complianz/cmp/vendorlist is not writable, so the TCF vendor list files cannot be saved. Please fix the folder permissions to allow the required files to be stored.',
				'complianz-gdpr'
			) : __(
				'The CMP vendorlist files for TCF are not downloaded to, or reachable in the uploads folder yet. If you continue to see this message, contact support to update the files manually.',
				'complianz-gdpr'
			),
			'url'                => cmplz_tcf_has_permission_error() ? 'https://complianz.io/tcf-vendor-list-not-downloading-fix-folder-permission-errors' : '',
		),
		'tcf-22'         => array(
			'plus_one'          => true,
			'warning_condition' => 'cmplz_upgraded_to_current_version',
			'dismissible'       => true,
			'open'              => __( 'This update includes TCF V2.2, and is certified by Google for upcoming guidelines.', 'complianz-gdpr' ),
			'url'               => 'https://complianz.io/new-iab-tcf-requirements-and-google-cmp-certification/',
		),
	// 'tcf-framework-option' => array(
	// 'plus_one'           => true,
	// 'warning_condition' => 'get_option_cmplz_upgraded_tcf_settings',
	// 'dismissible'        => true,
	// 'open'               => cmplz_sprintf( __( "You have enabled personalized ads, but not enabled an advertising framework. We recommend enabling TCF to comply with %supcoming guidelines%s.", 'complianz-gdpr' ), '<a href="https://complianz.io/new-iab-tcf-requirements-and-google-cmp-certification/" target="_blank">', '</a>'),
	// 'url'                => admin_url('admin.php?page=complianz#wizard/services'),
	// ),
	);

	if ( is_multisite() ) {
		$auto_updates = get_site_option( 'auto_update_plugins' );
	} else {
		$auto_updates = get_option( 'auto_update_plugins' );
	}

	if ( ! is_array( $auto_updates ) || ! in_array( CMPLZ_PLUGIN, $auto_updates, true ) ) {
		$warnings += array(
			'auto-updates-not-enabled1' => array(
				'plus_one'          => true,
				'warning_condition' => '_true_',
				'urgent'            => __( 'Please enable auto updates for Complianz. This is mandatory when TCF is active, to be able to quickly adapt to new requirements by the IAB.', 'complianz-gdpr' ),
				'dismissible'       => false,
				'url'               => 'https://complianz.io/about-auto-updates/',
			),
		);
	}

	return $warnings;
}

/**
 * Read the vendorListVersion from a local TCF vendor list / purposes JSON file.
 *
 * @param string $filename Absolute path to the JSON file.
 *
 * @return int The vendorListVersion, or 0 if the file is missing, unreadable or invalid.
 */
function cmplz_tcf_get_local_vendorlist_version( string $filename ): int {
	if ( ! file_exists( $filename ) ) {
		return 0;
	}

	global $wp_filesystem;
	if ( ! $wp_filesystem ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		WP_Filesystem();
	}

	$contents = $wp_filesystem->get_contents( $filename );
	if ( empty( $contents ) ) {
		return 0;
	}

	$data = json_decode( $contents );
	if ( ! is_object( $data ) || ! isset( $data->vendorListVersion ) ) {
		return 0;
	}

	return (int) $data->vendorListVersion;
}

/**
 * Clear the cached TCF purposes/features admin name transients, for all locales.
 *
 * @return void
 */
function cmplz_tcf_clear_purpose_transients() {
	$locales    = cmplz_tcf_languages();
	$fieldnames = array( 'purposes', 'specialpurposes', 'features', 'specialfeatures' );
	// Legacy camelCase property names that used to leak into the transient key. Clean those up as well.
	$legacy_fieldnames = array( 'specialFeatures', 'specialPurposes' );

	foreach ( $locales as $locale ) {
		foreach ( $fieldnames as $fieldname ) {
			delete_transient( 'cmplz_tcf_' . $locale . '_' . $fieldname );
		}
		foreach ( $legacy_fieldnames as $fieldname ) {
			delete_transient( 'cmplz_tcf_' . $locale . '_' . $fieldname );
		}
	}
}

/**
 * On activation set some new settings in cookiebanner
 */
function cmplz_update_json_files( $attempt = 1 ) {

	// Don't try again if it was executed recently.
	if ( get_option( 'cmplz_vendorlist_downloaded_once' ) > strtotime( '-1 week' ) ) {
		return;
	}

	// don't update on crons when not enabled.
	if ( wp_doing_cron() && ! cmplz_iab_is_enabled() ) {
		return;
	}

	if ( get_transient( 'cmplz_update_jsons_active' ) ) {
		return;
	}

	set_transient( 'cmplz_update_jsons_active', true, 4 * MINUTE_IN_SECONDS );
	$cmplzExistingLanguages = cmplz_tcf_languages();
	$srcUrl                 = 'https://cookiedatabase.org/cmp/vendorlist/';
	cmplz_download_json_to_site( $srcUrl . 'additional-vendor-information-list.json' );
	cmplz_download_json_to_site( $srcUrl . 'lspa.json' );

	$srcUrl .= 'v3/';
	cmplz_download_json_to_site( $srcUrl . 'vendor-list.json' );
	// Retry if file is still missing after download attempt.
	if ( cmplz_tcf_cmp_files_missing() && $attempt <= 2 ) {
		++$attempt;
		delete_transient( 'cmplz_update_jsons_active' );
		cmplz_update_json_files( $attempt );
		return;
	}
	cmplz_download_json_to_site( 'https://storage.googleapis.com/tcfac/additional-consent-providers.csv' );

	$consensuUrl         = 'https://vendor-list.consensu.org/v3/';
	$upload_dir          = cmplz_upload_dir( 'cmp/vendorlist' );
	$vendor_list_version = cmplz_tcf_get_local_vendorlist_version( $upload_dir . 'vendor-list.json' );
	foreach ( $cmplzExistingLanguages as $lang ) {
		$filename   = $upload_dir . "purposes-$lang.json";
		$downloaded = cmplz_download_json_to_site( $srcUrl . "purposes-$lang.json" );

		// Fall back to the IAB source if cookiedatabase.org doesn't have the file, or serves one that
		// is missing, unreadable, or lags behind our local vendor-list.json.
		if ( ! $downloaded || cmplz_tcf_get_local_vendorlist_version( $filename ) < $vendor_list_version ) {
			cmplz_download_json_to_site( $consensuUrl . "purposes-$lang.json" );
		}
	}

	// These language files are never requested (pt maps to pt-pt, sr maps to sr-cyrl), remove them if present.
	foreach ( array( 'pt', 'sr' ) as $orphan_lang ) {
		$orphan_file = $upload_dir . "purposes-$orphan_lang.json";
		if ( file_exists( $orphan_file ) ) {
			wp_delete_file( $orphan_file );
		}
	}

	update_option( 'cmplz_vendorlist_downloaded_once', time(), false );
	delete_transient( 'cmplz_update_jsons_active' );
	cmplz_tcf_clear_purpose_transients();
}

/**
 * Download a json file to this website
 *
 * @param string $src
 *
 * @return bool True if the file was downloaded and copied into place, false otherwise.
 *
 * @since 5.2.3
 */
function cmplz_download_json_to_site( string $src ): bool {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	$upload_dir = cmplz_upload_dir( 'cmp/vendorlist' );
	$success    = false;

	if ( ! is_dir( $upload_dir ) || ! is_writable( $upload_dir ) ) {
		update_option( 'cmplz_vendorlist_permission_error', true, false );
		return false;
	}

	// Download file.
	$tmpfile = download_url( $src, $timeout = 25 );
	$file    = $upload_dir . basename( $src );

	// Check for errors.
	if ( ! is_wp_error( $tmpfile ) ) {
		// Copy to a temp file in the same directory, then rename over the target, so visitors never see a missing or partial file.
		$staging = $file . '.tmp-' . wp_generate_password( 6, false );
		if ( copy( $tmpfile, $staging ) && rename( $staging, $file ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			delete_option( 'cmplz_vendorlist_permission_error' );
			$success = true;
		} else {
			if ( file_exists( $staging ) ) {
				wp_delete_file( $staging );
			}
			update_option( 'cmplz_vendorlist_permission_error', true, false );
		}
	}

	if ( is_string( $tmpfile ) && file_exists( $tmpfile ) ) {
		wp_delete_file( $tmpfile );
	}

	return $success;
}

function cmplz_tcf_set_default( $value, $fieldname, $field ) {

	if ( 'tcf_purposes' === $fieldname ) {
		$value = cmplz_tcf_get( 'purposes', true );
	}

	if ( 'tcf_specialpurposes' === $fieldname ) {
		$value = cmplz_tcf_get( 'specialpurposes', true );
	}

	if ( 'tcf_features' === $fieldname ) {
		$value = cmplz_tcf_get( 'features', true );
	}

	return $value;
}

/**
 * On activation of TCF, do some initializiation
 *
 * @return array
 */
function cmplz_tcf_change_settings( $options = array(), $field_id = false, $field_value = false, $prev_value = false, $type = false ) {
	if ( ! cmplz_admin_logged_in() ) {
		return $options;
	}

	// Should run before init vendorlist, otherwise the jsons won't download.
	if ( ( $field_value !== $prev_value ) &&
		( 'uses_ad_cookies_personalized' === $field_id ) &&
		( 'yes' === $field_value || 'tcf' === $field_value ) ) {
		// If this setting has just been enabled, re-download the jsons.
		delete_option( 'cmplz_vendorlist_downloaded_once' );
		cmplz_update_json_files();
	}

	if ( 'uses_ad_cookies' === $field_id ) {
		// always init in the back-end, even when iab not enabled.
		cmplz_update_json_files();
	}

	if ( $field_value === $prev_value ) {
		return $options;
	}

	if ( 'uses_ad_cookies_personalized' === $field_id && ( 'yes' === $field_value || 'tcf' === $field_value ) ) {
		// Set the color scheme.
		$color_schemes = cmplz_banner_color_schemes();
		$color_scheme  = $color_schemes['tcf'];

		cmplz_check_minimum_one_banner();
		$banners = cmplz_get_cookiebanners();
		if ( $banners ) {
			foreach ( $banners as $banner_item ) {
				$banner                         = cmplz_get_cookiebanner( $banner_item->ID );
				$banner->soft_cookiewall        = false;
				$banner->banner_width           = '600';
				$banner->use_box_shadow         = true;
				$banner->position               = 'center';
				$banner->manage_consent_options = 'show-everywhere';
				foreach ( $color_scheme as $fieldname => $value ) {
					$banner->{$fieldname} = $value;
				}
				$banner->view_preferences = __( 'Manage options', 'complianz-gdpr' );
				$banner->header           = array(
					'text' => __( 'Manage your privacy', 'complianz-gdpr' ),
					'show' => true,
				);
				$banner->save();
			}
		}

		// Deactivate a/b testing.
		$options['a_b_testing_buttons'] = false;
		/**
		 * Send an email
		 * but only once
		 */

		/*
		 * Disabled
		 *
			if ( !get_option('cmplz_tcf_mail_sent') ) {
				$from = get_option('admin_email');
				$site_url = site_url();
				$subject = "TCF enabled on ".$site_url;
				$to      = "tcf@really-simple-plugins.com";
				$headers = array();
				$message = "TCF was enabled on $site_url";
				add_filter( 'wp_mail_content_type', function ( $content_type ) {return 'text/html';} );
				$headers[] = "Reply-To: $from <$from>" . "\r\n";
				wp_mail( $to, $subject, $message, $headers );
				remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
				update_option( 'cmplz_tcf_mail_sent', true, false );
			}
		*/
	}
	return $options;
}

/**
 * Map a WordPress locale to its corresponding TCF language file code.
 *
 * Handles regional variants (e.g. pt_BR → pt-br, zh_TW → zh-hant, sr_RS → sr-cyrl).
 * Falls back to the 2-char language code, then 'en'.
 *
 * @return string TCF language code (e.g. 'pt-br', 'zh-hant', 'fr')
 */
function cmplz_get_tcf_locale(): string {
	$wp_locale = get_user_locale();

	$locale_map = array(
		'pt_BR' => 'pt-br',
		'pt_PT' => 'pt-pt',
		'zh_TW' => 'zh-hant',
		'zh_HK' => 'zh-hant',
		'sr_RS' => 'sr-cyrl',
	);

	if ( isset( $locale_map[ $wp_locale ] ) ) {
		return $locale_map[ $wp_locale ];
	}

	$short = strtolower( substr( $wp_locale, 0, 2 ) );

	// These language codes have no generic file — map to the most common regional variant.
	$variant_defaults = array(
		'pt' => 'pt-pt',
		'sr' => 'sr-cyrl',
	);
	if ( isset( $variant_defaults[ $short ] ) ) {
		return $variant_defaults[ $short ];
	}

	// Generic languages that have their own file: no regional variant (no hyphen) and not English.
	$simple_languages = array_filter(
		cmplz_tcf_languages(),
		function ( $lang ) {
			return 'en' !== $lang && false === strpos( $lang, '-' );
		}
	);
	return in_array( $short, $simple_languages, true ) ? $short : 'en';
}

/**
 * Get items from the most recent vendor list, and cache it for one month
 *
 * @param string $fieldname
 * @param bool   $default_on
 *
 * @return array
 */
function cmplz_tcf_get( string $fieldname, bool $default_on = false ) {
	if ( ! cmplz_is_logged_in_rest() ) {
		return array();
	}
	// User locale.
	$locale = cmplz_get_tcf_locale();
	$items  = get_transient( 'cmplz_tcf_' . $locale . '_' . $fieldname );
	if ( empty( $items ) ) {
		$items    = array();
		$cmp_path = cmplz_upload_dir( 'cmp/vendorlist' );
		// Get the purposes.
		if ( 'en' === $locale ) {
			$path = $cmp_path . 'vendor-list.json';
		} else {
			$path = $cmp_path . 'purposes-' . $locale . '.json';
		}
		if ( ! file_exists( $path ) ) {
			// Try downloading fresh files.
			cmplz_update_json_files();
		}

		if ( ! file_exists( $path ) ) {
			set_transient( 'cmplz_tcf_' . $locale . '_' . $fieldname, $items, DAY_IN_SECONDS );
			return $items;
		}

		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		$data = json_decode( $wp_filesystem->get_contents( $path ) );
		if ( ! empty( $data ) ) {
			// Use a separate variable for the JSON property name, so $fieldname keeps matching the transient key read above.
			$json_property = $fieldname;
			if ( 'specialfeatures' === $fieldname ) {
				$json_property = 'specialFeatures';
			}
			if ( 'specialpurposes' === $fieldname ) {
				$json_property = 'specialPurposes';
			}
			$remote_items = $data->{$json_property};
			$items        = array();
			if ( is_object( $remote_items ) ) {
				foreach ( $remote_items as $remote_item ) {
					$items[ $remote_item->id ] = $remote_item->name;
				}
			}
		}
		delete_option( 'cmplz_clear_tcf_purposes_after_upgrade' );
		set_transient( 'cmplz_tcf_' . $locale . '_' . $fieldname, $items, MONTH_IN_SECONDS );
	}

	if ( $default_on ) {
		$items = array_keys( $items );
		foreach ( $items as $key => $item ) {
			$items[ $key ] = "$item";
		}
	}

	return $items;
}

/**
 * For fields added with filters, we need to use the direct cmplz_fields filter instead of the cmplz_banner_fields filter
 * Because the fields won't be added yet otherwise.
 *
 * @param array $fields
 *
 * @return array
 */
function cmplz_adjust_fields_for_tcf( array $fields ): array {
	if ( ! cmplz_admin_logged_in() ) {
		return $fields;
	}

	if ( cmplz_iab_is_enabled() ) {
		// Set disabled.
		$disable_fields = array(
			'a_b_testing_buttons',
		);
		foreach ( $disable_fields as $field_id ) {
			$key = cmplz_get_field_index( $field_id, $fields );
			if ( false !== $key ) {
				$fields[ $key ]['disabled'] = 1;
				// We don't want this field to get enabled again based on conditions.
				unset( $fields[ $key ]['condition_action'], $fields[ $key ]['premium'] );
			}
		}
	}
	return $fields;
}

/**
 * Add fields for TCF
 *
 * @param array $fields
 *
 * @return array
 */
function cmplz_add_tcf_fields( array $fields ): array {
	if ( ! cmplz_admin_logged_in() ) {
		return $fields;
	}

	if ( cmplz_iab_is_enabled() ) {
		// set hidden
		// we prevent all editing, as these options have to be the same for all regions.
		$hide_fields = array(
			'message_optin',
			'use_categories',
			'colorpalette_background',
			'border_width',
			'colorpalette_text',
			'colorpalette_toggles',
			'colorpalette_border_radius',
			'save_preferences',
			'dismiss',
			'wcag_colors_toggles',
			'wcag_colors_general',
		// 'manage_consent_options',
		);
		foreach ( $hide_fields as $field_id ) {
			$keys = array_keys( array_column( $fields, 'id' ), $field_id );
			$key  = reset( $keys );
			if ( false !== $key ) {
				$fields[ $key ]['react_conditions'] = array(
					'relation' => 'AND',
					array(
						'hidden' => 'true', // fake condition which never applies.
					),
				);
			}
		}

		// Remove bottom right and bottom left positions from options.
		$keys = array_keys( array_column( $fields, 'id' ), 'position' );
		$key  = reset( $keys );
		if ( false !== $key ) {
			unset( $fields[ $key ]['options']['bottom-left'], $fields[ $key ]['options']['bottom-right'] );
		}

		// Set some default values for the TCF banner.
		$fields_defaults = array(
			array(
				'id'      => 'soft_cookiewall',
				'default' => false,
			),
			array(
				'id'      => 'banner_width',
				'default' => '600',
			),
			array(
				'id'      => 'position',
				'default' => 'center',
			),
			array(
				'id'      => 'manage_consent_options',
				'default' => 'show-everywhere',
			),
			array(
				'id'      => 'view_preferences',
				'default' => __( 'Manage options', 'complianz-gdpr' ),
			),
			array(
				'id'      => 'header',
				'default' => array(
					'text' => __( 'Manage your privacy', 'complianz-gdpr' ),
					'show' => true,
				),
			),
			array(
				'id'      => 'dismiss',
				'default' => array(
					'text' => __( 'Deny', 'complianz-gdpr' ),
					'show' => true,
				),
			),
		);
		$color_schemes   = cmplz_banner_color_schemes();
		$color_scheme    = $color_schemes['tcf'];
		foreach ( $color_scheme as $fieldname => $value ) {
			$fields_defaults[] = array(
				'id'      => $fieldname,
				'default' => $value,
			);
		}
		foreach ( $fields_defaults as $default_field ) {
			$keys = array_keys( array_column( $fields, 'id' ), $default_field['id'] );
			$key  = reset( $keys );
			if ( false !== $key ) {
				$fields[ $key ]['default'] = $default_field['default'];
			}
		}

		// If TCF is enabled, disable some options for the cookie policy.
		$keys = array_keys( array_column( $fields, 'id' ), 'cookie-statement' );
		$key  = reset( $keys );
		if ( false !== $key ) {
			$fields[ $key ]['disabled'] = array(
				'custom',
				'url',
			);
		}

		// Show this notice on all these fields.
		$link_notice_ids  = array( 'title', 'header', 'position', 'colorpalette_button_accept', 'use_custom_cookie_css' );
		$link_notice_keys = array();
		foreach ( $link_notice_ids as $link_notice_id ) {
			$keys               = array_keys( array_column( $fields, 'id' ), $link_notice_id );
			$link_notice_keys[] = reset( $keys );
		}
		foreach ( $link_notice_keys as $key ) {
			if ( false !== $key ) {
				$fields[ $key ]['help'] = array(
					'label' => 'warning',
					'title' => __( 'TCF: Guideline restrictions', 'complianz-gdpr' ),
					'text'  => __( 'Configuring your TCF consent banner is limited due to IAB guidelines.', 'complianz-gdpr' ),
					'url'   => 'https://complianz.io/customizing-the-tcf-banner/',
				);
			}
		}
	}
	// always add these fields, to ensure they're added on change to tcf immediately.
	// otherwise, this hook is already executed by the time the fields load, and the fields only appear on the next save.
	$load_fields = cmplz_is_logged_in_rest() || cmplz_iab_is_enabled();
	if ( $load_fields ) {
		$fields = array_merge(
			$fields,
			array(
				array(
					'id'               => 'tcf_purposes',
					'menu_id'          => 'tcf',
					'group_id'         => 'tcf',
					'default'          => cmplz_tcf_get( 'purposes', true ),
					'type'             => 'multicheckbox',
					'options'          => cmplz_tcf_get( 'purposes' ),
					'label'            => __( 'Your site will show vendors with the purposes selected here', 'complianz-gdpr' ),
					'help'             => array(
						'label' => 'default',
						'title' => __( 'Vendors', 'complianz-gdpr' ),
						'text'  => __( 'To get a better understanding of vendors, purposes and features please read this definitions guide.', 'complianz-gdpr' ),
						'url'   => 'https://complianz.io/definition/what-are-vendors/',
					),
					'react_conditions' => array(
						'relation' => 'AND',
						array(
							'!uses_ad_cookies_personalized' => 'no',
						),
					),
				),
				array(
					'id'               => 'tcf_specialpurposes',
					'menu_id'          => 'tcf',
					'group_id'         => 'tcf',
					'default'          => cmplz_tcf_get( 'specialpurposes', true ),
					'type'             => 'multicheckbox',
					'options'          => cmplz_tcf_get( 'specialpurposes' ),
					'label'            => __( 'Your site will show vendors with the special purposes selected here', 'complianz-gdpr' ),
					'help'             => array(
						'label' => 'default',
						'title' => __( 'Special purposes', 'complianz-gdpr' ),
						'text'  => __(
							'These special purposes should be enabled for best results. These purposes are set based on legitimate interest of the vendor, one of the legal bases of data processing.',
							'complianz-gdpr'
						),
						'url'   => 'https://complianz.io/definition/what-is-a-lawful-basis-for-data-processing/#legitimate-interest',
					),
					'react_conditions' => array(
						'relation' => 'AND',
						array(
							'!uses_ad_cookies_personalized' => 'no',
						),
					),
				),
				array(
					'id'               => 'tcf_features',
					'menu_id'          => 'tcf',
					'group_id'         => 'tcf',
					'default'          => cmplz_tcf_get( 'features', true ),
					'type'             => 'multicheckbox',
					'options'          => cmplz_tcf_get( 'features' ),
					'label'            => __( 'Your site will show vendors with the features selected here', 'complianz-gdpr' ),
					'react_conditions' => array(
						'relation' => 'AND',
						array(
							'!uses_ad_cookies_personalized' => 'no',
						),
					),
				),
				array(
					'id'               => 'tcf_specialfeatures',
					'menu_id'          => 'tcf',
					'group_id'         => 'tcf',
					'default'          => array(),
					'type'             => 'multicheckbox',
					'options'          => cmplz_tcf_get( 'specialfeatures' ),
					'label'            => __( 'Your site will show vendors with the special features selected here', 'complianz-gdpr' ),
					'react_conditions' => array(
						'relation' => 'AND',
						array(
							'!uses_ad_cookies_personalized' => 'no',
						),
					),
				),
				array(
					'id'               => 'tcf_international_transfer',
					'menu_id'          => 'tcf',
					'group_id'         => 'tcf',
					'default'          => 'yes',
					'type'             => 'radio',
					'options'          => COMPLIANZ::$config->yes_no,
					'label'            => __( 'Do you want to share data outside of the EU/UK?', 'complianz-gdpr' ),
					'tooltip'          => __(
						"Some vendors will share data outside of the EU/UK. It's disabled by default, but we recommend US based publishers to enable this option.",
						'complianz-gdpr'
					),
					'react_conditions' => array(
						'relation' => 'AND',
						array(
							'uses_ad_cookies_personalized' => 'yes',
						),
					),
				),

				array(
					'id'               => 'tcf_unclear_services',
					'menu_id'          => 'tcf',
					'group_id'         => 'tcf',
					'default'          => 'yes',
					'type'             => 'radio',
					'options'          => COMPLIANZ::$config->yes_no,
					'label'            => __( "Do you want to share data with advertisers that don't describe their services?", 'complianz-gdpr' ),
					'tooltip'          => __(
						"Vendors are required to describe their services. Some vendors list services under 'other' and could be considered to negate transparency.",
						'complianz-gdpr'
					),
					'react_conditions' => array(
						'relation' => 'AND',
						array(
							'!uses_ad_cookies_personalized' => 'no',
						),
					),
				),
				array(
					'id'               => 'tcf_lspact',
					'menu_id'          => 'tcf',
					'group_id'         => 'tcf',
					'default'          => 'no',
					'type'             => 'radio',
					'options'          => COMPLIANZ::$config->yes_no,
					'label'            => __( 'Have you signed the IAB Privacy, LLC’s Limited Service Provider Agreement (LSPA)?', 'complianz-gdpr' ),
					'react_conditions' => array(
						'relation' => 'AND',
						array(
							'regions'   => array( 'us' ),
							'us_states' => 'cal',
							'!uses_ad_cookies_personalized' => 'no',
						),
					),
					'help'             => array(
						'label' => 'default',
						'title' => __( 'Limited Service Provider Agreement (LSPA)', 'complianz-gdpr' ),
						'text'  => __( 'For California, please read the article about LSPA.', 'complianz-gdpr' ),
						'url'   => 'https://complianz.io/tcf-ccpa/',
					),
				),
			)
		);
	}
	return $fields;
}

/**
 * With TCF, we need to hardcode some categories
 *
 * @param $settings
 *
 * @return mixed
 */
function cmplz_tcf_adjust_cookie_policy_snapshot_settings( $settings ) {
	unset( $settings['categories'] );
	return $settings;
}
add_filter( 'cmplz_cookie_policy_snapshot_settings', 'cmplz_tcf_adjust_cookie_policy_snapshot_settings' );

/**
 * Add link to vendors overview
 *
 * @param $html
 *
 * @return mixed
 */
function cmplz_tcf_adjust_cookie_policy_snapshot_html( $html ) {
	$purposes = cmplz_get_option( 'tcf_purposes' );
	if ( ! is_array( $purposes ) ) {
		$purposes = array();
	}
	$purposes         = array_keys( array_filter( $purposes ) );
	$special_purposes = cmplz_get_option( 'tcf_specialpurposes' );
	if ( ! is_array( $special_purposes ) ) {
		$special_purposes = array();
	}
	$special_purposes = array_keys( array_filter( $special_purposes ) );
	$features         = cmplz_get_option( 'tcf_features' );
	if ( ! is_array( $features ) ) {
		$features = array();
	}
	$features         = array_keys( array_filter( $features ) );
	$special_features = cmplz_get_option( 'tcf_specialfeatures' );
	if ( ! is_array( $special_features ) ) {
		$special_features = array();
	}
	$special_features       = array_keys( array_filter( $special_features ) );
	$marker_marketing       = '<p id="cmplz-tcf-marketing-purposes-container" class="cmplz-tcf-container"></p>';
	$marker_statistics      = '<p id="cmplz-tcf-statistics-purposes-container" class="cmplz-tcf-container"></p>';
	$marker_specialfeatures = '<p id="cmplz-tcf-specialfeatures-container" class="cmplz-tcf-container"></p>';
	$marker_features        = '<p id="cmplz-tcf-features-container" class="cmplz-tcf-container"></p>';
	$marker_specialpurposes = '<p id="cmplz-tcf-specialpurposes-container" class="cmplz-tcf-container"></p>';

	$p_labels  = cmplz_tcf_get( 'purposes' );
	$sp_labels = cmplz_tcf_get( 'specialpurposes' );
	$f_labels  = cmplz_tcf_get( 'features' );
	$sf_labels = cmplz_tcf_get( 'specialfeatures' );

	foreach ( $p_labels as $key => $label ) {
		if ( ! in_array( $key, $purposes ) ) {
			unset( $p_labels[ $key ] );
		}
	}
	foreach ( $sp_labels as $key => $label ) {
		if ( ! in_array( $key, $special_purposes ) ) {
			unset( $sp_labels[ $key ] );
		}
	}
	foreach ( $f_labels as $key => $label ) {
		if ( ! in_array( $key, $features ) ) {
			unset( $f_labels[ $key ] );
		}
	}
	foreach ( $sf_labels as $key => $label ) {
		if ( ! in_array( $key, $special_features ) ) {
			unset( $sf_labels[ $key ] );
		}
	}
	$stats_purposes     = cmplz_tcf_filter_by_category( $p_labels, 'statistics' );
	$marketing_purposes = cmplz_tcf_filter_by_category( $p_labels, 'marketing' );
	$stats_purposes     = '<div>' . implode( '<br />', $stats_purposes ) . '</div>';
	$marketing_purposes = '<div>' . implode( '<br />', $marketing_purposes ) . '</div>';
	$features           = '<div>' . implode( '<br />', $f_labels ) . '</div>';
	$special_features   = '<div>' . implode( '<br />', $sf_labels ) . '</div>';
	$special_purposes   = '<div>' . implode( '<br />', $sp_labels ) . '</div>';
	$html               = str_replace( $marker_statistics, $stats_purposes, $html );
	$html               = str_replace( $marker_marketing, $marketing_purposes, $html );
	$html               = str_replace( $marker_specialfeatures, $special_features, $html );
	$html               = str_replace( $marker_features, $features, $html );
	$html               = str_replace( $marker_specialpurposes, $special_purposes, $html );

	$marker = '<div id="cmplz-tcf-vendor-template"';
	// translators: %s is a link to the vendor list on cookiedatabase.org.
	$add = cmplz_sprintf( __( 'The vendor list can be found at %s', 'complianz-gdpr' ), '<a href="https://cookiedatabase.org/cmp/vendorlist/vendor-list.json">cookiedatabase.org</a><br /><br />' );
	return str_replace( $marker, $add . $marker, $html );
}


function cmplz_tcf_filter_by_category( $purposes, $category ) {
	$p['marketing']  = array( 1, 2, 3, 4, 5, 6, 10 );
	$p['statistics'] = array( 1, 7, 8, 9 );

	foreach ( $purposes as $key => $value ) {
		if ( ! in_array( $key, $p[ $category ] ) ) {
			unset( $purposes[ $key ] );
		}
	}

	return $purposes;
}

function cmplz_count_all_vendors() {
	$upload_dir = cmplz_upload_dir( 'cmp/vendorlist' );
	$path       = $upload_dir . 'additional-vendor-information-list.json';
	if ( ! file_exists( $path ) ) {
		return 0;
	}

	global $wp_filesystem;
	if ( ! $wp_filesystem ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		WP_Filesystem();
	}
	$json = json_decode( $wp_filesystem->get_contents( $path ), true );
	if ( ! isset( $json['vendors'] ) ) {
		return 0;
	}

	$vendors = $json['vendors'];
	if ( is_array( $vendors ) ) {
		return count( $vendors );
	}
	return 0;
}
/**
 * Conditional notices for fields
 *
 * @param array $notices
 *
 * @return array
 */
function cmplz_tcf_field_notices( array $notices ): array {
	if ( ! cmplz_user_can_manage() ) {
		return $notices;
	}

	if ( cmplz_tcf_active() ) {
		$all_vendors      = cmplz_count_all_vendors();
		$excluded_vendors = cmplz_tcf_get_excluded_vendors();

		// should exclude purposes etc as well.
		$excluded_vendors = count( $excluded_vendors );
		$vendor_count     = $all_vendors;
		if ( $all_vendors > $excluded_vendors ) {
			$vendor_count = $all_vendors - $excluded_vendors;
		}
		$notices[] = array(
			'field_id' => 'tcf_specialfeatures',
			'label'    => 'default',
			'title'    => __( 'Vendor count', 'complianz-gdpr' ),
			// translators: %s is the number of selected vendors.
			'text'     => cmplz_sprintf( __( 'With your current settings, you have selected %s vendors.', 'complianz-gdpr' ), $vendor_count ),
		);
	}

	return $notices;
}
/*add_filter( 'cmplz_field_notices', 'cmplz_tcf_field_notices', 10, 1 );*/
