var cmplz_gcm_preferences, cmplz_gcm_statistics, cmplz_gcm_marketing;
!function() {
	function r(n) { var m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')); return m ? m[1] : ''; }
	var p = '{cookie_prefix}';
	cmplz_gcm_preferences = r(p + 'preferences') === 'allow' ? 'granted' : 'denied';
	cmplz_gcm_statistics  = r(p + 'statistics')  === 'allow' ? 'granted' : 'denied';
	cmplz_gcm_marketing   = r(p + 'marketing')   === 'allow' ? 'granted' : 'denied';
}();
window['gtag_enable_tcf_support'] = {enable_tcf_support};
window.dataLayer = window.dataLayer || [];
function gtag(){
	dataLayer.push(arguments);
}
gtag('consent', 'default', {
	'security_storage': "granted",
	'functionality_storage': "granted",
	'personalization_storage': cmplz_gcm_preferences,
	'analytics_storage': cmplz_gcm_statistics,
	'ad_storage': cmplz_gcm_marketing,
	'ad_user_data': cmplz_gcm_marketing,
	'ad_personalization': cmplz_gcm_marketing,
});

dataLayer.push({
	'event': 'default_consent'
});

gtag('set', 'dYWVlZG', true);
gtag('set', 'ads_data_redaction', {ads_data_redaction});
gtag('set', 'url_passthrough', {url_passthrough});

document.addEventListener("cmplz_fire_categories", function (e) {
	function gtag(){
		dataLayer.push(arguments);
	}
	var consentedCategories = e.detail.categories;
	let preferences = 'denied';
	let statistics = 'denied';
	let marketing = 'denied';

	if (cmplz_in_array( 'preferences', consentedCategories )) {
		preferences = 'granted';
	}

	if (cmplz_in_array( 'statistics', consentedCategories )) {
		statistics = 'granted';
	}

	if (cmplz_in_array( 'marketing', consentedCategories )) {
		marketing = 'granted';
	}
	gtag('consent', 'update', {
		'security_storage': "granted",
		'functionality_storage': "granted",
		'personalization_storage': preferences,
		'analytics_storage': statistics,
		'ad_storage': marketing,
		'ad_user_data': marketing,
		'ad_personalization': marketing,
	});
});

document.addEventListener("cmplz_revoke", function (e) {
	gtag('consent', 'update', {
		'security_storage': "granted",
		'functionality_storage': "granted",
		'personalization_storage': "denied",
		'analytics_storage': 'denied',
		'ad_storage': "denied",
		'ad_user_data': 'denied',
		'ad_personalization': 'denied',
	});
});

gtag('js', new Date());
gtag('config', '{G_code}', {
	cookie_flags: 'secure;samesite=none',
});
