<?php
global $post;
$item_visible    = ! empty( $instance['visible'] ) ? $instance['visible'] : 1;
$pagination      = ( ! empty( $instance['pagination'] ) && $instance['pagination'] == 'yes' ) ? true : false;
$navigation      = ( ! empty( $instance['navigation'] ) && $instance['navigation'] != 'yes' ) ? false : true;
$cat_id          = ! empty( $instance['cat_id'] ) ? $instance['cat_id'] : array();
$post_limit      = ! empty( $instance['post_limit'] ) ? $instance['post_limit'] : 4;
$data_itemtablet = ( $item_visible < 2 ) ? $item_visible : 2;
$list_cat        = array();
if ( ! is_array( $cat_id ) ) {
	$list_cat[] = $cat_id;
} else {
	$list_cat = $cat_id;
}
$html = '';

if ( $instance['title'] ) {
	$html .= $args['before_title'] . $instance['title'] . $args['after_title'];
}

if ( ! empty( $list_cat ) ) {
	$html .= '<div class="thim-post-caregories-slider">';
	$html .= '<div class="thim-carousel-wrapper" data-visible="' . $item_visible . '" data-itemtablet="' . $data_itemtablet . '" data-pagination="' . $pagination . '" data-navigation="' . $navigation . '" data-navigation-text="2">';

	// Batch query: 1 query for all categories instead of one get_posts() call per category.
	$valid_cat_ids = array();
	foreach ( $list_cat as $list_cat_id ) {
		if ( get_term( $list_cat_id, 'category' ) ) {
			$valid_cat_ids[] = (int) $list_cat_id;
		}
	}

	$posts_by_cat = array();
	if ( ! empty( $valid_cat_ids ) ) {
		$batch = new WP_Query(
			array(
				'post_type'           => 'post',
				'posts_per_page'      => count( $valid_cat_ids ) * $post_limit,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
				'tax_query'           => array(
					array(
						'taxonomy' => 'category',
						'field'    => 'term_id',
						'terms'    => $valid_cat_ids,
					),
				),
			)
		);
		foreach ( $batch->posts as $post ) {
			foreach ( wp_get_post_categories( $post->ID ) as $post_cat_id ) {
				if ( in_array( $post_cat_id, $valid_cat_ids, true ) && count( $posts_by_cat[ $post_cat_id ] ?? array() ) < $post_limit ) {
					$posts_by_cat[ $post_cat_id ][] = $post;
				}
			}
		}
		wp_reset_postdata();
	}

	foreach ( $list_cat as $k => $cat_id ) {
		if ( ! in_array( (int) $cat_id, $valid_cat_ids, true ) ) {
			continue;
		}
		$posts_array = $posts_by_cat[ (int) $cat_id ] ?? array();

		$cat_name    = get_cat_name( $cat_id );
		$top_image   = get_term_meta( $cat_id, 'thim_archive_top_image', true );
		$description = category_description( $cat_id );

		$img = '<div class="image"><a href="' . esc_url( get_term_link( (int) $cat_id, 'category' ) ) . '">';
		if ( $top_image && '' != $top_image['id'] ) {
			$img .= thim_get_feature_image( $top_image['id'], 'full', 420, 420, $cat_name );
		} else {
			$img .= thim_get_feature_image( null, 'full', 420, 420, $cat_name );
		}
		$img .= '</a></div>';

		$html .= '<div class="item">';
		$html .= $img;
		$html .= '<div class="content-wrapper">';
		$html .= '<h3 class="title"><a href="' . esc_url( get_term_link( (int) $cat_id, 'category' ) ) . '">' . $cat_name . '</a></h3>';
		if ( ! empty( $description ) ) {
			$html .= '<div class="desc">' . $description . '</div>';
		}
		if ( ! empty( $posts_array ) ) {
			$html .= '<div class="list-course-items">';
			$html .= '<label>' . esc_html__( 'Courses', 'eduma' ) . '</label>';
			foreach ( $posts_array as $key => $value ) {
				$html .= '<a class="course-link" href="' . esc_url( get_the_permalink( $value->ID ) ) . '" title="' . esc_attr( $value->post_title ) . '">' . thim_str_short( $value->post_title, 6 ) . '</a>';
			}
			$html .= '</div>';
		}
		$html .= '</div>';
		$html .= '</div>';
	}
	$html .= '</div>';
	if ( ! empty( $instance['link_view_all'] ) && ! empty( $instance['text_view_all'] ) ) {
		$html .= '<a class="link-view-all" href="' . esc_url( $instance['link_view_all'] ) . '" title="' . esc_attr( $instance['text_view_all'] ) . '">' . esc_attr( $instance['text_view_all'] ) . '</a>';
	}
	$html .= '</div>';

} else {
	$html .= '<p>' . esc_html__( 'You need edit page and config category for shortcode', 'eduma' ) . '</p>';
}


echo ent2ncr( $html );
