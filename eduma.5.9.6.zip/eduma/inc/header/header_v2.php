<div
	class="thim-nav-wrapper <?php echo get_theme_mod( 'thim_header_size', 'default' ) == 'full_width' ? 'header_full' : 'container'; ?>">
	<div class="row">
		<div class="navigation col-sm-12">
			<div class="tm-table">
				<div class="width-logo table-cell sm-logo">
					<?php
					do_action( 'thim_logo' );
					?>
				</div>
				<nav class="header-top-menu table-cell table-right">
					<?php get_template_part( 'inc/header/menu_right_header_v2' ); ?>
				</nav>
				<div class="menu-mobile-effect navbar-toggle" data-effect="mobile-effect">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</div>
			</div>
			<nav class="width-navigation">
				<?php get_template_part( 'inc/header/main-menu' ); ?>
			</nav>
		</div>
	</div>
</div>
