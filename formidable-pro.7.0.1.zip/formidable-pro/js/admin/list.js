/**
 * This file is loaded on the forms list/index page.
 * This code is responsible for:
 *  - autopopulating the application dropdown from the new form modal
 */
( function () {
	/** globals frmDom, frmGlobal, wp, frmAutocompleteApplicationVars */

	if ( 'undefined' === typeof frmDom || 'undefined' === typeof wp ) {
		return;
	}

	const { tag, div, span } = window.frmDom;
	const { __, sprintf } = wp.i18n;

	const state = {
		addedApplicationDropdown: false,
		applicationOptions: null,
	};

	addAction( 'frm_new_form_modal_form', addApplicationDropdownToNewFormModal );
	addFilter( 'frm_before_install_new_form', beforeInstallNewForm );

	function addApplicationDropdownToNewFormModal( $modal ) {
		if ( ! state.addedApplicationDropdown ) {
			$modal.addClass( 'frm_wrap' );
			$modal.find( '#frm_template_desc' ).parent().append( getApplicationDropdown( $modal ) );
			state.addedApplicationDropdown = true;
		}
	}

	function getApplicationDropdown( $modal ) {
		const dropdown = getApplicationAutocomplete();

		const label = tag( 'label', {
			children: [ document.createTextNode( __( 'Insert form into application', 'formidable-pro' ) ) ],
		} );

		label.setAttribute( 'for', 'frm_application_autocomplete_input' );

		const wrapper = div( {
			className: 'frm_wrap',
			children: [ label, dropdown ],
		} );
		wrapper.style.marginTop = '10px';

		window.frmDom.autocomplete.initAutocomplete( 'application', dropdown );

		jQuery( dropdown.querySelector( '.frm-application-search' ) ).autocomplete( 'option', 'appendTo', $modal );

		const urlParams = new URLSearchParams( window.location.search );
		const applicationId = urlParams.get( 'applicationId' );
		if ( applicationId && 'undefined' !== typeof frmAutocompleteApplicationVars ) {
			dropdown.querySelector( '#frm_application_autocomplete_input' ).value =
				window.frmAutocompleteApplicationVars.name;

			dropdown.querySelector( '.frm_autocomplete_value_input' ).value = applicationId;
		}

		return wrapper;
	}

	function getApplicationAutocomplete() {
		return span( {
			className: 'success_action_application_box success_action_box',
			children: [
				input( {
					id: 'frm_application_autocomplete_input',
					className: 'frm-application-search',
					type: 'text',
					placeholder: __( 'Select application', 'formidable-pro' ),
				} ),
				input( {
					className: 'frm_autocomplete_value_input',
					type: 'hidden',
					name: 'application_id',
				} ),
			],
		} );
	}

	function input( args ) {
		const output = tag( 'input', args );
		if ( 'object' === typeof args ) {
			if ( 'string' === typeof args.type ) {
				output.type = args.type;
			}
			if ( 'string' === typeof args.placeholder ) {
				output.setAttribute( 'placeholder', args.placeholder );
			}
			if ( 'string' === typeof args.name ) {
				output.setAttribute( 'name', args.name );
			}
		}
		return output;
	}

	function beforeInstallNewForm( data, { formData } ) {
		data.application_id = formData.application_id;
		return data;
	}

	function addAction( hookName, callback ) {
		wp.hooks.addAction( hookName, 'formidable', callback );
	}

	function addFilter( hookName, callback ) {
		wp.hooks.addFilter( hookName, 'formidable', callback );
	}

	const ADD_APPLICATIONS_MODAL_ID = 'frm_add_applications_modal';

	frmDom.util.documentOn( 'click', '.frm-add-applications', ( event ) => {
		event.preventDefault();
		showAddApplicationsModal( event.target.closest( '.frm-add-applications' ) );
	} );

	// The open dropdown hangs below the modal, so a click beside it often lands on the overlay.
	// Close only the dropdown then, instead of the whole modal and the selection with it.
	// This runs in the capture phase, before the overlay's own listener that closes the modal.
	document.addEventListener(
		'click',
		( event ) => {
			if ( ! event.target.classList || ! event.target.classList.contains( 'ui-widget-overlay' ) ) {
				return;
			}

			const toggle = document.querySelector( `#${ ADD_APPLICATIONS_MODAL_ID } .multiselect.dropdown-toggle[aria-expanded="true"]` );
			if ( ! toggle ) {
				return;
			}

			event.preventDefault();
			event.stopPropagation();
			toggle.click();
		},
		true
	);

	/**
	 * Open the modal that adds a form to applications from the forms list.
	 *
	 * @since 7.0
	 *
	 * @param {HTMLElement} addButton The Add button in the form's Applications column.
	 * @return {void}
	 */
	function showAddApplicationsModal( addButton ) {
		const content = document.getElementById( 'frm-add-applications-content' );
		let dropdown = content.querySelector( '#frm-add-applications-dropdown' );

		// Prepare the content before the dialog opens, so the dialog can move focus into it.
		if ( dropdown ) {
			const formTitle = addButton.closest( 'tr' ).querySelector( '.row-title' )?.textContent.trim();
			const currentIds = addButton.dataset.applicationIds ? addButton.dataset.applicationIds.split( ',' ) : [];
			const isInEveryApplication = getAllApplicationOptions( dropdown ).every( ( option ) => currentIds.includes( option.value ) );

			content.querySelector( '#frm-add-applications-description' ).textContent = getAddApplicationsDescription( formTitle, isInEveryApplication );
			dropdown.closest( '.frm_form_field' ).classList.toggle( 'frm_hidden', isInEveryApplication );
			setAddApplicationsError( '' );

			if ( isInEveryApplication ) {
				// Nothing is left to select, so point to the Applications page like when none exist.
				dropdown = null;
			} else {
				resetApplicationsDropdown( dropdown, addButton.dataset.applicationIds );
			}
		}

		frmDom.modal.maybeCreateModal( ADD_APPLICATIONS_MODAL_ID, {
			title: __( 'Add to Applications', 'formidable-pro' ),
			content,
			footer: getAddApplicationsModalFooter( addButton, dropdown ),
			dialogClass: 'frm-add-applications-dialog',
		} );
	}

	/**
	 * @since 7.0
	 *
	 * @param {string|undefined} formTitle
	 * @param {boolean}          isInEveryApplication
	 * @return {string} The text shown above the applications dropdown.
	 */
	function getAddApplicationsDescription( formTitle, isInEveryApplication ) {
		if ( isInEveryApplication ) {
			return formTitle
				? sprintf(
					/* translators: %s: Form title */
					__( '"%s" is already in every application. Create a new application to add it to another one.', 'formidable-pro' ),
					formTitle
				)
				: __( 'This form is already in every application. Create a new application to add it to another one.', 'formidable-pro' );
		}

		return formTitle
			? sprintf(
				/* translators: %s: Form title */
				__( 'Choose the applications to add "%s" to.', 'formidable-pro' ),
				formTitle
			)
			: __( 'Choose the applications to add this form to.', 'formidable-pro' );
	}

	/**
	 * The dropdown only lists the applications the form can still be added to,
	 * so keep the full list to rebuild it each time the modal opens.
	 *
	 * @since 7.0
	 *
	 * @param {HTMLSelectElement} dropdown
	 * @return {Array<HTMLOptionElement>} Every application option.
	 */
	function getAllApplicationOptions( dropdown ) {
		if ( ! state.applicationOptions ) {
			state.applicationOptions = Array.from( dropdown.options );
		}
		return state.applicationOptions;
	}

	/**
	 * Clear the previous selection and exclude applications the form is already in.
	 *
	 * @since 7.0
	 *
	 * @param {HTMLSelectElement} dropdown
	 * @param {string}            currentIds Comma separated IDs of the applications the form is already in.
	 * @return {void}
	 */
	function resetApplicationsDropdown( dropdown, currentIds ) {
		const current = new Set( currentIds ? currentIds.split( ',' ) : [] );

		const availableOptions = getAllApplicationOptions( dropdown ).filter( option => {
			option.selected = false;
			return ! current.has( option.value );
		} );
		dropdown.replaceChildren( ...availableOptions );

		if ( dropdown.dataset.frmMultiselectReady ) {
			jQuery( dropdown ).multiselect( 'rebuild' );
			return;
		}

		frmDom.bootstrap.multiselect.init.call( dropdown );
		dropdown.dataset.frmMultiselectReady = '1';
		jQuery( dropdown ).on( 'frm-multiselect-changed', () => {
			setAddApplicationsError( '' );
			const saveButton = document.getElementById( 'frm-add-applications-save' );
			saveButton.disabled = ! dropdown.selectedOptions.length;
		} );
	}

	/**
	 * @since 7.0
	 *
	 * @param {HTMLElement}            addButton
	 * @param {HTMLSelectElement|null} dropdown  Null when there are no applications left to add the form to.
	 * @return {HTMLElement} The modal footer.
	 */
	function getAddApplicationsModalFooter( addButton, dropdown ) {
		const cancelButton = frmDom.modal.footerButton( {
			text: __( 'Cancel', 'formidable-pro' ),
			buttonType: 'cancel',
		} );
		cancelButton.classList.add( 'dismiss' );

		if ( ! dropdown ) {
			const applicationsButton = frmDom.modal.footerButton( {
				text: __( 'Go to Applications', 'formidable-pro' ),
				buttonType: 'primary',
				href: frmGlobal.applicationsUrl,
				noDismiss: true,
			} );

			return frmDom.div( {
				children: [ cancelButton, applicationsButton ],
			} );
		}

		const saveButton = tag( 'button', {
			id: 'frm-add-applications-save',
			className: 'button button-primary frm-button-primary',
			text: __( 'Add to Applications', 'formidable-pro' ),
		} );
		saveButton.type = 'button';
		saveButton.disabled = true;

		frmDom.util.onClickPreventDefault( saveButton, () => addFormToApplications( addButton, dropdown, saveButton ) );

		return frmDom.div( {
			children: [ cancelButton, saveButton ],
		} );
	}

	/**
	 * @since 7.0
	 *
	 * @param {HTMLElement}       addButton
	 * @param {HTMLSelectElement} dropdown
	 * @param {HTMLElement}       saveButton
	 * @return {Promise<void>}
	 */
	async function addFormToApplications( addButton, dropdown, saveButton ) {
		if ( saveButton.classList.contains( 'frm_loading_button' ) ) {
			return;
		}

		const applicationIds = Array.from( dropdown.selectedOptions )
			.filter( ( option ) => ! option.disabled )
			.map( ( option ) => option.value );

		if ( ! applicationIds.length ) {
			setAddApplicationsError( __( 'Please select at least one application.', 'formidable-pro' ) );
			return;
		}

		const formData = new FormData();
		formData.append( 'form_id', addButton.dataset.formId );
		formData.append( 'application_ids', applicationIds.join( ',' ) );

		setAddApplicationsError( '' );
		saveButton.classList.add( 'frm_loading_button' );

		let response;
		try {
			response = await frmDom.ajax.doJsonPost( 'add_form_to_applications', formData );
		} catch ( error ) {
			saveButton.classList.remove( 'frm_loading_button' );
			setAddApplicationsError(
				'string' === typeof error ? error : __( 'The form could not be added to the applications. Please try again.', 'formidable-pro' )
			);
			return;
		}

		saveButton.classList.remove( 'frm_loading_button' );

		const cell = addButton.closest( 'td' );
		cell.innerHTML = response.html;
		jQuery( document.getElementById( ADD_APPLICATIONS_MODAL_ID ) ).dialog( 'close' );

		// The button that opened the modal was replaced, so move focus to the new one.
		cell.querySelector( '.frm-add-applications' )?.focus();
	}

	/**
	 * @since 7.0
	 *
	 * @param {string} message An empty string hides the error.
	 * @return {void}
	 */
	function setAddApplicationsError( message ) {
		const error = document.querySelector( '#frm-add-applications-content .frm-add-applications-error' );
		if ( ! error ) {
			return;
		}

		error.textContent = message;
		error.classList.toggle( 'frm_hidden', ! message );
	}
} )();
