<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmProConditionalLogicOptionData {

	private static $all_fields_by_form_id = array();

	/**
	 * Indexed by form_id, then field id. Lazily built from self::$all_fields_by_form_id
	 * so a single field can be looked up without looping the whole list.
	 *
	 * @since 7.0
	 */
	private static $fields_by_id_by_form_id = array();

	/**
	 * @param int|string $form_id
	 *
	 * @return array
	 */
	public static function get_all_fields_for_form( $form_id ) {
		if ( ! isset( self::$all_fields_by_form_id[ $form_id ] ) ) {
			// FrmField::get_all_for_form() lazily populates a transient cache the first
			// time it runs for a form in a request, via two wp_options inserts. Those
			// inserts change $wpdb->insert_id, which stomps on the id of whatever row a
			// caller inserted just before triggering this (e.g. the field container render
			// right after a new field is created via ajax). This is a read as far as any
			// caller of get_all_fields_for_form() is concerned, so restore insert_id after.
			global $wpdb;
			$insert_id                               = $wpdb->insert_id;
			self::$all_fields_by_form_id[ $form_id ] = self::get_prefiltered_list_of_fields_for_conditional_logic_options( (int) $form_id );
			$wpdb->insert_id                         = $insert_id;
		}
		return self::$all_fields_by_form_id[ $form_id ];
	}

	/**
	 * Look up a single eligible conditional-logic trigger field by id, without looping
	 * the whole per-form list. Used to render just the currently-selected option for a
	 * condition row instead of the full list.
	 *
	 * @since 7.0
	 *
	 * @param int|string $form_id
	 * @param int|string $field_id
	 *
	 * @return object|null
	 */
	public static function get_field( $form_id, $field_id ) {
		if ( ! isset( self::$fields_by_id_by_form_id[ $form_id ] ) ) {
			self::$fields_by_id_by_form_id[ $form_id ] = array();

			foreach ( self::get_all_fields_for_form( $form_id ) as $field ) {
				self::$fields_by_id_by_form_id[ $form_id ][ $field->id ] = $field;
			}
		}

		return self::$fields_by_id_by_form_id[ $form_id ][ $field_id ] ?? null;
	}

	/**
	 * This list of fields is used for conditional logic dropdown options.
	 * It is pre-filtered in order to make the list smaller.
	 * This way we can iterate fewer items when printing each logic row.
	 *
	 * @since 6.10.1
	 *
	 * @param int $form_id
	 *
	 * @return array
	 */
	private static function get_prefiltered_list_of_fields_for_conditional_logic_options( $form_id ) {
		return array_filter(
			FrmField::get_all_for_form( $form_id ),
			/**
			 * @param stdClass $field
			 *
			 * @return bool
			 */
			function ( $field ) {
				if ( FrmField::is_no_save_field( $field->type ) ) {
					return false;
				}

				// 'ranking' and 'likert' are Surveys field types, excluded here (rather than only
				// through the frm_is_field_present_in_logic_options filter, as Surveys itself does)
				// so this list stays authoritative for the browser-side deferred options rendering
				// in FrmProConditionalLogicController::should_defer_logic_options(). Keep this in
				// sync with FrmSurveys\controllers\LikertController::exclude_from_logic_options() and
				// FrmSurveys\controllers\RankingController::exclude_from_logic_options().
				if ( in_array( $field->type, array( 'file', 'credit_card', 'virtual', 'ranking', 'likert' ), true ) ) {
					return false;
				}

				if ( 'range' === $field->type && FrmField::get_option( $field, 'is_range_slider' ) ) {
					return false;
				}

				return ! FrmProField::is_list_field( $field );
			}
		);
	}

	/**
	 * @since 6.10.1
	 *
	 * @param int|string $form_id
	 *
	 * @return bool
	 */
	public static function data_is_available( $form_id ) {
		return array_key_exists( $form_id, self::$all_fields_by_form_id );
	}
}
