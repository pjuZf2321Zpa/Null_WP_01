<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * A selective, persistent index of scalar entry values used by Lookups and Views.
 *
 * The entry meta table remains the source of truth. A field is queried through this
 * table only after its backfill is complete.
 *
 * @since 7.0
 */
class FrmProMetaIndex {

	const BATCH_SIZE       = 2000;
	const MAX_VALUE_LENGTH = 150;

	/**
	 * Seconds a source write waits for the field lock held by another write or a backfill batch.
	 */
	const WRITE_LOCK_WAIT = 2;

	private static $foreground_backfills = array();

	private static $write_locks = array();

	/**
	 * Fields written in this request without the lock, marked stale again after the write.
	 *
	 * @var array<int, bool>
	 */
	private static $unlocked_writes = array();

	/**
	 * @since 7.0
	 *
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'frm_pro_meta_index';
	}

	/**
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function install() {
		global $wpdb;

		if ( 1 === (int) get_option( 'frmpro_meta_index_schema_version' ) ) {
			return;
		}

		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}

		$table     = self::table_name();
		$collation = $wpdb->get_charset_collate();
		$sql       = 'CREATE TABLE ' . $table . ' (
			meta_id bigint(20) NOT NULL,
			field_id bigint(20) NOT NULL,
			item_id bigint(20) NOT NULL,
			value_text varchar(150) NOT NULL,
			PRIMARY KEY  (meta_id),
			KEY field_value (field_id,value_text,item_id),
			KEY field_item (field_id,item_id),
			KEY field_meta (field_id,meta_id),
			KEY item_id (item_id)
		) ' . $collation . ';';

		dbDelta( $sql );
		$wpdb->query( $wpdb->prepare( 'SELECT 1 FROM %i LIMIT 0', $table ) );

		if ( $wpdb->last_error ) {
			set_transient( 'frmpro_meta_index_install_failed', 1, DAY_IN_SECONDS );
			return;
		}

		update_option( 'frmpro_meta_index_schema_version', 1, false );
		delete_transient( 'frmpro_meta_index_install_failed' );
	}

	/**
	 * Install the table on first use, retrying a failed install daily instead of on every indexed read.
	 *
	 * @since 7.0
	 *
	 * @return bool Whether the table is installed.
	 */
	private static function maybe_install() {
		if ( 1 === (int) get_option( 'frmpro_meta_index_schema_version' ) ) {
			return true;
		}

		if ( false !== get_transient( 'frmpro_meta_index_install_failed' ) ) {
			return false;
		}

		self::install();
		return 1 === (int) get_option( 'frmpro_meta_index_schema_version' );
	}

	/**
	 * Remove derived index data when Pro is uninstalled.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function uninstall() {
		global $wpdb;
		wp_clear_scheduled_hook( 'frm_pro_meta_index_prune' );
		delete_transient( 'frmpro_meta_index_install_failed' );

		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', self::table_name() ) );
		$option_names = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT option_name FROM %i WHERE option_name LIKE %s',
				$wpdb->options,
				$wpdb->esc_like( 'frmpro_meta_index_' ) . '%'
			)
		);

		foreach ( (array) $option_names as $option_name ) {
			if ( preg_match( '/^frmpro_meta_index_([0-9]+)$/', $option_name, $matches ) ) {
				wp_clear_scheduled_hook( 'frm_pro_meta_index_backfill', array( (int) $matches[1] ) );
			}

			delete_option( $option_name );
		}
	}

	/**
	 * Register a source field on demand. Existing queries remain in use during backfill.
	 *
	 * @since 7.0
	 *
	 * @param object $field Source field.
	 *
	 * @return bool Whether the field is ready for indexed queries.
	 */
	public static function register_field( $field ) {
		if ( ! self::is_available() || ! self::supports_field( $field ) || ! apply_filters( 'frm_use_meta_index', true, $field ) ) {
			return false;
		}

		if ( ! self::maybe_install() ) {
			return false;
		}

		$field_id = (int) $field->id;
		self::add_registered_field( $field_id );

		if ( isset( self::$write_locks[ $field_id ] ) ) {
			// This request is between the before and after hooks of a source write.
			return false;
		}

		if ( FrmProMetaIndexStorage::is_known_ready( $field_id ) ) {
			return true;
		}

		$status = FrmProMetaIndexStorage::get_status( $field_id );
		$state  = $status['state'];

		if ( is_array( $state ) && 'disabled' === ( $state['status'] ?? '' ) ) {
			return false;
		}

		if ( $status['flagged'] || ( is_array( $state ) && empty( $state['hooks_version'] ) ) ) {
			// A live writer or backfill batch holds the lock. Otherwise the flag is stale and the field is rebuilt.
			if ( ! FrmProMetaIndexStorage::acquire_lock( $field_id ) ) {
				self::schedule_backfill( $field_id );
				return false;
			}

			try {
				$state = self::reset_locked_field( $field_id );
			} finally {
				FrmProMetaIndexStorage::release_lock( $field_id );
			}

			if ( ! is_array( $state ) ) {
				self::schedule_backfill( $field_id );
				return false;
			}
		}

		if ( is_array( $state ) && 'ready' === ( $state['status'] ?? '' ) ) {
			if ( ( $state['used_at'] ?? 0 ) < time() - DAY_IN_SECONDS ) {
				FrmProMetaIndexStorage::touch_field( $field_id );
			}

			if ( ! $status['flagged'] ) {
				FrmProMetaIndexStorage::remember_ready( $field_id );
			}

			return true;
		}

		if ( false === $state ) {
			add_option(
				self::option_name( $field_id ),
				array(
					'hooks_version' => 1,
					'status'        => 'building',
					'cursor'        => 0,
					'used_at'       => time(),
				),
				'',
				false
			);
		}

		if ( false === $state || 'building' === ( $state['status'] ?? '' ) ) {
			if ( ! isset( self::$foreground_backfills[ $field_id ] ) ) {
				self::$foreground_backfills[ $field_id ] = true;
				self::backfill( $field_id, true );

				if ( self::is_ready( $field_id ) ) {
					return true;
				}
			}

			self::schedule_backfill( $field_id );
		}

		return false;
	}

	/**
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function schedule_pruning() {
		if ( ! wp_next_scheduled( 'frm_pro_meta_index_prune' ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', 'frm_pro_meta_index_prune' );
		}
	}

	/**
	 * Discard fields no longer read by any active Lookup or View.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function prune_unused_fields() {
		global $wpdb;

		$option_names = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT option_name FROM %i WHERE option_name LIKE %s',
				$wpdb->options,
				$wpdb->esc_like( 'frmpro_meta_index_' ) . '%'
			)
		);

		foreach ( (array) $option_names as $option_name ) {
			if ( ! preg_match( '/^frmpro_meta_index_([0-9]+)$/', $option_name, $matches ) ) {
				continue;
			}

			$state = get_option( $option_name );

			if ( ! is_array( $state ) || ( $state['used_at'] ?? 0 ) >= time() - 90 * DAY_IN_SECONDS ) {
				continue;
			}

			self::delete_field( (int) $matches[1] );
		}
	}

	/**
	 * @since 7.0
	 *
	 * @param object $field Source field.
	 *
	 * @return bool
	 */
	public static function supports_field( $field ) {
		if ( ! is_object( $field ) || empty( $field->id ) || ! empty( $field->field_options['post_field'] ) ) {
			return false;
		}

		if ( FrmField::is_field_with_multiple_values( $field ) ) {
			return false;
		}

		return in_array( $field->type, array( 'text', 'email', 'phone', 'url', 'select', 'radio', 'hidden' ), true );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return bool
	 */
	public static function is_ready( $field_id ) {
		$status = FrmProMetaIndexStorage::get_status( $field_id );
		$state  = $status['state'];
		return self::is_available() && ! $status['flagged'] && ! empty( $state['hooks_version'] ) && 'ready' === ( $state['status'] ?? '' );
	}

	/**
	 * Process backfill batches within a time budget.
	 *
	 * The lock is taken for one batch at a time so source writes wait briefly for it
	 * instead of missing it and forcing another rebuild.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 * @param bool $foreground Whether this is a small amount of work on a read request.
	 *
	 * @return void
	 */
	public static function backfill( $field_id, $foreground = false ) {
		$field_id = absint( $field_id );

		if ( ! self::is_available() || isset( self::$write_locks[ $field_id ] ) ) {
			return;
		}

		$deadline = microtime( true ) + ( $foreground ? 0.25 : 10 );

		do {
			if ( ! FrmProMetaIndexStorage::acquire_lock( $field_id ) ) {
				self::schedule_backfill( $field_id );
				return;
			}

			try {
				$has_more = self::process_backfill_batch( $field_id );
			} finally {
				FrmProMetaIndexStorage::release_lock( $field_id );
			}
		} while ( $has_more && microtime( true ) < $deadline );

		if ( $has_more ) {
			self::schedule_backfill( $field_id );
		}
	}

	/**
	 * Index one batch while holding the same lock as source writes.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return bool Whether more batches remain.
	 */
	private static function process_backfill_batch( $field_id ) {
		global $wpdb;

		$state = self::reset_locked_field( $field_id );

		if ( ! is_array( $state ) || 'building' !== ( $state['status'] ?? '' ) ) {
			return false;
		}

		if ( ! self::supports_field( FrmField::getOne( $field_id ) ) ) {
			self::disable_field( $field_id );
			return false;
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, meta_value FROM %i WHERE field_id = %d AND id > %d ORDER BY id ASC LIMIT %d',
				$wpdb->prefix . 'frm_item_metas',
				$field_id,
				$state['cursor'],
				self::BATCH_SIZE
			)
		);

		if ( ! is_array( $rows ) || $wpdb->last_error ) {
			self::schedule_backfill( $field_id );
			return false;
		}

		foreach ( $rows as $row ) {
			if ( ! self::is_scalar_value( $row->meta_value ) ) {
				self::disable_field( $field_id );
				return false;
			}
		}

		if ( count( $rows ) > 0 ) {
			$last_row = end( $rows );
			$result   = $wpdb->query(
				$wpdb->prepare(
					'INSERT IGNORE INTO %i (meta_id, field_id, item_id, value_text)
					SELECT id, field_id, item_id, meta_value FROM %i
					WHERE field_id = %d AND id > %d AND id <= %d AND LENGTH(meta_value) <= %d',
					self::table_name(),
					$wpdb->prefix . 'frm_item_metas',
					$field_id,
					$state['cursor'],
					$last_row->id,
					self::MAX_VALUE_LENGTH
				)
			);

			if ( false === $result ) {
				self::schedule_backfill( $field_id );
				return false;
			}

			$state['cursor'] = (int) $last_row->id;
		}

		if ( count( $rows ) < self::BATCH_SIZE ) {
			$state['status'] = 'ready';
			FrmProMetaIndexStorage::save_state( $field_id, $state );
			return false;
		}

		FrmProMetaIndexStorage::save_state( $field_id, $state );
		return true;
	}

	/**
	 * Rebuild a field from scratch when its flag outlived the write that set it.
	 *
	 * Call only while holding the field lock. Holding the lock proves no live writer
	 * owns a pending flag, so any flag found here belongs to a request that died or
	 * to a write that ran without the lock.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return array|false The current state, or false when the reset failed.
	 */
	private static function reset_locked_field( $field_id ) {
		global $wpdb;

		$status = FrmProMetaIndexStorage::get_status( $field_id );
		$state  = $status['state'];

		if ( false === $state && ! $status['flagged'] ) {
			// The field was deleted or never registered.
			return false;
		}

		if ( is_array( $state ) && ( 'disabled' === ( $state['status'] ?? '' ) || ( ! $status['flagged'] && ! empty( $state['hooks_version'] ) ) ) ) {
			return $state;
		}

		// Clear the flag before reading the source so a write that lands during the rebuild flags it again.
		FrmProMetaIndexStorage::clear_flag( $field_id );

		if ( false === $wpdb->delete( self::table_name(), array( 'field_id' => $field_id ), array( '%d' ) ) ) {
			FrmProMetaIndexStorage::mark_stale( $field_id );
			return false;
		}

		$state = array(
			'hooks_version' => 1,
			'status'        => 'building',
			'cursor'        => 0,
			'used_at'       => time(),
		);
		FrmProMetaIndexStorage::save_state( $field_id, $state );
		unset( self::$foreground_backfills[ $field_id ] );

		return $state;
	}

	/**
	 * Refresh one indexed field after a Lite meta write or delete.
	 *
	 * @since 7.0
	 *
	 * @param int $item_id Entry ID.
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	public static function refresh_meta( $item_id, $field_id ) {
		if ( isset( self::$unlocked_writes[ $field_id ] ) ) {
			// Mark again now the source row is written, in case a rebuild cleared the flag mid-write.
			unset( self::$unlocked_writes[ $field_id ] );
			FrmProMetaIndexStorage::mark_stale( $field_id );
			self::schedule_backfill( (int) $field_id );
			return;
		}

		if ( ! isset( self::$write_locks[ $field_id ] ) ) {
			return;
		}

		try {
			self::refresh_locked_meta( $item_id, $field_id );
			FrmProMetaIndexStorage::clear_pending_flag( $field_id );
		} finally {
			unset( self::$write_locks[ $field_id ] );
			FrmProMetaIndexStorage::release_lock( $field_id );
		}
	}

	/**
	 * Refresh source rows with the write lock held.
	 *
	 * @since 7.0
	 *
	 * @param int $item_id Entry ID.
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	private static function refresh_locked_meta( $item_id, $field_id ) {
		global $wpdb;

		$field_id = absint( $field_id );
		$state    = FrmProMetaIndexStorage::get_state( $field_id );

		if ( ! is_array( $state ) || 'disabled' === ( $state['status'] ?? '' ) ) {
			return;
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, meta_value FROM %i WHERE item_id = %d AND field_id = %d',
				$wpdb->prefix . 'frm_item_metas',
				$item_id,
				$field_id
			)
		);

		if ( null === $rows || $wpdb->last_error ) {
			FrmProMetaIndexStorage::mark_stale( $field_id );
			return;
		}

		$deleted = $wpdb->delete(
			self::table_name(),
			array(
				'item_id'  => $item_id,
				'field_id' => $field_id,
			),
			array( '%d', '%d' )
		);

		if ( false === $deleted ) {
			FrmProMetaIndexStorage::mark_stale( $field_id );
			return;
		}

		foreach ( $rows as $row ) {
			if ( ! self::is_scalar_value( $row->meta_value ) ) {
				self::disable_field( $field_id );
				return;
			}

			if ( ! self::store_row( $row->id, $field_id, $item_id, $row->meta_value ) ) {
				FrmProMetaIndexStorage::mark_stale( $field_id );
				return;
			}
		}
	}

	/**
	 * Refresh a field updated outside the normal entry save path.
	 *
	 * @since 7.0
	 *
	 * @param array $atts Updated field attributes, including entry and field IDs.
	 *
	 * @return void
	 */
	public static function refresh_updated_field( $atts ) {
		if ( isset( $atts['entry_id'], $atts['field_id'] ) ) {
			self::refresh_meta( $atts['entry_id'], $atts['field_id'] );
		}
	}

	/**
	 * @since 7.0
	 *
	 * @param int $item_id Entry ID.
	 *
	 * @return void
	 */
	public static function delete_entry( $item_id ) {
		global $wpdb;

		if ( ! get_option( 'frmpro_meta_index_fields', array() ) ) {
			return;
		}

		$wpdb->delete( self::table_name(), array( 'item_id' => $item_id ), array( '%d' ) );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	public static function delete_field( $field_id ) {
		if ( false === get_option( self::option_name( $field_id ) ) ) {
			return;
		}

		wp_clear_scheduled_hook( 'frm_pro_meta_index_backfill', array( (int) $field_id ) );
		self::disable_field( $field_id );
		delete_option( self::option_name( $field_id ) );
		FrmProMetaIndexStorage::clear_flag( $field_id );

		$fields = (array) get_option( 'frmpro_meta_index_fields', array() );
		unset( $fields[ $field_id ] );
		update_option( 'frmpro_meta_index_fields', $fields, true );
	}

	/**
	 * Exact scalar matches used by dependent Lookups.
	 *
	 * @since 7.0
	 *
	 * @param object $field Source field.
	 * @param mixed  $value Saved value.
	 * @param array  $args Lookup query arguments.
	 *
	 * @return array|false Matching entry IDs or false when the original query is required.
	 */
	public static function find_entry_ids( $field, $value, $args = array() ) {
		global $wpdb;

		if ( ! self::register_field( $field ) || ! is_scalar( $value ) || strlen( (string) $value ) > self::MAX_VALUE_LENGTH ) {
			return false;
		}

		$allowed_args = array( 'and_or', 'comparison_type', 'entry_ids', 'is_draft', 'user_id' );

		foreach ( array_keys( $args ) as $key ) {
			if ( ! in_array( $key, $allowed_args, true ) ) {
				return false;
			}
		}

		if ( isset( $args['comparison_type'] ) && 'equals' !== $args['comparison_type'] ) {
			return false;
		}

		$draft = isset( $args['is_draft'] ) ? (string) $args['is_draft'] : '0';

		if ( 'both' === $draft ) {
			$draft_values = array( 0, 1 );
		} elseif ( 'all' === $draft ) {
			$draft_values = array();
		} else {
			$draft_values = array_map( 'trim', explode( ',', $draft ) );

			if ( array_diff( $draft_values, array( '0', '1', '2', '3', '4' ) ) ) {
				return false;
			}

			$draft_values = array_map( 'intval', array_unique( $draft_values ) );
		}

		$entry_ids = isset( $args['entry_ids'] ) ? array_map( 'absint', (array) $args['entry_ids'] ) : array();

		if ( isset( $args['entry_ids'] ) && ! $entry_ids ) {
			return array();
		}

		if ( ! FrmProMetaIndexQuery::is_selective( $field->id, $value ) ) {
			return false;
		}

		if ( ! $entry_ids && ! isset( $args['user_id'] ) && $draft_values ) {
			$ids = self::find_view_entry_ids( $field, $value, $draft_values );
		} else {
			$ids = self::find_entry_ids_with_args( $field, $value, $entry_ids, $draft_values, $args );
		}

		if ( null === $ids || $wpdb->last_error ) {
			return false;
		}

		if ( $entry_ids ) {
			$ids = array_intersect( $ids, $entry_ids );
		}

		return (array) $ids;
	}

	/**
	 * @since 7.0
	 *
	 * @param object $field        Source field.
	 * @param mixed  $value        Saved value.
	 * @param array  $draft_values Allowed draft statuses.
	 *
	 * @return array|null Matching entry IDs, or null on a database error.
	 */
	private static function find_view_entry_ids( $field, $value, $draft_values ) {
		global $wpdb;

		return $wpdb->get_col(
			$wpdb->prepare(
				'SELECT idx.item_id FROM %i idx
				INNER JOIN %i em ON em.id = idx.meta_id AND BINARY em.meta_value = BINARY idx.value_text
				INNER JOIN %i e ON e.id = idx.item_id
				WHERE idx.field_id = %d AND idx.value_text = %s AND e.form_id = %d
				AND e.is_draft IN ( ' . implode( ', ', array_fill( 0, count( $draft_values ), '%d' ) ) . ' )',
				array_merge(
					array(
						self::table_name(),
						$wpdb->prefix . 'frm_item_metas',
						$wpdb->prefix . 'frm_items',
						$field->id,
						(string) $value,
						$field->form_id,
					),
					$draft_values
				)
			)
		);
	}

	/**
	 * @since 7.0
	 *
	 * @param object $field        Source field.
	 * @param mixed  $value        Saved value.
	 * @param array  $entry_ids    Optional entry IDs.
	 * @param array  $draft_values Allowed draft statuses.
	 * @param array  $args         Lookup query arguments.
	 *
	 * @return array|null Matching entry IDs, or null on a database error.
	 */
	private static function find_entry_ids_with_args( $field, $value, $entry_ids, $draft_values, $args ) {
		global $wpdb;

		$any_draft    = $draft_values ? 0 : 1;
		$draft_values = $draft_values ? $draft_values : array( -1 );
		$any_user     = isset( $args['user_id'] ) ? 0 : 1;
		$user_id      = isset( $args['user_id'] ) ? (int) $args['user_id'] : 0;

		if ( $entry_ids ) {
			return $wpdb->get_col(
				$wpdb->prepare(
					'SELECT idx.item_id FROM %i idx
					INNER JOIN %i em ON em.id = idx.meta_id AND BINARY em.meta_value = BINARY idx.value_text
					INNER JOIN %i e ON e.id = idx.item_id
					WHERE idx.field_id = %d AND idx.value_text = %s AND e.form_id = %d
					AND idx.item_id BETWEEN %d AND %d
					AND ( %d = 1 OR e.is_draft IN ( ' . implode( ', ', array_fill( 0, count( $draft_values ), '%d' ) ) . ' ) ) AND ( %d = 1 OR e.user_id = %d )',
					array_merge(
						array(
							self::table_name(),
							$wpdb->prefix . 'frm_item_metas',
							$wpdb->prefix . 'frm_items',
							$field->id,
							(string) $value,
							$field->form_id,
							min( $entry_ids ),
							max( $entry_ids ),
							$any_draft,
						),
						$draft_values,
						array(
							$any_user,
							$user_id,
						)
					)
				)
			);
		}

		return $wpdb->get_col(
			$wpdb->prepare(
				'SELECT idx.item_id FROM %i idx
				INNER JOIN %i em ON em.id = idx.meta_id AND BINARY em.meta_value = BINARY idx.value_text
				INNER JOIN %i e ON e.id = idx.item_id
				WHERE idx.field_id = %d AND idx.value_text = %s AND e.form_id = %d
				AND ( %d = 1 OR e.is_draft IN ( ' . implode( ', ', array_fill( 0, count( $draft_values ), '%d' ) ) . ' ) ) AND ( %d = 1 OR e.user_id = %d )',
				array_merge(
					array(
						self::table_name(),
						$wpdb->prefix . 'frm_item_metas',
						$wpdb->prefix . 'frm_items',
						$field->id,
						(string) $value,
						$field->form_id,
						$any_draft,
					),
					$draft_values,
					array(
						$any_user,
						$user_id,
					)
				)
			)
		);
	}

	/**
	 * Acquire the source field lock before Lite changes any rows.
	 *
	 * @since 7.0
	 *
	 * @param int $item_id Entry ID.
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	public static function begin_meta_change( $item_id, $field_id ) {
		$fields = (array) get_option( 'frmpro_meta_index_fields', array() );

		// Only test existence here. WordPress caches missing options for unindexed fields.
		if ( ! self::is_available() || ( ! isset( $fields[ $field_id ] ) && false === get_option( self::option_name( $field_id ) ) ) ) {
			return;
		}

		if ( isset( self::$write_locks[ $field_id ] ) ) {
			// A nested write would release the outer write's lock early, so leave the field for a rebuild.
			FrmProMetaIndexStorage::mark_stale( $field_id );
			return;
		}

		if ( ! FrmProMetaIndexStorage::acquire_lock( $field_id, self::WRITE_LOCK_WAIT ) ) {
			// Never block the source write. Readers fall back until the field is rebuilt.
			FrmProMetaIndexStorage::mark_stale( $field_id );
			self::$unlocked_writes[ $field_id ] = true;
			return;
		}

		// Does not replace a stale flag, which only a rebuild may clear.
		FrmProMetaIndexStorage::add_pending_flag( $field_id );
		self::$write_locks[ $field_id ] = true;
	}

	/**
	 * Leave all registered fields on the source tables after an unsupported lifecycle.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function invalidate_all() {
		global $wpdb;

		// Individual states also cover a registry update lost to a concurrent request.
		$option_names = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT option_name FROM %i WHERE option_name LIKE %s',
				$wpdb->options,
				$wpdb->esc_like( 'frmpro_meta_index_' ) . '%'
			)
		);

		foreach ( (array) $option_names as $option_name ) {
			if ( preg_match( '/^frmpro_meta_index_([0-9]+)$/', $option_name, $matches ) ) {
				FrmProMetaIndexStorage::mark_stale( (int) $matches[1] );
			}
		}
	}

	/**
	 * Invalidate derived data when Lite cannot maintain it.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function check_compatibility() {
		if ( ! self::is_available() ) {
			self::invalidate_all();
		}
	}

	/**
	 * Verify the Lite capability instead of guessing a release version.
	 *
	 * @since 7.0
	 *
	 * @return bool
	 */
	private static function is_available() {
		return is_callable( 'FrmEntryMeta::supports_entry_meta_change_hooks' ) && FrmEntryMeta::supports_entry_meta_change_hooks();
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Field ID.
	 *
	 * @return string
	 */
	private static function option_name( $field_id ) {
		return 'frmpro_meta_index_' . absint( $field_id );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	private static function add_registered_field( $field_id ) {
		$fields = (array) get_option( 'frmpro_meta_index_fields', array() );

		if ( isset( $fields[ $field_id ] ) ) {
			return;
		}

		$fields[ $field_id ] = 1;
		update_option( 'frmpro_meta_index_fields', $fields, true );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	private static function schedule_backfill( $field_id ) {
		if ( ! wp_next_scheduled( 'frm_pro_meta_index_backfill', array( $field_id ) ) ) {
			wp_schedule_single_event( time() + 10, 'frm_pro_meta_index_backfill', array( $field_id ) );
		}
	}

	/**
	 * @since 7.0
	 *
	 * @param mixed $value Stored value.
	 *
	 * @return bool
	 */
	private static function is_scalar_value( $value ) {
		return is_string( $value ) && strlen( $value ) <= self::MAX_VALUE_LENGTH && ! is_serialized( $value );
	}

	/**
	 * @since 7.0
	 *
	 * @param int    $meta_id Meta row ID.
	 * @param int    $field_id Field ID.
	 * @param int    $item_id Entry ID.
	 * @param string $value Stored value.
	 *
	 * @return bool
	 */
	private static function store_row( $meta_id, $field_id, $item_id, $value ) {
		global $wpdb;

		$result = $wpdb->replace(
			self::table_name(),
			array(
				'meta_id'    => $meta_id,
				'field_id'   => $field_id,
				'item_id'    => $item_id,
				'value_text' => $value,
			),
			array( '%d', '%d', '%d', '%s' )
		);

		return false !== $result;
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	private static function disable_field( $field_id ) {
		global $wpdb;
		FrmProMetaIndexStorage::save_state(
			$field_id,
			array(
				'hooks_version' => 1,
				'status'        => 'disabled',
				'cursor'        => 0,
				'used_at'       => time(),
			)
		);
		$wpdb->delete( self::table_name(), array( 'field_id' => $field_id ), array( '%d' ) );
	}
}
