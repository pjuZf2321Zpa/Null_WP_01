<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Decides when the meta index is faster than the source tables, and matches several values at once.
 *
 * @since 7.0
 */
class FrmProMetaIndexQuery {

	/**
	 * Matches at or below this count always use the index, however large a share of the field they are.
	 */
	const SELECTIVE_MATCH_LIMIT = 1000;

	/**
	 * The most parent values matched in one query. Lookups with more fall back to one query per parent.
	 */
	const MAX_CONDITIONS = 3;

	/**
	 * Estimated index rows per field, keyed by field ID.
	 *
	 * @var array<int, int>
	 */
	private static $field_row_estimates = array();

	/**
	 * Estimated index rows per field and value, keyed by field ID and value joined by a null byte.
	 *
	 * A cascade reads the same parent value once per child, so one EXPLAIN serves them all.
	 * Kept for the whole request, like the field estimates. A stale estimate only
	 * changes whether the index is used, never which entries match.
	 *
	 * @var array<string, int>
	 */
	private static $match_estimates = array();

	/**
	 * Entries matching every field and value at once, for a Lookup with several parents.
	 *
	 * One query lets the database start from the narrowest value instead of
	 * collecting every entry that matches the first, often broad, parent.
	 *
	 * @since 7.0
	 *
	 * @param array<int, array{0: stdClass, 1: mixed}> $conditions List of array( source field, saved value ) pairs.
	 * @param array                                     $args       Lookup query arguments. Only user_id is supported.
	 *
	 * @return array|false Matching entry IDs or false when the original queries are required.
	 */
	public static function find_entry_ids_for_all( $conditions, $args = array() ) {
		global $wpdb;

		if ( ! $conditions || count( $conditions ) > self::MAX_CONDITIONS || array_diff( array_keys( $args ), array( 'user_id' ) ) ) {
			return false;
		}

		$form_id     = (int) $conditions[0][0]->form_id;
		$is_narrowed = false;
		$index       = FrmProMetaIndex::table_name();
		$metas       = $wpdb->prefix . 'frm_item_metas';
		$joins       = '';
		$tables      = array( $index, $metas );
		$where       = '';
		$params      = array();

		foreach ( array_values( $conditions ) as $i => $condition ) {
			list( $field, $value ) = $condition;

			if ( (int) $field->form_id !== $form_id || ! is_scalar( $value ) || strlen( (string) $value ) > FrmProMetaIndex::MAX_VALUE_LENGTH ) {
				return false;
			}

			if ( ! FrmProMetaIndex::register_field( $field ) ) {
				return false;
			}

			if ( ! $is_narrowed ) {
				$is_narrowed = self::is_selective( $field->id, $value );
			}

			// The alias is built from the loop counter only, so it is safe in the query.
			$alias = (string) $i;

			if ( 0 !== $i ) {
				$joins   .= ' INNER JOIN %i c' . $alias . ' ON c' . $alias . '.item_id = c0.item_id';
				$joins   .= ' INNER JOIN %i m' . $alias . ' ON m' . $alias . '.id = c' . $alias . '.meta_id';
				$joins   .= ' AND BINARY m' . $alias . '.meta_value = BINARY c' . $alias . '.value_text';
				$tables[] = $index;
				$tables[] = $metas;
			}

			$where   .= ' AND c' . $alias . '.field_id = %d AND c' . $alias . '.value_text = %s';
			$params[] = (int) $field->id;
			$params[] = (string) $value;
		}

		if ( ! $is_narrowed ) {
			// Every value matches most of its field, so the source tables are faster.
			return false;
		}

		$tables[] = $wpdb->prefix . 'frm_items';

		$query = 'SELECT c0.item_id FROM %i c0
			INNER JOIN %i m0 ON m0.id = c0.meta_id AND BINARY m0.meta_value = BINARY c0.value_text' . $joins . '
			INNER JOIN %i e ON e.id = c0.item_id
			WHERE e.form_id = %d AND e.is_draft = 0 AND ( %d = 1 OR e.user_id = %d )' . $where;

		$values = array_merge(
			$tables,
			array(
				$form_id,
				isset( $args['user_id'] ) ? 0 : 1,
				isset( $args['user_id'] ) ? (int) $args['user_id'] : 0,
			),
			$params
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$ids = $wpdb->get_col( $wpdb->prepare( $query, $values ) );

		if ( ! is_array( $ids ) || $wpdb->last_error ) {
			return false;
		}

		// A field with two rows for one entry would repeat it.
		return array_values( array_unique( $ids ) );
	}

	/**
	 * Whether an exact match is narrow enough for the index to beat the source query.
	 *
	 * The index reads two extra rows per match to confirm it, so a value shared by
	 * most of a field is faster to find by scanning the source tables.
	 *
	 * @since 7.0
	 *
	 * @param int|string $field_id Source field ID.
	 * @param mixed      $value    Saved value.
	 *
	 * @return bool
	 */
	public static function is_selective( $field_id, $value ) {
		$field_id = (int) $field_id;
		$matches  = self::estimate_matches( $field_id, (string) $value );

		if ( $matches <= self::SELECTIVE_MATCH_LIMIT ) {
			return true;
		}

		if ( ! isset( self::$field_row_estimates[ $field_id ] ) ) {
			self::$field_row_estimates[ $field_id ] = self::estimate_field_rows( $field_id );
		}

		return $matches * 2 <= self::$field_row_estimates[ $field_id ];
	}

	/**
	 * Read the optimizer's estimate, which an index dive keeps close for an exact match.
	 *
	 * @since 7.0
	 *
	 * @param int    $field_id Source field ID.
	 * @param string $value    Saved value.
	 *
	 * @return int Estimated rows, or 0 when the plan cannot be read.
	 */
	private static function estimate_matches( $field_id, $value ) {
		global $wpdb;

		$key = $field_id . "\0" . $value;

		if ( ! isset( self::$match_estimates[ $key ] ) ) {
			$plan = $wpdb->get_row(
				$wpdb->prepare( 'EXPLAIN SELECT item_id FROM %i WHERE field_id = %d AND value_text = %s', FrmProMetaIndex::table_name(), $field_id, $value )
			);

			self::$match_estimates[ $key ] = self::plan_rows( $plan );
		}

		return self::$match_estimates[ $key ];
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return int Estimated rows, or 0 when the plan cannot be read.
	 */
	private static function estimate_field_rows( $field_id ) {
		global $wpdb;

		$plan = $wpdb->get_row(
			$wpdb->prepare( 'EXPLAIN SELECT item_id FROM %i WHERE field_id = %d', FrmProMetaIndex::table_name(), $field_id )
		);

		return self::plan_rows( $plan );
	}

	/**
	 * @since 7.0
	 *
	 * @param mixed $plan The first row of an EXPLAIN result.
	 *
	 * @return int
	 */
	private static function plan_rows( $plan ) {
		return is_object( $plan ) && isset( $plan->rows ) ? (int) $plan->rows : 0;
	}
}
