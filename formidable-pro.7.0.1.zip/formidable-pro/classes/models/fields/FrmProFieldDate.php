<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * @since 3.0
 */
class FrmProFieldDate extends FrmFieldType {

	/**
	 * @var string
	 *
	 * @since 3.0
	 */
	protected $type = 'date';

	/**
	 * @var bool
	 */
	protected $array_allowed = false;

	protected function field_settings_for_type() {
		$settings = array(
			'autopopulate'   => true,
			'size'           => true,
			'unique'         => true,
			'clear_on_focus' => true,
			'invalid'        => true,
			'read_only'      => true,
			'prefix'         => true,
		);
		FrmProFieldsHelper::fill_default_field_display( $settings );
		return $settings;
	}

	/**
	 * @since 4.05
	 *
	 * @param string $name
	 */
	protected function builder_text_field( $name = '' ) {
		$html  = FrmProFieldsHelper::builder_page_prepend( $this->field );
		$field = parent::builder_text_field( $name );
		return str_replace( '[input]', $field, $html );
	}

	protected function extra_field_opts() {
		return array(
			'start_year' => '-10',
			'end_year'   => '+10',
			'locale'     => 'en',
			'max'        => '10',
		);
	}

	protected function fill_default_atts( &$atts ) {
		$defaults = array(
			'format' => false,
		);
		$atts     = wp_parse_args( $atts, $defaults );
	}

	/**
	 * @since 3.06.01
	 */
	public function translatable_strings() {
		$strings   = parent::translatable_strings();
		$strings[] = 'locale';
		return $strings;
	}

	/**
	 * @since 3.01.01
	 *
	 * @param array|object $field
	 * @param array        $display
	 * @param array        $values
	 */
	public function show_options( $field, $display, $values ) {
		if ( ! function_exists( 'frm_dates_autoloader' ) ) {
			$upgrade_data = self::get_dates_add_on_upgrade_link_data( true );
			$class        = '';

			if ( empty( $upgrade_data['oneclick'] ) ) {
				$class = ' frm_noallow';
			}
		}

		$locales = FrmAppHelper::locales( 'date' );
		include FrmProAppHelper::plugin_path() . '/classes/views/frmpro-fields/back-end/dates-advanced.php';

		parent::show_options( $field, $display, $values );
	}

	/**
	 * Gets data attributes for dates add on upgrade link.
	 *
	 * @param bool $prepend_data Prepend `data-` to the array key.
	 *
	 * @return array
	 */
	public static function get_dates_add_on_upgrade_link_data( $prepend_data = false ) {
		$data = array(
			'oneclick' => '',
			'requires' => '',
			'upgrade'  => __( 'Extra Datepicker options', 'formidable-pro' ),
			'medium'   => 'datepicker-options',
		);

		$upgrading = FrmProAddonsController::install_link( 'dates' );

		if ( isset( $upgrading['url'] ) ) {
			$data['oneclick'] = json_encode( $upgrading );
		} else {
			$data['requires'] = self::get_dates_add_on_required_plan();
		}

		if ( ! $prepend_data ) {
			return $data;
		}

		$new_data = array();

		foreach ( $data as $key => $value ) {
			$new_data[ 'data-' . $key ] = $value;
		}

		return $new_data;
	}

	/**
	 * Get required plan for Dates add on.
	 *
	 * @since 5.3
	 *
	 * @return string Empty string if no plan is required for active license.
	 */
	private static function get_dates_add_on_required_plan() {
		return FrmAddonsController::get_addon_required_plan( 20247260 );
	}

	/**
	 * @since 4.0
	 *
	 * @param array $args - Includes 'field', 'display', and 'values'
	 */
	public function show_primary_options( $args ) {
		$field = $args['field'];
		include FrmProAppHelper::plugin_path() . '/classes/views/frmpro-fields/back-end/calendar.php';

		parent::show_primary_options( $args );
	}

	public function prepare_field_value( $value, $atts ) {
		return FrmProAppHelper::maybe_convert_from_db_date( $value );
	}

	protected function html5_input_type() {
		return 'text';
	}

	/**
	 * Add extra classes on front-end input
	 *
	 * @since 3.01.04
	 */
	protected function get_input_class() {
		$class = '';

		if ( ! FrmField::is_read_only( $this->field ) ) {
			$class = 'frm_date';
		}

		return $class . ( FrmField::get_option( $this->field, 'range_field' ) || FrmField::get_option( $this->field, 'is_range_end_field' ) ? ' frm_date_range' : '' );
	}

	protected function load_field_scripts( $args ) {
		if ( FrmField::is_read_only( $this->field ) ) {
			return;
		}

		global $frm_vars;

		if ( ! isset( $frm_vars['datepicker_loaded'] ) || ! is_array( $frm_vars['datepicker_loaded'] ) ) {
			$frm_vars['datepicker_loaded'] = array();
		}

		if ( ! isset( $frm_vars['datepicker_loaded'][ $args['html_id'] ] ) ) {
			$static_html_id = $this->html_id();

			if ( $args['html_id'] == $static_html_id ) {
				$frm_vars['datepicker_loaded'][ $args['html_id'] ] = true;
			} else {
				// User wildcard for repeating fields
				$frm_vars['datepicker_loaded'][ '^' . $static_html_id ] = true;
			}
		}

		$entry_id = $frm_vars['editing_entry'] ?? 0;
		FrmProFieldsHelper::set_field_js( $this->field, $entry_id );
	}

	public function validate( $args ) {
		$errors = array();
		$value  = $args['value'];

		if ( $value == '' ) {
			return $errors;
		}

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			$frmpro_settings = FrmProAppHelper::get_settings();
			$formatted_date  = FrmProAppHelper::convert_date( $value, $frmpro_settings->date_format, 'Y-m-d' );

			// Check format before converting. Padding is ignored, so 1/1/1969 matches 01/01/1969.
			$round_trip = FrmProAppHelper::convert_date( $formatted_date, 'Y-m-d', $frmpro_settings->date_format );

			if ( $this->remove_leading_zeros( $value ) !== $this->remove_leading_zeros( $round_trip ) ) {
				$allow_it = apply_filters(
					'frm_allow_date_mismatch',
					false,
					array(
						'date'           => $value,
						'formatted_date' => $formatted_date,
					)
				);

				if ( ! $allow_it ) {
					$errors[ 'field' . $args['id'] ] = FrmFieldsHelper::get_error_msg( $this->field, 'invalid' );
				}
			}

			$value = $formatted_date;
			unset( $formatted_date );
		}

		$date = explode( '-', $value );

		if ( count( $date ) !== 3 || ! checkdate( (int) $date[1], (int) $date[2], (int) $date[0] ) ) {
			$errors[ 'field' . $args['id'] ] = FrmFieldsHelper::get_error_msg( $this->field, 'invalid' );
		}

		if ( ! $this->validate_year_is_within_range( $date[0] ) ) {
			$errors[ 'field' . $args['id'] ] = FrmFieldsHelper::get_error_msg( $this->field, 'invalid' );
		}

		return $errors;
	}

	/**
	 * Strips leading zeros from each run of digits, keeping at least one digit.
	 *
	 * @since 7.0
	 *
	 * @param false|string $date
	 *
	 * @return false|string
	 */
	private function remove_leading_zeros( $date ) {
		return is_string( $date ) ? preg_replace( '/(?<!\d)0+(?=\d)/', '', $date ) : $date;
	}

	/**
	 * @since 6.34 This method went from private to protected.
	 *
	 * @param string $year
	 *
	 * @return bool
	 */
	protected function validate_year_is_within_range( $year ) {
		$year       = (int) $year;
		$start_year = $this->maybe_convert_relative_year_to_int( 'start_year' );
		$end_year   = $this->maybe_convert_relative_year_to_int( 'end_year' );

		return ( ! $start_year || $start_year <= $year ) && ( ! $end_year || $year <= $end_year );
	}

	/**
	 * @since 6.34 This method went from private to protected.
	 *
	 * @param string $start_end
	 *
	 * @return int
	 */
	protected function maybe_convert_relative_year_to_int( $start_end ) {
		$rel_year = FrmField::get_option( $this->field, $start_end );

		if ( is_string( $rel_year ) && $rel_year !== '' && ( '0' === $rel_year || '+' === $rel_year[0] || '-' === $rel_year[0] || strlen( $rel_year ) < 4 ) ) {
			$rel_year = gmdate( 'Y', strtotime( $rel_year . ' year' ) );
		}

		return (int) $rel_year;
	}

	public function is_not_unique( $value, $entry_id ) {
		$value = FrmProAppHelper::maybe_convert_to_db_date( $value, 'Y-m-d' );
		return parent::is_not_unique( $value, $entry_id );
	}

	public function set_value_before_save( $value ) {
		return FrmProAppHelper::maybe_convert_to_db_date( $value, 'Y-m-d' );
	}

	protected function prepare_display_value( $value, $atts ) {
		if ( $value === false ) {
			return $value;
		}

		if ( isset( $atts['offset'] ) ) {
			$value = FrmProFieldsHelper::get_date( $value, 'Y-m-d H:i:s' );

			if ( isset( $atts['time_ago'] ) ) {
				$atts['format'] = 'Y-m-d H:i:s';
			} elseif ( empty( $atts['format'] ) ) {
				$atts['format'] = get_option( 'date_format' );
			}

			$value = FrmProFieldsHelper::get_date( gmdate( 'Y-m-d H:i:s', strtotime( $atts['offset'], strtotime( $value ) ) ), $atts['format'] );
		}

		if ( isset( $atts['time_ago'] ) ) {
			$value = FrmProFieldsHelper::get_date( $value, 'Y-m-d H:i:s' );
			$value = FrmAppHelper::human_time_diff( strtotime( $value ), strtotime( date_i18n( 'Y-m-d' ) ), $atts['time_ago'] );
		} elseif ( ! isset( $atts['offset'] ) ) {
			if ( ! is_array( $value ) && strpos( $value, ',' ) ) {
				$value = explode( ',', $value );
			}

			if ( ! empty( $atts['date_format'] ) ) {
				$atts['format'] = $atts['date_format'];
			}

			$value = FrmProFieldsHelper::format_values_in_array( $value, $atts['format'], 'FrmProFieldsHelper::get_date' );
		}

		return $value;
	}

	/**
	 * Reads an imported date with the site's own date format before falling
	 * back to strtotime, which would read 26/04/2021 on a d/m/Y site as
	 * 1970-01-01 and 05/04/2021 as May 4 instead of April 5.
	 *
	 * This runs for CSV and XML imports and for values sent to the REST API.
	 *
	 * A value that cannot be read at all comes back untouched, the way the base
	 * class treats a value it has nothing to do with. That keeps the failure
	 * visible: the REST API hands it to validation, which reports an invalid
	 * date instead of clearing the field and answering with a success. An import
	 * does not validate, so it drops the value itself. See
	 * FrmProXMLHelper::convert_field_values().
	 *
	 * @param mixed $value
	 * @param array $atts  A CSV import passes `date_format` when the file itself
	 *                     proved which of the day and month comes first.
	 *
	 * @return mixed The date as Y-m-d, or the value as it arrived.
	 */
	protected function prepare_import_value( $value, $atts ) {
		$from_format = ! empty( $atts['date_format'] ) ? (string) $atts['date_format'] : '';
		$date        = FrmProDateFormatHelper::parse_date_in_any_format( $value, 'Y-m-d', $from_format );

		if ( '' !== $date ) {
			return $date;
		}

		// Nothing could be read. Hand a string back so the caller can report it
		// as an invalid date, and empty for anything that never held one.
		return is_string( $value ) ? $value : '';
	}

	/**
	 * @since 4.0.04
	 *
	 * @param mixed $value
	 */
	public function sanitize_value( &$value ) {
		FrmAppHelper::sanitize_value( 'sanitize_text_field', $value );
	}

	/**
	 * Add extra HTML attributes to the input.
	 *
	 * @param array $args       Field arguments.
	 * @param mixed $input_html HTML input.
	 *
	 * @return void
	 */
	protected function add_extra_html_atts( $args, &$input_html ) {
		if ( ! empty( $this->field['range_field'] ) ) {
			$input_html .= ' data-field-id="' . (int) $this->field['id'] . '"';
		}

		if ( ! empty( $this->field['range_start_field'] ) ) {
			$input_html .= ' data-range-start-field-id="' . (int) $this->field['range_start_field'] . '"';
		}
	}
}
