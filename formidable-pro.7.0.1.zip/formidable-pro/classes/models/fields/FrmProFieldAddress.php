<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * @since 3.0
 */
class FrmProFieldAddress extends FrmFieldType {

	/**
	 * @var string
	 *
	 * @since 3.0
	 */
	protected $type = 'address';

	/**
	 * @var bool
	 *
	 * @since 3.0
	 */
	protected $has_for_label = false;

	protected function field_settings_for_type() {
		$settings = array(
			'clear_on_focus' => false, // Don't use the regular placeholder option.
			'default_value'  => true,
			'description'    => false,
			'visibility'     => true,
			'read_only'      => true,
		);

		if ( is_array( $this->default_value_to_array() ) ) {
			$settings['default'] = false;
		}

		FrmProFieldsHelper::fill_default_field_display( $settings );
		return $settings;
	}

	protected function extra_field_opts() {
		$options = array(
			'address_type' => 'international',
		);

		foreach ( $this->default_labels() as $key => $label ) {
			$options[ $key . '_desc' ] = $label;
		}

		return $options;
	}

	/**
	 * @since 4.0
	 *
	 * @param array $args - Includes 'field', 'display', and 'values'.
	 */
	public function show_primary_options( $args ) {
		$field                            = $args['field'];
		$should_show_address_type_warning = self::should_show_address_type_warning( $field );

		include FrmProAppHelper::plugin_path() . '/classes/views/combo-fields/addresses/back-end-field-opts.php';

		parent::show_primary_options( $args );
	}

	/**
	 * @since 6.25
	 *
	 * @param array $field
	 *
	 * @return bool
	 */
	private static function should_show_address_type_warning( $field ) {
		if ( ! isset( $field['address_type'] ) || 'generic' !== $field['address_type'] ) {
			return false;
		}

		$parent_form_id = $field['parent_form_id'] ?? $field['form_id'] ?? 0;

		if ( ! $parent_form_id ) {
			return false;
		}

		if ( ! is_callable( array( 'FrmSquareLiteActionsController', 'get_actions_before_submit' ) ) ) {
			return false;
		}

		// Get all square actions that have this address field assigned.
		$assigned_square_actions = array_filter(
			FrmSquareLiteActionsController::get_actions_before_submit( $parent_form_id ),
			function ( $action ) use ( $field ) {
				return ! empty( $action->post_content['billing_address'] ) && (int) $action->post_content['billing_address'] === (int) $field['id'];
			}
		);

		return (bool) $assigned_square_actions;
	}

	/**
	 * Include the settings for placeholder, default value, and sub labels for each
	 * of the individual field labels.
	 *
	 * @since 4.0
	 *
	 * @param array $args - Includes 'field', 'display'.
	 */
	public function show_after_default( $args ) {
		$field         = $args['field'];
		$default_value = $this->default_value_to_array();
		$sub_fields    = $this->all_default_labels();

		foreach ( $sub_fields as $name => $field_label ) {
			include FrmProAppHelper::plugin_path() . '/classes/views/frmpro-fields/back-end/default-placeholder.php';
		}

		if ( ! empty( $field['description'] ) ) {
			// This is here only for reverse compatibility.
			include FrmAppHelper::plugin_path() . '/classes/views/frm-fields/back-end/field-description.php';
		}
	}

	/**
	 * @since 3.06.01
	 */
	public function translatable_strings() {
		$strings   = parent::translatable_strings();
		$strings[] = 'line1_desc';
		$strings[] = 'line2_desc';
		$strings[] = 'city_desc';
		$strings[] = 'state_desc';
		$strings[] = 'zip_desc';
		$strings[] = 'country_desc';
		return $strings;
	}

	private function default_labels() {
		return array(
			'line1'   => '',
			'line2'   => '',
			'city'    => __( 'City', 'formidable' ),
			'state'   => __( 'State/Province', 'formidable' ),
			'zip'     => __( 'Zip/Postal', 'formidable' ),
			'country' => __( 'Country', 'formidable' ),
		);
	}

	/**
	 * @since 4.0
	 */
	private function all_default_labels() {
		$labels            = $this->default_labels();
		$labels['line1']   = __( 'Line 1', 'formidable' );
		$labels['line2']   = __( 'Line 2', 'formidable' );
		$labels['country'] = __( 'Country', 'formidable' );
		return $labels;
	}

	/**
	 * Gets ALL subfields, keyed the same way Lite's newer combo-field Address type
	 * (FrmFieldAddress) registers them, so a conditional logic trigger can target one of them
	 * (e.g. "{field_id}_state").
	 *
	 * This class predates FrmFieldCombo and doesn't extend it (and deliberately doesn't set
	 * `is_combo_field`, since that property also drives CSV export column splitting elsewhere
	 * and this method exists only to support conditional logic sub field targeting). Callers
	 * that need to know whether a field supports this should check
	 * `method_exists( $field_type_obj, 'get_sub_fields' )` directly rather than
	 * FrmField::is_combo_field().
	 *
	 * @since 7.0
	 *
	 * @return array
	 */
	public function get_sub_fields() {
		$sub_fields = array();

		foreach ( $this->all_default_labels() as $key => $label ) {
			$sub_fields[ $key ] = array( 'label' => $label );
		}

		return $sub_fields;
	}

	public function show_on_form_builder( $name = '' ) {
		// Lite's preview skips frm_address_sub_fields, so customized sub fields keep the Pro preview.
		if ( class_exists( 'FrmFieldAddress' ) && ! has_filter( 'frm_address_sub_fields' ) ) {
			$preview_obj = new FrmFieldAddress( $this->field );
			$preview_obj->show_on_form_builder( $name );
			return;
		}

		$field    = FrmFieldsHelper::setup_edit_vars( $this->field );
		$defaults = $this->empty_value_array();
		$this->fill_values( $field['default_value'], $defaults );

		$field['value'] = $field['default_value'];
		$sub_fields     = FrmProAddressesController::get_sub_fields( $field );
		$field_name     = $this->html_name( $name );
		$html_id        = $this->html_id();

		include FrmProAppHelper::plugin_path() . '/classes/views/combo-fields/input-form-builder.php';
	}

	public function front_field_input( $args, $shortcode_atts ) {
		$pass_args = array(
			'errors'   => $args['errors'],
			'html_id'  => $args['html_id'],
			'field_id' => $args['field_id'],
		);
		ob_start();
		FrmProAddressesController::show_in_form( $this->field, $args['field_name'], $pass_args );

		return ob_get_clean();
	}

	/**
	 * @param array $atts
	 *
	 * @return void
	 */
	protected function fill_default_atts( &$atts ) {
		parent::fill_default_atts( $atts );
		$defaults = array(
			'line_sep'    => ' <br/>',
			'force_array' => false,
		);
		$atts     = wp_parse_args( $atts, $defaults );
	}

	protected function prepare_display_value( $value, $atts ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		$keys_to_check                = array( 'line1', 'city', 'state', 'zip', 'country' );
		$at_least_one_field_populated = false;

		foreach ( $keys_to_check as $key ) {
			if ( ! empty( $value[ $key ] ) ) {
				$at_least_one_field_populated = true;
				break;
			}
		}

		if ( ! $at_least_one_field_populated ) {
			return '';
		}

		if ( ! isset( $value['line1'] ) ) {
			$value['line1'] = '';
		}

		return $this->format_address_for_display( $value, $atts );
	}

	/**
	 * @since 3.0.06
	 *
	 * @param array $value
	 * @param array $atts
	 */
	public function format_address_for_display( $value, $atts = array() ) {
		$defaults = $this->empty_value_array();
		$this->fill_values( $value, $defaults );

		$this->fill_default_atts( $atts );

		if ( $atts['force_array'] ) {
			return $value;
		}

		$format = $this->address_format_for_display( $atts, $value );

		foreach ( $defaults as $k => $part ) {
			$format = str_replace( '[' . $k . ']', $value[ $k ], $format );
		}

		return str_replace( $atts['line_sep'] . $atts['line_sep'], $atts['line_sep'], $format );
	}

	/**
	 * @since 3.0.06
	 *
	 * @param array $atts
	 * @param array $value
	 *
	 * @return string
	 */
	private function address_format_for_display( $atts, $value ) {
		if ( ! empty( $atts['show'] ) ) {
			return '[' . $atts['show'] . ']';
		}

		$line_sep       = $atts['line_sep'];
		$address_type   = FrmField::get_option( $this->field, 'address_type' );
		$address_format = '';

		if ( ! empty( $value['line1'] ) ) {
			$address_format = '[line1]' . $line_sep . '[line2]' . $line_sep;
		}

		if ( 'europe' === $address_type ) {
			$address_format .= '[zip] [city]';
		} else {
			$address_format .= '[city], [state] [zip]';
		}

		$address_format .= $line_sep . '[country]';

		/**
		 * Change the format of a displayed address
		 *
		 * @since 3.0.06
		 */
		return apply_filters( 'frm_address_format', $address_format, array( 'field' => $this->field ) );
	}

	/**
	 * @since 4.0
	 *
	 * @return array|string
	 */
	private function default_value_to_array() {
		$default_value = $this->get_field_column( 'default_value' );

		if ( ! $default_value ) {
			$default_value = array();
		} elseif ( ! is_array( $default_value ) && ! str_contains( $default_value, ']' ) ) {
			// This is a default value without a shortcode so tear it up.
			$default_value = $this->address_string_to_array( $default_value );
		}

		if ( is_array( $default_value ) ) {
			$defaults = $this->empty_value_array();
			$this->fill_values( $default_value, $defaults );
		}

		return $default_value;
	}

	public function address_string_to_array( $value ) {
		if ( is_array( $value ) ) {
			return $value;
		}

		$value             = array_map( 'trim', explode( ',', $value ) );
		$empty_array       = array_keys( $this->empty_value_array() );
		$array_length_diff = count( $empty_array ) - count( $value );

		if ( $array_length_diff === 1 ) {
			$value[] = '';
		} elseif ( $array_length_diff > 1 ) {
			$filler_array = array_fill( 0, $array_length_diff, '' );
			$value        = array_merge( $value, $filler_array );
		} elseif ( $array_length_diff < 0 ) {
			$value = array_slice( $value, 0, count( $empty_array ) );
		}

		return array_combine( $empty_array, $value );
	}

	/**
	 * @return array
	 */
	private function empty_value_array() {
		return FrmProAddressesController::empty_value_array();
	}

	/**
	 * Convert comma-separated address values to an associative array
	 *
	 * @since 2.02.13
	 *
	 * @param array|string $value
	 * @param array $atts
	 *
	 * @return array
	 */
	protected function prepare_import_value( $value, $atts ) {
		if ( is_array( $value ) ) {
			return $value;
		}

		$sep   = apply_filters( 'frm_csv_sep', ', ' );
		$value = explode( $sep, $value );
		$count = count( $value );

		if ( $count < 4 || $count > 6 ) {
			return $value;
		}

		$new_value = $this->empty_value_array();

		$new_value['line1'] = $value[0];

		$last_item = end( $value );

		if ( $count === 6 || ( $count === 5 && is_numeric( $last_item ) ) ) {
			$new_value['line2'] = $value[1];
			$new_value['city']  = $value[2];
			$new_value['state'] = $value[3];
			$new_value['zip']   = $value[4];

			if ( $count === 6 ) {
				$new_value['country'] = $value[5];
			}
		} else {
			$new_value['city']  = $value[1];
			$new_value['state'] = $value[2];
			$new_value['zip']   = $value[3];

			if ( $count === 5 ) {
				$new_value['country'] = $value[4];
			}
		}

		return $new_value;
	}

	public function validate( $args ) {
		$this->field->temp_id = $args['id'];

		$errors = array();
		self::validate_required_fields( $errors, $args );
		self::validate_zip( $errors, $args );

		return $errors;
	}

	/**
	 * @param array $errors
	 * @param array $args
	 *
	 * @return void
	 */
	private function validate_required_fields( &$errors, $args ) {
		if ( ! $this->field->required ) {
			return;
		}

		if ( FrmProEntryMeta::skip_required_validation( $this->field ) ) {
			return;
		}

		$values = $args['value'];

		if ( $values == '' ) {
			$values = FrmProAddressesController::empty_value_array();
		}

		$field_array          = (array) $this->field;
		$field_array['value'] = $this->field->default_value;
		$field_array          = array_merge( (array) $this->field->field_options, $field_array );
		$sub_fields           = FrmProAddressesController::get_sub_fields( $field_array );
		$required_count       = 0;
		$missing              = array();

		// A sub field left out of the posted value, like a tampered request, is still validated as empty.
		$values = array_merge( array_fill_keys( array_keys( $sub_fields ), '' ), is_array( $values ) ? $values : array() );

		foreach ( $values as $key => $value ) {
			$subfield_is_required = ! array_key_exists( $key, $sub_fields ) || empty( $sub_fields[ $key ]['optional'] );

			if ( ! $subfield_is_required ) {
				continue;
			}

			++$required_count;

			if ( ! $value ) {
				$missing[] = $key;
			}
		}

		if ( ! $missing ) {
			return;
		}

		if ( count( $missing ) === $required_count ) {
			// Nothing was filled in, so show one error for the whole field. The empty sub field
			// errors flag each required input without repeating the message under every one.
			foreach ( $missing as $key ) {
				$errors[ 'field' . $args['id'] . '-' . $key ] = '';
			}

			$errors[ 'field' . $args['id'] ] = FrmFieldsHelper::get_error_msg( $this->field, 'blank' );
			return;
		}

		// Only some sub fields are missing, so name each one in its own error.
		foreach ( $missing as $key ) {
			$errors[ 'field' . $args['id'] . '-' . $key ] = $this->get_sub_field_error_msg( $key, 'blank' );
		}
	}

	/**
	 * Gets an error message for a single sub field, with the sub field label in place of the
	 * field label.
	 *
	 * @since 7.0
	 *
	 * @param string $name  Sub field name, like 'line1' or 'city'.
	 * @param string $error Error type, like 'blank'.
	 *
	 * @return string
	 */
	public function get_sub_field_error_msg( $name, $error ) {
		// Keep compatibility with Lite versions without FrmFieldsHelper::get_error_msg_for_name().
		$field = is_object( $this->field ) ? clone $this->field : $this->field;

		if ( is_object( $field ) ) {
			$field->name = $this->get_sub_field_label( $name );
		} elseif ( is_array( $field ) ) {
			$field['name'] = $this->get_sub_field_label( $name );
		}

		return FrmFieldsHelper::get_error_msg( $field, $error );
	}

	/**
	 * Gets the label a sub field is referred to by in its error messages.
	 *
	 * Short descriptions are used as plain text labels. Longer help text falls back to the
	 * sub field label combined with the field label, like "Address Line 1".
	 *
	 * @since 7.0
	 *
	 * @param string $name Sub field name, like 'line1' or 'city'.
	 *
	 * @return string
	 */
	public function get_sub_field_label( $name ) {
		$desc = FrmField::get_option( $this->field, $name . '_desc' );

		if ( is_string( $desc ) ) {
			$desc = trim( wp_strip_all_tags( $desc ) );

			if ( '' !== $desc && count( (array) preg_split( '/\s+/', $desc ) ) <= 4 && ! preg_match( '/[.!?:;]$/', $desc ) ) {
				return $desc;
			}
		}

		$labels     = $this->all_default_labels();
		$field_name = $this->get_field_column( 'name' );
		$field_name = is_string( $field_name ) ? $field_name : '';

		if ( empty( $labels[ $name ] ) ) {
			return $field_name;
		}

		/* translators: 1: Field label, 2: Sub field label */
		return sprintf( __( '%1$s %2$s', 'formidable' ), $field_name, $labels[ $name ] );
	}

	private function validate_zip( &$errors, $args ) {
		$values = $args['value'];

		if ( empty( $values['zip'] ) ) {
			return;
		}

		$address_type = FrmField::get_option( $this->field, 'address_type' );
		$format       = '';

		if ( $address_type === 'us' ) {
			$format = '/^[0-9]{5}(?:-[0-9]{4})?$/';
		}

		$format = apply_filters( 'frm_zip_format', $format, array( 'field' => $this->field ) );

		if ( $format && ! preg_match( $format, $values['zip'] ) ) {
			$errors[ 'field' . $args['id'] . '-zip' ] = __( 'This value is invalid', 'formidable' );
		}
	}

	/**
	 * @since 4.0.04
	 *
	 * @param mixed $value
	 */
	public function sanitize_value( &$value ) {
		FrmAppHelper::sanitize_value( 'sanitize_text_field', $value );
	}

	/**
	 * Set the aria-invalid attribute for each address sub field so the error summary link
	 * focuses the sub field that actually failed validation, not always line 1.
	 *
	 * @since 7.0
	 *
	 * @param array $shortcode_atts
	 * @param array $args
	 *
	 * @return void
	 */
	public function set_aria_invalid_error( &$shortcode_atts, $args ) {
		$error_key_id = $this->get_address_error_key_id( $args );
		$field_array  = (array) $this->field;

		if ( ! isset( $field_array['address_type'] ) && ! empty( $field_array['field_options'] ) ) {
			// This field hasn't had its options flattened onto it yet, which get_sub_fields()
			// needs to know the address type. The front-end render path already did this before
			// building the field object, but other callers (e.g. tests) may not have.
			$field_array = array_merge( (array) $field_array['field_options'], $field_array );
		}

		$sub_fields = FrmProAddressesController::get_sub_fields( $field_array );

		foreach ( $sub_fields as $name => $sub_field ) {
			$shortcode_atts[ 'aria-invalid-' . $name ] = isset( $args['errors'][ 'field' . $error_key_id . '-' . $name ] ) ? 'true' : 'false';
		}
	}

	/**
	 * Get the field ID that error keys are indexed by while this field is being rendered.
	 *
	 * FrmFieldType::get_error_key_id() only exists on Lite versions that include the form
	 * errors accessibility work this method is part of. Older Lite versions don't have it, so
	 * fall back to the plain field ID (this field's behavior before repeater rows were handled)
	 * rather than fataling on a missing method.
	 *
	 * @since 7.0
	 *
	 * @param array $args Rendering context. May include `field_id`.
	 *
	 * @return int|string
	 */
	private function get_address_error_key_id( $args ) {
		if ( method_exists( $this, 'get_error_key_id' ) ) {
			return $this->get_error_key_id( $args );
		}

		return ! empty( $args['field_id'] ) ? $args['field_id'] : $this->field_id;
	}
}
