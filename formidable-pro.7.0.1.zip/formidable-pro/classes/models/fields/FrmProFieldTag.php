<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * @since 3.0
 */
class FrmProFieldTag extends FrmFieldType {

	/**
	 * @var string
	 *
	 * @since 3.0
	 */
	protected $type = 'tag';

	protected function field_settings_for_type() {
		$settings = array(
			'size'           => true,
			'clear_on_focus' => true,
			'prefix'         => true,
		);

		FrmProFieldsHelper::fill_default_field_display( $settings );
		return $settings;
	}

	/**
	 * @since 4.05
	 *
	 * @param string $name
	 */
	protected function builder_text_field( $name = '' ) {
		$html  = FrmProFieldsHelper::builder_page_prepend( $this->field );
		$field = parent::builder_text_field( $name );
		return str_replace( '[input]', $field, $html );
	}

	public function front_field_input( $args, $shortcode_atts ) {
		if ( is_array( $this->field['value'] ) ) {
			global $frm_vars;
			$entry_id = $frm_vars['editing_entry'] ?? 0;
			FrmProFieldsHelper::tags_to_list( $this->field, $entry_id );
		}

		$input_html = $this->get_field_input_html_hook( $this->field );
		$this->add_aria_description( $args, $input_html );

		return '<input type="text" id="' . esc_attr( $args['html_id'] ) . '" name="' . esc_attr( $args['field_name'] ) . '" value="' . esc_attr( $this->field['value'] ) . '" ' . $input_html . '/>';
	}

	/**
	 * Create new tags
	 *
	 * @since 3.0
	 *
	 * @param array|string $value (the posted value)
	 * @param array $atts
	 *
	 * @return array|string Value.
	 */
	public function get_value_to_save( $value, $atts ) {
		$this->create_new_tags( $value, $atts );
		return $value;
	}

	/**
	 * @param array|string $value
	 * @param array        $atts
	 *
	 * @return void
	 */
	private function create_new_tags( $value, $atts ) {
		$tax_type = FrmField::get_option( $this->field, 'taxonomy' );
		$tax_type = $tax_type ? $tax_type : 'frm_tag';

		$tags  = explode( ',', wp_unslash( $value ) );
		$terms = array();

		if ( isset( $_POST['frm_wp_post'] ) ) {
			$_POST['frm_wp_post'][ $this->get_field_column( 'id' ) . '=tags_input' ] = $tags;
		}

		if ( $tax_type !== 'frm_tag' ) {
			return;
		}

		foreach ( $tags as $tag ) {
			$slug = sanitize_title( $tag );

			if ( ! isset( $_POST['frm_wp_post'] ) && ! term_exists( $slug, $tax_type ) ) {
				wp_insert_term( trim( $tag ), $tax_type, array( 'slug' => $slug ) );
			}

			$terms[] = $slug;
		}

		wp_set_object_terms( $atts['entry_id'], $terms, $tax_type );
	}

	/**
	 * @since 4.0.04
	 *
	 * @param mixed $value
	 */
	public function sanitize_value( &$value ) {
		FrmAppHelper::sanitize_value( 'sanitize_text_field', $value );
	}
}
