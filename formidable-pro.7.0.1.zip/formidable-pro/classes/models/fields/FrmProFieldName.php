<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * @since 6.4
 */
class FrmProFieldName extends FrmFieldName {

	protected function field_settings_for_type() {
		$settings              = parent::field_settings_for_type();
		$settings['read_only'] = true;

		return $settings;
	}

	/**
	 * In a repeater, $value is an array of per-row name arrays instead of a
	 * single array( 'first' => ..., 'last' => ... ), since FrmProContent
	 * skips flattening a name field's sub entry values (see FrmProContent::
	 * replace_single_shortcode). Join each row's own display value instead
	 * of letting the parent implementation misread the row array as a
	 * single name.
	 *
	 * @since 7.0
	 *
	 * @param array|string $value
	 * @param array        $atts
	 *
	 * @return string
	 */
	public function get_display_value( $value, $atts = array() ) {
		// A single row is array( 'first' => ..., 'last' => ... ); a repeater's rows are array( array( 'first' => ..., 'last' => ... ), ... ).
		if ( ! is_array( $value ) || ! $value || ! is_array( reset( $value ) ) ) {
			return parent::get_display_value( $value, $atts );
		}

		$value = array_map(
			function ( $name ) use ( $atts ) {
				return parent::get_display_value( $name, $atts );
			},
			$value
		);

		return implode( ', ', $value );
	}
}
