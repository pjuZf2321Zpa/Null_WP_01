<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Persistent readiness checks and locks shared by indexed reads and source writes.
 *
 * Each field has a state option and an optional sync flag. The flag is '1' while a
 * writer holding the field lock changes the source rows, and 'stale' when a write
 * happened without the lock. Only the lock holder clears '1', and only a rebuild
 * clears 'stale'. Flags are written with raw queries because another request may
 * have changed them since this request cached the option.
 *
 * @since 7.0
 */
class FrmProMetaIndexStorage {

	const FLAG_PENDING = '1';
	const FLAG_STALE   = 'stale';

	/**
	 * Seconds a ready check is reused, which bounds how long a flag set by another request goes unseen.
	 */
	const READY_CACHE_SECONDS = 1;

	/**
	 * Fields confirmed ready and unflagged, keyed by field ID, with the time the check expires.
	 *
	 * @var array<int, float>
	 */
	private static $ready_until = array();

	/**
	 * Read readiness without request-local option cache races.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return array|false
	 */
	public static function get_state( $field_id ) {
		return self::get_status( $field_id )['state'];
	}

	/**
	 * Read the state and sync flag in a single query.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return array{state: array|false, flagged: bool}
	 */
	public static function get_status( $field_id ) {
		global $wpdb;

		$state_name = self::state_name( $field_id );
		$rows       = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT option_name, option_value FROM %i WHERE option_name IN (%s, %s)',
				$wpdb->options,
				$state_name,
				self::flag_name( $field_id )
			)
		);

		if ( ! is_array( $rows ) || $wpdb->last_error ) {
			// Treat a failed read as flagged so callers fall back to the source tables.
			return array(
				'state'   => false,
				'flagged' => true,
			);
		}

		$status = array(
			'state'   => false,
			'flagged' => false,
		);

		foreach ( $rows as $row ) {
			if ( $state_name === $row->option_name ) {
				$state           = maybe_unserialize( $row->option_value );
				$status['state'] = is_array( $state ) ? $state : false;
			} else {
				$status['flagged'] = true;
			}
		}

		return $status;
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return bool
	 */
	public static function is_dirty( $field_id ) {
		return self::get_status( $field_id )['flagged'];
	}

	/**
	 * Flag a write made while holding the field lock, without replacing a stale flag.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	public static function add_pending_flag( $field_id ) {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				'INSERT IGNORE INTO %i (option_name, option_value, autoload) VALUES (%s, %s, %s)',
				$wpdb->options,
				self::flag_name( $field_id ),
				self::FLAG_PENDING,
				'no'
			)
		);
		self::flush_flag_cache( $field_id );
	}

	/**
	 * Require a rebuild because the index may have missed a source write.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	public static function mark_stale( $field_id ) {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				'INSERT INTO %i (option_name, option_value, autoload) VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE option_value = VALUES(option_value)',
				$wpdb->options,
				self::flag_name( $field_id ),
				self::FLAG_STALE,
				'no'
			)
		);
		self::flush_flag_cache( $field_id );
	}

	/**
	 * Clear only the flag added by the current lock holder, preserving a stale flag.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	public static function clear_pending_flag( $field_id ) {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE option_name = %s AND option_value = %s',
				$wpdb->options,
				self::flag_name( $field_id ),
				self::FLAG_PENDING
			)
		);
		self::flush_flag_cache( $field_id );
	}

	/**
	 * Clear any flag before a rebuild reads the source rows.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	public static function clear_flag( $field_id ) {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE option_name = %s',
				$wpdb->options,
				self::flag_name( $field_id )
			)
		);
		self::flush_flag_cache( $field_id );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return string
	 */
	public static function flag_name( $field_id ) {
		return 'frmpro_meta_index_dirty_' . absint( $field_id );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return string
	 */
	public static function state_name( $field_id ) {
		return 'frmpro_meta_index_' . absint( $field_id );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return string
	 */
	public static function lock_name( $field_id ) {
		return 'frm_meta_' . md5( FrmProMetaIndex::table_name() ) . '_' . absint( $field_id );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 * @param int $timeout  Seconds to wait for the lock.
	 *
	 * @return bool
	 */
	public static function acquire_lock( $field_id, $timeout = 0 ) {
		global $wpdb;
		return '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', self::lock_name( $field_id ), $timeout ) );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	public static function release_lock( $field_id ) {
		global $wpdb;
		$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', self::lock_name( $field_id ) ) );
	}

	/**
	 * Record a read so pruning keeps the field, without overwriting a concurrent reset.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Field ID.
	 *
	 * @return void
	 */
	public static function touch_field( $field_id ) {
		if ( ! self::acquire_lock( $field_id ) ) {
			// Another request holds the lock. A later read records the use.
			return;
		}

		try {
			$state = self::get_state( $field_id );

			if ( is_array( $state ) && 'ready' === ( $state['status'] ?? '' ) ) {
				$state['used_at'] = time();
				self::save_state( $field_id, $state );
			}
		} finally {
			self::release_lock( $field_id );
		}
	}

	/**
	 * Remove index rows for every entry in the given forms, for bulk deletes that bypass frm_after_destroy_entry.
	 *
	 * @since 7.0
	 *
	 * @param int[] $form_ids Form IDs whose entries are being deleted.
	 *
	 * @return void
	 */
	public static function delete_form_entries( $form_ids ) {
		global $wpdb;

		$form_ids = array_filter( array_map( 'absint', (array) $form_ids ) );

		if ( ! $form_ids || ! get_option( 'frmpro_meta_index_fields', array() ) ) {
			return;
		}

		$placeholders = implode( ',', array_fill( 0, count( $form_ids ), '%d' ) );

		$wpdb->query(
			$wpdb->prepare(
				'DELETE mi FROM %i AS mi INNER JOIN %i AS e ON e.id = mi.item_id WHERE e.form_id IN (' . $placeholders . ')', // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				array_merge( array( FrmProMetaIndex::table_name(), $wpdb->prefix . 'frm_items' ), $form_ids )
			)
		);
	}

	/**
	 * Write a state even if this request cached an older copy of the option.
	 *
	 * @since 7.0
	 *
	 * @param int   $field_id Field ID.
	 * @param array $state    Field state.
	 *
	 * @return void
	 */
	public static function save_state( $field_id, $state ) {
		self::forget_ready( $field_id );
		wp_cache_delete( self::state_name( $field_id ), 'options' );
		update_option( self::state_name( $field_id ), $state, false );
	}

	/**
	 * Skip the status query for a field this request found ready moments ago.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return bool
	 */
	public static function is_known_ready( $field_id ) {
		return isset( self::$ready_until[ $field_id ] ) && self::$ready_until[ $field_id ] > microtime( true );
	}

	/**
	 * Call only after get_status() found the field ready and unflagged.
	 *
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	public static function remember_ready( $field_id ) {
		self::$ready_until[ (int) $field_id ] = microtime( true ) + self::READY_CACHE_SECONDS;
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	private static function forget_ready( $field_id ) {
		unset( self::$ready_until[ (int) $field_id ] );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_id Source field ID.
	 *
	 * @return void
	 */
	private static function flush_flag_cache( $field_id ) {
		self::forget_ready( $field_id );
		wp_cache_delete( self::flag_name( $field_id ), 'options' );
	}
}
