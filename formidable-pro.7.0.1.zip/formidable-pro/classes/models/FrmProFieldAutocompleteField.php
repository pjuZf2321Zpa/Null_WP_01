<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * @since 5.5
 */
trait FrmProFieldAutocompleteField {

	/**
	 * @since 7.0 This uses the Lite implementation when Lite is up to date.
	 *
	 * @return array<string,string>
	 */
	public function autocomplete_options() {
		if ( is_callable( 'FrmFieldsHelper::get_autocomplete_options' ) ) {
			return FrmFieldsHelper::get_autocomplete_options( $this->get_filter_keys() );
		}

		$options     = FrmProFieldsHelper::get_autocomplete_options();
		$filter_keys = $this->get_filter_keys();

		if ( $filter_keys ) {
			return array_filter(
				$options,
				function ( $key ) use ( $filter_keys ) {
					return in_array( $key, $filter_keys, true );
				},
				ARRAY_FILTER_USE_KEY
			);
		}

		return $options;
	}

	/**
	 * @return array An empty array will include every key.
	 */
	protected function get_filter_keys() {
		return array();
	}
}
