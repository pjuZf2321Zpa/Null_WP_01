<?php
/**
 * Auto-delete entries controller
 *
 * @package FormidablePro
 *
 * @since 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Deletes entries that are older than the retention period set in a form's GDPR settings.
 */
class FrmProAutoDeleteEntriesController {

	/**
	 * The default number of days to keep entries.
	 *
	 * @since 7.0
	 *
	 * @var int
	 */
	const DEFAULT_DAYS = 90;

	/**
	 * The maximum number of days to keep entries. This is about 10 years.
	 * A larger number would push the cutoff date out of range.
	 *
	 * @since 7.0
	 *
	 * @var int
	 */
	const MAX_DAYS = 3650;

	/**
	 * The maximum number of entries to delete in a single cron run.
	 *
	 * @since 7.0
	 *
	 * @var int
	 */
	const BATCH_SIZE = 200;

	/**
	 * Delete expired entries for every form with auto-delete turned on.
	 * This runs hourly. Anything left over when the batch is used up gets deleted on the next run.
	 * Nothing is deleted while GDPR is disabled in global settings.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function delete_expired_entries() {
		if ( ! self::gdpr_is_enabled() ) {
			return;
		}

		/**
		 * Filter the maximum number of entries deleted in one auto-delete cron run.
		 *
		 * @since 7.0
		 *
		 * @param int $batch_size The maximum number of entries to delete.
		 */
		$remaining  = absint( apply_filters( 'frm_auto_delete_entries_batch_size', self::BATCH_SIZE ) );
		$forms      = self::get_forms_with_auto_delete();
		$forms_left = count( $forms );

		foreach ( $forms as $form ) {
			if ( $remaining <= 0 ) {
				break;
			}

			// Give each form a fair share so one large backlog cannot block the forms after it.
			// A share one form does not use carries over to the forms after it.
			$limit      = (int) ceil( $remaining / $forms_left );
			$remaining -= self::delete_expired_entries_for_form( $form, $limit );
			--$forms_left;
		}
	}

	/**
	 * Check if GDPR is enabled in global settings.
	 *
	 * @since 7.0
	 *
	 * @return bool
	 */
	public static function gdpr_is_enabled() {
		// Lite versions before 6.19 have no GDPR setting, so nothing should be deleted.
		return class_exists( 'FrmFieldGdprHelper' ) && ! FrmFieldGdprHelper::hide_gdpr_field();
	}

	/**
	 * Get a valid number of days to keep entries.
	 * Anything that is not a positive whole number falls back to the default.
	 * Anything over the maximum is lowered to the maximum instead of the default, so a long retention period stays long.
	 *
	 * @since 7.0
	 *
	 * @param mixed $days The saved or submitted number of days.
	 *
	 * @return int
	 */
	public static function sanitize_days( $days ) {
		$days = is_numeric( $days ) ? (int) $days : 0;
		return $days > 0 ? min( $days, self::MAX_DAYS ) : self::DEFAULT_DAYS;
	}

	/**
	 * Get the forms that have auto-delete turned on.
	 *
	 * @since 7.0
	 *
	 * @return array<stdClass>
	 */
	private static function get_forms_with_auto_delete() {
		$forms = FrmForm::getAll(
			array(
				'is_template'  => 0,
				// FrmProForm::update_options() saves the option as an int, so this only matches forms with it turned on.
				'options LIKE' => '"auto_delete_entries";i:1;',
			),
			'id ASC'
		);

		if ( ! is_array( $forms ) ) {
			return array();
		}

		return array_filter( $forms, array( self::class, 'form_has_auto_delete' ) );
	}

	/**
	 * @since 7.0
	 *
	 * @param stdClass $form The form object with unserialized options.
	 *
	 * @return bool
	 */
	private static function form_has_auto_delete( $form ) {
		return is_array( $form->options ) && ! empty( $form->options['auto_delete_entries'] );
	}

	/**
	 * Delete entries in a form that are older than its retention period.
	 * Child entries, uploaded files and linked posts are removed by the frm_before_destroy_entry hooks.
	 *
	 * @since 7.0
	 *
	 * @param stdClass $form  The form object with unserialized options.
	 * @param int      $limit The maximum number of entries to delete.
	 *
	 * @return int The number of entries deleted.
	 */
	private static function delete_expired_entries_for_form( $form, $limit ) {
		$days = self::sanitize_days( $form->options['auto_delete_days'] ?? 0 );

		$entry_ids = FrmDb::get_col(
			'frm_items',
			array(
				'form_id'        => $form->id,
				'parent_item_id' => 0,
				'created_at <'   => gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ),
			),
			'id',
			array(
				'order_by' => 'id ASC',
				'limit'    => $limit,
			)
		);

		$deleted = 0;

		foreach ( $entry_ids as $entry_id ) {
			if ( FrmEntry::destroy( $entry_id ) ) {
				++$deleted;
			}
		}

		return $deleted;
	}
}
