<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Registers the entry abilities that belong to Pro.
 *
 * Writing an entry through an ability is a Pro feature, so create-entry and
 * update-entry live here while Formidable owns listing, reading, and deleting
 * one. Both share the value shaping helpers Formidable exposes, so an entry is
 * stored the same way whichever of the two wrote it.
 *
 * @since 7.0
 */
class FrmProAbilitiesEntriesController {

	/**
	 * Register the entry abilities.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function register_abilities() {
		self::register_create_entry_ability();
		self::register_update_entry_ability();
	}

	/**
	 * Register the create entry ability.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	private static function register_create_entry_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/create-entry',
			array(
				'label'               => __( 'Create Entry', 'formidable-pro' ),
				'description'         => __(
					'Create a new Formidable entry (form submission). Use list-forms to find the form_id, and list-fields to see available field keys for the form.',
					'formidable-pro'
				),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'form_id' ),
					'properties' => array(
						'form_id'    => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Form ID or form_key to submit the entry to. Required. Use list-forms to find available forms.', 'formidable-pro' ),
						),
						'item_meta'  => array(
							'type'                 => 'object',
							'description'          => __(
								'Field values keyed by field ID or field_key. Use list-fields for a form\'s keys. Example: {"field_key1": "value1"}',
								'formidable-pro'
							),
							'additionalProperties' => true,
						),
						'is_draft'   => array(
							'type'        => 'integer',
							'description' => __( 'Set to 1 to save the entry as a draft.', 'formidable-pro' ),
						),
						'user_id'    => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __(
								'WordPress user ID, login, or email to record as the entry author. Only applied when the caller can edit entries.',
								'formidable-pro'
							),
						),
						'created_at' => array(
							'type'        => 'string',
							'description' => __( 'Entry creation date in MySQL format (Y-m-d H:i:s). Defaults to the current time.', 'formidable-pro' ),
						),
					),
				),
				'output_schema'       => array(
					'type'                 => 'object',
					'description'          => __( 'Created entry object or error response.', 'formidable-pro' ),
					'additionalProperties' => true,
				),
				'execute_callback'    => 'FrmProAbilitiesEntriesController::execute_create_entry',
				'permission_callback' => 'FrmProAbilitiesEntriesController::can_create_entry',
				'meta'                => FrmAbilitiesHelper::meta( false, false, false ),
			)
		);
	}

	/**
	 * Register the update entry ability.
	 *
	 * @return void
	 */
	private static function register_update_entry_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/update-entry',
			array(
				'label'               => __( 'Update Entry', 'formidable-pro' ),
				'description'         => __( 'Update an existing Formidable entry.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id'        => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Entry ID or item_key.', 'formidable' ),
						),
						'form_id'   => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Form ID or form_key.', 'formidable' ),
						),
						'item_meta' => array(
							'type'        => 'object',
							'description' => __( 'Field values keyed by field ID or field key.', 'formidable-pro' ),
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Updated entry object.', 'formidable-pro' ),
				),
				'execute_callback'    => 'FrmProAbilitiesEntriesController::execute_update_entry',
				'permission_callback' => 'FrmProAbilitiesEntriesController::can_update_entry',
				'meta'                => FrmAbilitiesHelper::meta( false, false, false ),
			)
		);
	}

	/**
	 * Create an entry.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_create_entry( $input ) {
		FrmAbilitiesHelper::set_current_user();

		if ( empty( $input['form_id'] ) ) {
			return new WP_Error( 'frm_no_form_id', __( 'A form id or form key is required to create an entry.', 'formidable-pro' ), array( 'status' => 400 ) );
		}

		$form = FrmAbilitiesHelper::get_form( $input['form_id'] );

		if ( is_wp_error( $form ) ) {
			return $form;
		}

		$owner_id = self::get_requested_entry_owner( $input );

		if ( is_wp_error( $owner_id ) ) {
			return $owner_id;
		}

		// An ability is not a form submission: there is no browser to set a cookie
		// on, no file upload to switch, and no visitor to run antispam against.
		$added_filters = self::add_submission_filters( true );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Only saved here so it can be restored below.
		$original_post = $_POST;

		try {
			return self::create_entry( $input, $form, $owner_id );
		} finally {
			// The filters and $_POST are only for this call. Leaving them behind
			// would disable antispam for anything else in the same process.
			$_POST = $original_post;
			self::remove_submission_filters( $added_filters );
		}
	}

	/**
	 * Validate and save a new entry, once the submission filters are in place.
	 *
	 * @since 7.0
	 *
	 * @param array    $input    Ability input parameters.
	 * @param stdClass $form     The form the entry is created in.
	 * @param int      $owner_id The user to record as the entry owner, or 0 for the acting user.
	 *
	 * @return array|WP_Error
	 */
	private static function create_entry( $input, $form, $owner_id ) {
		$new_entry            = $input;
		$new_entry['form_id'] = (int) $form->id;

		if ( ! isset( $new_entry['item_meta'] ) && isset( $new_entry['meta'] ) ) {
			$new_entry['item_meta'] = $new_entry['meta'];
			unset( $new_entry['meta'] );
		}

		if ( isset( $new_entry['item_meta'] ) ) {
			FrmAbilitiesEntriesController::normalize_item_meta_keys( $new_entry['item_meta'], $form->id );
		}

		$fields    = FrmField::get_all_for_form( $form->id );
		$new_entry = FrmAbilitiesEntriesController::prepare_entry_data( $new_entry, $fields );

		if ( $owner_id ) {
			self::set_entry_owner( $new_entry, $fields, $owner_id );
		}

		// Validation checks the nonce, which has already been established by the
		// authenticated request that got this far.
		$new_entry[ 'frm_submit_entry_' . $form->id ] = wp_create_nonce( 'frm_submit_entry_nonce' );

		self::load_registration_hooks( 'create' );

		// FrmEntryValidate::validate() and FrmEntry::create() both read $_POST
		// directly rather than taking the entry as an argument.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- The request is already authenticated, and the nonce is set above.
		$_POST = $new_entry;

		$errors = FrmEntryValidate::validate( $new_entry, false );

		if ( $errors ) {
			return FrmAbilitiesHelper::flatten_error(
				new WP_Error( 'frm_validate_entry', $errors, array( 'status' => 409 ) )
			);
		}

		$_POST['frm_skip_cookie'] = true;

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- The request is already authenticated, and the nonce is set above.
		$entry_id = FrmEntry::create( $_POST );

		if ( ! $entry_id ) {
			$frm_settings = FrmAppHelper::get_settings();
			return new WP_Error( 'frm_create_entry', $frm_settings->failed_msg, array( 'status' => 409 ) );
		}

		// Forms set to delete the entry after submission still run their actions,
		// then drop the row. Honor that here so the ability matches the form.
		FrmEntriesController::delete_entry_after_save(
			array(
				'entry_id' => $entry_id,
				'form'     => $form,
			)
		);

		$entry = FrmAbilitiesEntriesController::execute_get_entry( array( 'id' => $entry_id ) );

		if ( is_wp_error( $entry ) ) {
			// The form deleted the entry after saving it, so there is nothing left
			// to read back. The creation still succeeded.
			return array(
				'id'      => (int) $entry_id,
				'form_id' => (int) $form->id,
				'deleted' => true,
			);
		}

		return $entry;
	}

	/**
	 * Get the user a create-entry call asked to record as the entry owner.
	 *
	 * The owner can only be chosen by someone allowed to manage entries, the
	 * same gate FrmEntry applies to a posted frm_user_id. For anyone else the
	 * input is ignored and the entry belongs to the acting user, as it would
	 * for a public submission.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return int|WP_Error The user ID, 0 to use the acting user, or an error for a user that does not exist.
	 */
	private static function get_requested_entry_owner( $input ) {
		if ( ! isset( $input['user_id'] ) || '' === $input['user_id'] ) {
			return 0;
		}

		if ( ! current_user_can( 'frm_edit_entries' ) && ! current_user_can( 'administrator' ) ) {
			return 0;
		}

		// Accept a user ID, login, email, or 'current', like a User ID field does.
		$user_id = FrmAppHelper::get_user_id_param( sanitize_text_field( (string) $input['user_id'] ) );

		if ( ! is_numeric( $user_id ) || ! get_userdata( (int) $user_id ) ) {
			return new WP_Error( 'frm_invalid_user_id', __( 'The user_id does not match an existing user.', 'formidable-pro' ), array( 'status' => 400 ) );
		}

		return (int) $user_id;
	}

	/**
	 * Record the requested owner on an entry about to be created.
	 *
	 * FrmEntry::create() reads the owner from frm_user_id. A User ID field on
	 * the form also sets frm_user_id from its own value during validation, so
	 * that value is set to the same user to keep the two in agreement.
	 *
	 * @since 7.0
	 *
	 * @param array $entry    The prepared entry data.
	 * @param array $fields   The form's fields.
	 * @param int   $owner_id The user to record as the entry owner.
	 *
	 * @return void
	 */
	private static function set_entry_owner( &$entry, $fields, $owner_id ) {
		$entry['frm_user_id'] = $owner_id;

		foreach ( $fields as $field ) {
			if ( 'user_id' === $field->type ) {
				$entry['item_meta'][ $field->id ] = $owner_id;
			}
		}
	}

	/**
	 * Add the filters that turn off the parts of a submission an ability has no use for.
	 *
	 * A filter that is already in place is left alone, so removing ours later
	 * cannot take away one that some other code added.
	 *
	 * @since 7.0
	 *
	 * @param bool $include_cookies Whether to also stop the entry cookie, which only applies on create.
	 *
	 * @return array<array{0: string, 1: string, 2: int, 3: int}> The filters added, as hook name, callback, priority and accepted args.
	 */
	private static function add_submission_filters( $include_cookies ) {
		$filters = array(
			array( 'frm_stop_file_switching', '__return_true', 10, 1 ),
			array( 'frm_run_antispam', '__return_false', 10, 1 ),
			array( 'frm_is_field_hidden', 'FrmAbilitiesEntriesController::skip_unanswerable_field', 10, 2 ),
		);

		if ( $include_cookies ) {
			$filters[] = array( 'frm_create_cookies', '__return_false', 10, 1 );
		}

		$added = array();

		foreach ( $filters as $filter ) {
			if ( false !== has_filter( $filter[0], $filter[1] ) ) {
				continue;
			}

			add_filter( $filter[0], $filter[1], $filter[2], $filter[3] );
			$added[] = $filter;
		}

		return $added;
	}

	/**
	 * Remove the filters add_submission_filters() added.
	 *
	 * @since 7.0
	 *
	 * @param array<array{0: string, 1: string, 2: int, 3: int}> $filters The filters added, as hook name, callback, priority and accepted args.
	 *
	 * @return void
	 */
	private static function remove_submission_filters( $filters ) {
		foreach ( $filters as $filter ) {
			remove_filter( $filter[0], $filter[1], $filter[2] );
		}
	}

	/**
	 * Update an entry.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_update_entry( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$entry = self::get_entry_for_update( $input['id'] );

		if ( is_wp_error( $entry ) ) {
			return $entry;
		}

		// An ability is not a form submission: no file to switch, and no visitor
		// to run antispam against.
		$added_filters = self::add_submission_filters( false );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Only saved here so it can be restored below.
		$original_post = $_POST;

		try {
			return self::update_entry( $input, $entry );
		} finally {
			// The filters and $_POST are only for this call. Leaving them behind
			// would disable antispam for anything else in the same process.
			$_POST = $original_post;
			self::remove_submission_filters( $added_filters );
		}
	}

	/**
	 * Validate and save changes to an entry, once the submission filters are in place.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 * @param array $entry The entry being updated, as loaded by get_entry_for_update().
	 *
	 * @return array|WP_Error
	 */
	private static function update_entry( $input, $entry ) {
		// Validation reads the entry id off $_POST to scope its unique checks.
		$_POST['id'] = $entry['id'];

		$data = $input;
		self::combine_entry_and_data( $entry, $data );

		$data['form_id'] = ! empty( $data['form_id'] ) ? $data['form_id'] : $entry['form_id'];
		$data            = array_merge( $entry, $data );
		unset( $data['meta'] );

		$data = FrmAbilitiesEntriesController::prepare_entry_data( $data, FrmField::get_all_for_form( $data['form_id'] ) );

		// Validation checks the nonce, which has already been established by the
		// authenticated request that got this far.
		$data[ 'frm_submit_entry_' . $data['form_id'] ] = wp_create_nonce( 'frm_submit_entry_nonce' );

		self::load_registration_hooks( 'update' );

		// FrmEntryValidate::validate() and FrmEntry::update() both read $_POST
		// directly rather than taking the entry as an argument.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- The request is already authenticated, and the nonce is set above.
		$_POST = $data;

		$errors = FrmEntryValidate::validate( $data, false );

		if ( $errors ) {
			return FrmAbilitiesHelper::flatten_error(
				new WP_Error( 'frm_validate_entry', $errors, array( 'status' => 409 ) )
			);
		}

		self::allow_update_of_recently_saved_entry( $entry['id'] );

		// FrmEntry::update() returns the affected row count for the frm_items
		// row, which is 0 when only field values changed within the same second.
		// The update still ran, so only a false return (blocked, or a query
		// error) is a failure.
		$updated = FrmEntry::update( $entry['id'], $data );

		if ( false === $updated ) {
			return new WP_Error( 'frm_entry_update_failed', __( 'Entry update failed.', 'formidable-pro' ), array( 'status' => 500 ) );
		}

		return FrmAbilitiesEntriesController::execute_get_entry( array( 'id' => $entry['id'] ) );
	}

	/**
	 * Load one entry as an array, with its display values attached.
	 *
	 * @since 7.0
	 *
	 * @param int|string $id Entry ID or item_key.
	 *
	 * @return array|WP_Error
	 */
	private static function get_entry_for_update( $id ) {
		$entry = FrmEntry::getOne( $id );

		if ( ! $entry ) {
			return new WP_Error( 'frm_entry_invalid_id', __( 'Invalid entry ID.', 'formidable-pro' ), array( 'status' => 404 ) );
		}

		$entry->meta = FrmEntriesController::show_entry_shortcode(
			array(
				'format'        => 'array',
				'include_blank' => true,
				'id'            => $entry->id,
				'user_info'     => false,
				'child_array'   => true,
				'date_format'   => 'Y-m-d',
				'array_key'     => 'id',
			)
		);

		return (array) $entry;
	}

	/**
	 * Let the Registration add-on hook the entry as it would a real submission.
	 *
	 * The add-on reads the action off $_POST to decide whether it is creating a
	 * user or updating one, so create and update pass their own.
	 *
	 * @since 7.0
	 *
	 * @param string $action Either create or update.
	 *
	 * @return void
	 */
	private static function load_registration_hooks( $action ) {
		if ( class_exists( 'FrmRegEntryController' ) ) {
			$_POST['frm_action'] = $action;
			new FrmRegEntryController();
		}
	}

	/**
	 * Permission callback for create entry.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_create_entry( $input ) {
		return current_user_can( 'frm_create_entries' ) || current_user_can( 'administrator' );
	}

	/**
	 * Permission callback for update entry.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_update_entry( $input ) {
		return current_user_can( 'frm_edit_entries' ) || current_user_can( 'administrator' );
	}

	/**
	 * Remove an entry from the per-process re-save guard before an explicit update.
	 *
	 * FrmEntry::update() silently skips any entry id found in
	 * $frm_vars['saved_entries'], which core uses to stop duplicate saves
	 * within one page load. Every save adds the id to that list, and the
	 * global lives for the whole PHP process, so in a long-running process,
	 * like an MCP stdio session, the second API update of an entry would be
	 * skipped while still reporting no error. An explicit API update should
	 * always run, so drop the id from the guard first.
	 *
	 * A repeater's rows are entries of their own, and Pro updates them through
	 * the same FrmEntry::update(), so they need clearing too. Otherwise an update
	 * that edits a row created earlier in the same process reorders and deletes
	 * rows correctly while silently discarding the edited values.
	 *
	 * @since 7.0
	 *
	 * @param int|string $entry_id Entry ID about to be updated.
	 *
	 * @return void
	 */
	private static function allow_update_of_recently_saved_entry( $entry_id ) {
		global $frm_vars;

		if ( empty( $frm_vars['saved_entries'] ) || ! is_array( $frm_vars['saved_entries'] ) ) {
			return;
		}

		$ids = array( (int) $entry_id );

		foreach ( FrmEntry::getAll( array( 'it.parent_item_id' => (int) $entry_id ) ) as $child ) {
			$ids[] = (int) $child->id;
		}

		$frm_vars['saved_entries'] = array_values( array_diff( $frm_vars['saved_entries'], $ids ) );
	}

	/**
	 * @param array $entry
	 * @param array $data
	 *
	 * @return void
	 */
	private static function combine_entry_and_data( $entry, &$data ) {
		if ( isset( $data[1] ) ) {
			unset( $data[1] );
		}

		if ( ! isset( $data['item_meta'] ) && isset( $data['meta'] ) ) {
			$data['item_meta'] = $data['meta'];
			unset( $data['meta'] );
		}

		self::switch_displayed_value_to_saved( $entry );

		if ( empty( $data['item_meta'] ) ) {
			$skip              = array( 'page', 'page_size', 'order', 'order_by', 'search', 'item_meta' );
			$added             = array();
			$data['item_meta'] = $entry['meta'] ?? array();

			foreach ( $data as $k => $v ) {
				if ( in_array( $k, $skip, true ) ) {
					continue;
				}

				$field_id = 0;

				if ( is_numeric( $k ) ) {
					$field_id = $k;
					unset( $data[ $k ] );
				} elseif ( ! isset( $entry[ $k ] ) ) {
					$field = FrmField::getOne( $k );

					if ( $field ) {
						$field_id = $field->id;
					}
					unset( $field );
				}

				if ( $field_id ) {
					$added[]                        = $field_id;
					$data['item_meta'][ $field_id ] = $v;
					self::prepare_child_data( $field_id, $data['item_meta'] );
				}

				unset( $k, $v );
			}

			self::clear_extra_child_values( $added, $data['item_meta'] );

			return;
		}

		// Field-key keys must become ids before the merge below: the old
		// id-keyed value would otherwise fill the id slot and win over the
		// new key-keyed value when the metas are saved.
		FrmAbilitiesEntriesController::normalize_item_meta_keys( $data['item_meta'], $entry['form_id'] );

		// Fill in missing values with existing values
		$existing_meta      = $entry['meta'] ?? array();
		$data['item_meta'] += is_array( $existing_meta ) ? $existing_meta : array();
	}

	/**
	 * We want to use the real data for an entry on update, not a display value.
	 * The meta array may have both a key with "$field_id" and one with "$field-value".
	 * When the "$field-value" key exists, the "$field_id" value is replaced with the "$field-value" value.
	 *
	 * @param array $entry
	 *
	 * @return void
	 */
	private static function switch_displayed_value_to_saved( &$entry ) {
		$new_meta = $entry['meta'];

		foreach ( $new_meta as $key => $value ) {
			if ( strpos( $key, '-value' ) ) {
				$field_id = str_replace( '-value', '', $key );

				if ( is_numeric( $field_id ) ) {
					$entry['meta'][ $field_id ] = $value;
					unset( $entry['meta'][ $key ] );
				}
			}

			self::switch_display_values_inside_repeaters( $entry, $key, $value );
		}

		self::overlay_raw_meta_values( $entry );
	}

	/**
	 * Replace display values with the raw saved values for non-repeater fields.
	 *
	 * The meta array is built from display values (option labels, formatted
	 * dates), which fail validation for fields with separate values and for
	 * date fields when the merged data is validated on update. Repeater and
	 * embedded form structures are kept as built from the display data.
	 *
	 * @since 7.0
	 *
	 * @param array $entry
	 *
	 * @return void
	 */
	private static function overlay_raw_meta_values( &$entry ) {
		$raw_entry = FrmEntry::getOne( $entry['id'], true );

		if ( ! $raw_entry || ! is_array( $raw_entry->metas ) ) {
			return;
		}

		foreach ( $raw_entry->metas as $field_id => $raw_value ) {
			$display_value = $entry['meta'][ $field_id ] ?? null;

			if ( is_array( $display_value ) && isset( $display_value['form'] ) ) {
				continue;
			}

			$entry['meta'][ $field_id ] = $raw_value;
		}
	}

	/**
	 * @since 7.0
	 *
	 * @param array  $entry
	 * @param string $key   This is used when mapping updated to $entry.
	 * @param mixed  $value This data is checked in a loop.
	 *
	 * @return void
	 */
	private static function switch_display_values_inside_repeaters( &$entry, $key, $value ) {
		if ( ! is_array( $value ) || empty( $value['form'] ) ) {
			// Not a repeater value so exit early.
			return;
		}

		foreach ( $value as $repeater_entry_index => $repeater_entry_data ) {
			// Skip keys like 'form' that are not switched.
			if ( ! str_starts_with( $repeater_entry_index, 'i' ) || ! is_array( $repeater_entry_data ) ) {
				continue;
			}

			foreach ( $repeater_entry_data as $repeater_key => $repeater_value ) {
				if ( ! strpos( $repeater_key, '-value' ) ) {
					// Skip regular field ID keys. We are only interested in the "$field_id-value" keys.
					continue;
				}

				$field_id = str_replace( '-value', '', $repeater_key );

				if ( ! is_numeric( $field_id ) ) {
					continue;
				}

				if ( ! isset( $entry['meta'][ $key ][ $repeater_entry_index ] ) ) {
					$entry['meta'][ $key ][ $repeater_entry_index ] = array();
				}

				$entry['meta'][ $key ][ $repeater_entry_index ][ $field_id ] = $repeater_value;
				unset( $entry['meta'][ $key ][ $repeater_entry_index ][ $repeater_key ] );
			}
		}
	}

	/**
	 * @param int|string $field_id
	 * @param array      $meta
	 *
	 * @return void
	 */
	private static function prepare_child_data( $field_id, &$meta ) {
		$parent_field = self::parent_field_id( $field_id, $meta );

		if ( ! $parent_field ) {
			return;
		}

		foreach ( $meta[ $parent_field ] as $entry_id => $entry ) {
			$field_is_nested = is_array( $entry ) && isset( $entry[ $field_id ] ) && str_starts_with( $entry_id, 'i' );

			if ( $field_is_nested ) {
				$meta[ $parent_field ][ $entry_id ][ $field_id ] = $meta[ $field_id ];
				unset( $meta[ $field_id ] );
				break;
			}
		}
	}

	/**
	 * When a field is embedded, clear the top-level values
	 *
	 * @param array $added
	 * @param array $meta
	 *
	 * @return void
	 */
	private static function clear_extra_child_values( $added, &$meta ) {
		foreach ( $meta as $field_id => $value ) {
			if ( in_array( $field_id, $added ) ) {
				continue;
			}

			$parent_field = self::parent_field_id( $field_id, $meta );

			if ( $parent_field ) {
				unset( $meta[ $field_id ] );
			}
		}
	}

	/**
	 * @param int|string $field_id
	 * @param array      $meta
	 *
	 * @return int|string The parent field id or 0.
	 */
	private static function parent_field_id( $field_id, $meta ) {
		foreach ( $meta as $field => $value ) {
			if ( ! is_array( $value ) || ! isset( $value['form'] ) ) {
				continue;
			}

			foreach ( $value as $entry_id => $entry ) {
				if ( is_array( $entry ) && isset( $entry[ $field_id ] ) && str_starts_with( $entry_id, 'i' ) ) {
					return $field;
				}
			}
		}

		return 0;
	}
}
