<?php
/**
 * Spam entries cleanup.
 *
 * @since 7.0
 *
 * @package FormidablePro
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmProSpamEntriesController {

	/**
	 * The most spam entries deleted in one cleanup run, so a large backlog doesn't time out.
	 *
	 * @since 7.0
	 *
	 * @var int
	 */
	const DELETE_BATCH_SIZE = 500;

	/**
	 * Get the retention choices, in days. 0 keeps spam entries until they are deleted.
	 *
	 * @since 7.0
	 *
	 * @return array<int, string>
	 */
	public static function get_retention_options() {
		$options = array(
			0 => __( 'Never', 'formidable-pro' ),
		);

		foreach ( array( 7, 15, 30, 60, 90 ) as $days ) {
			/* translators: %d: Number of days. */
			$options[ $days ] = sprintf( _n( 'After %d day', 'After %d days', $days, 'formidable-pro' ), $days );
		}

		return $options;
	}

	/**
	 * @since 7.0
	 *
	 * @param mixed $days The posted number of days.
	 *
	 * @return int
	 */
	public static function sanitize_retention_days( $days ) {
		if ( ! is_numeric( $days ) ) {
			return 30;
		}

		$days = absint( $days );
		return array_key_exists( $days, self::get_retention_options() ) ? $days : 30;
	}

	/**
	 * Show the cleanup setting below the spam entries settings in the Captcha/Spam global settings.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function retention_setting() {
		$frmpro_settings = FrmProAppHelper::get_settings();
		$retention_days  = self::sanitize_retention_days( $frmpro_settings->spam_retention_days );

		include FrmProAppHelper::plugin_path() . '/classes/views/settings/spam-retention.php';
	}

	/**
	 * Get the saved retention period for the form settings summary.
	 *
	 * @since 7.0
	 *
	 * @return int
	 */
	public static function retention_summary() {
		$frmpro_settings = FrmProAppHelper::get_settings();
		return self::sanitize_retention_days( $frmpro_settings->spam_retention_days );
	}

	/**
	 * Permanently delete spam entries older than the retention setting.
	 * Runs on the daily cron event.
	 *
	 * @since 7.0
	 *
	 * @param int $last_entry_id The last entry scanned by the previous batch. 0 starts a new scan.
	 *
	 * @return void
	 */
	public static function delete_expired_spam( $last_entry_id = 0 ) {
		if ( ! class_exists( 'FrmSpamEntriesHelper' ) ) {
			return;
		}

		$frmpro_settings = FrmProAppHelper::get_settings();

		/**
		 * Allows changing how many days spam entries are kept before they are deleted.
		 *
		 * @since 7.0
		 *
		 * @param int $days 0 keeps spam entries until they are deleted.
		 */
		$days = (int) apply_filters( 'frm_spam_retention_days', self::sanitize_retention_days( $frmpro_settings->spam_retention_days ) );

		if ( $days < 1 ) {
			return;
		}

		$cutoff  = time() - $days * DAY_IN_SECONDS;
		$entries = FrmDb::get_results(
			'frm_items',
			array(
				'is_draft'       => FrmSpamEntriesHelper::SPAM_ENTRY_STATUS,
				'created_at <'   => gmdate( 'Y-m-d H:i:s', $cutoff ),
				'parent_item_id' => 0,
				'id >'           => absint( $last_entry_id ) + 1,
			),
			'id, description',
			array(
				'order_by' => 'id ASC',
				'limit'    => self::DELETE_BATCH_SIZE,
			)
		);

		foreach ( $entries as $entry ) {
			$description = $entry->description;
			FrmAppHelper::unserialize_or_decode( $description );

			if ( is_array( $description ) && 'manual' === ( $description['spam_source'] ?? '' ) ) {
				$marked_at = $description['spam_marked_at'] ?? 0;

				// Older manual spam has no moderation date. Keep it rather than guessing its age.
				if ( ! is_numeric( $marked_at ) || $marked_at <= 0 || $marked_at >= $cutoff ) {
					continue;
				}
			}

			FrmEntry::destroy( $entry->id );
		}

		if ( count( $entries ) !== self::DELETE_BATCH_SIZE ) {
			return;
		}

		$last_entry = end( $entries );
		$args       = array( (int) $last_entry->id );

		if ( ! wp_next_scheduled( 'frm_delete_expired_spam', $args ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'frm_delete_expired_spam', $args );
		}
	}
}
