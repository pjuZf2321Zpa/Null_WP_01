<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Registers the statistics ability.
 *
 * Statistics are a Pro feature, computed by FrmProStatisticsController.
 *
 * @since 7.0
 */
class FrmProAbilitiesStatsController {

	/**
	 * Register the stats abilities.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function register_abilities() {
		if ( ! class_exists( 'FrmProStatisticsController' ) ) {
			return;
		}

		self::register_get_stats_ability();
	}

	/**
	 * Register the get stats ability.
	 *
	 * @return void
	 */
	private static function register_get_stats_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/get-stats',
			array(
				'label'               => __( 'Get Field Stats', 'formidable-pro' ),
				'description'         => __(
					'Calculate statistics across entries for one or more fields. Supports total, count, average, median, star, maximum, minimum, unique, and deviation.',
					'formidable-pro'
				),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'type', 'field_id' ),
					'properties' => array(
						'type'     => array(
							'type'        => 'string',
							'description' => __( 'The statistic to calculate.', 'formidable-pro' ),
							'enum'        => array( 'total', 'count', 'average', 'median', 'star', 'maximum', 'minimum', 'unique', 'deviation' ),
						),
						'field_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __(
								'A field ID or field key, or a comma-separated list of field IDs/keys. Required. Use list-fields to find available fields.',
								'formidable-pro'
							),
						),
					),
				),
				'output_schema'       => array(
					'type'                 => 'object',
					'description'          => __( 'Statistics keyed by the requested field ID/key.', 'formidable-pro' ),
					'additionalProperties' => true,
				),
				'execute_callback'    => 'FrmProAbilitiesStatsController::execute_get_stats',
				'permission_callback' => 'FrmProAbilitiesStatsController::can_get_stats',
				'meta'                => FrmAbilitiesHelper::meta( true, false, true ),
			)
		);
	}

	/**
	 * Compute statistics for one or more fields.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_get_stats( $input ) {
		FrmAbilitiesHelper::set_current_user();

		if ( ! is_callable( 'FrmProStatisticsController::stats_shortcode' ) ) {
			return FrmAbilitiesHelper::missing_plugin_error( 'Formidable Forms Pro' );
		}

		if ( empty( $input['field_id'] ) ) {
			return new WP_Error( 'frm_stats_no_field', __( 'A field ID is required.', 'formidable-pro' ), array( 'status' => 400 ) );
		}

		$params = $input;
		unset( $params['field_id'] );

		$field_ids = is_array( $input['field_id'] ) ? $input['field_id'] : explode( ',', (string) $input['field_id'] );
		$data      = array();

		foreach ( $field_ids as $field_id ) {
			$field_id = trim( (string) $field_id );

			if ( '' === $field_id ) {
				continue;
			}

			$params['id']      = $field_id;
			$data[ $field_id ] = FrmProStatisticsController::stats_shortcode( $params );
		}

		return $data;
	}

	/**
	 * Permission callback for get stats.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_get_stats( $input ) {
		return current_user_can( 'frm_view_entries' ) || current_user_can( 'manage_options' );
	}
}
