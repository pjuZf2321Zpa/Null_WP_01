<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * @since 2.02.13
 */
class FrmProConditionalLogicController {

	/**
	 * Check if a given field should be present in another field's logic options
	 *
	 * @since 2.02.13
	 *
	 * @param array  $current_field The current field being displayed for editing
	 * @param object $logic_field   The logic field
	 * @param bool   $prefiltered   Pass bool to avoid some filter type checks that have already been applied.
	 *
	 * @return bool
	 */
	public static function is_field_present_in_logic_options( $current_field, $logic_field, $prefiltered = false ) {
		$present = true;

		if ( $logic_field->id == $current_field['id'] ) {
			$present = false;
		} else {
			if ( ! $prefiltered ) {
				if ( FrmField::is_no_save_field( $logic_field->type ) ) {
					$present = false;
				} elseif ( in_array( $logic_field->type, array( 'file', 'credit_card' ), true ) ) {
					$present = false;
				} elseif ( FrmProField::is_list_field( $logic_field ) ) {
					$present = false;
				}
			}

			if ( $present && 'range' === $logic_field->type && FrmField::get_option( $logic_field, 'is_range_slider' ) ) {
				$present = false;
			}

			if ( $present ) {
				$parent_form_id = $current_field['parent_form_id'] ?? '0';

				if ( $logic_field->form_id != $current_field['form_id'] && $logic_field->form_id != $parent_form_id ) {
					$present = false;
				} else {
					$in_section_id = $logic_field->field_options['in_section'] ?? '0';

					if ( $in_section_id == $current_field['id'] ) {
						$present = false;
					}
				}
			}
		}

		/**
		 * Allows excluding fields in the conditional logic options.
		 *
		 * @since 5.0
		 *
		 * @param bool  $present Is `true` if field is present in the conditional logic options.
		 * @param array $args    The arguments. Contains `$current_field` and `$logic_field`.
		 */
		return (bool) apply_filters( 'frm_is_field_present_in_logic_options', $present, compact( 'current_field', 'logic_field' ) );
	}

	/**
	 * Callbacks on `frm_is_field_present_in_logic_options` that are known to only exclude
	 * by the candidate field's own type, or by a same-container relationship (a section or
	 * a Likert row) that the browser already excludes on its own — see
	 * should_defer_logic_options(). Identified as `Class::method`, matching how each is
	 * registered (a string for Pro's own callback, a `array( 'Class', 'method' )` pair for
	 * Surveys' callbacks — normalized by callback_identifier()).
	 *
	 * @since 7.0
	 */
	const KNOWN_SAFE_LOGIC_OPTION_FILTER_CALLBACKS = array(
		'FrmProVirtualFieldController::exclude_virtual_from_logic',
		'FrmSurveys\controllers\LikertController::exclude_from_logic_options',
		'FrmSurveys\controllers\RankingController::exclude_from_logic_options',
	);

	/**
	 * Whether a condition row can defer rendering its full trigger-field option list to
	 * the browser instead of the server rendering it for every row. The eligible list is
	 * the same for every row in the form (minus the row's own field and its section or
	 * Likert-row mates, which the browser can exclude on its own), so it only needs to be
	 * built once.
	 *
	 * Disabled whenever a site adds anything other than the known-safe callbacks above to
	 * the `frm_is_field_present_in_logic_options` filter, since an arbitrary custom
	 * exclusion can't be replicated in the browser.
	 *
	 * @since 7.0
	 *
	 * @return bool
	 */
	public static function should_defer_logic_options() {
		global $wp_filter;

		if ( empty( $wp_filter['frm_is_field_present_in_logic_options'] ) ) {
			return true;
		}

		foreach ( $wp_filter['frm_is_field_present_in_logic_options']->callbacks as $callbacks_at_priority ) {
			foreach ( $callbacks_at_priority as $registered_callback ) {
				$identifier = self::callback_identifier( $registered_callback['function'] );

				if ( ! in_array( $identifier, self::KNOWN_SAFE_LOGIC_OPTION_FILTER_CALLBACKS, true ) ) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Normalize a registered callback to a `Class::method` string for comparison against
	 * KNOWN_SAFE_LOGIC_OPTION_FILTER_CALLBACKS. Returns an empty string for a callback
	 * shape that can't be identified this way (a closure, for example), which correctly
	 * never matches the allowlist.
	 *
	 * @since 7.0
	 *
	 * @param callable $callback
	 *
	 * @return string
	 */
	private static function callback_identifier( $callback ) {
		if ( is_string( $callback ) ) {
			return $callback;
		}

		if ( is_array( $callback ) && 2 === count( $callback ) ) {
			$class_or_object = $callback[0];
			$class_name      = is_object( $class_or_object ) ? get_class( $class_or_object ) : $class_or_object;

			return $class_name . '::' . $callback[1];
		}

		return '';
	}

	/**
	 * Localize the eligible conditional-logic trigger fields for this form once per page
	 * load, so the JS builder can hydrate each condition row's dropdown on first use
	 * instead of the server rendering the full field list for every row.
	 *
	 * @since 7.0
	 *
	 * @param array $form_array Processed form array. Includes 'id' and 'fields' (raw field objects).
	 *
	 * @return void
	 */
	public static function maybe_localize_fields_for_js( $form_array ) {
		if ( ! self::should_defer_logic_options() || empty( $form_array['fields'] ) ) {
			return;
		}

		// Localize regardless of whether the form already has conditional logic configured.
		// A form with none yet is exactly the case where "Add Condition" is clicked for the
		// first time this page load, and that first click still needs this list to hydrate
		// its dropdown from.
		$fields    = FrmProConditionalLogicOptionData::get_all_fields_for_form( $form_array['id'] );
		$js_fields = array();

		foreach ( $fields as $field ) {
			$js_fields[] = array(
				'id'         => (int) $field->id,
				'name'       => $field->name,
				'inSection'  => (int) ( $field->field_options['in_section'] ?? 0 ),
				'likertId'   => (int) ( $field->field_options['likert_id'] ?? 0 ),
				'wholeField' => self::offers_whole_field_logic_option( $field ),
				'subFields'  => self::get_logic_sub_fields_for_js( $field ),
			);
		}

		wp_add_inline_script(
			'formidable_admin',
			'window.frmConditionalLogicFields = ' . wp_json_encode( $js_fields ) . ';',
			'after'
		);
	}

	/**
	 * Marks a field's builder container with its conditional-logic trigger-option
	 * eligibility and grouping context, so the browser can add a freshly inserted field
	 * straight into `window.frmConditionalLogicFields` (see logicRow.js) without
	 * duplicating the PHP eligibility rules in JS. Fired for every field render, including
	 * a brand new field added via drag-and-drop or the "+" button.
	 *
	 * @since 7.0
	 *
	 * @param array $attributes Extra container attributes, keyed by attribute name.
	 * @param array $field      The field being rendered.
	 *
	 * @return array
	 */
	public static function add_logic_field_data_attributes( $attributes, $field ) {
		if ( ! self::should_defer_logic_options() ) {
			return $attributes;
		}

		$form_id        = $field['parent_form_id'] ?? $field['form_id'];
		$eligible_field = FrmProConditionalLogicOptionData::get_field( $form_id, $field['id'] );

		if ( ! $eligible_field ) {
			return $attributes;
		}

		$attributes['data-frm-logic-field']       = '1';
		$attributes['data-frm-logic-in-section']  = (int) ( $eligible_field->field_options['in_section'] ?? 0 );
		$attributes['data-frm-logic-likert-id']   = (int) ( $eligible_field->field_options['likert_id'] ?? 0 );
		$attributes['data-frm-logic-whole-field'] = self::offers_whole_field_logic_option( $eligible_field ) ? '1' : '0';
		$attributes['data-frm-logic-sub-fields']  = wp_json_encode( self::get_logic_sub_fields_for_js( $eligible_field ) );

		return $attributes;
	}

	/**
	 * Whether a trigger field is offered as a whole-field conditional logic option.
	 * Address has no sensible whole-field meaning ("any part matches" is confusing when
	 * city, state and zip aren't interchangeable), so only its sub fields are offered.
	 * Name keeps its whole-field option, since it flattens to a full name (see
	 * FrmProFieldsHelper::get_observed_logic_value()).
	 *
	 * @since 7.0
	 *
	 * @param stdClass $logic_field The candidate trigger field.
	 *
	 * @return bool
	 */
	public static function offers_whole_field_logic_option( $logic_field ) {
		return 'address' !== $logic_field->type;
	}

	/**
	 * Get the sub fields of a combo field (e.g. Address's State, Name's Last) that can each be
	 * selected as a conditional logic trigger, stored as "{field_id}_{sub_field_key}".
	 *
	 * Not every combo-like field object extends FrmFieldCombo (formidable-pro's
	 * FrmProFieldAddress predates that refactor), so this checks for the method directly
	 * rather than FrmField::is_combo_field(), which drives unrelated behavior elsewhere
	 * (like CSV export column headings).
	 *
	 * @since 7.0
	 *
	 * @param stdClass $logic_field The candidate trigger field.
	 *
	 * @return array<string, string> Sub field labels, keyed by sub field key.
	 */
	public static function get_logic_sub_fields( $logic_field ) {
		$field_obj = FrmFieldFactory::get_field_object( $logic_field );

		if ( ! method_exists( $field_obj, 'get_sub_fields' ) ) {
			return array();
		}

		return wp_list_pluck( $field_obj->get_sub_fields(), 'label' );
	}

	/**
	 * Sub fields in the list shape the browser-side logic option hydration expects (see
	 * getLogicFieldOptions() in logicRow.js).
	 *
	 * @since 7.0
	 *
	 * @param stdClass $logic_field The candidate trigger field.
	 *
	 * @return array<int, array{key: string, label: string}>
	 */
	private static function get_logic_sub_fields_for_js( $logic_field ) {
		$sub_fields = array();

		foreach ( self::get_logic_sub_fields( $logic_field ) as $key => $label ) {
			$sub_fields[] = array(
				'key'   => (string) $key,
				'label' => $label,
			);
		}

		return $sub_fields;
	}

	/**
	 * Whether the installed Lite checks the `frm_should_add_logic_row_in_lite` JS filter
	 * before binding its own "Add Condition" click handler (see admin.js), instead of
	 * binding it unconditionally. An older Lite binds unconditionally, so Pro's own click
	 * handler (see initLogicRowEventListeners() in logicRow.js) must not also bind, or a
	 * single click would add two rows.
	 *
	 * Detected via `FrmAddonsHelper::is_built_in()`, a method that doesn't exist before the
	 * Lite release this filter shipped in, rather than a version number comparison.
	 *
	 * @since 7.0
	 *
	 * @return bool
	 */
	public static function lite_supports_add_logic_row_filter() {
		return is_callable( 'FrmAddonsHelper::is_built_in' );
	}

	/**
	 * Get show/hide options for field conditional logic.
	 *
	 * @since 6.24
	 *
	 * @param array $field The field array.
	 *
	 * @return array
	 */
	public static function get_show_hide_options( $field ) {
		if ( 'submit' === $field['type'] ) {
			return array(
				'show'    => __( 'Show this button', 'formidable-pro' ),
				'hide'    => __( 'Hide this button', 'formidable-pro' ),
				'enable'  => __( 'Enable this button', 'formidable-pro' ),
				'disable' => __( 'Disable this button', 'formidable-pro' ),
			);
		}

		return array(
			'show' => $field['type'] === 'break' ? __( 'Do not skip next page', 'formidable-pro' ) : __( 'Show', 'formidable-pro' ),
			'hide' => $field['type'] === 'break' ? __( 'Skip next page', 'formidable-pro' ) : __( 'Hide', 'formidable-pro' ),
		);
	}

	/**
	 * Split a stored conditional logic field reference into its base field id and, when it targets
	 * a specific sub field of a combo field (e.g. Address's State, Name's Last), the sub field key.
	 *
	 * Sub field references are stored as "{field_id}_{sub_field_key}", the same convention already
	 * used for combo fields in CSV import/export (see FrmProCSVImportHelper::check_combo_field_export_col()).
	 *
	 * @since 7.0
	 *
	 * @param int|string $logic_field_id
	 *
	 * @return array 0 is the base field id, 1 is the sub field key or false when there isn't one.
	 */
	public static function get_logic_field_id_and_sub_key( $logic_field_id ) {
		if ( is_numeric( $logic_field_id ) ) {
			return array( $logic_field_id, false );
		}

		$parts = explode( '_', (string) $logic_field_id, 2 );

		if ( 2 !== count( $parts ) || ! is_numeric( $parts[0] ) || '' === $parts[1] ) {
			return array( $logic_field_id, false );
		}

		return array( $parts[0], $parts[1] );
	}

	/**
	 * Point a stored conditional logic field reference at a new field id, keeping the sub field key.
	 *
	 * @since 7.0
	 *
	 * @param int|string $logic_field_id A field id, or "{field_id}_{sub_field_key}".
	 * @param array      $id_map         Map of original field ids to their new ids.
	 *
	 * @return int|string The reference with the new field id, or the original when the field is not in the map.
	 */
	public static function switch_logic_field_id( $logic_field_id, $id_map ) {
		list( $base_field_id, $sub_field_key ) = self::get_logic_field_id_and_sub_key( $logic_field_id );

		if ( empty( $id_map[ $base_field_id ] ) ) {
			return $logic_field_id;
		}

		return false === $sub_field_key ? $id_map[ $base_field_id ] : $id_map[ $base_field_id ] . '_' . $sub_field_key;
	}

	/**
	 * Remap an action's sub field reference during duplication or import.
	 *
	 * @since 7.0
	 *
	 * @param int|string $logic_field_id An action setting that may reference a field part.
	 *
	 * @return int|string
	 */
	public static function switch_action_logic_field_id( $logic_field_id ) {
		global $frm_duplicate_ids;

		list( , $sub_field_key ) = self::get_logic_field_id_and_sub_key( $logic_field_id );

		if ( false === $sub_field_key ) {
			// Lite already switches whole field ids before applying this filter.
			return $logic_field_id;
		}

		return self::switch_logic_field_id( $logic_field_id, (array) $frm_duplicate_ids );
	}
}
