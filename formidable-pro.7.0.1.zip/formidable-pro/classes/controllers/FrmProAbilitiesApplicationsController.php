<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Registers the Formidable application abilities for the WordPress Abilities API.
 *
 * @since 7.0
 */
class FrmProAbilitiesApplicationsController {

	/**
	 * Register the application abilities.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function register_abilities() {
		if ( ! class_exists( 'FrmProApplication' ) ) {
			return;
		}

		self::register_list_applications_ability();
		self::register_get_application_ability();
		self::register_list_application_items_ability();
		self::register_create_application_ability();
		self::register_delete_application_ability();
		self::register_add_item_to_application_ability();
		self::register_remove_item_from_application_ability();
	}

	/**
	 * Register the list applications ability.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	private static function register_list_applications_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/list-applications',
			array(
				'label'               => __( 'List Applications', 'formidable-pro' ),
				'description'         => __(
					'List all Formidable applications. Returns each id, name, item counts, and dates. Use the id for get-application or list-application-items.',
					'formidable-pro'
				),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'default'    => array(),
					'type'       => 'object',
					'properties' => array(),
				),
				'output_schema'       => array(
					'type'        => 'array',
					'description' => __( 'Array of application objects.', 'formidable-pro' ),
					'items'       => self::get_application_output_schema(),
				),
				'execute_callback'    => 'FrmProAbilitiesApplicationsController::execute_list_applications',
				'permission_callback' => 'FrmProAbilitiesApplicationsController::can_list_applications',
				'meta'                => FrmAbilitiesHelper::meta( true, false, true ),
			)
		);
	}

	/**
	 * Register the get application ability.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	private static function register_get_application_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/get-application',
			array(
				'label'               => __( 'Get Application', 'formidable-pro' ),
				'description'         => __(
					'Retrieve one application by ID. Returns its name, item counts, and dates. Use list-application-items for the items themselves.',
					'formidable-pro'
				),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'application_id' ),
					'properties' => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID. Required.', 'formidable-pro' ),
						),
					),
				),
				'output_schema'       => self::get_application_output_schema(),
				'execute_callback'    => 'FrmProAbilitiesApplicationsController::execute_get_application',
				'permission_callback' => 'FrmProAbilitiesApplicationsController::can_get_application',
				'meta'                => FrmAbilitiesHelper::meta( true, false, true ),
			)
		);
	}

	/**
	 * The schema of a single application object, shared by list and get.
	 *
	 * @since 7.0
	 *
	 * @return array
	 */
	private static function get_application_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'id'         => array(
					'type'        => 'integer',
					'description' => __( 'Numeric application ID', 'formidable-pro' ),
				),
				'name'       => array(
					'type'        => 'string',
					'description' => __( 'Application name', 'formidable-pro' ),
				),
				'form_count' => array(
					'type'        => 'integer',
					'description' => __( 'Number of published forms in the application', 'formidable-pro' ),
				),
				'view_count' => array(
					'type'        => 'integer',
					'description' => __( 'Number of views in the application', 'formidable-pro' ),
				),
				'page_count' => array(
					'type'        => 'integer',
					'description' => __( 'Number of pages in the application', 'formidable-pro' ),
				),
				'created_at' => array(
					'type'        => 'string',
					'description' => __( 'Creation date in MySQL format, or an empty string when unknown', 'formidable-pro' ),
				),
				'updated_at' => array(
					'type'        => 'string',
					'description' => __( 'Last modified date in MySQL format, or an empty string when unknown', 'formidable-pro' ),
				),
			),
		);
	}

	/**
	 * Register the list application items ability.
	 *
	 * @return void
	 */
	private static function register_list_application_items_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/list-application-items',
			array(
				'label'               => __( 'List Application Items', 'formidable-pro' ),
				'description'         => __( 'List all forms, views, and pages in an application.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'application_id' ),
					'properties' => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID. Required.', 'formidable-pro' ),
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Application object with items array.', 'formidable-pro' ),
					'properties'  => array(
						'application_id'   => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID', 'formidable-pro' ),
						),
						'application_name' => array(
							'type'        => 'string',
							'description' => __( 'Application name', 'formidable-pro' ),
						),
						'items'            => array(
							'type'        => 'array',
							'description' => __( 'Array of items in the application', 'formidable-pro' ),
							'items'       => array(
								'type'       => 'object',
								'properties' => array(
									'id'   => array(
										'type'        => array( 'string', 'integer' ),
										'description' => __( 'Item ID', 'formidable-pro' ),
									),
									'name' => array(
										'type'        => 'string',
										'description' => __( 'Item name', 'formidable-pro' ),
									),
									'type' => array(
										'type'        => 'string',
										'description' => __( 'Item type (form, view, or page)', 'formidable-pro' ),
									),
								),
							),
						),
					),
				),
				'execute_callback'    => 'FrmProAbilitiesApplicationsController::execute_list_application_items',
				'permission_callback' => 'FrmProAbilitiesApplicationsController::can_list_application_items',
				'meta'                => FrmAbilitiesHelper::meta( true, false, true ),
			)
		);
	}

	/**
	 * Register the create application ability.
	 *
	 * @return void
	 */
	private static function register_create_application_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/create-application',
			array(
				'label'               => __( 'Create Application', 'formidable-pro' ),
				'description'         => __( 'Create a new Formidable application. Applications are used to organize forms, views, and pages.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'name' ),
					'properties' => array(
						'name' => array(
							'type'        => 'string',
							'description' => __( 'Application name. Required.', 'formidable-pro' ),
							'minLength'   => 1,
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Created application object with id and name.', 'formidable-pro' ),
					'properties'  => array(
						'id'      => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID', 'formidable-pro' ),
						),
						'name'    => array(
							'type'        => 'string',
							'description' => __( 'Application name', 'formidable-pro' ),
						),
						'message' => array(
							'type'        => 'string',
							'description' => __( 'Success message', 'formidable-pro' ),
						),
					),
				),
				'execute_callback'    => 'FrmProAbilitiesApplicationsController::execute_create_application',
				'permission_callback' => 'FrmProAbilitiesApplicationsController::can_create_application',
				'meta'                => FrmAbilitiesHelper::meta( false, false, false ),
			)
		);
	}

	/**
	 * Register the delete application ability.
	 *
	 * @return void
	 */
	private static function register_delete_application_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/delete-application',
			array(
				'label'               => __( 'Delete Application', 'formidable-pro' ),
				'description'         => __(
					'Delete a Formidable application. Forms, views, and pages will remain but will no longer be associated with this application.',
					'formidable-pro'
				),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'application_id' ),
					'properties' => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID. Required.', 'formidable-pro' ),
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Response with application_id and message.', 'formidable-pro' ),
					'properties'  => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID', 'formidable-pro' ),
						),
						'message'        => array(
							'type'        => 'string',
							'description' => __( 'Success message', 'formidable-pro' ),
						),
					),
				),
				'execute_callback'    => 'FrmProAbilitiesApplicationsController::execute_delete_application',
				'permission_callback' => 'FrmProAbilitiesApplicationsController::can_delete_application',
				'meta'                => FrmAbilitiesHelper::meta( false, true, false ),
			)
		);
	}

	/**
	 * Register the add item to application ability.
	 *
	 * @return void
	 */
	private static function register_add_item_to_application_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/add-item-to-application',
			array(
				'label'               => __( 'Add Item to Application', 'formidable-pro' ),
				'description'         => __( 'Add a form, view, or page to an application.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'application_id', 'item_id', 'item_type' ),
					'properties' => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID. Required.', 'formidable-pro' ),
						),
						'item_id'        => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'ID of the item to add (form, view, or page ID). Required.', 'formidable-pro' ),
						),
						'item_type'      => array(
							'type'        => 'string',
							'description' => __( 'Type of item (form, view, or page). Required.', 'formidable-pro' ),
							'enum'        => array( 'form', 'view', 'page' ),
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Response with application_id, item_id, item_type, and message.', 'formidable-pro' ),
					'properties'  => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID', 'formidable-pro' ),
						),
						'item_id'        => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Item ID', 'formidable-pro' ),
						),
						'item_type'      => array(
							'type'        => 'string',
							'description' => __( 'Item type', 'formidable-pro' ),
						),
						'message'        => array(
							'type'        => 'string',
							'description' => __( 'Success message', 'formidable-pro' ),
						),
					),
				),
				'execute_callback'    => 'FrmProAbilitiesApplicationsController::execute_add_item_to_application',
				'permission_callback' => 'FrmProAbilitiesApplicationsController::can_add_item_to_application',
				'meta'                => FrmAbilitiesHelper::meta( false, false, false ),
			)
		);
	}

	/**
	 * Register the remove item from application ability.
	 *
	 * @return void
	 */
	private static function register_remove_item_from_application_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/remove-item-from-application',
			array(
				'label'               => __( 'Remove Item from Application', 'formidable-pro' ),
				'description'         => __( 'Remove a form, view, or page from an application.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'application_id', 'item_id', 'item_type' ),
					'properties' => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID. Required.', 'formidable-pro' ),
						),
						'item_id'        => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'ID of the item to remove (form, view, or page ID). Required.', 'formidable-pro' ),
						),
						'item_type'      => array(
							'type'        => 'string',
							'description' => __( 'Type of item (form, view, or page). Required.', 'formidable-pro' ),
							'enum'        => array( 'form', 'view', 'page' ),
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Response with application_id, item_id, item_type, and message.', 'formidable-pro' ),
					'properties'  => array(
						'application_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Application ID', 'formidable-pro' ),
						),
						'item_id'        => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Item ID', 'formidable-pro' ),
						),
						'item_type'      => array(
							'type'        => 'string',
							'description' => __( 'Item type', 'formidable-pro' ),
						),
						'message'        => array(
							'type'        => 'string',
							'description' => __( 'Success message', 'formidable-pro' ),
						),
					),
				),
				'execute_callback'    => 'FrmProAbilitiesApplicationsController::execute_remove_item_from_application',
				'permission_callback' => 'FrmProAbilitiesApplicationsController::can_remove_item_from_application',
				'meta'                => FrmAbilitiesHelper::meta( false, false, false ),
			)
		);
	}

	/**
	 * List the applications on the site.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_list_applications( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$ready = self::prepare_taxonomy();

		if ( is_wp_error( $ready ) ) {
			return $ready;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => 'frm_application',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return FrmAbilitiesHelper::flatten_error( $terms );
		}

		if ( ! is_array( $terms ) ) {
			// get_terms() answers with a count as a string when asked for one.
			// Nothing here asks for that, so anything else means no applications.
			return array();
		}

		$data = array();

		foreach ( $terms as $term ) {
			if ( ! $term instanceof WP_Term ) {
				continue;
			}

			$data[] = self::prepare_application_for_response( $term );
		}

		return $data;
	}

	/**
	 * Get one application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_get_application( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$term = self::get_application( $input['application_id'] );

		return is_wp_error( $term ) ? $term : self::prepare_application_for_response( $term );
	}

	/**
	 * List the forms, views, and pages in an application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_list_application_items( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$term = self::get_application( $input['application_id'] );

		if ( is_wp_error( $term ) ) {
			return $term;
		}

		$application_id = (int) $term->term_id;
		$items          = array();

		foreach ( FrmProApplication::get_forms_for_application( $application_id ) as $form ) {
			$items[] = array(
				'id'   => (int) $form->id,
				'name' => (string) $form->name,
				'type' => 'form',
			);
		}

		foreach ( FrmProApplication::get_posts_for_application( $application_id ) as $post ) {
			$items[] = array(
				'id'   => (int) $post->ID,
				'name' => (string) $post->post_title,
				'type' => 'frm_display' === $post->post_type ? 'view' : 'page',
			);
		}

		return array(
			'application_id'   => $application_id,
			'application_name' => (string) $term->name,
			'items'            => $items,
		);
	}

	/**
	 * Create an application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_create_application( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$ready = self::prepare_taxonomy();

		if ( is_wp_error( $ready ) ) {
			return $ready;
		}

		$name = isset( $input['name'] ) ? sanitize_text_field( $input['name'] ) : '';

		if ( ! $name ) {
			return new WP_Error( 'frm_invalid_name', __( 'An application name is required.', 'formidable-pro' ), array( 'status' => 400 ) );
		}

		$term = FrmProApplication::create( $name );

		if ( is_wp_error( $term ) ) {
			return FrmAbilitiesHelper::flatten_error( $term );
		}

		if ( ! is_array( $term ) ) {
			return new WP_Error( 'frm_create_failed', __( 'Failed to create the application.', 'formidable-pro' ), array( 'status' => 500 ) );
		}

		return array(
			'id'      => (int) $term['term_id'],
			'name'    => $name,
			'message' => __( 'Application created successfully.', 'formidable-pro' ),
		);
	}

	/**
	 * Delete an application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_delete_application( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$term = self::get_application( $input['application_id'] );

		if ( is_wp_error( $term ) ) {
			return $term;
		}

		$application_id = (int) $term->term_id;
		$result         = wp_delete_term( $application_id, 'frm_application' );

		if ( is_wp_error( $result ) ) {
			return FrmAbilitiesHelper::flatten_error( $result );
		}

		if ( ! $result ) {
			return new WP_Error( 'frm_delete_failed', __( 'Failed to delete the application.', 'formidable-pro' ), array( 'status' => 500 ) );
		}

		return array(
			'application_id' => $application_id,
			'message'        => __( 'Application deleted successfully.', 'formidable-pro' ),
		);
	}

	/**
	 * Add a form, view, or page to an application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_add_item_to_application( $input ) {
		return self::change_application_membership( $input, 'add' );
	}

	/**
	 * Remove a form, view, or page from an application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_remove_item_from_application( $input ) {
		return self::change_application_membership( $input, 'remove' );
	}

	/**
	 * Add or remove one item, which differ only in which model call they make.
	 *
	 * @since 7.0
	 *
	 * @param array  $input  Ability input parameters.
	 * @param string $action Either add or remove.
	 *
	 * @return array|WP_Error
	 */
	private static function change_application_membership( $input, $action ) {
		FrmAbilitiesHelper::set_current_user();

		$term = self::get_application( $input['application_id'] );

		if ( is_wp_error( $term ) ) {
			return $term;
		}

		$item_id   = absint( $input['item_id'] );
		$item_type = sanitize_text_field( $input['item_type'] );

		if ( ! in_array( $item_type, array( 'form', 'view', 'page' ), true ) ) {
			return new WP_Error( 'frm_invalid_type', __( 'Invalid item type. Use form, view, or page.', 'formidable-pro' ), array( 'status' => 400 ) );
		}

		$application_id = (int) $term->term_id;
		$result         = 'add' === $action
			? self::add_item_by_type( $application_id, $item_id, $item_type )
			: self::remove_item_by_type( $application_id, $item_id, $item_type );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'application_id' => $application_id,
			'item_id'        => $item_id,
			'item_type'      => $item_type,
			'message'        => 'add' === $action
				? __( 'Item added to application successfully.', 'formidable-pro' )
				: __( 'Item removed from application successfully.', 'formidable-pro' ),
		);
	}

	/**
	 * Add one item to an application.
	 *
	 * @since 7.0
	 *
	 * @param int    $application_id Application term ID.
	 * @param int    $item_id        ID of the form or post being added.
	 * @param string $item_type      One of form, view, or page.
	 *
	 * @return true|WP_Error
	 */
	private static function add_item_by_type( $application_id, $item_id, $item_type ) {
		if ( 'form' === $item_type ) {
			if ( ! FrmForm::getOne( $item_id ) ) {
				return new WP_Error( 'frm_form_not_found', __( 'That form does not exist.', 'formidable-pro' ), array( 'status' => 404 ) );
			}

			// add_form_to_application() appends a _frm_form_id term meta with no
			// dedup, so re-adding the same form would leave a duplicate row. The
			// view and page path is already idempotent through wp_set_post_terms.
			$existing = array_map( 'intval', (array) get_term_meta( $application_id, '_frm_form_id' ) );

			if ( ! in_array( (int) $item_id, $existing, true ) ) {
				FrmProApplication::add_form_to_application( $application_id, $item_id );
			}

			return true;
		}

		$post = self::get_item_post( $item_id, $item_type );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		FrmProApplication::add_post_to_application( $application_id, $post->ID, $item_type );

		return true;
	}

	/**
	 * Remove one item from an application.
	 *
	 * @since 7.0
	 *
	 * @param int    $application_id Application term ID.
	 * @param int    $item_id        ID of the form or post being removed.
	 * @param string $item_type      One of form, view, or page.
	 *
	 * @return true|WP_Error
	 */
	private static function remove_item_by_type( $application_id, $item_id, $item_type ) {
		if ( 'form' === $item_type ) {
			if ( ! FrmForm::getOne( $item_id ) ) {
				return new WP_Error( 'frm_form_not_found', __( 'That form does not exist.', 'formidable-pro' ), array( 'status' => 404 ) );
			}

			FrmProApplication::remove_form_from_application( $application_id, $item_id );

			return true;
		}

		$post = self::get_item_post( $item_id, $item_type );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		FrmProApplication::remove_post_from_application( $application_id, $post->ID, $item_type );

		return true;
	}

	/**
	 * Load the post behind a view or page item, confirming it is that type.
	 *
	 * Forms, views, and pages are numbered independently, so an ID that is
	 * valid as one is usually valid as another. Without this check a form ID
	 * sent as a view lands on whichever post happens to share that ID, and
	 * wp_set_post_terms() then fails quietly because frm_application is only
	 * registered for pages, views, and forms, leaving the caller with a success
	 * response and an unchanged application.
	 *
	 * @since 7.0
	 *
	 * @param int    $item_id   ID of the post being added or removed.
	 * @param string $item_type Either view or page.
	 *
	 * @return WP_Error|WP_Post
	 */
	private static function get_item_post( $item_id, $item_type ) {
		$post_type = 'view' === $item_type ? 'frm_display' : 'page';
		$post      = get_post( $item_id );

		if ( $post && $post_type === $post->post_type ) {
			return $post;
		}

		$message = 'view' === $item_type
			? __( 'That view does not exist.', 'formidable-pro' )
			: __( 'That page does not exist.', 'formidable-pro' );

		return new WP_Error( 'frm_post_not_found', $message, array( 'status' => 404 ) );
	}

	/**
	 * Load one application term.
	 *
	 * @since 7.0
	 *
	 * @param int|string $id Application term ID.
	 *
	 * @return WP_Error|WP_Term
	 */
	private static function get_application( $id ) {
		$ready = self::prepare_taxonomy();

		if ( is_wp_error( $ready ) ) {
			return $ready;
		}

		$term = get_term( absint( $id ), 'frm_application' );

		if ( ! $term instanceof WP_Term ) {
			return new WP_Error( 'frm_application_not_found', __( 'That application does not exist.', 'formidable-pro' ), array( 'status' => 404 ) );
		}

		return $term;
	}

	/**
	 * Make sure the application taxonomy is registered before it is queried.
	 *
	 * Pro registers frm_application on an admin page load, so a REST or MCP
	 * request would otherwise query a taxonomy that does not exist yet.
	 *
	 * @since 7.0
	 *
	 * @return true|WP_Error
	 */
	private static function prepare_taxonomy() {
		if ( ! class_exists( 'FrmProApplication' ) ) {
			return FrmAbilitiesHelper::missing_plugin_error( 'Formidable Forms Pro' );
		}

		if ( class_exists( 'FrmProAppController' ) ) {
			FrmProAppController::create_taxonomies();
		}

		return true;
	}

	/**
	 * Build the response shape for one application.
	 *
	 * @since 7.0
	 *
	 * @param WP_Term $term The frm_application term.
	 *
	 * @return array
	 */
	private static function prepare_application_for_response( $term ) {
		return array(
			'id'         => (int) $term->term_id,
			'name'       => (string) $term->name,
			'form_count' => (int) get_term_meta( $term->term_id, '_frm_form_count', true ),
			'view_count' => (int) get_term_meta( $term->term_id, '_frm_view_count', true ),
			'page_count' => (int) get_term_meta( $term->term_id, '_frm_page_count', true ),
			'created_at' => self::format_application_time( $term->term_id, '_frm_created_at' ),
			'updated_at' => self::format_application_time( $term->term_id, '_frm_updated_at' ),
		);
	}

	/**
	 * Format an application's stored unix timestamp as a MySQL datetime.
	 *
	 * @since 7.0
	 *
	 * @param int    $term_id  Application term ID.
	 * @param string $meta_key Term meta key holding the timestamp.
	 *
	 * @return string MySQL datetime, or an empty string when unset.
	 */
	private static function format_application_time( $term_id, $meta_key ) {
		$timestamp = (int) get_term_meta( $term_id, $meta_key, true );
		return $timestamp > 0 ? gmdate( 'Y-m-d H:i:s', $timestamp ) : '';
	}

	/**
	 * Permission callback for the read-only application abilities.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_list_applications( $input ) {
		return current_user_can( 'frm_view_forms' ) || current_user_can( 'administrator' );
	}

	/**
	 * Permission callback for get application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_get_application( $input ) {
		return self::can_list_applications( $input );
	}

	/**
	 * Permission callback for list application items.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_list_application_items( $input ) {
		return self::can_list_applications( $input );
	}

	/**
	 * Permission callback for create application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_create_application( $input ) {
		return current_user_can( 'frm_edit_forms' ) || current_user_can( 'administrator' );
	}

	/**
	 * Permission callback for delete application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_delete_application( $input ) {
		return current_user_can( 'frm_delete_forms' ) || current_user_can( 'administrator' );
	}

	/**
	 * Permission callback for add item to application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_add_item_to_application( $input ) {
		return current_user_can( 'frm_edit_forms' ) || current_user_can( 'administrator' );
	}

	/**
	 * Permission callback for remove item from application.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_remove_item_from_application( $input ) {
		return current_user_can( 'frm_edit_forms' ) || current_user_can( 'administrator' );
	}
}
