<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Registers the style abilities that belong to Pro.
 *
 * Formidable supports a single style, so there is nothing to add or delete
 * there and nothing to choose between when assigning one to a form. All three
 * live here, while Formidable owns listing, reading, and updating.
 *
 * @since 7.0
 */
class FrmProAbilitiesStylesController {

	/**
	 * Register the style abilities.
	 *
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function register_abilities() {
		self::register_create_style_ability();
		self::register_delete_style_ability();
		self::register_assign_style_to_form_ability();
	}

	/**
	 * Register the create style ability.
	 *
	 * @return void
	 */
	private static function register_create_style_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/create-style',
			array(
				'label'               => __( 'Create Style', 'formidable-pro' ),
				'description'         => __( 'Create a new Formidable style with optional settings.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array(),
					'properties' => array(
						'name'         => array(
							'type'        => 'string',
							'description' => __( 'Style name. Defaults to "New Style" if not provided.', 'formidable-pro' ),
						),
						'post_content' => array(
							'type'                 => 'object',
							'description'          => __(
								'Style settings array containing colors, fonts, spacing, etc. Defaults to default style settings if not provided.',
								'formidable-pro'
							),
							'additionalProperties' => true,
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Created style object with comprehensive properties.', 'formidable-pro' ),
				),
				'execute_callback'    => 'FrmProAbilitiesStylesController::execute_create_style',
				'permission_callback' => 'FrmProAbilitiesStylesController::can_create_style',
				'meta'                => FrmAbilitiesHelper::meta( false, false, false ),
			)
		);
	}

	/**
	 * Register the delete style ability.
	 *
	 * @return void
	 */
	private static function register_delete_style_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/delete-style',
			array(
				'label'               => __( 'Delete Style', 'formidable-pro' ),
				'description'         => __( 'Delete a Formidable style. Cannot delete the default style. Forms using it are switched to the default style.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'id' ),
					'properties' => array(
						'id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Style ID or post_name.', 'formidable' ),
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Deleted style object, with reassigned_form_ids listing the forms moved to the default style.', 'formidable-pro' ),
				),
				'execute_callback'    => 'FrmProAbilitiesStylesController::execute_delete_style',
				'permission_callback' => 'FrmProAbilitiesStylesController::can_delete_style',
				'meta'                => FrmAbilitiesHelper::meta( false, true, false ),
			)
		);
	}

	/**
	 * Register the assign style to form ability.
	 *
	 * @return void
	 */
	private static function register_assign_style_to_form_ability() {
		FrmAbilitiesHelper::register(
			'formidable-forms/assign-style-to-form',
			array(
				'label'               => __( 'Assign Style to Form', 'formidable-pro' ),
				'description'         => __( 'Assign a style to a form. Use list-forms to find the form_id, and list-styles to find the style_id.', 'formidable-pro' ),
				'category'            => FrmAbilitiesController::CATEGORY,
				'input_schema'        => array(
					'type'       => 'object',
					'required'   => array( 'form_id', 'style_id' ),
					'properties' => array(
						'form_id'  => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Form ID or form_key. Required.', 'formidable-pro' ),
						),
						'style_id' => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Style ID or post_name to assign to the form. Use 0 to disable custom style. Required.', 'formidable-pro' ),
						),
					),
				),
				'output_schema'       => array(
					'type'        => 'object',
					'description' => __( 'Response with form_id, style_id, and message.', 'formidable-pro' ),
					'properties'  => array(
						'form_id'     => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Form ID', 'formidable-pro' ),
						),
						'style_id'    => array(
							'type'        => array( 'string', 'integer' ),
							'description' => __( 'Assigned style ID', 'formidable-pro' ),
						),
						'previous_id' => array(
							'type'        => 'integer',
							'description' => __( 'Previous style ID', 'formidable-pro' ),
						),
						'message'     => array(
							'type'        => 'string',
							'description' => __( 'Success message', 'formidable-pro' ),
						),
					),
				),
				'execute_callback'    => 'FrmProAbilitiesStylesController::execute_assign_style_to_form',
				'permission_callback' => 'FrmProAbilitiesStylesController::can_assign_style_to_form',
				'meta'                => FrmAbilitiesHelper::meta( false, false, false ),
			)
		);
	}

	/**
	 * /**
	 * Create a style.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_create_style( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$frm_style = new FrmStyle();
		$new_style = $frm_style->get_new();

		$new_style->post_type = FrmStylesController::$post_type;

		if ( isset( $input['name'] ) ) {
			$new_style->post_title = sanitize_text_field( $input['name'] );
		}

		if ( isset( $input['post_content'] ) && is_array( $input['post_content'] ) ) {
			// Merge over the defaults from get_new() so the stored settings are
			// complete, matching update-style and the styler UI. FrmStyle::get_one()
			// backfills defaults on read, so a lean row still renders, but
			// persisting the full set keeps create and update consistent and is
			// safe for anything reading the row directly.
			$defaults                = is_array( $new_style->post_content ) ? $new_style->post_content : array();
			$new_style->post_content = array_merge( $defaults, FrmAbilitiesStylesController::strip_hex_prefix( $input['post_content'] ) );
		}

		$id = $frm_style->save( (array) $new_style );

		if ( ! $id || is_wp_error( $id ) ) {
			return new WP_Error( 'frm_create_style', __( 'Style creation failed.', 'formidable-pro' ), array( 'status' => 409 ) );
		}

		// FrmStyle->save() does not respect post_type, so set it explicitly.
		wp_update_post(
			array(
				'ID'        => $id,
				'post_type' => FrmStylesController::$post_type,
			)
		);

		// Regenerate the stylesheet and refresh the transients.
		$frm_style->save_settings();

		return FrmAbilitiesStylesController::execute_get_style( array( 'id' => $id ) );
	}

	/**
	 * Delete a style.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_delete_style( $input ) {
		FrmAbilitiesHelper::set_current_user();

		// Read the style before it is gone, so the caller gets back what it
		// deleted, and so an ID belonging to some other post type is turned away
		// rather than trashed.
		$style = self::get_style( $input['id'] );

		if ( is_wp_error( $style ) ) {
			return $style;
		}

		$frm_style = new FrmStyle( $style->ID );

		if ( ! $frm_style->destroy( $style->ID ) ) {
			return new WP_Error(
				'frm_style_delete_failed',
				__( 'That style could not be deleted. The default style cannot be deleted.', 'formidable-pro' ),
				array( 'status' => 403 )
			);
		}

		$reassigned = self::reassign_forms_to_default_style( (int) $style->ID );

		// Sync the CSS and transient, as the style list does after a delete.
		$frm_style->save_settings();

		$response                        = FrmAbilitiesStylesController::prepare_style_for_response( $style );
		$response['reassigned_form_ids'] = $reassigned;

		if ( $reassigned ) {
			$response['message'] = sprintf(
				/* translators: %d: number of forms */
				_n(
					'%d form used this style and now uses the default style.',
					'%d forms used this style and now use the default style.',
					count( $reassigned ),
					'formidable-pro'
				),
				count( $reassigned )
			);
		}

		return $response;
	}

	/**
	 * Point every form that used a deleted style back at the default style.
	 *
	 * A form keeps its custom_style ID after the style post is gone, and then
	 * renders with no style at all. Storing 1 makes it follow whichever style is
	 * default, which is what a form with no style choice does.
	 *
	 * @since 7.0
	 *
	 * @param int $style_id ID of the style that was deleted.
	 *
	 * @return array IDs of the forms that were changed.
	 */
	private static function reassign_forms_to_default_style( $style_id ) {
		// custom_style is stored as a string by the styler, but older saves may
		// hold an int, so both serialized shapes are searched for.
		$substrings = array();

		foreach ( array( (string) $style_id, $style_id ) as $value ) {
			$substrings[] = substr( serialize( array( 'custom_style' => $value ) ), 5, -1 );
		}

		$form_ids   = FrmDb::get_col( 'frm_forms', array( 'options LIKE' => $substrings ), 'id' );
		$reassigned = array();

		foreach ( $form_ids as $form_id ) {
			$form = FrmForm::getOne( $form_id );

			if ( ! $form || ! isset( $form->options['custom_style'] ) || (int) $form->options['custom_style'] !== $style_id ) {
				continue;
			}

			$form->options['custom_style'] = '1';

			FrmForm::update( $form->id, (array) $form );

			$reassigned[] = (int) $form->id;
		}

		return $reassigned;
	}

	/**
	 * Assign a style to a form.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return array|WP_Error
	 */
	public static function execute_assign_style_to_form( $input ) {
		FrmAbilitiesHelper::set_current_user();

		$form = FrmAbilitiesHelper::get_form( $input['form_id'] );

		if ( is_wp_error( $form ) ) {
			return $form;
		}

		if ( isset( $input['style_id'] ) && self::is_style_post_name( $input['style_id'] ) ) {
			$style = self::get_style( $input['style_id'] );

			if ( is_wp_error( $style ) ) {
				return new WP_Error( 'frm_style_not_found', __( 'Invalid target style.', 'formidable-pro' ), array( 'status' => 400 ) );
			}

			$input['style_id'] = (int) $style->ID;
		}

		// A style_id of 0 is meaningful: it detaches the form from every style
		// and falls the form back to the default, so it is told apart from an
		// omitted or unusable value rather than treated as empty.
		$raw_style_id = isset( $input['style_id'] ) ? sanitize_text_field( $input['style_id'] ) : '0';
		$style_id     = isset( $input['style_id'] ) ? absint( $input['style_id'] ) : 0;

		// 0 and 1 are both reserved rather than style IDs: 0 turns the form's
		// styling off, and 1 is the legacy "always use default" value the styler
		// writes so a form follows whichever style is default later. Neither is
		// looked up, everything else has to be a real style.
		if ( $style_id > 1 && ! self::style_exists( $style_id ) ) {
			return new WP_Error( 'frm_style_not_found', __( 'Invalid target style.', 'formidable-pro' ), array( 'status' => 400 ) );
		}

		/**
		 * Filter the style ID about to be saved on a form.
		 *
		 * @since 7.0
		 *
		 * @param int $style_id The style ID being assigned.
		 */
		$style_id = apply_filters( 'frm_saved_form_style_id', $style_id );

		if ( ! $style_id && '0' !== $raw_style_id ) {
			return new WP_Error( 'frm_invalid_style', __( 'Invalid style value.', 'formidable-pro' ), array( 'status' => 400 ) );
		}

		$previous_style_id = $form->options['custom_style'] ?? '';
		$frm_style         = new FrmStyle();
		$default_style     = $frm_style->get_default_style();

		// A form pointing at the default style stores 1 rather than that style's
		// own ID, so the form follows whichever style is default later.
		if ( $default_style && $style_id === $default_style->ID && empty( $form->options['chat'] ) ) {
			$style_id = 1;
		}

		$form->options['custom_style'] = (string) $style_id;

		FrmForm::update( $form->id, (array) $form );

		return array(
			'form_id'     => (int) $form->id,
			'style_id'    => (int) $style_id,
			'previous_id' => $previous_style_id,
			'message'     => __( 'Style assigned to form successfully.', 'formidable-pro' ),
		);
	}

	/**
	 * Check that a style exists.
	 *
	 * @since 7.0
	 *
	 * @param int $style_id Style ID.
	 *
	 * @return bool
	 */
	private static function style_exists( $style_id ) {
		if ( ! class_exists( 'FrmStyle' ) ) {
			return false;
		}

		// get_style() rejects an ID that belongs to a post which is not a style,
		// so a page ID cannot be saved on a form as its style.
		return ! is_wp_error( self::get_style( $style_id ) );
	}

	/**
	 * Load one style by ID, post_name, or as the default.
	 *
	 * FrmAbilitiesStylesController::get_style() hands the id to FrmStyle first,
	 * and get_post() casts it to an int. A post_name that starts with digits,
	 * like "5k2x", would then load post 5 instead of looking up the name. So a
	 * post_name is turned into the style's ID here before the shared lookup runs.
	 *
	 * @since 7.0
	 *
	 * @param int|string $id Style ID, post_name, or 'default' for the default style.
	 *
	 * @return stdClass|WP_Error|WP_Post
	 */
	private static function get_style( $id ) {
		if ( self::is_style_post_name( $id ) ) {
			$id = self::get_style_id_by_post_name( sanitize_text_field( $id ) );

			if ( ! $id ) {
				return new WP_Error( 'frm_style_invalid_id', __( 'Invalid style ID.', 'formidable' ), array( 'status' => 404 ) );
			}
		}

		return FrmAbilitiesStylesController::get_style( $id );
	}

	/**
	 * Check whether a style identifier is a post_name rather than an ID.
	 *
	 * @since 7.0
	 *
	 * @param mixed $id Style ID, post_name, or 'default'.
	 *
	 * @return bool
	 */
	private static function is_style_post_name( $id ) {
		return is_string( $id ) && '' !== $id && ! is_numeric( $id ) && 'default' !== $id;
	}

	/**
	 * Find the ID of the published style with a post_name.
	 *
	 * @since 7.0
	 *
	 * @param string $post_name The style's post_name.
	 *
	 * @return int The style ID, or 0 when no style has that post_name.
	 */
	private static function get_style_id_by_post_name( $post_name ) {
		$styles = get_posts(
			array(
				'name'        => $post_name,
				'post_type'   => FrmStylesController::$post_type,
				'post_status' => 'publish',
				'numberposts' => 1,
			)
		);

		$style = $styles ? reset( $styles ) : null;

		return $style instanceof WP_Post ? (int) $style->ID : 0;
	}

	/**
	 * Permission callback for create style.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_create_style( $input ) {
		return current_user_can( 'frm_change_settings' ) || current_user_can( 'administrator' );
	}

	/**
	 * Permission callback for delete style.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_delete_style( $input ) {
		return current_user_can( 'frm_change_settings' ) || current_user_can( 'administrator' );
	}

	/**
	 * Permission callback for assign style to form.
	 *
	 * @since 7.0
	 *
	 * @param array $input Ability input parameters.
	 *
	 * @return bool
	 */
	public static function can_assign_style_to_form( $input ) {
		return current_user_can( 'frm_edit_forms' ) || current_user_can( 'administrator' );
	}
}
