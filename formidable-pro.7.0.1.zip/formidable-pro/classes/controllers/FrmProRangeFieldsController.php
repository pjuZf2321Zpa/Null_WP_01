<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Keeps the end field of a date or time range in step with its start field.
 *
 * The two fields of a range describe a single choice, so the settings that decide whether and how
 * that choice is made belong to the pair rather than to either half. They are only changed on the
 * start field, and the end field takes them from there.
 *
 * @since 7.0
 */
class FrmProRangeFieldsController {

	/**
	 * Gets the settings Pro itself shares between the two fields of a range.
	 *
	 * These are the ones the builder keeps in step and locks on the end field. An add-on that shares
	 * more of its own does that part itself.
	 *
	 * @since 7.0
	 *
	 * @param string $field_type The range's field type, date or time.
	 *
	 * @return string[]
	 */
	public static function get_builder_synced_settings( $field_type ) {
		$settings = array( 'required', 'unique', 'read_only', 'admin_only' );

		if ( 'time' === $field_type ) {
			$settings[] = 'linked_date_field';
		}

		if ( 'date' === $field_type ) {
			$settings[] = 'start_year';
			$settings[] = 'end_year';
		}

		return $settings;
	}

	/**
	 * Gets every setting the end field of a range takes from its start field.
	 *
	 * @since 7.0
	 *
	 * @param string $field_type The range's field type, date or time.
	 *
	 * @return string[]
	 */
	public static function get_synced_settings( $field_type ) {
		/**
		 * Filters the settings the end field of a range takes from its start field.
		 *
		 * Pro copies each of these to the end field whenever the form is saved. A setting added here
		 * is not kept in step in the builder, so the add-on that adds it has to do that itself.
		 *
		 * @since 7.0
		 *
		 * @param string[] $settings   Field option names, or `required` for the field's own column.
		 * @param string   $field_type The range's field type, date or time.
		 */
		$settings = apply_filters( 'frm_range_end_field_synced_settings', self::get_builder_synced_settings( $field_type ), $field_type );

		return is_array( $settings ) ? array_values( array_unique( $settings ) ) : array();
	}

	/**
	 * Gives the end field of a range the shared settings its start field has when it is created.
	 *
	 * The builder creates the end field with only the options that pair it with its start field, so
	 * without this it would start out with none of the start field's settings.
	 *
	 * @since 7.0
	 *
	 * @param array $field_values The values the new field is about to be created with.
	 *
	 * @return array
	 */
	public static function copy_synced_settings_to_new_end_field( $field_values ) {
		if ( ! self::is_range_field_type( $field_values['type'] ) ||
			empty( $field_values['field_options']['is_range_end_field'] ) ||
			empty( $field_values['field_options']['range_start_field'] )
		) {
			return $field_values;
		}

		$start_field = FrmField::getOne( (int) $field_values['field_options']['range_start_field'] );

		if ( ! $start_field ) {
			return $field_values;
		}

		foreach ( self::get_synced_settings( $field_values['type'] ) as $setting ) {
			if ( 'required' === $setting ) {
				$field_values['required'] = (int) $start_field->required;
				continue;
			}

			$field_values['field_options'][ $setting ] = FrmField::get_option( $start_field, $setting );
		}

		return $field_values;
	}

	/**
	 * Copies the shared settings from the start field of each range in the form to its end field.
	 *
	 * This runs once every field has been saved, so it reads what the start field was saved with,
	 * whether or not the end field's own settings were part of the same save.
	 *
	 * @since 7.0
	 *
	 * @param int $form_id The form that was saved.
	 *
	 * @return void
	 */
	public static function sync_range_end_fields( $form_id ) {
		foreach ( FrmField::get_all_for_form( $form_id ) as $field ) {
			if ( ! self::is_range_field_type( $field->type ) || ! FrmField::get_option( $field, 'is_range_end_field' ) ) {
				continue;
			}

			$start_field_id = (int) FrmField::get_option( $field, 'range_start_field' );
			$start_field    = $start_field_id ? FrmField::getOne( $start_field_id ) : null;

			if ( ! $start_field || $start_field->type !== $field->type ) {
				continue;
			}

			self::copy_synced_settings( $start_field, $field );
		}
	}

	/**
	 * Copies the shared settings from one field of a range to the other, when any of them differ.
	 *
	 * @since 7.0
	 *
	 * @param object $start_field The start field to copy from.
	 * @param object $end_field   The end field to copy to.
	 *
	 * @return void
	 */
	private static function copy_synced_settings( $start_field, $end_field ) {
		$field_options = is_array( $end_field->field_options ) ? $end_field->field_options : array();
		$new_values    = array();

		foreach ( self::get_synced_settings( $end_field->type ) as $setting ) {
			if ( 'required' === $setting ) {
				if ( (int) $start_field->required !== (int) $end_field->required ) {
					$new_values['required'] = (int) $start_field->required;
				}
				continue;
			}

			$start_value = FrmField::get_option( $start_field, $setting );

			if ( array_key_exists( $setting, $field_options ) && $field_options[ $setting ] === $start_value ) {
				continue;
			}

			$field_options[ $setting ]   = $start_value;
			$new_values['field_options'] = $field_options;
		}

		if ( $new_values ) {
			FrmField::update( (int) $end_field->id, $new_values );
		}
	}

	/**
	 * Decides whether a field type offers the range option.
	 *
	 * @since 7.0
	 *
	 * @param string $field_type The field type.
	 *
	 * @return bool
	 */
	private static function is_range_field_type( $field_type ) {
		return in_array( $field_type, array( 'date', 'time' ), true );
	}
}
