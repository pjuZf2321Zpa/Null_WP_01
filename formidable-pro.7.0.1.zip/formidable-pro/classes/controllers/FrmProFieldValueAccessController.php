<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Lets logged-out visitors read their own entries with [frm-field-value], and warns
 * admins when the ownership check hides a value prefilled into a field's default value.
 *
 * @since 7.0.1
 */
class FrmProFieldValueAccessController {

	/**
	 * Stores the default value lookups that the ownership check blocked, indexed by
	 * the ID of the field whose default value holds the shortcode.
	 *
	 * @var string
	 */
	const BLOCKED_LOOKUPS_OPTION = 'frm_field_value_blocked_lookups';

	/**
	 * The most fields a site keeps flagged at once, so a busy site cannot grow the option without limit.
	 *
	 * @var int
	 */
	const MAX_BLOCKED_LOOKUPS = 50;

	/**
	 * The most warnings shown at once. The rest are counted in one line below them.
	 *
	 * @var int
	 */
	const MAX_SHOWN_BLOCKED_LOOKUPS = 2;

	/**
	 * Remembers the entries a logged-out visitor submitted, so they can see their own
	 * entry on the next form, as in entry=pass_entry.
	 *
	 * @var string
	 */
	const GUEST_ENTRIES_COOKIE = 'frm_own_entries';

	/**
	 * The most entries the guest entries cookie remembers, newest kept.
	 *
	 * @var int
	 */
	const MAX_GUEST_ENTRIES = 10;

	/**
	 * The fields whose default values are being processed, innermost last.
	 *
	 * @var array<array{field: false|stdClass, has_nested_target: bool}>
	 */
	private static $default_value_stack = array();

	/**
	 * Track the field whose default value is about to have its shortcodes processed.
	 *
	 * @param false|stdClass $field The field that owns the default value.
	 * @param mixed          $value The default value before any shortcodes were replaced.
	 *
	 * @return void
	 */
	public static function start_default_value( $field, $value = '' ) {
		self::$default_value_stack[] = array(
			'field'             => is_object( $field ) ? $field : false,
			'has_nested_target' => is_string( $value ) && self::has_nested_lookup_target( $value ),
		);
	}

	/**
	 * Check if a [frm-field-value] shortcode in the value has another shortcode in its
	 * attributes, like entry="[get param=id]". Those get replaced before the lookup
	 * runs, so the lookup can no longer tell that the value came from the visitor.
	 *
	 * @param string $value The default value before any shortcodes were replaced.
	 *
	 * @return bool
	 */
	private static function has_nested_lookup_target( $value ) {
		return str_contains( $value, '[frm-field-value' ) && preg_match( '/\[frm-field-value\b[^\]]*\[/', $value );
	}

	/**
	 * Check if the entry a lookup targets comes from the request, as in entry=pass_entry
	 * or entry="[get param=id]". Blocking those is the ownership check doing its job,
	 * and a visitor could change the URL to raise the admin warning at will.
	 *
	 * @param array $atts The shortcode attributes, before the entry parameter is resolved.
	 *
	 * @return bool
	 */
	public static function lookup_target_from_request( $atts ) {
		$context = end( self::$default_value_stack );

		if ( $context && $context['has_nested_target'] ) {
			return true;
		}

		// A non-numeric entry names a URL parameter, and falls back to an entry key when the URL does not have it.
		return ! empty( $atts['entry'] ) && ! is_numeric( $atts['entry'] ) && '' !== FrmAppHelper::simple_get( $atts['entry'], 'sanitize_title' );
	}

	/**
	 * Stop tracking the field from the matching start_default_value() call.
	 *
	 * @return void
	 */
	public static function end_default_value() {
		array_pop( self::$default_value_stack );
	}

	/**
	 * Check if a lookup was saved in the form builder, in the default value being processed.
	 * Someone who can edit forms chose to show that entry, so its value is treated as public.
	 *
	 * The lookup must match a [frm-field-value] shortcode in the field's saved settings exactly,
	 * so a shortcode that reached the default value some other way is never trusted. Its target
	 * must also be fixed, not taken from the request as in entry=pass_entry.
	 *
	 * @param stdClass $target_field The field named in the shortcode's field_id.
	 * @param array    $atts         The shortcode attributes, before the entry parameter is resolved.
	 *
	 * @return bool
	 */
	public static function is_saved_default_value_lookup( $target_field, $atts ) {
		$host_field = self::get_default_value_field();

		if ( ! $host_field || self::is_private_field( $target_field ) || self::lookup_target_from_request( $atts ) ) {
			return false;
		}

		foreach ( self::get_saved_lookups( $host_field ) as $saved_atts ) {
			if ( self::is_same_lookup( $saved_atts, $atts ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Password and credit card values are never shown to visitors, even from the form builder.
	 *
	 * @param stdClass $field The field named in the shortcode's field_id.
	 *
	 * @return bool
	 */
	private static function is_private_field( $field ) {
		return FrmField::is_field_type( $field, 'password' ) || FrmField::is_field_type( $field, 'credit_card' );
	}

	/**
	 * Get the attributes of each [frm-field-value] shortcode in a field's saved default value.
	 * A shortcode with another shortcode in its attributes is left out, since its target comes from the request.
	 *
	 * @param stdClass $field The field whose default value holds the shortcodes.
	 *
	 * @return array<array>
	 */
	private static function get_saved_lookups( $field ) {
		preg_match_all( '/\[frm-field-value\b([^\[\]]*)\]/', self::get_saved_default_value( $field ), $matches );
		return array_map( 'FrmShortcodeHelper::get_shortcode_attribute_array', $matches[1] );
	}

	/**
	 * @param array $saved_atts The attributes of a shortcode in the saved default value.
	 * @param array $atts       The attributes of the lookup being run.
	 *
	 * @return bool
	 */
	private static function is_same_lookup( $saved_atts, $atts ) {
		if ( isset( $saved_atts['entry_id'] ) && ! isset( $saved_atts['entry'] ) ) {
			$saved_atts['entry'] = $saved_atts['entry_id'];
		}

		foreach ( array( 'field_id', 'entry', 'user_id', 'ip' ) as $key ) {
			$saved = isset( $saved_atts[ $key ] ) ? (string) $saved_atts[ $key ] : '';
			$value = isset( $atts[ $key ] ) && is_scalar( $atts[ $key ] ) && false !== $atts[ $key ] ? (string) $atts[ $key ] : '';

			if ( $saved !== $value ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Get the field whose default value is being processed right now.
	 *
	 * @return false|stdClass
	 */
	private static function get_default_value_field() {
		$context = end( self::$default_value_stack );
		return $context ? $context['field'] : false;
	}

	/**
	 * Check if a field default value is being processed right now.
	 *
	 * @return bool
	 */
	public static function is_processing_default_value() {
		return (bool) self::get_default_value_field();
	}

	/**
	 * Remember that the ownership check hid the value a field default value looked up,
	 * so the admin can be warned on the next Formidable admin page. Only password and credit
	 * card targets are flagged, since a saved lookup of any other field is trusted.
	 *
	 * @param stdClass $target_field The field named in the shortcode's field_id.
	 *
	 * @return void
	 */
	public static function flag_blocked_default_value( $target_field ) {
		$host_field = self::get_default_value_field();

		if ( ! $host_field || ! self::is_private_field( $target_field ) ) {
			return;
		}

		$host_id = (int) $host_field->id;
		$flags   = self::get_blocked_lookups();
		$flag    = array(
			'form_id'         => (int) $host_field->form_id,
			'target_field_id' => (int) $target_field->id,
		);

		if ( isset( $flags[ $host_id ] ) ) {
			if ( ! empty( $flags[ $host_id ]['dismissed'] ) || $flags[ $host_id ] === $flag ) {
				return;
			}
		} elseif ( count( $flags ) >= self::MAX_BLOCKED_LOOKUPS ) {
			return;
		}

		$flags[ $host_id ] = $flag;
		update_option( self::BLOCKED_LOOKUPS_OPTION, $flags, false );
	}

	/**
	 * @return array<int, array{form_id: int, target_field_id: int, dismissed?: bool}>
	 */
	private static function get_blocked_lookups() {
		$flags = get_option( self::BLOCKED_LOOKUPS_OPTION, array() );
		return is_array( $flags ) ? $flags : array();
	}

	/**
	 * Add a warning to Formidable admin pages for each field default value that the
	 * ownership check keeps from showing.
	 *
	 * @param array $messages The messages shown at the top of the page.
	 *
	 * @return array
	 */
	public static function add_blocked_lookup_messages( $messages ) {
		// The warning has no good place above the form builder canvas, and every other Formidable page shows it.
		if ( ! current_user_can( 'frm_edit_forms' ) || FrmAppHelper::is_form_builder_page( false ) ) {
			return $messages;
		}

		$flags = self::get_blocked_lookups();

		if ( ! $flags ) {
			return $messages;
		}

		$changed = false;
		$shown   = 0;
		$hidden  = 0;

		foreach ( $flags as $host_id => $flag ) {
			$host_field   = FrmField::getOne( $host_id );
			$target_field = FrmField::getOne( $flag['target_field_id'] );

			if ( ! self::flag_still_applies( $host_field, $target_field ) ) {
				unset( $flags[ $host_id ] );
				$changed = true;
				continue;
			}

			if ( ! empty( $flag['dismissed'] ) ) {
				continue;
			}

			if ( $shown >= self::MAX_SHOWN_BLOCKED_LOOKUPS ) {
				++$hidden;
				continue;
			}

			// A blank line keeps each warning apart from the one above it.
			$messages[] = ( $shown ? '<br/>' : '' ) . self::get_blocked_lookup_message( $host_field );
			++$shown;
		}

		if ( $hidden ) {
			$messages[] = '<br/>' . sprintf(
				/* translators: %d: Number of fields */
				_n(
					'%d more field has a default value that visitors no longer see. Review or dismiss the warnings above to see it.',
					'%d more fields have default values that visitors no longer see. Review or dismiss the warnings above to see them.',
					$hidden,
					'formidable-pro'
				),
				$hidden
			);
		}

		if ( $changed ) {
			update_option( self::BLOCKED_LOOKUPS_OPTION, $flags, false );
		}

		return $messages;
	}

	/**
	 * A flag is cleared once either field is gone, the default value no longer looks up another
	 * entry, or the lookup is one saved in the form builder, which visitors can now see.
	 *
	 * @param false|stdClass $host_field   The field whose default value holds the shortcode.
	 * @param false|stdClass $target_field The field named in the shortcode's field_id.
	 *
	 * @return bool
	 */
	private static function flag_still_applies( $host_field, $target_field ) {
		if ( ! $host_field || ! $target_field || ! self::is_private_field( $target_field ) ) {
			return false;
		}

		foreach ( self::get_saved_lookups( $host_field ) as $atts ) {
			if ( empty( $atts['field_id'] ) ) {
				continue;
			}

			$saved_target = FrmField::getOne( $atts['field_id'] );

			if ( $saved_target && (int) $saved_target->id === (int) $target_field->id ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param stdClass $field The field whose default value holds the shortcode.
	 *
	 * @return string The default value and dynamic default value, as one string.
	 */
	private static function get_saved_default_value( $field ) {
		$values = array( $field->default_value, FrmField::get_option( $field, 'dyn_default_value' ) );

		foreach ( $values as $key => $value ) {
			if ( ! is_string( $value ) ) {
				$values[ $key ] = (string) wp_json_encode( $value );
			}
		}

		return implode( ' ', $values );
	}

	/**
	 * @param stdClass $host_field The field whose default value holds the shortcode.
	 *
	 * @return string
	 */
	private static function get_blocked_lookup_message( $host_field ) {
		$message = sprintf(
			/* translators: %1$s: Field name, %2$s: Form name */
			__( 'Visitors no longer see the default value of the "%1$s" field in the "%2$s" form.', 'formidable-pro' ),
			esc_html( $host_field->name ),
			esc_html( FrmForm::getName( $host_field->form_id ) )
		);

		$message .= ' ' . __( 'Its [frm-field-value] shortcode reads another entry, which only that entry\'s owner and users who can view entries can now see.', 'formidable-pro' );

		$docs_url = FrmAppHelper::admin_upgrade_link(
			array(
				'medium'  => 'field-value-ownership',
				'content' => 'blocked-lookup-notice',
			),
			'knowledgebase/frm_field_value_requires_ownership/'
		);

		$message .= ' ' . sprintf(
			/* translators: %1$s: HTML open link, %2$s: HTML close link */
			__( 'If the looked up data is meant to be public, %1$slearn how to allow it%2$s.', 'formidable-pro' ),
			'<a href="' . esc_url( $docs_url ) . '" target="_blank" rel="noopener">',
			'</a>'
		);

		$dismiss_url = wp_nonce_url(
			add_query_arg(
				array(
					'frm_action' => 'frm_dismiss_field_value_lookup',
					'field_id'   => (int) $host_field->id,
				)
			),
			'frm_dismiss_field_value_lookup'
		);

		$message .= '<br/><a href="' . esc_url( self::get_builder_field_url( $host_field ) ) . '">' . esc_html__( 'Review the field', 'formidable-pro' ) . '</a>';

		return $message . ( ' | <a href="' . esc_url( $dismiss_url ) . '">' . esc_html__( 'Dismiss', 'formidable' ) . '</a>' );
	}

	/**
	 * Get the form builder URL that opens the settings for a field.
	 *
	 * @param stdClass $field The field to open.
	 *
	 * @return string
	 */
	private static function get_builder_field_url( $field ) {
		return add_query_arg(
			array(
				'page'       => 'formidable',
				'frm_action' => 'edit',
				'id'         => (int) $field->form_id,
				'frm_field'  => (int) $field->id,
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Hide the warning for a field when the admin dismisses it. The flag is kept so the
	 * same blocked lookup does not bring the warning back.
	 *
	 * @return void
	 */
	public static function maybe_dismiss_blocked_lookup() {
		if ( 'frm_dismiss_field_value_lookup' !== FrmAppHelper::simple_get( 'frm_action', 'sanitize_title' ) ) {
			return;
		}

		if ( ! current_user_can( 'frm_edit_forms' ) || ! check_admin_referer( 'frm_dismiss_field_value_lookup' ) ) {
			return;
		}

		$host_id = FrmAppHelper::simple_get( 'field_id', 'absint' );
		$flags   = self::get_blocked_lookups();

		if ( isset( $flags[ $host_id ] ) ) {
			$flags[ $host_id ]['dismissed'] = true;
			update_option( self::BLOCKED_LOOKUPS_OPTION, $flags, false );
		}

		wp_safe_redirect( remove_query_arg( array( 'frm_action', 'field_id', '_wpnonce' ) ) );
		exit;
	}

	/**
	 * Remember an entry a logged-out visitor just submitted in a signed cookie.
	 * The ownership check then lets that browser read the entry, and no other.
	 *
	 * @param int|string $entry_id The new entry ID.
	 * @param int|string $form_id  The form the entry was submitted in.
	 *
	 * @return void
	 */
	public static function remember_guest_entry( $entry_id, $form_id ) {
		if ( get_current_user_id() || FrmProAppHelper::no_gdpr_cookies() || ! (bool) apply_filters( 'frm_create_cookies', true ) ) {
			return;
		}

		$form = FrmForm::getOne( $form_id );

		// A repeater row is read through its parent entry, so only the parent is remembered.
		if ( ! $form || $form->parent_form_id ) {
			return;
		}

		/**
		 * Filter how long a logged-out visitor can see the entries they submitted.
		 *
		 * @since 7.0.1
		 *
		 * @param int $expiration The number of seconds the cookie lasts. Default one hour.
		 */
		$expiration = (int) apply_filters( 'frm_guest_entries_cookie_expiration', HOUR_IN_SECONDS );
		$expires    = time() + $expiration;

		$entries = self::get_guest_entries();
		// Remembering another entry must not extend an existing entry's access.
		$entries[ (int) $entry_id ] = $entries[ (int) $entry_id ] ?? $expires;
		$entries                    = array_slice( $entries, - self::MAX_GUEST_ENTRIES, null, true );
		$expires                    = max( $entries );
		$items                      = array();

		foreach ( $entries as $id => $entry_expires ) {
			$items[] = $id . ':' . $entry_expires;
		}

		// Each entry's expiry is signed, so later submissions cannot renew older entries.
		$payload = implode( ',', $items ) . '|' . $expires;
		$value   = $payload . '|' . self::sign_guest_entry_ids( $payload );

		// Let shortcodes later in this same request see the entry too.
		$_COOKIE[ self::GUEST_ENTRIES_COOKIE ] = $value;

		if ( headers_sent() ) {
			return;
		}

		if ( PHP_VERSION_ID < 70300 ) {
			// Older PHP versions cannot set SameSite, so browsers fall back to their own default.
			setcookie( self::GUEST_ENTRIES_COOKIE, $value, $expires, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
			return;
		}

		setcookie(
			self::GUEST_ENTRIES_COOKIE,
			$value,
			array(
				'expires'  => $expires,
				'path'     => COOKIEPATH,
				'domain'   => COOKIE_DOMAIN,
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}

	/**
	 * Get the IDs of the entries this logged-out visitor submitted, when the cookie signature is valid and it has not expired.
	 *
	 * @return array<int>
	 */
	public static function get_guest_entry_ids() {
		return array_keys( self::get_guest_entries() );
	}

	/**
	 * Get unexpired guest entry IDs and their signed expiry timestamps.
	 *
	 * @since 7.0.1
	 *
	 * @return array<int, int>
	 */
	private static function get_guest_entries() {
		if ( empty( $_COOKIE[ self::GUEST_ENTRIES_COOKIE ] ) ) {
			return array();
		}

		$value = sanitize_text_field( wp_unslash( $_COOKIE[ self::GUEST_ENTRIES_COOKIE ] ) );
		$parts = explode( '|', $value );

		if ( 3 !== count( $parts ) || ! hash_equals( self::sign_guest_entry_ids( $parts[0] . '|' . $parts[1] ), $parts[2] ) ) {
			return array();
		}

		if ( (int) $parts[1] < time() ) {
			return array();
		}

		$entries = array();
		$now     = time();

		foreach ( explode( ',', $parts[0] ) as $item ) {
			$entry = explode( ':', $item );
			$id    = absint( $entry[0] );
			// Cookies issued before per-entry expiries keep their original signed expiry.
			$expires = isset( $entry[1] ) ? (int) $entry[1] : (int) $parts[1];

			if ( $id && $expires > $now ) {
				$entries[ $id ] = $expires;
			}
		}

		return $entries;
	}

	/**
	 * @param string $payload Comma separated entry ID and expiry pairs, a pipe, and the cookie expiry timestamp.
	 *
	 * @return string
	 */
	private static function sign_guest_entry_ids( $payload ) {
		return wp_hash( self::GUEST_ENTRIES_COOKIE . '|' . $payload );
	}
}
