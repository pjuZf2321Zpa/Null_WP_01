<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Registers the Formidable abilities that belong to Pro features.
 *
 * Formidable owns the abilities for the things it can do on its own. The rest
 * live here, because the feature does: writing an entry, everything about a
 * style beyond the single one Formidable supports, statistics, and applications.
 *
 * Everything is gated on FrmAbilitiesController, so the MCP setting is one
 * switch for the whole AI surface, and so nothing registers on a site where an
 * API add-on that predates the move still owns these names. A license that is
 * expired with the grace period over is the second gate, matching what the API
 * add-on applies to the abilities it owns.
 *
 * @since 7.0
 */
class FrmProAbilitiesController {

	/**
	 * @since 7.0
	 *
	 * @return void
	 */
	public static function load_hooks() {
		if ( ! self::formidable_supports_abilities() ) {
			// Running alongside a copy of Formidable from before the abilities
			// moved. It has no gate to check and no category to register into,
			// and the API add-on is still serving these names there.
			return;
		}

		add_filter( 'frm_ability_domains', 'FrmProAbilitiesController::add_domains' );
		add_action( 'wp_abilities_api_init', 'FrmProAbilitiesController::register_abilities' );
	}

	/**
	 * Check that Formidable is new enough to own the abilities surface.
	 *
	 * @since 7.0
	 *
	 * @return bool
	 */
	public static function formidable_supports_abilities() {
		return is_callable( 'FrmAbilitiesController::is_active' );
	}

	/**
	 * Claim the ability domains Pro owns.
	 *
	 * The API add-on reads this list to work out which domains still need it.
	 * Note that entries and styles are split: Formidable owns reading and
	 * deleting an entry while Pro owns creating and editing one, and Formidable
	 * owns reading and updating the single style while Pro owns the rest. So the
	 * domains here are the Pro halves, not the whole resource.
	 *
	 * @since 7.0
	 * @see filter hook frm_ability_domains
	 *
	 * @param array<string, string> $domains Domain names mapped to the controller class that registers them.
	 *
	 * @return array<string, string>
	 */
	public static function add_domains( $domains ) {
		$domains['entry-writes'] = 'FrmProAbilitiesEntriesController';
		$domains['styles-pro']   = 'FrmProAbilitiesStylesController';
		$domains['stats']        = 'FrmProAbilitiesStatsController';
		$domains['applications'] = 'FrmProAbilitiesApplicationsController';

		return $domains;
	}

	/**
	 * Register every ability Pro owns.
	 *
	 * @since 7.0
	 * @see action hook wp_abilities_api_init
	 *
	 * @return void
	 */
	public static function register_abilities() {
		if ( ! FrmAbilitiesController::is_active() || self::license_is_expired() ) {
			return;
		}

		FrmProAbilitiesEntriesController::register_abilities();
		FrmProAbilitiesStylesController::register_abilities();
		FrmProAbilitiesStatsController::register_abilities();
		FrmProAbilitiesApplicationsController::register_abilities();
	}

	/**
	 * Check if the license is expired with the grace period over.
	 *
	 * Matches the gate the API add-on applies to the abilities it still owns,
	 * so an expired license removes the same surface however the abilities are
	 * split on this site. See FrmAPIAppController::license_is_expired. The
	 * abilities Formidable owns are unaffected, since they need no license.
	 *
	 * @since 7.0
	 *
	 * @return bool
	 */
	private static function license_is_expired() {
		return FrmProAddonsController::is_expired_outside_grace_period();
	}
}
