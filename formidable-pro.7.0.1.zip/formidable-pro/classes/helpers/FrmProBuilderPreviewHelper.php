<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Registers simple Pro previews with Lite's optional browser renderer.
 *
 * Older Lite versions do not run these filters and keep rendering previews in PHP.
 *
 * @since 7.0.1
 */
class FrmProBuilderPreviewHelper {

	/**
	 * Register exact classes so add-on overrides keep their server previews.
	 *
	 * @since 7.0.1
	 *
	 * @param array $classes Supported classes keyed by field type.
	 *
	 * @return array
	 */
	public static function field_classes( $classes ) {
		$classes['date']    = array( 'FrmProFieldDate' );
		$classes['user_id'] = array( 'FrmProFieldUserID' );
		$classes['total']   = array( 'FrmProFieldTotal' );
		$classes['summary'] = array( 'FrmProFieldSummary' );
		$classes['virtual'] = array( 'FrmProFieldVirtual' );
		return $classes;
	}

	/**
	 * Keep date inputs with a prefix or suffix on the server.
	 *
	 * @since 7.0.1
	 *
	 * @param bool   $supported Whether the browser can draw the preview.
	 * @param object $field     Saved field.
	 *
	 * @return bool
	 */
	public static function supports( $supported, $field ) {
		if ( ! $supported || 'date' !== $field->type ) {
			return $supported;
		}

		foreach ( array( 'prepend', 'append', 'is_currency', 'format' ) as $option ) {
			if ( FrmField::get_option( $field, $option ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Add translated messages and the formatted total to the preview data.
	 *
	 * @since 7.0.1
	 *
	 * @param array        $data      Preview data.
	 * @param array        $field     Prepared field settings.
	 * @param FrmFieldType $field_obj Field type object.
	 *
	 * @return array
	 */
	public static function preview_data( $data, $field, $field_obj ) {
		$messages = array(
			'user_id' => __( 'User ID fields will not show in your form.', 'formidable' ),
			'virtual' => __( 'Virtual fields will not show in your form.', 'formidable-pro' ),
			'summary' => __( 'Summary: This field displays a summary of values entered on previous pages.', 'formidable-pro' ),
		);

		if ( isset( $messages[ $field['type'] ] ) ) {
			$data['message'] = $messages[ $field['type'] ];
		} elseif ( $field_obj instanceof FrmProFieldTotal ) {
			$data['message'] = $field_obj->get_builder_display_value();
		}

		if ( isset( $data['message'] ) ) {
			$data['message'] = html_entity_decode( esc_html( $data['message'] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}

		return $data;
	}
}
