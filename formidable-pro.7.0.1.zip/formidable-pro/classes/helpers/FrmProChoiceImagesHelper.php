<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * Reuses image choices for fields populated from another field.
 *
 * @since 7.0
 */
class FrmProChoiceImagesHelper {

	/**
	 * @since 7.0
	 *
	 * @param array|object $field The dynamic or lookup field.
	 *
	 * @return false|object
	 */
	public static function get_source_field( $field ) {
		$type = FrmField::get_field_type( $field );

		if ( ! in_array( $type, array( 'data', 'lookup' ), true ) || ! in_array( FrmField::get_option( $field, 'data_type' ), array( 'radio', 'checkbox' ), true ) ) {
			return false;
		}

		$source_id = FrmField::get_option( $field, 'data' === $type ? 'form_select' : 'get_values_field' );
		return is_numeric( $source_id ) ? FrmField::getOne( $source_id ) : false;
	}

	/**
	 * @since 7.0
	 *
	 * @param array|object $field The dynamic or lookup field.
	 *
	 * @return bool
	 */
	public static function has_images( $field ) {
		$source = self::get_source_field( $field );

		if ( ! $source ) {
			return false;
		}

		return 'file' === $source->type || ( in_array( $source->type, array( 'radio', 'checkbox', 'product' ), true ) && FrmProImages::has_image_options( $source ) );
	}

	/**
	 * Use image styling only when more than half of the source field's uploads are images.
	 *
	 * The count covers every submitted entry's first upload in the source field, rather than the linked
	 * field's filtered choices, so the builder, the form and shortcodes always agree. Non-image
	 * files in an image styled field still show their text label. Source attachment IDs are
	 * cached until entries change or the cache expires. The result also refreshes when posts change.
	 *
	 * @since 7.0
	 *
	 * @param array|object $field The linked choice field.
	 *
	 * @return bool
	 */
	public static function has_image_majority( $field ) {
		$source = self::get_source_field( $field );

		if ( ! $source || 'file' !== $source->type ) {
			return self::has_images( $field );
		}

		$result_key   = 'frm_image_majority_' . $source->id;
		$last_changed = wp_cache_get_last_changed( 'posts' );
		$result       = FrmDb::check_cache( $result_key, 'frm_item_meta' );

		if ( is_array( $result ) && $result['last_changed'] === $last_changed ) {
			return $result['majority'];
		}

		$cache_key = 'frm_image_majority_submitted_ids_' . $source->id;
		$ids       = FrmDb::check_cache( $cache_key, 'frm_item_meta' );

		if ( false === $ids ) {
			$ids = array();

			foreach ( FrmEntryMeta::get_entry_metas_for_field( $source->id ) as $value ) {
				FrmAppHelper::unserialize_or_decode( $value );
				$value = is_array( $value ) ? reset( $value ) : $value;
				$ids[] = is_numeric( $value ) ? (int) $value : 0;
			}

			FrmDb::set_cache( $cache_key, $ids, 'frm_item_meta' );
		}

		$ids = array_filter( $ids );
		_prime_post_caches( array_unique( $ids ), false, false );
		$images   = count( array_filter( $ids, 'wp_attachment_is_image' ) );
		$majority = $images > count( $ids ) / 2;
		FrmDb::set_cache( $result_key, compact( 'last_changed', 'majority' ), 'frm_item_meta' );

		return $majority;
	}

	/**
	 * Build image choices without changing the field's stored options.
	 *
	 * @since 7.0
	 *
	 * @param array  $field   The field and its current options.
	 * @param string $context Whether these are form options or saved display values.
	 *
	 * @return array
	 */
	public static function prepare_field( $field, $context = 'form' ) {
		$source = self::get_source_field( $field );

		if ( ! $source ) {
			return $field;
		}

		$is_data = 'data' === FrmField::get_field_type( $field );
		$metas   = array();

		if ( $is_data && ! empty( $field['options'] ) ) {
			$rows = FrmDb::get_results(
				'frm_item_metas',
				array(
					'field_id' => $source->id,
					'item_id'  => array_keys( $field['options'] ),
				),
				'item_id, meta_value'
			);

			foreach ( $rows as $row ) {
				$metas[ $row->item_id ] = $row->meta_value;
			}
		}

		$source_entries = self::get_source_entries( $field, $is_data );
		$image_options  = 'file' !== $source->type || self::has_image_majority( $field );
		$file_labels    = 'file' === $source->type ? self::get_file_labels( $field, $source, $metas, $is_data ) : array();

		foreach ( $field['options'] as $key => $value ) {
			$raw_value  = $is_data ? ( $metas[ $key ] ?? '' ) : $value;
			$save_label = ! $is_data && 'label' === FrmField::get_option( $field, 'lookup_saved_value' );
			$choice     = self::get_choice( $source, $raw_value, $save_label && 'display' === $context );
			$label_key  = $is_data ? $key : ( $choice['file'] ?? 0 );

			if ( isset( $file_labels[ $label_key ] ) && '' !== $file_labels[ $label_key ] ) {
				$choice['label'] = $file_labels[ $label_key ];
			}

			$saved_value     = $save_label ? $choice['label'] : $value;
			$choice['value'] = $is_data ? (string) $key : FrmProFieldLookup::filter_lookup_saved_value( $saved_value, $field );

			if ( ! $is_data ) {
				if ( ! $save_label && 'file' !== $source->type && 'value' === FrmField::get_option( $field, 'lookup_displayed_value' ) ) {
					$choice['label'] = $value;
				}

				$choice['label'] = FrmProFieldLookup::filter_lookup_displayed_value( $choice['label'], $field );
			}

			$choice['label'] = self::sanitize_choice_label( $choice['label'], $value, $key, $field, $source_entries, $is_data );

			$field['options'][ $key ] = $choice;
		}

		$field['type']            = $field['data_type'];
		$field['original_type']   = $field['type'];
		$field['use_key']         = false;
		$field['separate_value']  = 1;
		$field['image_options']   = $image_options ? 1 : 0;
		$image_size               = FrmField::get_option( $field, 'image_size' );
		$field['image_size']      = $image_size ? $image_size : FrmProImages::get_default_size();
		$field['hide_image_text'] = FrmField::get_option( $field, 'hide_image_text' );
		return $field;
	}

	/**
	 * @since 7.0
	 *
	 * @param array $field Field and its source entry IDs.
	 * @param bool  $is_data Whether the options are indexed by entry ID.
	 *
	 * @return array
	 */
	private static function get_source_entries( $field, $is_data ) {
		if ( ! $is_data || empty( $field['options'] ) ) {
			return array();
		}

		$entries = FrmDb::get_results( 'frm_items', array( 'id' => array_keys( $field['options'] ) ), 'id, user_id, updated_by' );
		return array_column( $entries, null, 'id' );
	}

	/**
	 * @since 7.0
	 *
	 * @param string $label Display label without the generated image markup.
	 * @param string $value Raw lookup source value.
	 * @param int|string $key Dynamic source entry ID or lookup option index.
	 * @param array $field Field and its source configuration.
	 * @param array $entries Source authors indexed by entry ID.
	 * @param bool $is_data Whether this is a Dynamic field.
	 *
	 * @return string
	 */
	private static function sanitize_choice_label( $label, $value, $key, $field, $entries, $is_data ) {
		if ( ! $is_data ) {
			return FrmProLookupFieldsController::sanitize_lookup_label( $label, $value, $field );
		}

		$source_entries = isset( $entries[ $key ] ) ? array( $entries[ $key ] ) : array();
		return FrmProFieldsHelper::sanitize_entry_html( $label, $source_entries );
	}

	/**
	 * Resolve uploaded file labels from the same entries as the source uploads.
	 *
	 * @since 7.0
	 *
	 * @param array  $field   The linked field settings.
	 * @param object $source  The upload source field.
	 * @param array  $metas   Upload values keyed by entry ID.
	 * @param bool   $is_data Whether choices store entry IDs.
	 *
	 * @return array
	 */
	private static function get_file_labels( $field, $source, $metas, $is_data ) {
		$label_field = FrmField::getOne( FrmField::get_option( $field, 'image_label_field' ) );

		if ( ! $label_field || (string) $label_field->form_id !== (string) $source->form_id || ! self::can_use_label_field( $label_field ) ) {
			return array();
		}

		if ( ! $is_data ) {
			$rows = FrmDb::get_results( 'frm_item_metas', array( 'field_id' => $source->id ), 'item_id, meta_value', array( 'order_by' => 'item_id ASC' ) );

			foreach ( $rows as $row ) {
				$metas[ $row->item_id ] = $row->meta_value;
			}
		}

		if ( ! $metas ) {
			return array();
		}

		$rows   = FrmDb::get_results(
			'frm_item_metas',
			array(
				'field_id' => $label_field->id,
				'item_id'  => array_keys( $metas ),
			),
			'item_id, meta_value',
			array( 'order_by' => 'item_id ASC' )
		);
		$labels = array();

		foreach ( $rows as $row ) {
			$text = FrmEntriesHelper::display_value(
				maybe_unserialize( $row->meta_value ),
				$label_field,
				array(
					'plain_text' => true,
					'show_image' => false,
					'entry_id'   => $row->item_id,
				)
			);
			$text = wp_strip_all_tags( $text );

			if ( $is_data ) {
				$labels[ $row->item_id ] = $text;
				continue;
			}

			$uploads = $metas[ $row->item_id ];
			FrmAppHelper::unserialize_or_decode( $uploads );

			foreach ( (array) $uploads as $upload ) {
				if ( is_numeric( $upload ) && ! isset( $labels[ $upload ] ) ) {
					$labels[ $upload ] = $text;
				}
			}
		}

		return $labels;
	}

	/**
	 * @since 7.0
	 *
	 * @param object $field The candidate label field.
	 *
	 * @return bool
	 */
	private static function can_use_label_field( $field ) {
		return ! FrmField::is_no_save_field( $field->type ) && ! in_array( $field->type, array( 'file', 'data', 'lookup' ), true );
	}

	/**
	 * @since 7.0
	 *
	 * @param object       $source       The source field.
	 * @param array|string $value        The source entry value.
	 * @param bool         $match_labels Whether the lookup saved labels instead of values.
	 *
	 * @return array
	 */
	private static function get_choice( $source, $value, $match_labels = false ) {
		FrmAppHelper::unserialize_or_decode( $value );
		$value = is_array( $value ) ? reset( $value ) : $value;

		if ( 'file' === $source->type ) {
			if ( $match_labels && ! is_numeric( $value ) ) {
				return array(
					'label' => $value,
					'image' => 0,
					'file'  => 0,
				);
			}

			return array(
				'label' => is_numeric( $value ) && (int) $value > 0 ? wp_basename( get_post_meta( (int) $value, '_wp_attached_file', true ) ) : '',
				'image' => is_numeric( $value ) && wp_attachment_is_image( (int) $value ) ? (int) $value : 0,
				'file'  => is_numeric( $value ) ? (int) $value : 0,
			);
		}

		foreach ( (array) $source->options as $choice ) {
			if ( ! is_array( $choice ) ) {
				continue;
			}

			$saved_value = ! $match_labels && FrmField::is_option_true( $source, 'separate_value' ) ? ( $choice['value'] ?? $choice['label'] ) : $choice['label'];

			if ( (string) $saved_value === (string) $value ) {
				return $choice;
			}
		}

		return array(
			'label' => $value,
			'image' => 0,
		);
	}

	/**
	 * Show the shared image size and label controls for linked choices.
	 *
	 * @since 7.0
	 *
	 * @param array $field The field being edited.
	 *
	 * @return void
	 */
	public static function show_settings( $field ) {
		if ( ! self::has_images( $field ) ) {
			return;
		}

		$source = self::get_source_field( $field );

		if ( $source && 'file' === $source->type ) {
			$label_fields = array_filter( FrmField::get_all_for_form( $source->form_id, '', 'exclude', 'exclude' ), array( self::class, 'can_use_label_field' ) );
			require FrmProAppHelper::plugin_path() . '/classes/views/frmpro-fields/back-end/image-label-field.php';
		}

		if ( ! self::has_image_majority( $field ) ) {
			return;
		}

		$field['type']                = $field['data_type'];
		$field['image_options']       = 1;
		$field['hide_display_format'] = true;
		$field['image_size']          = $field['image_size'] ?? FrmProImages::get_default_size();
		$columns                      = array(
			'small'  => __( 'Small', 'formidable' ),
			'medium' => __( 'Medium', 'formidable' ),
			'large'  => __( 'Large', 'formidable' ),
			'xlarge' => __( 'Extra Large', 'formidable-pro' ),
		);
		require FrmProAppHelper::plugin_path() . '/classes/views/frmpro-fields/back-end/image-options.php';
	}

	/**
	 * Display selected choices using the same shortcode rules as image choices.
	 *
	 * @since 7.0
	 *
	 * @param object       $field The dynamic or lookup field.
	 * @param array|string $value The selected values.
	 * @param array        $atts  Shortcode attributes.
	 *
	 * @return array|string
	 */
	public static function display( $field, $value, $atts ) {
		if ( '' === $value || array() === $value ) {
			return $value;
		}

		$source            = self::get_source_field( $field );
		$saves_labels      = 'lookup' === FrmField::get_field_type( $field ) && 'label' === FrmField::get_option( $field, 'lookup_saved_value' );
		$shows_saved_value = in_array( $atts['show'] ?? '', array( 'id', 'value' ), true );

		if ( $source && 'file' === $source->type && $saves_labels && $shows_saved_value ) {
			if ( ! is_array( $value ) || ! empty( $atts['return_array'] ) ) {
				return $value;
			}

			return implode( $atts['sep'] ?? ', ', $value );
		}

		$values                  = (array) $value;
		$render_field            = get_object_vars( $field ) + $field->field_options;
		$render_field['options'] = array();

		if ( 'label' === ( $atts['show'] ?? '' ) ) {
			$render_field['lookup_displayed_value'] = 'label';
		}

		foreach ( $values as $selected ) {
			$key                             = 'data' === $field->type ? $selected : count( $render_field['options'] );
			$render_field['options'][ $key ] = $selected;
		}

		$render_field                                   = self::prepare_field( $render_field, 'display' );
		$display_field                                  = clone $field;
		$display_field->type                            = $render_field['type'];
		$display_field->options                         = $render_field['options'];
		$display_field->field_options['separate_value'] = 1;
		$display_field->field_options['image_options']  = $render_field['image_options'];

		if ( FrmProImages::showing_images( $display_field, $atts ) ) {
			$display = FrmProImages::display( $display_field, $value, $atts );
		} else {
			$column  = $source && 'file' === $source->type && in_array( $atts['show'] ?? '', array( 'id', 'value' ), true ) ? 'file' : 'label';
			$labels  = array_column( $render_field['options'], $column );
			$display = is_array( $value ) ? $labels : (string) ( $labels[0] ?? '' );
		}

		if ( is_array( $display ) && empty( $atts['return_array'] ) ) {
			$display = implode( $atts['sep'] ?? ', ', $display );
		}

		return $display;
	}
}
