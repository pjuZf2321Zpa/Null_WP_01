<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

/**
 * The text box shown with an "Other" option in radio, checkbox and dropdown fields.
 * Lite hands this over to Pro with the frm_prepare_other_input and frm_include_other_input hooks.
 *
 * @since 7.0
 */
class FrmProOtherInputHelper {

	/**
	 * Check if Lite hands the "Other" text box over to Pro.
	 * Older versions of Lite show their own text box, without the Pro settings like the placeholder.
	 *
	 * @since 7.0
	 *
	 * @return bool
	 */
	public static function is_supported() {
		return is_callable( 'FrmFieldsHelper::other_input_is_handled' );
	}

	/**
	 * Set the name and value for the "Other" text box, and check the option when the text box has a value.
	 *
	 * @since 7.0
	 *
	 * @param array $prepared {
	 *
	 *     @type array       $other_args The name and value for the text box.
	 *     @type bool        $other_opt  True when this is an "Other" option.
	 *     @type bool|string $checked    The checked attribute for the option.
	 * }
	 *
	 * @param array $args Includes field, opt_key and field_name. Checkbox fields also include field_val.
	 *
	 * @return array
	 */
	public static function prepare_other_input( $prepared, $args ) {
		if ( ! FrmFieldsHelper::is_other_opt( $args['opt_key'] ) ) {
			return $prepared;
		}

		$prepared['other_opt']  = true;
		$prepared['other_args'] = array(
			'name'  => self::get_other_name( $args ),
			'value' => self::get_other_value( $args ),
		);

		if ( '' !== $prepared['other_args']['value'] ) {
			$prepared['checked'] = 'checked="checked" ';
		}

		// If 'other' is selected as one of the default values for a checkbox field, 'checked' attribute should be on.
		if ( ! $prepared['checked'] &&
			$args['field']['type'] === 'checkbox' &&
			is_array( $args['field']['value'] ) &&
			isset( $args['field_val'] ) &&
			in_array( $args['field_val'], $args['field']['value'], true )
		) {
			$prepared['checked'] = 'checked="checked" ';
		}

		return $prepared;
	}

	/**
	 * Show the text box for an "Other" option.
	 *
	 * @since 7.0
	 *
	 * @param array $args Includes field, opt_key, html_id, name, value, checked and read_only.
	 *
	 * @return void
	 */
	public static function include_other_input( $args ) {
		if ( ! $args['other_opt'] ) {
			return;
		}

		$classes = array( 'frm_other_input' );

		if ( ! $args['checked'] || trim( $args['checked'] ) === '' ) {
			// Hide the field if the other option is not selected
			$classes[] = 'frm_pos_none';
		}

		if ( $args['field']['type'] === 'select' && ! empty( $args['field']['multiple'] ) ) {
			$classes[] = 'frm_other_full';
		}

		$other_id = FrmFieldsHelper::get_other_field_html_id( $args['field']['type'], $args['html_id'], $args['opt_key'] );
		$label    = $args['opt_label'] ?? $args['field']['name'];

		$input_attrs = array(
			'type'  => 'text',
			'id'    => $other_id,
			'class' => implode( ' ', $classes ),
		);

		if ( $args['read_only'] ) {
			$input_attrs['readonly'] = 'readonly';
			$input_attrs['disabled'] = 'disabled';
		}

		$input_attrs['name']  = $args['name'];
		$input_attrs['value'] = $args['value'];

		$placeholder = self::get_placeholder( $args['field'], $args['opt_key'] );

		if ( '' !== $placeholder ) {
			$input_attrs['placeholder'] = $placeholder;
		}

		echo '<label for="' . esc_attr( $other_id ) . '" class="frm_screen_reader frm_hidden">' . esc_html( $label ) . '</label>';
		echo '<input';
		FrmAppHelper::array_to_html_params( $input_attrs, true );
		echo ' />';
	}

	/**
	 * Get the value that belongs in the "Other" text box.
	 *
	 * @since 7.0
	 *
	 * @param array $args Includes opt_key and field. Fields in a repeater also include parent and pointer.
	 *
	 * @return string
	 */
	public static function get_other_val( $args ) { // phpcs:ignore SlevomatCodingStandard.Complexity.Cognitive.ComplexityTooHigh
		$defaults  = array(
			'opt_key' => 0,
			'field'   => array(),
			'parent'  => false,
			'pointer' => false,
		);
		$args      = wp_parse_args( $args, $defaults );
		$opt_key   = $args['opt_key'];
		$field     = $args['field'];
		$parent    = $args['parent'];
		$pointer   = $args['pointer'];
		$other_val = '';

		// If option is an "other" option and there is a value set for this field,
		// Check if the value belongs in the current "Other" option text field
		if ( ! FrmFieldsHelper::is_other_opt( $opt_key ) || ! FrmField::is_option_true( $field, 'value' ) ) {
			return $other_val;
		}

		// Check posted vals before checking saved values
		// For fields inside repeating sections - note, don't check if $pointer is true because it will often be zero
		if ( $parent && isset( $_POST['item_meta'][ $parent ][ $pointer ]['other'][ $field['id'] ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( FrmField::is_field_with_multiple_values( $field ) ) {
				$other_val = isset( $_POST['item_meta'][ $parent ][ $pointer ]['other'][ $field['id'] ][ $opt_key ] ) ? sanitize_text_field( wp_unslash( $_POST['item_meta'][ $parent ][ $pointer ]['other'][ $field['id'] ][ $opt_key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, SlevomatCodingStandard.Files.LineLength.LineTooLong
			} else {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing
				$other_val = sanitize_text_field( wp_unslash( $_POST['item_meta'][ $parent ][ $pointer ]['other'][ $field['id'] ] ) );
			}

			return $other_val;
		}

		if ( isset( $field['id'] ) && isset( $_POST['item_meta']['other'][ $field['id'] ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			// For normal fields

			if ( FrmField::is_field_with_multiple_values( $field ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing, SlevomatCodingStandard.Files.LineLength.LineTooLong
				$other_val = isset( $_POST['item_meta']['other'][ $field['id'] ][ $opt_key ] ) ? sanitize_text_field( wp_unslash( $_POST['item_meta']['other'][ $field['id'] ][ $opt_key ] ) ) : '';
			} else {
				$other_val = sanitize_text_field( wp_unslash( $_POST['item_meta']['other'][ $field['id'] ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			}

			return $other_val;
		}//end if

		// For checkboxes
		if ( $field['type'] === 'checkbox' && is_array( $field['value'] ) ) {
			// Check if there is an "other" val in saved value and make sure the
			// "other" val is not equal to the Other checkbox option
			// phpcs:ignore Universal.Operators.StrictComparisons
			if ( isset( $field['value'][ $opt_key ] ) && $field['options'][ $opt_key ] != $field['value'][ $opt_key ] ) {
				$other_val = $field['value'][ $opt_key ];
			}
		} else {
			/**
			 * For radio buttons and dropdowns
			 * Check if saved value equals any of the options. If not, set it as the other value.
			 */
			foreach ( $field['options'] as $opt_val ) {
				$temp_val = is_array( $opt_val ) ? $opt_val['value'] : $opt_val;

				// Multi-select dropdowns - key is not preserved
				if ( is_array( $field['value'] ) ) {
					// phpcs:ignore WordPress.PHP.StrictInArray.MissingTrueStrict
					$o_key = array_search( $temp_val, $field['value'] );

					if ( isset( $field['value'][ $o_key ] ) ) {
						unset( $field['value'][ $o_key ], $o_key );
					}
				} elseif ( $temp_val == $field['value'] ) { // phpcs:ignore Universal.Operators.StrictComparisons
					// For radio and regular dropdowns
					return '';
				} else {
					$other_val = $field['value'];
				}
				unset( $opt_val, $temp_val );
			}

			// For multi-select dropdowns only
			if ( is_array( $field['value'] ) && $field['value'] ) {
				$other_val = reset( $field['value'] );
			}
		}//end if

		return false === $other_val ? '' : $other_val;
	}

	/**
	 * Get the name for the "Other" text box.
	 * Converts item_meta[field_id] => item_meta[other][field_id] and
	 * item_meta[parent][0][field_id] => item_meta[parent][0][other][field_id].
	 *
	 * @since 7.0
	 *
	 * @param array $args Includes field, opt_key and field_name.
	 *
	 * @return string
	 */
	private static function get_other_name( $args ) {
		$name = str_replace( '[]', '', $args['field_name'] );
		$name = preg_replace( '/\[' . $args['field']['id'] . '\]$/', '', $name );
		$name = $name . '[other][' . $args['field']['id'] . ']';

		if ( FrmField::is_field_with_multiple_values( $args['field'] ) ) {
			$name .= '[' . $args['opt_key'] . ']';
		}

		return $name;
	}

	/**
	 * Find the parent and pointer, and get the text for the "Other" text box.
	 *
	 * @since 7.0
	 *
	 * @param array $args Includes field, opt_key and field_name.
	 *
	 * @return string
	 */
	private static function get_other_value( $args ) {
		$parent  = '';
		$pointer = '';

		// Check for parent ID and pointer
		$temp_array = explode( '[', $args['field_name'] );

		// Count should only be greater than 3 if inside of a repeating section
		if ( count( $temp_array ) > 3 ) {
			$parent  = str_replace( ']', '', $temp_array[1] );
			$pointer = str_replace( ']', '', $temp_array[2] );
		}

		return self::get_other_val(
			array(
				'opt_key' => $args['opt_key'],
				'field'   => $args['field'],
				'parent'  => $parent,
				'pointer' => $pointer,
			)
		);
	}

	/**
	 * Get the saved placeholder for the text box of an "Other" option.
	 *
	 * @since 7.0
	 *
	 * @param array       $field   Field settings, including the other_placeholder option keyed by "Other" option key.
	 * @param bool|string $opt_key The "Other" option key, or false for a dropdown, which only has one "Other" option.
	 *
	 * @return string
	 */
	private static function get_placeholder( $field, $opt_key ) {
		if ( empty( $field['other_placeholder'] ) || ! is_array( $field['other_placeholder'] ) ) {
			return '';
		}

		if ( false === $opt_key && is_array( $field['options'] ?? null ) ) {
			foreach ( $field['options'] as $key => $option ) {
				if ( FrmFieldsHelper::is_other_opt( (string) $key ) ) {
					$opt_key = $key;
					break;
				}
			}
		}

		$placeholder = false === $opt_key ? '' : ( $field['other_placeholder'][ $opt_key ] ?? '' );

		return is_string( $placeholder ) ? $placeholder : '';
	}
}
