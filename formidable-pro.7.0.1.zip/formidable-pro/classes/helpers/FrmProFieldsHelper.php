<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmProFieldsHelper {

	/**
	 * Filter display HTML using the source entries' author and editor permissions.
	 *
	 * @since 7.0
	 *
	 * @param string $html Display HTML, separate from the saved value.
	 * @param array  $entries Source entry objects contributing to the display value.
	 *
	 * @return string
	 */
	public static function sanitize_entry_html( $html, $entries = array() ) {
		if ( ! $entries ) {
			$entries = array(
				(object) array(
					'user_id'    => 0,
					'updated_by' => 0,
				),
			);
		}

		// A text field applies the shared author policy without remapping option labels or values.
		$field_object = FrmFieldFactory::get_field_type( 'text' );

		foreach ( $entries as $entry ) {
			$html = $field_object->get_display_value( $html, array( 'entry' => $entry ) );
		}

		return FrmAppHelper::kses( $html, 'all' );
	}

	/**
	 * Keep a record of fields that pass self::hide_on_page checks.
	 * This way we can reference back later and possibly show the field in test mode.
	 *
	 * @since 6.23
	 *
	 * @var array
	 */
	private static $fields_hidden_on_page = array();

	/**
	 * Keep a record of choices entry count for each field.
	 *
	 * @since 6.28
	 *
	 * @var array
	 */
	private static $choices_entry_count = array();

	/**
	 * Memoize and re-use the edited entry when validating choices limits.
	 *
	 * @since 6.28
	 *
	 * @var array<stdClass> Indexed by entry id.
	 */
	private static $editing_entries = array();

	/**
	 * @param array|string    $value
	 * @param false|stdClass $field
	 * @param bool           $dynamic_default
	 * @param bool           $allow_array
	 * @param array          $args
	 * bool|null $args['replace_field_id_shortcodes'] default true but should be set to false for calculations as they process field id shortcodes dynamically.
	 * bool|null $args['is_calc'] only gets set when processing a calculation. set to true.
	 * bool|null $args['do_shortcode'] replaces shortcodes in $value. This is true by default when unset.
	 *
	 * @return mixed
	 */
	public static function get_default_value( $value, $field, $dynamic_default = true, $allow_array = false, $args = array() ) {
		$dynamic_value = self::get_dynamic_default( $field, $dynamic_default );

		if ( is_object( $field ) ) {
			$field_obj          = FrmFieldFactory::get_field_type( $field->type );
			$should_unserialize = self::should_unserialize_metas( $field_obj );
		} else {
			$should_unserialize = true;
		}

		$unserialized = $value;

		if ( $should_unserialize ) {
			FrmAppHelper::unserialize_or_decode( $unserialized );
		}

		if ( is_array( $unserialized ) ) {
			$field_obj = FrmFieldFactory::get_field_object( $field );

			if ( $field->type === 'time' ) {
				$field_obj->time_array_to_string( $value );
			} elseif ( FrmAppHelper::is_empty_value( $unserialized ) || array_filter( $unserialized ) === array() ) {
				$value = '';
			} elseif ( $field->type === 'address' && $dynamic_value ) {
				$value = $dynamic_value;
			} else {
				$filtered = array();

				foreach ( $unserialized as $k => $v ) {
					$filtered[ $k ] = self::get_default_value( $v, $field, $dynamic_default, false );
				}

				self::maybe_force_array( $filtered, $field, $allow_array );
				return $filtered;
			}
		}

		$prev_val = '';

		if ( $dynamic_value !== '' ) {
			$prev_val = $value;
			$value    = $dynamic_value;
		}

		$pass_args = array(
			'allow_array' => $allow_array,
			'field'       => $field,
			'prev_val'    => $prev_val,
		);

		$replace_field_id_shortcodes = ! isset( $args['replace_field_id_shortcodes'] ) || $args['replace_field_id_shortcodes'];
		$unreplaced_value            = $value;

		self::replace_non_standard_formidable_shortcodes( $pass_args, $value );

		if ( $replace_field_id_shortcodes ) {
			self::replace_field_id_shortcodes( $value, $pass_args );
		}

		if ( ! isset( $args['do_shortcode'] ) || $args['do_shortcode'] ) {
			FrmProFieldValueAccessController::start_default_value( $field, $unreplaced_value );
			self::do_shortcode( $value, $allow_array );
			FrmProFieldValueAccessController::end_default_value();
		}

		self::maybe_force_array( $value, $field, $allow_array );

		return $value;
	}

	/**
	 * @param FrmFieldType $field_object
	 *
	 * @return bool
	 */
	private static function should_unserialize_metas( $field_object ) {
		$value = $field_object->maybe_decode_value( 'a:0:{}' );
		// If the unserialized array data actually gets unserialized, return true.
		return 'a:0:{}' !== $value;
	}

	/**
	 * @since 3.0.06
	 *
	 * @param stdClass $field
	 * @param bool     $dynamic_default
	 *
	 * @return string
	 */
	private static function get_dynamic_default( $field, $dynamic_default ) {
		if ( ! $field || ! $dynamic_default ) {
            return '';
        }

        if ( FrmField::is_option_value_in_object( $field, 'dyn_default_value' ) ) {
			return $field->field_options['dyn_default_value'];
		}

        return '';
	}

	/**
	 * Replace Formidable shortcodes (that are not added with add_shortcode) in a string
	 *
	 * @since 2.0.24
	 *
	 * @param array       $args
	 * @param string|null $value
	 *
	 * @return void
	 */
	public static function replace_non_standard_formidable_shortcodes( $args, &$value ) {
		if ( is_null( $value ) || ! str_contains( $value, '[' ) ) {
			// Don't run checks if there are no shortcodes
			return;
		}

		$default_args = array(
			'allow_array' => false,
			'field'       => false,
			'prev_val'    => '',
		);
		$args         = wp_parse_args( $args, $default_args );
        $matches      = self::get_shortcodes_from_string( $value );

		if ( ! isset( $matches[0] ) ) {
			return;
		}

		$args['matches'] = $matches;

		foreach ( $matches[1] as $match_key => $shortcode ) {
			$args['shortcode'] = $shortcode;
			$args['match_key'] = $match_key;
			self::replace_shortcode_in_string( $value, $args );
		}
	}

	/**
	 * @since 2.0.8
	 *
	 * @return array
	 */
	private static function get_shortcode_to_functions() {
		return array(
			'email'             => array( 'FrmProAppHelper', 'get_current_user_value' ),
			'login'             => array( 'FrmProAppHelper', 'get_current_user_value' ),
			'username'          => array( 'FrmProAppHelper', 'get_current_user_value' ),
			'display_name'      => array( 'FrmProAppHelper', 'get_current_user_value' ),
			'first_name'        => array( 'FrmProAppHelper', 'get_current_user_value' ),
			'last_name'         => array( 'FrmProAppHelper', 'get_current_user_value' ),
			'user_role'         => array( 'FrmProAppHelper', 'get_current_user_value' ),
			'user_id'           => array( 'FrmProAppHelper', 'get_user_id' ),
			'post_id'           => array( 'FrmProAppHelper', 'get_current_post_value' ),
			'post_title'        => array( 'FrmProAppHelper', 'get_current_post_value' ),
			'post_author_email' => 'get_the_author_meta',
			'ip'                => array( 'FrmAppHelper', 'get_ip_address' ),
			'admin_email'       => array( 'FrmFieldsHelper', 'dynamic_default_values' ),
			'siteurl'           => array( 'FrmFieldsHelper', 'dynamic_default_values' ),
			'frmurl'            => array( 'FrmFieldsHelper', 'dynamic_default_values' ),
			'sitename'          => array( 'FrmFieldsHelper', 'dynamic_default_values' ),
		);
	}

	/**
	 * @return array
	 */
	private static function get_shortcode_function_parameters() {
		return array(
			'email'             => 'user_email',
			'login'             => 'user_login',
			'username'          => 'user_login',
			'display_name'      => 'display_name',
			'first_name'        => 'user_firstname',
			'last_name'         => 'user_lastname',
			'user_role'         => 'roles',
			'post_id'           => 'ID',
			'post_title'        => 'post_title',
			'post_author_email' => 'user_email',
			'admin_email'       => 'admin_email',
			'siteurl'           => 'siteurl',
			'frmurl'            => 'frmurl',
			'sitename'          => 'sitename',
		);
	}

	/**
	 * @since 2.0.8
	 *
	 * @param string $string
	 *
	 * @return array
	 */
	private static function get_shortcodes_from_string( $string ) {
		$match_shortcodes  = implode( '|', array_keys( self::get_shortcode_to_functions() ) );
		$match_shortcodes .= '|user_meta|post_meta|server|auto_id|date|time|age|date_calc|get|if get';
		preg_match_all( '/\[(' . $match_shortcodes . '|get-(.?))\b(.*?)(?:(\/))?\]/s', $string, $matches, PREG_PATTERN_ORDER );
		return $matches;
	}

	/**
	 * @since 2.0.8
	 *
	 * @param array|string $value
	 * @param array        $args {
	 *
	 *     @type stdClass $field
	 *     @type bool     $allow_array
	 *     @type string   $shortcode
	 *     @type int      $match_key
	 * }
	 *
	 * @return void
	 */
	private static function replace_shortcode_in_string( &$value, $args ) {
		if ( isset( self::get_shortcode_to_functions()[ $args['shortcode'] ] ) ) {
			$new_value = self::get_shortcode_value_from_function( $args['shortcode'] );
		} else {
			$new_value = self::get_other_shortcode_values( $args );
		}

		if ( $args['shortcode'] === 'if get' ) {
			$args['new_value'] = $new_value;
			self::do_conditional_get( $args, $value );
		} elseif ( is_array( $new_value ) ) {
			if ( 1 === count( $new_value ) && ! FrmField::is_field_with_multiple_values( $args['field'] ) ) {
				$new_value = reset( $new_value );
			}

			$value = $new_value;
		} else {
			if ( is_null( $new_value ) ) {
				$new_value = '';
			}

			$value = str_replace( $args['matches'][0][ $args['match_key'] ], $new_value, $value );
		}
	}

	/**
	 * @since 2.0.8
	 *
	 * @param string $shortcode
	 */
	private static function get_shortcode_value_from_function( $shortcode ) {
		$shortcode_atts = self::get_shortcode_function_parameters();
        return call_user_func( self::get_shortcode_to_functions()[ $shortcode ], $shortcode_atts[ $shortcode ] ?? '' );
	}

	/**
	 * @since 2.0.8
	 *
	 * @param array $args
	 */
	private static function get_other_shortcode_values( $args ) {
		$atts = FrmShortcodeHelper::get_shortcode_attribute_array( stripslashes( $args['matches'][3][ $args['match_key'] ] ) );

		if ( isset( $atts['return_array'] ) ) {
			$args['allow_array'] = $atts['return_array'];
		}

		$args['shortcode_atts'] = $atts;
		$new_value              = '';

		switch ( $args['shortcode'] ) {
			case 'user_meta':
				if ( isset( $atts['key'] ) ) {
					$new_value = FrmProAppHelper::get_current_user_value( $atts['key'], false );
				}
				break;

			case 'post_meta':
				if ( isset( $atts['key'] ) ) {
					$new_value = FrmProAppHelper::get_current_post_value( $atts['key'] );
				}
				break;

			case 'if get':
				$new_value = self::do_get_shortcode( $args );
				break;

			case 'get':
				$new_value = self::do_get_shortcode( $args );
				self::escape_shortcodes( $new_value );
				break;

			case 'auto_id':
				$new_value = self::do_auto_id_shortcode( $args );
				break;

			case 'server':
				if ( isset( $atts['param'] ) ) {
					$new_value = FrmAppHelper::get_server_value( $atts['param'] );
					// Headers like HTTP_USER_AGENT and HTTP_REFERER are sent by the visitor.
					self::escape_shortcodes( $new_value );
				}
				break;

			case 'date':
				$date      = $atts['offset'] ?? current_time( 'mysql' );
				$format    = $atts['format'] ?? '';
				$new_value = self::get_single_date( $date, $format );
				break;

			case 'time':
				$new_value = FrmProAppHelper::get_time( $atts );
				break;

			case 'age':
			case 'date_calc':
				$new_value = self::do_age_shortcode( $atts );
				break;

			default:
				$new_value = self::check_posted_item_meta( $args['matches'][0][ $args['match_key'] ], $args['shortcode'], $atts, $args['allow_array'] );
		}

		return $new_value;
	}

	/**
	 * @since 3.0.06
	 *
	 * @param array        $args
	 * @param array|string $value
	 *
	 * @return void
	 */
	private static function do_conditional_get( $args, &$value ) {
		$shortcode_atts              = FrmShortcodeHelper::get_shortcode_attribute_array( stripslashes( $args['matches'][3][ $args['match_key'] ] ) );
		$shortcode_atts['short_key'] = $args['matches'][0][ $args['match_key'] ];
		FrmProContent::check_conditional_shortcode( $value, $args['new_value'], $shortcode_atts, 'get', 'if' );
	}

	/**
	 * Encode the opening brackets in a value from the request, so a visitor cannot add a
	 * shortcode that runs when the text around it is processed.
	 *
	 * @since 7.0.1
	 *
	 * @param mixed $value A string, or an array of strings.
	 *
	 * @return void
	 */
	public static function escape_shortcodes( &$value ) {
		if ( is_array( $value ) ) {
			array_walk_recursive( $value, array( self::class, 'escape_shortcodes' ) );
			return;
		}

		if ( is_string( $value ) ) {
			$value = str_replace( '[', '&#91;', $value );
		}
	}

	/**
	 * @since 2.0.8
	 *
	 * @param array $args
	 *
	 * @return string
	 */
	private static function do_get_shortcode( $args ) {
		// Reverse compatibility for [get-param] shortcode.
		if ( str_starts_with( $args['matches'][0][ $args['match_key'] ], '[get-' ) ) {
			$val   = $args['matches'][0][ $args['match_key'] ];
			$param = str_replace( '[get-', '', $val );

			if ( preg_match( '/\[/s', $param ) ) {
				$val .= ']';
			} else {
				$param = trim( $param, ']' ); // only if is doesn't create an imbalanced []
			}

			return FrmFieldsHelper::process_get_shortcode( compact( 'param' ), $args['allow_array'] );
		}

		$atts = $args['shortcode_atts'];

		// If the user forgot to include the required param option exit early.
		if ( ! isset( $atts['param'] ) ) {
			_doing_it_wrong( __METHOD__, '[get] shortcode is missing required param option.', '6.15' );
			return '';
		}

		if ( self::adding_a_form_row() ) {
			return self::get_get_shortcode_result_from_state( $atts['param'] );
		}

		// During form submissions, $_GET data is not available.
		// Fall back to the form state value that was captured during the initial page load.
		// Only do this when a form state was actually submitted with the request. Otherwise
		// listing contexts (e.g. a View filtering by [get param=x]) would incorrectly reuse a
		// stale in-memory state value on a regular page load where the param is simply not set.
		if ( self::form_state_was_submitted() && ! isset( $_GET[ $atts['param'] ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$state_value = self::get_get_shortcode_result_from_state( $atts['param'] );

			if ( '' !== $state_value ) {
				return $state_value;
			}
		}

		$atts['prev_val'] = $args['prev_val'];
		$new_value        = FrmFieldsHelper::dynamic_default_values( 'get', $atts, $args['allow_array'] );
		FrmProFormState::set_get_param( $atts['param'], $new_value );

		return $new_value;
	}

	/**
	 * @return bool
	 */
	private static function adding_a_form_row() {
		return 'frm_add_form_row' === FrmAppHelper::get_post_param( 'action', '', 'sanitize_key' );
	}

	/**
	 * Check if a form state was submitted with the current request.
	 *
	 * The frm_state hidden field is only present when a Formidable form is submitted, so this
	 * distinguishes a form submission (where the page-load $_GET values are carried in the state)
	 * from a regular page load such as a View listing page where the param may simply be unset.
	 *
	 * @since 6.33
	 *
	 * @return bool
	 */
	private static function form_state_was_submitted() {
		return '' !== FrmAppHelper::get_post_param( 'frm_state', '', 'sanitize_text_field' );
	}

	/**
	 * @param string $param
	 *
	 * @return string
	 */
	private static function get_get_shortcode_result_from_state( $param ) {
		$get_from_request = FrmProFormState::get_from_request( 'get', array() );

		if ( $get_from_request && isset( $get_from_request[ $param ] ) ) {
            return $get_from_request[ $param ];
		}

        return '';
	}

	/**
	 * @since 2.0.8
	 *
	 * @param array $args
	 *
	 * @return int
	 */
	private static function do_auto_id_shortcode( $args ) {
		$last_entry = FrmProEntryMetaHelper::get_max( $args['field'] );
		$start      = isset( $args['shortcode_atts']['start'] ) ? absint( $args['shortcode_atts']['start'] ) : false;

		if ( ! $last_entry ) {
			return false === $start ? 1 : $start;
		}

  $step = isset( $args['shortcode_atts']['step'] ) ? absint( $args['shortcode_atts']['step'] ) : 1;

		return max( $start, absint( $last_entry ) + $step );
	}

	/**
	 * @param string $string
	 *
	 * @return bool
	 */
	private static function is_date( $string ) {
		return strtotime( $string ) !== false;
	}

	/**
	 * @param array $args
	 *
	 * @return string
	 */
	private static function do_age_shortcode( $args ) {
		if ( ! isset( $args['id'] ) ) {
			return '';
		}

		$id      = esc_attr( $args['id'] );
		$format  = ! empty( $args['format'] ) && 'days' === $args['format'] ? 'days' : 'years';
		$compare = self::prepare_compare_arg_for_calc( $args );

		if ( self::compare_is_a_field_id_or_key( $args ) ) {
			$return = self::maybe_build_date_diff_calc( $id, $compare, $format, $args );
		}

		if ( empty( $return ) ) {
			$return = "calculateDateDifference( [$id], {$compare}, '{$format}' )";
		}

		return ! empty( $args['abs'] ) ? "Math.abs( {$return} )" : $return;
	}

	/**
	 * Get the string to use in JS for the second "b" parameter in calculateDateDifference.
	 *
	 * @since 6.8.3
	 *
	 * @param array $args
	 *
	 * @return string
	 */
	private static function prepare_compare_arg_for_calc( $args ) {
		if ( ! isset( $args['compare'] ) ) {
			// Use today's date as the compare value if there is no param.
			return "'" . FrmProAppHelper::get_date( 'm/d/Y' ) . "'";
		}

		if ( is_numeric( $args['compare'] ) ) {
			// Wrap field ID as a shortcode.
			return '[' . absint( $args['compare'] ) . ']';
		}

		if ( self::is_date( $args['compare'] ) ) {
			// Wrap date as a string.
			return "'" . esc_attr( $args['compare'] ) . "'";
		}

		// Wrap field key as a shortcode.
		return '[' . esc_js( $args['compare'] ) . ']';
	}

	/**
	 * @since 6.8.3
	 *
	 * @param string $id      The id param used in an [age] or [date_calc] shortcode.
	 * @param string $compare The modified compare param. This has been modified so it is a shortcode or a date string.
	 *                        For the 2nd parameter of calculateDateDifference.
	 * @param string $format  The format. Either 'days' or 'years'.
	 * @param array  $args    All options defined in the [date] or [date_calc] shortcode.
	 *
	 * @return string
	 */
	private static function maybe_build_date_diff_calc( $id, $compare, $format, $args ) {
		$calc = '';

		/**
		 * Filter the date calculation.
		 *
		 * @since 6.8.3
		 *
		 * @param string $calc
		 * @param array  $filter_args
		 */
		$filtered_calc = apply_filters( 'frm_build_date_diff_calc', $calc, compact( 'id', 'compare', 'format', 'args' ) );

		if ( is_string( $filtered_calc ) ) {
			$calc = $filtered_calc;
		} else {
			_doing_it_wrong( __METHOD__, 'Only strings should be returned when using the frm_build_date_diff_calc filter.', '6.8.3' );
		}

		return $calc;
	}

	/**
	 * Check if a compare param in a [age] or [date_calc] shortcode is a field ID or field key (rather than a date value).
	 *
	 * @since 6.8.3
	 *
	 * @param array $args
	 *
	 * @return bool
	 */
	private static function compare_is_a_field_id_or_key( $args ) {
		if ( ! isset( $args['compare'] ) ) {
			return false;
		}
		$compare = $args['compare'];
		return is_numeric( $compare ) || ! self::is_date( $compare );
	}

	/**
	 * Check for shortcodes in default values but prevent the form shortcode from filtering
	 *
	 * @since 2.0
	 *
	 * @param array|string $value
	 * @param bool         $return_array
	 *
	 * @return void
	 */
	private static function do_shortcode( &$value, $return_array = false ) {
		$is_final_val_set = self::do_array_shortcode( $value, $return_array );

		if ( $is_final_val_set ) {
			return;
		}

		global $frm_vars;
		$frm_vars['skip_shortcode'] = true;

		if ( is_array( $value ) ) {
			foreach ( $value as $k => $v ) {
				self::maybe_do_shortcode( $value[ $k ] );
				unset( $k, $v );
			}
		} else {
			self::maybe_do_shortcode( $value );
		}

		$frm_vars['skip_shortcode'] = false;
	}

	/**
	 * If shortcode must return an array, bypass the WP do_shortcode function
	 * This is set up to return arrays for frm-field-value shortcode in multiple select fields
	 *
	 * @param $value - string which will be switched to array, pass by reference
	 * @param $return_array - boolean keeps track of whether or not an array should be returned
	 *
	 * @return bool to tell calling function (do_shortcode) if final value is set
	 */
	private static function do_array_shortcode( &$value, $return_array ) {
		if ( ! $return_array || is_array( $value ) ) {
			return false;
		}

		// If frm-field-value shortcode and it should return an array, bypass the WP do_shortcode function
		if ( str_contains( $value, '[frm-field-value ' ) ) {
			preg_match_all( '/\[(frm-field-value)\b(.*?)(?:(\/))?\]/s', $value, $matches, PREG_PATTERN_ORDER );

			foreach ( $matches[0] as $short_key => $tag ) {
				$atts                 = FrmShortcodeHelper::get_shortcode_attribute_array( $matches[2][ $short_key ] );
				$atts['return_array'] = $return_array;

				$value = FrmProEntriesController::get_field_value_shortcode( $atts );
			}

			return true;
		}

		return false;
	}

	/**
	 * Don't waste time processing if we know there isn't a shortcode
	 *
	 * @since 3.0
	 *
	 * @param array|string $value
	 */
	private static function maybe_do_shortcode( &$value ) {
		if ( self::has_shortcode( $value ) && ! self::is_nested_shortcode( $value ) ) {
			$value = do_shortcode( $value );
		}
	}

	/**
	 * @since 3.0
	 *
	 * @param string|null $value
	 *
	 * @return bool
	 */
	private static function has_shortcode( $value ) {
		return is_string( $value ) && str_contains( $value, '[' ) && str_contains( $value, ']' );
	}

	/**
	 * Default values change from page to page. A nested shortcode may include
	 * a field value that has not been replaced yet. ie [frm-stats id=[25]]
	 * If this is the case, wait to process any shortcodes.
	 *
	 * @since 3.0
	 *
	 * @param string $value
	 *
	 * @return bool
	 */
	private static function is_nested_shortcode( $value ) {
		preg_match_all( '/\[([A-Za-z0-9\-\_]+)\b(.*?)(?:(\/))?\]/s', $value, $matches, PREG_PATTERN_ORDER );

		if ( empty( $matches[0] ) ) {
			return false;
		}

		$has_nested = false;

		foreach ( $matches[0] as $match ) {
			$has_nested = substr_count( $match, '[' ) > 1;

			if ( $has_nested ) {
				break;
			}
		}

		return $has_nested;
	}

	/**
	 * @param array|string $value
	 * @param array        $args
	 *
	 * @return void
	 */
	private static function replace_field_id_shortcodes( &$value, $args ) {
		if ( ! $value ) {
			return;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $k => $v ) {
				self::replace_each_field_id_shortcode( $v, $args );
				$value[ $k ] = $v;
				unset( $k, $v );
			}
		} else {
			self::replace_each_field_id_shortcode( $value, $args );
		}
	}

	/**
	 * @param array|string $value
	 * @param array        $args
	 *
	 * @return void
	 */
	public static function replace_each_field_id_shortcode( &$value, $args ) {
		// If a shortcode is nested, only get the inner shortcode.
		$pattern = "/\[([^\[]([\w\d]*)\b(.*?)(?:(\/))?)\]/s";
		preg_match_all( $pattern, $value, $matches, PREG_PATTERN_ORDER );

		if ( empty( $matches[0] ) ) {
			return;
		}

		$return_array = $args['allow_array'];

		foreach ( $matches[0] as $match_key => $val ) {
			$conditional = preg_match( '/^\[if/s', $matches[0][ $match_key ] ) ? true : false;

			if ( $conditional ) {
				// The following code doesn't actually replace [if] shortcodes properly.
				// [if] shortcodes are handled separately, in self::maybe_replace_if_shortcodes,
				// so skip them here to prevent conflicts.
				continue;
			}

			$foreach   = preg_match( '/^\[foreach/s', $matches[0][ $match_key ] ) ? true : false;
			$shortcode = $matches[1][ $match_key ];
			$atts      = FrmShortcodeHelper::get_shortcode_attribute_array( $matches[3][ $match_key ] );
			$shortcode = FrmShortcodeHelper::get_shortcode_tag( $matches, $match_key, compact( 'conditional', 'foreach' ) );

			if ( is_numeric( $shortcode ) ) {
				$field_id = $shortcode;
			} else {
				$field_id = FrmField::get_id_by_key( $shortcode );

				if ( ! $field_id ) {
					continue;
				}
			}

			if ( ! isset( $_REQUEST ) || ! isset( $_REQUEST['item_meta'] ) ) {
				if ( is_object( $args['field'] ) && (int) $field_id === (int) $args['field']->id ) {
					// If the form hasn't been posted, set self-defaults to blank.
					$value = str_replace( $val, $atts['default'] ?? '', $value );
				}
				continue;
			}

			/**
			 * Filters the value of a field shortcode so other add-ons or custom code can
			 * modify it before it is used.
			 *
			 * @since 6.26
			 *
			 * @param false|string $value    The value.
			 * @param int          $field_id The field ID.
			 * @param array        $atts     Shortcode atts.
			 */
			$new_value = apply_filters( 'frm_posted_field_shortcode_value', false, $field_id, $atts );

			if ( false === $new_value ) {
				$new_value = FrmAppHelper::get_param( 'item_meta[' . $field_id . ']', false, 'post', 'wp_kses_post' );
			}

			if ( false === $new_value && isset( $atts['default'] ) ) {
				$new_value     = $atts['default'];
				$using_default = true;
			}

			if ( is_array( $new_value ) && ! $return_array ) {
				$new_value = self::get_string_value_from_array( $new_value, $field_id, $atts );
			}

			if ( is_array( $new_value ) ) {
				$value = $new_value;
			} else {
				if ( empty( $using_default ) ) {
					// Escape any shortcodes in the value input to prevent them from processing
					$new_value = str_replace( '[', '&#91;', $new_value );
				}

				$new_value = self::maybe_get_option_label_for_shortcode_value( $new_value, $field_id, $atts );
                $value     = str_replace( $val, $new_value, $value );
			}
		}
	}

	/**
	 * Maybe get option label for shortcode value.
	 *
	 * @param string $value    Option value.
	 * @param int    $field_id Field ID.
	 * @param array  $atts     Shortcode atts.
	 *
	 * @return string
	 */
	private static function maybe_get_option_label_for_shortcode_value( $value, $field_id, $atts = array() ) {
		if ( empty( $atts['show'] ) ) {
			return $value;
		}

		$field = FrmField::getOne( $field_id );

		if ( ! $field ) {
			return $value;
		}

		return FrmProEntriesController::get_option_label_for_saved_value( $value, $field, $atts );
	}

	/**
	 * Change an array value to a string.
	 * For a name field, this uses the get_display_value function.
	 * By default, fields will be imploded as CSV.
	 *
	 * @since 5.2.02
	 * @since 6.8.1 This function was renamed from maybe_get_combo_field_value.
	 *
	 * @param array $value    The value.
	 * @param int   $field_id Field ID.
	 * @param array $atts     Shortcode attributes.
	 *
	 * @return string
	 */
	private static function get_string_value_from_array( $value, $field_id, $atts ) {
		$field_obj = FrmFieldFactory::get_field_object( $field_id );

		if ( $field_obj ) {
			$field      = $field_obj->get_field();
			$field_type = $field->type;

			switch ( $field_type ) {
				case 'name':
				case 'address':
					return $field_obj->get_display_value( $value, $atts );

				case 'checkbox':
				case 'select':
					if ( ! empty( $atts['show'] ) && 'label' === $atts['show'] && ! empty( $field->options ) && is_array( $field->options ) ) {
						$value = self::swap_option_values_for_labels( $value, $field->options );
					}
					break;
			}
		}

		return implode( ', ', $value );
	}

	/**
	 * @since 6.8.1
	 *
	 * @param array $values
	 * @param array $field_options
	 *
	 * @return array
	 */
	private static function swap_option_values_for_labels( $values, $field_options ) {
		$new_values = array();

		foreach ( $values as $value ) {
			$match = false;

			foreach ( $field_options as $option ) {
				if ( ! is_array( $option ) || empty( $option['value'] ) || $option['value'] !== $value ) {
					continue;
				}

				$new_values[] = $option['label'];
				$match        = true;
				break;
			}

			if ( ! $match ) {
				$new_values[] = $value;
			}
		}

		return $new_values;
	}

	/**
	 * If value is "current_user", returns current user's id
	 *
	 * @param $value
	 *
	 * @return int
	 */
	private static function get_user_id_if_value_is_current_user( $value ) {
		if ( 'current_user' === $value ) {
			$value = get_current_user_id();

			if ( 0 === $value ) {
				$value = -1; // Avoid 0 so logged out users do not match a "current user" check when there is no user id associated with the entry.
			}
		}

		return $value;
	}

	/**
	 * If this default value should be an array, we will make sure it is
	 *
	 * @since 2.0
	 *
	 * @param array|string   $value
	 * @param false|stdClass $field
	 * @param bool           $return_array
	 *
	 * @return void
	 */
	private static function maybe_force_array( &$value, $field, $return_array ) {
		if ( ! $return_array || is_array( $value ) || ! str_contains( $value, ',' ) || ! is_object( $field ) ) {
			// This is already in the correct format
			return;
		}

		if ( $field->type === 'address' ) {
			$field_obj = FrmFieldFactory::get_field_object( $field );
			$value     = $field_obj->address_string_to_array( $value );
		} elseif ( FrmField::is_field_with_multiple_values( $field ) && ( in_array( $field->type, array( 'data', 'lookup' ), true ) || ! in_array( $value, (array) $field->options ) ) ) {
			// If checkbox, multi-select dropdown, or checkbox data from entries field and default value has a comma

			// If the default value does not match any options OR if data from entries field (never would have commas in values), explode to array
			$value = explode( ',', $value );

			if ( is_array( $value ) ) {
				// Spaces prevent the value from being matched
				$value = array_map( 'trim', $value );
			}
		}
	}

	/**
	 * @param array $atts
	 */
	private static function check_posted_item_meta( $val, $shortcode, $atts, $return_array ) {
		if ( ! is_numeric( $shortcode ) || ! isset( $_REQUEST ) || ! isset( $_REQUEST['item_meta'] ) ) {
			return $val;
		}

		// Check for posted item_meta
		$new_value = FrmAppHelper::get_param( 'item_meta[' . $shortcode . ']', false, 'post' );

		if ( ! $new_value && isset( $atts['default'] ) ) {
			$new_value = $atts['default'];
		}

		if ( is_array( $new_value ) && ! $return_array ) {
			return implode( ', ', $new_value );
		}

		return $new_value;
	}

	/**
	 * Get the input name and id
	 * Called when loading a dynamic DFE field
	 *
	 * @since 2.0
	 *
	 * @param string $field_name
	 * @param string $html_id
	 * @param array  $field
	 * @param string $hidden_field_id
	 *
	 * @return void
	 */
	public static function get_html_id_from_container( &$field_name, &$html_id, $field, $hidden_field_id ) {
		$id_parts = explode( '-', str_replace( '_container', '', $hidden_field_id ) );
		$plus     = count( $id_parts ) === 3 ? '-' . end( $id_parts ) : ''; // This is in a sub field
		$html_id  = FrmFieldsHelper::get_html_id( $field, $plus );

		if ( $plus !== '' ) {
			// Get the name for the sub field
			$field_name .= '[' . $id_parts[1] . '][' . end( $id_parts ) . ']';
		}

		$field_name .= '[' . $field['id'] . ']';
	}

	/**
	 * @param array    $values
	 * @param stdClass $field
	 *
	 * @return array
	 */
	public static function setup_new_vars( $values, $field ) {
		$values['entry_id'] = 0;

		self::fill_field_options( $field, $values, false );
		self::prepare_field_array( $field, $values );

		if ( $values['type'] === 'user_id' || $values['original_type'] === 'user_id' ) {
			$show_admin_field = FrmAppHelper::is_admin() && current_user_can( 'frm_edit_entries' ) && ! FrmAppHelper::is_admin_page( 'formidable' );

			if ( $show_admin_field && self::field_on_current_page( $field ) ) {
				$values['value'] = $_POST && isset( $_POST['item_meta'][ $field->id ] ) ? $_POST['item_meta'][ $field->id ] : get_current_user_id();
			}
		}

		if ( empty( $field->default_value ) && isset( $values['calc'] ) ) {
			$dynamic_default = false;
			$allow_array     = false;
			$args            = array(
				'replace_field_id_shortcodes' => false,
				'is_calc'                     => true,
			);
			$values['calc']  = (string) apply_filters( 'frm_get_default_value', $values['calc'], $field, $dynamic_default, $allow_array, $args );
		}

		self::maybe_use_default_value( $values );
		self::maybe_restore_default_on_skipped_page( $values );
		self::maybe_show_hidden_field( $field, $values, true );
		self::prepare_post_fields( $field, $values );
		self::add_field_javascript( $values );

		return $values;
	}

	/**
	 * @param array      $values
	 * @param stdClass   $field
	 * @param int|string $entry_id
	 */
	public static function setup_edit_vars( $values, $field, $entry_id = 0 ) {
		$values['entry_id'] = $entry_id;

		self::fill_field_options( $field, $values );
		self::prepare_field_array( $field, $values );

		if ( $values['type'] === 'tag' && empty( $values['value'] ) ) {
            self::tags_to_list( $values, $entry_id );
        }

		self::maybe_show_hidden_field( $field, $values );
		self::prepare_post_fields( $field, $values );

		FrmProNestedFormsController::format_saved_values_for_hidden_nested_forms( $values );

		self::add_field_javascript( $values );

		return $values;
	}

	/**
	 * Populate the options for a field when loaded (front and back-end).
	 *
	 * @since 2.0.08
	 *
	 * @param object $field
	 * @param array  $values, pass by reference
	 * @param bool   $allow_blank
	 *
	 * @return void
	 */
	private static function fill_field_options( $field, &$values, $allow_blank = true ) {
		$defaults            = self::get_default_field_opts();
		$defaults['use_key'] = false;

		$never_empty = array( 'hide_field_cond' );

		foreach ( $defaults as $opt => $default ) {
			if ( isset( $values[ $opt ] ) && ! $values[ $opt ] && in_array( $opt, $never_empty ) ) {
				// Use the default value if empty.
				unset( $values[ $opt ] );
			}

			if ( isset( $values[ $opt ] ) ) {
				continue;
			}

			$use_value = isset( $field->field_options[ $opt ] ) && ( $field->field_options[ $opt ] != '' || $allow_blank );

			if ( $use_value && in_array( $opt, $never_empty ) && empty( $field->field_options[ $opt ] ) ) {
				$use_value = false;
			}

			$values[ $opt ] = $use_value ? $field->field_options[ $opt ] : $default;
		}

		// If the field includes an unused calculation, clear it out.
		if ( isset( $values['use_calc'] ) && ! empty( $values['calc'] ) && empty( $values['use_calc'] ) ) {
			$values['calc'] = '';
		}
	}

	/**
	 * Used to setup fields for new and edit
	 *
	 * @since 2.2.10
	 *
	 * @param stdClass $field
	 * @param array    $values
	 *
	 * @return void
	 */
	private static function prepare_field_array( $field, &$values ) {
		if ( ! isset( $values['parent_form_id'] ) ) {
			$values['parent_form_id'] = $field->form_id;
		}

		$values['hide_field']      = (array) $values['hide_field'];
		$values['hide_field_cond'] = (array) $values['hide_field_cond'];
		$values['hide_opt']        = (array) $values['hide_opt'];

		if ( self::is_builder_page() ) {
			return;
		}

		$values['name']        = self::get_default_value( $values['name'], $field, false );
		$values['description'] = self::get_default_value(
			$values['description'],
			$field,
			false,
			false,
			array(
				// Shortcodes already run for HTML fields when after_replace_html_shortcodes is called.
				// So skip processing it here as well.
				'do_shortcode' => 'html' !== $field->type,
			)
		);
		self::prepare_field_types( $field, $values );
	}

	/**
	 * Ajax calls on the builder page also need to be excluded
	 *
	 * @since 3.0.06
	 *
	 * @return bool
	 */
	private static function is_builder_page() {
		global $frm_vars;

		if ( ! empty( $frm_vars['is_admin'] ) ) {
			return true;
		}

		return FrmAppHelper::is_admin_page( 'formidable' );
	}

	/**
	 * @param array $values
	 */
	private static function prepare_field_types( $field, &$values ) {
		if ( $values['original_type'] === 'date' ) {
			$values['value'] = FrmProAppHelper::maybe_convert_from_db_date( $values['value'] );
		} elseif ( ! empty( $values['options'] ) ) {
			self::prepare_to_show_field_options( $field, $values );
		}
	}

	/**
	 * The default value has already been checked for shortcodes.
	 * Use it for the field value when needed
	 *
	 * @since 3.0
	 *
	 * @param array $values
	 */
	private static function maybe_use_default_value( &$values ) {
		$use_default = isset( $values['original_default'] ) && $values['original_default'] != $values['default_value'] && $values['original_default'] === $values['value'];

		if ( $use_default ) {
			$values['value'] = $values['default_value'];
		}
	}

	/**
	 * Keep the default value of a field that sits on a conditionally skipped page.
	 *
	 * Validation clears the value of a conditionally hidden field and writes that empty value back to
	 * $_POST. On a multi page form the field is then re-rendered as a hidden input carrying the empty
	 * value forward, and because a posted value takes precedence over the default, the default is lost
	 * for the rest of the submission. It never comes back, even once the page is shown again.
	 * See https://github.com/Strategy11/formidable-pro/issues/5470.
	 *
	 * The field is not on the current page, so this value is never shown to anyone. It only keeps the
	 * default available for the moment the page is shown again. Validation still clears the value on
	 * submit, so a field whose page is still skipped is saved without a value.
	 *
	 * @since 7.0
	 *
	 * @param array $values Field values array, passed by reference.
	 *
	 * @return void
	 */
	private static function maybe_restore_default_on_skipped_page( &$values ) {
		if ( ! $_POST ) {
			// Nothing has been posted, so the default value is already in place.
			return;
		}

		if ( FrmAppHelper::is_empty_value( $values['default_value'] ) || FrmAppHelper::is_not_empty_value( $values['value'] ) ) {
			return;
		}

		if ( ! self::is_on_skipped_page( $values ) ) {
			return;
		}

		$values['value'] = $values['default_value'];
	}

	/**
	 * @param stdClass $field
	 * @param array    $values
	 *
	 * @return void
	 */
	private static function prepare_post_fields( $field, &$values ) {
		if ( $values['post_field'] === 'post_category' ) {
			$values['use_key'] = true;
			$values['options'] = self::get_category_options( $values );

			if ( $values['type'] === 'data' && in_array( $values['data_type'], array( 'select', 'dropdown' ), true ) && ( ! $values['multiple'] || $values['autocom'] ) ) {
				// Add a blank option.
				$values['options'] = array( '' => '' ) + (array) $values['options'];
			}
		} elseif ( $values['post_field'] === 'post_status' && ! in_array( $field->type, array( 'hidden', 'text' ), true ) ) {
			$values['use_key'] = true;
			$values['options'] = self::get_status_options( $field, $values['options'] );
		}
	}

	/**
	 * @param stdClass $field
	 * @param array    $values
	 *
	 * @return void
	 */
	private static function prepare_to_show_field_options( $field, &$values ) {
		foreach ( $values['options'] as $val_key => $val_opt ) {
			self::maybe_remove_separate_value( $field, $val_opt );

			if ( is_array( $val_opt ) ) {
				foreach ( $val_opt as $opt_key => $opt ) {
					$values['options'][ $val_key ][ $opt_key ] = self::get_default_value( $opt, $field, false );
					unset( $opt_key, $opt );
				}
			} else {
				$values['options'][ $val_key ] = self::get_default_value( $val_opt, $field, false );
			}
			unset( $val_key, $val_opt );
		}
	}

	/**
	 * If a field doesn't have separate values, simplify the options array
	 * to include only the key and displayed value.
	 * Since v2.03, the field options always include separate values.
	 * This causes trouble with custom code reverse compatibility.
	 *
	 * @since 2.03.05
	 *
	 * @param stdClass     $field
	 * @param array|string $opt
	 */
	private static function maybe_remove_separate_value( $field, &$opt ) {
		// If we don't check for product, we lose the 'price' key of the product options array
		if ( FrmField::is_field_type( $field, 'product' ) || ! is_array( $opt ) || ! isset( $opt['label'] ) || FrmProImages::has_image_options( $field ) ) {
			return;
		}

		$no_separate_values = FrmField::is_option_empty( $field, 'separate_value' );

		if ( $no_separate_values ) {
			$opt = $opt['label'];
		}
	}

	/**
	 * @param stdClass $field
	 * @param array    $values
	 * @param bool     $is_new True if creating a new entry. False if editing an existing entry.
	 *
	 * @return void
	 */
	private static function maybe_show_hidden_field( $field, &$values, $is_new = false ) {
		if ( $values['type'] !== 'hidden' ) {
			return;
		}

		$admin_edit = FrmAppHelper::is_admin_page( 'formidable-entries' ) && current_user_can( 'frm_create_entries' );

		if ( ! $admin_edit || ! self::field_on_current_page( $field ) ) {
			return;
		}

		$values['type']        = 'text';
		$values['custom_html'] = FrmFieldsHelper::get_default_html( 'text' );

		// If creating a new entry, make the input readonly.
		if ( $is_new ) {
			$values['custom_html'] = str_replace( '[input]', '[input readonly=1]', $values['custom_html'] );
		}
	}

	/**
	 * Add field-specific JavaScript to global $frm_vars
	 *
	 * @since 2.01.0
	 *
	 * @param array $values
	 *
	 * @return void
	 */
	public static function add_field_javascript( $values ) {
		self::setup_conditional_fields( $values );
		FrmProLookupFieldsController::setup_lookup_field_js( $values );
	}

	/**
	 * @param array      $values
	 * @param int|string $entry_id
	 *
	 * @return void
	 */
	public static function tags_to_list( &$values, $entry_id ) {
		$post_id = FrmDb::get_var( 'frm_items', array( 'id' => $entry_id ), 'post_id' );

		if ( ! $post_id ) {
			return;
		}

		$tags = get_the_terms( $post_id, $values['taxonomy'] );

		if ( ! $tags ) {
			$values['value'] = '';
			return;
		}

		$names = array();

		foreach ( $tags as $tag ) {
			$names[] = $tag->name;
		}

		$values['value'] = implode( ', ', $names );
	}

	/**
	 * @param array $settings
	 * @param array $atts
	 *
	 * @return array
	 */
	public static function add_default_field_settings( $settings, $atts ) {
		$add_settings = self::get_default_field_opts();
		FrmProLookupFieldsController::add_autopopulate_value_field_options( $atts, $atts['field'], $add_settings );
		return array_merge( $add_settings, $settings );
	}

	/**
	 * Fill the settings for each field
	 *
	 * @return array
	 */
	public static function get_default_field_opts() {
		$frm_settings = FrmAppHelper::get_settings();

		return array(
			'align'                     => '',
			'form_select'               => '',
			'enable_conditional_logic'  => '1',
			'show_hide'                 => 'show',
			'any_all'                   => 'any',
			'hide_field'                => array(),
			'hide_field_cond'           => array( '==' ),
			'hide_opt'                  => array(),
			'post_field'                => '',
			'custom_field'              => '',
			'taxonomy'                  => 'category',
			'exclude_cat'               => 0,
			'read_only'                 => 0,
			'range_field'               => 0,
			'linked_date_field'         => 0,
			'autocomplete'              => '',
			'admin_only'                => '',
			'unique'                    => 0,
			'unique_msg'                => $frm_settings->unique_msg,
			'calc'                      => '',
			'calc_dec'                  => '',
			'calc_type'                 => '',
			'is_currency'               => 0,
			'custom_currency'           => 0,
			'use_global_currency'       => 1,
			'custom_thousand_separator' => ',',
			'custom_decimal_separator'  => '.',
			'custom_decimals'           => 2,
			'custom_symbol_left'        => '',
			'custom_symbol_right'       => '',
			'dyn_default_value'         => '',
			'multiple'                  => 0,
			'autocom'                   => 0,
			'conf_field'                => '',
			'conf_label'                => 1,
			'conf_label_text'           => __( 'Confirm', 'formidable' ) . ' [field_name]',
			'conf_input'                => '',
			'conf_desc'                 => '',
			'conf_msg'                  => __( 'The entered values do not match', 'formidable' ),
			'choice_limit_msg'          => __( 'All choices have reached their entry limit', 'formidable-pro' ),
			'other'                     => 0,
			'in_section'                => 0,
			'prepend'                   => '',
			'append'                    => '',
			'auto_grow'                 => 0,
			'max_limit'                 => 0,
			'max_limit_type'            => 'char',
			'min_size'                  => '',
		);
	}

	/**
	 * Get the options for a field before display.
	 * This determines which options to show in the field settings.
	 *
	 * @since 3.0
	 *
	 * @param bool[] $display
	 *
	 * @return void
	 */
	public static function fill_default_field_display( &$display ) {
		$defaults = array(
			'logic'         => true,
			'autopopulate'  => false,
			'default_value' => false,
			'calc'          => false,
			'visibility'    => true,
			'conf_field'    => false,
		);
		$display  = array_merge( $defaults, $display );
	}

	/**
	 * Initialize the field array when a field is loaded independent of the rest of the form
	 *
	 * @param object $field_object
	 * @param array  $args
	 *
	 * @return array
	 */
	public static function initialize_array_field( $field_object, $args = array() ) {
		$field_values = array( 'id', 'required', 'name', 'description', 'form_id', 'options', 'field_key', 'type' );
		$field        = array( 'value' => '' );

		foreach ( $field_values as $field_value ) {
			$field[ $field_value ] = $field_object->{$field_value};
		}

		$field['original_type']  = $field['type'];
		$field['type']           = apply_filters( 'frm_field_type', $field['type'], $field_object, '' );
		$field['size']           = isset( $field_object->field_options['size'] ) && $field_object->field_options['size'] != '' ? $field_object->field_options['size'] : '';
		$field['blank']          = $field_object->field_options['blank'] ?? '';
		$field['default_value']  = $args['default_value'] ?? '';
		$field['parent_form_id'] = $field_object->form_id;

		if ( isset( $args['field_id'] ) ) {
			// this might not be needed. Is field_id ever different from $field['id']?
			$field['id'] = $args['field_id'];
		}

		return $field;
	}

	/**
	 * Set up the $frm_vars['rules'] array
	 *
	 * @param array $field
	 *
	 * @return void
	 */
	public static function setup_conditional_fields( $field ) {
		// TODO: prevent this from being called at all on the form builder page
		if ( FrmAppHelper::is_admin_page( 'formidable' ) ) {
			return;
		}

		global $frm_vars;

		if ( false === self::are_logic_rules_needed_for_this_field( $field ) ) {
			return;
		}

		self::maybe_initialize_global_rules_array();

		$logic_rules = self::get_logic_rules_for_field( $field );

		foreach ( $field['hide_field'] as $i => $logic_field_id ) {
			if ( ! self::maybe_initialize_logic_field_rules_by_id( $logic_field_id, $field ) ) {
				continue;
			}

			$add_field = true;

			self::add_condition_to_logic_rules( $field, $i, $logic_rules );

			list( $base_logic_field_id, ) = FrmProConditionalLogicController::get_logic_field_id_and_sub_key( $logic_field_id );
			self::add_to_logic_field_dependents( $base_logic_field_id, $field['id'] );
		}
		unset( $i, $logic_field_id );

		if ( empty( $add_field ) ) {
			return;
		}

		// Add current field's logic rules to global rules array
		$frm_vars['rules'][ $field['id'] ] = $logic_rules;

		self::set_logic_rule_status_to_complete( $field['id'] );
		self::maybe_add_script_for_confirmation_field( $field, $logic_rules );
		self::add_field_to_global_dependent_ids( $field, $logic_rules['fieldType'] );
	}

	/**
	 * Check if global conditional logic rules are needed for a field
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 *
	 * @return bool
	 */
	private static function are_logic_rules_needed_for_this_field( $field ) {
		global $frm_vars;

		if ( empty( $field['hide_field'] ) || ( empty( $field['hide_opt'] ) && empty( $field['form_select'] ) ) ) {
			// Field doesn't have conditional logic on it.
			return false;
		}

		if ( 'complete' === ( $frm_vars['rules'][ $field['id'] ]['status'] ?? null ) ) {
			// Field has already been checked.
			return false;
		}

		if ( FrmAppHelper::doing_ajax() && true !== ( $frm_vars['footer_loaded'] ?? null ) ) {
			// Don't load rules again when adding a row in a repeating section or turning the page in a "Submit with ajax" form.
			return false;
		}

		return true;
	}

	/**
	 * Initialize the $frm_vars rules array if it isn't already initialized
	 *
	 * @since 2.01.0
	 */
	private static function maybe_initialize_global_rules_array() {
		global $frm_vars;

		if ( empty( $frm_vars['rules'] ) ) {
			$frm_vars['rules'] = array();
		}
	}

	/**
	 * Get the logic rules for the current field
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 *
	 * @return array
	 */
	private static function get_logic_rules_for_field( $field ) {
		global $frm_vars;

		if ( ! isset( $frm_vars['rules'][ $field['id'] ] ) ) {
			return self::initialize_logic_rules_for_field_array( $field, $field['parent_form_id'] );
		}

		return $frm_vars['rules'][ $field['id'] ];
	}

	/**
	 * Initialize the logic rules for a field
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 * @param int $form_id
	 *
	 * @return array
	 */
	private static function initialize_logic_rules_for_field_array( $field, $form_id ) {
		if ( $field['type'] === 'submit' ) {
			return self::initialize_logic_rules_for_submit( $field, $form_id );
		}

		$original_type = self::get_original_field_type( $field );

		return array(
			'fieldId'       => $field['id'],
			'fieldKey'      => $field['field_key'],
			'fieldType'     => $original_type,
			'inputType'     => self::get_the_input_type_for_logic_rules( $field, $original_type ),
			'isMultiSelect' => FrmField::is_multiple_select( $field ),
			'formId'        => $form_id,
			'inSection'     => $field['in_section'] ?? '0',
			'inEmbedForm'   => $field['in_embed_form'] ?? '0',
			'isRepeating'   => $form_id != $field['form_id'],
			'dependents'    => array(),
			'showHide'      => $field['show_hide'] ?? 'show',
			'anyAll'        => $field['any_all'] ?? 'any',
			'conditions'    => array(),
		);
	}

	/**
	 * Initialize the logic rules for the submit button
	 *
	 * @param array $submit_field
	 * @param int $form_id
	 *
	 * @return array
	 */
	private static function initialize_logic_rules_for_submit( $submit_field, $form_id ) {
		$show_hide = 'show';

		if ( isset( $submit_field['show_hide'] ) && ( $submit_field['show_hide'] === 'hide' || $submit_field['show_hide'] === 'disable' ) ) {
			$show_hide = 'hide';
		}

		$hide_disable = 'hide';

		if ( isset( $submit_field['show_hide'] ) && ( $submit_field['show_hide'] === 'enable' || $submit_field['show_hide'] === 'disable' ) ) {
			$hide_disable = 'disable';
		}

		$form_key = FrmForm::get_key_by_id( $form_id );

		return array(
			'fieldId'       => 'submit_' . $form_id,
			'fieldKey'      => 'submit_' . $form_id,
			'fieldType'     => 'submit',
			'inputType'     => 'submit',
			'isMultiSelect' => false,
			'formId'        => $form_id,
			'formKey'       => $form_key,
			'inSection'     => false,
			'inEmbedForm'   => false,
			'isRepeating'   => false,
			'dependents'    => array(),
			'showHide'      => $show_hide,
			'hideDisable'   => $hide_disable,
			'anyAll'        => $submit_field['any_all'] ?? 'any',
			'conditions'    => array(),
		);
	}

	/**
	 * Get the original field type
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 *
	 * @return string
	 */
	private static function get_original_field_type( $field ) {
		return $field['original_type'] ?? $field['type'];
	}

	/**
	 * Get the input type from a field
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 * @param string $field_type
	 *
	 * @return string
	 */
	private static function get_the_input_type_for_logic_rules( $field, $field_type ) {
		if ( in_array( $field_type, array( 'data', 'lookup', 'product' ), true ) ) {
			$cond_type = $field['data_type'];

			if ( $cond_type === 'single' || $cond_type === 'user_def' ) {
				$cond_type = 'text';
			}
		} elseif ( $field_type === 'scale' || $field_type === 'star' ) {
			$cond_type = 'radio';
		} else {
			$cond_type = $field_type;
		}

		return apply_filters( 'frm_logic_' . $field_type . '_input_type', $cond_type );
	}

	/**
	 * Set the logic rule status to complete
	 *
	 * @since 2.01.0
	 *
	 * @param int $field_id
	 */
	private static function set_logic_rule_status_to_complete( $field_id ) {
		global $frm_vars;
		$frm_vars['rules'][ $field_id ]['status'] = 'complete';
	}

	/**
	 * Get the field object for a logic field
	 *
	 * @since 2.01.0
	 *
	 * @param int|string $logic_field_id
	 *
	 * @return false|object
	 */
	private static function get_field_from_conditional_logic( $logic_field_id ) {
		return is_numeric( $logic_field_id ) ? FrmField::getOne( $logic_field_id ) : false;
	}

	/**
	 * Make sure a logic field has rules, and report whether the field can be used for logic.
	 *
	 * A field is looked up once per condition row that targets it, but the rules for that field
	 * only ever get built the first time. Every later row hits the isset check in
	 * maybe_initialize_logic_field_rules and does nothing with the object it just loaded.
	 * Those repeat loads are not free even when the object cache is warm, because
	 * FrmField::getOne unserializes field_options and unslashes the whole row every call,
	 * so a form with a lot of conditional logic pays for hundreds of discarded lookups.
	 * Check the rules array first and only load the field when the rules are actually missing.
	 *
	 * @since 6.34
	 *
	 * @param int|string $logic_field_id  ID of the field the condition is watching.
	 * @param array      $dependent_field The field the conditional logic belongs to.
	 *
	 * @return bool False when the logic field no longer exists.
	 */
	private static function maybe_initialize_logic_field_rules_by_id( $logic_field_id, $dependent_field ) {
		global $frm_vars;

		list( $base_field_id, ) = FrmProConditionalLogicController::get_logic_field_id_and_sub_key( $logic_field_id );

		if ( ! is_numeric( $base_field_id ) ) {
			return false;
		}

		if ( isset( $frm_vars['rules'][ $base_field_id ] ) ) {
			return true;
		}

		$logic_field = self::get_field_from_conditional_logic( $base_field_id );

		if ( ! $logic_field ) {
			return false;
		}

		self::maybe_initialize_logic_field_rules( $logic_field, $dependent_field );

		return true;
	}

	/**
	 * Add a row of conditional logic to the logic_rules array
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 * @param int $i
	 * @param array $logic_rules
	 */
	private static function add_condition_to_logic_rules( $field, $i, &$logic_rules ) {
		if ( ! isset( $field['hide_opt'][ $i ] ) ) {
			return;
		}

		if ( ! isset( $field['hide_field_cond'][ $i ] ) ) {
			$field['hide_field_cond'][ $i ] = '==';
		}

		$logic_rules['conditions'][] = array(
			'fieldId'  => $field['hide_field'][ $i ],
			'operator' => $field['hide_field_cond'][ $i ],
			'value'    => self::prepare_logic_setting( $field['hide_opt'][ $i ], $field ),
		);
	}

	/**
	 * Check logic for smart values or 'current_user'.
	 *
	 * @since 4.02
	 *
	 * @param string       $value
	 * @param array|object $field
	 */
	private static function prepare_logic_setting( $value, $field ) {
		$value = self::get_default_value( $value, $field, false );
		return self::get_user_id_if_value_is_current_user( $value );
	}

	/**
	 * Add a logic field to the frm_vars rules array
	 *
	 * @since 2.01.0
	 *
	 * @param object $logic_field
	 * @param array $dependent_field
	 */
	private static function maybe_initialize_logic_field_rules( $logic_field, $dependent_field ) {
		global $frm_vars;

		if ( isset( $frm_vars['rules'][ $logic_field->id ] ) ) {
			return;
		}

		if ( self::is_logic_field_in_embedded_form_with_dependent_field( $logic_field, $dependent_field ) ) {
			$logic_field->in_embed_form = $dependent_field['in_embed_form'];
		}
		$frm_vars['rules'][ $logic_field->id ] = self::initialize_logic_rules_for_fields_object( $logic_field, $dependent_field['parent_form_id'] );
	}

	/**
	 * Check if a dependent field is in an embedded form and if logic field is also in that embedded form
	 *
	 * @since 2.02.06
	 *
	 * @param object $logic_field
	 * @param array $dependent_field
	 *
	 * @return bool
	 */
	private static function is_logic_field_in_embedded_form_with_dependent_field( $logic_field, $dependent_field ) {
		return FrmField::is_option_true_in_array( $dependent_field, 'in_embed_form' ) && $logic_field->form_id == $dependent_field['form_id'];
	}

	/**
	 * Initialize the logic rules for a field object
	 *
	 * @since 2.01.0
	 *
	 * @param object $field
	 * @param int $form_id
	 *
	 * @return array
	 */
	private static function initialize_logic_rules_for_fields_object( $field, $form_id ) {
		$field_array = self::convert_field_object_to_flat_array( $field );
		return self::initialize_logic_rules_for_field_array( $field_array, $form_id );
	}

	/**
	 * @param object $field
	 *
	 * @return array Field array.
	 */
	public static function convert_field_object_to_flat_array( $field ) {
		return FrmFieldsHelper::convert_field_object_to_flat_array( $field );
	}

	/**
	 * Add dependent field to logic field's dependents
	 *
	 * A field with several conditions watching the same logic field used to be added once per
	 * condition row, so the front end re-evaluated that field once per duplicate every time the
	 * logic field changed. Keep the list unique, since hideOrShowFieldById only needs it once.
	 *
	 * @since 2.01.0
	 *
	 * @param int $logic_field_id
	 * @param int $dep_field_id
	 */
	private static function add_to_logic_field_dependents( $logic_field_id, $dep_field_id ) {
		global $frm_vars;

		$dependents = $frm_vars['rules'][ $logic_field_id ]['dependents'];

		foreach ( $dependents as $dependent ) {
			if ( (string) $dependent === (string) $dep_field_id ) {
				return;
			}
		}

		$frm_vars['rules'][ $logic_field_id ]['dependents'][] = $dep_field_id;
	}

	/**
	 * Add rules for a confirmation field
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 * @param array $logic_rules
	 *
	 * @return void
	 */
	private static function maybe_add_script_for_confirmation_field( $field, $logic_rules ) {
		global $frm_vars;

		// TODO: maybe move confirmation field inside of field div
		if ( FrmField::is_option_empty( $field, 'conf_field' ) ) {
        	return;
        }

        // Add the rules for confirmation field
        $conf_field_rules                            = $logic_rules;
        $conf_field_rules['fieldId']                 = 'conf_' . $logic_rules['fieldId'];
        $conf_field_rules['fieldKey']                = 'conf_' . $logic_rules['fieldKey'];
        $frm_vars['rules'][ 'conf_' . $field['id'] ] = $conf_field_rules;

        // Add to all logic field dependents
        self::add_conf_field_to_logic_field_dependents( $conf_field_rules );
	}

	/**
	 * Add confirmation field as a dependent for all of its logic fields
	 *
	 * @since 2.01.0
	 *
	 * @param array $conf_field_rules
	 */
	private static function add_conf_field_to_logic_field_dependents( $conf_field_rules ) {
		global $frm_vars;

		foreach ( $conf_field_rules['conditions'] as $condition ) {
			self::add_to_logic_field_dependents( $condition['fieldId'], $conf_field_rules['fieldId'] );
		}
	}

	/**
	 * Add dependent field to the dep_logic_fields or dep_dynamic_fields array
	 *
	 * @since 2.01.0
	 *
	 * @param array $field
	 * @param string $original_field_type
	 *
	 * @return void
	 */
	private static function add_field_to_global_dependent_ids( $field, $original_field_type ) {
		global $frm_vars;

		if ( $original_field_type === 'data' ) {
			// Add to dep_dynamic_fields
			if ( ! isset( $frm_vars['dep_dynamic_fields'] ) ) {
				$frm_vars['dep_dynamic_fields'] = array();
			}
			$frm_vars['dep_dynamic_fields'][] = $field['id'];

            return;
		}

        // Add to dep_logic_fields
        if ( ! isset( $frm_vars['dep_logic_fields'] ) ) {
            $frm_vars['dep_logic_fields'] = array();
        }
        $frm_vars['dep_logic_fields'][] = $field['id'];

        if ( FrmField::is_option_true_in_array( $field, 'conf_field' ) ) {
            $frm_vars['dep_logic_fields'][] = 'conf_' . $field['id'];
        }
    }

	/**
	 * @param array|object $field
	 */
	public static function get_category_options( $field ) {
		// TODO: Dynamic fields get categories here - maybe combine with FrmProPost::get_category_dropdown()?
		if ( is_object( $field ) ) {
			$field = (array) $field;
			$field = array_merge( $field, $field['field_options'] );
		}

		$post_type = FrmProFormsHelper::post_type( $field['form_id'] );

		if ( ! isset( $field['exclude_cat'] ) ) {
			$field['exclude_cat'] = 0;
		}

		$exclude = is_array( $field['exclude_cat'] ) ? implode( ',', $field['exclude_cat'] ) : $field['exclude_cat'];
		$exclude = apply_filters( 'frm_exclude_cats', $exclude, $field );

		$args = array(
			'orderby'    => 'name',
			'order'      => 'ASC',
			'hide_empty' => false,
			'exclude'    => $exclude,
			'type'       => $post_type,
		);

		if ( $field['type'] !== 'data' ) {
			$args['parent'] = '0';
		}

		$args['taxonomy'] = FrmProAppHelper::get_custom_taxonomy( $post_type, $field );

		if ( ! $args['taxonomy'] ) {
			return;
		}

		$args       = apply_filters( 'frm_get_categories', $args, $field );
        $categories = get_categories( $args );
        $options    = array();

		foreach ( $categories as $cat ) {
			$options[ $cat->term_id ] = $cat->name;
		}

		$options = FrmProFieldsController::order_values( $options, array( 'dynamic_field' => $field ) );

		return apply_filters(
			'frm_category_opts',
			$options,
			$field,
			array(
				'cat'  => $categories,
				'args' => $args,
			)
		);
	}

	/**
	 * @param array $args
	 */
	public static function get_child_checkboxes( $args ) {
		$defaults = array(
			'field'      => 0,
			'field_name' => false,
			'opt_key'    => 0,
			'opt'        => '',
			'type'       => 'checkbox',
			'value'      => false,
			'exclude'    => 0,
			'hide_id'    => false,
			'tax_num'    => 0,
		);
		$args     = wp_parse_args( $args, $defaults );

		if ( ! $args['field'] || ! isset( $args['field']['post_field'] ) || $args['field']['post_field'] !== 'post_category' ) {
			return;
		}

		if ( ! $args['value'] ) {
			$args['value'] = $args['field']['value'] ?? '';
		}

		if ( ! $args['exclude'] ) {
			$args['exclude'] = is_array( $args['field']['exclude_cat'] ) ? implode( ',', $args['field']['exclude_cat'] ) : $args['field']['exclude_cat'];
			$args['exclude'] = apply_filters( 'frm_exclude_cats', $args['exclude'], $args['field'] );
		}

		if ( ! $args['field_name'] ) {
			$args['field_name'] = 'item_meta[' . $args['field']['id'] . ']';
		}

		if ( $args['type'] === 'checkbox' ) {
			$args['field_name'] .= '[]';
		}

		$post_type = FrmProFormsHelper::post_type( $args['field']['form_id'] );
		$taxonomy  = 'category';

		$cat_atts = array(
			'orderby'    => 'name',
			'order'      => 'ASC',
			'hide_empty' => false,
			'parent'     => $args['opt_key'],
			'exclude'    => $args['exclude'],
			'type'       => $post_type,
		);

		if ( ! $args['opt_key'] ) {
			$cat_atts['taxonomy'] = FrmProAppHelper::get_custom_taxonomy( $post_type, $args['field'] );

			if ( ! $cat_atts['taxonomy'] ) {
				echo '<p>' . esc_html__( 'No Categories', 'formidable-pro' ) . '</p>';
				return;
			}

			$taxonomy = $cat_atts['taxonomy'];
		}

		$children = get_categories( $cat_atts );
		unset( $cat_atts );

		$level = $args['opt_key'] ? 2 : 1;

		foreach ( $children as $cat ) {  ?>
		<div class="frm_catlevel_<?php echo (int) $level; ?>"><?php
			self::_show_category(
				array(
					'cat'        => $cat,
					'field'      => $args['field'],
					'field_name' => $args['field_name'],
					'exclude'    => $args['exclude'],
					'type'       => $args['type'],
					'value'      => $args['value'],
					'level'      => $level,
					'onchange'   => '',
					'post_type'  => $post_type,
					'taxonomy'   => $taxonomy,
					'hide_id'    => $args['hide_id'],
					'tax_num'    => $args['tax_num'],
				)
			);
		?></div>
<?php
		}
	}

	/**
	 * Get the max depth for any given taxonomy (recursive function)
	 *
	 * Since 2.0
	 *
	 * @param string $cat_name - taxonomy name
	 * @param int $parent - parent ID, 0 by default
	 * @param int $cur_depth - depth of current taxonomy path
	 * @param int $max_depth - max depth of given taxonomy
	 *
	 * @return int $max_depth - max depth of given taxonomy
	 */
	public static function get_category_depth( $cat_name, $parent = 0, $cur_depth = 0, $max_depth = 0 ) {
		if ( ! $cat_name ) {
			$cat_name = 'category';
		}

		// Return zero if taxonomy is not hierarchical
		if ( $parent == 0 && ! is_taxonomy_hierarchical( $cat_name ) ) {
			return 0;
		}

		// Get all level one categories first
		$categories = get_categories(
			array(
				'number'     => 10,
				'taxonomy'   => $cat_name,
				'parent'     => $parent,
				'orderby'    => 'name',
				'order'      => 'ASC',
				'hide_empty' => false,
			)
		);

		// Only go 5 levels deep at the most
		if ( ! $categories || $cur_depth == 5 ) {
			// Only update the max depth, if the current depth is greater than the max depth so far
			return max( $cur_depth, $max_depth );
		}

		// Increment the current depth
		++$cur_depth;

		foreach ( $categories as $cat ) {
			$parent = $cat->cat_ID;
			// Get children
			$max_depth = self::get_category_depth( $cat_name, $parent, $cur_depth, $max_depth );
		}

		return $max_depth;
	}

	/**
	 * @param array $atts
	 *
	 * @return void
	 */
	public static function _show_category( $atts ) {
		if ( ! is_object( $atts['cat'] ) ) {
			return;
		}

		if ( is_array( $atts['value'] ) ) {
			$checked = in_array( $atts['cat']->cat_ID, $atts['value'] ) ? 'checked="checked" ' : '';
		} elseif ( $atts['cat']->cat_ID == $atts['value'] ) {
			$checked = 'checked="checked" ';
		} else {
			$checked = '';
		}

		$sanitized_name = ( $atts['field']['id'] ?? $atts['field']['field_options']['taxonomy'] ) . '-' . $atts['cat']->cat_ID;

		// Makes sure ID is unique for excluding checkboxes in Categories/Taxonomies in Create Post action
		if ( $atts['tax_num'] ) {
			$sanitized_name .= '-' . $atts['tax_num'];
		}

		?>
		<div class="frm_<?php echo esc_attr( $atts['type'] ); ?>" id="frm_<?php echo esc_attr( $atts['type'] . '_' . $sanitized_name ); ?>">
			<label for="field_<?php echo esc_attr( $sanitized_name ); ?>"><input type="<?php echo esc_attr( $atts['type'] ); ?>" name="<?php echo esc_attr( $atts['field_name'] ); ?>" <?php
				echo ! empty( $atts['hide_id'] ) ? '' : 'id="field_' . esc_attr( $sanitized_name ) . '"';
			?> value="<?php echo esc_attr( $atts['cat']->cat_ID ); ?>" <?php
			echo $checked; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			do_action( 'frm_field_input_html', $atts['field'] );
			?> /><?php echo esc_html( $atts['cat']->cat_name ); ?></label>
<?php
		$children = get_categories(
			array(
				'type'       => $atts['post_type'],
				'orderby'    => 'name',
				'order'      => 'ASC',
				'hide_empty' => false,
				'exclude'    => $atts['exclude'],
				'parent'     => $atts['cat']->cat_ID,
				'taxonomy'   => $atts['taxonomy'],
			)
		);

		if ( $children ) {
	++$atts['level'];

	foreach ( $children as $cat ) {
		$atts['cat'] = $cat;
		?>
		<div class="frm_catlevel_<?php echo esc_attr( $atts['level'] ); ?>"><?php self::_show_category( $atts ); ?></div>
<?php
	}
		}
		echo '</div>';
	}

	/**
	 * Filter the post status options for the current user
	 * Add default options if there are no valid options
	 *
	 * @param object $field
	 * @param array $options
	 *
	 * @return array
	 */
	public static function get_status_options( $field, $options = array() ) {
		return self::get_post_status_options( $field->form_id, $options );
	}

	/**
	 * Filter the post status options for the current user
	 * Add default options if there are no valid options
	 *
	 * @param string $form_id
	 * @param array $options
	 *
	 * @return array
	 */
	public static function get_post_status_options( $form_id, $options = array() ) {
		if ( FrmAppHelper::is_admin() ) {
			$post_status_options = self::get_initial_post_status_options();
		} else {
			$post_status_options = self::get_post_status_options_for_current_user( $form_id );
		}

		if ( empty( $post_status_options ) ) {
			return array();
		}

		$post_status_keys   = array_keys( $post_status_options );
		$post_status_keys[] = 'publish'; // Allow publish to be included as an option for everyone

		$final_options = array();

		foreach ( $options as $opt_key => $opt ) {
			$opt_key = is_array( $opt ) ? ( $opt['value'] ?? $opt['label'] ?? reset( $opt ) ) : $opt;

			if ( in_array( $opt_key, $post_status_keys ) ) {
				$final_options[ $opt_key ] = $opt;
			}
		}

		return $final_options ? $final_options : $post_status_options;
	}

	/**
	 * Get the initial options for a Post Status field
	 *
	 * @since 2.03.01
	 *
	 * @return array
	 */
	public static function get_initial_post_status_options() {
		$post_statuses = self::get_post_statuses();

		foreach ( $post_statuses as $key => $value ) {
			$post_statuses[ $key ] = array(
				'label' => $value,
				'value' => $key,
			);
		}

		return $post_statuses;
	}

	/**
	 * @since 4.0
	 */
	private static function get_post_statuses() {
		$post_statuses           = get_post_statuses();
		$post_statuses['future'] = __( 'Scheduled' );
		return $post_statuses;
	}

	/**
	 * Get the possible post status options for the current user
	 *
	 * @since 2.03.01
	 *
	 * @param string $form_id
	 *
	 * @return array - associative array with lowercase post status options as keys
	 */
	private static function get_post_status_options_for_current_user( $form_id ) {
		$post_status_options = array();
		$post_type           = FrmProFormsHelper::post_type( $form_id );
		$post_type_object    = get_post_type_object( $post_type );

		if ( ! $post_type_object ) {
			return $post_status_options;
		}

		$post_status_options = self::get_post_statuses();

		// Remove options that the current user should not have
		$can_publish = current_user_can( $post_type_object->cap->publish_posts );

		if ( ! $can_publish ) {
			unset( $post_status_options['publish'], $post_status_options['future'] );
		}

		return $post_status_options;
	}

	/**
	 * @param array $where
	 */
	public static function posted_field_ids( $where ) {
		$form_id = FrmAppHelper::get_post_param( 'form_id', 0, 'absint' );

		if ( $form_id && FrmProFormsHelper::has_another_page( $form_id ) ) {
			$where['fi.field_order <'] = FrmAppHelper::get_post_param( 'frm_page_order_' . $form_id, 0, 'absint' );
		}

		return $where;
	}

	/**
	 * @param array|object $field
	 * @param int         $id
	 *
	 * @return void
	 */
	public static function set_field_js( $field, $id = 0 ) {
		global $frm_vars;

		if ( ! isset( $frm_vars['datepicker_loaded'] ) || ! is_array( $frm_vars['datepicker_loaded'] ) ) {
			return;
		}

		$field_key = self::get_datepicker_key( $field );

		if ( ! $field_key ) {
			return;
		}

		$start_year = FrmField::get_option( $field, 'start_year' );
		$start_year = self::convert_to_static_year( $start_year );

		$end_year = FrmField::get_option( $field, 'end_year' );
		$end_year = self::convert_to_static_year( $end_year );

		$default_date = self::get_default_cal_date( $start_year, $end_year );

		$locale = FrmField::get_option( $field, 'locale' );
		$unique = FrmField::get_option( $field, 'unique' );

		$field = (array) $field;

		$field_js                                    = array(
			'start_year'   => $start_year,
			'end_year'     => $end_year,
			'locale'       => $locale === 'en' ? '' : $locale,
			'unique'       => $unique,
			'field_id'     => $field['id'],
			'entry_id'     => $id,
			'default_date' => $default_date,
		);
		$frm_vars['datepicker_loaded'][ $field_key ] = $field_js;
	}

	/**
	 * @since 3.0
	 *
	 * @param array $field
	 */
	private static function get_datepicker_key( $field ) {
		global $frm_vars;

		$field       = (array) $field;
		$field_key   = '';
        $default_key = 'field_' . $field['field_key'];
		$repeat_key  = '^' . $default_key;

		if ( ! empty( $frm_vars['datepicker_loaded'][ $repeat_key ] ) ) {
			$field_key = $repeat_key;
		} elseif ( ! empty( $frm_vars['datepicker_loaded'][ $default_key ] ) ) {
			$field_key = $default_key;
		}

		return $field_key;
	}

	/**
	 * If using -100, +10, or maybe just 10 for the start or end year
	 *
	 * @since 2.0.12
	 *
	 * @param int|string $year
	 */
	public static function convert_to_static_year( $year ) {
		if ( strlen( $year ) !== 4 || str_contains( $year, '-' ) || str_contains( $year, '+' ) ) {
			$year = gmdate( 'Y', strtotime( $year . ' years' ) );
		}
		return (int) $year;
	}

	/**
	 * Set the default date for jQuery calendar
	 *
	 * @since 2.0.12
	 *
	 * @param int $start_year
	 * @param int $end_year
	 *
	 * @return string Default date.
	 */
	private static function get_default_cal_date( $start_year, $end_year ) {
		$current_year = (int) gmdate( 'Y' );

		// If current year falls inside of the date range, make the default date today's date
		if ( $current_year >= $start_year && $current_year <= $end_year ) {
			return '';
		}

		return 'January 1, ' . $start_year . ' 00:00:00';
	}

	/**
	 * @param array $fields
	 */
	public static function get_form_fields( $fields, $form_id, $errors = array() ) {
		$error        = ! empty( $errors );
		$page_numbers = self::get_base_page_info( compact( 'fields', 'form_id', 'error', 'errors' ) );
		$ajax         = FrmProFormsHelper::has_form_setting(
			array(
				'form_id'          => $form_id,
				'setting_name'     => 'ajax_submit',
				'expected_setting' => 1,
			)
		);

		foreach ( (array) $fields as $k => $f ) {
			// Prevent sub fields from showing
			if ( $f->form_id != $form_id ) {
				unset( $fields[ $k ] );
			}

			if ( $ajax ) {
				self::set_ajax_field_globals( $f );
			}

			if ( $f->type !== 'break' ) {
				continue;
			}

			$page_numbers['page_breaks'][ $f->field_order ] = $f;

			self::get_next_and_prev_page( $f, $error, $page_numbers );

			unset( $f, $k );
		}

		if ( method_exists( 'FrmFieldName', 'track_first_name_field' ) ) {
			// This will override the tracked data in the Lite plugin.
			FrmFieldName::track_first_name_field( $fields );
		}

		unset( $ajax );

		if ( empty( $page_numbers['page_breaks'] ) ) {
			// There are no page breaks, so let's not check the pagination
			return $fields;
		}

		if ( ! $page_numbers['prev_page_obj'] && $page_numbers['prev_page'] ) {
			$page_numbers['prev_page'] = 0;
		}

		self::skip_conditional_pages( $page_numbers );
		self::set_prev_page_global( $form_id, $page_numbers );
		self::set_next_page_to_field_order( $form_id, $page_numbers );

		self::set_page_num_global( $page_numbers );

		unset( $page_numbers['page_breaks'] );

		self::set_fields_to_hidden( $fields, $page_numbers );

		return $fields;
	}

	/**
	 * @param array $atts {
	 *
	 *    @type array<stdClass> $fields
	 *    @type string          $form_id
	 *    @type bool            $error
	 *    @type array           $errors
	 * }
	 *
	 * @return array {
	 *
	 *     @type array     $page_breaks
	 *     @type bool      $go_back
	 *     @type bool      $next_page
	 *     @type int       $set_prev
	 *     @type bool      $set_next
	 *     @type bool      $get_last
	 *     @type bool      $prev_page_obj
	 *     @type false|int $prev_page
	 * }
	 */
	public static function get_base_page_info( $atts ) {
		$page_numbers = array(
			'page_breaks'   => array(),
			'go_back'       => false,
			'next_page'     => false,
			'set_prev'      => 0,
			'set_next'      => false,
			'get_last'      => false,
			'prev_page_obj' => false,
			'prev_page'     => FrmAppHelper::get_param( 'frm_page_order_' . $atts['form_id'], false, 'get', 'absint' ),
		);

		if ( FrmProFormsHelper::going_to_prev( $atts['form_id'] ) ) {
			$page_numbers['go_back']   = true;
			$page_numbers['next_page'] = FrmAppHelper::get_param( 'frm_next_page', 0, 'get', 'absint' );
			$page_numbers['prev_page'] = $page_numbers['next_page'] - 1;
			$page_numbers['set_prev']  = $page_numbers['prev_page'];
		} elseif ( FrmProFormsHelper::saving_draft() && ! $atts['error'] ) {
			$page_numbers['next_page'] = FrmAppHelper::get_param( 'frm_page_order_' . $atts['form_id'], false, 'get', 'absint' );

			// If next_page is zero, assume user clicked "Save Draft" on last page of form
			if ( $page_numbers['next_page'] === 0 ) {
				foreach ( $atts['fields'] as $field ) {
					if ( $field->type !== 'break' ) {
						continue;
					}

					$last_page = $field->field_order;
				}

				if ( isset( $last_page ) ) {
					// Assign the last page to prev_page
					$page_numbers['prev_page'] = $last_page;
				}
			} else {
				$page_numbers['set_prev']  = $page_numbers['prev_page'];
				$page_numbers['prev_page'] = $page_numbers['next_page'] - 1;
			}
		}

		if ( $atts['error'] ) {
			return self::update_page_info_on_error( $page_numbers, $atts );
		}

		return $page_numbers;
	}

	/**
	 * @since 5.5.3
	 *
	 * @param array $page_numbers
	 * @param array $atts
	 *
	 * @return array
	 */
	private static function update_page_info_on_error( $page_numbers, $atts ) {
		$page_numbers['set_prev'] = $page_numbers['prev_page'];
		$came_from_page           = self::get_last_page_num( $atts );

		if ( false !== $came_from_page ) {
			$page_numbers['prev_page'] = $came_from_page - 1;
			$page_numbers['set_prev']  = $page_numbers['prev_page'];
		} elseif ( $page_numbers['prev_page'] ) {
			$page_numbers['prev_page'] = $page_numbers['prev_page'] - 1;
		} else {
			$page_numbers['prev_page'] = 999;
			$page_numbers['get_last']  = true;
		}

		return $page_numbers;
	}

	/**
	 * @param array $atts
	 *
	 * @return bool|int|string
	 */
	private static function get_last_page_num( $atts ) {
		$has_last_page = isset( $_POST['frm_last_page'] );

		if ( $has_last_page ) {
			$came_from_page = FrmAppHelper::get_param( 'frm_last_page', false, 'get', 'sanitize_text_field' );
		} else {
			$came_from_page = false;
		}

		self::get_page_with_error( $atts, $came_from_page );
		return $came_from_page;
	}

	/**
	 * @param array $atts {
	 *
	 *    @type array $errors
	 * }
	 *
	 * @param bool|string $came_from_page
	 *
	 * @return void
	 */
	private static function get_page_with_error( $atts, &$came_from_page ) {
		if ( empty( $atts['errors'] ) ) {
			return;
		}

		$error_fields = array_keys( $atts['errors'] );
		$field_ids    = self::get_field_ids_for_error( $error_fields );

		if ( ! $field_ids ) {
			return;
		}

		$first_error = FrmDb::get_var( 'frm_fields', array( 'id' => $field_ids ), 'field_order', array( 'order_by' => 'field_order ASC' ) );

		if ( is_numeric( $first_error ) ) {
			$came_from_page = $first_error + 1;
		}
	}

	/**
	 * Get an array of field ids that have errors.
	 * If the field is in a repeating or embedded form, use the id
	 * of the field that belongs to this form instead of a child form.
	 *
	 * @since 2.05
	 *
	 * @param array $error_fields
	 *
	 * @return array
	 */
	private static function get_field_ids_for_error( $error_fields ) {
		$field_ids = array();

		foreach ( $error_fields as $error_field ) {
			if ( str_starts_with( $error_field, 'field' ) ) {
				$field_id = str_replace( 'field', '', $error_field );

				if ( strpos( $field_id, '-' ) ) {
					$field_parts = explode( '-', $field_id );

					if ( count( $field_parts ) === 3 ) {
						// Use the id of the parent repeating/embedded field
						$field_id = $field_parts[1];
					}
				}

				$field_ids[] = $field_id;
			}
		}

		return $field_ids;
	}

	/**
	 * When a form is loaded with ajax, we need all the info for
	 * the fields included in the footer with the first page
	 *
	 * @param stdClass $f
	 */
	private static function set_ajax_field_globals( $f ) {
		global $frm_vars;
		$ajax_now = ! FrmAppHelper::doing_ajax();

		if ( ! $ajax_now && ! empty( $frm_vars['inplace_edit'] ) ) {
			$ajax_now = true;
		}

		switch ( $f->type ) {
			case 'date':
				if ( ! FrmField::is_read_only( $f ) || FrmField::get_option( $f, 'date_calc' ) ) {
					if ( ! isset( $frm_vars['datepicker_loaded'] ) || ! is_array( $frm_vars['datepicker_loaded'] ) ) {
						$frm_vars['datepicker_loaded'] = array();
					}
					$frm_vars['datepicker_loaded'][ 'field_' . $f->field_key ] = $ajax_now;

					if ( $ajax_now ) {
						self::set_field_js( $f );
					}
				}
				break;
			case 'time':
				if ( ! empty( $f->field_options['unique'] ) && ! empty( $f->field_options['single_time'] ) ) {
					if ( ! isset( $frm_vars['timepicker_loaded'] ) ) {
						$frm_vars['timepicker_loaded'] = array();
					}
					$frm_vars['timepicker_loaded'][ 'field_' . $f->field_key ] = $ajax_now;
				}
				break;
			case 'text':
			case 'phone':
				if ( FrmProField::is_format_option_true_with_no_regex( $f ) ) {
					global $frm_input_masks;
					$frm_input_masks[] = $ajax_now;
				}
				break;
			case 'form':
				$fields = FrmField::get_all_for_form( $f->field_options['form_select'], '', 'exclude', 'exclude' );

				foreach ( $fields as $field ) {
					self::set_ajax_field_globals( $field );
				}
				break;
		}

		/**
		 * @since 2.05.06
		 */
		do_action(
			'frm_load_ajax_field_scripts',
			array(
				'field'    => $f,
				'is_first' => $ajax_now,
			)
		);
	}

	/**
	 * @param stdClass $f
	 * @param bool     $error
	 * @param array    $page_numbers
	 *
	 * @return void
	 */
	private static function get_next_and_prev_page( $f, $error, &$page_numbers ) {
		if ( ( $page_numbers['prev_page'] || $page_numbers['go_back'] ) && ! $page_numbers['get_last'] ) {
			if ( ( ( $error || $page_numbers['go_back'] ) && $f->field_order < $page_numbers['prev_page'] ) || ( ! $error && ! $page_numbers['go_back'] && ! $page_numbers['prev_page_obj'] && $f->field_order == $page_numbers['prev_page'] ) ) {
				$page_numbers['prev_page_obj'] = true;
				$page_numbers['prev_page']     = $f->field_order;
			} elseif ( $page_numbers['set_prev'] && $f->field_order < $page_numbers['set_prev'] ) {
				$page_numbers['prev_page_obj'] = true;
				$page_numbers['prev_page']     = $f->field_order;
			} elseif ( ( $f->field_order > $page_numbers['prev_page'] ) && ! $page_numbers['set_next'] && ( ! $page_numbers['next_page'] || is_numeric( $page_numbers['next_page'] ) ) ) {
				$page_numbers['next_page'] = $f;
				$page_numbers['set_next']  = true;
			}
		} elseif ( $page_numbers['get_last'] ) {
			$page_numbers['prev_page_obj'] = true;
			$page_numbers['prev_page']     = $f->field_order;
			$page_numbers['next_page']     = false;
		} elseif ( ! $page_numbers['next_page'] ) {
			$page_numbers['next_page'] = $f;
		} elseif ( is_numeric( $page_numbers['next_page'] ) && $f->field_order == $page_numbers['next_page'] ) {
			$page_numbers['next_page'] = $f;
		}
	}

	/**
	 * @param array $page_numbers
	 */
	private static function skip_conditional_pages( &$page_numbers ) {
		if ( ! $page_numbers['prev_page'] ) {
			return;
		}

		$current_page = $page_numbers['page_breaks'][ $page_numbers['prev_page'] ];
		$skip_page    = self::is_field_hidden( $current_page, wp_unslash( $_POST ) );

		if ( ! $skip_page ) {
			return;
		}

		$current_page = apply_filters( 'frm_get_current_page', $current_page, $page_numbers['page_breaks'], $page_numbers['go_back'] );

		if ( ! is_object( $current_page ) && $current_page < 0 ) {
			$current_page = 0;
		}

		if ( $current_page && $current_page->field_order == $page_numbers['prev_page'] ) {
			return;
		}

		$page_numbers['prev_page'] = $current_page ? $current_page->field_order : 0;

		foreach ( $page_numbers['page_breaks'] as $o => $pb ) {
			if ( $o > $page_numbers['prev_page'] ) {
				$page_numbers['next_page'] = $pb;
				break;
			}
		}

		if ( $page_numbers['next_page']->field_order <= $page_numbers['prev_page'] ) {
			$page_numbers['next_page'] = false;
		}
	}

	/**
	 * @param array $page_numbers
	 */
	private static function set_prev_page_global( $form_id, $page_numbers ) {
		global $frm_vars;

		if ( $page_numbers['prev_page'] ) {
			$frm_vars['prev_page'][ $form_id ] = $page_numbers['prev_page'];
		} else {
			unset( $frm_vars['prev_page'][ $form_id ] );
		}
	}

	/**
	 * @param array $page_numbers
	 */
	private static function set_next_page_to_field_order( $form_id, &$page_numbers ) {
		global $frm_vars;

		if ( $page_numbers['next_page'] ) {
			if ( is_numeric( $page_numbers['next_page'] ) && isset( $page_numbers['page_breaks'][ $page_numbers['next_page'] ] ) ) {
				$page_numbers['next_page'] = $page_numbers['page_breaks'][ $page_numbers['next_page'] ];
			}

			if ( ! is_numeric( $page_numbers['next_page'] ) ) {
				$frm_vars['next_page'][ $form_id ] = $page_numbers['next_page'];
				$page_numbers['next_page']         = $page_numbers['next_page']->field_order;
			}
		} else {
			unset( $frm_vars['next_page'][ $form_id ] );
		}
	}

	/**
	 * @param array $page_numbers
	 */
	private static function set_page_num_global( $page_numbers ) {
		global $frm_page_num;
		$pages        = array_keys( $page_numbers['page_breaks'] );
		$frm_page_num = $page_numbers['prev_page'] ? array_search( $page_numbers['prev_page'], $pages ) + 2 : 1;
	}

	/**
	 * Hide fields that are not on the current active page.
	 *
	 * @since 2.0.09
	 * @since 6.0 Added a new frm_hide_fields_on_other_pages filter.
	 *
	 * @param array $fields
	 * @param array $page_numbers
	 *
	 * @return void
	 */
	private static function set_fields_to_hidden( &$fields, $page_numbers ) {
		if ( ! $page_numbers['next_page'] && ! $page_numbers['prev_page'] ) {
			return;
		}

		/**
		 * Allow fields from all pages to be displayed with add_filter( 'frm_hide_fields_on_other_pages', '__return_false' );
		 *
		 * @since 6.0
		 */
		$should_hide_fields = apply_filters( 'frm_hide_fields_on_other_pages', true );

		if ( ! $should_hide_fields ) {
			return;
		}

		foreach ( $fields as $f ) {
			if ( $f->type === 'user_id' ) {
				continue;
			}

			if ( $f->type === 'hidden' ) {
				if ( self::hide_on_page( $page_numbers, $f ) ) {
					self::$fields_hidden_on_page[] = (int) $f->id;
				}
				continue;
			}

			if ( self::hide_on_page( $page_numbers, $f ) ) {
				if ( ! is_array( $f->field_options ) ) {
					$f->field_options = array();
				}

				self::$fields_hidden_on_page[]     = (int) $f->id;
				$f->field_options['original_type'] = $f->type;
				$f->type                           = 'hidden';
			}

			unset( $f );
		}
	}

	/**
	 * Check if a field should be hidden on the current page
	 *
	 * @param array    $page_numbers
	 * @param stdClass $f
	 *
	 * @return bool
	 */
	private static function hide_on_page( $page_numbers, $f ) {
		return ( $page_numbers['prev_page'] && $page_numbers['next_page'] && ( $f->field_order < $page_numbers['prev_page'] ) && ( $f->field_order > $page_numbers['next_page'] ) ) || ( $page_numbers['prev_page'] && $f->field_order < $page_numbers['prev_page'] ) || ( $page_numbers['next_page'] && $f->field_order > $page_numbers['next_page'] );
	}

	public static function get_current_page( $next_page, $page_breaks, $go_back, $order = 'asc' ) {
		$first    = $next_page;
		$set_back = false;

		if ( $go_back && $order === 'asc' ) {
			$order       = 'desc';
			$page_breaks = array_reverse( $page_breaks, true );
		}

		foreach ( $page_breaks as $pb ) {
			if ( $go_back && $pb->field_order < $next_page->field_order ) {
				$next_page = $pb;
				$set_back  = true;
				break;
			}

			if ( ! $go_back && $pb->field_order > $next_page->field_order && $pb->field_order != $first->field_order ) {
				$next_page = $pb;
				break;
			}
			unset( $pb );
		}

		if ( $go_back && ! $set_back ) {
			$next_page = 0;
		}

		if ( self::skip_next_page( $next_page ) ) {
			return $first == $next_page ? -1 : self::get_current_page( $next_page, $page_breaks, $go_back, $order );
		}

		return $next_page;
	}

	/**
	 * @return bool
	 */
	private static function skip_next_page( $next_page ) {
		return $next_page && self::is_field_hidden( $next_page, wp_unslash( $_POST ) );
	}

	public static function show_custom_html( $show, $field_type ) {
		if ( in_array( $field_type, array( 'break', 'end_divider' ), true ) ) {
			return false;
		}
		return $show;
	}

	/**
	 * @since 4.05
	 *
	 * @param array|object $field
	 *
	 * @return string
	 */
	public static function builder_page_prepend( $field ) {
		$html = '[input]';
		self::include_prepend( $field, $html );
		return $html;
	}

	/**
	 * @param array $field
	 */
	public static function before_replace_shortcodes( $html, $field ) {
		if ( isset( $field['classes'] ) && str_contains( $field['classes'], 'frm_grid' ) ) {
			$opt_count = 1;

			if ( isset( $field['options'] ) && is_array( $field['options'] ) ) {
				$opt_count = count( $field['options'] ) + 1;
			}

			$html = str_replace( '[required_class]', '[required_class] frm_grid_' . $opt_count, $html );

			if ( strpos( $html, ' horizontal_radio' ) ) {
				$html = str_replace( ' horizontal_radio', ' vertical_radio', $html );
			}
		}

		self::include_prepend( $field, $html );

		return $html;
	}

	/**
	 * @since 4.05
	 *
	 * @param array|object $field
	 * @param string       $html
	 *
	 * @return void
	 */
	private static function include_prepend( $field, &$html ) {
		$type = FrmField::get_field_type( $field );

		if ( in_array( $type, array( 'range', 'virtual', 'scale' ), true ) ) {
			// Range: The field handles a prefix differently.
			// Virtual: The field is server-side only and handles its own display.
			// Scale: Labels are placed under the first/last options.
			return;
		}

		$prepend     = FrmField::get_option( $field, 'prepend' );
		$append      = FrmField::get_option( $field, 'append' );
		$is_currency = FrmField::get_option( $field, 'is_currency' ) || FrmProCurrencyHelper::is_currency_format( FrmField::get_option( $field, 'format' ) );

		if ( ! $prepend && ! $append && ! $is_currency ) {
			return;
		}

		if ( $is_currency && is_array( $field ) && isset( $field['form_id'] ) ) {
			FrmProCurrencyHelper::add_currency_to_global( $field['form_id'] );

			if ( ! empty( $field['parent_form_id'] ) ) {
				FrmProCurrencyHelper::add_currency_to_global( $field['parent_form_id'] );
			}
		}

		preg_match_all( "/\[(input)\b(.*?)(?:(\/))?\]/s", $html, $shortcodes, PREG_PATTERN_ORDER );

		if ( empty( $shortcodes[0] ) ) {
			return;
		}

		$class       = self::input_group_class( $prepend, $append, FrmField::get_option( $field, 'autocom' ) );
		$pre         = '';
        $css_classes = FrmField::get_option( $field, 'classes' );
		$calc        = FrmField::get_option( $field, 'calc' );
		$is_total    = str_contains( $css_classes, 'frm_total' ) || $is_currency;

		if ( $is_total && $calc ) {
			$class .= ' frm_hidden';
			$pre   .= '<p class="frm_total_formatted" data-prepend="' . esc_attr( $prepend ) . '" data-append="' . esc_attr( $append ) . '"></p>';
		}

		$pre .= '<div class="' . esc_attr( $class ) . '"' . self::group_width( $field ) . '>';
		$pre .= self::prepend_html( $prepend );

		$post  = self::prepend_html( $append );
		$post .= '</div>';

		foreach ( $shortcodes[0] as $val ) {
			$html = str_replace( $val, $pre . $val . $post, $html );
		}
	}

	/**
	 * @since 4.05
	 * @since 6.9.1 Added $autocomplete parameter
	 *
	 * @param string $prepend
	 * @param string $append
	 * @param int    $autocomplete
	 *
	 * @return string
	 */
	private static function input_group_class( $prepend, $append, $autocomplete ) {
		if ( ! $prepend && ! $append ) {
			// Prevent the input group styles from being added if there is no prepend or append.
			// This is for the currency logic, that calls this function even when there is no input group.
			return 'frm_with_box';
		}

		$class = 'frm_input_group';

		if ( $prepend && $append ) {
			$class .= ' frm_with_boxes ';
		} else {
			$class .= ' frm_with_box';
		}

		if ( $prepend ) {
			$class .= ' frm_with_pre';
		}

		if ( $append ) {
			$class .= ' frm_with_post';
		}

		if ( $autocomplete && ! FrmProAppHelper::use_chosen_js() ) {
			$class .= ' frm_slimselect_wrapper';
		}

		return $class;
	}

	/**
	 * @since 4.05
	 *
	 * @param string $prepend
	 *
	 * @return string
	 */
	private static function prepend_html( $prepend ) {
		if ( ! $prepend ) {
			return '';
		}
		return '<span class="frm_inline_box">' . FrmAppHelper::kses( $prepend, array( 'i' ) ) . '</span>';
	}

	/**
	 * Include the field width if it's set in the field options.
	 *
	 * @since 4.06
	 *
	 * @param array|object $field
	 */
	private static function group_width( $field ) {
		$style = '';
		$width = FrmField::get_option( $field, 'size' );

		if ( ! $width || $width < 0 ) {
        	return $style;
        }

        if ( is_numeric( $width ) ) {
            $width .= 'px';
        }

        $style = ' style="width:' . esc_attr( $width ) . '"';
        add_filter( 'frm_field_classes', 'FrmProFieldsHelper::remove_auto_width' );

		return $style;
	}

	/**
	 * Fields with a set width are wrapping when they include prepend/append.
	 *
	 * @since 4.06
	 *
	 * @param string $class
	 */
	public static function remove_auto_width( $class ) {
		remove_filter( 'frm_field_classes', 'FrmProFieldsHelper::remove_auto_width' );
		return str_replace( 'auto_width', '', $class );
	}

	/**
	 * @param array $atts
	 */
	public static function replace_html_shortcodes( $html, $field, $atts ) {
		if ( FrmField::is_option_true( $field, 'conf_field' ) ) {
			$html .= self::get_confirmation_field_html( $field, $atts );
		}

		if ( 'html' === FrmField::get_field_type( $field ) ) {
			if ( str_contains( $html, '[form_name]' ) ) {
				$html = str_replace( '[form_name]', FrmForm::getName( FrmField::get_option( $field, 'form_id' ) ), $html );
			}

			$html = self::maybe_replace_if_shortcodes( $html, $field );
		}

		return $html;
	}

	/**
	 * @param string $html
	 * @param array  $html_field
	 *
	 * @return string
	 */
	private static function maybe_replace_if_shortcodes( $html, $html_field ) {
		if ( ! str_contains( $html, '[if' ) ) {
			// Only try if there are if shortcodes present.
			return $html;
		}

		$form_id    = $html_field['form_id'];
		$shortcodes = FrmProDisplaysHelper::get_shortcodes( $html, $form_id );
		$html_field = FrmField::getOne( $html_field['id'] ); // Change $html_field to an object because get_observed_logic_value expects an object.

		foreach ( $shortcodes[0] as $short_key => $tag ) {
			$conditional = preg_match( '/^\[if/s', $tag ) ? true : false;

			if ( ! $conditional ) {
				continue;
			}

			$foreach         = false;
			$field_id_or_key = FrmShortcodeHelper::get_shortcode_tag( $shortcodes, $short_key, compact( 'conditional', 'foreach' ) );
            $field           = FrmField::getOne( $field_id_or_key );

			if ( ! $field ) {
				continue;
			}

			$atts              = FrmShortcodeHelper::get_shortcode_attribute_array( $shortcodes[3][ $short_key ] );
			$atts['short_key'] = $tag;
			$replace_with      = self::get_observed_logic_value( $html_field, $_POST, $field->id );

			FrmProContent::check_conditional_shortcode( $html, $replace_with, $atts, $field_id_or_key, 'if', array( 'field' => $field ) );
		}

		return $html;
	}

	/**
	 * Get the HTML for a confirmation field
	 *
	 * @param array $field
	 * @param array $atts
	 *
	 * @return string
	 */
	private static function get_confirmation_field_html( $field, $atts ) {
		$conf_field = self::create_confirmation_field_array( $field, $atts );
        $args       = self::generate_repeat_args_for_conf_field( $field, $atts );

		// Replace shortcodes
		$extra_args = array(
			'errors' => $atts['errors'],
			'form'   => '',
		);
		$field_obj  = FrmFieldFactory::get_field_type( $conf_field['type'], $conf_field );
		$conf_html  = $field_obj->prepare_field_html( array_merge( $extra_args, $args ) );

		// Add a couple of classes
		$label_class = 'frm_primary_label';

		if ( ! str_contains( $conf_html, $label_class ) ) {
			$label_class = 'frm_pos_';
		}

		$conf_html       = str_replace( $label_class, 'frm_conf_label ' . $label_class, $conf_html );
        $container_class = 'frm_form_field';

		if ( ! str_contains( $conf_html, $container_class ) ) {
			$container_class = 'form-field';
		}

		$conf_html = str_replace( $container_class, $container_class . ' frm_conf_field', $conf_html );
        $conf_msg  = FrmFieldsHelper::get_error_msg( $field, 'conf_msg' );

		if ( $conf_msg ) {
			$conf_html = str_replace( 'data-invmsg=', 'data-confmsg="' . esc_attr( $conf_msg ) . '" data-invmsg=', $conf_html );
		}

		$add_class = self::get_confirmation_field_class( $field );

		return str_replace( $container_class, $container_class . $add_class, $conf_html );
	}

	/**
	 * Remove confirmation field label if stacked.
	 * Hide if inline, right, or left.
	 *
	 * @since 2.05
	 *
	 * @param array $field
	 *
	 * @return string
	 */
	private static function get_confirmation_field_class( $field ) {
		// Show the confirmation field label when the "Show confirmation field labels" setting is on.
		// Treat a missing option as on so existing fields show labels by default.
		if ( ! isset( $field['conf_label'] ) || FrmField::is_option_true( $field, 'conf_label' ) ) {
			return '';
		}

		$has_layout = ! empty( $field['classes'] ) && str_contains( $field['classes'], 'frm' );

		if ( $field['conf_field'] === 'inline' || $has_layout ) {
			$add_class = ' frm_hidden_container';
		} elseif ( $field['label'] === 'left' || $field['label'] === 'right' ) {
			$add_class = ' frm_hidden_container';
		} else {
			$add_class = ' frm_none_container';
		}

		return $add_class;
	}

	/**
	 * Gets the confirmation field label text.
	 *
	 * Uses the field's "Confirmation Label Text" setting when set, and falls back to
	 * the default "Confirm [field_name]". The [field_name] shortcode is replaced with
	 * the field name.
	 *
	 * @since 6.32
	 *
	 * @param array $field Field data.
	 *
	 * @return string
	 */
	public static function get_confirmation_field_label( $field ) {
		$label = $field['conf_label_text'] ?? __( 'Confirm', 'formidable' ) . ' [field_name]';

		if ( '' === trim( $label ) ) {
			$label = '&nbsp;';
		}

		return str_replace( '[field_name]', $field['name'], $label );
	}

	/**
	 * Create a confirmation field array to prepare for replace_shortcodes function
	 *
	 * @since 2.0.25
	 *
	 * @param array $field
	 * @param array $atts
	 *
	 * @return array
	 */
	private static function create_confirmation_field_array( $field, $atts ) {
		$conf_field = $field;

		$conf_field['id']          = 'conf_' . $field['id'];
		$conf_field['name']        = self::get_confirmation_field_label( $field );
		$conf_field['description'] = $field['conf_desc'];
		$conf_field['field_key']   = 'conf_' . $field['field_key'];

		if ( $conf_field['classes'] ) {
			$conf_field['classes'] = str_replace( array( 'first_', 'frm_first' ), '', $conf_field['classes'] );
		} elseif ( $conf_field['conf_field'] === 'inline' ) {
			$conf_field['classes'] = ' frm6';
		}

		// Prevent loop.
		$conf_field['conf_field'] = 'stop';

		// Filter default value/placeholder text
		$field['conf_input'] = apply_filters( 'frm_get_default_value', $field['conf_input'], (object) $field, false );

		$conf_field['placeholder']   = $field['conf_input'];
		$conf_field['value']         = '';
		$conf_field['default_value'] = '';

		// If going back and forth between pages, keep value in confirmation field.
		if ( ! empty( $conf_field['reset_value'] ) || ! isset( $_POST['item_meta'] ) ) {
        	return $conf_field;
        }

        $temp_args = array();

        if ( isset( $atts['section_id'] ) ) {
            $temp_args = array(
                'parent_field_id' => $atts['section_id'],
                'key_pointer'     => str_replace( '-', '', $atts['field_plus_id'] ),
            );
        }

        FrmEntriesHelper::get_posted_value( $conf_field['id'], $conf_field['value'], $temp_args );

		return $conf_field;
	}

	/**
	 * Generate the repeat args for a confirmation field
	 *
	 * @since 2.0.25
	 *
	 * @param array $field
	 * @param array $atts
	 *
	 * @return array
	 */
	private static function generate_repeat_args_for_conf_field( $field, $atts ) {
		// If inside of repeating section
		$args = array();

		if ( ! isset( $atts['section_id'] ) ) {
        	return $args;
        }

        $args['field_name']    = preg_replace( '/\[' . $field['id'] . '\]$/', '', $atts['field_name'] );
        $args['field_name']    = $args['field_name'] . '[conf_' . $field['id'] . ']';
        $args['field_id']      = 'conf_' . $atts['field_id'];
        $args['field_plus_id'] = $atts['field_plus_id'];
        $args['section_id']    = $atts['section_id'];

		return $args;
	}

	/**
	 * Possibly return an alternative value to $val for export.
	 *
	 * @param array|string $val
	 * @param stdClass     $field
	 * @param array|object $entry
	 *
	 * @return mixed
	 */
	public static function get_export_val( $val, $field, $entry = array() ) {
		if ( $field->type === 'user_id' ) {
			$val = self::get_export_user_id_val( $val );
		} elseif ( $field->type === 'file' ) {
			FrmAppHelper::unserialize_or_decode( $val ); // When exporting as XML $val is a serialized array of integers.
			$val = self::get_export_file_val( $val );
		} elseif ( $field->type === 'date' ) {
			$val = self::get_export_date_val( $val );
		} elseif ( $field->type === 'data' ) {
			$val = self::get_export_data_val( $val, $field, $entry );
		}
		return apply_filters( 'frm_xml_field_export_value', $val, $field );
	}

	private static function get_export_user_id_val( $val ) {
		return FrmFieldsHelper::get_user_display_name( $val, 'user_login' );
	}

	private static function get_export_file_val( $val ) {
		return self::get_file_name( $val, false );
	}

	private static function get_export_date_val( $val ) {
		$wp_date_format = apply_filters( 'frm_csv_date_format', 'Y-m-d' );
		return self::get_date( $val, $wp_date_format );
	}

	/**
	 * @param array|string $val
	 * @param stdClass      $field
	 * @param array|object $entry
	 */
	private static function get_export_data_val( $val, $field, $entry ) {
		$new_val = $val;
		FrmAppHelper::unserialize_or_decode( $new_val );

		if ( ! $new_val && $entry && FrmProField::is_list_field( $field ) ) {
			FrmProEntriesHelper::get_dynamic_list_values( $field, $entry, $new_val );
		}

		if ( is_numeric( $new_val ) ) {
			$val = self::get_data_value( $new_val, $field ); // Replace entry id with specified field
		} elseif ( is_array( $new_val ) ) {
			$val = self::get_array_data_value( $new_val, $field );
		}

		return $val;
	}

	/**
	 * @param array  $values
	 * @param object $field
	 *
	 * @return array|string
	 */
	private static function get_array_data_value( $values, $field ) {
		if ( self::doing_csv_export() ) {
			return self::get_array_data_value_for_csv_export( $values, $field );
		}

		$return = array();

		foreach ( $values as $value ) {
			$return[] = self::get_data_value( $value, $field );
		}

		return implode( ', ', $return );
	}

	/**
	 * @param array  $values
	 * @param object $field
	 *
	 * @return array
	 */
	private static function get_array_data_value_for_csv_export( $values, $field ) {
		$return = array();

		foreach ( $values as $value ) {
			$value                = (array) $value;
			$dynamic_field_values = array();

			foreach ( $value as $dynamic_field_value ) {
				$dynamic_field_values[] = self::get_data_value( $dynamic_field_value, $field );
			}

			$return[] = $dynamic_field_values;
		}

		return $return;
	}

	public static function get_file_icon( $media_id ) {
		if ( ! $media_id || ! is_numeric( $media_id ) ) {
			return;
		}

		$attachment = get_post( $media_id );

		if ( ! $attachment ) {
			return;
		}

		$orig_image = wp_get_attachment_image( $media_id, 'thumbnail', true );
		$image      = $orig_image;

		// If this is a mime type icon
		if ( $image && ! preg_match( '/wp-content\/uploads/', $image ) ) {
			$label  = basename( $attachment->guid );
			$image .= " <span id='frm_media_$media_id' class='frm_upload_label'><a href='" . wp_get_attachment_url( $media_id ) . "'>$label</a></span>";
		} elseif ( $image ) {
			$image = '<a href="' . esc_url( wp_get_attachment_url( $media_id ) ) . '" class="frm_file_link">' . $image . '</a>';
		}

		return apply_filters(
			'frm_file_icon',
			$image,
			array(
				'media_id' => $media_id,
				'image'    => $orig_image,
			)
		);
	}

	/**
	 * Get the file name for the given media IDs
	 *
	 * @param $media_ids
	 * @param bool $short
	 * @param string $sep
	 *
	 * @return string
	 */
	public static function get_file_name( $media_ids, $short = true, $sep = 'default' ) {
		$sep       = $sep === 'default' ? "<br/>\r\n" : $sep;
		$media_ids = (array) $media_ids;
        $value     = self::doing_csv_export() ? array() : '';

		foreach ( $media_ids as $media_id ) {
			if ( is_array( $value ) ) {
				$set     = array();
				$value[] = self::get_file_name_from_array( compact( 'media_id', 'sep', 'short' ), $set );
			} else {
				$value = self::get_file_name_from_array( compact( 'media_id', 'sep', 'short' ), $value );
			}
			unset( $media_id );
		}

		return $value;
	}

	/**
	 * The file id may be an array.
	 * Loop through values in the nested array too.
	 *
	 * @since 2.03.10
	 *
	 * @param array        $atts
	 * @param array|string $value
	 */
	private static function get_file_name_from_array( $atts, $value ) {
		if ( ! is_array( $atts['media_id'] ) ) {
            self::get_file_name_from_id( $atts, $value );
        	return $value;
        }

        $media_ids = $atts['media_id'];

        foreach ( $media_ids as $id ) {
            $atts['media_id'] = $id;
            self::get_file_name_from_id( $atts, $value );
        }

        return $value;
	}

	/**
	 * @since 4.08
	 *
	 * @return bool
	 */
	private static function doing_csv_export() {
		$action     = FrmAppHelper::get_param( 'action', '', 'get', 'sanitize_title' );
		$frm_action = FrmAppHelper::simple_get( 'frm_action', 'sanitize_title' );
		$format     = FrmAppHelper::get_param( 'format', '', 'post', 'sanitize_title' );

		return $frm_action === 'csv' || $action === 'frm_entries_csv' || ( $action === 'frm_export_xml' && $format === 'csv' );
	}

	/**
	 * Get the file output values from the media id
	 *
	 * @param array        $atts
	 * @param array|string $value
	 */
	private static function get_file_name_from_id( $atts, &$value ) {
		if ( ! is_numeric( $atts['media_id'] ) ) {
			return;
		}

		$attachment = get_post( $atts['media_id'] );

		if ( ! $attachment ) {
			return;
		}

		$url = wp_get_attachment_url( $atts['media_id'] );

		if ( is_array( $value ) ) {
			$value[] = $url;
			return;
		}

		$label = $atts['short'] ? basename( $attachment->guid ) : $url;

		if ( self::doing_csv_export() ) {
			if ( $value ) {
				$value .= ', ';
			}
		} elseif ( FrmAppHelper::is_admin() ) {
			$url = '<a href="' . esc_url( $url ) . '">' . $label . '</a>';

			if ( str_starts_with( FrmAppHelper::simple_get( 'page', 'sanitize_title' ), 'formidable-pro' ) ) {
				$url .= '<br/><a href="' . esc_url( admin_url( 'media.php?action=edit&attachment_id=' . $atts['media_id'] ) ) . '">' . esc_html__( 'Edit Uploaded File', 'formidable-pro' ) . '</a>';
			}
		} elseif ( $value ) {
			$value .= $atts['sep'];
		}

		$value .= $url;
	}

	/**
	 * Get the value that will be displayed for a Dynamic Field.
	 *
	 * @param array|string        $value
	 * @param int|stdClass|string $field
	 * @param array               $atts
	 * @param bool                $retrieved_linked_value Set by reference. This is set to true if get_linked_field_val is called.
	 *
	 * @return array|string
	 */
	public static function get_data_value( $value, $field, $atts = array(), &$retrieved_linked_value = false ) {
		// Make sure incoming data is in the right format.
		if ( ! is_object( $field ) ) {
			$field = FrmField::getOne( $field );
		}

		$linked_field_id = self::get_linked_field_id( $atts, $field );
		$is_list_field   = FrmProField::is_list_field( $field ) && ! isset( $atts['force_id'] );

		// If value is an entry ID and the Dynamic field is not mapped to a taxonomy.
		$is_tax = isset( $field->field_options['form_select'] ) && 'taxonomy' === $field->field_options['form_select'];

		if ( is_numeric( $value ) && ! $is_tax && $linked_field_id && ! $is_list_field ) {
			$linked_field = FrmField::getOne( $linked_field_id );

			// Get the value to display.
			self::get_linked_field_val( $linked_field, $atts, $value, $field );
			$retrieved_linked_value = true;
		}

		// Implode arrays.
		if ( is_array( $value ) ) {
			return implode( $atts['sep'] ?? ', ', $value );
		}

		return $value;
	}

	/**
	 * Get the ID of the linked field to display
	 * Called by self::get_data_value().
	 *
	 * @param array  $atts  Atts.
	 * @param object $field Field object.
	 *
	 * @return false|int Linked_field_id int or false.
	 */
	private static function get_linked_field_id( $atts, $field ) {
		// If show=25 or show="user_email" is set, then get that value.
		if ( ! empty( $atts['show'] ) ) {
			$linked_field_id = $atts['show'];
		} elseif ( isset( $field->field_options['form_select'] ) && is_numeric( $field->field_options['form_select'] ) ) {
			// If show=25 is NOT set, then just get the ID of the field selected in the Dynamic field's options.
			$linked_field_id = $field->field_options['form_select'];
		} else { // The linked field ID could be false if Dynamic field is mapped to a taxonomy, using really old settings, or if settings were not completed.
			$linked_field_id = false;
		}
		return $linked_field_id;
	}

	/**
	 * Get the value in the linked field
	 * Called by self::get_data_value().
	 *
	 * @param false|object $linked_field  Linked field object or false.
	 * @param array        $atts          Atts.
	 * @param int          $value         Value.
	 * @param stdClass     $dynamic_field The dynamic field. This is passed in the frm_should_dynamic_field_use_option_label filter.
	 *
	 * @return void
	 */
	private static function get_linked_field_val( $linked_field, $atts, &$value, $dynamic_field ) {
		$is_final_val = ! self::should_use_display_val( $linked_field, $atts, $value );

		// If linked field is a post field.
		if ( $linked_field && ! empty( $linked_field->field_options['post_field'] ) ) {
			$value = self::get_linked_post_field_val( $value, $atts, $linked_field );
		} elseif ( $linked_field ) { // If linked field.
			$original_value = $value;
			$value          = FrmEntryMeta::get_entry_meta_by_field( $value, $linked_field->id );

			if ( null === $value ) {
				if ( isset( $atts['field'] ) && isset( $atts['includes_list_data'] ) && FrmProField::is_list_field( $atts['field'] ) ) {
					// If the dynamic field value was saved, return it.
					$value = $original_value;
				}

				return;
			}
		} else { // No linked field (using show=ID, show="first_name", show="user_email", etc.).
			$user_id = FrmDb::get_var( 'frm_items', array( 'id' => $value ), 'user_id' );

			if ( $user_id ) {
				$show  = $atts['show'] ?? 'display_name';
				$value = FrmFieldsHelper::get_user_display_name( $user_id, $show, array( 'blank' => true ) );
			} else {
				$value = '';
			}
		}

		if ( ! $is_final_val ) {
			self::get_linked_field_display_val( $linked_field, $atts, $value, $dynamic_field );
		}
	}

	/**
	 * Checks if it should use display value for the linked field.
	 *
	 * @param false|object $linked_field Linked field object of false.
	 * @param array        $atts         Atts.
	 * @param int          $value        Value.
	 *
	 * @return bool
	 */
	private static function should_use_display_val( $linked_field, $atts, $value ) {
		if ( ! $linked_field ) {
			return false;
		}

		if ( ! self::doing_csv_export() ) {
			return true;
		}

		if ( in_array( $linked_field->type, array( 'date' ), true ) ) {
			return false;
		}

		$post_field = $linked_field->field_options['post_field'] ?? '';
		return ! ( in_array( $linked_field->type, array( 'rte', 'textarea' ), true ) && in_array( $post_field, array( 'post_content', 'post_excerpt' ), true ) );
	}

	/**
	 * Get the displayed value for Dynamic field that imports data from a post field
	 * Called from self::get_linked_field_val().
	 *
	 * @param int          $value        Value.
	 * @param array        $atts         Atts.
	 * @param false|object $linked_field Linked field object of false.
	 */
	private static function get_linked_post_field_val( $value, $atts, $linked_field ) {
		$post_id = FrmDb::get_var( 'frm_items', array( 'id' => $value ), 'post_id' );

		if ( ! $post_id ) {
            return FrmEntryMeta::get_entry_meta_by_field( $value, $linked_field->id );
        }

        if ( ! isset( $atts['truncate'] ) ) {
            $atts['truncate'] = false;
        }

        return FrmProEntryMetaHelper::get_post_value(
            $post_id,
            $linked_field->field_options['post_field'],
            $linked_field->field_options['custom_field'],
            array(
                'form_id'  => $linked_field->form_id,
                'field'    => $linked_field,
                'type'     => $linked_field->type,
                'truncate' => $atts['truncate'],
            )
        );
	}

	/**
	 * Get display value for linked field
	 * Called by self::get_linked_field_val
	 *
	 * @param false|stdClass $linked_field Linked field object of false.
	 * @param array          $atts         Atts.
	 * @param int            $value        Value.
	 * @param stdClass       $dynamic_field
	 *
	 * @return void
	 */
	private static function get_linked_field_display_val( $linked_field, $atts, &$value, $dynamic_field ) {
		if ( ! $linked_field ) {
			return;
		}

		if ( isset( $atts['show'] ) && ( (int) $atts['show'] == $linked_field->id || $atts['show'] == $linked_field->field_key ) ) {
			unset( $atts['show'] );
		}

		// If user ID field, show display name by default.
		if ( 'user_id' === $linked_field->type ) {
			unset( $atts['show'] );
		}

		if ( ! isset( $atts['show'] ) && isset( $atts['show_info'] ) ) {
			$atts['show'] = $atts['show_info'];
			// Prevent infinite recursion.
			unset( $atts['show_info'] );
		}

		if ( 'file' === $linked_field->type && ! isset( $atts['size'] ) ) {
			// Prevent using thumbnail size, causes a different URL and can't query from the database.
			$atts['size'] = 'full';
		}

		$value = FrmFieldsHelper::get_display_value( $value, $linked_field, $atts );

		if ( empty( $atts['show'] ) ) {
			$value = self::maybe_use_option_label( $value, $dynamic_field, $linked_field );
		}
	}

	/**
	 * This function is used for getting a dynamic field's separated option label.
	 * Check a dynamic field's target field options for an option match.
	 * If there is a match, the value is switched to the label value.
	 *
	 * @since 6.7
	 * @since 6.8 This was made public and moved from FrmProFieldsController.
	 *
	 * @param string   $value         The display value. This hasn't been updated yet to show a separated option label if one is defined.
	 * @param stdClass $current_field The dynamic field that we're getting a display value for.
	 * @param stdClass $data_field    The target field that the dynamic field gets its options through.
	 *
	 * @return false|string
	 */
	public static function maybe_use_option_label( $value, $current_field, $data_field ) {
		if ( empty( $data_field->options ) || empty( $data_field->field_options['separate_value'] ) ) {
			return $value;
		}

		/**
		 * This filter allows a developer to display the option value instead of the label.
		 * By default, a dynamic field that pulls data from a field with separated values
		 * will save the value but display the label.
		 *
		 * Using add_filter( 'frm_should_dynamic_field_use_option_label', '__return_false' );
		 * will change this behaviour so the value is always shown.
		 *
		 * @since 6.7
		 *
		 * @param bool     $should_use_option_label True by default.
		 * @param stdClass $current_field The dynamic field that we're getting a display value for.
		 */
		$should_use_option_label = (bool) apply_filters( 'frm_should_dynamic_field_use_option_label', true, $current_field );

		if ( ! $should_use_option_label ) {
			return $value;
		}

		$split  = explode( ', ', $value );
		$output = array();

		foreach ( $split as $meta_value ) {
			$match = false;

			foreach ( $data_field->options as $option ) {
				if ( isset( $option['value'] ) && isset( $option['label'] ) && $option['value'] === $value ) {
					$output[] = $option['label'];
					$match    = true;
					break;
				}
			}

			if ( ! $match ) {
				$output[] = $meta_value;
			}
		}

		return implode( ', ', $output );
	}

	/**
	 * @param mixed        $date
	 * @param false|string $date_format
	 *
	 * @return mixed
	 */
	public static function get_date( $date, $date_format = false ) {
		if ( ! $date ) {
			return $date;
		}

		if ( ! $date_format ) {
			$date_format = apply_filters( 'frm_date_format', get_option( 'date_format' ) );
		}

		return self::format_values_in_array( $date, $date_format, self::class . '::get_single_date' );
	}

	public static function get_single_date( $date, $date_format ) {
		if ( preg_match( '/^\d{1,2}\/\d{1,2}\/\d{2,4}$/', $date ) ) {
			$frmpro_settings = FrmProAppHelper::get_settings();
			$date            = FrmProAppHelper::convert_date( $date, $frmpro_settings->date_format, 'Y-m-d' );
		}

		if ( ! $date_format ) {
			// The default format for a default value date.
			if ( ! isset( $frmpro_settings ) ) {
				$frmpro_settings = FrmProAppHelper::get_settings();
			}

			$date_format = $frmpro_settings->date_format;
		}

		return date_i18n( $date_format, strtotime( $date ) );
	}

	/**
	 * @param string $callback
	 */
	public static function format_values_in_array( $value, $format, $callback ) {
		if ( ! $value ) {
			return $value;
		}

		if ( ! is_array( $value ) ) {
            return call_user_func_array( $callback, array( $value, $format ) );
        }

        $formatted_values = array();

        foreach ( $value as $v ) {
            $formatted_values[] = $v ? call_user_func_array( $callback, array( $v, $format ) ) : $v;
            unset( $v );
        }

        return $formatted_values;
	}

	/**
	 * @codeCoverageIgnore
	 *
	 * @param int    $user_id
	 * @param string $user_info
	 * @param array  $args
	 */
	public static function get_display_name( $user_id, $user_info = 'display_name', $args = array() ) {
		_deprecated_function( __FUNCTION__, '3.0', 'FrmFieldsHelper::get_user_display_name' );
		return FrmFieldsHelper::get_user_display_name( $user_id, $user_info, $args );
	}

	/**
	 * @param array    $subforms
	 * @param stdClass $field
	 *
	 * @return void
	 */
	public static function get_subform_ids( &$subforms, $field ) {
		if ( isset( $field->field_options['form_select'] ) && is_numeric( $field->field_options['form_select'] ) ) {
			$subforms[] = $field->field_options['form_select'];
		}
	}

	/**
	 * @param int|string   $form_id
	 * @param string       $value
	 * @param string       $include
	 * @param array|string $types
	 * @param array        $args
	 *
	 * @return void
	 */
	public static function get_field_options( $form_id, $value = '', $include = 'not', $types = array(), $args = array() ) {
		$inc_repeat = $args['inc_sub'] ?? 'exclude';
		$inc_embed  = $inc_repeat;
		$fields     = FrmField::get_all_for_form( (int) $form_id, '', $inc_embed, $inc_repeat );

		if ( ! $fields ) {
			return;
		}

		if ( ! $types ) {
			$types = array( 'break', 'divider', 'end_divider', 'data', 'file', 'captcha', 'form' );
		} elseif ( ! is_array( $types ) ) {
			$types      = explode( ',', $types );
			$temp_types = $types;

			foreach ( $temp_types as $k => $t ) {
				$types[ $k ] = trim( $types[ $k ], "'" );
				unset( $k, $t );
			}
			unset( $temp_types );
		}

		foreach ( $fields as $field ) {
			$stop = ( $include !== 'not' && ! in_array( $field->type, $types ) ) || ( $include === 'not' && in_array( $field->type, $types ) );

			if ( $stop || FrmProField::is_list_field( $field ) ) {
				continue;
			}
			unset( $stop );

			?>
			<option value="<?php echo (int) $field->id; ?>" <?php selected( $value, $field->id ); ?>><?php echo esc_html( FrmAppHelper::truncate( $field->name, 50 ) ); ?></option>
		<?php
		}
	}

	/**
	 * @param string $form_id
	 * @param string $target_id
	 * @param string $type
	 *
	 * @return void
	 */
	public static function get_shortcode_select( $form_id, $target_id = 'content', $type = 'all' ) {
		$field_list = array();
		$exclude    = FrmField::no_save_fields();

		if ( is_numeric( $form_id ) ) {
			if ( $type === 'field_opt' ) {
				$exclude[] = 'data';
				$exclude[] = 'checkbox';
			} elseif ( $type === 'calc' ) {
				$exclude[] = 'toggle';
			}

			$field_list = FrmField::get_all_for_form( $form_id, '', 'include' );
		}

		$linked_forms = array();
		?>
		<select class="frm_shortcode_select frm_insert_val" data-target="<?php echo esc_attr( $target_id ); ?>">
			<option value="">&mdash; <?php esc_html_e( 'Select a value to insert into the box below', 'formidable-pro' ); ?> &mdash;</option>
			<?php if ( $type !== 'field_opt' && $type !== 'calc' ) { ?>
				<option value="id"><?php esc_html_e( 'Entry ID', 'formidable' ); ?></option>
				<option value="key"><?php esc_html_e( 'Entry Key', 'formidable' ); ?></option>
				<option value="post_id"><?php esc_html_e( 'Post ID', 'formidable' ); ?></option>
				<option value="ip"><?php esc_html_e( 'User IP', 'formidable' ); ?></option>
				<option value="created-at"><?php esc_html_e( 'Entry creation date', 'formidable' ); ?></option>
				<option value="updated-at"><?php esc_html_e( 'Entry update date', 'formidable' ); ?></option>

				<optgroup label="<?php esc_attr_e( 'Form Fields', 'formidable-pro' ); ?>">
			<?php
			}

			if ( $field_list ) {
			foreach ( $field_list as $field ) {
					if ( in_array( $field->type, $exclude, true ) ) {
						continue;
						}

					if ( $type !== 'calc' && FrmProField::is_list_field( $field ) ) {
						continue;
						}

					$field_name = FrmAppHelper::truncate( $field->name, 60 );
					?>
				<option value="<?php echo esc_attr( $field->id ); ?>"><?php echo esc_html( $field_name ); ?> (<?php esc_html_e( 'ID', 'formidable' ); ?>)</option>
				<option value="<?php echo esc_attr( $field->field_key ); ?>"><?php echo esc_html( $field_name ); ?> (<?php esc_html_e( 'Key', 'formidable' ); ?>)</option>
					<?php if ( $field->type === 'file' && $type !== 'field_opt' && $type !== 'calc' ) { ?>
					<option class="frm_subopt" value="<?php echo esc_attr( $field->field_key ); ?> size=thumbnail">
						<?php esc_html_e( 'Thumbnail', 'formidable-pro' ); ?>
					</option>
					<option class="frm_subopt" value="<?php echo esc_attr( $field->field_key ); ?> size=medium">
						<?php esc_html_e( 'Medium', 'formidable' ); ?>
					</option>
					<option class="frm_subopt" value="<?php echo esc_attr( $field->field_key ); ?> size=large">
						<?php esc_html_e( 'Large', 'formidable' ); ?>
					</option>
					<option class="frm_subopt" value="<?php echo esc_attr( $field->field_key ); ?> size=full">
						<?php esc_html_e( 'Full Size', 'formidable-pro' ); ?>
					</option>
				<?php
						} elseif ( $field->type === 'data' && $type !== 'calc' ) {
						// Get all fields from linked form
						if ( isset( $field->field_options['form_select'] ) && is_numeric( $field->field_options['form_select'] ) ) {
							$linked_form = FrmDb::get_var( 'frm_fields', array( 'id' => $field->field_options['form_select'] ), 'form_id' );

							if ( ! in_array( $linked_form, $linked_forms ) ) {
								$linked_forms[] = $linked_form;
								$linked_fields  = FrmField::getAll(
									array(
										'fi.type not' => FrmField::no_save_fields(),
										'fi.form_id'  => (int) $linked_form,
									)
								);

								foreach ( $linked_fields as $linked_field ) {
								?>
					<option class="frm_subopt" value="<?php echo esc_attr( $field->id . ' show=' . $linked_field->id ); ?>"><?php echo esc_html( FrmAppHelper::truncate( $linked_field->name, 60 ) ); ?> (<?php esc_html_e( 'ID', 'formidable' ); ?>)</option>
					<option class="frm_subopt" value="<?php echo esc_attr( $field->field_key . ' show=' . $linked_field->field_key ); ?>"><?php echo esc_html( FrmAppHelper::truncate( $linked_field->name, 60 ) ); ?> (<?php esc_html_e( 'Key', 'formidable' ); ?>)</option>
						<?php
								}
							}
						}
						}
			}
			}

			if ( $type !== 'field_opt' && $type !== 'calc' ) {
			?>
			</optgroup>
			<optgroup label="<?php esc_attr_e( 'Helpers', 'formidable-pro' ); ?>">
				<option value="editlink"><?php esc_html_e( 'Admin link to edit the entry', 'formidable-pro' ); ?></option>
				<?php if ( $target_id === 'content' ) { ?>
				<option value="detaillink">
					<?php esc_html_e( 'Link to view single page if showing dynamic entries', 'formidable-pro' ); ?>
				</option>
				<?php
				}

				if ( $type !== 'email' ) {
				?>
				<option value="evenodd">
					<?php esc_html_e( 'Add a rotating \'even\' or \'odd\' class', 'formidable-pro' ); ?>
				</option>
				<?php } elseif ( $target_id === 'email_message' ) { ?>
				<option value="default-message">
					<?php esc_html_e( 'Default Email Message', 'formidable-pro' ); ?>
				</option>
				<?php } ?>
				<option value="siteurl"><?php esc_html_e( 'Site URL', 'formidable' ); ?></option>
				<option value="sitename"><?php esc_html_e( 'Site Name', 'formidable' ); ?></option>
			</optgroup>
			<?php } ?>
		</select>
	<?php
	}

	/**
	 * @param array $field_types
	 *
	 * @return array
	 */
	public static function modify_available_fields( $field_types ) {
		// TODO We only need this filter now when Stripe Lite isn't available.
		// Only show the credit card field when an add-on says so.
		$show_credit_card = apply_filters( 'frm_include_credit_card', false );

		if ( $show_credit_card ) {
			$field_types['credit_card']['icon'] = str_replace( ' frm_show_upgrade', '', $field_types['credit_card']['icon'] );
		}

		$field_options = FrmAppHelper::get_post_param( 'field_options', array(), 'wp_kses_post' );

		if ( ! empty( $field_options['is_range_slider'] ) ) {
			$field_types['range']['name'] = __( 'Range Slider', 'formidable-pro' );
		}

		return $field_types;
	}

	/**
	 * Check if a field is hidden through the frm_is_field_hidden hook
	 *
	 * @since 2.0.13
	 *
	 * @param bool $hidden
	 * @param object $field
	 * @param array $values
	 *
	 * @return bool Hidden.
	 */
	public static function route_to_is_field_hidden( $hidden, $field, $values ) {
		return self::is_field_hidden( $field, $values );
	}

	/**
	 * Check if a field is conditionally hidden
	 *
	 * @param object $field
	 * @param array $values
	 *
	 * @return bool
	 */
	public static function is_field_hidden( $field, $values ) {
		return ! self::is_field_conditionally_shown( $field, $values );
	}

	/**
	 * Check if a field is conditionally shown
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 * @param array $values
	 *
	 * @return bool
	 */
	private static function is_field_conditionally_shown( $field, $values ) {
		if ( ! self::field_needs_conditional_logic_checking( $field ) ) {
			return true;
		}

		self::prepare_conditional_logic( $field );

		$logic_outcomes = self::get_conditional_logic_outcomes( $field, $values );
		$visible        = self::is_field_visible_from_logic_outcomes( $field, $logic_outcomes );

		if ( $visible && ! self::dynamic_field_has_options( $field, $values ) ) {
			$visible = false;
		}

		/**
		 * Filters whether a field is conditionally shown
		 *
		 * @since 6.24
		 *
		 * @param bool $visible
		 * @param object $field
		 */
		return (bool) apply_filters( 'frm_field_is_conditionally_shown', $visible, $field );
	}

	/**
	 * Check if a field needs to have the conditional logic checked
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 *
	 * @return bool
	 */
	private static function field_needs_conditional_logic_checking( $field ) {
    	return $field->type !== 'user_id' && $field->type !== 'hidden' && ! empty( $field->field_options['hide_field'] );
	}

	/**
	 * Prepare conditional logic settings
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 */
	private static function prepare_conditional_logic( &$field ) {
		$field->field_options['hide_field'] = (array) $field->field_options['hide_field'];

		if ( ! empty( $field->field_options['hide_field_cond'] ) ) {
			$field->field_options['hide_field_cond'] = (array) $field->field_options['hide_field_cond'];
		} else {
			$field->field_options['hide_field_cond'] = array( '==' );
		}

		$field->field_options['hide_opt'] = (array) $field->field_options['hide_opt'];
	}

	/**
	 * Get the conditional logic outcomes for a field
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 * @param array $values
	 *
	 * @return array
	 */
	private static function get_conditional_logic_outcomes( $field, $values ) {
		$logic_outcomes = array();

		foreach ( $field->field_options['hide_field'] as $logic_key => $logic_field ) {
			if ( ! isset( $field->field_options['hide_field_cond'][ $logic_key ] ) ) {
				continue;
			}

			$observed_value = self::get_observed_logic_value( $field, $values, $logic_field, $logic_key );
			$logic_value    = self::get_conditional_logic_value( $field, $logic_key, $observed_value );

			list( $base_logic_field_id, ) = FrmProConditionalLogicController::get_logic_field_id_and_sub_key( $logic_field );

			if ( 'date' === FrmField::get_type( $base_logic_field_id ) ) {
				$observed_value = self::prepare_date_value( $observed_value );
				$logic_value    = self::prepare_date_value( $logic_value );
			}

			$operator         = $field->field_options['hide_field_cond'][ $logic_key ];
			$logic_outcomes[] = FrmFieldsHelper::value_meets_condition( $observed_value, $operator, $logic_value );
		}

		return $logic_outcomes;
	}

	/**
	 * Change date values to Y-m-d format so we can compare them consistently.
	 *
	 * @since 6.21
	 *
	 * @param string $value
	 *
	 * @return string
	 */
	private static function prepare_date_value( $value ) {
		$settings = FrmProAppHelper::get_settings();
		$format   = $settings->date_format;

		if ( 'Y-m-d' === $format ) {
			return $value;
		}

		$possible_separators = array( '/', '.', '-' );
		$separator           = false;

		foreach ( $possible_separators as $sep ) {
			if ( str_contains( $format, $sep ) ) {
				$separator = $sep;
				break;
			}
		}

		if ( false === $separator ) {
			return $value;
		}

		$split = explode( $separator, $value );

		if ( 3 !== count( $split ) ) {
			return $value;
		}

		switch ( $format ) {
			case 'Y/m/d':
				$year_part  = $split[0];
				$month_part = $split[1];
				$day_part   = $split[2];
				break;
			case 'n/j/Y':
			case 'm/d/Y':
				$month_part = $split[0];
				$day_part   = $split[1];
				$year_part  = $split[2];
				break;
			case 'd/m/Y':
			case 'd.m.Y':
			case 'j/m/Y':
			case 'j/n/Y':
			case 'j-m-Y':
			default:
				$day_part   = $split[0];
				$month_part = $split[1];
				$year_part  = $split[2];
				break;
		}

		if ( strlen( $year_part ) !== 4 ) {
			return $value;
		}

		if ( strlen( $month_part ) < 2 ) {
			$month_part = '0' . $month_part;
		}

		if ( strlen( $day_part ) < 2 ) {
			$day_part = '0' . $day_part;
		}

		return $year_part . '-' . $month_part . '-' . $day_part;
	}

	/**
	 * Check if a field is conditionally shown based on the conditional logic outcomes
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 * @param array $logic_outcomes
	 *
	 * @return bool
	 */
	private static function is_field_visible_from_logic_outcomes( $field, $logic_outcomes ) {
		$action  = $field->field_options['show_hide'] ?? 'show';
		$any_all = $field->field_options['any_all'] ?? 'any';
		$visible = 'show' === $action;

		self::check_logic_outcomes( $any_all, $logic_outcomes, $visible );

		return $visible;
	}

	/**
	 * Check if a Dynamic field has options at validation
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 * @param array $values
	 *
	 * @return bool
	 */
	private static function dynamic_field_has_options( $field, $values ) {
		$has_options = true;

		if ( $field->type !== 'data' || $field->field_options['data_type'] === 'data' ) {
			return $has_options;
		}

		foreach ( $field->field_options['hide_field'] as $logic_field_id ) {
			if ( ! self::is_dynamic_field( $logic_field_id ) ) {
				continue;
			}

			if ( ! self::logic_field_retrieves_options( $field, $values, $logic_field_id ) ) {
				$has_options = false;
				break;
			}
		}

		$args = array(
			'field'  => $field,
			'values' => $values,
		);

		return apply_filters( 'frm_dynamic_field_has_options', $has_options, $args );
	}

	/**
	 * Get the value for a single row of conditional logic
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 * @param int $key
	 * @param array|string $observed_value
	 *
	 * @return array|string
	 */
	private static function get_conditional_logic_value( $field, $key, $observed_value ) {
		$logic_value = $field->field_options['hide_opt'][ $key ];
		$logic_value = self::prepare_logic_setting( $logic_value, $field );
		self::get_logic_value_for_dynamic_field( $field, $key, $observed_value, $logic_value );

		return $logic_value;
	}

	/**
	 * Returns true if loading the first page of a multi page form for the first time.
	 *
	 * @since 7.0
	 *
	 * @param object $field
	 *
	 * @return bool
	 */
	private static function is_initial_page_load( $field ) {
		global $frm_vars;

		if ( isset( $_POST['frm_next_page'] ) || isset( $_POST[ 'frm_page_order_' . $field->form_id ] ) ) {
			// $_POST already has pagination info in it, so this isn't the initial page load.
			return false;
		}

		return isset( $frm_vars['next_page'][ $field->form_id ] );
	}

	/**
	 * @since 7.0
	 *
	 * @param int $field_order
	 * @param int $form_id
	 *
	 * @return array
	 */
	private static function get_default_values_for_fields_on_first_page( $field_order, $form_id ) {
		static $memoized = array();

		if ( isset( $memoized[ $form_id ][ $field_order ] ) ) {
			return $memoized[ $form_id ][ $field_order ];
		}

		$result = FrmDb::get_results(
			'frm_fields',
			array(
				'field_order <-' => $field_order,
				'form_id'        => $form_id,
			),
			'id,type,default_value'
		);

		$default_values = array();

		foreach ( $result as $row ) {
			$default_value = $row->default_value;
			// Only types with array_allowed (checkbox, name, address, etc.) store this JSON/serialized.
			FrmFieldsHelper::prepare_field_value( $default_value, $row->type );
			$default_values[ $row->id ] = $default_value;
		}

		$memoized[ $form_id ][ $field_order ] = $default_values;

		return $default_values;
	}

	/**
	 * Returns the default value for a field.
	 *
	 * @since 7.0
	 *
	 * @param int $logic_field_id
	 * @param int $field_order
	 * @param int $form_id
	 *
	 * @return int|string
	 */
	private static function get_default_value_for_field( $logic_field_id, $field_order, $form_id ) {
		$default_values = self::get_default_values_for_fields_on_first_page( $field_order, $form_id );
		return $default_values[ $logic_field_id ] ?? '';
	}

	/**
	 * Restricted to page break fields, since a default value is only meaningful for
	 * deciding whether to skip a page. Other fields that check their own hidden state
	 * (total, range, summary, entry validation, etc.) keep their existing behavior,
	 * so this doesn't change what they consider hidden on the first page load.
	 *
	 * @since 7.0
	 *
	 * @param array  $values
	 * @param int    $logic_field_id
	 * @param object $field
	 *
	 * @return bool
	 */
	private static function should_set_default_value( $values, $logic_field_id, $field ) {
		return isset( $field->type ) && 'break' === $field->type && ! isset( $values['item_meta'][ $logic_field_id ] ) && self::is_initial_page_load( $field );
	}

	/**
	 * Get the observed value from a logic field.
	 *
	 * @since 2.02.03
	 *
	 * @param object    $field
	 * @param array     $values
	 * @param int       $logic_field_id
	 * @param false|int $logic_key
	 *
	 * @return array|string
	 */
	private static function get_observed_logic_value( $field, $values, $logic_field_id, $logic_key = false ) {
		$observed_value = '';

		list( $base_field_id, $sub_field_key ) = FrmProConditionalLogicController::get_logic_field_id_and_sub_key( $logic_field_id );

		if ( self::should_set_default_value( $values, $base_field_id, $field ) ) {
			$values['item_meta'][ $base_field_id ] = self::get_default_value_for_field( $base_field_id, $field->field_order, $field->form_id );
		}

		if ( isset( $values['item_meta'][ $base_field_id ] ) ) {
			// Logic field is not repeating/embedded
			$observed_value = $values['item_meta'][ $base_field_id ];
		} elseif ( isset( $field->temp_id ) && $field->id != $field->temp_id ) {
			// Logic field is repeating/embedded
			$id_parts = explode( '-', $field->temp_id );

			if ( isset( $_POST['item_meta'][ $id_parts[1] ][ $id_parts[2] ] ) && isset( $_POST['item_meta'][ $id_parts[1] ][ $id_parts[2] ][ $base_field_id ] ) ) {
				$observed_value = wp_unslash( $_POST['item_meta'][ $id_parts[1] ][ $id_parts[2] ][ $base_field_id ] );
			}
		} elseif ( false !== $logic_key && ! empty( $field->field_options['in_section'] ) ) {
			$repeater_id = $field->field_options['in_section'];

			if ( ! empty( $values['item_meta'][ $repeater_id ] ) ) {
				$repeater_meta = $values['item_meta'][ $repeater_id ];

				if ( ! empty( $repeater_meta[ $logic_key ][ $base_field_id ] ) ) {
					$observed_value = $repeater_meta[ $logic_key ][ $base_field_id ];
				}
			} else {
				// Handle an embedded field inside of a section.
				$embed_field_id = self::check_values_for_embed_field_id( $values, $field->form_id );

				if ( -1 !== $embed_field_id && isset( $values['item_meta'][ $embed_field_id ][ $logic_key ][ $base_field_id ] ) ) {
					$observed_value = $values['item_meta'][ $embed_field_id ][ $logic_key ][ $base_field_id ];
				}
			}
		}

		if ( false !== $sub_field_key ) {
			// Match against a single sub field's value (e.g. Address's State, Name's Last) instead of the whole combo field.
			return is_array( $observed_value ) && isset( $observed_value[ $sub_field_key ] ) ? $observed_value[ $sub_field_key ] : '';
		}

		// Flatten a name field observed value for conditional logic.
		if ( is_array( $observed_value ) && 'name' === FrmField::get_type( $base_field_id ) ) {
			return implode( ' ', $observed_value );
		}

		return $observed_value;
	}

	/**
	 * @param array      $values
	 * @param int|string $form_id
	 *
	 * @return int
	 */
	private static function check_values_for_embed_field_id( $values, $form_id ) {
		if ( isset( $values['item_meta'] ) && is_array( $values['item_meta'] ) ) {
			foreach ( $values['item_meta'] as $field_id => $field_data ) {
				if ( ! empty( $field_data['form'] ) && (int) $form_id === (int) $field_data['form'] ) {
					return $field_id;
				}
			}
		}
		return -1;
	}

	/**
	 * Get the value for a single row of conditional logic when field and parent is Dynamic
	 *
	 * @since 2.02.03
	 *
	 * @param object       $field
	 * @param int          $key
	 * @param array|string $observed_value
	 * @param string       $logic_value
	 */
	private static function get_logic_value_for_dynamic_field( $field, $key, $observed_value, &$logic_value ) {
		if ( $field->type !== 'data' || ! self::is_dynamic_field( $field->field_options['hide_field'][ $key ] ) ) {
			return;
		}

		// If logic is "Dynamic field is equal to anything"
		if ( ! empty( $field->field_options['hide_opt'][ $key ] ) ) {
			return;
		}

		$logic_value = $observed_value;

		// If no value is set in parent field, make sure logic doesn't return true
		if ( ! $observed_value && $field->field_options['hide_field_cond'][ $key ] === '==' ) {
			$logic_value = 'anything';
		}
	}

	/**
	 * Check whether a field is visible or not from conditional logic outcomes
	 *
	 * @since 2.02.03
	 *
	 * @param string $any_all
	 * @param array $logic_outcomes
	 * @param bool $visible
	 */
	private static function check_logic_outcomes( $any_all, $logic_outcomes, &$visible ) {
		if ( 'any' === $any_all ) {
			if ( ! in_array( true, $logic_outcomes ) ) {
				$visible = ! $visible;
			}
		} elseif ( in_array( false, $logic_outcomes ) ) {
				$visible = ! $visible;
		}
	}

	/**
	 * Check if a field is Dynamic
	 *
	 * @since 2.02.03
	 *
	 * @param int $field_id
	 *
	 * @return bool
	 */
	private static function is_dynamic_field( $field_id ) {
		list( $base_field_id, ) = FrmProConditionalLogicController::get_logic_field_id_and_sub_key( $field_id );
		return FrmField::get_type( $base_field_id ) === 'data';
	}

	/**
	 * Check if a Dynamic logic field retrieves options for the child
	 *
	 * @since 2.02.03
	 *
	 * @param object $field
	 * @param array $values
	 * @param int $logic_field_id
	 *
	 * @return bool
	 */
	private static function logic_field_retrieves_options( $field, $values, $logic_field_id ) {
		$observed_value = self::get_observed_logic_value( $field, $values, $logic_field_id );

		if ( ! $observed_value ) {
			return false;
		}

		if ( ! is_array( $observed_value ) ) {
			$observed_value = explode( ',', $observed_value );
		}

		$linked_field_id = $field->field_options['form_select'] ?? '';

		if ( $linked_field_id === 'taxonomy' ) {
			// Category fields
			return self::does_parent_taxonomy_have_children( $field->field_options['taxonomy'], $observed_value );
		}

		// Standard dynamic fields
		$linked_field  = FrmField::getOne( $linked_field_id );
		$field_options = array();
		FrmProEntryMetaHelper::meta_through_join( $logic_field_id, $linked_field, $observed_value, $field, $field_options );

		return ! empty( $field_options );
	}

	/**
	 * Checks if child categories exist for a given taxonomy and parent taxonomy IDs
	 *
	 * @since 2.02.03
	 *
	 * @param string $taxonomy
	 * @param array $parent_taxonomy_ids
	 *
	 * @return array
	 */
	private static function does_parent_taxonomy_have_children( $taxonomy, $parent_taxonomy_ids ) {
		$has_children = false;

		if ( ! $parent_taxonomy_ids ) {
			return $has_children;
		}

		$child_categories = array();

		foreach ( $parent_taxonomy_ids as $parent_id ) {
			$args             = array(
				'parent'     => (int) $parent_id,
				'taxonomy'   => $taxonomy,
				'hide_empty' => 0,
			);
			$new_cats         = get_categories( $args );
			$child_categories = array_merge( $new_cats, $child_categories );

			// Stop as soon as there are options
			if ( $child_categories ) {
				$has_children = true;
				break;
			}
		}

		return $has_children;
	}

	/**
	 * @since 4.04.02
	 *
	 * @param array|object $field
	 * @param array|object|null $parent - The field array of the parent field.
	 *
	 * @return bool
	 */
	public static function is_on_skipped_page( $field, $parent = null ) {
		$field_type = FrmField::get_field_type( $field );

		if ( 'hidden' !== $field_type ) {
			// The field is on the current page.
			return false;
		}

		$form_id        = FrmAppHelper::get_param( 'form_id', 0, 'post', 'absint' );
		$parent         = $parent ?? $field;
		$field_order    = is_array( $parent ) ? $parent['field_order'] : $parent->field_order;
		$parent_form_id = is_array( $parent ) ? $parent['form_id'] : $parent->form_id;

		if ( ! $form_id || $form_id != $parent_form_id ) {
			// The page has not yet been turned for this form.
			return false;
		}

		$page_breaks = FrmProFormsHelper::has_field( 'break', $parent_form_id, false );

		if ( ! $page_breaks ) {
			return false;
		}

		$field_page = false;

		foreach ( $page_breaks as $break ) {
			if ( $break->field_order > $field_order ) {
				break;
			}

			// $field belongs to the last found page before the field.
			$field_page = $break;
		}

		if ( ! $field_page ) {
			return false;
		}

		return self::is_field_hidden( $field_page, wp_unslash( $_POST ) );
	}

	/**
	 * @param array|object $field
	 *
	 * @return bool
	 */
	public static function is_field_visible_to_user( $field ) {
		$visible    = true;
        $visibility = FrmField::get_option( $field, 'admin_only' );

		if ( $visibility ) {
			$visible = self::user_has_permission( $visibility );
		}

		/**
		 * Filters whether a field is visible to the user.
		 * This is used in the test mode add-on, for the Preview as role feature.
		 *
		 * @since 6.23
		 *
		 * @param bool         $visible Whether the field is visible to the user.
		 * @param array|object $field   The field object.
		 */
		return apply_filters( 'frm_field_visible_to_user', $visible, $field );
	}

	/**
	 * @since 3.0
	 *
	 * @param array|string $visibility
	 *
	 * @return bool
	 */
	public static function user_has_permission( $visibility ) {
		if ( ! is_array( $visibility ) ) {
			return FrmAppHelper::user_has_permission( $visibility );
		}

		foreach ( $visibility as $role ) {
			if ( 'loggedout' === $role ) {
				if ( ! is_user_logged_in() ) {
					return true;
				}
			} elseif ( '' === $role ) {
				return true;
			} elseif ( FrmAppHelper::current_user_can( $role ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Loop through value in hidden field and display arrays in separate fields
	 *
	 * @since 2.0
	 *
	 * @param array             $field
	 * @param string            $field_name
	 * @param array|string      $checked
	 * @param false|int|string  $opt_key
	 *
	 * @return void
	 */
	public static function insert_hidden_fields( $field, $field_name, $checked, $opt_key = false ) {
		if ( 'virtual' === $field['original_type'] ) {
			// Make sure the virtual field is never included as a hidden field.
			return;
		}

		if ( FrmProNestedFormsController::is_hidden_nested_form_field( $field ) ) {
			FrmProNestedFormsController::insert_hidden_nested_form( $field, $field_name, $checked );
			return;
		}

		if ( isset( $field['original_type'] ) && $field['original_type'] === 'html' ) {
			return;
		}

		if ( is_array( $checked ) ) {
			foreach ( $checked as $k => $checked2 ) {
				$checked2 = apply_filters( 'frm_hidden_value', $checked2, $field );
				self::insert_hidden_fields( $field, $field_name . '[' . $k . ']', $checked2, $k );
				unset( $k, $checked2 );
			}

			return;
		}

		$html_id = $field['html_id'];
		self::hidden_html_id( $field, $opt_key, $html_id );
		// 'opt_key' is used by e.g. product field of checkbox type that's not in a repeater/embedded form
		$field['opt_key'] = $opt_key;
		$html_atts        = array(
			'type'  => 'hidden',
			'name'  => $field_name,
			'id'    => $html_id,
			'value' => $checked,
		);
		?>
		<input <?php FrmAppHelper::array_to_html_params( $html_atts, true ); ?> <?php do_action( 'frm_field_input_html', $field ); ?> />
		<?php
		self::insert_extra_hidden_fields( $field, $opt_key );
	}

	/**
	 * The html id needs to be the same as when the fields are displayed normally
	 * so the calculations will work correctly
	 *
	 * @since 2.0.5
	 *
	 * @param array $field
	 * @param bool|string $opt_key
	 * @param string $html_id
	 */
	private static function hidden_html_id( $field, $opt_key, &$html_id ) {
		$html_id_end = $opt_key;

		if ( $opt_key === false && isset( $field['original_type'] ) && in_array( $field['original_type'], FrmProFormsHelper::radio_similar_field_types(), true ) ) {
			$html_id_end = 0;
		}

		if ( $html_id_end !== false ) {
			$html_id .= '-' . $html_id_end;
		}
	}

	/**
	 * Add confirmation and "other" hidden fields to help carry all data throughout the form
	 * Note: This doesn't control the HTML for fields in repeating sections
	 *
	 * @since 2.0
	 *
	 * @param array $field
	 * @param bool|string $opt_key
	 */
	public static function insert_extra_hidden_fields( $field, $opt_key = false ) {
		// If we're dealing with a repeating section, hidden fields are already taken care of
		if ( isset( $field['original_type'] ) && $field['original_type'] === 'divider' ) {
			return;
		}

		$add_currency_to_global = FrmField::get_option( $field, 'is_currency' ) || FrmProCurrencyHelper::is_currency_format( FrmField::get_option( $field, 'format' ) );

		if ( ! $add_currency_to_global ) {
			$add_currency_to_global = isset( $field['original_type'] ) && in_array( $field['original_type'], array( 'product', 'total' ), true );
		}

		if ( $add_currency_to_global ) {
			FrmProCurrencyHelper::add_currency_to_global( $field['form_id'] );
		}

		// If confirmation field on previous page, store value in hidden field
		if ( FrmField::is_option_true( $field, 'conf_field' ) && isset( $_POST['item_meta'][ 'conf_' . $field['id'] ] ) ) {
			self::insert_hidden_confirmation_fields( $field );
		// If Other field on previous page, store value in hidden field
		} elseif ( FrmField::is_option_true( $field, 'other' ) && isset( $_POST['item_meta']['other'][ $field['id'] ] ) ) {
			self::insert_hidden_other_fields( $field, $opt_key );
		}

		/**
		 * Allow other add-ons (as well as custom code) to insert extra hidden fields.
		 *
		 * @since 6.26
		 *
		 * @param array $field
		 */
		do_action( 'frm_insert_extra_hidden_fields', $field );
	}

	/**
	 * @since 6.28
	 *
	 * @param array|object $field
	 *
	 * @return bool
	 */
	public static function should_show_remaining_choices( $field ) {
		return FrmField::is_option_true( $field, 'show_remaining_quantity' );
	}

	/**
	 * Insert hidden confirmation fields
	 *
	 * @since 2.0.8
	 *
	 * @param array $field
	 */
	private static function insert_hidden_confirmation_fields( $field ) {
		if ( ! empty( $field['reset_value'] ) ) {
			$value = '';
		} else {
			$item_meta = FrmAppHelper::get_post_param( 'item_meta', array() );
			$value     = $item_meta[ 'conf_' . $field['id'] ] ?? '';
		}

		include FrmProAppHelper::plugin_path() . '/classes/views/frmpro-fields/front-end/hidden-conf-field.php';
	}

	/**
	 * Insert hidden Other fields
	 *
	 * @since 2.0.8
	 *
	 * @param array $field
	 * @param bool|int|string $opt_key
	 */
	private static function insert_hidden_other_fields( $field, $opt_key ) {
		$other_id = FrmFieldsHelper::get_other_field_html_id( $field['original_type'], $field['html_id'], $opt_key );

		// Checkbox and multi-select dropdown fields
		$item_meta = FrmAppHelper::get_post_param( 'item_meta', array() );

		if ( $opt_key && ! is_numeric( $opt_key ) && ! empty( $item_meta['other'][ $field['id'] ][ $opt_key ] ) ) {
			$posted_val = wp_unslash( $item_meta['other'][ $field['id'] ][ $opt_key ] );
			?>
			<input type="hidden" name="item_meta[other][<?php echo esc_attr( $field['id'] ); ?>][<?php echo esc_attr( $opt_key ); ?>]" id="<?php echo esc_attr( $other_id ); ?>" value="<?php echo esc_attr( $posted_val ); ?>" />
			<?php

		// Radio fields and regular dropdowns
		} elseif ( ! is_array( $field['value'] ) && ! is_array( $item_meta['other'][ $field['id'] ] ) ) {
			$posted_val = wp_unslash( $item_meta['other'][ $field['id'] ] );
			?>
			<input type="hidden" name="item_meta[other][<?php echo esc_attr( $field['id'] ); ?>]" id="<?php echo esc_attr( $other_id ); ?>" value="<?php echo esc_attr( $posted_val ); ?>" />
			<?php
		}
	}

	/**
	 * Check if the field is in a child form and return the parent form id
	 *
	 * @since 2.0
	 *
	 * @param stdClass $field
	 *
	 * @return int The ID of the form or parent form
	 */
	public static function get_parent_form_id( $field ) {
		$form = FrmForm::getOne( $field->form_id );

		// Include the parent form ids if this is a child field

		if ( ! empty( $form->parent_form_id ) ) {
            return $form->parent_form_id;
		}

        return $field->form_id;
	}

	/**
	 * Get the parent section field
	 *
	 * @since 2.0
	 *
	 * @param stdClass   $field
	 * @param int|string $form_id
	 *
	 * @return false|object The section field object if there is one
	 */
	public static function get_parent_section( $field, $form_id = 0 ) {
		if ( ! $form_id ) {
			$form_id = $field->form_id;
		}

		$query = array(
			'fi.field_order <' => $field->field_order - 1,
			'fi.form_id'       => $form_id,
			'fi.type'          => array( 'divider', 'end_divider' ),
		);

		return FrmField::getAll( $query, 'field_order', 1 );
	}

	/**
	 * Checks if given field should be on the current page.
	 *
	 * @since 5.4.1 The parameter can be field object, field array (after setup), field ID or field key.
	 *
	 * @param array|int|object|string $field Field object, field array, ID or field key.
	 *
	 * @return bool
	 */
	public static function field_on_current_page( $field ) {
		global $frm_vars;
		$current = true;
        $prev    = 0;
		$next    = 999999;

		if ( is_array( $field ) ) {
			$field = (object) $field;
		} elseif ( ! is_object( $field ) ) {
			$field = FrmField::getOne( $field );
		}

		if ( $frm_vars['prev_page'] && is_array( $frm_vars['prev_page'] ) && isset( $frm_vars['prev_page'][ $field->form_id ] ) ) {
			$prev = $frm_vars['prev_page'][ $field->form_id ];
		}

		if ( $frm_vars['next_page'] && is_array( $frm_vars['next_page'] ) && isset( $frm_vars['next_page'][ $field->form_id ] ) ) {
			$next = $frm_vars['next_page'][ $field->form_id ];

			if ( is_object( $next ) ) {
				$next = $next->field_order;
			}
		}

		if ( $field->field_order < $prev || $field->field_order > $next ) {
			$current = false;
		}

		return apply_filters( 'frm_show_field_on_page', $current, $field );
	}

	public static function switch_field_ids( $val ) {
		// For reverse compatibility
		return FrmFieldsHelper::switch_field_ids( $val );
	}

	/**
	 * @return array
	 */
	public static function get_table_options( $field_options ) {
		$columns = array();
		$rows    = array();

		if ( is_array( $field_options ) ) {
			foreach ( $field_options as $opt_key => $opt ) {
				switch ( substr( $opt_key, 0, 3 ) ) {
					case 'col':
						$columns[ $opt_key ] = $opt;
						break;
					case 'row':
						$rows[ $opt_key ] = $opt;
				}
			}
		}

		return array( $columns, $rows );
	}

	/**
	 * @param mixed $field_options
	 * @param array $columns
	 * @param array $rows
	 *
	 * @return array
	 */
	public static function set_table_options( $field_options, $columns, $rows ) {
		if ( is_array( $field_options ) ) {
			foreach ( $field_options as $opt_key => $opt ) {
				if ( str_starts_with( $opt_key, 'col' ) || str_starts_with( $opt_key, 'row' ) ) {
					unset( $field_options[ $opt_key ] );
				}
			}
			unset( $opt_key, $opt );
		} else {
			$field_options = array();
		}

		foreach ( $columns as $opt_key => $opt ) {
			$field_options[ $opt_key ] = $opt;
		}

		foreach ( $rows as $opt_key => $opt ) {
			$field_options[ $opt_key ] = $opt;
		}

		return $field_options;
	}

	/**
	 * Allow text values to autopopulate Dynamic fields
	 *
	 * @since 2.0.15
	 *
	 * @param array|string $value
	 * @param object $field
	 * @param bool $dynamic_default
	 * @param bool $allow_array
	 *
	 * @return array|string Value.
	 */
	public static function get_dynamic_field_default_value( $value, $field, $dynamic_default = true, $allow_array = false ) {
		// If field is Dynamic dropdown, checkbox, or radio field and the default value is not an entry ID
		$has_input      = $field->type === 'data' && isset( $field->field_options['data_type'] ) && $field->field_options['data_type'] !== 'data';
		$has_value      = $has_input && $value && ! is_numeric( $value );
		$is_placeholder = $value === FrmField::get_option( $field, 'placeholder' );

		if ( ! $has_value || $is_placeholder ) {
			return $value;
		}

		if ( ! is_array( $value ) ) {
            return self::get_id_for_dynamic_field( $field, $value );
        }

        $new_values = array();

        foreach ( $value as $val ) {
            if ( is_array( $val ) ) {
                // It shouldn't be possible for $val to be an array.
                // For now, if an array value is found, skip it.
                continue;
            }

            $val = trim( $val );

            if ( $val && ! is_numeric( $val ) ) {
                $new_values[] = self::get_id_for_dynamic_field( $field, $val );
            } elseif ( is_numeric( $val ) ) {
                $new_values[] = $val;
            }
        }

        return $new_values;
	}

	/**
	 * Get the entry ID or category ID to autopopulate a Dynamic field
	 *
	 * @since 2.0.15
	 *
	 * @param object $field
	 * @param string $value
	 *
	 * @return int Value.
	 */
	private static function get_id_for_dynamic_field( $field, $value ) {
		if ( isset( $field->field_options['post_field'] ) && $field->field_options['post_field'] === 'post_category' ) {
			// Category fields
			return FrmProField::get_cat_id_from_text( $value );
		}

		// Non post fields
		return FrmProField::get_dynamic_field_entry_id( $field->field_options['form_select'], $value, '=' );
	}

	/**
	 * Get the classes for a field div
	 *
	 * @since 2.02.05
	 *
	 * @param string $classes
	 * @param array $field
	 * @param array $args (should include field_id item)
	 *
	 * @return string
	 */
	public static function get_field_div_classes( $classes, $field, $args ) {
		// Add a class for repeating/embedded fields
		if ( $field['id'] != $args['field_id'] ) {
			$classes .= ' frm_field_' . $field['id'] . '_container';
		}

		// Add classes to inline confirmation field (if it doesn't already have classes set)
		if ( isset( $field['conf_field'] ) && $field['conf_field'] === 'inline' && ! $field['classes'] ) {
			$classes .= ' frm_first frm_half';
		}

		// Add class if field includes other option
		if ( isset( $field['other'] ) && true == $field['other'] ) {
			$classes .= ' frm_other_container';
		}

		// Hide the end date field if date range is enabled and display is inline
		if ( FrmField::get_option( $field, 'is_range_end_field' ) && FrmField::get_option( $field, 'display_inline' ) ) {
			$classes .= ' frm_hidden';
		}

		return $classes;
	}

	/**
	 * Checks if a field is on a higher, lower or the current page.
	 *
	 * @param array|int|object|string $field The field as an array, stdClass object or its ID.
	 * @param string           $where Can be 'higher', 'lower' or 'current'.
	 *
	 * @return bool
	 */
	public static function field_on_page( $field, $where ) {
		global $frm_vars;

		$prev = 0;
		$next = 9999;

		if ( is_numeric( $field ) ) {
			$field = FrmField::getOne( $field );
		}

		if ( is_array( $field ) ) {
			$form_id     = $field['form_id'];
			$field_order = $field['field_order'];
		} elseif ( is_object( $field ) ) {
			$form_id     = $field->form_id;
			$field_order = $field->field_order;
		}

		if ( $frm_vars['prev_page'] && is_array( $frm_vars['prev_page'] ) && isset( $frm_vars['prev_page'][ $form_id ] ) ) {
			$prev = $frm_vars['prev_page'][ $form_id ];
		}

		if ( $frm_vars['next_page'] && is_array( $frm_vars['next_page'] ) && isset( $frm_vars['next_page'][ $form_id ] ) ) {
			$next = $frm_vars['next_page'][ $form_id ];

			if ( is_object( $next ) ) {
				$next = $next->field_order;
			}
		}

		$field_order = (int) $field_order;

		if ( 'higher' === $where ) {
			return $field_order >= $next;
		}

		if ( 'lower' === $where ) {
			return $field_order <= $prev;
		}

		if ( 'current' === $where ) {
			return $field_order >= $prev && $field_order <= $next;
		}

		return false;
	}

	/**
	 * @since 5.4.1
	 * @since 7.0 This uses the Lite implementation when Lite is up to date.
	 *
	 * @return array<string,string>
	 */
	public static function get_autocomplete_options() {
		if ( is_callable( 'FrmFieldsHelper::get_autocomplete_options' ) ) {
			return FrmFieldsHelper::get_autocomplete_options();
		}

		return array(
			'on'                   => __( 'On', 'formidable' ),
			'off'                  => __( 'Off', 'formidable' ),
			'additional-name'      => __( 'Additional name', 'formidable' ),
			'bday'                 => __( 'Birthday', 'formidable' ),
			'bday-day'             => __( 'Birthday day', 'formidable' ),
			'bday-month'           => __( 'Birthday month', 'formidable' ),
			'bday-year'            => __( 'Birthday year', 'formidable' ),
			'country'              => __( 'Country', 'formidable' ),
			'country-name'         => __( 'Country name', 'formidable' ),
			'current-password'     => __( 'Current password', 'formidable' ),
			'email'                => __( 'Email', 'formidable' ),
			'family-name'          => __( 'Family name', 'formidable' ),
			'given-name'           => __( 'Given name', 'formidable' ),
			'honorific-prefix'     => __( 'Honorific prefix', 'formidable' ),
			'honorific-suffix'     => __( 'Honorific suffix', 'formidable' ),
			'impp'                 => __( 'IMPP', 'formidable' ),
			'language'             => __( 'Language', 'formidable' ),
			'name'                 => __( 'Name', 'formidable' ),
			'new-password'         => __( 'New password', 'formidable' ),
			'one-time-code'        => __( 'One time code', 'formidable' ),
			'organization'         => __( 'Organization', 'formidable' ),
			'organization-title'   => __( 'Organization title', 'formidable' ),
			'photo'                => __( 'Photo', 'formidable' ),
			'postal-code'          => __( 'Postal Code', 'formidable' ),
			'sex'                  => __( 'Sex', 'formidable' ),
			'street-address'       => __( 'Street address', 'formidable' ),
			'tel'                  => __( 'Tel', 'formidable' ),
			'tel-area-code'        => __( 'Tel area code', 'formidable' ),
			'tel-country-code'     => __( 'Tel country code', 'formidable' ),
			'tel-extension'        => __( 'Tel extension', 'formidable' ),
			'tel-local'            => __( 'Tel local', 'formidable' ),
			'tel-national'         => __( 'Tel national', 'formidable' ),
			'transaction-amount'   => __( 'Transaction amount', 'formidable' ),
			'transaction-currency' => __( 'Transaction currency', 'formidable' ),
			'url'                  => __( 'URL', 'formidable' ),
			'username'             => __( 'Username', 'formidable' ),
		);
	}

	/**
	 * Use the frm-datepicker class. We style this class instead of ui-datepicker to prevent conflicts.
	 *
	 * @since 5.5
	 * @since 6.19 This no longer conditionally returns ui-datepicker if the Datepicker add-on is not up to date.
	 *
	 * @return string
	 */
	public static function get_datepicker_class() {
		return 'frm-datepicker';
	}

	/**
	 * To avoid issues with regex limits, remove any field keys that aren't found in the content ahead of time for large field sets.
	 *
	 * @since 5.5.3
	 *
	 * @param string $content
	 * @param array  $keys
	 *
	 * @return array
	 */
	public static function filter_keys_for_regex( $content, $keys ) {
		$additional_keys = array();

		foreach ( $keys as $key ) {
			if ( str_contains( $content, (string) $key ) ) {
				$additional_keys[] = $key;
			}
		}

		return $additional_keys;
	}

	/**
	 * Adds show password HTML to the input HTML.
	 *
	 * @since 6.3.1
	 * @since 6.18   Added the `$field` parameter.
	 *
	 * @param string       $input_html Input HTML.
	 * @param array|object $field      Field array.
	 *
	 * @return string
	 */
	public static function add_show_password_html( $input_html, $field = array() ) {
		$show_label = __( 'Show password', 'formidable-pro' );

		$button_attrs = array(
			'type'                     => 'button',
			'class'                    => 'frm_show_password_btn',
			'title'                    => $show_label,
			'aria-label'               => $show_label,
			'data-hide-password-label' => __( 'Hide password', 'formidable-pro' ),
		);

		$icons = self::get_show_password_icons();

		$style       = '';
		$field_size  = FrmField::get_option( $field, 'size' );
		$width       = $field_size ? esc_attr( $field_size ) : '100%';
		$style       = "style=\"width:$width;\"";
		$input_html  = '<span class="frm_show_password_wrapper" ' . $style . '>' . $input_html;
		$input_html .= '<button' . FrmAppHelper::array_to_html_params( $button_attrs ) . '>';
		$input_html .= $icons['show'];
		$input_html .= $icons['hide'];

		return $input_html . '</button></span>';
	}

	/**
	 * Gets show password icons.
	 *
	 * @since 6.3.1
	 *
	 * @return array Always contains `show` and `hide`.
	 */
	private static function get_show_password_icons() {
		$icons = array(
			'show' => FrmProAppHelper::get_svg_icon( 'frm_eye_icon', 'frmsvg', array( 'echo' => false ) ),
			'hide' => FrmProAppHelper::get_svg_icon( 'frm_eye_slash_icon', 'frmsvg', array( 'echo' => false ) ),
		);

		$icons['show'] = FrmProAppHelper::set_svg_title( $icons['show'], __( 'Show Password', 'formidable-pro' ) );
		$icons['hide'] = FrmProAppHelper::set_svg_title( $icons['hide'], __( 'Hide Password', 'formidable-pro' ) );

		/**
		 * Filters the show/hide password icons.
		 *
		 * @since 6.3.1
		 *
		 * @param array $icons Contains `show` and `hide` keys, values are the HTML of icons.
		 */
		return apply_filters( 'frm_pro_show_password_icons', $icons );
	}

	/**
	 * Data type is sent in POST data as "dropdown" then saved as "select" to avoid conflicts
	 * with security tools that block the word "select" in POST data.
	 * This is used for both Lookup and Dynamic (data) fields.
	 *
	 * @since 6.7.1
	 *
	 * @param array $values
	 *
	 * @return array
	 */
	public static function map_dropdown_data_type_to_select( $values ) {
		if ( isset( $values['field_options'] ) && isset( $values['field_options']['data_type'] ) && 'dropdown' === $values['field_options']['data_type'] ) {
			$values['field_options']['data_type'] = 'select';
		}
		return $values;
	}

	/**
	 * Gets repeater fields from form ID.
	 *
	 * @since 6.10.1
	 *
	 * @param $form_id
	 *
	 * @return array
	 */
	public static function get_repeater_fields( $form_id ) {
		$dividers = FrmField::get_all_types_in_form( $form_id, 'divider' );
		return array_filter(
			$dividers,
			function ( $item ) {
				return FrmField::is_repeating_field( $item ) && ! empty( $item->field_options['form_select'] );
			}
		);
	}

	/**
	 * Chosen autocomplete dropdown fields require a blank data-placeholder attribute.
	 * Chosen is disabled by default (SlimSelect is used instead). When SlimSelect is used this isn't required.
	 *
	 * @since 6.34
	 *
	 * @param array  $field
	 * @param string $html
	 *
	 * @return bool
	 */
	public static function dropdown_html_requires_empty_data_placeholder( $field, $html ) {
		if ( ! FrmProAppHelper::use_chosen_js() ) {
			// SlimSelect does not require this.
			return false;
		}

		if ( str_contains( $html, ' data-placeholder="' ) ) {
			// There is already a placeholder attribute.
			return false;
		}

		return FrmField::is_option_true( $field, 'autocom' );
	}

	/**
	 * Outputs field value selector in conditional logic rows in builder and form actions.
	 *
	 * @since 6.17
	 *
	 * @param string $comparison        The comparison used.
	 * @param int    $selector_field_id The field ID of the field value selector.
	 * @param array  $selector_args     The arguments for the field value selector.
	 *
	 * @return void
	 */
	public static function show_field_value_selector( $comparison, $selector_field_id, $selector_args ) {
		$show_dropdown                  = in_array( $comparison, array( '==', '!=' ), true );
		$selector_args['show_dropdown'] = $show_dropdown;

		if ( ! $show_dropdown ) {
			/**
			 * Used to reset the conditional logic's value selector element options so that it is a text input rather than dropdown element.
			 */
			$callback = function () {
				return array();
			};
			add_filter( 'frm_pro_value_selector_options', $callback );
		}

		FrmFieldsHelper::display_field_value_selector( $selector_field_id, $selector_args );

		if ( ! $show_dropdown ) {
			remove_filter( 'frm_pro_value_selector_options', $callback );
		}
	}

	/**
	 * Check if a field type supports currency formatting.
	 *
	 * @since 6.20
	 *
	 * @param string $type The field type to check.
	 *
	 * @return bool Whether the field type supports currency formatting.
	 */
	public static function supports_currency_format( $type ) {
		return in_array( $type, array( 'text', 'textarea', 'number', 'range', 'hidden', 'virtual' ), true );
	}

	/**
	 * Check if a field is hidden on the current page.
	 *
	 * @since 6.23
	 *
	 * @param int|string $field_id
	 *
	 * @return bool
	 */
	public static function field_is_hidden_on_page( $field_id ) {
		return in_array( (int) $field_id, self::$fields_hidden_on_page, true );
	}

	/**
	 * Gets error messages.
	 *
	 * @param string $setting_name
	 *
	 * @return string
	 */
	public static function get_error_message( $setting_name ) {
		return self::get_error_messages()[ $setting_name ] ?? '';
	}

	/**
	 * @since 6.28 The function moved from FrmProFieldCheckbox to FrmProFieldsHelper
	 *
	 * @param string $key
	 *
	 * @return array
	 */
	public static function get_error_messages( $key = '' ) {
		$messages = array(
			// Translators: %1$d: min selections, %2$d: actual selections count.
			'min_selections' => __( 'This field requires a minimum of %1$d selected options but only %2$d were submitted.', 'formidable-pro' ),
		);

		if ( isset( $messages[ $key ] ) ) {
			return array( $key => $messages[ $key ] );
		}

		return $messages;
	}

	/**
	 * Determines if the choices limit validation message should be shown.
	 *
	 * @since 6.28
	 *
	 * @param array $statuses
	 * @param array $field
	 *
	 * @return bool
	 */
	public static function should_show_choices_limit_message( $statuses, $field ) {
		if ( ! $statuses ) {
			// Option limits are likely not enabled.
			// And there may not be any options for the field.
			return false;
		}

		foreach ( $statuses as $choice_limit_reached ) {
			if ( ! $choice_limit_reached ) {
				return false;
			}
		}

		return self::should_hide_maxed_out_field_choices( $field['form_id'], $field );
	}

	/**
	 * @since 6.28
	 *
	 * @param int|string $form_id
	 * @param array      $field
	 * @param string     $choice_key
	 *
	 * @return bool
	 */
	public static function should_hide_maxed_out_field_choices( $form_id, $field, $choice_key = '' ) {
		$entry = self::get_edited_entry();

		if ( $entry && self::choice_is_selected( $entry, $field, $choice_key ) ) {
			return false;
		}

		$form_options = FrmDb::get_var( 'frm_forms', array( 'id' => $form_id ), 'options' );

		if ( ! $form_options ) {
			return false;
		}

		FrmAppHelper::unserialize_or_decode( $form_options );

		return empty( $form_options['disable_on_choice_limit'] );
	}

	/**
	 * @since 6.28
	 *
	 * @param stdClass $entry
	 * @param array    $field
	 * @param string   $choice_key
	 *
	 * @return bool
	 */
	private static function choice_is_selected( $entry, $field, $choice_key ) {
		$entry_value = $entry->metas[ $field['id'] ] ?? '';
		$choice      = $field['options'][ $choice_key ];

		if ( is_array( $entry_value ) ) {
			foreach ( $entry_value as $current_value ) {
				if ( self::check_string_choice_match( $current_value, $choice, $field ) ) {
					return true;
				}
			}

			return false;
		}

		return self::check_string_choice_match( $entry_value, $choice, $field );
	}

	/**
	 * @since 6.28
	 *
	 * @param string       $entry_value
	 * @param array|string $choice
	 * @param array        $field
	 *
	 * @return bool
	 */
	private static function check_string_choice_match( $entry_value, $choice, $field ) {
		if ( is_array( $choice ) ) {
			$compare_value = FrmField::get_option( $field, 'separate_value' ) ? $choice['value'] : $choice['label'];
		} else {
			$compare_value = $choice;
		}

		return trim( $entry_value ) === trim( self::process_choice_value( $compare_value ) );
	}

	/**
	 * @since 6.28
	 *
	 * @return stdClass|null
	 */
	private static function get_edited_entry() {
		global $frm_vars;

		if ( empty( $frm_vars['editing_entry'] ) ) {
			return null;
		}

		$entry_id = (int) $frm_vars['editing_entry'];

		if ( isset( self::$editing_entries[ $entry_id ] ) ) {
			return self::$editing_entries[ $entry_id ];
		}

		$entry = FrmEntry::getOne( $entry_id, true );

		if ( $entry ) {
			self::$editing_entries[ $entry_id ] = $entry;
		}

		return $entry;
	}

	/**
	 * @since 6.28
	 *
	 * @param array  $field
	 * @param string $opt_key
	 *
	 * @return bool
	 */
	public static function choice_limit_reached( $field, $opt_key ) {
		if ( FrmAppHelper::is_form_builder_page() || ! FrmField::get_option( $field, 'set_choices_limit' ) ) {
			return false;
		}

		$options = FrmDb::get_var( 'frm_fields', array( 'id' => $field['id'] ), 'options' );

		if ( ! $options ) {
			return false;
		}

		FrmAppHelper::unserialize_or_decode( $options );
		return self::check_single_option_choice_limit( $field, $options, $opt_key );
	}

	/**
	 * @since 6.28
	 *
	 * @param array|object $field
	 * @param array        $field_options
	 * @param string       $opt_key
	 *
	 * @return bool
	 */
	public static function check_single_option_choice_limit( $field, $field_options, $opt_key ) {
		$field_id = absint( is_array( $field ) ? $field['id'] : $field->id );
		$limit    = $field_options[ $opt_key ]['limit'] ?? '';

		if ( '' === $limit ) {
			return false;
		}

		if ( str_contains( $limit, '[' ) ) {
			$limit = do_shortcode( $limit );
		}

		if ( ! is_numeric( $limit ) ) {
			return false;
		}

		$limit        = absint( $limit );
		$choice_value = self::get_processed_choice_value( $field, $field_options, $opt_key );
		$use_contains = FrmField::get_field_type( $field ) === 'checkbox' || ( FrmField::get_field_type( $field ) === 'select' && FrmField::get_option( $field, 'multiple' ) );

		$shortcode_atts = array(
			'id'   => $field_id,
			'type' => 'count',
		);

		if ( $use_contains ) {
			$shortcode_atts[ $field_id . '_contains' ] = $choice_value;
		} else {
			$shortcode_atts[ $field_id ] = $choice_value;
		}

		$shortcode           = '[frm-stats ' . FrmAppHelper::array_to_html_params( $shortcode_atts ) . ']';
        $count_of_item_metas = do_shortcode( $shortcode );
        $entry               = self::get_edited_entry();

		if ( $entry && (int) $entry->is_draft === FrmEntriesHelper::SUBMITTED_ENTRY_STATUS && self::choice_is_selected( $entry, $field, $opt_key ) ) {
			// Exclude the current entry from the count.
			$count_of_item_metas--;
		}

		self::$choices_entry_count[ $field_id ][ $opt_key ] = array(
			'count' => absint( $count_of_item_metas ),
			'limit' => $limit,
		);

		return absint( $count_of_item_metas ) >= $limit;
	}

	/**
	 * Get the option value to compare in the frm-stats shortcode.
	 * This processes shortcodes that may be in use.
	 *
	 * @since 6.28
	 *
	 * @param array  $field
	 * @param array  $field_options
	 * @param string $opt_key
	 *
	 * @return string
	 */
	private static function get_processed_choice_value( $field, $field_options, $opt_key ) {
		$choice_value = FrmField::is_option_true( $field, 'separate_value' ) ? $field_options[ $opt_key ]['value'] : $field_options[ $opt_key ]['label'];
		return self::process_choice_value( $choice_value );
	}

	/**
	 * Process shortcodes that may be in use in choice values.
	 *
	 * @since 6.28
	 *
	 * @param string $choice_value
	 *
	 * @return string
	 */
	private static function process_choice_value( $choice_value ) {
		if ( ! str_contains( $choice_value, '[' ) ) {
			return $choice_value;
		}

		$choice_value = do_shortcode( $choice_value );

		if ( str_contains( $choice_value, '[' ) ) {
			self::replace_non_standard_formidable_shortcodes( array(), $choice_value );
		}

		return $choice_value;
	}

	/**
	 * @since 6.28
	 *
	 * @param int    $field_id
	 * @param string $opt_key
	 *
	 * @return array|false
	 */
	public static function get_choice_entry_data( $field_id, $opt_key ) {
		return self::$choices_entry_count[ $field_id ][ $opt_key ] ?? false;
	}

	/**
	 * @since 6.28
	 *
	 * @param array $field
	 *
	 * @return string
	 */
	public static function get_remaining_qty_label( $field ) {
		$setting_key = 'remaining_qty_label';
        return $field['field_options'][ $setting_key ] ?? $field[ $setting_key ] ?? __( 'remaining', 'formidable-pro' );
	}

	/**
	 * @since 6.28
	 *
	 * @param array $field
	 *
	 * @return string
	 */
	public static function get_exhausted_message( $field ) {
		$setting_key = 'exhausted_message';
        return $field['field_options'][ $setting_key ] ?? $field[ $setting_key ] ?? __( 'Sorry, there are no more of this item', 'formidable-pro' );
	}

	/**
	 * @since 6.28
	 *
	 * @param int   $choices_left
	 * @param array $field
	 *
	 * @return string
	 */
	public static function get_remaining_qty_message( $choices_left, $field ) {
		if ( $choices_left <= 0 ) {
        	return self::wrap_remaining_qty_message_in_span( '(' . self::get_exhausted_message( $field ) . ')' );
        }

        $remaining_qty_label = self::get_remaining_qty_label( $field );
        $message             = '' === $remaining_qty_label ? '([remaining])' : '([remaining] ' . self::get_remaining_qty_label( $field ) . ')';

        /**
         * @since 6.28
         *
         * @param string $message
         * @param array  $args
         */
        $message = apply_filters( 'frm_remaining_qty_message', $message, compact( 'choices_left', 'remaining_qty_label', 'field' ) );
        $message = str_replace( '[remaining]', $choices_left, $message );

        return self::wrap_remaining_qty_message_in_span( $message );
	}

	/**
	 * @since 6.28
	 *
	 * @param string $message
	 *
	 * @return string
	 */
	private static function wrap_remaining_qty_message_in_span( $message ) {
		return ' <span class="frm_choice_limit_reached">' . $message . '</span>';
	}

	/**
	 * Get HTML for a file upload field depending on atts and file type
	 *
	 * @since 2.0.19
	 * @deprecated 3.0 This was still referenced in the registration add-on until version 3.0, released on October 8 2024.
	 *
	 * @codeCoverageIgnore
	 *
	 * @param array $ids
	 * @param string $size
	 * @param array $atts
	 *
	 * @return array|string
	 */
	public static function get_displayed_file_html( $ids, $size = 'thumbnail', $atts = array() ) {
		_deprecated_function( __FUNCTION__, '3.0', 'FrmProFieldFile->get_displayed_file_html' );
		$field_obj = FrmFieldFactory::get_field_type( 'file' );
		return $field_obj->get_displayed_file_html( $ids, $size, $atts );
	}

	/**
	 * @deprecated 3.0 As of August 7th 2024 this function was still referenced in our documentation.
	 *
	 * @codeCoverageIgnore
	 *
	 * @param array|string  $value
	 * @param array|object  $field
	 * @param array         $atts
	 */
	public static function get_display_value( $value, $field, $atts = array() ) {
		_deprecated_function( __FUNCTION__, '3.0', 'FrmFieldsHelper::get_unfiltered_display_value' );

		if ( is_array( $field ) ) {
			$field = FrmField::getOne( $field['id'] );
		}

		return FrmFieldsHelper::get_unfiltered_display_value( compact( 'value', 'field', 'atts' ) );
	}
}
