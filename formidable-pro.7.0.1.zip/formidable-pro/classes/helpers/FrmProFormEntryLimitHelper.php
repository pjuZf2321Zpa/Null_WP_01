<?php
/**
 * Form entry limit helper
 *
 * Handles the "Limit number of entries" form setting, including the entry count and time period options.
 *
 * @since 7.0
 *
 * @package FormidablePro
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmProFormEntryLimitHelper {

	/**
	 * Maximum entries tracked in one cookie, including URL encoding overhead.
	 *
	 * @since 7.0
	 *
	 * @var int
	 */
	const MAX_COOKIE_ENTRIES = 100;

	/**
	 * Get the maximum number of entries allowed by the "Limit number of entries" setting.
	 *
	 * @since 7.0
	 *
	 * @param array $options The form options.
	 *
	 * @return int
	 */
	public static function get_single_entry_limit( $options ) {
		$limit = isset( $options['single_entry_limit'] ) ? absint( $options['single_entry_limit'] ) : 1;
		$limit = max( 1, $limit );

		if ( FrmProFormsHelper::check_single_entry_type( $options, 'cookie' ) ) {
			return min( self::MAX_COOKIE_ENTRIES, $limit );
		}

		return $limit;
	}

	/**
	 * Get the time period units supported by the "Limit number of entries" setting.
	 *
	 * @since 7.0
	 *
	 * @return array<string, array{0: string, 1: string}> Singular and plural unit names keyed by the strtotime unit.
	 */
	public static function get_single_entry_interval_units() {
		return array(
			'hour'  => array( __( 'hour', 'formidable' ), __( 'hours', 'formidable' ) ),
			'day'   => array( __( 'day', 'formidable' ), __( 'days', 'formidable' ) ),
			'week'  => array( __( 'week', 'formidable' ), __( 'weeks', 'formidable' ) ),
			'month' => array( __( 'month', 'formidable' ), __( 'months', 'formidable' ) ),
			'year'  => array( __( 'year', 'formidable' ), __( 'years', 'formidable' ) ),
		);
	}

	/**
	 * Get the time period unit for the "Limit number of entries" setting.
	 *
	 * @since 7.0
	 *
	 * @param array $options The form options.
	 *
	 * @return string "forever", or one of the units from get_single_entry_interval_units().
	 */
	public static function get_single_entry_interval( $options ) {
		$interval = $options['single_entry_interval'] ?? 'forever';
		return array_key_exists( $interval, self::get_single_entry_interval_units() ) ? $interval : 'forever';
	}

	/**
	 * Get the number of units in the "Limit number of entries" time period, like the 2 in "per 2 weeks".
	 *
	 * @since 7.0
	 *
	 * @param array $options The form options.
	 *
	 * @return int
	 */
	public static function get_single_entry_interval_count( $options ) {
		return isset( $options['single_entry_interval_count'] ) ? max( 1, absint( $options['single_entry_interval_count'] ) ) : 1;
	}

	/**
	 * Get the timestamp where the current "Limit number of entries" time period starts.
	 * Entries created before this time do not count towards the limit.
	 *
	 * Time periods follow the calendar in the site timezone. An hour starts on the hour, a day at midnight,
	 * a week on the "Week Starts On" day, a month on the 1st, and a year on January 1st. When the count is
	 * more than 1, the period is the current hour, day, week, month or year plus the ones before it.
	 * So "per 3 months" in June starts on April 1st.
	 *
	 * @since 7.0
	 *
	 * @param array    $options The form options.
	 * @param int|null $now     The current timestamp. Defaults to time().
	 *
	 * @return int 0 when the limit applies forever.
	 */
	public static function get_single_entry_interval_start( $options, $now = null ) {
		$period = self::get_single_entry_calendar_period( $options, $now );

		if ( ! $period ) {
			return 0;
		}

		return $period['start']->modify( '-' . ( $period['count'] - 1 ) . ' ' . $period['unit'] )->getTimestamp();
	}

	/**
	 * Get the timestamp when an entry submitted now stops counting towards the "Limit number of entries" setting.
	 * For example, with "per 3 months" an entry submitted in June counts until September 1st.
	 *
	 * @since 7.0
	 *
	 * @param array    $options The form options.
	 * @param int|null $now     The current timestamp. Defaults to time().
	 *
	 * @return int 0 when the limit applies forever.
	 */
	public static function get_single_entry_interval_end( $options, $now = null ) {
		$period = self::get_single_entry_calendar_period( $options, $now );

		if ( ! $period ) {
			return 0;
		}

		return $period['start']->modify( '+' . $period['count'] . ' ' . $period['unit'] )->getTimestamp();
	}

	/**
	 * Get the start of the current calendar hour, day, week, month or year for the "Limit number of entries" time period.
	 *
	 * @since 7.0
	 *
	 * @param array    $options The form options.
	 * @param int|null $now     The current timestamp. Defaults to time().
	 *
	 * @return array|false False when the limit applies forever. {
	 *
	 *     @type DateTimeImmutable $start The start of the current calendar unit, in the site timezone.
	 *     @type int               $count The number of calendar units in the time period.
	 *     @type string            $unit  The calendar unit. One of hour, day, week, month or year.
	 * }
	 */
	private static function get_single_entry_calendar_period( $options, $now ) {
		$unit = self::get_single_entry_interval( $options );

		if ( 'forever' === $unit ) {
			return false;
		}

		$date  = ( new DateTimeImmutable( '@' . ( $now ?? time() ) ) )->setTimezone( wp_timezone() );
		$year  = (int) $date->format( 'Y' );
		$month = (int) $date->format( 'n' );
		$date  = $date->setTime( 'hour' === $unit ? (int) $date->format( 'G' ) : 0, 0 );

		if ( 'week' === $unit ) {
			$days_into_week = ( (int) $date->format( 'w' ) - (int) get_option( 'start_of_week', 1 ) + 7 ) % 7;
			$date           = $date->modify( '-' . $days_into_week . ' days' );
		} elseif ( 'month' === $unit ) {
			$date = $date->setDate( $year, $month, 1 );
		} elseif ( 'year' === $unit ) {
			$date = $date->setDate( $year, 1, 1 );
		}

		return array(
			'start' => $date,
			'count' => self::get_single_entry_interval_count( $options ),
			'unit'  => $unit,
		);
	}

	/**
	 * Check if the "Limit number of entries" setting uses the original one entry forever behavior.
	 * The legacy checks (unique email fields, the timestamp cookie, editing a single user entry) only apply in this case.
	 *
	 * @since 7.0
	 *
	 * @param array $options The form options.
	 *
	 * @return bool
	 */
	public static function is_default_single_entry_limit( $options ) {
		return 1 === self::get_single_entry_limit( $options ) && ! self::get_single_entry_interval_start( $options );
	}

	/**
	 * Get the error message when the submission limit is reached.
	 *
	 * @since 7.0
	 *
	 * @param array $options The form options.
	 *
	 * @return string
	 */
	public static function get_single_entry_limit_message( $options ) {
		if ( self::is_default_single_entry_limit( $options ) ) {
			return FrmProAppHelper::get_settings()->already_submitted;
		}

		return str_replace( '[limit]', self::get_single_entry_limit_description( $options ), FrmProAppHelper::get_settings()->submission_limit_reached );
	}

	/**
	 * Get the submission count and time period for the global limit message.
	 *
	 * @since 7.0
	 *
	 * @param array $options The form options.
	 *
	 * @return string
	 */
	private static function get_single_entry_limit_description( $options ) {
		$limit    = number_format_i18n( self::get_single_entry_limit( $options ) );
		$interval = self::get_single_entry_interval( $options );

		if ( 'forever' === $interval ) {
			return $limit;
		}

		$count = self::get_single_entry_interval_count( $options );

		switch ( $interval ) {
			case 'hour':
				/* translators: 1: Maximum number of submissions, 2: Number of hours. */
				$message = _n(
					'%1$s per %2$s hour',
					'%1$s per %2$s hours',
					$count,
					'formidable-pro'
				);
				break;
			case 'day':
				/* translators: 1: Maximum number of submissions, 2: Number of days. */
				$message = _n(
					'%1$s per %2$s day',
					'%1$s per %2$s days',
					$count,
					'formidable-pro'
				);
				break;
			case 'week':
				/* translators: 1: Maximum number of submissions, 2: Number of weeks. */
				$message = _n(
					'%1$s per %2$s week',
					'%1$s per %2$s weeks',
					$count,
					'formidable-pro'
				);
				break;
			case 'month':
				/* translators: 1: Maximum number of submissions, 2: Number of months. */
				$message = _n(
					'%1$s per %2$s month',
					'%1$s per %2$s months',
					$count,
					'formidable-pro'
				);
				break;
			default:
				/* translators: 1: Maximum number of submissions, 2: Number of years. */
				$message = _n(
					'%1$s per %2$s year',
					'%1$s per %2$s years',
					$count,
					'formidable-pro'
				);
				break;
		}

		return strval( sprintf( $message, $limit, number_format_i18n( $count ) ) );
	}

	/**
	 * Check if a logged-in user is limited to a single entry that they can go back and edit.
	 *
	 * @since 7.0
	 *
	 * @param stdClass $form The form object.
	 *
	 * @return bool
	 */
	public static function limits_to_one_editable_user_entry( $form ) {
		return $form->editable && FrmProFormsHelper::check_single_entry_type( $form->options, 'user' ) && self::is_default_single_entry_limit( $form->options );
	}

	/**
	 * Count the submitted entries in a form that count towards the "Limit number of entries" setting.
	 *
	 * @since 7.0
	 *
	 * @param stdClass $form  The form object.
	 * @param array    $where Additional conditions to match entries by, like the user ID or IP address.
	 *
	 * @return int
	 */
	private static function count_entries_in_single_entry_interval( $form, $where ) {
		$where['form_id']  = $form->id;
		$where['is_draft'] = FrmEntriesHelper::SUBMITTED_ENTRY_STATUS;

		$start = self::get_single_entry_interval_start( $form->options );

		if ( $start ) {
			// FrmDb treats "created_at >" as greater than or equal to.
			$where['created_at >'] = gmdate( 'Y-m-d H:i:s', $start );
		}

		return FrmDb::get_count( 'frm_items', $where );
	}

	/**
	 * Check if the entries matching a condition have reached the "Limit number of entries" setting.
	 *
	 * @since 7.0
	 *
	 * @param stdClass $form  The form object.
	 * @param array    $where Conditions to match entries by, like the user ID or IP address.
	 *
	 * @return bool
	 */
	public static function single_entry_limit_reached( $form, $where ) {
		return self::count_entries_in_single_entry_interval( $form, $where ) >= self::get_single_entry_limit( $form->options );
	}

	/**
	 * Check if an email address has reached the "Limit number of entries" setting.
	 * This is only used when the limit is not the default one entry forever. In that case the email field is flagged as unique instead.
	 *
	 * @since 7.0
	 *
	 * @param stdClass   $form     The form object.
	 * @param int|string $field_id The email field ID.
	 * @param string     $email    The submitted email address.
	 * @param int        $entry_id The entry being updated, so it does not count against itself. 0 for new entries.
	 *
	 * @return bool
	 */
	public static function email_single_entry_limit_reached( $form, $field_id, $email, $entry_id = 0 ) {
		global $wpdb;

		$start = self::get_single_entry_interval_start( $form->options );
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(DISTINCT it.id) FROM %i it
				INNER JOIN %i em ON em.item_id = it.id
				WHERE it.form_id = %d AND it.is_draft = %d AND it.id != %d AND it.created_at >= %s
				AND em.field_id = %d AND em.meta_value = %s',
				$wpdb->prefix . 'frm_items',
				$wpdb->prefix . 'frm_item_metas',
				$form->id,
				FrmEntriesHelper::SUBMITTED_ENTRY_STATUS,
				$entry_id,
				gmdate( 'Y-m-d H:i:s', $start ),
				$field_id,
				$email
			)
		);

		return $count >= self::get_single_entry_limit( $form->options );
	}

	/**
	 * Get how long the submission cookie must last before applying the expiration filter.
	 *
	 * @since 7.0
	 *
	 * @param array    $options The form options.
	 * @param int|null $now     The current timestamp. Defaults to time().
	 *
	 * @return float|int The lifetime in seconds.
	 */
	public static function get_single_entry_cookie_expiration( $options, $now = null ) {
		$expiration = isset( $options['cookie_expiration'] ) ? (float) $options['cookie_expiration'] * HOUR_IN_SECONDS : 30000000;
		$now        = $now ?? time();
		$end        = self::get_single_entry_interval_end( $options, $now );

		if ( ! $end ) {
			return $expiration;
		}

		// Keep the cookie until this entry stops counting, or the limit would reset early.
		return max( $expiration, $end - $now );
	}

	/**
	 * Get the name of the cookie used to track entries for the "Saved Cookie" limit type.
	 *
	 * @since 7.0
	 *
	 * @param int|string $form_id The form ID.
	 *
	 * @return string
	 */
	public static function get_single_entry_cookie_name( $form_id ) {
		return 'frm_form' . $form_id . '_' . COOKIEHASH;
	}

	/**
	 * Get the entries tracked in the "Saved Cookie" cookie that are inside the current time period.
	 *
	 * With the default limit the cookie value is a single MySQL date and only its presence matters.
	 * Otherwise the value is a comma separated list of "timestamp:entry_id" pairs so the entries can be counted.
	 * A legacy date value is read as one entry, so switching the setting keeps counting past submissions.
	 *
	 * @since 7.0
	 *
	 * @param stdClass $form The form object.
	 *
	 * @return array<array{time: int, entry_id: int}>
	 */
	public static function get_single_entry_cookie_records( $form ) {
		$cookie_name = self::get_single_entry_cookie_name( $form->id );

		if ( empty( $_COOKIE[ $cookie_name ] ) ) {
			return array();
		}

		$value   = sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_name ] ) );
		$records = array();

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $value ) ) {
			$records[] = array(
				'time'     => (int) strtotime( $value . ' UTC' ),
				'entry_id' => 0,
			);
		} else {
			foreach ( explode( ',', $value ) as $record ) {
				$parts     = explode( ':', $record );
				$records[] = array(
					'time'     => absint( $parts[0] ),
					'entry_id' => isset( $parts[1] ) ? absint( $parts[1] ) : 0,
				);
			}
		}

		$start = self::get_single_entry_interval_start( $form->options );

		return array_values(
			array_filter(
				$records,
				function ( $record ) use ( $start ) {
					return $record['time'] && $record['time'] >= $start;
				}
			)
		);
	}

	/**
	 * Get the new "Saved Cookie" value after an entry is submitted, for limits other than the default one entry forever.
	 *
	 * @since 7.0
	 *
	 * @param stdClass $form     The form object.
	 * @param int      $entry_id The submitted entry ID.
	 *
	 * @return string
	 */
	public static function get_single_entry_cookie_value( $form, $entry_id ) {
		$records = self::get_single_entry_cookie_records( $form );

		// The cookie can be set more than once for the same entry, for example by the AJAX cookie request after a redirect.
		$tracked = $entry_id && in_array( $entry_id, wp_list_pluck( $records, 'entry_id' ), true );

		if ( ! $tracked ) {
			$records[] = array(
				'time'     => time(),
				'entry_id' => $entry_id,
			);
		}

		// Only the most recent entries are needed to know if the limit is reached.
		$records = array_slice( $records, - self::get_single_entry_limit( $form->options ) );

		return implode(
			',',
			array_map(
				function ( $record ) {
					return $record['time'] . ':' . $record['entry_id'];
				},
				$records
			)
		);
	}
}
