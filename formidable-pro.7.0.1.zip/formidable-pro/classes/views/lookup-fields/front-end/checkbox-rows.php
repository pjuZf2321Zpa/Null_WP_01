<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

if ( isset( $field ) && ( FrmProChoiceImagesHelper::has_images( $field ) || FrmProImages::has_image_options( $field ) ) ) {
	$field['value'] = $saved_value_array;
	$field          = FrmProChoiceImagesHelper::prepare_field( $field );
	$field_name     = substr( $field_name, 0, -2 );
	require FrmProAppHelper::plugin_path() . '/classes/views/frmpro-fields/front-end/image-options.php';
	return;
}

$option_index = 0;

foreach ( $field['options'] as $opt_key => $opt_value ) {
	// Get label first so we do not pass the filtered $opt_value to the label filter.
	$opt_label = FrmProFieldLookup::filter_lookup_displayed_value( $opt_value, $field );
	$opt_label = FrmProLookupFieldsController::sanitize_lookup_label( $opt_label, $opt_value, $field );
	$opt_value = FrmProFieldLookup::filter_lookup_saved_value( $opt_value, $field );

	$checked = in_array( $opt_value, $saved_value_array ) ? ' checked="checked"' : '';
	?>
	<div class="<?php echo esc_attr( apply_filters( 'frm_checkbox_class', 'frm_checkbox', $field, $opt_value ) ); ?>" id="frm_checkbox_<?php echo esc_attr( $field['id'] ); ?>-<?php echo esc_attr( $opt_key ); ?>">
		<label for="<?php echo esc_attr( $html_id . '-' . $opt_key ); ?>">
			<input type="checkbox" name="<?php echo esc_attr( $field_name ); ?>"
					id="<?php echo esc_attr( $html_id . '-' . $opt_key ); ?>"
					value="<?php echo esc_attr( $opt_value ); ?>" <?php
			echo $checked . $disabled . ' '; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			if ( 0 === $option_index && FrmField::is_required( $field ) ) {
				echo ' aria-required="true" ';
			}

			do_action( 'frm_field_input_html', $field );
			?> /> <?php FrmAppHelper::kses_echo( $opt_label, 'all' ); ?>
		</label>
	</div>
	<?php
	++$option_index;
}
