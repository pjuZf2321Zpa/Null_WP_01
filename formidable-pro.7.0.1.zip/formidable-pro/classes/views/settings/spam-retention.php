<?php
/**
 * Spam entries cleanup setting in the Captcha/Spam global settings.
 *
 * @since 7.0
 *
 * @package FormidablePro
 *
 * @var int $retention_days The saved number of days. 0 keeps spam entries until they are deleted.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<div class="frm_grid_container">
	<p class="frm6 frm_form_field">
		<label for="frm_spam_retention_days">
			<?php esc_html_e( 'Delete spam entries automatically', 'formidable' ); ?>
			<?php FrmAppHelper::tooltip_icon( __( 'Spam entries older than this are permanently deleted once a day.', 'formidable-pro' ), array( 'data-container' => 'body' ) ); ?>
		</label>
		<select id="frm_spam_retention_days" name="frm_spam_retention_days">
			<?php foreach ( FrmProSpamEntriesController::get_retention_options() as $days => $label ) { ?>
				<option value="<?php echo absint( $days ); ?>" <?php selected( $retention_days, $days ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php } ?>
		</select>
	</p>
</div>
