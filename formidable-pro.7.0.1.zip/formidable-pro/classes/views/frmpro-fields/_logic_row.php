<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<div id="frm_logic_<?php echo esc_attr( $field['id'] . '_' . $meta_name ); ?>" class="frm_logic_row frm-flex-col frm-items-stretch frm-gap-xs">
	<span class="frm-logic-rule"><span class="frm-logic-rule-text"></span></span>

	<?php
	$defer_logic_options = FrmProConditionalLogicController::should_defer_logic_options();
	$sel                 = false;
	$select_attrs        = array(
		'class'     => 'frm_logic_field_opts',
		'data-type' => $field['type'],
	);

	if ( $defer_logic_options ) {
		// The full trigger-field list is identical for every row in the form, so the browser
		// hydrates it on first use (see logicRow.js) instead of it being rendered here for every row.
		// A saved trigger may target a combo field's sub field, stored as "{field_id}_{sub_field_key}".
		list( $hide_field_id, $hide_sub_field_key ) = FrmProConditionalLogicController::get_logic_field_id_and_sub_key( $hide_field );

		$logic_field_form_id  = $field['parent_form_id'] ?? $field['form_id'];
		$selected_logic_field = $hide_field ? FrmProConditionalLogicOptionData::get_field( $logic_field_form_id, $hide_field_id ) : null;
		$selected_logic_label = '';

		if ( $selected_logic_field ) {
			$in_section_id = $selected_logic_field->field_options['in_section'] ?? '0';

			if ( $selected_logic_field->id == $field['id'] || $in_section_id == $field['id'] ) {
				// Self-referential or same-section trigger. This matches the two relationship
				// checks is_field_present_in_logic_options() applies on the non-deferred path,
				// so a now-invalid saved trigger isn't treated as still selected here.
				$selected_logic_field = null;
			} elseif ( false !== $hide_sub_field_key ) {
				$logic_sub_fields = FrmProConditionalLogicController::get_logic_sub_fields( $selected_logic_field );

				if ( isset( $logic_sub_fields[ $hide_sub_field_key ] ) ) {
					$selected_logic_label = $selected_logic_field->name . ' (' . $logic_sub_fields[ $hide_sub_field_key ] . ')';
				}
			} elseif ( FrmProConditionalLogicController::offers_whole_field_logic_option( $selected_logic_field ) ) {
				$selected_logic_label = $selected_logic_field->name;
			}
		}

		$sel = '' !== $selected_logic_label;

		$select_attrs['data-frm-field-id']      = $field['id'];
		$select_attrs['data-frm-hydrate-logic'] = '1';
	}
	?>
	<select name="field_options[hide_field_<?php echo esc_attr( $field['id'] ); ?>][]"<?php FrmAppHelper::array_to_html_params( $select_attrs, true ); ?>>
		<option value=""><?php esc_html_e( '&mdash; Select &mdash;' ); ?></option>
		<?php
		if ( $defer_logic_options ) {
			if ( $sel ) {
				FrmProHtmlHelper::echo_dropdown_option( $selected_logic_label, true, array( 'value' => (string) $hide_field ) );
			}
		} else {
			$prefiltered = FrmProConditionalLogicOptionData::data_is_available( $field['form_id'] );

			foreach ( $form_fields as $ff ) {
				if ( ! FrmProConditionalLogicController::is_field_present_in_logic_options( $field, $ff, $prefiltered ) ) {
					continue;
				}

				if ( FrmProConditionalLogicController::offers_whole_field_logic_option( $ff ) ) {
					if ( $ff->id == $hide_field ) {
						$sel = true;
					}

					FrmProHtmlHelper::echo_dropdown_option(
						$ff->name,
						(string) $ff->id === (string) $hide_field,
						array(
							'value' => $ff->id,
						)
					);
				}

				// Let a combo field's individual sub fields (e.g. Address's State, Name's Last) be selected as the trigger.
				foreach ( FrmProConditionalLogicController::get_logic_sub_fields( $ff ) as $sub_key => $sub_label ) {
					$sub_field_value = $ff->id . '_' . $sub_key;

					if ( $sub_field_value === (string) $hide_field ) {
						$sel = true;
					}

					FrmProHtmlHelper::echo_dropdown_option(
						$ff->name . ' (' . $sub_label . ')',
						$sub_field_value === (string) $hide_field,
						array(
							'value' => $sub_field_value,
						)
					);
				}
			}
		}
		?>
	</select>

	<?php
	// Remove conditional logic if the field doesn't exist
	if ( $hide_field && ! $sel ) {
	?>
	<script type="text/javascript">jQuery(document).ready(function(){frmAdminBuild.triggerRemoveLogic(<?php echo (int) $field['id']; ?>, '<?php echo esc_attr( $meta_name ); ?>');});</script>
	<?php } ?>

	<select name="field_options[hide_field_cond_<?php echo esc_attr( $field['id'] ); ?>][]">
		<?php
		$field['hide_field_cond'][ $meta_name ] = isset( $field['hide_field_cond'][ $meta_name ] ) ? htmlspecialchars_decode( $field['hide_field_cond'][ $meta_name ] ) : '';
		$condition_options                      = array(
			'=='       => __( 'equals', 'formidable-pro' ),
			'!='       => __( 'does not equal', 'formidable-pro' ) . ' &nbsp;',
			'>'        => __( 'is greater than', 'formidable-pro' ),
			'>='       => __( 'is greater than or equal to', 'formidable-pro' ),
			'<'        => __( 'is less than', 'formidable-pro' ),
			'<='       => __( 'is less than or equal to', 'formidable-pro' ),
			'LIKE'     => __( 'contains', 'formidable-pro' ),
			'not LIKE' => __( 'does not contain', 'formidable-pro' ) . ' &nbsp;',
			'LIKE%'    => __( 'starts with', 'formidable-pro' ) . ' &nbsp;',
			'%LIKE'    => __( 'ends with', 'formidable-pro' ) . ' &nbsp;',
		);

		foreach ( $condition_options as $option_value => $option_label ) {
			FrmProHtmlHelper::echo_dropdown_option(
				$option_label,
				$field['hide_field_cond'][ $meta_name ] === $option_value,
				array( 'value' => $option_value )
			);
		}
		?>
	</select>

	<span id="frm_show_selected_values_<?php echo esc_attr( $field['id'] . '_' . $meta_name ); ?>">
		<?php
		$selector_field_id = $hide_field && is_numeric( $hide_field ) ? (int) $hide_field : 0;
		$selector_args     = array(
			'html_name' => 'field_options[hide_opt_' . $field['id'] . '][]',
			'value'     => $field['hide_opt'][ $meta_name ] ?? '',
			'source'    => $field['type'],
			'truncate'  => 40, // The default is 25. Allow more since there is available space.
		);

		FrmProFieldsHelper::show_field_value_selector( $field['hide_field_cond'][ $meta_name ], $selector_field_id, $selector_args );
		?>
	</span>

	<a href="javascript:void(0)" class="frm_remove_tag frm-h-stack frm-leading-none frm-mt-2xs" data-removeid="frm_logic_<?php echo esc_attr( $field['id'] . '_' . $meta_name ); ?>" data-showlast="#logic_<?php echo esc_attr( $field['id'] ); ?>" data-hidelast="#frm_logic_rows_<?php echo absint( $field['id'] ); ?>">
		<?php FrmAppHelper::icon_by_class( 'frmfont frm_minus1_icon frm_svg14' ); ?>
		<span class="frm-ml-2xs"><?php esc_html_e( 'Remove', 'formidable' ); ?></span>
	</a>
</div>
