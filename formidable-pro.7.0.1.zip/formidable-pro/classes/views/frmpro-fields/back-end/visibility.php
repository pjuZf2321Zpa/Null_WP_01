<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<p class="frm6 frm_form_field">
	<label class="frm-h-stack-xs" id="for_field_options_admin_only_<?php echo absint( $field['id'] ); ?>" for="field_options_admin_only_<?php echo absint( $field['id'] ); ?>">
		<span><?php esc_html_e( 'Visibility', 'formidable' ); ?></span>
		<?php
		FrmAppHelper::tooltip_icon(
			__( 'Determines who can see this field.', 'formidable' ),
			array(
				'data-placement' => 'right',
				'class'          => 'frm-flex',
			)
		);
		?>
	</label>

	<?php
	if ( $field['admin_only'] == 1 ) {
		$field['admin_only'] = 'administrator';
	} elseif ( empty( $field['admin_only'] ) ) {
		$field['admin_only'] = '';
	}
	?>

	<?php
	if ( class_exists( 'FrmBuilderSelectHelper' ) ) {
		global $frm_vars;
		$roles                      = $frm_vars['editable_roles'] ?? get_editable_roles();
		$frm_vars['editable_roles'] = $roles;
		$visibility_options         = array( '' => __( 'Everyone', 'formidable' ) );

		foreach ( $roles as $role_name => $details ) {
			$visibility_options[ $role_name ] = translate_user_role( $details['name'] );
		}
		$visibility_options['loggedin']  = __( 'Logged-in Users', 'formidable-pro' );
		$visibility_options['loggedout'] = __( 'Logged-out Users', 'formidable-pro' );
		$selected_visibility             = array();

		// Preserve higher-role selections for legacy string values.
		foreach ( array_keys( $visibility_options ) as $value ) {
			if ( FrmProAppHelper::selected( $field['admin_only'], $value, false ) ) {
				$selected_visibility[] = $value;
			}
		}

		FrmBuilderSelectHelper::render(
			array(
				'name'     => 'field_options[admin_only_' . $field['id'] . '][]',
				'id'       => 'field_options_admin_only_' . $field['id'],
				'multiple' => 'multiple',
				'class'    => 'frm_multiselect',
			),
			$visibility_options,
			$selected_visibility
		);
	} else {
		?>
	<select name="field_options[admin_only_<?php echo absint( $field['id'] ); ?>][]" id="field_options_admin_only_<?php echo absint( $field['id'] ); ?>" multiple="multiple" class="frm_multiselect">
		<option value="" <?php FrmProAppHelper::selected( $field['admin_only'], '' ); ?>><?php esc_html_e( 'Everyone', 'formidable' ); ?></option>
		<?php FrmAppHelper::roles_options( $field['admin_only'] ); ?>
		<option value="loggedin" <?php FrmProAppHelper::selected( $field['admin_only'], 'loggedin' ); ?>>
			<?php esc_html_e( 'Logged-in Users', 'formidable-pro' ); ?>
		</option>
		<option value="loggedout" <?php FrmProAppHelper::selected( $field['admin_only'], 'loggedout' ); ?>>
			<?php esc_html_e( 'Logged-out Users', 'formidable-pro' ); ?>
		</option>
	</select>
		<?php
	}
	?>
</p>
