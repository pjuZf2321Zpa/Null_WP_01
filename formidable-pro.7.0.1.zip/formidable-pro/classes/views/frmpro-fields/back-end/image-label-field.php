<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<p class="frm_form_field">
	<label for="image_label_field_<?php echo absint( $field['id'] ); ?>"><?php esc_html_e( 'Image option label', 'formidable-pro' ); ?></label>
	<select name="field_options[image_label_field_<?php echo absint( $field['id'] ); ?>]" id="image_label_field_<?php echo absint( $field['id'] ); ?>" class="frm_image_label_field">
		<option value="0"><?php esc_html_e( 'File name', 'formidable-pro' ); ?></option>
		<?php foreach ( $label_fields as $label_field ) { ?>
			<option value="<?php echo absint( $label_field->id ); ?>" <?php selected( FrmField::get_option( $field, 'image_label_field' ), $label_field->id ); ?>><?php echo esc_html( $label_field->name ); ?></option>
		<?php } ?>
	</select>
</p>
