<?php
/**
 * Auto-delete entries setting in the GDPR form settings.
 *
 * @since 7.0
 *
 * @package FormidablePro
 *
 * @var array $values       Form values.
 * @var bool  $gdpr_enabled Whether GDPR is enabled in global settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

$wrapper_params  = array( 'class' => 'frm8 frm_form_field' );
$checkbox_params = array(
	'type'  => 'checkbox',
	'name'  => 'options[auto_delete_entries]',
	'id'    => 'frm_auto_delete_entries',
	'value' => '1',
);
$days_params     = array(
	'type'       => 'number',
	'name'       => 'options[auto_delete_days]',
	'id'         => 'frm_auto_delete_days',
	'class'      => 'frm-auto-delete-days',
	'min'        => '1',
	'max'        => FrmProAutoDeleteEntriesController::MAX_DAYS,
	'step'       => '1',
	'value'      => $values['auto_delete_days'],
	'aria-label' => __( 'Number of days', 'formidable' ),
);

if ( ! empty( $values['auto_delete_entries'] ) ) {
	$checkbox_params['checked'] = 'checked';
}

if ( ! $gdpr_enabled ) {
	$wrapper_params['class']    .= ' frm_noallow';
	$checkbox_params['disabled'] = 'disabled';
	$days_params['disabled']     = 'disabled';
}
?>
<p <?php FrmAppHelper::array_to_html_params( $wrapper_params, true ); ?>>
	<label for="frm_auto_delete_entries" class="frm_inline_block">
		<input <?php FrmAppHelper::array_to_html_params( $checkbox_params, true ); ?> />
		<?php esc_html_e( 'Automatically delete entries after', 'formidable' ); ?>
	</label>
	<input <?php FrmAppHelper::array_to_html_params( $days_params, true ); ?> />
	<?php esc_html_e( 'days', 'formidable' ); ?>
	<?php FrmAppHelper::tooltip_icon( __( 'Entries older than this are permanently deleted. Posts created from them are moved to the trash. Uploaded files are deleted too when the file upload field is set to delete files with the entry.', 'formidable-pro' ), array( 'data-container' => 'body' ) ); ?>
</p>
<p class="howto">
	<?php esc_html_e( 'Once saved, entries older than this are deleted within the hour. Deleted entries cannot be restored.', 'formidable-pro' ); ?>
</p>
