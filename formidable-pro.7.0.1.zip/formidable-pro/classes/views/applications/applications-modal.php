<?php
/**
 * Content for the modal that adds a form to applications from the forms list.
 * JS moves #frm-add-applications-content into the modal when it opens.
 *
 * @since 7.0
 *
 * @var array $applications
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<div class="frm_hidden">
	<div id="frm-add-applications-content" class="inside frm-fields">
		<?php if ( $applications ) { ?>
			<p id="frm-add-applications-description" class="frm-add-applications-description"></p>
			<div class="frm_form_field">
				<label id="for_frm-add-applications-dropdown" for="frm-add-applications-dropdown"><?php esc_html_e( 'Applications', 'formidable' ); ?></label>
				<select id="frm-add-applications-dropdown" class="frm_multiselect" multiple="multiple">
					<?php foreach ( $applications as $application ) { ?>
						<option value="<?php echo esc_attr( $application['termId'] ); ?>"><?php echo esc_html( $application['name'] ); ?></option>
					<?php } ?>
				</select>
			</div>
			<p class="frm-add-applications-error frm_hidden" role="alert"></p>
		<?php } else { ?>
			<p class="frm-add-applications-description">
				<?php esc_html_e( 'You have not created any applications yet. Create an application to group related forms, views and pages together.', 'formidable-pro' ); ?>
			</p>
		<?php } ?>
	</div>
</div>
