<?php
	include_once(WPFC_WP_PLUGIN_DIR."/wp-fastest-cache-premium/pro/templates/img_optimizer_cron_job.php");
	include_once(WPFC_WP_PLUGIN_DIR."/wp-fastest-cache-premium/pro/templates/buy_credit.php");
?>

<style>
	.wpfc-image-view-tabs{display:flex;justify-content:flex-start;gap:2px;margin:12px 0 25px 0;border-bottom:1px solid #c3c4c7;}
	.wpfc-image-view-tab{padding:8px 15px;border:1px solid #c3c4c7;border-bottom:0;border-radius:4px 4px 0 0;background:#f0f0f1;color:#50575e;cursor:pointer;font-size:13px;}
	.wpfc-image-view-tab[aria-selected="true"]{background:#fff;color:#1d2327;font-weight:600;position:relative;top:1px;padding-bottom:9px;}
</style>

<div class="wpfc-image-view-tabs" role="tablist" aria-label="Image optimizer views">
	<button style="margin-left: 15px;" type="button" class="wpfc-image-view-tab" id="image-optimizer-tab" role="tab" aria-controls="wpfc-image-static-panel" aria-selected="true">Image Optimizer</button>
	<button style="margin-left: 2px;" type="button" class="wpfc-image-view-tab" id="image-list-tab" role="tab" aria-controls="wpfc-image-list" aria-selected="false">Image List</button>
    <button style="margin-left: 2px;" type="button" class="wpfc-image-view-tab" id="image-recheck-tab" role="tab" aria-controls="wpfc-image-recheck-panel" aria-selected="false">Recheck Images</button>
    <button style="margin-left: 2px;" type="button" class="wpfc-image-view-tab" id="auto-optimize-link" role="tab" aria-controls="wpfc-image-list" aria-selected="false">Auto Optimize</button>
</div>

<div id="wpfc-image-recheck-panel" role="tabpanel" aria-labelledby="image-recheck-tab" style="display: none; width: 100%; float: left; padding: 0px 20px; box-sizing: border-box;">
	<p>Check previously optimized images for missing or unoptimized image sizes, then optimize any that are missing.</p>
	<button type="button" id="wpfc-image-recheck-toggle" class="button button-primary">Start</button>
	<textarea id="wpfc-image-recheck-log" rows="14" readonly style="margin-top: 10px; width:100%;box-sizing:border-box;padding:10px;font-family:monospace;resize:vertical;" aria-live="polite" aria-label="Image recheck log"></textarea>
</div>



<div id="wpfc-image-static-panel" role="tabpanel" aria-labelledby="image-optimizer-tab" style="width:100%;float:left;" data-nonce="<?php echo wp_create_nonce('wpfc-statics-nonce'); ?>">
	<div style="float: left; width: 100%;">
		<div style="float:left;padding-left: 22px;padding-right:15px;">
			<div style="display: inline-block;">
				<div style="width: 150px; height: 150px; position: relative; border-top-left-radius: 150px; border-top-right-radius: 150px; border-bottom-right-radius: 150px; border-bottom-left-radius: 150px; background-color: #FFA726;">
					

					<div style="position: absolute; top: 0px; left: 0px; width: 150px; height: 150px; border-top-left-radius: 150px; border-top-right-radius: 150px; border-bottom-right-radius: 150px; border-bottom-left-radius: 150px; clip: rect(0px 150px 150px 75px);">
						<div id="wpfc-pie-chart-little" style="position: absolute; top: 0px; left: 0px; width: 150px; height: 150px; border-top-left-radius: 150px; border-top-right-radius: 150px; border-bottom-right-radius: 150px; border-bottom-left-radius: 150px; clip: rect(0px 75px 150px 0px); -webkit-transform: rotate(36deg); transform: rotate(0deg); background-color: #3ECF3C;"></div>
					</div>


					<div id="wpfc-pie-chart-big-container-first" style="display:none;position: absolute; top: 0px; left: 0px; width: 150px; height: 150px; border-top-left-radius: 150px; border-top-right-radius: 150px; border-bottom-right-radius: 150px; border-bottom-left-radius: 150px; clip: rect(0px 150px 150px 25px); -webkit-transform: rotate(0deg); transform: rotate(0deg);">
						<div style="position: absolute; top: 0px; left: 0px; width: 150px; height: 150px; border-top-left-radius: 150px; border-top-right-radius: 150px; border-bottom-right-radius: 150px; border-bottom-left-radius: 150px; clip: rect(0px 75px 150px 0px); -webkit-transform: rotate(180deg); transform: rotate(180deg); background-color: #3ECF3C;"></div>
					</div>
					<div id="wpfc-pie-chart-big-container-second-right" style="display:none;position: absolute; top: 0px; left: 0px; width: 150px; height: 150px; border-top-left-radius: 150px; border-top-right-radius: 150px; border-bottom-right-radius: 150px; border-bottom-left-radius: 150px; clip: rect(0px 150px 150px 75px); -webkit-transform: rotate(180deg); transform: rotate(180deg);">
						<div id="wpfc-pie-chart-big-container-second-left" style="position: absolute; top: 0px; left: 0px; width: 150px; height: 150px; border-top-left-radius: 150px; border-top-right-radius: 150px; border-bottom-right-radius: 150px; border-bottom-left-radius: 150px; clip: rect(0px 75px 150px 0px); -webkit-transform: rotate(90deg); transform: rotate(90deg); background-color: #3ECF3C;"></div>
					</div>

				</div>
				<div style="width: 114px;height: 114px;margin-top: -133px;background-color: white;margin-left: 18px;position: absolute;border-radius: 150px;">
					<p style="text-align:center;margin:27px 0 0 0;color: black;">Succeed</p>
					<p class="wpfc-loading-statics" id="wpfc-optimized-statics-percent" style="text-align: center; font-size: 18px; font-weight: bold; font-family: verdana; margin: -2px 0px 0px; color: black;"></p>
					<p style="text-align:center;margin:0;color: black;">%</p>
				</div>
			</div>
		</div>
		<div id="wpfc-statics-right" style="float: left;padding-left:12px;">
			<ul style="list-style: none outside none;float: left;">
				<li>
					<div style="background-color: #1E88E5;width:15px;height:15px;float:left;margin-top:4px;border-radius:5px;"></div>
					<div style="float:left;padding-left:6px;">All JPEG/PNG</div>
					<div class="wpfc-loading-statics" id="wpfc-optimized-statics-total_image_number" style="font-size: 14px; font-weight: bold; color: black; float: left; width: 65%; margin-left: 5px;"></div>
				</li>
				<li>
					<div style="background-color: #FFA726;width:15px;height:15px;float:left;margin-top:4px;border-radius:5px;"></div>
					<div style="float:left;padding-left:6px;">Pending</div>
					<div class="wpfc-loading-statics" id="wpfc-optimized-statics-pending" style="font-size: 14px; font-weight: bold; color: black; float: left; width: 65%; margin-left: 5px;"></div>
				</li>
				<li>
					<div style="background-color: #E53935;width:15px;height:15px;float:left;margin-top:4px;border-radius:5px;"></div>
					<div data-click-action="errors" style="float:left;padding-left:6px;width: 45%;cursor: pointer;">Errors</div>
					<div data-click-action="errors" class="wpfc-loading-statics" id="wpfc-optimized-statics-error" style="cursor: pointer;font-size: 14px; font-weight: bold; color: black; float: left; width: 45%; margin-left: 5px;"></div>
				</li>





				<li style="display:none;">
					<div style="float:left;padding-left:6px;">Server Location</div>
				</li>





			</ul>
			<ul style="list-style: none outside none;float: left;">
				<li>
					<div style="background-color: rgb(61, 207, 60);width:15px;height:15px;float:left;margin-top:4px;border-radius:5px;"></div>
					<div style="float:left;padding-left:6px;"><span>Optimized Images</span></div>
					<div class="wpfc-loading-statics" id="wpfc-optimized-statics-optimized" style="font-size: 14px; font-weight: bold; color: black; float: left; width: 65%; margin-left: 5px;"></div>
				</li>

				<li>
					<div style="background-color: #9E9E9E;width:15px;height:15px;float:left;margin-top:4px;border-radius:5px;"></div>
					<div data-click-action="excluded" style="cursor: pointer;float:left;padding-left:6px;"><span>Excluded</span></div>
					<div data-click-action="excluded" class="wpfc-loading-statics" id="wpfc-optimized-statics-excluded" style="cursor: pointer;font-size: 14px; font-weight: bold; color: black; float: left; width: 80%; margin-left: 5px;"></div>
				</li>

				<li>
					<div style="background-color: #2E7D32;width:15px;height:15px;float:left;margin-top:4px;border-radius:5px;"></div>
					<div style="float:left;padding-left:6px;"><span>Total Reduction</span></div>
					<style type="text/css">
						#wpfc-optimized-statics-reduction:not(.wpfc-loading-statics):after{ content: "" !important; }
					</style>
					<div class="wpfc-loading-statics" id="wpfc-optimized-statics-reduction" style="font-size: 14px; font-weight: bold; color: black; float: left; width: 80%; margin-left: 5px;"></div>
				</li>


				<li style="display: none;" id="wpfc-server-list"></li>



				
			</ul>

			<ul style="list-style: none outside none;float: left;">
				<li>
					<style type="text/css">
						.wpfc-credit-btn { background: none; border: none; padding: 4px; cursor: pointer; line-height: 1; } 
						.wpfc-credit-btn .dashicons { font-size: 20px; } .wpfc-refresh-credit .dashicons { color: #555; } 
						.wpfc-refresh-credit:hover .dashicons { color: #2271b1; /* WP blue */ } 
						.wpfc-buy-credit .dashicons { color: #2ea043; /* green */ } 
						.wpfc-buy-credit:hover .dashicons { color: #238636; }
					</style>

					<h1 style="margin-top:0;float:left;padding-top: 0;">Credit: <span id="wpfc-optimized-statics-credit" class="wpfc-loading-statics" style="display: inline-block; height: 16px; width: auto;min-width:25px;"></span> </h1>

					<button
						id="wpfc-refresh-image-credit-button"
				        class="wpfc-credit-btn wpfc-refresh-credit"
				        title="Refresh credit balance"
				        aria-label="Refresh credit balance">
				        <span class="dashicons dashicons-update"></span>
				    </button>

				    <button
				    	id="wpfc-buy-image-credit-button"
				        class="wpfc-credit-btn wpfc-buy-credit"
				        title="Buy more credits"
				        aria-label="Buy more credits">
				        <span class="dashicons dashicons-cart"></span>
				    </button>

				</li>
				<li>
					<input style="width:100%;height:65px;" id="wpfc-optimize-images-button" type="submit" value="Optimize All" class="button-primary" />
				</li>
				<li style="width:100%;margin-top:8px; display: none;">
					<label for="wpfc-image-optimization-queue" style="display:block;margin-bottom:4px;">Currently processing (up to 3 images)</label>
					<textarea id="wpfc-image-optimization-queue" rows="8" readonly style="width:100%;font-family:monospace;resize:vertical;" aria-label="Current image and sub-image paths"></textarea>
				</li>

				<li>
					<div id="wpfc-opt-image-loading" style="height: 10px; border: 1px solid rgb(61, 207, 60); width: 215px;padding: 2px;"><div style="height:100%;background-color: rgb(61, 207, 60);width:0;"></div></div>
				</li>

			</ul>
		</div>
	</div>
</div>
