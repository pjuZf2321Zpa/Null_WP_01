<?php
	class WPFC_PREMIUM_ADMIN{
		public function __construct(){
			
		}

		public function get_premium_version(){
			$response = wp_remote_get("http://api.wpfastestcache.net/user/".str_replace("www.", "", $_SERVER["HTTP_HOST"])."/type/".get_option("WpFc_api_key"), array('timeout' => 5));
	
			if (!$response || is_wp_error($response)) {
				return false;
			}else{
				if(wp_remote_retrieve_response_code($response) == 200){
					if(wp_remote_retrieve_body($response) == "free"){
						deactivate_plugins("wp-fastest-cache-premium/wpFastestCachePremium.php");
						$GLOBALS['wp_fastest_cache']->rm_folder_recursively(WPFC_WP_PLUGIN_DIR."/wp-fastest-cache-premium");
						$GLOBALS['wp_fastest_cache']->rm_folder_recursively(WPFC_WP_PLUGIN_DIR."/wp-fastest-cache-premium");
					}
				}
			}

			$wpfc_premium_version = "";
			if(file_exists(WPFC_WP_PLUGIN_DIR."/wp-fastest-cache-premium/wpFastestCachePremium.php")){
				if($data = @file_get_contents(WPFC_WP_PLUGIN_DIR."/wp-fastest-cache-premium/wpFastestCachePremium.php")){
					preg_match("/Version:\s*(.+)/", $data, $out);
					if(isset($out[1]) && $out[1]){
						$wpfc_premium_version = trim($out[1]);
					}
				}
			}
			return $wpfc_premium_version;
		}

	}
?>