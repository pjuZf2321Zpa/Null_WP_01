var WpFcStatics = {
	ajax_url: "",
	plugin_dir_url: "",
	current_page: 0,
	total_page: 0,
	per_page: 5,
	statics: {},
	country_code: "",
	lang_code: "",
	image_optimization_running: false,
	image_optimization_paused: false,
	image_optimization_request_active: false,
	image_optimization_group: null,
	image_recheck_running: false,
	image_recheck_paused: false,
	image_recheck_request_active: false,
	image_recheck_after_id: 0,
	image_recheck_images: [],
	image_recheck_index: 0,
	image_recheck_timer: null,
	init: function(ajax_url, plugin_dir_url, country_code, lang_code){
		this.country_code = country_code;
		this.lang_code = lang_code;
		this.ajax_url = ajax_url;
		this.plugin_dir_url = plugin_dir_url;
		this.set_click_event_show_hide_button();
		this.set_click_event_optimize_image_button();
		this.set_click_event_search_button();
		this.set_click_event_paging();
		this.set_click_event_clear_search_text();
		this.set_click_event_filter();
		this.set_click_event_per_page();
		this.set_click_event_buy_image_credit();
		this.set_click_event_refresh_image_credit();

		this.set_click_event_auto_optimize();
		this.set_click_event_recheck_images();
	},
	set_click_event_auto_optimize: function(){
		jQuery("#auto-optimize-link").click(function(){

			Wpfc_New_Dialog.dialog("wpfc-modal-auto-optimize", {
				close: function(e){
					let modal = jQuery(e).closest("div[id^='wpfc-modal-auto-optimize']");
					modal.remove();
				},
			}, function(dialog){
				Wpfc_New_Dialog.show_button("close");
			});
			
		});
	},
	set_click_event_recheck_images: function(){
		var self = this;
		jQuery("#image-recheck-tab").click(function(){
			jQuery(".wpfc-image-view-tab").attr("aria-selected", "false");
			jQuery(this).attr("aria-selected", "true");
			jQuery("#wpfc-image-static-panel, #wpfc-image-list").hide();
			jQuery("#wpfc-image-recheck-panel").show();
		});

		jQuery("#wpfc-image-recheck-toggle").click(function(){
			var $button = jQuery(this);
			if(self.image_recheck_running){
				if(self.image_recheck_paused){
					self.image_recheck_paused = false;
					$button.text("Pause").prop("disabled", false);
					self.append_image_recheck_log("Resumed.");
					if(!self.image_recheck_request_active){
						if(self.image_recheck_timer){
							window.clearTimeout(self.image_recheck_timer);
							self.image_recheck_timer = null;
						}
						self.process_next_image_recheck_item();
					}
				}else{
					self.image_recheck_paused = true;
					$button.text("Resume").prop("disabled", false);
					self.append_image_recheck_log("Paused after the current request.");
				}
				return;
			}

			self.image_recheck_running = true;
			self.image_recheck_paused = false;
			self.image_recheck_request_active = false;
			self.image_recheck_after_id = 0;
			self.image_recheck_images = [];
			self.image_recheck_index = 0;
			self.image_recheck_timer = null;
			jQuery("#wpfc-image-recheck-log").val("");
			$button.text("Pause").prop("disabled", false);
			self.append_image_recheck_log("Scan started.");
			self.load_next_image_recheck_attachment();
		});
	},
	append_image_recheck_log: function(message){
		var $log = jQuery("#wpfc-image-recheck-log");
		$log.val($log.val() + message + "\n");
		$log.scrollTop($log[0].scrollHeight);
	},
	load_next_image_recheck_attachment: function(){
		if(!this.image_recheck_running || this.image_recheck_paused){ return; }
		var self = this;
		this.image_recheck_request_active = true;
		jQuery.ajax({
			type: 'GET',
			url: self.ajax_url,
			dataType: 'json',
			cache: false,
			data: {
				action: 'wpfc_recheck_optimized_images_next',
				after_id: self.image_recheck_after_id,
				nonce: jQuery('#wpfc-image-static-panel').data('nonce')
			},
			error: function(){
				self.image_recheck_request_active = false;
				if(!self.image_recheck_running){ self.finish_image_recheck_stop(); return; }
				self.append_image_recheck_log("Could not load the next attachment. Scan stopped.");
				self.image_recheck_running = false;
				self.finish_image_recheck_stop();
			},
			success: function(response){
				self.image_recheck_request_active = false;
				if(!self.image_recheck_running){ self.finish_image_recheck_stop(); return; }
				if(!response || !response.success || !response.data){
					self.append_image_recheck_log("Invalid scan response. Scan stopped.");
					self.image_recheck_running = false;
					self.finish_image_recheck_stop();
					return;
				}
				if(response.data.done){
					self.append_image_recheck_log("Scan complete.");
					self.image_recheck_running = false;
					self.finish_image_recheck_stop();
					self.update_statics();
					return;
				}

				self.image_recheck_after_id = parseInt(response.data.attachment_id, 10) || self.image_recheck_after_id;
				self.image_recheck_images = Array.isArray(response.data.images) ? response.data.images : [];
				self.image_recheck_index = 0;
				if(self.image_recheck_images.length === 0){
					self.append_image_recheck_log("Attachment #" + self.image_recheck_after_id + ": no image files found.");
					if(self.image_recheck_paused){ return; }
					self.load_next_image_recheck_attachment();
					return;
				}
				self.append_image_recheck_log("Checking attachment #" + self.image_recheck_after_id + " (" + self.image_recheck_images.length + " images).");
				if(self.image_recheck_paused){ return; }
				self.process_next_image_recheck_item();
			}
		});
	},
	process_next_image_recheck_item: function(){
		if(!this.image_recheck_running || this.image_recheck_paused){ return; }
		if(this.image_recheck_index >= this.image_recheck_images.length){
			this.load_next_image_recheck_attachment();
			return;
		}

		var self = this;
		var image = this.image_recheck_images[this.image_recheck_index++];
		if(image.optimized){
			this.append_image_recheck_log("Already optimized: " + image.name);
			this.image_recheck_timer = window.setTimeout(function(){
				self.image_recheck_timer = null;
				self.process_next_image_recheck_item();
			}, 0);
			return;
		}

		this.append_image_recheck_log("Missing optimization; optimizing: " + image.name);
		this.image_recheck_request_active = true;
		this.optimize_image(this, this.image_recheck_after_id, false, false, false, function(success){
			self.image_recheck_request_active = false;
			self.append_image_recheck_log((success ? "Optimized: " : "Failed: ") + image.name);
			if(!self.image_recheck_running){ self.finish_image_recheck_stop(); return; }
			if(self.image_recheck_paused){ return; }
			self.process_next_image_recheck_item();
		}, 1, image.file, true);
	},
	finish_image_recheck_stop: function(){
		this.image_recheck_request_active = false;
		this.image_recheck_paused = false;
		if(this.image_recheck_timer){
			window.clearTimeout(this.image_recheck_timer);
			this.image_recheck_timer = null;
		}
		jQuery("#wpfc-image-recheck-toggle").text("Start").prop("disabled", false);
	},
	set_click_event_refresh_image_credit: function(){
		var self = this;

	    jQuery('#wpfc-refresh-image-credit-button').on('click', function () {

	        const $credit = jQuery('#wpfc-optimized-statics-credit');

		    $credit.addClass("wpfc-loading-statics");
			$credit.html("");

	        jQuery.ajax({
	            url: self.ajax_url,
	            type: 'POST',
	            dataType: 'json',
	            data: {
	                action: 'wpfc_refresh_credit',
	                nonce: jQuery('#wpfc-image-static-panel').data('nonce')
	            },
	            success: function (response) {
	                if (response.success) {
	                    $credit.text(response.data.credit);
	                }
	            },
	            complete: function () {
	            	$credit.removeClass("wpfc-loading-statics");
	            }
	        });
	    });

	},
	set_click_event_buy_image_credit: function(){
		var self = this;


		jQuery("#wpfc-buy-image-credit-button").click(function(){

			Wpfc_New_Dialog.dialog("wpfc-modal-buy-crdit", {
				finish: function(e){
					let modal = jQuery(e).closest("div[id^='wpfc-modal-buy-crdit']");

					if(modal.find("input[type='radio']:checked").length == 1){
						modal.find("form").submit();
					}

				},
			}, function(dialog){
				Wpfc_New_Dialog.show_button("finish");
			});

		});
	},
	event_on_shop: function(){
		jQuery("#wpfc-product-selection-list li").hover(function(e){
			jQuery("#wpfc-product-selection-list li label").removeClass("hover");
			jQuery(e.target).addClass("hover");
		});

		jQuery("#wpfc-product-selection-list li").click(function(e){
			jQuery("#wpfc-product-selection-list li label").removeClass("checked");
			jQuery(e.currentTarget).find("label").addClass("checked");
			jQuery(e.currentTarget).find("input").attr("checked", true);
		});

		jQuery("#wpfc-cancel-buy-credit").click(function(){
			jQuery("#wpfc-shop-modal").remove();
		});
	},
	set_click_event_per_page: function(){
		var self = this;
		
		jQuery("#wpfc-image-per-page").change(function(e){
			self.update_image_list(0);
		});
	},
	set_click_event_filter: function(){
		var self = this;
		
		jQuery("#wpfc-image-list-filter").change(function(e){
			self.update_image_list(0);
		});
	},
	set_click_event_clear_search_text: function(){
		var self = this;

		jQuery("span.deleteicon span").click(function(e){
			jQuery("#wpfc-image-search-input").val("");
			jQuery(e.target).addClass("cleared");
			self.update_image_list(0);
		});

		jQuery("#wpfc-image-search-input").keyup(function(e){
			if(jQuery(e.target).val().length > 0){
				jQuery("span.deleteicon span").removeClass("cleared");
			}else{
				jQuery("span.deleteicon span").addClass("cleared");

				if(e.keyCode == 8){
					self.update_image_list(0);
				}
			}

			if(e.keyCode == 13){
				self.update_image_list(0);
			}
		});
	},
	set_click_event_paging: function(){
		var self = this;
		jQuery(".wpfc-image-list-next-page, .wpfc-image-list-prev-page, .wpfc-image-list-first-page, .wpfc-image-list-last-page").click(function(e){
			if(jQuery(e.target).hasClass("wpfc-image-list-next-page")){
				self.update_image_list(self.current_page + 1);
			}else if(jQuery(e.target).hasClass("wpfc-image-list-prev-page")){
				self.update_image_list(self.current_page - 1);
			}else if(jQuery(e.target).hasClass("wpfc-image-list-first-page")){
				self.update_image_list(0);
			}else if(jQuery(e.target).hasClass("wpfc-image-list-last-page")){
				self.update_image_list(self.total_page - 1);
			}
		});
	},
	set_click_event_search_button: function(){
		var self = this;
		jQuery("#wpfc-image-search-button").click(function(){
			self.update_image_list(0);
		});
	},
	set_click_event_optimize_image_button: function(){
		var self = this;
		jQuery("#wpfc-optimize-images-button").click(function(){
			if(self.image_optimization_running){
				self.toggle_image_optimization_pause();
				return;
			}
			self.image_optimization_running = true;
			self.image_optimization_paused = false;
			self.image_optimization_group = null;
			jQuery(this).val("Pause").attr("disabled", false);
			self.load_image_optimization_queue();
		});
	},
	toggle_image_optimization_pause: function(){
		if(!this.image_optimization_running){ return; }
		var $button = jQuery("#wpfc-optimize-images-button");
		if(this.image_optimization_paused){
			this.image_optimization_paused = false;
			$button.val("Pause").attr("disabled", false);
			if(!this.image_optimization_request_active){
				if(this.image_optimization_group){
					this.process_next_queued_image();
				}else{
					this.load_image_optimization_queue();
				}
			}
			return;
		}

		this.image_optimization_paused = true;
		if(this.image_optimization_request_active){
			$button.val("Pausing...").attr("disabled", true);
		}else{
			$button.val("Resume").attr("disabled", false);
		}
	},
	stop_image_optimization_queue: function(){
		this.image_optimization_running = false;
		this.image_optimization_paused = false;
		this.image_optimization_request_active = false;
		this.image_optimization_group = null;
		jQuery("#wpfc-optimize-images-button").val("Optimize All").attr("disabled", false);
	},
	load_image_optimization_queue: function(){
		var self = this;
		if(!this.image_optimization_running || this.image_optimization_paused){ return; }
		var $queue = jQuery("#wpfc-image-optimization-queue");
		$queue.val("Loading the next image and its sub-images...");
		this.image_optimization_request_active = true;
		jQuery.ajax({
			type: 'GET',
			url: self.ajax_url,
			dataType: 'json',
			cache: false,
			data: {
				action: 'wpfc_get_image_optimization_queue_ajax_request',
				nonce: jQuery('#wpfc-image-static-panel').data('nonce')
			},
			error: function(){
				self.stop_image_optimization_queue();
				$queue.val("");
				alert("Could not load the image optimization queue. Please retry.");
			},
			success: function(response){
				self.image_optimization_request_active = false;
				if(!response || response.success !== "success" || !Array.isArray(response.images)){
					$queue.val("");
					self.stop_image_optimization_queue();
					alert(response && response.message ? response.message : "Could not load the image optimization queue.");
					return;
				}

				self.image_optimization_group = {images: response.images, next: 0, active: 0, completed: 0, activeIndexes: {}, failed: false};
				$queue.val("");
				if(response.images.length === 0){
					$queue.val("");
					jQuery("#wpfc-opt-image-loading div").width("0%");
					self.stop_image_optimization_queue();
					self.update_statics();
					return;
				}

				if(self.image_optimization_paused){
					jQuery("#wpfc-optimize-images-button").val("Resume").attr("disabled", false);
					return;
				}
				self.process_next_queued_image();
			}
		});
	},
	process_next_queued_image: function(){
		if(!this.image_optimization_running || this.image_optimization_paused || !this.image_optimization_group){ return; }
		var self = this;
		var group = this.image_optimization_group;
		var images = group.images;
		var $queue = jQuery("#wpfc-image-optimization-queue");
		var update_active_queue = function(){
			var active_images = images.filter(function(image, index){ return group.activeIndexes[index]; });
			$queue.val(active_images.map(function(image){ return image.name; }).join("\n"));
		};
		if(group.completed === images.length && group.active === 0){
			this.image_optimization_group = null;
			this.update_statics();
			this.load_image_optimization_queue();
			return;
		}

		while(group.active < 3 && group.next < images.length && !group.failed && !this.image_optimization_paused){
			(function(index){
				var image = images[index];
				group.active++;
				group.activeIndexes[index] = true;
				update_active_queue();
				self.image_optimization_request_active = true;
				self.optimize_image(self, image.id, false, false, false, function(success){
					if(self.image_optimization_group !== group){ return; }
					group.active--;
					delete group.activeIndexes[index];
					self.image_optimization_request_active = group.active > 0;
					if(success){ group.completed++; }
					update_active_queue();
					jQuery("#wpfc-opt-image-loading div").width((group.completed / images.length * 100) + "%");

					if(!success){ group.failed = true; }
					if(group.failed){
						if(group.active === 0){
							self.stop_image_optimization_queue();
							self.update_statics();
							alert("Image optimization stopped. Remaining images are still pending and can be retried.");
						}
						return;
					}
					if(self.image_optimization_paused){
						if(group.active === 0){
							jQuery("#wpfc-optimize-images-button").val("Resume").attr("disabled", false);
						}
						return;
					}
					self.process_next_queued_image();
				}, 1, image.file);
			})(group.next++);
		}

		if(group.failed && group.active === 0){
			this.stop_image_optimization_queue();
			this.update_statics();
			alert("Image optimization stopped. Remaining images are still pending and can be retried.");
			return;
		}
		if(this.image_optimization_paused && group.active === 0){
			this.image_optimization_request_active = false;
			jQuery("#wpfc-optimize-images-button").val("Resume").attr("disabled", false);
		}
	},
	update_image_list: function(page, search){
		var self = this;
		self.per_page = jQuery("#wpfc-image-per-page").val();

		if(page !== 0 && (page < 0 || (page > self.total_page - 1))){
			return;
		}

		jQuery("#revert-loader").show();

		var search = jQuery("#wpfc-image-search-input").val();
		var filter = jQuery("#wpfc-image-list-filter").val();

		jQuery.ajax({
			type: 'GET',
			url: self.ajax_url,
			data : {"action": "wpfc_update_image_list_ajax_request", "page": page, "search" : search, "filter" : filter, 'per_page' : self.per_page, 'nonce' : jQuery('#wpfc-image-static-panel').data('nonce')},
			dataType : "json",
			cache: false, 
			success: function(data){
				if(typeof data != "undefined" && data){
					self.total_page = Math.ceil(data.result_count/self.per_page);
					self.total_page = self.total_page > 0 ? self.total_page : 1;

					self.current_page = page;

					jQuery(".wpfc-current-page").text(self.current_page + 1);
					jQuery("#the-list").html(data.content);
					jQuery(".wpfc-total-pages").html(self.total_page);
					jQuery("#revert-loader").hide();

					jQuery(".wpfc-image-list-prev-page").removeClass("disabled");
					jQuery(".wpfc-image-list-next-page").removeClass("disabled");
					jQuery(".wpfc-image-list-first-page").removeClass("disabled");
					jQuery(".wpfc-image-list-last-page").removeClass("disabled");

					if((self.current_page + 1) == self.total_page){
						jQuery(".wpfc-image-list-next-page").addClass("disabled");
						jQuery(".wpfc-image-list-last-page").addClass("disabled");
					}

					if(self.current_page === 0){
						jQuery(".wpfc-image-list-prev-page").addClass("disabled");
						jQuery(".wpfc-image-list-first-page").addClass("disabled");
					}

					self.set_click_event_revert_image();
					self.set_click_event_collapse_image_details();

				}else{
					alert("Error: Image List Problem. Please refresh...");
				}
			}
		});
	},
	set_click_event_show_hide_button: function(){
		var self = this;
		jQuery("#image-optimizer-tab").click(function(){
			jQuery(".wpfc-image-view-tab").attr("aria-selected", "false");
			jQuery(this).attr("aria-selected", "true");
			jQuery("#wpfc-image-list, #wpfc-image-recheck-panel").hide();
			jQuery("#wpfc-image-static-panel").show();
			self.update_statics();
		});

		jQuery("#image-list-tab").click(function(){
			jQuery(".wpfc-image-view-tab").attr("aria-selected", "false");
			jQuery(this).attr("aria-selected", "true");
			jQuery("#wpfc-image-recheck-panel").hide();
			jQuery("#wpfc-image-list").show();
			jQuery("#wpfc-image-static-panel").hide();
			self.update_image_list(0);
		});

		jQuery("div[data-click-action='errors']").click(function(){
			jQuery(".wpfc-image-view-tab").attr("aria-selected", "false");
			jQuery("#image-list-tab").attr("aria-selected", "true");
			jQuery("#wpfc-image-recheck-panel").hide();
			jQuery("#wpfc-image-list").show();
			jQuery("#wpfc-image-static-panel").hide();
			jQuery("#wpfc-image-list-filter").val("error_code");
			self.update_image_list(0);
		});

		jQuery("div[data-click-action='excluded']").click(function(){
			jQuery(".wpfc-image-view-tab").attr("aria-selected", "false");
			jQuery("#image-list-tab").attr("aria-selected", "true");
			jQuery("#wpfc-image-recheck-panel").hide();
			jQuery("#wpfc-image-list").show();
			jQuery("#wpfc-image-static-panel").hide();
			jQuery("#wpfc-image-list-filter").val("excluded");
			self.update_image_list(0);
		});
	},
	wpfc_get_server_time: function(servers){
		var html = function(value){
			return '<div style="width: 70px;float:left;">' + 
									'<input value="' + value.url + '" name="wpfc-server-url" type="text" style="display:none;">' +
									'<input value="' + value.key + '" name="wpfc-server-location" type="radio" style="vertical-align: top; padding-top: 0px; margin-top: 0px;"><img>' + 
									'<div style="color:black;float: right; width: 62px; text-align: center;font-weight:bold;">' + value.location + '</div>' + 
									'<div class="server-time" style="float: right; width: 62px; text-align: center;font-weight:bold;">' + value.time.time + '</div>' + 
								'</div>';
		};

		var ajaxTime= new Date().getTime();
		var div;

		jQuery.ajax({
			type: 'GET', 
			url: WpFcCacheStatics.admin_ajax_url,
			data : {"action" : "get_server_time_ajax_request", "servers" : servers, "nonce"  : jQuery('#wpfc-image-static-panel').data('nonce')},
			dataType : "json",
			cache: false,
			error: function(x, t, m) {
				//alert(t);
				jQuery(servers).each(function(key, value){
					jQuery("#wpfc-server-list").prepend(html(value));
				});
			},
			success: function(data){
				jQuery(data).each(function(key, value){
					if(value.time.success){

						if(jQuery("#wpfc-server-list > div").length == 0){
							jQuery("#wpfc-server-list").prepend(html(value));
						}else{
							jQuery("#wpfc-server-list > div").each(function(i, e){
								if(value.time.time < parseFloat(jQuery(e).find("div.server-time").text())){
									jQuery(e).before(html(value));
									return false;
								}else{
									if(jQuery(e).next().length == 0){
										jQuery(e).after(html(value));
										return false;
									}else{
										if(value.time.time < parseFloat(jQuery(e).next().find("div.server-time").text())){
											jQuery(e).after(html(value));
											return false;
										}
									}
								}
							});
						}

					}else{
						if(key === 0){
							alert("Neither fsockopen nor curl exist in the server");
						}
					}
				});
			},
			timeout: 10000
		});
	},
	wpfc_get_servers: function(){
		var self = this;
		var servers = {

            "na": [
                {"key": "la", "time":0, "location":"Los Ang", "url":"https://la.wpfastestcache.com"},
                {"key": "dal", "time":0, "location":"Dallas", "url":"https://dallas.wpfastestcache.com"},
                {"key": "dc", "time":0, "location":"New York", "url":"https://dc.wpfastestcache.com"},
                {"key": "stlo", "time":0, "location":"St. Louis", "url":"https://stlouis.wpfastestcache.com"}
            ],

            "euw": [
                {"key": "fran", "time":0, "location":"Frankfurt", "url":"https://frankfurt.wpfastestcache.com"},
                {"key": "fr", "time":0, "location":"France", "url":"https://fr.wpfastestcache.com"},
                {"key": "it", "time":0, "location":"Italy", "url":"https://it.wpfastestcache.com"},
                {"key": "nl", "time":0, "location":"Holland", "url":"https://nl.wpfastestcache.com"},
                {"key": "ch", "time":0, "location":"CH", "url":"https://ch.wpfastestcache.com"},
                {"key": "uk", "time":0, "location":"UK", "url":"https://uk.wpfastestcache.com"}
            ],

            "eue": [
                {"key": "at", "time":0, "location":"AT", "url":"https://at.wpfastestcache.com"},
                {"key": "pl", "time":0, "location":"Poland", "url":"https://pl.wpfastestcache.com"},
                {"key": "bg", "time":0, "location":"Bg", "url":"https://bulgaria.wpfastestcache.com"},
                {"key": "tr", "time":0, "location":"Turkey", "url":"https://tr.wpfastestcache.com"}
            ],

            "AT": [
                {"key": "at", "time":0, "location":"AT", "url":"https://at.wpfastestcache.com"},
                {"key": "ch", "time":0, "location":"CH", "url":"https://ch.wpfastestcache.com"},
                {"key": "it", "time":0, "location":"Italy", "url":"https://it.wpfastestcache.com"},
                {"key": "pl", "time":0, "location":"Poland", "url":"https://pl.wpfastestcache.com"}
            ],

            "CH": [
                {"key": "ch", "time":0, "location":"CH", "url":"https://ch.wpfastestcache.com"},
                {"key": "at", "time":0, "location":"AT", "url":"https://at.wpfastestcache.com"},
                {"key": "it", "time":0, "location":"Italy", "url":"https://it.wpfastestcache.com"}
            ],

            "DE": [
                {"key": "fran", "time":0, "location":"Frankfurt", "url":"https://frankfurt.wpfastestcache.com"},
                {"key": "ch", "time":0, "location":"CH", "url":"https://ch.wpfastestcache.com"},
                {"key": "fr", "time":0, "location":"France", "url":"https://fr.wpfastestcache.com"},
                {"key": "it", "time":0, "location":"Italy", "url":"https://it.wpfastestcache.com"},
                {"key": "nl", "time":0, "location":"Holland", "url":"https://nl.wpfastestcache.com"},
                {"key": "at", "time":0, "location":"AT", "url":"https://at.wpfastestcache.com"}
            ],

            "ES": [
                {"key": "es", "time":0, "location":"ES", "url":"https://es.wpfastestcache.com"},
                {"key": "uk", "time":0, "location":"UK", "url":"https://uk.wpfastestcache.com"},
                {"key": "nl", "time":0, "location":"Holland", "url":"https://nl.wpfastestcache.com"},
                {"key": "fr", "time":0, "location":"France", "url":"https://fr.wpfastestcache.com"}
            ],

            "FR": [
                {"key": "fr", "time":0, "location":"France", "url":"https://fr.wpfastestcache.com"},
                {"key": "nl", "time":0, "location":"Holland", "url":"https://nl.wpfastestcache.com"},
                {"key": "uk", "time":0, "location":"UK", "url":"https://uk.wpfastestcache.com"}
            ],

            "GB": [
                {"key": "uk", "time":0, "location":"UK", "url":"https://uk.wpfastestcache.com"},
                {"key": "nl", "time":0, "location":"Holland", "url":"https://nl.wpfastestcache.com"},
                {"key": "fr", "time":0, "location":"France", "url":"https://fr.wpfastestcache.com"}
            ],

            "IT": [
                {"key": "it", "time":0, "location":"Italy", "url":"https://it.wpfastestcache.com"},
                {"key": "at", "time":0, "location":"AT", "url":"https://at.wpfastestcache.com"},
                {"key": "ch", "time":0, "location":"CH", "url":"https://ch.wpfastestcache.com"}
            ],

            "as": [
                {"key": "au", "time":0, "location":"Australia", "url":"https://au.wpfastestcache.com"},
                {"key": "jp", "time":0, "location":"Japan", "url":"https://jp.wpfastestcache.com"}
            ]


					};

		//http://www.countryareacode.net/en/list-of-countries-according-to-continent/
		var america = "AI, AR, AW, BS, BB, BZ, BM, BO, BR, VG, CA, KY, CL, CO, CR, CU, CW, DM, DO, EC, SV, FK, GL, GP, GT, GY, HT, HN, JM, MX, MS, NI, PA, PY, PE, PR, BL, KN, LC, MF, PM, VC, SR, TT, US, UY, VE";
		var oceania = "AS, AU, CK, TL, FJ, PF, GU, KI, MH, FM, NR, NC, NZ, NU, NF, MP, PW, PG, PN, WS, SB, TK, TV, VU";
		var asia = "AF, AM, AZ, BH, BD, BT, BN, KH, CN, GE, HK, IN, ID, IR, IQ, JP, JO, KW, KG, LA, LB, MO, MY, MV, MN, MM, NP, KP, OM, PK, PH, QA, SA, SG, KR, LK, SY, TW, TJ, TH, TM, AE, UZ, VN, YE";
			
		var w_europe = "AD, AT, BE, DK, FO, FR, DE, GI, IS, IE, IM, IT, LI, LU, MT, MC, NL, PT, SM, ES, CH, GB, VA";
		var e_europe = "AL, BY, BA, BG, HR, CY, CZ, EE, FI, GR, HU, KZ, IL, XK, LV, LT, MK, MD, ME, NO, PL, RO, RU, RS, SK, SI, SE, TR, UA";

		var africa = "DZ, AO, BJ, BW, BF, BI, CM, CV, CF, KM, CD, DJ, EG, GQ, ER, ET, GA, GM, GH, GN, GW, CI, KE, LS, LR, LY, MG, MW, ML, MR, MU, MA, MZ, NA, NE, NG, CG, RE, RW, SH, ST, SN, SC, SL, SO, ZA, SS, SD, SZ, TZ, TG, TN, UG, EH, ZM, ZW";
		var time_out = 4000;

		jQuery("#revert-loader-toolbar").show();
		jQuery("#wpfc-server-list").html("");


		if(self.country_code){
			if (servers[self.country_code]) {
		        self.wpfc_get_server_time(servers[self.country_code]);
		    } else if(america.search(self.country_code) > -1){
				self.wpfc_get_server_time(servers.na);
			}else if(w_europe.search(self.country_code) > -1){
				self.wpfc_get_server_time(servers.euw);
			}else if(e_europe.search(self.country_code) > -1){
				self.wpfc_get_server_time(servers.eue);
			}else if(oceania.search(self.country_code) > -1){
				self.wpfc_get_server_time(servers.as);
			}else if(asia.search(self.country_code) > -1){
				self.wpfc_get_server_time(servers.as);

				time_out = 5000;
			}else if(africa.search(self.country_code) > -1){
				self.wpfc_get_server_time(servers.euw);
				self.wpfc_get_server_time(servers.eue);
			}else if(self.country_code == "XX"){
				self.wpfc_get_server_time(servers.na);
				self.wpfc_get_server_time(servers.euw);
				self.wpfc_get_server_time(servers.as);
			}else{
				setTimeout(function(){
					alert("Unknown Country Code: " + self.country_code);
				}, 1000);
			}
		}else{
			if(typeof self.lang_code != "undefined" && self.lang_code == "ru_RU"){
				self.wpfc_get_server_time(servers.eue);
				self.wpfc_get_server_time(servers.as);
			}else if(typeof self.lang_code != "undefined" && self.lang_code == "zh_CN"){
				self.wpfc_get_server_time(servers.as);
			}else{
				setTimeout(function(){
					alert("Empty Country Code!");
				}, 1000);
			}
		}



		setTimeout(function(){
			jQuery("#revert-loader-toolbar").hide();
			jQuery("#wpfc-optimize-images-button").attr("disabled", false);
		}, time_out);
		//self.wpfc_get_server_time(server_key, value);
	},
	optimize_image: function(self, id, recursive, last, image_index, done, attempt, image_file, recheck_image){
		attempt = attempt || 1;
		var retry_request = function(){
			setTimeout(function(){
				self.optimize_image(self, id, recursive, last, image_index, done, attempt + 1, image_file, recheck_image);
			}, 900);
		};

		function set_loading_bar(percentage){
			jQuery("#wpfc-opt-image-loading div").width(percentage + "%");
		};

		// if(typeof id == "undefined"){
		// 	jQuery("[id^='wpfc-optimized-statics-']").addClass("wpfc-loading-statics");
		// 	jQuery("[id^='wpfc-optimized-statics-']").html("");
		// }


		if(jQuery("#wpfc-server-list input[name='wpfc-server-url']").length > 0){
			var server_url = jQuery("#wpfc-server-list input[name='wpfc-server-url']").val();
		}else{
			WpFcStatics.wpfc_get_servers();
			return 0;
		}
		
		if(!id){
			id = "";
		}

		jQuery.ajax({
			type: 'GET', 
			url: self.ajax_url,
			dataType : "json",
			data : {"action": "wpfc_optimize_image_ajax_request", "id" : id, "last" : last, "image_index": image_index, "image_file": image_file, "recheck_image": recheck_image ? 1 : 0, "server_url": server_url, 'nonce' : jQuery('#wpfc-image-static-panel').data('nonce')},
			cache: false,
			timeout: 60000,
			error: function(x, t, m) {
				if(attempt < 3){
					retry_request();
					return;
				}
				if(typeof done === "function"){
					done(false);
					return;
				}
				jQuery("#wpfc-optimize-images-button").attr("disabled", false);
				self.update_statics();
				alert("Image optimization failed after 3 attempts. Please retry Optimize All.");
			},
			success: function(data){
				if(!data || data.success != "success"){
					if(attempt < 3){
						retry_request();
						return;
					}
					if(typeof done === "function"){
						done(false);
						return;
					}
					jQuery("#wpfc-optimize-images-button").attr("disabled", false);
					self.update_statics();
					alert(data && data.message ? data.message : "Image optimization failed after 3 attempts.");
					return;
				}

				if(typeof done === "function"){
					done(true);
					return;
				}

				if(data && data.success == "success"){
					if(data.message != "finish"){

						console.log(data);
						if(Array.isArray(data.sub_images)){
							var indexes = data.sub_images;
							if(indexes.length === 0){
								self.update_statics(function(){
									set_loading_bar(0);
									if(recursive){ self.optimize_image(self, false, true, false); }
								});
								return;
							}

							var next_worker = 0;
							var active_workers = 0;
							var completed_workers = 0;
							var worker_failed = false;
							var run_next_workers = function(){
								if(worker_failed){ return; }
								if(completed_workers === indexes.length){
									self.update_statics(function(){
										set_loading_bar(0);
										if(recursive){ self.optimize_image(self, false, true, false); }
									});
									return;
								}
								while(active_workers < 4 && next_worker < indexes.length){
									(function(index){
										next_worker++;
										active_workers++;
										self.optimize_image(self, data.id, false, false, index, function(success){
											active_workers--;
											if(worker_failed){ return; }
											if(!success){
												worker_failed = true;
												jQuery("#wpfc-optimize-images-button").attr("disabled", false);
												self.update_statics();
												alert("An image could not be optimized. Please retry Optimize All.");
												return;
											}
											completed_workers++;
											set_loading_bar((completed_workers / indexes.length) * 100);
											run_next_workers();
										});
									})(indexes[next_worker]);
								}
							};
							run_next_workers();
							return;
						}

						//to check first call or not
						set_loading_bar(data.percentage);

						if(data.percentage == 100){

							if(id){
								if(recursive){
									self.optimize_image(self, false, true, false);
								}
							}else{
								self.update_statics(function(){
									set_loading_bar(0);

									if(recursive){
										self.optimize_image(self, false, true, false);
									}
								});
							}

						}else{
							if(recursive){
								self.optimize_image(self, data.id, true, false);
							}
						}
					}else{
						jQuery("#wpfc-optimize-images-button").attr("disabled", false);
						self.update_statics();
					}
				}else{
					self.update_statics();
					if(data && typeof data.message != "undefined" && data.message){

						if(data.message.match(/Error\sCode\:\s101/) || data.message.match(/^500$/)){
							if(jQuery("#wpfc-opt-image-loading div").width() > 0){
								if(recursive){
									setTimeout(function(){
										self.optimize_image(self, id, true, false);
									}, 900);
								}
							}
						}else{
							if(data.message.match(/no\sdecode\sdelegate\sfor\sthis\simage\sformat/i)){
								// toDO
							}

							if(data.message.match(/text\schunk\(s\)\sfound\safter\sPNG\sIDAT\s\(fixed\)/i) || 
								data.message.match(/cURL\serror\s28\:\sResolving\stimed\sout\safter/i)){
								//[minor] Text chunk(s) found after PNG IDAT (fixed)
								//cURL error 28: Resolving timed out after 10000 milliseconds

								if(recursive){
									setTimeout(function(){
										self.optimize_image(self, id, true, false);
									}, 900);
								}
							}else{
								alert(data.message);
								jQuery("#wpfc-optimize-images-button").attr("disabled", false);
							}
						}

					}else{
						alert("Please try later...");
					}
				}
			}
		});
	},
	update_statics: function(callback){
		var self = this;
		var credit = false;
		var str_callback = false;

		jQuery("[id^='wpfc-optimized-statics-']").addClass("wpfc-loading-statics");
		jQuery("[id^='wpfc-optimized-statics-']").html("");

		if(callback){
			str_callback = callback.toString();

			if(str_callback.match(/set_loading_bar\(0\)/)){
				credit = true;
			}
		}

		jQuery.ajax({
			type: 'GET', 
			url: self.ajax_url,
			dataType : "json",
			data : {"action": "wpfc_statics_ajax_request", "credit" : credit, 'nonce' : jQuery('#wpfc-image-static-panel').data('nonce')},
			cache: false, 
			success: function(data){
				if(callback){ callback(); }
				self.statics = data;
				self.modify_statics_html();
			}
		});
	},
	modify_statics_html: function(){
		var self = this;
		jQuery.each(this.statics, function(e, i){
			var el = jQuery("#wpfc-optimized-statics-" + e);
			if(el.length === 1){
				if(e == "percent"){
					var percent = i*3.6;

					if(percent > 180){
						jQuery("#wpfc-pie-chart-big-container-first").show();
						jQuery("#wpfc-pie-chart-big-container-second-right").show();
						jQuery('#wpfc-pie-chart-big-container-second-left').animate({  borderSpacing: (percent - 180) }, {
						    step: function(now,fx) {
						      jQuery(this).css('-webkit-transform','rotate('+now+'deg)'); 
						      jQuery(this).css('-moz-transform','rotate('+now+'deg)');
						      jQuery(this).css('transform','rotate('+now+'deg)');
						    },
						    duration:'slow'
						},'linear');

					}else{
						jQuery("#wpfc-pie-chart-big-container-first").hide();
						jQuery("#wpfc-pie-chart-big-container-second-right").hide();

						jQuery('#wpfc-pie-chart-little').animate({  borderSpacing: percent }, {
						    step: function(now,fx) {
						      jQuery(this).css('-webkit-transform','rotate('+now+'deg)'); 
						      jQuery(this).css('-moz-transform','rotate('+now+'deg)');
						      jQuery(this).css('transform','rotate('+now+'deg)');
						    },
						    duration:'slow'
						},'linear');
					}
				}

				el.removeClass("wpfc-loading-statics");
				el.html(i);
			}
		});
	},
	set_click_event_collapse_image_details: function(){
		jQuery("td.open-image-details").click(function(e){

			var sub = jQuery("tr[post-id='" + jQuery(e.target).closest("tr[post-id]").attr("post-id") + "'][post-type='detail']");

			if(sub.is(":hidden")){
				sub.show();
				jQuery(this).find("span").attr('class', 'dashicons dashicons-arrow-up-alt2')
			}else{
				sub.hide();
				jQuery(this).find("span").attr('class', 'dashicons dashicons-arrow-down-alt2');
			}

		});
	},
	set_click_event_revert_image: function(){
		var self = this;
		jQuery("div.revert").click(function(e){
			jQuery("#revert-loader").show();

			var id = jQuery(e.target).find("input")[0].value;

			jQuery.ajax({
				type: 'GET', 
				url: self.ajax_url,
				dataType : "json",
				data : {"action": "wpfc_revert_image_ajax_request", "id" : id, 'nonce' : jQuery('#wpfc-image-static-panel').data('nonce')},
				cache: false, 
				success: function(data){
					try{
						if(data.success == "true"){
							self.update_statics(function(){
								jQuery("tr[post-id='" + id + "']").hide(100, function(){
									if(jQuery("#the-list tr:visible").length === 0){
										self.update_image_list(0);
									}else{
										jQuery("#revert-loader").hide();
									}
								});
							});
						}else if(data.success == "false"){
							jQuery("#revert-loader").hide();
							if(typeof data.message != "undefined" && data.message){
								alert(data.message);
							}else{
								alert("Revert Image: " + 'data.success == "false"');
							}
						}

					}catch(err){
						alert("Revert Image: " + err.message);
					}
				}
			});

		});
	}
};
