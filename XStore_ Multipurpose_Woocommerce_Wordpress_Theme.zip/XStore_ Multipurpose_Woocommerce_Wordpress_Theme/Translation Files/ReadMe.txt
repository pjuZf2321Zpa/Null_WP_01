Hi there,

You can find translation files in our GlotPress project https://www.8theme.com/glotpress/projects/xstore/xstore/

This allows you to add your translation. Just follow a few steps https://make.wordpress.org/polyglots/handbook/translating/glotpress-translate-wordpress-org/

The final translations could then be downloaded and copied into the plugins and themes https://www.8theme.com/documentation/xstore/theme-translation/base-theme-translation/

Regards
The 8Theme team