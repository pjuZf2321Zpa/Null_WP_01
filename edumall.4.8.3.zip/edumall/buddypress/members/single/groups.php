<?php
/**
 * BuddyPress - Users Groups
 *
 * @since   3.0.0
 * @version 12.0.0
 */

defined( 'ABSPATH' ) || exit;
?>
<?php if ( bp_is_my_profile() ) : ?>
	<nav class="<?php bp_nouveau_single_item_subnav_classes(); ?>" id="subnav" role="navigation"
	     aria-label="<?php esc_attr_e( 'Groups menu', 'edumall' ); ?>">
		<ul id="member-secondary-nav" class="subnav bp-priority-subnav-nav-items">
			<?php bp_get_template_part( 'members/single/parts/item-subnav' ); ?>
		</ul>
		<?php bp_nouveau_member_hook( '', 'secondary_nav' ); ?>
	</nav>
<?php endif; ?>

<?php /*if ( ! bp_is_current_action( 'invites' ) ) : */ ?><!--
	<?php /*bp_get_template_part( 'common/search-and-filters-bar' ); */ ?>
--><?php /*endif; */ ?>

<?php

switch ( bp_current_action() ) :

	// Home/My Groups
	case 'my-groups':
		bp_nouveau_member_hook( 'before', 'groups_content' );
		?>

		<div class="groups mygroups" data-bp-list="groups">
			<div id="bp-ajax-loader"><?php bp_nouveau_user_feedback( 'member-groups-loading' ); ?></div>
		</div>

		<?php
		bp_nouveau_member_hook( 'after', 'groups_content' );
		break;

	// Group Invitations
	case 'invites':
		bp_get_template_part( 'members/single/groups/invites' );
		break;

	// Any other
	default:
		bp_get_template_part( 'members/single/plugins' );
		break;
endswitch;
