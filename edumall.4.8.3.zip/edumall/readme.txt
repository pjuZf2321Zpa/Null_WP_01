=== Edumall ===

Contributors: thememove
Tags: editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready

Requires at least: 5.0
Tested up to: 5.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Edumall – Education WordPress Theme

== Description ==

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

= How do I protect the sign-up and login forms with a CAPTCHA? =

Since 4.8.0 the theme ships a built-in CAPTCHA for its account forms, and everything is configured under Appearance > Customize > CAPTCHA.

Out of the box the "Honeypot" option is already active on the registration forms, so a fresh install is protected against ordinary spam bots without any setup. A honeypot adds a decoy field that only an automated script fills in; real visitors never see it and nothing extra is asked of them.

A sign-up is accepted only if the decoy field arrives with the submission and arrives empty, so both the bots that fill in every field they find and the scripts that post straight to the endpoint without reading the form are turned away. Please still treat the honeypot as the free, zero-friction baseline rather than a guarantee: a bot written for your site can replay the form exactly and leave the decoy empty. If you are being targeted deliberately, or spam continues after enabling it, switch to one of the CAPTCHA services below - those verify every submission against the provider itself.

If you use a full-page cache, clear it after updating and again whenever you turn the CAPTCHA on or change provider, so visitors are not served a copy of a page from before the field existed. With the Honeypot this is forgiving: submissions missing the decoy are accepted for a 48-hour grace window that starts when it first goes live (its first render, verification or admin page load). With reCAPTCHA, Turnstile or hCaptcha there is no such window - a cached page carries no challenge, so the submission arrives with no token and is refused, and the visitor is told the CAPTCHA failed on a form that never showed them one. This covers every cached page carrying a guarded form, not only the Register Form widget.

A notice in the WordPress admin reports how many submissions were rejected in the last 7 days, split by cause. Automated submissions look the same as a broken form from the server's point of view, so as a rule the numbers just mean the protection is working and no action is needed. Act only if real visitors report they cannot register.

To use a CAPTCHA service instead:

1. Create keys for the provider you want to use:
   - Google reCAPTCHA v2 ("I'm not a robot" checkbox) or reCAPTCHA v3 (invisible, score-based): https://www.google.com/recaptcha/admin/create
   - Cloudflare Turnstile: https://dash.cloudflare.com/?to=/:account/turnstile
   - hCaptcha: https://dashboard.hcaptcha.com/sites
2. Go to Appearance > Customize > CAPTCHA.
3. Pick the provider under "CAPTCHA Provider" and paste the Site Key and Secret Key. The key type must match the provider - a v2 Checkbox key will not work with the v3 option and vice versa.
4. Choose which forms are protected under "Protected Forms". "Registration" is on by default and covers the account popup, the Register Form Elementor widget, the instructor registration popup, and the WordPress (wp-login.php), Tutor LMS student / instructor and WooCommerce My Account registration forms. "Login" and "Lost Password" cover the theme's account popups plus the wp-login.php, Tutor LMS and WooCommerce login and lost-password forms; "Comments" covers the guest comment form and WooCommerce product reviews.
5. For reCAPTCHA v3 only, "Score Threshold" (0 - 1, default 0.5) controls how strict the invisible check is: raise it if spam still gets through, lower it if real visitors get rejected.
6. Optional: "Show Login Challenge After" shows the login challenge only once an IP address has failed to log in that many times within 15 minutes (0 = always); "If the Provider Is Unreachable" decides whether submissions are blocked (default) or let through for two minutes while the verification service is down; "Whitelisted IP Addresses" skips the CAPTCHA for your own addresses.
7. Publish, then open the site in a private window and submit a test registration to confirm the widget appears and the form still submits.

Notes:

* Keys can also be defined in wp-config.php via the EDUMALL_CAPTCHA_SITE_KEY and EDUMALL_CAPTCHA_SECRET_KEY constants; they override the Customizer values.
* If a provider is selected but a Site or Secret Key is missing, no challenge can be shown, so the guarded forms reject every submission (fail closed) until both keys are added - except the Login forms, which are let through so nobody is locked out (see below); a warning notice is shown in the WordPress admin. The Honeypot option needs no keys.
* Setting "CAPTCHA Provider" to "Disabled" turns the whole feature off, including the honeypot.
* The CAPTCHA guards the theme's own account popups and Register Form widget, plus the WordPress (wp-login.php), Tutor LMS and WooCommerce registration, login and lost-password forms and the guest comment form. Login forms built with wp_login_form() (the login widget/block, BuddyPress, Elementor Pro) post to wp-login.php and get the field too. It deliberately does not run when a logged-in administrator creates an account or sends a reset link, nor on the accounts WooCommerce creates outside its My Account form (checkout, stock notifications), so it never blocks legitimate back-office or purchase flows. The BuddyPress registration page and, on multisite, the network sign-up screen (wp-signup.php) use separate flows and are not covered; the guest comment form is left alone when Jetpack Comments replaces it. A third-party plugin with its own registration, login or lost-password form that never prints the theme field will have its submissions rejected while the matching option is on - use the edumall_captcha_skip filter to exempt it (or place its form where the standard register_form / login_form / lostpassword_form hooks fire).
* Wrong or missing keys: registration, lost-password and comment submissions are rejected (fail closed) until the keys are fixed, but the Login forms are deliberately the exception - while a key is blank, does not look like a key of the selected provider, or is reported wrong by the provider itself, logins are let through unverified and a warning is shown in the WordPress admin, so a typo can never lock the administrators out of their own site (the edumall_captcha_login_leniency filter turns this off). The keys are checked the moment they are saved (their shape, and - where the provider allows it - the Secret Key against the provider), so most mistakes are reported before any visitor meets the form; Google and hCaptcha only judge the Secret Key on a real solve, so a wrong Google/hCaptcha secret of the right shape is reported after the first submission instead. Only a verdict about this site's own keys opens the Login forms, never one a visitor's submission could provoke.
* Locked out anyway (for example a wrong Site Key, whose widget cannot render, or a server that cannot reach the provider with the failsafe set to Block)? Add define( 'EDUMALL_CAPTCHA_DISABLE', true ); to wp-config.php to switch the whole feature off, fix the keys under Customize > CAPTCHA (or set "If the Provider Is Unreachable" to Allow), then remove the line. Tip: test the login form in a private window right after saving the keys, while your admin session is still open.
* Other CAPTCHA plugins: if hCaptcha for WP or Simple Cloudflare Turnstile already protects one of the WordPress, WooCommerce or Tutor LMS forms, the theme CAPTCHA steps aside on that form (no second widget, no double verification) and keeps guarding the theme's own popups and widget, which no plugin can reach; an info notice on the Dashboard, Plugins and Themes screens lists the forms left to the plugin. The theme only steps aside from requests the plugin will actually verify itself; a submission the plugin would skip (its "only on the login page" options, a foreign WooCommerce nonce, an unusual action) is still checked by the theme. Two set-ups get their own warning: hCaptcha for WP in reCAPTCHA-compatibility mode next to the theme's Google reCAPTCHA (enable "Disable reCAPTCHA Compatibility" in hCaptcha, or pick another theme provider), and Turnstile's "WordPress Login" check while the theme's Login option is off (the check runs inside the theme login popup, where its widget cannot appear - enable the theme's Login option, or Turnstile's "only on the login page"). Tutor Pro's Fraud Protection (Tutor LMS Pro > Settings > Authentication) is handled the same way: on the forms its reCAPTCHA v2/v3 guards (WordPress and Tutor registration, WordPress and Tutor login, Tutor lost password - per its "Location" setting) the theme shows no second widget and lets Tutor Pro verify the token, but still rejects a submission that carries no reCAPTCHA token at all, because Tutor Pro only checks the token when it is present. Its honeypot method is invisible and simply runs alongside the theme's. So a site that already had Tutor Pro's reCAPTCHA on keeps working after the update with a single challenge per form; if Tutor Pro's reCAPTCHA is selected without keys, its widget renders broken and the theme keeps guarding - a warning in the WordPress admin says so.
* For the WordPress, Tutor and WooCommerce forms (which submit with a normal page reload), the reCAPTCHA v2 Checkbox, Turnstile, hCaptcha or Honeypot options are recommended over reCAPTCHA v3; the invisible v3 token is best suited to the theme's own popups.
* For reCAPTCHA, Turnstile and hCaptcha, the solution's host is checked against your site's home URL host (www and apex are treated as equivalent) to reject tokens solved on a copy of your public Site Key elsewhere. If your Site Key is registered for several domains, or the site is reached on a staging or secondary host, add those hosts with the edumall_captcha_allowed_hostnames filter so real visitors there are not turned away. If you switch the provider back to Honeypot after running a CAPTCHA service, the 48-hour grace window restarts on your next admin page load.
* The provider script (api.js) is loaded only on pages that actually show a guarded form, and only once the form is on screen; the edumall_captcha_preload_api filter restores loading it on every page. If the verification service ever reports that your keys are wrong, or cannot be reached from your server, a notice in the WordPress admin says so.
* Developers can override the server-side decision with the edumall_captcha_is_valid filter (or the host decision with edumall_captcha_hostname_valid / edumall_captcha_allowed_hostnames), skip the CAPTCHA per request with edumall_captcha_skip, register more forms with edumall_captcha_forms, add providers with edumall_captcha_providers, set the widget language with edumall_captcha_language, map a trusted proxy header with edumall_captcha_client_ip, and extend the popup template allowlist with edumall_popup_lazy_load_templates.

= Which CAPTCHA setup should I use? =

Run ONE CAPTCHA system on the site. Every extra one adds a second challenge to the same form, a second script to the same page, and one more place to look when sign-ups stop working. Pick whichever of these three descriptions fits you and follow only that one.

1. You have no CAPTCHA plugin yet - use the theme's (recommended)

   Appearance > Customize > CAPTCHA, pick a provider, tick the forms. Turn Tutor Pro's Fraud Protection OFF (Tutor LMS Pro > Settings > Authentication) and do not install a CAPTCHA plugin. This is the only setup that also covers the theme's own account popups, the Register Form widget and the instructor registration - forms no plugin can see - as well as the WordPress, Tutor LMS and WooCommerce forms and the comment form.

2. You already run hCaptcha for WP or Simple Cloudflare Turnstile - keep it

   Leave the plugin configured as it is and set the theme's provider to the SAME service (or to Honeypot). The theme steps aside on every form the plugin already protects and only guards what the plugin cannot see, so each form still gets exactly one challenge. Do not point the theme at Google reCAPTCHA while hCaptcha for WP runs in its default reCAPTCHA-compatibility mode: hCaptcha then takes over the Google script and the theme's reCAPTCHA widget cannot render (either enable "Disable reCAPTCHA Compatibility" in hCaptcha, or choose another theme provider). A notice in the WordPress admin points this out if it happens.

3. You already run Tutor Pro's Fraud Protection - decide which one keeps the Tutor forms

   With its reCAPTCHA method configured, the theme steps aside on the forms its "Location" setting covers and Tutor Pro challenges them; the theme keeps guarding its own popups, the WooCommerce forms and the comment form. Nothing breaks, but two Google keys on one site is a setup we recommend against, and mixing versions (for example the theme on reCAPTCHA v2 and Tutor Pro on v3) means a page that shows both a theme form and a Tutor form loads Google's script twice, which the two versions do not always survive. If you keep Tutor Pro's, match its version and keys in the theme, or untick the forms it covers; the simpler answer is to turn Fraud Protection off and let the theme do all of it. The WordPress admin warns when both are on.

Choosing a provider

* Honeypot - no keys, invisible, on by default. Stops ordinary spam bots and asks nothing of your visitors. Start here; move on only if spam gets through.
* Cloudflare Turnstile - a visible but usually click-free box, no Google account needed, the friendliest option for visitors in regions where Google is slow or blocked.
* Google reCAPTCHA v2 - the familiar "I'm not a robot" checkbox. Reliable, and the safest choice for forms that submit with a normal page reload (WordPress, Tutor LMS, WooCommerce).
* Google reCAPTCHA v3 - invisible and score based. Best on the theme's own popups; on ordinary page-reload forms prefer v2, Turnstile or hCaptcha. Raise the score threshold if spam gets through, lower it if real visitors are rejected.
* hCaptcha - like reCAPTCHA v2 with a stronger privacy stance.

Choosing the forms

* Registration is on by default and is where the spam is; leave it on.
* Comments is worth turning on for any site whose posts accept guest comments.
* Login and Lost Password are for sites that are actually being probed. When you turn Login on, set "Show Login Challenge After" to 3 - 5 so ordinary visitors see nothing and only an address that keeps failing meets the challenge.

Keys

* Create the keys for the provider you selected and add YOUR SITE'S DOMAIN to them (Google and hCaptcha reject solutions from unlisted domains).
* Each provider keeps its own Site Key and Secret Key fields, so switching between reCAPTCHA v2, v3, Turnstile and hCaptcha never loses the keys you already pasted - and never reuses another service's, which would not work (a v2 key and a v3 key even look identical). A provider you have not given keys to yet shows empty fields and reports itself as misconfigured until you fill them in. Keys of the wrong shape (a Turnstile key under reCAPTCHA, a key cut off when pasted) are reported when you save, and so is the same key pasted under two different providers.
* To try Turnstile or hCaptcha without creating an account, use their published testing keys - Turnstile 1x00000000000000000000AA / 1x0000000000000000000000000000000AA, hCaptcha 10000000-ffff-ffff-ffff-000000000001 / 0x0000000000000000000000000000000000000000. They always solve, and the theme accepts the placeholder host those keys answer with, so the forms work end to end. Never leave them on a live site: they accept every visitor.
* On a staging or multi-domain setup, add the extra hosts to the key and to the edumall_captcha_allowed_hostnames filter.
* Keys can also live in wp-config.php as EDUMALL_CAPTCHA_SITE_KEY and EDUMALL_CAPTCHA_SECRET_KEY. Those apply to whichever provider is selected and take precedence over every Customizer field, so use them only on a site that stays on one provider.

After saving, open the site in a private window and submit one test registration - and, if you enabled Login, one test login - before you consider it done.

== Changelog ==

= 4.8.3 - Oct 28, 2026 =
- Fixed:
Show the selected variation attributes in the cart, mini-cart and checkout item names with WooCommerce 11.2
List the product categories on the single product page parent first, as WooCommerce 11.2 does
Stop the FAQ Groups and Course Categories widget dropdowns using a function WooCommerce has deprecated
Check the email address format on the student registration form before sending it, and link each field to its label, as Tutor LMS 4.2.0 does
- Updated:
Updated outdated templates of WooCommerce 11.2.1
Revolution Slider plugin v.6.8.0
Compatible with Tutor LMS 4.2.0 and Tutor LMS Pro 4.2.0

= 4.8.2 - Oct 7, 2026 =
- Fixed:
Keep the Instructors page and the course Instructor filter widget in their previous order with Tutor LMS 4.1.0+, which otherwise lists newest instructors first
- Updated:
Compatible with Tutor LMS 4.1.1 and Tutor LMS Pro 4.1.1

= 4.8.1 - Sep 22, 2026 =
- Fixed:
Fix the checkout order summary showing only the shipping method chosen in the cart, which hid the method list and the pickup point pickers shipping plugins add to it
Fix a stray box drawn over the label of the checkboxes in the WooCommerce Cart, Checkout and filter blocks
Fix the Learning Area and Dashboard sticky bars scrolling away or hiding under the site header when Tutor LMS shows the site header and footer around them; the site header now scrolls away on those pages
Fix the title bar repeating the lesson title above the Learning Area
Fix the Tutor LMS Dashboard Header and Footer options having no effect
Stop the student registration form refilling the password fields after a failed sign-up
Fix the Q&A link of the Tutor LMS dashboard not opening the course's Q&A
- Updated:
Updated outdated templates of WooCommerce 11.1.1
Compatible with Tutor LMS 4.0.9 and Tutor LMS Pro 4.0.9

= 4.8.0 - Aug 19, 2026 =
- Added:
Built-in CAPTCHA for the account, registration and comment forms: Honeypot, Google reCAPTCHA v2 and v3, Cloudflare Turnstile or hCaptcha
Protection for the registration forms out of the box, through the keyless Honeypot option that needs no external service
Registration, Login, Lost Password and Comments under Protected Forms, with only Registration on after the update
Coverage for the theme's account popups and Register Form widget, the WordPress, Tutor LMS and WooCommerce forms and guest comments
An option to show the login challenge only after an IP address has failed to log in a number of times
Failed logins from the account popup reported to WordPress, so Limit Login Attempts and Wordfence count them too
No second challenge on the forms hCaptcha for WP, Simple Cloudflare Turnstile or Tutor Pro's reCAPTCHA already verify
Admin warnings for the plugin combinations the theme cannot reconcile
Submissions rejected while the selected provider has no working keys, except on the login forms, which stay open
The same answer to an unverified submission whether or not the account exists, so the forms cannot be used to find usernames or addresses
A host check on every solution, so a token solved elsewhere with a copy of the Site Key does not pass
An EDUMALL_CAPTCHA_DISABLE constant for wp-config.php, to switch the feature off if a site is ever locked out
- Fixed:
Fix the instructor registration popup opening empty
Restrict the popup loader to the account popup templates, so it cannot render other theme templates
Fix the Register Form widget keeping the previous attempt's message on the next submit
Fix the double-submit guard on the account forms and the Register Form widget never engaging
Fix the validation messages on the Tutor LMS login and registration forms rendering unstyled under Tutor LMS 4.0
Fix the theme's Preferences tab replacing the native one Tutor LMS 4.0 ships under the same key
Fix instructor registration accepting sign-ups while WordPress registration is turned off
Fix a hand-built instructor registration bypassing the Terms checkbox and the Tutor LMS consents
Fix a new instructor not being recorded as the pending application Tutor LMS 4.0 tells apart from a student

= 4.7.0 - Jul 28, 2026 =
- Updated:
Recompress the bundled images: 1.2MB down to 367KB, same filenames and dimensions
Ship the Gordita font as woff2 next to the ttf: the default font download drops from 369KB to 105KB
Minify the Elementor widget scripts, which until now shipped unminified
Load the minified fullpage build in the Fullpage widget, saving 156KB on pages that use it
Drop one database query per menu item from every page render
Build the header category menu from a single term query instead of one per category
Debounce the resize handlers so the mobile address bar sliding in and out no longer re-lays out the page
Cache theme SVG icon reads per request instead of re-opening the filesystem for each icon
Leave build sources (SCSS, JS modules) and source maps out of the theme package
- Fixed:
Fix missing thumbnails: the external placeholder service the theme relied on is gone, replaced with an inline SVG
Fix the page preloader swallowing clicks for two seconds after it had already faded out
Fix the Twitter widget re-calling the API and rewriting its token option on every page view when the credentials are rejected
Fix resized images falling back to the full-size original on sites that have changed domain
Fix new Edumall_Course( $id ) ignoring the id it was passed
Fix the child theme stylesheet not busting its cache after being edited
Fix $edumallSwiper being declared twice on pages carrying a carousel

= 4.6.2 - Jul 21, 2026 =
- Updated:
ThemeMove Addons For Elementor plugin version 2.1.2
- Fixed:
Fix Tutor LMS multisite fatal: rewrite wrongly-prefixed users/usermeta tables on subsites
Fix Edumall text-stroke group control shadowing Elementor's native one
Fix Elementor 4.1.5 compat: Font Awesome Pro icons and dead hooks

= 4.6.1 - Jul 11, 2026 =
- Updated:
Reduce tutor-lms.css by ~80KB: drop dashboard styles superseded by the Tutor LMS 4.0.0 native dashboard
Consolidate duplicated enrollment, logo and course loop price logic into shared helpers
- Fixed:
Fix theme brand color / site skin sync getting permanently frozen after saving any Tutor LMS setting
Fix xAPI lesson tracking firing on learning-area sub pages with the course as content
Fix the course builder logo not resolving when the Customizer logo is stored as an attachment id
Remove an orphaned dashboard review AJAX endpoint and its dead script

= 4.6.0 - Jul 10, 2026 =
- Updated:
Compatible with Tutor LMS 4.0.0 and Tutor LMS Pro 4.0.0
- Fixed:
Fix course price display for single course and course bundle
Fix a corrupted input[type=password] selector in the form color rules
Fix shop grid load flash: placeholder matches Isotope column count
Fix warning Undefined variable $orderedby
Add explicit cache-busting version to enqueued assets
Harden security: prepared SQL + sanitize/escape reflected input

= 4.5.7 - Jul 01, 2026 =
- Updated:
Insight Core plugin v.2.8.4
Compatible with Tutor LMS 3.9.14
- Fixed:
Fix instructor dashboard template drift with Tutor LMS 3.9.x: escape the settings page redirect URL, correct a duplicated dashboard template hook, and restore the missing "before dashboard content" hook
Fix the instructor withdrawal page not subtracting pending requests from the available balance, and show a "Total Pending Withdrawal" badge
Fix a possible fatal error on the dashboard Assignments tab when Tutor LMS Pro is not active

= 4.5.6 - Jun 29, 2026 =
- Updated:
Updated outdated templates of WooCommerce 10.9.0
- Fixed:
Fix demo performance: cache Tutor category queries by ID, dedupe per-card rating/instructor queries, memoize image resize

= 4.5.5 - Jun 26, 2026 =
- Added:
Delete option for a student's own course reviews on the dashboard (Tutor LMS 3.x)
- Updated:
Revolution Slider plugin v.6.7.58
Edumall Addons plugin v.1.4.0
- Fixed:
Fix Administrator locked out of Events/FAQs by Instructor role caps
Fix Q&A tab on lesson pages ignoring the per-course Q&A setting (Tutor LMS 3.x compatibility)
Fix Pro/addon course tabs (e.g. Google Classroom Stream) not showing on single course (Tutor LMS 3.x compatibility)
Fix Prerequisites/Subscription/PMPro access control bypassed on lesson, assignment, quiz & live-meeting pages (Tutor LMS 3.x compatibility)

= 4.5.4 - Jun 9, 2026 =
- Updated:
Insight Core plugin v.2.8.3
Revolution Slider plugin v.6.7.57
Updated outdated templates of WooCommerce 10.8.0
- Fixed:
Fix Gap Width control not applying on Inner Section element
Fix editor.js compat with Elementor v4 Atomic Editor
Fix Tutor LMS 3.9.11 compatibility

= 4.5.3 - April 26, 2026 =
- Fixed:
Fix: Term conditions in student registration form.

= 4.5.2 - April 22, 2026 =
- Updated:
Revolution Slider plugin v.6.7.54
- Fixed:
Fix: Broken Access Control in AJAX action edumall_delete_dashboard_course — added nonce verification, post-type restriction, ownership check, and instructor permission gate
Fix: CSRF vulnerability in edumall_place_rating AJAX action — added nonce verification
Fix: IDOR in edumall_update_review_modal — added review ownership check to prevent enrolled users from overwriting other students' reviews
Fix: lead-info not show in Course private

= 4.5.1 - March 23, 2026 =
- Updated:
Revolution Slider plugin v.6.7.51
- Performance:
Optimize asset enqueuing

= 4.5.0 - March 5, 2026 =
- Fixed:
Fix: Quiz attempt details white page when viewing attempt details
Hide Quiz Details button when "Hide Quiz Details From Students" is enabled
Enrolled actions: add href to retake button (fix Keep Data -> /undefined page not found)
Fix: performance, security

= 4.4.9 - February 26, 2026 =
- Updated:
Insight Core plugin v.2.8.1
Revolution Slider plugin v.6.7.41
Updated outdated templates of WooCommerce 10.5.2
- Fixed:
Fix: use get_completed_courses_by_user for Completed Courses tab in Tutor dashboard

= 4.4.8 - December 30, 2025 =
- Updated:
Move CSS inline to Files
Insight Core plugin v.2.8.0
Revolution Slider plugin v.6.7.40
- Fixed:
Local File Inclusion security
PHP warning

= 4.4.7 - November 10, 2025 =
- Updated:
Revolution Slider plugin v.6.7.38
Updated outdated templates of WooCommerce 10.3.0

= 4.4.6 - September 23, 2025 =
- Updated:
Revolution Slider plugin v.6.7.37
Updated outdated templates of WooCommerce 10.2.0
- Fixed:
Fix Blurred mobile logo
Add login class to Enroll Course button when ! is_user_logged_in
Fix minor style

= 4.4.5 - August 18, 2025 =
- Updated:
Updated outdated templates of WooCommerce 10.1.0
Fix PHP warning

= 4.4.4 - July 21, 2025 =
- Fixed:
Fix security issue on AJAX action lazy loader templates.

= 4.4.3 - July 15, 2025 =
- Updated:
Updated outdated templates of WooCommerce 10.0.0

= 4.4.2 - July 7, 2025 =
- Updated:
ThemeMove Addons For Elementor plugin v.2.1.0
Revolution Slider plugin v.6.7.35

= 4.4.1 - June 27, 2025 =
- Fixed:
Fix course price not showing when selling by WC
Fix text_domain PHP warning

= 4.4.0 - June 11, 2025 =
- Updated:
Insight Core plugin v.2.7.4
Revolution Slider plugin v.6.7.34
Compatible with Tutor subscription add-on
Updated outdated templates of WooCommerce 9.9.0

= 4.3.1 - Apr 23, 2025 =
- Updated:
Revolution Slider plugin v.6.7.32
Edumall Addons plugin v.1.3.0
- Fixed
Fix course featured UI not show properly.
Fix course filter widgets

= 4.3.0 - Mar 25, 2025 =
- Updated:
Revolution Slider plugin v.6.7.31
- Fixed:
Fix security issue on AJAX action lazy loader templates.

= 4.2.4 - Feb 27, 2025 =
- Updated:
Updated outdated templates of WooCommerce 9.7.0
Revolution Slider plugin v.6.7.29

= 4.2.3 - Feb 18, 2025 =
- Updated:
Insight Core plugin v.2.7.3
- Fixed:
Fix Kirki @font-face load wrong url.

= 4.2.2 - February 13, 2025 =
- Updated:
Insight Core plugin - v.2.7.2
Revolution Slider plugin v.6.7.28
Improvement customize preview loading time

= 4.2.1 - January 21, 2025 =
- Updated:
Updated outdated templates of WooCommerce 9.6.0
Revolution Slider plugin v.6.7.25

= 4.2.0 - December 18, 2024 =
- Fixed:
Updated outdated templates of WooCommerce 9.5.1
Compatible with the latest version of Elementor plugin
Fix Save course author
Fix Author on Single Course

= 4.1.0 - December 2, 2024 =
- Fixed:
Compatible with Tutor 3.0 native monetize
Fix PHP warning

= 4.0.9 - November 21, 2024 =
- Updated:
Tutor LMS Pro plugin - v.3.0.0
Revolution Slider plugin v.6.7.23
- Fixed:
Fix Certificate share icon
Fix load_text_domain

= 4.0.8 - November 14, 2024 =
- Updated:
Tutor LMS Pro plugin - v.2.7.7
Updated outdated templates of WooCommerce 9.4.1

= 4.0.7 - November 7, 2024 =
- Updated:
Revolution Slider plugin v.6.7.21
ThemeMove Addons For Elementor plugin v.2.0.1
- Fixed:
Don't update Elementor form to avoid PHP issue

= 4.0.6 - October 14, 2024 =
- Updated:
Insight Core plugin - v.2.7.1
Revolution Slider plugin - v.6.7.20

= 4.0.5 - September 26, 2024 =
- Updated:
Tutor LMS Pro plugin - v.2.7.6
Revolution Slider plugin - v.6.7.19

= 4.0.4 - September 16, 2024 =
- Fixed:
Fix Elementor widgets used waypoint broken in Elementor 2.24.x

= 4.0.3 - September 13, 2024 =
- Updated:
Tutor LMS Pro plugin - v.2.7.5
Tutor LMS Certificate Builder plugin - v.1.1.2
- Fixed:
Fixed some minor style errors
Fix for quiz attempt history not showing properly
Fix quiz body still start when remaining count limit
WooCommerce 9.3.1 outdated templates

= 4.0.2 - August 23, 2024 =
- Updated:
Revolution Slider plugin - v.6.7.18
- Fixed:
WooCommerce 9.2.0 outdated templates

= 4.0.1 - August 6, 2024 =
- Updated:
Tutor LMS Pro plugin - v.2.7.4
Revolution Slider plugin - v.6.7.16
- Fixed:
RTL style

= 4.0.0 - July 17, 2024 =
- Updated:
Tutor LMS Pro plugin - v.2.7.3
Tutor LMS Certificate Builder plugin - v.1.1.1
Revolution Slider plugin - v.6.7.15
- Fixed:
WooCommerce 9.1.0 outdated templates

3.9.10 - July 3, 2024
- Updated:
Revolution Slider plugin - v.6.7.14
- Fixed:
Create a new bundle course frontend
Fix Course powerTips not show
Fix translation
Fix Registration Date format
Fix Course builder logo

3.9.9 - Jun 19, 2024
- Updated:
Tutor LMS Pro plugin 2.7.2
Tutor LMS Certificate Builder plugin 1.1.0
- Fixed:
Compatible with Elementor Pro v.3.22.0
WooCommerce outdated templates
Fix Single Quiz drip_content_protection

3.9.8 - Jun 7, 2024
- Updated:
Insight Core plugin 2.7.0
Tutor LMS Pro plugin 2.7.1
ThemeMove Addons for Elementor plugin 2.0.0
Revolution Slider plugin - v.6.7.13

3.9.7 - May 13, 2024
- Updated:
Revolution Slider plugin - v.6.7.10
Show password for Password field.
- Fixed:
Fix Skip Quiz
Fix Escaping
WPML translate widget Accordion
Auto course complete on all lesson, quiz, assignment complete

3.9.6 - April 29, 2024
- Updated:
Tutor LMS Pro plugin 2.7.0
ThemeMove Addons for Elementor plugin 1.3.3
Revolution Slider plugin - v.6.7.7
- Fixed:
ReFix Course Tab elementor widget not working with WPML

3.9.5 - April 19, 2024
- Updated:
Revolution Slider plugin - v.6.7.4
- Fixed:
Fix Login/Register form responsive
Fix PHP warning
Fix Single Course share icon duplicate.
Fix Course tab elementor widget not working with WPML
Out-date WooCommerce templates
Optimize RTL

3.9.4 - March 25, 2024
- Updated:
Edumall Addons plugin 1.2.2
- Fixed:
Out-date WooCommerce templates version 8.7.0
Fix Dark skin style

3.9.3 - March 15, 2024
- Updated:
Insight Core plugin 2.6.7
- Fixed:
Fix google font not working error.

3.9.2 - March 13, 2024
- Updated:
Tutor LMS Pro plugin 2.6.2
- Fixed:
Fix PHP warning

3.9.1 - February 23, 2024
- Updated:
Tutor LMS Pro plugin 2.6.1
- Fixed:
Out-date WooCommerce templates version 8.6.0
Fix Responsive issue
Fix Dark skin style
Fix Header Category show draft courses

3.9.0 - January 31, 2024
- Updated:
Respected WordPress Membership setting in Dashboard -> Settings -> General
Changed popup login/register modal to separate pages.
Use native login form from Tutor plugin to working smooth with Email verification, 2FA, Limit login sessions.
(Requires enabling Enable Tutor Login in Tutor LMS Pro > Settings > Advanced > Options > Enable Tutor Login)
Edumall Addons plugin 1.2.1
- Fixed:
Out-date WooCommerce templates version 8.5.0

3.8.0 - January 22, 2024
- Fixed:
Fix custom course permalink is not working properly.
Fix single quiz permalink is not working properly.
Fix out-date Buddypress templates ver 12.0.0.
Fix shortcode tutor_course not display properly.

3.7.0 - January 10, 2024
- Updated:
Show notification button on dashboard page.
Add pagination for enrolled courses in dashboard page.
Add load more button for qna section in course single.
- Fixed:
PHP warning raising when limit active login sessions feature on.
Course create submitted message not showing.

3.6.0 - December 19, 2023
- Fixed:
Fix items per view setting of Elementor Carousel & Grid widgets not working properly on mobile.
Fix Single Course Responsive

3.5.9 - December 14, 2023
- Fixed:
Tested up with BuddyPress 12.0.0

3.5.8 - December 11, 2023
- Updated:
Tutor LMS plugin 2.5.0
Revolution Slider plugin - v.6.6.19
- Fixed:
Fix PHP waring from Elementor 3.18.0

3.5.7 - December 7, 2023
- Fixed:
Fix SEO problem with duplicate h1 tag on blog posts and zoom meeting

3.5.6 - December 6, 2023
- Updated:
Revolution Slider plugin - v.6.6.18
FontAwesome 6.4.2
- Fixed:
Fix PHP waring from Elementor 3.18.0

3.5.5 - December 05, 2023
- Updated:
Improvement user registration error messages.
- Fixed:
Public user profile show 404 page for exists user.
Instructor user profile url has wrong param query.

3.5.4 - October 20, 2023
- Updated:
Tutor LMS plugin 2.4.0
Tutor LMS Certificate Builder plugin 1.0.5
- Fixed:
Course Certificate not showing in new Tutor Version
Course GradeBook not showing in new Tutor Version
Fix Course Style in new Tutor Version

3.5.2 - October 16, 2023
- Updated:
Insight Core plugin - v.2.6.6
Revolution Slider plugin - v.6.6.16
Tutor LMS plugin 2.3.0
ThemeMove Addons For Elementor 1.3.1
Insight Swatches 1.7.0
- Fixed:
Out-date WooCommerce templates version 8.1.0
Fix Course Archive grid column
- New:
Home Child
Home Chef

3.5.1 - August 25, 2023
- Updated:
Insight Core plugin - v.2.6.5 (Compatible with WordPress 6.2.0)

3.5.0 - August 14, 2023
- Updated:
Compatible course bundle add-on

3.4.8 - August 03, 2023
- Updated:
Revolution Slider plugin - v.6.6.15
- Fixed:
Fix Cart fragments issue with WC 7.8.0

3.4.7 - July 31, 2023
- Updated:
Tutor LMS plugin 2.2.3
Revolution Slider plugin - v.6.6.14
- Fixed:
out-date WooCommerce templates

3.4.6 - April 28, 2023
- Updated:
Tutor LMS plugin 2.1.10

3.4.5 - April 06, 2023
- Updated:
Tutor LMS plugin 2.1.9
Insight Core plugin - v.2.6.4
Revolution Slider plugin - v.6.6.12
- Fixed
out-date wc templates
add to cart button not working properly.

3.4.4 - January 27, 2023
- Updated:
Optimize code

3.4.3 - December 22, 2022
- Updated:
Tutor LMS plugin 2.1.4
Insight Core plugin - v.2.5.1
Revolution Slider plugin - v.6.6.8
Single course reviews pagination.

3.4.2 - December 05, 2022
- Updated:
Compatible with WooCommerce 7.2.0
- Fixed:
Allows display HTML in cart item name.

3.4.1 - December 05, 2022
- Updated:
Tutor LMS plugin 2.1.3
Insight Core plugin - v.2.4.12
Revolution Slider plugin - v.6.6.7
Insight Swatches plugin - v.1.4.0
- Fixed:
Dashboard withdraw not working properly.
missing View certificate button on course layout 02
out-date WooCommerce templates.

3.4.0 - November 16, 2022
- Updated:
Tested up with Tutor LMS 2.1.2
- Fixed:
The Course Retake button doesn't show on the course page after course completion.
Auto Course Complete on all Lesson Completion not working properly.
Course expiry date info is not showing.
Course enrolled date info is not showing.
Add Public, Move to Draft, Cancel Submission actions on Dashboard My Course.

3.3.1 - November 02, 2022
- Updated:
Tested up with Tutor LMS 2.1.1
Insight Core plugin - v.2.4.11
Revolution Slider plugin - v.6.6.5

3.3.0 - September 23, 2022
- Fixed:
Tested up with Tutor LMS 2.0.10
Minor style

3.2.6 - September 21, 2022
- Fixed:
dashboard my course price.
Tested up with Elementor 3.7.7
Tested up with WooCommerce 6.9.3

3.2.5 - July 22, 2022
- Fixed:
minor style.

3.2.4 - July 14, 2022
- Updated:
add pagination for dashboard my courses.
- Fixed:
dashboard my courses delete action not working
dashboard my courses responsive
single quiz responsive

3.2.3 - Jun 16, 2022
- Updated:
Insight Core plugin - v.2.4.6
Tutor LMS plugin - v.2.0.6
Revolution Slider plugin - v.6.5.24
- Fixed:
Dashboard analytics style
Question not saved in Tutor 2.0.6

3.2.2 - Jun 01, 2022
- Fixed:
Create course layout
elementor widget Form

3.2.1 - May 31, 2022
- Fixed:
Archive Course Top Filter Bar not showing.
Lesson Sidebar toggle.

3.2.0 - May 27, 2022
- Updated :
Tutor LMS Pro plugin v.2.0.5
Tutor LMS Certificate Builder plugin v.1.0.4
- Fixed:
Instructor can't create events/faqs.
Reviews star unselectable
Dashboard certificate page style

3.1.0 - May 12, 2022
- Fixed:
Wishlist popup style
Public Profile page
Certificate Download page

3.0.6 - May 10, 2022
- Updated :
Revolution Slider plugin v.6.5.21
- Fixed:
Quiz type style
Tutor Modal style
Quiz submit not working in Question Single Layout

3.0.5 - May 06, 2022
- Updated :
Tutor LMS Pro plugin v.2.0.2
Tutor LMS Certificate Builder plugin v.1.0.3
Tested up Tutor LMS 2.0.2
Fix Assignment
Fix Quiz

3.0.4 - April 18, 2022
- Fixed
Question & answer not working properly
minor course style

3.0.3 - April 15, 2022
- Updated :
Insight Core plugin v.2.4.4
Insight Swatch plugin v.1.3.1
- Fixed
minor course loop style

3.0.2 - April 12, 2022
- Updated :
Revolution Slider plugin v.6.5.20
- Fixed :
Missing functions in Tutor LMS
Tested up with Elementor 3.6.2
Tested up with BuddyPress 10.2.0
PHP warning with PHP 8.x

3.0.1 - March 30, 2022
- Fixed :
Missing functions in Tutor LMS
Tested up Elementor 3.6.1

3.0.0 - March 29, 2022
- Updated :
Insight Core plugin v.2.4.0
Insight Swatch plugin v.1.3.0
Edumall Addons plugin v.1.2.0
Tutor LMS Pro plugin v.2.0.1
Tutor LMS Certificate Builder plugin v.1.0.2
Revolution Slider plugin v.6.5.19
- Fixed :
Elementor column gap
Compatible with Tutor LMS 2.0
Fix dashboard design


2.10.1 - February 09, 2022
- Updated :
Elementor Templates support for Custom Post Type

2.10.0 - February 08, 2022
- Updated :
Tutor LMS Pro plugin v.1.9.15
Revolution Slider plugin v.6.5.15
- Fixed :
Dashboard navigation style in RTL
Dashboard layout in multi languages.
Create course style

2.9.10 - January 28, 2022
- Updated :
Insight Core plugin v.2.2.8
Revolution Slider plugin v.6.5.14
Tutor LMS Pro plugin v.1.9.14
- Fixed :
Lesson sidebar toggle bug
Out-date BuddyPress templates
Minor lesson page style

2.9.9 - December 27, 2021
- Updated :
Update plugins
Quiz complete status on Lesson single.

2.9.8 - December 03, 2021
- Updated :
Insight Core plugin v.2.2.7
Insight Swatches plugin v.1.2.3
- Fixed :
External Product Add to cart

2.9.7 - November 19, 2021
- Added :
Course Tag Filter widget.
- Updated :
Hide complete lesson button for unenrolled users.
- Fixed :
Course single style

2.9.6 - November 11, 2021
- Updated :
Compatible with PHP 8.0
- Fixed :
Contact Form 7 Styling
PHP warning.

2.9.5 - October 28, 2021
- Added :
Tutor LMS Certificate Builder plugin
- Updated :
Tutor LMS plugin v.1.9.11
Test up BuddyPress 9.1.1

2.9.4 - September 29, 2021
- Updated :
Revolution Slider plugin v.6.5.8
Tutor LMS plugin v.1.9.9
- Fixed :
Single quiz attempt info.
Product Variation Add to Cart

2.9.3 - September 09, 2021
- Added :
Show Course Attachments, Q&A, Announcements, GG Class Room in Single Course for Admin and Course Owner when Course Content Access enabled.
- Fixed :
Instructor list not showing.
Compatible with Tutor 1.9.8

2.9.2 - August 01, 2021
- Fixed :
Review rating can't select.

2.9.1 - August 31, 2021
- Updated :
Insight Core plugin v.2.2.4
Tutor LMS plugin v.1.9.7
Revolution Slider plugin v.6.5.7
Insight Swatches plugin v.1.2.2
- Fixed :
Course loop title collapsed style
Widget Course Grid Filter not working properly.

2.9.0 - August 09, 2021
- Updated :
Revolution Slider plugin v.6.5.6
Tutor LMS plugin v.1.9.6
BuddyPress test up to 9.0.0
- Fixed :
UI Date picker css

2.8.11 - July 29, 2021
- Updated :
Revolution Slider plugin v.6.5.5
- Fixed :
Fix Compare, compatible with WPC Smart Compare 4.0.0 (Requires WooCommerce Smart Compare plugin v.4.0.0 to be installed)

2.8.10 - July 27, 2021
- Fixed :
Profile page missing phone number.
Previous attempts responsive style
Single Quiz responsive

2.8.9 - July 17, 2021
- Added :
Zoom added to the Frontend Dashboard
Field to add Course Tags in Frontend course builder
- Updated :
Jetpack compatible.
Tutor LMS Pro plugin v.1.9.4
Update Dashboard menu icon.
Move Zoom's settings form Dashboard - Settings to Dashboard - Zoom - Set API

2.8.8 - July 09, 2021
- Fixed :
Single Course share style
Public Course required login to view lessons
WP Widget: Tutor Course show PHP warning
- Improvement :
Change Public Course button text from "Enroll Now" to "Start Learning"

2.8.7 - July 05, 2021
- Updated :
Rev Slider plugin v.6.5.4
- Fixed :
Forgot password page of Events Manager show php code.
- Improvement :
Boost up site loading
Dashboard Create Course page.
Single Course Rating show long percentage number.
Preview Lesson do not required log in to view content.

2.8.6 - June 29, 2021
- Updated :
Tutor LMS Pro plugin v.1.9.3
- Fixed :
Add To Cart notification show multi times with Variable Product.
Single Product: Add To Cart variation not working properly.

2.8.5 - June 21, 2021
- Updated :
Revolution Slider plugin v.6.5.2
- Fixed :
Some text in Dashboard Settings untranslatable.
Product Variable SKU not change on variation changed
Smooth Scroll Links not working for anonymous users.
- Improvement :
Show Wishlist button in Single Course for Admin role when Course Content Access setting enable.

2.8.4 - June 16, 2021
- Added :
Hook/Action: edumall_popup_register_after_form_field_name
Hook/Action: edumall_popup_register_after_form_field_login
Hook/Action: edumall_popup_register_after_form_field_password
Hook/Action: edumall_popup_register_after_form_field_accept
Hook/Action: edumall_popup_instructor_registration_after_form_field_name
Hook/Action: edumall_popup_instructor_registration_after_form_field_username
Hook/Action: edumall_popup_instructor_registration_after_form_field_email
Hook/Action: edumall_popup_instructor_registration_after_form_field_password
Hook/Action: edumall_popup_instructor_registration_after_form_field_accept
- Fixed :
Course Certificate missing Title Bar.
Course Certificate share not working properly.
Compatible with BuddyPress 8.0.0
- Improvement :
Popup Login/Register prevent multi clicks submit.

2.8.3 - June 11, 2021
- Improvement :
Dashboard Withdrawals style in Dark mode.
Dashboard Settings Withdraw style in Dark mode.

2.8.2 - June 09, 2021
- Updated :
Tutor LMS Pro plugin v.1.9.1
- Fixed :
Zoom Meeting lesson redirect 404.

2.8.1 - June 03, 2021
- Added :
Terms & conditions + Privacy Policy link on Register Popup.
- Updated :
Insight Core plugin v.2.1.1
Tutor LMS Pro plugin v.1.9.0
- Fixed :
Profile Cover Upload not working properly.
Breadcrumb hidden by default on Title Bar.

2.8.0 - May 26, 2021
- Fixed :
Contact Form 7 Widget broken layout
Single Course Continue Button Link
Lesson Preview Sidebar Style
Lesson Quiz Previous Attempts Style

2.7.7 - May 24, 2021
- Fixed :
Course Topics Description Toggle broken in Tutor LMS ver 1.8.10
Frontend Course Builder Lesson Popup style.
- Improvement :
Allowed instructors add HTML tags for Bio field in Dashboard Settings.

2.7.6 - May 11, 2021
- Added :
Header Category: add setting control category number.
- Fixed :
Allowed HTML tags in Dashboard/Profile bio field.
Missing Grid Layout script for Search Result page.
- Updated :
Revolution Slider plugin v.6.4.11
- Improvement :
Woo Checkout Coupon toggle animation.

2.7.5 - May 11, 2021
- Fixed :
Fix a critical error in 2.7.4 raising on BuddyPress Group inactive

2.7.4 - May 11, 2021
- Added :
Hook/Filter: edumall_tutor_become_instructor_immediately
Dashboard My Students page, allows instructors manage their students.
- Improvement :
Assets loading.
Content Importer.
Make compatible BuddyPress with third party plugin: Youzify
- Updated :
Tutor LMS Pro plugin v.1.8.10
- Fixed :
BuddyPress Single Group Style
WP Widget: Course Instructor Filter limited 100 instructors.

2.7.3 - May 04, 2021
- Updated :
Tutor LMS Pro plugin v.1.8.9
- Fixed :
Google Map link in Single Event broken.
WooCommerce checkout billing form style broken in 5.2.0
WP Widget: Course/Faq/Event show draft posts.
Elementor Widget: Animated Headline show js bug on some cases.
Single Course Rating Meter display wrong percent.
- Improvement :
Product variation selection.
Enqueue Grid Layout on used for better performance.

2.7.2 - April 23, 2021
- Added :
Link + Hover Animation for Dashboard My Course thumbnails.
- Updated :
Insight Core plugin v.2.1.1
- Fixed :
Install Tutor LMS Pro plugin problem.
Icon align + spacing of Popup Login in RTL.
Wrong permalink structure in Prerequisites Courses.
Minor RTL style.
- Improvement :
Allows My Profile Bio show HTML.
Change Profile left menu icon.
style of Course Certificate page.
Course duration translatable.
Write review button show Login Form in Popup instead of Inline Form

2.7.1 - April 19, 2021
- Added :
setting Number of Courses in Header Category Menu
- Updated :
Revolution Slider plugin v.6.4.8
Edumall Add-on plugin v.1.1.0
Out-date templates of WooCommerce 5.2.0

2.7.0 - April 13, 2021
- Added :
new Page Template "Content Boxed" that Content section use small layout.
new WordPress widget: Course Name Filter
- Improvement :
WooCommerce Checkout Payment Icon for more gateways.
Course/Shop Layout Switcher Buttons loading animation.
WordPress widget: Course Sorting
WordPress widget: Course Price Filter
Course loop meta icon & order in Course List style.
Shop Quick View popup style + support variation product.
- Fixed :
Add username input field to Instructor Registration form to avoid 404 error on profile page.
Blog number posts option not working properly.
Missing icon for Out-of-stock product
Missing icon for External product

2.6.2 - April 05, 2021
- Fixed :
PHP warning showing in ver 2.6.1

2.6.1 - April 05, 2021
- Updated :
Tutor LMS Pro plugin v.1.8.7
Insight Core plugin v.2.1.0
- Fixed :
Dashboard Announcements create & update not working properly.
Some wrong translate string
Course/Lesson Attachments.

2.6.0 - March 25, 2021
- Added :
Course Duplicator feature in Dashboard My Courses.
- Fixed :
Wishlist button text on single course.
PHP warning in Media Gallery widget.
Events Manager not showing properly for role Admin on some edge case.
Course Level Filter missing All Level option.
Social Login Button style broken in latest version.
- Updated :
Tutor LMS Pro plugin v.1.8.6
Revolution Slider plugin v.6.4.6
- Improvement:
UX & Style in Dashboard Enrolled Courses page.
Style of instructors in single course page.
Change default user avatar from First Letter to Avatar.
Consistently all user avatars across the pages.

2.5.1 - March 17, 2021
- Updated :
Insight Swatches plugin v.1.2.0
Revolution Slider plugin v.6.4.3
Tutor LMS Pro plugin v.1.8.5
Compatible with WordPress 5.7
- Fixed :
Dashboard Announcements menu link missing icon.
- Improvement:
Site Performance

2.5.0 - March 05, 2021
- Added :
New filter: edumall_pre_user_login
New filter: edumall_pre_user_register
New filter: edumall_pre_user_reset_password
New filter: edumall_pre_instructor_register
New filter: edumall_elementor_widget_pre_user_register
- Fixed :
Cart empty message not showing when last item removed.
Header 01 style
Header Category Menu style
Image Resizer framework
Wrong Courses ordering in Course Tabs widget
- Updated :
Insight Core plugin v.2.0.0
Tutor LMS Pro plugin v.1.8.4
Revolution Slider plugin v.6.4.2
- Improvement:
Content Importer
Theme Auto Updater

= 2.4.2 - February 26, 2021 =
- Fixed :
Zoom Settings saving is not working.
FAQs capability for Admin.
- Improvement:
Course Prerequisites in Single Lesson.
Performance for single course page.

= 2.4.1 - February 23, 2021 =
- Fixed :
Disabled user choose site skin by default.

= 2.4.0 - February 23, 2021 =
- Added :
More filters/hooks for better expandable.
Topic Description in Curriculum section in single course page.
Setting allows user choose site skin.
- Fixed :
Missing translation string for tag.
Minor single course category style.
Sub-menu arrow position in RTL.
Category menu overlap when has a few items.
Lesson Sidebar overlap Header Category Menu
Event list style.
Event Manager can not access after version 2.3.2. Required switch theme again.
- Improvement:
Remove login url + register url from Top bar + Header user links for better security.
Allows admin + instructors view their courses without enroll

= 2.3.2 - February 17, 2021 =
- Added :
setting allows instructors create event posts.
- Fixed :
Course Rating filter widget.
- Updated:
Tutor LMS Pro plugin v.1.8.2
Revolution Slider plugin v.6.3.9
Edumall Addons plugin v.1.0.2
Insight Core plugin v.1.7.9.3
capability for Instructor.

= 2.3.1 - February 02, 2021 =
- Added :
support self-hosted video type for Popup Video widget.
setting disable breadcrumb for Title Bar type 01, 02, 06, 08
setting Title Bar type for single Event post page.
- Fixed :
widget Counter thousand separator show comma when disabled
Course home link in Zoom Meeting lesson
Course home link in Quiz lesson
- Improvement:
Event Date filtering open keyboard on mobile.

= 2.3.0 - January 28, 2021 =
- Fixed :
Minor RTL style.
Tutor LMS Pro plugin v.1.7.9
Compatible Tutor 1.7.9
Event Tags not display properly template.
Single Quiz layout.
- Updated:
Insight Core plugin v.1.7.9.2
Revolution Slider plugin v.6.3.6
- Improvement :
Course/Lesson zoom meeting countdown
Dashboard Settings page layout.
Lesson breadcrumb.
SEO
Page Loading Speed

= 2.2.0 - January 21, 2021 =
- Added :
Login redirect url setting in Customize => Login
Ajax handler for Add To Cart in single Product/Course page.
Notification on product added to cart for single Product/Course page.
- Fixed :
Profile page show wrong info.
Tutor Zoom Meeting saving problem.
Create Course RTL style.
Updated:
Insight Core plugin v.1.7.9.1
Edumall Addons plugin v.1.0.1
Tutor LMS Pro plugin v.1.7.8.1
- Improvement :
FAQ breadcrumb.
Show View Cart button instead of Add to Cart button when the course in cart.

= 2.1.0 - January 18, 2021 =
- Added :
Notification on product added to cart.
- Fixed :
Preview lesson layout.
Tutor Dashboard layout broken when edited with Elementor.
Header style in Create Course page.
- Updated :
Insight Core plugin v.1.7.9
- Improvement :
Gutenberg Editor.

= 2.0.0 - January 12, 2021 =
- Added :
3 homepages: Dark, Dev, Online Art
Dark mode.
Loop course level badges in style Grid 01 + 02 & Carousel 02 + 03.
German translation.
- Updated :
Italian translation.
Insight Core plugin v.1.7.8
Tutor LMS Pro plugin v.1.7.8
Testimonial Carousel 3D widget
- Fixed :
PHP warning when use BuddyPress < 7.0.0
Course Tag & Course Language template.
Layout switcher button style on Firefox.
Elementor loading on old browsers.
Course Tabs broken layout after window resize
Course Grid Layout alignment in RTL
- Improvement :
Change default title bar type single shop 05
Course Tabs widget
Course Search Form widget
Course Category Cards widget
Shapes widget
Icon Box widget
Course Grid widget
Testimonial widget
Modern Heading widget
Accordion widget
List widget

= 1.3.7 - December 31, 2020 =
Added: Instructors listing page.
Fixed: Create course page layout.
Improvement: Course Google Classroom Stream style.

= 1.3.6 - December 28, 2020 =
Fixed: PHP warning on Tutor LMS Pro not activate.
Fixed: BuddyPress Group Courses tab.
Updated: out-date BuddyPress templates.

= 1.3.5 - December 24, 2020 =
Added: Zoom settings on Dashboard page.
Fixed: Course Tabs widget not showing title after version 1.3.4

= 1.3.4 - December 23, 2020 =
Fixed: minor style of Datetime picker.
Fixed: minor style of Header.
Fixed: Course Tabs widget not showing courses of other instructors for logged instructor.
Improvement: Speed up theme when cache plugins not installed.

= 1.3.3 - December 22, 2020 =
Fixed: minor style in single course.
Fixed: Dashboard My Course page missing sidebar.

= 1.3.2 - December 21, 2020 =
Added: Off canvas menu for Dashboard page.
Fixed: php warning on Create Course page.
Fixed: minor style issue on Create Course page.
Fixed: single lesson layout.
Fixed: broken plugin link.
Improvement: style of Dashboard page.

= 1.3.1 - December 17, 2020 =
Added: style settings for widget Course Category Cards.
Improvement: Header components template overrideable.
Improvement: Top bar components template overrideable.
Improvement: UX of left navigation of Dashboard page.
Fixed: widget Course Tabs still loading when no courses found.
Fixed: php warning when Buddypress User Groups not activate.
Fixed: login popup responsive style.
Fixed: social login buttons style.
Fixed: header search form style on mobile.

= 1.3.0 - December 16, 2020 =
Added: Italian translation.
Fixed: minor style of Dashboard pages.
Fixed: wishlist button style.
Fixed: archive layout switcher js.
Fixed: time field of Zoom Meetings not working properly.
Improvement: mobile header style in Create Course page.
Improvement: zoom meeting popup in Create Course page.
Improvement: more settings for widget Tabs.
Updated: French translation.

= 1.2.2 - December 08, 2020 =
Improvement: Dashboard Withdraw style.
Fixed: Add to wishlist button style.
Fixed: Popup Login not showing when click on add to wishlist button.
Updated: Insight Core plugin - v.1.7.7
Updated: Revolution Slider plugin - v.6.3.3

= 1.2.1 - December 08, 2020 =
Added: new Top Bar type 05, default for BuddyPress pages.
Fixed: missing Withdraw button on Dashboard page.
Fixed: lesson sidebar not open on mobile.
Fixed: lesson not loading on classic editor mode.
Fixed: profile avatar cannot save.
Updated: Dashboard Profile settings layout.
Updated: out-date Tutor LMS templates.

= 1.2.0 - December 07, 2020 =
Added: full support RTL language.
Added: Arabic translated file
Added: French translated file
Added: new preset style for widget List.
Added: text shadow option for widget Heading Highlight Word.
Updated: out-date WooCommerce templates.
Updated: Tutor LMS Pro - v.1.7.5
Improvement: Elementor Control Text Stroke.
Improvement: BuddyPress Media style.

= 1.1.0 - November 27, 2020 =
Added: more settings control visibility of section on course category page.
Added: option Become a Instructor right after apply.
Added: link to info cards in Dashboard Overview page.
Added: Job Title field to Dashboard Profile page.
Fixed: Header category menu.
Fixed: Course certificate style.
Fixed: Profile social networks.
Improvement: full style for BuddyPress

= 1.0.2 - November 10, 2020 =
Added: Course sale badge
Fixed: minor cart style.
Fixed: minor public profile page style.

= 1.0.1 - November 10, 2020 =
Updated: Content import.
Fixed minor style.

= 1.0.0 - November 09, 2020 =
Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
