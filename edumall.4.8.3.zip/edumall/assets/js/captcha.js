(
	function( window, $ ) {
		'use strict';

		var apiReady = false;
		var apiRequested = false;
		var v3Timer = null;
		var lastSubmittedForm = null;

		/**
		 * The provider object, captured the moment its script reports ready.
		 * Read through api() rather than window.<global> at call time: hCaptcha
		 * in reCAPTCHA-compatibility mode (its default) later re-points
		 * window.grecaptcha at itself, which must not swap the object under a
		 * Google reCAPTCHA widget already rendered.
		 */
		var apiObject = null;

		var GLOBALS = {
			grecaptcha: 'grecaptcha',
			grecaptcha_v3: 'grecaptcha',
			turnstile: 'turnstile',
			hcaptcha: 'hcaptcha'
		};

		function api() {
			if ( apiObject ) {
				return apiObject;
			}

			var name = GLOBALS[ getSettings().adapter ];

			return name ? window[ name ] : null;
		}

		// Tokens older than this are re-fetched before the form is submitted.
		var V3_FRESH_MS = 60000;

		function getSettings() {
			return window.$edumallCaptcha || {};
		}

		function tokenField() {
			return getSettings().tokenField || 'edumall_captcha_token';
		}

		/**
		 * Provider adapters. Each wraps the provider's global into the same
		 * tiny surface: ready(), render(el, options) -> widgetId, reset(id),
		 * and for the invisible reCAPTCHA v3, execute() -> Promise<token>.
		 * The facade picks one by $edumallCaptcha.adapter, so adding a
		 * provider means adding an entry here and a PHP provider class.
		 */
		var ADAPTERS = {
			grecaptcha: {
				ready: function() {
					var g = api();

					return !! ( g && g.render && ! g.getRespKey ); // getRespKey: hCaptcha posing as grecaptcha.
				},
				render: function( el, options ) {
					return api().render( el, options );
				},
				reset: function( id ) {
					api().reset( id );
				},
				// reCAPTCHA writes its token into a textarea it injects itself,
				// under the name every reCAPTCHA plugin reads. Only the theme
				// field must carry the token, so the textarea is unnamed.
				stripFields: 'textarea[name="g-recaptcha-response"]'
			},
			grecaptcha_v3: {
				invisible: true,
				ready: function() {
					var g = api();

					return !! ( g && g.execute && g.ready && ! g.getRespKey );
				},
				whenReady: function( fn ) {
					api().ready( fn );
				},
				execute: function( siteKey, options ) {
					return api().execute( siteKey, { action: options.action } );
				}
			},
			turnstile: {
				ready: function() {
					var t = api();

					return !! ( t && t.render );
				},
				render: function( el, options ) {
					return api().render( el, options );
				},
				reset: function( id ) {
					api().reset( id );
				}
			},
			hcaptcha: {
				ready: function() {
					var h = api();

					return !! ( h && h.render );
				},
				render: function( el, options ) {
					return api().render( el, options );
				},
				reset: function( id ) {
					api().reset( id );
				},
				stripFields: 'textarea[name="h-captcha-response"], textarea[name="g-recaptcha-response"]'
			}
		};

		function getAdapter() {
			return ADAPTERS[ getSettings().adapter ] || null;
		}

		function isV3() {
			var adapter = getAdapter();

			return !! ( adapter && adapter.invisible );
		}

		/**
		 * Whether anything on the page needs the provider script right now.
		 */
		function hasPlaceholders() {
			return $( '.edumall-captcha, input.edumall-captcha-v3' ).length > 0;
		}

		/**
		 * Load the provider script on demand: only once a guarded form is on
		 * the page (at load, or after a popup / Elementor widget arrives). Pages
		 * without a form never pay for it. When the theme preloads the script
		 * (edumall_captcha_preload_api) apiUrl is empty and this is a no-op.
		 */
		function ensureApi() {
			var settings = getSettings();
			var adapter = getAdapter();

			if ( apiRequested || apiReady || ! settings.apiUrl || ! settings.siteKey ) {
				return;
			}

			// Another plugin already loaded the same provider script (hCaptcha
			// for WP, Simple Cloudflare Turnstile, ...): loading it twice makes
			// hCaptcha forget the widgets it rendered, so reuse what is there.
			if ( adapter && adapter.ready() ) {
				window.edumallCaptchaApiLoaded();
				return;
			}

			apiRequested = true;

			var script = document.createElement( 'script' );
			script.src = settings.apiUrl;
			script.async = true;
			script.defer = true;
			script.onerror = function() {
				// Let a later trigger try again (network blip, blocker prompt).
				apiRequested = false;
			};

			document.head.appendChild( script );
		}

		function findTokenInput( $container ) {
			var $form = $container.closest( 'form' );
			var $scope = $form.length ? $form : $container.parent();

			return $scope.find( 'input[name="' + tokenField() + '"]' ).first();
		}

		function stripProviderFields( $el ) {
			var adapter = getAdapter();

			if ( adapter && adapter.stripFields ) {
				$el.find( adapter.stripFields ).removeAttr( 'name' );
			}
		}

		function renderAll() {
			var settings = getSettings();
			var adapter = getAdapter();

			if ( ! apiReady || ! adapter || ! adapter.render || ! adapter.ready() || ! settings.siteKey ) {
				return;
			}

			$( '.edumall-captcha' ).each( function() {
				var $el = $( this );

				if ( $el.data( 'edumallCaptchaWidgetId' ) !== undefined ) {
					return;
				}

				var $token = findTokenInput( $el );

				var options = $.extend( {}, settings.renderOptions || {}, {
					sitekey: settings.siteKey,
					theme: settings.theme || 'light',
					callback: function( token ) {
						$token.val( token );
						stripProviderFields( $el );
					},
					'expired-callback': function() {
						$token.val( '' );
					},
					'error-callback': function() {
						$token.val( '' );
					}
				} );

				var widgetId = adapter.render( this, options );

				$el.data( 'edumallCaptchaWidgetId', widgetId );

				stripProviderFields( $el );
			} );
		}

		/**
		 * Fetch a reCAPTCHA v3 token into the given hidden input.
		 * Resolves in both branches so callers can always chain on it.
		 */
		function fillV3Input( input ) {
			var settings = getSettings();
			var adapter = getAdapter();

			return adapter.execute( settings.siteKey, settings.renderOptions || {} ).then( function( token ) {
				input.value = token;
				$( input ).data( 'edumallCaptchaTime', new Date().getTime() );
			}, function( error ) {
				if ( window.console && window.console.warn ) {
					window.console.warn( 'Edumall CAPTCHA: reCAPTCHA v3 token request failed. Check that the configured Site Key is a v3 key.', error );
				}
			} );
		}

		/**
		 * reCAPTCHA v3 is invisible: fetch a token for every form on screen and
		 * keep refreshing it, since v3 tokens expire after two minutes.
		 */
		function refreshV3Tokens() {
			var settings = getSettings();
			var adapter = getAdapter();

			if ( ! apiReady || ! isV3() || ! adapter.ready() || ! settings.siteKey ) {
				return;
			}

			var $inputs = $( 'input.edumall-captcha-v3' );

			if ( ! $inputs.length ) {
				return;
			}

			adapter.whenReady( function() {
				$inputs.each( function() {
					fillV3Input( this );
				} );
			} );

			// Background tabs throttle timers, so tokens are also refreshed on
			// tab focus and right before submit (below).
			if ( null === v3Timer ) {
				v3Timer = window.setInterval( refreshV3Tokens, 90000 );
			}
		}

		function initAll() {
			if ( hasPlaceholders() ) {
				ensureApi();
			}

			renderAll();
			refreshV3Tokens();
		}

		/**
		 * AJAX actions of the theme account forms a captcha can sit in
		 * (localized from the PHP form registry).
		 */
		function formActions() {
			return getSettings().formActions || [];
		}

		function matchFormAction( data ) {
			var actions = formActions();

			for ( var i = 0; i < actions.length; i++ ) {
				if ( data.indexOf( 'action=' + actions[ i ] ) !== -1 ) {
					return actions[ i ];
				}
			}

			return null;
		}

		function formsForAction( action, form ) {
			if ( form && $( form ).find( 'input[name="action"][value="' + action + '"]' ).length ) {
				return $( form );
			}

			return $( 'input[name="action"][value="' + action + '"]' ).closest( 'form' );
		}

		/**
		 * Reset the widget of the form that just posted the given AJAX action,
		 * leaving tokens already solved on other forms untouched.
		 */
		function resetForAction( action, form ) {
			if ( isV3() ) {
				// The submitted token is consumed - drop it right away so the
				// submit gate refetches instead of trusting a recent-looking
				// but already-used value while the async refresh is in flight.
				$( 'input.edumall-captcha-v3' ).val( '' ).removeData( 'edumallCaptchaTime' );
				refreshV3Tokens();
				return;
			}

			var adapter = getAdapter();

			if ( ! adapter || ! adapter.reset || ! adapter.ready() ) {
				return;
			}

			formsForAction( action, form ).find( '.edumall-captcha' ).each( function() {
				var $el = $( this );
				var widgetId = $el.data( 'edumallCaptchaWidgetId' );

				if ( widgetId === undefined ) {
					return;
				}

				findTokenInput( $el ).val( '' );

				try {
					adapter.reset( widgetId );
				} catch ( e ) {
					// The provider lost this widget (e.g. its script was loaded a
					// second time by another plugin): render a fresh one instead.
					$el.empty().removeData( 'edumallCaptchaWidgetId' );
					renderAll();
				}
			} );
		}

		/**
		 * The login challenge can be set to appear only after a few failed
		 * attempts. The popup form stays on screen between attempts, so when
		 * the server says the challenge is now required, drop the field into
		 * the slot the template left for it and render.
		 */
		function requireLoginChallenge( form ) {
			var settings = getSettings();
			var $slot = $( form ).find( '.edumall-captcha-slot' );

			if ( ! $slot.length || ! settings.siteKey ) {
				return;
			}

			var $field;

			if ( isV3() ) {
				$field = $( '<input>', {
					type: 'hidden',
					name: tokenField(),
					'class': 'edumall-captcha-v3',
					value: '',
					autocomplete: 'off'
				} );
			} else {
				$field = $( '<div class="form-group form-group-captcha"></div>' )
					.append( $( '<div class="edumall-captcha"></div>' ).attr( 'data-sitekey', settings.siteKey ) )
					.append( $( '<input>', {
						type: 'hidden',
						name: tokenField(),
						'class': 'edumall-captcha-token',
						value: '',
						autocomplete: 'off'
					} ) );
			}

			$slot.replaceWith( $field );

			initAll();
		}

		/**
		 * Called by the provider api.js once it has loaded (onload= query arg).
		 * Must exist before the api script runs, so it is defined at parse time.
		 */
		window.edumallCaptchaApiLoaded = function() {
			var name = GLOBALS[ getSettings().adapter ];

			if ( name && window[ name ] ) {
				apiObject = window[ name ];
			}

			apiReady = true;
			initAll();
		};

		/**
		 * Capture-phase submit gate. Remembers which captcha form posted (for a
		 * scoped reset) and, for reCAPTCHA v3, guarantees a fresh token at
		 * submit time: a stale/empty token is re-fetched and the jQuery submit
		 * pipeline (validate -> AJAX) is re-run. jQuery's trigger() does not
		 * re-fire native capture listeners, so this cannot loop.
		 *
		 * Only the theme's own AJAX forms are gated. The native
		 * WordPress/Tutor/WooCommerce forms submit synchronously and rely on
		 * their submit button's value, which a scripted re-submit would drop;
		 * their v3 token is instead kept fresh by the interval and
		 * visibilitychange refreshes below, well inside the 2-minute lifetime.
		 */
		document.addEventListener( 'submit', function( event ) {
			var form = event.target;
			var $form = $( form );

			if ( $form.find( '.edumall-captcha, input.edumall-captcha-v3' ).length ) {
				lastSubmittedForm = form;
			}

			var settings = getSettings();
			var adapter = getAdapter();

			if ( ! isV3() || ! settings.siteKey ) {
				return;
			}

			var $input = $form.find( 'input.edumall-captcha-v3' );

			// Only gate the theme's own AJAX forms (a jquery.validate instance
			// or the lost-password binding owns the submit). Native forms are
			// left to the interval/visibilitychange token refresh; scripting
			// their re-submit would drop the submit button's value.
			if ( ! $input.length || ( ! $form.data( 'validator' ) && 'edumall-lost-password-form' !== form.id ) ) {
				return;
			}

			// A token fetch is already in flight - swallow extra submits so a
			// double-click cannot queue a second AJAX POST.
			if ( $form.data( 'edumallCaptchaGatePending' ) ) {
				event.preventDefault();
				event.stopPropagation();
				return;
			}

			var fetchedAt = $input.data( 'edumallCaptchaTime' ) || 0;

			if ( $input.val() && new Date().getTime() - fetchedAt < V3_FRESH_MS ) {
				return;
			}

			event.preventDefault();
			event.stopPropagation();

			$form.data( 'edumallCaptchaGatePending', true );

			// Each gate attempt gets its own id. If the token fetch never
			// settles (script loaded but its challenge call stalls behind a
			// proxy or extension), a timeout clears the pending flag so the
			// visitor can retry - but the stalled attempt is then stale, and
			// its late resolve must not fire a second submit after the retry
			// already went through. The server fail-closes on an empty/stale
			// token, so clearing the flag never lets anything through unverified.
			var attempt = ( $form.data( 'edumallCaptchaGateAttempt' ) || 0 ) + 1;
			$form.data( 'edumallCaptchaGateAttempt', attempt );

			var gateTimer = window.setTimeout( function() {
				if ( $form.data( 'edumallCaptchaGateAttempt' ) !== attempt ) {
					return;
				}

				$form.data( 'edumallCaptchaGateAttempt', attempt + 1 );
				$form.removeData( 'edumallCaptchaGatePending' );
			}, 15000 );

			// The script may still be loading (on-demand load): wait for it.
			var whenReady = function( fn ) {
				if ( apiReady && adapter.ready() ) {
					adapter.whenReady( fn );
					return;
				}

				ensureApi();

				var poll = window.setInterval( function() {
					if ( apiReady && adapter.ready() ) {
						window.clearInterval( poll );
						adapter.whenReady( fn );
					}
				}, 100 );

				window.setTimeout( function() {
					window.clearInterval( poll );
				}, 15000 );
			};

			whenReady( function() {
				fillV3Input( $input.get( 0 ) ).then( function() {
					window.clearTimeout( gateTimer );

					// This attempt was superseded (it timed out, or a newer submit
					// started) - drop this resolve so a late token cannot queue a
					// duplicate submit.
					if ( $form.data( 'edumallCaptchaGateAttempt' ) !== attempt ) {
						return;
					}

					$form.removeData( 'edumallCaptchaGatePending' );
					$form.trigger( 'submit' );
				} );
			} );
		}, true );

		$( document ).ready( function() {
			initAll();
		} );

		/**
		 * The account popups are fetched over AJAX after page load - render any
		 * captcha container that arrives with them. Match the action name only,
		 * so custom 'edumall/ajax/get_endpoint' rewrites keep working.
		 */
		$( document ).on( 'ajaxSuccess', function( event, xhr, ajaxSettings ) {
			var url = ajaxSettings && ajaxSettings.url ? ajaxSettings.url.toString() : '';
			var marker = getSettings().lazyLoadMarker || 'lazy_load_template';

			if ( url.indexOf( marker ) === -1 ) {
				return;
			}

			initAll();
		} );

		/**
		 * Stamp the submitting form onto its own request, so two account forms
		 * in flight at once can never reset each other's widget.
		 */
		$( document ).on( 'ajaxSend', function( event, xhr, ajaxSettings ) {
			var data = ajaxSettings && 'string' === typeof ajaxSettings.data ? ajaxSettings.data : '';

			if ( matchFormAction( data ) && lastSubmittedForm ) {
				xhr.edumallCaptchaForm = lastSubmittedForm;
			}
		} );

		/**
		 * Tokens are single use - after a form attempt the widget must be
		 * reset (or a fresh v3 token fetched) so the visitor can try again.
		 * A failed login may also report that the challenge is now required.
		 */
		$( document ).on( 'ajaxComplete', function( event, xhr, ajaxSettings ) {
			var data = ajaxSettings && 'string' === typeof ajaxSettings.data ? ajaxSettings.data : '';
			var action = matchFormAction( data );

			if ( ! action ) {
				return;
			}

			var form = xhr && xhr.edumallCaptchaForm ? xhr.edumallCaptchaForm : lastSubmittedForm;

			resetForAction( action, form );

			var response = xhr && xhr.responseJSON ? xhr.responseJSON : null;

			if ( action === getSettings().loginAction && response && ! response.success && response.data && response.data.captcha_required ) {
				formsForAction( action, form ).each( function() {
					requireLoginChallenge( this );
				} );
			}
		} );

		/**
		 * Timers are throttled in background tabs - refresh v3 tokens as soon
		 * as the visitor returns, so a stale token is never submitted.
		 */
		$( document ).on( 'visibilitychange', function() {
			if ( ! document.hidden ) {
				refreshV3Tokens();
			}
		} );

		/**
		 * The register form widget can be initialized dynamically by Elementor.
		 */
		$( window ).on( 'elementor/frontend/init', function() {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/tm-register-form.default', function() {
					initAll();
				} );
			}
		} );

		// Small public surface for custom forms rendered later by other code.
		window.edumallCaptcha = {
			refresh: initAll,
			ensureApi: ensureApi
		};
	}
)( window, jQuery );
