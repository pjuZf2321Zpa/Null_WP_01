jQuery( document ).ready( function( $ ) {
	'use strict';

	paymentMethodChanged();
	linkOrderReviewToCheckoutForm();

	/**
	 * The order review table is printed in the sidebar, outside form.checkout.
	 * WooCommerce listens for shipping method changes on the form and submits only the form's own fields,
	 * so forward those changes to update_checkout and attach the table's fields to the form
	 * through the form attribute - otherwise the chosen shipping method never reaches the order.
	 */
	function linkOrderReviewToCheckoutForm() {
		var $form = $( 'form.checkout' ).first();

		if ( ! $form.length ) {
			return;
		}

		if ( ! $form.attr( 'id' ) ) {
			$form.attr( 'id', 'edumall-checkout-form' );
		}

		var formId = $form.attr( 'id' );

		function attachFields() {
			$( '.woocommerce-checkout-review-order-table' ).find( 'input, select, textarea' ).each( function() {
				if ( ! this.form ) {
					this.setAttribute( 'form', formId );
				}
			} );
		}

		attachFields();

		// The table is replaced on every update.
		$( document.body ).on( 'updated_checkout', attachFields );

		$( document.body ).on( 'change', '.woocommerce-checkout-review-order-table select.shipping_method, .woocommerce-checkout-review-order-table input[name^="shipping_method"]', function() {
			// Inside the form WooCommerce already handles it.
			if ( $( this ).closest( 'form.checkout' ).length ) {
				return;
			}

			$( document.body ).trigger( 'update_checkout', { current_target: this } );
		} );
	}

	function paymentMethodChanged() {
		var $orderReview = $( '#order_review' );

		$orderReview.on( 'click', 'input[name="payment_method"]', function() {
			var selectedClass = 'payment-selected';
			var parent = $( this ).parents( '.wc_payment_method' ).first();

			if ( ! parent.hasClass( selectedClass ) ) {
				parent.siblings().removeClass( selectedClass );
				parent.addClass( selectedClass );
			}
		} );
	}
} );
