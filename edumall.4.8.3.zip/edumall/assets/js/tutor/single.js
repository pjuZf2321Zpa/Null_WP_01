jQuery( document ).ready( function( $ ) {
	'use strict';

	var $navs = $( '#tutor-single-course-tabs-nav' );
	var activeClass = 'active';

	$navs.on( 'click', 'a', function( e ) {
		e.preventDefault();
		e.stopPropagation();

		var parent = $( this ).parent();

		if ( parent.hasClass( activeClass ) ) {
			return;
		}

		parent.siblings().removeClass( activeClass );
		parent.addClass( activeClass );

		var id = $( this ).attr( 'href' );

		var tabContent = $( id );

		if ( tabContent.length ) {
			tabContent.siblings().removeClass( activeClass );
			tabContent.addClass( activeClass );
		}

		$( document ).trigger( 'EdumallCourseTabsChange' );
	} );

	openRequestedTab();

	/**
	 * Honor Tutor LMS links to a course tab: ?page_tab= (or ?tab=) names the tab and
	 * #tutor-course-details-tab-wrapper asks to scroll to it. The "Go to all Q&A" button of
	 * the Tutor LMS 4.0.8+ dashboard sends ?page_tab=qna#tutor-course-details-tab-wrapper.
	 * Tutor's own tab keys map onto the Edumall tab ids; any other value names an Edumall
	 * tab directly (curriculum, instructors...). Layout 01 has no tabs, but its Q&A section
	 * carries the tab id, so the scroll still lands on it.
	 */
	function openRequestedTab() {
		var tutorTabs = {
			info: 'overview',
			questions: 'question-and-answer',
			qna: 'question-and-answer'
		};
		var params = new URLSearchParams( window.location.search );
		var requested = ( params.get( 'page_tab' ) || params.get( 'tab' ) || '' ).toLowerCase();
		var slug = Object.prototype.hasOwnProperty.call( tutorTabs, requested ) ? tutorTabs[ requested ] : requested;

		// Only what an id can hold goes into the selectors below.
		if ( ! /^[a-z0-9_-]+$/.test( slug ) ) {
			return;
		}

		var $tab = $( '#tutor-course-tab-' + slug );

		if ( ! $tab.length ) {
			return;
		}

		$navs.find( 'a[href="#tutor-course-tab-' + slug + '"]' ).trigger( 'click' );

		if ( '#tutor-course-details-tab-wrapper' !== window.location.hash ) {
			return;
		}

		var $target = $navs.length ? $navs : $tab;

		// Measure once the images above the tabs have taken their height.
		if ( 'complete' === document.readyState ) {
			scrollToElement( $target );
		} else {
			$( window ).one( 'load', function() {
				scrollToElement( $target );
			} );
		}
	}

	/**
	 * Scroll an element to the top of the viewport, below the sticky header and the admin
	 * bar - the offset the theme's smooth scroll links use (main.js).
	 */
	function scrollToElement( $target ) {
		var windowWidth = window.innerWidth;
		var $headerInner = $( '#page-header-inner' );
		var offset = 0;

		if ( 'undefined' !== typeof $edumall && $edumall.header_sticky_enable == 1 && $headerInner.data( 'sticky' ) == '1' ) {
			if ( $headerInner.data( 'header-vertical' ) != '1' || windowWidth < $edumall.mobile_menu_breakpoint ) {
				offset += $headerInner.height();
			}
		}

		if ( windowWidth > 600 ) {
			offset += $( '#wpadminbar' ).height() || 0;
		}

		$( 'html, body' ).animate( { scrollTop: Math.max( 0, $target.offset().top - offset ) }, 600 );
	}
} );
