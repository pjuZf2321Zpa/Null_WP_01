<?php
$section  = 'captcha';
$priority = 1;
$prefix   = 'captcha_';

$edumall_captcha           = Edumall_Captcha::instance();
$edumall_provider_choices  = array( '' => esc_html__( 'Disabled', 'edumall' ) ) + $edumall_captcha->get_provider_choices();
$edumall_key_providers     = array();
$edumall_visible_providers = array();

foreach ( $edumall_captcha->get_providers() as $edumall_provider_slug => $edumall_provider ) {
	if ( $edumall_provider->needs_keys() ) {
		$edumall_key_providers[] = $edumall_provider_slug;

		if ( ! $edumall_provider->is_invisible() ) {
			$edumall_visible_providers[] = $edumall_provider_slug;
		}
	}
}

Edumall_Kirki::add_field( 'theme', array(
	'type'        => 'select',
	'settings'    => 'captcha_provider',
	'label'       => esc_html__( 'CAPTCHA Provider', 'edumall' ),
	'description' => esc_html__( 'Protect the account, registration and comment forms against spam bots. Honeypot needs no keys and is invisible to visitors; reCAPTCHA, Turnstile and hCaptcha stop more advanced bots but require API keys.', 'edumall' ),
	'section'     => $section,
	'priority'    => $priority++,
	'default'     => 'honeypot',
	'choices'     => $edumall_provider_choices,
) );

Edumall_Kirki::add_field( 'theme', array(
	'type'            => 'multicheck',
	'settings'        => 'captcha_forms',
	'label'           => esc_html__( 'Protected Forms', 'edumall' ),
	'description'     => esc_html__( 'Registration covers the account popup, the Register Form widget, the instructor registration, the WordPress registration (wp-login.php), the Tutor LMS student and instructor registration and the WooCommerce My Account registration. Login and Lost Password cover the theme\'s account popups plus the wp-login.php, Tutor LMS and WooCommerce forms. Comments covers the guest comment and product review forms. Forms already protected by hCaptcha for WP, Simple Cloudflare Turnstile or Tutor Pro\'s Fraud Protection are left to that plugin.', 'edumall' ),
	'section'         => $section,
	'priority'        => $priority++,
	'default'         => array( 'register' ),
	'choices'         => $edumall_captcha->get_group_choices(),
	'active_callback' => array(
		array(
			'setting'  => 'captcha_provider',
			'operator' => '!=',
			'value'    => '',
		),
	),
) );

/*
 * One key pair per provider: every service issues its own, and a reCAPTCHA v2
 * pair does not work under v3, so switching provider must not silently reuse
 * the previous service's keys. Only the selected provider's pair is shown.
 */
$edumall_key_links = array(
	'recaptcha_v2' => esc_url( 'https://www.google.com/recaptcha/admin/create' ),
	'recaptcha_v3' => esc_url( 'https://www.google.com/recaptcha/admin/create' ),
	'turnstile'    => esc_url( 'https://dash.cloudflare.com/?to=/:account/turnstile' ),
	'hcaptcha'     => esc_url( 'https://dashboard.hcaptcha.com/sites' ),
);

$edumall_key_hints = array(
	'recaptcha_v2' => esc_html__( 'Use a reCAPTCHA v2 "I\'m not a robot" Checkbox key pair. A v3 key looks identical but will not work here.', 'edumall' ),
	'recaptcha_v3' => esc_html__( 'Use a reCAPTCHA v3 key pair. A v2 key looks identical but will not work here.', 'edumall' ),
	'turnstile'    => esc_html__( 'Use a Cloudflare Turnstile key pair.', 'edumall' ),
	'hcaptcha'     => esc_html__( 'Use an hCaptcha key pair.', 'edumall' ),
);

foreach ( $edumall_key_providers as $edumall_key_provider ) {
	$edumall_key_label = isset( $edumall_provider_choices[ $edumall_key_provider ] ) ? $edumall_provider_choices[ $edumall_key_provider ] : $edumall_key_provider;
	$edumall_key_hint  = isset( $edumall_key_hints[ $edumall_key_provider ] ) ? $edumall_key_hints[ $edumall_key_provider ] : '';
	$edumall_key_link  = isset( $edumall_key_links[ $edumall_key_provider ] ) ? $edumall_key_links[ $edumall_key_provider ] : '';

	$edumall_key_active = array(
		array(
			'setting'  => 'captcha_provider',
			'operator' => '==',
			'value'    => $edumall_key_provider,
		),
	);

	Edumall_Kirki::add_field( 'theme', array(
		'type'            => 'text',
		'settings'        => 'captcha_site_key_' . $edumall_key_provider,
		/* translators: %s: provider name. */
		'label'           => sprintf( esc_html__( 'Site Key (%s)', 'edumall' ), $edumall_key_label ),
		'description'     => '' !== $edumall_key_link
			/* translators: 1: hint about the key type, 2: URL where the keys are created. */
			? sprintf( wp_kses( __( '%1$s Create the keys at <a href="%2$s" target="_blank">this link</a> and add this site\'s domain to them.', 'edumall' ), array(
				'a' => array(
					'href'   => array(),
					'target' => array(),
				),
			) ), $edumall_key_hint, $edumall_key_link )
			/* translators: %s: hint about the key type. */
			: sprintf( esc_html__( '%s Add this site\'s domain to the keys.', 'edumall' ), $edumall_key_hint ),
		'section'         => $section,
		'priority'        => $priority++,
		'default'         => '',
		'active_callback' => $edumall_key_active,
	) );

	Edumall_Kirki::add_field( 'theme', array(
		'type'            => 'text',
		'settings'        => 'captcha_secret_key_' . $edumall_key_provider,
		/* translators: %s: provider name. */
		'label'           => sprintf( esc_html__( 'Secret Key (%s)', 'edumall' ), $edumall_key_label ),
		'description'     => esc_html__( 'Each provider keeps its own key pair, so you can switch between them without pasting the keys again. Both keys can also be set in wp-config.php as EDUMALL_CAPTCHA_SITE_KEY and EDUMALL_CAPTCHA_SECRET_KEY, which then apply to whichever provider is selected.', 'edumall' ),
		'section'         => $section,
		'priority'        => $priority++,
		'default'         => '',
		'active_callback' => $edumall_key_active,
	) );
}

Edumall_Kirki::add_field( 'theme', array(
	'type'            => 'number',
	'settings'        => 'captcha_recaptcha_v3_score',
	'label'           => esc_html__( 'reCAPTCHA v3 Score Threshold', 'edumall' ),
	'description'     => esc_html__( 'Submissions scoring below this value (0 - 1) are rejected. Higher is stricter.', 'edumall' ),
	'section'         => $section,
	'priority'        => $priority++,
	'default'         => 0.5,
	'choices'         => array(
		'min'  => 0,
		'max'  => 1,
		'step' => 0.05,
	),
	'active_callback' => array(
		array(
			'setting'  => 'captcha_provider',
			'operator' => '==',
			'value'    => 'recaptcha_v3',
		),
	),
) );

Edumall_Kirki::add_field( 'theme', array(
	'type'            => 'number',
	'settings'        => 'captcha_login_limit',
	'label'           => esc_html__( 'Show Login Challenge After', 'edumall' ),
	'description'     => esc_html__( 'Number of failed login attempts from the same IP address (within 15 minutes) before the challenge appears on the login forms. 0 shows it to everyone. Applies to the visible providers only.', 'edumall' ),
	'section'         => $section,
	'priority'        => $priority++,
	'default'         => 0,
	'choices'         => array(
		'min'  => 0,
		'max'  => 20,
		'step' => 1,
	),
	'active_callback' => array(
		array(
			'setting'  => 'captcha_provider',
			'operator' => 'in',
			'value'    => $edumall_visible_providers,
		),
		array(
			'setting'  => 'captcha_forms',
			'operator' => 'contains',
			'value'    => 'login',
		),
	),
) );

Edumall_Kirki::add_field( 'theme', array(
	'type'            => 'select',
	'settings'        => 'captcha_failsafe',
	'label'           => esc_html__( 'If the Provider Is Unreachable', 'edumall' ),
	'description'     => esc_html__( 'What happens when the verification service cannot be reached from your server (network outage, blocked outgoing requests). Block is the safe default; Allow lets submissions through unverified for two minutes after each failure so visitors are not locked out.', 'edumall' ),
	'section'         => $section,
	'priority'        => $priority++,
	'default'         => 'block',
	'choices'         => array(
		'block' => esc_html__( 'Block submissions (recommended)', 'edumall' ),
		'allow' => esc_html__( 'Allow submissions', 'edumall' ),
	),
	'active_callback' => array(
		array(
			'setting'  => 'captcha_provider',
			'operator' => 'in',
			'value'    => $edumall_key_providers,
		),
	),
) );

Edumall_Kirki::add_field( 'theme', array(
	'type'            => 'textarea',
	'settings'        => 'captcha_whitelist_ips',
	'label'           => esc_html__( 'Whitelisted IP Addresses', 'edumall' ),
	'description'     => esc_html__( 'One IP address per line. Visitors from these addresses skip the CAPTCHA on every form.', 'edumall' ),
	'section'         => $section,
	'priority'        => $priority++,
	'default'         => '',
	'active_callback' => array(
		array(
			'setting'  => 'captcha_provider',
			'operator' => '!=',
			'value'    => '',
		),
	),
) );
