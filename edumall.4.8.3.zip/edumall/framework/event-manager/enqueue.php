<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Event_Enqueue' ) ) {
	class Edumall_Event_Enqueue extends Edumall_Event {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ], 15 );

			add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ], 99 );
		}

		/**
		 * Enqueue scripts only used.
		 * Fixed datetime-jquery conflict with Zoom meeting in Tutor LMS.
		 */
		public function admin_enqueue_scripts() {
			$screen = get_current_screen();

			if ( 'tp_event' !== $screen->id ) {
				wp_deregister_script( 'wpems-admin-js' );
				wp_deregister_script( 'wpems-admin-datetimepicker-full' );
				wp_dequeue_script( 'wpems-admin-js' );
				wp_dequeue_script( 'wpems-admin-datetimepicker-full' );

				wp_deregister_style( 'wpems-admin-css' );
				wp_deregister_style( 'wpems-admin-datetimepicker-min' );
				wp_dequeue_style( 'wpems-admin-css' );
				wp_dequeue_style( 'wpems-admin-datetimepicker-min' );
			}
		}

		public function frontend_scripts() {
			$min = Edumall_Enqueue::instance()->get_min_suffix();

			/**
			 * Dequeue plugin assets (loaded globally by WPEMS); theme replacements load on event views only.
			 */
			wp_dequeue_script( 'wpems-owl-carousel-js' );
			wp_dequeue_style( 'wpems-owl-carousel-css' );

			wp_dequeue_script( 'wpems-magnific-popup-js' );
			wp_dequeue_style( 'wpems-magnific-popup-css' );

			wp_dequeue_script( 'wpems-countdown-plugin-js' );
			wp_dequeue_script( 'wpems-countdown-js' );
			wp_dequeue_style( 'wpems-countdown-css' );

			/**
			 * Re-write plugin js
			 * Use other countdown jquery.
			 * Remove unused code.
			 */
			wp_dequeue_script( 'wpems-frontend-js' );
			wp_dequeue_style( 'wpems-fronted-css' );

			wp_register_style( 'edumall-events-manager', EDUMALL_THEME_URI . "/events-manager{$min}.css", null, EDUMALL_THEME_VERSION );

			$load_events_styles = $this->is_archive() || $this->is_single();
			if ( apply_filters( 'edumall_enqueue_events_manager_styles', $load_events_styles ) ) {
				wp_enqueue_style( 'edumall-events-manager' );
			}

			if ( $this->is_archive() ) {
				wp_enqueue_script( 'edumall-grid-layout' );
			}

			if ( $this->is_single() ) {
				wp_enqueue_style( 'magnific-popup' );
				wp_enqueue_script( 'magnific-popup' );

				wp_enqueue_script( 'edumall-quantity-button' );

				$js_vars = wpems_l18n();

				wp_enqueue_script( 'edumall-events-manager', EDUMALL_THEME_ASSETS_URI . '/js/events-manager/single.js', [
					'jquery',
					'countdown',
				], EDUMALL_THEME_VERSION, true );

				wp_localize_script( 'edumall-events-manager', 'WPEMS', $js_vars );
			}
		}
	}
}
