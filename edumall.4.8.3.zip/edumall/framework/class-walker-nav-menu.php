<?php

class Edumall_Walker_Nav_Menu extends Walker_Nav_Menu {

	private $mega_menu = false;

	/**
	 * Item IDs (db_id) that have at least one mega menu child, collected while walking.
	 *
	 * @var array
	 */
	private $mega_menu_parents = array();

	/**
	 * Collect the parents of every mega menu item up front, so start_el() does not
	 * have to query the database once per menu item.
	 *
	 * Done here rather than in display_element() because Walker::walk() hands an empty
	 * $children_elements to the flat ( depth -1 ) and orphan passes.
	 */
	public function walk( $elements, $max_depth, ...$args ) {
		$this->mega_menu_parents = array();

		foreach ( $elements as $element ) {
			if ( isset( $element->object, $element->menu_item_parent ) && 'ic_mega_menu' === $element->object ) {
				$this->mega_menu_parents[ $element->menu_item_parent ] = true;
			}
		}

		return parent::walk( $elements, $max_depth, ...$args );
	}

	public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
		$id_field = $this->db_fields['id'];
		if ( is_object( $args[0] ) ) {
			$args[0]->has_children = ! empty( $children_elements[ $element->$id_field ] );
		}

		return parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
	}

	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		$indent          = '';
		$this->mega_menu = false;

		if ( $depth ) {
			$indent = str_repeat( "\t", $depth );
		}

		if ( ! isset( $item->ID ) ) {
			return;
		}

		$classes = array();
		if ( ! empty( $item->classes ) ) {
			$classes = (array) $item->classes;
		}

		$classes[] = 'menu-item-' . $item->ID;

		if ( $item->menu_item_parent === '0' ) {
			$classes[] = 'level-1';
		}

		$item_id = isset( $item->db_id ) ? $item->db_id : $item->ID;

		if ( ! empty( $this->mega_menu_parents[ $item_id ] ) ) {
			$classes[]       = apply_filters( 'insight_core_mega_menu_css_class', 'has-mega-menu', $item, $args, $depth );
			$this->mega_menu = true;
		}

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
		$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';

		$id = apply_filters( 'nav_menu_item_id', '', $item, $args, $depth );
		$id = $id ? ' id="' . esc_attr( $id ) . '"' : '';

		$output .= $indent . '<li' . $id . $class_names . '>';

		$atts           = array();
		$atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
		$atts['target'] = ! empty( $item->target ) ? $item->target : '';
		$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
		$atts['href']   = ! empty( $item->url ) ? $item->url : '';

		$atts       = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args, $depth );
		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( ! empty( $value ) ) {
				if ( $attr === 'href' ) {
					$value = esc_url( $value );
				} else {
					$value = esc_attr( $value );
				}
				$attributes .= ' ' . $attr . '="' . $value . '"';
			}
		}

		$item_output = $args->before;
		$item_output .= '<a' . $attributes . '><div class="menu-item-wrap">';
		$item_output .= '<span class="menu-item-title">' . $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after . '</span>';

		if ( $args->has_children ) {
			$item_output .= '<span class="toggle-sub-menu"> </span>';
		}

		$item_output .= '</div></a>';
		$item_output .= $args->after;

		if ( 'ic_mega_menu' === $item->object ) {
			$mega_menu_content_class = apply_filters( 'insight_core_mega_menu_content_css_class', 'mega-menu-content', $item, $args, $depth );

			$output .= '<div class="' . esc_attr( $mega_menu_content_class ) . '">' . do_shortcode( '[elementor-template id="' . $item->object_id . '"]' ) . '</div>';
		} else {
			$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
		}
	}

	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$class = 'sub-menu children';

		if ( $this->mega_menu ) {
			$class .= ' mega-menu';
		} else {
			$class .= ' simple-menu';
		}

		$indent = str_repeat( "\t", $depth );
		$output .= $indent . '<ul class="' . $class . '">';
	}
}
