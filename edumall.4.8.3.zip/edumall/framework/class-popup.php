<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Popup' ) ) {

	class Edumall_Popup {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_action( 'wp_footer', [ $this, 'add_popup_pre_loader' ] );

			add_action( 'edumall_ajax_lazy_load_template', [ $this, 'ajax_load_template_part' ] );
		}

		public function add_popup_pre_loader() {
			?>
			<div id="popup-pre-loader" class="popup-pre-loader">
				<div class="popup-load-inner">
					<div class="popup-loader-wrap">
						<div class="wrap-2">
							<div class="inner">
								<?php edumall_load_template( 'preloader/style', 'circle' ); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		public function ajax_load_template_part() {
			check_ajax_referer( 'edumall-security', 'security' );

			$template       = isset( $_GET['template'] ) && is_string( $_GET['template'] ) ? $this->sanitize_template_path( wp_unslash( $_GET['template'] ) ) : '';
			$template_scope = isset( $_GET['template_scope'] ) && is_string( $_GET['template_scope'] ) ? sanitize_file_name( wp_unslash( $_GET['template_scope'] ) ) : '';

			if ( empty( $template ) || empty( $template_scope ) ) {
				wp_send_json_error();
			}

			/**
			 * Exact allowlist of templates this public endpoint may render.
			 * Anything else (e.g. Tutor course content templates that rely on
			 * enrollment checks in their parent templates) must never be
			 * reachable here.
			 *
			 * @since 4.8.0
			 *
			 * @param array $templates Allowed template slugs, keyed by scope.
			 */
			$allowed_templates = apply_filters(
				'edumall_popup_lazy_load_templates',
				array(
					'theme-popup' => array(
						'popup-content-login',
						'popup-content-register',
						'popup-content-lost-password',
					),
					'tutor'       => array(
						'global/popup-content-instructor-registration',
					),
				)
			);

			if ( ! isset( $allowed_templates[ $template_scope ] ) || ! in_array( $template, $allowed_templates[ $template_scope ], true ) ) {
				wp_send_json_error();
			}

			$template_suffix = '';

			switch ( $template_scope ):
				case 'theme-popup':
					$template_suffix = 'template-parts/popup/';
					break;
				case 'tutor':
					$template_suffix = 'tutor/';
					break;
				default:
					wp_send_json_error();
					break;
			endswitch;

			$template_part = $template_suffix . $template;

			ob_start();
			get_template_part( $template_part );
			$html = ob_get_clean();

			$response = [
				'template' => $html,
			];

			wp_send_json_success( $response );
		}

		/**
		 * Sanitize a relative template path, keeping directory separators
		 * but cleaning every path segment. sanitize_file_name() alone strips
		 * the separators, which breaks sub-directory templates such as
		 * 'global/popup-content-instructor-registration'.
		 *
		 * @param string $path
		 *
		 * @return string
		 */
		private function sanitize_template_path( $path ) {
			$segments = array_filter( array_map( 'sanitize_file_name', explode( '/', $path ) ) );

			return implode( '/', $segments );
		}
	}

	Edumall_Popup::instance()->initialize();
}
