<?php
defined( 'ABSPATH' ) || exit;

require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-provider.php';
require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-provider-honeypot.php';
require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-provider-recaptcha-v2.php';
require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-provider-recaptcha-v3.php';
require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-provider-turnstile.php';
require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-provider-hcaptcha.php';
require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-compat.php';
require_once EDUMALL_FRAMEWORK_DIR . '/captcha/class-captcha-login-throttle.php';

if ( ! class_exists( 'Edumall_Captcha' ) ) {

	/**
	 * CAPTCHA protection for the account, comment and registration forms.
	 *
	 * Facade over a small set of collaborators:
	 *  - providers (framework/captcha/class-captcha-provider-*.php) print the
	 *    challenge and verify the token; Honeypot, reCAPTCHA v2/v3, Turnstile
	 *    and hCaptcha ship, more can be added via 'edumall_captcha_providers';
	 *  - a form registry (get_forms(), filter 'edumall_captcha_forms') lists
	 *    every render hook and verify hook the CAPTCHA attaches to: the theme's
	 *    own AJAX popups and Elementor widget, and the native WordPress,
	 *    WooCommerce and Tutor LMS login / registration / lost-password forms
	 *    plus the comment form;
	 *  - Edumall_Captcha_Compat steps aside on native forms another CAPTCHA
	 *    plugin already guards, and keeps that plugin off the theme popups;
	 *  - Edumall_Captcha_Login_Throttle counts failed logins per IP so the
	 *    login challenge can be shown only after N failures.
	 *
	 * Verification fails closed: a selected provider with a blank key, a
	 * missing token or a rejected token all block the submission. There are
	 * two deliberate exceptions: the optional failsafe for a provider outage,
	 * and the Login forms while the keys themselves are missing or rejected
	 * (see login_leniency_applies() - a typo must never lock a site's own
	 * administrators out of wp-login.php).
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha {

		/**
		 * The theme's own token field. Namespaced so it can never collide with
		 * another CAPTCHA plugin's g-recaptcha-response / cf-turnstile-response
		 * / h-captcha-response on a shared form: each side reads only its own
		 * token, so two guards on one form means two challenges, never a
		 * single-use token verified twice.
		 */
		const TOKEN_FIELD = 'edumall_captcha_token';

		/**
		 * Stamped the first time the honeypot trap is seen after it goes live -
		 * an admin page load, a front-end render, or the first verification,
		 * whichever comes first. A submission missing the trap is forgiven
		 * until this many seconds later, so a full-page cache filled before
		 * the update cannot lock visitors out during rollout.
		 */
		const HONEYPOT_SINCE_OPTION = 'edumall_captcha_honeypot_since';

		const HONEYPOT_GRACE = 172800; // 48 hours.

		/**
		 * Rolling 7-day count of rejections keyed by reason, so a genuine
		 * lockout stays visible to administrators.
		 */
		const HONEYPOT_REJECTS_TRANSIENT = 'edumall_captcha_honeypot_rejects';

		/**
		 * Last provider-side problem (unreachable, bad secret) for the admin notice.
		 */
		const LAST_ERROR_TRANSIENT = 'edumall_captcha_last_error';

		/**
		 * Set when the provider was switched without the keys being changed:
		 * every service issues its own key pair, and reCAPTCHA v2 and v3 keys
		 * look alike, so this is the only way to catch that mistake.
		 */
		const KEYS_STALE_TRANSIENT = 'edumall_captcha_keys_stale';

		/**
		 * Result of the last key probe (see probe_keys()): the provider's own
		 * verdict on the Secret Key, taken the moment the keys are saved.
		 */
		const KEY_PROBE_TRANSIENT = 'edumall_captcha_key_probe';

		/**
		 * Set after a provider outage when the failsafe is set to allow, so
		 * following submissions are let through without waiting on the
		 * timeout again.
		 */
		const BREAKER_TRANSIENT = 'edumall_captcha_breaker';

		const BREAKER_TTL = 120;

		/**
		 * Longest token accepted from a form (reCAPTCHA, Turnstile and hCaptcha
		 * tokens are all well under this).
		 */
		const MAX_TOKEN_LENGTH = 8192;

		const GROUPS = array( 'register', 'login', 'lost_password', 'comment' );

		protected static $instance = null;

		/**
		 * @var null|Edumall_Captcha_Provider[] Slug => provider.
		 */
		protected $providers = null;

		/**
		 * @var null|array Form registry.
		 */
		protected $forms = null;

		/**
		 * @var Edumall_Captcha_Compat
		 */
		protected $compat;

		/**
		 * @var Edumall_Captcha_Login_Throttle
		 */
		protected $throttle;

		/**
		 * Per-request verification result. Tokens are single use, so the
		 * provider must never be asked twice about the same token.
		 *
		 * @var null|bool
		 */
		protected $verify_result = null;

		/**
		 * @var array Last verification detail (reason, codes).
		 */
		protected $last_result = array();

		/**
		 * @var string Group being verified ('' outside a verification).
		 */
		protected $verifying_group = '';

		/**
		 * @var bool Whether a key probe is already queued for this request.
		 */
		protected $probe_scheduled = false;

		/**
		 * Verify hooks already attached, so a hook shared by several forms
		 * (lostpassword_post) is bound once and resolved by origin.
		 *
		 * @var array
		 */
		protected $bound_hooks = array();

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function __construct() {
			$this->compat   = new Edumall_Captcha_Compat();
			$this->throttle = new Edumall_Captcha_Login_Throttle( $this );
		}

		public function initialize() {
			$this->compat->initialize();
			$this->throttle->initialize();

			add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ), 12 );
			add_action( 'login_enqueue_scripts', array( $this, 'frontend_scripts' ) );
			add_filter( 'script_loader_tag', array( $this, 'async_defer_api_script' ), 10, 2 );

			add_action( 'admin_init', array( $this, 'maybe_stamp_honeypot_start' ) );
			add_action( 'admin_init', array( $this, 'maybe_probe_keys' ) );

			// Restart the honeypot grace window the moment the provider is saved
			// back to Honeypot, caught from the capability-checked save itself
			// rather than inferred later from an (unauthenticated) page load.
			add_action( 'update_option_theme_mods_' . get_stylesheet(), array( $this, 'on_theme_mods_updated' ), 10, 2 );

			add_action( 'admin_notices', array( $this, 'admin_notice_missing_keys' ) );
			add_action( 'admin_notices', array( $this, 'admin_notice_keys_not_updated' ) );
			add_action( 'admin_notices', array( $this, 'admin_notice_missing_trap' ) );
			add_action( 'admin_notices', array( $this, 'admin_notice_provider_error' ) );
			add_action( 'admin_notices', array( $this, 'admin_notice_tutor_pro_conflict' ) );
			add_action( 'admin_notices', array( $this, 'admin_notice_deferred_forms' ) );
			add_action( 'admin_notices', array( $this, 'admin_notice_plugin_conflicts' ) );

			foreach ( $this->get_forms() as $form_id => $form ) {
				$this->bind_form( $form_id, $form );
			}
		}

		/* ------------------------------------------------------------------
		 * Providers
		 * ---------------------------------------------------------------- */

		/**
		 * @return Edumall_Captcha_Provider[] Slug => provider.
		 */
		public function get_providers() {
			if ( null !== $this->providers ) {
				return $this->providers;
			}

			$providers = array(
				new Edumall_Captcha_Provider_Honeypot(),
				new Edumall_Captcha_Provider_Recaptcha_V2(),
				new Edumall_Captcha_Provider_Recaptcha_V3(),
				new Edumall_Captcha_Provider_Turnstile(),
				new Edumall_Captcha_Provider_Hcaptcha(),
			);

			/**
			 * Filters the available CAPTCHA providers.
			 *
			 * @since 4.8.0
			 *
			 * @param Edumall_Captcha_Provider[] $providers
			 */
			$providers = apply_filters( 'edumall_captcha_providers', $providers );

			$this->providers = array();

			foreach ( (array) $providers as $provider ) {
				if ( $provider instanceof Edumall_Captcha_Provider ) {
					$this->providers[ $provider->get_slug() ] = $provider;
				}
			}

			return $this->providers;
		}

		/**
		 * @return array Slug => label, for the Customizer.
		 */
		public function get_provider_choices() {
			$choices = array();

			foreach ( $this->get_providers() as $slug => $provider ) {
				$choices[ $slug ] = $provider->get_label();
			}

			return $choices;
		}

		/**
		 * @return string Provider slug or empty string when disabled.
		 */
		public function get_provider() {
			// Emergency switch for wp-config.php: a keyed provider on the Login
			// forms with a wrong key or blocked outgoing requests would otherwise
			// keep everyone, administrators included, out of wp-login.php.
			if ( defined( 'EDUMALL_CAPTCHA_DISABLE' ) && EDUMALL_CAPTCHA_DISABLE ) {
				return '';
			}

			$provider = (string) Edumall::setting( 'captcha_provider' );

			return isset( $this->get_providers()[ $provider ] ) ? $provider : '';
		}

		/**
		 * @return Edumall_Captcha_Provider|null
		 */
		public function get_provider_object() {
			$slug = $this->get_provider();

			return '' !== $slug ? $this->get_providers()[ $slug ] : null;
		}

		/**
		 * Whether the active provider needs API keys and an external script.
		 *
		 * @return bool
		 */
		public function provider_needs_keys() {
			$provider = $this->get_provider_object();

			return $provider && $provider->needs_keys();
		}

		/**
		 * Name of the Customizer setting holding one of the active provider's
		 * keys. Every service issues its own pair - and a reCAPTCHA v2 pair
		 * does not work under v3 - so each provider gets its own two settings
		 * and switching back and forth never loses a key.
		 *
		 * @param string $type     'site' or 'secret'.
		 * @param string $provider Provider slug; defaults to the active one.
		 *
		 * @return string
		 */
		public function get_key_setting( $type, $provider = null ) {
			$provider = null === $provider ? $this->get_provider() : $provider;

			return 'captcha_' . ( 'secret' === $type ? 'secret' : 'site' ) . '_key_' . $provider;
		}

		/**
		 * @param string $type     'site' or 'secret'.
		 * @param string $provider Provider slug; defaults to the active one.
		 *
		 * @return string
		 */
		public function get_key( $type, $provider = null ) {
			$provider = null === $provider ? $this->get_provider() : $provider;

			if ( '' === $provider ) {
				return '';
			}

			return trim( (string) Edumall::setting( $this->get_key_setting( $type, $provider ) ) );
		}

		public function get_site_key() {
			if ( defined( 'EDUMALL_CAPTCHA_SITE_KEY' ) && ! empty( EDUMALL_CAPTCHA_SITE_KEY ) ) {
				return trim( EDUMALL_CAPTCHA_SITE_KEY );
			}

			return $this->get_key( 'site' );
		}

		public function get_secret_key() {
			if ( defined( 'EDUMALL_CAPTCHA_SECRET_KEY' ) && ! empty( EDUMALL_CAPTCHA_SECRET_KEY ) ) {
				return trim( EDUMALL_CAPTCHA_SECRET_KEY );
			}

			return $this->get_key( 'secret' );
		}

		/* ------------------------------------------------------------------
		 * Settings
		 * ---------------------------------------------------------------- */

		public function is_enabled() {
			if ( '' === $this->get_provider() ) {
				return false;
			}

			// The honeypot is self-contained: no keys, no external service.
			if ( ! $this->provider_needs_keys() ) {
				return true;
			}

			return '' !== $this->get_site_key() && '' !== $this->get_secret_key();
		}

		/**
		 * Form groups the CAPTCHA is applied to.
		 *
		 * @return array Subset of self::GROUPS.
		 */
		public function get_enabled_forms() {
			$forms = Edumall::setting( 'captcha_forms', array( 'register' ) );

			if ( ! is_array( $forms ) ) {
				$forms = array( 'register' );
			}

			return array_values( array_intersect( $forms, self::GROUPS ) );
		}

		/**
		 * @param string $form One of self::GROUPS.
		 *
		 * @return bool
		 */
		public function is_enabled_for( $form ) {
			if ( ! $this->is_enabled() ) {
				return false;
			}

			return in_array( $form, $this->get_enabled_forms(), true );
		}

		/**
		 * Whether the feature is set to guard this form group, regardless of
		 * whether a key-based provider is fully configured. A selected-but-
		 * mis-keyed provider still guards the form - it simply cannot verify,
		 * so it must fail closed (see is_misconfigured()) rather than wave
		 * submissions through. Unlike is_enabled_for(), this stays true when a
		 * key is blank.
		 *
		 * @param string $form One of self::GROUPS.
		 *
		 * @return bool
		 */
		public function is_guarding( $form ) {
			if ( '' === $this->get_provider() ) {
				return false;
			}

			return in_array( $form, $this->get_enabled_forms(), true );
		}

		/**
		 * A key-based provider is selected but a Site or Secret key is missing,
		 * so no widget can be rendered and no token can be verified. In this
		 * state the guarded forms must be rejected, never allowed: a blank key
		 * must never silently mean "no protection". The Login forms are the
		 * exception - see verify_group() and login_leniency_applies().
		 *
		 * @return bool
		 */
		public function is_misconfigured() {
			if ( ! $this->provider_needs_keys() ) {
				return false;
			}

			return '' === $this->get_site_key() || '' === $this->get_secret_key();
		}

		/**
		 * Minimum acceptable reCAPTCHA v3 score (0 - 1).
		 *
		 * @return float
		 */
		public function get_v3_score_threshold() {
			$raw = Edumall::setting( 'captcha_recaptcha_v3_score', 0.5 );

			// A cleared field or an imported garbage value must fall back to the
			// default instead of silently disabling score enforcement via 0.
			if ( ! is_numeric( $raw ) ) {
				return 0.5;
			}

			$score = (float) $raw;

			if ( $score < 0 || $score > 1 ) {
				$score = 0.5;
			}

			return $score;
		}

		/**
		 * Failed logins per IP before the login challenge is shown. 0 = always.
		 *
		 * @return int
		 */
		public function get_login_limit() {
			return max( 0, absint( Edumall::setting( 'captcha_login_limit', 0 ) ) );
		}

		/**
		 * What to do when the provider cannot be reached at all.
		 *
		 * @return string 'block' (fail closed, default) or 'allow'.
		 */
		public function get_failsafe_mode() {
			return 'allow' === Edumall::setting( 'captcha_failsafe', 'block' ) ? 'allow' : 'block';
		}

		/**
		 * @return int Seconds to wait on the provider's siteverify endpoint.
		 */
		public function get_request_timeout() {
			/**
			 * Filters the siteverify request timeout.
			 *
			 * @since 4.8.0
			 *
			 * @param int $seconds Default 5.
			 */
			return max( 1, (int) apply_filters( 'edumall_captcha_request_timeout', 5 ) );
		}

		/**
		 * Widget language for the providers that accept one. Empty means the
		 * provider auto-detects the visitor's browser language.
		 *
		 * @return string
		 */
		public function get_language() {
			/**
			 * Filters the CAPTCHA widget language (e.g. 'vi', 'en', 'zh-CN').
			 * Empty string lets the provider auto-detect.
			 *
			 * @since 4.8.0
			 *
			 * @param string $language Default ''.
			 */
			return (string) apply_filters( 'edumall_captcha_language', '' );
		}

		/**
		 * @return string[] Whitelisted IPs from the Customizer.
		 */
		public function get_whitelisted_ips() {
			$raw = (string) Edumall::setting( 'captcha_whitelist_ips', '' );
			$ips = array_filter( array_map( 'trim', preg_split( '/[\s,]+/', $raw ) ) );

			/**
			 * Filters the IPs the CAPTCHA is skipped for.
			 *
			 * @since 4.8.0
			 *
			 * @param string[] $ips
			 */
			return array_values( array_unique( (array) apply_filters( 'edumall_captcha_whitelisted_ips', $ips ) ) );
		}

		/**
		 * @return string Client IP, or '' when unknown.
		 */
		public function get_client_ip() {
			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

			/**
			 * Filters the client IP used for the whitelist, the login throttle
			 * and the provider's remoteip. Sites behind a trusted proxy can map
			 * the forwarded header here.
			 *
			 * @since 4.8.0
			 *
			 * @param string $ip
			 */
			$ip = (string) apply_filters( 'edumall_captcha_client_ip', $ip );

			return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
		}

		/**
		 * @return bool Whether the current visitor's IP is whitelisted.
		 */
		public function is_whitelisted() {
			$ip = $this->get_client_ip();

			return '' !== $ip && in_array( $ip, $this->get_whitelisted_ips(), true );
		}

		/**
		 * @return Edumall_Captcha_Compat
		 */
		public function get_compat() {
			return $this->compat;
		}

		/**
		 * @return Edumall_Captcha_Login_Throttle
		 */
		public function get_login_throttle() {
			return $this->throttle;
		}

		/* ------------------------------------------------------------------
		 * Form registry
		 * ---------------------------------------------------------------- */

		/**
		 * Every form the CAPTCHA can attach to.
		 *
		 * Keys per entry:
		 *  - group:       register | login | lost_password | comment (Customizer toggle)
		 *  - render:      action hook the field is printed on ('' = none)
		 *  - verify:      [ hook, shape, priority, accepted_args ] - see bind_form()
		 *  - ajax_action: the theme AJAX action of the form (captcha.js resets it)
		 *  - native:      true for forms the theme does not own; these honour the
		 *                 whitelist and step aside for other CAPTCHA plugins
		 *  - origin:      callable deciding whether the current request is this
		 *                 form's submission (for hooks shared by several forms)
		 *  - compat:      callable returning the Compat form id for the request
		 *  - render_filter: filter whose content the field is appended to (for
		 *                 forms that only apply a filter, e.g. login_form_middle)
		 *  - fallback:    verify an unrecognised public POST on this entry's hook
		 *                 as this form instead of leaving it alone
		 *  - skip_when:   callable; true skips the form on this request
		 *  - privileged_cap: capability that lets a logged-in user skip the check
		 *  - guest_only:  skip for logged-in visitors
		 *
		 * @return array
		 */
		public function get_forms() {
			if ( null !== $this->forms ) {
				return $this->forms;
			}

			$forms = array(
				// The theme's own AJAX forms. Their handlers call verify_for()
				// (popup register / login) or run the short-circuit filters.
				'popup_register'            => array(
					'group'       => 'register',
					'render'      => 'edumall_popup_register_after_form_fields',
					'ajax_action' => 'edumall_user_register',
				),
				'popup_instructor_register' => array(
					'group'       => 'register',
					'render'      => 'edumall_popup_instructor_registration_after_form_fields',
					'ajax_action' => 'edumall_instructor_register',
					'verify'      => array(
						'hook'  => 'edumall_pre_instructor_register',
						'shape' => 'short_circuit',
					),
				),
				'elementor_register'        => array(
					'group'       => 'register',
					'render'      => 'edumall_elementor_register_form_after_form_fields',
					'ajax_action' => 'edumall_elementor_widget_user_register',
					'verify'      => array(
						'hook'  => 'edumall_elementor_widget_pre_user_register',
						'shape' => 'short_circuit',
					),
				),
				'popup_login'               => array(
					'group'       => 'login',
					'render'      => 'edumall_after_popup_login_form_fields',
					'ajax_action' => 'edumall_user_login',
				),
				'popup_lost_password'       => array(
					'group'       => 'lost_password',
					'render'      => 'edumall_popup_lost_password_after_form_fields',
					'ajax_action' => 'edumall_user_reset_password',
					'verify'      => array(
						'hook'  => 'edumall_pre_user_reset_password',
						'shape' => 'short_circuit',
					),
				),

				// Native registration: wp-login.php?action=register and the Tutor
				// LMS student / instructor registration pages, which fire the same
				// register_form / registration_errors hooks.
				'wp_register'               => array(
					'group'          => 'register',
					'render'         => 'register_form',
					'verify'         => array(
						'hook'          => 'registration_errors',
						'shape'         => 'wp_error',
						'accepted_args' => 3,
					),
					'native'         => true,
					'privileged_cap' => 'create_users',
					'compat'         => array( $this, 'compat_context_wp_or_tutor_register' ),
				),
				// woocommerce_process_registration_errors fires only for the My
				// Account form, never for the account checkout creates.
				'wc_register'               => array(
					'group'          => 'register',
					'render'         => 'woocommerce_register_form',
					'verify'         => array(
						'hook'          => 'woocommerce_process_registration_errors',
						'shape'         => 'wp_error',
						'accepted_args' => 4,
					),
					'native'         => true,
					'privileged_cap' => 'create_users',
					'compat'         => 'wc_register',
				),

				// Native login. login_form fires on wp-login.php and inside the
				// Tutor login template; wp-login.php is verified on
				// 'authenticate' (only for its own POST), Tutor and WooCommerce
				// on their pre-signon error filters.
				'wp_login'                  => array(
					'group'         => 'login',
					'render'        => 'login_form',
					// wp_login_form() (login widget/block, BuddyPress, Elementor Pro)
					// posts to wp-login.php too but only applies this filter.
					'render_filter' => 'login_form_middle',
					'verify'        => array(
						'hook'          => 'authenticate',
						'shape'         => 'authenticate',
						'priority'      => 30,
						'accepted_args' => 3,
					),
					'native'        => true,
					'origin'        => array( $this, 'origin_wp_login' ),
					'compat'        => array( $this, 'compat_context_wp_or_tutor_login' ),
				),
				'wc_login'                  => array(
					'group'  => 'login',
					'render' => 'woocommerce_login_form',
					'verify' => array(
						'hook'          => 'woocommerce_process_login_errors',
						'shape'         => 'wp_error',
						'accepted_args' => 3,
					),
					'native' => true,
					'compat' => 'wc_login',
				),
				// Tutor's login handler re-adds whatever tutor_process_login_errors
				// returns (one message shown twice), so it is verified where the
				// wp-login.php form is: on 'authenticate', inside Tutor's wp_signon(),
				// which Tutor reports once.
				'tutor_login'               => array(
					'group'  => 'login',
					'render' => '',
					'verify' => array(
						'hook'          => 'authenticate',
						'shape'         => 'authenticate',
						'priority'      => 30,
						'accepted_args' => 3,
					),
					'native' => true,
					'origin' => array( $this, 'origin_tutor_login' ),
					'compat' => 'tutor_login',
				),

				// Native lost password. lostpassword_post is fired by wp-login.php,
				// WooCommerce and Tutor alike; the origin callables tell them apart.
				// A public POST none of them recognises is still verified, as the
				// wp-login.php form ('fallback'), so a bot cannot pick an origin
				// that skips the check; a logged-in staff member is exempt via
				// privileged_cap and other callers can use edumall_captcha_skip.
				'wp_lost_password'          => array(
					'group'          => 'lost_password',
					'render'         => 'lostpassword_form',
					'verify'         => array(
						'hook'          => 'lostpassword_post',
						'shape'         => 'wp_error_action',
						'accepted_args' => 2,
					),
					'native'         => true,
					'privileged_cap' => 'edit_users',
					'origin'         => array( $this, 'origin_wp_login_page' ),
					'fallback'       => true,
					'compat'         => 'wp_lost_password',
				),
				'wc_lost_password'          => array(
					'group'          => 'lost_password',
					'render'         => 'woocommerce_lostpassword_form',
					'verify'         => array(
						'hook'          => 'lostpassword_post',
						'shape'         => 'wp_error_action',
						'accepted_args' => 2,
					),
					'native'         => true,
					'privileged_cap' => 'edit_users',
					'origin'         => array( $this, 'origin_wc_lost_password' ),
					'compat'         => 'wc_lost_password',
				),
				'tutor_lost_password'       => array(
					'group'          => 'lost_password',
					'render'         => 'tutor_lostpassword_form',
					'verify'         => array(
						'hook'          => 'lostpassword_post',
						'shape'         => 'wp_error_action',
						'accepted_args' => 2,
					),
					'native'         => true,
					'privileged_cap' => 'edit_users',
					'origin'         => array( $this, 'origin_tutor_lost_password' ),
					'compat'         => 'tutor_lost_password',
				),

				// Comment form (also WooCommerce product reviews). Guests only:
				// pre_comment_on_post is where wp-comments-post.php validates.
				'comment'                   => array(
					'group'      => 'comment',
					'render'     => 'comment_form_after_fields',
					// Jetpack Comments replaces the form with its own iframe, which
					// never carries the field; leave those to Jetpack/Akismet.
					'skip_when'  => array( $this, 'is_jetpack_comments_active' ),
					'verify'     => array(
						'hook'          => 'pre_comment_on_post',
						'shape'         => 'die',
						'accepted_args' => 1,
					),
					'native'     => true,
					'guest_only' => true,
					'compat'     => 'comment',
				),
			);

			/**
			 * Filters the forms the CAPTCHA attaches to. See get_forms() for
			 * the entry keys.
			 *
			 * @since 4.8.0
			 *
			 * @param array $forms
			 */
			$this->forms = (array) apply_filters( 'edumall_captcha_forms', $forms );

			return $this->forms;
		}

		/**
		 * Every per-provider key setting, including those a filter added, so
		 * the URL-override lock and the WPML exclusion list cannot drift from
		 * the fields the Customizer actually renders.
		 *
		 * @return string[]
		 */
		public function get_key_setting_names() {
			$names = array();

			foreach ( $this->get_providers() as $slug => $provider ) {
				if ( ! $provider->needs_keys() ) {
					continue;
				}

				$names[] = $this->get_key_setting( 'site', $slug );
				$names[] = $this->get_key_setting( 'secret', $slug );
			}

			return $names;
		}

		/**
		 * @return array Native form id => human-readable label (admin notices).
		 */
		public function get_form_labels() {
			return array(
				'wp_register'         => esc_html__( 'WordPress registration', 'edumall' ),
				'wp_login'            => esc_html__( 'WordPress login', 'edumall' ),
				'wp_lost_password'    => esc_html__( 'WordPress lost password', 'edumall' ),
				'comment'             => esc_html__( 'comments', 'edumall' ),
				'wc_register'         => esc_html__( 'WooCommerce registration', 'edumall' ),
				'wc_login'            => esc_html__( 'WooCommerce login', 'edumall' ),
				'wc_lost_password'    => esc_html__( 'WooCommerce lost password', 'edumall' ),
				'tutor_register'      => esc_html__( 'Tutor LMS registration', 'edumall' ),
				'tutor_login'         => esc_html__( 'Tutor LMS login', 'edumall' ),
				'tutor_lost_password' => esc_html__( 'Tutor LMS lost password', 'edumall' ),
			);
		}

		/**
		 * @return string[] AJAX actions of the theme forms, for captcha.js.
		 */
		public function get_ajax_actions() {
			$actions = array();

			foreach ( $this->get_forms() as $form ) {
				if ( ! empty( $form['ajax_action'] ) ) {
					$actions[] = (string) $form['ajax_action'];
				}
			}

			return array_values( array_unique( $actions ) );
		}

		/**
		 * @return array Group => label, for the Customizer.
		 */
		public function get_group_choices() {
			return array(
				'register'      => esc_html__( 'Registration', 'edumall' ),
				'login'         => esc_html__( 'Login', 'edumall' ),
				'lost_password' => esc_html__( 'Lost Password', 'edumall' ),
				'comment'       => esc_html__( 'Comments (guests)', 'edumall' ),
			);
		}

		/**
		 * Attach a registry entry's render and verify hooks.
		 *
		 * @param string $form_id
		 * @param array  $form
		 */
		protected function bind_form( $form_id, $form ) {
			if ( ! empty( $form['render'] ) ) {
				$render = function () use ( $form_id ) {
					$this->render_for_form( $form_id );
				};

				add_action( $form['render'], $render );
			}

			if ( ! empty( $form['render_filter'] ) ) {
				$append = function ( $content = '' ) use ( $form_id ) {
					return $this->append_field_to_content( $content, $form_id );
				};

				add_filter( $form['render_filter'], $append, 20 );
			}

			if ( empty( $form['verify']['hook'] ) ) {
				return;
			}

			$hook     = (string) $form['verify']['hook'];
			$shape    = isset( $form['verify']['shape'] ) ? (string) $form['verify']['shape'] : 'wp_error';
			$priority = isset( $form['verify']['priority'] ) ? (int) $form['verify']['priority'] : 10;
			$args     = isset( $form['verify']['accepted_args'] ) ? (int) $form['verify']['accepted_args'] : 1;
			$key      = $hook . '|' . $shape . '|' . $priority;

			// One binding per hook: the callback resolves which registered form
			// this request belongs to (see resolve_form_for_hook()).
			$this->bound_hooks[ $key ][] = $form_id;

			if ( count( $this->bound_hooks[ $key ] ) > 1 ) {
				return;
			}

			switch ( $shape ) {
				case 'short_circuit':
					$callback = function ( $result ) use ( $key ) {
						return $this->verify_short_circuit( $result, $this->resolve_form_for_hook( $key ) );
					};

					add_filter( $hook, $callback, $priority, 1 );
					break;

				case 'wp_error':
					$callback = function ( $errors ) use ( $key ) {
						return $this->verify_wp_error( $errors, $this->resolve_form_for_hook( $key ) );
					};

					add_filter( $hook, $callback, $priority, $args );
					break;

				case 'wp_error_action':
					$callback = function ( $errors ) use ( $key ) {
						$this->verify_wp_error( $errors, $this->resolve_form_for_hook( $key ) );
					};

					add_action( $hook, $callback, $priority, $args );
					break;

				case 'authenticate':
					$callback = function ( $user ) use ( $key ) {
						return $this->verify_authenticate( $user, $this->resolve_form_for_hook( $key ) );
					};

					add_filter( $hook, $callback, $priority, $args );

					/*
					 * Also cut in before the password is ever checked.
					 * 'authenticate' runs after wp_authenticate_username_password
					 * (priority 20), which looks the account up, fires
					 * wp_authenticate_user - where Tutor Pro's 2FA e-mails an OTP
					 * and redirects - and only then compares the password. Hooking
					 * that filter first means an unverified request never gets a
					 * password check, an OTP or a distinguishable answer. The
					 * result is memoised, so the callback above reuses it for the
					 * unknown-account path, which never reaches this filter.
					 */
					add_filter(
						'wp_authenticate_user',
						function ( $user ) use ( $key ) {
							return $this->verify_authenticate( $user, $this->resolve_form_for_hook( $key ) );
						},
						1,
						1
					);
					break;

				case 'die':
					$callback = function () use ( $key ) {
						$this->verify_or_die( $this->resolve_form_for_hook( $key ) );
					};

					add_action( $hook, $callback, $priority, $args );
					break;
			}
		}

		/**
		 * Which of the forms bound to a hook the current request belongs to:
		 * the first whose 'origin' test passes (a form without one always
		 * passes). Empty string when none does, i.e. an unrecognised caller.
		 *
		 * @param string $key Binding key.
		 *
		 * @return string Form id or ''.
		 */
		protected function resolve_form_for_hook( $key ) {
			$forms = $this->get_forms();

			$fallback = '';

			foreach ( (array) $this->bound_hooks[ $key ] as $form_id ) {
				if ( ! isset( $forms[ $form_id ] ) ) {
					continue;
				}

				$origin = isset( $forms[ $form_id ]['origin'] ) ? $forms[ $form_id ]['origin'] : null;

				if ( null === $origin || ( is_callable( $origin ) && call_user_func( $origin ) ) ) {
					return $form_id;
				}

				if ( '' === $fallback && ! empty( $forms[ $form_id ]['fallback'] ) ) {
					$fallback = $form_id;
				}
			}

			// Nothing recognised the request. A public front-end POST is still
			// held to the fallback form's check (fail closed); admin, CLI, cron
			// and API callers are not what the CAPTCHA is for.
			return '' !== $fallback && $this->is_public_post() ? $fallback : '';
		}

		/**
		 * @return bool Whether this is a front-end POST from a visitor.
		 */
		protected function is_public_post() {
			if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
				return false;
			}

			if ( ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
				return false;
			}

			return ! is_admin() || wp_doing_ajax();
		}

		/* Origin tests for hooks shared by several forms. --------------- */

		/**
		 * @return bool wp-login.php login POST.
		 */
		public function origin_wp_login() {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- routing only.
			return did_action( 'login_init' ) && isset( $_POST['log'] ) && ! wp_doing_ajax();
		}

		/**
		 * @return bool Any wp-login.php request.
		 */
		public function origin_wp_login_page() {
			return (bool) did_action( 'login_init' );
		}

		/**
		 * @return bool WooCommerce lost-password POST. Keyed on the field
		 *              WooCommerce itself dispatches on, not on the nonce field
		 *              name (WooCommerce also accepts the nonce as _wpnonce).
		 */
		public function origin_wc_lost_password() {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- routing only.
			return isset( $_POST['wc_reset_password'] );
		}

		/**
		 * @return bool Tutor's login form POST (its handler calls wp_signon()).
		 */
		public function origin_tutor_login() {
			/*
			 * Deliberately not narrowed to non-AJAX requests. Tutor dispatches
			 * tutor_action from 'init', which also runs on admin-ajax.php and
			 * xmlrpc.php, so excluding those left process_tutor_login() calling
			 * wp_signon() with no form to resolve and no challenge to answer.
			 * Only Tutor's two login templates ever send this value, and both
			 * post to the page, so nothing legitimate is caught by widening it.
			 */
			return 'tutor_user_login' === $this->tutor_action();
		}

		/**
		 * This request's tutor_action, normalised exactly the way Tutor
		 * normalises it before dispatching (Input::sanitize_request_data()).
		 * Comparing the raw value instead would miss "tutor_user_login " and
		 * "<i>tutor_user_login", which sanitize_text_field() reduces to the
		 * name Tutor then dispatches - so the handler would run while this
		 * resolved to no form, and to no challenge.
		 *
		 * @return string
		 */
		public function tutor_action() {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing only.
			if ( ! isset( $_REQUEST['tutor_action'] ) || ! is_string( $_REQUEST['tutor_action'] ) ) {
				return '';
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing only.
			return sanitize_text_field( wp_unslash( $_REQUEST['tutor_action'] ) );
		}

		/**
		 * @return bool Tutor LMS's own lost-password handler. Narrowed to the one
		 *              action Tutor routes to retrieve_password(): matching any
		 *              tutor_action let a request name an arbitrary one and be
		 *              attributed to a form the coexisting plugins then appear to
		 *              cover, while none of their checks would run. Anything else
		 *              falls through to the fail-closed wp_lost_password entry.
		 */
		public function origin_tutor_lost_password() {
			return 'tutor_retrieve_password' === $this->tutor_action();
		}

		/**
		 * @return bool Whether Jetpack's Comments module owns the comment form.
		 */
		public function is_jetpack_comments_active() {
			return class_exists( 'Jetpack' ) && method_exists( 'Jetpack', 'is_module_active' ) && \Jetpack::is_module_active( 'comments' );
		}

		/* Compat contexts for hooks shared between WordPress and Tutor. --- */

		/**
		 * @return string
		 */
		public function compat_context_wp_or_tutor_register() {
			if ( did_action( 'login_init' ) || ! function_exists( 'tutor' ) ) {
				return 'wp_register';
			}

			if ( '' !== $this->tutor_action() ) {
				return 'tutor_register';
			}

			// Rendering: only inside Tutor's own registration templates, which
			// bracket the form with these actions. Any other form firing
			// register_form (a registration widget, a page builder) is not a
			// Tutor form, and the plugins that guard Tutor forms cannot see it.
			return $this->in_tutor_template( 'tutor_before_student_reg_form', 'tutor_after_student_reg_form' )
				|| $this->in_tutor_template( 'tutor_before_instructor_reg_form', 'tutor_after_instructor_reg_form' )
				? 'tutor_register' : 'wp_register';
		}

		/**
		 * Whether the output being rendered sits between the two actions a
		 * Tutor template brackets its form with. This is how Tutor Pro spots
		 * its own forms too (it sets $GLOBALS['pagenow'] on the same hooks).
		 *
		 * @param string $open  Action fired before the form.
		 * @param string $close Action fired after the form.
		 *
		 * @return bool
		 */
		protected function in_tutor_template( $open, $close ) {
			return did_action( $open ) > did_action( $close );
		}

		/**
		 * @return string
		 */
		public function compat_context_wp_or_tutor_login() {
			if ( did_action( 'login_init' ) || ! function_exists( 'tutor' ) ) {
				return 'wp_login';
			}

			if ( '' !== $this->tutor_action() ) {
				return 'tutor_login';
			}

			// Rendering: only inside Tutor's own login template. A login widget,
			// block or page-builder form elsewhere on the site posts to
			// wp-login.php, so it is the WordPress login as far as the other
			// CAPTCHA plugins are concerned - and none of them render into it.
			return $this->in_tutor_template( 'tutor_before_login_form', 'tutor_after_login_form' ) ? 'tutor_login' : 'wp_login';
		}

		/**
		 * @param string $form_id
		 *
		 * @return array Registry entry or empty array.
		 */
		public function get_form( $form_id ) {
			$forms = $this->get_forms();

			return isset( $forms[ $form_id ] ) ? (array) $forms[ $form_id ] : array();
		}

		/**
		 * @param string $form_id
		 *
		 * @return string The entry's group, or '' for an unknown form.
		 */
		public function get_form_group( $form_id ) {
			$form = $this->get_form( $form_id );

			return isset( $form['group'] ) ? (string) $form['group'] : '';
		}

		/**
		 * Which other CAPTCHA plugin guards this form on this request, if any.
		 *
		 * @param string $form_id
		 *
		 * @return string Plugin slug or ''.
		 */
		public function plugin_guarding_form( $form_id ) {
			$form = $this->get_form( $form_id );

			if ( empty( $form['native'] ) || empty( $form['compat'] ) ) {
				return '';
			}

			$context = is_callable( $form['compat'] ) ? (string) call_user_func( $form['compat'] ) : (string) $form['compat'];

			return $this->compat->plugin_guarding( $context );
		}

		/**
		 * Why the CAPTCHA is skipped for this form on this request, if it is:
		 * '' (not skipped), 'skip_when', 'guest', 'privileged', 'plugin:<slug>'
		 * (another CAPTCHA plugin guards it), 'whitelist' or 'filter'.
		 *
		 * @param string $form_id
		 *
		 * @return string
		 */
		public function skip_reason( $form_id ) {
			$form   = $this->get_form( $form_id );
			$reason = '';

			if ( ! empty( $form['skip_when'] ) && is_callable( $form['skip_when'] ) && call_user_func( $form['skip_when'] ) ) {
				$reason = 'skip_when';
			} elseif ( ! empty( $form['guest_only'] ) && is_user_logged_in() ) {
				$reason = 'guest';
			} elseif ( ! empty( $form['privileged_cap'] ) && is_user_logged_in() && current_user_can( $form['privileged_cap'] ) ) {
				// A staff member or a programmatic caller creating an account or
				// sending a reset link is not a spam bot.
				$reason = 'privileged';
			} elseif ( $this->is_whitelisted() ) {
				// Before the plugin deferral: a whitelisted visitor is exempt from
				// every check, including the token-presence check that deferral
				// leaves behind.
				$reason = 'whitelist';
			} elseif ( ! empty( $form['native'] ) && '' !== $this->plugin_guarding_form( $form_id ) ) {
				$reason = 'plugin:' . $this->plugin_guarding_form( $form_id );
			}

			/**
			 * Filters whether the CAPTCHA is skipped for a form on this request.
			 *
			 * @since 4.8.0
			 *
			 * @param bool   $skip
			 * @param string $form_id Form registry id.
			 * @param array  $form    Registry entry.
			 */
			$skip = (bool) apply_filters( 'edumall_captcha_skip', '' !== $reason, $form_id, $form );

			if ( ! $skip ) {
				return '';
			}

			return '' !== $reason ? $reason : 'filter';
		}

		/**
		 * Whether the CAPTCHA is skipped entirely for this form on this
		 * request: whitelisted IP, privileged user, logged-in visitor on a
		 * guest-only form, another plugin already guarding it, or a filter.
		 *
		 * @param string $form_id
		 *
		 * @return bool
		 */
		public function should_skip( $form_id ) {
			return '' !== $this->skip_reason( $form_id );
		}

		/* ------------------------------------------------------------------
		 * Login throttle
		 * ---------------------------------------------------------------- */

		/**
		 * Whether the login challenge applies right now. With a login limit
		 * set and a visible provider, the challenge is only shown / required
		 * once this IP has failed that many times; invisible providers
		 * (honeypot, reCAPTCHA v3) always apply since they cost nothing.
		 *
		 * @return bool
		 */
		public function is_login_challenge_required() {
			$provider = $this->get_provider_object();
			$limit    = $this->get_login_limit();

			if ( ! $provider || $provider->is_invisible() || 0 === $limit ) {
				return true;
			}

			return $this->throttle->get_failures() >= $limit;
		}

		/* ------------------------------------------------------------------
		 * Front-end
		 * ---------------------------------------------------------------- */

		public function frontend_scripts() {
			// The honeypot is pure markup, so no script is needed for it.
			if ( ! $this->is_enabled() || ! $this->provider_needs_keys() || ! $this->get_enabled_forms() ) {
				return;
			}

			$provider = $this->get_provider_object();
			$min      = Edumall_Enqueue::instance()->get_min_suffix();

			wp_enqueue_script(
				'edumall-captcha',
				EDUMALL_THEME_URI . "/assets/js/captcha{$min}.js",
				array(
					'jquery',
				),
				EDUMALL_THEME_VERSION,
				true
			);

			/**
			 * Whether to enqueue the provider script on every page up front,
			 * instead of letting captcha.js load it only once a guarded form
			 * is actually on the page (the default since 4.8.0).
			 *
			 * @since 4.8.0
			 *
			 * @param bool $preload Default false.
			 */
			$preload = (bool) apply_filters( 'edumall_captcha_preload_api', false );

			$api_url = $provider->get_api_url( $this->get_site_key(), $this->get_language() );
			$api_url = add_query_arg( 'onload', 'edumallCaptchaApiLoaded', $api_url );

			wp_localize_script(
				'edumall-captcha',
				'$edumallCaptcha',
				array(
					'provider'       => $provider->get_slug(),
					'adapter'        => $provider->get_js_adapter(),
					'invisible'      => $provider->is_invisible(),
					'siteKey'        => $this->get_site_key(),
					'theme'          => Edumall::is_dark_version() ? 'dark' : 'light',
					'apiUrl'         => $preload ? '' : $api_url,
					'tokenField'     => self::TOKEN_FIELD,
					'renderOptions'  => (object) $provider->get_js_render_options( $this->get_language() ),
					'formActions'    => $this->get_ajax_actions(),
					'loginAction'    => 'edumall_user_login',
					'lazyLoadMarker' => 'lazy_load_template',
				)
			);

			// wp-login.php has none of the theme's styles and its form is 272px
			// wide with overflow hidden, so a 300px widget would be clipped.
			if ( did_action( 'login_init' ) ) {
				wp_add_inline_style( 'login', '.login form .form-group-captcha{margin:0 0 16px}.login form .edumall-captcha{transform:scale(.89);transform-origin:0 0}' );
			}

			if ( $preload ) {
				// The 'edumall-captcha' dependency guarantees the onload callback is defined before the api loads.
				// phpcs:ignore WordPress.WP.EnqueuedResourceParameters -- External CAPTCHA API URL; no local version to cache-bust.
				wp_enqueue_script( 'edumall-captcha-api', $api_url, array( 'edumall-captcha' ), null, true );
			}
		}

		public function async_defer_api_script( $tag, $handle ) {
			if ( 'edumall-captcha-api' !== $handle ) {
				return $tag;
			}

			return str_replace( ' src=', ' async defer src=', $tag );
		}

		/**
		 * Standard widget markup: the container captcha.js renders into and
		 * the theme's own token field next to it.
		 *
		 * @param string $form Form group.
		 */
		public function render_widget_markup( $form ) {
			?>
			<div class="form-group form-group-captcha">
				<div class="edumall-captcha" data-sitekey="<?php echo esc_attr( $this->get_site_key() ); ?>" data-edumall-captcha-form="<?php echo esc_attr( $form ); ?>"></div>
				<?php $this->render_token_input( $form, 'edumall-captcha-token' ); ?>
			</div>
			<?php
		}

		/**
		 * @param string $form      Form group.
		 * @param string $css_class CSS class captcha.js looks for.
		 */
		public function render_token_input( $form, $css_class ) {
			?>
			<input type="hidden" name="<?php echo esc_attr( self::TOKEN_FIELD ); ?>" class="<?php echo esc_attr( $css_class ); ?>" value="" autocomplete="off" data-edumall-captcha-form="<?php echo esc_attr( $form ); ?>">
			<?php
		}

		/**
		 * Print the field for a registry entry (render hook callback).
		 *
		 * @param string $form_id
		 */
		public function render_for_form( $form_id ) {
			$group = $this->get_form_group( $form_id );

			if ( '' === $group || ! $this->is_enabled_for( $group ) || $this->should_skip( $form_id ) ) {
				return;
			}

			// The Tutor login template fires the login_form action and then applies
			// login_form_middle inside the same form; print once, on the action.
			if ( 'wp_login' === $form_id ) {
				$this->login_form_action_rendered = true;
			}

			$this->render_field( $group );
		}

		/**
		 * @var bool Set when the wp_login field was just printed by the action.
		 */
		protected $login_form_action_rendered = false;

		/**
		 * Append the field to filter-rendered forms (wp_login_form()).
		 *
		 * @param string $content Filter content.
		 * @param string $form_id
		 *
		 * @return string
		 */
		public function append_field_to_content( $content, $form_id ) {
			if ( 'wp_login' === $form_id && $this->login_form_action_rendered ) {
				$this->login_form_action_rendered = false;

				return $content;
			}

			ob_start();
			$this->render_for_form( $form_id );
			$this->login_form_action_rendered = false;

			return (string) $content . ob_get_clean();
		}

		/**
		 * @param string $form Form group.
		 */
		public function render_field( $form ) {
			$provider = $this->get_provider_object();

			if ( ! $provider || ! $this->is_enabled_for( $form ) ) {
				return;
			}

			// Login with a failure limit: nothing to show yet, but leave a slot
			// so captcha.js can drop the widget in once the limit is reached
			// (the popup form stays on screen between attempts).
			if ( 'login' === $form && ! $this->is_login_challenge_required() ) {
				?>
				<div class="edumall-captcha-slot" data-edumall-captcha-form="login"></div>
				<?php
				return;
			}

			$provider->render_field( $form, $this );
		}

		public function render_field_register() {
			$this->render_field( 'register' );
		}

		public function render_field_login() {
			$this->render_field( 'login' );
		}

		public function render_field_lost_password() {
			$this->render_field( 'lost_password' );
		}

		/* ------------------------------------------------------------------
		 * Verification entry points
		 * ---------------------------------------------------------------- */

		/**
		 * Gate used directly by handlers that respond via wp_send_json_*():
		 * the theme's popup register and login handlers.
		 *
		 * @param string $form Form group.
		 *
		 * @return bool True when the request may proceed.
		 */
		public function verify_for( $form ) {
			if ( ! $this->is_guarding( $form ) ) {
				return true;
			}

			// The theme's own popups: only the whitelist and the filter can skip.
			$form_id = $this->popup_form_id( $form );

			if ( $this->should_skip( $form_id ) ) {
				return true;
			}

			if ( 'login' === $form && ! $this->is_login_challenge_required() ) {
				return true;
			}

			return $this->verify_group( $form );
		}

		/**
		 * Verify the current submission for a form group: the blank-key rule,
		 * then the provider round-trip, with the Login leniency on top.
		 *
		 * @param string $group
		 *
		 * @return bool
		 */
		protected function verify_group( $group ) {
			// Selected provider missing its keys: reject, never wave through -
			// except on Login, where locking the administrators out is worse
			// than a temporarily unguarded login form (see login_leniency_applies()).
			if ( $this->is_misconfigured() ) {
				if ( 'login' === $group && $this->login_leniency_applies() ) {
					$this->record_rejection( 'misconfigured_login_allowed' );

					return true;
				}

				$this->record_rejection( 'misconfigured' );

				return false;
			}

			// We already know this key pair cannot work - the provider said so
			// when an administrator saved it, or the provider was switched and
			// the keys were left behind. No visitor can solve a challenge that
			// cannot be verified, so on Login let them in rather than lock the
			// site out; this also covers a Site Key whose widget never renders,
			// where no token would ever arrive.
			if ( 'login' === $group && $this->login_leniency_applies() && ( $this->keys_rejected_by_provider() || $this->keys_are_stale() ) ) {
				$this->record_rejection( 'misconfigured_login_allowed' );

				return true;
			}

			$this->verifying_group = $group;
			$valid                 = $this->verify_token();
			$this->verifying_group = '';

			return $valid;
		}

		/**
		 * @param string $group Form group.
		 *
		 * @return string Registry id of the theme's own popup form for that group.
		 */
		protected function popup_form_id( $group ) {
			foreach ( $this->get_forms() as $form_id => $form ) {
				if ( empty( $form['native'] ) && isset( $form['group'] ) && $group === $form['group'] ) {
					return $form_id;
				}
			}

			return 'popup_' . $group;
		}

		/**
		 * Whether the theme login popup must carry a token on its next attempt:
		 * the Login form is guarded, this visitor is not skipped (whitelist,
		 * filter) and, with a login limit, the limit has been reached. The
		 * popup handler sends this back so captcha.js can drop the widget in.
		 *
		 * @return bool
		 */
		public function popup_login_needs_challenge() {
			return $this->is_guarding( 'login' ) && ! $this->should_skip( $this->popup_form_id( 'login' ) ) && $this->is_login_challenge_required();
		}

		/**
		 * Whether a form's group is guarded and this request must carry a
		 * valid token; false when the form is off, skipped or below the login
		 * limit. Shared prologue of the hook callbacks below.
		 *
		 * @param string $form_id
		 *
		 * @return bool
		 */
		protected function must_verify( $form_id ) {
			$group = $this->get_form_group( $form_id );

			if ( '' === $group || ! $this->is_guarding( $group ) || $this->should_skip( $form_id ) ) {
				return false;
			}

			if ( 'login' === $group && ! $this->is_login_challenge_required() ) {
				return false;
			}

			return true;
		}

		/**
		 * Whether the submission carries a field this theme rendered: the
		 * namespaced token, or the honeypot trap.
		 *
		 * @return bool
		 */
		protected function own_field_present() {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- presence check only; the value is verified below.
			if ( isset( $_POST[ Edumall_Captcha_Provider_Honeypot::FIELD ] ) ) {
				return true;
			}

			return '' !== $this->get_submitted_token();
		}

		/**
		 * Whether this form is guarded but handed to Tutor Pro's Fraud
		 * Protection on this request.
		 *
		 * @param string $form_id
		 *
		 * @return bool
		 */
		protected function is_deferred_to_tutor_pro( $form_id ) {
			$group = $this->get_form_group( $form_id );

			return '' !== $group && $this->is_guarding( $group ) && 'plugin:tutor_pro' === $this->skip_reason( $form_id );
		}

		/**
		 * @param string $form_id
		 *
		 * @return bool Whether the submission passes.
		 */
		protected function passes( $form_id ) {
			if ( ! $this->must_verify( $form_id ) ) {
				// Deferred to Tutor Pro: it verifies its own token, but only when
				// the field is there, so the theme still insists that it is.
				if ( $this->is_deferred_to_tutor_pro( $form_id ) && ! $this->compat->tutor_pro_token_present() ) {
					// Tutor Pro renders into its own forms only. When the form
					// that was actually served carries the theme's field instead
					// (a login widget posting to wp-login.php, a cached page from
					// before the settings changed), verify that rather than
					// turning a real visitor away.
					if ( $this->own_field_present() ) {
						return $this->verify_group( $this->get_form_group( $form_id ) );
					}

					$this->record_rejection( 'tutor_pro_missing' );

					return false;
				}

				return true;
			}

			return $this->verify_group( $this->get_form_group( $form_id ) );
		}

		/**
		 * Short-circuit filters of the theme's AJAX handlers, whose JS reads a
		 * flat {success, messages} JSON.
		 *
		 * @param null|array $result
		 * @param string     $form_id
		 *
		 * @return null|array Null to continue, array to abort.
		 */
		public function verify_short_circuit( $result, $form_id ) {
			if ( null !== $result || '' === $form_id ) {
				return $result;
			}

			if ( ! $this->passes( $form_id ) ) {
				return array(
					'success'  => false,
					'messages' => $this->get_failed_message(),
				);
			}

			return $result;
		}

		/**
		 * WP_Error-collecting filters and actions (registration_errors,
		 * woocommerce_process_*_errors, tutor_process_login_errors,
		 * lostpassword_post).
		 *
		 * @param WP_Error|mixed $errors
		 * @param string         $form_id
		 *
		 * @return WP_Error|mixed
		 */
		public function verify_wp_error( $errors, $form_id ) {
			if ( '' === $form_id ) {
				return $errors;
			}

			if ( ! $this->must_verify( $form_id ) && ! $this->is_deferred_to_tutor_pro( $form_id ) ) {
				return $errors;
			}

			if ( ! is_wp_error( $errors ) ) {
				$errors = new WP_Error();
			}

			if ( ! $this->passes( $form_id ) ) {
				/*
				 * Core has usually reached its own verdict by now - this username
				 * is taken, there is no account with that address - and wp-login.php
				 * prints every message it is handed. A request that has not shown
				 * it is human is owed none of that, so the CAPTCHA answer replaces
				 * those verdicts instead of joining them.
				 */
				foreach ( $errors->get_error_codes() as $code ) {
					$errors->remove( $code );
				}

				$errors->add( 'edumall_captcha', $this->get_failed_message() );
			}

			return $errors;
		}

		/**
		 * The 'authenticate' filter for the wp-login.php login form.
		 *
		 * @param WP_User|WP_Error|null $user
		 * @param string                $form_id
		 *
		 * @return WP_User|WP_Error|null
		 */
		public function verify_authenticate( $user, $form_id ) {
			if ( '' === $form_id ) {
				return $user;
			}

			/*
			 * Another step's answer - a wrong password, a plugin's lockout, a
			 * two-factor challenge - is left exactly as it is. The account core
			 * could not find is the one exception: wp_authenticate_username_password()
			 * answers that at priority 20 without ever firing wp_authenticate_user,
			 * so this filter is the only place an unverified request can be
			 * stopped before it is told which usernames exist.
			 */
			if ( is_wp_error( $user ) && ! $this->is_unknown_account_error( $user ) ) {
				return $user;
			}

			/*
			 * No exemption for XML-RPC or REST. A genuine API authentication
			 * resolves no form - neither origin callable can match one, and the
			 * fallback path excludes both - so it already returned above. What
			 * an exemption here would cover is the opposite: a request that
			 * reached a guarded form through one of those endpoints on purpose.
			 */
			if ( ! $this->passes( $form_id ) ) {
				return new WP_Error( 'edumall_captcha', $this->get_failed_message() );
			}

			return $user;
		}

		/**
		 * Whether a WP_Error is core's answer for an account it could not find,
		 * the only verdict verify_authenticate() is allowed to replace.
		 *
		 * @param WP_Error $error
		 *
		 * @return bool
		 */
		protected function is_unknown_account_error( $error ) {
			return (bool) array_intersect( array( 'invalid_username', 'invalid_email' ), $error->get_error_codes() );
		}

		/**
		 * Actions with no error channel (pre_comment_on_post): stop the request.
		 *
		 * @param string $form_id
		 */
		public function verify_or_die( $form_id ) {
			if ( '' === $form_id || $this->passes( $form_id ) ) {
				return;
			}

			wp_die(
				esc_html( $this->get_failed_message() ),
				esc_html__( 'Comment Submission Failure', 'edumall' ),
				array(
					'response'  => 403,
					'back_link' => true,
				)
			);
		}

		/* Back-compat wrappers kept for child themes hooking them directly. */

		public function pre_register_verify( $result ) {
			return $this->verify_short_circuit( $result, 'elementor_register' );
		}

		public function pre_lost_password_verify( $result ) {
			return $this->verify_short_circuit( $result, 'popup_lost_password' );
		}

		public function verify_registration_errors( $errors ) {
			return $this->verify_wp_error( $errors, 'wp_register' );
		}

		public function verify_woocommerce_register( $errors ) {
			return $this->verify_wp_error( $errors, 'wc_register' );
		}

		/* ------------------------------------------------------------------
		 * Token verification
		 * ---------------------------------------------------------------- */

		/**
		 * The submitted token: the theme's own field first, then the field the
		 * provider writes itself. reCAPTCHA and hCaptcha inject a textarea of
		 * their own next to the widget, which the front-end script un-names so
		 * only one token is posted; reading it as a fallback keeps the form
		 * working if that script did not get the chance. Never read while
		 * another CAPTCHA plugin is active - the token in it would be theirs.
		 *
		 * @return string
		 */
		public function get_submitted_token() {
			$provider = $this->get_provider_object();
			$fields   = array( self::TOKEN_FIELD );

			if ( $provider && ! $this->compat->is_any_plugin_active() ) {
				$fields = array_merge( $fields, $provider->get_legacy_token_fields() );
			}

			foreach ( $fields as $field ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- the form handler verifies its nonce before this runs.
				if ( isset( $_POST[ $field ] ) && is_string( $_POST[ $field ] ) && '' !== $_POST[ $field ] ) {
					// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
					$token = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );

					// No provider issues tokens anywhere near this long; an oversized
					// value is not worth a round-trip and is rejected outright.
					return strlen( $token ) > self::MAX_TOKEN_LENGTH ? '' : $token;
				}
			}

			return '';
		}

		/**
		 * Ask the provider to verify the submission. Memoized per request:
		 * tokens are single use, so a second provider round-trip would fail.
		 *
		 * @return bool
		 */
		public function verify_token() {
			if ( null !== $this->verify_result ) {
				return $this->verify_result;
			}

			$provider = $this->get_provider_object();

			if ( ! $provider ) {
				$this->verify_result = true;

				return true;
			}

			$slug = $provider->get_slug();

			// Failsafe breaker: a recent outage with the failsafe set to allow
			// lets submissions through without waiting on the provider again.
			if ( $provider->needs_keys() && 'allow' === $this->get_failsafe_mode() && get_transient( self::BREAKER_TRANSIENT ) ) {
				$this->last_result   = array(
					'reason' => 'failsafe',
					'codes'  => array(),
				);
				$this->verify_result = (bool) apply_filters( 'edumall_captcha_is_valid', true, $slug );

				return $this->verify_result;
			}

			$result = $provider->verify( $this->get_submitted_token(), $this );
			$result = wp_parse_args(
				(array) $result,
				array(
					'valid'           => false,
					'reason'          => '',
					'codes'           => array(),
					'transport_error' => false,
				)
			);

			$is_valid = (bool) $result['valid'];

			if ( ! $is_valid && $result['transport_error'] ) {
				$this->remember_error( $slug, 'unreachable', $result['codes'] );

				if ( 'allow' === $this->get_failsafe_mode() ) {
					set_transient( self::BREAKER_TRANSIENT, time(), self::BREAKER_TTL );
					$is_valid         = true;
					$result['reason'] = 'failsafe';
				}
			} elseif ( ! $is_valid && $this->is_misconfiguration_code( $result['codes'] ) ) {
				$this->remember_error( $slug, 'misconfigured', $result['codes'] );

				/*
				 * The provider says our Secret Key is wrong: nothing a visitor
				 * sent can produce that verdict, and on Login it would lock
				 * everyone out. Deliberately narrower than the codes that feed
				 * the admin notice: hCaptcha answers sitekey-secret-mismatch for
				 * a token minted under someone else's Site Key, so a bot could
				 * otherwise buy such a token and be waved through.
				 */
				if ( 'login' === $this->verifying_group && $this->login_leniency_applies() && $this->is_secret_misconfiguration_code( $result['codes'] ) ) {
					$is_valid         = true;
					$result['reason'] = 'misconfigured_login_allowed';
				}
			}

			if ( ! $is_valid ) {
				$this->record_rejection( (string) $result['reason'] );
			}

			$this->last_result = $result;

			/**
			 * Filters the CAPTCHA verification result.
			 *
			 * @since 4.8.0
			 *
			 * @param bool   $is_valid Whether the token passed the provider verification.
			 * @param string $provider Active CAPTCHA provider slug.
			 */
			$this->verify_result = (bool) apply_filters( 'edumall_captcha_is_valid', $is_valid, $slug );

			return $this->verify_result;
		}

		/**
		 * @return array Reason and codes of the last verification.
		 */
		public function get_last_result() {
			return $this->last_result;
		}

		/**
		 * Codes that can only come from this site's own Secret Key being wrong,
		 * never from anything the visitor submitted. Used for the Login
		 * leniency, which must not be reachable by a crafted token.
		 *
		 * @param string[] $codes
		 *
		 * @return bool
		 */
		protected function is_secret_misconfiguration_code( $codes ) {
			$secret = array( 'invalid-input-secret', 'missing-input-secret', 'key-format' );

			return (bool) array_intersect( array_map( 'strval', (array) $codes ), $secret );
		}

		/**
		 * @param string[] $codes
		 *
		 * @return bool Whether the provider reported a key problem.
		 */
		protected function is_misconfiguration_code( $codes ) {
			$misconfig = array( 'invalid-input-secret', 'missing-input-secret', 'sitekey-secret-mismatch', 'invalid-sitekey', 'key-format' );

			return (bool) array_intersect( array_map( 'strval', (array) $codes ), $misconfig );
		}

		/**
		 * @param string   $provider
		 * @param string   $kind     'unreachable' or 'misconfigured'.
		 * @param string[] $codes
		 */
		protected function remember_error( $provider, $kind, $codes ) {
			set_transient(
				self::LAST_ERROR_TRANSIENT,
				array(
					'provider' => $provider,
					'kind'     => $kind,
					'codes'    => array_slice( array_map( 'strval', (array) $codes ), 0, 3 ),
					'time'     => time(),
				),
				DAY_IN_SECONDS
			);
		}

		/**
		 * Confirm the provider says the challenge was solved on one of this
		 * site's own hosts, not replayed from a copy of the public Site Key
		 * hosted elsewhere. The allow-list defaults to the home URL host (www
		 * and apex treated as equal) and is filterable, so a Site Key
		 * registered for several domains, a staging clone or a reverse-proxied
		 * secondary domain can be permitted without turning the check off. An
		 * empty or unreported host never matches; the boolean filter is the
		 * final escape hatch.
		 *
		 * @param string $hostname Host reported by the provider.
		 * @param string $provider Active provider slug.
		 *
		 * @return bool
		 */
		public function hostname_matches( $hostname, $provider ) {
			$actual = $this->normalize_host( $hostname );

			/**
			 * Hosts accepted as this site's own for a CAPTCHA solution.
			 *
			 * @since 4.8.0
			 *
			 * @param string[] $hosts    Allowed hosts.
			 * @param string   $provider Active provider slug.
			 */
			$hosts  = array( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
			$object = $this->get_provider_object();

			/*
			 * The providers' documented testing keys answer with a placeholder
			 * host, so accept it while those keys are configured - otherwise
			 * trying a provider out without an account looks like a failure.
			 * It weakens nothing: a testing key accepts every visitor anyway.
			 */
			if ( $object && $object->get_slug() === $provider ) {
				$testing = $object->get_testing_hostname( $this->get_secret_key() );

				if ( '' !== $testing ) {
					$hosts[] = $testing;
				}
			}

			$allowed = apply_filters( 'edumall_captcha_allowed_hostnames', $hosts, $provider );

			$allowed = array_filter( array_map( array( $this, 'normalize_host' ), (array) $allowed ), 'strlen' );

			// A filter that forgot to return the list (or emptied it) must not
			// silently reject every solve; fall back to this site's own host.
			if ( empty( $allowed ) ) {
				$allowed = array( $this->normalize_host( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
			}

			$matches = '' !== $actual && in_array( $actual, $allowed, true );

			/**
			 * Final override of whether the CAPTCHA solution's host is accepted.
			 *
			 * @since 4.8.0
			 *
			 * @param bool   $matches  Whether the reported host was on the allow-list.
			 * @param string $hostname Host reported by the provider.
			 * @param string $provider Active provider slug.
			 */
			return (bool) apply_filters( 'edumall_captcha_hostname_valid', $matches, $hostname, $provider );
		}

		/**
		 * Lower-case a host and drop a leading "www." for a lenient comparison.
		 *
		 * @param string $host
		 *
		 * @return string
		 */
		public function normalize_host( $host ) {
			$host = strtolower( trim( (string) $host ) );

			if ( 0 === strpos( $host, 'www.' ) ) {
				$host = substr( $host, 4 );
			}

			return $host;
		}

		public function get_failed_message() {
			$provider = $this->get_provider_object();

			if ( $provider && ! $provider->needs_keys() ) {
				return esc_html__( 'Your submission was blocked because it looked automated. Please try again, or contact us if the problem persists.', 'edumall' );
			}

			return esc_html__( 'CAPTCHA verification failed. Please confirm you are not a robot and try again.', 'edumall' );
		}

		/* ------------------------------------------------------------------
		 * Honeypot grace window and rejection log
		 * ---------------------------------------------------------------- */

		/**
		 * Start the grace window from a non-AJAX admin page load. This is only
		 * one of the anchors; the trap's first front-end render stamps it too
		 * (see stamp_honeypot_start_once()), so the clock still starts on a
		 * site that is only ever administered over WP-CLI.
		 */
		public function maybe_stamp_honeypot_start() {
			if ( wp_doing_ajax() || ! current_user_can( 'edit_theme_options' ) ) {
				return;
			}

			$this->stamp_honeypot_start_once();
		}

		/**
		 * Restart the grace window when the CAPTCHA provider is switched (back)
		 * to Honeypot. Hooked to the theme-mods save so the transition is
		 * caught at the moment it is persisted, with the real old and new
		 * values, by a request already capability-checked - not inferred later
		 * from an unauthenticated page load. The stamp is write-once, so
		 * without this a site returning to Honeypot after running a key
		 * provider would inherit the old, long-expired stamp and give
		 * cache-served trap-less forms no grace at all; deleting it lets the
		 * next render/verify re-anchor to now.
		 *
		 * @param mixed $old_value Theme mods before the update.
		 * @param mixed $new_value Theme mods after the update.
		 */
		public function on_theme_mods_updated( $old_value, $new_value ) {
			if ( 'honeypot' === $this->provider_from_mods( $new_value )
				&& 'honeypot' !== $this->provider_from_mods( $old_value ) ) {
				delete_option( self::HONEYPOT_SINCE_OPTION );
			}

			// Keys or provider changed: ask the provider about the Secret Key, so
			// a typo is reported before it locks anyone out. The Customizer saves
			// one theme mod at a time, so the probe waits for the end of the
			// request rather than running on each half-updated pair.
			$keys = array( 'captcha_provider' );

			foreach ( $this->get_providers() as $slug => $provider ) {
				if ( $provider->needs_keys() ) {
					$keys[] = $this->get_key_setting( 'site', $slug );
					$keys[] = $this->get_key_setting( 'secret', $slug );
				}
			}

			foreach ( $keys as $key ) {
				$old = is_array( $old_value ) && isset( $old_value[ $key ] ) ? $old_value[ $key ] : null;
				$new = is_array( $new_value ) && isset( $new_value[ $key ] ) ? $new_value[ $key ] : null;

				if ( $old !== $new ) {
					$this->schedule_key_probe();
					break;
				}
			}

			$this->flag_stale_keys( $old_value, $new_value );
		}

		/**
		 * Every provider keeps its own Site Key and Secret Key, but nothing
		 * stops the same pair being pasted under two of them - and a reCAPTCHA
		 * v2 pair does not work under v3, nor either under Turnstile or
		 * hCaptcha. The shape check cannot see it (a v2 key and a v3 key are
		 * indistinguishable), so catch the case that matters: the provider now
		 * selected holds the Site Key of another one.
		 *
		 * @param mixed $old_value Theme mods before the update.
		 * @param mixed $new_value Theme mods after the update.
		 */
		protected function flag_stale_keys( $old_value, $new_value ) {
			$mod = function ( $mods, $key ) {
				return is_array( $mods ) && isset( $mods[ $key ] ) ? trim( (string) $mods[ $key ] ) : '';
			};

			$old_provider = $mod( $old_value, 'captcha_provider' );
			$new_provider = $mod( $new_value, 'captcha_provider' );
			$providers    = $this->get_providers();

			$needs_keys = function ( $slug ) use ( $providers ) {
				return isset( $providers[ $slug ] ) && $providers[ $slug ]->needs_keys();
			};

			/*
			 * Re-evaluated on every save, not only when the provider changes: the
			 * Customizer writes one setting at a time, so the save that fixes the
			 * keys is a save where the provider stayed put - and that is exactly
			 * when the warning has to go away again.
			 */
			$site = $needs_keys( $new_provider ) ? $mod( $new_value, $this->get_key_setting( 'site', $new_provider ) ) : '';

			if ( '' !== $site ) {
				$candidates = array_keys( $providers );

				// Name the provider just switched away from when it is the match.
				if ( '' !== $old_provider && $old_provider !== $new_provider ) {
					array_unshift( $candidates, $old_provider );
				}

				foreach ( $candidates as $slug ) {
					if ( $slug === $new_provider || ! $needs_keys( $slug ) ) {
						continue;
					}

					// The same Site Key configured under two services: nothing else
					// can tell, since a reCAPTCHA v2 key and a v3 key are the same shape.
					if ( $site === $mod( $new_value, $this->get_key_setting( 'site', $slug ) ) ) {
						set_transient(
							self::KEYS_STALE_TRANSIENT,
							array(
								'from' => $slug,
								'to'   => $new_provider,
							),
							WEEK_IN_SECONDS
						);

						return;
					}
				}
			}

			delete_transient( self::KEYS_STALE_TRANSIENT );
		}

		/**
		 * Probe once, at the end of this request.
		 */
		public function schedule_key_probe() {
			if ( $this->probe_scheduled ) {
				return;
			}

			$this->probe_scheduled = true;

			add_action( 'shutdown', array( $this, 'run_scheduled_key_probe' ), 0 );
		}

		public function run_scheduled_key_probe() {
			$this->probe_keys( true );
		}

		/**
		 * @return string Fingerprint of the active provider + keys.
		 */
		protected function key_fingerprint() {
			return md5( $this->get_provider() . '|' . $this->get_site_key() . '|' . $this->get_secret_key() );
		}

		/**
		 * Probe the keys once per admin session when they were never checked
		 * (keys set as constants, imported settings), so the notice below can
		 * report a wrong Secret Key even if no visitor has hit a form yet.
		 */
		public function maybe_probe_keys() {
			if ( wp_doing_ajax() || ! current_user_can( 'edit_theme_options' ) || ! $this->provider_needs_keys() || $this->is_misconfigured() ) {
				return;
			}

			$probe = get_transient( self::KEY_PROBE_TRANSIENT );

			if ( is_array( $probe ) && isset( $probe['fingerprint'] ) && $probe['fingerprint'] === $this->key_fingerprint() ) {
				return;
			}

			$this->schedule_key_probe();
		}

		/**
		 * Ask the provider whether the Secret Key is accepted, using a dummy
		 * token: a wrong secret comes back as invalid-input-secret (or the
		 * hCaptcha sitekey-secret-mismatch), a right one merely rejects the
		 * token. The verdict is stored for the admin notice and, when the keys
		 * are wrong, remembered like a live failure so the Login leniency
		 * (see verify_token()) applies at once.
		 *
		 * @param bool $force Probe even if this fingerprint was probed already.
		 *
		 * @return string 'ok', 'misconfigured', 'unreachable' or '' (nothing to probe).
		 */
		public function probe_keys( $force = false ) {
			$provider = $this->get_provider_object();

			if ( ! $provider || ! $provider->needs_keys() || $this->is_misconfigured() ) {
				delete_transient( self::KEY_PROBE_TRANSIENT );

				return '';
			}

			$fingerprint = $this->key_fingerprint();
			$probe       = get_transient( self::KEY_PROBE_TRANSIENT );

			if ( ! $force && is_array( $probe ) && isset( $probe['fingerprint'] ) && $probe['fingerprint'] === $fingerprint ) {
				return (string) $probe['verdict'];
			}

			// Shape first: Google and hCaptcha only judge the secret once a real
			// token arrives, so a wrong pair is caught by its shape where it can be.
			$patterns = wp_parse_args(
				(array) $provider->get_key_patterns(),
				array(
					'site'   => '',
					'secret' => '',
				)
			);

			$bad_shape = ( '' !== $patterns['site'] && ! preg_match( $patterns['site'], $this->get_site_key() ) )
				|| ( '' !== $patterns['secret'] && ! preg_match( $patterns['secret'], $this->get_secret_key() ) );

			$result = $bad_shape ? array( 'codes' => array( 'key-format' ) ) : $provider->verify( 'edumall-key-probe', $this );
			$result = wp_parse_args(
				(array) $result,
				array(
					'valid'           => false,
					'codes'           => array(),
					'transport_error' => false,
				)
			);

			if ( $result['transport_error'] ) {
				// Reported through the probe verdict only: no visitor was turned
				// away, so this must not surface as a rejection notice.
				$verdict = 'unreachable';
			} elseif ( $this->is_misconfiguration_code( $result['codes'] ) ) {
				$verdict = 'misconfigured';
				$this->remember_error( $provider->get_slug(), 'misconfigured', $result['codes'] );
			} else {
				$verdict = 'ok';
				// Keys accepted: an older "wrong keys" notice no longer applies.
				$last = get_transient( self::LAST_ERROR_TRANSIENT );

				if ( is_array( $last ) && isset( $last['kind'] ) && 'misconfigured' === $last['kind'] ) {
					delete_transient( self::LAST_ERROR_TRANSIENT );
				}
			}

			set_transient(
				self::KEY_PROBE_TRANSIENT,
				array(
					'fingerprint' => $fingerprint,
					'verdict'     => $verdict,
					'codes'       => array_slice( array_map( 'strval', (array) $result['codes'] ), 0, 3 ),
					'time'        => time(),
				),
				12 * HOUR_IN_SECONDS
			);

			return $verdict;
		}

		/**
		 * Whether the provider has told us (on a probe or a live check) that
		 * the configured keys are wrong.
		 *
		 * @return bool
		 */
		public function keys_rejected_by_provider() {
			$probe = get_transient( self::KEY_PROBE_TRANSIENT );

			// Only the probe's verdict counts here: it is triggered by an
			// administrator saving the keys, never by a visitor's submission,
			// and it is tied to the exact key pair in use.
			return is_array( $probe )
				&& isset( $probe['verdict'], $probe['fingerprint'] )
				&& 'misconfigured' === $probe['verdict']
				&& $probe['fingerprint'] === $this->key_fingerprint();
		}

		/**
		 * Whether the keys were left behind by a provider switch (flagged from
		 * a capability-checked Customizer save, so a visitor cannot provoke it).
		 *
		 * @return bool
		 */
		public function keys_are_stale() {
			$stale = get_transient( self::KEYS_STALE_TRANSIENT );

			return is_array( $stale ) && isset( $stale['to'] ) && $stale['to'] === $this->get_provider();
		}

		/**
		 * The Login forms are the one place a fail-closed misconfiguration
		 * would lock the administrators out of their own site, with no way
		 * back in short of editing wp-config.php. So when the failure is the
		 * configuration itself - a blank key, or the provider reporting the
		 * keys as wrong (a verdict no visitor can forge) - the Login forms
		 * are let through and the problem is shouted about in wp-admin
		 * instead. Every other group keeps failing closed.
		 *
		 * @return bool
		 */
		public function login_leniency_applies() {
			/**
			 * Filters whether the Login forms are let through while the CAPTCHA
			 * keys are missing or rejected by the provider (default true, so
			 * administrators are never locked out by a typo).
			 *
			 * @since 4.8.0
			 *
			 * @param bool $lenient
			 */
			return (bool) apply_filters( 'edumall_captcha_login_leniency', true );
		}

		/**
		 * Resolve the CAPTCHA provider from a theme-mods array. An absent key
		 * means the Customizer default, which is Honeypot (see section-captcha.php).
		 *
		 * @param mixed $mods Theme mods array.
		 *
		 * @return string
		 */
		protected function provider_from_mods( $mods ) {
			if ( is_array( $mods ) && isset( $mods['captcha_provider'] ) ) {
				return (string) $mods['captcha_provider'];
			}

			return 'honeypot';
		}

		/**
		 * Stamp the grace-window start once, anchored to the first moment the
		 * honeypot becomes visible on the site - whether that is an admin page
		 * load or the first front-end render of the trap. Without the front-end
		 * anchor a site whose owner never opens wp-admin would stay unstamped,
		 * and honeypot_grace_active() would forgive every trap-less POST forever.
		 *
		 * Starting the clock from a public request is safe: the option is
		 * write-once and time only moves forward, so the earliest caller merely
		 * bounds the window - it cannot be reset or extended by a later request.
		 */
		public function stamp_honeypot_start_once() {
			if ( 'honeypot' !== $this->get_provider() || get_option( self::HONEYPOT_SINCE_OPTION ) ) {
				return;
			}

			update_option( self::HONEYPOT_SINCE_OPTION, time(), false );
		}

		/**
		 * Whether the trap is still inside its post-rollout grace window.
		 * Read-only: this only reads the stamp; the clock is started elsewhere
		 * (an admin page load, the first render, or the first verification).
		 *
		 * @return bool
		 */
		public function honeypot_grace_active() {
			$since = (int) get_option( self::HONEYPOT_SINCE_OPTION, 0 );

			/*
			 * Not stamped yet means nothing has rendered the trap and no admin
			 * page has loaded since it went live, so there is no way to know
			 * whether caches have turned over. Stay permissive rather than risk
			 * turning real sign-ups away; the next form render or admin page
			 * load starts the clock.
			 */
			if ( ! $since ) {
				return true;
			}

			return ( time() - $since ) < self::HONEYPOT_GRACE;
		}

		/**
		 * Count a rejection by reason so the ways this feature can turn a real
		 * visitor away stay visible. Capped, so a flood cannot turn every
		 * rejected request into a database write.
		 *
		 * @param string $reason
		 */
		public function record_rejection( $reason ) {
			$reason = sanitize_key( $reason );

			if ( '' === $reason ) {
				$reason = 'unknown';
			}

			$counts = get_transient( self::HONEYPOT_REJECTS_TRANSIENT );

			if ( ! is_array( $counts ) ) {
				$counts = array();
			}

			$count = isset( $counts[ $reason ] ) ? (int) $counts[ $reason ] : 0;

			if ( $count >= 100 ) {
				return;
			}

			$counts[ $reason ] = $count + 1;

			set_transient( self::HONEYPOT_REJECTS_TRANSIENT, $counts, WEEK_IN_SECONDS );
		}

		/* ------------------------------------------------------------------
		 * Admin notices
		 * ---------------------------------------------------------------- */

		/**
		 * Warn administrators when a provider is selected but a key is
		 * missing, because the guarded forms then reject every submission
		 * (fail closed) until both keys are added.
		 */
		public function admin_notice_missing_keys() {
			if ( ! current_user_can( 'edit_theme_options' ) ) {
				return;
			}

			if ( ! $this->provider_needs_keys() || $this->is_enabled() ) {
				return;
			}
			?>
			<div class="notice notice-warning">
				<p>
					<strong><?php esc_html_e( 'Edumall CAPTCHA is misconfigured:', 'edumall' ); ?></strong>
					<?php
					printf(
						wp_kses(
							/* translators: %s: Customizer CAPTCHA section URL. */
							__( 'a CAPTCHA provider is selected but the Site Key or Secret Key is missing. No challenge can be shown, so the guarded forms reject every submission until this is fixed. Please add both keys in <a href="%s">Customize &rarr; CAPTCHA</a>, or set the provider to Honeypot or Disabled.', 'edumall' ),
							array(
								'a' => array(
									'href' => array(),
								),
							)
						),
						esc_url( admin_url( 'customize.php?autofocus[section]=captcha' ) )
					);

					if ( $this->is_guarding( 'login' ) && $this->login_leniency_applies() ) {
						echo ' ';
						esc_html_e( 'The Login forms are the exception: they are let through unverified while the keys are missing, so nobody is locked out.', 'edumall' );
					}
					?>
				</p>
			</div>
			<?php
		}

		/**
		 * Say so when the same Site Key is configured under two providers -
		 * usually the previous service's key pasted into the new one's field.
		 * The challenge then cannot render or verify, and nothing else can
		 * tell (a reCAPTCHA v2 key and a v3 key are the same shape).
		 */
		public function admin_notice_keys_not_updated() {
			if ( ! current_user_can( 'edit_theme_options' ) || ! $this->provider_needs_keys() ) {
				return;
			}

			$stale = get_transient( self::KEYS_STALE_TRANSIENT );

			if ( ! is_array( $stale ) || empty( $stale['to'] ) || $stale['to'] !== $this->get_provider() ) {
				return;
			}

			$providers = $this->get_providers();
			$label     = function ( $slug ) use ( $providers ) {
				return isset( $providers[ $slug ] ) ? $providers[ $slug ]->get_label() : $slug;
			};
			?>
			<div class="notice notice-warning">
				<p>
					<strong><?php esc_html_e( 'Edumall CAPTCHA:', 'edumall' ); ?></strong>
					<?php
					printf(
						/* translators: 1: previous provider name, 2: new provider name, 3: Customizer CAPTCHA section URL. */
						wp_kses( __( 'the provider was changed from %1$s to %2$s, but %2$s is configured with the same Site Key as %1$s. Every service issues its own key pair - a reCAPTCHA v2 pair does not work under v3, and neither works under Turnstile or hCaptcha - so please create keys for %2$s and paste them in <a href="%3$s">Customize &rarr; CAPTCHA</a>. Until then the challenge cannot be solved.', 'edumall' ), array( 'a' => array( 'href' => array() ) ) ),
						esc_html( $label( $stale['from'] ) ),
						esc_html( $label( $stale['to'] ) ),
						esc_url( admin_url( 'customize.php?autofocus[section]=captcha' ) )
					);

					if ( $this->is_guarding( 'login' ) && $this->login_leniency_applies() ) {
						echo ' ';
						esc_html_e( 'The Login forms are the exception: they are let through unverified while the keys do not work, so nobody is locked out.', 'edumall' );
					}
					?>
				</p>
			</div>
			<?php
		}

		/**
		 * Report honeypot rejections to administrators. Both causes are
		 * stated plainly: most are bots, which needs no action, but the same
		 * counters are the only way a genuine lockout ever becomes visible.
		 */
		public function admin_notice_missing_trap() {
			if ( ! current_user_can( 'edit_theme_options' ) || 'honeypot' !== $this->get_provider() ) {
				return;
			}

			$counts  = get_transient( self::HONEYPOT_REJECTS_TRANSIENT );
			$counts  = is_array( $counts ) ? $counts : array();
			$missing = isset( $counts['missing'] ) ? (int) $counts['missing'] : 0;
			$filled  = isset( $counts['filled'] ) ? (int) $counts['filled'] : 0;

			if ( $missing < 3 && $filled < 3 ) {
				return;
			}
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
					<strong><?php esc_html_e( 'Edumall spam protection:', 'edumall' ); ?></strong>
					<?php
					printf(
						/* translators: 1: number of submissions rejected for a missing field, 2: number rejected for a filled field. */
						esc_html__( 'in the last 7 days %1$d submissions were rejected because the anti-spam field was missing, and %2$d because it had been filled in.', 'edumall' ),
						absint( $missing ),
						absint( $filled )
					);
					?>
					<?php esc_html_e( 'Automated submissions look exactly like this, so as a rule no action is needed. Act only if real visitors report that they cannot register: a missing field then means they are being served an outdated or customised copy of the form, so clear your page cache and check any child-theme copy of the registration templates; a filled field means a browser extension is writing into the hidden field, and those visitors need to disable it or you need to switch to one of the CAPTCHA services.', 'edumall' ); ?>
				</p>
			</div>
			<?php
		}

		/**
		 * Surface a provider-side problem: the verification endpoint could not
		 * be reached, or it reported that the keys are wrong.
		 */
		public function admin_notice_provider_error() {
			if ( ! current_user_can( 'edit_theme_options' ) || ! $this->provider_needs_keys() ) {
				return;
			}

			$error = get_transient( self::LAST_ERROR_TRANSIENT );

			if ( ! is_array( $error ) || empty( $error['kind'] ) || ( isset( $error['provider'] ) && $error['provider'] !== $this->get_provider() ) ) {
				$this->admin_notice_probe_unreachable();

				return;
			}

			$when  = isset( $error['time'] ) ? human_time_diff( (int) $error['time'] ) : '';
			$codes = ! empty( $error['codes'] ) ? implode( ', ', array_map( 'sanitize_text_field', (array) $error['codes'] ) ) : '';
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
					<strong><?php esc_html_e( 'Edumall CAPTCHA:', 'edumall' ); ?></strong>
					<?php if ( 'misconfigured' === $error['kind'] && in_array( 'key-format', (array) $error['codes'], true ) ) : ?>
						<?php
						printf(
							/* translators: 1: provider name, 2: Customizer CAPTCHA section URL. */
							wp_kses( __( 'the Site Key or Secret Key does not look like a %1$s key pair - for example keys created for a different provider, or a key that was cut off when it was pasted. Please check both keys in <a href="%2$s">Customize &rarr; CAPTCHA</a>. Until then the guarded forms cannot verify anyone.', 'edumall' ), array( 'a' => array( 'href' => array() ) ) ),
							esc_html( $this->get_provider_object() ? $this->get_provider_object()->get_label() : $this->get_provider() ),
							esc_url( admin_url( 'customize.php?autofocus[section]=captcha' ) )
						);

						if ( $this->is_guarding( 'login' ) && $this->login_leniency_applies() ) {
							echo ' ';
							esc_html_e( 'The Login forms are the exception: they are let through unverified while the keys are wrong, so nobody is locked out.', 'edumall' );
						}
						?>
					<?php elseif ( 'misconfigured' === $error['kind'] ) : ?>
						<?php
						printf(
							/* translators: 1: how long ago, 2: provider error codes, 3: Customizer CAPTCHA section URL. */
							wp_kses( __( '%1$s ago the CAPTCHA provider rejected the site\'s keys (%2$s). Every guarded submission fails until the Site Key and Secret Key in <a href="%3$s">Customize &rarr; CAPTCHA</a> match the provider and the selected version.', 'edumall' ), array( 'a' => array( 'href' => array() ) ) ),
							esc_html( $when ),
							esc_html( $codes ),
							esc_url( admin_url( 'customize.php?autofocus[section]=captcha' ) )
						);

						if ( $this->is_guarding( 'login' ) && $this->login_leniency_applies() ) {
							echo ' ';
							esc_html_e( 'The Login forms are the exception: they are let through unverified while the keys are rejected, so nobody is locked out.', 'edumall' );
						}
						?>
					<?php else : ?>
						<?php
						printf(
							/* translators: 1: how long ago, 2: transport error. */
							esc_html__( '%1$s ago the CAPTCHA verification service could not be reached from this server (%2$s).', 'edumall' ),
							esc_html( $when ),
							esc_html( $codes )
						);
						?>
						<?php if ( 'allow' === $this->get_failsafe_mode() ) : ?>
							<?php esc_html_e( 'The failsafe is set to allow, so submissions were let through unverified for two minutes after each failure.', 'edumall' ); ?>
						<?php else : ?>
							<?php esc_html_e( 'Guarded submissions were rejected while it was unreachable. If your host blocks outgoing requests, allow the provider\'s API host, or set the failsafe to "Allow" under Customize > CAPTCHA.', 'edumall' ); ?>
						<?php endif; ?>
					<?php endif; ?>
				</p>
			</div>
			<?php
		}

		/**
		 * The keys could not be checked because the provider was unreachable
		 * from this server when they were saved. Nobody has been turned away
		 * by it (no visitor request was involved), but a server that cannot
		 * reach the provider cannot verify anyone either, so say so.
		 */
		public function admin_notice_probe_unreachable() {
			$probe = get_transient( self::KEY_PROBE_TRANSIENT );

			if ( ! is_array( $probe ) || empty( $probe['verdict'] ) || 'unreachable' !== $probe['verdict'] ) {
				return;
			}

			if ( ! isset( $probe['fingerprint'] ) || $probe['fingerprint'] !== $this->key_fingerprint() ) {
				return;
			}
			?>
			<div class="notice notice-warning is-dismissible">
				<p>
					<strong><?php esc_html_e( 'Edumall CAPTCHA:', 'edumall' ); ?></strong>
					<?php esc_html_e( 'the keys could not be checked because this server could not reach the CAPTCHA provider. If that is temporary you can ignore this; if your host blocks outgoing requests, allow the provider\'s API host, or set "If the Provider Is Unreachable" to Allow under Customize > CAPTCHA.', 'edumall' ); ?>
				</p>
			</div>
			<?php
		}

		/**
		 * Tutor Pro's Fraud Protection is handled like the other CAPTCHA plugins:
		 * the theme steps aside on the forms its reCAPTCHA guards (and still
		 * requires its token to be present, since Tutor Pro fails open without
		 * one). Warn only when its reCAPTCHA is selected without keys - then
		 * its widget renders broken and its check lets everything through, so
		 * the theme keeps guarding and visitors see the broken widget next to
		 * the theme's field.
		 */
		public function admin_notice_tutor_pro_conflict() {
			if ( ! current_user_can( 'edit_theme_options' ) || ! $this->is_enabled() ) {
				return;
			}

			if ( ! $this->compat->is_tutor_pro_recaptcha_misconfigured() ) {
				return;
			}
			?>
			<div class="notice notice-warning">
				<p>
					<strong><?php esc_html_e( 'Edumall CAPTCHA:', 'edumall' ); ?></strong>
					<?php esc_html_e( 'Tutor Pro\'s Fraud Protection is set to reCAPTCHA but one of its keys is missing: without a Site Key it shows no challenge at all, without a Secret Key it shows one it never verifies. Either way its check lets every submission through, so the theme CAPTCHA keeps guarding those forms itself (visitors may see two challenges). Please add both keys under Tutor LMS Pro > Settings > Authentication, or turn Fraud Protection off - the theme covers the same forms and more.', 'edumall' ); ?>
				</p>
			</div>
			<?php
		}

		/**
		 * Two plugin set-ups that break forms in ways the compat layer cannot
		 * fix on its own: hCaptcha for WP in reCAPTCHA-compatibility mode
		 * (its api.js takes over window.grecaptcha, so the theme's Google
		 * reCAPTCHA widget cannot render), and Simple Cloudflare Turnstile's
		 * WordPress login check while the theme's own Login group is off (its
		 * check runs inside the theme login popup's wp_signon() but its widget
		 * can never be shown there, so every popup login fails).
		 */
		public function admin_notice_plugin_conflicts() {
			if ( ! current_user_can( 'edit_theme_options' ) ) {
				return;
			}

			$provider = $this->get_provider();

			if ( in_array( $provider, array( 'recaptcha_v2', 'recaptcha_v3' ), true ) && $this->compat->is_hcaptcha_recaptcha_compat_on() ) {
				?>
				<div class="notice notice-warning">
					<p>
						<strong><?php esc_html_e( 'Edumall CAPTCHA conflict:', 'edumall' ); ?></strong>
						<?php esc_html_e( 'hCaptcha for WP is running in reCAPTCHA-compatibility mode, which replaces the Google reCAPTCHA script the theme relies on, so the theme\'s reCAPTCHA widget cannot render. Please enable "Disable reCAPTCHA Compatibility" in hCaptcha > Settings > General, or switch the theme provider to hCaptcha, Turnstile or Honeypot.', 'edumall' ); ?>
					</p>
				</div>
				<?php
			}

			if ( in_array( $provider, array( 'recaptcha_v2', 'recaptcha_v3' ), true ) && $this->compat->tutor_pro_uses_recaptcha() && $this->compat->is_tutor_pro_recaptcha_usable() ) {
				$theme_version = 'recaptcha_v2' === $provider ? 'v2' : 'v3';
				$tutor_version = $this->compat->get_tutor_pro_recaptcha_version();
				?>
				<div class="notice notice-warning is-dismissible">
					<p>
						<strong><?php esc_html_e( 'Edumall CAPTCHA:', 'edumall' ); ?></strong>
						<?php
						printf(
							/* translators: 1: theme reCAPTCHA version, 2: Tutor Pro reCAPTCHA version. */
							esc_html__( 'this site runs two Google reCAPTCHA set-ups - the theme (%1$s) and Tutor Pro\'s Fraud Protection (%2$s). Each form is challenged only once, but any page that shows a theme form and a Tutor form together loads Google\'s script twice, which two different versions or Site Keys do not always survive. Please keep one of them: turn Fraud Protection off under Tutor LMS Pro > Settings > Authentication (the theme covers the same forms and more), or leave it on and untick the matching forms under Customize > CAPTCHA.', 'edumall' ),
							esc_html( $theme_version ),
							esc_html( $tutor_version )
						);
						?>
					</p>
				</div>
				<?php
			}

			if ( ! $this->is_guarding( 'login' ) && $this->compat->sct_guards_wp_login_globally() ) {
				?>
				<div class="notice notice-warning">
					<p>
						<strong><?php esc_html_e( 'Edumall CAPTCHA conflict:', 'edumall' ); ?></strong>
						<?php esc_html_e( 'Simple Cloudflare Turnstile\'s "WordPress Login" check runs on every login, including the theme\'s login popup, where its widget can never be shown - so popup logins fail. Either enable "Login" under Customize > CAPTCHA (the theme then guards the popup and Turnstile steps aside there), or turn on "Only on the login page" in Turnstile\'s WordPress Login settings.', 'edumall' ); ?>
					</p>
				</div>
				<?php
			}
		}

		/**
		 * Tell administrators which native forms are left to another CAPTCHA
		 * plugin, so it is clear why the theme widget is absent there.
		 */
		public function admin_notice_deferred_forms() {
			if ( ! current_user_can( 'edit_theme_options' ) || ! $this->is_enabled() ) {
				return;
			}

			$summary = $this->compat->get_deferred_summary();

			if ( empty( $summary ) ) {
				return;
			}

			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

			// Only where it is relevant: the dashboard, plugins and themes screens.
			if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'plugins', 'themes' ), true ) ) {
				return;
			}
			?>
			<div class="notice notice-info">
				<p>
					<strong><?php esc_html_e( 'Edumall CAPTCHA:', 'edumall' ); ?></strong>
					<?php
					$labels = $this->get_form_labels();

					foreach ( $summary as $plugin => $forms ) {
						$names = array();

						foreach ( (array) $forms as $form_id ) {
							$names[] = isset( $labels[ $form_id ] ) ? $labels[ $form_id ] : sanitize_key( $form_id );
						}

						printf(
							/* translators: 1: plugin name, 2: comma-separated form names. */
							esc_html__( '%1$s already protects these forms, so the theme CAPTCHA steps aside on them: %2$s.', 'edumall' ),
							esc_html( $this->compat->get_plugin_label( $plugin ) ),
							esc_html( implode( ', ', $names ) )
						);
						echo ' ';
					}
					esc_html_e( 'The theme\'s own account popups and Register Form widget stay protected by the theme.', 'edumall' );

					if ( isset( $summary['tutor_pro'] ) ) {
						echo ' ';
						esc_html_e( 'On the forms left to Tutor Pro the theme still rejects a submission that carries no reCAPTCHA token at all, since Tutor Pro only checks the token when it is present. Note that those forms are then verified to Tutor Pro\'s standard: it checks only that Google accepted the token, not the reCAPTCHA v3 score, the action name or the host it was solved on.', 'edumall' );
					}
					?>
				</p>
			</div>
			<?php
		}
	}

	Edumall_Captcha::instance()->initialize();
}
