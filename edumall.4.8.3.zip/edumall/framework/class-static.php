<?php
defined( 'ABSPATH' ) || exit;

class Edumall {

	const PRIMARY_FONT = 'Gordita';
	const PRIMARY_COLOR = '#0071dc';
	const SECONDARY_COLOR = '#ffc221';
	const THIRD_COLOR = '#031f42';
	const HEADING_COLOR = '#252525';
	const HEADING_SECONDARY_COLOR = '#333';
	const TEXT_COLOR = '#696969';
	const TEXT_LIGHTEN_COLOR = '#ababab';
	const COMMENT_AVATAR_SIZE = 70;

	public static $mobile_detect = null;

	public static function mobile_detect() {
		if ( null === self::$mobile_detect ) {
			if ( class_exists( 'Mobile_Detect' ) ) {
				self::$mobile_detect = new Mobile_Detect();
			} else {
				self::$mobile_detect = false;
			}
		}

		return self::$mobile_detect;
	}

	public static function is_tablet() {
		if ( empty( self::mobile_detect() ) ) {
			return false;
		}

		return self::mobile_detect()->isTablet();
	}

	public static function is_mobile() {
		if ( empty( self::mobile_detect() ) ) {
			return false;
		}

		if ( self::is_tablet() ) {
			return false;
		}

		return self::mobile_detect()->isMobile();
	}

	public static function is_handheld() {
		return ( self::is_mobile() || self::is_tablet() );
	}

	public static function is_desktop() {
		return ! self::is_handheld();
	}

	public static function is_dark_version() {
		if ( 'dark' === Edumall_Global::instance()->get_site_skin() ) {
			return true;
		}

		return false;
	}

	/**
	 * Get settings for Kirki
	 *
	 * @param string $option_name
	 * @param string $default
	 *
	 * @return mixed
	 */
	public static function setting( $option_name = '', $default = '' ) {
		$value = Edumall_Kirki::get_option( 'theme', $option_name );

		return $value === null ? $default : $value;
	}

	/**
	 * Primary Menu
	 */
	public static function menu_primary( $args = array() ) {
		$menu_class = 'menu__container sm sm-simple';

		if ( EDUMALL_IS_RTL ) {
			$menu_class .= ' sm-rtl';
		}

		$defaults = array(
			'theme_location' => 'primary',
			'container'      => 'ul',
			'menu_class'     => $menu_class,
			'menu_id'        => 'menu-primary', // Change this id also need to change in global variable below.
			'extra_class'    => '',
		);

		if ( $defaults['extra_class'] ) {
			$defaults['menu_class'] .= ' ' . $defaults['extra_class'];
		}

		$args = wp_parse_args( $args, $defaults );

		if ( has_nav_menu( 'primary' ) && class_exists( 'Edumall_Walker_Nav_Menu' ) ) {
			$args['walker'] = new Edumall_Walker_Nav_Menu;
		}

		$menu = Edumall_Helper::get_post_meta( 'menu_display', '' );

		if ( $menu !== '' ) {
			$args['menu'] = $menu;
		}

		/**
		 * Nav menu render need many works.
		 * Cache it & used for mobile version to get the best performance.
		 *
		 * @see Edumall::menu_mobile_primary()
		 */ global $edumall_primary_menu;

		ob_start();

		wp_nav_menu( $args );

		$edumall_primary_menu = ob_get_clean();

		echo '' . $edumall_primary_menu;
	}

	/**
	 * Off Canvas Menu
	 */
	public static function off_canvas_menu_primary( $args = array() ) {
		$defaults = [
			'theme_location' => 'off_canvas',
			'container'      => 'ul',
			'menu_class'     => 'menu__container',
			'menu_id'        => 'off-canvas-menu-primary',
			'extra_class'    => '',
		];

		$args = wp_parse_args( $args, $defaults );

		if ( has_nav_menu( 'off_canvas' ) ) {
			$args['walker'] = new Edumall_Walker_Nav_Menu;
		}

		wp_nav_menu( $args );
	}

	/**
	 * Mobile Menu
	 */
	public static function menu_mobile_primary() {
		global $edumall_primary_menu;

		$edumall_primary_menu = is_null( $edumall_primary_menu ) ? '' : $edumall_primary_menu;

		$pattern = '/<ul\s[^>]*id=\"menu-primary\"[^>]*>/';

		if ( EDUMALL_IS_RTL ) {
			$mobile_menu = preg_replace( $pattern, '<ul id="mobile-menu-primary" class="menu__container mobile-menu-primary-rtl">', $edumall_primary_menu );
		} else {
			$mobile_menu = preg_replace( $pattern, '<ul id="mobile-menu-primary" class="menu__container">', $edumall_primary_menu );
		}

		echo '' . $mobile_menu;
		unset( $GLOBALS['edumall_primary_menu'] );
	}

	/**
	 * Resolve a Customizer logo setting (logo_dark / logo_light) to a URL.
	 *
	 * Single home for the id-vs-url decoding that branding_logo(), the course
	 * builder logo swap and the Tutor dashboard skin all need: the attachment id
	 * wins when present (retina-sized from logo_width), then a populated 'url'
	 * key, then a bare string value.
	 *
	 * @since 4.6.0
	 *
	 * @param string $logo_setting Customizer key, e.g. 'logo_dark'.
	 *
	 * @return string Resolved URL, '' when the setting is empty.
	 */
	public static function get_logo_setting_url( $logo_setting ) {
		$logo = Edumall::setting( $logo_setting );

		if ( is_array( $logo ) && isset( $logo['id'] ) && class_exists( 'Edumall_Image' ) ) {
			$logo_width   = intval( Edumall::setting( 'logo_width' ) );
			$retina_width = $logo_width > 0 ? $logo_width * 2 : 9999;

			$logo_args = array(
				'id'   => $logo['id'],
				'size' => "{$retina_width}x9999",
				'crop' => false,
			);

			$url = (string) Edumall_Image::get_attachment_url_by_id( $logo_args );

			if ( '' !== $url ) {
				return $url;
			}
		}

		if ( is_array( $logo ) && ! empty( $logo['url'] ) ) {
			return (string) $logo['url'];
		}

		if ( is_string( $logo ) && '' !== $logo ) {
			return $logo;
		}

		return '';
	}

	/**
	 * Logo
	 */
	public static function branding_logo( $reverse_scheme = null ) {
		$logo_dark_url  = Edumall_Helper::get_post_meta( 'custom_dark_logo', '' );
		$logo_light_url = Edumall_Helper::get_post_meta( 'custom_light_logo', '' );

		if ( 'dark' === Edumall_Global::instance()->get_site_skin() ) {
			$sticky_logo_skin = Edumall::setting( 'dark_scheme_header_sticky_logo' );
		} else {
			$sticky_logo_skin = Edumall::setting( 'header_sticky_logo' );
		}

		$header_logo_skin = Edumall_Global::instance()->get_header_skin();
		if ( 'dark' === Edumall_Global::instance()->get_site_skin() ) {
			$header_logo_skin = 'dark' === $header_logo_skin ? 'light' : 'dark';
		}

		if ( '' === $logo_dark_url ) {
			$logo_dark_url = self::get_logo_setting_url( 'logo_dark' );
		}

		if ( '' === $logo_light_url ) {
			$logo_light_url = self::get_logo_setting_url( 'logo_light' );
		}

		$has_both_skin = false;

		if ( $sticky_logo_skin !== $header_logo_skin || is_page_template( 'templates/one-page-scroll.php' ) ) {
			$has_both_skin = true;
		}

		if ( null !== $reverse_scheme ) {
			if ( 'dark' === Edumall_Global::instance()->get_site_skin() ) {
				$use_logo_scheme = 'light';
			} else {
				$use_logo_scheme = 'dark';
			}
		} else {
			$use_logo_scheme = $header_logo_skin;
		}

		$alt = get_bloginfo( 'name', 'display' );
		?>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( $has_both_skin === false ) : ?>
				<?php if ( 'dark' === $use_logo_scheme ): ?>
					<img src="<?php echo esc_url( $logo_dark_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>"
					     class="branding-logo dark-logo">
				<?php else: ?>
					<img src="<?php echo esc_url( $logo_light_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>"
					     class="branding-logo light-logo">
				<?php endif; ?>
			<?php else: ?>
				<img src="<?php echo esc_url( $logo_light_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>"
				     class="branding-logo light-logo">
				<img src="<?php echo esc_url( $logo_dark_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>"
				     class="branding-logo dark-logo">
			<?php endif; ?>
		</a>
		<?php
	}

	/**
	 * Adds custom attributes to the body tag.
	 */
	public static function body_attributes() {
		$attrs = apply_filters( 'edumall_body_attributes', array() );

		$attrs_string = '';
		if ( ! empty( $attrs ) ) {
			foreach ( $attrs as $attr => $value ) {
				$attrs_string .= " {$attr}=" . '"' . esc_attr( $value ) . '"';
			}
		}

		echo '' . $attrs_string;
	}

	/**
	 * Adds custom classes to the branding.
	 */
	public static function branding_class( $class = '' ) {
		$classes = array( 'branding' );

		if ( ! empty( $class ) ) {
			if ( ! is_array( $class ) ) {
				$class = preg_split( '#\s+#', $class );
			}
			$classes = array_merge( $classes, $class );
		} else {
			// Ensure that we always coerce class to being an array.
			$class = array();
		}

		$classes = apply_filters( 'edumall_branding_class', $classes, $class );

		echo 'class="' . esc_attr( join( ' ', $classes ) ) . '"';
	}

	/**
	 * Adds custom classes to the navigation.
	 */
	public static function navigation_class( $class = '' ) {
		$classes = array( 'navigation page-navigation' );

		if ( ! empty( $class ) ) {
			if ( ! is_array( $class ) ) {
				$class = preg_split( '#\s+#', $class );
			}
			$classes = array_merge( $classes, $class );
		} else {
			// Ensure that we always coerce class to being an array.
			$class = array();
		}

		$classes = apply_filters( 'edumall_navigation_class', $classes, $class );

		echo 'class="' . esc_attr( join( ' ', $classes ) ) . '"';
	}
}
