<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Provider_Hcaptcha' ) ) {

	/**
	 * hCaptcha.
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha_Provider_Hcaptcha extends Edumall_Captcha_Provider {

		const VERIFY_URL = 'https://api.hcaptcha.com/siteverify';

		public function get_slug() {
			return 'hcaptcha';
		}

		public function get_label() {
			return esc_html__( 'hCaptcha', 'edumall' );
		}

		public function get_js_adapter() {
			return 'hcaptcha';
		}

		public function get_api_url( $site_key, $language ) {
			// recaptchacompat=off: without it hCaptcha also writes its token
			// into a g-recaptcha-response field, which any reCAPTCHA plugin on
			// the same page would pick up and reject.
			$url = 'https://js.hcaptcha.com/1/api.js?render=explicit&recaptchacompat=off';

			if ( '' !== $language ) {
				$url .= '&hl=' . rawurlencode( $language );
			}

			return $url;
		}

		public function get_testing_hostname( $secret_key ) {
			// https://docs.hcaptcha.com/#integration-testing-test-keys
			return '0x0000000000000000000000000000000000000000' === (string) $secret_key ? 'dummy-key-pass' : '';
		}

		public function get_key_patterns() {
			return array(
				'site'   => '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i',
				'secret' => '/^(0x[0-9A-Fa-f]{40}|ES_[A-Za-z0-9]{20,})$/',
			);
		}

		public function get_verify_url() {
			return self::VERIFY_URL;
		}

		public function get_legacy_token_fields() {
			return array( 'h-captcha-response' );
		}

		public function verify( $token, $captcha ) {
			if ( '' === $token ) {
				return $this->result( false, 'empty' );
			}

			$remote = $this->remote_verify(
				$token,
				$captcha,
				array(
					'sitekey' => $captcha->get_site_key(),
				)
			);

			return $this->result_from_remote( $remote, $captcha );
		}
	}
}
