<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Provider_Honeypot' ) ) {

	/**
	 * Keyless, invisible trap: a field no human can see or reach, plus a
	 * signed render timestamp so a form posted back within a couple of
	 * seconds of being served is treated as automated.
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha_Provider_Honeypot extends Edumall_Captcha_Provider {

		/**
		 * Name of the trap field. Prefixed so browser autofill and password
		 * managers have no reason to recognise and populate it.
		 */
		const FIELD = 'edumall_hp';

		/**
		 * Signed timestamp of the render, so a form filled faster than any
		 * human could is rejected. Old timestamps are fine (page caches serve
		 * stale forms), only a too-fresh one is suspicious.
		 */
		const TIME_FIELD = 'edumall_hp_ts';

		public function get_slug() {
			return 'honeypot';
		}

		public function get_label() {
			return esc_html__( 'Honeypot (no keys required)', 'edumall' );
		}

		public function needs_keys() {
			return false;
		}

		public function is_invisible() {
			return true;
		}

		/**
		 * Seconds a form must have been on screen before it can be submitted.
		 *
		 * @return int
		 */
		public function get_min_submit_seconds() {
			/**
			 * Filters the minimum seconds between the honeypot form render and
			 * its submission. Zero disables the timing check.
			 *
			 * @since 4.8.0
			 *
			 * @param int $seconds Default 2.
			 */
			return max( 0, (int) apply_filters( 'edumall_captcha_honeypot_min_seconds', 2 ) );
		}

		public function render_field( $form, $captcha ) {
			// Anchor the grace window to the first time the trap is shown, so
			// the clock starts even on a site never opened in wp-admin.
			$captcha->stamp_honeypot_start_once();

			$now = time();

			/*
			 * Trap field: clipped rather than display:none, which some bots
			 * skip, and kept out of the tab order and the accessibility tree so
			 * no real visitor can reach it. The hiding is inlined on purpose:
			 * this option is on by default, so it must not depend on a
			 * stylesheet being present, current and non-RTL. 'readonly' stops a
			 * visitor typing into it; the data-* opt-outs keep password managers
			 * and form fillers from writing a value in programmatically.
			 */
			?>
			<div class="edumall-hp-field" aria-hidden="true" style="position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(1px,1px,1px,1px);white-space:nowrap;">
				<label>
					<?php esc_html_e( 'Leave this field empty', 'edumall' ); ?>
					<input type="text" name="<?php echo esc_attr( self::FIELD ); ?>" value="" autocomplete="off" tabindex="-1" readonly data-lpignore="true" data-1p-ignore data-bwignore data-form-type="other">
				</label>
			</div>
			<input type="hidden" name="<?php echo esc_attr( self::TIME_FIELD ); ?>" value="<?php echo esc_attr( $now . '.' . $this->sign( $now ) ); ?>">
			<?php
		}

		/**
		 * @param int $timestamp
		 *
		 * @return string
		 */
		protected function sign( $timestamp ) {
			return substr( wp_hash( 'edumall_captcha_hp|' . (int) $timestamp ), 0, 20 );
		}

		public function verify( $token, $captcha ) {
			// Anchor the grace window here too, so a bot that POSTs straight to
			// the endpoint without ever rendering the form cannot keep the clock
			// at zero and be forgiven forever on a headless site.
			$captcha->stamp_honeypot_start_once();

			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- the form handler verifies its nonce before this runs.
			$trap = isset( $_POST[ self::FIELD ] ) ? wp_unslash( $_POST[ self::FIELD ] ) : null;

			if ( null === $trap ) {
				/*
				 * No trap in the submission: the markup did not come from a form
				 * this version rendered. That is normally a script posting
				 * straight to the endpoint, but it is also what a page cache
				 * filled before the honeypot went live sends, so it is forgiven
				 * during the grace window after it goes live.
				 */
				if ( $captcha->honeypot_grace_active() ) {
					return $this->result( true );
				}

				return $this->result( false, 'missing' );
			}

			// Only a bot fills a field no human can see or tab into. Do not
			// trim: any character written in, whitespace included, counts as
			// filled, so a space-filling bot cannot slip past.
			if ( ! is_string( $trap ) || '' !== $trap ) {
				return $this->result( false, 'filled' );
			}

			$min = $this->get_min_submit_seconds();

			if ( $min > 0 ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
				$stamp = isset( $_POST[ self::TIME_FIELD ] ) && is_string( $_POST[ self::TIME_FIELD ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::TIME_FIELD ] ) ) : '';
				$parts = explode( '.', $stamp, 2 );

				// Only a genuine, signed stamp is trusted; a missing or forged one
				// simply contributes no timing signal (the trap check above still
				// applies), so cached or customised forms are never punished for it.
				if ( 2 === count( $parts ) && ctype_digit( $parts[0] ) && hash_equals( $this->sign( (int) $parts[0] ), $parts[1] ) ) {
					$rendered_at = (int) $parts[0];

					if ( $rendered_at <= time() && ( time() - $rendered_at ) < $min ) {
						return $this->result( false, 'too_fast' );
					}
				}
			}

			return $this->result( true );
		}
	}
}
