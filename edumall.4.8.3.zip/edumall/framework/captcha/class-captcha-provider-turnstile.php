<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Provider_Turnstile' ) ) {

	/**
	 * Cloudflare Turnstile.
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha_Provider_Turnstile extends Edumall_Captcha_Provider {

		const VERIFY_URL = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

		public function get_slug() {
			return 'turnstile';
		}

		public function get_label() {
			return esc_html__( 'Cloudflare Turnstile', 'edumall' );
		}

		public function get_js_adapter() {
			return 'turnstile';
		}

		public function get_api_url( $site_key, $language ) {
			return 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
		}

		public function get_testing_hostname( $secret_key ) {
			// https://developers.cloudflare.com/turnstile/troubleshooting/testing/
			return preg_match( '/^[1-3]x0{31}AA$/', (string) $secret_key ) ? 'example.com' : '';
		}

		public function get_key_patterns() {
			return array(
				'site'   => '/^[0-3]x[A-Za-z0-9_-]{20,}$/',
				'secret' => '/^[0-3]x[A-Za-z0-9_-]{30,}$/',
			);
		}

		public function get_verify_url() {
			return self::VERIFY_URL;
		}

		public function get_legacy_token_fields() {
			return array( 'cf-turnstile-response' );
		}

		public function get_js_render_options( $language = '' ) {
			// The theme owns the token field, so Turnstile must not inject its
			// own cf-turnstile-response input next to it.
			$options = array(
				'response-field' => false,
			);

			if ( '' !== $language ) {
				$options['language'] = $language;
			}

			return $options;
		}

		public function verify( $token, $captcha ) {
			if ( '' === $token ) {
				return $this->result( false, 'empty' );
			}

			return $this->result_from_remote( $this->remote_verify( $token, $captcha ), $captcha );
		}
	}
}
