<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Provider' ) ) {

	/**
	 * Contract every CAPTCHA provider implements. The facade (Edumall_Captcha)
	 * never branches on a provider slug: it asks the active provider to print
	 * its field and to verify the submitted token, and applies the shared,
	 * provider-agnostic policy on top (form gating, whitelist, failsafe,
	 * hostname allow-list, logging).
	 *
	 * @since 4.8.0
	 */
	abstract class Edumall_Captcha_Provider {

		/**
		 * @return string Provider slug stored in the Customizer setting.
		 */
		abstract public function get_slug();

		/**
		 * @return string Human-readable label for the Customizer.
		 */
		abstract public function get_label();

		/**
		 * Whether the provider needs API keys and an external script.
		 *
		 * @return bool
		 */
		public function needs_keys() {
			return true;
		}

		/**
		 * Whether the challenge is invisible to the visitor (no widget box).
		 * Invisible providers cannot be shown "after N failed logins", since
		 * there is nothing to show; the login limit is ignored for them.
		 *
		 * @return bool
		 */
		public function is_invisible() {
			return false;
		}

		/**
		 * Name of the JS adapter in captcha.js that drives this provider.
		 *
		 * @return string
		 */
		public function get_js_adapter() {
			return '';
		}

		/**
		 * URL of the provider script. Loaded on demand by captcha.js, which
		 * appends the onload callback name itself.
		 *
		 * @param string $site_key
		 * @param string $language Language code chosen by the theme ('' = auto).
		 *
		 * @return string Empty when the provider has no script.
		 */
		public function get_api_url( $site_key, $language ) {
			return '';
		}

		/**
		 * URL of the server-side verification endpoint.
		 *
		 * @return string Empty when the provider verifies locally.
		 */
		public function get_verify_url() {
			return '';
		}

		/**
		 * Regular expressions the Site Key and Secret Key of this provider are
		 * expected to match, so an obviously wrong pair (a Turnstile key pasted
		 * under reCAPTCHA, a truncated copy) is reported the moment it is saved.
		 * Empty patterns skip the check.
		 *
		 * @return array { site: string, secret: string }
		 */
		public function get_key_patterns() {
			return array(
				'site'   => '',
				'secret' => '',
			);
		}

		/**
		 * Host the provider reports when the site is configured with its
		 * publicly documented testing keys, which always solve and always
		 * answer with a fixed placeholder host rather than the real one.
		 * Accepting it lets an administrator try the provider out without an
		 * account; it weakens nothing, because a testing key accepts every
		 * visitor anyway.
		 *
		 * @param string $secret_key Configured Secret Key.
		 *
		 * @return string Empty when the keys are not the provider's test pair.
		 */
		public function get_testing_hostname( $secret_key ) {
			return '';
		}

		/**
		 * The provider's own default response field names, read only as a
		 * fallback for markup rendered before the theme moved to its own
		 * namespaced field (see Edumall_Captcha::TOKEN_FIELD).
		 *
		 * @return string[]
		 */
		public function get_legacy_token_fields() {
			return array();
		}

		/**
		 * Extra options captcha.js passes to the provider render() call.
		 *
		 * @param string $language Language code chosen by the theme ('' = auto).
		 *
		 * @return array
		 */
		public function get_js_render_options( $language = '' ) {
			return array();
		}

		/**
		 * Print the form field(s) for the given form.
		 *
		 * @param string          $form    Form group: register, login, lost_password, comment.
		 * @param Edumall_Captcha $captcha Facade, for keys and shared markup helpers.
		 */
		public function render_field( $form, $captcha ) {
			$captcha->render_widget_markup( $form );
		}

		/**
		 * Verify the submission.
		 *
		 * @param string          $token   Token read from the theme's field (may be empty).
		 * @param Edumall_Captcha $captcha Facade, for keys, IP, thresholds and helpers.
		 *
		 * @return array {
		 *     @type bool     $valid  Whether the challenge passed.
		 *     @type string   $reason Machine-readable reason when it did not.
		 *     @type string[] $codes  Provider error codes, if any.
		 *     @type bool     $transport_error True when the provider could not be reached
		 *                                     (lets the facade apply the failsafe policy).
		 * }
		 */
		abstract public function verify( $token, $captcha );

		/**
		 * Build the standard result array.
		 *
		 * @param bool     $valid
		 * @param string   $reason
		 * @param string[] $codes
		 * @param bool     $transport_error
		 *
		 * @return array
		 */
		protected function result( $valid, $reason = '', $codes = array(), $transport_error = false ) {
			return array(
				'valid'           => (bool) $valid,
				'reason'          => (string) $reason,
				'codes'           => array_values( array_map( 'strval', (array) $codes ) ),
				'transport_error' => (bool) $transport_error,
			);
		}

		/**
		 * POST the token to the provider's siteverify endpoint. Shared by the
		 * remote providers; the facade's timeout, IP and key helpers are used.
		 *
		 * @param string          $token
		 * @param Edumall_Captcha $captcha
		 * @param array           $extra_body Extra body params (e.g. sitekey for hCaptcha).
		 *
		 * @return array {
		 *     @type bool       $reached True when a JSON body came back.
		 *     @type array|null $body    Decoded JSON, or null.
		 *     @type string     $error   Transport error summary when not reached.
		 * }
		 */
		protected function remote_verify( $token, $captcha, $extra_body = array() ) {
			$body = array_merge(
				array(
					'secret'   => $captcha->get_secret_key(),
					'response' => $token,
					'remoteip' => $captcha->get_client_ip(),
				),
				$extra_body
			);

			$response = wp_remote_post(
				$this->get_verify_url(),
				array(
					'timeout' => $captcha->get_request_timeout(),
					'body'    => $body,
				)
			);

			if ( is_wp_error( $response ) ) {
				return array(
					'reached' => false,
					'body'    => null,
					'error'   => $response->get_error_code() . ': ' . $response->get_error_message(),
				);
			}

			$status  = (int) wp_remote_retrieve_response_code( $response );
			$decoded = json_decode( wp_remote_retrieve_body( $response ), true );

			// A 5xx, or a 2xx/3xx that is not JSON (proxy page, captive portal),
			// is the provider being unavailable, not a verdict on the token;
			// treat it like a transport failure. A 4xx is a verdict: the request
			// itself was refused, so it can never open the failsafe.
			if ( $status >= 500 || ( $status < 400 && ! is_array( $decoded ) ) ) {
				return array(
					'reached' => false,
					'body'    => null,
					'error'   => 'http_' . $status,
				);
			}

			if ( ! is_array( $decoded ) ) {
				$decoded = array(
					'success'     => false,
					'error-codes' => array( 'http_' . $status ),
				);
			}

			return array(
				'reached' => true,
				'body'    => $decoded,
				'error'   => '',
			);
		}

		/**
		 * Turn a siteverify JSON reply into the standard result, applying the
		 * shared checks: success flag, then hostname allow-list.
		 *
		 * @param array           $remote  Return value of remote_verify().
		 * @param Edumall_Captcha $captcha
		 *
		 * @return array
		 */
		protected function result_from_remote( $remote, $captcha ) {
			if ( empty( $remote['reached'] ) ) {
				return $this->result( false, 'unreachable', array( $remote['error'] ), true );
			}

			$body  = $remote['body'];
			$codes = isset( $body['error-codes'] ) ? (array) $body['error-codes'] : array();

			if ( empty( $body['success'] ) ) {
				return $this->result( false, 'rejected', $codes );
			}

			// The Site Key is public, so confirm the challenge was solved on this
			// site's own host and not on a copy hosted elsewhere.
			$hostname = isset( $body['hostname'] ) ? (string) $body['hostname'] : '';

			if ( ! $captcha->hostname_matches( $hostname, $this->get_slug() ) ) {
				return $this->result( false, 'hostname', array( 'hostname:' . $hostname ) );
			}

			return $this->result( true );
		}
	}
}
