<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Provider_Recaptcha_V3' ) ) {

	/**
	 * Google reCAPTCHA v3: invisible, score based. captcha.js fetches a token
	 * for the configured action into the theme's hidden field and keeps it
	 * fresh; the server enforces the action name and the score threshold.
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha_Provider_Recaptcha_V3 extends Edumall_Captcha_Provider {

		const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

		/**
		 * Action name sent with the token and enforced on verification.
		 */
		const ACTION = 'edumall_account';

		public function get_slug() {
			return 'recaptcha_v3';
		}

		public function get_label() {
			return esc_html__( 'Google reCAPTCHA v3 (invisible)', 'edumall' );
		}

		public function is_invisible() {
			return true;
		}

		public function get_js_adapter() {
			return 'grecaptcha_v3';
		}

		public function get_api_url( $site_key, $language ) {
			$url = 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $site_key );

			if ( '' !== $language ) {
				$url .= '&hl=' . rawurlencode( $language );
			}

			return $url;
		}

		public function get_key_patterns() {
			return array(
				'site'   => '/^6L[A-Za-z0-9_-]{38}$/',
				'secret' => '/^6L[A-Za-z0-9_-]{38}$/',
			);
		}

		public function get_verify_url() {
			return self::VERIFY_URL;
		}

		public function get_legacy_token_fields() {
			return array( 'g-recaptcha-response' );
		}

		public function get_js_render_options( $language = '' ) {
			return array(
				'action' => self::ACTION,
			);
		}

		/**
		 * Invisible: only the token carrier is printed; captcha.js fills it.
		 */
		public function render_field( $form, $captcha ) {
			$captcha->render_token_input( $form, 'edumall-captcha-v3' );
		}

		public function verify( $token, $captcha ) {
			if ( '' === $token ) {
				return $this->result( false, 'empty' );
			}

			$remote = $this->remote_verify( $token, $captcha );
			$result = $this->result_from_remote( $remote, $captcha );

			if ( ! $result['valid'] ) {
				return $result;
			}

			$body   = $remote['body'];
			$score  = isset( $body['score'] ) ? (float) $body['score'] : 0;
			$action = isset( $body['action'] ) ? (string) $body['action'] : '';

			if ( self::ACTION !== $action ) {
				return $this->result( false, 'action', array( 'action:' . $action ) );
			}

			if ( $score < $captcha->get_v3_score_threshold() ) {
				return $this->result( false, 'score', array( 'score:' . $score ) );
			}

			return $this->result( true );
		}
	}
}
