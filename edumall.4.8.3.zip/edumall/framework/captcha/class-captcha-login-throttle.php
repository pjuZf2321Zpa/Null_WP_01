<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Login_Throttle' ) ) {

	/**
	 * Counts failed logins per client IP so the login challenge can be shown
	 * only once an address has failed a few times, instead of to everyone.
	 * Every login path counts: the theme popup, wp-login.php, WooCommerce and
	 * Tutor all end in wp_login_failed / wp_login.
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha_Login_Throttle {

		const TRANSIENT_PREFIX = 'edumall_captcha_lf_';

		/**
		 * @var Edumall_Captcha
		 */
		protected $captcha;

		/**
		 * @param Edumall_Captcha $captcha
		 */
		public function __construct( $captcha ) {
			$this->captcha = $captcha;
		}

		public function initialize() {
			add_action( 'wp_login_failed', array( $this, 'record_failure' ), 10, 1 );
			add_action( 'wp_login', array( $this, 'clear' ), 10, 2 );
		}

		/**
		 * Minutes a failure stays counted.
		 *
		 * @return int
		 */
		public function get_interval() {
			/**
			 * Filters how long (minutes) failed logins are remembered per IP.
			 *
			 * @since 4.8.0
			 *
			 * @param int $minutes Default 15.
			 */
			return max( 1, (int) apply_filters( 'edumall_captcha_login_interval', 15 ) );
		}

		/**
		 * @param string $ip
		 *
		 * @return string
		 */
		protected function key( $ip ) {
			return self::TRANSIENT_PREFIX . md5( (string) $ip );
		}

		/**
		 * @param string $ip Client IP; defaults to the current request's.
		 *
		 * @return int
		 */
		public function get_failures( $ip = '' ) {
			$ip = '' !== $ip ? $ip : $this->captcha->get_client_ip();

			if ( '' === $ip ) {
				return 0;
			}

			return (int) get_transient( $this->key( $ip ) );
		}

		/**
		 * @param string $username Unused; wp_login_failed signature.
		 */
		public function record_failure( $username = '' ) {
			// Only worth a database write when the counter is actually consumed:
			// Login guarded, a limit set, and a provider that has something to show.
			$provider = $this->captcha->get_provider_object();

			if ( ! $provider || $provider->is_invisible() || ! $this->captcha->is_guarding( 'login' ) || 0 === $this->captcha->get_login_limit() ) {
				return;
			}

			$ip = $this->captcha->get_client_ip();

			if ( '' === $ip ) {
				return;
			}

			$count = $this->get_failures( $ip );

			// Cap the counter so a flood cannot turn every attempt into a write.
			if ( $count >= 1000 ) {
				return;
			}

			set_transient( $this->key( $ip ), $count + 1, $this->get_interval() * MINUTE_IN_SECONDS );
		}

		/**
		 * @param string  $user_login Unused; wp_login signature.
		 * @param WP_User $user       Unused.
		 */
		public function clear( $user_login = '', $user = null ) {
			$ip = $this->captcha->get_client_ip();

			if ( '' !== $ip ) {
				delete_transient( $this->key( $ip ) );
			}
		}
	}
}
