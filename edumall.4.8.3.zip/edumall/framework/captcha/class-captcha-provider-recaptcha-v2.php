<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Provider_Recaptcha_V2' ) ) {

	/**
	 * Google reCAPTCHA v2 "I'm not a robot" checkbox.
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha_Provider_Recaptcha_V2 extends Edumall_Captcha_Provider {

		const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

		public function get_slug() {
			return 'recaptcha_v2';
		}

		public function get_label() {
			return esc_html__( 'Google reCAPTCHA v2', 'edumall' );
		}

		public function get_js_adapter() {
			return 'grecaptcha';
		}

		public function get_api_url( $site_key, $language ) {
			$url = 'https://www.google.com/recaptcha/api.js?render=explicit';

			if ( '' !== $language ) {
				$url .= '&hl=' . rawurlencode( $language );
			}

			return $url;
		}

		public function get_key_patterns() {
			return array(
				'site'   => '/^6L[A-Za-z0-9_-]{38}$/',
				'secret' => '/^6L[A-Za-z0-9_-]{38}$/',
			);
		}

		public function get_verify_url() {
			return self::VERIFY_URL;
		}

		public function get_legacy_token_fields() {
			return array( 'g-recaptcha-response' );
		}

		public function verify( $token, $captcha ) {
			if ( '' === $token ) {
				return $this->result( false, 'empty' );
			}

			return $this->result_from_remote( $this->remote_verify( $token, $captcha ), $captcha );
		}
	}
}
