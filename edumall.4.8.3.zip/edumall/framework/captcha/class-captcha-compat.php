<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Captcha_Compat' ) ) {

	/**
	 * Coexistence with other CAPTCHA plugins that guard the same shared
	 * WordPress, WooCommerce and Tutor LMS forms.
	 *
	 * Where a plugin already guards a native form the theme steps aside on
	 * that form (no second widget, no second verification of a single-use
	 * token). Only plugins known to fail closed on a missing token are
	 * handed a form: hCaptcha for WP and Simple Cloudflare Turnstile. Tutor
	 * Pro's Fraud Protection fails open, so it is only reported, never
	 * deferred to.
	 *
	 * The theme's own AJAX account forms are never affected: no plugin can
	 * see them, so the theme always guards those itself.
	 *
	 * @since 4.8.0
	 */
	class Edumall_Captcha_Compat {

		/**
		 * Native form ids (as used in the form registry) hCaptcha for WP may
		 * guard: its status setting key + the value that enables the form.
		 */
		const HCAPTCHA_MAP = array(
			'wp_login'            => array( 'wp_status', 'login' ),
			'wp_register'         => array( 'wp_status', 'register' ),
			'wp_lost_password'    => array( 'wp_status', 'lost_pass' ),
			'comment'             => array( 'wp_status', 'comment' ),
			'wc_login'            => array( 'woocommerce_status', 'login' ),
			'wc_register'         => array( 'woocommerce_status', 'register' ),
			'wc_lost_password'    => array( 'woocommerce_status', 'lost_pass' ),
			'tutor_login'         => array( 'tutor_status', 'login' ),
			'tutor_register'      => array( 'tutor_status', 'register' ),
			'tutor_lost_password' => array( 'tutor_status', 'lost_pass' ),
		);

		/**
		 * Native form ids Simple Cloudflare Turnstile may guard: the option
		 * that switches its integration on. Its WordPress login / register /
		 * reset checks hook the global authenticate / registration_errors /
		 * lostpassword_post, which the Tutor templates and handlers fire too;
		 * it has no Tutor lost-password integration (its reset check runs on
		 * wp-login.php only).
		 */
		const SCT_MAP = array(
			'wp_login'         => 'cfturnstile_login',
			'wp_register'      => 'cfturnstile_register',
			'wp_lost_password' => 'cfturnstile_reset',
			'comment'          => 'cfturnstile_comment',
			'wc_login'         => 'cfturnstile_woo_login',
			'wc_register'      => 'cfturnstile_woo_register',
			'wc_lost_password' => 'cfturnstile_woo_reset',
			'tutor_login'      => 'cfturnstile_login',
			'tutor_register'   => 'cfturnstile_register',
		);

		/**
		 * Native form ids Tutor Pro's Fraud Protection may guard, by the
		 * "Location" it is enabled for. Only its reCAPTCHA v2/v3 methods are
		 * deferred to (a visible widget or a second Google script would clash);
		 * its honeypot is invisible and coexists with the theme's own.
		 */
		const TUTOR_PRO_MAP = array(
			'wp_register'         => 'wp_registration',
			'tutor_register'      => 'tutor_registration',
			'wp_login'            => 'wp_login',
			'tutor_login'         => 'tutor_login',
			'tutor_lost_password' => 'tutor_login',
		);

		/**
		 * @var null|array Memoized per request: form id => plugin slug (static part).
		 */
		protected $guarded = null;

		/**
		 * @return bool Whether hCaptcha for WP is active with keys (live or test mode).
		 */
		public function is_hcaptcha_active() {
			if ( ! function_exists( 'hcaptcha' ) ) {
				return false;
			}

			$settings = $this->hcaptcha_settings();

			if ( ! $settings ) {
				return false;
			}

			// get_site_key()/get_secret_key() also cover hCaptcha's built-in test
			// modes, where the raw options can be empty.
			$site_key = method_exists( $settings, 'get_site_key' ) ? (string) $settings->get_site_key() : (string) $settings->get( 'site_key' );
			$secret   = method_exists( $settings, 'get_secret_key' ) ? (string) $settings->get_secret_key() : (string) $settings->get( 'secret_key' );

			return '' !== $site_key && '' !== $secret;
		}

		/**
		 * Whether Simple Cloudflare Turnstile is active with keys and its
		 * integrations loaded (it loads them only when its keys are saved and
		 * either untested or tested successfully).
		 *
		 * @return bool
		 */
		public function is_sct_active() {
			// inc/turnstile.php is only included once both keys are saved.
			if ( ! function_exists( 'cfturnstile_check' ) ) {
				return false;
			}

			$tested = get_option( 'cfturnstile_tested' );

			return empty( $tested ) || 'yes' === $tested;
		}

		/**
		 * @return bool Whether Tutor Pro's Fraud Protection is on and its addon loaded.
		 */
		public function is_tutor_pro_fraud_protection_active() {
			if ( ! class_exists( '\TutorPro\Auth\Settings' )
				|| ! method_exists( '\TutorPro\Auth\Settings', 'is_spam_protection_enabled' )
				|| ! \TutorPro\Auth\Settings::is_spam_protection_enabled() ) {
				return false;
			}

			// The class autoloads even when Tutor Pro's Authentication addon file
			// was not loaded (it defines this constant), in which case none of
			// its hooks are registered.
			return defined( 'TUTOR_AUTH_FILE' );
		}

		/**
		 * @return string Tutor Pro's spam-protection method: honeypot, recaptcha_v2, recaptcha_v3 or ''.
		 */
		public function get_tutor_pro_method() {
			if ( ! $this->is_tutor_pro_fraud_protection_active() || ! method_exists( '\TutorPro\Auth\Settings', 'get_spam_protection_method' ) ) {
				return '';
			}

			return (string) \TutorPro\Auth\Settings::get_spam_protection_method();
		}

		/**
		 * @return string[] Tutor Pro's "Location" values (wp_registration, tutor_registration, wp_login, tutor_login).
		 */
		public function get_tutor_pro_locations() {
			if ( ! $this->is_tutor_pro_fraud_protection_active() || ! method_exists( '\TutorPro\Auth\Settings', 'get_spam_protection_location' ) ) {
				return array();
			}

			return array_map( 'strval', (array) \TutorPro\Auth\Settings::get_spam_protection_location() );
		}

		/**
		 * Whether Tutor Pro's reCAPTCHA is actually able to verify: with a
		 * blank key its check is a no-op, so the theme must not step aside.
		 *
		 * @return bool
		 */
		public function is_tutor_pro_recaptcha_usable() {
			$method = $this->get_tutor_pro_method();

			if ( ! in_array( $method, array( 'recaptcha_v2', 'recaptcha_v3' ), true ) || ! function_exists( 'tutils' ) ) {
				return false;
			}

			$prefix = 'recaptcha_v2' === $method ? 'recaptcha_v2_' : 'recaptcha_v3_';

			return '' !== trim( (string) tutils()->get_option( $prefix . 'site_key', '' ) )
				&& '' !== trim( (string) tutils()->get_option( $prefix . 'secret_key', '' ) );
		}

		/**
		 * Whether Tutor Pro's reCAPTCHA is selected but cannot work (blank key):
		 * its widget renders broken and its check lets everything through.
		 *
		 * @return bool
		 */
		public function is_tutor_pro_recaptcha_misconfigured() {
			return in_array( $this->get_tutor_pro_method(), array( 'recaptcha_v2', 'recaptcha_v3' ), true ) && ! $this->is_tutor_pro_recaptcha_usable();
		}

		/**
		 * Tutor Pro verifies its reCAPTCHA token only when the field is
		 * present; a submission without it is waved through. When the theme
		 * defers a form to Tutor Pro it therefore still requires that field,
		 * so a bot posting straight to the endpoint is stopped, while the
		 * token itself is verified once, by Tutor Pro.
		 *
		 * @return bool
		 */
		public function tutor_pro_token_present() {
			$field = 'recaptcha_v3' === $this->get_tutor_pro_method() ? 'recaptcha_token' : 'g-recaptcha-response';

			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- presence check only; Tutor Pro verifies the value.
			return isset( $_POST[ $field ] ) && is_string( $_POST[ $field ] ) && '' !== trim( $_POST[ $field ] );
		}

		/**
		 * Whether Tutor Pro's Fraud Protection also runs a Google reCAPTCHA, so
		 * the site ends up with two Google set-ups - two copies of api.js on any
		 * page that shows both a theme form and a Tutor form, and two key pairs
		 * unless the administrator deliberately configured the same one twice.
		 *
		 * @return bool
		 */
		public function tutor_pro_uses_recaptcha() {
			return in_array( $this->get_tutor_pro_method(), array( 'recaptcha_v2', 'recaptcha_v3' ), true );
		}

		/**
		 * @return string 'v2', 'v3' or '' - the reCAPTCHA version Tutor Pro runs.
		 */
		public function get_tutor_pro_recaptcha_version() {
			$method = $this->get_tutor_pro_method();

			return 'recaptcha_v2' === $method ? 'v2' : ( 'recaptcha_v3' === $method ? 'v3' : '' );
		}

		/**
		 * @return bool hCaptcha for WP loads its api.js in reCAPTCHA-compatibility
		 *              mode (the default), which aliases window.grecaptcha.
		 */
		public function is_hcaptcha_recaptcha_compat_on() {
			if ( ! $this->is_hcaptcha_active() ) {
				return false;
			}

			$settings = $this->hcaptcha_settings();

			if ( ! $settings || ! method_exists( $settings, 'is_on' ) ) {
				return true;
			}

			return ! $settings->is_on( 'recaptcha_compat_off' );
		}

		/**
		 * @return bool SCT's "WordPress Login" check is on and not confined to
		 *              wp-login.php, so it also runs inside the theme's AJAX popup.
		 */
		public function sct_guards_wp_login_globally() {
			return $this->is_sct_active() && get_option( 'cfturnstile_login', 0 ) && ! get_option( 'cfturnstile_login_only', 0 );
		}

		/**
		 * @return bool Whether any other CAPTCHA is guarding forms on this site.
		 */
		public function is_any_plugin_active() {
			return $this->is_hcaptcha_active() || $this->is_sct_active() || $this->is_tutor_pro_fraud_protection_active();
		}

		/**
		 * @return object|null hCaptcha settings object, or null.
		 */
		protected function hcaptcha_settings() {
			try {
				$main = hcaptcha();

				if ( ! is_object( $main ) || ! method_exists( $main, 'settings' ) ) {
					return null;
				}

				$settings = $main->settings();

				return is_object( $settings ) && method_exists( $settings, 'get' ) ? $settings : null;
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
				return null;
			}
		}

		/**
		 * @param string $plugin_file Plugin basename.
		 *
		 * @return bool
		 */
		protected function is_plugin_active( $plugin_file ) {
			if ( ! function_exists( 'is_plugin_active' ) ) {
				include_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			return function_exists( 'is_plugin_active' ) && is_plugin_active( $plugin_file );
		}

		/**
		 * Which plugin, if any, guards a native form on this request.
		 *
		 * The static part (plugin active + its option on) is memoized; the
		 * request part mirrors the conditions under which the plugin itself
		 * would skip its check, so the theme never steps aside from a request
		 * the plugin will not verify.
		 *
		 * @param string $form_id Registry form id (wp_register, wc_login, ...).
		 *
		 * @return string '' when nothing else guards it, else 'hcaptcha' or 'sct'.
		 */
		public function plugin_guarding( $form_id ) {
			if ( null === $this->guarded ) {
				$this->guarded = $this->detect();
			}

			$guarding = isset( $this->guarded[ $form_id ] ) ? $this->guarded[ $form_id ] : '';

			if ( '' !== $guarding && ! $this->plugin_covers_request( $guarding, $form_id ) ) {
				$guarding = '';
			}

			/**
			 * Filters which plugin the theme CAPTCHA defers to for a native form.
			 * Return '' to make the theme guard the form itself regardless.
			 *
			 * @since 4.8.0
			 *
			 * @param string $guarding Plugin slug ('hcaptcha', 'sct') or ''.
			 * @param string $form_id  Form registry id.
			 */
			return (string) apply_filters( 'edumall_captcha_plugin_guarding', $guarding, $form_id );
		}

		/**
		 * Whether the plugin will actually run its check on the current
		 * request for this form. Each plugin skips its verification in
		 * specific situations; deferring there would leave the form open.
		 *
		 * @param string $plugin  'hcaptcha' or 'sct'.
		 * @param string $form_id
		 *
		 * @return bool
		 */
		protected function plugin_covers_request( $plugin, $form_id ) {
			// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- routing checks only; nothing is trusted from these fields.
			$is_post       = isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'];
			$on_wp_login   = (bool) did_action( 'login_init' );
			$tutor_action  = Edumall_Captcha::instance()->tutor_action();
			$tutor_post    = isset( $_POST['tutor_action'] );
			$wc_reg_alias  = isset( $_POST['woocommerce-register-nonce'] ) || isset( $_POST['edd_register_nonce'] );
			$wc_log_alias  = isset( $_POST['woocommerce-login-nonce'] ) || isset( $_POST['edd_login_nonce'] );
			$wc_log_nonce  = isset( $_POST['woocommerce-login-nonce'] );
			$wc_lost_nonce = isset( $_POST['woocommerce-lost-password-nonce'] );
			$wp_action     = isset( $_POST['action'] ) && is_string( $_POST['action'] )
				? sanitize_key( wp_unslash( $_POST['action'] ) )
				: ( isset( $_GET['action'] ) && is_string( $_GET['action'] ) ? sanitize_key( wp_unslash( $_GET['action'] ) ) : '' );
			// phpcs:enable

			if ( 'sct' === $plugin ) {
				$login_on   = (bool) get_option( 'cfturnstile_login', 0 );
				$login_only = (bool) get_option( 'cfturnstile_login_only', 0 );

				switch ( $form_id ) {
					case 'wp_register':
					case 'tutor_register':
						// SCT returns early on a WooCommerce / EDD register nonce, whatever
						// the form; a bot can borrow the public WooCommerce nonce.
						if ( $wc_reg_alias ) {
							return false;
						}

						// "Only on the login page": Tutor's front-end form is not checked.
						return ! get_option( 'cfturnstile_register_only', 0 ) || $on_wp_login;

					case 'wp_login':
					case 'tutor_login':
						// SCT skips its global login check for a POST carrying a WooCommerce
						// login nonce when its own WooCommerce login option is off (and for
						// an EDD login nonce always).
						if ( $wc_log_alias ) {
							return false;
						}

						return ! $login_only || $on_wp_login;

					case 'wc_login':
						// With its WordPress login on, SCT verifies the My Account login
						// through the global check (skipped off wp-login.php when "only on
						// the login page"); otherwise through a WooCommerce-only check that
						// needs the woocommerce-login-nonce field (WooCommerce also accepts
						// the nonce as _wpnonce, which SCT would then skip).
						if ( $login_on ) {
							return ! $login_only || $on_wp_login;
						}

						return ! $is_post || $wc_log_nonce;

					case 'wp_lost_password':
					case 'tutor_lost_password':
						// SCT's reset check runs on wp-login.php only, and returns early
						// when a WooCommerce lost-password nonce field is present.
						return $on_wp_login && ! $wc_lost_nonce;

					case 'wc_lost_password':
						// SCT's WooCommerce reset check needs that exact nonce field.
						return ! $is_post || $wc_lost_nonce;
				}

				return true;
			}

			if ( 'tutor_pro' === $plugin ) {
				/*
				 * Tutor Pro renders into wp-login.php by $GLOBALS['pagenow'] but
				 * verifies by the request URI containing 'wp-login.php'. Under a
				 * plugin that moves the login to a custom slug the two disagree,
				 * and deferring there would leave the form checked by nobody, so
				 * the theme keeps guarding unless both hold.
				 */
				$on_wp_login_url = $on_wp_login
					&& isset( $_SERVER['REQUEST_URI'] )
					&& false !== strpos( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), 'wp-login.php' );

				switch ( $form_id ) {
					// Tutor Pro checks wp-login.php requests by URL, Tutor forms by the
					// tutor_action field, and the wp-login.php login only with wp-submit.
					case 'wp_register':
						return $on_wp_login_url;

					case 'wp_login':
						// phpcs:ignore WordPress.Security.NonceVerification.Missing
						return $on_wp_login_url && ( ! $is_post || isset( $_POST['wp-submit'] ) );

					case 'tutor_register':
					case 'tutor_login':
					case 'tutor_lost_password':
						return ! $is_post || $tutor_action;
				}

				return false;
			}

			if ( 'hcaptcha' === $plugin ) {
				switch ( $form_id ) {
					// hCaptcha's WordPress modules act on wp-login.php only, and each
					// only for its own action (register / login / lostpassword - not
					// the retrievepassword alias WordPress also accepts).
					case 'wp_register':
						return $on_wp_login && 'register' === $wp_action;

					case 'wp_login':
						return $on_wp_login && (bool) did_action( 'login_form_login' );

					case 'wp_lost_password':
						return $on_wp_login && 'lostpassword' === $wp_action;

					case 'tutor_register':
						// Its Tutor register module gates on $_POST['tutor_action']
						// alone, so read it exactly where the module reads it.
						return ! $is_post || $tutor_post;

					case 'tutor_login':
						// Its login module acts only once Tutor's own handler has
						// run (it waits on the tutor_login_credentials filter).
						return ! $is_post || 'tutor_user_login' === $tutor_action;

					case 'tutor_lost_password':
						// Its lost-password module hooks a filter Tutor fires
						// inside that one handler and nowhere else.
						return ! $is_post || 'tutor_retrieve_password' === $tutor_action;

					case 'wc_lost_password':
						// hCaptcha's WooCommerce lost-password module keys on the field
						// WooCommerce dispatches on.
						return ! $is_post || isset( $_POST['wc_reset_password'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
				}

				return true;
			}

			return true;
		}

		/**
		 * @return array form_id => plugin slug (static part: plugin + option).
		 */
		protected function detect() {
			$guarded = array();

			if ( $this->is_hcaptcha_active() ) {
				$settings = $this->hcaptcha_settings();

				foreach ( self::HCAPTCHA_MAP as $form_id => $pair ) {
					$status = $settings ? $settings->get( $pair[0] ) : array();

					if ( is_array( $status ) && in_array( $pair[1], $status, true ) ) {
						$guarded[ $form_id ] = 'hcaptcha';
					}
				}

				// hCaptcha's "WooCommerce Lost Password" module also loads its
				// WordPress lost-password module (wp-login.php?action=lostpassword).
				if ( isset( $guarded['wc_lost_password'] ) && ! isset( $guarded['wp_lost_password'] ) ) {
					$guarded['wp_lost_password'] = 'hcaptcha';
				}
			}

			if ( $this->is_tutor_pro_recaptcha_usable() ) {
				$locations = $this->get_tutor_pro_locations();

				foreach ( self::TUTOR_PRO_MAP as $form_id => $location ) {
					if ( in_array( $location, $locations, true ) ) {
						$guarded[ $form_id ] = 'tutor_pro';
					}
				}
			}

			if ( $this->is_sct_active() ) {
				$woo = $this->is_plugin_active( 'woocommerce/woocommerce.php' );

				foreach ( self::SCT_MAP as $form_id => $option ) {
					if ( ! get_option( $option, 0 ) ) {
						continue;
					}

					if ( 0 === strpos( $form_id, 'wc_' ) && ! $woo ) {
						continue;
					}

					if ( 'comment' === $form_id && $this->is_plugin_active( 'wpdiscuz/class.WpdiscuzCore.php' ) ) {
						continue;
					}

					$guarded[ $form_id ] = 'sct';
				}
			}

			return $guarded;
		}

		/**
		 * @return array List of [ plugin label, form ids ] the theme defers to.
		 */
		public function get_deferred_summary() {
			if ( null === $this->guarded ) {
				$this->guarded = $this->detect();
			}

			$by_plugin = array();

			foreach ( $this->guarded as $form_id => $plugin ) {
				// Static view (plugin + option), independent of the current
				// admin request; only the site-level filter can veto it here.
				/** This filter is documented in plugin_guarding(). */
				if ( '' === (string) apply_filters( 'edumall_captcha_plugin_guarding', $plugin, $form_id ) ) {
					continue;
				}

				$by_plugin[ $plugin ][] = $form_id;
			}

			return $by_plugin;
		}

		/**
		 * @param string $plugin
		 *
		 * @return string
		 */
		public function get_plugin_label( $plugin ) {
			switch ( $plugin ) {
				case 'hcaptcha':
					return 'hCaptcha for WP';
				case 'sct':
					return 'Simple Cloudflare Turnstile';
				case 'tutor_pro':
					return 'Tutor Pro Fraud Protection';
			}

			return $plugin;
		}

		/**
		 * Register the hooks that keep other plugins away from the theme's own
		 * AJAX account forms.
		 */
		public function initialize() {
			/*
			 * Simple Cloudflare Turnstile verifies its token inside the global
			 * 'authenticate' filter, which the theme's AJAX login popup reaches
			 * through wp_signon(). It can never render its widget in the popup,
			 * so without this every popup login would fail. The theme CAPTCHA
			 * guards the popup itself when the Login form is enabled.
			 */
			add_filter( 'cfturnstile_wp_login_checks', array( $this, 'skip_sct_for_theme_ajax_login' ) );
		}

		/**
		 * @param bool $skip
		 *
		 * @return bool
		 */
		public function skip_sct_for_theme_ajax_login( $skip ) {
			if ( $skip || ! wp_doing_ajax() || ! class_exists( 'Edumall_Captcha' ) ) {
				return $skip;
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- read-only routing check; the login handler verifies its nonce.
			$action  = isset( $_POST['action'] ) && is_string( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';
			$captcha = Edumall_Captcha::instance();

			// Only when the theme guards the form itself; otherwise SCT's check
			// stays (and the admin notice explains why the popup then fails).
			if ( 'edumall_user_login' === $action ) {
				return $captcha->is_guarding( 'login' );
			}

			// The auto-login right after a registration the theme just verified.
			if ( in_array( $action, array( 'edumall_user_register', 'edumall_elementor_widget_user_register', 'edumall_instructor_register' ), true ) ) {
				return $captcha->is_guarding( 'register' );
			}

			return $skip;
		}
	}
}
