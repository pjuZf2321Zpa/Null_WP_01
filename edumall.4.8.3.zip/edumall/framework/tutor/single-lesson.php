<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Single_Lesson' ) ) {
	class Edumall_Single_Lesson {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Lesson-type singles render inside Tutor 4.0.0's Modern learning area — the
		 * plugin's own UI, a full document of its own or, with the Tutor LMS 4.0.8+ Header
		 * and Footer toggles on, wrapped in the theme header and footer (see
		 * Edumall_Tutor_Site_Shell). What remains here is the registration- and
		 * permalink-level behavior that still shapes those URLs; the old chrome hooks
		 * (spotlight body class, title bar, breadcrumb trail, complete-form gate, legacy
		 * lesson sidebar loader) only ever fired through the deleted legacy templates.
		 */
		public function initialize() {
			// Disable archive link for lessons.
			add_filter( 'register_post_type_args', [ $this, 'remove_archive_link' ], 11, 2 );

			add_filter( 'post_type_link', [ $this, 'fix_single_lessons_slug' ], 10, 2 );
		}

		/**
		 * Fix single lessons url
		 *
		 * @param     $post_link
		 * @param int $id
		 *
		 * @return string
		 *
		 * @see     \TUTOR\Rewrite_Rules::add_rewrite_rules();
		 * @see     \TUTOR\Rewrite_Rules::change_lesson_single_url();
		 * @see     \TUTOR_ASSIGNMENTS\Assignments::change_assignment_single_url();
		 *
		 * @since   2.8.0
		 * @version 3.7.1
		 */
		public function fix_single_lessons_slug( $post_link, $id = 0 ) {
			$post = get_post( $id );

			global $wpdb;

			$course_base_slug = 'sample-course';
			$course_post_type = tutor()->course_post_type;

			if ( is_object( $post ) ) {
				if ( Edumall_Tutor::instance()->is_course_lesson_type( $post->post_type ) ) {
					/**
					 * Fix Here:
					 * We should get post id instead of get meta of lesson types.
					 */
					/*$course_id = get_post_meta( $post->ID, '_tutor_course_id_for_assignments', true );*/
					$course_id             = Edumall_Tutor::instance()->get_course_id_by_lessons_id( $post->ID );
					$course_base_permalink = tutor_utils()->get_option( 'course_permalink_base', 'courses' );

					switch ( $post->post_type ) {
						case Edumall_Tutor::instance()->get_quiz_type():
							$lesson_base_permalink = tutor_utils()->get_option( 'quiz_permalink_base', 'quizzes' );
							break;
						case Edumall_Tutor::instance()->get_assignment_type():
							$lesson_base_permalink = tutor_utils()->get_option( 'assignment_permalink_base', 'assignments' );;
							break;
						case Edumall_Tutor::instance()->get_zoom_meeting_type():
							$lesson_base_permalink = 'zoom-lessons';
							break;
						case Edumall_Tutor::instance()->get_google_meet_type():
							$lesson_base_permalink = 'meet-lessons';
							break;
						default:
							$lesson_base_permalink = tutor_utils()->get_option( 'lesson_permalink_base', 'lessons' );
							break;
					}

					if ( $course_id ) {
						$course = $wpdb->get_row( $wpdb->prepare( "SELECT post_name FROM {$wpdb->posts} WHERE ID = %d", $course_id ) );
						if ( $course ) {
							$course_base_slug = $course->post_name;
						}

						return home_url( "/{$course_base_permalink}/{$course_base_slug}/{$lesson_base_permalink}/" . $post->post_name . '/' );
					} else {
						return home_url( "/{$course_base_permalink}/sample-course/{$lesson_base_permalink}/" . $post->post_name . '/' );
					}
				}
			}

			return $post_link;
		}

		public function remove_archive_link( $args, $post_type ) {
			if ( Edumall_Tutor::instance()->is_course_lesson_type( $post_type ) ) {
				$args['has_archive'] = false;
			}

			return $args;
		}

	}
}
