<?php
defined( 'ABSPATH' ) || exit;

/**
 * Tutor LMS pages rendered inside the theme header and footer (the plugin's "site shell").
 *
 * Tutor LMS 4.0.8 replaced Spotlight Mode with a Header and a Footer toggle for the
 * Learning Area and for the Dashboard (Tutor LMS > Settings > Design > Page Elements).
 * With a toggle on, the plugin opens or closes that area through get_header() /
 * get_footer() instead of a bare document of its own, so the area renders inside
 * #page.site, under the Edumall header. A site updated from Tutor LMS 4.0.5 or older with
 * Spotlight Mode off - the plugin default - gets both Learning Area toggles on without
 * anyone touching them.
 *
 * @since 4.8.1
 */
if ( ! class_exists( 'Edumall_Tutor_Site_Shell' ) ) {
	class Edumall_Tutor_Site_Shell {

		/**
		 * Body class of a page Tutor LMS renders inside the theme header and footer.
		 *
		 * @var string
		 */
		const BODY_CLASS = 'edumall-tutor-site-shell';

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			if ( ! $this->is_supported() ) {
				return;
			}

			add_filter( 'body_class', array( $this, 'body_class' ) );
			add_filter( 'theme_mod_header_sticky_enable', array( $this, 'disable_sticky_header' ) );
			add_filter( 'edumall_title_bar_type', array( $this, 'hide_learning_area_title_bar' ) );
		}

		/**
		 * Whether the active Tutor LMS has the per-area Header and Footer toggles.
		 *
		 * @return bool
		 */
		public function is_supported() {
			return class_exists( '\TUTOR\Template' ) && method_exists( '\TUTOR\Template', 'get_site_shell_data' );
		}

		/**
		 * The Header and Footer toggles of one Tutor LMS area, as the plugin resolves them.
		 *
		 * All false on a Tutor LMS without the toggles, which never prints its areas through
		 * the theme header and footer.
		 *
		 * @param string $context 'learning' or 'dashboard'.
		 *
		 * @return array{show_site_header: bool, show_site_footer: bool, has_site_shell: bool}
		 */
		public function get_shell( $context ) {
			$shell = array(
				'show_site_header' => false,
				'show_site_footer' => false,
				'has_site_shell'   => false,
			);

			if ( ! $this->is_supported() ) {
				return $shell;
			}

			return array_merge( $shell, (array) \TUTOR\Template::get_site_shell_data( $context ) );
		}

		/**
		 * The Tutor LMS area the current request renders with the plugin's own templates.
		 *
		 * @return string 'learning', 'dashboard', or '' for any other page.
		 */
		public function get_current_context() {
			$tutor = Edumall_Tutor::instance();

			if ( $tutor->is_native_learning_area() ) {
				return 'learning';
			}

			// The course builder is a document of its own whatever the toggles say.
			if ( $tutor->is_native_dashboard() && ! $tutor->is_create_course() ) {
				return 'dashboard';
			}

			return '';
		}

		/**
		 * Mark the pages Tutor LMS renders inside the theme header and footer, for the
		 * .site overflow override in style.css.
		 *
		 * @param string[] $classes Body classes.
		 *
		 * @return string[]
		 */
		public function body_class( $classes ) {
			$context = $this->get_current_context();

			if ( '' !== $context && $this->get_shell( $context )['has_site_shell'] ) {
				$classes[] = self::BODY_CLASS;
			}

			return $classes;
		}

		/**
		 * Let the Edumall header scroll away above the Learning Area and Dashboard.
		 *
		 * Both carry sticky bars of their own (course header and curriculum, dashboard
		 * header and sidebar), which Tutor LMS offsets by the theme header it finds on the
		 * page. A stuck Edumall header does not fit that: measured the plugin's way, it is
		 * the <header> that scrolls away, so the bar inside it that turns fixed covers the
		 * plugin's bars; measured on that bar, the plugin pads its whole area by the header
		 * height the moment the header sticks, and the content jumps. Scrolling away, the
		 * header leaves the plugin's bars at the top of the screen, as in its own
		 * full-page mode.
		 *
		 * @param mixed $enabled Sticky Header option value.
		 *
		 * @return mixed
		 */
		public function disable_sticky_header( $enabled ) {
			// A theme-wide option: leave it alone wherever it is edited rather than rendered
			// (editing the Dashboard page in wp-admin would pass the dashboard test below).
			if ( is_admin() ) {
				return $enabled;
			}

			$context = $this->get_current_context();

			if ( '' !== $context && $this->get_shell( $context )['show_site_header'] ) {
				return 0;
			}

			return $enabled;
		}

		/**
		 * Drop the title bar the theme header prints above the Learning Area.
		 *
		 * The Learning Area heads itself (back link, course title, progress), so the title
		 * bar only repeats the lesson title. Logged-out visitors keep it: they get the
		 * theme's login page (tutor/login.php) instead of the Learning Area.
		 *
		 * @param string $type Title bar type.
		 *
		 * @return string
		 */
		public function hide_learning_area_title_bar( $type ) {
			if ( is_user_logged_in() && Edumall_Tutor::instance()->is_native_learning_area() ) {
				return 'none';
			}

			return $type;
		}
	}
}
