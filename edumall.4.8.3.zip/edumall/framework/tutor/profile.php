<?php
defined( 'ABSPATH' ) || exit;

/**
 * Templates & hooks for Profile page.
 */
if ( ! class_exists( 'Edumall_Tutor_Profile' ) ) {
	class Edumall_Tutor_Profile {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_filter( 'body_class', [ $this, 'body_class' ] );
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ] );
			add_filter( 'edumall_top_bar_type', [ $this, 'hide_top_bar' ] );
			add_filter( 'edumall_header_type', [ $this, 'hide_header' ] );
			add_filter( 'edumall_title_bar_type', [ $this, 'hide_title_bar' ] );
			add_filter( 'edumall_footer', [ $this, 'hide_footer' ] );
			add_filter( 'edumall_sidebar_1', [ $this, 'hide_sidebar' ] );

			add_action( 'template_redirect', [ $this, 'handle_invalid_users' ], 100 );
			add_action( 'wp_footer', [ $this, 'add_public_profile_nav_template' ] );

			add_filter( 'tutor_user_social_icons', [ $this, 'change_social_icons' ] );

			add_filter( 'query_vars', [ $this, 'register_query_vars' ] );
			add_action( 'generate_rewrite_rules', [ $this, 'add_rewrite_rules' ] );
		}

		public function body_class( $classes ) {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				$classes[] = 'dashboard-page';

				if ( ! Edumall::is_handheld() ) {
					$classes[] = 'dashboard-nav-fixed';
				}
			}

			return $classes;
		}

		public function frontend_scripts() {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				wp_enqueue_script( 'edumall-grid-layout' );
			}
		}

		public function hide_top_bar( $type ) {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				return 'none';
			}

			return $type;
		}

		public function hide_header( $type ) {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				return 'none';
			}

			return $type;
		}

		public function hide_title_bar( $type ) {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				return 'none';
			}

			return $type;
		}

		public function hide_footer( $type ) {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				return 'none';
			}

			return $type;
		}

		public function hide_sidebar( $type ) {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				return 'none';
			}

			return $type;
		}

		/**
		 * Show 404 page if given profile not exist.
		 *
		 * @return string
		 */
		public function handle_invalid_users() {
			/**
			 * @var WP_Query $wp_query
			 */
			global $wp_query;

			if ( ! empty( $wp_query->query[ Edumall_Tutor::PROFILE_QUERY_VAR ] ) ) {
				$user = tutor_utils()->get_user_by_login( $wp_query->query[ Edumall_Tutor::PROFILE_QUERY_VAR ] );

				if ( empty( $user->ID ) ) {
					$wp_query->set_404();
					status_header( 404 );
					get_template_part( 404 );
					exit();
				}
			}
		}

		/**
		 * Update user profile social icons.
		 *
		 * @param $social_icons
		 *
		 * @return mixed
		 */
		/**
		 * Swap Tutor's profile social networks for the Edumall list.
		 *
		 * Tutor 4.0.0 consumes two keys the theme list predates:
		 *
		 *   - `svg_icon`, passed straight into SvgIcon::make()->name(), a strict `string`
		 *     parameter. A missing key means `null` and a fatal TypeError on the account
		 *     settings screen (dashboard/account/settings) — Tutor guards this with a
		 *     `?? Icon::GLOBE` fallback in user-profile.php but not in social-accounts.php.
		 *   - `pattern`, interpolated into the field's JS validation regex. A missing key
		 *     yields an empty `//i` that matches anything.
		 *
		 * They are filled in here rather than in Edumall_Helper, which is shared with the
		 * theme's own profile templates and knows nothing about Tutor. Networks added
		 * through the `edumall_user_social_networks` filter fall back to Tutor's globe icon
		 * and a permissive URL pattern, so a third-party network cannot fatal the page.
		 *
		 * @since 4.5.9
		 *
		 * @param array $social_icons Tutor's own social fields (discarded).
		 *
		 * @return array
		 */
		public function change_social_icons( $social_icons ) {
			/**
			 * Replace with theme social.
			 */
			$social_icons = Edumall_Helper::get_user_social_networks_support();

			// Icon names map to files in Tutor's assets/icons directory. Tutor ships no
			// Instagram or Pinterest glyph, so those reuse the generic globe.
			$svg_icons = array(
				'twitter'   => 'x',
				'facebook'  => 'facebook',
				'instagram' => 'globe',
				'linkedin'  => 'linkedin',
				'pinterest' => 'globe',
				'youtube'   => 'youtube',
				'github'    => 'github',
			);

			$patterns = array(
				'twitter'   => '^https?:\/\/(www\.)?(x\.com|twitter\.com)\/([A-Za-z0-9_]+)\/?$',
				'facebook'  => '^https?:\/\/(www\.|m\.|web\.|mobile\.)?facebook\.com\/([A-Za-z0-9._-]+)\/?$',
				'instagram' => '^https?:\/\/(www\.)?instagram\.com\/([A-Za-z0-9._]+)\/?$',
				'linkedin'  => '^https?:\/\/(www\.)?linkedin\.com\/(in|company|school)\/([A-Za-z0-9_-]+)\/?$',
				'pinterest' => '^https?:\/\/(www\.)?pinterest\.[A-Za-z.]{2,6}\/([A-Za-z0-9_-]+)\/?$',
				'youtube'   => '^https?:\/\/(www\.)?youtube\.com\/(@[A-Za-z0-9._-]+|channel\/[A-Za-z0-9_-]+|c\/[A-Za-z0-9_-]+|user\/[A-Za-z0-9_-]+)\/?$',
				'github'    => '^https?:\/\/(www\.)?github\.com\/([A-Za-z0-9_-]+)\/?$',
			);

			foreach ( $social_icons as $key => $social_icon ) {
				if ( ! isset( $social_icon['svg_icon'] ) ) {
					$social_icons[ $key ]['svg_icon'] = isset( $svg_icons[ $key ] ) ? $svg_icons[ $key ] : 'globe';
				}

				if ( ! isset( $social_icon['pattern'] ) ) {
					$social_icons[ $key ]['pattern'] = isset( $patterns[ $key ] ) ? $patterns[ $key ] : '^https?:\/\/.+$';
				}
			}

			return $social_icons;
		}

		/**
		 * @param $vars
		 *
		 * @return array
		 */
		public function register_query_vars( $vars ) {
			$vars[] = 'profile_sub_page';

			return $vars;
		}

		public function add_public_profile_nav_template() {
			if ( Edumall_Tutor::instance()->is_profile() ) {
				tutor_load_template( 'profile.navs' );
				edumall_load_template( 'off-canvas' );
			}
		}

		/**
		 * Route the profile sub-pages (/profile/<user>/<sub-page>).
		 *
		 * This rule is prepended, so it shadows Tutor's own single-segment
		 * `profile/(.+?)/?$` rule for two-segment URLs. It therefore has to set the same
		 * query var Tutor reads — `tutor_profile_username` (the value of
		 * Edumall_Tutor::PROFILE_QUERY_VAR). It used to set `tutor_student_username`, a
		 * var Tutor no longer registers as of 4.0.0, so WP dropped it and every sub-page
		 * stopped being recognised as a profile page.
		 *
		 * @param WP_Rewrite $wp_rewrite Rewrite object.
		 *
		 * @return WP_Rewrite
		 */
		public function add_rewrite_rules( $wp_rewrite ) {
			$new_rules = array(
				'profile/(.+?)/(.+?)/?$' => 'index.php?' . Edumall_Tutor::PROFILE_QUERY_VAR . '=' . $wp_rewrite->preg_index( 1 ) . '&profile_sub_page=' . $wp_rewrite->preg_index( 2 ),
			);

			$wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
		}
	}
}
