<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Courses' ) ) {
	class Edumall_Courses {
		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			/**
			 * Frontend Dashboard
			 */
			add_action( 'wp_ajax_edumall_delete_dashboard_course', [ $this, 'delete_dashboard_course' ] );

			// Fix Tag Name.
			add_filter( 'register_taxonomy_args', [ $this, 'fix_tax_tag_name' ], 99, 2 );
		}

		/**
		 * Added hook to prevent trash course.
		 *
		 * @see \TUTOR\Course::tutor_delete_dashboard_course()
		 *
		 * @return mixed|void
		 */
		public function delete_dashboard_course() {
			// Verify nonce to prevent CSRF.
			tutor_utils()->checking_nonce();

			$course_id = intval( $_POST['course_id'] ?? 0 );

			// Ensure the target post exists and is a course, not an arbitrary post/page.
			$post = get_post( $course_id );
			if ( ! $post || tutor()->course_post_type !== $post->post_type ) {
				wp_send_json_error( [ 'message' => __( 'Invalid course.', 'edumall' ) ] );
			}

			// Verify the current user owns or manages this course.
			if ( ! tutor_utils()->can_user_manage( 'course', $course_id ) ) {
				wp_send_json_error( [ 'message' => __( 'Access Denied', 'edumall' ) ] );
			}

			// Non-admins are subject to the "instructor can delete course" setting.
			if ( ! current_user_can( 'administrator' ) ) {
				if ( ! tutor_utils()->get_option( 'instructor_can_delete_course' ) ) {
					wp_send_json_error( [ 'message' => __( 'Access Denied', 'edumall' ) ] );
				}
			}

			/**
			 * Filters whether a post trashing should take place.
			 *
			 * @since 1.2.2
			 *
			 * @param bool|null $trash Whether to go forward with trashing.
			 * @param int       $course_id
			 */
			$check = apply_filters( 'edumall_pre_trash_course', null, $course_id );
			if ( null !== $check ) {
				return $check;
			}

			wp_trash_post( $course_id );
			wp_send_json_success( [ 'element' => 'course' ] );
		}

		public function fix_tax_tag_name( $args, $taxonomy ) {
			if ( $taxonomy === Edumall_Tutor::instance()->get_tax_tag() ) {
				$args['labels']['name'] = _x( 'Course Tags', 'taxonomy general name', 'edumall' );
			}

			return $args;
		}
	}
}
