<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Tutor_Custom_Css' ) ) {
	class Edumall_Tutor_Custom_Css {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_filter( 'edumall_customize_output_button_typography_selectors', [
				$this,
				'customize_output_button_typography_selectors',
			] );

			add_filter( 'edumall_customize_output_button_selectors', [
				$this,
				'customize_output_button_selectors',
			] );

			add_filter( 'edumall_customize_output_button_hover_selectors', [
				$this,
				'customize_output_button_hover_selectors',
			] );

			// Keep Tutor LMS 4.0.0's appearance in sync with the Edumall Site Skin: feed
			// the primary color into Tutor's brand palette + follow the light/dark skin.
			add_filter( 'option_tutor_option', array( $this, 'sync_tutor_appearance' ) );
			add_filter( 'language_attributes', array( $this, 'force_tutor_theme_attribute' ), 999 );
		}

		/**
		 * Force Tutor's data-tutor-theme (light/dark) to follow the Edumall Site Skin.
		 *
		 * Tutor 4.0.0 stamps `data-tutor-theme` on <html> for its dashboard & learning
		 * area from a per-user preference (seeded from the `default_theme` option). That
		 * can drift from the Edumall Site Skin — e.g. Site Skin = Dark but Tutor still
		 * renders light — leaving a white surface with light (faded) text. When the theme
		 * locks the skin (Allow User's Site Skin = No) we overwrite the attribute so the
		 * native Tutor UI renders in the same mode as the rest of the site. The attribute
		 * only exists on dashboard/learning-area pages, so other pages are untouched.
		 *
		 * @since 4.5.9
		 *
		 * @param string $output The <html> language attributes string.
		 *
		 * @return string
		 */
		public function force_tutor_theme_attribute( $output ) {
			if ( ! class_exists( 'Edumall' ) || false === strpos( $output, 'data-tutor-theme' ) ) {
				return $output;
			}

			// Respect a per-user skin choice when the theme allows it.
			if ( '1' === (string) Edumall::setting( 'allows_user_custom_site_skin' ) ) {
				return $output;
			}

			// Resolve the skin through the canonical getter (set on `wp`, which runs before
			// language_attributes) so the edumall_site_skin filter is honored, same as every
			// other theme surface.
			$site_skin = class_exists( 'Edumall_Global' )
				? Edumall_Global::instance()->get_site_skin()
				: (string) Edumall::setting( 'site_skin', 'light' );

			$theme = ( 'dark' === $site_skin ) ? 'dark' : 'light';

			return preg_replace( '/data-tutor-theme="[^"]*"/', 'data-tutor-theme="' . $theme . '"', $output );
		}

		/**
		 * Keep Tutor LMS 4.0.0's appearance consistent with the Edumall theme.
		 *
		 * Two syncs, both only applied when the admin has NOT made an explicit choice:
		 *
		 * 1. `default_theme` -> follows the Edumall "Site Skin" Customizer setting
		 *    (site_skin = light|dark). Tutor 4.0.0 defaults its appearance to 'system'
		 *    (it follows the visitor's OS via `data-tutor-theme` + prefers-color-scheme)
		 *    and its native surfaces ignore Edumall's own dark/light chrome, so without
		 *    this the two clash — e.g. a dark Edumall skin around light Tutor content.
		 *    Mapping the skin onto Tutor's appearance keeps both in the same mode.
		 *
		 * 2. `brand_color` -> Edumall primary. Tutor 4.0.0 generates its whole
		 *    `--tutor-brand-*` ramp (consumed by the redesigned learning area/dashboard,
		 *    which do NOT read the legacy `--tutor-color-primary` the theme injects) from
		 *    the single `brand_color` option — see TUTOR\Assets::load_core_color_palette().
		 *    Feeding it the theme primary lets Tutor build the ramp itself, surviving
		 *    plugin updates instead of drifting against copied markup.
		 *
		 * @since 4.5.9
		 *
		 * @param mixed $option Stored `tutor_option` value (array when present).
		 *
		 * @return mixed
		 */
		public function sync_tutor_appearance( $option ) {
			static $primary_color = null;
			static $site_skin     = null;

			if ( ! is_array( $option ) ) {
				return $option;
			}

			// Never sync in admin context. Tutor's settings screen populates its form from
			// this (filtered) option and its AJAX save (admin-ajax, so is_admin() is true)
			// persists the whole posted form — with the filter active there, the synced
			// values would be written to the DB as if the admin had chosen them, freezing
			// the sync forever. The sync only matters where the palette is rendered: the
			// front end.
			if ( is_admin() ) {
				return $option;
			}

			// 1. Match Tutor's appearance to the Edumall Site Skin, unless the admin
			//    explicitly picked a Tutor appearance. Memoize only a resolved value so a
			//    read before theme settings are ready simply skips and a later read resolves.
			if ( ! isset( $option['default_theme'] ) || '' === $option['default_theme'] ) {
				if ( null === $site_skin ) {
					$resolved_skin = class_exists( 'Edumall' ) ? (string) Edumall::setting( 'site_skin', 'light' ) : '';

					if ( '' !== $resolved_skin ) {
						$site_skin = $resolved_skin;
					}
				}

				if ( 'dark' === $site_skin || 'light' === $site_skin ) {
					$option['default_theme'] = $site_skin;
				}
			}

			// 2. Mirror the Edumall primary into Tutor's brand color unless the admin picked
			//    one. Two traps here:
			//      * \TUTOR\Utils::get_brand_color() reads the legacy `tutor_primary_color`
			//        key FIRST and only falls back to `brand_color`, so writing `brand_color`
			//        on its own is a silent no-op.
			//      * \TUTOR\Assets skips the whole --tutor-brand-* ramp when the brand color
			//        equals Tutor's own default, so that default has to count as "not chosen"
			//        — otherwise every native button keeps Tutor's fallback indigo.
			$default_brand = class_exists( '\TUTOR\Options_V2' ) ? \TUTOR\Options_V2::DEFAULT_BRAND_COLOR : '#3e64de';

			$current_brand = '';
			if ( ! empty( $option['tutor_primary_color'] ) ) {
				$current_brand = (string) $option['tutor_primary_color'];
			} elseif ( ! empty( $option['brand_color'] ) ) {
				$current_brand = (string) $option['brand_color'];
			}

			$has_admin_brand = '' !== $current_brand && 0 !== strcasecmp( $current_brand, $default_brand );

			if ( ! $has_admin_brand ) {
				if ( null === $primary_color ) {
					$resolved = class_exists( 'Edumall' ) ? (string) Edumall::setting( 'primary_color', Edumall::PRIMARY_COLOR ) : '';

					// Cache only a real color so an early read (before theme settings are
					// ready) does not memoize an empty value for the whole request.
					if ( '' !== $resolved ) {
						$primary_color = $resolved;
					}
				}

				if ( is_string( $primary_color ) && '' !== $primary_color ) {
					// The legacy key is the one get_brand_color() actually reads; keep the
					// modern key in sync for when Tutor eventually drops the legacy one.
					$option['tutor_primary_color'] = $primary_color;
					$option['brand_color']         = $primary_color;
				}
			}

			return $option;
		}

		/**
		 * Button Customizer selectors.
		 *
		 * `.tutor-btn` is Tutor LMS 4.0.0's own button and is deliberately absent from all
		 * three lists. Painting it from the Customizer would push the theme's full button
		 * box model onto it (background, border, hover background, font size/weight/spacing)
		 * and break the plugin's own sizing and hover states. Only the two things the theme
		 * should own reach it, and both travel through Tutor's own CSS variables instead of
		 * a selector fight:
		 *
		 *   - font-family: `.tutor-btn` is `font-family: inherit` and Tutor applies
		 *     `--tutor-font-family-body`, which Edumall_Custom_Css sets from the theme font.
		 *   - color: Tutor derives `--tutor-button-primary` from its brand color, which
		 *     sync_tutor_appearance() above sets from the Edumall primary.
		 *
		 * `.tutor-button` is the legacy 3.x class. Tutor 4.0.0 ships no CSS for it at all
		 * while Edumall templates (login form, student registration) still emit it, so the
		 * theme keeps full ownership of that one.
		 *
		 * @since 4.5.9
		 *
		 * @param array $selectors Existing selectors.
		 *
		 * @return array
		 */
		public function customize_output_button_typography_selectors( $selectors ) {
			$new_selectors = [ '.single_add_to_cart_button, a.tutor-button, .tutor-button' ];

			$final_selectors = array_merge( $selectors, $new_selectors );

			return $final_selectors;
		}

		public function customize_output_button_selectors( $selectors ) {
			$new_selectors = [ '.single_add_to_cart_button, a.tutor-button, .tutor-button, .tutor-button.tutor-success' ];

			$final_selectors = array_merge( $selectors, $new_selectors );

			return $final_selectors;
		}

		public function customize_output_button_hover_selectors( $selectors ) {
			$new_selectors = [ '.single_add_to_cart_button:hover, a.tutor-button:hover, .tutor-button:hover, .tutor-button.tutor-success:hover' ];

			$final_selectors = array_merge( $selectors, $new_selectors );

			return $final_selectors;
		}
	}
}
