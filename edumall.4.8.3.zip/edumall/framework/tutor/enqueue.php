<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Tutor_Enqueue' ) ) {
	class Edumall_Tutor_Enqueue {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ], 11 );
		}

		public function frontend_scripts() {
			$min = Edumall_Enqueue::instance()->get_min_suffix();
			$rtl = Edumall_Enqueue::instance()->get_rtl_suffix();

			/*wp_dequeue_style( 'tutor' );
			wp_dequeue_style( 'tutor-frontend' );
			wp_dequeue_style( 'tutor-course-builder-css' );*/

			// Disable social share on all pages then add it for single course only.
			wp_dequeue_script( 'tutor-social-share' );

			wp_register_script( 'edumall-course-archive', EDUMALL_THEME_ASSETS_URI . "/js/tutor/archive{$min}.js", [ 'jquery' ], EDUMALL_THEME_VERSION, true );
			wp_register_script( 'edumall-course-single', EDUMALL_THEME_ASSETS_URI . "/js/tutor/single{$min}.js", [ 'jquery' ], EDUMALL_THEME_VERSION, true );

			wp_register_style( 'edumall-tutor', EDUMALL_THEME_URI . "/tutor-lms{$rtl}{$min}.css", null, EDUMALL_THEME_VERSION );

			// On Tutor LMS 4.0.0 the dashboard renders with the plugin's own native
			// templates & CSS. The theme's legacy tutor-lms.css targets the same
			// .tutor-dashboard-* classes and overrides the redesigned layout, so skip it
			// (and the legacy dashboard JS) on the dashboard only — it still loads on
			// single course, archive, Elementor course cards, etc.
			//
			// Only the logged-in dashboard renders that native UI: a logged-out visitor gets
			// the login template, which the theme still overrides (.user-form-box markup) and
			// styles from tutor-lms.css — so the theme CSS has to stay on that page.
			$edumall_native_dashboard = Edumall_Tutor::instance()->is_native_dashboard();

			// Same deal for the 4.0.0 learning area (lesson/quiz/assignment/zoom singles +
			// course?subpage): it is native UI, a full-page document of its own or wrapped in
			// the theme header and footer (Tutor LMS 4.0.8+ toggles), neither of which needs
			// tutor-lms.css. Logged-out visitors are the exception — without content access the
			// theme's own login template renders inside that document and needs its styling.
			$edumall_native_learning_area = Edumall_Tutor::instance()->is_native_learning_area();

			if ( ! $edumall_native_dashboard && ! ( $edumall_native_learning_area && is_user_logged_in() ) ) {
				wp_enqueue_style( 'edumall-tutor' );
			}

			if ( Edumall_Tutor::instance()->is_create_course() ) {
				wp_enqueue_style( 'edumall-tutor-course-builder', EDUMALL_THEME_URI . "/tutor-lms-course-builder{$rtl}{$min}.css", null, EDUMALL_THEME_VERSION );
			}

			$wishlist_dependency = [];
			if ( ! is_user_logged_in() ) {
				$wishlist_dependency[] = 'edumall-login';
			}
			wp_register_script( 'edumall-course-general', EDUMALL_THEME_ASSETS_URI . "/js/tutor/general{$min}.js", $wishlist_dependency, EDUMALL_THEME_VERSION, true );

			wp_enqueue_script( 'edumall-course-general' );

			$js_variables = array(
				'addedText' => esc_html__( 'Remove from wishlist', 'edumall' ),
				'addText'   => esc_html__( 'Add to wishlist', 'edumall' ),
			);
			wp_localize_script( 'edumall-course-general', '$edumallCourseWishlist', $js_variables );

			if ( Edumall_Tutor::instance()->is_category() ) {
				wp_enqueue_script( 'edumall-tab-panel' );
			}

			if ( Edumall_Tutor::instance()->is_course_listing() ) {
				wp_enqueue_script( 'edumall-common-archive' );
				wp_enqueue_script( 'edumall-course-archive' );
			}

			// Learning-area subpage URLs (course + ?subpage) also satisfy is_single_course(),
			// but they render the native document where none of these theme scripts have a
			// target element.
			if ( Edumall_Tutor::instance()->is_single_course() && ! $edumall_native_learning_area ) {
				wp_enqueue_script( 'tutor-social-share' );

				wp_enqueue_script( 'edumall-course-single' );

				wp_enqueue_script( 'sticky-kit' );
			}

			if ( Edumall_Tutor::instance()->is_single_course_bundle() ) {
				wp_enqueue_script( 'tutor-social-share' );
			}
		}
	}
}
