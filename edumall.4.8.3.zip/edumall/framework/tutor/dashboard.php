<?php
defined( 'ABSPATH' ) || exit;

/**
 * Templates & hooks for Dashboard page.
 */
if ( ! class_exists( 'Edumall_Tutor_Dashboard' ) ) {
	class Edumall_Tutor_Dashboard {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_filter( 'body_class', [ $this, 'body_class' ] );
			add_filter( 'edumall_top_bar_type', [ $this, 'hide_top_bar' ] );
			add_filter( 'edumall_header_type', [ $this, 'hide_header' ] );
			add_filter( 'edumall_title_bar_type', [ $this, 'hide_title_bar' ] );
			add_filter( 'edumall_footer', [ $this, 'hide_footer' ] );
			add_filter( 'edumall_sidebar_1', [ $this, 'hide_sidebar' ] );

			// Edumall visual skin for the native Tutor 4.0.0 dashboard.
			add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_dashboard_skin' ], 100 );

			/**
			 * WPML compatible
			 *
			 * @since 2.10.0
			 */
			add_filter( 'tutor_dashboard_page_id', [ $this, 'wpml_translation_page_id' ] );
			add_filter( 'tutor_dashboard_page_id_filter', [ $this, 'wpml_translation_page_id' ] );
			add_filter( 'generate_rewrite_rules', [ $this, 'add_rewrite_rules' ] );

			/**
			 * Add custom link to Dashboard menu
			 *
			 * @since 2.7.4
			 */
			add_filter( 'tutor_dashboard/instructor_nav_items', [ $this, 'add_my_students_nav_item' ] );
		}

		public function wpml_translation_page_id( $student_dashboard_page_id ) {
			if ( function_exists( 'wpml_object_id_filter' ) ) {
				$student_dashboard_page_id = wpml_object_id_filter( $student_dashboard_page_id );
			}

			return $student_dashboard_page_id;
		}

		/**
		 * Support wpml for dashboard page.
		 *
		 * @see \TUTOR\Rewrite_Rules::add_rewrite_rules()
		 *
		 * @param \WP_Rewrite $wp_rewrite
		 *
		 * @return \WP_Rewrite $wp_rewrite
		 */
		public function add_rewrite_rules( $wp_rewrite ) {
			global $sitepress;

			if ( $sitepress instanceof SitePress ) {
				// Student Dashboard URL.
				$dashboard_pages   = tutor_utils()->tutor_dashboard_permalinks();
				$dashboard_page_id = (int) tutor_utils()->get_option( 'tutor_dashboard_page_id' );

				$trid         = $sitepress->get_element_trid( $dashboard_page_id, 'post_page' );
				$translations = $sitepress->get_element_translations( $trid, 'post_page' );

				foreach ( $translations as $lang_code => $translation ) {
					$translate_page_id = $translation->element_id;

					$dashboard_page_slug = get_post_field( 'post_name', $translate_page_id );

					foreach ( $dashboard_pages as $dashboard_key => $dashboard_page ) {
						$new_rules["({$dashboard_page_slug})/{$dashboard_key}/?$"] = 'index.php?pagename=' . $wp_rewrite->preg_index( 1 ) . '&tutor_dashboard_page=' . $dashboard_key;

						// Sub Page of dashboard sub page.
						//regext = ([^/]*)
						$new_rules["({$dashboard_page_slug})/{$dashboard_key}/(.+?)/?$"] = 'index.php?pagename=' . $wp_rewrite->preg_index( 1 ) . '&tutor_dashboard_page=' . $dashboard_key . '&tutor_dashboard_sub_page=' . $wp_rewrite->preg_index( 2 );

						$wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
					}
				}
			}

			return $wp_rewrite;
		}

		/**
		 * Edumall visual skin for Tutor LMS 4.0.0's native dashboard.
		 *
		 * The dashboard renders with Tutor's own templates + CSS; brand color, font and
		 * text color already come from the theme's :root tokens. This layers the small set
		 * of Edumall refinements that tokens can't express (e.g. the solid brand-color
		 * active nav item) as inline CSS on a dedicated handle that depends on Tutor's
		 * dashboard styles, so it loads only on the dashboard and wins the cascade.
		 *
		 * @since 4.5.9
		 *
		 * @return void
		 */
		public function enqueue_dashboard_skin() {
			if ( ! Edumall_Tutor::instance()->is_native_dashboard() ) {
				return;
			}

			// Load the skin AFTER Tutor's own dashboard styles so its overrides win the
			// cascade, without depending on any single Tutor handle being present.
			$deps = array();
			foreach ( array( 'tutor-core', 'tutor-frontend', 'tutor-dashboard' ) as $tutor_handle ) {
				if ( wp_style_is( $tutor_handle, 'registered' ) || wp_style_is( $tutor_handle, 'enqueued' ) ) {
					$deps[] = $tutor_handle;
				}
			}

			$handle = 'edumall-tutor-dashboard-skin';
			wp_register_style( $handle, false, $deps, EDUMALL_THEME_VERSION );
			wp_enqueue_style( $handle );

			// !important is used throughout so this thin skin wins over Tutor's own
			// dashboard rules regardless of load order.
			$skin = '
				/* Edumall 5px roundness. --tutor-button-radius lives in the global :root
				   (Edumall_Custom_Css) so Tutor buttons match on every page, not just here. */
				:root {
					--tutor-input-radius: 5px !important;
					--tutor-tab-radius: 5px !important;
					--tutor-tab-radius-sm: 5px !important;
					--tutor-modal-radius: 5px !important;
					--tutor-popover-radius: 5px !important;
					--tutor-toast-radius: 5px !important;
				}
				.tutor-card,
				.tutor-dashboard-header,
				.tutor-dashboard-sidebar-nav ul li a {
					border-radius: 5px !important;
				}
				/* Brand-colored nav icons (they use fill:currentColor, so drive them with
				   color; forcing fill would flatten multi-path icons into solid blocks). */
				.tutor-dashboard-sidebar-nav ul li a svg {
					color: var(--edumall-color-primary) !important;
				}
				.tutor-dashboard-sidebar-nav ul li a.active {
					background-color: var(--edumall-color-primary) !important;
					color: #fff !important;
				}
				.tutor-dashboard-sidebar-nav ul li a.active svg {
					color: #fff !important;
				}
				.tutor-dashboard-sidebar-nav ul li a.active svg [stroke] {
					stroke: var(--edumall-color-primary) !important;
				}
				/* My Students has only an outline (stroke) icon, no -fill variant, so on the
				   active pill its strokes must stay white; the fill-icon rule above would turn
				   them brand-colored (invisible on the brand pill). Extra class raises the
				   specificity so this wins among the !important rules. */
				.tutor-dashboard-sidebar-nav .tutor-dashboard-menu-my-students a.active svg [stroke] {
					stroke: #fff !important;
				}

				/* My Students page: theme template inside the native dashboard. This is the
				   single source for these styles (the old tutor-lms.css copy never loaded
				   here). Colors read the theme tokens with literal fallbacks, since not
				   every token is defined on :root yet. */
				.dashboard-my-students-table,
				.dashboard-my-student-courses-table {
					margin-top: 20px;
					background: var(--edumall-color-box-fill-background, #fff);
					border-radius: 10px;
					border: 1px solid var(--edumall-color-box-fill-separator, #e8e8e8);
					overflow: hidden;
				}
				.dashboard-my-students-table .student-info {
					display: flex;
					align-items: center;
					gap: 14px;
				}
				.dashboard-my-students-table .student-avatar {
					width: 48px;
					height: 48px;
					border-radius: 50%;
					flex-shrink: 0;
					overflow: hidden;
				}
				.dashboard-my-students-table .student-avatar img {
					border-radius: 50%;
					width: 48px;
					height: 48px;
					object-fit: cover;
				}
				.dashboard-my-students-table .student-name {
					font-size: 15px;
					line-height: 1.4;
					font-weight: 600;
					margin: 0;
					color: var(--edumall-color-heading, inherit);
				}
				.dashboard-my-students-table .dashboard-table {
					border: 0;
					margin: 0;
					width: 100%;
					table-layout: auto;
				}
				.dashboard-my-students-table .dashboard-table th {
					background: var(--edumall-color-box-fill-light-background, #f4f9ff);
					font-size: 13px;
					font-weight: 600;
					text-transform: uppercase;
					letter-spacing: 0.03em;
					color: var(--edumall-color-text-lighten, #8b8b8b);
					padding: 14px 24px;
					border: 0;
					text-align: start;
				}
				.dashboard-my-students-table .dashboard-table td {
					padding: 16px 24px;
					vertical-align: middle;
					border: 0;
					text-align: start;
					background: var(--edumall-color-box-fill-background, #fff);
				}
				.dashboard-my-students-table .dashboard-table tr+tr {
					border-top: 1px solid var(--edumall-color-box-fill-separator, #e8e8e8);
				}
				.dashboard-my-students-table .td-student-actions {
					text-align: end;
				}
				.dashboard-my-students-table .td-student-actions a {
					display: inline-flex;
					align-items: center;
					gap: 6px;
					margin: 4px;
					border: 1px solid var(--edumall-color-box-fill-separator, #e8e8e8);
					border-radius: 6px;
					padding: 6px 16px;
					font-size: 13px;
					font-weight: 500;
					line-height: 1.4;
					color: var(--edumall-color-text-bit-lighten, #666);
					transition: all 0.2s ease;
				}
				.dashboard-my-students-table .td-student-actions a i {
					font-size: 14px;
				}
				.dashboard-my-students-table .td-student-actions a:hover {
					color: #fff;
					border-color: var(--edumall-color-primary, #3b82f6);
					background: var(--edumall-color-primary, #3b82f6);
				}
				.dashboard-my-student-courses-table .col-course-info {
					width: 470px;
				}
				.dashboard-my-student-courses-table .course-info {
					display: flex;
					align-items: center;
					gap: 14px;
				}
				.dashboard-my-student-courses-table .course-thumbnail {
					width: 60px;
					flex-shrink: 0;
					border-radius: 6px;
					overflow: hidden;
				}
				.dashboard-my-student-courses-table .course-title {
					font-size: 15px;
					line-height: 1.4;
					font-weight: 600;
					margin: 0;
					color: var(--edumall-color-heading, inherit);
				}
			' . $this->dashboard_logo_css();

			wp_add_inline_style( $handle, $skin );
		}

		/**
		 * CSS that swaps Tutor's native sidebar logo (WP core custom_logo / site title,
		 * which Edumall does not use) for the Edumall logo. Done via CSS so it works
		 * whether the theme stores its logo as an attachment id or a bare URL.
		 *
		 * @since 4.5.9
		 *
		 * @return string
		 */
		private function dashboard_logo_css() {
			if ( ! class_exists( 'Edumall' ) ) {
				return '';
			}

			// On a dark skin prefer the light logo (and vice-versa) so it stays visible.
			// Resolve the skin through the canonical getter so the edumall_site_skin
			// filter is honored, same as every other theme surface.
			$is_dark    = class_exists( 'Edumall_Global' ) && 'dark' === Edumall_Global::instance()->get_site_skin();
			$logo_order = $is_dark ? array( 'logo_light', 'logo_dark' ) : array( 'logo_dark', 'logo_light' );

			$logo_url = '';
			foreach ( $logo_order as $logo_setting ) {
				$logo_url = Edumall::get_logo_setting_url( $logo_setting );

				if ( '' !== $logo_url ) {
					break;
				}
			}

			if ( '' === $logo_url ) {
				return '';
			}

			// Keep Tutor's native logo container (80px tall + bottom border that lines up
			// with the dashboard header) and only drop the Edumall logo in as a centered
			// background at a fixed height so it does not blow up to the container size.
			return '
				.tutor-dashboard-sidebar-logo {
					background: url(' . esc_url( $logo_url ) . ') center / auto 34px no-repeat !important;
				}
				.tutor-dashboard-sidebar-logo .site-title,
				.tutor-dashboard-sidebar-logo img {
					display: none !important;
				}
			';
		}

		public function add_my_students_nav_item( $nav_items ) {
			// 'student' maps to Tutor's Icon::STUDENT (student.svg). Used as a bare string
			// so a future icon rename degrades to an empty glyph instead of a fatal. There
			// is no -fill variant, so the active state reuses the same outline (the sidebar
			// falls back to `icon` when `active_icon` is absent) and the dashboard skin
			// keeps its strokes white on the active pill.
			$nav_items['my-students'] = array(
				'title'       => __( 'My Students', 'edumall' ),
				'icon'        => 'student',
				'active_icon' => 'student',
				'auth_cap'    => tutor()->instructor_role,
			);

			return $nav_items;
		}

		public function body_class( $classes ) {
			global $wp_query;

			$dashboard_page_slug = '';
			$dashboard_page_name = '';
			if ( isset( $wp_query->query_vars['tutor_dashboard_page'] ) && $wp_query->query_vars['tutor_dashboard_page'] ) {
				$dashboard_page_slug = $wp_query->query_vars['tutor_dashboard_page'];
				$dashboard_page_name = $wp_query->query_vars['tutor_dashboard_page'];
			}

			/**
			 * Getting dashboard sub pages
			 */
			if ( isset( $wp_query->query_vars['tutor_dashboard_sub_page'] ) && $wp_query->query_vars['tutor_dashboard_sub_page'] ) {
				if ( ! empty( $dashboard_page_slug ) ) {
					$dashboard_page_slug = $dashboard_page_slug . '-' . $wp_query->query_vars['tutor_dashboard_sub_page'];
				}
			}

			if ( Edumall_Tutor::instance()->is_dashboard() ) {
				$classes[] = "dashboard-{$dashboard_page_slug}-page";

				if ( is_user_logged_in() && 'create-course' !== $dashboard_page_name ) {
					$classes[] = 'dashboard-page';

					if ( ! Edumall::is_handheld() ) {
						$classes[] = 'dashboard-nav-fixed';
					}
				}
			}

			return $classes;
		}

		public function hide_top_bar( $type ) {
			if ( $this->hides_theme_chrome( 'show_site_header' ) ) {
				return 'none';
			}

			return $type;
		}

		public function hide_header( $type ) {
			if ( $this->hides_theme_chrome( 'show_site_header' ) ) {
				return 'none';
			}

			return $type;
		}

		public function hide_title_bar( $type ) {
			if ( Edumall_Tutor::instance()->is_dashboard() ) {
				if ( is_user_logged_in() ) {
					return 'none';
				} else {
					return '05';
				}
			}

			if( Edumall_Tutor::instance()->is_student_registration_page() ) {
				return '05';
			}

			return $type;
		}

		public function hide_footer( $type ) {
			if ( $this->hides_theme_chrome( 'show_site_footer' ) ) {
				return 'none';
			}

			return $type;
		}

		/**
		 * Whether the logged-in dashboard drops the theme header (and top bar) or footer.
		 *
		 * The dashboard carries its own navigation, so the theme chrome stays off it - unless
		 * the Tutor LMS 4.0.8+ Header or Footer toggle for the dashboard is on (Settings >
		 * Design > Page Elements). The plugin then prints the dashboard through get_header() /
		 * get_footer() precisely to show them, and it drops its own sidebar logo along with a
		 * shown header, so hiding the header here would leave the page without a logo.
		 *
		 * @since 4.8.1
		 *
		 * @param string $toggle 'show_site_header' or 'show_site_footer'.
		 *
		 * @return bool
		 */
		private function hides_theme_chrome( $toggle ) {
			if ( ! Edumall_Tutor::instance()->is_dashboard() || ! is_user_logged_in() ) {
				return false;
			}

			$shell = Edumall_Tutor_Site_Shell::instance()->get_shell( 'dashboard' );

			return empty( $shell[ $toggle ] );
		}

		public function hide_sidebar( $type ) {
			if ( Edumall_Tutor::instance()->is_dashboard() && is_user_logged_in() ) {
				return 'none';
			}

			return $type;
		}
	}
}
