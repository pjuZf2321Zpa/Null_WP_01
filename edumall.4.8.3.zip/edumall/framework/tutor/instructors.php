<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Tutor_Instructors' ) ) {
	class Edumall_Tutor_Instructors {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function initialize() {
			add_filter( 'template_include', [ $this, 'template_instructors' ] );

			add_filter( 'body_class', [ $this, 'body_class' ] );

			add_filter( 'tutor/options/extend/attr', [ $this, 'add_instructor_setting' ] );

			add_action( 'tutor_option_save_after', [ $this, 'instructor_role_manage' ] );

			// Self-heal sites where an older version stored explicit-denial caps on the
			// Instructor role, which locked out admins that also hold the Instructor role.
			add_action( 'admin_init', [ $this, 'maybe_heal_instructor_cpt_caps' ] );
		}

		/**
		 * Custom post type capabilities that follow the "Manage Custom Post Type" setting.
		 *
		 * Keyed by post type slug so the value matches the keys stored in the
		 * `instructor_manage_cpt` option.
		 *
		 * @return array<string, string[]>
		 */
		protected function get_managed_cpt_caps() {
			return [
				Edumall_FAQ::instance()->get_post_type() => [
					'edit_faq',
					'read_faq',
					'delete_faq',
					'edit_faqs',
					'publish_faqs',
					'read_private_faqs',
				],
				Edumall_Event::instance()->get_event_type() => [
					'edit_tp_event',
					'read_tp_event',
					'delete_tp_event',
					'edit_tp_events',
					'edit_others_tp_events',
					'publish_tp_events',
					'read_private_tp_events',
					'delete_tp_events',
				],
			];
		}

		public function template_instructors( $template ) {
			if ( Edumall_Tutor::instance()->is_instructors_page() ) {
				$template = tutor_get_template( 'instructors' );
			}

			return $template;
		}

		public function body_class( $classes ) {
			if ( Edumall_Tutor::instance()->is_instructors_page() ) {
				$classes[] = ' instructors-page';
			}

			return $classes;
		}

		public function add_instructor_setting( $setting ) {
			$pages = tutor_utils()->get_pages();

			$cpts = array(
				'faq'      => __( 'FAQs', 'edumall' ),
				'tp_event' => __( 'Events', 'edumall' ),
			);

			$new_setting_fields = [
				[
					'key'         => 'instructor_register_immediately',
					'type'        => 'toggle_switch',
					'label'       => __( 'Become Instructor Immediately', 'edumall' ),
					'label_title' => '',
					'default'     => 'off',
					'desc'        => __( 'Enabling this feature will make user become Instructor immediately without review from Admin.', 'edumall' ),
				],
				[
					'key'     => 'instructor_manage_cpt',
					'type'    => 'checkbox_horizontal',
					'label'   => __( 'Manage Custom Post Type', 'edumall' ),
					'options' => $cpts,
					'desc'    => __( 'Allows instructors manage custom post types.', 'edumall' ),
				],
				[
					'key'     => 'instructor_listing_page',
					'type'    => 'select',
					'label'   => __( 'Instructor Listing Page', 'edumall' ),
					'default' => '0',
					'options' => $pages,
					'desc'    => __( 'This page will be used to show all approved instructors', 'edumall' ),
				],
				[
					'key'     => 'instructors_per_page',
					'type'    => 'number',
					'label'   => __( 'Pagination', 'edumall' ),
					'default' => '12',
					'desc'    => __( 'Number of instructors you would like displayed "per page" in the pagination', 'edumall' ),
				],
			];

			$general_blocks = $setting['general']['blocks'];

			foreach ( $general_blocks as $key => $general_block ) {
				if ( 'instructor' === $general_block['slug'] ) {
					$setting['general']['blocks'][ $key ]['fields'] = array_merge( $general_block['fields'], $new_setting_fields );

					break;
				}
			}

			return $setting;
		}

		public function instructor_role_manage() {
			$instructor = get_role( tutor()->instructor_role );

			if ( ! $instructor ) {
				return;
			}

			$cpt_allowed         = tutor_utils()->get_option( 'instructor_manage_cpt' );
			$default_cpt_allowed = [
				'tp_event' => '',
				'faq'      => '',
			];

			$cpt_allowed  = wp_parse_args( $cpt_allowed, $default_cpt_allowed );
			$managed_caps = $this->get_managed_cpt_caps();

			foreach ( $cpt_allowed as $cpt_name => $allowed ) {
				if ( ! isset( $managed_caps[ $cpt_name ] ) ) {
					continue;
				}

				$grant = ( '1' === $allowed || $allowed === $cpt_name ); // Tutor v2 stores the option key as the value.

				foreach ( $managed_caps[ $cpt_name ] as $cap ) {
					if ( $grant ) {
						$instructor->add_cap( $cap );
					} else {
						/*
						 * Remove the capability instead of granting it as `false`.
						 *
						 * `add_cap( $cap, false )` stores an explicit denial on the
						 * Instructor role. When a user holds both the Administrator and
						 * the Instructor role (common for site owners), WordPress merges
						 * the role capabilities and the explicit `false` wins over the
						 * Administrator grant, locking the admin out of the post type.
						 * Removing the cap leaves the Administrator grant intact.
						 */
						$instructor->remove_cap( $cap );
					}
				}
			}
		}

		/**
		 * Strip stale explicit-denial CPT capabilities from the Instructor role.
		 *
		 * Older releases stored "not allowed" as `add_cap( $cap, false )`. An explicit
		 * `false` overrides the Administrator role for users who hold both roles, so
		 * admins who were also instructors lost access to Events / FAQs even after
		 * re-activating the theme. This removes those stale denials once; an absent
		 * capability is the correct "not granted" state and never overrides other roles.
		 */
		public function maybe_heal_instructor_cpt_caps() {
			$instructor = get_role( tutor()->instructor_role );

			if ( ! $instructor ) {
				return;
			}

			$healed = false;

			foreach ( $this->get_managed_cpt_caps() as $caps ) {
				foreach ( $caps as $cap ) {
					if ( isset( $instructor->capabilities[ $cap ] ) && false === $instructor->capabilities[ $cap ] ) {
						$instructor->remove_cap( $cap );
						$healed = true;
					}
				}
			}

			if ( $healed ) {
				// Rebuild the current user's cached caps so access is restored on this same request.
				$user = wp_get_current_user();

				if ( $user instanceof WP_User ) {
					$user->get_role_caps();
				}
			}
		}
	}
}
