<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Edumall_Tutor_Certificate' ) ) {
	class Edumall_Tutor_Certificate {

		protected static $instance = null;

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Check if the current page is a certificate page.
		 * Supports both query string (?cert_hash=...) and pretty permalink (/certificate/{hash}/).
		 *
		 * @return bool
		 *
		 * @since 1.0.0
		 * @since 3.5.3 Added pretty permalink support.
		 */
		public function is_certificate_page() {
			if ( isset( $_GET['cert_hash'] ) ) {
				return true;
			}

			$cert_hash = get_query_var( 'cert_hash', '' );
			if ( ! empty( $cert_hash ) ) {
				return true;
			}

			return false;
		}

		/**
		 * Get the certificate hash from either the query string or the pretty permalink.
		 *
		 * @return string The certificate hash, or empty string if not found.
		 *
		 * @since 3.5.3
		 */
		public function get_cert_hash() {
			if ( isset( $_GET['cert_hash'] ) ) {
				return sanitize_text_field( wp_unslash( $_GET['cert_hash'] ) );
			}

			$cert_hash = get_query_var( 'cert_hash', '' );

			return $cert_hash ? sanitize_text_field( $cert_hash ) : '';
		}

		/**
		 * Generate a pretty certificate URL from a hash.
		 *
		 * Output: https://example.com/certificate/{hash}/
		 *
		 * @param string $cert_hash The certificate hash.
		 *
		 * @return string The pretty certificate URL.
		 *
		 * @since 3.5.3
		 */
		public static function get_certificate_url( $cert_hash ) {
			return home_url( '/certificate/' . sanitize_text_field( $cert_hash ) . '/' );
		}

		public function initialize() {
			add_filter( 'body_class', [ $this, 'body_class' ] );

			add_filter( 'edumall_top_bar_type', [ $this, 'change_top_bar_type' ], 9999 );
			add_filter( 'edumall_header_type', [ $this, 'change_header_type' ], 9999 );
			add_filter( 'edumall_title_bar_type', [ $this, 'change_title_bar' ], 9999 );
			add_filter( 'edumall_title_bar_heading_text', [ $this, 'title_bar_heading_text' ] );
			add_filter( 'edumall_sidebar_1', [ $this, 'disable_sidebar' ], 9999 );

			add_action( 'wp_enqueue_scripts', [ $this, 'frontend_scripts' ], 11 );

			/**
			 * Certificate pretty permalink support.
			 *
			 * Registers a rewrite rule so that /certificate/{hash}/ resolves
			 * to the same page as ?cert_hash={hash}. This produces clean,
			 * static URLs required by validators such as NELC.
			 *
			 * After activation, permalinks must be flushed:
			 * Settings → Permalinks → Save Changes (or `wp rewrite flush`).
			 *
			 * @since 3.5.3
			 */
			add_action( 'init', [ $this, 'add_certificate_rewrite_rules' ] );
			add_filter( 'query_vars', [ $this, 'add_certificate_query_vars' ] );

			/**
			 * Sync the rewritten cert_hash query var into $_GET.
			 *
			 * TutorLMS plugin reads $_GET['cert_hash'] directly to detect and
			 * render the certificate page. When a pretty URL (/certificate/{hash}/)
			 * is used, WordPress populates `get_query_var('cert_hash')` but does
			 * NOT set $_GET['cert_hash']. This bridge ensures the plugin functions
			 * correctly with pretty permalinks.
			 *
			 * @since 3.5.3
			 */
			add_action( 'template_redirect', [ $this, 'sync_cert_hash_to_get' ], 1 );
		}

		/**
		 * Register the rewrite rule for pretty certificate URLs.
		 *
		 * Maps: /certificate/{hash}/ → index.php?cert_hash={hash}
		 *
		 * @since 3.5.3
		 */
		public function add_certificate_rewrite_rules() {
			add_rewrite_rule(
				'^certificate/([a-zA-Z0-9]+)/?$',
				'index.php?cert_hash=$matches[1]',
				'top'
			);
		}

		/**
		 * Register cert_hash as a public query variable so WordPress
		 * recognises it from the rewritten URL.
		 *
		 * @param array $vars Existing query variables.
		 *
		 * @return array Modified query variables.
		 *
		 * @since 3.5.3
		 */
		public function add_certificate_query_vars( $vars ) {
			$vars[] = 'cert_hash';

			return $vars;
		}

		/**
		 * Sync the rewritten cert_hash query var into $_GET.
		 *
		 * When a pretty URL like /certificate/{hash}/ is used, WordPress
		 * sets the value via get_query_var() but NOT in $_GET. However,
		 * TutorLMS plugin reads $_GET['cert_hash'] directly to detect
		 * certificate pages and render them. This method bridges that gap
		 * so the plugin works correctly with pretty permalinks.
		 *
		 * Runs on template_redirect at priority 1 (very early) so it is
		 * available before any other hooks that check $_GET.
		 *
		 * @since 3.5.3
		 */
		public function sync_cert_hash_to_get() {
			if ( isset( $_GET['cert_hash'] ) ) {
				// Already set via query string, nothing to do.
				return;
			}

			$cert_hash = get_query_var( 'cert_hash', '' );
			if ( ! empty( $cert_hash ) ) {
				$_GET['cert_hash']     = sanitize_text_field( $cert_hash );
				$_REQUEST['cert_hash'] = $_GET['cert_hash'];
			}
		}

		public function body_class( $classes ) {
			if ( $this->is_certificate_page() ) {
				$classes [] = 'course-certificate-page';
			}

			return $classes;
		}

		public function change_top_bar_type( $type ) {
			if ( $this->is_certificate_page() ) {
				return Edumall::setting( 'global_top_bar' );
			}

			return $type;
		}

		public function change_header_type( $type ) {
			if ( $this->is_certificate_page() ) {
				return Edumall::setting( 'global_header' );
			}

			return $type;
		}

		public function change_title_bar( $type ) {
			if ( $this->is_certificate_page() ) {
				return Edumall::setting( 'title_bar_layout' );
			}

			return $type;
		}

		public function title_bar_heading_text( $text ) {
			if ( $this->is_certificate_page() ) {
				return __( 'Certificate', 'edumall' );
			}

			return $text;
		}

		public function disable_sidebar( $type ) {
			if ( $this->is_certificate_page() ) {
				return 'none';
			}

			return $type;
		}

		public function frontend_scripts() {
			/**
			 * Re-enqueue share script.
			 *
			 * @since 2.8.4
			 */
			if ( $this->is_certificate_page() ) {
				wp_enqueue_script( 'tutor-social-share' );
			}
		}
	}
}
