<?php

namespace Edumall_Elementor;

use Elementor\Group_Control_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

/**
 * Elementor advanced border control.
 *
 * A base control for creating border control. Displays input fields to define
 * border type, border width and border color.
 *
 * @since 1.0.0
 */
class Group_Control_Text_Stroke extends Group_Control_Base {

	/**
	 * Fields.
	 *
	 * Holds all the border control fields.
	 *
	 * @since  1.0.0
	 * @access protected
	 * @static
	 *
	 * @var array Border control fields.
	 */
	protected static $fields;

	/**
	 * Get text stroke control type.
	 *
	 * Retrieve the control type, in this case `edumall-text-stroke`.
	 *
	 * Must NOT be `text-stroke`: Elementor ships its own group control under that id
	 * (\Elementor\Group_Control_Text_Stroke) and Controls_Manager::add_group_control() simply
	 * overwrites the entry. Because the theme registers on `elementor/controls/register`, which
	 * fires after Elementor registers its own groups, using `text-stroke` here silently replaced
	 * the native Text Stroke controls of every core widget that consumes it (Heading, Icon Box,
	 * Counter, Accordion, Tabs, Divider, Image Box, Text Path, Nested Tabs, Nested Accordion).
	 *
	 * Renaming the id leaves this theme's own widgets untouched: setting keys are built from the
	 * `name` argument passed to add_group_control() plus the field key, never from the group id,
	 * and those `name` arguments are unchanged.
	 *
	 * It does orphan values saved against CORE widgets while this control was shadowing them —
	 * `<name>_enable|_color|_fill|_width` give way to core's
	 * `<name>_text_stroke_type|_text_stroke|_stroke_color`. Such a page loses its outline and
	 * renders as ordinary solid text; nothing disappears, and no PHP notice is raised because CSS
	 * generation iterates declared controls, not saved settings.
	 *
	 * @since  1.0.0
	 * @access public
	 * @static
	 *
	 * @return string Control type.
	 */
	public static function get_type() {
		return 'edumall-text-stroke';
	}

	/**
	 * Init fields.
	 *
	 * Initialize border control fields.
	 *
	 * @since  1.2.2
	 * @access protected
	 *
	 * @return array Control fields.
	 */
	protected function init_fields() {
		$fields = [];

		$fields['color'] = [
			'label'     => esc_html__( 'Color', 'edumall' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '',
			'selectors' => [
				'{{SELECTOR}}' => '-webkit-text-stroke-color: {{VALUE}};',
			],
		];

		// Divider.
		$fields['fill'] = [
			'label'                => esc_html__( 'Fill', 'edumall' ),
			'label_block'          => false,
			'type'                 => Controls_Manager::CHOOSE,
			'options'              => array(
				'none'    => [
					'title' => esc_html__( 'Transparent', 'edumall' ),
					'icon'  => 'eicon-ban',
				],
				'initial' => [
					'title' => esc_html__( 'Normal', 'edumall' ),
					'icon'  => 'eicon-paint-brush',
				],
			),
			'default'              => 'none',
			'selectors_dictionary' => [
				'none' => 'rgba(0, 0, 0, 0)',
			],
			'selectors'            => [
				'{{SELECTOR}}' => '-webkit-text-fill-color: {{VALUE}};',
			],
		];

		$fields['width'] = [
			'label'      => esc_html__( 'Width', 'edumall' ),
			'type'       => Controls_Manager::SLIDER,
			'range'      => [
				'px' => [
					'min'  => 1,
					'max'  => 30,
					'step' => 1,
				],
			],
			'selectors'  => [
				'{{SELECTOR}}' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
			],
			'responsive' => true,
		];

		return $fields;
	}

	/**
	 * Get default options.
	 *
	 * Retrieve the default options of the border control. Used to return the
	 * default options while initializing the border control.
	 *
	 * @since  1.9.0
	 * @access protected
	 *
	 * @return array Default border control options.
	 */
	protected function get_default_options() {
		return [
			'popover' => [
				'starter_title' => _x( 'Text Stroke', 'Text Stroke Control', 'edumall' ),
				'starter_name'  => 'enable',
				'starter_value' => 'yes',
				'settings'      => [
					'render_type' => 'ui',
				],
			],
		];
	}
}
