<?php

namespace Edumall_Elementor;

use Elementor\Plugin;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || exit;

class Modify_Widget_Section extends Modify_Base {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action(
			'elementor/element/section/section_layout/after_section_end',
			array(
				$this,
				'section_layout',
			)
		);

		/*
		 * Deliberately no `inner-section` registration.
		 *
		 * Inner sections are \Elementor\Element_Section instances too — same elType, just
		 * `isInner` set — so the `section` hook above already covers them. That is why Elementor
		 * needs a per-control `hide_in_inner` flag at all: inner and outer share one control
		 * stack. \Elementor\Widget_Inner_Section is only the widget-panel entry, and it declares
		 * no controls of its own, so `elementor/element/inner-section/section_layout/...` never
		 * fires on any version. It was registered here once and was always a no-op.
		 */
	}

	/**
	 * Update section gap control in layout section.
	 *
	 * @param \Elementor\Controls_Stack $element
	 */
	public function section_layout( $element ) {
		// Update content width strong selector to make it working properly with Boxed template.
		$element->update_control(
			'content_width',
			array(
				'selectors' => array(
					'{{WRAPPER}} > .elementor-container.elementor-container' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// Get section args.
		$section_gap = Plugin::instance()->controls_manager->get_control_from_stack( $element->get_unique_name(), 'gap' );

		/*
		 * Bail if this stack has no `gap` control. get_control_from_stack() answers with a
		 * WP_Error rather than null, so the `empty( $section_gap['options'] )` test below would
		 * array-access an object and fatal on PHP 7.4+.
		 *
		 * The `section` stack always registers `gap`, so this never trips today — it is here so
		 * that hooking this callback onto another stack degrades into a no-op instead of taking
		 * the site down.
		 */
		if ( is_wp_error( $section_gap ) ) {
			return;
		}

		if ( ! empty( $section_gap['options'] ) ) {
			$gap_options = $section_gap['options'];

			// Change 'Default' => 'Normal' text.
			if ( isset( $gap_options['default'] ) ) {
				$gap_options['default'] = esc_html__( 'Normal', 'edumall' );
			}

			// Add new gap option 'custom'.
			if ( ! isset( $gap_options['custom'] ) ) {
				$gap_options['custom'] = esc_html__( 'Custom', 'edumall' );
			}

			// Set new options.
			$section_gap['options'] = $gap_options;
		}

		// Change default gap setting from 'default' => 'extended'.
		$section_gap['default'] = 'extended';

		// Apply gap changed.
		$element->update_control( 'gap', $section_gap );

		/**
		 * Elementor also added custom gap width in 3.1.0
		 * We need remove it.
		 */
		$element->remove_responsive_control( 'gap_columns_custom' );

		$element->start_injection(
			array(
				'type' => 'control',
				'at'   => 'after',
				'of'   => 'gap',
			)
		);

		$element->add_control(
			'gap_beside',
			array(
				'label'        => esc_html__( 'Gap Beside', 'edumall' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'yes',
				'options'      => array(
					'no'  => esc_html__( 'No', 'edumall' ),
					'yes' => esc_html__( 'Yes', 'edumall' ),
				),
				'prefix_class' => 'elementor-section-gap-beside-',
				'condition'    => array(
					'gap!' => 'no',
				),
			)
		);

		$element->add_responsive_control(
			'gap_width',
			array(
				'label'     => esc_html__( 'Gap Width', 'edumall' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 0,
						'max'  => 100,
						'step' => 2,
					),
				),
				'selectors' => array(
					// Legacy DOM with .elementor-row.
					'{{WRAPPER}} > .elementor-column-gap-custom > .elementor-row > .elementor-column > .elementor-element-populated' => 'padding-left: calc( {{SIZE}}{{UNIT}} / 2); padding-right: calc( {{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}}.elementor-section-gap-beside-no > .elementor-column-gap-custom > .elementor-row'                    => 'margin-left: calc( -{{SIZE}}{{UNIT}} / 2); margin-right: calc( -{{SIZE}}{{UNIT}} / 2);',
					// Optimized DOM without .elementor-row (Elementor 3.x+).
					'{{WRAPPER}} > .elementor-column-gap-custom > .elementor-column > .elementor-element-populated'                  => 'padding-left: calc( {{SIZE}}{{UNIT}} / 2); padding-right: calc( {{SIZE}}{{UNIT}} / 2);',
					'{{WRAPPER}}.elementor-section-gap-beside-no > .elementor-column-gap-custom'                                    => 'margin-left: calc( -{{SIZE}}{{UNIT}} / 2); margin-right: calc( -{{SIZE}}{{UNIT}} / 2);',
				),
				'condition' => array(
					'gap' => 'custom',
				),
			)
		);

		$element->end_injection();

		// Add control custom alignment of content.
		$element->start_injection(
			array(
				'type' => 'control',
				'at'   => 'before',
				'of'   => 'content_position',
			)
		);

		$element->add_control(
			'content_alignment',
			array(
				'label'        => esc_html__( 'Content Alignment', 'edumall' ),
				'type'         => Controls_Manager::CHOOSE,
				'options'      => Widget_Utils::get_control_options_horizontal_alignment(),
				'default'      => 'center',
				'toggle'       => false,
				'prefix_class' => 'elementor-section-content-align-',
				'condition'    => array(
					'content_width!' => '',
				),
			)
		);

		$element->add_control(
			'column_vertical_alignment',
			array(
				'label'                => esc_html__( 'Column Vertical Alignment', 'edumall' ),
				'label_block'          => true,
				'type'                 => Controls_Manager::CHOOSE,
				'options'              => Widget_Utils::get_control_options_vertical_full_alignment(),
				'default'              => 'stretch',
				'toggle'               => false,
				'prefix_class'         => 'elementor-section-column-vertical-align-',
				/*
				 * This selector is inert, and that is deliberate. Do NOT re-point it at
				 * `{{WRAPPER}} > .elementor-container` to "make it work".
				 *
				 * Elementor dropped the `.elementor-row` wrapper from its section markup long ago
				 * and 3.26 deleted the `e_dom_optimization` opt-out outright, so the rule matches
				 * nothing on any current version. It is left in place only because removing it is
				 * pointless churn, not because anything still renders that wrapper.
				 *
				 * Targeting `.elementor-container` instead would make the non-empty 'stretch'
				 * default emit `align-items: stretch` on every single section, overriding
				 * Elementor's own `.elementor-section-items-*` (Column Position) rules on pages
				 * that are already published. Use Elementor's native Column Position instead.
				 */
				'selectors'            => array(
					'{{WRAPPER}} > .elementor-container > .elementor-row' => 'align-items: {{VALUE}}',
				),
				'selectors_dictionary' => array(
					'top'    => 'flex-start',
					'middle' => 'center',
					'bottom' => 'flex-end',
				),
			)
		);

		$element->update_control(
			'content_position',
			array(
				'condition' => array(
					'column_vertical_alignment' => 'stretch',
				),
			)
		);

		$element->end_injection();
	}
}

Modify_Widget_Section::instance()->initialize();
