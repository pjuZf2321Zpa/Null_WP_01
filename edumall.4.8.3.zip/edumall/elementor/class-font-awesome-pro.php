<?php

namespace Edumall_Elementor;

defined( 'ABSPATH' ) || exit;

class Font_Awesome_Pro {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function initialize() {
		add_action( 'elementor/frontend/after_register_styles', function() {
			foreach ( [ 'solid', 'regular', 'brands' ] as $style ) {
				wp_deregister_style( 'elementor-icons-fa-' . $style );
			}
		}, 20 );

		add_filter( 'elementor/icons_manager/native', [ $this, 'replace_font_awesome_pro' ], 10 );

		add_action( 'elementor/experiments/default-features-registered', [ $this, 'disable_inline_font_icons' ] );

		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ], 11 );
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ], 11 );
	}

	/**
	 * Turn off the default state of Elementor's "Inline Font Icons" experiment.
	 *
	 * That experiment renders icons on the frontend as inline SVG read from Elementor's own
	 * Font Awesome 5.15.3 JSON files. This theme replaces those libraries with Font Awesome Pro
	 * 6.4.2 and adds fa-light / fa-duotone, for which Elementor ships no JSON at all, so icons
	 * either render the wrong (FA5) glyph or disappear. The webfont path this theme already
	 * enqueues renders every one of them correctly.
	 *
	 * Only the DEFAULT is changed. A site owner who explicitly toggled the experiment under
	 * Elementor > Settings > Features keeps their own choice.
	 *
	 * @param object $experiments Elementor experiments manager.
	 */
	public function disable_inline_font_icons( $experiments ) {
		if ( ! method_exists( $experiments, 'set_feature_default_state' ) ) {
			return;
		}

		// Literal instead of Manager::STATE_INACTIVE: the guard above covers the method only, so a
		// class constant lookup here would be an unguarded fatal if Elementor ever renamed it.
		$experiments->set_feature_default_state( 'e_font_icon_svg', 'inactive' );
	}

	public function replace_font_awesome_pro( $settings ) {
		$json_url = EDUMALL_ELEMENTOR_ASSETS . '/libs/font-awesome-pro/%s.js';
		$version  = '6.4.2-pro';

		$icons['fa-regular'] = [
			'name'          => 'fa-regular',
			'label'         => esc_html__( 'Font Awesome - Regular Pro', 'edumall' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-regular',
			'labelIcon'     => 'fa-regular fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'regular' ),
			'native'        => true,
		];

		$icons['fa-solid'] = [
			'name'          => 'fa-solid',
			'label'         => esc_html__( 'Font Awesome - Solid Pro', 'edumall' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-solid',
			'labelIcon'     => 'fa-solid fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'solid' ),
			'native'        => true,
		];

		$icons['fa-brands'] = [
			'name'          => 'fa-brands',
			'label'         => esc_html__( 'Font Awesome - Brands Pro', 'edumall' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-brands',
			'labelIcon'     => 'fa-brands fa-font-awesome-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'brands' ),
			'native'        => true,
		];

		$icons['fa-light'] = [
			'name'          => 'fa-light',
			'label'         => esc_html__( 'Font Awesome - Light Pro', 'edumall' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-light',
			'labelIcon'     => 'fa-light fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'light' ),
			'native'        => true,
		];

		$icons['fa-duotone'] = [
			'name'          => 'fa-duotone',
			'label'         => esc_html__( 'Font Awesome - Duotone Pro', 'edumall' ),
			'url'           => false,
			'enqueue'       => false,
			'prefix'        => 'fa-',
			'displayPrefix' => 'fa-duotone',
			'labelIcon'     => 'fa-duotone fa-flag',
			'ver'           => $version,
			'fetchJson'     => sprintf( $json_url, 'duotone' ),
			'native'        => true,
		];

		// Remove old from plugin.
		unset(
			$settings['fa-solid'],
			$settings['fa-regular'],
			$settings['fa-brands'],
			$settings['fa-light'],
			$settings['fa-duotone']
		);

		return array_merge( $icons, $settings );
	}

	function admin_enqueue_scripts() {
		wp_enqueue_style( 'font-awesome-pro', EDUMALL_THEME_URI . '/assets/fonts/awesome/css/fontawesome-all.min.css', null, '6.4.2' );
	}
}

Font_Awesome_Pro::instance()->initialize();
