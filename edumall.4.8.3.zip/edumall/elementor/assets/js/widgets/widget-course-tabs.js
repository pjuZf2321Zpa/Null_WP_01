(function ($) {
  'use strict';

  var EdumallCourseTabs = function ($scope, $) {
	const $tabPanel = $scope.find('.edumall-tabpanel');
	const $activePanelContent = $tabPanel.children('.edumall-tab-content').children('.active');
	const $activeComponent = $activePanelContent.find('.tm-tab-course-element');
	const layout = $tabPanel.data('layout');

	if ('carousel' === layout) {
	  $activeComponent.EdumallSwiper();
	}

	$(document).on('EdumallTabChange', function (e, tabPanel, currentTab) {
	  if (currentTab.data('query') && !currentTab.hasClass('ajax-loaded')) {
		loadCourseData(tabPanel, currentTab);
		currentTab.addClass('ajax-loaded');

		return;
	  }

	  const layout = tabPanel.data('layout');
	  if (layout === 'carousel') {
		const $component = currentTab.find('.tm-tab-course-element');
		const swiper = $component.children('.swiper-inner').children('.swiper')[ 0 ].swiper;
		swiper && swiper.update();
	  }
	});

	function loadCourseData (tabPanel, currentTab) {
	  const $component = currentTab.find('.tm-tab-course-element');
	  const layout = tabPanel.data('layout');

	  if ('carousel' === layout) {
		$component.EdumallSwiper();
	  }

	  var query = currentTab.data('query');
	  query.action = 'get_course_tabs';

	  $.ajax({
		url: $edumall.ajaxurl,
		type: 'GET',
		data: query,
		dataType: 'json',
		success: function (response) {
		  if (!response.success) {
			$component.remove();
			currentTab.find('.edumall-grid-response-messages').html(response.template);
		  } else {
			if ('grid' === layout) {
			  const $grid = $component.children('.modern-grid');
			  $grid.children('.grid-item').remove();
			  $grid.append($(response.template));
			} else {
			  const swiper = $component.children('.swiper-inner').children('.swiper')[ 0 ].swiper;
			  swiper.removeAllSlides();
			  swiper.appendSlide(response.template);
			  swiper.update();
			}
		  }
		}
	  });
	}
  };

  $(window).on('elementor/frontend/init', function () {
	elementorFrontend.hooks.addAction('frontend/element_ready/tm-course-tabs.default', EdumallCourseTabs);
  });
})(jQuery);
