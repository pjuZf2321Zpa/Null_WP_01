<?php
/**
 * WOOCS — Currency Switcher Professional for WooCommerce integration.
 *
 * @package woodmart
 */

if ( ! defined( 'WOOCS_VERSION' ) ) {
	return;
}

add_filter( 'woodmart_do_not_recalulate_total_on_get_refreshed_fragments', '__return_true' );

if ( ! function_exists( 'woodmart_woocs_convert_product_bundle_in_cart' ) ) {
	/**
	 * Back convector bundle product price.
	 *
	 * @param float $price Product price.
	 * @return mixed|string
	 */
	function woodmart_woocs_convert_product_bundle_in_cart( $price ) {
		global $WOOCS; // phpcs:ignore WordPress.NamingConventions

		return $WOOCS->woocs_back_convert_price( $price ); // phpcs:ignore WordPress.NamingConventions
	}

	add_filter( 'woodmart_fbt_set_product_cart_price', 'woodmart_woocs_convert_product_bundle_in_cart', 10, 2 );
	add_filter( 'woodmart_pricing_before_calculate_discounts', 'woodmart_woocs_convert_product_bundle_in_cart', 10, 2 );
}

if ( ! function_exists( 'woodmart_woocs_shipping_progress_bar_amount' ) ) {
	/**
	 * Converse shipping progress bar limit
	 *
	 * @param float $limit Shipping limit.
	 * @return float
	 */
	function woodmart_woocs_shipping_progress_bar_amount( $limit ) {
		global $WOOCS; // phpcs:ignore WordPress.NamingConventions

		$limit *= $WOOCS->get_sign_rate( array( 'sign' => $WOOCS->current_currency ) ); // phpcs:ignore WordPress.NamingConventions

		return $limit;
	}

	add_filter( 'woodmart_shipping_progress_bar_amount', 'woodmart_woocs_shipping_progress_bar_amount' );
}

if ( ! function_exists( 'woodmart_woocs_convert_price' ) ) {
	/**
	 * Convector bundle product price.
	 *
	 * @param float $price Product price.
	 * @return mixed|string
	 */
	function woodmart_woocs_convert_price( $price ) {
		global $WOOCS; // phpcs:ignore WordPress.NamingConventions

		return $WOOCS->woocs_convert_price( $price ); // phpcs:ignore WordPress.NamingConventions
	}

	// Discount product price table.
	add_filter( 'woodmart_dynamic_discount_display_amount', 'woodmart_woocs_convert_price', 10, 1 );
	add_filter( 'woodmart_dynamic_discount_calculated_price_amount', 'woodmart_woocs_convert_price', 10, 1 );
}
