<?php
/**
 * Pay-first package balance (admin)
 *
 * Staff balance actions on the WooCommerce admin order edit screen (included from order/series-display.php).
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/order/admin/series-balance.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @var WC_Appointment_Series $series      Recurring series.
 * @var WC_Order              $order       Order being viewed.
 * @var float                 $balance_due Remaining balance due.
 * @var string                $currency    Order currency.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.4.1
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! $series instanceof WC_Appointment_Series || ! $series->has_open_balance() ) {
	return;
}

$payment                  = $series->get_payment_snapshot();
$admin                    = isset( $payment['admin'] ) && is_array( $payment['admin'] ) ? $payment['admin'] : array();
$is_balance_order_context = WC_Appointment_Series_Payment::is_balance_order( $order );
$actions                  = $series->get_admin_balance_actions( $payment, $order->get_id() );

if ( empty( $admin['needs_balance_payment'] ) && empty( $admin['can_mark_paid_offline'] ) ) {
	return;
}

$has_balance_order = ! empty( $payment['balance_order_id'] );
$paid_upfront      = isset( $payment['paid_upfront'] ) ? (float) $payment['paid_upfront'] : 0.0;
?>
<div class="wca-series-balance-block wca-series-balance-block--admin" style="margin-top: 1em; padding: 0.75em 1em; border: 1px solid rgba(0,0,0,.08); border-radius: 4px;">
	<?php if ( $is_balance_order_context && $paid_upfront > 0 ) : ?>
		<p style="margin: 0 0 0.5em;">
			<strong><?php esc_html_e( 'Paid on original order', 'woocommerce-appointments' ); ?>:</strong>
			<?php echo wp_kses_post( wc_price( $paid_upfront, array( 'currency' => $currency ) ) ); ?>
		</p>
	<?php endif; ?>
	<p style="margin: 0 0 0.5em;">
		<strong><?php esc_html_e( 'Remaining balance', 'woocommerce-appointments' ); ?>:</strong>
		<?php echo wp_kses_post( wc_price( $balance_due, array( 'currency' => $currency ) ) ); ?>
	</p>
	<p style="margin: 0 0 0.75em; font-size: 0.925em; color: #50575e;">
		<?php
		if ( $is_balance_order_context ) {
			esc_html_e( 'Collect in person, send a payment request, or mark the package paid offline.', 'woocommerce-appointments' );
		} elseif ( $has_balance_order ) {
			esc_html_e( 'Open the balance order to collect in person, send a payment request, or mark the package paid offline.', 'woocommerce-appointments' );
		} else {
			esc_html_e( 'Create a balance order first, then collect in person, send a payment request, or mark the package paid offline.', 'woocommerce-appointments' );
		}
		?>
	</p>
	<div class="wca-series-balance-admin-actions" style="margin: 0; display: flex; flex-wrap: wrap; align-items: center; column-gap: 8px; row-gap: 8px;">
		<?php foreach ( $actions as $staff_action ) : ?>
			<?php if ( ! empty( $staff_action['url'] ) ) : ?>
				<a
					class="<?php echo esc_attr( (string) ( $staff_action['button_class'] ?? 'button' ) ); ?>"
					style="margin: 0;"
					href="<?php echo esc_url( (string) $staff_action['url'] ); ?>"
					<?php echo ! empty( $staff_action['confirm'] ) ? ' onclick="return confirm(' . wp_json_encode( (string) $staff_action['confirm'] ) . ');"' : ''; ?>
				><?php echo esc_html( (string) $staff_action['label'] ); ?></a>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
</div>
