<?php
/**
 * Recurring series summary on order line items
 *
 * Displays recurring series sessions and pay-first balance on:
 * - Thank you / order received,
 * - Order confirmation emails,
 * - My Account → Orders, and
 * - Admin order screens.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/order/series-display.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @var array<int, array<string, mixed>> $rows                      Occurrence rows (`label`, optional `appointment`, payment fields).
 * @var bool                             $is_admin                  Admin order context.
 * @var bool                             $plain_text_email            Plain-text email rendering.
 * @var string                           $customer_tz_abbr          Customer timezone label (admin).
 * @var string                           $pattern                   Human-readable recurrence summary.
 * @var string                           $location_label            Location field label (product or default).
 * @var string                           $location_display          Series location snapshot display string.
 * @var bool                             $pay_first                 Pay-first payment model.
 * @var int                              $session_count             Number of sessions shown.
 * @var string                           $is_rtl                    `left` or `right`.
 * @var float                            $balance_due               Remaining balance due.
 * @var string                           $balance_pay_url           Pay balance URL.
 * @var string                           $currency                  Order currency.
 * @var string                           $series_account_url        My Account series URL.
 * @var bool                             $is_balance_order          Current order is the balance order.
 * @var float                            $paid_upfront              Amount paid on the original order.
 * @var float                            $series_total              Full series total (balance orders).
 * @var bool                             $balance_order_needs_payment Balance order still needs payment.
 * @var array<string, mixed>|null        $admin_balance             Args for order/admin/series-balance.php.
 * @var bool                             $show_customer_balance     Show customer balance block.
 * @var bool                             $show_account_link         Show My Account series link.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.5.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>
<div class="wc-appointment-series-summary<?php echo ! empty( $is_balance_order ) ? ' wc-appointment-series-summary--balance-order' : ''; ?>" style="margin-top: 10px; margin-bottom: 10px;">
	<div class="wc-appointment-series-summary-name">
		<strong<?php echo 'right' === $is_rtl ? ' dir="rtl"' : ''; ?>>
			<?php
			printf(
				/* translators: %d: number of appointments in the series */
				esc_html( _n( 'Recurring series · %d appointment', 'Recurring series · %d appointments', $session_count, 'woocommerce-appointments' ) ),
				(int) $session_count
			);
			?>
		</strong>
		<?php if ( $pattern ) : ?>
			<br /><small><?php echo esc_html( ucfirst( $pattern ) ); ?></small>
		<?php endif; ?>
		<?php if ( ! empty( $location_display ) ) : ?>
			<br /><small><?php echo esc_html( ( ! empty( $location_label ) ? $location_label : __( 'Location', 'woocommerce-appointments' ) ) . ': ' . $location_display ); ?></small>
		<?php endif; ?>
	</div>
	<ul class="wca-series-occ-list" style="margin: 0.5em 0 0; padding: 0; list-style: none;">
		<?php foreach ( $rows as $row ) : ?>
			<li class="wca-series-occ-item" style="padding: 0.25em 0;">
				<span><?php echo $plain_text_email ? esc_html( wp_strip_all_tags( $row['label'] ) ) : wp_kses_post( $row['label'] ); ?></span>
				<?php if ( $pay_first && ! empty( $row['payment_status'] ) ) : ?>
					&mdash;
					<small class="wca-series-occ-payment status-<?php echo esc_attr( $row['payment_status'] ); ?>">
						<?php echo esc_html( ! empty( $row['payment_label'] ) ? (string) $row['payment_label'] : ( 'paid' === $row['payment_status'] ? __( 'Paid on this order', 'woocommerce-appointments' ) : __( 'Balance due', 'woocommerce-appointments' ) ) ); ?>
					</small>
				<?php endif; ?>
				<?php if ( $is_admin && ! empty( $row['appointment'] ) ) : ?>
					&mdash;
					<a href="<?php echo esc_url( admin_url( 'post.php?post=' . absint( $row['appointment']->get_id() ) . '&action=edit' ) ); ?>">
						<?php esc_html_e( 'Edit appointment', 'woocommerce-appointments' ); ?>
					</a>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( $customer_tz_abbr ) : ?>
		<ul class="wc-appointment-summary-list wca-series-customer-tz" style="padding: 0; margin: 0.5em 0 0; list-style: none outside;">
			<li<?php echo 'right' === $is_rtl ? ' dir="rtl"' : ''; ?>>
				<?php esc_html_e( "Customer's Timezone", 'woocommerce-appointments' ); ?>:
				<strong><?php echo wp_kses_post( $customer_tz_abbr ); ?></strong>
			</li>
		</ul>
	<?php endif; ?>
	<?php if ( $admin_balance ) : ?>
		<?php wc_get_template( 'order/admin/series-balance.php', $admin_balance, 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH ); ?>
	<?php elseif ( ( ! empty( $show_customer_balance ) ) || ( ! empty( $is_balance_order ) && empty( $is_admin ) && ( $paid_upfront > 0 || $series_total > 0 || ! empty( $balance_order_needs_payment ) ) ) ) : ?>
		<div class="wca-series-balance-block<?php echo ! empty( $is_balance_order ) ? ' wca-series-balance-block--original-order' : ''; ?>" style="margin-top: 1em; padding: 0.75em 1em; border: 1px solid rgba(0,0,0,.08); border-radius: 4px;">
			<?php if ( ! empty( $show_customer_balance ) ) : ?>
				<p style="margin: 0 0 0.5em;">
					<strong><?php esc_html_e( 'Remaining balance', 'woocommerce-appointments' ); ?>:</strong>
					<?php echo wp_kses_post( wc_price( $balance_due, array( 'currency' => $currency ) ) ); ?>
				</p>
			<?php elseif ( $paid_upfront > 0 ) : ?>
				<p style="margin: 0 0 0.5em;">
					<strong><?php esc_html_e( 'Paid on original order', 'woocommerce-appointments' ); ?>:</strong>
					<?php echo wp_kses_post( wc_price( $paid_upfront, array( 'currency' => $currency ) ) ); ?>
				</p>
			<?php endif; ?>
			<?php if ( ! empty( $is_balance_order ) && $series_total > 0 ) : ?>
				<p style="margin: 0 0 0.5em;">
					<strong><?php esc_html_e( 'Series total', 'woocommerce-appointments' ); ?>:</strong>
					<?php echo wp_kses_post( wc_price( $series_total, array( 'currency' => $currency ) ) ); ?>
				</p>
			<?php endif; ?>
			<?php if ( ! empty( $show_customer_balance ) || ! empty( $balance_order_needs_payment ) ) : ?>
				<p style="margin: 0; font-size: 0.925em; color: #50575e;">
					<?php esc_html_e( 'Complete payment to confirm your remaining appointments.', 'woocommerce-appointments' ); ?>
				</p>
			<?php endif; ?>
			<?php if ( ! empty( $show_customer_balance ) && ( $balance_pay_url || $series_account_url ) ) : ?>
				<p style="margin: 0.75em 0 0;">
					<a class="woocommerce-button button alt wca-series-balance-pay" href="<?php echo esc_url( $balance_pay_url ? $balance_pay_url : $series_account_url ); ?>">
						<?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?>
					</a>
				</p>
			<?php endif; ?>
		</div>
	<?php elseif ( $show_account_link ) : ?>
		<p style="margin: 0.75em 0 0;">
			<a href="<?php echo esc_url( $series_account_url ); ?>"><?php esc_html_e( 'View series in My Account', 'woocommerce-appointments' ); ?></a>
		</p>
	<?php endif; ?>
</div>
