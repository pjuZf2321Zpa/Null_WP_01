<?php
/**
 * The template for displaying the list of appointments in the summary for customers.
 * It is used in:
 * - templates/order/appointment-display.php
 * - templates/order/admin/appointment-display.php
 * It will display in four places:
 * - After checkout,
 * - In the order confirmation email, and
 * - When customer reviews order in My Account > Orders,
 * - When reviewing a customer order in the admin area.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/order/appointment-summary-list.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @version 5.5.0
 * @since   3.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>
<ul class="wc-appointment-summary-list" style="padding: 0; list-style: none outside;">
	<?php
	// When? (timezone abbreviation is appended to the date via abbr element)
	if ( isset( $date ) && $date ) {
		printf(
		    '<li%1$s>%2$s: <strong>%3$s</strong></li>',
		    esc_html( isset( $is_rtl ) && 'right' === $is_rtl ? ' dir="rtl"' : '' ),
		    esc_html__( 'When', 'woocommerce-appointments' ),
		    wp_kses_post( $date ),
		);
	}
	// Duration?
	if ( isset( $duration ) && $duration ) {
		printf(
		    '<li%1$s>%2$s: <strong>%3$s</strong></li>',
		    esc_html( isset( $is_rtl ) && 'right' === $is_rtl ? ' dir="rtl"' : '' ),
		    esc_html__( 'Duration', 'woocommerce-appointments' ),
		    esc_attr( $duration ),
		);
	}
	// Meeting join URL?
	if ( ! empty( $meeting_join_url ) ) {
		printf(
		    '<li%1$s>%2$s: <strong><a href="%3$s">%4$s</a></strong></li>',
		    esc_html( isset( $is_rtl ) && 'right' === $is_rtl ? ' dir="rtl"' : '' ),
		    esc_html__( 'Join Meeting', 'woocommerce-appointments' ),
		    esc_url( $meeting_join_url ),
		    esc_html__( 'Open meeting', 'woocommerce-appointments' ),
		);
	}
	// Location?
	if ( ! empty( $location ) ) {
		printf(
		    '<li%1$s>%2$s: <strong>%3$s</strong></li>',
		    esc_html( isset( $is_rtl ) && 'right' === $is_rtl ? ' dir="rtl"' : '' ),
		    esc_html( ! empty( $location_label ) ? $location_label : __( 'Location', 'woocommerce-appointments' ) ),
		    esc_html( $location ),
		);
	}
	// Resources?
	if ( ! empty( $resource ) ) {
		printf(
		    '<li%1$s>%2$s: <strong>%3$s</strong></li>',
		    esc_html( isset( $is_rtl ) && 'right' === $is_rtl ? ' dir="rtl"' : '' ),
		    esc_html( ! empty( $resource_label ) ? $resource_label : __( 'Resources', 'woocommerce-appointments' ) ),
		    esc_html( $resource ),
		);
	}
	// Providers? (with staff timezone abbr when TZ differs from viewer)
	if ( isset( $providers ) && $providers ) {
		$_staff_tz_html = ! empty( $staff_tz_abbrs ) ? $staff_tz_abbrs : '';
		printf(
		    '<li%1$s>%2$s: <strong>%3$s</strong>%4$s</li>',
		    esc_html( isset( $is_rtl ) && 'right' === $is_rtl ? ' dir="rtl"' : '' ),
		    esc_attr( $label ),
		    esc_attr( $providers ),
		    wp_kses_post( $_staff_tz_html ),
		);
	}
	// Customer timezone abbr (admin context only, when TZ differs from viewer)
	if ( ! empty( $customer_tz_abbr ) ) {
		printf(
		    '<li%1$s>%2$s: <strong>%3$s</strong></li>',
		    esc_html( isset( $is_rtl ) && 'right' === $is_rtl ? ' dir="rtl"' : '' ),
		    esc_html__( "Customer's Timezone", 'woocommerce-appointments' ),
		    wp_kses_post( $customer_tz_abbr ),
		);
	}
	?>
</ul>
