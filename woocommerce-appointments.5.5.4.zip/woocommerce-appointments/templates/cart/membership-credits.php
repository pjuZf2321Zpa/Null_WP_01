<?php
/**
 * Membership credit opt-in
 *
 * Renders membership credit UI on the booking form footer, checkout fallback, or applied confirm.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/cart/membership-credits.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @var string            $mode                     `form`, `checkout`, or `applied`.
 * @var WC_Subscription[] $subscriptions            Eligible membership subscriptions.
 * @var int               $selected_subscription_id Selected subscription id.
 * @var bool              $auto_apply               Whether credit is pre-selected.
 * @var int               $credits_required         Credits required for the line.
 * @var string            $credit_summary           Applied checkout summary text.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.4.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$mode = isset( $mode ) ? $mode : 'checkout';

if ( 'applied' === $mode && ! empty( $credit_summary ) ) :
	?>
	<div class="wca-membership-credit-block wca-membership-checkout-applied">
		<?php echo esc_html( $credit_summary ); ?>
	</div>
	<?php
	return;
endif;

if ( empty( $subscriptions ) || ( 'checkout' === $mode && (int) ( $credits_required ?? 0 ) < 1 ) ) {
	return;
}

$default     = $subscriptions[0];
$selected_id = (int) ( $selected_subscription_id ?? $default->get_id() );
$multiple    = count( $subscriptions ) > 1;
$auto_apply  = ! empty( $auto_apply );
$is_form     = 'form' === $mode;
$block_class = 'wca-membership-credit-block' . ( $is_form ? ' wca-membership-footer' : '' );
if ( $auto_apply && ! $multiple ) {
	$block_class .= ' wca-membership-auto-apply';
}
$toggle_label = $is_form
	? __( 'Use membership credit', 'woocommerce-appointments' )
	: sprintf(
		/* translators: %d: number of appointments in the cart */
		_n(
			'Use membership credit for %d appointment in this order',
			'Use membership credits for %d appointments in this order',
			(int) $credits_required,
			'woocommerce-appointments'
		),
		(int) $credits_required
	);
?>
<div class="<?php echo esc_attr( $block_class ); ?>"<?php echo $is_form ? ' hidden' : ''; ?>>
	<?php if ( $multiple || ! $auto_apply ) : ?>
		<p class="form-field form-field-wide">
			<label for="wca-membership-use-<?php echo esc_attr( $mode ); ?>">
				<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="wca_membership[use]" id="wca-membership-use-<?php echo esc_attr( $mode ); ?>" value="1" <?php checked( $auto_apply ); ?> />
				<?php echo esc_html( $toggle_label ); ?>
			</label>
		</p>
	<?php else : ?>
		<input type="hidden" name="wca_membership[use]" value="1" />
	<?php endif; ?>

	<div class="wca-membership-plans">
		<?php if ( $multiple ) : ?>
			<p class="form-field form-field-wide" role="radiogroup" aria-label="<?php esc_attr_e( 'Membership plan', 'woocommerce-appointments' ); ?>">
				<?php foreach ( $subscriptions as $subscription ) : ?>
					<?php $radio_id = 'wca-membership-' . $mode . '-' . (int) $subscription->get_id(); ?>
					<label for="<?php echo esc_attr( $radio_id ); ?>">
						<input type="radio" class="woocommerce-form__input woocommerce-form__input-radio input-radio" name="wca_membership[subscription_id]" id="<?php echo esc_attr( $radio_id ); ?>" value="<?php echo esc_attr( (string) $subscription->get_id() ); ?>" <?php checked( $subscription->get_id(), $selected_id ); ?> />
						<span>
							<strong><?php echo esc_html( WC_Appointments_Integration_Subscription_Entitlement::get_plan_name( $subscription ) ); ?></strong>
							<small><?php echo esc_html( WC_Appointments_Integration_Subscription_Entitlement::balance_label( $subscription ) ); ?></small>
						</span>
					</label>
				<?php endforeach; ?>
			</p>
		<?php else : ?>
			<input type="hidden" name="wca_membership[subscription_id]" value="<?php echo esc_attr( (string) $selected_id ); ?>" />
			<strong><?php echo esc_html( WC_Appointments_Integration_Subscription_Entitlement::get_plan_name( $default, __( 'Your membership', 'woocommerce-appointments' ) ) ); ?></strong>
			<small><?php echo esc_html( WC_Appointments_Integration_Subscription_Entitlement::balance_label( $default ) ); ?></small>
		<?php endif; ?>
	</div>

	<?php if ( $is_form ) : ?>
		<?php if ( (int) ( $credits_required ?? 0 ) > 1 ) : ?>
			<p class="wca-membership-apply-note"><?php esc_html_e( 'One membership credit per appointment in this package will be used.', 'woocommerce-appointments' ); ?></p>
		<?php else : ?>
			<p class="wca-membership-apply-note"><?php esc_html_e( 'One membership credit will be used. You pay $0 for this appointment.', 'woocommerce-appointments' ); ?></p>
		<?php endif; ?>
	<?php endif; ?>
</div>
