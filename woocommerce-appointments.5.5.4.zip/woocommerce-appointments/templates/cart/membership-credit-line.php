<?php
/**
 * Per cart line: apply membership credit for a single appointment.
 *
 * @var string            $cart_item_key
 * @var WC_Subscription[] $subscriptions
 * @var int               $selected_subscription_id
 * @var bool              $credit_applied
 *
 * @package WooCommerce\Appointments\Templates
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $subscriptions ) ) {
	return;
}

$default_subscription = $subscriptions[0];
$selected_id          = $selected_subscription_id > 0 ? $selected_subscription_id : (int) $default_subscription->get_id();
$field_prefix         = 'wca_membership[' . $cart_item_key . ']';
?>
<div class="wca-membership-cart-credit">
	<label>
		<input
			type="checkbox"
			name="<?php echo esc_attr( $field_prefix . '[use]' ); ?>"
			value="1"
			<?php checked( $credit_applied ); ?>
		/>
		<?php esc_html_e( 'Use membership credit for this appointment', 'woocommerce-appointments' ); ?>
	</label>
	<?php if ( count( $subscriptions ) > 1 ) : ?>
		<select name="<?php echo esc_attr( $field_prefix . '[subscription_id]' ); ?>" class="wca-membership-subscription-select">
			<?php foreach ( $subscriptions as $subscription ) : ?>
				<?php
				$plan = WC_Appointments_Integration_Subscription_Entitlement::get_plan_product( $subscription );
				$name = $plan ? $plan->get_name() : sprintf( __( 'Subscription #%d', 'woocommerce-appointments' ), $subscription->get_id() );
				?>
			<option value="<?php echo esc_attr( (string) $subscription->get_id() ); ?>" <?php selected( $subscription->get_id(), $selected_id ); ?>>
				<?php
				echo esc_html(
					sprintf(
						'%1$s - %2$s',
						$name,
						WC_Appointments_Integration_Subscription_Entitlement::balance_label( $subscription )
					)
				);
				?>
			</option>
			<?php endforeach; ?>
		</select>
	<?php else : ?>
		<input type="hidden" name="<?php echo esc_attr( $field_prefix . '[subscription_id]' ); ?>" value="<?php echo esc_attr( (string) $selected_id ); ?>" />
		<span class="description">
			<?php
			$plan = WC_Appointments_Integration_Subscription_Entitlement::get_plan_product( $default_subscription );
			echo esc_html(
				sprintf(
					'%1$s: %2$s',
					$plan ? $plan->get_name() : __( 'Your membership', 'woocommerce-appointments' ),
					WC_Appointments_Integration_Subscription_Entitlement::balance_label( $default_subscription )
				)
			);
			?>
		</span>
	<?php endif; ?>
	<?php if ( is_cart() ) : ?>
		<span class="description wca-membership-cart-hint"><?php esc_html_e( 'Update cart to refresh the total.', 'woocommerce-appointments' ); ?></span>
	<?php endif; ?>
</div>
