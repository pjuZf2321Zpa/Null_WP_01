<?php
/**
 * Pay-first balance summary table
 *
 * Balance paid / series total / due rows in classic series emails and block email parts.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/emails/series-balance-summary.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @var string $text_align
 * @var bool   $bordered
 * @var string $cell_style
 * @var string $currency
 * @var float  $paid_upfront
 * @var float  $series_total
 * @var float  $balance_due
 * @var string $balance_pay_url
 * @var string $parent_order_number
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.4.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$parent_order_number = isset( $parent_order_number ) ? (string) $parent_order_number : '';

?>
<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; margin: 0 0 16px;" <?php echo $bordered ? 'border="1" bordercolor="#eee"' : 'border="1"'; ?>>
	<tbody>
		<?php if ( $paid_upfront > 0 ) : ?>
		<tr>
			<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( $cell_style ); ?>">
				<?php
				if ( $parent_order_number ) {
					printf(
						/* translators: %s: order number */
						esc_html__( 'Paid on order #%s', 'woocommerce-appointments' ),
						esc_html( $parent_order_number )
					);
				} else {
					esc_html_e( 'Paid today', 'woocommerce-appointments' );
				}
				?>
			</th>
			<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( $cell_style ); ?>">
				<?php echo wp_kses_post( wc_price( $paid_upfront, array( 'currency' => $currency ) ) ); ?>
			</td>
		</tr>
		<?php endif; ?>
		<?php if ( $series_total > 0 ) : ?>
		<tr>
			<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( $cell_style ); ?>">
				<?php esc_html_e( 'Series total', 'woocommerce-appointments' ); ?>
			</th>
			<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( $cell_style ); ?>">
				<?php echo wp_kses_post( wc_price( $series_total, array( 'currency' => $currency ) ) ); ?>
			</td>
		</tr>
		<?php endif; ?>
		<?php if ( $balance_due > 0 ) : ?>
		<tr>
			<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( $cell_style ); ?>">
				<?php esc_html_e( 'Remaining balance', 'woocommerce-appointments' ); ?>
			</th>
			<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;<?php echo esc_attr( $cell_style ); ?>">
				<?php echo wp_kses_post( wc_price( $balance_due, array( 'currency' => $currency ) ) ); ?>
				<?php esc_html_e( '— due before later appointments', 'woocommerce-appointments' ); ?>
				<?php if ( $balance_pay_url ) : ?>
					<br /><a href="<?php echo esc_url( $balance_pay_url ); ?>" style="font-weight: bold;">
						<?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?>
					</a>
				<?php endif; ?>
			</td>
		</tr>
		<?php endif; ?>
	</tbody>
</table>
