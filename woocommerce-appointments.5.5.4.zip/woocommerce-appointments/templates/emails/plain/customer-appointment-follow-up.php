<?php
/**
 * PLAIN Customer appointment follow-up email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/emails/plain/customer-appointment-follow-up.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.2.0
 * @since       4.8.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

echo '= ' . $email_heading . " =\n\n";

if ( $appointment->get_order() ) {
	/* translators: %s: billing first name */
	printf( __( 'Hello %s', 'woocommerce-appointments' ), ( is_callable( [ $appointment->get_order(), 'get_billing_first_name' ] ) ? $appointment->get_order()->get_billing_first_name() : $appointment->get_order()->billing_first_name ) ) . "\n\n";
}

/* translators: %1$s: appointment start date */
printf( __( 'Your appointment took place on %1$s.', 'woocommerce-appointments' ), $appointment->get_start_date_for_email( $appointment->get_effective_customer_timezone(), true ) );

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %s: appointment product title */
printf( __( 'Scheduled Product: %s', 'woocommerce-appointments' ), $appointment->get_product_name() ) . "\n";
/* translators: %s: appointment ID */
printf( __( 'Appointment ID: %s', 'woocommerce-appointments' ), $appointment->get_id() ) . "\n";
/* translators: %s: appointment start date */
printf( __( 'Appointment Date: %s', 'woocommerce-appointments' ), $appointment->get_start_date_for_email( $appointment->get_effective_customer_timezone(), true ) ) . "\n";
/* translators: %s: appointment duration */
printf( __( 'Appointment Duration: %s', 'woocommerce-appointments' ), $appointment->get_duration() ) . "\n";

$meeting_join = WC_Appointments_Meetings::get_my_account_join_context( $appointment )['url'];
if ( $meeting_join ) {
	printf( __( 'Join Meeting: %s', 'woocommerce-appointments' ), $meeting_join ) . "\n";
}
$is_admin = false;
wc_get_template( 'emails/parts/appointment-location-plain.php', compact( 'appointment', 'is_admin' ), 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
wc_get_template( 'emails/parts/appointment-resource-plain.php', compact( 'appointment', 'is_admin' ), 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
$staff = $appointment->get_staff_members( true );
if ( $appointment->has_staff() && $staff ) {
	/* translators: %s: appointment staff names */
	printf( __( 'Appointment Providers: %s', 'woocommerce-appointments' ), $staff ) . "\n";
}

echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/**
 * Show user-defined additonal content - this is set in each email's settings.
 */
if ( $additional_content ) {
	esc_html_e( wp_strip_all_tags( wptexturize( $additional_content ) ) );
	echo "\n\n----------------------------------------\n\n";
}

echo apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) );
