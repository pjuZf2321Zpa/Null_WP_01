<?php
/**
 * Pay-first balance summary (plain text)
 *
 * Balance paid / series total / due lines in plain-text series emails.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/emails/plain/series-balance-summary.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @var string $currency
 * @var float  $paid_upfront
 * @var float  $series_total
 * @var float  $balance_due
 * @var string $balance_pay_url
 * @var string $parent_order_number
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.4.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$parent_order_number = isset( $parent_order_number ) ? (string) $parent_order_number : '';

if ( $paid_upfront > 0 ) {
	$paid_label = $parent_order_number
		? sprintf(
			/* translators: %s: order number */
			__( 'Paid on order #%s:', 'woocommerce-appointments' ),
			$parent_order_number
		)
		: __( 'Paid today:', 'woocommerce-appointments' );
	echo esc_html( $paid_label ) . ' ' . wp_strip_all_tags( wc_price( $paid_upfront, array( 'currency' => $currency ) ) ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
if ( $series_total > 0 ) {
	echo esc_html__( 'Series total:', 'woocommerce-appointments' ) . ' ' . wp_strip_all_tags( wc_price( $series_total, array( 'currency' => $currency ) ) ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
if ( $balance_due > 0 ) {
	echo esc_html__( 'Remaining balance', 'woocommerce-appointments' ) . ': ' . wp_strip_all_tags( wc_price( $balance_due, array( 'currency' => $currency ) ) ) . ' ' . esc_html__( '— due before later appointments', 'woocommerce-appointments' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	if ( $balance_pay_url ) {
		echo esc_html__( 'Pay remaining balance:', 'woocommerce-appointments' ) . ' ' . esc_url( $balance_pay_url ) . "\n";
	}
}
echo "\n";
