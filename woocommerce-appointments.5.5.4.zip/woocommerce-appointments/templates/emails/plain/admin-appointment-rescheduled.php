<?php
/**
 * PLAIN Customer appointment confirmed email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/emails/plain/admin-appointment-rescheduled.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.2.5
 * @since       4.14.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

echo '= ' . $email_heading . " =\n\n";

echo __( 'The following appointment has been rescheduled by the customer. The details of the rescheduled appointment can be found below.', 'woocommerce-appointments' ) . "\n\n";

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %s: appointment product title */
printf( __( 'Scheduled Product: %s', 'woocommerce-appointments' ), $appointment->get_product_name() ) . "\n";
/* translators: %s: appointment ID */
printf( __( 'Appointment ID: %s', 'woocommerce-appointments' ), $appointment->get_id() ) . "\n";
/* translators: %s: appointment start date */
printf( __( 'Appointment Date: %s', 'woocommerce-appointments' ), $appointment->get_start_date_for_email( $email->recipient_timezone ?: wc_timezone_string(), true, null, null, 'admin' ) . " (prev: " . $prev_start_date . ")" ) . "\n";
/* translators: %s: appointment duration */
printf( __( 'Appointment Duration: %s', 'woocommerce-appointments' ), $appointment->get_duration() ) . "\n";

$_customer_tz_abbr = '';
if (
	class_exists( 'WC_Appointments_Timezone_Helper' ) &&
	'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' ) &&
	(bool) apply_filters( 'woocommerce_appointments_email_customer_timezone', true, $appointment, 'admin' )
) {
	$_customer_tz_abbr = WC_Appointments_Timezone_Helper::build_customer_timezone_abbr( $appointment, true, $email->recipient_timezone ?? '' );
}
if ( $_customer_tz_abbr ) {
	/* translators: %s: customer timezone e.g. 'New York (ET)' */
	printf( __( "Customer's Timezone: %s", 'woocommerce-appointments' ), $_customer_tz_abbr ) . "\n";
}

$meeting_join = WC_Appointments_Meetings::get_my_account_join_context( $appointment )['url'];
if ( $meeting_join ) {
	printf( __( 'Join Meeting: %s', 'woocommerce-appointments' ), $meeting_join ) . "\n";
}
$is_admin = true;
wc_get_template( 'emails/parts/appointment-location-plain.php', compact( 'appointment', 'is_admin' ), 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
wc_get_template( 'emails/parts/appointment-resource-plain.php', compact( 'appointment', 'is_admin' ), 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
$staff = $appointment->get_staff_members( true );
if ( $appointment->has_staff() && $staff ) {
	$_staff_tz_plain = '';
	if (
		class_exists( 'WC_Appointments_Timezone_Helper' ) &&
		'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' )
	) {
		$_staff_members = $appointment->get_staff_members();
		if ( $_staff_members ) {
			foreach ( (array) $_staff_members as $_sm ) {
				$_s_tz = WC_Appointments_Timezone_Helper::build_staff_timezone_abbr( $_sm->get_id(), $appointment, true, $email->recipient_timezone ?? '' );
				if ( $_s_tz ) {
					$_staff_tz_plain .= ' [' . $_s_tz . ']';
				}
			}
		}
	}
	/* translators: %s: appointment staff names */
	printf( __( 'Appointment Providers: %s', 'woocommerce-appointments' ), $staff . $_staff_tz_plain ) . "\n";
}

echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %s: a link to an appointment edit page */
echo make_clickable( sprintf( __( 'You can view and edit this appointment in the dashboard here: %s', 'woocommerce-appointments' ), admin_url( 'post.php?post=' . $appointment->get_id() . '&action=edit' ) ) );

echo apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) );
