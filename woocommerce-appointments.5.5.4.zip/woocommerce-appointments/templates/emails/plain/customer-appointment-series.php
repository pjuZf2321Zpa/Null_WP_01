<?php
/**
 * PLAIN Customer appointment series email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/emails/plain/customer-appointment-series.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.5.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$appointment_series    = ( isset( $appointment_series ) && $appointment_series instanceof WC_Appointment_Series ) ? $appointment_series : null;
$series_kind           = isset( $series_kind ) ? (string) $series_kind : '';
$affected_appointments = isset( $affected_appointments ) && is_array( $affected_appointments ) ? $affected_appointments : [];

echo '= ' . $email_heading . " =\n\n";

if ( WC_Appointment_Series_Email::KIND_CREATED === $series_kind ) {
	echo esc_html( $email->get_kind_intro( $series_kind ) ) . "\n\n";

	if ( $appointment_series && $appointment_series->has_open_balance() ) {
		$parent_order = $appointment_series->get_order_id() > 0 ? wc_get_order( $appointment_series->get_order_id() ) : null;
		WC_Appointment_Series_Email::render_balance_summary( $appointment_series, $parent_order, true );
	}
} elseif ( WC_Appointment_Series_Email::KIND_CANCELLED === $series_kind ) {
	echo esc_html( $email->get_kind_intro( $series_kind ) ) . "\n";
	if ( $email->get_scope_label() ) {
		echo esc_html( $email->get_scope_label() ) . "\n";
	}
	echo "\n";
} elseif ( WC_Appointment_Series_Email::KIND_STATUS_CHANGED === $series_kind ) {
	echo esc_html( $email->get_kind_intro( $series_kind ) ) . "\n";
	if ( $email->get_scope_label() ) {
		echo esc_html( $email->get_scope_label() ) . "\n";
	}
	if ( $email->get_status_label() ) {
		printf(
			/* translators: %s: new appointment status label */
			__( 'New status: %s', 'woocommerce-appointments' ),
			esc_html( $email->get_status_label() )
		);
		echo "\n";
	}
	echo "\n";
}

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

if ( ! empty( $email->placeholders['{appointment_series_pattern}'] ) ) {
	/* translators: %s: recurrence pattern summary */
	printf( __( 'Schedule: %s', 'woocommerce-appointments' ), esc_html( $email->placeholders['{appointment_series_pattern}'] ) ) . "\n\n";
}

$series_location = $appointment_series ? $appointment_series->get_meta( '_wca_location', true ) : [];
$product         = $appointment_series ? wc_get_product( $appointment_series->get_product_id() ) : null;
$show_location   = ! ( $product instanceof WC_Product_Appointment && WC_Appointments_Location::MODE_HIDDEN === $product->get_location_mode() );
$series_location_display = ( $show_location && is_array( $series_location ) && class_exists( 'WC_Appointments_Location' ) )
	? WC_Appointments_Location::format_snapshot_for_display( $series_location )
	: '';
if ( $series_location_display ) {
	printf(
		/* translators: 1: location field label, 2: location display */
		'%1$s: %2$s',
		esc_html( get_wc_appointment_data_label( 'location', $product ) ),
		esc_html( $series_location_display )
	) . "\n\n";
}

if ( ! empty( $affected_appointments ) ) {
	echo __( 'Appointments:', 'woocommerce-appointments' ) . "\n";
	foreach ( $affected_appointments as $appointment ) {
		$tz = $appointment->get_effective_customer_timezone();
		/* translators: 1: appointment ID, 2: start date/time */
		printf( __( 'Appointment #%1$s: %2$s', 'woocommerce-appointments' ), (int) $appointment->get_id(), esc_html( wp_strip_all_tags( $appointment->get_start_date_for_email( $tz, true ) ) ) ) . "\n";
	}
	echo "\n";
}

$manage_url = $email->get_manage_url();
if ( $manage_url ) {
	/* translators: %s: URL */
	printf( __( 'View series: %s', 'woocommerce-appointments' ), esc_url( $manage_url ) ) . "\n\n";
}

if ( $additional_content ) {
	echo esc_html( wp_strip_all_tags( $additional_content ) ) . "\n\n";
}

echo apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) );
