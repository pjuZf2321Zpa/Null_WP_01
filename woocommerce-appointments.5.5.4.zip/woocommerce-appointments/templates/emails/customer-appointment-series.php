<?php
/**
 * Customer appointment series email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/emails/customer-appointment-series.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.4.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$text_align            = is_rtl() ? 'right' : 'left';
$appointment_series    = ( isset( $appointment_series ) && $appointment_series instanceof WC_Appointment_Series ) ? $appointment_series : null;
$series_kind           = isset( $series_kind ) ? (string) $series_kind : '';
$affected_appointments = isset( $affected_appointments ) && is_array( $affected_appointments ) ? $affected_appointments : [];
?>

<?php do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<?php if ( WC_Appointment_Series_Email::KIND_CREATED === $series_kind ) : ?>

	<p><?php echo esc_html( $email->get_kind_intro( $series_kind ) ); ?></p>

	<?php
	if ( $appointment_series && $appointment_series->has_open_balance() ) {
		$parent_order = $appointment_series->get_order_id() > 0 ? wc_get_order( $appointment_series->get_order_id() ) : null;
		WC_Appointment_Series_Email::render_balance_summary( $appointment_series, $parent_order, (bool) $plain_text );
	}
	?>

<?php elseif ( WC_Appointment_Series_Email::KIND_CANCELLED === $series_kind ) : ?>

	<p><?php echo esc_html( $email->get_kind_intro( $series_kind ) ); ?></p>
	<?php if ( $email->get_scope_label() ) : ?>
		<p><strong><?php echo esc_html( $email->get_scope_label() ); ?></strong></p>
	<?php endif; ?>

<?php elseif ( WC_Appointment_Series_Email::KIND_STATUS_CHANGED === $series_kind ) : ?>

	<p><?php echo esc_html( $email->get_kind_intro( $series_kind ) ); ?></p>
	<?php if ( $email->get_scope_label() ) : ?>
		<p><strong><?php echo esc_html( $email->get_scope_label() ); ?></strong></p>
	<?php endif; ?>
	<?php if ( $email->get_status_label() ) : ?>
		<p>
			<?php
			printf(
				/* translators: %s: new appointment status label */
				esc_html__( 'New status: %s', 'woocommerce-appointments' ),
				esc_html( $email->get_status_label() )
			);
			?>
		</p>
	<?php endif; ?>

<?php endif; ?>

<?php if ( $appointment_series ) : ?>
	<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; margin:0 0 16px;" border="1">
		<tbody>
			<tr>
				<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
					<?php esc_html_e( 'Series', 'woocommerce-appointments' ); ?>
				</th>
				<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
					#<?php echo esc_html( (string) $appointment_series->get_id() ); ?>
				</td>
			</tr>
			<?php
			$product = wc_get_product( $appointment_series->get_product_id() );
			if ( $product ) :
				?>
				<tr>
					<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
						<?php esc_html_e( 'Scheduled Product', 'woocommerce-appointments' ); ?>
					</th>
					<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
						<?php echo wp_kses_post( $product->get_name() ); ?>
					</td>
				</tr>
			<?php endif; ?>
			<?php if ( ! empty( $email->placeholders['{appointment_series_pattern}'] ) ) : ?>
				<tr>
					<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
						<?php esc_html_e( 'Schedule', 'woocommerce-appointments' ); ?>
					</th>
					<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
						<?php echo esc_html( $email->placeholders['{appointment_series_pattern}'] ); ?>
					</td>
				</tr>
			<?php endif; ?>
			<?php
			$series_location = $appointment_series ? $appointment_series->get_meta( '_wca_location', true ) : [];
			$show_location   = ! ( isset( $product ) && $product instanceof WC_Product_Appointment && WC_Appointments_Location::MODE_HIDDEN === $product->get_location_mode() );
			$series_location_display = ( $show_location && is_array( $series_location ) && class_exists( 'WC_Appointments_Location' ) )
				? WC_Appointments_Location::format_snapshot_for_display( $series_location )
				: '';
			if ( $series_location_display ) :
				?>
				<tr>
					<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
						<?php echo esc_html( get_wc_appointment_data_label( 'location', isset( $product ) ? $product : null ) ); ?>
					</th>
					<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
						<?php echo esc_html( $series_location_display ); ?>
					</td>
				</tr>
			<?php endif; ?>
		</tbody>
	</table>
<?php endif; ?>

<?php echo wp_kses_post( $email->get_sessions_table_html() ); ?>

<?php
$manage_url = $email->get_manage_url();
if ( $manage_url ) :
	?>
	<p>
		<a href="<?php echo esc_url( $manage_url ); ?>"><?php esc_html_e( 'View series', 'woocommerce-appointments' ); ?></a>
	</p>
<?php endif; ?>

<?php if ( WC_Appointment_Series_Email::KIND_CANCELLED === $series_kind && $appointment_series && $appointment_series->get_order_id() > 0 ) : ?>
	<p><em><?php esc_html_e( 'Partial cancellations do not refund the order automatically. Contact us with questions.', 'woocommerce-appointments' ); ?></em></p>
<?php endif; ?>

<?php
/**
 * Additional content from email settings (below main content, above footer).
 * Block emails append the same text after ##WOO_CONTENT## via WC_Email_Appointment_Series::append_block_woo_additional_content().
 */
if ( $additional_content ) {
	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
}
?>

<?php do_action( 'woocommerce_email_footer', $email ); ?>
