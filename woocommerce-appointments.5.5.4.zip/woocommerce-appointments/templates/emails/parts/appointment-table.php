<?php
/**
 * Appointment table template.
 *
 * This template is used to display the appointment table in block emails.
 *
 * @since   5.3.8
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.5.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$appointment         = $email->object;
$email_preview       = 'email_preview' === $appointment->get_status();
$appointment_product = $appointment->get_product();
$text_align          = is_rtl() ? 'right' : 'left';
$is_admin_email      = isset( $email->id ) && 0 === strpos( (string) $email->id, 'admin_' );

if ( $email_preview ) {
	$product_title = __( 'Dummy Service', 'woocommerce-appointments' );
} elseif ( $appointment_product ) {
	$product_title = $appointment->get_product_name();
} else {
	$product_title = '';
}

$customer_tz = $appointment->get_effective_customer_timezone();
// Admin/staff recipient groups set recipient_timezone; customer emails fall back to customer TZ.
$display_tz = ( isset( $email->recipient_timezone ) && $email->recipient_timezone )
	? $email->recipient_timezone
	: $customer_tz;
?>
<table cellspacing="0" cellpadding="6" style="width: 100%; border: 1px solid #eee;" border="1" bordercolor="#eee">
	<tbody>
		<tr>
			<th scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php esc_html_e( 'Scheduled Product', 'woocommerce-appointments' ); ?></th>
			<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo esc_html( $product_title ); ?></td>
		</tr>
		<tr>
			<th style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;" scope="row"><?php esc_html_e( 'Appointment ID', 'woocommerce-appointments' ); ?></th>
			<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo esc_html( $appointment->get_id() ); ?></td>
		</tr>
		<tr>
			<th style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;" scope="row"><?php esc_html_e( 'Appointment Date', 'woocommerce-appointments' ); ?></th>
			<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo wp_kses_post( $appointment->get_start_date_for_email( $display_tz, false, null, null, $is_admin_email ? 'admin' : 'frontend' ) ); ?></td>
		</tr>
		<tr>
			<th style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;" scope="row"><?php esc_html_e( 'Appointment Duration', 'woocommerce-appointments' ); ?></th>
			<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo esc_html( $appointment->get_duration() ); ?></td>
		</tr>
		<?php
		if ( $is_admin_email && ! $email_preview ) :
			$_customer_tz_abbr = '';
			if (
				class_exists( 'WC_Appointments_Timezone_Helper' ) &&
				'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' ) &&
				(bool) apply_filters( 'woocommerce_appointments_email_customer_timezone', true, $appointment, 'admin' )
			) {
				$_customer_tz_abbr = WC_Appointments_Timezone_Helper::build_customer_timezone_abbr( $appointment, false, $display_tz );
			}
			if ( $_customer_tz_abbr ) :
				?>
				<tr>
					<th style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;" scope="row"><?php esc_html_e( "Customer's Timezone", 'woocommerce-appointments' ); ?></th>
					<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo wp_kses_post( $_customer_tz_abbr ); ?></td>
				</tr>
				<?php
			endif;
		endif;

		if ( ! $email_preview ) :
			$is_admin     = $is_admin_email;
			$meeting_join = WC_Appointments_Meetings::get_my_account_join_context( $appointment )['url'];
			if ( $meeting_join ) :
				?>
				<tr>
					<th style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;" scope="row"><?php esc_html_e( 'Join Meeting', 'woocommerce-appointments' ); ?></th>
					<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><a href="<?php echo esc_url( $meeting_join ); ?>"><?php esc_html_e( 'Open meeting', 'woocommerce-appointments' ); ?></a></td>
				</tr>
				<?php
			endif;
			wc_get_template( 'emails/parts/appointment-location-row.php', compact( 'appointment', 'text_align', 'is_admin' ), 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
			wc_get_template( 'emails/parts/appointment-resource-row.php', compact( 'appointment', 'text_align', 'is_admin' ), 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
		endif;
		if ( ! $email_preview && $appointment->has_staff() ) :
			$staff = $appointment->get_staff_members( true );
			if ( $staff ) :
				$staff_label = $appointment_product && $appointment_product->get_staff_label() ? $appointment_product->get_staff_label() : esc_html__( 'Appointment Providers', 'woocommerce-appointments' );
				$_staff_tz_abbrs = '';
				if (
					$is_admin_email &&
					class_exists( 'WC_Appointments_Timezone_Helper' ) &&
					'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' )
				) {
					$_staff_members = $appointment->get_staff_members();
					if ( $_staff_members ) {
						foreach ( (array) $_staff_members as $_sm ) {
							if ( ! $_sm instanceof WC_Product_Appointment_Staff ) {
								continue;
							}
							$_staff_tz_abbrs .= WC_Appointments_Timezone_Helper::build_staff_timezone_abbr( $_sm->get_id(), $appointment, false, $display_tz );
						}
					}
				}
				?>
				<tr>
					<th style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;" scope="row"><?php echo esc_html( $staff_label ); ?></th>
					<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo esc_html( $staff ); ?><?php echo wp_kses_post( $_staff_tz_abbrs ); ?></td>
				</tr>
				<?php
			endif;
		endif;
		?>
	</tbody>
</table>
