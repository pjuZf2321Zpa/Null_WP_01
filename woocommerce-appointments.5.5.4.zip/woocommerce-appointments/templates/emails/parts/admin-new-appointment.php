<?php
/**
 * Part template for Admin new appointment email.
 *
 * Used only for block emails (woocommerce_email_general_block_content). Greeting and intro
 * paragraphs belong in the editable block template (templates/emails/block/admin-new-appointment.php).
 *
 * @since   5.3.8
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$appointment   = $email->object;
$email_preview = 'email_preview' === $appointment->get_status();

$wc_order                = $appointment->get_order();
$is_pending_confirmation = ! $email_preview
	&& $appointment->has_status( [ 'pending-confirmation' ] )
	&& $wc_order
	&& wc_appointment_order_requires_confirmation( $wc_order );

wc_get_template(
	'emails/parts/appointment-table.php',
	[
		'email' => $email,
	],
	'woocommerce-appointments',
	WC_APPOINTMENTS_TEMPLATE_PATH
);

if ( $is_pending_confirmation ) :
	?>
<p><?php esc_html_e( 'This appointment is awaiting your approval. Please check it and inform the customer if the date is available or not.', 'woocommerce-appointments' ); ?></p>
<?php endif; ?>

<p>
<?php
echo make_clickable(
	sprintf(
		/* translators: %s: a link to an appointment edit page */
		esc_html__( 'You can view and edit this appointment in the dashboard here: %s', 'woocommerce-appointments' ),
		admin_url( 'post.php?post=' . $appointment->get_id() . '&action=edit' )
	)
);
?>
</p>
