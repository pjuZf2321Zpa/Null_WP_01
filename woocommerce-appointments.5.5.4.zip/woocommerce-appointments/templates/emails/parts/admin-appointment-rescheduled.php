<?php
/**
 * Part template for Admin appointment rescheduled email.
 *
 * Used only for block emails (woocommerce_email_general_block_content). Greeting and intro
 * paragraphs belong in the editable block template (templates/emails/block/admin-appointment-rescheduled.php).
 *
 * @since   5.3.8
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.5.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$appointment     = $email->object;
$text_align      = is_rtl() ? 'right' : 'left';
$prev_start_date = isset( $email->prev_start_date ) ? $email->prev_start_date : '';
$prev_end_date   = isset( $email->prev_end_date ) ? $email->prev_end_date : '';

if ( $prev_start_date || $prev_end_date ) :
	?>
<h3><?php esc_html_e( 'Previous Appointment Time', 'woocommerce-appointments' ); ?></h3>
<table cellspacing="0" cellpadding="6" style="width: 100%; border: 1px solid #eee;" border="1" bordercolor="#eee">
	<tbody>
		<?php if ( $prev_start_date ) : ?>
		<tr>
			<th scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php esc_html_e( 'Previous Start', 'woocommerce-appointments' ); ?></th>
			<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo esc_html( $prev_start_date ); ?></td>
		</tr>
		<?php endif; ?>
		<?php if ( $prev_end_date ) : ?>
		<tr>
			<th scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php esc_html_e( 'Previous End', 'woocommerce-appointments' ); ?></th>
			<td style="text-align:<?php echo esc_attr( $text_align ); ?>; border: 1px solid #eee;"><?php echo esc_html( $prev_end_date ); ?></td>
		</tr>
		<?php endif; ?>
	</tbody>
</table>
<?php endif; ?>

<h3><?php esc_html_e( 'New Appointment Details', 'woocommerce-appointments' ); ?></h3>

<?php
wc_get_template(
	'emails/parts/appointment-table.php',
	[
		'email' => $email,
	],
	'woocommerce-appointments',
	WC_APPOINTMENTS_TEMPLATE_PATH
);
?>

<p>
<?php
echo make_clickable(
	sprintf(
		/* translators: %s: a link to an appointment edit page */
		esc_html__( 'You can view and edit this appointment in the dashboard here: %s', 'woocommerce-appointments' ),
		admin_url( 'post.php?post=' . $appointment->get_id() . '&action=edit' )
	)
);
?>
</p>
