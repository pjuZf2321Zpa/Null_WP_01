<?php
/**
 * Appointment email resource row (HTML table).
 *
 * Expects: $appointment (WC_Appointment), $text_align (string), $is_admin (bool, optional).
 *
 * @package WooCommerce Appointments
 * @since 5.5.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $appointment ) || ! is_a( $appointment, 'WC_Appointment' ) || ! class_exists( 'WC_Appointments_Resource' ) ) {
	return;
}

$is_admin         = ! empty( $is_admin );
$resource_display = WC_Appointments_Resource::get_context_display( $appointment, $is_admin );
if ( '' === $resource_display ) {
	return;
}

$text_align = isset( $text_align ) ? $text_align : ( is_rtl() ? 'right' : 'left' );
?>
<tr>
	<th class="td" scope="row" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
		<?php echo esc_html( get_wc_appointment_data_label( 'resource', $appointment->get_product() ) ); ?>
	</th>
	<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
		<?php echo esc_html( $resource_display ); ?>
	</td>
</tr>
