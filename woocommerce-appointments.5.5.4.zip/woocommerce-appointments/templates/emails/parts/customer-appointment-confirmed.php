<?php
/**
 * Part template for Customer appointment confirmed email.
 *
 * Used only for block emails (woocommerce_email_general_block_content). Greeting and intro
 * paragraphs belong in the editable email-content block.
 *
 * Output order inside ##WOO_CONTENT## matches general-block-email.php: (1) this template —
 * appointment table, then optional payment line when the order is unpaid — (2) WooCommerce
 * core order details. Personalization tags are not processed inside this HTML (WC runs the
 * personalizer before merging ##WOO_CONTENT##); customize the payment line via
 * woocommerce_appointments_email_confirmed_payment_notice_html.
 *
 * @since   5.3.8
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$appointment = isset( $email->object ) && $email->object instanceof WC_Appointment ? $email->object : null;

wc_get_template(
	'emails/parts/appointment-table.php',
	[
		'email' => $email,
	],
	'woocommerce-appointments',
	WC_APPOINTMENTS_TEMPLATE_PATH
);

if ( ! $appointment ) {
	return;
}

$wc_order = $appointment->get_order();
if ( $wc_order && 'pending' === $wc_order->get_status() && 0 < $wc_order->get_total() ) {
	$default_notice = wp_kses_post(
		sprintf(
			/* translators: %s: checkout payment link (plain URL in plain text, or HTML anchor in HTML). */
			__( 'To pay for this appointment please use the following link: %s', 'woocommerce-appointments' ),
			'<a href="' . esc_url( $wc_order->get_checkout_payment_url() ) . '">' . esc_html__( 'Pay for appointment', 'woocommerce-appointments' ) . '</a>'
		)
	);

	/**
	 * Filter the payment notice HTML between the appointment summary and order details (block emails).
	 *
	 * @since 5.3.8
	 *
	 * @param string         $notice      Inner HTML for the payment line (passed through wp_kses_post).
	 * @param WC_Order    $wc_order    Order awaiting payment.
	 * @param WC_Appointment $appointment The appointment.
	 * @param WC_Email    $email       Email object.
	 */
	$notice = apply_filters( 'woocommerce_appointments_email_confirmed_payment_notice_html', $default_notice, $wc_order, $appointment, $email );

	if ( $notice ) {
		echo wp_kses_post( '<p>' . $notice . '</p>' );
	}
}
