<?php
/**
 * Part template for Customer appointment series email.
 *
 * Block emails only: greeting/intro are edited in the email-content block; series summary follows.
 *
 * @since   5.4.0
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.5.0
 */

defined( 'ABSPATH' ) || exit;

/** @var array<string, mixed> $view */

if ( empty( $view ) || ! is_array( $view ) ) {
	return;
}

if ( ! empty( $view['balance_series'] ) ) {
	WC_Appointment_Series_Email::render_balance_summary( $view['balance_series'], null, false, 'parts' );
}
?>

<table cellspacing="0" cellpadding="6" style="width: 100%; border: 1px solid #eee;" border="1" bordercolor="#eee">
	<tbody>
		<?php if ( ! empty( $view['product_name'] ) ) : ?>
			<tr>
				<th scope="row" style="text-align:<?php echo esc_attr( $view['text_align'] ); ?>; border: 1px solid #eee;"><?php esc_html_e( 'Scheduled Product', 'woocommerce-appointments' ); ?></th>
				<td style="text-align:<?php echo esc_attr( $view['text_align'] ); ?>; border: 1px solid #eee;"><?php echo esc_html( $view['product_name'] ); ?></td>
			</tr>
		<?php endif; ?>
		<?php if ( ! empty( $view['pattern'] ) ) : ?>
			<tr>
				<th scope="row" style="text-align:<?php echo esc_attr( $view['text_align'] ); ?>; border: 1px solid #eee;"><?php esc_html_e( 'Schedule', 'woocommerce-appointments' ); ?></th>
				<td style="text-align:<?php echo esc_attr( $view['text_align'] ); ?>; border: 1px solid #eee;"><?php echo esc_html( $view['pattern'] ); ?></td>
			</tr>
		<?php endif; ?>
		<?php if ( ! empty( $view['location_display'] ) ) : ?>
			<tr>
				<th scope="row" style="text-align:<?php echo esc_attr( $view['text_align'] ); ?>; border: 1px solid #eee;"><?php echo esc_html( ! empty( $view['location_label'] ) ? $view['location_label'] : __( 'Location', 'woocommerce-appointments' ) ); ?></th>
				<td style="text-align:<?php echo esc_attr( $view['text_align'] ); ?>; border: 1px solid #eee;"><?php echo esc_html( $view['location_display'] ); ?></td>
			</tr>
		<?php endif; ?>
	</tbody>
</table>

<?php echo wp_kses_post( $view['sessions_table_html'] ); ?>
