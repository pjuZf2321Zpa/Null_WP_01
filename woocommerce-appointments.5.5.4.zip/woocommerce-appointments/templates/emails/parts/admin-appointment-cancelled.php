<?php
/**
 * Part template for Admin appointment cancelled email.
 *
 * Used only for block emails (woocommerce_email_general_block_content). Greeting and intro
 * paragraphs belong in the editable block template (templates/emails/block/admin-appointment-cancelled.php).
 *
 * @since   5.3.8
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$appointment = $email->object;

wc_get_template(
	'emails/parts/appointment-table.php',
	[
		'email' => $email,
	],
	'woocommerce-appointments',
	WC_APPOINTMENTS_TEMPLATE_PATH
);
?>

<p>
<?php
echo make_clickable(
	sprintf(
		/* translators: %s: a link to an appointment edit page */
		esc_html__( 'You can view and edit this appointment in the dashboard here: %s', 'woocommerce-appointments' ),
		admin_url( 'post.php?post=' . $appointment->get_id() . '&action=edit' )
	)
);
?>
</p>
