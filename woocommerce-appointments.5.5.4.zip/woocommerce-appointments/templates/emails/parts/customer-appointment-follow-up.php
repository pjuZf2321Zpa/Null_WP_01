<?php
/**
 * Part template for Customer appointment follow-up email.
 *
 * Block emails only: greeting/intro are edited in the email-content block; appointment details follow.
 *
 * @since   5.3.8
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wc_get_template(
	'emails/parts/appointment-table.php',
	[ 'email' => $email ],
	'woocommerce-appointments',
	WC_APPOINTMENTS_TEMPLATE_PATH
);
