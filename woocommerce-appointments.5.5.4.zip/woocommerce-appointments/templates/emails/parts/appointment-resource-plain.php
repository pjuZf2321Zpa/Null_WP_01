<?php
/**
 * Appointment email resource line (plain text).
 *
 * Expects: $appointment (WC_Appointment), $is_admin (bool, optional).
 *
 * @package WooCommerce Appointments
 * @since 5.5.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $appointment ) || ! is_a( $appointment, 'WC_Appointment' ) || ! class_exists( 'WC_Appointments_Resource' ) ) {
	return;
}

$is_admin         = ! empty( $is_admin );
$resource_display = WC_Appointments_Resource::get_context_display( $appointment, $is_admin );
if ( '' === $resource_display ) {
	return;
}

echo esc_html( get_wc_appointment_data_label( 'resource', $appointment->get_product() ) ) . ': ' . esc_html( $resource_display ) . "\n";
