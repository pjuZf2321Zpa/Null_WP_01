<?php
/**
 * Admin new appointment email - Block template.
 *
 * This template can be overridden by editing it in the WooCommerce email editor.
 * Introductory copy uses personalization tags so it stays editable without duplicating
 * the dynamic content merged at ##WOO_CONTENT## (see general-block-email.php).
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 * @since   5.3.8
 */

use Automattic\WooCommerce\Internal\EmailEditor\BlockEmailRenderer;

defined( 'ABSPATH' ) || exit;

// phpcs:disable Squiz.PHP.EmbeddedPhp.ContentBeforeOpen -- removed to prevent empty new lines.
// phpcs:disable Squiz.PHP.EmbeddedPhp.ContentAfterEnd -- removed to prevent empty new lines.
?>

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php
/* translators: %s: appointment ID personalization token */
printf( esc_html__( 'New appointment: #%s', 'woocommerce-appointments' ), '<!--[woocommerce-appointments/id]-->' );
?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php
/* translators: %s: customer name personalization token */
printf( esc_html__( 'A new appointment has been made by %s. The details of this appointment are shown below.', 'woocommerce-appointments' ), '<!--[woocommerce-appointments/customer-name]-->' );
?></p>
<!-- /wp:paragraph -->

<!-- wp:woocommerce/email-content {"lock":{"move":false,"remove":true}} -->
<div class="wp-block-woocommerce-email-content"><?php echo esc_html( BlockEmailRenderer::WOO_EMAIL_CONTENT_PLACEHOLDER ); ?></div>
<!-- /wp:woocommerce/email-content -->
