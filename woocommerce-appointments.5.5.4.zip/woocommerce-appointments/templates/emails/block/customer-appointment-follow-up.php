<?php
/**
 * Customer appointment follow-up email - Block template.
 *
 * This template can be overridden by editing it in the WooCommerce email editor.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 * @since   5.3.8
 */

use Automattic\WooCommerce\Internal\EmailEditor\BlockEmailRenderer;

defined( 'ABSPATH' ) || exit;

// phpcs:disable Squiz.PHP.EmbeddedPhp.ContentBeforeOpen -- removed to prevent empty new lines.
// phpcs:disable Squiz.PHP.EmbeddedPhp.ContentAfterEnd -- removed to prevent empty new lines.
?>

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Thanks for your appointment!', 'woocommerce-appointments' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php
/* translators: %s: appointment start date personalization token */
printf( esc_html__( 'Your appointment took place on %s. The details of your appointment are shown below.', 'woocommerce-appointments' ), '<!--[woocommerce-appointments/start-date]-->' );
?></p>
<!-- /wp:paragraph -->

<!-- wp:woocommerce/email-content {"lock":{"move":false,"remove":true}} -->
<div class="wp-block-woocommerce-email-content"><?php echo esc_html( BlockEmailRenderer::WOO_EMAIL_CONTENT_PLACEHOLDER ); ?></div>
<!-- /wp:woocommerce/email-content -->
