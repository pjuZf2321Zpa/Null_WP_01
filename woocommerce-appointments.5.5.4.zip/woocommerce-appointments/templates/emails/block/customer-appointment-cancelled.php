<?php
/**
 * Customer appointment cancelled email - Block template.
 *
 * This template can be overridden by editing it in the WooCommerce email editor.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 * @since   5.3.8
 */

use Automattic\WooCommerce\Internal\EmailEditor\BlockEmailRenderer;

defined( 'ABSPATH' ) || exit;
?>

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Appointment Cancelled', 'woocommerce-appointments' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'We are sorry to say that your appointment could not be confirmed and has been cancelled. The details of the cancelled appointment are shown below.', 'woocommerce-appointments' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:woocommerce/email-content {"lock":{"move":false,"remove":true}} -->
<div class="wp-block-woocommerce-email-content"><?php echo esc_html( BlockEmailRenderer::WOO_EMAIL_CONTENT_PLACEHOLDER ); ?></div>
<!-- /wp:woocommerce/email-content -->
