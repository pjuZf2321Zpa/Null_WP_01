<?php
/**
 * Admin appointment rescheduled email - Block template.
 *
 * This template can be overridden by editing it in the WooCommerce email editor.
 * Introductory copy uses personalization tags so it stays editable without duplicating
 * the dynamic content merged at ##WOO_CONTENT## (see general-block-email.php).
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.3.8
 * @since   5.3.8
 */

use Automattic\WooCommerce\Internal\EmailEditor\BlockEmailRenderer;

defined( 'ABSPATH' ) || exit;

// phpcs:disable Squiz.PHP.EmbeddedPhp.ContentBeforeOpen -- removed to prevent empty new lines.
// phpcs:disable Squiz.PHP.EmbeddedPhp.ContentAfterEnd -- removed to prevent empty new lines.
?>

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Appointment Rescheduled', 'woocommerce-appointments' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'The following appointment has been rescheduled by the customer. The details of the rescheduled appointment can be found below.', 'woocommerce-appointments' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:woocommerce/email-content {"lock":{"move":false,"remove":true}} -->
<div class="wp-block-woocommerce-email-content"><?php echo esc_html( BlockEmailRenderer::WOO_EMAIL_CONTENT_PLACEHOLDER ); ?></div>
<!-- /wp:woocommerce/email-content -->
