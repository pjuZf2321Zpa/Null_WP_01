<?php
/**
 * Customer appointment series email - Block template.
 *
 * This template can be overridden by editing it in the WooCommerce email editor.
 * Dynamic series and order content is merged at ##WOO_CONTENT## (see general-block-email.php).
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce Appointments
 * @version 5.4.3
 * @since   5.4.0
 */

use Automattic\WooCommerce\Internal\EmailEditor\BlockEmailRenderer;

defined( 'ABSPATH' ) || exit;
?>

<!-- wp:heading -->
<h2 class="wp-block-heading"><?php echo esc_html__( 'Recurring appointments', 'woocommerce-appointments' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php esc_html_e( 'Recurring package update. Appointment details are below.', 'woocommerce-appointments' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:woocommerce/email-content {"lock":{"move":false,"remove":true}} -->
<div class="wp-block-woocommerce-email-content"><?php echo esc_html( BlockEmailRenderer::WOO_EMAIL_CONTENT_PLACEHOLDER ); ?></div>
<!-- /wp:woocommerce/email-content -->
