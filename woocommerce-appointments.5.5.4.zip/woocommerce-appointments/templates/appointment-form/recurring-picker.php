<?php
/**
 * Recurring series picker
 *
 * Recurring frequency, occurrence count, and payment model on the storefront appointment form.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/appointment-form/recurring-picker.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @var WC_Product_Appointment $product                 Appointable product.
 * @var string[]               $allowed_freqs         Allowed RRULE frequencies.
 * @var array<string, string>  $freq_labels           Frequency labels keyed by code.
 * @var array{min: int, max: int} $limits             Occurrence count limits.
 * @var string                 $default_repeat_freq   Default frequency code.
 * @var bool                   $multiple_freqs        More than one frequency available.
 * @var string[]               $payment_options       Allowed payment models.
 * @var string                 $default_payment_model Default payment model.
 * @var bool                   $show_payment_radios   Show payment model radios.
 * @var array<string, array{label: string, description: string}> $payment_copy Storefront payment copy.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.4.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

?>
<div class="wc-appointments-recurring-hook">
	<div
		class="wca-recurring-picker wc-appointments-recurring-picker"
		data-product-id="<?php echo esc_attr( (string) $product->get_id() ); ?>"
		data-recurring-mode="prepaid"
		data-default-freq="<?php echo esc_attr( $default_repeat_freq ); ?>"
	>

		<p class="form-field form-field-wide wca-recurring-toggle">
			<label for="wca_recurring_repeat">
				<input
					type="checkbox"
					id="wca_recurring_repeat"
					name="wca_recurring_repeat"
					value="1"
					class="wca-recurring-repeat"
					aria-controls="wca-recurring-schedule wca-recurring-detail wca-recurring-footer"
				/>
				<?php esc_html_e( 'Repeat this appointment', 'woocommerce-appointments' ); ?>
			</label>
		</p>

		<div id="wca-recurring-schedule" class="wca-recurring-schedule" hidden>
			<?php if ( $multiple_freqs ) : ?>
			<div class="wca-recurring-freq-row" role="radiogroup" aria-label="<?php esc_attr_e( 'Repeats', 'woocommerce-appointments' ); ?>">
				<div class="wca-recurring-freq-options">
					<?php foreach ( $allowed_freqs as $freq_code ) : ?>
					<label class="wca-recurring-freq-option">
						<input
							type="radio"
							name="wca_recurring_freq_select"
							value="<?php echo esc_attr( $freq_code ); ?>"
							class="wca-recurring-freq-radio"
							<?php checked( $freq_code, $default_repeat_freq ); ?>
							disabled
						/>
						<span class="button wca-recurring-freq-btn" role="presentation"><?php echo esc_html( $freq_labels[ $freq_code ] ); ?></span>
					</label>
					<?php endforeach; ?>
				</div>
			</div>
			<?php else : ?>
			<input type="hidden" name="wca_recurring_freq_select" value="<?php echo esc_attr( $default_repeat_freq ); ?>" class="wca-recurring-freq-value" />
			<?php endif; ?>

			<div class="wca-recurring-options">
				<div class="wca-recurring-col wca-recurring-col--every">
					<label class="wca-recurring-col-label wca-recurring-slot wca-recurring-slot--label" for="wca_recurring_interval">
						<?php esc_html_e( 'Every', 'woocommerce-appointments' ); ?>
					</label>
					<input
						type="number"
						id="wca_recurring_interval"
						name="wca_recurring_interval"
						min="1"
						max="12"
						value="1"
						class="wca-recurring-interval wca-recurring-slot wca-recurring-slot--input"
						aria-describedby="wca-interval-label"
						disabled
					/>
					<span id="wca-interval-label" class="wca-field-suffix wca-recurring-slot wca-recurring-slot--suffix"><?php esc_html_e( 'week', 'woocommerce-appointments' ); ?></span>
				</div>

				<div class="wca-recurring-col wca-recurring-col--sessions">
					<label class="wca-recurring-col-label wca-recurring-slot wca-recurring-slot--label" for="wca_recurring_count">
						<?php esc_html_e( 'For', 'woocommerce-appointments' ); ?>
					</label>
					<input
						type="number"
						id="wca_recurring_count"
						name="wca_recurring_count"
						min="<?php echo esc_attr( (string) $limits['min'] ); ?>"
						max="<?php echo esc_attr( (string) $limits['max'] ); ?>"
						value="<?php echo esc_attr( (string) $limits['max'] ); ?>"
						class="wca-recurring-count wca-recurring-slot wca-recurring-slot--input"
						disabled
					/>
					<span class="wca-field-suffix wca-recurring-slot wca-recurring-slot--suffix"><?php esc_html_e( 'appointments', 'woocommerce-appointments' ); ?></span>
				</div>
			</div>
		</div>

		<div id="wca-recurring-detail" class="wca-recurring-detail" hidden>
			<div class="wca-recurring-preview">
				<div class="wca-loading-bar" aria-hidden="true"></div>
				<p id="wca-preview-status" class="wca-preview-status" aria-live="polite"></p>
				<ul id="wca-preview-list" class="wca-preview-list"></ul>
			</div>
		</div>

		<div id="wca-recurring-footer" class="wca-recurring-footer" hidden>
			<?php if ( $show_payment_radios ) : ?>
			<div class="wca-recurring-freq-row wca-recurring-payment-row" role="radiogroup" aria-label="<?php esc_attr_e( 'Payment option', 'woocommerce-appointments' ); ?>">
				<div class="wca-recurring-freq-options">
					<?php
					foreach ( $payment_options as $model ) :
						if ( empty( $payment_copy[ $model ] ) ) {
							continue;
						}
						$copy = $payment_copy[ $model ];
						?>
					<label class="wca-recurring-freq-option wca-recurring-payment-option">
						<input
							type="radio"
							name="wca_payment_model"
							value="<?php echo esc_attr( $model ); ?>"
							class="wca-payment-model-radio"
							<?php checked( $model, $default_payment_model ); ?>
							disabled
						/>
						<span class="button wca-recurring-freq-btn" role="presentation">
							<span class="wca-recurring-payment-option-title"><?php echo esc_html( $copy['label'] ); ?></span>
							<span class="wca-recurring-payment-option-desc"><?php echo esc_html( $copy['description'] ); ?></span>
						</span>
					</label>
					<?php endforeach; ?>
				</div>
			</div>
			<?php else : ?>
			<input type="hidden" name="wca_payment_model" class="wca-payment-model-value" value="<?php echo esc_attr( $default_payment_model ); ?>" disabled />
			<?php endif; ?>
		</div>
	</div>
</div>
