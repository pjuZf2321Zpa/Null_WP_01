<?php
/**
 * Date and Time picker
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/appointment-form/datetime-picker.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.5.1
 * @since       3.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

wp_enqueue_script( 'wc-appointments-time-picker' ); #timepicker before datepicker, so events can be triggered
wp_enqueue_script( 'wc-appointments-date-picker' );
wp_enqueue_script( 'wc-appointments-appointment-form' );

// Fields located inside includes\appointment-form\class-wc-appointment-form-datetime-picker.php.
$class                = $field['class'];
$label                = $field['label'];
$name                 = $field['name'];
$default_availability = $field['default_availability'];
$min_date_js          = $field['min_date_js'];
$max_date_js          = $field['max_date_js'];
$default_date         = $field['default_date'];
$product_id           = $field['product_id'];
$duration_unit        = $field['duration_unit'];
$appointment_duration = $field['appointment_duration'];
$duration_minutes     = isset( $field['duration_minutes'] ) ? $field['duration_minutes'] : 0;
$availability_span    = $field['availability_span'];
$is_autoselect        = $field['is_autoselect'];
$timezone_conversion  = $field['timezone_conversion'];

// Embed first-month day_data so the calendar can paint without a second full WP AJAX round-trip.
$wca_product = get_wc_product_appointment( (int) $product_id );
if ( $wca_product instanceof WC_Product_Appointment ) {
	WC_Appointments_WC_Ajax::localize_initial_day_slots( $wca_product );
}

$month_before_day = strpos( __( 'F j, Y', 'woocommerce-appointments' ), 'F' ) < strpos( __( 'F j, Y', 'woocommerce-appointments' ), 'j' );

// Timezone setup for time-based durations.
$site_tzstring = wc_timezone_string();
$tzstring      = $site_tzstring;
$has_user_pref = false;

// Only show timezone selector for time-based durations (minute/hour).
$show_timezone = $timezone_conversion && in_array( $duration_unit, [ 'minute', 'hour' ], true );

// Priority when timezone selector is visible:
// 1. User preference (logged in), 2. Cookie (guests/session), 3. Site timezone.
if ( $show_timezone ) {
	if ( is_user_logged_in() && class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
		$user_tz_raw = WC_Appointments_Timezone_Helper::get_user_timezone_raw();
		if ( $user_tz_raw ) {
			$tzstring      = $user_tz_raw;
			$has_user_pref = true;
		}
	}
	if ( ! $has_user_pref && isset( $_COOKIE['appointments_time_zone'] ) && ! empty( $_COOKIE['appointments_time_zone'] ) ) {
		$tzstring = sanitize_text_field( wp_unslash( $_COOKIE['appointments_time_zone'] ) );
	}
}

$timezone_dropdown_selected = ( $has_user_pref || ( isset( $_COOKIE['appointments_time_zone'] ) && ! empty( $_COOKIE['appointments_time_zone'] ) ) ) ? $tzstring : '';

$tz_display    = $show_timezone && function_exists( 'wc_appointment_get_timezone_name' ) ? wc_appointment_get_timezone_name( $tzstring ) : '';

// Show timezone indicator when user's timezone differs from site timezone.
$tz_indicator = '';
if ( $show_timezone && $tzstring !== $site_tzstring ) {
	$tz_title = sprintf( '%s: %s - %s', __( 'Timezone', 'woocommerce-appointments' ), $tzstring, $tz_display );
	$tz_indicator = ' <span class="wca-booking-tz-indicator" title="' . esc_attr( $tz_title ) . '">' . esc_html( $tz_display ) . '</span>';
}

if ( $show_timezone ) {
	wp_enqueue_script( 'select2' );
	wp_enqueue_script( 'wc-appointments-timezone-picker' );
}
?>
<fieldset class="wc-appointments-date-picker <?php esc_attr_e( implode( ' ', $class ) ); ?>">
	<legend>
		<span class="label"><small class="wc-appointments-date-picker-choose-date"><?php esc_html_e( 'Choose...', 'woocommerce-appointments' ); ?></small></span>
	</legend>
	<div class="picker"
		data-default-availability="<?php echo $default_availability ? 'true' : 'false'; ?>"
		data-min_date="<?php echo ! empty( $min_date_js ) ? esc_attr( $min_date_js ) : 0; ?>"
		data-max_date="<?php esc_attr_e( $max_date_js ); ?>"
		data-default_date="<?php esc_attr_e( $default_date ); ?>"
		data-product_id="<?php esc_attr_e( $product_id ); ?>"
		data-duration_unit="<?php esc_attr_e( $duration_unit ); ?>"
		data-appointment_duration="<?php esc_attr_e( $appointment_duration ); ?>"
		data-duration_minutes="<?php esc_attr_e( $duration_minutes ); ?>"
		data-availability_span="<?php esc_attr_e( $availability_span ); ?>"
		data-is_autoselect="<?php esc_attr_e( $is_autoselect ); ?>"
		data-timezone_conversion="<?php esc_attr_e( $timezone_conversion ); ?>"
	></div>
	<div class="wc-appointments-date-picker-date-fields">
		<?php
        // woocommerce_appointments_mdy_format filter to choose between month/day/year and day/month/year format
		if ( $month_before_day && apply_filters( 'woocommerce_appointments_mdy_format', true ) ) :
        ?>
		<label>
			<input type="text" autocomplete="off" name="<?php esc_html_e( $name ); ?>_month" placeholder="<?php esc_html_e( 'mm', 'woocommerce-appointments' ); ?>" size="2" class="required_for_calculation appointment_date_month notranslate" />
			<span><?php esc_html_e( 'Month', 'woocommerce-appointments' ); ?></span>
		</label> / <label>
			<input type="text" autocomplete="off" name="<?php esc_html_e( $name ); ?>_day" placeholder="<?php esc_html_e( 'dd', 'woocommerce-appointments' ); ?>" size="2" class="required_for_calculation appointment_date_day notranslate" />
			<span><?php esc_html_e( 'Day', 'woocommerce-appointments' ); ?></span>
		</label>
		<?php else : ?>
		<label>
			<input type="text" autocomplete="off" name="<?php esc_html_e( $name ); ?>_day" placeholder="<?php esc_html_e( 'dd', 'woocommerce-appointments' ); ?>" size="2" class="required_for_calculation appointment_date_day notranslate" />
			<span><?php esc_html_e( 'Day', 'woocommerce-appointments' ); ?></span>
		</label> / <label>
			<input type="text" autocomplete="off" name="<?php esc_html_e( $name ); ?>_month" placeholder="<?php esc_html_e( 'mm', 'woocommerce-appointments' ); ?>" size="2" class="required_for_calculation appointment_date_month notranslate" />
			<span><?php esc_html_e( 'Month', 'woocommerce-appointments' ); ?></span>
		</label>
		<?php endif; ?>
		/ <label>
			<input type="text" autocomplete="off" value="<?php esc_html_e( date( 'Y' ) ); ?>" name="<?php esc_html_e( $name ); ?>_year" placeholder="<?php esc_html_e( 'YYYY', 'woocommerce-appointments' ); ?>" size="4" class="required_for_calculation appointment_date_year notranslate" />
			<span><?php esc_html_e( 'Year', 'woocommerce-appointments' ); ?></span>
		</label>
	</div>
</fieldset>
<!-- Selection info: shows selected date/time with timezone selector (between calendar and time slots) -->
<div class="form-field form-field-wide wc-appointments-selection-info-field">
	<div class="wc-appointments-slot-header<?php echo ! $show_timezone ? ' wc-appointments-slot-header--no-tz' : ''; ?>">
		<div class="wc-appointments-selection-info">
			<span class="wc-appointments-selection-placeholder"><?php esc_html_e( 'Choose a date above to see available time slots.', 'woocommerce-appointments' ); ?></span>
			<span class="wc-appointments-selection-date" style="display:none;"></span>
			<button type="button" class="wc-appointments-selection-clear wc-appointments-selection-clear-date" style="display:none;" title="<?php esc_attr_e( 'Clear date', 'woocommerce-appointments' ); ?>">&times;</button>
			<span class="wc-appointments-selection-time-prompt" style="display:none;"><?php esc_html_e( 'Select time below', 'woocommerce-appointments' ); ?></span>
			<span class="wc-appointments-selection-time" style="display:none;"></span>
			<button type="button" class="wc-appointments-selection-clear wc-appointments-selection-clear-time" style="display:none;" title="<?php esc_attr_e( 'Clear time', 'woocommerce-appointments' ); ?>">&times;</button>
		</div>
		<?php if ( $show_timezone ) : ?>
		<div class="wc-appointments-timezone-compact wc_appointments_field_timezone" data-has-user-pref="<?php echo esc_attr( $has_user_pref ? '1' : '0' ); ?>">
			<a class="selected-timezone" title="<?php esc_attr_e( 'Click to change timezone', 'woocommerce-appointments' ); ?>"><?php echo esc_html( $tz_display ); ?></a>
			<select name="wc_appointments_field_timezone" id="wc_appointments_field_timezone">
				<?php echo wc_appointments_wp_timezone_choice( $timezone_dropdown_selected ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</select>
		</div>
		<?php endif; ?>
	</div>
</div>
<div class="form-field form-field-wide wc-appointments-slots-container">
	<div class="wca-loading-bar"></div>
	<div class="slot-picker">
	</div>
	<input type="hidden" class="required_for_calculation notranslate" name="<?php esc_html_e( $name ); ?>_time" id="<?php esc_html_e( $name ); ?>" />
	<!-- TIMEZONE FIX: Hidden field to store original slot timestamp (site TZ) to avoid double conversion -->
	<input type="hidden" class="slot-timestamp-field notranslate" name="<?php esc_html_e( $name ); ?>_timestamp" id="<?php esc_html_e( $name ); ?>_timestamp" />
</div>
