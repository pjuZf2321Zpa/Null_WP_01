<?php
/**
 * LOCATION SELECT appointment form field
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/appointment-form/select-location.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.5.0
 * @since       5.5.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

wp_dequeue_script( 'selectWoo' );
wp_enqueue_script( 'select2' );
wp_enqueue_script( 'wc-appointments-staff-picker' );

// Fields located inside includes\appointment-form\class-wc-appointment-form.php
$class   = $field['class'];
$label   = $field['label'];
$name    = $field['name'];
$options = $field['options'];
?>
<p class="form-field form-field-wide <?php echo esc_attr( implode( ' ', (array) $class ) ); ?>">
	<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $label ); ?></label>
	<select name="<?php echo esc_attr( $name ); ?>" id="<?php echo esc_attr( $name ); ?>" required data-gate-msg="<?php echo esc_attr__( 'Choose a location to see available times.', 'woocommerce-appointments' ); ?>">
		<?php foreach ( $options as $key => $value ) : ?>
			<option value="<?php echo esc_attr( (string) $key ); ?>"><?php echo esc_html( $value ); ?></option>
		<?php endforeach; ?>
	</select>
</p>
