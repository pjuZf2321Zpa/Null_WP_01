<?php
/**
 * View recurring series
 *
 * Shows a single recurring series on My Account → view-series (details, occurrences, actions).
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/myaccount/view-series.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @var WC_Appointment_Series   $series                    Series being viewed.
 * @var string                  $timezone_indicator_html   Optional My Account timezone indicator.
 * @var string                  $status_message            Intro line (HTML allowed).
 * @var array<int, string[]>    $detail_rows               Label/value rows for the details table.
 * @var bool                    $has_actions               Whether the actions row is shown.
 * @var array<string, mixed>    $payment                   Payment snapshot from the series.
 * @var WC_Appointment[]        $appointments              Occurrence appointments.
 * @var WC_Product|null         $product                   Appointable product.
 * @var WC_Order|null           $order                     Parent checkout order.
 * @var string                  $series_url                My Account detail URL for this series.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.5.0
 * @since       5.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( empty( $series ) || ! $series instanceof WC_Appointment_Series ) {
	return;
}

wp_enqueue_script( 'wc-appointments-my-account' );

wc_print_notices();
?>
<p><?php echo wp_kses_post( $status_message ); ?></p>
<?php if ( $detail_rows || $has_actions ) : ?>
<table class="shop_table series_details">
	<tbody>
		<?php foreach ( $detail_rows as $row ) : ?>
			<tr>
				<td><?php echo esc_html( $row[0] ); ?></td>
				<td><?php echo wp_kses_post( $row[1] ); ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if ( $has_actions ) : ?>
			<tr>
				<td><?php esc_html_e( 'Actions', 'woocommerce-appointments' ); ?></td>
				<td>
					<?php if ( ! empty( $payment['has_open_balance'] ) ) : ?>
						<?php if ( ! empty( $payment['balance_pay_url'] ) ) : ?>
							<a class="woocommerce-button button alt anowrap" href="<?php echo esc_url( $payment['balance_pay_url'] ); ?>"><?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?></a>
						<?php else : ?>
							<?php
							WC_Appointment_Series_My_Account::render_post_action_form(
								$series,
								'pay_balance',
								__( 'Pay remaining balance', 'woocommerce-appointments' ),
								array( 'class' => 'woocommerce-button button alt anowrap' )
							);
							?>
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( $series->customer_can_cancel_series() ) : ?>
						<?php
						WC_Appointment_Series_My_Account::render_post_action_form(
							$series,
							'cancel_future',
							__( 'Cancel future', 'woocommerce-appointments' ),
							array(
								'class'   => 'woocommerce-button button anowrap cancel',
								'confirm' => __( 'Cancel all future appointments in this series?', 'woocommerce-appointments' ),
							)
						);
						?>
					<?php endif; ?>
				</td>
			</tr>
		<?php endif; ?>
		<?php do_action( 'woocommerce_appointments_series_details_after_table', $series ); ?>
	</tbody>
</table>
<?php endif; ?>

<?php if ( empty( $appointments ) ) : ?>
	<div class="woocommerce-Message woocommerce-Message--info woocommerce-info">
		<?php esc_html_e( 'No appointments have been scheduled for this series yet.', 'woocommerce-appointments' ); ?>
	</div>
	<?php return; ?>
<?php endif; ?>

<h3><?php esc_html_e( 'Appointments', 'woocommerce-appointments' ); ?></h3>
<table class="shop_table shop_table_responsive my_account_orders my_account_appointments series_appointments">
	<thead>
		<tr>
			<th scope="col" class="appointment-id"><span class="nobr"><?php esc_html_e( 'Appointment', 'woocommerce-appointments' ); ?></span></th>
			<th scope="col" class="appointment-when"><span class="nobr"><?php esc_html_e( 'When', 'woocommerce-appointments' ); ?><?php echo ! empty( $timezone_indicator_html ) ? wp_kses_post( $timezone_indicator_html ) : ''; ?></span></th>
			<th scope="col" class="scheduled-product"><span class="nobr"><?php esc_html_e( 'Scheduled', 'woocommerce-appointments' ); ?></span></th>
			<th scope="col" class="appointment-status"><span class="nobr"><?php esc_html_e( 'Status', 'woocommerce-appointments' ); ?></span></th>
			<th scope="col" class="appointment-actions"></th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $appointments as $appointment ) : ?>
			<?php
			$recurrence_id = (string) $appointment->get_meta( '_wca_recurrence_id' );
			$scheduled     = $appointment->get_product() ?: $product;
			$view_order    = class_exists( 'WC_Appointment_Series_Email' )
				? WC_Appointment_Series_Email::resolve_occurrence_order_for_customer( $appointment, $series )
				: ( $appointment->get_order() ?: $order );
			?>
			<tr>
				<td class="appointment-id anowrap" data-title="<?php esc_attr_e( 'Appointment', 'woocommerce-appointments' ); ?>">
					#<?php echo esc_html( (string) $appointment->get_id() ); ?>
					<?php if ( $view_order && 'pending-confirmation' !== $appointment->get_status() ) : ?>
						<a href="<?php echo esc_url( $view_order->get_view_order_url() ); ?>" class="adesc"><?php esc_html_e( 'Order', 'woocommerce-appointments' ); ?></a>
					<?php endif; ?>
				</td>
				<td class="appointment-when anowrap" data-title="<?php esc_attr_e( 'When', 'woocommerce-appointments' ); ?>">
					<?php echo esc_html( $appointment->get_start_date() ); ?>
					<span class="adesc"><?php echo esc_html( $appointment->get_duration() ); ?></span>
				</td>
				<td class="scheduled-product" data-title="<?php esc_attr_e( 'Scheduled', 'woocommerce-appointments' ); ?>">
					<?php if ( $scheduled && $scheduled->is_type( 'appointment' ) ) : ?>
						<a href="<?php echo esc_url( get_permalink( $scheduled->get_id() ) ); ?>"><?php echo esc_html( $scheduled->get_name() ); ?></a>
					<?php endif; ?>
				</td>
				<td class="appointment-status" data-title="<?php esc_attr_e( 'Status', 'woocommerce-appointments' ); ?>">
					<?php echo esc_html( wc_appointments_get_status_label( $appointment->get_status() ) ); ?>
				</td>
				<td class="appointment-actions" data-title="<?php esc_attr_e( 'Actions', 'woocommerce-appointments' ); ?>">
					<?php WC_Appointments_Meetings::render_my_account_join( $appointment ); ?>
					<?php if ( '' !== $recurrence_id && $series->customer_can_cancel_occurrence( $appointment ) ) : ?>
						<?php
						WC_Appointment_Series_My_Account::render_post_action_form(
							$series,
							'skip',
							__( 'Cancel', 'woocommerce-appointments' ),
							array(
								'class'   => 'woocommerce-button button anowrap cancel',
								'confirm' => __( 'Cancel this occurrence?', 'woocommerce-appointments' ),
								'hidden'  => array( 'wca_recurrence_id' => $recurrence_id ),
							)
						);
						?>
					<?php endif; ?>
					<?php if ( '' !== $recurrence_id && $series->customer_can_reschedule_occurrence( $appointment ) ) : ?>
						<a href="<?php echo esc_url( $appointment->get_reschedule_url( $series_url ) ); ?>" class="woocommerce-button button anowrap reschedule"><?php esc_html_e( 'Reschedule', 'woocommerce-appointments' ); ?></a>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
