<?php
/**
 * Recurring series table on My Account → Appointments.
 *
 * @package WooCommerce\Appointments\Templates
 * @version 5.4.0
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

$series_section  = isset( $series_section ) && is_array( $series_section ) ? $series_section : array();
$series_list     = isset( $series_section['series'] ) ? $series_section['series'] : array();
$series_page     = isset( $series_page ) ? max( 1, (int) $series_page ) : 1;
$series_per_page = isset( $series_per_page ) ? max( 1, (int) $series_per_page ) : 10;
$endpoint        = isset( $endpoint ) ? $endpoint : apply_filters( 'woocommerce_appointments_account_endpoint', 'appointments' );

if ( empty( $series_list ) ) {
	return;
}

$appointments_endpoint = apply_filters( 'woocommerce_appointments_account_endpoint', 'appointments' );
?>
<h3><?php esc_html_e( 'Recurring series', 'woocommerce-appointments' ); ?></h3>
<table class="shop_table shop_table_responsive my_account_orders my_account_series recurring_series_appointments">
	<thead>
		<tr>
			<th scope="col" class="series-package">
				<span class="nobr"><?php esc_html_e( 'Package', 'woocommerce-appointments' ); ?></span>
			</th>
			<th scope="col" class="series-status">
				<span class="nobr"><?php esc_html_e( 'Status', 'woocommerce-appointments' ); ?></span>
			</th>
			<th scope="col" class="series-balance">
				<span class="nobr"><?php esc_html_e( 'Balance', 'woocommerce-appointments' ); ?></span>
			</th>
			<th scope="col" class="series-actions"></th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $series_list as $series ) : ?>
			<?php
			if ( ! $series instanceof WC_Appointment_Series ) {
				continue;
			}
			$payment    = $series->get_payment_snapshot();
			$detail_url = WC_Appointment_Series_My_Account::get_url( $series->get_id() );
			$summary    = $series->get_pattern_summary();
			?>
			<tr>
				<td class="series-package" data-title="<?php esc_attr_e( 'Package', 'woocommerce-appointments' ); ?>">
					<a href="<?php echo esc_url( $detail_url ); ?>">
						<?php
						echo esc_html(
							$summary
								? $summary
								: sprintf(
									/* translators: %d: series id */
									__( 'Series #%d', 'woocommerce-appointments' ),
									$series->get_id()
								)
						);
						?>
					</a>
				</td>
				<td class="series-status" data-title="<?php esc_attr_e( 'Status', 'woocommerce-appointments' ); ?>">
					<?php echo esc_html( WC_Appointment_Series::get_status_label( $series->get_status() ) ); ?>
				</td>
				<td class="series-balance" data-title="<?php esc_attr_e( 'Balance', 'woocommerce-appointments' ); ?>">
					<?php if ( ! empty( $payment['has_open_balance'] ) ) : ?>
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: formatted balance amount */
								__( 'Balance due: %s', 'woocommerce-appointments' ),
								$payment['balance_due_formatted'] ?? (string) ( $payment['balance_due'] ?? '' )
							)
						);
						?>
					<?php else : ?>
						&mdash;
					<?php endif; ?>
				</td>
				<td class="series-actions appointment-actions" data-title="<?php esc_attr_e( 'Actions', 'woocommerce-appointments' ); ?>">
					<?php if ( ! empty( $payment['has_open_balance'] ) ) : ?>
						<?php if ( ! empty( $payment['balance_pay_url'] ) ) : ?>
							<a class="woocommerce-button button alt anowrap wca-series-balance-pay" href="<?php echo esc_url( $payment['balance_pay_url'] ); ?>">
								<?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?>
							</a>
						<?php else : ?>
							<a class="woocommerce-button button alt anowrap wca-series-balance-pay" href="<?php echo esc_url( $detail_url ); ?>">
								<?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?>
							</a>
						<?php endif; ?>
					<?php endif; ?>
					<a class="woocommerce-button button anowrap" href="<?php echo esc_url( $detail_url ); ?>">
						<?php esc_html_e( 'Manage', 'woocommerce-appointments' ); ?>
					</a>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<?php if ( $series_page > 1 || ! empty( $series_section['has_more'] ) ) : ?>
	<div class="woocommerce-pagination woocommerce-pagination--without-numbers woocommerce-Pagination wca-series-pagination">
		<?php if ( $series_page > 1 ) : ?>
			<a href="<?php echo esc_url( WC_Appointment_Series_My_Account::get_appointments_series_page_url( $series_page - 1 ) ); ?>" class="woocommerce-button woocommerce-button--previous woocommerce-Button woocommerce-Button--previous button"><?php esc_html_e( 'Previous', 'woocommerce-appointments' ); ?></a>
		<?php endif; ?>
		<?php if ( ! empty( $series_section['has_more'] ) ) : ?>
			<a href="<?php echo esc_url( WC_Appointment_Series_My_Account::get_appointments_series_page_url( $series_page + 1 ) ); ?>" class="woocommerce-button woocommerce-button--next woocommerce-Button woocommerce-Button--next button"><?php esc_html_e( 'Next', 'woocommerce-appointments' ); ?></a>
		<?php endif; ?>
	</div>
<?php endif; ?>
