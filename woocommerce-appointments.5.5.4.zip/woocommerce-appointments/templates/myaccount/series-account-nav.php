<?php
/**
 * Back link from series list/detail to Appointments (My Account).
 *
 * @package WooCommerce\Appointments\Templates
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Appointment_Series_My_Account' ) ) {
	return;
}
?>
<p class="wca-myaccount-series-nav">
	<a href="<?php echo esc_url( WC_Appointment_Series_My_Account::get_appointments_url() ); ?>">
		&larr; <?php esc_html_e( 'Back to appointments', 'woocommerce-appointments' ); ?>
	</a>
</p>
