<?php
/**
 * My Account — recurring series detail.
 *
 * @package WooCommerce\Appointments\Templates
 * @since   5.4.0
 *
 * @var WC_Appointment_Series $series
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $series ) || ! $series instanceof WC_Appointment_Series ) {
	return;
}

$payment       = $series->get_payment_snapshot();
$appointments  = $series->get_occurrence_appointments( 50 );
$version       = (int) $series->get_version();
$nonce_action  = 'wca_series_action_' . $series->get_id();
$is_active     = WC_Appointment_Series::STATUS_ACTIVE === $series->get_status();
$title         = $series->get_pattern_summary() ?: sprintf( __( 'Series #%d', 'woocommerce-appointments' ), $series->get_id() );

wc_get_template( 'myaccount/series-account-nav.php', array(), '', WC_APPOINTMENTS_TEMPLATE_PATH );
?>
<div class="wca-series-account">
	<h3><?php echo esc_html( $title ); ?></h3>
	<p><?php echo esc_html( WC_Appointment_Series::get_status_label( $series->get_status() ) ); ?></p>

	<?php if ( ! empty( $payment['has_open_balance'] ) ) : ?>
		<div class="wca-series-detail-balance">
			<p><?php echo esc_html( sprintf( __( 'Balance due: %s', 'woocommerce-appointments' ), $payment['balance_due_formatted'] ?? '' ) ); ?></p>
			<div class="wca-series-actions">
				<?php if ( ! empty( $payment['balance_pay_url'] ) ) : ?>
					<a class="woocommerce-button button alt" href="<?php echo esc_url( $payment['balance_pay_url'] ); ?>"><?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?></a>
				<?php else : ?>
					<form method="post">
						<?php wp_nonce_field( $nonce_action ); ?>
						<input type="hidden" name="wca_series_action" value="pay_balance" />
						<input type="hidden" name="wca_series_version" value="<?php echo esc_attr( (string) $version ); ?>" />
						<button type="submit" class="woocommerce-button button alt"><?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?></button>
					</form>
				<?php endif; ?>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( $is_active ) : ?>
		<form method="post" class="wca-series-actions">
			<?php wp_nonce_field( $nonce_action ); ?>
			<input type="hidden" name="wca_series_action" value="cancel_future" />
			<input type="hidden" name="wca_series_version" value="<?php echo esc_attr( (string) $version ); ?>" />
			<button type="submit" class="woocommerce-button button cancel" onclick="return confirm('<?php echo esc_js( __( 'Cancel all future appointments in this series?', 'woocommerce-appointments' ) ); ?>');"><?php esc_html_e( 'Cancel future', 'woocommerce-appointments' ); ?></button>
		</form>
	<?php endif; ?>

	<h4><?php esc_html_e( 'Occurrences', 'woocommerce-appointments' ); ?></h4>
	<?php if ( ! $appointments ) : ?>
		<p><?php esc_html_e( 'No appointments have been scheduled for this series yet.', 'woocommerce-appointments' ); ?></p>
	<?php else : ?>
		<ul class="wca-series-occ-list">
			<?php foreach ( $appointments as $appt ) : ?>
				<?php
				$recurrence_id = (string) $appt->get_meta( '_wca_recurrence_id' );
				$can_manage    = '' !== $recurrence_id && $series->customer_can_modify_occurrence( $appt );
				?>
				<li class="wca-series-occ-item">
					<span><?php echo esc_html( $appt->get_start_date() . ' (' . wc_appointments_get_status_label( $appt->get_status() ) . ')' ); ?></span>
					<?php if ( $can_manage ) : ?>
						<form method="post">
							<?php wp_nonce_field( $nonce_action ); ?>
							<input type="hidden" name="wca_series_action" value="skip" />
							<input type="hidden" name="wca_series_version" value="<?php echo esc_attr( (string) $version ); ?>" />
							<input type="hidden" name="wca_recurrence_id" value="<?php echo esc_attr( $recurrence_id ); ?>" />
							<button type="submit" class="woocommerce-button button" onclick="return confirm('<?php echo esc_js( __( 'Skip this occurrence?', 'woocommerce-appointments' ) ); ?>');"><?php esc_html_e( 'Skip', 'woocommerce-appointments' ); ?></button>
						</form>
						<form method="post" class="wca-series-occ-reschedule-form">
							<?php wp_nonce_field( $nonce_action ); ?>
							<input type="hidden" name="wca_series_action" value="reschedule" />
							<input type="hidden" name="wca_series_version" value="<?php echo esc_attr( (string) $version ); ?>" />
							<input type="hidden" name="wca_recurrence_id" value="<?php echo esc_attr( $recurrence_id ); ?>" />
							<input type="text" name="wca_new_start" value="<?php echo esc_attr( gmdate( 'Y-m-d H:i', $appt->get_start() ) ); ?>" placeholder="<?php esc_attr_e( 'YYYY-MM-DD HH:MM', 'woocommerce-appointments' ); ?>" required />
							<button type="submit" class="woocommerce-button button"><?php esc_html_e( 'Reschedule', 'woocommerce-appointments' ); ?></button>
						</form>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
