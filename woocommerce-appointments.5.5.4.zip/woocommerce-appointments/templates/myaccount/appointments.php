<?php
/**
 * My Appointments
 *
 * Shows customer appointments on My Account → Appointments. Also embeds appointment tables
 * elsewhere (e.g. credited appointments on View Subscription) when `table_only` is set.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce-appointments/myaccount/appointments.php.
 *
 * HOWEVER, on occasion we will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @version     5.5.0
 * @since       3.4.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$table_only            = ! empty( $table_only );
$wrap_section          = ! empty( $wrap_section );
$pagination_prev_url   = isset( $pagination_prev_url ) ? $pagination_prev_url : '';
$pagination_next_url   = isset( $pagination_next_url ) ? $pagination_next_url : '';
$has_tables            = ! empty( $tables );
$series_section        = isset( $series_section ) && is_array( $series_section ) ? $series_section : array();
$series_page           = isset( $series_page ) ? max( 1, (int) $series_page ) : 1;
$series_list           = ! empty( $series_section['series'] ) ? $series_section['series'] : array();
$has_series            = ! empty( $series_list );
$membership_summaries  = isset( $membership_summaries ) && is_array( $membership_summaries ) ? $membership_summaries : array();
$has_memberships       = ! empty( $membership_summaries );
$membership_book_url   = isset( $membership_book_url ) ? $membership_book_url : '';
$memberships_view_url  = isset( $memberships_view_url ) ? $memberships_view_url : '';
?>
<?php if ( ! $table_only ) : ?>
<noscript>
	<?php
	esc_html_e(
		'Your browser must support JavaScript in order to schedule an appointment.',
		'woocommerce-appointments',
	);
	?>
</noscript>
<?php
wp_enqueue_script( 'wc-appointments-my-account' );

if ( $has_memberships ) :
	?>
	<div class="woocommerce-Message woocommerce-Message--info woocommerce-info wca-membership-notice">
		<?php if ( $membership_book_url ) : ?>
			<a class="woocommerce-Button button" href="<?php echo esc_url( $membership_book_url ); ?>">
				<?php esc_html_e( 'Book appointment', 'woocommerce-appointments' ); ?>
			</a>
		<?php endif; ?>
		<?php foreach ( $membership_summaries as $index => $summary ) : ?>
			<?php if ( $index > 0 ) : ?>
				<br />
			<?php endif; ?>
			<strong><?php echo esc_html( $summary['plan_name'] ); ?></strong>
			<span class="adesc">
				<?php echo esc_html( $summary['balance_label'] ); ?>
				<?php if ( ! empty( $summary['renewal_label'] ) ) : ?>
					<?php echo esc_html( ' · ' . $summary['renewal_label'] ); ?>
				<?php endif; ?>
				<?php if ( ! empty( $summary['status_note'] ) ) : ?>
					<?php echo esc_html( ' · ' . $summary['status_note'] ); ?>
				<?php endif; ?>
			</span>
		<?php endforeach; ?>
		<?php if ( $memberships_view_url ) : ?>
			<br />
			<a class="adesc" href="<?php echo esc_url( $memberships_view_url ); ?>"><?php esc_html_e( 'View memberships', 'woocommerce-appointments' ); ?></a>
		<?php endif; ?>
	</div>
	<?php
endif;
endif;
?>

<?php if ( ! $table_only && $has_series ) : ?>
	<h3><?php esc_html_e( 'Recurring series', 'woocommerce-appointments' ); ?></h3>
	<table class="shop_table shop_table_responsive my_account_orders my_account_appointments recurring_series_appointments">
		<thead>
			<tr>
				<th scope="col" class="series-id"><span class="nobr"><?php esc_html_e( 'Series', 'woocommerce-appointments' ); ?></span></th>
				<th scope="col" class="appointment-when"><span class="nobr"><?php esc_html_e( 'When', 'woocommerce-appointments' ); ?><?php echo ! empty( $timezone_indicator_html ) ? wp_kses_post( $timezone_indicator_html ) : ''; ?></span></th>
				<th scope="col" class="scheduled-product"><span class="nobr"><?php esc_html_e( 'Scheduled', 'woocommerce-appointments' ); ?></span></th>
				<th scope="col" class="appointment-status"><span class="nobr"><?php esc_html_e( 'Status', 'woocommerce-appointments' ); ?></span></th>
				<th scope="col" class="appointment-actions"></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $series_list as $series ) : ?>
				<?php
				if ( ! $series instanceof WC_Appointment_Series ) {
					continue;
				}
				$payment    = $series->get_payment_snapshot();
				$detail_url = WC_Appointment_Series_My_Account::get_url( $series->get_id() );
				$product    = $series->get_appointable_product();
				?>
				<tr>
					<td class="series-id anowrap" data-title="<?php esc_attr_e( 'Series', 'woocommerce-appointments' ); ?>">
						<a href="<?php echo esc_url( $detail_url ); ?>">#<?php echo esc_html( (string) $series->get_id() ); ?></a>
					</td>
					<td class="appointment-when" data-title="<?php esc_attr_e( 'When', 'woocommerce-appointments' ); ?>">
						<?php
						$summary = $series->get_pattern_summary();
						echo $summary ? esc_html( $summary ) : '&mdash;';
						?>
					</td>
					<td class="scheduled-product" data-title="<?php esc_attr_e( 'Scheduled', 'woocommerce-appointments' ); ?>">
						<?php if ( $product ) : ?>
							<a href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>"><?php echo esc_html( $product->get_name() ); ?></a>
						<?php endif; ?>
					</td>
					<td class="appointment-status" data-title="<?php esc_attr_e( 'Status', 'woocommerce-appointments' ); ?>">
						<?php echo esc_html( WC_Appointment_Series::get_status_label( $series->get_status() ) ); ?>
					</td>
					<td class="appointment-actions" data-title="<?php esc_attr_e( 'Actions', 'woocommerce-appointments' ); ?>">
						<?php if ( ! empty( $payment['has_open_balance'] ) ) : ?>
							<a class="woocommerce-button button alt anowrap" href="<?php echo esc_url( ! empty( $payment['balance_pay_url'] ) ? $payment['balance_pay_url'] : $detail_url ); ?>"><?php esc_html_e( 'Pay remaining balance', 'woocommerce-appointments' ); ?></a>
						<?php endif; ?>
						<a class="woocommerce-button button anowrap" href="<?php echo esc_url( $detail_url ); ?>"><?php esc_html_e( 'View', 'woocommerce-appointments' ); ?></a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php if ( $series_page > 1 || ! empty( $series_section['has_more'] ) ) : ?>
		<?php do_action( 'woocommerce_before_account_appointments_pagination' ); ?>
		<div class="woocommerce-pagination woocommerce-pagination--without-numbers woocommerce-Pagination">
			<?php if ( $series_page > 1 ) : ?>
				<a href="<?php echo esc_url( WC_Appointment_Series_My_Account::get_appointments_series_page_url( $series_page - 1 ) ); ?>" class="woocommerce-button woocommerce-button--previous woocommerce-Button woocommerce-Button--previous button"><?php esc_html_e( 'Previous', 'woocommerce-appointments' ); ?></a>
			<?php endif; ?>
			<?php if ( ! empty( $series_section['has_more'] ) ) : ?>
				<a href="<?php echo esc_url( WC_Appointment_Series_My_Account::get_appointments_series_page_url( $series_page + 1 ) ); ?>" class="woocommerce-button woocommerce-button--next woocommerce-Button woocommerce-Button--next button"><?php esc_html_e( 'Next', 'woocommerce-appointments' ); ?></a>
			<?php endif; ?>
		</div>
		<?php do_action( 'woocommerce_after_account_appointments_pagination' ); ?>
	<?php endif; ?>
<?php endif; ?>

<?php if ( $has_tables ) :
	foreach ( $tables as $table_id => $table ) :
		$i = 0;
		if ( $wrap_section ) :
			?>
		<section class="woocommerce-order-details wca-membership-redemptions">
			<h2><?php echo esc_html( $table['header'] ); ?></h2>
		<?php else : ?>
		<h3><?php echo esc_html( $table['header'] ); ?></h3>
		<?php endif; ?>
		<table class="shop_table shop_table_responsive my_account_orders my_account_appointments <?php echo esc_attr( $table_id ); ?>_appointments">
			<thead>
				<tr>
					<th scope="col" class="appointment-id"><span class="nobr"><?php esc_html_e( 'Appointment', 'woocommerce-appointments' ); ?></span></th>
					<th scope="col" class="appointment-when"><span class="nobr"><?php esc_html_e( 'When', 'woocommerce-appointments' ); ?></span></th>
					<th scope="col" class="scheduled-product"><span class="nobr"><?php esc_html_e( 'Scheduled', 'woocommerce-appointments' ); ?></span></th>
					<th scope="col" class="appointment-status"><span class="nobr"><?php esc_html_e( 'Status', 'woocommerce-appointments' ); ?></span></th>
					<th scope="col" class="appointment-actions"></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ( $table['appointments'] as $appointment ) :
					$i++;
					if ( $i > $appointments_per_page ) {
						break;
					}
					$status        = $appointment->get_status();
					$not_closed    = 'cancelled' !== $status && 'completed' !== $status;
					$cancellable   = $not_closed && ! $appointment->passed_cancel_day();
					$reschedulable = $not_closed && ! $appointment->passed_reschedule_day();
					$product       = $appointment->get_product();
					$order         = $appointment->get_order();
					$duration_unit = $appointment->get_duration_unit();
					$show_tz       = ! empty( $timezone_indicator_html )
						&& WC_Appointments_Constants::DURATION_DAY !== $duration_unit
						&& WC_Appointments_Constants::DURATION_MONTH !== $duration_unit;
					?>
					<tr>
						<td class="appointment-id anowrap" data-title="<?php esc_attr_e( 'Appointment', 'woocommerce-appointments' ); ?>">
							<?php
							printf( '#%d', esc_attr( $appointment->get_id() ) );
							if ( $order ) :
								printf(
									'<a href="%1$s" class="adesc">%2$s</a>',
									esc_url( $order->get_view_order_url() ),
									esc_html__( 'Order', 'woocommerce-appointments' )
								);
							endif;
							?>
						</td>
						<td class="appointment-when anowrap" data-title="<?php esc_attr_e( 'When', 'woocommerce-appointments' ); ?>">
							<?php
							esc_attr_e( $appointment->get_start_date() );
							echo $show_tz ? $timezone_indicator_html : '';
							?>
							<span class="adesc"><?php esc_attr_e( $appointment->get_duration() ); ?></span>
						</td>
						<td class="scheduled-product" data-title="<?php esc_attr_e( 'Scheduled', 'woocommerce-appointments' ); ?>">
							<?php if ( $product && $product->is_type( 'appointment' ) ) : ?>
								<a href="<?php echo esc_url( get_permalink( $appointment->get_product_id() ) ); ?>"><?php esc_html_e( $appointment->get_product_name() ); ?></a>
							<?php endif; ?>
						</td>
						<td class="appointment-status" data-title="<?php esc_attr_e( 'Status', 'woocommerce-appointments' ); ?>">
							<?php esc_html_e( wc_appointments_get_status_label( $status ) ); ?>
						</td>
						<td class="appointment-actions" data-title="<?php esc_attr_e( 'Actions', 'woocommerce-appointments' ); ?>">
							<?php WC_Appointments_Meetings::render_my_account_join( $appointment ); ?>
							<?php if ( $cancellable ) : ?>
								<a href="<?php echo esc_url( $appointment->get_cancel_url() ); ?>" class="woocommerce-button button anowrap cancel"><?php esc_html_e( 'Cancel', 'woocommerce-appointments' ); ?></a>
							<?php endif; ?>
							<?php if ( $reschedulable ) : ?>
								<a href="<?php echo esc_url( $appointment->get_reschedule_url() ); ?>" class="woocommerce-button button anowrap reschedule"><?php esc_html_e( 'Reschedule', 'woocommerce-appointments' ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		$show_prev = $pagination_prev_url || ( ! $pagination_prev_url && 1 !== $page );
		$show_next = $pagination_next_url || ( ! $pagination_next_url && count( $table['appointments'] ) > $appointments_per_page );
		if ( $show_prev || $show_next ) :
			?>
		<?php do_action( 'woocommerce_before_account_appointments_pagination' ); ?>
		<div class="woocommerce-pagination woocommerce-pagination--without-numbers woocommerce-Pagination">
			<?php if ( $show_prev ) : ?>
				<a href="<?php echo esc_url( $pagination_prev_url ? $pagination_prev_url : wc_get_endpoint_url( $endpoint, $page - 1 ) ); ?>" class="woocommerce-button woocommerce-button--previous woocommerce-Button woocommerce-Button--previous button"><?php esc_html_e( 'Previous', 'woocommerce-appointments' ); ?></a>
			<?php endif; ?>
			<?php if ( $show_next ) : ?>
				<a href="<?php echo esc_url( $pagination_next_url ? $pagination_next_url : wc_get_endpoint_url( $endpoint, $page + 1 ) ); ?>" class="woocommerce-button woocommerce-button--next woocommerce-Button woocommerce-Button--next button"><?php esc_html_e( 'Next', 'woocommerce-appointments' ); ?></a>
			<?php endif; ?>
		</div>
		<?php do_action( 'woocommerce_after_account_appointments_pagination' ); ?>
		<?php endif; ?>
		<?php if ( $wrap_section ) : ?>
		</section>
		<?php endif; ?>
	<?php endforeach; ?>
<?php endif; ?>

<?php if ( ! $table_only && ! $has_tables && ! $has_series && ! $has_memberships ) : ?>
	<div class="woocommerce-Message woocommerce-Message--info woocommerce-info">
		<a class="woocommerce-Button button" href="<?php echo esc_url( $membership_book_url ? $membership_book_url : apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">
			<?php esc_html_e( 'Book', 'woocommerce-appointments' ); ?>
		</a>
		<?php esc_html_e( 'No appointments scheduled yet.', 'woocommerce-appointments' ); ?>
	</div>
<?php endif; ?>
