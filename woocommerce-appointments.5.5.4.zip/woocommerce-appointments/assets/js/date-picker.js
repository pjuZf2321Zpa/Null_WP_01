/* globals _, wc_appointments_date_picker_args, wc_appointment_form_params, wca_get_querystring, wca_is_valid_date, rrule, wcaShared */

/**
 * ============================================================================
 * TIMEZONE ARCHITECTURE - CRITICAL FOR DEVELOPERS
 * ============================================================================
 *
 * This file handles frontend date selection in the SITE TIMEZONE.
 *
 * KEY CONCEPT: Timestamps in WooCommerce Appointments are stored as UTC Unix
 * timestamps that SEMANTICALLY REPRESENT site timezone times. This means we
 * extract time components using LOCAL methods (getHours, getDate, etc.) rather
 * than UTC methods.
 *
 * RULE FOR THIS FILE:
 * ✅ USE: getHours(), getDate(), getMonth(), getFullYear() for date comparisons
 * ✅ USE: new Date(year, month, day) for date creation (local timezone)
 * ❌ DO NOT USE: getUTCHours(), getUTCDate() for extracting display values
 *
 * DST HANDLING:
 * The HOUR_OFFSET constant (set to 12) is used to avoid midnight boundary issues
 * during DST transitions. When comparing dates, we set hours to noon instead of
 * midnight to prevent day-shift bugs when clocks spring forward or fall back.
 *
 * See docs/TIMEZONE_ARCHITECTURE.md for full explanation.
 * See docs/plans/TIMEZONE_MANAGEMENT_PLAN.md for DST edge cases.
 *
 * DO NOT "FIX" THIS BY ADDING TIMEZONE CONVERSIONS - IT WILL BREAK DATE SELECTION!
 * ============================================================================
 */

/*
 * Offset for dates to avoid comparing them at midnight. Browsers are inconsistent with how they
 * handle midnight time right before a DST time change.
 *
 * WHY NOON (12): During spring DST transition, 00:00 might become 23:00 of the previous day
 * or 01:00 depending on browser implementation. Using noon avoids this ambiguity entirely.
 */
var HOUR_OFFSET = 12;

// globally accessible for tests
let wc_appointments_date_picker = {};

// Initialize immediately if DOM is ready, otherwise wait for DOMContentLoaded
// This ensures calendar loads independently of images and other resources
// Wrapped in error handling to prevent errors in other scripts from breaking the calendar
( function() {
	'use strict';

	/**
	 * Effective customer IANA timezone for a form: product select first, then cookie.
	 * Keeps calendar AJAX (including cache keys) aligned with the visible timezone.
	 */
	function getEffectiveCustomerTimezoneString( $form ) {
		if ( ! $form || ! $form.length ) {
			return '';
		}
		var picker = $form.find( '.picker:eq(0)' );
		if ( ! picker.length || ! picker.attr( 'data-timezone_conversion' ) ) {
			return '';
		}
		var sel = $form.find( 'select#wc_appointments_field_timezone, select[name="wc_appointments_field_timezone"]' );
		if ( sel.length && sel.val() ) {
			return sel.val();
		}
		if ( typeof wca_get_cookie === 'function' ) {
			var raw = wca_get_cookie( 'appointments_time_zone' );
			if ( raw ) {
				return decodeURIComponent( raw );
			}
		}
		return '';
	}

	/**
	 * Format a local Date as civil Y-m-d (no timezone conversion).
	 *
	 * @param {Date} date Local calendar date.
	 * @return {string} YYYY-MM-DD
	 */
	function wcaFormatYmd( date ) {
		var y = date.getFullYear();
		var m = String( date.getMonth() + 1 ).padStart( 2, '0' );
		var d = String( date.getDate() ).padStart( 2, '0' );
		return y + '-' + m + '-' + d;
	}

	function formNeedsLocation( form ) {
		var $loc = form.find( '#wc_appointments_field_location, .wc_appointment_field_location select' ).first();
		return $loc.length > 0 && ! ( parseInt( $loc.val(), 10 ) > 0 );
	}

	function setCalendarLoading( form, active ) {
		var $fieldset = form.find( '.wc-appointments-date-picker' ).first();
		if ( ! $fieldset.length ) {
			return;
		}
		if ( ! $fieldset.children( '.wca-loading-bar' ).length ) {
			$fieldset.prepend( '<div class="wca-loading-bar" aria-hidden="true"></div>' );
		}
		$fieldset.toggleClass( 'is-loading', !! active );
		$fieldset.children( '.wca-loading-bar' ).toggleClass( 'is-active', !! active );
	}

	// Function to initialize the date picker
	function initDatePicker( $ ) {
	var startDate;
	var endDate;
	var currentDateRange                    = {};
	var wc_appointments_date_picker_object  = {
		/**
		 * Whether availability autoselect is on for this picker (`data-is_autoselect="1"`).
		 *
		 * @param {jQuery} picker Calendar picker element.
		 * @return {boolean}
		 */
		is_autoselect: function( picker ) {
			return '1' === String( picker.attr( 'data-is_autoselect' ) );
		},

		init: function() {
			$( 'body' ).on( 'change', '#wc_appointments_field_staff', this.staff_calendar );
			$( 'body' ).on( 'change', '#wc_appointments_field_location, #wc_appointments_field_resource', this.dependent_field_calendar );
			$( 'body' ).on( 'click', '.wc-appointments-date-picker legend small.wc-appointments-date-picker-choose-date', this.toggle_calendar );
			$( 'body' ).on( 'click', '.appointment_date_year, .appointment_date_month, .appointment_date_day', this.open_calendar );
			$( 'body' ).on( 'input', '.appointment_date_year, .appointment_date_month, .appointment_date_day', this.input_date_trigger );
			$( 'body' ).on( 'change', '.appointment_to_date_year, .appointment_to_date_month, .appointment_to_date_day', this.input_date_trigger );

			// Clear date button handler
			$( 'body' ).on( 'click', '.wc-appointments-selection-clear-date', function() {
				var form = $( this ).closest( 'form' );
				if ( typeof wca_clear_date_selection === 'function' ) {
					wca_clear_date_selection( form );
				}
			} );

			$( '.wc-appointments-date-picker legend small.wc-appointments-date-picker-choose-date' ).show();
			$( '.wc-appointments-date-picker' ).each( function() {
				var form          = $( this ).closest( 'form' );
				var picker        = form.find( '.picker:eq(0)' );
				var fieldset      = $( this ).closest( 'fieldset' );
				var duration_unit = picker.attr( 'data-duration_unit' );

				// Re-init datepicker when customer changes timezone.
				// The timezone offset affects which days have available time slots,
				// so the datepicker must re-evaluate all rules with the new offset.
				form.on( 'timezone-selected', function() {
					// Clear rrule cache so rrule-based rules are re-evaluated.
					wc_appointments_date_picker.rrule_cache = {};
					wc_appointments_date_picker.schedule_date_picker_init( picker );
				} );

				// Only when NOT minute or hour duration type.
				if ( -1 === $.inArray( duration_unit, ['minute', 'hour'] ) ) {
					form.on( 'addon-duration-changed', function( event, duration ) {
						// Update 'data-combined_duration'.
						var appointment_duration = parseInt( picker.attr( 'data-appointment_duration' ), 10 );
						var addon_duration = parseInt( duration, 10 );
						var combined_duration = parseInt( appointment_duration + addon_duration, 10 );

						picker.data( 'combined_duration', combined_duration );
						picker.data( 'addon_duration', duration );

						// Highlight next selected days.
						wc_appointments_date_picker.highlight_days( form );

						// Refresh selection range when addon length changes.
						var y = fieldset.find( 'input.appointment_date_year' ).val();
						var m = fieldset.find( 'input.appointment_date_month' ).val();
						var d = fieldset.find( 'input.appointment_date_day' ).val();
						if ( y && m && d && typeof wca_update_selection_info === 'function' ) {
							wca_update_selection_info( form, y + '-' + m + '-' + d, null );
						}
					} );
				}

				// Hold until location/staff from querystring land, or until a venue is chosen.
				var staff_field = form.find( 'select#wc_appointments_field_staff' );
				var wait_staff = staff_field.length > 0 && null !== wca_get_querystring( 'staff' ) && staff_field.val() != wca_get_querystring( 'staff' );
				if ( formNeedsLocation( form ) || wait_staff ) {
					// Skip init; location/staff change handlers will call date_picker_init.
				} else {
					if ( staff_field.length > 0 && null !== wca_get_querystring( 'staff' ) && staff_field.val() == wca_get_querystring( 'staff' ) ) {
						wc_appointments_date_picker.ignore_initial_staff_change = true;
						setTimeout( function() { wc_appointments_date_picker.ignore_initial_staff_change = false; }, 200 );
					}
					wc_appointments_date_picker.schedule_date_picker_init( picker );
				}

				$( '.wc-appointments-date-picker-date-fields', fieldset ).hide();
				$( '.wc-appointments-date-picker-choose-date', fieldset ).hide();
			} );
		},

		highlight_days: function( form ) {
			var picker            = form.find( '.picker' );
			var selected_day      = picker.find( 'td.ui-datepicker-current-day' ).not( '.ui-state-disabled' );
			var duration          = picker.attr( 'data-appointment_duration' );
			var combined_duration = picker.data( 'combined_duration' ) ? picker.data( 'combined_duration' ) : duration;
			var days_highlighted  = ( ( 1 > combined_duration ) ? 1 : combined_duration ) - 1;

			// Empty previous selected span days.
			picker.find( 'td' ).removeClass( 'appointable-range' );

			// Highlight following span days when duration > 1 (start day uses current-day).
			if ( 0 < days_highlighted ) {
				selected_day.nextAll( 'td' ).add( selected_day.closest( 'tr' ).nextAll().find( 'td' ) ).slice( 0, days_highlighted ).addClass( 'appointable-range' );
			}
		},

		staff_calendar: function() {
			if ( wc_appointments_date_picker.ignore_initial_staff_change ) {
				return;
			}
			// Keep any selected date; create() re-selects it or autoselects first day.
			wc_appointments_date_picker.schedule_date_picker_init( $( this ).closest( 'form' ).find( '.picker:eq(0)' ) );
		},

		dependent_field_calendar: function() {
			var form = $( this ).closest( 'form' );
			if ( formNeedsLocation( form ) ) {
				return;
			}
			wc_appointments_date_picker.schedule_date_picker_init( form.find( '.picker:eq(0)' ) );
		},

		toggle_calendar: function() {
			var $picker = $( this ).closest( 'fieldset' ).find( '.picker:eq(0)' );
			wc_appointments_date_picker.schedule_date_picker_init( $picker );
			$picker.slideToggle();
		},

		open_calendar: function() {
			var $picker = $( this ).closest( 'fieldset' ).find( '.picker:eq(0)' );
			wc_appointments_date_picker.schedule_date_picker_init( $picker );
			$picker.slideDown();
		},

		input_date_trigger: function() {
			var $fieldset = $( this ).closest( 'fieldset' );
			var $picker   = $fieldset.find( '.picker:eq(0)' );
			var year      = parseInt( $fieldset.find( 'input.appointment_date_year' ).val(), 10 );
			var month     = parseInt( $fieldset.find( 'input.appointment_date_month' ).val(), 10 );
			var day       = parseInt( $fieldset.find( 'input.appointment_date_day' ).val(), 10 );

			if ( year && month && day ) {
				var date = new Date( year, month - 1, day );

				// Set selected date for datepicker.
				$picker.datepicker( 'setDate', date );

				// Fire up 'date-selected' trigger.
				// $fieldset.triggerHandler( 'date-selected', date );
			}
		},

		select_date_trigger: function( date ) {
			var fieldset             = $( this ).closest( 'fieldset' );
			var form                 = fieldset.closest( 'form' );
			var picker               = form.find( '.picker:eq(0)' );
			var parsed_date          = date.split( '-' );
			var year                 = parseInt( parsed_date[0], 10 );
			var month                = parseInt( parsed_date[1], 10 );
			var day                  = parseInt( parsed_date[2], 10 );
			var duration_unit        = picker.attr( 'data-duration_unit' );
			var appointment_duration = picker.attr( 'data-appointment_duration' );
			var combined_duration    = picker.data( 'combined_duration' ) ? picker.data( 'combined_duration' ) : appointment_duration;

			// Only when NOT minute or hour duration type.
			if ( -1 === $.inArray( duration_unit, ['minute', 'hour'] ) ) {
				// Full appointment duration length.
				var days_highlighted = ( 1 > combined_duration ) ? 1 : combined_duration;

				startDate = new Date( year, month - 1, day );
				endDate = new Date( year, month - 1, day + ( parseInt( days_highlighted, 10 ) - 1 ) );
				// Apply span classes immediately (onSelect does not re-run beforeShowDay).
				wc_appointments_date_picker.highlight_days( form );
			}

			// Set fields
			fieldset.find( 'input.appointment_to_date_year' ).val( '' );
			fieldset.find( 'input.appointment_to_date_month' ).val( '' );
			fieldset.find( 'input.appointment_to_date_day' ).val( '' );

			fieldset.find( 'input.appointment_date_year' ).val( parsed_date[0] );
			fieldset.find( 'input.appointment_date_month' ).val( parsed_date[1] );
			fieldset.find( 'input.appointment_date_day' ).val( parsed_date[2] ).trigger( 'change' );

			// Disable submit button.
			form.find( '.wc-appointments-appointment-form-button' ).prop( 'disabled', true );

			// Update selection info display.
			if ( typeof wca_update_selection_info === 'function' ) {
				wca_update_selection_info( form, date, null );
			}

			// After-form add-ons follow the date, not a successful cost quote.
			form.find( '.wc-appointments-appointment-hook-after' ).show();

			// Fire up 'date-selected' trigger (form + widget for multi shortcode/block pages).
			var appointment_wrap = fieldset.closest( '.wc-appointments-appointment-form' );
			form.triggerHandler( 'date-selected', date );
			if ( appointment_wrap.length ) {
				appointment_wrap.triggerHandler( 'date-selected', date );
			}

		},

		schedule_date_picker_init: function( element ) {
			var $element = $( element );
			var form = $element.closest( 'form' );
			if ( ! form.length || formNeedsLocation( form ) ) {
				return;
			}
			setCalendarLoading( form, true );
			var prev = form.data( 'wca_calendar_init_timer' );
			if ( prev ) {
				clearTimeout( prev );
			}
			form.data(
				'wca_calendar_init_timer',
				setTimeout( function() {
					form.removeData( 'wca_calendar_init_timer' );
					wc_appointments_date_picker.date_picker_init( $element );
				}, 100 )
			);
		},

		date_picker_init: function( element ) {
			var $element = $( element );
			if ( formNeedsLocation( $element.closest( 'form' ) ) ) {
				return;
			}
			var WC_DatePicker = new WC_Appointments_DatePicker( element );
			var $pickerEl = WC_DatePicker.customPicker;

			$pickerEl.data( 'wc_appointments_date_picker_instance', WC_DatePicker );

			// Per-picker default month anchor (shared module state broke multiple shortcodes on one page).
			var navigatedAnchor = $pickerEl.data( 'wca_navigated_month_first' );
			var initialDefaultDate;

			// if date is in querystring and it is valid,
			// then set it as default date for datepicker
			if ( null !== wca_get_querystring( 'date' ) && wca_is_valid_date( wca_get_querystring( 'date' ) ) ) {
				initialDefaultDate = wca_get_querystring( 'date' );
			} else if ( navigatedAnchor && navigatedAnchor instanceof Date && ! isNaN( navigatedAnchor.getTime() ) ) {
				initialDefaultDate = navigatedAnchor;
			} else {
				initialDefaultDate = WC_DatePicker.get_data_attr( 'default_date' );
			}

			/*
			 * This prevents the calendar resetting to the current date when re-initializing.
			 *
			 * The defaultDate is set to the current date when the datepicker is initialized.
			 * As the user navigates from month to month, we store the first-of-month on the
			 * picker element so each appointment form keeps its own anchor (multiple shortcodes).
			 *
			 * If the resource is updated, this allows the date picker to refresh without
			 * changing the month back to the current month.
			 */
			WC_DatePicker.set_default_params( {
				onSelect: wc_appointments_date_picker.select_date_trigger,
				minDate: WC_DatePicker.get_data_attr( 'min_date' ),
				maxDate: WC_DatePicker.get_data_attr( 'max_date' ),
				/*defaultDate: wca_get_querystring( 'date' ),*/
				defaultDate: initialDefaultDate,
				changeMonth: WC_DatePicker.get_custom_data( 'changeMonth' ),
				changeYear: WC_DatePicker.get_custom_data( 'changeYear' ),

				showWeek: WC_DatePicker.get_custom_data( 'showWeek' ),
				showOn: WC_DatePicker.get_custom_data( 'showOn' ),
				numberOfMonths: parseInt( WC_DatePicker.get_custom_data( 'numberOfMonths' ) ),
				showButtonPanel: WC_DatePicker.get_custom_data( 'showButtonPanel' ),
				showOtherMonths: WC_DatePicker.get_custom_data( 'showOtherMonths' ),
				selectOtherMonths: WC_DatePicker.get_custom_data( 'selectOtherMonths' ),
				gotoCurrent: WC_DatePicker.get_custom_data( 'gotoCurrent' ),

				closeText: WC_DatePicker.get_custom_data( 'closeText' ),
				currentText: WC_DatePicker.get_custom_data( 'currentText' ),
				prevText: WC_DatePicker.get_custom_data( 'prevText' ),
				nextText: WC_DatePicker.get_custom_data( 'nextText' ),
				monthNames: WC_DatePicker.get_custom_data( 'monthNames' ),
				monthNamesShort: WC_DatePicker.get_custom_data( 'monthNamesShort' ),
				dayNames: WC_DatePicker.get_custom_data( 'dayNames' ),
				/*dayNamesShort: WC_DatePicker.get_custom_data( 'dayNamesShort' ),*/
				/*dayNamesMin: WC_DatePicker.get_custom_data( 'dayNamesMin' ),*/
				dayNamesMin: WC_DatePicker.get_custom_data( 'dayNamesShort' ),

        firstDay: WC_DatePicker.get_custom_data( 'firstDay' ),
        isRTL: WC_DatePicker.get_custom_data( 'isRTL' ),
        beforeShowDay: WC_DatePicker.maybe_load_from_cache.bind( WC_DatePicker ),
				onChangeMonthYear: function( year, month ) {
					element.data( 'wca_navigated_month_first', new Date( year, month - 1, 1 ) );
					if ( this._suppressMonthFetch ) {
						return;
					}
					this.cache.attributes = {};
					this._dataLoading = true;
					setCalendarLoading( this.customForm, true );
					this.get_data( year, month )
						.done( function() {
							this._dataLoading = false;
							element.datepicker( 'refresh' );
							setCalendarLoading( this.customForm, false );
						}.bind( this ) );
					// Remove date from querystring to maintain consistency
					if ( typeof wca_update_querystring === 'function' ) {
						wca_update_querystring( 'date', null );
					}
					// Clear date, time slots (if any), addons and cost so user starts fresh in the new month.
					wc_appointments_date_picker.clear_selection_on_month_change( this.customForm );
					// Fire up 'month-year-changed' trigger.
					this.customForm.triggerHandler( 'month-year-changed', year, month );
				}.bind( WC_DatePicker )
			} );

			WC_DatePicker.create();

			wc_appointments_date_picker.get_day_attributes = WC_DatePicker.maybe_load_from_cache.bind( WC_DatePicker );
		},

		refresh_datepicker: function( $pickerTarget ) {
			var $toRefresh = ( $pickerTarget && $pickerTarget.length ) ? $pickerTarget : $( '.wc-appointments-date-picker .picker.hasDatepicker' );
			$toRefresh.each( function() {
				if ( $( this ).hasClass( 'hasDatepicker' ) ) {
					$( this ).datepicker( 'refresh' );
				}
			} );
		},

		/**
		 * Clear date, time slots (if present), addons and cost when user switches month/year.
		 * Keeps the form in a clean state so the user starts fresh in the new month.
		 * Works for both day-duration products (no time slots) and minute/hour products.
		 */
		clear_selection_on_month_change: function( form ) {
			var fieldset    = form.find( 'fieldset' );
			var slot_picker = form.find( '.slot-picker' );

			// Clear date input fields.
			fieldset.find( 'input.appointment_date_year' ).val( '' );
			fieldset.find( 'input.appointment_date_month' ).val( '' );
			fieldset.find( 'input.appointment_date_day' ).val( '' );

			if ( typeof wca_update_querystring === 'function' ) {
				wca_update_querystring( 'time', null );
			}

			form.find( '.wc-appointments-appointment-form-button' ).prop( 'disabled', true );

			// Hide addons and cost (clear cost calculation display).
			form.find( '.wc-appointments-appointment-hook-after, .wc-appointments-recurring-hook' ).hide();
			form.find( '.wc-appointments-appointment-cost' ).hide();

			// Clear time selection only when time slots exist (minute/hour products).
			if ( slot_picker.length ) {
				slot_picker.find( 'li' ).removeClass( 'selected' );
				slot_picker.parent( 'div' ).find( 'input' ).val( '' ).removeAttr( 'data-value' ).removeAttr( 'data-slot-timestamp' );
				form.find( '.slot-timestamp-field' ).val( '' );
				slot_picker.hide();
			}

			if ( typeof wca_update_selection_info === 'function' ) {
				wca_update_selection_info( form, null );
			}
		},

		get_number_of_days: function( defaultNumberOfDays, form, picker ) {
			var number_of_days       = defaultNumberOfDays;
			var duration_unit        = picker.attr( 'data-duration_unit' );
			var appointment_duration = picker.attr( 'data-appointment_duration' );
			var combined_duration    = picker.data( 'combined_duration' ) ? picker.data( 'combined_duration' ) : appointment_duration;
			var availability_span    = picker.attr( 'data-availability_span' );

			// Only when NOT minute or hour duration type.
			if ( -1 === $.inArray( duration_unit, ['minute', 'hour'] ) ) {
				number_of_days = ( 1 > combined_duration ) ? 1 : combined_duration;
			}

			if ( 1 > number_of_days || 'start' === availability_span ) {
				number_of_days = 1;
			}

			return number_of_days;
		},

		// Kept as no-op for backward compatibility (cleared on timezone-selected event).
		rrule_cache: {},

		get_format_date: function( date ) {
			// 1970, 1971, ... 2015, 2016, ...
			var yyyy = date.getFullYear();
			// 01, 02, 03, ... 10, 11, 12
			var MM = ( 10 > ( date.getMonth() + 1 ) ? '0' : '' ) + ( date.getMonth() + 1 );
			// 01, 02, 03, ... 29, 30, 31
			var dd = ( 10 > date.getDate() ? '0' : '' ) + date.getDate();

			// create the format you want
			return ( yyyy + '-' + MM + '-' + dd );
		},

		get_relative_date: function( relDateAttr ) {
			var minDate = new Date();
			var pattern = /([+-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g;
			var matches = pattern.exec( relDateAttr );
			while ( matches ) {
				switch ( matches[2] || 'd' ) {
					case 'd' : case 'D' :
						minDate.setDate( minDate.getDate() + parseInt( matches[1], 10 ) );
						break;
					case 'w' : case 'W' :
						minDate.setDate( ( minDate.getDate() + parseInt( matches[1], 10 ) ) * 7 );
						break;
					case 'm' : case 'M' :
						minDate.setMonth( minDate.getMonth() + parseInt( matches[1], 10 ) );
						break;
					case 'y': case 'Y' :
						minDate.setYear( minDate.getFullYear() + parseInt( matches[1], 10 ) );
						break;
				}
				matches = pattern.exec( relDateAttr );
			}
			return minDate;
		}
	};

	/**
	 * Represents a jQuery UI DatePicker.
	 *
	 * @constructor
	 * @version 3.7.4
	 * @since   3.7.4
	 * @param   {object} element - jQuery object for the picker that was initialized.
	 */
	var WC_Appointments_DatePicker = function WC_Appointments_DatePicker( element ) {
		this.customPicker = $( element );
		this.customForm   = this.customPicker.closest( 'form, .cart' );
		this.customData   = {};
		this.opts         = {
			cache: false
		};
		this.cache        = {
			data: {},
			attributes: {}
		};
		this._dataLoading = false;

		$.each( wc_appointment_form_params, function( key, val ) {
			this.customData[ key ] = val;
		}.bind( this ) );

		// Never cache calendar availability: staff/location/resource change must always refetch.
		this.opts.cache = false;
	};

	/**
	 * Creates the DatePicker referenced by initializing the first data call.
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 */
	WC_Appointments_DatePicker.prototype.create = function create() {
		var year        = parseInt( this.customForm.find( 'input.appointment_date_year' ).val(), 10 );
		var month       = parseInt( this.customForm.find( 'input.appointment_date_month' ).val(), 10 );
		var day         = parseInt( this.customForm.find( 'input.appointment_date_day' ).val(), 10 );

		this.customPicker
			.empty()
			.removeClass( 'hasDatepicker' )
			.datepicker( this.get_default_params() );

		if ( year && month && day ) {
			this.customPicker.datepicker( 'setDate', new Date( year, month - 1, day ) );
		} else if ( this.defaultParams.defaultDate ) {
			this.customPicker.datepicker( 'setDate', this.defaultParams.defaultDate );
		}

		var picker_year  = this.customPicker.datepicker( 'getDate' ).getFullYear();
		var picker_month = this.customPicker.datepicker( 'getDate' ).getMonth() + 1;

		this._dataLoading = true;
		setCalendarLoading( this.customForm, true );
		this.get_data( picker_year, picker_month )
			.done( function() {
				this._dataLoading = false;
				wc_appointments_date_picker.refresh_datepicker( this.customPicker );
			}.bind( this ) )
			.done( function() {
				var querystring_date;
				var is_querystring_date;
				var is_autoselect_only;
				var is_autoselect;

				// Auto-select first available day.
				// If date is in querystring, select it instead of the first day
				// it overrides autoselect setting.
				is_autoselect = wc_appointments_date_picker.is_autoselect( this.customPicker );

				// Auto-select if enabled, or honor date from querystring.
				querystring_date = wca_get_querystring( 'date' );
				is_querystring_date = null !== querystring_date && wca_is_valid_date( querystring_date );
				is_autoselect_only = ! is_querystring_date && is_autoselect;

				// For querystring dates, call the selection function directly (no click event)
				if ( is_querystring_date ) {
					this.customPicker.datepicker( 'refresh' );
					// Set the date in the datepicker
					var qs_date = querystring_date.split( '-' );
					var qs_date_obj = new Date( parseInt( qs_date[0], 10 ), parseInt( qs_date[1], 10 ) - 1, parseInt( qs_date[2], 10 ) );
					this._suppressMonthFetch = true;
					this.customPicker.datepicker( 'setDate', qs_date_obj );
					this._suppressMonthFetch = false;
					// Call selection function directly to avoid event bubbling
					// Use the picker element as context (it's inside the fieldset structure)
					wc_appointments_date_picker.select_date_trigger.call( this.customPicker[0], querystring_date );
					setCalendarLoading( this.customForm, false );
				} else if ( is_autoselect_only ) {
					if ( year && month && day ) {
						wc_appointments_date_picker.select_date_trigger.call( this.customPicker[0], year + '-' + month + '-' + day );
						setCalendarLoading( this.customForm, false );
					} else {
						var anchor = this.customPicker.datepicker( 'getDate' );
						var minTs  = anchor ? new Date( anchor.getFullYear(), anchor.getMonth(), anchor.getDate() ).getTime() : Date.now();
						// Keep loading on until autoselect picks a day or finishes scanning months.
						this.autoselect_first_available_day( minTs, 0 );
					}
				} else {
					// Scope removal to this picker instance only.
					this.customPicker.find( '.ui-datepicker-current-day' ).removeClass( 'ui-datepicker-current-day' );
					setCalendarLoading( this.customForm, false );
				}
			} );
	};

	/**
	 * If caching is being requested beforeShowDay will use this method to load styles from cache if available.
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 * @param   {object} date - Date to apply attributes to.
	 */
	WC_Appointments_DatePicker.prototype.maybe_load_from_cache = function maybe_load_from_cache( date ) {
		var cacheKey         = date.getTime();
		var defaultClass	 = '1' === this.customData.default_availability ? 'appointable' : 'not_appointable';
		var attributes		 = [ false, defaultClass, '' ];
		var cachedAttributes = ( this.customData.disable_slots_cache ) ? undefined : this.cache.attributes[ cacheKey ];

		// While AJAX is loading new month data, default all days to disabled
		// to prevent stale data from briefly showing days as available.
		if ( this._dataLoading ) {
			return [ false, 'not_appointable', '' ];
		}

		if ( cachedAttributes ) {
			cachedAttributes = [ cachedAttributes.selectable, cachedAttributes.class.join( ' ' ), cachedAttributes.title ];
		} else if ( this.appointmentsData ) {
			var checkDate   = new Date( date ); // new object so we don't modify the original.
			checkDate.setHours( HOUR_OFFSET );

			var attrs = this.getDateElementAttributes( checkDate );
			attributes = [ attrs.selectable, attrs.class.join( ' ' ), attrs.title ];
		}

		return cachedAttributes || attributes;
	};

	WC_Appointments_DatePicker.prototype.get_selected_staff_id = function get_selected_staff_id() {
		var staffId = parseInt( this.customForm.find( 'select#wc_appointments_field_staff' ).val(), 10 );

		return staffId > 0 ? staffId : 0;
	};

	WC_Appointments_DatePicker.prototype.get_effective_day_entry = function get_effective_day_entry( dayEntry, staffId ) {
		if ( ! dayEntry ) {
			return null;
		}

		if ( staffId && dayEntry.per_staff && dayEntry.per_staff[ staffId ] ) {
			return dayEntry.per_staff[ staffId ];
		}

		if ( ! staffId && dayEntry.per_staff && dayEntry.per_staff[ 0 ] ) {
			return dayEntry.per_staff[ 0 ];
		}

		return dayEntry;
	};

	/**
	 * Autoselect first bookable day from staff-aware day_data; loads next month via AJAX when needed.
	 */
	WC_Appointments_DatePicker.prototype.autoselect_first_available_day = function autoselect_first_available_day( minTimestamp, monthsScanned ) {
		var staffId = this.get_selected_staff_id();
		var dayData = this.appointmentsData && this.appointmentsData.day_data;
		var pick;
		var pickTs = null;
		var visible;
		var nextMonth;
		var dateStr;

		monthsScanned = monthsScanned || 0;
		if ( 12 < monthsScanned ) {
			setCalendarLoading( this.customForm, false );
			return;
		}

		if ( dayData ) {
			$.each( dayData, function( key, entry ) {
				var parts = String( key ).split( '-' );
				var dateObj;
				var ts;
				var effective;

				if ( 3 !== parts.length ) {
					return;
				}

				dateObj = new Date( parseInt( parts[0], 10 ), parseInt( parts[1], 10 ) - 1, parseInt( parts[2], 10 ) );
				ts      = dateObj.getTime();
				if ( ts < minTimestamp ) {
					return;
				}

				effective = this.get_effective_day_entry( entry, staffId );
				if ( effective && effective.selectable && ( null === pickTs || ts < pickTs ) ) {
					pickTs = ts;
					pick   = dateObj;
				}
			}.bind( this ) );
		}

		if ( pick ) {
			dateStr = pick.getFullYear() + '-' + ( pick.getMonth() + 1 ) + '-' + pick.getDate();
			this._suppressMonthFetch = true;
			this.customPicker.datepicker( 'setDate', pick ).datepicker( 'refresh' );
			this._suppressMonthFetch = false;
			wc_appointments_date_picker.select_date_trigger.call( this.customPicker[0], dateStr );
			setCalendarLoading( this.customForm, false );
			return;
		}


		visible   = this.customPicker.datepicker( 'getDate' );
		nextMonth = new Date( visible.getFullYear(), visible.getMonth() + 1, 1 );
		this._suppressMonthFetch = true;
		this.customPicker.datepicker( 'setDate', nextMonth );
		this._suppressMonthFetch = false;
		this._dataLoading = true;
		setCalendarLoading( this.customForm, true );
		this.get_data( nextMonth.getFullYear(), nextMonth.getMonth() + 1 )
			.done( function() {
				this._dataLoading = false;
				this.customPicker.datepicker( 'refresh' );
				this.autoselect_first_available_day( minTimestamp, monthsScanned + 1 );
			}.bind( this ) );
	};

	WC_Appointments_DatePicker.prototype.renderVisibleDayPrices = function renderVisibleDayPrices() {
		if ( ! this.customPicker.length || ! this.appointmentsData || ! this.appointmentsData.day_data ) {
			return;
		}

		var staffId = this.get_selected_staff_id();

		this.customPicker.find( '.ui-datepicker-calendar td' ).each( function( index, cell ) {
			var $cell = $( cell );
			var $target = $cell.children( 'a.ui-state-default, span.ui-state-default' ).first();

			$cell.removeClass( 'has-slot-price discounted_day' );
			$cell.find( '.wca-day-price' ).remove();

			if ( ! $target.length ) {
				return;
			}

			var year = parseInt( $cell.attr( 'data-year' ), 10 );
			var month = parseInt( $cell.attr( 'data-month' ), 10 );
			var day = parseInt( $target.text(), 10 );

			if ( isNaN( year ) || isNaN( month ) || isNaN( day ) ) {
				return;
			}

			var dayEntry = this.appointmentsData.day_data[ year + '-' + ( month + 1 ) + '-' + day ];
			var effectiveData = this.get_effective_day_entry( dayEntry, staffId );
			var price = effectiveData && effectiveData.price ? effectiveData.price : null;

			// Date picker: only show discount symbol in top-right of cell, not the price text.
			if ( ! price || ! price.show ) {
				return;
			}

			$cell.addClass( 'has-slot-price discounted_day' );
		}.bind( this ) );
	};

	/**
	 * Returns the default parameters.
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 */
	WC_Appointments_DatePicker.prototype.get_default_params = function get_default_params() {
		return this.defaultParams || {};
	};

	/**
	 * Set and override the default parameters.
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 * @param   {object} params - Parameters to be set or overridden.
	 */
	WC_Appointments_DatePicker.prototype.set_default_params = function set_default_params( params ) {
		var _defaultParams = {
			showWeek: false,
			showOn: false,
			numberOfMonths: 1,
			showButtonPanel: false,
			showOtherMonths: true,
			selectOtherMonths: true,
			gotoCurrent: true,
			dateFormat: $.datepicker.ISO_8601
			// dateFormat: 'yy-mm-dd'
		};

		if ( 'object' !== typeof params ) {
			throw new Error( 'Cannot set params with typeof ' + typeof params );
		}

		this.defaultParams = $.extend( _defaultParams, params ) || {};
	};

	/**
	 * Get the data from the server for a slot of time.
	 *
	 * @since   3.7.4
	 * @param   {string} year - Year being requested.
	 * @param   {string} month - Month being requested.
	 * @returns {object} Deferred object to be resolved after the http request
	 */
	WC_Appointments_DatePicker.prototype.get_data = function get_data( year, month ) {
		var get_date_range = function get_date_range( startDate ) {
			if ( !startDate ) {
				startDate = new Date( [ year, month, '01' ].join( '/' ) );
			}
			return this.get_padded_date_range( startDate, this.get_number_of_days_in_month( month ) );
		}.bind( this );

		var deferred	= $.Deferred();
		var dateRange   = get_date_range();
		var set_staff_id = ( 0 < this.customForm.find( 'select#wc_appointments_field_staff' ).val() ) ? this.customForm.find( 'select#wc_appointments_field_staff' ).val() : 0;
		var locationId = parseInt( this.customForm.find( 'select#wc_appointments_field_location' ).val(), 10 ) || 0;
		var resourceId = parseInt( this.customForm.find( 'select#wc_appointments_field_resource' ).val(), 10 ) || 0;
		var tzForCache = getEffectiveCustomerTimezoneString( this.customForm ) || 'site';
		var cacheKey = dateRange.startDate.getTime() + '-' + dateRange.endDate.getTime() + '-' + ( set_staff_id || '0' ) + '-' + locationId + '-' + resourceId + '-' + tzForCache;

		currentDateRange = dateRange;

		if ( formNeedsLocation( this.customForm ) ) {
			this.appointmentsData = { fully_scheduled_days: {} };
			setCalendarLoading( this.customForm, false );
			deferred.resolveWith( this, [ dateRange, this.appointmentsData ] );
			return deferred;
		}

		if ( this.opts.cache && this.cache.data[ cacheKey ] ) {
			deferred.resolveWith( this, [ dateRange, this.cache.data[ cacheKey ] ] );
		} else {
			var product_id = this.customPicker.attr( 'data-product_id' );
			if ( ! product_id ) {
				this.appointmentsData = this.appointmentsData || { fully_scheduled_days: {} };
				deferred.resolveWith( this, [ dateRange, {} ] );
				return deferred;
			}

			var boot = window.wc_appointments_initial_day_slots;
			var staffId = set_staff_id ? parseInt( set_staff_id, 10 ) : 0;
			// Boot covers one month: ?date= when present (PHP mirrors this), else default_date.
			var qsDate = wca_get_querystring( 'date' );
			var bootAnchor = ( null !== qsDate && wca_is_valid_date( qsDate ) )
				? qsDate
				: String( this.customPicker.data( 'default_date' ) || '' );
			var bootAnchorParts = bootAnchor.split( '-' );
			var bootMonthMatches = parseInt( bootAnchorParts[0], 10 ) === parseInt( year, 10 )
				&& parseInt( bootAnchorParts[1], 10 ) === parseInt( month, 10 );
			if (
				boot && ! this._wcaInitialDaySlotsConsumed
				&& bootMonthMatches
				&& String( boot.product_id ) === String( product_id )
				&& parseInt( boot.staff_id, 10 ) === staffId
				&& parseInt( boot.location_id, 10 ) === locationId
				&& parseInt( boot.resource_id, 10 ) === resourceId
				&& boot.data && boot.data.day_data
			) {
				this._wcaInitialDaySlotsConsumed = true;
				this.appointmentsData = boot.data;
				wc_appointments_date_picker_object.appointmentsData = this.appointmentsData;
				deferred.resolveWith( this, [ dateRange, boot.data ] );
				this.customForm.triggerHandler( 'calendar-data-loaded', [ this.appointmentsData, dateRange ] );
				return deferred;
			}

			var params = {
				'wc-ajax': 'wc_appointments_find_scheduled_day_slots',
				'product_id': product_id,
				'security': this.get_custom_data( 'nonce_find_day_slots' ),
				'min_date': wcaFormatYmd( dateRange.startDate ),
				'max_date': wcaFormatYmd( dateRange.endDate )
			};
			if ( set_staff_id && 0 !== set_staff_id ) {
				params.set_staff_id = set_staff_id;
			}
			if ( locationId > 0 ) {
				params.location_id = locationId;
			}
			if ( resourceId > 0 ) {
				params.resource_id = resourceId;
			}
			if ( tzForCache !== 'site' ) {
				params.display_timezone = tzForCache;
			}

			var prevXhr = this.customPicker.data( 'wca_day_slots_xhr' );
			if ( prevXhr && typeof prevXhr.abort === 'function' && 4 !== prevXhr.readyState ) {
				prevXhr.abort();
			}

			var xhr = $.ajax( {
				context: this,
				url: wc_appointments_date_picker_args.ajax_url,
				method: 'POST',
				data: params,
				dataType: 'json'
			} );
			this.customPicker.data( 'wca_day_slots_xhr', xhr );
			xhr
				.done( function( data ) {
					this.appointmentsData = this.appointmentsData || {};

					var parseCalendarAjaxPayload = function( raw ) {
						var d = raw;
						var i;
						for ( i = 0; i < 2 && 'string' === typeof d; i++ ) {
							try {
								d = JSON.parse( d );
							} catch ( e ) {
								return {};
							}
						}
						if ( ! d || 'object' !== typeof d || Array.isArray( d ) ) {
							return {};
						}
						return d;
					};

					data = parseCalendarAjaxPayload( data );
					if ( ! data.fully_scheduled_days ) { data.fully_scheduled_days = {}; }
					if ( ! data.unavailable_days ) { data.unavailable_days = {}; }
					if ( ! data.partially_scheduled_days ) { data.partially_scheduled_days = {}; }
					if ( ! data.remaining_scheduled_days ) { data.remaining_scheduled_days = {}; }

					if ( data.meta && null != data.meta.engine ) {
						this.customPicker.attr( 'data-engine', data.meta.engine );
					}

					$.each( data, function( key, val ) {
						if ( Array.isArray( val ) || 'object' === typeof val ) {
							var emptyType = ( Array.isArray( val ) ) ? [] : {};
							this.appointmentsData[ key ] = this.appointmentsData[ key ] || emptyType;
							$.extend( this.appointmentsData[ key ], val );
						} else {
							this.appointmentsData[ key ] = val;
						}
					}.bind( this ) );

					wc_appointments_date_picker_object.appointmentsData = this.appointmentsData;

					if ( ! this.customData.disable_slots_cache ) {
						this.cache.data[ cacheKey ] = data;
					}

					if ( !year && !month && this.appointmentsData.min_date ) {
						dateRange = get_date_range( this.get_default_date( this.appointmentsData.min_date ) );
					}

					deferred.resolveWith( this, [ dateRange, data ] );
					this.customForm.triggerHandler( 'calendar-data-loaded', [this.appointmentsData, dateRange] );
				}.bind( this ) )
				.fail( function( _jqXHR, textStatus ) {
					if ( 'abort' === textStatus ) {
						return;
					}
					this._dataLoading = false;
					setCalendarLoading( this.customForm, false );
					deferred.resolveWith( this, [ dateRange, {} ] );
				}.bind( this ) );
		}

		return deferred;
	};

	/**
	 * Gets the default date
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 * @returns {Date}  Default date
	 */
	WC_Appointments_DatePicker.prototype.get_default_date = function get_default_date( minAppointableDate ) {
		var defaultDate;
		var defaultDateFromData = this.customPicker.data( 'default_date' ).split( '-' );
		// We change the day to be 31, as default_date defaults to the current day,
		// but we want to go as far as to the end of the current month.
		defaultDateFromData[2] = '31';
		var modifier           = 1;

		// If for some reason the default_date didn't get or set incorrectly we should
		// try to fix it even though it may be indicative somewith else has gone wrong
		// on the backend.
		defaultDate = ( 3 !== defaultDateFromData.length ) ? new Date() : new Date( defaultDateFromData );

		// The server will sometimes return a min_appointable_date with the data request
		// If that happens we need to modify the default date to start from this
		// modified date.
		if ( minAppointableDate ) {
			switch ( minAppointableDate.unit ) {
				case 'month' :
					modifier = 30;
					break;
				case 'week' :
					modifier = 7;
					break;
			}

			modifier = modifier * minAppointableDate.value;

			defaultDate.setDate( defaultDate.getDate() + modifier );
		}

		return defaultDate;
	};

	/**
	 * Get number of days in a month
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 * @param   {number} [ month = currentMonth ] - The month in a 1 based index to get the number of days for.
	 * @returns {number} Number of days in the month.
	 */
	WC_Appointments_DatePicker.prototype.get_number_of_days_in_month = function get_number_of_days_in_month( month ) {
		var currentDate = this.get_default_date();

		month = month || currentDate.getMonth() + 1;

		return new Date( currentDate.getFullYear(), month, 0 ).getDate();
	};

	/**
	 * Get custom data that was set by the server prior to rendering the client.
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 * @param   {string} key - Custom data attribute to get.
	 */
	WC_Appointments_DatePicker.prototype.get_custom_data = function get_custom_data( key ) {
		if ( !key ) {
			return;
		}

		// Use 'in' to preserve false, 0, '' so filter params like showOtherMonths: false work.
		return key in this.customData ? this.customData[ key ] : null;
	};

	/**
	 * Get data attribute set on the $picker element.
	 *
	 * @version 3.7.4
	 * @since   3.7.4
	 * @param   {string} attr - Data attribute to get.
	 */
	WC_Appointments_DatePicker.prototype.get_data_attr = function get_data_attr( attr ) {
		if ( !attr ) {
			return;
		}

		return this.customPicker.data( attr );
	};

	/** Visible month ± pad (clamped to today); extend to 14 days when the window is short. */
	WC_Appointments_DatePicker.prototype.get_padded_date_range = function get_padded_date_range( date, rangeInDays, padInDays ) {
		date = date || this.get_default_date();
		padInDays = padInDays || 7;

		var currentDate = new Date();
		currentDate.setHours( HOUR_OFFSET, 0, 0, 0 );

		var year = date.getFullYear();
		var monthIndex = date.getMonth();
		var startDate = new Date( year, monthIndex, 1 );
		var endDate = new Date( year, monthIndex + 1, 0 );
		startDate.setHours( HOUR_OFFSET, 0, 0, 0 );
		endDate.setHours( HOUR_OFFSET, 0, 0, 0 );
		startDate.setDate( startDate.getDate() - padInDays );
		endDate.setDate( endDate.getDate() + padInDays );
		if ( startDate < currentDate ) {
			startDate = new Date( currentDate );
		}
		if ( endDate < startDate ) {
			endDate = new Date( startDate );
			endDate.setDate( endDate.getDate() + padInDays );
		}
		if ( 14 > Math.round( ( endDate.getTime() - startDate.getTime() ) / 86400000 ) ) {
			endDate = new Date( startDate );
			endDate.setDate( endDate.getDate() + 14 + padInDays );
		}
		return { startDate: startDate, endDate: endDate };
	};

	/**
	 * Gets the date element attributes. This was formerly called is_appointable but changed names to more accurately reflect its new purpose.
	 *
	 * Server must provide `day_data`; the picker interprets it without client-side availability math.
	 *
	 * @version 5.3.0
	 * @since   3.7.4
	 * @param   {Date}   key - Date to get the element attributes for.
	 * @returns {object} Attributes computed for the date.
	 */
	WC_Appointments_DatePicker.prototype.getDateElementAttributes = function getDateElementAttributes( date ) {
		var attributes = {
			class: [],
			title: '',
			selectable: true
		};

		var staff_id    = this.get_selected_staff_id();
		var year        = date.getFullYear();
		var month       = date.getMonth() + 1;
		var day         = date.getDate();
		var day_of_week = date.getDay();
		var the_date    = new Date( date );
		var today  	    = new Date();
		var curr_year  	= today.getFullYear();
		var curr_month 	= today.getMonth() + 1;
		var curr_day    = today.getDate();
		var ymdIndex    = year + '-' + month + '-' + day;

		// Add day of week class.
		attributes.class.push( 'weekday-' + day_of_week );

		// Offset for dates to avoid comparing them at midnight.
		if ( 'undefined' !== typeof startDate && 'undefined' !== typeof endDate ) {
			startDate.setHours( HOUR_OFFSET );
			endDate.setHours( HOUR_OFFSET );
		}

		// Select all days, when duration is longer than 1 day.
		if ( date >= startDate && date <= endDate ) {
			attributes.class.push( 'appointable-range' );
		}

		// Past day class.
		if ( new Date( year, month, day ) < new Date( curr_year, curr_month, curr_day ) ) {
			attributes.class.push( 'past_day' );
		}

		// ─── Modern day_data path (pure interpretation, no calculations) ───
		if ( this.appointmentsData.day_data ) {
			var dayEntry = this.appointmentsData.day_data[ ymdIndex ];

			if ( ! dayEntry ) {
				// Day not in server data — treat as unavailable.
				attributes.title      = wc_appointment_form_params.i18n_date_unavailable;
				attributes.selectable = false;
				attributes.class.push( 'not_appointable' );
				return attributes;
			}

			// Phase 11: Padding days folded into day_data.
			if ( dayEntry.padding ) {
				attributes.title      = wc_appointment_form_params.i18n_date_unavailable;
				attributes.selectable = false;
				attributes.class.push( 'not_appointable' );
				return attributes;
			}

			// Phase 11: Restricted weekdays folded into day_data.
			if ( dayEntry.restricted ) {
				attributes.title      = wc_appointment_form_params.i18n_date_unavailable;
				attributes.selectable = false;
				attributes.class.push( 'not_appointable' );
				return attributes;
			}

			// Determine which data to use: per-staff if staff selected, else day-level aggregate.
			var effectiveData = this.get_effective_day_entry( dayEntry, staff_id );

			// Time-based multi-day only: day/month availability is already computed per start date
			// in day_data; requiring span days to be selectable duplicates fully_scheduled logic and
			// blocks the day before a booked start (e.g. Tue when Wed is first day of a 2-day slot).
			var number_of_days = wc_appointments_date_picker.get_number_of_days( this.appointmentsData.appointment_duration, this.customForm, this.customPicker );
			var duSpan = this.appointmentsData.duration_unit || '';
			if ( number_of_days > 1 && -1 !== $.inArray( duSpan, [ 'minute', 'hour' ] ) ) {
				for ( var i = 1; i < number_of_days; i++ ) {
					var spanDate = new Date( date );
					spanDate.setDate( spanDate.getDate() + i );
					var spanKey = spanDate.getFullYear() + '-' + ( spanDate.getMonth() + 1 ) + '-' + spanDate.getDate();
					var spanEntry = this.appointmentsData.day_data[ spanKey ];

					if ( ! spanEntry || ! spanEntry.selectable ) {
						attributes.title      = wc_appointment_form_params.i18n_date_unavailable;
						attributes.selectable = false;
						attributes.class.push( 'not_appointable' );
						return attributes;
					}

					// Check staff-specific selectability for span days.
					if ( staff_id && spanEntry.per_staff && spanEntry.per_staff[ staff_id ] && ! spanEntry.per_staff[ staff_id ].selectable ) {
						attributes.title      = wc_appointment_form_params.i18n_date_unavailable;
						attributes.selectable = false;
						attributes.class.push( 'not_appointable' );
						return attributes;
					}
				}
			}

			// Read pre-computed values directly.
			attributes.selectable = effectiveData.selectable;
			attributes.class.push( effectiveData.css_class );


			// Determine if effective data has any bookings.
			// Multiple indicators for different capacity scenarios:
			// - occupancy_pct > 0: capacity-based (some spots booked on multi-capacity slots)
			// - booked_slots > 0: slot-count based (some slots fully booked)
			// - slots_with_bookings > 0: any slots with partial bookings
			var hasBookings = ( effectiveData.occupancy_pct && effectiveData.occupancy_pct > 0 )
				|| ( effectiveData.booked_slots && effectiveData.booked_slots > 0 )
				|| ( effectiveData.slots_with_bookings && effectiveData.slots_with_bookings > 0 );

			// Add partial_scheduled + remaining_scheduled_N for any day with bookings.
			// Visual indicator of capacity usage regardless of status.
			if ( hasBookings && effectiveData.selectable ) {
				if ( -1 === attributes.class.indexOf( 'partial_scheduled' ) ) {
					attributes.class.push( 'partial_scheduled' );
				}
				if ( effectiveData.remaining_bucket && effectiveData.remaining_bucket > 0 ) {
					attributes.class.push( 'remaining_scheduled_' + effectiveData.remaining_bucket );
				}
			}

			// Set title from pre-computed data or i18n fallback.
			if ( ! effectiveData.selectable ) {
				if ( 'fully_scheduled' === effectiveData.css_class ) {
					attributes.title = wc_appointment_form_params.i18n_date_fully_scheduled;
				} else {
					attributes.title = wc_appointment_form_params.i18n_date_unavailable;
				}
			} else if ( -1 < attributes.class.indexOf( 'partial_scheduled' ) ) {
				attributes.title = wc_appointment_form_params.i18n_date_partially_scheduled;
			} else if ( -1 < attributes.class.indexOf( 'past_day' ) ) {
				attributes.title = wc_appointment_form_params.i18n_date_unavailable;
				attributes.selectable = false;
			} else {
				attributes.title = wc_appointment_form_params.i18n_date_available;
			}

			// Override: if day is appointable, ensure no stale not_appointable class.
			if ( attributes.selectable ) {
				var notIdx = attributes.class.indexOf( 'not_appointable' );
				if ( notIdx > -1 ) {
					attributes.class.splice( notIdx, 1 );
				}
				if ( -1 === attributes.class.indexOf( 'appointable' ) ) {
					attributes.class.push( 'appointable' );
				}
			}

			// Slot price/discount: apply in same pass as occupancy so no post-render refresh or flicker.
			if ( effectiveData.price && effectiveData.price.show ) {
				attributes.class.push( 'has-slot-price' );
				attributes.class.push( 'discounted_day' );
			}

			return attributes;
		}

		attributes.title      = wc_appointment_form_params.i18n_date_unavailable;
		attributes.selectable = false;
		attributes.class.push( 'not_appointable' );
		return attributes;
	};

		// export globally
		wc_appointments_date_picker = wc_appointments_date_picker_object;
		wc_appointments_date_picker.init();
	}

	// Function to initialize the date picker with error handling
	// Defined after initDatePicker to ensure it's available
	function initDatePickerWrapper( $ ) {
		try {
			initDatePicker( $ );
		} catch ( error ) {
			console.error( 'WC Appointments: Error initializing date picker:', error );
			// Try to initialize again after a delay as a fallback
			setTimeout( function() {
				try {
					initDatePicker( $ );
				} catch ( retryError ) {
					console.error( 'WC Appointments: Failed to initialize date picker after retry:', retryError );
				}
			}, 500 );
		}
	}

	// Same gate as form, plus jquery-ui datepicker (required at init).
	var datePickerInitialized = false;
	wcaShared.whenDepsReady(
		function() {
			return (
				typeof jQuery !== 'undefined' &&
				jQuery.fn &&
				typeof jQuery.fn.datepicker === 'function' &&
				typeof wc_appointment_form_params !== 'undefined'
			);
		},
		function() {
			if ( datePickerInitialized ) {
				return;
			}
			datePickerInitialized = true;
			initDatePickerWrapper( jQuery );
		},
		'date-picker'
	);
} )();
