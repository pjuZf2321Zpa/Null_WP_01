/* global wc_appointments_writepanel_js_params, alert, confirm, ajaxurl */
jQuery( function( $ ) {
	'use strict';

	var wc_appointments_writepanel = {
		subscription_per_period_timer: null,
		init: function() {
			$( '#appointments_pricing' ).on( 'change', '.wc_appointment_pricing_type select', this.wc_appointments_table_grid );
			$( '#appointments_pricing, #appointments_products' ).on( 'focus', 'select, input, button', this.wc_appointments_table_grid_focus );
			$( '#appointments_pricing, #appointments_products' ).on( 'blur', 'select, input, button', this.wc_appointments_table_grid_blur );
			$( document ).on( 'focusin', this.wc_appointments_table_grid_clear_highlight_if_outside );
			$( 'body' ).on( 'row_added', this.wc_appointments_row_added );
			$( 'body' ).on( 'woocommerce-product-type-change', this.wc_appointments_trigger_change_events );
			$( 'input#_virtual' ).on( 'change', this.wc_appointments_trigger_change_events );
			$( 'input#_downloadable' ).on( 'change', this.wc_appointments_trigger_change_events );
			$( '#_wc_appointment_user_can_cancel' ).on( 'change', this.wc_appointments_user_cancel );
			$( '#_wc_appointment_user_can_reschedule' ).on( 'change', this.wc_appointments_user_reschedule );
			$( '#_wc_appointment_allow_recurring' ).on( 'change', this.wc_appointments_allow_recurring );
			$( '#_wca_appointment_membership' ).on( 'change', this.wc_appointments_subscription_membership );
			$( '#_wca_appointments_per_period_mode' ).on( 'change', this.wc_appointments_subscription_per_period_mode );
			$( '#product-type' ).on( 'change', this.wc_appointments_inventory_show );
			$( '#product-type' ).on( 'change', this.wc_appointments_disable_hide );
			$( '#product-type' ).on( 'change', this.wc_appointments_addon_style );
			$( '#product-type' ).on( 'change', this.wc_appointments_virtual_default );
			$( '#product_addons_data' ).on( 'click', '.wc-pao-addon-adjust-duration', this.wc_appointments_addon_adjust_duration );
			$( '#product_addons_data' ).on( 'change', 'select.wc-pao-addon-type-select', this.wc_appointments_addon_type );
			$( '#product_addons_data' ).on( 'change', 'select.wc-pao-addon-type-select', this.wc_appointments_addon_label );
			// Inventory change magic.
			$( '#_wc_appointment_qty_min' ).on( 'change', this.wc_appointments_qty_min );
			$( '#_wc_appointment_qty_max' ).on( 'change', this.wc_appointments_qty_max );
			$( '#_wc_appointment_recurring_min_occurrences, #_wc_appointment_recurring_max_occurrences' ).on( 'change', this.wc_appointments_recurring_occurrence );
			// Rule change magic.
			$( 'body' ).on( 'change', '.appointments-datetime-select-from :input, .appointments-datetime-select-to :input', this.wc_appointments_rule_range_change );
			$( '#_wc_appointment_has_price_label' ).on( 'change', this.wc_appointments_price_label );
			$( '#_wc_appointment_has_pricing' ).on( 'change', this.wc_appointments_pricing );
			$( '#_wc_appointment_staff_assignment' ).on( 'change', this.wc_appointments_staff_assignment );
			$( '#_wc_appointment_location_mode' ).on( 'change', this.wc_appointments_location_mode );
			$( '#_wc_appointment_location_mode' ).data( 'wcaLocationMode', $( '#_wc_appointment_location_mode' ).val() || 'none' );
			$( '#_wc_appointment_duration_unit' ).on( 'change', this.wc_appointment_duration_unit );
			$( '#_wc_appointment_has_restricted_days' ).on( 'change', this.wc_appointment_restricted_days );
			$( '.add_grid_row' ).on( 'click', this.wc_appointments_table_grid_add_row );
			$( 'body' ).on( 'click', '.remove_grid_row', this.wc_appointments_table_grid_remove_row );
			$( 'body' ).on( 'click', '.manual_sync', this.wc_appointments_manual_sync );
			$( 'body' ).on( 'click', '.oauth_redirect', this.wc_appointments_oauth_redirect );
			// Bind on the list (inside WC's wrapper) so Edit/remove never reach h3 slideToggle.
			$( '.wca-entity-list' )
				.on( 'click', '.wc-metabox > h3 a, .wc-metabox > h3 button', function( event ) {
					event.stopPropagation();
				} )
				.on( 'click', '.wc-metabox > h3', function( event ) {
					if ( $( event.target ).closest( 'a, button' ).length ) {
						return;
					}
					$( this ).parent().toggleClass( 'closed' );
				} )
				.on( 'click', 'button[class*="remove_appointment_"]', function( event ) {
					event.preventDefault();
					var $row = $( this ).closest( '.wc-metabox' );
					$row.removeClass( 'is-assigned' );
					wc_appointments_writepanel.wc_appointments_entity_sync( $row.closest( '.wca-entity-list' ) );
					return false;
				} );
			$( document ).on( 'select2:select', '.wca-entity-picker-select', function( event ) {
				var id = event.params && event.params.data ? event.params.data.id : null;
				if ( ! id ) {
					return;
				}
				var $list = $( $( this ).data( 'list' ) );
				if ( ! $list.length ) {
					return;
				}
				var locMode = $( '#_wc_appointment_location_mode' ).val() || '';
				if ( 'location' === $list.data( 'entity' ) && ( 'fixed' === locMode || 'hidden' === locMode ) ) {
					$list.find( '.is-assigned' ).removeClass( 'is-assigned' );
				}
				var $row = $list.find( '[' + $list.data( 'idAttr' ) + '="' + id + '"]' );
				$row.addClass( 'is-assigned' ).appendTo( $list );
				if ( $row.length ) {
					$row.addClass( 'is-just-added' ).one( 'animationend', function() {
						$row.removeClass( 'is-just-added' );
					} );
				}
				wc_appointments_writepanel.wc_appointments_entity_sync( $list );
			} );
			$( '#appointments_products' ).on( 'click', 'button.add_product', this.wc_appointments_add_product );
			$( '#appointments_products' ).on( 'click', 'td.remove_product', this.wc_appointments_remove_product );
			$( 'body' ).on( 'click', 'a.edit_billing', this.wc_appointments_edit_billing );

			wc_appointments_writepanel.wc_appointments_trigger_change_events();
			wc_appointments_writepanel.wc_appointments_price_show();
			wc_appointments_writepanel.wc_appointments_inventory_show();
			wc_appointments_writepanel.wc_appointments_disable_hide();
			wc_appointments_writepanel.wc_appointments_addon_style();
			wc_appointments_writepanel.wc_appointments_virtual_default();
			wc_appointments_writepanel.wc_appointments_sortable_rows();
			wc_appointments_writepanel.wc_appointments_pickers();
			wc_appointments_writepanel.wc_appointments_twilio_sms();
			wc_appointments_writepanel.wc_appointments_exporter_title_action();
			wc_appointments_writepanel.wc_appointments_open_product_data();
			wc_appointments_writepanel.wc_appointments_add_appointment_actions();
			wc_appointments_writepanel.wc_appointments_indexing_controls();
			wc_appointments_writepanel.wc_appointments_gcal_sync_controls();
			wc_appointments_writepanel.wc_appointments_settings_init();
			wc_appointments_writepanel.initSaveDisable();
			wc_appointments_writepanel.initProductConfigTabLinks();
		},

		wc_appointments_rule_range_change: function() {
			var input_this            = $( this );
			var input_this_val        = input_this.val();
			var input_this_val_int    = parseFloat( input_this_val.replace( /-/g, '' ).replace( /:/g, '.' ), 10 );
			var input_this_class      = input_this.attr( 'class' );
			var range_from_or_to      = input_this.closest( '.range_from' ).length ? 'from' : 'to';
			var range_oposite         = 'from' === range_from_or_to ? 'to' : 'from';
			var range_type            = input_this.closest( 'tr' ).find( '.range_type select' ).val();
			var input_other_container = input_this.closest( 'tr' ).find( '.appointments-datetime-select-' + range_oposite + '' );
			var input_other           = input_other_container.find( '[class^="' + input_this_class + '"]' );
			var input_other_val       = input_other.val();
			var input_other_val_int   = parseFloat( input_other_val.replace( /-/g, '' ).replace( /:/g, '.' ), 10 );

			// Set up from and to variables.
			var range_from         = 'from' === range_from_or_to ? input_this : input_other;
			var range_from_val_int = 'from' === range_from_or_to ? input_this_val_int : input_other_val_int;
			var range_to           = 'to' === range_from_or_to ? input_this : input_other;
			var range_to_val_int   = 'to' === range_from_or_to ? input_this_val_int : input_other_val_int;

			//console.log( input_this );
			//console.log( input_other_container );

			if ( !input_other_val_int ) {
				input_other.val( input_this_val );
				wc_appointments_writepanel.wc_appointments_input_animate( input_this, input_other );
			} else if ( 'custom:daterange' === range_type || 'time:range' === range_type ) {
				var range_from_date         = input_this.closest( 'tr' ).find( '.from_date input' );
				var range_from_date_val     = range_from_date.val();
				var range_from_date_int     = parseFloat( range_from_date_val.replace( /-/g, '' ) );
				var range_from_time         = input_this.closest( 'tr' ).find( '.from_time input' );
				var range_from_time_val     = range_from_time.val();
				var range_from_time_int     = parseFloat( range_from_time_val.replace( /:/g, '.' ) );
				var range_to_date           = input_this.closest( 'tr' ).find( '.to_date input' );
				var range_to_date_val       = range_to_date.val();
				var range_to_date_int       = parseFloat( range_to_date_val.replace( /-/g, '' ) );
				var range_to_time           = input_this.closest( 'tr' ).find( '.to_time input' );
				var range_to_time_val       = range_to_time.val();
				var range_to_time_int       = parseFloat( range_to_time_val.replace( /:/g, '.' ) );
				var range_oposite_from_time = 'to' === range_from_or_to ? range_to_time : range_from_time;
				var range_oposite_to_time   = 'to' === range_from_or_to ? range_from_time : range_to_time;
				var range_oposite_from_date = 'to' === range_from_or_to ? range_to_date : range_from_date;
				var range_oposite_to_date   = 'to' === range_from_or_to ? range_from_date : range_to_date;

				if ( input_this.hasClass( 'time-picker' ) ) {
					if ( 'time:range' === range_type && range_from_time_int > range_to_time_int ) {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_time, range_oposite_to_time, true );
					} else if ( range_from_date_int >= range_to_date_int && range_from_time_int > range_to_time_int ) {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_time, range_oposite_to_time, true );
					} else if ( range_from_date_int > range_to_date_int ) {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_time, range_oposite_to_date, true );
					} else {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_time, range_oposite_to_time );
					}
				} else if ( input_this.hasClass( 'date-picker' ) ) {
					if ( 'time:range' === range_type && range_from_time_int > range_to_time_int ) {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_date, range_oposite_to_time, true );
					} else if ( range_from_date_int > range_to_date_int ) {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_date, range_oposite_to_date, true );
					} else if ( range_from_time_int > range_to_time_int && range_from_date_int === range_to_date_int ) {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_date, range_oposite_to_time, true );
					} else {
						wc_appointments_writepanel.wc_appointments_input_animate( range_oposite_from_date );
					}
				}
			} else if ( range_from_val_int > range_to_val_int ) {
				if ( 'from' === range_from_or_to ) {
					range_to.val( input_this_val );
					wc_appointments_writepanel.wc_appointments_input_animate( input_this, range_to );
				} else {
					wc_appointments_writepanel.wc_appointments_input_animate( input_this, range_from, true );
				}
			} else if ( range_from_val_int <= range_to_val_int ) {
				wc_appointments_writepanel.wc_appointments_input_animate( input_this );
			} else {
				wc_appointments_writepanel.wc_appointments_input_animate( input_this );
			}

			return false;
		},
		wc_appointments_input_animate: function( selected, other, error ) {
			// Reset.
			selected.parents( 'tr' ).find( 'select, input' ).stop().css( {
				outlineWidth: '0'
			} );

			//console.log(selected);
			//console.log(other);
			//console.log(error);

			if ( other ) {
				other.stop().css( {
					outlineWidth: '0'
				} );

				// Update other.
				if ( error ) {
					other.stop().css( {
						outlineOffset: '-1px',
						outlineStyle: 'solid',
						outlineColor: 'red',
						outlineWidth: '1px'
					} );
				} else {
					other.stop().css( {
						outlineOffset: '-1px',
						outlineStyle: 'solid',
						outlineColor: 'black',
						outlineWidth: '1px'
					} ).animate( {
						outlineWidth: '0'
					}, 500, 'linear' );
				}
			}
		},
		wc_appointments_pickers: function() {
			// Date picker.
			$( '.date-picker' ).datepicker( {
				dateFormat: 'yy-mm-dd',
				numberOfMonths: 1,
				showOtherMonths: true,
				changeMonth: true,
				showButtonPanel: true,
				showOn: 'button',
				firstDay: wc_appointments_writepanel_js_params.firstday,
				buttonText: '☶'
			} );

			// Color picker.
			$( '#_wc_appointment_cal_color' ).wpColorPicker( {
				defaultColor: '#0073aa'
			} );

			return false;
		},
		wc_appointments_table_grid: function() {
			var value = $( this ).val();
			var tr    = $( this ).closest( 'tr' );
			var row   = $( tr );

			row.find( '.from_date, .from_day_of_week, .from_month, .from_week, .from_time, .from' ).hide();
			row.find( '.to_date, .to_day_of_week, .to_month, .to_week, .to_time, .to, .on_date' ).hide();
			row.find( '.repeating-label' ).hide();
			row.find( '.appointments-datetime-select-to' ).removeClass( 'appointments-datetime-select-both' );
			row.find( '.appointments-datetime-select-from' ).removeClass( 'appointments-datetime-select-both' );
			row.find( '.rrule' ).hide();

			if ( 'custom' === value ) {
				row.find( '.from_date, .to_date' ).show();
			}
			if ( 'custom:daterange' === value ) {
				row.find( '.from_time, .to_time' ).show();
				row.find( '.from_date, .to_date' ).show();
				row.find( '.appointments-datetime-select-to' ).addClass( 'appointments-datetime-select-both' );
				row.find( '.appointments-datetime-select-from' ).addClass( 'appointments-datetime-select-both' );
			}
			if ( 'months' === value ) {
				row.find( '.from_month, .to_month' ).show();
			}
			if ( 'weeks' === value ) {
				row.find( '.from_week, .to_week' ).show();
			}
			if ( 'days' === value ) {
				row.find( '.from_day_of_week, .to_day_of_week' ).show();
			}
			if ( value.match( '^time' ) ) {
				row.find( '.from_time, .to_time' ).show();
				//* Show the date range as well if "time range for custom dates" is selected
				if ( 'time:range' === value ) {
					row.find( '.from_date, .to_date' ).show();
					row.find( '.repeating-label' ).show();
					row.find( '.appointments-datetime-select-to' ).addClass( 'appointments-datetime-select-both' );
					row.find( '.appointments-datetime-select-from' ).addClass( 'appointments-datetime-select-both' );
				}
			}
			if ( 'duration' === value || 'slots' === value || 'quant' === value || 'sessions' === value ) {
				row.find( '.from, .to' ).show();
			}
			if ( row.closest( '#appointments_pricing' ).length ) {
				var sessionsRule = 'sessions' === value;
				var $slotCell    = row.find( 'td.wc_appointment_pricing_slot_cost' );
				$slotCell.toggleClass( 'wc_appointment_pricing_slot_cost--inactive', sessionsRule );
				$slotCell.find( '.price_wrap' ).attr( 'aria-hidden', sessionsRule ? 'true' : null );
				$slotCell.find( '[name="wc_appointment_pricing_cost[]"]' ).prop( 'readonly', sessionsRule );
				if ( sessionsRule ) {
					$slotCell.find( '[name="wc_appointment_pricing_cost_modifier[]"], [name="wc_appointment_pricing_cost[]"]' ).val( '' );
				}
			}
			if ( 'rrule' === value ) {
				row.find( '.rrule' ).show();
			}

			return false;
		},
		wc_appointments_table_grid_focus: function( e ) {
			var $this_body  = $( 'body' );
			var $this_table = $( this ).closest( 'table, tbody' );
			var $this_row   = $( this ).closest( 'tr' );

			//console.log( e );

			if ( 'focus' === e.type || 'focusin' === e.type || ( 'click' === e.type && $( this ).is( ':focus' ) ) ) {
				$( 'tr', $this_table ).removeClass( 'current' ).removeClass( 'last_selected' );
				$this_row.addClass( 'current' ).addClass( 'last_selected' );
				$this_body.addClass( 'row_highlighted' );
			}

			return false;
		},
		wc_appointments_table_grid_blur: function( e ) {
			var $this_body  = $( 'body' );
			var $this_table = $( this ).closest( 'table, tbody' );
			var $this_row   = $( this ).closest( 'tr' );

			$this_row.removeClass( 'current' );
			if ( 0 === $this_table.find( 'select:focus, input:focus, button:focus' ).length ) {
				$( 'tr', $this_table ).removeClass( 'current' ).removeClass( 'last_selected' );
				$this_body.removeClass( 'row_highlighted' );
			} else {
				var $focusedRow = $this_table.find( 'select:focus, input:focus, button:focus' ).closest( 'tr' );
				$( 'tr', $this_table ).removeClass( 'current' ).removeClass( 'last_selected' );
				$focusedRow.addClass( 'current' ).addClass( 'last_selected' );
			}

			return false;
		},
		wc_appointments_table_grid_clear_highlight_if_outside: function( e ) {
			var $target = $( e.target );
			if ( ! $target.closest( '#appointments_pricing, #appointments_products' ).length ) {
				$( '#appointments_pricing, #appointments_products' ).find( 'tr' ).removeClass( 'current' ).removeClass( 'last_selected' );
				$( 'body' ).removeClass( 'row_highlighted' );
			}
		},
		wc_appointments_sortable_rows: function() {
			if ( 'function' !== typeof $.fn.sortable ) {
				return false;
			}
			$( '#pricing_rows' ).sortable( {
				items: 'tr',
				cursor: 'move',
				axis: 'y',
				handle: '.sort',
				scrollSensitivity: 40,
				forcePlaceholderSize: true,
				helper: 'clone',
				opacity: 0.65,
				placeholder: {
					element: function() {
						return $( '<tr class="wc-metabox-sortable-placeholder"><td colspan=99>&nbsp;</td></tr>' )[0];
					},
					update: function() {}
				},
				start: function( event, ui ) {
					ui.item.css( 'background-color', '#f6f6f6' );
				},
				stop: function( event, ui ) {
					ui.item.prop( 'style', false );
					ui.item.show();
				}
			} );

			$( '.woocommerce_appointable_staff, .woocommerce_appointable_resources, .woocommerce_appointable_locations' ).sortable( {
				items: '> .wc-metabox:not([hidden])',
				cursor: 'move',
				axis: 'y',
				handle: 'h3',
				scrollSensitivity: 40,
				forcePlaceholderSize: true,
				helper: 'clone',
				opacity: 0.65,
				placeholder: 'wc-metabox-sortable-placeholder',
				start: function( event, ui ) {
					ui.item.css( 'background-color', '#f6f6f6' );
				},
				stop: function( event, ui ) {
					ui.item.prop( 'style', false );
					if ( $( this ).hasClass( 'wca-entity-list' ) && 'location' === $( this ).data( 'entity' ) ) {
						wc_appointments_writepanel.wc_appointments_entity_sync( $( '#wca_resource_list' ) );
						wc_appointments_writepanel.wc_appointments_location_meeting_visibility();
					}
				}
			} );
			var $locList = $( '#wca_location_list' );
			if ( $locList.hasClass( 'ui-sortable' ) ) {
				$locList.sortable(
					'customer_choice' === ( $( '#_wc_appointment_location_mode' ).val() || '' ) ? 'enable' : 'disable'
				);
			}


			return false;
		},
		wc_appointments_row_added: function() {
			$( '.wc_appointment_pricing_type select' ).trigger( 'change' );
			$( '.date-picker' ).datepicker( {
				dateFormat: 'yy-mm-dd',
				numberOfMonths: 1,
				showOtherMonths: true,
				changeMonth: true,
				showButtonPanel: true,
				showOn: 'button',
				firstDay: wc_appointments_writepanel_js_params.firstday,
				buttonText: '☶'
			} );

			return false;
		},
		wc_appointments_trigger_change_events: function() {
			$( '.wc_appointment_pricing_type select, #_wc_appointment_user_can_cancel, #_wc_appointment_user_can_reschedule, #_wc_appointment_allow_recurring, #_wca_appointment_membership, #_wc_appointment_has_price_label, #_wc_appointment_has_pricing, #_wc_appointment_duration_unit, #_wc_appointment_staff_assignment, #_wc_appointment_location_mode, #_stock, #_wc_appointment_qty_min, #_wc_appointment_qty_max, #_wc_appointment_recurring_min_occurrences, #_wc_appointment_recurring_max_occurrences, #_wc_appointment_has_restricted_days' ).trigger( 'change' );

			wc_appointments_writepanel.wc_appointments_open_product_data();

			return false;
		},
		wc_appointments_user_cancel: function() {
			if ( $( this ).is( ':checked' ) ) {
				$( '.form-field.appointment-cancel-limit' ).show();
			} else {
				$( '.form-field.appointment-cancel-limit' ).hide();
			}

			return false;
		},
		wc_appointments_open_product_data: function() {
			if ( !$( 'body' ).hasClass( 'post-type-product' ) ) {
				return false;
			}

			var product_type = $( 'select#product-type' ).val();
			if ( 'appointment' !== product_type ) {
				return false;
			}

			var box = $( '#woocommerce-product-data' );
			if ( !box.length ) {
				return false;
			}

			box.removeClass( 'closed' );
			box.find( '.inside' ).show();

			return false;
		},
		wc_appointments_user_reschedule: function() {
			if ( $( this ).is( ':checked' ) ) {
				$( '.form-field.appointment-reschedule-limit' ).show();
			} else {
				$( '.form-field.appointment-reschedule-limit' ).hide();
			}

			return false;
		},
		wc_appointments_allow_recurring: function() {
			var show = $( this ).is( ':checked' );
			$( '#woocommerce-product-data' ).toggleClass( 'wca-allow-recurring', show );
			$( '.appointment-recurring-storefront-options' ).toggle( show );
			if ( show ) {
				$( '#_wc_appointment_recurring_min_occurrences' ).trigger( 'change' );
			}
			return false;
		},
		wc_appointments_subscription_membership: function() {
			var $panel = $( '#wca_subscription_appointment_plan' );
			if ( ! $panel.length ) {
				return false;
			}

			var show = $( '#_wca_appointment_membership' ).is( ':checked' );
			var $group = $panel.find( '.show_if_wca_appointment_membership' );

			if ( show ) {
				$group.removeClass( 'hidden' ).show();
				wc_appointments_writepanel.wc_appointments_subscription_per_period_mode();
			} else {
				$group.addClass( 'hidden' ).hide();
			}

			return false;
		},
		wc_appointments_subscription_per_period_mode: function() {
			clearTimeout( wc_appointments_writepanel.subscription_per_period_timer );
			wc_appointments_writepanel.subscription_per_period_timer = setTimeout(
				wc_appointments_writepanel.wc_appointments_subscription_per_period_mode_update,
				0
			);
			return false;
		},
		wc_appointments_subscription_per_period_mode_update: function() {
			var $panel = $( '#wca_subscription_appointment_plan' );
			if ( ! $panel.length ) {
				return;
			}

			var $limit = $panel.find( '._wca_appointments_per_period_limit_field' );
			if ( 'custom' === $( '#_wca_appointments_per_period_mode' ).val() ) {
				$limit.removeClass( 'hidden' ).show();
			} else {
				$limit.addClass( 'hidden' ).hide();
			}
		},
		wc_appointments_recurring_occurrence: function() {
			var $min = $( '#_wc_appointment_recurring_min_occurrences' );
			var $max = $( '#_wc_appointment_recurring_max_occurrences' );
			if ( ! $min.length ) {
				return false;
			}
			var minVal = parseInt( $min.val(), 10 ) || 2;
			var maxVal = parseInt( $max.val(), 10 ) || 2;
			if ( $min.is( this ) && minVal > maxVal ) {
				$max.val( minVal );
				maxVal = minVal;
			} else if ( $max.is( this ) && maxVal < minVal ) {
				$min.val( maxVal );
				minVal = maxVal;
			}
			$min.prop( 'max', maxVal );
			$max.prop( 'min', minVal );
			return false;
		},
		wc_appointments_qty_min: function() {
			var qty_this	= parseInt( $( this ).val(), 10 );
			var qty_max		= parseInt( $( '#_wc_appointment_qty_max' ).val(), 10 );

			if ( qty_this > qty_max ) {
				$( '#_wc_appointment_qty_max' ).val( qty_this );
			}

			return false;
		},
		wc_appointments_qty_max: function() {
			var qty_this	= parseInt( $( this ).val(), 10 );
			var qty_min		= parseInt( $( '#_wc_appointment_qty_min' ).val(), 10 );

			if ( qty_this < qty_min ) {
				$( '#_wc_appointment_qty_min' ).val( qty_this );
			}

			return false;
		},
		wc_appointments_price_show: function() {
			var product_type = $( 'select#product-type' ).val();

			if ( 'appointment' === product_type ) {
				$( '.options_group.pricing' ).show();
				$( '.options_group.wcpbc_pricing' ).show(); // WooCommerce Price Based on Country integration.

				// Show additional pricing fields.
				$( '.options_group.pricing' ).find( 'span' ).show();
				$( '.options_group.wcpbc_pricing' ).find( 'span:first' ).show();
			}

			$( '.options_group.pricing' ).addClass( 'show_if_appointment' );
			$( '.options_group.wcpbc_pricing' ).addClass( 'show_if_appointment' ); // WooCommerce Price Based on Country integration.

			// Show additional pricing fields.
			$( '.options_group.pricing' ).find( '.show_if_simple' ).addClass( 'show_if_appointment' );
			$( '.options_group.wcpbc_pricing' ).find( '.show_if_simple' ).addClass( 'show_if_appointment' );

			return false;
		},
		wc_appointments_inventory_show: function() {
			var product_type = $( 'select#product-type' ).val();

			if ( 'appointment' === product_type ) {
				$( '.stock_fields' ).hide();
				$( '.stock_fields' ).addClass( 'hide_if_appointment' );
				$( '._stock_status_field' ).hide();
				$( '._stock_status_field' ).addClass( 'hide_if_appointment' );

				$( '._sold_individually_field' ).parents( '.options_group' ).show();
				$( '._sold_individually_field' ).parents( '.options_group' ).addClass( 'show_if_appointment' );

				$( '#inventory_product_data ._sold_individually_field' ).show();
				$( '#inventory_product_data ._sold_individually_field' ).addClass( 'show_if_appointment' );
			}

			return false;
		},
		wc_appointments_disable_hide: function() {
			var product_type = $( 'select#product-type' ).val();
			var type_defined = 'undefined' !== typeof product_type;

			if ( 'appointment' === product_type || !type_defined ) {
				$( 'body' ).find( '.disabled_if_appointment' )
					.prop( 'hidden', true )
					.prop( 'disabled', true );
			} else {
				$( 'body' ).find( '.disabled_if_appointment' )
					.prop( 'hidden', false )
					.prop( 'disabled', false );
			}

			return false;
		},
		wc_appointments_addon_style: function() {
			var product_type = $( 'select#product-type' ).val();
			var type_defined = 'undefined' !== typeof product_type;

			if ( 'appointment' === product_type || !type_defined ) {
				$( 'body' ).addClass( 'style_if_appointment' );
			} else {
				$( 'body' ).removeClass( 'style_if_appointment' );
			}

			return false;
		},
		wc_appointments_virtual_default: function() {
			var product_type       = $( 'select#product-type' ).val();
			var virtual_input      = $( 'body' ).find( 'input#_virtual' );
			var is_new_product     = $( 'body' ).hasClass( 'post-new-php' );
			var orig_checked_state = virtual_input.attr( 'checked' );

			//console.log( orig_checked_state );

			// Only set as default virtual on new product creation.
			if ( is_new_product ) {
				// Virtual as default only for appointment product tpye.
				if ( 'appointment' === product_type ) {
					virtual_input.prop( 'checked', true );
				// For other product types, revert to default.
				} else {
					if ( 'checked' === orig_checked_state ) {
						virtual_input.prop( 'checked', true );
					} else {
						virtual_input.prop( 'checked', false );
					}
				}
			}

			wc_appointments_writepanel.wc_appointments_virtual_appointment_tip();

			return false;
		},
		wc_appointments_virtual_appointment_tip: function() {
			var $label = $( 'label[for="_virtual"]' );
			var tip;
			if ( ! $label.length ) {
				return false;
			}
			if ( undefined === $label.data( 'wcaTipOriginal' ) ) {
				$label.data( 'wcaTipOriginal', $label.attr( 'data-tip' ) || '' );
			}
			tip = ( 'appointment' === $( 'select#product-type' ).val() )
				? ( wc_appointments_writepanel_js_params.i18n_virtual_appointment_tip || $label.data( 'wcaTipOriginal' ) )
				: $label.data( 'wcaTipOriginal' );
			$label.attr( 'data-tip', tip );
			return false;
		},
		wc_appointments_twilio_sms: function() {
			// admin settings toggles
			$( '.wc_twilio_sms_enable' ).each( function() {
				var notification = $( this ).data( 'notification' );

				$( this ).on( 'change', function() {
					if ( $( this ).is( ':checked' ) ) {
						$( 'input#wc_twilio_sms_appointments_' + notification + '_recipients' ).closest( 'tr' ).show();
						$( 'input#wc_twilio_sms_appointments_' + notification + '_schedule_number' ).closest( 'tr' ).show();
						$( 'textarea#wc_twilio_sms_appointments_' + notification + '_template' ).closest( 'tr' ).show();
					} else {
						$( 'input#wc_twilio_sms_appointments_' + notification + '_recipients' ).closest( 'tr' ).hide();
						$( 'input#wc_twilio_sms_appointments_' + notification + '_schedule_number' ).closest( 'tr' ).hide();
						$( 'textarea#wc_twilio_sms_appointments_' + notification + '_template' ).closest( 'tr' ).hide();
					}
				} ).trigger( 'change' );
			} );

			// appointments integration product tab

			// open / close SMS tab on product
			$( '#wc-twilio-sms-appointments-data .wc-metaboxes-wrapper' )
				.on( 'click', '.expand_all', function() {
					$( this ).closest( '.wc-metaboxes-wrapper' ).find( '.wc-metabox > .wc-metabox-content' ).show();
					return false;
				} )
				.on( 'click', '.close_all', function() {
					$( this ).closest( '.wc-metaboxes-wrapper' ).find( '.wc-metabox > .wc-metabox-content' ).hide();
					return false;
				} );

			// hide notification settings if "override" is not selected
			$( '.wc_twilio_sms_notification_toggle' ).each( function() {
				var notification   = $( this ).data( 'notification' );
				var scheduleNumber = $( 'input#wc_twilio_sms_appointments_' + notification + '_schedule_number' );

				$( this ).on( 'change', function() {
					if ( 'override' === $( this ).find( 'option:selected' ).val() ) {
						scheduleNumber.closest( 'p' ).show();
						scheduleNumber.closest( 'p' ).next( '.wc-twilio-sms-post-field' ).show();
						$( 'textarea#wc_twilio_sms_appointments_' + notification + '_template' ).closest( 'p' ).show();
					} else {
						scheduleNumber.closest( 'p' ).hide();
						scheduleNumber.closest( 'p' ).next( '.wc-twilio-sms-post-field' ).hide();
						$( 'textarea#wc_twilio_sms_appointments_' + notification + '_template' ).closest( 'p' ).hide();
					}
				} ).trigger( 'change' );
			} );

			return false;
		},
		wc_appointments_addon_adjust_duration: function() {
			if ( $( this ).is( ':checked' ) ) {
				$( this ).parents( '.wc-pao-addon-adjust-duration-container' ).find( '.wc-pao-addon-adjust-duration-settings' ).removeClass( 'hide' ).addClass( 'show' );
			} else {
				$( this ).parents( '.wc-pao-addon-adjust-duration-container' ).find( '.wc-pao-addon-adjust-duration-settings' ).removeClass( 'show' ).addClass( 'hide' );
			}
		},
		wc_appointments_addon_type: function() {
			var selectedValue = $( this ).val();
			var parent        = $( this ).parents( '.wc-pao-addon' );

			switch ( selectedValue ) {
				case 'multiple_choice':
				case 'checkbox':
					parent.find( '.wc-pao-addon-hide_duration-setting' ).removeClass( 'hide' ).addClass( 'show' );
					parent.find( '.wc-pao-addon-hide_price-setting' ).removeClass( 'hide' ).addClass( 'show' );
					parent.find( '.wc-pao-addon-adjust-duration-container' ).removeClass( 'show' ).addClass( 'hide' );
					break;
				case 'heading':
				case 'custom_price':
					parent.find( '.wc-pao-addon-adjust-duration-container' ).removeClass( 'show' ).addClass( 'hide' );
					break;
				default:
					parent.find( '.wc-pao-addon-hide_duration-setting' ).removeClass( 'show' ).addClass( 'hide' );
					parent.find( '.wc-pao-addon-hide_price-setting' ).removeClass( 'show' ).addClass( 'hide' );
					parent.find( '.wc-pao-addon-adjust-duration-container' ).removeClass( 'hide' ).addClass( 'show' );
					break;
			}

			return false;
		},
		wc_appointments_addon_label: function() {
			var product_type = $( 'select#product-type' ).val();
			var type_defined = 'undefined' !== typeof product_type;

			if ( 'appointment' === product_type || !type_defined ) {
				$( 'body' ).addClass( 'style_if_appointment' );
				$( 'body' ).addClass( 'style_if_appointment' );
			} else {
				$( 'body' ).removeClass( 'style_if_appointment' );
				$( 'body' ).removeClass( 'style_if_appointment' );
			}

			if ( 'appointment' === product_type || !type_defined ) {
				$( '.show_if_appointment' ).show();
			} else {
				$( '.show_if_appointment' ).hide();
			}

			return false;
		},
		wc_appointments_price_label: function() {
			if ( $( this ).is( ':checked' ) ) {
				$( '.form-field._wc_appointment_price_label_field' ).show();
			} else {
				$( '.form-field._wc_appointment_price_label_field' ).hide();
			}

			return false;
		},
		wc_appointments_pricing: function() {
			if ( $( this ).is( ':checked' ) ) {
				$( '#appointments_pricing' ).show();
			} else {
				$( '#appointments_pricing' ).hide();
			}

			return false;
		},
		wc_appointments_staff_assignment: function() {
			if ( 'customer' === $( this ).val() ) {
				$( '.form-field._wc_appointment_staff_label_field' ).show();
				$( '.form-field._wc_appointment_staff_nopref_field' ).show();
			} else {
				$( '.form-field._wc_appointment_staff_label_field' ).hide();
				$( '.form-field._wc_appointment_staff_nopref_field' ).hide();
			}

			return false;
		},
		wc_appointments_location_mode: function() {
			var $mode = $( '#_wc_appointment_location_mode' );
			var mode = $mode.val() || 'none';
			var prev = $mode.data( 'wcaLocationMode' );
			var $list = $( '#wca_location_list' );
			var fixed = ( 'fixed' === mode || 'hidden' === mode );
			var prevFixed = ( 'fixed' === prev || 'hidden' === prev );
			if ( fixed ) {
				$list.find( '.is-assigned' ).slice( 1 ).removeClass( 'is-assigned' );
			} else if ( 'customer_choice' === mode && prevFixed ) {
				$list.find( '.is-assigned' ).removeClass( 'is-assigned' );
			}
			$( '#appointment_locations_list .wca-locations-list-title' ).text(
				fixed
					? ( wc_appointments_writepanel_js_params.i18n_location || 'Location' )
					: ( wc_appointments_writepanel_js_params.i18n_locations || 'Locations' )
			);
			var $select = $( '#add_location_id' );
			if ( $select.length ) {
				var placeholder = fixed
					? ( $select.data( 'placeholderFixed' ) || wc_appointments_writepanel_js_params.i18n_select_location )
					: ( $select.data( 'placeholderCustomer' ) || wc_appointments_writepanel_js_params.i18n_select_locations || 'Select locations' );
				$select.attr( 'data-placeholder', placeholder ).data( 'placeholder', placeholder );
				wc_appointments_writepanel.wc_appointments_refresh_enhanced_select( $select );
			}
			wc_appointments_writepanel.wc_appointments_entity_sync( $list );
			$mode.data( 'wcaLocationMode', mode );
			return false;
		},
		wc_appointments_refresh_enhanced_select: function( $select ) {
			if ( ! $select || ! $select.length ) {
				return;
			}
			if ( $select.hasClass( 'select2-hidden-accessible' ) && 'function' === typeof $select.selectWoo ) {
				$select.selectWoo( 'destroy' );
				$select.removeClass( 'enhanced' );
				$( document.body ).trigger( 'wc-enhanced-select-init' );
			}
			$select.val( '' ).trigger( 'change' );
		},
		// Staff / Locations / Resources: show assigned rows, enable inputs, disable picker options.
		wc_appointments_entity_sync: function( $list ) {
			if ( ! $list.length ) {
				return;
			}
			var entity = $list.data( 'entity' );
			var idAttr = $list.data( 'idAttr' );
			var mode = $( '#_wc_appointment_location_mode' ).val() || 'none';
			var locState = null;
			if ( 'resource' === entity ) {
				var $locs = $( '#wca_location_list' );
				var shopHasLocs = $locs.children( '.wc-metabox' ).length > 0
					|| $( '#add_location_id option[value!=""]' ).length > 0;
				var allowed = [];
				if ( shopHasLocs && 'none' !== mode ) {
					$locs.children( '.is-assigned' ).each( function() {
						var lid = String( $( this ).attr( 'data-location-id' ) || '' );
						if ( lid ) {
							allowed.push( lid );
						}
					} );
					if ( ! allowed.length && 'customer_choice' === mode ) {
						allowed = $locs.children( '.wc-metabox:not(.is-missing)' ).map( function() {
							return String( $( this ).attr( 'data-location-id' ) || '' );
						} ).get().filter( Boolean );
						if ( ! allowed.length ) {
							allowed = $( '#add_location_id option' ).map( function() {
								return String( this.value || '' );
							} ).get().filter( Boolean );
						}
					}
				}
				locState = { shopHasLocs: shopHasLocs, allowed: allowed };
			}
			var venueOk = function( lid ) {
				if ( ! locState ) {
					return true;
				}
				if ( 'missing' === lid ) {
					return true;
				}
				if ( ! locState.shopHasLocs ) {
					return '0' === lid;
				}
				return locState.allowed.length > 0 && -1 !== locState.allowed.indexOf( lid );
			};
			var assigned = {};
			$list.children( '.wc-metabox' ).each( function() {
				var $row = $( this );
				var id = String( $row.attr( idAttr ) || '' );
				var ok = 'resource' !== entity || venueOk( String( $row.attr( 'data-location-id' ) || '0' ) );
				var on = $row.hasClass( 'is-assigned' ) && ok;
				if ( $row.hasClass( 'is-assigned' ) ) {
					assigned[ id ] = true;
				}
				$row.prop( 'hidden', ! on );
				$row.find( 'input' ).prop( 'disabled', ! on );
			} );
			if ( 'resource' === entity ) {
				$( '#appointments_resources .wca-resource-need-location' ).prop(
					'hidden',
					! ( locState && locState.shopHasLocs && 0 === locState.allowed.length )
				);
			}
			var $select = $( $list.data( 'picker' ) );
			var refresh = false;
			var addedSuffix = ' (' + ( wc_appointments_writepanel_js_params.i18n_added || 'Added' ) + ')';
			$select.find( 'option' ).each( function() {
				var $opt = $( this );
				var id = String( $opt.val() || '' );
				if ( ! id ) {
					return;
				}
				var isAssigned = !! assigned[ id ];
				var disable = isAssigned;
				if ( 'resource' === entity ) {
					disable = disable || ! venueOk( String( $opt.attr( 'data-location-id' ) || '0' ) );
				}
				if ( ! $opt.attr( 'data-label' ) ) {
					$opt.attr( 'data-label', $.trim( $opt.text() ) );
				}
				var label = $opt.attr( 'data-label' );
				var text = isAssigned ? label + addedSuffix : label;
				if ( !! $opt.prop( 'disabled' ) !== disable || $opt.text() !== text ) {
					refresh = true;
				}
				$opt.prop( 'disabled', disable ).text( text );
			} );
			if ( refresh ) {
				wc_appointments_writepanel.wc_appointments_refresh_enhanced_select( $select );
			} else if ( $select.length ) {
				$select.val( '' ).trigger( 'change' );
			}
			if ( $list.hasClass( 'ui-sortable' ) ) {
				$list.sortable( 'refresh' );
				if ( 'location' === entity ) {
					$list.sortable( 'customer_choice' === mode ? 'enable' : 'disable' );
				}
			}
			if ( 'location' === entity ) {
				wc_appointments_writepanel.wc_appointments_location_meeting_visibility();
				wc_appointments_writepanel.wc_appointments_entity_sync( $( '#wca_resource_list' ) );
			}
		},
		wc_appointments_location_meeting_visibility: function() {
			var $meeting = $( '._wc_appointment_meeting_provider_field' );
			var mode = $( '#_wc_appointment_location_mode' ).val();
			if ( ! $meeting.length ) {
				return false;
			}
			if ( 'none' === mode ) {
				$meeting.hide();
				return false;
			}
			var $rows = $( '#wca_location_list .is-assigned' );
			if ( ! $rows.length && 'customer_choice' === mode ) {
				$rows = $( '#wca_location_list .wc-metabox:not(.is-missing)' );
			}
			var hasOnline = false;
			$rows.each( function() {
				if ( 'online' === String( $( this ).attr( 'data-kind' ) || '' ) ) {
					hasOnline = true;
					return false;
				}
			} );
			$meeting.toggle( hasOnline );
			return false;
		},
		wc_appointment_duration_unit: function() {
			switch ( $( this ).val() ) {
				case 'month':
					$( '.form-field._wc_appointment_interval_duration_wrap' ).hide();
					$( '.form-field._wc_appointment_padding_duration_wrap' ).hide();
					$( '.form-field._wc_appointment_customer_timezones_field' ).hide();
					break;
				case 'day':
				case 'night':
					$( '.form-field._wc_appointment_interval_duration_wrap' ).hide();
					$( '.form-field._wc_appointment_padding_duration_wrap' ).show();
					$( '.form-field._wc_appointment_customer_timezones_field' ).hide();
					$( '#_wc_appointment_padding_duration_unit option[value="minute"]' ).hide();
					$( '#_wc_appointment_padding_duration_unit option[value="hour"]' ).hide();
					$( '#_wc_appointment_padding_duration_unit option[value="day"]' ).show();
					$( '#_wc_appointment_padding_duration_unit' ).val( 'day' );
					break;
				default: // all other.
					$( '.form-field._wc_appointment_interval_duration_wrap' ).show();
					$( '.form-field._wc_appointment_padding_duration_wrap' ).show();
					$( '.form-field._wc_appointment_customer_timezones_field' ).show();
					$( '#_wc_appointment_padding_duration_unit option[value="minute"]' ).show();
					$( '#_wc_appointment_padding_duration_unit option[value="hour"]' ).show();
					$( '#_wc_appointment_padding_duration_unit option[value="day"]' ).hide();
					break;
			}

			return false;
		},
		wc_appointment_restricted_days: function() {
			if ( $( this ).is( ':checked' ) ) {
				$( '.appointment-day-restriction' ).show();
			} else {
				$( '.appointment-day-restriction' ).hide();
			}

			return false;
		},
		wc_appointments_table_grid_add_row: function( e ) {
			var newRowIndex = $( e.target ).closest( 'table' ).find( '#pricing_rows tr' ).length;
			var newRow = $( this ).data( 'row' );
			newRow = newRow.replace( /appointments_cost_js_index_replace/ig, newRowIndex.toString() );
			$( e.target ).closest( 'table' ).find( 'tbody' ).append( newRow );
			$( 'body' ).trigger( 'row_added' );

			return false;
		},
		wc_appointments_table_grid_remove_row: function( e ) {
			$( e.target ).closest( 'tr' ).remove();
			return false;
		},
		wc_appointments_manual_sync: function() {
			var el       = $( this ).closest( 'td' );
			var staff_id = $( this ).attr( 'data-staff' );
			var $button  = $( this );

			// Show confirmation dialog explaining what will happen.
			var confirmMessage = staff_id 
				? wc_appointments_writepanel_js_params.i18n_manual_sync_confirm_staff
				: wc_appointments_writepanel_js_params.i18n_manual_sync_confirm_global;
			
			if ( ! confirm( confirmMessage ) ) {
				return false;
			}

			// Update button text and disable it.
			var originalText = $button.text();
			$button.text( wc_appointments_writepanel_js_params.i18n_manual_sync_syncing ).prop( 'disabled', true );

			// Block removed element.
			$( el ).block( { message: null } );

			var data = {
				action: 'woocommerce_manual_sync',
				staff_id: staff_id,
				security: wc_appointments_writepanel_js_params.nonce_manual_sync
			};

			$.post( wc_appointments_writepanel_js_params.ajax_url, data, function( response ) {
				if ( response.error ) {
					alert( response.error );
					$button.text( originalText ).prop( 'disabled', false );
					$( el ).unblock();
				} else {
					$( '.last_synced' ).html( response.html );
					// Show success message before reload.
					if ( response.message ) {
						alert( response.message );
					}
					$button.text( originalText ).prop( 'disabled', false );
					$( el ).unblock();
				}
			} ).fail( function() {
				alert( wc_appointments_writepanel_js_params.i18n_manual_sync_failed );
				$button.text( originalText ).prop( 'disabled', false );
				$( el ).unblock();
			} );

			return false;
		},
		wc_appointments_oauth_redirect: function() {
			var el       = $( this ).closest( 'td' );
			var staff_id = $( this ).attr( 'data-staff' );
			var logout   = $( this ).attr( 'data-logout' );

			// Block removed element.
			$( el ).block( { message: null } );

			var data = {
				action: 'woocommerce_oauth_redirect',
				staff_id: staff_id,
				logout: logout,
				security: wc_appointments_writepanel_js_params.nonce_oauth_redirect
			};

			$.post( wc_appointments_writepanel_js_params.ajax_url, data, function( response ) {
				if ( response.error ) {
					alert( response.error );
					$( el ).unblock();
				} else {
					top.location.replace( response.uri );
					$( el ).unblock();
				}
			} );
		},
		wc_appointments_add_product: function() {
			var add_product_id   = parseInt( $( 'select#add_product_id' ).val(), 10 );
			var staff 	         = parseInt( $( 'select#add_product_id' ).attr( 'data-staff' ) );
			var products         = $( '#wc_appointments_staff_product_ids' ).val();
			var add_product_name = '';

			$( '.woocommerce_staff_products' ).block( { message: null } );

			var data = {
				action: 'woocommerce_add_staff_product',
				staff_id: staff,
				assigned_products: products,
				add_product_id: add_product_id,
				add_product_name: add_product_name,
				security: wc_appointments_writepanel_js_params.nonce_add_product
			};

			$.post( wc_appointments_writepanel_js_params.ajax_url, data, function( response ) {
				if ( response.error ) {
					alert( response.error );
					$( '.woocommerce_staff_products' ).unblock();
				} else {
					$( '.woocommerce_staff_products' ).append( response.html ).unblock();
					$( '#wc_appointments_staff_product_ids' ).val( products + ',' + add_product_id );
				}
			} );

			return false;
		},
		wc_appointments_remove_product: function( element ) {
			element.preventDefault();
			var answer = confirm( wc_appointments_writepanel_js_params.i18n_confirmation );
			if ( answer ) {
				var el = $( this ).parent();

				// Remove selected product ID from comma separated list.
				var product_id 	= $( this ).attr( 'data-product' );
				var staff_id 	= $( this ).attr( 'data-staff' );

				// Remove from product IDs.
				var product_ids = $( '#wc_appointments_staff_product_ids' ).val();
				var new_product_ids = product_ids.replace( new RegExp( ',?' + product_id + ',?' ), function( match ) {
					var first_comma = ',' === match.charAt( 0 );
					var second_comma = ',' === match.charAt( match.length - 1 );
					if ( first_comma && second_comma ) {
						return ',';
					}
					return '';
			    } );
				$( '#wc_appointments_staff_product_ids' ).val( new_product_ids );

				// Block removed element.
				$( el ).block( { message: null } );

				var data = {
					action: 'woocommerce_remove_appointable_staff',
					post_id: product_id,
					staff_id: staff_id,
					security: wc_appointments_writepanel_js_params.nonce_delete_staff
				};

				$.post( wc_appointments_writepanel_js_params.ajax_url, data, function() {
					$( el ).fadeOut( '300', function() {
						$( el ).remove();
					} );
				} );
			}

			return false;
		},
		wc_appointments_exporter_title_action: function() {
			// Add buttons to appointment screen.
			var $appointmen_screen = $( '.edit-php.post-type-wc_appointment' );
			var	$title_action      = $appointmen_screen.find( '.page-title-action:first' );
			var	$blankslate        = $appointmen_screen.find( '.woocommerce-BlankState' );

			if ( 0 === $blankslate.length ) {
				if ( wc_appointments_writepanel_js_params.exporter.permission ) {
					$title_action.after(
						'<a href="' +
						wc_appointments_writepanel_js_params.exporter.url +
						'" class="page-title-action">' +
						wc_appointments_writepanel_js_params.exporter.string +
						'</a>'
					);
				}
			} else {
				$title_action.hide();
			}
		},
		wc_appointments_add_appointment_actions: function() {
			$( '#appointment_order_id' ).filter( ':not(.enhanced)' ).each( function() {
				var select2_args = {
					allowClear: true,
					placeholder: $( this ).data( 'placeholder' ),
					minimumInputLength: 1,
					escapeMarkup: function( m ) {
						return m;
					},
					ajax: {
						url: wc_appointments_writepanel_js_params.ajax_url,
						dataType: 'json',
						quietMillis: 250,
						data: function( params ) {
							return {
								term: params.term,
								action: 'wc_appointments_json_search_order',
								security: wc_appointments_writepanel_js_params.nonce_appointment_order
							};
						},
						processResults: function( data ) {
							var terms = [];
							if ( data ) {
								$.each( data, function( id, text ) {
									terms.push( {
										id: id,
										text: text
									} );
								} );
							}
							return {
								results: terms
							};
						},
						cache: true
					},
					multiple: false
				};
				$( this ).select2( select2_args ).addClass( 'enhanced' );
			} );
			$( function() {
				var order_label_selector = $( '.appointment-order-label-select' );
				var	order_billing_row    = $( 'tr.billing_row' );
				$( '.appointment-order-selector' ).on( 'change', function() {
					var order_selector = $( this ).val();
					if ( 'existing' === order_selector ) {
						order_label_selector.show();
						order_billing_row.hide();
					} else {
						order_label_selector.hide();
						order_billing_row.show();
					}
				} );
			} );
		},
		wc_appointments_edit_billing: function( element ) {
			element.preventDefault();

			var el            = $( this );
			var	wrapper       = el.closest( '.billing_row' );
			var	edit_billing  = wrapper.find( 'div.edit_billing' );
			var	none_set      = wrapper.find( 'p.none_set' );
			var country_input = edit_billing.find( '.js_field-country' );
			var	state_input   = edit_billing.find( '.js_field-state' );

			el.parent().find( 'a' ).toggle();

			if ( !country_input.val() ) {
				country_input.val( wc_appointments_writepanel_js_params.billing.default_country ).trigger( 'change' );
				state_input.val( wc_appointments_writepanel_js_params.billing.default_state ).trigger( 'change' );
			}

			none_set.toggle();
			edit_billing.toggle();

			return false;
		},
		wc_appointments_indexing_controls: function() {
			if ( 'undefined' === typeof ajaxurl || ! $( '#wc-appointments-start-reindex' ).length ) {
				return;
			}

			var nonce = wc_appointments_writepanel_js_params.nonce_indexing || '';
			var i18n = wc_appointments_writepanel_js_params || {};
			var $fieldset = $( '#wc-appointments-indexing-controls' );
			var $btn = $( '#wc-appointments-start-reindex' );
			var $stopBtn = $( '#wc-appointments-stop-reindex' );
			var $resumeBtn = $( '#wc-appointments-resume-reindex' );
			var $status = $( '#wc-appointments-index-status' );
			var $notice = $( '#wc-appointments-index-notice' );
			var $progress = $( '#wc-appointments-index-progress' );
			var $counts = $( '#wc-appointments-index-counts' );
			var manuallyTriggered = false;
			var pollStartTime = 0;
			var maxPollTime = 300000;
			var lastProcessedAll = -1;
			var visualPercent = 0;
			var pollTimer = null;

			var format = function( template, value ) {
				return ( template || '' ).replace( '%s', value );
			};

			var statusText = function( statusValue ) {
				var tpl = i18n.i18n_reindex_status_format || 'Status: %s';
				return format( tpl, statusValue );
			};

			var extractProgress = function( res ) {
				if ( res && res.data && res.data.progress ) {
					return res.data.progress;
				}
				if ( res && res.data && res.data.status ) {
					return res.data;
				}
				return {};
			};

			var showNotice = function( message, isError ) {
				var $paragraph = $notice.find( 'p' );
				if ( ! $paragraph.length ) {
					$paragraph = $( '<p></p>' ).appendTo( $notice );
				}
				if ( ! message ) {
					$notice.hide().removeClass( 'notice-error notice-warning' );
					$paragraph.text( '' );
					return;
				}
				$notice
					.toggleClass( 'notice-error', !! isError )
					.toggleClass( 'notice-warning', ! isError )
					.show();
				$paragraph.text( message );
			};

			var clearPollTimer = function() {
				if ( pollTimer ) {
					clearTimeout( pollTimer );
					pollTimer = null;
				}
			};

			var resetUiIdle = function() {
				clearPollTimer();
				$status.removeClass( 'is-running' );
				$progress.hide();
				$progress.removeClass( 'is-disabled is-complete' ).removeAttr( 'aria-disabled' ).removeAttr( 'tabindex' );
				$counts.text( '' );
				$btn.prop( 'disabled', false ).show();
				$stopBtn.hide();
				$resumeBtn.hide();
				manuallyTriggered = false;
				pollStartTime = 0;
				lastProcessedAll = -1;
				visualPercent = 0;
			};

			function render( data ) {
				var status = data.status || 'idle';
				var totalRules = data.total_rules || 0;
				var processedRules = data.processed_rules || 0;
				var totalAppts = data.total_appointments || 0;
				var processedAppts = data.processed_appts || 0;
				var cacheRowsCreated = data.cache_rows_created || 0;
				var errorMessage = data.error_message || '';
				var totalAll = Math.max( 1, totalRules + totalAppts );
				var processedAll = processedRules + processedAppts;
				var percent = 0;
				var $bar = $progress.find( '.progress-bar' );
				var $text = $progress.find( '.progress-text' );

				if ( 'completed' === status ) {
					percent = 100;
				} else if ( 0 < totalAll ) {
					percent = Math.max( 0, Math.min( 99, Math.round( ( processedAll / totalAll ) * 100 ) ) );
				}

				$status.text( statusText( status ) );

				if ( 'running' === status || 'queued' === status ) {
					$status.addClass( 'is-running' );
					showNotice( '', false );
					$bar.css( 'transition', 'width 400ms ease' );
					visualPercent = Math.min( percent, visualPercent + Math.max( 1, Math.round( ( percent - visualPercent ) * 0.5 ) ) );
					$bar.css( 'width', visualPercent + '%' );
					$text.text( Math.round( visualPercent ) + '%' );
					$progress.show();
					$progress.addClass( 'is-disabled' ).removeClass( 'is-complete' ).attr( 'aria-disabled', 'true' ).removeAttr( 'tabindex' );
					$counts.text( 'Rules: ' + processedRules + '/' + totalRules + ' • Appointments: ' + processedAppts + '/' + totalAppts + ' • Cache rows created: ' + cacheRowsCreated.toLocaleString() );
					$btn.prop( 'disabled', true );
					$stopBtn.show();
					$resumeBtn.hide();
					return;
				}

				if ( 'completed' === status ) {
					clearPollTimer();
					manuallyTriggered = false;
					pollStartTime = 0;
					$status.removeClass( 'is-running' ).text( statusText( status ) );
					$bar.css( 'width', '100%' );
					$text.text( '100%' );
					$progress.show();
					$progress.removeClass( 'is-disabled' ).addClass( 'is-complete' ).attr( 'aria-disabled', 'false' ).attr( 'tabindex', '0' );
					$counts.text( 'Rules: ' + processedRules + '/' + totalRules + ' • Appointments: ' + processedAppts + '/' + totalAppts + ' • Cache rows created: ' + cacheRowsCreated.toLocaleString() );
					var currentTime = new Date().toLocaleString();
					var lastIndexingText = 'Last manual re-index: <strong>' + currentTime + '</strong> (' + processedRules + ' rules, ' + processedAppts + ' appointments, ' + cacheRowsCreated.toLocaleString() + ' cache rows)';
					$fieldset.find( 'p.wc-appointments-last-indexing' ).html( lastIndexingText );
					showNotice( '', false );
					$btn.prop( 'disabled', false ).show();
					$stopBtn.hide();
					$resumeBtn.hide();
					return;
				}

				if ( 'failed' === status ) {
					showNotice( errorMessage || i18n.i18n_reindex_unknown_error || '', true );
					resetUiIdle();
					$status.text( format( i18n.i18n_reindex_status_failed || 'Status: failed — %s', errorMessage || status ) );
					return;
				}

				if ( 'stopped' === status ) {
					showNotice( errorMessage || i18n.i18n_reindex_stopped || '', true );
					resetUiIdle();
					$status.text( statusText( status ) );
					return;
				}

				// Idle — allow resume UI if server still reports running (edge case).
				resetUiIdle();
				$status.text( statusText( 'idle' ) );
			}

			function schedulePoll( delay ) {
				clearPollTimer();
				pollTimer = setTimeout( poll, delay );
			}

			function handleTerminalPollFailure( res, ajaxStatus ) {
				var prog = extractProgress( res );
				var message = ( res && res.data && res.data.message ) ? res.data.message : '';
				if ( ! message && prog.error_message ) {
					message = prog.error_message;
				}
				if ( ! message && ajaxStatus ) {
					message = ajaxStatus;
				}
				if ( prog.status ) {
					render( prog );
					return;
				}
				resetUiIdle();
				showNotice( message || i18n.i18n_reindex_unknown_error || '', true );
				$status.text(
					format(
						i18n.i18n_reindex_status_failed || 'Status: failed — %s',
						message || i18n.i18n_reindex_unknown_error || ''
					)
				);
			}

			function poll() {
				if ( ! manuallyTriggered ) {
					return;
				}

				if ( 0 < pollStartTime && ( Date.now() - pollStartTime ) > maxPollTime ) {
					$status.text( i18n.i18n_reindex_status_timeout || statusText( 'timeout' ) );
					$.post( ajaxurl, {
						action: 'wc_appointments_stop_reindex',
						_wpnonce: nonce
					} ).always( function( res ) {
						var prog = extractProgress( res );
						if ( prog.status ) {
							render( prog );
						} else {
							resetUiIdle();
							showNotice( i18n.i18n_reindex_stopped || '', true );
						}
					} );
					return;
				}

				$.post( ajaxurl, {
					action: 'wc_appointments_process_reindex_chunk',
					_wpnonce: nonce,
					limit: 50
				} ).done( function( res ) {
					var prog = extractProgress( res );
					if ( res && res.success ) {
						render( prog );
						if ( 'running' === prog.status || 'queued' === prog.status ) {
							var processedAllNow = ( prog.processed_rules || 0 ) + ( prog.processed_appts || 0 );
							var nextDelay = processedAllNow > lastProcessedAll ? 350 : 1200;
							lastProcessedAll = processedAllNow;
							schedulePoll( nextDelay );
						} else {
							manuallyTriggered = false;
							clearPollTimer();
						}
						return;
					}
					handleTerminalPollFailure( res );
					manuallyTriggered = false;
					clearPollTimer();
				} ).fail( function( xhr, ajaxStatus ) {
					handleTerminalPollFailure( xhr.responseJSON || {}, ajaxStatus );
					manuallyTriggered = false;
					clearPollTimer();
				} );
			}

			function beginPolling( initial ) {
				render( initial );
				lastProcessedAll = ( initial.processed_rules || 0 ) + ( initial.processed_appts || 0 );
				manuallyTriggered = true;
				pollStartTime = Date.now();
				schedulePoll( 350 );
			}

			function startReindex() {
				if ( ! confirm( i18n.i18n_reindex_confirm || '' ) ) {
					return;
				}

				clearPollTimer();
				manuallyTriggered = true;
				$btn.prop( 'disabled', true );
				$stopBtn.show();
				$resumeBtn.hide();
				$status.text( i18n.i18n_reindex_status_starting || statusText( 'starting' ) );
				$status.addClass( 'is-running' );
				showNotice( '', false );

				var $bar = $progress.find( '.progress-bar' );
				var $text = $progress.find( '.progress-text' );
				$bar.css( 'width', '0%' );
				$text.text( '0%' );
				$progress.show();
				$progress.addClass( 'is-disabled' ).removeClass( 'is-complete' ).attr( 'aria-disabled', 'true' ).removeAttr( 'tabindex' );
				$counts.text( i18n.i18n_reindex_preparing || '' );

				$.post( ajaxurl, {
					action: 'wc_appointments_start_reindex',
					_wpnonce: nonce
				} ).done( function( res ) {
					if ( res && res.success && res.data && res.data.progress ) {
						beginPolling( res.data.progress );
						return;
					}
					var message = ( res && res.data && res.data.message ) ? res.data.message : ( i18n.i18n_reindex_no_response_data || '' );
					var prog = extractProgress( res );
					if ( prog.status ) {
						render( prog );
					} else {
						resetUiIdle();
						showNotice( message, true );
						$status.text( format( i18n.i18n_reindex_status_failed || 'Status: failed — %s', message ) );
					}
				} ).fail( function( xhr, ajaxStatus ) {
					resetUiIdle();
					showNotice( format( i18n.i18n_reindex_status_failed_ajax || 'Status: failed — %s', ajaxStatus ), true );
					$status.text( format( i18n.i18n_reindex_status_failed_ajax || 'Status: failed — %s', ajaxStatus ) );
				} );
			}

			$btn.on( 'click', function( e ) {
				e.preventDefault();
				startReindex();
			} );

			// Page load: recover interrupted re-index state from server-rendered progress.
			var initialProgress = $fieldset.data( 'initialProgress' ) || {};

			$stopBtn.on( 'click', function( e ) {
				e.preventDefault();
				clearPollTimer();
				$stopBtn.prop( 'disabled', true );
				$.post( ajaxurl, {
					action: 'wc_appointments_stop_reindex',
					_wpnonce: nonce
				} ).always( function( res ) {
					$stopBtn.prop( 'disabled', false );
					manuallyTriggered = false;
					var prog = extractProgress( res );
					var stopMessage = ( res && res.data && res.data.message ) ? res.data.message : '';
					if ( prog.status ) {
						if ( 'stopped' === prog.status && ! prog.error_message && stopMessage ) {
							prog.error_message = stopMessage;
						}
						render( prog );
					} else {
						resetUiIdle();
						showNotice( stopMessage || i18n.i18n_reindex_stopped || '', true );
					}
				} );
			} );

			$resumeBtn.on( 'click', function( e ) {
				e.preventDefault();
				showNotice( '', false );
				$btn.hide();
				beginPolling( $.extend( { status: 'running' }, initialProgress ) );
			} );
			if ( 'running' === initialProgress.status || 'queued' === initialProgress.status ) {
				render( initialProgress );
				$btn.hide();
				$stopBtn.show();
				$resumeBtn.show();
				showNotice( i18n.i18n_reindex_resume_prompt || '', false );
				$notice.removeClass( 'notice-error' ).addClass( 'notice-warning' );
			} else if ( 'failed' === initialProgress.status || 'stopped' === initialProgress.status ) {
				render( initialProgress );
			} else {
				render( { status: 'idle' } );
			}
		},

		/**
		 * GCal Sync Controls (standardized with reindex pattern).
		 */
		wc_appointments_gcal_sync_controls: function() {
			if ( typeof ajaxurl === 'undefined' || ! $( '#wc-appointments-start-gcal-sync' ).length ) {
				return;
			}

			var nonce = wc_appointments_writepanel_js_params.nonce_indexing || '';
			var $btn = $( '#wc-appointments-start-gcal-sync' );
			var $status = $( '#wc-appointments-gcal-sync-status' );
			var $progress = $( '#wc-appointments-gcal-sync-progress' );
			var $message = $( '#wc-appointments-gcal-sync-message' );
			var manuallyTriggered = false;
			var pollStartTime = 0;
			var maxPollTime = 300000; // 5 minutes max
			var lastPhase = '';
			var staffId = $btn.data( 'staff' ) || 0;
			var i18n = wc_appointments_writepanel_js_params || {};
			var format = function( template, value ) {
				return ( template || '' ).replace( '%s', value );
			};
			var formatCount = function( template, value ) {
				return ( template || '' ).replace( '%d', value );
			};
			var statusText = function( statusValue ) {
				var tpl = i18n.i18n_gcal_sync_status_format || '';
				return tpl ? format( tpl, statusValue ) : statusValue;
			};
			var phaseLabels = {
				backup: i18n.i18n_gcal_sync_phase_backup || '',
				delete: i18n.i18n_gcal_sync_phase_delete || '',
				sync: i18n.i18n_gcal_sync_phase_sync || '',
				complete: i18n.i18n_gcal_sync_phase_complete || ''
			};

			function render( progress ) {
				var status = progress.status || 'idle';
				var phase = progress.phase || '';
				var msg = progress.message || '';
				var phaseMessage = phaseLabels[ phase ] || '';

				// Only show status if not idle
				if ( status !== 'idle' ) {
					$status.text( statusText( status ) );
					$status.show();
				} else {
					$status.hide();
				}

				if ( status === 'running' || status === 'preparing' ) {
					$status.addClass( 'is-running' );
					$progress.show();
					$btn.prop( 'disabled', true );

					// Show phase-based progress
					var percent = 0;
					if ( phase === 'backup' ) {
						percent = 10;
					} else if ( phase === 'delete' ) {
						percent = 40;
					} else if ( phase === 'sync' ) {
						percent = 70;
					} else if ( phase === 'complete' ) {
						percent = 100;
					}

					var $bar = $progress.find( '.progress-bar' );
					var $text = $progress.find( '.progress-text' );
					$bar.css( 'width', percent + '%' );
					$text.text( percent + '%' );

					$message.text( phaseMessage || msg ).show();
				} else if ( status === 'completed' ) {
					$status.removeClass( 'is-running' );
					$progress.addClass( 'is-complete' );
					$btn.prop( 'disabled', false );
					manuallyTriggered = false;

					var $bar = $progress.find( '.progress-bar' );
					var $text = $progress.find( '.progress-text' );
					$bar.css( 'width', '100%' );
					$text.text( '100%' );

					$status.text(
						formatCount(
							i18n.i18n_gcal_sync_completed_count || '%d',
							parseInt( progress.synced_count || 0, 10 )
						)
					).show();
					$message.hide().text( '' );

					// Clear progress data before reload so message doesn't persist
					$.post( ajaxurl, {
						action: 'wc_appointments_clear_gcal_sync_progress',
						staff_id: staffId,
						_wpnonce: nonce
					} );
				} else if ( status === 'failed' ) {
					$status.removeClass( 'is-running' );
					$btn.prop( 'disabled', false );
					manuallyTriggered = false;
					$progress.hide();

					$message.text( msg || i18n.i18n_gcal_sync_failed_short || '' ).show();
				} else if ( status === 'stopped' ) {
					$status.removeClass( 'is-running' );
					$btn.prop( 'disabled', false );
					manuallyTriggered = false;
					$progress.hide();
					$message.text( i18n.i18n_gcal_sync_stopped || '' ).show();
				} else {
					$status.removeClass( 'is-running' );
					$btn.prop( 'disabled', false );
					$progress.hide();
					$message.hide().text( '' );
				}
			}

			function poll() {
				if ( ! manuallyTriggered ) {
					return;
				}

				if ( Date.now() - pollStartTime > maxPollTime ) {
					console.log( 'GCal sync poll timeout reached' );
					$status.text( i18n.i18n_gcal_sync_status_timeout || statusText( 'timeout' ) );
					$btn.prop( 'disabled', false );
					manuallyTriggered = false;
					$status.removeClass( 'is-running' );
					$progress.hide();
					return;
				}

				$.post( ajaxurl, {
					action: 'wc_appointments_process_gcal_sync_chunk',
					staff_id: staffId,
					_wpnonce: nonce
				} ).done( function( res ) {
					if ( res && res.success && res.data && res.data.progress ) {
						var progress = res.data.progress;
						render( progress );

						var status = progress.status || 'idle';
						var phase = progress.phase || '';

						if ( status === 'running' || status === 'preparing' ) {
							// Continue polling with adaptive cadence
							var delay = 500;
							if ( phase !== lastPhase ) {
								delay = 100; // Fast poll on phase change
								lastPhase = phase;
							}
							setTimeout( poll, delay );
						} else if ( status === 'completed' || status === 'failed' || status === 'stopped' ) {
							manuallyTriggered = false;
						}
					} else {
						console.log( 'GCal sync chunk failed:', res );
						$status.text( i18n.i18n_gcal_sync_status_error || statusText( 'error' ) );
						$btn.prop( 'disabled', false );
						manuallyTriggered = false;
						$status.removeClass( 'is-running' );
						$progress.hide();
					}
				} ).fail( function( xhr, status, error ) {
					console.log( 'GCal sync chunk AJAX failed:', status, error );
					$status.text( i18n.i18n_gcal_sync_status_error || statusText( 'error' ) );
					$btn.prop( 'disabled', false );
					manuallyTriggered = false;
					$status.removeClass( 'is-running' );
					$progress.hide();
				} );
			}

			$btn.on( 'click', function( e ) {
				e.preventDefault();

				if ( ! confirm( i18n.i18n_gcal_sync_confirm || i18n.i18n_manual_sync_confirm_global || '' ) ) {
					return;
				}

				manuallyTriggered = true;
				$btn.prop( 'disabled', true );
				$status.text( i18n.i18n_gcal_sync_status_starting || statusText( 'starting' ) );
				$status.addClass( 'is-running' );
				$progress.show();
				$progress.removeClass( 'is-complete' );

				var $bar = $progress.find( '.progress-bar' );
				var $text = $progress.find( '.progress-text' );
				$bar.css( 'width', '0%' );
				$text.text( '0%' );
				$message.text( i18n.i18n_gcal_sync_preparing || '' ).show();

				$.post( ajaxurl, {
					action: 'wc_appointments_start_gcal_sync',
					staff_id: staffId,
					_wpnonce: nonce
				} ).done( function( res ) {
					console.log( 'Start GCal sync response:', res );
					if ( res && res.success && res.data && res.data.progress ) {
						var initial = res.data.progress;
						render( initial );
						pollStartTime = Date.now();
						lastPhase = initial.phase || '';
						setTimeout( poll, 350 );
					} else {
						console.log( 'Start GCal sync failed:', res );
						$status.text(
							format(
								i18n.i18n_gcal_sync_status_failed || i18n.i18n_gcal_sync_status_format || '%s',
								( res.data ? res.data.message || i18n.i18n_gcal_sync_unknown_error || '' : i18n.i18n_gcal_sync_no_response_data || '' )
							)
						);
						$btn.prop( 'disabled', false );
						manuallyTriggered = false;
						$status.removeClass( 'is-running' );
						$progress.hide();
					}
				} ).fail( function( xhr, status, error ) {
					console.log( 'Start GCal sync AJAX failed:', status, error );
					$status.text(
						format(
							i18n.i18n_gcal_sync_status_failed_ajax || i18n.i18n_gcal_sync_status_format || '%s',
							status
						)
					);
					$btn.prop( 'disabled', false );
					manuallyTriggered = false;
					$status.removeClass( 'is-running' );
					$progress.hide();
				} );
			} );

			// Backup management handlers
			wc_appointments_writepanel.init_gcal_backup_controls();

			// Initialize - hide status when idle
			$status.hide();
			$progress.hide();
			$message.hide().text( '' );
		},

		/**
		 * Initialize Google Calendar backup management controls.
		 */
		init_gcal_backup_controls: function() {
			var i18n = wc_appointments_writepanel_js_params || {};
			var nonce = i18n.nonce_gcal_backup || '';
			var $exportBtn = $( '#wc-appointments-gcal-export' );
			var $importBtn = $( '#wc-appointments-gcal-import' );
			var $importFile = $( '#wc-appointments-gcal-import-file' );
			var $showBackupsBtn = $( '#wc-appointments-gcal-show-backups' );
			var $backupList = $( '#wc-appointments-gcal-backup-list' );

			// Export handler
			$exportBtn.on( 'click', function( e ) {
				e.preventDefault();
				var userId = $( this ).data( 'user-id' ) || 0;
				$exportBtn.prop( 'disabled', true );

				$.post( ajaxurl, {
					action: 'wc_appointments_gcal_export_rules',
					user_id: userId,
					security: nonce
				} ).done( function( res ) {
					if ( res && res.success ) {
						var data = res.data;
						var filename = 'gcal-rules-' + ( userId ? 'staff-' + userId : 'global' ) + '-' + data.export_date.replace( /[:.]/g, '-' ) + '.json';
						var blob = new Blob( [ JSON.stringify( data, null, 2 ) ], { type: 'application/json' } );
						var url = URL.createObjectURL( blob );
						var a = document.createElement( 'a' );
						a.href = url;
						a.download = filename;
						document.body.appendChild( a );
						a.click();
						document.body.removeChild( a );
						URL.revokeObjectURL( url );
					} else {
						alert( res.data ? res.data.message : i18n.i18n_gcal_export_failed || 'An error occurred. Please try again.' );
					}
					$exportBtn.prop( 'disabled', false );
				} ).fail( function() {
					alert( i18n.i18n_gcal_export_failed || 'An error occurred. Please try again.' );
					$exportBtn.prop( 'disabled', false );
				} );
			} );

			// Import handler
			$importBtn.on( 'click', function( e ) {
				e.preventDefault();
				$importFile.click();
			} );

			$importFile.on( 'change', function() {
				var file = this.files[0];
				if ( ! file ) return;

				var reader = new FileReader();
				reader.onload = function( e ) {
					try {
						var data = JSON.parse( e.target.result );
						var importConfirm = i18n.i18n_gcal_import_confirm || 'Import %d rules? This will add them to existing rules.';
						if ( ! confirm( importConfirm.replace( '%d', ( data.rule_count || 0 ) ) ) ) {
							return;
						}

						$importBtn.prop( 'disabled', true );
						$.post( ajaxurl, {
							action: 'wc_appointments_gcal_import_rules',
							data: JSON.stringify( data ),
							security: nonce
						} ).done( function( res ) {
							if ( res && res.success ) {
								alert( res.data.message || i18n.i18n_gcal_import_success || 'Import successful' );
								location.reload();
							} else {
								alert( res.data ? res.data.message : i18n.i18n_gcal_import_failed || 'An error occurred. Please try again.' );
							}
							$importBtn.prop( 'disabled', false );
						} ).fail( function() {
							alert( i18n.i18n_gcal_import_failed || 'An error occurred. Please try again.' );
							$importBtn.prop( 'disabled', false );
						} );
					} catch ( err ) {
						alert( i18n.i18n_gcal_invalid_json || 'Invalid JSON file' );
					}
				};
				reader.readAsText( file );
				$importFile.val( '' );
			} );

			// Show backups handler (toggle)
			$showBackupsBtn.on( 'click', function( e ) {
				e.preventDefault();
				var userId = $( this ).data( 'user-id' ) || 0;
				var $icon = $showBackupsBtn.find( '.dashicons' );
				
				if ( $backupList.is( ':visible' ) ) {
					$backupList.slideUp();
					$icon.removeClass( 'dashicons-arrow-up-alt2' ).addClass( 'dashicons-arrow-down-alt2' );
					$showBackupsBtn.attr( 'aria-expanded', 'false' );
					return;
				}

				$showBackupsBtn.prop( 'disabled', true );
				$.post( ajaxurl, {
					action: 'wc_appointments_gcal_get_backups',
					user_id: userId,
					security: nonce
				} ).done( function( res ) {
					if ( res && res.success ) {
						var backups = res.data.backups || [];
						if ( backups.length === 0 ) {
							$backupList.html( '<p class="description">' + ( i18n.i18n_gcal_no_backups || 'No backups available.' ) + '</p>' );
						} else {
							var html = '<table class="widefat"><thead><tr><th>' + ( i18n.i18n_gcal_backup_date || 'Date' ) + '</th><th>' + ( i18n.i18n_gcal_backup_rules || 'Rules' ) + '</th><th>' + ( i18n.i18n_gcal_backup_actions || 'Actions' ) + '</th></tr></thead><tbody>';
							backups.forEach( function( backup ) {
								var date = new Date( backup.timestamp * 1000 );
								html += '<tr>';
								html += '<td>' + date.toLocaleString() + '</td>';
								html += '<td>' + backup.rule_count + '</td>';
								html += '<td>';
								html += '<button type="button" class="button wc-gcal-restore-backup" data-backup-id="' + backup.id + '" data-user-id="' + userId + '">' + ( i18n.i18n_gcal_backup_restore || 'Restore' ) + '</button> ';
								html += '<button type="button" class="button wc-gcal-download-backup" data-backup-id="' + backup.id + '" data-user-id="' + userId + '">' + ( i18n.i18n_gcal_backup_download || 'Download' ) + '</button> ';
								html += '<button type="button" class="button wc-gcal-delete-backup" data-backup-id="' + backup.id + '" data-user-id="' + userId + '">' + ( i18n.i18n_gcal_backup_delete || 'Delete' ) + '</button>';
								html += '</td>';
								html += '</tr>';
							} );
							html += '</tbody></table>';
							$backupList.html( html );
						}
						$backupList.slideDown();
						$icon.removeClass( 'dashicons-arrow-down-alt2' ).addClass( 'dashicons-arrow-up-alt2' );
						$showBackupsBtn.attr( 'aria-expanded', 'true' );
					}
					$showBackupsBtn.prop( 'disabled', false );
				} ).fail( function() {
					alert( i18n.i18n_gcal_no_backups || 'Failed to load backups' );
					$showBackupsBtn.prop( 'disabled', false );
				} );
			} );

			// Restore backup handler (delegated)
			$backupList.on( 'click', '.wc-gcal-restore-backup', function( e ) {
				e.preventDefault();
				var backupId = $( this ).data( 'backup-id' );
				var userId = $( this ).data( 'user-id' ) || 0;
						if ( ! confirm( i18n.i18n_gcal_restore_confirm || 'Restore this backup? Current rules will be replaced.' ) ) {
					return;
				}

				$( this ).prop( 'disabled', true );
				$.post( ajaxurl, {
					action: 'wc_appointments_gcal_restore_backup',
					backup_id: backupId,
					user_id: userId,
					security: nonce
				} ).done( function( res ) {
					if ( res && res.success ) {
						alert( res.data.message || i18n.i18n_gcal_restore_success || 'Restore successful' );
						location.reload();
					} else {
						alert( res.data ? res.data.message : i18n.i18n_gcal_restore_failed || 'An error occurred. Please try again.' );
					}
				} ).fail( function() {
					alert( i18n.i18n_gcal_restore_failed || 'An error occurred. Please try again.' );
				} );
			} );

			// Download backup handler (delegated)
			$backupList.on( 'click', '.wc-gcal-download-backup', function( e ) {
				e.preventDefault();
				var backupId = $( this ).data( 'backup-id' );
				var userId = $( this ).data( 'user-id' ) || 0;

				$.post( ajaxurl, {
					action: 'wc_appointments_gcal_get_backups',
					user_id: userId,
					security: nonce
				} ).done( function( res ) {
					if ( res && res.success ) {
						var backups = res.data.backups || [];
						var backup = backups.find( function( b ) { return b.id === backupId; } );
						if ( backup ) {
							var exportData = {
								version: '1.0',
								export_date: new Date( backup.timestamp * 1000 ).toISOString(),
								context: userId ? 'staff' : 'global',
								context_id: userId,
								rule_count: backup.rule_count,
								rules: backup.rules
							};
							var filename = 'gcal-backup-' + backupId + '.json';
							var blob = new Blob( [ JSON.stringify( exportData, null, 2 ) ], { type: 'application/json' } );
							var url = URL.createObjectURL( blob );
							var a = document.createElement( 'a' );
							a.href = url;
							a.download = filename;
							document.body.appendChild( a );
							a.click();
							document.body.removeChild( a );
							URL.revokeObjectURL( url );
						}
					}
				} );
			} );

			// Delete backup handler (delegated)
			$backupList.on( 'click', '.wc-gcal-delete-backup', function( e ) {
				e.preventDefault();
				var backupId = $( this ).data( 'backup-id' );
				var userId = $( this ).data( 'user-id' ) || 0;
				if ( ! confirm( i18n.i18n_gcal_delete_backup_confirm || 'Delete this backup?' ) ) {
					return;
				}

				$( this ).prop( 'disabled', true );
				$.post( ajaxurl, {
					action: 'wc_appointments_gcal_delete_backup',
					backup_id: backupId,
					user_id: userId,
					security: nonce
				} ).done( function( res ) {
					if ( res && res.success ) {
						$showBackupsBtn.click();
					} else {
						alert( res.data ? res.data.message : i18n.i18n_gcal_delete_backup_failed || 'An error occurred. Please try again.' );
					}
				} ).fail( function() {
					alert( i18n.i18n_gcal_delete_backup_failed || 'An error occurred. Please try again.' );
				} );
			} );
		},

		/**
		 * Admin Settings - Toggle indexing options visibility
		 */
		wc_appointments_settings_init: function() {
			this.toggleIndexingOptions();
			$( '#wc_appointments_use_indexed_cache' ).on( 'change', this.toggleIndexingOptions );

			// Show/Hide for Google Calendar Client ID / Secret.
			var i18n = wc_appointments_writepanel_js_params || {};
			$( '#wc_appointments_gcal_client_id, #wc_appointments_gcal_client_secret' ).each( function() {
				var $input = $( this );
				var show = i18n.i18n_show_password || 'Show';
				var hide = i18n.i18n_hide_password || 'Hide';
				$( '<button type="button" class="button">' + show + '</button>' )
					.insertAfter( $input )
					.on( 'click', function() {
						var on = 'password' === $input.attr( 'type' );
						$input.attr( 'type', on ? 'text' : 'password' );
						$( this ).text( on ? hide : show );
					} );
			} );
		},

		toggleIndexingOptions: function() {
			var useIndexed = $( '#wc_appointments_use_indexed_cache' ).is( ':checked' );
			var $horizonRow = $( '#wc_appointments_cache_horizon_months' ).closest( 'tr' );
			// Find the fieldset that contains the re-index controls
			var $controlsFieldset = $( '#wc-appointments-start-reindex' ).closest( 'fieldset' );
			// Also find the table row that contains the fieldset
			var $controlsRow = $controlsFieldset.closest( 'tr' );

			if ( useIndexed ) {
				$horizonRow.show();
				$controlsFieldset.show();
				$controlsRow.show();
			} else {
				$horizonRow.hide();
				$controlsFieldset.hide();
				$controlsRow.hide();
			}
		},

		/**
		 * Open Appointments product data tabs from configuration notice links.
		 */
		initProductConfigTabLinks: function() {
			$( document ).on( 'click', '.wca-product-config-tab-link', function( e ) {
				if ( ! this.hash || 0 !== this.hash.indexOf( '#appointments_' ) ) {
					return;
				}
				e.preventDefault();
				wc_appointments_writepanel.goToProductConfigTarget( this.hash );
			} );
			if ( window.location.hash && 0 === window.location.hash.indexOf( '#appointments_' ) ) {
				wc_appointments_writepanel.goToProductConfigTarget( window.location.hash );
			}
		},

		goToProductConfigTarget: function( hash ) {
			if ( ! hash || 0 !== hash.indexOf( '#appointments_' ) ) {
				return;
			}
			wc_appointments_writepanel.wc_appointments_open_product_data();
			var tabHash = '#appointments_general' === hash ? '#general_product_data' : hash;
			var $tab = $( '#woocommerce-product-data ul.wc-tabs li a[href="' + tabHash + '"]' );
			if ( ! $tab.length ) {
				return;
			}
			if ( ! $tab.parent().hasClass( 'active' ) ) {
				$tab.trigger( 'click' );
			}
			window.setTimeout( function() {
				var $target = $( hash );
				if ( ! $target.length || ! $target.is( ':visible' ) ) {
					$target = $( tabHash );
				}
				if ( ! $target.length ) {
					$target = $( '#woocommerce-product-data' );
				}
				var top = Math.max( 0, $target.offset().top - ( $( '#wpadminbar' ).outerHeight() || 0 ) - 24 );
				$( 'html, body' ).stop( true ).animate( { scrollTop: top }, 250 );
				if ( window.history && window.history.replaceState ) {
					window.history.replaceState( null, '', window.location.pathname + window.location.search + hash );
				}
			}, 200 );
		},

		/**
		 * Disable all form fields when save/submit is initiated.
		 * Works on global settings (form#mainform) and staff profile (form#your-profile).
		 */
		initSaveDisable: function() {
			var forms = 'form#mainform, form#your-profile';
			$( document ).on( 'submit', forms, function() {
				var $form = $( this );
				var $container = $form.find( '#appointments_settings' );
				if ( ! $container.length ) {
					$container = $( '#appointments_settings' );
				}
				if ( ! $container.length ) {
					return;
				}

				// Add saving class for visual feedback.
				$container.addClass( 'wca-saving' );

				// Disable all interactive fields inside the availability container.
				$container.find( 'select, input:not([type="hidden"]), button, a.button, .add_grid_row' ).each( function() {
					var $el = $( this );
					if ( $el.is( 'a' ) ) {
						$el.addClass( 'disabled' ).css( 'pointer-events', 'none' );
					} else {
						$el.prop( 'disabled', true );
					}
				} );

				// Preserve the submit button's name/value in a hidden input
				// so WooCommerce still sees $_POST['save'] after we disable the button.
				$form.find( 'button[name="save"], input[name="save"]' ).each( function() {
					var $btn = $( this );
					if ( ! $form.find( 'input[type="hidden"][name="save"]' ).length ) {
						$form.append( '<input type="hidden" name="save" value="' + ( $btn.val() || '1' ) + '" />' );
					}
				} );

				// Now disable the submit/save button for visual feedback.
				$form.find( '.button-primary, input[type="submit"], button[type="submit"]' ).prop( 'disabled', true ).addClass( 'wca-saving-btn' );
			} );
		}
	};
	window.wc_appointments_writepanel = wc_appointments_writepanel;

	// Initialize when document is ready
	$( document ).ready( function() {
		wc_appointments_writepanel.init();
		wc_appointments_writepanel.wc_appointments_entity_sync( $( '#wca_staff_list' ) );
		if ( $( '#wca_location_list' ).length ) {
			wc_appointments_writepanel.wc_appointments_entity_sync( $( '#wca_location_list' ) );
		} else {
			wc_appointments_writepanel.wc_appointments_entity_sync( $( '#wca_resource_list' ) );
		}
	} );
} );
