/* globals wc_appointment_form_params, wc_appointments_timezone_picker_args, wca_get_cookie, wcaShared */

// globally accessible for tests
var wc_appointments_timezone_picker = {};

wcaShared.whenDepsReady(
	function() {
		return typeof jQuery !== 'undefined'
			&& typeof jQuery.fn.select2 === 'function'
			&& typeof wc_appointments_timezone_picker_args !== 'undefined';
	},
	function() {
		jQuery( function( $ ) {
	'use strict';

	var wc_appointments_timezone_picker_object = {
		get_short_name_from_option: function( option ) {
			var option_title = option.attr( 'title' ) || '';
			// title: "Timezone: Europe/Ljubljana - CEST" (abbr after last " - ").
			var title_dash = option_title.split( ' - ' );
			if ( title_dash.length > 1 && option_title.indexOf( 'Timezone:' ) === 0 ) {
				return title_dash.pop().trim();
			}

			var option_text = option.text() || '';
			// "City — CEST" (em dash) or "Default (Ljubljana - CEST)" / "Default (UTC)".
			var em_parts = option_text.split( '—' );
			if ( em_parts.length > 1 ) {
				return em_parts.pop().trim();
			}
			var paren = option_text.match( /\(([^()]+)\)\s*$/ );
			if ( paren && paren[1] ) {
				var inner = paren[1].trim();
				var inner_dash = inner.split( ' - ' );
				return ( inner_dash.length > 1 ? inner_dash.pop() : inner ).trim();
			}

			return '';
		},
		get_display_timezone_label: function( timezone, timezone_field ) {
			if ( timezone_field && timezone_field.length ) {
				var selected_option_short_name = wc_appointments_timezone_picker_object.get_short_name_from_option( timezone_field.find( 'option:selected' ) );
				if ( selected_option_short_name ) {
					return selected_option_short_name;
				}
			}

			var effective_timezone = timezone || wc_appointment_form_params.server_timezone;
			return effective_timezone.replace( '_', ' ' );
		},
		has_timezone_preference: function() {
			return !! wca_get_cookie( 'appointments_time_zone' )
				|| wca_get_cookie( 'appointments_use_site_timezone' ) === '1'
				|| !! wc_appointment_form_params.use_site_timezone;
		},
		init: function() {
			$( 'body' ).on( 'select2:select', 'select[name="wc_appointments_field_timezone"]', function() {
				wc_appointments_timezone_picker_object.select_timezone.call( this );
			} );
			$( 'a.selected-timezone' ).on( 'click', this.show_timezone_select );
			$( 'select[name="wc_appointments_field_timezone"]' ).on( 'select2:close', this.hide_timezone_select );

			$( '.wc-appointments-appointment-form' ).each( function() {
				var picker              = $( this ).find( '.picker:eq(0)' );
				var timezone_field      = $( this ).find( '.wc_appointments_field_timezone select' );
				var site_timezone       = wc_appointment_form_params.server_timezone;
				var local_timezone      = site_timezone;
				var timezone_conversion = picker.attr( 'data-timezone_conversion' );

				try {
					if ( typeof Intl !== 'undefined' && Intl.DateTimeFormat ) {
						local_timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || site_timezone;
					}
				} catch ( ignore ) {
					// Keep site_timezone.
				}

				timezone_field.select2();

				if ( ! timezone_conversion || wc_appointments_timezone_picker_object.has_timezone_preference() || local_timezone === site_timezone ) {
					return;
				}

				timezone_field.val( local_timezone );
				wc_appointments_timezone_picker_object.select_timezone.call( timezone_field[0] );
			} );
		},
		show_timezone_select: function() {
			var selection = $( this ).closest( '.wc_appointments_field_timezone' );

			selection.find( 'select, .select2' ).css( 'display', 'block' );
			selection.find( 'select' ).select2( 'open' );
		},
		hide_timezone_select: function( event ) {
			var selection = $( this ).closest( '.wc_appointments_field_timezone' );

			selection.find( 'select, .select2' ).css( 'display', 'none' );

			event.preventDefault();
		},
		select_timezone: function() {
			var timezone = $( this ).val() || '';
			var form = $( this ).closest( 'form' );
			var params = {
				'wc-ajax': 'wc_appointments_set_timezone_cookie',
				'timezone': timezone,
				'security': wc_appointment_form_params.nonce_set_timezone_cookie
			};

			form.find( '.wc-appointments-appointment-form-button' ).prop( 'disabled', true );

			$.ajax( {
				context: this,
				url: wc_appointments_timezone_picker_args.ajax_url,
				method: 'POST',
				data: params
			} )
				.done( function( data ) {
					$( '.wc-appointments-appointment-form' ).each( function() {
						var timezone_form  = $( this ).closest( 'form' );
						var timezone_field = timezone_form.find( '.wc_appointments_field_timezone' );
						var selected_timezone = timezone_field.find( 'select' ).val();

						timezone_field.find( '.selected-timezone' ).text( wc_appointments_timezone_picker_object.get_display_timezone_label( selected_timezone || data, timezone_field.find( 'select' ) ) );
						timezone_field.find( 'select, .select2' ).css( 'display', 'none' );
					} );

					form.triggerHandler( 'timezone-selected' );
				} )
				.always( function() {
					form.find( '.wc-appointments-appointment-form-button' ).prop( 'disabled', false );
				} );
		}
	};

	wc_appointments_timezone_picker = wc_appointments_timezone_picker_object;
	wc_appointments_timezone_picker.init();
} );
	},
	'timezone-picker'
);
