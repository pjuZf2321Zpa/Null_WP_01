/**
 * Appointment Admin Panel — Unified contextual panel for view/edit/create modes.
 *
 * Standalone React (wp.element) component rendered into a portal div.
 * Communicates with the calendar via window.wcaPanel global API.
 * Reuses existing REST V2, AJAX, SSE, and wcaModalHooks extensibility infrastructure.
 *
 * @since 5.3.0
 */
( function() {
	'use strict';

	if ( ! window.wp || ! window.wp.element ) {
		return;
	}

	var h               = wp.element.createElement;
	var wpIcon          = window.wcaWpIcons && window.wcaWpIcons.render ? window.wcaWpIcons.render : function() { return null; };
	var useState        = wp.element.useState;
	var useEffect       = wp.element.useEffect;
	var useLayoutEffect = wp.element.useLayoutEffect || useEffect;
	var useRef          = wp.element.useRef;
	var Fragment        = wp.element.Fragment;
	var ti = function( opts ) {
		var fn = window.panelHelpers && window.panelHelpers.textInput;
		return fn ? fn( h, opts ) : null;
	};

	// Localized config from PHP
	var cfg = window.wcaPanel || {};
	if ( ! cfg.panelEnabled ) {
		return;
	}

	/** SR-only status for checking/unavailable (visual state is on the datetime row). */
	function datetimeAvailStatus( h, availStatus, availMessage, t ) {
		if ( 'checking' !== availStatus && 'unavailable' !== availStatus ) {
			return null;
		}
		var msg = 'checking' === availStatus
			? t( 'checkingAvailability', 'Checking availability\u2026' )
			: ( availMessage || t( 'slotUnavailable', 'This slot is not available.' ) );
		return h( 'span', {
			className: 'screen-reader-text',
			role: 'status',
			'aria-live': 'polite'
		}, msg );
	}

	/** Default block; Screen Options allowUnavailable restores confirm. onBlock(msg) when blocked. */
	function allowUnavailableSubmit( availStatus, availMessage, allow, t, onBlock, sectionRef ) {
		if ( 'unavailable' !== availStatus ) {
			return true;
		}
		var msg = availMessage || t( 'slotUnavailable', 'This slot is not available.' );
		if ( allow ) {
			return window.confirm( msg + ' - ' + t( 'confirmation', 'Are you sure?' ) );
		}
		onBlock( msg );
		if ( sectionRef ) {
			schedulePanelFit( sectionRef, true );
		}
		return false;
	}

	/** Stale when form browse day ≠ slot admin day (not site Fake UTC Y-m-d vs formDate). */
	function availSlotRefsStaleForForm( opts ) {
		var siteTime = opts.siteTimeRef && opts.siteTimeRef.current;
		var siteDateVal = opts.siteDateRef && opts.siteDateRef.current;
		var formDate = opts.formDate || opts.formSiteDate || '';
		if ( ! siteTime || ! siteDateVal || ! formDate ) {
			return false;
		}
		var adminAtPick = opts.adminDateRef && opts.adminDateRef.current;
		if ( adminAtPick ) {
			return adminAtPick !== formDate;
		}
		// Without an admin browse day, only same-TZ compares site civil to formDate.
		var utils = window.WCAppointmentsTimezoneUtils;
		if ( utils && utils.getTimezoneConfig && utils.getTimezoneConfig().hasDifferentTz ) {
			return false;
		}
		return siteDateVal !== formDate;
	}

	/** Single-date timed fields for availabilityParamsReady / fetchAvailability. */
	function resolveTimedAvailParams( opts ) {
		var siteTime = opts.siteTimeRef.current;
		var siteDateVal = opts.siteDateRef.current;
		if ( availSlotRefsStaleForForm( opts ) ) {
			if ( opts.clearStale ) {
				opts.siteTimeRef.current = '';
				opts.siteDateRef.current = '';
				opts.startTsRef.current = 0;
				if ( opts.adminDateRef ) {
					opts.adminDateRef.current = '';
				}
			}
			siteTime = '';
			siteDateVal = '';
		}
		if ( siteTime && siteDateVal && opts.showTimeFields ) {
			var out = { date: siteDateVal, timeFrom: siteTime, valuesAreSiteTz: true };
			var sst = parseInt( opts.startTsRef.current, 10 );
			if ( sst > 86400 ) { out.slotStartTimestamp = sst; }
			return out;
		}
		// Date-only / all-day: civil Y-M-D — never admin→site via midnight placeholder.
		if ( ! opts.showTimeFields ) {
			return { date: opts.formDate, timeFrom: opts.formTimeFrom, timeTo: opts.formTimeTo };
		}
		if ( opts.forFetch ) {
			var utils = window.WCAppointmentsTimezoneUtils;
			var eD = opts.formDate;
			var eT1 = opts.formTimeFrom;
			var eT2 = opts.formTimeTo;
			if ( utils && utils.convertAdminStringsToSiteTimezone ) {
				var c1 = utils.convertAdminStringsToSiteTimezone( opts.formDate, opts.formTimeFrom );
				var c2 = utils.convertAdminStringsToSiteTimezone( opts.formDate, opts.formTimeTo );
				eD = c1.date;
				eT1 = c1.time;
				eT2 = c2.time;
			}
			return { date: eD, timeFrom: eT1, timeTo: eT2, valuesAreSiteTz: true };
		}
		return { date: opts.formDate, timeFrom: opts.formTimeFrom, timeTo: opts.formTimeTo };
	}

	function assignResolvedTimedParams( target, single ) {
		target.date = single.date;
		target.timeFrom = single.timeFrom;
		if ( single.timeTo ) { target.timeTo = single.timeTo; }
		if ( single.valuesAreSiteTz ) { target.valuesAreSiteTz = true; }
		if ( single.slotStartTimestamp ) { target.slotStartTimestamp = single.slotStartTimestamp; }
	}

	function bumpAvailCheckGen( availCheckGenRef ) {
		if ( availCheckGenRef ) {
			availCheckGenRef.current += 1;
		}
		return availCheckGenRef ? availCheckGenRef.current : 0;
	}

	function beginAvailabilityPending( setAvailStatus, setAvailMessage, availCheckGenRef ) {
		var gen = bumpAvailCheckGen( availCheckGenRef );
		setAvailMessage( '' );
		setAvailStatus( 'checking' );
		return gen;
	}

	function applyAvailabilityResult( availCheckGenRef, generation, setAvailStatus, setAvailMessage, result, ignoreEmptyAjax ) {
		if ( availCheckGenRef && availCheckGenRef.current !== generation ) {
			return;
		}
		var nextStatus = result && result.status ? result.status : '';
		if ( ! nextStatus && ignoreEmptyAjax ) {
			// Aborted/superseded AJAX — clear orphan checking only; keep available.
			setAvailStatus( function( prev ) { return 'checking' === prev ? '' : prev; } );
			return;
		}
		setAvailStatus( nextStatus );
		setAvailMessage( result && result.message ? result.message : '' );
	}

	// ── Panel sub-modules (loaded as separate scripts) ───────────
	// Some optimization plugins concatenate scripts into a wrapper function,
	// which can prevent `var panelStatus = ...` from becoming a true global.
	// Always read modules from `window.*` to avoid ReferenceErrors.
	var panelHelpers = window.panelHelpers || {};
	var panelForm    = window.panelForm || {};
	var panelBrowse  = window.panelBrowse || {};
	var panelStatus  = window.panelStatus || {};

	// Fallback: if the segmented status control module isn't available,
	// render a plain <select> so editing can still proceed.
	if ( ! panelStatus || 'function' !== typeof panelStatus.StatusSegmented ) {
		panelStatus = {
			StatusSegmented: function( opts ) {
				var value     = String( ( opts && opts.value ) || '' );
				var statuses  = ( opts && opts.statuses ) || [];
				var statusMap = ( opts && opts.statusMap ) || {};
				var onChange  = ( opts && opts.onChange ) || function() {};
				var tt        = ( opts && opts.t ) || function( k, fb ) { return fb || k; };
				var humanize  = ( opts && opts.humanizeStatus ) || function( st ) { return st; };

				return h( 'div', { className: 'wca-status-section' },
					h( 'select', {
						className: 'wca-form-input wca-form-select wca-status-fallback-select',
						value: value,
						'aria-label': tt( 'appointmentStatus', 'Appointment status' ),
						onChange: function( e ) { onChange( e.target.value ); }
					},
						statuses.map( function( st ) {
							var label = statusMap[ st ] || humanize( st );
							return h( 'option', { key: 'st-opt-' + st, value: st }, label );
						} )
					)
				);
			}
		};
	}

	// Calendar config (available when on calendar page)
	var calCfg = window.wcAppointmentsReactCalendar || {};
	// Locale / week start: prefer React calendar config when loaded (same as main admin calendar).
	var browsePanelCfg = Object.assign( {}, cfg, {
		locale: ( calCfg && calCfg.locale ) ? calCfg.locale : cfg.locale,
		firstday: ( calCfg && calCfg.firstDay !== undefined && calCfg.firstDay !== null ) ? calCfg.firstDay : cfg.firstday
	} );
	// Merge wcaPanel + calendar i18n so standalone pages get currencySymbols (calCfg.i18n is absent there).
	var i18n   = Object.assign( {}, ( cfg.i18n ) || {}, ( calCfg.i18n ) || {} );
	// Status labels on the calendar page live on wcAppointmentsReactCalendar.statuses; merge into i18n for humanizeStatus().
	if ( calCfg.statuses && 'object' === typeof calCfg.statuses ) {
		i18n.statuses = Object.assign( {}, calCfg.statuses, i18n.statuses || {} );
	}

	// Translation helper — same pattern as calendar; optional replacements via wcaShared.i18n.
	function t( key, fallback, replacements ) {
		if ( null != replacements && window.wcaShared ) {
			var dict = {};
			var fromI18n = i18n && i18n[ key ];
			var fromCfg = cfg.i18n && cfg.i18n[ key ];
			if ( fromI18n ) {
				dict[ key ] = fromI18n;
			} else if ( fromCfg ) {
				dict[ key ] = fromCfg;
			}
			return window.wcaShared.i18n( dict, key, fallback || key, replacements );
		}
		return ( i18n && i18n[ key ] ) || ( cfg.i18n && cfg.i18n[ key ] ) || fallback || key;
	}

	/**
	 * Localized "Appointment #123" (full phrase for correct word order in translations).
	 *
	 * @param {number|string} id Appointment post ID.
	 * @return {string}
	 */
	function formatAppointmentWithId( id ) {
		return t( 'appointmentWithId', 'Appointment #%d', parseInt( id, 10 ) || id );
	}

	// ─── Helpers ──────────────────────────────────────────────────

	var debounce = window.wcaShared.debounce;

	/**
	 * Format a Date using a PHP-style pattern (subset).
	 * Reuses the calendar's formatDateByPattern if available, otherwise basic fallback.
	 */
	function formatDateByPattern( date, pattern ) {
		if ( window.__wcaFormatDateByPattern ) {
			return window.__wcaFormatDateByPattern( date, pattern );
		}
		// Basic fallback
		var y = date.getUTCFullYear();
		var m = date.getUTCMonth() + 1;
		var d = date.getUTCDate();
		return y + '-' + ( m < 10 ? '0' : '' ) + m + '-' + ( d < 10 ? '0' : '' ) + d;
	}

	function formatTimeByPattern( date, pattern ) {
		if ( window.__wcaFormatTimeByPattern ) {
			return window.__wcaFormatTimeByPattern( date, pattern );
		}
		var hh = date.getUTCHours();
		var mm = date.getUTCMinutes();
		return ( hh < 10 ? '0' : '' ) + hh + ':' + ( mm < 10 ? '0' : '' ) + mm;
	}

	/** One string for create-success "when" line (locale + site TZ). */
	function formatCreateSuccessWhen( formDate, timeFrom, timeTo, dateFrom, dateTo, monthFrom, monthTo ) {
		var tz = ( calCfg && calCfg.siteTimezone ) ? calCfg.siteTimezone : undefined;
		function locDate( ymd ) {
			var p = ( ymd || '' ).split( '-' );
			if ( p.length !== 3 ) { return ymd; }
			var d = new Date( parseInt( p[ 0 ], 10 ), parseInt( p[ 1 ], 10 ) - 1, parseInt( p[ 2 ], 10 ) );
			return d.toLocaleDateString( undefined, { year: 'numeric', month: 'short', day: 'numeric', timeZone: tz } );
		}
		function locMonth( ym ) {
			var p = ( ym || '' ).split( '-' );
			if ( p.length !== 2 ) { return ym; }
			var d = new Date( parseInt( p[ 0 ], 10 ), parseInt( p[ 1 ], 10 ) - 1, 1 );
			return d.toLocaleDateString( undefined, { year: 'numeric', month: 'short', timeZone: tz } );
		}
		function locTime( hhmm ) {
			if ( ! hhmm ) { return ''; }
			var q = ( hhmm + '' ).split( ':' );
			if ( q.length < 2 ) { return hhmm; }
			var d = new Date( 2000, 0, 1, parseInt( q[ 0 ], 10 ), parseInt( q[ 1 ], 10 ) );
			return isNaN( d.getTime() ) ? hhmm : d.toLocaleTimeString( undefined, { hour: '2-digit', minute: '2-digit' } );
		}
		if ( formDate ) {
			var ds = locDate( formDate ), a = locTime( timeFrom ), b = locTime( timeTo );
			return ( a && b ) ? ( ds + ' ' + a + '\u2013' + b ) : ds;
		}
		if ( dateFrom ) {
			var x = locDate( dateFrom ), y = dateTo && dateTo !== dateFrom ? locDate( dateTo ) : '';
			return y ? ( x + ' \u2192 ' + y ) : x;
		}
		if ( monthFrom ) {
			var u = locMonth( monthFrom ), v = monthTo && monthTo !== monthFrom ? locMonth( monthTo ) : '';
			return v ? ( u + ' \u2192 ' + v ) : u;
		}
		return '';
	}

	/**
	 * Convert a site-tz-as-UTC timestamp to admin-tz for display.
	 * Reuses the calendar's convertToAdminTimezone if available.
	 */
	function convertToAdminTimezone( ts ) {
		if ( window.__wcaConvertToAdminTimezone ) {
			return window.__wcaConvertToAdminTimezone( ts );
		}
		// Fallback: use offset math
		var adminOffset = calCfg.adminTimezoneOffset || 0;
		var siteOffset  = calCfg.siteTimezoneOffset || 0;
		var diff = ( adminOffset - siteOffset ) * 60; // seconds
		return ts + diff;
	}

	/**
	 * Date for formatRange/formatDuration: UTC getters hold admin-local wall time (timed appts).
	 * Uses tsToAdminLocalISO (IANA / DST) — same as EditContent inputs — not convertSiteToAdminTimezone
	 * (static offset), which can disagree by one hour around DST boundaries.
	 *
	 * @param {number} ts        Raw appointment timestamp (site wall clock in Date UTC fields).
	 * @param {boolean} allDay   All-day: keep semantic timestamp unchanged.
	 * @return {Date|null}
	 */
	function dateForAdminRangeDisplay( ts, allDay ) {
		if ( ! ts ) { return null; }
		if ( allDay ) {
			return new Date( ts * 1000 );
		}
		var utils = window.WCAppointmentsTimezoneUtils;
		if ( utils && utils.tsToAdminLocalISO ) {
			var iso = utils.tsToAdminLocalISO( ts );
			if ( iso ) {
				var tPos = iso.indexOf( 'T' );
				if ( tPos > 0 ) {
					var dPart = iso.substring( 0, tPos ).split( '-' );
					var tPart = iso.substring( tPos + 1 ).split( ':' );
					if ( 3 === dPart.length && 2 <= tPart.length ) {
						var y = parseInt( dPart[ 0 ], 10 );
						var mo = parseInt( dPart[ 1 ], 10 );
						var da = parseInt( dPart[ 2 ], 10 );
						var hh = parseInt( tPart[ 0 ], 10 );
						var mi = parseInt( tPart[ 1 ], 10 );
						var ss = parseInt( tPart[ 2 ] || '0', 10 );
						if ( ! isNaN( y ) && ! isNaN( hh ) ) {
							return new Date( Date.UTC( y, mo - 1, da, hh, mi, isNaN( ss ) ? 0 : ss ) );
						}
					}
				}
			}
		}
		var adj = convertToAdminTimezone( ts );
		return new Date( adj * 1000 );
	}

	/**
	 * Check if a timestamp range represents all-day.
	 */
	function isAllDayRangeTs( startTs, endTs ) {
		if ( ! startTs || ! endTs ) { return false; }
		// Site-tz-as-UTC: check that UTC hours/minutes are 00:00 for both timestamps
		var sd = new Date( startTs * 1000 );
		var ed = new Date( endTs * 1000 );
		var startMidnight = sd.getUTCHours() === 0 && sd.getUTCMinutes() === 0;
		var endMidnight = ed.getUTCHours() === 0 && ed.getUTCMinutes() === 0;
		return ( endTs - startTs ) >= 86400 && startMidnight && endMidnight;
	}

	/**
	 * Check if error indicates session/nonce expiration (401/403)
	 */
	function isAuthError( error ) {
		if ( ! error ) { return false; }
		var msg = error.message || String( error );
		return /HTTP 401/i.test( msg ) || /HTTP 403/i.test( msg );
	}

	/**
	 * Dispatch session expired event to calendar (shows reload banner)
	 */
	function notifySessionExpired() {
		try {
			window.dispatchEvent( new CustomEvent( 'wca_session_expired' ) );
		} catch ( _ ) {
			var evt = document.createEvent( 'CustomEvent' );
			evt.initCustomEvent( 'wca_session_expired', true, true, {} );
			window.dispatchEvent( evt );
		}
	}

	/**
	 * REST API GET helper.
	 */
	function apiGet( path, params ) {
		var base = cfg.restUrl || calCfg.restUrl || '';
		if ( '/' !== base.slice( -1 ) ) { base += '/'; }
		var url = base + path;
		if ( params ) {
			var qs = [];
			for ( var k in params ) {
				if ( params.hasOwnProperty( k ) ) {
					var v = params[ k ];
					if ( Array.isArray( v ) ) {
						for ( var i = 0; i < v.length; i++ ) {
							qs.push( encodeURIComponent( k ) + '[]=' + encodeURIComponent( v[ i ] ) );
						}
					} else {
						qs.push( encodeURIComponent( k ) + '=' + encodeURIComponent( v ) );
					}
				}
			}
			if ( qs.length ) { url += ( -1 < url.indexOf( '?' ) ? '&' : '?' ) + qs.join( '&' ); }
		}
		var nonce = cfg.nonce || calCfg.nonce || '';
		return fetch( url, { headers: { 'X-WP-Nonce': nonce } } ).then( function( r ) {
			if ( ! r.ok ) {
				var err = new Error( 'HTTP ' + r.status );
				if ( r.status === 401 || r.status === 403 ) { notifySessionExpired(); }
				throw err;
			}
			return r.json();
		} );
	}

	/**
	 * REST API PUT helper.
	 */
	function apiPut( path, body ) {
		var base = cfg.restUrl || calCfg.restUrl || '';
		if ( '/' !== base.slice( -1 ) ) { base += '/'; }
		var url = base + path;
		var nonce = cfg.nonce || calCfg.nonce || '';
		return fetch( url, {
			method: 'PUT',
			headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
			body: JSON.stringify( body )
		} ).then( function( r ) {
			if ( ! r.ok ) {
				return r.json().catch( function() { return {}; } ).then( function( data ) {
					var err = new Error( ( data && data.message ) ? data.message : ( 'HTTP ' + r.status ) );
					err.code = data && data.code ? data.code : '';
					if ( r.status === 401 || r.status === 403 ) { notifySessionExpired(); }
					throw err;
				} );
			}
			return r.json();
		} );
	}

	/**
	 * REST API DELETE helper.
	 */
	function apiDelete( path ) {
		var base = cfg.restUrl || calCfg.restUrl || '';
		if ( '/' !== base.slice( -1 ) ) { base += '/'; }
		var url = base + path;
		var nonce = cfg.nonce || calCfg.nonce || '';
		return fetch( url, {
			method: 'DELETE',
			headers: { 'X-WP-Nonce': nonce }
		} ).then( function( r ) {
			if ( ! r.ok ) {
				var err = new Error( 'HTTP ' + r.status );
				if ( r.status === 401 || r.status === 403 ) { notifySessionExpired(); }
				throw err;
			}
			return r.json();
		} );
	}

	// ─── Positioning ──────────────────────────────────────────────

	var PANEL_WIDTH           = 380;
	var PANEL_MAX_H           = 800;
	var GAP                   = 8;
	var PANEL_BOTTOM_INSET    = 12; // Match appointment-admin-panel.scss calc(100dvh - 24px).
	var PANEL_ANCHOR_MOBILE   = 782; // Match appointment-admin-panel.scss responsive breakpoint.
	// Optical top-align: panel shell has rounded corners; nudge up so the flat edge lines up with the event.
	var PANEL_TOP_NUDGE       = 24;

	function schedulePanelFit( sectionRef, opening ) {
		var after = ( opening && sectionRef ) ? function() {
			var scroll = window.panelHelpers && window.panelHelpers.scrollPanelSectionIntoView;
			if ( scroll ) { scroll( sectionRef.current ); }
		} : null;
		if ( window.wcaPanel && window.wcaPanel.scheduleFitContent ) {
			window.wcaPanel.scheduleFitContent( after );
		} else if ( after ) {
			after();
		}
	}

	/** Measure content, place beside trigger, cap height to viewport. */
	function layoutPanel( panelEl, triggerRect, prev, opts ) {
		opts = opts || {};
		prev = prev || {};
		var padding = GAP, vpW = window.innerWidth, vpH = window.innerHeight, naturalH = 0;
		var result = { x: 0, y: 0, side: 'right', centered: false, shellHeight: 0, maxAvail: 0 };

		if ( ! opts.repositionOnly && panelEl ) {
			var savedH = panelEl.style.height, savedMaxH = panelEl.style.maxHeight;
			var savedShellVar = panelEl.style.getPropertyValue( '--wca-panel-shell-h' );
			var hadFillShell = panelEl.classList.contains( 'wca-panel--fill-shell' );
			var header = panelEl.querySelector( '.wca-panel-header' );
			var body = panelEl.querySelector( '.wca-panel-body' );
			var scrollEl = body && body.querySelector( '.wca-panel-body-scroll' );
			var savedScrollTop = scrollEl ? scrollEl.scrollTop : 0;
			panelEl.style.height = 'auto';
			panelEl.style.maxHeight = 'none';
			panelEl.style.setProperty( '--wca-panel-shell-h', 'auto' );
			panelEl.classList.remove( 'wca-panel--fill-shell' );
			naturalH = header ? header.offsetHeight : 0;
			if ( body ) {
				var footer = body.querySelector( '.wca-panel-footer' );
				naturalH += ( scrollEl ? scrollEl.scrollHeight : body.scrollHeight ) + ( footer ? footer.offsetHeight : 0 );
			}
			naturalH = Math.ceil( naturalH );
			var boxH = Math.ceil( panelEl.offsetHeight );
			if ( boxH > naturalH ) {
				naturalH = boxH;
			}
			panelEl.style.height = savedH;
			panelEl.style.maxHeight = savedMaxH;
			if ( savedShellVar ) { panelEl.style.setProperty( '--wca-panel-shell-h', savedShellVar ); }
			else { panelEl.style.removeProperty( '--wca-panel-shell-h' ); }
			if ( hadFillShell ) { panelEl.classList.add( 'wca-panel--fill-shell' ); }
			if ( scrollEl && savedScrollTop ) { scrollEl.scrollTop = savedScrollTop; }
		} else if ( panelEl ) {
			naturalH = Math.ceil( panelEl.offsetHeight );
		}

		if ( ! triggerRect ) {
			return finishCenter( Math.max( padding, ( vpW - PANEL_WIDTH ) / 2 ) );
		}
		var rect = triggerRect;
		function availH( y ) { return Math.min( PANEL_MAX_H, Math.max( 120, vpH - y - PANEL_BOTTOM_INSET ) ); }
		function centerShell() {
			var maxC = Math.min( PANEL_MAX_H, vpH - padding * 2 );
			result.maxAvail = maxC;
			var need = naturalH > 0 ? Math.min( naturalH, PANEL_MAX_H ) : 0;
			var sh = need > 0 ? Math.min( need, maxC ) : Math.min( 320, maxC );
			result.shellHeight = need > sh + 1 ? sh : 0;
			// Upper-biased (~12% viewport) so short compose grows down; tall still clamps via center.
			var centerY = Math.max( padding, ( vpH - sh ) / 2 );
			result.y = Math.min( centerY, Math.max( padding, Math.round( vpH * 0.12 ) ) );
		}

		function finishCenter( x ) {
			result.centered = true;
			result.side = 'center';
			result.x = x;
			centerShell();
			return result;
		}

		if ( vpW <= PANEL_ANCHOR_MOBILE ) {
			return finishCenter( Math.max( padding, ( vpW - PANEL_WIDTH ) / 2 ) );
		}
		if ( rect.right + padding + PANEL_WIDTH <= vpW - padding ) {
			result.x = rect.right + padding;
			result.side = 'right';
		} else if ( rect.left - padding - PANEL_WIDTH >= padding ) {
			result.x = rect.left - padding - PANEL_WIDTH;
			result.side = 'left';
		} else {
			return finishCenter( Math.max( padding, ( vpW - PANEL_WIDTH ) / 2 ) );
		}

		var prefY = rect.top - PANEL_TOP_NUDGE;
		var lockedShell = opts.repositionOnly && prev.shellHeight > 0 ? prev.shellHeight : 0;
		var needH = naturalH > 0 ? Math.min( naturalH, PANEL_MAX_H ) : 0;
		var maxAtPrefY = availH( Math.max( padding, prefY ) );
		var visH = Math.ceil( lockedShell || needH || naturalH );
		var y = Math.max( padding, prefY );
		if ( visH > 0 ) {
			y = Math.max( padding, Math.min( y, vpH - PANEL_BOTTOM_INSET - visH ) );
		}
		var maxA = availH( y );
		var shellH = lockedShell || ( needH > 0 ? Math.min( needH, maxA ) : 0 );
		result.y = y;
		result.shellHeight = lockedShell || ( shellH > 0 && needH > shellH ? shellH : 0 );
		result.maxAvail = maxA;
		return result;
	}

	function formExpansionHeader( h, opts ) {
		var children = Array.prototype.slice.call( arguments, 2 );
		return h.apply( null, [ 'button', {
			type: 'button',
			className: 'wca-expansion__header',
			'aria-expanded': opts.open ? 'true' : 'false',
			onClick: function() {
				var opening = !opts.open;
				opts.onOpenChange( opening );
				schedulePanelFit( opts.sectionRef, opening );
			}
		} ].concat( children ) );
	}

	/** Trailing Edit text or chevron-up close — shared by customer details, add-ons, browse. */
	function expansionTrailingAction( h, open, t ) {
		return open
			? wpIcon( h, 'chevronUp', 'wca-expansion__action', { title: t( 'close', 'Close' ) } )
			: h( 'span', { className: 'wca-text-action wca-expansion__action' }, t( 'edit', 'Edit' ) );
	}

	// ─── Timezone display helpers ─────────────────────────────────

	/**
	 * Compute timezone abbreviation and diff tooltip for a given IANA timezone.
	 * Reuses exact proven pattern from the calendar viewing panel.
	 */
	function computeTzInfo( ianaTz, startTs ) {
		if ( ! ianaTz || ! startTs ) { return null; }
		if ( ! ( calCfg.showTimezoneContext ) ) { return null; }
		var siteTz   = calCfg.siteTimezone || '';
		var viewerTz = calCfg.adminTimezone || siteTz;
		if ( ! viewerTz || ianaTz === viewerTz ) { return null; }
		try {
			var tzDisplay = ianaTz.replace( /_/g, ' ' ).split( '/' ).pop();
			var fakeUtcDate = new Date( startTs * 1000 );
			var siteOffsetMin = calCfg.siteTimezoneOffset || 0;
			var siteWallMs = Date.UTC( fakeUtcDate.getUTCFullYear(), fakeUtcDate.getUTCMonth(), fakeUtcDate.getUTCDate(), fakeUtcDate.getUTCHours(), fakeUtcDate.getUTCMinutes(), 0 );
			var realUtcMs = siteWallMs - ( siteOffsetMin * 60000 );
			var getVal = function( parts, type ) { for ( var i = 0; i < parts.length; i++ ) { if ( parts[ i ].type === type ) { return parts[ i ].value; } } return ''; };
			// Abbreviation
			var tzAbbrFormatter = new Intl.DateTimeFormat( 'en-US', { timeZone: ianaTz, timeZoneName: 'short' } );
			var tzAbbrParts = tzAbbrFormatter.formatToParts( new Date( realUtcMs ) );
			var tzAbbr = getVal( tzAbbrParts, 'timeZoneName' ) || '';
			if ( tzAbbr && tzAbbr !== tzDisplay ) { tzDisplay = tzDisplay + ' (' + tzAbbr + ')'; }
			// Compute diff
			var fmt1 = new Intl.DateTimeFormat( 'en-US', { timeZone: ianaTz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false } );
			var parts1 = fmt1.formatToParts( new Date( realUtcMs ) );
			var wall1 = new Date( getVal( parts1, 'year' ) + '-' + getVal( parts1, 'month' ) + '-' + getVal( parts1, 'day' ) + 'T' + getVal( parts1, 'hour' ) + ':' + getVal( parts1, 'minute' ) + ':00' );
			var fmt2 = new Intl.DateTimeFormat( 'en-US', { timeZone: viewerTz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false } );
			var parts2 = fmt2.formatToParts( new Date( realUtcMs ) );
			var wall2 = new Date( getVal( parts2, 'year' ) + '-' + getVal( parts2, 'month' ) + '-' + getVal( parts2, 'day' ) + 'T' + getVal( parts2, 'hour' ) + ':' + getVal( parts2, 'minute' ) + ':00' );
			var diffMinutes = Math.round( ( wall1.getTime() - wall2.getTime() ) / 60000 );
			if ( diffMinutes === 0 ) { return null; }
			var absMins = Math.abs( diffMinutes );
			var hrs = Math.floor( absMins / 60 );
			var mins = absMins % 60;
			var hoursStr = t( 'hoursFormat', '%dh', hrs );
			var amount = ( hrs > 0 && mins > 0 ) ? ( hoursStr + ' ' + mins + t( 'durationMin', 'min' ) ) : ( hrs > 0 ? hoursStr : mins + t( 'durationMin', 'min' ) );
			var direction = diffMinutes > 0 ? t( 'ahead', 'ahead' ) : t( 'behind', 'behind' );
			var dateFmt = calCfg.dateFormat || 'M j, Y';
			var timeFmt = calCfg.timeFormat || 'g:i a';
			var timeStr = formatDateByPattern( wall1, dateFmt ) + ', ' + formatTimeByPattern( wall1, timeFmt );
			var tooltip = tzDisplay + ' \u2014 ' + timeStr + ' (' + amount + ' ' + direction + ')';
			return { abbr: tzDisplay, tooltip: tooltip };
		} catch ( e ) {
			return null;
		}
	}

	// ─── Product header helper (shared across view/edit/create) ────

	/**
	 * Build a unified product header node: color dot + product icon + product name.
	 * @param {Object} opts
	 * @param {string} opts.name        Product name to display.
	 * @param {string} opts.color       Calendar color hex (defaults to #0073aa).
	 * @param {string} [opts.href]      Optional link for the product name.
	 * @param {number} [opts.qty]       Optional qty badge (shown when > 1).
	 * @param {string} [opts.id]        Appointment ID (shown as #ID prefix).
	 * @return {Object} React element.
	 */
	function buildProductHeader( opts ) {
		var name  = opts.name || '';
		var color = ( opts.color && String( opts.color ).trim() ) || '#0073aa';
		var href  = opts.href || '';
		var qty   = opts.qty || 0;
		var apptId = opts.id || '';

		var dotNode = h( 'span', { className: 'wca-product-color-dot', style: { '--wca-dot-color': color }, 'aria-hidden': 'true' } );
		var iconNode = wpIcon( h, 'box', 'wca-product-header-icon', { title: t( 'product', 'Product' ) } );

		var nameText = name;
		if ( qty > 1 ) { nameText = name + ' \u00d7' + String( qty ); }

		var nameNode;
		if ( name ) {
			nameNode = href
				? h( 'a', { className: 'wca-product-header-name', href: href }, nameText )
				: h( 'span', { className: 'wca-product-header-name' }, nameText );
		} else {
			nameNode = h( 'span', { className: 'wca-product-header-name wca-skeleton wca-skeleton-product' } );
		}

		var idNode = apptId ? h( 'span', { className: 'wca-product-header-id' }, '#' + String( apptId ) ) : null;

		return h( 'div', { className: 'wca-panel-product-header' },
			dotNode,
			iconNode,
			nameNode,
			idNode
		);
	}

	// ─── Formatting helpers ───────────────────────────────────────

	function humanizeStatus( s ) {
		if ( ! s ) { return ''; }
		var map = i18n.statuses || {};
		if ( map[ s ] ) { return map[ s ]; }
		return String( s ).split( '-' ).map( function( w ) {
			return w.charAt( 0 ).toUpperCase() + w.slice( 1 );
		} ).join( ' ' );
	}
	window.__wcaHumanizeAppointmentStatus = humanizeStatus;

	/**
	 * Extract displayable add-ons from a WC order line item meta_data array.
	 * Shared between view/edit panels so rendering stays consistent.
	 *
	 * @param {Object|null} lineItem
	 * @return {Array<{k: string, v: (string|Object)}>}
	 */
	function extractAddonsFromLineItem( lineItem ) {
		var addons = [];
		if ( ! lineItem || ! Array.isArray( lineItem.meta_data ) ) {
			return addons;
		}
		lineItem.meta_data.forEach( function( m ) {
			if ( ! m ) { return; }
			var keyRaw = m.key;
			var keyDisp = m.display_key;
			var key = keyDisp || keyRaw;
			if ( ! key || '_' === String( key ).charAt( 0 ) ) { return; }
			var keyLc = String( keyRaw || key ).toLowerCase();
			var keyDispLc = String( keyDisp || '' ).toLowerCase();
			if ( 'appointment_id' === keyLc || 'appointment id' === keyDispLc ) { return; }

			var rawVal = m.value;
			var dispVal = m.display_value;
			var val = ( null != dispVal ) ? dispVal : rawVal;
			if ( val === undefined || null === val || '' === val ) { return; }

			var valStr = '';
			if ( Array.isArray( rawVal ) ) {
				valStr = rawVal.join( ', ' );
			} else if ( 'object' === typeof rawVal ) {
				valStr = JSON.stringify( rawVal );
			} else if ( 'string' === typeof rawVal && /^https?:\/\//i.test( rawVal.trim() ) ) {
				var cleanUrl = rawVal.trim();
				var filename = cleanUrl.split( '/' ).pop().split( '?' )[ 0 ].split( '#' )[ 0 ] || cleanUrl;
				if ( dispVal && 'string' === typeof dispVal ) {
					var stripped = dispVal.replace( /(<([^>]+)>)/gi, '' ).trim();
					if ( stripped ) { filename = stripped; }
				}
				valStr = h( 'a', { href: cleanUrl, target: '_blank', rel: 'noopener noreferrer' }, filename );
			} else {
				var textVal = String( val );
				var aMatch = textVal.match( /<a\s+(?:[^>]*?\s+)?href=(["'])(.*?)\1[^>]*>(.*?)<\/a>/i );
				if ( aMatch ) {
					valStr = h(
						'a',
						{ href: aMatch[ 2 ], target: '_blank', rel: 'noopener noreferrer' },
						aMatch[ 3 ].replace( /(<([^>]+)>)/gi, '' ).trim() || aMatch[ 2 ]
					);
				} else {
					valStr = textVal.replace( /(<([^>]+)>)/gi, ' ' ).trim();
				}
			}

			addons.push( { k: String( key ), v: valStr } );
		} );
		return addons;
	}

	/**
	 * Render add-ons as Label: value rows (view value + edit card body).
	 *
	 * @param {Array<{k: string, v: (string|Object)}>} addons
	 * @return {Object|null} React element
	 */
	function renderAddonsBlock( addons ) {
		if ( ! addons || ! addons.length ) {
			return null;
		}
		return h( 'div', { className: 'wca-addons' },
			addons.map( function( a, idx ) {
				return h( 'div', { key: 'ad-' + idx },
					h( 'span', { className: 'wca-addons__k' }, a.k + ': ' ),
					h( 'span', { className: 'wca-addons__v' }, a.v )
				);
			} )
		);
	}

	function formatDuration( start, end, unit, val, startTs, endTs ) {
		if ( 'day' === unit ) {
			var dayMs = 86400000;
			var d = Math.max( 1, Math.ceil( ( end - start ) / dayMs ) );
			return d + ' ' + ( 1 === d ? t( 'durationDay', 'day' ) : t( 'durationDays', 'days' ) );
		}
		if ( 'month' === unit ) {
			var m = Math.max( 1, val || 1 );
			return m + ' ' + ( 1 === m ? t( 'durationMonth', 'month' ) : t( 'durationMonths', 'months' ) );
		}
		var isAllDay = isAllDayRangeTs( startTs || 0, endTs || 0 );
		if ( ! unit && isAllDay ) {
			var dayMs2 = 86400000;
			var d2 = Math.max( 1, Math.ceil( ( end - start ) / dayMs2 ) );
			return d2 + ' ' + ( 1 === d2 ? t( 'durationDay', 'day' ) : t( 'durationDays', 'days' ) );
		}
		var mins = start && end ? Math.max( 0, Math.round( ( end - start ) / 60000 ) ) : 0;
		if ( 60 <= mins && 0 === mins % 60 ) {
			var hrs = Math.round( mins / 60 );
			return hrs + ' ' + ( 1 === hrs ? t( 'durationHour', 'hour' ) : t( 'durationHours', 'hours' ) );
		}
		if ( 60 <= mins ) {
			var hh = Math.floor( mins / 60 );
			var mm = mins % 60;
			return hh + ' ' + ( 1 === hh ? t( 'durationHr', 'hr' ) : t( 'durationHrs', 'hrs' ) ) + ' ' + mm + ' ' + t( 'durationMin', 'min' );
		}
		return mins + ' ' + t( 'durationMin', 'min' );
	}

	function formatRange( start, end, unit, durationVal, startTs, endTs, stacked ) {
		if ( ! start || ! end ) { return ''; }
		var dateFmt = calCfg.dateFormat || 'F j, Y';
		var timeFmt = calCfg.timeFormat || 'g:i a';
		var showDaysOnly = ( 'day' === unit || 'month' === unit ) || ( ! unit && isAllDayRangeTs( startTs || 0, endTs || 0 ) );
		if ( showDaysOnly ) {
			var endInclusive = new Date( ( ( endTs || 0 ) - 1 ) * 1000 );
			var s = formatDateByPattern( start, dateFmt );
			var e = formatDateByPattern( endInclusive, dateFmt );
			if ( 'month' === unit && 1 === durationVal ) { return s; }
			return ( s === e ) ? s : ( s + ' \u2013 ' + e );
		}
		var sDate = formatDateByPattern( start, dateFmt );
		var eDate = formatDateByPattern( end, dateFmt );
		var t1 = formatTimeByPattern( start, timeFmt );
		var t2 = formatTimeByPattern( end, timeFmt );
		var times = t1 + ' \u2013 ' + t2;
		if ( stacked ) {
			return ( sDate === eDate ? sDate : ( sDate + ' \u2013 ' + eDate ) ) + '\n' + times;
		}
		if ( sDate === eDate ) {
			return sDate + ', ' + times;
		}
		return sDate + ', ' + t1 + ' \u2013 ' + eDate + ', ' + t2;
	}

	/** Shared with panel-series.js (same output as view panel “When”). Pass true as 3rd arg to stack date / time. */
	window.__wcaFormatAppointmentRange = function( startTs, endTs, stacked ) {
		startTs = parseInt( startTs, 10 ) || 0;
		endTs = parseInt( endTs, 10 ) || 0;
		if ( ! startTs || ! endTs ) {
			return '';
		}
		var allDay = isAllDayRangeTs( startTs, endTs );
		var start = dateForAdminRangeDisplay( startTs, allDay );
		var end = dateForAdminRangeDisplay( endTs, allDay );
		return ( start && end ) ? formatRange( start, end, '', 0, startTs, endTs, stacked ) : '';
	};

	// Currency formatting — mirrors calendar viewing panel logic
	var currencySymbols = ( i18n && i18n.currencySymbols ) || {};
	var currencyFormat  = ( i18n && i18n.currencyFormat ) || {};
	function toNum( v ) { var n = parseFloat( v ); return isNaN( n ) ? 0 : n; }
	function formatNumber( val, decimals, decSep, thouSep ) {
		var n = Number( val );
		if ( isNaN( n ) ) { n = 0; }
		var fixed = n.toFixed( 'number' === typeof decimals ? decimals : 2 );
		var parts = fixed.split( '.' );
		var integer = parts[ 0 ];
		var frac = 1 < parts.length ? parts[ 1 ] : '';
		var rgx = /(\d+)(\d{3})/;
		while ( rgx.test( integer ) ) {
			integer = integer.replace( rgx, '$1' + ( thouSep || ',' ) + '$2' );
		}
		return frac ? integer + ( decSep || '.' ) + frac : integer;
	}
	function fmtCurrency( v, orderCurrency ) {
		var symbol = ( orderCurrency && currencySymbols[ orderCurrency ] ) || '';
		var decs = ( 'number' === typeof currencyFormat.priceDecimals ) ? currencyFormat.priceDecimals : 2;
		var num = formatNumber( v, decs, currencyFormat.decimalSeparator, currencyFormat.thousandSeparator );
		var pos = String( currencyFormat.currencyPosition || 'left' );
		var space = ( 'left_space' === pos || 'right_space' === pos ) ? ' ' : '';
		if ( symbol ) {
			switch ( pos ) {
				case 'right':
				case 'right_space': return num + space + symbol;
				case 'left_space': return symbol + space + num;
				case 'left':
				default: return symbol + space + num;
			}
		}
		return num;
	}
	/** Storefront-style "(+$X)" / "(-$X)" for location/resource option labels. */
	function additionalCostSuffix( cost, orderCurrency ) {
		var n = parseFloat( cost );
		if ( isNaN( n ) || ! n ) { return ''; }
		return ' (' + ( n < 0 ? '-' : '+' ) + fmtCurrency( Math.abs( n ), orderCurrency ) + ')';
	}
	window.__wcaPanelFmtCurrency = fmtCurrency;
	window.__wcaPanelPayColon = function( h, label, amount, currency, link ) {
		var labelNode = link
			? h( 'a', { href: link, target: '_blank', rel: 'noopener noreferrer' }, label )
			: label;
		// Fragment (not an array): array children need keys and tripped React in SeriesPricingBlock.
		return h( Fragment, null, labelNode, ': ', h( 'span', { className: 'wca-series-pay-amount' }, fmtCurrency( amount, currency ) ) );
	};
	window.__wcaPanelPayAmountSpan = function( h, key, label, amount, currency, link ) {
		return h( 'span', { key: key }, window.__wcaPanelPayColon( h, label, amount, currency, link ) );
	};
	function footerCurrencyPrefixSuffix( orderCurrency ) {
		var symbol = ( orderCurrency && currencySymbols[ orderCurrency ] ) || '';
		if ( ! symbol ) {
			return { prefix: '', suffix: '' };
		}
		var pos = String( currencyFormat.currencyPosition || 'left' );
		var space = ( 'left_space' === pos || 'right_space' === pos ) ? ' ' : '';
		switch ( pos ) {
			case 'right':
				return { prefix: '', suffix: symbol };
			case 'right_space':
				return { prefix: '', suffix: space + symbol };
			case 'left_space':
				return { prefix: symbol + space, suffix: '' };
			case 'left':
			default:
				return { prefix: symbol + space, suffix: '' };
		}
	}
	// ─── ViewContent Component ────────────────────────────────────

	function ViewContent( props ) {
		var appt        = props.apptData || {};
		var callbacks   = props.callbacks || {};
		var products    = props.products || [];
		var staffList   = props.staffList || [];

		var [ orderInfo, setOrderInfo ]       = useState( appt.order_info || null );
		var [ localStatus, setLocalStatus ]   = useState( String( ( appt.status ) || '' ).toLowerCase() );
		var [ isUpdating, setIsUpdating ]     = useState( false );
		var [ resolvedStaffName, setResolvedStaffName ] = useState( '' );
		var [ resolvedProductName, setResolvedProductName ] = useState( '' );
		var [ customerAvatar, setCustomerAvatar ] = useState( '' );
		var [ staffAvatar, setStaffAvatar ]       = useState( '' );

		var seriesBundle = window.panelSeries && window.panelSeries.useSeriesBundle
			? window.panelSeries.useSeriesBundle( window.panelSeries.sid( appt ), appt )
			: null;

		var isApptLoading = !!( appt.id && !( 'product_title' in appt ) );

		var staffIdStr = ( appt.staff_id != null ) ? String( appt.staff_id ) : '';
		var adminPost  = calCfg.adminPost || '';
		var adminBase  = adminPost.replace( /post\.php.*/, '' );

		var rawStartTs = appt.start_ts || appt.start || 0;
		var rawEndTs   = appt.end_ts || appt.end || 0;
		// All-day appointments are calendar dates in site time; do not shift into admin TZ for display.
		var isAllDayView = !!( appt.all_day ) || isAllDayRangeTs( rawStartTs, rawEndTs );

		// Timestamps for display: timed → admin wall via tsToAdminLocalISO (matches edit form); all-day → site semantic.
		var start = dateForAdminRangeDisplay( rawStartTs, isAllDayView );
		var end   = dateForAdminRangeDisplay( rawEndTs, isAllDayView );

		var durationUnit = appt.duration_unit ? String( appt.duration_unit ) : '';
		var durationVal  = appt.duration ? parseInt( appt.duration, 10 ) : 0;
		var durationText = ( start && end ) ? formatDuration( start, end, durationUnit, durationVal, rawStartTs, rawEndTs ) : '';
		var rangeText    = ( start && end ) ? formatRange( start, end, durationUnit, durationVal, rawStartTs, rawEndTs ) : '';

		// Product lookup
		var product = null;
		for ( var j0 = 0; j0 < products.length; j0++ ) {
			if ( String( products[ j0 ].id ) === String( appt.product_id ) ) {
				product = products[ j0 ];
				break;
			}
		}

		// Resolve staff name from preloaded data
		useEffect( function() {
			if ( ! staffIdStr || '0' === staffIdStr ) { return; }
			if ( appt.staff_name ) { setResolvedStaffName( appt.staff_name ); return; }
			for ( var j = 0; j < staffList.length; j++ ) {
				if ( String( staffList[ j ].id ) === staffIdStr ) {
					var nm = staffList[ j ].full_name || staffList[ j ].display_name || staffList[ j ].name || '';
					if ( nm ) { setResolvedStaffName( nm ); return; }
				}
			}
			if ( 'staff_name' in appt ) {
				setResolvedStaffName( t( 'unknown_staff', 'Staff' ) + ' #' + staffIdStr );
				return;
			}
			apiGet( 'wc-appointments/v1/staff', { include: [ staffIdStr ], per_page: 1, _fields: 'id,display_name,full_name' } )
				.then( function( items ) {
					var s = ( Array.isArray( items ) && items[ 0 ] ) || null;
					if ( s ) { setResolvedStaffName( s.full_name || s.display_name || '' ); }
				} ).catch( function() {} );
		}, [ staffIdStr ] );

		// Resolve product name
		useEffect( function() {
			if ( appt.product_title ) { setResolvedProductName( appt.product_title ); return; }
			if ( product && product.name ) { setResolvedProductName( product.name ); return; }
			if ( 'product_title' in appt ) { return; }
			var pidStr = appt.product_id ? String( appt.product_id ) : '';
			if ( ! pidStr ) { return; }
			apiGet( 'wc-appointments/v1/products', { include: [ pidStr ], per_page: 1 } )
				.then( function( items ) {
					var p = ( Array.isArray( items ) && items[ 0 ] ) || null;
					if ( p && p.name ) { setResolvedProductName( p.name ); }
				} ).catch( function() {} );
		}, [ appt.product_id ] );

		// Resolve avatars and order info from preloaded data
		useEffect( function() {
			// Customer avatar
			if ( 'customer_avatar' in appt ) {
				setCustomerAvatar( appt.customer_avatar || '' );
			} else if ( appt.customer_id && parseInt( appt.customer_id, 10 ) > 0 ) {
				apiGet( 'wp/v2/users/' + String( appt.customer_id ), { context: 'edit', _fields: 'id,avatar_urls' } )
					.then( function( u ) {
						var av = ( u && u.avatar_urls ) ? ( u.avatar_urls['48'] || u.avatar_urls['96'] || '' ) : '';
						setCustomerAvatar( av );
					} ).catch( function() {} );
			}
			// Staff avatar
			if ( 'staff_avatar' in appt ) {
				setStaffAvatar( appt.staff_avatar || '' );
			} else if ( staffIdStr && parseInt( staffIdStr, 10 ) > 0 ) {
				apiGet( 'wp/v2/users/' + staffIdStr, { context: 'edit', _fields: 'id,avatar_urls' } )
					.then( function( u ) {
						var av = ( u && u.avatar_urls ) ? ( u.avatar_urls['48'] || u.avatar_urls['96'] || '' ) : '';
						setStaffAvatar( av );
					} ).catch( function() {} );
			}
			// Order info
			var isV2 = 'order_info' in appt || 'product_title' in appt;
			if ( isV2 ) {
				if ( appt.order_info ) {
					setOrderInfo( appt.order_info );
				} else if ( appt.order_id && ! ( 'order_info' in appt ) ) {
					apiGet( 'wc-appointments/v2/orders/' + String( appt.order_id ) )
						.then( function( data ) { setOrderInfo( data || null ); } )
						.catch( function() {} );
				} else if ( 'order_info' in appt ) {
					setOrderInfo( null );
				}
			} else if ( appt.order_id ) {
				apiGet( 'wc-appointments/v2/orders/' + String( appt.order_id ), { _fields: 'id,customer_email,customer_phone,currency,total,discount_total,discount_tax,coupon_lines,billing,line_items' } )
					.then( function( data ) { setOrderInfo( data || null ); } )
					.catch( function() {} );
			}
		}, [ appt.order_id, appt.customer_id, staffIdStr, appt.order_info ] );

		// Customer name resolution
		var firstName = appt.customer_first_name || ( orderInfo && orderInfo.billing && orderInfo.billing.first_name ) || '';
		var lastName  = appt.customer_last_name || ( orderInfo && orderInfo.billing && orderInfo.billing.last_name ) || '';
		var fullName  = ( firstName || lastName ) ? ( firstName + ' ' + lastName ).trim() : '';
		var displayName = isApptLoading ? '' : ( appt.customer_full_name || appt.customer_name || fullName || ( appt.customer_id ? ( '#' + appt.customer_id ) : t( 'guest', 'Guest' ) ) );

		var nameForLabel = ( product && product.name ) || resolvedProductName || '';

		// Order line item for this appointment
		var apptLineItem = null;
		var orderItemName = '';
		if ( orderInfo && appt.order_item_id && Array.isArray( orderInfo.line_items ) ) {
			for ( var jj = 0; jj < orderInfo.line_items.length; jj++ ) {
				var it = orderInfo.line_items[ jj ];
				if ( String( it && it.id ) === String( appt.order_item_id ) ) {
					apptLineItem = it;
					orderItemName = it.name || '';
					break;
				}
			}
		}
		if ( ! nameForLabel && orderItemName ) { nameForLabel = orderItemName; }

		// Addons extraction (shared)
		var addons = extractAddonsFromLineItem( apptLineItem );

		// ─── Hook context (same as calendar viewing panel) ──────────
		var hookContext = {
			h: h, t: t, i18n: i18n, appt: appt, orderInfo: orderInfo,
			staffList: staffList, products: products, adminBase: adminBase,
			adminPost: adminPost, customerAvatar: customerAvatar,
			staffAvatar: staffAvatar, displayName: displayName,
			resolvedStaffName: resolvedStaffName, rangeText: rangeText,
			durationText: durationText
		};
		var hooks = window.wcaModalHooks;

		// Resolved status: list/id-only opens load status via REST after mount; localStatus
		// is initialized once and does not follow appt.status unless we merge both sources.
		function getResolvedViewStatus() {
			return String( localStatus || ( appt.status ) || '' ).toLowerCase();
		}

		// ─── Status change handler ────────────────────────────
		function doStatusChange( newStatus ) {
			if ( isUpdating || newStatus === getResolvedViewStatus() ) { return; }
			if ( 'cancelled' === newStatus ) {
				if ( ! window.confirm( t( 'confirmCancel', 'Are you sure?' ) ) ) { return; }
			}
			setIsUpdating( true );
			apiPut( 'wc-appointments/v2/appointments/' + String( appt.id ), { status: newStatus } )
				.then( function( updated ) {
					setLocalStatus( newStatus );
					setIsUpdating( false );
					if ( callbacks.onSave ) { callbacks.onSave( appt.id, updated ); }
					try { window.dispatchEvent( new Event( 'wc_appointments_updated' ) ); } catch ( _ ) {}
				} )
				.catch( function() {
					window.alert( t( 'statusChangeFailed', 'An error occurred. Please try again.' ) );
					setIsUpdating( false );
				} );
		}

		// ─── Build grid rows ──────────────────────────────────
		var gridChildren = [];

		var keyIcons = {
			product: 'box',
			location: 'location',
			resources: 'door',
			meeting: 'video',
			customer: 'staffMember',
			when: 'calendar',
			staff: 'staffProvider',
			timezone: 'globe',
			addons: 'addons',
			pricing: 'payment'
		};

		function row( label, valueEl, key ) {
			var iconName = key ? keyIcons[ key ] : null;
			var keyContent;
			if ( iconName ) {
				keyContent = h( 'span', { className: 'wca-key-inner' },
					wpIcon( h, iconName, 'wca-key-icon', { title: label } ),
					h( 'span', { className: 'wca-key-label' }, label )
				);
			} else {
				keyContent = label;
			}
			gridChildren.push( h( 'div', { className: 'wca-key', key: ( key || label ) + '-k' }, keyContent ) );
			gridChildren.push( h( 'div', { className: 'wca-val', key: ( key || label ) + '-v' }, valueEl ) );
		}

		// ── Section builders ─────────────────────────────────────
		// Each returns an array of { label, value, key } row objects (or empty array to skip).
		// Hook filters and after-content are handled uniformly by the sections loop below.
		var viewPerms = calCfg.staffPermissions || {};

		function buildProductRows() {
			var viewProductColor = ( appt.cal_color && String( appt.cal_color ).trim() ) || ( product && product.cal_color ? String( product.cal_color ).trim() : '#0073aa' );
			var viewProdLink = appt.product_id && viewPerms.canManageProducts ? ( adminPost + '?post=' + String( appt.product_id ) + '&action=edit' ) : '';
			var viewProductNameDisplay = nameForLabel + ( appt.qty && parseInt( appt.qty, 10 ) > 1 ? ' \u00d7' + String( parseInt( appt.qty, 10 ) ) : '' );
			var viewProductNameEl = viewProdLink && viewProductNameDisplay ? h( 'a', { key: 'name', href: viewProdLink }, viewProductNameDisplay ) : ( viewProductNameDisplay ? h( 'span', { key: 'name' }, viewProductNameDisplay ) : h( 'span', { key: 'name', className: 'wca-skeleton wca-skeleton-product' } ) );
			var viewProductDotEl = h( 'span', { key: 'dot', className: 'wca-product-color-dot', style: { '--wca-dot-color': viewProductColor }, 'aria-hidden': 'true' } );
			var viewProductValueEl = h( 'span', { className: 'wca-val-product' }, viewProductNameEl, viewProductDotEl );
			return [ { label: t( 'product', 'Product' ), value: viewProductValueEl, key: 'product' } ];
		}

		function buildStaffRows() {
			if ( ! staffIdStr || '0' === staffIdStr ) { return []; }
			var sObj = null;
			for ( var k = 0; k < staffList.length; k++ ) {
				if ( String( staffList[ k ].id ) === staffIdStr ) { sObj = staffList[ k ]; break; }
			}
			var baseName = sObj ? ( sObj.full_name || sObj.display_name || sObj.name || '' ) : '';
			var sName = resolvedStaffName || baseName || '';
			var staffHref = adminBase + 'user-edit.php?user_id=' + staffIdStr;
			var staffNameNode = sName ? h( 'a', { key: 'name', href: staffHref }, sName ) : h( 'span', { key: 'name', className: 'wca-skeleton' } );
			var staffAvatarNode = h( 'a', { key: 'avatar', href: staffHref, className: 'wca-avatar-link' },
				staffAvatar ? h( 'img', { className: 'wca-avatar', src: staffAvatar, alt: '' } ) : h( 'span', { className: 'wca-avatar-skeleton' } )
			);
			var staffTz = sObj && sObj.timezone ? sObj.timezone : '';
			var staffTzInfo = computeTzInfo( staffTz, rawStartTs );
			var staffTzNode = staffTzInfo ? h( 'abbr', { key: 'staff-tz', className: 'wca-tz-context-abbr', 'aria-label': staffTzInfo.tooltip, tabIndex: 0 }, staffTzInfo.abbr ) : null;
			var staffSummary = h( 'div', { className: 'wca-staff-summary' }, staffAvatarNode, staffNameNode, staffTzNode );
			return [ { label: t( 'staff', 'Staff' ), value: staffSummary, key: 'staff' } ];
		}

		function buildLocationRows() {
			var locText = appt.location_display || '';
			if ( ! locText ) { return []; }
			var href = appt.location_id && viewPerms.canManageLocations
				? adminPost + '?post=' + String( appt.location_id ) + '&action=edit'
				: '';
			return [ { label: t( 'location', 'Location' ), value: href ? h( 'a', { href: href }, locText ) : locText, key: 'location' } ];
		}

		function buildResourceRows() {
			var canLink = !! viewPerms.canManageResources;
			var parts = [];
			var allocs = Array.isArray( appt.resource_allocations ) ? appt.resource_allocations : [];
			allocs.forEach( function( a, idx ) {
				if ( ! a ) { return; }
				var title = a.title ? String( a.title ).trim() : '';
				var rid = parseInt( a.resource_id, 10 ) || 0;
				if ( ! title && rid ) {
					title = '#' + String( rid );
				}
				if ( ! title ) { return; }
				if ( parts.length ) {
					parts.push( ', ' );
				}
				if ( canLink && rid ) {
					parts.push( h( 'a', {
						key: 'res-' + String( rid ) + '-' + String( idx ),
						href: adminPost + '?post=' + String( rid ) + '&action=edit'
					}, title ) );
				} else {
					parts.push( h( 'span', { key: 'res-' + String( rid || idx ) }, title ) );
				}
			} );
			if ( ! parts.length ) {
				var text = appt.resource_display || '';
				if ( ! text ) { return []; }
				return [ { label: t( 'resources', 'Resources' ), value: text, key: 'resources' } ];
			}
			return [ {
				label: t( 'resources', 'Resources' ),
				value: h( 'span', { className: 'wca-val-resources' }, parts ),
				key: 'resources'
			} ];
		}

		function buildMeetingRows() {
			var joinUrl = appt.meeting_join_url || '';
			if ( ! joinUrl ) { return []; }
			return [ {
				label: t( 'joinMeeting', 'Join Meeting' ),
				value: h( 'a', { href: joinUrl, target: '_blank', rel: 'noopener noreferrer' }, t( 'openMeeting', 'Open meeting' ) ),
				key: 'meeting'
			} ];
		}

		function buildScheduleRows() {
			if ( ! rangeText && ! durationText ) { return []; }
			var whenChildren = [];
			if ( rangeText ) {
				whenChildren.push( rangeText );
				var whenTzHtml = ( ! isAllDayView && calCfg.adminTimezoneHtml ) ? String( calCfg.adminTimezoneHtml ).trim() : '';
				if ( whenTzHtml ) {
					whenChildren.push( h( 'span', { key: 'tz', dangerouslySetInnerHTML: { __html: whenTzHtml } } ) );
				}
			}
			if ( durationText ) {
				if ( whenChildren.length ) {
					whenChildren.push( ' ' );
					whenChildren.push( h( 'span', { key: 'dur', className: 'wca-when-duration' }, '\u00b7 ' + durationText ) );
				} else {
					whenChildren.push( durationText );
				}
			}
			return [ { label: t( 'when', 'When' ), value: h( 'span', null, whenChildren ), key: 'when' } ];
		}

		function buildCustomerRows() {
			var uid = appt.customer_id ? String( appt.customer_id ) : '';
			var link = uid ? ( adminBase + 'user-edit.php?user_id=' + uid ) : '';
			var avatarNode = link ? h( 'a', { key: 'avatar', href: link, className: 'wca-avatar-link', title: t( 'editCustomer', 'Edit Customer' ) },
				customerAvatar ? h( 'img', { className: 'wca-avatar', src: customerAvatar, alt: '' } ) : h( 'span', { className: 'wca-avatar-skeleton' } )
			) : ( isApptLoading ? h( 'span', { key: 'avatar', className: 'wca-avatar-skeleton' } ) : null );
			var nameNode = link && displayName ? h( 'a', { key: 'name', href: link, className: 'wca-customer-name' }, displayName ) : h( 'span', { key: 'name', className: 'wca-customer-name' }, displayName || h( 'span', { className: 'wca-skeleton' } ) );
			var custStatus = String( appt.customer_status || 'expected' ).toLowerCase();
			var attendanceNode = null;
			if ( 'expected' !== custStatus ) {
				var custStatusLabel = ( 'arrived' === custStatus ) ? t( 'arrived', 'Arrived' ) : ( ( 'no-show' === custStatus ) ? t( 'noShow', 'No-show' ) : '' );
				if ( custStatusLabel ) {
					attendanceNode = h( 'span', { key: 'attendance', className: 'wca-customer-attendance' }, custStatusLabel );
				}
			}
			var customerTz = appt.customer_timezone || appt.local_timezone || '';
			var custTzInfo = computeTzInfo( customerTz, rawStartTs );
			var customerTzNode = custTzInfo ? h( 'abbr', { key: 'cust-tz', className: 'wca-tz-context-abbr', 'aria-label': custTzInfo.tooltip, tabIndex: 0 }, custTzInfo.abbr ) : null;
			var customerEmail = ( orderInfo && orderInfo.billing && orderInfo.billing.email ) || appt.customer_email || '';
			var customerPhone = ( orderInfo && orderInfo.billing && orderInfo.billing.phone ) || appt.customer_phone || '';
			var emailIcon = customerEmail ? h( 'a', { key: 'email', href: 'mailto:' + customerEmail, className: 'wca-contact-icon wca-contact-email', title: customerEmail }, wpIcon( h, 'atSymbol', null ) ) : null;
			var phoneIcon = customerPhone ? h( 'a', { key: 'phone', href: 'tel:' + customerPhone.replace( /[^\d+]/g, '' ), className: 'wca-contact-icon wca-contact-phone', title: customerPhone }, wpIcon( h, 'mobile', null ) ) : null;
			var contactIcons = ( emailIcon || phoneIcon ) ? h( 'span', { key: 'contact-icons', className: 'wca-contact-icons' }, emailIcon, phoneIcon ) : null;
			var summary = h( 'div', { className: 'wca-customer-summary' }, avatarNode, nameNode, attendanceNode, contactIcons, customerTzNode );
			return [ { label: t( 'customer', 'Customer' ), value: summary, key: 'customer' } ];
		}

		function buildTimezoneRows() {
			if ( ! calCfg.showTimezoneContext ) { return []; }

			// Customer TZ abbr is shown next to the customer name (buildCustomerRows).
			// Here we only surface booking timezone when it differs from the customer's
			// preference (mirrors class-wc-appointment-meta-box-data.php).
			var customerTz = appt.customer_timezone || appt.local_timezone || '';
			var bookingTz  = appt.local_timezone || '';

			var bookingTzInfo = null;
			if ( bookingTz && bookingTz !== customerTz ) {
				bookingTzInfo = computeTzInfo( bookingTz, rawStartTs );
			}

			if ( ! bookingTzInfo ) { return []; }

			var tzBlock = h( 'div', { className: 'wca-tz-block' },
				h( 'div', { key: 'book-tz' },
					t( 'bookingTimezone', 'Booking Timezone' ) + ': ',
					h( 'abbr', { className: 'wca-tz-context-abbr', 'aria-label': bookingTzInfo.tooltip, tabIndex: 0 }, bookingTzInfo.abbr )
				)
			);
			return [ { label: t( 'timezones', 'Timezones' ), value: tzBlock, key: 'timezone' } ];
		}

		function buildAddonsRows() {
			if ( ! addons.length ) { return []; }
			var addonsBlock = renderAddonsBlock( addons );
			return [ { label: t( 'addons', 'Add-ons' ), value: addonsBlock, key: 'addons' } ];
		}

		function buildDefaultPricingNode() {
			var pNode = null;
			var renderItemsArea = !!( orderInfo && appt.order_item_id );
			if ( renderItemsArea ) {
				var itemName = ( apptLineItem && apptLineItem.name ) ? String( apptLineItem.name ) : ( nameForLabel || '' );
				var qty = ( apptLineItem && null != apptLineItem.quantity ) ? parseInt( apptLineItem.quantity, 10 ) : ( appt.qty ? parseInt( appt.qty, 10 ) : 1 );
				if ( isNaN( qty ) || 0 >= qty ) { qty = 1; }
				var costExTax = apptLineItem ? toNum( apptLineItem.total ) : 0;
				var taxAmt    = apptLineItem ? toNum( apptLineItem.total_tax ) : 0;
				var totalAmt  = costExTax + taxAmt;
				var prodLink  = appt.product_id && viewPerms.canManageProducts ? ( adminPost + '?post=' + String( appt.product_id ) + '&action=edit' ) : '';
				var orderLink = appt.order_id && viewPerms.canViewOrders ? ( adminPost + '?post=' + String( appt.order_id ) + '&action=edit' ) : '';
				var orderTotal = orderInfo ? toNum( orderInfo.total ) : 0;
				var oCurrency = orderInfo ? orderInfo.currency : '';
				var tolerance = 0.01;
				var itemDiscNode = null;
				if ( apptLineItem ) {
					var ex = Math.max( 0, toNum( apptLineItem.subtotal ) - toNum( apptLineItem.total ) );
					var tx = Math.max( 0, toNum( apptLineItem.subtotal_tax ) - toNum( apptLineItem.total_tax ) );
					var itemDisc = ex + tx;
					if ( itemDisc > tolerance ) {
						itemDiscNode = h( 'div', { key: 'item-discount', className: 'wca-item-discount' }, '-' + fmtCurrency( itemDisc, oCurrency ) + ' ' + t( 'discount', 'Discount' ) );
					}
				}
				var orderDiscNode = null;
				if ( orderInfo ) {
					var odEx  = toNum( orderInfo.discount_total ) || 0;
					var odTax = toNum( orderInfo.discount_tax ) || 0;
					var od    = odEx + odTax;
					var codes = [];
					if ( Array.isArray( orderInfo.coupon_lines ) ) {
						for ( var ci = 0; ci < orderInfo.coupon_lines.length; ci++ ) {
							var cl = orderInfo.coupon_lines[ ci ];
							if ( cl && cl.code ) { codes.push( String( cl.code ) ); }
						}
					}
					if ( od > tolerance && codes.length ) {
						var lab = ( 1 === codes.length ) ? t( 'coupon', 'Coupon' ) : t( 'coupons', 'Coupons' );
						var couponEls = [];
						couponEls.push( '-' + fmtCurrency( od, oCurrency ) + ' ' + lab + ': ' );
						for ( var codeIdx = 0; codeIdx < codes.length; codeIdx++ ) {
							if ( 0 < codeIdx ) { couponEls.push( ', ' ); }
							couponEls.push( h( 'span', { key: 'coupon-' + codeIdx }, codes[ codeIdx ] ) );
						}
						orderDiscNode = h( 'div', { key: 'order-discount', className: 'wca-item-discount' }, couponEls );
					}
				}
				var paySpan = window.__wcaPanelPayAmountSpan;
				var pricingLines = [];
				var heroes = [];
				var sameAsOrder = orderInfo && Math.abs( orderTotal - totalAmt ) <= tolerance;
				if ( orderInfo ) {
					heroes.push( paySpan( h, 'order-total', t( 'order_total', 'Order Total' ), orderTotal, oCurrency, orderLink ) );
				}
				// Line amount as a second hero only when there is no tax meta to carry Cost/Tax/Total.
				if ( ! sameAsOrder && taxAmt <= tolerance ) {
					heroes.push( paySpan( h, 'line-total', t( 'cost', 'Cost' ), costExTax, oCurrency ) );
				}
				if ( heroes.length ) {
					pricingLines.push( h( 'div', { key: 'heroes', className: 'wca-cost-tax-group wca-cost-tax-group--hero' }, heroes ) );
				}
				if ( taxAmt > tolerance ) {
					var metaSpans = [
						paySpan( h, 'cost', t( 'cost', 'Cost' ), costExTax, oCurrency ),
						paySpan( h, 'tax', t( 'tax', 'Tax' ), taxAmt, oCurrency )
					];
					// Line Total when it can differ from Order Total (multi-line orders) or there is no order.
					if ( ! sameAsOrder ) {
						metaSpans.push( paySpan( h, 'total', t( 'total', 'Total' ), totalAmt, oCurrency ) );
					}
					pricingLines.push( h( 'div', { key: 'meta', className: 'wca-cost-tax-group' }, metaSpans ) );
				}
				if ( itemDiscNode ) { pricingLines.push( itemDiscNode ); }
				if ( orderDiscNode ) { pricingLines.push( orderDiscNode ); }
				pNode = h( 'div', { className: 'wca-appointment-items' },
					h( 'div', { className: 'wca-pricing-section' }, pricingLines )
				);
			} else if ( appt.order_id && ! orderInfo ) {
				pNode = h( 'div', { className: 'wca-appointment-items' },
					h( 'div', { className: 'wca-pricing-section' },
						h( 'div', { className: 'wca-cost-tax-group wca-cost-tax-group--hero' },
							h( 'span', { className: 'wca-skeleton wca-skeleton-cost' } ),
							h( 'span', { className: 'wca-skeleton wca-skeleton-order-total' } )
						)
					)
				);
			}
			// Pricing hook filter operates on a single node (backward-compatible signature)
			if ( hooks ) { pNode = hooks.applyFilters( 'appointment_modal_pricing_section', pNode, appt, hookContext ); }
			return pNode;
		}

		function buildPricingRows() {
			if ( seriesBundle && window.panelSeries && window.panelSeries.isSeries( appt ) && window.panelSeries.SeriesPricingBlock ) {
				var seriesPricing = h( window.panelSeries.SeriesPricingBlock, {
					appt: appt,
					h: h,
					bundle: seriesBundle,
					buildDefaultPricing: buildDefaultPricingNode
				} );
				if ( seriesPricing ) {
					var pricingLabel = t( 'pricing', 'Pricing' );
					var payFirst = seriesBundle.payment && 'pay_first' === seriesBundle.payment.payment_model;
					if ( payFirst && cfg.recurring && cfg.recurring.balanceTitle ) {
						pricingLabel = cfg.recurring.balanceTitle;
					}
					return [ { label: pricingLabel, value: seriesPricing, key: 'pricing' } ];
				}
			}
			var pNode = buildDefaultPricingNode();
			if ( ! pNode ) { return []; }
			return [ { label: t( 'pricing', 'Pricing' ), value: pNode, key: 'pricing' } ];
		}

		// ── Declarative sections array ────────────────────────────
		// hookKey: used for applyFilters and getContent; null = no automatic hook processing.
		// Pricing handles its own filter internally (different signature) but still uses the after-content hook.
		var sections = [
{ key: 'product',  hookKey: null,       build: buildProductRows },
{ key: 'location', hookKey: null,       build: buildLocationRows },
{ key: 'resources', hookKey: null,      build: buildResourceRows },
{ key: 'meeting',  hookKey: null,       build: buildMeetingRows },
{ key: 'staff',    hookKey: 'staff',    build: buildStaffRows },
{ key: 'schedule', hookKey: 'schedule', build: buildScheduleRows },
			{ key: 'customer', hookKey: 'customer', build: buildCustomerRows },
			{ key: 'timezone', hookKey: null,        build: buildTimezoneRows },
			{ key: 'addons',   hookKey: 'addons',   build: buildAddonsRows },
			{ key: 'pricing',  hookKey: null,        build: buildPricingRows }
		];

		for ( var si = 0; si < sections.length; si++ ) {
			var sec = sections[ si ];
			var secRows = sec.build();
			if ( ! secRows || ! secRows.length ) { continue; }

			// Apply hook filter (standard sections: filter operates on rows array)
			if ( sec.hookKey && hooks ) {
				secRows = hooks.applyFilters( 'appointment_modal_' + sec.hookKey + '_section', secRows, appt, hookContext );
			}

			// Push rows into grid
			for ( var ri = 0; ri < secRows.length; ri++ ) {
				row( secRows[ ri ].label, secRows[ ri ].value, secRows[ ri ].key );
			}

			// After-content hook (sections with hookKey only; pricing after-content handled separately below)
			var afterKey = sec.hookKey;
			if ( afterKey && hooks ) {
				var afterContent = hooks.getContent( 'appointment_modal_after_' + afterKey, appt, hookContext );
				if ( afterContent && afterContent.length ) {
					for ( var ai = 0; ai < afterContent.length; ai++ ) {
						gridChildren.push( h( 'div', { key: 'after-' + afterKey + '-' + ai, className: 'wca-custom-content wca-full-width' }, afterContent[ ai ] ) );
					}
				}
			}
		}

		var afterPricing = hooks ? hooks.getContent( 'appointment_modal_after_pricing', appt, hookContext ) : [];
		var afterPricingNodes = afterPricing && afterPricing.length ? afterPricing.map( function( el, idx ) {
			return h( 'div', { key: 'after-pricing-' + idx, className: 'wca-custom-content' }, el );
		} ) : null;

		// Recurring package sessions (panel footer block).
		var seriesFooterNode = ( seriesBundle && window.panelSeries && window.panelSeries.SeriesFooterBlock )
			? h( window.panelSeries.SeriesFooterBlock, { key: 'wca-series-footer', appt: appt, h: h, bundle: seriesBundle } )
			: null;

		// Before footer hook (series block is rendered after status below).
		var beforeFooter = hooks ? hooks.getContent( 'appointment_modal_before_footer', appt, hookContext ) : [];
		var beforeFooterChildren = [];
		if ( beforeFooter && beforeFooter.length ) {
			beforeFooter.forEach( function( el, idx ) {
				beforeFooterChildren.push( h( 'div', { key: 'before-footer-' + idx, className: 'wca-custom-content' }, el ) );
			} );
		}
		var beforeFooterNodes = beforeFooterChildren.length
			? h( 'div', { className: 'wca-before-footer' }, beforeFooterChildren )
			: null;

		// ── Status section (view: read-only, only current status) ──
		function buildStatusSection() {
			var loading = isUpdating || isApptLoading;
			if ( ! loading && ! appt.id ) { return null; }
			var s = getResolvedViewStatus();
			var statusMap = i18n.statuses || {};
			var label = loading ? '\u00a0' : ( s ? ( statusMap[ s ] || humanizeStatus( s ) ) : ( t( 'noStatus', 'No status' ) || '—' ) );
			var segClass = 'wca-status-seg ' + ( loading ? 'wca-status-seg--loading' : 'wca-status-seg--' + ( s || 'pending' ) + ' is-active wca-status-seg--readonly' );
			return h( 'div', { className: 'wca-status-section' },
				h( 'div', { className: 'wca-status-segmented wca-status-segmented--readonly', role: 'group', 'aria-label': t( 'appointmentStatus', 'Appointment status' ) },
					wpIcon( h, 'productFilterStatus', 'wca-status-icon', { title: t( 'status', 'Status' ) } ),
					h( 'span', { className: segClass }, label )
				)
			);
		}
		var statusSectionNode = buildStatusSection();

		// After header hook
		var afterHeader = hooks ? hooks.getContent( 'appointment_modal_after_header', appt, hookContext ) : [];
		var afterHeaderNodes = afterHeader && afterHeader.length ? afterHeader.map( function( el, idx ) {
			return h( 'div', { key: 'after-header-' + idx, className: 'wca-custom-content' }, el );
		} ) : null;

		var headerContent = null;
		if ( hooks ) { headerContent = hooks.applyFilters( 'appointment_modal_header', null, appt, hookContext ); }

		return h( 'div', { className: 'wca-panel-body-scroll' },
			headerContent || null,
			afterHeaderNodes,
			h( 'div', { className: 'wca-panel-grid' }, gridChildren ),
			afterPricingNodes,
			beforeFooterNodes,
			statusSectionNode,
			seriesFooterNode
		);
	}

	// ─── EditContent Component ────────────────────────────────────

	function EditContent( props ) {
		var appt       = props.apptData || {};
		var callbacks  = props.callbacks || {};
		var products   = props.products || [];
		var staffList  = props.staffList || [];
		var onCancel   = props.onCancel || function() {};
		var onSaved    = props.onSaved || function() {};

		var utils = window.WCAppointmentsTimezoneUtils;
		var ajaxUrl = cfg.ajaxUrl || '';
		var nonces  = cfg.ajaxNonces || {};

		var editProduct = null;
		for ( var pi = 0; pi < products.length; pi++ ) {
			if ( String( products[ pi ].id ) === String( appt.product_id ) ) {
				editProduct = products[ pi ];
				break;
			}
		}

		var durationUnit = appt.duration_unit ? String( appt.duration_unit ) : ( ( editProduct && editProduct.duration_unit ) ? String( editProduct.duration_unit ) : '' );
		var editStartTs = appt.start_ts || appt.start || 0;
		var editEndTs   = appt.end_ts || appt.end || 0;
		// All-day: use site-local semantic date (no admin-TZ shift). Timed: admin-local ISO for inputs.
		// Handle potential string '0'/'1' or integer values from database.
		var isAllDay = ( true === appt.all_day || 1 === appt.all_day || '1' === appt.all_day || 'true' === appt.all_day ) || isAllDayRangeTs( editStartTs, editEndTs );
		
		// If it's a timed product (hour/minute) and has specific times (not exactly midnight), 
		// it should not be considered "all day" for UI purposes, even if backend forced all_day=true.
		if ( isAllDay && ( 'hour' === durationUnit || 'minute' === durationUnit ) ) {
			if ( editStartTs && editEndTs && ! isAllDayRangeTs( editStartTs, editEndTs ) ) {
				isAllDay = false;
			}
		}
		// Day/month duration products are date-based in the edit UI and must never
		// be interpreted as timed values in admin timezone (prevents day shifts).
		if ( 'day' === durationUnit || 'month' === durationUnit ) {
			isAllDay = true;
		}

		// ── Build initial form state from appt data ──
		var initDate      = '';
		var initTimeFrom  = '';
		var initTimeTo    = '';
		var initDateFrom  = '';
		var initDateTo    = '';
		var initMonthFrom = '';
		var initMonthTo   = '';
		if ( editStartTs ) {
			if ( utils && utils.tsToAdminLocalISO && ! isAllDay ) {
				var iso = utils.tsToAdminLocalISO( editStartTs );
				if ( iso ) {
					var parts    = iso.split( 'T' );
					initDate     = parts[ 0 ];
					initTimeFrom = ( parts[ 1 ] || '' ).substring( 0, 5 );
					initDateFrom  = initDate;
					initMonthFrom = initDate.substring( 0, 7 );
				}
			} else {
				var sd       = new Date( editStartTs * 1000 );
				initDate     = sd.getUTCFullYear() + '-' + ( '0' + ( sd.getUTCMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + sd.getUTCDate() ).slice( -2 );
				initTimeFrom = ( '0' + sd.getUTCHours() ).slice( -2 ) + ':' + ( '0' + sd.getUTCMinutes() ).slice( -2 );
				initDateFrom  = initDate;
				initMonthFrom = initDate.substring( 0, 7 );
			}
		}
		if ( editEndTs ) {
			if ( utils && utils.tsToAdminLocalISO && ! isAllDay ) {
				var iso = utils.tsToAdminLocalISO( editEndTs );
				if ( iso ) {
					var parts    = iso.split( 'T' );
					initDateTo   = parts[ 0 ];
					initTimeTo   = ( parts[ 1 ] || '' ).substring( 0, 5 );
					initMonthTo  = initDateTo.substring( 0, 7 );
				}
			} else {
				var ed       = new Date( editEndTs * 1000 );
				initDateTo   = ed.getUTCFullYear() + '-' + ( '0' + ( ed.getUTCMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + ed.getUTCDate() ).slice( -2 );
				initTimeTo   = ( '0' + ed.getUTCHours() ).slice( -2 ) + ':' + ( '0' + ed.getUTCMinutes() ).slice( -2 );
				initMonthTo  = initDateTo.substring( 0, 7 );
			}
		}
		// Day/all-day ranges can be stored in two forms:
		// 1) Exclusive end at next-day 00:00:00 (needs -1 day for display)
		// 2) Inclusive end at 23:59:59 (already display-ready)
		// Normalize only the exclusive-midnight variant.
		if ( initDateTo && ( isAllDay || 'day' === durationUnit ) && editEndTs > editStartTs ) {
			try {
				var endMod = editEndTs % 86400;
				var isExclusiveMidnightEnd = 0 === endMod;
				if ( isExclusiveMidnightEnd ) {
					var incEnd = new Date( initDateTo.replace( /-/g, '/' ) );
					incEnd.setDate( incEnd.getDate() - 1 );
					initDateTo = incEnd.getFullYear() + '-' + ( '0' + ( incEnd.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + incEnd.getDate() ).slice( -2 );
					initMonthTo = initDateTo.substring( 0, 7 );
				}
				initTimeTo = '00:00';
			} catch ( _incErr ) {}
		}
		var initStaffIds = [];
		if ( appt.staff_ids && Array.isArray( appt.staff_ids ) ) {
			initStaffIds = appt.staff_ids.map( String );
		} else if ( appt.staff_id ) {
			initStaffIds = [ String( appt.staff_id ) ];
		}
		var initLocationId = appt.location_id ? String( appt.location_id ) : '';
		var initResourceId = '';
		if ( Array.isArray( appt.resource_allocations ) && appt.resource_allocations.length && appt.resource_allocations[ 0 ].resource_id ) {
			initResourceId = String( appt.resource_allocations[ 0 ].resource_id );
		}

		var initStatus = String( appt.status || '' ).toLowerCase();
		var initCustomerId = appt.customer_id ? String( appt.customer_id ) : '';
		var initCustomerName = appt.customer_name || '';
		var initQty = appt.qty ? parseInt( appt.qty, 10 ) : 1;
		if ( isNaN( initQty ) || initQty < 1 ) { initQty = 1; }
		var initCustomerStatus = appt.customer_status ? String( appt.customer_status ) : 'expected';
		var initProductId = appt.product_id ? String( appt.product_id ) : '';

		var seriesBundle = window.panelSeries && window.panelSeries.useSeriesBundle
			? window.panelSeries.useSeriesBundle( window.panelSeries.sid( appt ), appt )
			: null;

		// ── Form state (shared hook) ──
		var _f = panelForm.useAppointmentForm( {
			date: initDate, timeFrom: initTimeFrom, timeTo: initTimeTo,
			dateFrom: initDateFrom, dateTo: initDateTo,
			monthFrom: initMonthFrom, monthTo: initMonthTo,
			staffIds: initStaffIds, locationId: initLocationId, resourceId: initResourceId, status: initStatus,
			customerId: initCustomerId, customerSearch: panelHelpers.sanitizeSelect2Label( initCustomerName ),
			customerStatus: initCustomerStatus, qty: initQty, productId: initProductId
		}, { dirtyFields: [ 'date', 'timeFrom', 'timeTo', 'dateFrom', 'dateTo', 'monthFrom', 'monthTo', 'staffIds', 'locationId', 'resourceId', 'status', 'customerId', 'customerStatus', 'qty', 'productId' ] } );
		var formDate        = _f.form.date;
		var formTimeFrom    = _f.form.timeFrom;
		var formTimeTo      = _f.form.timeTo;
		var formDateFrom    = _f.form.dateFrom;
		var formDateTo      = _f.form.dateTo;
		var formMonthFrom   = _f.form.monthFrom;
		var formMonthTo     = _f.form.monthTo;
		var formStaffIds    = _f.form.staffIds;
		var formLocationId  = _f.form.locationId || '';
		var formResourceId  = _f.form.resourceId || '';
		var formStatus      = _f.form.status;
		var formCustomerId  = _f.form.customerId;
		var customerSearch  = _f.form.customerSearch;
		var customerStatus  = _f.form.customerStatus;
		var formQty         = _f.form.qty;
		var formProductId   = _f.form.productId;
		var setFormDate        = function( v ) { _f.setField( 'date', v ); };
		var setFormTimeFrom    = function( v ) { _f.setField( 'timeFrom', v ); };
		var setFormTimeTo      = function( v ) { _f.setField( 'timeTo', v ); };
		var setFormDateFrom    = function( v ) { _f.setField( 'dateFrom', v ); };
		var setFormDateTo      = function( v ) { _f.setField( 'dateTo', v ); };
		var setFormMonthFrom   = function( v ) { _f.setField( 'monthFrom', v ); };
		var setFormMonthTo     = function( v ) { _f.setField( 'monthTo', v ); };
		var setFormStaffIds    = function( v ) { _f.setField( 'staffIds', v ); };
		var setFormLocationId  = function( v ) { _f.setField( 'locationId', v ); };
		var setFormResourceId  = function( v ) { _f.setField( 'resourceId', v || '' ); };
		var setFormStatus      = function( v ) { _f.setField( 'status', v ); };
		var setFormCustomerId  = function( v ) { _f.setField( 'customerId', v ); };
		var setCustomerSearch  = function( v ) { _f.setField( 'customerSearch', v ); };
		var setCustomerStatus  = function( v ) { _f.setField( 'customerStatus', v ); };
		var setFormQty         = function( v ) { _f.setField( 'qty', v ); };
		var setFormProductId   = function( v ) { _f.setField( 'productId', v ); };
		var [ customerResults, setCustomerResults ] = useState( [] );
		var [ isSaving, setIsSaving ]           = useState( false );
		var [ saveError, setSaveError ]         = useState( '' );
		var seriesScopeState                    = useState( 'one' );
		var seriesScope                         = seriesScopeState[ 0 ];
		var setSeriesScope                      = seriesScopeState[ 1 ];

		useEffect( function() {
			setSeriesScope( 'one' );
		}, [ appt.id ] );
		var initialProductName = appt.product_title || '';
		if ( ! initialProductName && appt.product_id ) {
			var pSearch = products.find( function( p ) { return String( p.id ) === String( appt.product_id ); } );
			if ( pSearch ) { initialProductName = pSearch.name || ''; }
		}
		var [ productName, setProductName ]     = useState( initialProductName );

		var editProductOptions = panelHelpers.productSelectOptions( products, formProductId, productName );

		// -- Overnight support --
		var initialEndDaysOffset = 0;
		if ( ! isAllDay && initDate && initDateTo && initDate !== initDateTo ) {
			try {
				var dStart = new Date( initDate.replace( /-/g, '/' ) );
				var dEnd   = new Date( initDateTo.replace( /-/g, '/' ) );
				var diffMs = dEnd.getTime() - dStart.getTime();
				initialEndDaysOffset = Math.max( 0, Math.round( diffMs / 86400000 ) );
			} catch ( _e ) {}
		}
		var [ endDaysOffset, setEndDaysOffset ] = useState( initialEndDaysOffset );

		// ── Browse state (shared hook) ──
		var _b = panelForm.useBrowseState();
		var browseOpen          = _b.browseOpen;
		var setBrowseOpen       = _b.setBrowseOpen;
		var miniCalMonth        = _b.miniCalMonth;
		var setMiniCalMonth     = _b.setMiniCalMonth;
		var miniCalData         = _b.miniCalData;
		var setMiniCalData      = _b.setMiniCalData;
		var miniCalLoading      = _b.miniCalLoading;
		var setMiniCalLoading   = _b.setMiniCalLoading;
		var miniCalExpanded     = _b.miniCalExpanded;
		var setMiniCalExpanded  = _b.setMiniCalExpanded;
		var miniCalStripCenter  = _b.miniCalStripCenter;
		var setMiniCalStripCenter = _b.setMiniCalStripCenter;
		var slotsData           = _b.slotsData;
		var setSlotsData        = _b.setSlotsData;
		var slotsLoading        = _b.slotsLoading;
		var setSlotsLoading     = _b.setSlotsLoading;
		var availStatus         = _b.availStatus;
		var setAvailStatus      = _b.setAvailStatus;
		var availMessage        = _b.availMessage;
		var setAvailMessage     = _b.setAvailMessage;
		var availXHRRef         = _b.refs.availXHR;
		var availTimerRef       = _b.refs.availTimer;
		var availCheckGenRef    = _b.refs.availCheckGen;
		var editBrowseSectionRef = useRef( null );
		var editDetailsSectionRef = useRef( null );

		// Order info for addons display
		var [ orderInfo, setOrderInfo ]           = useState( null );
		var editStaffSelectRef     = useRef( null );
		var editLocationSelectRef  = useRef( null );
		var editResourceSelectRef  = useRef( null );
		var editProductSelectRef   = useRef( null );
		var editCustomerSelectRef  = useRef( null );
		// Only check availability after the user explicitly changes date/time in edit panel.
		var availabilityTouchedRef = useRef( false );
		// Initialize with site-TZ time from the appointment timestamp so slot chips
		// highlight correctly on initial load when admin TZ differs from site TZ.
		// Timestamps are "site-tz-as-UTC", so UTC components give site-local time.
		var initSiteTime = '';
		var initSiteDate = '';
		if ( editStartTs && ! isAllDay ) {
			var siteD = new Date( editStartTs * 1000 );
			initSiteTime = ( siteD.getUTCHours() < 10 ? '0' : '' ) + siteD.getUTCHours() + ':' + ( siteD.getUTCMinutes() < 10 ? '0' : '' ) + siteD.getUTCMinutes();
			initSiteDate = siteD.getUTCFullYear() + '-' + ( siteD.getUTCMonth() < 9 ? '0' : '' ) + ( siteD.getUTCMonth() + 1 ) + '-' + ( siteD.getUTCDate() < 10 ? '0' : '' ) + siteD.getUTCDate();
		}
		var selectedSlotSiteTimeRef = useRef( initSiteTime );
		var selectedSlotSiteDateRef = useRef( initSiteDate );
		var selectedSlotStartTsRef = useRef( ( appt.id && ! isAllDay ) ? ( editStartTs || 0 ) : 0 );
		var selectedSlotAdminDateRef = useRef( ( appt.id && ! isAllDay && formDate ) ? formDate : '' );
		var editPreviewTimerRef    = useRef( null );
		var editPreviewLiveRef     = useRef( false );
		var editPreviewScheduleKeyRef = useRef( '' );

		var isDirty = _f.isDirty;

		useEffect( function() {
			if ( props.registerDiscardCheck ) {
				props.registerDiscardCheck( function() {
					if ( ! isDirty ) { return true; }
					return window.confirm( t( 'discardChanges', 'You have unsaved changes. Discard them?' ) );
				} );
			}
			return function() {
				if ( props.registerDiscardCheck ) { props.registerDiscardCheck( null ); }
			};
		}, [ isDirty, props.registerDiscardCheck ] );

		var editProductColor = ( appt.cal_color && String( appt.cal_color ).trim() ) || ( editProduct && editProduct.cal_color ? String( editProduct.cal_color ).trim() : '#0073aa' );
		var editAdminPost = calCfg.adminPost || '';
		var editProdLink = appt.product_id ? ( editAdminPost + '?post=' + String( appt.product_id ) + '&action=edit' ) : '';
		var editPerms = calCfg.staffPermissions || {};
		if ( ! editPerms.canManageProducts ) { editProdLink = ''; }

		// ── Status options ──
		var statusMap = i18n.statuses || {};
		var allStatuses = [ 'confirmed', 'unpaid', 'paid', 'pending-confirmation', 'complete', 'cancelled' ];

		// ── Staff + schedule shape: follow the selected form product (not only the original appt) ──
		var formProductRow = null;
		for ( var fpi = 0; fpi < products.length; fpi++ ) {
			if ( String( products[ fpi ].id ) === String( formProductId ) ) {
				formProductRow = products[ fpi ];
				break;
			}
		}
		var formDurationUnit = ( formProductRow && formProductRow.duration_unit )
			? String( formProductRow.duration_unit )
			: durationUnit;
		// Write-site product switch: UI must use form product has_time/duration, not appt.isAllDay.
		var showTimeFields = formProductRow
			? ( !! formProductRow.has_time && 'day' !== formDurationUnit && 'night' !== formDurationUnit && 'month' !== formDurationUnit )
			: ( 'month' !== durationUnit && 'day' !== durationUnit && 'night' !== durationUnit && ! isAllDay );
		var showDateRange  = ( 'day' === formDurationUnit || ( ! formProductRow && isAllDay ) || endDaysOffset > 0 ) && 'month' !== formDurationUnit;
		var showMonthRange = 'month' === formDurationUnit;
		var editHasStaff = !!( formProductRow && formProductRow.has_staff );
		var showEditStaff = editHasStaff || !!calCfg.canManageOthers;
		var editHasLocations = !!( formProductRow && formProductRow.has_locations );
		var editLocationMap = ( formProductRow && formProductRow.locations ) || {};
		var editLocationMode = ( formProductRow && formProductRow.location_mode ) || 'none';
		var editLocationCosts = ( formProductRow && formProductRow.location_costs ) || {};
		var editOptCurrency = ( window.wcaPanel && window.wcaPanel.currency ) || calCfg.currency || '';
		var locationOptions = editHasLocations ? Object.keys( editLocationMap ).map( function( lid ) {
			return { value: String( lid ), label: String( editLocationMap[ lid ] || lid ) + additionalCostSuffix( editLocationCosts[ lid ], editOptCurrency ) };
		} ) : [];
		var editLocationPickRequired = editHasLocations && 'customer_choice' === editLocationMode && locationOptions.length > 1 && ! formLocationId;
		var editHasResources = !!( formProductRow && formProductRow.has_resources );
		var editResourceMap = ( formProductRow && formProductRow.resources ) || {};
		var editResourceLabel = ( formProductRow && formProductRow.resource_label ) || t( 'resources', 'Resources' );
		var resourceOptions = [];
		if ( editHasResources ) {
			Object.keys( editResourceMap ).forEach( function( rid ) {
				var row = editResourceMap[ rid ];
				if ( ! row ) { return; }
				var rLoc = parseInt( row.location_id, 10 ) || 0;
				// Match WC_Appointments_Resource::is_available_at_location when a venue is chosen.
				if ( formLocationId && rLoc !== parseInt( formLocationId, 10 ) ) { return; }
				resourceOptions.push( {
					value: String( rid ),
					label: ( row.title || String( rid ) ) + additionalCostSuffix( row.cost, editOptCurrency )
				} );
			} );
		}
		function onEditLocationChange( v ) {
			var next = v || '';
			if ( String( next ) === String( formLocationId || '' ) ) { return; }
			// Keep civil date(s); only times are invalid for the new venue (slots reload).
			_f.setFields( {
				locationId: next,
				resourceId: '',
				staffIds: [],
				timeFrom: '', timeTo: ''
			} );
			selectedSlotSiteTimeRef.current = '';
			selectedSlotStartTsRef.current = 0;
			setBrowseOpen( false );
			setAvailStatus( '' );
			setAvailMessage( '' );
		}
		var availStaffId = editHasStaff ? ( formStaffIds[ 0 ] || '' ) : '';
		var staffOptions = showEditStaff ? staffList.map( function( s ) {
			return { value: String( s.id ), label: s.full_name || s.display_name || s.name || ( '#' + s.id ) };
		} ) : [];

		// Staff users on unstaffed products must not keep a forced staff id (false unavailable).
		useEffect( function() {
			if ( ! showEditStaff && formStaffIds.length ) {
				setFormStaffIds( [] );
			}
		}, [ showEditStaff, formProductId ] );

		// Keep location in sync with product allow-list (fixed or a single listed location auto-picks).
		useEffect( function() {
			if ( ! editHasLocations ) {
				if ( formLocationId ) { setFormLocationId( '' ); }
				return;
			}
			var keys = Object.keys( editLocationMap );
			if ( ! keys.length ) { return; }
			if ( 'fixed' === editLocationMode || 'hidden' === editLocationMode || 1 === keys.length ) {
				if ( formLocationId !== keys[ 0 ] ) { setFormLocationId( keys[ 0 ] ); }
				return;
			}
			if ( formLocationId && ! editLocationMap[ formLocationId ] ) {
				setFormLocationId( '' );
			}
		}, [ formProductId, editHasLocations, editLocationMode, locationOptions.length ] );

		// Keep resource in sync with product pool (location-filtered); single option auto-picks.
		useEffect( function() {
			if ( ! editHasResources ) {
				if ( formResourceId ) { setFormResourceId( '' ); }
				return;
			}
			var valid = {};
			resourceOptions.forEach( function( opt ) { valid[ opt.value ] = true; } );
			if ( formResourceId && ! valid[ formResourceId ] ) {
				setFormResourceId( '' );
				return;
			}
			if ( ! formResourceId && 1 === resourceOptions.length ) {
				setFormResourceId( resourceOptions[ 0 ].value );
			}
		}, [ formProductId, formLocationId, editHasResources, resourceOptions.length ] );

		// ── Customer search ──
		var searchTimerRef = useRef( null );
		function handleCustomerSearch( term ) {
			setCustomerSearch( term );
			if ( searchTimerRef.current ) { clearTimeout( searchTimerRef.current ); }
			if ( ! term || term.length < 2 ) {
				setCustomerResults( [] );
				return;
			}
			searchTimerRef.current = setTimeout( function() {
				var searchParams = new URLSearchParams();
				searchParams.append( 'action', 'woocommerce_json_search_customers' );
				searchParams.append( 'security', nonces.searchCustomers || '' );
				searchParams.append( 'term', term );
				fetch( ajaxUrl + '?' + searchParams.toString(), { method: 'GET', credentials: 'same-origin' } )
					.then( function( r ) { return r.json(); } )
					.then( function( data ) {
						if ( data && 'object' === typeof data ) {
							var results = [];
							var keys = Object.keys( data );
							for ( var ki = 0; ki < keys.length; ki++ ) {
								results.push( { id: keys[ ki ], name: panelHelpers.sanitizeSelect2Label( data[ keys[ ki ] ] ) } );
							}
							setCustomerResults( results );
						}
					} )
					.catch( function() {} );
			}, 300 );
		}
		
		// ── Auto-compute end time on mount if missing but fromTime exists ──
		useEffect( function() {
			if ( appt.id && formTimeFrom && ! formTimeTo && originalDurationMin ) {
				applyEditDurationToEnd( formTimeFrom );
			}
		}, [ formTimeFrom, formTimeTo, originalDurationMin ] );

		// ── Enhanced selects (selectWoo/select2) — delegated to panelHelpers ──
		useEffect( function() {
			return panelHelpers.initPreloadedProductSelect( editProductSelectRef, editProductOptions, setFormProductId, setProductName );
		}, [ editProductOptions.length ] );

		// Edit: staff enhanced select
		useEffect( function() {
			return panelHelpers.initEnhancedSelect( editStaffSelectRef, function( v ) {
				setFormStaffIds( v ? [ v ] : [] );
			} );
		}, [ staffOptions.length ] );

		useEffect( function() {
			panelHelpers.setEnhancedSelectValue( editStaffSelectRef, formStaffIds[ 0 ] || '' );
		}, [ formStaffIds[ 0 ] ] );

		// Edit: location enhanced select (visual parity with staff; fixed mode stays disabled)
		useEffect( function() {
			if ( ! editHasLocations || ! locationOptions.length ) { return; }
			return panelHelpers.initEnhancedSelect( editLocationSelectRef, onEditLocationChange );
		}, [ locationOptions.length, editLocationMode ] );

		useEffect( function() {
			panelHelpers.setEnhancedSelectValue( editLocationSelectRef, formLocationId || '' );
		}, [ formLocationId ] );

		// Edit: resource enhanced select
		useEffect( function() {
			if ( ! editHasResources || ! Object.keys( editResourceMap ).length ) { return; }
			return panelHelpers.initEnhancedSelect( editResourceSelectRef, setFormResourceId );
		}, [ Object.keys( editResourceMap ).length, formLocationId ] );

		useEffect( function() {
			panelHelpers.setEnhancedSelectValue( editResourceSelectRef, formResourceId || '' );
		}, [ formResourceId ] );

		useEffect( function() {
			if ( editLocationPickRequired && browseOpen ) {
				setBrowseOpen( false );
			}
		}, [ editLocationPickRequired ] );

		// Edit: customer AJAX select2 (delegated to panelHelpers)
		useEffect( function() {
			return panelHelpers.initAjaxSelect( editCustomerSelectRef, {
				url: ajaxUrl,
				action: 'woocommerce_json_search_customers',
				security: nonces.searchCustomers || '',
				placeholder: '',
				allowClear: false,
				onSelect: function( id, text ) {
					setFormCustomerId( id );
					setCustomerSearch( text );
					setCustomerResults( [] );
				}
			} );
		}, [ formCustomerId ] );

		// ── Order info loading (for addons display) ──
		useEffect( function() {
			if ( ! appt.order_id ) { return; }
			var cancelled = false;
			if ( appt.order_info ) {
				setOrderInfo( appt.order_info );
			} else {
				apiGet( 'wc-appointments/v2/orders/' + String( appt.order_id ) )
					.then( function( data ) { if ( ! cancelled ) { setOrderInfo( data || null ); } } )
					.catch( function() {} );
			}
			return function() { cancelled = true; };
		}, [ appt.order_id ] );

		// ── Browse data loading (delegated to panelHelpers action wrappers) ──
		function loadMonthAvailability( yearMonth ) {
			panelHelpers.loadMonthAvail( ajaxUrl, nonces, {
				productId: formProductId, staffId: availStaffId, locationId: formLocationId || '', resourceId: formResourceId || '', qty: formQty, yearMonth: yearMonth,
				date: showTimeFields ? ( formDate || '' ) : '',
				editingAppointmentId: appt.id || 0,
				showTimeFields: showTimeFields
			}, _b );
		}
		function loadStripAvailability( centerYMD ) {
			panelHelpers.loadStripAvail( ajaxUrl, nonces, {
				productId: formProductId, staffId: availStaffId, locationId: formLocationId || '', resourceId: formResourceId || '', qty: formQty, centerYMD: centerYMD,
				firstDayOfWeek: panelHelpers.getFirstDayOfWeek( browsePanelCfg ),
				date: showTimeFields ? ( formDate || centerYMD ) : '',
				editingAppointmentId: appt.id || 0,
				showTimeFields: showTimeFields,
				strip: !! ( editHasStaff && ! availStaffId )
			}, _b );
		}
		function loadDaySlots( date ) {
			var tzCfg = utils && utils.getTimezoneConfig && utils.getTimezoneConfig();
			if ( ! ( tzCfg && tzCfg.hasDifferentTz ) ) {
				selectedSlotSiteDateRef.current = date;
			}
			panelHelpers.loadDaySlotsAction( ajaxUrl, nonces, {
				productId: formProductId,
				staffId: availStaffId,
				locationId: formLocationId || '',
				resourceId: formResourceId || '',
				qty: formQty,
				date: date,
				showTimeFields: showTimeFields,
				editingAppointmentId: appt.id || 0
			}, _b );
		}

		// Opening browse via date/time focus: toggle open; load only when memory is empty.
		function openEditBrowseOnFocus() {
			if ( ! formProductId || browseOpen || editLocationPickRequired ) { return; }
			setMiniCalLoading( true );
			setBrowseOpen( true );
			schedulePanelFit( editBrowseSectionRef, true );
		}

		// Refresh mini-cal when open (product / staff / location / qty) or after SSE invalidate.
		useEffect( function() {
			panelHelpers.syncOpenBrowseCal( ajaxUrl, nonces, _b, {
				productId: formProductId,
				staffId: availStaffId,
				locationId: formLocationId || '',
				resourceId: formResourceId || '',
				qty: formQty,
				formDate: formDate,
				showMonthRange: showMonthRange,
				showTimeFields: showTimeFields,
				hasStaff: !! editHasStaff,
				firstDayOfWeek: panelHelpers.getFirstDayOfWeek( browsePanelCfg ),
				editingAppointmentId: appt.id || 0
			} );
		}, [ browseOpen, formProductId, availStaffId, formLocationId, formResourceId, formQty, miniCalExpanded, showMonthRange, showTimeFields, editHasStaff, _b.browseEpoch ] );

		// ── Availability check (delegated to panelHelpers) ──
		function scheduleCheckAvailability() {
			if ( ! formProductId || ! formDate ) {
				if ( availTimerRef.current ) { clearTimeout( availTimerRef.current ); }
				return;
			}
			if ( availTimerRef.current ) { clearTimeout( availTimerRef.current ); }
			availTimerRef.current = setTimeout( checkEditAvailability, 400 );
		}
		function checkEditAvailability() {
			if ( ! formProductId || ! ajaxUrl || ! formDate || editLocationPickRequired ) {
				if ( availCheckGenRef ) { availCheckGenRef.current += 1; }
				setAvailStatus( '' );
				setAvailMessage( '' );
				return;
			}
			var checkGen = beginAvailabilityPending( setAvailStatus, setAvailMessage, availCheckGenRef );

			var availParams = {
				productId: formProductId,
				staffId: availStaffId,
				locationId: formLocationId || '',
				resourceId: formResourceId || '',
				qty: formQty,
				showTimeFields: showTimeFields
			};
			if ( appt.id ) {
				availParams.editingAppointmentId = appt.id;
			}

			if ( showMonthRange ) {
				availParams.monthFrom = formMonthFrom;
				availParams.monthTo = formMonthTo || formMonthFrom;
			} else if ( ! showTimeFields ) {
				availParams.dateFrom = formDateFrom || formDate;
				availParams.dateTo = formDateTo || formDate;
			} else {
				assignResolvedTimedParams( availParams, resolveTimedAvailParams( {
					siteTimeRef: selectedSlotSiteTimeRef,
					siteDateRef: selectedSlotSiteDateRef,
					startTsRef: selectedSlotStartTsRef,
					adminDateRef: selectedSlotAdminDateRef,
					formSiteDate: formDate,
					formDate: formDate,
					formTimeFrom: formTimeFrom,
					formTimeTo: formTimeTo,
					showTimeFields: showTimeFields,
					forFetch: true,
					clearStale: true
				} ) );
			}

			panelHelpers.fetchAvailability( ajaxUrl, nonces, availParams, availXHRRef ).then( function( result ) {
				applyAvailabilityResult( availCheckGenRef, checkGen, setAvailStatus, setAvailMessage, result, true );
			} ).catch( function() {
				applyAvailabilityResult( availCheckGenRef, checkGen, setAvailStatus, setAvailMessage, {
					status: 'unavailable',
					message: 'Error checking availability'
				} );
			} );
		}

		// Schedule availability check when date/time changes
		useEffect( function() {
			if ( ! availabilityTouchedRef.current ) { return; }
			scheduleCheckAvailability();
			return function() { if ( availTimerRef.current ) { clearTimeout( availTimerRef.current ); } };
		}, [ formDate, formTimeFrom, formTimeTo, formProductId, formQty, formLocationId, formResourceId, JSON.stringify( formStaffIds ) ] );

		// ── Live preview on calendar only when draft schedule diverges from saved ──
		// Keeps the real event (and overlap layout) stable on view→edit; hide+ghost only while rescheduling.
		useEffect( function() {
			var api = window.__wcaCalPreview;
			if ( ! api ) { return; }
			var apptId = appt.id;
			var scheduleChanged = formDate !== initDate || formTimeFrom !== initTimeFrom || formTimeTo !== initTimeTo
				|| formDateTo !== initDateTo || formMonthFrom !== initMonthFrom || formMonthTo !== initMonthTo;

			if ( ! scheduleChanged ) {
				editPreviewLiveRef.current = false;
				editPreviewScheduleKeyRef.current = '';
				if ( apptId ) { api.showEvent( apptId ); }
				api.remove();
				return function() {
					if ( editPreviewTimerRef.current ) { clearTimeout( editPreviewTimerRef.current ); editPreviewTimerRef.current = null; }
				};
			}

			var scheduleKey = [
				formDate || '', formTimeFrom || '', formTimeTo || '',
				formDateTo || '', formMonthFrom || '', formMonthTo || '',
				showTimeFields ? '1' : '0', String( endDaysOffset || 0 )
			].join( '|' );
			var scheduleKeyChanged = editPreviewScheduleKeyRef.current !== scheduleKey;
			editPreviewScheduleKeyRef.current = scheduleKey;

			editPreviewLiveRef.current = true;
			if ( apptId ) { api.hideEvent( apptId ); }

			if ( editPreviewTimerRef.current ) { clearTimeout( editPreviewTimerRef.current ); }

			editPreviewTimerRef.current = setTimeout( function() {
				// Build preview ISO strings from current form state (or engine timestamps when set).
				var startISO = '';
				var endISO = '';
				var allDay = false;
				var previewStartTs = 0;
				var previewEndTs = 0;

				if ( showTimeFields ) {
					if ( formDate && formTimeFrom ) {
						var editSlotTs = parseInt( selectedSlotStartTsRef.current, 10 ) || 0;
						if ( editSlotTs > 86400 ) {
							// Naive startISO parses as browser-local and misplaces the bar when form
							// holds admin civil date+time; engine start_ts + tsToAdminLocalISO matches real events.
							previewStartTs = editSlotTs;
							if ( formTimeTo ) {
								var editDurSec = ( editStartTs && editEndTs ) ? Math.max( 60, editEndTs - editStartTs ) : 1800;
								previewEndTs = editSlotTs + editDurSec;
							}
						} else {
							startISO = formDate + 'T' + formTimeFrom + ':00';
							if ( formTimeTo ) {
								var dateToVal = ( ( showDateRange || endDaysOffset > 0 ) && formDateTo ) ? formDateTo : formDate;
								endISO = dateToVal + 'T' + formTimeTo + ':00';
							}
						}
					}
				} else if ( formDate ) {
					startISO = formDate;
					if ( editStartTs && editEndTs ) {
						var day     = 86400;
						var durSec  = editEndTs - editStartTs;
						var durDays = Math.max( 1, Math.ceil( durSec / day ) );
						var _ep      = formDate.split( '-' );
						var endD     = new Date( parseInt( _ep[ 0 ], 10 ), parseInt( _ep[ 1 ], 10 ) - 1, parseInt( _ep[ 2 ], 10 ) + durDays );
						endISO       = endD.getFullYear() + '-' + ( '0' + ( endD.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + endD.getDate() ).slice( -2 );
					} else {
						var _dp = formDate.split( '-' );
						var _nd = new Date( parseInt( _dp[ 0 ], 10 ), parseInt( _dp[ 1 ], 10 ) - 1, parseInt( _dp[ 2 ], 10 ) + 1 );
						endISO = _nd.getFullYear() + '-' + ( '0' + ( _nd.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + _nd.getDate() ).slice( -2 );
					}
					allDay = true;
				}

				if ( ! startISO && ! previewStartTs ) {
					api.remove();
					return;
				}

				// Navigate calendar to the new date if outside current view.
				var navDate = allDay ? startISO : ( previewStartTs ? formDate : ( startISO.split( 'T' )[ 0 ] || '' ) );
				var didNavigate = false;
				if ( navDate ) {
					didNavigate = api.navigateTo( navDate );
				}

				// Build preview data (title = customer like calendar events, not product).
				var previewData = {
					startISO: startISO || undefined,
					endISO: endISO || undefined,
					allDay: allDay
				};
				if ( previewStartTs > 86400 ) {
					previewData.startTs = previewStartTs;
					if ( previewEndTs > previewStartTs ) {
						previewData.endTs = previewEndTs;
					}
				} else if ( allDay ) {
					// Use site-local semantic timestamps (UTC midnight) for all-day preview.
					// This ensures the calendar uses its robust tsToNaiveLocalDate logic.
					previewData.startTs = Math.floor( new Date( startISO + 'T00:00:00Z' ).getTime() / 1000 );
					if ( endISO ) {
						previewData.endTs = Math.floor( new Date( endISO + 'T00:00:00Z' ).getTime() / 1000 );
					}
				}
				var previewTitle = t( 'guest', 'Guest' );
				var editCustId = parseInt( formCustomerId, 10 );
				if ( editCustId > 0 ) {
					var editCustLabel = customerSearch && String( customerSearch ).trim();
					previewTitle = panelHelpers.customerNameFromSelectLabel( editCustLabel ) || t( 'customer', 'Customer' );
				}
				previewData.title = ( window.panelSeries && window.panelSeries.isSeries( appt ) ? '\u21BB ' : '' ) + previewTitle;
				// Product color only (same as real events).
				if ( formProductId ) {
					for ( var epi = 0; epi < products.length; epi++ ) {
						if ( products[ epi ] && String( products[ epi ].id ) === String( formProductId ) ) {
							if ( products[ epi ].cal_color && String( products[ epi ].cal_color ).trim() ) {
								previewData.color = String( products[ epi ].cal_color ).trim();
							}
							break;
						}
					}
				}

				// Reposition the panel next to the preview event (no calendar scroll).
				function repositionPanelToPreview() {
					requestAnimationFrame( function() {
						requestAnimationFrame( function() {
							var previewEl = document.querySelector( '.wca-preview-event' );
							if ( previewEl && window.wcaPanel && window.wcaPanel.updateTrigger ) {
								window.wcaPanel.updateTrigger( previewEl );
							}
						} );
					} );
				}

				// Scroll calendar/page so the preview is in view, then reposition the panel (sync with layout).
				function scrollAndRepositionEditPreview() {
					requestAnimationFrame( function() {
						api.scrollToPreview();
						repositionPanelToPreview();
					} );
				}

				function applyPreview() {
					api.update( previewData );
					// Product/customer-only refreshes must not re-anchor the panel (real event remount jump).
					if ( scheduleKeyChanged || didNavigate ) {
						scrollAndRepositionEditPreview();
					}
				}

				if ( didNavigate ) {
					editPreviewTimerRef.current = setTimeout( applyPreview, 500 );
				} else {
					applyPreview();
				}
			}, 150 );

			return function() {
				if ( editPreviewTimerRef.current ) { clearTimeout( editPreviewTimerRef.current ); editPreviewTimerRef.current = null; }
				if ( api ) { api.remove(); }
				// Defer showEvent: immediate restore remounts the real panel-target and updateTrigger
				// jumps the panel (product switch / metadata refresh). Next effect re-claims live first.
				editPreviewLiveRef.current = false;
				var restoreId = apptId;
				Promise.resolve().then( function() {
					if ( editPreviewLiveRef.current ) { return; }
					var a = window.__wcaCalPreview;
					if ( restoreId && a ) { a.showEvent( restoreId ); }
				} );
			};
		}, [ formDate, formTimeFrom, formTimeTo, formDateTo, formMonthFrom, formMonthTo, formProductId, formCustomerId, customerSearch, products, showTimeFields, endDaysOffset, editStartTs, editEndTs, appt.id ] );

		// ── Save handler ──
		function handleSave() {
			if ( isSaving ) { return; }
			if ( editLocationPickRequired ) {
				setSaveError( t( 'locationRequired', 'Please choose a location.' ) );
				return;
			}
			var dateOrTimeChanged = formDate !== initDate || formTimeFrom !== initTimeFrom || formTimeTo !== initTimeTo || formDateTo !== initDateTo || formMonthFrom !== initMonthFrom || formMonthTo !== initMonthTo;
			var slotDirty = dateOrTimeChanged || formQty !== initQty || formProductId !== initProductId || String( formLocationId || '' ) !== String( initLocationId || '' ) || String( formResourceId || '' ) !== String( initResourceId || '' ) || JSON.stringify( formStaffIds ) !== JSON.stringify( initStaffIds );
			if ( slotDirty && ! allowUnavailableSubmit( availStatus, availMessage, cfg.allowUnavailable, t, setSaveError, editDetailsSectionRef ) ) {
				return;
			}
			setSaveError( '' );
			setIsSaving( true );

			var body = {};

			// Status
			if ( formStatus !== initStatus ) {
				body.status = formStatus;
			}

			// Attendance
			if ( customerStatus !== initCustomerStatus ) {
				body.customer_status = customerStatus;
			}

			// Schedule
			if ( dateOrTimeChanged && ( formDate || formMonthFrom ) ) {
				if ( isAllDay || 'day' === durationUnit ) {
					var dateVal = formDate || formDateFrom;
					body.start = Math.floor( new Date( dateVal + 'T00:00:00Z' ).getTime() / 1000 );
					var endD = new Date( ( formDateTo || dateVal ).replace( /-/g, '/' ) );
					endD.setDate( endD.getDate() + 1 );
					body.end = Math.floor( Date.UTC( endD.getFullYear(), endD.getMonth(), endD.getDate() ) / 1000 );
				} else if ( 'month' === durationUnit ) {
					var mFrom = formMonthFrom || formDate.substring( 0, 7 );
					body.start = Math.floor( new Date( mFrom + '-01T00:00:00Z' ).getTime() / 1000 );
					var mp = ( formMonthTo || mFrom ).split( '-' );
					var nextM = new Date( parseInt( mp[ 0 ], 10 ), parseInt( mp[ 1 ], 10 ), 1 );
					body.end = Math.floor( Date.UTC( nextM.getFullYear(), nextM.getMonth(), 1 ) / 1000 );
				} else {
					var dateVal = formDate;
					var timeFrom = formTimeFrom || '00:00';
					var timeTo = formTimeTo || '00:00';
					var dateToVal = dateVal;
					if ( endDaysOffset > 0 ) {
						try {
							var dt = new Date( dateVal.replace( /-/g, '/' ) );
							dt.setDate( dt.getDate() + endDaysOffset );
							dateToVal = dt.getFullYear() + '-' + ( '0' + ( dt.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + dt.getDate() ).slice( -2 );
						} catch ( _e ) {}
					}
					if ( utils && utils.convertAdminStringsToSiteTimezone ) {
						var convFrom = utils.convertAdminStringsToSiteTimezone( dateVal, timeFrom );
						var convTo   = utils.convertAdminStringsToSiteTimezone( dateToVal, timeTo );
						body.start = Math.floor( new Date( convFrom.date + 'T' + convFrom.time + ':00Z' ).getTime() / 1000 );
						body.end   = Math.floor( new Date( convTo.date + 'T' + convTo.time + ':00Z' ).getTime() / 1000 );
					} else {
						body.start = Math.floor( new Date( dateVal + 'T' + timeFrom + ':00Z' ).getTime() / 1000 );
						body.end = Math.floor( new Date( dateToVal + 'T' + timeTo + ':00Z' ).getTime() / 1000 );
					}
				}
			}

			// Staff
			if ( JSON.stringify( formStaffIds ) !== JSON.stringify( initStaffIds ) ) {
				body.staff_ids = formStaffIds.map( function( id ) { return parseInt( id, 10 ); } );
			}

			// Location
			if ( String( formLocationId || '' ) !== String( initLocationId || '' ) ) {
				body.location_id = formLocationId ? parseInt( formLocationId, 10 ) : 0;
			}

			// Resource (also re-apply when location changes so pool is re-filtered)
			if (
				String( formResourceId || '' ) !== String( initResourceId || '' )
				|| ( editHasResources && String( formLocationId || '' ) !== String( initLocationId || '' ) )
			) {
				body.resource_id = formResourceId ? parseInt( formResourceId, 10 ) : 0;
			}

			// Customer
			if ( formCustomerId !== initCustomerId ) {
				body.customer_id = formCustomerId ? parseInt( formCustomerId, 10 ) : 0;
			}

			// Quantity
			if ( formQty !== initQty ) {
				body.qty = formQty;
			}

			// Product
			if ( formProductId !== initProductId ) {
				body.product_id = formProductId ? parseInt( formProductId, 10 ) : 0;
			}

			// Series scope when status or schedule changed.
			if ( ( body.status || body.start || body.end ) && window.panelSeries && window.panelSeries.needsSeriesScope( appt, true ) ) {
				body.series_scope = seriesScope || 'one';
			}

			// Nothing changed
			if ( 0 === Object.keys( body ).length ) {
				setIsSaving( false );
				onCancel();
				return;
			}

			apiPut( 'wc-appointments/v2/appointments/' + String( appt.id ), body )
				.then( function( updated ) {
					setIsSaving( false );
					if ( callbacks.onSave ) { callbacks.onSave( appt.id, updated ); }
					onSaved( updated );

					// Add order note for the change
					try {
						var note = '';
						if ( ( body.start || body.end ) && window.__wcaFormatNoteRange ) {
							var prevTxt = window.__wcaFormatNoteRange( editStartTs, editEndTs, isAllDay );
							var nextTs  = body.start || editStartTs;
							var nextTe  = body.end || editEndTs;
							var nextAll = ( typeof body.all_day !== 'undefined' ) ? !! body.all_day : isAllDay;
							var nextTxt = window.__wcaFormatNoteRange( nextTs, nextTe, nextAll );
							note = t( 'appointmentUpdatedNoteWithChanges', 'Appointment #' + String( appt.id ) + ' updated: ' + prevTxt + ' → ' + nextTxt );
						} else {
							note = t( 'appointmentUpdatedNote', 'Appointment #' + String( appt.id ) + ' updated.' );
						}

						if ( appt.order_id && window.__wcaAddOrderNote ) {
							window.__wcaAddOrderNote( appt.order_id, note, false );
						}
					} catch ( _en ) {}

					try { window.dispatchEvent( new Event( 'wc_appointments_updated' ) ); } catch ( _ ) {}
				} )
				.catch( function( err ) {
					setIsSaving( false );
					setSaveError( t( 'updateFailed', 'An error occurred. Please try again.' ) + ( err && err.message ? ' ' + err.message : '' ) );
				} );
		}

		// ── Browse panel helpers ──
		var originalDurationMin = ( editStartTs && editEndTs ) ? Math.max( 0, Math.round( ( editEndTs - editStartTs ) / 60 ) ) : 0;
		function applyEditDurationToEnd( fromTime ) {
			if ( ! fromTime || ! originalDurationMin ) { return; }
			var parts = String( fromTime ).split( ':' );
			var startH = parseInt( parts[ 0 ], 10 );
			var startM = parseInt( parts[ 1 ] || 0, 10 );
			if ( isNaN( startH ) || isNaN( startM ) ) { return; }

			var startMin = ( startH * 60 ) + startM;
			var endMin = startMin + originalDurationMin;
			var endDisp = ( ( endMin % 1440 ) + 1440 ) % 1440;
			var hh = ( '0' + Math.floor( endDisp / 60 ) ).slice( -2 );
			var mm = ( '0' + ( endDisp % 60 ) ).slice( -2 );
			setFormTimeTo( hh + ':' + mm );
			var offset = Math.floor( endMin / 1440 );
			setEndDaysOffset( offset );
			if ( offset > 0 ) {
				var dt = new Date( formDate.replace( /-/g, '/' ) );
				dt.setDate( dt.getDate() + offset );
				setFormDateTo( dt.getFullYear() + '-' + ( '0' + ( dt.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + dt.getDate() ).slice( -2 ) );
			} else {
				setFormDateTo( formDate );
			}
		}
		// ── Addons from order line item (read-only display) ──
		var apptLineItem = null;
		if ( orderInfo && appt.order_item_id && Array.isArray( orderInfo.line_items ) ) {
			for ( var ali = 0; ali < orderInfo.line_items.length; ali++ ) {
				var alit = orderInfo.line_items[ ali ];
				if ( String( alit && alit.id ) === String( appt.order_item_id ) ) { apptLineItem = alit; break; }
			}
		}
		var addons = extractAddonsFromLineItem( apptLineItem );

		// ── Timezone context for datetime row ──
		var editTzInfo = computeTzInfo( calCfg.adminTimezone || '', editStartTs );

		// ── Edit status section (delegated to panelStatus module) ──
		var editStatusSectionNode = panelStatus.StatusSegmented( {
			value: formStatus,
			onChange: setFormStatus,
			statuses: allStatuses,
			statusMap: statusMap,
			pinnedStatuses: { 'confirmed': 1, 'cancelled': 1 },
			t: t,
			humanizeStatus: humanizeStatus
		} );

		var seriesScopeDirty = formStatus !== initStatus || formDate !== initDate || formTimeFrom !== initTimeFrom || formTimeTo !== initTimeTo || formDateTo !== initDateTo || formMonthFrom !== initMonthFrom || formMonthTo !== initMonthTo;
		var seriesScopeNode = ( window.panelSeries && window.panelSeries.SeriesScopeBlock && window.panelSeries.needsSeriesScope( appt, seriesScopeDirty ) )
			? h( window.panelSeries.SeriesScopeBlock, {
				key: 'wca-series-scope',
				appt: appt,
				h: h,
				value: seriesScope,
				onChange: setSeriesScope,
				visible: true
			} )
			: null;

		// ── Footer (rendered outside scrollable body by WcaPanel) ──
		// No live price in edit mode: order line totals are shown in view mode only (authoritative).
		// Always show Update (disabled until dirty) so the edit footer is never empty on open.
		var editFooter = h( 'div', { className: 'wca-panel-footer' },
			h( 'button', {
				type: 'button',
				className: 'button button-primary wca-panel-btn--primary',
				onClick: handleSave,
				disabled: isSaving || ! isDirty
			}, isSaving ? t( 'saving', 'Saving…' ) : t( 'update', 'Update' ) )
		);

		// ── Render — scrollable body + footer (footer stays at bottom via flex) ──
		return h( Fragment, null,
			h( 'div', { className: 'wca-panel-body-scroll' },
			// ── Product + Qty row (editable product, same layout as create) ──
			h( 'div', { className: 'wca-form-section wca-form-product-section' },
				h( 'div', { className: 'wca-form-row wca-form-product-row' },
					ti( {
						id: 'wca-edit-product',
						label: t( 'product', 'Product' ),
						value: formProductId,
						mod: 'grow',
						tag: 'select',
						ref: editProductSelectRef,
						onChange: function( e ) { setFormProductId( e.target.value ); },
						children: editProductOptions.map( function( opt ) {
							return h( 'option', { key: opt.value, value: opt.value }, opt.label );
						} )
					} ),
					ti( {
						id: 'wca-edit-qty',
						label: t( 'qty', 'Qty' ),
						value: String( formQty ),
						type: 'number',
						mod: 'qty',
						min: '1',
						step: '1',
						onChange: function( e ) {
						var v = parseInt( e.target.value, 10 );
						setFormQty( isNaN( v ) || v < 1 ? 1 : v );
						}
					} )
				)
			),

			// ── Location section ──
			editHasLocations && locationOptions.length ? h( 'div', { className: 'wca-form-section wca-form-location-section' },
				h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-edit-location',
						label: ( formProductRow && formProductRow.location_label ) || t( 'location', 'Location' ),
						value: formLocationId || '',
						mod: 'grow',
						tag: 'select',
						ref: editLocationSelectRef,
						required: 'customer_choice' === editLocationMode && locationOptions.length > 1,
						disabled: 'fixed' === editLocationMode || 'hidden' === editLocationMode || 1 === locationOptions.length,
						onChange: function( e ) {
							onEditLocationChange( e.target.value || '' );
						},
						children: [ h( 'option', { key: '', value: '' }, '' ) ].concat(
							locationOptions.map( function( opt ) {
								return h( 'option', { key: opt.value, value: opt.value }, opt.label );
							} )
						)
					} )
				)
			) : null,

			editLocationPickRequired ? h( 'div', { className: 'wca-slots-notice wca-slots-notice--info' }, t( 'locationGate', 'Choose a location to see available times.' ) ) : null,

			// ── Resource section (location-filtered; hide when venue has no matching rooms) ──
			editHasResources && ( resourceOptions.length || ! formLocationId ) && Object.keys( editResourceMap ).length ? h( 'div', { className: 'wca-form-section wca-form-resource-section' },
				h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-edit-resource',
						label: editResourceLabel,
						value: formResourceId || '',
						mod: 'grow',
						tag: 'select',
						ref: editResourceSelectRef,
						disabled: 1 === resourceOptions.length,
						onChange: function( e ) {
							setFormResourceId( e.target.value || '' );
						},
						children: [ h( 'option', { key: '', value: '' }, '' ) ].concat(
							resourceOptions.map( function( opt ) {
								return h( 'option', { key: opt.value, value: opt.value }, opt.label );
							} )
						)
					} )
				)
			) : null,

			// ── Staff section ──
			showEditStaff && staffOptions.length ? h( 'div', { className: 'wca-form-section wca-form-staff-section' },
				h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-edit-staff',
						label: t( 'staff', 'Staff' ),
						value: formStaffIds[ 0 ] || '',
						mod: 'grow',
						tag: 'select',
						ref: editStaffSelectRef,
						onChange: function( e ) {
						var val = e.target.value;
						setFormStaffIds( val ? [ val ] : [] );
						},
						children: [ h( 'option', { key: '', value: '' }, '' ),
						staffOptions.map( function( opt ) {
							return h( 'option', { key: opt.value, value: opt.value }, opt.label );
						} ) ]
					} )
				)
			) : null,

			// ── Date/time + browse expansion ──
			h( Fragment, null,
			h( 'div', { ref: editDetailsSectionRef, className: 'wca-form-section wca-form-details-section' },
				h( 'div', { className: 'wca-form-row wca-form-datetime-row' + ( 'checking' === availStatus ? ' wca-form-datetime-row--checking' : '' ) + ( 'unavailable' === availStatus ? ' wca-form-datetime-row--unavailable' : '' ), 'aria-busy': 'checking' === availStatus ? 'true' : undefined },
					h( 'div', { className: 'wca-form-datetime-fields' },
						showMonthRange ? h( Fragment, null,
							ti( {
						id: 'wca-edit-month-from',
								label: t( 'month', 'Month' ),
						value: formMonthFrom,
								mod: 'month',
						type: 'month',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						availabilityTouchedRef.current = true;
						setFormMonthFrom( v );
						setFormDate( v + '-01' );
						// Maintain duration
						if ( v && initMonthFrom && initMonthTo ) {
						var d1 = new Date( initMonthFrom + '-01' );
						var d2 = new Date( initMonthTo + '-01' );
						var diff = ( d2.getFullYear() - d1.getFullYear() ) * 12 + ( d2.getMonth() - d1.getMonth() );
						var nextDt = new Date( v + '-01' );
						nextDt.setMonth( nextDt.getMonth() + diff );
						setFormMonthTo( nextDt.getFullYear() + '-' + ( '0' + ( nextDt.getMonth() + 1 ) ).slice( -2 ) );
						}
						}
					} ),
							ti( {
						id: 'wca-edit-month-to',
								label: t( 'to', 'To' ),
						value: formMonthTo,
								mod: 'month',
						type: 'month',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) { availabilityTouchedRef.current = true; setFormMonthTo( e.target.value ); }
					} )
						) : ( ! showTimeFields && ( isAllDay || showDateRange ) ) ? h( Fragment, null,
							ti( {
						id: 'wca-edit-date-from',
								label: t( 'date', 'Date' ),
						value: formDate,
								mod: 'date',
						type: 'date',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						availabilityTouchedRef.current = true;
						selectedSlotStartTsRef.current = 0;
						setFormDate( v );
						setFormDateFrom( v );
						// Maintain duration
						if ( v && initDateFrom && initDateTo ) {
						var d1 = new Date( initDateFrom.replace( /-/g, '/' ) );
						var d2 = new Date( initDateTo.replace( /-/g, '/' ) );
						var diffDays = Math.round( ( d2 - d1 ) / 86400000 );
						var nextDt = new Date( v.replace( /-/g, '/' ) );
						nextDt.setDate( nextDt.getDate() + diffDays );
						var y = nextDt.getFullYear(), m = ( '0' + ( nextDt.getMonth() + 1 ) ).slice( -2 ), d = ( '0' + nextDt.getDate() ).slice( -2 );
						setFormDateTo( y + '-' + m + '-' + d );
						}
						}
					} ),
							ti( {
						id: 'wca-edit-date-to',
								label: t( 'to', 'To' ),
						value: formDateTo,
								mod: 'date',
						type: 'date',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) { availabilityTouchedRef.current = true; setFormDateTo( e.target.value ); }
					} )
						) : ( showTimeFields && endDaysOffset > 0 ) ? h( 'div', { className: 'wca-form-overnight-grid' },
							ti( {
						id: 'wca-edit-date-from',
								label: t( 'date', 'Date' ),
						value: formDate,
								mod: 'date',
						type: 'date',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						availabilityTouchedRef.current = true;
						selectedSlotSiteTimeRef.current = '';
						selectedSlotSiteDateRef.current = '';
						selectedSlotStartTsRef.current = 0;
						setFormDate( v );
						setFormDateFrom( v );
						if ( v && endDaysOffset > 0 ) {
						try {
						var dt = new Date( v.replace( /-/g, '/' ) );
						dt.setDate( dt.getDate() + endDaysOffset );
						setFormDateTo( dt.getFullYear() + '-' + ( '0' + ( dt.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + dt.getDate() ).slice( -2 ) );
						} catch ( _e ) {}
						}
						if ( browseOpen && v && showTimeFields ) { loadDaySlots( v ); }
						}
					} ),
							ti( {
						id: 'wca-edit-time-from',
								label: t( 'from', 'From' ),
						value: formTimeFrom,
								mod: 'time',
						type: 'time',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						availabilityTouchedRef.current = true;
						selectedSlotSiteTimeRef.current = '';
						selectedSlotSiteDateRef.current = '';
						selectedSlotStartTsRef.current = 0;
						setFormTimeFrom( v );
						applyEditDurationToEnd( v );
						}
					} ),
							ti( {
						id: 'wca-edit-date-to',
								label: t( 'endDate', 'End date' ),
								labelAddon: h( 'span', { className: 'wca-overnight-badge', title: t( 'endsNextDay', 'Ends on a different day' ) }, '+' + endDaysOffset + 'd' ),
						value: formDateTo,
								mod: 'date',
						disabled: true,
						type: 'date'
					} ),
							ti( {
						id: 'wca-edit-time-to',
								label: t( 'to', 'To' ),
						value: formTimeTo,
								mod: 'time',
						type: 'time',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) { availabilityTouchedRef.current = true; setFormTimeTo( e.target.value ); setEndDaysOffset( 0 ); }
					} )
						) : h( Fragment, null,
							ti( {
						id: 'wca-edit-date',
								label: t( 'date', 'Date' ),
						value: formDate,
								mod: 'date',
						type: 'date',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) {
						availabilityTouchedRef.current = true;
						selectedSlotStartTsRef.current = 0;
						var v = e.target.value; setFormDate( v );
						if ( browseOpen && v && showTimeFields ) {
						loadDaySlots( v );
						}
						}
					} ),
							showTimeFields ? h( 'div', { className: 'wca-form-time-range' },
								ti( {
						id: 'wca-edit-time-from',
									label: t( 'from', 'From' ),
						value: formTimeFrom,
									mod: 'time',
						type: 'time',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						availabilityTouchedRef.current = true;
						selectedSlotSiteTimeRef.current = '';
						selectedSlotSiteDateRef.current = '';
						selectedSlotStartTsRef.current = 0;
						setFormTimeFrom( v );
						applyEditDurationToEnd( v );
						}
					} ),
							ti( {
						id: 'wca-edit-time-to',
									label: t( 'to', 'To' ),
						value: formTimeTo,
									mod: 'time',
						type: 'time',
						onFocus: openEditBrowseOnFocus,
						onChange: function( e ) { availabilityTouchedRef.current = true; setFormTimeTo( e.target.value ); setEndDaysOffset( 0 ); }
					} )
							) : null
						)
					),
					editTzInfo ? h( 'span', { className: 'wca-tz-badge', 'aria-label': editTzInfo.tooltip, tabIndex: 0 }, editTzInfo.abbr ) : null,
					datetimeAvailStatus( h, availStatus, availMessage, t )
				),
				saveError ? h( 'div', { className: 'wca-edit-error' }, saveError ) : null
			),

			formProductId ? h( 'div', { ref: editBrowseSectionRef, className: 'wca-form-browse-section' },
				! browseOpen ? h( 'button', {
					type: 'button',
					className: 'wca-text-action wca-browse-trigger',
					onClick: openEditBrowseOnFocus
				}, t( 'pickFromCalendar', 'Pick from a calendar' ) ) : null,
				browseOpen ? h( 'div', { className: 'wca-expansion wca-expansion--expanded' },
					formExpansionHeader( h, {
						open: true,
						onOpenChange: function( opening ) {
							setBrowseOpen( !! opening );
						},
						sectionRef: editBrowseSectionRef
					},
						h( 'span', { className: 'wca-expansion__title' }, t( 'pickFromCalendar', 'Pick from a calendar' ) ),
						wpIcon( h, 'chevronUp', 'wca-expansion__action', { title: t( 'close', 'Close' ) } )
					),
					h( 'div', { className: 'wca-expansion__body' },
			h( panelBrowse.BrowsePanel, {
				// State from useBrowseState
				miniCalMonth: miniCalMonth, miniCalData: miniCalData, miniCalLoading: miniCalLoading,
				miniCalExpanded: miniCalExpanded, miniCalStripCenter: miniCalStripCenter,
				slotsData: slotsData, slotsLoading: slotsLoading,
				availStatus: availStatus, availMessage: availMessage,
				// Config
				durationUnit: durationUnit, showTimeFields: showTimeFields,
				showDateRange: showDateRange, showMonthRange: showMonthRange,
				formDate: formDate, formDateFrom: formDateFrom, formMonthFrom: formMonthFrom,
				formTimeFrom: formTimeFrom, formTimeFromSite: selectedSlotSiteTimeRef.current, formStartTs: selectedSlotStartTsRef.current, panelCfg: browsePanelCfg, t: t, idPrefix: 'wca-edit',
				// Action callbacks
				loadMonthAvailability: loadMonthAvailability,
				loadStripAvailability: loadStripAvailability,
				loadDaySlots: loadDaySlots,
				setMiniCalExpanded: setMiniCalExpanded,
				setMiniCalStripCenter: setMiniCalStripCenter,
				// Selection callbacks (Edit-specific: mark touched + maintain duration)
				onDayClick: function( dateStr ) {
					availabilityTouchedRef.current = true;
					selectedSlotStartTsRef.current = 0;
					selectedSlotSiteTimeRef.current = '';
					if ( showTimeFields ) { setFormTimeFrom( '' ); setFormTimeTo( '' ); }
					setFormDate( dateStr );
					setFormDateFrom( dateStr );

					// Maintain duration
					if ( dateStr && initDateFrom && initDateTo ) {
						var d1 = new Date( initDateFrom.replace( /-/g, '/' ) );
						var d2 = new Date( initDateTo.replace( /-/g, '/' ) );
						var diffDays = Math.round( ( d2 - d1 ) / 86400000 );
						var nextDt = new Date( dateStr.replace( /-/g, '/' ) );
						nextDt.setDate( nextDt.getDate() + diffDays );
						var ny = nextDt.getFullYear(), nm = ( '0' + ( nextDt.getMonth() + 1 ) ).slice( -2 ), nd = ( '0' + nextDt.getDate() ).slice( -2 );
						setFormDateTo( ny + '-' + nm + '-' + nd );
					}
				},
				onMonthClick: function( monthStr ) {
					availabilityTouchedRef.current = true;
					setFormMonthFrom( monthStr );
					setFormDate( monthStr + '-01' );
					// Maintain duration
					if ( monthStr && initMonthFrom && initMonthTo ) {
						var d1 = new Date( initMonthFrom + '-01' );
						var d2 = new Date( initMonthTo + '-01' );
						var diff = ( d2.getFullYear() - d1.getFullYear() ) * 12 + ( d2.getMonth() - d1.getMonth() );
						var nextDt = new Date( monthStr + '-01' );
						nextDt.setMonth( nextDt.getMonth() + diff );
						setFormMonthTo( nextDt.getFullYear() + '-' + ( '0' + ( nextDt.getMonth() + 1 ) ).slice( -2 ) );
					}
				},
				onSlotClick: function( chipTime, slotStartTs, adminTime, adminDate ) {
					availabilityTouchedRef.current = true;
					selectedSlotSiteTimeRef.current = chipTime;
					var sst = parseInt( slotStartTs, 10 );
					selectedSlotStartTsRef.current = sst > 86400 ? sst : 0;
					if ( utils && utils.tsToNaiveLocalDate && sst > 86400 ) {
						selectedSlotSiteDateRef.current = utils.tsToNaiveLocalDate( sst );
					}
					var timeToSet = adminTime || chipTime;
					var dateToSet = adminDate || formDate;
					selectedSlotAdminDateRef.current = dateToSet || formDate || '';

					var updates = { timeFrom: timeToSet };
					if ( dateToSet !== formDate ) {
						updates.date = dateToSet;
					}

					// Compute end time based on original duration
					if ( timeToSet && originalDurationMin ) {
						var p = String( timeToSet ).split( ':' );
						var sh = parseInt( p[ 0 ], 10 );
						var sm = parseInt( p[ 1 ] || 0, 10 );
						if ( ! isNaN( sh ) && ! isNaN( sm ) ) {
							var sMin = ( sh * 60 ) + sm;
							var eMin = sMin + originalDurationMin;
							var eDisp = ( ( eMin % 1440 ) + 1440 ) % 1440;
							updates.timeTo = ( '0' + Math.floor( eDisp / 60 ) ).slice( -2 ) + ':' + ( '0' + ( eDisp % 60 ) ).slice( -2 );
							var offset = Math.floor( eMin / 1440 );
							setEndDaysOffset( offset );
							if ( offset > 0 ) {
								var dt = new Date( dateToSet.replace( /-/g, '/' ) );
								dt.setDate( dt.getDate() + offset );
								updates.dateTo = dt.getFullYear() + '-' + ( '0' + ( dt.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + dt.getDate() ).slice( -2 );
							} else {
								updates.dateTo = dateToSet;
							}
						}
					}
					_f.setFields( updates );
				}
			} )
				)
			) : null
			) : null
			),

			seriesScopeNode,

			// ── Customer + attendance (2/3 + 1/3) ──
			h( 'div', { className: 'wca-form-section wca-form-customer-section' },
				h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-edit-customer',
						label: t( 'customer', 'Customer' ),
						// Select2 owns this <select> (initAjaxSelect). Uncontrolled only —
						// do not pass React `value` or the field becomes read-only / dual-mode.
						forceActive: !! formCustomerId,
						mod: 'two-thirds',
						tag: 'select',
						controlClass: 'wca-field__control wc-customer-search',
						ref: editCustomerSelectRef,
						defaultValue: formCustomerId || '',
						children: [ formCustomerId
							? h( 'option', { key: String( formCustomerId ), value: formCustomerId }, customerSearch || ( '#' + formCustomerId ) )
							: h( 'option', { key: '', value: '' }, '' ) ]
					} ),
					ti( {
						id: 'wca-edit-attendance',
						label: t( 'customerStatus', 'Attendance' ),
						value: customerStatus,
						mod: 'one-third',
						tag: 'select',
						onChange: function( e ) { setCustomerStatus( e.target.value ); },
						children: [ h( 'option', { key: 'expected', value: 'expected' }, t( 'expected', 'Expected' ) ),
						h( 'option', { key: 'arrived', value: 'arrived' }, t( 'arrived', 'Arrived' ) ),
						h( 'option', { key: 'no-show', value: 'no-show' }, t( 'noShow', 'No-show' ) ) ]
					} )
				)
			),

			// ── Add-ons (read-only from order) ──
			addons.length ? h( 'div', { className: 'wca-addons-card' },
				h( 'div', { className: 'wca-addons-card__title' }, t( 'addons', 'Add-ons' ) ),
				renderAddonsBlock( addons )
			) : null,

			// Status section (segmented + more, same positioning as view panel)
			editStatusSectionNode,

			( seriesBundle && window.panelSeries && window.panelSeries.SeriesFooterBlock )
				? h( window.panelSeries.SeriesFooterBlock, { key: 'wca-series-footer', appt: appt, h: h, bundle: seriesBundle } )
				: null
			),
			editFooter
		);
	}

	// Compact deposit schedule hint fits the expansion header aside (plain text, short).
	function wcaDepositsHintFitsHeaderAside( html ) {
		if ( ! html || 'string' !== typeof html ) {
			return false;
		}
		var text = html.replace( /<[^>]+>/g, '' ).replace( /\s+/g, ' ' ).trim();
		return 100 >= text.length && ( ( html.match( /<\/p>/gi ) || [] ).length <= 1 );
	}

	// ─── CreateContent Component ─────────────────────────────────

	function CreateContent( props ) {
		var prefill    = props.prefill || {};
		var callbacks  = props.callbacks || {};
		var products   = props.products || [];
		var onCancel   = props.onCancel || function() {};
		var onCreated  = props.onCreated || function() {};
		var onOpenEditInline = props.onOpenEditInline || function() {};

		var utils = window.WCAppointmentsTimezoneUtils;
		var ajaxUrl = cfg.ajaxUrl || '';
		var nonces  = cfg.ajaxNonces || {};
		var canViewOrders = !!cfg.canViewOrders;

		// ── Pre-fill values from calendar click ──
		var prefillDate = '';
		var prefillTimeFrom = '';
		var prefillTimeTo = '';
		var prefillEndDate = '';
		if ( prefill.startTs ) {
			// Use formatInputDate/formatInputTime (getHours() — browser local) so the prefilled
			// time matches what the admin saw on the calendar. The calendar feeds FullCalendar
			// ISO strings in admin-TZ format (no suffix); FullCalendar parses them as local
			// browser time, so info.date.getTime() returns a real-UTC value and getHours()
			// correctly recovers the displayed hour. tsToAdminLocalISO would incorrectly
			// add a (adminOffset − siteOffset) shift on top of that real-UTC value, showing
			// a wrong time. This mirrors the fix already applied to the creation form's
			// prefillSelectedRange → formatInputDate / formatInputTime path.
			if ( utils && utils.formatInputDate && utils.formatInputTime ) {
				prefillDate     = utils.formatInputDate( prefill.startTs );
				prefillTimeFrom = utils.formatInputTime( prefill.startTs );
			} else {
				var psd = new Date( prefill.startTs * 1000 );
				prefillDate     = psd.getFullYear() + '-' + ( psd.getMonth() + 1 < 10 ? '0' : '' ) + ( psd.getMonth() + 1 ) + '-' + ( psd.getDate() < 10 ? '0' : '' ) + psd.getDate();
				prefillTimeFrom = ( psd.getHours() < 10 ? '0' : '' ) + psd.getHours() + ':' + ( psd.getMinutes() < 10 ? '0' : '' ) + psd.getMinutes();
			}
		}
		if ( prefill.endTs ) {
			// For all-day calendar selections, endTs is FullCalendar's exclusive end
			// (midnight of the day AFTER the last selected day). Convert to inclusive
			// end date by subtracting one day so the form shows the correct last day
			// and the preview builder's addOneDay() produces the right exclusive end.
			var endTsForDate = prefill.endTs;
			if ( prefill.allDay && endTsForDate ) {
				endTsForDate = endTsForDate - 86400;
			}
			if ( utils && utils.formatInputDate && utils.formatInputTime ) {
				prefillTimeTo   = utils.formatInputTime( prefill.endTs );
				prefillEndDate  = utils.formatInputDate( endTsForDate );
			} else {
				var pedTime = new Date( prefill.endTs * 1000 );
				prefillTimeTo   = ( pedTime.getHours() < 10 ? '0' : '' ) + pedTime.getHours() + ':' + ( pedTime.getMinutes() < 10 ? '0' : '' ) + pedTime.getMinutes();
				var ped = new Date( endTsForDate * 1000 );
				prefillEndDate  = ped.getFullYear() + '-' + ( ped.getMonth() + 1 < 10 ? '0' : '' ) + ( ped.getMonth() + 1 ) + '-' + ( ped.getDate() < 10 ? '0' : '' ) + ped.getDate();
			}
		}

		// If start and end times are identical (e.g. allDay click where both are '00:00'),
		// clear the end time so the auto-compute effect applies product duration instead.
		if ( prefillTimeTo && prefillTimeFrom && prefillTimeTo === prefillTimeFrom ) {
			prefillTimeTo = '';
		}
		// Calendar date-only picks (month click or all-day): midnight is not a chosen slot — pick first available time.
		if ( prefillDate && panelHelpers.isDateOnlyTimePlaceholder( prefillTimeFrom ) ) {
			prefillTimeFrom = '';
		}

		// ── Form state (shared hook) ──
		var _f = panelForm.useAppointmentForm( {
			date: prefillDate, timeFrom: prefillTimeFrom, timeTo: prefillTimeTo,
			dateFrom: prefillDate, dateTo: prefillEndDate || '',
			monthFrom: prefillDate ? prefillDate.substring( 0, 7 ) : '',
			monthTo: prefillEndDate ? prefillEndDate.substring( 0, 7 ) : '',
			staffIds: prefill.staffId ? [ String( prefill.staffId ) ] : [],
			locationId: '',
			resourceId: '',
			status: cfg.defaultCreateStatus || 'confirmed', customerId: '', customerSearch: '',
			qty: 1,
			productId: prefill.productId ? String( prefill.productId ) : ''
		} );
		var productId       = _f.form.productId;
		var formDate        = _f.form.date;
		var formTimeFrom    = _f.form.timeFrom;
		var formTimeTo      = _f.form.timeTo;
		var formDateFrom    = _f.form.dateFrom;
		var formDateTo      = _f.form.dateTo;
		var formMonthFrom   = _f.form.monthFrom;
		var formMonthTo     = _f.form.monthTo;
		var staffId         = _f.form.staffIds[ 0 ] || '';
		var locationId      = _f.form.locationId || '';
		var resourceId      = _f.form.resourceId || '';
		var customerId      = _f.form.customerId;
		var customerSearch  = _f.form.customerSearch;
		var formStatus      = _f.form.status;
		var formQty         = _f.form.qty;
		var setFormDate        = function( v ) { _f.setField( 'date', v ); };
		var setFormTimeFrom    = function( v ) { _f.setField( 'timeFrom', v ); };
		var setFormTimeTo      = function( v ) { _f.setField( 'timeTo', v ); };
		var setFormDateFrom    = function( v ) { _f.setField( 'dateFrom', v ); };
		var setFormDateTo      = function( v ) { _f.setField( 'dateTo', v ); };
		var setFormMonthFrom   = function( v ) { _f.setField( 'monthFrom', v ); };
		var setFormMonthTo     = function( v ) { _f.setField( 'monthTo', v ); };
		var setStaffId         = function( v ) { _f.setField( 'staffIds', v ? [ v ] : [] ); };
		var setLocationId      = function( v ) { _f.setField( 'locationId', v || '' ); };
		var setResourceId      = function( v ) { _f.setField( 'resourceId', v || '' ); };
		var setCustomerId      = function( v ) { _f.setField( 'customerId', v ); };
		var setCustomerSearch  = function( v ) { _f.setField( 'customerSearch', v ); };
		var setFormStatus      = function( v ) { _f.setField( 'status', v ); };
		var setFormQty         = function( v ) { _f.setField( 'qty', v ); };
		var [ productDetails, setProductDetails ] = useState( null );
		var [ productName, setProductName ]       = useState( '' );
		var [ orderType, setOrderType ]         = useState( 'new' );
		var [ existingOrderId, setExistingOrderId ] = useState( '' );
		var [ orderSearch, setOrderSearch ]     = useState( '' );
		var [ detailsOpen, setDetailsOpen ]     = useState( false );
		var [ billing, setBilling ]             = useState( { first_name: '', last_name: '', company: '', address_1: '', address_2: '', city: '', postcode: '', country: '', state: '', email: '', phone: '', timezone: '', payment_method: '', transaction_id: '' } );
		var [ createAccount, setCreateAccount ] = useState( false );
		var [ isSubmitting, setIsSubmitting ]   = useState( false );
		var [ submitError, setSubmitError ]     = useState( '' );
		var [ successData, setSuccessData ]     = useState( null );
		var [ calculatedCost, setCalculatedCost ] = useState( '' );
		var [ calculatedCostRaw, setCalculatedCostRaw ] = useState( 0 );
		var [ calculatedCostRawFull, setCalculatedCostRawFull ] = useState( 0 );
		var [ costDepositApplied, setCostDepositApplied ] = useState( false );
		var [ overridePrice, setOverridePrice ] = useState( '' );
		var [ priceEditing, setPriceEditing ] = useState( false );
		var [ priceEditValue, setPriceEditValue ] = useState( '' );
		var priceInputRef = useRef( null );
		var [ wcDepositOption, setWcDepositOption ] = useState( 'no' );
		var [ wcDepositPlanId, setWcDepositPlanId ] = useState( '' );

		// ── Recurring series (UI in panel-series.js); null = off, object = on ──
		var [ recurringMeta, setRecurringMeta ] = useState( null );
		var recurringOn = null !== recurringMeta;

		// ── Browse state (shared hook) ──
		var _b = panelForm.useBrowseState();
		var browseOpen          = _b.browseOpen;
		var setBrowseOpen       = _b.setBrowseOpen;
		var miniCalMonth        = _b.miniCalMonth;
		var setMiniCalMonth     = _b.setMiniCalMonth;
		var miniCalData         = _b.miniCalData;
		var setMiniCalData      = _b.setMiniCalData;
		var miniCalLoading      = _b.miniCalLoading;
		var setMiniCalLoading   = _b.setMiniCalLoading;
		var miniCalExpanded     = _b.miniCalExpanded;
		var setMiniCalExpanded  = _b.setMiniCalExpanded;
		var miniCalStripCenter  = _b.miniCalStripCenter;
		var setMiniCalStripCenter = _b.setMiniCalStripCenter;
		var slotsData           = _b.slotsData;
		var setSlotsData        = _b.setSlotsData;
		var slotsLoading        = _b.slotsLoading;
		var setSlotsLoading     = _b.setSlotsLoading;
		var availStatus         = _b.availStatus;
		var setAvailStatus      = _b.setAvailStatus;
		var availMessage        = _b.availMessage;
		var setAvailMessage     = _b.setAvailMessage;
		var availXHRRef         = _b.refs.availXHR;
		var availTimerRef       = _b.refs.availTimer;
		var availCheckGenRef    = _b.refs.availCheckGen;
		/** { immediate, silent } flags consumed by the availability effect. */
		var createAvailScheduleRef = useRef( { immediate: false, silent: false } );
		/** Dedupes identical in-flight availability checks (avoids abort/restart stacks). */
		var createAvailInFlightKeyRef = useRef( '' );
		var createDetailsFetchGenRef = useRef( 0 );
		var addonsXHRRef = useRef( null );
		/** Last site date requested for day-slots auto-pick (avoids '' ↔ '00:00' reload loops). */
		var createSlotsLoadDateRef = useRef( '' );
		// ── Create-specific state ──
		var [ addonsHtml, setAddonsHtml ]         = useState( '' );
		var [ addonsOpen, setAddonsOpen ]         = useState( false );
		var [ addonsLoading, setAddonsLoading ]   = useState( false );
		var [ hasRequiredAddons, setHasRequiredAddons ] = useState( false );
		var [ addonsError, setAddonsError ] = useState( '' );
		var [ addonsCost, setAddonsCost ] = useState( 0 );
		var [ addonsDuration, setAddonsDuration ] = useState( 0 );
		var [ endDaysOffset, setEndDaysOffset ] = useState( 0 );
		var addonsContainerRef = useRef( null );
		var checkAddonsValidRef = useRef( null );
		var paoFormRef = useRef( null );
		var paoSilentRef = useRef( false );
		var addonsInjectedRef  = useRef( '' );
		var addonsCacheRef     = useRef( {} );
		var costXHRRef         = useRef( null );
		var costTimerRef       = useRef( null );
		// Latest customer for cost quotes: select2 onSelect closes over fetchCustomerBilling from
		// an older render; its finally must not re-quote as guest after a member was selected.
		var customerIdRef      = useRef( customerId );
		customerIdRef.current  = customerId;
		var productSelectRef   = useRef( null );
		var staffSelectRef        = useRef( null );
		var locationSelectRef     = useRef( null );
		var resourceSelectRef     = useRef( null );
		var orderTypeSelectRef            = useRef( null );
		var existingOrderSelectRef = useRef( null );
		var customerSelectRef      = useRef( null );
		var paymentSelectRef           = useRef( null );
		var billingCountrySelectRef    = useRef( null );
		var billingStateSelectRef      = useRef( null );
		var timezoneSelectRef          = useRef( null );
		var customerDetailsRef         = useRef( null );
		var addonsSectionRef      = useRef( null );
		var onCurrencyAppliedRef  = useRef( function() {} );
		var integrationCurrency   = panelForm.useIntegrationCurrency( {
			cfg: cfg.integrationCurrency,
			fallbackCurrency: calCfg.currency || '',
			ajaxUrl: ajaxUrl,
			productId: productId,
			onApplied: function() { onCurrencyAppliedRef.current(); },
			t: t,
			wpIcon: wpIcon,
			h: h
		} );
		// Initialize with site-TZ time from prefilled admin strings so slot chips
		// highlight correctly on initial load when admin TZ differs from site TZ.
		var initSiteTime = '';
		var initSiteDate = '';
		var initSiteTs   = 0;
		if ( utils && utils.convertAdminStringsToSiteTimezone && prefillDate && prefillTimeFrom ) {
			var conv = utils.convertAdminStringsToSiteTimezone( prefillDate, prefillTimeFrom );
			initSiteTime = conv.time;
			initSiteDate = conv.date;
			if ( initSiteTime && initSiteDate ) {
				var dP = initSiteDate.split( '-' );
				var tP = initSiteTime.split( ':' );
				initSiteTs = Date.UTC( parseInt( dP[ 0 ], 10 ), parseInt( dP[ 1 ], 10 ) - 1, parseInt( dP[ 2 ], 10 ), parseInt( tP[ 0 ], 10 ), parseInt( tP[ 1 ] || 0, 10 ) ) / 1000;
			}
		}
		var selectedSlotSiteTimeRef = useRef( initSiteTime );
		var selectedSlotSiteDateRef = useRef( initSiteDate );
		var slotStartTsRef = useRef( initSiteTs || 0 );
		var selectedSlotAdminDateRef = useRef( prefillDate || '' );
		var slotStartTsState = useState( initSiteTs || 0 );
		var slotStartTs = slotStartTsState[ 0 ];
		function patchSlotStartTs( ts ) {
			var v = parseInt( ts, 10 ) || 0;
			slotStartTsRef.current = v > 86400 ? v : 0;
			slotStartTsState[ 1 ]( slotStartTsRef.current );
		}
		/** Clear times (+ optional field updates) when slot query context changes. */
		function clearCreateTimes( extras ) {
			var u = { timeFrom: '', timeTo: '' };
			if ( extras ) {
				for ( var k in extras ) { u[ k ] = extras[ k ]; }
			}
			_f.setFields( u );
			patchSlotStartTs( 0 );
			selectedSlotSiteTimeRef.current = '';
			createSlotsLoadDateRef.current = '';
		}
		// Staff/room change invalidates times from the previous slot query.
		setStaffId = function( v ) {
			var next = v ? String( v ) : '';
			if ( next === String( ( _f.form.staffIds && _f.form.staffIds[ 0 ] ) || '' ) ) {
				return;
			}
			clearCreateTimes( { staffIds: next ? [ next ] : [] } );
		};
		setResourceId = function( v ) {
			var next = v || '';
			if ( String( next ) === String( _f.form.resourceId || '' ) ) {
				return;
			}
			clearCreateTimes( { resourceId: next } );
		};
		// Write-site product change: clear schedule + browse memory in the same write.
		// productIdRef: select2 handler is captured once (options.length), so closed-over productId stays stale.
		var productIdRef = useRef( productId );
		productIdRef.current = productId;
		function setProductId( v ) {
			var next = v ? String( v ) : '';
			var prev = productIdRef.current ? String( productIdRef.current ) : '';
			if ( prev && next && prev !== next ) {
				patchSlotStartTs( 0 );
				selectedSlotSiteTimeRef.current = '';
				selectedSlotSiteDateRef.current = '';
				selectedSlotAdminDateRef.current = '';
				createSlotsLoadDateRef.current = '';
				_b.invalidateBrowse();
				setMiniCalStripCenter( '' );
				setAvailStatus( '' );
				setAvailMessage( '' );
				_f.setFields( {
					productId: next,
					staffIds: [],
					date: '', timeFrom: '', timeTo: '',
					dateFrom: '', dateTo: '',
					monthFrom: '', monthTo: ''
				} );
				return;
			}
			_f.setField( 'productId', next );
		}
		var createSlotRefs = {
			siteTimeRef: selectedSlotSiteTimeRef,
			siteDateRef: selectedSlotSiteDateRef,
			startTsRef: slotStartTsRef,
			adminDateRef: selectedSlotAdminDateRef
		};

		// ── Product options from preloaded products ──
		var productOptions = panelHelpers.productSelectOptions( products, productId, productName );

		// Billing: WC country/state maps for native <option>s + selectWoo (same as payment method).
		var billingCountriesMap = cfg.billingCountries || {};
		var billingCountryCodesList = Object.keys( billingCountriesMap );
		var billingStatesCfg = cfg.billingStates || {};
		var billingStatesForCountry = billing.country && billingStatesCfg[ billing.country ] ? billingStatesCfg[ billing.country ] : null;
		var billingStateKeys = billingStatesForCountry && 'object' === typeof billingStatesForCountry ? Object.keys( billingStatesForCountry ) : [];
		var billingStateIsDropdown = billingStateKeys.length > 0;

		// ── Fetch product details when product changes ──
		function findCreatePreloadRow( pid ) {
			if ( ! pid || ! products.length ) { return null; }
			for ( var i = 0; i < products.length; i++ ) {
				if ( products[ i ] && String( products[ i ].id ) === String( pid ) ) {
					return products[ i ];
				}
			}
			return null;
		}
		function fetchCreateProductDetails( pid ) {
			if ( ! pid || ! ajaxUrl ) { return; }
			var gen = ++createDetailsFetchGenRef.current;
			var fd = new FormData();
			fd.append( 'action', 'wc_appointments_get_product_details' );
			fd.append( 'nonce', nonces.getProductDetails || '' );
			fd.append( 'product_id', pid );
			fetch( ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' } )
				.then( function( r ) { return r.json(); } )
				.then( function( resp ) {
					if ( gen !== createDetailsFetchGenRef.current ) { return; }
					if ( resp && resp.success ) {
						setProductDetails( resp.data || null );
					}
				} )
				.catch( function() {} );
		}
		useEffect( function() {
			setAvailStatus( '' );
			setAvailMessage( '' );
			setRecurringMeta( null );
			createAvailScheduleRef.current = { immediate: false, silent: false };
			createSlotsLoadDateRef.current = '';
			createAvailInFlightKeyRef.current = '';
			createDetailsFetchGenRef.current += 1;
			if ( availCheckGenRef ) { availCheckGenRef.current += 1; }
			if ( ! productId || ! ajaxUrl ) {
				setProductDetails( null );
				setCalculatedCost( '' );
				setCalculatedCostRaw( 0 );
				return;
			}
			var preload = findCreatePreloadRow( productId );
			// Seed from preload so UI/avail/browse can run without waiting on get_product_details.
			if ( preload ) {
				setProductDetails( {
					product_id: String( productId ),
					has_time: !! preload.has_time,
					duration_unit: preload.duration_unit || '',
					duration: preload.duration || 1,
					has_addons: !! preload.has_addons,
					has_staff: !! preload.has_staff,
					staff_assignment: preload.staff_assignment || 'customer',
					staff: preload.staff || {},
					has_locations: !! preload.has_locations,
					location_mode: preload.location_mode || 'none',
					location_label: preload.location_label || '',
					locations: preload.locations || {},
					location_costs: preload.location_costs || {},
					has_resources: !! preload.has_resources,
					resource_assignment: preload.resource_assignment || 'display',
					resource_label: preload.resource_label || '',
					resources: preload.resources || {}
				} );
				// Always fetch live details after seed; preload can omit has_resources.
				fetchCreateProductDetails( productId );
				return;
			}
			setProductDetails( null );
			fetchCreateProductDetails( productId );
		}, [ productId ] );


		// WooCommerce Deposits: reset choice when product details load (matches storefront defaults).
		useEffect( function() {
			if ( ! productDetails || ! productDetails.wc_deposits ) {
				setWcDepositOption( 'no' );
				setWcDepositPlanId( '' );
				return;
			}
			var wd = productDetails.wc_deposits;
			if ( wd.forced ) {
				setWcDepositOption( 'yes' );
			} else if ( wd.default_option === 'deposit' ) {
				setWcDepositOption( 'yes' );
			} else {
				setWcDepositOption( 'no' );
			}
			if ( wd.plans && wd.plans.length ) {
				setWcDepositPlanId( String( wd.plans[ 0 ].id ) );
			} else {
				setWcDepositPlanId( '' );
			}
		}, [ productDetails ] );

		// Re-quote footer when deposit choice or plan changes (must match create_appointment totals).
		useEffect( function() {
			if ( ! productId || ! productDetails || recurringOn ) {
				return;
			}
			scheduleCalculateCost();
		}, [ wcDepositOption, wcDepositPlanId, recurringOn ] );

		function wcaPanelPayDepositSelected() {
			if ( ! productDetails || ! productDetails.wc_deposits ) {
				return false;
			}
			return productDetails.wc_deposits.forced || 'yes' === wcDepositOption;
		}

		var prevPayDepositRef = useRef( false );

		// Deposit due is derived from product deposit rules (same as storefront). Do not keep a custom full-price override while paying deposit.
		useEffect( function() {
			var payDeposit = wcaPanelPayDepositSelected();
			if ( prevPayDepositRef.current && ! payDeposit ) {
				setOverridePrice( '' );
				setPriceEditValue( '' );
				setPriceEditing( false );
			}
			if ( payDeposit && ( overridePrice || priceEditing ) ) {
				setOverridePrice( '' );
				setPriceEditValue( '' );
				setPriceEditing( false );
			}
			prevPayDepositRef.current = payDeposit;
		}, [ wcDepositOption, productDetails ] );

		// Clear invalid staff; auto-select logged-in / default staff when assigned and empty.
		useEffect( function() {
			if ( ! productDetails ) { return; }
			if ( ! productDetails.has_staff ) {
				if ( _f.form.staffIds.length ) {
					_f.setField( 'staffIds', [] );
				}
				return;
			}
			var map = productDetails.staff || {};
			var cur = _f.form.staffIds[ 0 ] || '';
			if ( cur && ! map[ String( cur ) ] ) {
				_f.setField( 'staffIds', [] );
				cur = '';
			}
			if ( cur ) { return; }
			var cal = window.wcAppointmentsReactCalendar;
			var uid = cal && cal.current_user && cal.current_user.id;
			var def = productDetails.default_staff_id ? String( productDetails.default_staff_id ) : '';
			var pick = ( def && map[ def ] ) ? def : ( uid && map[ String( uid ) ] ? String( uid ) : '' );
			if ( pick ) {
				_f.setField( 'staffIds', [ pick ] );
			}
		}, [ productDetails ] );

		// Location allow-list sync (fixed or a single listed location auto-selects).
		useEffect( function() {
			if ( ! productDetails ) { return; }
			if ( ! productDetails.has_locations ) {
				if ( _f.form.locationId ) { _f.setField( 'locationId', '' ); }
				return;
			}
			var map = productDetails.locations || {};
			var keys = Object.keys( map );
			if ( ! keys.length ) { return; }
			if ( 'fixed' === productDetails.location_mode || 'hidden' === productDetails.location_mode || 1 === keys.length ) {
				if ( _f.form.locationId !== keys[ 0 ] ) { _f.setField( 'locationId', keys[ 0 ] ); }
				return;
			}
			if ( _f.form.locationId && ! map[ _f.form.locationId ] ) {
				_f.setField( 'locationId', '' );
			}
		}, [ productDetails ] );

		// Resource pool sync (location-filtered); single option auto-selects.
		useEffect( function() {
			if ( ! productDetails ) { return; }
			if ( ! productDetails.has_resources ) {
				if ( _f.form.resourceId ) { _f.setField( 'resourceId', '' ); }
				return;
			}
			var map = productDetails.resources || {};
			var loc = _f.form.locationId || '';
			var locInt = loc ? parseInt( loc, 10 ) : 0;
			var keys = Object.keys( map ).filter( function( rid ) {
				var row = map[ rid ];
				if ( ! row ) { return false; }
				var rLoc = parseInt( row.location_id, 10 ) || 0;
				if ( locInt && rLoc !== locInt ) { return false; }
				return true;
			} );
			var cur = _f.form.resourceId || '';
			if ( cur && -1 === keys.indexOf( String( cur ) ) ) {
				setResourceId( '' );
				cur = '';
			}
			if ( ! cur && 1 === keys.length ) {
				setResourceId( keys[ 0 ] );
			}
		}, [ productDetails, locationId ] );

		// ── Field visibility: fetched details, else preload duration shape ──
		var preloadRow = findCreatePreloadRow( productId );
		var detailsLive = productDetails && String( productDetails.product_id || '' ) === String( productId );
		var hasTime = detailsLive ? !! productDetails.has_time : ( preloadRow ? !! preloadRow.has_time : true );
		var durationUnit = detailsLive ? ( productDetails.duration_unit || '' ) : ( ( preloadRow && preloadRow.duration_unit ) || '' );
		var productDuration = detailsLive ? ( productDetails.duration || 1 ) : ( ( preloadRow && preloadRow.duration ) || 1 );
		// Preload decides Staff/Add-ons visibility on first paint (no late reveal).
		var hasAddons = preloadRow ? !! preloadRow.has_addons : !!( detailsLive && productDetails.has_addons );
		var hasStaff = preloadRow ? !! preloadRow.has_staff : !!( detailsLive && productDetails.has_staff );
		var hasLocations = preloadRow ? !! preloadRow.has_locations : !!( detailsLive && productDetails.has_locations );
		var locationMode = ( detailsLive && productDetails.location_mode ) || ( preloadRow && preloadRow.location_mode ) || '';
		var locationMap = ( detailsLive && productDetails.locations ) || ( preloadRow && preloadRow.locations ) || {};
		var locationCosts = ( detailsLive && productDetails.location_costs ) || ( preloadRow && preloadRow.location_costs ) || {};
		var locationLabel = ( detailsLive && productDetails.location_label ) || ( preloadRow && preloadRow.location_label ) || t( 'location', 'Location' );
		var locationPickRequired = hasLocations && 'customer_choice' === locationMode && Object.keys( locationMap || {} ).length > 1 && ! locationId;
		// Preload or live details (OR): preload can omit has_resources.
		var hasResources = !!( ( preloadRow && preloadRow.has_resources ) || ( detailsLive && productDetails.has_resources ) );
		var resourceMap = {};
		if ( detailsLive && productDetails.resources && Object.keys( productDetails.resources ).length ) {
			resourceMap = productDetails.resources;
		} else if ( preloadRow && preloadRow.resources ) {
			resourceMap = preloadRow.resources;
		}
		var resourceLabel = ( detailsLive && productDetails.resource_label ) || ( preloadRow && preloadRow.resource_label ) || t( 'resources', 'Resources' );
		var createOptCurrency = ( window.wcaPanel && window.wcaPanel.currency ) || calCfg.currency || '';
		var createResourceOptions = [];
		if ( hasResources ) {
			Object.keys( resourceMap ).forEach( function( rid ) {
				var row = resourceMap[ rid ];
				if ( ! row ) { return; }
				var rLoc = parseInt( row.location_id, 10 ) || 0;
				// Once a venue is chosen, match PHP is_available_at_location (exact location_id).
				if ( locationId && rLoc !== parseInt( locationId, 10 ) ) { return; }
				createResourceOptions.push( {
					value: String( rid ),
					label: ( row.title || String( rid ) ) + additionalCostSuffix( row.cost, createOptCurrency )
				} );
			} );
		}
		function onCreateLocationChange( v ) {
			var next = v || '';
			if ( String( next ) === String( locationId || '' ) ) { return; }
			// Keep civil date(s); only times need a re-pick for the new venue.
			clearCreateTimes( { locationId: next, resourceId: '', staffIds: [] } );
			_b.invalidateBrowse();
			setBrowseOpen( false );
			setAvailStatus( '' );
			setAvailMessage( '' );
		}
		var showTimeFields = hasTime && 'day' !== durationUnit && 'night' !== durationUnit && 'month' !== durationUnit;
		var showDateRange = 'day' === durationUnit;
		var showMonthRange = 'month' === durationUnit;
		var resourceAssignment = ( detailsLive && productDetails.resource_assignment ) || ( preloadRow && preloadRow.resource_assignment ) || '';
		// Customer must pick a room when the filtered pool has options (same gate as location pick).
		var createResourcePickRequired = hasResources && 'customer' === resourceAssignment
			&& createResourceOptions.length > 0 && ! resourceId;
		// Wait for venue / room before loading hours (avoids 00:00 from an empty-context 24/7 list).
		var slotsContextPending = locationPickRequired || createResourcePickRequired;
		useEffect( function() {
			if ( slotsContextPending && browseOpen ) {
				setBrowseOpen( false );
			}
		}, [ slotsContextPending ] );
		function createAwaitingSlotPick() {
			return showTimeFields && ! showDateRange && ! showMonthRange && formDate
				&& panelHelpers.isDateOnlyTimePlaceholder( formTimeFrom, slotStartTsRef.current );
		}
		var createTimeLocked = !!( slotsLoading || createAwaitingSlotPick() || slotsContextPending );

		function resolveCreateTimed( forFetch, clearStale ) {
			return resolveTimedAvailParams( {
				siteTimeRef: createSlotRefs.siteTimeRef,
				siteDateRef: createSlotRefs.siteDateRef,
				startTsRef: createSlotRefs.startTsRef,
				adminDateRef: createSlotRefs.adminDateRef,
				formSiteDate: formDate,
				formDate: formDate,
				formTimeFrom: formTimeFrom,
				formTimeTo: formTimeTo,
				showTimeFields: showTimeFields,
				forFetch: forFetch,
				clearStale: clearStale
			} );
		}

		function buildCreateAvailParams( forFetch ) {
			var params = {
				productId: productId,
				staffId: staffId || '',
				locationId: locationId || '',
				resourceId: resourceId || '',
				qty: formQty,
				showTimeFields: showTimeFields,
				addonsDuration: addonsDuration || 0
			};
			if ( showDateRange ) {
				params.dateFrom = formDateFrom;
				params.dateTo = formDateTo;
				params.timeFrom = formTimeFrom;
				params.timeTo = formTimeTo;
			} else if ( showMonthRange ) {
				params.monthFrom = formMonthFrom;
				params.monthTo = formMonthTo;
				params.timeFrom = formTimeFrom;
				params.timeTo = formTimeTo;
			} else {
				assignResolvedTimedParams( params, resolveCreateTimed( forFetch, forFetch ) );
			}
			return params;
		}

		function markCreateSlotAvailable( pickedTime ) {
			if ( showTimeFields && ( ! pickedTime || panelHelpers.isDateOnlyTimePlaceholder( pickedTime, slotStartTsRef.current ) ) ) {
				return;
			}
			setAvailMessage( '' );
			setAvailStatus( 'available' );
			createAvailScheduleRef.current = { immediate: true, silent: true };
		}

		// ── Staff options (preload seed or live details; never the global staff list) ──
		var staffMap = ( detailsLive && productDetails.staff ) || ( preloadRow && preloadRow.staff ) || {};
		var staffKeys = ( staffMap && 'object' === typeof staffMap ) ? Object.keys( staffMap ) : [];
		var staffOptions = staffKeys.map( function( sid ) {
			return { value: String( sid ), label: staffMap[ sid ] || ( '#' + sid ) };
		} );
		var staffNames = staffKeys.map( function( sid ) { return staffMap[ sid ] || ( '#' + sid ); } );
		var assignmentType = ( detailsLive && productDetails.staff_assignment ) || ( preloadRow && preloadRow.staff_assignment ) || 'customer';
		var isAllStaff = 'all' === assignmentType;

		// ── Browse data loading (delegated to panelHelpers action wrappers) ──
		function abortPanelAjax( ref ) {
			if ( ref.current && ref.current.abort ) {
				try { ref.current.abort(); } catch ( e ) {}
				ref.current = null;
			}
		}
		function loadMonthAvailability( yearMonth ) {
			abortPanelAjax( costXHRRef );
			panelHelpers.loadMonthAvail( ajaxUrl, nonces, {
				productId: productId, staffId: staffId || '', locationId: locationId || '', resourceId: resourceId || '', qty: formQty, yearMonth: yearMonth,
				date: showTimeFields ? ( formDate || '' ) : '',
				showTimeFields: showTimeFields
			}, _b );
		}
		function loadStripAvailability( centerYMD ) {
			abortPanelAjax( costXHRRef );
			panelHelpers.loadStripAvail( ajaxUrl, nonces, {
				productId: productId, staffId: staffId || '', locationId: locationId || '', resourceId: resourceId || '', qty: formQty, centerYMD: centerYMD,
				firstDayOfWeek: panelHelpers.getFirstDayOfWeek( browsePanelCfg ),
				date: showTimeFields ? ( formDate || centerYMD ) : '',
				showTimeFields: showTimeFields,
				strip: !! ( hasStaff && !( staffId || '' ) )
			}, _b );
		}
		function loadDaySlots( date ) {
			var tzCfg = utils && utils.getTimezoneConfig && utils.getTimezoneConfig();
			if ( ! ( tzCfg && tzCfg.hasDifferentTz ) ) {
				selectedSlotSiteDateRef.current = date;
			}
			// Mark so the date-only effect does not issue a second (aborting) slots fetch.
			createSlotsLoadDateRef.current = date || '';
			panelHelpers.loadDaySlotsAction( ajaxUrl, nonces, { productId: productId, staffId: staffId || '', locationId: locationId || '', resourceId: resourceId || '', qty: formQty, date: date, showTimeFields: showTimeFields }, _b );
		}

		// ── Cost calculation (delegated to panelHelpers) ──
		function scheduleCalculateCost() {
			if ( recurringOn ) { return; }
			// Pause cost quotes while browse month/strip owns Local's single PHP worker.
			if ( miniCalLoading ) { return; }
			if ( costTimerRef.current ) { clearTimeout( costTimerRef.current ); }
			costTimerRef.current = setTimeout( calculateCost, 300 );
		}
		function calculateCost() {
			if ( recurringOn || ! productId || ! ajaxUrl ) {
				if ( recurringOn ) { return; }
				setCalculatedCost( '' );
				setCalculatedCostRaw( 0 );
				return;
			}
			if ( miniCalLoading ) { return; }
			// Do not quote until location/resource picks that is_appointable() requires are set
			// (avoids flashing "Please choose Resources." after venue-only selection).
			if ( slotsContextPending ) {
				setCalculatedCost( '' );
				setCalculatedCostRaw( 0 );
				setCalculatedCostRawFull( 0 );
				setCostDepositApplied( false );
				return;
			}
			var quoteCustomerId = customerIdRef.current || '0';
			var costParams = {
				productId: productId, staffId: staffId || '', qty: formQty,
				locationId: locationId || '', resourceId: resourceId || '',
				customerId: quoteCustomerId,
				showTimeFields: showTimeFields,
				addonsDuration: addonsDuration, addonsCost: addonsCost
			};
			if ( showDateRange ) {
				costParams.dateFrom = formDateFrom;
				costParams.timeFrom = formTimeFrom;
			} else if ( showMonthRange ) {
				costParams.monthFrom = formMonthFrom;
				costParams.timeFrom = formTimeFrom;
			} else {
				assignResolvedTimedParams( costParams, resolveCreateTimed( true, false ) );
			}
			if ( productDetails && productDetails.wc_deposits ) {
				var wdepCost = productDetails.wc_deposits;
				if ( wdepCost.forced || 'yes' === wcDepositOption ) {
					costParams.wcDepositOption = 'yes';
					if ( 'plan' === wdepCost.type && wcDepositPlanId ) {
						costParams.wcDepositPlanId = wcDepositPlanId;
					}
				} else {
					costParams.wcDepositOption = 'no';
				}
			}
			panelHelpers.fetchCost( ajaxUrl, costParams, costXHRRef ).then( function( result ) {
				setCalculatedCost( result.html );
				setCalculatedCostRaw( result.raw );
				setCalculatedCostRawFull( result.rawFull > 0 ? result.rawFull : result.raw );
				setCostDepositApplied( !! result.depositApplied );
			} );
		}

		// ── Availability check (delegated to panelHelpers) ──
		function createAvailabilityInputReady() {
			if ( slotsContextPending ) {
				return false;
			}
			if ( createAwaitingSlotPick() ) {
				return false;
			}
			return productId && panelHelpers.availabilityParamsReady
				&& panelHelpers.availabilityParamsReady( buildCreateAvailParams( false ) );
		}

		function createShouldOpenBrowseOnFocus() {
			return 'unavailable' === availStatus || ! createAvailabilityInputReady();
		}

		function scheduleCheckAvailability( immediate, silent ) {
			var availDelayMs = immediate ? 0 : 150;
			if ( ! createAvailabilityInputReady() ) {
				if ( availTimerRef.current ) { clearTimeout( availTimerRef.current ); }
				return;
			}
			if ( availTimerRef.current ) { clearTimeout( availTimerRef.current ); }
			availTimerRef.current = setTimeout( function() { checkAvailability( !! silent ); }, availDelayMs );
		}
		function createAvailCheckKey( params ) {
			return [
				params.productId || '',
				params.staffId || '',
				params.locationId || '',
				params.resourceId || '',
				params.qty || '',
				params.date || '',
				params.dateFrom || '',
				params.dateTo || '',
				params.monthFrom || '',
				params.monthTo || '',
				params.timeFrom || '',
				params.timeTo || '',
				params.slotStartTimestamp || '',
				params.addonsDuration || 0
			].join( '|' );
		}
		function checkAvailability( silent ) {
			var ready = !!( productId && ajaxUrl && createAvailabilityInputReady() );
			if ( ! ready ) {
				return;
			}
			var availParams = buildCreateAvailParams( true );
			var checkKey = createAvailCheckKey( availParams );
			// Same selection already in flight: do not abort/restart (avoids stacked admin-ajax).
			if ( createAvailInFlightKeyRef.current === checkKey ) {
				return;
			}
			createAvailInFlightKeyRef.current = checkKey;
			var checkGen = silent
				? bumpAvailCheckGen( availCheckGenRef )
				: beginAvailabilityPending( setAvailStatus, setAvailMessage, availCheckGenRef );
			function finishAvail( result ) {
				if ( createAvailInFlightKeyRef.current === checkKey ) {
					createAvailInFlightKeyRef.current = '';
				}
				applyAvailabilityResult( availCheckGenRef, checkGen, setAvailStatus, setAvailMessage, result, true );
				scheduleCalculateCost();
			}
			panelHelpers.fetchAvailability( ajaxUrl, nonces, availParams, availXHRRef ).then( finishAvail ).catch( function() {
				finishAvail( {
					status: 'unavailable',
					message: 'Error checking availability'
				} );
			} );
		}

		onCurrencyAppliedRef.current = function() {
			if ( productId && hasAddons ) {
				setAddonsCost( 0 );
				setAddonsDuration( 0 );
				setEndDaysOffset( 0 );
				loadProductAddons( productId, true );
			}
			scheduleCalculateCost();
		};

		// ── Product add-ons: preload HTML on select; AJAX only for currency reload / missing preload ──
		function addonsCacheKeyForProduct( pid ) {
			var panelAddonsCfg = window.wcaPanel || {};
			var key = pid + '|' + ( panelAddonsCfg.pricesIncludeTax ? 'paincl' : 'paexcl' );
			if ( integrationCurrency.addonsCacheSuffix ) {
				key += '|' + integrationCurrency.addonsCacheSuffix;
			}
			return key;
		}

		function applyAddonsPayload( html, hasReq, cacheKey ) {
			if ( cacheKey ) {
				addonsCacheRef.current[ cacheKey ] = { html: html || '', has_required_addons: !! hasReq };
			}
			setAddonsHtml( html || '' );
			setHasRequiredAddons( !! hasReq );
			setAddonsLoading( false );
		}

		function loadProductAddons( pid, forceReload ) {
			if ( ! pid || ! ajaxUrl ) { applyAddonsPayload( '', false, '' ); return; }
			var addonsCacheKey = addonsCacheKeyForProduct( pid );
			var cached = ! forceReload && addonsCacheRef.current[ addonsCacheKey ];
			if ( cached ) {
				applyAddonsPayload( cached.html, cached.has_required_addons, '' );
				return;
			}
			setAddonsLoading( true );
			if ( addonsXHRRef.current && addonsXHRRef.current.abort ) {
				try { addonsXHRRef.current.abort(); } catch ( e ) {}
			}
			var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
			addonsXHRRef.current = ctrl;
			var panelAddonsCfg = window.wcaPanel || {};
			var fd = new FormData();
			fd.append( 'action', 'wc_appointments_get_product_addons' );
			fd.append( 'product_id', pid );
			fd.append( 'nonce', nonces.getProductDetails || '' );
			fd.append( panelAddonsCfg.pricesIncludeTax ? 'wc_appointments_panel_addons_incl_tax' : 'wc_appointments_panel_addons_excl_tax', '1' );
			fetch( ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin', signal: ctrl ? ctrl.signal : undefined } )
				.then( function( r ) { return r.json(); } )
				.then( function( resp ) {
					if ( resp && resp.success && resp.data ) {
						applyAddonsPayload( resp.data.html || '', resp.data.has_required_addons, addonsCacheKey );
					} else {
						applyAddonsPayload( '', false, '' );
					}
				} )
				.catch( function() { applyAddonsPayload( '', false, '' ); } );
		}

		useEffect( function() {
			if ( typeof props.onProductChange === 'function' ) {
				props.onProductChange( productId ? String( productId ) : '' );
			}
			if ( ! productId || ! hasAddons ) {
				applyAddonsPayload( '', false, '' );
				if ( ! productId ) { setAddonsError( '' ); }
				return;
			}
			var key = addonsCacheKeyForProduct( productId );
			var cached = addonsCacheRef.current[ key ];
			if ( cached ) {
				applyAddonsPayload( cached.html, cached.has_required_addons, '' );
				return;
			}
			if ( preloadRow && preloadRow.addons_html ) {
				applyAddonsPayload( String( preloadRow.addons_html ), preloadRow.has_required_addons, key );
				return;
			}
			loadProductAddons( productId );
		}, [ productId, hasAddons ] );

		// ── Inject add-ons HTML into DOM ref and initialize WC_PAO.Form ──
		// Re-run when product changes so the container ref is mounted.
		useEffect( function() {
			if ( ! addonsContainerRef.current ) { addonsInjectedRef.current = ''; return; }
			if ( ! addonsHtml ) {
				addonsContainerRef.current.innerHTML = '';
				addonsInjectedRef.current = '';
				paoFormRef.current = null;
				setAddonsCost( 0 );
				setAddonsDuration( 0 );
				setEndDaysOffset( 0 );
				return;
			}
			// Skip re-injection if the same HTML is already in this container.
			if ( addonsInjectedRef.current === addonsHtml ) { return; }
			addonsInjectedRef.current = addonsHtml;
			var container = addonsContainerRef.current;
			container.innerHTML = addonsHtml;

			// Find the wrapping section element (.wc-appointment-addons-container or parent)
			var $section = window.jQuery ? window.jQuery( container ).closest( '.wc-appointment-addons-container' ) : null;
			if ( ! $section || ! $section.length ) {
				$section = window.jQuery ? window.jQuery( container ) : null;
			}

			// Ensure hidden qty field for PAO qty-dependent logic
			if ( $section && ! $section.find( 'input.qty' ).length ) {
				$section.append( '<input type="hidden" class="qty" value="' + ( parseInt( formQty || '1', 10 ) ) + '" />' );
			}

			// Initialize WC_PAO.Form to compute totals and trigger events
			if ( window.WC_PAO && 'function' === typeof window.WC_PAO.Form && $section && $section.length ) {
				try {
					// Storefront PAO fires wc_product_addons_calculate_tax for price suffixes.
					// On this admin page that AJAX contends with check_availability / calculate_costs
					// (same admin-ajax pool) and was measured at ~9s TTFB while avail waited behind it.
					// Panel pricing uses wc_appointments_calculate_costs; disable PAO tax AJAX here.
					if ( window.woocommerce_addons_params ) {
						window.woocommerce_addons_params.tax_enabled = 0;
					}
					var $totals = $section.find( '#product-addons-total' );
					if ( $totals.length ) {
						$totals
							.data( 'show-incomplete-sub-total', 1 ).attr( 'data-show-incomplete-sub-total', 1 )
							.data( 'show-sub-total', 1 ).attr( 'data-show-sub-total', 1 )
							.data( 'hide-product-price', 1 ).attr( 'data-hide-product-price', 1 );
						var lbl = t( 'addons_total', 'Add-ons total' );
						$totals.data( 'i18n_sub_total', lbl ).attr( 'data-i18n_sub_total', lbl );
					}
					paoFormRef.current = new window.WC_PAO.Form( $section );
					paoFormRef.current.contains_required = true;
					paoFormRef.current.show_incomplete_subtotals = true;
					// Clean up duplicate #product-addons-total elements
					$section.find( '.validation_message' ).each( function() {
						window.jQuery( this ).nextAll( '#product-addons-total' ).remove();
					} );
					var $totalsAll = $section.find( '#product-addons-total' );
					if ( $totalsAll.length > 1 ) { $totalsAll.not( $totalsAll.first() ).remove(); }
				} catch ( e ) {
					console.warn( 'WC_PAO.Form init failed:', e );
				}
			}

			// Listen for updated_addons to extract addon cost and duration
			if ( $section && $section.length ) {
				$section.off( 'updated_addons.panelAddons' ).on( 'updated_addons.panelAddons', function() {
					if ( paoSilentRef.current ) {
						paoSilentRef.current = false;
						return;
					}
					var qtyLive = parseInt( $section.find( 'input.qty' ).val() || formQty || '1', 10 );
					var $t = $section.find( '#product-addons-total' );
					var priceData = $t.data( 'price_data' ) || [];
					var dur = 0;
					var cost = 0;
					priceData.forEach( function( item ) {
						var durPu = parseInt( item.duration_raw_pu || 0, 10 );
						var durRaw = parseInt( item.duration_raw || 0, 10 );
						var durBase = durPu || durRaw || 0;
						if ( durBase ) {
							dur += ( 'quantity_based' === item.duration_type ) ? durBase * qtyLive : durBase;
						}
						var costPu = parseFloat( ( item.cost_raw_pu || 0 ).toString().replace( ',', '.' ) );
						var costRaw = parseFloat( ( item.cost_raw || 0 ).toString().replace( ',', '.' ) );
						var hasRaw = ! isNaN( costRaw ) && 0 !== costRaw;
						var hasPu = ! isNaN( costPu ) && 0 !== costPu;
						var costBase = hasRaw ? costRaw : ( hasPu ? costPu : 0 );
						if ( 0 !== costBase ) { cost += costBase; }
					} );
					setAddonsDuration( dur );
					setAddonsCost( cost );
					// Clean up duplicate totals
					$section.find( '.validation_message' ).each( function() {
						window.jQuery( this ).nextAll( '#product-addons-total' ).remove();
					} );
					var $ta = $section.find( '#product-addons-total' );
					if ( $ta.length > 1 ) { $ta.not( $ta.first() ).remove(); }
				} );
				// Also bind change on PAO addon fields to trigger the PAO update event
				$section.off( 'change.paoPanel' ).on( 'change.paoPanel', '.wc-pao-addon-field', function() {
					$section.trigger( 'woocommerce-product-addons-update' );
				} );
			}

			// Trigger initial change on inputs to seed PAO state
			if ( window.jQuery && window.jQuery.fn.trigger ) {
				window.jQuery( container ).find( 'select, input' ).trigger( 'change' );
			}

			return function() {
				addonsInjectedRef.current = '';
				if ( $section && $section.length ) {
					$section.off( 'updated_addons.panelAddons' );
					$section.off( 'change.paoPanel' );
				}
				paoFormRef.current = null;
			};
		}, [ addonsHtml ] );

		// Keep PAO hidden qty in sync when appointment quantity changes (inject effect may early-return on same HTML).
		useEffect( function() {
			if ( ! addonsContainerRef.current || ! addonsHtml || ! window.jQuery ) { return; }
			var $c = window.jQuery( addonsContainerRef.current );
			var $section = $c.closest( '.wc-appointment-addons-container' );
			if ( ! $section.length ) { $section = $c; }
			if ( ! $section.length ) { return; }
			var q = parseInt( formQty || '1', 10 );
			var $hq = $section.find( 'input.qty' );
			if ( $hq.length ) {
				$hq.val( q );
				$section.trigger( 'woocommerce-product-addons-update' );
			}
		}, [ formQty, addonsHtml ] );

		// ── Addon validation helper (briefly uncollapse section so PaoValidation can run, then re-collapse)
		function checkAddonsValid() {
			if ( ! hasRequiredAddons ) { return true; }
			var container = addonsContainerRef.current;
			if ( ! container || ! addonsHtml || ! window.jQuery || ! window.PaoValidation ) { return false; }
			var section = container.closest( '.wca-form-addons-section' );
			var wasCollapsed = section && ! section.classList.contains( 'wca-expansion--expanded' );
			if ( wasCollapsed && section ) { section.classList.add( 'wca-expansion--expanded' ); }
			var valid = false;
			var $container = window.jQuery( container );
			var $addons = $container.find( '[data-restrictions]' ).filter( function() {
				return window.jQuery( this ).attr( 'id' );
			} );
			if ( $addons.length ) {
				var validation = new window.PaoValidation( { $el: $container, $addons: $addons } );
				valid = validation.validate( true );
			}
			if ( wasCollapsed && section ) { section.classList.remove( 'wca-expansion--expanded' ); }
			return valid;
		}
		checkAddonsValidRef.current = checkAddonsValid;

		// ── Live addon validation: run PaoValidation on each field selection/deselection; submit button only shows top notice
		// Also trigger woocommerce-product-addons-update on the addons section so PAO (and any listeners) refresh the Add-ons total and selected addons list.
		useEffect( function() {
			if ( ! addonsHtml || ! addonsContainerRef.current ) { return; }
			var container = addonsContainerRef.current;
			var debounceTimer = null;
			function runLiveValidation() {
				debounceTimer = null;
				if ( checkAddonsValidRef.current ) {
					var valid = checkAddonsValidRef.current();
					if ( valid ) { setAddonsError( '' ); }
				}
				// Refresh Add-ons total and selected addons display.
				var section = container.closest( '.wca-form-addons-section' );
				if ( section && window.jQuery ) {
					window.jQuery( section ).trigger( 'woocommerce-product-addons-update' );
				}
			}
			function onAddonInteraction() {
				if ( debounceTimer ) { clearTimeout( debounceTimer ); }
				debounceTimer = setTimeout( runLiveValidation, 120 );
			}
			container.addEventListener( 'change', onAddonInteraction );
			container.addEventListener( 'input', onAddonInteraction );
			container.addEventListener( 'keyup', onAddonInteraction );
			return function() {
				if ( debounceTimer ) { clearTimeout( debounceTimer ); }
				container.removeEventListener( 'change', onAddonInteraction );
				container.removeEventListener( 'input', onAddonInteraction );
				container.removeEventListener( 'keyup', onAddonInteraction );
			};
		}, [ addonsHtml ] );

		// ── Auto-compute end time from product duration + addon duration ──
		function applyCombinedDurationToEnd( fromTime, force ) {
			if ( ! fromTime || ! showTimeFields ) {
				return;
			}
			// If already set and not forced, don't overwrite user-specified end time.
			if ( formTimeTo && ! force ) { return; }

			var duration = parseInt( productDuration, 10 ) || 0;
			var unit = durationUnit || 'hour';
			var minutes = 0;
			if ( 'hour' === unit ) { minutes = duration * 60; }
			else if ( 'minute' === unit ) { minutes = duration; }
			else {
				return;
			}

			// Add addon duration (same as modal)
			minutes += ( addonsDuration || 0 );
			if ( minutes <= 0 ) {
				return;
			}

			// Sanitize fromTime: remove tags and extract HH:MM.
			var cleanFrom = String( fromTime ).replace( /<[^>]+>/g, '' ).trim();
			var parts = cleanFrom.split( ':' );
			var startH = parseInt( parts[ 0 ], 10 );
			var startM = parseInt( parts[ 1 ] || 0, 10 );
			if ( isNaN( startH ) || isNaN( startM ) ) {
				return;
			}

			var startMin = ( startH * 60 ) + startM;
			var endMin   = startMin + minutes;
			var daysOff  = Math.floor( endMin / 1440 );
			var endDisp  = ( ( endMin % 1440 ) + 1440 ) % 1440;
			var hh = ( '0' + Math.floor( endDisp / 60 ) ).slice( -2 );
			var mm = ( '0' + ( endDisp % 60 ) ).slice( -2 );
			var endVal = hh + ':' + mm;

			setEndDaysOffset( daysOff );
			setFormTimeTo( endVal );
		}

		// ── Auto-compute end date from product duration (day-based) ──
		function autoComputeEndDate( fromDate ) {
			if ( ! fromDate ) { return; }
			var baseDays = parseInt( productDuration, 10 );
			var df = new Date( fromDate.replace( /-/g, '/' ) );
			df.setDate( df.getDate() + Math.max( baseDays - 1, 0 ) );
			var y = df.getFullYear();
			var m = ( '0' + ( df.getMonth() + 1 ) ).slice( -2 );
			var d = ( '0' + df.getDate() ).slice( -2 );
			setFormDateTo( y + '-' + m + '-' + d );
		}

		// ── Auto-compute end month from product duration (month-based) ──
		function autoComputeEndMonth( fromMonth ) {
			if ( ! fromMonth ) { return; }
			var baseMonths = parseInt( productDuration, 10 );
			var parts = fromMonth.split( '-' );
			var fy = parseInt( parts[ 0 ], 10 );
			var fm = parseInt( parts[ 1 ], 10 ) - 1;
			var endDate = new Date( fy, fm + Math.max( baseMonths - 1, 0 ), 1 );
			var endStr = endDate.getFullYear() + '-' + ( '0' + ( endDate.getMonth() + 1 ) ).slice( -2 );
			setFormMonthTo( endStr );
		}

		// When Product Add-Ons duration totals change, refresh end time / end date range.
		useEffect( function() {
			if ( ! productDetails ) { return; }
			var pd = productDetails;
			var unitR = pd.duration_unit || '';
			var addonVal = addonsDuration || 0;

			if ( showTimeFields && formTimeFrom && ( 'hour' === unitR || 'minute' === unitR ) ) {
				applyCombinedDurationToEnd( formTimeFrom, true );
				return;
			}
			// Day/month: always base + addon days (addon 0 = revert to product-only span after deselect)
			if ( showDateRange && formDateFrom && 'day' === unitR ) {
				var baseDaysR = parseInt( pd.duration || 1, 10 );
				var daysR = baseDaysR + ( isNaN( addonVal ) ? 0 : addonVal );
				var dfr = new Date( formDateFrom.replace( /-/g, '/' ) );
				dfr.setDate( dfr.getDate() + Math.max( daysR - 1, 0 ) );
				var yR = dfr.getFullYear();
				var mR = ( '0' + ( dfr.getMonth() + 1 ) ).slice( -2 );
				var dR = ( '0' + dfr.getDate() ).slice( -2 );
				setFormDateTo( yR + '-' + mR + '-' + dR );
			} else if ( showMonthRange && formMonthFrom && 'month' === unitR ) {
				var baseMonthsR = parseInt( pd.duration || 1, 10 );
				var monthsR = baseMonthsR + ( isNaN( addonVal ) ? 0 : addonVal );
				var partsR = formMonthFrom.split( '-' );
				var fyR = parseInt( partsR[ 0 ], 10 );
				var fmR = parseInt( partsR[ 1 ], 10 ) - 1;
				var endR = new Date( fyR, fmR + Math.max( monthsR - 1, 0 ), 1 );
				setFormMonthTo( endR.getFullYear() + '-' + ( '0' + ( endR.getMonth() + 1 ) ).slice( -2 ) );
			}
		}, [ addonsDuration, showTimeFields, showDateRange, showMonthRange, formTimeFrom, formDateFrom, formMonthFrom, productDetails ] );

		// ── Live preview event on calendar (Google Calendar-style) ──
		// Debounced: updates the preview event position whenever date/time changes in the create panel.
		var previewTimerRef = useRef( null );
		var createInitialPreviewRef = useRef( true );
		useEffect( function() {
			var api = window.__wcaCalPreview;
			if ( ! api ) { return; }

			// Helper: add one day to YYYY-MM-DD for FullCalendar exclusive end
			function addOneDay( ymd ) {
				var p = ymd.split( '-' );
				var d = new Date( parseInt( p[ 0 ], 10 ), parseInt( p[ 1 ], 10 ) - 1, parseInt( p[ 2 ], 10 ) + 1 );
				return d.getFullYear() + '-' + ( '0' + ( d.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + d.getDate() ).slice( -2 );
			}

			// Clear any pending debounce
			if ( previewTimerRef.current ) { clearTimeout( previewTimerRef.current ); }

			previewTimerRef.current = setTimeout( function() {
				// Build preview data from current form state
				var startISO = '';
				var endISO = '';
				var allDay = false;
				var previewStartTs = 0;
				var previewEndTs = 0;

				// Detect multi-day all-day span (covers pre-product-load multi-day selections)
				var hasMultiDaySpan = formDateFrom && formDateTo && formDateFrom !== formDateTo;

				if ( showDateRange || hasMultiDaySpan ) {
					// Day-based products or multi-day selection
					var rangeStart = formDateFrom || formDate;
					if ( rangeStart ) {
						startISO = rangeStart;
						endISO = addOneDay( formDateTo || rangeStart );
						allDay = true;
					}
				} else if ( showMonthRange ) {
					// Month-based products
					if ( formMonthFrom ) {
						startISO = formMonthFrom + '-01';
						var mTo = formMonthTo || formMonthFrom;
						var mParts = mTo.split( '-' );
						// Exclusive end: first day of next month
						var nextM = new Date( parseInt( mParts[ 0 ], 10 ), parseInt( mParts[ 1 ], 10 ), 1 );
						endISO = nextM.getFullYear() + '-' + ( '0' + ( nextM.getMonth() + 1 ) ).slice( -2 ) + '-01';
						allDay = true;
					}
				} else if ( showTimeFields ) {
					// Hour/minute-based products (single day with time)
					var createSlotTs = parseInt( slotStartTsRef.current, 10 ) || 0;
					if ( formDate && formTimeFrom && !panelHelpers.isDateOnlyTimePlaceholder( formTimeFrom, createSlotTs ) ) {
						if ( createSlotTs > 86400 ) {
							previewStartTs = createSlotTs;
							var crMin = 0;
							if ( productDetails ) {
								var crDur = parseInt( productDetails.duration || 0, 10 );
								var crUnit = productDetails.duration_unit || 'hour';
								if ( 'hour' === crUnit ) { crMin = crDur * 60; }
								else if ( 'minute' === crUnit ) { crMin = crDur; }
							}
							crMin += ( addonsDuration || 0 );
							if ( formTimeTo && crMin > 0 ) {
								previewEndTs = createSlotTs + crMin * 60;
							}
						} else {
							startISO = formDate + 'T' + formTimeFrom + ':00';
							if ( formTimeTo ) {
								var previewEndDate = formDate;
								if ( endDaysOffset > 0 && formDate ) {
									var _dp = formDate.split( '-' );
									var _dd = new Date( parseInt( _dp[ 0 ], 10 ), parseInt( _dp[ 1 ], 10 ) - 1, parseInt( _dp[ 2 ], 10 ) + endDaysOffset );
									previewEndDate = _dd.getFullYear() + '-' + ( '0' + ( _dd.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + _dd.getDate() ).slice( -2 );
								}
								endISO = previewEndDate + 'T' + formTimeTo + ':00';
							} else {
								// Match admin calendar slot until product duration loads (avoids 1h preview vs 30m hover).
								var __tp = formTimeFrom.split( ':' );
								var __sm = ( parseInt( __tp[ 0 ], 10 ) * 60 ) + parseInt( __tp[ 1 ], 10 ) + 30;
								var __endM = ( ( __sm % 1440 ) + 1440 ) % 1440;
								var __eh = ( '0' + Math.floor( __endM / 60 ) ).slice( -2 );
								var __em = ( '0' + ( __endM % 60 ) ).slice( -2 );
								endISO = formDate + 'T' + __eh + ':' + __em + ':00';
							}
						}
					} else if ( formDate ) {
						// Calendar day-click / awaiting first slot: show all-day placeholder on that date.
						startISO = formDate;
						endISO = addOneDay( formDate );
						allDay = true;
					}
				} else if ( formDate ) {
					// Fallback: single date, all day
					startISO = formDate;
					endISO = addOneDay( formDate );
					allDay = true;
				}

				if ( ! startISO && ! previewStartTs ) {
					api.remove();
					return;
				}

				// Navigate calendar to show the preview date if outside current view
				var navDate = allDay ? startISO : ( previewStartTs ? formDate : ( startISO.split( 'T' )[ 0 ] || '' ) );
				var didNavigate = false;
				if ( navDate ) {
					didNavigate = api.navigateTo( navDate );
				}

				var previewData = {
					startISO: startISO || undefined,
					endISO: endISO || undefined,
					allDay: allDay
				};
				if ( previewStartTs > 86400 ) {
					previewData.startTs = previewStartTs;
					if ( previewEndTs > previewStartTs ) {
						previewData.endTs = previewEndTs;
					}
				} else if ( allDay && startISO ) {
					// Site-local semantic timestamps (UTC midnight) — matches edit preview and real all-day events.
					previewData.startTs = Math.floor( new Date( startISO + 'T00:00:00Z' ).getTime() / 1000 );
					if ( endISO ) {
						previewData.endTs = Math.floor( new Date( endISO + 'T00:00:00Z' ).getTime() / 1000 );
					}
				}
				var createPreviewTitle = t( 'guest', 'Guest' );
				var createCustId = parseInt( customerId, 10 );
				if ( createCustId > 0 ) {
					var createCustLabel = customerSearch && String( customerSearch ).trim();
					createPreviewTitle = panelHelpers.customerNameFromSelectLabel( createCustLabel ) || t( 'customer', 'Customer' );
				}
				previewData.title = ( recurringOn ? '\u21BB ' : '' ) + createPreviewTitle;
				if ( productId ) {
					var pi, matchedProduct = null;
					for ( pi = 0; pi < products.length; pi++ ) {
						if ( products[ pi ] && String( products[ pi ].id ) === String( productId ) ) {
							matchedProduct = products[ pi ];
							if ( matchedProduct.cal_color && String( matchedProduct.cal_color ).trim() ) {
								previewData.color = String( matchedProduct.cal_color ).trim();
							}
							break;
						}
					}
					if ( ! previewData.color && productDetails && productDetails.cal_color && String( productDetails.cal_color ).trim() ) {
						previewData.color = String( productDetails.cal_color ).trim();
					}
				}

				// Reposition the panel next to the preview event (no calendar scroll).
				function repositionPanelToPreview() {
					requestAnimationFrame( function() {
						requestAnimationFrame( function() {
							var previewEl = document.querySelector( '.wca-preview-event' );
							if ( previewEl && window.wcaPanel && window.wcaPanel.updateTrigger ) {
								window.wcaPanel.updateTrigger( previewEl );
							}
						} );
					} );
				}

				// Scroll calendar/page so the preview is in view, then reposition the panel (sync with layout).
				function scrollAndRepositionPreview() {
					requestAnimationFrame( function() {
						api.scrollToPreview();
						repositionPanelToPreview();
					} );
				}

				// On initial mount, skip the calendar scroll — the clicked cell is
				// already visible. Just reposition the panel next to the preview event.
				// On subsequent runs (user changed date/time), do the full scroll.
				var isInitialRun = createInitialPreviewRef.current;
				if ( isInitialRun ) { createInitialPreviewRef.current = false; }

				if ( didNavigate ) {
					// gotoDate triggers async refetch that wipes manually-added events;
					// delay preview injection until refetch settles.
					previewTimerRef.current = setTimeout( function() {
						api.update( previewData );
						if ( isInitialRun ) { repositionPanelToPreview(); } else { scrollAndRepositionPreview(); }
					}, 500 );
				} else {
					api.update( previewData );
					if ( isInitialRun ) { repositionPanelToPreview(); } else { scrollAndRepositionPreview(); }
				}
			}, 150 );

			return function() {
				if ( previewTimerRef.current ) { clearTimeout( previewTimerRef.current ); previewTimerRef.current = null; }
				api.remove();
			};
		}, [ formDate, formTimeFrom, formTimeTo, formDateFrom, formDateTo, formMonthFrom, formMonthTo, showTimeFields, showDateRange, showMonthRange, productId, productDetails, products, endDaysOffset ] );

		var browseSectionRef = useRef( null );
		var detailsSectionRef = useRef( null );
		var dateTimeErrRef = useRef( false );
		var recurringSectionRef = useRef( null );

		// ── Auto-compute end date/month when product details load with a prefilled start but missing end ──
		useEffect( function() {
			if ( ! productId || ( ! detailsLive && ! preloadRow ) ) { return; }
			// Day-based: calendar prefill often sets dateFrom === dateTo (single-day click). For products
			// with duration > 1 day that leaves an invalid range and the availability check fails until
			// the user re-selects (onDayClick runs autoComputeEndDate). Recompute when end is missing
			// or clearly still the single-day prefill while duration requires a longer span.
			if ( showDateRange && formDateFrom ) {
				var dayDur = parseInt( productDuration, 10 );
				if ( ! formDateTo || ( dayDur > 1 && formDateFrom === formDateTo ) ) {
					autoComputeEndDate( formDateFrom );
				}
			}
			if ( showMonthRange && formMonthFrom ) {
				var monthDur = parseInt( productDuration, 10 );
				if ( ! formMonthTo || ( monthDur > 1 && formMonthFrom === formMonthTo ) ) {
					autoComputeEndMonth( formMonthFrom );
				}
			}
			if ( showTimeFields && formTimeFrom && ! formTimeTo ) {
				applyCombinedDurationToEnd( formTimeFrom );
			}
		}, [ productId, productDetails, formTimeFrom, formTimeTo, addonsDuration, productDuration ] );

		// ── Recalculate cost and check availability on relevant field changes ──
		useEffect( function() {
			if ( ! productId ) { return; }
			// Skip while range is still the invalid same-day/same-month prefill; auto-compute effect above
			// will set end on the next state update — avoids a false "unavailable" from the debounced check.
			if ( showDateRange && formDateFrom && formDateTo && formDateFrom === formDateTo ) {
				if ( parseInt( productDuration, 10 ) > 1 ) {
					return;
				}
			}
			if ( showMonthRange && formMonthFrom && formMonthTo && formMonthFrom === formMonthTo ) {
				if ( parseInt( productDuration, 10 ) > 1 ) {
					return;
				}
			}
			var inputReady = createAvailabilityInputReady();
			var showAvailSpinner = ! inputReady && createAwaitingSlotPick() && slotsLoading;
			if ( ! inputReady ) {
				if ( availTimerRef.current ) {
					clearTimeout( availTimerRef.current );
					availTimerRef.current = null;
				}
				if ( showAvailSpinner ) {
					setAvailMessage( '' );
					setAvailStatus( function( prev ) {
						if ( 'available' === prev || 'unavailable' === prev ) {
							return prev;
						}
						return 'checking';
					} );
				} else {
					setAvailStatus( function( prev ) {
						return 'checking' === prev ? '' : prev;
					} );
				}
				scheduleCalculateCost();
				return;
			}
			var sched = createAvailScheduleRef.current;
			createAvailScheduleRef.current = { immediate: false, silent: false };
			// Availability first on the shared PHP pool; cost + deferred details run when it finishes.
			scheduleCheckAvailability( sched.immediate, sched.silent );
		// productDetails intentionally omitted: preload already shapes the form; details arrival was re-firing
		// identical checks and stacking admin-ajax behind itself.
		// addonsCost is handled separately: cost-only add-ons must not re-check availability.
		}, [ productId, formDate, formTimeFrom, formTimeTo, formDateFrom, formDateTo, formMonthFrom, formMonthTo, staffId, locationId, resourceId, formQty, addonsDuration, slotsLoading ] );

		// Quote footer once browse month/strip releases the PHP worker.
		useEffect( function() {
			if ( miniCalLoading || recurringOn || ! productId ) { return; }
			scheduleCalculateCost();
		}, [ miniCalLoading ] );

		// Cost-only Product Add-Ons (flat fee, datepicker price, etc.) update addonsCost without
		// changing addonsDuration; the avail effect above would miss them.
		useEffect( function() {
			if ( ! productId || recurringOn ) { return; }
			scheduleCalculateCost();
		}, [ addonsCost ] );

		// Member discounts key off the selected customer (not the logged-in admin).
		useEffect( function() {
			if ( ! productId || recurringOn ) { return; }
			scheduleCalculateCost();
		}, [ customerId ] );

		function getDateTimeSubmitError() {
			if ( showTimeFields && ! formDate ) {
				return t( 'dateRequired', 'This field is required.' );
			}
			if ( showDateRange && ! formDateFrom ) {
				return t( 'dateRequired', 'This field is required.' );
			}
			if ( showMonthRange && ! formMonthFrom ) {
				return t( 'dateRequired', 'This field is required.' );
			}
			if ( showTimeFields && ( ! formTimeFrom || ! formTimeTo ) ) {
				return t( 'timeRequired', 'This field is required.' );
			}
			if ( showTimeFields && formTimeFrom && formTimeTo && formTimeFrom === formTimeTo && endDaysOffset < 1 ) {
				return t( 'timeStartEndSame', 'Start and end times cannot be the same.' );
			}
			return '';
		}

		// Clear field-level date/time notice once those checks pass (leave server createFailed alone).
		useEffect( function() {
			if ( ! dateTimeErrRef.current || ! submitError ) { return; }
			if ( getDateTimeSubmitError() ) { return; }
			dateTimeErrRef.current = false;
			setSubmitError( '' );
		}, [ formDate, formTimeFrom, formTimeTo, formDateFrom, formMonthFrom, formMonthTo, showTimeFields, showDateRange, showMonthRange, endDaysOffset ] );

		// ── Calendar date prefill without a real time: load slots only (calendar is owned by browse UI) ──
		useEffect( function() {
			if ( ! productId || ! productDetails || ! showTimeFields || slotsContextPending ) { return; }
			var dateVal = showDateRange ? formDateFrom : formDate;
			if ( ! dateVal || ! panelHelpers.isDateOnlyTimePlaceholder( formTimeFrom, slotStartTsRef.current ) ) { return; }
			var siteDate = formDate || dateVal;
			if ( createSlotsLoadDateRef.current === siteDate ) { return; }
			patchSlotStartTs( 0 );
			selectedSlotSiteTimeRef.current = '';
			loadDaySlots( siteDate );
		}, [ productDetails, showTimeFields, showDateRange, formDate, formDateFrom, formTimeFrom, locationId, resourceId, staffId, slotsContextPending ] );

		// ── Auto-select first available time slot when slots load and no time is set ──
		useEffect( function() {
			if ( slotsContextPending || slotsLoading || ! panelHelpers.isDateOnlyTimePlaceholder( formTimeFrom, slotStartTsRef.current ) ) { return; }
			var expectedBrowseDate = formDate;
			var dateVal = showDateRange ? formDateFrom : formDate;
			if ( ! dateVal ) { return; }
			if ( ! slotsData || ! Array.isArray( slotsData.slots ) ) {
				return;
			}
			// slotsData.date is the browse request day (admin civil when TZ display differs).
			if ( expectedBrowseDate && slotsData.date && slotsData.date !== expectedBrowseDate ) { return; }
			var avail = slotsData.slots.filter( function( s ) {
				return s.available && ! panelHelpers.isDateOnlyTimePlaceholder( s.time, s.start_ts );
			} );
			if ( ! avail.length ) {
				var slotsGen = availCheckGenRef ? availCheckGenRef.current : 0;
				applyAvailabilityResult( availCheckGenRef, slotsGen, setAvailStatus, setAvailMessage, {
					status: 'unavailable',
					message: t( 'noSlotsOnDateSelect', 'No available time slots on this date. Please select a different date.' )
				} );
				return;
			}
			var firstSlot = avail[ 0 ];
			var siteTime = firstSlot.time || '';
			var slotTs = parseInt( firstSlot.start_ts, 10 ) || 0;
			selectedSlotSiteTimeRef.current = siteTime;
			patchSlotStartTs( slotTs );
			var siteDateFromTs = ( utils && utils.tsToNaiveLocalDate && slotTs > 86400 )
				? utils.tsToNaiveLocalDate( slotTs )
				: '';
			if ( siteDateFromTs ) {
				selectedSlotSiteDateRef.current = siteDateFromTs;
			} else if ( slotsData.date ) {
				selectedSlotSiteDateRef.current = slotsData.date;
			}
			var timeToSet = firstSlot.admin_time || siteTime;
			var dateToSet = firstSlot.admin_date || formDate;
			selectedSlotAdminDateRef.current = dateToSet || formDate || '';
			if ( dateToSet && dateToSet !== formDate ) {
				setFormDate( dateToSet );
			}
			setFormTimeFrom( timeToSet );
			applyCombinedDurationToEnd( timeToSet );
			markCreateSlotAvailable( timeToSet );
		}, [ slotsData, slotsLoading, showTimeFields, formDate, slotsContextPending ] );

		// Refresh mini-cal when open (product / staff / location / qty) or after SSE invalidate.
		useEffect( function() {
			panelHelpers.syncOpenBrowseCal( ajaxUrl, nonces, _b, {
				productId: productId,
				staffId: staffId || '',
				locationId: locationId || '',
				resourceId: resourceId || '',
				qty: formQty,
				formDate: formDate,
				showMonthRange: showMonthRange,
				showTimeFields: showTimeFields,
				hasStaff: !! hasStaff,
				firstDayOfWeek: panelHelpers.getFirstDayOfWeek( browsePanelCfg )
			} );
		}, [ browseOpen, productId, staffId, locationId, resourceId, formQty, miniCalExpanded, showMonthRange, hasStaff, _b.browseEpoch ] );

		// ── Enhanced selects (delegated to panelHelpers) ──

		// Product select — preloaded options (instant open).
		useEffect( function() {
			return panelHelpers.initPreloadedProductSelect( productSelectRef, productOptions, setProductId, setProductName );
		}, [ productOptions.length ] );

		// Staff enhanced select (re-run when staff section is visible so ref is in DOM)
		useEffect( function() {
			if ( ! productId || ! hasStaff || isAllStaff ) { return; }
			var cleanupFn = null;
			var tmr = setTimeout( function() {
				cleanupFn = panelHelpers.initEnhancedSelect( staffSelectRef, function( v ) { setStaffId( v ); } );
			}, 0 );
			return function() {
				clearTimeout( tmr );
				if ( typeof cleanupFn === 'function' ) {
					try { cleanupFn(); } catch ( e ) {}
				}
			};
		}, [ productId, hasStaff, staffOptions.length, isAllStaff ] );

		useEffect( function() {
			panelHelpers.setEnhancedSelectValue( staffSelectRef, staffId || '' );
		}, [ staffId ] );

		// Location enhanced select (re-run when location section is visible; fixed mode stays disabled)
		useEffect( function() {
			if ( ! productId || ! hasLocations ) { return; }
			var locKeyCount = Object.keys( locationMap || {} ).length;
			if ( ! locKeyCount ) { return; }
			var cleanupFn = null;
			var tmr = setTimeout( function() {
				cleanupFn = panelHelpers.initEnhancedSelect( locationSelectRef, onCreateLocationChange );
			}, 0 );
			return function() {
				clearTimeout( tmr );
				if ( typeof cleanupFn === 'function' ) {
					try { cleanupFn(); } catch ( e ) {}
				}
			};
		}, [ productId, hasLocations, Object.keys( locationMap || {} ).length, locationMode ] );

		useEffect( function() {
			panelHelpers.setEnhancedSelectValue( locationSelectRef, locationId || '' );
		}, [ locationId ] );

		// Resource enhanced select
		useEffect( function() {
			if ( ! productId || ! hasResources ) { return; }
			var poolCount = Object.keys( resourceMap || {} ).length;
			if ( ! poolCount ) { return; }
			var cleanupFn = null;
			var tmr = setTimeout( function() {
				cleanupFn = panelHelpers.initEnhancedSelect( resourceSelectRef, setResourceId );
			}, 0 );
			return function() {
				clearTimeout( tmr );
				if ( typeof cleanupFn === 'function' ) {
					try { cleanupFn(); } catch ( e ) {}
				}
			};
		}, [ productId, hasResources, Object.keys( resourceMap || {} ).length, locationId ] );

		useEffect( function() {
			panelHelpers.setEnhancedSelectValue( resourceSelectRef, resourceId || '' );
		}, [ resourceId ] );

		// Order type enhanced select
		useEffect( function() {
			return panelHelpers.initEnhancedSelect( orderTypeSelectRef, function( v ) {
				setOrderType( v );
				setExistingOrderId( '' );
				setOrderSearch( '' );
			} );
		}, [ productId ] );

		// Existing order owns contact/payment; close customer details when leaving "new order".
		useEffect( function() {
			if ( 'new' !== orderType ) {
				setDetailsOpen( false );
			}
		}, [ orderType ] );

		// Existing order AJAX enhanced select (delegated to panelHelpers)
		useEffect( function() {
			if ( orderType !== 'existing' || existingOrderId ) { return; }
			return panelHelpers.initAjaxSelect( existingOrderSelectRef, {
				url: ajaxUrl,
				action: 'wc_appointments_json_search_order',
				security: nonces.searchOrder || '',
				placeholder: '',
				minimumInputLength: 0,
				processResults: function( data ) {
					var items = [];
					if ( data && 'object' === typeof data ) {
						var keys = Object.keys( data );
						for ( var ki = 0; ki < keys.length; ki++ ) {
							var cleanName = data[ keys[ ki ] ] ? panelHelpers.sanitizeSelect2Label( data[ keys[ ki ] ] ) : '';
							// Use server label only — it already includes order number + date; prepending #id duplicated numeric IDs.
							items.push( { id: keys[ ki ], text: cleanName || ( '#' + keys[ ki ] ) } );
						}
					}
					return { results: items };
				},
				onSelect: function( id, text ) {
					setExistingOrderId( id );
					setOrderSearch( text.replace( /^#\d+\s*/, '' ).trim() );
				},
				onClear: function() {
					setExistingOrderId( '' );
					setOrderSearch( '' );
				}
			} );
		}, [ orderType, existingOrderId, productId ] );

		// Customer search (inside open Customer card, or always when attaching to an existing order).
		useEffect( function() {
			if ( ! productId || customerId ) { return; }
			if ( 'new' === orderType && ! detailsOpen ) { return; }
			return panelHelpers.initAjaxSelect( customerSelectRef, {
				url: ajaxUrl,
				action: 'woocommerce_json_search_customers',
				security: nonces.searchCustomers || '',
				placeholder: '',
				onSelect: function( id, text ) {
					setCustomerId( id );
					setCustomerSearch( text );
					setCreatePreviewTitle( panelHelpers.customerNameFromSelectLabel( text ) || t( 'customer', 'Customer' ) );
					if ( 'new' === orderType ) {
						// Yield cost AJAX only; leave availability in flight so its result still paints.
						abortPanelAjax( costXHRRef );
						fetchCustomerBilling( id );
					}
				}
			} );
		}, [ productId, customerId, detailsOpen, orderType ] );

		// Customer card: country / state / timezone when open (timezone options = get_timezone_dropdown HTML).
		useEffect( function() {
			if ( orderType !== 'new' || ! productId || ! detailsOpen ) {
				return;
			}
			var cleanups = [];
			var tmr = setTimeout( function() {
				var c = panelHelpers.initEnhancedSelect( billingCountrySelectRef, function( v ) {
					setBilling( function( prev ) {
						var n = Object.assign( {}, prev );
						n.country = v;
						n.state = '';
						return n;
					} );
				} );
				if ( typeof c === 'function' ) { cleanups.push( c ); }
				if ( billingStateIsDropdown && billingStateSelectRef.current ) {
					c = panelHelpers.initEnhancedSelect( billingStateSelectRef, function( v ) {
						setBillingField( 'state', v );
					} );
					if ( typeof c === 'function' ) { cleanups.push( c ); }
				}
				if ( timezoneSelectRef.current && cfg.timezoneOptionsHtml ) {
					var tzEl = timezoneSelectRef.current;
					if ( ! tzEl.dataset.wcaTzOpts ) {
						tzEl.innerHTML = cfg.timezoneOptionsHtml;
						tzEl.dataset.wcaTzOpts = '1';
					}
					tzEl.value = billing.timezone || '';
					c = panelHelpers.initEnhancedSelect( timezoneSelectRef, { minimumResultsForSearch: 0 }, function( v ) {
						setBillingField( 'timezone', v || '' );
					} );
					if ( typeof c === 'function' ) { cleanups.push( c ); }
				}
			}, 0 );
			return function() {
				clearTimeout( tmr );
				for ( var i = 0; i < cleanups.length; i++ ) {
					try { cleanups[ i ](); } catch ( e ) {}
				}
			};
		}, [ detailsOpen, orderType, productId, billing.country, billingStateIsDropdown ] );

		// Order: payment method selectWoo (new order only).
		useEffect( function() {
			if ( orderType !== 'new' || ! productId ) {
				return;
			}
			var cleanups = [];
			var tmr = setTimeout( function() {
				var c = panelHelpers.initEnhancedSelect( paymentSelectRef, function( v ) {
					setBillingField( 'payment_method', v );
				} );
				if ( typeof c === 'function' ) { cleanups.push( c ); }
			}, 0 );
			return function() {
				clearTimeout( tmr );
				for ( var i = 0; i < cleanups.length; i++ ) {
					try { cleanups[ i ](); } catch ( e ) {}
				}
			};
		}, [ orderType, productId ] );

		function setCreatePreviewTitle( label ) {
			var api = window.__wcaCalPreview;
			if ( api && api.setTitle ) {
				api.setTitle( ( recurringOn ? '\u21BB ' : '' ) + label );
			}
		}

		function clearSelectedCustomer() {
			setCustomerId( '' );
			setCustomerSearch( '' );
			setCreateAccount( false );
			setCreatePreviewTitle( t( 'guest', 'Guest' ) );
			setBilling( function( prev ) {
				return {
					first_name: '', last_name: '', company: '', address_1: '', address_2: '',
					city: '', postcode: '', country: '', state: '', email: '', phone: '', timezone: '',
					payment_method: prev.payment_method || '',
					transaction_id: prev.transaction_id || ''
				};
			} );
		}

		function fetchCustomerBilling( userId ) {
			if ( ! userId || ! ajaxUrl ) { return; }
			var fd = new FormData();
			fd.append( 'action', 'wc_appointments_get_customer_details' );
			fd.append( 'security', nonces.getCustomerDetails || '' );
			fd.append( 'user_id', userId );
			fetch( ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' } )
				.then( function( r ) { return r.json(); } )
				.then( function( resp ) {
					if ( ! resp || ! resp.success || ! resp.data ) { return; }
					var d = resp.data;
					var tz = d.timezone || '';
					setBilling( function( prev ) {
						return {
							first_name: d.first_name || '',
							last_name: d.last_name || '',
							company: d.company || '',
							address_1: d.address_1 || '',
							address_2: d.address_2 || '',
							city: d.city || '',
							postcode: d.postcode || '',
							country: d.country || '',
							state: d.state || '',
							email: d.email || '',
							phone: d.phone || '',
							timezone: tz,
							payment_method: prev.payment_method || '',
							transaction_id: prev.transaction_id || ''
						};
					} );
					setCreateAccount( false );
					setDetailsOpen( true );
					schedulePanelFit( customerDetailsRef, true );
					setTimeout( function() {
						panelHelpers.setEnhancedSelectValue( timezoneSelectRef, tz );
					}, 0 );
				} )
				.catch( function() {} )
				.finally( function() {
					scheduleCalculateCost();
				} );
		}

		// ── Price edit ──
		var createCurrency = integrationCurrency.displayCurrency || calCfg.currency || '';

		// Recurring preview prices feed the same footer path as single-appointment cost AJAX.
		useEffect( function() {
			if ( ! recurringOn ) {
				scheduleCalculateCost();
				return;
			}
			var total = parseFloat( recurringMeta.totalPrice ) || 0;
			var sub = parseFloat( recurringMeta.subtotal ) || 0;
			if ( total <= 0 ) {
				setCalculatedCost( '' );
				setCalculatedCostRaw( 0 );
				setCalculatedCostRawFull( 0 );
				return;
			}
			setCalculatedCostRaw( total );
			setCalculatedCostRawFull( sub > total ? sub : total );
			var html = sub > total + 0.000001
				? '<del class="description">' + fmtCurrency( sub, createCurrency ) + '</del> <span>' + fmtCurrency( total, createCurrency ) + '</span>'
				: fmtCurrency( total, createCurrency );
			setCalculatedCost( html );
		}, [ recurringOn, recurringMeta, createCurrency ] );

		// Footer raw_price includes Product Add-Ons; backend override is appointment base only (PAO summed separately).
		function wcaPanelPriceDecimals() {
			var dec = window.wcaPanel && window.wcaPanel.priceDecimals;
			return ( 'number' === typeof dec && dec >= 0 ) ? dec : 2;
		}
		function wcaFormatPriceForInput( num ) {
			var n = parseFloat( num );
			if ( isNaN( n ) || n < 0 ) {
				return '';
			}
			var dec = wcaPanelPriceDecimals();
			return n.toFixed( dec );
		}
		function panelAppointmentBaseRaw() {
			// raw_full_price is always the full appointment line; raw_price is deposit due when deposits apply.
			var raw = parseFloat( calculatedCostRawFull );
			if ( isNaN( raw ) || raw <= 0 ) {
				raw = parseFloat( calculatedCostRaw );
			}
			if ( isNaN( raw ) || raw <= 0 ) {
				return 0;
			}
			var ac = parseFloat( addonsCost );
			if ( ! isNaN( ac ) && ac > 0 ) {
				return Math.max( 0, raw - ac );
			}
			return raw;
		}
		function panelAppointmentEditPriceValue() {
			if ( overridePrice !== '' && overridePrice !== undefined && overridePrice !== null ) {
				return wcaFormatPriceForInput( overridePrice );
			}
			var baseRaw = panelAppointmentBaseRaw();
			return baseRaw > 0 ? wcaFormatPriceForInput( baseRaw ) : '';
		}
		function onPriceEditClick() {
			if ( wcaPanelPayDepositSelected() ) {
				return;
			}
			setPriceEditValue( panelAppointmentEditPriceValue() );
			setPriceEditing( true );
		}
		function onPriceEditCommit( val ) {
			if ( val === undefined ) { val = priceEditValue; }
			if ( '' === val || val === undefined || val === null ) {
				setOverridePrice( '' );
				setPriceEditValue( '' );
				setPriceEditing( false );
				scheduleCalculateCost();
				return;
			}
			var num = parseFloat( ( '' + val ).replace( ',', '.' ) );
			if ( ! isNaN( num ) && num >= 0 ) {
				var formatted = wcaFormatPriceForInput( num );
				setOverridePrice( formatted );
				setPriceEditValue( formatted );
			}
			setPriceEditing( false );
		}
		function onPriceEditKey( e ) {
			if ( 'Enter' === e.key ) {
				e.preventDefault();
				onPriceEditCommit( e.target ? e.target.value : priceEditValue );
			} else if ( 'Escape' === e.key ) {
				e.preventDefault();
				setOverridePrice( '' );
				setPriceEditValue( '' );
				setPriceEditing( false );
				scheduleCalculateCost();
			}
		}
		useEffect( function() {
			if ( ! priceEditing ) { return; }
			var t = setTimeout( function() {
				var el = priceInputRef.current;
				if ( el && typeof el.focus === 'function' ) {
					el.focus();
					if ( el.select ) { el.select(); }
				}
			}, 0 );
			return function() { clearTimeout( t ); };
		}, [ priceEditing ] );

		// If cost arrives while editing and there's no typed value yet, prefill full appointment base.
		useEffect( function() {
			if ( ! priceEditing ) { return; }
			if ( priceEditValue ) { return; }
			var prefill = panelAppointmentEditPriceValue();
			if ( prefill ) {
				setPriceEditValue( prefill );
			}
		}, [ priceEditing, calculatedCostRaw, calculatedCostRawFull, overridePrice, priceEditValue, addonsCost ] );

		// Success replaces the tall create form; remasure so fill-shell does not keep the old height.
		useLayoutEffect( function() {
			if ( ! successData ) { return; }
			schedulePanelFit();
		}, [ successData ] );

		// ── Status options ──
		var statusMap = i18n.statuses || {};
		var createStatuses = [ 'confirmed', 'unpaid', 'paid', 'pending-confirmation', 'cancelled', 'complete' ];

		// ── Billing field helper ──
		function setBillingField( field, value ) {
			setBilling( function( prev ) {
				var next = Object.assign( {}, prev );
				next[ field ] = value;
				return next;
			} );
		}

		// ── Submit handler ──
		function handleSubmit() {
			if ( isSubmitting ) { return; }

			// Busy-state guard: warn if add-ons are still loading.
			if ( addonsLoading ) {
				var busyMsg = t( 'loadingInProgress', 'Background tasks are still running' ) + ' (' + t( 'loadingAddons', 'Add-ons' ) + ')';
				if ( ! window.confirm( busyMsg + ' \u2014 ' + t( 'proceedAnyway', 'Proceed anyway?' ) ) ) {
					return;
				}
			}

			function flashDetailsError( msg ) {
				setSubmitError( msg );
				setAddonsError( '' );
				schedulePanelFit( detailsSectionRef, true );
			}
			if ( ! allowUnavailableSubmit( availStatus, availMessage, cfg.allowUnavailable, t, flashDetailsError ) ) {
				return;
			}

			if ( ! productId ) {
				setSubmitError( t( 'productRequired', 'This field is required.' ) );
				setAddonsError( '' );
				return;
			}
			if ( hasLocations && 'customer_choice' === locationMode && Object.keys( locationMap || {} ).length > 1 && ! locationId ) {
				setSubmitError( t( 'locationRequired', 'Please choose a location.' ) );
				setAddonsError( '' );
				return;
			}
			var resourceAssignment = ( detailsLive && productDetails.resource_assignment ) || ( preloadRow && preloadRow.resource_assignment ) || '';
			if ( hasResources && 'customer' === resourceAssignment && Object.keys( resourceMap || {} ).length > 1 && ! resourceId ) {
				setSubmitError( t( 'resourceRequired', 'Please choose a resource.' ) );
				setAddonsError( '' );
				return;
			}
			var dtErr = getDateTimeSubmitError();
			if ( dtErr ) {
				dateTimeErrRef.current = true;
				flashDetailsError( dtErr );
				return;
			}

			// Required add-ons validation: PaoValidation shows errors below required fields; we show top notice "Please select required add-ons."
			if ( hasRequiredAddons && ! checkAddonsValid() ) {
				setAddonsOpen( true );
				schedulePanelFit( addonsSectionRef, true );
				setAddonsError( t( 'requiredAddons', 'Please select required add-ons.' ) );
				setSubmitError( '' );
				return;
			}
			setAddonsError( '' );

			dateTimeErrRef.current = false;
			setSubmitError( '' );
			setIsSubmitting( true );

			var fd = new FormData();
			fd.append( 'action', 'wc_appointments_create_appointment' );
			var calCfg = window.wcAppointmentsReactCalendar;
			fd.append( 'wca_admin_create_context', ( calCfg && calCfg.adminCalendarPage ) ? 'calendar' : 'standalone' );
			fd.append( 'nonce', nonces.create || '' );
			fd.append( 'appointment_product_id', productId );
			fd.append( 'appointment_customer_id', customerId || '0' );
			fd.append( 'appointment_staff_id', staffId || '0' );
			fd.append( 'appointment_location_id', locationId || '0' );
			fd.append( 'appointment_resource_id', resourceId || '0' );
			fd.append( 'appointment_status', formStatus );
			fd.append( 'appointment_customer_status', 'expected' );
			fd.append( 'order_type', orderType );
			fd.append( 'quantity', String( formQty ) );

			if ( recurringOn && recurringMeta.rrule ) {
				fd.append( 'wca_recurring_enabled', '1' );
				fd.append( 'wca_rrule', recurringMeta.rrule );
				if ( recurringMeta.schedule ) {
					fd.append( 'wca_recurring_schedule', JSON.stringify( recurringMeta.schedule ) );
				}
			}

			if ( productDetails && productDetails.wc_deposits ) {
				var wdep = productDetails.wc_deposits;
				if ( wdep.forced || 'yes' === wcDepositOption ) {
					fd.append( 'wc_deposit_option', 'yes' );
					if ( 'plan' === wdep.type && wcDepositPlanId ) {
						fd.append( 'wc_deposit_payment_plan', wcDepositPlanId );
					}
				} else {
					fd.append( 'wc_deposit_option', 'no' );
				}
			}

			// Only send committed override (full appointment base). Do not send in-progress footer/deposit edit values.
			if ( overridePrice !== '' && overridePrice !== undefined && overridePrice !== null ) {
				var overrideNum = parseFloat( ( '' + overridePrice ).replace( ',', '.' ) );
				if ( ! isNaN( overrideNum ) && overrideNum >= 0 ) {
					fd.append( 'appointment_override_price', String( overrideNum ) );
					var panelCfgOv = window.wcaPanel || {};
					if ( ! panelCfgOv.pricesIncludeTax ) {
						fd.append( 'appointment_override_price_excl_tax', '1' );
					}
				}
			}

			if ( orderType === 'existing' && existingOrderId ) {
				fd.append( 'appointment_order_id', existingOrderId );
			}

			// Timezone conversion: admin-TZ → site-TZ
			var dateVal = formDate;
			var timeFrom = formTimeFrom || '00:00';
			var timeTo = formTimeTo || '23:59';

			if ( utils && utils.convertAdminStringsToSiteTimezone ) {
				var convF = utils.convertAdminStringsToSiteTimezone( dateVal, timeFrom );
				var convT = utils.convertAdminStringsToSiteTimezone( dateVal, timeTo );
				dateVal = convF.date;
				timeFrom = convF.time;
				timeTo = convT.time;
			}

			fd.append( 'appointment_date', dateVal );
			fd.append( 'appointment_time_from', timeFrom );
			fd.append( 'appointment_time_to', timeTo );
			if ( endDaysOffset > 0 ) {
				fd.append( 'appointment_end_days_offset', String( endDaysOffset ) );
			}

			// Match wc_appointments_calculate_costs: slot grid instant so server base cost matches footer (avoid 0/wrong quote).
			var submitSlotTs = parseInt( slotStartTsRef.current, 10 );
			if ( submitSlotTs > 86400 ) {
				fd.append( 'wc_appointments_field_start_date_timestamp', String( submitSlotTs ) );
			}

			if ( showDateRange ) {
				var dateFromVal = formDateFrom;
				var dateToVal = formDateTo || formDateFrom;
				if ( utils && utils.convertAdminStringsToSiteTimezone ) {
					var tzConf2 = utils.getTimezoneConfig ? utils.getTimezoneConfig() : {};
					if ( tzConf2.hasDifferentTz ) {
						// Note: conversion removed to maintain site-time consistency
					}
				}
				fd.append( 'appointment_date_from', dateFromVal );
				fd.append( 'appointment_date_to', dateToVal );
			} else if ( showMonthRange ) {
				fd.append( 'appointment_month_from', formMonthFrom );
				fd.append( 'appointment_month_to', formMonthTo || formMonthFrom );
			}

			// Billing fields
			if ( orderType === 'new' ) {
				var billingFields = [ 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'postcode', 'country', 'state', 'email', 'phone', 'payment_method', 'transaction_id' ];
				for ( var bi = 0; bi < billingFields.length; bi++ ) {
					var bk = billingFields[ bi ];
					if ( billing[ bk ] ) {
						fd.append( '_billing_' + bk, billing[ bk ] );
					}
				}
				if ( createAccount ) {
					fd.append( 'appointment_create_account', '1' );
				}
				if ( billing.timezone ) {
					fd.append( 'appointment_local_timezone', billing.timezone );
				}
			}

			// Add-on fields from injected addons container
			if ( addonsContainerRef.current ) {
				var addonInputs = addonsContainerRef.current.querySelectorAll( 'input[name], select[name], textarea[name]' );
				for ( var ai = 0; ai < addonInputs.length; ai++ ) {
					var el = addonInputs[ ai ];
					var name = el.getAttribute( 'name' );
					if ( ! name ) { continue; }
					if ( el.type === 'checkbox' || el.type === 'radio' ) {
						if ( el.checked ) {
							fd.append( name, el.value || '1' );
						}
					} else if ( el.tagName === 'SELECT' && el.multiple ) {
						for ( var oi = 0; oi < el.options.length; oi++ ) {
							if ( el.options[ oi ].selected ) {
								fd.append( name, el.options[ oi ].value );
							}
						}
					} else if ( el.type && 'file' === el.type.toLowerCase() ) {
						// Append File blobs so PHP receives $_FILES; el.value is only the fake path (e.g. C:\fakepath\...).
						if ( el.files && el.files.length ) {
							for ( var fi = 0; fi < el.files.length; fi++ ) {
								fd.append( name, el.files[ fi ] );
							}
						}
					} else {
						fd.append( name, el.value || '' );
					}
				}
			}

			fetch( ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' } )
				.then( function( r ) { return r.json(); } )
				.then( function( response ) {
					setIsSubmitting( false );
					if ( response && response.success ) {
						cfg.defaultCreateStatus = formStatus;
						setSuccessData( response.data || {} );
						onCreated( response.data );
					} else {
						var errMsg = ( response && response.data ) ? ( 'string' === typeof response.data ? response.data : ( response.data.message || '' ) ) : '';
						setSubmitError( errMsg || t( 'createFailed', 'An error occurred. Please try again.' ) );
					}
				} )
				.catch( function() {
					setIsSubmitting( false );
					setSubmitError( t( 'createFailed', 'An error occurred. Please try again.' ) );
				} );
		}

		// ── Success state: title, lines, pencil → REST load + edit mode (parent)
		if ( successData ) {
			var createdApptId = successData.appointment_id ? parseInt( successData.appointment_id, 10 ) : 0;
			var createdOrderId = successData.order_id ? parseInt( successData.order_id, 10 ) : 0;
			var createdSeriesId = successData.series_id ? parseInt( successData.series_id, 10 ) : 0;
			var createdSeriesCount = successData.series_count ? parseInt( successData.series_count, 10 ) : 0;
			var productNameLabel = ( productDetails && productDetails.formatted_name ) || '';
			if ( ! productNameLabel && productId ) {
				for ( var pi = 0; pi < productOptions.length; pi++ ) {
					if ( productOptions[ pi ].value === String( productId ) ) {
						productNameLabel = productOptions[ pi ].label;
						break;
					}
				}
			}
			var scheduleStr = successData.success_when
				? String( successData.success_when )
				: formatCreateSuccessWhen( formDate, formTimeFrom, formTimeTo, formDateFrom, formDateTo, formMonthFrom, formMonthTo );
			var detailLineNodes = [];
			if ( productNameLabel ) {
				detailLineNodes.push( h( 'div', { key: 'p', className: 'wca-create-success-line' }, productNameLabel ) );
			}
			if ( createdSeriesCount > 0 ) {
				detailLineNodes.push( h( 'div', { key: 'sc', className: 'wca-create-success-line' },
					createdSeriesCount + ' ' + t( 'appointmentsCreated', 'appointments created' )
				) );
			}
			if ( scheduleStr && ! createdSeriesId ) {
				var scheduleLineKids = [ scheduleStr ];
				var succAdmTz = calCfg.adminTimezone || '';
				var succSiteTz = calCfg.siteTimezone || '';
				var succTzHtml = ( succAdmTz && succSiteTz && succAdmTz !== succSiteTz && calCfg.adminTimezoneHtml )
					? String( calCfg.adminTimezoneHtml ).trim()
					: '';
				if ( succTzHtml ) {
					scheduleLineKids.push( h( 'span', { key: 'succ-tz', dangerouslySetInnerHTML: { __html: succTzHtml } } ) );
				}
				detailLineNodes.push( h( 'div', { key: 's', className: 'wca-create-success-line' }, scheduleLineKids ) );
			}
			if ( createdApptId ) {
				detailLineNodes.push( h( 'div', { key: 'a', className: 'wca-create-success-line wca-create-success-line--meta' },
					formatAppointmentWithId( createdApptId )
				) );
			}
			if ( canViewOrders && createdOrderId ) {
				detailLineNodes.push( h( 'div', { key: 'o', className: 'wca-create-success-line wca-create-success-line--meta' },
					t( 'orderType', 'Order' ) + ' #' + createdOrderId
				) );
			}
			var successTitle = createdSeriesId
				? t( 'seriesCreated', 'Series created' )
				: t( 'appointmentCreated', 'Appointment created successfully.' );
			return h( Fragment, null,
				h( 'div', { className: 'wca-panel-body-scroll' },
					h( 'div', { className: 'wca-create-success' },
						h( 'div', { className: 'wca-create-success-icon' }, wpIcon( h, 'check', 'wca-create-success-check' ) ),
						h( 'div', { className: 'wca-create-success-title' }, successTitle ),
						detailLineNodes.length ? h( 'div', { className: 'wca-create-success-lines' }, detailLineNodes ) : null,
						createdApptId ? h( 'div', { className: 'wca-create-success-edit' },
							h( 'button', {
								type: 'button',
								className: 'wca-panel-icon-btn',
								title: t( 'editAppointment', 'Edit Appointment' ),
								'aria-label': t( 'editAppointment', 'Edit Appointment' ),
								onClick: function() { onOpenEditInline( createdApptId ); }
							}, wpIcon( h, 'pencil', null ) )
						) : null
					)
				)
			);
		}

		// ── Create status section (delegated to panelStatus module) ──
		var createStatusSectionNode = panelStatus.StatusSegmented( {
			value: formStatus,
			onChange: setFormStatus,
			statuses: createStatuses,
			statusMap: statusMap,
			pinnedStatuses: { 'confirmed': 1, 'cancelled': 1 },
			t: t,
			humanizeStatus: humanizeStatus
		} );

		// ── Render helper functions ──────────────────────────────────
		// Plain functions (not components) that close over CreateContent state.
		// Extracted for readability — createBody becomes a scannable list of section calls.

		function renderProductSection() {
			return h( 'div', { className: 'wca-form-section wca-form-product-section' },
				h( 'div', { className: 'wca-form-row wca-form-product-row' },
					ti( {
						id: 'wca-create-product',
						label: t( 'product', 'Product' ),
						value: productId,
						mod: 'grow',
						tag: 'select',
						ref: productSelectRef,
						onChange: function( e ) { setProductId( e.target.value ); },
						children: [].concat(
							productId ? [] : [ h( 'option', { key: '', value: '' }, '' ) ],
							productOptions.map( function( opt ) {
								return h( 'option', { key: opt.value, value: opt.value }, opt.label );
							} )
						)
					} ),
					productId ? ti( {
						id: 'wca-create-qty',
						label: t( 'qty', 'Qty' ),
						value: String( formQty ),
						type: 'number',
						mod: 'qty',
						name: 'quantity',
						min: '1',
						step: '1',
						onChange: function( e ) {
						var v = parseInt( e.target.value, 10 );
						setFormQty( isNaN( v ) || v < 1 ? 1 : v );
						}
					} ) : null
				)
			);
		}

		function renderLocationSection() {
			if ( ! productId || ! hasLocations ) { return null; }
			var locKeys = Object.keys( locationMap || {} );
			if ( ! locKeys.length ) { return null; }
			var locCurrency = createCurrency || createOptCurrency;
			return h( 'div', { className: 'wca-form-section wca-form-location-section' },
				h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-create-location',
						label: locationLabel,
						value: locationId,
						mod: 'grow',
						tag: 'select',
						ref: locationSelectRef,
						required: 'customer_choice' === locationMode && locKeys.length > 1,
						disabled: 'fixed' === locationMode || 'hidden' === locationMode || 1 === locKeys.length,
						onChange: function( e ) { onCreateLocationChange( e.target.value ); },
						children: [ h( 'option', { key: '', value: '' }, '' ) ].concat(
							locKeys.map( function( lid ) {
								return h( 'option', { key: lid, value: lid }, String( locationMap[ lid ] || lid ) + additionalCostSuffix( locationCosts[ lid ], locCurrency ) );
							} )
						)
					} )
				)
			);
		}

		function renderResourceSection() {
			if ( ! productId || ! hasResources || ! createResourceOptions.length ) {
				return null;
			}
			var resourceAssignment = ( detailsLive && productDetails.resource_assignment ) || ( preloadRow && preloadRow.resource_assignment ) || '';
			var resourcePickRequired = 'customer' === resourceAssignment && createResourceOptions.length > 1;
			return h( 'div', { className: 'wca-form-section wca-form-resource-section' },
				h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-create-resource',
						label: resourceLabel,
						value: resourceId,
						mod: 'grow',
						tag: 'select',
						ref: resourceSelectRef,
						required: resourcePickRequired,
						disabled: 1 === createResourceOptions.length,
						onChange: function( e ) { setResourceId( e.target.value || '' ); },
						// Empty option text: floating label is the placeholder (non-empty empty-value text overlaps the label).
						children: [ h( 'option', { key: '', value: '' }, '' ) ].concat(
							createResourceOptions.map( function( opt ) {
								return h( 'option', { key: opt.value, value: opt.value }, opt.label );
							} )
						)
					} )
				)
			);
		}

		function renderStaffSection() {
			if ( ! productId || ! hasStaff ) { return null; }
			return h( 'div', { className: 'wca-form-section wca-form-staff-section' },
				h( 'div', { className: 'wca-form-row' },
					isAllStaff ? ti( {
						id: 'wca-create-staff',
						label: t( 'staff', 'Staff' ),
						value: '',
						forceActive: true,
						disabled: true,
						mod: 'grow',
						tag: 'select',
						readOnly: true,
						children: [ h( 'option', { key: '', value: '' }, t( 'allStaffAssigned', 'All staff assigned' ) + ': ' + staffNames.join( ', ' ) ) ]
					} ) : ti( {
						id: 'wca-create-staff',
						label: t( 'staff', 'Staff' ),
						value: staffId,
						mod: 'grow',
						tag: 'select',
						ref: staffSelectRef,
						onChange: function( e ) { setStaffId( e.target.value ); },
						children: [ h( 'option', { key: '', value: '' }, '' ),
						staffOptions.map( function( opt ) {
							return h( 'option', { key: opt.value, value: opt.value }, opt.label );
						} ) ]
					} )
				)
			);
		}

		function renderOrderSection() {
			if ( ! productId ) { return null; }
			return h( 'div', { className: 'wca-form-section wca-form-order-section' },
				h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-create-order-type',
						label: t( 'orderType', 'Order' ),
						value: orderType,
						mod: 'grow',
						tag: 'select',
						ref: orderTypeSelectRef,
						onChange: function( e ) { setOrderType( e.target.value ); setExistingOrderId( '' ); setOrderSearch( '' ); },
						children: [ h( 'option', { key: 'new', value: 'new' }, t( 'newOrder', 'Create new order' ) ),
						h( 'option', { key: 'existing', value: 'existing' }, t( 'existingOrder', 'Add to an existing order' ) ) ]
					} )
				),
				orderType === 'existing' ? h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-create-existing-order',
						label: t( 'existingOrderLabel', 'Existing order' ),
						value: existingOrderId,
						forceActive: !! existingOrderId,
						mod: 'grow',
						control: existingOrderId ? h( 'div', {
							id: 'wca-create-existing-order',
							className: 'wca-create-customer-selected',
							'aria-labelledby': 'wca-create-existing-order-label'
						},
							h( 'span', null, orderSearch || ( '#' + existingOrderId ) ),
							h( 'button', {
								type: 'button',
								className: 'wca-create-customer-clear',
								onClick: function() { setExistingOrderId( '' ); setOrderSearch( '' ); },
								title: t( 'clear', 'Clear' )
							}, wpIcon( h, 'closeSmall', null ) )
						) : h( 'select', {
							id: 'wca-create-existing-order',
							ref: existingOrderSelectRef,
							className: 'wca-field__control',
							'aria-labelledby': 'wca-create-existing-order-label'
						},
							h( 'option', { key: '', value: '' }, '' )
						)
					} )
				) : h( 'div', { className: 'wca-form-row' },
					ti( {
						id: 'wca-create-billing-payment',
						label: t( 'paymentMethod', 'Payment method' ),
						value: billing.payment_method,
						mod: 'half',
						tag: 'select',
						ref: paymentSelectRef,
						onChange: function( e ) { setBillingField( 'payment_method', e.target.value ); },
						children: [ h( 'option', { key: '', value: '' }, '' ),
							( cfg.paymentMethods || [] ).map( function( pm ) {
								return h( 'option', { key: pm.id, value: pm.id }, pm.title );
							} ) ]
					} ),
					ti( {
						id: 'wca-create-billing-transaction-id',
						label: t( 'transactionId', 'Transaction ID' ),
						value: billing.transaction_id,
						mod: 'half',
						type: 'text',
						onChange: function( e ) { setBillingField( 'transaction_id', e.target.value ); }
					} )
				)
			);
		}

		function customerCardTitle() {
			if ( detailsOpen ) {
				return t( 'customer', 'Customer' );
			}
			var name = ( ( billing.first_name || '' ) + ' ' + ( billing.last_name || '' ) ).trim();
			return name || billing.email || panelHelpers.customerNameFromSelectLabel( customerSearch ) || t( 'customer', 'Customer' );
		}

		function renderCustomerSearchControl() {
			return ti( {
				id: 'wca-create-customer',
				label: t( 'guest', 'Guest' ),
				forceActive: !! customerId,
				mod: 'grow',
				control: customerId ? h( 'div', {
					id: 'wca-create-customer',
					className: 'wca-create-customer-selected',
					'aria-labelledby': 'wca-create-customer-label'
				},
					h( 'span', null, customerSearch || ( '#' + customerId ) ),
					h( 'button', {
						type: 'button',
						className: 'wca-create-customer-clear',
						onClick: clearSelectedCustomer,
						title: t( 'clear', 'Clear' )
					}, wpIcon( h, 'closeSmall', null ) )
				) : h( 'select', {
					id: 'wca-create-customer',
					ref: customerSelectRef,
					className: 'wca-field__control wc-customer-search',
					'aria-labelledby': 'wca-create-customer-label',
					defaultValue: ''
				},
					h( 'option', { key: '', value: '' }, '' )
				)
			} );
		}

		function renderCustomerSection() {
			if ( ! productId ) { return null; }
			// Existing order: search only (order already has contact).
			if ( orderType !== 'new' ) {
				return h( 'div', { className: 'wca-form-section wca-form-customer-section' },
					h( 'div', { className: 'wca-form-row' }, renderCustomerSearchControl() )
				);
			}
			return h( 'div', {
				ref: customerDetailsRef,
				className: 'wca-expansion wca-form-customer-section' + ( detailsOpen ? ' wca-expansion--expanded' : '' )
			},
				formExpansionHeader( h, {
					open: detailsOpen,
					onOpenChange: setDetailsOpen,
					sectionRef: customerDetailsRef
				},
					h( 'span', { className: 'wca-expansion__title' }, customerCardTitle() ),
					expansionTrailingAction( h, detailsOpen, t )
				),
				detailsOpen ? h( 'div', { className: 'wca-expansion__body' },
					h( 'div', { className: 'wca-form-row' }, renderCustomerSearchControl() ),
					h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-billing-first-name',
							label: t( 'firstName', 'First name' ),
							value: billing.first_name,
							mod: 'half',
							type: 'text',
							onChange: function( e ) { setBillingField( 'first_name', e.target.value ); }
						} ),
						ti( {
							id: 'wca-create-billing-last-name',
							label: t( 'lastName', 'Last name' ),
							value: billing.last_name,
							mod: 'half',
							type: 'text',
							onChange: function( e ) { setBillingField( 'last_name', e.target.value ); }
						} )
					),
					h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-billing-company',
							label: t( 'company', 'Company' ),
							value: billing.company,
							mod: 'grow',
							type: 'text',
							onChange: function( e ) { setBillingField( 'company', e.target.value ); }
						} )
					),
					h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-billing-address-1',
							label: t( 'address1', 'Address line 1' ),
							value: billing.address_1,
							mod: 'grow',
							type: 'text',
							onChange: function( e ) { setBillingField( 'address_1', e.target.value ); }
						} )
					),
					h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-billing-address-2',
							label: t( 'address2', 'Address line 2' ),
							value: billing.address_2,
							mod: 'grow',
							type: 'text',
							onChange: function( e ) { setBillingField( 'address_2', e.target.value ); }
						} )
					),
					h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-billing-city',
							label: t( 'city', 'City' ),
							value: billing.city,
							mod: 'half',
							type: 'text',
							onChange: function( e ) { setBillingField( 'city', e.target.value ); }
						} ),
						ti( {
							id: 'wca-create-billing-postcode',
							label: t( 'postcode', 'Postcode / ZIP' ),
							value: billing.postcode,
							mod: 'half',
							type: 'text',
							onChange: function( e ) { setBillingField( 'postcode', e.target.value ); }
						} )
					),
					h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-billing-country',
							label: t( 'country', 'Country / Region' ),
							value: billing.country,
							mod: 'half',
							tag: 'select',
							ref: billingCountrySelectRef,
							onChange: function( e ) {
								var v = e.target.value;
								setBilling( function( prev ) {
									var n = Object.assign( {}, prev );
									n.country = v;
									n.state = '';
									return n;
								} );
							},
							children: [ h( 'option', { key: '', value: '' }, '' ),
							billingCountryCodesList.map( function( code ) {
								return h( 'option', { key: code, value: code }, billingCountriesMap[ code ] );
							} ) ]
						} ),
						ti( {
							id: 'wca-create-billing-state',
							label: t( 'state', 'State / County' ),
							value: billing.state,
							mod: 'half',
							control: billingStateIsDropdown
								? h( 'select', {
									id: 'wca-create-billing-state',
									ref: billingStateSelectRef,
									className: 'wca-field__control',
									'aria-labelledby': 'wca-create-billing-state-label',
									value: billing.state,
									onChange: function( e ) { setBillingField( 'state', e.target.value ); }
								},
								h( 'option', { key: '', value: '' }, '' ),
								billingStateKeys.map( function( sk ) {
									return h( 'option', { key: sk, value: sk }, billingStatesForCountry[ sk ] );
								} )
								)
								: h( 'input', {
									id: 'wca-create-billing-state',
									type: 'text',
									className: 'wca-field__control',
									'aria-labelledby': 'wca-create-billing-state-label',
									value: billing.state,
									onChange: function( e ) { setBillingField( 'state', e.target.value ); }
								} )
						} )
					),
					h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-billing-email',
							label: t( 'emailAddress', 'Email address' ),
							value: billing.email,
							mod: 'half',
							type: 'email',
							onChange: function( e ) { setBillingField( 'email', e.target.value ); }
						} ),
						ti( {
							id: 'wca-create-billing-phone',
							label: t( 'phone', 'Phone' ),
							value: billing.phone,
							mod: 'half',
							type: 'tel',
							onChange: function( e ) { setBillingField( 'phone', e.target.value ); }
						} )
					),
					cfg.timezoneOptionsHtml ? h( 'div', { className: 'wca-form-row' },
						ti( {
							id: 'wca-create-customer-timezone',
							label: t( 'timezone', 'Timezone' ),
							value: billing.timezone,
							forceActive: true,
							mod: 'grow',
							tag: 'select',
							ref: timezoneSelectRef,
							onChange: function( e ) { setBillingField( 'timezone', e.target.value || '' ); },
							children: [ h( 'option', { key: '', value: '' }, '' ) ]
						} )
					) : null,
					! customerId ? h( 'div', { className: 'wca-form-row' },
						h( 'label', { className: 'wca-form-checkbox-label' },
							h( 'input', { type: 'checkbox', checked: createAccount, onChange: function( e ) { setCreateAccount( e.target.checked ); } } ),
							h( 'span', null, t( 'createAccount', 'Create an account for this customer' ) )
						)
					) : null
				) : null
			);
		}

		function renderDepositsSection() {
			if ( ! productId || ! productDetails || ! productDetails.wc_deposits ) {
				return null;
			}
			var wd = productDetails.wc_deposits;
			var forced = !! wd.forced;
			var paying = forced || 'yes' === wcDepositOption;
			var showPlans = 'plan' === wd.type && wd.plans && wd.plans.length && paying;
			var hintHtml = wd.formatted_hint || '';
			var hintInHeader = !!( hintHtml && ! showPlans && wcaDepositsHintFitsHeaderAside( hintHtml ) );
			var body = [];

			if ( forced ) {
				body.push( h( 'p', { className: 'description', key: 'req' }, t( 'depositRequired', 'A deposit is required for this product.' ) ) );
			} else {
				body.push( h( 'ul', { className: 'wc-deposits-option', key: 'opts' },
					[ [ 'yes', t( 'payDeposit', 'Pay deposit' ) ], [ 'no', t( 'payInFull', 'Pay in full' ) ] ].map( function( opt ) {
						var id = 'wca-deposit-opt-' + opt[ 0 ];
						return h( 'li', { key: opt[ 0 ] },
							h( 'input', { type: 'radio', name: 'wca_wc_deposit_option', id: id, checked: opt[ 0 ] === wcDepositOption, onChange: function() { setWcDepositOption( opt[ 0 ] ); } } ),
							h( 'label', { htmlFor: id }, opt[ 1 ] )
						);
					} )
				) );
			}
			if ( paying ) {
				body.push( h( 'p', { className: 'description wca-deposits-price-hint', key: 'price' },
					t( 'depositPriceHint', 'Deposit due follows the product deposit settings. To set a custom charge for this booking, choose Pay in full and use Edit price in the footer.' )
				) );
			}
			if ( hintHtml && ! showPlans && ! hintInHeader ) {
				body.push( h( 'div', { className: 'wc-deposits-payment-description description', key: 'hint', dangerouslySetInnerHTML: { __html: hintHtml } } ) );
			}
			if ( showPlans ) {
				body.push( h( 'ul', { className: 'wc-deposits-payment-plans', key: 'plans' },
					wd.plans.map( function( pl ) {
						var pid = 'wca-deposit-plan-' + pl.id;
						return h( 'li', { key: pl.id, className: 'wc-deposits-payment-plan' },
							h( 'input', { type: 'radio', name: 'wca_wc_deposit_plan', id: pid, value: String( pl.id ), checked: String( pl.id ) === String( wcDepositPlanId ), onChange: function() { setWcDepositPlanId( String( pl.id ) ); } } ),
							h( 'label', { htmlFor: pid }, h( 'strong', null, pl.name || ( '#' + pl.id ) ) )
						);
					} )
				) );
			}

			return h( 'div', { className: 'wca-expansion wca-expansion--expanded wca-form-deposits-section' },
				h( 'div', { className: 'wca-expansion__header', role: 'presentation' },
					h( 'span', { className: 'wca-expansion__title' }, t( 'depositPayment', 'Deposit payment' ) ),
					hintInHeader
						? h( 'span', { className: 'wca-slots-count wca-deposits-payment-aside', dangerouslySetInnerHTML: { __html: hintHtml } } )
						: null
				),
				h( 'div', { className: 'wca-expansion__body wc-deposits-wrapper' }, body )
			);
		}

		function renderAddonsSection() {
			if ( ! productId || ! hasAddons ) { return null; }
			return h( 'div', { ref: addonsSectionRef, className: 'wca-expansion wca-form-addons-section' + ( addonsOpen ? ' wca-expansion--expanded' : '' ) + ( hasRequiredAddons ? ' wca-form-addons-section--required' : '' ) },
				formExpansionHeader( h, {
					open: addonsOpen,
					onOpenChange: setAddonsOpen,
					sectionRef: addonsSectionRef
				},
					h( 'span', { className: 'wca-expansion__title' }, t( 'addons', 'Add-ons' ) ),
					( window.wcaPanel && window.wcaPanel.taxEnabled ) ? h( 'span', { className: 'wca-footer-price-tax-hint wca-addons-tax-hint' }, ( window.wcaPanel.pricesIncludeTax ? t( 'priceInclTaxShort', '(incl. tax)' ) : t( 'priceExclTaxShort', '(ex. tax)' ) ) ) : null,
					hasRequiredAddons ? h( 'span', { className: 'wca-form-required-asterisk' }, ' *' ) : null,
					( addonsLoading || ! addonsHtml ) ? h( 'span', { className: 'spinner is-active' } ) : null,
					expansionTrailingAction( h, addonsOpen, t )
				),
				h( 'div', { className: 'wca-expansion__body wca-form-addons-body' },
					addonsError ? h( 'div', { className: 'wca-edit-error wca-addons-error' }, addonsError ) : null,
					h( 'div', { className: 'wc-appointment-addons-container woocommerce' },
						h( 'div', { ref: addonsContainerRef } )
					)
				)
			);
		}

		// ── Render form — scrollable body + footer (footer stays at bottom via flex) ──
		var createBody = h( 'div', { className: 'wca-panel-body-scroll' },
			renderProductSection(),
			renderLocationSection(),
			locationPickRequired ? h( 'div', { className: 'wca-slots-notice wca-slots-notice--info' }, t( 'locationGate', 'Choose a location to see available times.' ) ) : null,
			( ! locationPickRequired && createResourcePickRequired ) ? h( 'div', { className: 'wca-slots-notice wca-slots-notice--info' }, t( 'resourceGate', 'Choose a resource to see available times.' ) ) : null,
			renderResourceSection(),
			renderStaffSection(),

			// ── Details section: date/time ──
			( function renderDateTimeSection() {
				if ( ! productId ) { return null; }
				function openBrowsePanel() {
					setMiniCalLoading( true );
					setBrowseOpen( true );
					schedulePanelFit( browseSectionRef, true );
					// Month/strip (+ focus-day slots) load via syncOpenBrowseCal; details wait until miniCalLoading clears.
				}
				function openBrowseOnFocus() {
					if ( slotsContextPending || ! createShouldOpenBrowseOnFocus() ) {
						return;
					}
					openBrowsePanel();
				}
				var dateErr = !! submitError && (
					( showTimeFields && ! formDate ) ||
					( showDateRange && ! formDateFrom ) ||
					( showMonthRange && ! formMonthFrom )
				);
				var timeErr = !! submitError && showTimeFields && !! formDate && (
					! formTimeFrom || ! formTimeTo || ( formTimeFrom === formTimeTo && endDaysOffset < 1 )
				);
				return h( Fragment, null,
				h( 'div', { ref: detailsSectionRef, className: 'wca-form-section wca-form-details-section' },
					h( 'div', { className: 'wca-form-row wca-form-datetime-row' + ( 'checking' === availStatus ? ' wca-form-datetime-row--checking' : '' ) + ( 'unavailable' === availStatus ? ' wca-form-datetime-row--unavailable' : '' ), 'aria-busy': 'checking' === availStatus ? 'true' : undefined },
						h( 'div', { className: 'wca-form-datetime-fields' },
							// Standard date + time range
							! showDateRange && ! showMonthRange ? ( ( showTimeFields && endDaysOffset > 0 ) ? h( 'div', { className: 'wca-form-overnight-grid' },
								ti( {
						id: 'wca-create-date',
									label: t( 'date', 'Date' ),
						value: formDate,
									mod: 'date',
						type: 'date',
						required: true,
						error: dateErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						patchSlotStartTs( 0 );
						selectedSlotSiteTimeRef.current = '';
						selectedSlotSiteDateRef.current = '';
						selectedSlotAdminDateRef.current = '';
						setFormDate( v );
						if ( v && endDaysOffset > 0 ) {
						try {
						var dt = new Date( v.replace( /-/g, '/' ) );
						dt.setDate( dt.getDate() + endDaysOffset );
						setFormDateTo( dt.getFullYear() + '-' + ( '0' + ( dt.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + dt.getDate() ).slice( -2 ) );
						} catch ( _e ) {}
						}
						if ( browseOpen && v ) { loadDaySlots( v ); }
						}
					} ),
								ti( {
						id: 'wca-create-time-from',
									label: t( 'from', 'From' ),
						value: formTimeFrom,
									mod: 'time',
						type: 'time',
						disabled: createTimeLocked,
						error: timeErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						selectedSlotSiteTimeRef.current = '';
						selectedSlotSiteDateRef.current = '';
						selectedSlotAdminDateRef.current = '';
						patchSlotStartTs( 0 );
						setFormTimeFrom( v );
						applyCombinedDurationToEnd( v, true );
						}
					} ),
								ti( {
						id: 'wca-create-date-to',
										label: t( 'endDate', 'End date' ),
										labelAddon: h( 'span', { className: 'wca-overnight-badge', title: t( 'endsNextDay', 'Ends on a different day' ) }, '+' + endDaysOffset + 'd' ),
						value: formDateTo || ( function() {
						if ( ! formDate ) { return ''; }
						var dt = new Date( formDate.replace( /-/g, '/' ) );
						dt.setDate( dt.getDate() + endDaysOffset );
						return dt.getFullYear() + '-' + ( '0' + ( dt.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + dt.getDate() ).slice( -2 );
						} )(),
										mod: 'date',
						disabled: true,
						type: 'date',
						readOnly: true
					} ),
								ti( {
						id: 'wca-create-time-to',
									label: t( 'to', 'To' ),
						value: formTimeTo,
									mod: 'time',
						type: 'time',
						disabled: createTimeLocked,
						error: timeErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) { setEndDaysOffset( 0 ); setFormTimeTo( e.target.value ); }
					} )
							) : h( Fragment, null,
								ti( {
						id: 'wca-create-date',
									label: t( 'date', 'Date' ),
						value: formDate,
									mod: 'date',
						type: 'date',
						required: true,
						error: dateErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						patchSlotStartTs( 0 );
						selectedSlotSiteTimeRef.current = '';
						selectedSlotSiteDateRef.current = '';
						selectedSlotAdminDateRef.current = '';
						setFormDate( v );
						if ( browseOpen && v ) {
						loadDaySlots( v );
						}
						}
					} ),
								showTimeFields ? h( 'div', { className: 'wca-form-time-range' },
									ti( {
						id: 'wca-create-time-from',
										label: t( 'from', 'From' ),
						value: formTimeFrom,
										mod: 'time',
						type: 'time',
						disabled: createTimeLocked,
						error: timeErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) {
						var v = e.target.value;
						selectedSlotSiteTimeRef.current = '';
						selectedSlotSiteDateRef.current = '';
						selectedSlotAdminDateRef.current = '';
						patchSlotStartTs( 0 );
						setFormTimeFrom( v );
						applyCombinedDurationToEnd( v, true );
						}
					} ),
							ti( {
						id: 'wca-create-time-to',
										label: t( 'to', 'To' ),
						value: formTimeTo,
										mod: 'time',
						type: 'time',
						disabled: createTimeLocked,
						error: timeErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) { setEndDaysOffset( 0 ); setFormTimeTo( e.target.value ); }
					} )
								) : null
							) ) : null,
							// Date range for day duration (same labels as edit)
							showDateRange ? h( Fragment, null,
								ti( {
						id: 'wca-create-date-from',
									label: t( 'date', 'Date' ),
						value: formDateFrom,
									mod: 'date',
						type: 'date',
						error: dateErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) { var v = e.target.value; setFormDateFrom( v ); autoComputeEndDate( v ); }
					} ),
							ti( {
						id: 'wca-create-date-to',
									label: t( 'to', 'To' ),
						value: formDateTo,
									mod: 'date',
						type: 'date',
						onFocus: openBrowseOnFocus,
						onChange: function( e ) { setFormDateTo( e.target.value ); }
					} )
							) : null,
							// Month range for month duration (same labels as edit)
							showMonthRange ? h( Fragment, null,
								ti( {
						id: 'wca-create-month-from',
									label: t( 'month', 'Month' ),
						value: formMonthFrom,
									mod: 'month',
						type: 'month',
						error: dateErr,
						onFocus: openBrowseOnFocus,
						onChange: function( e ) { var v = e.target.value; setFormMonthFrom( v ); autoComputeEndMonth( v ); }
					} ),
							ti( {
						id: 'wca-create-month-to',
									label: t( 'to', 'To' ),
						value: formMonthTo,
									mod: 'month',
						type: 'month',
						onFocus: openBrowseOnFocus,
						onChange: function( e ) { setFormMonthTo( e.target.value ); }
					} )
							) : null
						),
						datetimeAvailStatus( h, availStatus, availMessage, t )
					),
					submitError ? h( 'div', { className: 'wca-edit-error' }, submitError ) : null
				),
				h( 'div', { ref: browseSectionRef, className: 'wca-form-browse-section' },
				! browseOpen ? h( 'button', {
					type: 'button',
					className: 'wca-text-action wca-browse-trigger',
					onClick: function() {
						if ( locationPickRequired ) { return; }
						openBrowsePanel();
					}
				}, t( 'pickFromCalendar', 'Pick from a calendar' ) ) : null,
				browseOpen ? h( 'div', { className: 'wca-expansion wca-expansion--expanded' },
					formExpansionHeader( h, {
						open: true,
						onOpenChange: function( opening ) {
							if ( opening ) {
								openBrowsePanel();
							} else {
								setBrowseOpen( false );
								schedulePanelFit( browseSectionRef, false );
							}
						},
						sectionRef: browseSectionRef
					},
						h( 'span', { className: 'wca-expansion__title' }, t( 'pickFromCalendar', 'Pick from a calendar' ) ),
						wpIcon( h, 'chevronUp', 'wca-expansion__action', { title: t( 'close', 'Close' ) } )
					),
					h( 'div', { className: 'wca-expansion__body' },
				h( panelBrowse.BrowsePanel, {
				// State from useBrowseState
				miniCalMonth: miniCalMonth, miniCalData: miniCalData, miniCalLoading: miniCalLoading,
				miniCalExpanded: miniCalExpanded, miniCalStripCenter: miniCalStripCenter,
				slotsData: slotsData, slotsLoading: slotsLoading,
				availStatus: availStatus, availMessage: availMessage,
				// Config
				durationUnit: durationUnit, showTimeFields: showTimeFields,
				showDateRange: showDateRange, showMonthRange: showMonthRange,
				formDate: formDate, formDateFrom: formDateFrom, formMonthFrom: formMonthFrom,
				formTimeFrom: formTimeFrom, formTimeFromSite: selectedSlotSiteTimeRef.current, formStartTs: slotStartTsRef.current, panelCfg: browsePanelCfg, t: t, idPrefix: 'wca-create',
				showSlotCapacity: productDetails && parseInt( productDetails.qty, 10 ) > 1,
				// Action callbacks
				loadMonthAvailability: loadMonthAvailability,
				loadStripAvailability: loadStripAvailability,
				loadDaySlots: loadDaySlots,
				setMiniCalExpanded: setMiniCalExpanded,
				setMiniCalStripCenter: setMiniCalStripCenter,
				// Selection callbacks (Create-specific: date-range, month-range, duration)
				onDayClick: function( dateStr ) {
					patchSlotStartTs( 0 );
					selectedSlotSiteTimeRef.current = '';
					selectedSlotAdminDateRef.current = '';
					if ( showTimeFields ) { setFormTimeFrom( '' ); setFormTimeTo( '' ); }
					if ( showDateRange ) {
						setFormDateFrom( dateStr );
						setFormDate( dateStr );
						autoComputeEndDate( dateStr );
					} else {
						setFormDate( dateStr );
					}
				},
				onMonthClick: function( monthStr ) { setFormMonthFrom( monthStr ); autoComputeEndMonth( monthStr ); },
				onSlotClick: function( chipTime, slotStartTs, adminTime, adminDate ) {
					selectedSlotSiteTimeRef.current = chipTime;
					patchSlotStartTs( slotStartTs );
					var clickedTs = parseInt( slotStartTs, 10 ) || 0;
					if ( utils && utils.tsToNaiveLocalDate && clickedTs > 86400 ) {
						selectedSlotSiteDateRef.current = utils.tsToNaiveLocalDate( clickedTs );
					}

					var timeToSet = adminTime || chipTime;
					var dateToSet = adminDate || formDate;
					selectedSlotAdminDateRef.current = dateToSet || formDate || '';

					var updates = { timeFrom: timeToSet };
					if ( dateToSet !== formDate ) {
						updates.date = dateToSet;
					}

					// Compute end time based on product duration
					if ( productDetails ) {
						var duration = parseInt( productDetails.duration || 0, 10 );
						var unit = productDetails.duration_unit || 'hour';
						var minutes = 0;
						if ( 'hour' === unit ) { minutes = duration * 60; }
						else if ( 'minute' === unit ) { minutes = duration; }
						
						minutes += ( addonsDuration || 0 );

						if ( timeToSet && minutes > 0 ) {
							var p = String( timeToSet ).split( ':' );
							var sh = parseInt( p[ 0 ], 10 );
							var sm = parseInt( p[ 1 ] || 0, 10 );
							if ( ! isNaN( sh ) && ! isNaN( sm ) ) {
								var sMin = ( sh * 60 ) + sm;
								var eMin = sMin + minutes;
								var chipDaysOff = Math.floor( eMin / 1440 );
								var eDisp = ( ( eMin % 1440 ) + 1440 ) % 1440;
								var endVal = ( '0' + Math.floor( eDisp / 60 ) ).slice( -2 ) + ':' + ( '0' + ( eDisp % 60 ) ).slice( -2 );
								updates.timeTo = endVal;
								setEndDaysOffset( chipDaysOff );
							}
						}
					}
					_f.setFields( updates );
				}
			} )
					)
				) : null
				)
				);
			} )(),

			( window.panelSeries && window.panelSeries.CreateSeriesSection )
				? h( 'div', { ref: recurringSectionRef, className: 'wca-form-recurring-wrap' },
					h( window.panelSeries.CreateSeriesSection, {
						h: h,
						productId: productId,
						productDetails: productDetails,
						enabled: recurringOn,
						onEnabledChange: function( on ) {
							setRecurringMeta( on ? {} : null );
							schedulePanelFit( recurringSectionRef, on );
						},
						formDate: formDate,
						formDateFrom: formDateFrom,
						formTimeFrom: formTimeFrom,
						staffId: staffId,
						formQty: formQty,
						slotStartTs: slotStartTs,
						onMetaChange: setRecurringMeta,
						onSectionReveal: function() { schedulePanelFit( recurringSectionRef, true ); }
					} )
				)
				: null,

			integrationCurrency.renderSection(),

			renderOrderSection(),

			renderCustomerSection(),

			renderAddonsSection(),

			! recurringOn ? renderDepositsSection() : null,

			// Status section (segmented + more, same positioning as view panel)
			productId ? createStatusSectionNode : null
		);
		var payDepositSelected = wcaPanelPayDepositSelected();
		var canEditFooterPrice = ! payDepositSelected;
		var hasPriceDisplay = calculatedCost || overridePrice || priceEditing;
		var footerUseServerHtml = ( payDepositSelected || ! overridePrice ) && !! calculatedCost;
		var footerPriceText = '';
		if ( overridePrice && canEditFooterPrice ) {
			var obNum = parseFloat( overridePrice );
			var acFoot = parseFloat( addonsCost );
			var footSum = ( isNaN( obNum ) ? 0 : obNum ) + ( recurringOn || isNaN( acFoot ) ? 0 : acFoot );
			footerPriceText = fmtCurrency( footSum, createCurrency );
		}
		var footerCurrencyParts = footerCurrencyPrefixSuffix( createCurrency );
		var canSubmitCreate = ! isSubmitting && !! productId && ( ! recurringOn || recurringMeta.canSubmit );
		var showCreateFooterBtn = isSubmitting || canSubmitCreate;
		var createFooter = ( hasPriceDisplay || showCreateFooterBtn ) ? h( 'div', { className: 'wca-panel-footer' },
			// Keep price visible even while editing
			hasPriceDisplay ? h( 'div', { className: 'wca-footer-price-wrap wc-appointment-footer-price' + ( priceEditing ? ' is-price-editing' : '' ) + ( payDepositSelected ? ' wca-footer-price--deposit-quote' : '' ) },
				h( 'span', {
					className: 'wca-footer-price price',
					key: 'footer-price-' + createCurrency,
					dangerouslySetInnerHTML: footerUseServerHtml ? { __html: calculatedCost } : undefined
				}, footerUseServerHtml ? undefined : footerPriceText ),
				( window.wcaPanel && window.wcaPanel.taxEnabled ) ? h( 'span', { className: 'wca-footer-price-tax-hint' }, ( window.wcaPanel.pricesIncludeTax ? t( 'priceInclTaxShort', '(incl. tax)' ) : t( 'priceExclTaxShort', '(ex. tax)' ) ) ) : null,
				canEditFooterPrice ? h( 'button', {
					type: 'button',
					className: 'wca-text-action wca-footer-price-edit',
					'aria-label': t( 'editPrice', 'Edit price' ),
					onClick: onPriceEditClick
				}, t( 'edit', 'Edit' ) ) : null,
				canEditFooterPrice ? h( 'span', { className: 'wca-footer-price-input-wrap' },
					footerCurrencyParts.prefix ? h( 'span', { className: 'wca-footer-currency-symbol', 'aria-hidden': 'true' }, footerCurrencyParts.prefix ) : null,
					h( 'input', {
						ref: priceInputRef,
						type: 'number',
						step: '0.01',
						min: '0',
						className: 'wca-form-input wca-footer-price-input',
						placeholder: '0.00',
						value: priceEditValue,
						onChange: function( e ) { setPriceEditValue( e.target.value ); },
						onBlur: function( e ) { onPriceEditCommit( e.target.value ); },
						onKeyDown: onPriceEditKey
					} ),
					footerCurrencyParts.suffix ? h( 'span', { className: 'wca-footer-currency-symbol', 'aria-hidden': 'true' }, footerCurrencyParts.suffix ) : null
				) : null
			) : null,
			showCreateFooterBtn ? h( 'button', {
				type: 'button',
				className: 'button button-primary wca-panel-btn--primary',
				onClick: handleSubmit,
				disabled: ! canSubmitCreate
			}, isSubmitting ? t( 'creating', 'Creating…' ) : t( 'createAppointment', 'Create' ) ) : null
		) : null;
		return h( Fragment, null, createBody, createFooter );
	}

	// ─── WcaPanel Root Component ──────────────────────────────────

	function WcaPanel() {
		var [ isOpen, setIsOpen ]       = useState( false );
		var [ mode, setMode ]           = useState( 'view' ); // 'view' | 'edit' | 'create'
		var [ apptData, setApptData ]   = useState( null );
		var [ prefill, setPrefill ]     = useState( null );
		var [ createHasProduct, setCreateHasProduct ] = useState( false );
		var [ centered, setCentered ]   = useState( false );
		var [ position, setPosition ]   = useState( { x: -2000, y: -2000, shellHeight: 0, maxAvail: PANEL_MAX_H } );
		var [ visible, setVisible ]     = useState( false ); // for animation
		var [ isReady, setIsReady ]     = useState( false );
		var callbacksRef                = useRef( {} );
		var triggerElRef                 = useRef( null );
		var triggerRectRef               = useRef( null );
		var panelRef                     = useRef( null );
		var positionRef                  = useRef( { x: -2000, y: -2000, shellHeight: 0, maxAvail: PANEL_MAX_H, side: 'right' } );
		var [ layoutPass, setLayoutPass ]   = useState( 0 );
		var layoutAfterRef                  = useRef( null );
		var discardCheckRef              = useRef( null );
		var focusReturnRef               = useRef( null );
		var headerTitleTextRef           = useRef( null );

		function registerDiscardCheck( fn ) {
			discardCheckRef.current = fn || null;
		}

		function trySetMode( next ) {
			if ( 'edit' === mode && 'view' === next && discardCheckRef.current && discardCheckRef.current() === false ) {
				return;
			}
			setMode( next );
		}

		function getTriggerRect() {
			var rect = triggerRectRef.current;
			if ( triggerElRef.current ) {
				var lr = triggerElRef.current.getBoundingClientRect();
				if ( lr.width > 0 || lr.height > 0 ) {
					rect = lr;
					triggerRectRef.current = lr;
				}
			}
			return rect;
		}

		/**
		 * Measure rendered content, then place shell (Compose measure → place → show).
		 *
		 * @param {{ repositionOnly?: boolean }} opts Keep shell height (calendar scroll); remeasure otherwise.
		 */
		function applyPanelLayout( opts ) {
			opts = opts || {};
			if ( ! panelRef.current ) {
				return null;
			}
			var prev = positionRef.current;
			var rect = centered ? null : getTriggerRect();
			var layout = layoutPanel( panelRef.current, rect, prev, opts );
			if ( centered || ! rect ) {
				layout.centered = true;
			}

			var next = {
				x: layout.x,
				y: layout.y,
				shellHeight: layout.shellHeight,
				maxAvail: layout.maxAvail,
				side: layout.side
			};
			var moved = !( Math.abs( next.x - prev.x ) < 2 && Math.abs( next.y - prev.y ) < 2
				&& Math.abs( next.shellHeight - ( prev.shellHeight || 0 ) ) < 2
				&& next.side === prev.side );
			if ( ! moved ) {
				return layout;
			}
			positionRef.current = next;
			setPosition( next );
			if ( layout.centered !== centered ) {
				setCentered( layout.centered );
			}
			return layout;
		}

		function revealPanelAfterLayout() {
			if ( visibleSetRef.current || awaitPreviewRef.current || awaitDataRef.current ) {
				return;
			}
			visibleSetRef.current = true;
			requestAnimationFrame( function() {
				setVisible( true );
				setIsReady( true );
			} );
		}

		// Create-mode: wait for preview event. View/edit: wait only when core row data still missing.
		var awaitPreviewRef              = useRef( false );
		var awaitDataRef                 = useRef( false );
		var visibleSetRef                = useRef( false );
		var awaitFallbackRef             = useRef( null );
		var lastLayoutContentKeyRef      = useRef( '' );

		// Products and staff from calendar config
		var products = [];
		if ( calCfg.preloadedProducts ) {
			products = calCfg.preloadedProducts;
		}
		var staffList = [];
		if ( calCfg.preloadedStaff ) {
			staffList = calCfg.preloadedStaff.map( function( s ) {
				return { id: s.id, display_name: s.name || ( '#' + s.id ), full_name: s.name || ( '#' + s.id ), name: s.name || '', avatar: s.avatar || '', timezone: s.timezone || '' };
			} );
		}

		function apptNeedsFullFetch( ad ) {
			if ( ! ad || ! ad.id ) {
				return false;
			}
			// Calendar rows include product_title; sparse { id } from a missing event needs fetch.
			if ( ! ( 'product_title' in ad ) ) {
				return true;
			}
			var orderId = parseInt( ad.order_id, 10 );
			// null order_info means calendar preload already tried; do not block the panel.
			if ( orderId > 0 && ! ( 'order_info' in ad ) ) {
				return true;
			}
			return false;
		}

		function fetchFullApptIfNeeded( config, m ) {
			var ad = config.apptData;
			if ( ( m === 'view' || m === 'edit' ) && apptNeedsFullFetch( ad ) ) {
				// Prefer calendar localize; standalone list/widget use wcaPanel.calendarPanelFields.
				var panelFields = calCfg.calendarPanelFields || cfg.calendarPanelFields || '';
				apiGet( 'wc-appointments/v2/appointments/' + ad.id, {
					_fields: panelFields
				} )
					.then( function( full ) {
						if ( full && window.panelSeries ) {
							window.panelSeries.indexPreloadFromRows( [ full ] );
							full = window.panelSeries.mergeApptPreload( full );
						}
						awaitDataRef.current = false;
						setApptData( full );
					} )
					.catch( function() {
						awaitDataRef.current = false;
					} );
			}
		}

		// ── Open handler ──
		function openPanel( config ) {
			config = config || {};
			var m = config.mode || 'view';
			var ad = config.apptData;
			if ( ! config.triggerRect && 'view' === m && ad && ad.id ) {
				var calApi = window.__wcaCalPreview;
				if ( calApi && calApi.openView && calApi.openView( ad.id, parseInt( ad.start_ts || ad.start || 0, 10 ) ) ) {
					return;
				}
			}
			var wasOpen = isOpen;
			var keepVisible = isOpen && !! config.triggerRect;
			if ( keepVisible ) {
				positionRef.current = Object.assign( {}, positionRef.current, { shellHeight: 0 } );
			}
			setMode( m );
			var apptForPanel = config.apptData || null;
			if ( apptForPanel && window.panelSeries && window.panelSeries.mergeApptPreload ) {
				apptForPanel = window.panelSeries.mergeApptPreload( apptForPanel );
			}
			setApptData( apptForPanel );
			setPrefill( config.prefill || null );
			setCreateHasProduct( !!( 'create' === m && config.prefill && config.prefill.productId ) );
			callbacksRef.current = config.callbacks || {};
			if ( 'create' === m && ! callbacksRef.current.onCreate ) {
				callbacksRef.current.onCreate = function( data ) {
					if ( window.wcaPanel && window.wcaPanel.navigateAfterAdminCreate ) {
						window.wcaPanel.navigateAfterAdminCreate( data );
					} else {
						window.location.reload();
					}
				};
			}
			triggerElRef.current = config.triggerEl || null;
			triggerRectRef.current = config.triggerRect || null;
			focusReturnRef.current = ( config.triggerEl && typeof config.triggerEl.focus === 'function' ) ? config.triggerEl : document.activeElement;
			// Sparse list/widget opens only pass { id }. Fetch in background; do not gate shell
			// reveal on REST (ViewContent already skeletons missing fields). Create still awaits preview.
			awaitDataRef.current = false;
			setCentered( ! config.triggerRect );
			if ( config.callbacks && config.callbacks.highlightEvent && config.triggerEl ) {
				config.callbacks.highlightEvent( config.triggerEl );
			}
			awaitPreviewRef.current = ( 'create' === m && !! config.triggerRect );
			setLayoutPass( function( n ) { return n + 1; } );
			if ( ! keepVisible ) {
				visibleSetRef.current = false;
				setVisible( false );
				setIsReady( false );
				if ( awaitFallbackRef.current ) { clearTimeout( awaitFallbackRef.current ); awaitFallbackRef.current = null; }
				setIsOpen( true );
			}
			fetchFullApptIfNeeded( config, m );
		}

		// ── Close handler ──
		function closePanel( opts ) {
			opts = opts || {};
			if ( ! opts.force && discardCheckRef.current && discardCheckRef.current() === false ) {
				return;
			}
			setVisible( false );
			visibleSetRef.current = false;
			awaitPreviewRef.current = false;
			if ( awaitFallbackRef.current ) { clearTimeout( awaitFallbackRef.current ); awaitFallbackRef.current = null; }
			// Remove highlight
			if ( callbacksRef.current.removeHighlight ) {
				callbacksRef.current.removeHighlight();
			}
			// Delay unmount for animation
			setTimeout( function() {
				setIsOpen( false );
				setApptData( null );
				setPrefill( null );
				setCreateHasProduct( false );
				setMode( 'view' );
				if ( callbacksRef.current.onClose ) {
					callbacksRef.current.onClose();
				}
				callbacksRef.current = {};
				triggerElRef.current = null;
				triggerRectRef.current = null;
				discardCheckRef.current = null;
				positionRef.current = { x: -2000, y: -2000, shellHeight: 0, maxAvail: PANEL_MAX_H, side: 'right' };
				var focusEl = focusReturnRef.current;
				focusReturnRef.current = null;
				if ( focusEl ) {
					var isCalEvent = focusEl.classList && focusEl.classList.contains( 'fc-event' );
					if ( isCalEvent && typeof focusEl.blur === 'function' ) {
						// FC anchors keep a focus box-shadow that looks like a lingering selection.
						try { focusEl.blur(); } catch ( _blurErr ) {}
					} else if ( typeof focusEl.focus === 'function' ) {
						try { focusEl.focus(); } catch ( _focusErr ) {}
					}
				}
			}, 200 );
		}

		// ── Expose global API ──
		useEffect( function() {
			window.wcaPanel.open = openPanel;
			window.wcaPanel.close = closePanel;
			window.wcaPanel.isOpen = function() { return isOpen; };
			window.wcaPanel.navigateAfterAdminCreate = function( data ) {
				var u = data && data.post_create_redirect;
				if ( u && ( 'string' === typeof u ) && u.length ) {
					window.location.assign( u );
				} else {
					window.location.reload();
				}
			};

			// Expose update method for SSE, drag/resize, etc. (functional update avoids stale id checks)
			window.wcaPanel.updateApptData = function( id, data ) {
				if ( !isOpen || !data ) {
					return;
				}
				setApptData( function( prev ) {
					if ( ! prev || String( prev.id ) !== String( id ) ) {
						return prev;
					}
					return Object.assign( {}, prev, data );
				} );
			};

			// Allow child components (e.g. CreateContent preview) to update the
			// trigger element so the panel repositions next to the preview event
			// instead of staying anchored to the original day cell.
			window.wcaPanel.updateTrigger = function( el ) {
				if ( ! el || ! isOpen || centered ) { return; }
				triggerElRef.current = el;
				var rect = el.getBoundingClientRect();
				if ( rect.width <= 0 && rect.height <= 0 ) { return; }
				triggerRectRef.current = rect;
				if ( awaitPreviewRef.current && ! visibleSetRef.current ) {
					awaitPreviewRef.current = false;
					if ( awaitFallbackRef.current ) { clearTimeout( awaitFallbackRef.current ); awaitFallbackRef.current = null; }
				}
				if ( ! panelRef.current ) { return; }
				// First open must run layoutPass (measure + reveal). Later preview follows only reposition.
				if ( ! visibleSetRef.current ) {
					setLayoutPass( function( n ) { return n + 1; } );
				} else {
					applyPanelLayout( { repositionOnly: true } );
				}
			};

			window.wcaPanel.syncLayout = function() {
				if ( isOpen && ! centered && panelRef.current && triggerRectRef.current ) {
					applyPanelLayout( { repositionOnly: true } );
				}
			};

			window.wcaPanel.scheduleFitContent = function( afterFn ) {
				layoutAfterRef.current = afterFn || null;
				setLayoutPass( function( n ) { return n + 1; } );
			};
			window.wcaPanel.scheduleSectionFit = schedulePanelFit;

			try {
				var u = new URL( window.location.href );
				if ( '1' === u.searchParams.get( 'open_panel' ) ) {
					u.searchParams.delete( 'open_panel' );
					window.history.replaceState( {}, '', u.pathname + u.search + u.hash );
					openPanel( { mode: 'create' } );
				}
			} catch ( _openPanelUrlErr ) {}
		}, [ openPanel, closePanel, isOpen, centered ] );

		// ── Follow anchor on calendar scroll / viewport resize (not internal panel scroll) ──
		useEffect( function() {
			if ( ! isOpen || centered ) { return; }
			var raf = 0;
			function scheduleSync( e ) {
				if ( e && e.target && panelRef.current && panelRef.current.contains( e.target ) ) {
					return;
				}
				if ( raf ) { return; }
				raf = requestAnimationFrame( function() {
					raf = 0;
					if ( panelRef.current && triggerRectRef.current ) {
						applyPanelLayout( { repositionOnly: true } );
					}
				} );
			}
			function onResize() { scheduleSync(); }
			window.addEventListener( 'scroll', scheduleSync, true );
			window.addEventListener( 'resize', onResize );
			return function() {
				window.removeEventListener( 'scroll', scheduleSync, true );
				window.removeEventListener( 'resize', onResize );
				if ( raf ) { cancelAnimationFrame( raf ); }
			};
		}, [ isOpen, centered ] );

		// Header/footer scroll-edge shadows (same chrome as admin calendar).
		useEffect( function() {
			if ( ! isOpen || ! visible || ! panelRef.current ) { return undefined; }
			var panel = panelRef.current;
			var scroller = panel.querySelector( '.wca-panel-body-scroll' );
			if ( ! scroller ) { return undefined; }
			function syncScrollEdges() {
				panel.classList.toggle( 'is-scrolled', scroller.scrollTop > 0 );
				// Subpixel: scrollTop often stops ~1–2px short of scrollHeight - clientHeight.
				panel.classList.toggle( 'is-overflow-bottom', scroller.scrollHeight - scroller.clientHeight - scroller.scrollTop > 2 );
			}
			scroller.addEventListener( 'scroll', syncScrollEdges, { passive: true } );
			var ro = new ResizeObserver( syncScrollEdges );
			ro.observe( scroller );
			syncScrollEdges();
			return function() {
				scroller.removeEventListener( 'scroll', syncScrollEdges );
				ro.disconnect();
				panel.classList.remove( 'is-scrolled', 'is-overflow-bottom' );
			};
		}, [ isOpen, visible, mode ] );

		// ── Initial focus when panel becomes visible ──
		useEffect( function() {
			if ( ! visible || ! panelRef.current ) { return; }
			if ( 'create' === mode ) {
				var productEl = panelRef.current.querySelector( '#wca-create-product' );
				if ( productEl && ! productEl.value && window.panelHelpers && window.panelHelpers.focusPanelSelect ) {
					if ( window.panelHelpers.focusPanelSelect( productEl ) ) {
						return;
					}
				}
			}
			var closeBtn = panelRef.current.querySelector( '.wca-panel-close-btn' );
			if ( closeBtn && typeof closeBtn.focus === 'function' ) {
				closeBtn.focus();
			}
		}, [ visible, mode ] );

		// ── Mobile keyboard: scroll focused field just above the keyboard ──
		useEffect( function() {
			if ( ! isOpen || ! visible || ! panelRef.current ) { return undefined; }
			if ( window.innerWidth > PANEL_ANCHOR_MOBILE ) { return undefined; }
			var vv = window.visualViewport;
			if ( ! vv ) { return undefined; }
			var panel = panelRef.current;
			var el = null;

			function settle() {
				if ( ! el ) { return; }
				var field = el.closest( '.select2-search, .wca-field' ) || el;
				if ( ! panel.contains( field ) ) {
					var open = panel.querySelector( '.select2-container--open' );
					field = open ? ( open.closest( '.wca-field' ) || open ) : null;
				}
				if ( ! field || ! panel.contains( field ) ) { return; }
				var delta = field.getBoundingClientRect().bottom - ( vv.offsetTop + vv.height ) + 12;
				if ( delta >= -1 ) { return; }
				var scroller = panel.querySelector( '.wca-panel-body-scroll' );
				if ( scroller ) { scroller.scrollTop += delta; }
			}

			function onFocusIn( e ) {
				var t = e.target;
				var tag = t && ( t.tagName || '' ).toLowerCase();
				if ( 'input' !== tag && 'textarea' !== tag ) { return; }
				if ( ! panel.contains( t ) && ! ( t.classList.contains( 'select2-search__field' ) && panel.querySelector( '.select2-container--open' ) ) ) { return; }
				el = t;
				settle();
			}

			document.addEventListener( 'focusin', onFocusIn, true );
			vv.addEventListener( 'resize', settle );
			vv.addEventListener( 'scroll', settle );
			return function() {
				document.removeEventListener( 'focusin', onFocusIn, true );
				vv.removeEventListener( 'resize', settle );
				vv.removeEventListener( 'scroll', settle );
			};
		}, [ isOpen, visible ] );

		// ── Header title: native tooltip only when truncated (long translations) ──
		var headerTitleApptId = apptData && apptData.id ? apptData.id : null;
		useLayoutEffect( function() {
			if ( ! isOpen ) {
				return;
			}
			var el = headerTitleTextRef.current;
			if ( ! el ) {
				return;
			}
			function syncTitleTooltip() {
				var full = ( el.textContent || '' ).trim();
				if ( full && ( el.clientWidth + 1 ) < el.scrollWidth ) {
					el.setAttribute( 'title', full );
				} else {
					el.removeAttribute( 'title' );
				}
			}
			syncTitleTooltip();
			var ro = 'undefined' !== typeof ResizeObserver ? new ResizeObserver( syncTitleTooltip ) : null;
			if ( ro ) {
				ro.observe( el );
				if ( el.parentElement ) {
					ro.observe( el.parentElement );
				}
			}
			var onWin = debounce( syncTitleTooltip, 150 );
			window.addEventListener( 'resize', onWin );
			return function() {
				if ( ro ) {
					ro.disconnect();
				}
				window.removeEventListener( 'resize', onWin );
				if ( headerTitleTextRef.current ) {
					headerTitleTextRef.current.removeAttribute( 'title' );
				}
			};
		}, [ isOpen, visible, mode, headerTitleApptId ] );

		var layoutContentKey = String( apptData && apptData.id || 0 ) + '|' + mode + '|'
			+ ( apptData && apptData.series_occurrences ? apptData.series_occurrences.length : '' ) + '|'
			+ ( apptData && apptData.product_title ? 1 : 0 ) + '|'
			+ ( createHasProduct ? 1 : 0 );

		useLayoutEffect( function() {
			if ( ! isOpen || ! panelRef.current || ! layoutPass ) {
				return;
			}
			if ( awaitPreviewRef.current || awaitDataRef.current ) {
				return;
			}
			if ( ! centered && ! triggerRectRef.current ) {
				return;
			}
			// When content key changes (switching appointments), defer measurement
			// to allow React to render new content before we measure naturalH.
			var prevContentKey = lastLayoutContentKeyRef.current;
			var contentKeyChanged = prevContentKey && prevContentKey !== layoutContentKey;
			lastLayoutContentKeyRef.current = layoutContentKey;
			if ( contentKeyChanged && visibleSetRef.current ) {
				// Defer to next frame so React can paint new content
				requestAnimationFrame( function() {
					if ( panelRef.current && isOpen ) {
						setLayoutPass( function( n ) { return n + 1; } );
					}
				} );
				return;
			}
			applyPanelLayout();
			var after = layoutAfterRef.current;
			layoutAfterRef.current = null;
			if ( after ) {
				after();
			}
			revealPanelAfterLayout();
		}, [ isOpen, centered, layoutContentKey, layoutPass ] );

		useLayoutEffect( function() {
			if ( ! isOpen ) {
				return;
			}
			if ( awaitFallbackRef.current ) {
				clearTimeout( awaitFallbackRef.current );
			}
			awaitFallbackRef.current = setTimeout( function() {
				if ( ! visibleSetRef.current && isOpen ) {
					awaitDataRef.current = false;
					awaitPreviewRef.current = false;
					setLayoutPass( function( n ) { return n + 1; } );
				}
			}, 600 );
			return function() {
				if ( awaitFallbackRef.current ) {
					clearTimeout( awaitFallbackRef.current );
					awaitFallbackRef.current = null;
				}
			};
		}, [ isOpen, layoutContentKey ] );

		// ── Don't render when closed ──
		if ( ! isOpen ) { return null; }

		// ── More menu items (shared actions + mode switchers) ──
		var moreMenuItems = [];
		if ( mode === 'create' && cfg.legacyAddAsCustomer ) {
			moreMenuItems.push( {
				key: 'legacy-create',
				label: t( 'createAsCustomer', 'Create as a Customer' ),
				href: ( calCfg.adminPost || '' ).replace( /post\.php.*/, '' ) + 'edit.php?post_type=wc_appointment&page=add_appointment',
				icon: 'customerAccount'
			} );
		}
		if ( apptData && apptData.id ) {
			var adminPost = calCfg.adminPost || '';

			if ( apptData.order_id ) {
				moreMenuItems.push( { key: 'view-order', label: t( 'viewOrder', 'View Order' ), href: adminPost + '?post=' + apptData.order_id + '&action=edit', icon: 'bag' } );
			}
			var custEmail = apptData.customer_email || '';
			if ( custEmail ) {
				moreMenuItems.push( { key: 'email-customer', label: t( 'emailCustomer', 'Email customer' ), href: 'mailto:' + custEmail, icon: 'atSymbol' } );
			}
			moreMenuItems.push( {
				key: 'trash',
				label: t( 'trash', 'Trash' ),
				icon: 'trash',
				className: 'wca-panel-more-item--danger',
				onClick: function() {
					if ( ! window.confirm( t( 'confirmDelete', 'Are you sure?' ) ) ) { return; }
					apiDelete( 'wc-appointments/v2/appointments/' + apptData.id )
						.then( function() {
							if ( callbacksRef.current.onDelete ) { callbacksRef.current.onDelete( apptData.id ); }
							closePanel();
						} )
						.catch( function() { window.alert( t( 'deleteFailed', 'An error occurred. Please try again.' ) ); } );
				}
			} );
		}

		// ── Header (unified across view/edit/create) ──
		var showHeaderTz = mode !== 'create' || createHasProduct;
		var headerTzHtml = ( showHeaderTz && calCfg.adminTimezoneHtml ) ? String( calCfg.adminTimezoneHtml ).trim() : '';

		var modeTitle = '';
		if ( mode === 'create' ) {
			modeTitle = t( 'newAppointment', 'New Appointment' );
		} else if ( mode === 'edit' ) {
			modeTitle = t( 'editAppointment', 'Edit Appointment' ) + ( apptData && apptData.id ? ( ' #' + String( apptData.id ) ) : '' );
		} else {
			modeTitle = apptData && apptData.id ? formatAppointmentWithId( apptData.id ) : t( 'appointmentIdLabel', 'Appointment' );
		}

		var headerTitle = h( 'div', { className: 'wca-panel-header-title-wrap' },
			wpIcon( h, 'appointment', 'wca-panel-header-title-icon', { title: t( 'appointment', 'Appointment' ) } ),
			h( 'span', { ref: headerTitleTextRef, className: 'wca-panel-header-title' }, modeTitle ),
			headerTzHtml ? h( 'span', { className: 'wca-panel-header-tz', dangerouslySetInnerHTML: { __html: headerTzHtml } } ) : null
		);

		// ── Inline header action buttons (icon-only, before more menu) ──
		var headerActionButtons = [];
		if ( apptData && apptData.id ) {
			if ( mode === 'view' ) {
				headerActionButtons.push( h( 'button', {
					key: 'hdr-edit',
					type: 'button',
					className: 'wca-panel-icon-btn',
					title: t( 'editAppointment', 'Edit Appointment' ),
					'aria-label': t( 'editAppointment', 'Edit Appointment' ),
					onClick: function() { trySetMode( 'edit' ); }
				}, wpIcon( h, 'pencil', null ) ) );
			} else if ( mode === 'edit' ) {
				headerActionButtons.push( h( 'button', {
					key: 'hdr-view',
					type: 'button',
					className: 'wca-panel-icon-btn',
					title: t( 'viewAppointment', 'View Appointment' ),
					'aria-label': t( 'viewAppointment', 'View Appointment' ),
					onClick: function() { trySetMode( 'view' ); }
				}, wpIcon( h, 'seen', null ) ) );
			}
		}

		var headerMoreNode = moreMenuItems.length ? h( 'div', { className: 'wca-panel-more-wrap' },
			h( 'button', {
				type: 'button',
				className: 'wca-panel-icon-btn',
				title: t( 'moreActions', 'More actions' ),
				onClick: function( e ) {
					e.stopPropagation();
					var wrap = e.currentTarget.parentNode;
					wrap.classList.toggle( 'is-open' );
					if ( wrap.classList.contains( 'is-open' ) ) {
						var closeH = function( ev ) {
							if ( ! wrap.contains( ev.target ) ) {
								wrap.classList.remove( 'is-open' );
								document.removeEventListener( 'click', closeH, true );
							}
						};
						setTimeout( function() { document.addEventListener( 'click', closeH, true ); }, 0 );
					}
				}
			}, wpIcon( h, 'moreVertical', null ) ),
			h( 'div', { className: 'wca-panel-more-dropdown' },
				moreMenuItems.map( function( item ) {
					if ( item.onClick ) {
						return h( 'button', {
							key: item.key,
							type: 'button',
							className: 'wca-panel-more-item' + ( item.className ? ' ' + item.className : '' ),
							onClick: function() {
								var wrap = document.querySelector( '.wca-panel-more-wrap.is-open' );
								if ( wrap ) { wrap.classList.remove( 'is-open' ); }
								item.onClick();
							}
						},
							wpIcon( h, item.icon, 'wca-panel-more-item-svg' ),
							h( 'span', null, item.label )
						);
					}
					return h( 'a', {
						key: item.key,
						href: item.href,
						target: item.href && item.href.indexOf( 'mailto:' ) !== 0 ? '_blank' : undefined,
						rel: 'noopener noreferrer',
						className: 'wca-panel-more-item'
					},
						wpIcon( h, item.icon, 'wca-panel-more-item-svg' ),
						h( 'span', null, item.label )
					);
				} )
			)
		) : null;

		var headerActionsNode = headerActionButtons.length
			? h( 'div', { className: 'wca-panel-header-actions' }, headerActionButtons )
			: null;

		var headerRight = h( 'div', { className: 'wca-panel-header-right' },
			headerActionsNode,
			headerMoreNode,
			h( 'button', {
				type: 'button',
				className: 'wca-panel-icon-btn wca-panel-close-btn',
				title: t( 'close', 'Close' ),
				'aria-label': t( 'close', 'Close' ),
				onClick: closePanel
			}, wpIcon( h, 'closeSmall', null ) )
		);

		var headerNode = h( 'div', { className: 'wca-panel-header' },
			headerTitle,
			headerRight
		);

		// ── Body ──
		var bodyContent = null;
		if ( mode === 'view' && apptData ) {
			bodyContent = h( ViewContent, {
				apptData: apptData,
				callbacks: callbacksRef.current,
				products: products,
				staffList: staffList
			} );
		} else if ( mode === 'edit' && apptData ) {
			bodyContent = h( EditContent, {
				apptData: apptData,
				callbacks: callbacksRef.current,
				products: products,
				staffList: staffList,
				onCancel: function() { trySetMode( 'view' ); },
				onSaved: function( updated ) {
					var merged = Object.assign( {}, apptData, updated );
					// REST API returns 'start'/'end' but ViewContent reads 'start_ts'/'end_ts'.
					if ( updated.start !== undefined ) { merged.start_ts = updated.start; }
					if ( updated.end !== undefined ) { merged.end_ts = updated.end; }
					setApptData( merged );
					discardCheckRef.current = null;
					setMode( 'view' );
				},
				registerDiscardCheck: registerDiscardCheck
			} );
		} else if ( mode === 'create' ) {
			bodyContent = h( CreateContent, {
				prefill: prefill || {},
				callbacks: callbacksRef.current,
				products: products,
				staffList: staffList,
				onProductChange: function( id ) { setCreateHasProduct( !! id ); },
				onCancel: function() { closePanel( { force: true } ); },
				onCreated: function( data ) {
					if ( callbacksRef.current.onCreate ) { callbacksRef.current.onCreate( data ); }
				},
				onOpenEditInline: function( appointmentId ) {
					if ( ! appointmentId ) { return; }
					apiGet( 'wc-appointments/v2/appointments/' + String( appointmentId ) )
						.then( function( full ) {
							setApptData( full );
							setMode( 'edit' );
						} )
						.catch( function() {
							window.alert( t( 'appointmentLoadFailed', 'An error occurred. Please try again.' ) );
						} );
				},
			} );
		}

		// ── Panel shell ──
		var shellH = position.shellHeight || 0;
		var maxAvail = position.maxAvail || Math.min( PANEL_MAX_H, window.innerHeight - ( position.y || 0 ) - PANEL_BOTTOM_INSET );
		var panelStyle = {
			'--wca-panel-shell-h': shellH > 0 ? ( shellH + 'px' ) : 'auto',
			'--wca-panel-anchor-max-h': maxAvail + 'px',
			position: 'fixed',
			top: position.y + 'px',
			left: position.x + 'px'
		};

		var panelClasses = 'wca-panel wca-panel--' + mode;
		if ( visible ) { panelClasses += ' wca-panel--visible'; }
		if ( shellH > 0 ) {
			panelClasses += ' wca-panel--fill-shell';
		}
		if ( ! centered ) {
			panelClasses += ' wca-panel--anchored';
			if ( position.side === 'left' ) {
				panelClasses += ' wca-panel--side-left';
			} else {
				panelClasses += ' wca-panel--side-right';
			}
		}
		if ( centered ) { panelClasses += ' wca-panel--centered'; }
		if ( isReady ) { panelClasses += ' wca-panel--ready'; }

		var backdropNode = centered ? h( 'div', {
			className: 'wca-panel-backdrop' + ( visible ? ' wca-panel-backdrop--visible' : '' )
		} ) : null;

		return h( Fragment, null,
			backdropNode,
			h( 'div', {
				ref: panelRef,
				className: panelClasses,
				style: panelStyle,
				role: 'dialog',
				'aria-label': t( 'appointment', 'Appointment' ),
				'aria-modal': centered ? 'true' : 'false'
			},
				headerNode,
				bodyContent ? h( 'div', { className: 'wca-panel-body', key: mode }, bodyContent ) : null
			)
		);
	}

	// ─── Mount panel into portal ──────────────────────────────────

	function mountPanel() {
		var root = document.getElementById( 'wca-panel-root' );
		if ( ! root ) {
			root = document.createElement( 'div' );
			root.id = 'wca-panel-root';
			document.body.appendChild( root );
		}
		if ( wp.element && 'function' === typeof wp.element.createRoot ) {
			var reactRoot = wp.element.createRoot( root );
			reactRoot.render( h( WcaPanel ) );
		} else if ( wp.element && 'function' === typeof wp.element.render ) {
			wp.element.render( h( WcaPanel ), root );
		}
	}

	// Initialize global API stub immediately (before DOM ready)
	window.wcaPanel = window.wcaPanel || {};
	window.wcaPanel.panelEnabled = true;
	window.wcaPanel.open = function() {};
	window.wcaPanel.close = function() {};
	window.wcaPanel.isOpen = function() { return false; };

	function initPanelModule() {
		mountPanel();

		document.addEventListener( 'mousedown', function( e ) {
			var api = window.wcaPanel;
			if ( ! api || ! api.isOpen || ! api.isOpen() || ! api.close ) {
				return;
			}
			// Product Add-Ons datepicker mounts #ui-datepicker-div on body (outside .wca-panel).
			if ( e.target.closest( '.wca-panel, .fc-event, .fc-daygrid-event, .wca-panel-dropdown, .select2-dropdown, .select2-container--open, #ui-datepicker-div, .ui-datepicker' ) ) {
				return;
			}
			api.close();
		}, true );

		document.addEventListener( 'keydown', function( e ) {
			var api = window.wcaPanel;
			if ( 'Escape' !== e.key || ! api || ! api.isOpen || ! api.isOpen() || ! api.close ) {
				return;
			}
			e.preventDefault();
			api.close();
		} );

		// Intercept [data-wca-panel-create] / [data-wca-panel-view] (legacy page links).
		document.addEventListener( 'click', function( e ) {
			// Create panel trigger.
			var createBtn = e.target.closest( '[data-wca-panel-create]' );
			if ( createBtn ) {
				e.preventDefault();
				e.stopImmediatePropagation();
				if ( window.wcaPanel && window.wcaPanel.open ) {
					var openCfg = { mode: 'create' };
					if ( typeof window.__wcaBuildCreatePanelCallbacks === 'function' ) {
						openCfg.callbacks = window.__wcaBuildCreatePanelCallbacks();
					}
					var cal = window.wcAppointmentsReactCalendar;
					if ( cal && cal.initialStaffId ) {
						openCfg.prefill = { staffId: cal.initialStaffId };
					}
					window.wcaPanel.open( openCfg );
				}
				return;
			}

			// View panel trigger (list table View button).
			var viewBtn = e.target.closest( '[data-wca-panel-view]' );
			if ( viewBtn ) {
				e.preventDefault();
				var apptId = viewBtn.getAttribute( 'data-wca-panel-view' );
				if ( apptId && window.wcaPanel && window.wcaPanel.open ) {
					var rect = viewBtn.getBoundingClientRect();
					window.wcaPanel.open( {
						mode: 'view',
						apptData: { id: parseInt( apptId, 10 ) },
						triggerEl: viewBtn,
						triggerRect: rect,
						callbacks: {
							onDelete: function() {
								window.location.reload();
							}
						}
					} );
				}
				return;
			}
		}, true );

		var submenuLinks = document.querySelectorAll(
			'a[href*="page=add_appointment"], a[href*="post-new.php"][href*="post_type=wc_appointment"]'
		);
		for ( var i = 0; i < submenuLinks.length; i++ ) {
			if ( ! submenuLinks[ i ].hasAttribute( 'data-wca-panel-create' ) ) {
				submenuLinks[ i ].setAttribute( 'data-wca-panel-create', '1' );
			}
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', initPanelModule );
	} else {
		initPanelModule();
	}

} )();
