/* globals wca_get_querystring, wcaShared */
wcaShared.whenDepsReady(
	function() {
		return typeof jQuery !== 'undefined';
	},
	function() {
		jQuery( function( $ ) {
	'use strict';

	var wc_appointments_month_picker = {
		/**
		 * Whether availability autoselect is on for this picker (`data-is_autoselect="1"`).
		 *
		 * @param {jQuery} picker Month picker element.
		 * @return {boolean}
		 */
		is_autoselect: function( picker ) {
			return '1' === String( picker.attr( 'data-is_autoselect' ) );
		},

		init: function() {
			$( 'body' ).on( 'change', '#wc_appointments_field_location', function() {
				var form = $( this ).closest( 'form' );
				if ( form.find( '.form-field-month' ).length ) {
					wc_appointments_month_picker.maybe_autoselect( form );
				}
			} );

			$( '.wc-appointments-appointment-form' ).each( function() {
				var form   = $( this ).closest( 'form' );
				var picker = form.find( '.picker:eq(0)' );

				form.on( 'addon-duration-changed', function( event, duration ) {
					var appointment_duration = parseInt( picker.attr( 'data-appointment_duration' ), 10 );
					var addon_duration = parseInt( duration, 10 );
					picker.data( 'combined_duration', parseInt( appointment_duration + addon_duration, 10 ) );
					picker.data( 'addon_duration', duration );
					wc_appointments_month_picker.highlight_months( form );
				} );

				form.on( 'month-unavailable-autoselect', function() {
					wc_appointments_month_picker.autoselect_first_available_month( form );
				} );

				picker.on( 'click', 'a', function( event ) {
					event.preventDefault();
					wc_appointments_month_picker.set_selected_month( form, $( this ).parent().data( 'slot' ) );
				} );

				wc_appointments_month_picker.maybe_autoselect( form );
			} );
		},

		maybe_autoselect: function( form ) {
			var $loc = form.find( '#wc_appointments_field_location' );
			if ( $loc.length && ! ( parseInt( $loc.val(), 10 ) > 0 ) ) {
				return;
			}

			var picker        = form.find( '.picker:eq(0)' );
			var is_autoselect = wc_appointments_month_picker.is_autoselect( picker );
			var querystring_date = wca_get_querystring( 'date' );

			if ( null !== querystring_date ) {
				var selected_slot = picker.find( 'li.slot a[data-value="' + querystring_date + '"]' ).not( '.slot_empty' );
				if ( 0 < selected_slot.length ) {
					wc_appointments_month_picker.set_selected_month( form, selected_slot.parent().data( 'slot' ) );
				} else {
					wc_appointments_month_picker.autoselect_first_available_month( form );
				}
			} else if ( is_autoselect ) {
				wc_appointments_month_picker.autoselect_first_available_month( form );
			}
		},

		set_selected_month: function( form, value ) {
			var submit_button       = form.find( '.wc-appointments-appointment-form-button' );
			var picker              = form.find( '.picker:eq(0)' );
			var target              = form.find( '.picker:eq(0)' ).parent( 'div' ).find( 'input' );
			var selected_slot       = picker.find( '[data-slot="' + value + '"]' );
			var selected_slot_value = selected_slot.find( 'a' ).data( 'value' );

			target.val( selected_slot_value );
			submit_button.prop( 'disabled', true );
			form.find( '.wc-appointments-appointment-hook-after' ).show();
			form.triggerHandler( 'month-selected' );
			picker.find( 'li' ).removeClass( 'selected' );
			selected_slot.addClass( 'selected' );
			wc_appointments_month_picker.highlight_months( form );
		},

		autoselect_first_available_month: function( form ) {
			var picker = form.find( '.picker:eq(0)' );
			var current_selected = picker.find( 'li.selected' );
			var next_slot;

			if ( 0 < current_selected.length ) {
				next_slot = current_selected.nextAll( 'li.slot:not(".slot_empty,.fully_scheduled,.partial_scheduled"):first' );
				if ( 0 === next_slot.length ) {
					next_slot = picker.find( 'li.slot:not(".slot_empty,.fully_scheduled,.partial_scheduled"):first' );
				}
			} else {
				next_slot = picker.find( 'li.slot:not(".slot_empty,.fully_scheduled,.partial_scheduled"):first' );
			}

			if ( 0 < next_slot.length && next_slot.has( 'a' ) ) {
				var slot_link = next_slot.find( 'a' );
				slot_link.one( 'click', function( e ) {
					e.stopPropagation();
				} );
				slot_link.trigger( 'click' );
				wc_appointments_month_picker.highlight_months( form );
				form.removeData( 'autoselect-in-progress' );
			} else {
				form.removeData( 'autoselect-in-progress' );
			}
		},

		highlight_months: function( form ) {
			var picker            = form.find( '.picker:eq(0)' );
			var selected_slot     = picker.find( 'li.selected' ).not( '.slot_empty' );
			var duration          = picker.attr( 'data-appointment_duration' );
			var combined_duration = picker.data( 'combined_duration' ) ? picker.data( 'combined_duration' ) : duration;
			var days_needed       = ( 1 > combined_duration ) ? 1 : combined_duration;
			var days_highlighted  = days_needed - 1;

			if ( 0 < days_needed ) {
				picker.find( 'li' ).removeClass( 'selected-month' );
				selected_slot.nextAll().slice( 0, days_highlighted ).addClass( 'selected-month' );
			}
		}
	};

	wc_appointments_month_picker.init();
} );
	},
	'month-picker'
);
