/**
 * Recurring package — admin panel + calendar.
 *
 * @since 5.4.0
 */

var panelSeries = ( function() {
	'use strict';

	var wpEl = window.wp && window.wp.element;
	var wpIcon = window.wcaWpIcons && window.wcaWpIcons.render ? window.wcaWpIcons.render : function() { return null; };
	var payColon = function( h, label, amount, currency, link ) {
		return window.__wcaPanelPayColon ? window.__wcaPanelPayColon( h, label, amount, currency, link ) : [];
	};
	var paySpan = function( h, key, label, amount, currency, link ) {
		return window.__wcaPanelPayAmountSpan
			? window.__wcaPanelPayAmountSpan( h, key, label, amount, currency, link )
			: h( 'span', { key: key }, payColon( h, label, amount, currency, link ) );
	};
	var preloadById = {};
	var preloadPending = {};

	var sh = window.wcaShared;
	var rp = sh.recurringPreview;

	function cfg() {
		return window.wcaPanel || {};
	}

	function t( key, fb, replacements ) {
		return sh.i18n( cfg().recurring || {}, key, fb || key, replacements );
	}

	function sid( appt ) {
		return appt ? parseInt( appt.series_id || appt.seriesId || 0, 10 ) : 0;
	}

	function restFetch( path, options ) {
		options = options || {};
		return sh.restJson( ( cfg().seriesRestUrl || '' ).replace( /\/$/, '' ) + path, {
			method: options.method || 'GET',
			nonce: cfg().nonce || '',
			idempotency: true,
			cache: 'no-store',
			body: options.body
		} );
	}

	function seriesPreloadSlice( row ) {
		if ( ! row ) {
			return null;
		}
		return {
			series_checkout_order_id: row.series_checkout_order_id || 0,
			series_payment: row.series_payment || null,
			series_pattern_summary: row.series_pattern_summary || '',
			series_count_cap: row.series_count_cap || 0,
			series_occurrences: Array.isArray( row.series_occurrences ) ? row.series_occurrences : null
		};
	}

	function indexPreloadFromRows( rows ) {
		if ( ! rows ) {
			return;
		}
		for ( var i = 0; i < rows.length; i++ ) {
			var id = parseInt( rows[ i ].series_id || rows[ i ].seriesId || 0, 10 );
			var slice = seriesPreloadSlice( rows[ i ] );
			if ( id > 0 && slice && Array.isArray( slice.series_occurrences ) ) {
				preloadById[ id ] = slice;
			}
		}
	}

	function mergeApptPreload( appt ) {
		if ( ! appt ) {
			return appt;
		}
		var id = sid( appt );
		if ( id <= 0 || Array.isArray( appt.series_occurrences ) ) {
			return appt;
		}
		var row = preloadById[ id ];
		if ( ! row ) {
			return appt;
		}
		return Object.assign( {}, appt, row );
	}

	function snapshotFromAppt( appt, seriesId ) {
		appt = mergeApptPreload( appt );
		if ( appt && Array.isArray( appt.series_occurrences ) ) {
			return {
				loading: false,
				payment: appt.series_payment || null,
				occurrences: appt.series_occurrences,
				checkoutOrderId: parseInt( appt.series_checkout_order_id || 0, 10 )
			};
		}
		return { loading: !! seriesId, payment: null, occurrences: [], checkoutOrderId: 0 };
	}

	function loadPreload( seriesId ) {
		if ( preloadById[ seriesId ] ) {
			return Promise.resolve( preloadById[ seriesId ] );
		}
		if ( ! preloadPending[ seriesId ] ) {
			preloadPending[ seriesId ] = Promise.all( [
				restFetch( '/' + seriesId ),
				restFetch( '/' + seriesId + '/occurrences?limit=50' )
			] ).then( function( res ) {
				var series = res[ 0 ] || {};
				var row = {
					series_checkout_order_id: parseInt( series.order_id || 0, 10 ),
					series_payment: series.payment || null,
					series_pattern_summary: series.pattern_summary || '',
					series_count_cap: parseInt( series.rrule_count_cap || 0, 10 ),
					series_occurrences: ( res[ 1 ] && res[ 1 ].occurrences ) || []
				};
				if ( Array.isArray( row.series_occurrences ) ) {
					preloadById[ seriesId ] = row;
				}
				delete preloadPending[ seriesId ];
				return row;
			} ).catch( function( err ) {
				delete preloadPending[ seriesId ];
				throw err;
			} );
		}
		return preloadPending[ seriesId ];
	}

	function useSeriesBundle( seriesId, appt ) {
		var empty = { loading: false, payment: null, occurrences: [], checkoutOrderId: 0, setPayment: function() {} };
		if ( ! wpEl || ! wpEl.useState || ! wpEl.useEffect ) {
			return empty;
		}
		var useState = wpEl.useState;
		var useEffect = wpEl.useEffect;
		var state = useState( snapshotFromAppt( appt, seriesId ) );
		var snap = state[ 0 ];
		var setSnap = state[ 1 ];

		useEffect( function() {
			if ( ! seriesId ) {
				setSnap( { loading: false, payment: null, occurrences: [], checkoutOrderId: 0 } );
				return;
			}
			var ready = snapshotFromAppt( appt, seriesId );
			if ( ! ready.loading ) {
				setSnap( ready );
				return;
			}
			var cancelled = false;
			setSnap( { loading: true, payment: null, occurrences: [], checkoutOrderId: 0 } );
			loadPreload( seriesId ).then( function() {
				if ( ! cancelled ) {
					setSnap( snapshotFromAppt( appt, seriesId ) );
				}
			} ).catch( function() {
				if ( ! cancelled ) {
					setSnap( { loading: false, payment: null, occurrences: [], checkoutOrderId: 0 } );
				}
			} );
			return function() {
				cancelled = true;
			};
		}, [ seriesId, appt ] );

		function setPayment( payment ) {
			if ( preloadById[ seriesId ] ) {
				preloadById[ seriesId ].series_payment = payment;
			}
			setSnap( function( prev ) {
				return { loading: false, payment: payment, occurrences: prev.occurrences, checkoutOrderId: prev.checkoutOrderId };
			} );
		}

		return { loading: snap.loading, payment: snap.payment, occurrences: snap.occurrences, checkoutOrderId: snap.checkoutOrderId, setPayment: setPayment };
	}

	function apptFromExtendedProps( p ) {
		if ( ! p || ! p.appointmentId ) {
			return null;
		}
		return mergeApptPreload( {
			id: p.appointmentId,
			product_id: p.productId,
			product_title: p.productTitle || '',
			cal_color: p.calColor || '',
			duration_unit: p.durationUnit || '',
			duration: p.duration || 0,
			staff_id: p.staffId,
			staff_name: p.staffName || '',
			staff_avatar: p.staffAvatar || '',
			location_id: p.locationId || 0,
			location_display: p.locationDisplay || '',
			resource_display: p.resourceDisplay || '',
			resource_allocations: Array.isArray( p.resourceAllocations ) ? p.resourceAllocations : [],
			meeting_join_url: p.meetingJoinUrl || '',
			status: p.status,
			start_ts: p.start_ts,
			end_ts: p.end_ts,
			customer_id: p.customerId,
			order_id: p.orderId,
			order_item_id: p.orderItemId,
			qty: p.qty || 1,
			order_info: p.orderInfo || null,
			customer_status: p.customerStatus || '',
			customer_name: p.customerName || '',
			customer_first_name: p.customerFirstName || '',
			customer_last_name: p.customerLastName || '',
			customer_full_name: p.customerFullName || '',
			customer_email: p.customerEmail || '',
			customer_phone: p.customerPhone || '',
			customer_avatar: p.customerAvatar || '',
			local_timezone: p.local_timezone || '',
			customer_timezone: p.customer_timezone || '',
			series_id: p.seriesId || 0,
			series_occurrence: p.seriesOccurrence || 0,
			series_count_cap: p.seriesCountCap || 0,
			series_checkout_order_id: p.seriesCheckoutOrderId || 0,
			series_payment: p.seriesPayment || null,
			series_pattern_summary: p.seriesPatternSummary || '',
			series_occurrences: Array.isArray( p.seriesOccurrences ) ? p.seriesOccurrences : null
		} );
	}

	function seriesHint( appt ) {
		if ( ! sid( appt ) ) {
			return null;
		}
		var pattern = appt.series_pattern_summary || '';
		var occ = parseInt( appt.series_occurrence || 0, 10 );
		var total = parseInt( appt.series_count_cap || 0, 10 );
		var titleParts = [ t( 'recurringLabel', 'Recurring package' ) ];
		if ( pattern ) {
			titleParts.push( pattern );
		}
		if ( occ > 0 && total > 0 ) {
			titleParts.push( t( 'sessionOf', 'Appointment %1$d of %2$d', { '%1$d': occ, '%2$d': total } ) );
		}
		return { title: titleParts.join( ' · ' ), count: ( occ > 0 && total > 0 ) ? ( occ + '/' + total ) : '' };
	}

	function recurringAbbr( h, appt ) {
		var hint = seriesHint( appt );
		if ( ! h || ! hint ) {
			return null;
		}
		return h( 'abbr', { className: 'wca-list-recurring', title: hint.title },
			h( 'span', { className: 'wca-list-recurring__icon', 'aria-hidden': 'true' }, '\u21BB' ),
			hint.count ? h( 'span', { className: 'wca-list-recurring__count' }, hint.count ) : null
		);
	}

	/** True when the appointment is in a series and status or schedule fields are dirty. */
	function needsSeriesScope( appt, dirty ) {
		return sid( appt ) > 0 && !! dirty;
	}

	/** Apply-to choices for status and schedule scope (one | future | all). */
	function SeriesScopeBlock( props ) {
		var h = props.h;
		if ( ! h || ! props.visible || ! sid( props.appt ) ) {
			return null;
		}
		var value = props.value || 'one';
		var legend = t( 'scopeLegend', 'Apply to' );
		var apptId = sid( props.appt );
		return h( 'div', { className: 'wca-expansion wca-expansion--expanded wca-form-series-scope-section' },
			h( 'div', { className: 'wca-expansion__header', role: 'presentation' },
				h( 'span', { className: 'wca-expansion__title' }, legend )
			),
			h( 'div', { className: 'wca-expansion__body', role: 'radiogroup', 'aria-label': legend },
				h( 'ul', { className: 'wc-deposits-option' }, [
					[ 'one', t( 'scopeOne', 'This appointment only' ) ],
					[ 'future', t( 'scopeFuture', 'This and following appointments' ) ],
					[ 'all', t( 'scopeAll', 'All appointments in the series' ) ]
				].map( function( opt ) {
					var id = 'wca-series-scope-' + opt[ 0 ] + '-' + apptId;
					return h( 'li', { key: opt[ 0 ] },
						h( 'input', {
							type: 'radio',
							id: id,
							name: 'wca-series-scope',
							value: opt[ 0 ],
							checked: value === opt[ 0 ],
							onChange: function() { props.onChange && props.onChange( opt[ 0 ] ); }
						} ),
						h( 'label', { htmlFor: id }, opt[ 1 ] )
					);
				} ) )
			)
		);
	}

	function SeriesPricingBlock( props ) {
		var h = props.h;
		var appt = props.appt || {};
		var bundle = props.bundle;
		var buildDefaultPricing = props.buildDefaultPricing;
		var useState = wpEl.useState;
		var seriesId = sid( appt );

		if ( ! h || ! bundle || ! seriesId ) {
			return buildDefaultPricing ? buildDefaultPricing() : null;
		}

		var payment = bundle.payment;
		var uiState = useState( { busy: false, msg: '', msgType: '' } );
		var ui = uiState[ 0 ];
		var setUi = uiState[ 1 ];

		if ( bundle.loading && ! payment ) {
			return h( 'div', { className: 'wca-appointment-items' },
				h( 'div', { className: 'wca-pricing-section' },
					h( 'span', { className: 'wca-skeleton wca-skeleton-cost' } )
				)
			);
		}

		if ( ! payment || 'pay_first' !== payment.payment_model ) {
			return buildDefaultPricing ? buildDefaultPricing() : null;
		}

		var currency = payment.currency || '';
		var checkoutLink = cfg().canViewOrders && payment.checkout_order_edit_url ? payment.checkout_order_edit_url : '';
		var rows = [];
		var meta = [];

		if ( payment.has_open_balance ) {
			rows.push( h( 'div', { key: 'due' }, payColon( h, t( 'balanceDue', 'Balance due' ), payment.balance_due, currency ) ) );
			if ( payment.paid_upfront > 0 ) {
				meta.push( paySpan( h, 'paid', t( 'paidUpfront', 'Paid upfront' ), payment.paid_upfront, currency, checkoutLink ) );
			}
			if ( payment.series_total > 0 ) {
				meta.push( paySpan( h, 'total', t( 'seriesTotal', 'Series total' ), payment.series_total, currency ) );
			}
		} else if ( 'paid' === payment.balance_status ) {
			rows.push( h( 'div', { key: 'settled', className: 'wca-series-pay-settled' },
				payment.series_total > 0
					? payColon( h, t( 'balancePaid', 'Balance paid' ), payment.series_total, currency )
					: t( 'balancePaid', 'Balance paid' )
			) );
		}
		if ( meta.length ) {
			rows.push( h( 'div', { key: 'meta', className: 'wca-cost-tax-group' }, meta ) );
		}

		var btnClass = 'wca-contact-icon wca-contact-icon--text';
		var actions = [];
		if ( cfg().canViewOrders && bundle.setPayment ) {
			var admin = payment.admin || {};
			function runAction( action, body, okMsg ) {
				setUi( { busy: true, msg: '', msgType: '' } );
				var payload = body || {};
				payload.action = action;
				restFetch( '/' + seriesId + '/balance', { method: 'POST', body: payload } ).then( function( data ) {
					if ( data && data.series && data.series.payment ) {
						bundle.setPayment( data.series.payment );
					}
					setUi( { busy: false, msg: okMsg || t( 'balanceActionDone', 'Saved.' ), msgType: 'success' } );
				} ).catch( function( err ) {
					setUi( {
						busy: false,
						msg: err && err.message ? err.message : t( 'balanceActionFailed', 'Action failed.' ),
						msgType: 'error'
					} );
				} );
			}
			function actionBtn( key, label, onClick ) {
				return h( 'button', { key: key, type: 'button', className: btnClass, disabled: ui.busy, onClick: onClick }, label );
			}
			if ( payment.balance_order_edit_url ) {
				actions.push( h( 'a', { key: 'view', className: btnClass, href: payment.balance_order_edit_url, target: '_blank', rel: 'noopener noreferrer' }, t( 'viewBalanceOrder', 'View balance order' ) ) );
			} else if ( admin.can_create_balance_order ) {
				actions.push( actionBtn( 'create', t( 'createBalanceOrder', 'Create balance order' ), function() {
					runAction( 'create_order', { send_invoice: false }, t( 'balanceOrderCreated', 'Balance order created.' ) );
				} ) );
			}
			if ( admin.can_send_payment_request ) {
				actions.push( actionBtn( 'invoice', t( 'sendPaymentRequest', 'Send payment request' ), function() {
					runAction( 'invoice', {}, t( 'paymentRequestSent', 'Payment request sent.' ) );
				} ) );
			}
			if ( admin.can_mark_paid_offline ) {
				actions.push( actionBtn( 'offline', t( 'markPaidOffline', 'Mark paid offline' ), function() {
					if ( window.confirm( t( 'markPaidOfflineConfirm', 'Mark the remaining balance as paid offline?' ) ) ) {
						runAction( 'paid_offline', {}, t( 'balanceMarkedPaid', 'Balance marked paid.' ) );
					}
				} ) );
			}
		}

		if ( actions.length ) {
			rows.push( h( 'div', { key: 'actions', className: 'wca-contact-icons wca-contact-icons--row' }, actions ) );
		}
		if ( ui.msg ) {
			var icon = wpIcon( h, 'error' === ui.msgType ? 'closeSmall' : 'check', 'wca-wp-icon' );
			rows.push( h( 'p', {
				key: 'msg',
				className: 'wca-panel-series-msg' + ( 'error' === ui.msgType ? ' is-error' : '' ),
				role: 'status'
			}, icon, ui.msg ) );
		}

		return h( 'div', { className: 'wca-appointment-items' },
			h( 'div', { className: 'wca-pricing-section' }, rows )
		);
	}

	function SeriesFooterBlock( props ) {
		var h = props.h;
		var appt = props.appt || {};
		var bundle = props.bundle;
		var useState = wpEl.useState;
		var useRef = wpEl.useRef;
		var useEffect = wpEl.useEffect;
		var seriesId = sid( appt );

		if ( ! h || ! bundle || ! seriesId ) {
			return null;
		}

		var expandedState = useState( false );
		var expanded = expandedState[ 0 ];
		var setExpanded = expandedState[ 1 ];
		var blockRef = useRef( null );
		function scheduleSeriesFit( opening ) {
			var fit = window.wcaPanel && window.wcaPanel.scheduleSectionFit;
			if ( fit ) { fit( blockRef, opening ); }
		}
		useEffect( function() {
			if ( expanded && ! bundle.loading ) {
				scheduleSeriesFit( true );
			}
		}, [ expanded, bundle.loading ] );
		var hint = seriesHint( appt );
		var toggleLabel = expanded ? t( 'seriesCollapse', 'Hide appointments' ) : t( 'seriesExpand', 'Show all appointments' );
		var valChildren = [
			h( 'div', { key: 'head', className: 'wca-panel-series-head' },
				hint && hint.count
					? h( 'abbr', { key: 'count', className: 'wca-list-recurring', title: hint.title },
						h( 'span', { className: 'wca-list-recurring__count' }, hint.count ) )
					: null,
				h( 'button', {
					key: 'toggle',
					type: 'button',
					className: 'wca-panel-series-expand wca-panel-text-link',
					onClick: function() {
						var opening = ! expanded;
						setExpanded( opening );
						scheduleSeriesFit( opening );
					},
					'aria-expanded': expanded ? 'true' : 'false'
				}, toggleLabel )
			)
		];

		if ( expanded ) {
			if ( bundle.loading ) {
				valChildren.push( h( 'p', { key: 'loading', className: 'wca-panel-series-list-msg' }, t( 'loading', 'Loading…' ) ) );
			} else if ( ! bundle.occurrences.length ) {
				valChildren.push( h( 'p', { key: 'empty', className: 'wca-panel-series-list-msg' }, t( 'noOccurrences', 'No appointments loaded.' ) ) );
			} else {
				valChildren.push( h( 'ul', { key: 'list', className: 'wca-panel-series-list' },
					bundle.occurrences.map( function( row ) {
						var apptId = parseInt( row.appointment_id, 10 );
						var isCur = apptId === parseInt( appt.id, 10 );
						var status = String( row.status || '' ).toLowerCase();
						var statusLabel = window.__wcaHumanizeAppointmentStatus
							? window.__wcaHumanizeAppointmentStatus( status )
							: status;
						return h( 'li', {
							key: String( row.appointment_id || row.recurrence_id || row.start_ts ),
							className: 'wca-panel-series-list-item' + ( isCur ? ' is-current' : '' ),
							'aria-current': isCur ? 'true' : undefined,
							title: isCur ? t( 'currentSession', 'Current' ) : undefined
						},
							h( 'span', { className: 'wca-panel-series-list-date' },
								window.__wcaFormatAppointmentRange
									? window.__wcaFormatAppointmentRange( row.start_ts, row.end_ts, true )
									: ''
							),
							status ? h( 'span', {
								className: 'wca-status-seg wca-status-seg--' + status + ' is-active wca-status-seg--readonly',
								title: statusLabel
							}, statusLabel ) : null,
							! isCur && apptId && window.wcaPanel && window.wcaPanel.open
								? h( 'button', {
									type: 'button',
									className: 'wca-panel-icon-btn',
									title: t( 'openSession', 'Open' ),
									'aria-label': t( 'openSession', 'Open' ),
									onClick: function() {
										window.wcaPanel.open( {
											mode: 'view',
											apptData: { id: apptId, start_ts: row.start_ts || 0 }
										} );
									}
								}, wpIcon( h, 'seen', null ) )
								: null
						);
					} )
				) );
			}
		}

		return h( 'div', { ref: blockRef, className: 'wca-panel-footer-series' },
			h( 'div', { className: 'wca-panel-grid wca-panel-footer-series-grid' },
				h( 'div', { className: 'wca-key' },
					h( 'span', { className: 'wca-key-inner' },
						wpIcon( h, 'recurring', 'wca-key-icon', { title: t( 'recurringLabel', 'Recurring package' ) } )
					)
				),
				h( 'div', { className: 'wca-val wca-panel-series-val' }, valChildren )
			)
		);
	}

	function productDurationSeconds( pd ) {
		if ( ! pd ) { return 0; }
		var n = parseInt( pd.duration, 10 ) || 0;
		var u = pd.duration_unit || 'minute';
		return 'hour' === u ? n * 3600 : 'day' === u ? n * 86400 : 'month' === u ? n * 2592000 : n * 60;
	}

	function previewDtstart( props ) {
		var slotTs = parseInt( props.slotStartTs, 10 ) || 0;
		if ( slotTs > 86400 ) { return slotTs; }
		var date = props.formDate || props.formDateFrom;
		if ( ! date ) { return 0; }
		var d = date.split( '-' );
		var tf = ( props.formTimeFrom || '00:00' ).split( ':' );
		return Date.UTC( parseInt( d[ 0 ], 10 ), parseInt( d[ 1 ], 10 ) - 1, parseInt( d[ 2 ], 10 ), parseInt( tf[ 0 ], 10 ), parseInt( tf[ 1 ] || 0, 10 ) ) / 1000;
	}

	/** Admin create panel — recurring schedule + preview (shared REST with storefront). */
	function CreateSeriesSection( props ) {
		var h = props.h;
		var tr = t;
		var pd = props.productDetails;
		var useState = wpEl.useState;
		var useEffect = wpEl.useEffect;
		var useRef = wpEl.useRef;
		var enabled = !! props.enabled;
		var onEnabledChange = props.onEnabledChange || function() {};
		var onMetaChange = props.onMetaChange || function() {};
		var minCount = ( pd && pd.recurring_min ) || 2;
		var maxCount = ( pd && pd.recurring_max ) || 52;
		var freqs = sh.normalizeFreqs( pd && pd.recurring_freqs );
		var singleFreq = freqs.length < 2;
		var freqLabels = { DAILY: tr( 'daily', 'Daily' ), WEEKLY: tr( 'weekly', 'Weekly' ), MONTHLY: tr( 'monthly', 'Monthly' ) };
		var i18nDict = cfg().recurring || {};

		// Hooks must run every render (no early return above) — parent keeps this mounted.
		var formState = useState( {
			freq: freqs[ 0 ] || 'WEEKLY',
			interval: 1,
			count: maxCount,
			preview: null,
			loading: false,
			error: ''
		} );
		var form = formState[ 0 ];
		var setForm = formState[ 1 ];
		var freq = form.freq;
		var interval = form.interval;
		var count = form.count;
		var preview = form.preview;
		var loading = form.loading;
		var error = form.error;
		function patchForm( patch ) {
			setForm( function( prev ) { return Object.assign( {}, prev, patch ); } );
		}
		var scheduleState = useState( rp.fresh );
		var schedule = scheduleState[ 0 ];
		var setSchedule = scheduleState[ 1 ];
		var anchorRecurrenceIdState = useState( '' );
		var anchorRecurrenceId = anchorRecurrenceIdState[ 0 ];
		var setAnchorRecurrenceId = anchorRecurrenceIdState[ 1 ];
		var previewExpandedState = useState( false );
		var previewExpanded = previewExpandedState[ 0 ];
		var setPreviewExpanded = previewExpandedState[ 1 ];
		var removeBlockedState = useState( false );
		var removeBlocked = removeBlockedState[ 0 ];
		var setRemoveBlocked = removeBlockedState[ 1 ];
		var timerRef = useRef( null );
		var reqRef = useRef( 0 );
		var freqSelectRef = useRef( null );
		var lastAnchorTsRef = useRef( 0 );
		var onSectionReveal = props.onSectionReveal || function() {};

		function resetScheduleAdjustments() {
			setSchedule( rp.fresh() );
			setRemoveBlocked( false );
			setPreviewExpanded( false );
		}

		function needsTimeSlot() {
			return rp.needsTimeSlot( ( pd && pd.duration_unit ) || 'minute' );
		}

		function hasAnchor() {
			return previewDtstart( props ) > 0 || ( ! needsTimeSlot() && ( props.formDate || props.formDateFrom ) );
		}

		function seriesStatus( sum ) {
			return rp.statusMessage( {
				tr: tr,
				error: error,
				removeBlocked: removeBlocked,
				hasAnchor: hasAnchor(),
				loading: loading,
				needsTimeSlot: needsTimeSlot(),
				summary: sum,
				minRequired: minCount
			} );
		}

		function pushMeta( rrule, sum ) {
			onMetaChange( {
				rrule: rrule,
				billable: sum ? sum.billable_count : 0,
				totalPrice: sum ? parseFloat( sum.total_price ) || 0 : 0,
				subtotal: sum ? parseFloat( sum.subtotal ) || 0 : 0,
				canSubmit: !!( sum && sum.billable_count >= minCount ),
				schedule: rp.payload( schedule )
			} );
		}

		function buildPreviewBody( rrule ) {
			var calCfg = window.wcAppointmentsReactCalendar || {};
			var body = {
				product_id: parseInt( props.productId, 10 ),
				dtstart_ts: previewDtstart( props ),
				timezone: calCfg.siteTimezone || cfg().siteTimezone || 'UTC',
				rrule: rrule,
				duration_seconds: productDurationSeconds( pd ),
				staff_id: props.staffId ? parseInt( props.staffId, 10 ) : 0,
				qty: props.formQty || 1,
				payment_model: 'prepaid'
			};
			return rp.attach( body, schedule );
		}

		function removeSession( recurrenceId ) {
			var billable = preview && preview.summary ? parseInt( preview.summary.billable_count, 10 ) || 0 : 0;
			var result = rp.removeOccurrence( schedule, recurrenceId, {
				anchorId: anchorRecurrenceId,
				billable: billable,
				minRequired: minCount
			} );
			if ( ! result ) {
				return;
			}
			if ( result.blocked ) {
				setRemoveBlocked( true );
				return;
			}
			setRemoveBlocked( false );
			setSchedule( result.schedule );
		}

		function applyRescheduleOverride( recurrenceId, startTs ) {
			var result = rp.applyOverride( schedule, recurrenceId, startTs );
			if ( result ) {
				setSchedule( result.schedule );
			}
		}

		function toggleReschedule( recurrenceId ) {
			var rrule = sh.buildRrule( freq, interval, count );
			var toggled = rp.toggleReschedule( schedule, recurrenceId );
			setSchedule( toggled.schedule );
			rp.fetchRescheduleSuggestions( toggled, recurrenceId, ( preview && preview.occurrences ) || [], function() {
				return buildPreviewBody( rrule );
			}, function( body ) {
				return restFetch( '/preview', { method: 'POST', body: body } );
			}, function( suggestions, id ) {
				setSchedule( function( prev ) {
					if ( prev.rescheduleTarget !== id ) {
						return prev;
					}
					return suggestions ? rp.setSuggestions( prev, id, suggestions ) : rp.patch( prev, { rescheduleFetching: '' } );
				} );
			} );
		}

		useEffect( function() {
			if ( ! pd || ! pd.allow_recurring ) { return; }
			patchForm( {
				freq: freqs.indexOf( freq ) < 0 ? freqs[ 0 ] : freq,
				count: maxCount
			} );
		}, [ pd ] );

		useEffect( function() {
			if ( ! enabled || singleFreq || ! pd || ! pd.allow_recurring ) { return; }
			var helpers = window.panelHelpers;
			if ( ! helpers || ! helpers.initEnhancedSelect ) { return; }
			var cleanup = null;
			var tmr = setTimeout( function() {
				cleanup = helpers.initEnhancedSelect( freqSelectRef, function( v ) {
					resetScheduleAdjustments();
					patchForm( { freq: v } );
				} );
				if ( helpers.setEnhancedSelectValue ) { helpers.setEnhancedSelectValue( freqSelectRef, freq ); }
			}, 0 );
			return function() {
				clearTimeout( tmr );
				if ( typeof cleanup === 'function' ) { try { cleanup(); } catch ( _e ) {} }
			};
		}, [ enabled, freq, freqs.join( ',' ), pd ] );

		useEffect( function() {
			if ( ! props.productId || ! pd || ! pd.allow_recurring ) {
				return;
			}
			if ( ! enabled ) {
				patchForm( { preview: null, error: '', loading: false } );
				resetScheduleAdjustments();
				onMetaChange( null );
				return;
			}
			var anchorTs = previewDtstart( props );
			if ( anchorTs > 0 && anchorTs !== lastAnchorTsRef.current ) {
				lastAnchorTsRef.current = anchorTs;
				resetScheduleAdjustments();
			}
			var rrule = sh.buildRrule( freq, interval, count );
			if ( ! props.formDate && ! props.formDateFrom ) {
				patchForm( { preview: null, loading: false } );
				pushMeta( rrule, null );
				return;
			}
			if ( timerRef.current ) { clearTimeout( timerRef.current ); }
			pushMeta( rrule, preview && preview.summary );
			timerRef.current = setTimeout( function() {
				var reqId = ++reqRef.current;
				patchForm( { loading: true, error: '' } );
				restFetch( '/preview', {
					method: 'POST',
					body: buildPreviewBody( rrule )
				} ).then( function( data ) {
					if ( reqId !== reqRef.current ) { return; }
					if ( data && data.summary ) {
						setAnchorRecurrenceId( rp.resolveAnchor( data.occurrences || [], anchorTs ) );
						patchForm( { preview: data, loading: false, error: '' } );
						pushMeta( rrule, data.summary );
					} else {
						patchForm( { preview: null, loading: false, error: ( data && data.message ) ? data.message : tr( 'previewFailed', 'Preview failed.' ) } );
						pushMeta( rrule, null );
					}
				} ).catch( function( err ) {
					if ( reqId !== reqRef.current ) { return; }
					patchForm( {
						preview: null,
						loading: false,
						error: err && err.message ? err.message : tr( 'previewFailed', 'Preview failed.' )
					} );
					pushMeta( rrule, null );
				} );
			}, 400 );
			return function() { if ( timerRef.current ) { clearTimeout( timerRef.current ); } };
		}, [ enabled, freq, interval, count, props.productId, props.formDate, props.formDateFrom, props.formTimeFrom, props.staffId, props.formQty, props.slotStartTs, pd, schedule.exdates.join( ',' ), JSON.stringify( schedule.overrides ) ] );

		useEffect( function() {
			if ( enabled && pd && pd.allow_recurring ) { onSectionReveal(); }
		}, [ enabled, loading, preview, count, freq, interval, pd ] );

		var ti = window.panelHelpers && window.panelHelpers.textInput
			? function( o ) { return window.panelHelpers.textInput( h, o ); }
			: null;
		if ( ! h || ! props.productId || ! pd || ! pd.allow_recurring || ! ti ) {
			return null;
		}

		var sum = preview && preview.summary;
		var occurrences = ( preview && preview.occurrences ) || [];
		var conflicts = sh.conflictsToMap( preview && preview.conflicts );
		var noticeText = enabled ? seriesStatus( sum ) : '';
		var listKids = [];
		var showPreviewToggle = false;

		if ( enabled ) {
			if ( loading && ! occurrences.length ) {
				listKids = [ 1, 2, 3 ].map( function( i ) {
					return h( 'li', { key: 'sk-' + i, className: 'wca-preview-item' }, h( 'span', { className: 'wca-slot-skeleton' } ) );
				} );
			} else if ( occurrences.length ) {
				rp.listPlan( occurrences, conflicts, previewExpanded ).forEach( function( item ) {
					if ( item.gap ) {
						listKids.push( h( 'li', {
							key: 'gap-' + item.gap,
							className: 'wca-preview-item wca-preview-ellipsis'
						}, tr( 'previewCollapsedSummary', '… and %d more appointments', item.gap ) ) );
						return;
					}
					var occ = occurrences[ item.idx ];
					var rid = occ.recurrence_id || '';
					listKids.push( h( 'li', {
						key: String( rid || occ.start_ts ),
						className: 'wca-preview-item' + ( schedule.rescheduleTarget === rid ? ' is-rescheduling' : '' ),
						'data-recurrence-id': rid,
						dangerouslySetInnerHTML: { __html: rp.rowHtml( {
							id: rid,
							anchor: rid && rid === anchorRecurrenceId,
							active: schedule.rescheduleTarget === rid,
							fetching: schedule.rescheduleFetching === rid,
							unavail: !! conflicts[ rid ],
							datetime: occ.display_label || '',
							i18n: cfg().recurring || {},
							suggestions: schedule.rescheduleTarget === rid ? ( schedule.slotSuggestions[ rid ] || [] ) : [],
							formatLabel: function( slot, ts ) {
								return slot && slot.display_label ? slot.display_label : String( ts );
							}
						} ) }
					} ) );
				} );
				showPreviewToggle = occurrences.length > rp.previewCollapseAt;
			}
		}

		return h( 'div', { className: 'wca-expansion wca-form-recurring-section' + ( enabled ? ' wca-expansion--expanded' : '' ) },
			h( 'label', {
				className: 'wca-expansion__header wca-form-recurring-header',
				'aria-expanded': enabled ? 'true' : 'false'
			},
				h( 'input', {
					type: 'checkbox',
					checked: enabled,
					onChange: function( e ) { onEnabledChange( e.target.checked ); }
				} ),
				h( 'span', { className: 'wca-expansion__title' }, tr( 'repeatThisAppointment', 'Repeat this appointment' ) )
			),
			enabled ? h( 'div', { className: 'wca-expansion__body' },
				h( 'div', { className: 'wca-form-row wca-form-recurring-fields' },
					! singleFreq ? ti( {
						id: 'wca-create-series-freq',
						label: tr( 'frequency', 'Frequency' ),
						value: freq,
						mod: 'grow',
						tag: 'select',
						ref: freqSelectRef,
						onChange: function( e ) {
							resetScheduleAdjustments();
							patchForm( { freq: e.target.value } );
						},
						children: freqs.map( function( f ) {
							return h( 'option', { key: f, value: f }, freqLabels[ f ] || f );
						} )
					} ) : null,
					ti( {
						id: 'wca-create-series-interval',
						label: singleFreq
							? tr( 'every', 'Every' ) + ' (' + rp.intervalUnit( freq, interval, i18nDict ) + ')'
							: tr( 'every', 'Every' ),
						value: interval,
						mod: singleFreq ? 'grow' : 'compact',
						type: 'number',
						min: 1,
						max: 12,
						onChange: function( e ) {
							resetScheduleAdjustments();
							patchForm( { interval: Math.max( 1, parseInt( e.target.value, 10 ) || 1 ) } );
						}
					} ),
					ti( {
						id: 'wca-create-series-count',
						label: tr( 'countLabel', 'Count' ),
						value: count,
						mod: 'compact',
						type: 'number',
						min: minCount,
						max: maxCount,
						onChange: function( e ) {
							resetScheduleAdjustments();
							var v = parseInt( e.target.value, 10 ) || minCount;
							patchForm( { count: Math.min( maxCount, Math.max( minCount, v ) ) } );
						}
					} )
				),
				h( 'div', { className: 'wca-slots-panel wca-create-series-preview' + ( loading ? ' is-loading' : '' ) },
					noticeText ? h( 'p', { className: 'wca-slots-notice wca-slots-notice--warning', 'aria-live': 'polite' }, noticeText ) : null,
					listKids.length ? h( 'ul', {
						className: 'wca-preview-list',
						onClick: function( ev ) {
							rp.handleListClick( ev, {
								onRemove: removeSession,
								onReschedule: toggleReschedule,
								getRescheduleTarget: function() {
									return schedule.rescheduleTarget;
								},
								onPickSlot: applyRescheduleOverride,
								canReschedule: true
							} );
						}
					}, listKids ) : null,
					showPreviewToggle ? h( 'button', {
						type: 'button',
						className: 'wca-expand-btn',
						onClick: function() { setPreviewExpanded( ! previewExpanded ); }
					}, previewExpanded
						? tr( 'showFewerSessions', 'Show fewer appointments' )
						: tr( 'showAllSessions', 'Show all %d appointments', occurrences.length ) ) : null
				)
			) : null
		);
	}

	return {
		sid: sid,
		mergeApptPreload: mergeApptPreload,
		indexPreloadFromRows: indexPreloadFromRows,
		apptFromExtendedProps: apptFromExtendedProps,
		useSeriesBundle: useSeriesBundle,
		isSeries: function( appt ) {
			return sid( appt ) > 0;
		},
		needsSeriesScope: needsSeriesScope,
		seriesHint: seriesHint,
		recurringAbbr: recurringAbbr,
		SeriesFooterBlock: SeriesFooterBlock,
		SeriesPricingBlock: SeriesPricingBlock,
		SeriesScopeBlock: SeriesScopeBlock,
		CreateSeriesSection: CreateSeriesSection
	};
}() );

window.panelSeries = panelSeries;
