/**
 * Panel Helpers — shared utility functions for the appointment admin panel.
 *
 * Extracted from appointment-admin-panel.js to eliminate duplication
 * between EditContent and CreateContent components.
 *
 * @since 5.3.0
 */

var panelHelpers = ( function() {
	'use strict';

	function isSlotsCacheEnabled() {
		return !! ( typeof window !== 'undefined' && window.wcaPanel && window.wcaPanel.slotsCacheEnabled );
	}

	/**
	 * Midnight / empty time is not a chosen slot (calendar date-only pick).
	 * Real midnight (or admin-TZ 00:00) slot picks carry a site-axis start timestamp.
	 *
	 * @param {string}          timeStr     Time string (admin or site).
	 * @param {number|string=}  slotStartTs Optional slot start timestamp (>86400 = real pick).
	 * @return {boolean}
	 */
	function isDateOnlyTimePlaceholder( timeStr, slotStartTs ) {
		if ( ! timeStr ) {
			return true;
		}
		var trimmed = String( timeStr ).trim();
		if ( '00:00' !== trimmed && '0:00' !== trimmed ) {
			return false;
		}
		if ( undefined !== slotStartTs && null !== slotStartTs && '' !== slotStartTs ) {
			return ( parseInt( slotStartTs, 10 ) || 0 ) <= 86400;
		}
		return true;
	}

	/** WC Checkout TextInput shell + control (opts.control for custom nodes). */
	function textInput( h, o ) {
		o = o || {};
		var id = o.id;
		var mod = o.mod || '';
		if ( mod && mod.indexOf( 'wca-field--' ) !== 0 ) {
			mod = 'wca-field--' + mod;
		}
		// date/time/month always float: native controls show their own placeholder chrome.
		var filled = o.forceActive ||
			( 'date' === o.type || 'time' === o.type || 'month' === o.type ) ||
			( 'number' === o.type && ( 0 === o.value || '0' === o.value ) ) ||
			( null != o.value && String( o.value ) !== '' );
		// Disabled selects often show a locked choice; keep the label floated.
		if ( ! filled && o.disabled && 'select' === ( o.tag || '' ) ) {
			filled = true;
		}
		var cls = 'wca-field wca-field--text-input' + ( mod ? ' ' + mod : '' );
		if ( filled ) {
			cls += ' is-active';
		}
		if ( o.error ) {
			cls += ' wca-field--error';
		}
		if ( o.disabled ) {
			cls += ' wca-field--disabled';
		}

		var control = o.control;
		if ( ! control ) {
			var tag = o.tag || 'input';
			var p = {
				id: id,
				className: o.controlClass || 'wca-field__control',
				'aria-labelledby': id + '-label'
			};
			var keys = [ 'ref', 'value', 'defaultValue', 'onChange', 'onFocus', 'disabled', 'readOnly', 'required', 'name', 'min', 'max', 'step', 'type' ];
			for ( var i = 0; i < keys.length; i++ ) {
				var k = keys[ i ];
				if ( o[ k ] !== undefined ) {
					p[ k ] = o[ k ];
				}
			}
			if ( 'number' === o.type && null != p.value ) {
				p.value = String( p.value );
			}
			control = undefined !== o.children
				? ( Array.isArray( o.children )
					? h.apply( null, [ tag, p ].concat( o.children ) )
					: h( tag, p, o.children ) )
				: h( tag, p );
		}

		return h( 'div', { className: cls },
			control,
			( o.label && id ) ? h( 'label', {
				className: 'wca-field__label' + ( o.labelAddon ? ' wca-field__label--with-addon' : '' ),
				id: id + '-label',
				htmlFor: id,
				title: o.label
			}, o.labelAddon ? [ h( 'span', { className: 'wca-field__label-text' }, o.label ), o.labelAddon ] : o.label ) : null
		);
	}

	/**
	 * Whether an AJAX search value contains real HTML tags (vs plain text with "<").
	 *
	 * @param {*} raw Value from JSON search.
	 * @return {boolean}
	 */
	function ajaxSelectLabelHasMarkup( raw ) {
		return typeof raw === 'string' && /<[a-zA-Z][\s\S]*?>/.test( raw );
	}

	/**
	 * Strip tags and decode HTML entities for plain-text Select2 / SelectWoo labels.
	 * WooCommerce JSON search returns strings with literal entities (e.g. &ndash;) and sometimes markup.
	 *
	 * @param {*} str Raw label from AJAX or REST.
	 * @return {string}
	 */
	function sanitizeSelect2Label( str ) {
		if ( str === null || str === undefined ) {
			return '';
		}
		var s = String( str ).replace( /<[^>]+>/g, '' );
		if ( typeof document === 'undefined' ) {
			return s;
		}
		var d = document.createElement( 'div' );
		d.innerHTML = s;
		return d.textContent || d.innerText || '';
	}

	/**
	 * Customer AJAX / Select2 label → display name only (calendar preview titles).
	 * WooCommerce search often returns "Name (email@domain.tld)" and may append " #123" or "(#123)".
	 *
	 * @param {*} raw Label from customer search or REST.
	 * @return {string} Plain name, or empty if nothing usable remains.
	 */
	function customerNameFromSelectLabel( raw ) {
		var s = sanitizeSelect2Label( raw ).trim();
		if ( ! s ) {
			return '';
		}
		s = s.replace( /\s*\(#\d+\)\s*$/, '' ).replace( /\s*#\d+\s*$/, '' ).trim();
		var m;
		while ( ( m = s.match( /^(.+?)\s*\(([^)]+)\)\s*$/ ) ) && /[@]/.test( m[ 2 ] ) ) {
			s = m[ 1 ].trim();
		}
		m = s.match( /^(.+?)\s+[—–-]\s+.+@.+\s*$/ );
		if ( m ) {
			return m[ 1 ].trim();
		}
		m = s.match( /^(.+?)\s+[^\s@]+@[^\s.]+\.[^\s]+\s*$/ );
		if ( m && m[ 1 ].trim() ) {
			return m[ 1 ].trim();
		}
		return s;
	}

	/**
	 * Remove orphaned Select2/SelectWoo dropdown containers from <body> that
	 * belong to panel selects. These use the 'wca-panel-dropdown' class set via
	 * dropdownCssClass. Orphans can be left behind if the underlying <select>
	 * was removed from the DOM before Select2.destroy() could clean up.
	 */
	function cleanOrphanedPanelDropdowns() {
		try {
			var containers = document.querySelectorAll( 'body > .select2-container' );
			for ( var i = 0; i < containers.length; i++ ) {
				if ( containers[ i ].querySelector( '.wca-panel-dropdown' ) ) {
					containers[ i ].remove();
				}
			}
			// Also remove stray open dropdown overlays
			var dropdowns = document.querySelectorAll( 'body > .wca-panel-dropdown' );
			for ( var j = 0; j < dropdowns.length; j++ ) {
				dropdowns[ j ].remove();
			}
		} catch ( e ) {}
	}

	// ─── Enhanced Select Initialization ──────────────────────────

	/**
	 * Initialize selectWoo/select2 on a ref element.
	 *
	 * @param {Object}   ref        React ref whose .current is the <select> DOM node.
	 * @param {Object}   [opts]     Extra select2 options to merge.
	 * @param {Function} onChangeFn Called with the new value on change.
	 * @return {Function|undefined} Cleanup function to destroy the instance.
	 */
	function initEnhancedSelect( ref, opts, onChangeFn ) {
		// Allow 2-arg signature: initEnhancedSelect( ref, onChangeFn )
		if ( 'function' === typeof opts ) {
			onChangeFn = opts;
			opts = {};
		}
		var $ = window.jQuery;
		if ( ! $ || ! ref.current ) { return; }
		var method = $.fn.selectWoo ? 'selectWoo' : ( $.fn.select2 ? 'select2' : null );
		if ( ! method ) { return; }
		var $el = $( ref.current );
		var defaults = {
			minimumResultsForSearch: 10,
			width: '100%',
			dropdownCssClass: 'wca-panel-dropdown',
			escapeMarkup: function( m ) {
				return m;
			},
			templateResult: function( data ) {
				if ( ! data || data.loading ) {
					return data ? data.text : '';
				}
				return data.text;
			},
			templateSelection: function( data ) {
				if ( ! data ) {
					return '';
				}
				return data.text;
			}
		};
		var merged = {};
		var k;
		for ( k in defaults ) { if ( defaults.hasOwnProperty( k ) ) { merged[ k ] = defaults[ k ]; } }
		if ( opts ) { for ( k in opts ) { if ( opts.hasOwnProperty( k ) ) { merged[ k ] = opts[ k ]; } } }
		try {
			if ( $el.hasClass( 'select2-hidden-accessible' ) || $el.hasClass( 'selectWoo-hidden-accessible' ) ) {
				$el[ method ]( 'destroy' );
			}
			$el[ method ]( merged );
			$el.off( 'change.wcaPanel' ).on( 'change.wcaPanel', function() {
				onChangeFn( $el.val() || '' );
			} );
		} catch ( e ) {}
		return function() {
			try {
				$el.off( 'change.wcaPanel' );
				try { $el[ method ]( 'close' ); } catch ( e ) {}
				if ( $el.hasClass( 'select2-hidden-accessible' ) || $el.hasClass( 'selectWoo-hidden-accessible' ) ) {
					$el[ method ]( 'destroy' );
				}
			} catch ( e ) {}
			cleanOrphanedPanelDropdowns();
		};
	}

	/**
	 * Set value on a selectWoo/select2-enhanced <select> (jQuery boundary for panel React code).
	 *
	 * @param {Object} ref  React ref whose .current is the <select> DOM node.
	 * @param {string} value
	 */
	function setEnhancedSelectValue( ref, value ) {
		var $ = window.jQuery;
		if ( ! $ || ! ref || ! ref.current ) {
			return;
		}
		var $el = $( ref.current );
		if ( ! ( $el.hasClass( 'select2-hidden-accessible' ) || $el.hasClass( 'selectWoo-hidden-accessible' ) ) ) {
			return;
		}
		var next = null == value ? '' : String( value );
		// Select2 only: bare `change` re-enters change.wcaPanel and can clear staff/location on sync.
		$el.val( next ).trigger( 'change.select2' );
	}

	/**
	 * Build product <option> list from preloaded products; ensure selected id is present.
	 *
	 * @param {Array}  products     { id, name }[]
	 * @param {string} selectedId
	 * @param {string} selectedName
	 * @return {Array<{value:string,label:string}>}
	 */
	function productSelectOptions( products, selectedId, selectedName ) {
		var opts = ( products || [] ).map( function( p ) {
			return { value: String( p.id ), label: p.name || ( '#' + p.id ) };
		} );
		var sid = selectedId ? String( selectedId ) : '';
		if ( sid && ! opts.some( function( o ) { return o.value === sid; } ) ) {
			opts.unshift( { value: sid, label: selectedName || ( '#' + sid ) } );
		}
		return opts;
	}

	/**
	 * Local (preloaded) product select — instant open; no AJAX; not clearable.
	 *
	 * @param {Object}   ref
	 * @param {Array}    options  From productSelectOptions()
	 * @param {Function} setId
	 * @param {Function} setName
	 * @return {Function|undefined} Cleanup
	 */
	function initPreloadedProductSelect( ref, options, setId, setName ) {
		// Always show the filter box: default minimumResultsForSearch (10) hides it for small catalogs,
		// so typing focuses result rows instead of filtering (create panel product select).
		return initEnhancedSelect( ref, { minimumResultsForSearch: 0 }, function( v ) {
			setId( v );
			var label = '';
			if ( v ) {
				for ( var i = 0; i < options.length; i++ ) {
					if ( options[ i ].value === String( v ) ) {
						label = options[ i ].label;
						break;
					}
				}
			}
			setName( label );
		} );
	}

	/**
	 * Initialize an AJAX-powered select2 (for customer/order search).
	 *
	 * @param {Object}   ref         React ref whose .current is the <select> DOM node.
	 * @param {Object}   ajaxOpts    { url, action, security, placeholder, onSelect, onClear }
	 * @return {Function|undefined}  Cleanup function.
	 */
	function initAjaxSelect( ref, ajaxOpts ) {
		var $ = window.jQuery;
		if ( ! $ || ! ref.current ) { return; }
		var method = $.fn.selectWoo ? 'selectWoo' : ( $.fn.select2 ? 'select2' : null );
		if ( ! method ) { return; }
		var $el = $( ref.current );
		try {
			if ( $el.hasClass( 'select2-hidden-accessible' ) || $el.hasClass( 'selectWoo-hidden-accessible' ) ) {
				$el[ method ]( 'destroy' );
			}
			var defaultProcessResults = function( data, params ) {
				var items = [];
				var more = false;
				if ( data && 'object' === typeof data ) {
					// Handle paginated structure { results: [], more: true/false }
					if ( data.results && 'object' === typeof data.results ) {
						more = !! data.more;
						data = data.results;
					}
					var keys = Object.keys( data );
					for ( var ki = 0; ki < keys.length; ki++ ) {
						var raw = data[ keys[ ki ] ];
						var plain = sanitizeSelect2Label( raw );
						var row = { id: keys[ ki ], text: plain || ( '#' + keys[ ki ] ) };
						if ( ajaxSelectLabelHasMarkup( raw ) ) {
							row.richHtml = raw;
						}
						items.push( row );
					}
				}
				return { results: items, pagination: { more: more } };
			};
			var defaultTemplateResult = function( data ) {
				if ( ! data ) {
					return '';
				}
				if ( data.loading ) {
					return data.text;
				}
				if ( data.richHtml ) {
					return $( '<span class="wca-select2-html-label"></span>' ).html( data.richHtml );
				}
				return data.text;
			};
			var defaultTemplateSelection = function( data ) {
				if ( ! data ) {
					return '';
				}
				if ( data.richHtml ) {
					return $( '<span class="wca-select2-html-label"></span>' ).html( data.richHtml );
				}
				return data.text;
			};
			$el[ method ]( {
				width: '100%',
				dropdownCssClass: 'wca-panel-dropdown',
				placeholder: ajaxOpts.placeholder || '',
				allowClear: ajaxOpts.allowClear !== false,
				minimumInputLength: ajaxOpts.minimumInputLength !== undefined ? ajaxOpts.minimumInputLength : 2,
				language: typeof wc_enhanced_select_params !== 'undefined' ? {
					inputTooShort: function( args ) {
						var n = args.minimum - args.input.length;
						return 1 === n
							? wc_enhanced_select_params.i18n_input_too_short_1
							: wc_enhanced_select_params.i18n_input_too_short_n.replace( '%qty%', n );
					}
				} : undefined,
				escapeMarkup: function( m ) {
					return m;
				},
				templateResult: ajaxOpts.templateResult || defaultTemplateResult,
				templateSelection: ajaxOpts.templateSelection || defaultTemplateSelection,
				ajax: {
					url: ajaxOpts.url,
					dataType: 'json',
					delay: 300,
					data: function( params ) {
						return {
							action: ajaxOpts.action,
							security: ajaxOpts.security || '',
							term: params.term || '',
							page: params.page || 1,
							current_id: $el.val() || ''
						};
					},
					processResults: ajaxOpts.processResults || defaultProcessResults,
					cache: true
				}
			} );
			$el.off( 'change.wcaPanel' ).on( 'change.wcaPanel', function() {
				var val = $el.val();
				var selText = '';
				if ( val ) {
					var selData = $el[ method ]( 'data' );
					selText = ( selData && selData[ 0 ] ) ? selData[ 0 ].text : ( '#' + val );
				}
				// Close Select2 BUT DO NOT destroy it BEFORE callbacks.
				// Removing destruction here allows the rich select to persist.
				// The useEffect cleanup handle destruction on unmount.
				try { $el[ method ]( 'close' ); } catch ( e ) {}
				if ( val ) {
					if ( ajaxOpts.onSelect ) { ajaxOpts.onSelect( String( val ), selText ); }
				} else {
					if ( ajaxOpts.onClear ) { ajaxOpts.onClear(); }
				}
			} );
		} catch ( e ) {}
		return function() {
			try {
				$el.off( 'change.wcaPanel' );
				try { $el[ method ]( 'close' ); } catch ( e ) {}
				if ( $el.hasClass( 'select2-hidden-accessible' ) || $el.hasClass( 'selectWoo-hidden-accessible' ) ) {
					$el[ method ]( 'destroy' );
				}
			} catch ( e ) {}
			cleanOrphanedPanelDropdowns();
		};
	}

	/**
	 * Move keyboard focus to a native <select> or its selectWoo/select2 selection control.
	 *
	 * @param {HTMLElement|string} elOrSelector
	 * @return {boolean}
	 */
	function focusPanelSelect( elOrSelector ) {
		var el = 'string' === typeof elOrSelector ? document.querySelector( elOrSelector ) : elOrSelector;
		if ( ! el ) {
			return false;
		}
		var $ = window.jQuery;
		if ( $ ) {
			var $el = $( el );
			if ( $el.hasClass( 'select2-hidden-accessible' ) || $el.hasClass( 'selectWoo-hidden-accessible' ) ) {
				var $selection = $el.next( '.select2-container, .selectWoo-container' ).find( '.select2-selection' ).first();
				if ( $selection.length && typeof $selection[ 0 ].focus === 'function' ) {
					$selection[ 0 ].focus();
					return true;
				}
			}
		}
		if ( typeof el.focus === 'function' ) {
			el.focus();
			return true;
		}
		return false;
	}

	// ─── AJAX Helpers ────────────────────────────────────────────

	/**
	 * Build a FormData instance from an action name and key/value fields object.
	 *
	 * @param {string} action  WP AJAX action name.
	 * @param {Object} fields  Key/value pairs to append.
	 * @return {FormData}
	 */
	function buildFormData( action, fields ) {
		var fd = new FormData();
		fd.append( 'action', action );
		if ( fields ) {
			var keys = Object.keys( fields );
			for ( var i = 0; i < keys.length; i++ ) {
				fd.append( keys[ i ], fields[ keys[ i ] ] );
			}
		}
		return fd;
	}

	/**
	 * Perform a fetch with AbortController support.
	 * Aborts any previous request stored in ctrlRef before starting a new one.
	 *
	 * @param {string}   url      AJAX URL.
	 * @param {FormData} body     Request body.
	 * @param {Object}   ctrlRef  React ref that holds the current AbortController.
	 * @return {Promise}          Resolves with parsed JSON.
	 */
	function abortableFetch( url, body, ctrlRef ) {
		if ( ctrlRef && ctrlRef.current && ctrlRef.current.abort ) {
			try { ctrlRef.current.abort(); } catch ( e ) {}
		}
		var ctrl = new AbortController();
		if ( ctrlRef ) { ctrlRef.current = ctrl; }
		return fetch( url, {
			method: 'POST',
			body: body,
			credentials: 'same-origin',
			signal: ctrl.signal
		} ).then( function( r ) { return r.json(); } );
	}

	// ─── Calendar Locale Helpers ─────────────────────────────────

	/**
	 * Get the calendar locale string (BCP 47 format) from panel config.
	 *
	 * @param {Object} panelCfg  The wcaPanel config object.
	 * @return {string|undefined}
	 */
	function getCalendarLocale( panelCfg ) {
		var loc = panelCfg.locale ? String( panelCfg.locale ) : '';
		return loc ? loc.replace( /_/g, '-' ) : undefined;
	}

	/**
	 * Get the first day of week (0=Sunday … 6=Saturday) from panel config.
	 *
	 * @param {Object} panelCfg  The wcaPanel config object.
	 * @return {number}
	 */
	function getFirstDayOfWeek( panelCfg ) {
		var fd = parseInt( panelCfg.firstday, 10 );
		return ( isNaN( fd ) || fd < 0 || fd > 6 ) ? 1 : fd;
	}

	/**
	 * Generate an array of 7 YYYY-MM-DD strings for the week that contains centerYMD,
	 * ordered from the site's first day of week (WordPress start_of_week).
	 *
	 * @param {string} centerYMD     A date in YYYY-MM-DD within the desired week.
	 * @param {number} firstDayOfWeek  0 = Sunday … 6 = Saturday (same as WP get_option( 'start_of_week' )).
	 * @return {string[]}
	 */
	function getStripDates( centerYMD, firstDayOfWeek ) {
		if ( ! centerYMD ) { return []; }
		var d = new Date( centerYMD + 'T12:00:00' );
		if ( isNaN( d.getTime() ) ) { return []; }
		var fd = parseInt( firstDayOfWeek, 10 );
		if ( isNaN( fd ) || fd < 0 || fd > 6 ) {
			fd = 1;
		}
		var dow = d.getDay();
		var offset = ( dow - fd + 7 ) % 7;
		d.setDate( d.getDate() - offset );
		var out = [];
		for ( var i = 0; i < 7; i++ ) {
			var x = new Date( d );
			x.setDate( x.getDate() + i );
			var y = x.getFullYear();
			var mo = ( '0' + ( x.getMonth() + 1 ) ).slice( -2 );
			var dy = ( '0' + x.getDate() ).slice( -2 );
			out.push( y + '-' + mo + '-' + dy );
		}
		return out;
	}

	/**
	 * Get unique YYYY-MM month keys that the 7-day strip spans.
	 *
	 * @param {string} centerYMD     Center date in YYYY-MM-DD format.
	 * @param {number} firstDayOfWeek 0–6, same as getStripDates().
	 * @return {string[]}
	 */
	function getMonthsForStrip( centerYMD, firstDayOfWeek ) {
		var dates = getStripDates( centerYMD, firstDayOfWeek );
		var set = {};
		for ( var i = 0; i < dates.length; i++ ) { set[ dates[ i ].substring( 0, 7 ) ] = true; }
		return Object.keys( set );
	}

	/**
	 * Get today's date as YYYY-MM-DD string.
	 *
	 * @return {string}
	 */
	function getTodayYMD() {
		var now = new Date();
		return now.getFullYear() + '-' + ( '0' + ( now.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + now.getDate() ).slice( -2 );
	}

	/**
	 * Get the current YYYY-MM string.
	 *
	 * @return {string}
	 */
	function getCurrentYM() {
		var now = new Date();
		return now.getFullYear() + '-' + ( '0' + ( now.getMonth() + 1 ) ).slice( -2 );
	}

	// ─── Fetch Wrappers (AJAX endpoints) ─────────────────────────

	/**
	 * Fetch month availability data (session memory + in-flight coalesce; not abortable).
	 *
	 * @param {string} ajaxUrl
	 * @param {Object} nonces
	 * @param {Object} params   { productId, yearMonth, staffId, qty, date?, editingAppointmentId?, strip?, stripCenter? }
	 * @param {Object} cacheRef React ref for month availability cache.
	 * @return {Promise<Object>}
	 */
	function fetchMonthAvailability( ajaxUrl, nonces, params, cacheRef ) {
		var sid = params.staffId || '';
		var q = parseInt( params.qty || '1', 10 );
		var editingAppointmentId = parseInt( params.editingAppointmentId || 0, 10 );
		var ck = monthAvailMemKey( params );
		var cacheEnabled = isSlotsCacheEnabled();

		if ( cacheEnabled && cacheRef && cacheRef.current ) {
			var cached = cacheRef.current[ ck ];
			if ( cached && ( Date.now() - cached.ts ) < 300000 ) {
				return Promise.resolve( { cached: true, data: cached.data } );
			}
		}

		var fd = buildFormData( 'wc_appointments_get_month_availability', {
			nonce: nonces.getMonthAvailability || '',
			product_id: params.productId,
			year_month: params.yearMonth,
			staff_id: sid,
			location_id: params.locationId || '',
			resource_id: params.resourceId || '',
			quantity: String( q ),
			date: params.date || '',
			editing_appointment_id: editingAppointmentId > 0 ? String( editingAppointmentId ) : '',
			strip: params.strip ? '1' : '',
			strip_center: params.stripCenter || ''
		} );

		return abortableFetch( ajaxUrl, fd, null ).then( function( resp ) {
			if ( resp && resp.success && resp.data ) {
				if ( cacheEnabled && cacheRef && cacheRef.current ) {
					cacheRef.current[ ck ] = { ts: Date.now(), data: resp.data };
				}
				return { cached: false, data: resp.data };
			}
			return { cached: false, data: { days: {}, months: {} } };
		} ).catch( function() {
			return { cached: false, data: { days: {}, months: {} } };
		} );
	}

	/** Session key for month days (+ optional strip window). */
	function monthAvailMemKey( params ) {
		var sid = params.staffId || '';
		var lid = params.locationId || '';
		var rid = params.resourceId || '';
		var q = parseInt( params.qty || '1', 10 );
		var editId = parseInt( params.editingAppointmentId || 0, 10 );
		var key = params.productId + '|' + params.yearMonth + '|' + sid + '|' + lid + '|' + rid + '|' + q + '|edit:' + editId;
		if ( params.strip ) {
			key += '|strip:' + ( params.stripCenter || params.date || '' );
		}
		return key;
	}

	/** Session key for a single day's slot list (matches fetchDaySlots). */
	function daySlotsMemKey( productId, date, staffId, qty, editId, locationId, resourceId ) {
		return productId + '|' + date + '|' + ( staffId || '' ) + '|' + ( locationId || '' ) + '|' + ( resourceId || '' ) + '|' + parseInt( qty || 1, 10 ) + '|edit:' + parseInt( editId || 0, 10 ) + '|slot_ts_v2';
	}

	/**
	 * Fetch day slots data.
	 *
	 * @param {string} ajaxUrl
	 * @param {Object} nonces
	 * @param {Object} params    { productId, date, staffId, qty }
	 * @param {Object} ctrlRef   React ref for AbortController.
	 * @param {Object} cacheRef  React ref for day slots cache.
	 * @return {Promise<Object>}
	 */
	function fetchDaySlots( ajaxUrl, nonces, params, ctrlRef, cacheRef ) {
		var sid = params.staffId || '';
		var lid = params.locationId || '';
		var rid = params.resourceId || '';
		var q = parseInt( params.qty || '1', 10 );
		var editingAppointmentId = parseInt( params.editingAppointmentId || 0, 10 );
		var ck = daySlotsMemKey( params.productId, params.date, sid, q, editingAppointmentId, lid, rid );
		var cacheEnabled = isSlotsCacheEnabled();

		if ( cacheRef && cacheRef.current ) {
			var boot = cacheRef.current[ ck ];
			if ( cacheEnabled && boot && ( Date.now() - boot.ts ) < 30000 ) {
				return Promise.resolve( { cached: true, data: boot.data } );
			}
		}

		var fd = buildFormData( 'wc_appointments_get_day_slots', {
			nonce: nonces.getDaySlots || '',
			product_id: params.productId,
			date: params.date,
			staff_id: sid,
			location_id: lid,
			resource_id: rid,
			quantity: String( q ),
			editing_appointment_id: editingAppointmentId > 0 ? String( editingAppointmentId ) : ''
		} );

		return abortableFetch( ajaxUrl, fd, ctrlRef ).then( function( resp ) {
			if ( resp && resp.success && resp.data ) {
				if ( cacheEnabled && cacheRef && cacheRef.current ) {
					cacheRef.current[ ck ] = { ts: Date.now(), data: resp.data };
				}
				return { cached: false, data: resp.data };
			}
			return { cached: false, data: { slots: [], total_available: 0 } };
		} ).catch( function( err ) {
			if ( err && err.name === 'AbortError' ) { throw err; }
			return { cached: false, data: { slots: [], total_available: 0 } };
		} );
	}

	/**
	 * Check appointment availability.
	 *
	 * @param {string} ajaxUrl
	 * @param {Object} nonces
	 * @param {Object} params    { productId, staffId, qty, date, timeFrom, timeTo, showTimeFields }
	 * @param {Object} ctrlRef   React ref for AbortController.
	 * @return {Promise<Object>} Resolves with { status: 'available'|'unavailable'|'', message: '' }
	 */
	function isMidnightPlaceholder( timeStr, slotStartTs ) {
		return isDateOnlyTimePlaceholder( timeStr, slotStartTs );
	}

	/**
	 * Whether availability AJAX has enough fields to run (matches fetchAvailability skip rules).
	 *
	 * @param {Object} params Availability params passed to fetchAvailability.
	 * @return {boolean}
	 */
	function availabilityParamsReady( params ) {
		if ( ! params || ! params.productId ) {
			return false;
		}
		if ( params.dateFrom !== undefined ) {
			return !!( params.dateFrom && params.dateTo );
		}
		if ( params.monthFrom !== undefined ) {
			return !!( params.monthFrom && params.monthTo );
		}
		if ( ! params.date ) {
			return false;
		}
		if ( params.showTimeFields ) {
			if ( ! params.timeFrom || isMidnightPlaceholder( params.timeFrom, params.slotStartTimestamp ) ) {
				return false;
			}
			if ( ! params.valuesAreSiteTz && ! params.timeTo ) {
				return false;
			}
		}
		return true;
	}

	function fetchAvailability( ajaxUrl, nonces, params, ctrlRef ) {
		if ( ! params.productId || ! ajaxUrl ) {
			return Promise.resolve( { status: '', message: '' } );
		}

		var siteDate = params.date || '';
		var siteTimeFrom = params.timeFrom || '';
		var siteTimeTo = params.timeTo || '';
		var siteDateFrom = params.dateFrom;
		var siteDateTo = params.dateTo;

		// Timed fields: admin→site. Civil dateFrom/dateTo stay as posted (no midnight shift).
		var utils = window.WCAppointmentsTimezoneUtils;
		if ( ! params.valuesAreSiteTz && utils && utils.convertAdminStringsToSiteTimezone && utils.getTimezoneConfig ) {
			var tzCfg = utils.getTimezoneConfig();
			if ( tzCfg.hasDifferentTz ) {
				if ( siteDate && siteTimeFrom ) {
					var cFrom = utils.convertAdminStringsToSiteTimezone( siteDate, siteTimeFrom );
					siteDate = cFrom.date;
					siteTimeFrom = cFrom.time;
				}
				if ( siteTimeTo ) {
					var dateForTimeTo = siteDate || params.date || siteDateTo || siteDateFrom || '';
					if ( dateForTimeTo ) {
						var cTo = utils.convertAdminStringsToSiteTimezone( dateForTimeTo, siteTimeTo );
						siteTimeTo = cTo.time;
					}
				}
			}
		}

		var fields = {
			nonce: nonces.checkAvailability || '',
			appointment_product_id: params.productId,
			appointment_staff_id: params.staffId || '',
			appointment_location_id: params.locationId || '',
			appointment_resource_id: params.resourceId || '',
			is_admin_panel: '1',
			quantity: parseInt( params.qty || '1', 10 )
		};

		// Date-range mode (day-based duration)
		if ( params.dateFrom !== undefined ) {
			if ( ! siteDateFrom || ! siteDateTo ) {
				return Promise.resolve( { status: '', message: '' } );
			}
			fields.appointment_date_from = siteDateFrom;
			fields.appointment_date_to = siteDateTo;
		// Month-range mode
		} else if ( params.monthFrom !== undefined ) {
			if ( ! params.monthFrom || ! params.monthTo ) {
				return Promise.resolve( { status: '', message: '' } );
			}
			fields.appointment_month_from = params.monthFrom;
			fields.appointment_month_to = params.monthTo;
		// Standard single-date mode
		} else {
			if ( ! siteDate ) {
				return Promise.resolve( { status: '', message: '' } );
			}
			fields.appointment_date = siteDate;
			if ( params.showTimeFields ) {
				if ( ! siteTimeFrom ) {
					return Promise.resolve( { status: '', message: '' } );
				}
				if ( ! params.valuesAreSiteTz && ! siteTimeTo ) {
					return Promise.resolve( { status: '', message: '' } );
				}
				fields.appointment_time_from = siteTimeFrom;
				if ( siteTimeTo ) { fields.appointment_time_to = siteTimeTo; }
				var sst = parseInt( params.slotStartTimestamp, 10 );
				if ( sst > 86400 ) {
					var sstStr = String( sst );
					fields.wc_appointments_field_start_date_timestamp = sstStr;
					fields.wca_slot_start_ts = sstStr;
				}
			}
		}

		// Pass addon duration (minutes) so the server includes it in availability checks.
		var addonsDur = parseInt( params.addonsDuration || 0, 10 );
		if ( addonsDur > 0 ) {
			fields.duration = addonsDur;
		}

		var editApptId = parseInt( params.editingAppointmentId || 0, 10 );
		if ( editApptId > 0 ) {
			fields.editing_appointment_id = String( editApptId );
		}


		var fd = buildFormData( 'wc_appointments_check_availability', fields );

		return abortableFetch( ajaxUrl, fd, ctrlRef ).then( function( resp ) {
			if ( resp && resp.success ) {
				return {
					status: ( resp.data && resp.data.available === false ) ? 'unavailable' : 'available',
					message: ( resp.data && ( resp.data.notice_message || resp.data.message ) ) ? ( resp.data.notice_message || resp.data.message ) : ''
				};
			}
			return {
				status: 'unavailable',
				message: resp && resp.data ? ( 'string' === typeof resp.data ? resp.data : ( resp.data.notice_message || resp.data.message || '' ) ) : ''
			};
		} ).catch( function( err ) {
			if ( err && 'AbortError' === err.name ) {
				return { status: '', message: '' };
			}
			return { status: 'unavailable', message: 'Error checking availability' };
		} );
	}

	/**
	 * Calculate appointment cost.
	 *
	 * @param {string} ajaxUrl
	 * @param {Object} params    { productId, staffId, qty, date, timeFrom, showTimeFields, addonsData }
	 * @param {Object} ctrlRef   React ref for AbortController.
	 * @return {Promise<Object>} Resolves with { html: '', raw: 0 }
	 */
	function fetchCost( ajaxUrl, params, ctrlRef ) {
		if ( ! params.productId || ! ajaxUrl ) {
			return Promise.resolve( { html: '', raw: 0 } );
		}

		var siteDate = params.date || '';
		var siteTimeFrom = params.timeFrom || '';
		var siteDateFrom = params.dateFrom;

		// Convert timed admin-TZ values to site-TZ. Civil dateFrom stays Y-m-d (no midnight shift).
		var utils = window.WCAppointmentsTimezoneUtils;
		if ( ! params.valuesAreSiteTz && utils && utils.convertAdminStringsToSiteTimezone && utils.getTimezoneConfig ) {
			var tzCfg = utils.getTimezoneConfig();
			if ( tzCfg.hasDifferentTz ) {
				if ( siteDate && siteTimeFrom ) {
					var cFrom = utils.convertAdminStringsToSiteTimezone( siteDate, siteTimeFrom );
					siteDate = cFrom.date;
					siteTimeFrom = cFrom.time;
				}
			}
		}

		var posted = {};
		posted[ 'appointable-product-id' ] = params.productId;
		posted.quantity = parseInt( params.qty || '1', 10 );
		if ( params.staffId ) { posted.wc_appointments_field_staff = params.staffId; }
		if ( params.locationId ) { posted.wc_appointments_field_location = params.locationId; }
		if ( params.resourceId ) { posted.wc_appointments_field_resource = params.resourceId; }

		// Date-range mode (day-based duration)
		if ( params.dateFrom !== undefined ) {
			if ( ! siteDateFrom ) { return Promise.resolve( { html: '', raw: 0 } ); }
			var dp2 = siteDateFrom.split( '-' );
			posted.wc_appointments_field_start_date_year = parseInt( dp2[ 0 ], 10 );
			posted.wc_appointments_field_start_date_month = parseInt( dp2[ 1 ], 10 );
			posted.wc_appointments_field_start_date_day = parseInt( dp2[ 2 ], 10 );
		// Month-range mode
		} else if ( params.monthFrom !== undefined ) {
			if ( ! params.monthFrom ) { return Promise.resolve( { html: '', raw: 0 } ); }
			posted.wc_appointments_field_start_date_yearmonth = params.monthFrom;
		// Standard single-date mode
		} else {
			if ( ! siteDate ) { return Promise.resolve( { html: '', raw: 0 } ); }
			var dp = siteDate.split( '-' );
			posted.wc_appointments_field_start_date_year = parseInt( dp[ 0 ], 10 );
			posted.wc_appointments_field_start_date_month = parseInt( dp[ 1 ], 10 );
			posted.wc_appointments_field_start_date_day = parseInt( dp[ 2 ], 10 );
			if ( params.showTimeFields && siteTimeFrom ) {
				posted.wc_appointments_field_start_date_time = siteTimeFrom;
				var costSlotTs = parseInt( params.slotStartTimestamp, 10 );
				if ( costSlotTs > 86400 ) {
					posted.wc_appointments_field_start_date_timestamp = String( costSlotTs );
				}
			}
		}

		// Include Product Add-Ons cost/duration
		if ( params.addonsDuration ) { posted.wc_appointments_field_addons_duration = params.addonsDuration; }
		if ( params.addonsCost ) { posted.wc_appointments_field_addons_cost = params.addonsCost; }

		// Memberships (and similar) discount against the selected customer, not the logged-in admin.
		if ( Object.prototype.hasOwnProperty.call( params, 'customerId' ) ) {
			posted.customer_id = parseInt( params.customerId, 10 ) || 0;
		}

		if ( params.wcDepositOption ) {
			posted.wc_deposit_option = params.wcDepositOption;
		}
		if ( params.wcDepositPlanId ) {
			posted.wc_deposit_payment_plan = params.wcDepositPlanId;
		}

		// Merge any addon form data
		if ( params.addonsData ) {
			var ak = Object.keys( params.addonsData );
			for ( var ai = 0; ai < ak.length; ai++ ) {
				posted[ ak[ ai ] ] = params.addonsData[ ak[ ai ] ];
			}
		}

		var fd = new FormData();
		fd.append( 'action', 'wc_appointments_calculate_costs' );
		fd.append( 'form', new URLSearchParams( posted ).toString() );
		// Top-level POST flag: when catalog prices are entered excl. tax, server quotes net for the panel footer.
		var panelCfgCost = window.wcaPanel || {};
		if ( ! panelCfgCost.pricesIncludeTax ) {
			fd.append( 'wc_appointments_panel_cost_excl_tax', '1' );
		}

		return abortableFetch( ajaxUrl, fd, ctrlRef ).then( function( resp ) {
			if ( resp && resp.success ) {
				var html = '';
				if ( 'string' === typeof resp.data ) { html = resp.data; }
				else if ( resp.data ) { html = resp.data.html || ''; }
				var tmp = document.createElement( 'div' );
				tmp.innerHTML = html;
				var strong = tmp.querySelector( 'strong' );
				var displayHtml = strong ? strong.innerHTML : html;
				// Extract raw number
				var raw = 0;
				if ( resp.data && 'object' === typeof resp.data && resp.data.raw_price !== undefined ) {
					raw = parseFloat( resp.data.raw_price ) || 0;
				} else {
					var numStr = displayHtml.replace( /<[^>]+>/g, '' ).replace( /[^\d.,\-]/g, '' ).replace( /,/g, '.' );
					raw = parseFloat( numStr ) || 0;
				}
				var rawFull = raw;
				var depositApplied = false;
				if ( resp.data && 'object' === typeof resp.data ) {
					if ( resp.data.raw_full_price !== undefined ) {
						rawFull = parseFloat( resp.data.raw_full_price ) || raw;
					}
					depositApplied = !! resp.data.deposit_applied;
				}
				return { html: displayHtml, raw: raw, rawFull: rawFull, depositApplied: depositApplied };
			}
			return { html: '', raw: 0 };
		} ).catch( function() {
			return { html: '', raw: 0 };
		} );
	}

	// ─── Browse Action Wrappers ─────────────────────────────────
	// High-level actions that manage browse state (from useBrowseState)
	// and delegate to the low-level fetch wrappers above.

	function loadMonthAvail( ajaxUrl, nonces, params, browse ) {
		if ( ! params.productId || ! params.yearMonth ) { return; }
		browse.setMiniCalMonth( params.yearMonth );
		browse.setMiniCalLoading( true );
		fetchMonthAvailability( ajaxUrl, nonces, {
			productId: params.productId, yearMonth: params.yearMonth,
			staffId: params.staffId || '', locationId: params.locationId || '', resourceId: params.resourceId || '', qty: params.qty,
			date: params.date || '', editingAppointmentId: params.editingAppointmentId || 0
		}, browse.refs.monthAvailCache ).then( function( result ) {
			browse.setMiniCalData( result.data );
		} ).finally( function() { browse.setMiniCalLoading( false ); } );
	}

	function loadStripAvail( ajaxUrl, nonces, params, browse ) {
		var productId = params.productId;
		var centerYMD = params.centerYMD;
		if ( ! productId || ! centerYMD ) { browse.setMiniCalStripCenter( '' ); return; }
		var firstDow = params.firstDayOfWeek;
		if ( firstDow === undefined || firstDow === null ) {
			firstDow = getFirstDayOfWeek( typeof window !== 'undefined' && window.wcaPanel ? window.wcaPanel : {} );
		}
		var months = getMonthsForStrip( centerYMD, firstDow );
		if ( ! months.length ) { return; }
		browse.setMiniCalStripCenter( centerYMD );
		browse.setMiniCalMonth( centerYMD.substring( 0, 7 ) );
		var sid = params.staffId || '';
		var lid = params.locationId || '';
		var rid = params.resourceId || '';
		var q = parseInt( params.qty || '1', 10 );
		var editId = parseInt( params.editingAppointmentId || 0, 10 );
		var stripMode = !! params.strip;
		var focusDate = params.date || centerYMD;
		var merged = { days: {} };
		browse.setMiniCalLoading( true );
		Promise.all( months.map( function( ym ) {
			return fetchMonthAvailability( ajaxUrl, nonces, {
				productId: productId, yearMonth: ym, staffId: sid, locationId: lid, resourceId: rid, qty: q,
				date: focusDate && focusDate.indexOf( ym ) === 0 ? focusDate : '',
				editingAppointmentId: editId, strip: stripMode, stripCenter: centerYMD
			}, browse.refs.monthAvailCache ).then( function( result ) {
				return ( ( result && result.data ) || {} ).days || {};
			} ).catch( function() { return {}; } );
		} ) ).then( function( results ) {
			for ( var ri = 0; ri < results.length; ri++ ) {
				for ( var dayKey in results[ ri ] ) { merged.days[ dayKey ] = results[ ri ][ dayKey ]; }
			}
			browse.setMiniCalData( merged );
		} ).finally( function() { browse.setMiniCalLoading( false ); } );
	}

	function loadDaySlotsAction( ajaxUrl, nonces, params, browse ) {
		if ( ! params.productId || ! params.date || ! params.showTimeFields ) { browse.setSlotsData( null ); return; }
		browse.setSlotsLoading( true );
		fetchDaySlots( ajaxUrl, nonces, {
			productId: params.productId, date: params.date,
			staffId: params.staffId || '', locationId: params.locationId || '', resourceId: params.resourceId || '', qty: params.qty,
			editingAppointmentId: params.editingAppointmentId || 0
		}, browse.refs.daySlotsXHR, browse.refs.daySlotsCache ).then( function( result ) {
			browse.setSlotsData( result.data || { slots: [], date: params.date } );
			browse.setSlotsLoading( false );
		} ).catch( function( err ) {
			if ( err && err.name === 'AbortError' ) { return; }
			browse.setSlotsData( { slots: [], date: params.date } );
			browse.setSlotsLoading( false );
		} );
	}

	function syncOpenBrowseCal( ajaxUrl, nonces, browse, opts ) {
		if ( ! opts || ! opts.productId ) { return; }
		browse.refs.monthAvailCache.current = {};
		browse.refs.daySlotsCache.current = {};
		if ( ! browse.browseOpen ) { return; }
		var center = opts.formDate || browse.miniCalStripCenter || getTodayYMD();
		var emptyStaffed = !! opts.hasStaff && !( opts.staffId || '' );
		var common = { productId: opts.productId, staffId: opts.staffId || '', locationId: opts.locationId || '', resourceId: opts.resourceId || '', qty: opts.qty };
		if ( opts.showMonthRange || browse.miniCalExpanded ) {
			loadMonthAvail( ajaxUrl, nonces, Object.assign( {
				yearMonth: browse.miniCalMonth || center.substring( 0, 7 ),
				date: opts.showTimeFields ? ( opts.formDate || '' ) : '',
				editingAppointmentId: opts.editingAppointmentId || 0
			}, common ), browse );
		} else {
			loadStripAvail( ajaxUrl, nonces, Object.assign( {
				centerYMD: browse.miniCalStripCenter || center,
				firstDayOfWeek: opts.firstDayOfWeek,
				date: opts.showTimeFields ? ( opts.formDate || center ) : '',
				editingAppointmentId: opts.editingAppointmentId || 0,
				strip: emptyStaffed
			}, common ), browse );
		}
		if ( opts.showTimeFields && opts.formDate ) {
			loadDaySlotsAction( ajaxUrl, nonces, Object.assign( {
				date: opts.formDate, showTimeFields: true,
				editingAppointmentId: opts.editingAppointmentId || 0
			}, common ), browse );
		}
	}

	/** Scroll a section into view inside .wca-panel-body-scroll (call after layout pass). */
	function scrollPanelSectionIntoView( sectionEl ) {
		if ( ! sectionEl ) { return; }
		try {
			var scrollerEl = sectionEl.closest( '.wca-panel-body-scroll' );
			if ( ! scrollerEl ) { return; }
			var contentRect = scrollerEl.getBoundingClientRect();
			var sectionRect = sectionEl.getBoundingClientRect();
			var margin = 16;
			if ( sectionRect.top >= contentRect.top + margin && sectionRect.bottom <= contentRect.bottom - margin ) {
				return;
			}
			scrollerEl.scrollTop = Math.max( scrollerEl.scrollTop + ( sectionRect.top - contentRect.top ) - margin, 0 );
		} catch ( err ) {}
	}

	// ─── Public API ──────────────────────────────────────────────

	return {
		sanitizeSelect2Label: sanitizeSelect2Label,
		customerNameFromSelectLabel: customerNameFromSelectLabel,
		textInput: textInput,
		initEnhancedSelect: initEnhancedSelect,
		setEnhancedSelectValue: setEnhancedSelectValue,
		productSelectOptions: productSelectOptions,
		initPreloadedProductSelect: initPreloadedProductSelect,
		initAjaxSelect: initAjaxSelect,
		focusPanelSelect: focusPanelSelect,
		buildFormData: buildFormData,
		abortableFetch: abortableFetch,
		getCalendarLocale: getCalendarLocale,
		getFirstDayOfWeek: getFirstDayOfWeek,
		getStripDates: getStripDates,
		getMonthsForStrip: getMonthsForStrip,
		getTodayYMD: getTodayYMD,
		getCurrentYM: getCurrentYM,
		fetchMonthAvailability: fetchMonthAvailability,
		fetchDaySlots: fetchDaySlots,
		availabilityParamsReady: availabilityParamsReady,
		fetchAvailability: fetchAvailability,
		fetchCost: fetchCost,
		isDateOnlyTimePlaceholder: isDateOnlyTimePlaceholder,
		loadMonthAvail: loadMonthAvail,
		loadStripAvail: loadStripAvail,
		loadDaySlotsAction: loadDaySlotsAction,
		syncOpenBrowseCal: syncOpenBrowseCal,
		scrollPanelSectionIntoView: scrollPanelSectionIntoView
	};

} )();

if ( typeof window !== 'undefined' ) {
	window.panelHelpers = panelHelpers;
}

// Support both global and module usage
if ( typeof module !== 'undefined' && module.exports ) {
	module.exports = panelHelpers;
}
