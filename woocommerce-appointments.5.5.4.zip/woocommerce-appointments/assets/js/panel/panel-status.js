/**
 * Panel Status — Segmented status control component for the appointment admin panel.
 *
 * Extracted from appointment-admin-panel.js to eliminate duplication
 * between EditContent and CreateContent components.
 *
 * @since 5.3.0
 */

var panelStatus = ( function() {
	'use strict';

	if ( ! window.wp || ! window.wp.element ) { return {}; }

	var h      = wp.element.createElement;
	var wpIcon = window.wcaWpIcons && window.wcaWpIcons.render ? window.wcaWpIcons.render : function() { return null; };

	/**
	 * Render a segmented status control with overflow dropdown.
	 *
	 * @param {Object} opts
	 * @param {string}   opts.value          Current status value.
	 * @param {Function} opts.onChange        Called with new status string on click.
	 * @param {string[]} opts.statuses        All available status slugs.
	 * @param {Object}   opts.statusMap       Map of slug → display label.
	 * @param {Object}   opts.pinnedStatuses  Map of slug → truthy (always visible).
	 * @param {Function} opts.t               Translation helper function.
	 * @param {Function} opts.humanizeStatus  Fallback label formatter.
	 * @return {Object}  React element.
	 */
	function StatusSegmented( opts ) {
		var s = String( opts.value || '' ).toLowerCase();
		var statuses = opts.statuses || [];
		var statusMap = opts.statusMap || {};
		var pinnedStatuses = opts.pinnedStatuses || {};
		var onChange = opts.onChange || function() {};
		var t = opts.t || function( k, fb ) { return fb || k; };
		var humanize = opts.humanizeStatus || function( st ) { return st; };

		var visibleItems = [];
		var overflowItems = [];

		statuses.forEach( function( st ) {
			var label = statusMap[ st ] || humanize( st );
			var isCurrent = st === s;
			var isPinned = !! pinnedStatuses[ st ];
			var btn = h( 'button', {
				key: 'st-' + st,
				type: 'button',
				className: 'wca-status-seg wca-status-seg--' + st + ( isCurrent ? ' is-active' : '' ),
				title: isCurrent ? ( label + ' \u2014 ' + t( 'current', 'Current' ) ) : ( t( 'changeStatusTo', 'Change status to' ) + ' ' + label ),
				onClick: function() { onChange( st ); }
			}, label );
			if ( isCurrent || isPinned ) {
				visibleItems.push( btn );
			} else {
				overflowItems.push( { status: st, label: label } );
			}
		} );

		var moreDropdown = null;
		if ( overflowItems.length ) {
			moreDropdown = h( 'div', { className: 'wca-status-more-wrap', key: 'more-wrap' },
				h( 'button', {
					type: 'button',
					className: 'wca-status-more-btn',
					title: t( 'moreStatuses', 'More statuses' ),
					onClick: function( e ) {
						e.stopPropagation();
						var wrap = e.currentTarget.parentNode;
						var isOpen = wrap.classList.contains( 'is-open' );
						try {
							var allWraps = document.querySelectorAll( '.wca-status-more-wrap.is-open' );
							for ( var wi = 0; wi < allWraps.length; wi++ ) { allWraps[ wi ].classList.remove( 'is-open' ); }
						} catch ( _ ) {}
						if ( ! isOpen ) {
							try {
								var btnRect = e.currentTarget.getBoundingClientRect();
								var panel = e.currentTarget.closest( '.wca-panel' );
								var panelRect = panel ? panel.getBoundingClientRect() : null;
								wrap.classList.remove( 'align-left', 'align-right' );
								if ( panelRect ) {
									var spaceOnRight = panelRect.right - btnRect.right;
									var spaceOnLeft = btnRect.left - panelRect.left;
									if ( spaceOnLeft > spaceOnRight ) {
										wrap.classList.add( 'align-left' );
									} else {
										wrap.classList.add( 'align-right' );
									}
								} else {
									if ( btnRect.right > window.innerWidth / 2 ) {
										wrap.classList.add( 'align-right' );
									} else {
										wrap.classList.add( 'align-left' );
									}
								}
							} catch ( _ ) {}
							wrap.classList.add( 'is-open' );
							var closeHandler = function( ev ) {
								if ( ! wrap.contains( ev.target ) ) {
									wrap.classList.remove( 'is-open' );
									document.removeEventListener( 'click', closeHandler, true );
								}
							};
							setTimeout( function() { document.addEventListener( 'click', closeHandler, true ); }, 0 );
						}
					}
				}, wpIcon( h, 'moreVertical', null ) ),
				h( 'div', { className: 'wca-status-more-dropdown', role: 'menu' },
					overflowItems.map( function( item ) {
						return h( 'button', {
							key: 'st-dd-' + item.status,
							type: 'button',
							className: 'wca-status-more-item wca-status-more-item--' + item.status,
							role: 'menuitem',
							onClick: function() {
								try { var w = document.querySelector( '.wca-status-more-wrap.is-open' ); if ( w ) { w.classList.remove( 'is-open' ); } } catch ( _ ) {}
								onChange( item.status );
							}
						}, item.label );
					} )
				)
			);
		}

		// No leading status icon here: view mode keeps the glyph as its row label;
		// edit/create chips are self-explanatory (aria-label on the group).
		return h( 'div', { className: 'wca-status-section' },
			h( 'div', { className: 'wca-status-segmented', role: 'group', 'aria-label': t( 'appointmentStatus', 'Appointment status' ) },
				visibleItems,
				moreDropdown
			)
		);
	}

	return {
		StatusSegmented: StatusSegmented
	};

} )();

// Ensure global availability even when scripts are concatenated into a wrapper scope.
if ( typeof window !== 'undefined' ) {
	window.panelStatus = panelStatus;
}

if ( typeof module !== 'undefined' && module.exports ) {
	module.exports = panelStatus;
}
