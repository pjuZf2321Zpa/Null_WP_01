/**
 * Panel Form — Shared form state hook for Edit and Create panels.
 *
 * Consolidates duplicated useState/useRef calls into reusable hooks.
 * Consumed by EditContent and CreateContent in appointment-admin-panel.js.
 *
 * @since 5.3.0
 */
( function() {
	'use strict';

	if ( ! window.wp || ! window.wp.element ) {
		return;
	}

	var useState   = wp.element.useState;
	var useRef     = wp.element.useRef;
	var useEffect  = wp.element.useEffect;

	// Strip vs full-month mini-calendar preference: shared across Edit/Create (two useBrowseState instances).
	// Initialized lazily via useBrowseState to ensure window.wcaPanel is available.
	var gBrowseMiniCalExpanded = null;

	// ─── Default form field values ────────────────────────────────
	var DEFAULT_FORM = {
		date: '',
		timeFrom: '',
		timeTo: '',
		dateFrom: '',
		dateTo: '',
		monthFrom: '',
		monthTo: '',
		staffIds: [],
		locationId: '',
		resourceId: '',
		status: '',
		customerId: '',
		customerSearch: '',
		customerStatus: 'expected',
		qty: 1,
		productId: ''
	};

	// ─── Merge helper ─────────────────────────────────────────────
	function mergeDefaults( initialData ) {
		var out = {};
		for ( var k in DEFAULT_FORM ) { out[ k ] = DEFAULT_FORM[ k ]; }
		if ( initialData ) {
			for ( var ik in initialData ) {
				if ( ik in DEFAULT_FORM ) { out[ ik ] = initialData[ ik ]; }
			}
		}
		return out;
	}

	// ─── useAppointmentForm hook ──────────────────────────────────
	// Manages core form fields shared between Edit and Create panels.
	// Returns form state, field setters, dirty tracking, and reset.
	//
	// Options:
	//   dirtyFields — Array of field names to track for isDirty.
	//                 Defaults to all fields in DEFAULT_FORM.
	function useAppointmentForm( initialData, opts ) {
		var init = mergeDefaults( initialData );

		var [ form, _setForm ] = useState( init );
		var initRef = useRef( init );

		// Set a single field.
		function setField( key, value ) {
			_setForm( function( prev ) {
				var next = {};
				for ( var pk in prev ) { next[ pk ] = prev[ pk ]; }
				next[ key ] = value;
				return next;
			} );
		}

		// Set multiple fields at once (batch update, single re-render).
		function setFields( updates ) {
			_setForm( function( prev ) {
				var next = {};
				for ( var pk in prev ) { next[ pk ] = prev[ pk ]; }
				for ( var uk in updates ) { next[ uk ] = updates[ uk ]; }
				return next;
			} );
		}

		// Reset form to new initial data (e.g. "Create Another").
		function resetForm( newInit ) {
			var reset = mergeDefaults( newInit );
			initRef.current = reset;
			_setForm( reset );
		}

		// Dirty tracking: compare current form to initial values.
		var dirtyKeys = ( opts && opts.dirtyFields ) ? opts.dirtyFields : null;
		var isDirty = false;
		var ref = initRef.current;
		if ( dirtyKeys ) {
			for ( var i = 0; i < dirtyKeys.length; i++ ) {
				var dk = dirtyKeys[ i ];
				if ( dk === 'staffIds' ) {
					if ( JSON.stringify( form.staffIds ) !== JSON.stringify( ref.staffIds ) ) { isDirty = true; break; }
				} else if ( form[ dk ] !== ref[ dk ] ) { isDirty = true; break; }
			}
		} else {
			for ( var fk in ref ) {
				if ( fk === 'staffIds' ) {
					if ( JSON.stringify( form.staffIds ) !== JSON.stringify( ref.staffIds ) ) { isDirty = true; break; }
				} else if ( form[ fk ] !== ref[ fk ] ) { isDirty = true; break; }
			}
		}

		return {
			form: form,
			setField: setField,
			setFields: setFields,
			resetForm: resetForm,
			isDirty: isDirty,
			initData: initRef.current
		};
	}

	// ─── useBrowseState hook ──────────────────────────────────────
	// Manages browse panel state (mini calendar, slots, availability)
	// shared between Edit and Create panels.
	function useBrowseState() {
		var [ browseOpen, setBrowseOpen ]             = useState( false );
		var [ miniCalMonth, setMiniCalMonth ]         = useState( '' );
		var [ miniCalData, setMiniCalData ]           = useState( null );
		var [ miniCalLoading, setMiniCalLoading ]     = useState( false );
		// Lazy initialize the global state from configured window.wcaPanel once.
		if ( gBrowseMiniCalExpanded === null ) {
			gBrowseMiniCalExpanded = !! ( window.wcaPanel && window.wcaPanel.browseMiniCalExpanded );
		}

		var [ miniCalExpanded, _setMiniCalExpanded ] = useState( gBrowseMiniCalExpanded );
		var [ miniCalStripCenter, setMiniCalStripCenter ] = useState( '' );
		var [ slotsData, setSlotsData ]               = useState( null );
		var [ slotsLoading, setSlotsLoading ]         = useState( false );
		var [ availStatus, setAvailStatus ]           = useState( '' );
		var [ availMessage, setAvailMessage ]         = useState( '' );
		var [ browseEpoch, setBrowseEpoch ]           = useState( 0 );

		// Shared refs for caches and XHR controllers.
		var monthAvailCacheRef = useRef( {} );
		var daySlotsCacheRef   = useRef( {} );
		var daySlotsXHRRef     = useRef( null );
		var availXHRRef        = useRef( null );
		var availTimerRef      = useRef( null );
		var availCheckGenRef   = useRef( 0 );

		// Persist 7-day strip vs full-month preference (user meta via AJAX; same nonce as calendar toolbar view).
		function persistBrowseMiniCalExpanded( expanded ) {
			var expandedBool = !! expanded;
			if ( window.wcaPanel ) {
				window.wcaPanel.browseMiniCalExpanded = expandedBool;
			}
			var ajaxUrl = window.wcaPanel && window.wcaPanel.ajaxUrl;
			var nonce = window.wcaPanel && window.wcaPanel.ajaxNonces && window.wcaPanel.ajaxNonces.calendarView;
			if ( ajaxUrl && nonce ) {
				var formData = new FormData();
				formData.append( 'action', 'wc_appointments_save_browse_mini_cal' );
				formData.append( 'security', nonce );
				formData.append( 'expanded', expandedBool ? '1' : '0' );
				fetch( ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' } ).catch( function() {} );
			}
		}

		function setMiniCalExpanded( v ) {
			gBrowseMiniCalExpanded = !! v;
			_setMiniCalExpanded( gBrowseMiniCalExpanded );
			persistBrowseMiniCalExpanded( gBrowseMiniCalExpanded );
		}

		// Keep Edit/Create browse panels aligned when opening browse after toggling in the other panel.
		useEffect( function() {
			if ( browseOpen ) {
				_setMiniCalExpanded( gBrowseMiniCalExpanded );
			}
		}, [ browseOpen ] );

		// Reset all browse state (e.g. on "Create Another").
		function resetBrowse() {
			setBrowseOpen( false );
			setMiniCalMonth( '' );
			setMiniCalData( null );
			setMiniCalLoading( false );
			_setMiniCalExpanded( gBrowseMiniCalExpanded );
			setMiniCalStripCenter( '' );
			setSlotsData( null );
			setSlotsLoading( false );
			setAvailStatus( '' );
			setAvailMessage( '' );
			monthAvailCacheRef.current = {};
			daySlotsCacheRef.current = {};
		}

		function invalidateBrowse() {
			monthAvailCacheRef.current = {};
			daySlotsCacheRef.current = {};
			if ( daySlotsXHRRef.current && daySlotsXHRRef.current.abort ) {
				try { daySlotsXHRRef.current.abort(); } catch ( e2 ) {}
			}
			setMiniCalLoading( false );
			setSlotsLoading( false );
			setMiniCalData( null );
			setSlotsData( null );
			setBrowseEpoch( function( n ) { return n + 1; } );
		}

		useEffect( function() {
			window.addEventListener( 'wca_browse_invalidate', invalidateBrowse );
			return function() {
				window.removeEventListener( 'wca_browse_invalidate', invalidateBrowse );
			};
		}, [] );

		return {
			browseOpen: browseOpen,
			setBrowseOpen: setBrowseOpen,
			miniCalMonth: miniCalMonth,
			setMiniCalMonth: setMiniCalMonth,
			miniCalData: miniCalData,
			setMiniCalData: setMiniCalData,
			miniCalLoading: miniCalLoading,
			setMiniCalLoading: setMiniCalLoading,
			miniCalExpanded: miniCalExpanded,
			setMiniCalExpanded: setMiniCalExpanded,
			miniCalStripCenter: miniCalStripCenter,
			setMiniCalStripCenter: setMiniCalStripCenter,
			slotsData: slotsData,
			setSlotsData: setSlotsData,
			slotsLoading: slotsLoading,
			setSlotsLoading: setSlotsLoading,
			availStatus: availStatus,
			setAvailStatus: setAvailStatus,
			availMessage: availMessage,
			setAvailMessage: setAvailMessage,
			resetBrowse: resetBrowse,
			invalidateBrowse: invalidateBrowse,
			browseEpoch: browseEpoch,
			refs: {
				monthAvailCache: monthAvailCacheRef,
				daySlotsCache: daySlotsCacheRef,
				daySlotsXHR: daySlotsXHRRef,
				availXHR: availXHRRef,
				availTimer: availTimerRef,
				availCheckGen: availCheckGenRef
			}
		};
	}

	/**
	 * Optional integration currency selector (config from `wcaPanel.integrationCurrency`).
	 *
	 * @param {Object}   opts
	 * @param {Object}   opts.cfg               Panel integrationCurrency config.
	 * @param {string}   opts.fallbackCurrency  Shop currency when integration is off.
	 * @param {string}   opts.ajaxUrl
	 * @param {string}   opts.productId
	 * @param {Function} opts.onApplied         After set-currency AJAX succeeds.
	 * @param {Function} opts.t
	 * @param {Function} opts.wpIcon          ( h, name, className, props ) => node
	 * @param {Function} opts.h               createElement
	 * @return {Object}
	 */
	function useIntegrationCurrency( opts ) {
		var icCfg = opts.cfg && opts.cfg.enabled ? opts.cfg : null;
		var fallback = opts.fallbackCurrency || '';
		var initial = icCfg && icCfg.current ? icCfg.current : fallback;
		var panelHelpers = window.panelHelpers || {};

		var [ displayCurrency, setDisplayCurrency ] = useState( initial );
		var lastRef = useRef( initial );
		var selectRef = useRef( null );

		function apply( code ) {
			lastRef.current = code;
			setDisplayCurrency( code );
			if ( panelHelpers.setEnhancedSelectValue ) {
				panelHelpers.setEnhancedSelectValue( selectRef, code );
			}
		}

		function handleChange( code ) {
			if ( ! icCfg || ! code || ! opts.ajaxUrl || code === lastRef.current ) {
				return;
			}
			var prev = lastRef.current;
			apply( code );
			var fd = new FormData();
			fd.append( 'action', icCfg.ajaxAction || '' );
			fd.append( icCfg.currencyParam || 'currency', code );
			var extra = icCfg.extraPostFields || {};
			for ( var ek in extra ) {
				if ( Object.prototype.hasOwnProperty.call( extra, ek ) ) {
					fd.append( ek, extra[ ek ] );
				}
			}
			fetch( opts.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' } )
				.then( function( r ) {
					if ( ! r.ok ) {
						throw new Error( 'currency' );
					}
					return r.json();
				} )
				.then( function( resp ) {
					if ( resp && resp.error ) {
						window.alert( resp.error );
						apply( prev );
						return;
					}
					if ( resp && resp.success === false ) {
						var msg = ( resp.data && resp.data.message ) ? resp.data.message : ( resp.data || '' );
						if ( msg ) {
							window.alert( msg );
						}
						apply( prev );
						return;
					}
					if ( typeof opts.onApplied === 'function' ) {
						opts.onApplied();
					}
				} )
				.catch( function() {
					apply( prev );
				} );
		}

		useEffect( function() {
		if ( ! icCfg || ! opts.productId ) {
			return;
		}
			var cleanupFn = null;
			var tmr = setTimeout( function() {
				cleanupFn = panelHelpers.initEnhancedSelect( selectRef, handleChange );
				if ( panelHelpers.setEnhancedSelectValue ) {
					panelHelpers.setEnhancedSelectValue( selectRef, lastRef.current );
				}
			}, 0 );
			return function() {
				clearTimeout( tmr );
				if ( typeof cleanupFn === 'function' ) {
					try {
						cleanupFn();
					} catch ( e ) {}
				}
			};
		}, [ opts.productId ] );

		function renderSection() {
			if ( ! icCfg || ! opts.productId || ! opts.h || ! opts.wpIcon ) {
				return null;
			}
			var h = opts.h;
			var wpIcon = opts.wpIcon;
			var tr = opts.t || function( _k, d ) { return d; };
			var label = icCfg.label || tr( 'appointmentCurrency', 'Appointment currency' );
			return h( 'div', { className: 'wca-form-section wca-form-order-section' },
				h( 'div', { className: 'wca-form-row' },
					window.panelHelpers && window.panelHelpers.textInput
						? window.panelHelpers.textInput( h, {
							id: 'wca-create-currency',
							label: label,
							// Enhanced select owns the DOM; keep uncontrolled (defaultValue only).
							forceActive: !! displayCurrency,
							mod: 'grow',
							tag: 'select',
							ref: selectRef,
							defaultValue: displayCurrency,
							children: ( icCfg.options || [] ).map( function( opt ) {
								return h( 'option', { key: opt.code, value: opt.code }, opt.label || opt.code );
							} )
						} )
						: h( 'select', {
							id: 'wca-create-currency',
							ref: selectRef,
							className: 'wca-field__control',
							defaultValue: displayCurrency
						},
							( icCfg.options || [] ).map( function( opt ) {
								return h( 'option', { key: opt.code, value: opt.code }, opt.label || opt.code );
							} )
						)
				)
			);
		}

		return {
			enabled: !! icCfg,
			displayCurrency: displayCurrency,
			footerUseServerHtml: !! icCfg,
			addonsCacheSuffix: icCfg ? displayCurrency : '',
			renderSection: renderSection
		};
	}

	// ─── Expose on window ─────────────────────────────────────────
	window.panelForm = {
		useAppointmentForm: useAppointmentForm,
		useBrowseState: useBrowseState,
		useIntegrationCurrency: useIntegrationCurrency
	};

} )();
