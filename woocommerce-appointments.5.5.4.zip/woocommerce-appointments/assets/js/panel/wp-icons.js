/**
 * SVG paths rendered via wp.element — no Dashicons font.
 * Most paths match @wordpress/icons v10.x (24×24, fill currentColor).
 * Customer / order / billing / status keys mirror WooCommerce Blocks (`plugins/woocommerce/client/blocks/assets/js/icons/library/`).
 *
 * @since 5.3.0
 */
( function() {
	'use strict';

	/**
	 * Icon definitions: each value is
	 * { paths: [ { d, fillRule?, clipRule? } ], viewBox?, opticalScale? }.
	 * `opticalScale` normalizes perceived footprint (glyph coverage), not CSS size.
	 *
	 * @type {Object<string, {paths: Array<Object>, viewBox?: string, opticalScale?: number}>}
	 */
	var ICONS = {
		pencil: {
			opticalScale: 1.08,
			paths: [ { d: 'm19 7-3-3-8.5 8.5-1 4 4-1L19 7Zm-7 11.5H5V20h7v-1.5Z' } ]
		},
		seen: {
			opticalScale: 1.06,
			paths: [ { d: 'M3.99961 13C4.67043 13.3354 4.6703 13.3357 4.67017 13.3359L4.67298 13.3305C4.67621 13.3242 4.68184 13.3135 4.68988 13.2985C4.70595 13.2686 4.7316 13.2218 4.76695 13.1608C4.8377 13.0385 4.94692 12.8592 5.09541 12.6419C5.39312 12.2062 5.84436 11.624 6.45435 11.0431C7.67308 9.88241 9.49719 8.75 11.9996 8.75C14.502 8.75 16.3261 9.88241 17.5449 11.0431C18.1549 11.624 18.6061 12.2062 18.9038 12.6419C19.0523 12.8592 19.1615 13.0385 19.2323 13.1608C19.2676 13.2218 19.2933 13.2686 19.3093 13.2985C19.3174 13.3135 19.323 13.3242 19.3262 13.3305L19.3291 13.3359C19.3289 13.3357 19.3288 13.3354 19.9996 13C20.6704 12.6646 20.6703 12.6643 20.6701 12.664L20.6697 12.6632L20.6688 12.6614L20.6662 12.6563L20.6583 12.6408C20.6517 12.6282 20.6427 12.6108 20.631 12.5892C20.6078 12.5459 20.5744 12.4852 20.5306 12.4096C20.4432 12.2584 20.3141 12.0471 20.1423 11.7956C19.7994 11.2938 19.2819 10.626 18.5794 9.9569C17.1731 8.61759 14.9972 7.25 11.9996 7.25C9.00203 7.25 6.82614 8.61759 5.41987 9.9569C4.71736 10.626 4.19984 11.2938 3.85694 11.7956C3.68511 12.0471 3.55605 12.2584 3.4686 12.4096C3.42484 12.4852 3.39142 12.5459 3.36818 12.5892C3.35656 12.6108 3.34748 12.6282 3.34092 12.6408L3.33297 12.6563L3.33041 12.6614L3.32948 12.6632L3.32911 12.664C3.32894 12.6643 3.32879 12.6646 3.99961 13ZM11.9996 16C13.9326 16 15.4996 14.433 15.4996 12.5C15.4996 10.567 13.9326 9 11.9996 9C10.0666 9 8.49961 10.567 8.49961 12.5C8.49961 14.433 10.0666 16 11.9996 16Z' } ]
		},
		closeSmall: {
			opticalScale: 1.12,
			paths: [ { d: 'M12 13.06l3.712 3.713 1.061-1.06L13.061 12l3.712-3.712-1.06-1.06L12 10.938 8.288 7.227l-1.061 1.06L10.939 12l-3.712 3.712 1.06 1.061L12 13.061z' } ]
		},
		moreVertical: {
			opticalScale: 1.14,
			paths: [ { d: 'M13 19h-2v-2h2v2zm0-6h-2v-2h2v2zm0-6h-2V5h2v2z' } ]
		},
		trash: {
			opticalScale: 1.06,
			paths: [ {
				d: 'M12 5.5A2.25 2.25 0 0 0 9.878 7h4.244A2.251 2.251 0 0 0 12 5.5ZM12 4a3.751 3.751 0 0 0-3.675 3H5v1.5h1.27l.818 8.997a2.75 2.75 0 0 0 2.739 2.501h4.347a2.75 2.75 0 0 0 2.738-2.5L17.73 8.5H19V7h-3.325A3.751 3.751 0 0 0 12 4Zm4.224 4.5H7.776l.806 8.861a1.25 1.25 0 0 0 1.245 1.137h4.347a1.25 1.25 0 0 0 1.245-1.137l.805-8.861Z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		atSymbol: {
			opticalScale: 1.06,
			paths: [ { d: 'M12.5939 21C14.1472 21 16.1269 20.5701 17.0711 20.1975L16.6447 18.879C16.0964 19.051 14.3299 19.6242 12.6548 19.6242C7.4467 19.6242 4.67513 16.8726 4.67513 12C4.67513 7.21338 7.50762 4.34713 12.2893 4.34713C17.132 4.34713 19.4162 7.55732 19.4162 10.7675C19.4162 14.035 19.0508 15.4968 17.4975 15.4968C16.5838 15.4968 16.0964 14.7803 16.0964 13.9777V7.5H14.4822V8.30255H14.3909C14.1777 7.67198 12.9898 7.12739 11.467 7.2707C9.18274 7.5 7.4467 9.27707 7.4467 11.8567C7.4467 14.5796 8.81726 16.672 11.467 16.758C13.203 16.8153 14.1168 16.0127 14.4822 15.1815H14.5736C14.7563 16.414 16.401 16.8439 17.467 16.8439C20.6954 16.8439 21 13.5764 21 10.7962C21 6.86943 18.0761 3 12.3807 3C6.50254 3 3 6.3535 3 11.9427C3 17.7325 6.38071 21 12.5939 21ZM11.7107 15.2962C9.73096 15.2962 9.03046 13.6051 9.03046 11.7707C9.03046 10.1083 10.0355 8.67516 11.7716 8.67516C13.599 8.67516 14.5736 9.36306 14.5736 11.7707C14.5736 14.1497 13.7513 15.2962 11.7107 15.2962Z' } ]
		},
		store: {
			opticalScale: 1.06,
			paths: [ {
				d: 'M19.75 11H21V8.667L19.875 4H4.125L3 8.667V11h1.25v8.75h15.5V11zm-1.5 0H5.75v7.25H10V13h4v5.25h4.25V11zm-5.5-5.5h2.067l.486 3.24.028.76H12.75v-4zm-3.567 0h2.067v4H8.669l.028-.76.486-3.24zm7.615 3.1l-.464-3.1h2.36l.806 3.345V9.5h-2.668l-.034-.9zM7.666 5.5h-2.36L4.5 8.845V9.5h2.668l.034-.9.464-3.1z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		// Same SVG as WooCommerce core Product Collection block (`product-collection/icon.tsx`).
		box: {
			opticalScale: 1.06,
			paths: [
				{
					d: 'M19 11H5C4.72386 11 4.5 11.2239 4.5 11.5V17.5C4.5 17.7761 4.72386 18 5 18H19C19.2761 18 19.5 17.7761 19.5 17.5V11.5C19.5 11.2239 19.2761 11 19 11ZM5 9.5H19C20.1046 9.5 21 10.3954 21 11.5V17.5C21 18.6046 20.1046 19.5 19 19.5H5C3.89543 19.5 3 18.6046 3 17.5V11.5C3 10.3954 3.89543 9.5 5 9.5Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				},
				{
					d: 'M18 7.5C18 7.77614 17.7761 8 17.5 8L6.5 8C6.22386 8 6 7.77614 6 7.5V7.5C6 7.22386 6.22386 7 6.5 7L17.5 7C17.7761 7 18 7.22386 18 7.5V7.5Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				},
				{
					d: 'M16 5C16 5.27614 15.7761 5.5 15.5 5.5L8.5 5.5C8.22386 5.5 8 5.27614 8 5V5C8 4.72386 8.22386 4.5 8.5 4.5L15.5 4.5C15.7761 4.5 16 4.72386 16 5V5Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				}
			]
		},
		people: {
			opticalScale: 1.08,
			paths: [ { d: 'M15.5 9.5a1 1 0 100-2 1 1 0 000 2zm0 1.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5zm-2.25 6v-2a2.75 2.75 0 00-2.75-2.75h-4A2.75 2.75 0 003.75 15v2h1.5v-2c0-.69.56-1.25 1.25-1.25h4c.69 0 1.25.56 1.25 1.25v2h1.5zm7-2v2h-1.5v-2c0-.69-.56-1.25-1.25-1.25H15v-1.5h2.5A2.75 2.75 0 0120.25 15zM9.5 8.5a1 1 0 11-2 0 1 1 0 012 0zm1.5 0a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z', fillRule: 'evenodd' } ]
		},
		staffMember: {
			opticalScale: 1.08,
			paths: [ {
				d: 'M7.25 16.437a6.5 6.5 0 1 1 9.5 0V16A2.75 2.75 0 0 0 14 13.25h-4A2.75 2.75 0 0 0 7.25 16v.437Zm1.5 1.193a6.47 6.47 0 0 0 3.25.87 6.47 6.47 0 0 0 3.25-.87V16c0-.69-.56-1.25-1.25-1.25h-4c-.69 0-1.25.56-1.25 1.25v1.63ZM4 12a8 8 0 1 1 16 0 8 8 0 0 1-16 0Zm10-2a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		staffProvider: {
			opticalScale: 1.06,
			paths: [
				{
					d: 'M4.5 6A1.5 1.5 0 0 1 6 4.5h12A1.5 1.5 0 0 1 19.5 6v12a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 18V6ZM6 6v12h12V6H6Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				},
				{
					d: 'M9.5 8.25a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Zm0 1.5a.75.75 0 1 1 0 1.5.75.75 0 0 1 0-1.5Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				},
				{ d: 'M13 9.25h5.25v1.4H13V9.25zm0 3h5.25v1.4H13v-1.4zm0 3h3.75v1.4H13v-1.4z' }
			]
		},
		// CPT / list appointment glyph (same as dashicons-clock / product-type.appointment).
		appointment: {
			opticalScale: 1.08,
			paths: [ {
				d: 'M12 18.5a6.5 6.5 0 1 1 0-13 6.5 6.5 0 0 1 0 13ZM4 12a8 8 0 1 1 16 0 8 8 0 0 1-16 0Zm9 1V8h-1.5v3.5h-2V13H13Z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		// ↻ recurring package — clockwise circular arrow (Material "refresh").
		recurring: {
			opticalScale: 1.04,
			paths: [ {
				d: 'M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z'
			} ]
		},
		calendar: {
			opticalScale: 1.06,
			paths: [ { d: 'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm.5 16c0 .3-.2.5-.5.5H5c-.3 0-.5-.2-.5-.5V7h15v12zM9 10H7v2h2v-2zm0 4H7v2h2v-2zm4-4h-2v2h2v-2zm4 0h-2v2h2v-2zm-4 4h-2v2h2v-2zm4 0h-2v2h2v-2z' } ]
		},
		calendarTime: {
			opticalScale: 1.06,
			paths: [
				{ d: 'M19 4h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h7l-.2-2H5V9h14v2.08c.34.05.67.12 1 .22V6c0-1.1-.9-2-2-2zM19 7.5H5v-2h14v2z' },
				{ d: 'M18 14c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm1.5 5.5l-2.1-1.2V16h1v1.5l1.6.8-.5.7z' }
			]
		},
		postDate: {
			opticalScale: 1.06,
			paths: [
				{ d: 'M11.696 13.972c.356-.546.599-.958.728-1.235a1.79 1.79 0 00.203-.783c0-.264-.077-.47-.23-.618-.148-.153-.354-.23-.618-.23-.295 0-.569.07-.82.212a3.413 3.413 0 00-.738.571l-.147-1.188c.289-.234.59-.41.903-.526.313-.117.66-.175 1.041-.175.375 0 .695.08.959.24.264.153.46.362.59.626.135.265.203.556.203.876 0 .362-.08.734-.24 1.115-.154.381-.427.87-.82 1.466l-.756 1.152H14v1.106h-4l1.696-2.609z' },
				{ d: 'M19.5 7h-15v12a.5.5 0 00.5.5h14a.5.5 0 00.5-.5V7zM3 7V5a2 2 0 012-2h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V7z' }
			]
		},
		globe: {
			opticalScale: 1.08,
			paths: [ { d: 'M12 4c-4.4 0-8 3.6-8 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8Zm6.5 8c0 .6 0 1.2-.2 1.8h-2.7c0-.6.2-1.1.2-1.8s0-1.2-.2-1.8h2.7c.2.6.2 1.1.2 1.8Zm-.9-3.2h-2.4c-.3-.9-.7-1.8-1.1-2.4-.1-.2-.2-.4-.3-.5 1.6.5 3 1.6 3.8 3ZM12.8 17c-.3.5-.6 1-.8 1.3-.2-.3-.5-.8-.8-1.3-.3-.5-.6-1.1-.8-1.7h3.3c-.2.6-.5 1.2-.8 1.7Zm-2.9-3.2c-.1-.6-.2-1.1-.2-1.8s0-1.2.2-1.8H14c.1.6.2 1.1.2 1.8s0 1.2-.2 1.8H9.9ZM11.2 7c.3-.5.6-1 .8-1.3.2.3.5.8.8 1.3.3.5.6 1.1.8 1.7h-3.3c.2-.6.5-1.2.8-1.7Zm-1-1.2c-.1.2-.2.3-.3.5-.4.7-.8 1.5-1.1 2.4H6.4c.8-1.4 2.2-2.5 3.8-3Zm-1.8 8H5.7c-.2-.6-.2-1.1-.2-1.8s0-1.2.2-1.8h2.7c0 .6-.2 1.1-.2 1.8s0 1.2.2 1.8Zm-2 1.4h2.4c.3.9.7 1.8 1.1 2.4.1.2.2.4.3.5-1.6-.5-3-1.6-3.8-3Zm7.4 3c.1-.2.2-.3.3-.5.4-.7.8-1.5 1.1-2.4h2.4c-.8 1.4-2.2 2.5-3.8 3Z' } ]
		},
		// Outline map pin (stroke, matches other panel key icons).
		location: {
			opticalScale: 1.08,
			paths: [
				{
					d: 'M12 21s-6-5.686-6-10.5a6 6 0 1 1 12 0C18 15.314 12 21 12 21Z',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.6',
					strokeLinejoin: 'round'
				},
				{
					d: 'M12 13.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.6'
				}
			]
		},
		// Door / room (resources) - matches product Resources tab icon.
		door: {
			opticalScale: 1.06,
			paths: [
				{
					d: 'M5 2h14v20H5V2zm2 2v16h10V4H7z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				},
				{
					d: 'M15 11h2v2h-2z'
				}
			]
		},
		// Video camera for Join Meeting rows.
		video: {
			opticalScale: 1.06,
			paths: [ {
				d: 'M3.75 7.5A1.75 1.75 0 0 1 5.5 5.75h7A1.75 1.75 0 0 1 14.25 7.5v9a1.75 1.75 0 0 1-1.75 1.75h-7A1.75 1.75 0 0 1 3.75 16.5v-9Zm12.03 1.22 3.47-2.02a.75.75 0 0 1 1.13.65v9.3a.75.75 0 0 1-1.13.65l-3.47-2.02V8.72Z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		plus: {
			opticalScale: 1.12,
			paths: [ { d: 'M11 12.5V17.5H12.5V12.5H17.5V11H12.5V6H11V11H6V12.5H11Z' } ]
		},
		payment: {
			opticalScale: 1.06,
			paths: [ {
				d: 'M5.5 9.5v-2h13v2h-13zm0 3v4h13v-4h-13zM4 7a1 1 0 011-1h14a1 1 0 011 1v10a1 1 0 01-1 1H5a1 1 0 01-1-1V7z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		mobile: {
			opticalScale: 1.08,
			paths: [ { d: 'M15 4H9c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h6c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm.5 14c0 .3-.2.5-.5.5H9c-.3 0-.5-.2-.5-.5V6c0-.3.2-.5.5-.5h6c.3 0 .5.2.5.5v12zm-4.5-.5h2V16h-2v1.5z' } ]
		},
		listView: {
			opticalScale: 1.1,
			paths: [ { d: 'M3 6h11v1.5H3V6Zm3.5 5.5h11V13h-11v-1.5ZM21 17H10v1.5h11V17Z' } ]
		},
		search: {
			opticalScale: 1.08,
			paths: [ { d: 'M13 5c-3.3 0-6 2.7-6 6 0 1.4.5 2.7 1.3 3.7l-3.8 3.8 1.1 1.1 3.8-3.8c1 .8 2.3 1.3 3.7 1.3 3.3 0 6-2.7 6-6S16.3 5 13 5zm0 10.5c-2.5 0-4.5-2-4.5-4.5s2-4.5 4.5-4.5 4.5 2 4.5 4.5-2 4.5-4.5 4.5z' } ]
		},
		chevronUp: {
			opticalScale: 1.18,
			paths: [ { d: 'M6.5 12.4L12 8l5.5 4.4-.9 1.2L12 10l-4.5 3.6-1-1.2z' } ]
		},
		chevronDown: {
			opticalScale: 1.18,
			paths: [ { d: 'M17.5 11.6L12 16l-5.5-4.4.9-1.2L12 14l4.5-3.6 1 1.2z' } ]
		},
		check: {
			opticalScale: 1.14,
			paths: [ { d: 'M16.7 7.1l-6.3 8.5-3.3-2.5-.9 1.2 4.5 3.4L17.9 8z' } ]
		},
		info: {
			opticalScale: 1.08,
			paths: [ {
				d: 'M5.5 12a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0ZM12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm.75 4v1.5h-1.5V8h1.5Zm0 8v-5h-1.5v5h1.5Z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		// ── WooCommerce Blocks icon library (`plugins/woocommerce/client/blocks/assets/js/icons/library/`) ──
		customerAccount: {
			opticalScale: 1.08,
			paths: [ {
				d: 'M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM7.07 18.28C7.5 17.38 10.12 16.5 12 16.5C13.88 16.5 16.51 17.38 16.93 18.28C15.57 19.36 13.86 20 12 20C10.14 20 8.43 19.36 7.07 18.28ZM12 14.5C13.46 14.5 16.93 15.09 18.36 16.83C19.38 15.49 20 13.82 20 12C20 7.59 16.41 4 12 4C7.59 4 4 7.59 4 12C4 13.82 4.62 15.49 5.64 16.83C7.07 15.09 10.54 14.5 12 14.5ZM12 6C10.06 6 8.5 7.56 8.5 9.5C8.5 11.44 10.06 13 12 13C13.94 13 15.5 11.44 15.5 9.5C15.5 7.56 13.94 6 12 6ZM10.5 9.5C10.5 10.33 11.17 11 12 11C12.83 11 13.5 10.33 13.5 9.5C13.5 8.67 12.83 8 12 8C11.17 8 10.5 8.67 10.5 9.5Z',
				fillRule: 'evenodd',
				clipRule: 'evenodd'
			} ]
		},
		bag: {
			viewBox: '0 0 32 32',
			opticalScale: 1.03,
			paths: [
				{
					d: 'M12.4444 14.2222C12.9354 14.2222 13.3333 14.6202 13.3333 15.1111C13.3333 15.8183 13.6143 16.4966 14.1144 16.9967C14.6145 17.4968 15.2927 17.7778 16 17.7778C16.7072 17.7778 17.3855 17.4968 17.8856 16.9967C18.3857 16.4966 18.6667 15.8183 18.6667 15.1111C18.6667 14.6202 19.0646 14.2222 19.5555 14.2222C20.0465 14.2222 20.4444 14.6202 20.4444 15.1111C20.4444 16.2898 19.9762 17.4203 19.1427 18.2538C18.3092 19.0873 17.1787 19.5555 16 19.5555C14.8212 19.5555 13.6908 19.0873 12.8573 18.2538C12.0238 17.4203 11.5555 16.2898 11.5555 15.1111C11.5555 14.6202 11.9535 14.2222 12.4444 14.2222Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				},
				{
					d: 'M11.2408 6.68254C11.4307 6.46089 11.7081 6.33333 12 6.33333H20C20.2919 6.33333 20.5693 6.46089 20.7593 6.68254L24.7593 11.3492C25.0134 11.6457 25.0717 12.0631 24.9085 12.4179C24.7453 12.7727 24.3905 13 24 13H8.00001C7.60948 13 7.25469 12.7727 7.0915 12.4179C6.92832 12.0631 6.9866 11.6457 7.24076 11.3492L11.2408 6.68254ZM12.4599 8.33333L10.1742 11H21.8258L19.5401 8.33333H12.4599Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				},
				{
					d: 'M7 12C7 11.4477 7.44772 11 8 11H24C24.5523 11 25 11.4477 25 12V25.3333C25 25.8856 24.5523 26.3333 24 26.3333H8C7.44772 26.3333 7 25.8856 7 25.3333V12ZM9 13V24.3333H23V13H9Z',
					fillRule: 'evenodd',
					clipRule: 'evenodd'
				}
			]
		},
		// Outline puzzle + light corner plus (product add-ons key icon).
		addons: {
			opticalScale: 1.06,
			paths: [
				{
					d: 'M15.26 8.37H14.18V5.49C14.18 4.7 13.53 4.05 12.74 4.05H9.86V2.97C9.86 1.98 9.05 1.17 8.06 1.17C7.07 1.17 6.26 1.98 6.26 2.97V4.05H3.38C2.59 4.05 1.95 4.7 1.95 5.49V8.23H3.02C4.09 8.23 4.96 9.1 4.96 10.17C4.96 11.24 4.09 12.11 3.02 12.11H1.94V14.85C1.94 15.64 2.59 16.29 3.38 16.29H6.12V15.21C6.12 14.14 6.99 13.27 8.06 13.27C9.13 13.27 10 14.14 10 15.21V16.29H12.74C13.53 16.29 14.18 15.64 14.18 14.85V11.97H15.26C16.25 11.97 17.06 11.16 17.06 10.17C17.06 9.18 16.25 8.37 15.26 8.37Z',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.5',
					strokeLinejoin: 'round'
				},
				{
					d: 'M16.4 17.9h4.8M18.8 15.5v4.8',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.45',
					strokeLinecap: 'round'
				}
			]
		},
		checkPayment: {
			opticalScale: 1.06,
			paths: [
				{
					d: 'M17.3 8v1c1 .2 1.4.9 1.4 1.7h-1c0-.6-.3-1-1-1-.8 0-1.3.4-1.3.9 0 .4.3.6 1.4 1 1 .2 2 .6 2 1.9 0 .9-.6 1.4-1.5 1.5v1H16v-1c-.9-.1-1.6-.7-1.7-1.7h1c0 .6.4 1 1.3 1 1 0 1.2-.5 1.2-.8 0-.4-.2-.8-1.3-1.1-1.3-.3-2.1-.8-2.1-1.8 0-.9.7-1.5 1.6-1.6V8h1.3zM12 10v1H6v-1h6zm2-2v1H6V8h8zM2 4v16h20V4H2zm2 14V6h16v12H4z',
					fillRule: 'nonzero'
				},
				{
					d: 'M6 16c2.6 0 3.9-3 1.7-3-2 0-1 3 1.5 3 1 0 1-.8 2.8-.8',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.6',
					strokeLinecap: 'round'
				}
			]
		},
		productFilterStatus: {
			opticalScale: 1.06,
			paths: [
				{
					d: 'M4.75 4.8999C4.75 4.20955 5.30964 3.6499 6 3.6499H8.34082C8.7889 3.6499 9.20271 3.88974 9.42544 4.27854L9.62184 4.62136C9.84457 5.01016 10.2584 5.25 10.7065 5.25H13C13.6904 5.25 14.25 5.80964 14.25 6.5V10.3999C14.25 11.0903 13.6904 11.6499 13 11.6499H6C5.30964 11.6499 4.75 11.0903 4.75 10.3999V4.8999Z',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.6',
					strokeLinejoin: 'round'
				},
				{
					d: 'M4 15.25H20',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.6',
					strokeLinecap: 'round'
				},
				{
					d: 'M4 19.25H13',
					fill: 'none',
					stroke: 'currentColor',
					strokeWidth: '1.6',
					strokeLinecap: 'round'
				}
			]
		}
	};

	/**
	 * @param {Function} h           wp.element.createElement
	 * @param {string}   name        Key in ICONS
	 * @param {string}   [className] Extra classes (e.g. wca-key-icon)
	 * @param {Object}   [extra]     Extra SVG attributes (title is applied as child <title> if string)
	 * @return {Object|null} React element
	 */
	function render( h, name, className, extra ) {
		var def = ICONS[ name ];
		if ( ! def || ! def.paths || ! def.paths.length ) {
			return null;
		}
		var svgClass = 'wca-wp-icon';
		if ( className ) {
			svgClass += ' ' + className;
		}
		var svgProps = {
			className: svgClass,
			viewBox: def.viewBox || '0 0 24 24',
			xmlns: 'http://www.w3.org/2000/svg',
			'aria-hidden': 'true',
			focusable: 'false'
		};
		var children = [];
		if ( extra && extra.title ) {
			children.push( h( 'title', { key: 't' }, extra.title ) );
		}
		var pathGroupChildren = [];
		def.paths.forEach( function( p, idx ) {
			var pp = { key: 'p' + idx, d: p.d };
			if ( p.fillRule ) { pp.fillRule = p.fillRule; }
			if ( p.clipRule ) { pp.clipRule = p.clipRule; }
			if ( p.fill !== undefined ) { pp.fill = p.fill; }
			if ( p.stroke ) { pp.stroke = p.stroke; }
			if ( p.strokeWidth != null ) { pp.strokeWidth = p.strokeWidth; }
			if ( p.stroke ) {
				pp.strokeLinecap = p.strokeLinecap || 'round';
				pp.strokeLinejoin = p.strokeLinejoin || 'round';
			}
			if ( p.opacity != null ) { pp.opacity = p.opacity; }
			pathGroupChildren.push( h( 'path', pp ) );
		} );
		if ( def.opticalScale && def.opticalScale !== 1 ) {
			var center = ( def.viewBox === '0 0 32 32' ) ? 16 : 12;
			var tr = 'translate(' + center + ' ' + center + ') scale(' + def.opticalScale + ') translate(' + ( -center ) + ' ' + ( -center ) + ')';
			children.push( h( 'g', { key: 'g0', transform: tr }, pathGroupChildren ) );
		} else {
			children = children.concat( pathGroupChildren );
		}
		if ( extra ) {
			var k;
			for ( k in extra ) {
				if ( extra.hasOwnProperty( k ) && k !== 'title' ) {
					svgProps[ k ] = extra[ k ];
				}
			}
		}
		return h.apply( null, [ 'svg', svgProps ].concat( children ) );
	}

	window.wcaWpIcons = { render: render };
} )();
