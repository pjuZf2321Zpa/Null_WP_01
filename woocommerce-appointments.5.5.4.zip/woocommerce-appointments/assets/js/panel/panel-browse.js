/**
 * Panel Browse — BrowsePanel controlled rendering component.
 *
 * Extracted from appointment-admin-panel.js to eliminate duplication
 * between EditContent and CreateContent components.
 *
 * Renders the mini calendar (strip / full month / month grid) and slot chips.
 * All state is received as props from the parent's useBrowseState() hook.
 * Data loading is delegated to callbacks provided by the parent.
 *
 * @since 5.3.0
 */

var panelBrowse = ( function() {
	'use strict';

	if ( ! window.wp || ! window.wp.element ) { return {}; }

	var h        = wp.element.createElement;
	var Fragment = wp.element.Fragment;

	var helpers = window.panelHelpers || {};

	/**
	 * BrowsePanel — controlled availability browser component.
	 *
	 * State props (from parent's useBrowseState):
	 * @param {string}   props.miniCalMonth       Current calendar YYYY-MM.
	 * @param {Object}   props.miniCalData        Calendar data ({ days:{}, months:{} }).
	 * @param {boolean}  props.miniCalLoading      Loading indicator.
	 * @param {boolean}  props.miniCalExpanded     Full-month vs strip view.
	 * @param {string}   props.miniCalStripCenter  Strip center YYYY-MM-DD.
	 * @param {Object}   props.slotsData           Day slots data.
	 * @param {boolean}  props.slotsLoading        Slots loading indicator.
	 * @param {string}   props.availStatus         'available'|'unavailable'|''.
	 * @param {string}   props.availMessage        Availability message text.
	 *
	 * Config props:
	 * @param {string}   props.durationUnit    'hour'|'minute'|'day'|'month' or ''.
	 * @param {boolean}  props.showTimeFields  Whether to show time slot chips.
	 * @param {boolean}  props.showDateRange   Whether product uses day-based duration.
	 * @param {boolean}  props.showMonthRange  Whether product uses month-based duration.
	 * @param {string}   props.formDate        Current single-date value (YYYY-MM-DD).
	 * @param {string}   props.formDateFrom    Current range start date.
	 * @param {string}   props.formMonthFrom   Current month range start.
	 * @param {string}   props.formTimeFrom    Current selected time.
	 * @param {Object}   props.panelCfg        Panel config (locale, firstday, etc.).
	 * @param {Function} props.t               Translation helper.
	 * @param {string}   props.idPrefix        Element ID prefix ('wca-edit' or 'wca-create').
	 *
	 * Action callbacks (parent provides these, wrapping current productId/staffId/qty):
	 * @param {Function} props.loadMonthAvailability  Called with (yearMonth).
	 * @param {Function} props.loadStripAvailability  Called with (centerYMD).
	 * @param {Function} props.loadDaySlots           Called with (dateStr).
	 * @param {Function} props.setMiniCalExpanded     Called with (bool).
	 *
	 * Selection callbacks (parent handles form state updates):
	 * @param {Function} props.onDayClick       Called with (dateStr) when a day cell is clicked.
	 * @param {Function} props.onMonthClick     Called with (monthStr) when a month cell is clicked.
	 * @param {Function} props.onSlotClick      Called with (timeStr, startTs) when a slot chip is clicked; startTs is engine Unix start (optional).
	 */
	function BrowsePanel( props ) {
		var durationUnit   = props.durationUnit || '';
		var showTimeFields = props.showTimeFields;
		var showDateRange  = props.showDateRange;
		var showMonthRange = props.showMonthRange;
		var formDate       = props.formDate || '';
		var formDateFrom   = props.formDateFrom || '';
		var formMonthFrom  = props.formMonthFrom || '';
		var formTimeFrom   = props.formTimeFrom || '';
		var formTimeFromSite = props.formTimeFromSite || '';
		var formStartTs    = props.formStartTs || 0;
		var panelCfg       = props.panelCfg || {};
		var t              = props.t || function( k, fb ) { return fb || k; };
		var idPrefix       = props.idPrefix || 'wca-browse';

		// State from parent
		var miniCalMonth       = props.miniCalMonth || '';
		var miniCalData        = props.miniCalData;
		var miniCalLoading     = props.miniCalLoading;
		var miniCalExpanded    = props.miniCalExpanded;
		var miniCalStripCenter = props.miniCalStripCenter || '';
		var slotsData          = props.slotsData;
		var slotsLoading       = props.slotsLoading;
		var fTsInt = parseInt( formStartTs || 0, 10 );
		var hasTsMatch = fTsInt > 0 && slotsData && slotsData.slots && slotsData.slots.some( function( s ) { return parseInt( s.start_ts || 0, 10 ) === fTsInt; } );

		// Action callbacks from parent
		var loadMonthAvailability = props.loadMonthAvailability || function() {};
		var loadStripAvailability = props.loadStripAvailability || function() {};
		var loadDaySlots          = props.loadDaySlots || function() {};
		var setMiniCalExpanded    = props.setMiniCalExpanded || function() {};
		var setMiniCalStripCenter = props.setMiniCalStripCenter || function() {};
		var onDayClick            = props.onDayClick || function() {};
		var onMonthClick          = props.onMonthClick || function() {};
		var onSlotClick           = props.onSlotClick || function() {};

		/** True when miniCalData already has every Y-M-D key (view toggle can skip refetch). */
		function miniCalHasDayKeys( ymdList ) {
			var days = ( miniCalData && miniCalData.days ) || {};
			if ( ! ymdList || ! ymdList.length ) { return false; }
			for ( var i = 0; i < ymdList.length; i++ ) {
				if ( ! Object.prototype.hasOwnProperty.call( days, ymdList[ i ] ) ) {
					return false;
				}
			}
			return true;
		}

		// ── Locale helpers ──
		var locale = helpers.getCalendarLocale( panelCfg );
		var firstDayOfWeek = helpers.getFirstDayOfWeek( panelCfg );
		var todayStr = helpers.getTodayYMD();
		var currentYM = helpers.getCurrentYM();
		var isMonthUnit = durationUnit === 'month';

		// Mini-cal day keys: timed+different TZ use admin civil dates; day/all-day use civil Y-M-D.
		// Do not admin→site convert midnight placeholders (shifts AWST staff selection by one day).
		function selectedDayYMD() {
			if ( showDateRange ) {
				return formDateFrom || '';
			}
			return formDate || '';
		}

		// ── Shift strip by N days ──
		function shiftStrip( days ) {
			var center = miniCalStripCenter || selectedDayYMD() || '';
			if ( ! center ) { return; }
			var d = new Date( center + 'T12:00:00' );
			if ( isNaN( d.getTime() ) ) { return; }
			d.setDate( d.getDate() + days );
			var newCenter = d.getFullYear() + '-' + ( '0' + ( d.getMonth() + 1 ) ).slice( -2 ) + '-' + ( '0' + d.getDate() ).slice( -2 );
			loadStripAvailability( newCenter );
		}

		// ── Render notices ──
		function renderNotices() {
			if ( showTimeFields && formDate && ! slotsLoading ) {
				var dateOnlyPick = helpers.isDateOnlyTimePlaceholder( formTimeFrom, formStartTs );
				var availSlots = slotsData ? ( slotsData.slots || [] ).filter( function( s ) { return s.available; } ) : null;
				if ( dateOnlyPick && ( props.availStatus === 'unavailable' || ( availSlots && ! availSlots.length ) ) ) {
					return h( 'div', { className: 'wca-slots-notice wca-slots-notice--warning' }, props.availMessage || t( 'noSlotsOnDateSelect', 'No available time slots on this date. Please select a different date.' ) );
				}
				if ( ! slotsData ) {
					return null;
				}
				if ( formTimeFrom && slotsData.total_available > 0 ) {
					var timeFound = false;
					var compareTime = formTimeFromSite || formTimeFrom;
					for ( var si = 0; si < availSlots.length; si++ ) {
						var st = availSlots[ si ].time;
						var sat = availSlots[ si ].admin_time;
						if ( st === compareTime || ( sat && sat === compareTime ) ) { timeFound = true; break; }
					}
					if ( ! timeFound ) {
						return h( 'div', { className: 'wca-slots-notice wca-slots-notice--warning' }, t( 'timeUnavailableOnDate', 'Your selected time is not available on this date. Please select an available time slot below.' ) );
					}
				} else if ( formTimeFrom && slotsData.total_available === 0 ) {
					return h( 'div', { className: 'wca-slots-notice wca-slots-notice--warning' }, t( 'noSlotsOnDateSelect', 'No available time slots on this date. Please select a different date.' ) );
				}
				return null;
			}
			if ( showDateRange && ! showTimeFields ) {
				if ( props.availStatus === 'unavailable' ) {
					return h( 'div', { className: 'wca-slots-notice wca-slots-notice--warning' }, props.availMessage || t( 'dateRangeUnavailable', 'This date range is not available. Please select different dates.' ) );
				}
				if ( ! formDateFrom ) {
					return h( 'div', { className: 'wca-slots-notice wca-slots-notice--info' }, t( 'selectDateRange', 'Select a start date for this day-based product.' ) );
				}
				return null;
			}
			if ( showMonthRange && ! showTimeFields ) {
				if ( props.availStatus === 'unavailable' ) {
					return h( 'div', { className: 'wca-slots-notice wca-slots-notice--warning' }, props.availMessage || t( 'monthRangeUnavailable', 'This month range is not available. Please select different months.' ) );
				}
				if ( ! formMonthFrom ) {
					return h( 'div', { className: 'wca-slots-notice wca-slots-notice--info' }, t( 'selectMonthRange', 'Select a start month for this month-based product.' ) );
				}
				return null;
			}
			return null;
		}

		// ── Handle day click (select only; do not refetch month/strip) ──
		function handleDayClick( dateStr ) {
			if ( dateStr < todayStr ) { return; }
			var dayMeta = ( miniCalData && miniCalData.days ) ? ( miniCalData.days[ dateStr ] || { available: false, slots_count: 0 } ) : { available: false, slots_count: 0 };
			if ( ! dayMeta.available ) { return; }
			onDayClick( dateStr );
			if ( showTimeFields ) { loadDaySlots( dateStr ); }
		}

		// ── Handle month click ──
		function handleMonthClick( monthStr ) {
			if ( monthStr < currentYM ) { return; }
			onMonthClick( monthStr );
		}

		// Skeleton day/month cells only (header stays in renderCalendar).
		function calSkelCells( count ) {
			var cells = [];
			for ( var i = 0; i < count; i++ ) {
				cells.push( h( 'div', { key: 'sk' + i, className: 'wca-mini-cal-skel' } ) );
			}
			return cells;
		}

		// ── Render calendar ──
		function renderCalendar() {
			var ym = miniCalMonth;
			if ( ! isMonthUnit && ! miniCalExpanded ) {
				var stripCenterFallback = miniCalStripCenter || selectedDayYMD() || todayStr;
				ym = stripCenterFallback ? stripCenterFallback.substring( 0, 7 ) : ym;
			}
			if ( ! ym ) { return null; }
			var parts = ym.split( '-' );
			var year = parseInt( parts[ 0 ], 10 );
			var month = parseInt( parts[ 1 ], 10 ) - 1;

			// Navigation header
			var headerNode = h( 'div', { className: 'wca-mini-cal-header' },
				h( 'button', { type: 'button', className: 'wca-mini-cal-nav', onClick: function() {
					if ( isMonthUnit ) { loadMonthAvailability( ( year - 1 ) + '-' + ( '0' + ( month + 1 ) ).slice( -2 ) ); }
					else { var nd = new Date( year, month - 1, 1 ); loadMonthAvailability( nd.getFullYear() + '-' + ( '0' + ( nd.getMonth() + 1 ) ).slice( -2 ) ); }
				} }, '\u2039' ),
				h( 'input', { type: 'month', className: 'wca-mini-cal-title', value: ym, onChange: function( e ) {
					if ( e.target.value ) { loadMonthAvailability( e.target.value ); }
				} } ),
				h( 'button', { type: 'button', className: 'wca-mini-cal-nav', onClick: function() {
					if ( isMonthUnit ) { loadMonthAvailability( ( year + 1 ) + '-' + ( '0' + ( month + 1 ) ).slice( -2 ) ); }
					else { var nd2 = new Date( year, month + 1, 1 ); loadMonthAvailability( nd2.getFullYear() + '-' + ( '0' + ( nd2.getMonth() + 1 ) ).slice( -2 ) ); }
				} }, '\u203A' )
			);

			// Month grid (month-based products)
			if ( isMonthUnit ) {
				if ( miniCalLoading ) {
					return h( Fragment, null, headerNode, h( 'div', { className: 'wca-mini-cal-month-grid' }, calSkelCells( 12 ) ) );
				}
				var months = ( miniCalData && miniCalData.months ) || {};
				var monthCells = [];
				for ( var mi = 1; mi <= 12; mi++ ) {
					var mk = year + '-' + ( '0' + mi ).slice( -2 );
					var md = months[ mk ] || { available: false };
					var mLabel;
					try { mLabel = new Date( year, mi - 1, 1 ).toLocaleDateString( locale, { month: 'short' } ); }
					catch ( e3 ) { mLabel = ( '0' + mi ).slice( -2 ); }
					var mCls = 'wca-mini-cal-month-cell';
					if ( mk === currentYM ) { mCls += ' is-current'; }
					if ( mk === formMonthFrom ) { mCls += ' is-selected'; }
					if ( mk < currentYM ) { mCls += ' is-past'; }
					if ( ! md.available ) { mCls += ' is-unavailable'; }
					( function( mkVal ) {
						monthCells.push( h( 'div', { key: mkVal, className: mCls, onClick: function() { handleMonthClick( mkVal ); } },
							h( 'span', { className: 'wca-month-label' }, mLabel ),
							h( 'span', { className: 'wca-mini-cal-dot' + ( md.available ? '' : ' dot-none' ) } )
						) );
					} )( mk );
				}
				return h( Fragment, null, headerNode, h( 'div', { className: 'wca-mini-cal-month-grid' }, monthCells ) );
			}

			// 7-day strip
			if ( ! miniCalExpanded ) {
				var selectedDate = selectedDayYMD();
				var stripCenter = miniCalStripCenter || selectedDate || todayStr;
				var stripDates = helpers.getStripDates( stripCenter, firstDayOfWeek );
				var stripTitle = '';
				if ( stripDates.length ) {
					try {
						var d1 = new Date( stripDates[ 0 ] + 'T12:00:00' );
						var d2 = new Date( stripDates[ stripDates.length - 1 ] + 'T12:00:00' );
						var left = d1.toLocaleDateString( locale, { month: 'short', day: 'numeric' } );
						var right = d2.toLocaleDateString( locale, { month: 'short', day: 'numeric' } );
						stripTitle = d1.getFullYear() === d2.getFullYear()
							? left + ' \u2013 ' + right + ', ' + d2.getFullYear()
							: d1.toLocaleDateString( locale, { month: 'short', day: 'numeric', year: 'numeric' } ) + ' \u2013 ' + d2.toLocaleDateString( locale, { month: 'short', day: 'numeric', year: 'numeric' } );
					} catch ( eTitle ) { stripTitle = stripDates[ 0 ] + ' \u2013 ' + stripDates[ stripDates.length - 1 ]; }
				}
				var stripHeaderNode = h( 'div', { className: 'wca-mini-cal-header wca-mini-cal-strip-header' },
					h( 'button', { type: 'button', className: 'wca-mini-cal-nav', onClick: function() { shiftStrip( -7 ); } }, '\u2039' ),
					h( 'span', { className: 'wca-mini-cal-title wca-mini-cal-strip-title' }, stripTitle ),
					h( 'button', { type: 'button', className: 'wca-mini-cal-nav', onClick: function() { shiftStrip( 7 ); } }, '\u203A' )
				);
				var expandBtn = h( 'button', { type: 'button', className: 'wca-expand-btn', onClick: function() {
					var ym = stripCenter.substring( 0, 7 );
					setMiniCalExpanded( true );
					// Layout-only when this month's days are already in memory.
					var hasYm = false;
					var dmap = ( miniCalData && miniCalData.days ) || {};
					for ( var dk in dmap ) {
						if ( dk.indexOf( ym + '-' ) === 0 ) { hasYm = true; break; }
					}
					if ( ! hasYm ) { loadMonthAvailability( ym ); }
				} }, t( 'expandToFullMonth', 'Expand to full month' ) );
				if ( miniCalLoading ) {
					return h( Fragment, null, stripHeaderNode, h( 'div', { className: 'wca-mini-cal-strip' }, calSkelCells( 7 ) ), expandBtn );
				}
				var days = ( miniCalData && miniCalData.days ) || {};
				var stripCells = [];
				for ( var si = 0; si < stripDates.length; si++ ) {
					var dayStr = stripDates[ si ];
					var dayD = days[ dayStr ] || { available: false, slots_count: 0 };
					var dCls = 'wca-mini-cal-day wca-mini-cal-strip-day';
					if ( dayStr === todayStr ) { dCls += ' is-today'; }
					if ( dayStr === selectedDate ) { dCls += ' is-selected'; }
					if ( dayStr < todayStr ) { dCls += ' is-past'; }
					if ( ! dayD.available ) { dCls += ' is-unavailable'; }
					var dotCls = 'wca-mini-cal-dot';
					if ( ! dayD.available ) { dotCls += ' dot-none'; }
					else if ( dayD.slots_count <= 2 ) { dotCls += ' dot-low'; }
					var dayNum = parseInt( dayStr.split( '-' )[ 2 ], 10 );
					var dowShort = '';
					try { var stripD = new Date( dayStr + 'T12:00:00' ); dowShort = stripD.toLocaleDateString( locale, { weekday: 'narrow' } ); } catch ( eStrip ) {}
					( function( dsVal ) {
						stripCells.push( h( 'div', { key: dsVal, className: dCls, onClick: function() { handleDayClick( dsVal ); } },
							h( 'span', { className: 'wca-mini-cal-strip-dow' }, dowShort ),
							dayNum,
							h( 'span', { className: dotCls } )
						) );
					} )( dayStr );
				}
				return h( Fragment, null, stripHeaderNode, h( 'div', { className: 'wca-mini-cal-strip' }, stripCells ), expandBtn );
			}

			// Full month grid
			var days = ( miniCalData && miniCalData.days ) || {};
			var daysInMonth = new Date( year, month + 1, 0 ).getDate();
			var startDow = new Date( year, month, 1 ).getDay();
			var offset = ( startDow - firstDayOfWeek + 7 ) % 7;
			var selectedDate = selectedDayYMD();

			// DOW headers
			var dowCells = [];
			for ( var di = 0; di < 7; di++ ) {
				var refDate = new Date( 2024, 0, 7 + firstDayOfWeek + di );
				var lbl;
				try { lbl = refDate.toLocaleDateString( locale, { weekday: 'narrow' } ); }
				catch ( e4 ) { lbl = [ 'S', 'M', 'T', 'W', 'T', 'F', 'S' ][ ( firstDayOfWeek + di ) % 7 ]; }
				dowCells.push( h( 'div', { key: 'dow-' + di, className: 'wca-mini-cal-dow' }, lbl ) );
			}

			var showWeekBtn = ! showMonthRange ? h( 'button', { type: 'button', className: 'wca-expand-btn', onClick: function() {
				var center = selectedDayYMD() || todayStr;
				var stripDates = helpers.getStripDates( center, firstDayOfWeek );
				var reuse = miniCalHasDayKeys( stripDates );
				setMiniCalExpanded( false );
				setMiniCalStripCenter( center );
				if ( ! reuse ) { loadStripAvailability( center ); }
			} }, t( 'showWeekView', 'Show week view' ) ) : null;

			if ( miniCalLoading ) {
				return h( Fragment, null, headerNode, h( 'div', { className: 'wca-mini-cal-grid' }, dowCells, calSkelCells( 35 ) ), showWeekBtn );
			}

			// Empty cells
			var blanks = [];
			for ( var bi = 0; bi < offset; bi++ ) {
				blanks.push( h( 'div', { key: 'b-' + bi, className: 'wca-mini-cal-day is-other-month' } ) );
			}

			// Day cells
			var dayCells = [];
			for ( var dd = 1; dd <= daysInMonth; dd++ ) {
				var dayStr = ym + '-' + ( '0' + dd ).slice( -2 );
				var dayD = days[ dayStr ] || { available: false, slots_count: 0 };
				var dCls = 'wca-mini-cal-day';
				if ( dayStr === todayStr ) { dCls += ' is-today'; }
				if ( dayStr === selectedDate ) { dCls += ' is-selected'; }
				if ( dayStr < todayStr ) { dCls += ' is-past'; }
				if ( ! dayD.available ) { dCls += ' is-unavailable'; }
				var dotCls = 'wca-mini-cal-dot';
				if ( ! dayD.available ) { dotCls += ' dot-none'; }
				else if ( dayD.slots_count <= 2 ) { dotCls += ' dot-low'; }
				( function( dsVal ) {
					dayCells.push( h( 'div', { key: dsVal, className: dCls, onClick: function() { handleDayClick( dsVal ); } },
						dd,
						h( 'span', { className: dotCls } )
					) );
				} )( dayStr );
			}

			return h( Fragment, null, headerNode, h( 'div', { className: 'wca-mini-cal-grid' }, dowCells, blanks, dayCells ), showWeekBtn );
		}

		// Render slot chips
		function renderSlots() {
			if ( ! showTimeFields || ! formDate ) { return null; }

			// slot.capacity is remaining places (capacity_available), not product max.
			// Show per-chip counts on multi-capacity products (any slot still has 2+ left).
			var showSlotCapacityLabels = false;
			if ( props.showSlotCapacity === true ) {
				showSlotCapacityLabels = true;
			} else if ( props.showSlotCapacity !== false && slotsData && slotsData.slots ) {
				showSlotCapacityLabels = slotsData.slots.some( function( s ) {
					return s.available && ( parseInt( s.capacity, 10 ) || 0 ) > 1;
				} );
			}

			return h( 'div', { className: 'wca-slots-panel' + ( slotsLoading ? ' is-loading' : '' ) },
				h( 'div', { className: 'wca-slots-header' },
					h( 'span', { className: 'wca-slots-title' }, t( 'availableSlots', 'Available Slots' ) ),
					slotsData && slotsData.total_available > 0 ? h( 'span', { className: 'wca-slots-count' }, slotsData.total_available + ' ' + t( 'slotsAvailable', 'available' ) ) : null
				),
				slotsLoading ? h( 'div', { className: 'wca-slots-grid' },
					h( 'div', { className: 'wca-slot-skeleton' } ),
					h( 'div', { className: 'wca-slot-skeleton' } ),
					h( 'div', { className: 'wca-slot-skeleton' } ),
					h( 'div', { className: 'wca-slot-skeleton' } ),
					h( 'div', { className: 'wca-slot-skeleton' } ),
					h( 'div', { className: 'wca-slot-skeleton' } )
				) : ( slotsData && slotsData.slots && slotsData.slots.length > 0 ? h( 'div', { className: 'wca-slots-grid' },
					slotsData.slots.filter( function( s ) { return s.available; } ).map( function( slot, slotIdx ) {
						// slot.time is the value used for selection/saving (HH:MM).
						// slot.display_time is purely for display and should respect WP time_format.
						var slotValue = slot.time || '';
						var slotStartTs = parseInt( slot.start_ts || 0, 10 );
						// Use start_ts for unambiguous matching (especially important for TZs).
						// Fallback to time string matching ONLY if no precise timestamp match exists in this grid.
						var isSel = false;
						if ( hasTsMatch ) {
							isSel = ( slotStartTs === fTsInt );
						} else {
							isSel = formTimeFromSite ? ( slotValue === formTimeFromSite ) : ( slotValue === formTimeFrom );
						}
						var displayTime = slot.display_time || slotValue;

						return h( 'button', {
							key: slotValue + '-' + slotIdx,
							type: 'button',
							className: 'wca-slot-chip' + ( isSel ? ' is-selected' : '' ),
							onClick: function() { onSlotClick( slotValue, slot.start_ts, slot.admin_time, slot.admin_date ); }
						},
							h( 'span', { className: 'wca-slot-time' }, displayTime ),
							slot.price && slot.price.show && slot.price.display ? h( 'span', { className: 'wca-slot-price', dangerouslySetInnerHTML: { __html: slot.price.display } } ) : null,
							showSlotCapacityLabels && ( parseInt( slot.capacity, 10 ) || 0 ) >= 1 ? h( 'span', { className: 'wca-slot-capacity' }, slot.capacity + ' ' + t( 'slotsAvailable', 'available' ) ) : null,
							slot.staff_available && slot.staff_available.length > 0 ? h( 'span', { className: 'wca-slot-staff-count' }, slot.staff_available.length + ' ' + t( 'staffCount', 'staff' ) ) : null
						);
					} )
				) : h( 'div', { className: 'wca-slots-empty' }, t( 'noSlots', 'No available slots' ) ) )
			);
		}

		// ── Main render ──
		return h( 'div', { id: idPrefix + '-browse-panel', className: 'wca-browse-panel', role: 'region', 'aria-label': t( 'browseAvailability', 'Browse availability' ) },
			renderNotices(),
			h( 'div', { className: 'wca-mini-cal' },
				renderCalendar()
			),
			renderSlots()
		);
	}

	return {
		BrowsePanel: BrowsePanel
	};

} )();

if ( typeof window !== 'undefined' ) {
	window.panelBrowse = panelBrowse;
}

if ( typeof module !== 'undefined' && module.exports ) {
	module.exports = panelBrowse;
}
