/* global */
( function() {
	'use strict';
	var boot = window.wcaAvailabilityHub || {};
	var TYPES_FULL = boot.typesFull || [];
	var TYPES_PLACE = boot.typesPlace || TYPES_FULL.filter( function( p ) {
		return -1 !== [ 'custom', 'custom:daterange', 'days', 'time' ].indexOf( p[0] ) || /^time:[1-7]$/.test( p[0] );
	} );
	var STAFF_ALLOWED = boot.staffAllowedTypes || null; // null = all; string[] = staff permission level
	var TYPE_LABEL = {};
	TYPES_FULL.forEach( function( p ) { TYPE_LABEL[p[0]] = p[1]; } );
	var DAY_SHORT = boot.dayShort || { '1': 'Mon', '2': 'Tue', '3': 'Wed', '4': 'Thu', '5': 'Fri', '6': 'Sat', '7': 'Sun' };
	/* WP start_of_week is 0=Sun-6=Sat; wp_localize_script may stringify it. */
	var START_OF_WEEK = ( function() {
		var n = parseInt( boot.startOfWeek, 10 );
		return ( !isNaN( n ) && 0 <= n && 6 >= n ) ? n : 1;
	} )();
	var DEFAULT_LAYER = boot.defaultLayer || 'global';
	/* Display order; never invent location/resource when boot omits them (hard-disable / staff caps). */
	var LAYER_ORDER = [ 'global', 'location', 'resource', 'product', 'staff' ].filter( function( layer ) {
		return Array.isArray( boot.allowedLayers )
			? -1 !== boot.allowedLayers.indexOf( layer )
			: -1 !== [ 'global', 'product', 'staff' ].indexOf( layer );
	} );
	/* Edit/save layers; omit = all visible layers editable (admins). */
	var EDIT_LAYERS = Array.isArray( boot.editableLayers ) ? boot.editableLayers : null;
	var LAYER_BAG = { location: 'locations', resource: 'resources', product: 'products', staff: 'staff' };
	var PRESENCE_KEY = { global: 'global', product: 'products', staff: 'staff', location: 'locations', resource: 'resources' };
	var CAN_SET_APPOINTABLE = false !== boot.canSetAppointable;
	/* Site 09:00–17:00 defaults, already shifted to viewer TZ when it differs. */
	var SUGGEST_FROM = boot.suggestFrom || '09:00';
	var SUGGEST_TO = boot.suggestTo || '17:00';

	function canEditTab() {
		return !EDIT_LAYERS || -1 !== EDIT_LAYERS.indexOf( state.tab );
	}
	var i18n = boot.i18n || {};
	var entities = boot.entities || { locations: [], resources: [], products: [], staff: [] };
	var pendingRuleFocus = boot.initial && boot.initial.ruleId ? String( boot.initial.ruleId ) : '';
	var nid = 1;
	var state = {
		tab: boot.initial && boot.initial.tab ? boot.initial.tab : DEFAULT_LAYER,
		showPriority: !!boot.showPriority,
		showStatus: false !== boot.showStatus,
		showTitle: false !== boot.showTitle,
		sideQuery: '',
		searchLayer: '',
		railOpen: false,
		dirty: false,
		saving: false,
		locationId: boot.initial && boot.initial.locationId ? String( boot.initial.locationId ) : ( entities.locations[0] && String( entities.locations[0].id ) ) || '',
		resourceId: boot.initial && boot.initial.resourceId ? String( boot.initial.resourceId ) : ( entities.resources[0] && String( entities.resources[0].id ) ) || '',
		productId: boot.initial && boot.initial.productId ? String( boot.initial.productId ) : ( entities.products[0] && String( entities.products[0].id ) ) || '',
		staffId: boot.initial && boot.initial.staffId ? String( boot.initial.staffId ) : ( entities.staff[0] && String( entities.staff[0].id ) ) || '',
		presence: boot.presence || { staff: false, locations: false, resources: false, products: true, global: true },
		deleted: { global: [], location: {}, resource: {}, product: {}, staff: {} },
		rules: boot.rules || { global: [], location: {}, resource: {}, product: {}, staff: {} }
	};
	state.baseline = JSON.parse( JSON.stringify( state.rules ) );
	var pinSideTop = true; // pin current entity to top of rail list after next paint

	var copy = {
		global: {
			name: i18n.layerGlobal || 'General',
			blurb: i18n.blurbGlobal || 'Applies shop-wide. Rules on other levels override them.',
			emptyHours: i18n.emptyHoursGlobal || 'Add when appointments are usually available.',
			emptyExcep: i18n.emptyExcepGlobal || 'Add holidays, maintenance, or other shop-wide closures.'
		},
		location: {
			name: i18n.layerLocation || 'Location',
			blurb: i18n.blurbLocation || 'Add rules only when this venue should differ from other layers.',
			emptyHours: i18n.emptyHoursInherit || 'Add hours only when they should differ from other layers.',
			emptyExcep: i18n.emptyExcepLocation || 'Block days or hours this venue cannot take appointments.',
			side: 'locations',
			place: true
		},
		resource: {
			name: i18n.layerResource || 'Resource',
			blurb: i18n.blurbResource || 'Add rules only when this room or equipment should differ from other layers.',
			emptyHours: i18n.emptyHoursInherit || 'Add hours only when they should differ from other layers.',
			emptyExcep: i18n.emptyExcepResource || 'Block days or hours this room or equipment is out of service.',
			side: 'resources',
			place: true
		},
		product: {
			name: i18n.layerProduct || 'Product',
			blurb: i18n.blurbProduct || 'Add rules only to limit this product further.',
			emptyHours: i18n.emptyHoursProduct || 'No product hours yet.',
			emptyExcep: i18n.emptyExcepProduct || 'Add closures that apply only to this product, not the whole shop.',
			side: 'products'
		},
		staff: {
			name: i18n.layerStaff || 'Staff',
			blurb: i18n.blurbStaff || 'Add rules only when the schedule should differ from other layers.',
			emptyHours: i18n.emptyHoursInherit || 'Add hours only when they should differ from other layers.',
			emptyExcep: i18n.emptyExcepStaff || 'Add vacation, sick leave, or other blocked times.',
			side: 'staff'
		}
	};

	function layerPresent( layer ) {
		var key = PRESENCE_KEY[layer];
		return !!key && -1 !== LAYER_ORDER.indexOf( layer ) && false !== state.presence[key];
	}
	function visibleLayers() {
		return Array.prototype.slice.call( document.querySelectorAll( '.hub-layer' ) ).filter( function( el ) {
			return !el.hidden;
		} );
	}
	function syncLayerPresence() {
		document.querySelectorAll( '.hub-layer' ).forEach( function( el ) {
			var key = el.dataset.tab;
			var show = layerPresent( key );
			el.hidden = !show;
			if ( !show && 'page' === el.getAttribute( 'aria-current' ) ) {
				el.setAttribute( 'aria-current', 'false' );
			}
		} );
	}
	function productHoursEmptyHtml() {
		var list = [ 'global', 'staff', 'location', 'resource' ].filter( layerPresent ).map( layerLabel ).join( ' · ' );
		var body = ( i18n.productHoursEmpty || 'Follows %s when those layers allow the time. Add product hours only to limit this service further.' ).replace( '%s', list );
		return '<strong>' + esc( i18n.productHoursEmptyTitle || 'No product hours yet' ) + '</strong><p>' + esc( body ) + '</p>';
	}

	function esc( s ) {
		return String( null == s ? '' : s )
			.replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' ).replace( /"/g, '&quot;' );
	}

	function hubUrl( layer, id ) {
		var url = new URL( boot.pageUrl || window.location.href, window.location.origin );
		url.searchParams.set( 'layer', layer );
		if ( id && 'global' !== layer ) url.searchParams.set( 'id', String( id ) );
		else url.searchParams.delete( 'id' );
		url.searchParams.delete( 'rule' );
		return url.pathname + url.search;
	}

	function isPlainClick( e ) {
		return e && 0 === e.button && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey;
	}

	function markDirty() {
		state.dirty = true;
	}

	function confirmLeave() {
		return !state.saving && ( !state.dirty || window.confirm( i18n.leaveDirty || 'You have unsaved changes. Leave this screen without saving?' ) );
	}

	function goTab( next, sideId ) {
		if ( !layerPresent( next ) ) next = DEFAULT_LAYER;
		if ( next === state.tab && !sideId ) return;
		if ( !confirmLeave() ) return;
		if ( state.dirty ) {
			state.rules = JSON.parse( JSON.stringify( state.baseline ) );
			state.dirty = false;
		}
		state.tab = next;
		state.railOpen = false;
		pinSideTop = true;
		if ( sideId ) {
			if ( 'location' === next ) state.locationId = sideId;
			if ( 'resource' === next ) state.resourceId = sideId;
			if ( 'product' === next ) state.productId = sideId;
			if ( 'staff' === next ) state.staffId = sideId;
		}
		syncHistory();
		paint();
	}

	function setRailOpen( open ) {
		state.railOpen = !!open;
		var hub = document.querySelector( '.hub-layout' );
		var toggle = document.getElementById( 'hub-rail-toggle' );
		if ( hub ) hub.classList.toggle( 'rail-open', state.railOpen );
		if ( toggle ) toggle.setAttribute( 'aria-expanded', state.railOpen ? 'true' : 'false' );
		if ( state.railOpen ) window.requestAnimationFrame( revealSideSelection );
	}

	function tzHtml() {
		var map = boot.tzHtml;
		if ( !map ) return '';
		// All layers show times in the viewer timezone (staff profile when it differs).
		return map.staff || map.site || '';
	}

	function syncRailToggle() {
		var label = document.getElementById( 'hub-rail-toggle-label' );
		if ( !label ) return;
		var c = copy[state.tab] || {};
		var ent = sideList() ? currentEntity() : null;
		var title = ent ? ( ( c.name || state.tab ) + ': ' + ent.name ) : ( c.name || state.tab );
		label.innerHTML = '<strong>' + esc( title ) + tzHtml() + '</strong>' +
			( c.blurb ? '<span class="meta">' + esc( c.blurb ) + '</span>' : '' );
	}

	function currentKindId() {
		if ( 'global' === state.tab ) return 0;
		if ( 'location' === state.tab ) return state.locationId;
		if ( 'resource' === state.tab ) return state.resourceId;
		if ( 'product' === state.tab ) return state.productId;
		if ( 'staff' === state.tab ) return state.staffId;
		return 0;
	}

	function deletedForTab() {
		var t = state.tab;
		if ( 'global' === t ) return state.deleted.global || [];
		var id = String( currentKindId() );
		return ( state.deleted[t] && state.deleted[t][id] ) || [];
	}

	function clearDeletedForTab() {
		var t = state.tab;
		if ( 'global' === t ) { state.deleted.global = []; return; }
		var id = String( currentKindId() );
		if ( state.deleted[t] ) state.deleted[t][id] = [];
	}

	function trackDeleted( rowId ) {
		var n = parseInt( rowId, 10 );
		if ( !n || 1000000000 <= n ) return;
		var t = state.tab;
		if ( 'global' === t ) {
			state.deleted.global.push( n );
			return;
		}
		var id = String( currentKindId() );
		if ( !state.deleted[t][id] ) state.deleted[t][id] = [];
		state.deleted[t][id].push( n );
	}

	function syncHistory() {
		if ( !boot.pageUrl || !window.history || !window.history.replaceState ) return;
		var url = new URL( boot.pageUrl, window.location.origin );
		url.searchParams.set( 'layer', state.tab );
		var id = currentKindId();
		if ( 'global' !== state.tab && id ) {
			url.searchParams.set( 'id', String( id ) );
		} else {
			url.searchParams.delete( 'id' );
		}
		window.history.replaceState( {}, '', url.pathname + url.search );
	}

	function syncEditorFieldsFromDom() {
		var panel = document.querySelector( '.wca-availability-hub .panel.is-active, .wca-availability-hub' );
		var root = panel || document;
		var rows = rowsForTab();
		var byId = {};
		rows.forEach( function( r ) { byId[ String( r.id ) ] = r; } );
		root.querySelectorAll( 'tr[data-id]' ).forEach( function( tr ) {
			var row = byId[ String( tr.getAttribute( 'data-id' ) ) ];
			if ( !row || 'google' === row.source ) return;
			tr.querySelectorAll( '[data-f]' ).forEach( function( el ) {
				var field = el.getAttribute( 'data-f' );
				if ( !field ) return;
				row[field] = el.value;
			} );
			nudgeRange( row, 'from' );
		} );
	}

	function saveChanges() {
		if ( !canEditTab() || !state.dirty || state.saving ) return;
		state.saving = true;
		refreshFoot();
		// Datepicker can update the input without syncing JS state; read DOM before serialize.
		syncEditorFieldsFromDom();
		var send = function( again ) {
			var rows = rowsForTab().filter( function( r ) { return 'google' !== r.source; } );
			var noticeEl = document.querySelector( '.wca-product-config-notice[data-product-id]' );
			var payload = {
				action: 'wc_appointments_availability_hub_save',
				security: boot.nonce,
				kind: state.tab,
				kind_id: currentKindId(),
				rules: JSON.stringify( rows ),
				deleted: deletedForTab().join( ',' ),
				config_notice_product_id: ( noticeEl && parseInt( noticeEl.getAttribute( 'data-product-id' ), 10 ) ) || ( 'product' === state.tab ? currentKindId() : 0 )
			};
			var body = Object.keys( payload ).map( function( k ) {
				return encodeURIComponent( k ) + '=' + encodeURIComponent( payload[k] );
			} ).join( '&' );
			return fetch( boot.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: body
			} ).then( function( r ) { return r.json(); } ).then( function( res ) {
				if ( !res || !res.success ) {
					if ( !again && res && res.data && res.data.nonce ) {
						boot.nonce = res.data.nonce;
						return send( true );
					}
					throw new Error( ( res && res.data && res.data.message ) || ( i18n.saveFailed || 'Could not save changes.' ) );
				}
				if ( res.data && res.data.rules ) {
					if ( 'global' === state.tab ) {
						state.rules.global = res.data.rules;
					} else {
						state.rules[state.tab][String( currentKindId() )] = res.data.rules;
					}
				}
				if ( res.data && res.data.clearConfigNotice ) {
					document.querySelectorAll( '.wca-product-config-notice' ).forEach( function( n ) { n.remove(); } );
				}
				clearDeletedForTab();
				state.baseline = JSON.parse( JSON.stringify( state.rules ) );
				state.dirty = false;
				showToast( i18n.saved || 'Changes saved' );
			} );
		};
		send( false ).catch( function( err ) {
			showToast( err.message || ( i18n.saveFailed || 'Could not save changes.' ) );
		} ).finally( function() {
			state.saving = false;
			paint();
		} );
	}

	function discardChanges() {
		if ( !state.dirty ) return;
		if ( !window.confirm( i18n.discardConfirm || 'Discard unsaved changes?' ) ) return;
		state.rules = JSON.parse( JSON.stringify( state.baseline ) );
		state.dirty = false;
		showToast( i18n.discarded || 'Changes discarded' );
		paint();
	}

	function showToast( msg ) {
		var t = document.getElementById( 'toast' );
		if ( !t ) {
			t = document.createElement( 'div' );
			t.id = 'toast';
			t.className = 'toast';
			t.setAttribute( 'role', 'status' );
			t.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( t );
		}
		t.textContent = msg;
		t.classList.add( 'show' );
		window.clearTimeout( showToast._timer );
		showToast._timer = window.setTimeout( function() { t.classList.remove( 'show' ); }, 2200 );
	}

	function footHtml() {
		if ( !canEditTab() ) {
			return '<div class="editor-foot is-readonly"><span class="status">' +
				esc( i18n.viewOnly || 'View only. You can edit your own hours.' ) + '</span></div>';
		}
		var canAct = state.dirty && !state.saving;
		var status = state.saving
			? ( i18n.saving || 'Saving…' )
			: ( canAct ? ( i18n.unsaved || 'Unsaved changes' ) : ( i18n.allSaved || 'All changes saved' ) );
		return '<div class="editor-foot">' +
			'<span class="status' + ( canAct ? ' dirty' : '' ) + '">' + esc( status ) + '</span>' +
			'<button type="button" class="btn" data-discard' + ( canAct ? '' : ' disabled' ) + '>' + esc( i18n.discard || 'Discard' ) + '</button>' +
			'<button type="button" class="btn btn-primary' + ( state.saving ? ' is-busy' : '' ) + '" data-save' +
				( canAct ? '' : ' disabled' ) +
				' aria-busy="' + ( state.saving ? 'true' : 'false' ) + '"' +
				' aria-label="' + esc( i18n.saveChanges || 'Save changes' ) + '">' +
			esc( i18n.save || 'Save' ) + '</button></div>';
	}

	function bindEdgeChrome() {
		var foot = document.querySelector( '.editor-foot' );
		var shell = document.querySelector( '#hub-results:not([hidden]), #hub-entities:not([hidden])' );
		var list = shell && shell.querySelector( '.hub-entities-scroll' );
		var syncFoot = function() {
			if ( !foot ) return;
			foot.classList.toggle( 'is-stuck', Math.ceil( foot.getBoundingClientRect().bottom ) >= window.innerHeight - 12 );
		};
		var syncNav = function() {
			if ( !shell || !list ) return;
			shell.classList.toggle( 'is-scrolled', list.scrollTop > 0 );
			shell.classList.toggle( 'is-overflow-bottom', list.scrollHeight - list.clientHeight - list.scrollTop > 2 );
		};
		if ( bindEdgeChrome._foot ) {
			window.removeEventListener( 'scroll', bindEdgeChrome._foot, true );
			window.removeEventListener( 'resize', bindEdgeChrome._foot );
		}
		bindEdgeChrome._foot = syncFoot;
		window.addEventListener( 'scroll', syncFoot, true );
		window.addEventListener( 'resize', syncFoot );
		if ( list ) list.addEventListener( 'scroll', syncNav, { passive: true } );
		syncFoot();
		syncNav();
		revealSideSelection();
	}

	function revealSideSelection() {
		if ( !pinSideTop ) return;
		pinSideTop = false;
		var list = document.querySelector( '#hub-results:not([hidden]) .hub-entities-scroll, #hub-entities:not([hidden]) .hub-entities-scroll' );
		var el = list && list.clientHeight && list.querySelector( '[data-go-layer][aria-current="true"]' );
		if ( el ) list.scrollTop += el.getBoundingClientRect().top - list.getBoundingClientRect().top;
	}

	function typesFor( tab ) {
		var list = ( 'location' === tab || 'resource' === tab ) ? TYPES_PLACE : TYPES_FULL;
		if ( 'staff' !== tab || !STAFF_ALLOWED ) return list;
		return list.filter( function( p ) {
			var type = p[0];
			if ( /^time:[1-7]$/.test( type ) ) return -1 !== STAFF_ALLOWED.indexOf( 'time' );
			return -1 !== STAFF_ALLOWED.indexOf( type );
		} );
	}

	function isTimeType( type ) {
		return 'time' === type || 'time:range' === type || /^time:[1-7]$/.test( type );
	}

	/** Recurring week patterns used for the At a glance strip only. */
	function isWeekPatternType( type ) {
		return isTimeType( type ) || 'days' === type;
	}

	/** Open hours table: any appointable rule (classic types). Closed & busy: closed + synced. */
	function isHoursRow( row ) {
		if ( 'google' === row.source ) return false;
		return 'yes' === row.available;
	}

	function isDailyProduct() {
		if ( 'product' !== state.tab ) return false;
		var p = entities.products.find( function( x ) { return x.id === state.productId; } );
		return !!( p && 'day' === p.duration );
	}

	function needsDateBounds( type ) {
		return 'custom:daterange' === type || 'time:range' === type;
	}

	function rangeStaticText( row ) {
		if ( row.range_text ) return row.range_text;
		if ( needsDateBounds( row.type ) ) {
			return [row.from_date, row.from].filter( Boolean ).join( ' ' ) + ' - ' + [row.to_date, row.to].filter( Boolean ).join( ' ' );
		}
		if ( 'custom' === row.type ) {
			return ( row.from || row.from_date || '' ) + ' - ' + ( row.to || row.to_date || '' );
		}
		if ( 'days' === row.type ) {
			return ( DAY_SHORT[row.from] || row.from ) + ' - ' + ( DAY_SHORT[row.to] || row.to );
		}
		return ( row.from || '' ) + ' - ' + ( row.to || '' );
	}

	function selectOptions( pairs, selected ) {
		return pairs.map( function( p ) {
			return '<option value="' + esc( p[0] ) + '"' + ( String( p[0] ) === String( selected ) ? ' selected' : '' ) + '>' + esc( p[1] ) + '</option>';
		} ).join( '' );
	}

	function dayOptions( selected ) {
		var order = weekOrder();
		return selectOptions( order.map( function( k ) { return [k, DAY_SHORT[k] || k]; } ), selected );
	}

	function monthOptions( selected ) {
		var months = boot.months || [
			['1', 'January'], ['2', 'February'], ['3', 'March'], ['4', 'April'],
			['5', 'May'], ['6', 'June'], ['7', 'July'], ['8', 'August'],
			['9', 'September'], ['10', 'October'], ['11', 'November'], ['12', 'December']
		];
		return selectOptions( months, selected );
	}

	function weekOptions( selected ) {
		var opts = [];
		for ( var w = 1; 52 >= w; w++ ) opts.push( [String( w ), String( w )] );
		return selectOptions( opts, selected );
	}

	function ensureDateBounds( row ) {
		if ( !needsDateBounds( row.type ) ) return;
		var today = new Date();
		var ymd = today.getFullYear() + '-' + String( today.getMonth() + 1 ).padStart( 2, '0' ) + '-' + String( today.getDate() ).padStart( 2, '0' );
		if ( !row.from_date ) row.from_date = ymd;
		if ( !row.to_date ) row.to_date = ymd;
		if ( !row.from || -1 === String( row.from ).indexOf( ':' ) ) row.from = SUGGEST_FROM;
		if ( !row.to || -1 === String( row.to ).indexOf( ':' ) ) row.to = SUGGEST_TO;
		row.from = String( row.from ).slice( 0, 5 );
		row.to = String( row.to ).slice( 0, 5 );
	}

	function hmMin( s ) {
		var m = String( s || '' ).match( /^(\d{1,2}):(\d{2})/ );
		return m ? ( +m[1] ) * 60 + ( +m[2] ) : -1;
	}

	/** Copy empty opposite; bump end when start moves past it (overnight times left alone). */
	function nudgeRange( row, field ) {
		if ( row.from && !row.to ) row.to = row.from;
		else if ( row.to && !row.from ) row.from = row.to;
		if ( needsDateBounds( row.type ) ) {
			if ( row.from_date && !row.to_date ) row.to_date = row.from_date;
			else if ( row.to_date && !row.from_date ) row.from_date = row.to_date;
		}
		if ( 'from' !== field && 'from_date' !== field ) return;
		if ( 'custom' === row.type && row.from && row.to && String( row.from ) > String( row.to ) ) {
			row.to = row.from;
		}
		if ( needsDateBounds( row.type ) && row.from_date && row.to_date && row.from_date > row.to_date ) {
			row.to_date = row.from_date;
		}
	}

	function rangeInputsHtml( row ) {
		var type = row.type;
		var date = function( field, value, label ) {
			return '<input type="text" class="date-picker" data-f="' + field + '" value="' + esc( value || '' ) + '" placeholder="yyyy-mm-dd" autocomplete="off" aria-label="' + esc( label ) + '">';
		};
		var time = function( field, value, label ) {
			return '<input type="time" data-f="' + field + '" value="' + esc( String( value || '' ).slice( 0, 5 ) ) + '" step="60" autocomplete="off" aria-label="' + esc( label ) + '">' +
				( 'to' !== field ? '' : '<span class="range-hint"' + ( 0 <= hmMin( row.from ) && hmMin( row.from ) >= hmMin( row.to ) ? '' : ' hidden' ) + '>' + esc( i18n.endsNextDay || 'Ends the next day' ) + '</span>' );
		};
		var pair = function( a, b ) {
			return '<div class="range range--pair">' + a + '<span class="dash">-</span>' + b + '</div>';
		};
		var unitTo = function( selectHtml, label ) {
			var a = parseInt( row.from, 10 ), b = parseInt( row.to, 10 );
			return '<div class="to_time">' + selectHtml +
				'<span class="range-hint"' + ( a && b && a > b ? '' : ' hidden' ) + '>' + esc( label ) + '</span></div>';
		};
		var html;
		if ( 'custom' === type ) {
			html = pair(
				'<div class="appointments-datetime-select-from"><div class="from_date">' + date( 'from', row.from || row.from_date, i18n.fromDate || 'From date' ) + '</div></div>',
				'<div class="appointments-datetime-select-to"><div class="to_date">' + date( 'to', row.to || row.to_date, i18n.toDate || 'To date' ) + '</div></div>'
			);
		} else if ( needsDateBounds( type ) ) {
			ensureDateBounds( row );
			html = '<div class="range range--pair range--dt">' +
				'<div class="appointments-datetime-select-from appointments-datetime-select-both">' +
				'<div class="from_date">' + date( 'from_date', row.from_date, i18n.fromDate || 'From date' ) + '</div>' +
				'<div class="from_time">' + time( 'from', row.from, i18n.fromTime || 'From time' ) + '</div>' +
				'</div><span class="dash">-</span>' +
				'<div class="appointments-datetime-select-to appointments-datetime-select-both">' +
				'<div class="to_date">' + date( 'to_date', row.to_date, i18n.toDate || 'To date' ) + '</div>' +
				'<div class="to_time">' + time( 'to', row.to, i18n.toTime || 'To time' ) + '</div>' +
				'</div></div>';
		} else if ( 'days' === type ) {
			html = pair(
				'<select data-f="from" class="day-of-week-picker" aria-label="' + esc( i18n.fromDay || 'From day' ) + '">' + dayOptions( row.from ) + '</select>',
				unitTo( '<select data-f="to" class="day-of-week-picker" aria-label="' + esc( i18n.toDay || 'To day' ) + '">' + dayOptions( row.to ) + '</select>', i18n.endsNextWeek || 'Ends the next week' )
			);
		} else if ( 'months' === type ) {
			html = pair(
				'<select data-f="from" class="month-picker" aria-label="' + esc( i18n.fromMonth || 'From month' ) + '">' + monthOptions( row.from ) + '</select>',
				unitTo( '<select data-f="to" class="month-picker" aria-label="' + esc( i18n.toMonth || 'To month' ) + '">' + monthOptions( row.to ) + '</select>', i18n.endsNextYear || 'Ends the next year' )
			);
		} else if ( 'weeks' === type ) {
			html = pair(
				'<select data-f="from" class="week-picker" aria-label="' + esc( i18n.fromWeek || 'From week' ) + '">' + weekOptions( row.from ) + '</select>',
				unitTo( '<select data-f="to" class="week-picker" aria-label="' + esc( i18n.toWeek || 'To week' ) + '">' + weekOptions( row.to ) + '</select>', i18n.endsNextYear || 'Ends the next year' )
			);
		} else {
			html = pair(
				'<div class="from_time">' + time( 'from', row.from, i18n.fromTime || 'From time' ) + '</div>',
				'<div class="to_time">' + time( 'to', row.to, i18n.toTime || 'To time' ) + '</div>'
			);
		}
		return html;
	}

	function initRangePickers( root ) {
		if ( !window.jQuery || !jQuery.fn.datepicker ) {
			return;
		}
		jQuery( root || document ).find( '.date-picker' ).each( function() {
			var $el = jQuery( this );
			if ( $el.hasClass( 'hasDatepicker' ) ) {
				$el.datepicker( 'destroy' );
			}
			$el.datepicker( {
				dateFormat: 'yy-mm-dd',
				numberOfMonths: 1,
				showOtherMonths: true,
				changeMonth: true,
				showButtonPanel: true,
				showOn: 'button',
				firstDay: START_OF_WEEK,
				buttonText: '\u2637',
				onSelect: function( dateText ) {
					this.value = dateText;
					// Native listeners on [data-f] must see the new value (jQuery trigger is not enough).
					this.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				}
			} );
		} );
	}

	function typeOptions( list, selected ) {
		var html = '';
		var inTime = false;
		list.forEach( function( p ) {
			var time = isTimeType( p[0] );
			if ( time && !inTime ) {
				html += '<optgroup label="' + esc( i18n.timeRangesGroup || 'Time ranges' ) + '">';
				inTime = true;
			} else if ( !time && inTime ) {
				html += '</optgroup>';
				inTime = false;
			}
			html += '<option value="' + esc( p[0] ) + '"' + ( p[0] === selected ? ' selected' : '' ) + '>' + esc( p[1] ) + '</option>';
		} );
		if ( inTime ) html += '</optgroup>';
		return html;
	}

	function typeName( row ) {
		if ( 'google' === row.source ) return row.recurring ? ( i18n.googleRecurring || 'Google Recurring Event' ) : ( i18n.googleEvent || 'Google Event' );
		return TYPE_LABEL[row.type] || row.type;
	}

	function rowsForTab() {
		var t = state.tab;
		if ( 'global' === t ) return state.rules.global;
		if ( 'location' === t ) return state.rules.location[state.locationId] || ( state.rules.location[state.locationId] = [] );
		if ( 'resource' === t ) return state.rules.resource[state.resourceId] || ( state.rules.resource[state.resourceId] = [] );
		if ( 'product' === t ) return state.rules.product[state.productId] || ( state.rules.product[state.productId] = [] );
		if ( 'staff' === t ) return state.rules.staff[state.staffId] || ( state.rules.staff[state.staffId] = [] );
		return [];
	}

	function count( layer ) {
		if ( 'global' === layer ) return state.rules.global.length;
		var bag = state.rules[layer] || {};
		return Object.keys( bag ).reduce( function( n, k ) { return n + bag[k].length; }, 0 );
	}

	function entityCount( layer, id ) {
		var bag = state.rules[layer];
		return ( bag[id] || [] ).length;
	}

	function sideId() {
		return ( { location: state.locationId, resource: state.resourceId, product: state.productId, staff: state.staffId } )[state.tab];
	}

	function setSideId( id ) {
		if ( 'location' === state.tab ) state.locationId = id;
		if ( 'resource' === state.tab ) state.resourceId = id;
		if ( 'product' === state.tab ) state.productId = id;
		if ( 'staff' === state.tab ) state.staffId = id;
	}

	function sideList() {
		var key = copy[state.tab] && copy[state.tab].side;
		return key ? entities[key] : null;
	}

	function badgeHtml( item ) {
		return item && item.badge ? '<span class="pill busy">' + esc( item.badge ) + '</span>' : '';
	}

	function ensureSideSelection() {
		var list = sideList();
		if ( !list || !list.length ) return;
		if ( !list.some( function( i ) { return i.id === sideId(); } ) ) {
			setSideId( list[0].id );
		}
	}

	function currentEntity() {
		var list = sideList();
		if ( !list ) return null;
		return list.find( function( i ) { return i.id === sideId(); } ) || list[0];
	}

	/** Other layers that contribute rules (skip bare connections with n=0). */
	function affectingHtml() {
		if ( 'global' === state.tab ) return '';
		var chips = [];
		var seen = {};
		function add( layer, id, label ) {
			if ( !layerPresent( layer ) || seen[layer + ':' + ( id || '' )] ) return;
			var n = id ? entityCount( layer, id ) : count( layer );
			if ( !n ) return;
			seen[layer + ':' + ( id || '' )] = true;
			var tip = ( i18n.alsoAffectingTip || '%s rules also apply to this schedule' ).replace( '%s', label );
			chips.push( '<a class="affecting-chip" href="' + esc( hubUrl( layer, id ) ) + '" data-go-layer="' + esc( layer ) + '"' +
				( id ? ' data-go-id="' + esc( id ) + '"' : '' ) + ' title="' + esc( tip ) + '">' + esc( label ) + '<span class="rc">' + n + '</span></a>' );
		}
		function addNamed( bag, layer, id ) {
			var item = ( entities[bag] || [] ).find( function( i ) { return String( i.id ) === String( id ); } );
			if ( item ) add( layer, id, item.name );
		}
		add( 'global', '', i18n.layerGlobal || 'General' );
		var ent = currentEntity();
		if ( 'product' === state.tab && ent ) {
			( ent.staffIds || [] ).forEach( function( id ) { addNamed( 'staff', 'staff', id ); } );
			( ent.locationIds || [] ).forEach( function( id ) { addNamed( 'locations', 'location', id ); } );
			( ent.resourceIds || [] ).forEach( function( id ) { addNamed( 'resources', 'resource', id ); } );
		} else if ( 'location' === state.tab ) {
			( entities.resources || [] ).forEach( function( r ) {
				if ( String( r.location || '' ) === String( sideId() || '' ) ) addNamed( 'resources', 'resource', r.id );
			} );
		} else if ( 'resource' === state.tab && ent && ent.location ) {
			addNamed( 'locations', 'location', ent.location );
		}
		if ( !chips.length ) return '';
		return '<div class="affecting" aria-label="' + esc( i18n.alsoAffecting || 'Other rules that apply' ) + '">' +
			chips.slice( 0, 12 ).join( '' ) +
			( chips.length > 12 ? '<span class="affecting-more">+' + ( chips.length - 12 ) + '</span>' : '' ) +
			'</div>';
	}

	function weekOrder() {
		/* WP 0=Sun-6=Sat -> availability keys 1=Mon-7=Sun, rotated to start_of_week. */
		var startKey = 0 === START_OF_WEEK ? 7 : START_OF_WEEK;
		var order = [];
		for ( var i = 0; 7 > i; i++ ) {
			order.push( String( ( ( startKey - 1 + i ) % 7 ) + 1 ) );
		}
		return order;
	}

	/** Week glance: shared `admin-availability-week.js` (same strip as product Availability tab). */
	function weekPreview( rows, layer ) {
		if ( !window.wcaAvailabilityWeek || !window.wcaAvailabilityWeek.weekHtml ) return '';
		var layerName = layer || 'global';
		var locId = 'resource' === layerName && layerPresent( 'location' ) && ( currentEntity() || {} ).location;
		return window.wcaAvailabilityWeek.weekHtml( {
			rows: rows,
			layer: layerName,
			globalRows: state.rules.global || [],
			locationRows: locId ? ( state.rules.location[ locId ] || [] ) : [],
			daily: isDailyProduct(),
			dayShort: DAY_SHORT,
			startOfWeek: START_OF_WEEK,
			i18n: i18n
		} );
	}

	function refreshFoot() {
		var old = document.querySelector( '.editor-foot' );
		if ( !old ) return;
		var stuck = old.classList.contains( 'is-stuck' );
		old.outerHTML = footHtml();
		var foot = document.querySelector( '.editor-foot' );
		if ( !foot ) return;
		if ( stuck ) foot.classList.add( 'is-stuck' );
		foot.querySelector( '[data-save]' ).addEventListener( 'click', saveChanges );
		foot.querySelector( '[data-discard]' ).addEventListener( 'click', discardChanges );
	}

	function glanceBlockHtml( weekHtml ) {
		var affect = affectingHtml();
		if ( !weekHtml && !affect ) return '';
		return '<div class="glance">' +
			( weekHtml ? '<p class="glance-label">' + esc( i18n.weekGlance || 'Week at a glance' ) + '</p>' : '' ) +
			affect + ( weekHtml || '' ) + '</div>';
	}

	/** Update Week at a glance from in-memory rows without rebuilding inputs (keeps focus). */
	function refreshGlance() {
		var intro = document.querySelector( '.editor-intro' );
		if ( !intro ) return;
		var next = glanceBlockHtml( weekPreview( rowsForTab(), state.tab ) );
		var glance = intro.querySelector( '.glance' );
		if ( glance ) glance.outerHTML = next;
		else if ( next ) intro.insertAdjacentHTML( 'beforeend', next );
	}

	function bindEditor( tr, row ) {
		if ( 'google' === row.source ) return;
		tr.querySelectorAll( '[data-f]' ).forEach( function( el ) {
			el.addEventListener( 'change', function() {
				var field = el.getAttribute( 'data-f' );
				row[field] = el.value;
				if ( 'available' === field && 'no' === el.value ) row.qty = '';
				if ( 'type' === field || 'available' === field ) {
					if ( 'type' === field ) {
						var today = new Date();
						var ymd = today.getFullYear() + '-' + String( today.getMonth() + 1 ).padStart( 2, '0' ) + '-' + String( today.getDate() ).padStart( 2, '0' );
						if ( needsDateBounds( row.type ) ) {
							row.from_date = ymd;
							row.to_date = ymd;
							row.from = SUGGEST_FROM;
							row.to = SUGGEST_TO;
						} else {
							delete row.from_date;
							delete row.to_date;
							if ( 'custom' === row.type ) {
								row.from = ymd;
								row.to = ymd;
							} else if ( 'days' === row.type || 'months' === row.type || 'weeks' === row.type ) {
								row.from = '1';
								row.to = 'days' === row.type ? '5' : '1';
							} else if ( isTimeType( row.type ) ) {
								row.from = SUGGEST_FROM;
								row.to = SUGGEST_TO;
							}
						}
					}
					markDirty();
					paint();
					return;
				}
				if ( -1 !== [ 'from', 'to', 'from_date', 'to_date' ].indexOf( field ) ) {
					nudgeRange( row, field );
					[ 'from', 'to', 'from_date', 'to_date' ].forEach( function( f ) {
						var inp = tr.querySelector( '[data-f="' + f + '"]' );
						// Skip the focused time control (Chromium commits after the first hour digit).
						if ( inp && inp !== el && null != row[f] ) inp.value = String( row[f] ).slice( 0, 'time' === inp.type ? 5 : 32 );
					} );
					markDirty();
					// paint() destroys <input type="time"> mid-digit; glance updates without rebuild.
					if ( 'time' === el.type ) {
						el._wcaDirtyTime = true;
						refreshFoot();
						refreshGlance();
						return;
					}
					paint();
					return;
				}
				markDirty();
				refreshFoot();
				refreshGlance();
			} );
			if ( 'INPUT' === el.tagName ) {
				if ( 'time' === el.type ) {
					el.addEventListener( 'blur', function() {
						if ( !el._wcaDirtyTime ) return;
						el._wcaDirtyTime = false;
						paint();
					} );
				}
				el.addEventListener( 'input', function() {
					if ( 'time' === el.type && !el.value ) return;
					var field = el.getAttribute( 'data-f' );
					row[field] = el.value;
					if ( 'time' === el.type ) {
						var hint = tr.querySelector( '.range-hint' );
						if ( hint ) hint.hidden = !( 0 <= hmMin( row.from ) && hmMin( row.from ) >= hmMin( row.to ) );
						el._wcaDirtyTime = true;
					}
					if ( !state.dirty ) {
						markDirty();
						refreshFoot();
					}
					// Live glance without full paint (keeps focus on priority / time).
					if ( 'priority' === field || 'time' === el.type || -1 !== [ 'from', 'to', 'from_date', 'to_date' ].indexOf( field ) ) {
						refreshGlance();
					}
				} );
			}
		} );
		var rm = tr.querySelector( '[data-rm]' );
		if ( rm ) {
			rm.addEventListener( 'click', function() {
				var rows = rowsForTab();
				var i = rows.findIndex( function( r ) { return r.id === row.id; } );
				if ( 0 <= i ) {
					trackDeleted( rows[i].id );
					rows.splice( i, 1 );
				}
				markDirty();
				paint();
			} );
		}
	}

	function editorRow( row, mode, canReorder ) {
		var t = state.tab;
		var sync = 'google' === row.source;
		var locked = sync || !canEditTab();
		var showTitle = !!state.showTitle;
		var statusLabel = i18n.status || 'Status';
		var titleLabel = i18n.title || 'Title';
		var typeLabel = i18n.type || 'Type';
		var rangeLabel = i18n.range || 'Range';
		var spotsLabel = i18n.spots || 'Capacity';
		var priorityLabel = i18n.priority || 'Priority';
		var syncBadge = sync ? '<span class="tag g">' + esc( i18n.synced || 'Synced' ) + '</span>' : '';
		var sortCell = canReorder
			? ( locked
				? '<td class="sort"></td>'
				: '<td class="sort" title="' + esc( i18n.dragReorder || 'Drag to reorder' ) + '"></td>' )
			: '';

		var titleCell = '';
		if ( showTitle ) {
			titleCell = locked
				? '<td class="col-title" data-label="' + esc( titleLabel ) + '"><span class="rule-head"><span class="rule-static rule-title">' + esc( row.title || ( sync ? ( i18n.busy || 'Busy' ) : '' ) ) + '</span>' + syncBadge + '</span></td>'
				: '<td class="col-title" data-label="' + esc( titleLabel ) + '"><input type="text" data-f="title" class="rule-title-input" placeholder="' + esc( i18n.titlePlaceholder || 'Optional title' ) + '" value="' + esc( row.title || '' ) + '"></td>';
		}

		var qty = '';
		if ( 'product' === t ) {
			qty = '<td class="col-spots" data-label="' + esc( spotsLabel ) + '">' + ( 'yes' === row.available
				? ( locked
					? '<span class="rule-static">' + esc( row.qty || '-' ) + '</span>'
					: '<input type="number" min="1" class="qty-input" placeholder="' + esc( i18n.spotsPlaceholder || 'Default' ) + '" title="' + esc( i18n.spotsInheritTitle || 'Leave blank to inherit from the product Capacity (or a higher layer).' ) + '" data-f="qty" value="' + esc( row.qty || '' ) + '">' )
				: '<span class="quiet" title="' + esc( i18n.spotsNaTitle || 'Capacity only applies to open rules.' ) + '" aria-label="' + esc( i18n.spotsNaTitle || 'Capacity only applies to open rules.' ) + '">-</span>' ) + '</td>';
		}

		var pri = state.showPriority
			? ( locked
				? '<td class="col-priority" data-label="' + esc( priorityLabel ) + '"><span class="rule-static">' + esc( null == row.priority || '' === row.priority ? 10 : row.priority ) + '</span></td>'
				: '<td class="col-priority" data-label="' + esc( priorityLabel ) + '"><input type="number" class="pri-input" data-f="priority" value="' + esc( null == row.priority || '' === row.priority ? 10 : row.priority ) + '"></td>' )
			: '';

		var typeList = typesFor( t );
		var typeInList = typeList.some( function( p ) { return p[0] === row.type; } );
		var typeSelect = typeInList
			? typeOptions( typeList, row.type )
			: null;

		if ( locked ) {
			var statusPill = sync
				? '<span class="pill busy">' + esc( i18n.busy || 'Busy' ) + '</span>'
				: ( 'yes' === row.available
					? '<span class="pill y">' + esc( i18n.open || 'Open' ) + '</span>'
					: '<span class="pill n">' + esc( i18n.closed || 'Closed' ) + '</span>' );
			var typeCell = showTitle
				? '<td class="col-type" data-label="' + esc( typeLabel ) + '"><span class="rule-static">' + esc( typeName( row ) ) + '</span></td>'
				: '<td class="col-type" data-label="' + esc( typeLabel ) + '"><span class="rule-head"><span class="rule-static">' + esc( typeName( row ) ) + '</span>' + syncBadge + '</span></td>';
			return '<tr class="' + ( sync ? 'sync-row' : 'view-row' ) + '" data-id="' + row.id + '">' +
				sortCell + titleCell + typeCell +
				'<td class="col-range" data-label="' + esc( rangeLabel ) + '"><span class="rule-static">' + esc( rangeStaticText( row ) ) + '</span></td>' + qty + pri +
				( state.showStatus ? '<td class="col-status" data-label="' + esc( statusLabel ) + '">' + statusPill + '</td>' : '' ) +
				'<td class="actions"><span class="screen-reader-text">' +
					esc( sync ? ( i18n.syncedFromGcal || 'Synced from Google Calendar' ) : ( i18n.viewOnly || 'View only' ) ) +
				'</span></td></tr>';
		}

		var availHidden = 'hours' === mode
			? '<input type="hidden" data-f="available" value="yes">'
			: '<input type="hidden" data-f="available" value="no">';
		var availCell = state.showStatus
			? ( 'hours' === mode
				? '<td class="col-status" data-label="' + esc( statusLabel ) + '"><span class="pill y">' + esc( i18n.open || 'Open' ) + '</span>' + availHidden + '</td>'
				: '<td class="col-status" data-label="' + esc( statusLabel ) + '"><span class="pill n">' + esc( i18n.closed || 'Closed' ) + '</span>' + availHidden + '</td>' )
			: '';

		var typeCellHtml = typeSelect
			? '<td class="col-type" data-label="' + esc( typeLabel ) + '"><select data-f="type">' + typeSelect + '</select></td>'
			: '<td class="col-type" data-label="' + esc( typeLabel ) + '"><span class="rule-static">' + esc( typeName( row ) ) + '</span><input type="hidden" data-f="type" value="' + esc( row.type ) + '"></td>';

		return '<tr data-id="' + row.id + '">' +
			sortCell +
			titleCell +
			typeCellHtml +
			'<td class="col-range" data-label="' + esc( rangeLabel ) + '">' + rangeInputsHtml( row ) + ( state.showStatus ? '' : availHidden ) + '</td>' +
			qty + pri + availCell +
			'<td class="actions"><button type="button" class="btn-rm" data-rm aria-label="' + esc( i18n.remove || 'Remove' ) + '" title="' + esc( i18n.remove || 'Remove' ) + '"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button></td></tr>';
	}

	function editorHead( mode, canReorder ) {
		var t = state.tab;
		var h = canReorder ? '<th class="sort" aria-label="' + esc( i18n.reorder || 'Reorder' ) + '"></th>' : '';
		if ( state.showTitle ) h += '<th class="col-title" title="' + esc( i18n.titleHint || 'Shown on the admin calendar.' ) + '">' + esc( i18n.title || 'Title' ) + '</th>';
		h += '<th class="col-type">' + esc( i18n.type || 'Type' ) + '</th><th class="col-range">' + esc( i18n.range || 'Range' ) + '</th>';
		if ( 'product' === t ) h += '<th class="col-spots" title="' + esc( i18n.spotsHint || 'Optional. Leave blank to inherit from the product (or a higher layer).' ) + '">' + esc( i18n.spots || 'Capacity' ) + '</th>';
		if ( state.showPriority ) h += '<th class="col-priority">' + esc( i18n.priority || 'Priority' ) + '</th>';
		if ( state.showStatus ) h += '<th class="col-status">' + esc( i18n.status || 'Status' ) + '</th>';
		h += '<th class="actions"><span class="screen-reader-text">' + esc( i18n.actions || 'Actions' ) + '</span></th>';
		return h;
	}

	function canReorderRows( rows ) {
		if ( !canEditTab() ) return false;
		var n = 0;
		for ( var i = 0; i < rows.length; i++ ) {
			if ( 'google' !== rows[i].source ) n++;
			if ( 2 <= n ) return true;
		}
		return false;
	}

	function tableBlock( rows, mode, emptyHtml, addLabel, addKind ) {
		var canReorder = canReorderRows( rows );
		var t = state.tab;
		var cols = 3 + ( canReorder ? 1 : 0 ) + ( state.showTitle ? 1 : 0 ) + ( 'product' === t ? 1 : 0 ) + ( state.showPriority ? 1 : 0 ) + ( state.showStatus ? 1 : 0 );
		var addBtn = addKind
			? '<button type="button" class="btn-add" data-add="' + addKind + '"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>' + esc( addLabel ) + '</button>'
			: '';
		if ( !rows.length ) {
			if ( !addKind ) return '<div class="empty">' + emptyHtml + '</div>';
			return '<div class="empty">' + emptyHtml +
				'<div class="empty-actions">' + addBtn + '</div></div>';
		}
		var foot = addKind
			? '<tfoot><tr><td colspan="' + cols + '">' +
				'<p class="foot-hint">' + esc( i18n.rulesExplanation || 'Rules further down the table will override those at the top.' ) + '</p>' +
				'<div class="empty-actions">' + addBtn + '</div></td></tr></tfoot>'
			: '';
		return '<div class="box"><table class="grid" data-mode="' + esc( mode ) + '"><thead><tr>' + editorHead( mode, canReorder ) + '</tr></thead>' +
			'<tbody>' + rows.map( function( r ) { return editorRow( r, mode, canReorder ); } ).join( '' ) + '</tbody>' +
			foot + '</table></div>';
	}

	function layerLabel( layer ) {
		return ( {
			global: i18n.layerGlobal || 'General',
			location: i18n.layerLocations || 'Locations',
			resource: i18n.layerResources || 'Resources',
			product: i18n.layerProducts || 'Products',
			staff: i18n.layerStaff || 'Staff'
		} )[layer] || layer;
	}
	function entityLinkHtml( layer, item, current ) {
		var n = 'global' === layer ? count( 'global' ) : entityCount( layer, item.id );
		return '<a href="' + esc( hubUrl( layer, item.id ) ) + '" data-go-layer="' + esc( layer ) + '"' +
			( item.id ? ' data-go-id="' + esc( item.id ) + '"' : '' ) +
			( current ? ' aria-current="true"' : '' ) + '>' +
			'<span class="nm">' + esc( item.name ) + '</span>' +
			( n ? '<span class="rc">' + n + '</span>' : '' ) +
			( item.meta || item.badge ? '<span class="m">' + badgeHtml( item ) + esc( item.meta || '' ) + '</span>' : '' ) +
			'</a>';
	}

	function isCurrentSide( layer, item ) {
		return layer === state.tab && ( 'global' === layer || String( item.id ) === String( sideId() ) );
	}

	function markCurrentSide( layer, id ) {
		document.querySelectorAll( '#hub-results:not([hidden]) [data-go-layer], #hub-entities:not([hidden]) [data-go-layer]' ).forEach( function( a ) {
			var on = a.getAttribute( 'data-go-layer' ) === layer && ( a.getAttribute( 'data-go-id' ) || '' ) === String( id || '' );
			if ( on ) a.setAttribute( 'aria-current', 'true' );
			else a.removeAttribute( 'aria-current' );
		} );
	}

	/** Strip accents and map smart quotes so typed ASCII/NFC matches stored titles. */
	function foldSearch( s ) {
		return String( s || '' )
			.normalize( 'NFD' )
			.replace( /[\u0300-\u036f]/g, '' )
			.replace( /[\u2018\u2019\u201A\u201B]/g, "'" )
			.replace( /[\u201C\u201D\u201E\u201F]/g, '"' )
			.toLowerCase();
	}

	/** Browse entities under the active layer, or global search results when querying. */
	function paintEntities() {
		var browse = document.getElementById( 'hub-entities' );
		var results = document.getElementById( 'hub-results' );
		var layers = document.getElementById( 'hub-layers' );
		var q = foldSearch( ( state.sideQuery || '' ).trim() );
		if ( !browse ) return;

		if ( q ) {
			if ( layers ) layers.hidden = true;
			browse.hidden = true;
			browse.innerHTML = '';
			if ( !results ) return;
			var filter = state.searchLayer || '';
			var chips = '<div class="hub-search-filters"><button type="button" class="hub-search-filter' +
				( filter ? '' : ' is-on' ) + '" data-search-layer="">' + esc( i18n.searchAll || 'All' ) + '</button>';
			LAYER_ORDER.forEach( function( layer ) {
				if ( !layerPresent( layer ) ) return;
				chips += '<button type="button" class="hub-search-filter' + ( filter === layer ? ' is-on' : '' ) +
					'" data-search-layer="' + layer + '">' + esc( layerLabel( layer ) ) + '</button>';
			} );
			chips += '</div>';
			var html = '';
			var any = false;
			LAYER_ORDER.forEach( function( layer ) {
				if ( !layerPresent( layer ) || ( filter && filter !== layer ) ) return;
				var rows = 'global' === layer
					? ( -1 !== foldSearch( layerLabel( 'global' ) ).indexOf( q ) ? [ { id: '', name: layerLabel( 'global' ) } ] : [] )
					: ( entities[LAYER_BAG[layer]] || [] ).filter( function( item ) {
						return -1 !== foldSearch( item.name + ' ' + ( item.meta || '' ) + ' ' + ( item.badge || '' ) ).indexOf( q );
					} );
				if ( !rows.length ) return;
				any = true;
				if ( !filter ) {
					html += '<p class="hub-search-group">' + esc( layerLabel( layer ) ) +
						'<span class="n">' + rows.length + '</span></p>';
				}
				html += '<div class="hub-entity-list" role="list">' +
					rows.map( function( item ) { return entityLinkHtml( layer, item, isCurrentSide( layer, item ) ); } ).join( '' ) +
					'</div>';
			} );
			results.hidden = false;
			results.innerHTML = chips + '<div class="hub-entities-scroll">' +
				( any ? html : '<p class="hub-empty">' + esc( i18n.noMatches || 'No matches' ) + '</p>' ) + '</div>';
			return;
		}

		if ( results ) { results.hidden = true; results.innerHTML = ''; }
		if ( layers ) layers.hidden = false;
		var t = state.tab;
		var side = sideList();
		if ( !side ) {
			browse.hidden = true;
			browse.innerHTML = '';
			return;
		}
		ensureSideSelection();
		browse.hidden = false;
		browse.innerHTML = '<div class="hub-entities-scroll"><div class="hub-entity-list" role="list">' +
			side.map( function( item ) { return entityLinkHtml( t, item, isCurrentSide( t, item ) ); } ).join( '' ) +
			'</div></div>';
		var activeLayer = document.querySelector( '.hub-layer[aria-current="page"]' );
		if ( activeLayer && activeLayer.parentNode ) {
			activeLayer.parentNode.insertBefore( browse, activeLayer.nextSibling );
		}
	}

	function paintEditor() {
		var t = state.tab;
		var c = copy[t];
		var panel = document.querySelector( '[data-panel="' + t + '"]' );
		ensureSideSelection();
		var all = rowsForTab();
		var ent = currentEntity();

		var hours = all.filter( isHoursRow );
		var excepManual = all.filter( function( r ) { return !isHoursRow( r ) && 'google' !== r.source; } );
		var synced = all.filter( function( r ) { return 'google' === r.source; } );

		var heading = ent ? esc( ent.name ) : esc( c.name );
		var title = '<h2>' + heading + tzHtml() + ' ' + badgeHtml( ent ) +
			( ent && ent.meta ? ' <span class="editor-meta">' + esc( ent.meta ) + '</span>' : '' ) +
			( ent && ent.editUrl
				? ' <a class="wca-hub-ext" href="' + esc( ent.editUrl ) + '" target="_blank" rel="noopener noreferrer">' +
					esc( i18n.editEntity || 'Edit' ) +
					'<span class="dashicons dashicons-external" aria-hidden="true"></span></a>'
				: '' ) +
			'</h2>';

		var hoursEmpty = 'product' === t
			? productHoursEmptyHtml()
			: '<strong>' + esc( i18n.emptyHoursTitle || 'No open hours yet' ) + '</strong><p>' + esc( c.emptyHours ) + '</p>';
		var excepEmpty = '<strong>' + esc( i18n.emptyExcepTitle || 'Nothing unavailable yet' ) + '</strong><p>' + esc( c.emptyExcep ) + '</p>';

		var weekHtml = weekPreview( all, t );
		var editable = canEditTab();
		var hoursAdd = editable && CAN_SET_APPOINTABLE ? 'hours' : null;
		var excepAdd = editable ? 'excep' : null;
		var hoursBody = tableBlock( hours, 'hours', hoursEmpty, i18n.addOpenHours || 'Add open hours', hoursAdd );
		var excepBody = tableBlock( excepManual, 'excep', excepEmpty, i18n.addClosedDate || 'Add unavailable time', excepAdd );
		var syncedBody = synced.length
			? '<div class="synced-stack">' +
				'<div class="block-h"><p class="glance-label">' + esc( i18n.syncedFromGcal || 'Synced from Google Calendar' ) + '</p>' + ( state.showStatus ? '' : '<span class="pill busy">' + esc( i18n.busy || 'Busy' ) + '</span>' ) + '</div>' +
				tableBlock( synced, 'excep' ) +
			'</div>'
			: '';

		panel.innerHTML =
			'<div class="editor-stack">' +
				'<div class="editor-intro">' +
					'<div class="editor-h">' +
						'<div>' + title + '<p class="why">' + ( 'global' !== t ? '<span class="pill optional">' + esc( i18n.optional || 'Optional' ) + '</span> ' : '' ) + esc( c.blurb ) +
							( ent && ent.restrictedStartNote ? ' ' + esc( ent.restrictedStartNote ) : '' ) + '</p></div>' +
					'</div>' +
					glanceBlockHtml( weekHtml ) +
				'</div>' +
				'<div class="block">' +
					'<div class="block-h"><h3>' + esc( i18n.openHours || 'Open hours' ) + '</h3>' + ( state.showStatus ? '' : '<span class="pill y">' + esc( i18n.open || 'Open' ) + '</span>' ) + '</div>' + hoursBody +
				'</div>' +
				'<div class="block">' +
					'<div class="block-h"><h3>' + esc( i18n.closedDates || 'Unavailable' ) + '</h3>' + ( state.showStatus ? '' : '<span class="pill n">' + esc( i18n.closed || 'Closed' ) + '</span>' ) + '</div>' + excepBody + syncedBody +
				'</div>' +
				footHtml() +
			'</div>';

		if ( editable ) {
			panel.querySelectorAll( 'tr[data-id]' ).forEach( function( tr ) {
				var row = all.find( function( r ) { return r.id === parseInt( tr.getAttribute( 'data-id' ), 10 ); } );
				if ( row ) bindEditor( tr, row );
			} );
			panel.querySelectorAll( '[data-add]' ).forEach( function( b ) {
				b.addEventListener( 'click', function() { addRule( b.getAttribute( 'data-add' ) ); } );
			} );
			var saveBtn = panel.querySelector( '[data-save]' );
			if ( saveBtn ) saveBtn.addEventListener( 'click', saveChanges );
			var discardBtn = panel.querySelector( '[data-discard]' );
			if ( discardBtn ) discardBtn.addEventListener( 'click', discardChanges );
			panel.querySelectorAll( 'table.grid tbody' ).forEach( bindSortable );
		}
		initRangePickers( panel );
		bindEdgeChrome();
		if ( pendingRuleFocus ) {
			var focusTr = document.querySelector( 'tr[data-id="' + pendingRuleFocus + '"]' );
			pendingRuleFocus = '';
			if ( focusTr ) {
				focusTr.scrollIntoView( { block: 'nearest' } );
				var focusQty = focusTr.querySelector( '[data-f="qty"]' );
				if ( focusQty ) focusQty.focus();
			}
		}
	}

	function bindSortable( tbody ) {
		tbody.addEventListener( 'pointerdown', function( e ) {
			var cell = e.target.closest && e.target.closest( 'td.sort' );
			if ( !cell || 0 !== e.button ) return;
			var drag = cell.closest( 'tr' );
			if ( !drag || drag.classList.contains( 'sync-row' ) || !tbody.contains( drag ) ) return;
			e.preventDefault();

			var rect = drag.getBoundingClientRect();
			var grabY = e.clientY - rect.top;
			var cells = drag.cells;
			var i;
			for ( i = 0; i < cells.length; i++ ) {
				cells[i].style.width = cells[i].getBoundingClientRect().width + 'px';
			}
			var ph = document.createElement( 'tr' );
			ph.className = 'wca-sort-ph';
			ph.innerHTML = '<td colspan="' + cells.length + '"></td>';
			ph.style.height = rect.height + 'px';
			tbody.insertBefore( ph, drag );
			drag.classList.add( 'dragging' );
			drag.style.cssText = 'width:' + rect.width + 'px;left:' + rect.left + 'px;top:' + rect.top + 'px';

			var ac = new AbortController();
			var sig = { signal: ac.signal };
			document.addEventListener( 'pointermove', function( ev ) {
				drag.style.top = ( ev.clientY - grabY ) + 'px';
				var el = document.elementFromPoint( ev.clientX, ev.clientY );
				var over = el && el.closest && el.closest( 'tr[data-id], tr.wca-sort-ph' );
				if ( !over || over === ph || !tbody.contains( over ) ) return;
				var before = ev.clientY < over.getBoundingClientRect().top + over.offsetHeight / 2;
				tbody.insertBefore( ph, before ? over : over.nextSibling );
			}, sig );
			document.addEventListener( 'pointerup', end, sig );
			document.addEventListener( 'pointercancel', end, sig );

			function end() {
				ac.abort();
				tbody.insertBefore( drag, ph );
				ph.remove();
				drag.classList.remove( 'dragging' );
				drag.removeAttribute( 'style' );
				for ( i = 0; i < cells.length; i++ ) cells[i].style.width = '';
				var map = {};
				var rows = rowsForTab();
				rows.forEach( function( r ) { map[ r.id ] = r; } );
				var ordered = Array.prototype.map.call( tbody.querySelectorAll( 'tr[data-id]' ), function( tr ) {
					return map[ parseInt( tr.getAttribute( 'data-id' ), 10 ) ];
				} ).filter( Boolean );
				if ( !ordered.length ) return;
				var inSet = {};
				ordered.forEach( function( r ) { inSet[ r.id ] = true; } );
				var qi = 0;
				var next = rows.map( function( r ) {
					if ( inSet[ r.id ] ) return ordered[ qi++ ];
					return r;
				} );
				if ( qi !== ordered.length ) return;
				rows.length = 0;
				Array.prototype.push.apply( rows, next );
				markDirty();
				refreshFoot();
			}
		} );
	}

	/** New Open after last Open (else before first Closed/Google). New Closed after last Closed (else after last Open), before Google. */
	function insertIndexForNewRule( rows, kind ) {
		var i, lastOpen = -1, lastClosed = -1, firstClosed = -1, firstGoogle = rows.length;
		for ( i = 0; i < rows.length; i++ ) {
			if ( 'google' === rows[ i ].source ) {
				if ( i < firstGoogle ) {
					firstGoogle = i;
				}
				continue;
			}
			if ( 'yes' === rows[ i ].available ) {
				lastOpen = i;
			} else {
				if ( 0 > firstClosed ) {
					firstClosed = i;
				}
				lastClosed = i;
			}
		}
		if ( 'hours' === kind ) {
			return 0 <= lastOpen ? lastOpen + 1 : ( 0 <= firstClosed ? firstClosed : firstGoogle );
		}
		return 0 <= lastClosed ? lastClosed + 1 : ( 0 <= lastOpen ? lastOpen + 1 : firstGoogle );
	}

	function addRule( kind ) {
		if ( 'hours' === kind && !CAN_SET_APPOINTABLE ) return;
		var t = state.tab;
		var today = new Date();
		var ymd = today.getFullYear() + '-' + String( today.getMonth() + 1 ).padStart( 2, '0' ) + '-' + String( today.getDate() ).padStart( 2, '0' );
		var row = {
			id: ( nid += 1, 1000000000 + nid ),
			type: 'excep' === kind ? 'custom' : 'time',
			from: 'excep' === kind ? ymd : SUGGEST_FROM,
			to: 'excep' === kind ? ymd : SUGGEST_TO,
			available: 'excep' === kind ? 'no' : 'yes',
			priority: 10,
			source: 'manual',
			title: ''
		};
		if ( 'product' === t ) row.qty = '';
		if ( 'product' === t && 'hours' === kind && isDailyProduct() ) {
			row.type = 'days';
			row.from = '1';
			row.to = '5';
		}
		var rows = rowsForTab();
		rows.splice( insertIndexForNewRule( rows, kind ), 0, row );
		markDirty();
		paint();
		var el = document.querySelector( 'tr[data-id="' + row.id + '"] [data-f="from"]' );
		if ( el ) el.focus();
	}

	function paint() {
		if ( !layerPresent( state.tab ) ) state.tab = DEFAULT_LAYER;
		syncLayerPresence();
		document.querySelectorAll( '.hub-layer' ).forEach( function( el ) {
			el.setAttribute( 'aria-current', el.dataset.tab === state.tab ? 'page' : 'false' );
		} );
		document.querySelectorAll( '[data-panel]' ).forEach( function( p ) {
			var on = p.getAttribute( 'data-panel' ) === state.tab;
			p.classList.toggle( 'active', on );
			p.hidden = !on;
			if ( !on ) p.innerHTML = '';
		} );
		document.querySelectorAll( '[data-count]' ).forEach( function( el ) {
			var n = count( el.getAttribute( 'data-count' ) );
			el.textContent = n ? String( n ) : '';
			el.setAttribute( 'data-empty', n ? '0' : '1' );
		} );
		paintEntities();
		paintEditor();
		setRailOpen( state.railOpen );
		syncRailToggle();
	}

	document.querySelectorAll( '.hub-layer' ).forEach( function( el ) {
		el.addEventListener( 'click', function( e ) {
			if ( !isPlainClick( e ) ) return;
			e.preventDefault();
			goTab( el.dataset.tab );
			el.blur(); /* mouse select: keep fill, drop focus ring (entities lose it via repaint) */
		} );
		el.addEventListener( 'keydown', function( e ) {
			var layers = visibleLayers();
			var i = layers.indexOf( el );
			if ( 0 > i ) return;
			var next = null;
			if ( 'ArrowDown' === e.key ) next = layers[( i + 1 ) % layers.length];
			if ( 'ArrowUp' === e.key ) next = layers[( i - 1 + layers.length ) % layers.length];
			if ( 'Home' === e.key ) next = layers[0];
			if ( 'End' === e.key ) next = layers[layers.length - 1];
			if ( !next ) return;
			e.preventDefault();
			next.focus();
			goTab( next.dataset.tab );
		} );
	} );

	var searchInput = document.getElementById( 'side-search' );
	if ( searchInput ) {
		searchInput.addEventListener( 'input', function() {
			state.sideQuery = searchInput.value;
			if ( !( state.sideQuery || '' ).trim() ) {
				state.searchLayer = '';
				pinSideTop = true;
			}
			paintEntities();
			bindEdgeChrome();
		} );
	}

	document.querySelector( '.wca-availability-hub' ).addEventListener( 'click', function( e ) {
		var el = e.target.closest( '[data-clear-search], [data-search-layer], [data-go-layer]' );
		if ( !el || !isPlainClick( e ) ) return;
		if ( el.hasAttribute( 'data-clear-search' ) ) {
			e.preventDefault();
			state.sideQuery = '';
			state.searchLayer = '';
			pinSideTop = true;
			if ( searchInput ) { searchInput.value = ''; searchInput.focus(); }
			paintEntities();
			bindEdgeChrome();
			return;
		}
		if ( el.hasAttribute( 'data-search-layer' ) ) {
			e.preventDefault();
			state.searchLayer = el.getAttribute( 'data-search-layer' ) || '';
			paintEntities();
			bindEdgeChrome();
			return;
		}
		e.preventDefault();
		var layer = el.getAttribute( 'data-go-layer' );
		var id = el.getAttribute( 'data-go-id' ) || '';
		if ( layer === state.tab ) {
			if ( id && id === String( sideId() || '' ) ) { setRailOpen( false ); return; }
			if ( id ) {
				setSideId( id );
				syncHistory();
				markCurrentSide( layer, id );
				paintEditor();
				setRailOpen( false );
				syncRailToggle();
				return;
			}
		}
		goTab( layer, id );
		el.blur();
	} );

	document.getElementById( 'hub-rail-toggle' ).addEventListener( 'click', function() {
		setRailOpen( !state.railOpen );
		if ( state.railOpen ) {
			window.setTimeout( function() {
				var searchFocus = document.getElementById( 'side-search' );
				if ( searchFocus ) searchFocus.focus();
			}, 0 );
		}
	} );

	document.addEventListener( 'keydown', function( e ) {
		if ( 'Escape' !== e.key || !state.railOpen ) return;
		setRailOpen( false );
	} );
	document.addEventListener( 'click', function( e ) {
		if ( !window.matchMedia( '(max-width: 782px)' ).matches || !state.railOpen ) return;
		var rail = document.getElementById( 'hub-rail' );
		if ( rail && !rail.contains( e.target ) ) setRailOpen( false );
	} );
	window.addEventListener( 'beforeunload', function( e ) {
		if ( !state.dirty ) return;
		e.preventDefault();
		e.returnValue = '';
	} );

	document.addEventListener( 'change', function( e ) {
		var input = e.target;
		if ( !input || !input.name || 0 !== String( input.name ).indexOf( 'wca_hub_show_' ) ) return;
		var pri = document.querySelector( 'input[name="wca_hub_show_priority"]' );
		var st = document.querySelector( 'input[name="wca_hub_show_status"]' );
		var ti = document.querySelector( 'input[name="wca_hub_show_title"]' );
		state.showPriority = !!( pri && pri.checked );
		state.showStatus = !!( st && st.checked );
		state.showTitle = !!( ti && ti.checked );
		paint();
		var body = 'action=wc_appointments_availability_hub_screen_option'
			+ '&security=' + encodeURIComponent( boot.nonce || '' )
			+ '&show_priority=' + ( state.showPriority ? '1' : '0' )
			+ '&show_status=' + ( state.showStatus ? '1' : '0' )
			+ '&show_title=' + ( state.showTitle ? '1' : '0' );
		fetch( boot.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body
		} ).catch( function() {} );
	} );

	syncHistory();
	paint();
} )();
