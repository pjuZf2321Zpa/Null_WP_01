/**
	Admin Appointments Calendar (React + FullCalendar)
	- Renders the admin calendar and wires appointments/rules modals
	- Integrates Server-Sent Events (SSE) for live updates
	- Gates non-SSE refetches to prevent duplicate event flashes on create

	============================================================================
	TIMEZONE ARCHITECTURE - CRITICAL FOR DEVELOPERS
	============================================================================

	This file uses UTC methods (getUTCHours, getUTCDate, etc.) INTENTIONALLY.

	WHY: FullCalendar expects ISO strings in UTC format. Our timestamps are stored
	as UTC Unix timestamps that SEMANTICALLY REPRESENT site timezone times.

	EXAMPLE:
	- Stored timestamp: 1705320000 (for site in Europe/Ljubljana, UTC+1)
	- Represents: 2024-01-15 14:00 Ljubljana time
	- When we call new Date(ts * 1000).getUTCHours() → 14 (correct!)
	- If we called getHours() → would vary by browser timezone (WRONG!)

	RULE FOR THIS FILE:
	✅ USE: getUTCHours(), getUTCDate(), getUTCMonth(), getUTCFullYear()
	❌ DO NOT USE: getHours(), getDate(), getMonth() for timestamp extraction

	This is the OPPOSITE of the admin panel JS which uses local methods.
	See docs/TIMEZONE_ARCHITECTURE.md for full explanation.

	DO NOT "FIX" THIS BY ADDING TIMEZONE CONVERSIONS - IT WILL BREAK THE CALENDAR!
	============================================================================
*/
( function() {
/* global wcAppointmentsReactCalendar, wp */
	'use strict';

	// Admin Calendar (React): integrates FullCalendar with WooCommerce Appointments
	// Handles i18n, REST fetching, availability rendering, and admin panel integration
	if ( !window.wcAppointmentsReactCalendar ) {
		return;
	}
	var h = wp.element.createElement;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var useLayoutEffect = wp.element.useLayoutEffect || useEffect;
	var useRef = wp.element.useRef;
	var i18n = ( window.wcAppointmentsReactCalendar && window.wcAppointmentsReactCalendar.i18n ) || {};
	var FALLBACK_MONTHS_FULL = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ];
	var FALLBACK_MONTHS_SHORT = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];
	var NARROW_MQ = '(max-width: 782px)';

	function isNarrowViewport() {
		return !!( window.matchMedia && window.matchMedia( NARROW_MQ ).matches );
	}

	/** Week/list on narrow: month + year. Day/month (and desktop) keep FullCalendar's title. */
	function resolveViewTitle( view ) {
		if ( !view ) {
			return '';
		}
		if ( isNarrowViewport() && ( 'timeGridWeek' === view.type || 'listWeek' === view.type ) && view.currentStart ) {
			var months = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.monthsFull ) || FALLBACK_MONTHS_FULL;
			return months[ view.currentStart.getMonth() ] + ' ' + view.currentStart.getFullYear();
		}
		return view.title || '';
	}

	// Compatibility-only hook surface. Primary implementation now lives in panel code.
	if ( !window.wcaModalHooks ) {
		window.wcaModalHooks = {
			addFilter: function() {},
			removeFilter: function() {},
			applyFilters: function( hook, value ) { return value; },
			hasFilters: function() { return false; },
			getContent: function() { return []; }
		};
	}

	// ---------------------------------------------------------------------------
	// TIME + CORE UTILITIES
	// ---------------------------------------------------------------------------
	function pad( n ) {
		return 10 > n ? '0' + n : String( n );
	}

	function t( key, fallback, count ) {
		var v = i18n && i18n[ key ];
		var msg = ( 'string' === typeof v && v ) ? v : ( fallback || key );
		if ( undefined !== count ) {
			msg = msg.replace( '%d', String( count ) );
		}
		return msg;
	}

	function escHtml( s ) {
		if ( !s ) { return ''; }
		return String( s ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' ).replace( /"/g, '&quot;' );
	}

	function wcaFinePointerHover() {
		return !!( window.matchMedia && window.matchMedia( '(hover: hover) and (pointer: fine)' ).matches );
	}

	// Body tip for overlapping bg rules (FC bg opacity mutes nested tips). M3 surface + edge clamp.
	// Desktop: follow pointer on hover. Touch: pin on tap (no modal); dismiss on outside tap.
	function bindBgRulePortalTip() {
		if ( window.__wcaBgRuleTipBound ) {
			return;
		}
		window.__wcaBgRuleTipBound = true;
		var tip = document.createElement( 'div' );
		tip.className = 'wca-bg-tooltip';
		tip.hidden = true;
		document.body.appendChild( tip );
		var pinned = false;

		function collectLines( clientX, clientY, fallbackEl ) {
			var seen = {};
			var lines = [];
			var stack = document.elementsFromPoint ? document.elementsFromPoint( clientX, clientY ) : ( fallbackEl ? [ fallbackEl ] : [] );
			for ( var i = 0; i < stack.length; i++ ) {
				var m = stack[ i ].__wcaBlockRule;
				if ( !m || !stack[ i ].classList.contains( 'wca-bg-has-tooltip' ) || seen[ m.id ] ) {
					continue;
				}
				seen[ m.id ] = 1;
				lines.push( m.html );
			}
			if ( !lines.length && fallbackEl && fallbackEl.__wcaBlockRule ) {
				lines.push( fallbackEl.__wcaBlockRule.html );
			}
			return lines;
		}

		function placeTip( clientX, clientY ) {
			var pad = 8;
			var g = 8;
			var tw = tip.offsetWidth;
			var th = tip.offsetHeight;
			var x = clientX + g;
			var y = clientY + g;
			if ( x + tw > window.innerWidth - pad ) {
				x = clientX - tw - g;
			}
			if ( y + th > window.innerHeight - pad ) {
				y = clientY - th - g;
			}
			tip.style.left = Math.max( pad, Math.min( x, window.innerWidth - tw - pad ) ) + 'px';
			tip.style.top = Math.max( pad, Math.min( y, window.innerHeight - th - pad ) ) + 'px';
		}

		function showTip( clientX, clientY, fallbackEl, pin ) {
			var lines = collectLines( clientX, clientY, fallbackEl );
			if ( !lines.length ) {
				if ( !pin ) {
					tip.hidden = true;
				}
				return false;
			}
			tip.innerHTML = lines.slice( 0, 4 ).join( '' ) + ( 4 < lines.length ? '<div class="wca-bg-tooltip__more">+' + ( lines.length - 4 ) + '</div>' : '' );
			tip.hidden = false;
			placeTip( clientX, clientY );
			pinned = !!pin;
			return true;
		}

		function hideTip() {
			pinned = false;
			tip.hidden = true;
		}

		window.__wcaBgRuleTipShow = function( clientX, clientY, fallbackEl, pin ) {
			return showTip( clientX, clientY, fallbackEl || null, !!pin );
		};
		window.__wcaBgRuleTipHide = hideTip;

		document.addEventListener( 'mousemove', function( ev ) {
			if ( pinned || !wcaFinePointerHover() ) {
				return;
			}
			var over = ev.target.closest && ev.target.closest( '.wca-bg-has-tooltip' );
			if ( !over ) {
				tip.hidden = true;
				return;
			}
			showTip( ev.clientX, ev.clientY, over, false );
		}, true );

		document.addEventListener( 'pointerdown', function( ev ) {
			if ( !pinned ) {
				return;
			}
			if ( tip.contains( ev.target ) ) {
				return;
			}
			if ( ev.target.closest && ev.target.closest( '.wca-bg-has-tooltip' ) ) {
				return;
			}
			hideTip();
		}, true );
	}

	function renderTimeGridDayHeader( arg ) {
		var d = arg.date;
		var locale = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.locale ) ? wcAppointmentsReactCalendar.locale : 'en';
		return {
			html: '<span class="wca-fc-hd">' + escHtml( d.toLocaleDateString( locale, { weekday: 'short' } ) ) + '<strong>' + d.getDate() + '</strong></span>'
		};
	}

	function renderTimezoneAllDayAxis() {
		var html = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.adminTimezoneHtml ) || '';
		return html ? { html: html.trim() } : { text: '' };
	}

	function formatDateByPattern( d, pattern ) {
		if ( !d || !( d instanceof Date ) ) { return ''; }
		var mIndex = d.getUTCMonth();
		var day = d.getUTCDate();
		var year = d.getUTCFullYear();
		var monthsFull = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.monthsFull ) || FALLBACK_MONTHS_FULL;
		var monthsShort = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.monthsShort ) || FALLBACK_MONTHS_SHORT;
		var locale = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.locale ) || 'en';
		var tokens = {
			'F': monthsFull[ mIndex ],
			'M': monthsShort[ mIndex ],
			'm': pad( mIndex + 1 ),
			'n': String( mIndex + 1 ),
			'd': pad( day ),
			'j': String( day ),
			'Y': String( year ),
			'y': String( year ).slice( -2 ),
			'l': d.toLocaleDateString( locale, { weekday: 'long', timeZone: 'UTC' } ),
			'D': d.toLocaleDateString( locale, { weekday: 'short', timeZone: 'UTC' } )
		};
		// Walk so PHP \ escapes stay literal (same as storefront wca_format_date).
		var out = '';
		var src = String( pattern || '' );
		for ( var i = 0; i < src.length; i++ ) {
			var ch = src.charAt( i );
			if ( ch === '\\' ) {
				out += i + 1 < src.length ? src.charAt( ++i ) : '\\';
				continue;
			}
			out += Object.prototype.hasOwnProperty.call( tokens, ch ) ? tokens[ ch ] : ch;
		}
		return out;
	}

	function formatTimeByPattern( d, pattern ) {
		if ( !d || !( d instanceof Date ) ) { return ''; }
		var Hnum = d.getUTCHours();
		var H = pad( Hnum );
		var gnum = ( Hnum % 12 ) || 12;
		var g = String( gnum );
		var h = pad( gnum );
		var i = pad( d.getUTCMinutes() );
		var s = pad( d.getUTCSeconds() );
		var a = 12 > Hnum ? 'am' : 'pm';
		var tokens = {
			'g': g,
			'h': h,
			'H': H,
			'i': i,
			's': s,
			'a': a
		};
		return String( pattern || '' ).replace( /g|h|H|i|s|a/g, function( tok ) {
			return tokens[ tok ] || tok;
		} );
	}

	function formatTimeByPatternLocal( d, pattern ) {
		if ( !d || !( d instanceof Date ) ) { return ''; }
		var local = new Date( Date.UTC(
			d.getFullYear(),
			d.getMonth(),
			d.getDate(),
			d.getHours(),
			d.getMinutes(),
			d.getSeconds()
		) );
		return formatTimeByPattern( local, pattern );
	}

	function buildFullCalendarTimeFormat( pattern ) {
		var fmt = {};
		var hasHours = /[gGhH]/.test( pattern || '' );
		var hasLeadingHour = /[Hh]/.test( pattern || '' );
		var hasMinutes = /i/.test( pattern || '' );
		var hasSeconds = /s/.test( pattern || '' );
		var is24Hour = /[GH]/.test( pattern || '' );
		var is12Hour = /[gh]/.test( pattern || '' ) || /a/.test( pattern || '' );
		if ( hasHours ) {
			fmt.hour = hasLeadingHour ? '2-digit' : 'numeric';
		}
		if ( hasMinutes ) {
			fmt.minute = '2-digit';
		}
		if ( hasSeconds ) {
			fmt.second = '2-digit';
		}
		if ( is24Hour ) {
			fmt.hour12 = false;
		} else if ( is12Hour ) {
			fmt.hour12 = true;
		}
		return fmt;
	}

	// =========================================================================
	// DEPRECATED TIMEZONE UTILITIES - Phase 6 Unified Slots Standardization
	// =========================================================================
	// These functions will be removed in a future major release. Server now provides
	// pre-calculated display fields in slot data:
	//   - slot.selection_value: ISO-8601 format for FullCalendar events
	//   - slot.display_day: Date in YYYY-MM-DD format
	//   - slot.display_time: Time in HH:mm format
	//   - slot.display_time_formatted: Localized time string
	// New code should use these server-provided values directly.
	// See UNIFIED-SLOTS-STANDARDIZATION.md for the new consumer pattern.
	// =========================================================================

	/**
	 * Convert a timestamp from site timezone to admin user's timezone.
	 * Delegates to centralized timezone utilities.
	 *
	 * @deprecated 5.3.5 Use slot.selection_value from server response instead.
	 * @param {number} ts - Unix timestamp (site timezone semantic)
	 * @returns {number} - Adjusted timestamp for admin timezone display
	 */
	function convertToAdminTimezone( ts ) {
		var utils = window.WCAppointmentsTimezoneUtils;
		return utils ? utils.convertSiteToAdminTimezone( ts ) : ts;
	}

	/**
	 * Check if admin has a different timezone than the site.
	 * Delegates to centralized timezone utilities.
	 *
	 * @deprecated 5.3.5 Display timezone differences handled server-side now.
	 * @returns {boolean}
	 */
	function adminHasDifferentTimezone() {
		var utils = window.WCAppointmentsTimezoneUtils;
		if ( !utils ) { return false; }
		var config = utils.getTimezoneConfig();
		return config.hasDifferentTz;
	}

	/**
	 * Convert timestamp to ISO string using UTC methods.
	 * Delegates to centralized timezone utilities.
	 *
	 * @deprecated 5.3.5 Use slot.selection_value from server response instead.
	 */
	function tsToNaiveLocalISO( ts ) {
		var utils = window.WCAppointmentsTimezoneUtils;
		return utils ? utils.tsToNaiveLocalISO( ts ) : '';
	}

	/**
	 * Convert timestamp to ISO string, adjusted for admin timezone display.
	 * Delegates to centralized timezone utilities.
	 *
	 * @deprecated 5.3.5 Use slot.selection_value from server response instead.
	 */
	function tsToAdminLocalISO( ts ) {
		var utils = window.WCAppointmentsTimezoneUtils;
		return utils ? utils.tsToAdminLocalISO( ts ) : '';
	}

	/**
	 * Convert timestamp to date string (Y-m-d) using UTC methods.
	 * Delegates to centralized timezone utilities.
	 *
	 * @deprecated 5.3.5 Use slot.display_day from server response instead.
	 */
	function tsToNaiveLocalDate( ts ) {
		var utils = window.WCAppointmentsTimezoneUtils;
		return utils ? utils.tsToNaiveLocalDate( ts ) : '';
	}

	/**
	 * Convert timestamp to date string (Y-m-d), adjusted for admin timezone.
	 * Delegates to centralized timezone utilities.
	 *
	 * @deprecated 5.3.5 Use slot.display_day from server response instead.
	 */
	function tsToAdminLocalDate( ts ) {
		var utils = window.WCAppointmentsTimezoneUtils;
		return utils ? utils.tsToAdminLocalDate( ts ) : '';
	}

	/**
	 * Convert Date object to Y-m-d string.
	 * Delegates to centralized timezone utilities.
	 */
	function dateToYmd( date ) {
		var utils = window.WCAppointmentsTimezoneUtils;
		return utils ? utils.dateToYmd( date ) : '';
	}

	function mapInitialView( v ) {
		// Map query/view setting to FullCalendar view identifiers
		switch ( ( v || '' ).toLowerCase() ) {
			case 'month':
				return 'dayGridMonth';
			case 'day':
				return 'timeGridDay';
			case 'list':
				return 'listWeek';
			case 'week':
			default:
				return 'timeGridWeek';
		}
	}

	var __wcaActiveGetControllers = [];
	var EXCLUDED_STATUSES = ( function () {
		var list = window.wcAppointmentsReactCalendar && window.wcAppointmentsReactCalendar.excludedStatuses;
		var map = { 'trash': 1, 'auto-draft': 1, 'in-cart': 1, 'was-in-cart': 1 };
		if ( Array.isArray( list ) ) {
			list.forEach( function ( status ) {
				if ( status ) {
					map[ String( status ).toLowerCase() ] = 1;
				}
			} );
		}
		return map;
	} )();
	var __wcaRestApiAvailable = null; // null = unknown, true = available, false = unavailable
	var __wcaSessionExpired = false; // Track session/nonce expiration (401/403 errors)

	/**
	 * Check if the error indicates session/nonce expiration (401/403)
	 * @param {Error|string} error - The error object or message
	 * @returns {boolean} True if this is an auth error
	 */
	function isAuthError( error ) {
		if ( !error ) {
			return false;
		}
		var msg = error.message || String( error );
		return /HTTP 401/i.test( msg ) || /HTTP 403/i.test( msg );
	}

	/**
	 * Mark session as expired and dispatch event for UI update
	 */
	function markSessionExpired() {
		if ( __wcaSessionExpired ) {
			return; // Already marked
		}
		__wcaSessionExpired = true;
		try {
			window.dispatchEvent( new CustomEvent( 'wca_session_expired' ) );
		} catch ( _ ) {
			// Fallback for older browsers
			var evt = document.createEvent( 'CustomEvent' );
			evt.initCustomEvent( 'wca_session_expired', true, true, {} );
			window.dispatchEvent( evt );
		}
	}

	function isExcludedStatus( status ) {
		return !!( status && EXCLUDED_STATUSES[ String( status ).toLowerCase() ] );
	}

	/**
	 * Check if REST API is available with cached result
	 * @returns {Promise<boolean>} Resolves to true if REST available, false otherwise
	 */
	function checkRestApiAvailability() {
		// Return cached result if available
		if ( null !== __wcaRestApiAvailable ) {
			return Promise.resolve( __wcaRestApiAvailable );
		}

		// Trust localized restUrl + nonce from PHP. A live GET to v2/index burns a PHP
		// worker for seconds on cold load (Local ~2 workers) and queues panel availability.
		// Real failures are detected in apiGet and flip __wcaRestApiAvailable to false.
		var base = ( window.wcAppointmentsReactCalendar && window.wcAppointmentsReactCalendar.restUrl ) ? window.wcAppointmentsReactCalendar.restUrl : '';
		var nonce = ( window.wcAppointmentsReactCalendar && window.wcAppointmentsReactCalendar.nonce ) ? window.wcAppointmentsReactCalendar.nonce : '';
		__wcaRestApiAvailable = !!( base && nonce );
		return Promise.resolve( __wcaRestApiAvailable );
	}

	function ensureArray( val ) {
		return Array.isArray( val ) ? val : [];
	}

	function resolveAvailabilityFilterIds( productId, staffId ) {
		var availStaffParam = null;
		if ( 'unassigned' === staffId ) {
			availStaffParam = 0;
		} else if ( staffId ) {
			availStaffParam = staffId;
		}
		return {
			availProductId: productId || null,
			availStaffParam: availStaffParam
		};
	}

	function buildAvailabilityScopes( availProductId, availStaffParam ) {
		var scopesToFetch = [ { kind: 'availability#global', kindId: null } ];
		if ( availProductId ) {
			scopesToFetch.push( { kind: 'availability#product', kindId: availProductId } );
		}
		// Unassigned staff (0) is intentionally excluded from scoped fetches.
		if ( availStaffParam && 0 !== availStaffParam ) {
			scopesToFetch.push( { kind: 'availability#staff', kindId: availStaffParam } );
		}
		return scopesToFetch;
	}

	function normalizeAvailabilityBuckets( v2Results, availProductId, availStaffParam ) {
		var unavGlobal = [];
		var unavProduct = [];
		var unavStaff = [];

		if ( v2Results && 'object' === typeof v2Results ) {
			if ( v2Results[ 'availability#global' ] ) {
				unavGlobal = v2Results[ 'availability#global' ].unavailable || [];
				if ( availProductId && v2Results[ 'availability#product' ] ) {
					unavProduct = v2Results[ 'availability#product' ].unavailable || [];
				}
				if ( availStaffParam && 0 !== availStaffParam && v2Results[ 'availability#staff' ] ) {
					unavStaff = v2Results[ 'availability#staff' ].unavailable || [];
				}
			} else {
				ensureArray( v2Results ).forEach( function( rule ) {
					var kind = rule.kind || '';
					if ( false !== rule.appointable ) {
						return;
					}
					if ( -1 !== kind.indexOf( '#global' ) ) {
						unavGlobal.push( rule );
					} else if ( -1 !== kind.indexOf( '#product' ) ) {
						unavProduct.push( rule );
					} else if ( -1 !== kind.indexOf( '#staff' ) ) {
						unavStaff.push( rule );
					}
				} );
			}
		}

		return [ unavGlobal, unavProduct, unavStaff ];
	}

	function fetchAvailabilityBuckets( apiGetFn, startTs, endTs, availProductId, availStaffParam ) {
		var scopesToFetch = buildAvailabilityScopes( availProductId, availStaffParam );
		var v2Params = {
			start_ts: startTs,
			end_ts: endTs,
			scopes: JSON.stringify( scopesToFetch )
		};
		if ( availProductId ) {
			v2Params.product_id = availProductId;
		}
		if ( availStaffParam && 0 !== availStaffParam ) {
			v2Params.staff_id = availStaffParam;
		}
		return apiGetFn( 'wc-appointments/v2/availabilities', v2Params ).then( function( v2Results ) {
			return normalizeAvailabilityBuckets( v2Results, availProductId, availStaffParam );
		} );
	}

	// ---------------------------------------------------------------------------
	// UI: TOAST NOTIFICATION STATE
	// ---------------------------------------------------------------------------
	var __wcaToasts = [];
	var __wcaToastListeners = [];
	var __wcaToastIdCounter = 0;
	var __wcaToastSeen = {}; // Deduplication for toasts by resource ID + content hash
	var __wcaToastTTL = 3000; // 3 second deduplication window for toasts
	var __wcaToastBulkKeys = {
		avail_created: 'toastMultipleAvailabilityCreated',
		avail_updated: 'toastMultipleAvailabilityUpdated',
		avail_deleted: 'toastMultipleAvailabilityDeleted',
		appt_created: 'toastMultipleAppointmentsCreated',
		appt_updated: 'toastMultipleAppointmentsUpdated'
	};
	var __wcaApptStateCache = {}; // Cache of appointment states for change detection
	var __wcaPendingCheckout = {}; // Track appointments transitioning from cart to checkout
	var __wcaCheckoutTTL = 5000; // 5 second window to suppress cart-removal notices after checkout
	var __wcaLocalToastSuppress = {}; // Suppress SSE toast after local drag toast
	var __wcaLocalToastTTL = 4000; // 4 second local suppression window

	function showToast( message, type, groupKey ) {
		type = type || 'info';
		var now = Date.now();

		// Grouping logic: if similar toast was added very recently, update it instead of adding new one
		if ( groupKey ) {
			// Find any existing toast with the same groupKey and type that hasn't expired yet
			var existingToast = __wcaToasts.find( function( t ) {
				return t.groupKey === groupKey && t.type === type && ( now - t.created ) < 3000;
			} );

			if ( existingToast ) {
				var toastIndex = __wcaToasts.indexOf( existingToast );
				var bulkKey = __wcaToastBulkKeys[ groupKey ] || '';
				var newCount = ( existingToast.count || 1 ) + 1;
				var newMessage = ( bulkKey && i18n[ bulkKey ] ) ? t( bulkKey, existingToast.message, newCount ) : existingToast.message;

				// Replace the object reference to ensure React re-renders the component
				var updatedToast = Object.assign( {}, existingToast, {
					message: newMessage,
					count: newCount,
					created: now
				} );

				// Reset dismiss timer
				if ( updatedToast.timerId ) {
					clearTimeout( updatedToast.timerId );
				}
				updatedToast.timerId = setTimeout( function() {
					var currentToast = __wcaToasts.find( function( t ) { return t.id === updatedToast.id; } );
					if ( currentToast && !currentToast.hover ) {
						dismissToast( updatedToast.id );
					}
				}, 4000 );

				// Update the global array
				__wcaToasts[ toastIndex ] = updatedToast;

				__wcaToastListeners.forEach( function( fn ) {
					try { fn( __wcaToasts.slice() ); } catch ( _ ) {}
				} );
				return updatedToast.id;
			}
		}

		var id = ++__wcaToastIdCounter;
		var toast = { id: id, message: message, type: type, groupKey: groupKey, count: 1, created: now, visible: true, hover: false };
		__wcaToasts.push( toast );
		__wcaToastListeners.forEach( function( fn ) {
			try { fn( __wcaToasts.slice() ); } catch ( _ ) {}
		} );
		// Auto-dismiss after 4 seconds, but check hover state
		var dismissTimer = setTimeout( function() {
			var currentToast = __wcaToasts.find( function( t ) { return t.id === id; } );
			if ( currentToast && !currentToast.hover ) {
				dismissToast( id );
			}
		}, 4000 );
		// Store timer ID for potential cleanup
		toast.timerId = dismissTimer;
		return id;
	}

	function dismissToast( id ) {
		var toastIndex = __wcaToasts.findIndex( function( t ) { return t.id === id; } );
		if ( toastIndex !== -1 ) {
			var toast = __wcaToasts[ toastIndex ];
			// Clear any pending timer
			if ( toast.timerId ) {
				clearTimeout( toast.timerId );
			}
			__wcaToasts.splice( toastIndex, 1 );
		}
		__wcaToastListeners.forEach( function( fn ) {
			try { fn( __wcaToasts.slice() ); } catch ( _ ) {}
		} );
	}

	function subscribeToasts( fn ) {
		__wcaToastListeners.push( fn );
		return function() {
			__wcaToastListeners = __wcaToastListeners.filter( function( f ) { return f !== fn; } );
		};
	}

	// Toast container component
	function ToastContainer() {
		var [ toasts, setToasts ] = useState( [] );

		useEffect( function() {
			return subscribeToasts( setToasts );
		}, [] );

		if ( !toasts.length ) {
			return null;
		}

		return h( 'div', { className: 'wca-toast-container' },
			toasts.slice( 0, 3 ).map( function( toast ) {
				var iconClass = 'dashicons ';
				if ( 'success' === toast.type ) {
					iconClass += 'dashicons-yes-alt';
				} else if ( 'error' === toast.type ) {
					iconClass += 'dashicons-warning';
				} else {
					iconClass += 'dashicons-info';
				}
				return h( 'div', {
					key: toast.id,
					className: 'wca-toast wca-toast--' + toast.type,
					onMouseEnter: function() {
						// Set hover state and clear timer
						toast.hover = true;
						if ( toast.timerId ) {
							clearTimeout( toast.timerId );
							toast.timerId = null;
						}
					},
					onMouseLeave: function() {
						// Clear hover state and set new timer
						toast.hover = false;
						if ( !toast.timerId ) {
							toast.timerId = setTimeout( function() {
								dismissToast( toast.id );
							}, 1000 ); // Give 1 second after hover ends
						}
					}
				},
					h( 'span', { className: iconClass } ),
					h( 'span', { className: 'wca-toast-message' }, toast.message ),
					h( 'button', {
						className: 'wca-toast-dismiss',
						onClick: function() { dismissToast( toast.id ); },
						'aria-label': t( 'dismiss', 'Dismiss' )
					}, h( 'span', { className: 'dashicons dashicons-no-alt' } ) )
				);
			} )
		);
	}

	// Helper to cache appointment state for change detection
	function cacheApptState( id, status, start, end, customerName ) {
		if ( !id ) { return; }
		__wcaApptStateCache[ id ] = {
			status: status || '',
			start: parseInt( start, 10 ) || 0,
			end: parseInt( end, 10 ) || 0,
			customerName: customerName || ''
		};
	}

	// Mark an appointment as having just completed checkout (suppress cart-removal notice)
	function markCheckoutComplete( id ) {
		if ( !id ) { return; }
		__wcaPendingCheckout[ id ] = Date.now();
	}

	function markLocalToastSuppression( id, action ) {
		if ( !id ) { return; }
		__wcaLocalToastSuppress[ String( id ) ] = {
			action: action || '',
			ts: Date.now()
		};
	}

	function shouldSuppressLocalToast( id, action ) {
		if ( !id ) { return false; }
		var key = String( id );
		var entry = __wcaLocalToastSuppress[ key ];
		if ( !entry ) { return false; }
		var now = Date.now();
		if ( ( now - ( entry.ts || 0 ) ) > __wcaLocalToastTTL ) {
			delete __wcaLocalToastSuppress[ key ];
			return false;
		}
		if ( !action || !entry.action ) {
			return true;
		}
		return entry.action === action;
	}

	// Check if an appointment recently completed checkout
	function isRecentCheckout( id ) {
		if ( !id || !__wcaPendingCheckout[ id ] ) { return false; }
		var elapsed = Date.now() - __wcaPendingCheckout[ id ];
		if ( elapsed > __wcaCheckoutTTL ) {
			delete __wcaPendingCheckout[ id ];
			return false;
		}
		return true;
	}

	/**
	 * Format timestamp for toast notifications with proper timezone conversion
	 * Delegates to centralized timezone utilities.
	 *
	 * @param {number} ts - UTC timestamp representing site timezone time
	 * @return {string} Formatted date/time string for toast display
	 */
	function formatToastDateTime( ts ) {
		try {
			if ( !ts ) { return ''; }

			var utils = window.WCAppointmentsTimezoneUtils;
			if ( !utils ) {
				var d = new Date( ts * 1000 );
				var dateFmt = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.dateFormat ) || 'M j, Y';
				var timeFmt = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.timeFormat ) || 'g:i a';
				return formatDateByPattern( d, dateFmt ) + ', ' + formatTimeByPattern( d, timeFmt );
			}

			var dateFmt = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.dateFormat ) || 'M j, Y';
			var timeFmt = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.timeFormat ) || 'g:i a';

			return utils.formatToastDateTime( ts, dateFmt, timeFmt, formatDateByPattern, formatTimeByPattern );
		} catch ( _ ) {
			return '';
		}
	}

	/**
	 * Format toast schedule text.
	 * For all-day appointments, force a date-only semantic range to avoid
	 * timezone-shifted clock times in toast messages.
	 *
	 * @param {number} startTs
	 * @param {number} endTs
	 * @param {boolean} isAllDay
	 * @return {string}
	 */
	function formatToastWhen( startTs, endTs, isAllDay ) {
		if ( !startTs ) { return ''; }
		if ( !isAllDay ) {
			return formatToastDateTime( startTs );
		}

		var dateFmt = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.dateFormat ) || 'M j, Y';
		function formatToastDateOnly( ts ) {
			if ( !ts ) { return ''; }
			// All-day toasts should reflect semantic booking dates (site wall-clock),
			// not admin-timezone-adjusted civil dates.
			var raw = new Date( ts * 1000 );
			var semanticDate = new Date( Date.UTC( raw.getUTCFullYear(), raw.getUTCMonth(), raw.getUTCDate(), 0, 0, 0 ) );
			return formatDateByPattern( semanticDate, dateFmt );
		}

		var s = formatToastDateOnly( startTs );

		if ( !endTs || endTs <= startTs ) {
			return s;
		}

		var e = formatToastDateOnly( Math.max( 0, endTs - 1 ) );
		return s === e ? s : ( s + ' – ' + e );
	}

	// Helper to get customer display name from payload
	function getCustomerDisplayName( payload ) {
		try {
			if ( !payload ) { return ''; }
			var name = payload.customer_name || payload.customer_full_name || '';
			if ( !name && payload.customer_first_name ) {
				name = ( payload.customer_first_name + ' ' + ( payload.customer_last_name || '' ) ).trim();
			}
			return name;
		} catch ( _ ) {
			return '';
		}
	}

	// Build semantic toast message with proper i18n structure
	function buildSemanticToastMessage( template, replacements ) {
		var msg = template;
		Object.keys( replacements || {} ).forEach( function( key ) {
			var val = replacements[ key ] || '';
			msg = msg.replace( new RegExp( '\\{' + key + '\\}', 'g' ), val );
			msg = msg.replace( new RegExp( '%' + key + '%', 'g' ), val );
		} );
		return msg;
	}

	// Status map for humanizing status strings
	function humanizeStatus( status, statusMap ) {
		if ( !status ) { return ''; }
		if ( statusMap && statusMap[ status ] ) { return statusMap[ status ]; }
		return status.split( '-' ).map( function( p ) {
			return p.charAt( 0 ).toUpperCase() + p.slice( 1 );
		} ).join( ' ' );
	}

	// Build toast message for SSE events
	function getToastMessageForEvent( topic, payload, i18n, resourceId ) {
		var isAvailability = topic && topic.indexOf( 'availability.' ) === 0;
		var groupKey = '';
		var id = ( payload && payload.id ) || resourceId || 0;
		if ( !id && !isAvailability ) {
			return '';
		}

		var newStatus = payload && payload.status ? String( payload.status ) : '';
		var newStart = payload && payload.start ? parseInt( payload.start, 10 ) : 0;
		var newEnd = payload && payload.end ? parseInt( payload.end, 10 ) : 0;
		var prev = id ? __wcaApptStateCache[ id ] : null;
		var resolvedStart = newStart || ( prev ? prev.start : 0 );
		var resolvedEnd = newEnd || ( prev ? prev.end : 0 );
		var customerName = getCustomerDisplayName( payload ) || ( prev && prev.customerName ) || '';
		var customerLabel = customerName || t( 'guest', 'Guest' );
		var payloadAllDay = !!( payload && ( true === payload.all_day || 1 === payload.all_day || '1' === payload.all_day || 'true' === payload.all_day ) );
		var isAllDayToast = payloadAllDay || isAllDayRangeTs( resolvedStart || 0, resolvedEnd || 0 );
		var dateTimeStr = formatToastWhen( resolvedStart || 0, resolvedEnd || 0, isAllDayToast );
		var replacements = { customer: customerLabel, datetime: dateTimeStr, id: id };
		var statusMap = ( i18n && i18n.statuses ) || {};
		var message = '';

		if ( isAvailability ) {
			if ( topic.indexOf( '.deleted' ) > 0 ) {
				message = t( 'toastAvailabilityDeleted', 'Availability rule deleted' );
				groupKey = 'avail_deleted';
			} else if ( topic.indexOf( '.created' ) > 0 || topic.indexOf( '.updated' ) > 0 ) {
				message = t( 'toastAvailabilitySaved', 'Availability rule saved' );
				groupKey = topic.indexOf( '.created' ) > 0 ? 'avail_created' : 'avail_updated';
			}
		// Appointment events
		} else if ( topic.indexOf( 'appointment.' ) === 0 ) {
			var action = topic.replace( 'appointment.', '' );
			var prevStatus = prev ? prev.status : '';
			var statusChanged = newStatus && newStatus !== prevStatus;
			var startChanged = newStart && newStart !== ( prev ? prev.start : 0 );
			var suppressLocalReschedule = shouldSuppressLocalToast( id, 'rescheduled' );

			if ( action === 'created' ) {
				// Skip toast for in-cart additions
				if ( newStatus !== 'in-cart' ) {
					var seriesIdToast = payload && ( payload.series_id || payload.seriesId )
						? parseInt( payload.series_id || payload.seriesId, 10 )
						: 0;
					if ( seriesIdToast > 0 ) {
						replacements.pattern = ( payload.series_pattern_summary || '' ).trim();
						message = buildSemanticToastMessage(
							t( 'toastSeriesCreated', '{customer} booked a recurring series ({pattern})' ),
							replacements
						);
						groupKey = 'series_created:' + seriesIdToast;
					} else {
						message = buildSemanticToastMessage(
							t( 'toastAppointmentCreatedSemantic', 'Appointment #{id} with {customer} created for {datetime}' ),
							replacements
						);
						groupKey = 'appt_created';
					}
				}

			} else if ( action === 'cancelled' ) {
				message = buildSemanticToastMessage(
					t( 'toastAppointmentCancelledSemantic', 'Appointment #{id} with {customer} for {datetime} was cancelled' ),
					replacements
				);
				groupKey = 'appt_updated';

			} else if ( action === 'deleted' || action === 'trashed' ) {
				message = buildSemanticToastMessage(
					t( 'toastAppointmentDeletedSemantic', 'Appointment #{id} with {customer} was removed' ),
					replacements
				);
				groupKey = 'appt_updated';

			} else if ( action === 'rescheduled' ) {
				if ( suppressLocalReschedule ) {
					message = '';
				} else {
					message = buildSemanticToastMessage(
						t( 'toastAppointmentRescheduledSemantic', 'Appointment #{id} with {customer} rescheduled to {datetime}' ),
						replacements
					);
					groupKey = 'appt_updated';
				}

			} else if ( action === 'updated' ) {
				// Checkout: in-cart → paid/unpaid/pending-confirmation/confirmed
				var checkoutStatuses = { 'unpaid': 1, 'pending-confirmation': 1, 'paid': 1, 'confirmed': 1 };
				var isCheckout = statusChanged && prevStatus === 'in-cart' && checkoutStatuses[ newStatus ];
				var isCartRemoval = newStatus === 'was-in-cart';
				var isCartAdd = newStatus === 'in-cart' && prevStatus !== 'in-cart';

				if ( isCheckout ) {
					markCheckoutComplete( id );
					message = buildSemanticToastMessage(
						t( 'toastAppointmentBooked', '{customer} booked appointment #{id} for {datetime}' ),
						replacements
					);
					groupKey = 'appt_created';
				} else if ( isCartRemoval ) {
					// Skip toast for cart removals (including after checkout)
					message = '';
				} else if ( isCartAdd ) {
					// Skip toast for cart additions
					message = '';
				} else if ( newStatus === 'cancelled' && statusChanged ) {
					message = buildSemanticToastMessage(
						t( 'toastAppointmentCancelledSemantic', 'Appointment #{id} with {customer} for {datetime} was cancelled' ),
						replacements
					);
				} else if ( startChanged && !statusChanged ) {
					if ( suppressLocalReschedule ) {
						message = '';
					} else {
						message = buildSemanticToastMessage(
							t( 'toastAppointmentRescheduledSemantic', 'Appointment #{id} with {customer} rescheduled to {datetime}' ),
							replacements
						);
					}
				} else if ( statusChanged && newStatus ) {
					// Only show toast for approved status changes (confirmed, paid, complete, cancelled, pending-confirmation)
					var approvedStatuses = { 'confirmed': 1, 'paid': 1, 'complete': 1, 'cancelled': 1, 'pending-confirmation': 1 };
					if ( approvedStatuses[ newStatus ] ) {
						replacements.status = humanizeStatus( newStatus, statusMap );
						message = buildSemanticToastMessage(
							t( 'toastAppointmentStatusChanged', 'Appointment #{id} with {customer} status changed to {status}' ),
							replacements
						);
					}
				}
				if ( message && !groupKey ) {
					groupKey = 'appt_updated';
				}
			}
		}

		// Update state cache
		if ( id ) {
			if ( topic && ( topic.indexOf( '.deleted' ) > 0 || topic.indexOf( '.trashed' ) > 0 ) ) {
				delete __wcaApptStateCache[ id ];
			} else if ( newStatus || newStart || newEnd || customerName ) {
				cacheApptState( id, newStatus || ( prev ? prev.status : '' ), newStart || resolvedStart, newEnd || resolvedEnd, customerName );
			}
		}

		if ( !message ) { return { message: '', type: 'info', groupKey: '' }; }

		// Deduplicate toasts by resource ID + topic.
		// This is a second layer of deduplication, in case SSE stream sends duplicates.
		var toastKey = isAvailability
			? 'avail:' + ( resourceId || id ) + ':' + topic
			: 'appt:' + id + ':' + message.substring( 0, 40 );
		var now = Date.now();
		if ( __wcaToastSeen[ toastKey ] && ( now - __wcaToastSeen[ toastKey ] ) < __wcaToastTTL ) {
			return { message: '', type: 'info', groupKey: '' };
		}
		// Also check a broader key based on appointment ID + action category to catch
		// cases where the same reschedule produces toasts with different customer name
		// resolution (e.g., local "Guest" vs SSE full name).
		if ( !isAvailability && id ) {
			var actionCategory = '';
			if ( topic && topic.indexOf( 'appointment.' ) === 0 ) {
				var act = topic.replace( 'appointment.', '' );
				if ( act === 'rescheduled' || ( act === 'updated' && startChanged ) ) {
					actionCategory = 'reschedule';
				}
			}
			if ( actionCategory ) {
				var broadKey = 'appt:' + id + ':' + actionCategory;
				if ( __wcaToastSeen[ broadKey ] && ( now - __wcaToastSeen[ broadKey ] ) < __wcaToastTTL ) {
					return { message: '', type: 'info', groupKey: '' };
				}
				__wcaToastSeen[ broadKey ] = now;
			}
		}
		__wcaToastSeen[ toastKey ] = now;

		// Periodic cleanup (10% chance)
		if ( Math.random() < 0.1 ) {
			var cutoff = now - __wcaToastTTL * 3;
			var checkoutCutoff = now - __wcaCheckoutTTL * 2;
			for ( var k in __wcaToastSeen ) {
				if ( __wcaToastSeen[ k ] < cutoff ) { delete __wcaToastSeen[ k ]; }
			}
			for ( var c in __wcaPendingCheckout ) {
				if ( __wcaPendingCheckout[ c ] < checkoutCutoff ) { delete __wcaPendingCheckout[ c ]; }
			}
		}

		return { message: message, type: 'info', groupKey: groupKey };
	}

	function abortAllGetRequests() {
		__wcaActiveGetControllers.forEach( function( c ) {
			try {
				c.abort();
			} catch ( _ ) {}
		} );
		__wcaActiveGetControllers = [];
	}

	function isRequestsBlocked() {
		try {
			return !!window.__wcaBlockRequests;
		} catch ( _ ) {
			return false;
		}
	}

	function setRequestsBlocked( on ) {
		try {
			window.__wcaBlockRequests = !!on;
		} catch ( _ ) {}
		if ( on ) {
			abortAllGetRequests();
		}
	}

	/**
	 * Retry wrapper for API calls that handles 502/503 errors
	 * @param {Function} fetchFn - Function that returns a Promise
	 * @param {number} maxRetries - Maximum number of retry attempts (default: 2)
	 * @returns {Promise} Promise that resolves/rejects after retries
	 */
	function retryOnServerError( fetchFn, maxRetries ) {
		maxRetries = maxRetries || 2;
		var attempt = 0;

		function attemptRequest() {
			return fetchFn().catch( function( error ) {
				// Check if error is a 502 or 503
				var isRetryableError = false;
				var statusCode = null;

				if ( error && error.message ) {
					var statusMatch = error.message.match( /HTTP (\d+)/ );
					if ( statusMatch ) {
						statusCode = parseInt( statusMatch[ 1 ], 10 );
						isRetryableError = 502 === statusCode || 503 === statusCode;
					}
				}

				// Also check for network errors that might be retryable
				if ( !isRetryableError && error && 'TypeError' === error.name && error.message && ( error.message.includes( 'fetch' ) || error.message.includes( 'network' ) ) ) {
					isRetryableError = true;
				}

				// Don't retry if:
				// - Not a retryable error
				// - Request was aborted
				// - Max retries reached
				if ( !isRetryableError || 'AbortError' === error.name || attempt >= maxRetries ) {
					throw error;
				}

				// Increment attempt and retry with exponential backoff
				attempt += 1;
				var delay = Math.min( 500 * Math.pow( 2, attempt - 1 ), 2000 ); // 500ms, 1000ms, max 2000ms

				return new Promise( function( resolve ) {
					setTimeout( function() {
						resolve( attemptRequest() );
					}, delay );
				} );
			} );
		}

		return attemptRequest();
	}

	function apiGet( path, params ) {
		if ( isRequestsBlocked() ) {
			return Promise.reject( new Error( 'Blocked during drag/resize' ) );
		}

		// If REST is known to be unavailable, reject immediately
		if ( false === __wcaRestApiAvailable ) {
			return Promise.reject( new Error( 'REST API unavailable' ) );
		}

		var run = function() {
			if ( isRequestsBlocked() ) {
				return Promise.reject( new Error( 'Blocked during drag/resize' ) );
			}
			var base = ( window.wcAppointmentsReactCalendar && window.wcAppointmentsReactCalendar.restUrl ) ? window.wcAppointmentsReactCalendar.restUrl : '';
			if ( '/' !== base.slice( -1 ) ) {
				base += '/';
			}
			var u = new URL( base + String( path ).replace( /^\//, '' ) );
			if ( params ) {
				var filter = params.filter;
				Object.keys( params ).forEach( function( k ) {
					if ( 'filter' === k ) {
						return;
					}
					var v = params[ k ];
					if ( undefined === v || null === v || '' === v ) {
						return;
					}
					if ( Array.isArray( v ) ) {
						// Check if array contains objects - if so, serialize as JSON
						var hasObjects = 0 < v.length && 'object' === typeof v[ 0 ] && null !== v[ 0 ] && !Array.isArray( v[ 0 ] );
						if ( hasObjects ) {
							// Serialize array of objects as JSON string
							u.searchParams.append( k, JSON.stringify( v ) );
						} else {
							// Handle simple arrays (strings, numbers, etc.)
							var key = ( 'include' === k ) ? 'include[]' : ( k.endsWith( '[]' ) ? k : ( k + '[]' ) );
							v.forEach( function( item ) {
								u.searchParams.append( key, item );
							} );
						}
					} else {
						u.searchParams.append( k, v );
					}
				} );
				if ( Array.isArray( filter ) ) {
					for ( var i = 0; i < filter.length; i++ ) {
						var f = filter[ i ] || {};
						if ( f.key !== undefined ) {
							u.searchParams.append( 'filter[' + i + '][key]', f.key );
						}
						if ( f.compare !== undefined ) {
							u.searchParams.append( 'filter[' + i + '][compare]', f.compare );
						}
						if ( f.value !== undefined ) {
							if ( Array.isArray( f.value ) ) {
								for ( var fi = 0; fi < f.value.length; fi++ ) {
									u.searchParams.append( 'filter[' + i + '][value][]', f.value[ fi ] );
								}
							} else {
								u.searchParams.append( 'filter[' + i + '][value]', f.value );
							}
						}
					}
				}
			}
			var controller = ( window && 'function' === typeof window.AbortController ) ? new window.AbortController() : null;
			var signal = controller ? controller.signal : undefined;
			if ( controller ) {
				__wcaActiveGetControllers.push( controller );
			}
			return retryOnServerError( function() {
				return fetch( u.toString(), {
					headers: {
						'X-WP-Nonce': wcAppointmentsReactCalendar.nonce
					},
					signal: signal
				} ).then( function( r ) {
					if ( controller ) {
						__wcaActiveGetControllers = __wcaActiveGetControllers.filter( function( c ) {
							return c !== controller;
						} );
					}
					if ( !r.ok ) {
						throw new Error( 'HTTP ' + r.status );
					}
					return r.json();
				} ).catch( function( e ) {
					if ( controller ) {
						__wcaActiveGetControllers = __wcaActiveGetControllers.filter( function( c ) {
							return c !== controller;
						} );
					}
					// Detect session/nonce expiration (401/403)
					if ( isAuthError( e ) ) {
						markSessionExpired();
					}
					// Mark REST as unavailable on consistent failures
					if ( e && e.message && ( /Failed to fetch/i.test( e.message ) || /NetworkError/i.test( e.message ) ) ) {
						__wcaRestApiAvailable = false;
					}
					throw e;
				} );
			} );
		};

		return run();
	}

	// Determine if a [start_ts, end_ts] range spans full days (all-day block)
	function isAllDayRangeTs( start_ts, end_ts ) {
		var day = 86400;
		if ( !start_ts || !end_ts ) {
			return false;
		}
		var startDay = Math.floor( start_ts / day );
		var endDayInclusive = Math.floor( ( end_ts - 1 ) / day );
		var spansMultipleDays = endDayInclusive > startDay;
		if ( spansMultipleDays ) {
			return true;
		}
		var startsAtMidnight = 0 === ( start_ts % day );
		var coversFullSingleDay = startsAtMidnight && ( end_ts - start_ts ) >= ( day - 1 ) && endDayInclusive === startDay;
		return coversFullSingleDay;
	}

	// Multi-select filter section component used inside FilterPanel
	function FilterSection( props ) {
		var label = props.label || '';
		var searchPlaceholder = props.searchPlaceholder || '';
		var items = props.items || []; // [{ id, name, avatar? }]
		var selected = props.selected || []; // array of selected ids
		var onChange = props.onChange || function() {};
		var showSearch = items.length > 8;
		var [ query, setQuery ] = useState( '' );

		var filtered = query
			? items.filter( function( it ) {
				return String( it.name || '' ).toLowerCase().indexOf( query.toLowerCase() ) !== -1;
			} )
			: items;

		function toggle( id ) {
			var idStr = String( id );
			var idx = -1;
			for ( var i = 0; i < selected.length; i++ ) {
				if ( String( selected[ i ] ) === idStr ) {
					idx = i;
					break;
				}
			}
			if ( idx > -1 ) {
				var next = selected.slice();
				next.splice( idx, 1 );
				onChange( next );
			} else {
				onChange( selected.concat( [ idStr ] ) );
			}
		}

		function isSelected( id ) {
			var idStr = String( id );
			for ( var i = 0; i < selected.length; i++ ) {
				if ( String( selected[ i ] ) === idStr ) {
					return true;
				}
			}
			return false;
		}

		return h( 'div', { className: 'wca-filter-section' },
			h( 'div', { className: 'wca-filter-section__header' },
				h( 'span', { className: 'wca-filter-section__label' }, label ),
				selected.length > 0 ? h( 'span', { className: 'wca-filter-section__count' }, String( selected.length ) ) : null
			),
			showSearch ? h( 'div', { className: 'wca-filter-section__search' },
				h( 'input', {
					type: 'text',
					value: query,
					placeholder: searchPlaceholder,
					onChange: function( e ) { setQuery( e.target.value || '' ); },
					className: 'wca-filter-section__search-input'
				} ),
				query ? h( 'button', {
					type: 'button',
					className: 'wca-filter-section__search-clear',
					onClick: function() { setQuery( '' ); },
					'aria-label': t( 'clear', 'Clear' )
				}, '×' ) : null
			) : null,
			h( 'div', { className: 'wca-filter-section__list' },
				filtered.length === 0
					? h( 'div', { className: 'wca-filter-section__empty' }, t( 'noResults', 'No results' ) )
					: filtered.map( function( it ) {
						var checked = isSelected( it.id );
						return h( 'label', {
							key: String( it.id ),
							className: 'wca-filter-section__item' + ( checked ? ' is-checked' : '' )
						},
							h( 'input', {
								type: 'checkbox',
								checked: checked,
								onChange: function() { toggle( it.id ); },
								className: 'wca-filter-section__checkbox'
							} ),
							it.avatar ? h( 'img', {
								src: it.avatar,
								alt: '',
								className: 'wca-filter-section__avatar'
							} ) : null,
							h( 'span', { className: 'wca-filter-section__name' }, String( it.name || '' ) ),
							it.color ? h( 'span', {
								className: 'wca-filter-section__color',
								style: { background: it.color }
							} ) : null
						);
					} )
			)
		);
	}

	// FilterPanel: status as a wrapping row, then Products / Staff / Locations columns.
	function FilterPanel( props ) {
		var canManageOthers = props.canManageOthers;
		var productIds = props.productIds || [];
		var setProductIds = props.setProductIds;
		var staffIds = props.staffIds || [];
		var setStaffIds = props.setStaffIds;
		var locationIds = props.locationIds || [];
		var setLocationIds = props.setLocationIds;
		var statusIds = props.statusIds || [];
		var setStatusIds = props.setStatusIds;

		// Build product items from preloaded data (include cal_color for dot next to name, like viewing modal)
		var productItems = ( wcAppointmentsReactCalendar.preloadedProducts || [] ).map( function( p ) {
			var color = ( p.cal_color && String( p.cal_color ).trim() ) ? String( p.cal_color ).trim() : '#0073aa';
			return { id: String( p.id ), name: p.name || ( '#' + p.id ), color: color };
		} );

		// Build staff items from preloaded data (includes Unassigned option)
		var staffItems = [];
		if ( canManageOthers ) {
			staffItems.push( { id: 'unassigned', name: t( 'unassigned', 'Unassigned' ) } );
			( wcAppointmentsReactCalendar.preloadedStaff || [] ).forEach( function( s ) {
				staffItems.push( { id: String( s.id ), name: s.name || ( '#' + s.id ), avatar: s.avatar || '' } );
			} );
		}

		var locationItems = ( wcAppointmentsReactCalendar.preloadedLocations || [] ).map( function( loc ) {
			return { id: String( loc.id ), name: loc.name || ( '#' + loc.id ) };
		} );
		if ( locationItems.length ) {
			locationItems.unshift( { id: 'none', name: t( 'noLocation', 'No location' ) } );
		}

		// Build status items from i18n statuses map
		var statusMap = ( i18n && i18n.statuses ) || {};
		var statusItems = [];
		var statusOrder = [ 'unpaid', 'pending-confirmation', 'confirmed', 'paid', 'complete', 'cancelled' ];
		statusOrder.forEach( function( key ) {
			if ( statusMap[ key ] ) {
				statusItems.push( { id: key, name: statusMap[ key ] } );
			}
		} );

		// For staff users, don't count the locked staff filter as a user-chosen filter
		var lockedStaffId = !canManageOthers ? String( wcAppointmentsReactCalendar.initialStaffId || '' ) : '';
		var userStaffCount = canManageOthers ? staffIds.length : 0; // Don't count locked staff filter
		var totalActive = productIds.length + userStaffCount + locationIds.length + statusIds.length;

		return h( 'div', { className: 'wca-filter-panel' },
			toolbarDashiconBtn( 'button wca-toolbar-filter-toggle', 'close', 'Close', 'dashicons-no-alt', props.onClose ),
			h( 'div', { className: 'wca-filter-panel__body' },
				h( FilterSection, {
					label: t( 'filterStatus', 'Status' ),
					items: statusItems,
					selected: statusIds,
					onChange: setStatusIds
				} ),
				h( FilterSection, {
					label: t( 'filterProducts', 'Products' ),
					searchPlaceholder: t( 'search', 'Search' ),
					items: productItems,
					selected: productIds,
					onChange: setProductIds
				} ),
				canManageOthers ? h( FilterSection, {
					label: t( 'filterStaff', 'Staff' ),
					searchPlaceholder: t( 'search', 'Search' ),
					items: staffItems,
					selected: staffIds,
					onChange: setStaffIds
				} ) : null,
				locationItems.length ? h( FilterSection, {
					label: t( 'filterLocations', 'Locations' ),
					searchPlaceholder: t( 'search', 'Search' ),
					items: locationItems,
					selected: locationIds,
					onChange: setLocationIds
				} ) : null
			),
			totalActive > 0 ? h( 'div', { className: 'wca-filter-panel__footer' },
				h( 'button', {
					type: 'button',
					className: 'wca-filter-panel__clear-all',
					onClick: function() {
						setProductIds( [] );
						// Preserve locked staff ID for staff users
						if ( lockedStaffId ) {
							setStaffIds( [ lockedStaffId ] );
						} else {
							setStaffIds( [] );
						}
						setLocationIds( [] );
						setStatusIds( [] );
					}
				}, t( 'clearAll', 'Clear all' ), ' (', String( totalActive ), ')' )
			) : null
		);
	}

	var TOOLBAR_VIEWS = [
		{ id: 'dayGridMonth', labelKey: 'month', defaultLabel: 'Month' },
		{ id: 'timeGridWeek', labelKey: 'week', defaultLabel: 'Week' },
		{ id: 'timeGridDay', labelKey: 'day', defaultLabel: 'Day' },
		{ id: 'listWeek', labelKey: 'list', defaultLabel: 'List' }
	];

	function toolbarDashiconBtn( className, labelKey, defaultLabel, icon, handler ) {
		var label = t( labelKey, defaultLabel );
		return h( 'button', {
			className: className,
			onClick: function() {
				if ( handler ) {
					handler();
				}
			},
			title: label,
			'aria-label': label
		}, h( 'span', { className: 'dashicons ' + icon, 'aria-hidden': 'true' } ) );
	}

	function Toolbar( props ) {
		// Admin calendar toolbar: navigation, filters and view switcher
		var canManageOthers = props.canManageOthers;
		var productIds = props.productIds || [];
		var setProductIds = props.setProductIds;
		var staffIds = props.staffIds || [];
		var setStaffIds = props.setStaffIds;
		var locationIds = props.locationIds || [];
		var setLocationIds = props.setLocationIds;
		var statusIds = props.statusIds || [];
		var setStatusIds = props.setStatusIds;
		var filtersOpen = props.filtersOpen;
		var setFiltersOpen = props.setFiltersOpen;
		var title = props.title || '';
		var periodYmd = props.periodYmd || '';
		var onGotoDate = props.onGotoDate;
		var onPrev = props.onPrev;
		var onNext = props.onNext;
		var onToday = props.onToday;
		var onBackToMonth = props.onBackToMonth;
		var showMonthBack = !!props.showMonthBack;
		var changeView = props.changeView;
		var currentView = props.currentView || '';

		// For staff users, the initialStaffId is locked (backend-enforced) and shouldn't count as a user filter
		var userStaffCount = canManageOthers ? staffIds.length : 0;
		var totalActive = productIds.length + userStaffCount + locationIds.length + statusIds.length;

		var filterLabel = t( 'filters', 'Filters' );
		if ( totalActive > 0 ) {
			filterLabel += ' (' + totalActive + ')';
		}

		var isMonthView = 'dayGridMonth' === currentView;

		return h( 'div', { className: 'wca-toolbar-wrapper' },
			h( 'div',
				{
					className: 'wca-react-toolbar'
				},
				h( 'div',
					{
						className: 'wca-toolbar-left'
					},
					wcAppointmentsReactCalendar.canCreateAppointments ? h( 'a', {
						href: wcAppointmentsReactCalendar.addAppointmentUrl || '#',
						className: 'wca-toolbar-add-btn',
						title: t( 'addNewAppointment', 'Add New Appointment' ),
						'aria-label': t( 'addNewAppointment', 'Add New Appointment' ),
						'data-label': t( 'addNew', 'New' ),
						'data-wca-panel-create': wcAppointmentsReactCalendar.panelEnabled ? '1' : undefined
					}, h( 'span', { className: 'dashicons dashicons-plus', 'aria-hidden': 'true' } ) ) : null,
					h( 'div', { className: 'wca-toolbar-time-nav' },
					showMonthBack ? toolbarDashiconBtn( 'button wca-toolbar-back', 'backToMonth', 'Back to month', 'dashicons-arrow-left-alt', onBackToMonth ) : null,
					h( 'button', {
						className: 'button wca-toolbar-today',
						title: t( 'today', 'Today' ),
						'aria-label': t( 'today', 'Today' ),
						onClick: function() {
							if ( onToday ) {
								onToday();
							}
						}
					},
						h( 'span', { className: 'wca-toolbar-today-text' }, t( 'today', 'Today' ) ),
						h( 'span', { className: 'dashicons dashicons-admin-home wca-toolbar-today-icon', 'aria-hidden': 'true' } )
					),
						h( 'div', { className: 'wca-toolbar-period' },
							toolbarDashiconBtn( 'button wca-toolbar-nav-prev', 'prev', 'Prev', 'dashicons-arrow-left-alt2', onPrev ),
							toolbarDashiconBtn( 'button wca-toolbar-nav-next', 'next', 'Next', 'dashicons-arrow-right-alt2', onNext ),
							h( 'label', {
								className: 'wca-toolbar-title',
								title: title || undefined
							},
								title || '',
								h( 'input', {
									// Remount when month/date type flips so the native picker UI refreshes.
									key: isMonthView ? 'month' : 'date',
									type: isMonthView ? 'month' : 'date',
									className: 'wca-toolbar-period-date',
									value: isMonthView ? ( periodYmd || '' ).slice( 0, 7 ) : ( periodYmd || '' ),
									'aria-label': isMonthView ? t( 'chooseMonth', 'Choose month' ) : t( 'chooseDate', 'Choose date' ),
									onChange: function( e ) {
										var v = e.target.value;
										if ( ! v || ! onGotoDate ) {
											return;
										}
										// Month input is YYYY-MM; gotoDate needs a day.
										onGotoDate( isMonthView ? v + '-01' : v );
									}
								} )
							),
							h( 'button',
								{
									className: 'button wca-toolbar-filter-toggle' + ( filtersOpen ? ' is-active' : '' ),
									onClick: function() { setFiltersOpen( !filtersOpen ); },
									title: filterLabel,
									'aria-label': filterLabel,
									'aria-expanded': filtersOpen ? 'true' : 'false'
								},
								h( 'span', { className: 'dashicons dashicons-filter', 'aria-hidden': 'true' } ),
								totalActive > 0 ? h( 'span', {
									className: 'wca-toolbar-filter-badge',
									'aria-hidden': 'true'
								}, String( totalActive ) ) : null
							)
						)
					)
				),
				h( 'div', { className: 'wca-toolbar-views' },
					h( 'select', {
						className: 'wca-toolbar-views-select',
						value: currentView,
						'aria-label': t( 'view', 'View' ),
						onChange: function( e ) {
							changeView( e.target.value );
						}
					}, TOOLBAR_VIEWS.map( function( view ) {
						return h( 'option', { key: view.id, value: view.id }, t( view.labelKey, view.defaultLabel ) );
					} ) )
				)
			),
			filtersOpen ? h( FilterPanel, {
				canManageOthers: canManageOthers,
				onClose: function() { setFiltersOpen( false ); },
				productIds: productIds,
				setProductIds: setProductIds,
				staffIds: staffIds,
				setStaffIds: setStaffIds,
				locationIds: locationIds,
				setLocationIds: setLocationIds,
				statusIds: statusIds,
				setStatusIds: setStatusIds
			} ) : null
		);
	}

	function App() {
		// Root app: loads data, initializes FullCalendar, and wires handlers
		var canManageOthers = !!wcAppointmentsReactCalendar.canManageOthers;
		var qs0 = ( function() {
			try {
				return new URLSearchParams( window.location.search );
			} catch ( e ) {
				return null;
			}
		} )();
		var qsView = qs0 ? ( qs0.get( 'view' ) || '' ) : '';
		var initialView = mapInitialView( qsView || wcAppointmentsReactCalendar.initialView );
		var initialDateParam = qs0 ? ( qs0.get( 'calendar_day' ) || '' ) : '';
		var calElRef = useRef( null );
		var calRef = useRef( null );
		var __productsState = useState( [] );
		var products = __productsState[ 0 ];
		var __staffState = useState( [] );
		var staff = __staffState[ 0 ];

		// Multi-select filter state: arrays of selected IDs
		var [ productIds, setProductIds ] = useState( function() {
			var qsProduct = qs0 ? ( qs0.get( 'product_id' ) || '' ) : '';
			return qsProduct ? [ String( qsProduct ) ] : [];
		}() );
		var [ staffIds, setStaffIds ] = useState( function() {
			// First try URL parameter
			if ( qs0 ) {
				var urlStaffId = qs0.get( 'staff_id' );
				if ( urlStaffId && urlStaffId !== '0' && urlStaffId !== 0 ) {
					return [ String( urlStaffId ) ];
				}
			}
			// Fall back to initial staff ID from configuration (for staff users)
			var initialStaff = wcAppointmentsReactCalendar.initialStaffId || '';
			return initialStaff ? [ String( initialStaff ) ] : [];
		}() );
		var [ statusIds, setStatusIds ] = useState( [] );
		var [ locationIds, setLocationIds ] = useState( [] );
		var [ filtersOpen, setFiltersOpen ] = useState( false );

		// Derive single productId/staffId for API calls (use first selected or empty)
		var productId = productIds.length === 1 ? productIds[ 0 ] : '';
		var staffId = staffIds.length === 1 ? staffIds[ 0 ] : '';

		var [ error, setError ] = useState( '' );
		var __emptyTipState = useState( false );
		var setEmptyTip = __emptyTipState[ 1 ];
		var [ loadingEvents, setLoadingEvents ] = useState( false );
		var [ viewTitle, setViewTitle ] = useState( '' );
		var [ periodYmd, setPeriodYmd ] = useState( initialDateParam || '' );
		var [ currentView, setCurrentView ] = useState( initialView );
		var [ showMonthBack, setShowMonthBack ] = useState( false );
		var monthReturnYmdRef = useRef( '' );
		var dragInProgressRef = useRef( false );

		// Refs to store current filter values for use in events function (avoids stale closures)
		var productIdRef = useRef( productId );
		var staffIdRef = useRef( staffId );
		var productIdsRef = useRef( productIds );
		var staffIdsRef = useRef( staffIds );
		var locationIdsRef = useRef( locationIds );
		var statusIdsRef = useRef( statusIds );

		// Refs to control efficient reloads
		var skipAvailRef = useRef( true );
		var appointmentsDirtyRef = useRef( true );
		var availabilitiesDirtyRef = useRef( true );
		var sseReadyRef = useRef( false );
		var pendingCreateRef = useRef( 0 );
		var sseInjectedIdsRef = useRef( {} );
		var prevViewTypeRef = useRef( initialView );
		var prevActiveRangeRef = useRef( '' );

		var pendingAppointmentFetchesRef = useRef( {} );
		var appointmentFetchControllerRef = useRef( null );
		var loadGenRef = useRef( 0 );
		var preloadedDataRef = useRef( null );
		var lastCreatePickRef = useRef( { ts: 0, key: '' } );
		var suppressCreateFromRuleTapRef = useRef( 0 );
		var apptEventElRef = useRef( {} );
		var panelTargetApptIdRef = useRef( null );

		function getRangeKey( startTs, endTs ) {
			return startTs + '-' + endTs;
		}

		function getPreloadedAppointmentsForRange( startTs, endTs ) {
			var preloaded = preloadedDataRef.current;
			if ( !preloaded || preloaded.startTs > startTs || preloaded.endTs < endTs ) {
				return null;
			}
			return ( preloaded.appointments || [] ).filter( function( appt ) {
				var s = parseInt( appt.start, 10 ) || 0;
				var e = parseInt( appt.end, 10 ) || 0;
				var isoS = tsToAdminLocalISO( s );
				var isoE = tsToAdminLocalISO( e );
				var dispS = isoS ? Math.floor( new Date( isoS ).getTime() / 1000 ) : s;
				var dispE = isoE ? Math.floor( new Date( isoE ).getTime() / 1000 ) : e;
				return dispS < endTs && dispE > startTs;
			} );
		}

		function appointmentMatchesStaffFilterId( appt, reqStaffId ) {
			var reqStaffIdStr = String( reqStaffId );
			// Creator/author match: same semantics as calendar SQL and legacy calendar cards.
			if ( appt && appt.creator_id && String( appt.creator_id ) === reqStaffIdStr ) {
				return true;
			}
			var apptStaffId = appt.staff_id || appt.staff_ids;
			if ( 'unassigned' === reqStaffId || 0 === reqStaffId || '0' === reqStaffId ) {
				if ( apptStaffId && 0 !== apptStaffId && '0' !== apptStaffId ) {
					if ( Array.isArray( apptStaffId ) ? 0 < apptStaffId.length : true ) {
						return false;
					}
				}
				return true;
			}
			if ( Array.isArray( apptStaffId ) ) {
				return -1 !== apptStaffId.indexOf( parseInt( reqStaffId, 10 ) ) || -1 !== apptStaffId.indexOf( reqStaffIdStr );
			}
			return String( apptStaffId || '' ) === reqStaffIdStr;
		}

		// Multi-select filter: filter appointments by arrays of product IDs, staff IDs, location IDs, and status IDs
		function filterAppointmentsByMultiSelect( appointments, reqProductIds, reqStaffIds, reqStatusIds, reqLocationIds ) {
			if ( !appointments || !appointments.length ) {
				return appointments;
			}
			var hasProducts = reqProductIds && reqProductIds.length > 0;
			var hasStaff = reqStaffIds && reqStaffIds.length > 0;
			var hasStatuses = reqStatusIds && reqStatusIds.length > 0;
			var hasLocations = reqLocationIds && reqLocationIds.length > 0;
			if ( !hasProducts && !hasStaff && !hasStatuses && !hasLocations ) {
				return appointments;
			}
			return appointments.filter( function( appt ) {
				// Product filter: appointment must match ANY selected product
				if ( hasProducts ) {
					var apptPid = String( appt.product_id || '' );
					var productMatch = false;
					for ( var i = 0; i < reqProductIds.length; i++ ) {
						if ( apptPid === String( reqProductIds[ i ] ) ) {
							productMatch = true;
							break;
						}
					}
					if ( !productMatch ) {
						return false;
					}
				}
				// Staff filter: appointment must match ANY selected staff
				if ( hasStaff ) {
					var staffMatch = false;
					for ( var j = 0; j < reqStaffIds.length; j++ ) {
						var sid = reqStaffIds[ j ];
						if ( appointmentMatchesStaffFilterId( appt, sid ) ) {
							staffMatch = true;
							break;
						}
					}
					if ( !staffMatch ) {
						return false;
					}
				}
				// Location filter: appointment must match ANY selected location
				if ( hasLocations ) {
					var apptLid = String( appt.location_id || ( appt.extendedProps && appt.extendedProps.locationId ) || '' );
					var noLocation = ! apptLid || '0' === apptLid;
					var locationMatch = false;
					for ( var li = 0; li < reqLocationIds.length; li++ ) {
						var reqLid = String( reqLocationIds[ li ] );
						if ( 'none' === reqLid ? noLocation : ( ! noLocation && apptLid === reqLid ) ) {
							locationMatch = true;
							break;
						}
					}
					if ( !locationMatch ) {
						return false;
					}
				}
				// Status filter: appointment must match ANY selected status
				if ( hasStatuses ) {
					var apptStatus = String( appt.status || '' ).replace( /^wc-/, '' );
					var statusMatch = false;
					for ( var k = 0; k < reqStatusIds.length; k++ ) {
						if ( apptStatus === String( reqStatusIds[ k ] ).replace( /^wc-/, '' ) ) {
							statusMatch = true;
							break;
						}
					}
					if ( !statusMatch ) {
						return false;
					}
				}
				return true;
			} );
		}

		function updatePreloadedAppointment( apptId, newData ) {
			if ( !apptId || !newData ) {
				return;
			}
			var idStr = String( apptId );
			var start = parseInt( newData.start, 10 ) || 0;
			var end = parseInt( newData.end, 10 ) || start;
			var upsert = function( list, canInsert ) {
				if ( !Array.isArray( list ) ) {
					return;
				}
				for ( var i = 0; i < list.length; i++ ) {
					if ( String( list[ i ].id ) === idStr ) {
						for ( var k in newData ) {
							if ( newData.hasOwnProperty( k ) ) {
								list[ i ][ k ] = newData[ k ];
							}
						}
						return;
					}
				}
				if ( canInsert ) {
					list.push( newData );
				}
			};
			if ( preloadedDataRef.current && Array.isArray( preloadedDataRef.current.appointments ) ) {
				var pre = preloadedDataRef.current;
				upsert( pre.appointments, end > pre.startTs && start < pre.endTs );
			}
		}

		function clearPreloadedAppointments() {
			pendingAppointmentFetchesRef.current = {};
			preloadedDataRef.current = null;
		}

		function loadIsStale( gen ) {
			return gen !== loadGenRef.current;
		}

		function fetchAppointmentsForRange( startTs, endTs ) {
			var key = getRangeKey( startTs, endTs );
			if ( pendingAppointmentFetchesRef.current[ key ] ) {
				return pendingAppointmentFetchesRef.current[ key ];
			}
			if ( appointmentFetchControllerRef.current ) {
				try {
					appointmentFetchControllerRef.current.abort();
				} catch ( _abortPrev ) {}
			}
			abortAllGetRequests();
			var controller = ( window.AbortController ) ? new window.AbortController() : null;
			appointmentFetchControllerRef.current = controller;
			var ajaxUrl = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.ajaxUrl ) ? wcAppointmentsReactCalendar.ajaxUrl : '';
			var nonce = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.nonce ) ? wcAppointmentsReactCalendar.nonce : '';
			var body = new URLSearchParams();
			body.append( 'action', 'wc_appointments_admin_calendar_range' );
			body.append( 'security', nonce );
			body.append( 'start_ts', String( startTs ) );
			body.append( 'end_ts', String( endTs ) );
			var promise = fetch( ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: body.toString(),
				credentials: 'same-origin',
				signal: controller ? controller.signal : undefined
			} ).then( function( response ) {
				return response.text().then( function( text ) {
					try {
						return JSON.parse( text );
					} catch ( _parse ) {
						throw new Error( 'Invalid server response (HTTP ' + response.status + ').' );
					}
				} );
			} ).then( function( res ) {
				if ( !res || !res.success ) {
					var msg = ( res && res.data && res.data.message ) ? res.data.message : 'Calendar range fetch failed';
					throw new Error( msg );
				}
				return ensureArray( res.data );
			} ).finally( function() {
				delete pendingAppointmentFetchesRef.current[ key ];
				if ( controller && appointmentFetchControllerRef.current === controller ) {
					appointmentFetchControllerRef.current = null;
				}
			} );
			pendingAppointmentFetchesRef.current[ key ] = promise;
			return promise;
		}

		function scheduleAvailabilityLoad( startTs, endTs, processFn, loadGen ) {
			if ( skipAvailRef.current || false === __wcaRestApiAvailable || !availabilitiesDirtyRef.current ) {
				return;
			}
			var idle = window.requestIdleCallback || function( fn ) { setTimeout( fn, 0 ); };
			idle( function() {
				if ( loadIsStale( loadGen ) || isRequestsBlocked() ) {
					return;
				}
				var availFilters = resolveAvailabilityFilterIds( productIdRef.current, staffIdRef.current );
				fetchAvailabilityBuckets( apiGet, startTs, endTs, availFilters.availProductId, availFilters.availStaffParam ).then( function( res ) {
					if ( loadIsStale( loadGen ) ) {
						return;
					}
					var fn = processFn || window.__wcaProcessAvailability;
					if ( 'function' === typeof fn ) {
						fn( res, startTs, endTs, availFilters.availProductId, availFilters.availStaffParam );
					}
					availabilitiesDirtyRef.current = false;
				} ).catch( function( err ) {
					if ( loadIsStale( loadGen ) || ( err && ( 'AbortError' === err.name || /Blocked during drag\/resize/i.test( String( err.message || '' ) ) ) ) ) {
						return;
					}
					console.error( 'Failed to fetch availability rules:', err );
				} );
			} );
		}

		function removePreloadedAppointment( apptId ) {
			if ( !apptId ) {
				return;
			}
			var idStr = String( apptId );
			var filter = function( appt ) {
				return String( appt.id ) !== idStr;
			};
			if ( preloadedDataRef.current && Array.isArray( preloadedDataRef.current.appointments ) ) {
				preloadedDataRef.current.appointments = preloadedDataRef.current.appointments.filter( filter );
			}
		}

		/**
		 * Calculate month date range for month view (accounting for week start offsets)
		 * @param {Date} date - Date within the month
		 * @returns {Object} Object with startTs and endTs
		 */
		function calculateMonthRange( date ) {
			var year = date.getFullYear();
			var month = date.getMonth();
			var startOfWeek = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.firstDay !== undefined ) ? wcAppointmentsReactCalendar.firstDay : 0;
			var firstDay = new Date( year, month, 1 );
			var lastDay = new Date( year, month + 1, 0 );
			var dayOffset = ( firstDay.getDay() - startOfWeek + 7 ) % 7;
			var endDayOffset = 7 - ( ( lastDay.getDate() + dayOffset ) % 7 );
			if ( 7 === endDayOffset ) {
				endDayOffset = 0;
			}
			var startTs = Math.floor( ( firstDay.getTime() - ( dayOffset * 86400 * 1000 ) ) / 1000 );
			var endTs = Math.floor( ( lastDay.getTime() + ( ( endDayOffset + 1 ) * 86400 * 1000 ) ) / 1000 );
			return { startTs: startTs, endTs: endTs };
		}

		/** Union of prev/current/next month grids — must match PHP get_preloaded_appointments() for month view. */
		function getMonthViewPreloadRange( anchorDate ) {
			var anchor = anchorDate instanceof Date ? anchorDate : new Date( anchorDate );
			var y = anchor.getFullYear();
			var m = anchor.getMonth();
			var startTs = Infinity;
			var endTs = 0;
			for ( var offset = -1; offset <= 1; offset++ ) {
				var range = calculateMonthRange( new Date( y, m + offset, 1 ) );
				startTs = Math.min( startTs, range.startTs );
				endTs = Math.max( endTs, range.endTs );
			}
			return { startTs: startTs, endTs: endTs };
		}

		function recordSseInjection( id, eventObj ) {
			try {
				if ( !id ) {
					return;
				}
				var key = String( id );
				sseInjectedIdsRef.current[ key ] = true;
				if ( eventObj && 'function' === typeof eventObj.setExtendedProp ) {
					eventObj.setExtendedProp( '__wcaSseInjected', true );
				} else if ( eventObj && eventObj.extendedProps ) {
					eventObj.extendedProps.__wcaSseInjected = true;
				}
			} catch ( _ ) {}
		}

		function clearSseInjectionFlag( id ) {
			try {
				if ( !id ) {
					return;
				}
				delete sseInjectedIdsRef.current[ String( id ) ];
			} catch ( _ ) {}
		}

		function cleanupSseInjectedEvents() {
			try {
				var ids = Object.keys( sseInjectedIdsRef.current || {} );
				if ( !ids.length ) {
					return;
				}
				var cal = calRef.current;
				if ( !cal || 'function' !== typeof cal.getEventById ) {
					return;
				}
				ids.forEach( function( id ) {
					try {
						var ev = cal.getEventById( 'appt-' + String( id ) );
						if ( ev && ev.extendedProps && ev.extendedProps.__wcaSseInjected ) {
							ev.remove();
						}
					} catch ( _e ) {}
					clearSseInjectionFlag( id );
				} );
			} catch ( _ ) {}
		}

		function triggerCalendarRefetch() {
			try {
				if ( calRef.current && 'function' === typeof calRef.current.refetchEvents ) {
					calRef.current.refetchEvents();
				}
			} catch ( _ ) {}
		}

		var filtersMountedRef = useRef( false );
		var prevProductStaffRef = useRef( { productIds: productIds, staffIds: staffIds } );
		useEffect( function() {
			// Update refs synchronously before re-rendering events (for use in events function)
			productIdRef.current = productId;
			staffIdRef.current = staffId;
			productIdsRef.current = productIds;
			staffIdsRef.current = staffIds;
			locationIdsRef.current = locationIds;
			statusIdsRef.current = statusIds;
			var prevProductStaff = prevProductStaffRef.current;
			var productStaffChanged = JSON.stringify( prevProductStaff.productIds ) !== JSON.stringify( productIds )
				|| JSON.stringify( prevProductStaff.staffIds ) !== JSON.stringify( staffIds );
			prevProductStaffRef.current = { productIds: productIds, staffIds: staffIds };
			try {
				if ( !window.wcAppointmentsReactCalendar ) {
					return;
				}
				window.wcAppointmentsReactCalendar.productId = productId || '';
				window.wcAppointmentsReactCalendar.staffId = staffId || '';
			} catch ( e ) {}
			// Appointments filter client-side from server preload; only availability rules refetch when product/staff change.
			if ( filtersMountedRef.current && productStaffChanged ) {
				availabilitiesDirtyRef.current = true;
			}
			filtersMountedRef.current = true;
			// Re-run events source with updated filter refs (preload hit = instant, no API).
			triggerCalendarRefetch();
		}, [ productId, staffId, productIds, staffIds, locationIds, statusIds ] );

		// Do not load product/staff lists on page load; filter data is preloaded from PHP

		useEffect( function() {
			setEmptyTip( false );
			if ( !calElRef.current || !window.FullCalendar || !window.FullCalendar.Calendar ) {
				setError( t( 'calendarLibFailed', 'Calendar library failed to load.' ) );
				return;
			}
			var timePattern = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.timeFormat ) ? wcAppointmentsReactCalendar.timeFormat : 'g:i a';
			var fcTimeFormat = buildFullCalendarTimeFormat( timePattern );

			// Check REST API availability on mount
			checkRestApiAvailability().then( function( available ) {
				if ( !available ) {
					setError( t( 'restApiUnavailable', 'REST API is not available. Calendar will display preloaded appointments only. Please contact your administrator if this persists.' ) );
				}
			} ).catch( function() {
				// Silently continue - preloaded appointments will still work
			} );

			// Order-note / confirm range parts (date + optional time).
			function __formatNoteParts( startTs, endTs, allDay ) {
				var dateFmt = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.dateFormat ) ? wcAppointmentsReactCalendar.dateFormat : 'F j, Y';
				var timeFmt = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.timeFormat ) ? wcAppointmentsReactCalendar.timeFormat : 'g:i a';
				var showDaysOnly = !!allDay || isAllDayRangeTs( startTs || 0, endTs || 0 );
				var sD = new Date( ( startTs || 0 ) * 1000 );
				if ( showDaysOnly ) {
					var eInc = new Date( ( Math.max( 0, ( endTs || 0 ) - 1 ) ) * 1000 );
					var s = formatDateByPattern( sD, dateFmt );
					var e = formatDateByPattern( eInc, dateFmt );
					return { date: ( s === e ) ? s : ( s + ' – ' + e ), time: '' };
				}
				var eD = new Date( ( endTs || 0 ) * 1000 );
				var sDate = formatDateByPattern( sD, dateFmt );
				var eDate = formatDateByPattern( eD, dateFmt );
				return {
					date: ( sDate === eDate ) ? sDate : ( sDate + ' – ' + eDate ),
					time: formatTimeByPattern( sD, timeFmt ) + ' – ' + formatTimeByPattern( eD, timeFmt )
				};
			}

			function __formatNoteRange( startTs, endTs, allDay ) {
				var parts = __formatNoteParts( startTs, endTs, allDay );
				return parts.time ? ( parts.date + ', ' + parts.time ) : parts.date;
			}

			function hexToRgb( hex ) {
				if ( !hex || 'string' !== typeof hex ) {
					return null;
				}
				var h = hex.trim();
				if ( '#' === h.charAt( 0 ) ) {
					h = h.slice( 1 );
				}
				if ( 3 === h.length ) {
					var r3 = parseInt( h.charAt( 0 ) + h.charAt( 0 ), 16 );
					var g3 = parseInt( h.charAt( 1 ) + h.charAt( 1 ), 16 );
					var b3 = parseInt( h.charAt( 2 ) + h.charAt( 2 ), 16 );
					if ( isNaN( r3 ) || isNaN( g3 ) || isNaN( b3 ) ) {
						return null;
					}
					return [ r3, g3, b3 ];
				}
				if ( 6 === h.length ) {
					var r = parseInt( h.slice( 0, 2 ), 16 );
					var g = parseInt( h.slice( 2, 4 ), 16 );
					var b = parseInt( h.slice( 4, 6 ), 16 );
					if ( isNaN( r ) || isNaN( g ) || isNaN( b ) ) {
						return null;
					}
					return [ r, g, b ];
				}
				return null;
			}

			function relLum( rgb ) {
				function comp( c ) {
					var s = c / 255;
					return 0.03928 >= s ? ( s / 12.92 ) : Math.pow( ( s + 0.055 ) / 1.055, 2.4 );
				}
				return ( 0.2126 * comp( rgb[ 0 ] ) ) + ( 0.7152 * comp( rgb[ 1 ] ) ) + ( 0.0722 * comp( rgb[ 2 ] ) );
			}

			function chooseTextColor( bgHex ) {
				var rgb = hexToRgb( bgHex );
				if ( !rgb ) {
					return '#000000';
				}
				var l = relLum( rgb );
				var crWhite = ( 1 + 0.05 ) / ( l + 0.05 );
				var crBlack = ( l + 0.05 ) / 0.05;
				return crWhite >= crBlack ? '#ffffff' : '#000000';
			}

			// Convert a Date's local wall-clock into a naive epoch by composing UTC
			// from local components. This prevents timezone offsets from shifting
			// the saved time when persisting drag/resize operations.

			// Build absolute REST URL from plugin base
			function restUrl( path ) {
				var base = wcAppointmentsReactCalendar.restUrl;
				if ( '/' !== base.slice( -1 ) ) {
					base += '/';
				}
				return base + String( path ).replace( /^\//, '' );
			}

			// PUT JSON helper for updating appointments via REST
			function apiPutJSON( path, payload ) {
				return retryOnServerError( function() {
					return fetch( restUrl( path ), {
						method: 'PUT',
						headers: {
							'Content-Type': 'application/json',
							'X-WP-Nonce': wcAppointmentsReactCalendar.nonce
						},
						body: JSON.stringify( payload )
					} ).then( function( r ) {
						if ( !r.ok ) {
							throw new Error( 'HTTP ' + r.status );
						}
						return r.json();
					} );
				} );
			}

			// POST JSON helper
			function apiPostJSON( path, payload ) {
				return retryOnServerError( function() {
					return fetch( restUrl( path ), {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
							'X-WP-Nonce': wcAppointmentsReactCalendar.nonce
						},
						body: JSON.stringify( payload )
					} ).then( function( r ) {
						if ( !r.ok ) {
							throw new Error( 'HTTP ' + r.status );
						}
						return r.json();
					} );
				} );
			}

			function addOrderNote( orderId, message, customerNote ) {
				if ( !orderId ) {
					return Promise.resolve();
				}
				var path = 'wc/v3/orders/' + String( orderId ) + '/notes';
				var payload = {
					note: String( message || '' ),
					customer_note: !!customerNote
				};
				return apiPostJSON( path, payload ).catch( function() {} );
			}
			try {
				window.__wcaAddOrderNote = addOrderNote;
				window.__wcaFormatNoteRange = __formatNoteRange;
			} catch ( __ ) {}

			/**
		 * Compute start/end timestamps from FullCalendar event with timezone conversion
		 *
		 * TIMEZONE HANDLING:
		 * =================
		 * This function processes FullCalendar event objects and converts them to UTC timestamps
		 * that the server can understand. It uses dateToNaiveEpoch() to handle timezone conversion
		 * when staff are in different timezones than the site.
		 *
		 * The function handles:
		 * - Single date/time events: Convert both start and end times
		 * - All-day events: Calculate proper day boundaries
		 * - Drag operations without resize: Preserve original duration
		 *
		 * Examples:
		 * - Staff in same timezone: 07:00 → 07:00 UTC timestamp
		 * - Staff in different timezone: 07:00 admin → 08:00 site → 08:00 UTC timestamp
		 *
		 * @param {Object} ev - FullCalendar event object with start/end Date objects
		 * @param {Object} prev - Previous event data for duration preservation
		 * @return {Object} Object with start, end, and all_day properties for server
		 */
			function computeTimesFromEvent( ev, prev ) {
				var startTs;
				var endTs = 0;

				if ( ev.allDay ) {
					// ALL-DAY OR OVERNIGHT EVENTS: date-only grid position in Month view.
					var day = 86400; // 24 hours in seconds
					var ds = ev.start;

					// If this is a timed appointment (overnight duration) being dragged in
					// Month view, it's rendered as allDay: true because it spans multiple days.
					// We must preserve its original time components from prev data.
					var isTimed = prev && ( 'hour' === prev.durationUnit || 'minute' === prev.durationUnit );

					if ( isTimed && prev.start_ts ) {
						var ost = new Date( prev.start_ts * 1000 );
						startTs = Math.floor( Date.UTC( ds.getFullYear(), ds.getMonth(), ds.getDate(), ost.getUTCHours(), ost.getUTCMinutes(), ost.getUTCSeconds() ) / 1000 );
					} else {
						// ALL-DAY EVENTS: date-only — no timezone conversion.
						// Extract calendar date components directly from FullCalendar's Date
						// object and form a naive midnight UTC timestamp (same convention as
						// the server-side strtotime("YYYY-MM-DD") naive storage).
						startTs = Math.floor( Date.UTC( ds.getFullYear(), ds.getMonth(), ds.getDate(), 0, 0, 0 ) / 1000 );
					}

					if ( ev.end ) {
						var de = ev.end;
						if ( isTimed && prev.end_ts ) {
							var oen = new Date( prev.end_ts * 1000 );
							var eh = oen.getUTCHours();
							var em = oen.getUTCMinutes();
							var es = oen.getUTCSeconds();
							// FullCalendar's allDay end date is exclusive (starts at 00:00 of the day after).
							// Our timed end_ts represents an inclusive boundary during the day.
							// If the original end time was NOT exactly at midnight (00:00), it means 
							// FullCalendar has shifted the end date forward by one day to represent
							// the full-day block covering that timed end. We must subtract 1 day back.
							var needsDayShift = ( eh !== 0 || em !== 0 || es !== 0 );
							var endRefDate = de;
							if ( needsDayShift ) {
								endRefDate = new Date( de.getTime() - 86400000 );
							}
							endTs = Math.floor( Date.UTC( endRefDate.getFullYear(), endRefDate.getMonth(), endRefDate.getDate(), eh, em, es ) / 1000 );
						} else {
							// End is exclusive in FullCalendar; subtract 1 s to make it inclusive.
							var endExclusive = Math.floor( Date.UTC( de.getFullYear(), de.getMonth(), de.getDate(), 0, 0, 0 ) / 1000 );
							endTs = Math.max( startTs, endExclusive - 1 );
						}
					} else {
						if ( isTimed ) {
							var originalDuration = ( ( prev && prev.end_ts ) || 0 ) - ( ( prev && prev.start_ts ) || 0 );
							endTs = startTs + Math.max( 1, originalDuration );
						} else {
							endTs = startTs + day - 1;
						}
					}
				} else {
					// TIME-BASED EVENTS: apply admin timezone conversion.
					startTs = dateToNaiveEpoch( ev.start );
					if ( ev.end ) {
						endTs = dateToNaiveEpoch( ev.end );
					} else {
						var originalDuration = ( ( prev && prev.end_ts ) || 0 ) - ( ( prev && prev.start_ts ) || 0 );
						endTs = startTs + Math.max( 1, originalDuration );
					}
				}

				return {
					start: startTs,
					end: endTs,
					all_day: !!ev.allDay
				};
			}

			// Update appointment schedule via REST and refresh calendar
			function updateAppointmentSchedule( apptId, payload, revert, ctx ) {
				return apiPutJSON( 'wc-appointments/v2/appointments/' + String( apptId ), payload )
					.then( function( response ) {
						try {
							var s = response && 'object' === typeof response && !Array.isArray( response ) ? response : null;
							var startTs = ( s && null != s.start ) ? s.start : payload.start;
							var endTs = ( s && null != s.end ) ? s.end : payload.end;
							var rawAd = ( s && null != s.all_day ) ? s.all_day : payload.all_day;
							var allDayNum = ( true === rawAd || 1 === +rawAd ) ? 1 : 0;

							updatePreloadedAppointment( apptId, {
								start: startTs,
								end: endTs,
								all_day: allDayNum
							} );

							var ev = ctx && ctx.fcEvent;
							if ( ev && 'function' === typeof ev.setExtendedProp ) {
								ev.setExtendedProp( 'start_ts', startTs );
								ev.setExtendedProp( 'end_ts', endTs );
							}

							var wp = window.wcaPanel;
							if ( wp && 'function' === typeof wp.updateApptData ) {
								wp.updateApptData( apptId, {
									start_ts: startTs,
									end_ts: endTs,
									start: startTs,
									end: endTs,
									all_day: allDayNum
								} );
							}

							var note = ( ctx && ctx.note ) || t( 'appointmentUpdatedNote', 'Appointment #' + String( apptId ) + ' updated.' );
							if ( ctx && ctx.orderId ) {
								addOrderNote( ctx.orderId, note, !!ctx.notifyCustomer );
							}

							// Always show the drag/drop toast immediately and suppress any
							// subsequent SSE toasts for this appointment. The server may fire
							// both appointment.updated and appointment.rescheduled events for
							// the same drag operation, so relying on SSE to show the toast
							// can produce duplicates.
							var ext = ( ev && ev.extendedProps ) || {};
							var customerName = ext.customerName || t( 'guest', 'Guest' );
							var dragAllDay = !!allDayNum || isAllDayRangeTs( startTs || 0, endTs || 0 );
							var dateTimeStr = formatToastWhen( startTs || 0, endTs || 0, dragAllDay );
							var toastMsg = buildSemanticToastMessage(
								t( 'toastAppointmentRescheduledSemantic', 'Appointment #{id} with {customer} rescheduled to {datetime}' ),
								{ customer: customerName, datetime: dateTimeStr, id: apptId }
							);
							showToast( toastMsg, 'success' );
							markLocalToastSuppression( apptId, 'rescheduled' );
							// Mark as seen to suppress duplicate SSE toasts.
							try {
								var toastKey = 'appt:' + String( apptId ) + ':' + toastMsg.substring( 0, 40 );
								__wcaToastSeen[ toastKey ] = Date.now();
								// Also mark the broad reschedule key so SSE events with
								// different customer name resolution are still suppressed.
								__wcaToastSeen[ 'appt:' + String( apptId ) + ':reschedule' ] = Date.now();
							} catch ( _ ) {}

						} catch ( error ) {
							console.error( error );
						}
					} )
					.catch( function( error ) {
						console.error( error );
						try {
							if ( 'function' === typeof revert ) {
								revert();
							}
						} catch ( _ ) {}
					} );
			}

			// Interval helpers used by availability rendering (kept here for reuse/testing)
			// clampIntervalToWindow not used directly; available for reuse via window export
			function clampIntervalToWindow( s, e, winStart, winEnd ) {
				var ss = Math.max( winStart, s || 0 );
				var ee = Math.min( winEnd, e || 0 );
				return ee > ss ? [ ss, ee ] : null;
			}
			try {
				window.__wcaClampIntervalToWindow = clampIntervalToWindow;
			} catch ( _ce ) {}

			function seriesExtendedFields( row, seriesId ) {
				return {
					seriesId: seriesId || 0,
					seriesOccurrence: row.series_occurrence || 0,
					seriesCountCap: row.series_count_cap || 0,
					seriesCheckoutOrderId: row.series_checkout_order_id || 0,
					seriesPayment: row.series_payment || null,
					seriesPatternSummary: row.series_pattern_summary || '',
					seriesOccurrences: row.series_occurrences || null
				};
			}

			// Create a FullCalendar event object from an appointment row
			function buildAppointmentEvent( row, usersIndex, colorsIndex ) {
				var st = row.start;
				var en = row.end;
				var staffArr = Array.isArray( row.staff_ids ) ? row.staff_ids : ( Array.isArray( row.staff_id ) ? row.staff_id : ( row.staff_id ? [ row.staff_id ] : [] ) );
				var staffSingle = staffArr && staffArr.length ? staffArr[ 0 ] : '';
				var isAllDay = !!row.all_day || isAllDayRangeTs( st, en );
				var idAppt = 'appt-' + String( row.id || ( st + '-' + en ) );
				var custObj = ( usersIndex || {} )[ row.customer_id ] || {};
				var hasCustomer = 0 < parseInt( row.customer_id, 10 );
				// Prefer customer name fields directly from row (included in v2 API response), fallback to index
				var fn = row.customer_first_name || custObj.first_name || '';
				var ln = row.customer_last_name || custObj.last_name || '';
				var full = row.customer_full_name || ( ( fn || ln ) ? ( ( fn + ' ' + ln ).trim() ) : '' );
				var custName = full || row.customer_name || custObj.name || ( hasCustomer ? t( 'customer', 'Customer' ) : t( 'guest', 'Guest' ) );
				var seriesId = parseInt( row.series_id || row.seriesId || 0, 10 );
				var seriesPrefix = seriesId ? '\u21BB ' : '';
				if ( isAllDay ) {
					var day = 86400;
					// Day-based appointments are date-only values (no time component).
					// Do NOT apply timezone offset — "March 16" is March 16 for every
					// viewer regardless of their timezone vs the site timezone.
					var startDate = tsToNaiveLocalDate( Math.floor( st / day ) * day );
					var endExclusiveTs = ( Math.floor( ( en - 1 ) / day ) + 1 ) * day;
					var endDateExclusive = tsToNaiveLocalDate( endExclusiveTs );

					var displayTitle = custName;
					var durationUnit = row.duration_unit || '';
					// Overnight appointments (hour/minute based) show start time in month view block
					if ( 'hour' === durationUnit || 'minute' === durationUnit ) {
						var timePattern = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.timeFormat ) ? wcAppointmentsReactCalendar.timeFormat : 'g:i a';
						var startHour = formatTimeByPattern( new Date( convertToAdminTimezone( st ) * 1000 ), timePattern );
						displayTitle = startHour + ' ' + custName;
					}

					var evt0 = {
						id: idAppt,
						title: seriesPrefix + displayTitle,
						start: startDate,
						end: endDateExclusive,
						allDay: true,
					extendedProps: Object.assign( {
						appointmentId: row.id,
						productId: row.product_id,
						productTitle: row.product_title || '',
						calColor: row.cal_color || ( colorsIndex && colorsIndex[ String( row.product_id ) ] ? String( colorsIndex[ String( row.product_id ) ] ) : '' ),
						durationUnit: row.duration_unit || '',
						duration: row.duration || 0,
						staffId: staffSingle,
						staffName: row.staff_name || '',
						staffAvatar: row.staff_avatar || '',
						locationId: row.location_id || 0,
						locationDisplay: row.location_display || '',
						resourceDisplay: row.resource_display || '',
						resourceAllocations: Array.isArray( row.resource_allocations ) ? row.resource_allocations : [],
						meetingJoinUrl: row.meeting_join_url || '',
						status: row.status || '',
						start_ts: st,
						end_ts: en,
						customerId: row.customer_id,
						customerName: custName || '',
						customerFirstName: fn || '',
						customerLastName: ln || '',
						customerEmail: row.customer_email || '',
						customerPhone: row.customer_phone || '',
						customerStatus: row.customer_status || '',
						customerAvatar: row.customer_avatar || '',
						orderId: row.order_id,
						orderItemId: row.order_item_id,
						orderInfo: row.order_info || null,
						cost: row.cost,
						qty: row.qty || 1,
						local_timezone: row.local_timezone || '',
						customer_timezone: row.customer_timezone || ''
					}, seriesExtendedFields( row, seriesId ) )
				};
				// Prefer cal_color directly from row (included in v2 API response), fallback to index
				var clr0 = row.cal_color || ( colorsIndex && colorsIndex[ String( row.product_id ) ] ? String( colorsIndex[ String( row.product_id ) ] ) : '' );
					if ( clr0 ) {
						evt0.backgroundColor = clr0;
						evt0.borderColor = clr0;
						evt0.color = clr0;
						evt0.textColor = chooseTextColor( clr0 );
					}
					// Cache state for change detection in toast notifications
					cacheApptState( row.id, row.status, st, en );
					return evt0;
				}
				var evt1 = {
					id: idAppt,
					title: seriesPrefix + custName,
					start: tsToAdminLocalISO( st ),
					end: tsToAdminLocalISO( en ),
					allDay: false,
					extendedProps: Object.assign( {
						appointmentId: row.id,
						productId: row.product_id,
						productTitle: row.product_title || '',
						calColor: row.cal_color || ( colorsIndex && colorsIndex[ String( row.product_id ) ] ? String( colorsIndex[ String( row.product_id ) ] ) : '' ),
						durationUnit: row.duration_unit || '',
						duration: row.duration || 0,
						staffId: staffSingle,
						staffName: row.staff_name || '',
						staffAvatar: row.staff_avatar || '',
						locationId: row.location_id || 0,
						locationDisplay: row.location_display || '',
						resourceDisplay: row.resource_display || '',
						resourceAllocations: Array.isArray( row.resource_allocations ) ? row.resource_allocations : [],
						meetingJoinUrl: row.meeting_join_url || '',
						status: row.status || '',
						start_ts: st,
						end_ts: en,
						customerId: row.customer_id,
						customerName: custName || '',
						customerFirstName: fn || '',
						customerLastName: ln || '',
						customerEmail: row.customer_email || '',
						customerPhone: row.customer_phone || '',
						customerStatus: row.customer_status || '',
						customerAvatar: row.customer_avatar || '',
						orderId: row.order_id,
						orderItemId: row.order_item_id,
						orderInfo: row.order_info || null,
						cost: row.cost,
						qty: row.qty || 1,
						local_timezone: row.local_timezone || '',
						customer_timezone: row.customer_timezone || ''
					}, seriesExtendedFields( row, seriesId ) )
				};
				// Prefer cal_color directly from row (included in v2 API response), fallback to index
				var clr1 = row.cal_color || ( colorsIndex && colorsIndex[ String( row.product_id ) ] ? String( colorsIndex[ String( row.product_id ) ] ) : '' );
				if ( clr1 ) {
					evt1.backgroundColor = clr1;
					evt1.borderColor = clr1;
					evt1.color = clr1;
					evt1.textColor = chooseTextColor( clr1 );
				}
				// Cache state for change detection in toast notifications
				cacheApptState( row.id, row.status, st, en );
				return evt1;
			}
			try {
				window.__wcaBuildAppointmentEvent = buildAppointmentEvent;
			} catch ( _ ) {}

			/**
	 * Convert Date object to UTC timestamp with proper timezone conversion for calendar operations
	 * Delegates to centralized timezone utilities.
	 *
	 * @param {Date} d - Date object from FullCalendar (represents admin timezone time when staff differs)
	 * @return {number} UTC timestamp representing site timezone time
	 */
		function dateToNaiveEpoch( d ) {
			if ( !d || !( d instanceof Date ) ) {
				return 0;
			}

			// Get timezone configuration
			var params = window.wc_appointments_writepanel_js_params || {};
			var adminTz = params.admin_timezone || 'UTC';
			var siteTz = params.site_timezone || 'UTC';
			var hasDifferentTz = !!(adminTz && siteTz && adminTz !== siteTz);

			// Check if timezone utils are available
			var utils = window.WCAppointmentsTimezoneUtils;

			if ( utils && hasDifferentTz ) {
				try {
					// Use timezone utils for proper conversion
					var convertedTimestamp = utils.convertAdminDateToSiteTimestamp( d );

					// Validate the conversion result
					if ( convertedTimestamp && convertedTimestamp > 0 ) {
						return convertedTimestamp;
					} else {
						throw new Error('Invalid timezone conversion result');
					}
				} catch ( conversionError ) {
					// Fallback: treat the input as if it's already in site timezone
					return Math.floor( Date.UTC( d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds() ) / 1000 );
				}
			} else {
				// When timezones are the same, just convert to UTC timestamp directly
				// This represents site timezone time since admin = site
				return Math.floor( Date.UTC( d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds() ) / 1000 );
			}
		}

			// Store preloaded appointments for use in events function.
			// Empty [] is a valid PHP result (none in the three-month window); still seed the
			// covering range so first paint and in-range view switches skip REST + loading bar.
			try {
				var preloaded = ( wcAppointmentsReactCalendar && Array.isArray( wcAppointmentsReactCalendar.preloadedAppointments ) )
					? wcAppointmentsReactCalendar.preloadedAppointments
					: null;
				if ( null !== preloaded ) {
					// Calculate preloaded range — always month-equivalent (prev/current/next grids)
					// so view switches are instant regardless of initial view (must match PHP).
					var initialDate = initialDateParam || '';
					var dayTs = initialDate ? ( new Date( initialDate ).getTime() / 1000 ) : ( Date.now() / 1000 );
					var monthPreload = getMonthViewPreloadRange( new Date( dayTs * 1000 ) );
					var preloadStartTs = monthPreload.startTs;
					var preloadEndTs = monthPreload.endTs;

					var apptsFiltered = preloaded.filter( function( row ) {
						return row && !isExcludedStatus( row.status );
					} );

					if ( window.panelSeries && window.panelSeries.indexPreloadFromRows ) {
						window.panelSeries.indexPreloadFromRows( apptsFiltered );
					}

					preloadedDataRef.current = {
						startTs: preloadStartTs,
						endTs: preloadEndTs,
						appointments: apptsFiltered
					};
				}
			} catch ( _ ) {}

			function openDayFromMonth( date ) {
				// ≤782px month tap → day view; stash month currentStart for Back.
				var v = calRef.current && calRef.current.view;
				monthReturnYmdRef.current = dateToYmd( ( v && v.currentStart ) || date );
				setShowMonthBack( true );
				changeView( 'timeGridDay', date );
			}

			// Hide fixed toolbar as soon as Screen Options/Help opens (WP adds .screen-meta-active after slideDown).
			if ( window.jQuery && !window.__wcaScreenMetaToolbarBound ) {
				window.__wcaScreenMetaToolbarBound = true;
				window.jQuery( document ).on( 'screen:options:open', function() {
					document.body.classList.add( 'wca-screen-meta-open' );
				} ).on( 'screen:options:close', function() {
					document.body.classList.remove( 'wca-screen-meta-open' );
				} );
			}

			function handlePanelCreate( data ) {
				if ( data && data.post_create_redirect && window.wcaPanel && window.wcaPanel.navigateAfterAdminCreate ) {
					window.wcaPanel.navigateAfterAdminCreate( data );
					return;
				}
				var apptId = data && data.appointment_id ? parseInt( data.appointment_id, 10 ) : 0;
				if ( apptId ) {
					panelTargetApptIdRef.current = String( apptId );
					if ( window.__wcaInjectAppointment ) {
						window.__wcaInjectAppointment( apptId );
					} else {
						clearPreloadedAppointments();
						triggerCalendarRefetch();
					}
					return;
				}
				clearPreloadedAppointments();
				triggerCalendarRefetch();
			}

			function buildCreatePanelCallbacks() {
				return {
					onCreate: handlePanelCreate,
					onClose: removeAllPanelHighlights,
					removeHighlight: removeAllPanelHighlights
				};
			}
			window.__wcaBuildCreatePanelCallbacks = buildCreatePanelCallbacks;

			function removeAllPanelHighlights() {
				try {
					panelTargetApptIdRef.current = null;
					var els = document.querySelectorAll( '.wca-event--panel-target' );
					for ( var hi = 0; hi < els.length; hi++ ) {
						els[ hi ].classList.remove( 'wca-event--panel-target' );
					}
					var harnesses = document.querySelectorAll( '.wca-event-harness--panel-target' );
					for ( var hj = 0; hj < harnesses.length; hj++ ) {
						harnesses[ hj ].classList.remove( 'wca-event-harness--panel-target' );
					}
					if ( window.__wcaCalPreview ) {
						window.__wcaCalPreview.remove();
					}
				} catch ( _ ) {}
			}

			/** Mark selected event + its FC harness (overlap stacking lives on the harness). */
			function markPanelTarget( el ) {
				if ( ! el ) { return; }
				try {
					el.classList.add( 'wca-event--panel-target' );
					var harness = el.closest ? el.closest( '.fc-timegrid-event-harness, .fc-daygrid-event-harness' ) : null;
					if ( harness ) {
						harness.classList.add( 'wca-event-harness--panel-target' );
					}
				} catch ( _ ) {}
			}

			function dispatchAppointmentsUpdated() {
				try { window.dispatchEvent( new Event( 'wc_appointments_updated' ) ); } catch ( _ ) {}
			}

			function apptDataForCalendarId( apptId ) {
				var cal = calRef.current;
				var ev = cal && 'function' === typeof cal.getEventById
					? cal.getEventById( 'appt-' + String( apptId ) )
					: null;
				if ( ev && ev.extendedProps && window.panelSeries && window.panelSeries.apptFromExtendedProps ) {
					return window.panelSeries.apptFromExtendedProps( ev.extendedProps );
				}
				return { id: apptId };
			}

			function openCalendarView( apptId, eventEl ) {
				window.wcaPanel.open( {
					mode: 'view',
					apptData: apptDataForCalendarId( apptId ),
					triggerEl: eventEl,
					triggerRect: eventEl ? eventEl.getBoundingClientRect() : null,
					callbacks: {
						onClose: removeAllPanelHighlights,
						onSave: dispatchAppointmentsUpdated,
						onDelete: dispatchAppointmentsUpdated,
						highlightEvent: function( el ) {
							removeAllPanelHighlights();
							panelTargetApptIdRef.current = String( apptId );
							markPanelTarget( el );
						},
						removeHighlight: removeAllPanelHighlights
					}
				} );
			}

			function openViewById( apptId, startTs ) {
				if ( !apptId || !window.wcaPanel || !window.wcaPanel.panelEnabled ) {
					return false;
				}
				function tryOpen( scrollAfter ) {
					var eventEl = apptEventElRef.current[ String( apptId ) ] || null;
					if ( !eventEl ) {
						return false;
					}
					openCalendarView( apptId, eventEl );
					if ( scrollAfter ) {
						var calApi = window.__wcaCalPreview;
						if ( calApi && calApi.scrollToAnchor ) {
							calApi.scrollToAnchor( eventEl, true );
						}
					}
					return true;
				}
				if ( tryOpen( false ) ) {
					return true;
				}
				var dateStr = startTs ? tsToNaiveLocalDate( startTs ) : '';
				var calApi = window.__wcaCalPreview;
				if ( dateStr && calApi && calApi.navigateTo ) {
					setTimeout( function() { tryOpen( true ); }, calApi.navigateTo( dateStr ) ? 500 : 100 );
					return true;
				}
				return false;
			}

			/** Open create panel from calendar pick; dedupe dateClick + select on one click. */
			function openCreatePanelFromCalendarPick( pick ) {
				if ( !window.wcaPanel || !window.wcaPanel.panelEnabled || !window.wcaPanel.open ) {
					return false;
				}
				// Rule stripe tap: tip only — do not also open create.
				if ( ( Date.now() - ( suppressCreateFromRuleTapRef.current || 0 ) ) < 500 ) {
					return false;
				}
				var pickKey = String( pick.startTs || 0 ) + '|' + String( pick.endTs || 0 ) + '|' + ( pick.allDay ? '1' : '0' );
				var nowMs = Date.now();
				if ( lastCreatePickRef.current.key === pickKey && ( nowMs - lastCreatePickRef.current.ts ) < 500 ) {
					return false;
				}
				lastCreatePickRef.current = { ts: nowMs, key: pickKey };
				window.wcaPanel.open( {
					mode: 'create',
					prefill: {
						startTs: pick.startTs,
						endTs: pick.endTs,
						allDay: !!pick.allDay,
						productId: productIdRef.current,
						staffId: staffIdRef.current
					},
					triggerEl: pick.triggerEl || null,
					triggerRect: pick.triggerRect || null,
					callbacks: buildCreatePanelCallbacks()
				} );
				return true;
			}

			function setDragRequestBlocking( isBlocked ) {
				try {
					setRequestsBlocked( isBlocked );
					dragInProgressRef.current = isBlocked;
				} catch ( e ) {}
			}

			// Anchored reschedule confirm (same scroll/anchor source as create/view panel).
			function confirmReschedule( opts ) {
				return new Promise( function( resolve ) {
					var settled = false;
					var from = opts.from || {};
					var to = opts.to || {};
					var note = opts.note || '';
					var notifyHint = opts.notifyHint || '';
					var el = document.createElement( 'div' );
					el.className = 'wca-rsc';
					el.setAttribute( 'role', 'dialog' );
					el.setAttribute( 'aria-modal', 'true' );

					function pathLi( parts, isTo ) {
						return '<li' + ( isTo ? ' class="is-to"' : '' ) + '>' +
							( parts.date ? '<span class="wca-rsc__date">' + escHtml( parts.date ) + '</span>' : '' ) +
							( parts.time ? '<span class="wca-rsc__time">' + escHtml( parts.time ) + '</span>' : '' ) +
							'</li>';
					}
					// Match layoutPanel: GAP 8, PANEL_TOP_NUDGE 24, bottom inset 12.
					function place() {
						var pad = 8;
						var rect = opts.rect;
						var vpW = window.innerWidth;
						var vpH = window.innerHeight;
						var w = el.offsetWidth;
						var h = el.offsetHeight;
						var x = Math.max( pad, ( vpW - w ) / 2 );
						var y = Math.max( pad, Math.round( vpH * 0.12 ) );
						if ( rect && rect.width >= 1 ) {
							y = Math.max( pad, Math.min( rect.top - 24, vpH - 12 - h ) );
							if ( rect.right + pad + w <= vpW - pad ) {
								x = rect.right + pad;
							} else if ( rect.left - pad - w >= pad ) {
								x = rect.left - pad - w;
							}
						}
						el.style.top = y + 'px';
						el.style.left = x + 'px';
					}

					var notifyHtml = '';
					if ( note ) {
						notifyHtml =
							'<label class="wca-rsc__notify"><input type="checkbox"> <span>' + escHtml( t( 'notifyCustomer', 'Email customer about this change' ) ) + '</span></label>' +
							'<p class="wca-rsc__preview" hidden>' + note + '</p>';
					} else if ( notifyHint ) {
						notifyHtml = '<p class="wca-rsc__notify is-hint">' + escHtml( notifyHint ) + '</p>';
					}

					el.innerHTML =
						'<strong class="wca-rsc__title">' + escHtml( t( 'rescheduleConfirmTitle', 'Reschedule appointment?' ) ) + '</strong>' +
						'<ul class="wca-rsc__path">' + pathLi( from, false ) + pathLi( to, true ) + '</ul>' +
						notifyHtml +
						'<div class="wca-rsc__actions">' +
							'<button type="button" class="button wca-rsc__cancel">' + escHtml( t( 'cancelAppointment', 'Cancel' ) ) + '</button>' +
							'<button type="button" class="button button-primary wca-rsc__ok">' + escHtml( t( 'rescheduleAction', 'Reschedule' ) ) + '</button>' +
						'</div>';

					var notifyInput = el.querySelector( 'input[type="checkbox"]' );
					var previewEl = el.querySelector( '.wca-rsc__preview' );
					var cancelBtn = el.querySelector( '.wca-rsc__cancel' );
					var okBtn = el.querySelector( '.wca-rsc__ok' );

					function finish( ok ) {
						if ( settled ) {
							return;
						}
						settled = true;
						document.removeEventListener( 'keydown', onKey, true );
						document.removeEventListener( 'mousedown', onOut, true );
						if ( !ok ) {
							if ( el.parentNode ) {
								el.parentNode.removeChild( el );
							}
							resolve( { confirmed: false, notify: false } );
							return;
						}
						// Stay open until persist finishes so Reschedule doesn't look like Cancel.
						el.classList.add( 'is-busy' );
						okBtn.disabled = true;
						cancelBtn.disabled = true;
						if ( notifyInput ) {
							notifyInput.disabled = true;
						}
						okBtn.textContent = t( 'rescheduling', 'Rescheduling…' );
						resolve( {
							confirmed: true,
							notify: !!( notifyInput && notifyInput.checked ),
							close: function() {
								if ( el.parentNode ) {
									el.parentNode.removeChild( el );
								}
							}
						} );
					}
					function onKey( e ) {
						if ( 'Escape' === e.key ) {
							e.preventDefault();
							finish( false );
						}
					}
					function onOut( e ) {
						if ( !el.contains( e.target ) ) {
							finish( false );
						}
					}

					if ( notifyInput && previewEl ) {
						notifyInput.onchange = function() {
							previewEl.hidden = !notifyInput.checked;
							place();
						};
					}
					cancelBtn.onclick = function() {
						finish( false );
					};
					okBtn.onclick = function() {
						finish( true );
					};
					document.body.appendChild( el );
					place();
					document.addEventListener( 'keydown', onKey, true );
					setTimeout( function() {
						document.addEventListener( 'mousedown', onOut, true );
					}, 0 );
					okBtn.focus();
				} );
			}

			function persistMovedOrResizedAppointment( info, logLabel ) {
				try {
					var p = ( info.event && info.event.extendedProps ) || {};
					if ( false === __wcaRestApiAvailable || !p.appointmentId ) {
						if ( info && 'function' === typeof info.revert ) {
							info.revert();
						}
						return;
					}

					var payload = computeTimesFromEvent( info.event, p );
					var prevStart = p.start_ts || 0;
					var prevEnd = p.end_ts || 0;
					if ( payload.start === prevStart && payload.end === prevEnd ) {
						return;
					}

					var apptId = p.appointmentId;
					var fromParts = __formatNoteParts( prevStart, prevEnd, isAllDayRangeTs( prevStart, prevEnd ) );
					var toParts = __formatNoteParts( payload.start || 0, payload.end || 0, !!payload.all_day || isAllDayRangeTs( payload.start || 0, payload.end || 0 ) );
					var hasOrder = !!p.orderId;
					var hasEmail = !!( p.customerEmail && String( p.customerEmail ).trim() );
					var isCancelled = 'cancelled' === String( p.status || '' ).toLowerCase();
					var canNotify = hasOrder && hasEmail && !isCancelled;
					var notifyHint = '';
					if ( hasOrder && isCancelled ) {
						notifyHint = t( 'notifyCancelledAppointment', 'Appointment is cancelled, so the customer will not be notified about the change.' );
					} else if ( hasOrder && !hasEmail ) {
						notifyHint = t( 'notifyNoCustomerEmail', 'No customer email on this order, so the customer will not be notified about the change.' );
					}
					// Same date/time rows as the path; strike previous, leave new plain.
					var note = '';
					if ( hasOrder ) {
						var noteLine = function( txt, struck ) {
							var e = escHtml( txt );
							return struck ? '<del>' + e + '</del>' : e;
						};
						var noteBlock = function( parts, struck ) {
							return [ parts.date, parts.time ].filter( Boolean ).map( function( s ) {
								return noteLine( s, struck );
							} ).join( '<br>' );
						};
						note = escHtml( t( 'appointmentRescheduledCustomerNote', 'Your appointment was rescheduled.' ) ) +
							'<br><br>' + noteBlock( fromParts, true ) + '<br>' + noteBlock( toParts, false );
					}

					// Same anchor source + scroll as create/view panel.
					var anchorEl = apptEventElRef.current[ String( apptId ) ] || info.el || null;
					if ( anchorEl && window.__wcaCalPreview && window.__wcaCalPreview.scrollToAnchor ) {
						window.__wcaCalPreview.scrollToAnchor( anchorEl, false );
					}
					requestAnimationFrame( function() {
						anchorEl = apptEventElRef.current[ String( apptId ) ] || anchorEl;
						var rect = ( anchorEl && anchorEl.getBoundingClientRect ) ? anchorEl.getBoundingClientRect() : null;
						if ( rect && rect.width < 1 ) {
							rect = null;
						}
						confirmReschedule( {
							from: fromParts,
							to: toParts,
							note: canNotify ? note : '',
							notifyHint: notifyHint,
							rect: rect
						} ).then( function( result ) {
							if ( !result.confirmed ) {
								if ( info && 'function' === typeof info.revert ) {
									info.revert();
								}
								return;
							}
							updateAppointmentSchedule( apptId, payload, info.revert, {
								orderId: p.orderId,
								note: note,
								fcEvent: info.event,
								notifyCustomer: !!result.notify
							} ).finally( function() {
								if ( result.close ) {
									result.close();
								}
							} );
						} );
					} );
				} catch ( error ) {
					if ( logLabel ) {
						console.error( logLabel, error );
					}
					try {
						if ( info && 'function' === typeof info.revert ) {
							info.revert();
						}
					} catch ( __ ) {}
				}
			}

			// FullCalendar initialization: editing enabled; header hidden (custom toolbar)
			var CalendarCtor = ( window.FullCalendar && window.FullCalendar.Calendar ) ? window.FullCalendar.Calendar : null;
			if ( !CalendarCtor ) {
				return;
			}
			var calendar = new CalendarCtor( calElRef.current, {
				initialView: initialView,
				initialDate: initialDateParam || undefined,
				locale: ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.locale ) ? wcAppointmentsReactCalendar.locale : 'en',
				headerToolbar: false,
				// Page scroll for all views. Month cell height comes from CSS (not FC aspectRatio).
				height: 'auto',
				// Pin day headers while scrolling (auto only follows height:'auto'; force on for month too).
				stickyHeaderDates: true,
				allDayText: t( 'allDay', 'All day' ),
				expandRows: true,
				eventMaxStack: 10, //time views only
				dayMaxEvents: 3, // height:auto ignores true; keep a fixed "+more" cap
				nowIndicator: true,
				now: function() {
					// Use timezone-aware current time for the now indicator
					var utils = window.WCAppointmentsTimezoneUtils;
					return utils ? utils.getTimezoneAwareNow() : new Date();
				},
				eventColor: '#0073aa',
				eventTextColor: chooseTextColor( '#0073aa' ),
				slotLabelFormat: fcTimeFormat,
				eventTimeFormat: fcTimeFormat,
				// Align with 30m grid + hover overlay: FC defaults to 1h for selections / events without end.
				slotDuration: '00:30:00',
				snapDuration: '00:30:00',
				defaultTimedEventDuration: '00:30:00',
				eventDataTransform: function( raw ) {
					try {
						var p = raw && raw.extendedProps ? raw.extendedProps : {};
						var cid = p.customerId || p.customer_id || null;
						var idx = window.__wcaUsersIndex || {};
						var u = ( idx && cid ) ? idx[ cid ] : null;
						if ( u ) {
							var fn = u.first_name || '';
							var ln = u.last_name || '';
							var full = ( fn || ln ) ? ( ( fn + ' ' + ln ).trim() ) : ( u.name || '' );
							if ( full ) {
								var prefix = parseInt( p.seriesId || 0, 10 ) > 0 ? '\u21BB ' : '';
								raw.title = prefix + full;
							}
						}
					} catch ( _ ) {}
					return raw;
				},
				selectable: false !== __wcaRestApiAvailable,
				selectMirror: false !== __wcaRestApiAvailable,
				// Allow single-click day picks in month view (default min distance blocks click-only select).
				selectMinDistance: 0,
				editable: false !== __wcaRestApiAvailable,
				eventStartEditable: false !== __wcaRestApiAvailable,
				eventDurationEditable: false !== __wcaRestApiAvailable,
				firstDay: ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.firstDay !== undefined ) ? wcAppointmentsReactCalendar.firstDay : 0,
				navLinks: true,
				views: {
					dayGridMonth: {
						// Show only the weeks needed for the month (4–6), not a fixed 6 rows.
						fixedWeekCount: false
					},
					listWeek: {
						// Page scroll: FC list sticky headers escape the viewport at the last day group.
						stickyHeaderDates: false
					},
					timeGrid: {
						dayHeaderContent: renderTimeGridDayHeader,
						allDayContent: renderTimezoneAllDayAxis
					}
				},

				datesSet: function( info ) {
					var vtype = info && info.view && info.view.type ? info.view.type : '';
					setCurrentView( vtype || currentView );
					setViewTitle( resolveViewTitle( info && info.view ) );
					// Persist current view and anchor date in querystring to survive reloads
					try {
						setQSParam( 'view', mapViewToParam( vtype || currentView ) );
						var anchor = ( info && info.view && info.view.currentStart ) ? info.view.currentStart : ( info && info.start ? info.start : null );
						if ( anchor ) {
							var anchorYmd = dateToYmd( anchor );
							setPeriodYmd( anchorYmd );
							setQSParam( 'calendar_day', anchorYmd );
						}
					} catch ( __ ) {}
					appointmentsDirtyRef.current = true;
					availabilitiesDirtyRef.current = true;
					var prevVT = prevViewTypeRef.current || '';
					var firstDatesSet = !prevActiveRangeRef.current;
					prevViewTypeRef.current = vtype;
					var rangeKey = '';
					try {
						if ( info && info.start && info.end ) {
							rangeKey = info.start.getTime() + '-' + info.end.getTime();
						}
					} catch ( _rk ) {}
					var rangeChanged = prevActiveRangeRef.current && rangeKey && prevActiveRangeRef.current !== rangeKey;
					if ( rangeKey ) {
						prevActiveRangeRef.current = rangeKey;
					}

					// FullCalendar may call events() before datesSet and skip availability reload.
					// Force refetch when view type or visible range changes.
					if ( prevVT && vtype && ( prevVT !== vtype || rangeChanged ) ) {
						try {
							if ( calendar && 'function' === typeof calendar.refetchEvents ) {
								calendar.refetchEvents();
							}
						} catch ( _vt ) {}
					}

					// Entering a view: week/day → now or 08:00; month/list → top (not leftover page Y).
					if ( firstDatesSet || prevVT !== vtype ) {
						window.requestAnimationFrame( function() {
							var root = document.scrollingElement || document.documentElement;
							if ( 'timeGridWeek' === vtype || 'timeGridDay' === vtype ) {
								var grid = calendar && calendar.el;
								var slot = grid && ( grid.querySelector( '.fc-timegrid-now-indicator-line' )
									|| grid.querySelector( '[data-time="08:00:00"]' ) );
								if ( slot ) {
									root.scrollTop += slot.getBoundingClientRect().top - Math.floor( window.innerHeight * 0.35 );
								}
							} else if ( 'dayGridMonth' === vtype || 'listWeek' === vtype ) {
								root.scrollTop = 0;
							}
						} );
					}

				},

				eventClassNames: function( arg ) {
					try {
						var p = ( arg && arg.event ) ? ( arg.event.extendedProps || {} ) : {};
						if ( !p || !p.appointmentId ) {
							return [];
						}
						var now = Math.floor( Date.now() / 1000 );
						var classes = [];
						if ( ( p.end_ts || 0 ) < now ) {
							classes.push( 'is-past' );
						}
						if ( 'cancelled' === String( p.status || '' ).toLowerCase() ) {
							classes.push( 'is-cancelled' );
						}
						return classes;
					} catch ( e ) {
						return [];
					}
				},

				eventDidMount: function( info ) {
					try {
						var p = ( info && info.event ) ? ( info.event.extendedProps || {} ) : {};
						if ( !p ) { return; }

						// Block bg events: prebuild tip HTML; portal tip avoids FC bg opacity.
						if ( p.block ) {
							var title = p.rule_title || t( 'unavailableRule', 'Unavailable Rule' );
							if ( 48 < title.length ) {
								title = title.slice( 0, 48 ) + '\u2026';
							}
							var bit = '';
							if ( 'global' === p.rule_scope ) {
								bit = t( 'ruleLevelGlobal', 'General' );
							} else if ( p.kind_id && ( 'product' === p.rule_scope || 'staff' === p.rule_scope ) ) {
								bit = t( p.rule_scope, 'product' === p.rule_scope ? 'Product' : 'Staff' ) + ':' + p.kind_id;
							}
							info.el.classList.add( 'wca-bg-has-tooltip' );
							info.el.__wcaBlockRule = {
								id: String( p.rule_id || title ),
								html: '<div class="wca-bg-tooltip__row"><strong>' + escHtml( title ) + '</strong>' +
									( bit ? '<span class="wca-bg-tooltip__meta">' + escHtml( bit ) + '</span>' : '' ) + '</div>'
							};
							bindBgRulePortalTip();
							return;
						}

						// Appointment events: toggle .is-past class
						if ( !p.appointmentId ) {
							return;
						}
						apptEventElRef.current[ String( p.appointmentId ) ] = info.el;
						if ( panelTargetApptIdRef.current && String( p.appointmentId ) === panelTargetApptIdRef.current ) {
							try {
								if ( window.__wcaCalPreview ) {
									window.__wcaCalPreview.remove();
								}
								markPanelTarget( info.el );
								var panelApi = window.wcaPanel;
								if ( panelApi && panelApi.isOpen && panelApi.isOpen() && panelApi.updateTrigger ) {
									panelApi.updateTrigger( info.el );
								}
							} catch ( _pt ) {}
						}
						var now = Math.floor( Date.now() / 1000 );
						if ( ( p.end_ts || 0 ) < now ) {
							info.el.classList.add( 'is-past' );
						} else {
							info.el.classList.remove( 'is-past' );
						}
						if ( p.locationDisplay || p.resourceDisplay ) {
							var tipParts = [];
							if ( p.locationDisplay ) {
								tipParts.push( String( p.locationDisplay ) );
							}
							if ( p.resourceDisplay ) {
								tipParts.push( String( p.resourceDisplay ) );
							}
							info.el.setAttribute( 'title', tipParts.join( ' · ' ) );
						}
					} catch ( e ) {}
				},

				eventWillUnmount: function( info ) {
					try {
						var p = ( info && info.event ) ? ( info.event.extendedProps || {} ) : {};
						if ( p && p.appointmentId ) {
							delete apptEventElRef.current[ String( p.appointmentId ) ];
						}
					} catch ( e ) {}
				},

				eventClick: function( info ) {
					// Appointments open the panel; rule stripes use M3 tip only (no modal).
					if ( info && info.jsEvent ) {
						info.jsEvent.preventDefault();
					}
					var p = ( info && info.event ) ? ( info.event.extendedProps || {} ) : {};
					if ( p && p.appointmentId ) {
						if ( wcAppointmentsReactCalendar.panelEnabled && window.wcaPanel && window.wcaPanel.panelEnabled ) {
							openCalendarView( p.appointmentId, info.el || null );
						}
					} else if ( p && p.block ) {
						suppressCreateFromRuleTapRef.current = Date.now();
						if ( info.jsEvent && 'function' === typeof info.jsEvent.stopPropagation ) {
							info.jsEvent.stopPropagation();
						}
						bindBgRulePortalTip();
						var jx = info.jsEvent || {};
						var cx = 'number' === typeof jx.clientX ? jx.clientX : 0;
						var cy = 'number' === typeof jx.clientY ? jx.clientY : 0;
						// Pin on touch; desktop already has hover follow (pin still ok for click).
						var pin = !wcaFinePointerHover();
						if ( window.__wcaBgRuleTipShow ) {
							window.__wcaBgRuleTipShow( cx, cy, info.el || null, pin );
						}
					}
				},

				dateClick: function( info ) {
					try {
						var jx = info.jsEvent;
						// Only the click target counts — do not scan elementsFromPoint (bg
						// events sit under slots and falsely blocked empty-cell create).
						var stripe = jx && jx.target && jx.target.closest
							? jx.target.closest( '.wca-bg-has-tooltip' )
							: null;
						if ( stripe ) {
							suppressCreateFromRuleTapRef.current = Date.now();
							bindBgRulePortalTip();
							if ( window.__wcaBgRuleTipShow ) {
								window.__wcaBgRuleTipShow( jx.clientX, jx.clientY, stripe, !wcaFinePointerHover() );
							}
							return;
						}
						var startTs = Math.floor( info.date.getTime() / 1000 );
						var viewType = info.view && info.view.type ? info.view.type : '';
						var isMonthGrid = 'dayGridMonth' === viewType;
						if ( isMonthGrid && isNarrowViewport() ) {
							openDayFromMonth( info.date );
							return;
						}
						// Month grid day clicks are date-only picks (same as drag-select all-day).
						var allDay = !!info.allDay || isMonthGrid;
						var endTs = allDay ? ( startTs + 86400 ) : 0;
						var dcTriggerEl = info.dayEl || null;
						openCreatePanelFromCalendarPick( {
							startTs: startTs,
							endTs: endTs,
							allDay: allDay,
							triggerEl: dcTriggerEl,
							triggerRect: dcTriggerEl ? dcTriggerEl.getBoundingClientRect() : null,
							source: 'dateClick'
						} );
					} catch ( _ ) {}
				},

				select: function( info ) {
					try {
						var sjx = info.jsEvent;
						var stripeEl = sjx && sjx.target && sjx.target.closest
							? sjx.target.closest( '.wca-bg-has-tooltip' )
							: null;
						var selSecs = Math.floor( ( info.end.getTime() - info.start.getTime() ) / 1000 );
						// Single-slot tap on a stripe (not a drag): tip only, no create.
						if ( stripeEl && 1800 >= selSecs ) {
							suppressCreateFromRuleTapRef.current = Date.now();
							bindBgRulePortalTip();
							if ( window.__wcaBgRuleTipShow ) {
								window.__wcaBgRuleTipShow( sjx.clientX, sjx.clientY, stripeEl, !wcaFinePointerHover() );
							}
							try { if ( calRef.current ) { calRef.current.unselect(); } } catch ( _us0 ) {}
							return;
						}
						var startTs = Math.floor( info.start.getTime() / 1000 );
						if ( info.view && 'dayGridMonth' === info.view.type && isNarrowViewport() ) {
							openDayFromMonth( info.start );
							try { if ( calRef.current ) { calRef.current.unselect(); } } catch ( _usN ) {}
							return;
						}
						// One slot (30m): omit end so the panel applies product duration (same as legacy 30m path).
						var endTs = 1800 === selSecs ? 0 : Math.floor( info.end.getTime() / 1000 );
						var selTriggerEl = null;
						if ( info.jsEvent && info.jsEvent.target ) {
							selTriggerEl = info.jsEvent.target.closest( '.fc-timegrid-slot, .fc-daygrid-day, .fc-timegrid-col' ) || info.jsEvent.target;
						}
						openCreatePanelFromCalendarPick( {
							startTs: startTs,
							endTs: endTs,
							allDay: !!info.allDay,
							triggerEl: selTriggerEl,
							triggerRect: selTriggerEl ? selTriggerEl.getBoundingClientRect() : null,
							source: 'select'
						} );
						try { if ( calRef.current ) { calRef.current.unselect(); } } catch ( _us ) {}
					} catch ( _ ) {}
				},

				eventDragStart: function() {
					setDragRequestBlocking( true );
				},

				eventResizeStart: function() {
					setDragRequestBlocking( true );
				},

				/**
			 * Handle drag-and-drop appointment rescheduling with timezone conversion
			 *
			 * TIMEZONE HANDLING:
			 * =================
			 * This handler processes drag operations on the calendar and ensures proper timezone
			 * conversion when staff are in different timezones than the site. The drag operation provides
			 * FullCalendar event objects with Date objects representing the new time in the admin's timezone.
			 *
			 * The workflow is:
			 * 1. Validate the drag operation (REST API available, appointment exists)
			 * 2. Convert the new times using computeTimesFromEvent() (handles timezone conversion)
			 * 3. Send the converted timestamps to the server via REST API
			 * 4. Update the calendar display and send notifications
			 *
			 * Examples:
			 * - Staff in same timezone: Drag to 07:00 → Send 07:00 timestamp
			 * - Staff in different timezone: Drag to 07:00 admin → Convert to 08:00 site → Send 08:00 timestamp
			 *
			 * @param {Object} info - FullCalendar drag info object with event, revert function, etc.
			 */
				eventDrop: function( info ) {
					// Persist drag move using proper timezone conversion
					persistMovedOrResizedAppointment( info, 'Drag & drop error:' );
				},

				eventResize: function( info ) {
					// Persist duration changes using naive wall-clock timestamps
					persistMovedOrResizedAppointment( info );
				},

				eventDragStop: function() {
					setDragRequestBlocking( false );
					if ( window.wcaPanel && window.wcaPanel.syncLayout ) {
						window.wcaPanel.syncLayout();
					}
				},

				eventResizeStop: function() {
					setDragRequestBlocking( false );
					if ( window.wcaPanel && window.wcaPanel.syncLayout ) {
						window.wcaPanel.syncLayout();
					}
				},

				navLinkDayClick: function( date, jsEvent ) {
					try {
						if ( jsEvent ) {
							jsEvent.preventDefault();
						}
						var v = calRef.current && calRef.current.view;
						if ( v && 'dayGridMonth' === v.type && isNarrowViewport() ) {
							openDayFromMonth( date );
							return;
						}
						setQSParam( 'calendar_day', dateToYmd( date ) );
						changeView( 'timeGridDay', date );
					} catch ( _ ) {}
				},

				navLinkWeekClick: function( weekStart, jsEvent ) {
					// Jump into week view at the clicked week start
					try {
						if ( jsEvent ) {
							jsEvent.preventDefault();
						}
						setQSParam( 'calendar_day', dateToYmd( weekStart ) );
						changeView( 'timeGridWeek', weekStart );
					} catch ( _ ) {}
				},

				events: function( info, success, failure ) {
					function buildIndexesFromAppointments( rows ) {
						var idx = {};
						var usersIdx = {};
						ensureArray( rows ).forEach( function( row ) {
							if ( row.product_id && row.cal_color ) {
								var pid = String( row.product_id );
								if ( !idx[ pid ] ) {
									idx[ pid ] = String( row.cal_color );
								}
							}
							if ( row.customer_id ) {
								var cid = parseInt( row.customer_id, 10 );
								if ( 0 < cid && !usersIdx[ cid ] ) {
									usersIdx[ cid ] = {
										name: row.customer_name || row.customer_full_name || ( '#' + cid ),
										email: '',
										first_name: row.customer_first_name || '',
										last_name: row.customer_last_name || ''
									};
								}
							}
						} );
						return {
							idx: idx,
							usersIdx: usersIdx
						};
					}

					function applyClientFiltersAndBuildEvents( rows, idx, usersIdx ) {
						if ( window.panelSeries && window.panelSeries.indexPreloadFromRows ) {
							window.panelSeries.indexPreloadFromRows( rows );
						}
						var apptsFiltered = filterAppointmentsByMultiSelect( rows, productIdsRef.current, staffIdsRef.current, statusIdsRef.current, locationIdsRef.current );
						var evs = [];
						apptsFiltered.forEach( function( row ) {
							evs.push( buildAppointmentEvent( row, usersIdx, idx ) );
						} );
						return {
							apptsFiltered: apptsFiltered,
							evs: evs
						};
					}

					function publishRuntimeIndexes( idx, usersIdx ) {
						try {
							window.__wcaUsersIndex = usersIdx || {};
							window.__wcaProductColorsIndex = idx || {};
						} catch ( _ ) {}
					}

					var startTs = Math.floor( new Date( info.startStr ).getTime() / 1000 );
					var endTs = Math.floor( new Date( info.endStr ).getTime() / 1000 );
					var loadGen = ++loadGenRef.current;
					var __preloadedAppts = getPreloadedAppointmentsForRange( startTs, endTs );

					if ( isRequestsBlocked() ) {
						setLoadingEvents( false );
						if ( 'function' === typeof failure ) {
							failure( new Error( 'Blocked during drag/resize' ) );
						}
						return;
					}

					var currentProductId = productIdRef.current;
					var currentStaffId = staffIdRef.current;
					var staffParam = null;
					if ( 'unassigned' === currentStaffId ) {
						staffParam = 0;
					} else if ( currentStaffId ) {
						staffParam = currentStaffId;
					}
					// currentProductId/staffParam are for availability rules only; appointments are unfiltered + multi-select client filters.
					// Define processAvailabilityResults function early so it's available for both preloaded and API-fetched appointments
					// This function processes availability rules and renders them on the calendar
					var processAvailabilityResults = function( res, useStartTs, useEndTs, useProductId, useStaffParam ) {
						// Use provided parameters or fall back to closure variables
						useStartTs = useStartTs !== undefined ? useStartTs : startTs;
						useEndTs = useEndTs !== undefined ? useEndTs : endTs;
						useProductId = useProductId !== undefined ? useProductId : currentProductId;
						useStaffParam = useStaffParam !== undefined ? useStaffParam : staffParam;

						// res format: [unavGlobal, unavProduct, unavStaff]
						try {
							// Timed rules may shift into the admin TZ for week/day grids.
							// Civil date-only / full-day rules must NOT (same as all-day appointments):
							// "March 16" stays March 16 for every viewer.
							var __cal = calRef.current;
							var __isMonthView = __cal && __cal.view && 0 === String( __cal.view.type || '' ).indexOf( 'dayGrid' );
							var __tzUtils = window.WCAppointmentsTimezoneUtils || {};
							var __parseYmd = function( s ) {
								var p = String( s || '' ).split( '-' );
								return { y: parseInt( p[ 0 ], 10 ) || 0, m: parseInt( p[ 1 ], 10 ) || 0, d: parseInt( p[ 2 ], 10 ) || 0 };
							};
							var __ruleShiftTz = function( hStart, hEnd ) {
								if ( 'function' === typeof __tzUtils.shouldShiftAvailabilityRuleTimezone ) {
									return !!__tzUtils.shouldShiftAvailabilityRuleTimezone( {
										isMonthView: !!__isMonthView,
										hasDifferentTz: adminHasDifferentTimezone(),
										hStart: hStart,
										hEnd: hEnd
									} );
								}
								// Fallback if timezone utils are missing (should not happen on calendar page).
								if ( __isMonthView || !adminHasDifferentTimezone() ) {
									return false;
								}
								var hs = String( hStart || '00:00' ).split( ':' );
								var he = String( hEnd || '23:59' ).split( ':' );
								var sh = parseInt( hs[ 0 ], 10 ) || 0;
								var sm = parseInt( hs[ 1 ], 10 ) || 0;
								var eh = parseInt( he[ 0 ], 10 ) || 0;
								var em = parseInt( he[ 1 ], 10 ) || 0;
								var civil = ( 0 === sh && 0 === sm ) && ( ( 23 === eh && 59 === em ) || ( 24 === eh && 0 === em ) );
								return !civil;
							};
							var __ymdToTs = function( ymd, hm, shiftTz ) {
								if ( 'function' === typeof __tzUtils.availabilityRuleYmdHmToTs ) {
									return __tzUtils.availabilityRuleYmdHmToTs( ymd, hm, !!shiftTz );
								}
								var d = __parseYmd( ymd );
								var p = String( hm || '00:00' ).split( ':' );
								var ts = Math.floor( new Date( d.y, d.m - 1, d.d, parseInt( p[ 0 ], 10 ) || 0, parseInt( p[ 1 ], 10 ) || 0, 0 ).getTime() / 1000 );
								return shiftTz ? convertToAdminTimezone( ts ) : ts;
							};
							var __toYmd = function( d ) {
								var y = d.getFullYear();
								var m = d.getMonth() + 1;
								var day = d.getDate();
								return String( y ) + '-' + ( 10 > m ? '0' : '' ) + String( m ) + '-' + ( 10 > day ? '0' : '' ) + String( day );
							};
							var __clampPush = function( out, s, e ) {
								if ( s < useStartTs ) {
									s = useStartTs;
								}
								if ( e > useEndTs ) {
									e = useEndTs;
								}
								if ( e > s ) {
									out.push( [ s, e ] );
								}
							};
							var __forViewDays = function( out, dayFilter, hStart, hEnd ) {
								var shiftTz = __ruleShiftTz( hStart, hEnd );
								var sD = new Date( useStartTs * 1000 );
								var eD = new Date( ( useEndTs - 1 ) * 1000 );
								var d0 = new Date( sD.getFullYear(), sD.getMonth(), sD.getDate() );
								var dayMs = 86400 * 1000;
								for ( var dd = d0; dd.getTime() <= eD.getTime(); dd = new Date( dd.getTime() + dayMs ) ) {
									var ymd = __toYmd( dd );
									if ( dayFilter && !dayFilter( dd.getDay() ) ) { continue; }
									var s = __ymdToTs( ymd, hStart, shiftTz );
									var e = __ymdToTs( ymd, hEnd, shiftTz );
									__clampPush( out, s, e );
								}
							};
							var __forRangeDays = function( out, ymdStart, ymdEnd, hStart, hEnd ) {
								var shiftTz = __ruleShiftTz( hStart, hEnd );
								var d0 = __parseYmd( ymdStart );
								var d1 = __parseYmd( ymdEnd );
								var startDate = new Date( d0.y, d0.m - 1, d0.d );
								var endDate = new Date( d1.y, d1.m - 1, d1.d );
								var dayMs = 86400 * 1000;
								for ( var dd = startDate; dd.getTime() <= endDate.getTime(); dd = new Date( dd.getTime() + dayMs ) ) {
									var ymd = __toYmd( dd );
									var s = __ymdToTs( ymd, hStart, shiftTz );
									var e = __ymdToTs( ymd, hEnd, shiftTz );
									__clampPush( out, s, e );
								}
							};
							var __expandRRuleLocal = function( r ) {
								var out = [];
								var lines = String( r.rrule || '' ).split( /\n+/ );
								var freq = 'DAILY';
								var intervalN = 1;
								var byDays = null;
								var untilTs = 0;
								var exDates = {};
								var dtstartYmd = '';
								var dtstartHm = '';
								for ( var i = 0; i < lines.length; i++ ) {
									var ln = String( lines[ i ] || '' ).trim();
									if ( !ln ) { continue; }
									if ( 0 === ln.indexOf( 'DTSTART:' ) ) {
										var v0 = ln.split( ':' )[ 1 ] || '';
										var p0 = __parseDateTimeToYmdHm( v0 );
										dtstartYmd = p0.ymd || dtstartYmd;
										dtstartHm = p0.hm || dtstartHm;
										continue;
									}
									if ( 0 === ln.indexOf( 'RRULE:' ) ) {
										var args = ln.split( ':' )[ 1 ] || '';
										var parts = args.split( ';' );
										for ( var j = 0; j < parts.length; j++ ) {
											var kv = parts[ j ].split( '=' );
											var k = ( kv[ 0 ] || '' ).toUpperCase();
											var v = kv[ 1 ] || '';
											if ( 'FREQ' === k ) { freq = String( v || 'DAILY' ).toUpperCase(); } else if ( 'INTERVAL' === k ) { intervalN = Math.max( 1, parseInt( v, 10 ) || 1 ); } else if ( 'BYDAY' === k ) {
												var arr = v.split( ',' );
												var map = { SU: 0, MO: 1, TU: 2, WE: 3, TH: 4, FR: 5, SA: 6 };
												byDays = {};
												for ( var q = 0; q < arr.length; q++ ) {
													var code = arr[ q ].toUpperCase();
													if ( map.hasOwnProperty( code ) ) { byDays[ map[ code ] ] = 1; }
												}
											} else if ( 'UNTIL' === k ) {
												var val = v;
												var iso = '';
												if ( /\d{8}T\d{6}Z/.test( val ) ) {
													iso = val.slice( 0, 4 ) + '-' + val.slice( 4, 6 ) + '-' + val.slice( 6, 8 ) + 'T' + val.slice( 9, 11 ) + ':' + val.slice( 11, 13 ) + ':' + val.slice( 13, 15 ) + 'Z';
												} else if ( /\d{8}/.test( val ) ) {
													iso = val.slice( 0, 4 ) + '-' + val.slice( 4, 6 ) + '-' + val.slice( 6, 8 ) + 'T00:00:00Z';
												}
												try { untilTs = Math.floor( new Date( iso ).getTime() / 1000 ); } catch ( __u ) {}
											}
										}
										continue;
									}
									if ( 0 === ln.indexOf( 'EXDATE' ) ) {
										var v1 = ln.split( ':' )[ 1 ] || '';
										var arr2 = v1.split( ',' );
										for ( var w = 0; w < arr2.length; w++ ) {
											var p = __parseDateTimeToYmdHm( arr2[ w ] );
											if ( p.ymd ) { exDates[ p.ymd ] = 1; }
										}
										continue;
									}
								}
								if ( !dtstartYmd ) {
									var pFrom = __parseDateTimeToYmdHm( r.from_range || r.from_date || r.from || '' );
									var pTo = __parseDateTimeToYmdHm( r.to_range || r.to_date || r.to || '' );
									dtstartYmd = pFrom.ymd || ( pTo.ymd || __toYmd( new Date( useStartTs * 1000 ) ) );
									dtstartHm = pFrom.hm || '';
								}
								var hmStart = ( r.from || r.from_range || '' );
								var hmEnd = ( r.to || r.to_range || '' );
								var pStart = __parseDateTimeToYmdHm( hmStart );
								var pEnd = __parseDateTimeToYmdHm( hmEnd );
								var hStart = pStart.hm || '00:00';
								var hEnd = pEnd.hm || '23:59';
								var shiftTz = __ruleShiftTz( hStart, hEnd );
								// Midnight anchors are civil day math only (never admin-TZ shifted).
								var dtStartMid = __ymdToTs( dtstartYmd, '00:00', false );
								var sD = new Date( useStartTs * 1000 );
								var eD = new Date( ( useEndTs - 1 ) * 1000 );
								var d0 = new Date( sD.getFullYear(), sD.getMonth(), sD.getDate() );
								var dayMs = 86400 * 1000;
								for ( var dd = d0; dd.getTime() <= eD.getTime(); dd = new Date( dd.getTime() + dayMs ) ) {
									var ymd = __toYmd( dd );
									if ( exDates[ ymd ] ) { continue; }
									var dayTs = __ymdToTs( ymd, '00:00', false );
									if ( 0 < untilTs && untilTs < dayTs ) { break; }
									var diffDays = Math.floor( ( dayTs - dtStartMid ) / 86400 );
									if ( 0 > diffDays ) { continue; }
									if ( 'WEEKLY' === freq ) {
										var weeks = Math.floor( diffDays / 7 );
										if ( 0 !== ( weeks % intervalN ) ) { continue; }
										var dow = dd.getDay();
										if ( byDays && !byDays[ dow ] ) { continue; }
									} else if ( 'DAILY' === freq ) {
										if ( 0 !== ( diffDays % intervalN ) ) { continue; }
									} else {
										continue;
									}
									var s = __ymdToTs( ymd, hStart, shiftTz );
									var e = __ymdToTs( ymd, hEnd, shiftTz );
									__clampPush( out, s, e );
								}
								return out;
							};
							var __parseDateTimeToYmdHm = function( s ) {
								if ( !s ) { return { ymd: '', hm: '' }; }
								if ( -1 !== s.indexOf( 'T' ) ) {
									var d = new Date( s );
									var ymd = __toYmd( d );
									var hh = d.getHours();
									var mm = d.getMinutes();
									var ph = 10 > hh ? ( '0' + hh ) : String( hh );
									var pmn = 10 > mm ? ( '0' + mm ) : String( mm );
									return { ymd: ymd, hm: ph + ':' + pmn };
								}
								if ( -1 !== s.indexOf( ':' ) ) {
									return { ymd: '', hm: s };
								}
								return { ymd: s, hm: '' };
							};
							var expandRuleToIntervalsLocal = function( r ) {
								var type = String( ( r && ( r.type || r.range_type ) ) || '' ).toLowerCase();
								var out = [];
								if ( 'custom' === type ) {
									// For custom rules, dates can be in from_date/to_date OR from_range/to_range
									// Check both locations to handle different data formats
									var f0 = r.from || r.from_date || r.from_range || '';
									var t0 = r.to || r.to_date || r.to_range || '';
									if ( f0 && t0 ) {
										// Date-only custom blocks are civil (never admin-TZ shifted).
										var s = __ymdToTs( f0, '00:00', false );
										var e = __ymdToTs( t0, '23:59', false );
										__clampPush( out, s, e );
									}
								} else if ( 'custom:daterange' === type || 'time:range' === type ) {
									var fd = r.from_date || '';
									var td = r.to_date || '';
									var fh = r.from || r.from_range || '00:00';
									var th = r.to || r.to_range || '23:59';
									if ( fd && td ) {
										__forRangeDays( out, fd, td, fh, th );
									}
								} else if ( 'rrule' === type ) {
									out = __expandRRuleLocal( r );
								} else if ( 'time' === type ) {
									var fh2 = r.from || r.from_range || '00:00';
									var th2 = r.to || r.to_range || '23:59';
									__forViewDays( out, null, fh2, th2 );
								} else if ( 0 === type.indexOf( 'time:' ) ) {
									var dnum = parseInt( type.split( ':' )[ 1 ], 10 );
									var fh3 = r.from || r.from_range || '00:00';
									var th3 = r.to || r.to_range || '23:59';
									var map = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 0 };
									__forViewDays( out, function( dow ) { return dow === map[ dnum ]; }, fh3, th3 );
								} else if ( 'days' === type ) {
									var fN = parseInt( ( r.from || r.from_range || '1' ), 10 );
									var tN = parseInt( ( r.to || r.to_range || '7' ), 10 );
									var seq = {};
									var cur = fN;
									for ( var i = 0; 7 > i; i++ ) {
										seq[ cur ] = 1;
										if ( cur === tN ) { break; }
										cur = ( cur % 7 ) + 1;
									}
									var map2 = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 0 };
									__forViewDays( out, function( dow ) {
										var dn = 0;
										for ( var k in map2 ) { if ( map2.hasOwnProperty( k ) && map2[ k ] === dow ) { dn = parseInt( k, 10 ); break; } }
										return !!seq[ dn ];
									}, '00:00', '23:59' );
								}
								return out;
							};
							var unavRulesGlobal = Array.isArray( res[ 0 ] ) ? res[ 0 ] : [];
							var unavRulesProduct = Array.isArray( res[ 1 ] ) ? res[ 1 ] : [];
							var unavRulesStaff = Array.isArray( res[ 2 ] ) ? res[ 2 ] : [];
							var __ruleMeta = function( r, scope ) {
								return {
									rule_id: r.id || null,
									rule_title: r.title || '',
									rule_scope: scope,
									rule_type: r.type || r.range_type || '',
									kind_id: r.kind_id || 0
								};
							};
							var unavAnnotated = [];
							var __appendUnavIntervals = function( rules, scope ) {
								( rules || [] ).forEach( function( r ) {
									try {
										var meta = __ruleMeta( r, scope );
										var ivs = expandRuleToIntervalsLocal( r || {} );
										for ( var i = 0; i < ivs.length; i++ ) {
											unavAnnotated.push( { s: ivs[ i ][ 0 ], e: ivs[ i ][ 1 ], meta: meta } );
										}
									} catch ( __ ) {}
								} );
							};
							__appendUnavIntervals( unavRulesGlobal, 'global' );
							__appendUnavIntervals( unavRulesProduct, 'product' );
							__appendUnavIntervals( unavRulesStaff, 'staff' );
							// Render per-rule background events so each one carries its rule metadata
							// This enables tooltip display on hover showing which rule blocks the slot
							try {
								var cal = calRef.current;
								if ( cal && 'function' === typeof cal.getEvents ) {
									cal.getEvents().forEach( function( e ) {
										try {
											var p = e.extendedProps || {};
											if ( p && p.block ) {
												e.remove();
											}
										} catch ( _ ) {}
									} );
								}
								var vtype = ( cal && cal.view && cal.view.type ) ? cal.view.type : '';
								unavAnnotated.forEach( function( ann, idx ) {
									var sTs = ann.s;
									var eTs = ann.e;
									var meta = ann.meta || {};
									var ruleIdStr = meta.rule_id ? String( meta.rule_id ) : String( idx );
									// Civil full-day intervals (00:00–23:59 / next midnight) belong in the
									// all-day row on week/day grids, same as month + all-day appointments.
									var sWall = new Date( sTs * 1000 );
									var eWall = new Date( eTs * 1000 );
									var startsMidnight = ( 0 === sWall.getHours() && 0 === sWall.getMinutes() );
									var endsCivil = ( 23 === eWall.getHours() && 59 === eWall.getMinutes() )
										|| ( 0 === eWall.getHours() && 0 === eWall.getMinutes() && eTs > sTs );
									var intervalIsCivilAllDay = startsMidnight && endsCivil;
									var useAllDayBranch = ( 0 === String( vtype || '' ).indexOf( 'dayGrid' ) ) || intervalIsCivilAllDay;
									if ( useAllDayBranch ) {
										var sD = new Date( sTs * 1000 );
										var dayStart = new Date( sD.getFullYear(), sD.getMonth(), sD.getDate() );
										var curTs = Math.floor( dayStart.getTime() / 1000 );
										while ( curTs < eTs ) {
											var nextTs = curTs + 86400;
											var startDay = new Date( curTs * 1000 );
											var endDay = new Date( nextTs * 1000 );
											var padSec = 60;
											var fullDayStart = curTs;
											var fullDayEnd = nextTs;
											var coversFullDay = ( sTs <= ( fullDayStart + padSec ) ) && ( eTs >= ( fullDayEnd - padSec ) );
											if ( !coversFullDay ) {
												curTs = nextTs;
												continue;
											}
											if ( cal && 'function' === typeof cal.addEvent ) {
												cal.addEvent( {
													id: 'block-bg-rule-' + ruleIdStr + '-' + curTs,
													title: '',
													start: startDay,
													end: endDay,
													display: 'background',
													allDay: true,
													className: 'fc-bg-event-striped',
													extendedProps: {
														block: true,
														rule_id: meta.rule_id,
														rule_title: meta.rule_title,
														rule_scope: meta.rule_scope,
														rule_type: meta.rule_type,
														kind_id: meta.kind_id,
														scope: meta.rule_scope,
														product_id: useProductId || null,
														staff_id: useStaffParam || null,
														start_ts: sTs,
														end_ts: eTs
													}
												} );
											}
											curTs = nextTs;
										}
									} else {
										var start = new Date( sTs * 1000 );
										var end = new Date( eTs * 1000 );
										if ( cal && 'function' === typeof cal.addEvent ) {
											cal.addEvent( {
												id: 'block-bg-rule-' + ruleIdStr + '-' + idx,
												title: '',
												start: start,
												end: end,
												display: 'background',
												className: 'fc-bg-event-striped',
												extendedProps: {
													block: true,
													rule_id: meta.rule_id,
													rule_title: meta.rule_title,
													rule_scope: meta.rule_scope,
													rule_type: meta.rule_type,
													kind_id: meta.kind_id,
													scope: meta.rule_scope,
													product_id: useProductId || null,
													staff_id: useStaffParam || null,
													start_ts: sTs,
													end_ts: eTs
												}
											} );
										}
									}
								} );
								availabilitiesDirtyRef.current = false;
							} catch ( _ ) {}
						} catch ( _ ) {}
					};

					// Store globally for use from preloaded appointments path
					window.__wcaProcessAvailability = processAvailabilityResults;

					function finishAppointmentsLoad( rowsForRender ) {
						if ( loadIsStale( loadGen ) ) {
							return;
						}
						rowsForRender = ensureArray( rowsForRender ).filter( function( row ) {
							return row && !isExcludedStatus( row.status );
						} );
						cleanupSseInjectedEvents();
						var indexes = buildIndexesFromAppointments( rowsForRender );
						publishRuntimeIndexes( indexes.idx, indexes.usersIdx );
						var built = applyClientFiltersAndBuildEvents( rowsForRender, indexes.idx, indexes.usersIdx );
						success( built.evs );
						setLoadingEvents( false );
						setEmptyTip( 0 === built.evs.length );
						appointmentsDirtyRef.current = false;
						skipAvailRef.current = false;
						scheduleAvailabilityLoad( startTs, endTs, processAvailabilityResults, loadGen );
					}

					if ( false === __wcaRestApiAvailable ) {
						if ( null !== __preloadedAppts ) {
							finishAppointmentsLoad( __preloadedAppts );
						} else if ( !loadIsStale( loadGen ) ) {
							success( [] );
							setLoadingEvents( false );
							setEmptyTip( true );
						}
						return;
					}

					if ( null !== __preloadedAppts ) {
						var preloadRows = __preloadedAppts;
						( window.requestAnimationFrame || function( fn ) { setTimeout( fn, 0 ); } )( function() {
							if ( !loadIsStale( loadGen ) ) {
								finishAppointmentsLoad( preloadRows );
							}
						} );
					} else {
						setLoadingEvents( true );
						setEmptyTip( false );
						fetchAppointmentsForRange( startTs, endTs ).then( function( rows ) {
							if ( !loadIsStale( loadGen ) ) {
								finishAppointmentsLoad( rows );
							}
						} ).catch( function( err ) {
							if ( loadIsStale( loadGen ) ) {
								return;
							}
							setLoadingEvents( false );
							var blocked = false;
							try {
								blocked = isRequestsBlocked() || ( err && ( 'AbortError' === err.name || /Blocked during drag\/resize/i.test( String( err.message || '' ) ) ) );
							} catch ( _ ) {}
							if ( !blocked ) {
								try {
									var msg = ( err && err.message ) ? err.message : String( err || t( 'unknownError', 'Unknown error' ) );
									setError( t( 'restFetchFailed', 'Failed to load calendar data: ' ) + msg + '.' );
								} catch ( e ) {}
							}
							if ( 'function' === typeof failure ) {
								failure( err );
							}
						} );
					}
				}
			} );

			// Render calendar and mount listeners
			calendar.render();
			var stickyRoot = document.querySelector( '.wca-react-calendar' );
			var onStickyChromeScroll = function() {
				if ( stickyRoot ) {
					stickyRoot.classList.toggle( 'is-scrolled', ( window.pageYOffset || document.documentElement.scrollTop || 0 ) > 0 );
				}
			};
			window.addEventListener( 'scroll', onStickyChromeScroll, { passive: true } );
			onStickyChromeScroll();
			var onCalendarResize = function() {
				try {
					refreshTimeGridCaches( true );
					setViewTitle( resolveViewTitle( calendar.view ) );
				} catch ( _ ) {}
			};
			window.addEventListener( 'resize', onCalendarResize );
			try {
				setViewTitle( resolveViewTitle( calendar && calendar.view ) );
			} catch ( e ) {}
			calRef.current = calendar;
			var hoverTimeout = null;
			var hoverCellEl = null;
			var hoverTimeEl = null;
			var hoverSuppressed = false;
			var calendarEl = calElRef.current;
			var timeGridBodyEl = null;
			var cachedDayCols = null;
			var cachedSlotLanes = null;
			var gridCacheTs = 0;

			function clearHoverCell() {
				try {
					if ( hoverTimeout ) {
						clearTimeout( hoverTimeout );
						hoverTimeout = null;
					}
					if ( hoverCellEl && hoverCellEl.parentNode ) {
						hoverCellEl.parentNode.removeChild( hoverCellEl );
					}
				} catch ( _ ) {}
				hoverCellEl = null;
				hoverTimeEl = null;
			}

			function getTimeGridBody() {
				try {
					if ( timeGridBodyEl && calendarEl && calendarEl.contains( timeGridBodyEl ) ) {
						return timeGridBodyEl;
					}
				} catch ( _ ) {}
				timeGridBodyEl = calendarEl ? calendarEl.querySelector( '.fc-timegrid-body' ) : null;
				return timeGridBodyEl;
			}

			function refreshTimeGridCaches( force ) {
				var now = Date.now();
				if ( !force && cachedDayCols && cachedSlotLanes && ( now - gridCacheTs ) < 250 ) {
					return;
				}
				cachedDayCols = calendarEl ? calendarEl.querySelectorAll( '.fc-timegrid-col' ) : null;
				cachedSlotLanes = calendarEl ? calendarEl.querySelectorAll( '.fc-timegrid-slot-lane' ) : null;
				gridCacheTs = now;
			}

			function formatTimeString( timeStr ) {
				if ( !timeStr ) {
					return '';
				}
				var parts = String( timeStr ).split( ':' );
				var hh = parseInt( parts[ 0 ] || '0', 10 );
				var mm = parseInt( parts[ 1 ] || '0', 10 );
				var ss = parseInt( parts[ 2 ] || '0', 10 );
				if ( isNaN( hh ) || isNaN( mm ) || isNaN( ss ) ) {
					return '';
				}
				var d = new Date();
				d.setHours( hh, mm, ss, 0 );
				return formatTimeByPatternLocal( d, timePattern );
			}

			function getSlotTimeLabel( slotLane ) {
				try {
					if ( !slotLane ) {
						return '';
					}
					var row = slotLane.closest( 'tr' );
					if ( row ) {
						var labelEl = row.querySelector( '.fc-timegrid-slot-label-cushion' );
						if ( labelEl && labelEl.textContent ) {
							return labelEl.textContent.trim();
						}
						var rowTime = row.getAttribute( 'data-time' );
						if ( rowTime ) {
							return formatTimeString( rowTime );
						}
					}
					var laneTime = slotLane.getAttribute( 'data-time' ) || ( slotLane.dataset ? slotLane.dataset.time : '' );
					if ( laneTime ) {
						return formatTimeString( laneTime );
					}
				} catch ( _ ) {}
				return '';
			}

			function onTimeGridPointerDown() {
				hoverSuppressed = true;
				clearHoverCell();
			}

			function onTimeGridPointerUp() {
				hoverSuppressed = false;
			}

			function onTimeGridMouseMove( e ) {
				if ( hoverTimeout ) {
					clearTimeout( hoverTimeout );
				}
				hoverTimeout = setTimeout( function() {
					try {
						var view = ( calendar && calendar.view ) ? calendar.view : null;
						if ( hoverSuppressed ) {
							clearHoverCell();
							return;
						}
						if ( dragInProgressRef.current ) {
							clearHoverCell();
							return;
						}
						if ( !view || ( 'timeGridWeek' !== view.type && 'timeGridDay' !== view.type ) ) {
							clearHoverCell();
							return;
						}
						var timeGridBody = getTimeGridBody();
						if ( !timeGridBody ) {
							clearHoverCell();
							return;
						}
						var target = e && e.target ? e.target : null;
						if ( !target || !target.closest ) {
							clearHoverCell();
							return;
						}
						if ( target.closest( '.fc-timegrid-slot-label' ) || target.closest( '.fc-timegrid-axis' ) ) {
							clearHoverCell();
							return;
						}
						var dayCol = target.closest( '.fc-timegrid-col' );
						if ( !dayCol && calendarEl ) {
							refreshTimeGridCaches( false );
							var cols = cachedDayCols || [];
							for ( var i = 0; i < cols.length; i++ ) {
								var rect = cols[ i ].getBoundingClientRect();
								if ( rect && e.clientX >= rect.left && e.clientX <= rect.right ) {
									dayCol = cols[ i ];
									break;
								}
							}
						}
						if ( !dayCol ) {
							clearHoverCell();
							return;
						}
						var slotLane = target.closest( '.fc-timegrid-slot-lane' );
						if ( !slotLane && calendarEl ) {
							refreshTimeGridCaches( false );
							var lanes = cachedSlotLanes || [];
							for ( var j = 0; j < lanes.length; j++ ) {
								var laneRect = lanes[ j ].getBoundingClientRect();
								if ( laneRect && e.clientY >= laneRect.top && e.clientY <= laneRect.bottom ) {
									slotLane = lanes[ j ];
									break;
								}
							}
						}
						if ( !slotLane ) {
							clearHoverCell();
							return;
						}
						var slotRect = slotLane.getBoundingClientRect();
						var colRect = dayCol.getBoundingClientRect();
						var bodyRect = timeGridBody.getBoundingClientRect();
						if ( !slotRect || !colRect || !bodyRect ) {
							clearHoverCell();
							return;
						}
						var relTop = slotRect.top - bodyRect.top;
						var relLeft = colRect.left - bodyRect.left;
						if ( !hoverCellEl ) {
							hoverCellEl = document.createElement( 'div' );
							hoverCellEl.className = 'fc-timegrid-cell-hover';
							hoverTimeEl = document.createElement( 'span' );
							hoverTimeEl.className = 'fc-timegrid-cell-hover-time';
							hoverCellEl.appendChild( hoverTimeEl );
							timeGridBody.appendChild( hoverCellEl );
						}
						var timeLabel = getSlotTimeLabel( slotLane );
						if ( hoverTimeEl ) {
							hoverTimeEl.textContent = timeLabel;
						}
						if ( hoverCellEl && hoverCellEl.classList ) {
							hoverCellEl.classList.toggle( 'is-empty', !timeLabel );
						}
						hoverCellEl.style.top = relTop + 'px';
						hoverCellEl.style.left = relLeft + 'px';
						hoverCellEl.style.width = colRect.width + 'px';
						hoverCellEl.style.height = slotRect.height + 'px';
					} catch ( _ ) {}
				}, 12 );
			}

			if ( calendarEl ) {
				refreshTimeGridCaches( true );
				calendarEl.addEventListener( 'mousemove', onTimeGridMouseMove );
				calendarEl.addEventListener( 'mouseleave', clearHoverCell );
				calendarEl.addEventListener( 'mousedown', onTimeGridPointerDown, true );
				calendarEl.addEventListener( 'mouseup', onTimeGridPointerUp, true );
				calendarEl.addEventListener( 'touchstart', onTimeGridPointerDown, true );
				calendarEl.addEventListener( 'touchend', onTimeGridPointerUp, true );
			}
			function invalidateAppointmentsAndRefetch( markCreate ) {
				try {
					if ( markCreate ) {
						pendingCreateRef.current = Date.now();
					}
					skipAvailRef.current = true;
					appointmentsDirtyRef.current = true;
					availabilitiesDirtyRef.current = false;
					clearPreloadedAppointments();
					if ( !dragInProgressRef.current ) {
						triggerCalendarRefetch();
					}
				} catch ( e ) {}
			}

			// Expose a global refresh hook for panel compatibility integrations.
			try {
				// Immediate refresh triggered by compatibility integrations after create
				// Always refetch so the new appointment appears on the calendar
				window.wcAppointmentsRefreshCalendar = function() {
					invalidateAppointmentsAndRefetch( true );
				};
			} catch ( e ) {}

			// ── Preview event API for create panel (Google Calendar-style live preview) ──
			try {
				var __wcaPreviewId = '__wca-preview';
				var getCalendarApi = function() {
					return calRef.current || null;
				};
				var getCalendarEventById = function( eventId ) {
					var cal = getCalendarApi();
					if ( !cal || !eventId || 'function' !== typeof cal.getEventById ) {
						return null;
					}
					return cal.getEventById( eventId );
				};
				var removeCalendarEventById = function( eventId ) {
					var ev = getCalendarEventById( eventId );
					if ( ev ) {
						ev.remove();
					}
				};
				var setAppointmentDisplayProp = function( apptId, display ) {
					if ( !apptId ) {
						return;
					}
					var ev = getCalendarEventById( 'appt-' + String( apptId ) );
					if ( ev ) {
						ev.setProp( 'display', display );
					}
				};
				window.__wcaCalPreview = {
					// Show or update a preview event on the calendar.
					// data: { startISO, endISO, allDay, title (customer label), color, startTs, endTs }
					update: function( data ) {
						try {
							if ( !data || ( !data.startISO && !data.startTs ) ) { return; }
							var cal = getCalendarApi();
							if ( !cal ) { return; }
							// Build ISO strings from timestamps if not provided directly
							var startISO = data.startISO || '';
							var endISO = data.endISO || '';
							if ( !startISO && data.startTs ) {
								startISO = tsToAdminLocalISO( data.startTs );
							}
							if ( !endISO && data.endTs ) {
								endISO = tsToAdminLocalISO( data.endTs );
							}
							var isAllDay = !!data.allDay;
							// Timed preview without end: use one slot (30m), not FC's former 1h default.
							if ( !isAllDay && !endISO ) {
								if ( data.startTs ) {
									endISO = tsToAdminLocalISO( data.startTs + 1800 );
								} else if ( startISO ) {
									var __d = new Date( startISO );
									if ( !isNaN( __d.getTime() ) ) {
										__d.setMinutes( __d.getMinutes() + 30 );
										var __pad = function( n ) { return ( n < 10 ? '0' : '' ) + n; };
										endISO = __d.getFullYear() + '-' + __pad( __d.getMonth() + 1 ) + '-' + __pad( __d.getDate() ) + 'T' + __pad( __d.getHours() ) + ':' + __pad( __d.getMinutes() ) + ':' + __pad( __d.getSeconds() );
									}
								}
							}
							if ( isAllDay && data.startTs ) {
								startISO = tsToNaiveLocalDate( data.startTs );
								if ( data.endTs ) {
									var day = 86400;
									var endExTs = ( Math.floor( ( data.endTs - 1 ) / day ) + 1 ) * day;
									endISO = tsToNaiveLocalDate( endExTs );
								}
							}
							// Remove existing preview
							removeCalendarEventById( __wcaPreviewId );
							// Match real appointment events: product color + contrast text; block display in
							// month grid so title shows inside the bar (same as week/day), not only a dot.
							var previewClasses = [ 'wca-preview-event' ];
							var clr = data.color && String( data.color ).trim();
							if ( clr ) {
								previewClasses.push( 'wca-preview-event--product' );
							} else {
								previewClasses.push( 'wca-preview-event--neutral' );
							}
							var evPreview = {
								id: __wcaPreviewId,
								title: data.title || t( 'newAppointment', 'New Appointment' ),
								start: startISO,
								end: endISO || undefined,
								allDay: isAllDay,
								// Omit display: use FullCalendar defaults — month view: all-day = full bar,
								// timed = list-item + dot (same as real appointment events).
								editable: false,
								classNames: previewClasses,
								extendedProps: { __wcaPreview: true }
							};
							if ( clr ) {
								evPreview.backgroundColor = clr;
								evPreview.borderColor = clr;
								evPreview.textColor = chooseTextColor( clr );
							}
							cal.addEvent( evPreview );
						} catch ( _prev ) {}
					},
					// Remove the preview event from the calendar.
					remove: function() {
						try {
							removeCalendarEventById( __wcaPreviewId );
						} catch ( _prev ) {}
					},
					setTitle: function( title ) {
						try {
							var cal = getCalendarApi();
							var ev = cal && cal.getEventById( __wcaPreviewId );
							if ( ev ) { ev.setProp( 'title', title || '' ); }
						} catch ( _t ) {}
					},
					// Navigate the calendar to show the given date (YYYY-MM-DD string).
					// Returns true if navigation was triggered (date was outside visible range).
					navigateTo: function( dateStr ) {
						try {
							var cal = getCalendarApi();
							if ( !cal || !dateStr ) { return false; }
							// Only navigate if the date is outside the current visible range
							var view = cal.view;
							if ( !view ) { return false; }
							var aS = view.activeStart || view.currentStart;
							var aE = view.activeEnd || view.currentEnd;
							var target = new Date( dateStr + 'T12:00:00' );
							if ( target >= aS && target < aE ) { return false; }
							cal.gotoDate( target );
							return true;
						} catch ( _nav ) { return false; }
					},
					// Hide a calendar event by appointment ID (prevents duplicate display during edit).
					hideEvent: function( apptId ) {
						try {
							setAppointmentDisplayProp( apptId, 'none' );
						} catch ( _h ) {}
					},
					// Show a previously hidden calendar event by appointment ID.
					showEvent: function( apptId ) {
						try {
							setAppointmentDisplayProp( apptId, 'auto' );
						} catch ( _s ) {}
					},
					// Scroll calendar scrollers + page so the preview stays visible next to the panel.
					// FullCalendar nests several .fc-scrollers (horizontal vs vertical); closest() often
					// misses the vertical one, so we walk ancestors and adjust every vertical scrollport.
					openView: openViewById,
					scrollToAnchor: function( anchorEl, repositionPanel ) {
						try {
							if ( !anchorEl ) { return; }
							var calEl = calRef.current && calRef.current.el;
							// Keep anchor away from viewport / scroller edges; matches panel placement
							// (panel is vertically centered on the event midpoint in calculatePanelPosition).
							var VIEW_PAD = 100;
							function collectVerticalScrollers( fromEl, stopAt ) {
								var list = [];
								var n = fromEl.parentElement;
								while ( n && n !== stopAt && n !== document.body ) {
									var st = window.getComputedStyle( n );
									var oy = st.overflowY;
									if ( ( oy === 'auto' || oy === 'scroll' || oy === 'overlay' ) && n.scrollHeight > n.clientHeight + 1 ) {
										list.push( n );
									}
									n = n.parentElement;
								}
								return list;
							}
							function scrollerPad( sr ) {
								return Math.min( VIEW_PAD, Math.max( 8, Math.floor( sr.height / 6 ) ) );
							}
							function centerAnchorInScroller( scroller ) {
								var er = anchorEl.getBoundingClientRect();
								var sr = scroller.getBoundingClientRect();
								var pad = scrollerPad( sr );
								if ( er.top >= sr.top + pad && er.bottom <= sr.bottom - pad ) {
									return false;
								}
								// Align event vertical midpoint with scroller viewport midpoint (same axis as panel).
								var relTop = ( er.top - sr.top ) + scroller.scrollTop;
								var target = relTop - ( sr.height / 2 ) + ( er.height / 2 );
								var clamped = Math.max( 0, Math.min( target, scroller.scrollHeight - scroller.clientHeight ) );
								if ( Math.abs( clamped - scroller.scrollTop ) < 1 ) {
									return false;
								}
								scroller.scrollTop = clamped;
								return true;
							}
							// Few passes: inner scroll affects outer visibility.
							var pass, p, scrollers;
							for ( pass = 0; pass < 4; pass++ ) {
								scrollers = collectVerticalScrollers( anchorEl, calEl || null );
								var any = false;
								for ( p = 0; p < scrollers.length; p++ ) {
									if ( centerAnchorInScroller( scrollers[ p ] ) ) {
										any = true;
									}
								}
								if ( !any ) {
									break;
								}
							}
							// If the calendar sits inside a scrollable admin column, adjust that too.
							if ( calEl ) {
								for ( pass = 0; pass < 3; pass++ ) {
									scrollers = collectVerticalScrollers( calEl, null );
									var any2 = false;
									for ( p = 0; p < scrollers.length; p++ ) {
										if ( centerAnchorInScroller( scrollers[ p ] ) ) {
											any2 = true;
										}
									}
									if ( !any2 ) {
										break;
									}
								}
							}
							// Scroll the document so the anchor sits in the viewport with ~VIEW_PAD margin
							// and its vertical center lines up with the viewport center (panel is centered on event).
							var er2 = anchorEl.getBoundingClientRect();
							var vh = window.innerHeight;
							var root = document.scrollingElement || document.documentElement;
							var eventMid = er2.top + er2.height / 2;
							var vpMid = vh / 2;
							var needDocScroll = er2.top < VIEW_PAD || er2.bottom > vh - VIEW_PAD;
							if ( needDocScroll ) {
								root.scrollTop += eventMid - vpMid;
							}
							if ( repositionPanel && window.wcaPanel && window.wcaPanel.updateTrigger ) {
								requestAnimationFrame( function() {
									window.wcaPanel.updateTrigger( anchorEl );
								} );
							}
						} catch ( _sp ) {}
					},
					scrollToPreview: function() {
						this.scrollToAnchor( document.querySelector( '.wca-preview-event' ) );
					}
				};
			} catch ( e ) {}

			// Also listen for custom panel/compatibility events to refetch
			var onAppointmentsCreated = function() {
				invalidateAppointmentsAndRefetch( true );
			};
			var onAppointmentsUpdated = function() {
				invalidateAppointmentsAndRefetch( false );
			};
			var onAppointmentsDeleted = onAppointmentsUpdated;
			var onAvailabilityChanged = function() {
				try {
					availabilitiesDirtyRef.current = true;
					triggerCalendarRefetch();
				} catch ( e ) {}
			};
			try {
				window.addEventListener( 'wc_appointments_created', onAppointmentsCreated );
				window.addEventListener( 'wc_appointments_updated', onAppointmentsUpdated );
				window.addEventListener( 'wc_appointments_deleted', onAppointmentsDeleted );
				window.addEventListener( 'wca_availability_created', onAvailabilityChanged );
				window.addEventListener( 'wca_availability_updated', onAvailabilityChanged );
				window.addEventListener( 'wca_availability_deleted', onAvailabilityChanged );
			} catch ( e ) {}
			return function() {
				try {
					window.removeEventListener( 'resize', onCalendarResize );
					window.removeEventListener( 'scroll', onStickyChromeScroll );
				} catch ( _ ) {}
				try {
					window.removeEventListener( 'wc_appointments_created', onAppointmentsCreated );
					window.removeEventListener( 'wc_appointments_updated', onAppointmentsUpdated );
					window.removeEventListener( 'wc_appointments_deleted', onAppointmentsDeleted );
					window.removeEventListener( 'wca_availability_created', onAvailabilityChanged );
					window.removeEventListener( 'wca_availability_updated', onAvailabilityChanged );
					window.removeEventListener( 'wca_availability_deleted', onAvailabilityChanged );
				} catch ( _ ) {}
				try {
					if ( calendarEl ) {
						calendarEl.removeEventListener( 'mousemove', onTimeGridMouseMove );
						calendarEl.removeEventListener( 'mouseleave', clearHoverCell );
						calendarEl.removeEventListener( 'mousedown', onTimeGridPointerDown, true );
						calendarEl.removeEventListener( 'mouseup', onTimeGridPointerUp, true );
						calendarEl.removeEventListener( 'touchstart', onTimeGridPointerDown, true );
						calendarEl.removeEventListener( 'touchend', onTimeGridPointerUp, true );
					}
					cachedDayCols = null;
					cachedSlotLanes = null;
					gridCacheTs = 0;
					clearHoverCell();
					calendar.destroy();
				} catch ( e ) {}
			};
		}, [] ); // Only initialize calendar once on mount; filter changes handled via refetchEvents

		// Re-evaluate past/active state periodically so opacity stays current without navigation
		useEffect( function() {
			var t = setInterval( function() {
				try {
					if ( dragInProgressRef.current ) {
						return;
					}
					if ( calRef.current && 'function' === typeof calRef.current.rerenderEvents ) {
						calRef.current.rerenderEvents();
					}
				} catch ( e ) {}
			}, 60000 );
			return function() {
				try {
					clearInterval( t );
				} catch ( e ) {}
			};
		}, [] );

		// Live updates via SSE: replace aggressive polling
		useEffect( function() {
			var src = null;
			var watchdog = null;
			var reconnectTimer = null;
			var destroyed = false;
			var sseRetryMs = 15000; // one-shot reconnect; matches WC_Appointments_SSE::get_retry_ms()
			var ajaxUrl = '';
			var onVisibility = null;

			try {
				sseRetryMs = parseInt( wcAppointmentsReactCalendar.sseRetryMs || '15000', 10 ) || 15000;
			} catch ( _e ) {}

			try {
				ajaxUrl = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.ajaxUrl ) ? wcAppointmentsReactCalendar.ajaxUrl : '';
			} catch ( _r0 ) {
				ajaxUrl = '';
			}
			var ES = ( window && window.EventSource ) ? window.EventSource : null;
			if ( !ES || !ajaxUrl ) {
				return function() {};
			}

			function clearWatchdog() {
				try {
					if ( watchdog ) {
						clearTimeout( watchdog );
						watchdog = null;
					}
				} catch ( _ ) {}
			}

			function resetWatchdog() {
				try {
					clearWatchdog();
					watchdog = setTimeout( function() {
						try {
							if ( destroyed ) {
								return;
							}
							if ( document && document.hidden ) {
								return;
							}
							if ( dragInProgressRef.current ) {
								return;
							}
							triggerCalendarRefetch();
						} catch ( _w ) {}
					}, 60000 );
				} catch ( _ ) {}
			}

			function closeSource() {
				try {
					if ( src && 'function' === typeof src.close ) {
						src.close();
					}
				} catch ( _ ) {}
				src = null;
			}

			function clearVisibilityWait() {
				try {
					if ( onVisibility ) {
						document.removeEventListener( 'visibilitychange', onVisibility );
						onVisibility = null;
					}
				} catch ( _ ) {}
			}

			function buildSseUrl() {
				try {
					var u = new URL( ajaxUrl );
					u.searchParams.set( 'action', 'wca_sse_stream' );
					var lastId = 0;
					try {
						// Use site-specific localStorage key for multisite compatibility
						var blogId = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.blogId ) ? wcAppointmentsReactCalendar.blogId : '';
						var storageKey = blogId ? 'wca:lastEventId:' + blogId : 'wca:lastEventId';
						lastId = window.localStorage ? parseInt( window.localStorage.getItem( storageKey ) || '0', 10 ) : 0;
					} catch ( _s ) {
						lastId = 0;
					}
					if ( 0 < lastId ) {
						u.searchParams.set( 'since_id', String( lastId ) );
					}
					return u.toString();
				} catch ( _ ) {
					return '';
				}
			}

			function scheduleReconnect() {
				if ( destroyed ) {
					return;
				}
				try {
					if ( reconnectTimer ) {
						clearTimeout( reconnectTimer );
						reconnectTimer = null;
					}
					clearVisibilityWait();
					// One-shot streams always end in error after open; honor server retry.
					if ( document && document.hidden ) {
						onVisibility = function() {
							if ( destroyed || document.hidden ) {
								return;
							}
							clearVisibilityWait();
							startStream();
						};
						document.addEventListener( 'visibilitychange', onVisibility );
						return;
					}
					reconnectTimer = setTimeout( function() {
						reconnectTimer = null;
						startStream();
					}, sseRetryMs + Math.floor( Math.random() * 500 ) );
				} catch ( _ ) {}
			}

			function startStream() {
				if ( destroyed ) {
					return;
				}
				if ( document && document.hidden ) {
					scheduleReconnect();
					return;
				}
				closeSource();
				clearWatchdog();
				clearVisibilityWait();
				var url = buildSseUrl();
				if ( !url ) {
					scheduleReconnect();
					return;
				}
				try {
					src = new ES( url, { withCredentials: true } );
				} catch ( _err ) {
					scheduleReconnect();
					return;
				}
				// Deduplicate SSE events for a short TTL to avoid double-handling
				var __sseSeen = {};
				var __sseTTL = 3000;
				var inCurrentRange = function( st, en ) {
					try {
						var cal = calRef.current;
						if ( !cal || !cal.view ) {
							return true;
						}
						var aS = cal.view.activeStart || cal.view.currentStart || cal.view.start;
						var aE = cal.view.activeEnd || cal.view.currentEnd || cal.view.end;
						var sTs = Math.floor( aS.getTime() / 1000 );
						var eTs = Math.floor( aE.getTime() / 1000 );
						return ( en > sTs ) && ( st < eTs );
					} catch ( _ ) {
						return true;
					}
				};
				var passesStaffFilter = function( row, activeStaffId ) {
					if ( null === activeStaffId ) {
						return true;
					}
					return appointmentMatchesStaffFilterId( row, activeStaffId );
				};
				var resolveActiveStaffFilter = function() {
					if ( 'unassigned' === staffId ) {
						return 0;
					}
					return staffId || null;
				};
				var isRowVisibleInCurrentView = function( row ) {
					try {
						var st = parseInt( row.start, 10 );
						var en = parseInt( row.end, 10 );
						if ( isExcludedStatus( row.status ) ) {
							return false;
						}
						if ( productId && String( row.product_id ) !== String( productId ) ) {
							return false;
						}
						if ( !passesStaffFilter( row, resolveActiveStaffFilter() ) ) {
							return false;
						}
						if ( !inCurrentRange( st, en ) ) {
							return false;
						}
						return true;
					} catch ( _ ) {
						return true;
					}
				};
				var refetchCurrentCalendar = function() {
					var cal = calRef.current;
					if ( cal && 'function' === typeof cal.refetchEvents ) {
						cal.refetchEvents();
					}
				};
				var getResourceIdFromEvent = function( evt ) {
					return evt && evt.resource_id ? evt.resource_id : ( evt && evt.payload && evt.payload.id ? evt.payload.id : null );
				};
				var showToastForTopic = function( topic, payload, resourceId ) {
					try {
						var toastMsg = getToastMessageForEvent( topic, payload || {}, wcAppointmentsReactCalendar.i18n || {}, resourceId || '' );
						if ( toastMsg && toastMsg.message ) {
							showToast( toastMsg.message, toastMsg.type || 'info', toastMsg.groupKey );
						}
					} catch ( __toast ) {}
				};
				// Remove existing appointment events from FullCalendar by id
				var removeAppt = function( id ) {
					try {
						var cal = calRef.current;
						if ( !cal ) {
							return;
						}
						var arr = ( 'function' === typeof cal.getEvents ) ? ( function() {
							try {
								var apptIdStr = String( id );
								var eid = 'appt-' + apptIdStr;
								var all = cal.getEvents();
								var out = [];
								for ( var i = 0; i < all.length; i++ ) {
									var evx = all[ i ];
									var p = evx.extendedProps || {};
									var m1 = String( evx.id || '' ) === eid;
									var m2 = String( p.appointmentId || p.appointment_id || '' ) === apptIdStr;
									if ( m1 || m2 ) {
										out.push( evx );
									}
								}
								return out;
							} catch ( __ ) {
								return [];
							}
						}() ) : [];
						for ( var j = 0; j < arr.length; j++ ) {
							try {
								arr[ j ].remove();
							} catch ( __r ) {}
						}
						if ( 'function' === typeof cal.getEventById ) {
							var ev = cal.getEventById( 'appt-' + String( id ) );
							if ( ev ) {
								try {
									ev.remove();
								} catch ( __r2 ) {}
							}
						}
						clearSseInjectionFlag( id );
					} catch ( _ ) {}
				};
				var addAppointmentRowToCalendar = function( cal, row ) {
					var usersIdx = window.__wcaUsersIndex || {};
					var colorsIdx = window.__wcaProductColorsIndex || {};
					removeAppt( row.id );
					var mk = ( window && 'function' === typeof window.__wcaBuildAppointmentEvent ? window.__wcaBuildAppointmentEvent : ( window && 'function' === typeof window.buildAppointmentEvent ? window.buildAppointmentEvent : null ) );
					if ( 'function' !== typeof mk ) {
						return false;
					}
					var evt = mk ? mk( row, usersIdx, colorsIdx ) : null;
					if ( evt && 'function' === typeof cal.addEvent ) {
						var added = cal.addEvent( evt );
						recordSseInjection( row.id, added );
					}
					return !!evt;
				};
				// Fetch and inject a single appointment into the current calendar
				var injectAppt = function( id ) {
					try {
						var cal = calRef.current;
						if ( !cal ) {
							return;
						}

						// Fetch single appointment with all modal data fields using the appointments endpoint
						// (calendar endpoint requires date range, so we use appointments for single fetch)
						// Include all fields needed for modal display to avoid subsequent API calls
						apiGet( 'wc-appointments/v2/appointments/' + String( id ), {
							_fields: ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.calendarPanelFields ) ? wcAppointmentsReactCalendar.calendarPanelFields : ''
						} ).then( function( row ) {
							try {
								if ( !row || !row.id || !isRowVisibleInCurrentView( row ) ) {
									return;
								}
								updatePreloadedAppointment( row.id, row );
								if ( window.panelSeries && window.panelSeries.indexPreloadFromRows ) {
									window.panelSeries.indexPreloadFromRows( [ row ] );
								}
								addAppointmentRowToCalendar( cal, row );
							} catch ( _inj ) {}
						} ).catch( function() {} );
					} catch ( _ ) {}
				};
				try {
					window.__wcaInjectAppointment = injectAppt;
				} catch ( _injex ) {}

				var upsertAppointmentEvent = function( row ) {
					try {
						var cal = calRef.current;
						if ( !cal ) {
							return false;
						}
						if ( !addAppointmentRowToCalendar( cal, row ) ) {
							return false;
						}
						if ( 'function' === typeof cal.rerenderEvents ) {
							cal.rerenderEvents();
						}
						return true;
					} catch ( _ ) {
						return false;
					}
				};

				// Track SSE connection readiness to control refetch behavior
				src.addEventListener( 'open', function() {
					try {
						sseReadyRef.current = true;
					} catch ( _r ) {}
					resetWatchdog();
				} );
				src.addEventListener( 'error', function() {
					try {
						sseReadyRef.current = false;
					} catch ( _r2 ) {}
					resetWatchdog();
					closeSource();
					scheduleReconnect();
				} );
				// Handle appointment and availability SSE events with gating
				var onEvent = function( e ) {
					try {
						if ( dragInProgressRef.current ) {
							return;
						}

						// SSE data comes as a JSON string that needs to be parsed
						var rawData = e.data || '';
						var d = typeof rawData === 'string' ? JSON.parse( rawData ) : (rawData || {});
						var topic = d.topic || '';
						var id = d.id || '';
						var resourceId = d.resource_id || '';
						var resource = d.resource || '';

						// Deduplicate SSE events to prevent duplicate processing
						var sseKey = resource + ':' + resourceId + ':' + topic;
						var now = Date.now();
						if ( __sseSeen[ sseKey ] && ( now - __sseSeen[ sseKey ] ) < __sseTTL ) {
							return; // Skip duplicate
						}
						__sseSeen[ sseKey ] = now;

						try {
							var evId = e && e.lastEventId ? parseInt( e.lastEventId, 10 ) : 0;
							if ( 0 < evId && window.localStorage ) {
								// Use site-specific localStorage key for multisite compatibility
								var blogId = ( wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.blogId ) ? wcAppointmentsReactCalendar.blogId : '';
								var storageKey = blogId ? 'wca:lastEventId:' + blogId : 'wca:lastEventId';
								window.localStorage.setItem( storageKey, String( evId ) );
							}
						} catch ( _ ) {}
						var t = String( d.topic || '' );
						if ( 0 === t.indexOf( 'appointment.' ) || 0 === t.indexOf( 'availability.' ) ) {
							try {
								window.dispatchEvent( new CustomEvent( 'wca_browse_invalidate' ) );
							} catch ( __bi ) {}
						}
						if ( 0 === t.indexOf( 'appointment.' ) ) {
							// If this is a delete/trash/cancel event, remove and exit early
							if ( /\.(deleted|trashed|cancelled)$/.test( t ) ) {
								var deletedResourceId = getResourceIdFromEvent( d );
								try {
									if ( deletedResourceId ) {
										removePreloadedAppointment( deletedResourceId );
									}
								} catch ( __rc ) {}
								try {
									if ( deletedResourceId ) {
										removeAppt( deletedResourceId );
									} else {
										refetchCurrentCalendar();
									}
								} catch ( __del ) {}
								showToastForTopic( t, d.payload, d.resource_id );
								return;
							}
							appointmentsDirtyRef.current = true;
							skipAvailRef.current = true;
							// Selectively update server preload so in-range view switches stay instant
							if ( d && d.payload && d.payload.id ) {
								updatePreloadedAppointment( d.payload.id, d.payload );
								if ( window.panelSeries && window.panelSeries.indexPreloadFromRows ) {
									window.panelSeries.indexPreloadFromRows( [ d.payload ] );
								}
							}
							if ( d && d.resource_id ) {
								if ( d.payload && d.payload.id ) {
									try {
										var row = d.payload;

										// Always show toast for appointment events, even if outside current view
										showToastForTopic( t, d.payload, d.resource_id );

										// Clear pending create marker after SSE delivers the event
										try {
											pendingCreateRef.current = 0;
										} catch ( ___pc ) {}

										if ( !isRowVisibleInCurrentView( row ) ) {
											return;
										}
										var cal = calRef.current;
										if ( !cal ) {
											try {
												injectAppt( row.id );
											} catch ( __ ) {}
											return;
										}
										// Upsert or inject appointment into the calendar from SSE payload
										try {
											if ( !upsertAppointmentEvent( row ) ) {
												injectAppt( row.id );
											}

										} catch ( __up ) {
											try {
												injectAppt( row.id );
											} catch ( ___inj ) {}
										}
									} catch ( __ ) {}
								} else {
									// No payload, fetch and update preload
									injectAppt( d.resource_id );
								}
							}
							// handled via direct injection above
						} else if ( 0 === t.indexOf( 'availability.' ) ) {
							availabilitiesDirtyRef.current = true;
							// Force availability refetch even if a previous appointment flow skipped it.
							skipAvailRef.current = false;
							refetchCurrentCalendar();
							showToastForTopic( t, d.payload, d.resource_id );
						} else if ( /\.(deleted|trashed)$/.test( t ) ) {
							if ( d && d.resource_id ) {
								removeAppt( d.resource_id );
							} else {
								refetchCurrentCalendar();
							}
						}
						resetWatchdog();
					} catch ( _ ) {}
				};
				src.addEventListener( 'appointment.created', onEvent );
				src.addEventListener( 'appointment.updated', onEvent );
				src.addEventListener( 'appointment.deleted', onEvent );
				src.addEventListener( 'appointment.trashed', onEvent );
				src.addEventListener( 'appointment.rescheduled', onEvent );
				src.addEventListener( 'appointment.cancelled', onEvent );
				src.addEventListener( 'availability.created', onEvent );
				src.addEventListener( 'availability.updated', onEvent );
				src.addEventListener( 'availability.deleted', onEvent );
				// Also handle default messages in case server does not set event names
				src.addEventListener( 'message', onEvent );
			}

			startStream();

			return function() {
				destroyed = true;
				clearWatchdog();
				clearVisibilityWait();
				closeSource();
				try {
					if ( reconnectTimer ) {
						clearTimeout( reconnectTimer );
					}
				} catch ( _ ) {}
				try {
					delete window.__wcaInjectAppointment;
				} catch ( _injex ) {}
				delete window.__wcaBuildCreatePanelCallbacks;
			};
		}, [] );

		// Listen for session expiration events (401/403 from REST API)
		useEffect( function() {
			function onSessionExpired() {
				setError( t( 'sessionExpired', 'Your session has expired. Please reload the page to continue editing.' ) );
			}
			window.addEventListener( 'wca_session_expired', onSessionExpired );
			return function() {
				window.removeEventListener( 'wca_session_expired', onSessionExpired );
			};
		}, [] );

		function setQSParam( name, value ) {
			try {
				var currentHref = window.location.href;
				var url = new URL( currentHref );
				var existing = url.searchParams.get( name );
				var isEmpty = ( '' === value || null === value || value === undefined );
				if ( isEmpty ) {
					if ( null === existing ) {
						return;
					}
					url.searchParams.delete( name );
				} else {
					if ( String( existing ) === String( value ) ) {
						return;
					}
					url.searchParams.set( name, value );
				}
				var nextHref = url.toString();
				if ( nextHref !== currentHref ) {
					window.history.replaceState( {}, '', nextHref );
				}
			} catch ( e ) {}
		}

		useEffect( function() {
			setQSParam( 'product_id', productId || '' );
		}, [ productId ] );
		useEffect( function() {
			setQSParam( 'staff_id', staffId || '' );
		}, [ staffId ] );

		function mapViewToParam( v ) {
			switch ( v ) {
				case 'dayGridMonth':
					return 'month';
				case 'timeGridDay':
					return 'day';
				case 'listWeek':
					return 'list';
				case 'timeGridWeek':
				default:
					return 'week';
			}
		}

		function changeView( v, date ) {
			if ( 'timeGridDay' !== v ) {
				monthReturnYmdRef.current = '';
				setShowMonthBack( false );
			}
			if ( calRef.current ) {
				calRef.current.changeView( v, date );
			}
			setCurrentView( v );
			var viewParam = mapViewToParam( v );
			setQSParam( 'view', viewParam );

			// Save view preference to user meta (fire-and-forget)
			var ajaxUrl = wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.ajaxUrl;
			var viewNonce = wcAppointmentsReactCalendar && wcAppointmentsReactCalendar.viewNonce;
			if ( ajaxUrl && viewNonce ) {
				var formData = new FormData();
				formData.append( 'action', 'wc_appointments_save_calendar_view' );
				formData.append( 'security', viewNonce );
				formData.append( 'view', viewParam );
				fetch( ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' } ).catch( function() {} );
			}
		}

		function backToMonth() {
			var p = ( monthReturnYmdRef.current || '' ).split( '-' );
			monthReturnYmdRef.current = '';
			setShowMonthBack( false );
			changeView( 'dayGridMonth', 3 === p.length ? new Date( +p[ 0 ], +p[ 1 ] - 1, +p[ 2 ] ) : undefined );
		}

		function prev() {
			if ( calRef.current ) {
				calRef.current.prev();
			}
		}

		function next() {
			if ( calRef.current ) {
				calRef.current.next();
			}
		}

		function today() {
			if ( calRef.current ) {
				calRef.current.today();
			}
		}

		function gotoPeriodDate( ymd ) {
			if ( calRef.current && ymd ) {
				calRef.current.gotoDate( new Date( ymd + 'T12:00:00' ) );
			}
		}

		return h(
			'div', {
				className: 'wca-react-calendar wca-view-' + ( currentView || 'timeGridWeek' )
			},
			h( Toolbar, {
				title: viewTitle,
				periodYmd: periodYmd,
				products: products,
				staff: staff,
				canManageOthers: canManageOthers,
				productIds: productIds,
				setProductIds: setProductIds,
				staffIds: staffIds,
				setStaffIds: setStaffIds,
				locationIds: locationIds,
				setLocationIds: setLocationIds,
				statusIds: statusIds,
				setStatusIds: setStatusIds,
				filtersOpen: filtersOpen,
				setFiltersOpen: setFiltersOpen,
				changeView: changeView,
				showMonthBack: showMonthBack,
				onBackToMonth: backToMonth,
				onPrev: prev,
				onNext: next,
				onToday: today,
				onGotoDate: gotoPeriodDate,
				currentView: currentView
			} ),
			error ? h( 'div', {
				className: 'notice notice-error'
			}, h( 'p', null, error, ' ', h( 'a', {
				href: '#',
				onClick: function( e ) {
					e.preventDefault();
					window.location.reload();
				},
				style: { textDecoration: 'underline', cursor: 'pointer' }
			}, t( 'reloadPage', 'Reload page' ) ) ) ) : null,
			h( 'div',
				{
					className: 'wca-calendar-container'
				},
				h( 'div',
					{
						className: 'wca-loading-bar' + ( loadingEvents ? ' is-active' : '' )
					}
				),
				h( 'div',
					{
						id: 'wca-calendar-view',
						ref: calElRef
					}
				)
			),
			'listWeek' !== currentView ? h(
				'div',
				{
					className: 'wca-calendar-legend',
					'aria-label': t( 'stripedBackgroundLegend', 'Striped background indicates unavailable time blocked by availability rules.' )
				},
				h( 'span', { className: 'wca-calendar-legend__item' },
					h( 'span', {
						className: 'wca-calendar-legend__swatch',
						'aria-hidden': 'true'
					} ),
					h( 'span', { className: 'wca-calendar-legend__text' }, t( 'stripedBackgroundLegend', 'Striped background indicates unavailable time blocked by availability rules.' ) )
				)
			) : null,
			h( ToastContainer )
		);
	}

	// Expose helper functions globally for the contextual panel (appointment-admin-panel.js)
	window.__wcaFormatDateByPattern = formatDateByPattern;
	window.__wcaFormatTimeByPattern = formatTimeByPattern;
	window.__wcaConvertToAdminTimezone = convertToAdminTimezone;
	window.__wcaIsAllDayRangeTs = isAllDayRangeTs;

	document.addEventListener( 'DOMContentLoaded', function() {
		var rootEl = document.getElementById( 'wca-react-calendar-root' );
		if ( !rootEl ) {
			return;
		}
		if ( wp.element && 'function' === typeof wp.element.createRoot ) {
			var root = wp.element.createRoot( rootEl );
			root.render( h( App ) );
		} else if ( wp.element && 'function' === typeof wp.element.render ) {
			wp.element.render( h( App ), rootEl );
		}
	} );
} )();
