/**
 * Staff Profile Sidebar Navigation
 *
 * Transforms the WordPress user profile page into a sidebar navigation layout.
 * Finds all h2 section headings and creates navigation from them.
 * Syncs with WordPress admin color scheme.
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

(function() {
	'use strict';

	/**
	 * WordPress Admin Color Schemes
	 * Maps color scheme names to their primary colors
	 */
	var colorSchemes = {
		'fresh': { // Default
			primary: '#2271b1',
			primaryHover: '#135e96',
			primaryLight: 'rgba(34, 113, 177, 0.08)',
			primaryBg: '#f0f6fc'
		},
		'light': {
			primary: '#0073aa',
			primaryHover: '#006799',
			primaryLight: 'rgba(0, 115, 170, 0.08)',
			primaryBg: '#e5f5fa'
		},
		'modern': {
			primary: '#3858e9',
			primaryHover: '#2145e6',
			primaryLight: 'rgba(56, 88, 233, 0.08)',
			primaryBg: '#eef1fd'
		},
		'blue': {
			primary: '#096484',
			primaryHover: '#07526c',
			primaryLight: 'rgba(9, 100, 132, 0.08)',
			primaryBg: '#e5f1f5'
		},
		'coffee': {
			primary: '#c7a589',
			primaryHover: '#9c7f6a',
			primaryLight: 'rgba(199, 165, 137, 0.12)',
			primaryBg: '#f7f3f0'
		},
		'ectoplasm': {
			primary: '#a3b745',
			primaryHover: '#829237',
			primaryLight: 'rgba(163, 183, 69, 0.1)',
			primaryBg: '#f4f6eb'
		},
		'midnight': {
			primary: '#e14d43',
			primaryHover: '#dd382d',
			primaryLight: 'rgba(225, 77, 67, 0.1)',
			primaryBg: '#fceeed'
		},
		'ocean': {
			primary: '#9ebaa0',
			primaryHover: '#738e75',
			primaryLight: 'rgba(158, 186, 160, 0.15)',
			primaryBg: '#f2f6f2'
		},
		'sunrise': {
			primary: '#dd823b',
			primaryHover: '#c36922',
			primaryLight: 'rgba(221, 130, 59, 0.1)',
			primaryBg: '#fdf4ed'
		}
	};

	/**
	 * Collect all sibling elements after startEl until one matches the selector.
	 *
	 * @param {Element} startEl  The starting element.
	 * @param {string}  selector CSS selector to stop at.
	 * @return {Element[]} Array of in-between sibling elements.
	 */
	function getElementsUntil(startEl, selector) {
		var elements = [];
		var el = startEl.nextElementSibling;
		while (el && !el.matches(selector)) {
			elements.push(el);
			el = el.nextElementSibling;
		}
		return elements;
	}

	/**
	 * Create a DOM element from an HTML string.
	 *
	 * @param {string} html HTML markup.
	 * @return {Element} The created element.
	 */
	function createElement(html) {
		var tpl = document.createElement('template');
		tpl.innerHTML = html.trim();
		return tpl.content.firstChild;
	}

	var StaffProfile = {
		sections: [],
		activeSection: null,
		form: null,
		nav: null,
		content: null,
		mobileMenuOpen: false,

		/**
		 * Initialize - transform the profile page.
		 */
		init: function() {
			this.form = document.querySelector('form#your-profile');
			if (!this.form) {
				return;
			}

			// Apply color scheme first
			this.applyColorScheme();

			// Build sections from h2 headings
			this.buildSections();

			if (this.sections.length === 0) {
				return;
			}

			// Create the sidebar layout
			this.createLayout();

			// Bind events
			this.bindEvents();

			// Show initial section
			this.initFromHash();

			// Mark as ready (removes loading state)
			this.form.classList.add('wca-profile-ready');
		},

		/**
		 * Detect and apply WordPress admin color scheme.
		 */
		applyColorScheme: function() {
			var root = document.documentElement;
			var styles = getComputedStyle(root);

			// Prefer native WP admin color variables when available.
			// This keeps --wca-primary aligned with the active admin color scheme.
			var wpPrimary = styles.getPropertyValue('--wp-admin-theme-color').trim();
			var wpPrimaryHover = styles.getPropertyValue('--wp-admin-theme-color-darker-10').trim();

			if (wpPrimary) {
				root.style.setProperty('--wca-primary', wpPrimary);
				root.style.setProperty('--wca-primary-hover', wpPrimaryHover || wpPrimary);
				root.style.setProperty('--wca-primary-light', 'color-mix(in srgb, var(--wca-primary) 10%, #fff)');
				root.style.setProperty('--wca-primary-bg', 'color-mix(in srgb, var(--wca-primary) 8%, #fff)');
				root.style.setProperty('--wca-accent', wpPrimary);
				return;
			}

			// Fallback for environments where WP admin custom properties are unavailable.
			var scheme = this.detectColorScheme();
			var colors = colorSchemes[scheme] || colorSchemes['fresh'];
			root.style.setProperty('--wca-primary', colors.primary);
			root.style.setProperty('--wca-primary-hover', colors.primaryHover);
			root.style.setProperty('--wca-primary-light', colors.primaryLight);
			root.style.setProperty('--wca-primary-bg', colors.primaryBg);
			root.style.setProperty('--wca-accent', colors.primary);
		},

		/**
		 * Detect the current WordPress admin color scheme.
		 */
		detectColorScheme: function() {
			// Method 1: Check body classes
			var bodyClasses = document.body.className;
			var schemeMatch = bodyClasses.match(/admin-color-([a-z]+)/);
			if (schemeMatch && schemeMatch[1]) {
				return schemeMatch[1];
			}

			// Method 2: Check for scheme-specific colors in existing elements
			var adminBar = document.getElementById('wpadminbar');
			if (adminBar) {
				var bgColor = getComputedStyle(adminBar).backgroundColor;
				// Map background colors to schemes (approximate)
				if (bgColor.indexOf('29, 35, 39') > -1 || bgColor === '#1d2327') return 'fresh';
				if (bgColor.indexOf('227, 227, 227') > -1) return 'light';
				if (bgColor.indexOf('29, 36, 42') > -1) return 'modern';
				if (bgColor.indexOf('9, 54, 70') > -1) return 'blue';
				if (bgColor.indexOf('69, 54, 44') > -1) return 'coffee';
				if (bgColor.indexOf('52, 57, 47') > -1) return 'ectoplasm';
				if (bgColor.indexOf('38, 44, 51') > -1) return 'midnight';
				if (bgColor.indexOf('98, 124, 129') > -1) return 'ocean';
				if (bgColor.indexOf('207, 73, 68') > -1) return 'sunrise';
			}

			// Default to fresh
			return 'fresh';
		},

		/**
		 * Build sections array from h2 headings in the form.
		 */
		buildSections: function() {
			var self = this;

			// Section config with icons (use stable keys)
			var sectionConfig = {
				'personal-options': { icon: 'dashicons-admin-settings' },
				'name': { icon: 'dashicons-admin-users' },
				'contact-info': { icon: 'dashicons-email-alt' },
				'about-yourself': { icon: 'dashicons-id-alt' },
				'about-the-user': { icon: 'dashicons-id-alt' },
				'account-management': { icon: 'dashicons-admin-network' },
				'timezone': { icon: 'dashicons-clock' },
				'availability': { icon: 'dashicons-calendar-alt' },
				'google-calendar': { icon: 'dashicons-google' },
				'assigned-products': { icon: 'dashicons-products' }
			};

			// Map localized heading labels to stable keys
			var labelToKey = {};
			if (typeof wcaStaffProfile !== 'undefined' && wcaStaffProfile.sectionLabels) {
				Object.keys(wcaStaffProfile.sectionLabels).forEach(function(key) {
					var label = wcaStaffProfile.sectionLabels[key];
					if (label) {
						labelToKey[label.toLowerCase()] = key;
					}
				});
			}

			// Find all h2 headings in the form
			this.form.querySelectorAll('h2').forEach(function(heading) {
				var headingText = heading.textContent.trim();

				if (!headingText) {
					return;
				}

				var headingKey = heading.dataset.section;
				var headingId = heading.id;
				var normalizedText = headingText.toLowerCase();

				var key = headingKey || labelToKey[normalizedText] || '';
				if (!key && headingId && headingId.indexOf('wca-section-') === 0) {
					key = headingId.replace('wca-section-', '');
				}
				if (!key && headingId && sectionConfig[headingId]) {
					key = headingId;
				}
				if (!key) {
					key = normalizedText.replace(/[^a-z0-9]+/g, '-');
				}

				// Skip application-passwords section for staff users
				if (key === 'application-passwords') {
					return;
				}

				var config = sectionConfig[key] || {};
				var icon = config.icon || 'dashicons-admin-generic';

				// Get all content until next h2
				var contentEls = getElementsUntil(heading, 'h2');

				if (!contentEls.length) {
					return;
				}

				self.sections.push({
					key: key,
					label: headingText,
					icon: icon,
					heading: heading,
					contentEls: contentEls
				});
			});
		},

		/**
		 * Create the sidebar layout wrapper.
		 */
		createLayout: function() {

			// Create wrapper that goes around the form
			var wrapper = createElement('<div class="wca-profile-wrapper"></div>');

			// Create mobile header with toggle
			var mobileHeader = createElement(
				'<div class="wca-mobile-header">' +
					'<button type="button" class="wca-menu-toggle" aria-expanded="false">' +
						'<span class="dashicons dashicons-menu"></span>' +
						'<span class="wca-current-section"></span>' +
						'<span class="dashicons dashicons-arrow-down-alt2"></span>' +
					'</button>' +
				'</div>'
			);

			// Create navigation
			this.nav = createElement('<nav class="wca-profile-nav" role="tablist"></nav>');

			// Add back-to-dashboard link for staff members (not admins)
			if (typeof wcaStaffProfile !== 'undefined' && wcaStaffProfile.dashboardUrl && !wcaStaffProfile.isAdmin) {
				var backLabel = (wcaStaffProfile.i18n && wcaStaffProfile.i18n.backToDashboard) || 'Dashboard';
				this.nav.appendChild(createElement(
					'<a href="' + wcaStaffProfile.dashboardUrl + '" class="wca-profile-back">' +
						'<span class="dashicons dashicons-arrow-left-alt2"></span>' +
						'<span>' + backLabel + '</span>' +
					'</a>'
				));
			}

			var ul = createElement('<ul class="wca-nav-list"></ul>');

			this.sections.forEach(function(section) {
				ul.appendChild(createElement(
					'<li class="wca-nav-item" data-section="' + section.key + '">' +
						'<a href="#wca-section-' + section.key + '" role="tab" aria-selected="false">' +
							'<span class="dashicons ' + section.icon + '"></span>' +
							'<span class="wca-nav-label">' + section.label + '</span>' +
						'</a>' +
					'</li>'
				));
			});

			this.nav.appendChild(ul);

			// Create content wrapper
			this.content = createElement('<div class="wca-profile-content"></div>');

			// Find and preserve submit button before wrapping
			var submitButton = this.form.querySelector('p.submit');

			// Wrap each section's content in a panel div
			this.sections.forEach(function(section) {
				var panel = createElement('<div id="wca-section-' + section.key + '" class="wca-section-panel" role="tabpanel"></div>');

				// Insert panel before heading, then move heading and content into it
				if (section.heading) {
					section.heading.parentNode.insertBefore(panel, section.heading);
					panel.appendChild(section.heading);
				}
				if (section.contentEls && section.contentEls.length) {
					section.contentEls.forEach(function(el) {
						panel.appendChild(el);
					});
				}
			});

			// Insert wrapper before form
			this.form.parentNode.insertBefore(wrapper, this.form);

			// Add mobile header and nav to wrapper
			wrapper.appendChild(mobileHeader);
			wrapper.appendChild(this.nav);
			wrapper.appendChild(this.content);

			// Move form into content area
			this.content.appendChild(this.form);

			// Ensure submit button stays at the bottom and is always visible
			if (submitButton) {
				submitButton.classList.add('wca-submit-button');
				this.form.appendChild(submitButton);
			}
		},

		/**
		 * Bind event handlers.
		 */
		bindEvents: function() {
			var self = this;

			// Nav item clicks (delegated on nav element)
			this.nav.addEventListener('click', function(e) {
				var link = e.target.closest('.wca-nav-item a');
				if (link) {
					e.preventDefault();
					var sectionKey = link.parentElement.dataset.section;
					self.switchSection(sectionKey);
					self.closeMobileMenu();
				}
			});

			// Keyboard navigation (delegated on nav element)
			this.nav.addEventListener('keydown', function(e) {
				var link = e.target.closest('.wca-nav-item a');
				if (!link) {
					return;
				}

				var items = Array.from(self.nav.querySelectorAll('.wca-nav-item a'));
				var index = items.indexOf(link);
				var newIndex = index;

				switch (e.keyCode) {
					case 38: // Up
					case 37: // Left
						newIndex = index > 0 ? index - 1 : items.length - 1;
						break;
					case 40: // Down
					case 39: // Right
						newIndex = index < items.length - 1 ? index + 1 : 0;
						break;
					case 36: // Home
						newIndex = 0;
						break;
					case 35: // End
						newIndex = items.length - 1;
						break;
					default:
						return;
				}

				e.preventDefault();
				items[newIndex].focus();
				items[newIndex].click();
			});

			// Mobile toggle + close on outside click + Escape
			document.addEventListener('click', function(e) {
				if (e.target.closest('.wca-menu-toggle')) {
					e.preventDefault();
					self.toggleMobileMenu();
					return;
				}

				if (self.mobileMenuOpen && !e.target.closest('.wca-profile-nav, .wca-menu-toggle')) {
					self.closeMobileMenu();
				}
			});

			document.addEventListener('keydown', function(e) {
				if (e.keyCode === 27 && self.mobileMenuOpen) {
					self.closeMobileMenu();
				}
			});

			// Hash change
			window.addEventListener('hashchange', function() {
				self.initFromHash();
			});

			// Handle form submission to preserve current section
			this.form.addEventListener('submit', function() {
				// Save current section before form submission
				if (self.activeSection) {
					self.saveCurrentSection(self.activeSection);
				}
			});
		},

		/**
		 * Initialize from URL hash or saved section.
		 */
		initFromHash: function() {
			var hash = window.location.hash.replace('#wca-section-', '');
			var savedSection = this.getSavedSection();
			var targetSection = hash || savedSection;

			var found = this.sections.find(function(s) { return s.key === targetSection; });

			if (found) {
				this.switchSection(targetSection, false);
			} else {
				// Default to first section
				this.switchSection(this.sections[0].key, false);
			}
		},

		/**
		 * Get the saved section from localStorage.
		 */
		getSavedSection: function() {
			try {
				return localStorage.getItem('wca_staff_active_section');
			} catch (e) {
				return null;
			}
		},

		/**
		 * Save the current section to localStorage.
		 */
		saveCurrentSection: function(sectionKey) {
			try {
				localStorage.setItem('wca_staff_active_section', sectionKey);
			} catch (e) {
				// Ignore localStorage errors
			}
		},

		/**
		 * Switch to a section.
		 */
		switchSection: function(sectionKey, updateHash) {
			if (typeof updateHash === 'undefined') {
				updateHash = true;
			}

			var section = this.sections.find(function(s) { return s.key === sectionKey; });
			if (!section) {
				return;
			}

			this.activeSection = sectionKey;

			// Save current section to localStorage
			this.saveCurrentSection(sectionKey);

			// Update nav
			this.nav.querySelectorAll('.wca-nav-item').forEach(function(item) {
				item.classList.remove('wca-active');
			});
			var activeItem = this.nav.querySelector('[data-section="' + sectionKey + '"]');
			if (activeItem) {
				activeItem.classList.add('wca-active');
			}

			// Update ARIA
			this.nav.querySelectorAll('.wca-nav-item a').forEach(function(a) {
				a.setAttribute('aria-selected', 'false');
			});
			var activeLink = this.nav.querySelector('[data-section="' + sectionKey + '"] a');
			if (activeLink) {
				activeLink.setAttribute('aria-selected', 'true');
			}

			// Update panels
			this.content.querySelectorAll('.wca-section-panel').forEach(function(panel) {
				panel.classList.remove('wca-active');
			});
			var activePanel = this.content.querySelector('#wca-section-' + sectionKey);
			if (activePanel) {
				activePanel.classList.add('wca-active');
			}

			// Update mobile header
			var currentSectionLabel = document.querySelector('.wca-current-section');
			if (currentSectionLabel) {
				currentSectionLabel.textContent = section.label;
			}

			// Update hash
			if (updateHash && history.pushState) {
				history.pushState(null, null, '#wca-section-' + sectionKey);
			}

			// Trigger event
			document.dispatchEvent(new CustomEvent('wca_section_changed', { detail: sectionKey }));
		},

		/**
		 * Toggle mobile menu.
		 */
		toggleMobileMenu: function() {
			if (this.mobileMenuOpen) {
				this.closeMobileMenu();
			} else {
				this.openMobileMenu();
			}
		},

		/**
		 * Open mobile menu.
		 */
		openMobileMenu: function() {
			this.mobileMenuOpen = true;
			this.nav.classList.add('wca-nav-open');
			var toggle = document.querySelector('.wca-menu-toggle');
			if (toggle) {
				toggle.setAttribute('aria-expanded', 'true');
			}
			document.body.classList.add('wca-menu-open');
		},

		/**
		 * Close mobile menu.
		 */
		closeMobileMenu: function() {
			this.mobileMenuOpen = false;
			this.nav.classList.remove('wca-nav-open');
			var toggle = document.querySelector('.wca-menu-toggle');
			if (toggle) {
				toggle.setAttribute('aria-expanded', 'false');
			}
			document.body.classList.remove('wca-menu-open');
		},

		/**
		 * Live effective price calculation for staff cost inputs.
		 */
		initProductsCostCalc: function() {
			var table = document.querySelector('.wca-staff-products-table');
			if ( ! table ) {
				return;
			}

			var currency = ( typeof wcaStaffProfile !== 'undefined' && wcaStaffProfile.currency ) ? wcaStaffProfile.currency : {};
			var symbol   = currency.symbol || '$';
			var position = currency.position || 'left';
			var decimals = typeof currency.decimals !== 'undefined' ? parseInt( currency.decimals, 10 ) : 2;
			var decSep   = currency.decSep || '.';
			var thousSep = currency.thousSep || ',';

			function formatPrice( amount ) {
				var negative = amount < 0;
				var abs      = Math.abs( amount ).toFixed( decimals );
				var parts    = abs.split( '.' );
				var intPart  = parts[0].replace( /\B(?=(\d{3})+(?!\d))/g, thousSep );
				var formatted = decimals > 0 ? intPart + decSep + parts[1] : intPart;

				var html = '';
				if ( negative ) {
					html += '-';
				}
				switch ( position ) {
					case 'left':
						html += '<span class="woocommerce-Price-currencySymbol">' + symbol + '</span>' + formatted;
						break;
					case 'left_space':
						html += '<span class="woocommerce-Price-currencySymbol">' + symbol + '</span>&nbsp;' + formatted;
						break;
					case 'right':
						html += formatted + '<span class="woocommerce-Price-currencySymbol">' + symbol + '</span>';
						break;
					case 'right_space':
						html += formatted + '&nbsp;<span class="woocommerce-Price-currencySymbol">' + symbol + '</span>';
						break;
					default:
						html += '<span class="woocommerce-Price-currencySymbol">' + symbol + '</span>' + formatted;
				}
				return '<span class="woocommerce-Price-amount amount">' + html + '</span>';
			}

			function updateRow( input ) {
				var basePrice     = parseFloat( input.getAttribute( 'data-base-price' ) ) || 0;
				var staffCost     = input.value !== '' ? parseFloat( input.value ) : NaN;
				var wrapper       = input.closest( 'td' ).querySelector( '.wca-effective-price' );
				var amountEl      = wrapper ? wrapper.querySelector( '.wca-effective-amount' ) : null;

				if ( ! wrapper || ! amountEl ) {
					return;
				}

				if ( isNaN( staffCost ) || staffCost === 0 ) {
					wrapper.style.display = 'none';
					return;
				}

				var effective = basePrice + staffCost;
				amountEl.innerHTML = formatPrice( effective );
				amountEl.className = 'wca-effective-amount' + ( staffCost < 0 ? ' wca-discount' : '' );
				wrapper.style.display = '';
			}

			// Bind events
			table.querySelectorAll( '.wca-price-input[data-base-price]' ).forEach( function( input ) {
				input.addEventListener( 'input', function() {
					updateRow( input );
				});
			});
		}
	};

	// Initialize when ready
	document.addEventListener('DOMContentLoaded', function() {
		var isAdminEdit = (typeof wcaStaffProfile !== 'undefined' && wcaStaffProfile.isAdminEdit);

		if (isAdminEdit) {
			// Admin viewing staff profile: only init functionality, no sidebar navigation.
			StaffProfile.applyColorScheme();
			StaffProfile.initProductsCostCalc();
		} else {
			// Staff viewing own profile: full sidebar layout.
			StaffProfile.init();
			StaffProfile.initProductsCostCalc();
		}
	});

	// Expose globally
	window.WCAStaffProfile = StaffProfile;

})();
