/**
 * WooCommerce Appointments - Timezone Utilities
 * 
 * Centralized timezone conversion utilities for admin calendar and modal.
 * Handles timezone conversions between admin timezone and site timezone.
 * 
 * @package WooCommerce Appointments
 */

(function (window) {
	'use strict';

	/**
	 * Get timezone configuration from global parameters
	 * @returns {Object} Object with adminTz, siteTz, and hasDifferentTz properties
	 */
	function getTimezoneConfig() {
		// Prioritize newer config objects with named timezones.
		var calendar = window.wcAppointmentsReactCalendar || {};
		var panel = window.wcaPanel || {};
		var writepanel = window.wc_appointments_writepanel_js_params || {};

		// The new calendar uses siteTimezone/adminTimezone keys.
		var adminTz = calendar.adminTimezone || panel.adminTimezone || writepanel.admin_timezone || '';
		var siteTz = calendar.siteTimezone || panel.siteTimezone || writepanel.site_timezone || '';

		// Safety fallback for site timezone - if it is 'UTC', try to find a better one
		// from other configuration sources if available.
		if ( ( ! siteTz || siteTz === 'UTC' ) && writepanel.site_timezone && writepanel.site_timezone !== 'UTC' ) {
			siteTz = writepanel.site_timezone;
		}

		return {
			adminTz: adminTz,
			siteTz: siteTz,
			hasDifferentTz: !!(adminTz && siteTz && adminTz !== siteTz)
		};
	}

	function getTimezoneOffset(referenceDate) {
		var config = getTimezoneConfig();
		if (!config.hasDifferentTz) {
			return 0;
		}

		var date = referenceDate || new Date();
		
		try {
			var fmt = { 
				year: 'numeric', month: '2-digit', day: '2-digit',
				hour: '2-digit', minute: '2-digit', second: '2-digit',
				hour12: false 
			};
			
			// Use Intl.DateTimeFormat for better stability across environments
			var adminDTF = new Intl.DateTimeFormat('en-US', Object.assign({}, fmt, { timeZone: config.adminTz }));
			var siteDTF = new Intl.DateTimeFormat('en-US', Object.assign({}, fmt, { timeZone: config.siteTz }));
			
			var adminParts = adminDTF.formatToParts(date);
			var siteParts = siteDTF.formatToParts(date);
			
			var p = {};
			adminParts.forEach(function(part) { if (part.type !== 'literal') p['a' + part.type] = part.value; });
			siteParts.forEach(function(part) { if (part.type !== 'literal') p['s' + part.type] = part.value; });
			
			var adminDate = new Date(Date.UTC(p.ayear, p.amonth - 1, p.aday, p.ahour, p.aminute, p.asecond));
			var siteDate = new Date(Date.UTC(p.syear, p.smonth - 1, p.sday, p.shour, p.sminute, p.ssecond));
			
			return Math.round((siteDate.getTime() - adminDate.getTime()) / (1000 * 60));
		} catch (error) {
			console.warn('Timezone offset calculation failed:', error);
			// Fallback to static offsets if available in calendar config
			var calendar = window.wcAppointmentsReactCalendar || {};
			if ( calendar.adminTimezoneOffset !== undefined && calendar.siteTimezoneOffset !== undefined ) {
				return calendar.siteTimezoneOffset - calendar.adminTimezoneOffset;
			}
		}
		
		return 0;
	}

	/**
	 * Convert timestamp from site timezone to admin timezone
	 * Used for displaying times in the admin's timezone
	 * 
	 * @param {number} ts - UTC timestamp representing site timezone time
	 * @returns {number} Adjusted timestamp for admin timezone display
	 */
	function convertSiteToAdminTimezone(ts) {
		if (!ts) {
			return ts;
		}

		var config = getTimezoneConfig();
		if (!config.hasDifferentTz) {
			return ts;
		}

		var calendarConfig = window.wcAppointmentsReactCalendar || {};
		var adminOffsetMinutes = calendarConfig.adminTimezoneOffset || 0;
		var siteOffsetMinutes = calendarConfig.siteTimezoneOffset || 0;
		var offsetDiffMinutes = adminOffsetMinutes - siteOffsetMinutes;

		return ts + (offsetDiffMinutes * 60);
	}

	/**
	 * Convert Date object (admin timezone) to UTC timestamp (site timezone)
	 * Used for calendar drag & drop operations
	 * 
	 * @param {Date} date - Date object representing admin timezone time
	 * @returns {number} UTC timestamp representing site timezone time
	 */
	function convertAdminDateToSiteTimestamp(date) {
		if (!date || !(date instanceof Date)) {
			return 0;
		}

		var config = getTimezoneConfig();

		if (config.hasDifferentTz) {
			try {
				// The Date object's local components represent admin timezone wall-clock time.
				// Use convertAdminStringsToSiteTimezone to get site timezone wall-clock time.
				var dateStr = date.getFullYear() + '-' +
					('0' + (date.getMonth() + 1)).slice(-2) + '-' +
					('0' + date.getDate()).slice(-2);
				var timeStr = ('0' + date.getHours()).slice(-2) + ':' +
					('0' + date.getMinutes()).slice(-2);

				var converted = convertAdminStringsToSiteTimezone(dateStr, timeStr);
				var cParts = converted.date.split('-');
				var cTime = converted.time.split(':');

				// Return as UTC timestamp representing site timezone wall-clock time
				return Math.floor(Date.UTC(
					parseInt(cParts[0], 10),
					parseInt(cParts[1], 10) - 1,
					parseInt(cParts[2], 10),
					parseInt(cTime[0], 10),
					parseInt(cTime[1], 10),
					date.getSeconds()
				) / 1000);
			} catch (e) {
				console.warn('convertAdminDateToSiteTimestamp failed:', e);
				// Fallback to no-conversion path
			}
		}

		return Math.floor(Date.UTC(
			date.getFullYear(),
			date.getMonth(),
			date.getDate(),
			date.getHours(),
			date.getMinutes(),
			date.getSeconds()
		) / 1000);
	}

	/**
	 * Convert site timezone date/time strings to admin timezone
	 * Reverse of convertAdminStringsToSiteTimezone.
	 * Used when slot times (site TZ) need to be shown in admin TZ form fields.
	 *
	 * @param {string} dateStr - Date string in YYYY-MM-DD format (site timezone)
	 * @param {string} timeStr - Time string in HH:MM format (site timezone)
	 * @returns {Object} Object with date and time strings in admin timezone
	 */
	function convertSiteStringsToAdminTimezone(dateStr, timeStr) {
		var config = getTimezoneConfig();

		dateStr = ( dateStr != null && dateStr !== '' ) ? String( dateStr ) : '';
		timeStr = ( timeStr != null && timeStr !== '' ) ? String( timeStr ) : '';

		if (!config.hasDifferentTz) {
			return { date: dateStr, time: timeStr };
		}

		if (!dateStr || !timeStr) {
			return { date: dateStr, time: timeStr };
		}

		var dateParts = dateStr.split('-');
		var timeParts = timeStr.split(':');
		if (dateParts.length !== 3 || timeParts.length !== 2) {
			return { date: dateStr, time: timeStr };
		}

		var year = parseInt(dateParts[0], 10);
		var month = parseInt(dateParts[1], 10);
		var day = parseInt(dateParts[2], 10);
		var hour = parseInt(timeParts[0], 10);
		var minute = parseInt(timeParts[1], 10);

		try {
			// Rule: "Site's timezone as UTC is correct".
			// 1. Interpret site wall-clock numbers as UTC wall-clock numbers (naive timestamp).
			var siteTs = Date.UTC(year, month - 1, day, hour, minute, 0);

			// 2. Calculate the offset difference (Site - Admin) in minutes at this time.
			// getTimezoneOffset returns (SiteOffset - AdminOffset) in minutes.
			var diffMinutes = getTimezoneOffset(new Date(siteTs));

			// 3. Apply the shift: AdminTime = SiteTime - diffMinutes.
			var adminTs = siteTs - (diffMinutes * 60 * 1000);

			// 4. Return the wall-clock components of the adjusted naive timestamp.
			var d = new Date(adminTs);
			return {
				date: d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()),
				time: pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes())
			};
		} catch (e) {
			console.warn('convertSiteStringsToAdminTimezone failed:', e);
			return { date: dateStr, time: timeStr };
		}
	}

	/**
	 * Convert admin timezone date/time strings to site timezone
	 * Used when submitting form data to server
	 *
	 * @param {string} dateStr - Date string in YYYY-MM-DD format (admin timezone)
	 * @param {string} timeStr - Time string in HH:MM format (admin timezone)
	 * @returns {Object} Object with date and time strings in site timezone
	 */
	function convertAdminStringsToSiteTimezone(dateStr, timeStr) {
		var config = getTimezoneConfig();

		dateStr = ( dateStr != null && dateStr !== '' ) ? String( dateStr ) : '';
		timeStr = ( timeStr != null && timeStr !== '' ) ? String( timeStr ) : '';

		if (!config.hasDifferentTz) {
			return { date: dateStr, time: timeStr };
		}

		if (!dateStr || !timeStr) {
			return { date: dateStr, time: timeStr };
		}

		var dateParts = dateStr.split('-');
		var timeParts = timeStr.split(':');
		if (dateParts.length !== 3 || timeParts.length !== 2) {
			return { date: dateStr, time: timeStr };
		}

		var year = parseInt(dateParts[0], 10);
		var month = parseInt(dateParts[1], 10);
		var day = parseInt(dateParts[2], 10);
		var hour = parseInt(timeParts[0], 10);
		var minute = parseInt(timeParts[1], 10);

		try {
			// Rule: "Site's timezone as UTC is correct".
			// 1. Interpret admin wall-clock numbers as UTC wall-clock numbers (naive timestamp).
			var adminTs = Date.UTC(year, month - 1, day, hour, minute, 0);

			// 2. Calculate the offset difference (Site - Admin) in minutes at this time.
			var diffMinutes = getTimezoneOffset(new Date(adminTs));

			// 3. Apply the shift: SiteTime = AdminTime + diffMinutes.
			var siteTs = adminTs + (diffMinutes * 60 * 1000);

			// 4. Return the wall-clock components of the adjusted naive timestamp.
			var d = new Date(siteTs);
			return {
				date: d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()),
				time: pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes())
			};
		} catch (e) {
			console.warn('convertAdminStringsToSiteTimezone failed:', e);
			return { date: dateStr, time: timeStr };
		}
	}

	/**
	 * Extract date/time components from timestamp for display
	 * Handles timezone conversion when admin timezone differs from site
	 * 
	 * @param {number} ts - UTC timestamp representing site timezone time
	 * @param {boolean} forDisplay - If true, convert to admin timezone for display
	 * @returns {Object} Object with year, month, day, hour, minute as strings
	 */
	function extractDateTimeParts(ts, forDisplay) {
		var config = getTimezoneConfig();
		var date = new Date(parseInt(ts, 10) * 1000);

		if (forDisplay && config.hasDifferentTz) {
			var siteParts = extractSiteTimezoneParts(ts);
			var siteDate = new Date(
				parseInt(siteParts.year, 10),
				parseInt(siteParts.month, 10) - 1,
				parseInt(siteParts.day, 10),
				parseInt(siteParts.hour, 10),
				parseInt(siteParts.minute, 10)
			);

			var adminFormatted = siteDate.toLocaleString(undefined, {
				year: 'numeric',
				month: '2-digit',
				day: '2-digit',
				hour: '2-digit',
				minute: '2-digit',
				hour12: false,
				timeZone: config.adminTz
			});

			var parts = adminFormatted.match(/(\d{2})[\/.](\d{2})[\/.](\d{4}),\s+(\d{2}):(\d{2})/);
			if (parts) {
				return {
					year: parts[3],
					month: parts[1],
					day: parts[2],
					hour: parts[4],
					minute: parts[5]
				};
			}

			var altParts = adminFormatted.match(/(\d{4})[\/.](\d{2})[\/.](\d{2}),\s+(\d{2}):(\d{2})/);
			if (altParts) {
				return {
					year: altParts[1],
					month: altParts[2],
					day: altParts[3],
					hour: altParts[4],
					minute: altParts[5]
				};
			}

			return extractSiteTimezoneParts(ts);
		} else {
			return {
				year: '' + date.getFullYear(),
				month: ('0' + (date.getMonth() + 1)).slice(-2),
				day: ('0' + date.getDate()).slice(-2),
				hour: ('0' + date.getHours()).slice(-2),
				minute: ('0' + date.getMinutes()).slice(-2)
			};
		}
	}

	/**
	 * Extract site timezone components from timestamp
	 * @param {number} ts - UTC timestamp representing site timezone time
	 * @returns {Object} Object with year, month, day, hour, minute as strings
	 */
	function extractSiteTimezoneParts(ts) {
		var date = new Date(parseInt(ts, 10) * 1000);
		var offsetMs = date.getTimezoneOffset() * 60000;
		var adjustedDate = new Date(date.getTime() + offsetMs);

		return {
			year: '' + adjustedDate.getFullYear(),
			month: ('0' + (adjustedDate.getMonth() + 1)).slice(-2),
			day: ('0' + adjustedDate.getDate()).slice(-2),
			hour: ('0' + adjustedDate.getHours()).slice(-2),
			minute: ('0' + adjustedDate.getMinutes()).slice(-2)
		};
	}

	/**
	 * Format timestamp for toast notifications with timezone conversion
	 * @param {number} ts - UTC timestamp representing site timezone time
	 * @param {string} dateFormat - Date format pattern
	 * @param {string} timeFormat - Time format pattern
	 * @param {Function} formatDateByPattern - Date formatting function
	 * @param {Function} formatTimeByPattern - Time formatting function
	 * @returns {string} Formatted date/time string
	 */
	function formatToastDateTime(ts, dateFormat, timeFormat, formatDateByPattern, formatTimeByPattern) {
		if (!ts) {
			return '';
		}

		var config = getTimezoneConfig();

		if (config.hasDifferentTz) {
			// Convert timestamp from site timezone to admin timezone for display
			var adjustedTs = convertSiteToAdminTimezone(ts);
			var adminDate = new Date(adjustedTs * 1000);
			
			return formatDateByPattern(adminDate, dateFormat) + ', ' + formatTimeByPattern(adminDate, timeFormat);
		}

		// When timezones are the same, use the timestamp directly
		var date = new Date(ts * 1000);
		return formatDateByPattern(date, dateFormat) + ', ' + formatTimeByPattern(date, timeFormat);
	}

	/**
	 * Pad number with leading zero
	 * @param {number} n - Number to pad
	 * @returns {string} Padded string
	 */
	function pad(n) {
		return (n < 10 ? '0' : '') + n;
	}

	/**
	 * Convert timestamp to ISO string using UTC methods
	 * @param {number} ts - Unix timestamp
	 * @returns {string} ISO string
	 */
	function tsToNaiveLocalISO(ts) {
		if (!ts) { return ''; }
		var d = new Date((ts || 0) * 1000);
		var y = d.getUTCFullYear();
		var m = pad(d.getUTCMonth() + 1);
		var day = pad(d.getUTCDate());
		var hh = pad(d.getUTCHours());
		var mm = pad(d.getUTCMinutes());
		var ss = pad(d.getUTCSeconds());
		return y + '-' + m + '-' + day + 'T' + hh + ':' + mm + ':' + ss;
	}

	/**
	 * Convert timestamp to ISO string, adjusted for admin timezone display
	 * @param {number} ts - Unix timestamp
	 * @returns {string} ISO string in admin timezone
	 */
	function tsToAdminLocalISO(ts) {
		if (!ts) { return ''; }
		var config = getTimezoneConfig();
		if (!config.hasDifferentTz) {
			return tsToNaiveLocalISO(ts);
		}
		// Extract site-local time from semantic timestamp (UTC components = site-local)
		var d = new Date(parseInt(ts, 10) * 1000);
		var dateStr = d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate());
		var timeStr = pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes());
		var secs = pad(d.getUTCSeconds());
		// Use IANA-based DST-aware conversion (not static offsets)
		var converted = convertSiteStringsToAdminTimezone(dateStr, timeStr);
		return converted.date + 'T' + converted.time + ':' + secs;
	}

	/**
	 * Convert timestamp to date string (Y-m-d) using UTC methods
	 * @param {number} ts - Unix timestamp
	 * @returns {string} Date string
	 */
	function tsToNaiveLocalDate(ts) {
		if (!ts) { return ''; }
		var d = new Date((ts || 0) * 1000);
		var y = d.getUTCFullYear();
		var m = pad(d.getUTCMonth() + 1);
		var day = pad(d.getUTCDate());
		return y + '-' + m + '-' + day;
	}

	/**
	 * Convert timestamp to date string (Y-m-d), adjusted for admin timezone
	 * @param {number} ts - Unix timestamp
	 * @returns {string} Date string in admin timezone
	 */
	function tsToAdminLocalDate(ts) {
		if (!ts) { return ''; }
		var config = getTimezoneConfig();
		if (!config.hasDifferentTz) {
			return tsToNaiveLocalDate(ts);
		}
		// Extract site-local time from semantic timestamp (UTC components = site-local)
		var d = new Date(parseInt(ts, 10) * 1000);
		var dateStr = d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate());
		var timeStr = pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes());
		// Use IANA-based DST-aware conversion (not static offsets)
		var converted = convertSiteStringsToAdminTimezone(dateStr, timeStr);
		return converted.date;
	}

	/**
	 * Convert Date object to Y-m-d string
	 * @param {Date} date - Date object
	 * @returns {string} Date string
	 */
	function dateToYmd(date) {
		if (!date || !(date instanceof Date)) { return ''; }
		return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
	}

	/**
	 * Extract date/time components using local methods (for input fields)
	 * @param {number|string} ts - Unix timestamp
	 * @returns {Object} Object with year, month, day, hour, minute as strings
	 */
	function formatPartsLocal(ts) {
		var d = new Date(parseInt(ts, 10) * 1000);
		var localHour = d.getHours();
		var localMinute = d.getMinutes();

		return {
			year: '' + d.getFullYear(),
			month: ('0' + (d.getMonth() + 1)).slice(-2),
			day: ('0' + d.getDate()).slice(-2),
			hour: ('0' + localHour).slice(-2),
			minute: ('0' + localMinute).slice(-2)
		};
	}

	/**
	 * Format timestamp as date string (YYYY-MM-DD) for input fields
	 * @param {number} ts - Unix timestamp
	 * @returns {string} Date string
	 */
	function formatInputDate(ts) {
		var p = formatPartsLocal(ts);
		return p.year + '-' + p.month + '-' + p.day;
	}

	/**
	 * Format timestamp as time string (HH:MM) for input fields
	 * @param {number} ts - Unix timestamp
	 * @returns {string} Time string
	 */
	function formatInputTime(ts) {
		var p = formatPartsLocal(ts);
		return p.hour + ':' + p.minute;
	}

	/**
	 * Format timestamp as month string (YYYY-MM) for input fields
	 * @param {number} ts - Unix timestamp
	 * @returns {string} Month string
	 */
	function formatInputMonth(ts) {
		var p = formatPartsLocal(ts);
		return p.year + '-' + p.month;
	}

	/**
	 * Get timezone-aware current time for FullCalendar now indicator
	 * Returns a Date object that represents the current time in the admin's timezone
	 * 
	 * @returns {Date} Date object representing current time in admin timezone
	 */
	function getTimezoneAwareNow() {
		var config = getTimezoneConfig();
		
		if (!config.hasDifferentTz) {
			// If timezones are the same, return current time
			return new Date();
		}
		
		try {
			// Get current time in site timezone
			var now = new Date();
			
			// Format current time in site timezone
			var siteFormatted = now.toLocaleString('en-US', { 
				timeZone: config.siteTz, 
				year: 'numeric', 
				month: '2-digit', 
				day: '2-digit',
				hour: '2-digit', 
				minute: '2-digit', 
				second: '2-digit',
				hour12: false 
			});
			
			// Parse the formatted string to get components
			var siteParts = siteFormatted.match(/(\d+)\/(\d+)\/(\d+), (\d+):(\d+):(\d+)/);
			if (siteParts) {
				// Create a Date object using the site timezone components
				// This Date will be interpreted as local time by FullCalendar
				var siteDate = new Date(
					parseInt(siteParts[3], 10), // year
					parseInt(siteParts[1], 10) - 1, // month (0-based)
					parseInt(siteParts[2], 10), // day
					parseInt(siteParts[4], 10), // hour
					parseInt(siteParts[5], 10), // minute
					parseInt(siteParts[6], 10) // second
				);
				
				// Format this Date in admin timezone to get the display time
				var adminFormatted = siteDate.toLocaleString('en-US', {
					timeZone: config.adminTz,
					year: 'numeric',
					month: '2-digit',
					day: '2-digit',
					hour: '2-digit',
					minute: '2-digit',
					second: '2-digit',
					hour12: false
				});
				
				// Parse admin timezone representation
				var adminParts = adminFormatted.match(/(\d+)\/(\d+)\/(\d+), (\d+):(\d+):(\d+)/);
				if (adminParts) {
					// Return a Date object that represents the admin's current time
					// This will be used by FullCalendar's now indicator
					return new Date(
						parseInt(adminParts[3], 10), // year
						parseInt(adminParts[1], 10) - 1, // month (0-based)
						parseInt(adminParts[2], 10), // day
						parseInt(adminParts[4], 10), // hour
						parseInt(adminParts[5], 10), // minute
						parseInt(adminParts[6], 10) // second
					);
				}
			}
		} catch (e) {
			console.warn('getTimezoneAwareNow failed:', e);
		}
		
		// Fallback to current time
		return new Date();
	}

	/**
	 * Parse H:i (or H:i:s) into hour/minute ints.
	 *
	 * @param {string} hm
	 * @returns {{h:number,m:number}}
	 */
	function parseAvailabilityRuleHm( hm ) {
		var p = String( hm || '00:00' ).split( ':' );
		return { h: parseInt( p[ 0 ], 10 ) || 0, m: parseInt( p[ 1 ], 10 ) || 0 };
	}

	/**
	 * Whether a rule time span is civil / full-day (00:00–23:59 or 00:00–24:00).
	 * Used by admin calendar unavailable stripes (same idea as all-day appointments).
	 *
	 * @param {string} hStart
	 * @param {string} hEnd
	 * @returns {boolean}
	 */
	function isCivilDayAvailabilitySpan( hStart, hEnd ) {
		var hs = parseAvailabilityRuleHm( hStart || '00:00' );
		var he = parseAvailabilityRuleHm( hEnd || '23:59' );
		return ( 0 === hs.h && 0 === hs.m ) && ( ( 23 === he.h && 59 === he.m ) || ( 24 === he.h && 0 === he.m ) );
	}

	/**
	 * Whether admin calendar should reproject a rule instant into the admin timezone.
	 * Civil / full-day spans never shift (month grid never shifts). Timed spans shift
	 * only when the admin timezone differs from the site timezone.
	 *
	 * @param {Object}  opts
	 * @param {boolean} opts.isMonthView
	 * @param {boolean} [opts.hasDifferentTz] When omitted, reads live config.
	 * @param {string}  opts.hStart
	 * @param {string}  opts.hEnd
	 * @returns {boolean}
	 */
	function shouldShiftAvailabilityRuleTimezone( opts ) {
		opts = opts || {};
		if ( opts.isMonthView ) {
			return false;
		}
		var hasDifferentTz = ( 'boolean' === typeof opts.hasDifferentTz )
			? opts.hasDifferentTz
			: getTimezoneConfig().hasDifferentTz;
		if ( !hasDifferentTz ) {
			return false;
		}
		return !isCivilDayAvailabilitySpan( opts.hStart, opts.hEnd );
	}

	/**
	 * Build a local wall-clock timestamp for a rule Y-m-d + H:i, optionally shifting
	 * into the admin timezone for timed (non-civil) spans on week/day grids.
	 *
	 * @param {string}   ymd
	 * @param {string}   hm
	 * @param {boolean}  shiftTz
	 * @returns {number} Unix seconds
	 */
	function availabilityRuleYmdHmToTs( ymd, hm, shiftTz ) {
		var parts = String( ymd || '' ).split( '-' );
		var y = parseInt( parts[ 0 ], 10 ) || 0;
		var m = parseInt( parts[ 1 ], 10 ) || 0;
		var d = parseInt( parts[ 2 ], 10 ) || 0;
		var t = parseAvailabilityRuleHm( hm );
		var ts = Math.floor( new Date( y, m - 1, d, t.h, t.m, 0 ).getTime() / 1000 );
		return shiftTz ? convertSiteToAdminTimezone( ts ) : ts;
	}

	window.WCAppointmentsTimezoneUtils = {
		getTimezoneConfig: getTimezoneConfig,
		getTimezoneOffset: getTimezoneOffset,
		convertSiteToAdminTimezone: convertSiteToAdminTimezone,
		convertAdminDateToSiteTimestamp: convertAdminDateToSiteTimestamp,
		convertAdminStringsToSiteTimezone: convertAdminStringsToSiteTimezone,
		convertSiteStringsToAdminTimezone: convertSiteStringsToAdminTimezone,
		extractDateTimeParts: extractDateTimeParts,
		extractSiteTimezoneParts: extractSiteTimezoneParts,
		formatToastDateTime: formatToastDateTime,
		tsToNaiveLocalISO: tsToNaiveLocalISO,
		tsToAdminLocalISO: tsToAdminLocalISO,
		tsToNaiveLocalDate: tsToNaiveLocalDate,
		tsToAdminLocalDate: tsToAdminLocalDate,
		dateToYmd: dateToYmd,
		formatPartsLocal: formatPartsLocal,
		formatInputDate: formatInputDate,
		formatInputTime: formatInputTime,
		formatInputMonth: formatInputMonth,
		pad: pad,
		getTimezoneAwareNow: getTimezoneAwareNow,
		parseAvailabilityRuleHm: parseAvailabilityRuleHm,
		isCivilDayAvailabilitySpan: isCivilDayAvailabilitySpan,
		shouldShiftAvailabilityRuleTimezone: shouldShiftAvailabilityRuleTimezone,
		availabilityRuleYmdHmToTs: availabilityRuleYmdHmToTs
	};

})(window);
