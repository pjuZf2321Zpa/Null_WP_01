/**
 * Appointment Slot Renderer — pure UI renderer for pre-computed slot data.
 *
 * Consumes the hierarchical JSON response from WC_Appointment_Slots_Provider
 * and renders day/slot UI without any client-side rule processing.
 *
 * The existing date-picker.js remains untouched — this module is additive.
 * When the new AJAX endpoint is enabled, this renderer replaces the
 * rule-processing portions of date-picker.js.
 *
 * Usage:
 *   wcaSlotRenderer.init({ productId, formEl, ... });
 *   wcaSlotRenderer.loadMonth( '2025-03' );
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

/* globals jQuery, wc_appointment_form_params */

var wcaSlotRenderer = ( function( $ ) {
	'use strict';

	// ─── State ──────────────────────────────────────────────────────────
	var state = {
		productId:    0,
		staffId:      0,
		level:        'days',    // summary | days | slots | full
		formEl:       null,
		datepickerEl: null,
		timeSlotsEl:  null,
		cache:        {},        // Keyed by "YYYY-MM_staffId"
		activeMonth:  null,      // 'YYYY-MM'
		activeDate:   null,      // 'YYYY-MM-DD'
		loading:      false,
		ajaxAction:   'wc_appointments_get_slot_data',
		enabled:      false,     // Feature flag — set to true to activate
	};

	// ─── Public API ─────────────────────────────────────────────────────

	/**
	 * Initialize the renderer.
	 *
	 * @param {Object} opts Configuration.
	 * @param {number} opts.productId  Product ID.
	 * @param {jQuery} opts.formEl     Form container element.
	 * @param {number} [opts.staffId]  Staff ID (0 = no preference).
	 * @param {string} [opts.level]    Response level.
	 */
	function init( opts ) {
		if ( ! opts || ! opts.productId || ! opts.formEl ) {
			return;
		}

		state.productId    = opts.productId;
		state.formEl       = opts.formEl;
		state.staffId      = opts.staffId || 0;
		state.level        = opts.level || 'days';
		state.datepickerEl = opts.formEl.find( '.picker' );
		state.timeSlotsEl  = opts.formEl.find( '#appointment_time_slots, .appointment_time_slots' );
		state.enabled      = true;

		bindEvents();
	}

	/**
	 * Load slot data for a month.
	 *
	 * @param {string} monthStr 'YYYY-MM'
	 * @param {number} [staffId] Override staff ID.
	 */
	function loadMonth( monthStr, staffId ) {
		if ( ! state.enabled ) {
			return;
		}

		staffId = ( typeof staffId !== 'undefined' ) ? staffId : state.staffId;
		var cacheKey = monthStr + '_' + staffId;

		state.activeMonth = monthStr;

		// Cache hit.
		if ( ! ( typeof wc_appointment_form_params !== 'undefined' && wc_appointment_form_params.disable_slots_cache ) && state.cache[ cacheKey ] ) {
			applyMonthData( state.cache[ cacheKey ] );
			return;
		}

		// Compute date range: full month.
		var startDate = monthStr + '-01';
		var endDate   = getLastDayOfMonth( monthStr );

		fetchSlots( startDate, endDate, staffId, function( data ) {
			if ( ! ( typeof wc_appointment_form_params !== 'undefined' && wc_appointment_form_params.disable_slots_cache ) ) {
				state.cache[ cacheKey ] = data;
			}
			applyMonthData( data );
		} );
	}

	/**
	 * Load slot data for a specific day (level: slots or full).
	 *
	 * @param {string} dateStr 'YYYY-MM-DD'
	 * @param {number} [staffId] Override staff ID.
	 */
	function loadDay( dateStr, staffId ) {
		if ( ! state.enabled ) {
			return;
		}

		staffId = ( typeof staffId !== 'undefined' ) ? staffId : state.staffId;
		state.activeDate = dateStr;

		var cacheKey = dateStr + '_slots_' + staffId;

		if ( ! ( typeof wc_appointment_form_params !== 'undefined' && wc_appointment_form_params.disable_slots_cache ) && state.cache[ cacheKey ] ) {
			renderTimeSlots( state.cache[ cacheKey ], dateStr );
			return;
		}

		fetchSlots( dateStr, dateStr, staffId, function( data ) {
			if ( ! ( typeof wc_appointment_form_params !== 'undefined' && wc_appointment_form_params.disable_slots_cache ) ) {
				state.cache[ cacheKey ] = data;
			}
			renderTimeSlots( data, dateStr );
		}, 'slots' );
	}

	/**
	 * Update staff selection and reload current view.
	 *
	 * @param {number} staffId New staff ID.
	 */
	function setStaff( staffId ) {
		state.staffId = staffId;

		if ( state.activeMonth ) {
			loadMonth( state.activeMonth, staffId );
		}
	}

	/**
	 * Clear all cached data.
	 */
	function clearCache() {
		state.cache = {};
	}

	/**
	 * Check if the renderer is enabled.
	 *
	 * @return {boolean}
	 */
	function isEnabled() {
		return state.enabled;
	}

	// ─── Private ────────────────────────────────────────────────────────

	/**
	 * Bind DOM events.
	 */
	function bindEvents() {
		// Staff change.
		state.formEl.on( 'change', '#wc_appointments_field_staff', function() {
			var newStaffId = parseInt( $( this ).val(), 10 ) || 0;
			setStaff( newStaffId );
		} );

		state.formEl.on( 'change', '#wc_appointments_field_resource', function() {
			// Resource choice changes which pool gates remaining capacity; refetch like staff.
			state.slots = null;
			if ( state.selectedDate ) {
				fetchSlots( state.selectedDate, state.selectedDate, state.staffId || 0, function() {
					renderSlots();
				} );
			}
		} );
	}

	/**
	 * Fetch slots from the Provider AJAX endpoint.
	 *
	 * @param {string}   startDate 'YYYY-MM-DD'
	 * @param {string}   endDate   'YYYY-MM-DD'
	 * @param {number}   staffId   Staff ID.
	 * @param {Function} callback  Success callback( data ).
	 * @param {string}   [level]   Override level.
	 */
	function fetchSlots( startDate, endDate, staffId, callback, level ) {
		if ( state.loading ) {
			return;
		}

		state.loading = true;

		var ajaxUrl = ( typeof wc_appointment_form_params !== 'undefined' && wc_appointment_form_params.ajax_url )
			? wc_appointment_form_params.ajax_url
			: wc_appointments_date_picker_args.ajax_url;

		$.ajax( {
			type: 'POST',
			url:  ajaxUrl.replace( '%%endpoint%%', state.ajaxAction ),
			data: {
				product_id:  state.productId,
				start_date:  startDate,
				end_date:    endDate,
				staff_id:    staffId,
				resource_id: parseInt( state.formEl.find( '#wc_appointments_field_resource' ).val(), 10 ) || 0,
				level:       level || state.level,
			},
			dataType: 'json',
			success: function( data ) {
				state.loading = false;
				if ( data && ! data.error ) {
					callback( data );
				}
			},
			error: function() {
				state.loading = false;
			},
		} );
	}

	/**
	 * Apply month-level data to the datepicker.
	 *
	 * Reads day summaries and applies CSS classes + attributes to calendar cells.
	 * This replaces the rule-processing in getDateElementAttributes().
	 *
	 * @param {Object} data Provider response.
	 */
	function applyMonthData( data ) {
		if ( ! data.days || ! state.datepickerEl || ! state.datepickerEl.length ) {
			return;
		}

		var days = data.days;

		// Apply to each datepicker cell via the beforeShowDay callback bridge.
		// Store data on the form element so date-picker.js can read it.
		state.formEl.data( 'wcaSlotsV3Days', days );
		state.formEl.data( 'wcaSlotsV3Months', data.months || {} );

		// Trigger custom event so date-picker.js can refresh.
		state.formEl.trigger( 'wca-slots-v3-month-loaded', [ data ] );
	}

	/**
	 * Render time slots for a selected day.
	 *
	 * Replaces the get_available_slots_html() template logic with
	 * pre-computed slot data from the Provider.
	 *
	 * @param {Object} data    Provider response (level: slots or full).
	 * @param {string} dateStr 'YYYY-MM-DD'
	 */
	function renderTimeSlots( data, dateStr ) {
		var container = state.timeSlotsEl;
		if ( ! container || ! container.length ) {
			return;
		}

		var daySlots = ( data.slots && data.slots[ dateStr ] ) ? data.slots[ dateStr ] : [];

		if ( ! daySlots.length ) {
			container.html( '<p class="wca-no-slots">' + getI18n( 'no_slots' ) + '</p>' );
			state.formEl.trigger( 'wca-slots-v3-day-rendered', [ dateStr, [] ] );
			return;
		}

		var html = '<div class="wca-time-slots">';

		for ( var i = 0; i < daySlots.length; i++ ) {
			var slot = daySlots[ i ];
			html += renderSingleSlot( slot );
		}

		html += '</div>';
		container.html( html );

		// Bind slot click.
		container.find( '.wca-slot' ).on( 'click', function() {
			var ts = $( this ).data( 'start' );
			selectSlot( ts, dateStr );
		} );

		state.formEl.trigger( 'wca-slots-v3-day-rendered', [ dateStr, daySlots ] );
	}

	/**
	 * Render a single time slot element.
	 *
	 * @param {Object} slot Slot data from Provider.
	 * @return {string} HTML.
	 */
	function renderSingleSlot( slot ) {
		var classes = [ 'wca-slot' ];
		var cap     = slot.capacity || {};

		if ( ! slot.available ) {
			classes.push( 'wca-slot--sold-out' );
		} else if ( cap.status === 'filling_fast' ) {
			classes.push( 'wca-slot--filling-fast' );
		} else {
			classes.push( 'wca-slot--available' );
		}

		var timeDisplay = slot.time || '';
		var priceDisplay = slot.price && slot.price.display ? slot.price.display : '';
		var capMessage  = cap.message || '';

		var html = '<div class="' + classes.join( ' ' ) + '" data-start="' + slot.start + '" data-end="' + slot.end + '">';
		html += '<span class="wca-slot__time">' + escHtml( timeDisplay ) + '</span>';

		if ( priceDisplay || capMessage ) {
			html += '<span class="wca-slot__meta">';
			if ( priceDisplay ) {
				html += '<span class="wca-slot__price">' + priceDisplay + '</span>';
			}

			if ( capMessage ) {
				html += '<span class="wca-slot__cap">' + escHtml( capMessage ) + '</span>';
			}

			html += '</span>';
		}

		// Occupancy indicator.
		if ( cap.occupancy_pct > 0 && slot.available ) {
			html += '<span class="wca-slot__occupancy" style="width:' + cap.occupancy_pct + '%"></span>';
		}

		html += '</div>';

		return html;
	}

	/**
	 * Handle slot selection.
	 *
	 * @param {number} startTs  Slot start timestamp.
	 * @param {string} dateStr  Date 'YYYY-MM-DD'.
	 */
	function selectSlot( startTs, dateStr ) {
		// Set the hidden field value.
		var dateTimeField = state.formEl.find( '#wc_appointments_field_start_date_time' );
		if ( dateTimeField.length ) {
			dateTimeField.val( startTs ).trigger( 'change' );
		}

		// Visual selection.
		state.formEl.find( '.wca-slot' ).removeClass( 'wca-slot--selected' );
		state.formEl.find( '.wca-slot[data-start="' + startTs + '"]' ).addClass( 'wca-slot--selected' );

		state.formEl.trigger( 'wca-slots-v3-slot-selected', [ startTs, dateStr ] );
	}

	// ─── Helpers ────────────────────────────────────────────────────────

	/**
	 * Get the last day of a month.
	 *
	 * @param {string} monthStr 'YYYY-MM'
	 * @return {string} 'YYYY-MM-DD'
	 */
	function getLastDayOfMonth( monthStr ) {
		var parts = monthStr.split( '-' );
		var year  = parseInt( parts[0], 10 );
		var month = parseInt( parts[1], 10 );
		var last  = new Date( year, month, 0 ).getDate();
		return monthStr + '-' + ( last < 10 ? '0' : '' ) + last;
	}

	/**
	 * Get i18n string.
	 *
	 * @param {string} key String key.
	 * @return {string}
	 */
	function getI18n( key ) {
		var strings = {
			no_slots: 'No time slots available for this date.',
		};

		if ( typeof wc_appointment_form_params !== 'undefined' ) {
			if ( key === 'no_slots' && wc_appointment_form_params.i18n_date_unavailable ) {
				return wc_appointment_form_params.i18n_date_unavailable;
			}
		}

		return strings[ key ] || '';
	}

	/**
	 * Escape HTML entities.
	 *
	 * @param {string} str Input.
	 * @return {string}
	 */
	function escHtml( str ) {
		if ( ! str ) {
			return '';
		}
		var div = document.createElement( 'div' );
		div.appendChild( document.createTextNode( str ) );
		return div.innerHTML;
	}

	// ─── Public Interface ───────────────────────────────────────────────
	return {
		init:       init,
		loadMonth:  loadMonth,
		loadDay:    loadDay,
		setStaff:   setStaff,
		clearCache: clearCache,
		isEnabled:  isEnabled,
		// Expose state for debugging.
		_state:     state,
	};

} )( jQuery );
