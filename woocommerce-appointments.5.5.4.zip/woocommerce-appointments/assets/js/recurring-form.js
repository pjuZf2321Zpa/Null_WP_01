/* global wcaRecurring, wcaShared */
( function () {
	'use strict';

	var sh = wcaShared;
	var rp = sh.recurringPreview;
	function i18nFmt( key, fb, reps ) {
		return sh.i18n( wcaRecurring.i18n || {}, key, fb, reps );
	}

	function setPreviewLoading( form, active, sessions ) {
		var $ = typeof jQuery !== 'undefined' ? jQuery : null;
		if ( sessions !== false ) {
			form.root.classList.toggle( 'wca-preview-is-loading', !!active );
			if ( form.previewBar ) {
				form.previewBar.classList.toggle( 'is-active', !!active );
			}
		}
		sh.toggleLoadingBar( form.costEl, active );
		if ( active && form.costEl && $ ) {
			$( form.costEl ).show();
		}
		if ( active ) {
			sh.setDisabled( form.bookBtn, true );
		} else if ( sessions === false ) {
			sh.setDisabled( form.bookBtn, form.lastBillable < recurringMinRequired() );
		}
	}

	function recurringMinRequired() {
		return Math.max( 2, parseInt( wcaRecurring.minOccurrences, 10 ) || 2 );
	}

	function recurringMaxAllowed() {
		return Math.max( recurringMinRequired(), parseInt( wcaRecurring.maxOccurrences, 10 ) || 8 );
	}

	var previewCountOpts = { packageFb: '%d appointments in this package' };

	function appendPreviewRow( list, form, row, unavailableIds ) {
		var id = row.recurrence_id;
		var s = form.sched;
		var active = s.rescheduleTarget === id;
		var li = document.createElement( 'li' );

		li.className = 'wca-preview-item' + ( active ? ' is-rescheduling' : '' );
		li.dataset.recurrenceId = id;
		li.innerHTML = rp.rowHtml( {
			id: id,
			anchor: id === form.anchorRecurrenceId,
			active: active,
			fetching: s.rescheduleFetching === id,
			unavail: !! unavailableIds[ id ],
			datetime: sh.formatFakeUtcDateTime( row.start_ts, row.display_label ),
			i18n: wcaRecurring.i18n || {},
			userCanCancel: !! wcaRecurring.userCanCancel,
			userCanReschedule: !! wcaRecurring.userCanReschedule,
			suggestions: active ? ( s.slotSuggestions[ id ] || [] ) : [],
			formatLabel: function ( slot, ts ) {
				return slot && slot.display_label ? slot.display_label : sh.formatFakeUtcDateTime( ts );
			}
		} );
		list.appendChild( li );
	}

	function RecurringForm( root ) {
		this.root = root;
		this.repeatCheckbox = root.querySelector( '#wca_recurring_repeat' );
		this.freqHidden = root.querySelector( '.wca-recurring-freq-value' );
		this.paymentModelHidden = root.querySelector( '.wca-payment-model-value' );
		this.footer = root.querySelector( '#wca-recurring-footer' );
		this.schedule = root.querySelector( '#wca-recurring-schedule' );
		this.detail = root.querySelector( '#wca-recurring-detail' );
		this.previewStatus = root.querySelector( '#wca-preview-status' );
		this.previewList = root.querySelector( '#wca-preview-list' );
		this.previewBar = root.querySelector( '.wca-recurring-preview .wca-loading-bar' );
		this.interval = root.querySelector( '#wca_recurring_interval' );
		this.intervalLabel = root.querySelector( '#wca-interval-label' );
		this.count = root.querySelector( '#wca_recurring_count' );
		this.recurringMode = root.dataset.recurringMode || 'prepaid';
		this.defaultFreq = root.dataset.defaultFreq || 'WEEKLY';
		this.idemKey = ( window.crypto && crypto.randomUUID ) ? crypto.randomUUID() : String( Date.now() );
		this.appointmentFormEl = root.closest( '.wc-appointments-appointment-form' );
		this.formEl = this.appointmentFormEl ? this.appointmentFormEl.closest( 'form' ) : null;
		this.costEl = this.appointmentFormEl ? sh.qs( this.appointmentFormEl, '.wc-appointments-appointment-cost' ) : null;
		this.bookBtn = sh.qs( this.formEl || this.appointmentFormEl, '.single_add_to_cart_button' );
		this.anchorSlotTs = 0;
		this.previewAbort = null;
		this.previewReq = 0;
		this.sched = rp.fresh();
		this.lastBillable = 0;
		this.anchorRecurrenceId = '';
		this.previewExpanded = false;
		this.previewToggle = null;
		this.previewCtx = null;
		this.removeBlocked = false;
		this.lastSummary = null;
		this.bind();
		this.setExpanded( this.isRecurring() );
		this.updateUI();
	}

	RecurringForm.prototype.resetScheduleAdjustments = function () {
		this.sched = rp.fresh();
		this.previewExpanded = false;
		this.removeBlocked = false;
		this.afterSchedList();
	};

	RecurringForm.prototype.afterSchedList = function () {
		if ( this.previewCtx ) {
			this.renderPreviewList( this.previewCtx.occurrences, this.previewCtx.unavailableIds );
		}
	};

	RecurringForm.prototype.isPatternField = function ( el ) {
		if ( ! el || ! el.name ) {
			return false;
		}
		var name = el.name;
		return 'wca_recurring_repeat' === name
			|| 'wca_recurring_freq_select' === name
			|| 'wca_recurring_interval' === name
			|| 'wca_recurring_count' === name;
	};

	RecurringForm.prototype.getCheckedFreqInput = function () {
		return this.root.querySelector( 'input[name="wca_recurring_freq_select"]:checked' );
	};

	RecurringForm.prototype.getFreqInputs = function () {
		return sh.qsa( this.root, 'input[name="wca_recurring_freq_select"]' );
	};

	RecurringForm.prototype.getFreqValue = function () {
		if ( ! this.isRecurring() ) {
			return 'NONE';
		}
		var checked = this.getCheckedFreqInput();
		if ( checked ) {
			return checked.value || this.defaultFreq;
		}
		if ( this.freqHidden ) {
			return this.freqHidden.value || this.defaultFreq;
		}
		return this.defaultFreq;
	};

	RecurringForm.prototype.setFreqValue = function ( freq ) {
		if ( 'NONE' === freq ) {
			return;
		}
		var inputs = this.getFreqInputs();
		var i;
		for ( i = 0; i < inputs.length; i++ ) {
			if ( 'radio' === inputs[ i ].type ) {
				inputs[ i ].checked = inputs[ i ].value === freq;
			} else {
				inputs[ i ].value = freq;
			}
		}
	};

	RecurringForm.prototype.isRecurring = function () {
		return !!( this.repeatCheckbox && this.repeatCheckbox.checked );
	};

	RecurringForm.prototype.bind = function () {
		var self = this;

		if ( this.repeatCheckbox ) {
			this.repeatCheckbox.addEventListener( 'change', function () {
				self.onRepeatChange();
			} );
		}

		this.root.addEventListener( 'change', sh.debounce( function ( ev ) {
			if ( self.isPatternField( ev.target ) ) {
				self.resetScheduleAdjustments();
			}
			if ( self.isRecurring() ) {
				self.updateUI();
			}
			self.refresh(
				ev.target && 'wca_payment_model' === ev.target.name && self.hasSelectedSlot()
					? { pricing: true }
					: {}
			);
		}, 300 ) );

		document.addEventListener( 'change', sh.debounce( function ( ev ) {
			var target = ev.target;
			if ( ! target || ! self.isRecurring() || ! self.hasSelectedSlot() ) {
				return;
			}
			if ( target.matches && target.matches( '#wc_appointments_field_timezone, select[name="wc_appointments_field_timezone"]' ) ) {
				var formRoot = self.appointmentFormEl || self.formEl;
				if ( formRoot && formRoot.contains( target ) ) {
					self.refresh( { keepList: true } );
				}
			}
		}, 300 ) );

		this.root.addEventListener( 'input', sh.debounce( function () {
			if ( self.isRecurring() ) {
				self.updateUI();
			}
		}, 150 ) );

		if ( this.previewList ) {
			this.previewList.addEventListener( 'click', function ( ev ) {
				rp.handleListClick( ev, {
					onRemove: function ( id ) { self.removeSession( id ); },
					onReschedule: function ( id ) { self.toggleReschedule( id ); },
					getRescheduleTarget: function () { return self.sched.rescheduleTarget; },
					onPickSlot: function ( id, ts ) { self.applyRescheduleOverride( id, ts ); },
					canReschedule: !!wcaRecurring.userCanReschedule
				} );
			} );
		}

		var eventsHost = this.formEl || this.appointmentFormEl;
		if ( eventsHost ) {
			var eventTypes = [
				'wca:time-selected',
				'wca:month-selected',
				'wca:date-selected',
				'wca:time-cleared',
				'wca:date-cleared',
				'wca:staff-selected',
				'wca:addon-costs-changed',
				'wca:addon-costs-only-changed',
				'wca:addon-duration-changed',
				'wca:quantity-changed'
			];
			eventTypes.forEach( function ( name ) {
				eventsHost.addEventListener( name, function () {
					if ( ! self.isRecurring() ) {
						return;
					}
					var type = name.replace( /^wca:/, '' );

					if ( type === 'time-cleared' || type === 'date-cleared' || type === 'staff-selected' ) {
						if ( self.sched.rescheduleTarget ) {
							return;
						}
						self.clearSlotPreview();
						return;
					}
					if ( type === 'quantity-changed' || type.indexOf( 'addon-' ) === 0 ) {
						if ( self.hasSelectedSlot() ) {
							self.refresh( { pricing: true } );
						}
						return;
					}
					if ( self.sched.rescheduleTarget ) {
						if (
							type === 'time-selected' ||
							type === 'month-selected' ||
							( type === 'date-selected' && ! self.needsTimeSlot() )
						) {
							var pickTs = self.getSlotTimestamp();
							if ( pickTs > 0 ) {
								self.applyRescheduleOverride( self.sched.rescheduleTarget, pickTs );
							}
						}
						return;
					}
					if ( type === 'date-selected' && self.needsTimeSlot() ) {
						self.clearSlotPreview();
						return;
					}
					self.onSlotChanged();
				} );
			} );
		}
	};

	RecurringForm.prototype.setRecurringCostMode = function ( active ) {
		if ( ! this.formEl ) {
			return;
		}
		if ( active ) {
			this.formEl.setAttribute( 'data-wca-recurring-active', '1' );
		} else {
			this.formEl.removeAttribute( 'data-wca-recurring-active' );
		}
	};

	RecurringForm.prototype.updatePricing = function ( data ) {
		if ( ! this.isRecurring() || ! data || ! data.summary ) {
			return;
		}

		var html = data.summary.total_price_html || '';
		var $ = typeof jQuery !== 'undefined' ? jQuery : null;

		if ( this.costEl && html && $ ) {
			this.costEl.innerHTML = html;
			sh.toggleLoadingBar( this.costEl, false );
			$( this.costEl ).show();
			$( this.formEl ).find( '.wc-appointments-recurring-hook' ).show();
		}

		if ( this.formEl && typeof CustomEvent !== 'undefined' ) {
			this.formEl.dispatchEvent(
				new CustomEvent( 'wca:appointment-cost-success', { bubbles: true, detail: { html: html } } )
			);
		}
	};

	RecurringForm.prototype.setExpandedFieldsDisabled = function ( expanded ) {
		var fields = this.getFreqInputs().concat( sh.qsa( this.root, 'input[name="wca_payment_model"]' ) );
		if ( this.interval ) {
			fields.push( this.interval );
		}
		if ( this.count ) {
			fields.push( this.count );
		}
		if ( this.paymentModelHidden ) {
			fields.push( this.paymentModelHidden );
		}
		var i;
		for ( i = 0; i < fields.length; i++ ) {
			fields[ i ].disabled = ! expanded;
		}
	};

	RecurringForm.prototype.setExpanded = function ( expanded ) {
		this.root.classList.toggle( 'is-active', expanded );
		if ( this.schedule ) {
			this.schedule.hidden = ! expanded;
		}
		if ( this.detail ) {
			this.detail.hidden = ! expanded;
		}
		if ( this.footer ) {
			this.footer.hidden = ! expanded;
		}
		this.setExpandedFieldsDisabled( expanded );
		if ( typeof document !== 'undefined' && document.body ) {
			document.body.classList.toggle( 'wca-recurring-checkout-active', expanded && this.isRecurring() );
		}
	};

	RecurringForm.prototype.onRepeatChange = function () {
		if ( this.isRecurring() ) {
			this.setRecurringCostMode( true );
			this.setExpanded( true );
			this.updateUI();
			this.onSlotChanged();
		} else {
			this.setRecurringCostMode( false );
			this.setExpanded( false );
			this.clearSlotPreview();
		}
		if ( this.formEl ) {
			this.syncMembershipFooter();
		}
	};

	RecurringForm.prototype.syncMembershipFooter = function () {
		if ( ! this.formEl ) {
			return;
		}
		var footer = this.formEl.querySelector( '.wca-membership-footer' );
		if ( ! footer ) {
			return;
		}
		if ( this.isRecurring() ) {
			footer.hidden = this.lastBillable < recurringMinRequired();
			return;
		}
		var costEl = this.appointmentFormEl ? sh.qs( this.appointmentFormEl, '.wc-appointments-appointment-cost' ) : null;
		footer.hidden = ! costEl || ! costEl.textContent.trim();
	};

	RecurringForm.prototype.getCustomerOptions = function () {
		return {
			allowedFreqs: ( wcaRecurring.allowedFreqs && wcaRecurring.allowedFreqs.length ) ? wcaRecurring.allowedFreqs : [ 'WEEKLY' ],
			defaultFreq: wcaRecurring.defaultFreq || 'WEEKLY',
			minOccurrences: wcaRecurring.minOccurrences || 2,
			maxOccurrences: wcaRecurring.maxOccurrences || 8,
			recurringMode: wcaRecurring.recurringMode || 'prepaid',
			paymentOptions: wcaRecurring.paymentOptions || [ 'prepaid' ],
			defaultPaymentModel: wcaRecurring.defaultPaymentModel || 'prepaid'
		};
	};

	RecurringForm.prototype.getPaymentModel = function () {
		var checked = this.root.querySelector( 'input[name="wca_payment_model"]:checked' );
		if ( checked ) {
			return checked.value || 'prepaid';
		}
		if ( this.paymentModelHidden ) {
			return this.paymentModelHidden.value || 'prepaid';
		}
		return this.getCustomerOptions().defaultPaymentModel;
	};

	RecurringForm.prototype.getActiveFreq = function () {
		var opts = this.getCustomerOptions();
		var freq = this.getFreqValue();
		if ( 'NONE' === freq ) {
			return 'NONE';
		}
		if ( opts.allowedFreqs.indexOf( freq ) === -1 ) {
			freq = opts.allowedFreqs[0];
			this.setFreqValue( freq );
		}
		return freq;
	};

	RecurringForm.prototype.updateUI = function () {
		var freq = this.getActiveFreq();

		if ( 'NONE' === freq ) {
			return;
		}

		var interval = this.interval ? parseInt( this.interval.value, 10 ) : 1;
		if ( ! interval || interval < 1 ) {
			interval = 1;
		}

		if ( this.intervalLabel ) {
			this.intervalLabel.textContent = rp.intervalUnit( freq, interval, wcaRecurring.i18n || {} );
		}
	};

	RecurringForm.prototype.durationUnit = function () {
		var picker = this.appointmentFormEl ? sh.qs( this.appointmentFormEl, '.picker' ) : null;
		return picker ? ( picker.getAttribute( 'data-duration_unit' ) || '' ) : '';
	};

	RecurringForm.prototype.needsTimeSlot = function () {
		return rp.needsTimeSlot( this.durationUnit() );
	};

	RecurringForm.prototype.hasSelectedSlot = function () {
		if ( ! this.appointmentFormEl ) {
			return false;
		}
		if ( this.getSlotTimestamp() > 0 ) {
			return true;
		}
		var unit = this.durationUnit();
		if ( unit === 'month' ) {
			return sh.qsa( this.appointmentFormEl, '.picker li.slot.selected' ).length > 0;
		}
		if ( unit === 'day' ) {
			var fieldset = sh.qs( this.appointmentFormEl, 'fieldset.wc-appointments-date-picker' );
			if ( ! fieldset ) {
				return false;
			}
			var year = sh.qs( fieldset, 'input.appointment_date_year' );
			var month = sh.qs( fieldset, 'input.appointment_date_month' );
			var day = sh.qs( fieldset, 'input.appointment_date_day' );
			return !!(
				parseInt( year && year.value, 10 ) &&
				parseInt( month && month.value, 10 ) &&
				parseInt( day && day.value, 10 )
			);
		}
		return false;
	};

	RecurringForm.prototype.getSlotTimestamp = function () {
		var wrap = this.appointmentFormEl;
		var ts;

		if ( ! wrap ) {
			return 0;
		}

		if ( this.formEl ) {
			var slotField = sh.qs( this.formEl, '.slot-timestamp-field' );
			ts = slotField ? ( parseInt( slotField.value, 10 ) || 0 ) : 0;
			if ( ts > 0 ) {
				return ts;
			}
			var startField = sh.qs( this.formEl, 'input[name="wc_appointments_field_start_date_timestamp"]' );
			ts = startField ? ( parseInt( startField.value, 10 ) || 0 ) : 0;
			if ( ts > 0 ) {
				return ts;
			}
		}

		var slotInput = sh.qs( wrap, '.wc-appointments-slots-container input[data-slot-timestamp]' );
		ts = slotInput ? ( parseInt( slotInput.getAttribute( 'data-slot-timestamp' ), 10 ) || 0 ) : 0;
		if ( ts > 0 ) {
			return ts;
		}

		var selectedSlots = sh.qsa( wrap, 'li.slot.selected' );
		for ( var i = 0; i < selectedSlots.length; i++ ) {
			var slotTs = parseInt( selectedSlots[ i ].dataset.slotTimestamp, 10 ) || 0;
			if ( slotTs > 0 ) {
				return slotTs;
			}
		}
		return 0;
	};

	RecurringForm.prototype.syncPreviewToggle = function ( show, total ) {
		var btn = this.previewToggle;
		var hide = ! show || ! total || total <= rp.previewCollapseAt;

		if ( ! hide && ! btn ) {
			var self = this;
			var previewWrap = this.root.querySelector( '.wca-recurring-preview' );
			if ( ! previewWrap ) {
				return;
			}
			btn = document.createElement( 'button' );
			btn.type = 'button';
			btn.className = 'wca-expand-btn';
			btn.addEventListener( 'click', function ( ev ) {
				ev.preventDefault();
				self.previewExpanded = ! self.previewExpanded;
				if ( self.previewCtx ) {
					self.renderPreviewList( self.previewCtx.occurrences, self.previewCtx.unavailableIds );
				}
			} );
			previewWrap.appendChild( btn );
			this.previewToggle = btn;
		}
		if ( ! btn ) {
			return;
		}
		btn.hidden = hide;
		btn.style.display = hide ? 'none' : '';
		if ( ! hide ) {
			btn.textContent = this.previewExpanded
				? i18nFmt( 'showFewerSessions', 'Show fewer appointments' )
				: i18nFmt( 'showAllSessions', 'Show all %d appointments', total );
		}
	};

	RecurringForm.prototype.clearSlotPreview = function () {
		this.previewReq += 1;
		if ( this.previewAbort ) {
			this.previewAbort.abort();
			this.previewAbort = null;
		}
		setPreviewLoading( this, false );
		this.anchorSlotTs = 0;
		this.sched = rp.fresh();
		this.previewCtx = null;
		this.previewExpanded = false;
		this.previewList.innerHTML = '';
		this.syncPreviewToggle( false );
		this.clearHiddenFields();
		if ( this.isRecurring() ) {
			sh.setDisabled( this.bookBtn, true );
			this.previewStatus.textContent = rp.statusMessage( {
				tr: i18nFmt,
				hasAnchor: false,
				loading: false,
				needsTimeSlot: this.needsTimeSlot()
			} );
			return;
		}
		this.lastBillable = 0;
		this.lastSummary = null;
		this.previewStatus.textContent = '';
		if ( this.formEl && this.hasSelectedSlot() && typeof jQuery !== 'undefined' ) {
			jQuery( this.formEl ).triggerHandler( { day: 'date-selected', month: 'month-selected' }[ this.durationUnit() ] || 'time-selected' );
		}
	};

	RecurringForm.prototype.onSlotChanged = function () {
		if ( ! this.hasSelectedSlot() ) {
			this.clearSlotPreview();
			return;
		}
		if ( this.sched.rescheduleTarget ) {
			return;
		}
		var ts = this.getSlotTimestamp();
		if ( ts && ts !== this.anchorSlotTs ) {
			this.anchorSlotTs = ts;
			this.resetScheduleAdjustments();
		} else if ( ts ) {
			this.anchorSlotTs = ts;
		}
		this.refresh( { keepList: !!this.previewCtx } );
	};

	RecurringForm.prototype.getSessionCount = function () {
		var min   = recurringMinRequired();
		var max   = recurringMaxAllowed();
		var count = this.count ? parseInt( this.count.value, 10 ) : max;
		return Math.max( min, Math.min( max, count || max ) );
	};

	RecurringForm.prototype.buildRrule = function () {
		if ( ! this.isRecurring() ) {
			return '';
		}
		var interval = this.interval ? parseInt( this.interval.value, 10 ) : 1;
		return sh.buildRrule( this.getActiveFreq(), interval, this.getSessionCount() );
	};

	RecurringForm.prototype.getBookingTimezone = function () {
		var tz = wcaRecurring.timezone;
		var root = this.appointmentFormEl || this.formEl;

		if ( root ) {
			var sel = root.querySelector( '#wc_appointments_field_timezone, select[name="wc_appointments_field_timezone"]' );
			if ( sel && sel.value ) {
				tz = sel.value;
			}
		}

		// Match date-picker / slots AJAX: prefer the visible select, cookie only when select is empty.
		if ( ( ! tz || ! String( tz ).length ) && typeof wca_get_cookie === 'function' ) {
			var raw = wca_get_cookie( 'appointments_time_zone' );
			if ( raw ) {
				try {
					tz = decodeURIComponent( raw );
				} catch ( err ) {
					tz = raw;
				}
			}
		}

		return tz;
	};

	RecurringForm.prototype.buildConflictsPayload = function () {
		if ( ! this.previewCtx ) {
			return [];
		}

		var out = [];
		var occ = this.previewCtx.occurrences || [];
		var unavailable = this.previewCtx.unavailableIds || {};
		var i;

		for ( i = 0; i < occ.length; i++ ) {
			if ( unavailable[ occ[ i ].recurrence_id ] ) {
				out.push( {
					recurrence_id: occ[ i ].recurrence_id,
					start_ts: occ[ i ].start_ts,
					reason: 'slot_unavailable'
				} );
			}
		}

		return out;
	};

	RecurringForm.prototype.buildPreviewBody = function ( opts ) {
		opts = opts || {};
		var ts = this.getSlotTimestamp();
		var body = {
			product_id: wcaRecurring.productId,
			dtstart_ts: ts,
			timezone: this.getBookingTimezone(),
			rrule: this.buildRrule(),
			payment_model: this.getPaymentModel()
		};
		if ( this.formEl && typeof jQuery !== 'undefined' ) {
			body.form = jQuery( this.formEl ).serialize();
		} else if ( this.appointmentFormEl && typeof jQuery !== 'undefined' ) {
			body.form = jQuery( this.appointmentFormEl ).serialize();
		}
		body = rp.attach( body, this.sched );
		if ( opts.pricing && this.previewCtx ) {
			body.pricing_only = true;
			body.conflicts = this.buildConflictsPayload();
		}
		return body;
	};

	RecurringForm.prototype.applyRescheduleOverride = function ( recurrenceId, startTs ) {
		var result = rp.applyOverride( this.sched, recurrenceId, startTs );
		if ( ! result ) {
			return;
		}
		this.sched = result.schedule;
		this.refresh( { keepList: true } );
	};

	RecurringForm.prototype.removeSession = function ( recurrenceId ) {
		var result = rp.removeOccurrence( this.sched, recurrenceId, {
			anchorId: this.anchorRecurrenceId,
			billable: this.lastBillable,
			minRequired: recurringMinRequired()
		} );
		if ( ! result ) {
			return;
		}
		if ( result.blocked ) {
			this.removeBlocked = true;
			if ( this.lastSummary ) {
				this.updatePreviewNotice( this.lastSummary );
			}
			return;
		}
		this.removeBlocked = false;
		this.sched = result.schedule;
		this.refresh( { keepList: true } );
	};

	RecurringForm.prototype.toggleReschedule = function ( recurrenceId ) {
		var self = this;
		var occ = ( this.previewCtx && this.previewCtx.occurrences ) || [];
		var toggled = rp.toggleReschedule( this.sched, recurrenceId );

		this.sched = toggled.schedule;
		this.afterSchedList();
		rp.fetchRescheduleSuggestions( toggled, recurrenceId, occ, function () {
			return self.buildPreviewBody();
		}, function ( body ) {
			return sh.restJson( wcaRecurring.previewUrl, { method: 'POST', body: body } );
		}, function ( suggestions, id ) {
			if ( self.sched.rescheduleTarget !== id ) {
				return;
			}
			self.sched = suggestions ? rp.setSuggestions( self.sched, id, suggestions ) : rp.patch( self.sched, { rescheduleFetching: '' } );
			self.afterSchedList();
		} );
	};

	RecurringForm.prototype.refresh = async function ( opts ) {
		opts = opts || {};
		if ( ! this.isRecurring() ) {
			return;
		}
		if ( ! this.hasSelectedSlot() ) {
			this.clearSlotPreview();
			return;
		}

		if ( this.previewAbort ) {
			this.previewAbort.abort();
		}
		this.previewAbort = typeof AbortController !== 'undefined' ? new AbortController() : null;
		var requestId = ++this.previewReq;
		var pricingOnly = !!opts.pricing && !!this.previewCtx;
		var keepList = pricingOnly || !!opts.keepList || ( !!this.previewCtx && !opts.forceClear );

		if ( ! keepList ) {
			this.previewList.innerHTML = '';
			this.syncPreviewToggle( false );
			this.previewStatus.textContent = '';
		}
		setPreviewLoading( this, true, !pricingOnly );
		if ( ! pricingOnly ) {
			this.updatePreviewNotice( this.lastSummary || null, true );
		}

		var body = this.buildPreviewBody( opts );

		try {
			var data = await sh.restJson( wcaRecurring.previewUrl, {
				method: 'POST',
				body: body,
				signal: this.previewAbort ? this.previewAbort.signal : undefined
			} );
			if ( requestId !== this.previewReq ) {
				return;
			}
			if ( ! this.hasSelectedSlot() ) {
				this.clearSlotPreview();
				return;
			}
			this.updatePricing( data );
			if ( ! pricingOnly ) {
				this.renderPreview( data );
			}
			this.writeHiddenFields( body );
		} catch ( err ) {
			if ( err && err.name === 'AbortError' ) {
				return;
			}
			if ( requestId !== this.previewReq ) {
				return;
			}
			if ( ! pricingOnly ) {
				this.renderError( { detail: err && err.message ? err.message : String( err ) } );
			}
		} finally {
			if ( requestId === this.previewReq ) {
				this.previewAbort = null;
				setPreviewLoading( this, false, !pricingOnly );
			}
		}
	};

	RecurringForm.prototype.updatePreviewNotice = function ( summary, loading ) {
		var msg = rp.statusMessage( {
			tr: i18nFmt,
			removeBlocked: this.removeBlocked,
			hasAnchor: this.hasSelectedSlot(),
			loading: !!loading,
			needsTimeSlot: this.needsTimeSlot(),
			summary: summary,
			minRequired: recurringMinRequired()
		} );
		if ( msg ) {
			this.previewStatus.innerHTML = '<span class="wca-preview-warning">' + msg + '</span>';
		} else {
			this.previewStatus.textContent = rp.countLabel( summary, i18nFmt, previewCountOpts );
		}
	};

	RecurringForm.prototype.renderPreviewList = function ( occurrences, unavailableIds ) {
		var self = this;
		var list = this.previewList;
		var total = occurrences.length;
		var ellipsis;

		list.innerHTML = '';
		if ( ! total ) {
			this.syncPreviewToggle( false );
			return;
		}

		rp.listPlan( occurrences, unavailableIds, this.previewExpanded ).forEach( function ( item ) {
			if ( item.gap ) {
				ellipsis = document.createElement( 'li' );
				ellipsis.className = 'wca-preview-ellipsis';
				ellipsis.textContent = i18nFmt( 'previewCollapsedSummary', '… and %d more appointments', item.gap );
				list.appendChild( ellipsis );
				return;
			}
			appendPreviewRow( list, self, occurrences[ item.idx ], unavailableIds );
		} );

		this.syncPreviewToggle( total > rp.previewCollapseAt, total );
	};

	RecurringForm.prototype.renderPreview = function ( data ) {
		var summary = data.summary || {};
		var unavailableIds = sh.conflictsToMap( data.conflicts );

		var billable = summary.billable_count || 0;
		this.lastBillable = billable;
		this.syncMembershipFooter();

		var occurrences = data.occurrences || [];
		this.anchorRecurrenceId = rp.resolveAnchor( occurrences, this.getSlotTimestamp() );

		sh.setDisabled( this.bookBtn, billable < recurringMinRequired() );
		this.lastSummary = summary;
		this.updatePreviewNotice( summary );

		this.sched = rp.patch( this.sched, { slotSuggestions: {}, rescheduleTarget: '', rescheduleFetching: '' } );
		this.previewCtx = { occurrences: occurrences, unavailableIds: unavailableIds };
		this.renderPreviewList( occurrences, unavailableIds );
	};

	RecurringForm.prototype.renderError = function ( problem ) {
		this.previewCtx = null;
		this.previewExpanded = false;
		this.previewList.innerHTML = '';
		this.syncPreviewToggle( false );
		this.previewStatus.textContent = ( problem && problem.detail ) ? problem.detail : wcaRecurring.i18n.networkError;
		sh.setDisabled( this.bookBtn, true );
	};

	RecurringForm.prototype.writeHiddenFields = function ( body ) {
		this.setHidden( 'wca_recurring_enabled', '1' );
		this.setHidden( 'wca_rrule', body.rrule );
		this.setHidden( 'wca_recurring_schedule', JSON.stringify( rp.payload( this.sched ) ) );
		this.setHidden( 'wca_idempotency_key', this.idemKey );
		this.setHidden( 'wca_payment_model', this.getPaymentModel() );
	};

	RecurringForm.prototype.clearHiddenFields = function () {
		[ 'wca_recurring_enabled', 'wca_rrule', 'wca_recurring_schedule', 'wca_idempotency_key', 'wca_payment_model' ].forEach( function ( name ) {
			var el = this.root.querySelector( 'input[type="hidden"][name="' + name + '"]' );
			if ( el ) {
				el.remove();
			}
		}.bind( this ) );
	};

	RecurringForm.prototype.setHidden = function ( name, value ) {
		var el = this.root.querySelector( 'input[type="hidden"][name="' + name + '"]' );
		if ( ! el ) {
			el = document.createElement( 'input' );
			el.type = 'hidden';
			el.name = name;
			this.root.appendChild( el );
		}
		el.value = value;
	};

	document.querySelectorAll( '.wca-recurring-picker' ).forEach( function ( el ) {
		new RecurringForm( el );
	} );
}() );
