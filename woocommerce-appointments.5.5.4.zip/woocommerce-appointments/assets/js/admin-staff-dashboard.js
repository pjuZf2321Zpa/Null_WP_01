/**
 * Staff Dashboard JavaScript
 *
 * Modern analytics dashboard with charts and real-time updates.
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

(function() {
	'use strict';

	/**
	 * Simple AJAX POST helper using fetch.
	 *
	 * @param {string} url      The endpoint URL.
	 * @param {Object} data     Key/value pairs to send.
	 * @param {Object} callbacks Object with success, error, and complete callbacks.
	 */
	function ajaxPost(url, data, callbacks) {
		var params = new URLSearchParams();
		Object.keys(data).forEach(function(key) {
			params.append(key, data[key]);
		});

		fetch(url, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: params.toString()
		})
		.then(function(res) { return res.json(); })
		.then(function(response) {
			if (callbacks.success) {
				callbacks.success(response);
			}
		})
		.catch(function(err) {
			if (callbacks.error) {
				callbacks.error(err);
			}
		})
		.finally(function() {
			if (callbacks.complete) {
				callbacks.complete();
			}
		});
	}

	var StaffDashboard = {
		chart: null,
		chartData: null,
		currentRange: '7days',
		currentMonth: new Date().getMonth() + 1,
		currentYear: new Date().getFullYear(),
		locationId: 0,

		/**
		 * Initialize dashboard functionality.
		 */
		init: function() {
			this.mountLocationPicker();
			this.initAnimations();
			this.initChart();
			this.bindEvents();
			this.setupAutoRefresh();
		},

		/**
		 * Initialize entry animations for dashboard elements.
		 */
		initAnimations: function() {
			// Animate progress bars
			document.querySelectorAll('.wca-kpi-progress-bar').forEach(function(bar) {
				var progress = bar.dataset.progress || 0;
				setTimeout(function() {
					bar.style.width = progress + '%';
				}, 100);
			});

			// Animate week bars
			document.querySelectorAll('.wca-week-bar').forEach(function(bar) {
				var height = bar.dataset.height || 0;
				setTimeout(function() {
					bar.style.height = Math.max(4, height) + '%';
				}, 200);
			});

			// Animate product bars
			document.querySelectorAll('.wca-product-bar-fill').forEach(function(bar) {
				var width = bar.dataset.width || 0;
				setTimeout(function() {
					bar.style.width = width + '%';
				}, 300);
			});
		},

		/**
		 * Initialize the appointments chart.
		 */
		initChart: function() {
			var canvas = document.getElementById('wca-appointments-chart');
			if (!canvas) {
				return;
			}

			// Load chart data
			this.loadChartData(this.currentRange);
		},

		/**
		 * Load chart data via AJAX.
		 */
		loadChartData: function(range) {
			var self = this;

			if (!wcaStaffDashboard || !wcaStaffDashboard.ajaxUrl) {
				this.renderFallbackChart();
				return;
			}

			ajaxPost(wcaStaffDashboard.ajaxUrl, {
				action: 'wca_staff_dashboard_chart_data',
				nonce: wcaStaffDashboard.nonce,
				range: range,
				location_id: this.locationId
			}, {
				success: function(response) {
					if (response.success && response.data) {
						self.chartData = response.data;
						self.renderChart(response.data);
					} else {
						self.renderFallbackChart();
					}
				},
				error: function() {
					self.renderFallbackChart();
				}
			});
		},

		/**
		 * Render the chart with data.
		 */
		renderChart: function(data) {
			var canvas = document.getElementById('wca-appointments-chart');
			if (!canvas) {
				return;
			}

			var ctx = canvas.getContext('2d');
			var self = this;

			// Destroy existing chart
			if (this.chart) {
				this.chart.destroy();
			}

			// Update totals display
			this.updateChartTotals(data);

			// Get computed styles for theming
			var styles = getComputedStyle(document.documentElement);
			var primaryColor = styles.getPropertyValue('--wca-primary').trim() || '#2271b1';
			var successColor = styles.getPropertyValue('--wca-success').trim() || '#00a32a';

			// Check if Chart.js is available
			if (typeof Chart === 'undefined') {
				this.renderCanvasChart(ctx, data, primaryColor, successColor);
				return;
			}

			// Build datasets
			var datasets = [{
				label: wcaStaffDashboard.i18n.appointments || 'Appointments',
				data: data.appointments,
				borderColor: primaryColor,
				backgroundColor: this.hexToRgba(primaryColor, 0.1),
				borderWidth: 2,
				fill: true,
				tension: 0.4,
				pointRadius: 3,
				pointHoverRadius: 5,
				pointBackgroundColor: primaryColor
			}];

			// Add revenue dataset if available
			if (data.revenue && data.revenue.length > 0 && wcaStaffDashboard.canViewEarnings) {
				datasets.push({
					label: wcaStaffDashboard.i18n.revenue || 'Revenue',
					data: data.revenue,
					borderColor: successColor,
					backgroundColor: 'transparent',
					borderWidth: 2,
					borderDash: [5, 5],
					fill: false,
					tension: 0.4,
					pointRadius: 3,
					pointHoverRadius: 5,
					pointBackgroundColor: successColor,
					yAxisID: 'y1'
				});
			}

			this.chart = new Chart(ctx, {
				type: 'line',
				data: {
					labels: data.labels,
					datasets: datasets
				},
				options: {
					responsive: true,
					maintainAspectRatio: false,
					interaction: {
						intersect: false,
						mode: 'index'
					},
					plugins: {
						legend: {
							display: datasets.length > 1,
							position: 'top',
							align: 'center',
							labels: {
								usePointStyle: true,
								padding: 20,
								font: {
									size: 12
								}
							}
						},
						tooltip: {
							backgroundColor: 'rgba(0, 0, 0, 0.8)',
							padding: 12,
							titleFont: {
								size: 13,
								weight: '600'
							},
							bodyFont: {
								size: 12
							},
							callbacks: {
								label: function(context) {
									var label = context.dataset.label || '';
									var value = context.parsed.y;
									if (context.datasetIndex === 1 && wcaStaffDashboard.currency) {
										value = self.formatCurrency(value);
									}
									return label + ': ' + value;
								}
							}
						}
					},
					scales: {
						x: {
							grid: {
								display: false
							},
							ticks: {
								font: {
									size: 11
								},
								maxRotation: 0,
								autoSkip: true,
								maxTicksLimit: 10
							}
						},
						y: {
							beginAtZero: true,
							grid: {
								color: 'rgba(0, 0, 0, 0.05)'
							},
							ticks: {
								font: {
									size: 11
								},
								stepSize: 1,
								precision: 0
							}
						},
						y1: {
							display: datasets.length > 1,
							position: 'right',
							beginAtZero: true,
							grid: {
								drawOnChartArea: false
							},
							ticks: {
								font: {
									size: 11
								},
								callback: function(value) {
									return self.formatCurrency(value);
								}
							}
						}
					}
				}
			});
		},

		/**
		 * Render a simple canvas chart when Chart.js is not available.
		 */
		renderCanvasChart: function(ctx, data, primaryColor, successColor) {
			var canvas = ctx.canvas;
			var width = canvas.width;
			var height = canvas.height;
			var padding = 40;
			var chartWidth = width - (padding * 2);
			var chartHeight = height - (padding * 2);

			// Clear canvas
			ctx.clearRect(0, 0, width, height);

			if (!data.appointments || data.appointments.length === 0) {
				ctx.fillStyle = '#646970';
				ctx.font = '14px -apple-system, BlinkMacSystemFont, sans-serif';
				ctx.textAlign = 'center';
				ctx.fillText(wcaStaffDashboard.i18n.noData || 'No data available', width / 2, height / 2);
				return;
			}

			var maxValue = Math.max(...data.appointments, 1);
			var points = data.appointments.length;
			var stepX = chartWidth / (points - 1 || 1);

			// Draw grid lines
			ctx.strokeStyle = 'rgba(0, 0, 0, 0.05)';
			ctx.lineWidth = 1;
			for (var i = 0; i <= 4; i++) {
				var y = padding + (chartHeight / 4) * i;
				ctx.beginPath();
				ctx.moveTo(padding, y);
				ctx.lineTo(width - padding, y);
				ctx.stroke();
			}

			// Draw line chart
			ctx.strokeStyle = primaryColor;
			ctx.lineWidth = 2;
			ctx.beginPath();

			data.appointments.forEach(function(value, index) {
				var x = padding + (stepX * index);
				var y = padding + chartHeight - ((value / maxValue) * chartHeight);

				if (index === 0) {
					ctx.moveTo(x, y);
				} else {
					ctx.lineTo(x, y);
				}
			});

			ctx.stroke();

			// Draw points
			ctx.fillStyle = primaryColor;
			data.appointments.forEach(function(value, index) {
				var x = padding + (stepX * index);
				var y = padding + chartHeight - ((value / maxValue) * chartHeight);

				ctx.beginPath();
				ctx.arc(x, y, 4, 0, Math.PI * 2);
				ctx.fill();
			});

			// Draw x-axis labels (simplified)
			ctx.fillStyle = '#646970';
			ctx.font = '11px -apple-system, BlinkMacSystemFont, sans-serif';
			ctx.textAlign = 'center';

			var labelStep = Math.ceil(points / 7);
			data.labels.forEach(function(label, index) {
				if (index % labelStep === 0 || index === points - 1) {
					var x = padding + (stepX * index);
					ctx.fillText(label, x, height - 10);
				}
			});
		},

		/**
		 * Update chart totals display.
		 */
		updateChartTotals: function(data) {
			var totals = document.getElementById('wca-chart-totals');
			var totalAppointments = document.getElementById('wca-total-appointments');
			var totalRevenue = document.getElementById('wca-total-revenue');

			if (data.total_appointments !== undefined) {
				if (totals) {
					totals.style.display = '';
				}
				if (totalAppointments) {
					totalAppointments.textContent = data.total_appointments;
				}

				if (data.total_revenue !== undefined && wcaStaffDashboard.canViewEarnings && totalRevenue) {
					totalRevenue.textContent = this.formatCurrency(data.total_revenue);
				}
			}
		},

		/**
		 * Load monthly heatmap data.
		 */
		loadMonthlyHeatmap: function(month, year) {
			var self = this;

			if (!wcaStaffDashboard || !wcaStaffDashboard.ajaxUrl) {
				return;
			}

			ajaxPost(wcaStaffDashboard.ajaxUrl, {
				action: 'wca_staff_dashboard_monthly_heatmap',
				nonce: wcaStaffDashboard.nonce,
				month: month,
				year: year,
				location_id: this.locationId
			}, {
				success: function(response) {
					if (response.success && response.data) {
						self.updateHeatmap(response.data);
					}
				},
				error: function() {
					console.error('Failed to load monthly heatmap data');
				}
			});
		},

		/**
		 * Update heatmap with new data.
		 */
		updateHeatmap: function(data) {
			var cells = document.getElementById('wca-heatmap-cells');
			var label = document.getElementById('wca-month-label');
			var occupancy = document.getElementById('wca-occupancy-rate');

			// Update month label
			if (label) {
				label.textContent = data.month_label;
			}

			// Update occupancy rate
			if (occupancy) {
				occupancy.textContent = wcaStaffDashboard.i18n.occupancyRate.replace('%d%%', data.occupancy + '%');
			}

			if (!cells) {
				return;
			}

			// Clear and rebuild heatmap cells
			cells.innerHTML = '';

			// Add empty cells for days before the first of the month
			var firstDate = Object.keys(data.heatmap)[0];
			var firstWeekday = data.heatmap[firstDate].weekday;

			// Calculate empty cells needed based on WordPress week start day
			// This should match the PHP calculation
			var startOfWeek = parseInt(wcaStaffDashboard.startOfWeek || 0); // Default to Sunday if not set
			var adjustedWeekday = (firstWeekday - startOfWeek + 7) % 7;

			for (var i = 0; i < adjustedWeekday; i++) {
				cells.insertAdjacentHTML('beforeend', '<span class="wca-heatmap-cell wca-heatmap-empty"></span>');
			}

			// Add heatmap cells (is_today from server staff TZ, not browser UTC).
			var self = this;
			Object.keys(data.heatmap).forEach(function(date) {
				var cellData = data.heatmap[date];
				var isToday = !!cellData.is_today;
				var dateObj = new Date(date);
				var dateLabel = self.formatDate(dateObj);

				var cell = document.createElement('span');
				cell.className = 'wca-heatmap-cell' + (isToday ? ' wca-heatmap-today' : '');
				cell.dataset.level = cellData.intensity;
				cell.dataset.date = date;
				cell.title = dateLabel + ': ' + cellData.count + ' appointments';
				cell.innerHTML = '<span class="wca-heatmap-day">' + cellData.day + '</span>';
				cells.appendChild(cell);
			});
		},

		/**
		 * Render fallback when no data.
		 */
		renderFallbackChart: function() {
			var canvas = document.getElementById('wca-appointments-chart');
			if (!canvas) {
				return;
			}

			var ctx = canvas.getContext('2d');
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.fillStyle = '#646970';
			ctx.font = '14px -apple-system, BlinkMacSystemFont, sans-serif';
			ctx.textAlign = 'center';
			ctx.fillText(wcaStaffDashboard.i18n.noData || 'No data available', canvas.width / 2, canvas.height / 2);
		},

				/**
		 * Location control beside Dashboard title: none / static / filter menu.
		 */
		mountLocationPicker: function() {
			var locations = (typeof wcaStaffDashboard !== 'undefined' && wcaStaffDashboard.locations) || [];
			if (!locations.length) {
				return;
			}

			var h1 = document.querySelector('#wpbody-content .wrap > h1');
			if (!h1) {
				return;
			}

			h1.classList.add('wp-heading-inline');

			var root = document.createElement('div');
			root.className = 'wca-dash-location';
			var icon = this.el('span', 'dashicons dashicons-location');
			var label = this.el('span', 'wca-dash-location__label');

			if (locations.length === 1) {
				root.className += ' wca-dash-location--static';
				var staticEl = this.el('span', 'wca-dash-location__toggle');
				label.textContent = locations[0].name || '';
				staticEl.appendChild(icon);
				staticEl.appendChild(label);
				root.appendChild(staticEl);
				this.attachBesideTitle(h1, root);
				return;
			}

			var toggle = this.el('button', 'wca-dash-location__toggle');
			toggle.type = 'button';
			toggle.id = 'wca-dash-location-toggle';
			toggle.setAttribute('aria-expanded', 'false');
			toggle.setAttribute('aria-haspopup', 'listbox');
			toggle.setAttribute('aria-controls', 'wca-dash-location-menu');
			toggle.setAttribute(
				'aria-label',
				(wcaStaffDashboard.i18n && wcaStaffDashboard.i18n.locationFilter) || 'Filter by location'
			);

			var caret = this.el('span', 'dashicons dashicons-arrow-down-alt2');
			toggle.appendChild(icon);
			toggle.appendChild(label);
			toggle.appendChild(caret);

			var menu = this.el('ul', 'wca-dash-location__menu');
			menu.id = 'wca-dash-location-menu';
			menu.setAttribute('role', 'listbox');
			menu.hidden = true;
			locations.forEach(function(loc) {
				var item = document.createElement('li');
				item.setAttribute('role', 'option');
				item.setAttribute('data-location-id', String(loc.id));
				item.textContent = loc.name;
				menu.appendChild(item);
			});

			root.appendChild(toggle);
			root.appendChild(menu);
			this.attachBesideTitle(h1, root);

			this._locationToggle = toggle;
			this._locationLabel = label;
			this._locationMenu = menu;
			this.syncLocationPicker();
		},

		el: function(tag, className) {
			var node = document.createElement(tag);
			if (className) {
				node.className = className;
			}
			if (tag === 'span' && className && className.indexOf('dashicons') !== -1) {
				node.setAttribute('aria-hidden', 'true');
			}
			return node;
		},

		attachBesideTitle: function(h1, root) {
			h1.insertAdjacentElement('afterend', root);
			var hr = h1.parentNode.querySelector(':scope > hr.wp-header-end');
			if (!hr) {
				hr = document.createElement('hr');
				hr.className = 'wp-header-end';
			}
			root.insertAdjacentElement('afterend', hr);
		},

		setLocationMenuOpen: function(open) {
			if (!this._locationToggle || !this._locationMenu) {
				return;
			}
			this._locationToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			this._locationToggle.classList.toggle('is-open', open);
			this._locationMenu.hidden = !open;
		},

		syncLocationPicker: function() {
			if (!this._locationMenu || !this._locationLabel) {
				return;
			}
			var self = this;
			this._locationMenu.querySelectorAll('[role="option"]').forEach(function(opt) {
				var selected = (parseInt(opt.getAttribute('data-location-id'), 10) || 0) === self.locationId;
				opt.classList.toggle('is-selected', selected);
				opt.setAttribute('aria-selected', selected ? 'true' : 'false');
				if (selected) {
					self._locationLabel.textContent = opt.textContent;
				}
			});
		},

		bindEvents: function() {
			var self = this;

			document.addEventListener('keydown', function(e) {
				if (e.key === 'Escape') {
					self.setLocationMenuOpen(false);
				}
			});

			document.addEventListener('click', function(e) {
				var locToggle = e.target.closest('button.wca-dash-location__toggle');
				if (locToggle) {
					e.preventDefault();
					var open = locToggle.getAttribute('aria-expanded') === 'true';
					self.setLocationMenuOpen(!open);
					return;
				}

				var locOpt = e.target.closest('.wca-dash-location__menu [role="option"]');
				if (locOpt) {
					e.preventDefault();
					var locationId = parseInt(locOpt.getAttribute('data-location-id'), 10) || 0;
					self.setLocationMenuOpen(false);
					if (locationId === self.locationId) {
						return;
					}
					self.locationId = locationId;
					self.syncLocationPicker();
					self.refreshStats(function() {
						self.loadChartData(self.currentRange);
						self.loadMonthlyHeatmap(self.currentMonth, self.currentYear);
					});
					return;
				}

				if (self._locationMenu && !self._locationMenu.hidden && !e.target.closest('.wca-dash-location')) {
					self.setLocationMenuOpen(false);
				}

				var rangeBtn = e.target.closest('.wca-chart-range');
				if (rangeBtn) {
					e.preventDefault();
					var range = rangeBtn.dataset.range;
					if (range === self.currentRange) {
						return;
					}
					document.querySelectorAll('.wca-chart-range').forEach(function(btn) {
						btn.classList.remove('active');
					});
					rangeBtn.classList.add('active');
					self.currentRange = range;
					self.loadChartData(range);
					return;
				}

				var refreshBtn = e.target.closest('.wca-refresh-stats');
				if (refreshBtn) {
					e.preventDefault();
					if (refreshBtn.classList.contains('loading')) {
						return;
					}
					refreshBtn.classList.add('loading');
					self.refreshStats(function() {
						refreshBtn.classList.remove('loading');
					});
					return;
				}

				if (e.target.closest('#wca-month-prev')) {
					e.preventDefault();
					self.currentMonth--;
					if (self.currentMonth < 1) {
						self.currentMonth = 12;
						self.currentYear--;
					}
					self.loadMonthlyHeatmap(self.currentMonth, self.currentYear);
					return;
				}

				if (e.target.closest('#wca-month-next')) {
					e.preventDefault();
					self.currentMonth++;
					if (self.currentMonth > 12) {
						self.currentMonth = 1;
						self.currentYear++;
					}
					self.loadMonthlyHeatmap(self.currentMonth, self.currentYear);
				}
			});
		},

		/**
		 * Setup auto-refresh for stats.
		 */
		setupAutoRefresh: function() {
			var refreshInterval = 60000; // 60 seconds
			var self = this;

			setInterval(function() {
				self.refreshStats();
			}, refreshInterval);
		},

		/**
		 * Refresh dashboard stats via AJAX.
		 *
		 * Fetches fresh server-rendered HTML for all widgets and replaces
		 * their contents, then reloads the chart and heatmap.
		 */
		refreshStats: function(callback) {
			var self = this;

			if (!wcaStaffDashboard || !wcaStaffDashboard.ajaxUrl) {
				if (callback) callback();
				return;
			}

			ajaxPost(wcaStaffDashboard.ajaxUrl, {
				action: 'wca_staff_dashboard_refresh_widgets',
				nonce: wcaStaffDashboard.nonce,
				location_id: this.locationId
			}, {
				success: function(response) {
					if (response.success && response.data) {
						self.replaceWidgetHtml(response.data);
					}
				},
				error: function(err) {
					console.error('Dashboard refresh error:', err);
				},
				complete: function() {
					if (callback) callback();
				}
			});
		},

		/**
		 * Replace widget inner HTML with fresh server-rendered content.
		 *
		 * @param {Object} html Map of widget key to rendered HTML string.
		 */
		replaceWidgetHtml: function(html) {
			var widgetMap = {
				'welcome':      '#wca_staff_welcome .inside',
				'upcoming':     '#wca_staff_upcoming .inside',
				'insights':     '#wca_staff_insights .inside',
				'week':         '#wca_staff_week .inside',
				'heatmap':      '#wca_staff_heatmap .inside',
				'top-products': '#wca_staff_top_products .inside'
			};

			var self = this;

			Object.keys(widgetMap).forEach(function(key) {
				if (!html[key]) {
					return;
				}
				var container = document.querySelector(widgetMap[key]);
				if (container) {
					container.innerHTML = html[key];
				}
			});

			// Re-run entry animations for the freshly injected content.
			this.initAnimations();

			// Reload the chart with the current range.
			this.loadChartData(this.currentRange);

			// Reset heatmap navigation to current month (matches server-rendered HTML).
			this.currentMonth = new Date().getMonth() + 1;
			this.currentYear = new Date().getFullYear();
		},

		/**
		 * Format currency value.
		 */
		formatCurrency: function(value) {
			if (!wcaStaffDashboard.currency) {
				return value;
			}

			var symbol = wcaStaffDashboard.currency.symbol || '$';
			var position = wcaStaffDashboard.currency.position || 'left';
			var formatted = parseFloat(value).toFixed(2);

			if (position === 'left' || position === 'left_space') {
				return symbol + (position === 'left_space' ? ' ' : '') + formatted;
			} else {
				return formatted + (position === 'right_space' ? ' ' : '') + symbol;
			}
		},

		/**
		 * Convert hex color to rgba.
		 */
		hexToRgba: function(hex, alpha) {
			hex = hex.replace('#', '');

			if (hex.length === 3) {
				hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
			}

			var r = parseInt(hex.substring(0, 2), 16);
			var g = parseInt(hex.substring(2, 4), 16);
			var b = parseInt(hex.substring(4, 6), 16);

			return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + alpha + ')';
		},

		/**
		 * Format date for display.
		 */
		formatDate: function(date) {
			var months = [
				'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
				'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
			];
			return months[date.getMonth()] + ' ' + date.getDate();
		}
	};

	// Initialize when document is ready
	document.addEventListener('DOMContentLoaded', function() {
		StaffDashboard.init();
	});

	// Expose globally for potential external use
	window.WCAStaffDashboard = StaffDashboard;

})();
