/* globals wc_appointments_my_account_params */

document.addEventListener( 'DOMContentLoaded', function() {
	'use strict';

	var params = wc_appointments_my_account_params || {};
	var cancelButtons = document.getElementsByClassName( 'woocommerce-button cancel' );

	for ( var i = 0, l = cancelButtons.length; i < l; i++ ) {
		cancelButtons[ i ].addEventListener( 'click', function( ev ) {
			if ( ! confirm( params.i18n_confirmation ) ) {
				ev.preventDefault();
			}
		} );
	}

	var countdowns = document.querySelectorAll( '.wca-join-countdown' );
	if ( ! countdowns.length ) {
		return;
	}

	function tick() {
		var now = Math.floor( Date.now() / 1000 );
		for ( var j = 0; j < countdowns.length; j++ ) {
			var el = countdowns[ j ];
			var start = parseInt( el.getAttribute( 'data-start' ), 10 ) || 0;
			var end = parseInt( el.getAttribute( 'data-end' ), 10 ) || 0;
			if ( ! start || ! end ) {
				continue;
			}
			if ( now >= end ) {
				el.textContent = params.i18n_ended || '';
			} else if ( now >= start ) {
				el.textContent = params.i18n_in_progress || '';
			}
			// else keep PHP "Starts in …"
		}
	}

	tick();
	setInterval( tick, 30000 );
} );
