/* globals wca_get_querystring, wcaShared, wca_clear_date_selection, wca_update_selection_info */
wcaShared.whenDepsReady(
	function() {
		return typeof jQuery !== 'undefined' && typeof jQuery.fn.select2 === 'function';
	},
	function() {
		jQuery( function( $ ) {
	'use strict';

	if ( Array.isArray ) {
		$.isArray = Array.isArray;
	}

	var wc_appointments_staff_picker = {
		init: function() {
			$( 'body' ).on( 'change', '#wc_appointments_field_staff', this.select_staff );
			$( 'body' ).on( 'change', 'select[id^="wc_appointments_field_resource"]', this.select_staff );
			$( 'body' ).on( 'change', '#wc_appointments_field_location', this.on_location );

			$( '.wc-appointments-appointment-form' ).each( function() {
				var form = $( this ).closest( 'form' );

				form.find( '#wc_appointments_field_staff, select[id^="wc_appointments_field_resource"]' ).each( function() {
					var $field = $( this );
					if ( $field.hasClass( 'select2-hidden-accessible' ) ) {
						return;
					}
					var $select = $field.select2( {
						escapeMarkup: function( m ) { return m; },
						templateResult: wc_appointments_staff_picker.template_staff,
						templateSelection: function( state ) { return state.text || ''; } // SelectWoo text-only; avatar via paint().
					} );
					wc_appointments_staff_picker.paint( $field );
					$field.on( 'change', function() {
						wc_appointments_staff_picker.paint( $field );
					} );
					var staffQs = wca_get_querystring( 'staff' );
					if ( $field.is( '#wc_appointments_field_staff' ) && null !== staffQs && staffQs !== $select.val() ) {
						$select.val( staffQs ).trigger( 'change' );
					}
				} );

				var location_field = wc_appointments_staff_picker.location_field( form );
				if ( location_field.length && ! location_field.hasClass( 'select2-hidden-accessible' ) ) {
					location_field.select2( { width: '100%' } );
					var locQs = wca_get_querystring( 'location' );
					if ( null !== locQs && locQs !== location_field.val() ) {
						location_field.val( locQs ).trigger( 'change', [ { fromQuerystring: true } ] );
					}
				}

				wc_appointments_staff_picker.set_location_prompt( form );
				wc_appointments_staff_picker.filter_resources( form );
			} );
		},

		location_field: function( form ) {
			var $loc = form.find( '#wc_appointments_field_location' );
			return $loc.length ? $loc : form.find( '.wc_appointment_field_location select' ).first();
		},

		set_location_prompt: function( form ) {
			var $loc = wc_appointments_staff_picker.location_field( form );
			var $ph  = form.find( '.wc-appointments-selection-placeholder' );
			var msg  = $loc.attr( 'data-gate-msg' );
			if ( ! $loc.length || ! $ph.length || ! msg ) {
				return;
			}
			if ( ! $ph.data( 'wcaDefault' ) ) {
				$ph.data( 'wcaDefault', $.trim( $ph.text() ) );
			}
			var blocked = ! ( parseInt( $loc.val(), 10 ) > 0 );
			$ph.text( blocked ? msg : $ph.data( 'wcaDefault' ) );
			if ( blocked && typeof wca_update_selection_info === 'function' ) {
				wca_update_selection_info( form, null );
			}
		},

		// Rebuild each resource <select> for the venue (pool cached; no disabled/gray options) (#1472).
		filter_resources: function( form ) {
			var $wraps = form.find( '.wc_appointment_field_resource' );
			if ( ! $wraps.length ) {
				return;
			}
			var $loc = wc_appointments_staff_picker.location_field( form );
			var lid  = $loc.length ? ( parseInt( $loc.val(), 10 ) || 0 ) : -1;

			$wraps.each( function() {
				var $wrap  = $( this );
				var $res   = $wrap.find( 'select[id^="wc_appointments_field_resource"]' ).first();
				if ( ! $res.length ) {
					return;
				}
				var before = $res.val();

				if ( ! $res.data( 'wcaResourcePool' ) ) {
					$res.data( 'wcaResourcePool', $res.children( 'option' ).clone( true ).get() );
				}

				// No venue yet → empty (hide). Else shared (0) or matching location; lid < 0 = no location field.
				var next = ( $loc.length && ! lid ) ? [] : $.map( $res.data( 'wcaResourcePool' ), function( el ) {
					var optLid = el.getAttribute( 'data-location-id' );
					return ( lid < 0 || '0' === optLid || String( lid ) === optLid ) ? el.cloneNode( true ) : null;
				} );

				$res.empty().append( next );
				if ( ! next.length ) {
					$wrap.hide();
					$res.prop( 'required', false );
					if ( before ) {
						$res.val( '' ).trigger( 'change' );
					}
					return;
				}

				$wrap.show();
				$res.prop( 'required', true ).val( before );
				if ( ! $res.val() ) {
					$res.val( next[0].value );
				}
				if ( String( before || '' ) !== String( $res.val() || '' ) ) {
					$res.trigger( 'change' );
				} else {
					wc_appointments_staff_picker.paint( $res );
				}
			} );
		},

		on_location: function( event, meta ) {
			var form = $( this ).closest( 'form' );
			if ( ! ( meta && meta.fromQuerystring ) ) {
				if ( typeof wca_clear_date_selection === 'function' ) {
					wca_clear_date_selection( form );
				}
				form.find( '.form-field-month .picker li' ).removeClass( 'selected selected-month' );
				form.find( '.form-field-month input' ).val( '' );
			}
			wc_appointments_staff_picker.set_location_prompt( form );
			wc_appointments_staff_picker.filter_resources( form );
			form.triggerHandler( 'location-selected' );
		},

		template_staff: function( state ) {
			if ( ! state.id ) {
				return state.text;
			}
			var url = state.element ? ( $( state.element ).attr( 'data-avatar' ) || '' ) : '';
			return ( url ? '<img class="staff-avatar" src="' + url + '" alt="" />' : '' ) + state.text;
		},

		// SelectWoo selection is text-only; rewrite after it paints (defer past its sync update).
		paint: function( $field ) {
			window.setTimeout( function() {
				var $opt = $field.find( 'option:selected' );
				var $el  = $field.next( '.select2-container' ).find( '.select2-selection__rendered' );
				if ( $el.length && $opt.val() ) {
					$el.html( wc_appointments_staff_picker.template_staff( { id: $opt.val(), text: $.trim( $opt.text() ), element: $opt[0] } ) );
				}
			}, 0 );
		},

		select_staff: function() {
			var form = $( this ).closest( 'form' );
			form.find( '.wc-appointments-appointment-form-button' ).prop( 'disabled', true );
			form.triggerHandler( 'staff-selected' );
		}
	};

	wc_appointments_staff_picker.init();
} );
	},
	'staff-picker'
);
