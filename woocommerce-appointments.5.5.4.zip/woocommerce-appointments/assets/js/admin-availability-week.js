/**
 * Shared Week at a glance (hub + product Availability tab).
 * window.wcaAvailabilityWeek.weekHtml( opts )
 * Product tab: localize wcaProductAvailabilityWeek before this file.
 */
( function( window ) {
	'use strict';

	var LEVEL = { global: 1, product: 2, location: 3, resource: 4, staff: 5 };
	var DAYS = [ '1', '2', '3', '4', '5', '6', '7' ];

	function esc( s ) {
		return String( s == null ? '' : s ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' ).replace( /"/g, '&quot;' );
	}

	function hmMin( s ) {
		var m = String( s || '' ).match( /^(\d{1,2}):(\d{2})/ );
		return m ? ( +m[1] ) * 60 + ( +m[2] ) : -1;
	}

	function isGlanceType( type ) {
		return 'time' === type || 'time:range' === type || 'days' === type || 'months' === type || 'weeks' === type || /^time:[1-7]$/.test( type );
	}

	function inWrap( n, a, b ) {
		return a <= b ? ( n >= a && n <= b ) : ( n >= a || n <= b );
	}

	function civilNow( r ) {
		var a = parseInt( r.from, 10 ), b = parseInt( r.to, 10 );
		if ( !a || !b ) return false;
		if ( 'months' === r.type ) return inWrap( new Date().getMonth() + 1, a, b );
		if ( 'weeks' !== r.type ) return false;
		var d = new Date(), utc = new Date( Date.UTC( d.getFullYear(), d.getMonth(), d.getDate() ) );
		var dayNum = utc.getUTCDay() || 7;
		utc.setUTCDate( utc.getUTCDate() + 4 - dayNum );
		return inWrap( Math.ceil( ( ( ( utc - Date.UTC( utc.getUTCFullYear(), 0, 1 ) ) / 86400000 ) + 1 ) / 7 ), a, b );
	}

	function dayKeys( r ) {
		if ( 'months' === r.type || 'weeks' === r.type ) return civilNow( r ) ? DAYS : [];
		if ( 'time' === r.type ) return DAYS;
		if ( 'days' === r.type ) {
			var a = parseInt( r.from, 10 ), b = parseInt( r.to, 10 );
			if ( !a || !b ) return [];
			var keys = [];
			for ( var k = Math.min( a, b ); k <= Math.max( a, b ); k++ ) keys.push( String( k ) );
			return keys;
		}
		var m = String( r.type || '' ).match( /^time:(\d)$/ );
		return m ? [ m[1] ] : [];
	}

	function intervals( r, daily ) {
		if ( 'days' === r.type || 'months' === r.type || 'weeks' === r.type || ( daily && 'yes' === r.available ) ) return [ [ 0, 1440 ] ];
		var a = hmMin( r.from ), b = hmMin( r.to );
		if ( 0 > a || 0 > b ) return [];
		return a < b ? [ [ a, b ] ] : [ [ a, 1440 ], [ 0, b ] ];
	}

	function mergeIv( list ) {
		if ( !list.length ) return [];
		var sorted = list.slice().sort( function( x, y ) { return x[0] - y[0] || x[1] - y[1]; } );
		var out = [ sorted[0].slice() ];
		for ( var i = 1; i < sorted.length; i++ ) {
			var cur = sorted[i], last = out[ out.length - 1 ];
			if ( cur[0] <= last[1] ) last[1] = Math.max( last[1], cur[1] );
			else out.push( cur.slice() );
		}
		return out;
	}

	function subtractIv( opens, closeds ) {
		var result = mergeIv( opens );
		mergeIv( closeds ).forEach( function( c ) {
			var next = [];
			result.forEach( function( o ) {
				if ( c[1] <= o[0] || c[0] >= o[1] ) next.push( o );
				else {
					if ( o[0] < c[0] ) next.push( [ o[0], c[0] ] );
					if ( c[1] < o[1] ) next.push( [ c[1], o[1] ] );
				}
			} );
			result = next;
		} );
		return result;
	}

	function paint( strokes ) {
		var avail = [];
		// Lowest override first (last-writer-wins). At equal priority+level, Closed
		// paints after Open so Unavailable rows are not reopened by earlier Open hours.
		strokes.slice().sort( function( x, y ) {
			if ( x.priority !== y.priority ) return y.priority - x.priority;
			if ( x.level !== y.level ) return x.level - y.level;
			if ( x.open !== y.open ) return x.open ? -1 : 1;
			return y.order - x.order;
		} ).forEach( function( s ) {
			avail = s.open ? mergeIv( avail.concat( s.intervals ) ) : subtractIv( avail, s.intervals );
		} );
		return avail;
	}

	function fmt( m ) {
		return String( Math.floor( m / 60 ) ).padStart( 2, '0' ) + ':' + String( m % 60 ).padStart( 2, '0' );
	}

	function weekOrder( startOfWeek ) {
		var sow = parseInt( startOfWeek, 10 );
		if ( isNaN( sow ) || 0 > sow || 6 < sow ) sow = 1;
		var start = 0 === sow ? 7 : sow, order = [];
		for ( var i = 0; 7 > i; i++ ) order.push( String( ( ( start - 1 + i ) % 7 ) + 1 ) );
		return order;
	}

	function weekHtml( opts ) {
		opts = opts || {};
		var layer = opts.layer || 'global', daily = !!opts.daily, dayShort = opts.dayShort || {}, i18n = opts.i18n || {};
		var byDay = { '1': [], '2': [], '3': [], '4': [], '5': [], '6': [], '7': [] };

		function add( list, levelName ) {
			var level = LEVEL[levelName] || 1;
			( list || [] ).forEach( function( r, order ) {
				if ( 'google' === r.source || !isGlanceType( r.type ) ) return;
				var ivs = intervals( r, daily );
				if ( !ivs.length ) return;
				var p = parseInt( r.priority, 10 );
				var stroke = { priority: isNaN( p ) ? 10 : p, level: level, order: order, open: 'yes' === r.available, intervals: ivs };
				dayKeys( r ).forEach( function( key ) { byDay[key].push( stroke ); } );
			} );
		}

		add( opts.rows, layer );
		if ( 'global' !== layer ) add( opts.globalRows, 'global' );
		if ( 'resource' === layer && opts.locationRows && opts.locationRows.length ) add( opts.locationRows, 'location' );

		var order = weekOrder( opts.startOfWeek );
		if ( !order.some( function( key ) { return byDay[key].length; } ) ) return '';

		return '<div class="wca-week" aria-label="' + esc( i18n.weekAria || 'Open days' ) + '">' + order.map( function( key ) {
			var avail = paint( byDay[key] ), labels;
			if ( !avail.length ) labels = '<div class="wca-week__t">' + esc( i18n.closed || 'Closed' ) + '</div>';
			else if ( 1 === avail.length && !avail[0][0] && 1440 === avail[0][1] ) labels = '<div class="wca-week__t">' + esc( i18n.allDay || 'All day' ) + '</div>';
			else labels = avail.map( function( iv ) { return '<div class="wca-week__t">' + esc( fmt( iv[0] ) + '-' + fmt( iv[1] ) ) + '</div>'; } ).join( '' );
			return '<div class="wca-week__d' + ( avail.length ? ' is-open' : '' ) + '"><div class="wca-week__n">' + esc( dayShort[key] || key ) + '</div>' + labels + '</div>';
		} ).join( '' ) + '</div>';
	}

	window.wcaAvailabilityWeek = { weekHtml: weekHtml };

	var boot = window.wcaProductAvailabilityWeek;
	if ( boot && boot.mount ) {
		document.addEventListener( 'DOMContentLoaded', function() {
			var el = document.querySelector( boot.mount );
			if ( !el ) return;
			el.innerHTML = weekHtml( {
				rows: boot.productRows || [],
				globalRows: boot.globalRows || [],
				layer: 'product',
				daily: !!boot.daily,
				dayShort: boot.dayShort,
				startOfWeek: boot.startOfWeek,
				i18n: boot.i18n || {}
			} );
		} );
	}
} )( window );
