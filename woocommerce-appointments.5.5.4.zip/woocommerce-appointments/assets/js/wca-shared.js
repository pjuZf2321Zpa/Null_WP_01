/** Cross-surface utilities — enqueued as wca-shared-js. */
( function ( window ) {
	'use strict';
	if ( window.wcaShared ) {
		return;
	}

	function pad( n ) {
		return ( n < 10 ? '0' : '' ) + n;
	}

	function debounce( fn, wait ) {
		var t;
		return function () {
			var ctx = this, args = arguments;
			clearTimeout( t );
			t = setTimeout( function () { fn.apply( ctx, args ); }, wait );
		};
	}

	function qs( el, sel ) {
		return el ? el.querySelector( sel ) : null;
	}

	function qsa( el, sel ) {
		return el ? Array.prototype.slice.call( el.querySelectorAll( sel ) ) : [];
	}

	function setDisabled( el, on ) {
		if ( el ) {
			el.disabled = !!on;
		}
	}

	function toggleLoadingBar( el, active ) {
		var bar;
		if ( ! el ) {
			return;
		}
		bar = qs( el, '.wca-loading-bar' );
		if ( ! bar ) {
			bar = document.createElement( 'div' );
			bar.className = 'wca-loading-bar';
			bar.setAttribute( 'aria-hidden', 'true' );
			el.appendChild( bar );
		}
		bar.classList.toggle( 'is-active', !!active );
	}

	function i18n( dict, key, fb, reps ) {
		var msg = ( dict && dict[ key ] ) || fb || key;
		if ( null == reps ) {
			return msg;
		}
		if ( 'number' === typeof reps ) {
			return msg.replace( '%d', String( reps ) );
		}
		Object.keys( reps ).forEach( function ( k ) {
			msg = msg.split( k ).join( String( reps[ k ] ) );
		} );
		return msg;
	}

	function conflictsToMap( rows ) {
		var m = {};
		( rows || [] ).forEach( function ( r ) {
			if ( r && r.recurrence_id ) {
				m[ r.recurrence_id ] = true;
			}
		} );
		return m;
	}

	/**
	 * Wait for delayed deps (page optimizers), then run after DOM ready. Polls ~15s.
	 *
	 * @param {Function} isReady Returns true when deps exist.
	 * @param {Function} onReady Called once when ready.
	 * @param {string}   [label] Console label on timeout.
	 */
	function whenDepsReady( isReady, onReady, label ) {
		var n = 0;
		( function tick() {
			if ( isReady() ) {
				if ( document.readyState === 'loading' ) {
					document.addEventListener( 'DOMContentLoaded', onReady );
				} else {
					setTimeout( onReady, 0 );
				}
				return;
			}
			if ( n >= 300 ) {
				console.error(
					'WC Appointments: timed out waiting for dependencies' +
						( label ? ' (' + label + ')' : '' ) +
						'.'
				);
				return;
			}
			n += 1;
			setTimeout( tick, 50 );
		} )();
	}

	function formatFakeUtcDateTime( ts, label ) {
		if ( label ) {
			return label;
		}
		if ( ! ts ) {
			return '';
		}
		var d = new Date( ts * 1000 );
		var mo = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];
		var wd = [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ];
		return wd[ d.getUTCDay() ] + ', ' + mo[ d.getUTCMonth() ] + ' ' + d.getUTCDate() + ', ' + d.getUTCFullYear() + ', ' + pad( d.getUTCHours() ) + ':' + pad( d.getUTCMinutes() );
	}

	function buildRrule( freq, interval, count ) {
		var p = [ 'RRULE:FREQ=' + freq ];
		var iv = parseInt( interval, 10 ) || 1;
		if ( iv > 1 ) {
			p.push( 'INTERVAL=' + iv );
		}
		p.push( 'COUNT=' + ( parseInt( count, 10 ) || 0 ) );
		return p.join( ';' );
	}

	function normalizeFreqs( freqs ) {
		if ( Array.isArray( freqs ) ) {
			return freqs;
		}
		if ( 'string' === typeof freqs && freqs ) {
			return freqs.split( ',' ).map( function ( f ) { return f.trim().toUpperCase(); } ).filter( Boolean );
		}
		return [ 'WEEKLY', 'DAILY', 'MONTHLY' ];
	}

	function restJson( url, opts ) {
		opts = opts || {};
		var hdr = Object.assign( {}, opts.headers || {} );
		var method = opts.method || 'GET';
		if ( opts.nonce && ! hdr[ 'X-WP-Nonce' ] ) {
			hdr[ 'X-WP-Nonce' ] = opts.nonce;
		}
		if ( 'GET' !== method && ! hdr[ 'Content-Type' ] ) {
			hdr[ 'Content-Type' ] = 'application/json';
		}
		if ( opts.idempotency && 'GET' !== method && ! hdr[ 'Idempotency-Key' ] ) {
			hdr[ 'Idempotency-Key' ] = 'wca-' + Date.now() + '-' + Math.random().toString( 36 ).slice( 2, 10 );
		}
		return fetch( url, {
			method: method,
			headers: hdr,
			credentials: opts.credentials || 'same-origin',
			cache: opts.cache || 'default',
			signal: opts.signal,
			body: opts.body ? ( 'string' === typeof opts.body ? opts.body : JSON.stringify( opts.body ) ) : undefined
		} ).then( function ( r ) {
			return r.json().then( function ( data ) {
				if ( ! r.ok ) {
					throw new Error( ( data && ( data.detail || data.message ) ) || ( 'HTTP ' + r.status ) );
				}
				return data;
			} );
		} );
	}

	var rp = {
		fresh: function () {
			return { exdates: [], overrides: {}, rescheduleTarget: '', rescheduleFetching: '', slotSuggestions: {} };
		},
		payload: function ( s ) {
			return { exdates: s.exdates.slice(), overrides: Object.assign( {}, s.overrides ) };
		},
		attach: function ( body, s ) {
			if ( s.exdates.length ) {
				body.exdates = s.exdates.slice();
			}
			if ( Object.keys( s.overrides ).length ) {
				body.overrides = Object.assign( {}, s.overrides );
			}
			return body;
		},
		resolveAnchor: function ( occ, ts ) {
			if ( ! occ || ! occ.length ) {
				return '';
			}
			if ( ts > 0 ) {
				for ( var i = 0; i < occ.length; i++ ) {
					if ( occ[ i ].start_ts === ts ) {
						return occ[ i ].recurrence_id || '';
					}
				}
			}
			return occ[ 0 ].recurrence_id || '';
		},
		suggestTs: function ( occ, id ) {
			for ( var j = 0; j < ( occ || [] ).length; j++ ) {
				if ( occ[ j ].recurrence_id === id ) {
					return occ[ j ].start_ts || 0;
				}
			}
			return 0;
		},
		rowHtml: function ( o ) {
			var i18nMap = o.i18n || {};
			var id = o.id;
			var on = !!o.active;
			var act;
			if ( o.anchor ) {
				act = '<span class="wca-preview-selection" title="' + ( i18nMap.selectedSlot || 'Selection' ) + '" aria-label="' + ( i18nMap.selectedSlot || 'Selection' ) + '"></span>';
			} else {
				act = '';
				if ( o.userCanCancel !== false ) {
					act += '<button type="button" class="wc-appointments-selection-clear wca-preview-remove" title="' + ( i18nMap.removeSession || 'Remove' ) + '" aria-label="' + ( i18nMap.removeSession || 'Remove' ) + '">\u00d7</button>';
				}
		if ( o.userCanReschedule !== false ) {
			act += '<button type="button" class="wc-appointments-selection-clear wca-preview-reschedule' + ( on ? ' is-on' : '' ) + ( on && o.fetching ? ' is-loading' : '' ) + '" aria-pressed="' + ( on ? 'true' : 'false' ) + '"><span class="wca-preview-reschedule-icon" aria-hidden="true">\u21BB</span> ' + ( i18nMap.rescheduleSession || 'Reschedule' ) + '</button>';
		}
		}
		var canReschedule = o.userCanReschedule !== false;
		var dtClass = 'wca-preview-item-datetime' + ( o.unavail && canReschedule ? ' wca-preview-item-datetime--reschedule' : '' );
		var dtTitle = o.unavail && canReschedule ? ( i18nMap.rescheduleSession || 'Reschedule' ) : '';
		var html = '<span class="wca-preview-item-date' + ( o.unavail ? ' wca-preview-unavailable' : '' ) + '"><span class="' + dtClass + '"' + ( on ? ' id="wca-reschedule-source-' + id + '"' : '' ) + ( dtTitle ? ' title="' + dtTitle + '"' : '' ) + '>' + ( o.datetime || '' ) + '</span></span><span class="wca-preview-item-actions">' + act + '</span>';
		if ( on && o.suggestions && o.suggestions.length ) {
			var fmt = o.formatLabel || function ( sl, ts ) { return String( ts ); };
			html += '<div class="wca-reschedule-alternatives" role="group" aria-labelledby="wca-reschedule-source-' + id + '"><p class="wca-reschedule-heading">' + ( i18nMap.rescheduleAlternatives || 'Nearest available slots' ) + '</p><ul>' +
					o.suggestions.map( function ( sl ) {
						var ts = sl && sl.start_ts ? sl.start_ts : sl;
						return '<li><button type="button" class="wca-reschedule-slot" data-ts="' + ts + '">' + fmt( sl, ts ) + '</button></li>';
					} ).join( '' ) + '</ul></div>';
			}
			return on ? '<section class="wca-reschedule-panel" aria-label="' + ( i18nMap.rescheduleSession || 'Reschedule' ) + '">' + html + '</section>' : html;
		},
		countLabel: function ( summary, tr, opts ) {
			opts = opts || {};
			if ( ! summary ) {
				return '';
			}
			var billable = parseInt( summary.billable_count, 10 ) || 0;
			var total = parseInt( summary.occurrence_count, 10 ) || 0;
			var conflicts = parseInt( summary.conflict_count, 10 ) || 0;
			if ( ! opts.alwaysPackage && conflicts > 0 && total > billable ) {
				return tr( 'previewBillableOf', opts.billableOfFb || '%1$d of %2$d appointments', { '%1$d': billable, '%2$d': total } );
			}
			return tr( 'previewPackage', opts.packageFb || '%d appointments', billable );
		},
		previewCollapseAt: 10,
		patch: function ( s, extra ) {
			return Object.assign( {}, s, extra );
		},
		intervalUnit: function ( freq, interval, dict ) {
			dict = dict || {};
			var plural = ( parseInt( interval, 10 ) || 1 ) > 1;
			var keys = {
				DAILY: plural ? 'daysUnit' : 'dayUnit',
				WEEKLY: plural ? 'weeksUnit' : 'weekUnit',
				MONTHLY: plural ? 'monthsUnit' : 'monthUnit'
			};
			var key = keys[ freq ] || keys.WEEKLY;
			var fallbacks = {
				dayUnit: 'day', daysUnit: 'days',
				weekUnit: 'week', weeksUnit: 'weeks',
				monthUnit: 'month', monthsUnit: 'months'
			};
			return dict[ key ] || fallbacks[ key ] || fallbacks.weekUnit;
		},
		listPlan: function ( occurrences, unavailableIds, expanded ) {
			var occ = occurrences || [];
			var n = occ.length;
			var plan = [];
			var prev = -1;
			var indices = [];
			var i;
			var cap = rp.previewCollapseAt;
			for ( i = 0; i < n; i++ ) {
				indices.push( i );
			}
			if ( n > cap && ! expanded ) {
				var pick = {};
				var mark = function ( from, to ) {
					for ( i = from; i < to; i++ ) {
						pick[ i ] = 1;
					}
				};
				mark( 0, Math.min( 6, n ) );
				mark( Math.max( 0, n - 2 ), n );
				for ( i = 0; i < n; i++ ) {
					if ( unavailableIds[ occ[ i ].recurrence_id ] ) {
						pick[ i ] = 1;
					}
				}
				indices = Object.keys( pick ).map( Number ).sort( function ( a, b ) {
					return a - b;
				} );
				if ( indices.length >= n ) {
					indices = [];
					for ( i = 0; i < n; i++ ) {
						indices.push( i );
					}
				}
			}
			indices.forEach( function ( idx ) {
				if ( prev >= 0 && idx > prev + 1 ) {
					plan.push( { gap: idx - prev - 1 } );
				}
				plan.push( { idx: idx } );
				prev = idx;
			} );
			return plan;
		},
		needsTimeSlot: function ( unit ) {
			return 'minute' === unit || 'hour' === unit;
		},
		removeOccurrence: function ( s, id, opts ) {
			opts = opts || {};
			if ( ! id || id === opts.anchorId || s.exdates.indexOf( id ) !== -1 ) {
				return null;
			}
			if ( ( parseInt( opts.billable, 10 ) || 0 ) <= ( parseInt( opts.minRequired, 10 ) || 2 ) ) {
				return { blocked: true };
			}
			var o = Object.assign( {}, s.overrides );
			delete o[ id ];
			return { schedule: rp.patch( s, { overrides: o, exdates: s.exdates.concat( [ id ] ), rescheduleTarget: '' } ) };
		},
		applyOverride: function ( s, id, ts ) {
			if ( ! id || ! ts ) {
				return null;
			}
			var o = Object.assign( {}, s.overrides );
			o[ id ] = ts;
			return { schedule: rp.patch( s, { overrides: o, rescheduleTarget: '', rescheduleFetching: '' } ) };
		},
		toggleReschedule: function ( s, id ) {
			if ( s.rescheduleTarget === id ) {
				return { schedule: rp.patch( s, { rescheduleTarget: '', rescheduleFetching: '' } ), fetch: false };
			}
			var cached = s.slotSuggestions[ id ];
			return {
				schedule: rp.patch( s, { rescheduleTarget: id, rescheduleFetching: cached ? '' : id } ),
				fetch: !cached
			};
		},
		setSuggestions: function ( s, id, list ) {
			var next = Object.assign( {}, s.slotSuggestions );
			next[ id ] = list || [];
			return rp.patch( s, { slotSuggestions: next, rescheduleFetching: '' } );
		},
		fetchRescheduleSuggestions: function ( toggled, id, occ, buildBody, post, onResult ) {
			if ( ! toggled.fetch ) {
				return;
			}
			var body = buildBody();
			body.suggest_recurrence_id = id;
			body.suggest_start_ts = rp.suggestTs( occ, id );
			post( body ).then( function ( data ) {
				onResult( data && data.suggestions, id );
			} ).catch( function () {
				onResult( null, id );
			} );
		},
		statusMessage: function ( o ) {
			if ( ! o ) {
				return '';
			}
			var tr = o.tr || function ( _k, fb ) { return fb || ''; };
			var needsSlot = o.needsTimeSlot !== false;
			if ( o.error ) {
				return o.error;
			}
			if ( o.removeBlocked ) {
				return tr( 'minSessions', 'Minimum appointments required for this package.' );
			}
			if ( ! o.hasAnchor && ! o.loading ) {
				return needsSlot
					? tr( 'selectSlot', 'Select a time first.' )
					: tr( 'selectDate', 'Select a date first.' );
			}
			if ( o.loading && o.hasAnchor ) {
				return tr( 'previewLoading', 'Checking availability…' );
			}
			var sum = o.summary;
			if ( ! sum ) {
				return '';
			}
			var billable = parseInt( sum.billable_count, 10 ) || 0;
			var min = parseInt( o.minRequired, 10 ) || 2;
			if ( billable < min ) {
				return tr( 'previewBelowMinimum', 'Need at least %2$d appointments; only %1$d available. Adjust the schedule or remove appointments.', { '%1$d': billable, '%2$d': min } );
			}
			if ( parseInt( sum.conflict_count, 10 ) > 0 ) {
				return tr( 'conflictsSkipped', o.conflictsFb || '%d unavailable — will be skipped', parseInt( sum.conflict_count, 10 ) );
			}
			return '';
		},
		handleListClick: function ( ev, h ) {
			var row = ev.target.closest( '[data-recurrence-id]' );
			var id, slot, tgt;
			if ( ! row || ! h ) {
				return;
			}
			id = row.getAttribute( 'data-recurrence-id' ) || row.dataset.recurrenceId;
			if ( ! id ) {
				return;
			}
			if ( ev.target.closest( '.wca-preview-remove' ) && ! ev.target.closest( '.wca-preview-selection' ) ) {
				ev.preventDefault();
				if ( h.onRemove ) {
					h.onRemove( id );
				}
				return;
			}
			if ( ev.target.closest( '.wca-preview-reschedule' ) ) {
				ev.preventDefault();
				if ( h.onReschedule ) {
					h.onReschedule( id );
				}
				return;
			}
			if (
				h.onReschedule &&
				h.canReschedule !== false &&
				row.querySelector( '.wca-preview-unavailable' ) &&
				ev.target.closest( '.wca-preview-item-datetime' )
			) {
				ev.preventDefault();
				h.onReschedule( id );
				return;
			}
			slot = ev.target.closest( '.wca-reschedule-slot[data-ts]' );
			tgt = h.getRescheduleTarget ? h.getRescheduleTarget() : '';
			if ( slot && tgt === id && h.onPickSlot ) {
				ev.preventDefault();
				h.onPickSlot( id, parseInt( slot.getAttribute( 'data-ts' ), 10 ) );
			}
		}
	};

	window.wcaShared = {
		debounce: debounce,
		qs: qs,
		qsa: qsa,
		setDisabled: setDisabled,
		toggleLoadingBar: toggleLoadingBar,
		i18n: i18n,
		conflictsToMap: conflictsToMap,
		whenDepsReady: whenDepsReady,
		formatFakeUtcDateTime: formatFakeUtcDateTime,
		buildRrule: buildRrule,
		normalizeFreqs: normalizeFreqs,
		restJson: restJson,
		recurringPreview: rp
	};
}( window ) );
