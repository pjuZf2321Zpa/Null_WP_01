/**
 * WooCommerce Appointments - Admin List Table
 *
 * Handles the appointment list table page behaviors:
 * - Customer filter subtitle (like WordPress search results)
 * - Bulk action options injection
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

/* global wca_list_table_params */
( function() {
	'use strict';

	var params = typeof wca_list_table_params !== 'undefined' ? wca_list_table_params : {};

	/**
	 * Inject customer filter subtitle into the page heading.
	 *
	 * Mimics WordPress core's "Search results for:" subtitle pattern
	 * that appears after the h1.wp-heading-inline element.
	 */
	function injectCustomerFilterSubtitle() {
		if ( ! params.customer_filter_label ) {
			return;
		}

		var heading = document.querySelector( '.wrap hr.wp-header-end' );
		if ( ! heading ) {
			return;
		}

		// Build subtitle HTML matching WordPress core's search results pattern.
		var subtitle = document.createElement( 'span' );
		subtitle.className = 'subtitle wca-customer-filter-subtitle';
		subtitle.innerHTML =
			params.customer_filter_text +
			' <a href="' + params.customer_filter_clear_url + '" class="wca-filter-subtitle-clear" title="' + params.customer_filter_clear_title + '">&times;</a>';

		// Insert before heading (same position as WordPress search subtitle).
		heading.parentNode.insertBefore( subtitle, heading );
	}

	/**
	 * Add bulk action options to the bulk action dropdowns.
	 *
	 * Adds appointment-specific bulk actions (confirm, cancel, etc.)
	 * based on user permissions passed via localized params.
	 */
	function addBulkActionOptions() {
		if ( ! params.bulk_actions || ! params.bulk_actions.length ) {
			return;
		}

		var selects = document.querySelectorAll( 'select[name="action"], select[name="action2"]' );
		if ( ! selects.length ) {
			return;
		}

		params.bulk_actions.forEach( function( action ) {
			selects.forEach( function( select ) {
				var option = document.createElement( 'option' );
				option.value = action.value;
				option.textContent = action.label;
				select.appendChild( option );
			} );
		} );
	}

	// Initialize on DOM ready.
	document.addEventListener( 'DOMContentLoaded', function() {
		injectCustomerFilterSubtitle();
		addBulkActionOptions();
	} );

} )();
