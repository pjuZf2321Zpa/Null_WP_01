/* global wc_appointments_availability_filter_params */
jQuery( function( $ ) {
	'use strict';

	var wc_appointments_availability_filter = {
		init: function() {
			var date_pickers = $( '.widget_availability_filter .date-picker' );

			if ( ! date_pickers.length ) {
				return;
			}

			var datepicker_options = {
				dateFormat: wc_appointments_availability_filter_params.dateFormat,
				altFormat: 'yy-mm-dd',
				numberOfMonths: 1,
				showOtherMonths: true,
				changeMonth: true,
				showButtonPanel: false,
				minDate: 0,
				firstDay: wc_appointments_availability_filter_params.firstDay,
				closeText: wc_appointments_availability_filter_params.closeText,
				currentText: wc_appointments_availability_filter_params.currentText,
				prevText: wc_appointments_availability_filter_params.prevText,
				nextText: wc_appointments_availability_filter_params.nextText,
				monthNames: wc_appointments_availability_filter_params.monthNames,
				monthNamesShort: wc_appointments_availability_filter_params.monthNamesShort,
				dayNames: wc_appointments_availability_filter_params.dayNames,
				dayNamesShort: wc_appointments_availability_filter_params.dayNamesShort,
				dayNamesMin: wc_appointments_availability_filter_params.dayNamesMin,
				isRTL: wc_appointments_availability_filter_params.isRTL
			};

			date_pickers.each( function() {
				var picker = $( this );
				var hidden = picker.siblings( '.date-picker-field' );

				picker.datepicker( $.extend( {}, datepicker_options, {
					altField: hidden,
					onSelect: function() {
						hidden.trigger( 'change' );
					}
				} ) );
			} );
		}
	};

	wc_appointments_availability_filter.init();
} );
