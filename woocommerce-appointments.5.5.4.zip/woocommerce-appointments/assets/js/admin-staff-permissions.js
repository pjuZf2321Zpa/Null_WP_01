﻿/**
 * Staff Permissions Settings
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

(function () {
	'use strict';

	function qs( sel, root ) {
		return ( root || document ).querySelector( sel );
	}

	function qsa( sel, root ) {
		return ( root || document ).querySelectorAll( sel );
	}

	function updateCount( category ) {
		var section = qs( '.wca-permission-category[data-category="' + category + '"]' );
		if ( ! section ) {
			return;
		}
		var total = qsa( '.wca-permission-checkbox', section ).length;
		var enabled = qsa( '.wca-permission-checkbox:checked', section ).length;
		var countEl = qs( '.wca-category-count', section );
		if ( countEl ) {
			countEl.textContent = enabled + '/' + total;
		}
	}

	function updateAllCounts() {
		qsa( '.wca-permission-category' ).forEach( function ( el ) {
			updateCount( el.dataset.category );
		} );
	}

	function setChecks( root, checked ) {
		qsa( '.wca-permission-checkbox', root || document ).forEach( function ( cb ) {
			cb.checked = checked;
		} );
	}

	function toggleAll( btn, checked ) {
		var category = btn.dataset.category;
		if ( category ) {
			var section = qs( '.wca-permission-category[data-category="' + category + '"]' );
			if ( section ) {
				setChecks( section, checked );
				updateCount( category );
			}
			return;
		}
		setChecks( document, checked );
		updateAllCounts();
	}

	function filterPermissions( input ) {
		var term = input.value.toLowerCase().trim();

		qsa( '.wca-permission-item' ).forEach( function ( item ) {
			// Match label/description only - not dependency lines like "Requires: View Calendar".
			var title = ( qs( '.wca-permission-title', item ) || {} ).textContent || '';
			var desc = ( qs( '.wca-permission-description', item ) || {} ).textContent || '';
			var haystack = ( title + ' ' + desc ).toLowerCase();
			item.classList.toggle( 'wca-hidden', !!( term && haystack.indexOf( term ) === -1 ) );
		} );

		qsa( '.wca-permission-category' ).forEach( function ( cat ) {
			var visible = qsa( '.wca-permission-item:not(.wca-hidden)', cat ).length;
			cat.classList.toggle( 'wca-hidden', !!( term && ! visible ) );
		} );

		if ( term ) {
			qsa( '.wca-category-header' ).forEach( function ( header ) {
				header.setAttribute( 'aria-expanded', 'true' );
			} );
		}
	}

	function applyPreset( select ) {
		var preset = select.value;
		if ( ! preset || typeof wcaPermissions === 'undefined' || ! wcaPermissions.presets || ! wcaPermissions.presets[ preset ] ) {
			return;
		}

		setChecks( document, false );
		wcaPermissions.presets[ preset ].forEach( function ( perm ) {
			var cb = qs( 'input[name="wc_appointments_staff_permissions[' + perm + ']"]' );
			if ( cb ) {
				cb.checked = true;
			}
		} );
		updateAllCounts();
	}

	function bindPreset() {
		var select = document.getElementById( 'wc_appointments_staff_permission_preset' );
		if ( ! select ) {
			return;
		}
		function onChange() {
			applyPreset( select );
		}
		select.addEventListener( 'change', onChange );
		if ( typeof jQuery !== 'undefined' ) {
			jQuery( select ).on( 'change select2:select', onChange );
		}
	}

	function init() {
		document.addEventListener( 'click', function ( e ) {
			var header = e.target.closest( '.wca-category-header' );
			if ( header ) {
				e.preventDefault();
				header.setAttribute(
					'aria-expanded',
					header.getAttribute( 'aria-expanded' ) === 'true' ? 'false' : 'true'
				);
				return;
			}

			var enableBtn = e.target.closest( '.wca-enable-all' );
			if ( enableBtn ) {
				e.preventDefault();
				toggleAll( enableBtn, true );
				return;
			}

			var disableBtn = e.target.closest( '.wca-disable-all' );
			if ( disableBtn ) {
				e.preventDefault();
				toggleAll( disableBtn, false );
			}
		} );

		document.addEventListener( 'input', function ( e ) {
			if ( e.target.id === 'wca-permissions-search' ) {
				filterPermissions( e.target );
			}
		} );

		document.addEventListener( 'change', function ( e ) {
			if ( e.target.classList.contains( 'wca-permission-checkbox' ) ) {
				var section = e.target.closest( '.wca-permission-category' );
				if ( section ) {
					updateCount( section.dataset.category );
				}
			}
		} );

		bindPreset();
		updateAllCounts();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
