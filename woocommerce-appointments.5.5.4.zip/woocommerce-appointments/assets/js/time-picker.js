/* globals wc_appointment_form_params, wca_get_querystring, wcaShared */
wcaShared.whenDepsReady(
	function() {
		return typeof jQuery !== 'undefined';
	},
	function() {
		jQuery( function( $ ) {
	'use strict';

	var wc_appointments_time_picker = {
		/**
		 * Scope DOM queries to one appointment widget (multi shortcode/block pages).
		 */
		getInstanceContext: function( element ) {
			var $el              = $( element );
			var appointment_wrap = $el.closest( '.wc-appointments-appointment-form' );
			if ( ! appointment_wrap.length ) {
				appointment_wrap = $el.find( '.wc-appointments-appointment-form' ).first();
			}
			var form             = appointment_wrap.length ? appointment_wrap.closest( 'form' ) : $el.closest( 'form' );

			if ( ! form.length ) {
				form = $el.closest( 'form' );
			}

			var date_fieldset = appointment_wrap.find( 'fieldset.wc-appointments-date-picker' ).first();
			if ( ! date_fieldset.length ) {
				date_fieldset = form.find( 'fieldset.wc-appointments-date-picker' ).first();
			}

			var picker = date_fieldset.find( '.picker' ).not( '.slot-picker' ).first();
			if ( ! picker.length ) {
				picker = appointment_wrap.find( '.picker' ).not( '.slot-picker' ).first();
			}
			if ( ! picker.length ) {
				picker = form.find( '.picker' ).not( '.slot-picker' ).first();
			}

			var slot_picker = appointment_wrap.find( '.wc-appointments-slots-container .slot-picker' ).first();
			if ( ! slot_picker.length ) {
				slot_picker = appointment_wrap.find( '.slot-picker' ).not( '.picker' ).first();
			}
			if ( ! slot_picker.length ) {
				slot_picker = form.find( '.wc-appointments-slots-container .slot-picker' ).first();
			}

			var slots_container = slot_picker.closest( '.wc-appointments-slots-container' );
			if ( ! slots_container.length ) {
				slots_container = slot_picker.parent( 'div' );
			}

			return {
				form: form,
				appointment_wrap: appointment_wrap,
				picker: picker,
				slot_picker: slot_picker,
				date_fieldset: date_fieldset,
				slots_container: slots_container
			};
		},
		/**
		 * Whether availability autoselect is on for this picker (`data-is_autoselect` is `1` or `true`).
		 *
		 * @param {jQuery} picker Date or datetime picker element.
		 * @return {boolean}
		 */
		isAutoselectEnabled: function( picker ) {
			var flag = picker.attr( 'data-is_autoselect' );
			return '1' === String( flag ) || 'true' === String( flag );
		},
		init: function() {
			var appointment_forms = $( '.wc-appointments-appointment-form' );
			// Run on each form instance.
			appointment_forms.each( function() {
				var appointment_wrap = $( this );
				var form             = appointment_wrap.closest( 'form' );
				var ctx              = wc_appointments_time_picker.getInstanceContext( appointment_wrap );
				var picker           = ctx.picker;

				// Show updated time slots.
				form.on( 'addon-duration-changed', function( event, duration ) {
					// Update 'data-combined_duration'.
					var appointment_duration = parseInt( picker.attr( 'data-appointment_duration' ), 10 );
					var addon_duration = parseInt( duration, 10 );
					var combined_duration = parseInt( appointment_duration + addon_duration, 10 );

					picker.data( 'combined_duration', combined_duration );
					picker.data( 'addon_duration', duration );

					wc_appointments_time_picker.show_available_time_slots( appointment_wrap );
				} );

				form.on( 'quantity-changed', function() {
					var qtyInput    = form.find( '.input-text.qty, input[name="quantity"]' );
					var qty         = parseInt( qtyInput.val(), 10 ) || 1;
					var selected    = ctx.slot_picker.find( 'li.selected' );
					var remaining   = selected.length ? parseInt( selected.attr( 'data-remaining' ), 10 ) : 0;
					var preserveTime = selected.length && remaining >= qty;

					wc_appointments_time_picker.show_available_time_slots( appointment_wrap, { preserveTime: preserveTime } );
				} );

				// Per-widget date change (fieldset lives inside appointment_wrap).
				appointment_wrap.on( 'date-selected', function() {
					wc_appointments_time_picker.show_available_time_slots( appointment_wrap, { preserveTime: false } );
				} );

				// Init picker.
				wc_appointments_time_picker.time_picker_init( appointment_wrap );
			} );

			// Update time slots, when timezone changes (name selector — duplicate IDs on multi-form pages).
			$( 'body' ).on( 'change', 'select[name="wc_appointments_field_timezone"]', function() {
				wc_appointments_time_picker.show_available_time_slots( this );
			} );

			// Reset time slots when selected staff or resource changes.
			$( 'body' ).on( 'change', 'select#wc_appointments_field_staff, select[name="wc_appointments_field_staff"], select#wc_appointments_field_resource, select[name="wc_appointments_field_resource"]', function() {
				wc_appointments_time_picker.hide_time_slots( this );
			} );

			// Clear date selection when X button clicked.
			$( 'body' ).on( 'click', '.wc-appointments-selection-clear-date', function( e ) {
				e.preventDefault();
				var form = $( this ).closest( 'form' );
				wc_appointments_time_picker.clear_date_selection( form );
			} );

			// Clear time selection when X button clicked.
			$( 'body' ).on( 'click', '.wc-appointments-selection-clear-time', function( e ) {
				e.preventDefault();
				var form = $( this ).closest( 'form' );
				wc_appointments_time_picker.clear_time_selection( form );
			} );
		},
		time_picker_init: function( element ) {
			var ctx        = wc_appointments_time_picker.getInstanceContext( element );
			var slot_picker = ctx.slot_picker;
			// Time slot manually selected.
			slot_picker.on( 'click', 'a', function( event ) {
				event.preventDefault();
				event.stopPropagation();

				if ( $( this ).hasClass( 'wca-show-first-available' ) ) {
					if ( typeof wca_clear_date_selection === 'function' ) {
						wca_clear_date_selection( ctx.form );
					}
					var instance = ctx.picker.data( 'wc_appointments_date_picker_instance' );
					if ( instance && instance.autoselect_first_available_day ) {
						instance.autoselect_first_available_day( Date.now(), 0 );
					}
					return;
				}

				wc_appointments_time_picker.set_selected_time( ctx.form, $( this ).parent().data( 'slot' ) );
			} );
		},
		set_selected_time: function( form, time_value ) {
			var ctx           = wc_appointments_time_picker.getInstanceContext( form );
			var submit_button = ctx.form.find( '.wc-appointments-appointment-form-button' );
			var slot_picker   = ctx.slot_picker;

			// Disable submit button.
			submit_button.prop( 'disabled', true );

			// Fire up 'time-selected' trigger.
			if ( undefined === time_value ) {
				//form.triggerHandler( 'time-selected' );
				return;
			}

			var selected_slot = slot_picker.find( 'li.slot[data-slot="' + time_value + '"]' ).first();
			var selected_slot_value = selected_slot.find( 'a' ).data( 'value' ) || selected_slot.find( 'span[data-value]' ).data( 'value' );

			// Fire up 'time-selected' trigger.
			if ( ! selected_slot.length || undefined === selected_slot.attr( 'data-slot' ) ) {
				return;
			}

			var target = ctx.slots_container.find( 'input' );

			// TIMEZONE FIX: Get original timestamp (site TZ) to avoid double conversion.
			// data-slot-timestamp contains the original slot timestamp in site timezone.
			var slot_timestamp = selected_slot.data( 'slot-timestamp' );

			// INTERNAL FORMAT FIX: Ensure hidden field always contains machine-readable
			// H:i format with ASCII digits regardless of user's WP time format setting.
			// The data-slot attribute (e.g. "1430") is the canonical machine-readable value.
			// Convert it to "14:30" format for strtotime() on the server.
			//
			// @deprecated 5.3.5 This time parsing logic will be removed. Server now provides:
			//   - slot.selection_value: ISO-8601 format for form submission
			//   - slot.display_time_formatted: Localized display string
			//   - slot.display_time: 24h H:i format
			// New slots should use data-selection-value attribute instead of manual parsing.
			// See UNIFIED-SLOTS-STANDARDIZATION.md for the new consumer pattern.
			var machine_time = selected_slot_value; // default: data-value (e.g. "14:30")
			var time_str = time_value != null ? String( time_value ) : '';
			if ( time_str && /^\d{3,4}$/.test( time_str ) ) {
				// data-slot is in Hi format (e.g. "930" or "1430") — normalize to H:i
				// (time_value may be number from jQuery .data(); .substring requires string)
				var padded = time_str.length === 3 ? '0' + time_str : time_str;
				machine_time = padded.substring( 0, 2 ) + ':' + padded.substring( 2, 4 );
			} else if ( selected_slot_value ) {
				// Normalize data-value: strip non-ASCII, handle AM/PM
				var cleaned = selected_slot_value.replace( /[^\d:aApPmM\s]/g, '' );
				var tm = cleaned.match( /(\d{1,2}):(\d{2})\s*(AM|PM|am|pm)?/ );
				if ( tm ) {
					var h = parseInt( tm[1], 10 );
					var m = parseInt( tm[2], 10 );
					if ( tm[3] ) {
						var p = tm[3].toUpperCase();
						if ( 'PM' === p && h < 12 ) { h += 12; }
						else if ( 'AM' === p && 12 === h ) { h = 0; }
					}
					machine_time = ( h < 10 ? '0' + h : '' + h ) + ':' + ( m < 10 ? '0' + m : '' + m );
				}
			}

			// Add selected time value to input.
			// target.val( value ).trigger( 'change' );
			target.val( machine_time ); // timeslot in clean H:i format for server parsing
			target.attr( 'data-value', time_value ); // timeslot in Hi format
			target.attr( 'data-slot-timestamp', slot_timestamp ); // original timestamp (site TZ)

			// Also set the timestamp hidden field for form submission.
			var timestamp_field = form.find( '.slot-timestamp-field' );
			if ( timestamp_field.length && slot_timestamp ) {
				timestamp_field.val( slot_timestamp );
			}

			// Fire up 'time-selected' trigger.
			ctx.form.triggerHandler( 'time-selected' );

			// Empty previous selected slot.
			slot_picker.find( 'li' ).removeClass( 'selected' );

			// Add .selected class to selected slot.
			selected_slot.addClass( 'selected' );

			// Update selection info display with selected time.
			wc_appointments_time_picker.update_selection_info( ctx.form );

			return 'selected';
		},
		unset_selected_time: function( form ) {
			var ctx           = wc_appointments_time_picker.getInstanceContext( form );
			var submit_button = ctx.form.find( '.wc-appointments-appointment-form-button' );
			var slot_picker   = ctx.slot_picker;

			// Disable submit button.
			submit_button.prop( 'disabled', true );

			// Empty previous selected slot.
			slot_picker.find( 'li' ).removeClass( 'selected' );
		},
		show_available_time_slots: function( element, options ) {
			options = options || {};
			var preserveTime    = false !== options.preserveTime;
			var ctx             = wc_appointments_time_picker.getInstanceContext( element );
			var form            = ctx.form;
			var picker          = ctx.picker;
			var slot_picker     = ctx.slot_picker;
			var fieldset        = ctx.date_fieldset;
			var year            = parseInt( fieldset.find( 'input.appointment_date_year' ).val(), 10 );
			var month           = parseInt( fieldset.find( 'input.appointment_date_month' ).val(), 10 );
			var day             = parseInt( fieldset.find( 'input.appointment_date_day' ).val(), 10 );
			var selected_slot   = slot_picker.find( 'li.selected' );
			var time_value      = preserveTime ? selected_slot.attr( 'data-slot' ) : undefined;
			var is_autoselect   = wc_appointments_time_picker.isAutoselectEnabled( picker );
			var addon_duration  = picker.data( 'addon_duration' ) ? picker.data( 'addon_duration' ) : 0;
			var timezone_change = 0;

			// Detect time zone change?
			if ( 'wc_appointments_field_timezone' === $( element ).attr( 'name' ) ) {
				timezone_change = 1;
			}

			if ( !year || !month || !day ) {
				return;
			}

			// Clear time only when not preserving (qty refresh must keep required_for_calculation filled).
			var slots_container = ctx.slots_container;
			if ( ! preserveTime ) {
				slots_container.find( 'input' ).val( '' ).removeAttr( 'data-value' ).removeAttr( 'data-slot-timestamp' ).trigger( 'change' );
				slot_picker.find( 'li' ).removeClass( 'selected' );
				form.find( '.single_add_to_cart_button, .wc-appointments-appointment-form-button' ).prop( 'disabled', true );
				wc_appointments_time_picker.update_selection_info( form );
			}

			// Show loading bar (element exists in template, or create if needed for backward compat).
			if ( ! slots_container.find( '.wca-loading-bar' ).length ) {
				slots_container.prepend( '<div class="wca-loading-bar"></div>' );
			}
			slots_container.find( '.wca-loading-bar' ).addClass( 'is-active' );

			// Abort stale in-flight slot requests so rapid date changes cannot apply an old response.
			var previousXhr = form.data( 'wca-slots-xhr' );
			if ( previousXhr && previousXhr.abort ) {
				previousXhr.abort();
			}

			var requestId = ( form.data( 'wca-slots-request-id' ) || 0 ) + 1;
			form.data( 'wca-slots-request-id', requestId );

			// Get slots.
			var slotsXhr = $.ajax( {
				type: 'POST',
				url: wc_appointment_form_params.ajax_url,
				data: {
					action: 'wc_appointments_get_slots',
					form: form.serialize(),
					duration: addon_duration
				},
				success: function( code ) {
					if ( requestId !== form.data( 'wca-slots-request-id' ) ) {
						return;
					}

					var currentYear  = parseInt( fieldset.find( 'input.appointment_date_year' ).val(), 10 );
					var currentMonth = parseInt( fieldset.find( 'input.appointment_date_month' ).val(), 10 );
					var currentDay   = parseInt( fieldset.find( 'input.appointment_date_day' ).val(), 10 );

					if ( currentYear !== year || currentMonth !== month || currentDay !== day ) {
						slots_container.find( '.wca-loading-bar' ).removeClass( 'is-active' );
						return;
					}

					// Handle JSON error response (e.g. result === 'ERROR' or success === false).
					var isJsonError = false;
					if ( typeof code === 'string' && code.trim().charAt( 0 ) === '{' ) {
						try {
							var result = JSON.parse( code );
							if ( result && ( result.result === 'ERROR' || result.success === false ) ) {
								isJsonError = true;
								slot_picker.show();
								slot_picker.html( ( result.data && result.data.html ) ? result.data.html : ( result.html || '' ) );
								slots_container.find( '.wca-loading-bar' ).removeClass( 'is-active' );
								wc_appointments_time_picker.update_selection_info( form );
							}
						} catch ( e ) {}
					}

					if ( isJsonError ) {
						return;
					}

					slot_picker.show();
					slot_picker.html( code );
					slot_picker.find( 'li.slot-sold-out' ).removeClass( 'selected' );
					slots_container.find( '.wca-loading-bar' ).removeClass( 'is-active' );
					wc_appointments_time_picker.update_selection_info( form );

				if ( timezone_change ) {
					wc_appointments_time_picker.unset_selected_time( form );

					return;
				}

				var set_selected = wc_appointments_time_picker.set_selected_time( form, time_value );

				// If time is in querystring, select it instead of the first time.
				// Overrides autoselect setting.
				var querystring_time = wca_get_querystring( 'time' );
				if ( null !== querystring_time && undefined === set_selected ) {
					var selected_time = slot_picker.find( 'li.slot[data-slot="' + querystring_time + '"]' ).not( '.slot_empty' );

					if ( 0 < selected_time.length ) {
						form.triggerHandler( 'selected-time-unavailable', selected_time );
						var time_value = selected_time.attr( 'data-slot' );
						wc_appointments_time_picker.set_selected_time( form, time_value );
					} else {
						// Time not available: store for display, don't auto-select another.
						form.data( 'wca-unavailable-time', querystring_time );
						wc_appointments_time_picker.update_selection_info( form );
						form.triggerHandler( 'time-unavailable', [ querystring_time ] );
						if ( is_autoselect ) {
							slot_picker.find( 'li.slot_empty' ).first().append(
								'<a href="#" class="wca-show-first-available">' + ( wc_appointment_form_params.i18n_show_first_available || 'Show first available' ) + '</a>'
							);
						}
					}
				// Auto select first available time (server marks li.selected via slots AJAX).
				} else if ( is_autoselect && undefined === set_selected ) {
					wc_appointments_time_picker.autoselect_first_available_time( form );
				}
				},
				error: function( jqXHR, textStatus ) {
					if ( 'abort' === textStatus ) {
						return;
					}

					if ( requestId !== form.data( 'wca-slots-request-id' ) ) {
						return;
					}

					slots_container.find( '.wca-loading-bar' ).removeClass( 'is-active' );
					slot_picker.show();
				},
				dataType: 'html'
			} );

			form.data( 'wca-slots-xhr', slotsXhr );
		},
		/**
		 * Bookable slot the server already marked selected (engine pick from slots AJAX).
		 * Single query — does not scan slot list order.
		 */
		find_server_selected_bookable_slot: function( slot_picker ) {
			var anchor = slot_picker.find( 'li.slot.selected:not(.slot-sold-out) a' ).first();
			return anchor.length ? anchor.closest( 'li.slot' ) : $( [] );
		},
		/**
		 * Legacy DOM-order fallback when slots HTML has no li.selected (e.g. stale cache).
		 * Not used on the normal autoselect path — see autoselect_first_available_time.
		 */
		find_first_bookable_slot: function( slot_picker ) {
			var anchor = slot_picker.find( 'li.slot:not(.slot_empty):not(.slot-sold-out) a' ).first();
			return anchor.length ? anchor.closest( 'li.slot' ) : $( [] );
		},
		/**
		 * Apply auto-selected time after slots AJAX.
		 *
		 * @param {jQuery} form  Cart form or appointment widget root.
		 */
		autoselect_first_available_time: function( form ) {
			var ctx             = wc_appointments_time_picker.getInstanceContext( form );
			var picker          = ctx.picker;
			var slot_picker     = ctx.slot_picker;
			var selected_day    = picker.find( 'td.ui-datepicker-current-day' ).not( '.ui-state-disabled' );
			var first_slot      = wc_appointments_time_picker.find_server_selected_bookable_slot( slot_picker );

			// Server pick first; then first bookable slot in this widget only (not page-global).
			if ( ! first_slot.length ) {
				first_slot = wc_appointments_time_picker.find_first_bookable_slot( slot_picker );
			}
			var is_autoselect = wc_appointments_time_picker.isAutoselectEnabled( picker );

			if ( 0 < first_slot.length ) {
				var time_value = first_slot.attr( 'data-slot' );
				wc_appointments_time_picker.set_selected_time( ctx.form, time_value );

			// Go to next day when autoselect is active.
			} else if ( is_autoselect ) {
				// Stop propagation on programmatic clicks to prevent event bubbling
				var next_day = selected_day.nextAll( 'td:not(.ui-state-disabled)' ).add( selected_day.closest( 'tr' ).nextAll().find( 'td' ) ).slice( 0, 1 );
				next_day.one( 'click', function( e ) {
					e.stopPropagation();
				} );
				next_day.trigger( 'click' );

				//selected_day.prop( 'title', wc_appointment_form_params.i18n_date_unavailable );
				//selected_day.addClass( 'not_appointable' );
				//selected_day.addClass( 'ui-datepicker-unselectable' );
				//selected_day.addClass( 'ui-state-disabled' );
			}
		},
		hide_time_slots: function( element ) {
			var ctx             = wc_appointments_time_picker.getInstanceContext( element );
			var slot_picker     = ctx.slot_picker;
			var fieldset        = ctx.date_fieldset;
			var year            = parseInt( fieldset.find( 'input.appointment_date_year' ).val(), 10 );
			var month           = parseInt( fieldset.find( 'input.appointment_date_month' ).val(), 10 );
			var day             = parseInt( fieldset.find( 'input.appointment_date_day' ).val(), 10 );

			if ( !year || !month || !day ) {
				return;
			}

			// hide slots
			slot_picker.hide();
		},
		/**
		 * Update the selection info display in the slot header.
		 * Shows: placeholder (no date) -> date + "select time" (date selected) -> date + time (both selected)
		 */
		update_selection_info: function( form ) {
			var ctx            = wc_appointments_time_picker.getInstanceContext( form );
			var fieldset       = ctx.date_fieldset;
			var slot_picker    = ctx.slot_picker;
			var selection_info = ctx.appointment_wrap.find( '.wc-appointments-selection-info' );
			if ( ! selection_info.length ) {
				selection_info = ctx.form.find( '.wc-appointments-selection-info' );
			}

			if ( ! selection_info.length ) {
				return;
			}

			var placeholder    = selection_info.find( '.wc-appointments-selection-placeholder' );
			var date_el        = selection_info.find( '.wc-appointments-selection-date' );
			var clear_date_btn = selection_info.find( '.wc-appointments-selection-clear-date' );
			var time_prompt    = selection_info.find( '.wc-appointments-selection-time-prompt' );
			var time_el        = selection_info.find( '.wc-appointments-selection-time' );
			var clear_time_btn = selection_info.find( '.wc-appointments-selection-clear-time' );

			var year  = parseInt( fieldset.find( 'input.appointment_date_year' ).val(), 10 );
			var month = parseInt( fieldset.find( 'input.appointment_date_month' ).val(), 10 );
			var day   = parseInt( fieldset.find( 'input.appointment_date_day' ).val(), 10 );

			// No date selected - show placeholder.
			if ( ! year || ! month || ! day ) {
				placeholder.show();
				date_el.hide();
				clear_date_btn.hide();
				time_prompt.hide();
				time_el.hide();
				clear_time_btn.hide();
				return;
			}

			// Date is selected - format and show it using WP date format.
			var date_obj = new Date( year, month - 1, day );
			var date_str = wca_format_date( date_obj, wc_appointment_form_params.date_format );

			placeholder.hide();
			date_el.text( date_str ).show();
			clear_date_btn.show();

			// Check if time is selected.
			var selected_slot = slot_picker.find( 'li.selected' );
			if ( selected_slot.length ) {
				var row      = selected_slot.first();
				var time_raw = row.attr( 'data-display-time' );
				var time_str = row.attr( 'data-display-time-formatted' );
				if ( ! time_str ) {
					time_str = time_raw || row.find( 'a' ).data( 'value' ) || row.find( 'span[data-value]' ).data( 'value' ) || row.find( 'a' ).text() || row.find( '.slot-time-text' ).text();
					if ( time_str && typeof wca_format_time === 'function' ) {
						time_str = wca_format_time( time_str, wc_appointment_form_params.time_format );
					}
				}
				// Multi-unit length: append end from 24h start + duration minutes (incl. addons).
				var mins = ( parseInt( ctx.picker.attr( 'data-duration_minutes' ), 10 ) || 0 )
					+ ( parseInt( ctx.picker.data( 'addon_duration' ), 10 ) || 0 );
				var parts = time_raw && mins > 60 ? String( time_raw ).match( /^(\d{1,2}):(\d{2})$/ ) : null;
				if ( parts && typeof wca_format_time === 'function' ) {
					var total = ( parseInt( parts[1], 10 ) * 60 ) + parseInt( parts[2], 10 ) + mins;
					var end_h = Math.floor( total / 60 ) % 24;
					var end_m = total % 60;
					var end_raw = ( end_h < 10 ? '0' : '' ) + end_h + ':' + ( end_m < 10 ? '0' : '' ) + end_m;
					time_str += ' - ' + wca_format_time( end_raw, wc_appointment_form_params.time_format );
				}
				time_prompt.hide();
				time_el.text( time_str ).show();
				clear_time_btn.show();
				// Clear any stale unavailable marker.
				ctx.form.removeData( 'wca-unavailable-time' );
			} else {
				// Check for unavailable time from querystring.
				var unavail_time = ctx.form.data( 'wca-unavailable-time' );
				if ( unavail_time ) {
					var formatted = wc_appointments_time_picker.format_time_value( unavail_time );
					var label = wc_appointment_form_params.i18n_time_unavailable || 'Selected time is unavailable';
					time_prompt.hide();
					time_el.html( formatted + ' <small>(' + label + ')</small>' ).show();
					clear_time_btn.show();
				} else {
					// Any bookable row (one query; no per-slot filter).
					var has_bookable_slots = 0 < wc_appointments_time_picker.find_first_bookable_slot( slot_picker ).length;
					if ( has_bookable_slots ) {
						time_prompt.show();
					} else {
						time_prompt.hide();
					}
					time_el.hide();
					clear_time_btn.hide();
				}
			}
		},
		/**
		 * Format time value from slot format (e.g. "1000" or "930") to display format.
		 */
		format_time_value: function( time_value ) {
			var time_str = time_value != null ? String( time_value ) : '';
			if ( time_str && /^\d{3,4}$/.test( time_str ) ) {
				var padded = time_str.length === 3 ? '0' + time_str : time_str;
				var raw = padded.substring( 0, 2 ) + ':' + padded.substring( 2, 4 );
				if ( typeof wca_format_time === 'function' && wc_appointment_form_params.time_format ) {
					return wca_format_time( raw, wc_appointment_form_params.time_format );
				}
				return raw;
			}
			return time_str;
		},
		/**
		 * Clear only the date selection (also clears time).
		 */
		clear_date_selection: function( form ) {
			// Use common function from appointment-form.js
			if ( typeof wca_clear_date_selection === 'function' ) {
				wca_clear_date_selection( form );
			}
		},
		/**
		 * Clear only the time selection (keep date).
		 */
		clear_time_selection: function( form ) {
			var ctx         = wc_appointments_time_picker.getInstanceContext( form );
			var slot_picker = ctx.slot_picker;

			// Clear time selection and unavailable marker.
			slot_picker.find( 'li' ).removeClass( 'selected' );
			ctx.form.removeData( 'wca-unavailable-time' );

			// Clear hidden time fields.
			ctx.slots_container.find( 'input' ).val( '' ).removeAttr( 'data-value' ).removeAttr( 'data-slot-timestamp' );
			ctx.form.find( '.slot-timestamp-field' ).val( '' );

			// Disable submit button.
			form.find( '.wc-appointments-appointment-form-button' ).prop( 'disabled', true );

			// Hide cost.
			form.find( '.wc-appointments-appointment-cost' ).hide();

			// Update selection info display - keep date, clear time
			wc_appointments_time_picker.update_selection_info( form );

			// Remove time from querystring.
			if ( typeof wca_update_querystring === 'function' ) {
				wca_update_querystring( 'time', null );
			}

			// Trigger time cleared event.
			form.triggerHandler( 'time-cleared' );
		}
	};

	wc_appointments_time_picker.init();
} );
	},
	'time-picker'
);
