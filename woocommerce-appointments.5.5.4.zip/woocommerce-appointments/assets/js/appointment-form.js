/* globals wc_appointment_form_params, wcaShared */
// Initialize immediately if DOM is ready, otherwise wait for DOMContentLoaded
// This ensures calendar loads independently of images and other resources
// Wrapped in error handling to prevent errors in other scripts from breaking the calendar
(function () {
	'use strict';

	// Function to initialize the appointment form with error handling
	function initAppointmentFormWrapper($) {
		try {
			initAppointmentForm($);
		} catch (error) {
			console.error('WC Appointments: Error initializing appointment form:', error);
			// Try to initialize again after a delay as a fallback
			setTimeout(function () {
				try {
					initAppointmentForm($);
				} catch (retryError) {
					console.error('WC Appointments: Failed to initialize appointment form after retry:', retryError);
				}
			}, 500);
		}
	}

	// Function to initialize the appointment form
	function initAppointmentForm($) {
		var form_count = 1;
		var wc_appointments_appointment_form = {
			init: function () {
				var appointment_forms = $('.wc-appointments-appointment-form');
				appointment_forms.show().prop('disabled', false);
				$('.wc-appointments-appointment-form-button').show().removeClass('disabled').prop('disabled', true);

				form_count = appointment_forms.length;

				// Run on each form instance.
				appointment_forms.each(function () {
					var form = $(this).closest('form');

					// Run date picker on each instance.
					wc_appointments_appointment_form.appointment_form_init(form);
				});
			},
			appointment_form_init: function (form) {
				var picker = form.find('.picker:eq(0)');
				var duration_unit = picker.attr('data-duration_unit');

				// Disable submit button.
				form.find('.wc-appointments-appointment-form-button').prop('disabled', true);

				// Bridge jQuery custom events to native CustomEvents for vanilla recurring-form.js.
				form.on(
					'time-selected month-selected date-selected time-cleared date-cleared staff-selected addon-costs-changed addon-costs-only-changed addon-duration-changed',
					function (e) {
						if (form[0] && typeof CustomEvent !== 'undefined') {
							form[0].dispatchEvent(
								new CustomEvent('wca:' + e.type, { bubbles: true, detail: e })
							);
						}
					}
				);

				//console.log(duration_unit);

				// Day/night: date picker only (no time picker). Bind costs on date/staff/addons.
				if ('day' === duration_unit || 'night' === duration_unit) {
					form.on('date-selected', this.calculate_costs)
						.on('staff-selected', this.calculate_costs)
						.on('addon-duration-changed', this.calculate_costs)
						.on('addon-costs-changed', this.calculate_costs);
					// if duration unit is months then there is month picker present
					// bind cost calculation on the month selection
				} else if ('month' === duration_unit) {
					form.on('month-selected', this.calculate_costs)
						.on('staff-selected', this.calculate_costs)
						.on('addon-duration-changed', this.calculate_costs)
						.on('addon-costs-changed', this.calculate_costs);
					// if duration unit is hours or minutes then there is time picker present
					// bind cost calculation on the staff and time selection
				} else {
					form.on('time-selected', this.calculate_costs)
						.on('addon-costs-only-changed', this.calculate_costs);
				}

				form.find('.quantity').on('change', 'input.qty, input[name="quantity"]', this.on_quantity_changed);
				form.on(
					'change',
					'input[name="wc_deposit_option"], input[name="wc_deposit_payment_plan"]',
					this.on_deposit_option_changed
				);
				form.on('click', '.quantity .plus, .quantity .minus, .quantity button', function () {
					var qtyInput = $(this).closest('.quantity').find('input.qty, input[name="quantity"]');
					if (qtyInput.length) {
						setTimeout(function () {
							wc_appointments_appointment_form.on_quantity_changed.call(qtyInput[0]);
						}, 0);
					}
				});

				// Update querystring.
				// Only when 1 form is present on page.
				// console.log( form_count );
				if (1 >= form_count) {
					form.on('month-selected', this.update_querystring)
						.on('date-selected', this.update_querystring)
						.on('time-selected', this.update_querystring)
						.on('staff-selected', this.update_querystring)
						.on('location-selected', this.update_querystring);
					//.on( 'addon-selected', this.update_querystring );
				}

				// Add-ons changed.
				form.on('updated_addons', this.selected_addon);

				var addons_totals = form.find('#product-addons-total');
				var addons_data = addons_totals && addons_totals.data('price_data') ? addons_totals.data('price_data') : 0;

				//console.log( addons_totals );
				//console.log( addons_totals.data() );

				if (addons_data.length) {
					wc_appointments_appointment_form.selected_addon('preset', form);
				}

				// WooCommerce TM Extra Product Options integration.
				form.on('appointment-cost-success', this.tm_epo_integration);
			},
			selected_addon: function (type, form) {
				if ('preset' !== type) {
					form = $(this).closest('form');
				}

				// Make sure the check the button state
				// to prevent enabling the button when it should be disabled.
				var check_add_to_cart_button_state = form.find('.single_add_to_cart_button').is(':disabled');

				form.find('.single_add_to_cart_button').prop('disabled', true);

				// Access selected addons data.
				var addons_totals = form.find('#product-addons-total');
				var addons_data = addons_totals && addons_totals.data('price_data') ? addons_totals.data('price_data') : 0;
				var addons_field_duration = form.find('#wc_appointments_field_addons_duration');
				var addons_field_cost = form.find('#wc_appointments_field_addons_cost');
				var product_qty = 0 < parseInt(form.find('.input-text.qty').val()) ? parseInt(form.find('.input-text.qty').val()) : 1;
				var addons_duration = 0;
				var addons_costs = 0;
				var addons_duration_only = false;
				var addons_costs_only = false;

				//console.log( product_qty );
				//console.log( addons_data );

				// Loop through selected addons.
				if (addons_data.length) {
					$.each(addons_data, function (i, addon) {
						var addon_duration = 0;
						// Get the appropriate duration value - prefer per-unit for quantity_based, otherwise use total
						if (addon.duration_raw_pu && 0 != parseInt(addon.duration_raw_pu)) {
							addon_duration = parseInt(addon.duration_raw_pu);
						} else if (addon.duration_raw && 0 != parseInt(addon.duration_raw)) {
							addon_duration = parseInt(addon.duration_raw);
						}
						if (0 != addon_duration) {
							switch (addon.duration_type) {
								case 'flat_time':
									addons_duration += addon_duration;
									break;
								case 'quantity_based':
									addons_duration += addon_duration * product_qty;
									break;
								default:
									addons_duration += addon_duration;
									break;
							}
						}

						var addon_cost = 0;
						var addon_cost_raw = addon.cost_raw;
						var addon_cost_raw_pu = addon.cost_raw_pu;
						// Get the appropriate cost value - prefer per-unit for quantity_based, otherwise use total
						if (addon_cost_raw_pu && 0 != parseFloat(addon_cost_raw_pu.toString().replace(/,/g, '.'))) {
							addon_cost = parseFloat(addon_cost_raw_pu.toString().replace(/,/g, '.'));
						} else if (addon_cost_raw && 0 != parseFloat(addon_cost_raw.toString().replace(/,/g, '.'))) {
							addon_cost = parseFloat(addon_cost_raw.toString().replace(/,/g, '.'));
						}
						if (0 != addon_cost) {
							switch (addon.price_type) {
								case 'flat_fee':
									// Flat fee is added once to the total, not per-unit
									addons_costs += addon_cost;
									break;
								case 'percentage_based':
									// Percentage is already calculated with qty in addons.js, don't divide
									addons_costs += addon_cost;
									break;
								case 'quantity_based':
									// Per-unit cost, multiply by quantity
									addons_costs += addon_cost * product_qty;
									break;
								default:
									addons_costs += addon_cost;
									break;
							}
						}
					});
				}

				// Save addon duration to input field.
				if (0 < addons_field_duration.length) {
					if (0 !== addons_duration) {
						addons_field_duration.val(addons_duration);
					} else {
						addons_field_duration.val(0);
					}
				}

				// Save addon costs to input field.
				if (0 < addons_field_cost.length) {
					if (0 !== addons_costs) {
						addons_field_cost.val(addons_costs);
					} else {
						addons_field_cost.val(0);
					}
				}

				//console.log( addons_duration );
				//console.log( addons_costs );

				// Duration change triggers.
				if (0 !== addons_duration && wc_appointment_form_params.duration_changed !== addons_duration) {
					wc_appointment_form_params.duration_changed = addons_duration;
					form.triggerHandler('addon-duration-changed', [addons_duration]);
					addons_duration_only = true;
				} else if (0 !== addons_duration && wc_appointment_form_params.duration_changed === addons_duration) {
					wc_appointment_form_params.duration_changed = addons_duration;
					form.triggerHandler('addon-duration-unchanged', [addons_duration]);
				} else if (0 === addons_duration && !wc_appointment_form_params.duration_changed) {
					wc_appointment_form_params.duration_changed = false;
					form.triggerHandler('addon-duration-unchanged', [addons_duration]);
				} else if (0 === addons_duration && wc_appointment_form_params.duration_changed !== addons_duration) {
					wc_appointment_form_params.duration_changed = false;
					form.triggerHandler('addon-duration-changed', [addons_duration]);
					addons_duration_only = true;
				} else {
					wc_appointment_form_params.duration_changed = false;
					form.triggerHandler('addon-duration-unchanged', [addons_duration]);
				}

				// Costs change triggers.
				if (0 !== addons_costs && wc_appointment_form_params.costs_changed !== addons_costs) {
					wc_appointment_form_params.costs_changed = addons_costs;
					form.triggerHandler('addon-costs-changed', [addons_costs]);
					addons_costs_only = true;
				} else if (0 !== addons_costs && wc_appointment_form_params.costs_changed === addons_costs) {
					wc_appointment_form_params.costs_changed = addons_costs;
					form.triggerHandler('addon-costs-unchanged', [addons_costs]);
				} else if (0 === addons_costs && !wc_appointment_form_params.costs_changed) {
					wc_appointment_form_params.costs_changed = false;
					form.triggerHandler('addon-costs-unchanged', [addons_costs]);
				} else if (0 === addons_costs && wc_appointment_form_params.costs_changed !== addons_costs) {
					wc_appointment_form_params.costs_changed = false;
					form.triggerHandler('addon-costs-changed', [addons_costs]);
					addons_costs_only = true;
				} else {
					wc_appointment_form_params.costs_changed = false;
					form.triggerHandler('addon-costs-unchanged', [addons_costs]);
				}

				// Only costs or only duration changed.
				if (addons_costs_only && !addons_duration_only) {
					form.triggerHandler('addon-costs-only-changed', [addons_costs]);
				} else if (!addons_costs_only && addons_duration_only) {
					form.triggerHandler('addon-duration-only-changed', [addons_duration]);
				} else if (addons_costs_only && addons_duration_only) {
					form.triggerHandler('addon-duration-and-costs-changed', [addons_duration]);
				}

				// Enable book now button when addons have no cost or duration.
				if (!addons_costs_only && !addons_duration_only && !check_add_to_cart_button_state) {
					form.find('.single_add_to_cart_button').prop('disabled', false);
				}

				form.triggerHandler('addon-selected');
			},
			on_deposit_option_changed: function () {
				var form = $(this).closest('form');

				if (form.attr('data-wca-recurring-active') === '1') {
					return wc_appointments_appointment_form.on_quantity_changed.call(this);
				}

				var anchor = form.find('input.required_for_calculation').filter(function () {
					return $(this).val();
				}).first();

				if (!anchor.length) {
					return;
				}

				wc_appointments_appointment_form.calculate_costs.call(anchor[0]);
			},
			on_quantity_changed: function () {
				var form = $(this).closest('form');

				if (form.attr('data-wca-recurring-active') === '1') {
					if (form[0] && typeof CustomEvent !== 'undefined') {
						form[0].dispatchEvent(new CustomEvent('wca:quantity-changed', { bubbles: true }));
					}
					return;
				}

				if (form.find('input.appointment_date_day').val()) {
					form.triggerHandler('quantity-changed');
				}
				wc_appointments_appointment_form.calculate_costs.call(this);
			},
			calculate_costs: function () {
				var name = $(this).attr('name');
				var form = $(this).closest('form');

				if (form.attr('data-wca-recurring-active') === '1') {
					return;
				}

				var required_fields = form.find('input.required_for_calculation');
				var filled = true;
				var picker = form.find('.picker:eq(0)');
				var duration_unit = picker.attr('data-duration_unit');

				//console.log( event );
				//console.log( duration_unit );

				// what does this line do?
				// when is range picker present?
				// if it is future implementation it should be removed
				if (picker.data('is_range_picker_enabled')) {
					if ('wc_appointments_field_duration' !== name) {
						return;
					}
				}

				$.each(required_fields, function (index, field) {
					var value = $(field).val();

					if (!value) {
						filled = false;
					}
				});

				if (!filled) {
					form.find('.wc-appointments-appointment-cost').hide();
					form.find('.wc-appointments-recurring-hook').hide();
					form.find('.wca-membership-footer').prop('hidden', true);

					return;
				}

				// form.find( '.wc-appointments-appointment-cost' ).block( { message: null, overlayCSS: { background: '#fff', backgroundSize: '16px 16px', opacity: 0.6 } } ).show();

				// Add loading bar.
				if (!form.find('.wc-appointments-appointment-cost .wca-loading-bar').length) {
					form.find('.wc-appointments-appointment-cost').append('<div class="wca-loading-bar"></div>');
				}
				form.find('.wc-appointments-appointment-cost .wca-loading-bar').addClass('is-active');
				form.find('.wc-appointments-appointment-cost').show();

				form.find('.single_add_to_cart_button').prop('disabled', true);

				// Prevent stale cost responses when date/time changes rapidly (per cart form, not form.index()).
				var previousCostXhr = form.data('wca-cost-xhr');
				if (previousCostXhr && previousCostXhr.abort) {
					previousCostXhr.abort();
				}

				var costRequestId = (form.data('wca-cost-request-id') || 0) + 1;
				form.data('wca-cost-request-id', costRequestId);

				var costXhr = $.ajax({
					type: 'POST',
					url: wc_appointment_form_params.ajax_url,
					data: {
						action: 'wc_appointments_calculate_costs',
						form: form.serialize()
					},
					success: function (code) {
						if (costRequestId !== form.data('wca-cost-request-id')) {
							return;
						}

						var result;
						try {
							if (typeof code !== 'string') {
								result = code;
							} else if ('{' !== code.charAt(0)) {
								code = '{' + code.split(/{(.+)?/)[1];
								result = JSON.parse(code);
							} else {
								result = JSON.parse(code);
							}
						} catch (e) {
							form.find('.wc-appointments-appointment-cost .wca-loading-bar').removeClass('is-active');
							form.find('.single_add_to_cart_button').prop('disabled', true);
							return;
						}

						var errorHtml = (result.data && result.data.html) ? result.data.html : result.html;

						if ('ERROR' === result.result) {
							// Always show the error and stop loading so the user sees the message.
							form.find('.wc-appointments-appointment-cost').html(errorHtml || '');
							form.find('.wc-appointments-appointment-cost').show();
							form.find('.wc-appointments-appointment-cost .wca-loading-bar').removeClass('is-active');
							form.find('.wca-membership-footer').prop('hidden', true);
							form.find('.single_add_to_cart_button').prop('disabled', true);

							// Optionally try autoselect for month picker when this month is unavailable (e.g. fully booked).
							if ('month' === duration_unit && !form.data('autoselect-in-progress')) {
								var picker = form.find('.picker:eq(0)');
								var available_slots = picker.find('li.slot:not(".slot_empty,.fully_scheduled,.partial_scheduled")');
								if (0 < available_slots.length) {
									form.data('autoselect-in-progress', true);
									form.triggerHandler('month-unavailable-autoselect');
								}
							}
						} else if ('SUCCESS' === result.result) {
							form.find('.wc-appointments-appointment-cost').html(result.html);
							form.find('.wc-appointments-appointment-cost .wca-loading-bar').removeClass('is-active');
							form.find('.wc-appointments-recurring-hook').show();
							form.find('.wca-membership-footer').prop('hidden', false);
							form.find('.single_add_to_cart_button').prop('disabled', false);
							form.triggerHandler('appointment-cost-success', [form, result.html]);
						} else {
							form.find('.wc-appointments-appointment-cost').hide();
							form.find('.wc-appointments-recurring-hook').hide();
							form.find('.wca-membership-footer').prop('hidden', true);
							form.find('.wc-appointments-appointment-cost .wca-loading-bar').removeClass('is-active');
							form.find('.single_add_to_cart_button').prop('disabled', true);
						}
					},
					error: function (jqXHR, textStatus) {
						if ('abort' === textStatus) {
							return;
						}

						if (costRequestId !== form.data('wca-cost-request-id')) {
							return;
						}

						form.find('.wc-appointments-appointment-cost').hide();
						form.find('.wc-appointments-appointment-cost .wca-loading-bar').removeClass('is-active');
						form.find('.wca-membership-footer').prop('hidden', true);
						form.find('.single_add_to_cart_button').prop('disabled', true);
					},
					dataType: 'html'
				});

				form.data('wca-cost-xhr', costXhr);
			},

			update_querystring: function (action) {
				var form = $(this).closest('form');

				if (!wc_appointment_form_params.is_admin) {
					wc_appointments_appointment_form.set_querystring_data(form, action);
				}
			},

			// Sync appointment selection into the URL (single replaceState via wca_update_querystring).
			set_querystring_data: function (form, action) {
				if (!window.history || !window.history.pushState) {
					return;
				}

				var year = form.find('input.appointment_date_year').val();
				var month = form.find('input.appointment_date_month').val();
				var day = form.find('input.appointment_date_day').val();
				var time = form.find('#wc_appointments_field_start_date');
				var date_m = form.find('input#wc_appointments_field_start_date').val();
				var staff = form.find('#wc_appointments_field_staff');
				var location = form.find('#wc_appointments_field_location, .wc_appointment_field_location select').first();
				var date = date_m && !year && !month && !day ? date_m : year + '-' + month + '-' + day;
				var time_v = 'undefined' !== typeof time.attr('data-value') ? time.attr('data-value') : '';

				var date_url = year && month && day ? date : null;
				if (date_m && !year && !month && !day && wca_is_valid_date(date_m)) {
					date_url = date_m; // month querystring
				}

				// null/'' deletes; omit key to leave alone. Date/time only set when present
				// (clears go through wca_clear_date_selection). Staff/location sync only on their events.
				var updates = {};
				if (date_url) {
					updates.date = date_url;
				}
				if (0 < time.length && '' !== time.val() && time_v) {
					updates.time = time_v;
				}
				if ('staff-selected' === action.type) {
					updates.staff = (0 < staff.length && '' !== staff.val()) ? staff.val() : null;
				}
				if ('location-selected' === action.type) {
					updates.location = (0 < location.length && parseInt(location.val(), 10) > 0) ? location.val() : null;
				}
				wca_update_querystring(updates);
			},

			// WooCommerce TM Extra Product Options integration.
			tm_epo_integration: function (event, form, result_html) {
				if (window.hasOwnProperty('tm_epo_js') || window.hasOwnProperty('TMEPOJS')) {
					var tm_epo_totals_form = form.find('.tc-totals-form');
					var tm_epo_totals_container = form.find('.tc-epo-totals');

					if (tm_epo_totals_form && tm_epo_totals_container) {
						//var tm_epo_pp = parseFloat( tm_epo_totals_container.data( 'tc_totals_ob' ).options_total_price );
						var tm_epo_pp = parseFloat($.epoAPI.util.unformat($('<div>' + result_html + '</div>').find('.amount').text()));

						tm_epo_totals_container.data('price', tm_epo_pp);
						tm_epo_totals_form.find('.cpf-product-price').val(tm_epo_pp);
						form.trigger({
							'type': 'tm-epo-update'
						});
					}
				}
			}
		};

		wc_appointments_appointment_form.init();
	}

	// jQuery + localize params (optimizers often delay both).
	var appointmentFormInitialized = false;
	wcaShared.whenDepsReady(
		function () {
			return typeof jQuery !== 'undefined' && typeof wc_appointment_form_params !== 'undefined';
		},
		function () {
			if (appointmentFormInitialized) {
				return;
			}
			appointmentFormInitialized = true;
			initAppointmentFormWrapper(jQuery);
		},
		'appointment-form'
	);
})();

// Gets parameter value from the querystring using its key.
/* exported wca_get_querystring */
function wca_get_querystring(key) {
	'use strict';

	key = key.replace(/[*+?^$.\[\]{}()|\/]/g, '\\$&'); // escape RegEx meta chars
	var match = location.search.match(new RegExp('[?&]' + key + '=([^&]+)(&|$)'));

	return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
}

// Checks if date string is valid.
/* exported wca_is_valid_date */
function wca_is_valid_date(string) {
	'use strict';

	var comp = string.split('-');
	var y = parseInt(comp[0], 10);
	var m = parseInt(comp[1], 10);
	var d = parseInt(comp[2], 10);
	var date = new Date(y, m - 1, d);

	if (y === date.getFullYear() && m === date.getMonth() + 1 && d === date.getDate()) {
		return true;
	} else {
		return false;
	}
}

// Get browser cookie by name.
/* exported wca_get_cookie */
function wca_get_cookie(name) {
	'use strict';

	var nameEQ = name + '=';
	var ca = document.cookie.split(';');
	for (var i = 0; ca.length > i; i++) {
		var c = ca[i];
		while (' ' === c.charAt(0)) {
			c = c.substring(1, c.length);
		}
		if (0 === c.indexOf(nameEQ)) {
			return c.substring(nameEQ.length, c.length);
		}
	}

	return null;
}

// Set browser cookie by name, value and expiration in days.
/* exported wca_set_cookie */
function wca_set_cookie(name, value, days) {
	'use strict';

	var expires = '';

	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		expires = '; expires=' + date.toUTCString();
	}

	document.cookie = name + '=' + (value || '') + expires + '; path=/';
}

/**
 * Format date using WordPress date format + WP locale month/day names.
 * Uses monthNames / dayNames from wc_appointment_form_params (same as the datepicker),
 * not the browser locale (toLocaleDateString would ignore the site language).
 */
function wca_format_date(date, format) {
	if (!(date instanceof Date) || isNaN(date.getTime())) {
		return '';
	}

	if (!format) {
		format = 'F j, Y';
	}

	var params = (typeof wc_appointment_form_params !== 'undefined') ? wc_appointment_form_params : {};
	var monthsFull = params.monthNames || [
		'January', 'February', 'March', 'April', 'May', 'June',
		'July', 'August', 'September', 'October', 'November', 'December'
	];
	var monthsShort = params.monthNamesShort || [
		'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
		'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
	];
	var daysFull = params.dayNames || [
		'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
	];
	var daysShort = params.dayNamesShort || [
		'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'
	];

	function pad(n) {
		return n < 10 ? '0' + n : String(n);
	}

	var mIndex = date.getMonth();
	var dayNum = date.getDate();
	var year = date.getFullYear();
	var weekday = date.getDay();
	var tokens = {
		F: monthsFull[mIndex] || '',
		M: monthsShort[mIndex] || '',
		m: pad(mIndex + 1),
		n: String(mIndex + 1),
		d: pad(dayNum),
		j: String(dayNum),
		Y: String(year),
		y: String(year).slice(-2),
		l: daysFull[weekday] || '',
		D: daysShort[weekday] || ''
	};

	// Walk so PHP \ escapes stay literal (e.g. pt_PT "\d\e" → "de", not day token d).
	var out = '';
	var src = String(format);
	for (var i = 0; i < src.length; i++) {
		var ch = src.charAt(i);
		if (ch === '\\') {
			out += i + 1 < src.length ? src.charAt(++i) : '\\';
			continue;
		}
		out += Object.prototype.hasOwnProperty.call(tokens, ch) ? tokens[ch] : ch;
	}
	return out;
}

/**
 * Format time using WordPress time format (Settings → General).
 */
function wca_format_time(time_str, format) {
	// Parse time string (e.g., "10:30 AM", "14:30")
	var time_parts = String(time_str).match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
	if (!time_parts) {
		return time_str; // Return original if can't parse
	}

	var hours = parseInt(time_parts[1], 10);
	var minutes = parseInt(time_parts[2], 10);
	var period = time_parts[3] ? time_parts[3].toUpperCase() : '';

	// Convert to 24-hour format for easier manipulation
	if (period === 'PM' && hours < 12) {
		hours += 12;
	} else if (period === 'AM' && hours === 12) {
		hours = 0;
	}

	// Default format if none provided
	if (!format) {
		format = 'g:i a';
	}

	function pad(n) {
		return n < 10 ? '0' + n : String(n);
	}

	var formatted_time = '';

	// Handle different time formats
	if (format.indexOf('g') !== -1 || format.indexOf('h') !== -1) {
		// 12-hour format
		var display_hours = hours % 12;
		if (display_hours === 0) {
			display_hours = 12;
		}

		var display_period = '';
		if (format.indexOf('A') !== -1) {
			display_period = hours >= 12 ? 'PM' : 'AM';
		} else if (format.indexOf('a') !== -1) {
			display_period = hours >= 12 ? 'pm' : 'am';
		}

		if (format.indexOf('h') !== -1) {
			display_hours = pad(display_hours);
		}

		formatted_time = display_hours + ':' + pad(minutes);
		if (display_period) {
			formatted_time += ' ' + display_period;
		}
	} else {
		// 24-hour format (G or H)
		var display_24 = format.indexOf('H') !== -1 ? pad(hours) : String(hours);
		formatted_time = display_24 + ':' + pad(minutes);
	}

	return formatted_time;
}

/**
 * Update querystring parameter(s) without reload.
 * Pass (key, value) or a map { key: value }. null/'' deletes that key.
 */
function wca_update_querystring(key, value) {
	var params = ('object' === typeof key && null !== key) ? key : {};
	if ('string' === typeof key) {
		params[key] = value;
	}

	var url = new URL(window.location);
	var k;
	for (k in params) {
		if (!Object.prototype.hasOwnProperty.call(params, k)) {
			continue;
		}
		if (null === params[k] || '' === params[k]) {
			url.searchParams.delete(k);
		} else {
			url.searchParams.set(k, params[k]);
		}
	}

	var newUrl = url.toString();
	if (window.location.toString() !== newUrl) {
		history.replaceState({}, '', newUrl);
	}
}

/**
 * Clear date selection - common function for both date and datetime pickers
 */
function wca_clear_date_selection(form) {
	var fieldset = form.find('.wc-appointments-date-picker');
	var picker = fieldset.find('.picker');

	// Clear date fields
	fieldset.find('input.appointment_date_year').val('');
	fieldset.find('input.appointment_date_month').val('');
	fieldset.find('input.appointment_date_day').val('');

	// Clear time fields if they exist
	form.find('.slot-picker').parent('div').find('input').val('').removeAttr('data-value').removeAttr('data-slot-timestamp');
	form.find('.slot-timestamp-field').val('');

	// Clear time selection
	form.find('.slot-picker li').removeClass('selected');
	form.find('.slot-picker').hide().empty();

	// Reset calendar selection if using datepicker
	if (picker.hasClass('hasDatepicker')) {
		picker.datepicker('setDate', null);
		// Remove selected class from calendar days
		picker.find('.ui-datepicker-current-day').removeClass('ui-datepicker-current-day');
		picker.find('td a').removeClass('ui-state-active ui-state-highlight');
	}

	// Disable submit button
	form.find('.wc-appointments-appointment-form-button').prop('disabled', true);

	// Hide add-ons, recurring picker, and cost
	form.find('.wc-appointments-appointment-hook-after, .wc-appointments-recurring-hook').hide();
	form.find('.wc-appointments-appointment-cost').hide();

	// Update selection info display
	wca_update_selection_info(form, null);

	// Remove date and time from querystring
	wca_update_querystring({ date: null, time: null });

	// Trigger date cleared event
	form.triggerHandler('date-cleared');
}

/**
 * Update selection info display - simplified version
 * Only updates date and time display, leaves static elements unchanged
 */
function wca_update_selection_info(form, date, time) {
	var selection_info = form.find('.wc-appointments-selection-info');
	var placeholder = selection_info.find('.wc-appointments-selection-placeholder');
	var date_display = selection_info.find('.wc-appointments-selection-date');
	var time_prompt = selection_info.find('.wc-appointments-selection-time-prompt');
	var time_display = selection_info.find('.wc-appointments-selection-time');
	var clear_date_button = selection_info.find('.wc-appointments-selection-clear-date');
	var clear_time_button = selection_info.find('.wc-appointments-selection-clear-time');

	if (date) {
		// Format and show date
		var parsed_date = date.split('-');
		var year = parseInt(parsed_date[0], 10);
		var month = parseInt(parsed_date[1], 10);
		var day = parseInt(parsed_date[2], 10);
		var date_obj = new Date(year, month - 1, day);
		var fmt = wc_appointment_form_params.date_format;
		var formatted_date = wca_format_date(date_obj, fmt);

		// Multi-day/night/month: append end date when span > 1 (calendar already highlights the range).
		var picker = form.find('.picker').first();
		var unit = picker.attr('data-duration_unit') || '';
		var days = parseInt(picker.data('combined_duration') || picker.attr('data-appointment_duration'), 10) || 1;
		if (days > 1 && unit !== 'minute' && unit !== 'hour' && 'start' !== picker.attr('data-availability_span')) {
			var end_obj = new Date(year, month - 1, day);
			end_obj.setDate(end_obj.getDate() + days - 1);
			var end_str = wca_format_date(end_obj, fmt);
			// Same month: "October 28 - 29, 2026". Cross-month keeps both full dates.
			if (date_obj.getFullYear() === end_obj.getFullYear() && date_obj.getMonth() === end_obj.getMonth()) {
				var pad = /(^|[^\\])d/.test(fmt);
				var start_day = pad && day < 10 ? '0' + day : String(day);
				var end_day = pad && end_obj.getDate() < 10 ? '0' + end_obj.getDate() : String(end_obj.getDate());
				var idx = formatted_date.indexOf(start_day);
				formatted_date = idx !== -1
					? formatted_date.slice(0, idx) + start_day + ' - ' + end_day + formatted_date.slice(idx + start_day.length)
					: formatted_date + ' - ' + end_str;
			} else {
				formatted_date += ' - ' + end_str;
			}
		}

		placeholder.hide();
		date_display.text(formatted_date).show();
		clear_date_button.show();

		// Handle time display (only for datetime pickers)
		if (time_prompt.length) {
			if (time) {
				var display_time = time;
				// Prefer WP time_format when a raw clock string is passed (slot path uses display_time_formatted).
				if (typeof wca_format_time === 'function' && wc_appointment_form_params.time_format
					&& /^\d{1,2}:\d{2}(\s*(AM|PM))?$/i.test(String(time).trim())) {
					display_time = wca_format_time(time, wc_appointment_form_params.time_format);
				}
				time_prompt.hide();
				time_display.text(display_time).show();
				clear_time_button.show();
			} else {
				// Check if there are any available slots before showing "Select time below"
				var slot_picker = form.find('.slot-picker');
				var available_slots = slot_picker.find('li.slot:not(.slot_empty)');
				if (available_slots.length > 0) {
					time_prompt.show();
				} else {
					time_prompt.hide();
				}
				time_display.hide();
				clear_time_button.hide();
			}
		}
	} else {
		// No date - show placeholder, hide date/time
		placeholder.show();
		date_display.hide().text('');
		time_display.hide().text('');
		clear_date_button.hide();
		clear_time_button.hide();

		// Only hide time prompt if it's a datetime picker
		if (time_prompt.length) {
			time_prompt.hide();
		}
	}
}

// Make functions globally available (needed when files are bundled with esbuild)
if (typeof window !== 'undefined') {
	window.wca_get_querystring = wca_get_querystring;
	window.wca_is_valid_date = wca_is_valid_date;
	window.wca_get_cookie = wca_get_cookie;
	window.wca_set_cookie = wca_set_cookie;
	window.wca_format_date = wca_format_date;
	window.wca_format_time = wca_format_time;
	window.wca_update_querystring = wca_update_querystring;
	window.wca_clear_date_selection = wca_clear_date_selection;
	window.wca_update_selection_info = wca_update_selection_info;
}
