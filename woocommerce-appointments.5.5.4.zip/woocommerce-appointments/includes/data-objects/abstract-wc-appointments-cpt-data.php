<?php
/**
 * Shared WC_Data base for location/resource CPTs.
 *
 * Posts are created/trashed by WordPress; this object hydrates and saves meta.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * @since 5.5.0
 */
abstract class WC_Appointments_CPT_Data extends WC_Data implements WC_Appointments_Data_Object_Interface {

	abstract protected function data_store_key(): string;

	/**
	 * @param int|static|object $item ID or object.
	 */
	public function __construct( $item = 0 ) {
		parent::__construct( $item );

		if ( is_numeric( $item ) && $item > 0 ) {
			$this->set_id( $item );
		} elseif ( $item instanceof static ) {
			$this->set_id( $item->get_id() );
		} elseif ( is_object( $item ) && ! empty( $item->ID ) ) {
			$this->set_id( $item->ID );
		} else {
			$this->set_object_read( true );
		}

		$this->data_store = WC_Data_Store::load( $this->data_store_key() );
		if ( $this->get_id() > 0 ) {
			$this->data_store->read( $this );
		}
	}

	public function get_date_created( $context = 'view' ) {
		return $this->get_prop( 'date_created', $context );
	}

	public function get_date_modified( $context = 'view' ) {
		return $this->get_prop( 'date_modified', $context );
	}

	public function get_name( string $context = 'view' ): string {
		return (string) $this->get_prop( 'name', $context );
	}

	public function get_status( string $context = 'view' ): string {
		return (string) $this->get_prop( 'status', $context );
	}

	/**
	 * @param string $prop    Prop.
	 * @param string $context view|edit.
	 * @return mixed
	 */
	public function get_field( string $prop, string $context = 'view' ) {
		return $this->get_prop( $prop, $context );
	}

	/** @param array<string, mixed> $fields Prop => value. */
	public function set_fields( array $fields ): void {
		foreach ( $fields as $prop => $value ) {
			$this->set_prop( $prop, $value );
		}
	}

	public function save() {
		if ( ! $this->data_store || ! $this->get_id() ) {
			return $this->get_id();
		}
		$this->data_store->update( $this );
		return $this->get_id();
	}

	public function delete( $force_delete = false ) {
		if ( ! $this->data_store ) {
			return false;
		}
		$this->data_store->delete( $this, [ 'force_delete' => (bool) $force_delete ] );
		return true;
	}
}
