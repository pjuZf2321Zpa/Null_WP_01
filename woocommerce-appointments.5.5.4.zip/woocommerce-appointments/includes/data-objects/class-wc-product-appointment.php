<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class for the appointment product type.
 */
class WC_Product_Appointment extends WC_Product {

	/**
	 * Quantity basis constants.
	 */
	public const QTY_BASIS_SLOT = 'slot';
	public const QTY_BASIS_DAY = 'day';

	/**
	 * Duration unit constants.
	 */
	public const DURATION_UNIT_MINUTE = 'minute';
	public const DURATION_UNIT_HOUR = 'hour';
	public const DURATION_UNIT_DAY = 'day';
	public const DURATION_UNIT_MONTH = 'month';

	/**
	 * Stores product data.
	 *
	 * @var array<string, mixed>
	 */
	protected array $defaults = [
		'has_price_label'         => false,
		'price_label'             => '',
		'has_pricing'             => false,
		'pricing'                 => [],
		'qty'                     => 1,
		'qty_basis'               => self::QTY_BASIS_SLOT,
		'qty_min'                 => 1,
		'qty_max'                 => 1,
		'duration_unit'           => self::DURATION_UNIT_HOUR,
		'duration'                => 1,
		'interval_unit'           => self::DURATION_UNIT_HOUR,
		'interval'                => 1,
		'padding_duration_unit'   => self::DURATION_UNIT_HOUR,
		'padding_duration'        => 0,
		'padding_after_duration'  => 0,
		'min_date_unit'           => self::DURATION_UNIT_DAY,
		'min_date'                => 0,
		'max_date_unit'           => self::DURATION_UNIT_MONTH,
		'max_date'                => 12,
		'user_can_cancel'         => false,
		'cancel_limit_unit'       => self::DURATION_UNIT_DAY,
		'cancel_limit'            => 1,
		'user_can_reschedule'     => false,
		'reschedule_limit_unit'   => self::DURATION_UNIT_DAY,
		'reschedule_limit'        => 1,
		'requires_confirmation'   => false,
		'cal_color'               => '',
		'availability_span'       => '',
		'availability_autoselect' => false,
		'has_restricted_days'     => false,
		'restricted_days'         => [],
		/*'availability'            => [],*/
		'staff_label'             => '',
		'staff_assignment'        => '',
		'staff_nopref'            => false,
		'staff_id'                => [],
		'staff_ids'               => [],
		'staff_base_costs'        => [],
		'staff_qtys'              => [],
		'location_mode'           => 'none',
		'location_ids'            => [],
		'location_costs'          => [],
		'location_label'          => '',
		'resource_requirements'   => [],
		'resource_label'          => '',
		'resource_assignment'     => 'display',
		'meeting_provider'        => 'none',
	];

	/**
	 * Stores availability rules once loaded.
	 *
	 * @var array<string, array<int, array<string, mixed>>>
	 */
	public array $availability_rules = [];

	/**
	 * Stores staff ID if auto assigned.
	 *
	 * @var int|false
	 */
	public $assigned_staff_id = false;

	/**
	 * Merges appointment product data into the parent object.
	 *
	 * @param int|WC_Product|object $product Product to init.
	 */
	public function __construct( $product = 0 ) {
		/**
		 * Override default attributes for Product Appointment.
		 *
		 * @since 4.14.4
		 *
		 * @param array $defaults Default values to init new Product.
		 * @param int|WC_Product|object $product Product to init.
		 *
		 * @see WC_Product_Appointment::defaults
		 */
		$defaults   = apply_filters( 'woocommerce_appointments_product_defaults', $this->defaults, $product );
		$this->data = array_merge( $this->data, $defaults );
		parent::__construct( $product );
	}

	/**
	 * Get the add to cart button text
	 *
	 * @return string
	 */
	public function add_to_cart_text() {
		return apply_filters( 'woocommerce_appointment_add_to_cart_text', __( 'Book', 'woocommerce-appointments' ), $this );
	}

	/**
	 * Get the add to cart button text for the single page
	 *
	 * @return string
	 */
	public function single_add_to_cart_text() {
		return $this->get_requires_confirmation() ? apply_filters( 'woocommerce_appointment_single_check_availability_text', __( 'Check Availability', 'woocommerce-appointments' ), $this ) : apply_filters( 'woocommerce_appointment_single_add_to_cart_text', __( 'Book Now', 'woocommerce-appointments' ), $this );
	}

	/**
	 * Return if appointment has label
	 * @return bool
	 */
	public function has_price_label() {
		$has_price_label = false;

		// Products must exist of course
		if ( $this->get_has_price_label() ) {
			$price_label     = $this->get_price_label();
			$has_price_label = $price_label ?: __( 'Price Varies', 'woocommerce-appointments' );
		}

		return $has_price_label;
	}

	/**
	 * Get price HTML
	 *
	 * @param string $deprecated Deprecated argument.
	 * @return string
	 */
	public function get_price_html( $deprecated = '' ) {
		$sale_price    = wc_format_sale_price(
		    wc_get_price_to_display(
		        $this,
		        [
					'qty'   => 1,
					'price' => $this->get_regular_price(),
				],
		    ),
		    wc_get_price_to_display( $this ),
		) . $this->get_price_suffix();
		$regular_price = wc_price( floatval( wc_get_price_to_display( $this ) ) ) . $this->get_price_suffix();

		// Price.
		if ( '' === $this->get_price() ) {
			$price = apply_filters( 'woocommerce_empty_price_html', '<span class="amount">' . __( 'Free!', 'woocommerce-appointments' ) . '</span>', $this );
		} elseif ( $this->is_on_sale() ) {
			$price = $sale_price;
		} else {
			$price = $regular_price;
		}

		// Default price display.
		$price_html = $price;

		// Price with additional cost.
		if ( $this->has_additional_costs() ) {
			/* translators: %s: display price */
			$price_html = sprintf( __( 'From: %s', 'woocommerce-appointments' ), $price );
		}

		// Price label.
		if ( $this->has_price_label() ) {
			$price_html = $this->has_price_label();
		}

		// Duration HTML label.
		if ( self::DURATION_UNIT_MONTH === $this->get_duration_unit() ) {
			/* translators: %s: months in singular or plural */
			$duration_html = ' <small class="duration">' . sprintf( _n( '%s month', '%s months', $this->get_duration(), 'woocommerce-appointments' ), $this->get_duration() ) . '</small>';
		} elseif ( self::DURATION_UNIT_DAY === $this->get_duration_unit() ) {
			/* translators: %s: days in singular or plural */
			$duration_html = ' <small class="duration">' . sprintf( _n( '%s day', '%s days', $this->get_duration(), 'woocommerce-appointments' ), $this->get_duration() ) . '</small>';
		// Hourly or minutes product duration sets add-on duration in minutes.
		} else {
			$duration_full = WC_Appointment_Duration::format_minutes( $this->get_duration_in_minutes(), WC_Appointments_Constants::DURATION_MINUTE );
			$duration_html = ' <small class="duration">' . $duration_full . '</small>';
		}

		return apply_filters( 'woocommerce_get_price_html', apply_filters( 'woocommerce_return_price_html', $price_html, $this ) . apply_filters( 'woocommerce_return_duration_html', $duration_html, $this ), $this );
	}

	/**
	 * Get cost HTML
	 *
	 * @param float $cost Base cost.
	 * @return string
	 */
	public function get_cost_html( float $cost = 0 ): string {
		$display_price = wc_get_price_to_display(
			$this,
			[
				'qty'   => 1,
				'price' => $cost,
			]
		);

		return apply_filters(
			'woocommerce_get_cost_html',
			wc_price( $display_price ) . $this->get_price_suffix( $cost, 1 ),
			$this
		);
	}

	/**
	 * Get internal type.
	 *
	 * @return string
	 */
	public function get_type() {
		return 'appointment';
	}

	/**
	 * @since 3.0.0
	 * @return bool
	 */
	public function is_wc_appointment_has_staff(): bool {
		return $this->has_staff();
	}

	/*
	|--------------------------------------------------------------------------
	| CRUD Getters and setters.
	|--------------------------------------------------------------------------
	*/

	/**
	 * Returns whether the product has additional costs.
	 *
	 * @param  string $context
	 * @return boolean
	 */
	public function get_has_additional_costs( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'has_additional_costs', $context );
	}

	/**
	 * Set has_additional_costs.
	 *
	 * @param boolean $value
	 */
	public function set_has_additional_costs( $value ): void {
		$this->set_prop( 'has_additional_costs', wc_appointments_string_to_bool( $value ) );
	}

	/**
	 * Returns whether the product has a custom price label.
	 *
	 * @param  string $context
	 * @return boolean
	 */
	public function get_has_price_label( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'has_price_label', $context );
	}

	/**
	 * Set has_price_label.
	 *
	 * @param boolean $value
	 */
	public function set_has_price_label( $value ): void {
		$this->set_prop( 'has_price_label', $value );
	}

	/**
	 * Returns the custom price label.
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_price_label( string $context = 'view' ): string {
		return (string) $this->get_prop( 'price_label', $context );
	}

	/**
	 * Set get_price_label.
	 *
	 * @param string $value
	 */
	public function set_price_label( $value ): void {
		$this->set_prop( 'price_label', $value );
	}

	/**
	 * Returns whether the product has custom pricing rules.
	 *
	 * @param  string $context
	 * @return boolean
	 */
	public function get_has_pricing( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'has_pricing', $context );
	}

	/**
	 * Set has_pricing.
	 *
	 * @param boolean $value
	 */
	public function set_has_pricing( $value ): void {
		$this->set_prop( 'has_pricing', $value );
	}

	/**
	 * Get pricing_rules.
	 *
	 * @param  string $context
	 * @return array<int, array<string, mixed>>
	 */
	public function get_pricing( string $context = 'view' ): array {
		return (array) $this->get_prop( 'pricing', $context );
	}

	/**
	 * Set pricing_rules.
	 *
	 * @param array<int, array<string, mixed>> $value
	 */
	public function set_pricing( $value ): void {
		$this->set_prop( 'pricing', (array) $value );
	}

	/**
	 * Returns the quantity available to schedule per slot.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_qty( string $context = 'view' ): int {
		return (int) $this->get_prop( 'qty', $context );
	}

	/**
	 * Set qty.
	 *
	 * @param integer $value
	 */
	public function set_qty( $value ): void {
		$this->set_prop( 'qty', absint( $value ) );
	}

	/**
	 * Get min qty available to schedule per slot.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_qty_min( string $context = 'view' ): int {
		return (int) $this->get_prop( 'qty_min', $context );
	}

	/**
	 * Set min qty.
	 *
	 * @param integer $value
	 */
	public function set_qty_min( $value ): void {
		$this->set_prop( 'qty_min', absint( $value ) );
	}
	/**
	 * Returns the maximum quantity allowed to schedule per slot.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_qty_max( string $context = 'view' ): int {
		return (int) $this->get_prop( 'qty_max', $context );
	}

	/**
	 * Set max qty.
	 *
	 * @param integer $value
	 */
	public function set_qty_max( $value ): void {
		$this->set_prop( 'qty_max', absint( $value ) );
	}

	/**
	 * Returns how quantity is applied (per slot or per day).
	 *
	 * @param string $context
	 * @return string
	 */
	public function get_qty_basis( string $context = 'view' ): string {
		$basis = $this->get_prop( 'qty_basis', $context );

		return in_array( $basis, [ self::QTY_BASIS_DAY, self::QTY_BASIS_SLOT ], true ) ? (string) $basis : self::QTY_BASIS_SLOT;
	}

	/**
	 * Set how quantity is applied (per slot or per day).
	 *
	 * @param string $value
	 */
	public function set_qty_basis( $value ): void {
		$basis = in_array( $value, [ self::QTY_BASIS_DAY, self::QTY_BASIS_SLOT ], true ) ? $value : self::QTY_BASIS_SLOT;
		$this->set_prop( 'qty_basis', $basis );
	}

	/**
	 * Helper to check if quantity is enforced per day.
	 *
	 * @return bool
	 */
	public function is_qty_per_day(): bool {
		return self::QTY_BASIS_DAY === $this->get_qty_basis();
	}

	/**
	 * Returns the duration unit (minute, hour, day, month).
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_duration_unit( string $context = 'view' ): string {
		$value = $this->get_prop( 'duration_unit', $context );

		if ('view' === $context) {
            return (string) apply_filters( 'woocommerce_appointments_get_duration_unit', $value, $this );
        }
		return (string) $value;
	}

	/**
	 * Set duration_unit.
	 *
	 * @param string $value
	 */
	public function set_duration_unit( $value ): void {
		$this->set_prop( 'duration_unit', (string) $value );
	}

	/**
	 * Returns the duration of the appointment.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_duration( string $context = 'view' ): int {
		$value = $this->get_prop( 'duration', $context );

		if ('view' === $context) {
            return (int) apply_filters( 'woocommerce_appointments_get_duration', $value, $this );
        }

		return (int) $value;
	}

	/**
	 * Get duration in minutes.
	 *
	 * @return integer
	 */
	public function get_duration_in_minutes(): int {
		$duration = self::DURATION_UNIT_HOUR === $this->get_duration_unit() ? $this->get_duration() * 60 : $this->get_duration();
		$duration = self::DURATION_UNIT_DAY === $this->get_duration_unit() ? $this->get_duration() * 60 * 24 : $duration;
		// Night spans civil days like day-unit (1 night = 1440 minutes).
		$duration = WC_Appointments_Constants::DURATION_NIGHT === $this->get_duration_unit() ? $this->get_duration() * 60 * 24 : $duration;
		$duration = self::DURATION_UNIT_MONTH === $this->get_duration_unit() ? $this->get_duration() : $duration;

		return (int) apply_filters( 'woocommerce_appointments_get_duration_in_minutes', $duration, $this );
	}

	/**
	 * Set duration.
	 *
	 * @param integer $value
	 */
	public function set_duration( $value ): void {
		$this->set_prop( 'duration', absint( $value ) );
	}

	/**
	 * Returns the interval unit (minute, hour, day, month).
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_interval_unit( string $context = 'view' ): string {
		$value = $this->get_prop( 'interval_unit', $context );

		if ('view' === $context) {
            return (string) apply_filters( 'woocommerce_appointments_get_interval_unit', $value, $this );
        }
		return (string) $value;
	}

	/**
	 * Set interval_unit.
	 *
	 * @param string $value
	 */
	public function set_interval_unit( $value ): void {
		$this->set_prop( 'interval_unit', (string) $value );
	}

	/**
	 * Returns the interval between appointments.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_interval( string $context = 'view' ): int {
		return (int) $this->get_prop( 'interval', $context );
	}

	/**
	 * Set interval.
	 *
	 * @param integer $value
	 */
	public function set_interval( $value ): void {
		$this->set_prop( 'interval', absint( $value ) );
	}

	/**
	 * Get padding_duration_unit.
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_padding_duration_unit( string $context = 'view' ): string {
		$value = $this->get_prop( 'padding_duration_unit', $context );

		if ('view' === $context) {
            return (string) apply_filters( 'woocommerce_appointments_get_padding_duration_unit', $value, $this );
        }

		return (string) $value;
	}

	/**
	 * Set padding_duration_unit.
	 *
	 * @param string $value
	 */
	public function set_padding_duration_unit( $value ): void {
		$this->set_prop( 'padding_duration_unit', (string) $value );
	}

	/**
	 * Get padding_duration.
	 *
	 * This is the buffer BEFORE an appointment. The historical field name is kept
	 * to avoid a data migration; prefer get_padding_before_in_minutes() in new code.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_padding_duration( string $context = 'view' ): int {
		$value = $this->get_prop( 'padding_duration', $context );

		if ('view' === $context) {
            return (int) apply_filters( 'woocommerce_appointments_get_padding_duration', $value, $this );
        }

		return (int) $value;
	}

	/**
	 * Convert a padding value + the shared padding unit to minutes.
	 *
	 * @param int $value Raw padding value in the product's padding unit.
	 * @return int
	 */
	private function padding_value_to_minutes( int $value ): int {
		$unit     = $this->get_padding_duration_unit();
		$duration = self::DURATION_UNIT_HOUR === $unit ? $value * 60 : $value;
		$duration = self::DURATION_UNIT_DAY === $unit ? $value * 60 * 24 : $duration;
		$duration = self::DURATION_UNIT_MONTH === $unit ? $value : $duration;

		return (int) $duration;
	}

	/**
	 * Get duration in minutes for padding between appointments (buffer BEFORE).
	 *
	 * @return integer
	 */
	public function get_padding_duration_in_minutes(): int {
		$duration = $this->padding_value_to_minutes( $this->get_padding_duration() );

		return (int) apply_filters( 'woocommerce_appointments_get_padding_duration_in_minutes', $duration, $this );
	}

	/**
	 * Alias of get_padding_duration_in_minutes(): buffer BEFORE an appointment.
	 *
	 * @return integer
	 */
	public function get_padding_before_in_minutes(): int {
		return $this->get_padding_duration_in_minutes();
	}

	/**
	 * Set padding_duration (buffer BEFORE an appointment).
	 *
	 * @param integer $value
	 */
	public function set_padding_duration( $value ): void {
		$this->set_prop( 'padding_duration', absint( $value ) );
	}

	/**
	 * Get padding_after_duration (buffer AFTER an appointment).
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_padding_after_duration( string $context = 'view' ): int {
		$value = $this->get_prop( 'padding_after_duration', $context );

		if ( 'view' === $context ) {
			return (int) apply_filters( 'woocommerce_appointments_get_padding_after_duration', $value, $this );
		}

		return (int) $value;
	}

	/**
	 * Get duration in minutes for the buffer AFTER an appointment.
	 *
	 * Shares the padding unit with the before buffer.
	 *
	 * @return integer
	 */
	public function get_padding_after_in_minutes(): int {
		$duration = $this->padding_value_to_minutes( $this->get_padding_after_duration() );

		return (int) apply_filters( 'woocommerce_appointments_get_padding_after_in_minutes', $duration, $this );
	}

	/**
	 * Set padding_after_duration (buffer AFTER an appointment).
	 *
	 * @param integer $value
	 */
	public function set_padding_after_duration( $value ): void {
		$this->set_prop( 'padding_after_duration', absint( $value ) );
	}

	/**
	 * Returns the unit for the minimum lead time (minute, hour, day, month).
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_min_date_unit( string $context = 'view' ): string {
		return (string) $this->get_prop( 'min_date_unit', $context );
	}

	/**
	 * Set min_date_unit.
	 *
	 * @param string $value
	 */
	public function set_min_date_unit( $value ): void {
		$this->set_prop( 'min_date_unit', (string) $value );
	}

	/**
	 * Returns the minimum lead time value.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_min_date( string $context = 'view' ): int {
		return (int) $this->get_prop( 'min_date', $context );
	}

	/**
	 * Set min_date.
	 *
	 * @param integer $value
	 */
	public function set_min_date( $value ): void {
		$this->set_prop( 'min_date', absint( $value ) );
	}

	/**
	 * Returns the unit for the maximum lead time (minute, hour, day, month).
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_max_date_unit( string $context = 'view' ): string {
		return (string) $this->get_prop( 'max_date_unit', $context );
	}

	/**
	 * Set max_date_unit.
	 *
	 * @param string $value
	 */
	public function set_max_date_unit( $value ): void {
		$this->set_prop( 'max_date_unit', (string) $value );
	}

	/**
	 * Get max_date.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_max_date( string $context = 'view' ): int {
		return (int) $this->get_prop( 'max_date', $context );
	}

	/**
	 * Set max_date.
	 *
	 * @param integer $value
	 */
	public function set_max_date( $value ): void {
		$this->set_prop( 'max_date', absint( $value ) );
	}

	/**
	 * Returns whether the user can cancel the appointment.
	 *
	 * @param  string $context
	 * @return boolean
	 */
	public function get_user_can_cancel( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'user_can_cancel', $context );
	}

	/**
	 * Set user_can_cancel.
	 *
	 * @param boolean $value
	 */
	public function set_user_can_cancel( $value ): void {
		$this->set_prop( 'user_can_cancel', wc_appointments_string_to_bool( $value ) );
	}

	/**
	 * Returns the unit for the cancellation deadline (minute, hour, day, month).
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_cancel_limit_unit( string $context = 'view' ): string {
		$value = $this->get_prop( 'cancel_limit_unit', $context );

		if ('view' === $context) {
            return (string) apply_filters( 'woocommerce_appointments_get_cancel_limit_unit', $value, $this );
        }

		return (string) $value;
	}

	/**
	 * Set cancel_limit_unit.
	 *
	 * @param string $value
	 */
	public function set_cancel_limit_unit( $value ): void {
		$value = in_array( $value, [ self::DURATION_UNIT_MONTH, self::DURATION_UNIT_DAY, self::DURATION_UNIT_HOUR, self::DURATION_UNIT_MINUTE ], true ) ? $value : self::DURATION_UNIT_DAY;
		$this->set_prop( 'cancel_limit_unit', $value );
	}

	/**
	 * Returns the cancellation deadline value.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_cancel_limit( string $context = 'view' ): int {
		$value = $this->get_prop( 'cancel_limit', $context );

		if ('view' === $context) {
            return (int) apply_filters( 'woocommerce_appointments_get_cancel_limit', $value, $this );
        }

		return (int) $value;
	}

	/**
	 * Set cancel_limit.
	 *
	 * @param integer $value
	 */
	public function set_cancel_limit( $value ): void {
		$this->set_prop( 'cancel_limit', max( 1, absint( $value ) ) );
	}

	/**
	 * Get user_can_reschedule.
	 *
	 * @param  string $context
	 * @return boolean
	 */
	public function get_user_can_reschedule( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'user_can_reschedule', $context );
	}

	/**
	 * Set user_can_reschedule.
	 *
	 * @param boolean $value
	 */
	public function set_user_can_reschedule( $value ): void {
		$this->set_prop( 'user_can_reschedule', wc_appointments_string_to_bool( $value ) );
	}

	/**
	 * Returns the unit for the rescheduling deadline (minute, hour, day, month).
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_reschedule_limit_unit( string $context = 'view' ): string {
		return (string) $this->get_prop( 'reschedule_limit_unit', $context );
	}

	/**
	 * Set reschedule_limit_unit.
	 *
	 * @param string $value
	 */
	public function set_reschedule_limit_unit( $value ): void {
		$value = in_array( $value, [ self::DURATION_UNIT_MONTH, self::DURATION_UNIT_DAY, self::DURATION_UNIT_HOUR, self::DURATION_UNIT_MINUTE ], true ) ? $value : self::DURATION_UNIT_DAY;
		$this->set_prop( 'reschedule_limit_unit', $value );
	}

	/**
	 * Returns the rescheduling deadline value.
	 *
	 * @param  string $context
	 * @return integer
	 */
	public function get_reschedule_limit( string $context = 'view' ): int {
		return (int) $this->get_prop( 'reschedule_limit', $context );
	}

	/**
	 * Set reschedule_limit.
	 *
	 * @param integer $value
	 */
	public function set_reschedule_limit( $value ): void {
		$this->set_prop( 'reschedule_limit', max( 1, absint( $value ) ) );
	}

	/**
	 * Returns whether the appointment requires admin confirmation.
	 *
	 * @param  string $context
	 * @return boolean
	 */
	public function get_requires_confirmation( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'requires_confirmation', $context );
	}

	/**
	 * Set requires_confirmation.
	 *
	 * @param boolean $value
	 */
	public function set_requires_confirmation( $value ): void {
		$this->set_prop( 'requires_confirmation', wc_appointments_string_to_bool( $value ) );
	}

	/**
	 * Get cal_color.
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_cal_color( string $context = 'view' ): string {
		return (string) $this->get_prop( 'cal_color', $context );
	}

	/**
	 * Set get_cal_color.
	 *
	 * @param string $value
	 */
	public function set_cal_color( $value ): void {
		$this->set_prop( 'cal_color', $value );
	}

	/**
	 * Returns the availability span setting.
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_availability_span( string $context = 'view' ): string {
		$value = $this->get_prop( 'availability_span', $context );

		if ('view' === $context) {
            return (string) apply_filters( 'woocommerce_appointments_get_availability_span', $value, $this );
        }
		return (string) $value;
	}

	/**
	 * Set availability_span.
	 *
	 * @param string $value
	 */
	public function set_availability_span( $value ): void {
		$this->set_prop( 'availability_span', (string) $value );
	}

	/**
	 * Returns whether availability should be auto-selected.
	 *
	 * @param  string $context
	 * @return boolean
	 */
	public function get_availability_autoselect( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'availability_autoselect', $context );
	}

	/**
	 * Set availability_autoselect.
	 *
	 * @param boolean $value
	 */
	public function set_availability_autoselect( $value ): void {
		$this->set_prop( 'availability_autoselect', wc_appointments_string_to_bool( $value ) );
	}

	/**
	 * Returns the availability rules for the product.
	 *
	 * @param  string $context
	 * @return array<int, array<string, mixed>>
	 */
	public function get_availability( string $context = 'view' ): array {
		$kind_id = wc_appointments_get_product_id_for_availability( (int) $this->get_id() );

		$product_rules = WC_Data_Store::load( 'appointments-availability' )->get_all_as_array(
		    [
				[
					'key'     => 'kind',
					'compare' => '=',
					'value'   => 'availability#product',
				],
				[
					'key'     => 'kind_id',
					'compare' => '=',
					'value'   => $kind_id,
				],
			],
		);

		return (array) apply_filters( 'wc_appointments_product_availability', $product_rules, $this );
	}

	/**
	 * Get has_restricted_days.
	 *
	 * @param  string $context
	 * @return bool
	 */
	public function get_has_restricted_days( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'has_restricted_days', $context );
	}

	/**
	 * Set has_restricted_days.
	 *
	 * @param string $value
	 */
	public function set_has_restricted_days( $value ): void {
		$this->set_prop( 'has_restricted_days', $value );
	}

	/**
	 * Returns the restricted days.
	 *
	 * @param  string $context
	 * @return array<int, int>
	 */
	public function get_restricted_days( string $context = 'view' ): array {
		return (array) $this->get_prop( 'restricted_days', $context );
	}

	/**
	 * Set restricted_days.
	 *
	 * @param string $value
	 */
	public function set_restricted_days( $value ): void {
		$this->set_prop( 'restricted_days', $value );
	}

	/**
	 * Returns the label used for staff.
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_staff_label( string $context = 'view' ): string {
		return (string) $this->get_prop( 'staff_label', $context );
	}

	/**
	 * Set staff_label.
	 *
	 * @param string $value
	 */
	public function set_staff_label( $value ): void {
		$this->set_prop( 'staff_label', $value );
	}

	/**
	 * Get staff_assignment.
	 *
	 * @param  string $context
	 * @return string
	 */
	public function get_staff_assignment( string $context = 'view' ): string {
		return (string) $this->get_prop( 'staff_assignment', $context );
	}

	/**
	 * Set staff_assignment.
	 *
	 * @param string $value
	 */
	public function set_staff_assignment( $value ): void {
		$this->set_prop( 'staff_assignment', (string) $value );
	}

	/**
	 * Returns whether 'no preference' option is available for staff.
	 *
	 * @param  string $context
	 * @return bool
	 */
	public function get_staff_nopref( string $context = 'view' ): bool {
		return (bool) $this->get_prop( 'staff_nopref', $context );
	}

	/**
	 * Set staff_nopref.
	 *
	 * @param string $value
	 */
	public function set_staff_nopref( $value ): void {
		$this->set_prop( 'staff_nopref', wc_appointments_string_to_bool( $value ) );
	}

	/**
	 * Returns the list of assigned staff IDs.
	 *
	 * @param  string $context
	 * @return int[]
	 */
	public function get_staff_ids( string $context = 'view' ): array {
		return (array) $this->get_prop( 'staff_ids', $context );
	}

	/**
	 * Set staff_ids.
	 *
	 * @param int[]|array<int, int|string> $value
	 */
	public function set_staff_ids( $value ): void {
		$this->set_prop( 'staff_ids', wp_parse_id_list( (array) $value ) );
	}

	/**
	 * Get location mode.
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Context.
	 * @return string none|fixed|hidden|customer_choice
	 */
	public function get_location_mode( string $context = 'view' ): string {
		$mode = (string) $this->get_prop( 'location_mode', $context );
		return in_array( $mode, [ 'none', 'fixed', 'hidden', 'customer_choice' ], true ) ? $mode : 'none';
	}

	/**
	 * Set location mode.
	 *
	 * @since 5.5.0
	 *
	 * @param string $value Mode.
	 */
	public function set_location_mode( $value ): void {
		$mode = (string) $value;
		if ( ! in_array( $mode, [ 'none', 'fixed', 'hidden', 'customer_choice' ], true ) ) {
			$mode = 'none';
		}
		$this->set_prop( 'location_mode', $mode );
	}

	/**
	 * Get location IDs allow-list (ordered).
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Context.
	 * @return int[]
	 */
	public function get_location_ids( string $context = 'view' ): array {
		return array_values( array_filter( array_map( 'absint', (array) $this->get_prop( 'location_ids', $context ) ) ) );
	}

	/**
	 * Set location IDs allow-list.
	 *
	 * @since 5.5.0
	 *
	 * @param int[]|array<int, int|string> $value IDs.
	 */
	public function set_location_ids( $value ): void {
		$this->set_prop( 'location_ids', wp_parse_id_list( (array) $value ) );
	}

	/**
	 * @since 5.5.0
	 * @param string $context Context.
	 * @return array<int|string, float|string>
	 */
	public function get_location_costs( string $context = 'view' ): array {
		return (array) $this->get_prop( 'location_costs', $context );
	}

	/**
	 * @since 5.5.0
	 * @param array<int|string, float|string> $value Location ID => cost.
	 */
	public function set_location_costs( $value ): void {
		$this->set_prop( 'location_costs', (array) $value );
	}

	/**
	 * Returns the label used for locations on the storefront.
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Context.
	 * @return string
	 */
	public function get_location_label( string $context = 'view' ): string {
		return (string) $this->get_prop( 'location_label', $context );
	}

	/**
	 * Set location_label.
	 *
	 * @since 5.5.0
	 *
	 * @param string $value Label.
	 */
	public function set_location_label( $value ): void {
		$this->set_prop( 'location_label', $value );
	}

	/**
	 * Whether the product uses locations (Fixed with an allow-list, or Customer selected with a list or every published venue).
	 *
	 * @since 5.5.0
	 *
	 * @return bool
	 */
	public function has_locations(): bool {
		if ( ! WC_Appointments_Features::is_locations_resources_active() ) {
			return false;
		}
		if ( 'none' === $this->get_location_mode() ) {
			return false;
		}
		if ( [] !== $this->get_location_ids() ) {
			return true;
		}
		return class_exists( 'WC_Appointments_Location' )
			&& [] !== WC_Appointments_Location::get_allowed_location_ids( $this );
	}

	/**
	 * Get resource requirements (ordered: resource_id, qty_consumed, capacity, cost).
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Context.
	 * @return array<int, array{resource_id?: int, qty_consumed?: int, capacity?: int, cost?: float|string}>
	 */
	public function get_resource_requirements( string $context = 'view' ): array {
		$value = $this->get_prop( 'resource_requirements', $context );
		return is_array( $value ) ? $value : [];
	}

	/**
	 * Set resource requirements. Order is Automatic pick priority / customer dropdown order.
	 *
	 * @since 5.5.0
	 *
	 * @param array<int, array{resource_id?: int, qty_consumed?: int, capacity?: int, cost?: float|string}> $value Requirements.
	 */
	public function set_resource_requirements( $value ): void {
		$clean = [];
		$seen  = [];
		if ( is_array( $value ) ) {
			foreach ( $value as $req ) {
				$rid = (int) ( $req['resource_id'] ?? 0 );
				if ( $rid <= 0 || isset( $seen[ $rid ] ) ) {
					continue;
				}
				$seen[ $rid ] = true;
				$cost         = isset( $req['cost'] ) ? wc_format_decimal( $req['cost'] ) : 0;
				$clean[]      = [
					'resource_id'  => $rid,
					'qty_consumed' => max( 1, (int) ( $req['qty_consumed'] ?? 1 ) ),
					'capacity'     => max( 1, (int) ( $req['capacity'] ?? 1 ) ),
					'cost'         => (float) $cost,
				];
			}
		}
		$this->set_prop( 'resource_requirements', $clean );
	}

	/**
	 * Whether the product requires any resources.
	 *
	 * @since 5.5.0
	 *
	 * @return bool
	 */
	public function has_resources(): bool {
		if ( ! WC_Appointments_Features::is_locations_resources_active() ) {
			return false;
		}
		return [] !== $this->get_resource_requirements();
	}

	/**
	 * Frontend label for resources (when shown or customer selected).
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Context.
	 * @return string
	 */
	public function get_resource_label( string $context = 'view' ): string {
		return (string) $this->get_prop( 'resource_label', $context );
	}

	/**
	 * Set resource label.
	 *
	 * @since 5.5.0
	 *
	 * @param string $value Label.
	 */
	public function set_resource_label( $value ): void {
		$this->set_prop( 'resource_label', wc_clean( $value ) );
	}

	/**
	 * How customers see resources: hidden|display|customer.
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Context.
	 * @return string
	 */
	public function get_resource_assignment( string $context = 'view' ): string {
		$value = (string) $this->get_prop( 'resource_assignment', $context );
		return in_array( $value, [ 'hidden', 'display', 'customer' ], true ) ? $value : 'display';
	}

	/**
	 * Set resource assignment mode.
	 *
	 * @since 5.5.0
	 *
	 * @param string $value Mode.
	 */
	public function set_resource_assignment( $value ): void {
		$value = (string) $value;
		if ( ! in_array( $value, [ 'hidden', 'display', 'customer' ], true ) ) {
			$value = 'display';
		}
		$this->set_prop( 'resource_assignment', $value );
	}

	/**
	 * Whether resource assignment mode matches.
	 *
	 * @since 5.5.0
	 *
	 * @param string $type Mode.
	 * @return bool
	 */
	public function is_resource_assignment_type( string $type ): bool {
		return $this->get_resource_assignment() === $type;
	}

	/**
	 * Get virtual meeting provider (none|google_meet).
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Context.
	 * @return string
	 */
	public function get_meeting_provider( string $context = 'view' ): string {
		$provider = (string) $this->get_prop( 'meeting_provider', $context );
		return in_array( $provider, [ 'none', 'google_meet' ], true ) ? $provider : 'none';
	}

	/**
	 * Set virtual meeting provider.
	 *
	 * @since 5.5.0
	 *
	 * @param string $value Provider slug.
	 */
	public function set_meeting_provider( $value ): void {
		$provider = sanitize_key( (string) $value );
		if ( ! in_array( $provider, [ 'none', 'google_meet' ], true ) ) {
			$provider = 'none';
		}
		$this->set_prop( 'meeting_provider', $provider );
	}

	/**
	 * Returns the base costs for staff.
	 *
	 * @param  string $context
	 * @return array<int|string, float|string>
	 */
	public function get_staff_base_costs( string $context = 'view' ): array {
		return (array) $this->get_prop( 'staff_base_costs', $context );
	}

	/**
	 * Set staff_base_costs.
	 *
	 * @param array<int|string, float|string> $value
	 */
	public function set_staff_base_costs( $value ): void {
		$this->set_prop( 'staff_base_costs', (array) $value );
	}

	/**
	 * Returns the quantities for staff.
	 *
	 * @param  string $context
	 * @return array<int|string, int|string>
	 */
	public function get_staff_qtys( string $context = 'view' ): array {
		return (array) $this->get_prop( 'staff_qtys', $context );
	}

	/**
	 * Set staff_qtys.
	 *
	 * @param array<int|string, int|string> $value
	 */
	public function set_staff_qtys( $value ): void {
		$this->set_prop( 'staff_qtys', (array) $value );
	}

	/*
	|--------------------------------------------------------------------------
	| Conditionals
	|--------------------------------------------------------------------------
	|
	| Conditionals functions which return true or false.
	*/

	/**
	 * If this product class is a skeleton/place holder class (used for appointment addons).
	 *
	 * @return boolean
	 */
	public function is_skeleton(): bool {
		return false;
	}

	/**
	 * If this product class is an addon for appointments.
	 *
	 * @return boolean
	 */
	public function is_appointments_addon(): bool {
		return false;
	}

	/**
	 * Extension/plugin/add-on name for the appointment addon this product refers to.
	 *
	 * @return string
	 */
	public function appointments_addon_title(): string {
		return '';
	}

	/**
	 * Returns whether or not the product is in stock.
	 *
	 * @todo Develop further to embrace WC stock statuses and backorders.
	 *
	 * @return bool
	 */
	public function is_in_stock() {
		return apply_filters( 'woocommerce_product_is_in_stock', true, $this );
		// return apply_filters( 'woocommerce_product_is_in_stock', 'instock' === $this->get_stock_status(), $this );
	}

	/**
	 * Appointments can always be purchased regardless of price.
	 *
	 * @return boolean
	 */
	public function is_purchasable() {
		return apply_filters( 'woocommerce_is_purchasable', $this->exists() && ( 'publish' === $this->get_status() || current_user_can( 'edit_post', $this->get_id() ) ), $this );
	}

	/**
	 * The base cost will either be the 'base' cost or the base cost + cheapest staff
	 * @return float
	 */
	public function get_base_cost(): float {
		$base = (float) $this->get_price();

		if ( $this->has_staff() ) {
			$staff    = $this->get_staff();
			$cheapest = null;

			foreach ( $staff as $staff_member ) {
				if ( is_null( $cheapest ) || $staff_member->get_base_cost() < $cheapest ) {
					$cheapest = $staff_member->get_base_cost();
				}
			}
			$base += $cheapest;
		}

		if ( $this->has_resources() ) {
			$costs = array_map( static fn( $req ) => (float) ( $req['cost'] ?? 0 ), $this->get_resource_requirements() );
			if ( $costs ) {
				$base += min( $costs );
			}
		}

		if ( $this->has_locations() ) {
			$loc_costs = array_map( 'floatval', $this->get_location_costs() );
			if ( $loc_costs ) {
				$base += min( $loc_costs );
			}
		}

		return (float) $base;
	}

	/**
	 * Return if appointment has extra costs.
	 *
	 * @return bool
	 */
	public function has_additional_costs(): bool {
		if ( $this->get_has_additional_costs() ) {
			return true;
		}

		if ( $this->has_staff() ) {
			foreach ( (array) $this->get_staff() as $staff_member ) {
				if ( $staff_member->get_base_cost() ) {
					return true;
				}
			}
		}

		if ( $this->has_resources() ) {
			foreach ( $this->get_resource_requirements() as $req ) {
				if ( (float) ( $req['cost'] ?? 0 ) ) {
					return true;
				}
			}
		}

		if ( $this->has_locations() && array_filter( array_map( 'floatval', $this->get_location_costs() ) ) ) {
			return true;
		}

		$costs = $this->get_costs();
        return ! empty( $costs ) && $this->get_has_pricing();
	}

	/**
	 * How staff are assigned.
	 *
	 * @param string $type
	 * @return boolean customer or automatic
	 */
	public function is_staff_assignment_type( string $type ): bool {
		return $this->get_staff_assignment() === $type;
	}

	/**
	 * Checks if a product requires confirmation.
	 *
	 * @return bool
	 */
	public function requires_confirmation(): bool {
		return (bool) apply_filters( 'woocommerce_appointment_requires_confirmation', $this->get_requires_confirmation(), $this );
	}

	/**
	 * See if the appointment can be cancelled.
	 *
	 * @return boolean
	 */
	public function can_be_cancelled(): bool {
		return (bool) apply_filters( 'woocommerce_appointment_user_can_cancel', $this->get_user_can_cancel(), $this );
	}

	/**
	 * See if the appointment can be rescheduled.
	 *
	 * @return boolean
	 */
	public function can_be_rescheduled(): bool {
		return (bool) apply_filters( 'woocommerce_appointment_user_can_reschedule', $this->get_user_can_reschedule(), $this );
	}

	/**
	 * See if the appointment has timezone support enabled.
	 *
	 * Timezone support is always enabled by default since 5.2.0.
	 * Use the 'wc_appointments_timezone_support_enabled' filter to disable per product if needed.
	 *
	 * @since 5.2.0 Now always returns true by default; per-product setting removed.
	 *
	 * @return boolean
	 */
	public function has_timezones(): bool {
		return (bool) apply_filters( 'wc_appointments_timezone_support_enabled', true, $this );
	}

	/**
	 * See if the appointment requires time selection.
	 *
	 * @return boolean
	 */
	public function has_time(): bool {
		return in_array( $this->get_duration_unit(), [ self::DURATION_UNIT_HOUR, self::DURATION_UNIT_MINUTE ], true );
	}

	/**
	 * See if dates are by default appointable.
	 *
	 * @return bool
	 */
	public function get_default_availability(): bool {
		return (bool) apply_filters( 'woocommerce_appointment_default_availability', false, $this );
	}

	/**
	 * See if this appointment product has restricted days.
	 *
	 * @return boolean
	 */
	public function has_restricted_days(): bool {
		return $this->get_has_restricted_days();
	}

	/*
	|--------------------------------------------------------------------------
	| Non-CRUD getters
	|--------------------------------------------------------------------------
	*/
	/**
	 * Gets all formatted cost rules.
	 *
	 * @return array<int, array{0: string, 1: array<string, mixed>}>
	 */
	public function get_costs(): array {
		if ( ! $this->get_has_pricing() ) {
			return [];
		}
		return WC_Product_Appointment_Rule_Manager::process_pricing_rules( $this->get_pricing() );
	}

	/**
	 * Get Min date.
	 *
	 * @return array<string, mixed>
	 */
	public function get_min_date_a(): array {
        return ['value' => apply_filters( 'woocommerce_appointments_min_date', $this->get_min_date(), $this->get_id() ), 'unit' => $this->get_min_date_unit() ? apply_filters( 'woocommerce_appointments_min_date_unit', $this->get_min_date_unit(), $this->get_id() ) : 'month'];
    }

	/**
	 * Get max date.
	 *
	 * @return array{value: mixed, unit: mixed}
	 */
	public function get_max_date_a(): array {
        return ['value' => $this->get_max_date() ? apply_filters( 'woocommerce_appointments_max_date', $this->get_max_date(), $this->get_id() ) : 1, 'unit' => $this->get_max_date_unit() ? apply_filters( 'woocommerce_appointments_max_date_unit', $this->get_max_date_unit(), $this->get_id() ) : 'month'];
    }

	/**
	 * Get default intervals.
	 *
	 * @since 3.2.0 introduced.
	 * @return array{0: int, 1: int}
	 */
	public function get_intervals(): array {
		$default_interval = self::DURATION_UNIT_HOUR === $this->get_duration_unit() ? $this->get_duration() * 60 : $this->get_duration();
		$custom_interval  = self::DURATION_UNIT_HOUR === $this->get_duration_unit() ? $this->get_duration() * 60 : $this->get_duration();
		if ( $this->get_interval_unit() && $this->get_interval() ) {
			$custom_interval = self::DURATION_UNIT_HOUR === $this->get_interval_unit() ? $this->get_interval() * 60 : $this->get_interval();
			$custom_interval = self::DURATION_UNIT_MONTH === $this->get_duration_unit() ? $this->get_duration() : $custom_interval;
		}

		// Filters for the intervals.
		$default_interval = apply_filters( 'woocommerce_appointments_interval', $default_interval, $this );
		$custom_interval  = apply_filters( 'woocommerce_appointments_base_interval', $custom_interval, $this );

		return [ $default_interval, $custom_interval ];
	}

	/**
	 * See if this appointment product has any staff.
	 * @return boolean
	 */
	public function has_staff(): bool {
		$count_staff = count( $this->get_staff_ids() );
		return (bool) $count_staff;
	}

	/**
	 * Get staff by ID.
	 *
	 * @return array<int, WC_Product_Appointment_Staff>
	 */
	public function get_staff(): array {
		$product_staff = [];

		foreach ( $this->get_staff_ids() as $staff_id ) {
			$product_staff[] = new WC_Product_Appointment_Staff( $staff_id, $this );
		}

		return $product_staff;
	}

	/**
	 * Get staff member by ID
	 *
	 * @param int $staff_id Staff ID.
	 * @return WC_Product_Appointment_Staff|false
	 */
	public function get_staff_member( int $staff_id ) {
		if ( $this->has_staff() && ! empty( $staff_id ) ) {
			return new WC_Product_Appointment_Staff( $staff_id, $this );
		}

		return false;
	}

	/**
	 * Get staff members by IDs
	 *
	 * @param array<int, int>|int $ids       Staff IDs.
	 * @param bool              $names     Return names only.
	 * @param bool              $with_link Include admin links.
	 * @return array<int, mixed>|false
	 */
	public function get_staff_members( $ids = [], bool $names = false, bool $with_link = false ) {
		// If no IDs are give, get all product staff IDs.
		if ( ! $ids ) {
			$ids = $this->get_staff_ids();

			return false;
		}

		return wc_appointments_get_staff_from_ids( $ids, $names, $with_link );
	}

	/**
	 * Get available quantity.
	 *
	 * @since 3.2.0 introduced.
	 * @param int|string $staff_id Staff ID.
	 * @return int
	 */
	public function get_available_qty( $staff_id = '', bool $no_fallback = false, bool $individual = false ): int {
		$default_qty = $no_fallback ? 0 : $this->get_qty();

		if ( $this->has_staff() ) {
			$qtys       = $this->get_staff_qtys();
			$staff_qty  = 0;
			$staff_qtys = [];

			if ( $staff_id && is_array( $staff_id ) ) {
				foreach ( $staff_id as $staff_member_id ) {
					$qty          = isset( $qtys[ $staff_member_id ] ) && '' !== $qtys[ $staff_member_id ] && 0 !== $qtys[ $staff_member_id ] ? $qtys[ $staff_member_id ] : $default_qty;
					$staff_qtys[] = $qty;
				}
				// Only count when $qtys is an array.
				$staff_qty = $this->is_staff_assignment_type( 'all' ) ? max( $staff_qtys ) : array_sum( $staff_qtys );
			} elseif ( $staff_id && is_numeric( $staff_id ) ) {
				$staff_qty = isset( $qtys[ $staff_id ] ) && '' !== $qtys[ $staff_id ] && 0 !== $qtys[ $staff_id ] ? $qtys[ $staff_id ] : $default_qty;
			} elseif ( ! $staff_id ) {
				foreach ( $this->get_staff_ids() as $staff_member_id ) {
					$staff_qtys[] = isset( $qtys[ $staff_member_id ] ) && '' !== $qtys[ $staff_member_id ] && 0 !== $qtys[ $staff_member_id ] ? $qtys[ $staff_member_id ] : $this->get_qty();
				}
				// Only count when $qtys is an array.
				if ( [] !== $staff_qtys ) {
					$staff_qty = $individual || $this->is_staff_assignment_type( 'all' ) ? max( $staff_qtys ) : array_sum( $staff_qtys );
				}
			}

			return (int) apply_filters( 'woocommerce_appointments_get_available_quantity', $staff_qty ? absint( $staff_qty ) : absint( $default_qty ), $this, $staff_id );
		}

		return (int) apply_filters( 'woocommerce_appointments_get_available_quantity', $default_qty, $this, $staff_id );
	}

	/**
	 * Get rules in order of `override power`. The higher the index the higher the override power. Element at index 4 will
	 * override element at index 2.
	 *
	 * Within priority the rules will be ordered top to bottom.
	 *
	 * @return array  availability_rules {
	 *    @type $staff_id => array {
	 *
	 *       The $order_index depicts the levels override. `0` Is the lowest. `1` overrides `0` and `2` overrides `1`.
	 *       e.g. If monday is set to available in `1` and not available in `2` the results should be that Monday is
	 *       NOT available because `2` overrides `1`.
	 *       $order_index corresponds to override power. The higher the element index the higher the override power.
	 *       @type $order_index => array {
	 *          @type string $type   The type of range selected in admin.
	 *          @type string $range  Depending on the type this depicts what range and if available or not.
	 *          @type integer $priority
	 *          @type string $level Global, Product or Staff
	 *          @type integer $order The index for the order set in admin.
	 *      }
	 * }
	 *
	 * @param int|int[] $for_staff Staff ID, list of staff IDs, or 0 for product-level.
	 * @return array<int, array<string, mixed>>
	 */
	public function get_availability_rules( $for_staff = 0 ): array {
		// Default to zero, when no staff is set.
		if ( empty( $for_staff ) ) {
			$for_staff = 0;
		}

		// Repeat the function if staff IDs are in array.
		if ( is_array( $for_staff ) ) {
			$for_all_staff = [];
			foreach ( $for_staff as $for_staff_id ) {
				$for_all_staff[] = $this->get_availability_rules( $for_staff_id );
			}
			return array_merge( ...$for_all_staff );
		}

		$layers = class_exists( 'WC_Appointment_Slots_Engine', false )
			? WC_Appointment_Slots_Engine::resolve_availability_layer_ids()
			: [ 'location_id' => 0, 'resource_id' => 0 ];
		$location_id = (int) ( $layers['location_id'] ?? 0 );
		$resource_id = (int) ( $layers['resource_id'] ?? 0 );
		$cache_key   = (string) $for_staff . ':' . $location_id . ':' . $resource_id;

		if ( ! isset( $this->availability_rules[ $cache_key ] ) ) {
			$this->availability_rules[ $cache_key ] = [];

			// Global and Gcal rules.
			$global_rules = WC_Appointments_Availability_Data_Store::get_global_availability();
			#print '<pre>'; print_r( $global_rules ); print '</pre>';

			// Location open/closed (only when request has location context).
			$location_rules = $location_id
				? WC_Appointments_Availability_Data_Store::get_location_availability( $location_id )
				: [];

			// Selected: Open+Closed in mask. OR-pool: candidate Open only (Closed is seat-level).
			$resource_rules = [];
			if ( $resource_id ) {
				$resource_rules = WC_Appointments_Availability_Data_Store::get_resource_availability( $resource_id );
			} elseif ( $this->has_resources() ) {
				foreach ( WC_Appointments_Availability_Data_Store::get_resource_availability(
					array_column( $this->get_resource_requirements(), 'resource_id' )
				) as $rule ) {
					if ( 'yes' === ( $rule['appointable'] ?? '' ) ) {
						$resource_rules[] = $rule;
					}
				}
			}

			// Product rules.
			$product_rules = $this->get_availability();

			#print '<pre>'; print_r( $product_rules ); print '</pre>';

			// Staff rules.
			$staff_rules = [];

			// Get availability of each staff - no staff has been chosen yet.
			if ( $this->has_staff() && ! $for_staff ) {
				// Always load staff rules so they can override product rules
				// (e.g. product "days Mon-Sun NOT available" + staff "time 09-17 available").
				// The JS date picker's has_any_available_staff() checks each staff individually.
				$staff_rules = WC_Appointments_Availability_Data_Store::get_staff_availability( $this->get_staff_ids() );
				#print '<pre>'; print_r( $staff_rules ); print '</pre>';
			} elseif ( $for_staff ) {

				// Staff rules.
				$staff_object = $this->get_staff_member( $for_staff );
				$staff_rules  = $staff_object ? $staff_object->get_availability() : [];
				#print '<pre>'; print_r( $staff_rules ); print '</pre>';
			}

			// Merge order (last wins after priority sort): global → product → location → resource → staff.
			$availability_rules = array_filter(
			    array_merge(
			        WC_Product_Appointment_Rule_Manager::process_availability_rules( array_reverse( $global_rules ), 'global', true, $this ),
			        WC_Product_Appointment_Rule_Manager::process_availability_rules( array_reverse( $product_rules ), 'product', true, $this ),
			        WC_Product_Appointment_Rule_Manager::process_availability_rules( array_reverse( $location_rules ), 'location', true, $this ),
			        WC_Product_Appointment_Rule_Manager::process_availability_rules( array_reverse( $resource_rules ), 'resource', true, $this ),
			        WC_Product_Appointment_Rule_Manager::process_availability_rules( array_reverse( $staff_rules ), 'staff', true, $this ),
			    ),
			);
			#print '<pre>'; print_r( $availability_rules ); print '</pre>';

			usort( $availability_rules, [ $this, 'rule_override_power_sort' ] );

			$this->availability_rules[ $cache_key ] = $availability_rules;

		}

		return apply_filters( 'woocommerce_appointment_get_availability_rules', $this->availability_rules[ $cache_key ], $for_staff, $this );
	}

	/**
	 * Rules appended by woocommerce_appointment_get_availability_rules.
	 *
	 * Index path overlays this tail after cache rows. Only append-after-base is
	 * supported (typical third-party inject); mutate/remove/reorder is not.
	 *
	 * @param int $for_staff Staff ID (0 = product-level).
	 * @return array<int, array<string, mixed>> Parsed rule rows appended by the filter.
	 */
	public function get_availability_rules_filter_delta( $for_staff = 0 ): array {
		if ( ! has_filter( 'woocommerce_appointment_get_availability_rules' ) ) {
			return [];
		}

		$for_staff = empty( $for_staff ) ? 0 : (int) $for_staff;
		$filtered  = $this->get_availability_rules( $for_staff );

		$layers = class_exists( 'WC_Appointment_Slots_Engine', false )
			? WC_Appointment_Slots_Engine::resolve_availability_layer_ids()
			: [ 'location_id' => 0, 'resource_id' => 0 ];
		$cache_key = (string) $for_staff
			. ':' . (int) ( $layers['location_id'] ?? 0 )
			. ':' . (int) ( $layers['resource_id'] ?? 0 );
		$base   = $this->availability_rules[ $cache_key ] ?? [];
		$base_n = count( $base );

		if ( count( $filtered ) <= $base_n ) {
			return [];
		}

		for ( $i = 0; $i < $base_n; $i++ ) {
			if ( $filtered[ $i ] !== $base[ $i ] ) {
				return [];
			}
		}

		return array_slice( $filtered, $base_n );
	}

	/**
	 * Sort rules.
	 *
	 * @deprecated Replaced with WC_Product_Appointment_Rule_Manager::sort_rules_callback
	 *
	 * @param array<string, mixed> $rule1 Rule A.
	 * @param array<string, mixed> $rule2 Rule B.
	 * @return int
	 */
	public function rule_override_power_sort( $rule1, $rule2 ) {
		return WC_Product_Appointment_Rule_Manager::sort_rules_callback( $rule1, $rule2 );
	}

	/**
	 * Check a date against the availability rules
	 *
	 * @param int|string   $check_date   Date to check (UTC epoch int).
	 * @param int|string   $staff_id     Staff ID (0 = product-level).
	 * @param bool         $get_capacity When true, return capacity instead of bool.
	 * @return bool|int Available or not; capacity when $get_capacity is true.
	 */
	public function check_availability_rules_against_date( $check_date, $staff_id, $get_capacity = false ) {
		// Check if we can use indexed availability within horizon
		$use_indexed = false;
		if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
			$index_toggle = WC_Appointments_Cache_Availability::is_index_enabled();
			$horizon_months = function_exists( 'wc_appointments_get_cache_horizon_months' ) ? wc_appointments_get_cache_horizon_months() : 3;
			$horizon_ts = strtotime( '+' . $horizon_months . ' months UTC' );
			$use_indexed = $index_toggle && ( $check_date <= $horizon_ts );
		}

		// Use indexed availability if enabled and within horizon
		if ( $use_indexed && class_exists( 'WC_Appointments_Controller' ) ) {
			return \WC_Appointments_Controller::check_cached_availability_rules_against_date( $this, $check_date, $staff_id, $get_capacity );
		}

		// Fall back to original method when horizon exceeded or indexing disabled
		return WC_Product_Appointment_Rule_Manager::check_availability_rules_against_date( $this, (int) $check_date, $staff_id, $get_capacity );
	}

	/**
	 * Check a time against the time specific availability rules
	 *
	 * @param int|string $slot_start_time Timestamp to check.
	 * @param int|string $slot_end_time   Timestamp to check.
	 * @param int|string $staff_id        Staff ID (0 = product-level).
	 * @param bool       $get_capacity    When true, return capacity instead of bool.
	 * @return bool|int Available or not; capacity when $get_capacity is true.
	 */
	public function check_availability_rules_against_time( $slot_start_time, $slot_end_time, $staff_id, $get_capacity = false ) {
		// Check if we can use indexed availability within horizon
		$use_indexed = false;
		if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
			$index_toggle = WC_Appointments_Cache_Availability::is_index_enabled();
			$horizon_months = function_exists( 'wc_appointments_get_cache_horizon_months' ) ? wc_appointments_get_cache_horizon_months() : 3;
			$horizon_ts = strtotime( '+' . $horizon_months . ' months UTC' );
			$use_indexed = $index_toggle && ( $slot_end_time <= $horizon_ts );
		}

		// Use indexed availability if enabled and within horizon
		if ( $use_indexed && class_exists( 'WC_Appointments_Controller' ) ) {
			return \WC_Appointments_Controller::check_cached_availability_rules_against_time( $this, $slot_start_time, $slot_end_time, $staff_id, $get_capacity );
		}

		// Fall back to original method when horizon exceeded or indexing disabled
		return WC_Product_Appointment_Rule_Manager::check_availability_rules_against_time( $this, (int) $slot_start_time, (int) $slot_end_time, $staff_id, $get_capacity );
	}

	/**
	 * Checks appointment data is correctly set, and that the chosen slots are indeed available.
	 *
	 * @since 4.7.0
	 *
	 * @param array<string, mixed> $data Posted appointment data.
	 *
	 * @return bool|WP_Error True on success; WP_Error on failure.
	 */
	public function is_appointable( array $data ) {
		$location_id = isset( $data['_location_id'] ) ? absint( $data['_location_id'] ) : 0;

		// Location allow-list + required choice (customer_choice).
		if ( class_exists( 'WC_Appointments_Location' ) && $this->has_locations() ) {
			if ( ! empty( $data['_location_error'] ) ) {
				return new WP_Error( 'Error', (string) $data['_location_error'] );
			}
			if ( $location_id <= 0 ) {
				$location_id = WC_Appointments_Location::sole_allowed_location_id( $this );
			}
			if ( 'customer_choice' === $this->get_location_mode() && $location_id <= 0 ) {
				return new WP_Error( 'Error', __( 'Please choose a location.', 'woocommerce-appointments' ) );
			}
			if ( $location_id > 0 && ! WC_Appointments_Location::authorize_location_id( $this, $location_id ) ) {
				return new WP_Error( 'Error', __( 'Selected location is not available for this product.', 'woocommerce-appointments' ) );
			}
		}

		// Validate staff are set
		if ( $this->has_staff() && $this->is_staff_assignment_type( 'customer' ) ) {
			if ( empty( $data['_staff_id'] ) ) {
				// return new WP_Error( 'Error', sprintf( __( 'Please choose the %s.', 'woocommerce-appointments' ), $this->get_staff_label() ? $this->get_staff_label() : __( 'Providers', 'woocommerce-appointments' ) ) );
				$data['_staff_id'] = 0;
			}
		} elseif ( $this->has_staff() && $this->is_staff_assignment_type( 'automatic' ) ) {
			$data['_staff_id'] = 0;
		} elseif ( $this->has_staff() && $this->is_staff_assignment_type( 'all' ) ) {
			$data['_staff_id'] = 0;
		} else {
			$data['_staff_id'] = '';
		}

		// Resource venue eligibility (shared by customer pick and automatic/display allocation).
		$resource_id = 0;
		$at_venue    = false;
		if ( $this->has_resources() && class_exists( 'WC_Appointments_Resource' ) ) {
			foreach ( WC_Appointments_Resource::normalize_requirements( $this ) as $req ) {
				if ( WC_Appointments_Resource::is_available_at_location( (int) $req['resource_id'], $location_id ) ) {
					$at_venue = true;
					break;
				}
			}
		}

		if ( $this->has_resources() && $this->is_resource_assignment_type( 'customer' ) && class_exists( 'WC_Appointments_Resource' ) ) {
			$resource_id = isset( $data['_resource_id'] ) ? absint( $data['_resource_id'] ) : 0;
			if ( $resource_id <= 0 && $at_venue ) {
				$label = $this->get_resource_label() ?: __( 'Resources', 'woocommerce-appointments' );
				/* translators: %s: resource field label (singular or plural, e.g. Room or Rooms) */
				return new WP_Error( 'Error', sprintf( __( 'Please choose %s.', 'woocommerce-appointments' ), $label ) );
			}
			if ( $resource_id > 0 ) {
				if ( ! WC_Appointments_Resource::authorize_resource_id( $this, $resource_id ) ) {
					return new WP_Error( 'Error', __( 'Selected resource is not available for this product.', 'woocommerce-appointments' ) );
				}
				if ( $location_id > 0 && ! WC_Appointments_Resource::is_available_at_location( $resource_id, $location_id ) ) {
					return new WP_Error( 'Error', __( 'Selected resource is not available at this location.', 'woocommerce-appointments' ) );
				}
			}
		} elseif ( $this->has_resources() ) {
			// Automatic / display: require a free room when this venue has eligible rooms.
			// Other-venue-only rooms soft-skip in the slot engine (product capacity); ATC must match.
			if ( ! empty( $data['_resource_allocations'][0]['resource_id'] ) ) {
				$resource_id = absint( $data['_resource_allocations'][0]['resource_id'] );
			} elseif ( $at_venue ) {
				return new WP_Error( 'Error', __( 'This time is no longer available. Please choose another.', 'woocommerce-appointments' ) );
			}
		}

		// Validate date and time
		if ( empty( $data['date'] ) ) {
			return new WP_Error( 'Error', __( 'This field is required.', 'woocommerce-appointments' ) );
		}
		if ( in_array( $this->get_duration_unit(), [ self::DURATION_UNIT_MINUTE, self::DURATION_UNIT_HOUR ], true ) && empty( $data['time'] ) ) {
			return new WP_Error( 'Error', __( 'Time is required - please choose one above', 'woocommerce-appointments' ) );
		}
		if ( in_array( $this->get_duration_unit(), [ self::DURATION_UNIT_DAY, WC_Appointments_Constants::DURATION_NIGHT, self::DURATION_UNIT_MONTH ], true ) ) {
			$start_ts = ! empty( $data['_start_date'] ) ? (int) $data['_start_date'] : 0;
			if ( ! $start_ts && ! empty( $data['_date'] ) ) {
				$civil = preg_replace( '/\s.*$/', '', (string) $data['_date'] );
				if ( preg_match( '/^\d{4}-\d{1,2}-\d{1,2}$/', $civil ) ) {
					$start_ts = (int) strtotime( $civil . ' 00:00:00 UTC' );
				}
			}
			if ( $start_ts && wc_appointments_is_past_request_date( $this, $start_ts ) ) {
				return new WP_Error( 'Error', __( 'You must choose a future date and time.', 'woocommerce-appointments' ) );
			}
		} elseif ( $data['_date'] && date( 'Ymd', strtotime( $data['_date'] ) ) < gmdate( 'Ymd', current_time( 'timestamp' ) ) ) {
			return new WP_Error( 'Error', __( 'You must choose a future date and time.', 'woocommerce-appointments' ) );
		}
		if ( $this->has_time() && $data['_date'] && ! empty( $data['_time'] ) && date( 'YmdHi', strtotime( $data['_date'] . ' ' . $data['_time'] ) ) < gmdate( 'YmdHi', current_time( 'timestamp' ) ) ) {
			return new WP_Error( 'Error', __( 'You must choose a future date and time.', 'woocommerce-appointments' ) );
		}

		// Enforce configured quantity bounds before any availability lookups.
		$requested_qty = max( 1, (int) ( $data['_qty'] ?? 1 ) );
		$min_qty       = max( 1, (int) $this->get_qty_min() );
		$max_qty       = (int) $this->get_qty_max();

		if ( $requested_qty < $min_qty ) {
			/* translators: %d: minimum quantity */
			return new WP_Error( 'Error', sprintf( __( 'Please choose at least %d for this appointment.', 'woocommerce-appointments' ), $min_qty ) );
		}

		if ( 0 < $max_qty && $requested_qty > $max_qty ) {
			/* translators: %d: maximum quantity */
			return new WP_Error( 'Error', sprintf( __( 'Please choose %d or fewer for this appointment.', 'woocommerce-appointments' ), $max_qty ) );
		}

		// Validate min date and max date
		if ( in_array( $this->get_duration_unit(), [ self::DURATION_UNIT_MINUTE, self::DURATION_UNIT_HOUR ], true ) ) {
			$now = current_time( 'timestamp' );
		} elseif ( self::DURATION_UNIT_MONTH === $this->get_duration_unit() ) {
			$now = strtotime( 'midnight first day of this month', current_time( 'timestamp' ) );
		} else {
			$now = strtotime( 'midnight', current_time( 'timestamp' ) );
		}

		$min = $this->get_min_date_a();
		if ( $min ) {
			$min_date = wc_appointments_get_min_timestamp_for_day( strtotime( $data['_date'] ), $min['value'], $min['unit'] );

			if ( strtotime( $data['_date'] . ' ' . $data['_time'] ) < $min_date ) {
				/* translators: %s: minimum date */
				return new WP_Error( 'Error', sprintf( __( 'The earliest appointment possible is currently %s.', 'woocommerce-appointments' ), date_i18n( wc_appointments_date_format() . ' ' . wc_appointments_time_format(), $min_date ) ) );
			}
		}

		$max = $this->get_max_date_a();
		if ( $max ) {
			$max_date = strtotime( "+{$max['value']} {$max['unit']}", $now );
			if ( strtotime( $data['_date'] . ' ' . $data['_time'] ) > $max_date ) {
				/* translators: %s: maximum date */
				return new WP_Error( 'Error', sprintf( __( 'The latest appointment possible is currently %s.', 'woocommerce-appointments' ), date_i18n( wc_appointments_date_format() . ' ' . wc_appointments_time_format(), $max_date ) ) );
			}
		}

		// Check that the day of the week is not restricted.
		if ( $this->has_restricted_days() ) {
			$restricted_days = (array) $this->get_restricted_days();

			// Weekday for this check must follow the same civil calendar as day/month slots (UTC-labelled / Fake UTC
			// pipeline): derive from posted `_date` using UTC noon + gmdate() so PHP default_tz / site TZ do not
			// shift the Gregorian start day. If `_date` is unusable, fall back to gmdate() on `_start_date`.
			$start_weekday = null;
			if ( ! empty( $data['_date'] ) ) {
				$civil = preg_replace( '/\s.*$/', '', (string) $data['_date'] );
				if ( preg_match( '/^\d{4}-\d{1,2}-\d{1,2}$/', $civil ) ) {
					$civil_noon_utc = strtotime( $civil . ' 12:00:00 UTC' );
					if ( $civil_noon_utc > 0 ) {
						$start_weekday = (int) gmdate( 'w', $civil_noon_utc );
					}
				}
			}
			if ( null === $start_weekday ) {
				$start_weekday = (int) gmdate( 'w', (int) ( $data['_start_date'] ?? 0 ) );
			}
			// Loose compare: restricted_days meta may store string day numbers (e.g. "1").
			if ( ! in_array( $start_weekday, $restricted_days ) ) {
				return new WP_Error( 'Error', __( 'Sorry, appointments cannot start on this day.', 'woocommerce-appointments' ) );
			}
		}

		// Get availability for the dates (single source of truth: same slots pipeline as display/cost).
		$available_appointments = wc_appointments_get_total_available_appointments_for_range(
			$this,
			$data['_start_date'],
			$data['_end_date'],
			$data['_staff_id'],
			$data['_qty'],
			$location_id,
			$resource_id
		);

		if ( is_array( $available_appointments ) ) {
			$this->assigned_staff_id = current( array_keys( $available_appointments ) );
		}

		if ( ! $available_appointments ) {
			return new WP_Error( 'Error', __( 'Sorry, the selected slot is not available.', 'woocommerce-appointments' ) );
		}

		return true;
	}

	/** Recurring prepaid package defaults. */
	public const RECURRING_DEFAULT_MIN_OCCURRENCES   = 2;
	public const RECURRING_DEFAULT_MAX_OCCURRENCES   = 8;
	public const RECURRING_ABSOLUTE_MAX_OCCURRENCES  = 365;

	public const META_RECURRING_MIN_OCCURRENCES    = '_wc_appointment_recurring_min_occurrences';
	public const META_RECURRING_MAX_OCCURRENCES    = '_wc_appointment_recurring_max_occurrences';
	public const META_RECURRING_PAYMENT_OPTIONS    = '_wc_appointment_recurring_payment_options';
	public const RECURRING_MODE_NONE    = 'none';
	public const RECURRING_MODE_PREPAID = 'prepaid';

	/**
	 * RRULE FREQ choices for recurring picker.
	 *
	 * @return array<string, string>
	 */
	public static function get_recurring_freq_choices() {
		return array(
			'DAILY'   => __( 'Daily', 'woocommerce-appointments' ),
			'WEEKLY'  => __( 'Weekly', 'woocommerce-appointments' ),
			'MONTHLY' => __( 'Monthly', 'woocommerce-appointments' ),
		);
	}

	/**
	 * @param WC_Product|int $product Product or id.
	 * @return self|null
	 */
	public static function as_appointment_product( $product ) {
		if ( is_numeric( $product ) ) {
			$product = wc_get_product( (int) $product );
		}
		return ( $product instanceof self ) ? $product : null;
	}

	/**
	 * Whether prepaid recurring packages are enabled for this product.
	 *
	 * @param string $context view|edit.
	 * @return bool
	 */
	public function get_allow_recurring( string $context = 'view' ): bool {
		if ( 'appointment' !== $this->get_type() ) {
			return false;
		}

		unset( $context );
		return wc_string_to_bool( $this->get_meta( '_wc_appointment_allow_recurring' ) );
	}

	/**
	 * @return string none|prepaid
	 */
	public function get_recurring_mode() {
		return $this->get_allow_recurring() ? self::RECURRING_MODE_PREPAID : self::RECURRING_MODE_NONE;
	}

	/**
	 * @return bool
	 */
	public function allows_recurring() {
		return $this->get_allow_recurring();
	}

	/**
	 * @return int
	 */
	public function get_recurring_min_occurrences() {
		return $this->get_recurring_limits_filtered()['min'];
	}

	/**
	 * @return int
	 */
	public function get_recurring_max_occurrences() {
		return $this->get_recurring_limits_filtered()['max'];
	}

	/**
	 * Minimum billable sessions at checkout (defaults to product minimum).
	 *
	 * @return int
	 */
	public function get_recurring_min_billable_sessions() {
		return max(
			1,
			(int) apply_filters(
				'wc_appointments_recurring_min_billable_sessions',
				$this->get_recurring_min_occurrences(),
				$this
			)
		);
	}

	/**
	 * @return string[]
	 */
	public function get_recurring_allowed_freqs() {
		$stored = $this->get_meta( '_wc_appointment_recurring_allowed_freqs' );
		$raw    = is_string( $stored ) && '' !== $stored
			? array_map( 'trim', explode( ',', $stored ) )
			: array();

		if ( empty( $raw ) ) {
			return array_keys( self::get_recurring_freq_choices() );
		}

		return self::sanitize_recurring_allowed_freqs( $raw );
	}

	/**
	 * @param string[] $freqs Posted frequency codes.
	 * @return string[]
	 */
	public static function sanitize_recurring_allowed_freqs( $freqs ) {
		$valid = array_keys( self::get_recurring_freq_choices() );
		$freqs = array_map( 'strtoupper', array_map( 'sanitize_key', (array) $freqs ) );
		$freqs = array_values( array_intersect( $freqs, $valid ) );
		return empty( $freqs ) ? array( 'WEEKLY' ) : $freqs;
	}

	/**
	 * Stored min/max with plugin defaults (unfiltered).
	 *
	 * @return array{min: int, max: int}
	 */
	public function get_recurring_occurrence_limits() {
		return self::sanitize_recurring_occurrence_limits(
			(int) $this->get_meta( self::META_RECURRING_MIN_OCCURRENCES, true ),
			(int) $this->get_meta( self::META_RECURRING_MAX_OCCURRENCES, true )
		);
	}

	/**
	 * @param int $min Raw minimum.
	 * @param int $max Raw maximum.
	 * @return array{min: int, max: int}
	 */
	private static function sanitize_recurring_occurrence_limits( $min, $max ) {
		$min = (int) $min;
		$max = (int) $max;

		if ( $min < 2 ) {
			$min = self::RECURRING_DEFAULT_MIN_OCCURRENCES;
		}
		if ( $max < 2 ) {
			$max = self::RECURRING_DEFAULT_MAX_OCCURRENCES;
		}

		$abs_max = self::RECURRING_ABSOLUTE_MAX_OCCURRENCES;
		$min     = max( 2, min( $abs_max, $min ) );
		$max     = max( $min, min( $abs_max, $max ) );

		return array(
			'min' => $min,
			'max' => $max,
		);
	}

	/** @var array{min: int, max: int}|null */
	private $recurring_limits_filtered_cache;

	/** @var string[]|null */
	private $recurring_payment_options_cache;

	/**
	 * @return array{min: int, max: int}
	 */
	private function get_recurring_limits_filtered() {
		if ( null !== $this->recurring_limits_filtered_cache ) {
			return $this->recurring_limits_filtered_cache;
		}

		$limits = $this->get_recurring_occurrence_limits();

		$this->recurring_limits_filtered_cache = array(
			'min' => (int) apply_filters( 'wc_appointments_recurring_min_occurrences', $limits['min'], $this ),
			'max' => (int) apply_filters( 'wc_appointments_recurring_max_occurrences', $limits['max'], $this ),
		);

		return $this->recurring_limits_filtered_cache;
	}

	/**
	 * Valid payment model identifiers for recurring packages.
	 *
	 * @return string[]
	 */
	public static function get_valid_recurring_payment_models() {
		return array(
			WC_Appointment_Series::PAYMENT_PREPAID,
			WC_Appointment_Series::PAYMENT_PAY_FIRST,
		);
	}

	/**
	 * Admin select: prepaid, pay_first, or both.
	 *
	 * @return array<string, string>
	 */
	public static function get_recurring_payment_setting_choices() {
		return array(
			WC_Appointment_Series::PAYMENT_PREPAID   => __( 'Pay for all appointments now', 'woocommerce-appointments' ),
			WC_Appointment_Series::PAYMENT_PAY_FIRST => __( 'Pay for first appointment only', 'woocommerce-appointments' ),
			'both'                                   => __( 'Customer chooses on booking form', 'woocommerce-appointments' ),
		);
	}

	/**
	 * Stored payment setting (prepaid|pay_first|both); legacy comma meta supported.
	 *
	 * @return string
	 */
	public function get_recurring_payment_setting() {
		$raw    = trim( (string) $this->get_meta( self::META_RECURRING_PAYMENT_OPTIONS ) );
		$models = self::get_valid_recurring_payment_models();

		if ( 'both' === $raw || in_array( $raw, $models, true ) ) {
			return 'both' === $raw ? 'both' : $raw;
		}

		if ( '' !== $raw && false !== strpos( $raw, ',' ) ) {
			$parts = array_values( array_intersect( array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw ) ) ), $models ) );
			return count( $parts ) >= 2 ? 'both' : ( $parts[0] ?? 'both' );
		}

		return 'both';
	}

	/**
	 * Payment models offered on the recurring booking form. Filter: `wc_appointments_recurring_payment_options`.
	 *
	 * @return string[]
	 */
	public function get_recurring_payment_options() {
		if ( null !== $this->recurring_payment_options_cache ) {
			return $this->recurring_payment_options_cache;
		}

		$setting = $this->get_recurring_payment_setting();
		$models  = self::get_valid_recurring_payment_models();
		$options = ( 'both' === $setting ) ? $models : ( in_array( $setting, $models, true ) ? array( $setting ) : $models );

		$this->recurring_payment_options_cache = (array) apply_filters( 'wc_appointments_recurring_payment_options', $options, $this );

		return $this->recurring_payment_options_cache;
	}

	/**
	 * Storefront pre-selection (prepaid). Filter: `wc_appointments_recurring_default_payment_model`.
	 *
	 * @return string
	 */
	public function get_recurring_default_payment_model() {
		$allowed = $this->get_recurring_payment_options();
		$default = (string) apply_filters( 'wc_appointments_recurring_default_payment_model', WC_Appointment_Series::PAYMENT_PREPAID, $this );

		return in_array( $default, $allowed, true ) ? $default : ( $allowed[0] ?? WC_Appointment_Series::PAYMENT_PREPAID );
	}

	/**
	 * @param string $model WC_Appointment_Series::PAYMENT_* constant.
	 * @return bool
	 */
	private function allows_recurring_payment( $model ) {
		return in_array( $model, $this->get_recurring_payment_options(), true );
	}

	/** @return bool */
	public function allows_pay_first_recurring() {
		return $this->allows_recurring_payment( WC_Appointment_Series::PAYMENT_PAY_FIRST );
	}

	/** @return bool */
	public function allows_prepaid_recurring() {
		return $this->allows_recurring_payment( WC_Appointment_Series::PAYMENT_PREPAID );
	}

	/**
	 * Resolve a requested payment model against this product's allowed options.
	 *
	 * @param string $requested Posted or previewed model ('' falls back to default).
	 * @return string
	 */
	public function resolve_recurring_payment_model( $requested = '' ) {
		$requested = sanitize_key( (string) $requested );
		$allowed   = $this->get_recurring_payment_options();

		return in_array( $requested, $allowed, true ) ? $requested : $this->get_recurring_default_payment_model();
	}

	/**
	 * Storefront recurring picker: payment option label + description per model.
	 *
	 * @return array<string, array{label: string, description: string}>
	 */
	public static function get_recurring_payment_storefront_copy() {
		return array(
			WC_Appointment_Series::PAYMENT_PREPAID   => array(
				'label'       => __( 'Pay for all appointments now', 'woocommerce-appointments' ),
				'description' => __( 'Charged today.', 'woocommerce-appointments' ),
			),
			WC_Appointment_Series::PAYMENT_PAY_FIRST => array(
				'label'       => __( 'Pay for first appointment only', 'woocommerce-appointments' ),
				'description' => __( 'Balance due before later appointments.', 'woocommerce-appointments' ),
			),
		);
	}

	/**
	 * @return array<string, mixed>
	 */
	public function get_recurring_customer_options() {
		$freqs        = $this->get_recurring_allowed_freqs();
		$limits       = $this->get_recurring_limits_filtered();
		$payment_opts = $this->get_recurring_payment_options();

		return array(
			'allowedFreqs'        => $freqs,
			'defaultFreq'       => $freqs[0],
			'minOccurrences'    => $limits['min'],
			'maxOccurrences'    => $limits['max'],
			'recurringMode'     => self::RECURRING_MODE_PREPAID,
			'isPrepaid'         => true,
			'paymentOptions'    => $payment_opts,
			'defaultPaymentModel' => $this->get_recurring_default_payment_model(),
			'allowPayFirst'     => in_array( WC_Appointment_Series::PAYMENT_PAY_FIRST, $payment_opts, true ),
			'allowPrepaid'      => in_array( WC_Appointment_Series::PAYMENT_PREPAID, $payment_opts, true ),
		);
	}

	/**
	 * @param string               $rrule RRULE line.
	 * @param array<string, mixed> $args    Unused.
	 * @return string|WP_Error
	 */
	public function enforce_recurring_rrule( $rrule, $args = array() ) {
		unset( $args );
		$rrule = trim( (string) $rrule );
		if ( '' === $rrule ) {
			return new WP_Error( 'wca_rrule_required', __( 'Choose a repeat schedule.', 'woocommerce-appointments' ) );
		}

		$extra_lines = array();
		$rrule_line  = $rrule;
		foreach ( WC_Appointment_Series_RRule::parse_ical_lines( $rrule ) as $line ) {
			if ( preg_match( '/^(EXDATE|RDATE)[;:]/i', $line ) ) {
				$extra_lines[] = $line;
				continue;
			}
			if ( 0 === stripos( $line, 'RRULE:' ) ) {
				$rrule_line = $line;
			}
		}

		$body  = preg_replace( '/^RRULE:/i', '', $rrule_line );
		$parts = array();
		foreach ( array_filter( array_map( 'trim', explode( ';', $body ) ) ) as $segment ) {
			$kv = explode( '=', $segment, 2 );
			if ( 2 === count( $kv ) ) {
				$parts[ strtoupper( $kv[0] ) ] = $kv[1];
			}
		}

		$freq = isset( $parts['FREQ'] ) ? strtoupper( $parts['FREQ'] ) : '';
		if ( ! in_array( $freq, $this->get_recurring_allowed_freqs(), true ) ) {
			return new WP_Error(
				'wca_rrule_freq',
				__( 'This repeat frequency is not allowed for this service.', 'woocommerce-appointments' )
			);
		}

		$interval = isset( $parts['INTERVAL'] ) ? max( 1, (int) $parts['INTERVAL'] ) : 1;
		if ( $interval > 12 ) {
			$interval = 12;
		}

		if ( isset( $parts['BYDAY'] ) && 'WEEKLY' !== $freq ) {
			unset( $parts['BYDAY'] );
		}

		$limits = $this->get_recurring_limits_filtered();
		$out    = array( 'FREQ=' . $freq );

		if ( $interval > 1 ) {
			$out[] = 'INTERVAL=' . $interval;
		}
		if ( isset( $parts['BYDAY'] ) && '' !== $parts['BYDAY'] ) {
			$out[] = 'BYDAY=' . $parts['BYDAY'];
		}

		$has_until = isset( $parts['UNTIL'] ) && '' !== $parts['UNTIL'];
		$has_count = isset( $parts['COUNT'] ) && '' !== $parts['COUNT'];

		if ( $has_until ) {
			$out[] = 'UNTIL=' . $parts['UNTIL'];
		} elseif ( $has_count ) {
			$out[] = 'COUNT=' . max( $limits['min'], min( $limits['max'], (int) $parts['COUNT'] ) );
		} else {
			return new WP_Error(
				'wca_rrule_end',
				__( 'Choose when the package ends (date or number of appointments).', 'woocommerce-appointments' )
			);
		}

		$normalized = 'RRULE:' . implode( ';', $out );
		if ( ! empty( $extra_lines ) ) {
			$normalized .= "\n" . implode( "\n", array_unique( $extra_lines ) );
		}
		return $normalized;
	}

	/**
	 * @param array<string, mixed> $booking_data Posted appointment fields.
	 * @return array{staff_assignment_mode: string, locked_staff_id: int}
	 */
	public function get_recurring_series_staff_from_booking( $booking_data ) {
		if ( ! $this->has_staff() || ! $this->is_staff_assignment_type( 'customer' ) ) {
			return self::normalize_recurring_series_staff( '' );
		}

		$staff_id = ! empty( $booking_data['_staff_id'] ) ? (int) $booking_data['_staff_id'] : 0;
		if ( $staff_id > 0 && $this->get_staff_member( $staff_id ) ) {
			return self::normalize_recurring_series_staff( WC_Appointment_Series::STAFF_LOCK_TO_FIRST, $staff_id );
		}

		return self::normalize_recurring_series_staff( '' );
	}

	/**
	 * Save recurring product fields from the admin product screen.
	 *
	 * @param WC_Product $product Product.
	 * @return void
	 */
	public static function save_recurring_admin_fields( $product ) {
		if ( ! is_wc_appointment_product( $product ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$allow_recurring = isset( $_POST['_wc_appointment_allow_recurring'] );
		$product->update_meta_data( '_wc_appointment_allow_recurring', $allow_recurring ? 'yes' : 'no' );

		$posted_freqs = array();
		if ( isset( $_POST['_wc_appointment_recurring_allowed_freqs'] ) && is_array( $_POST['_wc_appointment_recurring_allowed_freqs'] ) ) {
			$posted_freqs = array_map( 'sanitize_key', wp_unslash( $_POST['_wc_appointment_recurring_allowed_freqs'] ) );
		}
		$product->update_meta_data(
			'_wc_appointment_recurring_allowed_freqs',
			implode( ',', self::sanitize_recurring_allowed_freqs( $posted_freqs ) )
		);

		if ( $allow_recurring ) {
			$min_occurrences = filter_input( INPUT_POST, self::META_RECURRING_MIN_OCCURRENCES, FILTER_SANITIZE_NUMBER_INT );
			$max_occurrences = filter_input( INPUT_POST, self::META_RECURRING_MAX_OCCURRENCES, FILTER_SANITIZE_NUMBER_INT );
			$limits          = self::sanitize_recurring_occurrence_limits(
				false !== $min_occurrences ? (int) $min_occurrences : 0,
				false !== $max_occurrences ? (int) $max_occurrences : 0
			);
			$product->update_meta_data( self::META_RECURRING_MIN_OCCURRENCES, $limits['min'] );
			$product->update_meta_data( self::META_RECURRING_MAX_OCCURRENCES, $limits['max'] );

			$payment_choices = self::get_recurring_payment_setting_choices();
			$posted          = sanitize_key( wp_unslash( $_POST[ self::META_RECURRING_PAYMENT_OPTIONS ] ?? '' ) );
			if ( ! isset( $payment_choices[ $posted ] ) ) {
				$posted = 'both';
			}
			$product->update_meta_data( self::META_RECURRING_PAYMENT_OPTIONS, $posted );
			$product->delete_meta_data( '_wc_appointment_recurring_default_payment_model' );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * @param array<string, mixed> $line_data Order line `_wca_recurring` meta.
	 * @return array{staff_assignment_mode: string, locked_staff_id: int}
	 */
	public static function get_recurring_series_staff_from_line( $line_data ) {
		$line_data = is_array( $line_data ) ? $line_data : array();
		if ( ! isset( $line_data['staff_assignment_mode'] ) ) {
			return self::normalize_recurring_series_staff( '' );
		}

		return self::normalize_recurring_series_staff(
			(string) $line_data['staff_assignment_mode'],
			isset( $line_data['locked_staff_id'] ) ? (int) $line_data['locked_staff_id'] : 0
		);
	}

	/**
	 * @param string $mode Staff assignment mode from booking or order line meta.
	 * @param int    $locked_staff_id Staff ID when mode is lock-to-first.
	 * @return array{staff_assignment_mode: string, locked_staff_id: int}
	 */
	private static function normalize_recurring_series_staff( $mode, $locked_staff_id = 0 ) {
		$auto = array(
			'staff_assignment_mode' => 'auto_per_occurrence',
			'locked_staff_id'       => 0,
		);

		if ( ! in_array( $mode, array( WC_Appointment_Series::STAFF_LOCK_TO_FIRST, 'auto_per_occurrence' ), true ) ) {
			return $auto;
		}

		return array(
			'staff_assignment_mode' => $mode,
			'locked_staff_id'       => (int) $locked_staff_id,
		);
	}
}
