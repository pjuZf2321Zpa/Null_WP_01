<?php
/**
 * Location data object (`wca_location` CPT).
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Location entity: physical or online place of service.
 *
 * @since 5.5.0
 */
class WC_Appointments_Location extends WC_Appointments_CPT_Data {

	public const DATA_STORE = 'appointments-location';
	public const POST_TYPE  = 'wca_location';

	protected $object_type = 'appointments_location';
	protected $cache_group = 'appointments-location';

	/** @var array<string, mixed> */
	protected $data = [
		'name'            => '',
		'status'          => 'publish',
		'kind'            => 'physical',
		'instructions'    => '',
		'address'         => '',
		'city'            => '',
		'state'           => '',
		'postcode'        => '',
		'country'         => '',
		'phone'           => '',
		'static_join_url' => '',
		'date_created'    => null, // Interface; CPT dates live on the post.
		'date_modified'   => null,
	];

	protected function data_store_key(): string {
		return self::DATA_STORE;
	}

	public function get_kind( string $context = 'view' ): string {
		return (string) $this->get_field( 'kind', $context );
	}

	// --- Domain / CPT admin (merged from helper) ---
	const SNAPSHOT_VERSION  = 1;
	const MODE_NONE         = 'none';
	const MODE_FIXED        = 'fixed';
	const MODE_HIDDEN       = 'hidden';
	const MODE_CUSTOMER     = 'customer_choice';
	const KIND_PHYSICAL     = 'physical';
	const KIND_ONLINE       = 'online';

	/**
	 * Whether mode auto-assigns one location (Fixed show name, or Fixed hidden).
	 *
	 * @since 5.5.0
	 * @param string $mode Location mode.
	 */
	public static function is_fixed_mode( string $mode ): bool {
		return in_array( $mode, [ self::MODE_FIXED, self::MODE_HIDDEN ], true );
	}

	/**
	 * Whether location should be shown to the current audience.
	 *
	 * Admin always sees a stored venue. Customers skip Location mode Fixed (hidden).
	 * Same contract as {@see WC_Appointments_Resource::should_display()}.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @param bool           $is_admin    Admin / staff email context.
	 */
	public static function should_display( $appointment, bool $is_admin = false ): bool {
		if ( ! is_a( $appointment, 'WC_Appointment' ) || ! $appointment->has_location() ) {
			return false;
		}
		if ( $is_admin ) {
			return true;
		}
		$product = $appointment->get_product();
		if ( ! $product instanceof WC_Product_Appointment ) {
			return false;
		}
		return self::MODE_HIDDEN !== $product->get_location_mode();
	}

	/**
	 * Formatted location for the current audience, or empty when hidden.
	 *
	 * Same contract as {@see WC_Appointments_Resource::get_context_display()}.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @param bool           $is_admin    Admin context.
	 */
	public static function get_context_display( $appointment, bool $is_admin = false ): string {
		if ( ! self::should_display( $appointment, $is_admin ) ) {
			return '';
		}
		return class_exists( 'WC_Appointments_Meetings' )
			? WC_Appointments_Meetings::format_location_display( $appointment )
			: $appointment->get_location_display();
	}

	/**
	 * Human label for a location kind.
	 *
	 * @since 5.5.0
	 * @param string $kind Kind slug (`physical` / `online`).
	 */
	public static function get_kind_label( string $kind ): string {
		return self::KIND_ONLINE === $kind
			? _x( 'Online', 'appointment location kind', 'woocommerce-appointments' )
			: _x( 'In person', 'appointment location kind', 'woocommerce-appointments' );
	}

	/**
	 * Boot hooks.
	 *
	 * @since 5.5.0
	 */
	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'register_post_type' ], 6 );
		add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_boxes' ] );
		add_action( 'edit_form_after_title', [ __CLASS__, 'render_title_hint' ] );
		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'save_meta' ], 10, 2 );
		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'claim_unscoped_resources_after_save' ], 20, 2 );
		add_action( 'before_delete_post', [ __CLASS__, 'before_delete_location' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_scripts' ] );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', [ __CLASS__, 'list_columns' ] );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', [ __CLASS__, 'render_list_column' ], 10, 2 );
	}

	/**
	 * Enhanced select + WC admin styles on location edit screens.
	 *
	 * @since 5.5.0
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue_admin_scripts( string $hook_suffix ): void {
		$screen = get_current_screen();
		if ( ! $screen || self::POST_TYPE !== $screen->post_type ) {
			return;
		}
		if ( ! in_array( $hook_suffix, [ 'post.php', 'post-new.php' ], true ) ) {
			return;
		}

		wp_enqueue_style( 'woocommerce_admin_styles' );
		wp_enqueue_style( 'select2' );
		wp_enqueue_script( 'jquery-tiptip' );
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_add_inline_script(
			'jquery-tiptip',
			'jQuery(function($){$(".woocommerce-help-tip").tipTip({attribute:"aria-label",fadeIn:50,fadeOut:50,delay:200,keepAlive:true});});'
		);
	}

	/**
	 * Register private CPT under Appointments menu.
	 *
	 * @since 5.5.0
	 */
	public static function register_post_type(): void {
		$ui = WC_Appointments_Features::is_locations_resources_active();

		register_post_type(
			self::POST_TYPE,
			[
				'labels'              => [
					'name'               => __( 'Locations', 'woocommerce-appointments' ),
					'singular_name'      => __( 'Location', 'woocommerce-appointments' ),
					'add_new'            => __( 'Add Location', 'woocommerce-appointments' ),
					'add_new_item'       => __( 'Add New Location', 'woocommerce-appointments' ),
					'edit_item'          => __( 'Edit Location', 'woocommerce-appointments' ),
					'new_item'           => __( 'New Location', 'woocommerce-appointments' ),
					'view_item'          => __( 'View Location', 'woocommerce-appointments' ),
					'search_items'       => __( 'Search Locations', 'woocommerce-appointments' ),
					'not_found'          => __( 'No locations found', 'woocommerce-appointments' ),
					'not_found_in_trash' => __( 'No locations found in trash', 'woocommerce-appointments' ),
					'menu_name'          => __( 'Locations', 'woocommerce-appointments' ),
					'all_items'          => __( 'Locations', 'woocommerce-appointments' ),
				],
				'description'         => __( 'Locations for appointable products.', 'woocommerce-appointments' ),
				'public'              => false,
				'show_ui'             => $ui,
				'capability_type'     => 'appointment',
				'map_meta_cap'        => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_in_menu'        => $ui ? 'edit.php?post_type=wc_appointment' : false,
				'hierarchical'        => false,
				'show_in_nav_menus'   => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => [ 'title' ],
				'has_archive'         => false,
			]
		);
	}

	/**
	 * Admin list columns.
	 *
	 * @since 5.5.0
	 *
	 * @param array<string, string> $columns Columns.
	 * @return array<string, string>
	 */
	public static function list_columns( array $columns ): array {
		$out = [];
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'title' === $key ) {
				$out['wca_location_kind']  = __( 'Type', 'woocommerce-appointments' );
				$out['wca_location_where'] = __( 'Where', 'woocommerce-appointments' );
			}
		}
		return $out;
	}

	/**
	 * Render admin list column values.
	 *
	 * @since 5.5.0
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 */
	public static function render_list_column( string $column, int $post_id ): void {
		$location = get_wc_appointments_location( $post_id );
		if ( ! $location ) {
			return;
		}
		if ( 'wca_location_kind' === $column ) {
			echo esc_html( self::get_kind_label( $location->get_kind() ) );
			return;
		}
		if ( 'wca_location_where' === $column ) {
			if ( self::KIND_ONLINE === $location->get_kind() ) {
				$url = (string) $location->get_field( 'static_join_url' );
				echo $url ? esc_html( $url ) : esc_html__( 'No URL', 'woocommerce-appointments' );
				return;
			}
			$bits = array_filter(
				[
					(string) $location->get_field( 'city' ),
					(string) $location->get_field( 'country' ),
				]
			);
			echo $bits ? esc_html( implode( ', ', $bits ) ) : esc_html__( 'No address', 'woocommerce-appointments' );
		}
	}

	/**
	 * Meta boxes on location edit screen.
	 *
	 * @since 5.5.0
	 */
	public static function add_meta_boxes(): void {
		add_meta_box(
			'wca_location_details',
			__( 'Location', 'woocommerce-appointments' ),
			[ __CLASS__, 'render_meta_box' ],
			self::POST_TYPE,
			'normal',
			'high'
		);
		add_meta_box(
			'wca_location_used_by',
			__( 'Products', 'woocommerce-appointments' ),
			[ __CLASS__, 'render_used_by_meta_box' ],
			self::POST_TYPE,
			'side',
			'default'
		);
		add_meta_box(
			'wca_location_resources',
			__( 'Resources', 'woocommerce-appointments' ),
			[ __CLASS__, 'render_resources_meta_box' ],
			self::POST_TYPE,
			'side',
			'low'
		);
	}

	/**
	 * Hint under the post title.
	 *
	 * @since 5.5.0
	 *
	 * @param WP_Post $post Post.
	 */
	public static function render_title_hint( $post ): void {
		if ( ! is_object( $post ) || self::POST_TYPE !== $post->post_type ) {
			return;
		}
		echo '<p class="description">';
		esc_html_e( 'The title is the name customers see.', 'woocommerce-appointments' );
		echo '</p>';
	}

	/**
	 * Render location meta box.
	 *
	 * @since 5.5.0
	 *
	 * @param WP_Post $post Post.
	 */
	public static function render_meta_box( $post ): void {
		$location        = get_wc_appointments_location( (int) $post->ID );
		$kind            = $location ? $location->get_kind() : self::KIND_PHYSICAL;
		$kind            = in_array( $kind, [ self::KIND_PHYSICAL, self::KIND_ONLINE ], true ) ? $kind : self::KIND_PHYSICAL;
		$instructions    = $location ? (string) $location->get_field( 'instructions' ) : '';
		$address         = $location ? (string) $location->get_field( 'address' ) : '';
		$city            = $location ? (string) $location->get_field( 'city' ) : '';
		$state           = $location ? (string) $location->get_field( 'state' ) : '';
		$postcode        = $location ? (string) $location->get_field( 'postcode' ) : '';
		$country         = $location ? (string) $location->get_field( 'country' ) : '';
		$phone           = $location ? (string) $location->get_field( 'phone' ) : '';
		$static_join_url = $location ? (string) $location->get_field( 'static_join_url' ) : '';

		$countries = [ '' => '' ];
		if ( function_exists( 'WC' ) && WC()->countries ) {
			$countries = $countries + WC()->countries->get_countries();
		}

		wp_nonce_field( 'wca_location_save', 'wca_location_nonce' );
		?>
		<div class="wca-location-edit">
			<div class="wca-location-type" role="radiogroup" aria-label="<?php esc_attr_e( 'Type', 'woocommerce-appointments' ); ?>">
				<label>
					<input type="radio" name="wca_location_kind" value="<?php echo esc_attr( self::KIND_PHYSICAL ); ?>" <?php checked( $kind, self::KIND_PHYSICAL ); ?>>
					<?php echo esc_html( self::get_kind_label( self::KIND_PHYSICAL ) ); ?>
					<small><?php esc_html_e( 'Physical address', 'woocommerce-appointments' ); ?></small>
				</label>
				<label>
					<input type="radio" name="wca_location_kind" value="<?php echo esc_attr( self::KIND_ONLINE ); ?>" <?php checked( $kind, self::KIND_ONLINE ); ?>>
					<?php echo esc_html( self::get_kind_label( self::KIND_ONLINE ) ); ?>
					<small><?php esc_html_e( 'Video or join link', 'woocommerce-appointments' ); ?></small>
				</label>
			</div>

			<div class="wca-location-physical">
				<span class="wca-padding-float wca-location-span">
					<input type="text" name="wca_location_address" id="wca_location_address" value="<?php echo esc_attr( $address ); ?>">
					<label class="wca-padding-float__label" for="wca_location_address"><?php esc_html_e( 'Address', 'woocommerce-appointments' ); ?></label>
				</span>
				<span class="wca-padding-float">
					<input type="text" name="wca_location_city" id="wca_location_city" value="<?php echo esc_attr( $city ); ?>">
					<label class="wca-padding-float__label" for="wca_location_city"><?php esc_html_e( 'City', 'woocommerce-appointments' ); ?></label>
				</span>
				<span class="wca-padding-float">
					<input type="text" name="wca_location_state" id="wca_location_state" value="<?php echo esc_attr( $state ); ?>">
					<label class="wca-padding-float__label" for="wca_location_state"><?php esc_html_e( 'State / Province', 'woocommerce-appointments' ); ?></label>
				</span>
				<span class="wca-padding-float">
					<input type="text" name="wca_location_postcode" id="wca_location_postcode" value="<?php echo esc_attr( $postcode ); ?>">
					<label class="wca-padding-float__label" for="wca_location_postcode"><?php esc_html_e( 'Postcode', 'woocommerce-appointments' ); ?></label>
				</span>
				<span class="wca-padding-float">
					<select name="wca_location_country" id="wca_location_country" class="wc-enhanced-select">
						<?php foreach ( $countries as $code => $name ) : ?>
							<option value="<?php echo esc_attr( (string) $code ); ?>" <?php selected( $country, (string) $code ); ?>><?php echo esc_html( (string) $name ); ?></option>
						<?php endforeach; ?>
					</select>
					<label class="wca-padding-float__label" for="wca_location_country"><?php esc_html_e( 'Country', 'woocommerce-appointments' ); ?></label>
				</span>
				<span class="wca-padding-float wca-location-span">
					<input type="tel" name="wca_location_phone" id="wca_location_phone" value="<?php echo esc_attr( $phone ); ?>">
					<label class="wca-padding-float__label" for="wca_location_phone"><?php esc_html_e( 'Phone', 'woocommerce-appointments' ); ?></label>
				</span>
			</div>

			<div class="wca-location-online">
				<span class="wca-padding-float wca-location-span">
					<input type="url" name="wca_location_static_join_url" id="wca_location_static_join_url" value="<?php echo esc_attr( $static_join_url ); ?>">
					<label class="wca-padding-float__label" for="wca_location_static_join_url">
						<?php esc_html_e( 'Join URL', 'woocommerce-appointments' ); ?>
						<?php echo wc_help_tip( esc_html__( 'Optional. Used when the product does not generate a meeting link.', 'woocommerce-appointments' ) ); ?>
					</label>
				</span>
			</div>

			<span class="wca-padding-float wca-location-span">
				<textarea name="wca_location_instructions" id="wca_location_instructions" rows="3"><?php echo esc_textarea( $instructions ); ?></textarea>
				<label class="wca-padding-float__label" for="wca_location_instructions">
					<?php esc_html_e( 'Instructions', 'woocommerce-appointments' ); ?>
					<?php echo wc_help_tip( esc_html__( 'Shown to the customer for this location.', 'woocommerce-appointments' ) ); ?>
				</label>
			</span>
		</div>
		<?php
		echo wp_kses_post(
			sprintf(
				'<p class="description wca-hub-deeplink-notice">%s</p>',
				'auto-draft' === $post->post_status
					? esc_html__( 'Save the location (a draft is fine) to set open hours and unavailable times.', 'woocommerce-appointments' )
					: sprintf(
						/* translators: %s: link to the Availability hub (opens in a new tab). */
						esc_html__( 'Open hours and unavailable times for this location are managed in the %s.', 'woocommerce-appointments' ),
						WC_Appointments_Admin_Availability_Hub::external_anchor(
							WC_Appointments_Admin_Availability_Hub::url( 'location', $post->ID ),
							__( 'Availability hub', 'woocommerce-appointments' )
						)
					)
			)
		);
	}

	/**
	 * Persist location meta.
	 *
	 * @since 5.5.0
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 */
	public static function save_meta( $post_id, $post ): void {
		if ( ! isset( $_POST['wca_location_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wca_location_nonce'] ) ), 'wca_location_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$location = get_wc_appointments_location( (int) $post_id );
		if ( ! $location ) {
			return;
		}

		$kind = isset( $_POST['wca_location_kind'] ) ? sanitize_text_field( wp_unslash( $_POST['wca_location_kind'] ) ) : self::KIND_PHYSICAL;
		if ( ! in_array( $kind, [ self::KIND_PHYSICAL, self::KIND_ONLINE ], true ) ) {
			$kind = self::KIND_PHYSICAL;
		}

		$location->set_fields(
			[
				'kind'            => $kind,
				'instructions'    => isset( $_POST['wca_location_instructions'] ) ? sanitize_textarea_field( wp_unslash( $_POST['wca_location_instructions'] ) ) : '',
				'address'         => isset( $_POST['wca_location_address'] ) ? sanitize_text_field( wp_unslash( $_POST['wca_location_address'] ) ) : '',
				'city'            => isset( $_POST['wca_location_city'] ) ? sanitize_text_field( wp_unslash( $_POST['wca_location_city'] ) ) : '',
				'state'           => isset( $_POST['wca_location_state'] ) ? sanitize_text_field( wp_unslash( $_POST['wca_location_state'] ) ) : '',
				'postcode'        => isset( $_POST['wca_location_postcode'] ) ? sanitize_text_field( wp_unslash( $_POST['wca_location_postcode'] ) ) : '',
				'country'         => isset( $_POST['wca_location_country'] ) ? sanitize_text_field( wp_unslash( $_POST['wca_location_country'] ) ) : '',
				'phone'           => isset( $_POST['wca_location_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['wca_location_phone'] ) ) : '',
				'static_join_url' => isset( $_POST['wca_location_static_join_url'] ) ? esc_url_raw( wp_unslash( $_POST['wca_location_static_join_url'] ) ) : '',
			]
		);
		$location->save();
	}

	/**
	 * When a venue is published, claim any resources that still have no location.
	 *
	 * Bypasses the one-shot init migration flag so venues added later still claim rooms.
	 *
	 * @since 5.5.0
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 */
	public static function claim_unscoped_resources_after_save( $post_id, $post ): void {
		if ( ! is_object( $post ) || self::POST_TYPE !== $post->post_type ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( 'publish' !== $post->post_status ) {
			return;
		}
		if ( ! class_exists( 'WC_Appointments_Resource' ) ) {
			return;
		}
		WC_Appointments_Resource::claim_unscoped_resource_locations();
	}

	/**
	 * Read-only list of appointable products that allow this location.
	 *
	 * @since 5.5.0
	 *
	 * @param WP_Post $post Location post.
	 */
	public static function render_used_by_meta_box( $post ): void {
		$location_id = is_object( $post ) ? (int) $post->ID : 0;
		$product_ids = $location_id > 0 ? self::get_product_ids_using_location( $location_id ) : [];

		if ( ! $product_ids ) {
			echo '<p class="description">';
			esc_html_e( 'No products use this location yet. Assign it on the product Location tab.', 'woocommerce-appointments' );
			echo '</p>';
		} else {
			$default_color = WC_Appointments_Admin::get_default_cal_color();
			echo '<ul class="wca-location-used-by">';
			foreach ( $product_ids as $product_id ) {
				$title = get_the_title( $product_id );
				if ( '' === $title ) {
					/* translators: %d: product ID */
					$title = sprintf( __( 'Product #%d', 'woocommerce-appointments' ), $product_id );
				}
				$color = trim( (string) get_post_meta( $product_id, '_wc_appointment_cal_color', true ) );
				$url   = get_edit_post_link( $product_id, 'raw' );
				$dot   = sprintf(
					'<span class="wca-product-color-dot" style="--wca-dot-color:%s" aria-hidden="true"></span>',
					esc_attr( '' !== $color ? $color : $default_color )
				);
				echo '<li>';
				if ( $url ) {
					printf(
						'<a class="wca-location-used-by__link" href="%s"><span class="wca-location-used-by__title">%s</span>%s</a>',
						esc_url( $url . '#appointments_locations' ),
						esc_html( $title ),
						$dot // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
					);
				} else {
					echo '<span class="wca-location-used-by__title">' . esc_html( $title ) . '</span>' . $dot; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				echo '</li>';
			}
			echo '</ul>';
		}

		$can_manage_products = class_exists( 'WC_Appointments_Staff_Permissions' )
			? WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'manage_products' )
			: current_user_can( 'edit_products' );

		if ( $can_manage_products ) {
			echo '<div class="wca-location-used-by-footer">';
			printf(
				'<a href="%s" target="_blank">%s</a>',
				esc_url( admin_url( 'edit.php?post_type=product&product_type=appointment' ) ),
				esc_html__( 'Manage Products', 'woocommerce-appointments' )
			);
			echo ' &middot; ';
			printf(
				'<a href="%s" target="_blank">%s</a>',
				esc_url( admin_url( 'post-new.php?post_type=product&appointable_product=1' ) ),
				esc_html__( 'Add Product', 'woocommerce-appointments' )
			);
			echo '</div>';
		}
	}

	/**
	 * Read-only list of resources available at this location.
	 *
	 * @since 5.5.0
	 *
	 * @param WP_Post $post Location post.
	 */
	public static function render_resources_meta_box( $post ): void {
		$location_id  = is_object( $post ) ? (int) $post->ID : 0;
		$resource_ids = ( $location_id > 0 && class_exists( 'WC_Appointments_Resource' ) )
			? WC_Appointments_Resource_Data_Store::get_ids_for_location( $location_id )
			: [];

		if ( ! $resource_ids ) {
			echo '<p class="description">';
			esc_html_e( 'No resources for this location yet. Assign this venue on the resource edit screen.', 'woocommerce-appointments' );
			echo '</p>';
		} else {
			echo '<ul class="wca-location-used-by">';
			foreach ( $resource_ids as $resource_id ) {
				$title = get_the_title( $resource_id );
				if ( '' === $title ) {
					/* translators: %d: resource ID */
					$title = sprintf( __( 'Resource #%d', 'woocommerce-appointments' ), $resource_id );
				}
				$url   = get_edit_post_link( $resource_id, 'raw' );
				$thumb = get_the_post_thumbnail(
					$resource_id,
					[ 64, 64 ],
					[
						'class' => 'wca-location-used-by__thumb',
						'alt'   => '',
					]
				);
				if ( ! $thumb ) {
					$thumb = '<span class="wca-location-used-by__thumb wca-location-used-by__thumb--placeholder" aria-hidden="true"></span>';
				}
				echo '<li>';
				if ( $url ) {
					printf(
						'<a class="wca-location-used-by__link" href="%s">%s<span class="wca-location-used-by__title">%s</span></a>',
						esc_url( $url ),
						$thumb, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_the_post_thumbnail() / static placeholder.
						esc_html( $title )
					);
				} else {
					echo $thumb; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<span class="wca-location-used-by__title">' . esc_html( $title ) . '</span>';
				}
				echo '</li>';
			}
			echo '</ul>';
		}

		$can_manage_resources = class_exists( 'WC_Appointments_Staff_Permissions' )
			? WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'manage_resources' )
			: current_user_can( 'edit_products' );

		if ( $can_manage_resources ) {
			echo '<div class="wca-location-used-by-footer">';
			printf(
				'<a href="%s" target="_blank">%s</a>',
				esc_url( admin_url( 'edit.php?post_type=wca_resource' ) ),
				esc_html__( 'Manage Resources', 'woocommerce-appointments' )
			);
			echo ' &middot; ';
			printf(
				'<a href="%s" target="_blank">%s</a>',
				esc_url( admin_url( 'post-new.php?post_type=wca_resource' ) ),
				esc_html__( 'Add Resource', 'woocommerce-appointments' )
			);
			echo '</div>';
		}
	}

	/**
	 * Appointable product IDs that allow this location (mode + allow-list rules).
	 *
	 * @since 5.5.0
	 *
	 * @param int $location_id Location post ID.
	 * @return int[]
	 */
	public static function get_product_ids_using_location( int $location_id ): array {
		if ( $location_id <= 0 ) {
			return [];
		}

		$out = [];
		foreach ( WC_Product_Appointment_Data_Store_CPT::get_appointable_product_ids( true ) as $product_id ) {
			$product = get_wc_product_appointment( $product_id );
			if ( $product && self::authorize_location_id( $product, $location_id ) ) {
				$out[] = (int) $product_id;
			}
		}

		return $out;
	}

	/**
	 * Published location posts as id => title.
	 *
	 * @since 5.5.0
	 *
	 * @return array<int, string>
	 */
	public static function get_location_choices(): array {
		if ( ! WC_Appointments_Features::is_locations_resources_active() ) {
			return [];
		}

		$out = [];
		foreach ( WC_Appointments_Location_Data_Store::get_published_ids() as $id ) {
			$out[ $id ] = get_the_title( $id );
		}
		return $out;
	}

	/**
	 * Allowed location IDs for a product (ordered).
	 *
	 * Customer selected with fewer than two listed IDs means every published location.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @return int[]
	 */
	public static function get_allowed_location_ids( $product ): array {
		if ( ! is_a( $product, 'WC_Product_Appointment' ) ) {
			return [];
		}
		$mode = $product->get_location_mode();
		if ( 'none' === $mode ) {
			return [];
		}
		$ids = array_values( array_filter( array_map( 'absint', (array) $product->get_location_ids() ) ) );
		if ( self::is_fixed_mode( $mode ) ) {
			return $ids;
		}
		if ( self::MODE_CUSTOMER === $mode ) {
			if ( count( $ids ) >= 2 ) {
				return $ids;
			}
			return array_values( array_map( 'intval', array_keys( self::get_location_choices() ) ) );
		}
		return [];
	}

	/**
	 * Allowed location ID when the product has exactly one.
	 *
	 * Customer selected with a single listed location uses this automatically (no picker).
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @return int 0 when not exactly one allowed location.
	 */
	public static function sole_allowed_location_id( $product ): int {
		$allowed = self::get_allowed_location_ids( $product );
		return 1 === count( $allowed ) ? (int) $allowed[0] : 0;
	}

	/**
	 * Whether a location ID is allowed for the product.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment $product     Product.
	 * @param int                    $location_id Location ID.
	 * @return bool
	 */
	public static function authorize_location_id( $product, int $location_id ): bool {
		if ( $location_id <= 0 || ! is_a( $product, 'WC_Product_Appointment' ) ) {
			return false;
		}
		$allowed = self::get_allowed_location_ids( $product );
		return in_array( $location_id, $allowed, true );
	}

	/**
	 * Resolve location ID from posted data / product mode.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment   $product Product.
	 * @param array<string, mixed>     $posted  Posted form data.
	 * @return int|WP_Error 0 when none; ID when resolved; WP_Error when invalid.
	 */
	public static function resolve_from_posted( $product, array $posted ) {
		if ( ! is_a( $product, 'WC_Product_Appointment' ) || ! $product->has_locations() ) {
			return 0;
		}

		$mode    = $product->get_location_mode();
		$allowed = self::get_allowed_location_ids( $product );

		if ( self::is_fixed_mode( $mode ) ) {
			return ! empty( $allowed[0] ) ? (int) $allowed[0] : 0;
		}

		if ( self::MODE_CUSTOMER !== $mode ) {
			return 0;
		}

		$posted_id = 0;
		if ( ! empty( $posted['wc_appointments_field_location'] ) ) {
			$posted_id = absint( $posted['wc_appointments_field_location'] );
		} elseif ( ! empty( $posted['location_id'] ) ) {
			$posted_id = absint( $posted['location_id'] );
		}

		if ( $posted_id <= 0 ) {
			$sole = self::sole_allowed_location_id( $product );
			if ( $sole > 0 ) {
				return $sole;
			}
			return new WP_Error( 'wca_location_required', __( 'Please choose a location.', 'woocommerce-appointments' ) );
		}

		if ( ! self::authorize_location_id( $product, $posted_id ) ) {
			return new WP_Error( 'wca_location_invalid', __( 'Selected location is not available for this product.', 'woocommerce-appointments' ) );
		}

		return $posted_id;
	}

	/**
	 * Build immutable snapshot array from a location post.
	 *
	 * @since 5.5.0
	 *
	 * @param int $location_id Location post ID.
	 * @return array<string, mixed>
	 */
	public static function build_snapshot( int $location_id ): array {
		$location = $location_id > 0 ? get_wc_appointments_location( $location_id ) : false;
		if ( ! $location ) {
			return [];
		}

		$kind = $location->get_kind();
		if ( ! in_array( $kind, [ self::KIND_PHYSICAL, self::KIND_ONLINE ], true ) ) {
			$kind = self::KIND_PHYSICAL;
		}

		$snapshot = [
			'snapshot_version' => self::SNAPSHOT_VERSION,
			'title'            => $location->get_name(),
			'kind'             => $kind,
			'instructions'     => (string) $location->get_field( 'instructions' ),
		];

		if ( self::KIND_PHYSICAL === $kind ) {
			$snapshot['address']  = (string) $location->get_field( 'address' );
			$snapshot['city']     = (string) $location->get_field( 'city' );
			$snapshot['state']    = (string) $location->get_field( 'state' );
			$snapshot['postcode'] = (string) $location->get_field( 'postcode' );
			$snapshot['country']  = (string) $location->get_field( 'country' );
			$snapshot['phone']    = (string) $location->get_field( 'phone' );
		} else {
			$snapshot['static_join_url'] = (string) $location->get_field( 'static_join_url' );
		}

		return $snapshot;
	}

	/**
	 * Format snapshot for cart / emails / ICS / display.
	 *
	 * @since 5.5.0
	 *
	 * @param array<string, mixed> $snapshot Snapshot.
	 * @return string
	 */
	public static function format_snapshot_for_display( array $snapshot ): string {
		if ( empty( $snapshot ) ) {
			return '';
		}

		$parts = [];
		$title = isset( $snapshot['title'] ) ? trim( (string) $snapshot['title'] ) : '';
		if ( '' !== $title ) {
			$parts[] = $title;
		}

		$kind = isset( $snapshot['kind'] ) ? (string) $snapshot['kind'] : '';
		if ( self::KIND_PHYSICAL === $kind ) {
			$address_bits = array_filter(
				[
					isset( $snapshot['address'] ) ? trim( (string) $snapshot['address'] ) : '',
					isset( $snapshot['city'] ) ? trim( (string) $snapshot['city'] ) : '',
					isset( $snapshot['state'] ) ? trim( (string) $snapshot['state'] ) : '',
					isset( $snapshot['postcode'] ) ? trim( (string) $snapshot['postcode'] ) : '',
					isset( $snapshot['country'] ) ? trim( (string) $snapshot['country'] ) : '',
				]
			);
			if ( $address_bits ) {
				$parts[] = implode( ', ', $address_bits );
			}
			if ( ! empty( $snapshot['phone'] ) ) {
				$parts[] = (string) $snapshot['phone'];
			}
		} elseif ( self::KIND_ONLINE === $kind ) {
			if ( ! empty( $snapshot['static_join_url'] ) ) {
				$parts[] = (string) $snapshot['static_join_url'];
			}
		}

		if ( ! empty( $snapshot['instructions'] ) ) {
			$parts[] = (string) $snapshot['instructions'];
		}

		return implode( ' - ', $parts );
	}

	/**
	 * Apply location_id + snapshot onto an appointment at write time.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment                $appointment Appointment.
	 * @param int                           $location_id Location ID.
	 * @param array<string, mixed>|null     $snapshot    Optional pre-built snapshot.
	 */
	public static function apply_to_appointment( $appointment, int $location_id, $snapshot = null ): void {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return;
		}
		if ( $location_id <= 0 ) {
			$appointment->set_location_id( 0 );
			$appointment->set_location( [] );
			$appointment->set_meeting_provider( '' );
			return;
		}
		if ( null === $snapshot ) {
			$snapshot = self::build_snapshot( $location_id );
		}
		$product = $appointment->get_product();
		// Stamp product location surcharge at write (same as wc_appointments_get_posted_data).
		if ( is_a( $product, 'WC_Product_Appointment' ) && is_array( $snapshot ) ) {
			$snapshot['cost'] = self::product_location_cost( $product, $location_id );
		}
		$appointment->set_location_id( $location_id );
		$appointment->set_location( is_array( $snapshot ) ? $snapshot : [] );
		$appointment->set_meeting_provider(
			is_a( $product, 'WC_Product_Appointment' ) ? $product->get_meeting_provider() : ''
		);
	}

	/**
	 * Product location surcharge for an ID (string/int keys).
	 *
	 * @since 5.5.1
	 *
	 * @param WC_Product_Appointment $product     Product.
	 * @param int                    $location_id Location ID.
	 */
	public static function product_location_cost( $product, int $location_id ): float {
		if ( $location_id <= 0 || ! is_a( $product, 'WC_Product_Appointment' ) ) {
			return 0.0;
		}
		$costs = $product->get_location_costs();
		return (float) ( $costs[ $location_id ] ?? $costs[ (string) $location_id ] ?? 0 );
	}

	/**
	 * Location ID => cost map for panel preload / product details.
	 *
	 * @since 5.5.1
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @param array<string, mixed>   $id_map  Location id keys (values unused).
	 * @return array<string, float>
	 */
	public static function product_location_costs_map( $product, array $id_map ): array {
		$out = [];
		foreach ( array_keys( $id_map ) as $sid ) {
			$out[ (string) $sid ] = self::product_location_cost( $product, (int) $sid );
		}
		return $out;
	}

	/**
	 * Remove availability#location rules when a location is permanently deleted.
	 *
	 * @since 5.5.0
	 *
	 * @param int $post_id Post ID.
	 */
	public static function before_delete_location( $post_id ): void {
		$post_id = absint( $post_id );
		if ( ! $post_id || self::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		$data_store = WC_Data_Store::load( 'appointments-availability' );
		if ( $data_store && method_exists( $data_store, 'delete_rules_for_kind' ) ) {
			$data_store->delete_rules_for_kind( WC_Appointments_Availability::KIND_LOCATION, $post_id );
		}
	}

}


WC_Appointments_Location::init();
