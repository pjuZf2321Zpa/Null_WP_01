<?php
/**
 * Recurring appointment series data object.
 *
 * @package WooCommerce\Appointments
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Series row mapped from wp_wc_appointment_series.
 */
class WC_Appointment_Series extends WC_Data {

	const STATUS_PENDING   = 'pending';
	const STATUS_ACTIVE    = 'active';
	const STATUS_COMPLETED = 'completed';
	const STATUS_CANCELLED = 'cancelled';

	const PAYMENT_PREPAID   = 'prepaid';
	const PAYMENT_PAY_FIRST = 'pay_first';

	/** Meta keys for pay-first balance tracking (stored in wp_wc_appointment_seriesmeta). */
	const META_SERIES_TOTAL      = '_wca_series_total';
	const META_PAID_UPFRONT      = '_wca_paid_upfront';
	const META_BALANCE_DUE       = '_wca_balance_due';
	const META_BALANCE_STATUS    = '_wca_balance_status';
	const META_BALANCE_ORDER_ID  = '_wca_balance_order_id';
	const META_PAID_SESSION_COUNT = '_wca_paid_session_count';
	const META_QTY                = '_wca_qty';

	const STAFF_LOCK_TO_FIRST       = 'lock_to_first';
	const STAFF_AUTO_PER_OCCURRENCE = 'auto_per_occurrence';

	const DATA_STORE   = 'appointment-series';
	const CACHE_GROUP  = 'wc-appointment-series';

	/**
	 * Object type.
	 *
	 * @var string
	 */
	protected $object_type = 'appointment_series';

	/**
	 * Cache group (cleared when {@see cache_enabled()} is false).
	 *
	 * @var string
	 */
	protected $cache_group = self::CACHE_GROUP;

	/**
	 * Per-request cache for {@see get_balance_order()} (false = resolved, none found).
	 *
	 * @var WC_Order|false|null
	 */
	protected $balance_order_cache;

	/**
	 * Per-request cache for {@see get_checkout_order()} (false = resolved, none found).
	 *
	 * @var WC_Order|false|null
	 */
	protected $checkout_order_cache;

	/**
	 * Row data (matches wp_wc_appointment_series columns).
	 *
	 * @var array<string, mixed>
	 */
	protected $data = array(
		'version'               => 1,
		'status'                => self::STATUS_PENDING,
		'product_id'            => 0,
		'customer_id'           => 0,
		'staff_assignment_mode' => self::STAFF_LOCK_TO_FIRST,
		'locked_staff_id'       => 0,
		'order_id'              => 0,
		'subscription_id'       => 0,
		'payment_model'         => self::PAYMENT_PREPAID,
		'rrule'                 => '',
		'dtstart_ts'            => 0,
		'duration_seconds'      => 0,
		'timezone'              => '',
		'next_materialize_ts'   => 0,
		'last_materialized_ts'  => 0,
		'materialized_count'    => 0,
		'rrule_count_cap'       => 0,
		'notified_created_at'   => 0,
		'created_at'            => '',
		'updated_at'            => '',
	);

	/**
	 * Whether series row and meta object caching is enabled.
	 *
	 * @return bool
	 */
	public static function cache_enabled() {
		return (bool) apply_filters( 'wc_appointments_series_cache_enabled', false );
	}

	/**
	 * @return string WC_Data meta cache group (empty when caching is off).
	 */
	public function get_cache_group() {
		return self::cache_enabled() ? self::CACHE_GROUP : '';
	}

	/**
	 * @param int|WC_Appointment_Series $series Series id or instance.
	 */
	public function __construct( $series = 0 ) {
		if ( ! self::cache_enabled() ) {
			$this->cache_group = '';
		}

		parent::__construct( $series );

		if ( is_numeric( $series ) && 0 < $series ) {
			$this->set_id( $series );
		} elseif ( $series instanceof self ) {
			$this->set_id( $series->get_id() );
		} else {
			$this->set_object_read( true );
		}

		$this->data_store = WC_Data_Store::load( self::DATA_STORE );

		if ( $this->get_id() > 0 ) {
			$this->data_store->read( $this );
		}
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_version( $context = 'view' ) {
		return (int) $this->get_prop( 'version', $context );
	}

	/**
	 * @param int $version Row version.
	 * @return void
	 */
	public function set_version( $version ) {
		$this->set_prop( 'version', (int) $version );
	}

	/**
	 * @param string $context view|edit.
	 * @return string
	 */
	public function get_status( $context = 'view' ) {
		return (string) $this->get_prop( 'status', $context );
	}

	/**
	 * @param string $status Series status.
	 * @return void
	 */
	public function set_status( $status ) {
		$this->set_prop( 'status', (string) $status );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_product_id( $context = 'view' ) {
		return (int) $this->get_prop( 'product_id', $context );
	}

	/**
	 * @param int $product_id Product id.
	 * @return void
	 */
	public function set_product_id( $product_id ) {
		$this->set_prop( 'product_id', (int) $product_id );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_customer_id( $context = 'view' ) {
		return (int) $this->get_prop( 'customer_id', $context );
	}

	/**
	 * @param int $customer_id Customer user id.
	 * @return void
	 */
	public function set_customer_id( $customer_id ) {
		$this->set_prop( 'customer_id', (int) $customer_id );
	}

	/**
	 * @param string $context view|edit.
	 * @return string
	 */
	public function get_staff_assignment_mode( $context = 'view' ) {
		return (string) $this->get_prop( 'staff_assignment_mode', $context );
	}

	/**
	 * @param string $mode Staff assignment mode.
	 * @return void
	 */
	public function set_staff_assignment_mode( $mode ) {
		$this->set_prop( 'staff_assignment_mode', (string) $mode );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_locked_staff_id( $context = 'view' ) {
		return (int) $this->get_prop( 'locked_staff_id', $context );
	}

	/**
	 * @param int $staff_id Locked staff id.
	 * @return void
	 */
	public function set_locked_staff_id( $staff_id ) {
		$this->set_prop( 'locked_staff_id', (int) $staff_id );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_order_id( $context = 'view' ) {
		return (int) $this->get_prop( 'order_id', $context );
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public function set_order_id( $order_id ) {
		$this->set_prop( 'order_id', (int) $order_id );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_subscription_id( $context = 'view' ) {
		return (int) $this->get_prop( 'subscription_id', $context );
	}

	/**
	 * @param int $subscription_id Subscription post id.
	 * @return void
	 */
	public function set_subscription_id( $subscription_id ) {
		$this->set_prop( 'subscription_id', (int) $subscription_id );
	}

	/**
	 * @param string $context view|edit.
	 * @return string
	 */
	public function get_payment_model( $context = 'view' ) {
		return (string) $this->get_prop( 'payment_model', $context );
	}

	/**
	 * @param string $payment_model Payment model.
	 * @return void
	 */
	public function set_payment_model( $payment_model ) {
		$this->set_prop( 'payment_model', (string) $payment_model );
	}

	/**
	 * @param string $context view|edit.
	 * @return string
	 */
	public function get_rrule( $context = 'view' ) {
		return (string) $this->get_prop( 'rrule', $context );
	}

	/**
	 * @param string $rrule iCal RRULE block.
	 * @return void
	 */
	public function set_rrule( $rrule ) {
		$this->set_prop( 'rrule', (string) $rrule );
	}

	/**
	 * @param string $context view|edit.
	 * @return int Fake-UTC anchor timestamp.
	 */
	public function get_dtstart_ts( $context = 'view' ) {
		return (int) $this->get_prop( 'dtstart_ts', $context );
	}

	/**
	 * @param int $dtstart_ts Anchor timestamp.
	 * @return void
	 */
	public function set_dtstart_ts( $dtstart_ts ) {
		$this->set_prop( 'dtstart_ts', (int) $dtstart_ts );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_duration_seconds( $context = 'view' ) {
		return (int) $this->get_prop( 'duration_seconds', $context );
	}

	/**
	 * @param int $duration_seconds Occurrence duration.
	 * @return void
	 */
	public function set_duration_seconds( $duration_seconds ) {
		$this->set_prop( 'duration_seconds', (int) $duration_seconds );
	}

	/**
	 * @param string $context view|edit.
	 * @return string IANA timezone id.
	 */
	public function get_timezone( $context = 'view' ) {
		return (string) $this->get_prop( 'timezone', $context );
	}

	/**
	 * @param string $timezone IANA timezone.
	 * @return void
	 */
	public function set_timezone( $timezone ) {
		$this->set_prop( 'timezone', (string) $timezone );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_next_materialize_ts( $context = 'view' ) {
		return (int) $this->get_prop( 'next_materialize_ts', $context );
	}

	/**
	 * @param int $next_materialize_ts Next materialize timestamp.
	 * @return void
	 */
	public function set_next_materialize_ts( $next_materialize_ts ) {
		$this->set_prop( 'next_materialize_ts', (int) $next_materialize_ts );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_last_materialized_ts( $context = 'view' ) {
		return (int) $this->get_prop( 'last_materialized_ts', $context );
	}

	/**
	 * @param int $last_materialized_ts Last materialized occurrence start.
	 * @return void
	 */
	public function set_last_materialized_ts( $last_materialized_ts ) {
		$this->set_prop( 'last_materialized_ts', (int) $last_materialized_ts );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_materialized_count( $context = 'view' ) {
		return (int) $this->get_prop( 'materialized_count', $context );
	}

	/**
	 * @param int $materialized_count Materialized occurrence count.
	 * @return void
	 */
	public function set_materialized_count( $materialized_count ) {
		$this->set_prop( 'materialized_count', (int) $materialized_count );
	}

	/**
	 * @param string $context view|edit.
	 * @return int
	 */
	public function get_rrule_count_cap( $context = 'view' ) {
		return (int) $this->get_prop( 'rrule_count_cap', $context );
	}

	/**
	 * @param int $rrule_count_cap COUNT cap (0 = unbounded).
	 * @return void
	 */
	public function set_rrule_count_cap( $rrule_count_cap ) {
		$this->set_prop( 'rrule_count_cap', (int) $rrule_count_cap );
	}

	/**
	 * @param string $context view|edit.
	 * @return int Unix timestamp when `created` notification was sent (0 = never).
	 */
	public function get_notified_created_at( $context = 'view' ) {
		return (int) $this->get_prop( 'notified_created_at', $context );
	}

	/**
	 * @param int $notified_created_at Unix timestamp.
	 * @return void
	 */
	public function set_notified_created_at( $notified_created_at ) {
		$this->set_prop( 'notified_created_at', (int) $notified_created_at );
	}

	/**
	 * @param string $context view|edit.
	 * @return string
	 */
	public function get_created_at( $context = 'view' ) {
		return (string) $this->get_prop( 'created_at', $context );
	}

	/**
	 * @param string $created_at Created at (mysql UTC).
	 * @return void
	 */
	public function set_created_at( $created_at ) {
		$this->set_prop( 'created_at', (string) $created_at );
	}

	/**
	 * @param string $context view|edit.
	 * @return string
	 */
	public function get_updated_at( $context = 'view' ) {
		return (string) $this->get_prop( 'updated_at', $context );
	}

	/**
	 * @param string $updated_at Updated at (mysql UTC).
	 * @return void
	 */
	public function set_updated_at( $updated_at ) {
		$this->set_prop( 'updated_at', (string) $updated_at );
	}

	// -------------------------------------------------------------------------
	// Pay-first balance meta helpers (wc_appointment_seriesmeta; not series table columns).
	// -------------------------------------------------------------------------

	/**
	 * @return float Full series total at purchase (0 when not set).
	 */
	public function get_series_total() {
		return (float) $this->get_meta( self::META_SERIES_TOTAL );
	}

	/**
	 * @param float $amount Full series purchase total.
	 * @return void
	 */
	public function set_series_total( $amount ) {
		$this->update_meta_data( self::META_SERIES_TOTAL, (float) $amount );
	}

	/**
	 * @return float Amount collected on the parent order.
	 */
	public function get_paid_upfront() {
		return (float) $this->get_meta( self::META_PAID_UPFRONT );
	}

	/**
	 * @param float $amount Amount paid at checkout.
	 * @return void
	 */
	public function set_paid_upfront( $amount ) {
		$this->update_meta_data( self::META_PAID_UPFRONT, (float) $amount );
	}

	/**
	 * @return float Outstanding balance (series_total − paid_upfront); 0 when settled.
	 */
	public function get_balance_due() {
		return (float) $this->get_meta( self::META_BALANCE_DUE );
	}

	/**
	 * @param float $amount Balance due.
	 * @return void
	 */
	public function set_balance_due( $amount ) {
		$this->update_meta_data( self::META_BALANCE_DUE, (float) $amount );
	}

	/**
	 * @return string 'open' | 'paid'.
	 */
	public function get_balance_status() {
		$status = (string) $this->get_meta( self::META_BALANCE_STATUS );
		return in_array( $status, array( 'open', 'paid' ), true ) ? $status : 'open';
	}

	/**
	 * @param string $status 'open'|'paid'.
	 * @return void
	 */
	public function set_balance_status( $status ) {
		$this->update_meta_data( self::META_BALANCE_STATUS, in_array( $status, array( 'open', 'paid' ), true ) ? $status : 'open' );
	}

	/**
	 * @return int Current/open balance WC order ID (0 if none).
	 */
	public function get_balance_order_id() {
		return (int) $this->get_meta( self::META_BALANCE_ORDER_ID );
	}

	/**
	 * @param int $order_id Balance WC order id (0 to clear).
	 * @return void
	 */
	public function set_balance_order_id( $order_id ) {
		$this->balance_order_cache = null;
		$this->update_meta_data( self::META_BALANCE_ORDER_ID, (int) $order_id );
	}

	/**
	 * @return int Paid session count (starts at 1 for pay_first).
	 */
	public function get_paid_session_count() {
		return (int) $this->get_meta( self::META_PAID_SESSION_COUNT );
	}

	/**
	 * @param int $count Paid session count.
	 * @return void
	 */
	public function set_paid_session_count( $count ) {
		$this->update_meta_data( self::META_PAID_SESSION_COUNT, (int) $count );
	}

	/**
	 * @return int Quantity (minimum 1).
	 */
	public function get_qty() {
		return max( 1, (int) $this->get_meta( self::META_QTY ) );
	}

	/**
	 * @param int $qty Quantity (minimum 1).
	 * @return void
	 */
	public function set_qty( $qty ) {
		$this->update_meta_data( self::META_QTY, max( 1, (int) $qty ) );
	}

	/**
	 * Whether this series has an unsettled balance.
	 *
	 * @return bool
	 */
	public function has_open_balance() {
		return self::PAYMENT_PAY_FIRST === $this->get_payment_model()
			&& $this->get_balance_due() > 0
			&& 'paid' !== $this->get_balance_status();
	}

	/**
	 * Plain-text formatted balance for REST/JS (no HTML entities).
	 *
	 * @param float  $amount   Amount.
	 * @param string $currency Currency code.
	 * @return string
	 */
	public static function format_balance_due_plain( $amount, $currency ) {
		$amount = (float) $amount;
		if ( $amount <= 0 ) {
			return '';
		}
		$html = wc_price( $amount, array( 'currency' => $currency ) );

		return html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	/**
	 * Remaining balance from series and checkout totals.
	 *
	 * @param float $series_total   Full package price.
	 * @param float $checkout_total Amount charged on the parent order.
	 * @return float
	 */
	public static function calculate_balance_due( $series_total, $checkout_total ) {
		$series_total = (float) $series_total;
		if ( $series_total <= 0 ) {
			return 0.0;
		}
		return max( 0.0, $series_total - (float) $checkout_total );
	}

	/**
	 * Remaining balance in storefront display units (package display − paid display).
	 *
	 * Pass a saved series, or product + net totals (preview/cart).
	 *
	 * @param WC_Product|WC_Appointment_Series|null $product_or_series Appointable product, series, or null.
	 * @param float                                   $series_total      Net package total (ignored when 1st arg is series).
	 * @param float                                   $checkout_total    Net checkout amount (ignored when 1st arg is series).
	 * @return float
	 */
	public static function calculate_balance_due_display( $product_or_series, $series_total = 0.0, $checkout_total = 0.0 ) {
		$product = null;
		if ( $product_or_series instanceof WC_Appointment_Series ) {
			$series = $product_or_series;
			if ( (float) $series->get_balance_due() <= 0 ) {
				return 0.0;
			}
			$series_total = (float) $series->get_series_total();
			if ( $series_total <= 0 ) {
				return (float) $series->get_balance_due();
			}
			$checkout_total = (float) $series->get_paid_upfront();
			$product        = wc_get_product( $series->get_product_id() );
		} else {
			$product        = $product_or_series;
			$series_total   = (float) $series_total;
			$checkout_total = (float) $checkout_total;
		}

		if ( $series_total <= 0 ) {
			return 0.0;
		}

		if ( $product && is_wc_appointment_product( $product ) ) {
			$series_display   = (float) wc_get_price_to_display( $product, array( 'price' => $series_total, 'qty' => 1 ) );
			$checkout_display = (float) wc_get_price_to_display( $product, array( 'price' => $checkout_total, 'qty' => 1 ) );
			return max( 0.0, $series_display - $checkout_display );
		}

		return self::calculate_balance_due( $series_total, $checkout_total );
	}

	/**
	 * Store pay-first balance meta after the parent order is known.
	 *
	 * @param float $series_total   Full package price.
	 * @param float $checkout_total Amount collected on the parent order.
	 * @return void
	 */
	public function apply_pay_first_balance( $series_total, $checkout_total ) {
		if ( self::PAYMENT_PAY_FIRST !== $this->get_payment_model() || $series_total <= 0 ) {
			return;
		}

		$balance = self::calculate_balance_due( $series_total, $checkout_total );
		$this->set_series_total( $series_total );
		$this->set_paid_upfront( $checkout_total );
		$this->set_balance_due( $balance );
		$this->set_balance_status( $balance > 0 ? 'open' : 'paid' );
		$this->set_paid_session_count( 1 );
	}

	/**
	 * Parent checkout order id (series row, else first occurrence order).
	 *
	 * @return int
	 */
	public function resolve_parent_order_id() {
		$order_id = (int) $this->get_order_id();
		if ( $order_id <= 0 && $this->get_id() > 0 ) {
			wc_get_logger()->warning(
				sprintf( 'Series #%d has order_id=0; payment flows may be incomplete. Run the series repair CLI command.', $this->get_id() ),
				[ 'source' => 'wc-appointments' ]
			);
		}
		return $order_id;
	}

	/**
	 * Locate `_wca_recurring` on the parent order for this series.
	 *
	 * @param WC_Order|null $order Optional order (resolved when omitted).
	 * @return array<string, mixed>|null
	 */
	public function find_pay_first_recurring_from_order( $order = null ) {
		if ( ! $order instanceof WC_Order ) {
			$order_id = $this->resolve_parent_order_id();
			if ( $order_id <= 0 ) {
				return null;
			}
			$order = wc_get_order( $order_id );
		}
		if ( ! $order ) {
			return null;
		}

		$line = self::find_series_order_line( $order, $this->get_id() );
		if ( $line ) {
			$recurring = $line->get_meta( '_wca_recurring', true );
			if ( is_array( $recurring ) ) {
				return $recurring;
			}
		}

		if ( (int) $order->get_meta( '_wca_series_id', true ) !== $this->get_id() ) {
			return null;
		}

		foreach ( $order->get_items() as $item ) {
			$recurring = $item->get_meta( '_wca_recurring', true );
			if ( ! is_array( $recurring ) ) {
				continue;
			}
			$summary = isset( $recurring['preview_summary'] ) && is_array( $recurring['preview_summary'] ) ? $recurring['preview_summary'] : array();
			$total   = (float) ( $recurring['series_total'] ?? $summary['total_price'] ?? 0 );
			if ( $total > 0 ) {
				return $recurring;
			}
		}

		return null;
	}

	/**
	 * Backfill pay-first totals from order line meta or the parent order.
	 *
	 * @param array<string, mixed>|null $recurring Optional `_wca_recurring` from the order line.
	 * @param WC_Order|null             $order     Optional balance order (loads parent recurring).
	 * @return void
	 */
	public function ensure_pay_first_totals_from_order( $recurring = null, $order = null ) {
		if ( self::PAYMENT_PAY_FIRST !== $this->get_payment_model() ) {
			return;
		}

		if ( $this->get_series_total() > 0 && $this->get_paid_upfront() > 0 && ( $this->get_balance_due() > 0 || 'paid' === $this->get_balance_status() ) ) {
			return;
		}

		$mutated = false;
		if ( $this->get_series_total() > 0 && $this->get_balance_due() > 0 && $this->get_paid_upfront() <= 0 ) {
			$this->set_paid_upfront( max( 0.0, $this->get_series_total() - $this->get_balance_due() ) );
			$mutated = true;
		} elseif ( ! is_array( $recurring ) || empty( $recurring ) ) {
			if ( $order instanceof WC_Order && WC_Appointment_Series_Payment::is_balance_order( $order ) ) {
				$parent_id = (int) $order->get_meta( '_wca_parent_order_id', true );
				$recurring = $parent_id > 0 ? $this->find_pay_first_recurring_from_order( wc_get_order( $parent_id ) ) : null;
			}
			if ( ! is_array( $recurring ) || empty( $recurring ) ) {
				$recurring = $this->find_pay_first_recurring_from_order();
			}
			if ( is_array( $recurring ) && ! empty( $recurring ) ) {
				$summary      = isset( $recurring['preview_summary'] ) && is_array( $recurring['preview_summary'] ) ? $recurring['preview_summary'] : array();
				$series_total = (float) ( $recurring['series_total'] ?? $summary['total_price'] ?? 0 );
				if ( $series_total > 0 ) {
					$this->apply_pay_first_balance( $series_total, (float) ( $recurring['checkout_total'] ?? $summary['due_today'] ?? 0 ) );
					$mutated = true;
				}
			}
		}
		if ( $mutated && $this->get_id() > 0 ) {
			$this->save_meta_data();
		}
	}

	/**
	 * Human-readable recurrence pattern for customer-facing copy.
	 *
	 * @param array<string, mixed>|null $humanize_opts Optional precomputed {@see WC_Appointment_Series_RRule::humanize_wp_date_opts()} (pass `locale` once per batch).
	 * @param string|null               $display_tz    Optional IANA zone for My Account viewer wall times.
	 * @return string
	 */
	public function get_pattern_summary( ?array $humanize_opts = null, ?string $display_tz = null ) {
		$count_cap = $this->get_rrule_count_cap();
		if ( $count_cap <= 0 ) {
			$count_cap = WC_Appointment_Series_RRule::parse_count_cap( $this->get_rrule() );
		}
		$opts = null !== $humanize_opts ? $humanize_opts : WC_Appointment_Series_RRule::humanize_wp_date_opts();
		if ( $count_cap > 0 ) {
			$opts['count_cap'] = $count_cap;
		}
		if ( null === $display_tz && ! is_admin() && class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
			$display_tz = WC_Appointments_Timezone_Helper::get_booking_form_timezone();
		}
		$series_tz  = (string) ( $this->get_timezone() ?: wc_timezone_string() );
		$dtstart_ts = (int) $this->get_dtstart_ts();
		$human_tz   = ( is_string( $display_tz ) && '' !== $display_tz ) ? $display_tz : $series_tz;
		if ( $human_tz !== $series_tz && $dtstart_ts > 0 ) {
			try {
				$dtstart_ts = WC_Appointment_Series_RRule::convert_fake_utc_axis(
					$dtstart_ts,
					new DateTimeZone( $series_tz ),
					new DateTimeZone( $human_tz )
				);
			} catch ( Exception $e ) {
				$human_tz = $series_tz;
			}
		}

		return WC_Appointment_Series_RRule::humanize( $this->get_rrule(), $dtstart_ts, $human_tz, $opts );
	}

	/**
	 * Linked checkout WC order when one exists.
	 *
	 * @return WC_Order|null
	 */
	public function get_checkout_order() {
		if ( null !== $this->checkout_order_cache ) {
			return false === $this->checkout_order_cache ? null : $this->checkout_order_cache;
		}

		$order_id = (int) $this->get_order_id();
		$order    = $order_id > 0 ? wc_get_order( $order_id ) : false;
		$order    = $order instanceof WC_Order ? $order : false;

		$this->checkout_order_cache = $order;

		return $order ? $order : null;
	}

	/**
	 * Currency for customer-facing amounts (parent order when linked).
	 *
	 * @return string
	 */
	public function get_checkout_currency() {
		$order = $this->get_checkout_order();
		if ( $order ) {
			return $order->get_currency();
		}
		return get_woocommerce_currency();
	}

	/**
	 * Linked balance WC order when one exists (any status).
	 *
	 * @return WC_Order|null
	 */
	public function get_balance_order() {
		if ( null !== $this->balance_order_cache ) {
			return false === $this->balance_order_cache ? null : $this->balance_order_cache;
		}

		$order_id = (int) $this->get_balance_order_id();
		$order    = $order_id > 0 ? wc_get_order( $order_id ) : false;
		$order    = $order instanceof WC_Order ? $order : false;

		$this->balance_order_cache = $order;

		return $order ? $order : null;
	}

	/**
	 * Pending balance WC order when one exists and still needs payment.
	 *
	 * @return WC_Order|null
	 */
	public function get_payable_balance_order() {
		$order = $this->get_balance_order();
		if ( ! $order || ! WC_Appointment_Series_Payment::balance_order_is_payable( $order ) ) {
			return null;
		}
		return $order;
	}

	/**
	 * REST / admin payment snapshot (avoids duplicating field assembly).
	 *
	 * @return array<string, mixed>
	 */
	public function get_payment_snapshot() {
		if ( self::PAYMENT_PAY_FIRST !== $this->get_payment_model() ) {
			return array(
				'payment_model'    => $this->get_payment_model(),
				'has_open_balance' => false,
			);
		}

		$open_balance      = $this->has_open_balance();
		$needs             = $open_balance && $this->needs_balance_payment();
		$balance_order_id  = (int) $this->get_balance_order_id();
		$balance_order     = $balance_order_id > 0 ? $this->get_balance_order() : null;
		$checkout_order_id = (int) $this->get_order_id();
		$currency          = $this->get_checkout_currency();
		$balance_due       = self::calculate_balance_due_display( $this );

		$snapshot = array(
			'payment_model'            => $this->get_payment_model(),
			'series_total'             => $this->get_series_total(),
			'paid_upfront'             => $this->get_paid_upfront(),
			'balance_due'              => $balance_due,
			'balance_due_formatted'    => self::format_balance_due_plain( $balance_due, $currency ),
			'balance_status'           => $this->get_balance_status(),
			'balance_order_id'         => $balance_order_id,
			'has_open_balance'         => $open_balance,
			'balance_pay_url'          => WC_Appointment_Series_Payment::get_balance_pay_url( $this ),
			'balance_order_edit_url'   => $balance_order_id > 0
				? ( $balance_order ? $balance_order->get_edit_order_url() : self::get_order_edit_url( $balance_order_id ) )
				: '',
			'checkout_order_edit_url'  => $checkout_order_id > 0 ? self::get_order_edit_url( $checkout_order_id ) : '',
			'currency'                 => $currency,
		);

		if ( WC_Appointment_Series_Payment::staff_can_manage_balance() ) {
			$snapshot['admin'] = array(
				'needs_balance_payment'    => $needs,
				'can_create_balance_order' => $needs && ! $balance_order_id,
				'can_send_payment_request' => $needs,
				'can_mark_paid_offline'    => $open_balance,
			);
		}

		return $snapshot;
	}

	/**
	 * Materialized appointment IDs for this series, ordered by start time.
	 *
	 * @param int $limit Max IDs (1–100).
	 * @return int[]
	 */
	public function get_appointment_ids( $limit = 100 ) {
		if ( $this->get_id() <= 0 ) {
			return array();
		}

		$query = new WP_Query(
			array(
				'post_type'      => 'wc_appointment',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => min( 100, max( 1, (int) $limit ) ),
				'no_found_rows'  => true,
				'orderby'        => 'meta_value',
				'meta_key'       => '_appointment_start',
				'order'          => 'ASC',
				'meta_query'     => array(
					array(
						'key'   => '_wca_series_id',
						'value' => $this->get_id(),
					),
				),
			)
		);

		return array_map( 'intval', (array) $query->posts );
	}

	/**
	 * Loaded occurrences for display or REST (ordered by start).
	 *
	 * @param int $limit    Max rows (1–100).
	 * @param int $after_ts Skip starts at or before this Fake UTC epoch.
	 * @return WC_Appointment[]
	 */
	public function get_occurrence_appointments( $limit = 50, $after_ts = 0 ) {
		$limit = min( 100, max( 1, (int) $limit ) );
		if ( $this->get_id() <= 0 ) {
			return array();
		}

		$manager      = new WC_Appointment_Series_Manager();
		$rows         = $manager->get_occurrence_rows( $this->get_id() );
		$appointments = array();

		foreach ( $rows as $row ) {
			if ( $after_ts > 0 && (int) $row['start_ts'] <= $after_ts ) {
				continue;
			}
			$appt = get_wc_appointment( (int) $row['appointment_id'] );
			if ( ! $appt ) {
				continue;
			}
			$appointments[] = $appt;
			if ( count( $appointments ) >= $limit ) {
				break;
			}
		}

		return $appointments;
	}

	/**
	 * Parse Fake UTC YmdHis wall token to epoch (do not use strtotime).
	 *
	 * @param string $raw Stored meta value.
	 * @return int
	 */
	public static function parse_wall_meta_ts( $raw ) {
		if ( '' === (string) $raw ) {
			return 0;
		}

		$parsed = DateTimeImmutable::createFromFormat( 'YmdHis', (string) $raw, new DateTimeZone( 'UTC' ) );

		return $parsed ? $parsed->getTimestamp() : 0;
	}

	/**
	 * Recurring package fields for admin panel / calendar (single series load).
	 *
	 * @param int $occurrence_limit Max sessions in the expandable list (1–100).
	 * @return array<string, mixed>
	 */
	public function get_panel_preload( $occurrence_limit = 50 ) {
		$occurrence_limit = min( 100, max( 1, (int) $occurrence_limit ) );
		$occurrences      = array();

		foreach ( ( new WC_Appointment_Series_Manager() )->get_occurrence_rows( $this->get_id() ) as $row ) {
			if ( count( $occurrences ) >= $occurrence_limit ) {
				break;
			}
			$occurrences[] = self::occurrence_row_to_rest_item( $row );
		}

		$count_cap = $this->get_rrule_count_cap();
		if ( $count_cap <= 0 ) {
			$count_cap = WC_Appointment_Series_RRule::parse_count_cap( $this->get_rrule() );
		}

		return array(
			'series_checkout_order_id' => (int) $this->get_order_id(),
			'series_payment'           => $this->get_payment_snapshot(),
			'series_pattern_summary'   => $this->get_pattern_summary(),
			'series_count_cap'         => $count_cap,
			'series_occurrences'       => $occurrences,
		);
	}

	/**
	 * @param int $series_id Series post ID.
	 * @return array<string, mixed>
	 */
	public static function get_panel_preload_for_id( int $series_id ): array {
		if ( $series_id <= 0 || ! class_exists( 'WC_Appointment_Series_Events' ) || ! WC_Appointment_Series_Events::is_enabled() ) {
			return array();
		}

		try {
			return ( new self( $series_id ) )->get_panel_preload();
		} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			return array();
		}
	}

	/**
	 * REST occurrence payload for one appointment.
	 *
	 * @param WC_Appointment $appt Appointment.
	 * @return array<string, mixed>
	 */
	public static function occurrence_to_rest_item( WC_Appointment $appt ) {
		return array(
			'appointment_id' => $appt->get_id(),
			'recurrence_id'  => (string) $appt->get_meta( '_wca_recurrence_id' ),
			'start_ts'       => (int) $appt->get_start(),
			'end_ts'         => (int) $appt->get_end(),
			'status'         => $appt->get_status(),
		);
	}

	/**
	 * REST occurrence payload from a manager SQL row.
	 *
	 * @param array{appointment_id: int, start_ts: int, end_ts?: int, status: string, recurrence_id: string} $row Occurrence row.
	 * @return array<string, mixed>
	 */
	public static function occurrence_row_to_rest_item( array $row ) {
		return array(
			'appointment_id' => (int) ( $row['appointment_id'] ?? 0 ),
			'recurrence_id'  => (string) ( $row['recurrence_id'] ?? '' ),
			'start_ts'       => (int) ( $row['start_ts'] ?? 0 ),
			'end_ts'         => (int) ( $row['end_ts'] ?? 0 ),
			'status'         => (string) ( $row['status'] ?? '' ),
		);
	}

	/**
	 * @param string $status Status slug.
	 * @return string
	 */
	public static function get_status_label( $status ) {
		static $labels = null;
		if ( null === $labels ) {
			$labels = array(
				self::STATUS_ACTIVE    => __( 'Active', 'woocommerce-appointments' ),
				self::STATUS_COMPLETED => __( 'Completed', 'woocommerce-appointments' ),
				self::STATUS_CANCELLED => __( 'Cancelled', 'woocommerce-appointments' ),
				self::STATUS_PENDING   => __( 'Pending', 'woocommerce-appointments' ),
			);
		}
		return $labels[ $status ] ?? (string) $status;
	}

	/**
	 * Appointable product for this series.
	 *
	 * @return WC_Product_Appointment|null
	 */
	public function get_appointable_product() {
		$product = wc_get_product( $this->get_product_id() );
		return ( $product && is_wc_appointment_product( $product ) ) ? $product : null;
	}

	/**
	 * Whether the customer may cancel future occurrences in bulk.
	 *
	 * @return bool
	 */
	public function customer_can_cancel_series() {
		$product = $this->get_appointable_product();
		return self::STATUS_CANCELLED !== $this->get_status() && $product && $product->can_be_cancelled();
	}

	/**
	 * Whether the customer may cancel (skip) this occurrence.
	 *
	 * @param WC_Appointment $appt Appointment.
	 * @return bool
	 */
	public function customer_can_cancel_occurrence( WC_Appointment $appt ) {
		return $this->customer_occurrence_changeable( $appt ) && ! $appt->passed_cancel_day();
	}

	/**
	 * Whether the customer may reschedule this occurrence.
	 *
	 * @param WC_Appointment $appt Appointment.
	 * @return bool
	 */
	public function customer_can_reschedule_occurrence( WC_Appointment $appt ) {
		return $this->customer_occurrence_changeable( $appt ) && ! $appt->passed_reschedule_day();
	}

	/**
	 * @param string $recurrence_id RECURRENCE-ID.
	 * @return WC_Appointment|null
	 */
	public function get_occurrence_by_recurrence_id( $recurrence_id ) {
		$recurrence_id = WC_Appointment_Series_RRule::sanitize_recurrence_id( (string) $recurrence_id );
		if ( '' === $recurrence_id ) {
			return null;
		}
		foreach ( $this->get_occurrence_appointments( 50 ) as $appt ) {
			if ( (string) $appt->get_meta( '_wca_recurrence_id' ) === $recurrence_id ) {
				return $appt;
			}
		}
		return null;
	}

	/**
	 * Series active and occurrence not terminal (completed packages stay {@see STATUS_COMPLETED}).
	 *
	 * @param WC_Appointment $appt Appointment.
	 * @return bool
	 */
	private function customer_occurrence_changeable( WC_Appointment $appt ) {
		return self::STATUS_CANCELLED !== $this->get_status()
			&& ! in_array( $appt->get_status(), array( 'cancelled', 'completed' ), true );
	}

	/**
	 * @param int $order_id Order id.
	 * @return string
	 */
	public static function get_order_edit_url( $order_id ) {
		$order_id = (int) $order_id;
		if ( $order_id <= 0 ) {
			return admin_url( 'edit.php?post_type=shop_order' );
		}
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			return admin_url( 'admin.php?page=wc-orders&action=edit&id=' . $order_id );
		}
		return admin_url( 'post.php?post=' . $order_id . '&action=edit' );
	}

	/**
	 * Load series from a pay-first balance WC order.
	 *
	 * @param WC_Order|false|null $order Order.
	 * @return WC_Appointment_Series|null
	 */
	public static function from_balance_order( $order ) {
		if ( ! $order instanceof WC_Order || WC_Appointment_Series_Payment::ORDER_TYPE_BALANCE !== (string) $order->get_meta( WC_Appointment_Series_Payment::ORDER_META_TYPE, true ) ) {
			return null;
		}
		$series_id = (int) $order->get_meta( '_wca_series_id', true );
		if ( $series_id <= 0 ) {
			return null;
		}
		try {
			return new self( $series_id );
		} catch ( Exception $e ) {
			unset( $e );
			return null;
		}
	}

	/**
	 * Staff balance actions for the order edit screen.
	 *
	 * @param array<string, mixed>|null $payment          Optional snapshot.
	 * @param int                         $context_order_id Order being edited.
	 * @return array<int, array<string, mixed>>
	 */
	public function get_admin_balance_actions( $payment = null, $context_order_id = 0 ) {
		if ( ! is_array( $payment ) ) {
			$payment = $this->get_payment_snapshot();
		}
		$admin = isset( $payment['admin'] ) && is_array( $payment['admin'] ) ? $payment['admin'] : array();
		if ( empty( $admin ) ) {
			return array();
		}

		$actions          = array();
		$context_order_id = (int) $context_order_id;
		$balance_order_id = (int) ( $payment['balance_order_id'] ?? 0 );
		$on_balance_order = $context_order_id > 0 && $balance_order_id > 0 && $context_order_id === $balance_order_id;

		if ( $on_balance_order && ! empty( $payment['checkout_order_edit_url'] ) ) {
			$actions[] = array( 'url' => $payment['checkout_order_edit_url'], 'label' => __( 'View original order', 'woocommerce-appointments' ) );
		}
		if ( ! empty( $payment['balance_order_edit_url'] ) && ! $on_balance_order ) {
			$actions[] = array( 'url' => $payment['balance_order_edit_url'], 'label' => __( 'View balance order', 'woocommerce-appointments' ) );
		} elseif ( ! empty( $admin['can_create_balance_order'] ) ) {
			$actions[] = array(
				'label'        => __( 'Create balance order', 'woocommerce-appointments' ),
				'button_class' => 'button',
				'url'          => WC_Appointment_Series_Payment::get_admin_balance_action_url( $this->get_id(), $context_order_id, 'create_order' ),
			);
		}
		if ( ! empty( $admin['can_send_payment_request'] ) ) {
			$actions[] = array(
				'label'        => __( 'Send payment request', 'woocommerce-appointments' ),
				'button_class' => 'button',
				'url'          => WC_Appointment_Series_Payment::get_admin_balance_action_url( $this->get_id(), $context_order_id, 'invoice' ),
			);
		}
		if ( ! empty( $admin['can_mark_paid_offline'] ) ) {
			$actions[] = array(
				'label'        => __( 'Mark paid offline', 'woocommerce-appointments' ),
				'button_class' => 'button button-primary',
				'confirm'      => __( 'Mark the remaining balance as paid offline?', 'woocommerce-appointments' ),
				'url'          => WC_Appointment_Series_Payment::get_admin_balance_action_url( $this->get_id(), $context_order_id, 'paid_offline' ),
			);
		}
		return $actions;
	}

	/**
	 * @param int|null $due_occurrence_count Optional preloaded due count (calendar panel batch).
	 * @return bool
	 */
	public function needs_balance_payment( $due_occurrence_count = null ) {
		if ( ! $this->has_open_balance() ) {
			return false;
		}
		if ( in_array( $this->get_status(), array( self::STATUS_CANCELLED, self::STATUS_COMPLETED ), true ) ) {
			if ( null !== $due_occurrence_count ) {
				return (int) $due_occurrence_count > 0;
			}
			return $this->count_due_occurrences() > 0;
		}
		return true;
	}

	/**
	 * Create pending balance order at pay-first series confirmation when filters allow.
	 *
	 * Opt out: `wc_appointments_recurring_auto_create_balance_order`.
	 * Invoice timing: `wc_appointments_recurring_balance_invoice_timing`.
	 *
	 * @since 5.4.0
	 *
	 * @return WC_Order|null Created or existing payable order; null when skipped or failed.
	 */
	public function auto_create_balance_order_if_due() {
		if ( self::PAYMENT_PAY_FIRST !== $this->get_payment_model() || ! $this->has_open_balance() ) {
			return null;
		}
		if ( ! (bool) apply_filters( 'wc_appointments_recurring_auto_create_balance_order', true, $this ) ) {
			return null;
		}
		$send   = 'on_balance_order_created' === apply_filters( 'wc_appointments_recurring_balance_invoice_timing', 'manual', $this );
		$result = $this->create_balance_order( $send );
		return $result instanceof WC_Order ? $result : null;
	}

	/**
	 * Create or return the open balance order for this series.
	 *
	 * @param bool $send_invoice Whether to send the balance payment request email.
	 * @return WC_Order|WP_Error
	 */
	public function create_balance_order( $send_invoice = false ) {
		if ( ! $this->needs_balance_payment() ) {
			return new WP_Error( 'no_balance_needed', __( 'No balance is due for this series.', 'woocommerce-appointments' ) );
		}

		$existing = $this->get_payable_balance_order();
		if ( $existing ) {
			if ( $send_invoice ) {
				WC_Appointment_Series_Email::send_balance_payment_request( $existing );
			}
			return $existing;
		}

		if ( $this->get_balance_order_id() ) {
			$this->set_balance_order_id( 0 );
			if ( $this->get_id() > 0 ) {
				$this->save_meta_data();
			}
		}

		$parent_order_id = $this->resolve_parent_order_id();
		$parent_order    = $parent_order_id > 0 ? wc_get_order( $parent_order_id ) : null;

		$order = new WC_Order();
		$order->set_created_via( 'wca_series_balance' );
		if ( $this->get_customer_id() > 0 ) {
			$order->set_customer_id( $this->get_customer_id() );
		}
		$order->set_currency( $parent_order ? $parent_order->get_currency() : get_woocommerce_currency() );
		$order->set_prices_include_tax( $parent_order ? $parent_order->get_prices_include_tax() : ( 'yes' === get_option( 'woocommerce_prices_include_tax' ) ) );
		if ( $parent_order ) {
			$order->set_address( $parent_order->get_address( 'billing' ), 'billing' );
			$order->set_address( $parent_order->get_address( 'shipping' ), 'shipping' );
			if ( ! $order->get_customer_id() && $parent_order->get_customer_id() ) {
				$order->set_customer_id( $parent_order->get_customer_id() );
			}
		}

		$this->sync_balance_line_on_order( $order );
		$order->update_meta_data( '_wca_series_id', $this->get_id() );
		$order->update_meta_data( WC_Appointment_Series_Payment::ORDER_META_TYPE, WC_Appointment_Series_Payment::ORDER_TYPE_BALANCE );
		$order->update_meta_data( '_wca_parent_order_id', $parent_order_id );
		if ( is_admin() ) {
			$order->update_meta_data( '_wc_order_attribution_source_type', 'admin' );
		} elseif ( $parent_order instanceof WC_Order && ( $source_type = (string) $parent_order->get_meta( '_wc_order_attribution_source_type', true ) ) ) {
			$order->update_meta_data( '_wc_order_attribution_source_type', $source_type );
			if ( ( $utm_source = (string) $parent_order->get_meta( '_wc_order_attribution_utm_source', true ) ) ) {
				$order->update_meta_data( '_wc_order_attribution_utm_source', $utm_source );
			}
		} else {
			$order->update_meta_data( '_wc_order_attribution_source_type', 'utm' );
			$order->update_meta_data( '_wc_order_attribution_utm_source', __( 'Series balance', 'woocommerce-appointments' ) );
		}
		$order->add_order_note(
			sprintf(
				/* translators: %d: series id */
				__( 'Balance order created for recurring series #%d.', 'woocommerce-appointments' ),
				$this->get_id()
			)
		);
		$order->save();
		do_action( 'woocommerce_deposits_create_order', $order );

		$this->set_balance_order_id( $order->get_id() );
		if ( $this->get_id() > 0 ) {
			$this->save_meta_data();
		}

		do_action( 'wc_appointment_series_balance_order_created', $order->get_id(), $this->get_id() );

		if ( $send_invoice ) {
			WC_Appointment_Series_Email::send_balance_payment_request( $order );
		}

		return $order;
	}

	/**
	 * @param int $order_id Optional paid balance order id.
	 * @return void
	 */
	public function settle_balance( $order_id = 0 ) {
		$this->set_balance_due( 0 );
		$this->set_balance_status( 'paid' );
		if ( $order_id > 0 ) {
			$this->update_meta_data( '_wca_balance_paid_order_id', $order_id );
		}
		$this->save();
	}

	/**
	 * Whether an order line item is the recurring parent for a series.
	 *
	 * @param WC_Order_Item $item Order line item.
	 * @return bool
	 */
	public static function order_line_is_recurring_parent( $item ) {
		if ( ! $item instanceof WC_Order_Item_Product ) {
			return false;
		}
		$recurring = $item->get_meta( '_wca_recurring', true );
		return is_array( $recurring ) && ! empty( $recurring['rrule'] );
	}

	/**
	 * Convert a catalog (tax-inclusive when store prices include tax) amount to order line net.
	 *
	 * @param WC_Product|false|null $product        Product (tax class / taxable).
	 * @param WC_Order              $order          Order for billing country rates.
	 * @param float                 $catalog_amount Catalog amount.
	 * @return float
	 */
	public static function catalog_amount_to_order_line_net( $product, WC_Order $order, $catalog_amount ) {
		$catalog_amount = (float) $catalog_amount;
		if ( $catalog_amount <= 0 || ! wc_tax_enabled() || ! wc_prices_include_tax() || ! $product || ! $product->is_taxable() ) {
			return max( 0.0, $catalog_amount );
		}

		$rates = $order->get_billing_country()
			? WC_Tax::find_rates(
				array(
					'country'   => $order->get_billing_country(),
					'state'     => $order->get_billing_state(),
					'postcode'  => $order->get_billing_postcode(),
					'city'      => $order->get_billing_city(),
					'tax_class' => $product->get_tax_class(),
				)
			)
			: array();

		if ( empty( $rates ) ) {
			$rates = WC_Tax::get_base_tax_rates( $product->get_tax_class() );
		}

		return max( 0.0, $catalog_amount - array_sum( WC_Tax::calc_tax( $catalog_amount, $rates, true ) ) );
	}

	/**
	 * @param WC_Order_Item_Product $item           Order line.
	 * @param WC_Order              $order          Order.
	 * @param float                 $catalog_amount Catalog amount.
	 * @return void
	 */
	public static function apply_catalog_line_net( WC_Order_Item_Product $item, WC_Order $order, $catalog_amount ) {
		$line_net = self::catalog_amount_to_order_line_net( $item->get_product(), $order, $catalog_amount );
		$item->set_subtotal( $line_net );
		$item->set_total( $line_net );
		$item->set_subtotal_tax( 0 );
		$item->set_total_tax( 0 );
		$item->set_taxes( array( 'subtotal' => array(), 'total' => array() ) );
	}

	/**
	 * Balance order appointable line (replaces legacy fee-only rows).
	 *
	 * @param WC_Order $order Balance order.
	 * @return void
	 */
	public function sync_balance_line_on_order( WC_Order $order ) {
		$catalog_balance = (float) $this->get_balance_due();
		if ( $catalog_balance <= 0 && $this->get_series_total() > 0 ) {
			$catalog_balance = (float) self::calculate_balance_due( $this->get_series_total(), $this->get_paid_upfront() );
		}
		if ( $catalog_balance <= 0 ) {
			return;
		}

		$parent_order_id = (int) $order->get_meta( '_wca_parent_order_id', true );
		if ( $parent_order_id <= 0 ) {
			$parent_order_id = (int) $this->resolve_parent_order_id();
		}
		$parent_order = $parent_order_id > 0 ? wc_get_order( $parent_order_id ) : null;
		if ( $parent_order && ! $order->get_billing_country() ) {
			$order->set_address( $parent_order->get_address( 'billing' ), 'billing' );
			$order->set_address( $parent_order->get_address( 'shipping' ), 'shipping' );
		}

		$parent_line = $parent_order ? self::find_series_order_line( $parent_order, $this->get_id() ) : null;
		$qty         = $parent_line ? max( 1, (int) $parent_line->get_quantity() ) : max( 1, (int) $this->get_qty() );
		$product     = wc_get_product( $this->get_product_id() );

		foreach ( $order->get_items( 'fee' ) as $fee_id => $fee_item ) {
			$order->remove_item( $fee_id );
			unset( $fee_item );
		}

		$line_item = null;
		foreach ( $order->get_items( 'line_item' ) as $item ) {
			if ( (int) $item->get_meta( '_wca_series_id', true ) === (int) $this->get_id() ) {
				$line_item = $item;
				break;
			}
		}

		if ( ! $line_item && $product ) {
			$line_item = new WC_Order_Item_Product();
			$line_item->set_product( $product );
			$line_item->set_variation_id( $product->is_type( 'variation' ) ? $product->get_id() : 0 );
			$line_item->update_meta_data( '_wca_series_id', $this->get_id() );
			$line_item->update_meta_data( '_wca_balance_line', 'yes' );
			$order->add_item( $line_item );
		}
		if ( ! $line_item ) {
			return;
		}

		if ( ! $line_item instanceof WC_Order_Item_Product ) {
			return;
		}

		$line_item->set_quantity( $qty );
		if ( $parent_line ) {
			$line_item->set_tax_class( $parent_line->get_tax_class() );
		}

		self::apply_catalog_line_net( $line_item, $order, $catalog_balance );
		$line_item->save();
		$order->calculate_totals( true );
	}

	/**
	 * @param string $action   mark_paid|link|unlink.
	 * @param int    $order_id For link/unlink.
	 * @return void
	 */
	public function update_due_occurrences( $action, $order_id = 0 ) {
		$this->foreach_due_occurrence( $action, (int) $order_id );
	}

	/** @return int */
	public function count_due_occurrences() {
		return (int) ( new WP_Query(
			array(
				'post_type'      => 'wc_appointment',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				'meta_query'     => self::due_occurrence_meta_query( $this->get_id() ),
			)
		) )->found_posts;
	}

	/**
	 * @param WC_Order $order     Order.
	 * @param int      $series_id Series id.
	 * @return WC_Order_Item_Product|null
	 */
	protected static function find_series_order_line( WC_Order $order, $series_id ) {
		$series_id = (int) $series_id;
		$fallback  = null;
		foreach ( $order->get_items( 'line_item' ) as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			if ( $series_id > 0 && (int) $item->get_meta( '_wca_series_id', true ) === $series_id ) {
				return $item;
			}
			if ( null === $fallback && self::order_line_is_recurring_parent( $item ) ) {
				$fallback = $item;
			}
		}
		return $fallback;
	}

	/**
	 * @param int $series_id Series id.
	 * @return array<int|string, mixed>
	 */
	protected static function due_occurrence_meta_query( $series_id ) {
		return array(
			'relation' => 'AND',
			array( 'key' => '_wca_series_id', 'value' => (int) $series_id ),
			array( 'key' => '_wca_series_payment_status', 'value' => 'due' ),
		);
	}

	/**
	 * @param string $action   mark_paid|link|unlink.
	 * @param int    $order_id For link/unlink.
	 * @return void
	 */
	protected function foreach_due_occurrence( $action, $order_id = 0 ) {
		$query = new WP_Query(
			array(
				'post_type'      => 'wc_appointment',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 200,
				'no_found_rows'  => true,
				'meta_query'     => self::due_occurrence_meta_query( $this->get_id() ),
			)
		);
		foreach ( array_map( 'intval', $query->posts ) as $appt_id ) {
			$appt = get_wc_appointment( $appt_id );
			if ( ! $appt ) {
				continue;
			}
			if ( 'mark_paid' === $action ) {
				$appt->update_meta_data( '_wca_series_payment_status', 'paid' );
				if ( $order_id > 0 ) {
					$appt->set_order_id( $order_id );
				}
			} elseif ( 'link' === $action ) {
				$appt->set_order_id( $order_id );
			} elseif ( 'unlink' === $action && (int) $appt->get_order_id() === (int) $order_id ) {
				$appt->set_order_id( 0 );
			} else {
				continue;
			}
			$appt->save();
		}
	}

}
