<?php
/**
 * Resource data object (`wca_resource` CPT).
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resource entity: scarce inventory at a location.
 *
 * @since 5.5.0
 */
class WC_Appointments_Resource extends WC_Appointments_CPT_Data {

	public const DATA_STORE = 'appointments-resource';
	public const POST_TYPE  = 'wca_resource';

	protected $object_type = 'appointments_resource';
	protected $cache_group = 'appointments-resource';

	/** @var array<string, mixed> */
	protected $data = [
		'name'          => '',
		'status'        => 'publish',
		'location_id'   => 0,
		'notes'         => '',
		'date_created'  => null, // Interface; CPT dates live on the post.
		'date_modified' => null,
	];

	protected function data_store_key(): string {
		return self::DATA_STORE;
	}

	public function get_location_id( string $context = 'view' ): int {
		return (int) $this->get_field( 'location_id', $context );
	}

	public function get_notes( string $context = 'view' ): string {
		return (string) $this->get_field( 'notes', $context );
	}

	// --- Domain / CPT admin (merged from helper) ---
	const SNAPSHOT_VERSION = 1;

	/**
	 * Boot hooks.
	 *
	 * @since 5.5.0
	 */
	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'register_post_type' ], 6 );
		add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_boxes' ] );
		add_action( 'edit_form_after_title', [ __CLASS__, 'render_title_hint' ] );
		add_action( 'save_post_' . self::POST_TYPE, [ __CLASS__, 'save_meta' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_scripts' ] );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', [ __CLASS__, 'list_columns' ] );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', [ __CLASS__, 'render_list_column' ], 10, 2 );
		add_action( 'admin_head-edit.php', [ __CLASS__, 'list_thumb_styles' ] );
		add_action( 'wp_trash_post', [ __CLASS__, 'trash_notice' ] );
		add_action( 'before_delete_post', [ __CLASS__, 'before_delete_resource' ] );
		add_action( 'init', [ __CLASS__, 'maybe_migrate_unscoped_resource_locations' ], 20 );
		add_action( 'admin_notices', [ __CLASS__, 'migrated_locations_notice' ] );
	}

	/**
	 * Enhanced select + WC admin styles on resource edit screens.
	 *
	 * @since 5.5.0
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue_admin_scripts( string $hook_suffix ): void {
		$screen = get_current_screen();
		if ( ! $screen || self::POST_TYPE !== $screen->post_type ) {
			return;
		}
		if ( ! in_array( $hook_suffix, [ 'post.php', 'post-new.php' ], true ) ) {
			return;
		}

		wp_enqueue_style( 'woocommerce_admin_styles' );
		wp_enqueue_style( 'select2' );
		wp_enqueue_script( 'jquery-tiptip' );
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_add_inline_script(
			'jquery-tiptip',
			'jQuery(function($){$(".woocommerce-help-tip").tipTip({attribute:"aria-label",fadeIn:50,fadeOut:50,delay:200,keepAlive:true});});'
		);
	}

	/**
	 * Register CPT under Appointments menu.
	 *
	 * @since 5.5.0
	 */
	public static function register_post_type(): void {
		$ui = WC_Appointments_Features::is_locations_resources_active();

		register_post_type(
			self::POST_TYPE,
			[
				'labels'              => [
					'name'               => __( 'Rooms & resources', 'woocommerce-appointments' ),
					'singular_name'      => __( 'Resource', 'woocommerce-appointments' ),
					'add_new'            => __( 'Add Resource', 'woocommerce-appointments' ),
					'add_new_item'       => __( 'Add New Resource', 'woocommerce-appointments' ),
					'edit_item'          => __( 'Edit Resource', 'woocommerce-appointments' ),
					'new_item'           => __( 'New Resource', 'woocommerce-appointments' ),
					'view_item'          => __( 'View Resource', 'woocommerce-appointments' ),
					'search_items'       => __( 'Search Resources', 'woocommerce-appointments' ),
					'not_found'          => __( 'No resources found', 'woocommerce-appointments' ),
					'not_found_in_trash' => __( 'No resources found in trash', 'woocommerce-appointments' ),
					'menu_name'          => __( 'Rooms & resources', 'woocommerce-appointments' ),
					'all_items'          => __( 'Rooms & resources', 'woocommerce-appointments' ),
				],
				'description'         => __( 'Rooms, equipment, and other limited items used by services.', 'woocommerce-appointments' ),
				'public'              => false,
				'show_ui'             => $ui,
				'capability_type'     => 'appointment',
				'map_meta_cap'        => true,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_in_menu'        => $ui ? 'edit.php?post_type=wc_appointment' : false,
				'hierarchical'        => false,
				'show_in_nav_menus'   => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => [ 'title', 'thumbnail' ],
				'has_archive'         => false,
			]
		);
	}

	/**
	 * Admin list columns.
	 *
	 * @since 5.5.0
	 *
	 * @param array<string, string> $columns Columns.
	 * @return array<string, string>
	 */
	public static function list_columns( array $columns ): array {
		$out = [];
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'title' === $key ) {
				$out['wca_resource_location'] = __( 'Location', 'woocommerce-appointments' );
			}
		}
		return $out;
	}

	/**
	 * Featured images beside titles on the resources list (only when set; WP escapes title HTML).
	 *
	 * @since 5.5.0
	 */
	public static function list_thumb_styles(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'edit-' . self::POST_TYPE !== $screen->id ) {
			return;
		}

		global $wp_query;
		if ( empty( $wp_query->posts ) || ! is_array( $wp_query->posts ) ) {
			return;
		}

		$css = '';
		foreach ( $wp_query->posts as $post ) {
			$url = get_the_post_thumbnail_url( (int) $post->ID, [ 80, 80 ] );
			if ( ! $url ) {
				continue;
			}
			$css .= sprintf(
				'#post-%d .row-title::before{content:"";display:inline-block;vertical-align:middle;margin-right:10px;width:40px;height:40px;border-radius:4px;background:url(%s) center/cover}',
				(int) $post->ID,
				esc_url( $url )
			);
		}
		if ( '' === $css ) {
			return;
		}
		echo '<style id="wca-resource-list-thumbs">' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_url + int IDs.
	}

	/**
	 * Render admin list column values.
	 *
	 * @since 5.5.0
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 */
	public static function render_list_column( string $column, int $post_id ): void {
		if ( 'wca_resource_location' === $column ) {
			echo esc_html( self::get_location_label( $post_id ) );
		}
	}

	/**
	 * Meta boxes on resource edit screen.
	 *
	 * @since 5.5.0
	 */
	public static function add_meta_boxes(): void {
		add_meta_box(
			'wca_resource_details',
			__( 'Resource', 'woocommerce-appointments' ),
			[ __CLASS__, 'render_meta_box' ],
			self::POST_TYPE,
			'normal',
			'high'
		);

		// Side order: Publish (core) → Featured image → Products.
		remove_meta_box( 'postimagediv', self::POST_TYPE, 'side' );
		add_meta_box(
			'postimagediv',
			__( 'Featured image' ),
			'post_thumbnail_meta_box',
			self::POST_TYPE,
			'side',
			'default'
		);

		add_meta_box(
			'wca_resource_used_by',
			__( 'Products', 'woocommerce-appointments' ),
			[ __CLASS__, 'render_used_by_meta_box' ],
			self::POST_TYPE,
			'side',
			'low'
		);
	}

	/**
	 * Hint under the post title.
	 *
	 * @since 5.5.0
	 *
	 * @param WP_Post $post Post.
	 */
	public static function render_title_hint( $post ): void {
		if ( ! is_object( $post ) || self::POST_TYPE !== $post->post_type ) {
			return;
		}
		echo '<p class="description">';
		esc_html_e( 'Name this resource (e.g. Treatment room, Laser, Massage chair).', 'woocommerce-appointments' );
		echo '</p>';
	}

	/**
	 * Render resource meta box.
	 *
	 * @since 5.5.0
	 *
	 * @param WP_Post $post Post.
	 */
	public static function render_meta_box( $post ): void {
		$resource    = get_wc_appointments_resource( (int) $post->ID );
		$location_id = $resource ? $resource->get_location_id() : 0;
		$notes       = $resource ? $resource->get_notes() : '';
		$locations   = class_exists( 'WC_Appointments_Location' )
			? WC_Appointments_Location::get_location_choices()
			: [];

		wp_nonce_field( 'wca_resource_save', 'wca_resource_nonce' );
		?>
		<div class="wca-location-edit">
			<?php if ( $locations ) : ?>
				<?php
				$selected_location = $location_id > 0 && isset( $locations[ $location_id ] )
					? $location_id
					: (int) array_key_first( $locations );
				?>
				<span class="wca-padding-float">
					<select name="wca_resource_location_id" id="wca_resource_location_id" class="wc-enhanced-select" required>
						<?php foreach ( $locations as $lid => $ltitle ) : ?>
							<option value="<?php echo esc_attr( (string) $lid ); ?>" <?php selected( $selected_location, (int) $lid ); ?>><?php echo esc_html( $ltitle ); ?></option>
						<?php endforeach; ?>
					</select>
					<label class="wca-padding-float__label" for="wca_resource_location_id">
						<?php esc_html_e( 'Location', 'woocommerce-appointments' ); ?>
						<?php echo wc_help_tip( esc_html__( 'Each room or piece of equipment belongs to one venue. For the same setup at another venue, create another resource.', 'woocommerce-appointments' ) ); ?>
					</label>
				</span>
			<?php endif; ?>

			<span class="wca-padding-float wca-location-span">
				<textarea name="wca_resource_notes" id="wca_resource_notes" rows="3"><?php echo esc_textarea( $notes ); ?></textarea>
				<label class="wca-padding-float__label" for="wca_resource_notes">
					<?php esc_html_e( 'Notes', 'woocommerce-appointments' ); ?>
					<?php echo wc_help_tip( esc_html__( 'Internal notes about this resource (not shown to customers).', 'woocommerce-appointments' ) ); ?>
				</label>
			</span>
		</div>
		<p class="description wca-hub-deeplink-notice">
			<?php esc_html_e( "Capacity and cost are set on each product's Resources tab.", 'woocommerce-appointments' ); ?>
		</p>
		<?php
		echo wp_kses_post(
			sprintf(
				'<p class="description wca-hub-deeplink-notice">%s</p>',
				'auto-draft' === $post->post_status
					? esc_html__( 'Save the resource (a draft is fine) to set open hours and unavailable times.', 'woocommerce-appointments' )
					: sprintf(
						/* translators: %s: link to the Availability hub (opens in a new tab). */
						esc_html__( 'Open hours and unavailable times for this resource are managed in the %s.', 'woocommerce-appointments' ),
						WC_Appointments_Admin_Availability_Hub::external_anchor(
							WC_Appointments_Admin_Availability_Hub::url( 'resource', $post->ID ),
							__( 'Availability hub', 'woocommerce-appointments' )
						)
					)
			)
		);
	}

	/**
	 * Persist resource meta.
	 *
	 * @since 5.5.0
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 */
	public static function save_meta( $post_id, $post ): void {
		if ( ! isset( $_POST['wca_resource_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wca_resource_nonce'] ) ), 'wca_resource_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$resource = get_wc_appointments_resource( (int) $post_id );
		if ( ! $resource ) {
			return;
		}

		$locations = class_exists( 'WC_Appointments_Location' )
			? WC_Appointments_Location::get_location_choices()
			: [];
		$location_id = 0;
		if ( $locations ) {
			$location_id = isset( $_POST['wca_resource_location_id'] ) ? absint( $_POST['wca_resource_location_id'] ) : 0;
			if ( $location_id <= 0 || ! isset( $locations[ $location_id ] ) ) {
				$location_id = (int) array_key_first( $locations );
			}
		}

		$resource->set_fields(
			[
				'notes'       => isset( $_POST['wca_resource_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['wca_resource_notes'] ) ) : '',
				'location_id' => $location_id,
			]
		);
		$resource->save();
	}

	/**
	 * Read-only list of products that require this resource.
	 *
	 * @since 5.5.0
	 *
	 * @param WP_Post $post Resource post.
	 */
	public static function render_used_by_meta_box( $post ): void {
		$resource_id = is_object( $post ) ? (int) $post->ID : 0;
		$product_ids = $resource_id > 0 ? self::get_product_ids_using_resource( $resource_id ) : [];

		if ( ! $product_ids ) {
			echo '<p class="description">';
			esc_html_e( 'No products require this resource yet. Assign it on the product Resources tab.', 'woocommerce-appointments' );
			echo '</p>';
		} else {
			$default_color = WC_Appointments_Admin::get_default_cal_color();
			echo '<ul class="wca-location-used-by">';
			foreach ( $product_ids as $product_id ) {
				$title = get_the_title( $product_id );
				if ( '' === $title ) {
					/* translators: %d: product ID */
					$title = sprintf( __( 'Product #%d', 'woocommerce-appointments' ), $product_id );
				}
				$color = trim( (string) get_post_meta( $product_id, '_wc_appointment_cal_color', true ) );
				$url   = get_edit_post_link( $product_id, 'raw' );
				$dot   = sprintf(
					'<span class="wca-product-color-dot" style="--wca-dot-color:%s" aria-hidden="true"></span>',
					esc_attr( '' !== $color ? $color : $default_color )
				);
				echo '<li>';
				if ( $url ) {
					printf(
						'<a class="wca-location-used-by__link" href="%s"><span class="wca-location-used-by__title">%s</span>%s</a>',
						esc_url( $url ),
						esc_html( $title ),
						$dot // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
					);
				} else {
					echo '<span class="wca-location-used-by__title">' . esc_html( $title ) . '</span>' . $dot; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				echo '</li>';
			}
			echo '</ul>';
		}

		$can_manage_products = class_exists( 'WC_Appointments_Staff_Permissions' )
			? WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'manage_products' )
			: current_user_can( 'edit_products' );

		if ( $can_manage_products ) {
			echo '<div class="wca-location-used-by-footer">';
			printf(
				'<a href="%s" target="_blank">%s</a>',
				esc_url( admin_url( 'edit.php?post_type=product&product_type=appointment' ) ),
				esc_html__( 'Manage Products', 'woocommerce-appointments' )
			);
			echo '</div>';
		}
	}

	/**
	 * Show admin notice when trashing a resource that products still require.
	 *
	 * @since 5.5.0
	 *
	 * @param int $post_id Post ID.
	 */
	public static function trash_notice( $post_id ): void {
		if ( self::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		$product_ids = self::get_product_ids_using_resource( (int) $post_id );
		if ( [] === $product_ids ) {
			return;
		}
		$titles = array_map( 'get_the_title', $product_ids );
		if ( class_exists( 'WC_Admin_Meta_Boxes' ) ) {
			WC_Admin_Meta_Boxes::add_error(
				sprintf(
					/* translators: %s: comma-separated product names */
					__( 'This resource is still required by: %s. Those products will have no bookable slots until the requirement is removed or the resource is restored.', 'woocommerce-appointments' ),
					implode( ', ', $titles )
				)
			);
		}
	}

	/**
	 * Remove availability#resource rules when a resource is permanently deleted.
	 *
	 * @since 5.5.0
	 *
	 * @param int $post_id Post ID.
	 */
	public static function before_delete_resource( $post_id ): void {
		$post_id = absint( $post_id );
		if ( ! $post_id || self::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}
		$data_store = WC_Data_Store::load( 'appointments-availability' );
		if ( $data_store && method_exists( $data_store, 'delete_rules_for_kind' ) ) {
			$data_store->delete_rules_for_kind( WC_Appointments_Availability::KIND_RESOURCE, $post_id );
		}
	}

	// ─── Data helpers ────────────────────────────────────────────

	/**
	 * Whether this resource can be used at a booking location.
	 *
	 * Unscoped resources (location 0) are only valid when the shop has no
	 * locations. Location-scoped resources require a matching booking location
	 * when one is set.
	 *
	 * @since 5.5.0
	 *
	 * @param int $resource_id      Resource post ID.
	 * @param int $booking_location Occupancy location ID (0 = none / not selected).
	 * @return bool
	 */
	public static function is_available_at_location( int $resource_id, int $booking_location ): bool {
		$res_loc = WC_Appointments_Resource_Data_Store::get_location_id( $resource_id );
		if ( $res_loc <= 0 ) {
			return ! class_exists( 'WC_Appointments_Location' )
				|| [] === WC_Appointments_Location::get_location_choices();
		}
		if ( $booking_location <= 0 ) {
			return true;
		}
		return $res_loc === $booking_location;
	}

	/**
	 * Admin list / summaries label for resource location.
	 *
	 * @since 5.5.0
	 *
	 * @param int $resource_id Resource post ID.
	 * @return string
	 */
	public static function get_location_label( int $resource_id ): string {
		$location_id = WC_Appointments_Resource_Data_Store::get_location_id( $resource_id );
		if ( $location_id <= 0 ) {
			return __( 'No location', 'woocommerce-appointments' );
		}
		$title = get_the_title( $location_id );
		if ( '' === $title ) {
			/* translators: %d: location ID */
			return sprintf( __( 'Location #%d', 'woocommerce-appointments' ), $location_id );
		}
		return $title;
	}

	/**
	 * Published resources as id => title.
	 *
	 * @since 5.5.0
	 *
	 * @return array<int, string>
	 */
	public static function get_resource_choices(): array {
		if ( ! WC_Appointments_Features::is_locations_resources_active() ) {
			return [];
		}

		$out = [];
		foreach ( WC_Appointments_Resource_Data_Store::get_published_ids() as $id ) {
			$out[ $id ] = get_the_title( $id );
		}
		return $out;
	}


	/**
	 * Product IDs that require this resource.
	 *
	 * @since 5.5.0
	 *
	 * @param int $resource_id Resource post ID.
	 * @return int[]
	 */
	public static function get_product_ids_using_resource( int $resource_id ): array {
		if ( $resource_id <= 0 ) {
			return [];
		}

		$out = [];
		foreach ( WC_Product_Appointment_Data_Store_CPT::get_appointable_product_ids( true ) as $product_id ) {
			$product = get_wc_product_appointment( $product_id );
			if ( ! $product instanceof WC_Product_Appointment ) {
				continue;
			}
			$requirements = $product->get_resource_requirements();
			foreach ( $requirements as $req ) {
				if ( (int) ( $req['resource_id'] ?? 0 ) === $resource_id ) {
					$out[] = (int) $product_id;
					break;
				}
			}
		}

		return $out;
	}

	/**
	 * Normalize requirements from a product (published resources only; keep order).
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @return array<int, array{resource_id: int, qty_consumed: int, capacity: int, cost: float}>
	 */
	public static function normalize_requirements( $product ): array {
		if ( ! $product instanceof WC_Product_Appointment || ! $product->has_resources() ) {
			return [];
		}
		$requirements = $product->get_resource_requirements();
		if ( [] === $requirements ) {
			return [];
		}

		$out = [];
		foreach ( $requirements as $req ) {
			$rid = (int) ( $req['resource_id'] ?? 0 );
			if ( $rid <= 0 ) {
				continue;
			}
			if ( 'publish' !== get_post_status( $rid ) || self::POST_TYPE !== get_post_type( $rid ) ) {
				continue;
			}
			$out[] = [
				'resource_id'  => $rid,
				'qty_consumed' => max( 1, (int) ( $req['qty_consumed'] ?? 1 ) ),
				'capacity'     => max( 1, (int) ( $req['capacity'] ?? 1 ) ),
				'cost'         => (float) ( $req['cost'] ?? 0 ),
			];
		}
		return $out;
	}

	/**
	 * Whether a resource ID is allowed for this product (posted occupancy / customer pick).
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment $product     Product.
	 * @param int                    $resource_id Resource ID.
	 */
	public static function authorize_resource_id( $product, int $resource_id ): bool {
		if ( $resource_id <= 0 || ! is_a( $product, 'WC_Product_Appointment' ) ) {
			return false;
		}
		foreach ( self::normalize_requirements( $product ) as $req ) {
			if ( $resource_id === (int) ( $req['resource_id'] ?? 0 ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether a resource is unavailable for a Fake-UTC window (OR-pool seat / allocation).
	 *
	 * Empty / Closed-only = default open. Any Open rule seeds default closed so minutes
	 * outside Open count as unavailable.
	 *
	 * @since 5.5.0
	 *
	 * @param int $resource_id Resource post ID.
	 * @param int $start_ts    Window start (Fake UTC wall epoch).
	 * @param int $end_ts      Window end (Fake UTC wall epoch).
	 */
	public static function is_closed_for_window( int $resource_id, int $start_ts, int $end_ts ): bool {
		if ( $resource_id <= 0 || $start_ts <= 0 || $end_ts <= $start_ts ) {
			return false;
		}
		if ( ! class_exists( 'WC_Appointments_Availability_Data_Store', false )
			|| ! class_exists( 'WC_Appointment_Slots_Rule_Resolver', false ) ) {
			return false;
		}
		$raw = WC_Appointments_Availability_Data_Store::get_resource_availability( $resource_id );
		if ( empty( $raw ) ) {
			return false;
		}
		$rules = WC_Product_Appointment_Rule_Manager::process_availability_rules( array_reverse( $raw ), 'resource', false, null );
		if ( empty( $rules ) ) {
			return false;
		}
		usort( $rules, [ 'WC_Product_Appointment_Rule_Manager', 'sort_rules_callback' ] );

		$default_avail = ! in_array( true, array_column( $rules, 'appointable' ), true );
		$day_midnight  = (int) ( new DateTimeImmutable( gmdate( 'Y-m-d', $start_ts ) . ' 00:00:00', new DateTimeZone( 'UTC' ) ) )->getTimestamp();
		$start_min     = max( 0, (int) floor( ( $start_ts - $day_midnight ) / 60 ) );
		$end_min       = max( $start_min + 1, (int) ceil( ( $end_ts - $day_midnight ) / 60 ) );
		$interval      = max( 1, $end_min - $start_min );
		$mask          = WC_Appointment_Slots_Rule_Resolver::build_minute_mask( $rules, $day_midnight, $default_avail, $interval, 0 );

		for ( $m = $start_min; $m < $end_min; $m++ ) {
			if ( isset( $mask[ $m ] ) && ! $mask[ $m ][0] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Units already consumed on a resource in a window (each appointment counts).
	 *
	 * Applies each appointment product's own padding to its occupancy window,
	 * matching the slots resource bucket.
	 *
	 * @since 5.5.0
	 *
	 * @param int $resource_id Resource post ID.
	 * @param int $start_ts    Window start (padded booking window).
	 * @param int $end_ts      Window end (padded booking window).
	 * @param int $exclude_id  Appointment ID to ignore (reschedule / self).
	 * @return int
	 */
	public static function count_used_in_window( int $resource_id, int $start_ts, int $end_ts, int $exclude_id = 0 ): int {
		if ( $resource_id <= 0 || $start_ts <= 0 || $end_ts <= $start_ts ) {
			return 0;
		}

		// Pad the SQL window by a day so product padding outside the exact range is still loaded.
		$ids = WC_Appointments_Resource_Data_Store::get_appointment_ids_in_range(
			[ $resource_id ],
			$start_ts - DAY_IN_SECONDS,
			$end_ts + DAY_IN_SECONDS
		);
		if ( [] === $ids ) {
			return 0;
		}

		$used = 0;
		foreach ( $ids as $appointment_id ) {
			if ( $appointment_id <= 0 || $appointment_id === $exclude_id ) {
				continue;
			}
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment || ! is_a( $appointment, 'WC_Appointment' ) ) {
				continue;
			}

			$pad_before = 0;
			$pad_after  = 0;
			$appt_product = $appointment->get_product();
			if ( $appt_product instanceof WC_Product_Appointment ) {
				$pad_before = (int) $appt_product->get_padding_before_in_minutes();
				$pad_after  = (int) $appt_product->get_padding_after_in_minutes();
			}
			$a_start = (int) $appointment->get_start() - ( $pad_before * 60 );
			$a_end   = (int) $appointment->get_end() + ( $pad_after * 60 );
			if ( $a_start >= $end_ts || $a_end <= $start_ts ) {
				continue;
			}

			foreach ( (array) $appointment->get_resource_allocations() as $alloc ) {
				if ( (int) ( $alloc['resource_id'] ?? 0 ) === $resource_id ) {
					$used += max( 1, (int) ( $alloc['qty_consumed'] ?? 1 ) );
				}
			}
		}

		return $used;
	}

	/**
	 * Build allocation snapshot array from product requirements.
	 *
	 * Checked resources are an OR pool: one is allocated. Customer mode uses the
	 * chosen ID; Automatic picks the first location-eligible resource with free
	 * capacity in the booking window (falls back to first match when no window).
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment $product              Product.
	 * @param int                    $selected_resource_id Customer-selected resource (0 = auto-pick).
	 * @param int                    $location_id          Booking location (0 = not set).
	 * @param int                    $start_ts             Booking start (0 = skip free check).
	 * @param int                    $end_ts               Booking end (0 = skip free check).
	 * @param int                    $exclude_id           Appointment ID to ignore when counting use.
	 * @return array<int, array<string, mixed>> Array of allocation snapshots (0 or 1 entry).
	 */
	public static function build_allocations_from_product( $product, int $selected_resource_id = 0, int $location_id = 0, int $start_ts = 0, int $end_ts = 0, int $exclude_id = 0 ): array {
		$requirements = self::normalize_requirements( $product );
		if ( [] === $requirements ) {
			return [];
		}

		if ( $location_id > 0 ) {
			$requirements = array_values(
				array_filter(
					$requirements,
					static function ( array $req ) use ( $location_id ): bool {
						return self::is_available_at_location( (int) $req['resource_id'], $location_id );
					}
				)
			);
		}

		if ( [] === $requirements ) {
			return [];
		}

		// Customer selected: only the chosen alternative.
		if ( $selected_resource_id > 0 ) {
			$matched = array_values(
				array_filter(
					$requirements,
					static function ( array $req ) use ( $selected_resource_id ): bool {
						return (int) $req['resource_id'] === $selected_resource_id;
					}
				)
			);
			if ( [] !== $matched ) {
				$requirements = $matched;
			} else {
				// Stale / wrong-location pick: fall back to automatic from the filtered pool.
				$selected_resource_id = 0;
			}
		}
		if ( $selected_resource_id <= 0 ) {
			$pad_start = $start_ts;
			$pad_end   = $end_ts;
			if ( $pad_start > 0 && $pad_end > $pad_start && $product instanceof WC_Product_Appointment ) {
				$pad_start -= (int) $product->get_padding_before_in_minutes() * 60;
				$pad_end   += (int) $product->get_padding_after_in_minutes() * 60;
			}

			$picked = null;
			foreach ( $requirements as $req ) {
				$rid          = (int) $req['resource_id'];
				$qty_consumed = (int) $req['qty_consumed'];
				if ( $pad_start > 0 && $pad_end > $pad_start ) {
					if ( self::is_closed_for_window( $rid, $pad_start, $pad_end ) ) {
						continue;
					}
					$used = self::count_used_in_window( $rid, $pad_start, $pad_end, $exclude_id );
					if ( ( (int) $req['capacity'] - $used ) < $qty_consumed ) {
						continue;
					}
				}
				$picked = $req;
				break;
			}
			if ( null === $picked ) {
				if ( $pad_start > 0 && $pad_end > $pad_start ) {
					return [];
				}
				$picked = $requirements[0];
			}
			$requirements = [ $picked ];
		}

		$req = $requirements[0];
		$rid = (int) $req['resource_id'];

		return [
			[
				'snapshot_version' => self::SNAPSHOT_VERSION,
				'resource_id'      => $rid,
				'title'            => get_the_title( $rid ),
				'qty_consumed'     => $req['qty_consumed'],
				'cost'             => (float) ( $req['cost'] ?? 0 ),
			],
		];
	}

	/**
	 * Apply allocations onto an appointment at write time.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment                   $appointment Appointment.
	 * @param array<int, array<string, mixed>> $allocations Allocation snapshot array.
	 */
	public static function apply_to_appointment( $appointment, array $allocations ): void {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return;
		}
		$appointment->set_resource_allocations( $allocations );
	}

	/**
	 * Titles from allocation snapshots for admin display (comma-separated).
	 *
	 * @since 5.5.0
	 *
	 * @param array<int, array<string, mixed>> $allocations Allocations.
	 * @return string
	 */
	public static function format_allocations_for_display( array $allocations ): string {
		$titles = [];
		foreach ( $allocations as $alloc ) {
			$title = isset( $alloc['title'] ) ? trim( (string) $alloc['title'] ) : '';
			if ( '' !== $title ) {
				$titles[] = $title;
			}
		}
		return implode( ', ', $titles );
	}

	/**
	 * Whether allocated resources should be shown to the current audience.
	 *
	 * Admin always sees allocations when present. Customers only when Selection is
	 * Customer selects, or Automatic with show name (stored as display).
	 * Same contract as {@see WC_Appointments_Location::should_display()}.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @param bool           $is_admin    Admin / staff email context.
	 * @return bool
	 */
	public static function should_display( $appointment, bool $is_admin = false ): bool {
		if ( ! is_a( $appointment, 'WC_Appointment' ) || ! $appointment->has_resource_allocations() ) {
			return false;
		}
		if ( $is_admin ) {
			return true;
		}
		$product = $appointment->get_product();
		if ( ! $product instanceof WC_Product_Appointment ) {
			return false;
		}
		return in_array( $product->get_resource_assignment(), [ 'display', 'customer' ], true );
	}

	/**
	 * Formatted resource titles for the current audience, or empty when hidden.
	 *
	 * Same contract as {@see WC_Appointments_Location::get_context_display()}.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @param bool           $is_admin    Admin context.
	 * @return string
	 */
	public static function get_context_display( $appointment, bool $is_admin = false ): string {
		if ( ! self::should_display( $appointment, $is_admin ) ) {
			return '';
		}
		return $appointment->get_resource_display();
	}

	/**
	 * One-shot init scan: assign unscoped resources once locations already exist.
	 *
	 * Does not mark complete while the shop still has no locations. Venues published
	 * later claim rooms via {@see claim_unscoped_resource_locations()}.
	 *
	 * @since 5.5.0
	 */
	public static function maybe_migrate_unscoped_resource_locations(): void {
		$done_flag = 'wc_appointments_resources_location_migration_v1_done';
		if ( get_option( $done_flag ) ) {
			return;
		}

		// Read-only storefront day-slots AJAX must not scan/migrate resources on every request.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$wc_ajax = isset( $_REQUEST['wc-ajax'] ) ? sanitize_key( wp_unslash( $_REQUEST['wc-ajax'] ) ) : '';
		if ( 'wc_appointments_find_scheduled_day_slots' === $wc_ajax ) {
			return;
		}

		if ( ! class_exists( 'WC_Appointments_Location' ) ) {
			return;
		}
		if ( [] === WC_Appointments_Location::get_location_choices() ) {
			return;
		}

		self::claim_unscoped_resource_locations();
		// Locations exist: one-shot init scan. Further claims run on venue publish / resource save.
		update_option( $done_flag, 1, true );
	}

	/**
	 * Assign unscoped resources and queue an admin notice when any were claimed.
	 *
	 * Used when a venue is published (bypasses the init one-shot flag).
	 *
	 * @since 5.5.0
	 *
	 * @return array<int, array{resource_id:int, location_id:int, title:string}>
	 */
	public static function claim_unscoped_resource_locations(): array {
		$migrated = self::migrate_unscoped_resource_locations();
		if ( [] === $migrated ) {
			return [];
		}

		$existing = get_option( 'wc_appointments_resources_location_migration_notice', [] );
		if ( ! is_array( $existing ) ) {
			$existing = [];
		}
		update_option(
			'wc_appointments_resources_location_migration_notice',
			array_merge( $existing, $migrated ),
			false
		);

		return $migrated;
	}

	/**
	 * Assign unscoped resources (location 0) when the shop has locations.
	 *
	 * @since 5.5.0
	 *
	 * @return array<int, array{resource_id:int, location_id:int, title:string}>
	 */
	public static function migrate_unscoped_resource_locations(): array {
		if ( ! class_exists( 'WC_Appointments_Location' ) ) {
			return [];
		}

		$location_ids = array_map( 'intval', array_keys( WC_Appointments_Location::get_location_choices() ) );
		if ( [] === $location_ids ) {
			return [];
		}

		sort( $location_ids, SORT_NUMERIC );

		$migrated = [];
		foreach ( array_keys( self::get_resource_choices() ) as $resource_id ) {
			$resource_id = (int) $resource_id;
			if ( WC_Appointments_Resource_Data_Store::get_location_id( $resource_id ) > 0 ) {
				continue;
			}

			$location_id = self::resolve_migration_location_id( $resource_id, $location_ids );
			WC_Appointments_Resource_Data_Store::update_location_id( $resource_id, $location_id );
			$migrated[] = [
				'resource_id' => $resource_id,
				'location_id' => $location_id,
				'title'       => get_the_title( $resource_id ),
			];
		}

		return $migrated;
	}

	/**
	 * Pick a venue for an unscoped resource during migration.
	 *
	 * @since 5.5.0
	 *
	 * @param int   $resource_id  Resource post ID.
	 * @param int[] $location_ids Published location IDs (sorted).
	 * @return int
	 */
	public static function resolve_migration_location_id( int $resource_id, array $location_ids ): int {
		if ( [] === $location_ids ) {
			return 0;
		}
		if ( 1 === count( $location_ids ) ) {
			return (int) $location_ids[0];
		}

		$candidate_sets = [];
		foreach ( self::get_product_ids_using_resource( $resource_id ) as $product_id ) {
			$product = get_wc_product_appointment( $product_id );
			if ( ! $product instanceof WC_Product_Appointment || ! $product->has_locations() ) {
				continue;
			}
			$allowed = array_map( 'intval', WC_Appointments_Location::get_allowed_location_ids( $product ) );
			$allowed = array_values( array_intersect( $allowed, $location_ids ) );
			if ( [] !== $allowed ) {
				$candidate_sets[] = $allowed;
			}
		}

		if ( [] !== $candidate_sets ) {
			$intersect = array_shift( $candidate_sets );
			foreach ( $candidate_sets as $set ) {
				$intersect = array_values( array_intersect( $intersect, $set ) );
			}
			if ( [] !== $intersect ) {
				sort( $intersect, SORT_NUMERIC );
				return (int) $intersect[0];
			}
		}

		return (int) $location_ids[0];
	}

	/**
	 * Admin notice listing resources auto-assigned to a venue.
	 *
	 * @since 5.5.0
	 */
	public static function migrated_locations_notice(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_appointments' ) ) {
			return;
		}

		if ( isset( $_GET['wc_appointments_dismiss_resource_location_notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ?? '' ) ), 'wc_appointments_dismiss_resource_location_notice' ) ) {
				return;
			}
			delete_option( 'wc_appointments_resources_location_migration_notice' );
			return;
		}

		$migrated = get_option( 'wc_appointments_resources_location_migration_notice', [] );
		if ( ! is_array( $migrated ) || [] === $migrated ) {
			return;
		}

		$items = [];
		foreach ( $migrated as $row ) {
			$resource_id = (int) ( $row['resource_id'] ?? 0 );
			$location_id = (int) ( $row['location_id'] ?? 0 );
			$title       = isset( $row['title'] ) ? (string) $row['title'] : get_the_title( $resource_id );
			$location    = $location_id > 0 ? get_the_title( $location_id ) : '';
			if ( '' === $title ) {
				/* translators: %d: resource ID */
				$title = sprintf( __( 'Resource #%d', 'woocommerce-appointments' ), $resource_id );
			}
			if ( '' === $location ) {
				/* translators: %d: location ID */
				$location = sprintf( __( 'Location #%d', 'woocommerce-appointments' ), $location_id );
			}
			$items[] = sprintf( '%1$s → %2$s', $title, $location );
		}

		$dismiss_url = wp_nonce_url(
			add_query_arg( 'wc_appointments_dismiss_resource_location_notice', '1' ),
			'wc_appointments_dismiss_resource_location_notice'
		);

		echo '<div class="notice notice-info is-dismissible"><p>';
		echo esc_html__( 'Rooms & resources no longer use All locations. These were assigned to a venue automatically. Review and move any that belong elsewhere:', 'woocommerce-appointments' );
		echo '</p><ul style="list-style:disc;margin-left:1.5em;">';
		foreach ( $items as $item ) {
			echo '<li>' . esc_html( $item ) . '</li>';
		}
		echo '</ul><p><a href="' . esc_url( $dismiss_url ) . '">' . esc_html__( 'Dismiss', 'woocommerce-appointments' ) . '</a></p></div>';
	}

}


WC_Appointments_Resource::init();
