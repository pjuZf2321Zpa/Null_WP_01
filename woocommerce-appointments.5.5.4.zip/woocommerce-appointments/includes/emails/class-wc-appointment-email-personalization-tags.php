<?php
/**
 * WooCommerce Appointments Email Personalization Tags
 *
 * Registers appointment-only personalization tags for the WooCommerce block email editor.
 * Customer and order fields use WooCommerce core tags (see CustomerTagsProvider, OrderTagsProvider);
 * this class adds context via WC_Appointment_Email_Manager::add_appointment_context_data() so
 * tags like woocommerce/customer-full-name and woocommerce/order-payment-url work when applicable.
 *
 * @package WooCommerce Appointments
 * @since   5.3.8
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\EmailEditor\Engine\PersonalizationTags\Personalization_Tag;

/**
 * WC_Appointment_Email_Personalization_Tags class.
 *
 * Handles registration and rendering of appointment-specific personalization tags
 * for the WooCommerce block email editor.
 */
class WC_Appointment_Email_Personalization_Tags {

	/**
	 * Initialize the personalization tags.
	 *
	 * @since 5.3.8
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'woocommerce_email_editor_register_personalization_tags', [ $this, 'register_personalization_tags' ] );
	}

	/**
	 * Register appointment personalization tags.
	 *
	 * @since 5.3.8
	 *
	 * @param object $personalization_tags_registry The personalization tags registry.
	 * @return object The personalization tags registry.
	 */
	public function register_personalization_tags( $personalization_tags_registry ) {
		// Check if the Personalization_Tag class exists (WooCommerce 9.0+).
		if ( ! class_exists( Personalization_Tag::class ) ) {
			return $personalization_tags_registry;
		}

		// Appointment ID (not the same as woocommerce/order-number).
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Appointment ID', 'woocommerce-appointments' ),
				'woocommerce-appointments/id',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_id' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		/**
		 * Customer display name: same resolution order as woocommerce/customer-full-name (billing → WP user → guest)
		 * once context is enriched with order/wp_user in WC_Appointment_Email_Manager::add_appointment_context_data().
		 */
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Customer name', 'woocommerce-appointments' ),
				'woocommerce-appointments/customer-name',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_customer_name' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Appointment admin link (WC provides woocommerce/order-admin-url for orders, not CPT appointments).
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Admin Edit Link', 'woocommerce-appointments' ),
				'woocommerce-appointments/admin-link',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_admin_link' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Appointment start date.
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Start Date', 'woocommerce-appointments' ),
				'woocommerce-appointments/start-date',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_start_date' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Appointment end date.
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'End Date', 'woocommerce-appointments' ),
				'woocommerce-appointments/end-date',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_end_date' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Appointment duration.
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Duration', 'woocommerce-appointments' ),
				'woocommerce-appointments/duration',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_duration' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Scheduled product name for this appointment (not the same as woocommerce/order-items).
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Product Name', 'woocommerce-appointments' ),
				'woocommerce-appointments/product-name',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_product_name' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Appointment staff.
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Staff', 'woocommerce-appointments' ),
				'woocommerce-appointments/staff',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_staff' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Appointment resources.
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Resources', 'woocommerce-appointments' ),
				'woocommerce-appointments/resources',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_resources' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Customer reschedule link.
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Reschedule Link', 'woocommerce-appointments' ),
				'woocommerce-appointments/reschedule-link',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_reschedule_link' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		// Customer cancel link.
		$personalization_tags_registry->register(
			new Personalization_Tag(
				__( 'Cancel Link', 'woocommerce-appointments' ),
				'woocommerce-appointments/cancel-link',
				__( 'Appointment', 'woocommerce-appointments' ),
				[ $this, 'get_appointment_cancel_link' ],
				[],
				null,
				[ 'woo_email' ]
			)
		);

		return $personalization_tags_registry;
	}

	/**
	 * Get appointment from context.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return WC_Appointment|null The appointment object or null.
	 */
	private function get_appointment_from_context( $context ) {
		if ( ! empty( $context['appointment'] ) && $context['appointment'] instanceof WC_Appointment ) {
			return $context['appointment'];
		}

		if ( ! empty( $context['appointment_id'] ) && function_exists( 'get_wc_appointment' ) ) {
			$appointment = get_wc_appointment( $context['appointment_id'] );
			if ( $appointment ) {
				return $appointment;
			}
		}

		return null;
	}

	/**
	 * Get appointment ID.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_id( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		return (string) $appointment->get_id();
	}

	/**
	 * Customer display name matching WooCommerce CustomerTagsProvider logic when context includes order or wp_user,
	 * then guest/customer record name from the appointment (same cases as woocommerce/customer-full-name).
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_customer_name( $context ) {
		if ( isset( $context['order'] ) ) {
			return $context['order']->get_formatted_billing_full_name() ?? '';
		}
		if ( isset( $context['wp_user'] ) ) {
			$first_name = $context['wp_user']->first_name ?? '';
			$last_name  = $context['wp_user']->last_name ?? '';

			return trim( "$first_name $last_name" );
		}

		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		return $appointment->get_customer()->full_name;
	}

	/**
	 * Get appointment admin link.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_admin_link( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '#';
		}

		$edit_url = admin_url( 'post.php?post=' . $appointment->get_id() . '&action=edit' );

		return '<a href="' . esc_url( $edit_url ) . '">' . __( 'Edit appointment', 'woocommerce-appointments' ) . '</a>';
	}

	/**
	 * Get appointment start date.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_start_date( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		$customer_tz = $appointment->get_effective_customer_timezone();

		// Plain text: HTML abbr from get_*_for_email() is escaped in the block editor and appears as raw markup.
		$formatted = $appointment->get_start_date_for_email( $customer_tz, true );

		return is_string( $formatted ) ? $formatted : '';
	}

	/**
	 * Get appointment end date.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_end_date( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		$customer_tz = $appointment->get_effective_customer_timezone();

		// Plain text: HTML abbr from get_*_for_email() is escaped in the block editor and appears as raw markup.
		$formatted = $appointment->get_end_date_for_email( $customer_tz, true );

		return is_string( $formatted ) ? $formatted : '';
	}

	/**
	 * Get appointment duration.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_duration( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		return $appointment->get_duration();
	}

	/**
	 * Get appointment product name.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_product_name( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		return $appointment->get_product_name();
	}

	/**
	 * Get appointment staff.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_staff( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment || ! $appointment->has_staff() ) {
			return '';
		}

		return $appointment->get_staff_members( true );
	}

	/**
	 * Get appointment resources.
	 *
	 * @since 5.5.0
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_resources( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment || ! class_exists( 'WC_Appointments_Resource' ) ) {
			return '';
		}

		return WC_Appointments_Resource::get_context_display( $appointment, false );
	}

	/**
	 * Get appointment reschedule link.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_reschedule_link( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		$product = $appointment->get_product();
		if ( ! $product || ! $product->get_user_can_reschedule() ) {
			return '';
		}

		$reschedule_url = $appointment->get_reschedule_url();

		return '<a href="' . esc_url( $reschedule_url ) . '">' . __( 'Reschedule appointment', 'woocommerce-appointments' ) . '</a>';
	}

	/**
	 * Get appointment cancel link.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @return string
	 */
	public function get_appointment_cancel_link( $context ) {
		$appointment = $this->get_appointment_from_context( $context );

		if ( ! $appointment ) {
			return '';
		}

		$product = $appointment->get_product();
		if ( ! $product || ! $product->get_user_can_cancel() ) {
			return '';
		}

		$cancel_url = $appointment->get_cancel_url();

		return '<a href="' . esc_url( $cancel_url ) . '">' . __( 'Cancel appointment', 'woocommerce-appointments' ) . '</a>';
	}
}
