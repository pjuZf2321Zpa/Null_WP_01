<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Email_Appointment_Series' ) ) :

	/**
	 * Appointment series
	 *
	 * An email sent when a recurring package is created or when multiple series
	 * occurrences are cancelled or updated in one scoped action. The customer is
	 * the primary recipient; admin and assigned staff receive the same copy via BCC.
	 *
	 * @class   WC_Email_Appointment_Series
	 */
	class WC_Email_Appointment_Series extends WC_Email {

		/**
		 * Email variant: created, cancelled, or status_changed.
		 *
		 * @var string
		 */
		public $series_kind = '';

		/**
		 * Series row for this email.
		 *
		 * @var WC_Appointment_Series|null
		 */
		public $appointment_series;

		/**
		 * Occurrences included in this email.
		 *
		 * @var WC_Appointment[]
		 */
		public $affected_appointments = [];

		/**
		 * Scoped change context (scope, new_status, appointment_ids, …).
		 *
		 * @var array<string, mixed>
		 */
		public $series_context = [];

		/**
		 * @var string[]
		 */
		protected $attachments_cache = [];

		/**
		 * Block editor email template path.
		 *
		 * @var string
		 */
		public $template_block = '';

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->id             = 'appointment_series';
			$this->title          = __( 'Appointment Series', 'woocommerce-appointments' );
			$this->description    = __( 'Sent when a recurring package is confirmed or when multiple appointments in a series are cancelled or updated. Per-appointment reminders use Appointment Reminder.', 'woocommerce-appointments' );
			$this->customer_email = true;
			$this->template_html  = 'emails/customer-appointment-series.php';
			$this->template_plain = 'emails/plain/customer-appointment-series.php';
			$this->template_block = 'emails/block/customer-appointment-series.php';
			$this->placeholders   = [
				'{site_title}'                    => $this->get_blogname(),
				'{appointment_series_kind}'       => '',
				'{appointment_series_title}'      => '',
				'{appointment_series_id}'                  => '',
				'{appointment_series_pattern}'             => '',
				'{appointment_series_session_count}'       => '',
				'{appointment_series_sessions_table}'      => '',
				'{appointment_series_scope}'               => '',
				'{appointment_series_new_status}'          => '',
				'{appointment_series_manage_url}'            => '',
				'{product_title}'                          => '',
				'{order_date}'                             => '',
				'{order_number}'                           => '',
			];

			parent::__construct();

			$this->template_base = WC_APPOINTMENTS_TEMPLATE_PATH;
		}

		/**
		 * Trigger the email.
		 *
		 * @param int                  $appointment_series_id Series id.
		 * @param string               $kind                  created|cancelled|status_changed.
		 * @param array<string, mixed> $args                  Notification context.
		 */
		public function trigger( $appointment_series_id, $kind, $args = [] ) {
			$this->setup_locale();

			$this->series_kind      = (string) $kind;
			$this->series_context   = is_array( $args ) ? $args : [];
			$this->attachments_cache      = [];

			try {
				$this->appointment_series = new WC_Appointment_Series( (int) $appointment_series_id );
			} catch ( Exception $e ) {
				unset( $e );
				return;
			}

			$this->affected_appointments = $this->load_affected_appointments();
			$this->setup_placeholders();
			$this->setup_recipient();

			if ( ! $this->is_enabled() || ! $this->get_recipient() ) {
				return;
			}

			if ( WC_Appointment_Series_Email::KIND_CREATED === $this->series_kind && $this->ics_enabled() ) {
				$this->attachments_cache = $this->build_ics_attachments();
			}

			$recipient = $this->get_recipient();
			$headers   = $this->get_headers();

			$bcc = (string) $this->get_option( 'bcc', '' );
			if ( '' === $bcc ) {
				$bcc = (string) $this->get_option( 'additional_recipients', get_option( 'admin_email' ) );
			}
			$bcc_emails = array_filter( array_map( 'trim', explode( ',', $bcc ) ) );
			foreach ( $this->affected_appointments as $appointment ) {
				if ( $appointment->has_staff() ) {
					foreach ( (array) $appointment->get_staff_members() as $staff ) {
						if ( ! empty( $staff->user_email ) ) {
							$bcc_emails[] = $staff->user_email;
						}
					}
				}
			}
			$bcc = (string) apply_filters( 'woocommerce_email_appointment_series_bcc', implode( ', ', array_unique( $bcc_emails ) ), $this );
			if ( $bcc ) {
				list( $recipient, $headers ) = WC_Appointment_Email_Manager::prepare_private_recipients( $recipient . ', ' . $bcc, $headers );
			}

			$recipient = apply_filters( 'woocommerce_email_appointment_series_recipients', $recipient, $this );

			$this->send( $recipient, $this->get_subject(), $this->get_content(), $headers, $this->get_attachments() );
		}

		/**
		 * Get email subject.
		 *
		 * @return string
		 */
		public function get_default_subject() {
			return $this->series_kind_copy( 'subject' );
		}

		/**
		 * Get email heading.
		 *
		 * @return string
		 */
		public function get_default_heading() {
			return $this->series_kind_copy( 'heading' );
		}

		/**
		 * Default content to show below main email content.
		 *
		 * @return string
		 */
		public function get_default_additional_content() {
			return __( 'Contact us if you have questions about this package.', 'woocommerce-appointments' );
		}

		/**
		 * Intro paragraph for the series email body (HTML and plain).
		 *
		 * @param string $series_kind WC_Appointment_Series_Email::KIND_* constant.
		 * @return string
		 */
		public function get_kind_intro( $series_kind ) {
			if ( WC_Appointment_Series_Email::KIND_CREATED === $series_kind ) {
				return __( 'Your recurring package is confirmed. Appointment details are below.', 'woocommerce-appointments' );
			}
			if ( WC_Appointment_Series_Email::KIND_CANCELLED === $series_kind ) {
				return __( 'Recurring appointments were cancelled. Appointment details are below.', 'woocommerce-appointments' );
			}
			if ( WC_Appointment_Series_Email::KIND_STATUS_CHANGED === $series_kind ) {
				return __( 'Recurring appointments were updated. Appointment details are below.', 'woocommerce-appointments' );
			}

			return '';
		}

		/**
		 * @return string[]
		 */
		public function get_attachments() {
			return $this->attachments_cache;
		}

		/**
		 * @return bool
		 */
		public function ics_enabled() {
			return 'yes' === $this->get_option( 'ics_enabled', 'yes' );
		}

		/**
		 * @return WC_Appointment[]
		 */
		protected function load_affected_appointments() {
			$ids = [];

			if ( ! empty( $this->series_context['appointment_ids'] ) ) {
				$ids = array_map( 'intval', (array) $this->series_context['appointment_ids'] );
			} elseif ( WC_Appointment_Series_Email::KIND_CREATED === $this->series_kind && $this->appointment_series ) {
				$manager    = new WC_Appointment_Series_Manager();
				$series_ids = WC_Appointment_Series_Email::get_series_ids_for_order( (int) $this->appointment_series->get_order_id() );
				if ( ! $series_ids ) {
					$series_ids = array( (int) $this->appointment_series->get_id() );
				}
				foreach ( $series_ids as $load_series_id ) {
					foreach ( $manager->get_occurrence_rows( $load_series_id ) as $row ) {
						$ids[] = (int) $row['appointment_id'];
					}
				}
			}

			$max = (int) apply_filters(
				'wc_appointments_series_ics_max_events',
				200,
				$this->appointment_series ? $this->appointment_series->get_id() : 0,
				$this->series_kind
			);
			if ( $max > 0 && count( $ids ) > $max ) {
				$ids = array_slice( $ids, 0, $max );
			}

			$appointments = [];
			foreach ( $ids as $id ) {
				$appt = get_wc_appointment( $id );
				if ( $appt ) {
					$appointments[] = $appt;
				}
			}

			usort(
				$appointments,
				static function ( $a, $b ) {
					return (int) $a->get_start() <=> (int) $b->get_start();
				}
			);

			return apply_filters(
				'wc_appointments_series_email_occurrences',
				$appointments,
				$this->appointment_series,
				$this->series_kind,
				$this->series_context
			);
		}

		/**
		 * @return void
		 */
		protected function setup_placeholders() {
			if ( ! $this->appointment_series ) {
				return;
			}

			$product = wc_get_product( $this->appointment_series->get_product_id() );
			$title   = $product ? $product->get_name() : '';

			$this->placeholders['{appointment_series_kind}']   = $this->series_kind;
			$this->placeholders['{appointment_series_title}'] = $this->get_kind_title();
			$this->placeholders['{appointment_series_id}']                 = (string) $this->appointment_series->get_id();
			$this->placeholders['{appointment_series_pattern}']            = WC_Appointment_Series_RRule::humanize(
				$this->appointment_series->get_rrule(),
				$this->appointment_series->get_dtstart_ts(),
				$this->appointment_series->get_timezone()
			);
			$this->placeholders['{appointment_series_session_count}']      = (string) count( $this->affected_appointments );
			$this->placeholders['{appointment_series_sessions_table}']     = $this->get_sessions_table_html();
			$this->placeholders['{appointment_series_scope}']              = $this->get_scope_label();
			$this->placeholders['{appointment_series_new_status}']         = $this->get_status_label();
			$this->placeholders['{appointment_series_manage_url}']         = $this->get_manage_url();
			$this->placeholders['{product_title}']                         = $title;

			$order = $this->appointment_series->get_order_id() > 0 ? wc_get_order( $this->appointment_series->get_order_id() ) : false;
			if ( $order ) {
				$order_date = $order->get_date_created() ?: '';

				$this->placeholders['{order_date}']   = wc_format_datetime( $order_date );
				$this->placeholders['{order_number}'] = $order->get_order_number();
			} else {
				$this->placeholders['{order_date}']   = '';
				$this->placeholders['{order_number}'] = __( 'N/A', 'woocommerce-appointments' );
			}
		}

		/**
		 * @return void
		 */
		protected function setup_recipient() {
			if ( ! $this->appointment_series ) {
				return;
			}

			$order = $this->appointment_series->get_order_id() > 0 ? wc_get_order( $this->appointment_series->get_order_id() ) : false;

			if ( $order ) {
				$this->recipient = $order->get_billing_email();
			} elseif ( $this->appointment_series->get_customer_id() > 0 ) {
				$user = get_user_by( 'id', $this->appointment_series->get_customer_id() );
				if ( $user ) {
					$this->recipient = $user->user_email;
				}
			}

			if ( ! $this->recipient && ! empty( $this->affected_appointments[0] ) ) {
				$customer = $this->affected_appointments[0]->get_customer();
				if ( $customer && ! empty( $customer->email ) ) {
					$this->recipient = $customer->email;
				}
			}
		}

		/**
		 * @return string
		 */
		public function get_kind_title() {
			return $this->series_kind_copy( 'heading' );
		}

		/**
		 * Subject, heading, and kind title share the same strings (one entry per line in the .pot).
		 *
		 * @param string $part subject|heading.
		 * @return string
		 */
		protected function series_kind_copy( $part ) {
			$is_subject = 'subject' === $part;

			switch ( $this->series_kind ) {
				case WC_Appointment_Series_Email::KIND_CANCELLED:
					return $is_subject
						? __( '[{site_title}]: Recurring appointments cancelled', 'woocommerce-appointments' )
						: __( 'Recurring appointments cancelled', 'woocommerce-appointments' );
				case WC_Appointment_Series_Email::KIND_STATUS_CHANGED:
					return $is_subject
						? __( '[{site_title}]: Recurring appointments updated', 'woocommerce-appointments' )
						: __( 'Recurring appointments updated', 'woocommerce-appointments' );
				default:
					return $is_subject
						? __( '[{site_title}]: Recurring appointments confirmed for {product_title}', 'woocommerce-appointments' )
						: __( 'Recurring appointments confirmed', 'woocommerce-appointments' );
			}
		}

		/**
		 * @return string
		 */
		public function get_scope_label() {
			$scope = isset( $this->series_context['scope'] ) ? (string) $this->series_context['scope'] : '';

			if ( 'all' === $scope ) {
				return __( 'All appointments in the series', 'woocommerce-appointments' );
			}
			if ( 'future' === $scope ) {
				return __( 'This and following appointments', 'woocommerce-appointments' );
			}

			return '';
		}

		/**
		 * @return string
		 */
		public function get_status_label() {
			$status = isset( $this->series_context['new_status'] ) ? (string) $this->series_context['new_status'] : '';
			if ( '' === $status ) {
				return '';
			}

			$labels = function_exists( 'get_wc_appointment_statuses' ) ? get_wc_appointment_statuses() : [];

			return isset( $labels[ $status ] ) ? (string) $labels[ $status ] : $status;
		}

		/**
		 * @return string
		 */
		public function get_manage_url() {
			if ( ! $this->appointment_series ) {
				return '';
			}

			return class_exists( 'WC_Appointment_Series_My_Account' )
				? WC_Appointment_Series_My_Account::get_url( (int) $this->appointment_series->get_id() )
				: '';
		}

		/**
		 * @return string
		 */
		public function get_sessions_table_html() {
			if ( empty( $this->affected_appointments ) ) {
				return '';
			}

			$text_align = is_rtl() ? 'right' : 'left';
			ob_start();
			?>
			<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; margin:0 0 16px;" border="1">
				<thead>
					<tr>
						<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Date', 'woocommerce-appointments' ); ?></th>
						<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Appointment', 'woocommerce-appointments' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $this->affected_appointments as $appointment ) : ?>
						<?php $tz = $appointment->get_effective_customer_timezone(); ?>
						<tr>
							<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
								<?php echo wp_kses_post( $appointment->get_start_date_for_email( $tz, true ) ); ?>
							</td>
							<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;">
								#<?php echo esc_html( (string) $appointment->get_id() ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php
			return ob_get_clean();
		}

		/**
		 * @return string[]
		 */
		protected function build_ics_attachments() {
			if ( empty( $this->affected_appointments ) ) {
				return [];
			}

			include_once WC_APPOINTMENTS_ABSPATH . 'includes/admin/export/class-wc-appointments-ics-exporter.php';
			$exporter = new WC_Appointments_ICS_Exporter();
			$file     = $exporter->get_ics( $this->affected_appointments );

			return $file ? [ $file ] : [];
		}

		/**
		 * Block editor: pass the related WC_Order into general-block-email.php when the series has an order.
		 *
		 * @since 5.4.0
		 * @return string
		 */
		public function get_block_editor_email_template_content() {
			$order_for_blocks = null;
			if ( $this->appointment_series && $this->appointment_series->get_order_id() > 0 ) {
				$order_for_blocks = wc_get_order( $this->appointment_series->get_order_id() );
			}

			$html = wc_get_template_html(
				$this->template_block_content,
				[
					'order'         => $order_for_blocks,
					'sent_to_admin' => false,
					'plain_text'    => false,
					'email'         => $this,
				]
			);

			return $this->append_block_woo_additional_content( $html );
		}

		/**
		 * Append Additional content from email settings after dynamic series/order output in block emails.
		 *
		 * Block templates place ##WOO_CONTENT## inside the WooCommerce content block; this keeps
		 * the settings field aligned with classic templates (below main content, above the footer).
		 *
		 * Native param/return types omitted for theme subclass BC on PHP 8.
		 *
		 * @param string $html Rendered general-block-email.php HTML.
		 * @return string
		 */
		protected function append_block_woo_additional_content( $html ) {
			$additional_content = $this->get_additional_content();
			if ( '' === $additional_content ) {
				return $html;
			}

			return $html . wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
		}

		/**
		 * get_content_html function.
		 *
		 * @return string
		 */
		public function get_content_html() {
			ob_start();
			wc_get_template(
				$this->template_html,
				$this->get_template_args( false ),
				'woocommerce-appointments',
				$this->template_base
			);

			return ob_get_clean();
		}

		/**
		 * get_content_plain function.
		 *
		 * @return string
		 */
		public function get_content_plain() {
			ob_start();
			wc_get_template(
				$this->template_plain,
				$this->get_template_args( true ),
				'woocommerce-appointments',
				$this->template_base
			);

			return ob_get_clean();
		}

		/**
		 * @param bool $plain_text Plain text email.
		 * @return array<string, mixed>
		 */
		protected function get_template_args( $plain_text ) {
			$wc_order = ( $this->appointment_series && $this->appointment_series->get_order_id() > 0 )
				? wc_get_order( $this->appointment_series->get_order_id() )
				: null;

			return array(
				'appointment_series'  => $this->appointment_series,
				'series_kind'           => $this->series_kind,
				'affected_appointments' => $this->affected_appointments,
				'email_heading'         => $this->get_heading(),
				'additional_content'    => $this->get_additional_content(),
				'sent_to_admin'         => false,
				'plain_text'            => $plain_text,
				'email'                 => $this,
				'text_align'            => is_rtl() ? 'right' : 'left',
				'wc_order'              => $wc_order,
			);
		}

		/**
		 * Initialise settings form fields.
		 */
		public function init_form_fields() {
			$this->form_fields = [
				'enabled'               => [
					'title'   => __( 'Enable/Disable', 'woocommerce-appointments' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable this email notification', 'woocommerce-appointments' ),
					'default' => 'yes',
				],
				'delivery_mode'         => [
					'title'       => __( 'Delivery mode', 'woocommerce-appointments' ),
					'type'        => 'select',
					'description' => __( 'One email per package, or one per appointment (legacy).', 'woocommerce-appointments' ),
					'default'     => 'consolidated',
					'class'       => 'wc-enhanced-select',
					'options'     => [
						'consolidated'   => __( 'One email per series (recommended)', 'woocommerce-appointments' ),
						'per_occurrence' => __( 'One email per appointment (legacy)', 'woocommerce-appointments' ),
					],
					'desc_tip'    => true,
				],
				'subject'               => [
					'title'       => __( 'Subject', 'woocommerce-appointments' ),
					'type'        => 'text',
					/* translators: %s: list of placeholders */
					'description' => sprintf( __( 'Available placeholders: %s', 'woocommerce-appointments' ), '<code>{site_title}, {product_title}, {appointment_series_id}, {appointment_series_pattern}, {appointment_series_session_count}, {appointment_series_scope}, {appointment_series_new_status}, {order_date}, {order_number}</code>' ),
					'placeholder' => $this->get_default_subject(),
					'default'     => '',
					'desc_tip'    => true,
				],
				'heading'               => [
					'title'       => __( 'Email Heading', 'woocommerce-appointments' ),
					'type'        => 'text',
					'placeholder' => $this->get_default_heading(),
					'default'     => '',
					'desc_tip'    => true,
				],
				'additional_content'    => [
					'title'       => __( 'Additional Content', 'woocommerce-appointments' ),
					'type'        => 'textarea',
					'description' => __( 'Shown below appointment details (and the order table when included).', 'woocommerce-appointments' ),
					'css'         => 'width:400px; height: 75px;',
					'placeholder' => $this->get_default_additional_content(),
					'default'     => '',
					'desc_tip'    => true,
				],
				'bcc'                   => [
					'title'       => __( 'Admin & staff recipients (BCC)', 'woocommerce-appointments' ),
					'type'        => 'text',
					/* translators: %s: WP admin email */
					'description' => sprintf( __( 'Comma-separated addresses notified in addition to the customer (BCC). Defaults to %s; assigned staff for the package are always included.', 'woocommerce-appointments' ), '<code>' . esc_html( get_option( 'admin_email' ) ) . '</code>' ),
					'placeholder' => get_option( 'admin_email' ),
					'default'     => get_option( 'admin_email' ),
					'desc_tip'    => true,
				],
				'ics_enabled'           => [
					'title'   => __( 'Calendar invite (.ics)', 'woocommerce-appointments' ),
					'type'    => 'checkbox',
					'label'   => __( 'Attach multi-event .ics on package created', 'woocommerce-appointments' ),
					'default' => 'yes',
				],
				'email_type'            => [
					'title'       => __( 'Email type', 'woocommerce-appointments' ),
					'type'        => 'select',
					'description' => __( 'Choose which format of email to send.', 'woocommerce-appointments' ),
					'default'     => 'html',
					'class'       => 'email_type wc-enhanced-select',
					'options'     => $this->get_email_type_options(),
					'desc_tip'    => true,
				],
			];
		}
	}

endif;

return new WC_Email_Appointment_Series();
