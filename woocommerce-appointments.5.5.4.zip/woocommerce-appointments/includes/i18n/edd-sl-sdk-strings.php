<?php
/**
 * Reference strings for the bundled EDD Software Licensing SDK.
 *
 * These calls are never executed. They only exist to expose the SDK's UI
 * strings to the plugin's text domain so tools like wp i18n make-pot can
 * include them for translators.
 */

if ( get_option( 'woocommerce_appointments_edd_sl_sdk_i18n_reference' ) ) {
	/* translators: %s: license expiration date. */
	__( 'Your license key expired on %s. Please renew your license key.', 'woocommerce-appointments' );

	__( 'Your license key has been disabled.', 'woocommerce-appointments' );
	__( 'Invalid license. Please verify it.', 'woocommerce-appointments' );
	__( 'Your license key is not active for this URL.', 'woocommerce-appointments' );

	/* translators: %s: the extension name. */
	__( 'This appears to be an invalid license key for %s.', 'woocommerce-appointments' );

	__( 'This appears to be an invalid license key.', 'woocommerce-appointments' );
	__( 'Your license key has reached its activation limit.', 'woocommerce-appointments' );
	__( 'The key you entered belongs to a bundle, please use the product specific license key.', 'woocommerce-appointments' );
	__( 'Your license key has been deactivated.', 'woocommerce-appointments' );
	__( 'Unlicensed: currently not receiving updates.', 'woocommerce-appointments' );
	__( 'License key never expires.', 'woocommerce-appointments' );

	/* translators: %s: the license expiration date. */
	__( 'Your license key expires soon! It expires on %s.', 'woocommerce-appointments' );

	/* translators: %s: the license expiration date. */
	__( 'Your license key expires on %s.', 'woocommerce-appointments' );

	__( 'Unknown date', 'woocommerce-appointments' );
	__( 'Activate', 'woocommerce-appointments' );
	__( 'Deactivate', 'woocommerce-appointments' );
	__( 'Delete', 'woocommerce-appointments' );
	__( 'You do not have permission to manage this license.', 'woocommerce-appointments' );
	__( 'You do not have permission to manage this setting.', 'woocommerce-appointments' );
	__( 'There was an error activating your license. Please try again.', 'woocommerce-appointments' );
	__( 'Your license was successfully activated.', 'woocommerce-appointments' );
	__( 'There was an error deactivating your license. Please try again.', 'woocommerce-appointments' );
	__( 'Your license was successfully deactivated.', 'woocommerce-appointments' );
	__( 'Your license was successfully deleted.', 'woocommerce-appointments' );
	__( 'Data tracking has been enabled.', 'woocommerce-appointments' );
	__( 'Data tracking has been disabled.', 'woocommerce-appointments' );
	__( 'Activating...', 'woocommerce-appointments' );
	__( 'Deactivating...', 'woocommerce-appointments' );
	__( 'An unknown error occurred.', 'woocommerce-appointments' );
	__( 'Dismiss notice', 'woocommerce-appointments' );

	/* translators: %s: item name */
	__( 'License key for %s:', 'woocommerce-appointments' );

	__( 'Allow the licensing API to collect usage data about your site, such as the PHP and WordPress versions.', 'woocommerce-appointments' );
	__( 'Theme License', 'woocommerce-appointments' );
	__( 'Manage License', 'woocommerce-appointments' );

	/* translators: %s: plugin name */
	__( 'There is a new version of %s available.', 'woocommerce-appointments' );

	__( 'Contact your network administrator to install the update.', 'woocommerce-appointments' );

	/* translators: %s: version number */
	__( 'View version %s details', 'woocommerce-appointments' );

	__( 'Update now', 'woocommerce-appointments' );

	/* translators: 1. opening anchor tag, do not translate 2. the new plugin version 3. closing anchor tag, do not translate 4. opening anchor tag, do not translate 5. closing anchor tag, do not translate */
	__( '%1$sView version %2$s details%3$s or %4$supdate now%5$s.', 'woocommerce-appointments' );
}











