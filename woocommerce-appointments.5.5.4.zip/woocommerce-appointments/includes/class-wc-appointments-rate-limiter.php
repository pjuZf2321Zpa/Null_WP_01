<?php
/**
 * Rate Limiter for WooCommerce Appointments.
 *
 * Provides rate limiting functionality for public AJAX endpoints to prevent abuse.
 *
 * @package WooCommerce Appointments
 * @since   5.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Rate_Limiter class.
 *
 * Handles rate limiting for public-facing AJAX endpoints to prevent
 * denial of service attacks and resource exhaustion.
 */
class WC_Appointments_Rate_Limiter {

	/**
	 * Default maximum requests per window.
	 * Set high enough to handle moderate traffic (multiple users browsing simultaneously).
	 *
	 * @var int
	 */
	const DEFAULT_MAX_REQUESTS = 60;

	/**
	 * Default time window in seconds.
	 *
	 * @var int
	 */
	const DEFAULT_WINDOW_SECONDS = 60;

	/**
	 * Stricter limit for failed/suspicious requests.
	 *
	 * @var int
	 */
	const STRICT_MAX_REQUESTS = 20;

	/**
	 * Default guest read cap for storefront slot/cost AJAX (per window).
	 *
	 * @since 5.4.3
	 *
	 * @var int
	 */
	const GUEST_READ_MAX_REQUESTS = 30;

	/**
	 * Stricter guest cap when a stale optional nonce is posted.
	 *
	 * @since 5.4.3
	 *
	 * @var int
	 */
	const GUEST_READ_STRICT_MAX_REQUESTS = 10;

	/**
	 * Default guest read window for storefront slot/cost AJAX (seconds).
	 *
	 * @since 5.4.3
	 *
	 * @var int
	 */
	const GUEST_READ_WINDOW_SECONDS = 60;

	/**
	 * Guest cap per minute for public REST reads (slots, availability index).
	 * Generous: headless storefronts polling from one IP stay well under it.
	 *
	 * @since 5.5.0
	 *
	 * @var int
	 */
	const REST_PUBLIC_READ_MAX_REQUESTS = 120;

	/**
	 * Check if the current request is within rate limits.
	 *
	 * Returns true if the request is allowed, false if rate limit exceeded.
	 * Automatically increments the request counter.
	 *
	 * @since 5.2.0
	 *
	 * @param string $context        Unique context identifier (e.g., 'calculate_costs', 'get_slots').
	 * @param int    $max_requests   Maximum requests allowed in the time window.
	 * @param int    $window_seconds Time window in seconds.
	 *
	 * @return bool True if request is allowed, false if rate limited.
	 */
	public static function check( string $context, int $max_requests = self::DEFAULT_MAX_REQUESTS, int $window_seconds = self::DEFAULT_WINDOW_SECONDS ): bool {
		// Authenticated users with appropriate capabilities bypass rate limiting.
		if ( is_user_logged_in() && current_user_can( 'edit_appointments' ) ) {
			return true;
		}

		/**
		 * Disable rate limiting for a context (e.g. staging, load tests).
		 *
		 * @since 5.4.3
		 *
		 * @param bool   $enabled  Whether limiting is active.
		 * @param string $context  Rate limit context identifier.
		 */
		if ( ! apply_filters( 'wc_appointments_rate_limit_enabled', true, $context ) ) {
			return true;
		}

		// Check IP whitelist.
		$client_ip = self::get_client_ip();
		if ( self::is_whitelisted( $client_ip ) ) {
			return true;
		}

		/**
		 * Filter the maximum requests allowed for a specific context.
		 *
		 * @since 5.2.0
		 *
		 * @param int    $max_requests Maximum requests allowed.
		 * @param string $context      Rate limit context identifier.
		 */
		$max_requests = (int) apply_filters( 'wc_appointments_rate_limit_max_requests', $max_requests, $context );

		/**
		 * Filter the time window for rate limiting.
		 *
		 * @since 5.2.0
		 *
		 * @param int    $window_seconds Time window in seconds.
		 * @param string $context        Rate limit context identifier.
		 */
		$window_seconds = (int) apply_filters( 'wc_appointments_rate_limit_window', $window_seconds, $context );

		// Get client identifier (IP + user agent hash for better accuracy).
		$client_id = self::get_client_identifier();
		$rate_key  = 'wca_rate_' . $context . '_' . $client_id;

		// Get current request count.
		$requests = (int) get_transient( $rate_key );

		// Check if limit exceeded.
		if ( $requests >= $max_requests ) {
			// Log rate limit hit for monitoring (only if WC logging is available).
			if ( function_exists( 'wc_get_logger' ) && apply_filters( 'wc_appointments_debug_rate_limit_logging', WC_APPOINTMENTS_DEBUG ) ) {
				$logger = wc_get_logger();
				$logger->warning(
					sprintf(
						'Rate limit exceeded for context "%s" from client %s. Requests: %d/%d',
						$context,
						self::get_client_ip(),
						$requests,
						$max_requests
					),
					[ 'source' => 'wc-appointments-rate-limiter' ]
				);
			}
			return false;
		}

		// Increment counter.
		set_transient( $rate_key, $requests + 1, $window_seconds );

		return true;
	}

	/**
	 * Apply rate limiting and send error response if limit exceeded.
	 *
	 * Convenience method that checks rate limit and immediately sends
	 * a 429 Too Many Requests response if limit is exceeded.
	 *
	 * @since 5.2.0
	 *
	 * @param string $context        Unique context identifier.
	 * @param int    $max_requests   Maximum requests allowed.
	 * @param int    $window_seconds Time window in seconds.
	 *
	 * @return void Exits with JSON error if rate limited.
	 */
	public static function throttle( string $context, int $max_requests = self::DEFAULT_MAX_REQUESTS, int $window_seconds = self::DEFAULT_WINDOW_SECONDS ): void {
		if ( ! self::check( $context, $max_requests, $window_seconds ) ) {
			self::deny();
		}
	}

	/**
	 * Apply guest-only rate limiting for read-only storefront AJAX, with optional stricter limits when a stale nonce is sent.
	 *
	 * Logged-in users (including customers without edit_appointments) are not throttled here.
	 * When a nonce is present but invalid, all callers get the strict limit — same as before.
	 *
	 * @since 5.4.3
	 *
	 * @param string $context         Rate limit context for guests.
	 * @param int    $max_requests    Guest request cap per window.
	 * @param int    $window_seconds  Window length in seconds.
	 * @param string $nonce_action    Nonce action to verify when `security` is posted (empty = skip).
	 * @param string $strict_context  Stricter context when nonce verification fails.
	 */
	public static function throttle_guest_read_with_optional_nonce(
		string $context,
		int $max_requests = self::GUEST_READ_MAX_REQUESTS,
		int $window_seconds = self::GUEST_READ_WINDOW_SECONDS,
		string $nonce_action = '',
		string $strict_context = ''
	): void {
		/**
		 * Limit storefront read AJAX to guests only (default true).
		 *
		 * When false, logged-in customers are throttled too (staff with `edit_appointments` still bypass via `check()`).
		 *
		 * @since 5.4.3
		 *
		 * @param bool   $guest_only True to throttle guests only.
		 * @param string $context    Rate limit context identifier.
		 */
		$guest_only = (bool) apply_filters( 'wc_appointments_rate_limit_guest_only', true, $context );

		if ( $guest_only ? ! is_user_logged_in() : true ) {
			self::throttle( $context, $max_requests, $window_seconds );
		}

		if ( '' === $nonce_action ) {
			return;
		}

		$security = isset( $_POST['security'] ) ? sanitize_text_field( wp_unslash( $_POST['security'] ) ) : '';
		if ( '' === $security ) {
			return;
		}

		if ( check_ajax_referer( $nonce_action, 'security', false ) ) {
			return;
		}

		$strict_context = '' !== $strict_context ? $strict_context : $context . '_strict';

		/**
		 * Filter the stricter cap applied when an optional nonce is present but invalid.
		 *
		 * @since 5.4.3
		 *
		 * @param int    $strict_max   Maximum requests in the strict window.
		 * @param string $context      Strict context identifier.
		 */
		$strict_max = (int) apply_filters( 'wc_appointments_rate_limit_strict_max_requests', self::GUEST_READ_STRICT_MAX_REQUESTS, $strict_context );

		self::throttle( $strict_context, $strict_max, $window_seconds );
	}

	/**
	 * REST permission callback for public read routes: throttle guests, never block staff.
	 *
	 * Staff with edit_appointments, whitelisted IPs, and the enable filter bypass
	 * via check(). Logged-in customers get their own per-user counter. Cap and window are
	 * filterable with wc_appointments_rate_limit_max_requests / _window using the given context.
	 *
	 * @since 5.5.0
	 *
	 * @param string $context Rate limit context (e.g. 'rest_slots').
	 * @return true|WP_Error
	 */
	public static function rest_permission( string $context ) {
		if ( self::check( $context, self::REST_PUBLIC_READ_MAX_REQUESTS, self::DEFAULT_WINDOW_SECONDS ) ) {
			return true;
		}

		return new WP_Error(
			'rate_limit_exceeded',
			__( 'Too many requests. Please try again later.', 'woocommerce-appointments' ),
			[ 'status' => 429 ]
		);
	}

	/**
	 * Send rate limit exceeded response and exit.
	 *
	 * @since 5.2.0
	 *
	 * @return void Never returns - exits with JSON error.
	 */
	public static function deny(): void {
		status_header( 429 );
		wp_send_json_error(
			[
				'message' => __( 'Too many requests. Please try again later.', 'woocommerce-appointments' ),
				'code'    => 'rate_limit_exceeded',
			],
			429
		);
	}

	/**
	 * Get a unique client identifier.
	 *
	 * Combines IP address with a hash of the user agent for better
	 * identification while maintaining some privacy.
	 *
	 * @since 5.2.0
	 *
	 * @return string MD5 hash of client identifier.
	 */
	private static function get_client_identifier(): string {
		$ip         = self::get_client_ip();
		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

		// For logged-in users, include user ID for more accurate tracking.
		$user_id = get_current_user_id();
		if ( $user_id ) {
			return md5( $ip . $user_agent . $user_id );
		}

		return md5( $ip . $user_agent );
	}

	/**
	 * Get the client IP address.
	 *
	 * Handles common proxy headers while preventing spoofing.
	 *
	 * @since 5.2.0
	 *
	 * @return string Client IP address.
	 */
	private static function get_client_ip(): string {
		$ip = '';

		// Check for CloudFlare.
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
		}
		// Check for proxy headers (only trust if behind known proxy).
		elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			// Take the first IP in the chain (original client).
			$ips = explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) );
			$ip  = trim( $ips[0] );
		}
		// Check for real IP header.
		elseif ( ! empty( $_SERVER['HTTP_X_REAL_IP'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_REAL_IP'] ) );
		}
		// Fall back to remote address.
		elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}

		// Validate IP format.
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$ip = '0.0.0.0';
		}

		return $ip;
	}

	/**
	 * Check if an IP is whitelisted from rate limiting.
	 *
	 * Allows administrators to whitelist specific IPs via filter.
	 *
	 * @since 5.2.0
	 *
	 * @param string $ip IP address to check.
	 *
	 * @return bool True if whitelisted.
	 */
	public static function is_whitelisted( string $ip ): bool {
		/**
		 * Filter the list of whitelisted IPs that bypass rate limiting.
		 *
		 * @since 5.2.0
		 *
		 * @param array $whitelist Array of IP addresses or CIDR ranges.
		 */
		$whitelist = apply_filters( 'wc_appointments_rate_limit_whitelist', [] );

		if ( empty( $whitelist ) ) {
			return false;
		}

		foreach ( $whitelist as $allowed ) {
			// Check for exact match.
			if ( $ip === $allowed ) {
				return true;
			}

			// Check for CIDR range match.
			if ( strpos( $allowed, '/' ) !== false && self::ip_in_range( $ip, $allowed ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if an IP is within a CIDR range.
	 *
	 * @since 5.2.0
	 *
	 * @param string $ip   IP address to check.
	 * @param string $cidr CIDR notation range (e.g., '192.168.1.0/24').
	 *
	 * @return bool True if IP is within range.
	 */
	private static function ip_in_range( string $ip, string $cidr ): bool {
		list( $subnet, $mask ) = explode( '/', $cidr );

		// Convert to binary format for comparison.
		$ip_binary     = sprintf( '%032b', ip2long( $ip ) );
		$subnet_binary = sprintf( '%032b', ip2long( $subnet ) );

		return substr_compare( $ip_binary, $subnet_binary, 0, (int) $mask ) === 0;
	}

	/**
	 * Clear rate limit for a specific context and client.
	 *
	 * Useful for testing or when a client has been verified as legitimate.
	 *
	 * @since 5.2.0
	 *
	 * @param string $context Unique context identifier.
	 *
	 * @return bool True on success.
	 */
	public static function clear( string $context ): bool {
		$client_id = self::get_client_identifier();
		$rate_key  = 'wca_rate_' . $context . '_' . $client_id;

		return delete_transient( $rate_key );
	}

	/**
	 * Get the remaining requests for a context.
	 *
	 * @since 5.2.0
	 *
	 * @param string $context      Unique context identifier.
	 * @param int    $max_requests Maximum requests allowed.
	 *
	 * @return int Number of remaining requests.
	 */
	public static function get_remaining( string $context, int $max_requests = self::DEFAULT_MAX_REQUESTS ): int {
		if ( ! apply_filters( 'wc_appointments_rate_limit_enabled', true, $context ) ) {
			return $max_requests;
		}

		$guest_only = (bool) apply_filters( 'wc_appointments_rate_limit_guest_only', true, $context );
		if ( $guest_only && is_user_logged_in() && ! current_user_can( 'edit_appointments' ) ) {
			return $max_requests;
		}

		$max_requests = (int) apply_filters( 'wc_appointments_rate_limit_max_requests', $max_requests, $context );

		$client_id = self::get_client_identifier();
		$rate_key  = 'wca_rate_' . $context . '_' . $client_id;
		$requests  = (int) get_transient( $rate_key );

		return max( 0, $max_requests - $requests );
	}
}
