<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Cart_Manager class.
 */
class WC_Appointment_Cart_Manager {
	use WC_Appointments_Manager_Trait;
	use WC_Appointment_Cart_Recurring_Trait;

	/**
	 * The class id used for identification in logging.
	 *
	 * @var string
	 */
	public string $id = 'wc_appointment_cart_manager';

	/**
	 * Constructor
	 */
	public function __construct() {
		if ( $this->is_active() ) {
			$this->register_hooks();
		}
	}

	/**
	 * Register WordPress hooks for this manager.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'woocommerce_before_add_to_cart_button', [ $this, 'add_product_object' ], 0 );
		add_action( 'woocommerce_before_appointment_form_output', [ $this, 'add_product_object' ], 0 );
		add_action( 'woocommerce_after_appointment_form_output', [ $this, 'add_product_object' ], 0 );
		add_action( 'woocommerce_appointment_add_to_cart', [ $this, 'add_to_cart' ], 30 );
		add_filter( 'woocommerce_cart_item_quantity', [ $this, 'cart_item_quantity' ], 15, 3 );
		add_filter( 'woocommerce_add_cart_item', [ $this, 'add_cart_item' ], 9, 1 ); #9 to allow others to hook after.
		add_filter( 'woocommerce_get_cart_item_from_session', [ $this, 'get_cart_item_from_session' ], 9, 3 ); #9 to allow others to hook after.
		add_action( 'woocommerce_cart_loaded_from_session', [ $this, 'cart_loaded_from_session' ], 10 );
		add_filter( 'woocommerce_get_item_data', [ $this, 'get_item_data' ], 10, 2 );
		add_filter( 'woocommerce_add_cart_item_data', [ $this, 'add_cart_item_data' ], 10, 2 );
		add_action( 'woocommerce_new_order_item', [ $this, 'order_item_meta' ], 50, 2 );
		add_action( 'woocommerce_store_api_checkout_order_processed', [ $this, 'review_items_on_block_checkout' ], 10, 1 );
		add_action( 'woocommerce_checkout_order_processed', [ $this, 'review_items_on_shortcode_checkout' ], 10, 1 );
		add_filter( 'woocommerce_add_to_cart_validation', [ $this, 'validate_appointment_posted_data' ], 10, 3 );
		add_filter( 'woocommerce_add_to_cart_validation', [ $this, 'validate_appointment_requires_confirmation' ], 20, 2 );
		add_filter( 'woocommerce_add_to_cart_validation', [ $this, 'validate_appointment_sold_individually' ], 20, 3 );
		add_filter( 'woocommerce_store_api_product_quantity_editable', [ $this, 'disable_cart_block_qty_field' ], 10, 3 );
		add_action( 'woocommerce_after_checkout_validation', [ $this, 'validate_appointment_order_legacy_checkout' ], 999, 2 );
		add_action( 'woocommerce_store_api_cart_errors', [ $this, 'validate_appointment_order_checkout_block_support' ], 999, 2 );
		add_action( 'woocommerce_cart_item_removed', [ $this, 'cart_item_removed' ], 20 );
		add_action( 'woocommerce_cart_item_restored', [ $this, 'cart_item_restored' ], 20 );
		add_action( 'woocommerce_before_cart_emptied', [ $this, 'release_cart_hold_appointments' ], 5, 1 );

		if ( 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ) ) {
			add_filter( 'woocommerce_add_to_cart_redirect', [ $this, 'add_to_cart_redirect' ] );
		}

		add_filter( 'woocommerce_product_add_to_cart_url', [ $this, 'woocommerce_product_link_querystring' ], 10, 2 );
		add_filter( 'woocommerce_loop_product_link', [ $this, 'woocommerce_product_link_querystring' ], 10, 2 );

		// Recurring series classes load after this file; defer hook registration to `init`.
		add_action( 'init', array( $this, 'register_recurring_cart_hooks' ), 20 );
	}

	/**
	 * Add product object when global variable is missing.
	 *
	 * Ensures the global $product variable is set by checking $GLOBALS['product']
	 * if the global is not available. Used to maintain product context in various hooks.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function add_product_object(): void {
		global $product;

		if ( ! $product && isset( $GLOBALS['product'] ) ) {
			$product = $GLOBALS['product'];
		}
	}

	/**
	 * Add to cart for appointments.
	 *
	 * Outputs the appointment booking form template for adding appointments to cart.
	 * Creates a WC_Appointment_Form instance and renders the appointment form.
	 *
	 * @since 1.0.0
	 *
	 * @return void Outputs HTML template.
	 */
	public function add_to_cart(): void {
		global $product;

		// Prepare form
		$appointment_form = new WC_Appointment_Form( $product );

		// Get template
		wc_get_template(
			'single-product/add-to-cart/appointment.php',
			[
				'appointment_form' => $appointment_form,
			],
			'woocommerce-appointments',
			WC_APPOINTMENTS_TEMPLATE_PATH
		);
	}

	/**
	 * Detect whether the current request is a cart simulation that must not
	 * create real appointment DB records.
	 *
	 * Many payment processors (PayPal, Afterpay, Stripe, etc.) simulate the
	 * customer's cart server-side to compute totals, taxes, or shipping before
	 * the customer clicks pay. They run the full WooCommerce add-to-cart pipeline
	 * and then immediately discard every item they added. If our plugin creates a
	 * real `WC_Appointment` row during that pipeline, the row is set to
	 * `was-in-cart` milliseconds later, but — when indexing is enabled — the
	 * availability cache retains the stale `in-cart` entry, falsely consuming a
	 * slot and causing phantom overbooking blocks.
	 *
	 * Third-party plugins can:
	 * - Add their wc-ajax action name to `wc_appointments_cart_simulation_ajax_actions`
	 * - Add a REST path fragment to `wc_appointments_cart_simulation_rest_paths`
	 * - Return true from the `wc_appointments_is_cart_simulation` boolean filter
	 *
	 * @since 5.2.5
	 *
	 * @return bool True when appointment creation must be skipped.
	 */
	public static function is_cart_simulation_request(): bool {
		/**
		 * Filterable list of wc-ajax action names that indicate a cart simulation.
		 *
		 * @since 5.2.5
		 *
		 * @param string[] $actions Known simulation action names.
		 */
		$simulation_ajax_actions = (array) apply_filters(
			'wc_appointments_cart_simulation_ajax_actions',
			[
				// WooCommerce PayPal Payments (non-simulate actions; simulate-* matched below).
				'ppc-create-order',
				'ppc-approve-order',
			]
		);

		$wc_ajax = isset( $_REQUEST['wc-ajax'] ) ? sanitize_key( wp_unslash( $_REQUEST['wc-ajax'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		// Substring covers ppc-simulate-cart, ppc-sdk-v6-simulate-cart, and future renames.
		if ( $wc_ajax && ( in_array( $wc_ajax, $simulation_ajax_actions, true ) || false !== strpos( $wc_ajax, 'simulate-cart' ) ) ) {
			return true;
		}

		/**
		 * Filterable list of REST URI path fragments that indicate a cart simulation.
		 *
		 * @since 5.2.5
		 *
		 * @param string[] $paths URI fragments (substring match).
		 */
		$simulation_rest_paths = (array) apply_filters(
			'wc_appointments_cart_simulation_rest_paths',
			[
				// WooCommerce Store API simulate endpoint (used by various payment gateways).
				'/wc/store/v1/cart/simulate',
			]
		);

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		foreach ( $simulation_rest_paths as $path ) {
			if ( '' !== $path && false !== strpos( $request_uri, $path ) ) {
				return true;
			}
		}

		/**
		 * Final boolean override: any plugin can signal simulation mode.
		 *
		 * @since 5.2.5
		 *
		 * @param bool $is_simulation Whether this is a simulation request.
		 */
		return (bool) apply_filters( 'wc_appointments_is_cart_simulation', false );
	}

	/**
	 * Make appointment quantity in cart readonly.
	 *
	 * Replaces the quantity input field with a hidden input for appointment cart items,
	 * making the quantity read-only since appointment quantities are set during booking.
	 *
	 * @since 1.0.0
	 *
	 * @param string $product_quantity Original quantity HTML.
	 * @param string $cart_item_key    Cart item key.
	 *
	 * @return string Modified quantity HTML with hidden input for appointments, or original HTML for other products.
	 */
	public function cart_item_quantity( string $product_quantity, string $cart_item_key ): string {
		$cart_item = WC()->cart->get_cart_item( $cart_item_key );
		if (! empty( $cart_item['appointment'] ) && ! empty( $cart_item['appointment']['_qty'] )) {
            return sprintf( '%1$s <input type="hidden" name="cart[%2$s][qty]" value="%1$s" />', $cart_item['quantity'], $cart_item_key );
        }

		return $product_quantity;
	}

	/**
	 * Adjust the price of the appointment product based on appointment properties.
	 *
	 * Modifies the cart item price based on appointment cost and quantity.
	 * Sets the product price to the appointment cost if specified in cart item data.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $cart_item Cart item array.
	 *
	 * @return array<string, mixed> Modified cart item array with adjusted price.
	 */
	public function add_cart_item( array $cart_item ): array {
		if ( ! empty( $cart_item['appointment'] ) && isset( $cart_item['appointment']['_cost'] ) && '' !== $cart_item['appointment']['_cost'] ) {
			$quantity = isset( $cart_item['appointment']['_qty'] ) && 0 !== $cart_item['appointment']['_qty'] ? $cart_item['appointment']['_qty'] : 1;
			$cart_item['data']->set_price( $cart_item['appointment']['_cost'] / $quantity );
		}

		return $cart_item;
	}

	/**
	 * Get data from the session and add to the cart item's meta.
	 *
	 * Restores appointment data from session when cart is loaded.
	 * Applies appointment pricing adjustments via add_cart_item().
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $cart_item     Cart item array.
	 * @param array<string, mixed> $values        Session values containing appointment data.
	 * @param string              $cart_item_key Cart item key.
	 *
	 * @return array<string, mixed> Cart item array with appointment data restored.
	 */
	public function get_cart_item_from_session( $cart_item, array $values, string $cart_item_key ): array {
		if ( ! empty( $values['wca_recurring'] ) && is_array( $values['wca_recurring'] ) ) {
			$cart_item['wca_recurring'] = $values['wca_recurring'];
		}

		if ( ! empty( $values['appointment'] ) ) {
			$cart_item['appointment'] = $values['appointment'];
			$cart_item                = $this->add_cart_item( $cart_item );
		}

		return $cart_item;
	}

	/**
	 * Mark in-cart appointment holds as was-in-cart when the cart is emptied (checkout or manual).
	 *
	 * @param WC_Cart|bool $cart Cart instance or legacy boolean flag.
	 */
	public function release_cart_hold_appointments( $cart ): void {
		if ( self::is_cart_simulation_request() ) {
			return;
		}

		$cart_obj = ( is_object( $cart ) && method_exists( $cart, 'get_cart' ) ) ? $cart : WC()->cart;
		if ( ! $cart_obj || ! method_exists( $cart_obj, 'get_cart' ) ) {
			return;
		}

		foreach ( $cart_obj->get_cart() as $cart_item ) {
			if ( empty( $cart_item['appointment'] ) ) {
				continue;
			}

			$appointment_id = wc_appointments_get_cart_item_hold_appointment_id( $cart_item );
			if ( $appointment_id > 0 ) {
				$appointment = get_wc_appointment( $appointment_id );
				if ( $appointment ) {
					$this->release_in_cart_hold( $appointment );
				}
			}
		}

		WC_Cache_Helper::get_transient_version( 'appointments', true );
	}

	/**
	 * Handle appointment cleanup when cart item is removed.
	 *
	 * @since 1.0.0
	 *
	 * @param string $cart_item_key Cart item key identifying which item was removed.
	 *
	 * @return void
	 */
	public function cart_item_removed( $cart_item_key ): void {
		// Simulation requests never create an appointment, so there is nothing to
		// transition here. Bail early to avoid a pointless DB lookup.
		if ( self::is_cart_simulation_request() ) {
			return;
		}

		$cart_item = WC()->cart->removed_cart_contents[ $cart_item_key ];

		if ( isset( $cart_item['appointment'] ) ) {
			$appointment_id = wc_appointments_get_cart_item_hold_appointment_id( $cart_item );
			if ( $appointment_id > 0 ) {
				$appointment = get_wc_appointment( $appointment_id );
				if ( $appointment ) {
					$this->release_in_cart_hold( $appointment );
				}
			}
			WC_Cache_Helper::get_transient_version( 'appointments', true );
		}
	}

	/**
	 * Restore appointment when cart item is restored.
	 *
	 * Cancels scheduled deletion and restores appointment status to 'in-cart'
	 * when a cart item is restored from removed state.
	 *
	 * @since 1.0.0
	 *
	 * @param string $cart_item_key Cart item key identifying which item was restored.
	 *
	 * @return void
	 */
	public function cart_item_restored( $cart_item_key ): void {
		$cart      = WC()->cart->get_cart();
		$cart_item = $cart[ $cart_item_key ];

		if ( isset( $cart_item['appointment'] ) ) {
			$appointment_id = wc_appointments_get_cart_item_hold_appointment_id( $cart_item );
			if ( $appointment_id > 0 ) {
				$appointment = get_wc_appointment( $appointment_id );
				if ( $appointment ) {
					$this->restore_in_cart_hold( $appointment );
				}
			}
			WC_Cache_Helper::get_transient_version( 'appointments', true );
		}
	}

	/**
	 * Schedule appointment to be deleted if inactive.
	 *
	 * Schedules an Action Scheduler event to remove the appointment from cart
	 * if the customer remains inactive for the specified hold stock time.
	 * Uses WooCommerce hold stock minutes setting (default 60 minutes).
	 *
	 * @since 1.0.0
	 *
	 * @param int $appointment_id Appointment ID to schedule removal for.
	 *
	 * @return void
	 */
	public function schedule_cart_removal( $appointment_id ): void {
		$hold_stock_minutes = (int) get_option( 'woocommerce_hold_stock_minutes', 60 );

		// Make sure appointments are cleared, regardless of WC stock options.
		if ( ! $hold_stock_minutes ) {
			$hold_stock_minutes = 60;
		}

		$minutes = apply_filters( 'woocommerce_appointments_remove_inactive_cart_time', $hold_stock_minutes );

		/**
		 * If this has been emptied, or set to 0, it will just exit. This means that in-cart appointments will need to be manually removed.
		 * Also take note that if the $minutes var is set to 5 or less, this means that it is possible for the in-cart appointment to be
		 * removed before the customer is able to check out.
		 */
		if ( empty( $minutes ) ) {
			return;
		}

		$timestamp = time() + MINUTE_IN_SECONDS * (int) $minutes;

		as_schedule_single_action( $timestamp, 'wc-appointment-remove-inactive-cart', [ $appointment_id ], 'wca' );
	}

	/**
	 * Check for invalid appointments when cart is loaded from session.
	 *
	 * @since 1.0.0
	 * @param WC_Cart $cart Cart object.
	 * @return void
	 */
	public function cart_loaded_from_session( $cart ) {
		if ( $cart->is_empty() ) {
			return;
		}

		$removed_titles   = [];
		$past_date_titles = [];
		$valid_statuses   = [
			'was-in-cart',
			'in-cart',
			'unpaid',
			'paid',
			'pending-confirmation',
			'wc-partial-payment',
			'partial-payment',
		];
		$paid_statuses    = apply_filters( 'woocommerce_appointments_paid_order_statuses', [ 'processing', 'completed', 'wc-partial-payment', 'partial-payment' ] );

		$did_remove = false;

		foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( ! empty( $cart_item['wca_recurring'] ) ) {
				continue;
			}

			$appointment_id = wc_appointments_get_cart_item_hold_appointment_id( $cart_item );
			if ( $appointment_id <= 0 ) {
				continue;
			}

			$removal_reason = $this->get_cart_session_hold_removal_reason( $appointment_id, $valid_statuses, $paid_statuses );
			if ( null === $removal_reason ) {
				continue;
			}

			unset( $cart->cart_contents[ $cart_item_key ] );
			$did_remove = true;

			$product_title = $this->get_cart_session_removed_product_title( $cart_item );
			if ( '' === $product_title ) {
				continue;
			}

			if ( 'remove_past_date' === $removal_reason ) {
				$past_date_titles[] = $product_title;
			} elseif ( 'remove_invalid' === $removal_reason ) {
				$removed_titles[] = $product_title;
			}
			// remove_order_linked: drop the zombie line quietly (already purchased / settled).
		}

		if ( $did_remove ) {
			// Reason helper releases in-cart → was-in-cart (unset skips cart_item_removed).
			WC_Cache_Helper::get_transient_version( 'appointments', true );
			$cart->calculate_totals();
		}

		if ( ! empty( $past_date_titles ) ) {
			$past_date_titles = array_unique( $past_date_titles );
			$message          = sprintf(
				/* translators: %s: list of product titles */
				_n( 'An appointment for %s has been removed from your cart because the appointment date has passed.', 'Appointments for %s have been removed from your cart because the appointment dates have passed.', count( $past_date_titles ), 'woocommerce-appointments' ),
				wc_format_list_of_items( $past_date_titles )
			);

			if ( ! wc_has_notice( $message, 'notice' ) ) {
				wc_add_notice( $message, 'notice' );
			}
		}

		if ( ! empty( $removed_titles ) ) {
			$removed_titles = array_unique( $removed_titles );
			$message        = sprintf(
				/* translators: %s: list of product titles */
				_n( 'An appointment for %s has been removed from your cart due to inactivity.', 'Appointments for %s have been removed from your cart due to inactivity.', count( $removed_titles ), 'woocommerce-appointments' ),
				wc_format_list_of_items( $removed_titles )
			);

			if ( ! wc_has_notice( $message, 'notice' ) ) {
				wc_add_notice( $message, 'notice' );
			}
		}
	}

	/**
	 * Decide whether a cart hold appointment should be removed when the session loads.
	 *
	 * When removing, releases still-`in-cart` holds to `was-in-cart` (session unset skips
	 * {@see cart_item_removed()}). When keeping, restores `was-in-cart` to `in-cart`.
	 * No-op for paid/cancelled/other statuses.
	 *
	 * @since 5.4.1
	 *
	 * @param int      $appointment_id Hold appointment ID.
	 * @param string[] $valid_statuses Appointment statuses that may remain in the cart.
	 * @param string[] $paid_statuses  Order statuses treated as already paid.
	 * @return null|'remove_invalid'|'remove_past_date'|'remove_order_linked' Null keeps the cart line.
	 */
	private function get_cart_session_hold_removal_reason( $appointment_id, $valid_statuses, $paid_statuses ) {
		clean_post_cache( $appointment_id );
		$appointment = get_wc_appointment( $appointment_id );

		if ( ! $appointment ) {
			if ( $this->cart_hold_appointment_exists_in_db( $appointment_id ) ) {
				return null;
			}

			return 'remove_invalid';
		}

		$this->maybe_recover_appointment_order_from_line_item( $appointment );

		$order_id = $appointment->get_order_id();
		if ( $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order || in_array( $order->get_status(), $paid_statuses, true ) || in_array( $order->get_status(), [ 'cancelled', 'failed', 'refunded', 'trash' ], true ) ) {
				$this->release_in_cart_hold( $appointment );
				return 'remove_order_linked';
			}

			$this->restore_in_cart_hold( $appointment );
			return null;
		}

		if ( ! $appointment->has_status( $valid_statuses ) ) {
			$this->release_in_cart_hold( $appointment );
			return 'remove_invalid';
		}

		if ( $this->cart_hold_appointment_start_is_past( $appointment ) ) {
			$this->release_in_cart_hold( $appointment );
			return 'remove_past_date';
		}

		$this->restore_in_cart_hold( $appointment );
		return null;
	}

	/**
	 * @since 5.4.1
	 *
	 * @param WC_Appointment $appointment Appointment hold.
	 * @return void
	 */
	private function release_in_cart_hold( $appointment ) {
		if ( $appointment->has_status( WC_Appointments_Constants::STATUS_IN_CART ) ) {
			$appointment->update_status( WC_Appointments_Constants::STATUS_WAS_IN_CART );
		}
	}

	/**
	 * @since 5.4.9
	 *
	 * @param WC_Appointment $appointment Appointment hold.
	 * @return void
	 */
	private function restore_in_cart_hold( $appointment ) {
		if ( $appointment->has_status( WC_Appointments_Constants::STATUS_WAS_IN_CART ) ) {
			$appointment->update_status( WC_Appointments_Constants::STATUS_IN_CART );
			$this->schedule_cart_removal( $appointment->get_id() );
		}
	}

	/**
	 * @since 5.4.1
	 *
	 * @param int $appointment_id Hold appointment ID.
	 * @return bool
	 */
	private function cart_hold_appointment_exists_in_db( $appointment_id ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE ID = %d AND post_type = 'wc_appointment'",
				$appointment_id
			)
		);
	}

	/**
	 * @since 5.4.1
	 *
	 * @param WC_Appointment $appointment Appointment hold.
	 * @return void
	 */
	private function maybe_recover_appointment_order_from_line_item( $appointment ) {
		if ( $appointment->get_order_id() || ! ( $order_item_id = $appointment->get_order_item_id() ) ) {
			return;
		}

		$order_id = 0;
		if ( function_exists( 'wc_get_order_id_by_order_item_id' ) ) {
			$order_id = wc_get_order_id_by_order_item_id( $order_item_id );
		} else {
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$order_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT order_id FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_id = %d",
					$order_item_id
				)
			);
		}

		if ( $order_id ) {
			$appointment->set_order_id( $order_id );
			$appointment->save();
		}
	}

	/**
	 * @since 5.4.1
	 *
	 * @param WC_Appointment $appointment Appointment hold.
	 * @return bool
	 */
	private function cart_hold_appointment_start_is_past( $appointment ) {
		$start = $appointment->get_start();
		if ( ! $start ) {
			return false;
		}

		$cutoff = $appointment->get_all_day()
			? strtotime( 'today', current_time( 'timestamp' ) )
			: current_time( 'timestamp' );

		return $start < $cutoff;
	}

	/**
	 * @since 5.4.1
	 *
	 * @param array<string, mixed> $cart_item Cart line.
	 * @return string Linked product title HTML or empty string.
	 */
	private function get_cart_session_removed_product_title( $cart_item ) {
		if ( empty( $cart_item['product_id'] ) ) {
			return '';
		}

		return sprintf(
			'<a href="%s">%s</a>',
			get_permalink( $cart_item['product_id'] ),
			get_the_title( $cart_item['product_id'] )
		);
	}

	/**
	 * Add posted data to the cart item.
	 *
	 * Processes appointment form data and adds it to cart item meta.
	 * Calculates appointment cost, creates appointment object, and schedules cart removal.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $cart_item_meta Cart item meta array.
	 * @param int                  $product_id     Product ID.
	 *
	 * @return array<string, mixed> Cart item meta array with appointment data added.
	 *
	 * @throws Exception If appointment cost calculation fails or appointment creation fails.
	 */
	public function add_cart_item_data( array $cart_item_meta, int $product_id ): array {
		$product = wc_get_product( $product_id );

		if ( ! is_wc_appointment_product( $product ) ) {
			return $cart_item_meta;
		}

		if ( WC_Appointment_Series_Request::is_recurring_request() ) {
			$appointment_product = WC_Product_Appointment::as_appointment_product( $product_id );
			if ( $appointment_product && $appointment_product->allows_recurring() ) {
				return $this->filter_recurring_cart_item_data( $cart_item_meta, $product_id );
			}
		}

		// Cart simulation requests (PayPal, Afterpay, Stripe express, etc.) run the
		// full add-to-cart pipeline and then discard every item immediately. Creating
		// a real appointment DB record here would leave a stale `was-in-cart` entry
		// that corrupts the availability index and causes phantom slot-blocking.
		// Return early with pricing data only — no DB write.
		if ( self::is_cart_simulation_request() ) {
			return $cart_item_meta;
		}

		$posted = $this->cart_post_unslashed();
		if ( ! array_key_exists( 'appointment', $cart_item_meta ) ) {
			$cart_item_meta['appointment'] = wc_appointments_get_posted_data( $posted, $product );
		}
		$cost = WC_Appointments_Cost_Calculation::calculate_appointment_cost( $posted, $product );

		if ( $cost instanceof WP_Error ) {
			throw new Exception( esc_html( $cost->get_error_message() ) );
		}

		$cost = (float) apply_filters( 'wc_appointments_cart_appointment_cost', $cost, $posted, $product );

		$cart_item_meta['appointment']['_cost'] = $cost;

		// Create the new appointment
		$new_appointment = $this->add_appointment_from_cart_data( $cart_item_meta, $product_id );

		// Handle errors from appointment creation (e.g., double-booking detected).
		if ( is_wp_error( $new_appointment ) ) {
			throw new Exception( $new_appointment->get_error_message() );
		}

		// Store in cart
		$cart_item_meta['appointment']['_appointment_id'] = $new_appointment->get_id();

		// Schedule this item to be removed from the cart if the user is inactive
		$this->schedule_cart_removal( $new_appointment->get_id() );

		return $cart_item_meta;
	}


	/**
	 * Create appointment from cart data.
	 *
	 * Creates a new appointment object from cart item data with booking lock protection.
	 * Uses exponential backoff retry if lock cannot be acquired initially.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $cart_item_meta Cart item meta containing appointment data.
	 * @param int                  $product_id     Product ID.
	 * @param string               $status         Optional. Initial appointment status. Default 'in-cart'.
	 *
	 * @return WC_Appointment|WP_Error Appointment object on success, WP_Error on failure (e.g., booking locked).
	 */
	private function add_appointment_from_cart_data( array $cart_item_meta, int $product_id, $status = 'in-cart' ) {
		// Use booking handler for appointment creation from cart data.
		$handler = new WC_Appointment_Booking_Handler();
		return $handler->create_from_cart_data( $cart_item_meta, $product_id, $status );
	}

	/**
	 * Put meta data into format which can be displayed.
	 *
	 * Formats appointment data for display in cart and checkout.
	 * Converts appointment metadata into human-readable key-value pairs.
	 *
	 * @since 1.0.0
	 *
	 * @param array<int, array<string, mixed>> $other_data Existing item data array.
	 * @param array<string, mixed>            $cart_item  Cart item array.
	 *
	 * @return array<int, array<string, mixed>> {
	 *     Array of item data arrays with 'name' and 'value' keys.
	 *
	 *     @type array{
	 *         name: string,
	 *         value: string
	 *     } $item_data Formatted appointment data for display.
	 * }
	 */
	public function get_item_data( $other_data, array $cart_item ): array {
		if ( empty( $cart_item['appointment'] ) ) {
			return $other_data;
		}

		$is_recurring = ! empty( $cart_item['wca_recurring'] );

		if ( ! empty( $cart_item['appointment']['_appointment_id'] ) ) {
			$appointment = get_wc_appointment( $cart_item['appointment']['_appointment_id'] );
		}

		// TIMEZONE (5.2.0): Check if customer timezone differs from site timezone.
		// Timezone is shown as a separate row (not appended to date/time) for cleaner display.
		$local_tz    = $cart_item['appointment']['_local_timezone'] ?? '';
		$site_tz     = wc_timezone_string();
		$show_tz_ui = class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'frontend', get_current_user_id() );
		$show_tz_row = $show_tz_ui && $local_tz && $local_tz !== $site_tz && function_exists( 'wc_appointment_get_timezone_name' );

		if ( ! empty( $cart_item['appointment'] ) ) {
			foreach ( $cart_item['appointment'] as $key => $value ) {
				if ( substr( $key, 0, 1 ) === '_' ) {
					continue;
				}
				// Recurring packages show sessions under "Recurring series" instead of anchor date/time.
				if ( $is_recurring && in_array( $key, array( 'date', 'time' ), true ) ) {
					continue;
				}
				$other_data[] = [
					'name'    => get_wc_appointment_data_label( $key, $cart_item['data'] ),
					'value'   => $value,
					'display' => '',
				];
			}

			// Add timezone as separate row if different from site timezone.
			if ( $show_tz_row ) {
				$at = null;
				if ( ! empty( $cart_item['appointment']['_start_date'] ) ) {
					try {
						$at = new DateTimeImmutable(
							date( 'Y-m-d H:i:s', (int) $cart_item['appointment']['_start_date'] ),
							new DateTimeZone( $site_tz )
						);
					} catch ( Exception $e ) {
						$at = null;
					}
				}
				$other_data[] = [
					'name'    => __( 'Time zone', 'woocommerce-appointments' ),
					'value'   => wc_appointment_get_timezone_name( $local_tz, true, $at ),
					'display' => '',
				];
			}
		}

		return $other_data;
	}

	/**
	 * Add appointment meta data to order item.
	 *
	 * Links appointment to order item when order is created.
	 * Updates appointment with order ID, order item ID, and customer ID.
	 * Handles draft orders specially to maintain 'in-cart' status during checkout block flow.
	 *
	 * @since 1.0.0
	 *
	 * @param int                    $item_id Order item ID.
	 * @param array<string, mixed>|object $values Cart item values (array) or order item object with legacy_values property.
	 *
	 * @return void
	 */
	public function order_item_meta( $item_id, $values ): void {
		$appointment_cost = 0;

		// Handle case where $values is an object (e.g., WC_Order_Item_Tax) instead of array
		if ( ! is_array( $values ) ) {
			// If it's an object with legacy_values, use that, otherwise skip
			if ( ! property_exists( $values, 'legacy_values' ) || empty( $values->legacy_values ) || ! is_array( $values->legacy_values ) ) {
				return;
			}
			$values = $values->legacy_values;
		}

		if ( ! empty( $values['appointment'] ) ) {
			if ( empty( $values['appointment']['_appointment_id'] ) ) {
				return;
			}

			$product          = $values['data'];
			$appointment_id   = $values['appointment']['_appointment_id'];
			$appointment_cost = (float) $values['appointment']['_cost'];
		}

		if ( isset( $appointment_id ) ) {
			$appointment = get_wc_appointment( $appointment_id );

			// Validate appointment object exists and is valid.
			if ( ! $appointment || ! is_a( $appointment, 'WC_Appointment' ) ) {
				if ( function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Failed to load appointment #%d for order item #%d', $appointment_id, $item_id ) );
				}
				return;
			}

			if ( function_exists( 'wc_get_order_id_by_order_item_id' ) ) {
				$order_id = wc_get_order_id_by_order_item_id( $item_id );
			}
			if ( empty( $order_id ) ) {
				global $wpdb;
				$order_id = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT order_id FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_id = %d",
						$item_id
					)
				);
			}

			// Validate order exists.
			if ( empty( $order_id ) ) {
				if ( function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Failed to get order ID for order item #%d', $item_id ) );
				}
				return;
			}

			$order = wc_get_order( $order_id );

			// Validate order object exists and is valid.
			if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
				if ( function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Failed to load order #%d for appointment #%d', $order_id, $appointment_id ) );
				}
				return;
			}

			$order_status = $order->get_status();

			// Testing.
			#error_log( var_export( 'Appointment ID', true ) );
			#error_log( var_export( $appointment_id, true ) );
			#error_log( var_export( 'Appointment Cost', true ) );
			#error_log( var_export( $appointment_cost, true ) );
			#error_log( var_export( 'Appointment Status', true ) );
			#error_log( var_export( $appointment->get_status(), true ) );
			#error_log( var_export( 'Order Status', true ) );
			#error_log( var_export( $order_status, true ) );

			$appointment->set_order_id( $order_id );
			$appointment->set_order_item_id( $item_id );
			if ( ! $appointment->get_customer_id() && $order->get_customer_id() ) {
				$appointment->set_customer_id( $order->get_customer_id() );
			}

			/**
			 * In this particular case, the status will be 'in-cart' as we don't want to change it
			 * before the actual order is done if we're dealing with the checkout blocks.
			 * The checkout block creates a draft order before it is then changes to another more final status.
			 * Later the woocommerce_blocks_checkout_order_processed hook is called and
			 * review_items_on_checkout runs to change the status of the appointment to their correct value.
			 */
			// For draft orders, keep appointments in a draft-like state unless they were removed.
			// If the appointment was already marked as 'was-in-cart' (removed), do not revert it.
			if ( 'checkout-draft' === $order_status && ! $appointment->has_status( WC_Appointments_Constants::STATUS_WAS_IN_CART ) ) {
				// Maintain 'in-cart' to avoid premature status changes during draft lifecycle.
				$appointment->set_status( WC_Appointments_Constants::STATUS_IN_CART );
			}

			// Save appointment with error handling and retry logic.
			$saved_appointment_id = null;
			$max_retries = 3;
			$retry_count = 0;

			while ( $retry_count < $max_retries ) {
				try {
					$saved_appointment_id = $appointment->save();

					// Verify the appointment was actually saved by checking if ID exists.
					if ( $saved_appointment_id && $saved_appointment_id > 0 ) {
						// Double-check the appointment exists in database.
						$verify_appointment = get_wc_appointment( $saved_appointment_id );
						if ( $verify_appointment && is_a( $verify_appointment, 'WC_Appointment' ) ) {
							// Successfully saved and verified.
							if ( $order->is_paid() && class_exists( 'WC_Appointments_Integration_Subscriptions_Cart' ) ) {
								WC_Appointments_Integration_Subscriptions_Cart::consume_credits_from_order( $order_id );
							}
							break;
						}
					}

					// If we get here, save didn't work properly.
					$retry_count++;
					if ( $retry_count < $max_retries ) {
						// Wait a brief moment before retrying (helps with race conditions).
						usleep( 100000 ); // 100ms
					}
				} catch ( Exception $e ) {
					$retry_count++;
					if ( function_exists( 'wc_add_appointment_log' ) ) {
						wc_add_appointment_log( $this->id, sprintf( 'Exception saving appointment #%d for order #%d (attempt %d/%d): %s', $appointment_id, $order_id, $retry_count, $max_retries, $e->getMessage() ) );
					}

					if ( $retry_count < $max_retries ) {
						// Wait before retrying.
						usleep( 100000 ); // 100ms
					} else {
						// Final attempt failed, log error and add order note.
						if ( function_exists( 'wc_add_appointment_log' ) ) {
							wc_add_appointment_log( $this->id, sprintf( 'CRITICAL: Failed to save appointment #%d for order #%d after %d attempts', $appointment_id, $order_id, $max_retries ) );
						}
						/* translators: %d: appointment ID. */
						$order->add_order_note( sprintf( __( 'Warning: Failed to save appointment #%d. Please check appointment manually.', 'woocommerce-appointments' ), $appointment_id ) );
					}
				}
			}

			// If save still failed after retries, try one more time with a fresh appointment object.
			if ( ! $saved_appointment_id || $saved_appointment_id <= 0 ) {
				try {
					// Reload appointment to get fresh state.
					$fresh_appointment = get_wc_appointment( $appointment_id );
					if ( $fresh_appointment && is_a( $fresh_appointment, 'WC_Appointment' ) ) {
						$fresh_appointment->set_order_id( $order_id );
						$fresh_appointment->set_order_item_id( $item_id );
						if ( ! $fresh_appointment->get_customer_id() && $order->get_customer_id() ) {
							$fresh_appointment->set_customer_id( $order->get_customer_id() );
						}
						if ( 'checkout-draft' === $order_status && ! $fresh_appointment->has_status( WC_Appointments_Constants::STATUS_WAS_IN_CART ) ) {
							$fresh_appointment->set_status( WC_Appointments_Constants::STATUS_IN_CART );
						}

						$saved_appointment_id = $fresh_appointment->save();
						if ( $saved_appointment_id && $saved_appointment_id > 0 ) {
							if ( $order->is_paid() && class_exists( 'WC_Appointments_Integration_Subscriptions_Cart' ) ) {
								WC_Appointments_Integration_Subscriptions_Cart::consume_credits_from_order( $order_id );
							}
							// Success - no logging needed for normal operations
						}
					}
				} catch ( Exception $e ) {
					if ( function_exists( 'wc_add_appointment_log' ) ) {
						wc_add_appointment_log( $this->id, sprintf( 'CRITICAL: Final retry failed for appointment #%d: %s', $appointment_id, $e->getMessage() ) );
					}
					/* translators: %d: appointment ID. */
					$order->add_order_note( sprintf( __( 'CRITICAL: Failed to save appointment #%d after all retry attempts. Manual intervention required.', 'woocommerce-appointments' ), $appointment_id ) );
				}
			}
		}
	}

	/**
	 * Redirects directly to the cart for products that need confirmation.
	 *
	 * Redirects users to the cart page when adding appointment products that require confirmation,
	 * instead of redirecting to the product page. Clears success notices to avoid confusion.
	 *
	 * @since 1.0.0
	 * @version 3.4.0
	 *
	 * @param string|false $url Original redirect URL (WC core passes false by default).
	 *
	 * @return string|false Cart URL if product requires confirmation, otherwise original URL.
	 */
	public function add_to_cart_redirect( $url ) {
		if ( isset( $_REQUEST['add-to-cart'] ) && is_numeric( $_REQUEST['add-to-cart'] ) && wc_appointment_requires_confirmation( intval( $_REQUEST['add-to-cart'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			// Remove add to cart messages only in case there's no error.
			$notices = wc_get_notices();
			if ( empty( $notices['error'] ) ) {
				wc_clear_notices();

				// Go to checkout.
				return wc_get_cart_url();
			}
		}

		return $url;
	}

	/**
	 * Add querystring to product link.
	 *
	 * Preserves appointment booking parameters (date, time, staff) in product permalinks
	 * when navigating from appointment calendar or other booking interfaces.
	 *
	 * @since 3.4.0
	 *
	 * @param string              $permalink Product permalink.
	 * @param WC_Product|object  $product   Product object.
	 *
	 * @return string Product permalink with appointment query parameters added.
	 */
	public function woocommerce_product_link_querystring( $permalink, $product ) {
		if ( ! is_wc_appointment_product( $product ) ) {
			return $permalink;
		}

		// Querystrings exist?
		$date  = sanitize_text_field( (string) filter_input( INPUT_GET, 'min_date' ) );
		$time  = sanitize_text_field( (string) filter_input( INPUT_GET, 'time' ) );
		$staff = sanitize_text_field( (string) filter_input( INPUT_GET, 'staff' ) );

		if ( $date ) {
			$permalink = add_query_arg( 'date', $date, $permalink );
		}
		if ( $time ) {
			$permalink = add_query_arg( 'time', $time, $permalink );
		}
		if ( $staff ) {
			$permalink = add_query_arg( 'staff', $staff, $permalink );
		}

		return apply_filters( 'woocommerce_appointment_get_permalink', $permalink, $this );
	}

	/**
	 * Remove all appointments that require confirmation from cart.
	 *
	 * Removes appointment products that require confirmation from the cart.
	 * Used when adding a non-confirmation product to maintain cart compatibility.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	protected function remove_appointment_that_requires_confirmation() {
		foreach ( WC()->cart->cart_contents as $item_key => $item ) {
			if ( wc_appointment_requires_confirmation( $item['product_id'] ) ) {
				WC()->cart->set_quantity( $item_key, 0 );
			}
		}
	}

	/**
	 * Review appointment items on block checkout.
	 *
	 * Updates appointment statuses when order is processed via WooCommerce Blocks checkout.
	 * Handles status transitions from 'in-cart' to appropriate status based on product requirements.
	 *
	 * @since 1.0.0
	 *
	 * @param WC_Order $order Order object.
	 *
	 * @return void
	 */
    public function review_items_on_block_checkout( $order ): void {
		$order_id = $order->get_id();

		if ( empty( $order_id ) ) {
			return;
		}

		if ( class_exists( 'WC_Deposits' ) || class_exists( 'Webtomizer\WCDP\WC_Deposits' ) ) {
			// Is this a final payment?
			$parent_id = wp_get_post_parent_id( $order_id );
			if ( ! empty( $parent_id ) ) {
				$order_id = $parent_id;
			}
		}

		$order        = wc_get_order( $order_id );
		$order_status = $order->get_status();

		$appointments = WC_Appointment_Data_Store::get_appointment_ids_from_order_id( $order_id );

		// Fallback: Check for order items that should have appointments but don't.
		$this->ensure_appointments_for_order_items( $order );

		foreach ( $appointments as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );

			// Skip if appointment doesn't exist or is invalid.
			if ( ! $appointment || ! is_a( $appointment, 'WC_Appointment' ) ) {
				if ( function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Invalid appointment #%d found for order #%d', $appointment_id, $order_id ) );
				}
				continue;
			}

			$product_id  = $appointment->get_product_id();
			if ( $product_id === 0 ) {
				continue;
			}

			// Skip appointments that were removed from cart.
			if ( $appointment->has_status( WC_Appointments_Constants::STATUS_WAS_IN_CART ) ) {
				continue;
			}

			/**
			 * We just want to deal with the appointments that we left forcibly on the 'in-cart' state
			 * and provide them the same state they would be if not using blocks.
			 */
			if ( ! wc_appointment_requires_confirmation( $product_id ) && ! in_array( $order_status, [ 'processing', 'completed' ], true ) ) {
				/**
				 * We need to bring the appointment status from the new in-cart status to unpaid if it doesn't require confirmation
				 */
				$appointment->set_status( 'unpaid' );
				$saved_id = $appointment->save();
				if ( (! $saved_id || $saved_id <= 0) && function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Failed to save appointment #%d status update for order #%d', $appointment_id, $order_id ) );
				}
			} elseif ( 'in-cart' === $appointment->get_status() && wc_appointment_requires_confirmation( $product_id ) ) {
				/**
				 * If the order is in cart and requires confirmation, we need to change this.
				 */
				$appointment->set_status( 'pending-confirmation' );
				$saved_id = $appointment->save();
				if ( (! $saved_id || $saved_id <= 0) && function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Failed to save appointment #%d status update for order #%d', $appointment_id, $order_id ) );
				}
			}
		}
	}

	/**
	 * Review appointment items on shortcode checkout.
	 *
	 * Updates appointment statuses when order is processed via shortcode checkout.
	 * Handles status transitions from 'in-cart' to appropriate status based on product requirements.
	 * Skips draft orders to avoid premature status changes.
	 *
	 * @since 1.0.0
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return void
	 */
    public function review_items_on_shortcode_checkout( $order_id ): void {
		if ( empty( $order_id ) ) {
			return;
		}

		if ( class_exists( 'WC_Deposits' ) || class_exists( 'Webtomizer\WCDP\WC_Deposits' ) ) {
			// Is this a final payment?
			$parent_id = wp_get_post_parent_id( $order_id );
			if ( ! empty( $parent_id ) ) {
				$order_id = $parent_id;
			}
		}

		/**
		 * We need to make sure we don't do anything to the appointment just yet because of the new checkout-draft status
		 * assigned by the checkout block when entering the checkout page.
		 */
		$order        = wc_get_order( $order_id );
		$order_status = $order->get_status();

		if ( 'checkout-draft' === $order_status ) {
			return;
		}

		$appointments = WC_Appointment_Data_Store::get_appointment_ids_from_order_id( $order_id );

		// Fallback: Check for order items that should have appointments but don't.
		$this->ensure_appointments_for_order_items( $order );

		foreach ( $appointments as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );

			// Skip if appointment doesn't exist or is invalid.
			if ( ! $appointment || ! is_a( $appointment, 'WC_Appointment' ) ) {
				if ( function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Invalid appointment #%d found for order #%d', $appointment_id, $order_id ) );
				}
				continue;
			}

			$product_id  = $appointment->get_product_id();

			if ( $product_id === 0 ) {
				continue;
			}

			// Skip appointments that were removed from cart.
			if ( $appointment->has_status( WC_Appointments_Constants::STATUS_WAS_IN_CART ) ) {
				continue;
			}

			if ( ! wc_appointment_requires_confirmation( $product_id ) && ! in_array( $order_status, [ 'processing', 'completed' ], true ) ) {
				/**
				 * We need to bring the appointment status from the new in-cart status to unpaid if it doesn't require confirmation
				 */
				$appointment->set_status( 'unpaid' );
				$saved_id = $appointment->save();
				if ( (! $saved_id || $saved_id <= 0) && function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Failed to save appointment #%d status update for order #%d', $appointment_id, $order_id ) );
				}
			} elseif ( 'in-cart' === $appointment->get_status() && wc_appointment_requires_confirmation( $product_id ) ) {
				/**
				 * If the order is in cart and requires confirmation, we need to change this.
				 */
				$appointment->set_status( 'pending-confirmation' );
				$saved_id = $appointment->save();
				if ( (! $saved_id || $saved_id <= 0) && function_exists( 'wc_add_appointment_log' ) ) {
					wc_add_appointment_log( $this->id, sprintf( 'Failed to save appointment #%d status update for order #%d', $appointment_id, $order_id ) );
				}
			}
		}
	}

	/**
	 * When an appointment is added to the cart, validate it.
	 *
	 * Validates the appointment data posted from the product page.
	 * Checks if the selected slots are still available and valid.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $passed     Whether validation passed so far.
	 * @param int  $product_id Product ID being added to cart.
	 * @param int  $qty        Quantity being added.
	 *
	 * @return bool True if validation passes, false otherwise (adds error notice).
	 */
	public function validate_appointment_posted_data( $passed, $product_id, $qty ) {
		$product = wc_get_product( $product_id );

		if ( ! is_wc_appointment_product( $product ) ) {
			return $passed;
		}

		if ( WC_Appointment_Series_Request::is_recurring_request() ) {
			$appointment_product = WC_Product_Appointment::as_appointment_product( $product_id );
			if ( $appointment_product && $appointment_product->allows_recurring() ) {
				return $passed;
			}
		}

		$posted   = $this->cart_post_unslashed();
		$data     = wc_appointments_get_posted_data( $posted, $product );
		$validate = $product->is_appointable( $data );

		if ( is_wp_error( $validate ) ) {
			wc_add_notice( $validate->get_error_message(), 'error' );
			return false;
		}

		return $passed;
	}

	/**
	 * Validate cart compatibility with confirmation requirements.
	 *
	 * Ensures cart cannot contain both appointment products that require confirmation
	 * and those that don't. Removes incompatible items and displays notices.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $passed    Whether validation passed so far.
	 * @param int  $product_id Product ID being added to cart.
	 *
	 * @return bool True if validation passes, false if items were removed (adds notice).
	 */
	public function validate_appointment_requires_confirmation( $passed, $product_id ) {
		if ( wc_appointment_requires_confirmation( $product_id ) ) {
			$items = WC()->cart->get_cart();

			foreach ( $items as $item_key => $item ) {
				if ( ! isset( $item['appointment'] ) || ! wc_appointment_requires_confirmation( $item['product_id'] ) ) {
					WC()->cart->remove_cart_item( $item_key );
					// Item qty.
					$item_qty = $item['quantity'] > 1 ? absint( $item['quantity'] ) . ' &times; ' : '';
					// Item name.
					$item_name = apply_filters(
						'woocommerce_add_to_cart_item_name_in_quotes',
						sprintf(
							'&ldquo;%s&rdquo;',
							wp_strip_all_tags( get_the_title( $item['product_id'] ) )
						),
						$item['product_id']
					);
					// Add notice.
					wc_add_notice(
						sprintf(
							/* translators: %s: product name */
							__( '%s has been removed from your cart. It is not possible to complete the purchase along with an appointment that requires confirmation.', 'woocommerce-appointments' ),
							$item_qty . $item_name
						),
						'notice'
					);
				}
			}
		} elseif ( wc_appointment_cart_requires_confirmation() ) {
			// Remove appointment that requires confirmation.
			$this->remove_appointment_that_requires_confirmation();
			// Add notice.
			wc_add_notice( __( 'An appointment that requires confirmation has been removed from your cart. It is not possible to complete the purchase along with an appointment that doesn\'t require confirmation.', 'woocommerce-appointments' ), 'notice' );
		}

		return $passed;
	}

	/**
	 * Disable quantity field editing for appointments in cart block.
	 *
	 * Makes appointment quantities read-only in WooCommerce Blocks cart.
	 * Appointment quantities are set during booking and cannot be changed in cart.
	 *
	 * @since 1.0.0
	 *
	 * @param bool        $value     Whether quantity field is editable.
	 * @param WC_Product  $product   Product object.
	 * @param array<string, mixed> $cart_item Cart item array.
	 *
	 * @return bool False if product is an appointment product, otherwise original value.
	 */
	public function disable_cart_block_qty_field( $value, $product, $cart_item ) {
		#error_log( var_export( $value, true ) );
		#error_log( var_export( $product, true ) );
		#error_log( var_export( $cart_item, true ) );

		// Disable quantity field editing for appointments.
		if ( is_wc_appointment_product( $product ) ) {
			return false;
		}

		return $value;
	}

	/**
	 * Validate sold individually requirement for appointments.
	 *
	 * Ensures appointment products marked as sold individually can only be added once to cart.
	 * Prevents duplicate appointments of the same product in cart.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $passed    Whether validation passed so far.
	 * @param int  $product_id Product ID being added to cart.
	 * @param int  $qty       Quantity being added.
	 *
	 * @return bool True if validation passes, false if product already in cart (adds error notice).
	 */
	public function validate_appointment_sold_individually( $passed, $product_id, $qty ) {
		if ( wc_appointment_sold_individually( $product_id ) ) {
			$product = wc_get_product( $product_id );
			$items   = WC()->cart->get_cart();

			foreach ( $items as $item ) {
				// Ptroduct already in cart. Stop here.
				if ( $item['product_id'] === $product_id ) {
					// Product name.
					$product_name = apply_filters(
						'woocommerce_add_to_cart_item_name_in_quotes',
						sprintf(
							'&ldquo;%s&rdquo;',
							wp_strip_all_tags( get_the_title( $item['product_id'] ) )
						),
						$product->get_name()
					);
					// Add notice.
					$message = sprintf(
						/* translators: %s: product name */
						__( 'You cannot add another %s to your cart.', 'woocommerce-appointments' ),
						$product_name
					);
					$wp_button_class = wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '';
					wc_add_notice(
						sprintf(
							'<a href="%s" class="button wc-forward%s">%s</a> %s',
							wc_get_cart_url(),
							esc_attr( $wp_button_class ),
							__( 'View cart', 'woocommerce-appointments' ),
							$message
						),
						'error'
					);

					$passed = false;
				}
			}
		}

		return $passed;
	}

	/**
     * Validate appointment product order for checkout block.
     *
     * Wrapper method for WooCommerce Blocks checkout validation.
     * Skips validation if called from admin (Gutenberg editor preview).
     *
     * @since 1.15.76
     *
     * @param \WP_Error $errors WP_Error object to add validation errors to.
     * @param \WC_Cart  $cart   Cart object.
     *
     * @return void
     */
    public function validate_appointment_order_checkout_block_support( \WP_Error $errors, \WC_Cart $cart ): void {
		// Existing checkout validation if rest api request generates from gutenberg editor.
		if ( is_admin() ) {
			return;
		}

		$this->validate_appointment_order( $errors, $cart );
	}

	/**
     * Validate appointment product order for legacy checkout.
     *
     * Wrapper method for legacy shortcode checkout validation.
     * Delegates to validate_appointment_order() with current cart.
     *
     * @since 1.15.76
     *
     * @param array<string, mixed> $data   Checkout data (unused, kept for hook compatibility).
     * @param \WP_Error            $errors WP_Error object to add validation errors to.
     *
     * @return void
     */
    public function validate_appointment_order_legacy_checkout( array $data, \WP_Error $errors ): void {
		$this->validate_appointment_order( $errors, WC()->cart );
	}

	/**
	 * Ensures appointments are saved for all order items that should have them.
	 * This is a fallback mechanism to catch appointments that weren't saved during checkout.
	 *
	 * @param WC_Order $order The order to check.
	 * @return void
	 */
	protected function ensure_appointments_for_order_items( $order ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$order_id = $order->get_id();
		if ( empty( $order_id ) ) {
			return;
		}

		// Get all appointments already linked to this order.
		$existing_appointments = WC_Appointment_Data_Store::get_appointment_ids_from_order_id( $order_id );
		$existing_appointment_item_ids = [];

		// Build a map of order item IDs that already have appointments.
		foreach ( $existing_appointments as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( $appointment && is_a( $appointment, 'WC_Appointment' ) ) {
				$item_id = $appointment->get_order_item_id();
				if ( $item_id !== 0 ) {
					$existing_appointment_item_ids[] = $item_id;
				}
			}
		}

		// Check each order item for missing appointments.
		foreach ( $order->get_items() as $item_id => $item ) {
			// Skip if this item already has an appointment.
			if ( in_array( $item_id, $existing_appointment_item_ids, true ) ) {
				continue;
			}

			// Check if this is an appointment product.
			$product = $item->get_product();
            if (! $product) {
                continue;
            }
            if (! is_wc_appointment_product( $product )) {
                continue;
            }

			// Try to get appointment ID from order item meta.
			$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $item_id, true, $order_id );
			if ( ! empty( $appointment_ids ) ) {
				// Appointment IDs exist in meta, verify they're actually saved.
				foreach ( $appointment_ids as $appointment_id ) {
					$appointment = get_wc_appointment( $appointment_id );
					if ( $appointment && is_a( $appointment, 'WC_Appointment' ) ) {
						// Appointment exists, ensure it's properly linked.
						if ( $appointment->get_order_id() !== $order_id ) {
							$appointment->set_order_id( $order_id );
							$appointment->set_order_item_id( $item_id );
							if ( ! $appointment->get_customer_id() && $order->get_customer_id() ) {
								$appointment->set_customer_id( $order->get_customer_id() );
							}
							$saved_id = $appointment->save();
							if ($saved_id && $saved_id > 0) {
                                // Successfully fixed linkage - no logging needed for normal operations
                            } elseif (function_exists( 'wc_add_appointment_log' )) {
                                // Log if the fix attempt failed
                                wc_add_appointment_log( $this->id, sprintf( 'Failed to fix appointment #%d linkage for order #%d item #%d', $appointment_id, $order_id, $item_id ) );
                            }
						}
					} else {
						// Appointment ID in meta but appointment doesn't exist - remove from meta.
						wc_delete_order_item_meta( $item_id, '_appointment_id' );
						if ( function_exists( 'wc_add_appointment_log' ) ) {
							wc_add_appointment_log( $this->id, sprintf( 'Removed invalid appointment ID #%d from order #%d item #%d meta', $appointment_id, $order_id, $item_id ) );
						}
					}
				}
				continue;
			}

			// No appointment found - try to recover from cart session data if available.
			// This is a last resort fallback - normally appointments should be created during add_to_cart.
			// We can't recreate appointments here without the original cart data, so we'll just log it.
			if ( function_exists( 'wc_add_appointment_log' ) ) {
				wc_add_appointment_log( $this->id, sprintf( 'WARNING: Order #%d item #%d (product #%d) should have an appointment but none found. This may indicate a checkout issue.', $order_id, $item_id, $product->get_id() ) );
			}

			// Add order note for admin visibility.
			/* translators: 1: order item ID, 2: product name. */
			$order->add_order_note( sprintf( __( 'Warning: Order item #%1$d (product: %2$s) should have an appointment but none was found. Please check manually.', 'woocommerce-appointments' ), $item_id, $product->get_name() ) );
		}
	}

	/**
     * Validate appointment order items during checkout.
     *
     * Validates appointment availability for all appointments in cart during checkout.
     * Excludes in-cart appointments from availability checks and flags checkout appointments
     * as temporarily confirmed to prevent double-booking validation issues.
     *
     * @since 1.15.76
     *
     * @param \WP_Error $errors WP_Error object to add validation errors to.
     * @param \WC_Cart  $cart   Cart object containing appointment items.
     *
     * @return void
     */
    public function validate_appointment_order( \WP_Error $errors, \WC_Cart $cart ): void {
		// Do not need to validate if cart is empty.
		if ( $cart->is_empty() ) {
			return;
		}

		$has_recurring = false;
		foreach ( $cart->get_cart() as $product_data ) {
			if ( ! empty( $product_data['wca_recurring'] ) ) {
				$has_recurring = true;
				break;
			}
		}

		$cart_items = $cart->get_cart();

		// Group cart appointments by slot to detect overbooking across multiple cart items.
		// Key: "product_id_staffids_start_end", Value: array of cart item data.
		$slots_in_cart            = [];
		$overlap_exclude_appt_ids = [];

		foreach ( $cart_items as $cart_item_key => $product_data ) {
			$product = WC_Product_Appointment::as_appointment_product( $product_data['data'] ?? 0 );
			if ( ! $product ) {
				continue;
			}

			if ( ! empty( $product_data['wca_recurring'] ) ) {
				$appointments = WC_Appointment_Recurring_Cart_Occupancy::appointments_for_product( $product, 0, PHP_INT_MAX, 0, $cart_item_key );
			} elseif ( ( $hold_id = wc_appointments_get_cart_item_hold_appointment_id( $product_data ) ) > 0 ) {
				$hold = get_wc_appointment( $hold_id );
				$appointments = ( $hold && ! $hold->has_status( WC_Appointments_Constants::STATUS_WAS_IN_CART ) ) ? array( $hold ) : array();
			} else {
				// Appointable product in cart without a valid hold — reject at checkout.
				$errors->add(
					'appointment-missing-hold-' . $cart_item_key,
					sprintf(
						/* translators: %s: product name */
						esc_html__( 'The appointment for %s could not be verified. Please remove it from your cart and try again.', 'woocommerce-appointments' ),
						$product->get_name()
					)
				);
				$appointments = array();
			}

			foreach ( $appointments as $appointment ) {
				$staff_ids_str = implode( ',', $appointment->get_staff_ids() );
				$loc           = (int) $appointment->get_location_id();
				$slot_key      = "{$appointment->get_product_id()}_{$staff_ids_str}_{$appointment->get_start()}_{$appointment->get_end()}_{$loc}";
				$appt_id       = (int) $appointment->get_id();

				if ( ! isset( $slots_in_cart[ $slot_key ] ) ) {
					$slots_in_cart[ $slot_key ] = array(
						'product'     => $product,
						'appointment' => $appointment,
						'cart_qty'    => 0,
					);
				}
				$slots_in_cart[ $slot_key ]['cart_qty'] += max( 1, (int) $appointment->get_qty() );
				// Exclude every in-cart hold for this checkout, not only the first per slot group.
				if ( $appt_id > 0 ) {
					$overlap_exclude_appt_ids[] = $appt_id;
				}
			}
		}

		// Holds in this cart must not count against their own slot during re-validation (admin edit uses the same exclude).
		$overlap_exclude_appt_ids = array_values( array_unique( $overlap_exclude_appt_ids ) );
		if ( ! empty( $overlap_exclude_appt_ids ) ) {
			\WC_Appointment_Slots_Engine::set_overlap_exclude_appointment_ids( $overlap_exclude_appt_ids );
		}

		$checkout_collections = array();

		if ( $has_recurring && ! empty( $slots_in_cart ) ) {
			$batch_ranges = array();

			foreach ( $slots_in_cart as $slot_data ) {
				$product     = $slot_data['product'];
				$appointment = $slot_data['appointment'];

				if ( ! $appointment ) {
					continue;
				}

				$start_date = (int) $appointment->get_start();
				$end_date   = (int) $appointment->get_end();
				if ( $product->get_availability_span() ) {
					$end_date = wc_appointments_availability_span_end_date( $product, $start_date );
				}

				$avail_staff_id = 0;
				if ( $product->has_staff() && ! $product->is_staff_assignment_type( 'all' ) ) {
					$avail_staff_id = $appointment->get_staff_id() ?: 0;
				}

				$batch_key = (int) $product->get_id() . ':' . (int) $avail_staff_id . ':' . (int) $appointment->get_location_id();

				if ( ! isset( $batch_ranges[ $batch_key ] ) ) {
					$batch_ranges[ $batch_key ] = array(
						'product'     => $product,
						'staff_id'    => $avail_staff_id > 0 ? $avail_staff_id : null,
						'location_id' => (int) $appointment->get_location_id(),
						'min'         => $start_date,
						'max'         => $end_date,
					);
					continue;
				}

				$batch_ranges[ $batch_key ]['min'] = min( $batch_ranges[ $batch_key ]['min'], $start_date );
				$batch_ranges[ $batch_key ]['max'] = max( $batch_ranges[ $batch_key ]['max'], $end_date );
			}

			foreach ( $batch_ranges as $batch_key => $range ) {
				$loaded = \WC_Appointments_Controller::load_slots_collections_for_range(
					$range['product'],
					(int) $range['min'],
					(int) $range['max'],
					$range['staff_id'],
					(int) $range['location_id']
				);
				if ( is_array( $loaded ) && ! empty( $loaded ) ) {
					$checkout_collections[ $batch_key ] = $loaded;
				}
			}
		}

		try {
			foreach ( $slots_in_cart as $slot_key => $slot_data ) {
				$product     = $slot_data['product'];
				$appointment = $slot_data['appointment'];

				$start_date = $appointment->get_start();
				$end_date   = $appointment->get_end();
				$cart_qty   = max( 1, (int) $slot_data['cart_qty'] );

				// Same staff scope as add-to-cart / is_appointable(): 0 = all product staff (fan-out).
				$avail_staff_id = 0;
				if ( $product->has_staff() && ! $product->is_staff_assignment_type( 'all' ) ) {
					$avail_staff_id = $appointment->get_staff_id() ?: 0;
				}

				$is_overbooked = false;
				$batch_key     = (int) $product->get_id() . ':' . (int) $avail_staff_id . ':' . (int) $appointment->get_location_id();
				$use_batch     = $has_recurring && isset( $checkout_collections[ $batch_key ] );

				$cart_resource_id = 0;
				$cart_allocs      = $appointment->get_resource_allocations();
				if ( ! empty( $cart_allocs[0]['resource_id'] ) ) {
					$cart_resource_id = (int) $cart_allocs[0]['resource_id'];
				}

				try {
					$available = \WC_Appointments_Controller::get_indexed_total_available_for_range(
						$product,
						$start_date,
						$end_date,
						$avail_staff_id > 0 ? $avail_staff_id : null,
						$cart_qty,
						$use_batch ? $checkout_collections[ $batch_key ] : null,
						(int) $appointment->get_location_id(),
						$cart_resource_id
					);
					$is_overbooked = \WC_Appointments_Controller::is_indexed_range_unavailable( $product, $available, $avail_staff_id, $cart_qty );
				} catch ( \Exception $e ) {
					$is_overbooked = true;
				}

				if ( $is_overbooked ) {
					$errors->add(
						"appointment-checkout-overbooked-{$appointment->get_product_id()}",
						sprintf(
							/* translators: %s: product name */
							esc_html__( 'Sorry, the selected time slot is no longer available for %s. Please remove it from your cart and choose another.', 'woocommerce-appointments' ),
							$product->get_name()
						)
					);
				}
			}
		} finally {
			if ( ! empty( $overlap_exclude_appt_ids ) ) {
				\WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();
			}
		}
	}

	/**
	 * Unslashed POST for add-to-cart (WooCommerce verifies nonce).
	 *
	 * @return array<string, mixed>
	 */
	private function cart_post_unslashed(): array {
		return apply_filters( 'wc_appointments_cart_post_unslashed', wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field in wc_appointments_get_posted_data().
	}
}

$GLOBALS['wc_appointment_cart_manager'] = new WC_Appointment_Cart_Manager();
