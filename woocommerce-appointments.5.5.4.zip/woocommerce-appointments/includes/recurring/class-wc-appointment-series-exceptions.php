<?php
/**
 * Recurring series exceptions.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Version conflict exception for series updates.
 */
class WC_Appointment_Series_Version_Conflict extends Exception {

	/**
	 * @var int
	 */
	private $series_id;

	/**
	 * @var int
	 */
	private $expected_version;

	/**
	 * @param int $series_id        Series row id.
	 * @param int $expected_version Version the client sent.
	 */
	public function __construct( $series_id, $expected_version ) {
		$this->series_id          = (int) $series_id;
		$this->expected_version = (int) $expected_version;
		parent::__construct(
			sprintf(
				/* translators: 1: series id, 2: expected version */
				__( 'Series %1$d version mismatch (expected %2$d).', 'woocommerce-appointments' ),
				$this->series_id,
				$this->expected_version
			)
		);
	}

	/**
	 * @return int
	 */
	public function get_series_id() {
		return $this->series_id;
	}

	/**
	 * @return int
	 */
	public function get_expected_version() {
		return $this->expected_version;
	}
}

/**
 * Idempotency key reuse conflict.
 */
class WC_Appointment_Series_Idempotency_Conflict extends Exception {

	/**
	 * @var string
	 */
	private $idempotency_key;

	/**
	 * @param string $idempotency_key Client idempotency key.
	 */
	public function __construct( $idempotency_key ) {
		$this->idempotency_key = (string) $idempotency_key;
		parent::__construct(
			sprintf(
				/* translators: %s: idempotency key */
				__( 'Idempotency key %s was reused with a different request body.', 'woocommerce-appointments' ),
				$this->idempotency_key
			)
		);
	}

	/**
	 * @return string
	 */
	public function get_idempotency_key() {
		return $this->idempotency_key;
	}
}
