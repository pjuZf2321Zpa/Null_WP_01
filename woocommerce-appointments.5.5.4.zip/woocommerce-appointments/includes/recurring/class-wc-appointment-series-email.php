<?php
/**
 * Recurring series email coordinator (suppression, scheduling, send) and
 * shared order/email presentation (session times, sessions table, admin TZ line).
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * One consolidated customer notification for series create / bulk scope changes.
 */
final class WC_Appointment_Series_Email {

	const KIND_CREATED        = 'created';
	const KIND_CANCELLED      = 'cancelled';
	const KIND_STATUS_CHANGED = 'status_changed';

	const AS_HOOK = 'wca/series/send-email';

	/**
	 * @var int
	 */
	private static $suppress_depth = 0;

	/** @var int Balance order id while a payment-request email is rendering. */
	private static $balance_invoice_order_id = 0;

	/**
	 * @var bool
	 */
	private static $actions_removed = false;

	/**
	 * Whether series email is enabled in settings (no mailer bootstrap; safe during materialize).
	 *
	 * @return bool
	 */
	public static function is_series_email_setting_enabled() {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return false;
		}

		$enabled = isset( self::series_settings()['enabled'] ) ? (string) self::series_settings()['enabled'] : 'yes';

		return 'yes' === $enabled;
	}

	/**
	 * Whether series emails can be sent (settings + mailer registered and enabled).
	 *
	 * @return bool
	 */
	public static function is_available() {
		if ( ! self::is_series_email_setting_enabled() ) {
			return false;
		}

		$email = self::get_series_email();

		return $email && $email->is_enabled();
	}

	/**
	 * Delivery mode from email settings.
	 *
	 * @return string consolidated|per_occurrence
	 */
	public static function get_delivery_mode() {
		$mode = isset( self::series_settings()['delivery_mode'] ) ? (string) self::series_settings()['delivery_mode'] : 'consolidated';

		return in_array( $mode, array( 'per_occurrence', 'consolidated' ), true ) ? $mode : 'consolidated';
	}

	/**
	 * Whether per-occurrence emails should be suppressed for consolidated series.
	 *
	 * @param int|null $appointment_id When set, only suppress admin new-appointment mail for that series occurrence.
	 * @return bool
	 */
	public static function should_suppress_occurrence_emails( $appointment_id = null ) {
		if ( ! self::is_series_email_setting_enabled() || 'consolidated' !== self::get_delivery_mode() ) {
			return false;
		}

		if ( ! apply_filters( 'wc_appointments_suppress_series_occurrence_emails', true ) ) {
			return false;
		}

		if ( null === $appointment_id ) {
			return true;
		}

		$appointment = get_wc_appointment( (int) $appointment_id );
		$series_id     = $appointment ? (int) $appointment->get_meta( '_wca_series_id' ) : 0;

		return $series_id > 0 && (bool) apply_filters( 'wc_appointments_suppress_series_occurrence_admin_emails', true, $series_id, (int) $appointment_id );
	}

	/**
	 * Run callback without firing per-occurrence transactional appointment emails.
	 *
	 * @param callable $callback Callback.
	 * @return mixed
	 */
	public static function without_occurrence_emails( $callback ) {
		if ( ! self::should_suppress_occurrence_emails() ) {
			return call_user_func( $callback );
		}

		++self::$suppress_depth;

		if ( 1 === self::$suppress_depth ) {
			foreach ( WC_Appointment_Email_Manager::get_transactional_email_actions() as $action ) {
				remove_action( $action, array( 'WC_Emails', 'send_transactional_email' ), 10 );
			}
			self::$actions_removed = true;
		}

		try {
			return call_user_func( $callback );
		} finally {
			--self::$suppress_depth;

			if ( 0 === self::$suppress_depth && self::$actions_removed ) {
				foreach ( WC_Appointment_Email_Manager::get_transactional_email_actions() as $action ) {
					add_action( $action, array( 'WC_Emails', 'send_transactional_email' ), 10, 10 );
				}
				self::$actions_removed = false;
			}
		}
	}

	/**
	 * @return array<string, mixed>
	 */
	private static function series_settings() {
		static $settings = null;

		if ( null === $settings ) {
			$raw      = get_option( 'woocommerce_appointment_series_settings', array() );
			$settings = is_array( $raw ) ? $raw : array();
		}

		return $settings;
	}

	/**
	 * @return WC_Email_Appointment_Series|null
	 */
	private static function get_series_email() {
		if ( ! function_exists( 'WC' ) || ! WC() ) {
			return null;
		}

		$mailer = WC()->mailer();
		if ( ! $mailer ) {
			return null;
		}

		$emails = $mailer->get_emails();
		$email  = ! empty( $emails['WC_Email_Appointment_Series'] ) ? $emails['WC_Email_Appointment_Series'] : null;

		return $email instanceof WC_Email_Appointment_Series ? $email : null;
	}

	/**
	 * Series ids on order lines (`_wca_series_id`).
	 *
	 * @param int $order_id Order id.
	 * @return int[]
	 */
	public static function get_series_ids_for_order( $order_id ) {
		$order = $order_id > 0 ? wc_get_order( (int) $order_id ) : false;
		if ( ! $order ) {
			return array();
		}

		$ids = array();
		foreach ( $order->get_items() as $item ) {
			$line_series_id = (int) $item->get_meta( '_wca_series_id', true );
			if ( $line_series_id > 0 ) {
				$ids[ $line_series_id ] = $line_series_id;
			}
		}

		return array_values( $ids );
	}

	/**
	 * Debounced `created` notification after series create / prepaid materialize.
	 *
	 * @param int                  $series_id Series id.
	 * @param array<string, mixed> $args      Optional args.
	 * @return void
	 */
	public static function schedule_created_notification( $series_id, $args = array() ) {
		$series_id = (int) $series_id;
		if ( $series_id <= 0 || ! self::is_available() ) {
			return;
		}

		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}

		$args  = is_array( $args ) ? $args : array();
		$delay = (int) apply_filters( 'wc_appointments_series_email_debounce_seconds', 120, $series_id );
		$delay = max( 0, $delay );

		$order = null;
		try {
			$order_id = (int) ( new WC_Appointment_Series( $series_id ) )->get_order_id();
			$order    = $order_id > 0 ? wc_get_order( $order_id ) : false;
		} catch ( Exception $e ) {
			unset( $e );
		}

		if ( $order && $order->get_meta( '_wca_series_created_email_scheduled' ) ) {
			return;
		}
		if ( $order ) {
			$order->update_meta_data( '_wca_series_created_email_scheduled', '1' );
			$order->save();
		}

		$schedule_args = array_merge( array( 'retry' => 0 ), $args );

		as_schedule_single_action(
			time() + $delay,
			self::AS_HOOK,
			array( $series_id, self::KIND_CREATED, $schedule_args ),
			'wca'
		);

		do_action( 'woocommerce_appointments_series_email_scheduled', $series_id, self::KIND_CREATED, $schedule_args );
	}

	/**
	 * Action Scheduler handler.
	 *
	 * @param int                  $series_id Series id.
	 * @param string               $kind      Notification kind.
	 * @param array<string, mixed> $args      Context args.
	 * @return void
	 */
	public static function on_scheduled_notification( $series_id, $kind, $args = array() ) {
		$series_id = (int) $series_id;
		$kind      = (string) $kind;
		$args      = is_array( $args ) ? $args : array();

		if ( self::KIND_CREATED !== $kind ) {
			self::send( $series_id, $kind, $args );
			return;
		}

		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			unset( $e );
			return;
		}

		if ( $series->get_notified_created_at() > 0 ) {
			return;
		}

		if ( self::materialization_pending( $series ) ) {
			$retry = isset( $args['retry'] ) ? (int) $args['retry'] : 0;
			if ( $retry >= 3 || ! function_exists( 'as_schedule_single_action' ) ) {
				return;
			}

			$args['retry'] = $retry + 1;
			$delay         = (int) apply_filters( 'wc_appointments_series_email_debounce_seconds', 120, $series_id );

			as_schedule_single_action(
				time() + max( 30, $delay ),
				self::AS_HOOK,
				array( $series_id, self::KIND_CREATED, $args ),
				'wca'
			);
			return;
		}

		self::send( $series_id, self::KIND_CREATED, $args );
	}

	/**
	 * Send one series notification.
	 *
	 * @param int                  $series_id Series id.
	 * @param string               $kind      created|cancelled|status_changed.
	 * @param array<string, mixed> $args      scope, new_status, appointment_ids, anchor_id.
	 * @return void
	 */
	public static function send( $series_id, $kind, $args = array() ) {
		$series_id = (int) $series_id;
		$kind      = (string) $kind;

		if ( $series_id <= 0 || ! self::is_available() ) {
			return;
		}

		if ( ! apply_filters( 'wc_appointments_series_send_email', true, $series_id, $kind, $args ) ) {
			return;
		}

		if ( self::KIND_CREATED === $kind ) {
			$store = WC_Data_Store::load( WC_Appointment_Series::DATA_STORE );
			if ( ! $store->mark_created_notified( $series_id ) ) {
				return;
			}
			try {
				$series = new WC_Appointment_Series( $series_id );
				foreach ( self::get_series_ids_for_order( (int) $series->get_order_id() ) as $other_id ) {
					if ( $other_id !== $series_id ) {
						$store->mark_created_notified( $other_id );
					}
				}
			} catch ( Exception $e ) {
				unset( $e );
			}
		}

		$email = self::get_series_email();
		if ( ! $email ) {
			return;
		}

		$email->trigger( $series_id, $kind, $args );

		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			$series = null;
			unset( $e );
		}

		if ( $series ) {
			do_action( 'woocommerce_appointments_series_email_sent', $series, $kind, $args );
		}
	}

	/**
	 * @param WC_Appointment_Series $series Series.
	 * @return bool
	 */
	protected static function materialization_pending( WC_Appointment_Series $series ) {
		$materializer = new WC_Appointment_Series_Materializer();

		if ( $materializer->needs_more_materialization( $series ) ) {
			return true;
		}

		if ( function_exists( 'as_next_scheduled_action' ) ) {
			$next = as_next_scheduled_action(
				WC_Appointment_Series_Materializer::AS_HOOK,
				array(
					'series_id'  => (int) $series->get_id(),
					'batch_size' => (int) apply_filters( 'wc_appointments_series_materialize_batch', 50, $series->get_id() ),
					'request_id' => '',
				),
				WC_Appointment_Series_Materializer::AS_GROUP
			);

			if ( $next ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Appointment ids in scope matching a status (after bulk update).
	 *
	 * @param int    $series_id  Series id.
	 * @param int    $anchor_id  Anchor occurrence id.
	 * @param string $scope      future|all.
	 * @param string $status     Expected appointment status.
	 * @return int[]
	 */
	public static function appointment_ids_in_scope_with_status( $series_id, $anchor_id, $scope, $status ) {
		$manager = new WC_Appointment_Series_Manager();
		$ctx     = $manager->get_scope_context( $series_id, $anchor_id );

		if ( is_wp_error( $ctx ) ) {
			return array();
		}

		$scope = 'all' === $scope ? 'all' : 'future';
		$ids   = array();

		foreach ( $ctx['rows'] as $row ) {
			if ( 'all' !== $scope && (int) $row['start_ts'] < (int) $ctx['cutoff'] ) {
				continue;
			}

			$appt = get_wc_appointment( (int) $row['appointment_id'] );
			if ( $appt && $status === $appt->get_status() ) {
				$ids[] = (int) $appt->get_id();
			}
		}

		return $ids;
	}

	/*
	|--------------------------------------------------------------------------
	| Order / email presentation (mirrors wc_appointments_get_summary_list).
	|--------------------------------------------------------------------------
	*/

	/**
	 * Whether order/email rendering is in the admin context.
	 *
	 * @param bool $is_admin Caller flag.
	 * @return bool
	 */
	public static function order_is_admin_context( $is_admin ) {
		$sent = WC_Appointment_Order_Manager::$email_sent_to_admin;

		return $is_admin || ( null !== $sent && $sent );
	}

	/**
	 * Display timezone for series session labels on orders and emails.
	 *
	 * @param bool   $is_admin    Admin context.
	 * @param string $customer_tz Booking IANA timezone.
	 * @return string
	 */
	public static function order_display_timezone( $is_admin, $customer_tz ) {
		$site_tz = wc_timezone_string();

		if ( $is_admin ) {
			$current_email = WC_Appointment_Order_Manager::$current_email;
			if ( $current_email && ! empty( $current_email->recipient_timezone ) ) {
				return (string) $current_email->recipient_timezone;
			}
			if ( ! $current_email && class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
				return WC_Appointments_Timezone_Helper::get_admin_user_timezone();
			}

			return $site_tz;
		}

		if ( class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
			$uid = (int) get_current_user_id();
			if ( $uid > 0 ) {
				return WC_Appointments_Timezone_Helper::get_booking_form_timezone( $uid );
			}
			if ( $customer_tz && WC_Appointments_Timezone_Helper::is_valid_timezone( $customer_tz ) ) {
				return $customer_tz;
			}
		}

		return $site_tz;
	}

	/**
	 * Persist booking timezone on an occurrence when meta is missing (in-memory only).
	 *
	 * @param WC_Appointment $appointment   Appointment.
	 * @param string         $customer_tz   IANA timezone.
	 * @param WC_Appointment_Series|null $series Optional series fallback.
	 * @return void
	 */
	public static function ensure_local_timezone( WC_Appointment $appointment, $customer_tz = '', $series = null ) {
		if ( $appointment->get_local_timezone() ) {
			return;
		}

		if ( ! $customer_tz && $series instanceof WC_Appointment_Series ) {
			$customer_tz = (string) $series->get_timezone();
		}

		if ( $customer_tz ) {
			$appointment->set_local_timezone( $customer_tz );
		}
	}

	/**
	 * Customer-facing start label for a series occurrence (emails, same as single appointments).
	 *
	 * @param WC_Appointment             $appointment Appointment.
	 * @param WC_Appointment_Series|null $series      Series.
	 * @param bool                       $plain_text  Plain text email.
	 * @return string
	 */
	public static function format_appointment_start( WC_Appointment $appointment, $series = null, $plain_text = false ) {
		self::ensure_local_timezone( $appointment, '', $series );

		$product = $appointment->get_product();
		$appt    = ( $product instanceof WC_Product && is_wc_appointment_product( $product ) )
			? WC_Product_Appointment::as_appointment_product( $product )
			: null;

		return self::format_session_time(
			(int) $appointment->get_start(),
			(string) $appointment->get_local_timezone(),
			false,
			$plain_text,
			$appt,
			false,
			$appointment
		);
	}

	/**
	 * Label for a session row (order emails, cart, product preview).
	 *
	 * @param int                           $start_ts          Start timestamp.
	 * @param string                        $customer_tz       Booking timezone.
	 * @param bool                          $is_admin          Admin context.
	 * @param bool                          $plain_text        Plain text (no HTML abbr element).
	 * @param WC_Product_Appointment|null   $product           Product.
	 * @param bool                          $suppress_tz_abbr  True for cart (separate Time zone row).
	 * @param WC_Appointment|null           $appointment       Materialized occurrence (optional).
	 * @return string
	 */
	public static function format_session_time( $start_ts, $customer_tz, $is_admin, $plain_text = false, $product = null, $suppress_tz_abbr = false, $appointment = null ) {
		$start_ts = (int) $start_ts;
		if ( $start_ts <= 0 ) {
			return '';
		}

		$is_admin   = self::order_is_admin_context( $is_admin );
		$display_tz = self::order_display_timezone( $is_admin, (string) $customer_tz );

		if ( $appointment instanceof WC_Appointment ) {
			$appt = $appointment;
			self::ensure_local_timezone( $appt, (string) $customer_tz );
		} else {
			$appt = new WC_Appointment();
			$appt->set_start( $start_ts );
			if ( $customer_tz ) {
				$appt->set_local_timezone( $customer_tz );
			}
			if ( $product instanceof WC_Product_Appointment && ! $product->has_time() ) {
				$appt->set_all_day( true );
			}
		}

		$formatted = $appt->get_start_date_for_email(
			$display_tz,
			$plain_text,
			null,
			null,
			$is_admin ? 'admin' : 'frontend',
			$suppress_tz_abbr ? false : null
		);

		return is_string( $formatted ) ? $formatted : '';
	}

	/**
	 * Admin **Customer's Timezone** line for series order display.
	 *
	 * @param WC_Appointment[] $appointments Materialized rows.
	 * @param string           $customer_tz  Booking timezone.
	 * @param bool             $is_admin     Admin context.
	 * @return string HTML or empty.
	 */
	public static function admin_customer_timezone_abbr( array $appointments, $customer_tz, $is_admin ) {
		if (
			! $is_admin
			|| ! class_exists( 'WC_Appointments_Timezone_Helper' )
			|| 'disabled' === get_option( 'wc_appointments_timezone_display', 'all' )
		) {
			return '';
		}

		$tz_sample = ! empty( $appointments[0] ) && $appointments[0] instanceof WC_Appointment ? $appointments[0] : null;
		if ( ! $tz_sample && $customer_tz ) {
			$tz_sample = new WC_Appointment();
			$tz_sample->set_local_timezone( $customer_tz );
		} elseif ( $tz_sample ) {
			self::ensure_local_timezone( $tz_sample, $customer_tz );
		}

		if ( ! $tz_sample || ! (bool) apply_filters( 'woocommerce_appointments_email_customer_timezone', true, $tz_sample, 'admin' ) ) {
			return '';
		}

		$viewer_tz = self::order_display_timezone( true, (string) $customer_tz );
		if ( ! WC_Appointment_Order_Manager::$current_email ) {
			$viewer_tz = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
		}

		return WC_Appointments_Timezone_Helper::build_customer_timezone_abbr( $tz_sample, false, $viewer_tz );
	}

	/**
	 * Booking timezone from order line meta or series row.
	 *
	 * @param array<string, mixed>     $recurring Line `_wca_recurring` meta.
	 * @param WC_Appointment_Series|null $series  Series.
	 * @return string
	 */
	public static function resolve_customer_timezone( array $recurring, $series = null ) {
		$tz = (string) ( $recurring['timezone'] ?? '' );
		if ( $series instanceof WC_Appointment_Series && $series->get_timezone() ) {
			$tz = (string) $series->get_timezone();
		}

		return $tz;
	}

	/**
	 * Template args for order/series-display.php, or null when nothing to render.
	 *
	 * @param WC_Appointment_Series|null $series       Series.
	 * @param array<string, mixed>       $recurring    Line meta.
	 * @param WC_Appointment[]           $appointments Materialized occurrences.
	 * @param WC_Order_Item              $item         Order line.
	 * @param WC_Order|null              $order        Order.
	 * @param bool                       $is_admin     Admin context.
	 * @return array<string, mixed>|null
	 */
	public static function get_order_series_display_args( $series, array $recurring, array $appointments, $item, $order, $is_admin ) {
		if ( ! $item instanceof WC_Order_Item ) {
			return null;
		}

		$product    = $item->get_product();
		$pay_first  = ( $series instanceof WC_Appointment_Series && WC_Appointment_Series::PAYMENT_PAY_FIRST === $series->get_payment_model() )
			|| WC_Appointment_Series::PAYMENT_PAY_FIRST === (string) ( $recurring['payment_model'] ?? '' );
		$is_admin   = self::order_is_admin_context( $is_admin );
		$plain_text = (bool) ( WC_Appointment_Order_Manager::$email_plain_text ?? false );
		$customer_tz  = self::resolve_customer_timezone( $recurring, $series );
		$appt_product = ( $product instanceof WC_Product ) ? WC_Product_Appointment::as_appointment_product( $product ) : null;
		$series_obj   = $series instanceof WC_Appointment_Series ? $series : null;
		$display_tz   = self::order_display_timezone( $is_admin, $customer_tz );
		$rows         = array();
		$index        = 0;

		if ( ! empty( $appointments ) ) {
			foreach ( $appointments as $appointment ) {
				if ( ! $appointment instanceof WC_Appointment ) {
					continue;
				}
				$label = $is_admin
					? self::format_session_time( (int) $appointment->get_start(), $customer_tz, true, $plain_text, $appt_product, false, $appointment )
					: self::format_appointment_start( $appointment, $series_obj, $plain_text );
				$rows[] = array(
					'label'          => $label,
					'appointment'    => $appointment,
					'payment_status' => $pay_first ? (string) $appointment->get_meta( '_wca_series_payment_status' ) : '',
				);
			}
		} elseif ( ! empty( $recurring['session_starts'] ) ) {
			foreach ( array_map( 'intval', (array) $recurring['session_starts'] ) as $start_ts ) {
				if ( $start_ts <= 0 ) {
					continue;
				}
				++$index;
				$rows[] = array(
					'label'          => self::format_session_time( $start_ts, $customer_tz, $is_admin, $plain_text, $appt_product ),
					'payment_status' => $pay_first ? ( 1 === $index ? 'paid' : 'due' ) : '',
				);
			}
		}

		$is_balance_order = $order instanceof WC_Order && WC_Appointment_Series_Payment::is_balance_order( $order );

		if ( empty( $rows ) && ! ( $is_balance_order && $series instanceof WC_Appointment_Series ) ) {
			return null;
		}

		if ( $series instanceof WC_Appointment_Series ) {
			$pattern = (string) $series->get_pattern_summary( null, $display_tz );
		} elseif ( ! empty( $recurring['rrule'] ) ) {
			$pattern = WC_Appointment_Series_RRule::humanize(
				(string) $recurring['rrule'],
				(int) ( $recurring['dtstart_ts'] ?? 0 ),
				(string) ( $recurring['timezone'] ?? wc_timezone_string() ),
				WC_Appointment_Series_RRule::humanize_wp_date_opts()
			);
		} else {
			$pattern = '';
		}

		$location_display = '';
		$location_label   = get_wc_appointment_data_label( 'location', $appt_product );
		// Customer series emails: same hide rule as Resources::get_context_display( ..., false ).
		$show_location    = ! ( $appt_product instanceof WC_Product_Appointment && WC_Appointments_Location::MODE_HIDDEN === $appt_product->get_location_mode() );
		if ( $show_location && class_exists( 'WC_Appointments_Location' ) ) {
			if ( $series instanceof WC_Appointment_Series ) {
				$series_location = $series->get_meta( '_wca_location', true );
				if ( is_array( $series_location ) ) {
					$location_display = WC_Appointments_Location::format_snapshot_for_display( $series_location );
				}
			} elseif ( ! empty( $recurring['location'] ) && is_array( $recurring['location'] ) ) {
				$location_display = WC_Appointments_Location::format_snapshot_for_display( $recurring['location'] );
			}
		}

		$currency        = $order instanceof WC_Order ? $order->get_currency() : get_woocommerce_currency();
		$balance_due     = 0.0;
		$balance_pay_url = '';

		if ( $series instanceof WC_Appointment_Series && $pay_first ) {
			$balance_due     = (float) WC_Appointment_Series::calculate_balance_due_display( $series );
			$currency        = $series->get_checkout_currency();
			$balance_pay_url = $series->has_open_balance() ? WC_Appointment_Series_Payment::get_balance_pay_url( $series ) : '';
		} elseif ( $pay_first ) {
			$balance_due = WC_Appointment_Series::calculate_balance_due_display(
				$product instanceof WC_Product ? $product : null,
				(float) ( $recurring['series_total'] ?? 0 ),
				(float) ( $recurring['checkout_total'] ?? 0 )
			);
		}

		$series_account_url = ( $series instanceof WC_Appointment_Series && $series->get_id() > 0 && is_user_logged_in() && class_exists( 'WC_Appointment_Series_My_Account' ) )
			? WC_Appointment_Series_My_Account::get_url( $series->get_id() )
			: '';
		$paid_upfront      = 0.0;
		$series_total_meta = 0.0;
		$session_count     = count( $rows );

		if ( $is_balance_order && $series instanceof WC_Appointment_Series ) {
			$paid_upfront      = (float) $series->get_paid_upfront();
			$series_total_meta = (float) $series->get_series_total();
			$count_cap         = (int) $series->get_rrule_count_cap();
			if ( $count_cap > 0 ) {
				$session_count = $count_cap;
			}
		}

		if ( $pay_first && $series instanceof WC_Appointment_Series && $order instanceof WC_Order ) {
			foreach ( $rows as $row_index => $row ) {
				if ( empty( $row['appointment'] ) ) {
					continue;
				}
				$rows[ $row_index ]['payment_label'] = self::pay_first_payment_label( $row['appointment'], $order );
			}
		}

		return array(
			'rows'                  => $rows,
			'is_admin'              => $is_admin,
			'plain_text_email'      => $plain_text,
			'customer_tz_abbr'      => self::admin_customer_timezone_abbr( $appointments, $customer_tz, $is_admin ),
			'pattern'               => $pattern,
			'location_label'        => $location_label,
			'location_display'      => $location_display,
			'pay_first'             => $pay_first,
			'session_count'         => $session_count,
			'is_rtl'                => is_rtl() ? 'right' : 'left',
			'balance_due'           => $balance_due,
			'balance_pay_url'       => $balance_pay_url,
			'currency'              => $currency,
			'series_account_url'    => $series_account_url,
			'is_balance_order'         => $is_balance_order,
			'paid_upfront'             => $paid_upfront,
			'series_total'             => $series_total_meta,
			'balance_order_needs_payment' => $is_balance_order && $order instanceof WC_Order && ! $is_admin && $order->needs_payment(),
			'admin_balance'            => (
				$is_admin
				&& ! WC_Appointment_Order_Manager::$current_email
				&& $series instanceof WC_Appointment_Series
				&& $pay_first
				&& $order instanceof WC_Order
				&& $series->needs_balance_payment()
			) ? compact( 'series', 'order', 'balance_due', 'currency' ) : null,
			'show_customer_balance'    => ! $is_balance_order && ! $is_admin && $pay_first && $balance_due > 0,
			'show_account_link'          => ! $is_admin && $series_account_url && ( ! $pay_first || $balance_due <= 0 ),
		);
	}

	/**
	 * Whether this occurrence was covered by the parent (pay-first) checkout order.
	 *
	 * @param WC_Appointment $appointment Occurrence.
	 * @return bool
	 */
	public static function is_pay_first_parent_occurrence( WC_Appointment $appointment ) {
		return 1 === (int) $appointment->get_meta( '_wca_series_occurrence' );
	}

	/**
	 * Customer-facing order link for a series occurrence (My Account, emails).
	 *
	 * @param WC_Appointment        $appointment Occurrence.
	 * @param WC_Appointment_Series $series      Series.
	 * @return WC_Order|null
	 */
	public static function resolve_occurrence_order_for_customer( WC_Appointment $appointment, WC_Appointment_Series $series ) {
		if ( self::is_pay_first_parent_occurrence( $appointment ) ) {
			$parent_id = (int) $series->resolve_parent_order_id();
			return $parent_id > 0 ? wc_get_order( $parent_id ) : null;
		}

		$linked_id = (int) $appointment->get_order_id();
		if ( $linked_id > 0 ) {
			$linked_order = wc_get_order( $linked_id );
			if ( $linked_order ) {
				return $linked_order;
			}
		}

		if ( $series->has_open_balance() ) {
			$balance_order = $series->get_payable_balance_order();
			if ( ! $balance_order ) {
				$balance_order = $series->get_balance_order();
			}
			if ( $balance_order ) {
				return $balance_order;
			}
		}

		return $series->get_balance_order();
	}

	/**
	 * Pay-first payment label for a series occurrence on an order line.
	 *
	 * @param WC_Appointment $appointment Occurrence.
	 * @param WC_Order       $order       Parent or balance order being viewed.
	 * @return string
	 */
	public static function pay_first_payment_label( WC_Appointment $appointment, WC_Order $order ) {
		$is_balance = WC_Appointment_Series_Payment::is_balance_order( $order );

		if ( self::is_pay_first_parent_occurrence( $appointment ) ) {
			return $is_balance
				? __( 'Paid on original order', 'woocommerce-appointments' )
				: __( 'Paid on this order', 'woocommerce-appointments' );
		}

		$status = (string) $appointment->get_meta( '_wca_series_payment_status' );
		if ( 'due' === $status ) {
			return $is_balance
				? ( $order->needs_payment()
					? __( 'Included in this balance', 'woocommerce-appointments' )
					: __( 'Confirmed by this payment', 'woocommerce-appointments' ) )
				: __( 'Balance due', 'woocommerce-appointments' );
		}

		$paid_id = (int) $appointment->get_order_id();
		if ( $paid_id > 0 && $paid_id !== (int) $order->get_id() ) {
			$paid_order = wc_get_order( $paid_id );
			return sprintf(
				/* translators: %s: order number */
				__( 'Paid on order #%s', 'woocommerce-appointments' ),
				$paid_order ? $paid_order->get_order_number() : $paid_id
			);
		}

		return $is_balance
			? __( 'Confirmed by this payment', 'woocommerce-appointments' )
			: __( 'Paid on this order', 'woocommerce-appointments' );
	}

	/**
	 * Render recurring series schedule on order line items (thank-you, emails, My Account, admin).
	 *
	 * @param int|string           $item_id  Order line id.
	 * @param WC_Order_Item        $item     Order line.
	 * @param WC_Order|null        $order    Order.
	 * @param bool                 $is_admin Admin context.
	 * @return bool True when a series block was rendered.
	 */
	public static function render_order_series_display( $item_id, $item, $order, $is_admin = false ) {
		if ( ! $item instanceof WC_Order_Item ) {
			return false;
		}

		$recurring = $item->get_meta( '_wca_recurring', true );
		$recurring = is_array( $recurring ) ? $recurring : array();
		$series_id = (int) $item->get_meta( '_wca_series_id', true );

		// Line-level recurring meta only — do not inherit order `_wca_series_id` (mixed checkout).
		if ( $series_id <= 0 && empty( $recurring['session_starts'] ) && empty( $recurring['rrule'] ) ) {
			return false;
		}

		$series       = null;
		$appointments = array();

		if ( $series_id > 0 ) {
			try {
				$series = new WC_Appointment_Series( $series_id );
				$series->ensure_pay_first_totals_from_order( $recurring, $order );
				foreach ( $series->get_appointment_ids() as $appointment_id ) {
					$appointment = get_wc_appointment( $appointment_id );
					if ( $appointment ) {
						$appointments[] = $appointment;
					}
				}
			} catch ( Exception $e ) {
				unset( $e );
			}
		}

		$template_args = self::get_order_series_display_args( $series, $recurring, $appointments, $item, $order, $is_admin );
		if ( null === $template_args ) {
			return false;
		}

		wc_get_template(
			'order/series-display.php',
			$template_args,
			'woocommerce-appointments',
			WC_APPOINTMENTS_TEMPLATE_PATH
		);

		return true;
	}

	/** @return int */
	public static function balance_invoice_order_id() {
		return self::$balance_invoice_order_id;
	}

	/**
	 * Send WooCommerce payment-request email for a balance order.
	 *
	 * @param WC_Order $order Balance order.
	 * @return void
	 */
	public static function send_balance_payment_request( WC_Order $order ) {
		$series = WC_Appointment_Series::from_balance_order( $order );
		if ( ! $series || ! $series->needs_balance_payment() ) {
			return;
		}
		$invoice = ( WC()->mailer()->get_emails() ?? array() )['WC_Email_Customer_Invoice'] ?? null;
		if ( ! $invoice ) {
			return;
		}
		self::$balance_invoice_order_id = (int) $order->get_id();
		add_filter( 'gettext', array( __CLASS__, 'filter_balance_invoice_gettext' ), 10, 3 );
		add_action( 'woocommerce_email_before_order_table', array( __CLASS__, 'render_balance_invoice_email_summary' ), 5, 4 );
		$invoice->trigger( $order->get_id() );
		remove_action( 'woocommerce_email_before_order_table', array( __CLASS__, 'render_balance_invoice_email_summary' ), 5 );
		remove_filter( 'gettext', array( __CLASS__, 'filter_balance_invoice_gettext' ), 10 );
		self::$balance_invoice_order_id = 0;
	}

	/**
	 * Package totals above the order table during payment-request email send.
	 *
	 * @param WC_Order     $order          Order.
	 * @param bool         $sent_to_admin  Whether sent to admin.
	 * @param bool         $plain_text     Plain-text email.
	 * @param WC_Email|null $email         Email object.
	 * @return void
	 */
	public static function render_balance_invoice_email_summary( $order, $sent_to_admin, $plain_text, $email = null ) {
		unset( $sent_to_admin, $email );
		if ( ! $order instanceof WC_Order || self::$balance_invoice_order_id !== (int) $order->get_id() || ! WC_Appointment_Series_Payment::is_balance_order( $order ) ) {
			return;
		}
		$series = WC_Appointment_Series::from_balance_order( $order );
		if ( $series ) {
			self::render_balance_summary( $series, $order, (bool) $plain_text );
		}
	}

	/**
	 * Rewrite invoice email strings while a balance payment request is sending.
	 *
	 * @param string $translated Translated text.
	 * @param string $text       Original text.
	 * @param string $domain     Text domain.
	 * @return string
	 */
	public static function filter_balance_invoice_gettext( $translated, $text, $domain ) {
		if ( 'woocommerce' !== $domain || ! self::$balance_invoice_order_id ) {
			return $translated;
		}
		$map = array(
			'An order has been created for you on %1$s. Your order details are below, with a link to make payment when you’re ready: %2$s' =>
				/* translators: %1$s: site title, %2$s: order pay link */
				__( 'The remaining balance for your appointment package is below. Pay at %1$s to confirm your upcoming appointments: %2$s', 'woocommerce-appointments' ),
			'Pay for this order' => __( 'Pay remaining balance', 'woocommerce-appointments' ),
		);
		return $map[ $text ] ?? $translated;
	}

	/**
	 * Output pay-first package totals (emails, order views).
	 *
	 * @param WC_Appointment_Series $series        Series.
	 * @param WC_Order|null         $order         Related order when available.
	 * @param bool                  $plain_text    Plain-text output.
	 * @param string                $email_context Optional email template context (e.g. parts).
	 * @return void
	 */
	public static function render_balance_summary( WC_Appointment_Series $series, $order = null, $plain_text = false, $email_context = '' ) {
		$series->ensure_pay_first_totals_from_order( null, $order );
		$paid_upfront = (float) $series->get_paid_upfront();
		$series_total = (float) $series->get_series_total();
		$balance_due  = (float) WC_Appointment_Series::calculate_balance_due_display( $series );
		if ( $balance_due <= 0 && $paid_upfront <= 0 && $series_total <= 0 ) {
			return;
		}
		$parent_id = ( $order instanceof WC_Order ? (int) $order->get_meta( '_wca_parent_order_id', true ) : 0 ) ?: (int) $series->resolve_parent_order_id();
		$parent    = $parent_id > 0 ? wc_get_order( $parent_id ) : null;
		$bordered  = 'parts' === (string) $email_context;
		wc_get_template(
			$plain_text ? 'emails/plain/series-balance-summary.php' : 'emails/series-balance-summary.php',
			array(
				'text_align'          => is_rtl() ? 'right' : 'left',
				'bordered'            => $bordered,
				'cell_style'          => $bordered ? 'border: 1px solid #eee;' : '',
				'currency'            => $series->get_checkout_currency(),
				'paid_upfront'        => $paid_upfront,
				'series_total'        => $series_total,
				'balance_due'         => $balance_due,
				'balance_pay_url'     => WC_Appointment_Series_Payment::get_balance_pay_url( $series ),
				'parent_order_number' => $parent ? $parent->get_order_number() : '',
			),
			'woocommerce-appointments',
			WC_APPOINTMENTS_TEMPLATE_PATH
		);
	}
}
