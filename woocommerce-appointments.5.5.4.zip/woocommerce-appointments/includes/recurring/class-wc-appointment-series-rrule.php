<?php
/**
 * Adapter over RRule\RSet for series expansion (Fake UTC bridge).
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * RRULE expansion in series IANA timezone, storage as Fake UTC timestamps.
 */
class WC_Appointment_Series_RRule {

	/**
	 * RRule set for expansion.
	 *
	 * @var \RRule\RSet
	 */
	private $set;

	/**
	 * Series timezone.
	 *
	 * @var \DateTimeZone
	 */
	private $tz;

	/**
	 * Constructor.
	 *
	 * @param string $ical_block RRULE line and optional EXDATE/RDATE lines (LF-separated).
	 * @param int    $dtstart_ts Anchor as Fake-UTC epoch (store wall time).
	 * @param string $tz_id      IANA timezone, e.g. Europe/Ljubljana.
	 */
	public function __construct( $ical_block, $dtstart_ts, $tz_id ) {
		$this->tz = new DateTimeZone( $tz_id );

		$dtstart = self::fake_utc_to_zoned( $dtstart_ts, $this->tz );

		$this->set = new RRule\RSet( $ical_block, $dtstart );
	}

	/**
	 * Expand occurrences in a range as recurrence_id => start_ts (Fake UTC).
	 *
	 * @param  DateTimeImmutable $range_start Range start (series timezone).
	 * @param  DateTimeImmutable $range_end   Range end (series timezone).
	 * @param  int               $limit       Max occurrences.
	 * @return array<string, int>
	 */
	public function expand( DateTimeImmutable $range_start, DateTimeImmutable $range_end, $limit = 200 ) {
		$out = array();

		foreach ( $this->set->getOccurrencesBetween( $range_start, $range_end, $limit ) as $dt ) {
			if ( $dt instanceof DateTime ) {
				$dt = DateTimeImmutable::createFromMutable( $dt );
			}
			$recurrence_id         = $dt->format( 'Ymd\THis' );
			$out[ $recurrence_id ] = self::zoned_to_fake_utc( $dt );
		}

		return $out;
	}

	/**
	 * Append an EXDATE line for one occurrence.
	 *
	 * @param  string $ical_block    Existing iCal block.
	 * @param  string $recurrence_id RECURRENCE-ID (Ymd\THis in series TZ).
	 * @param  string $tz_id         IANA timezone.
	 * @return string
	 */
	public static function append_exdate( $ical_block, $recurrence_id, $tz_id = '' ) {
		return self::append_ical_datetime_line( $ical_block, 'EXDATE', $recurrence_id, $tz_id );
	}

	/**
	 * @param array<string, int>   $overrides Original RECURRENCE-ID => new Fake UTC start.
	 * @param string               $tz_id     Series IANA timezone.
	 * @param callable             $callback  fn( string $old_id, int $new_start, string $new_id ): void
	 * @return void
	 */
	public static function each_override( $overrides, $tz_id, $callback ) {
		foreach ( (array) $overrides as $old_id => $new_start ) {
			$old_id    = self::sanitize_recurrence_id( (string) $old_id );
			$new_start = (int) $new_start;
			if ( '' === $old_id || $new_start <= 0 ) {
				continue;
			}
			$callback( $old_id, $new_start, self::recurrence_id_from_fake_utc( $new_start, $tz_id ) );
		}
	}

	/**
	 * Apply storefront reschedules onto an expanded map (replace; keeps COUNT stable).
	 *
	 * @param array<string, int> $occurrences recurrence_id => Fake UTC start.
	 * @param array<string, int> $overrides   Original RECURRENCE-ID => new Fake UTC start.
	 * @param string             $tz_id       Series IANA timezone.
	 * @return array<string, int>
	 */
	public static function merge_occurrence_overrides( $occurrences, $overrides, $tz_id ) {
		if ( empty( $overrides ) || ! is_array( $occurrences ) ) {
			return $occurrences;
		}

		self::each_override(
			$overrides,
			$tz_id,
			function ( $old_id, $new_start, $new_id ) use ( &$occurrences ) {
				unset( $occurrences[ $old_id ] );
				if ( '' !== $new_id ) {
					$occurrences[ $new_id ] = $new_start;
				}
			}
		);

		asort( $occurrences, SORT_NUMERIC );
		return $occurrences;
	}

	/**
	 * Merge storefront skip/remove (EXDATE) and conflict reschedules (EXDATE + RDATE).
	 *
	 * @param string               $ical_block  Base RRULE block.
	 * @param string               $tz_id       Series IANA timezone.
	 * @param string[]             $exdates     RECURRENCE-IDs to exclude.
	 * @param array<string, int>   $overrides   Map of original RECURRENCE-ID => new start (Fake UTC).
	 * @return string
	 */
	public static function apply_schedule_adjustments( $ical_block, $tz_id, $exdates = array(), $overrides = array() ) {
		$ical_block = self::rrule_line( (string) $ical_block ) ?: 'RRULE:FREQ=WEEKLY;COUNT=8';

		foreach ( (array) $exdates as $recurrence_id ) {
			$recurrence_id = self::sanitize_recurrence_id( $recurrence_id );
			if ( '' !== $recurrence_id ) {
				$ical_block = self::append_exdate( $ical_block, $recurrence_id, $tz_id );
			}
		}

		self::each_override(
			$overrides,
			$tz_id,
			function ( $old_id, $new_start, $new_id ) use ( &$ical_block, $tz_id ) {
				$ical_block = self::append_exdate( $ical_block, $old_id, $tz_id );
				if ( '' !== $new_id ) {
					$ical_block = self::append_rdate( $ical_block, $new_id, $tz_id );
				}
			}
		);

		return $ical_block;
	}

	/**
	 * RECURRENCE-ID (Ymd\THis) from a Fake-UTC slot timestamp.
	 *
	 * @param int    $fake_utc_ts Fake-UTC epoch.
	 * @param string $tz_id       IANA timezone.
	 * @return string
	 */
	public static function recurrence_id_from_fake_utc( $fake_utc_ts, $tz_id ) {
		$tz    = new DateTimeZone( $tz_id ? $tz_id : 'UTC' );
		$civil = gmdate( 'Y-m-d H:i:s', (int) $fake_utc_ts );
		$dt    = new DateTimeImmutable( $civil, $tz );
		return $dt->format( 'Ymd\THis' );
	}

	/**
	 * @param string $recurrence_id Raw id.
	 * @return string
	 */
	public static function sanitize_recurrence_id( $recurrence_id ) {
		return preg_replace( '/[^0-9T]/', '', (string) $recurrence_id );
	}

	/**
	 * Append an RDATE line for one occurrence.
	 *
	 * @param  string $ical_block    Existing iCal block.
	 * @param  string $recurrence_id RECURRENCE-ID (Ymd\THis in series TZ).
	 * @param  string $tz_id         IANA timezone.
	 * @return string
	 */
	public static function append_rdate( $ical_block, $recurrence_id, $tz_id = '' ) {
		return self::append_ical_datetime_line( $ical_block, 'RDATE', $recurrence_id, $tz_id );
	}

	/**
	 * Append EXDATE or RDATE when not already present.
	 *
	 * @param string $ical_block    Existing iCal block.
	 * @param string $property      EXDATE or RDATE.
	 * @param string $recurrence_id RECURRENCE-ID (Ymd\THis in series TZ).
	 * @param string $tz_id         IANA timezone.
	 * @return string
	 */
	protected static function append_ical_datetime_line( $ical_block, $property, $recurrence_id, $tz_id = '' ) {
		$recurrence_id = self::sanitize_recurrence_id( $recurrence_id );
		if ( '' === $recurrence_id || self::ical_has_datetime_line( $ical_block, $property, $recurrence_id ) ) {
			return $ical_block;
		}

		$line = self::format_ical_datetime_line( $property, $recurrence_id, $tz_id );
		if ( '' === $line ) {
			return $ical_block;
		}

		return rtrim( $ical_block, "\n" ) . "\n" . $line;
	}

	/**
	 * @param string $ical_block    iCal block.
	 * @param string $property      EXDATE or RDATE.
	 * @param string $recurrence_id RECURRENCE-ID.
	 * @return bool
	 */
	protected static function ical_has_datetime_line( $ical_block, $property, $recurrence_id ) {
		foreach ( preg_split( "/\r?\n/", (string) $ical_block ) as $line ) {
			if ( 0 !== strpos( $line, $property ) ) {
				continue;
			}
			if ( preg_match( '/:' . preg_quote( $recurrence_id, '/' ) . '$/', $line ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Build EXDATE/RDATE with TZID when the series timezone is known.
	 *
	 * php-rrule matches datetimes in the RRULE timezone; bare values use PHP default TZ and miss exclusions.
	 *
	 * @param string $property      EXDATE or RDATE.
	 * @param string $recurrence_id RECURRENCE-ID (Ymd\THis).
	 * @param string $tz_id         IANA timezone.
	 * @return string
	 */
	protected static function format_ical_datetime_line( $property, $recurrence_id, $tz_id = '' ) {
		$recurrence_id = self::sanitize_recurrence_id( $recurrence_id );
		if ( '' === $recurrence_id ) {
			return '';
		}

		$tz_id = is_string( $tz_id ) ? trim( $tz_id ) : '';
		if ( '' !== $tz_id && ! preg_match( '/^[A-Za-z0-9_+\-\/]+$/', $tz_id ) ) {
			$tz_id = '';
		}

		if ( '' !== $tz_id ) {
			return $property . ';TZID=' . $tz_id . ':' . $recurrence_id;
		}

		return $property . ':' . $recurrence_id;
	}

	/**
	 * Split an iCal block into trimmed lines (including single-line collapsed blocks).
	 *
	 * @param string $ical_block iCal block.
	 * @return string[]
	 */
	public static function parse_ical_lines( $ical_block ) {
		$ical_block = trim( (string) $ical_block );
		if ( '' === $ical_block ) {
			return array();
		}

		$lines = preg_split( "/\r\n|\r|\n/", $ical_block );
		if ( 1 === count( $lines ) && preg_match( '/\s+(EXDATE|RDATE)[;:]/i', $lines[0] ) ) {
			$lines = preg_split( '/\s+(?=(?:EXDATE|RDATE)[;:])/i', $lines[0] );
		}

		return array_values( array_filter( array_map( 'trim', $lines ) ) );
	}

	/**
	 * Sanitize a multiline iCal block from POST (preserve LF-separated EXDATE/RDATE lines).
	 *
	 * @param mixed $ical_block Raw value.
	 * @return string
	 */
	public static function sanitize_ical_block( $ical_block ) {
		if ( ! is_string( $ical_block ) ) {
			return '';
		}

		$out = array();
		foreach ( self::parse_ical_lines( $ical_block ) as $line ) {
			$line = trim( sanitize_text_field( $line ) );
			if ( '' !== $line && ( 0 === stripos( $line, 'RRULE:' ) || preg_match( '/^(EXDATE|RDATE)[;:]/i', $line ) ) ) {
				$out[] = $line;
			}
		}

		return implode( "\n", $out );
	}

	/**
	 * Extract the RRULE: line from a block.
	 *
	 * @param  string $ical_block iCal block.
	 * @return string
	 */
	public static function rrule_line( $ical_block ) {
		foreach ( self::parse_ical_lines( $ical_block ) as $line ) {
			if ( 0 === stripos( $line, 'RRULE:' ) ) {
				return $line;
			}
		}
		return '';
	}

	/**
	 * Parse COUNT= from the RRULE line (0 when absent or unbounded).
	 *
	 * @param  string $ical_block iCal block.
	 * @return int
	 */
	public static function parse_count_cap( $ical_block ) {
		$line = self::rrule_line( $ical_block );
		if ( preg_match( '/COUNT=(\d+)/i', $line, $matches ) ) {
			return (int) $matches[1];
		}
		return 0;
	}

	/**
	 * Range end for RRULE expansion from UNTIL or a COUNT-based day estimate.
	 *
	 * @param DateTimeImmutable $range_start Expansion start (series timezone).
	 * @param string            $ical_block  iCal block.
	 * @param string            $tz_id       IANA timezone.
	 * @return DateTimeImmutable
	 */
	public static function expansion_range_end( DateTimeImmutable $range_start, $ical_block, $tz_id ) {
		$until = self::parse_until_zoned( $ical_block, $tz_id );
		if ( $until instanceof DateTimeImmutable ) {
			return $until;
		}

		$count = self::parse_count_cap( $ical_block );
		if ( $count <= 0 ) {
			$count = WC_Product_Appointment::RECURRING_ABSOLUTE_MAX_OCCURRENCES;
		}

		return $range_start->modify( '+' . self::estimate_expansion_days( $ical_block, $count ) . ' days' );
	}

	/**
	 * Approximate calendar span of one RRULE step in days.
	 *
	 * Single source for freq/interval parsing; used by the suggestion window
	 * and the expansion-range estimator.
	 *
	 * @param string $ical_block iCal block.
	 * @return int Days; minimum 1.
	 */
	public static function interval_days( $ical_block ) {
		$line     = self::rrule_line( $ical_block );
		$freq     = 'WEEKLY';
		$interval = 1;
		if ( preg_match( '/FREQ=(DAILY|WEEKLY|MONTHLY)/i', $line, $m ) ) {
			$freq = strtoupper( $m[1] );
		}
		if ( preg_match( '/INTERVAL=(\d+)/i', $line, $m ) ) {
			$interval = max( 1, (int) $m[1] );
		}
		if ( 'DAILY' === $freq ) {
			return $interval;
		}
		if ( 'MONTHLY' === $freq ) {
			return $interval * 31;
		}
		return $interval * 7;
	}

	/**
	 * Conservative calendar span for expanding COUNT occurrences.
	 *
	 * @param string $ical_block iCal block.
	 * @param int    $count      Occurrence cap.
	 * @return int Days from range start.
	 */
	private static function estimate_expansion_days( $ical_block, $count ) {
		return max( 0, (int) $count - 1 ) * self::interval_days( $ical_block ) + 14;
	}

	/**
	 * @param string $ical_block iCal block.
	 * @param string $tz_id      IANA timezone.
	 * @return DateTimeImmutable|null
	 */
	public static function parse_until_zoned( $ical_block, $tz_id ) {
		$line = self::rrule_line( $ical_block );
		if ( ! preg_match( '/UNTIL=([^;]+)/i', $line, $matches ) ) {
			return null;
		}

		$raw = trim( $matches[1] );
		if ( '' === $raw ) {
			return null;
		}

		$tz = new DateTimeZone( $tz_id ? $tz_id : 'UTC' );

		try {
			if ( preg_match( '/^\d{8}T\d{6}Z$/i', $raw ) ) {
				$civil = substr( $raw, 0, 4 ) . '-' . substr( $raw, 4, 2 ) . '-' . substr( $raw, 6, 2 )
					. ' ' . substr( $raw, 9, 2 ) . ':' . substr( $raw, 11, 2 ) . ':' . substr( $raw, 13, 2 );
				return new DateTimeImmutable( $civil, $tz );
			}
			if ( preg_match( '/^\d{8}$/', $raw ) ) {
				$civil = substr( $raw, 0, 4 ) . '-' . substr( $raw, 4, 2 ) . '-' . substr( $raw, 6, 2 ) . ' 23:59:59';
				return new DateTimeImmutable( $civil, $tz );
			}
			return new DateTimeImmutable( $raw, $tz );
		} catch ( Exception $e ) {
			return null;
		}
	}

	/**
	 * {@see RRule::humanReadable()} options using WordPress date/time formats.
	 *
	 * @return array<string, mixed>
	 */
	public static function humanize_wp_date_opts() {
		$format = wc_appointments_datetime_format();

		return array(
			'date_formatter' => static function ( $date ) use ( $format ) {
				if ( ! $date instanceof \DateTimeInterface ) {
					return '';
				}

				$tz = $date->getTimezone();

				return wp_date( $format, $date->getTimestamp(), $tz instanceof \DateTimeZone ? $tz : null );
			},
		);
	}

	/**
	 * Human-readable recurrence summary for UI (My Account, admin).
	 *
	 * @param string $ical_block   iCal block containing RRULE.
	 * @param int    $dtstart_ts   Anchor Fake-UTC epoch.
	 * @param string               $tz_id        IANA timezone.
	 * @param array<string, mixed> $opts         Optional {@see RRule::humanReadable()} options; `count_cap` overrides COUNT=.
	 * @return string
	 */
	public static function humanize( $ical_block, $dtstart_ts = 0, $tz_id = 'UTC', array $opts = array() ) {
		$count_cap = isset( $opts['count_cap'] ) ? (int) $opts['count_cap'] : 0;
		$locale    = isset( $opts['locale'] ) ? (string) $opts['locale'] : '';
		unset( $opts['count_cap'], $opts['locale'] );

		if ( $count_cap > 0 ) {
			$ical_block = preg_replace( '/COUNT=\d+/i', 'COUNT=' . $count_cap, $ical_block );
		}

		$line = self::rrule_line( $ical_block );
		if ( '' === $line ) {
			return '';
		}

		try {
			$tz      = new DateTimeZone( $tz_id ? $tz_id : 'UTC' );
			$dtstart = $dtstart_ts > 0 ? self::fake_utc_to_zoned( $dtstart_ts, $tz ) : new DateTimeImmutable( 'now', $tz );
			$rule    = new RRule\RRule( $line, $dtstart );
			if ( '' === $locale ) {
				$locale = function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
			}
			if ( class_exists( 'Locale' ) ) {
				$locale = Locale::acceptFromHttp( $locale );
			}
			$summary = (string) $rule->humanReadable( array_merge( array( 'locale' => $locale ), $opts ) );
		} catch ( Exception $e ) {
			$summary = preg_replace( '/^RRULE:/i', '', $line );
		}

		return self::capitalize_first( $summary );
	}

	/**
	 * Uppercase the first character for sentence-style UI copy (e.g. "Daily, starting from …").
	 *
	 * @param string $text Human-readable recurrence summary.
	 * @return string
	 */
	private static function capitalize_first( $text ) {
		if ( '' === $text ) {
			return '';
		}
		if ( function_exists( 'mb_substr' ) && function_exists( 'mb_strtoupper' ) ) {
			return mb_strtoupper( mb_substr( $text, 0, 1 ) ) . mb_substr( $text, 1 );
		}

		return ucfirst( $text );
	}

	/**
	 * Project Fake-UTC civil clock into a real IANA datetime for RRule\RSet.
	 *
	 * @param  int          $ts Fake-UTC epoch.
	 * @param  DateTimeZone $tz Series IANA zone.
	 * @return DateTimeImmutable
	 */
	public static function fake_utc_to_zoned( $ts, DateTimeZone $tz ) {
		$civil = gmdate( 'Y-m-d H:i:s', $ts );
		return new DateTimeImmutable( $civil, $tz );
	}

	/**
	 * Slot-engine Unix instant → Fake UTC (store wall clock).
	 *
	 * @param int          $unix_ts Slot timestamp.
	 * @param DateTimeZone $tz      Series IANA zone.
	 * @return int
	 */
	public static function instant_to_fake_utc( $unix_ts, DateTimeZone $tz ) {
		return self::zoned_to_fake_utc( ( new DateTimeImmutable( '@' . (int) $unix_ts ) )->setTimezone( $tz ) );
	}

	/**
	 * Re-label Fake-UTC civil digits from one IANA zone to another (store ↔ booking).
	 *
	 * @param int            $fake_ts  Fake-UTC epoch.
	 * @param DateTimeZone   $from_tz  Source zone for wall digits.
	 * @param DateTimeZone   $to_tz    Target zone for wall digits.
	 * @return int
	 */
	public static function convert_fake_utc_axis( $fake_ts, DateTimeZone $from_tz, DateTimeZone $to_tz ) {
		$fake_ts = (int) $fake_ts;
		if ( $fake_ts <= 0 ) {
			return 0;
		}

		return self::zoned_to_fake_utc(
			self::fake_utc_to_zoned( $fake_ts, $from_tz )->setTimezone( $to_tz )
		);
	}

	/**
	 * Store wall clock from an IANA datetime as a Fake-UTC epoch.
	 *
	 * @param  DateTimeImmutable $dt Occurrence in series timezone.
	 * @return int
	 */
	private static function zoned_to_fake_utc( DateTimeImmutable $dt ) {
		$civil = $dt->format( 'Y-m-d H:i:s' );
		return (int) ( new DateTimeImmutable( $civil, new DateTimeZone( 'UTC' ) ) )->getTimestamp();
	}
}
