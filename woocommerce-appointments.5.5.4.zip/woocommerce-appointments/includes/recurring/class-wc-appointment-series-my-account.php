<?php
/**
 * My Account recurring series (list on Appointments, detail on view-series endpoint).
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Server-rendered series list on Appointments; detail at /my-account/view-series/{id}/.
 */
class WC_Appointment_Series_My_Account {

	/**
	 * Register My Account series endpoints and hooks.
	 *
	 * @return void
	 * @since 5.4.0
	 */
	public static function init() {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return;
		}

		add_action( 'init', array( __CLASS__, 'register_endpoints' ) );
		add_filter( 'woocommerce_get_query_vars', array( __CLASS__, 'register_query_vars' ) );
		add_filter( 'woocommerce_account_menu_item_classes', array( __CLASS__, 'highlight_appointments_menu_item' ), 10, 2 );
		add_filter( 'woocommerce_appointments_my_appointments_template_args', array( __CLASS__, 'filter_appointments_template_args' ), 20 );
		add_action( 'woocommerce_account_' . self::get_view_endpoint() . '_endpoint', array( __CLASS__, 'render_view_endpoint' ) );
		add_action( 'template_redirect', array( __CLASS__, 'template_redirect' ) );
		add_filter( 'woocommerce_appointments_reschedule_appointment_redirect', array( __CLASS__, 'filter_reschedule_context' ), 10, 2 );
		add_filter( 'woocommerce_appointments_reschedule_template_args', array( __CLASS__, 'filter_reschedule_context' ), 10, 1 );
	}

	/** @return string */
	public static function get_view_endpoint() {
		return apply_filters( 'woocommerce_appointments_account_view_series_endpoint', 'view-series' );
	}

	/** @return string */
	public static function get_legacy_series_endpoint() {
		return apply_filters( 'woocommerce_appointments_account_series_endpoint', 'series' );
	}

	/** @return string */
	public static function appointments_endpoint() {
		return apply_filters( 'woocommerce_appointments_account_endpoint', 'appointments' );
	}

	/** @return string */
	public static function get_appointments_url() {
		return wc_get_endpoint_url( self::appointments_endpoint(), '', wc_get_page_permalink( 'myaccount' ) );
	}

	/**
	 * Reschedule redirect URL or template context for series occurrences.
	 *
	 * When $value is template args, adds series_back_url and $series for reschedule scope radios.
	 *
	 * @param array<string, mixed>|string $value       Template args or redirect URL.
	 * @param WC_Appointment|null         $appointment Appointment (redirect filter only).
	 * @return array<string, mixed>|string
	 */
	public static function filter_reschedule_context( $value, $appointment = null ) {
		if ( is_array( $value ) ) {
			$appointment = ! empty( $value['appointment'] ) && $value['appointment'] instanceof WC_Appointment ? $value['appointment'] : null;
		}
		if ( ! $appointment instanceof WC_Appointment ) {
			return $value;
		}
		$url = self::series_detail_url_for_appointment( $appointment );
		if ( ! $url ) {
			return $value;
		}
		if ( is_array( $value ) ) {
			$value['series_back_url'] = $url;
			try {
				$value['series'] = new WC_Appointment_Series( (int) $appointment->get_meta( '_wca_series_id' ) );
			} catch ( Exception $e ) {
				unset( $e );
			}
			return $value;
		}
		return $url;
	}

	/**
	 * My Account reschedule POST for series occurrence(s).
	 *
	 * Reads wca_series_scope from POST (one|future; customer cannot choose all).
	 *
	 * @param WC_Appointment       $appointment      Occurrence.
	 * @param array<string, mixed> $appointment_data Posted slot data (_start_date, _end_date).
	 * @return true|WP_Error
	 */
	public static function reschedule_occurrence_from_post( WC_Appointment $appointment, array $appointment_data ) {
		$series = self::get_owned_series( (int) $appointment->get_meta( '_wca_series_id' ) );
		if ( ! $series || ! $series->customer_can_reschedule_occurrence( $appointment ) ) {
			return new WP_Error( 'forbidden', __( 'You cannot reschedule this occurrence.', 'woocommerce-appointments' ) );
		}
		$new_start = isset( $appointment_data['_start_date'] ) ? (int) $appointment_data['_start_date'] : 0;
		$new_end   = isset( $appointment_data['_end_date'] ) ? (int) $appointment_data['_end_date'] : 0;
		if ( $new_start <= 0 || $new_end <= $new_start ) {
			return new WP_Error( 'invalid_dates', __( 'Select a valid appointment time.', 'woocommerce-appointments' ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$scope  = isset( $_POST['wca_series_scope'] ) ? sanitize_key( wp_unslash( $_POST['wca_series_scope'] ) ) : 'one';
		$scope  = in_array( $scope, array( 'one', 'future' ), true ) ? $scope : 'one';
		$result = WC_Appointment_Series_Scope::apply_reschedule( $appointment, $new_start, $new_end, $scope );
		return is_wp_error( $result ) ? $result : true;
	}

	/**
	 * @param int $series_id Series id (0 = appointments list URL).
	 * @return string
	 */
	public static function get_url( $series_id = 0 ) {
		return $series_id > 0
			? wc_get_endpoint_url( self::get_view_endpoint(), absint( $series_id ), wc_get_page_permalink( 'myaccount' ) )
			: self::get_appointments_url();
	}

	/**
	 * @param int $series_page Series list page number.
	 * @return string
	 */
	public static function get_appointments_series_page_url( $series_page = 1 ) {
		$url = self::get_appointments_url();
		return $series_page > 1 ? add_query_arg( 'wca_series_page', absint( $series_page ), $url ) : $url;
	}

	/** @return int */
	public static function get_current_series_id() {
		global $wp;
		return ( is_account_page() && isset( $wp->query_vars[ self::get_view_endpoint() ] ) )
			? absint( $wp->query_vars[ self::get_view_endpoint() ] )
			: 0;
	}

	/**
	 * @param int $user_id  Customer user id.
	 * @param int $page     Page number (1-based).
	 * @param int $per_page Items per page.
	 * @return array{series: WC_Appointment_Series[], has_more: bool}
	 */
	public static function query_for_user( $user_id, $page, $per_page ) {
		$user_id  = absint( $user_id );
		$page     = max( 1, (int) $page );
		$per_page = max( 1, (int) $per_page );

		if ( ! $user_id ) {
			return array( 'series' => array(), 'has_more' => false );
		}

		$store  = WC_Data_Store::load( WC_Appointment_Series::DATA_STORE );
		$args   = array( 'customer_id' => $user_id );
		$series = $store->query( array_merge( $args, array( 'limit' => $per_page + 1, 'offset' => ( $page - 1 ) * $per_page ) ) );
		$more   = count( $series ) > $per_page;

		return array(
			'series'   => $more ? array_slice( $series, 0, $per_page ) : $series,
			'has_more' => $more,
		);
	}

	/**
	 * Register rewrite endpoints for view-series.
	 *
	 * @return void
	 * @since 5.4.0
	 */
	public static function register_endpoints() {
		add_rewrite_endpoint( self::get_view_endpoint(), EP_PAGES );
		add_rewrite_endpoint( self::get_legacy_series_endpoint(), EP_PAGES );

		if ( ! get_option( 'wca_view_series_endpoints_registered' ) ) {
			update_option( 'woocommerce_queue_flush_rewrite_rules', 'yes' );
			add_option( 'wca_view_series_endpoints_registered', '1' );
		}
	}

	/**
	 * @param array<string, string> $vars Query vars.
	 * @return array<string, string>
	 */
	public static function register_query_vars( $vars ) {
		$view            = self::get_view_endpoint();
		$vars[ $view ]   = $view;
		$legacy          = self::get_legacy_series_endpoint();
		$vars[ $legacy ] = $legacy;
		return $vars;
	}

	/**
	 * @param string[] $classes  Menu item classes.
	 * @param string   $endpoint Account endpoint.
	 * @return string[]
	 */
	public static function highlight_appointments_menu_item( $classes, $endpoint ) {
		if ( self::appointments_endpoint() === $endpoint && self::get_current_series_id() > 0 && ! in_array( 'is-active', $classes, true ) ) {
			$classes[] = 'is-active';
		}
		return $classes;
	}

	/**
	 * @param array<string, mixed> $args Template args.
	 * @return array<string, mixed>
	 */
	public static function filter_appointments_template_args( $args ) {
		global $wp;
		if ( ! isset( $wp->query_vars[ self::appointments_endpoint() ] ) ) {
			return $args;
		}
		$per_page = isset( $args['appointments_per_page'] ) ? (int) $args['appointments_per_page'] : 10;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page     = max( 1, isset( $_GET['wca_series_page'] ) ? absint( $_GET['wca_series_page'] ) : 1 );
		$section  = self::query_for_user( get_current_user_id(), $page, $per_page );
		$args['series_section'] = $section;
		$args['series_page']    = $page;
		return $args;
	}

	/**
	 * @param int|string $series_id Series id from the endpoint.
	 * @return void
	 */
	public static function render_view_endpoint( $series_id ) {
		$series = self::get_owned_series( absint( $series_id ) );
		if ( ! $series ) {
			wp_safe_redirect( self::get_appointments_url() );
			exit;
		}

		$payment = $series->get_payment_snapshot();
		$product = $series->get_appointable_product();
		$order   = ( $order_id = $series->resolve_parent_order_id() ) > 0 ? wc_get_order( $order_id ) : null;
		$pattern = $series->get_pattern_summary();
		$product_mark = $product
			? sprintf( '<a href="%1$s">%2$s</a>', esc_url( get_permalink( $product->get_id() ) ), esc_html( $product->get_name() ) )
			: '&mdash;';

		$detail_rows = array();
		if ( $pattern ) {
			$detail_rows[] = array( __( 'Schedule', 'woocommerce-appointments' ), esc_html( $pattern ) );
		}
		$series_location = $series->get_meta( '_wca_location', true );
		$location_display = ( is_array( $series_location ) && class_exists( 'WC_Appointments_Location' ) )
			? WC_Appointments_Location::format_snapshot_for_display( $series_location )
			: '';
		if ( $location_display ) {
			$detail_rows[] = array(
				get_wc_appointment_data_label( 'location', $product ),
				esc_html( $location_display ),
			);
		}
		$balance_order_id = (int) ( $payment['balance_order_id'] ?? 0 );
		if ( $order ) {
			$detail_rows[] = array(
				$balance_order_id > 0 ? __( 'Original order', 'woocommerce-appointments' ) : __( 'Order', 'woocommerce-appointments' ),
				'<a href="' . esc_url( $order->get_view_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a>',
			);
		}
		if ( $balance_order_id > 0 ) {
			$balance_order = wc_get_order( $balance_order_id );
			if ( $balance_order ) {
				$detail_rows[] = array(
					__( 'Balance order', 'woocommerce-appointments' ),
					'<a href="' . esc_url( $balance_order->get_view_order_url() ) . '">#' . esc_html( $balance_order->get_order_number() ) . '</a>',
				);
			}
		}
		if ( ! empty( $payment['has_open_balance'] ) ) {
			$detail_rows[] = array( __( 'Remaining balance', 'woocommerce-appointments' ), esc_html( $payment['balance_due_formatted'] ?? '' ) );
		}

		wc_get_template(
			'myaccount/view-series.php',
			apply_filters(
				'woocommerce_appointments_series_detail_template_args',
				array(
					'series'                    => $series,
					'timezone_indicator_html' => WC_Appointments_Timezone_Helper::get_my_account_indicator_html(),
					'status_message'          => apply_filters(
						'woocommerce_appointments_series_details_status',
						sprintf(
							/* translators: 1: series number 2: product name 3: series status */
							esc_html__( 'Series #%1$s · %2$s — %3$s.', 'woocommerce-appointments' ),
							'<mark class="series-number">' . esc_html( (string) $series->get_id() ) . '</mark>',
							'<mark class="series-product">' . $product_mark . '</mark>', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							'<mark class="series-status">' . esc_html( WC_Appointment_Series::get_status_label( $series->get_status() ) ) . '</mark>'
						),
						$series
					),
					'detail_rows'               => $detail_rows,
					'has_actions'               => ! empty( $payment['has_open_balance'] ) || $series->customer_can_cancel_series(),
					'payment'                   => $payment,
					'appointments'              => $series->get_occurrence_appointments( 50 ),
					'product'                   => $product,
					'order'                     => $order,
					'series_url'                => self::get_url( $series->get_id() ),
				)
			),
			'woocommerce-appointments',
			WC_APPOINTMENTS_TEMPLATE_PATH
		);
	}

	/**
	 * Legacy redirects and series POST actions on view-series.
	 *
	 * @return void
	 * @since 5.4.0
	 */
	public static function template_redirect() {
		if ( ! is_account_page() ) {
			return;
		}

		global $wp;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$legacy_id = isset( $_GET['wca_series'] ) ? absint( $_GET['wca_series'] ) : 0;
		if ( isset( $wp->query_vars[ self::get_legacy_series_endpoint() ] ) ) {
			wp_safe_redirect( $legacy_id ? self::get_url( $legacy_id ) : self::get_appointments_url() );
			exit;
		}
		if ( isset( $wp->query_vars[ self::appointments_endpoint() ] ) ) {
			$tab_raw    = filter_input( INPUT_GET, 'wca_tab' );
			$legacy_tab = is_string( $tab_raw ) && 'series' === wc_clean( wp_unslash( $tab_raw ) );
			if ( $legacy_id || $legacy_tab ) {
				wp_safe_redirect( $legacy_id ? self::get_url( $legacy_id ) : self::get_appointments_url() );
				exit;
			}
		}

		if ( ! is_user_logged_in() || ! self::get_current_series_id() ) {
			return;
		}
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : '';
		$action_raw = filter_input( INPUT_POST, 'wca_series_action' );
		if ( 'POST' !== $method || ! is_string( $action_raw ) || '' === $action_raw ) {
			return;
		}

		$series_id = self::get_current_series_id();
		$action    = sanitize_key( wp_unslash( $action_raw ) );
		$fail      = __( 'An error occurred. Please try again.', 'woocommerce-appointments' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'wca_series_action_' . $series_id ) ) {
			self::redirect_detail( $series_id, $fail, 'error' );
		}

		$series = self::get_owned_series( $series_id );
		if ( ! $series ) {
			wc_add_notice( __( 'You cannot manage this series.', 'woocommerce-appointments' ), 'error' );
			wp_safe_redirect( self::get_appointments_url() );
			exit;
		}

		if ( 'pay_balance' === $action ) {
			$order = WC_Appointment_Series_Payment::ensure_payable_balance_order( $series );
			if ( is_wp_error( $order ) ) {
				self::redirect_detail( $series_id, $order->get_error_message(), 'error' );
			}
			wp_safe_redirect( $order->get_checkout_payment_url() );
			exit;
		}

		if ( 'cancel_future' === $action ) {
			if ( ! $series->customer_can_cancel_series() ) {
				self::redirect_detail( $series_id, __( 'You cannot cancel appointments in this series.', 'woocommerce-appointments' ), 'error' );
			}
			// Anchor = next upcoming occurrence for a deterministic future cutoff.
			$anchor = current( $series->get_occurrence_appointments( 1, time() ) ) ?: null;
			if ( ! $anchor ) {
				self::redirect_detail( $series_id, $fail, 'error' );
			}
			$result = WC_Appointment_Series_Scope::apply_status( $anchor, 'cancelled', WC_Appointment_Series_Scope::FUTURE );
			$notice = __( 'Future appointments in this series were cancelled.', 'woocommerce-appointments' );
		} elseif ( 'skip' === $action ) {
			$recurrence_raw = filter_input( INPUT_POST, 'wca_recurrence_id' );
			$rid            = is_string( $recurrence_raw )
				? WC_Appointment_Series_RRule::sanitize_recurrence_id( wp_unslash( $recurrence_raw ) )
				: '';
			$appt = $series->get_occurrence_by_recurrence_id( $rid );
			if ( ! $appt || ! $series->customer_can_cancel_occurrence( $appt ) ) {
				self::redirect_detail( $series_id, __( 'You cannot cancel this occurrence.', 'woocommerce-appointments' ), 'error' );
			}
			$result = WC_Appointment_Series_Scope::apply_status( $appt, 'cancelled', WC_Appointment_Series_Scope::ONE );
			$notice = __( 'That occurrence was cancelled.', 'woocommerce-appointments' );
		} else {
			self::redirect_detail( $series_id, $fail, 'error' );
			return;
		}

		if ( is_wp_error( $result ) ) {
			$msg = 'version_conflict' === $result->get_error_code() ? __( 'This series was updated elsewhere. Please try again.', 'woocommerce-appointments' ) : $result->get_error_message();
			self::redirect_detail( $series_id, $msg, 'error' );
		}
		self::redirect_detail( $series_id, $notice, 'success' );
	}

	/**
	 * @param int $series_id Series ID.
	 * @return WC_Appointment_Series|null
	 */
	public static function get_owned_series( $series_id ) {
		$series = new WC_Appointment_Series( absint( $series_id ) );
		if ( ! $series->get_id() || (int) $series->get_customer_id() !== get_current_user_id() ) {
			return null;
		}
		return $series;
	}

	/**
	 * Output POST form for view-series actions (pay balance, cancel future, skip).
	 *
	 * @param WC_Appointment_Series $series       Series.
	 * @param string                $action       wca_series_action value.
	 * @param string                $button_label Button label.
	 * @param array<string, mixed>  $args         Optional class, confirm, hidden fields.
	 * @return void
	 */
	public static function render_post_action_form( WC_Appointment_Series $series, $action, $button_label, $args = array() ) {
		$class   = isset( $args['class'] ) ? $args['class'] : 'woocommerce-button button anowrap';
		$confirm = ! empty( $args['confirm'] ) ? $args['confirm'] : '';
		$hidden  = isset( $args['hidden'] ) ? (array) $args['hidden'] : array();
		$nonce   = 'wca_series_action_' . $series->get_id();
		?>
		<form method="post" style="display:inline;">
			<?php wp_nonce_field( $nonce ); ?>
			<input type="hidden" name="wca_series_action" value="<?php echo esc_attr( $action ); ?>" />
			<input type="hidden" name="wca_series_version" value="<?php echo esc_attr( (string) (int) $series->get_version() ); ?>" />
			<?php foreach ( $hidden as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $value ); ?>" />
			<?php endforeach; ?>
			<button type="submit" class="<?php echo esc_attr( $class ); ?>"<?php echo $confirm ? ' onclick="return confirm(\'' . esc_js( $confirm ) . '\');"' : ''; ?>><?php echo esc_html( $button_label ); ?></button>
		</form>
		<?php
	}

	/**
	 * @param WC_Appointment $appointment Occurrence.
	 * @return string
	 */
	protected static function series_detail_url_for_appointment( WC_Appointment $appointment ) {
		$series = self::get_owned_series( (int) $appointment->get_meta( '_wca_series_id' ) );
		return $series ? self::get_url( $series->get_id() ) : '';
	}

	/**
	 * @param int    $series_id Series id.
	 * @param string $message   Notice text.
	 * @param string $type      Notice type (error|success).
	 * @return void
	 */
	protected static function redirect_detail( $series_id, $message, $type = 'error' ) {
		if ( $message ) {
			wc_add_notice( $message, $type );
		}
		wp_safe_redirect( $series_id ? self::get_url( $series_id ) : self::get_appointments_url() );
		exit;
	}
}
