<?php
/**
 * Pure series expansion, conflict detection, and pricing summary.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Preview helper (no DB writes).
 */
class WC_Appointment_Series_Preview {

	const DEFAULT_MAX_OCCURRENCES = 52;

	/**
	 * Expand RRULE and detect slot conflicts.
	 *
	 * @param array<string, mixed> $args {
	 *     @type int    $product_id       Product id.
	 *     @type int    $dtstart_ts       Anchor (Fake UTC).
	 *     @type string $timezone         IANA timezone.
	 *     @type string $rrule            iCal block.
	 *     @type int    $duration_seconds Duration.
	 *     @type int    $staff_id         Optional staff id for conflict checks.
	 *     @type int    $qty              Quantity per occurrence (default 1).
	 *     @type int    $max_occurrences  Cap on expanded rows (default 52).
	 * }
	 * @param array<string, mixed> $args Preview args.
	 * @param bool                 $include_pricing Include pricing in summary.
	 * @param bool                 $skip_normalize  Skip normalize_preview_args (caller already normalized).
	 * @return array<string, mixed>
	 */
	public function preview( $args, $include_pricing = true, $skip_normalize = false ) {
		if ( ! $skip_normalize ) {
			$args = WC_Appointment_Series_Request::normalize_preview_args( $args );
		}

		$args = wp_parse_args(
			$args,
			array(
				'staff_id'        => 0,
				'qty'             => 1,
				'max_occurrences' => self::DEFAULT_MAX_OCCURRENCES,
				'payment_model'   => '',
			)
		);

		$product = wc_get_product( (int) $args['product_id'] );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			return array(
				'occurrences' => array(),
				'conflicts'   => array(),
				'summary'     => array(
					'occurrence_count' => 0,
					'conflict_count'   => 0,
					'billable_count'   => 0,
				),
				'error'       => 'invalid_product',
			);
		}

		$timezone        = (string) ( $args['timezone'] ?? wc_timezone_string() );
		$effective_rrule = WC_Appointment_Series_RRule::apply_schedule_adjustments(
			(string) ( $args['rrule'] ?? '' ),
			$timezone,
			(array) ( $args['exdates'] ?? array() ),
			(array) ( $args['overrides'] ?? array() )
		);
		$occurrences     = $this->expand_occurrences( $args );
		$pricing_only = ! empty( $args['pricing_only'] );

		// Storefront pricing-only refresh: skip conflict detection; checkout re-validates.
		if ( $pricing_only ) {
			$conflicts = self::sanitize_known_conflicts(
				(array) ( $args['conflicts'] ?? array() ),
				$occurrences
			);
		} else {
			$conflicts   = $this->detect_conflicts(
				$product,
				$occurrences,
				(int) $args['staff_id'],
				max( 1, (int) $args['qty'] ),
				(int) $args['dtstart_ts'],
				max( 1, (int) $args['duration_seconds'] ),
				(string) ( $args['timezone'] ?? '' ),
				(int) ( $args['location_id'] ?? 0 )
			);
		}
		$conflicts = self::filter_conflicts_excluding_rescheduled(
			$conflicts,
			(array) ( $args['overrides'] ?? array() ),
			(string) ( $args['timezone'] ?? wc_timezone_string() )
		);
		$occurrence_count = count( $occurrences );
		$conflict_count   = count( $conflicts );
		$billable         = max( 0, $occurrence_count - $conflict_count );

		$payment_model        = $this->resolve_preview_payment_model( $product, (string) $args['payment_model'] );
		$subtotal             = 0.0;
		$total_price          = 0.0;
		$total_price_html = '';
		$due_today        = 0.0;
		$balance_due      = 0.0;

		if ( $include_pricing ) {
			$pricing     = $this->resolve_series_pricing( $product, $billable, $args, $occurrences, $conflicts );
			$subtotal    = $pricing['subtotal'];
			$total_price = WC_Appointments_Cost_Calculation::apply_recurring_package_pricing( $subtotal, $product, $billable );
			$pay_first   = WC_Appointment_Series::PAYMENT_PAY_FIRST === $payment_model;
			$checkout_net     = $pay_first ? $pricing['first_session'] : $total_price;
			$due_today        = $checkout_net;
			$balance_due      = $pay_first ? WC_Appointment_Series::calculate_balance_due( $total_price, $checkout_net ) : 0.0;
			$total_price_html = $this->format_series_cost_footer_html( $product, $pay_first, $checkout_net, $total_price, $billable, $subtotal );
		}
		$formatted = $this->format_occurrences( $occurrences, $product, (string) ( $args['timezone'] ?? '' ) );
		return array(
			'occurrences' => $formatted,
			'conflicts'   => $conflicts,
			'summary'     => array(
				'occurrence_count' => $occurrence_count,
				'conflict_count'   => $conflict_count,
				'billable_count'   => $billable,
				'subtotal'             => $subtotal,
				'total_price'          => $total_price,
				'total_price_html' => $total_price_html,
				'due_today'        => $due_today,
				'balance_due'      => $balance_due,
				'payment_model'        => $payment_model,
				'effective_rrule'  => $effective_rrule,
			),
		);
	}

	/**
	 * Storefront series preview (wc-ajax shares WooCommerce cart session with calendar/slots).
	 */
	public static function wc_ajax_preview(): void {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			wp_send_json_error( array( 'message' => __( 'Recurring appointments are disabled.', 'woocommerce-appointments' ) ), 503 );
		}

		if ( class_exists( 'WC_Appointments_Rate_Limiter' ) ) {
			WC_Appointments_Rate_Limiter::throttle_guest_read_with_optional_nonce(
				'series_preview',
				WC_Appointments_Rate_Limiter::GUEST_READ_MAX_REQUESTS,
				WC_Appointments_Rate_Limiter::GUEST_READ_WINDOW_SECONDS
			);
		}

		$body    = json_decode( file_get_contents( 'php://input' ), true );
		$payload = self::payload_from_body( is_array( $body ) ? $body : array() );

		if ( is_wp_error( $payload ) ) {
			wp_send_json_error( array( 'message' => $payload->get_error_message() ), 400 );
		}
		wp_send_json( $payload );
	}

	/**
	 * Preview payload from a JSON body (wc-ajax and REST).
	 *
	 * @param array<string, mixed> $body Request body.
	 * @return array<string, mixed>|WP_Error
	 */
	public static function payload_from_body( array $body ) {
		$args       = WC_Appointment_Series_Request::preview_args_from_rest( $body );
		$suggest_id = isset( $body['suggest_recurrence_id'] ) ? WC_Appointment_Series_RRule::sanitize_recurrence_id( (string) $body['suggest_recurrence_id'] ) : '';

		$preview = new self();

		if ( '' !== $suggest_id ) {
			$args['suggest_start_ts'] = (int) ( $body['suggest_start_ts'] ?? 0 );

			$result = array(
				'suggestions' => $preview->suggest_occurrence_alternatives( $args, $suggest_id ),
			);
			return $result;
		}

		// Args already normalized in preview_args_from_rest (incl. one-shot axis convert).
		$result = $preview->preview( $args, true, true );

		if ( ! empty( $result['error'] ) ) {
			return new WP_Error( 'invalid-product', __( 'Invalid appointable product.', 'woocommerce-appointments' ) );
		}

		$summary = $result['summary'] ?? array();

		return array_merge(
			$result,
			array(
				'total_price'      => $summary['total_price'] ?? 0,
				'total_price_html' => $summary['total_price_html'] ?? '',
			)
		);
	}

	/**
	 * Resolve the payment model for preview, falling back to the product default.
	 *
	 * @param WC_Product $product       Appointable product.
	 * @param string     $requested     Requested model ('prepaid'|'pay_first'|'').
	 * @return string
	 */
	protected function resolve_preview_payment_model( $product, $requested ) {
		$appt = WC_Product_Appointment::as_appointment_product( $product );
		return $appt ? $appt->resolve_recurring_payment_model( $requested ) : WC_Appointment_Series::PAYMENT_PREPAID;
	}

	/**
	 * Drop conflicts for storefront-rescheduled occurrences (original id, RDATE id, or chosen start).
	 *
	 * @param array<int, array<string, mixed>> $conflicts Conflict rows.
	 * @param array<string, int>               $overrides RECURRENCE-ID => Fake UTC start.
	 * @param string                           $timezone  Series IANA timezone.
	 * @return array<int, array<string, mixed>>
	 */
	public static function filter_conflicts_excluding_rescheduled( $conflicts, $overrides, $timezone ) {
		if ( empty( $overrides ) || empty( $conflicts ) ) {
			return $conflicts;
		}

		$ids = $starts = array();
		WC_Appointment_Series_RRule::each_override(
			$overrides,
			$timezone,
			function ( $old_id, $new_start, $new_id ) use ( &$ids, &$starts ) {
				$ids[ $old_id ]           = true;
				$starts[ $new_start ]     = true;
				if ( '' !== $new_id ) {
					$ids[ $new_id ] = true;
				}
			}
		);
		if ( ! $ids && ! $starts ) {
			return $conflicts;
		}

		return array_values(
			array_filter(
				$conflicts,
				function ( $conflict ) use ( $ids, $starts ) {
					$rid = WC_Appointment_Series_RRule::sanitize_recurrence_id( (string) ( $conflict['recurrence_id'] ?? '' ) );
					if ( '' !== $rid && ! empty( $ids[ $rid ] ) ) {
						return false;
					}
					$ts = (int) ( $conflict['start_ts'] ?? 0 );
					return ! ( $ts > 0 && ! empty( $starts[ $ts ] ) );
				}
			)
		);
	}

	/**
	 * Suggest conflict-free anchor dtstarts (expand + conflicts only per candidate).
	 *
	 * @param array<string, mixed> $base_args       Preview args (rrule, product, horizon, etc.).
	 * @param int[]                $dtstart_offsets Seconds to add to anchor dtstart per candidate.
	 * @param int                  $max_suggestions Max results.
	 * @return array<int, array<string, mixed>>
	 */
	public function suggest_dtstarts( $base_args, $dtstart_offsets, $max_suggestions = 3 ) {
		$base_args = wp_parse_args(
			$base_args,
			array(
				'staff_id'        => 0,
				'qty'             => 1,
				'max_occurrences' => self::DEFAULT_MAX_OCCURRENCES,
			)
		);

		$product = wc_get_product( (int) $base_args['product_id'] );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			return array();
		}

		$staff_id = (int) $base_args['staff_id'];
		$qty      = max( 1, (int) $base_args['qty'] );
		$anchor   = (int) $base_args['dtstart_ts'];

		$suggestions = array();
		foreach ( $dtstart_offsets as $offset ) {
			$candidate                 = $base_args;
			$candidate['dtstart_ts'] = $anchor + (int) $offset;

			$occurrences = $this->expand_occurrences( $candidate );
			$conflicts   = $this->detect_conflicts(
				$product,
				$occurrences,
				$staff_id,
				$qty,
				(int) $candidate['dtstart_ts'],
				max( 1, (int) ( $candidate['duration_seconds'] ?? 0 ) ),
				(string) ( $base_args['timezone'] ?? '' ),
				(int) ( $base_args['location_id'] ?? 0 )
			);

			if ( empty( $conflicts ) && ! empty( $occurrences ) ) {
				$occurrence_count = count( $occurrences );
				$suggestions[]    = array(
					'dtstart_ts' => $candidate['dtstart_ts'],
					'summary'    => array(
						'occurrence_count' => $occurrence_count,
						'conflict_count'   => 0,
						'billable_count'   => $occurrence_count,
						'total_price'      => 0,
					),
				);
			}

			if ( count( $suggestions ) >= $max_suggestions ) {
				break;
			}
		}

		return $suggestions;
	}

	/**
	 * @param array<string, mixed> $args Preview args.
	 * @return array<string, int> recurrence_id => start_ts.
	 */
	public function expand_occurrences( $args ) {
		$tz_id     = (string) $args['timezone'];
		$tz        = new DateTimeZone( $tz_id );
		$dtstart   = (int) $args['dtstart_ts'];
		$max       = max( 1, (int) $args['max_occurrences'] );
		$duration  = max( 1, (int) $args['duration_seconds'] );
		$ical = WC_Appointment_Series_RRule::apply_schedule_adjustments(
			(string) ( $args['rrule'] ?? '' ),
			$tz_id,
			(array) ( $args['exdates'] ?? array() )
		);

		$range_start = WC_Appointment_Series_RRule::fake_utc_to_zoned( $dtstart, $tz );
		$range_end   = WC_Appointment_Series_RRule::expansion_range_end( $range_start, $ical, $tz_id );

		$count_cap = WC_Appointment_Series_RRule::parse_count_cap( $ical );
		$limit     = $count_cap > 0 ? min( $max, $count_cap ) : $max;

		$rrule = new WC_Appointment_Series_RRule(
			$ical,
			$dtstart,
			$tz_id
		);

		return WC_Appointment_Series_RRule::merge_occurrence_overrides(
			$rrule->expand( $range_start, $range_end, $limit ),
			(array) ( $args['overrides'] ?? array() ),
			$tz_id
		);
	}

	/**
	 * @param WC_Product           $product           Appointable product.
	 * @param array<string, int>   $occurrences       recurrence_id => start_ts.
	 * @param int                  $staff_id          Staff id (0 = product default path).
	 * @param int                  $qty               Quantity.
	 * @param int                  $anchor_ts         Selected first slot (Fake UTC); skipped — already chosen on the form.
	 * @param int                  $duration_seconds  Occurrence length (matches RRULE expansion).
	 * @param string               $booking_timezone  Booking timezone for axis conversion.
	 * @param int                  $location_id       Location id for per-location capacity.
	 * @return array<int, array<string, string>>
	 */
	public function detect_conflicts( $product, $occurrences, $staff_id = 0, $qty = 1, $anchor_ts = 0, $duration_seconds = 0, $booking_timezone = '', $location_id = 0 ) {
		$conflicts = array();

		if ( ! is_wc_appointment_product( $product ) ) {
			return $conflicts;
		}

		if ( empty( $occurrences ) ) {
			return $conflicts;
		}

		$anchor_ts   = (int) $anchor_ts;
		$qty         = max( 1, (int) $qty );
		$staff_id    = (int) $staff_id;
		$location_id = (int) $location_id;

		$duration = max( 1, (int) $duration_seconds );
		if ( $duration <= 1 ) {
			$duration = max( 1, (int) $product->get_duration_in_minutes() * MINUTE_IN_SECONDS, HOUR_IN_SECONDS );
		}

		$booking_tz = wc_appointments_series_booking_timezone( $product, $booking_timezone );
		$staff_arg  = $staff_id > 0 ? $staff_id : null;
		$checks     = array();
		$range_start = PHP_INT_MAX;
		$range_end   = 0;

		foreach ( $occurrences as $recurrence_id => $start_ts ) {
			$start_ts = (int) $start_ts;
			if ( $anchor_ts > 0 && $start_ts === $anchor_ts ) {
				continue;
			}

			$check_start = $booking_tz
				? WC_Appointment_Series_RRule::convert_fake_utc_axis( $start_ts, $booking_tz, wp_timezone() )
				: $start_ts;
			$check_end   = $check_start + $duration;
			if ( $product->get_availability_span() ) {
				$check_end = wc_appointments_availability_span_end_date( $product, $check_start );
			}

			$checks[ $recurrence_id ] = array(
				'start_ts'    => $start_ts,
				'check_start' => $check_start,
				'check_end'   => $check_end,
			);
			$range_start = min( $range_start, $check_start );
			$range_end   = max( $range_end, $check_end );
		}

		if ( empty( $checks ) ) {
			return $conflicts;
		}
		$collections = WC_Appointments_Controller::load_slots_collections_for_range( $product, $range_start, $range_end, $staff_arg, $location_id );
		$use_batch     = is_array( $collections ) && ! empty( $collections );

		foreach ( $checks as $recurrence_id => $check ) {
			$start_ts    = (int) $check['start_ts'];
			$check_start = (int) $check['check_start'];
			$check_end   = (int) $check['check_end'];

			try {
				$available = WC_Appointments_Controller::get_indexed_total_available_for_range(
					$product,
					$check_start,
					$check_end,
					$staff_arg,
					$qty,
					$use_batch ? $collections : null,
					$location_id
				);
			} catch ( Exception $e ) {
				$conflicts[] = array(
					'recurrence_id' => (string) $recurrence_id,
					'start_ts'      => (string) $start_ts,
					'reason'        => 'slot_unavailable',
				);
				continue;
			}

			if ( WC_Appointments_Controller::is_indexed_range_unavailable( $product, $available, $staff_id, $qty ) ) {
				$conflicts[] = array(
					'recurrence_id' => (string) $recurrence_id,
					'start_ts'      => (string) $start_ts,
					'reason'        => 'slot_unavailable',
				);
			}
		}

		return $conflicts;
	}

	/**
	 * Normalize client-supplied conflicts for pricing-only preview (storefront UX).
	 *
	 * @param array<int, array<string, mixed>> $conflicts   Conflict rows from the client.
	 * @param array<string, int>               $occurrences Expanded occurrence map.
	 * @return array<int, array<string, string>>
	 */
	public static function sanitize_known_conflicts( $conflicts, $occurrences ) {
		if ( empty( $conflicts ) || empty( $occurrences ) ) {
			return array();
		}

		$out = array();
		foreach ( $conflicts as $conflict ) {
			if ( ! is_array( $conflict ) ) {
				continue;
			}

			$recurrence_id = WC_Appointment_Series_RRule::sanitize_recurrence_id( (string) ( $conflict['recurrence_id'] ?? '' ) );
			if ( '' === $recurrence_id || ! isset( $occurrences[ $recurrence_id ] ) ) {
				continue;
			}

			$out[] = array(
				'recurrence_id' => $recurrence_id,
				'start_ts'      => (string) (int) $occurrences[ $recurrence_id ],
				'reason'        => 'slot_unavailable',
			);
		}

		return $out;
	}

	/**
	 * Nearest bookable Fake-UTC times for one unavailable occurrence (slots engine).
	 *
	 * @param array<string, mixed> $args          Preview args.
	 * @param string               $recurrence_id Target RECURRENCE-ID.
	 * @param int                  $limit         Max suggestions.
	 * @return array<int, array{start_ts: int, display_label: string}> Series Fake-UTC starts, ascending.
	 */
	public function suggest_occurrence_alternatives( $args, $recurrence_id, $limit = 6 ) {
		$recurrence_id = WC_Appointment_Series_RRule::sanitize_recurrence_id( $recurrence_id );
		if ( '' === $recurrence_id ) {
			return array();
		}

		$limit   = max( 1, min( 10, (int) $limit ) );
		$product = wc_get_product( (int) $args['product_id'] );
		$appt    = $product ? WC_Product_Appointment::as_appointment_product( $product ) : null;

		if ( ! wc_appointments_is_timed_slot_product( $appt ) ) {
			return array();
		}

		$occurrences = $this->expand_occurrences( $args );

		$target_ts = (int) ( $occurrences[ $recurrence_id ] ?? $args['suggest_start_ts'] ?? 0 );
		if ( $target_ts <= 0 ) {
			return array();
		}
		$duration  = max( (int) ( $args['duration_seconds'] ?? 0 ), (int) $appt->get_duration_in_minutes() * MINUTE_IN_SECONDS, HOUR_IN_SECONDS );
		$staff_id  = (int) ( $args['staff_id'] ?? 0 );
		$anchor    = (int) ( $args['dtstart_ts'] ?? 0 );
		$booking_tz = wc_appointments_series_booking_timezone( $appt, (string) ( $args['timezone'] ?? '' ) );
		$labels     = array();

		// Frequency-aware window: one step before and after the target day,
		// so weekly/monthly series suggest adjacent same-weekday/week slots
		// instead of only the same day (which is empty for non-daily rules).
		$window = WC_Appointment_Series_RRule::interval_days( (string) ( $args['rrule'] ?? '' ) ) * DAY_IN_SECONDS;

		try {
			$target_unix = WC_Appointment_Series_RRule::fake_utc_to_zoned( $target_ts, $booking_tz )->getTimestamp();
			$day_start   = WC_Appointment_Slots_Collection::timestamp_site_midnight( wp_date( 'Y-m-d', $target_unix ) );
			$collection  = WC_Appointment_Slots_Provider::get_time_slots_collection(
				$appt,
				$day_start - $window,
				$day_start + $window + ( 2 * DAY_IN_SECONDS ),
				$staff_id > 0 ? $staff_id : 0,
				false,
				false,
				$booking_tz->getName(),
				false,
				(int) ( $args['location_id'] ?? 0 )
			);
		} catch ( Exception $e ) {
			return array();
		}

		foreach ( WC_Appointment_Slots_Collection::slots_for_day_summary( $appt, $collection->get_all_slots() ) as $slot ) {
			if ( ! $slot->bookable || ! $slot->available ) {
				continue;
			}

			$fake_ts = WC_Appointment_Series_RRule::convert_fake_utc_axis( (int) $slot->start_ts, wp_timezone(), $booking_tz );
			if ( $fake_ts <= 0 || $fake_ts === $target_ts || ! $this->occurrence_fits_series_schedule( $occurrences, $recurrence_id, $fake_ts, $duration, $anchor ) ) {
				continue;
			}

			$labels[ $fake_ts ] = $slot->selection_display ?: wc_appointments_format_booking_fake_utc( $fake_ts, $booking_tz->getName() );
		}

		// Nearest-first, with the target calendar day preferred so the
		// same-day chips still lead when available.
		$keys       = array_keys( $labels );
		$target_day = gmdate( 'Y-m-d', (int) $target_ts );
		usort(
			$keys,
			static function ( $a, $b ) use ( $target_ts, $target_day ) {
				$day_cmp = (int) ( gmdate( 'Y-m-d', $b ) === $target_day ) - (int) ( gmdate( 'Y-m-d', $a ) === $target_day );
				return 0 !== $day_cmp ? $day_cmp : abs( $a - $target_ts ) <=> abs( $b - $target_ts );
			}
		);

		$pick = array_slice( $keys, 0, $limit );
		sort( $pick, SORT_NUMERIC );

		$result = array_map(
			static function ( $ts ) use ( $labels ) {
				return array( 'start_ts' => (int) $ts, 'display_label' => $labels[ $ts ] );
			},
			$pick
		);
		return $result;
	}

	/**
	 * Whether a candidate time fits the series (sibling overlap + anchor slot).
	 *
	 * @param array<string, int> $occurrences   Expanded series.
	 * @param string             $recurrence_id Occurrence being moved.
	 * @param int                $start_ts      Candidate Fake UTC start.
	 * @param int                $duration      Duration seconds.
	 * @param int                $anchor_ts     Anchor on the form.
	 * @return bool
	 */
	protected function occurrence_fits_series_schedule( $occurrences, $recurrence_id, $start_ts, $duration, $anchor_ts ) {
		$start_ts = (int) $start_ts;
		if ( $start_ts <= 0 ) {
			return false;
		}

		if ( $anchor_ts > 0 && $start_ts === $anchor_ts ) {
			foreach ( $occurrences as $rid => $other_start ) {
				if ( (int) $other_start === $anchor_ts && (string) $rid !== (string) $recurrence_id ) {
					return false;
				}
			}
		}

		$end_ts = $start_ts + $duration;

		foreach ( $occurrences as $rid => $other_start ) {
			if ( (string) $rid === (string) $recurrence_id ) {
				continue;
			}
			$other_end = (int) $other_start + $duration;
			if ( $start_ts < $other_end && $end_ts > (int) $other_start ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * @param array<string, int>   $occurrences       recurrence_id => start_ts.
	 * @param WC_Product|null      $product           Appointable product.
	 * @param string               $booking_timezone  IANA timezone for display labels.
	 * @return array<int, array<string, mixed>>
	 */
	protected function format_occurrences( $occurrences, $product = null, $booking_timezone = '' ) {
		$date_only = ! wc_appointments_is_timed_slot_product( $product );
		$out       = array();

		foreach ( $occurrences as $recurrence_id => $start_ts ) {
			$out[] = array(
				'recurrence_id' => $recurrence_id,
				'start_ts'      => (int) $start_ts,
				'display_label' => wc_appointments_format_booking_fake_utc( (int) $start_ts, (string) $booking_timezone, $date_only ),
			);
		}

		return $out;
	}

	/**
	 * Series subtotal and first-session unit price (one occurrence loop).
	 *
	 * @param WC_Product             $product        Product.
	 * @param int                    $billable_count Billable occurrences.
	 * @param array<string, mixed>   $args           Preview args.
	 * @param array<string, int>     $occurrences    recurrence_id => start_ts.
	 * @param array<int, array<string, string>> $conflicts Conflict rows.
	 * @return array{subtotal: float, first_session: float}
	 */
	protected function resolve_series_pricing( $product, $billable_count, $args = array(), $occurrences = array(), $conflicts = array() ) {
		$zero = array(
			'subtotal'      => 0.0,
			'first_session' => 0.0,
		);
		if ( $billable_count <= 0 || ! class_exists( 'WC_Appointments_Cost_Calculation' ) ) {
			return $zero;
		}

		$ctx = $this->pricing_context( $args, $occurrences, $conflicts );
		if ( $ctx['anchor_ts'] <= 0 && empty( $ctx['posted'] ) ) {
			$unit = (float) $product->get_price();
			return array(
				'subtotal'      => $unit * $billable_count,
				'first_session' => $unit,
			);
		}

		// Extract once-per-series addon totals and adjust posted data for per-session pricing.
		$once_addons    = $this->extract_once_per_series_addons( $product, $ctx['posted'] );
		$session_posted = $ctx['posted'];
		if ( $once_addons['cost'] > 0 && isset( $session_posted['wc_appointments_field_addons_cost'] ) ) {
			$session_posted['wc_appointments_field_addons_cost'] = max( 0, (float) $session_posted['wc_appointments_field_addons_cost'] - $once_addons['cost'] );
		}
		if ( $once_addons['duration'] > 0 && isset( $session_posted['wc_appointments_field_addons_duration'] ) ) {
			$session_posted['wc_appointments_field_addons_duration'] = max( 0, (float) $session_posted['wc_appointments_field_addons_duration'] - $once_addons['duration'] );
		}

		$subtotal       = 0.0;
		$first          = 0.0;
		$billable_slots = array_diff_key( $occurrences, $ctx['conflict_ids'] );
		asort( $billable_slots, SORT_NUMERIC );
		$pricing_uniform = ! $this->series_session_costs_vary_by_slot( $product, $billable_slots );
		if ( $pricing_uniform ) {
			$count    = count( $billable_slots );
			$slot_keys = array_keys( $billable_slots );
			$first_ts = (int) $billable_slots[ $slot_keys[0] ];
			$first_posted = $session_posted;

			if ( $once_addons['duration'] > 0 && isset( $ctx['posted']['wc_appointments_field_addons_duration'] ) ) {
				$first_posted['wc_appointments_field_addons_duration'] = (float) $ctx['posted']['wc_appointments_field_addons_duration'];
			}

			$first = $this->session_cost_for_slot( $product, $first_ts, $first_posted, $ctx['qty'] );

			if ( $count <= 1 ) {
				$subtotal = $first;
			} elseif ( $once_addons['duration'] > 0 ) {
				$rest_ts   = (int) $billable_slots[ $slot_keys[1] ];
				$rest_unit = $this->session_cost_for_slot( $product, $rest_ts, $session_posted, $ctx['qty'] );
				$subtotal  = $first + ( $rest_unit * ( $count - 1 ) );
			} else {
				$subtotal = $first * $count;
			}
		} else {
			$cost_cache = array();
			foreach ( $billable_slots as $recurrence_id => $start_ts ) {
				$slot_posted = $session_posted;
				if ( ! isset( $cost_cache[ (int) $start_ts ] ) ) {
					if ( empty( $cost_cache ) && $once_addons['duration'] > 0 && isset( $ctx['posted']['wc_appointments_field_addons_duration'] ) ) {
						$slot_posted['wc_appointments_field_addons_duration'] = (float) $ctx['posted']['wc_appointments_field_addons_duration'];
					}
					$cost_cache[ (int) $start_ts ] = $this->session_cost_for_slot( $product, (int) $start_ts, $slot_posted, $ctx['qty'] );
				}
				$cost = $cost_cache[ (int) $start_ts ];
				$subtotal += $cost;
				if ( $first <= 0 && $cost > 0 ) {
					$first = $cost;
				}
			}
		}
		if ( $subtotal <= 0 ) {
			$unit     = $this->fallback_session_unit_price( $product, $session_posted, $ctx['anchor_ts'], $ctx['qty'] );
			$subtotal = $unit * $billable_count;
			if ( $first <= 0 ) {
				$first = $unit;
			}
		} elseif ( $first <= 0 ) {
			$first = $this->fallback_session_unit_price( $product, $session_posted, $ctx['anchor_ts'], $ctx['qty'] );
		}

		// Add once-per-series addon cost to subtotal and first session (for pay-first due_today).
		$subtotal += $once_addons['cost'];
		$first    += $once_addons['cost'];

		return array(
			'subtotal'      => $subtotal,
			'first_session' => $first,
		);
	}

	/**
	 * Once-per-series addon totals for recurring pricing and duration.
	 *
	 * @param WC_Product           $product Product.
	 * @param array<string, mixed> $posted  Form POST data.
	 * @return array{cost: float, duration: float}
	 */
	public static function once_per_series_addon_totals( $product, $posted ) {
		return ( new self() )->extract_once_per_series_addons( $product, $posted );
	}

	/**
	 * Cost and duration (minutes) of addons marked once per recurring series.
	 *
	 * @param WC_Product           $product Product.
	 * @param array<string, mixed> $posted  Form POST data.
	 * @return array{cost: float, duration: float}
	 */
	protected function extract_once_per_series_addons( $product, $posted ) {
		$empty = array(
			'cost'     => 0.0,
			'duration' => 0.0,
		);
		if ( ! class_exists( 'WC_Product_Addons_Helper' ) || empty( $GLOBALS['Product_Addon_Cart'] ) ) {
			return $empty;
		}

		$product_addons = WC_Product_Addons_Helper::get_product_addons( $product->get_id(), '' );
		if ( empty( $product_addons ) || ! is_array( $product_addons ) ) {
			return $empty;
		}

		$once_flags = array();
		foreach ( $product_addons as $addon ) {
			if ( ! empty( $addon['field_name'] ) && ! empty( $addon['wc_appointment_recurring_once_per_series'] ) ) {
				$once_flags[ $addon['field_name'] ] = true;
			}
		}
		if ( empty( $once_flags ) ) {
			return $empty;
		}

		$posted = is_array( $posted ) ? $posted : array();
		try {
			// PAO merges $_POST with cart_item_data; series preview passes form fields in $posted only.
			$cart_data = $GLOBALS['Product_Addon_Cart']->add_cart_item_data( $posted, $product->get_id() );
		} catch ( Exception $e ) {
			return $empty;
		}
		if ( empty( $cart_data['addons'] ) || ! is_array( $cart_data['addons'] ) ) {
			return $empty;
		}

		$qty = max( 1, (int) ( $posted['quantity'] ?? $posted['qty'] ?? 1 ) );
		$totals = $empty;
		foreach ( $cart_data['addons'] as $addon_item ) {
			if ( ! is_array( $addon_item ) || empty( $addon_item['field_name'] ) || ! isset( $once_flags[ $addon_item['field_name'] ] ) ) {
				continue;
			}
			if ( isset( $addon_item['price'] ) ) {
				$totals['cost'] += (float) $addon_item['price'];
			}
			$duration = isset( $addon_item['duration'] ) ? (float) $addon_item['duration'] : 0.0;
			if ( $duration && ! empty( $addon_item['duration_type'] ) && 'quantity_based' === $addon_item['duration_type'] ) {
				$duration *= $qty;
			}
			$totals['duration'] += $duration;
		}

		return $totals;
	}

	/**
	 * @param array<string, mixed>              $args        Preview args.
	 * @param array<string, int>                $occurrences recurrence_id => start_ts.
	 * @param array<int, array<string, string>> $conflicts   Conflict rows.
	 * @return array{posted: array<string, mixed>, qty: int, anchor_ts: int, conflict_ids: array<string, bool>}
	 */
	protected function pricing_context( $args, $occurrences, $conflicts = array() ) {
		$posted    = $this->resolve_pricing_posted( $args );
		$qty       = isset( $args['qty'] ) ? max( 1, (int) $args['qty'] ) : 1;
		$anchor_ts = isset( $args['dtstart_ts'] ) ? (int) $args['dtstart_ts'] : 0;

		if ( $anchor_ts <= 0 && ! empty( $occurrences ) ) {
			$first = reset( $occurrences );
			$anchor_ts = is_numeric( $first ) ? (int) $first : 0;
		}

		$conflict_ids = array();
		foreach ( $conflicts as $conflict ) {
			if ( isset( $conflict['recurrence_id'] ) ) {
				$conflict_ids[ $conflict['recurrence_id'] ] = true;
			}
		}

		return array(
			'posted'       => $posted,
			'qty'          => $qty,
			'anchor_ts'    => $anchor_ts,
			'conflict_ids' => $conflict_ids,
		);
	}

	/**
	 * Net session cost for one occurrence slot.
	 *
	 * @param WC_Product           $product       Appointable product.
	 * @param int                  $start_ts      Fake UTC start.
	 * @param array<string, mixed> $posted_source Posted appointment data template.
	 * @param int                  $qty           Quantity.
	 * @return float
	 */
	protected function session_cost_for_slot( $product, $start_ts, $posted_source, $qty ) {
		$cost = $this->calculate_session_cost(
			$product,
			$this->build_cost_posted_for_slot( $product, $start_ts, $posted_source, $qty )
		);

		return is_wp_error( $cost ) ? 0.0 : max( 0, (float) $cost );
	}

	/**
	 * Whether per-session cost calculation can differ across billable occurrences.
	 *
	 * @param WC_Product           $product        Product.
	 * @param array<string, int>   $billable_slots recurrence_id => start_ts.
	 * @return bool True when each occurrence needs its own cost run.
	 */
	protected function series_session_costs_vary_by_slot( $product, $billable_slots ) {
		if ( empty( $billable_slots ) || ! method_exists( $product, 'get_costs' ) ) {
			return false;
		}

		$costs = $product->get_costs();
		if ( empty( $costs ) ) {
			return false;
		}

		$timestamps = array_map( 'intval', array_values( $billable_slots ) );

		foreach ( $costs as $rule ) {
			if ( ! is_array( $rule ) || empty( $rule[0] ) ) {
				continue;
			}

			$type = (string) $rule[0];

			if ( in_array( $type, array( 'time:range', 'days', 'weeks', 'months', 'custom', 'blocks' ), true ) ) {
				return true;
			}

			if ( in_array( $type, array( 'quant', 'slots', 'series_count' ), true ) ) {
				continue;
			}

			if ( 0 === strpos( $type, 'time' ) ) {
				$rules = isset( $rule[1] ) && is_array( $rule[1] ) ? $rule[1] : array();
				if ( ! empty( $rules['day'] ) ) {
					$weekdays = array();
					foreach ( $timestamps as $ts ) {
						$weekdays[ (int) gmdate( 'w', $ts ) ] = true;
					}
					if ( count( $weekdays ) > 1 ) {
						return true;
					}
				}
				continue;
			}

			return true;
		}

		return false;
	}

	/**
	 * Fallback unit price when per-slot costing is unavailable.
	 *
	 * @param WC_Product           $product       Appointable product.
	 * @param array<string, mixed> $posted_source Posted appointment data.
	 * @param int                  $anchor_ts     Fake UTC anchor start.
	 * @param int                  $qty           Quantity.
	 * @return float
	 */
	protected function fallback_session_unit_price( $product, $posted_source, $anchor_ts, $qty ) {
		if ( ! empty( $posted_source ) ) {
			$raw = $this->calculate_session_cost( $product, $posted_source );
			if ( ! is_wp_error( $raw ) && $raw > 0 ) {
				return (float) $raw;
			}
		}

		if ( $anchor_ts > 0 ) {
			$anchor = $this->session_cost_for_slot( $product, $anchor_ts, $posted_source, $qty );
			if ( $anchor > 0 ) {
				return $anchor;
			}
		}

		return (float) $product->get_price();
	}

	/**
	 * @param array<string, mixed> $args Preview args.
	 * @return array<string, mixed>
	 */
	protected function resolve_pricing_posted( $args ) {
		if ( isset( $args['posted'] ) && ! empty( $args['posted'] ) ) {
			return $args['posted'];
		}

		return WC_Appointment_Series_Request::get_add_to_cart_post();
	}

	/**
	 * Build a cost-calculation payload aligned to a slot timestamp (Fake UTC).
	 *
	 * Raw storefront $_POST date fields can disagree with the slot token; the cost
	 * engine expects y/m/d/time fields that match the slot instant (see admin AJAX).
	 *
	 * @param WC_Product             $product        Appointable product.
	 * @param int                    $start_ts       Slot start (Fake UTC epoch).
	 * @param array<string, mixed>   $posted_source  Optional form POST for staff/qty/timezone.
	 * @param int                    $qty            Quantity per session.
	 * @return array<string, mixed>
	 */
	protected function build_cost_posted_for_slot( $product, $start_ts, $posted_source = array(), $qty = 1 ) {
		$cost_posted = is_array( $posted_source ) ? $posted_source : array();

		$start_ts = (int) $start_ts;
		if ( $start_ts <= 0 ) {
			return $cost_posted;
		}

		$formatted = wc_appointments_slot_token_formatted_times( $start_ts );
		$cost_posted['wc_appointments_field_start_date_year']      = $formatted['year'];
		$cost_posted['wc_appointments_field_start_date_month']     = $formatted['month'];
		$cost_posted['wc_appointments_field_start_date_day']       = $formatted['day'];
		$cost_posted['wc_appointments_field_start_date_timestamp'] = (string) $start_ts;
		$cost_posted['quantity']                                   = max( 1, (int) $qty );

		if ( is_wc_appointment_product( $product ) && $product->has_time() ) {
			$cost_posted['wc_appointments_field_start_date_time'] = gmdate( 'H:i', $start_ts );
		}

		return $cost_posted;
	}

	/**
	 * @param WC_Product             $product Product.
	 * @param array<string, mixed>   $posted  Form payload.
	 * @return float|WP_Error
	 */
	protected function calculate_session_cost( $product, $posted ) {
		WC_Appointments_Cost_Calculation::$appointment_cost      = 0;
		WC_Appointments_Cost_Calculation::$applied_cost_rules     = array();
		return WC_Appointments_Cost_Calculation::calculate_appointment_cost( $posted, $product );
	}

	/**
	 * Validate preview and build checkout RRULE + billable session starts (one pass).
	 *
	 * @param WC_Product_Appointment $product     Product.
	 * @param array<string, mixed>   $preview     Preview payload.
	 * @param array<string, mixed>   $args        Normalized preview args.
	 * @return array{rrule: string, session_starts: int[], billable_count: int, conflict_count: int, partial: bool}|WP_Error
	 */
	public static function cart_schedule( WC_Product_Appointment $product, $preview, $args ) {
		$summary   = (array) ( $preview['summary'] ?? array() );
		$billable  = (int) ( $summary['billable_count'] ?? 0 );
		$conflicts = (array) ( $preview['conflicts'] ?? array() );
		$min       = $product->get_recurring_min_billable_sessions();
		$partial   = (bool) apply_filters( 'wc_appointments_recurring_allow_partial_checkout', true, $product, $preview, $args );

		if ( ! empty( $preview['error'] ) ) {
			return new WP_Error( 'preview_error', __( 'This recurring series is not available.', 'woocommerce-appointments' ) );
		}
		if ( $billable < $min ) {
			$message = ( $conflicts && $billable > 0 )
				? sprintf(
					/* translators: 1: available appointments, 2: minimum required */
					__( 'Need at least %2$d appointments; only %1$d available. Adjust the schedule or remove appointments.', 'woocommerce-appointments' ),
					$billable,
					$min
				)
				: __( 'No billable appointments in this package.', 'woocommerce-appointments' );
			return new WP_Error( 'insufficient_billable', $message );
		}
		if ( ! $partial && $conflicts ) {
			return new WP_Error(
				'conflicts',
				__( 'One or more appointments are unavailable. Adjust your schedule.', 'woocommerce-appointments' )
			);
		}

		$overrides = (array) ( $args['overrides'] ?? array() );
		$timezone  = (string) ( $args['timezone'] ?? wc_timezone_string() );
		$exdates   = array_map( 'strval', (array) ( $args['exdates'] ?? array() ) );
		$skip = array();

		foreach ( self::filter_conflicts_excluding_rescheduled( $conflicts, $overrides, $timezone ) as $conflict ) {
			$rid = WC_Appointment_Series_RRule::sanitize_recurrence_id( $conflict['recurrence_id'] ?? '' );
			if ( '' === $rid ) {
				continue;
			}
			$skip[ $rid ] = true;
			if ( $partial ) {
				$exdates[] = $rid;
			}
		}
		$exdates = array_values( array_unique( $exdates ) );

		$booking_tz     = wc_appointments_series_booking_timezone( $product, $timezone );
		$session_starts = array();
		foreach ( (array) ( $preview['occurrences'] ?? array() ) as $occ ) {
			$rid = (string) ( $occ['recurrence_id'] ?? '' );
			$ts  = (int) ( $occ['start_ts'] ?? 0 );
			if ( $rid && $ts > 0 && ! isset( $skip[ $rid ] ) ) {
				if ( $booking_tz ) {
					$ts = WC_Appointment_Series_RRule::convert_fake_utc_axis( $ts, $booking_tz, wp_timezone() );
				}
				$session_starts[] = $ts;
			}
		}

		if ( '' === WC_Appointment_Series_RRule::rrule_line( (string) ( $args['rrule'] ?? '' ) ) ) {
			return new WP_Error( 'no_rrule', __( 'Choose a repeat schedule.', 'woocommerce-appointments' ) );
		}

		$rrule = WC_Appointment_Series_RRule::apply_schedule_adjustments( (string) ( $args['rrule'] ?? '' ), $timezone, $exdates, $overrides );
		$check = $product->enforce_recurring_rrule( $rrule );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		return array(
			'rrule'          => $check,
			'session_starts' => $session_starts,
			'billable_count' => $billable,
			'conflict_count' => count( $conflicts ),
			'partial'        => $partial,
		);
	}

	/**
	 * Storefront price HTML for a net amount (respects shop tax display + suffix).
	 *
	 * @param WC_Product $product    Appointable product.
	 * @param float      $net_amount Net cost from the appointment cost engine.
	 * @param float      $subtotal   Optional higher list amount for sale markup.
	 * @return string
	 */
	protected function format_net_price_html( $product, $net_amount, $subtotal = 0.0 ) {
		$net_amount = max( 0, (float) $net_amount );
		$subtotal   = max( 0, (float) $subtotal );

		if ( $subtotal > $net_amount ) {
			return '<del aria-hidden="true">' . $this->format_net_price_html( $product, $subtotal ) . '</del> <ins>' . $this->format_net_price_html( $product, $net_amount ) . '</ins>';
		}

		if ( is_wc_appointment_product( $product ) ) {
			return $product->get_cost_html( $net_amount );
		}

		return wc_price( $net_amount );
	}

	/**
	 * Recurring package cost footer — single definition list for storefront preview.
	 *
	 * @param WC_Product $product          Appointable product.
	 * @param bool       $pay_first        Pay-first package (first session at checkout).
	 * @param float      $checkout_net     Net amount charged at checkout.
	 * @param float      $series_total     Net package total.
	 * @param int        $billable_count   Billable sessions in the preview.
	 * @param float      $series_subtotal  Pre-package subtotal (strike-through when higher than series total).
	 * @return string
	 */
	protected function format_series_cost_footer_html( $product, $pay_first, $checkout_net, $series_total, $billable_count, $series_subtotal = 0.0 ) {
		$billable_count  = max( 0, (int) $billable_count );
		$series_total    = max( 0, (float) $series_total );
		$checkout_net    = max( 0, (float) $checkout_net );
		$series_subtotal = max( 0, (float) $series_subtotal );

		$sessions = '';
		if ( $billable_count > 0 ) {
			$sessions = '<span class="wca-series-sessions description">' . esc_html(
				sprintf(
					/* translators: %d: number of billable appointments */
					_n( '%d appointment', '%d appointments', $billable_count, 'woocommerce-appointments' ),
					$billable_count
				)
			) . '</span>';
		}

		$row = static function ( $label, $amount_html, $highlight = false ) {
			return sprintf(
				'<div class="wca-recurring-cost-row%s"><dt>%s</dt><dd>%s</dd></div>',
				$highlight ? ' wca-recurring-cost-row--due-today' : '',
				esc_html( $label ),
				$amount_html
			);
		};

		$hero_label = $pay_first
			? __( 'Due today', 'woocommerce-appointments' )
			: _x( 'Total', 'recurring series cost string', 'woocommerce-appointments' );
		$rows       = array(
			$row(
				$hero_label,
				'<strong>' . $this->format_net_price_html( $product, $pay_first ? $checkout_net : $series_total, $pay_first ? 0.0 : $series_subtotal ) . '</strong>' . $sessions,
				true
			),
		);

		if ( $pay_first && $series_total > 0 ) {
			$rows[] = $row( __( 'Package total', 'woocommerce-appointments' ), $this->format_net_price_html( $product, $series_total, $series_subtotal ) );
			$balance = WC_Appointment_Series::calculate_balance_due_display( $product, $series_total, $checkout_net );
			if ( $balance > 0 ) {
				$rows[] = $row( __( 'Remaining balance', 'woocommerce-appointments' ), wp_kses_post( wc_price( $balance ) ) );
			}
		}

		return (string) apply_filters(
			'woocommerce_appointments_appointment_cost_html',
			'<dl class="wca-recurring-cost-footer">' . implode( '', $rows ) . '</dl>',
			$product,
			array()
		);
	}

}
