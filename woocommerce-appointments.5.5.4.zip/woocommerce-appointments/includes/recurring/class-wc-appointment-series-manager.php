<?php
/**
 * Single mutation entry for recurring appointment series.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * create / cancel / skip_one / reschedule_one.
 */
class WC_Appointment_Series_Manager {

	/**
	 * @var WC_Appointment_Series_Preview
	 */
	protected $preview;

	/**
	 * @var WC_Appointment_Series_Materializer
	 */
	protected $materializer;

	/**
	 * @param WC_Appointment_Series_Preview|null      $preview      Preview helper.
	 * @param WC_Appointment_Series_Materializer|null $materializer Materializer.
	 */
	public function __construct( $preview = null, $materializer = null ) {
		$this->preview      = $preview ? $preview : new WC_Appointment_Series_Preview();
		$this->materializer = $materializer ? $materializer : new WC_Appointment_Series_Materializer();
	}

	/**
	 * Create a series: preview conflicts, insert row, sync first batch, async tail.
	 *
	 * @param array<string, mixed> $args            Series fields.
	 * @param string               $idempotency_key Client idempotency key.
	 * @return WC_Appointment_Series|WP_Error
	 */
	public function create( $args, $idempotency_key = '' ) {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return new WP_Error( 'recurring_disabled', __( 'Recurring appointments are disabled.', 'woocommerce-appointments' ) );
		}

		$args   = $this->normalize_create_args( $args );
		$error  = $this->validate_create_args( $args );
		if ( is_wp_error( $error ) ) {
			return $error;
		}

		$committed_starts = array_values(
			array_filter(
				array_map( 'intval', (array) ( $args['session_starts'] ?? array() ) )
			)
		);
		$from_order         = ! empty( $args['order_id'] ) && $committed_starts;

		if ( $from_order ) {
			$product = WC_Product_Appointment::as_appointment_product( (int) $args['product_id'] );
			$min     = $product ? $product->get_recurring_min_billable_sessions() : WC_Product_Appointment::RECURRING_DEFAULT_MIN_OCCURRENCES;
			if ( count( $committed_starts ) < $min ) {
				return new WP_Error(
					'insufficient_billable',
					__( 'No billable appointments in this package.', 'woocommerce-appointments' )
				);
			}
		} else {
			$args    = WC_Appointment_Series_Request::normalize_preview_args( $args );
			$preview = $this->preview->preview( $args, true, true );
			if ( ! empty( $preview['error'] ) ) {
				return new WP_Error( 'invalid_product', __( 'Invalid appointable product.', 'woocommerce-appointments' ) );
			}
			if ( ! empty( $preview['conflicts'] ) ) {
				return new WP_Error(
					'series_conflict',
					__( 'One or more appointments are unavailable. Adjust your schedule.', 'woocommerce-appointments' ),
					array( 'conflicts' => $preview['conflicts'] )
				);
			}
		}

		$series = new WC_Appointment_Series();
		$series->set_status( WC_Appointment_Series::STATUS_PENDING );
		$series->set_product_id( (int) $args['product_id'] );
		$series->set_customer_id( (int) $args['customer_id'] );
		$series->set_staff_assignment_mode( (string) $args['staff_assignment_mode'] );
		if ( ! empty( $args['locked_staff_id'] ) ) {
			$series->set_locked_staff_id( (int) $args['locked_staff_id'] );
		}
		if ( ! empty( $args['location_id'] ) ) {
			$series->update_meta_data( '_wca_location_id', (int) $args['location_id'] );
			if ( ! empty( $args['location'] ) && is_array( $args['location'] ) ) {
				$series->update_meta_data( '_wca_location', $args['location'] );
			} elseif ( class_exists( 'WC_Appointments_Location' ) ) {
				$series->update_meta_data( '_wca_location', WC_Appointments_Location::build_snapshot( (int) $args['location_id'] ) );
			}
		}
		$series->set_order_id( isset( $args['order_id'] ) ? (int) $args['order_id'] : 0 );
		$product_for_payment = WC_Product_Appointment::as_appointment_product( (int) $args['product_id'] );
		$series->set_payment_model(
			$product_for_payment
				? $product_for_payment->resolve_recurring_payment_model( (string) ( $args['payment_model'] ?? '' ) )
				: WC_Appointment_Series::PAYMENT_PREPAID
		);
		$series->set_rrule( (string) $args['rrule'] );
		$series->set_dtstart_ts( (int) $args['dtstart_ts'] );
		$series->set_duration_seconds( (int) $args['duration_seconds'] );
		$once_duration = (int) ( $args['once_per_series_addon_duration_seconds'] ?? 0 );
		if ( $once_duration > 0 ) {
			$series->update_meta_data( '_wca_once_per_series_addon_duration_seconds', $once_duration );
		}
		$series->set_timezone( (string) $args['timezone'] );
		$series->set_next_materialize_ts( (int) $args['dtstart_ts'] );
		$count_cap = $from_order
			? count( $committed_starts )
			: WC_Appointment_Series_RRule::parse_count_cap( (string) $args['rrule'] );
		$series->set_rrule_count_cap( $count_cap );
		$series->set_qty( max( 1, (int) $args['qty'] ) );

		$series->save();

		$sync_batch = (int) apply_filters( 'wc_appointments_series_sync_first_batch', 10, $series );
		$series->set_status( WC_Appointment_Series::STATUS_ACTIVE );
		$store = $series->get_data_store();
		$store->update_if_version( $series, 1 );

		$series = new WC_Appointment_Series( $series->get_id() );

		if ( $from_order ) {
			$this->materializer->materialize_committed_sessions(
				$series->get_id(),
				$committed_starts,
				(int) $args['order_id'],
				(int) ( $args['order_item_id'] ?? 0 )
			);
		} else {
			$this->materializer->materialize_batch( $series->get_id(), $sync_batch );
			$series = new WC_Appointment_Series( $series->get_id() );
			if ( $this->materializer->needs_more_materialization( $series ) ) {
				WC_Appointment_Series_Materializer::schedule( $series->get_id() );
			}
		}

		$series = new WC_Appointment_Series( $series->get_id() );

		if ( WC_Appointment_Series::PAYMENT_PAY_FIRST === $series->get_payment_model() ) {
			if ( isset( $args['series_total'] ) && (float) $args['series_total'] > 0 ) {
				$series->apply_pay_first_balance(
					(float) $args['series_total'],
					isset( $args['checkout_total'] ) ? (float) $args['checkout_total'] : 0.0
				);
			}
			$series->ensure_pay_first_totals_from_order();
			$series->save();
			$series = new WC_Appointment_Series( $series->get_id() );
		}

		unset( $idempotency_key );

		if ( $series->get_materialized_count() > 0 ) {
			WC_Appointment_Series_Email::schedule_created_notification( $series->get_id() );
		}

		if ( WC_Appointment_Series::PAYMENT_PAY_FIRST === $series->get_payment_model() ) {
			if ( $series->auto_create_balance_order_if_due() ) {
				$series = new WC_Appointment_Series( $series->get_id() );
			}
		}

		// Rewrite mid-create SSE payloads now that all occurrences (and pay-first totals) exist.
		if ( class_exists( 'WC_Appointments_SSE' ) && $series->get_id() > 0 ) {
			WC_Appointments_SSE::refresh_series_payloads_in_queue( (int) $series->get_id() );
		}

		return $series;
	}

	/**
	 * Create a series from a paid order line (storefront prepaid checkout).
	 *
	 * @since 5.4.0
	 *
	 * @param WC_Order              $order           Order.
	 * @param WC_Order_Item_Product $item            Line item.
	 * @param array<string, mixed>  $line_data       `_wca_recurring` order line meta.
	 * @param string                $idempotency_key Idempotency key.
	 * @return WC_Appointment_Series|WP_Error
	 */
	public function create_from_order_item( $order, $item, $line_data, $idempotency_key = '' ) {
		$line_data  = is_array( $line_data ) ? $line_data : array();
		$staff_args = WC_Product_Appointment::get_recurring_series_staff_from_line( $line_data );

		$result = $this->create(
			array(
				'product_id'            => (int) $item->get_product_id(),
				'customer_id'           => (int) $order->get_customer_id(),
				'rrule'                 => (string) ( $line_data['rrule'] ?? '' ),
				'dtstart_ts'            => (int) ( $line_data['dtstart_ts'] ?? 0 ),
				'timezone'              => (string) ( $line_data['timezone'] ?? wc_timezone_string() ),
				'duration_seconds'      => (int) ( $line_data['duration_seconds'] ?? 0 ),
				'once_per_series_addon_duration_seconds' => (int) ( $line_data['once_per_series_addon_duration_seconds'] ?? 0 ),
				'staff_assignment_mode' => $staff_args['staff_assignment_mode'],
				'locked_staff_id'       => $staff_args['locked_staff_id'],
				'location_id'           => (int) ( $line_data['location_id'] ?? 0 ),
				'location'              => isset( $line_data['location'] ) && is_array( $line_data['location'] ) ? $line_data['location'] : array(),
				'session_starts'        => array_map( 'intval', (array) ( $line_data['session_starts'] ?? array() ) ),
				'order_id'              => (int) $order->get_id(),
				'order_item_id'         => (int) $item->get_id(),
				'payment_model'         => (string) ( $line_data['payment_model'] ?? WC_Appointment_Series::PAYMENT_PREPAID ),
				'series_total'          => isset( $line_data['series_total'] ) ? (float) $line_data['series_total'] : 0.0,
				'checkout_total'        => isset( $line_data['checkout_total'] ) ? (float) $line_data['checkout_total'] : 0.0,
				'qty'                   => (int) ( $line_data['qty'] ?? 1 ),
			),
			$idempotency_key
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$series_id = $result->get_id();
		$item->update_meta_data( '_wca_series_id', $series_id );
		$item->save();

		if ( (int) $order->get_meta( '_wca_series_id', true ) <= 0 ) {
			$order->update_meta_data( '_wca_series_id', $series_id );
			$order->save();
		}

		return $result;
	}

	/**
	 * Admin panel create: preview, order line, series (same pipeline as storefront checkout).
	 *
	 * @since 5.4.0
	 *
	 * @param WC_Order               $order             Order.
	 * @param WC_Product_Appointment $product           Product.
	 * @param array<string, mixed>   $preview_args      Preview request.
	 * @param float|null             $line_net_override Net line total when admin overrides price; null uses preview total.
	 * @return WC_Appointment_Series|WP_Error
	 */
	public function create_from_admin_panel_order( $order, $product, $preview_args, $line_net_override = null ) {
		if ( ! $order || ! $product ) {
			return new WP_Error( 'invalid_args', __( 'Invalid order or product.', 'woocommerce-appointments' ) );
		}

		$preview  = $this->preview->preview( $preview_args );
		$schedule = WC_Appointment_Series_Preview::cart_schedule( $product, $preview, $preview_args );
		if ( is_wp_error( $schedule ) ) {
			return $schedule;
		}

		$summary      = (array) ( $preview['summary'] ?? array() );
		$series_total = (float) ( $summary['total_price'] ?? 0 );
		$qty          = max( 1, (int) ( $preview_args['qty'] ?? 1 ) );
		$staff_args   = $product->get_recurring_series_staff_from_booking( array( '_staff_id' => (int) ( $preview_args['staff_id'] ?? 0 ) ) );
		$line_net = null !== $line_net_override
			? (float) $line_net_override
			: wc_appointments_admin_line_net_from_amount( $product, $series_total );

		$catalog_price = $product->get_price( 'edit' );
		if ( $line_net > 0 ) {
			$product->set_price( $line_net / $qty );
		}
		$item_id = $order->add_product( $product, $qty );
		$product->set_price( $catalog_price );
		$item    = $item_id ? $order->get_item( $item_id ) : null;
		if ( ! $item || ! is_a( $item, 'WC_Order_Item_Product' ) ) {
			return new WP_Error( 'order_item', __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
		}
		$location_id = (int) ( $preview_args['location_id'] ?? 0 );
		$location    = [];
		if ( $location_id > 0 && class_exists( 'WC_Appointments_Location' ) ) {
			$location = WC_Appointments_Location::build_snapshot( $location_id );
		}

		$line_data = array_merge(
			$staff_args,
			array(
				'rrule'            => $schedule['rrule'],
				'payment_model'    => WC_Appointment_Series::PAYMENT_PREPAID,
				'series_total'     => $series_total,
				'checkout_total'   => $line_net,
				'preview_summary'  => $summary,
				'session_starts'   => $schedule['session_starts'],
				'dtstart_ts'       => (int) ( $preview_args['dtstart_ts'] ?? 0 ),
				'timezone'         => (string) ( $preview_args['timezone'] ?? wc_timezone_string() ),
				'duration_seconds' => (int) ( $preview_args['duration_seconds'] ?? 0 ),
				'once_per_series_addon_duration_seconds' => (int) ( $preview_args['once_per_series_addon_duration_seconds'] ?? 0 ),
				'staff_id'         => (int) ( $preview_args['staff_id'] ?? 0 ),
				'location_id'      => $location_id,
				'location'         => $location,
				'qty'              => $qty,
			)
		);

		$item->add_meta_data( '_wca_recurring', $line_data, true );
		$item->save();
		$order->save();

		$result = $this->create_from_order_item( $order, $item, $line_data, sprintf( 'admin-%d-item-%d', (int) $order->get_id(), $item_id ) );
		if ( ! is_wp_error( $result ) ) {
			$order->calculate_totals( wc_tax_enabled() );
			$order->save();
		}

		return $result;
	}

	/**
	 * Cancel one occurrence (EXDATE when possible).
	 *
	 * @param int            $series_id   Series id.
	 * @param int            $version     Optimistic version.
	 * @param WC_Appointment $appointment Target occurrence.
	 * @return bool|WP_Error
	 */
	public function cancel_one( $series_id, $version, WC_Appointment $appointment ) {
		$recurrence_id = (string) $appointment->get_meta( '_wca_recurrence_id' );
		if ( '' !== $recurrence_id ) {
			return $this->skip_one( $series_id, $version, $recurrence_id );
		}

		$this->set_occurrence_status( (int) $appointment->get_id(), 'cancelled' );

		return true;
	}

	/**
	 * Cancel series occurrences.
	 *
	 * @param int    $series_id         Series id.
	 * @param int    $expected_version  Optimistic version.
	 * @param string $scope             future|all.
	 * @param string $idempotency_key   Client key (reserved for REST).
	 * @param int    $anchor_id         When set, "future" is from this occurrence's start; else wall-clock now.
	 * @return bool|WP_Error
	 */
	public function cancel( $series_id, $expected_version, $scope = 'future', $idempotency_key = '', $anchor_id = 0 ) {
		unset( $idempotency_key );

		$scope = 'all' === $scope ? 'all' : 'future';

		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			unset( $e );
			return new WP_Error( 'invalid_series', __( 'Series not found.', 'woocommerce-appointments' ) );
		}

		$result = $this->set_scoped_status( $series_id, (int) $anchor_id, $scope, 'cancelled' );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$ctx = $result['ctx'];

		if ( 'all' === $scope ) {
			$series->set_status( WC_Appointment_Series::STATUS_CANCELLED );
		} else {
			$has_past_active = false;
			foreach ( $ctx['rows'] as $row ) {
				if ( (int) $row['start_ts'] < $ctx['cutoff'] && 'cancelled' !== $row['status'] ) {
					$has_past_active = true;
					break;
				}
			}
			$series->set_status(
				$has_past_active ? WC_Appointment_Series::STATUS_COMPLETED : WC_Appointment_Series::STATUS_CANCELLED
			);
		}

		$series->set_next_materialize_ts( 0 );

		try {
			$series->get_data_store()->update_if_version( $series, (int) $expected_version );
		} catch ( WC_Appointment_Series_Version_Conflict $e ) {
			return new WP_Error( 'version_conflict', $e->getMessage(), array( 'status' => 412 ) );
		}

		if ( WC_Appointment_Series::STATUS_CANCELLED === $series->get_status() ) {
			WC_Appointment_Series_Events::series_cancelled( $series );
		}

		return true;
	}

	/**
	 * Set status on future or all materialized occurrences (order sync suppressed).
	 *
	 * @param int    $series_id   Series id.
	 * @param int    $anchor_id   Occurrence being edited.
	 * @param string $new_status  Appointment status slug.
	 * @param string $scope       future|all.
	 * @return int[]|WP_Error Updated appointment IDs.
	 */
	public function update_status_scope( $series_id, $anchor_id, $new_status, $scope ) {
		$scope = in_array( $scope, array( 'future', 'all' ), true ) ? $scope : 'future';

		return WC_Appointment_Series_Scope::without_order_sync(
			function () use ( $series_id, $anchor_id, $new_status, $scope ) {
				$result = $this->set_scoped_status( $series_id, $anchor_id, $scope, $new_status );

				return is_wp_error( $result ) ? $result : $result['updated'];
			}
		);
	}

	/**
	 * Skip one occurrence: EXDATE + cancel appointment.
	 *
	 * @param int    $series_id        Series id.
	 * @param int    $expected_version Version.
	 * @param string $recurrence_id    RECURRENCE-ID.
	 * @param string $idempotency_key  Client key.
	 * @return bool|WP_Error
	 */
	public function skip_one( $series_id, $expected_version, $recurrence_id, $idempotency_key = '' ) {
		unset( $idempotency_key );

		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			return new WP_Error( 'invalid_series', __( 'Series not found.', 'woocommerce-appointments' ) );
		}

		$series->set_rrule( WC_Appointment_Series_RRule::append_exdate( $series->get_rrule(), $recurrence_id, $series->get_timezone() ) );

		$appointment_id = $this->find_appointment_by_recurrence( $series_id, $recurrence_id );

		// Do not sync parent order → order cancelled → cancel_series_from_order (entire series).
		WC_Appointment_Series_Scope::without_order_sync(
			function () use ( $appointment_id ) {
				if ( $appointment_id > 0 ) {
					$this->set_occurrence_status( $appointment_id, 'cancelled' );
				}
			}
		);

		try {
			$series->get_data_store()->update_if_version( $series, (int) $expected_version );
		} catch ( WC_Appointment_Series_Version_Conflict $e ) {
			return new WP_Error( 'version_conflict', $e->getMessage(), array( 'status' => 412 ) );
		}

		return true;
	}

	/**
	 * Check availability for a single reschedule target slot.
	 *
	 * @param WC_Product            $product     Appointable product.
	 * @param int                   $new_start   Fake UTC start.
	 * @param int                   $new_end     Fake UTC end.
	 * @param int[]                 $exclude_ids Appointment IDs to exclude from overlap check (batch targets).
	 * @param WC_Appointment_Series $series      Series (for locked staff).
	 * @param int                   $appointment_id Occurrence id for conflict messaging (optional).
	 * @return true|WP_Error
	 */
	public function check_reschedule_slot( $product, $new_start, $new_end, $exclude_ids = array(), $series = null, $appointment_id = 0 ) {
		if ( ! is_wc_appointment_product( $product ) ) {
			return new WP_Error( 'invalid_product', __( 'Invalid appointment product.', 'woocommerce-appointments' ) );
		}

		$new_start = (int) $new_start;
		$new_end   = (int) $new_end;
		// Occurrence times are booking-axis Fake UTC (series TZ). Slots engine expects store Fake UTC.
		$check_start = $new_start;
		$check_end   = $new_end;
		$booking_tz  = wc_appointments_series_booking_timezone(
			$product,
			$series ? (string) $series->get_timezone() : ''
		);
		if ( $booking_tz ) {
			$duration    = max( 1, $new_end - $new_start );
			$check_start = WC_Appointment_Series_RRule::convert_fake_utc_axis( $new_start, $booking_tz, wp_timezone() );
			$check_end   = $check_start + $duration;
		}

		if ( $exclude_ids ) {
			\WC_Appointment_Slots_Engine::set_overlap_exclude_appointment_ids( $exclude_ids );
		}
		try {
			$staff_id    = $series && $series->get_locked_staff_id() > 0 ? $series->get_locked_staff_id() : null;
			$location_id = $series ? (int) $series->get_meta( '_wca_location_id', true ) : 0;
			$available   = WC_Appointments_Controller::get_indexed_total_available_for_range( $product, $check_start, $check_end, $staff_id, 1, null, $location_id );
		} finally {
			if ( $exclude_ids ) {
				\WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();
			}
		}
		if ( false !== $available ) {
			return true;
		}
		$appt  = $appointment_id > 0 ? get_wc_appointment( $appointment_id ) : null;
		$when  = $appt ? wc_appointment_format_timestamp( $new_start, $appt->is_all_day() ) : '';
		$label = $when && $appointment_id > 0
			? sprintf(
				/* translators: 1: appointment ID, 2: formatted date/time */
				__( 'The new time is not available for appointment #%1$d (%2$s).', 'woocommerce-appointments' ),
				(int) $appointment_id,
				$when
			)
			: __( 'The new time is not available.', 'woocommerce-appointments' );
		return new WP_Error( 'series_conflict', $label, array( 'status' => 422 ) );
	}

	/**
	 * Move one occurrence: EXDATE old + RDATE new + update appointment.
	 *
	 * Does not bump series version — caller batches writes then calls update_if_version once.
	 *
	 * @param WC_Appointment_Series $series         Series object (rrule mutated in place).
	 * @param int                   $appointment_id Occurrence appointment id.
	 * @param int                   $new_start      Fake UTC start.
	 * @param int                   $new_end        Fake UTC end.
	 * @return void
	 */
	public function reschedule_occurrence( WC_Appointment_Series $series, $appointment_id, $new_start, $new_end ) {
		$appt = get_wc_appointment( (int) $appointment_id );
		$rid  = $appt ? (string) $appt->get_meta( '_wca_recurrence_id' ) : '';
		if ( ! $appt || '' === $rid ) {
			return;
		}

		$tz     = $series->get_timezone();
		$new_id = WC_Appointment_Series_RRule::recurrence_id_from_fake_utc( (int) $new_start, $tz );

		$series->set_rrule( WC_Appointment_Series_RRule::append_exdate( $series->get_rrule(), $rid, $tz ) );
		$series->set_rrule( WC_Appointment_Series_RRule::append_rdate( $series->get_rrule(), $new_id, $tz ) );

		$appt->set_start( (int) $new_start );
		$appt->set_end( (int) $new_end );
		$appt->update_meta_data( '_wca_recurrence_id', $new_id );
		$appt->update_meta_data( '_wca_is_series_override', 'yes' );
		$appt->save();
		do_action( 'wc_appointments_index_appointment', (int) $appointment_id );
	}

	/**
	 * Reschedule one occurrence to a new slot (availability check + version bump).
	 *
	 * @param int    $series_id        Series id.
	 * @param int    $expected_version   Optimistic-lock version.
	 * @param string $recurrence_id    Original RECURRENCE-ID.
	 * @param int    $new_start        Fake UTC start.
	 * @param int    $new_end          Fake UTC end.
	 * @param string $idempotency_key  Client key (unused).
	 * @param int    $appointment_id   Occurrence id when known (0 = look up by recurrence_id).
	 * @return bool|WP_Error
	 */
	public function reschedule_one( $series_id, $expected_version, $recurrence_id, $new_start, $new_end, $idempotency_key = '', $appointment_id = 0 ) {
		unset( $idempotency_key );

		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			return new WP_Error( 'invalid_series', __( 'Series not found.', 'woocommerce-appointments' ) );
		}

		$product = wc_get_product( $series->get_product_id() );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			return new WP_Error( 'invalid_product', __( 'Invalid appointable product.', 'woocommerce-appointments' ) );
		}

		if ( $appointment_id <= 0 ) {
			$appointment_id = $this->find_appointment_by_recurrence( $series_id, $recurrence_id );
		}
		if ( $appointment_id <= 0 ) {
			return new WP_Error( 'invalid_appointment', __( 'Appointment not found in series.', 'woocommerce-appointments' ) );
		}

		$avail = $this->check_reschedule_slot( $product, (int) $new_start, (int) $new_end, array( $appointment_id ), $series, $appointment_id );
		if ( is_wp_error( $avail ) ) {
			return $avail;
		}

		$this->reschedule_occurrence( $series, $appointment_id, (int) $new_start, (int) $new_end );

		try {
			$series->get_data_store()->update_if_version( $series, (int) $expected_version );
		} catch ( WC_Appointment_Series_Version_Conflict $e ) {
			return new WP_Error( 'version_conflict', $e->getMessage(), array( 'status' => 412 ) );
		}

		return true;
	}

	/**
	 * @param array<string, mixed> $args Raw args.
	 * @return array<string, mixed>
	 */
	protected function normalize_create_args( $args ) {
		$product = isset( $args['product_id'] ) ? wc_get_product( (int) $args['product_id'] ) : false;
		$duration = isset( $args['duration_seconds'] ) ? (int) $args['duration_seconds'] : 0;

		if ( $duration <= 0 && $product && is_wc_appointment_product( $product ) ) {
			$duration = (int) $product->get_duration_in_minutes() * MINUTE_IN_SECONDS;
			if ( $duration <= 0 ) {
				$duration = 3600;
			}
		}

		$args = wp_parse_args(
			$args,
			array(
				'customer_id'           => 0,
				'staff_assignment_mode' => 'auto_per_occurrence',
				'locked_staff_id'       => 0,
				'timezone'              => 'UTC',
				'duration_seconds'      => $duration,
				'qty'                   => 1,
				'location_id'           => 0,
				'payment_model'         => WC_Appointment_Series::PAYMENT_PREPAID,
				'series_total'          => 0.0,
				'checkout_total'        => 0.0,
			)
		);

		if ( $product && is_wc_appointment_product( $product ) && class_exists( 'WC_Appointments_Location' ) && $product->has_locations() ) {
			$location_id = (int) ( $args['location_id'] ?? 0 );
			if ( $location_id <= 0 ) {
				if ( WC_Appointments_Location::is_fixed_mode( $product->get_location_mode() ) ) {
					$allowed     = WC_Appointments_Location::get_allowed_location_ids( $product );
					$location_id = ! empty( $allowed[0] ) ? (int) $allowed[0] : 0;
				} elseif ( 'customer_choice' === $product->get_location_mode() ) {
					$location_id = WC_Appointments_Location::sole_allowed_location_id( $product );
				}
			}
			$args['location_id'] = $location_id;
			if ( $location_id > 0 && ( empty( $args['location'] ) || ! is_array( $args['location'] ) ) ) {
				$args['location'] = WC_Appointments_Location::build_snapshot( $location_id );
			}
		}

		return $args;
	}

	/**
	 * @param array<string, mixed> $args Normalized args.
	 * @return true|WP_Error
	 */
	protected function validate_create_args( $args ) {
		if ( empty( $args['product_id'] ) || empty( $args['rrule'] ) || empty( $args['dtstart_ts'] ) ) {
			return new WP_Error( 'invalid_series', __( 'Missing required series fields.', 'woocommerce-appointments' ) );
		}

		$product = wc_get_product( (int) $args['product_id'] );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			return new WP_Error( 'invalid_product', __( 'Invalid appointable product.', 'woocommerce-appointments' ) );
		}

		if ( empty( $args['timezone'] ) ) {
			return new WP_Error( 'invalid_timezone', __( 'Series timezone is required.', 'woocommerce-appointments' ) );
		}

		if ( class_exists( 'WC_Appointments_Location' ) && $product->has_locations() ) {
			$location_id = (int) ( $args['location_id'] ?? 0 );
			if ( 'customer_choice' === $product->get_location_mode() && $location_id <= 0 ) {
				return new WP_Error( 'wca_location_required', __( 'Please choose a location.', 'woocommerce-appointments' ) );
			}
			if ( $location_id > 0 && ! WC_Appointments_Location::authorize_location_id( $product, $location_id ) ) {
				return new WP_Error( 'wca_location_invalid', __( 'Selected location is not available for this product.', 'woocommerce-appointments' ) );
			}
		}

		return true;
	}

	/**
	 * @param int    $series_id Series id.
	 * @param int    $anchor_id Anchor occurrence (0 = wall-clock cutoff).
	 * @param string $scope     future|all.
	 * @param string $status    Target appointment status.
	 * @return array{ctx: array<string, mixed>, updated: int[]}|WP_Error
	 */
	protected function set_scoped_status( $series_id, $anchor_id, $scope, $status ) {
		return WC_Appointment_Series_Email::without_occurrence_emails(
			function () use ( $series_id, $anchor_id, $scope, $status ) {
				$scope   = 'all' === $scope ? 'all' : 'future';
				$ctx     = $this->scoped_rows( $series_id, $anchor_id );
				$updated = array();

				if ( is_wp_error( $ctx ) ) {
					return $ctx;
				}

				foreach ( $ctx['rows'] as $row ) {
					if ( ( 'all' !== $scope && (int) $row['start_ts'] < (int) $ctx['cutoff'] ) || (string) $row['status'] === $status ) {
						continue;
					}

					$this->set_occurrence_status( (int) $row['appointment_id'], $status );
					$updated[] = (int) $row['appointment_id'];
				}

				$ctx['scope'] = $scope;

				return array(
					'ctx'     => $ctx,
					'updated' => $updated,
				);
			}
		);
	}

	/**
	 * Scope context for emails / REST (anchor cutoff + occurrence rows).
	 *
	 * @param int $series_id Series id.
	 * @param int $anchor_id Anchor occurrence id (0 = wall-clock now).
	 * @return array{rows: array<int, array<string, mixed>>, cutoff: int}|WP_Error
	 */
	public function get_scope_context( $series_id, $anchor_id = 0 ) {
		return $this->scoped_rows( $series_id, $anchor_id );
	}

	/**
	 * @param int $series_id Series id.
	 * @return array<int, array{appointment_id: int, start_ts: int, end_ts: int, status: string, recurrence_id: string}>
	 */
	public function get_occurrence_rows( $series_id ) {
		return $this->get_series_occurrence_rows( $series_id );
	}

	/**
	 * @param int    $appointment_id Appointment id.
	 * @param string $status         Appointment status slug.
	 * @return void
	 */
	protected function set_occurrence_status( $appointment_id, $status ) {
		$appt = get_wc_appointment( $appointment_id );
		if ( ! $appt ) {
			return;
		}

		$appt->set_status( $status );
		$appt->save();
		do_action( 'wc_appointments_index_appointment', $appointment_id );
	}

	/**
	 * @param int $series_id Series id.
	 * @param int $anchor_id Anchor occurrence (0 = wall-clock cutoff).
	 * @return array{rows: array<int, array<string, mixed>>, cutoff: int}|WP_Error
	 */
	protected function scoped_rows( $series_id, $anchor_id = 0 ) {
		$rows = $this->get_series_occurrence_rows( $series_id );

		if ( $anchor_id > 0 ) {
			$anchor = get_wc_appointment( $anchor_id );
			if ( ! $anchor || (int) $anchor->get_meta( '_wca_series_id' ) !== (int) $series_id ) {
				return new WP_Error( 'invalid_appointment', __( 'Appointment not found in series.', 'woocommerce-appointments' ) );
			}

			$anchor_id = (int) $anchor->get_id();
			$cutoff    = (int) $anchor->get_start();

			foreach ( $rows as $row ) {
				if ( (int) $row['appointment_id'] === $anchor_id && (int) $row['start_ts'] > 0 ) {
					$cutoff = (int) $row['start_ts'];
					break;
				}
			}

			return array(
				'rows'   => $rows,
				'cutoff' => $cutoff,
			);
		}

		return array(
			'rows'   => $rows,
			'cutoff' => $this->fake_utc_now( $series_id ),
		);
	}

	/**
	 * "Now" on the series Fake-UTC axis (store wall clock labelled UTC).
	 *
	 * Occurrence start_ts values are Fake UTC, so a raw real-UTC `time()` cutoff would be
	 * skewed by the store offset and misclassify occurrences near the present moment.
	 *
	 * @param int $series_id Series id.
	 * @return int Fake-UTC epoch (falls back to real time when the zone is unavailable).
	 */
	protected function fake_utc_now( $series_id ) {
		try {
			$series = new WC_Appointment_Series( (int) $series_id );
		} catch ( Exception $e ) {
			unset( $e );
			return time();
		}

		$tz_id = $series->get_timezone();
		if ( '' === $tz_id ) {
			return time();
		}

		try {
			return WC_Appointment_Series_RRule::instant_to_fake_utc( time(), new DateTimeZone( $tz_id ) );
		} catch ( Exception $e ) {
			unset( $e );
			return time();
		}
	}

	/**
	 * Series occurrences with parsed schedule (same SQL as REST /occurrences).
	 *
	 * @param int $series_id Series id.
	 * @return array<int, array{appointment_id: int, start_ts: int, end_ts: int, status: string, recurrence_id: string}>
	 */
	protected function get_series_occurrence_rows( $series_id ) {
		global $wpdb;

		$series_id = (int) $series_id;
		if ( $series_id <= 0 ) {
			return array();
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table names.
		$sql = $wpdb->prepare(
			"SELECT p.ID AS appointment_id,
				start_meta.meta_value AS start_raw,
				end_meta.meta_value AS end_raw,
				rid_meta.meta_value AS recurrence_id,
				p.post_status AS status
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} sid
				ON p.ID = sid.post_id AND sid.meta_key = '_wca_series_id' AND sid.meta_value = %s
			LEFT JOIN {$wpdb->postmeta} start_meta
				ON p.ID = start_meta.post_id AND start_meta.meta_key = '_appointment_start'
			LEFT JOIN {$wpdb->postmeta} end_meta
				ON p.ID = end_meta.post_id AND end_meta.meta_key = '_appointment_end'
			LEFT JOIN {$wpdb->postmeta} rid_meta
				ON p.ID = rid_meta.post_id AND rid_meta.meta_key = '_wca_recurrence_id'
			WHERE p.post_type = 'wc_appointment'
			AND p.post_status != 'trash'
			ORDER BY start_meta.meta_value ASC",
			(string) $series_id
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- built above.
		$rows = $wpdb->get_results( $sql );
		$out  = array();

		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'appointment_id' => (int) $row->appointment_id,
				'start_ts'       => WC_Appointment_Series::parse_wall_meta_ts( $row->start_raw ?? '' ),
				'end_ts'         => WC_Appointment_Series::parse_wall_meta_ts( $row->end_raw ?? '' ),
				'recurrence_id'  => (string) ( $row->recurrence_id ?? '' ),
				'status'         => str_replace( 'wc-', '', (string) ( $row->status ?? '' ) ),
			);
		}

		return $out;
	}

	/**
	 * @param int $series_id Series id.
	 * @return int[]
	 */
	protected function get_series_appointments( $series_id ) {
		return array_map(
			function ( $row ) {
				return (int) $row['appointment_id'];
			},
			$this->get_series_occurrence_rows( $series_id )
		);
	}

	/**
	 * @param int    $series_id     Series id.
	 * @param string $recurrence_id RECURRENCE-ID.
	 * @return int
	 */
	protected function find_appointment_by_recurrence( $series_id, $recurrence_id ) {
		$query = new WP_Query(
			array(
				'post_type'      => 'wc_appointment',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				'no_found_rows'  => true,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => '_wca_series_id',
						'value' => (int) $series_id,
					),
					array(
						'key'   => '_wca_recurrence_id',
						'value' => $recurrence_id,
					),
				),
			)
		);

		return ! empty( $query->posts ) ? (int) $query->posts[0] : 0;
	}
}
