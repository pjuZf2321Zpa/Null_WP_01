<?php
/**
 * Idempotency key storage for series mutations (24h TTL).
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Idempotency table access.
 */
class WC_Appointment_Series_Idempotency {

	const TABLE = 'wc_appointment_series_idempotency';

	const TTL_SECONDS = DAY_IN_SECONDS;

	/**
	 * Look up a stored response for this key and body hash.
	 *
	 * @param  string $key       Idempotency-Key header value.
	 * @param  string $body_hash sha256 of canonical request body.
	 * @return array{code:int,body:string}|null
	 * @throws WC_Appointment_Series_Idempotency_Conflict When key exists with different hash.
	 */
	public function lookup( $key, $body_hash ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE;
		$sql   = sprintf(
			'SELECT request_hash, response_code, response_body FROM %s WHERE idempotency_key = %%s AND expires_at > %%s',
			$table
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$key,
				current_time( 'mysql', true )
			),
			ARRAY_A
		);

		if ( ! $row ) {
			return null;
		}

		if ( ! hash_equals( $row['request_hash'], $body_hash ) ) {
			throw new WC_Appointment_Series_Idempotency_Conflict( $key );
		}

		return array(
			'code' => (int) $row['response_code'],
			'body' => (string) $row['response_body'],
		);
	}

	/**
	 * Persist a response for replay.
	 *
	 * @param string $key       Idempotency key.
	 * @param string $body_hash Request body hash.
	 * @param int    $series_id Series id (0 before create).
	 * @param int    $code      HTTP status code.
	 * @param string $body      Serialized response body.
	 * @return void
	 */
	public function store( $key, $body_hash, $series_id, $code, $body ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->replace(
			$wpdb->prefix . self::TABLE,
			array(
				'idempotency_key' => $key,
				'series_id'       => (int) $series_id,
				'request_hash'    => $body_hash,
				'response_code'   => (int) $code,
				'response_body'   => $body,
				'expires_at'      => gmdate( 'Y-m-d H:i:s', time() + self::TTL_SECONDS ),
			),
			array( '%s', '%d', '%s', '%d', '%s', '%s' )
		);
	}

	/**
	 * Hash a request body for idempotency comparison.
	 *
	 * @param  array<string, mixed> $body Request body.
	 * @return string
	 */
	public static function hash_body( $body ) {
		ksort( $body );
		return hash( 'sha256', wp_json_encode( $body ) );
	}

	/**
	 * Delete expired idempotency rows.
	 *
	 * @param  int $limit Max rows to delete per call.
	 * @return int Rows deleted.
	 */
	public function prune_expired( $limit = 1000 ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE;
		$sql   = sprintf( 'DELETE FROM %s WHERE expires_at <= %%s LIMIT %%d', $table );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->query(
			$wpdb->prepare(
				$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				current_time( 'mysql', true ),
				$limit
			)
		);
	}
}
