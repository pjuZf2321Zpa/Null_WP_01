<?php
/**
 * Virtual in-cart occupancy for recurring prepaid cart lines (until order materializes).
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Unsaved WC_Appointment objects from wca_recurring.session_starts for the slots engine.
 */
class WC_Appointment_Recurring_Cart_Occupancy {

	/**
	 * Saved + in-cart recurring virtual appointments for occupancy (overlap index, per-day caps).
	 *
	 * @param WC_Product_Appointment $product     Product.
	 * @param int                    $range_start Range start (inclusive).
	 * @param int                    $range_end   Range end (exclusive).
	 * @param int                    $staff_id    Staff filter (0 = all).
	 * @return WC_Appointment[]
	 */
	public static function occupying_appointments_for_product( WC_Product_Appointment $product, int $range_start, int $range_end, int $staff_id = 0 ): array {
		return array_merge(
			WC_Appointment_Data_Store::get_all_existing_appointments( $product, $range_start, $range_end, (array) $staff_id ),
			self::appointments_for_product( $product, $range_start, $range_end, $staff_id )
		);
	}

	/**
	 * @param WC_Product_Appointment $product       Product.
	 * @param int                    $range_start   Range start (inclusive).
	 * @param int                    $range_end     Range end (exclusive).
	 * @param int                    $staff_id      Staff filter (0 = all).
	 * @param string                 $cart_item_key When set, only that cart line.
	 * @return WC_Appointment[]
	 */
	public static function appointments_for_product( WC_Product_Appointment $product, int $range_start, int $range_end, int $staff_id = 0, string $cart_item_key = '' ): array {
		if ( $range_end <= $range_start || ! function_exists( 'WC' ) || ! did_action( 'wp_loaded' ) ) {
			return array();
		}

		if ( ! WC()->cart && did_action( 'woocommerce_init' ) ) {
			wc_load_cart();
		}

		$cart = WC()->cart;
		if ( ! $cart || $cart->is_empty() || WC_Appointment_Cart_Manager::is_cart_simulation_request() ) {
			return array();
		}

		$product_id = $product->get_id();
		$out        = array();

		foreach ( $cart->get_cart() as $key => $item ) {
			if ( ( $cart_item_key && $key !== $cart_item_key )
				|| (int) ( $item['product_id'] ?? 0 ) !== $product_id
				|| empty( $item['wca_recurring'] ) ) {
				continue;
			}

			$r      = $item['wca_recurring'];
			$starts = array_filter( array_map( 'intval', (array) ( $r['session_starts'] ?? array() ) ) );
			if ( ! $starts ) {
				continue;
			}

			$duration = (int) ( $r['duration_seconds'] ?? 0 );
			if ( $duration <= 0 ) {
				$duration = (int) $product->get_duration_in_minutes() * MINUTE_IN_SECONDS;
				if ( $duration <= 0 ) {
					continue;
				}
			}

			$lock      = (int) ( $r['locked_staff_id'] ?? 0 );
			$pick      = (int) ( $r['staff_id'] ?? 0 );
			$staff_ids = wc_appointments_normalize_staff_ids(
				$lock > 0 ? $lock : ( $pick > 0 ? $pick : ( $item['appointment']['_staff_ids'] ?? $item['appointment']['_staff_id'] ?? array() ) )
			);
			if ( ! $staff_ids && $product->has_staff() ) {
				$staff_ids = wc_appointments_normalize_staff_ids( $product->get_staff_ids() );
			}
			if ( $staff_id > 0 && $staff_ids && ! in_array( $staff_id, $staff_ids, true ) ) {
				continue;
			}

			$qty = max( 1, (int) ( $item['appointment']['_qty'] ?? 1 ) );

			foreach ( $starts as $start ) {
				$end = $start + $duration;
				if ( $start <= 0 || $start >= $range_end || $end <= $range_start ) {
					continue;
				}

				$a = new WC_Appointment();
				$a->set_id( - (int) sprintf( '%u', crc32( $key . '|' . $start ) ) );
				$a->set_product_id( $product_id );
				$a->set_start( $start );
				$a->set_end( $end );
				$a->set_qty( $qty );
				$a->set_status( WC_Appointments_Constants::STATUS_IN_CART );
				$loc = (int) ( $item['appointment']['_location_id'] ?? 0 );
				if ( $loc > 0 ) {
					$a->set_location_id( $loc );
				}
				$cart_allocs = $item['appointment']['_resource_allocations'] ?? [];
				if ( is_array( $cart_allocs ) && [] !== $cart_allocs ) {
					$a->set_resource_allocations( $cart_allocs );
				}
				if ( $staff_ids ) {
					$a->set_staff_ids( $staff_ids );
				}
				$out[] = $a;
			}
		}

		return $out;
	}
}
