<?php
/**
 * Recurring series — admin list hint + classic edit metabox.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * @internal List hint + appointment edit metabox only.
 */
final class WC_Appointment_Series_Admin {

	/**
	 * @var bool
	 */
	private static $scripts_enqueued = false;

	/**
	 * Admin hooks (call from WC_Appointment_Series_Events::init).
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! is_admin() || ! WC_Appointment_Series_Events::is_enabled() ) {
			return;
		}

		add_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_box' ), 20, 2 );
	}

	/**
	 * @param WC_Appointment|int|null $appointment Appointment or post ID.
	 * @return array{count: string, title: string}|null
	 */
	public static function get_list_hint( $appointment ) {
		$data = self::load( $appointment, false );

		return $data ? $data['hint'] : null;
	}

	/**
	 * @param array{count?: string, title?: string} $hint List hint.
	 * @return void
	 */
	public static function echo_list_hint_markup( $hint ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::get_list_hint_markup( $hint );
	}

	/**
	 * @param array{count?: string, title?: string} $hint List hint.
	 * @return string
	 */
	public static function get_list_hint_markup( $hint ) {
		if ( empty( $hint['count'] ) ) {
			return '';
		}

		return '<br /><abbr class="wca-list-recurring" title="' . esc_attr( $hint['title'] ?? '' ) . '">'
			. '<span class="wca-list-recurring__icon" aria-hidden="true">&#8635;</span>'
			. '<span class="wca-list-recurring__count">' . esc_html( $hint['count'] ) . '</span></abbr>';
	}

	/**
	 * @param string  $post_type Post type.
	 * @param WP_Post $post      Post.
	 * @return void
	 */
	public static function register_meta_box( $post_type, $post ) {
		if ( 'wc_appointment' !== $post_type || ! $post instanceof WP_Post ) {
			return;
		}

		if ( (int) get_post_meta( $post->ID, '_wca_series_id', true ) <= 0 ) {
			return;
		}

		add_meta_box(
			'woocommerce-appointment-series',
			__( 'Recurring package', 'woocommerce-appointments' ),
			array( __CLASS__, 'render_meta_box' ),
			$post_type,
			'normal',
			'default'
		);
	}

	/**
	 * @param WP_Post $post Appointment post.
	 * @return void
	 */
	public static function render_meta_box( $post ) {
		$data = self::load( $post->ID, true );
		if ( ! $data ) {
			return;
		}

		self::enqueue_scripts();

		$pattern = $data['pattern'];

		$expand   = esc_attr__( 'Show all appointments', 'woocommerce-appointments' );
		$collapse = esc_attr__( 'Hide appointments', 'woocommerce-appointments' );
		?>
		<div class="wca-series-meta">
			<?php if ( $pattern ) : ?>
				<p class="description wca-series-meta__pattern"><?php echo esc_html( $pattern ); ?></p>
			<?php endif; ?>

			<?php if ( $data['sessions'] ) : ?>
				<?php if ( ! empty( $data['hint']['count'] ) ) : ?>
					<template class="wca-series-hint-src">
						<span class="wca-series-meta-box-title-wrap">
							<span class="wca-series-meta-box-title-label"><?php esc_html_e( 'Recurring package', 'woocommerce-appointments' ); ?></span>
							<?php
							// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- abbr markup only.
							echo preg_replace( '#^<br\s*/?>#', '', self::get_list_hint_markup( $data['hint'] ) );
							?>
						</span>
					</template>
				<?php endif; ?>

				<button type="button" class="button-link wca-series-meta__sessions-toggle" aria-expanded="false"
					aria-controls="wca-series-meta-sessions-panel"
					data-label-expand="<?php echo esc_attr( $expand ); ?>"
					data-label-collapse="<?php echo esc_attr( $collapse ); ?>">
					<?php esc_html_e( 'Show all appointments', 'woocommerce-appointments' ); ?>
				</button>
				<ul id="wca-series-meta-sessions-panel" class="wca-series-meta__sessions-list" hidden>
					<?php foreach ( $data['sessions'] as $session ) : ?>
						<li class="wca-series-meta__sessions-item<?php echo $session['current'] ? ' is-current' : ''; ?>">
							<span class="wca-series-meta__sessions-when">
								<?php if ( $session['current'] ) : ?>
									<strong><?php echo esc_html( $session['when'] ); ?></strong>
									<span class="description"><?php esc_html_e( 'This appointment', 'woocommerce-appointments' ); ?></span>
								<?php else : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $session['id'] ) ); ?>"><?php echo esc_html( $session['when'] ); ?></a>
								<?php endif; ?>
							</span>
							<mark class="appointment-status status-<?php echo esc_attr( $session['status'] ); ?>">
								<span><?php echo esc_html( $session['status_label'] ); ?></span>
							</mark>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * @param WC_Appointment|int|null $appointment   Appointment or ID.
	 * @param bool                    $with_sessions Load sibling rows (edit metabox only).
	 * @return array<string, mixed>|null
	 */
	private static function load( $appointment, $with_sessions ) {
		$appointment = is_numeric( $appointment ) ? get_wc_appointment( (int) $appointment ) : $appointment;
		if ( ! $appointment || ! is_a( $appointment, 'WC_Appointment' ) ) {
			return null;
		}

		$series_id = (int) $appointment->get_meta( '_wca_series_id' );
		if ( $series_id <= 0 ) {
			return null;
		}

		$occurrence = (int) $appointment->get_meta( '_wca_series_occurrence' );
		$total      = 0;
		$pattern    = '';

		try {
			$series = new WC_Appointment_Series( $series_id );
			$total  = $series->get_rrule_count_cap();
			if ( $total <= 0 ) {
				$total = WC_Appointment_Series_RRule::parse_count_cap( $series->get_rrule() );
			}
			$humanize_opts = WC_Appointment_Series_RRule::humanize_wp_date_opts();
			if ( $total > 0 ) {
				$humanize_opts['count_cap'] = $total;
			}
			$pattern = WC_Appointment_Series_RRule::humanize(
				$series->get_rrule(),
				$series->get_dtstart_ts(),
				$series->get_timezone(),
				$humanize_opts
			);
		} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			unset( $e );
		}

		$title_parts = array( __( 'Recurring package', 'woocommerce-appointments' ) );
		if ( $pattern ) {
			$title_parts[] = $pattern;
		}
		if ( $occurrence > 0 && $total > 0 ) {
			$title_parts[] = sprintf(
				/* translators: %1$d: current appointment number in series, %2$d: total appointments in series */
				__( 'Appointment %1$d of %2$d', 'woocommerce-appointments' ),
				$occurrence,
				$total
			);
		}

		$count = ( $occurrence > 0 && $total > 0 ) ? $occurrence . '/' . $total : '';
		$out   = array(
			'hint'     => array(
				'count' => $count,
				'title' => implode( '. ', $title_parts ),
			),
			'pattern'  => $pattern,
			'sessions' => array(),
		);

		if ( ! $with_sessions ) {
			return $out;
		}

		$query = new WP_Query(
			array(
				'post_type'      => 'wc_appointment',
				'post_status'    => 'any',
				'posts_per_page' => 50,
				'no_found_rows'  => true,
				'meta_key'       => '_appointment_start',
				'orderby'        => 'meta_value_num',
				'order'          => 'ASC',
				'meta_query'     => array(
					array(
						'key'   => '_wca_series_id',
						'value' => $series_id,
					),
				),
			)
		);

		$current_id = (int) $appointment->get_id();
		foreach ( (array) $query->posts as $row ) {
			$appt = get_wc_appointment( $row->ID );
			if ( ! $appt ) {
				continue;
			}
			$status = str_replace( 'wc-', '', (string) $appt->get_status() );
			$out['sessions'][] = array(
				'id'            => (int) $appt->get_id(),
				'when'          => $appt->get_start_date(),
				'status'        => $status,
				'status_label'  => wc_appointments_get_status_label( $status ),
				'current'       => (int) $appt->get_id() === $current_id,
			);
		}

		return $out;
	}

	/**
	 * One inline script per edit screen (header hint clone + sessions toggle).
	 *
	 * @return void
	 */
	private static function enqueue_scripts() {
		if ( self::$scripts_enqueued ) {
			return;
		}
		self::$scripts_enqueued = true;

		wp_register_script( 'wca-series-meta-edit', false, array(), WC_APPOINTMENTS_VERSION, true );
		wp_enqueue_script( 'wca-series-meta-edit' );
		wp_add_inline_script(
			'wca-series-meta-edit',
			"(function(){var b=document.getElementById('woocommerce-appointment-series');if(!b)return;"
			. "var h=b.querySelector('.postbox-header .hndle,.hndle'),t=b.querySelector('.wca-series-hint-src');"
			. "if(h&&t&&!h.querySelector('.wca-list-recurring')){h.textContent='';h.appendChild(t.content.cloneNode(true));}"
			. "var n=b.querySelector('.wca-series-meta__sessions-toggle'),p=b.querySelector('#wca-series-meta-sessions-panel');"
			. "if(!n||!p)return;n.addEventListener('click',function(){var o=n.getAttribute('aria-expanded')==='true';"
			. "o=!o;n.setAttribute('aria-expanded',o?'true':'false');p.hidden=!o;"
			. "n.textContent=o?n.getAttribute('data-label-collapse'):n.getAttribute('data-label-expand');});})();"
		);
	}
}
