<?php
/**
 * Batch materialization of series occurrences into wc_appointment posts.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Creates occurrence appointments and advances series materialization cursors.
 */
class WC_Appointment_Series_Materializer {

	const AS_HOOK  = 'wca/series/materialize';
	const AS_GROUP = 'wca/series';

	/**
	 * Action Scheduler callback.
	 *
	 * @param int    $series_id   Series id.
	 * @param int    $batch_size  Batch size.
	 * @param string $request_id  Optional trace id.
	 * @param int    $order_id    Optional parent order id.
	 * @return void
	 */
	public static function on_async_materialize( $series_id, $batch_size = 50, $request_id = '', $order_id = 0 ) {
		( new self() )->materialize_batch( (int) $series_id, (int) $batch_size, (string) $request_id, (int) $order_id );
	}

	/**
	 * Enqueue async materialization for a series.
	 *
	 * @param int $series_id Series id.
	 * @return void
	 */
	public static function schedule( $series_id ) {
		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			return;
		}

		$batch = (int) apply_filters( 'wc_appointments_series_materialize_batch', 50, $series_id );

		as_enqueue_async_action(
			self::AS_HOOK,
			array(
				'series_id'  => (int) $series_id,
				'batch_size' => $batch,
				'request_id' => '',
			),
			self::AS_GROUP
		);
	}

	/**
	 * Materialize occurrences (RRULE batch, or a fixed map for prepaid checkout).
	 *
	 * @param int                     $series_id      Series id.
	 * @param int                     $batch_size     Max new occurrences (ignored when $occurrences set).
	 * @param string                  $request_id     Unused.
	 * @param int                     $order_id       Order id for new occurrences.
	 * @param array<string, int>|null $occurrences    Optional recurrence_id => start_ts.
	 * @param int                     $order_item_id  Order line id when $occurrences is set.
	 * @param bool                    $prepaid_finish Complete series and link line meta.
	 * @return int Number of appointments created.
	 */
	public function materialize_batch( $series_id, $batch_size, $request_id = '', $order_id = 0, $occurrences = null, $order_item_id = 0, $prepaid_finish = false ) {
		unset( $request_id );

		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return 0;
		}

		if ( null === $occurrences && $batch_size <= 0 ) {
			return 0;
		}

		return (int) WC_Appointment_Series_Email::without_occurrence_emails(
			function () use ( $series_id, $batch_size, $order_id, $occurrences, $order_item_id, $prepaid_finish ) {
				return $this->materialize_batch_inner( $series_id, $batch_size, $order_id, $occurrences, $order_item_id, $prepaid_finish );
			}
		);
	}

	/**
	 * @param int                     $series_id      Series id.
	 * @param int                     $batch_size     Batch size.
	 * @param int                     $order_id       Order id.
	 * @param array<string, int>|null $occurrences    Recurrence map.
	 * @param int                     $order_item_id  Order line id.
	 * @param bool                    $prepaid_finish Prepaid completion flag.
	 * @return int Created count.
	 */
	protected function materialize_batch_inner( $series_id, $batch_size, $order_id = 0, $occurrences = null, $order_item_id = 0, $prepaid_finish = false ) {
		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			return 0;
		}

		if ( null === $occurrences && WC_Appointment_Series::STATUS_ACTIVE !== $series->get_status() ) {
			return 0;
		}

		$is_pay_first = WC_Appointment_Series::PAYMENT_PAY_FIRST === $series->get_payment_model();

		if ( null === $occurrences ) {
			$rrule = new WC_Appointment_Series_RRule(
				$series->get_rrule(),
				$series->get_dtstart_ts(),
				$series->get_timezone()
			);

			$tz          = new DateTimeZone( $series->get_timezone() );
			$range_start = WC_Appointment_Series_RRule::fake_utc_to_zoned(
				max( $series->get_next_materialize_ts(), $series->get_dtstart_ts() ),
				$tz
			);
			$range_end = WC_Appointment_Series_RRule::expansion_range_end(
				$range_start,
				$series->get_rrule(),
				$series->get_timezone()
			);

			$occurrences = $rrule->expand( $range_start, $range_end, $batch_size );
		}

		if ( empty( $occurrences ) ) {
			return 0;
		}

		$created         = 0;
		$last_ts         = $series->get_last_materialized_ts();
		$count_so_far    = $series->get_materialized_count();
		$expected_ver    = $series->get_version();
		$appointment_ids = array();
		$existing        = $this->load_batch_appointment_state( $series_id, array_keys( $occurrences ) );

		foreach ( $occurrences as $recurrence_id => $start_ts ) {
			if ( isset( $existing['materialized'][ $recurrence_id ] ) || isset( $existing['overrides'][ $recurrence_id ] ) ) {
				continue;
			}

			$occurrence_index = $count_so_far + 1;

			// For pay_first: only link the FIRST billable occurrence to the parent order.
			// Subsequent occurrences get order_id=0 until a balance order is created.
			$occ_order_id = $order_id;
			if ( $is_pay_first && $occurrence_index > 1 ) {
				$occ_order_id = 0;
			}

			$appointment_id = $this->create_occurrence( $series, $recurrence_id, (int) $start_ts, $occurrence_index, (int) $occ_order_id, (int) $order_item_id, $is_pay_first );
			if ( $appointment_id <= 0 ) {
				continue;
			}

			++$created;
			++$count_so_far;
			$last_ts             = max( $last_ts, (int) $start_ts );
			$appointment_ids[]   = $appointment_id;
			do_action( 'wc_appointments_index_appointment', $appointment_id );

			if ( WC_Appointment_Series::STAFF_LOCK_TO_FIRST === $series->get_staff_assignment_mode() && ! $series->get_locked_staff_id() ) {
				$appt = get_wc_appointment( $appointment_id );
				if ( $appt ) {
					$staff_ids = $appt->get_staff_ids();
					if ( ! empty( $staff_ids ) ) {
						$series->set_locked_staff_id( (int) reset( $staff_ids ) );
					}
				}
			}
		}

		if ( $last_ts > 0 ) {
			$series->set_last_materialized_ts( $last_ts );
			$series->set_next_materialize_ts( $prepaid_finish ? 0 : $last_ts + 1 );
		}

		$series->set_materialized_count( $count_so_far );

		if ( $series->get_rrule_count_cap() > 0 && $count_so_far >= $series->get_rrule_count_cap() ) {
			$series->set_status( WC_Appointment_Series::STATUS_COMPLETED );
		}

		// Occurrence posts above are already committed. Persist the advanced cursors even
		// if a concurrent mutation bumped the row version: re-apply on a fresh load so
		// materialized_count / next_materialize_ts never stall (which would loop the daily
		// sweep on the same window). The batch dedupe guarantees no duplicate appointments.
		$series = $this->persist_materialization_cursors(
			(int) $series_id,
			$series,
			(int) $expected_ver,
			array(
				'status'             => $series->get_status( 'edit' ),
				'last_materialized'  => (int) $last_ts,
				'materialized_count' => (int) $count_so_far,
				'next_materialize'   => $prepaid_finish ? 0 : ( $last_ts > 0 ? $last_ts + 1 : null ),
				'locked_staff_id'    => (int) $series->get_locked_staff_id( 'edit' ),
				'prepaid_finish'     => (bool) $prepaid_finish,
			)
		);

		if ( $prepaid_finish && $order_item_id > 0 && $appointment_ids ) {
			$merged = array_values(
				array_unique(
					array_merge(
						wp_parse_id_list( (array) wc_get_order_item_meta( $order_item_id, '_appointment_id', true ) ),
						$appointment_ids
					)
				)
			);
			wc_update_order_item_meta( $order_item_id, '_appointment_id', $merged );
		}

		if ( ! $prepaid_finish && WC_Appointment_Series::STATUS_ACTIVE === $series->get_status() && $this->needs_more_materialization( $series ) ) {
			self::schedule( $series->get_id() );
		}

		return $created;
	}

	/**
	 * Persist advanced materialization cursors with optimistic-lock retry.
	 *
	 * On a version conflict the row is reloaded and the cursor targets are merged onto the
	 * fresh state (monotonic max), then retried. After a few attempts it gives up silently:
	 * the occurrence posts already exist and the daily sweep reconciles, so a conflict must
	 * never bubble up and fail the Action Scheduler job.
	 *
	 * @param int                   $series_id     Series id.
	 * @param WC_Appointment_Series $series        Series with first-attempt values applied.
	 * @param int                   $expected_ver  Version expected for the first attempt.
	 * @param array<string, mixed>  $targets       Cursor targets to re-apply on reload.
	 * @return WC_Appointment_Series Persisted (or last-known) series object.
	 */
	protected function persist_materialization_cursors( $series_id, WC_Appointment_Series $series, $expected_ver, array $targets ) {
		$attempt = 0;

		while ( true ) {
			try {
				$series->get_data_store()->update_if_version( $series, (int) $expected_ver );
				return $series;
			} catch ( WC_Appointment_Series_Version_Conflict $e ) {
				unset( $e );
				if ( ++$attempt >= 3 ) {
					return $series;
				}

				try {
					$fresh = new WC_Appointment_Series( (int) $series_id );
				} catch ( Exception $ex ) {
					unset( $ex );
					return $series;
				}

				$expected_ver = $fresh->get_version();
				$this->apply_cursor_targets( $fresh, $targets );
				$series = $fresh;
			}
		}
	}

	/**
	 * Merge cursor targets onto a freshly loaded series (monotonic, conflict-safe).
	 *
	 * @param WC_Appointment_Series $series  Fresh series.
	 * @param array<string, mixed>  $targets Cursor targets from this batch.
	 * @return void
	 */
	protected function apply_cursor_targets( WC_Appointment_Series $series, array $targets ) {
		if ( null !== $targets['next_materialize'] ) {
			$series->set_last_materialized_ts( max( $series->get_last_materialized_ts(), (int) $targets['last_materialized'] ) );
			$series->set_next_materialize_ts(
				! empty( $targets['prepaid_finish'] ) ? 0 : max( $series->get_next_materialize_ts(), (int) $targets['next_materialize'] )
			);
		} elseif ( ! empty( $targets['prepaid_finish'] ) ) {
			$series->set_next_materialize_ts( 0 );
		}

		$series->set_materialized_count( max( $series->get_materialized_count(), (int) $targets['materialized_count'] ) );

		if ( (int) $targets['locked_staff_id'] > 0 && ! $series->get_locked_staff_id() ) {
			$series->set_locked_staff_id( (int) $targets['locked_staff_id'] );
		}

		// Respect a concurrent terminal cancel; otherwise honour the computed status.
		if ( WC_Appointment_Series::STATUS_CANCELLED !== $series->get_status() ) {
			$series->set_status( (string) $targets['status'] );
		}
	}

	/**
	 * Prepaid/pay-first checkout: materialize sessions sold on the order line (no availability re-check).
	 *
	 * @param int    $series_id      Series id.
	 * @param int[]  $session_starts Fake UTC starts from `_wca_recurring`.
	 * @param int    $order_id       Order id.
	 * @param int    $order_item_id  Order line id.
	 * @return int Appointments created.
	 */
	public function materialize_committed_sessions( $series_id, $session_starts, $order_id = 0, $order_item_id = 0 ) {
		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			return 0;
		}

		$map = array();
		foreach ( array_unique( array_filter( array_map( 'intval', (array) $session_starts ) ) ) as $start_ts ) {
			$map[ WC_Appointment_Series_RRule::recurrence_id_from_fake_utc( $start_ts, $series->get_timezone() ) ] = $start_ts;
		}

		return $this->materialize_batch( $series_id, count( $map ), '', $order_id, $map, $order_item_id, true );
	}

	/**
	 * Whether more occurrences remain before the series end (COUNT/UNTIL or expansion window).
	 *
	 * @param WC_Appointment_Series $series Series.
	 * @return bool
	 */
	public function needs_more_materialization( WC_Appointment_Series $series ) {
		if ( WC_Appointment_Series::STATUS_ACTIVE !== $series->get_status() ) {
			return false;
		}

		if ( $series->get_rrule_count_cap() > 0 && $series->get_materialized_count() >= $series->get_rrule_count_cap() ) {
			return false;
		}

		$tz          = new DateTimeZone( $series->get_timezone() );
		$range_start = WC_Appointment_Series_RRule::fake_utc_to_zoned(
			max( $series->get_next_materialize_ts(), $series->get_dtstart_ts() ),
			$tz
		);
		$range_end = WC_Appointment_Series_RRule::expansion_range_end(
			$range_start,
			$series->get_rrule(),
			$series->get_timezone()
		);

		$rrule = new WC_Appointment_Series_RRule(
			$series->get_rrule(),
			$series->get_dtstart_ts(),
			$series->get_timezone()
		);

		$ahead = $rrule->expand( $range_start, $range_end, 1 );

		return ! empty( $ahead );
	}

	/**
	 * Load materialized and override recurrence ids for a batch in one query.
	 *
	 * @param int      $series_id      Series id.
	 * @param string[] $recurrence_ids RECURRENCE-ID values.
	 * @return array{materialized: array<string, bool>, overrides: array<string, bool>}
	 */
	protected function load_batch_appointment_state( $series_id, $recurrence_ids ) {
		$state = array(
			'materialized' => array(),
			'overrides'    => array(),
		);

		$recurrence_ids = array_values( array_filter( array_map( 'strval', $recurrence_ids ) ) );
		if ( empty( $recurrence_ids ) ) {
			return $state;
		}

		global $wpdb;

		$placeholders = implode( ', ', array_fill( 0, count( $recurrence_ids ), '%s' ) );
		$sql          = "SELECT rid.meta_value AS recurrence_id, ov.meta_value AS is_override
			FROM {$wpdb->postmeta} sid
			INNER JOIN {$wpdb->postmeta} rid ON sid.post_id = rid.post_id AND rid.meta_key = '_wca_recurrence_id'
			LEFT JOIN {$wpdb->postmeta} ov ON sid.post_id = ov.post_id AND ov.meta_key = '_wca_is_series_override'
			WHERE sid.meta_key = '_wca_series_id' AND sid.meta_value = %d
			AND rid.meta_value IN ({$placeholders})";

		$params = array_merge( array( (int) $series_id ), $recurrence_ids );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- placeholders built from count.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );

		if ( empty( $rows ) ) {
			return $state;
		}

		foreach ( $rows as $row ) {
			$rid = (string) $row->recurrence_id;
			$state['materialized'][ $rid ] = true;
			if ( 'yes' === (string) $row->is_override ) {
				$state['overrides'][ $rid ] = true;
			}
		}

		return $state;
	}

	/**
	 * @param WC_Appointment_Series $series           Series.
	 * @param string                $recurrence_id    RECURRENCE-ID.
	 * @param int                   $start_ts         Fake UTC start.
	 * @param int                   $occurrence_index 1-based index.
	 * @param int                   $order_id         Order id (0 for pay_first non-first occurrences).
	 * @param int                   $order_item_id    Order line id.
	 * @param bool                  $is_pay_first     Whether this is a pay-first series.
	 * @return int Appointment id or 0.
	 */
	protected function create_occurrence( WC_Appointment_Series $series, $recurrence_id, $start_ts, $occurrence_index, $order_id = 0, $order_item_id = 0, $is_pay_first = false ) {
		$duration = max( 1, (int) $series->get_duration_seconds() );
		if ( 1 === (int) $occurrence_index ) {
			$duration += max( 0, (int) $series->get_meta( '_wca_once_per_series_addon_duration_seconds', true ) );
		}

		$appt = new WC_Appointment();
		$appt->set_product_id( $series->get_product_id() );
		$appt->set_customer_id( $series->get_customer_id() );
		$appt->set_staff_ids( $this->resolve_staff_for( $series ) );
		$location_id = (int) $series->get_meta( '_wca_location_id', true );
		$location    = $series->get_meta( '_wca_location', true );
		if ( $location_id > 0 && class_exists( 'WC_Appointments_Location' ) ) {
			WC_Appointments_Location::apply_to_appointment(
				$appt,
				$location_id,
				is_array( $location ) ? $location : null
			);
		}

		// Resource allocations from product requirements.
		$product = wc_get_product( $series->get_product_id() );
		if ( class_exists( 'WC_Appointments_Resource' ) && $product instanceof WC_Product_Appointment ) {
			WC_Appointments_Resource::apply_to_appointment(
				$appt,
				WC_Appointments_Resource::build_allocations_from_product(
					$product,
					0,
					$location_id,
					(int) $start_ts,
					(int) $start_ts + $duration
				)
			);
		}

		$appt->set_start( $start_ts );
		$appt->set_end( $start_ts + $duration );
		$appt->set_qty( $series->get_qty() );
		$appt->set_status( apply_filters( 'wc_appointments_series_occurrence_status', 'confirmed', $series, $recurrence_id, $start_ts ) );

		// For non-pay-first: fall back to series order_id when none explicitly provided.
		// For pay-first: only the first occurrence links to the parent order.
		if ( $is_pay_first ) {
			if ( $order_id > 0 ) {
				$appt->set_order_id( $order_id );
			}
		} else {
			$linked_order = $order_id > 0 ? $order_id : (int) $series->get_order_id();
			if ( $linked_order > 0 ) {
				$appt->set_order_id( $linked_order );
			}
		}
		if ( $order_item_id > 0 ) {
			$appt->set_order_item_id( $order_item_id );
		}

		$appt->update_meta_data( '_wca_series_id', $series->get_id() );
		$appt->update_meta_data( '_wca_recurrence_id', $recurrence_id );
		$appt->update_meta_data( '_wca_series_occurrence', (int) $occurrence_index );

		if ( $is_pay_first ) {
			$payment_status = 1 === (int) $occurrence_index ? 'paid' : 'due';
			$appt->update_meta_data( '_wca_series_payment_status', $payment_status );
		}

		$series_tz = (string) $series->get_timezone();
		if ( $series_tz && class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::is_valid_timezone( $series_tz ) ) {
			$appt->set_local_timezone( $series_tz );
		}

		$appt->save();

		return (int) $appt->get_id();
	}

	/**
	 * @param WC_Appointment_Series $series Series.
	 * @return int[]
	 */
	protected function resolve_staff_for( WC_Appointment_Series $series ) {
		if ( WC_Appointment_Series::STAFF_LOCK_TO_FIRST === $series->get_staff_assignment_mode() && $series->get_locked_staff_id() > 0 ) {
			return array( $series->get_locked_staff_id() );
		}

		return array();
	}
}
