<?php
/**
 * Pay-first balance order hooks and checkout guards.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Balance-order lifecycle hooks; order/series write logic lives on {@see WC_Appointment_Series}.
 */
class WC_Appointment_Series_Payment {

	const ORDER_META_TYPE    = '_wca_series_payment_type';
	const ORDER_TYPE_BALANCE = 'balance';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! class_exists( 'WC_Appointment_Series_Events' ) || ! WC_Appointment_Series_Events::is_enabled() ) {
			return;
		}

		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_order_status_changed' ), 5, 3 );
		add_action( 'admin_action_wca_series_balance', array( __CLASS__, 'handle_admin_order_balance_action' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_admin_order_balance_notice' ) );
	}

	/** @return bool */
	public static function staff_can_manage_balance() {
		return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_appointments' );
	}

	/**
	 * Nonced admin URL for a staff balance action on the order edit screen.
	 *
	 * @param int    $series_id      Series id.
	 * @param int    $order_id       Order being edited.
	 * @param string $balance_action create_order|invoice|paid_offline.
	 * @return string
	 */
	public static function get_admin_balance_action_url( $series_id, $order_id, $balance_action ) {
		$series_id = (int) $series_id;
		return wp_nonce_url(
			add_query_arg(
				array(
					'action'             => 'wca_series_balance',
					'series_id'          => $series_id,
					'order_id'           => (int) $order_id,
					'wca_balance_action'   => sanitize_key( $balance_action ),
				),
				admin_url( 'admin.php' )
			),
			'wca_series_balance_' . $series_id
		);
	}

	/**
	 * Admin action handler for series balance create/invoice/paid_offline.
	 *
	 * @return void
	 */
	public static function handle_admin_order_balance_action() {
		$series_id = isset( $_REQUEST['series_id'] ) ? absint( $_REQUEST['series_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$order_id  = isset( $_REQUEST['order_id'] ) ? absint( $_REQUEST['order_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$action    = isset( $_REQUEST['wca_balance_action'] ) ? sanitize_key( wp_unslash( $_REQUEST['wca_balance_action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		check_admin_referer( 'wca_series_balance_' . $series_id );

		$redirect = WC_Appointment_Series::get_order_edit_url( $order_id );

		if ( ! self::staff_can_manage_balance() ) {
			wp_die( esc_html__( 'You do not have permission to manage series balances.', 'woocommerce-appointments' ) );
		}

		try {
			$series = new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			unset( $e );
			wp_safe_redirect( add_query_arg( 'wca_balance_notice', 'error', $redirect ) );
			exit;
		}

		$result = self::run_balance_action( $series, $action, array() );

		wp_safe_redirect(
			add_query_arg( 'wca_balance_notice', is_wp_error( $result ) ? 'error' : 'success', $redirect )
		);
		exit;
	}

	/**
	 * Flash notice after an admin balance action redirect.
	 *
	 * @return void
	 */
	public static function render_admin_order_balance_notice() {
		$notice_raw = filter_input( INPUT_GET, 'wca_balance_notice' );
		if ( ! is_string( $notice_raw ) ) {
			return;
		}

		$is_error = 'error' === wc_clean( wp_unslash( $notice_raw ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		printf(
			'<div class="notice %1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $is_error ? 'notice-error' : 'notice-success' ),
			esc_html(
				$is_error
					? __( 'The series balance action could not be completed.', 'woocommerce-appointments' )
					: __( 'Series balance updated.', 'woocommerce-appointments' )
			)
		);
	}

	/**
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	public static function is_balance_order( $order ) {
		return $order instanceof WC_Order && self::ORDER_TYPE_BALANCE === (string) $order->get_meta( self::ORDER_META_TYPE, true );
	}

	/**
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	public static function balance_order_is_payable( $order ) {
		if ( ! self::is_balance_order( $order ) ) {
			return $order->needs_payment();
		}
		return (float) $order->get_total() > 0 && $order->has_status( array( 'pending', 'failed' ) );
	}

	/** @return WC_Order|WP_Error */
	public static function ensure_payable_balance_order( WC_Appointment_Series $series ) {
		$series->ensure_pay_first_totals_from_order();
		if ( WC_Appointment_Series::PAYMENT_PAY_FIRST !== $series->get_payment_model() || ! $series->has_open_balance() ) {
			return new WP_Error( 'no_balance', __( 'No balance is due for this series.', 'woocommerce-appointments' ) );
		}
		$order = $series->get_payable_balance_order();
		return $order ? $order : $series->create_balance_order( false );
	}

	/** @return string */
	public static function get_balance_pay_url( WC_Appointment_Series $series ) {
		if ( ! $series->has_open_balance() ) {
			return '';
		}
		$order = $series->get_payable_balance_order();
		return $order ? $order->get_checkout_payment_url() : '';
	}

	/**
	 * @param WC_Appointment_Series $series Series.
	 * @param string                $action create_order|invoice|paid_offline.
	 * @param array<string, mixed>  $args   Optional action args (send_invoice, note).
	 * @return array<string, mixed>|WP_Error
	 */
	public static function run_balance_action( WC_Appointment_Series $series, $action, $args = array() ) {
		$action = sanitize_key( $action );
		$args   = is_array( $args ) ? $args : array();

		if ( 'create_order' === $action ) {
			$result = $series->create_balance_order( ! empty( $args['send_invoice'] ) );
			return is_wp_error( $result )
				? $result
				: array( 'balance_order' => array( 'id' => $result->get_id(), 'url' => $result->get_edit_order_url() ) );
		}

		if ( 'invoice' === $action ) {
			$order = self::ensure_payable_balance_order( $series );
			if ( is_wp_error( $order ) ) {
				return $order;
			}
			if ( ! $series->needs_balance_payment() ) {
				return new WP_Error( 'invoice_not_applicable', __( 'No payment request can be sent for this series.', 'woocommerce-appointments' ) );
			}
			WC_Appointment_Series_Email::send_balance_payment_request( $order );
			return array( 'sent' => true, 'order_id' => $order->get_id() );
		}

		if ( 'paid_offline' === $action ) {
			return self::mark_balance_paid_offline( $series, isset( $args['note'] ) ? (string) $args['note'] : '' )
				? array( 'paid_offline' => true )
				: new WP_Error( 'not_pay_first', __( 'This series does not use pay-first billing.', 'woocommerce-appointments' ) );
		}

		return new WP_Error( 'invalid_action', __( 'Unknown balance action.', 'woocommerce-appointments' ) );
	}

	/**
	 * @param WC_Appointment_Series $series Series.
	 * @param string                $note   Optional order note.
	 * @return bool
	 */
	public static function mark_balance_paid_offline( WC_Appointment_Series $series, $note = '' ) {
		if ( WC_Appointment_Series::PAYMENT_PAY_FIRST !== $series->get_payment_model() ) {
			return false;
		}

		$balance_order    = $series->get_balance_order();
		$balance_order_id = $balance_order ? (int) $balance_order->get_id() : 0;

		$series->settle_balance( $balance_order_id );
		$series->update_due_occurrences( 'mark_paid', $balance_order_id );

		if ( $balance_order && ! $balance_order->has_status( wc_get_is_paid_statuses() ) ) {
			$balance_order->update_status( 'completed', $note ? $note : __( 'Marked as paid offline by admin.', 'woocommerce-appointments' ), false );
		}

		do_action( 'wc_appointment_series_balance_paid_offline', $series->get_id(), $series );
		return true;
	}

	/**
	 * Route balance-order status transitions to paid/cancelled handlers.
	 *
	 * @param int    $order_id Order id.
	 * @param string $from     Previous status.
	 * @param string $to       New status.
	 * @return void
	 */
	public static function on_order_status_changed( $order_id, $from, $to ) {
		unset( $from );
		$order = wc_get_order( $order_id );
		if ( ! $order || ! self::is_balance_order( $order ) ) {
			return;
		}
		if ( in_array( $to, array( 'processing', 'completed', 'partial-payment' ), true ) ) {
			self::on_balance_order_paid( $order_id );
		} elseif ( in_array( $to, array( 'cancelled', 'refunded' ), true ) ) {
			self::on_balance_order_cancelled( $order_id );
		}
	}

	/**
	 * @param int $order_id Balance order id.
	 * @return void
	 */
	public static function on_balance_order_paid( $order_id ) {
		$order  = wc_get_order( $order_id );
		$series = WC_Appointment_Series::from_balance_order( $order );
		if ( ! $series || 'paid' === $series->get_balance_status() ) {
			return;
		}
		$series->settle_balance( $order_id );
		$series->update_due_occurrences( 'mark_paid', $order_id );
		do_action( 'wc_appointment_series_balance_paid', $series->get_id(), $order_id, $series );
	}

	/**
	 * @param int $order_id Balance order id.
	 * @return void
	 */
	public static function on_balance_order_cancelled( $order_id ) {
		$order  = wc_get_order( $order_id );
		$series = WC_Appointment_Series::from_balance_order( $order );
		if ( ! $series || ! $order ) {
			return;
		}
		if ( 'paid' !== $series->get_balance_status() ) {
			$series->set_balance_order_id( 0 );
			$series->save();
			$series->update_due_occurrences( 'unlink', $order_id );
		}
		do_action( 'wc_appointment_series_balance_order_cancelled', $series->get_id(), $order_id, $series );
	}
}
