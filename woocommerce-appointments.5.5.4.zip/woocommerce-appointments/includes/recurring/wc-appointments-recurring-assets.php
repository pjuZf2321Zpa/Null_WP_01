<?php
/**
 * Central recurring / membership asset registration.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Recurring picker strings shared by storefront form and admin panel.
 *
 * @return array<string, string>
 */
function wc_appointments_recurring_shared_i18n() {
	return array(
		'every'                   => __( 'Every', 'woocommerce-appointments' ),
		'for'                     => __( 'For', 'woocommerce-appointments' ),
		'appointments'            => __( 'appointments', 'woocommerce-appointments' ),
		'dayUnit'                 => __( 'day', 'woocommerce-appointments' ),
		'daysUnit'                => __( 'days', 'woocommerce-appointments' ),
		'weekUnit'                => __( 'week', 'woocommerce-appointments' ),
		'weeksUnit'               => __( 'weeks', 'woocommerce-appointments' ),
		'monthUnit'               => __( 'month', 'woocommerce-appointments' ),
		'monthsUnit'              => __( 'months', 'woocommerce-appointments' ),
		'selectSlot'              => __( 'Select a time first.', 'woocommerce-appointments' ),
		'selectDate'              => __( 'Select a date first.', 'woocommerce-appointments' ),
		'previewLoading'          => __( 'Checking availability…', 'woocommerce-appointments' ),
		/* translators: %d: number of unavailable appointments that will be skipped */
		'conflictsSkipped'        => __( '%d unavailable — will be skipped', 'woocommerce-appointments' ),
		'minSessions'             => __( 'Minimum appointments required for this package.', 'woocommerce-appointments' ),
		/* translators: 1: available appointments, 2: minimum required */
		'previewBelowMinimum'     => __( 'Need at least %2$d appointments; only %1$d available. Adjust the schedule or remove appointments.', 'woocommerce-appointments' ),
		/* translators: %d: total number of appointments in the package preview list. */
		'showAllSessions'         => __( 'Show all %d appointments', 'woocommerce-appointments' ),
		'showFewerSessions'       => __( 'Show fewer appointments', 'woocommerce-appointments' ),
		/* translators: %d: number of appointments hidden behind the collapsed preview summary. */
		'previewCollapsedSummary' => __( '… and %d more appointments', 'woocommerce-appointments' ),
		'removeSession'           => __( 'Remove', 'woocommerce-appointments' ),
		'rescheduleSession'       => __( 'Reschedule', 'woocommerce-appointments' ),
		'rescheduleAlternatives'  => __( 'Nearest available slots', 'woocommerce-appointments' ),
		'selectedSlot'            => __( 'Selection', 'woocommerce-appointments' ),
	);
}

/**
 * Register and enqueue recurring storefront assets on appointable product pages.
 *
 * @param WC_Product|null $product Appointable product.
 * @return void
 */
function wc_appointments_enqueue_recurring_form_assets( $product = null ) {
	if ( ! class_exists( 'WC_Appointment_Series_Events' ) || ! WC_Appointment_Series_Events::is_enabled() ) {
		return;
	}

	if ( ! $product instanceof WC_Product ) {
		$product = wc_get_product( get_queried_object_id() );
	}

	$appointment_product = WC_Product_Appointment::as_appointment_product( $product );
	if ( ! $appointment_product || ! $appointment_product->allows_recurring() ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	wp_register_style(
		'wc-appointments-recurring',
		WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/recurring.css',
		array( 'wc-appointments-styles' ),
		WC_APPOINTMENTS_VERSION
	);
	wp_enqueue_style( 'wc-appointments-recurring' );

	wp_register_script(
		'wc-appointments-recurring-form',
		WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/recurring-form' . $suffix . '.js',
		array( 'wc-appointments-appointment-form', 'wca-shared-js' ),
		WC_APPOINTMENTS_VERSION,
		true
	);

	$customer_options = $appointment_product->get_recurring_customer_options();

	wp_localize_script(
		'wc-appointments-recurring-form',
		'wcaRecurring',
		array(
			'previewUrl'          => WC_Ajax_Compat::get_endpoint( 'wc_appointments_series_preview' ),
			'productId'           => (int) $appointment_product->get_id(),
			'timezone'            => wc_timezone_string(),
			'allowedFreqs'        => $customer_options['allowedFreqs'],
			'defaultFreq'         => $customer_options['defaultFreq'],
			'minOccurrences'      => $customer_options['minOccurrences'],
			'maxOccurrences'      => $customer_options['maxOccurrences'],
			'paymentOptions'      => $customer_options['paymentOptions'],
			'defaultPaymentModel' => $customer_options['defaultPaymentModel'],
			'allowPayFirst'       => $customer_options['allowPayFirst'],
			'allowPrepaid'        => $customer_options['allowPrepaid'],
			'userCanCancel'       => $appointment_product->can_be_cancelled(),
			'userCanReschedule'   => $appointment_product->can_be_rescheduled() && wc_appointments_is_timed_slot_product( $appointment_product ),
			'i18n'                => array_merge(
				wc_appointments_recurring_shared_i18n(),
				array(
					/* translators: %s: formatted remaining balance amount. */
					'balanceDue'             => __( '%s remaining balance', 'woocommerce-appointments' ),
					/* translators: %d: number of appointments in the recurring package. */
					'previewPackage'         => __( '%d appointments in this package', 'woocommerce-appointments' ),
					'networkError'           => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
				)
			),
		)
	);

	wp_enqueue_script( 'wc-appointments-recurring-form' );
}
