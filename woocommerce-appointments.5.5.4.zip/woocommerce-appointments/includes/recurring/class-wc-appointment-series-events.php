<?php
/**
 * Recurring series bootstrap, feature flag, hooks, and post meta registration.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Series extension surface (actions/filters + feature flag).
 */
class WC_Appointment_Series_Events {

	const MATERIALIZATION_SWEEP_LIMIT = 200;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		if ( defined( 'WC_APPOINTMENTS_ABSPATH' ) ) {
			require_once WC_APPOINTMENTS_ABSPATH . 'includes/recurring/class-wc-appointment-series-scope.php';
		}
		add_action( 'init', array( __CLASS__, 'register_post_meta' ), 20 );
		WC_Appointment_Series_Scope::init();
		add_action( WC_Appointment_Series_Materializer::AS_HOOK, array( 'WC_Appointment_Series_Materializer', 'on_async_materialize' ), 10, 4 );
		add_action( WC_Appointment_Series_Email::AS_HOOK, array( 'WC_Appointment_Series_Email', 'on_scheduled_notification' ), 10, 3 );
		add_action( 'woocommerce_appointments_daily_cleanup', array( __CLASS__, 'sweep_materialization' ) );
		add_action( 'woocommerce_appointments_daily_cleanup', array( __CLASS__, 'prune_idempotency_records' ) );
		add_action( 'wc_ajax_wc_appointments_series_preview', array( 'WC_Appointment_Series_Preview', 'wc_ajax_preview' ) );

		if ( is_admin() ) {
			add_action( 'woocommerce_appointments_product_recurring_options', array( __CLASS__, 'render_admin_recurring_options' ), 10 );
			add_action( 'woocommerce_admin_process_product_object', array( 'WC_Product_Appointment', 'save_recurring_admin_fields' ), 25 );
			WC_Appointment_Series_Admin::init();
		}
	}

	/**
	 * @param WC_Product $product_object Appointable product.
	 * @return void
	 */
	public static function render_admin_recurring_options( $product_object ) {
		if ( ! $product_object || 'appointment' !== $product_object->get_type() ) {
			return;
		}

		include WC_APPOINTMENTS_ABSPATH . 'includes/admin/views/html-appointment-recurring-product.php';
	}

	/**
	 * Daily sweep: materialize due active series within their horizon.
	 *
	 * @return void
	 */
	public static function sweep_materialization() {
		if ( ! self::is_enabled() ) {
			return;
		}

		$store = WC_Data_Store::load( WC_Appointment_Series::DATA_STORE );
		$ids   = $store->get_due_for_materialization( time(), self::MATERIALIZATION_SWEEP_LIMIT );

		if ( empty( $ids ) ) {
			return;
		}

		$materializer = new WC_Appointment_Series_Materializer();
		$batch        = (int) apply_filters( 'wc_appointments_series_materialize_batch', 50 );

		foreach ( $ids as $series_id ) {
			$materializer->materialize_batch( (int) $series_id, $batch );
		}
	}

	/**
	 * Delete expired REST idempotency rows (24h TTL).
	 *
	 * @return void
	 */
	public static function prune_idempotency_records() {
		if ( ! class_exists( 'WC_Appointment_Series_Idempotency', false ) ) {
			return;
		}

		( new WC_Appointment_Series_Idempotency() )->prune_expired();
	}

	/**
	 * Whether recurring appointments are enabled site-wide.
	 *
	 * Enabled by default; disable with `wc_appointments_recurring_enabled`.
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) apply_filters( 'wc_appointments_recurring_enabled', true );
	}

	/**
	 * Register occurrence post meta keys (§5.3).
	 *
	 * @return void
	 */
	public static function register_post_meta() {
		$meta_args = array(
			'type'              => 'integer',
			'single'            => true,
			'show_in_rest'      => true,
			'auth_callback'     => '__return_true',
			'sanitize_callback' => 'absint',
		);

		register_post_meta( 'wc_appointment', '_wca_series_id', $meta_args );

		register_post_meta(
			'wc_appointment',
			'_wca_recurrence_id',
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'auth_callback'     => '__return_true',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);

		register_post_meta( 'wc_appointment', '_wca_series_occurrence', $meta_args );

		register_post_meta(
			'wc_appointment',
			'_wca_is_series_override',
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'auth_callback'     => '__return_true',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);

		register_post_meta(
			'wc_appointment',
			'_wca_series_idempotency_key',
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'auth_callback'     => '__return_true',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
	}

	/**
	 * Fired after a series row is created.
	 *
	 * @param WC_Appointment_Series $series Series object.
	 * @return void
	 */
	public static function series_created( WC_Appointment_Series $series ) {
		do_action( 'woocommerce_appointments_series_created', $series );
	}

	/**
	 * Fired after a series row is updated.
	 *
	 * @param WC_Appointment_Series $series Series object.
	 * @return void
	 */
	public static function series_updated( WC_Appointment_Series $series ) {
		do_action( 'woocommerce_appointments_series_updated', $series );
	}

	/**
	 * Fired after a series is cancelled.
	 *
	 * @param WC_Appointment_Series $series Series object.
	 * @return void
	 */
	public static function series_cancelled( WC_Appointment_Series $series ) {
		do_action( 'woocommerce_appointments_series_cancelled', $series );
	}

}
