<?php
/**
 * Normalize preview / create request payloads for recurring series.
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Shared request parsing for cart POST and REST JSON.
 */
class WC_Appointment_Series_Request {

	/**
	 * @var array<string, array{args: array<string, mixed>, preview: array<string, mixed>}>
	 */
	private static $recurring_preview_cache = array();

	/**
	 * Whether the current request is a recurring package add-to-cart.
	 *
	 * @return bool
	 */
	public static function is_recurring_request() {
		$enabled_raw = filter_input( INPUT_POST, 'wca_recurring_enabled' );

		return is_string( $enabled_raw ) && '1' === wc_clean( wp_unslash( $enabled_raw ) );
	}

	/**
	 * Unslashed add-to-cart POST (WC product form; sanitized per field downstream).
	 *
	 * @return array<string, mixed>
	 */
	public static function get_add_to_cart_post() {
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field via wc_appointments_get_posted_data().
	}

	/**
	 * Cached preview for recurring add-to-cart POST (one preview per request per arg set).
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @return array{args: array<string, mixed>, preview: array<string, mixed>}|null
	 */
	public static function load_recurring_preview( $product ) {
		if ( ! $product || ! $product->allows_recurring() ) {
			return null;
		}

		$preview_args = self::preview_args_from_post( $product->get_id() );
		$cache_key    = md5( wp_json_encode( $preview_args ) );

		if ( ! isset( self::$recurring_preview_cache[ $cache_key ] ) ) {
			// preview_args_from_post already normalized (store → booking axis once).
			$preview = ( new WC_Appointment_Series_Preview() )->preview( $preview_args, true, true );
			self::$recurring_preview_cache[ $cache_key ] = array(
				'args'    => $preview_args,
				'preview' => $preview,
			);
		}

		return self::$recurring_preview_cache[ $cache_key ];
	}

	/**
	 * Billable sessions for a recurring add-to-cart request (uses shared preview cache).
	 *
	 * @param int $product_id Appointable product id.
	 * @return int
	 */
	public static function billable_count_from_request( $product_id ) {
		if ( ! self::is_recurring_request() ) {
			return 0;
		}

		$product = WC_Product_Appointment::as_appointment_product( $product_id );
		$cached  = self::load_recurring_preview( $product );
		if ( ! $cached || ! empty( $cached['preview']['error'] ) ) {
			return 0;
		}

		$schedule = WC_Appointment_Series_Preview::cart_schedule( $product, $cached['preview'], $cached['args'] );

		return is_wp_error( $schedule ) ? 0 : max( 0, (int) $schedule['billable_count'] );
	}

	/**
	 * Build preview args from add-to-cart POST.
	 *
	 * @param int $product_id Product id.
	 * @return array<string, mixed>
	 */
	public static function preview_args_from_post( $product_id ) {
		$product = wc_get_product( $product_id );
		$posted  = self::get_add_to_cart_post();
		$data    = wc_appointments_get_posted_data( $posted, $product );

		$timezone = ! empty( $data['_local_timezone'] ) ? (string) $data['_local_timezone'] : wc_timezone_string();
		$dtstart  = isset( $data['_start_date'] ) ? (int) $data['_start_date'] : 0;

		$duration = self::duration_seconds_from_product( $product, $data );
		$staff_id = ! empty( $data['_staff_id'] ) ? (int) $data['_staff_id'] : 0;
		$qty      = ! empty( $data['_qty'] ) ? max( 1, (int) $data['_qty'] ) : 1;

		$rrule_raw = filter_input( INPUT_POST, 'wca_rrule' );
		$rrule     = is_string( $rrule_raw )
			? WC_Appointment_Series_RRule::sanitize_ical_block( wp_unslash( $rrule_raw ) )
			: 'RRULE:FREQ=WEEKLY;COUNT=8';
		$rrule = self::normalize_rrule_for_product( $product_id, $rrule );

		$args = self::normalize_preview_args(
			array(
				'product_id'       => (int) $product_id,
				'dtstart_ts'       => $dtstart,
				'timezone'         => $timezone,
				'rrule'            => $rrule,
				'duration_seconds' => $duration,
				'staff_id'         => $staff_id,
				'qty'              => $qty,
				'location_id'      => (int) ( $data['_location_id'] ?? 0 ),
				'max_occurrences'  => self::recurring_max_occurrences( $product_id ),
				'payment_model'    => self::payment_model_from_source( $posted ),
				'posted'           => $posted,
			)
		);

		return self::merge_schedule_adjustments( self::apply_once_per_series_addon_duration( $args ), $posted );
	}

	/**
	 * Build preview args from REST JSON body.
	 *
	 * @param array<string, mixed> $body Request body.
	 * @return array<string, mixed>
	 */
	public static function preview_args_from_rest( $body ) {
		$body     = is_array( $body ) ? $body : array();
		$timezone = isset( $body['timezone'] ) ? (string) $body['timezone'] : 'UTC';
		$dtstart  = isset( $body['dtstart'] ) ? $body['dtstart'] : ( isset( $body['dtstart_ts'] ) ? $body['dtstart_ts'] : 0 );
		$product_id = isset( $body['product_id'] ) ? (int) $body['product_id'] : 0;

		$max = isset( $body['max_occurrences'] ) ? (int) $body['max_occurrences'] : 0;
		if ( $max <= 0 && $product_id > 0 ) {
			$max = self::recurring_max_occurrences( $product_id );
		}

		$rrule = isset( $body['rrule'] ) ? (string) $body['rrule'] : '';
		$rrule = self::normalize_rrule_for_product( $product_id, $rrule );

		$args = array(
			'product_id'       => $product_id,
			'dtstart_ts'       => self::parse_dtstart( $dtstart, $timezone ),
			'timezone'         => $timezone,
			'rrule'            => $rrule,
			'duration_seconds' => isset( $body['duration_seconds'] ) ? (int) $body['duration_seconds'] : 0,
			'staff_id'         => isset( $body['staff_id'] ) ? (int) $body['staff_id'] : 0,
			'qty'              => isset( $body['qty'] ) ? (int) $body['qty'] : 1,
			'location_id'      => isset( $body['location_id'] ) ? (int) $body['location_id'] : 0,
			'max_occurrences'  => $max > 0 ? $max : WC_Appointment_Series_Preview::DEFAULT_MAX_OCCURRENCES,
			'payment_model'    => self::payment_model_from_source( $body ),
		);

		// Civil string dtstart is already booking-zone Fake UTC from parse_dtstart().
		// Numeric dtstart_ts (storefront slot token) still needs store → booking convert.
		if ( ! is_numeric( $dtstart ) ) {
			$args['_dtstart_booking_axis'] = true;
		}

		if ( ! empty( $body['form'] ) && is_string( $body['form'] ) ) {
			$args = self::merge_posted_form_into_preview_args( $args, $body['form'] );
		}

		$args = self::normalize_preview_args( $args );

		if ( ! empty( $body['pricing_only'] ) ) {
			$args['pricing_only'] = true;
		}

		if ( isset( $body['conflicts'] ) && is_array( $body['conflicts'] ) ) {
			$args['conflicts'] = $body['conflicts'];
		}

		return self::merge_schedule_adjustments( $args, $body );
	}

	/**
	 * Build series create args from REST JSON (extends preview args with staff + order fields).
	 *
	 * @param array<string, mixed> $body Request body.
	 * @return array<string, mixed>
	 */
	public static function create_args_from_rest( $body ) {
		$body   = is_array( $body ) ? $body : array();
		$args   = self::preview_args_from_rest( $body );
		$product_id = (int) $args['product_id'];

		if ( isset( $body['staff_assignment_mode'] ) ) {
			$staff_args = WC_Product_Appointment::get_recurring_series_staff_from_line(
				array(
					'staff_assignment_mode' => (string) $body['staff_assignment_mode'],
					'locked_staff_id'       => isset( $body['locked_staff_id'] ) ? (int) $body['locked_staff_id'] : 0,
				)
			);
		} elseif ( $product_id > 0 && ! empty( $args['staff_id'] ) ) {
			$product = WC_Product_Appointment::as_appointment_product( $product_id );
			$staff_args = $product
				? $product->get_recurring_series_staff_from_booking( array( '_staff_id' => (int) $args['staff_id'] ) )
				: array(
					'staff_assignment_mode' => 'auto_per_occurrence',
					'locked_staff_id'       => 0,
				);
		} else {
			$product    = WC_Product_Appointment::as_appointment_product( $product_id );
			$staff_args = $product
				? $product->get_recurring_series_staff_from_booking( array() )
				: array(
					'staff_assignment_mode' => 'auto_per_occurrence',
					'locked_staff_id'       => 0,
				);
		}

		return array(
			'product_id'            => $product_id,
			'customer_id'           => isset( $body['customer_id'] ) ? (int) $body['customer_id'] : 0,
			'rrule'                 => (string) $args['rrule'],
			'dtstart_ts'            => (int) $args['dtstart_ts'],
			'timezone'              => (string) $args['timezone'],
			'duration_seconds'      => (int) $args['duration_seconds'],
			'once_per_series_addon_duration_seconds' => (int) ( $args['once_per_series_addon_duration_seconds'] ?? 0 ),
			'staff_assignment_mode' => $staff_args['staff_assignment_mode'],
			'locked_staff_id'       => $staff_args['locked_staff_id'],
			'location_id'           => (int) ( $args['location_id'] ?? 0 ),
			'order_id'              => isset( $body['order_id'] ) ? (int) $body['order_id'] : 0,
			'payment_model'         => WC_Appointment_Series::PAYMENT_PREPAID,
			'qty'                   => (int) $args['qty'],
		);
	}

	/**
	 * Attach exdates / per-occurrence overrides from POST or REST JSON.
	 *
	 * @param array<string, mixed> $args   Preview args.
	 * @param array<string, mixed> $source Request payload.
	 * @return array<string, mixed>
	 */
	public static function merge_schedule_adjustments( $args, $source ) {
		$source = is_array( $source ) ? $source : array();

		if ( ! empty( $source['wca_recurring_schedule'] ) ) {
			$schedule = json_decode( wp_unslash( (string) $source['wca_recurring_schedule'] ), true );
			if ( is_array( $schedule ) ) {
				$source = array_merge( $source, $schedule );
			}
		}

		$exdates = array();
		foreach ( (array) ( $source['exdates'] ?? array() ) as $id ) {
			$id = WC_Appointment_Series_RRule::sanitize_recurrence_id( (string) $id );
			if ( '' !== $id ) {
				$exdates[] = $id;
			}
		}
		if ( $exdates ) {
			$args['exdates'] = array_values( array_unique( $exdates ) );
		}

		$overrides = array();
		foreach ( (array) ( $source['overrides'] ?? array() ) as $old_id => $new_start ) {
			$old_id = WC_Appointment_Series_RRule::sanitize_recurrence_id( (string) $old_id );
			if ( '' !== $old_id ) {
				$overrides[ $old_id ] = (int) $new_start;
			}
		}
		if ( $overrides ) {
			$args['overrides'] = $overrides;
		}

		return $args;
	}

	/**
	 * Parse serialized appointment-form fields into preview args (staff, qty, posted).
	 *
	 * @param array<string, mixed> $args Preview args.
	 * @param string               $form URL-encoded form string from the storefront.
	 * @return array<string, mixed>
	 */
	public static function merge_posted_form_into_preview_args( $args, $form ) {
		$posted = array();
		parse_str( $form, $posted );
		if ( empty( $posted ) ) {
			return $args;
		}

		$args['posted'] = $posted;

		$product_id = isset( $args['product_id'] ) ? (int) $args['product_id'] : 0;
		$product    = $product_id > 0 ? wc_get_product( $product_id ) : null;
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			return $args;
		}

		$data = wc_appointments_get_posted_data( $posted, $product );
		if ( empty( $args['dtstart_ts'] ) && ! empty( $data['_start_date'] ) ) {
			$args['dtstart_ts'] = (int) $data['_start_date'];
			// Form _start_date is store Fake UTC; allow normalize to convert once.
			unset( $args['_dtstart_booking_axis'] );
		}
		if ( ! empty( $data['_staff_id'] ) ) {
			$args['staff_id'] = (int) $data['_staff_id'];
		}
		if ( ! empty( $data['_qty'] ) ) {
			$args['qty'] = max( 1, (int) $data['_qty'] );
		}
		if ( ! empty( $data['_location_id'] ) ) {
			$args['location_id'] = (int) $data['_location_id'];
		}
		if ( empty( $args['duration_seconds'] ) ) {
			$args['duration_seconds'] = self::duration_seconds_from_product( $product, $data );
		}

		if ( ! empty( $data['_local_timezone'] ) ) {
			$args['timezone'] = (string) $data['_local_timezone'];
		} elseif ( ! empty( $posted['wc_appointments_field_timezone'] ) ) {
			$tz = sanitize_text_field( (string) $posted['wc_appointments_field_timezone'] );
			if ( $tz && $tz !== wc_timezone_string() && class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::is_valid_timezone( $tz ) ) {
				$args['timezone'] = $tz;
			}
		}

		return self::apply_once_per_series_addon_duration( $args );
	}

	/**
	 * Base occurrence duration for series storage; once-per-series addon duration applies on the first session only.
	 *
	 * @param array<string, mixed> $args Preview args.
	 * @return array<string, mixed>
	 */
	private static function apply_once_per_series_addon_duration( $args ) {
		$product_id = (int) ( $args['product_id'] ?? 0 );
		$posted     = isset( $args['posted'] ) && is_array( $args['posted'] ) ? $args['posted'] : array();
		if ( $product_id <= 0 || empty( $posted ) || empty( $args['duration_seconds'] ) ) {
			return $args;
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			return $args;
		}

		$once = WC_Appointment_Series_Preview::once_per_series_addon_totals( $product, $posted );
		if ( $once['duration'] <= 0 ) {
			return $args;
		}

		$extra = (int) round( $once['duration'] * MINUTE_IN_SECONDS );
		if ( $extra > 0 ) {
			$args['duration_seconds']                         = max( 1, (int) $args['duration_seconds'] - $extra );
			$args['once_per_series_addon_duration_seconds'] = $extra;
		}

		return $args;
	}

	/**
	 * Parse dtstart to Fake UTC epoch.
	 *
	 * @param mixed  $value    dtstart (int|string).
	 * @param string $timezone IANA timezone.
	 * @return int
	 */
	public static function parse_dtstart( $value, $timezone ) {
		if ( is_numeric( $value ) ) {
			return (int) $value;
		}

		$tz = new DateTimeZone( $timezone ? $timezone : 'UTC' );
		try {
			$dt = new DateTimeImmutable( (string) $value, $tz );
		} catch ( Exception $e ) {
			return 0;
		}

		$civil = $dt->format( 'Y-m-d H:i:s' );
		return (int) ( new DateTimeImmutable( $civil, new DateTimeZone( 'UTC' ) ) )->getTimestamp();
	}

	/**
	 * @param array<string, mixed> $args Preview args.
	 * @return array<string, mixed>
	 */
	public static function normalize_preview_args( $args ) {
		$args['product_id']       = isset( $args['product_id'] ) ? (int) $args['product_id'] : 0;
		$args['dtstart_ts']       = isset( $args['dtstart_ts'] ) ? (int) $args['dtstart_ts'] : 0;
		$args['timezone']         = isset( $args['timezone'] ) ? (string) $args['timezone'] : wc_timezone_string();
		$args['rrule']            = isset( $args['rrule'] ) ? (string) $args['rrule'] : '';
		$args['duration_seconds'] = isset( $args['duration_seconds'] ) ? max( 0, (int) $args['duration_seconds'] ) : 0;
		$args['staff_id']         = isset( $args['staff_id'] ) ? (int) $args['staff_id'] : 0;
		$args['qty']              = isset( $args['qty'] ) ? max( 1, (int) $args['qty'] ) : 1;
		$args['location_id']      = isset( $args['location_id'] ) ? (int) $args['location_id'] : 0;
		$args['max_occurrences']  = isset( $args['max_occurrences'] ) ? max( 1, (int) $args['max_occurrences'] ) : WC_Appointment_Series_Preview::DEFAULT_MAX_OCCURRENCES;
		$args['payment_model']    = isset( $args['payment_model'] ) ? sanitize_key( (string) $args['payment_model'] ) : '';

		// Store Fake UTC → booking axis once. Idempotent: REST string dtstarts and repeat
		// normalize (preview_args_* then preview()) must not shift the anchor again.
		if ( empty( $args['_dtstart_booking_axis'] ) ) {
			$booking_tz = wc_appointments_series_booking_timezone( (int) $args['product_id'], (string) $args['timezone'] );
			if ( ! empty( $args['dtstart_ts'] ) && $booking_tz ) {
				$args['dtstart_ts'] = WC_Appointment_Series_RRule::convert_fake_utc_axis(
					(int) $args['dtstart_ts'],
					wp_timezone(),
					$booking_tz
				);
			}
			$args['_dtstart_booking_axis'] = true;
		}

		return $args;
	}

	/**
	 * Sanitize payment model from POST/REST; product rules applied in preview/cart.
	 *
	 * @param array<string, mixed> $source Request payload.
	 * @return string
	 */
	public static function payment_model_from_source( $source ) {
		$raw = isset( $source['payment_model'] ) ? sanitize_key( (string) $source['payment_model'] ) : '';
		if ( '' === $raw && isset( $source['wca_payment_model'] ) ) {
			$raw = sanitize_key( (string) $source['wca_payment_model'] );
		}
		$valid = WC_Product_Appointment::get_valid_recurring_payment_models();
		return in_array( $raw, $valid, true ) ? $raw : '';
	}

	/**
	 * Apply product-level RRULE restrictions.
	 *
	 * @param int    $product_id Product id.
	 * @param string $rrule      RRULE line.
	 * @return string
	 */
	private static function normalize_rrule_for_product( $product_id, $rrule ) {
		if ( $product_id <= 0 || '' === $rrule ) {
			return $rrule;
		}

		$product = WC_Product_Appointment::as_appointment_product( $product_id );
		if ( ! $product ) {
			return '';
		}

		$checked = $product->enforce_recurring_rrule( $rrule );
		return is_wp_error( $checked ) ? '' : $checked;
	}

	/**
	 * @param int $product_id Product id.
	 * @return int
	 */
	private static function recurring_max_occurrences( $product_id ) {
		$product = WC_Product_Appointment::as_appointment_product( $product_id );
		return $product ? $product->get_recurring_max_occurrences() : WC_Product_Appointment::RECURRING_DEFAULT_MAX_OCCURRENCES;
	}

	/**
	 * @param WC_Product|null      $product Appointable product.
	 * @param array<string, mixed> $data    Posted appointment data.
	 * @return int
	 */
	private static function duration_seconds_from_product( $product, $data ) {
		$data = is_array( $data ) ? $data : array();
		if ( ! empty( $data['_duration'] ) ) {
			return max( 1, (int) $data['_duration'] * MINUTE_IN_SECONDS );
		}
		if ( $product && is_wc_appointment_product( $product ) ) {
			$minutes = (int) $product->get_duration_in_minutes();
			if ( $minutes > 0 ) {
				return $minutes * MINUTE_IN_SECONDS;
			}
		}
		return 0;
	}
}
