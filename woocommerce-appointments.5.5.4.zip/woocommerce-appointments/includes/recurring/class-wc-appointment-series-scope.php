<?php
/**
 * Scoped status and schedule changes for recurring series (admin panel, REST, My Account).
 *
 * @package WooCommerce\Appointments\Recurring
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Google Calendar-style scope: one | future | all.
 *
 * Entry point for batch status and uniform-delta reschedule operations on series occurrences.
 */
final class WC_Appointment_Series_Scope {

	const ONE    = 'one';
	const FUTURE = 'future';
	const ALL    = 'all';

	/**
	 * When true, suppresses order-status sync during scoped single-occurrence saves.
	 *
	 * @var bool
	 */
	private static $suppress_order_sync = false;

	/**
	 * Register order-sync guard for single-occurrence admin saves.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'woocommerce_appointments_stop_order_update', array( __CLASS__, 'filter_stop_order_sync' ), 10, 4 );
	}

	/**
	 * @param bool     $stop           Current filter value.
	 * @param WC_Order $order          Order.
	 * @param int      $appointment_id Appointment id.
	 * @param string   $status         Target order status.
	 * @return bool
	 */
	public static function filter_stop_order_sync( $stop, $order, $appointment_id, $status ) {
		unset( $order, $appointment_id, $status );
		return self::$suppress_order_sync ? true : (bool) $stop;
	}

	/**
	 * Run a callback while suppressing per-occurrence order sync.
	 *
	 * @param callable $callback Callback.
	 * @return mixed
	 */
	public static function without_order_sync( $callback ) {
		$previous                  = self::$suppress_order_sync;
		self::$suppress_order_sync = true;
		try {
			return call_user_func( $callback );
		} finally {
			self::$suppress_order_sync = $previous;
		}
	}

	/**
	 * @param string $scope Raw scope from client.
	 * @return string one|future|all
	 */
	public static function normalize( $scope ) {
		$scope = sanitize_key( (string) $scope );
		return in_array( $scope, array( self::FUTURE, self::ALL ), true ) ? $scope : self::ONE;
	}

	/**
	 * Load series + manager for a series occurrence.
	 *
	 * @param WC_Appointment $appt Occurrence.
	 * @return array{0:WC_Appointment_Series,1:WC_Appointment_Series_Manager}|WP_Error|null null when not a series occurrence.
	 */
	private static function resolve( WC_Appointment $appt ) {
		$sid = (int) $appt->get_meta( '_wca_series_id' );
		if ( $sid <= 0 ) {
			return null;
		}
		try {
			return array( new WC_Appointment_Series( $sid ), new WC_Appointment_Series_Manager() );
		} catch ( Exception $e ) {
			return new WP_Error( 'invalid_series', __( 'Series not found.', 'woocommerce-appointments' ), array( 'status' => 404 ) );
		}
	}

	/**
	 * Apply a status change to one, future, or all occurrences in scope.
	 *
	 * @param WC_Appointment $appointment Target occurrence (anchor for future/all).
	 * @param string         $new_status  New appointment status slug.
	 * @param string         $scope       one|future|all.
	 * @return string|WP_Error 'full' = scope layer handled the save; 'one' = caller should save the single occurrence.
	 */
	public static function apply_status( WC_Appointment $appointment, $new_status, $scope ) {
		$scope      = self::normalize( $scope );
		$new_status = sanitize_text_field( $new_status );

		$valid = function_exists( 'get_wc_appointment_statuses' ) ? get_wc_appointment_statuses( 'validate' ) : array();
		if ( $valid && ! in_array( $new_status, $valid, true ) ) {
			return new WP_Error( 'woocommerce_appointments_invalid_status', __( 'Invalid appointment status.', 'woocommerce-appointments' ), array( 'status' => 400 ) );
		}

		$r = self::resolve( $appointment );
		if ( ! $r || is_wp_error( $r ) ) {
			return $r ?: self::ONE;
		}
		// Non-cancel ONE scope: parent REST/update_item saves the single occurrence.
		if ( self::ONE === $scope && 'cancelled' !== $new_status ) {
			return self::ONE;
		}

		list( $series, $manager ) = $r;
		$sid = (int) $series->get_id();
		$ver = (int) $series->get_version();
		$aid = (int) $appointment->get_id();

		if ( self::ONE === $scope ) {
			$result = self::without_order_sync( function () use ( $manager, $sid, $ver, $appointment ) { return $manager->cancel_one( $sid, $ver, $appointment ); } );
			return is_wp_error( $result ) ? $result : 'full';
		}

		$batch = self::ALL === $scope ? 'all' : 'future';
		if ( 'cancelled' === $new_status ) {
			$result = self::without_order_sync( function () use ( $manager, $sid, $ver, $batch, $aid ) { return $manager->cancel( $sid, $ver, $batch, '', $aid ); } );
		} else {
			$result = $manager->update_status_scope( $sid, $aid, $new_status, $scope );
		}
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( is_array( $result ) && empty( $result ) ) {
			return new WP_Error( 'woocommerce_appointments_no_scope_matches', __( 'No appointments matched the selected scope.', 'woocommerce-appointments' ), array( 'status' => 400 ) );
		}

		$email_args = array( 'scope' => $batch, 'anchor_id' => $aid );
		if ( 'cancelled' === $new_status ) {
			$email_args['appointment_ids'] = WC_Appointment_Series_Email::appointment_ids_in_scope_with_status( $sid, $aid, $batch, 'cancelled' );
			WC_Appointment_Series_Email::send( $sid, WC_Appointment_Series_Email::KIND_CANCELLED, $email_args );
		} else {
			$email_args['new_status']      = $new_status;
			$email_args['appointment_ids'] = is_array( $result ) ? $result : array();
			WC_Appointment_Series_Email::send( $sid, WC_Appointment_Series_Email::KIND_STATUS_CHANGED, $email_args );
		}

		return 'full';
	}

	/**
	 * Reschedule series occurrences by uniform delta (anchor shift applied to each target).
	 *
	 * ONE scope delegates to manager::reschedule_one (EXDATE + RDATE + version bump).
	 * FUTURE/ALL: preflight availability for every target, then loop reschedule_occurrence with one version bump (all-or-nothing).
	 *
	 * @param WC_Appointment $appointment Anchor occurrence.
	 * @param int            $new_start   New start (Fake UTC epoch).
	 * @param int            $new_end     New end (Fake UTC epoch).
	 * @param string         $scope       one|future|all.
	 * @return string|WP_Error 'full' = scope layer handled the save; 'one' = caller should save the single occurrence.
	 */
	public static function apply_reschedule( WC_Appointment $appointment, $new_start, $new_end, $scope ) {
		$scope = self::normalize( $scope );
		$r     = self::resolve( $appointment );
		if ( ! $r || is_wp_error( $r ) ) {
			return $r ?: self::ONE;
		}
		list( $series, $manager ) = $r;
		$rid = (string) $appointment->get_meta( '_wca_recurrence_id' );
		if ( self::ONE === $scope ) {
			if ( '' === $rid ) {
				return self::ONE;
			}
			$res = $manager->reschedule_one( (int) $series->get_id(), (int) $series->get_version(), $rid, (int) $new_start, (int) $new_end, '', (int) $appointment->get_id() );
			return is_wp_error( $res ) ? $res : 'full';
		}

		$delta = (int) $new_start - (int) $appointment->get_start();
		$dur   = (int) $appointment->get_end() - (int) $appointment->get_start();
		$ctx   = $manager->get_scope_context( (int) $series->get_id(), (int) $appointment->get_id() );
		if ( is_wp_error( $ctx ) ) {
			return $ctx;
		}
		$ok      = array( 'confirmed', 'paid', 'pending-confirmation', 'unpaid' );
		$cutoff  = (int) ( isset( $ctx['cutoff'] ) ? $ctx['cutoff'] : 0 );
		$all     = self::ALL === $scope;
		$targets = array_filter( isset( $ctx['rows'] ) ? $ctx['rows'] : array(), function ( $row ) use ( $all, $cutoff, $ok ) {
			return ( $all || (int) $row['start_ts'] >= $cutoff ) && in_array( (string) $row['status'], $ok, true );
		} );
		if ( ! $targets ) {
			return new WP_Error( 'woocommerce_appointments_no_scope_matches', __( 'No appointments matched the selected scope.', 'woocommerce-appointments' ), array( 'status' => 400 ) );
		}
		$excl    = array_map( function ( $row ) { return (int) $row['appointment_id']; }, $targets );
		$product = wc_get_product( $series->get_product_id() );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			return new WP_Error( 'invalid_product', __( 'Invalid appointable product.', 'woocommerce-appointments' ) );
		}
		foreach ( $targets as $row ) {
			$avail = $manager->check_reschedule_slot( $product, (int) $row['start_ts'] + $delta, (int) $row['start_ts'] + $delta + $dur, $excl, $series, (int) $row['appointment_id'] );
			if ( is_wp_error( $avail ) ) {
				return $avail;
			}
		}
		$ver = (int) $series->get_version();
		return self::without_order_sync( function () use ( $manager, $series, $targets, $delta, $dur, $ver ) {
			return WC_Appointment_Series_Email::without_occurrence_emails( function () use ( $manager, $series, $targets, $delta, $dur, $ver ) {
				foreach ( $targets as $row ) {
					$manager->reschedule_occurrence( $series, (int) $row['appointment_id'], (int) $row['start_ts'] + $delta, (int) $row['start_ts'] + $delta + $dur );
				}
				try {
					$series->get_data_store()->update_if_version( $series, $ver );
				} catch ( WC_Appointment_Series_Version_Conflict $e ) {
					return new WP_Error( 'version_conflict', $e->getMessage(), array( 'status' => 412 ) );
				}
				return 'full';
			} );
		} );
	}
}
