<?php
/**
 * Recurring prepaid package cart integration.
 *
 * @package WooCommerce\Appointments
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cart hooks for recurring series (prepaid packages).
 */
trait WC_Appointment_Cart_Recurring_Trait {

	/**
	 * Whether recurring cart hooks were registered this request.
	 *
	 * @var bool
	 */
	private static $recurring_cart_hooks_registered = false;

	/**
	 * Register recurring cart hooks when feature is enabled.
	 *
	 * @return void
	 */
	public function register_recurring_cart_hooks() {
		if ( self::$recurring_cart_hooks_registered ) {
			return;
		}

		if ( ! class_exists( 'WC_Appointment_Series_Events' ) || ! WC_Appointment_Series_Events::is_enabled() ) {
			return;
		}

		self::$recurring_cart_hooks_registered = true;

		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'validate_recurring_add_to_cart' ), 5, 3 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'append_recurring_cart_item_data' ), 15, 2 );
		add_filter( 'woocommerce_cart_item_quantity', array( $this, 'lock_recurring_cart_quantity' ), 15, 3 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'persist_recurring_order_line_meta' ), 10, 4 );
		// Cheque/BACS land on on-hold; processing/completed cover COD and paid gateways.
		add_action( 'woocommerce_order_status_on-hold', array( $this, 'create_series_from_order' ), 0, 1 );
		add_action( 'woocommerce_order_status_processing', array( $this, 'create_series_from_order' ), 0, 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'create_series_from_order' ), 0, 1 );
		add_action( 'woocommerce_order_status_partial-payment', array( $this, 'create_series_from_order' ), 0, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'cancel_series_from_order' ), 10, 1 );
		add_action( 'woocommerce_order_status_refunded', array( $this, 'cancel_series_from_order' ), 10, 1 );
		add_action( 'woocommerce_before_appointment_hook_after', array( $this, 'render_recurring_picker' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_recurring_form_assets' ), 100 );
	}

	/**
	 * Storefront product page assets for recurring picker.
	 *
	 * @return void
	 */
	public function enqueue_recurring_form_assets() {
		if ( ! is_product() ) {
			return;
		}

		global $product;
		wc_appointments_enqueue_recurring_form_assets( $product instanceof WC_Product ? $product : null );
	}

	/**
	 * Payment model posted with the recurring form (sanitized, never trusted for price—server recalculates).
	 *
	 * @return string 'prepaid'|'pay_first'
	 */
	public static function get_posted_payment_model() {
		$raw = WC_Appointment_Series_Request::payment_model_from_source( WC_Appointment_Series_Request::get_add_to_cart_post() );
		return '' !== $raw ? $raw : WC_Appointment_Series::PAYMENT_PREPAID;
	}

	/**
	 * @param array<string, mixed> $cart_item_meta Cart meta.
	 * @param int                  $product_id     Product id.
	 * @return array<string, mixed>
	 */
	public function filter_recurring_cart_item_data( $cart_item_meta, $product_id ) {
		$product = WC_Product_Appointment::as_appointment_product( $product_id );
		if ( ! WC_Appointment_Series_Request::is_recurring_request() || ! $product || ! $product->allows_recurring() ) {
			return $cart_item_meta;
		}

		if ( self::is_cart_simulation_request() ) {
			return $cart_item_meta;
		}

		return array_merge( $cart_item_meta, $this->build_recurring_cart_line( $product ) );
	}

	/**
	 * @param bool $passed     Validation result.
	 * @param int  $product_id Product id.
	 * @param int  $quantity   Quantity.
	 * @return bool
	 */
	public function validate_recurring_add_to_cart( $passed, $product_id, $quantity ) {
		unset( $quantity );
		if ( ! $passed || ! WC_Appointment_Series_Request::is_recurring_request() ) {
			return $passed;
		}
		$product = WC_Product_Appointment::as_appointment_product( $product_id );
		if ( ! $product || ! $product->allows_recurring() ) {
			wc_add_notice( __( 'Recurring packages are not enabled for this product.', 'woocommerce-appointments' ), 'error' );
			return false;
		}

		$requested_model = self::get_posted_payment_model();
		if ( WC_Appointment_Series::PAYMENT_PAY_FIRST === $requested_model && ! $product->allows_pay_first_recurring() ) {
			wc_add_notice( __( 'The selected payment option is not available for this product.', 'woocommerce-appointments' ), 'error' );
			return false;
		}

		$posted   = WC_Appointment_Series_Request::get_add_to_cart_post();
		$data     = wc_appointments_get_posted_data( $posted, $product );
		$validate = $product->is_appointable( $data );
		if ( is_wp_error( $validate ) ) {
			wc_add_notice( $validate->get_error_message(), 'error' );
			return false;
		}

		try {
			$cached  = $this->get_cached_recurring_preview( $product );
			$preview = $cached['preview'];
		} catch ( Exception $e ) {
			wc_add_notice( $e->getMessage(), 'error' );
			return false;
		}

		if ( ! empty( $preview['error'] ) ) {
			wc_add_notice( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ), 'error' );
			return false;
		}

		$schedule = WC_Appointment_Series_Preview::cart_schedule( $product, $preview, $cached['args'] );
		if ( is_wp_error( $schedule ) ) {
			wc_add_notice( $schedule->get_error_message(), 'error' );
			return false;
		}

		if ( $schedule['partial'] && $schedule['conflict_count'] > 0 ) {
			wc_add_notice(
				sprintf(
					/* translators: 1: skipped appointments, 2: billable appointments */
					_n(
						'%1$d unavailable appointment will be skipped; %2$d will be charged.',
						'%1$d unavailable appointments will be skipped; %2$d will be charged.',
						$schedule['conflict_count'],
						'woocommerce-appointments'
					),
					$schedule['conflict_count'],
					$schedule['billable_count']
				),
				'notice'
			);
		}
		return $passed;
	}

	/**
	 * @param WC_Product_Appointment $product Appointable product.
	 * @return array<string, mixed>
	 */
	protected function build_recurring_cart_line( WC_Product_Appointment $product ) {
		$posted       = WC_Appointment_Series_Request::get_add_to_cart_post();
		$appointment  = wc_appointments_get_posted_data( $posted, $product );
		$cached       = $this->get_cached_recurring_preview( $product );
		$preview_args = $cached['args'];
		$preview      = $cached['preview'];

		$schedule = WC_Appointment_Series_Preview::cart_schedule( $product, $preview, $preview_args );
		if ( is_wp_error( $schedule ) ) {
			throw new Exception( esc_html( $schedule->get_error_message() ) );
		}

		$rrule          = $schedule['rrule'];
		$session_starts = $schedule['session_starts'];
		$billable_count = $schedule['billable_count'];
		$series_total = isset( $preview['summary']['total_price'] ) ? (float) $preview['summary']['total_price'] : 0.0;

		$payment_model = $product->resolve_recurring_payment_model( self::get_posted_payment_model() );

		$due_today = $series_total;
		if ( WC_Appointment_Series::PAYMENT_PAY_FIRST === $payment_model ) {
			$summary       = isset( $preview['summary'] ) && is_array( $preview['summary'] ) ? $preview['summary'] : array();
			$due_today_raw = (float) ( $summary['due_today'] ?? 0 );
			$due_today     = $due_today_raw > 0 ? $due_today_raw : $series_total;
		}

		$due_today = (float) apply_filters(
			'wc_appointments_recurring_pay_first_checkout_total',
			$due_today,
			$product,
			array(
				'rrule'         => $rrule,
				'payment_model' => $payment_model,
				'series_total'  => $series_total,
			)
		);

		$checkout_total = (float) apply_filters(
			'wc_appointments_recurring_cart_line_total',
			$due_today,
			$product,
			array(
				'rrule'         => $rrule,
				'payment_model' => $payment_model,
				'series_total'  => $series_total,
			)
		);

		$idempotency_raw = filter_input( INPUT_POST, 'wca_idempotency_key' );
		$idempotency     = is_string( $idempotency_raw ) ? sanitize_text_field( wp_unslash( $idempotency_raw ) ) : '';
		if ( '' === $idempotency && function_exists( 'wp_generate_uuid4' ) ) {
			$idempotency = wp_generate_uuid4();
		}

		$staff_args = $product->get_recurring_series_staff_from_booking( $appointment );

		$appointment['_qty']  = max( 1, (int) ( $appointment['_qty'] ?? 1 ) );
		$appointment['_cost'] = $checkout_total;

		$line = array(
			'appointment'   => $appointment,
			'wca_recurring' => array(
				'rrule'                 => $rrule,
				'billable_count'        => (int) $billable_count,
				'payment_model'         => $payment_model,
				'series_total'          => $series_total,
				'checkout_total'        => $checkout_total,
				'idempotency_key'       => $idempotency,
				'preview_summary'       => $preview['summary'],
				'session_starts'        => $session_starts,
				'dtstart_ts'            => (int) $preview_args['dtstart_ts'],
				'timezone'              => (string) $preview_args['timezone'],
				'duration_seconds'      => (int) $preview_args['duration_seconds'],
				'once_per_series_addon_duration_seconds' => (int) ( $preview_args['once_per_series_addon_duration_seconds'] ?? 0 ),
				'staff_id'              => (int) $preview_args['staff_id'],
				'staff_assignment_mode' => $staff_args['staff_assignment_mode'],
				'locked_staff_id'       => $staff_args['locked_staff_id'],
				'location_id'           => (int) ( $appointment['_location_id'] ?? 0 ),
				'location'              => isset( $appointment['_location'] ) && is_array( $appointment['_location'] ) ? $appointment['_location'] : array(),
				'qty'                   => (int) $appointment['_qty'],
			),
		);
		return $line;
	}

	/**
	 * @param WC_Product_Appointment $product Product.
	 * @return array{args: array<string, mixed>, preview: array<string, mixed>}
	 */
	protected function get_cached_recurring_preview( WC_Product_Appointment $product ) {
		$cached = WC_Appointment_Series_Request::load_recurring_preview( $product );
		if ( ! $cached ) {
			throw new Exception( esc_html__( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
		}

		return $cached;
	}

	/**
	 * @param array<int, array<string, mixed>> $item_data Item data rows.
	 * @param array<string, mixed>           $cart_item Cart item.
	 * @return array<int, array<string, mixed>>
	 */
	public function append_recurring_cart_item_data( $item_data, $cart_item ) {
		$r = isset( $cart_item['wca_recurring'] ) && is_array( $cart_item['wca_recurring'] ) ? $cart_item['wca_recurring'] : null;
		if ( ! $r ) {
			return $item_data;
		}

		$payment_model = (string) ( $r['payment_model'] ?? WC_Appointment_Series::PAYMENT_PREPAID );
		if ( WC_Appointment_Series::PAYMENT_PAY_FIRST === $payment_model ) {
			$product        = $cart_item['data'] ?? null;
			$series_total   = (float) ( $r['series_total'] ?? 0 );
			$checkout_total = (float) ( $r['checkout_total'] ?? 0 );
			$balance        = WC_Appointment_Series::calculate_balance_due_display( $product, $series_total, $checkout_total );

			$pay_first_copy = WC_Product_Appointment::get_recurring_payment_storefront_copy();
			$item_data[]    = array(
				'name'    => __( 'Payment option', 'woocommerce-appointments' ),
				'value'   => $pay_first_copy[ WC_Appointment_Series::PAYMENT_PAY_FIRST ]['label'] ?? __( 'Pay for first appointment only', 'woocommerce-appointments' ),
				'display' => '',
			);

			if ( $balance > 0 ) {
				$item_data[] = array(
					'name'    => __( 'Remaining balance', 'woocommerce-appointments' ),
					'value'   => wp_strip_all_tags( wc_price( $balance ) ),
					'display' => '',
				);
			}
		}

		$starts   = array_map( 'intval', (array) ( $r['session_starts'] ?? array() ) );
		$lines    = array();
		$summary  = (array) ( $r['preview_summary'] ?? array() );
		$rrule    = (string) ( $summary['effective_rrule'] ?? $r['rrule'] ?? '' );
		$billable = (int) ( $summary['billable_count'] ?? 0 );
		if ( $billable <= 0 && ! empty( $starts ) ) {
			$billable = count( $starts );
		}

		if ( $rrule && class_exists( 'WC_Appointment_Series_RRule' ) ) {
			$pattern = WC_Appointment_Series_RRule::humanize(
				$rrule,
				(int) ( $r['dtstart_ts'] ?? 0 ),
				(string) ( $r['timezone'] ?? 'UTC' ),
				array( 'include_start' => false )
			);
			if ( $pattern ) {
				$pattern = ucfirst( str_ireplace( ' times', ' appointments', $pattern ) );
				if ( $billable > 0 ) {
					/* translators: %d: number of billable appointments */
					$count_label = sprintf( _n( '%d appointment', '%d appointments', $billable, 'woocommerce-appointments' ), $billable );
					$pattern     = preg_match( '/\d+\s+appointments/iu', $pattern )
						? preg_replace( '/\d+\s+appointments/iu', $count_label, $pattern, 1 )
						: rtrim( $pattern, '.,' ) . ', ' . $count_label;
				}
				$lines[] = esc_html( $pattern );
			}
		}

		$product       = $cart_item['data'] ?? null;
		$appt          = ( $product instanceof WC_Product && is_wc_appointment_product( $product ) )
			? WC_Product_Appointment::as_appointment_product( $product )
			: null;
		$customer_tz   = (string) ( $cart_item['appointment']['_local_timezone'] ?? $r['timezone'] ?? '' );
		$display_lines = $lines;
		foreach ( $starts as $ts ) {
			if ( $ts > 0 ) {
				$display_lines[] = wp_strip_all_tags(
					WC_Appointment_Series_Email::format_session_time( (int) $ts, $customer_tz, false, true, $appt, true )
				);
			}
		}

		$item_data[] = array(
			'name'    => __( 'Recurring series', 'woocommerce-appointments' ),
			'value'   => implode( '<br />', $display_lines ),
			'display' => '',
		);

		return $item_data;
	}

	/**
	 * @param string               $product_quantity Quantity HTML.
	 * @param string               $cart_item_key    Cart key.
	 * @param array<string, mixed> $cart_item        Cart item.
	 * @return string
	 */
	public function lock_recurring_cart_quantity( $product_quantity, $cart_item_key, $cart_item ) {
		if ( ! empty( $cart_item['wca_recurring'] ) ) {
			return sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', esc_attr( $cart_item_key ) );
		}

		return $product_quantity;
	}

	/**
	 * @param WC_Order_Item_Product $item          Order line.
	 * @param string                $cart_item_key Cart key.
	 * @param array<string, mixed>  $values        Cart values.
	 * @param WC_Order              $order         Order.
	 * @return void
	 */
	public function persist_recurring_order_line_meta( $item, $cart_item_key, $values, $order ) {
		unset( $cart_item_key, $order );
		if ( empty( $values['wca_recurring'] ) || ! is_array( $values['wca_recurring'] ) ) {
			return;
		}

		$item->add_meta_data( '_wca_recurring', $values['wca_recurring'], true );
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public function create_series_from_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$manager = new WC_Appointment_Series_Manager();

		foreach ( $order->get_items() as $item_id => $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$line_data = $item->get_meta( '_wca_recurring', true );
			if ( ! $line_data || empty( $line_data['rrule'] ) ) {
				continue;
			}

			if ( (int) $item->get_meta( '_wca_series_id', true ) > 0 ) {
				continue;
			}

			$key = ! empty( $line_data['idempotency_key'] )
				? (string) $line_data['idempotency_key']
				: sprintf( 'order-%d-item-%d', (int) $order->get_id(), (int) $item_id );

			$result = $manager->create_from_order_item( $order, $item, $line_data, $key );

			if ( is_wp_error( $result ) ) {
				$order->add_order_note(
					sprintf(
						/* translators: %1$s: error message, %2$d: line item id */
						__( 'Recurring series could not be created for line #%2$d: %1$s', 'woocommerce-appointments' ),
						$result->get_error_message(),
						(int) $item_id
					)
				);
			}
		}
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public function cancel_series_from_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$manager = new WC_Appointment_Series_Manager();

		foreach ( $order->get_items() as $item ) {
			$series_id = (int) $item->get_meta( '_wca_series_id', true );
			if ( $series_id <= 0 ) {
				continue;
			}

			try {
				$series = new WC_Appointment_Series( $series_id );
			} catch ( Exception $e ) {
				continue;
			}

			if ( WC_Appointment_Series::STATUS_CANCELLED === $series->get_status() ) {
				continue;
			}

			$manager->cancel( $series_id, $series->get_version(), 'future', 'order-cancel-' . (int) $order_id );
		}
	}

	/**
	 * Storefront recurring picker (fired from `appointment.php` via `woocommerce_before_appointment_hook_after`).
	 *
	 * @param string $position   Must be `after` (matches other appointment form hooks).
	 * @param int    $product_id Appointable product ID.
	 * @return void
	 */
	public function render_recurring_picker( $position, $product_id ) {
		if ( 'after' !== $position ) {
			return;
		}

		$product = WC_Product_Appointment::as_appointment_product( $product_id );
		if ( ! $product || ! $product->allows_recurring() ) {
			return;
		}

		$customer_options = $product->get_recurring_customer_options();
		$freq_labels      = WC_Product_Appointment::get_recurring_freq_choices();
		$allowed_freqs    = array_values(
			array_intersect(
				array_keys( $freq_labels ),
				array_map( 'strtoupper', $customer_options['allowedFreqs'] ?: array( 'WEEKLY' ) )
			)
		);
		if ( empty( $allowed_freqs ) ) {
			$allowed_freqs = array( 'WEEKLY' );
		}
		$payment_options = $product->get_recurring_payment_options();

		$template_args = apply_filters(
			'wc_appointments_recurring_picker_template_args',
			array(
				'product'               => $product,
				'allowed_freqs'         => $allowed_freqs,
				'freq_labels'           => $freq_labels,
				'limits'                => array(
					'min' => $product->get_recurring_min_occurrences(),
					'max' => $product->get_recurring_max_occurrences(),
				),
				'default_repeat_freq'   => $allowed_freqs[0],
				'multiple_freqs'        => count( $allowed_freqs ) > 1,
				'payment_options'       => $payment_options,
				'default_payment_model' => $product->get_recurring_default_payment_model(),
				'show_payment_radios'   => count( $payment_options ) > 1,
				'payment_copy'          => WC_Product_Appointment::get_recurring_payment_storefront_copy(),
			),
			$product
		);

		wc_get_template(
			'appointment-form/recurring-picker.php',
			$template_args,
			'woocommerce-appointments',
			WC_APPOINTMENTS_TEMPLATE_PATH
		);
	}
}
