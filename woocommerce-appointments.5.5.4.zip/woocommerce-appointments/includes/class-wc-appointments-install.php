<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Define database version.
define( 'WC_APPOINTMENTS_DB_VERSION', '5.5.3' );

/**
 * Installation/Migration Class.
 *
 * Handles the activation/installation of the plugin.
 *
 * @version  4.3.4
 */
class WC_Appointments_Install {
	/**
	 * Initialize hooks.
	 *
	 * @since 4.3.4
	 */
	public static function init(): void {
		self::register_database_tables();
		self::run();
	}

	/**
	 * Register custom series meta table on $wpdb (required for WC_Data meta CRUD).
	 *
	 * @since 5.4.0
	 */
	public static function register_database_tables(): void {
		global $wpdb;

		$wpdb->wc_appointment_seriesmeta = $wpdb->prefix . 'wc_appointment_seriesmeta';
		if ( ! in_array( 'wc_appointment_seriesmeta', $wpdb->tables, true ) ) {
			$wpdb->tables[] = 'wc_appointment_seriesmeta';
		}

		// Create the series meta table when missing (e.g. db version bumped before schema ran).
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->wc_appointment_seriesmeta ) ) !== $wpdb->wc_appointment_seriesmeta ) {
			self::create_series_meta_table();
		}
	}

	/**
	 * Create wp_wc_appointment_seriesmeta when absent.
	 *
	 * @since 5.4.0
	 */
	private static function create_series_meta_table(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$collate = '';
		if ( $wpdb->has_cap( 'collation' ) ) {
			if ( ! empty( $wpdb->charset ) ) {
				$collate .= "DEFAULT CHARACTER SET $wpdb->charset";
			}
			if ( ! empty( $wpdb->collate ) ) {
				$collate .= " COLLATE $wpdb->collate";
			}
		}

		dbDelta(
			"CREATE TABLE {$wpdb->wc_appointment_seriesmeta} (
				meta_id bigint(20) unsigned NOT NULL auto_increment,
				wc_appointment_series_id bigint(20) unsigned NOT NULL,
				meta_key varchar(255) NULL,
				meta_value longtext NULL,
				PRIMARY KEY (meta_id),
				KEY wc_appointment_series_id (wc_appointment_series_id),
				KEY meta_key (meta_key(32))
			) $collate;"
		);
	}

	/**
	 * Run the installation.
	 *
	 * @since 4.3.4
	 */
	private static function run(): void {
		$saved_version     = get_option( 'wc_appointments_version' );
		$saved_db_version  = get_option( 'wc_appointments_db_version', '' );
		$installed_version = $saved_version ?: WC_APPOINTMENTS_VERSION;
		$needs_schema      = '' === $saved_db_version || version_compare( (string) $saved_db_version, WC_APPOINTMENTS_DB_VERSION, '<' );

		// Check the version before running (plugin bump or schema behind WC_APPOINTMENTS_DB_VERSION).
		if ( ! defined( 'IFRAME_REQUEST' ) && ( WC_APPOINTMENTS_VERSION !== $saved_version || $needs_schema ) ) {
			// Flag legacy installs so pricing defaults can preserve prior behavior.
			// We only set this once, on upgrade from a version older than 5.0.0.
			$legacy_flag = get_option( 'wc_appointments_legacy_pricing_defaults', '' );
			if ( '' === $legacy_flag ) {
				if ( $saved_version && version_compare( $saved_version, '5.0.0', '<' ) ) {
					add_option( 'wc_appointments_legacy_pricing_defaults', 'yes' );
				} else {
					add_option( 'wc_appointments_legacy_pricing_defaults', 'no' );
				}
			}

			// Hub "Show priority": off for fresh installs; on for upgrades (classic / early hub always showed it).
			if ( '' === get_option( 'wc_appointments_hub_priority_default', '' ) ) {
				add_option( 'wc_appointments_hub_priority_default', $saved_version ? '1' : '0' );
			}

			// Store when plugin was updated to 5.0.0 (for per-product pricing logic)
			// Products modified after this time use interval-based, before use duration-based
			if ( version_compare( WC_APPOINTMENTS_VERSION, '5.0.0', '>=' ) && ( ! $saved_version || version_compare( $saved_version, '5.0.0', '<' ) ) ) {
				$update_time = get_option( 'wc_appointments_version_5_0_0_update_time', '' );
				if ( '' === $update_time ) {
					add_option( 'wc_appointments_version_5_0_0_update_time', current_time( 'mysql', true ) );
				}
			}

			if ( $saved_version && version_compare( $saved_version, WC_APPOINTMENTS_VERSION, '<' ) ) {
				self::migrate_gcal_legacy_connection_transients();
			}

			// Removed "What's New" landing page trigger for upgrades
			if ( ! defined( 'WC_APPOINTMENTS_INSTALLING' ) ) {
				define( 'WC_APPOINTMENTS_INSTALLING', true );
			}

			self::update_plugin_version();
			self::update_db_version();

			global $wpdb;

			$wpdb->hide_errors();

			$collate = '';

			if ( $wpdb->has_cap( 'collation' ) ) {
				if ( ! empty( $wpdb->charset ) ) {
					$collate .= "DEFAULT CHARACTER SET $wpdb->charset";
				}
				if ( ! empty( $wpdb->collate ) ) {
					$collate .= " COLLATE $wpdb->collate";
				}
			}

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			dbDelta(
			    "CREATE TABLE {$wpdb->prefix}wc_appointment_relationships (
					ID bigint(20) unsigned NOT NULL auto_increment,
					product_id bigint(20) unsigned NOT NULL,
					staff_id bigint(20) unsigned NOT NULL,
					sort_order bigint(20) unsigned NOT NULL default 0,
					PRIMARY KEY  (ID),
					KEY product_id (product_id),
					KEY staff_id (staff_id)
				) $collate;
				CREATE TABLE {$wpdb->prefix}wc_appointments_availability (
					ID bigint(20) unsigned NOT NULL auto_increment,
					kind varchar(100) NOT NULL,
					kind_id varchar(100) NOT NULL,
					event_id varchar(255) NOT NULL,
					parent_event_id varchar(255) NULL default NULL,
					title varchar(255) NULL,
					range_type varchar(60) NOT NULL,
					from_date varchar(60) NOT NULL,
					to_date varchar(60) NOT NULL,
					from_range varchar(60) NULL,
					to_range varchar(60) NULL,
					appointable varchar(5) NOT NULL default 'yes',
					priority int(2) NOT NULL default 10,
					qty bigint(20) NOT NULL,
					ordering int(2) NOT NULL default 0,
					date_created datetime NULL default NULL,
					date_modified datetime NULL default NULL,
				    rrule text NULL default NULL,
				    PRIMARY KEY  (ID),
					KEY kind_id (kind_id),
					KEY idx_kind_kind_id (kind, kind_id),
					KEY idx_event_id (event_id(191)),
					KEY idx_parent_event_id (parent_event_id(191))
				) $collate;
				CREATE TABLE {$wpdb->prefix}wc_appointments_availability_cache (
				id bigint(20) unsigned NOT NULL auto_increment,
				source enum('availability','appointment') NOT NULL,
				source_id bigint(20) unsigned NOT NULL,
				product_id bigint(20) unsigned NOT NULL default 0,
				staff_id bigint(20) unsigned NOT NULL default 0,
				resource_id bigint(20) unsigned NOT NULL default 0,
				scope enum('global','product','staff','location','resource') NOT NULL default 'global',
				appointable varchar(5) NOT NULL default 'yes',
				priority int(11) NOT NULL default 10,
				ordering int(2) NOT NULL default 0,
				qty bigint(20) NOT NULL default 0,
				start_ts bigint(20) NOT NULL,
				end_ts bigint(20) NOT NULL,
				range_type varchar(60) NULL,
				rule_kind varchar(100) NULL,
				status varchar(100) NULL,
				date_created datetime NULL default NULL,
				date_modified datetime NULL default NULL,
					PRIMARY KEY (id),
					KEY src (source, source_id),
					KEY time_idx (start_ts, end_ts),
					KEY product_staff (product_id, staff_id),
					KEY avail_global_lookup (source, scope, start_ts, end_ts, staff_id, priority),
					KEY avail_product_lookup (source, scope, product_id, start_ts, end_ts, staff_id, priority),
					KEY avail_staff_lookup (source, scope, staff_id, start_ts, end_ts, priority),
					KEY priority_sort (priority DESC),
					KEY idx_resource (resource_id, start_ts, end_ts),
					UNIQUE KEY uniq_occurrence (source, source_id, product_id, staff_id, resource_id, start_ts, end_ts)
				) $collate;
				CREATE TABLE {$wpdb->prefix}wc_appointment_series (
					id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
					version INT UNSIGNED NOT NULL DEFAULT 1,
					status VARCHAR(20) NOT NULL DEFAULT 'pending',
					product_id BIGINT UNSIGNED NOT NULL,
					customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
					staff_assignment_mode VARCHAR(20) NOT NULL DEFAULT 'lock_to_first',
					locked_staff_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
					order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
					subscription_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
					payment_model VARCHAR(20) NOT NULL DEFAULT 'prepaid',
					rrule TEXT NOT NULL,
					dtstart_ts BIGINT UNSIGNED NOT NULL,
					duration_seconds INT UNSIGNED NOT NULL,
					timezone VARCHAR(64) NOT NULL,
					horizon_days SMALLINT UNSIGNED NOT NULL DEFAULT 0,
					next_materialize_ts BIGINT UNSIGNED NOT NULL DEFAULT 0,
					last_materialized_ts BIGINT UNSIGNED NOT NULL DEFAULT 0,
					materialized_count INT UNSIGNED NOT NULL DEFAULT 0,
					rrule_count_cap INT UNSIGNED NOT NULL DEFAULT 0,
					notified_created_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
					created_at DATETIME NOT NULL,
					updated_at DATETIME NOT NULL,
					PRIMARY KEY (id),
					KEY idx_customer (customer_id, status),
					KEY idx_product (product_id, status),
					KEY idx_subscription (subscription_id),
					KEY idx_order (order_id),
					KEY idx_next_materialize (status, next_materialize_ts)
				) $collate;
				CREATE TABLE {$wpdb->prefix}wc_appointment_series_idempotency (
					idempotency_key VARCHAR(80) NOT NULL,
					series_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
					request_hash CHAR(64) NOT NULL,
					response_code SMALLINT UNSIGNED NOT NULL,
					response_body LONGTEXT NOT NULL,
					expires_at DATETIME NOT NULL,
					PRIMARY KEY (idempotency_key),
					KEY idx_series (series_id),
					KEY idx_expires (expires_at)
				) $collate;
				CREATE TABLE {$wpdb->prefix}wc_appointment_seriesmeta (
					meta_id bigint(20) unsigned NOT NULL auto_increment,
					wc_appointment_series_id bigint(20) unsigned NOT NULL,
					meta_key varchar(255) NULL,
					meta_value longtext NULL,
					PRIMARY KEY (meta_id),
					KEY wc_appointment_series_id (wc_appointment_series_id),
					KEY meta_key (meta_key(32))
				) $collate;",
			);

			// One-time cleanup: clear stale from_date/to_date on recurring time rules.
			// Old plugin versions (≤5.2.x) stored dates in these fields for range_type 'time'
			// and 'time:N' rules. These are recurring rules and should not have date bounds.
			// Also purge incorrect index cache rows that were generated from those stale dates
			// and schedule re-indexing so the rules get properly expanded across all future days.
			if ( 'done' !== get_option( 'wc_appointments_cleanup_time_rule_dates' ) ) {
				// 1. Collect affected rule IDs before clearing the stale values.
				$affected_rule_ids = $wpdb->get_col(
					"SELECT ID FROM {$wpdb->prefix}wc_appointments_availability
					 WHERE ( range_type = 'time' OR ( range_type LIKE 'time:%' AND range_type != 'time:range' ) )
					   AND ( from_date != '' OR to_date != '' )"
				);

				// 2. Clear the stale from_date/to_date values.
				if ( ! empty( $affected_rule_ids ) ) {
					$affected_rule_ids = array_map( 'intval', $affected_rule_ids );
					$ids_placeholder   = implode( ', ', array_fill( 0, count( $affected_rule_ids ), '%d' ) );
					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- One-time migration; dynamic IN placeholders; IDs int-cast.
					$sql = $wpdb->prepare( "UPDATE {$wpdb->prefix}wc_appointments_availability SET from_date = '', to_date = '' WHERE ID IN ({$ids_placeholder})", ...$affected_rule_ids );
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
					$wpdb->query( $sql );

					// 3. Delete incorrect cache rows generated from those stale dates.
					$cache_table = $wpdb->prefix . 'wc_appointments_availability_cache';
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $cache_table ) ) === $cache_table ) {
						// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
						$delete_sql = $wpdb->prepare( "DELETE FROM {$cache_table} WHERE source = 'availability' AND source_id IN ({$ids_placeholder})", ...$affected_rule_ids );
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
						$wpdb->query( $delete_sql );
					}

					// 4. Schedule re-indexing for each affected rule so correct cache rows are generated.
					if ( function_exists( 'as_schedule_single_action' ) ) {
						foreach ( $affected_rule_ids as $rule_id ) {
							$rule_id = (int) $rule_id;
							if ( ! as_next_scheduled_action( 'wc_appointments_index_availability_rule', [ $rule_id ] ) ) {
								as_schedule_single_action( time() + 15, 'wc_appointments_index_availability_rule', [ $rule_id ] );
							}
						}
					}
				}

				update_option( 'wc_appointments_cleanup_time_rule_dates', 'done', true );
			}

			// Product type.
			if ( ! get_term_by( 'slug', sanitize_title( 'appointment' ), 'product_type' ) ) {
				wp_insert_term( 'appointment', 'product_type' );
			}

			// Capabilities.
			$wp_roles = wp_roles();

			// Shop staff role.
			add_role(
			    'shop_staff',
			    __( 'Shop Staff', 'woocommerce-appointments' ),
			    [
				'level_8'                   => true,
				'level_7'                   => true,
				'level_6'                   => true,
				'level_5'                   => true,
				'level_4'                   => true,
				'level_3'                   => true,
				'level_2'                   => true,
					'level_1'                   => true,
					'level_0'                   => true,

					'read'                      => true,

					'read_private_posts'        => true,
					'edit_posts'                => true,
					'edit_published_posts'      => true,
					'edit_private_posts'        => true,
					'edit_others_posts'         => false,
					'publish_posts'             => true,
					'delete_private_posts'      => true,
					'delete_posts'              => true,
					'delete_published_posts'    => true,
					'delete_others_posts'       => false,

					'read_private_pages'        => true,
					'edit_pages'                => true,
					'edit_published_pages'      => true,
					'edit_private_pages'        => true,
					'edit_others_pages'         => false,
					'publish_pages'             => true,
					'delete_pages'              => true,
					'delete_private_pages'      => true,
					'delete_published_pages'    => true,
					'delete_others_pages'       => false,

					'read_private_products'     => true,
					'edit_products'             => true,
					'edit_published_products'   => true,
					'edit_private_products'     => true,
					'edit_others_products'      => false,
					'publish_products'          => true,
					'delete_products'           => true,
					'delete_private_products'   => true,
					'delete_published_products' => true,
					'delete_others_products'    => false,
					'edit_shop_orders'          => true,
					'edit_others_shop_orders'   => true,

					'manage_categories'         => false,
					'manage_links'              => false,
					'moderate_comments'         => true,
					'unfiltered_html'           => true,
					'upload_files'              => true,
					'export'                    => false,
					'import'                    => false,

					'edit_users'                => true,
					'list_users'                => true,
				],
			);

			if ( is_object( $wp_roles ) ) {
				// Ability to manage appointments.
				$wp_roles->add_cap( 'shop_manager', 'manage_appointments' );
				$wp_roles->add_cap( 'administrator', 'manage_appointments' );
				$wp_roles->add_cap( 'shop_staff', 'manage_appointments' );

				// Ability to edit their shop orders.
				$wp_roles->add_cap( 'shop_staff', 'edit_shop_orders' );
				$wp_roles->add_cap( 'shop_manager', 'edit_shop_orders' );

				// Ability to edit others shop orders.
				$wp_roles->add_cap( 'shop_staff', 'edit_others_shop_orders' );
				$wp_roles->add_cap( 'shop_manager', 'edit_others_shop_orders' );

				// Ability to view others appointments.
				$wp_roles->add_cap( 'shop_manager', 'manage_others_appointments' );
				$wp_roles->add_cap( 'administrator', 'manage_others_appointments' );
				$wp_roles->remove_cap( 'shop_staff', 'manage_others_appointments' );
			}

			// Shop staff expand capabilities.
			$capabilities         = [];
			$capabilities['core'] = [
				'view_woocommerce_reports',
			];

			$capability_types = [
				'appointment',
			];
			foreach ( $capability_types as $capability_type ) {
				$capabilities[ $capability_type ] = [
					// Post type
					"edit_{$capability_type}",
					"read_{$capability_type}",
					"delete_{$capability_type}",
					"edit_{$capability_type}s",
					"edit_others_{$capability_type}s",
					"publish_{$capability_type}s",
					"read_private_{$capability_type}s",
					"delete_{$capability_type}s",
					"delete_private_{$capability_type}s",
					"delete_published_{$capability_type}s",
					"delete_others_{$capability_type}s",
					"edit_private_{$capability_type}s",
					"edit_published_{$capability_type}s",

					// Terms
					"manage_{$capability_type}_terms",
					"edit_{$capability_type}_terms",
					"delete_{$capability_type}_terms",
					"assign_{$capability_type}_terms",
				];
			}

			foreach ( $capabilities as $cap_group ) {
				foreach ( $cap_group as $cap ) {
					$wp_roles->add_cap( 'shop_staff', $cap );
					$wp_roles->add_cap( 'shop_manager', $cap );
					$wp_roles->add_cap( 'administrator', $cap );
				}
			}

			// Update 5.2.5 — purge stale in-cart availability cache rows left by PayPal
			// ppc-simulate-cart requests (see gh#1275). The guard fix in
			// WC_Appointments_Cache_Availability::already_indexed_in_request() prevents new
			// stale entries going forward; this one-time migration clears existing ones.
			if ( version_compare( $installed_version, '5.2.5', '<' ) ) {
				self::migration_5_2_5_purge_stale_incart_index();
			}

			// Update 5.5.0 — expand availability cache scope enum for location/resource rules.
			if ( '' === $saved_db_version || version_compare( (string) $saved_db_version, '5.5.0', '<' ) ) {
				self::migration_5_5_0_availability_cache_scopes();
			}

			// Update 5.5.2 - drop unused availability cache creator_id.
			if ( '' === $saved_db_version || version_compare( (string) $saved_db_version, '5.5.2', '<' ) ) {
				self::migration_5_5_2_drop_availability_cache_creator_id();
			}

			// Update 5.1.2
			if ( version_compare( $installed_version, '5.1.2', '<' ) ) {
				self::migration_5_1_2();
			}

			// Update 4.21.3
			if ( version_compare( $installed_version, '4.22.0', '<' ) ) {
				// Flush Permalinks.
				flush_rewrite_rules();
			}

			// Update 4.21.3
			if ( version_compare( $installed_version, '4.21.3', '<' ) ) {
				// Flush Permalinks.
				flush_rewrite_rules();
			}

			// Update 4.5.1
			if ( version_compare( $installed_version, '4.5.1', '<' ) ) {
				self::migration_4_5_1();
			}

			// Update 4.4.0
			if ( version_compare( $installed_version, '4.4.0', '<' ) ) {
				self::migration_4_4_0();
			}

			// Update 4.1.5
			if ( version_compare( get_option( 'wc_appointments_version', WC_APPOINTMENTS_VERSION ), '4.1.5', '<' ) ) {
				self::migration_4_1_5();
			}

			// Update 3.4.0
			if ( version_compare( get_option( 'wc_appointments_version', WC_APPOINTMENTS_VERSION ), '3.4', '<' ) ) {
				self::migration_3_4_0();
			}

			// Update 3.7.0
			if ( version_compare( get_option( 'wc_appointments_version', WC_APPOINTMENTS_VERSION ), '3.7', '<' ) ) {
				self::migration_3_7_0();
			}

			// Check template versions.
			if ( class_exists( 'WC_Appointments_Admin' ) ) {
				WC_Appointments_Admin::template_file_check_notice();
			}

			self::cleanup_empty_availability_rules();

			// Ensure postmeta indexes exist for appointment date queries
			self::ensure_postmeta_indexes();

			// Availability rule lookups (GCal sync, storefront rules).
			self::ensure_availability_table_indexes();

			do_action( 'wc_appointments_updated' );
		}
	}

	/**
	 * Updates the plugin version in db.
	 *
	 * @since 4.3.4
	 */
	private static function update_plugin_version(): void {
		delete_option( 'wc_appointments_version' );
		add_option( 'wc_appointments_version', WC_APPOINTMENTS_VERSION );
	}

	/**
	 * Updates the plugin db version in db.
	 *
	 * @since 4.3.4
	 */
	private static function update_db_version(): void {
		delete_option( 'wc_appointments_db_version' );
		add_option( 'wc_appointments_db_version', WC_APPOINTMENTS_DB_VERSION );
	}

	/**
	 * Remove pre-5.0 Google Calendar transients left after sync-token storage moved to options.
	 *
	 * Runs once per site on plugin upgrade.
	 */
	private static function migrate_gcal_legacy_connection_transients(): void {
		if ( get_option( 'wc_appointments_gcal_legacy_transients_cleared' ) ) {
			return;
		}

		delete_transient( 'wc_appointments_gcal_access_token' );
		delete_transient( 'wc_appointments_gcal_sync_token' );
		update_option( 'wc_appointments_gcal_legacy_transients_cleared', 1, false );
	}

	/**
	 * 5.5.0: Expand availability cache `scope` enum for location/resource open/closed rules.
	 *
	 * @since 5.5.0
	 */
	private static function migration_5_5_0_availability_cache_scopes(): void {
		global $wpdb;

		$table = $wpdb->prefix . 'wc_appointments_availability_cache';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $table !== $exists ) {
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table from wpdb->prefix; DDL cannot use prepare placeholders for identifiers.
		$wpdb->query( "ALTER TABLE `{$table}` MODIFY COLUMN scope enum('global','product','staff','location','resource') NOT NULL default 'global'" );
	}

	/**
	 * 5.5.2: Drop unused creator_id from availability cache (never read for product logic).
	 *
	 * @since 5.5.2
	 */
	private static function migration_5_5_2_drop_availability_cache_creator_id(): void {
		global $wpdb;

		$table = $wpdb->prefix . 'wc_appointments_availability_cache';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $table !== $exists ) {
			return;
		}

		$column_exists = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
				 WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
				DB_NAME,
				$table,
				'creator_id'
			)
		);

		if ( ! empty( $column_exists ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Migration DDL; table from wpdb->prefix.
			$wpdb->query( "ALTER TABLE {$table} DROP COLUMN creator_id" );
		}
	}

	/**
	 * 5.2.5: Remove stale `in-cart` rows from the availability cache index.
	 *
	 * When the WooCommerce PayPal Payments `ppc-simulate-cart` action fired, our
	 * plugin created appointment DB rows with `in-cart` status and then immediately
	 * set them to `was-in-cart`. A guard bug in the cache indexer prevented the
	 * status change from being reflected, leaving orphaned `in-cart` rows in the
	 * `wp_wc_appointments_availability_cache` table. Those rows falsely consumed
	 * capacity, making live slots appear fully booked.
	 *
	 * This migration deletes every `appointment` source row in the cache whose
	 * corresponding `wc_appointment` post has status `wc-was-in-cart`.
	 *
	 * @since 5.2.5
	 */
	private static function migration_5_2_5_purge_stale_incart_index(): void {
		global $wpdb;

		if ( ! class_exists( 'WC_Appointments_Cache_Availability' ) ) {
			return;
		}

		$cache_table = $wpdb->prefix . WC_Appointments_Cache_Availability::CACHE_TABLE;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration; table names from wpdb.
		$delete_sql = $wpdb->prepare( "DELETE cache FROM `{$cache_table}` AS cache INNER JOIN `{$wpdb->posts}` AS p ON p.ID = cache.source_id WHERE cache.source = %s AND p.post_type = %s AND p.post_status = %s", 'appointment', 'wc_appointment', 'wc-was-in-cart' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$deleted = $wpdb->query( $delete_sql );

		if ( $deleted ) {
			wc_get_logger()->info(
				sprintf( '5.2.5 migration: removed %d stale in-cart availability cache rows.', (int) $deleted ),
				[ 'source' => 'wc-appointments' ]
			);
		}
	}

	private static function migration_3_7_0(): void {
		global $wpdb;

		// Trash all GCal appointments.
		$gcal_id = (int) apply_filters( 'woocommerce_appointments_gcal_synced_product_id', 2147483647 );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Migration; table names from wpdb; gcal_id int-cast.
		$trash_sql = $wpdb->prepare( "UPDATE {$wpdb->posts} as posts LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id SET posts.post_status = 'trash' WHERE posts.post_type = 'wc_appointment' AND meta.meta_key = '_appointment_product_id' AND meta.meta_value = %d", $gcal_id );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $trash_sql );

		// Delete full sync checking.
		wp_clear_scheduled_hook( 'wc-appointment-sync-full-from-gcal' );

		// Move Google Calendar Integration settings.
		$old_gcal_settings = get_option( 'wc_appointments_gcal_settings' );
		if ( $old_gcal_settings ) {
			foreach ( $old_gcal_settings as $old_gcal_setting_key => $old_gcal_setting_value ) {
				switch ( $old_gcal_setting_key ) {
					case 'client_id':
						add_option( 'wc_appointments_gcal_client_id', $old_gcal_setting_value );
						break;
					case 'client_secret':
						add_option( 'wc_appointments_gcal_client_secret', $old_gcal_setting_value );
						break;
					case 'calendar_id':
						add_option( 'wc_appointments_gcal_calendar_id', $old_gcal_setting_value );
						break;
					case 'authorization':
						add_option( 'wc_appointments_gcal_authorization', $old_gcal_setting_value );
						break;
					case 'twoway':
						add_option( 'wc_appointments_gcal_twoway', $old_gcal_setting_value );
						break;
					case 'debug':
						add_option( 'wc_appointments_gcal_debug', $old_gcal_setting_value );
						break;
				}
			}
			#delete_option( 'wc_appointments_gcal_settings' );
		}
	}

	/**
	 * Change appointment status from "pending" to "pending-confirmation".
	 *
	 * @since 3.4.0
	 */
	private static function migration_3_4_0(): void {
		global $wpdb;

		$wpdb->query(
		    "UPDATE {$wpdb->posts} as posts
			SET posts.post_status = 'pending-confirmation'
			WHERE posts.post_type = 'wc_appointment'
			AND posts.post_status = 'pending';",
		);
	}

	/**
	 * Trash duplicated appointments for WPML.
	 *
	 * @since 4.1.5
	 */
	private static function migration_4_1_5(): void {
		global $wpdb;

		if ( class_exists( 'SitePress' ) && class_exists( 'woocommerce_wpml' ) && class_exists( 'WPML_Element_Translation_Package' ) ) {
			$wpdb->query(
			    "UPDATE {$wpdb->posts} as posts
				LEFT JOIN {$wpdb->prefix}icl_translations AS translations ON translations.element_id = posts.id
				SET posts.post_status = 'trash'
				WHERE posts.post_type = 'wc_appointment'
					AND translations.element_type = 'post_wc_appointment'
					AND translations.source_language_code != ''
				",
			);
		}
	}

	/**
	 * Migrate global availabiltity from options table
	 * to custom availability table.
	 *
	 * @since 4.3.4
	 */
	private static function migration_4_4_0(): void {
		global $wpdb;

		// Get 'wc_appointments_gcal_twoway' option.
		$two_way_option = get_option( 'wc_appointments_gcal_twoway' );

		// Migrate global availabilities.
		$global_availability = get_option( 'wc_global_appointment_availability', [] );

		if ( ! empty( $global_availability ) ) {
			$index = 0;

			foreach ( $global_availability as $rule ) {
				$type        = empty( $rule['type'] ) ? '' : $rule['type'];
				$from_range  = empty( $rule['from'] ) ? '' : $rule['from'];
				$to_range    = empty( $rule['to'] ) ? '' : $rule['to'];
				$from_date   = empty( $rule['from_date'] ) ? '' : $rule['from_date'];
				$to_date     = empty( $rule['to_date'] ) ? '' : $rule['to_date'];
				$appointable = empty( $rule['appointable'] ) ? '' : $rule['appointable'];
				$priority    = empty( $rule['priority'] ) ? 10 : $rule['priority'];

				$wpdb->insert(
				    $wpdb->prefix . 'wc_appointments_availability',
				    [
						'kind'          => 'availability#global',
						'kind_id'       => '',
						'title'         => '',
						'range_type'    => $type,
						'from_range'    => $from_range,
						'to_range'      => $to_range,
						'from_date'     => $from_date,
						'to_date'       => $to_date,
						'appointable'   => $appointable,
						'priority'      => $priority,
						'ordering'      => $index,
						'rrule'         => '',
						'date_created'  => current_time( 'mysql' ),
						'date_modified' => current_time( 'mysql' ),
					],
				);

				$index++;
			}

			// When migrated, delete old availability rules.
			delete_option( 'wc_global_appointment_availability' );
		}

		// Migrate product availabilities.
		$all_product_args = [
			'post_status'      => 'publish',
			'post_type'        => 'product',
			'posts_per_page'   => -1,
			'suppress_filters' => true,
			'fields'           => 'ids',
			'orderby'          => 'title',
			'order'            => 'ASC',
		];
		$posts_query      = new WP_Query();
	    $all_product_ids  = $posts_query->query( $all_product_args );

		if ( $all_product_ids ) {
			foreach ( $all_product_ids as $all_product_id ) {
				$product_availabilities = get_post_meta( $all_product_id, '_wc_appointment_availability', true );

				if ( is_array( $product_availabilities ) ) {
					$index_p = 0;

					foreach ( $product_availabilities as $rule ) {
						$type        = empty( $rule['type'] ) ? '' : $rule['type'];
						$from_range  = empty( $rule['from'] ) ? '' : $rule['from'];
						$to_range    = empty( $rule['to'] ) ? '' : $rule['to'];
						$from_date   = empty( $rule['from_date'] ) ? '' : $rule['from_date'];
						$to_date     = empty( $rule['to_date'] ) ? '' : $rule['to_date'];
						$appointable = empty( $rule['appointable'] ) ? '' : $rule['appointable'];
						$priority    = empty( $rule['priority'] ) ? 10 : $rule['priority'];

						$wpdb->insert(
						    $wpdb->prefix . 'wc_appointments_availability',
						    [
								'kind'          => 'availability#product',
								'kind_id'       => $all_product_id,
								'title'         => '',
								'range_type'    => $type,
								'from_range'    => $from_range,
								'to_range'      => $to_range,
								'from_date'     => $from_date,
								'to_date'       => $to_date,
								'appointable'   => $appointable,
								'priority'      => $priority,
								'ordering'      => $index_p,
								'rrule'         => '',
								'date_created'  => current_time( 'mysql' ),
								'date_modified' => current_time( 'mysql' ),
							],
						);

						$index_p++;
					}

					// When migrated, delete old availability rules.
					WC_Product_Appointment_Data_Store_CPT::delete_legacy_availability_meta( (int) $all_product_id );
				} else {
					continue;
				}
			}
		}

		// Migrate staff availabilities and settings.
		$all_staff = get_users(
		    [
				'role'    => 'shop_staff',
				'orderby' => 'nicename',
				'order'   => 'asc',
			],
		);

		if ( $all_staff ) {
			foreach ( $all_staff as $single_staff ) {
				// Get single staff availability rules.
				$single_staff_availabilities = get_user_meta( $single_staff->ID, '_wc_appointment_availability', true );

				// Get single staff availability rules.
				$single_staff_gcal_calendar_id = get_user_meta( $single_staff->ID, 'wc_appointments_gcal_calendar_id', true );

				// Update single staff two_way option.
				if ( 'yes' === $two_way_option ) {
					update_user_meta( $single_staff->ID, 'wc_appointments_gcal_twoway', 'two_way' );
				} elseif ( 'no' === $two_way_option ) {
					update_user_meta( $single_staff->ID, 'wc_appointments_gcal_twoway', 'one_way' );
				}

				if ( is_array( $single_staff_availabilities ) ) {
					$index_s = 0;

					foreach ( $single_staff_availabilities as $rule ) {
						$type        = empty( $rule['type'] ) ? '' : $rule['type'];
						$from_range  = empty( $rule['from'] ) ? '' : $rule['from'];
						$to_range    = empty( $rule['to'] ) ? '' : $rule['to'];
						$from_date   = empty( $rule['from_date'] ) ? '' : $rule['from_date'];
						$to_date     = empty( $rule['to_date'] ) ? '' : $rule['to_date'];
						$appointable = empty( $rule['appointable'] ) ? '' : $rule['appointable'];
						$priority    = empty( $rule['priority'] ) ? 10 : $rule['priority'];

						$wpdb->insert(
						    $wpdb->prefix . 'wc_appointments_availability',
						    [
								'kind'          => 'availability#staff',
								'kind_id'       => $single_staff->ID,
								'title'         => '',
								'range_type'    => $type,
								'from_range'    => $from_range,
								'to_range'      => $to_range,
								'from_date'     => $from_date,
								'to_date'       => $to_date,
								'appointable'   => $appointable,
								'priority'      => $priority,
								'ordering'      => $index_s,
								'rrule'         => '',
								'date_created'  => current_time( 'mysql' ),
								'date_modified' => current_time( 'mysql' ),
							],
						);

						$index_s++;
					}

					// When migrated, delete old availability rules.
					delete_user_meta( $single_staff->ID, '_wc_appointment_availability' );
				} else {
					continue;
				}
			}
		}

		// Update 'wc_appointments_gcal_twoway' option.
		if ( 'yes' === $two_way_option ) {
			update_option( 'wc_appointments_gcal_twoway', 'two_way' );
		} elseif ( 'no' === $two_way_option ) {
			update_option( 'wc_appointments_gcal_twoway', 'one_way' );
		}

		// Stop syncing via WP Cron.
		wp_clear_scheduled_hook( 'wc-appointment-sync-from-gcal' );
		wp_clear_scheduled_hook( 'wc-appointment-complete' );
		wp_clear_scheduled_hook( 'wc-appointment-reminder' );
		wp_clear_scheduled_hook( 'wc-appointment-remove-inactive-cart' );
	}

	/**
	 * Remove as scheduled action.
	 *
	 * @since 4.5.1
	 */
	private static function migration_4_5_1(): void {
		if ( ! defined( 'EMPTY_TRASH_DAYS' ) ) {
			define( 'EMPTY_TRASH_DAYS', 30 );
		}

		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'wc-appointment-sync-from-gcal' );
		}
	}

	/**
	 * Add parent_event_id column to availability table.
	 *
	 * @since 5.1.2
	 */
	private static function migration_5_1_2(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'wc_appointments_availability';
		
		// Check if parent_event_id column exists
		$column_exists = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
				 WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
				DB_NAME,
				$table,
				'parent_event_id'
			)
		);

		// Add column if it doesn't exist
		if ( empty( $column_exists ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Migration DDL; table from wpdb->prefix.
			$wpdb->query( "ALTER TABLE {$table} ADD COLUMN parent_event_id VARCHAR(255) NULL DEFAULT NULL AFTER event_id" );
		}
	}

	/**
	 * Ensure indexes exist on the availability rules table.
	 *
	 * Covers Google Calendar `event_id` / `parent_event_id` equality lookups and
	 * storefront/admin `kind` + `kind_id` filters. Safe to call multiple times.
	 *
	 * @since 5.4.3
	 */
	public static function ensure_availability_table_indexes(): void {
		global $wpdb;

		$table = $wpdb->prefix . 'wc_appointments_availability';

		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			return;
		}

		$indexes = [
			'idx_kind_kind_id'    => 'kind, kind_id',
			'idx_event_id'        => 'event_id(191)',
			'idx_parent_event_id' => 'parent_event_id(191)',
		];

		foreach ( $indexes as $index_name => $columns ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$check_sql = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", $index_name );
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			if ( ! empty( $wpdb->get_results( $check_sql ) ) ) {
				continue;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( "ALTER TABLE {$table} ADD INDEX {$index_name} ({$columns})" );
		}
	}

	/**
	 * Ensure required indexes and unique keys exist on the availability cache table.
	 * Safe to call multiple times.
	 */
	public static function ensure_availability_cache_indexes(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'wc_appointments_availability_cache';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$check_sql = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", 'uniq_src_srcid_staff_prod_time_status' );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( empty( $wpdb->get_results( $check_sql ) ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( "ALTER TABLE {$table} ADD UNIQUE KEY uniq_src_srcid_staff_prod_time_status (source, source_id, staff_id, product_id, start_ts, end_ts, status)" );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$check_sql = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", 'idx_src_staff_time' );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( empty( $wpdb->get_results( $check_sql ) ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( "ALTER TABLE {$table} ADD INDEX idx_src_staff_time (source, staff_id, start_ts, end_ts)" );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$check_sql = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", 'idx_src_product_time' );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( empty( $wpdb->get_results( $check_sql ) ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( "ALTER TABLE {$table} ADD INDEX idx_src_product_time (source, product_id, start_ts, end_ts)" );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$check_sql = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", 'idx_status' );
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( empty( $wpdb->get_results( $check_sql ) ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( "ALTER TABLE {$table} ADD INDEX idx_status (status)" );
		}
	}

	/**
	 * Ensure required indexes exist on postmeta table for appointment queries.
	 * Safe to call multiple times.
	 *
	 * This optimizes all appointment-related postmeta queries by creating composite
	 * indexes:
	 *
	 * 1. (meta_key, meta_value) - Helps with:
	 *    - Date range queries: _appointment_start, _appointment_end (comparisons: <, >, <=, >=)
	 *    - ID lookups: _appointment_product_id, _appointment_staff_id, _appointment_customer_id,
	 *      _appointment_order_item_id (equality and IN clauses)
	 *    - Google Calendar: _wc_appointments_gcal_event_id (IN clauses)
	 *    - Other meta: _appointment_all_day (equality checks)
	 *
	 * 2. (post_id, meta_key) - Helps with:
	 *    - JOIN operations: When joining postmeta on post_id and filtering by meta_key
	 *    - Significantly speeds up queries with multiple LEFT JOINs on postmeta
	 *    - Used in get_appointment_ids_by() when querying by customer, product, staff, dates
	 *
	 * These indexes allow MySQL to efficiently:
	 * - Filter by meta_key first, then perform comparisons/lookups on meta_value
	 * - Join on post_id first, then filter by meta_key (much faster than scanning all postmeta)
	 */
		public static function ensure_postmeta_indexes(): void {
			global $wpdb;
			$table = $wpdb->postmeta;

			// Check if composite index on (meta_key, meta_value) exists
			// This index helps with all queries that filter by meta_key and compare/lookup meta_value
			$index_name = 'wc_appointments_meta_key_value';
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$check_sql  = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", $index_name );
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$existing_index = $wpdb->get_results( $check_sql );

			$created_key = false;
			if ( empty( $existing_index ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
				$wpdb->query( "ALTER TABLE {$table} ADD INDEX {$index_name} (meta_key(191), meta_value(20))" );
				$created_key = true;
			}

			$index_name_join = 'wc_appointments_post_id_meta_key';
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$check_sql       = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", $index_name_join );
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$existing_index_join = $wpdb->get_results( $check_sql );

			$created_join = false;
			if ( empty( $existing_index_join ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
				$wpdb->query( "ALTER TABLE {$table} ADD INDEX {$index_name_join} (post_id, meta_key(191))" );
				$created_join = true;
			}

			if ( $created_key ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$check_sql = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", $index_name );
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$check_key = $wpdb->get_results( $check_sql );
				if ( empty( $check_key ) && function_exists( 'wc_get_logger' ) ) {
					wc_get_logger()->warning( 'WC Appointments: Warning - postmeta meta_key/meta_value index creation may have failed.', array( 'source' => 'woocommerce-appointments' ) );
				}
			}
			if ( $created_join ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$check_sql = $wpdb->prepare( "SHOW INDEX FROM {$table} WHERE Key_name = %s", $index_name_join );
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$check_join = $wpdb->get_results( $check_sql );
				if ( empty( $check_join ) && function_exists( 'wc_get_logger' ) ) {
					wc_get_logger()->warning( 'WC Appointments: Warning - post_id/meta_key index creation may have failed.', array( 'source' => 'woocommerce-appointments' ) );
				}
			}
		}

	/**
	 * Ensure indexes.
	 *
	 * Checks and ensures availability cache indexes exist on plugin load.
	 */
	public static function maybe_ensure_indexes(): void {
		$flag = 'wc_appointments_availability_cache_indexes_done';
		if ( get_option( $flag ) ) {
			return;
		}
		self::ensure_availability_cache_indexes();
		update_option( $flag, 1, false );
	}

	/**
	 * Ensure postmeta indexes.
	 *
	 * Checks and ensures postmeta indexes exist on plugin load.
	 */
	public static function maybe_ensure_postmeta_indexes(): void {
		$flag = 'wc_appointments_postmeta_indexes_done';
		// One-shot: SHOW INDEX on postmeta every request is expensive on Local/large shops.
		if ( get_option( $flag ) ) {
			return;
		}
		self::ensure_postmeta_indexes();
		update_option( $flag, 1, true );
	}

	/**
	 * Ensure availability table indexes on plugin load (idempotent).
	 *
	 * @since 5.4.3
	 */
	public static function maybe_ensure_availability_table_indexes(): void {
		$flag = 'wc_appointments_availability_table_indexes_done';
		if ( get_option( $flag ) ) {
			return;
		}
		self::ensure_availability_table_indexes();
		update_option( $flag, 1, true );
	}

	/**
	 * Cleanup empty availability rules.
	 *
	 * Removes empty or invalid availability rules from the database.
	 */
	private static function cleanup_empty_availability_rules(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'wc_appointments_availability';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Maintenance cleanup; table from wpdb->prefix.
		$wpdb->query( "DELETE FROM {$table} WHERE (range_type = '' OR (IFNULL(from_date,'') = '' AND IFNULL(to_date,'') = '' AND IFNULL(from_range,'') = '' AND IFNULL(to_range,'') = '')) AND event_id = ''" );
	}
}

add_action( 'plugins_loaded', [ 'WC_Appointments_Install', 'maybe_ensure_indexes' ], 20 );
add_action( 'plugins_loaded', [ 'WC_Appointments_Install', 'maybe_ensure_postmeta_indexes' ], 20 );
add_action( 'plugins_loaded', [ 'WC_Appointments_Install', 'maybe_ensure_availability_table_indexes' ], 20 );
