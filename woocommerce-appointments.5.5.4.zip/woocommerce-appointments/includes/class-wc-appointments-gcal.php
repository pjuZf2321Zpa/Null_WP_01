<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Google Calendar Synchronization.
 */
class WC_Appointments_GCal {

	public const TOKEN_TRANSIENT_TIME = 3500;

	public const DAYS_OF_WEEK = [
		1 => 'monday',
		2 => 'tuesday',
		3 => 'wednesday',
		4 => 'thursday',
		5 => 'friday',
		6 => 'saturday',
		7 => 'sunday',
	];

	/**
	 * Class ID set by default.
	 */
	public string $id = 'gcal';

	/**
	 * oAuth URI set by default.
	 */
	public string $oauth_uri = 'https://accounts.google.com/o/oauth2/';

	/**
	 * Calendars URI set by default.
	 */
	public string $calendars_uri = 'https://www.googleapis.com/calendar/v3/calendars/';

	/**
	 * Calendars list set by default.
	 */
	public string $calendars_list = 'https://www.googleapis.com/calendar/v3/users/me/calendarList';

	/**
	 * API scope set by default.
	 */
	public string $api_scope = 'https://www.googleapis.com/auth/calendar';

	/**
	 * API Redirect URI.
	 */
	public string $redirect_uri;

	/**
	 * Option Client ID.
	 *
	 * @var string|false
	 */
	public $client_id = false;

	/**
	 * Option Client Secret.
	 *
	 * @var string|false
	 */
	public $client_secret = false;

	/**
	 * Option Calendar ID.
	 *
	 * @var string|false
	 */
	public $calendar_id = false;

	/**
	 * Option Debug.
	 *
	 * @var bool
	 */
	private bool $debug = false;

	/**
	 * OAuth2 token endpoint.
	 *
	 * @var string
	 */
	private string $token_uri;

	/**
	 * OAuth2 revoke endpoint.
	 *
	 * @var string
	 */
	private string $revoke_uri;

	/**
	 * Option Twoway.
	 *
	 * @var string
	 */
	private string $twoway = 'one_way';

	/**
	 * If the service is currently is a syncing operation with google.
	 *
	 * @var bool
	 */
	protected bool $syncing = false;

	/**
	 * If the service is currently is a syncing operation with google.
	 *
	 * @var bool
	 */
	protected bool $staff_syncing = false;

	/**
	 * @var WC_Appointments_GCal The single instance of the class
	 */
	protected static $_instance;

	/**
	 * Per-request access token cache keyed by user_id.
	 *
	 * @var array<string, string|false>
	 */
	private array $access_token_cache = [];

	/**
	 * User ID not set by default.
	 *
	 * @var int|string|false
	 */
	private $user_id = false;


	/**
	 * Forward-only sync window used during a run.
	 * Set by sync_from_gcal_locked and consumed by sync_from_gcal() new fetch path.
	 *
	 * @var array{start: int, end: int}|null Sync window timestamps or null.
	 */
	protected ?array $current_sync_window = null;

	/**
	 * When true, inbound sync without a token fetches all historical events (admin re-sync only).
	 *
	 * @var bool
	 */
	protected bool $manual_full_resync = false;

	/**
	 * The calendar ID from which an incoming sync originated.
	 * Used to prevent syncing back to the same calendar while allowing cross-calendar sync.
	 *
	 * @var string
	 */
	protected string $incoming_sync_calendar_id = '';

	/**
	 * Main WC_Appointments_GCal Instance
	 */
	public static function instance(): self {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Init and hook in the integration.
	 */
	public function __construct() {
		// API.
		$this->redirect_uri  = WC()->api_request_url( 'wc_appointments_oauth_redirect' );
		$this->client_id     = get_option( 'wc_appointments_gcal_client_id' );
		$this->client_secret = get_option( 'wc_appointments_gcal_client_secret' );
		$this->calendar_id   = get_option( 'wc_appointments_gcal_calendar_id' );
		$this->debug         = get_option( 'wc_appointments_gcal_debug' );
		$this->twoway        = get_option( 'wc_appointments_gcal_twoway' );

		// Upgrade to current OAuth endpoints (filterable for safety).
		$this->oauth_uri = apply_filters( 'wc_appointments_gcal_oauth_auth_url', 'https://accounts.google.com/o/oauth2/v2/auth' );
		$this->token_uri = apply_filters( 'wc_appointments_gcal_oauth_token_url', 'https://oauth2.googleapis.com/token' );
		$this->revoke_uri = apply_filters( 'wc_appointments_gcal_oauth_revoke_url', 'https://oauth2.googleapis.com/revoke' );

		// Oauth redirect.
		add_action( 'woocommerce_api_wc_appointments_oauth_redirect', [ $this, 'oauth_redirect' ] );
		add_action( 'admin_notices', [ $this, 'admin_notices' ] );

		// Run the schedule and Sync from GCal (ensure single run per calendar).
		add_action( 'action_scheduler_after_process_queue', [ $this, 'sync_from_gcal_locked' ] );

		// Appointment update actions.
		// Sync all statuses (except cancelled), but limit inside maybe_sync_to_gcal_from_status() function.
		$statuses = apply_filters(
		    'woocommerce_appointments_gcal_statuses',
		    [ 'unpaid', 'paid', 'pending-confirmation', 'confirmed', 'complete', 'in-cart' ],
		);
		foreach ( $statuses as $status ) {
			add_action( 'woocommerce_appointment_' . $status, [ $this, 'sync_unedited_appointment' ] );
		}

		// Remove from Gcal.
		add_action( 'woocommerce_appointment_cancelled', [ $this, 'sync_updated_appointment' ] );

		// Process edited appointment.
		add_action( 'woocommerce_appointment_process_meta', [ $this, 'sync_edited_appointment' ] );

		// Process edited appointment with staff changed.
		add_action( 'woocommerce_appointment_staff_changed', [ $this, 'maybe_sync_to_gcal_from_staff_change' ], 10, 4 );

		// Process rescheduled appointment.
		add_action( 'woocommerce_appointments_rescheduled_appointment', [ $this, 'sync_updated_appointment' ] );

		// Process REST API updates (used by admin calendar, external integrations, etc.).
		add_action( 'woocommerce_rest_insert_wc_appointment_object', [ $this, 'sync_rest_api_appointment' ], 10, 3 );

		// Sync trashed/untrashed appointments.
		add_action( 'trashed_post', [ $this, 'sync_updated_appointment' ] );
		add_action( 'untrashed_post', [ $this, 'sync_updated_appointment' ] );

		// Sync availability to Gcal.
		add_action( 'woocommerce_before_appointments_availability_object_save', [ $this, 'sync_availability' ] ); // 'woocommerce_before_' . $object_type . '_object_save'
		add_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $this, 'delete_availability' ] );
	}

	/**
	 * Get redirect_uri option.
	 */
    public function get_redirect_uri(): string {
        return $this->redirect_uri;
    }

	/**
	 * Get client_id option.
	 *
	 * @return string|false
	 */
    public function get_client_id() {
        return $this->client_id;
    }

	/**
	 * Get client_secret option.
	 *
	 * @return string|false
	 */
    public function get_client_secret() {
        return $this->client_secret;
    }

	/**
	 * Build a signed OAuth state (target staff id + initiating user + expiry + HMAC).
	 *
	 * Binding the initiator means a crafted callback URL cannot connect a foreign
	 * Google account when a different admin clicks it.
	 *
	 * @param int $user_id Staff user ID, or 0 for global calendar.
	 * @return string
	 */
	public function create_oauth_state( int $user_id = 0 ): string {
		$expiry  = time() + HOUR_IN_SECONDS;
		$payload = absint( $user_id ) . '.' . get_current_user_id() . '.' . $expiry;
		$sig     = hash_hmac( 'sha256', $payload, wp_salt( 'nonce' ) );
		return $payload . '.' . $sig;
	}

	/**
	 * Validate OAuth state and return the staff user id (0 = global).
	 *
	 * @param string $state Raw state query value.
	 * @return int|false User id on success, false if invalid, expired, or issued to another user.
	 */
	public function parse_oauth_state( string $state ) {
		$parts = explode( '.', trim( $state ) );
		if ( 4 !== count( $parts ) ) {
			return false;
		}

		list( $user_id, $initiator, $expiry, $sig ) = $parts;
		$expect = hash_hmac( 'sha256', $user_id . '.' . $initiator . '.' . $expiry, wp_salt( 'nonce' ) );

		if ( ! hash_equals( $expect, (string) $sig ) ) {
			return false;
		}

		if ( absint( $expiry ) < time() || absint( $initiator ) !== get_current_user_id() ) {
			return false;
		}

		return absint( $user_id );
	}

	/**
	 * Read refresh token (plaintext). Never deletes storage on failure.
	 *
	 * One-shot migrate: a brief encrypt-at-rest experiment may have left `wcaenc:`
	 * blobs; decrypt once and rewrite plaintext so AUTH salt rotation cannot strand sync.
	 *
	 * @param int|string $user_id Staff user ID or empty for global.
	 * @return string
	 */
	private function get_refresh_token( $user_id = '' ): string {
		$stored = $user_id
			? (string) get_user_meta( $user_id, 'wc_appointments_gcal_refresh_token', true )
			: (string) get_option( 'wc_appointments_gcal_refresh_token', '' );

		if ( '' === $stored || 0 !== strpos( $stored, 'wcaenc:' ) ) {
			return $stored;
		}

		$plain = '';
		if ( function_exists( 'openssl_decrypt' ) ) {
			$decoded = base64_decode( substr( $stored, 7 ), true );
			if ( false !== $decoded && strlen( $decoded ) >= 17 ) {
				$plain = (string) openssl_decrypt(
					substr( $decoded, 16 ),
					'AES-256-CBC',
					hash( 'sha256', wp_salt( 'auth' ), true ),
					OPENSSL_RAW_DATA,
					substr( $decoded, 0, 16 )
				);
			}
		}

		if ( '' === $plain ) {
			$this->log_error( 'token_decrypt_failed', 'Legacy encrypted refresh token could not be read; left in place.' );
			return '';
		}

		if ( $user_id ) {
			update_user_meta( $user_id, 'wc_appointments_gcal_refresh_token', $plain );
		} else {
			update_option( 'wc_appointments_gcal_refresh_token', $plain, false );
		}

		return $plain;
	}

	/**
	 * Persist refresh token as plaintext.
	 *
	 * @param int|string $user_id Staff user ID or empty for global.
	 * @param string     $token   Refresh token plaintext.
	 * @return bool
	 */
	private function save_refresh_token( $user_id, string $token ): bool {
		if ( '' === $token ) {
			return false;
		}

		if ( $user_id ) {
			return false !== update_user_meta( $user_id, 'wc_appointments_gcal_refresh_token', $token );
		}

		return false !== update_option( 'wc_appointments_gcal_refresh_token', $token, false );
	}

	/**
	 * Set calendar_id option.
	 *
	 * @param string|false $option Calendar ID.
	 */
	public function set_calendar_id( $option ): void {
        $this->calendar_id = $option;
    }

	/**
	 * Get calendar_id option.
	 *
	 * @return string|false
	 */
    public function get_calendar_id() {
        return $this->calendar_id;
    }

	/**
	 * Set user_id option.
	 *
	 * @param int|string|false $option User ID. Use 0 for global, or false to reset context.
	 */
	public function set_user_id( $option ): void {
		// Always preserve the real user_id so inbound sync (availability rules)
		// gets the correct kind=staff / kind_id context.
		$this->user_id = $option;

		$staff_calendar_id = $option ? get_user_meta( $option, 'wc_appointments_gcal_calendar_id', true ) : '';
		$calendar_id       = $staff_calendar_id ?: get_option( 'wc_appointments_gcal_calendar_id' );
		$two_way           = $option ? get_user_meta( $option, 'wc_appointments_gcal_twoway', true ) : '';
		$two_way           = $two_way ?: get_option( 'wc_appointments_gcal_twoway' );

		$this->set_calendar_id( $calendar_id );
		$this->set_twoway( $two_way );
	}

	/**
	 * Get user_id option.
	 *
	 * @return int|string|false
	 */
    public function get_user_id() {
        return $this->user_id;
    }

	/**
	 * Get debug option.
	 */
    public function get_debug(): bool {
        return $this->debug;
    }

	/**
	 * Set twoway option.
	 *
	 * @param string $option Two-way sync option ('one_way' or 'two_way').
	 */
	public function set_twoway( $option ): void {
        $this->twoway = $option;
    }

	/**
	 * Get twoway option.
	 */
    public function get_twoway(): string {
        return $this->twoway;
    }

	/**
	 * Get twoway option.
	 */
    public function is_twoway_enabled(): bool {
		$twoway_enabled = 'two_way' === $this->get_twoway();

		return apply_filters( 'woocommerce_appointments_gcal_sync_twoway_enabled', $twoway_enabled, $this );
    }

	/**
      * Display admin screen notices.
      */
     public function admin_notices(): void {
		// Get current screen.
		$screen          = function_exists( 'get_current_screen' ) ? get_current_screen() : '';
		$screen_id       = $screen ? $screen->id : '';
		$section_raw     = filter_input( INPUT_GET, 'section' );
		$current_section = is_string( $section_raw ) ? sanitize_text_field( wp_unslash( $section_raw ) ) : '';

		// error_log( var_export( $current_section, true ) );

		$allowed_screens = [ 'user-edit', 'woocommerce_page_wc-settings' ];

		$oauth_raw = filter_input( INPUT_GET, 'wc_gcal_oauth' );
		if ( in_array( $screen_id, $allowed_screens, true ) && is_string( $oauth_raw ) ) {
			if ( 'success' === sanitize_text_field( wp_unslash( $oauth_raw ) ) ) {
				echo '<div class="updated fade"><p><strong>' . esc_html__( 'Google Calendar', 'woocommerce-appointments' ) . '</strong> ' . esc_html__( 'Account connected successfully!', 'woocommerce-appointments' ) . '</p></div>';
			} else {
				echo '<div class="error fade"><p><strong>' . esc_html__( 'Google Calendar', 'woocommerce-appointments' ) . '</strong> ' . esc_html__( 'An error occurred. Please try again.', 'woocommerce-appointments' ) . '</p></div>';
			}
		}

		$logout_raw = filter_input( INPUT_GET, 'wc_gcal_logout' );
		if ( in_array( $screen_id, $allowed_screens, true ) && is_string( $logout_raw ) ) {
			if ( 'success' === sanitize_text_field( wp_unslash( $logout_raw ) ) ) {
				echo '<div class="updated fade"><p><strong>' . esc_html__( 'Google Calendar', 'woocommerce-appointments' ) . '</strong> ' . esc_html__( 'Account disconnected successfully!', 'woocommerce-appointments' ) . '</p></div>';
			} else {
				echo '<div class="error fade"><p><strong>' . esc_html__( 'Google Calendar', 'woocommerce-appointments' ) . '</strong> ' . esc_html__( 'An error occurred. Please try again.', 'woocommerce-appointments' ) . '</p></div>';
			}
		}

		// Persistent notice for dropped connections (automatic deauth only, not manual disconnect).
		$this->maybe_show_connection_dropped_notice( $screen_id );

		// Lightweight diagnostics panel (safe, optional).
		$show_status = apply_filters( 'wc_appointments_gcal_show_status_panel', true, $this );
		if ( $show_status && in_array( $screen_id, $allowed_screens, true ) && 'gcal' === $current_section ) {
			$uid         = $this->get_user_id() ? (int) $this->get_user_id() : 0;
			$last_sync   = 0 !== $uid ? get_user_meta( $uid, 'wc_appointments_gcal_last_sync', true ) : get_option( 'wc_appointments_gcal_last_sync' );
			$last_error  = 0 !== $uid ? get_user_meta( $uid, 'wc_appointments_gcal_last_error', true ) : get_option( 'wc_appointments_gcal_last_error' );
			$last_sync_t = (int) ( $last_sync['ts'] ?? 0 );
			$ok          = (bool) ( $last_sync['ok'] ?? false );
			$msg         = (string) ( $last_sync['msg'] ?? '' );

			// Backward-compatibility: older manual sync flow stored a different payload shape.
			if ( is_array( $last_sync ) && 0 === $last_sync_t && isset( $last_sync['timestamp'] ) ) {
				$last_sync_t = absint( $last_sync['timestamp'] );
				$ok          = true;
				if ( '' === $msg && isset( $last_sync['synced_count'] ) ) {
					/* translators: %d: number of events synced */
					$msg = sprintf( __( 'Successfully synced %d event(s) from Google Calendar.', 'woocommerce-appointments' ), absint( $last_sync['synced_count'] ) );
				}
			}

			// Avoid stale "OK" after manual disconnect or missing OAuth credentials.
			$has_refresh_token = 0 !== $uid
				? (bool) get_user_meta( $uid, 'wc_appointments_gcal_refresh_token', true )
				: (bool) get_option( 'wc_appointments_gcal_refresh_token' );
			$is_connected = (bool) $has_refresh_token && $this->is_calendar_set() && '' !== (string) $this->get_client_id() && '' !== (string) $this->get_client_secret();
			
			// Check if staff calendars are active (only for global calendar view).
			$staff_calendars_active = false;
			$staff_count = 0;
			if ( 0 === $uid ) {
				$synced_staff = $this->get_synced_staff_ids();
				$staff_calendars_active = ! empty( $synced_staff );
				$staff_count = is_array( $synced_staff ) ? count( $synced_staff ) : 0;
			}
			
			if ( ! $is_connected ) {
				// Build diagnostic message showing what's missing.
				$missing_parts = [];
				if ( ! $has_refresh_token ) {
					$missing_parts[] = __( 'not authorized', 'woocommerce-appointments' );
				}
				if ( '' === (string) $this->get_client_id() ) {
					$missing_parts[] = __( 'missing Client ID', 'woocommerce-appointments' );
				}
				if ( '' === (string) $this->get_client_secret() ) {
					$missing_parts[] = __( 'missing Client Secret', 'woocommerce-appointments' );
				}
				if ( ! $this->is_calendar_set() ) {
					$missing_parts[] = __( 'calendar not selected', 'woocommerce-appointments' );
				}
				
				// If staff calendars are working, show that instead of error.
				if ( $staff_calendars_active && 0 === $uid ) {
					$ok = true; // Don't show error badge if staff calendars work.
					$msg = sprintf(
						/* translators: 1: number of staff calendars, 2: list of missing items */
						__( 'Global calendar: %2$s. %1$d staff calendar(s) active and syncing.', 'woocommerce-appointments' ),
						$staff_count,
						implode( ', ', $missing_parts )
					);
				} else {
					$ok = false;
					if ( '' === $msg || '0' === $msg ) {
						$msg = ! empty( $missing_parts ) 
							/* translators: %s: list of missing connection parts */
							? sprintf( __( 'Disconnected (%s).', 'woocommerce-appointments' ), implode( ', ', $missing_parts ) )
							: __( 'Disconnected.', 'woocommerce-appointments' );
					}
				}
			}

			// Fresh OAuth return: show OK immediately (avoids stale error from a concurrent sync run).
			if ( is_string( $oauth_raw ) && 'success' === sanitize_text_field( wp_unslash( $oauth_raw ) ) && $is_connected ) {
				$ok         = true;
				$msg        = __( 'Google Calendar account connected successfully.', 'woocommerce-appointments' );
				$last_error = '';
			}

			$when        = 0 !== $last_sync_t ? sprintf( '%s, %s', date_i18n( wc_appointments_date_format(), $last_sync_t ), date_i18n( wc_appointments_time_format(), $last_sync_t ) ) : __( 'never', 'woocommerce-appointments' );

			$status_label = $ok ? esc_html__( 'Last sync', 'woocommerce-appointments' ) : esc_html__( 'Last sync attempt', 'woocommerce-appointments' );

			echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'Google Calendar Connection Status', 'woocommerce-appointments' ) . ':</strong> ';
			if ( $ok ) {
				echo '<span style="color:#0a0;">' . esc_html__( 'OK', 'woocommerce-appointments' ) . '</span>';
			} else {
				echo '<span style="color:#a00;">' . esc_html__( 'Error', 'woocommerce-appointments' ) . '</span>';
			}
			echo ' — ' . esc_html( $status_label ) . ': ' . esc_html( $when );
			if ( '' !== $msg && '0' !== $msg ) {
				echo ' — ' . esc_html( $msg );
			}
			if ( $last_error ) {
				echo '<br/>' . esc_html__( 'Last error:', 'woocommerce-appointments' ) . ' ' . esc_html( wp_strip_all_tags( $last_error ) );
			}
			echo '</p></div>';
		}
	}

	/**
	 * Show a persistent admin notice when a GCal connection was dropped automatically.
	 *
	 * Only fires after handle_deauthorize() (token refresh failures),
	 * never after a manual disconnect via oauth_logout().
	 *
	 * @param string $screen_id Current admin screen ID.
	 */
	protected function maybe_show_connection_dropped_notice( string $screen_id ): void {
		// Screens where the notice should appear.
		$notice_screens = [
			'user-edit',
			'profile',
			'dashboard',
			'woocommerce_page_wc-settings',
			'edit-wc_appointment',
			'wc_appointment',
			'wc_appointment_page_appointment_calendar',
			'wc_appointment_page_add_appointment',
			'wc_appointment_page_wc_appointments_global_availability',
		];

		if ( ! in_array( $screen_id, $notice_screens, true ) ) {
			return;
		}

		$current_user_id = get_current_user_id();
		$notices         = [];

		// 1. Global connection dropped — visible to users who can manage appointments.
		if ( current_user_can( 'manage_appointments' ) ) {
			$global_dropped = get_option( 'wc_appointments_gcal_connection_dropped' );
			if ( $global_dropped ) {
				$settings_url = admin_url( 'admin.php?page=wc-settings&tab=appointments&section=gcal' );
				$notices[]    = sprintf(
					/* translators: %1$s opening link tag, %2$s closing link tag */
					__( 'The global Google Calendar connection was lost due to repeated authentication failures. Appointments are not being synced. Please %1$sreconnect your Google account%2$s.', 'woocommerce-appointments' ),
					'<a href="' . esc_url( $settings_url ) . '">',
					'</a>'
				);
			}
		}

		// 2. Staff connection dropped — visible to the affected staff member themselves.
		if ( $current_user_id && get_user_meta( $current_user_id, 'wc_appointments_gcal_connection_dropped', true ) ) {
			$profile_url = admin_url( 'profile.php' );
			$notices[]   = sprintf(
				/* translators: %1$s opening link tag, %2$s closing link tag */
				__( 'Your Google Calendar connection was lost due to repeated authentication failures. Your appointments are not being synced. Please %1$sreconnect your Google account%2$s from your profile.', 'woocommerce-appointments' ),
				'<a href="' . esc_url( $profile_url ) . '">',
				'</a>'
			);
		}

		// 3. Admin viewing another staff member's profile — show if that staff member's connection dropped.
		$user_id_raw = filter_input( INPUT_GET, 'user_id' );
		if ( current_user_can( 'manage_appointments' ) && 'user-edit' === $screen_id && is_string( $user_id_raw ) ) {
			$edited_user_id = absint( wp_unslash( $user_id_raw ) );
			if ( $edited_user_id && $edited_user_id !== $current_user_id && get_user_meta( $edited_user_id, 'wc_appointments_gcal_connection_dropped', true ) ) {
				$user_data = get_userdata( $edited_user_id );
				$name      = $user_data ? $user_data->display_name : '#' . $edited_user_id;
				$notices[] = sprintf(
					/* translators: %s staff member display name */
					__( 'The Google Calendar connection for %s was lost due to repeated authentication failures. Please reconnect their Google account below.', 'woocommerce-appointments' ),
					'<strong>' . esc_html( $name ) . '</strong>'
				);
			}
		}

		// 4. Admin on appointment screens — summarise any staff with dropped connections.
		if ( current_user_can( 'manage_appointments' ) && 'user-edit' !== $screen_id && 'profile' !== $screen_id ) {
			$dropped_staff = get_users( [
				'meta_key'     => 'wc_appointments_gcal_connection_dropped',
				'meta_compare' => 'EXISTS',
				'fields'       => [ 'ID', 'display_name' ],
				'number'       => 10,
			] );

			if ( $dropped_staff ) {
				$names = [];
				foreach ( $dropped_staff as $staff ) {
					// Skip current user — they already see their own personal notice (#2).
					if ( (int) $staff->ID === $current_user_id ) {
						continue;
					}
					$edit_url = admin_url( 'user-edit.php?user_id=' . $staff->ID );
					$names[]  = '<a href="' . esc_url( $edit_url ) . '">' . esc_html( $staff->display_name ) . '</a>';
				}
				if ( $names ) {
					$notices[] = sprintf(
						/* translators: %s comma-separated list of staff names with links */
						__( 'Google Calendar connection was lost for the following staff: %s. Their appointments are not being synced until they reconnect.', 'woocommerce-appointments' ),
						implode( ', ', $names )
					);
				}
			}
		}

		// De-duplicate and render.
		$notices = array_unique( $notices );
		foreach ( $notices as $notice ) {
			echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Google Calendar', 'woocommerce-appointments' ) . '</strong> — ' . wp_kses( $notice, [ 'a' => [ 'href' => [] ], 'strong' => [] ] ) . '</p></div>';
		}
	}

	/**
	 * Get Access Token.
	 *
	 * @param  string $code Authorization code.
	 * @param  string|int $user_id
	 *
	 * @return string|false Access token or false on failure.
	 */
	public function get_access_token( $code = '', $user_id = '' ) {
		$user_id = $user_id ?: '';
		$user_id = $this->get_user_id() ?: $user_id;

		// Check roles if user is shop staff.
		if ( $user_id ) {
			$user_meta = get_userdata( $user_id );
			if ( isset( $user_meta->roles ) && ! in_array( 'shop_staff', (array) $user_meta->roles, true ) ) {
				$this->log_debug(
					'token_role_rejected',
					sprintf( 'User #%d lacks shop_staff role (has: %s). Token request rejected.', $user_id, implode( ', ', (array) $user_meta->roles ) )
				);
				return false;
			}
		}

		// Instance cache key (string for consistent array key).
		$cache_key = (string) ( $user_id ?: 'global' );

		// Load refresh token before any cached access token (disconnect must not look connected).
		$refresh_token = $this->get_refresh_token( $user_id );

		if ( ! $code && ! $refresh_token ) {
			$this->clear_gcal_access_cache( $user_id );
			return false;
		}

		// Return from instance cache if already resolved this request (Fix 6).
		if ( ! $code && isset( $this->access_token_cache[ $cache_key ] ) ) {
			return $this->access_token_cache[ $cache_key ];
		}

		// Load cached access token from transient.
		$access_token = $user_id ? get_transient( 'wc_appointments_gcal_access_token_' . $user_id ) : get_transient( 'wc_appointments_gcal_access_token' );

		// Fallback: if transient was evicted (object cache flush/pressure), check durable option (Fix 4).
		if ( ! $access_token && ! $code ) {
			$durable = $this->get_durable_access_token( $user_id );
			if ( $durable && ! empty( $durable['token'] ) && time() < (int) $durable['expires'] ) {
				$access_token = $durable['token'];
				// Re-populate transient from durable store.
				$ttl = max( 60, (int) $durable['expires'] - time() );
				if ( $user_id ) {
					set_transient( 'wc_appointments_gcal_access_token_' . $user_id, $access_token, $ttl );
				} else {
					set_transient( 'wc_appointments_gcal_access_token', $access_token, $ttl );
				}
			}
		}

		// If we have a valid cached token and no new code, reuse.
		if ( $access_token && ! $code ) {
			$this->access_token_cache[ $cache_key ] = $access_token;
			return $access_token;
		}

		// Exchange authorization code for tokens.
		if ( $code ) {
			$data = [
				'code'          => $code,
				'client_id'     => $this->get_client_id(),
				'client_secret' => $this->get_client_secret(),
				'redirect_uri'  => $this->get_redirect_uri(),
				'grant_type'    => 'authorization_code',
				'access_type'   => 'offline',
			];

			$response = wp_remote_post(
			    $this->token_uri,
			    [
					'body'    => http_build_query( $data ),
					'timeout' => 20,
				],
			);

			if ( is_wp_error( $response ) ) {
				$this->log_error( 'token_exchange_error', $response->get_error_message() );
				return false;
			}

			$code_http = (int) wp_remote_retrieve_response_code( $response );
			$payload   = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( 200 !== $code_http || empty( $payload['access_token'] ) ) {
				$reason = $payload['error'] ?? 'unknown';
				$this->log_error( 'token_exchange_http_' . $code_http, $reason );
				return false;
			}

			$access_token  = $payload['access_token'];
			$expires_in    = (int) ( $payload['expires_in'] ?? self::TOKEN_TRANSIENT_TIME );
			$got_new_rt    = isset( $payload['refresh_token'] ) && $payload['refresh_token'];
			$refresh_token = $got_new_rt ? $payload['refresh_token'] : $refresh_token;

			// Diagnostic: log whether Google returned a refresh_token.
			// With prompt=consent + access_type=offline this should always be present.
			if ( ! $got_new_rt ) {
				$this->log_error(
					'token_exchange_no_refresh_token',
					sprintf(
						'Google did not return a refresh_token during code exchange (user: %s). '
						. 'Existing refresh_token %s. Ensure the authorization URL includes prompt=consent and access_type=offline.',
						$user_id ?: 'global',
						$refresh_token ? 'will be reused' : 'is also missing — connection will fail after access token expires'
					)
				);
			} else {
				$this->log_debug( 'token_exchange_ok', sprintf( 'Code exchange successful for %s, refresh_token received.', $user_id ? 'staff #' . $user_id : 'global' ) );
			}

			// Cache access token slightly before expiry.
			$ttl = max( 60, $expires_in - 60 );
			$this->store_access_token( $user_id, $access_token, $ttl );
			if ( $refresh_token ) {
				if ( $user_id ) {
					$saved = $this->save_refresh_token( $user_id, $refresh_token );
					if ( ! $saved ) {
						$this->log_error( 'token_exchange_save_failed', sprintf( 'update_user_meta returned false for staff #%s refresh_token.', $user_id ) );
					}
				} else {
					$this->save_refresh_token( '', $refresh_token );
				}
			}

			// Clear any connection-dropped flag — user has successfully reconnected.
			if ( $user_id ) {
				delete_user_meta( $user_id, 'wc_appointments_gcal_connection_dropped' );
			} else {
				delete_option( 'wc_appointments_gcal_connection_dropped' );
			}

			$this->access_token_cache[ $cache_key ] = $access_token;
			return $access_token;
		}

		// Refresh access token using refresh_token.
		if ( $refresh_token ) {
			// Non-blocking lock: prevent concurrent stampede but never block the caller.
			$lock_key     = 'wc_appointments_gcal_refresh_lock' . ( $user_id ? '_' . (int) $user_id : '' );
			$lock_timeout = 30; // seconds
			$got_lock     = $this->acquire_refresh_lock( $lock_key, $lock_timeout );

			if ( ! $got_lock ) {
				// Another process may be refreshing — check if a fresh token appeared.
				$access_token = $user_id ? get_transient( 'wc_appointments_gcal_access_token_' . $user_id ) : get_transient( 'wc_appointments_gcal_access_token' );
				if ( $access_token ) {
					$this->access_token_cache[ $cache_key ] = $access_token;
					return $access_token;
				}
				// No fresh token yet — proceed without lock (worst case: duplicate refresh, harmless).
			}

			$data = [
				'client_id'     => $this->get_client_id(),
				'client_secret' => $this->get_client_secret(),
				'refresh_token' => $refresh_token,
				'grant_type'    => 'refresh_token',
				'access_type'   => 'offline',
			];

			$response = wp_remote_post(
			    $this->token_uri,
			    [
					'body'    => http_build_query( $data ),
					'timeout' => 20,
				],
			);

			if ( is_wp_error( $response ) ) {
				if ( $got_lock ) {
					$this->release_refresh_lock( $lock_key );
				}
				$this->log_error( 'token_refresh_error', $response->get_error_message() );
				return false;
			}

			$code_http = (int) wp_remote_retrieve_response_code( $response );
			$payload   = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( 200 !== $code_http || empty( $payload['access_token'] ) ) {
				if ( $got_lock ) {
					$this->release_refresh_lock( $lock_key );
				}
				$reason = $payload['error'] ?? 'unknown';
				// Only deauthorize after multiple consecutive invalid_grant failures
				// to avoid disconnecting on transient Google-side errors.
				if ( in_array( $reason, [ 'invalid_grant', 'unauthorized_client' ], true ) ) {
					$strikes = $this->increment_auth_strikes( $user_id );
					$max     = (int) apply_filters( 'wc_appointments_gcal_max_auth_strikes', 5, $this );
					if ( $strikes >= $max ) {
						// Safety: only deauthorize if failures span a minimum time window.
						// This prevents plugin updates or transient API outages from
						// permanently disconnecting existing working connections.
						$strike_key  = $user_id ? 'wc_appointments_gcal_auth_strikes_' . (int) $user_id : 'wc_appointments_gcal_auth_strikes';
						$strike_data = get_option( $strike_key );
						$min_window  = (int) apply_filters( 'wc_appointments_gcal_deauth_min_window', 6 * HOUR_IN_SECONDS, $this );
						$first_fail  = is_array( $strike_data ) && ! empty( $strike_data['first'] ) ? (int) $strike_data['first'] : time();

						if ( ( time() - $first_fail ) >= $min_window ) {
							$this->handle_deauthorize( $user_id );
							$this->log_error( 'token_refresh_deauthorized', sprintf( 'Deauthorized after %d consecutive %s failures spanning %d hours.', $strikes, $reason, round( ( time() - $first_fail ) / 3600, 1 ) ) );
						} else {
							$this->log_error( 'token_refresh_strike', sprintf( 'Strike %d/%d for %s (user: %s). Deauth deferred — failures must span at least %d hours.', $strikes, $max, $reason, $user_id ?: 'global', $min_window / 3600 ) );
						}
					} else {
						$this->log_error( 'token_refresh_strike', sprintf( 'Strike %d/%d for %s (user: %s).', $strikes, $max, $reason, $user_id ?: 'global' ) );
					}
				}
				$this->log_error( 'token_refresh_http_' . $code_http, $reason );
				return false;
			}

			$access_token = $payload['access_token'];
			$expires_in   = (int) ( $payload['expires_in'] ?? self::TOKEN_TRANSIENT_TIME );
			$ttl          = max( 60, $expires_in - 60 );

			$this->store_access_token( $user_id, $access_token, $ttl );

			// Persist rotated refresh token if Google issued a new one.
			if ( ! empty( $payload['refresh_token'] ) && $payload['refresh_token'] !== $refresh_token ) {
				$this->save_refresh_token( $user_id, (string) $payload['refresh_token'] );
			}

			if ( $got_lock ) {
				$this->release_refresh_lock( $lock_key );
			}

			// Successful refresh — clear any accumulated auth strikes.
			$this->reset_auth_strikes( $user_id );

			$this->access_token_cache[ $cache_key ] = $access_token;
			return $access_token;
		}

		return false;
	}

	/**
	 * Proactively refresh Google Calendar access tokens for global and all staff with a stored refresh token.
	 * Called by the scheduled cron so tokens are renewed before they expire when no sync or admin request runs.
	 *
	 * @return void
	 */
	public function refresh_all_gcal_tokens(): void {
		$this->access_token_cache = [];

		// Save current instance context to restore after refresh loop.
		$original_user_id = $this->user_id;

		// Refresh global token if a refresh token is stored.
		$this->set_user_id( false ); // Reset to global context.
		if ( get_option( 'wc_appointments_gcal_refresh_token' ) ) {
			$result = $this->get_access_token( '', '' );
			if ( false === $result ) {
				$this->log_error( 'cron_refresh_global_failed', 'Failed to refresh global token during scheduled refresh' );
			}
		}

		// Refresh tokens for all staff users who have connected GCal (have a refresh token).
		$staff_with_gcal = get_users(
			[
				'role'         => 'shop_staff',
				'meta_key'     => 'wc_appointments_gcal_refresh_token',
				'meta_value'   => '',
				'meta_compare' => '!=',
				'fields'       => 'ID',
			]
		);

		if ( is_array( $staff_with_gcal ) ) {
			foreach ( $staff_with_gcal as $user_id ) {
				$id = (int) ( is_object( $user_id ) ? ( $user_id->ID ?? 0 ) : $user_id );
				if ( $id > 0 ) {
					// Set instance context to this staff member before refresh.
					$this->set_user_id( $id );
					$result = $this->get_access_token( '', $id );
					if ( false === $result ) {
						$this->log_error( 'cron_refresh_staff_failed', sprintf( 'Failed to refresh token for staff ID %d during scheduled refresh', $id ) );
					}
				}
			}
		}

		// Restore original instance context.
		$this->set_user_id( $original_user_id );
	}

	/**
	 * Store access token in both transient (fast) and wp_options (durable fallback).
	 *
	 * @param int|string $user_id User ID or empty for global.
	 * @param string     $token   Access token.
	 * @param int        $ttl     Time to live in seconds.
	 */
	private function store_access_token( $user_id, string $token, int $ttl ): void {
		$durable_value = [
			'token'   => $token,
			'expires' => time() + $ttl,
		];

		if ( $user_id ) {
			set_transient( 'wc_appointments_gcal_access_token_' . $user_id, $token, $ttl );
			update_user_meta( $user_id, '_wc_appointments_gcal_access_token_durable', $durable_value );
		} else {
			set_transient( 'wc_appointments_gcal_access_token', $token, $ttl );
			update_option( '_wc_appointments_gcal_access_token_durable', $durable_value, false );
		}
	}

	/**
	 * Get durable access token fallback from wp_options/user_meta.
	 *
	 * @param int|string $user_id User ID or empty for global.
	 * @return array{token:string,expires:int}|false
	 */
	private function get_durable_access_token( $user_id ) {
		if ( $user_id ) {
			$value = get_user_meta( $user_id, '_wc_appointments_gcal_access_token_durable', true );
		} else {
			$value = get_option( '_wc_appointments_gcal_access_token_durable' );
		}
		if ( is_array( $value ) && ! empty( $value['token'] ) && ! empty( $value['expires'] ) ) {
			return $value;
		}
		return false;
	}

	/**
	 * Drop cached access tokens for global or staff context.
	 *
	 * @param int|string $user_id Staff user ID, or empty for global.
	 */
	private function clear_gcal_access_cache( $user_id = '' ): void {
		unset( $this->access_token_cache[ (string) ( $user_id ?: 'global' ) ] );
		if ( $user_id ) {
			delete_transient( 'wc_appointments_gcal_access_token_' . absint( $user_id ) );
			delete_user_meta( absint( $user_id ), '_wc_appointments_gcal_access_token_durable' );
			return;
		}
		delete_transient( 'wc_appointments_gcal_access_token' );
		delete_option( '_wc_appointments_gcal_access_token_durable' );
	}

	/**
	 * Acquire a refresh lock using wp_options to prevent concurrent token refreshes.
	 * Uses INSERT ... ON DUPLICATE KEY to be atomic across concurrent PHP processes.
	 *
	 * @param string $lock_key     Unique lock identifier.
	 * @param int    $lock_timeout Lock TTL in seconds.
	 * @return bool True if lock acquired, false if another process holds it.
	 */
	private function acquire_refresh_lock( string $lock_key, int $lock_timeout ): bool {
		global $wpdb;

		$now     = time();
		$expires = $now + $lock_timeout;

		// Try to create the lock row. If it already exists, check expiry.
		$existing = get_option( $lock_key );
		if ( false !== $existing && (int) $existing > $now ) {
			// Lock is held and not expired.
			return false;
		}

		// Attempt atomic update: only succeed if the value is still what we read.
		if ( false === $existing ) {
			// Row doesn't exist — add it.
			$added = add_option( $lock_key, (string) $expires, '', false );
			return (bool) $added;
		}

		// Row exists but expired — update atomically.
		$updated = $wpdb->update(
			$wpdb->options,
			[ 'option_value' => (string) $expires ],
			[
				'option_name'  => $lock_key,
				'option_value' => (string) $existing,
			],
		);

		// Clear options cache for this key so subsequent reads are fresh.
		wp_cache_delete( $lock_key, 'options' );

		return $updated > 0;
	}

	/**
	 * Release a refresh lock.
	 *
	 * @param string $lock_key Unique lock identifier.
	 */
	private function release_refresh_lock( string $lock_key ): void {
		delete_option( $lock_key );
	}

	/**
	 * Locking wrapper around sync to avoid overlapping runs and to expose a forward-only window.
	 * Delegates to existing sync_from_gcal() to preserve behavior.
	 */
	public function sync_from_gcal_locked(): void {
		$enabled = apply_filters( 'wc_appointments_gcal_locking_enabled', true, $this );
		if ( ! $enabled ) {
			$this->sync_from_gcal();
			return;
		}

		if ( ! $this->acquire_sync_lock() ) {
			$this->log_debug( 'sync_skipped_locked', 'Another sync is in progress for this calendar.' );
			return;
		}

		try {
			// Expose the forward-only window to internal calls if needed.
			$this->current_sync_window = $this->get_forward_sync_window();
			$this->sync_from_gcal();
		} catch ( \Throwable $e ) {
			// Defensive: some upstream code paths embed a raw JSON response in the exception message.
			// If the exception message is a valid Google Calendar response (contains 'items' array), treat it as non-fatal
			// to avoid breaking sync on benign/informational payloads like empty incremental updates.
			$msg = trim( $e->getMessage() );
			$decoded = json_decode( $msg, true );

			if ( is_array( $decoded ) && array_key_exists( 'items', $decoded ) ) {
				// Valid Google response structure detected in exception message - treat as non-fatal.
				// Log at debug level and record a successful (but informational) sync status.
				$event_count = is_array( $decoded['items'] ) ? count( $decoded['items'] ) : 0;
				$this->log_debug( 'sync_handled_json_exception', sprintf( 'Handled Google Calendar response in exception message (%d event(s)).', $event_count ) );
				/* translators: %d event count */
				$this->mark_last_sync_status( true, sprintf( __( 'Processed %d event(s) from exception payload.', 'woocommerce-appointments' ), $event_count ) );
			} else {
				// Not a valid Google response structure — rethrow.
				throw $e;
			}
		} finally {
			$this->current_sync_window = null;
			$this->release_sync_lock();
		}
	}

	/**
	 * Forward-only sync window [now, horizon] based on availability cache horizon.
	 *
	 * @return array{start:int,end:int}
	 */
	protected function get_forward_sync_window(): array {
		$start = (int) current_time( 'timestamp' );
		$end   = $this->get_cache_horizon_ts();

		$start = apply_filters( 'wc_appointments_gcal_forward_window_start', $start, $this );
		$end   = apply_filters( 'wc_appointments_gcal_forward_window_end', $end, $this );

		return [ 'start' => $start, 'end' => $end ];
	}

	/**
	 * @param bool $enabled Admin manual re-sync only.
	 */
	public function set_manual_full_resync( bool $enabled ): void {
		$this->manual_full_resync = $enabled;
	}

	/**
     * Compute availability horizon timestamp without calling private methods on other classes.
     */
    protected function get_cache_horizon_ts(): int {
		// Use the configurable horizon from admin settings.
		if ( function_exists( 'wc_appointments_get_cache_horizon_months' ) ) {
			$months = wc_appointments_get_cache_horizon_months();
			return (int) strtotime( '+' . $months . ' months UTC' );
		}
		// Fallback to 3 months if helper function is not available.
		return strtotime( '+3 months UTC' );
	}

	/**
	 * Acquire a transient lock per calendar/user to avoid overlapping syncs.
	 *
	 * @return bool
	 */
	protected function acquire_sync_lock(): bool {
		$key = $this->get_sync_lock_key();
		if ( get_transient( $key ) ) {
			return false;
		}
		$ttl = (int) apply_filters( 'wc_appointments_gcal_lock_ttl', 60, $this ); // seconds
		return (bool) set_transient( $key, 1, $ttl );
	}

	/**
	 * Release sync lock.
	 */
	protected function release_sync_lock(): void {
		delete_transient( $this->get_sync_lock_key() );
	}

	/**
     * Build per-calendar/user sync lock key.
     */
    protected function get_sync_lock_key(): string {
		$uid = $this->get_user_id() ? (int) $this->get_user_id() : 0;
		$cid = sanitize_key( (string) $this->get_calendar_id() );
		return 'wc_appointments_gcal_lock_' . md5( $uid . '|' . $cid );
	}

	/**
	 * Acquire a short-lived lock for this calendar/user to avoid overlapping syncs.
	 *
	 * @param string $key Lock key.
	 */
	protected function acquire_lock( $key ): bool {
		$ttl = (int) apply_filters( 'wc_appointments_gcal_lock_ttl', 60, $this ); // seconds
		if ( get_transient( $key ) ) {
			return false;
		}
		// Minimize race: set if not exists.
		return set_transient( $key, 1, $ttl );
	}

	/**
	 * Release lock.
	 *
	 * @param string $key Lock key.
	 */
	protected function release_lock( $key ): void {
		delete_transient( $key );
	}

	/**
	 * Build lock key per calendar/user context.
	 */
	protected function get_calendar_lock_key(): string {
		$uid = $this->get_user_id() ? (int) $this->get_user_id() : 0;
		$cid = sanitize_key( (string) $this->get_calendar_id() );
		return 'wc_appointments_gcal_lock_' . md5( $uid . '|' . $cid );
	}

	/**
	 * Handle deauthorization: clear tokens safely.
	 *
	 * @param int|string $user_id
	 */
	protected function handle_deauthorize( $user_id = '' ): void {
		if ( $user_id ) {
			delete_transient( 'wc_appointments_gcal_access_token_' . $user_id );
			delete_user_meta( $user_id, 'wc_appointments_gcal_refresh_token' );
			delete_user_meta( $user_id, '_wc_appointments_gcal_access_token_durable' );
			// Preserve calendar_id and twoway so re-auth restores the connection
			// without the staff member having to reconfigure their settings (Fix 5).

			// Flag the connection as dropped so an admin notice prompts reconnection.
			// Not set during manual disconnect (oauth_logout) — only on automatic deauth.
			update_user_meta( $user_id, 'wc_appointments_gcal_connection_dropped', time() );
		} else {
			delete_transient( 'wc_appointments_gcal_access_token' );
			delete_option( 'wc_appointments_gcal_refresh_token' );
			delete_option( '_wc_appointments_gcal_access_token_durable' );

			// Flag the global connection as dropped.
			update_option( 'wc_appointments_gcal_connection_dropped', time(), false );
		}
		// Clear instance cache.
		$cache_key = (string) ( $user_id ?: 'global' );
		unset( $this->access_token_cache[ $cache_key ] );
		// Clear strike counter on full deauthorize.
		$this->reset_auth_strikes( $user_id );
	}

	/**
	 * Increment consecutive auth failure strikes for a user/global context.
	 *
	 * Uses wp_options with a cooldown window so concurrent requests within
	 * the same burst (e.g. 30 seconds) only count as a single strike (Fix 2).
	 * Strikes auto-expire after 24 hours.
	 *
	 * @param int|string $user_id User ID or empty for global.
	 * @return int New strike count.
	 */
	protected function increment_auth_strikes( $user_id = '' ): int {
		$key      = $user_id ? 'wc_appointments_gcal_auth_strikes_' . (int) $user_id : 'wc_appointments_gcal_auth_strikes';
		$now      = time();
		$cooldown = 30; // seconds — concurrent failures within this window count as one strike.
		$expiry   = DAY_IN_SECONDS;

		$data = get_option( $key );
		if ( ! is_array( $data ) || empty( $data['count'] ) || empty( $data['time'] ) ) {
			$data = [ 'count' => 0, 'time' => 0, 'first' => $now ];
		}

		// Auto-expire: if first strike was > 24 hours ago, reset.
		if ( ( $now - (int) $data['first'] ) > $expiry ) {
			$data = [ 'count' => 0, 'time' => 0, 'first' => $now ];
		}

		// Cooldown: if last strike was within the cooldown window, don't increment.
		if ( ( $now - (int) $data['time'] ) < $cooldown ) {
			return (int) $data['count'];
		}

		$data['count'] = (int) $data['count'] + 1;
		$data['time']  = $now;
		if ( 1 === $data['count'] ) {
			$data['first'] = $now;
		}

		update_option( $key, $data, false );

		return (int) $data['count'];
	}

	/**
	 * Reset consecutive auth failure strikes (e.g. after successful token refresh).
	 *
	 * @param int|string $user_id User ID or empty for global.
	 */
	protected function reset_auth_strikes( $user_id = '' ): void {
		$key = $user_id ? 'wc_appointments_gcal_auth_strikes_' . (int) $user_id : 'wc_appointments_gcal_auth_strikes';
		delete_option( $key );
	}

	/**
	 * Persist incremental sync token.
	 *
	 * @param string     $sync_token
	 * @param int|string $user_id
	 */
	protected function set_sync_token( $sync_token, $user_id = '' ): void {
		$key = $user_id ? 'wc_appointments_gcal_sync_token_' . (int) $user_id : 'wc_appointments_gcal_sync_token';
		update_option( $key, (string) $sync_token, false );
	}

	/**
     * Retrieve incremental sync token.
     *
     * @param int|string $user_id
     */
    protected function get_sync_token( $user_id = '' ): string {
		$key = $user_id ? 'wc_appointments_gcal_sync_token_' . (int) $user_id : 'wc_appointments_gcal_sync_token';
		return (string) get_option( $key, '' );
	}

	/**
     * Fetch events using incremental syncToken when available, falling back to a forward-only window.
     * Handles pagination and 410 invalid token recovery.
     *
     * @param string $access_token Access token.
     * @param array{start: int, end: int} $window UTC timestamps
     * @param string $sync_token  Existing syncToken or empty string
     * @return array{events: list<array<string, mixed>>, nextSyncToken: string}
     */
    protected function fetch_events_delta_or_window( string $access_token, array $window, $sync_token = '' ): array {
		$base_url = 'https://www.googleapis.com/calendar/v3/calendars/' . rawurlencode( $this->get_calendar_id() ) . '/events';

		$enable_delta = (bool) apply_filters( 'wc_appointments_gcal_incremental_sync_enabled', true, $this );

		// Build minimal parameter set based on whether we're using incremental sync or a forward-only window.
		if ( $enable_delta && $sync_token ) {
			// Incremental sync: Use syncToken + maxResults + showDeleted.
			// Do NOT include singleEvents/orderBy as these can trigger 400 Bad Request with syncToken.
			// showDeleted is important to capture cancelled events so we can delete corresponding availability rules.
			$params = [
				'syncToken'   => $sync_token,
				'maxResults'  => (int) apply_filters( 'wc_appointments_gcal_max_results', 200, $this ),
				'showDeleted' => 'true',
			];
		} else {
			// Forward-only window: Use timeMin/timeMax without singleEvents to get recurring events as RRULE.
			// Use 'Z' suffix for UTC timestamps (Google prefers this over +00:00 offset).
			// singleEvents=false means recurring events are returned as a single event with recurrence rules
			// For manual re-sync, window['start'] may be null to get all events (including old recurring ones).
			$params = [
				'maxResults'   => (int) apply_filters( 'wc_appointments_gcal_max_results', 200, $this ),
				'singleEvents' => 'false',
				'showDeleted'  => 'true',
				'timeMax'      => gmdate( 'Y-m-d\TH:i:s\Z', $window['end'] ),
			];
			
			// Only add timeMin if start is specified (not null).
			// When start is null, we get all events including old recurring events with future occurrences.
			if ( null !== ( $window['start'] ?? null ) ) {
				$params['timeMin'] = gmdate( 'Y-m-d\TH:i:s\Z', $window['start'] );
			}
		}

		$headers = [
			'Authorization' => 'Bearer ' . $access_token,
		];

		$events     = [];
		$page_token = '';
		$next_sync  = '';

		$max_pages = (int) apply_filters( 'wc_appointments_gcal_max_pages_per_run', 10, $this );

		for ( $i = 0; $i < $max_pages; $i++ ) {
			$query = $params;
			if ( '' !== $page_token && '0' !== $page_token ) {
				$query['pageToken'] = $page_token;
			}
			$url = add_query_arg( $query, $base_url );

			$this->log_debug( 'events_fetch_request', 'Fetching events from: ' . $url );

			$response = wp_remote_get(
			    $url,
			    [
					'headers' => $headers,
					'timeout' => 20,
				],
			);

			if ( is_wp_error( $response ) ) {
				$this->log_error( 'events_fetch_error', $response->get_error_message() );
				break;
			}

			$http_code = (int) wp_remote_retrieve_response_code( $response );
			$body      = wp_remote_retrieve_body( $response );

			// Handle invalid sync token (410 Gone): clear token and return so caller can retry with window.
			if ( 410 === $http_code ) {
				$this->log_debug( 'events_fetch_410', 'Sync token invalid, clearing and falling back to forward-only window.' );
				$this->set_sync_token( '', $this->get_user_id() ? (int) $this->get_user_id() : '' );
				return [ 'events' => [], 'nextSyncToken' => '' ];
			}

			// Handle 400 Bad Request specially: Google may return 400 when a supplied syncToken is malformed/stale,
			// or other badRequest conditions. Inspect the body and treat known Google errors as recoverable.
			if ( 400 === $http_code ) {
				$decoded = json_decode( $body, true );

				// If this looks like a Google API error payload, handle gracefully.
				if ( is_array( $decoded ) && isset( $decoded['error']['errors'][0]['reason'] ) ) {
					$reason = (string) ( $decoded['error']['errors'][0]['reason'] ?? '' );

					// When using a syncToken, treat 400/badRequest like an invalid token: clear stored token and retry with window.
					if ( $sync_token ) {
						$this->log_debug( 'events_fetch_400_sync_token', sprintf( 'Received 400 (%s) with syncToken, clearing token and falling back to forward-only window.', $reason ) );
						$this->set_sync_token( '', $this->get_user_id() ? (int) $this->get_user_id() : '' );
						return [ 'events' => [], 'nextSyncToken' => '' ];
					}

					// Without a syncToken, this is likely a Google-side badRequest (e.g. invalid parameters).
					// Log at debug level and return empty so caller can continue without throwing.
					$this->log_debug( 'events_fetch_400', 'Google Calendar returned 400 Bad Request: ' . substr( $body, 0, 1000 ) );
					return [ 'events' => [], 'nextSyncToken' => '' ];
				}

				// Non-JSON or unexpected body - fallback to error logging below.
			}

			// Any other non-200 responses are considered errors.
			// Some API clients return 400 Bad Request when the supplied syncToken is malformed/stale.
			// Treat 400 while using a syncToken as an invalid-token case so the caller can retry with a forward-only window.
			if ( 400 === $http_code && $sync_token ) {
				$this->log_debug( 'events_fetch_400_sync_token', 'Received 400 Bad Request when using syncToken; clearing token and falling back to forward-only window.' );
				$this->set_sync_token( '', $this->get_user_id() ? (int) $this->get_user_id() : '' );
				return [ 'events' => [], 'nextSyncToken' => '' ];
			}

			if ( 404 === $http_code ) {
				$this->log_error( 'events_fetch_http_404', substr( $body, 0, 200 ) );
				$this->set_sync_token( '', $this->get_user_id() ? (int) $this->get_user_id() : '' );
				$this->mark_last_sync_status(
					false,
					__( 'Google Calendar not found for the stored calendar ID. Disconnect, reconnect, and re-select the calendar.', 'woocommerce-appointments' )
				);
				return [ 'events' => [], 'nextSyncToken' => '' ];
			}

			if ( 200 !== $http_code ) {
				$this->log_error( 'events_fetch_http_' . $http_code, substr( $body, 0, 200 ) );
				break;
			}

			$payload = json_decode( $body, true );
			if ( ! is_array( $payload ) ) {
				$this->log_error( 'events_fetch_decode', 'Invalid JSON response.' );
				break;
			}

			if ( ! empty( $payload['items'] ) && is_array( $payload['items'] ) ) {
				$events = array_merge( $events, $payload['items'] );
			}

			$page_token = (string) ( $payload['nextPageToken'] ?? '' );
			$next_sync  = (string) ( $payload['nextSyncToken'] ?? $next_sync );

			if ( '' === $page_token || '0' === $page_token ) {
				break;
			}
		}

		return [ 'events' => $events, 'nextSyncToken' => $next_sync ];
	}

	/**
     * Minimal debug logger honoring plugin debug setting.
     *
     * Log messages and Google API response payloads must stay in English — do not wrap in __().
     */
    protected function log_debug( string $handle, string $message ): void {
		if ( ! $this->get_debug() || ! $this->is_log_enabled( $handle ) ) {
			return;
		}

		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug( '[' . $handle . '] ' . $message, [ 'source' => $this->id ] );
		}
	}

	/**
	 * Serialize debug context for log messages without var_export().
	 *
	 * @param mixed $value Value to stringify.
	 * @return string
	 */
	protected function format_debug_value( $value ): string {
		if ( is_wp_error( $value ) ) {
			return $value->get_error_message();
		}

		if ( is_scalar( $value ) || null === $value ) {
			return (string) $value;
		}

		$encoded = wp_json_encode( $value );
		return is_string( $encoded ) ? $encoded : '';
	}

	/**
	 * Minimal error logger honoring plugin debug setting.
	 *
	 * Log messages and Google API response payloads must stay in English — do not wrap in __().
	 *
	 * @param string $handle  Log handle.
	 * @param string $message Log message.
	 */
	protected function log_error( string $handle, string $message ): void {
		if ( ! $this->get_debug() || ! $this->is_log_enabled( $handle ) ) {
			return;
		}

		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->error( '[' . $handle . '] ' . $message, [ 'source' => $this->id ] );
		}
	}

	/**
	 * Normalize all-day appointment timestamp to a calendar date for Google Calendar.
	 *
	 * Handles both storage shapes safely:
	 * 1) Site-local instant timestamps (normal path) -> derive date in site timezone.
	 * 2) UTC-midnight day tokens (legacy/semantic path) on negative offsets ->
	 *    keep the UTC date token to avoid shifting one day earlier.
	 *
	 * @param int    $timestamp Unix timestamp.
	 * @param string $timezone  Site timezone string.
	 * @return string Y-m-d date string for Google all-day payload.
	 */
	protected function get_gcal_all_day_date( int $timestamp, string $timezone ): string {
		$site_tz          = new DateTimeZone( $timezone );
		$is_utc_midnight  = '00:00:00' === gmdate( 'H:i:s', $timestamp );
		$is_site_midnight = '00:00:00' === wp_date( 'H:i:s', $timestamp, $site_tz );

		// Semantic day token: UTC midnight but not site-midnight.
		if ( $is_utc_midnight && ! $is_site_midnight ) {
			return gmdate( 'Y-m-d', $timestamp );
		}

		return wp_date( 'Y-m-d', $timestamp, $site_tz );
	}

	/**
	 * Check if logging is enabled for a specific handle.
	 *
	 * @param string $handle Log handle.
	 * @return bool
	 */
	protected function is_log_enabled( string $handle ): bool {
		$detailed_handles = [
			'sync_event_',
			'sync_event_summary',
			'sync_event_all_day_push',
			'sync_from_gcal_fetch_result',
			'events_fetch_request',
			'appointment_detected_fallback',
			'availability_rule_confirmed',
			'appointment_skipped',
			'appointment_skipped_update',
			'invalid_date_format',
			'token_refresh_strike',
		];

		$is_detailed = false;
		foreach ( $detailed_handles as $detailed_handle ) {
			if ( 0 === strpos( $handle, $detailed_handle ) ) {
				$is_detailed = true;
				break;
			}
		}

		if ( $is_detailed ) {
			return (bool) apply_filters( 'woocommerce_appointments_gcal_log_detailed', false, $handle, $this );
		}

		return true;
	}

	/**
	 * OAuth Logout.
	 *
	 * @param int|string $user_id User ID.
	 * @return bool|null
	 */
	protected function oauth_logout( $user_id = '' ): ?bool {
		$user_id = $user_id ?: '';
		$user_id = $this->get_user_id() ?: $user_id;

		// Debug.
		$this->log_debug( 'oauth_logout', 'Disconnecting from the Google Calendar app...' );

		// Staff disconnect: clear local tokens only — do NOT revoke at Google.
		// Revoking a shared Google account token would invalidate the global
		// connection when both use the same Google account.
		if ( $user_id ) {
			delete_user_meta( $user_id, 'wc_appointments_gcal_refresh_token' );
			delete_user_meta( $user_id, 'wc_appointments_gcal_calendar_id' );
			delete_user_meta( $user_id, 'wc_appointments_gcal_twoway' );
			$this->clear_gcal_access_cache( $user_id );
			delete_option( 'wc_appointments_gcal_sync_token_' . absint( $user_id ) );

			// Manual disconnect — clear any prior connection-dropped notice.
			delete_user_meta( $user_id, 'wc_appointments_gcal_connection_dropped' );
			$this->set_user_id( $user_id );
			$this->mark_last_sync_status( false, __( 'Disconnected.', 'woocommerce-appointments' ) );
			delete_user_meta( $user_id, 'wc_appointments_gcal_last_error' );

			// Debug.
			$this->log_debug( 'oauth_logout_staff', 'Successfully disconnected staff #' . $user_id . ' from the Google Calendar app (local only)' );
			return true;
		}

		// Global disconnect: local cleanup only by default.
		// Revoking at Google can invalidate other refresh tokens issued for the
		// same Google account/client (including staff connections).
		$refresh_token    = $this->get_refresh_token( '' );
		$revoke_on_logout = (bool) apply_filters( 'wc_appointments_gcal_revoke_on_global_disconnect', false, $this );

		if ( $refresh_token && $revoke_on_logout ) {
			$params = [
				'body'    => http_build_query( [ 'token' => $refresh_token ] ),
				'timeout' => 20,
				'headers' => [
					'Content-Type' => 'application/x-www-form-urlencoded',
				],
			];

			$response = wp_remote_post( $this->revoke_uri, $params );
			if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
				$this->log_debug( 'revoke_token_success', 'Successfully revoked token at Google.' );
			} else {
				$this->log_debug(
					'revoke_token_error',
					'Google revoke returned non-200 (proceeding with local cleanup): ' . $this->format_debug_value( is_wp_error( $response ) ? $response : ( $response['response'] ?? '' ) )
				);
			}
		}

		// Always clear global local tokens.
		delete_option( 'wc_appointments_gcal_refresh_token' );
		$this->clear_gcal_access_cache( '' );
		delete_option( 'wc_appointments_gcal_sync_token' );

		// Manual disconnect — clear any prior connection-dropped notice.
		delete_option( 'wc_appointments_gcal_connection_dropped' );
		$this->set_user_id( 0 );
		$this->mark_last_sync_status( false, __( 'Disconnected.', 'woocommerce-appointments' ) );
		delete_option( 'wc_appointments_gcal_last_error' );

		// Debug.
		$this->log_debug( 'oauth_logout_success', 'Successfully disconnected from the Google Calendar app' );
		return true;
	}

	/**
     * Process the oauth redirect.
     */
    public function oauth_redirect(): void {
		if ( ! current_user_can( 'manage_appointments' ) ) {
			wp_die( esc_html__( 'Permission denied!', 'woocommerce-appointments' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback; state is HMAC-verified below.
		$state_raw = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$user_id   = 0;

		// Signed state binds the callback to the initiating admin + staff context (CSRF).
		if ( '' === $state_raw ) {
			wp_die( esc_html__( 'Invalid OAuth state.', 'woocommerce-appointments' ) );
		}

		$parsed_user_id = $this->parse_oauth_state( $state_raw );
		if ( false === $parsed_user_id ) {
			wp_die( esc_html__( 'Invalid or expired OAuth state.', 'woocommerce-appointments' ) );
		}

		$user_id = (int) $parsed_user_id;

		// Re-apply the same staff/global gate as the AJAX OAuth initiator (state alone is not enough).
		if ( ! WC_Appointments_Staff_Permissions::can_manage_gcal_for_staff( $user_id ) ) {
			wp_die( esc_html__( 'Permission denied!', 'woocommerce-appointments' ) );
		}

		if ( $user_id > 0 ) {
			// If the user is connecting their own calendar, redirect to profile.php
			// (where the custom staff profile UI loads).
			if ( $user_id === get_current_user_id() ) {
				$admin_url     = admin_url( 'profile.php' );
				$redirect_args = [];
			} else {
				$admin_url     = admin_url( 'user-edit.php' );
				$redirect_args = [
					'user_id' => $user_id,
				];
			}
		} else {
			$admin_url     = admin_url( 'admin.php' );
			$redirect_args = [
				'page'    => 'wc-settings',
				'tab'     => 'appointments',
				'section' => $this->id,
			];
		}

		// OAuth.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback; state verified above.
		$code = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
		if ( '' !== $code ) {
			$access_token = $this->get_access_token( $code, $user_id );

			if ( ! $access_token ) {
				$redirect_args['wc_gcal_oauth'] = 'fail';

				wp_safe_redirect( add_query_arg( $redirect_args, $admin_url ) );
				exit;
			}

			$this->record_oauth_connect_success( $user_id ? (int) $user_id : 0 );

			$redirect_args['wc_gcal_oauth'] = 'success';
			wp_safe_redirect( add_query_arg( $redirect_args, $admin_url ) );
			exit;
		}

		// Error.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback; state verified above.
		if ( isset( $_GET['error'] ) ) {
			$redirect_args['wc_gcal_oauth'] = 'fail';

			wp_safe_redirect( add_query_arg( $redirect_args, $admin_url ) );
			exit;
		}

		// Logout.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback; state verified above.
		if ( isset( $_GET['logout'] ) ) {
			$logout                          = $this->oauth_logout( $user_id );
			$redirect_args['wc_gcal_logout'] = ( $logout ?? false ) ? 'success' : 'fail';

			wp_safe_redirect( add_query_arg( $redirect_args, $admin_url ) );
			exit;
		}

		wp_die( esc_html__( 'Invalid request!', 'woocommerce-appointments' ) );
	}

	/**
	 * Get user calendars.
	 *
	 * @return array<string, string>|null Calendar list
	 */
	public function get_calendars(): ?array {
		// Get all Google Calendars.
		$google_calendars = [];

		// Check if Authorized.
		$access_token = $this->get_access_token();
		if ( ! $access_token ) {
			return null;
		}

		// Connection params.
		$params = [
			'method'  => 'GET',
			'timeout' => 60,
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			],
		];

		$response = wp_safe_remote_post( $this->calendars_list, $params );

		if ( ! is_wp_error( $response ) && 200 == $response['response']['code'] && 'OK' == $response['response']['message'] ) {
			// Get response data.
			$response_data = json_decode( $response['body'], true );

			// List calendars.
			if ( is_array( $response_data['items'] ) && (isset($response_data['items']) && [] !== $response_data['items']) ) {
				foreach ( $response_data['items'] as $data ) {
					$google_calendars[ $data['id'] ] = $data['summary'];
				}
			}
		}

		return $google_calendars;
	}

	/**
	 * Check if Google Calendar settings are supplied.
	 *
	 * @return bool True is calendar is set, false otherwise.
	 */
	public function is_calendar_set(): bool {
		$client_id     = $this->get_client_id();
		$client_secret = $this->get_client_secret();
		$calendar_id   = $this->get_calendar_id();

		return ! empty( $client_id ) && ! empty( $client_secret ) && ! empty( $calendar_id );
	}

	/**
	 * Makes an http request to the Google Calendar API.
	 *
	 * @param  string     $api_url  API Url to make the request against.
	 * @param  array<string, mixed> $params   Array of parameters that will be used when making the request.
	 * @param  string|int $staff_id Staff ID if request is for specific staff.
	 *
	 * @version       3.5.6
	 * @since         3.5.6
	 * @return array<string, mixed>|\WP_Error Response object from the request.
	 */
	protected function make_gcal_request( string $api_url, $params = [], $staff_id = '' ) {
		if ( '' === $api_url ) {
			return new WP_Error( 'wc_appointments_gcal_empty_url', 'Google Calendar API URL is empty.' );
		}

		// Check if Authorized.
		$access_token = $this->get_access_token( '', $staff_id );
		if ( ! $access_token ) {
			return new WP_Error( 'wc_appointments_gcal_no_access_token', 'Google Calendar access token is unavailable.' );
		}

		// Connection params.
		$params['method']  = strtoupper( $params['method'] ?? 'GET' );
		$params['timeout'] = 60;
		$params['headers']   = [
			'Content-Type'  => 'application/json',
			'Authorization' => 'Bearer ' . $access_token,
		];

		// No real use for now.
		if ( isset( $params['querystring'] ) && is_array( $params['querystring'] ) ) {
			$sep      = false !== strpos( $api_url, '?' ) ? '&' : '?';
			$api_url .= $sep . http_build_query( $params['querystring'] );
			unset( $params['querystring'] );
		}

		if ( in_array( $params['method'], [ 'GET', 'DELETE' ] ) ) {
			unset( $params['body'] );
		}

		// Filter the gCal request.
		$params = apply_filters( 'woocommerce_appointments_gcal_sync_parameters', $params, $api_url, $staff_id );

		$response = wp_safe_remote_request( $api_url, $params );

		// 200 = ok
		// 204 = deleted
		if ( ! is_wp_error( $response ) && 'OK' === $response['response']['message']
			&& in_array( (int) $response['response']['code'], [ 200, 204 ], true )
		) {
			// Success.
		} elseif ( 410 === (int) $response['response']['code'] ) {
			$this->log_debug( 'event_delete_410', 'Attempting to delete event that does not exist any more' );
		} else {
			$this->log_debug( 'make_request_error', 'Error while making Google Calendar request for ' . $api_url . ': ' . $this->format_debug_value( $response ) );
		}

		return $response;
	}

	/**
	 * Acquire an appointment-scoped event lock to avoid duplicate creates.
	 * Uses add_option for atomicity; stores an expiry to prevent deadlocks.
	 *
	 * @param int    $appointment_id Appointment ID
	 * @param string $scope          Lock scope key (e.g. "site|<calendar>", "staff_<id>|<calendar>")
	 * @return bool                  True if lock acquired; false if already locked
	 */
	protected function acquire_event_lock( $appointment_id, string $scope ): bool {
		$option   = $this->get_event_lock_option_name( $appointment_id, $scope );
		$now      = time();
		$ttl      = (int) apply_filters( 'wc_appointments_gcal_event_lock_ttl', 30, $this ); // seconds
		$expires  = $now + max( 1, $ttl );
		$existing = get_option( $option, [] );

		// Clear stale lock if expired.
		if ( is_array( $existing ) && isset( $existing['expires'] ) && (int) $existing['expires'] < $now ) {
			delete_option( $option );
		}

		// Atomic acquire via add_option. Autoload disabled.
		return (bool) add_option( $option, [ 'expires' => $expires ], '', false );
	}

	/**
	 * Release appointment-scoped event lock.
	 *
	 * @param int    $appointment_id Appointment ID
	 * @param string $scope          Scope key used when acquiring
	 */
	protected function release_event_lock( $appointment_id, string $scope ): void {
		delete_option( $this->get_event_lock_option_name( $appointment_id, $scope ) );
	}

	/**
     * Build appointment event lock option name.
     *
     * @param int    $appointment_id
     */
    protected function get_event_lock_option_name( $appointment_id, string $scope ): string {
		$aid = (int) $appointment_id;
		return 'wc_appt_gcal_event_lock_' . md5( $aid . '|' . $scope );
	}

	/**
     * Is edited from post.php's meta box.
     */
    public function is_edited_from_meta_box(): bool {
		$nonce_raw = filter_input( INPUT_POST, 'wc_appointments_details_meta_box_nonce' );
		if ( ! is_string( $nonce_raw ) || '' === $nonce_raw ) {
			return false;
		}

		return (bool) wp_verify_nonce( sanitize_text_field( wp_unslash( $nonce_raw ) ), 'wc_appointments_details_meta_box' );
	}

	/**
     * Sync Appointment with GCal when appointment is edited/updated/saved manually.
     *
     * @param  int $appointment_id Appointment ID
     */
    public function sync_edited_appointment( $appointment_id ): void {
		if ( ! $this->is_edited_from_meta_box() ) {
			return;
		}

		$this->maybe_sync_to_gcal_from_status( $appointment_id );
	}

	/**
     * Sync Appointment with GCal when appointment is NOT edited/updated/saved manually.
     * New appoiintments should also sync this way.
     *
     * @param  int $appointment_id Appointment ID
     */
    public function sync_unedited_appointment( $appointment_id ): void {
		if ( $this->is_edited_from_meta_box() ) {
			return;
		}

		$this->maybe_sync_to_gcal_from_status( $appointment_id );
	}

	/**
     * Sync Appointment with GCal when updated via REST API.
     *
     * @param WC_Appointment  $object   Appointment object.
     * @param WP_REST_Request $request  Request object.
     * @param bool            $creating True when creating, false when updating.
     */
    public function sync_rest_api_appointment( $object, $request, $creating ): void {
		// Only sync updates, not creations (creations are handled by status hooks).
		if ( $creating ) {
			return;
		}

		$appointment_id = $object->get_id();
		if ( $appointment_id ) {
			$this->maybe_sync_to_gcal_from_status( $appointment_id );
		}
	}

	/**
     * Sync Appointment with GCal when appointment changes status or anything else.
     *
     * @param  int $appointment_id Appointment ID
     */
    public function sync_updated_appointment( $appointment_id ): void {
		$this->maybe_sync_to_gcal_from_status( $appointment_id );
	}

	/**
     * Maybe remove / sync appointment based on appointment status.
     *
     * @param int $appointment_id Appointment ID
     */
    public function maybe_sync_to_gcal_from_status( $appointment_id ): void {
		global $wpdb;

		// Skip if currently syncing from gCal to avoid loop-back.
		if ( $this->syncing ) {
			return;
		}

		// Check if Authorized: either the global calendar has a token, or staff calendars are connected.
		$access_token = $this->get_access_token();
		if ( ! $access_token && ! $this->get_synced_staff_ids() ) {
			return;
		}

		$status = $wpdb->get_var( $wpdb->prepare( "SELECT post_status FROM $wpdb->posts WHERE post_type = 'wc_appointment' AND ID = %d", $appointment_id ) );

		if ( in_array( $status, [ 'cancelled', 'trash' ] ) ) {
			$this->remove_from_gcal( $appointment_id, false, false, true ); // true - sync other staff as well.
		} elseif ( in_array( $status, apply_filters( 'woocommerce_appointments_gcal_sync_statuses', [ 'confirmed', 'paid', 'complete' ] ) ) ) {
			$this->sync_to_gcal( $appointment_id, false, false, true ); // true - sync other staff as well.
		} elseif ( 'unpaid' === $status ) { // Sync Cash on Delivery appointments.
			$order_id = WC_Appointment_Data_Store::get_appointment_order_id( $appointment_id );
			$order    = wc_get_order( $order_id );
			if (is_a($order, 'WC_Order') && 'cod' === $order->get_payment_method()) {
                $this->sync_to_gcal( $appointment_id, false, false, true );
                // true - sync other staff as well.
            }
		}
	}

	/**
     * Maybe remove / sync appointment based on appointment staff change.
     *
     * @param array<int, mixed>|mixed $from Previous staff.
     * @param array<int, mixed>|mixed $to New staff.
     * @param int $appointment_id Appointment ID
     * @param WC_Appointment $appointment Appointment object.
     */
    public function maybe_sync_to_gcal_from_staff_change( $from, $to, $appointment_id, $appointment ): void {
		// Only work with staff changes, when appointments are edited manually
		// and are already existing to avoid infinite loops with calls to gcal.
		if ( ! $this->is_edited_from_meta_box() ) {
			return;
		}

		// Check if Authorized: either the global calendar has a token, or staff calendars are connected.
		$access_token = $this->get_access_token();

		// Debug: never log token values (present/absent only).
		$this->log_debug(
			'staff_change_token_check',
			'Manage token checks: global_token=' . ( $access_token ? 'yes' : 'no' )
		);
		if ( ! $access_token && ! $this->get_synced_staff_ids() ) {
			return;
		}

		// Check if appointment exists.
		$appointment = get_wc_appointment( $appointment_id );
		if ( ! $appointment ) {
			return;
		}

		$this->staff_syncing = true;

		// Debug.
		$this->log_debug( 'staff_change_manage', 'Manage staff for appointment #' . $appointment_id );

		// Get staff that was removed.
		#$to = [4, 5, 6, 7, 8];
		#$from = [1, 2, 3, 4, 5];
		$removed_staff_ids = array_diff( $from, $to );

		// Debug.
		$this->log_debug( 'staff_change_removed', 'Removed staff IDs :' . $this->format_debug_value( $removed_staff_ids ) );
		if ( [] !== $removed_staff_ids ) {
			foreach ( $removed_staff_ids as $removed_staff_id ) {
				$calendar_id       = get_user_meta( $removed_staff_id, 'wc_appointments_gcal_calendar_id', true );
				$removed_staff_calendar_id = $calendar_id ?: '';

				// Staff must have calendar ID set.
				if ( $removed_staff_calendar_id ) {
					// Switch calendar to staff for new sync.
					$this->set_calendar_id( $removed_staff_calendar_id );
					$this->set_user_id( $removed_staff_id ); #reset to staff calendar sync.

					// Debug.
						$this->log_debug( 'staff_change_remove_action', 'Removing appointment #' . $appointment_id . ' for staff #' . $removed_staff_id . ' from Google Calendar: ' . $removed_staff_calendar_id );

					// Remove event from removed staff.
					$this->remove_from_gcal( $appointment_id, $removed_staff_id, $removed_staff_calendar_id, false );
				}
			}

			// Reset to global calendar sync.
			$site_calendar_id  = get_option( 'wc_appointments_gcal_calendar_id' );
			$this->set_calendar_id( $site_calendar_id );
			$this->set_user_id( 0 );

			$this->log_debug( 'staff_change_reset', 'Sync reset to global' );
		}

		// Get staff that was added.
		#$from = [1, 2, 3, 4, 5];
		#$to = [4, 5, 6, 7, 8];
		$added_staff_ids = array_diff( $to, $from );

		// Debug.
		$this->log_debug( 'staff_change_added', 'Added staff IDs :' . $this->format_debug_value( $added_staff_ids ) );
		if ( [] !== $added_staff_ids ) {
			foreach ( $added_staff_ids as $added_staff_id ) {
				$calendar_id             = get_user_meta( $added_staff_id, 'wc_appointments_gcal_calendar_id', true );
				$added_staff_calendar_id = $calendar_id ?: '';

				// Staff must have calendar ID set.
				if ( $added_staff_calendar_id ) {
					// Switch calendar to staff for new sync.
					$this->set_calendar_id( $added_staff_calendar_id );
					$this->set_user_id( $added_staff_id ); #reset to staff calendar sync.

					// Debug.
						$this->log_debug( 'staff_change_add_action', 'Adding appointment #' . $appointment_id . ' for staff #' . $added_staff_id . 'to Google Calendar: ' . $added_staff_calendar_id );

					// Sync event to added staff.
					$this->sync_to_gcal( $appointment_id, $added_staff_id, $added_staff_calendar_id, false ); #false - do not sync other staff.
				}
			}

			// Reset to global calendar sync.
			$site_calendar_id  = get_option( 'wc_appointments_gcal_calendar_id' );
			$this->set_calendar_id( $site_calendar_id );
			$this->set_user_id( 0 );

			$this->log_debug( 'staff_change_reset_after_add', 'Sync reset to global' );
		}

		$this->staff_syncing = false;
	}

	/**
	 * Sync an event resource with Google Calendar.
	 * https://developers.google.com/google-apps/calendar/v3/reference/events
	 *
	 * @param   int            $appointment_id Appointment ID
	 * @param   array<string, mixed> $params Set of parameters to be passed to the http request
	 * @param   array<string, mixed> $resource_params Resource params
	 * @param   array<string, mixed> $data Optional set of data for writeable syncs
	 * @since                  3.5.6
	 * @version                3.5.6
	 * @return array<string, mixed>|false Parsed JSON data from the http request or false if error
	 */
	public function sync_event_resource( $appointment_id = -1, array $params = [], array $resource_params = [], $data = [] ) {
		if ( 0 > $appointment_id ) {
			return false;
		}

		$appointment = get_wc_appointment( $appointment_id );
		$event_id    = $resource_params['event_id'];
		$staff_id    = $resource_params['staff_id'];
		$calendar_id = $resource_params['calendar_id'];
		$api_url     = $this->calendars_uri . $calendar_id . '/events' . ( ( $event_id ) ? '/' . $event_id : '' );
		$json_data   = false;

		if ( isset( $params['method'] ) && 'GET' !== $params['method'] ) {
			$params['body'] = wp_json_encode( apply_filters( 'woocommerce_appointments_gcal_sync', $data, $appointment ) );
		}

		try {

			$response = $this->make_gcal_request( $api_url, $params, $staff_id );
			if ( is_wp_error( $response ) ) {
				$json_data = false;
			} else {
				$json_data = json_decode( $response['body'], true );
			}

			// Debug.
			$this->log_debug( 'sync_event_resource_ok', 'Synced appointment #' . $appointment->get_id() . ' with Google Calendar: ' . $calendar_id );

		} catch ( Exception $e ) {
			$json_data = false;

			// Debug.
			$this->log_debug( 'sync_event_resource_error', 'Error while getting data for ' . $api_url . ': ' . $e->getMessage() );
		}

		return $json_data;

	}

	/**
      * Sync Appointment to GCal
      *
      * @param  int $appointment_id Appointment ID
      * @param  int|false $appointment_staff_id Staff ID when syncing a staff calendar.
      * @param  string|false $staff_calendar_id Staff calendar ID.
      * @param  bool $staff_sync Whether this is a staff calendar sync.
      */
     public function sync_to_gcal( $appointment_id, $appointment_staff_id = false, $staff_calendar_id = false, $staff_sync = false ): void {
		if ( 'wc_appointment' !== get_post_type( $appointment_id ) ) {
			return;
		}

		// Compute target calendar for this sync operation.
		$target_calendar_id = ( $appointment_staff_id && $staff_calendar_id ? $staff_calendar_id : $this->get_calendar_id() );

		// During incoming sync, prevent syncing back to the SAME calendar the event came from,
		// but allow cross-calendar sync to OTHER calendars.
		if ( $this->syncing && '' !== $this->incoming_sync_calendar_id && $target_calendar_id === $this->incoming_sync_calendar_id ) {
			// Event is coming from this calendar, don't send it back to the same calendar.
			return;
		}

        /**
         * woocommerce_appointments_sync_to_gcal_start hook
         */
        do_action( 'woocommerce_appointments_sync_to_gcal_start', $appointment_id, $appointment_staff_id );

        // Get appointment object.
        $appointment = get_wc_appointment( $appointment_id );

        // Staff calendar should be different from main calendar.
        if ( $appointment_staff_id ) {
            $staff_event_ids = $appointment->get_google_calendar_staff_event_ids();
            $event_id        = $staff_event_ids[ $appointment_staff_id ] ?? '';
        } else {
            $event_id = $appointment->get_google_calendar_event_id();
        }

        // Compute active calendar and acquire a short-lived appointment-scoped lock to avoid duplicate creates.
        $active_calendar_id = ( $appointment_staff_id && $staff_calendar_id ? $staff_calendar_id : $this->get_calendar_id() );
        $lock_scope         = ( $appointment_staff_id ? ( 'staff_' . (int) $appointment_staff_id ) : 'site' ) . '|' . $active_calendar_id;

        if ( ! $this->acquire_event_lock( $appointment_id, $lock_scope ) ) {
            // Another sync in-flight for this appointment/cal.
            return;
        }

        try {
            // Preflight search: if no local event id, try to find an existing remote event via extended properties.
            if ( ! $event_id && $active_calendar_id ) {
                $search_url = $this->calendars_uri . $active_calendar_id . '/events'
                    . '?singleEvents=true&maxResults=2&orderBy=startTime'
                    . '&privateExtendedProperty=' . rawurlencode( 'appointment_id=' . $appointment_id )
                    . '&privateExtendedProperty=' . rawurlencode( 'site_url=' . home_url() );
                if ( $appointment_staff_id ) {
                    $search_url .= '&privateExtendedProperty=' . rawurlencode( 'staff_id=' . $appointment_staff_id );
                }

                $resp = $this->make_gcal_request( $search_url, [ 'method' => 'GET' ], $appointment_staff_id ?: '' );
                if ( $resp && ! is_wp_error( $resp ) ) {
                    $decoded = json_decode( $resp['body'], true );
                    if ( is_array( $decoded ) && ! empty( $decoded['items'] ) && isset( $decoded['items'][0]['id'] ) ) {
                        $event_id = (string) $decoded['items'][0]['id'];
                        // Persist found event id to appointment meta to ensure updates go via PUT.
                        if ( $appointment_staff_id ) {
                            $appointment->set_google_calendar_staff_event_ids( [ $appointment_staff_id => $event_id ] );
                        } else {
                            $appointment->set_google_calendar_event_id( wc_clean( $event_id ) );
                        }
                        $appointment->save();
                    }
                }
            }

            $product    = $appointment->get_product();
            $order      = $appointment->get_order();
            $customer   = $appointment->get_customer();
            $timezone   = wc_timezone_string();

		/* translators: %d: Appointment ID */
		$summary     = sprintf( __( 'Appointment #%d', 'woocommerce-appointments' ), $appointment_id ) . ( $product ? ' - ' . html_entity_decode( $product->get_title() ) : '' );
		$description = '';

		// Add customer name.
		if ( $customer ) {
			$description .= sprintf( '%s: %s', __( 'Customer', 'woocommerce-appointments' ), $customer->full_name ) . PHP_EOL;
		}

		// Product name.
		if ( is_object( $product ) ) {
			$description .= sprintf( '%s: %s', __( 'Product', 'woocommerce-appointments' ), $product->get_title() ) . PHP_EOL;
		}

		// Appointment data (same as before)...
		$appointment_data = [
			__( 'Appointment ID', 'woocommerce-appointments' ) => $appointment_id,
			__( 'When', 'woocommerce-appointments' )      => $appointment->get_start_date(),
			__( 'Duration', 'woocommerce-appointments' )  => $appointment->get_duration(),
			__( 'Location', 'woocommerce-appointments' )  => class_exists( 'WC_Appointments_Meetings' )
				? WC_Appointments_Meetings::format_location_display( $appointment )
				: $appointment->get_location_display(),
			__( 'Providers', 'woocommerce-appointments' ) => $appointment->get_staff_members( true ),
		];
		if ( class_exists( 'WC_Appointments_Resource' ) ) {
			$resource_line = WC_Appointments_Resource::get_context_display( $appointment, true );
			if ( '' !== $resource_line ) {
				$appointment_data[ get_wc_appointment_data_label( 'resource', $appointment->get_product() ) ] = $resource_line;
			}
		}
		$meeting_join = class_exists( 'WC_Appointments_Meetings' )
			? WC_Appointments_Meetings::get_my_account_join_context( $appointment )['url']
			: $appointment->get_meeting_join_url();
		if ( '' !== $meeting_join ) {
			$appointment_data[ __( 'Join Meeting', 'woocommerce-appointments' ) ] = $meeting_join;
		}
		$padding_duration = $product->get_padding_duration();
		if ( $padding_duration && in_array( $product->get_duration_unit(), [ 'hour', 'minute', 'day' ], true ) ) {
			$appointment_data += [
				__( 'Padding Time', 'woocommerce-appointments' ) => WC_Appointment_Duration::format_minutes( $padding_duration, $product->get_duration_unit() ),
			];
		}
		foreach ( $appointment_data as $key => $value ) {
			if ( empty( $value ) ) {
				continue;
			}
			$description .= sprintf(
			    '%1$s: %2$s',
			    rawurldecode( html_entity_decode( $key ) ),
			    rawurldecode( html_entity_decode( $value ) ),
			) . PHP_EOL;
		}

		// Addons and other order items (unchanged)...
		if ( is_a( $order, 'WC_Order' ) ) {
			foreach ( $order->get_items() as $order_item_id => $order_item ) {
				if ( WC_Appointment_Data_Store::get_appointment_order_item_id( $appointment_id ) !== $order_item_id ) {
					continue;
				}
				foreach ( $order_item->get_all_formatted_meta_data() as $meta ) {
					$description .= apply_filters(
					    'woocommerce_appointments_gcal_sync_order_meta',
					    sprintf( '%s: %s', rawurldecode( html_entity_decode( $meta->key ) ), rawurldecode( html_entity_decode( $meta->value ) ) ),
					    $meta,
					    $order,
					) . PHP_EOL;
				}
			}
		}

            // Resource params.
            $resource_params = [
                'event_id'    => $event_id,
                'staff_id'    => $appointment_staff_id,
                'calendar_id' => $active_calendar_id,
            ];

		// Build event payload.
		$data = [
			'summary'     => wp_kses_post( $summary ),
			'description' => wp_kses_post( $description ),
			'extendedProperties' => [
				'private' => [
					'appointment_id' => (string) $appointment_id,
					'site_url'       => home_url(),
					'staff_id'       => $appointment_staff_id ? (string) $appointment_staff_id : '',
					'order_id'       => is_a( $order, 'WC_Order' ) ? (string) $order->get_id() : '',
				],
			],
		];
		$gcal_location = class_exists( 'WC_Appointments_Meetings' )
			? WC_Appointments_Meetings::get_calendar_location_field( $appointment )
			: $appointment->get_location_display();
		if ( '' !== $gcal_location ) {
			$data['location'] = $gcal_location;
		}

		$needs_meet = class_exists( 'WC_Appointments_Meetings' ) && WC_Appointments_Meetings::needs_gcal_conference_create( $appointment );
		if ( $needs_meet ) {
			$data['conferenceData'] = WC_Appointments_Meetings::get_gcal_conference_create_request( (int) $appointment_id );
		}

		// Start/end times with explicit timeZone or all-day dates.
		if ( $appointment->is_all_day() ) {
			// Google Calendar all-day events are timezone-agnostic DATE values.
			// Keep semantic day boundaries stable across timezone offsets.
			$start_date = $this->get_gcal_all_day_date( (int) $appointment->get_start(), $timezone );
			$end_date   = $this->get_gcal_all_day_date( (int) $appointment->get_end(), $timezone );

			// End remains exclusive (Google/ICS semantics), matching internal storage.
			$data['end']   = [ 'date' => $end_date ];
			$data['start'] = [ 'date' => $start_date ];

			$this->log_debug(
				'sync_event_all_day_push',
				sprintf(
					'Appointment #%d push all-day start=%s end=%s (raw_start=%d raw_end=%d tz=%s)',
					$appointment_id,
					$start_date,
					$end_date,
					(int) $appointment->get_start(),
					(int) $appointment->get_end(),
					$timezone
				)
			);
		} else {
			$data['end'] = [ 'dateTime' => date( 'Y-m-d\TH:i:s', $appointment->get_end() ), 'timeZone' => $timezone ];
			$data['start'] = [ 'dateTime' => date( 'Y-m-d\TH:i:s', $appointment->get_start() ), 'timeZone' => $timezone ];
		}

		// OPTIONAL: Visibility (private|public|default) — off by default (no change unless filtered).
		$visibility = apply_filters( 'wc_appointments_gcal_event_visibility', null, $appointment, $resource_params, $this );
		if ( null !== $visibility ) {
			$data['visibility'] = (string) $visibility;
		}

		// OPTIONAL: colorId — off by default.
		$color_id = apply_filters( 'wc_appointments_gcal_event_color_id', null, $appointment, $resource_params, $this );
		if ( null !== $color_id ) {
			$data['colorId'] = (string) $color_id;
		}

		// OPTIONAL: attendees — off by default.
		$attendees = apply_filters( 'wc_appointments_gcal_event_attendees', [], $appointment, $resource_params, $this );
		if ( ! empty( $attendees ) && is_array( $attendees ) ) {
			$data['attendees'] = array_values( array_filter( $attendees, 'is_array' ) );
		}

		// OPTIONAL: reminders — off by default.
            $reminders = apply_filters( 'wc_appointments_gcal_event_reminders', null, $appointment, $resource_params, $this );
            if ( is_array( $reminders ) ) {
                $data['reminders'] = $reminders; // Expecting Google Calendar reminders structure.
            }

		// Conflict policy (prefer_site | prefer_calendar). Default to prefer_site (no change in behavior).
            $conflict_policy = apply_filters( 'wc_appointments_gcal_conflict_policy', 'prefer_site', $appointment, $resource_params, $this );

		// If updating an existing event, load existing to support conflict checks and no-op avoidance.
            $existing = [];
            if ( $event_id ) {
                $response_data = $this->sync_event_resource(
                    $appointment_id,
                    [
                        'method'      => 'GET',
                        'querystring' => [
                            'fields' => 'summary,description,start,end,updated,etag',
                        ],
                    ],
                    $resource_params,
                );
                $existing = is_array( $response_data ) ? $response_data : [];

				// BC: allow preserving Google-side description edits (removed in 5.0 rewrite).
				$data['description'] = wp_kses_post(
					(string) apply_filters( 'woocommerce_appointments_gcal_sync_updated_description', $description, $existing, $appointment )
				);

                if ( 'prefer_calendar' === $conflict_policy && isset( $existing['updated'] ) && $existing['updated'] ) {
                    $remote_updated_ts = strtotime( $existing['updated'] );
                    if ( $remote_updated_ts && 60 > ( time() - $remote_updated_ts ) ) {
                        // Skip overwrite if remote changed very recently.
                        return;
                    }
                }

                // No-op avoidance (skip PUT if core fields unchanged).
                $extract_time = function( $edge ): string {
                    if ( ! is_array( $edge ) ) {
                        return '';
                    }
                    if ( isset( $edge['dateTime'] ) ) {
                        return (string) $edge['dateTime'];
                    }
                    if ( isset( $edge['date'] ) ) {
                        return (string) $edge['date'];
                    }
                    return '';
                };
                $existing_fingerprint = [
                    'summary'     => (string) ( $existing['summary'] ?? '' ),
                    'description' => (string) ( $existing['description'] ?? '' ),
                    'start'       => $extract_time( $existing['start'] ?? [] ),
                    'end'         => $extract_time( $existing['end'] ?? [] ),
                ];
                $new_fingerprint = [
                    'summary'     => (string) $data['summary'],
                    'description' => (string) $data['description'],
                    'start'       => $extract_time( $data['start'] ),
                    'end'         => $extract_time( $data['end'] ),
                ];
                $should_skip = apply_filters(
                    'wc_appointments_gcal_skip_noop_update',
                    $existing_fingerprint === $new_fingerprint,
                    $existing_fingerprint,
                    $new_fingerprint,
                    $appointment,
                    $this,
                );
                if ( $should_skip && ! $needs_meet ) {
                    return;
                }
            }

            $sync_params = [
                'method' => $event_id ? 'PUT' : 'POST',
            ];
            if ( ! empty( $data['conferenceData'] ) ) {
                $sync_params['querystring'] = [
                    'conferenceDataVersion' => 1,
                ];
            }

            $response_data = $this->sync_event_resource(
                $appointment_id,
                $sync_params,
                $resource_params,
                $data,
            );

            if ( class_exists( 'WC_Appointments_Meetings' ) && ( $needs_meet || WC_Appointments_Meetings::should_create_for( $appointment ) || '' !== $appointment->get_meeting_provider() ) ) {
                WC_Appointments_Meetings::apply_from_gcal_event( $appointment, $response_data );
            }

            // Save event IDs back (unchanged from before)...
            if ( isset( $response_data['id'] ) ) {
                if ( $appointment_staff_id ) {
                    $appointment->set_google_calendar_staff_event_ids( [ $appointment_staff_id => $response_data['id'] ] );
                } else {
                    $appointment->set_google_calendar_event_id( wc_clean( $response_data['id'] ) );
                }
            }

            $appointment->skip_status_transition_events();
            $appointment->save();

            $staff_ids = $appointment->get_staff_ids();
            if ( $staff_ids && ! $appointment_staff_id && $staff_sync ) {
                foreach ( $staff_ids as $staff_id ) {
                    $calendar_id       = get_user_meta( $staff_id, 'wc_appointments_gcal_calendar_id', true );
                    $staff_calendar_id = $calendar_id ?: '';
                    // Skip staff whose calendar matches the site calendar (already synced above).
                    if ( $staff_calendar_id && $staff_calendar_id !== $active_calendar_id ) {
                        $this->sync_to_gcal( $appointment_id, $staff_id, $staff_calendar_id, false );
                    }
                }
            }
        } finally {
            // Always release appointment-scoped lock.
            $this->release_event_lock( $appointment_id, $lock_scope );
        }
    }

	/**
	 * Backoff-enabled HTTP request wrapper (GET/POST/PUT/PATCH/DELETE).
	 * Retries on transient conditions (403 rate limits, 429, 5xx).
	 *
	 * @param string $url
	 * @param array<string, mixed> $args wp_remote_* args
	 * @return array<string, mixed>|\WP_Error
	 */
	protected function http_request_with_backoff( $url, array $args ) {
		$max_retries = (int) apply_filters( 'wc_appointments_gcal_http_max_retries', 3, $this );
		$delay_base  = (int) apply_filters( 'wc_appointments_gcal_http_backoff_base_ms', 300, $this );
		$response    = new WP_Error( 'wc_appointments_gcal_http_retries_exhausted', 'Google Calendar HTTP request retries exhausted.' );

		for ( $attempt = 0; $attempt <= $max_retries; $attempt++ ) {
			$response = wp_safe_remote_request( $url, $args );

			if ( is_wp_error( $response ) ) {
				// Retry WP_Error only on transient networking issues.
				if ( $attempt < $max_retries ) {
					usleep( ( $delay_base * ( 2 ** $attempt ) + random_int( 0, 150 ) ) * 1000 );
					continue;
				}
				return $response;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );

			// Retry on transient/quota errors.
			if ((in_array( $code, [ 429, 500, 502, 503 ], true ) || $this->is_rate_limit_error($response)) && $attempt < $max_retries) {
                usleep( ( $delay_base * ( 2 ** $attempt ) + random_int( 0, 150 ) ) * 1000 );
                continue;
            }

			return $response;
		}

		return $response;
	}

	/**
	 * Detect Google Calendar rate limit responses from body.
	 *
	 * @param array<string, mixed> $response
	 * @return bool
	 */
	protected function is_rate_limit_error( $response ) {
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 403 !== $code ) {
			return false;
		}
		$body = wp_remote_retrieve_body( $response );
		if ( ! $body ) {
			return false;
		}
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) ) {
			return false;
		}
		// Match common Google error reasons.
		$reason = $data['error']['errors'][0]['reason'] ?? '';
		return in_array( $reason, [ 'rateLimitExceeded', 'userRateLimitExceeded', 'quotaExceeded' ], true );
	}

	/**
     * Remove/cancel the appointment in GCal
     *
     * @param  int          $appointment_id       Appointment ID
     * @param  int|false    $appointment_staff_id Staff ID
     * @param  string|false $staff_calendar_id    Staff synced calendar ID
     * @param  bool         $staff_sync           Should we sync all staff?
     */
    public function remove_from_gcal( $appointment_id, $appointment_staff_id = false, $staff_calendar_id = false, $staff_sync = false ): void {
		// Compute target calendar for this removal operation.
		$target_calendar_id = $staff_calendar_id ?: $this->get_calendar_id();

		// During incoming sync, prevent removing from the SAME calendar the event came from,
		// but allow cross-calendar removal to OTHER calendars.
		if ( $this->syncing && '' !== $this->incoming_sync_calendar_id && $target_calendar_id === $this->incoming_sync_calendar_id ) {
			// Event is coming from this calendar, don't send removal back to the same calendar.
			return;
		}

		// Stop the removal with a filter.
		$stop_the_removal = apply_filters(
		    'woocommerce_appointments_gcal_remove_from_gcal',
		    false,
		    $appointment_id,
		    $appointment_staff_id,
		    $staff_calendar_id,
		    $this,
		);
		if ( $stop_the_removal ) {
			return;
		}

		// Check if appointment exists.
		$appointment = get_wc_appointment( $appointment_id );
		if ( ! $appointment ) {
			return;
		}

		// Staff calendars first: staff-only sync has no main event ID, so the main-calendar
		// guards below must not skip them. A staff calendar equal to the main calendar is
		// covered by the main DELETE below unless there is no main event to delete.
		if ( ! $appointment_staff_id && $staff_sync ) {
			$main_event_id    = $appointment->get_google_calendar_event_id();
			$main_calendar_id = $this->get_calendar_id();
			foreach ( $appointment->get_staff_ids() as $staff_id ) {
				$s_calendar_id = get_user_meta( $staff_id, 'wc_appointments_gcal_calendar_id', true );
				if ( $s_calendar_id && ( ! $main_event_id || $s_calendar_id !== $main_calendar_id ) ) {
					$this->remove_from_gcal( $appointment_id, $staff_id, $s_calendar_id, false );
				}
			}
		}

		// Staff calendar should be different from main calendar.
		if ( $appointment_staff_id ) {
			$staff_event_ids = $appointment->get_google_calendar_staff_event_ids();
			$event_id       = $staff_event_ids[ $appointment_staff_id ] ?? '';
		} else {
			$event_id = $appointment->get_google_calendar_event_id();
		}

		// Stop removal, when no event is synced.
		if ( ! $event_id ) {
			return;
		}

		// Check if Authorized.
		$access_token = $this->get_access_token( '', $appointment_staff_id );
		if ( ! $access_token ) {
			return;
		}

		// Calendar ID.
		$calendar_id = $staff_calendar_id ?: $this->get_calendar_id();

		// Stop here if calendar is not set.
		if ( ! $calendar_id ) {
			return;
		}

		// Remove event.
		$api_url = $this->calendars_uri . $calendar_id . '/events/' . $event_id;

		// Connection params.
		$params = [
			'method'  => 'DELETE',
			'timeout' => 60,
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			],
		];

		$this->log_debug( 'remove_event_request', 'Removing event #' . $event_id . ' from Google Calendar: ' . $calendar_id );

		$response = $this->http_request_with_backoff( $api_url, $params );

		if ( ! is_wp_error( $response ) && isset( $response['response']['code'] ) && 204 == (int) $response['response']['code'] ) {
			$this->log_debug( 'remove_event_success', 'Event #' . $event_id . ' removed successfully!' );

			// Clear local linkage after a successful DELETE so re-sync does not target a dead event.
			$fresh = get_wc_appointment( $appointment_id );
			if ( $fresh ) {
				if ( $appointment_staff_id ) {
					$staff_event_ids                            = $fresh->get_google_calendar_staff_event_ids();
					$staff_event_ids[ (int) $appointment_staff_id ] = '';
					$fresh->set_google_calendar_staff_event_ids( $staff_event_ids );
				} else {
					$fresh->set_google_calendar_event_id( '' );
					if ( class_exists( 'WC_Appointments_Meetings' ) ) {
						WC_Appointments_Meetings::clear_meeting( $fresh, false );
					}
				}
				$fresh->skip_status_transition_events();
				$fresh->save();
			}
		} else {
			if ( is_wp_error( $response ) ) {
				$error_detail = $response->get_error_message();
			} else {
				$error_detail = wp_remote_retrieve_body( $response );
				if ( '' === $error_detail ) {
					$error_detail = $this->format_debug_value( $response['response'] ?? $response );
				}
			}
			$this->log_debug( 'remove_event_error', 'Error while removing event #' . $event_id . ': from Google Calendar: ' . $calendar_id . ' : ' . $error_detail );
		}
	}

	/**
	 * @return list<int>|null
	 */
	public function get_synced_staff_ids(): ?array {
		// Match staff roles used elsewhere in the plugin (see woocommerce-appointments.php admin checks).
		$staff_roles = array_values(
			array_filter(
				(array) apply_filters(
					'wc_appointments_gcal_staff_roles_for_sync',
					[ 'shop_staff', 'wc_appointment_staff' ],
				),
			),
		);

		if ( [] === $staff_roles ) {
			return null;
		}

		$all_staff = get_users(
		    [
				'role__in' => $staff_roles,
				'orderby'  => 'nicename',
				'order'    => 'asc',
				'fields'   => [ 'ID' ],
			],
		);

		if ( $all_staff ) {
			$synced_ids = [];
			foreach ( $all_staff as $provider ) {
				if ( ! isset( $provider->ID ) ) {
					continue;
				}
				$two_way     = get_user_meta( $provider->ID, 'wc_appointments_gcal_twoway', true );
				$calendar_id = get_user_meta( $provider->ID, 'wc_appointments_gcal_calendar_id', true );

				if ( 'two_way' === $two_way && $calendar_id ) {
					$synced_ids[] = absint( $provider->ID );
				}
			}

			// Array of staff with sync enabled.
			if ( [] !== $synced_ids ) {
				return $synced_ids;
			}
		}

		return null;
	}

	/**
	 * Run the schedule and sync from GCal.
	 * Wired to use incremental (syncToken) or forward-only window fetch, then delegate event processing.
	 * Falls back to the legacy body when the feature flag is disabled.
	 * @param int|string $user_id User ID.
	 */
	public function sync_from_gcal( $user_id = '' ): void {
		// Manual sync sets context via set_user_id() then calls sync_from_gcal() with no
		// argument. Without resolving here, $user_id stays empty and this method only pulls
		// calendars for users returned by get_synced_staff_ids() — staff excluded from that
		// list (e.g. different role) would never sync, and the run would fall through to global.
		if ( '' === $user_id ) {
			$preset = $this->get_user_id();
			if ( $preset ) {
				$user_id = absint( $preset );
			}
		}

		// Get all staff with sync enabled.
		$synced_staff = $this->get_synced_staff_ids();
		$synced_calendar_ids = [];
		if ( $synced_staff && ! $user_id ) {
			foreach ( $synced_staff as $synced_staff_id ) {
				$staff_cal = get_user_meta( $synced_staff_id, 'wc_appointments_gcal_calendar_id', true );
				$this->sync_from_gcal( $synced_staff_id );
				$last_sync = get_user_meta( $synced_staff_id, 'wc_appointments_gcal_last_sync', true );
				if ( $staff_cal && is_array( $last_sync ) && ! empty( $last_sync['ok'] ) ) {
					$synced_calendar_ids[] = $staff_cal;
				}
			}
		}

		// Set user id, calendar and 2-way sync.
		if ( $user_id ) {
			$this->set_user_id( $user_id );
			$this->set_calendar_id( get_user_meta( $user_id, 'wc_appointments_gcal_calendar_id', true ) ?: '' );
			$this->set_twoway( get_user_meta( $user_id, 'wc_appointments_gcal_twoway', true ) ?: '' );
		} else {
			$this->set_user_id( 0 ); // reset to global calendar sync.

			// Skip global sync if the global calendar was already synced by a staff member
			// to prevent double-syncing and sync token corruption.
			$global_calendar_id = get_option( 'wc_appointments_gcal_calendar_id' );
			if ( $global_calendar_id && in_array( $global_calendar_id, $synced_calendar_ids, true ) ) {
				return;
			}
		}

		// Two way sync not enabled.
		if ( ! $this->is_twoway_enabled() ) {
			return;
		}

		// Check if Authorized and if calendar is set.
		$access_token    = $this->get_access_token();
		$is_calendar_set = $this->is_calendar_set();
		if ( ! $is_calendar_set ) {
			$this->mark_last_sync_status( false, __( 'Google Calendar is not configured.', 'woocommerce-appointments' ) );
			return;
		}
		if ( ! $access_token ) {
			$this->mark_last_sync_status( false, __( 'Google Calendar is disconnected or token refresh failed.', 'woocommerce-appointments' ) );
			return;
		}

		// New path: centralized fetch with incremental sync token or forward-only window.
		$use_new_fetch = (bool) apply_filters( 'wc_appointments_gcal_use_new_fetch', true, $this );

		if ( $use_new_fetch ) {
			// Read stored incremental token for this context (per-staff or global).
			$current_user = $this->get_user_id() ? (int) $this->get_user_id() : '';
			$sync_token = $this->get_sync_token( $current_user );

			if ( empty( $sync_token ) && $this->manual_full_resync ) {
				$window = [
					'start' => null,
					'end'   => $this->get_cache_horizon_ts(),
				];
			} else {
				$window = $this->get_forward_sync_window();
			}

			$fetched = $this->fetch_events_delta_or_window( $access_token, $window, $sync_token );
			$events  = is_array( $fetched['events'] ?? null ) ? $fetched['events'] : [];
			$next    = (string) ( $fetched['nextSyncToken'] ?? '' );

			// Log what we received from Google Calendar.
			$this->log_debug( 'sync_from_gcal_fetch_result', sprintf(
				'Fetched %d events from Google Calendar. Manual full resync: %s, Sync token: %s, Window: start=%s, end=%s',
				count( $events ),
				$this->manual_full_resync ? 'YES' : 'NO',
				$sync_token ? 'present' : 'none',
				$window['start'] ? gmdate( 'Y-m-d H:i:s', $window['start'] ) : 'null (no timeMin)',
				gmdate( 'Y-m-d H:i:s', $window['end'] )
			) );
			
			$appointment_count = 0;
			$availability_count = 0;
			
			// Log each event summary.
			foreach ( $events as $idx => $event ) {
				$event_id = $event['id'] ?? 'unknown';
				$summary = $event['summary'] ?? 'No title';
				$status = $event['status'] ?? 'unknown';
				$has_recurrence = isset( $event['recurrence'] ) ? 'YES (recurring parent)' : 'NO';
				$recurring_event_id = $event['recurringEventId'] ?? '';
				$is_instance = $recurring_event_id ? 'YES (instance of ' . $recurring_event_id . ')' : 'NO';
				
				// Check if this is an appointment (has appointment_id in extended properties).
				$is_appointment = isset( $event['extendedProperties']['private']['appointment_id'] ) 
					|| isset( $event['extendedProperties']['shared']['appointment_id'] );
				
				if ( $is_appointment ) {
					$appointment_count++;
				} else {
					$availability_count++;
				}
				
				$start_str = 'unknown';
				if ( isset( $event['start']['dateTime'] ) ) {
					$start_str = $event['start']['dateTime'];
				} elseif ( isset( $event['start']['date'] ) ) {
					$start_str = $event['start']['date'] . ' (all-day)';
				}
				
				$this->log_debug( 'sync_event_' . $idx, sprintf(
					'Event #%d: id=%s, summary=%s, status=%s, start=%s, recurring=%s, instance=%s, type=%s',
					$idx + 1,
					$event_id,
					$summary,
					$status,
					$start_str,
					$has_recurrence,
					$is_instance,
					$is_appointment ? 'APPOINTMENT' : 'AVAILABILITY'
				) );
			}
			
			$this->log_debug( 'sync_event_summary', sprintf(
				'Event breakdown: %d appointments (will be skipped for availability rules), %d availability rules',
				$appointment_count,
				$availability_count
			) );

			if ( [] === $events && ( '' !== $sync_token && '0' !== $sync_token ) && ( '' === $next || '0' === $next ) ) {
				$this->log_debug( 'events_fetch_retry', 'No events returned with syncToken; retrying with forward-only window.' );
				$fetched = $this->fetch_events_delta_or_window( $access_token, $window, '' );
				$events  = is_array( $fetched['events'] ?? null ) ? $fetched['events'] : [];
				$next    = (string) ( $fetched['nextSyncToken'] ?? '' );
			}

			// Persist next incremental token for subsequent runs.
			if ( '' !== $next ) {
				$this->set_sync_token( $next, $current_user );
			}

			// Hand off to existing ingestion by emulating the response.
			$emulated_response = [
				'response' => [
					'code'    => 200,
					'message' => 'OK',
				],
				'body'     => wp_json_encode(
				    [
						'items'         => $events,
						'nextSyncToken' => $next,
					],
				),
			];

			$this->gcal_fetch_events( $emulated_response );

			// Update last-sync diagnostics with meaningful information.
			$current_user = $this->get_user_id() ? (int) $this->get_user_id() : '';

			// Get active synced rules for this context.
			$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
			$filter = $current_user 
				? [
					[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#staff' ],
					[ 'key' => 'kind_id', 'compare' => '=', 'value' => $current_user ],
					[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
				]
				: [
					[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#global' ],
					[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
				];
			$active_rules = $availability_data_store->get_all( $filter );
			$now = time();

			// Keep parity with manual re-sync counting:
			// - exclude exception/child rules (rules with parent_event_id),
			// - count recent creations for "changes" metric.
			$non_exception_rules = array_filter(
				$active_rules,
				function( $rule ) {
					$parent_id = $rule->get_parent_event_id();
					return ! $parent_id;
				}
			);
			$total_active = count( $non_exception_rules );
			$synced_count = count(
				array_filter(
					$non_exception_rules,
					function( $rule ) use ( $now ) {
						$created = $rule->get_date_created();
						if ( ! $created ) {
							return false;
						}
						return ( $now - $created->getTimestamp() ) < 120;
					}
				)
			);
			
			// Build status message based on what was processed.
			// Track changes in a time window to provide context about when changes occurred.
			$change_window_hours = (int) apply_filters( 'wc_appointments_gcal_change_window_hours', 24, $this );
			$change_window_seconds = $change_window_hours * HOUR_IN_SECONDS;
			
			// Get or initialize the change tracking data.
			$change_tracking_key = $current_user ? 'wc_appointments_gcal_change_tracking_' . $current_user : 'wc_appointments_gcal_change_tracking';
			$change_tracking = $current_user 
				? get_user_meta( $current_user, $change_tracking_key, true )
				: get_option( $change_tracking_key );
			
			if ( ! is_array( $change_tracking ) ) {
				$change_tracking = [
					'changes' => [], // Array of [timestamp, count] pairs
					'last_change_time' => 0,
				];
			}
			
			// Record only the latest sync-run change count.
			// This avoids stale cumulative counts from prior runs and keeps notice output deterministic.
			if ( $synced_count > 0 ) {
				$change_tracking['changes'] = [ [ $now, $synced_count ] ];
				$change_tracking['last_change_time'] = $now;
			} else {
				$change_tracking['changes'] = [];
				$change_tracking['last_change_time'] = 0;
			}
			
			// Calculate total changes in the time window.
			$total_changes_in_window = array_sum( array_column( $change_tracking['changes'], 1 ) );
			$last_change_time = (int) $change_tracking['last_change_time'];
			
			// Save updated tracking data.
			if ( $current_user ) {
				update_user_meta( $current_user, $change_tracking_key, $change_tracking );
			} else {
				update_option( $change_tracking_key, $change_tracking, false );
			}
			
			// Build the status message with time context.
			if ( $total_changes_in_window > 0 ) {
				$time_since_last_change = $now - $last_change_time;
				
				if ( $time_since_last_change < HOUR_IN_SECONDS ) {
					// Recent changes (less than 1 hour ago).
					$minutes_ago = max( 1, round( $time_since_last_change / MINUTE_IN_SECONDS ) );
					$message = sprintf(
						/* translators: %1$d: number of changes, %2$d: minutes ago, %3$d: total active rules */
						_n(
							'%1$d change %2$d minute(s) ago. %3$d active rule(s).',
							'%1$d changes in the last %2$d minute(s). %3$d active rule(s).',
							$total_changes_in_window,
							'woocommerce-appointments'
						),
						$total_changes_in_window,
						$minutes_ago,
						$total_active
					);
				} elseif ( $time_since_last_change < DAY_IN_SECONDS ) {
					// Changes within the last day.
					$hours_ago = max( 1, round( $time_since_last_change / HOUR_IN_SECONDS ) );
					$message = sprintf(
						/* translators: %1$d: number of changes, %2$d: hours ago, %3$d: total active rules */
						_n(
							'%1$d change %2$d hour(s) ago. %3$d active rule(s).',
							'%1$d changes in the last %2$d hour(s). %3$d active rule(s).',
							$total_changes_in_window,
							'woocommerce-appointments'
							),
						$total_changes_in_window,
						$hours_ago,
						$total_active
					);
				} else {
					// Changes more than a day ago but within the window.
					$days_ago = max( 1, round( $time_since_last_change / DAY_IN_SECONDS ) );
					$message = sprintf(
						/* translators: %1$d: number of changes, %2$d: days ago, %3$d: total active rules */
						_n(
							'%1$d change %2$d day(s) ago. %3$d active rule(s).',
							'%1$d changes in the last %2$d day(s). %3$d active rule(s).',
							$total_changes_in_window,
							'woocommerce-appointments'
						),
						$total_changes_in_window,
						$days_ago,
						$total_active
					);
				}
			} else {
				// No changes in the time window.
				$message = sprintf(
					/* translators: %1$d: time window in hours, %2$d: total active rules */
					__( 'No changes in the last %1$d hour(s). %2$d active rule(s).', 'woocommerce-appointments' ),
					$change_window_hours,
					$total_active
				);
			}
			
			$this->mark_last_sync_status( true, $message );
			return;
		}

		// Legacy path (kept for safety and backward-compatibility).
		$params = [
			'method'  => 'GET',
			'timeout' => 60,
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			],
		];

		// Don't sync events older than now.
		$timeMin = new DateTime();
		$timeMin->setTimezone( new DateTimeZone( wc_timezone_string() ) );
		$timeMin = $timeMin->format( 'Y-m-d\TH:i:sP' ); #\DateTime::RFC3339
		$timeMin = rawurlencode( $timeMin );

		// Don't sync events more than 1 year in future.
		$timeMax = new DateTime();
		$timeMax->setTimezone( new DateTimeZone( wc_timezone_string() ) );
		$timeMax->modify( '+1 year' );
		$timeMax = $timeMax->format( 'Y-m-d\TH:i:sP' ); #\DateTime::RFC3339
		$timeMax = rawurlencode( $timeMax );

		// Time zone.
		$timeZone = wc_timezone_string();

		// Get sync token.
		$sync_token = $this->get_sync_token();

		// maxResults 1000, 250 by default.
		if ( $this->get_sync_token() !== '' && $this->get_sync_token() !== '0' ) { #updated events only
			$response = wp_safe_remote_post( $this->calendars_uri . $this->get_calendar_id() . '/events' . "?singleEvents=false&showDeleted=true&syncToken=$sync_token&timeZone=$timeZone", $params );
		} else { #full sync
			$response = wp_safe_remote_post( $this->calendars_uri . $this->get_calendar_id() . '/events' . "?singleEvents=false&showDeleted=true&maxResults=1000&timeMin=$timeMin&timeMax=$timeMax&timeZone=$timeZone", $params );
		}

		if ( ! is_wp_error( $response ) && 410 == $response['response']['code'] ) {
			$this->set_sync_token( '0' );
			$response = wp_safe_remote_post( $this->calendars_uri . $this->get_calendar_id() . '/events' . "?singleEvents=false&showDeleted=true&maxResults=1000&timeMin=$timeMin&timeMax=$timeMax&timeZone=$timeZone", $params );
		}

		if ( is_wp_error( $response ) ) {
			// WP_Error may wrap a valid Google Calendar JSON response in its error message.
			// Check if the error message is actually valid Google JSON (contains 'items' array).
			$error_msg = $response->get_error_message();

			// Try to decode as JSON first
			$decoded = json_decode( $error_msg, true );

			if ( is_array( $decoded ) && array_key_exists( 'items', $decoded ) ) {
				// Valid Google response wrapped in WP_Error - process it normally.
				$this->log_debug( 'valid_error_wrapped_response', 'Received valid Google Calendar response in WP_Error, processing events.' );

				// Create a synthetic successful response to pass to gcal_fetch_events().
				$synthetic_response = [
					'response' => [
						'code'    => 200,
						'message' => 'OK',
					],
					'body' => $error_msg,
				];

				$this->gcal_fetch_events( $synthetic_response );
				$this->mark_last_sync_status( true, __( 'Processed events from error-wrapped response.', 'woocommerce-appointments' ) );
			} else {
				// Genuine error - log it.
				$this->log_debug( 'sync_error_wp_error', 'Error while performing sync from Google Calendar: ' . $this->get_calendar_id() . ': ' . $error_msg );
				$this->mark_last_sync_status( false, __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
				$this->mark_last_error( wp_strip_all_tags( $error_msg ) );
			}
			return;
		}

		$this->gcal_fetch_events( $response );

		// Update diagnostics on legacy path as well.
		$this->mark_last_sync_status( true, __( 'Legacy fetch completed.', 'woocommerce-appointments' ) );
	}

	/**
	 * Record a successful/failed last-sync status (per-user or global).
	 *
	 * @param bool   $ok
	 * @param string $message
	 */
	protected function mark_last_sync_status( $ok, $message = '' ): void {
		$payload = [
			'ts'  => (int) current_time( 'timestamp' ),
			'ok'  => (bool) $ok,
			'msg' => (string) $message,
		];
		$uid = $this->get_user_id() ? (int) $this->get_user_id() : 0;
		if ( 0 !== $uid ) {
			update_user_meta( $uid, 'wc_appointments_gcal_last_sync', $payload );
		} else {
			update_option( 'wc_appointments_gcal_last_sync', $payload, false );
		}
	}

	/**
	 * Record last error text/time for diagnostics (per-user or global).
	 *
	 * @param string $error_text
	 */
	protected function mark_last_error( $error_text ): void {
		$uid = $this->get_user_id() ? (int) $this->get_user_id() : 0;
		$txt = trim( (string) $error_text );
		if ( 0 !== $uid ) {
			update_user_meta( $uid, 'wc_appointments_gcal_last_error', $txt );
		} else {
			update_option( 'wc_appointments_gcal_last_error', $txt, false );
		}
	}

	/**
	 * Persist successful connection diagnostics right after OAuth code exchange.
	 *
	 * @param int $context_user_id 0 for global calendar, otherwise staff user ID.
	 */
	protected function record_oauth_connect_success( int $context_user_id ): void {
		$this->set_user_id( $context_user_id );

		if ( 0 !== $context_user_id ) {
			delete_user_meta( $context_user_id, 'wc_appointments_gcal_last_error' );
		} else {
			delete_option( 'wc_appointments_gcal_last_error' );
		}

		$this->mark_last_sync_status(
			true,
			__( 'Google Calendar account connected successfully.', 'woocommerce-appointments' )
		);

		// Do not trigger sync here. A global-context sync_from_gcal() can traverse staff
		// contexts and cause side effects after connect/disconnect flows.
	}

	/**
     * Fetch the events and generate gcal availability.
     *
     * @param  mixed $response Google Calendar API response.
     */
    public function gcal_fetch_events( $response ): void {
		// Stop here if no $response.
		if ( ! $response ) {
			return;
		}

		$this->syncing = true;

		// Track the source calendar to allow cross-calendar sync while preventing loop-back.
		$this->incoming_sync_calendar_id = (string) $this->get_calendar_id();

		// Get gcals availability rules.
		$gcal_availability_rules = $this->gcal_availability_rules( $response );
		$gcal_availability_rules = is_array( $gcal_availability_rules ) ? $gcal_availability_rules : [];

		// Last synced variables.
		// 0: current time in timestamp.
		// 1: number of events synced.
		$last_synced[] = absint( current_time( 'timestamp' ) );
		$last_synced[] = absint( count( $gcal_availability_rules ) );

		// Save gcal availability.
		if ( $this->get_user_id() ) {
			update_user_meta( $this->get_user_id(), 'wc_appointments_gcal_availability_last_synced', $last_synced );
		} else {
			update_option( 'wc_appointments_gcal_availability_last_synced', $last_synced );
		}

		$this->syncing = false;
		$this->incoming_sync_calendar_id = '';
	}

	/**
	 * Generate availability rules from GCal.
	 *
	 * @param array<string, mixed> $response Response from Google Calendar API.
	 *
	 * @return list<string>|null Array of event IDs processed or null on error.
	 */
	public function gcal_availability_rules( array $response ): ?array {
		global $wpdb;

		if ( $this->staff_syncing ) {
			// staff is being added/removed, don't touch the appointments.
			return null;
		}

		// Response error.
		if ( 200 !== $response['response']['code'] || 'OK' !== strtoupper( $response['response']['message'] ) ) {

			// Debug.
			$this->log_debug( 'sync_response_error', 'Error while performing sync from Google Calendar: ' . $this->get_calendar_id() . ': ' . $this->format_debug_value( $response['body'] ?? '' ) );
			return null;
		}

		// Hook: woocommerce_appointments_sync_from_gcal_start
		do_action( 'woocommerce_appointments_sync_from_gcal_start', $response );

		// Get site's time zone.
		$wp_appointments_timezone = wc_timezone_string();

		// Get time zone offset.
		wc_appointment_get_timezone_offset( $wp_appointments_timezone );

		// Get response data.
		$response_data = json_decode( $response['body'], true );

		// No events.
		if ( empty( $response_data['items'] ) || ! is_array( $response_data['items'] ) ) {
			return null;
		}

		// Set next sync token (per-user or global, matching the current sync context).
		$sync_token = $response_data['nextSyncToken'] ?? '';
		if ( $sync_token ) {
			$current_user = $this->get_user_id() ? (int) $this->get_user_id() : '';
			$this->set_sync_token( $sync_token, $current_user );
		}

		// Set event ids for counting later.
		$gcal_count = [];

		// Set event eid if it exists later.
		$appointment_eid = 0;

		/**
		 * Availability Data store instance.
		 *
		 * @var WC_Appointments_Availability_Data_Store $availability_data_store
		 */
		$availability_data_store = WC_Data_Store::load( WC_Appointments_Availability::DATA_STORE );

		// Assemble events
		foreach ( $response_data['items'] as $event ) {
			$appointment_eid = 0;

			// Hook: woocommerce_appointments_sync_from_gcal_start
			do_action( 'woocommerce_appointments_sync_from_gcal_event_start', $event );

			// Check if all day event.
			// value = DATE for all day, otherwise time included.
			$all_day = isset( $event['start']['date'] ) && isset( $event['end']['date'] );

			// Initialize date variables - some cancelled events may not have start/end.
			$dtstart = null;
			$dtend   = null;

			// Only parse dates if the event has start/end properties.
			if ( isset( $event['start'] ) && isset( $event['end'] ) ) {
				if ( $all_day ) {
					// Get Start and end date information
					$dtstart = new WC_DateTime( $event['start']['date'] );
					$dtend   = new WC_DateTime( $event['end']['date'] );
					// Note: Google Calendar returns end dates as exclusive boundaries per ICS spec.
					// Our system also stores end timestamps as exclusive boundaries (00:00:00 of next day).
					// No adjustment needed - the dates align with our architecture.
				} elseif ( isset( $event['start']['dateTime'] ) && isset( $event['end']['dateTime'] ) ) {
					// Get Start and end datetime information
					$dtstart = new WC_DateTime( $event['start']['dateTime'] );
					$dtstart->setTimezone( new DateTimeZone( $wp_appointments_timezone ) );
					$dtend = new WC_DateTime( $event['end']['dateTime'] );
					$dtend->setTimezone( new DateTimeZone( $wp_appointments_timezone ) );
				}
			}

			// For cancelled instances of recurring events, look up by parent event ID.
			$lookup_event_id = $event['id'];
			$is_cancelled_instance = isset( $event['recurringEventId'] ) && ! empty( $event['recurringEventId'] ) && 'CANCELLED' === strtoupper( $event['status'] );

			if ( $is_cancelled_instance ) {
				$lookup_event_id = $event['recurringEventId'];
			}

			// Check early if this event has appointment_id in extended properties.
			// This flag will be used throughout the event processing to skip creating/updating availability rules.
			$has_appointment_id = isset( $event['extendedProperties']['private']['appointment_id'] )
				|| isset( $event['extendedProperties']['shared']['appointment_id'] );
			$event_site      = (string) ( ( $event['extendedProperties']['private'] ?? $event['extendedProperties']['shared'] ?? [] )['site_url'] ?? '' );
			$is_foreign_site = (bool) $event_site
				&& untrailingslashit( strtolower( $event_site ) ) !== untrailingslashit( strtolower( home_url() ) );

			// Load all synced availabilities.
			$availabilities = $availability_data_store->get_all(
			    [
					[
						'key'     => 'event_id',
						'compare' => '=',
						'value'   => $lookup_event_id,
					],
				],
			);

			// Handle cancelled instances BEFORE checking for empty availabilities.
			if ( $is_cancelled_instance && ! empty( $availabilities ) ) {
				// Extract the exception date from the cancelled instance.
				$exception_date = $this->get_exception_date_from_event( $event );

				if ( ! $exception_date ) {
					continue;
				}

				foreach ( $availabilities as $availability ) {
					// Add exception date to the availability rule.
					$this->add_exception_to_availability( $availability, $exception_date );
					$availability->save();
				}
				// Skip to next event after handling cancelled instance.
				continue;
			}

			// Handle MODIFIED instances of recurring events (has recurringEventId but NOT cancelled).
			// When someone changes the time for one occurrence, Google creates a modified instance
			// with different start/end times but still references the parent via recurringEventId.
			// We need to: 1) Add EXDATE to parent's rule for original time, 2) Create new rule for modified time.
			$is_modified_instance = isset( $event['recurringEventId'] ) && ! empty( $event['recurringEventId'] ) && 'CANCELLED' !== strtoupper( $event['status'] ?? '' );

			if ( $is_modified_instance ) {
				// Step 1: Add EXDATE to parent's availability rule for the original time.
				// The parent availability rules were found using $lookup_event_id = $event['recurringEventId'].
				// But we need to look up by the PARENT event ID, not the instance ID.
				$parent_availabilities = $availability_data_store->get_all(
					[
						[
							'key'     => 'event_id',
							'compare' => '=',
							'value'   => $event['recurringEventId'],
						],
					],
				);

				if ( ! empty( $parent_availabilities ) ) {
					// Extract the original start time from the event to create EXDATE.
					$exception_date = $this->get_exception_date_from_event( $event );

					if ( $exception_date ) {
						foreach ( $parent_availabilities as $parent_availability ) {
							$this->add_exception_to_availability( $parent_availability, $exception_date );
							$parent_availability->save();
						}
					}
				}

				// Step 2: Check if we already have an availability rule for this modified instance.
				$instance_availabilities = $availability_data_store->get_all(
					[
						[
							'key'     => 'event_id',
							'compare' => '=',
							'value'   => $event['id'],
						],
					],
				);

				if ( ! empty( $instance_availabilities ) ) {
					// Update existing availability rule for modified instance.
					foreach ( $instance_availabilities as $instance_availability ) {
						if ( ! $this->update_availability_from_event( $instance_availability, $event ) ) {
							continue;
						}
						// Store parent event ID reference for cascade deletion.
						$instance_availability->set_parent_event_id( $event['recurringEventId'] );
						$instance_availability->save();
					}
				} else {
					// Create new availability rule for the modified instance's new time.
					$new_availability = get_wc_appointments_availability();
					if ( ! $this->update_availability_from_event( $new_availability, $event ) ) {
						continue;
					}
					// Store parent event ID reference for cascade deletion.
					$new_availability->set_parent_event_id( $event['recurringEventId'] );
					$new_availability->save();
				}

				// Don't count modified instances separately - they're part of the parent recurring event.
				// The EXDATE is added to the parent rule, and the modified instance rule is a child of the parent.
				// From a user perspective, this is still one "event" (the recurring event with an exception).
				continue;
			}

			// No availabilities, check if an appointment matches the event.
			if ( empty( $availabilities ) ) {

				// Check if appointment ID is saved in extendedProperties (check both private and shared).
				// We set 'private' when syncing TO Google, so check that first.
				// IMPORTANT: Check for the PRESENCE of appointment_id, not whether the post still exists.
				// Even if the appointment was deleted from WordPress, we should NOT create an availability rule from it.
				// The $has_appointment_id flag was already set earlier in the loop.
				if ( isset( $event['extendedProperties']['private']['appointment_id'] ) ) {
					$appointment_eid = absint( $event['extendedProperties']['private']['appointment_id'] );
					$appointment_eid = is_string( get_post_status( $appointment_eid ) ) ? $appointment_eid : 0; // check if post exists.
				} elseif ( isset( $event['extendedProperties']['shared']['appointment_id'] ) ) {
					$appointment_eid = absint( $event['extendedProperties']['shared']['appointment_id'] );
					$appointment_eid = is_string( get_post_status( $appointment_eid ) ) ? $appointment_eid : 0; // check if post exists.
				} else {
					$appointment_eid = 0;
				}

				// Fallback: find appointment by stored Google Calendar event ID when extended properties are missing.
				if ( ! $appointment_eid && $lookup_event_id ) {
					$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_by(
						[
							'gcal_event_id' => $lookup_event_id,
							'limit'         => 1,
						],
					);
					if ( ! empty( $appointment_ids ) ) {
						$appointment_eid = absint( $appointment_ids[0] );
						$appointment_eid = is_string( get_post_status( $appointment_eid ) ) ? $appointment_eid : 0; // check if post exists.
						
						// Debug: Log appointment detection via fallback.
						if ( $appointment_eid ) {
							$this->log_debug( 'appointment_detected_fallback', sprintf( 'Event #%s is an APPOINTMENT (ID: %d) found by gcal_event_id - SKIPPING availability rule creation', $event['id'], $appointment_eid ) );
						}
					} else {
						// Debug: Confirmed this is an availability rule event.
						$this->log_debug( 'availability_rule_confirmed', sprintf( 'Event #%s is an AVAILABILITY RULE (no appointment found by any method)', $event['id'] ) );
					}
				}

				// Do not mutate appointments from unrelated/stale calendar events.
				if ( $appointment_eid ) {
					$appt_check  = get_wc_appointment( $appointment_eid );
					$reject      = ! is_a( $appt_check, 'WC_Appointment' );

					if ( ! $reject ) {
						$incoming_id = (string) ( $event['id'] ?? '' );
						$stored_id   = $this->get_user_id()
							? (string) ( $appt_check->get_google_calendar_staff_event_ids()[ $this->get_user_id() ] ?? '' )
							: $appt_check->get_google_calendar_event_id();
						$reject = $is_foreign_site
							|| ( $stored_id && $incoming_id && $stored_id !== $incoming_id );
					}

					if ( $reject ) {
						if ( ! $is_foreign_site ) {
							$this->log_debug(
								'appointment_rejected',
								sprintf(
									'Skipping event #%s - stale appointment linkage (site_url or event id mismatch)',
									$event['id']
								)
							);
							continue;
						}
						$appointment_eid = 0; // Shared calendar: import as busy, do not mutate.
					}
				}

				// Cancel appointment.
				if ( $appointment_eid ) {
					// When event is deleted inside GCal set appointment status to cancelled and go to next event.
					if ( isset( $event['status'] ) && 'CANCELLED' === strtoupper( $event['status'] ) ) {
						// Get appointment object.
						$appointment = get_wc_appointment( $appointment_eid );

						// Don't proceed if ID is not of a valid appointment.
						if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
							continue;
						}

						// Don't cancel trashed appointment.
						if ( 'trash' === $appointment->get_status() ) {
							continue;
						}

						// Don't cancel already cancelled appointment.
						if ( 'cancelled' === $appointment->get_status() ) {
							continue;
						}

						// Get staff IDs.
						$staff_ids = $appointment->get_staff_ids();

						// Testing.

						// Event coming from staff member.
						if ( $this->get_user_id() ) {
							// Remove staff that has cancelled event from appointment staff.
							$set_staff_ids = array_diff( $staff_ids, [ $this->get_user_id() ] );

							// Staff still present.
							if ( [] !== $set_staff_ids ) {
								// Save.
								$this->syncing = true;

								$staff_event_ids = $appointment->get_google_calendar_staff_event_ids();
								$staff_event_ids[ (int) $this->get_user_id() ] = '';
								$appointment->set_google_calendar_staff_event_ids( $staff_event_ids );
								$appointment->set_staff_ids( $set_staff_ids );
								$appointment->save();

								$this->syncing = false;

								// Staff removed, but skipped cancellation.
								$this->log_debug( 'staff_removed', 'Successfully removed staff #' . $this->get_user_id() . ' from appointment #' . $appointment_eid . ' from Google Calendar event #' . $event['id'] );

								// Skip cancellation.
								continue;

							// No staff present any more.
							} else {
								// Save.
								$this->syncing = true;

								$appointment->set_google_calendar_staff_event_ids( [] );
								$appointment->set_staff_ids( [] );
								$appointment->save();

								$this->syncing = false;

								// Go one with the appointment cancellation.
							}
						}

						$this->syncing = true;

						// Update appointment status to cancelled.
						$appointment->update_status( WC_Appointments_Constants::STATUS_CANCELLED );
						$appointment->save();

						$this->syncing = false;

						// Sync to other calendars withc multi-calendar sync.
						// Sync to site calendar.
						if ( $this->get_user_id() ) {
							$site_calendar_id  = get_option( 'wc_appointments_gcal_calendar_id' );
							// Site calendar exists?
							if ( $site_calendar_id ) {
								// Switch calendar back to global for new sync.
								$this->set_calendar_id( $site_calendar_id );
								$this->set_user_id( 0 ); #reset to global calendar sync.

								// Testing.

								$this->remove_from_gcal( $appointment_eid );
							}
						// Sync to other staff members.
						} elseif ( [] !== $staff_ids ) {
							foreach ( $staff_ids as $staff_id ) {
								$calendar_id       = get_user_meta( $staff_id, 'wc_appointments_gcal_calendar_id', true );
								$staff_calendar_id = $calendar_id ?: '';
								// Staff must have calendar ID set.
								// Skip sync to the same calendar again.
								if ( $staff_calendar_id && $this->get_calendar_id() !== $staff_calendar_id ) {
									// Switch calendar to staff for new sync.
									$this->set_calendar_id( $staff_calendar_id );
									$this->set_user_id( $staff_id ); #reset to staff calendar sync.

									// Testing.

									$this->remove_from_gcal( $appointment_eid, $staff_id, $staff_calendar_id, false );
								}
							}

							// Reset to global calendar sync.
							$site_calendar_id  = get_option( 'wc_appointments_gcal_calendar_id' );
							$this->set_calendar_id( $site_calendar_id );
							$this->set_user_id( 0 );
						}

						// Debug.
						if ( $this->get_user_id() ) {
							$this->log_debug( 'appointment_cancelled', 'Successfully cancelled appointment #' . $appointment_eid . ' from Google Calendar event #' . $event['id'] . ' for staff #' . $this->get_user_id() );
						} else {
							$this->log_debug( 'appointment_cancelled', 'Successfully cancelled appointment #' . $appointment_eid . ' from Google Calendar event #' . $event['id'] );
						}
					// Update appointment data.
					} else {
						// Get appointment object.
						$appointment = get_wc_appointment( $appointment_eid );

						// Don't proceed if ID is not of a valid appointment.
						if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
							continue;
						}

						// Testing.

						// Skip if event has no valid dates (can happen with some cancelled events).
						if ( null === $dtstart || null === $dtend ) {
							continue;
						}

						// Skip to next event if appointment times are the same.
						if (
							absint( date( 'YmdHis', $appointment->get_start() ) ) === absint( $dtstart->format( 'YmdHis' ) ) &&
							absint( date( 'YmdHis', $appointment->get_end() ) ) === absint( $dtend->format( 'YmdHis' ) )
						) {
							continue;
						}

						// Get staff IDs.
						$staff_ids = $appointment->get_staff_ids();

						// Testing.

						$this->syncing = true;

						// Set appointment start and end date with events time and timezone.
						// Do not use $dtstart->getTimestamp()" as it does not work correctly.
						$appointment->set_start( absint( strtotime( $dtstart->format( 'Y-m-d H:i:s' ) ) ) );
						$appointment->set_end( absint( strtotime( $dtend->format( 'Y-m-d H:i:s' ) ) ) );
						$appointment->set_all_day( (bool) intval( $all_day ) );

						// Testing.

						// Update appointment event ID if saved
						// in extendedProperties of the event.
						if ( $this->get_user_id() ) {
							$appointment->set_google_calendar_staff_event_ids( [ $this->get_user_id() => $event['id'] ] );
						} else {
							$appointment->set_google_calendar_event_id( wc_clean( $event['id'] ) );
						}

						// Testing.

						// Save the changes.
						$appointment->save();

						// Keep syncing flag true during multi-calendar sync to prevent loop-back.
						// Sync to other calendars with multi-calendar sync.
						// Sync to site calendar.
						if ( $this->get_user_id() ) {
							$site_calendar_id  = get_option( 'wc_appointments_gcal_calendar_id' );
							// Site calendar exists?
							if ( $site_calendar_id ) {
								// Switch calendar back to global for new sync.
								$this->set_calendar_id( $site_calendar_id );
								$this->set_user_id( 0 ); #reset to global calendar sync.

								// Testing.

								$this->sync_to_gcal( $appointment_eid, false, false, true ); #true - sync other staff as well.
							}
							// Sync to other staff members.
						} elseif ( [] !== $staff_ids ) {
							foreach ( $staff_ids as $staff_id ) {
								$calendar_id       = get_user_meta( $staff_id, 'wc_appointments_gcal_calendar_id', true );
								$staff_calendar_id = $calendar_id ?: '';
								// Staff must have calendar ID set.
								// Skip sync to the same calendar again.
								if ( $staff_calendar_id && $this->get_calendar_id() !== $staff_calendar_id ) {
									// Switch calendar to staff for new sync.
									$this->set_calendar_id( $staff_calendar_id );
									$this->set_user_id( $staff_id ); #reset to staff calendar sync.

									// Testing.

									$this->sync_to_gcal( $appointment_eid, $staff_id, $staff_calendar_id, true ); #true - sync other staff as well.
								}
							}

							// Reset to global calendar sync.
							$site_calendar_id  = get_option( 'wc_appointments_gcal_calendar_id' );
							$this->set_calendar_id( $site_calendar_id );
							$this->set_user_id( 0 );
						}

						// Reset syncing flag after all sync operations complete.
						$this->syncing = false;

						// Debug.
						if ( $this->get_user_id() ) {
							$this->log_debug( 'appointment_updated', 'Successfully updated appointment #' . $appointment_eid . ' from Google Calendar event #' . $event['id'] . ' for staff #' . $this->get_user_id() );
						} else {
							$this->log_debug( 'appointment_updated', 'Successfully updated appointment #' . $appointment_eid . ' from Google Calendar event #' . $event['id'] );
						}
					}

					// Go to next event.
					continue;
				}

				// Skip own-site appointment events; foreign site_url imports as busy.
				if ( $has_appointment_id && ! $is_foreign_site ) {
					$this->log_debug( 'appointment_skipped', sprintf( 'Skipping event #%s - it is an appointment (has appointment_id in extendedProperties), not an availability rule', $event['id'] ) );
					continue;
				}

				// Skip expired events - don't create availability rules for past events.
				// For non-recurring events, check if the end date is in the past.
				// For recurring events, they're handled by their RRULE and will naturally not show future occurrences.
				// Use 30-day grace period to account for timezone differences and recent past events.
				if ( ! isset( $event['recurrence'] ) && $dtend ) {
					$now = current_time( 'timestamp' );
					$grace_threshold = strtotime( '-30 days', $now );
					
					if ( $dtend->getTimestamp() < $grace_threshold ) {
						continue;
					}
				}

				// This is a genuine availability rule event - create it.
				$availability = get_wc_appointments_availability();
				if ( 'CANCELLED' !== strtoupper( $event['status'] ) ) {
					if ( ! $this->update_availability_from_event( $availability, $event ) ) {
						continue;
					}
					$availability->save();
					
					// Count this availability rule.
					$gcal_count[] = $event['id'];
				}

				continue;
			}

			// Skip own-site appointment updates; foreign site_url mirrors keep syncing.
			if ( $has_appointment_id && ! $is_foreign_site ) {
				$this->log_debug( 'appointment_skipped_update', sprintf( 'Skipping update for event #%s - it is an appointment (has appointment_id in extendedProperties), not an availability rule', $event['id'] ) );
				continue;
			}

			// Loop through availability rules.
			// Update rules or delete them.
			foreach ( $availabilities as $availability ) {
				$event_date        = new WC_DateTime( $event['updated'] );
				$availability_date = $availability->get_date_modified();

				// Testing.

				if ( $event_date > $availability_date ) {
					// Sync Google Event -> Availability.
					if ('CANCELLED' !== strtoupper( $event['status'] )) {
                        if ( ! $this->update_availability_from_event( $availability, $event ) ) {
							// Debug: Event has invalid date format, skip.
							$this->log_debug( 'invalid_date_format', 'Skipping event #' . $event['id'] . ' - invalid date format' );
							continue;
						}
                        $availability->save();
                        
                        // Check if this rule is expired before counting it.
                        // For non-recurring events, check if the end date is in the past.
                        // For recurring events, they're handled by their RRULE and will naturally not show future occurrences.
                        // Use 30-day grace period to account for timezone differences and recent past events.
                        $should_count = true;
                        if ( 'rrule' !== $availability->get_range_type() && $dtend ) {
							$now = current_time( 'timestamp' );
							$grace_threshold = strtotime( '-30 days', $now );
							
							if ( $dtend->getTimestamp() < $grace_threshold ) {
								$should_count = false;
							}
						}
						
						// Count this availability rule update only if not expired.
						if ( $should_count ) {
							$gcal_count[] = $event['id'];
						}
                    } elseif (isset( $event['recurringEventId'] ) && ! empty( $event['recurringEventId'] )) {
                        // Handle cancelled instances of recurring events as exceptions.
                        // This is a cancelled instance of a recurring event.
                        // Fetch the parent recurring event to get the complete EXDATE list.
                        $parent_event = $this->fetch_parent_recurring_event( $event['recurringEventId'] );
                        if ( $parent_event ) {
								// Update availability from parent event (which includes EXDATE).
								if ( $this->update_availability_from_event( $availability, $parent_event ) ) {
									$availability->save();
								}

								if ( $this->get_user_id() ) {
									$this->log_debug( 'update_rule_with_exceptions', 'Successfully updated availability rule #' . $availability->get_id() . ' with exceptions from parent event #' . $event['recurringEventId'] . ' for staff #' . $this->get_user_id() );
								} else {
									$this->log_debug( 'update_rule_with_exceptions', 'Successfully updated availability rule #' . $availability->get_id() . ' with exceptions from parent event #' . $event['recurringEventId'] );
								}
							} else {
								// Fallback: add this specific exception if we can't fetch parent.
								$exception_date = $this->get_exception_date_from_event( $event );
								if ( $exception_date ) {
									$this->add_exception_to_availability( $availability, $exception_date );
									$availability->save();

									if ( $this->get_user_id() ) {
										$this->log_debug( 'add_exception_date', 'Successfully added exception date ' . $exception_date . ' to availability rule #' . $availability->get_id() . ' for staff #' . $this->get_user_id() );
									} else {
										$this->log_debug( 'add_exception_date', 'Successfully added exception date ' . $exception_date . ' to availability rule #' . $availability->get_id() );
									}
								}
							}
                    } else {
							// This is a non-recurring event or the entire recurring series is cancelled - delete the rule.
							$deleted_event_id = $availability->get_event_id();
							$availability->delete();

							if ( $this->get_user_id() ) {
								$this->log_debug( 'delete_rule_success', 'Successfully deleted availability rule #' . $availability->get_id() . ' for staff #' . $this->get_user_id() );
							} else {
								$this->log_debug( 'delete_rule_success', 'Successfully deleted availability rule #' . $availability->get_id() );
							}

							// CASCADE DELETE: Also delete any availability rules created from modified instances
							// of this parent recurring event.
							if ( $deleted_event_id ) {
								$this->cascade_delete_modified_instance_rules( $deleted_event_id );
							}
						}
				}
			}

			// Don't add to counter here - we only count availability rules that are created/updated,
			// not all processed events (which includes appointments that are skipped).
		}

		$this->log_debug( 'sync_complete', sprintf( 'Total availability rules created/updated: %d', count( $gcal_count ) ) );
		if ( $this->get_user_id() ) {
			$this->log_debug( 'sync_complete_context', 'Sync completed for staff #' . $this->get_user_id() );
		} else {
			$this->log_debug( 'sync_complete_context', 'Sync completed for global calendar' );
		}

		// Event ids for counting.
		return $gcal_count;
	}

	/**
	 * Fetch parent recurring event from Google Calendar.
	 *
	 * @param string $recurring_event_id Parent recurring event ID.
	 *
	 * @return array<string, mixed>|null Parent event data or null on failure.
	 */
	private function fetch_parent_recurring_event( string $recurring_event_id ) {
		// Check if authorized.
		$access_token = $this->get_access_token();
		if ( ! $access_token ) {
			return null;
		}

		$calendar_id = $this->get_calendar_id();
		if ( ! $calendar_id ) {
			return null;
		}

		$api_url = $this->calendars_uri . rawurlencode( $calendar_id ) . '/events/' . rawurlencode( $recurring_event_id );

		$params = [
			'method'  => 'GET',
			'timeout' => 20,
			'headers' => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $access_token,
			],
		];

		$response = wp_safe_remote_request( $api_url, $params );

		if ( is_wp_error( $response ) ) {
			// Debug.
			$this->log_error( 'fetch_parent_wp_error', 'Error fetching parent recurring event #' . $recurring_event_id . ': ' . $response->get_error_message() );
			return null;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			// Debug.
			$this->log_error( 'fetch_parent_http_error', 'Failed to fetch parent recurring event #' . $recurring_event_id . ' (HTTP ' . $code . ')' );
			return null;
		}

		$body = wp_remote_retrieve_body( $response );
		$event_data = json_decode( $body, true );

		if ( ! is_array( $event_data ) || empty( $event_data['id'] ) ) {
			return null;
		}

		return $event_data;
	}

	/**
	 * Cascade delete availability rules created from modified instances of a parent recurring event.
	 *
	 * When a parent recurring event is deleted in Google Calendar, any availability rules
	 * that were created for modified instances (rescheduled occurrences) should also be deleted.
	 *
	 * @param string $parent_event_id The parent recurring event ID.
	 */
	private function cascade_delete_modified_instance_rules( string $parent_event_id ): void {
		if ( empty( $parent_event_id ) ) {
			return;
		}

		/**
		 * @var WC_Appointments_Availability_Data_Store $availability_data_store
		 */
		$availability_data_store = WC_Data_Store::load( WC_Appointments_Availability::DATA_STORE );

		// Find all availability rules that have this event as their parent.
		$child_availabilities = $availability_data_store->get_all(
			[
				[
					'key'     => 'parent_event_id',
					'compare' => '=',
					'value'   => $parent_event_id,
				],
			],
		);

		if ( empty( $child_availabilities ) ) {
			// Debug.
			$this->log_debug( 'cascade_delete_none', 'No modified instance rules found for parent event #' . $parent_event_id );
			return;
		}

		// Debug.
		$this->log_debug( 'cascade_delete_count', 'CASCADE DELETE: Found ' . count( $child_availabilities ) . ' modified instance rule(s) for parent event #' . $parent_event_id );

		foreach ( $child_availabilities as $child_availability ) {
			$child_id = $child_availability->get_id();
			$child_event_id = $child_availability->get_event_id();
			$child_availability->delete();

			// Debug.
			if ( $this->get_user_id() ) {
				$this->log_debug( 'cascade_delete_action', 'CASCADE DELETE: Deleted modified instance availability rule #' . $child_id . ' (event: ' . $child_event_id . ') for staff #' . $this->get_user_id() );
			} else {
				$this->log_debug( 'cascade_delete_action', 'CASCADE DELETE: Deleted modified instance availability rule #' . $child_id . ' (event: ' . $child_event_id . ')' );
			}
		}
	}

	/**
	 * Extract exception date from a cancelled recurring event instance.
	 *
	 * @param array<string, mixed> $event Google calendar event.
	 *
	 * @return string|null Exception date in EXDATE format or null.
	 */
	private function get_exception_date_from_event( array $event ) {
		if ( ! isset( $event['originalStartTime'] ) ) {
			return null;
		}

		// Check if all day event.
		$all_day = isset( $event['originalStartTime']['date'] );

		// Get site TimeZone.
		$wp_appointments_timezone = wc_timezone_string();

		if ( $all_day ) {
			// For all-day events, use date format (VALUE=DATE).
			$date = new WC_DateTime( $event['originalStartTime']['date'] );
			return $date->format( 'Ymd' );
		}
        // For timed events, use datetime format in UTC.
        $date = new WC_DateTime( $event['originalStartTime']['dateTime'] );
        // Convert to UTC for EXDATE
        $date->setTimezone( new DateTimeZone( $wp_appointments_timezone ) );
        return $date->format( 'Y-m-d\TH:i:sP' );
        #\DateTime::RFC3339

	}

	/**
     * Add exception date to availability rule.
     *
     * @param WC_Appointments_Availability $availability Availability rule.
     * @param string                       $exception_date Exception date.
     */
    private function add_exception_to_availability( WC_Appointments_Availability $availability, $exception_date ): void {
		$rrule = $availability->get_rrule();

		if ( empty( $rrule ) ) {
			return;
		}

		// Parse existing RRULE to check for EXDATE.
		$lines = array_filter( array_map( 'trim', explode( "\n", $rrule ) ) );
		$exdate_lines = [];
		$other_lines = [];

		foreach ( $lines as $line ) {
			if ( strpos( $line, 'EXDATE' ) === 0 ) {
				$exdate_lines[] = $line;
			} else {
				$other_lines[] = $line;
			}
		}

		// Collect existing exception dates, handling both VALUE=DATE and VALUE=DATE-TIME formats.
		$existing_exceptions = [];
		foreach ( $exdate_lines as $exdate_line ) {
			// Parse EXDATE;VALUE=DATE:date1,date2 or EXDATE:date1,date2 format.
			if ( preg_match( '/^EXDATE(?:;[^:]*)?:(.+)$/', $exdate_line, $matches ) ) {
				$dates = array_map( 'trim', explode( ',', $matches[1] ) );
				$existing_exceptions = array_merge( $existing_exceptions, $dates );
			}
		}

		// Add new exception if not already present.
		if ( ! in_array( $exception_date, $existing_exceptions, true ) ) {
			$existing_exceptions[] = $exception_date;
		} else {
			// Exception already exists, no need to update.
			return;
		}

		// Sort exceptions chronologically for cleaner output.
		sort( $existing_exceptions );

		// Determine if we need VALUE=DATE or not (check format of first exception).
		$needs_value_date = strlen( $existing_exceptions[0] ) === 8;

		// Build new EXDATE line(s) - PHP RRule library requires separate EXDATE lines, not comma-separated.
		// Each exception date gets its own EXDATE line for proper parsing.
		$exdate_prefix = $needs_value_date ? 'EXDATE;VALUE=DATE:' : 'EXDATE:';
		foreach ( $existing_exceptions as $exception ) {
			$other_lines[] = $exdate_prefix . $exception;
		}

		// Reconstruct RRULE with updated EXDATE lines.
		$availability->set_rrule( implode( "\n", $other_lines ) );
	}

	/**
	 * Sanitize a recurring rule to make sure the date + time formats match up.
	 *
	 * @param string $rrule   Recurring Rule.
	 * @param bool   $all_day Whether the event is all-day.
	 *
	 * @return string|null
	 */
	private function maybe_sanitize_rrule( string $rrule, bool $all_day ): ?string {
		// If we have only a start date then make sure the UNTIL also only has a date.
		if ($all_day) {
            return preg_replace( '/(UNTIL=\d{8})T\d{6}[^;]*/', '$1', $rrule );
        }

		// For timed events, ensure UNTIL has a time component.
		// Google Calendar may send date-only UNTIL for timed events when "ends on date" is used.
		// Use T235959Z to include all occurrences on the final day.
		return preg_replace( '/(UNTIL=\d{8})(?!T)/', '$1T235959Z', $rrule );
	}

	/**
     * Update global availability object with data from google event object.
     *
     * @param WC_Appointments_Availability $availability WooCommerce Appointments Availability object.
     * @param array<string, mixed>         $event        Google calendar event.
     */
    private function update_availability_from_event( WC_Appointments_Availability $availability, array $event ): bool {
		// Check if all day event.
		// value = DATE for all day, otherwise time included.
		$all_day = isset( $event['start']['date'] ) && isset( $event['end']['date'] );

		// Validate that event has required date properties.
		if ( ! isset( $event['start'] ) || ! isset( $event['end'] ) ) {
			return false;
		}

		// Check if BUSY or FREE.
		// value = OPAQUE for busy, and TRANSPARENT for free
		#$yes_no = isset( $event['transparency'] ) && 'TRANSPARENT' === strtoupper( $event['transparency'] ) ? 'yes' : 'no';
		$yes_no = 'no';

		// Get site TimeZone.
		$wp_appointments_timezone = wc_timezone_string();

		if ( $all_day ) {
			// Get Start and end date information.
			$dtstart = new DateTime( $event['start']['date'] );
			$dtend   = new DateTime( $event['end']['date'] );
			// Google Calendar returns end dates as exclusive boundaries per ICS spec (the day after
			// the last day of the event). Availability rules store to_range as an inclusive end date,
			// so subtract 1 day to convert from exclusive to inclusive.
			$dtend->modify( '-1 day' );
		} elseif ( isset( $event['start']['dateTime'] ) && isset( $event['end']['dateTime'] ) ) {
			// Get Start and end datetime information
			$dtstart = new DateTime( $event['start']['dateTime'] );
			$dtstart->setTimezone( new DateTimeZone( $wp_appointments_timezone ) );
			$dtend = new DateTime( $event['end']['dateTime'] );
			$dtend->setTimezone( new DateTimeZone( $wp_appointments_timezone ) );
		} else {
			// Event has no valid date format.
			return false;
		}

		$availability->set_event_id( $event['id'] )
			// Admin-facing label (Availability hub / calendar). Availabilities REST requires edit caps;
			// storefront slots never expose rule titles. Fall back when Google omits summary.
			->set_title( $event['summary'] ?? __( 'Busy', 'woocommerce-appointments' ) )
			->set_appointable( $yes_no )
			->set_priority( 5 )
			->set_ordering( 0 );

		if ( $this->get_user_id() ) {
			$availability->set_kind( WC_Appointments_Availability::KIND_STAFF );
			$availability->set_kind_id( $this->get_user_id() );
		} else {
			$availability->set_kind( WC_Appointments_Availability::KIND_GLOBAL );
		}

		// @TODO: check timezones.
		if ( isset( $event['recurrence'] ) ) {

			// Join all recurrence rules including RRULE and EXDATE.
			$recurrence_string = implode( "\n", $event['recurrence'] );
			$sanitized_rrule   = $this->maybe_sanitize_rrule( $recurrence_string, $all_day );

			// Validate that the recurrence string contains a valid RRULE line.
			// Invalid rrules from Google Calendar can crash the frontend date picker.
			if ( ! preg_match( '/RRULE:[^\r\n]*FREQ=/i', $sanitized_rrule ) ) {
				// Log the invalid rrule so admins can investigate.
				$this->log_error( 'invalid_recurrence_rule', sprintf(
					'WARNING: Invalid recurrence rule from Google Calendar event #%s (staff #%s). Rule: %s — Falling back to non-recurring event.',
					$event['id'],
					$this->get_user_id() ?: 'global',
					substr( $sanitized_rrule, 0, 300 )
				) );
			} else {
				$availability->set_range_type( 'rrule' );
				$availability->set_rrule( $sanitized_rrule );
				if ( $all_day ) {
					$availability->set_from_range( $dtstart->format( 'Y-m-d' ) );
					$availability->set_to_range( $dtend->format( 'Y-m-d' ) );
				} else {
					$availability->set_from_range( $dtstart->format( 'Y-m-d\TH:i:sP' ) ); // \DateTime::RFC3339
					$availability->set_to_range( $dtend->format( 'Y-m-d\TH:i:sP' ) ); // \DateTime::RFC3339
				}

				return true;
			}
		}

		// Non-recurring: clear any stale RRULE left from a prior recurring sync.
		$availability->set_rrule( '' );

		if ( $all_day ) {

			$availability->set_range_type( 'custom' )
				->set_from_range( $dtstart->format( 'Y-m-d' ) )
				->set_to_range( $dtend->format( 'Y-m-d' ) );

		} else {

			$availability->set_range_type( 'custom:daterange' )
				->set_from_date( $dtstart->format( 'Y-m-d' ) )
				->set_to_date( $dtend->format( 'Y-m-d' ) )
				->set_from_range( $dtstart->format( 'H:i' ) )
				->set_to_range( $dtend->format( 'H:i' ) );

		}

		return true;
	}

	/**
	 * Fix legacy all-day availability rules that have an extra day due to the bug fixed in 5.3.0-beta-6.
	 * This method corrects synced all-day rules where the end date is one day too far in the future.
	 *
	 * @since 5.3.3
	 * @return int Number of rules fixed.
	 */
	public function fix_legacy_allday_rules(): int {
		$fixed_count = 0;
		$availability_data_store = WC_Data_Store::load( WC_Appointments_Availability::DATA_STORE );

		// Get all synced availability rules (those with event_id set).
		$synced_availabilities = $availability_data_store->get_all(
			[
				[
					'key'     => 'event_id',
					'compare' => '!=',
					'value'   => '',
				],
			]
		);

		foreach ( $synced_availabilities as $availability ) {
			// Only process 'custom' range type (all-day events).
			if ( 'custom' !== $availability->get_range_type() ) {
				continue;
			}

			$from_range = $availability->get_from_range();
			$to_range   = $availability->get_to_range();

			// Skip if not valid date format (Y-m-d).
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from_range ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to_range ) ) {
				continue;
			}

			// Check if this rule spans more than one day.
			$from_dt = new DateTime( $from_range );
			$to_dt   = new DateTime( $to_range );
			$diff    = $from_dt->diff( $to_dt );

			// If the rule spans more than 0 days, it might have the extra day bug.
			// We can't automatically fix multi-day events without knowing the original Google Calendar event,
			// but we can log them for manual review.
			if ( $diff->days > 0 ) {
				// For now, we'll let the next sync fix these by re-importing from Google Calendar.
				// The update_availability_from_event method now has the correct logic (subtract 1 day).
				continue;
			}
		}

		return $fixed_count;
	}

	/**
	 * Maybe delete Global Availability from Google.
	 *
	 * @param WC_Appointments_Availability $availability Availability to delete.
	 */
	public function delete_availability( WC_Appointments_Availability $availability ): void {
		if ( $this->syncing ) {
			return;
		}

		if ( $availability->get_event_id() ) {
			// Set staff ID and staff calendar ID
			// if event is from staff availability.
			if ( 'availability#staff' === $availability->get_kind() && $availability->get_kind_id() ) {
				$this->set_user_id( $availability->get_kind_id() );
			}

			// Set parameters for gcal request.
			$calendar_id = $this->get_calendar_id() ?: 0;
			$api_url     = $this->calendars_uri . $calendar_id . '/events/' . $availability->get_event_id();
			$user_id     = $this->get_user_id() ?: 0;
			$params      = [
				'method' => 'DELETE',
			];

			try {
				// Shared-calendar mirrors: never DELETE the appointment-owned Google event.
				$probe = $this->make_gcal_request( $api_url, [ 'method' => 'GET' ], $user_id );
				if ( ! is_wp_error( $probe ) && $probe ) {
					$probe_event = json_decode( (string) ( $probe['body'] ?? '' ), true );
					$probe_props = is_array( $probe_event ) ? ( $probe_event['extendedProperties']['private'] ?? $probe_event['extendedProperties']['shared'] ?? [] ) : [];
					if ( ! empty( $probe_props['appointment_id'] ) ) {
						return;
					}
				}

				$response = $this->make_gcal_request( $api_url, $params, $user_id );

				// Nothing to work on.
				if ( is_wp_error( $response ) || ! $response ) {
					return;
				}

				// Event already deleted.
				if ( 410 === $response['response']['code'] ) {
					return;
				}

				// Debug.
					if ( $this->get_user_id() ) {
						$this->log_debug( 'delete_event_success', 'Successfully deleted event #' . $availability->get_event_id() . ' from Google for staff #' . $this->get_user_id() );
					} else {
						$this->log_debug( 'delete_event_success', 'Successfully deleted event #' . $availability->get_event_id() . ' from Google' );
					}

			} catch ( Exception $e ) {

				// Debug.
					if ( $this->get_user_id() ) {
						$this->log_error( 'delete_event_error', 'Error while deleting event #' . $availability->get_event_id() . ' from Google for staff #' . $this->get_user_id() . ':' . $e->getMessage() );
					} else {
						$this->log_error( 'delete_event_error', 'Error while deleting event #' . $availability->get_event_id() . ' from Google: ' . $e->getMessage() );
					}
			}
		}
	}

	/**
	 * Sync Global Availability to Google.
	 *
	 * @param WC_Appointments_Availability $availability Global Availability object.
	 */
	public function sync_availability( WC_Appointments_Availability $availability ): void {
		if ( ! $availability->get_changes() ) {
			// nothing changed don't waste time syncing.
			return;
		}

		if ( $this->syncing ) {
			// Event is coming from google don't send it back.
			return;
		}

		if ( $availability->get_event_id() ) {
			// Set staff ID and staff calendar ID
			// if event is from staff availability.
			if ( 'availability#staff' === $availability->get_kind() && $availability->get_kind_id() ) {
				$this->set_user_id( $availability->get_kind_id() );
			}

			// Set parameters for gcal request.
			$calendar_id = $this->get_calendar_id() ?: 0;
			$api_url     = $this->calendars_uri . $calendar_id . '/events/' . $availability->get_event_id();
			$user_id     = $this->get_user_id() ?: 0;
			$params      = [
				'method' => 'GET',
			];
			$json_data   = false;
			$event_data  = false;

			try {

				$response = $this->make_gcal_request( $api_url, $params, $user_id );

				// Nothing to work on.
				if ( is_wp_error( $response ) || ! $response ) {
					return;
				}

				$json_data = json_decode( $response['body'], true );

				// Debug.
					if ( $this->get_user_id() ) {
						$this->log_debug( 'get_event_success', 'Successfully got event #' . $availability->get_event_id() . ' from Google for staff #' . $this->get_user_id() );
					} else {
						$this->log_debug( 'get_event_success', 'Successfully got event #' . $availability->get_event_id() . ' from Google' );
					}

			} catch ( Exception $e ) {

				// Debug.
					if ( $this->get_user_id() ) {
						$this->log_error( 'get_event_error', 'Error while getting event #' . $availability->get_event_id() . ' from Google for staff #' . $this->get_user_id() . ':' . $e->getMessage() );
					} else {
						$this->log_error( 'get_event_error', 'Error while getting event #' . $availability->get_event_id() . ' from Google: ' . $e->getMessage() );
					}
			}

			// Only update events created in Gcal.
			// @TODO maybe add site rules to gcal as new events.
			if ( $json_data ) {
				$write_props = $json_data['extendedProperties']['private'] ?? $json_data['extendedProperties']['shared'] ?? [];
				if ( ! empty( $write_props['appointment_id'] ) ) {
					return; // Shared-calendar busy mirror: do not overwrite the appointment event.
				}

				$event      = $json_data;
				$event_data = $this->update_event_from_availability( $event, $availability );

				// Skip update of 'rrule' type of rules.
				if ( $event_data ) {

					// Set parameters for gcal request.
					$params = [
						'method' => 'PUT',
						'body'   => wp_json_encode( $event_data ),
					];

					try {

						$response = $this->make_gcal_request( $api_url, $params, $user_id );

						// Debug.
						if ( $this->get_user_id() ) {
							$this->log_debug( 'update_event_success', 'Successfully updated event #' . $event_data['id'] . ' with Google for staff #' . $this->get_user_id() );
						} else {
							$this->log_debug( 'update_event_success', 'Successfully updated event #' . $event_data['id'] . ' with Google' );
						}

					} catch ( Exception $e ) {

						// Debug.
						if ( $this->get_user_id() ) {
							$this->log_error( 'update_event_error', 'Error while updating event #' . $event_data['id'] . ' with Google for staff #' . $this->get_user_id() . ':' . $e->getMessage() );
						} else {
							$this->log_error( 'update_event_error', 'Error while updating event #' . $event_data['id'] . ' with Google: ' . $e->getMessage() );
						}
					}
				}
			}
		}
	}

	/**
     * Update google event object with data from global availability object.
     *
     * @param array<string, mixed> $event Google calendar event.
     * @param WC_Appointments_Availability $availability WooCommerce Global Availability object.
     *
     * @return array<string, mixed>|null
     */
    private function update_event_from_availability( array $event, WC_Appointments_Availability $availability ): ?array {
		$timezone        = wc_timezone_string();
		$start_date_time = new WC_DateTime();
		$end_date_time   = new WC_DateTime();

		$event['summary'] = $availability->get_title();

		switch ( $availability->get_range_type() ) {
			case 'custom:daterange':
				$start_date_time = new WC_DateTime( $availability->get_from_date() . ' ' . $availability->get_from_range() );
				$event['start']  = [
					'dateTime' => $start_date_time->format( 'Y-m-d\TH:i:s' ),
					'timeZone' => $timezone,
				];

				$end_date_time = new WC_DateTime( $availability->get_to_date() . ' ' . $availability->get_to_range() );
				$event['end']  = [
					'dateTime' => $end_date_time->format( 'Y-m-d\TH:i:s' ),
					'timeZone' => $timezone,
				];

				break;
			case 'custom':
				$start_date_time = new WC_DateTime( $availability->get_from_range() );
				$event['start']  = [
					'date' => $start_date_time->format( 'Y-m-d' ),
				];

				$end_date_time = new WC_DateTime( $availability->get_to_range() );
				$end_date_time->add( new DateInterval( 'P1D' ) );
				$event['end'] = [
					'date' => $end_date_time->format( 'Y-m-d' ),
				];

				break;
			case 'months':
				$start_date_time->setDate(
				    (int) date( 'Y' ),
				    (int) $availability->get_from_range(),
				    1,
				);

				$event['start'] = [
					'date' => $start_date_time->format( 'Y-m-d' ),
				];

				$number_of_months = 1 + intval( $availability->get_to_range() ) - intval( $availability->get_from_range() );

				$end_date_time = $start_date_time->add( new DateInterval( 'P' . $number_of_months . 'M' ) );

				$event['end'] = [
					'date' => $end_date_time->format( 'Y-m-d' ),
				];

				$event['recurrence'] = [ 'RRULE:FREQ=YEARLY' ];

				break;
			case 'weeks':
				$start_date_time->setDate(
				    (int) date( 'Y' ),
				    1,
				    1,
				);

				$end_date_time->setDate(
				    (int) date( 'Y' ),
				    1,
				    2,
				);

				$all_days     = implode( ',', array_keys( \RRule\RRule::WEEKDAYS ) );
				$week_numbers = implode( ',', range( $availability->get_from_range(), $availability->get_to_range() ) );
				$rrule        = "RRULE:FREQ=YEARLY;BYWEEKNO=$week_numbers;BYDAY=$all_days";

				$event['start'] = [
					'date' => $start_date_time->format( 'Y-m-d' ),
				];

				$event['end'] = [
					'date' => $end_date_time->format( 'Y-m-d' ),
				];

				$event['recurrence'] = [ $rrule ];

				break;
			case 'days':
				$start_day = intval( $availability->get_from_range() );
				$end_day   = intval( $availability->get_to_range() );

				$start_date_time->modify( 'this ' . self::DAYS_OF_WEEK[ $start_day ] );
				$event['start'] = [
					'date' => $start_date_time->format( 'Y-m-d' ),
				];

				$end_date_time = $start_date_time->modify( 'this ' . self::DAYS_OF_WEEK[ $end_day ] );

				$event['end'] = [
					'date' => $end_date_time->format( 'Y-m-d' ),
				];

				$event['recurrence'] = [ 'RRULE:FREQ=WEEKLY' ];

				break;
			case 'time:1':
			case 'time:2':
			case 'time:3':
			case 'time:4':
			case 'time:5':
			case 'time:6':
			case 'time:7':
				[, $day_of_week] = explode( ':', $availability->get_range_type() );

				$start_date_time->modify( 'this ' . self::DAYS_OF_WEEK[ $day_of_week ] );
				$end_date_time->modify( 'this ' . self::DAYS_OF_WEEK[ $day_of_week ] );
				$rrule = 'RRULE:FREQ=WEEKLY';

				// fall through please.
			case 'time':
				if ( ! isset( $rrule ) ) {
					$rrule = 'RRULE:FREQ=DAILY';
				}

				[$start_hour, $start_min] = explode( ':', $availability->get_from_range() );
				$start_date_time->setTime( (int) $start_hour, (int) $start_min );

				[$end_hour, $end_min] = explode( ':', $availability->get_to_range() );
				$end_date_time->setTime( (int) $end_hour, (int) $end_min );

				$event['start'] = [
					'dateTime' => $start_date_time->format( 'Y-m-d\TH:i:s' ),
					'timeZone' => $timezone,
				];

				$event['end'] = [
					'dateTime' => $end_date_time->format( 'Y-m-d\TH:i:s' ),
					'timeZone' => $timezone,
				];

				$event['recurrence'] = [ $rrule ];

				break;

			default:
				// That should be everything, anything else is not supported.
				return null;
		}

		return $event;
	}

	/**
	 * Markup for the Google OAuth connect control in admin, following Sign in with Google branding.
	 *
	 * @see https://developers.google.com/identity/branding-guidelines
	 *
	 * @param array<string, mixed> $attributes HTML attributes for the button element (e.g. data-staff, data-logout). Optional key "class" is merged with default classes.
	 * @return string
	 */
	public static function get_google_oauth_connect_button_html( array $attributes = [] ): string {
		$classes = 'button oauth_redirect wc-appointments-google-identity-btn';
		if ( ! empty( $attributes['class'] ) ) {
			$classes .= ' ' . trim( (string) $attributes['class'] );
		}
		unset( $attributes['class'] );

		$attr_html = '';
		foreach ( $attributes as $name => $value ) {
			if ( ! is_string( $name ) || '' === $name ) {
				continue;
			}
			$attr_html .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( (string) $value ) );
		}

		$label = __( 'Continue with Google', 'woocommerce-appointments' );

		$icon_url = WC_APPOINTMENTS_PLUGIN_URL . '/assets/images/google-g-mark.svg';
		$icon     = '<span class="wc-appointments-google-identity-btn__icon" aria-hidden="true"><img src="' . esc_url( $icon_url ) . '" alt="" width="18" height="18" decoding="async" loading="eager" /></span>';

		return sprintf(
			'<button type="button" class="%s"%s><span class="wc-appointments-google-identity-btn__inner">%s<span class="wc-appointments-google-identity-btn__label">%s</span></span></button>',
			esc_attr( $classes ),
			$attr_html,
			$icon,
			esc_html( $label )
		);
	}

	/**
	 * Allowed HTML for {@see self::get_google_oauth_connect_button_html()} when passed to wp_kses().
	 *
	 * @return array<string, array<string, bool|array<string, bool>>>
	 */
	public static function get_google_oauth_connect_button_kses_allowed_html(): array {
		return [
			'button' => [
				'type'        => true,
				'class'       => true,
				'data-staff'  => true,
				'data-logout' => true,
			],
			'span'   => [
				'class'       => true,
				'aria-hidden' => true,
			],
			'img'    => [
				'src'      => true,
				'alt'      => true,
				'width'    => true,
				'height'   => true,
				'decoding' => true,
				'loading'  => true,
			],
		];
	}
}

if ( ! function_exists( 'wc_appointments_gcal' ) ) {
	/**
	 * Returns the main instance of WC_Appointments_GCal to prevent the need to use globals.
	 *
	 * @return WC_Appointments_GCal
	 */
	function wc_appointments_gcal() {
		return WC_Appointments_GCal::instance();
	}
}

wc_appointments_gcal();
