<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Handles email sending
 */
class WC_Appointment_Email_Manager {
	use WC_Appointments_Manager_Trait;

	/**
	 * Email group name for WooCommerce Appointments emails.
	 *
	 * @since 5.3.8
	 * @var string
	 */
	const EMAIL_GROUP = 'wc-appointments';

	/**
	 * Assign the WooCommerce email group when the running WC version supports it (10.3+).
	 *
	 * @param WC_Email $email Email instance.
	 */
	public static function assign_email_group( $email ): void {
		if ( ! is_a( $email, 'WC_Email' ) ) {
			return;
		}

		if ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '10.3', '>=' ) ) {
			$email->email_group = self::EMAIL_GROUP;
		}
	}

	/**
	 * Constructor sets up actions
	 */
	public function __construct() {
		if ( $this->is_active() ) {
			$this->register_hooks();
		}
	}

	/**
	 * Register WordPress hooks for this manager.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		$this->appointments_email_preview();

		add_filter( 'woocommerce_email_groups', [ $this, 'register_email_groups' ] );
		add_filter( 'woocommerce_email_classes', [ $this, 'init_emails' ] );
		add_filter( 'woocommerce_email_attachments', [ $this, 'attach_ics_file' ], 10, 3 );
		add_filter( 'woocommerce_template_directory', [ $this, 'template_directory' ], 10, 2 );

		$this->appointments_email_actions();
		$this->load_block_email_editor_support();
	}

	/**
	 * Appointments email preview.
	 *
	 * @since   4.23.1
	 * @version 4.23.1
	 */
	public function appointments_email_preview(): void {
		include __DIR__ . '/emails/class-wc-appointments-email-preview.php';
	}

	/**
	 * Include our mail templates.
	 *
	 * @param array<string, WC_Email> $emails Array of email classes.
	 *
	 * @return array<string, WC_Email> Modified array of email classes.
	 */
	public function init_emails( array $emails ): array {
		if ( ! isset( $emails['WC_Email_Admin_Appointment_Cancelled'] ) ) {
			$emails['WC_Email_Admin_Appointment_Cancelled'] = include __DIR__ . '/emails/class-wc-email-admin-appointment-cancelled.php';
		}

		if ( ! isset( $emails['WC_Email_Admin_Appointment_Rescheduled'] ) ) {
			$emails['WC_Email_Admin_Appointment_Rescheduled'] = include __DIR__ . '/emails/class-wc-email-admin-appointment-rescheduled.php';
		}

		if ( ! isset( $emails['WC_Email_Admin_New_Appointment'] ) ) {
			$emails['WC_Email_Admin_New_Appointment'] = include __DIR__ . '/emails/class-wc-email-admin-new-appointment.php';
		}

		if ( ! isset( $emails['WC_Email_Appointment_Cancelled'] ) ) {
			$emails['WC_Email_Appointment_Cancelled'] = include __DIR__ . '/emails/class-wc-email-appointment-cancelled.php';
		}

		if ( ! isset( $emails['WC_Email_Appointment_Confirmed'] ) ) {
			$emails['WC_Email_Appointment_Confirmed'] = include __DIR__ . '/emails/class-wc-email-appointment-confirmed.php';
		}

		if ( ! isset( $emails['WC_Email_Appointment_Reminder'] ) ) {
			$emails['WC_Email_Appointment_Reminder'] = include __DIR__ . '/emails/class-wc-email-appointment-reminder.php';
		}

		if ( ! isset( $emails['WC_Email_Appointment_Follow_Up'] ) ) {
			$emails['WC_Email_Appointment_Follow_Up'] = include __DIR__ . '/emails/class-wc-email-appointment-follow-up.php';
		}

		if ( ! isset( $emails['WC_Email_Appointment_Series'] ) ) {
			$emails['WC_Email_Appointment_Series'] = include __DIR__ . '/emails/class-wc-email-appointment-series.php';
		}

		foreach (
			[
				'WC_Email_Admin_Appointment_Cancelled',
				'WC_Email_Admin_Appointment_Rescheduled',
				'WC_Email_Admin_New_Appointment',
				'WC_Email_Appointment_Cancelled',
				'WC_Email_Appointment_Confirmed',
				'WC_Email_Appointment_Reminder',
				'WC_Email_Appointment_Follow_Up',
				'WC_Email_Appointment_Series',
			] as $email_class
		) {
			if ( isset( $emails[ $email_class ] ) ) {
				self::assign_email_group( $emails[ $email_class ] );
			}
		}

		return $emails;
	}

	/**
	 * Attach the .ics files in the emails.
	 *
	 * @param  list<string> $attachments Array of attachments.
	 * @param  string       $email_id    Email ID.
	 * @param  mixed        $object      Order or Appointment object.
	 *
	 * @return list<string> Modified attachments.
	 */
	public function attach_ics_file( $attachments, $email_id, $object ) {
		$available = apply_filters(
		    'woocommerce_appointments_emails_ics',
		    [
				'admin_new_appointment',
				'admin_appointment_rescheduled',
				'appointment_confirmed',
				'appointment_reminder',
				'appointment_series',
				'customer_processing_order',
				'customer_completed_order',
			],
		);

		#error_log( var_export( $email_id, true ) );
		#error_log( var_export( $object, true ) );

		if ( in_array( $email_id, $available ) ) {
			include_once WC_APPOINTMENTS_ABSPATH . 'includes/admin/export/class-wc-appointments-ics-exporter.php';
			$generate = new WC_Appointments_ICS_Exporter();

			// Email object is for WC_Order.
			if ( is_a( $object, 'WC_Order' ) ) {
				$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_id( $object->get_id() );

				// Order contains appointments.
				if ( $appointment_ids ) {
					$appointment_objects = array_map( 'get_wc_appointment', $appointment_ids );
					$attachments[]       = $generate->get_ics( $appointment_objects );
				}
			// Email object is for single WC_Appointment.
			} elseif ( is_a( $object, 'WC_Appointment' ) ) {
				$attachments[] = $generate->get_appointment_ics( $object );
			}
		}

		return $attachments;
	}

	/**
	 * Custom template directory.
	 *
	 * @param  string $directory Template directory.
	 * @param  string $template  Template name.
	 *
	 * @return string Modified template directory.
	 */
	public function template_directory( $directory, $template ) {
		if ( false !== strpos( $template, '-appointment' ) ) {
			return 'woocommerce-appointments';
		}

		return $directory;
	}

	/**
	 * Appointments email actions for transactional emails.
	 *
	 * @since   3.2.4
	 * @version 3.2.4
	 */
	public function appointments_email_actions(): void {
		foreach ( self::get_transactional_email_actions() as $action ) {
			add_action( $action, [ 'WC_Emails', 'send_transactional_email' ], 10, 10 );
		}
	}

	/**
	 * Appointment status hooks that enqueue WooCommerce transactional emails.
	 *
	 * @return string[]
	 */
	public static function get_transactional_email_actions() {
		return apply_filters(
			'woocommerce_appointments_email_actions',
			array(
				'woocommerce_appointment_in-cart_to_paid',
				'woocommerce_appointment_in-cart_to_pending-confirmation',
				'woocommerce_appointment_unpaid_to_paid',
				'woocommerce_appointment_unpaid_to_confirmed',
				'woocommerce_appointment_unpaid_to_pending-confirmation',
				'woocommerce_appointment_confirmed_to_paid',
				'woocommerce_appointment_confirmed',
				'woocommerce_admin_confirmed',
				'woocommerce_appointment_pending-confirmation_to_cancelled',
				'woocommerce_appointment_confirmed_to_cancelled',
				'woocommerce_appointment_paid_to_cancelled',
				'woocommerce_appointment_unpaid_to_cancelled',
			)
		);
	}

	/**
	 * Register email groups for WooCommerce 10.3.0+.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, array<string, mixed>|string> $email_groups Array of email groups.
	 * @return array<string, array<string, mixed>|string>
	 */
	public function register_email_groups( $email_groups ) {
		if ( ! is_array( $email_groups ) ) {
			return $email_groups;
		}

		$email_groups[ self::EMAIL_GROUP ] = __( 'Appointments', 'woocommerce-appointments' );

		return $email_groups;
	}

	/**
	 * Move additional recipients to BCC so they are not exposed in the To list.
	 *
	 * @since 5.3.9
	 *
	 * @param string $recipients Comma-separated recipient list.
	 * @param string $headers    Existing email headers.
	 * @return array{0:string,1:string} Visible recipient and headers.
	 */
	public static function prepare_private_recipients( string $recipients, string $headers ): array {
		$emails = array_values( array_unique( array_filter( array_map( 'trim', explode( ',', $recipients ) ) ) ) );

		if ( count( $emails ) < 2 ) {
			return [ $recipients, $headers ];
		}

		$recipient = array_shift( $emails );
		$headers   = trim( $headers );

		$headers .= ( '' === $headers ? '' : "\r\n" ) . 'Bcc: ' . implode( ', ', $emails ) . "\r\n";

		return [ $recipient, $headers ];
	}

	/**
	 * Load block email editor support for WooCommerce 9.0+.
	 *
	 * @since 5.3.8
	 */
	public function load_block_email_editor_support(): void {
		// Block email editor requires WooCommerce 9.0+.
		if ( ! defined( 'WC_VERSION' ) || version_compare( WC_VERSION, '9.0', '<' ) ) {
			return;
		}

		// Register appointment emails for block editor.
		add_filter( 'woocommerce_transactional_emails_for_block_editor', [ $this, 'register_block_editor_emails' ] );

		// Add appointment context data for email personalization.
		add_filter( 'woocommerce_email_editor_integration_personalizer_context_data', [ $this, 'add_appointment_context_data' ], 10, 2 );

		add_action( 'woocommerce_email_general_block_content', [ $this, 'render_appointment_block_content' ], 10, 3 );
		add_filter( 'woocommerce_mail_content', [ $this, 'use_classic_template_when_block_body_missing' ], 8 );

		// Exclude appointment emails from order details rendering in block emails.
		// Appointment emails don't have traditional order objects, so we handle the content ourselves.
		add_filter( 'woocommerce_emails_general_block_content_emails_without_order_details', [ $this, 'exclude_appointment_emails_from_order_details' ] );

		// Load personalization tags class.
		require_once WC_APPOINTMENTS_ABSPATH . 'includes/emails/class-wc-appointment-email-personalization-tags.php';

		$personalization_tags = new WC_Appointment_Email_Personalization_Tags();
		$personalization_tags->init();
	}

	/**
	 * Block shell without merged ##WOO_CONTENT## — fall back to classic PHP template.
	 *
	 * @since 5.4.0
	 *
	 * @param string $content Email HTML.
	 * @return string
	 */
	public function use_classic_template_when_block_body_missing( $content ) {
		$email = $this->get_sending_appointment_email();
		if ( ! $email || empty( $email->block_email_editor_enabled ) || ! method_exists( $email, 'get_content_html' ) ) {
			return $content;
		}

		$marker = '';
		if ( $email->object instanceof WC_Appointment ) {
			$marker = (string) $email->object->get_id();
		} elseif ( $email->object instanceof WC_Order ) {
			$marker = $email->object->get_order_number();
		}

		if ( ( '' !== $marker && false !== strpos( $content, $marker ) )
			|| ( '' === $marker && strlen( trim( wp_strip_all_tags( $content ) ) ) > 400 ) ) {
			return $content;
		}

		$block_on = $email->block_email_editor_enabled;
		$email->block_email_editor_enabled = false;
		$classic  = (string) $email->get_content_html();
		$email->block_email_editor_enabled = $block_on;

		return '' !== $classic ? $classic : $content;
	}

	/**
	 * WC_Email with sending=true during woocommerce_mail_content (before phpmailer_init).
	 *
	 * @return WC_Email|null
	 */
	private function get_sending_appointment_email() {
		if ( ! function_exists( 'WC' ) ) {
			return null;
		}

		$mailer = WC()->mailer();
		if ( ! $mailer ) {
			return null;
		}

		$ids = $this->get_appointment_email_ids();
		foreach ( $mailer->get_emails() as $email ) {
			if ( $email instanceof WC_Email && ! empty( $email->sending ) && in_array( $email->id, $ids, true ) ) {
				return $email;
			}
		}

		return null;
	}

	/**
	 * Register appointment emails for the block email editor.
	 *
	 * @since 5.3.8
	 *
	 * @param list<string> $emails Array of email IDs supported by block editor.
	 * @return list<string>
	 */
	public function register_block_editor_emails( $emails ) {
		return array_merge( $emails, $this->get_appointment_email_ids() );
	}

	/**
	 * Get the list of appointment email IDs.
	 *
	 * @since 5.3.8
	 * @return list<string>
	 */
	public function get_appointment_email_ids() {
		return [
			'admin_appointment_cancelled',
			'admin_appointment_rescheduled',
			'admin_new_appointment',
			'appointment_cancelled',
			'appointment_confirmed',
			'appointment_reminder',
			'appointment_follow_up',
			'appointment_series',
		];
	}

	/**
	 * Add appointment context data for email personalization.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $context The context data.
	 * @param WC_Email             $email   The email object.
	 * @return array<string, mixed>
	 */
	public function add_appointment_context_data( $context, $email ) {
		// Only add context for appointment emails.
		if ( ! $email || false === strpos( get_class( $email ), 'Appointment' ) ) {
			return $context;
		}

		if ( $email instanceof WC_Email_Appointment_Series && $email->appointment_series ) {
			$context['appointment_series']    = $email->appointment_series;
			$context['appointment_series_id'] = $email->appointment_series->get_id();

			$wc_order = $email->appointment_series->get_order_id() > 0 ? wc_get_order( $email->appointment_series->get_order_id() ) : false;
			if ( $wc_order ) {
				$context['order'] = $wc_order;
			}

			$customer_user_id = $email->appointment_series->get_customer_id();
			if ( $customer_user_id && empty( $context['wp_user'] ) ) {
				$wp_user = get_user_by( 'id', $customer_user_id );
				if ( $wp_user ) {
					$context['wp_user'] = $wp_user;
				}
			}

			return $context;
		}

		// Get the appointment object from the email.
		if ( isset( $email->object ) && $email->object instanceof WC_Appointment ) {
			$appointment = $email->object;

			$context['appointment']    = $appointment;
			$context['appointment_id'] = $appointment->get_id();

			// Let WooCommerce core personalization tags (customer, order, payment URL, etc.) resolve
			// when this appointment is tied to an order or WordPress user — same keys as WC_Email previews.
			$wc_order = $appointment->get_order();
			if ( $wc_order ) {
				$context['order'] = $wc_order;
			}

			$customer_user_id = $appointment->get_customer_id();
			if ( $customer_user_id && empty( $context['wp_user'] ) ) {
				$wp_user = get_user_by( 'id', $customer_user_id );
				if ( $wp_user ) {
					$context['wp_user'] = $wp_user;
				}
			}
		}

		return $context;
	}

	/**
	 * Exclude appointment emails from order details rendering in block emails.
	 *
	 * Appointment emails use WC_Appointment objects, not WC_Order objects, so the default
	 * order details rendering would not work correctly. Customer appointment confirmed is an
	 * exception: it passes WC_Order into general-block-email.php and must not be listed here.
	 *
	 * @since 5.3.8
	 *
	 * @param list<string> $emails Array of email IDs that should not display order details.
	 * @return list<string>
	 */
	public function exclude_appointment_emails_from_order_details( $emails ) {
		$without_order_details = array_diff( $this->get_appointment_email_ids(), [ 'appointment_confirmed', 'appointment_series' ] );

		return array_merge( $emails, array_values( $without_order_details ) );
	}

	/**
	 * Render appointment details content for block emails.
	 *
	 * This is called via the woocommerce_email_general_block_content action
	 * to render appointment details in the email-content block.
	 *
	 * @since 5.3.8
	 *
	 * @param bool     $sent_to_admin Whether the email is sent to admin.
	 * @param bool     $plain_text    Whether the email is plain text.
	 * @param WC_Email $email         The email object.
	 * @return void
	 */
	public function render_appointment_block_content( $sent_to_admin, $plain_text, $email ) {
		// Only render for appointment emails.
		if ( ! in_array( $email->id, $this->get_appointment_email_ids(), true ) ) {
			return;
		}

		$is_series = 'appointment_series' === $email->id && $email instanceof WC_Email_Appointment_Series && $email->appointment_series;

		if ( ! $is_series ) {
			$appointment = isset( $email->object ) && $email->object instanceof WC_Appointment ? $email->object : null;
			if ( ! $appointment ) {
				return;
			}
		}

		switch ( $email->id ) {
			case 'admin_appointment_cancelled':
				$template_part = 'admin-appointment-cancelled';
				break;
			case 'admin_appointment_rescheduled':
				$template_part = 'admin-appointment-rescheduled';
				break;
			case 'admin_new_appointment':
				$template_part = 'admin-new-appointment';
				break;
			case 'appointment_cancelled':
				$template_part = 'customer-appointment-cancelled';
				break;
			case 'appointment_confirmed':
				$template_part = 'customer-appointment-confirmed';
				break;
			case 'appointment_reminder':
				$template_part = 'customer-appointment-reminder';
				break;
			case 'appointment_follow_up':
				$template_part = 'customer-appointment-follow-up';
				break;
			case 'appointment_series':
				$template_part = 'customer-appointment-series';
				break;
			default:
				$template_part = '';
				break;
		}

		if ( '' === $template_part ) {
			return;
		}

		$template_args = array(
			'sent_to_admin' => $sent_to_admin,
			'plain_text'    => $plain_text,
			'email'         => $email,
		);

		if ( $is_series ) {
			$series  = $email->appointment_series;
			$product = wc_get_product( $series->get_product_id() );
			$align   = is_rtl() ? 'right' : 'left';
			$series_location = $series->get_meta( '_wca_location', true );
			$location_display = ( is_array( $series_location ) && class_exists( 'WC_Appointments_Location' ) )
				? WC_Appointments_Location::format_snapshot_for_display( $series_location )
				: '';
			$template_args['view'] = array(
				'text_align'          => $align,
				'product_name'        => $product ? $product->get_name() : '',
				'pattern'             => (string) ( $email->placeholders['{appointment_series_pattern}'] ?? '' ),
				'location_label'      => get_wc_appointment_data_label( 'location', $product ),
				'location_display'    => $location_display,
				'balance_series'      => $series->has_open_balance() ? $series : null,
				'sessions_table_html' => $email->get_sessions_table_html(),
			);
		}

		wc_get_template(
			'emails/parts/' . $template_part . '.php',
			$template_args,
			'woocommerce-appointments',
			WC_APPOINTMENTS_TEMPLATE_PATH
		);
	}
}

return new WC_Appointment_Email_Manager();
