<?php
/**
 * Class dependencies
 */
if ( ! class_exists( 'WC_Appointment_Form_Picker' ) ) {
	include_once __DIR__ . '/class-wc-appointment-form-picker.php';
}

/**
 * Date Picker class
 */
class WC_Appointment_Form_Date_Picker extends WC_Appointment_Form_Picker {

	private string $field_type = 'date-picker';
	private string $field_name = 'start_date';

	/**
	 * Constructor
	 * @param object $appointment_form The appointment form which called this picker
	 */
	public function __construct( $appointment_form ) {
		$this->appointment_form             = $appointment_form;
		$this->args                         = [];
		$this->args['class']                = [];
		$this->args['type']                 = $this->field_type;
		$this->args['name']                 = $this->field_name;
		$this->args['min_date']             = $this->appointment_form->product->get_min_date();
		$this->args['max_date']             = $this->appointment_form->product->get_max_date();
		$this->args['default_availability'] = $this->appointment_form->product->get_default_availability();
		$this->args['availability_span']    = $this->appointment_form->product->get_availability_span();
		$this->args['min_date_js']          = $this->get_min_date();
		$this->args['max_date_js']          = $this->get_max_date();
		$this->args['duration_unit']        = $this->appointment_form->product->get_duration_unit();
		$this->args['appointment_duration'] = $this->appointment_form->product->get_duration();
		$this->args['product_id']           = $this->appointment_form->product->get_id();
		$this->args['is_autoselect']        = $this->appointment_form->product->get_availability_autoselect();
		$this->args['label']                = $this->get_field_label( __( 'Date', 'woocommerce-appointments' ) );
		$this->args['product_type']         = $this->appointment_form->product->get_type();
		$this->args['default_date']         = date( 'Y-m-d', $this->get_default_date() );
	}

	/**
	 * Attempts to find what date to default to in the date picker
	 * by looking at the fist available slot. Otherwise, the current date is used.
	 *
	 * @return int Timestamp of the default date.
	 */
	public function get_default_date() {
		/**
		 * Filter woocommerce_appointments_override_form_default_date
		 *
		 * @since 1.9.6
		 * @param int $default_date unix time stamp.
		 * @param WC_Appointment_Form_Picker $form_instance
		 */
		$default_date = apply_filters( 'woocommerce_appointments_override_form_default_date', null, $this );

		if ( $default_date ) {
			return $default_date;
		}

		$default_date = current_time( 'timestamp' );

		/**
		 * Filter wc_appointments_calendar_default_to_current_date. By default the calendar
		 * will show the current date first. If you would like it to display the first available date
		 * you can return false to this filter and then we'll search for the first available date,
		 * depending on the scheduled days calculation.
		 *
		 * @since 3.5.0
		 * @param bool $default_to_current_date Whether to default to the current date.
		 */
        $default_to_current = apply_filters( 'wc_appointments_calendar_default_to_current_date', true );
        if ( ! $default_to_current || $this->appointment_form->product->get_availability_autoselect() ) {
			/*
			 * Handles the case where a user can set all dates to be not-available by default.
			 * Also they add an availability rule where they are appointable at a future date in time.
			 */

			$now      = strtotime( 'midnight', current_time( 'timestamp' ) );
			$min      = $this->appointment_form->product->get_min_date_a();
			$max      = $this->appointment_form->product->get_max_date_a();
			$min_date = $now;

			if ( ! empty( $min ) ) {
				$min_date = strtotime( "+{$min['value']} {$min['unit']}", $now );
			}

			$max_date = strtotime( "+{$max['value']} {$max['unit']}", $now );

			if ( $this->appointment_form->product->get_availability_autoselect() ) {
				// Autoselect finds the first bookable day client-side from calendar AJAX (staff-aware).
				$default_date = $min_date;
			} else {
				$staff_id = 0;
				$product  = $this->appointment_form->product;
				if ( $product->has_staff() && 'customer' === $product->get_staff_assignment() ) {
					$staff_ids = array_map( 'absint', $product->get_staff_ids() );
					$requested = filter_input( INPUT_GET, 'staff', FILTER_VALIDATE_INT );
					if ( false !== $requested && null !== $requested && in_array( (int) $requested, $staff_ids, true ) ) {
						$staff_id = (int) $requested;
					} elseif ( ! $product->get_staff_nopref() && ! empty( $staff_ids ) ) {
						$staff_id = (int) $staff_ids[0];
					}
				}

				$first_available = \WC_Appointment_Slots_Provider::find_first_available_slot_chunked(
					$product,
					$min_date,
					$max_date,
					$staff_id
				);
				if ( false !== $first_available ) {
					$default_date = $first_available;
				}
			}
		}

		return $default_date;
	}
}
