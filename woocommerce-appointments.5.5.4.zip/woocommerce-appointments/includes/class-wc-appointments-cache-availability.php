<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Appointments_Cache_Availability
 *
 * @package Woocommerce/Appointments
 */

/**
 * WC Appointments Availability Cache: Stored in Custom table.
 *
 * @since 5.0.0
 */
class WC_Appointments_Cache_Availability {

	public const CACHE_TABLE    = 'wc_appointments_availability_cache';
	public const ROLLING_MONTHS = 3;
	public const BACKFILL_FLAG  = 'wc_appointments_availability_cache_backfilled';

	/** Option key: manual re-index progress (status running/queued forces dynamic storefront reads). */
	public const INDEX_PROGRESS_OPTION = 'wc_appointments_index_progress';

	/** Action Scheduler hooks cancelled when manual re-index starts. */
	private const INDEX_AS_HOOKS = [
		'wc_appointments_availability_cache_backfill',
		'wc_appointments_index_availability_rule',
		'wc_appointments_backfill_appointments_batch',
		'wc_appointments_index_appointment',
	];

	/** Option key: rule IDs saved while indexed cache was off; drained when indexing is turned back on. */
	private const PENDING_AVAILABILITY_INDEX_IDS = 'wc_appointments_availability_pending_index_ids';

	/** After a cold cache, synchronously index this many highest-ID rules still missing cache rows (AS covers the rest). */
	private const SYNC_PRIME_UNINDEXED_RULE_CAP = 25;

	// How many days to retain availability/appointment cache rows before pruning.
	public const INDEX_RETENTION_DAYS = 30;

	// Tolerance for horizon check: active rules can be a couple of days off horizon, but not more than this.
	// Rules must reach within this many days of the horizon at all times for reliable index operation.
	public const HORIZON_TOLERANCE_DAYS = 2;

	// New: constrain per-pass work to avoid timeouts/memory spikes.
	public const NON_RRULE_MAX_DAYS_PER_PASS       = 7;    // days per rule per pass during backfill
	public const NON_RRULE_MAX_ROWS_PER_PASS       = 600;  // rows per rule per pass during backfill
	public const RRULE_MAX_OCCURRENCES_PER_PASS    = 800;  // occurrences per rule per pass during backfill
	public const RRULE_MAX_ROWS_PER_PASS           = 600;  // rows per rule per pass during backfill
    /**
     * Ensure we invalidate front-end caches only once per request.
     */
    private static bool $did_invalidate_cache = false;

	/** True while manual re-index AJAX is synchronously indexing rules (not Action Scheduler). */
	private static bool $manual_reindex_inline_rule_index = false;

	/** Malformed product/staff-scoped rules skipped during the current re-index session. */
	private static int $skipped_malformed_rules_session = 0;

	/**
	 * Resource ID to stamp on availability cache rows during the current index pass.
	 * Location kind_id uses product_id; resource kind_id uses this column.
	 */
	private int $index_row_resource_id = 0;

	/**
	 * Track appointment IDs already indexed in this request to prevent double inserts
	 * when both on_appointment_saved and on_appointment_status_event fire.
	 * Value is the status string at the time of last indexing.
	 * Static because the class may be instantiated more than once.
	 *
	 * @var array<int, string>
	 */
	private static array $indexed_this_request = [];

	/**
	 * Check and mark an appointment as indexed in the current request.
	 *
	 * Returns true (skip) only if the appointment was already indexed AND its
	 * status has not changed since. A status change (e.g. in-cart → was-in-cart)
	 * must always be re-processed so the index reflects the new state.
	 *
	 * @param int    $appointment_id  Appointment ID.
	 * @param string $current_status  Current appointment status.
	 * @return bool True if already indexed with same status (should skip), false if should proceed.
	 */
	private function already_indexed_in_request( int $appointment_id, string $current_status = '' ): bool {
		if (
			isset( self::$indexed_this_request[ $appointment_id ] ) &&
			self::$indexed_this_request[ $appointment_id ] === $current_status
		) {
			return true;
		}
		self::$indexed_this_request[ $appointment_id ] = $current_status;
		return false;
	}

	public static function is_index_enabled(): bool {
		return 'yes' === get_option( 'wc_appointments_use_indexed_cache', 'no' );
	}

	/**
	 * Mark the index as stale because data changed while indexing was disabled.
	 * When indexing is re-enabled, this flag triggers an automatic full rebuild.
	 */
	private static function mark_index_stale(): void {
		if ( ! get_option( 'wc_appointments_index_stale' ) ) {
			update_option( 'wc_appointments_index_stale', 1, false );
		}
	}

	/**
	 * Clear the stale flag (called after a rebuild is triggered).
	 */
	private static function clear_index_stale(): void {
		delete_option( 'wc_appointments_index_stale' );
	}

	/**
	 * Check whether the index has been marked stale.
	 */
	public static function is_index_stale(): bool {
		return (bool) get_option( 'wc_appointments_index_stale', false );
	}

	/**
	 * Whether appointable availability rules are indexed for a product/range.
	 *
	 * @param int   $product_id Product ID.
	 * @param int   $start_ts   Range start timestamp.
	 * @param int   $end_ts     Range end timestamp.
	 * @param int[] $staff_ids  Optional staff IDs. Empty = any staff (legacy).
	 * @return bool
	 */
	public static function has_availability_index_for_range( int $product_id, int $start_ts, int $end_ts, array $staff_ids = [] ): bool {
		if ( ! class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			return false;
		}

		$data_store = new WC_Appointments_Availability_Cache_Data_Store();

		return $data_store->has_availability_index_for_range( $product_id, $start_ts, $end_ts, $staff_ids );
	}

	/**
	 * Whether appointment occupancy backfill batches are still running.
	 *
	 * `wc_appointments_backfill_appt_offset` is a pending flag (1 = gaps remain), not a scan cursor.
	 *
	 * @return bool
	 */
	public static function is_appointment_backfill_in_progress(): bool {
		if ( (int) get_option( 'wc_appointments_backfill_appt_offset', 0 ) > 0 ) {
			return true;
		}

		return function_exists( 'as_next_scheduled_action' )
			&& (bool) as_next_scheduled_action( 'wc_appointments_backfill_appointments_batch' );
	}

	/**
	 * Whether a manual reindex is currently in progress.
	 *
	 * @return bool
	 */
	public static function is_manual_reindex_active(): bool {
		$progress = get_option( self::INDEX_PROGRESS_OPTION, [] );
		if ( ! is_array( $progress ) ) {
			return false;
		}

		$status = isset( $progress['status'] ) ? (string) $progress['status'] : 'idle';
		if ( ! in_array( $status, [ 'running', 'queued' ], true ) ) {
			return false;
		}

		// Require manual re-index runtime state so orphaned progress rows cannot block the index forever.
		return (bool) get_option( 'wc_appointments_manual_reindex_full_indexing', false )
			|| (bool) get_option( 'wc_appointments_index_queue', false );
	}

	/**
	 * Allow synchronous rule indexing during manual re-index AJAX chunks.
	 *
	 * @param bool $allow Whether inline rule indexing is permitted.
	 */
	public static function set_manual_reindex_inline_rule_index( bool $allow ): void {
		self::$manual_reindex_inline_rule_index = $allow;
	}

	/**
	 * Whether background index/backfill Action Scheduler work should be suppressed.
	 */
	public static function should_block_background_index_scheduling(): bool {
		return self::is_manual_reindex_active();
	}

	/**
	 * Whether an Action Scheduler index worker should no-op (manual re-index owns the pipeline).
	 */
	public static function should_skip_background_index_worker(): bool {
		if ( ! self::is_manual_reindex_active() ) {
			return false;
		}

		return ! self::$manual_reindex_inline_rule_index;
	}

	/**
	 * Cancel pending background index/backfill Action Scheduler jobs.
	 *
	 * Used when manual re-index starts so only one rebuild pipeline runs.
	 *
	 * @return int Number of hook types processed.
	 */
	public static function cancel_pending_index_actions(): int {
		if ( ! function_exists( 'as_unschedule_all_actions' ) ) {
			return 0;
		}

		$processed = 0;
		foreach ( self::INDEX_AS_HOOKS as $hook ) {
			as_unschedule_all_actions( $hook );
			++$processed;
		}

		return $processed;
	}

	/**
	 * Clear storefront index bypass flags after re-index completes or is released.
	 *
	 * @param string $reason Terminal reason (completed, failed, stopped, etc.).
	 */
	public static function release_storefront_after_reindex( string $reason ): void {
		self::clear_index_skip_flags();
		self::cancel_pending_index_actions();
		self::clear_index_stale();
		// Full reindex already covered every rule; leftover pending IDs (saved while
		// indexing was off) must not keep is_index_ready_for_slots() false forever.
		delete_option( self::PENDING_AVAILABILITY_INDEX_IDS );
	}

	/**
	 * Whether the availability index can serve slot generation for a product/range.
	 *
	 * @param int   $product_id Product ID.
	 * @param int   $start_ts   Range start.
	 * @param int   $end_ts     Range end.
	 * @param int[] $staff_ids  Optional staff filter for readiness (matches fetch).
	 * @return bool
	 */
	public static function is_index_ready_for_slots( int $product_id, int $start_ts, int $end_ts, array $staff_ids = [] ): bool {
		if ( ! self::is_index_enabled() ) {
			return false;
		}

		if ( self::is_manual_reindex_active() ) {
			return false;
		}

		$pending = get_option( self::PENDING_AVAILABILITY_INDEX_IDS, [] );
		if ( is_array( $pending ) && ! empty( $pending ) ) {
			// Indexing is enabled (checked above). Pending IDs are only recorded while
			// indexing was off; leftover entries after re-enable/reindex must not block
			// the storefront forever (manual reindex used to leave them behind).
			delete_option( self::PENDING_AVAILABILITY_INDEX_IDS );
		}

		$range_ready = self::has_availability_index_for_range( $product_id, $start_ts, $end_ts, $staff_ids );

		// Stale means changes landed while indexing was off. Keep rebuilding, but do not
		// force the dynamic minute-mask path forever when this product/range already has
		// indexed availability rows (occupancy falls back to live appointments while stale).
		if ( self::is_index_stale() ) {
			self::ensure_backfill_scheduled();
			if ( $range_ready ) {
				return true;
			}
			return false;
		}

		return $range_ready;
	}

	/**
	 * Ensure async backfill/index jobs are queued (idempotent).
	 *
	 * Schedules at most one pending wc_appointments_availability_cache_backfill action.
	 * The hook intentionally takes no args; run_backfill_batches() fans out per-rule work.
	 */
	public static function ensure_backfill_scheduled(): void {
		if ( ! self::is_index_enabled() ) {
			return;
		}

		if ( self::should_block_background_index_scheduling() ) {
			return;
		}

		if ( ! function_exists( 'as_next_scheduled_action' ) || ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}

		if ( as_next_scheduled_action( 'wc_appointments_availability_cache_backfill' ) ) {
			return;
		}

		as_schedule_single_action( time() + 5, 'wc_appointments_availability_cache_backfill' );
	}

	/**
	 * Option key: product IDs temporarily bypassing index reads (product_id => expiry timestamp).
	 */
	private const SKIP_INDEX_OPTION = 'wc_appointments_skip_index_products';

	/**
	 * @return array<int, int> Product ID => expiry timestamp.
	 */
	private static function get_skip_index_products(): array {
		$map = get_option( self::SKIP_INDEX_OPTION, [] );
		if ( ! is_array( $map ) ) {
			return [];
		}

		$now     = time();
		$changed = false;
		foreach ( $map as $product_id => $expires ) {
			if ( (int) $expires <= $now ) {
				unset( $map[ $product_id ] );
				$changed = true;
			}
		}

		if ( $changed ) {
			if ( [] === $map ) {
				delete_option( self::SKIP_INDEX_OPTION );
			} else {
				update_option( self::SKIP_INDEX_OPTION, $map, false );
			}
		}

		return $map;
	}

	/**
	 * Remember that index reads are unusable for this product (until TTL or re-enable).
	 *
	 * @param int $product_id Product ID.
	 */
	public static function mark_index_unusable_for_product( int $product_id ): void {
		if ( 0 >= $product_id ) {
			return;
		}

		$map = get_option( self::SKIP_INDEX_OPTION, [] );
		if ( ! is_array( $map ) ) {
			$map = [];
		}
		$map[ $product_id ] = time() + HOUR_IN_SECONDS;
		update_option( self::SKIP_INDEX_OPTION, $map, false );
	}

	/**
	 * Clear index bypass for one product after a successful index read.
	 *
	 * @param int $product_id Product ID.
	 */
	public static function clear_index_skip_for_product( int $product_id ): void {
		if ( 0 >= $product_id ) {
			return;
		}

		$map = get_option( self::SKIP_INDEX_OPTION, [] );
		if ( ! is_array( $map ) || ! isset( $map[ $product_id ] ) ) {
			return;
		}

		unset( $map[ $product_id ] );
		if ( [] === $map ) {
			delete_option( self::SKIP_INDEX_OPTION );
		} else {
			update_option( self::SKIP_INDEX_OPTION, $map, false );
		}
	}

	/**
	 * Whether index reads should be bypassed for a product after a recent fallback.
	 *
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function should_skip_index_for_product( int $product_id ): bool {
		if ( 0 >= $product_id ) {
			return false;
		}

		$map = self::get_skip_index_products();

		return isset( $map[ $product_id ] );
	}

	/**
	 * Clear per-product index bypass flags (e.g. when indexing is re-enabled).
	 */
	public static function clear_index_skip_flags(): void {
		delete_option( self::SKIP_INDEX_OPTION );
	}

	/**
	 * Remember a rule that changed while indexed availability was disabled so it can be indexed immediately on re-enable.
	 *
	 * @param int $availability_id Availability rule ID.
	 */
	private function add_pending_availability_index_id( int $availability_id ): void {
		if ( 0 >= $availability_id ) {
			return;
		}
		$pending = get_option( self::PENDING_AVAILABILITY_INDEX_IDS, [] );
		if ( ! is_array( $pending ) ) {
			$pending = [];
		}
		if ( in_array( $availability_id, $pending, true ) ) {
			return;
		}
		$pending[] = $availability_id;
		if ( count( $pending ) > 2000 ) {
			$pending = array_slice( $pending, -2000 );
		}
		update_option( self::PENDING_AVAILABILITY_INDEX_IDS, array_values( $pending ), false );
	}

	/**
	 * Index all rules that were saved while indexing was off (bounded async schedule for overflow).
	 */
	private function drain_pending_availability_index_ids(): void {
		$pending = get_option( self::PENDING_AVAILABILITY_INDEX_IDS, [] );
		delete_option( self::PENDING_AVAILABILITY_INDEX_IDS );
		if ( ! is_array( $pending ) || [] === $pending ) {
			return;
		}
		$pending = array_values( array_unique( array_filter( array_map( 'intval', $pending ) ) ) );
		// Index a bounded batch inline on re-enable (settings save); defer overflow to Action Scheduler.
		$sync_cap = 80;
		foreach ( array_slice( $pending, 0, $sync_cap ) as $rule_id ) {
			if ( 0 < $rule_id ) {
				$this->run_rule_index_pass( $rule_id );
			}
		}
		foreach ( array_slice( $pending, $sync_cap ) as $rule_id ) {
			if ( 0 < $rule_id ) {
				$this->schedule_rule_index( $rule_id );
			}
		}
	}

	/**
	 * Fired when the `wc_appointments_use_indexed_cache` option is updated.
	 * If indexing was just re-enabled and the index is stale, schedule a full rebuild
	 * so the cache table reflects all changes made while indexing was off.
	 *
	 * @param string $old_value Previous option value.
	 * @param string $new_value New option value.
	 */
	public function on_index_option_changed( $old_value, $new_value ): void {
		if ( 'yes' !== $new_value ) {
			return;
		}

		$was_disabled   = ( 'yes' !== $old_value );
		$needs_backfill = $was_disabled || self::is_index_stale();

		$this->ensure_table_exists();

		if ( $was_disabled && self::is_index_stale() ) {
			if ( class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
				$data_store = new \WC_Appointments_Availability_Cache_Data_Store();
				$data_store->clear_all();
			}
		}

		$this->drain_pending_availability_index_ids();

		// Pending rules drain inline on re-enable; release the stale gate so indexed reads work
		// for rules saved while indexing was off (appointment backfill may still run async).
		if ( $was_disabled && self::is_index_stale() ) {
			self::clear_index_stale();
		}

		if ( $needs_backfill ) {
			delete_option( self::BACKFILL_FLAG );
			self::clear_index_skip_flags();
			$this->run_backfill_batches();
		}

		$this->invalidate_frontend_cache();
	}

	/**
	 * Constructor.
	 *
	 * Initializes hooks for availability and appointment updates to maintain the cache.
	 */
	public function __construct() {
		// Instant updates for Availability rules (from data store hooks).
		add_action( 'woocommerce_after_appointments_availability_object_save', [ $this, 'on_availability_saved' ] );
		add_action( 'woocommerce_after_appointments_availability_object_delete', [ $this, 'delete_availability' ] );

		// Instant updates for Appointments.
		add_action( 'woocommerce_after_appointment_object_save', [ $this, 'on_appointment_saved' ], 10, 3 );
		add_action( 'before_delete_post', [ $this, 'delete_appointment_from_post' ] );
		add_action( 'wp_trash_post', [ $this, 'delete_appointment_from_post' ] );
		// When an appointment is restored from trash, re-index it.
		add_action( 'untrash_post', [ $this, 'reindex_appointment_from_untrash' ] );

		// Also, listen to key appointment status events to ensure coverage.
		$statuses = [
			'unpaid',
			'paid',
			'pending-confirmation',
			'confirmed',
			'complete',
			'in-cart',
			'cancelled',
			'cart',
		];

		foreach ( $statuses as $status ) {
			// Accept both ($appointment_id, $appointment) which the core hook emits.
			add_action( 'woocommerce_appointment_' . $status, [ $this, 'on_appointment_status_event' ], 10, 2 );
		}

		// Bridge: when payment completes for an order, index all its appointments.
		add_action( 'woocommerce_pre_payment_complete', [ $this, 'index_order_appointments' ], 10, 1 );
		// Also run after payment complete (fires for most gateways) and after checkout order creation.
		add_action( 'woocommerce_payment_complete', [ $this, 'index_order_appointments' ], 20, 1 );
		add_action( 'woocommerce_checkout_order_processed', [ $this, 'index_order_appointments' ], 20, 1 );

		// Daily cron to extend RRULE occurrences rolling window.
		add_action( 'woocommerce_appointments_daily_cleanup', [ $this, 'extend_rrule_horizon' ] );

		// One-off async backfill to index existing future rules and appointments.
		add_action( 'init', [ $this, 'maybe_schedule_backfill' ], 20 );
		add_action( 'init', [ $this, 'maybe_process_appointment_backfill' ], 21 );
		add_action( 'wc_appointments_availability_cache_backfill', [ $this, 'run_backfill_batches' ] );

		// Register appointment backfill batch worker and per-appointment worker (scheduled via Action Scheduler).
		add_action( 'wc_appointments_backfill_appointments_batch', [ $this, 'run_backfill_appointments_batch' ], 10, 1 );
		add_action( 'wc_appointments_index_appointment', [ $this, 'index_appointment_from_id' ], 10, 1 );

		// Per-rule async indexing after interactive saves.
		add_action( 'wc_appointments_index_availability_rule', [ $this, 'run_rule_index_pass' ], 10, 1 );

		// When daily cleanup marks rules expired, drop any leftover cache rows for them.
		add_action( 'wc_appointments_after_cleanup_expired_availability', [ $this, 'on_availability_rules_expired' ], 10, 1 );

		// When an appointment is removed from the cart, delete its index rows (simple path).
		add_action( 'woocommerce_remove_cart_item', [ $this, 'delete_appointment_from_cart' ], 10, 2 );

		// When the entire cart is emptied, remove all related in-cart appointment rows from the index.
		// Use the "before" hook to still have access to cart items.
		add_action( 'woocommerce_before_cart_emptied', [ $this, 'delete_appointments_from_cart_items' ], 10, 1 );
		// After emptying, invalidate the frontend cache once.
		add_action(
             'woocommerce_cart_emptied',
            function(): void {
			$this->invalidate_frontend_cache();
		},
            10,
            0
            );

		// Optional: update progress incrementally when a per-rule pass runs in the background.
		add_action( 'wc_appointments_index_availability_rule', [ $this, 'note_rule_scheduled' ], 5, 1 );

		// When the indexing option is toggled on, rebuild if the index was marked stale.
		add_action( 'update_option_wc_appointments_use_indexed_cache', [ $this, 'on_index_option_changed' ], 10, 2 );
	}

	/**
	 * Ensure table exists.
	 *
	 * Checks if the cache table exists and creates it if missing.
	 *
	 * @return bool True if table exists or was created.
	 */
	public function ensure_table_exists(): bool {
		global $wpdb;
		$table = $this->table();

		// Quick probe
		$exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
		if ( $exists === $table ) {
			$this->ensure_scope_enum_includes_location_resource();
			return true;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		// Schema matching the installation table creation
		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL auto_increment,
			source enum('availability','appointment') NOT NULL,
			source_id bigint(20) unsigned NOT NULL,
			product_id bigint(20) unsigned NOT NULL default 0,
			staff_id bigint(20) unsigned NOT NULL default 0,
			resource_id bigint(20) unsigned NOT NULL default 0,
			scope enum('global','product','staff','location','resource') NOT NULL default 'global',
			appointable varchar(5) NOT NULL default 'yes',
			priority int(11) NOT NULL default 10,
			ordering int(11) NOT NULL default 0,
			qty bigint(20) NOT NULL default 0,
			start_ts bigint(20) NOT NULL,
			end_ts bigint(20) NOT NULL,
			range_type varchar(60) NULL,
			rule_kind varchar(100) NULL,
			status varchar(100) NULL,
			date_created datetime NULL default NULL,
			date_modified datetime NULL default NULL,
			PRIMARY KEY (id),
			KEY src (source, source_id),
			KEY time_idx (start_ts, end_ts),
			KEY product_staff (product_id, staff_id),
			KEY avail_global_lookup (source, scope, start_ts, end_ts, staff_id, priority),
			KEY avail_product_lookup (source, scope, product_id, start_ts, end_ts, staff_id, priority),
			KEY avail_staff_lookup (source, scope, staff_id, start_ts, end_ts, priority),
			KEY priority_sort (priority DESC),
			KEY idx_resource (resource_id, start_ts, end_ts),
			UNIQUE KEY uniq_occurrence (source, source_id, product_id, staff_id, resource_id, start_ts, end_ts)
		) {$charset_collate}";

		dbDelta( $sql );

		$exists_after = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
		return ( $exists_after === $table );
	}

	/**
	 * Expand scope enum for location/resource open/closed rules (existing installs).
	 *
	 * @since 5.5.0
	 */
	private function ensure_scope_enum_includes_location_resource(): void {
		global $wpdb;

		$table = $this->table();
		$col  = $wpdb->get_row( "SHOW COLUMNS FROM `{$table}` LIKE 'scope'", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! is_array( $col ) || empty( $col['Type'] ) ) {
			return;
		}

		$type = strtolower( (string) $col['Type'] );
		if ( false !== strpos( $type, "'location'" ) && false !== strpos( $type, "'resource'" ) ) {
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table from $this->table() / wpdb prefix; DDL cannot use prepare placeholders for identifiers.
		$wpdb->query( "ALTER TABLE `{$table}` MODIFY COLUMN scope enum('global','product','staff','location','resource') NOT NULL default 'global'" );
	}


	/**
	 * Update the last successful indexing timestamp for automatic rule indexing.
	 * This tracks when individual rules are indexed automatically (not during manual re-index).
	 *
	 * @param int $rules_count Number of rules indexed in this operation.
	 * @param int $appointments_count Number of appointments indexed in this operation.
	 */
	private function update_last_successful_indexing( int $rules_count = 1, int $appointments_count = 0 ): void {
		// Get existing last completed info
		$last_completed = get_option( 'wc_appointments_last_index_completed', [] );
		$existing_rules = (int) ( $last_completed['total_rules'] ?? 0 );
		$existing_appointments = (int) ( $last_completed['total_appointments'] ?? 0 );

		// Update with new totals
		update_option(
             'wc_appointments_last_index_completed',
            [
				'timestamp' => time(),
				'total_rules' => $existing_rules + $rules_count,
				'total_appointments' => $existing_appointments + $appointments_count,
				'current_run_rules' => $rules_count,
				'current_run_appointments' => $appointments_count,
				'auto_indexed' => true, // Flag to indicate this was automatic indexing
			],
            false
            );
	}


	/**
     * Optional: when a background per-rule job enqueues (or runs), record a tick.
     * This keeps progress moving even if UI polls later.
     */
    public function note_rule_scheduled( int $availability_id ): void {
		if ( ! self::is_manual_reindex_active() ) {
			return;
		}

		$progress = get_option( self::INDEX_PROGRESS_OPTION, [] );
		if ( empty( $progress ) ) {
			return;
		}
		// Only note activity by updating the timestamp; do not mutate counters here.
		$progress['updated_at'] = time();
		update_option( self::INDEX_PROGRESS_OPTION, $progress, false );
	}

	/**
	 * Centralized, idempotent cache invalidation for any availability/appointment write.
	 * Keeps front-end transient/object caches in sync with minimal overhead.
	 */
	private function invalidate_frontend_cache(): void {
		if ( self::$did_invalidate_cache ) {
			return;
		}

		self::$did_invalidate_cache = true;

		if ( ! class_exists( 'WC_Appointments_Cache' ) ) {
			return;
		}

		// Known groups used around availability rendering.
		WC_Appointments_Cache::invalidate_cache_group( 'appointments' );
		WC_Appointments_Cache::invalidate_cache_group( 'schedule_ts' );
		WC_Appointments_Cache::invalidate_cache_group( 'schedule_dr' );
		WC_Appointments_Cache::invalidate_cache_group( 'schedule_fo' );
		WC_Appointments_Cache::invalidate_cache_group( 'staff_ps' );
		WC_Appointments_Cache::invalidate_cache_group( 'schedule_staff_ids' );
	}

	public function maybe_schedule_backfill(): void {
		if ( self::should_block_background_index_scheduling() ) {
			return;
		}

		$backfill_complete = (bool) get_option( self::BACKFILL_FLAG );
		$backfill_scheduled = function_exists( 'as_next_scheduled_action' ) ? as_next_scheduled_action( 'wc_appointments_availability_cache_backfill' ) : false;
		// Only schedule if not already backfilled (idempotent) and not already scheduled.
		if ( $backfill_complete ) {
			return;
		}
		if ( ! $backfill_scheduled ) {
			as_schedule_single_action( time() + 60, 'wc_appointments_availability_cache_backfill' );
		}
	}

	/**
	 * Clear or re-queue appointment backfill when pending but no batch is scheduled.
	 */
	public function maybe_process_appointment_backfill(): void {
		if ( ! self::is_index_enabled() || self::should_block_background_index_scheduling() ) {
			return;
		}

		$pending = (int) get_option( 'wc_appointments_backfill_appt_offset', 0 );
		if ( $pending <= 0 ) {
			return;
		}

		if ( class_exists( 'WC_Appointment_Data_Store' ) ) {
			$gaps = WC_Appointment_Data_Store::get_future_appointment_ids_missing_from_cache( $this->now_ts(), 1 );

			if ( empty( $gaps ) ) {
				update_option( 'wc_appointments_backfill_appt_offset', 0, false );
				wp_cache_delete( 'wc_appointments_backfill_appt_offset', 'options' );
				return;
			}
		}

		if ( function_exists( 'as_next_scheduled_action' )
			&& as_next_scheduled_action( 'wc_appointments_backfill_appointments_batch' ) ) {
			return;
		}

		$this->schedule_backfill_appointments();
	}

	/**
	 * Mark backfill complete.
	 *
	 * Sets the option flag indicating backfill has completed.
	 */
	private function mark_backfill_complete(): void {
		update_option( self::BACKFILL_FLAG, 1, false );
		self::clear_index_stale();
		if ( ! self::is_manual_reindex_active() ) {
			self::clear_index_skip_flags();
		}
	}

	private function table(): string {
		global $wpdb;
		return $wpdb->prefix . self::CACHE_TABLE;
	}

	/**
	 * Get horizon timestamp (rolling months ahead in UTC).
	 *
	 * @return int Timestamp (strtotime returns int for valid date strings).
	 */
	private function horizon_ts(): int {
		// Rolling months ahead (UTC) - configurable via admin settings.
		$months = wc_appointments_get_cache_horizon_months();
		$ts = strtotime( '+' . $months . ' months UTC' );
		// strtotime can return false on failure, but with this format it should always succeed.
		return $ts ?: time();
	}

	private function now_ts(): int {
		// UTC timestamp.
		return time();
	}

	/**
	 * Check if an end timestamp should be indexed based on retention period and indexing mode.
	 *
	 * @param int $end_ts The end timestamp to check.
	 * @return bool True if should be indexed, false otherwise.
	 */
	private function should_index_end_ts( int $end_ts ): bool {
		$now = $this->now_ts();
		$force_full_index = (bool) get_option( 'wc_appointments_manual_reindex_full_indexing', false );

		if ( ! $force_full_index ) {
			// Automatic indexing: only index future occurrences
			return $end_ts > $now;
		}
        // Manual re-indexing: include occurrences within retention period
        $retention_days = self::INDEX_RETENTION_DAYS;
        $retention_cut = strtotime( '-' . $retention_days . ' days UTC', $now );
        return $end_ts >= $retention_cut;
	}

	/**
     * Fetch the latest cached end_ts for an availability rule.
     * Returns 0 if nothing cached yet.
     */
    private function get_availability_last_cached_end_ts( int $availability_id ): int {
		if ( ! class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			return 0;
		}

		$data_store = new WC_Appointments_Availability_Cache_Data_Store();
		$rows = $data_store->get_items(
            [
				'source' => 'availability',
				'source_id' => $availability_id,
				'order_by' => 'end_ts',
				'order' => 'DESC',
				'limit' => 1,
			]
            );

		if ( empty( $rows ) ) {
			return 0;
		}

		return max( 0, (int) $rows[0]['end_ts'] );
	}

	/**
	 * Log a message (no-op; used by some internal paths).
	 *
	 * @param string $message The log message.
	 * @param string $level   The log level (unused).
	 */
	private function log_index_message( string $message, string $level = 'info' ): void {
		// No-op.
	}

	/**
	 * Check if a rule's last cached end timestamp is within tolerance of the horizon.
	 * Rules must reach within HORIZON_TOLERANCE_DAYS of the horizon at all times for reliable index operation.
	 *
	 * @param int $last_cached_end_ts The last cached end timestamp for the rule.
	 * @param int|null $horizon Optional. Horizon timestamp. If not provided, uses current horizon.
	 * @return bool True if the rule is within tolerance of the horizon, false otherwise.
	 */
	private function is_rule_within_horizon_tolerance( int $last_cached_end_ts, ?int $horizon = null ): bool {
		if ( 0 >= $last_cached_end_ts ) {
			return false;
		}

		if ( null === $horizon ) {
			$horizon = $this->horizon_ts();
		}

		$tolerance_seconds = self::HORIZON_TOLERANCE_DAYS * DAY_IN_SECONDS;
		$min_acceptable_end_ts = $horizon - $tolerance_seconds;

		return $last_cached_end_ts >= $min_acceptable_end_ts;
	}

	/**
	 * Check if a rule has constraints (to_date or RRULE UNTIL) that prevent it from reaching the horizon.
	 * If a rule has such constraints, it cannot be extended beyond them, so we should skip it in periodic checks.
	 *
	 * @param int $availability_id The availability rule ID.
	 * @param int|null $horizon Optional. Horizon timestamp. If not provided, uses current horizon.
	 * @return array{has_constraint: bool, max_possible_end_ts: int, constraint_type: string} Information about constraints.
	 */
	private function check_rule_constraints( int $availability_id, ?int $horizon = null ): array {
		if ( null === $horizon ) {
			$horizon = $this->horizon_ts();
		}

		$result = [
			'has_constraint' => false,
			'max_possible_end_ts' => $horizon,
			'constraint_type' => '',
		];

		$availability = get_wc_appointments_availability( $availability_id );

		if ( ! $availability ) {
			return $result;
		}

		$range_type = trim( (string) $availability->get_range_type() );
		$to_date = trim( (string) $availability->get_to_date() );
		$to_date_ts = false;
		if ( '' !== $to_date ) {
			$to_date_ts = strtotime( $to_date . ' 23:59:59 UTC' );
		}

		$constraint_ts = 0;
		$constraint_type = '';

		$custom_range_end_ts = $this->resolve_custom_range_end_ts( $availability, $horizon );
		if ( null !== $custom_range_end_ts ) {
			$constraint_ts   = $custom_range_end_ts;
			$constraint_type = 'custom_date_range';
		}

		// Check for seasonal months rules (e.g., only applies to January each year)
		if ( 'months' === $range_type ) {
			$from_range = trim( (string) $availability->get_from_range() );
			$to_range = trim( (string) $availability->get_to_range() );

			if ( '' !== $from_range && '' !== $to_range ) {
				$from_month = (int) $from_range;
				$to_month = (int) $to_range;
				$now = $this->now_ts();
				$current_year = (int) gmdate( 'Y', $now );
				$horizon_month = (int) gmdate( 'n', $horizon );
				$horizon_year = (int) gmdate( 'Y', $horizon );

				// Find the last occurrence of this seasonal pattern before or at the horizon
				$last_occurrence_end_ts = false;

				// Check each year from current to horizon year
				for ( $year = $current_year; $year <= $horizon_year; $year++ ) {
					$year_end_month = ( $year === $horizon_year ) ? $horizon_month : 12;

					// Check if any month in this year's range falls within the seasonal pattern
					for ( $month = 1; $month <= $year_end_month; $month++ ) {
						if ( $this->is_month_in_range( $month, $from_month, $to_month ) ) {
							// Calculate end of this month occurrence
							$next_month = $month + 1;
							$next_year = $year;
							if ( 12 < $next_month ) {
								$next_month = 1;
								$next_year++;
							}
							$month_end_ts = strtotime( sprintf( '%d-%02d-01 00:00:00 UTC', $next_year, $next_month ) ) - 1;
							if ( $month_end_ts <= $horizon ) {
								$last_occurrence_end_ts = $month_end_ts;
							}
						}
					}
				}

				// If we found a last occurrence and it's before the horizon, this is a constraint
				if ($last_occurrence_end_ts && $last_occurrence_end_ts < $horizon && ( ! $constraint_ts || $last_occurrence_end_ts < $constraint_ts )) {
                    $constraint_ts = $last_occurrence_end_ts;
                    $constraint_type = 'seasonal_months';
                }
			}
		}

		// Check for to_date constraint
		if ($to_date_ts && $to_date_ts < $horizon && ( ! $constraint_ts || $to_date_ts < $constraint_ts )) {
            $constraint_ts = $to_date_ts;
            $constraint_type = 'to_date';
        }

		// Check for RRULE UNTIL constraint
		$rrule = trim( (string) $availability->get_rrule() );
		$until_ts = false;
		if ('' !== $rrule && stripos( $rrule, 'UNTIL' ) !== false && preg_match( '/(?:^|;)\s*UNTIL=([0-9]{8}(T[0-9]{6}Z?)?)/i', $rrule, $m )) {
            $until_raw = $m[1];
            if ( strlen( $until_raw ) === 8 ) {
					$until_str = substr( $until_raw, 0, 4 ) . '-' . substr( $until_raw, 4, 2 ) . '-' . substr( $until_raw, 6, 2 ) . ' 23:59:59 UTC';
					$until_ts = strtotime( $until_str );
				} else {
				$ymd = substr( $until_raw, 0, 8 );
				$hms = preg_replace( '/[^0-9]/', '', substr( $until_raw, 9 ) );
				if ( strlen( $hms ) >= 6 ) {
					$until_str = substr( $ymd, 0, 4 ) . '-' . substr( $ymd, 4, 2 ) . '-' . substr( $ymd, 6, 2 ) .
						' ' . substr( $hms, 0, 2 ) . ':' . substr( $hms, 2, 2 ) . ':' . substr( $hms, 4, 2 ) . ' UTC';
					$until_ts = strtotime( $until_str );
					}
				}
        }

		if ( $until_ts && $until_ts < $horizon && ( ! $constraint_ts || $until_ts < $constraint_ts ) ) {
			$constraint_ts = $until_ts;
			$constraint_type = 'rrule_until';
		}

		if ( $constraint_ts ) {
			$result['has_constraint'] = true;
			$result['max_possible_end_ts'] = $constraint_ts;
			$result['constraint_type'] = $constraint_type;
		}

		return $result;
	}

	/**
	 * Parse custom range_type end timestamp when from/to range fields are set.
	 *
	 * @param WC_Appointments_Availability $availability Availability rule.
	 * @param int                          $horizon_ts   Cache horizon timestamp.
	 * @return int|null End timestamp or null when not applicable.
	 */
	private function resolve_custom_range_end_ts( WC_Appointments_Availability $availability, int $horizon_ts ): ?int {
		if ( 'custom' !== trim( (string) $availability->get_range_type() ) ) {
			return null;
		}

		$to_range = trim( (string) apply_filters( 'woocommerce_appointments_availability_to_range', $availability->get_to_range(), $availability ) );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to_range ) ) {
			return null;
		}

		$to_range_end_ts = strtotime( $to_range . ' 23:59:59 UTC' );
		if ( false === $to_range_end_ts || $to_range_end_ts <= 0 || $to_range_end_ts >= $horizon_ts ) {
			return null;
		}

		return $to_range_end_ts;
	}


	/**
     * Unified public API: index an availability rule by ID or object.
     * - If $availability is int, loads rule and indexes it.
     * - If the object provided, preserves existing behavior.
     *
     * @param int|WC_Appointments_Availability $availability
     */
    public function index_availability( $availability ): void {
		// Accept the previous signature (object) to remain BC.
		if ( is_object( $availability ) ) {
			// The existing implementation below.
			$id = (int) $availability->get_id();
			if ( 0 === $id ) {
				return;
			}
			$kind    = (string) $availability->get_kind();
			$kind_id = (string) $availability->get_kind_id();
			$scope_info = $this->derive_scope( $kind, $kind_id );
			try {
				// Clear existing cache rows for this source.
				$this->delete_rows( 'availability', $id );
				$rows_inserted = $this->index_availability_rule(
					$availability,
					[
						'max_occurrences' => PHP_INT_MAX,
						'max_rows'        => PHP_INT_MAX,
					],
					[
						'max_days' => PHP_INT_MAX,
						'max_rows' => PHP_INT_MAX,
					]
				);
				$this->schedule_rule_index( $id );
				$this->invalidate_frontend_cache();
			} catch ( \Exception $e ) {
				// Do not rethrow: corrupted rule should not break other indexing.
			}
			return;
		}
		// New: integer entry point.
		$availability_id = (int) $availability;
		if ( 0 >= $availability_id ) {
			return;
		}
		// Load via helper to get a WC_Appointments_Availability object.
		try {
			$availability_obj = get_wc_appointments_availability( $availability_id );
		} catch ( \Exception $e ) {
			return;
		}
		if ( ! is_object( $availability_obj ) ) {
			return;
		}
		try {
			$this->index_availability( $availability_obj );
			$this->invalidate_frontend_cache();
		} catch ( \Exception $e ) {
			// Do not rethrow: corrupted rule should not break other indexing.
		}
	}

	/**
     * Schedule a per-rule index continuation in the background.
     */
    private function schedule_rule_index( int $availability_id ): void {
		if ( self::should_block_background_index_scheduling() ) {
			return;
		}

		// Avoid duplicate schedules for the same rule.
		if ( ! as_next_scheduled_action( 'wc_appointments_index_availability_rule', [ $availability_id ] ) ) {
			as_schedule_single_action( time() + 15, 'wc_appointments_index_availability_rule', [ $availability_id ] );
		}
	}

	/**
     * Background pass: index one availability rule in constrained batches.
     * Reschedules itself until the rule reaches the rolling horizon.
     */
    public function run_rule_index_pass( int $availability_id ): void {
		if ( ! self::is_index_enabled() ) {
			return;
		}

		if ( self::should_skip_background_index_worker() ) {
			return;
		}

		if ( 0 >= $availability_id ) {
			return;
		}

		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );

		$force_full_index = (bool) get_option( 'wc_appointments_manual_reindex_full_indexing', false );
		$horizon          = $this->horizon_ts();
		$days_to_horizon  = (int) ceil( max( 0, $horizon - $this->now_ts() ) / DAY_IN_SECONDS );
		$last_cached_end  = $this->get_availability_last_cached_end_ts( $availability_id );

		try {
			$availability = get_wc_appointments_availability( $availability_id );
		} catch ( \Exception $e ) {
			return;
		}
		if ( ! $availability || ! is_object( $availability ) ) {
			return;
		}

		$rrule = (string) $availability->get_rrule();
		$range_type = (string) $availability->get_range_type();
		$from_date = trim( (string) $availability->get_from_date() );
		$to_date = trim( (string) $availability->get_to_date() );
		$rows_inserted = 0;

		// Even with force_full_index, use larger but still reasonable limits to avoid timeouts
		// This ensures we can process large rules without hitting PHP execution time limits
		$rrule_max_occurrences = $force_full_index ? 5000 : self::RRULE_MAX_OCCURRENCES_PER_PASS;
		$rrule_max_rows = $force_full_index ? 5000 : self::RRULE_MAX_ROWS_PER_PASS;
		$non_rrule_max_days = $force_full_index ? $days_to_horizon : self::NON_RRULE_MAX_DAYS_PER_PASS;
		$non_rrule_max_rows = $force_full_index ? 5000 : self::NON_RRULE_MAX_ROWS_PER_PASS;

		// Open-ended recurring non-RRULE rules (e.g. time:1 Mondays) should be
		// primed to the horizon on cold start. Otherwise the first pass only writes
		// ~7 days and users see availability drop after the first matching weekday.
		$is_time_family_type = ( 'time' === $range_type || 'time:range' === $range_type || 0 === strpos( $range_type, 'time:' ) );
		$is_open_ended_non_rrule = '' === $rrule && '' === $from_date && '' === $to_date;
		$is_recurring_non_rrule = in_array( $range_type, [ 'days', 'months' ], true ) || $is_time_family_type;
		$prime_to_horizon = ! $force_full_index && 0 >= (int) $last_cached_end && $is_open_ended_non_rrule && $is_recurring_non_rrule;
		if ( $prime_to_horizon ) {
			$non_rrule_max_days = max( self::NON_RRULE_MAX_DAYS_PER_PASS, min( 365, $days_to_horizon + self::HORIZON_TOLERANCE_DAYS ) );
		}

		try {
			$rows_inserted = $this->index_availability_rule(
				$availability,
				[
					'max_occurrences' => $rrule_max_occurrences,
					'max_rows'        => $rrule_max_rows,
				],
				[
					'max_days' => $non_rrule_max_days,
					'max_rows' => $non_rrule_max_rows,
				],
				true
			);
		} catch ( \Exception $e ) {
			// Do not rethrow: one corrupted rule should not break other rule indexing.
			return;
		}

		$after_index_end = $this->get_availability_last_cached_end_ts( $availability_id );
		$is_within_tolerance = $this->is_rule_within_horizon_tolerance( $after_index_end, $horizon );

		if ( ! $is_within_tolerance ) {
			$this->schedule_rule_index( $availability_id );
		}

		// Update last successful indexing timestamp for automatic rule indexing
		$this->update_last_successful_indexing( 1, 0 );
	}

	/**
     * When an appointment item is removed from the cart, delete its cached "appointment" rows.
     * Keep it simple: if the cart item carries an appointment ID, use it; otherwise skip.
     *
     * @param string  $cart_item_key
     * @param WC_Cart $cart
     */
    public function delete_appointment_from_cart( $cart_item_key, $cart ): void {
 		if ( ! $cart || ! is_object( $cart ) || ! method_exists( $cart, 'get_cart_item' ) ) {
 			return;
 		}

		$cart_item = $cart->get_cart_item( $cart_item_key );
		if ( empty( $cart_item ) || ! wc_appointments_validate_cart_item( $cart_item ) ) {
			return;
		}

		$appointment_id = wc_appointments_get_cart_item_hold_appointment_id( $cart_item );
		if ( 0 < $appointment_id ) {
			$this->delete_appointment( $appointment_id );
		}
 	}

	/**
     * Bulk delete all appointment rows originating from items in the cart being emptied.
     * Runs before WooCommerce clears the cart so we can inspect items.
     *
     * @param WC_Cart|bool $cart Cart instance or legacy boolean flag.
     */
    public function delete_appointments_from_cart_items( $cart ): void {
		// Ensure wp_loaded has been fired before accessing the cart to avoid WooCommerce warnings.
		if ( ! did_action( 'wp_loaded' ) ) {
			return;
		}

		// Some integrations call this hook with a boolean (true). Normalize to a cart instance.
		$cart_obj = ( is_object( $cart ) && method_exists( $cart, 'get_cart' ) ) ? $cart : WC()->cart;
		if ( ! $cart_obj || ! method_exists( $cart_obj, 'get_cart' ) ) {
			return;
		}

		// Do not remove in-cart index rows when the cart is being "emptied" only as part of a
		// payment gateway simulation (e.g. WooCommerce PayPal Payments ppc-simulate-cart).
		// The cart is refilled in the same request; removing rows would drop holds and allow overbooking.
		if ( class_exists( 'WC_Appointment_Cart_Manager' ) && WC_Appointment_Cart_Manager::is_cart_simulation_request() ) {
			$this->log_index_message(
				'delete_appointments_from_cart_items: skipped (cart simulation request); in-cart index rows preserved',
				'info'
			);
			return;
		}

		$items = $cart_obj->get_cart();
		if ( empty( $items ) || ! is_array( $items ) ) {
			return;
		}

		foreach ( $items as $cart_item ) {
			if ( ! wc_appointments_validate_cart_item( $cart_item ) ) {
				continue;
			}
			if ( ! class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
				continue;
			}

			$data_store = new WC_Appointments_Availability_Cache_Data_Store();

			$appt_id = wc_appointments_get_cart_item_hold_appointment_id( $cart_item );
			if ( 0 < $appt_id ) {
				$data_store->delete_by_criteria(
					array(
						'source'    => 'appointment',
						'source_id' => $appt_id,
						'status'    => 'in-cart',
					)
				);
			}
 		}

		// Invalidate front-end caches once after removals.
		$this->invalidate_frontend_cache();
 	}

	/**
     * Unified public API: delete all cache rows for a specific Appointment.
     */
    public function delete_appointment( int $appointment_id ): void {
		if ( 0 >= $appointment_id ) {
			return;
		}
		$this->delete_rows( 'appointment', $appointment_id );
		$this->invalidate_frontend_cache();
	}


	/**
     * Unified public API: delete all cache rows for an availability rule.
     *
     * @param int $availability_id
     */
    public function delete_availability( $availability_id ): void {
		$this->delete_rows( 'availability', (int) $availability_id );
		$this->invalidate_frontend_cache();
	}

	/**
	 * After daily cleanup marks rules expired: purge their cache rows (indexer never expands them).
	 *
	 * @param int[] $availability_ids Expired rule IDs.
	 */
	public function on_availability_rules_expired( $availability_ids ): void {
		if ( ! is_array( $availability_ids ) || [] === $availability_ids ) {
			return;
		}
		foreach ( $availability_ids as $availability_id ) {
			$id = (int) $availability_id;
			if ( 0 < $id ) {
				$this->delete_rows( 'availability', $id );
			}
		}
		$this->invalidate_frontend_cache();
	}

	/**
     * Hook wrapper: after availability save -> index by ID.
     *
     * @param object $availability
     */
    public function on_availability_saved( $availability ): void {
		$index_enabled    = self::is_index_enabled();
		$availability_id = ( is_object( $availability ) && method_exists( $availability, 'get_id' ) ) ? (int) $availability->get_id() : 0;
		if ( ! $index_enabled ) {
			self::mark_index_stale();
			if ( 0 < $availability_id ) {
				$this->add_pending_availability_index_id( $availability_id );
			}
			return;
		}

		if ( is_object( $availability ) && method_exists( $availability, 'get_id' ) ) {
			$this->index_availability( (int) $availability->get_id() );
		}
	}

	/**
	 * Called after an appointment object is saved.
	 * @param WC_Appointment       $appointment
	 * @param mixed                $data_store
	 * @param array<string, mixed> $changes
	 */
	public function on_appointment_saved( $appointment, $data_store = null, $changes = [] ): void {
		if ( ! self::is_index_enabled() ) {
			self::mark_index_stale();
			return;
		}

		// Be defensive about the object.
		if ( ! $appointment || ! is_object( $appointment ) || ! method_exists( $appointment, 'get_id' ) ) {
			return;
		}

		$current_status = method_exists( $appointment, 'get_status' ) ? (string) $appointment->get_status() : '';

		// Guard: both on_appointment_saved and on_appointment_status_event can fire
		// for the same appointment within a single request. Skip only if the status
		// has NOT changed since last indexing (e.g. two redundant save calls).
		if ( $this->already_indexed_in_request( (int) $appointment->get_id(), $current_status ) ) {
			return;
		}

		// Ensure cache rows reflect the latest snapshot.
		$this->delete_rows( 'appointment', (int) $appointment->get_id() );
		$this->insert_appointment_row( $appointment );

		$this->invalidate_frontend_cache();
	}

	/**
	 * Called when appointment status transitions.
	 * Core emits ($appointment_id, $appointment).
	 *
	 * @param int             $appointment_id
	 * @param WC_Appointment  $appointment
	 */
	public function on_appointment_status_event( $appointment_id, $appointment = null ): void {
		if ( ! self::is_index_enabled() ) {
			self::mark_index_stale();
			return;
		}

		$appointment_id = (int) $appointment_id;

		// Prefer the object if passed, otherwise try to load.
		if ( ! $appointment || ! is_object( $appointment ) ) {
			try {
				$appointment = get_wc_appointment( $appointment_id );
			} catch ( \Exception $e ) {
				return;
			}
		}
		if ( ! $appointment || ! method_exists( $appointment, 'get_id' ) ) {
			return;
		}

		$current_status = method_exists( $appointment, 'get_status' ) ? (string) $appointment->get_status() : '';

		// Guard: both on_appointment_saved and on_appointment_status_event can fire
		// for the same appointment within a single request. Skip only if the status
		// has NOT changed since last indexing.
		if ( $this->already_indexed_in_request( (int) $appointment->get_id(), $current_status ) ) {
			return;
		}

		// Re-index this appointment row to reflect new status/qty/staff etc.
		$this->delete_rows( 'appointment', (int) $appointment->get_id() );
		$this->insert_appointment_row( $appointment );

		$this->invalidate_frontend_cache();
	}

	/**
     * Bridge payment completion -> index all appointments for that order.
     *
     * @param int|string $order_id
     */
    public function index_order_appointments( $order_id ): void {
		$order_id = (int) $order_id;
		if ( 0 >= $order_id ) {
			return;
		}

		if ( ! class_exists( 'WC_Appointment_Data_Store' ) ) {
			return;
		}

		$appointment_ids = (array) WC_Appointment_Data_Store::get_appointment_ids_from_order_id( $order_id );
		if ( [] === $appointment_ids ) {
			return;
		}

		foreach ( $appointment_ids as $aid ) {
			$aid = (int) $aid;
			if ( 0 >= $aid ) {
				continue;
			}
			try {
				$appointment = get_wc_appointment( $aid );
			} catch ( \Exception $e ) {
				continue;
			}
			if ( ! $appointment ) {
				continue;
			}
			$this->delete_rows( 'appointment', $aid );
			$this->insert_appointment_row( $appointment );
		}

		$this->invalidate_frontend_cache();
	}

	/**
	 * Delete appointment from post ID.
	 *
	 * @param int $post_id
	 * @since 5.0.0
	 */
	public function delete_appointment_from_post( $post_id ): void {
		if ( 'wc_appointment' !== get_post_type( $post_id ) ) {
			return;
		}

		$this->delete_rows( 'appointment', (int) $post_id );
	}

	/**
     * Re-index appointment after it is restored from trash.
     *
     * @param int $post_id
     */
    public function reindex_appointment_from_untrash( $post_id ): void {
		// Only handle appointment post type.
		if ( 'wc_appointment' !== get_post_type( $post_id ) ) {
			return;
		}

		// Respect setting: only index when feature is enabled.
		if ( ! self::is_index_enabled() ) {
			return;
		}

		// Re-index the appointment to add it back to the cache index.
		$this->index_appointment( (int) $post_id );
	}

	/**
     * Unified public API: index a single appointment by ID.
     * Idempotent. Internally forwards to existing implementation.
     */
    public function index_appointment( int $appointment_id ): void {
		if ( 0 >= $appointment_id ) {
			return;
		}
		$this->index_appointment_from_id( $appointment_id );
	}

	/**
	 * Index appointment from ID.
	 *
	 * Loads an appointment by ID and indexes it.
	 *
	 * @param int $appointment_id Appointment ID.
	 */
	public function index_appointment_from_id( $appointment_id ): void {
		$appointment_id = (int) $appointment_id;
		if ( 0 >= $appointment_id ) {
			return;
		}

		if ( self::should_skip_background_index_worker() ) {
			return;
		}

		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );

		try {
			$appointment = get_wc_appointment( $appointment_id );
		} catch ( Exception $e ) {
			return;
		}
		$this->delete_rows( 'appointment', $appointment_id );
		$this->insert_appointment_row( $appointment );

		$this->invalidate_frontend_cache();
	}

	/**
	 * @param WC_Appointment $appointment Appointment object.
	 */
	private function insert_appointment_row( $appointment ): void {
		$product_id      = (int) ( method_exists( $appointment, 'get_product_id' ) ? $appointment->get_product_id() : 0 );
		// Legacy single staff id.
		$legacy_staff_id = (int) ( method_exists( $appointment, 'get_staff_id' ) ? $appointment->get_staff_id() : 0 );
		// Multiple staff ids support.
		$staff_ids       = method_exists( $appointment, 'get_staff_ids' ) ? (array) $appointment->get_staff_ids() : [];
		// Normalize staff IDs: merge legacy single staff id if provided, ensure ints, unique, allow empty -> [0].
		if ( 0 < $legacy_staff_id ) {
			$staff_ids[] = $legacy_staff_id;
		}
		$staff_ids = array_values( array_unique( array_map( 'intval', array_filter( $staff_ids, static fn( $v ): bool => (int) $v >= 0 ) ) ) );
		if ( [] === $staff_ids ) {
			$staff_ids = [ 0 ]; // no specific staff assigned
		}

		$qty = (int) ( method_exists( $appointment, 'get_qty' ) ? $appointment->get_qty() : 1 );

		$status = method_exists( $appointment, 'get_status' ) ? $appointment->get_status() : 'trash';

		// Do not cache appointments that were in the cart.
		if ( 'was-in-cart' === $status ) {
			return;
		}
		$start    = method_exists( $appointment, 'get_start' ) ? $appointment->get_start() : '';
		$end      = method_exists( $appointment, 'get_end' ) ? $appointment->get_end() : '';
		$start_ts = is_numeric( $start ) ? (int) $start : ( $start ? strtotime( $start . ' UTC' ) : 0 );
		$end_ts   = is_numeric( $end ) ? (int) $end : ( $end ? strtotime( $end . ' UTC' ) : 0 );

		if ( ! $start_ts || ! $end_ts || $end_ts <= $start_ts ) {
			return;
		}

		// During manual re-indexing, include past appointments within the retention period
		// For automatic indexing, only index future appointments
		if ( ! $this->should_index_end_ts( $end_ts ) ) {
			return;
		}

		if ( ! class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			return;
		}

		$rows = [];
		$now  = current_time( 'mysql' );
		foreach ( $staff_ids as $sid ) {
			$rows[] = [
				'source'        => 'appointment',
				'source_id'     => (int) $appointment->get_id(),
				'product_id'    => $product_id,
				'staff_id'      => (int) $sid,
				'resource_id'   => 0,
				'scope'         => 'product',
				'appointable'   => 'no',
				'priority'      => 10,
				'qty'           => max( 1, $qty ),
				'start_ts'      => $start_ts,
				'end_ts'        => $end_ts,
				'range_type'    => 'appointment',
				'rule_kind'     => 'appointment',
				'status'        => $status,
				'date_created'  => $now,
				'date_modified' => $now,
			];
		}

		// Resource allocation rows (one per allocation, staff_id=0).
		$allocations = is_a( $appointment, 'WC_Appointment' ) ? $appointment->get_resource_allocations() : [];
		if ( [] !== $allocations ) {
			$alloc_product = null;
			if ( class_exists( 'WC_Product_Appointment' ) ) {
				$alloc_product = wc_get_product( $product_id );
			}
			$pad_before = 0;
			$pad_after  = 0;
			if ( $alloc_product instanceof WC_Product_Appointment ) {
				$pad_before = (int) $alloc_product->get_padding_before_in_minutes() * 60;
				$pad_after  = (int) $alloc_product->get_padding_after_in_minutes() * 60;
			}
			$res_start = $start_ts - $pad_before;
			$res_end   = $end_ts + $pad_after;

			foreach ( $allocations as $alloc ) {
				$rid = (int) ( $alloc['resource_id'] ?? 0 );
				if ( $rid <= 0 ) {
					continue;
				}
				$rows[] = [
					'source'        => 'appointment',
					'source_id'     => (int) $appointment->get_id(),
					'product_id'    => $product_id,
					'staff_id'      => 0,
					'resource_id'   => $rid,
					'scope'         => 'product',
					'appointable'   => 'no',
					'priority'      => 10,
					'qty'           => max( 1, (int) ( $alloc['qty_consumed'] ?? 1 ) ),
					'start_ts'      => $res_start,
					'end_ts'        => $res_end,
					'range_type'    => 'appointment',
					'rule_kind'     => 'appointment',
					'status'        => $status,
					'date_created'  => $now,
					'date_modified' => $now,
				];
			}
		}

		$data_store = new WC_Appointments_Availability_Cache_Data_Store();
		$data_store->bulk_insert( $rows );
	}

	/**
	 * Delete rows.
	 *
	 * Deletes cache rows for a specific source and ID.
	 *
	 * @param string $source    Source type (availability, appointment).
	 * @param int    $source_id Source ID.
	 * @return int Number of rows deleted.
	 */
	private function delete_rows( string $source, int $source_id ): int {
		if ( ! class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			return 0;
		}

		$data_store = new WC_Appointments_Availability_Cache_Data_Store();
		return $data_store->delete_by_source( $source, $source_id );
	}

	/**
	 * Whether an appointment has a future occupancy row in the cache.
	 *
	 * @param int $appointment_id Appointment ID.
	 * @param int $now            UTC timestamp.
	 */
	private function has_appointment_occupancy_cache_row( int $appointment_id, int $now ): bool {
		global $wpdb;

		$appointment_id = absint( $appointment_id );
		if ( $appointment_id <= 0 ) {
			return false;
		}

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$wpdb->prefix}wc_appointments_availability_cache WHERE source = 'appointment' AND source_id = %d AND end_ts > %d LIMIT 1",
				$appointment_id,
				$now
			)
		);
	}

	/**
	 * Extend a civil-midnight (minute 1440) window for minute/hour product duration tail.
	 *
	 * Matches dynamic {@see WC_Appointment_Slots_Rule_Minutes::minute_range_from_times()}:
	 * only evening segments that end at midnight (from_min > 0) get the duration tail.
	 * Full-day 00:00–24:00 windows must NOT extend into the next civil day.
	 *
	 * @param int    $eff_to_min  End minute on the civil-day axis (1440 = midnight).
	 * @param string $appointable Availability row appointable flag ('yes' / 'no').
	 * @param int    $mask_tail   Product duration in minutes.
	 * @param int    $from_min    Start minute on the civil-day axis.
	 * @return int
	 */
	private function eff_to_min_with_mask_tail( int $eff_to_min, string $appointable, int $mask_tail, int $from_min = 0 ): int {
		if ( 'yes' !== $appointable || $mask_tail <= 0 || 1440 !== $eff_to_min || $from_min <= 0 ) {
			return $eff_to_min;
		}

		return 1440 + $mask_tail;
	}

	/**
	 * Index one availability rule (RRULE expand vs non-RRULE), matching dynamic type resolution.
	 *
	 * @param object               $availability            Availability object.
	 * @param array<string, mixed> $rrule_limits            RRULE pass limits.
	 * @param array<string, mixed> $non_rrule_limits        Non-RRULE pass limits.
	 * @param bool                 $purge_orphan_rrule_rows Drop legacy RRULE expand rows when rrule is set on a non-rrule type.
	 * @return int Rows inserted.
	 */
	private function index_availability_rule( object $availability, array $rrule_limits, array $non_rrule_limits, bool $purge_orphan_rrule_rows = false ): int {
		$kind       = (string) $availability->get_kind();
		$kind_id    = (string) $availability->get_kind_id();
		$scope_info = $this->derive_scope( $kind, $kind_id );
		if ( ! empty( $scope_info['malformed'] ) ) {
			$this->skip_malformed_availability_rule( $availability );
			return 0;
		}

		if ( wc_appointments_availability_should_expand_rrule_index( $availability ) ) {
			$rows = $this->expand_rrule_availability( $availability, (string) $availability->get_rrule(), $rrule_limits );
			return $rows;
		}

		if ( $purge_orphan_rrule_rows ) {
			$rule_id = (int) $availability->get_id();
			if ( 0 < $rule_id && '' !== trim( (string) $availability->get_rrule() ) && 0 < $this->delete_rows( 'availability', $rule_id ) ) {
				$this->invalidate_frontend_cache();
			}
		}

		return $this->index_non_rrule_availability( $availability, $non_rrule_limits );
	}

	/**
	 * @param object               $availability Availability object.
	 * @param array<string, mixed> $limits       Processing limits.
	 * @return int Rows inserted.
	 */
	private function index_non_rrule_availability( object $availability, array $limits = [] ): int {
		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );

		$kind        = (string) $availability->get_kind();
		$kind_id     = (string) $availability->get_kind_id();
		$range_type  = (string) $availability->get_range_type();
		$appointable = (string) $availability->get_appointable();
		$priority    = (int) $availability->get_priority();
		$ordering    = (int) $availability->get_ordering();
		$qty         = (int) $availability->get_qty();

		if ( wc_appointments_availability_range_type_is_expired( $range_type ) ) {
			// Keep cache clear: expired rules must never leave rows that confuse readers,
			// and readiness must not wait for expansions that will never run.
			$this->delete_rows( 'availability', (int) $availability->get_id() );
			return 0;
		}

		$status = '';

		// Determine scope/product/staff from 'kind' and 'kind_id'.
		$scope_info = $this->derive_scope( $kind, $kind_id );
		$product_id = $scope_info['product_id'];
		$staff_id   = $scope_info['staff_id'];
		$scope      = $scope_info['scope'];
		$this->index_row_resource_id = (int) $scope_info['resource_id'];

		// Window (DATE scope, not DATETIME). These strings are interpreted by the rule manager.
		$from_date = trim( (string) $availability->get_from_date() ); // e.g. '2025-01-01' or empty
		$to_date   = trim( (string) $availability->get_to_date() );   // e.g. '2025-12-31' or empty
		$from_range_raw = trim( (string) $availability->get_from_range() );
		$to_range_raw   = trim( (string) $availability->get_to_range() );

		// Some "custom" rules store their date window in from_range/to_range (YYYY-MM-DD)
		// while from_date/to_date remain empty. Without anchoring to that window, bounded
		// per-pass indexing (max_days=7) starts from "today" and can miss far-future blocks
		// in the first pass, making indexed availability disagree with dynamic rules.
		$looks_like_date_range = static function( string $value ): bool {
			return (bool) preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value );
		};
		if ( 'custom' === $range_type && '' === $from_date && '' === $to_date && $looks_like_date_range( $from_range_raw ) && $looks_like_date_range( $to_range_raw ) ) {
			$from_date = $from_range_raw;
			$to_date   = $to_range_raw;
		}

		// Recurring time rules (time, time:1–7) are NOT date-bounded — they repeat every day
		// (or every matching weekday). Old plugin versions (≤5.2.x) sometimes stored stale dates
		// in from_date/to_date for these rule types, causing the indexer to generate cache entries
		// for only that single date instead of all future days. Ignore those fields here.
		$is_recurring_time = ( 'time' === $range_type || ( 0 === strpos( $range_type, 'time:' ) && 'time:range' !== $range_type ) );
		// days/months/weeks repeat by calendar unit; stale from_date/to_date from other types
		// must not clamp the index window (same class of bug as recurring time rules above).
		$is_recurring_day_month_week = in_array( $range_type, [ 'days', 'months', 'weeks' ], true );
		if ( $is_recurring_time || $is_recurring_day_month_week ) {
			$from_date = '';
			$to_date   = '';
		}

		// Build processing context similar to production rule evaluation.
		$product_obj = $product_id ? wc_get_product( $product_id ) : null;
		$mask_tail   = 0;
		if ( $product_obj instanceof WC_Product_Appointment
			&& in_array( $product_obj->get_duration_unit(), [ 'minute', 'hour' ], true ) ) {
			$intervals = $product_obj->get_intervals();
			$mask_tail = max( 0, (int) ( $intervals[0] ?? 0 ) );
		}

		// Normalize the single rule using the Rule Manager (for non-time rules fallback).
		if ( ! class_exists( 'WC_Product_Appointment_Rule_Manager' ) ) {
			return 0;
		}
		$processed_rules = WC_Product_Appointment_Rule_Manager::process_availability_rules(
		    [ $availability ],
		    $scope,
		    false,
		    $product_obj instanceof WC_Product_Appointment ? $product_obj : null,
		);
		$rule = $processed_rules[0] ?? null;
		if ( ! $rule ) {
			return 0;
		}

		$now     = $this->now_ts();
		$horizon = $this->horizon_ts();
		$force_full_index = (bool) get_option( 'wc_appointments_manual_reindex_full_indexing', false );

		// During manual re-indexing, include past occurrences within retention period
		// For automatic indexing, only index from today forward
		$retention_days = self::INDEX_RETENTION_DAYS;
		$retention_cut = strtotime( '-' . $retention_days . ' days UTC', $now );
		$min_start_day = $force_full_index ? $retention_cut : strtotime( 'today 00:00:00 UTC', $now );

		// Determine day iteration bounds (inclusive) using only DATEs. If missing, clamp appropriately.
		$start_day_ts = '' !== $from_date ? strtotime( $from_date . ' 00:00:00 UTC' ) : $min_start_day;
		$end_day_ts   = '' !== $to_date ? strtotime( $to_date . ' 23:59:59 UTC' ) : $horizon;

		$start_day_ts = max( $min_start_day, $start_day_ts );
		$end_day_ts   = min( $horizon, $end_day_ts );

		if ( $end_day_ts <= $start_day_ts ) {
			return 0;
		}

		$availability_id = (int) $availability->get_id();
		$last_cached_end = $this->get_availability_last_cached_end_ts( $availability_id );
		$force_full_index = (bool) get_option( 'wc_appointments_manual_reindex_full_indexing', false );

		if ( 0 < $last_cached_end ) {
			$resume_from_day = strtotime( gmdate( 'Y-m-d 00:00:00', $last_cached_end - 1 ) . ' UTC' );
			$start_day_ts    = max( $start_day_ts, $resume_from_day );

			// For recurring rules with force_full_index, extend end_day_ts to include next occurrence
			// But still respect reasonable limits to avoid timeouts
			if ( $force_full_index && '' === $to_date && ( strpos( $range_type, 'time:' ) === 0 || 'days' === $range_type ) ) {
				$tolerance_seconds = self::HORIZON_TOLERANCE_DAYS * DAY_IN_SECONDS;
				$extended_end_ts = $horizon + $tolerance_seconds + ( 7 * DAY_IN_SECONDS );
				$end_day_ts = max( $end_day_ts, $extended_end_ts );
			}
		}

		$max_days = (int) ( $limits['max_days'] ?? PHP_INT_MAX );
		$max_rows = (int) ( $limits['max_rows'] ?? PHP_INT_MAX );

		// Handle days range differently - iteration by full day.
		if ( 'days' === $range_type ) {
			$from_rng = trim( (string) $availability->get_from_range() ); // day number 1-7 (1=Monday, 7=Sunday)
			$to_rng   = trim( (string) $availability->get_to_range() );   // day number 1-7

			if ( '' !== $from_rng && '' !== $to_rng ) {
				$from_day = (int) $from_rng;
				$to_day   = (int) $to_rng;

				// Validate day range (1-7)
				if ( 1 <= $from_day && 7 >= $from_day && 1 <= $to_day && 7 >= $to_day ) {
					return $this->index_days_range_availability( $availability, $from_day, $to_day, $start_day_ts, $end_day_ts );
				}
			}
			return 0; // Invalid day range
		}

		// Handle month ranges differently - iterate by month instead of day
		if ( 'months' === $range_type ) {
			$from_rng = trim( (string) $availability->get_from_range() ); // month number 1-12
			$to_rng   = trim( (string) $availability->get_to_range() );   // month number 1-12

			if ( '' !== $from_rng && '' !== $to_rng ) {
				$from_month = (int) $from_rng;
				$to_month   = (int) $to_rng;

				// Validate month range (1-12)
				if ( 1 <= $from_month && 12 >= $from_month && 1 <= $to_month && 12 >= $to_month ) {
					return $this->index_month_range_availability( $availability, $from_month, $to_month, $start_day_ts, $end_day_ts, $horizon );
				}
			}
			return 0; // Invalid month range
		}

		// Special-case: custom:daterange should index a single span from from_date/from_range to to_date/to_range.
		if ( 'custom:daterange' === $range_type ) {
			$from_rng = trim( (string) $availability->get_from_range() ); // HH:MM
			$to_rng   = trim( (string) $availability->get_to_range() );   // HH:MM

			if ( '' !== $from_date && '' !== $to_date && '' !== $from_rng && '' !== $to_rng ) {
				$to_minutes = static function( string $hhmm ): int {
					$parts = explode( ':', $hhmm );
					$h = (int) ( $parts[0] ?? 0 );
					$m = (int) ( $parts[1] ?? 0 );
					return max( 0, min( 23, $h ) ) * 60 + max( 0, min( 59, $m ) );
				};

				$from_min = $to_minutes( $from_rng );
				$to_min   = $to_minutes( $to_rng );

				$start_day = strtotime( $from_date . ' 00:00:00 UTC' );
				$end_day   = strtotime( $to_date . ' 00:00:00 UTC' );

				$occ_start = $start_day + ( $from_min * 60 );
				$occ_end   = $end_day + ( $to_min * 60 );

				if ( $this->should_index_end_ts( $occ_end ) && $occ_end > $occ_start ) {
					$rows = [
						[
							'source'        => 'availability',
							'source_id'     => (int) $availability->get_id(),
							'product_id'    => $product_id,
							'staff_id'      => $staff_id,
							'scope'         => $scope,
							'appointable'   => $appointable,
							'priority'      => $priority,
							'ordering'      => $ordering,
							'qty'           => $qty,
							'start_ts'      => $occ_start,
							'end_ts'        => $occ_end,
							'range_type'    => $range_type,
							'rule_kind'     => $kind,
							'status'        => $status,
							'date_created'  => current_time( 'mysql' ),
							'date_modified' => current_time( 'mysql' ),
						],
					];

					return $this->bulk_insert_cache_rows( $rows );
				}

				// If invalid or reversed bounds, do not index.
				return 0;
			}
			// If missing bounds, fall through to the default time/day indexing below.
		}

		// Parse explicit time range if available (e.g., 'time' rules), to avoid per-minute expansion.
		$from_rng = trim( (string) $availability->get_from_range() ); // e.g. '08:00'
		$to_rng   = trim( (string) $availability->get_to_range() );   // e.g. '04:00'
		$has_time_bounds = ( '' !== $from_rng && '' !== $to_rng );

		$rows        = [];
		$cursor      = (int) strtotime( gmdate( 'Y-m-d 00:00:00', $start_day_ts ) . ' UTC' );
		$days_done   = 0;
		$rows_done   = 0;
		$inserted    = 0;
		$indexed_by_weekday = ( 0 === strpos( $range_type, 'time:' ) && 'time:range' !== $range_type );
		$indexed_by_custom_dates = ( 'custom' === $range_type );

		while ( $cursor <= $end_day_ts ) {
			if ( $days_done >= $max_days || $rows_done >= $max_rows ) {
				break;
			}

			// Check if this day matches the range_type day specification
			$day_matches = true;
			if ( strpos( $range_type, 'time:' ) === 0 ) {
				$day_spec = (int) substr( $range_type, 5 ); // Extract day number from 'time:X'
				if ( 1 <= $day_spec && 7 >= $day_spec ) {
					$current_day_of_week = (int) gmdate( 'N', $cursor ); // 1=Monday, 7=Sunday
					$day_matches = ( $current_day_of_week === $day_spec );
				}
			}

			// For custom range types, check if the current date is within from_range and to_range.
			if ( 'custom' === $range_type ) {
				$from_range_date = trim( (string) $availability->get_from_range() );
				$to_range_date = trim( (string) $availability->get_to_range() );

				if ( '' !== $from_range_date && '' !== $to_range_date ) {
					$current_date = gmdate( 'Y-m-d', $cursor );
					$day_matches = ( $current_date >= $from_range_date && $current_date <= $to_range_date );
				}
			}

			// Skip this day if it doesn't match the day specification
			if ( ! $day_matches ) {
				$cursor += DAY_IN_SECONDS;
				// Weekday/custom filters scan the full window; only count every-day rules toward max_days.
				if ( ! $indexed_by_weekday && ! $indexed_by_custom_dates ) {
					$days_done++;
				}
				continue;
			}

			// Skip this day if it's already fully cached (unless force_full_index is enabled for recurring rules)
			if ( 0 < $last_cached_end && ( ! $force_full_index || ( strpos( $range_type, 'time:' ) !== 0 && 'days' !== $range_type ) ) ) {
				$day_end_ts = $cursor + DAY_IN_SECONDS;
				if ( $day_end_ts <= $last_cached_end ) {
					$cursor += DAY_IN_SECONDS;
					continue;
				}
			}

			// Prefer explicit time bounds when present (faster than per-minute expansion).
			$from_rng = trim( (string) $availability->get_from_range() );
			$to_rng   = trim( (string) $availability->get_to_range() );
			$has_time_bounds = ( '' !== $from_rng && '' !== $to_rng );

			if ( $has_time_bounds ) {
				$to_minutes = static function( string $hhmm ): int {
					$parts = explode( ':', $hhmm );
					$h = (int) ( $parts[0] ?? 0 );
					$m = (int) ( $parts[1] ?? 0 );
					if ( 24 === $h && 0 === $m ) {
						return 1440;
					}
					return max( 0, min( 23, $h ) ) * 60 + max( 0, min( 59, $m ) );
				};

				$from_min = $to_minutes( $from_rng );
				$to_min   = $to_minutes( $to_rng );

				// True wrap: end before start on the clock. `00:00` after a morning start is end of civil day (same as Rule_Minutes::is_wrap_midnight_hhmm_pair).
				$end_at_civil_midnight = ( 0 === $to_min && $from_min > 0 );
				$wrap_midnight         = ( $to_min < $from_min ) && ! $end_at_civil_midnight;

				if ( $wrap_midnight ) {
					// Overnight rule: save a single cached row spanning into the next day
					// start_ts = today's from_min, end_ts = next day's to_min (no +1 minute).
					$occ_start = $cursor + ( $from_min * 60 );
					$occ_end   = $cursor + DAY_IN_SECONDS + ( $to_min * 60 );

					if ( $this->should_index_end_ts( $occ_end ) && $occ_end > $occ_start ) {
						$rows[] = [
							'source' => 'availability',
							'source_id' => $availability_id,
							'product_id' => $product_id,
							'staff_id' => $staff_id,
							'scope' => $scope,
							'appointable' => $appointable,
							'priority' => $priority,
							'ordering' => $ordering,
							'qty' => $qty,
							'start_ts' => $occ_start,
							'end_ts' => $occ_end,
							'range_type' => $range_type,
							'rule_kind' => $kind,
							'status' => $status,
							'date_created' => current_time( 'mysql' ),
							'date_modified' => current_time( 'mysql' ),
						];
						$rows_done++;

						if ( count( $rows ) >= 200 ) {
							$inserted += $this->bulk_insert_cache_rows( $rows );
							$rows = [];
						}
					}
				} elseif ( $from_min === $to_min ) {
					// Whole-day rule: when from_range equals to_range, this represents the entire day.
					// from_min is 0 for true whole-day — do not duration-tail into the next civil day.
					$eff_to_min = $this->eff_to_min_with_mask_tail( 1440, $appointable, $mask_tail, (int) $from_min );
					$occ_start  = $cursor;
					$occ_end    = $cursor + ( $eff_to_min * 60 );

					if ( $this->should_index_end_ts( $occ_end ) ) {
						$rows[] = [
							'source' => 'availability',
							'source_id' => $availability_id,
							'product_id' => $product_id,
							'staff_id' => $staff_id,
							'scope' => $scope,
							'appointable' => $appointable,
							'priority' => $priority,
							'ordering' => $ordering,
							'qty' => $qty,
							'start_ts' => $occ_start,
							'end_ts' => $occ_end,
							'range_type' => $range_type,
							'rule_kind' => $kind,
							'status' => $status,
							'date_created' => current_time( 'mysql' ),
							'date_modified' => current_time( 'mysql' ),
						];
						$rows_done++;

						if ( count( $rows ) >= 200 ) {
							$inserted += $this->bulk_insert_cache_rows( $rows );
							$rows = [];
						}
					}
				} else {
					// Same-day rule: one row for today's window (no +1 minute).
					// Stored `00:00` as "to" after a morning start means end of civil day, not minute 0.
					$eff_to_min = $to_min;
					$end_at_civil_midnight = ( 0 === $to_min && $from_min > 0 );
					if ( $end_at_civil_midnight ) {
						$eff_to_min = 1440;
					} else {
						$eff_to_min = $this->eff_to_min_with_mask_tail( $eff_to_min, $appointable, $mask_tail, (int) $from_min );
					}
					$occ_start = $cursor + ( $from_min * 60 );
					$occ_end   = $cursor + ( $eff_to_min * 60 );

					if ( $this->should_index_end_ts( $occ_end ) && $occ_end > $occ_start ) {
						$rows[] = [
							'source' => 'availability',
							'source_id' => $availability_id,
							'product_id' => $product_id,
							'staff_id' => $staff_id,
							'scope' => $scope,
							'appointable' => $appointable,
							'priority' => $priority,
							'ordering' => $ordering,
							'qty' => $qty,
							'start_ts' => $occ_start,
							'end_ts' => $occ_end,
							'range_type' => $range_type,
							'rule_kind' => $kind,
							'status' => $status,
							'date_created' => current_time( 'mysql' ),
							'date_modified' => current_time( 'mysql' ),
						];
						$rows_done++;

						if ( count( $rows ) >= 200 ) {
							$inserted += $this->bulk_insert_cache_rows( $rows );
							$rows = [];
						}
					}
				}
			} else {
				// Fallback to rule manager ranges; still index a single row per contiguous range,
				// and if the range wraps (end_min < start_min), save ONE row spanning into the next day.
				$minute_data = WC_Product_Appointment_Rule_Manager::get_rule_minute_range( $rule, $cursor );

				$ranges = [];
				if ( isset( $minute_data['ranges'] ) && is_array( $minute_data['ranges'] ) && ( isset( $minute_data['ranges'] ) && [] !== $minute_data['ranges'] ) ) {
					$ranges = $minute_data['ranges'];
				} else {
					$minutes = $minute_data['minutes'] ?? [];
					if ( is_array( $minutes ) && [] !== $minutes ) {
						$ranges = $this->compress_minutes_to_ranges( $minutes );
					}
				}

				foreach ( $ranges as $range ) {
						if ( $rows_done >= $max_rows ) {
						break 2;
						}

						$start_min = (int) $range[0];
						$end_min   = (int) $range[1];

						if ( $end_min < $start_min ) {
						// Overnight: one row spanning to next day end (no +1 minute).
						$occ_start = $cursor + ( $start_min * 60 );
						$occ_end   = $cursor + DAY_IN_SECONDS + ( $end_min * 60 );

						if ( $this->should_index_end_ts( $occ_end ) && $occ_end > $occ_start ) {
							$rows[] = [
								'source' => 'availability',
								'source_id' => $availability_id,
								'product_id' => $product_id,
								'staff_id' => $staff_id,
								'scope' => $scope,
								'appointable' => $appointable,
								'priority' => $priority,
								'ordering' => $ordering,
								'qty' => $qty,
								'start_ts' => $occ_start,
								'end_ts' => $occ_end,
								'range_type' => $range_type,
								'rule_kind' => $kind,
								'status' => $status,
								'date_created' => current_time( 'mysql' ),
								'date_modified' => current_time( 'mysql' ),
							];
							$rows_done++;

							if ( count( $rows ) >= 200 ) {
								$inserted += $this->bulk_insert_cache_rows( $rows );
								$rows = [];
								}
							}
						} else {
						// Normal same-day range as a single row (no +1 minute).
						$occ_start = $cursor + ( $start_min * 60 );
						$occ_end   = $cursor + ( $end_min * 60 );

						if ( $this->should_index_end_ts( $occ_end ) && $occ_end > $occ_start ) {
							$rows[] = [
								'source' => 'availability',
								'source_id' => $availability_id,
								'product_id' => $product_id,
								'staff_id' => $staff_id,
								'scope' => $scope,
								'appointable' => $appointable,
								'priority' => $priority,
								'ordering' => $ordering,
								'qty' => $qty,
								'start_ts' => $occ_start,
								'end_ts' => $occ_end,
								'range_type' => $range_type,
								'rule_kind' => $kind,
								'status' => $status,
								'date_created' => current_time( 'mysql' ),
								'date_modified' => current_time( 'mysql' ),
							];
							$rows_done++;

							if ( count( $rows ) >= 200 ) {
								$inserted += $this->bulk_insert_cache_rows( $rows );
								$rows = [];
								}
							}
						}
					}
			}

			$cursor += DAY_IN_SECONDS;
			$days_done++;

			if ( $cursor > ( $end_day_ts + DAY_IN_SECONDS ) ) {
				break;
			}
		}

		if ( [] !== $rows ) {
			$inserted += $this->bulk_insert_cache_rows( $rows );
		}

		return $inserted;
	}

	/**
     * Index availability for day-of-week ranges - check each day and index full days.
     *
     * @param WC_Appointments_Availability $availability
     * @param int $from_day Day number 1-7 (1=Monday, 7=Sunday)
     * @param int $to_day Day number 1-7
     * @param int $start_day_ts
     * @param int $end_day_ts
     * @return int Number of rows inserted
     */
    private function index_days_range_availability( object $availability, int $from_day, int $to_day, $start_day_ts, $end_day_ts ): int {
		$availability_id = (int) $availability->get_id();
		$kind            = (string) $availability->get_kind();
		$kind_id         = (string) $availability->get_kind_id();
		$range_type      = (string) $availability->get_range_type();
		$appointable     = (string) $availability->get_appointable();
		$priority        = (int) $availability->get_priority();
		$ordering        = (int) $availability->get_ordering();
		$qty             = (int) $availability->get_qty();
		$status          = ''; #status is not available with original availability.

		// Determine scope/product/staff from 'kind' and 'kind_id'.
		$scope_info = $this->derive_scope( $kind, $kind_id );
		$product_id = $scope_info['product_id'];
		$staff_id   = $scope_info['staff_id'];
		$scope      = $scope_info['scope'];
		$this->index_row_resource_id = (int) $scope_info['resource_id'];

		#error_log( var_export( $availability, true ) );

		// Create a day-of-week range (handle wrapping, e.g., Friday to Monday)
		$target_days = [];
		if ( $to_day >= $from_day ) {
			// Normal range (e.g., Monday to Friday)
			for ( $day = $from_day; $day <= $to_day; $day++ ) {
				$target_days[] = $day;
			}
		} else {
			// Wrapping range (e.g., Friday to Monday)
			for ( $day = $from_day; 7 >= $day; $day++ ) {
				$target_days[] = $day;
			}
			for ( $day = 1; $day <= $to_day; $day++ ) {
				$target_days[] = $day;
			}
		}

		// Safety check: if no target days, return early
		if ( [] === $target_days ) {
			return 0;
		}

		$rows = [];
		// Force cursor to midnight UTC — $start_day_ts may carry a non-midnight
		// offset from the resume logic or caller, which would produce rows with
		// wrong intra-day timestamps for full-day rules.
		$cursor = (int) strtotime( gmdate( 'Y-m-d 00:00:00', $start_day_ts ) . ' UTC' );
		$inserted = 0;
		$days_processed = 0;
		$max_days = 365; // Safety limit to prevent infinite loops

		while ( $cursor <= $end_day_ts && $days_processed < $max_days ) {
			// Get day of the week (1=Monday, 7=Sunday)
			$day_of_week = (int) gmdate( 'N', $cursor );

			// Check if this day matches our target days
			if ( in_array( $day_of_week, $target_days, true ) ) {
				// Index the full day (00:00:00 to 23:59:59)
				$day_start = $cursor;
				#$day_end = $cursor + 86400 - 1; // 23:59:59 (86400 = 24 * 60 * 60)
				$day_end = $cursor + 86400; // the next day at noon.

				// Index if within retention period (for manual re-indexing) or in the future (for automatic)
				if ( $this->should_index_end_ts( $day_end ) ) {
					$rows[] = [
						'source' => 'availability',
						'source_id' => $availability_id,
						'product_id' => $product_id,
						'staff_id' => $staff_id,
						'scope' => $scope,
						'appointable' => $appointable,
						'priority' => $priority,
						'ordering' => $ordering,
						'qty' => $qty,
						'start_ts' => $day_start,
						'end_ts' => $day_end,
						'range_type' => $range_type,
						'rule_kind' => $kind,
						'status' => $status,
						'date_created' => current_time( 'mysql' ),
						'date_modified' => current_time( 'mysql' ),
					];

					if ( count( $rows ) >= 200 ) {
						$inserted += $this->bulk_insert_cache_rows( $rows );
						$rows = [];
					}
				}
			}

			// Move to the next day.
			$cursor += 86400; // 24 * 60 * 60 seconds
			$days_processed++;
		}

		if ( [] !== $rows ) {
			$inserted += $this->bulk_insert_cache_rows( $rows );
		}

		return $inserted;
	}

	/**
     * Index availability for month ranges - iterate by month instead of day.
     *
     * @param WC_Appointments_Availability $availability
     * @param int $from_month Month number 1-12
     * @param int $to_month Month number 1-12
     * @param int $start_day_ts
     * @param int $end_day_ts
     * @return int Number of rows inserted
     */
    private function index_month_range_availability( object $availability, int $from_month, int $to_month, $start_day_ts, $end_day_ts, int $horizon ): int {

		$availability_id = (int) $availability->get_id();
		$kind            = (string) $availability->get_kind();
		$kind_id         = (string) $availability->get_kind_id();
		$range_type      = (string) $availability->get_range_type();
		$appointable     = (string) $availability->get_appointable();
		$priority        = (int) $availability->get_priority();
		$ordering        = (int) $availability->get_ordering();
		$qty             = (int) $availability->get_qty();
		$status          = ''; #status is not available with original availability.

		// Determine scope/product/staff from 'kind' and 'kind_id'.
		$scope_info = $this->derive_scope( $kind, $kind_id );
		$product_id = $scope_info['product_id'];
		$staff_id   = $scope_info['staff_id'];
		$scope      = $scope_info['scope'];
		$this->index_row_resource_id = (int) $scope_info['resource_id'];

		$rows     = [];
		$inserted = 0;

		// Get the year range to iterate through
		$start_year = (int) gmdate( 'Y', $start_day_ts );
		$end_year   = (int) gmdate( 'Y', $end_day_ts );

		// Iterate through years and months
		for ( $year = $start_year; $year <= $end_year; $year++ ) {
			// Determine which months to process for this year
			$year_start_month = ( $year === $start_year ) ? (int) gmdate( 'n', $start_day_ts ) : 1;
			$year_end_month   = ( $year === $end_year ) ? (int) gmdate( 'n', $end_day_ts ) : 12;

			for ( $month = $year_start_month; $month <= $year_end_month; $month++ ) {
				// Check if this month is in the availability range
				if ( $this->is_month_in_range( $month, $from_month, $to_month ) ) {
					// Create a month range: first day 00:00:00 to first day of next month 00:00:00
					$month_start = strtotime( sprintf( '%d-%02d-01 00:00:00 UTC', $year, $month ) );
					$next_month = $month + 1;
					$next_year = $year;
					if ( 12 < $next_month ) {
						$next_month = 1;
						$next_year++;
					}
					$month_end = strtotime( sprintf( '%d-%02d-01 00:00:00 UTC', $next_year, $next_month ) );

					// Ensure the month range is within our bounds and within retention period (for manual re-indexing) or future (for automatic)
					if ( $this->should_index_end_ts( $month_end ) && $month_start <= $horizon ) {
						// Always use whole month ranges regardless of horizon bounds
						$occ_start = $month_start;
						$occ_end   = $month_end;

						if ( $occ_end > $occ_start ) {
							$rows[] = [
								'source' => 'availability',
								'source_id' => $availability_id,
								'product_id' => $product_id,
								'staff_id' => $staff_id,
								'scope' => $scope,
								'appointable' => $appointable,
								'priority' => $priority,
								'ordering' => $ordering,
								'qty' => $qty,
								'start_ts' => $occ_start,
								'end_ts' => $occ_end,
								'range_type' => $range_type,
								'rule_kind' => $kind,
								'status' => $status,
								'date_created' => current_time( 'mysql' ),
								'date_modified' => current_time( 'mysql' ),
							];

							if ( count( $rows ) >= 200 ) {
								$inserted += $this->bulk_insert_cache_rows( $rows );
								$rows = [];
							}
						}
					}
				}
			}
		}

		if ( [] !== $rows ) {
			$inserted += $this->bulk_insert_cache_rows( $rows );
		}

		return $inserted;
	}

	/**
     * Check if a month is within the availability range, handling wrap-around.
     *
     * @param int $month Current month (1-12)
     * @param int $from_month Start month (1-12)
     * @param int $to_month End month (1-12)
     */
    private function is_month_in_range( int $month, int $from_month, int $to_month ): bool {
		if ( $from_month <= $to_month ) {
			// Normal range (e.g., March to September: 3-9)
			return $month >= $from_month && $month <= $to_month;
		}
        // Wrap-around range (e.g., October to February: 10-2)
        return $month >= $from_month || $month <= $to_month;
	}

	/**
	 * Turn a sorted list of minute indices into contiguous [start,end] minute ranges.
	 * Example: [0,1,2,5,6] -> [[0,2],[5,6]]
	 *
	 * @param int[] $minutes
	 * @return array<int,int>[]
	 */
	private function compress_minutes_to_ranges( array $minutes ): array {
		$ranges = [];
		sort( $minutes, SORT_NUMERIC );

		$start = null;
		$prev  = null;

		foreach ( $minutes as $m ) {
			if ( null === $start ) {
				$start = $m;
				$prev  = $m;
				continue;
			}
			if ( $prev + 1 === $m ) {
				$prev = $m;
				continue;
			}
			// Break in sequence.
			$ranges[] = [ $start, $prev ];
			$start = $m;
			$prev  = $m;
		}

		if ( null !== $start ) {
			$ranges[] = [ $start, $prev ];
		}

		return $ranges;
	}

	/**
	 * Expand RRULE availability.
	 *
	 * Expands and indexes a recurring availability rule.
	 *
	 * @param object               $availability Availability object.
	 * @param string               $rrule_string RRULE string.
	 * @param array<string, mixed> $limits       Processing limits.
	 * @return int Number of rows inserted.
	 */
	private function expand_rrule_availability( object $availability, string $rrule_string, array $limits = [] ): int {
		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );

		$kind        = (string) $availability->get_kind();
		$kind_id     = (string) $availability->get_kind_id();
		$range_type  = (string) $availability->get_range_type();
		$appointable = (string) $availability->get_appointable();
		$priority    = (int) $availability->get_priority();
		$ordering    = (int) $availability->get_ordering();
		$qty         = (int) $availability->get_qty();
		$rule_id     = (int) $availability->get_id();

		if ( wc_appointments_availability_range_type_is_expired( $range_type ) ) {
			$this->delete_rows( 'availability', $rule_id );
			return 0;
		}

		$status = '';

		#error_log( var_export( $rrule_string, true ) );

		$scope_info = $this->derive_scope( $kind, $kind_id );
		$product_id = $scope_info['product_id'];
		$staff_id   = $scope_info['staff_id'];
		$scope      = $scope_info['scope'];
		$this->index_row_resource_id = (int) $scope_info['resource_id'];

		// DTSTART: prefer from_range, fallback to to_range.
		$from_rng = trim( (string) $availability->get_from_range() );
		$to_rng   = trim( (string) $availability->get_to_range() );
		$dtstart_str = '' !== $from_rng ? $from_rng : $to_rng;
		if ( '' === $dtstart_str ) {
			return 0;
		}

		if ( ! class_exists( \RRule\RRule::class ) ) {
			return 0;
		}

		try {
			// Handle timezone for recurring rules
			// Parse the datetime string with its original timezone and create DTSTART in site timezone
			$site_timezone = new DateTimeZone( wc_timezone_string() );

			// Parse the datetime string with its original timezone
			$temp_dt = new DateTimeImmutable( $dtstart_str );

			// Get the time components in the original timezone
			$year = (int) $temp_dt->format( 'Y' );
			$month = (int) $temp_dt->format( 'n' );
			$day = (int) $temp_dt->format( 'j' );
			$hour = (int) $temp_dt->format( 'G' );
			$minute = (int) $temp_dt->format( 'i' );
			$second = (int) $temp_dt->format( 's' );

			// Create a datetime object with the same time components but in site timezone
			$dtstart = new DateTimeImmutable();
			$dtstart = $dtstart->setTimezone( $site_timezone )
								 ->setDate( $year, $month, $day )
								 ->setTime( $hour, $minute, $second );

			// If the provided rrule string contains multiple lines (RRULE and EXDATE entries),
			// extract only the RRULE line to pass into the RRule constructor. Passing
			// the full multi-line string may cause the library to not yield occurrences.
			$rrule_to_pass = $rrule_string;
			if ( preg_match( '/(^|\r?\n)RRULE:(.+?)(\r?\n|$)/i', $rrule_string, $m ) ) {
				$rrule_to_pass = trim( $m[2] );
			}

			$rule    = new \RRule\RRule( $rrule_to_pass, $dtstart );
		} catch ( \Throwable $e ) {
			return 0;
		}

		$horizon = $this->horizon_ts();
		$this->now_ts();

		// For RRULE rules with force_full_index, extend horizon to include next occurrence
		// But still respect reasonable limits to avoid timeouts
		$force_full_index = (bool) get_option( 'wc_appointments_manual_reindex_full_indexing', false );
		$to_date = trim( (string) $availability->get_to_date() );
		if ( $force_full_index && '' === $to_date ) {
			$tolerance_seconds = self::HORIZON_TOLERANCE_DAYS * DAY_IN_SECONDS;
			$horizon = $horizon + $tolerance_seconds + ( 7 * DAY_IN_SECONDS );
		}

		// Determine the duration for each occurrence.
		$duration_secs = 0;
		if ( '' !== $from_rng && '' !== $to_rng ) {
			// Parse datetime strings and convert to site timezone for duration calculation
			try {
				$from_dt = new DateTimeImmutable( $from_rng );
				$to_dt = new DateTimeImmutable( $to_rng );

				// Convert both to site timezone
				$from_dt_site = $from_dt->setTimezone( $site_timezone );
				$to_dt_site = $to_dt->setTimezone( $site_timezone );

				$fr_ts = $from_dt_site->getTimestamp();
				$to_ts = $to_dt_site->getTimestamp();

				if ( $to_ts > $fr_ts ) {
					$duration_secs = $to_ts - $fr_ts;
				}
			} catch ( \Throwable $e ) {
				// Fallback to the original method if parsing fails
				$fr_ts = strtotime( $from_rng . ' UTC' );
				$to_ts = strtotime( $to_rng . ' UTC' );
				if ( $fr_ts && $to_ts && $to_ts > $fr_ts ) {
					$duration_secs = $to_ts - $fr_ts;
				}
			}
		}

		$max_occ  = (int) ( $limits['max_occurrences'] ?? PHP_INT_MAX );
		$max_rows = (int) ( $limits['max_rows'] ?? PHP_INT_MAX );

		// Progress resume: ignore occurrences already fully cached in the future.
		$availability_id = (int) $availability->get_id();
		$last_cached_end = $this->get_availability_last_cached_end_ts( $availability_id );

		$rows      = [];
		$occ_done  = 0;
		$rows_done = 0;
		$inserted  = 0;

		// Parse EXDATE entries from the rrule string (if any) so we can skip those occurrences.
		// Build a set of keys in site timezone to compare against occurrences.
		// Support both date-only EXDATEs (Y-m-d) and date-time EXDATEs (Y-m-d H:i:s).
		$exdate_map = [];
		if ( stripos( $rrule_string, 'EXDATE' ) !== false ) {
			// Be tolerant to params (e.g., TZID) and capture the value portion after the colon.
			preg_match_all( '/EXDATE(?:;[^:]+)?:([^\r\n]+)/i', $rrule_string, $ex_matches );
			foreach ( $ex_matches[1] as $ex_list ) {
					$parts = array_map( 'trim', explode( ',', $ex_list ) );
					foreach ( $parts as $part ) {
					if ( '' === $part ) {
						continue;
						}
					try {
						// Try generic parse first.
						$ex_dt = new DateTimeImmutable( $part );
						$ex_dt_site = $ex_dt->setTimezone( $site_timezone );
						// Full datetime key.
						$ex_full = $ex_dt_site->format( 'Y-m-d H:i:s' );
						$ex_date = $ex_dt_site->format( 'Y-m-d' );
						$exdate_map[ $ex_full ] = true;
						$exdate_map[ $ex_date ] = true; // allow date-only matches
						continue;
						} catch ( \Throwable $e ) {
						// Fallbacks for iCal common formats

						// 1) UTC basic format YYYYMMDDTHHMMSSZ
						if ( preg_match( '/^\d{8}T\d{6}Z$/', $part ) ) {
							$dt = DateTimeImmutable::createFromFormat( 'Ymd\\THis\\Z', $part, new DateTimeZone( 'UTC' ) );
							if ( $dt ) {
								$dt_site = $dt->setTimezone( $site_timezone );
								$ex_full = $dt_site->format( 'Y-m-d H:i:s' );
								$ex_date = $dt_site->format( 'Y-m-d' );
								$exdate_map[ $ex_full ] = true;
								$exdate_map[ $ex_date ] = true;
								continue;
								}
							}

						// 2) Date-only YYYYMMDD
						if ( preg_match( '/^\d{8}$/', $part ) ) {
							$dt = DateTimeImmutable::createFromFormat( 'Ymd', $part, $site_timezone );
							if ( $dt ) {
								$ex_date = $dt->format( 'Y-m-d' );
								$exdate_map[ $ex_date ] = true;
								continue;
								}
							}

						// 3) Hyphenated date YYYY-MM-DD (ensure it's accepted)
						if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $part ) ) {
							try {
								$dt = new DateTimeImmutable( $part );
								$dt_site = $dt->setTimezone( $site_timezone );
								$ex_date = $dt_site->format( 'Y-m-d' );
								$exdate_map[ $ex_date ] = true;
								continue;
								} catch ( \Throwable $e2 ) {
								// ignore
								}
							}

						// If parsing fails, ignore this token.
						continue;
						}
					}
				}
		}

		foreach ( $rule as $occurrence ) {
			if ( $occ_done >= $max_occ || $rows_done >= $max_rows ) {
				break;
			}

			// Normalize occurrence to site timezone for comparison with EXDATEs.
			// php-rrule yields DateTime; clone + setTimezone needs the mutable instance.
			$occ_in_site = ( clone $occurrence )->setTimezone( $site_timezone );
			$occ_full = $occ_in_site->format( 'Y-m-d H:i:s' );
			$occ_date = $occ_in_site->format( 'Y-m-d' );

			// If this occurrence matches an EXDATE (either full datetime or date-only), skip it.
			if ( isset( $exdate_map[ $occ_full ] ) || isset( $exdate_map[ $occ_date ] ) ) {
				$occ_done++;
				continue;
			}

			// Compute start_ts preserving local time as before (format then strtotime with 'UTC').
			$local_time_str = $occurrence->format( 'Y-m-d H:i:s' );
			$start_ts = (int) strtotime( $local_time_str . ' UTC' );

			// Compute end_ts for occurrence duration.
			$end_ts = 0 < $duration_secs ? $start_ts + $duration_secs : $start_ts + DAY_IN_SECONDS;

			// During manual re-indexing, include past occurrences within retention period
			// For automatic indexing, skip fully past occurrences
			if ( ! $this->should_index_end_ts( $end_ts ) ) {
				$occ_done++;
				continue;
			}

			if ( $start_ts > $horizon ) {
				break;
			}

			if ( $end_ts <= $start_ts || ( 0 < $last_cached_end && $end_ts <= $last_cached_end ) ) {
				$occ_done++;
				continue;
			}

			$rows[] = [
				'source' => 'availability',
				'source_id' => (int) $availability->get_id(),
				'product_id' => $product_id,
				'staff_id' => $staff_id,
				'scope' => $scope,
				'appointable' => $appointable,
				'priority' => $priority,
				'ordering' => $ordering,
				'qty' => $qty,
				'start_ts' => $start_ts,
				'end_ts' => $end_ts,
				'range_type' => $range_type,
				'rule_kind' => $kind,
				'status' => $status,
				'date_created' => current_time( 'mysql' ),
				'date_modified' => current_time( 'mysql' ),
			];
			$rows_done++;
			$occ_done++;

			// Insert in reasonable chunks to avoid huge queries.
			if ( count( $rows ) >= 200 ) {
				$inserted += $this->bulk_insert_cache_rows( $rows );
				$rows = [];
			}
		}

		if ( [] !== $rows ) {
			$inserted += $this->bulk_insert_cache_rows( $rows );
		}

		return $inserted;
	}

	/**
	 * Bulk insert cache rows using CRUD data store.
	 *
	 * @param list<array<string, mixed>> $rows_data Array of row data arrays
	 * @return int Number of rows inserted
	 */
	private function bulk_insert_cache_rows( array $rows_data ): int {
		if ( [] === $rows_data ) {
			return 0;
		}

		if ( ! class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			return 0;
		}

		foreach ( $rows_data as $i => $row ) {
			if ( ! array_key_exists( 'resource_id', $row ) ) {
				$rows_data[ $i ]['resource_id'] = $this->index_row_resource_id;
			}
		}

		$data_store = new WC_Appointments_Availability_Cache_Data_Store();
		return $data_store->bulk_insert( $rows_data );
	}

	/**
	 * Derive scope.
	 *
	 * Determines the scope, product ID, staff ID, and resource ID from kind/kind_id.
	 *
	 * @param string $kind    Kind string.
	 * @param string $kind_id Kind ID string.
	 * @return array{scope: string, product_id: int, staff_id: int, resource_id: int, malformed: bool} Scope info.
	 */
	private function derive_scope( string $kind, string $kind_id ): array {
		// - global -> scope=global, product_id=0, staff_id=0, resource_id=0
		// - location -> scope=location, product_id=kind_id (location post ID)
		// - resource -> scope=resource, resource_id=kind_id
		// - product -> scope=product, product_id=kind_id
		// - staff -> scope=staff, staff_id=kind_id
		$scope       = 'global';
		$product_id  = 0;
		$staff_id    = 0;
		$resource_id = 0;

		if ( false !== stripos( $kind, 'location' ) ) {
			$scope      = 'location';
			$product_id = (int) $kind_id;
		} elseif ( false !== stripos( $kind, 'resource' ) ) {
			$scope       = 'resource';
			$resource_id = (int) $kind_id;
		} elseif ( false !== stripos( $kind, 'product' ) ) {
			$scope      = 'product';
			$product_id = (int) $kind_id;
		} elseif ( false !== stripos( $kind, 'staff' ) ) {
			$scope    = 'staff';
			$staff_id = (int) $kind_id;
		}

		$kind_id_trimmed = trim( $kind_id );
		$malformed       = ( '' === $kind_id_trimmed || '0' === $kind_id_trimmed )
			&& in_array( $scope, [ 'product', 'staff', 'location', 'resource' ], true );

		return [
			'scope'       => $scope,
			'product_id'  => $product_id,
			'staff_id'    => $staff_id,
			'resource_id' => $resource_id,
			'malformed'   => $malformed,
		];
	}

	/**
	 * Reset malformed-rule skip counter at the start of a manual re-index.
	 */
	public static function reset_skipped_malformed_rule_count(): void {
		self::$skipped_malformed_rules_session = 0;
	}

	/**
	 * Malformed product/staff-scoped rules skipped in the current re-index session.
	 */
	public static function get_skipped_malformed_rule_count(): int {
		return self::$skipped_malformed_rules_session;
	}

	/**
	 * Drop cache rows for a malformed scoped rule and record the skip for re-index summary.
	 *
	 * @param object $availability Availability object.
	 */
	private function skip_malformed_availability_rule( object $availability ): void {
		$rule_id = (int) $availability->get_id();
		if ( 0 < $rule_id ) {
			$this->delete_rows( 'availability', $rule_id );
		}

		++self::$skipped_malformed_rules_session;
	}

	/**
	 * Daily task: extend the availability cache toward the horizon for all rules in bounded chunks.
	 * Single entry point to keep backfill simple and predictable.
	 */
	public function extend_rrule_horizon(): void {
		if ( self::should_skip_background_index_worker() ) {
			return;
		}

		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );
		@ignore_user_abort( true );

		// Gather all availability rule IDs that could require indexing.
		$availability_ids = $this->get_all_availability_ids();
		if ( [] === $availability_ids ) {
			return;
		}

		// Periodic fail check: ensure all rules are indexed regularly
		$this->periodic_fail_check( $availability_ids );

		// Periodic fail check: ensure all appointments are indexed
		$this->periodic_fail_check_appointments();

		// For each rule, schedule a bounded indexing pass. Collect rules with no cache rows yet (skipped by
		// periodic_fail_check) so we can sync-prime the newest IDs—otherwise cold rebuild waits on AS delay only.
		$unindexed_zero_end = [];
		foreach ( $availability_ids as $availability_id ) {
			$availability_id = (int) $availability_id;
			if ( 0 >= $availability_id ) {
				continue;
			}
			$this->schedule_rule_index( $availability_id );
			if ( 0 >= $this->get_availability_last_cached_end_ts( $availability_id ) ) {
				$unindexed_zero_end[] = $availability_id;
			}
		}
		if ( [] !== $unindexed_zero_end ) {
			rsort( $unindexed_zero_end, SORT_NUMERIC );
			foreach ( array_slice( $unindexed_zero_end, 0, self::SYNC_PRIME_UNINDEXED_RULE_CAP ) as $availability_id ) {
				$this->run_rule_index_pass( $availability_id );
			}
		}

		// Optional: prune past rows to keep the cache lean.
		$this->prune_past_rows();
	}

	/**
	 * Schedule appointment backfill batches using the Action Scheduler.
	 * This mirrors how extend_rrule_horizon schedules per-rule indexing to avoid timeouts.
	 *
	 * @param int $limit Number of appointments to process per batch (the worker will reschedule itself if needed).
	 */
	public function schedule_backfill_appointments( $limit = 200 ): void {
		if ( self::should_block_background_index_scheduling() ) {
			return;
		}

		if ( ! function_exists( 'as_schedule_single_action' ) || ! function_exists( 'as_next_scheduled_action' ) ) {
			return;
		}

		// Avoid duplicate schedules for appointment backfill batches.
		if ( ! as_next_scheduled_action( 'wc_appointments_backfill_appointments_batch' ) ) {
			as_schedule_single_action( time() + 15, 'wc_appointments_backfill_appointments_batch', [ (int) $limit ] );
		}
	}

	/**
	 * Persist backfill pending flag and queue another batch when gaps remain.
	 *
	 * @param int $pending 1 when unindexed appointments remain, 0 when complete.
	 * @param int $limit   Batch size for the scheduled worker.
	 */
	private function persist_backfill_appt_offset( int $pending, int $limit ): void {
		update_option( 'wc_appointments_backfill_appt_offset', $pending > 0 ? 1 : 0, false );
		wp_cache_delete( 'wc_appointments_backfill_appt_offset', 'options' );

		if ( $pending > 0 ) {
			$this->schedule_backfill_appointments( $limit );
		}
	}

	/**
	 * Background worker: process a bounded batch of appointments and reschedule if more remain.
	 *
	 * Called by Action Scheduler with a single integer argument $limit.
	 *
	 * @param int $limit
	 */
	public function run_backfill_appointments_batch( $limit = 200 ): void {
		if ( self::should_skip_background_index_worker() ) {
			return;
		}

		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );
		@ignore_user_abort( true );

		$limit = (int) $limit;
		if ( 0 >= $limit ) {
			$limit = 200;
		}

		$this->backfill_appointments( $limit );

		// No immediate cache invalidation here — per-appointment indexing will invalidate as they run.
	}

	/**
	 * Periodic fail check: ensure all rules are indexed regularly within the horizon tolerance.
	 * This method identifies rules that:
	 * 1. Haven't been indexed recently (7+ days ago) AND don't reach the horizon within tolerance, OR
	 * 2. Were recently indexed but still don't reach the horizon within tolerance (indicates indexing failure).
	 *
	 * Rules must reach within HORIZON_TOLERANCE_DAYS of the horizon at all times for reliable index operation.
	 *
	 * @param list<int> $availability_ids Array of availability rule IDs to check.
	 */
	private function periodic_fail_check( array $availability_ids ): void {
		if ( [] === $availability_ids ) {
			return;
		}

		$horizon = $this->horizon_ts();
		$check_threshold = strtotime( '-7 days', $this->now_ts() ); // Check rules not indexed in the last 7 days.
		$failed_rules = [];
		$recently_indexed_but_failed = [];
		$constrained_rules_not_at_limit = [];

		foreach ( $availability_ids as $availability_id ) {
			$availability_id = (int) $availability_id;
			if ( 0 >= $availability_id ) {
				continue;
			}

			// Check if a rule has been indexed recently
			$last_cached_end = $this->get_availability_last_cached_end_ts( $availability_id );

			// Skip rules with no cached data (they shouldn't be indexed yet or are new).
			if ( 0 >= $last_cached_end ) {
				continue;
			}

			// Check if rule has constraints that prevent it from reaching the horizon
			$constraint_info = $this->check_rule_constraints( $availability_id, $horizon );

			if ( $constraint_info['has_constraint'] ) {
				// Rule has constraints (to_date or UNTIL) that prevent it from reaching the horizon
				// Check if it's within tolerance of its maximum possible end (the constraint)
				$is_within_constraint_tolerance = $this->is_rule_within_horizon_tolerance( $last_cached_end, $constraint_info['max_possible_end_ts'] );

				if ( ! $is_within_constraint_tolerance ) {
					// Rule has constraints but isn't indexed to its limit - needs re-indexing
					$constrained_rules_not_at_limit[] = [
						'id' => $availability_id,
						'constraint_type' => $constraint_info['constraint_type'],
						'max_possible_end_ts' => $constraint_info['max_possible_end_ts'],
					];
				}
				// If rule is within tolerance of its constraint limit, skip it (it's already at its maximum)
				continue;
			}

			// Rule has no constraints - check if it's within tolerance of the horizon
			$is_within_tolerance = $this->is_rule_within_horizon_tolerance( $last_cached_end, $horizon );

			if ( ! $is_within_tolerance ) {
				// Rule doesn't reach horizon within tolerance - needs re-indexing
				$was_recently_indexed = $last_cached_end >= $check_threshold;

				if ( $was_recently_indexed ) {
					// Rule was indexed recently but still doesn't reach horizon - this indicates indexing failure
					$recently_indexed_but_failed[] = $availability_id;
				} else {
					// Rule hasn't been indexed recently - periodic fail check should catch this
					$failed_rules[] = $availability_id;
				}
			}
		}

		// Log and handle rules that haven't been indexed recently
		if ( [] !== $failed_rules ) {
			$this->log_index_message(
			    sprintf(
			        'Periodic fail check found %d rules requiring re-indexing (not indexed in 7+ days). Rule IDs: %s',
			        count( $failed_rules ),
			        implode( ', ', $failed_rules ),
			    ),
			    'warning',
			);

			foreach ( $failed_rules as $failed_rule_id ) {
				$this->run_rule_index_pass( $failed_rule_id );
			}
		}

		if ( [] !== $recently_indexed_but_failed ) {
			$this->log_index_message(
			    sprintf(
			        'CRITICAL: Periodic fail check found %d rules that were recently indexed but still don\'t reach horizon within %d-day tolerance. These rules have no constraints and should be able to reach the horizon. This indicates indexing failure. Rule IDs: %s',
			        count( $recently_indexed_but_failed ),
			        self::HORIZON_TOLERANCE_DAYS,
			        implode( ', ', $recently_indexed_but_failed ),
			    ),
			    'error',
			);

			$original_force_full_index = get_option( 'wc_appointments_manual_reindex_full_indexing', false );
			update_option( 'wc_appointments_manual_reindex_full_indexing', true, false );

			foreach ( $recently_indexed_but_failed as $failed_rule_id ) {
				$this->run_rule_index_pass( $failed_rule_id );
			}

			if ( true !== $original_force_full_index ) {
				delete_option( 'wc_appointments_manual_reindex_full_indexing' );
			}
		}

		if ( [] !== $constrained_rules_not_at_limit ) {
			$rule_ids = array_column( $constrained_rules_not_at_limit, 'id' );
			$constraint_types = array_unique( array_column( $constrained_rules_not_at_limit, 'constraint_type' ) );

			$this->log_index_message(
			    sprintf(
			        'Periodic fail check found %d rules with constraints (%s) that aren\'t indexed to their limit within %d-day tolerance. Rule IDs: %s',
			        count( $constrained_rules_not_at_limit ),
			        implode( ', ', $constraint_types ),
			        self::HORIZON_TOLERANCE_DAYS,
			        implode( ', ', $rule_ids ),
			    ),
			    'warning',
			);

			foreach ( $constrained_rules_not_at_limit as $constrained_rule ) {
				$this->run_rule_index_pass( $constrained_rule['id'] );
			}
		}
	}

	/**
     * Periodic fail check: ensure all appointments that should be indexed are actually in the index.
     * Checks for appointments that exist in the database but are missing from the index.
     *
     * Processes appointments in batches and indexes them directly to avoid flooding Action Scheduler.
     * For high-volume sites, this method processes a limited batch per run and will continue
     * checking on subsequent daily cron runs until all appointments are verified.
     */
    private function periodic_fail_check_appointments(): void {
		if ( ! class_exists( 'WC_Appointment_Data_Store' ) ) {
			return;
		}

		$now = $this->now_ts();
		$horizon = $this->horizon_ts();

		// Process a reasonable batch per run to avoid timeouts
		// For sites with hundreds of thousands of appointments, this will process
		// incrementally over multiple daily runs
		$check_limit = 200; // Check up to 200 appointments per run
		$index_limit = 50;  // Index up to 50 missing appointments per run to avoid timeouts

		// Get offset from last run to continue where we left off
		$last_offset = (int) get_option( 'wc_appointments_periodic_check_appt_offset', 0 );

		$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_by(
		    [
				'date_after' => $now - DAY_IN_SECONDS, // Include appointments starting from yesterday (ongoing)
				'date_before' => $horizon, // Up to horizon
				'limit' => $check_limit,
				'offset' => $last_offset,
				'order' => 'ASC',
				'order_by' => 'start_date',
			],
		);

		if ( empty( $appointment_ids ) ) {
			// Reset offset if we've checked all appointments
			update_option( 'wc_appointments_periodic_check_appt_offset', 0, false );
			return;
		}

		$missing_appointments = [];
		$cache_data_store = null;

		if ( class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			$cache_data_store = new WC_Appointments_Availability_Cache_Data_Store();
		}

		foreach ( $appointment_ids as $appointment_id ) {
			$appointment_id = (int) $appointment_id;
			if ( 0 >= $appointment_id ) {
				continue;
			}

			// Check if appointment exists in index
			if ( $cache_data_store instanceof \WC_Appointments_Availability_Cache_Data_Store ) {
				$existing_rows = $cache_data_store->get_items(
                    [
						'source' => 'appointment',
						'source_id' => $appointment_id,
						'limit' => 1,
					]
                    );

				// Check if any existing row has end_ts > now (future appointment)
				$has_future_row = false;
				foreach ( $existing_rows as $row ) {
					if ( isset( $row['end_ts'] ) && (int) $row['end_ts'] > $now ) {
						$has_future_row = true;
						break;
					}
				}

				if ( ! $has_future_row ) {
					// Verify the appointment actually has a future end time before marking as missing
					try {
						$appointment = get_wc_appointment( $appointment_id );
						if ( $appointment && method_exists( $appointment, 'get_end' ) ) {
							$end_ts = (int) $appointment->get_end();
							if ( $end_ts > $now ) {
								$missing_appointments[] = $appointment_id;
							}
						}
					} catch ( Exception $e ) {
						// Skip if appointment can't be loaded
						continue;
					}
				}
			}
		}

		// Index missing appointments directly (in batches to avoid timeouts)
		$indexed_count = 0;
		if ( [] !== $missing_appointments ) {
			$this->log_index_message(
			    sprintf(
			        'Periodic fail check found %d appointments missing from index (checking batch starting at offset %d). Will index up to %d per run.',
			        count( $missing_appointments ),
			        $last_offset,
			        $index_limit,
			    ),
			    'warning',
			);

			// Index missing appointments directly in batches to avoid Action Scheduler overload
			foreach ( array_slice( $missing_appointments, 0, $index_limit ) as $appointment_id ) {
				try {
					$this->index_appointment_from_id( $appointment_id );
					$indexed_count++;
				} catch ( Exception $e ) {
					// Log error but continue with other appointments
					$this->log_index_message(
					    sprintf( 'Failed to index appointment %d during periodic check: %s', $appointment_id, $e->getMessage() ),
					    'error',
					);
				}
			}

			if ( 0 < $indexed_count ) {
				$this->log_index_message(
				    sprintf(
				        'Periodic fail check indexed %d missing appointments. Appointment IDs: %s',
				        $indexed_count,
				        implode( ', ', array_slice( $missing_appointments, 0, min( 20, $indexed_count ) ) ) . ( 20 < $indexed_count ? '...' : '' ),
				    ),
				    'info',
				);
			}

			// If there are more missing appointments than we indexed, log that they'll be processed in next run
			if ( count( $missing_appointments ) > $index_limit ) {
				$this->log_index_message(
				    sprintf(
				        'Periodic fail check: %d additional missing appointments will be indexed in subsequent runs.',
				        count( $missing_appointments ) - $index_limit,
				    ),
				    'info',
				);
			}
		}

		// Update offset for next run
		$new_offset = $last_offset + count( $appointment_ids );

		// If we processed a full batch, continue from this offset next time
		// Otherwise, reset offset to start from beginning (we've checked all appointments)
		if ( count( $appointment_ids ) >= $check_limit ) {
			update_option( 'wc_appointments_periodic_check_appt_offset', $new_offset, false );
		} else {
			// We've reached the end, reset for next cycle
			update_option( 'wc_appointments_periodic_check_appt_offset', 0, false );
		}
	}

	/**
	 * Get all availability rule IDs quickly (IDs only).
	 *
	 * @return int[]
	 */
	private function get_all_availability_ids(): array {
		if ( ! class_exists( 'WC_Appointments_Availability_Data_Store' ) ) {
			return [];
		}

		$data_store = new WC_Appointments_Availability_Data_Store();

		return $data_store->get_all_availability_rule_ids();
	}

	/**
	 * Prune past/expired rows from the cache to prevent unbounded growth.
	 * - Removes rows with status='expired' (availability)
	 * - Removes appointment/availability rows with end_ts older than retention
	 * - Removes stale in-cart appointment holds older than 1 day
	 */
	private function prune_past_rows(): void {
		if ( ! class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			return;
		}

		$data_store = new WC_Appointments_Availability_Cache_Data_Store();

		// Global retention cut for availability/appointment rows.
		$retention_days = defined( 'self::INDEX_RETENTION_DAYS' ) ? self::INDEX_RETENTION_DAYS : 30;
		$cut = strtotime( '-' . $retention_days . ' days UTC', $this->now_ts() );

		// Remove expired availability rows.
		$data_store->delete_by_time_criteria(
            [
				'source' => 'availability',
				'status' => 'expired',
			]
            );

		// Remove very old rows (appointments and availability) beyond retention cut.
		$data_store->delete_by_time_criteria(
            [
				'end_ts_before' => (int) $cut,
			]
            );

		// Remove stale in-cart appointment holds older than 1 day to free holds.
		$in_cart_cut = strtotime( '-1 day UTC', $this->now_ts() );
		$data_store->delete_by_time_criteria(
            [
				'source' => 'appointment',
				'status' => 'in-cart',
				'end_ts_before' => (int) $in_cart_cut,
			]
            );
	}

	/**
	 * First-run backfill entry: enqueue per-rule passes, then mark complete.
	 * Keeps behavior aligned with the daily extender.
	 */
	public function run_backfill_batches(): void {
		if ( self::should_skip_background_index_worker() ) {
			return;
		}

		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );
		@ignore_user_abort( true );

		// Schedule availability rule passes (do not insert directly to avoid timeouts).
		$this->extend_rrule_horizon();

		// Schedule appointment backfill batches (do not insert directly to avoid timeouts).
		$this->schedule_backfill_appointments();

		// Mark that initial backfill scheduling has been done (batches will run asynchronously).
		$this->mark_backfill_complete();
	}

	/**
	 * Backfill appointments.
	 *
	 * Processes a batch of appointments for backfilling the index.
	 *
	 * @param int $limit Max appointments to process.
	 * @return int Number of appointments successfully indexed.
	 */
	private function backfill_appointments( int $limit = 1000 ): int {
		$now = $this->now_ts();

		if ( ! class_exists( 'WC_Appointment_Data_Store' ) ) {
			return 0;
		}

		$limit = max( 1, $limit );
		$ids   = WC_Appointment_Data_Store::get_future_appointment_ids_missing_from_cache( $now, $limit );

		if ( empty( $ids ) ) {
			$this->persist_backfill_appt_offset( 0, $limit );
			return 0;
		}

		$indexed = 0;
		foreach ( $ids as $id ) {
			try {
				$this->index_appointment_from_id( (int) $id );
			} catch ( Exception $e ) {
				$this->log_index_message(
					sprintf( 'Failed to index appointment %d during backfill: %s', (int) $id, $e->getMessage() ),
					'error'
				);
				continue;
			}

			if ( $this->has_appointment_occupancy_cache_row( (int) $id, $now ) ) {
				++$indexed;
			}
		}

		$this->persist_backfill_appt_offset( ( $indexed > 0 && count( $ids ) >= $limit ) ? 1 : 0, $limit );

		return $indexed;
	}
}

// Instantiation handled by woocommerce-appointments.php bootstrap.
// Do not instantiate here to avoid duplicate hook registrations.
