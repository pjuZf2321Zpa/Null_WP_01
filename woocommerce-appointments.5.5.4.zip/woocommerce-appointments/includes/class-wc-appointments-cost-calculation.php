<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class that handles all cost calculations.
 *
 * @since 4.7.0
 */
class WC_Appointments_Cost_Calculation {

	/** Pricing rule type: recurring package volume (excluded from per-slot get_costs()). */
	public const PRICING_RULE_SESSIONS = 'sessions';

	/**
	 * @param array<string, mixed>|string $rule Rule row or type slug.
	 */
	public static function is_sessions_pricing_rule( $rule ): bool {
		if ( is_string( $rule ) ) {
			return self::PRICING_RULE_SESSIONS === $rule;
		}

		return is_array( $rule ) && self::PRICING_RULE_SESSIONS === ( $rule['type'] ?? '' );
	}

	/**
	 * @param array<string, mixed> $rule  Pricing rule row with from/to.
	 * @param int                  $count Value to match (e.g. billable sessions).
	 */
	private static function pricing_rule_matches_count( array $rule, int $count ): bool {
		$from = (int) ( $rule['from'] ?? 0 );
		$to   = (int) ( $rule['to'] ?? 0 );

		return $from >= 1 && $to >= $from && $count >= $from && $count <= $to;
	}

	/** @var list<array<string, mixed>>|null */
	public static $applied_cost_rules;

	/** @var float|int|string */
	public static $appointment_cost = 0;

	/**
	 * Compute default flags for pricing behavior in a single place.
	 *
	 * Goal: keep any legacy compatibility checks out of the main flow,
	 * so the cost logic reads cleanly while defaults are decided here.
	 *
	 * - Interval-based pricing default:
	 *   New saves or fresh installs → true.
	 *   Legacy installs → false, except safe case when duration == interval for minute/hour.
	 * - Base cost overlap default:
	 *   New saves or fresh installs → true.
	 *   Legacy installs → false.
	 *
	 * @param WC_Product_Appointment $product Current appointable product.
	 * @param string                 $slot_unit Product duration unit.
	 * @return array{apply_cost_per_interval_default:bool,apply_base_overlap_default:bool}
	 */
	private static function get_pricing_defaults( $product, $slot_unit ): array {
		// Check per-product: products saved after 5.0.0 use interval-based, older products use duration-based
		// Interval-based pricing option wasn't available before 5.0.0, so old products should use duration
		$product_id = $product->get_id();
		$product_post = get_post( $product_id );

		// Defaults: new behavior (interval-based for new products)
		$apply_cost_per_interval_default = true;
		$apply_base_overlap_default      = true;

		// Check if product was modified before plugin was updated to 5.0.0
		// If product was saved before 5.0.0 update, use duration-based (legacy behavior)
		if ( $product_post ) {
			$product_modified = $product_post->post_modified_gmt;
			// Get when plugin was updated to 5.0.0 (stored when install script runs)
			$plugin_5_0_0_update_time = get_option( 'wc_appointments_version_5_0_0_update_time', '' );

			// If product was modified before 5.0.0 update, use duration-based
			if ( $plugin_5_0_0_update_time && $product_modified && $product_modified < $plugin_5_0_0_update_time ) {
				// Old product (saved before 5.0.0 update) - use duration-based
				$apply_cost_per_interval_default = false;
				$apply_base_overlap_default      = false;

				// Safe exception: minute/hour products where duration equals interval.
				if ( in_array( $slot_unit, [ 'minute', 'hour' ] ) ) {
					[$duration_minutes, $base_interval_minutes] = $product->get_intervals();
					$apply_cost_per_interval_default = (int) max( 1, $duration_minutes ) === (int) max( 1, $base_interval_minutes );
				}
			}
		}

		return [
			'apply_cost_per_interval_default' => $apply_cost_per_interval_default,
			'apply_base_overlap_default'      => $apply_base_overlap_default,
		];
	}

	/**
	 * Parse HH:MM from pricing rule from/to strings.
	 *
	 * @return int[]|null [ hour, minute ] or null.
	 */
	private static function parse_pricing_rule_hhmm( string $raw ): ?array {
		if ( ! preg_match( '/^\s*(\d{1,2})\s*:\s*(\d{2})\s*$/', trim( $raw ), $m ) ) {
			return null;
		}

		return [ (int) $m[1], (int) $m[2] ];
	}

	/**
	 * Rule window as YmdHi strings in the site timezone (same basis as wc_appointments_get_formatted_times()).
	 *
	 * @return string[] Two-element list: start YmdHi, end YmdHi.
	 */
	private static function time_rule_start_end_hi_site_local( int $slot_unix_ts, string $from_raw, string $to_raw ): array {
		$tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
		try {
			$local = ( new DateTimeImmutable( '@' . $slot_unix_ts ) )->setTimezone( $tz );
		} catch ( Exception $e ) {
			$hi = gmdate( 'YmdHi', $slot_unix_ts );

			return [ $hi, $hi ];
		}

		$fp = self::parse_pricing_rule_hhmm( $from_raw );
		$tp = self::parse_pricing_rule_hhmm( $to_raw );
		if ( null === $fp || null === $tp ) {
			$hi = $local->format( 'YmdHi' );

			return [ $hi, $hi ];
		}

		try {
			$start_dt = $local->setTime( $fp[0], $fp[1], 0 );
			$end_dt   = $local->setTime( $tp[0], $tp[1], 0 );
		} catch ( Exception $e ) {
			$hi = $local->format( 'YmdHi' );

			return [ $hi, $hi ];
		}

		return [ $start_dt->format( 'YmdHi' ), $end_dt->format( 'YmdHi' ) ];
	}

	/**
	 * Rule window as YmdHi for slot-engine token timestamps (gmdate / UTC facade, same as posted slot fields).
	 *
	 * @return string[] Two-element list: start YmdHi, end YmdHi.
	 */
	private static function time_rule_start_end_hi_slot_token( int $slot_unix_ts, string $from_raw, string $to_raw ): array {
		$fp = self::parse_pricing_rule_hhmm( $from_raw );
		$tp = self::parse_pricing_rule_hhmm( $to_raw );
		if ( null === $fp || null === $tp ) {
			$hi = gmdate( 'YmdHi', $slot_unix_ts );

			return [ $hi, $hi ];
		}

		$utc_tz = new DateTimeZone( 'UTC' );
		$base   = DateTimeImmutable::createFromFormat( '!Y-m-d', gmdate( 'Y-m-d', $slot_unix_ts ), $utc_tz );
		if ( ! $base instanceof DateTimeImmutable ) {
			$hi = gmdate( 'YmdHi', $slot_unix_ts );

			return [ $hi, $hi ];
		}

		$start_hi = $base->format( 'Ymd' ) . sprintf( '%02d%02d', $fp[0], $fp[1] );
		$start_m  = $fp[0] * 60 + $fp[1];
		$end_m    = $tp[0] * 60 + $tp[1];
		$end_day  = ( $end_m < $start_m ) ? $base->modify( '+1 day' ) : $base;
		$end_hi   = $end_day->format( 'Ymd' ) . sprintf( '%02d%02d', $tp[0], $tp[1] );

		return [ $start_hi, $end_hi ];
	}

	/**
	 * Calculate costs from posted values.
	 *
	 * @param  array<string, mixed> $posted Posted form values.
	 * @param  WC_Product           $product Appointable product.
	 * @return float|WP_Error
	 */
	public static function calculate_appointment_cost( $posted, $product ) {
		if ( ! is_wc_appointment_product( $product ) ) {
			return new WP_Error( 'invalid_product', __( 'Invalid appointment product.', 'woocommerce-appointments' ) );
		}

		// Always recompute: posted data (customer_id, slot, qty) and cost filters must not reuse a prior request value.

		// Get pricing rules.
		$costs = $product->get_costs();

		// Get posted data.
		$data = wc_appointments_get_posted_data( $posted, $product );

		$quote_only = ! empty( $posted['wc_appointments_field_quote_only'] )
			&& in_array( strtolower( (string) $posted['wc_appointments_field_quote_only'] ), [ '1', 'true', 'yes', 'on' ], true );

		if ( apply_filters( 'woocommerce_appointments_calculate_cost_validate_appointable', ! $quote_only, $product, $posted, $data ) ) {
			$validate = $product->is_appointable( $data );
			if ( is_wp_error( $validate ) ) {
				return $validate;
			}
		} elseif ( empty( $data['_start_date'] ) ) {
			return new WP_Error( 'Error', __( 'This field is required.', 'woocommerce-appointments' ) );
		}

		$use_slot_token_ts = ! empty( $data['_slot_token_timestamp'] );
		$slot_times_fmt    = static function ( int $ts ) use ( $use_slot_token_ts ) {
			return $use_slot_token_ts ? wc_appointments_slot_token_formatted_times( $ts ) : wc_appointments_get_formatted_times( $ts );
		};

		// Base price.
		$product_price   = apply_filters( 'appointments_calculated_product_price', $product->get_price(), $product, $posted );
		$base_cost       = max( 0, $product_price );
		$base_slot_cost  = 0;
		$total_slot_cost = 0;

		// See if we have an $product->assigned_staff_id.
		if ( $product->assigned_staff_id ) {
			$data['_staff_id'] = $product->assigned_staff_id;
		}

		// Get staff cost.
		if ( isset( $data['_staff_ids'] ) && is_array( $data['_staff_ids'] ) ) { #multiple staff
			foreach ( $data['_staff_ids'] as $data_staff_id ) {
				$staff      = $product->get_staff_member( absint( $data_staff_id ) );
				$base_cost += $staff ? $staff->get_base_cost() : 0;
			}
		} elseif ( isset( $data['_staff_id'] ) ) { #single staff
			$staff      = $product->get_staff_member( absint( $data['_staff_id'] ) );
			$base_cost += $staff ? $staff->get_base_cost() : 0;
		}

		$base_cost += (float) ( $data['_resource_allocations'][0]['cost'] ?? 0 );
		$base_cost += (float) ( $data['_location']['cost'] ?? 0 );

		$catalog_unit_base = $base_cost;

		// Slot data.
		self::$applied_cost_rules = [];
		$slot_duration            = $product->get_duration();
		$slot_unit                = $product->get_duration_unit();
		$slot_timestamp           = $data['_start_date'];
		$catalog_span_unit        = in_array( $slot_unit, [ 'day', 'month', 'night' ], true );

		// Compute default pricing flags in one place to keep legacy logic hidden.
		$pricing_defaults = self::get_pricing_defaults( $product, $slot_unit );
		$apply_cost_per_interval = apply_filters( 'woocommerce_appointments_apply_cost_per_interval', $pricing_defaults['apply_cost_per_interval_default'], $product, $posted );
		// Determine scheduled slots using product interval for minute/hour units when enabled.
		if ( in_array( $slot_unit, [ 'minute', 'hour' ] ) && $apply_cost_per_interval ) {
			[$duration_minutes, $base_interval_minutes] = $product->get_intervals();
			$total_duration_minutes = isset( $data['_duration'] )
				? absint( $data['_duration'] )
				: ( 'hour' === $slot_unit ? $slot_duration * 60 : $slot_duration );
			$slots_scheduled = max( 1, (int) ceil( $total_duration_minutes / max( 1, $base_interval_minutes ) ) );
		} else {
			$start_ts = ! empty( $data['_start_date'] ) ? (int) $data['_start_date'] : 0;
			$end_ts   = ! empty( $data['_end_date'] ) ? (int) $data['_end_date'] : 0;
			if ( in_array( $slot_unit, [ 'day', 'night' ], true ) && $start_ts > 0 && $end_ts > $start_ts ) {
				$slots_scheduled = max( 1, (int) floor( ( $end_ts - $start_ts ) / DAY_IN_SECONDS / max( 1, (int) $slot_duration ) ) );
			} elseif ( isset( $data['_duration'] ) ) {
				$slots_scheduled = WC_Appointments_Constants::DURATION_HOUR === $slot_unit
					? (int) ceil( absint( $data['_duration'] ) / 60 )
					: absint( $data['_duration'] );
				$slots_scheduled = max( 1, (int) ceil( $slots_scheduled / max( 1, (int) $slot_duration ) ) );
			} else {
				$slots_scheduled = 1;
			}
		}

		// Check pricing rules for start date only;
		if ( apply_filters( 'appointment_form_pricing_rules_for_start_date', false ) ) {
			if ( in_array( $slot_unit, [ 'minute', 'hour' ] ) && $apply_cost_per_interval ) {
				$slots_scheduled = 1;
			} else {
				$slot_duration = 1;
			}
		}

		// Padding duration (day / month units): block days covered by before/after buffers.
		if ( ( $product->get_padding_duration() || $product->get_padding_after_duration() ) && ! in_array( $slot_unit, [ 'minute', 'hour' ], true ) ) {
            $padding_days          = WC_Appointment_Slots_Provider::get_padding_days_for_product( $product );
            $contains_padding_days = false;
            // Evaluate costs for each scheduled slot
            for ( $slot = 0; $slot < $slots_scheduled; $slot ++ ) {
					$slot_start_time_offset = $slot * $slot_duration;
					$slot_end_time_offset   = ( ( $slot + 1 ) * $slot_duration ) - 1;
					$slot_start_time        = gmdate( 'Y-n-j', strtotime( "+{$slot_start_time_offset} {$slot_unit}", $slot_timestamp ) );
					$slot_end_time          = gmdate( 'Y-n-j', strtotime( "+{$slot_end_time_offset} {$slot_unit}", $slot_timestamp ) );

					if ( in_array( $slot_end_time, $padding_days, true ) ) {
						$contains_padding_days = true;
					}

					if ( in_array( $slot_start_time, $padding_days, true ) ) {
						$contains_padding_days = true;
					}
				}
            if ( $contains_padding_days ) {
					return new WP_Error( 'Error', __( 'Sorry, the selected day is not available.', 'woocommerce-appointments' ) );
				}
        }

		$span_step_unit = ( 'night' === $slot_unit ) ? 'day' : $slot_unit;

		// Evaluate costs for each scheduled slot.
		for ( $slot = 0; $slot < $slots_scheduled; $slot ++ ) {
			if ( $catalog_span_unit ) {
				$slot_start_ts = WC_Appointment_Slots_Pricing::checkout_span_instant( (int) $slot_timestamp, $slot * $slot_duration, $span_step_unit, $use_slot_token_ts );
				$slot_end_ts   = WC_Appointment_Slots_Pricing::checkout_span_instant( (int) $slot_timestamp, ( $slot + 1 ) * $slot_duration, $span_step_unit, $use_slot_token_ts );
				$slot_cost     = WC_Appointment_Slots_Pricing::compute_slot_price( $product, $slot_start_ts, $slot_end_ts, 0, $slot_unit, (float) $catalog_unit_base );

				if ( 0 === $slot ) {
					foreach ( $costs as $rule_key => $rule ) {
						$type  = $rule[0];
						$rules = $rule[1];
						if ( 'slots' === $type && ! empty( $data['_duration'] ) && intval( $rules['from'] ) <= $data['_duration'] && intval( $rules['to'] ) >= $data['_duration'] ) {
							$slot_cost = self::apply_cost( $slot_cost, $rules['rule']['slot'][0], $rules['rule']['slot'][1] );
							$base_cost = self::apply_base_cost( $base_cost, $rules['rule']['base'][0], $rules['rule']['base'][1], $rule_key );
						} elseif ( 'quant' === $type && ! empty( $data['_qty'] ) && $rules['from'] <= $data['_qty'] && $rules['to'] >= $data['_qty'] ) {
							$slot_cost = self::apply_cost( $slot_cost, $rules['rule']['slot'][0], $rules['rule']['slot'][1] );
							$base_cost = self::apply_base_cost( $base_cost, $rules['rule']['base'][0], $rules['rule']['base'][1], $rule_key );
						}
					}
				}

				$total_slot_cost += $slot_cost;
				continue;
			}

			$slot_cost = $base_slot_cost;
			if ( $apply_cost_per_interval ) {
				[$duration_minutes, $base_interval_minutes] = $product->get_intervals();
				$start_offset_minutes = $slot * max( 1, $base_interval_minutes );
				$end_offset_minutes   = ( $slot + 1 ) * max( 1, $base_interval_minutes );
				$slot_start_time      = $slot_times_fmt( strtotime( "+{$start_offset_minutes} minutes", $slot_timestamp ) );
				$slot_end_time        = $slot_times_fmt( strtotime( "+{$end_offset_minutes} minutes", $slot_timestamp ) );
			} else {
				$slot_start_time_offset = $slot * $slot_duration;
				$slot_end_time_offset   = ( $slot + 1 ) * $slot_duration;
				$slot_start_time        = $slot_times_fmt( strtotime( "+{$slot_start_time_offset} {$slot_unit}", $slot_timestamp ) );
				$slot_end_time          = $slot_times_fmt( strtotime( "+{$slot_end_time_offset} {$slot_unit}", $slot_timestamp ) );
			}

			foreach ( $costs as $rule_key => $rule ) {
				$type         = $rule[0];
				$rules        = $rule[1];
				$rule_applied = false;

				if ( strrpos( $type, 'time' ) === 0 ) {
					if ( 'time:range' === $type ) {
						$year  = $slot_start_time['year'];
						$month = $slot_start_time['month'];
						$day   = $slot_start_time['day'];

						if ( ! isset( $rules[ $year ][ $month ][ $day ] ) ) {
							continue;
						}

						$rule_val = $rules[ $year ][ $month ][ $day ]['rule'];
						$from     = $rules[ $year ][ $month ][ $day ]['from'];
						$to       = $rules[ $year ][ $month ][ $day ]['to'];
					} else {
						if ( ! empty( $rules['day'] ) && (int) $rules['day'] !== (int) $slot_start_time['day_of_week'] ) {
							continue;
						}

						$rule_val = $rules['rule'];
						$from     = $rules['from'];
						$to       = $rules['to'];
					}

					[ $rule_start_time_hi, $rule_end_time_hi ] = $use_slot_token_ts
						? self::time_rule_start_end_hi_slot_token( (int) $slot_start_time['timestamp'], (string) $from, (string) $to )
						: self::time_rule_start_end_hi_site_local( (int) $slot_start_time['timestamp'], (string) $from, (string) $to );

					// Slot cost: match as before; Base cost: apply on any overlap (corrected)
					$slot_matched = false;
					$base_matched = false;
					// Default base cost behavior is centralized; legacy logic kept out of sight.
					$default_apply_base_overlap = $pricing_defaults['apply_base_overlap_default'];
					$apply_base_overlap = apply_filters( 'woocommerce_appointments_base_cost_apply_on_overlap', $default_apply_base_overlap, $product, $rule_key, $rule_val );

                    // Reverse time rule - The end time is tomorrow e.g. 16:00 today - 12:00 tomorrow
                    if ( $rule_end_time_hi <= $rule_start_time_hi ) {
                        // Keep existing behavior for slot cost matching
                        if ( $slot_end_time['time'] > $rule_start_time_hi ) {
                            $slot_matched = true;
                        }
                        if ( $slot_start_time['time'] >= $rule_start_time_hi && $slot_end_time['time'] >= $rule_end_time_hi ) {
                            $slot_matched = true;
                        }
                        if ( $slot_start_time['time'] <= $rule_start_time_hi && $slot_end_time['time'] <= $rule_end_time_hi ) {
                            $slot_matched = true;
                        }

                        // Base cost behavior: overlap-based (default) or full-include-based via filter
                        if ( $apply_base_overlap ) {
                            // Edges exclusive overlap across midnight
                            if ( $slot_end_time['time'] > $rule_start_time_hi || $slot_start_time['time'] < $rule_end_time_hi ) {
                                $base_matched = true;
                            }
                        } else {
                            // Revert: base cost only when fully within rule window (match slot)
                            $base_matched = $slot_matched;
                        }
                    } else {
                        // Normal rule
                        // Slot cost only when fully within the rule window (unchanged)
                        if ( $slot_start_time['time'] >= $rule_start_time_hi && $slot_end_time['time'] <= $rule_end_time_hi ) {
                            $slot_matched = true;
                        }
                        // Base cost behavior: overlap-based (default) or full-include-based via filter
                        if ( $apply_base_overlap ) {
                            // Any overlap with the rule window
                            if ( $slot_start_time['time'] < $rule_end_time_hi && $slot_end_time['time'] > $rule_start_time_hi ) {
                                $base_matched = true;
                            }
                        } else {
                            // Revert: base cost only when fully within rule window (match slot)
                            $base_matched = $slot_matched;
                        }
                    }

                    if ( $slot_matched ) {
                        $slot_cost    = self::apply_cost( $slot_cost, $rule_val['slot'][0], $rule_val['slot'][1] );
                        $rule_applied = true;
                    }
                    if ( $base_matched ) {
						$base_cost    = self::apply_base_cost( $base_cost, $rule_val['base'][0], $rule_val['base'][1], $rule_key );
                        $rule_applied = true;
                    }
				} else {
					switch ( $type ) {
						case 'months':
						case 'weeks':
						case 'days':
							$check_date = $slot_start_time['timestamp'];

							while ( $check_date < $slot_end_time['timestamp'] ) {
								$checking_date = $slot_times_fmt( $check_date );
								$date_key      = 'days' == $type ? 'day_of_week' : substr( $type, 0, -1 );

								// Cater to months beyond this year.
								if ( 'month' === $date_key && intval( $checking_date['year'] ) > intval( date( 'Y' ) ) ) {
									$month_beyond_this_year = intval( $checking_date['month'] ) + 12;
									$checking_date['month'] = (string) ( $month_beyond_this_year % 12 );
									if ( '0' === $checking_date['month'] ) {
										$checking_date['month'] = '12';
									}
								}

								if ( isset( $rules[ $checking_date[ $date_key ] ] ) ) {
									$rule         = $rules[ $checking_date[ $date_key ] ];
									$slot_cost    = self::apply_cost( $slot_cost, $rule['slot'][0], $rule['slot'][1] );
									$base_cost    = self::apply_base_cost( $base_cost, $rule['base'][0], $rule['base'][1], $rule_key );
									$rule_applied = true;
								}
								$check_date = strtotime( "+1 {$type}", $check_date );
							}
							break;
						case 'custom':
							$check_date = $slot_start_time['timestamp'];

							while ( $check_date < $slot_end_time['timestamp'] ) {
								$checking_date = $slot_times_fmt( $check_date );
								if ( isset( $rules[ $checking_date['year'] ][ $checking_date['month'] ][ $checking_date['day'] ] ) ) {
									$rule         = $rules[ $checking_date['year'] ][ $checking_date['month'] ][ $checking_date['day'] ];
									$slot_cost    = self::apply_cost( $slot_cost, $rule['slot'][0], $rule['slot'][1] );
									$base_cost    = self::apply_base_cost( $base_cost, $rule['base'][0], $rule['base'][1], $rule_key );
									$rule_applied = true;

									/*
									 * Why do we break?
									 * See: Applying a cost rule to an appointment slot
									 * from the DEVELOPER.md
									 */
									break;
								}
								$check_date = strtotime( '+1 day', $check_date );
							}
							break;
						case 'slots':
							if ( 0 === $slot && !empty( $data['_duration'] ) && (intval( $rules['from'] ) <= $data['_duration'] && intval( $rules['to'] ) >= $data['_duration'])) {
                                $slot_cost    = self::apply_cost( $slot_cost, $rules['rule']['slot'][0], $rules['rule']['slot'][1] );
								$base_cost    = self::apply_base_cost( $base_cost, $rules['rule']['base'][0], $rules['rule']['base'][1], $rule_key );
                                $rule_applied = true;
                            }
							break;
						case 'quant':
							if ( 0 === $slot && !empty( $data['_qty'] ) && ($rules['from'] <= $data['_qty'] && $rules['to'] >= $data['_qty'])) {
                                $slot_cost    = self::apply_cost( $slot_cost, $rules['rule']['slot'][0], $rules['rule']['slot'][1] );
								$base_cost    = self::apply_base_cost( $base_cost, $rules['rule']['base'][0], $rules['rule']['base'][1], $rule_key );
                                $rule_applied = true;
                            }
							break;
					}
				}
				/**
				 * Filter to modify rule cost logic. By default, all relevant cost rules will be
				 * applied to a slot. Hooks returning false can modify this so only the first
				 * applicable rule will modify the slot cost.
				 *
				 * @since 4.8.14
				 * @param bool                   $apply_multiple_rules Whether to apply multiple rules per slot.
				 * @param WC_Product_Appointment $product              Current appointable product.
				 */
				if ( $rule_applied && ( ! apply_filters( 'woocommerce_appointments_apply_multiple_rules_per_slot', true, $product ) ) ) {
					break;
				}
			}
			$total_slot_cost += $slot_cost;
		}

		if ( $catalog_span_unit ) {
			self::$appointment_cost = max( 0, $total_slot_cost + max( 0, $base_cost - $catalog_unit_base ) );
		} else {
			self::$appointment_cost = max( 0, $total_slot_cost + $base_cost );
		}

		// Multiply costs, when multiple qty scheduled.
		if ( 1 < $data['_qty'] ) {
			self::$appointment_cost *= absint( $data['_qty'] );
		}

		return apply_filters( 'appointment_form_calculated_appointment_cost', self::$appointment_cost, $product, $posted );
	}

	/**
	 * First matching sessions rule on a recurring package subtotal (after estimate_total_price).
	 *
	 * Uses base_modifier/base_cost only (slot columns are ignored).
	 *
	 * @param float      $subtotal       Per-session sum.
	 * @param WC_Product $product        Appointable product.
	 * @param int        $billable_count Billable sessions.
	 * @return float
	 */
	public static function apply_recurring_package_pricing( float $subtotal, $product, int $billable_count ): float {
		$subtotal = (float) $subtotal;
		if ( $billable_count <= 0 || ! is_wc_appointment_product( $product ) ) {
			return $subtotal;
		}

		foreach ( $product->get_pricing() as $rule_key => $rule ) {
			if ( ! is_array( $rule ) || ! self::is_sessions_pricing_rule( $rule ) || ! self::pricing_rule_matches_count( $rule, $billable_count ) ) {
				continue;
			}

			$modifier = (string) ( $rule['base_modifier'] ?? '' );
			$cost     = (float) ( $rule['base_cost'] ?? 0 );
			if ( $cost && ( 'minus' === $modifier || '' === $modifier ) ) {
				$cost *= $billable_count;
			}

			return (float) apply_filters(
				'wc_appointments_recurring_package_total',
				round( max( 0, self::apply_cost( $subtotal, $modifier, $cost ) ), wc_get_price_decimals() ),
				$subtotal,
				$billable_count,
				$product,
				$rule
			);
		}

		return $subtotal;
	}

	/**
	 * Apply a cost.
	 *
	 * @since 1.15.0
	 * @param  float  $base       Base cost.
	 * @param  string $multiplier Multiplier type (times, divide, minus, equals, etc).
	 * @param  float  $cost       Cost to apply.
	 * @return float New cost.
	 */
	public static function apply_cost( $base, $multiplier, $cost ): float {
		$base = floatval( $base );
		$cost = floatval( $cost );

		if ( 0.0 === $cost ) {
			return $base;
		}

		switch ( $multiplier ) {
			case 'times':
				$new_cost = $base * $cost;
				break;
			case 'divide':
				$new_cost = $base / $cost;
				break;
			case 'minus':
				$new_cost = $base - $cost;
				break;
			case 'equals':
				$new_cost = $cost;
				break;
			default:
				$new_cost = $base + $cost;
				break;
		}

		return $new_cost;
	}

	/**
	 * Apply base cost.
	 *
	 * @since 4.7.0
	 *
	 * @param  float $base
	 * @param  string $multiplier
	 * @param  float $cost
	 * @param  string|int $rule_key Cost to apply the rule to - used for * and /
	 *
	 * @return float
	 */
	private static function apply_base_cost( $base, $multiplier, $cost, $rule_key = '' ) {
		if ( ! $cost || in_array( $rule_key, self::$applied_cost_rules ) ) {
			return $base;
		}

		self::$applied_cost_rules[] = $rule_key;

		return self::apply_cost( $base, $multiplier, $cost );
	}

}

