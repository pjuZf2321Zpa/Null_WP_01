<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Main WC_Appointments_Admin class.
 */
class WC_Appointments_Admin {

	private static self $_this;

	/**
	 * Constructor
	 */
	public function __construct() {
		self::$_this = $this;

		// Add to <head> in admin.
		add_action( 'admin_head', [ $this, 'appointments_admin_head' ], 11, 0 );

		// Load correct list table classes for current screen.
		add_action( 'current_screen', [ $this, 'setup_screen' ] );
		add_action( 'current_screen', [ $this, 'add_whats_new_help_tab' ], 20 );
		add_action( 'check_ajax_referer', [ $this, 'setup_screen' ], 10, 2 );

		add_action( 'woocommerce_product_duplicate', [ $this, 'woocommerce_duplicate_product' ], 10, 2 );
		add_filter( 'post_updated_messages', [ $this, 'post_updated_messages' ] );
		add_action( 'admin_init', [ $this, 'init_tabs' ], 10, 0 );
		add_action( 'admin_init', [ $this, 'include_meta_box_handlers' ], 10, 0 );
		add_action( 'admin_init', [ $this, 'redirect_new_add_appointment_url' ], 10, 0 );
		add_action( 'woocommerce_product_options_inventory_product_data', [ $this, 'appointment_inventory' ], 10, 0 );
		add_filter( 'product_type_options', [ $this, 'product_type_options' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'styles_and_scripts' ] );
		add_action( 'woocommerce_product_options_general_product_data', [ $this, 'appointment_general' ], 10, 0 );
		add_action( 'load-options-general.php', [ $this, 'reset_ics_exporter_timezone_cache' ], 10, 0 );
		add_action( 'woocommerce_before_order_itemmeta', [ $this, 'appointment_display' ], 10, 3 );
		add_filter( 'woocommerce_get_settings_pages', [ $this, 'add_settings_page' ], 10, 1 );
		add_filter( 'woocommerce_template_overrides_scan_paths', [ $this, 'template_scan_path' ] );
		add_filter( 'woocommerce_product_type_query', [ $this, 'maybe_override_product_type' ], 10, 2 );
		add_action( 'woocommerce_admin_order_item_headers', [ $this, 'intercept_order_item_deprecations' ], 10, 0 );
		add_action( 'woocommerce_admin_order_items_after_tax', [ $this, 'restore_order_item_deprecations' ], 10, 0 );

		// Saving data.
		add_action( 'woocommerce_process_product_meta', [ $this, 'save_product_data' ], 20 );
		add_action( 'woocommerce_admin_process_product_object', [ $this, 'set_props' ], 20 );
		add_action( 'before_delete_post', [ $this, 'before_delete_product' ], 11 );
		add_action( 'admin_notices', [ $this, 'product_config_notices' ], 20 );

		include __DIR__ . '/class-wc-appointments-admin-menus.php';
		include __DIR__ . '/class-wc-appointments-admin-staff-profile.php';
		include __DIR__ . '/class-wc-appointments-admin-availability-hub.php';
		include __DIR__ . '/export/class-wc-appointments-export-manager.php';
		include __DIR__ . '/class-wc-appointments-admin-exporters.php';
	}

	/**
	 * Add meta tags and scripts to <head> in admin.
	 *
	 * @since 4.10.7
	 */
	public function appointments_admin_head(): void {
		$client_id_raw = filter_input( INPUT_POST, 'wc_appointments_gcal_client_id' );
		$client_id     = is_string( $client_id_raw ) ? sanitize_text_field( wp_unslash( $client_id_raw ) ) : '';
		$client_id     = $client_id ?: (string) get_option( 'wc_appointments_gcal_client_id', '' );

		if ( $client_id ) {
			echo '<meta name="google-signin-client_id" content="' . esc_attr( $client_id ) . '">';
		}

	}

	/**
	 * Looks at the current screen and loads the correct list table handler.
	 *
	 * @since 3.3.0
	 */
	public function setup_screen(): void {
		global $wc_list_table;

		$screen_id = false;

		if ( function_exists( 'get_current_screen' ) ) {
			$screen    = get_current_screen();
			$screen_id = $screen->id ?? '';
		}

		$request_screen = filter_input( INPUT_GET, 'screen' );
		if ( null === $request_screen || false === $request_screen ) {
			$request_screen = filter_input( INPUT_POST, 'screen' );
		}
		if ( is_string( $request_screen ) && '' !== $request_screen ) {
			$screen_id = wc_clean( wp_unslash( $request_screen ) );
		}

		if ('edit-wc_appointment' === $screen_id) {
            include_once __DIR__ . '/class-wc-appointments-admin-list-table.php';
            $wc_list_table = new WC_Appointments_Admin_List_Table();
        }

		// Ensure the table handler is only loaded once. Prevents multiple loads if a plugin calls check_ajax_referer many times.
		remove_action( 'current_screen', [ $this, 'setup_screen' ] );
		remove_action( 'check_ajax_referer', [ $this, 'setup_screen' ] );
	}

	/**
	 * Add a Help tab linking to the Appointments "What's New" page on Appointments admin screens
	 * (skipped on the What's New page itself - no self-link).
	 *
	 * @return void
	 */
	public function add_whats_new_help_tab(): void {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( ! $screen || empty( $screen->id ) ) {
			return;
		}

		// Only add the tab on Appointments-related admin screens.
		if ( false === strpos( $screen->id, 'wc_appointment' ) ) {
			return;
		}

		// Already on What's New: a Help tab that links here is redundant.
		if ( ! empty( $screen->id ) && false !== strpos( $screen->id, WC_Appointments_Admin_Whats_New::PAGE_SLUG ) ) {
			return;
		}
		if ( isset( $_GET['page'] ) && WC_Appointments_Admin_Whats_New::PAGE_SLUG === sanitize_key( wp_unslash( $_GET['page'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		// Respect capabilities required to view the landing page.
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		// Avoid adding the tab more than once.
		foreach ( (array) $screen->get_help_tabs() as $tab ) {
			if ( isset( $tab['id'] ) && 'wc_appointments_whats_new' === $tab['id'] ) {
				return;
			}
		}

		$whats_new_url = admin_url( 'edit.php?post_type=wc_appointment&page=' . WC_Appointments_Admin_Whats_New::PAGE_SLUG );

		$screen->add_help_tab(
		    [
				'id'      => 'wc_appointments_whats_new',
				'title'   => __( "What's New", 'woocommerce-appointments' ),
				'content' => wp_kses_post(
				    sprintf(
				        '<p>%1$s</p><p><a href="%2$s">%3$s</a></p>',
				        __( 'Read about the latest updates in WooCommerce Appointments.', 'woocommerce-appointments' ),
				        esc_url( $whats_new_url ),
				        __( 'Open the What\'s New page', 'woocommerce-appointments' ),
				    ),
				),
			],
		);
	}

	/**
	 * Save Appointment data for the product in 2.6.x.
	 *
	 * @param int $post_id
	 * @return void
	 */
	public function save_product_data( $post_id ): void {
		$product_type_raw = filter_input( INPUT_POST, 'product-type' );
		$product_type     = is_string( $product_type_raw ) ? sanitize_title( wp_unslash( $product_type_raw ) ) : '';
		if ( version_compare( WC_VERSION, '3.0', '>=' ) || 'appointment' !== $product_type ) {
			return;
		}
		$product = get_wc_product_appointment( $post_id );
		$this->set_props( $product );
		$product->save();
	}

	/**
	 * @return array<string, mixed>
	 */
	private function get_product_post_data(): array {
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- WooCommerce product save verifies nonce; wc_clean() per field below.
	}

	/**
	 * Get posted pricing fields and format.
	 *
	 * @since 1.0.0
	 *
	 * @return list<array<string, mixed>>
	 */
	private function get_posted_pricing(): array {
		$pricing  = [];
		$post     = $this->get_product_post_data();
		$row_size = count( $post['wc_appointment_pricing_type'] ?? [] );
		for ( $i = 0; $i < $row_size; $i ++ ) {
			$pricing[ $i ]['type']          = wc_clean( $post['wc_appointment_pricing_type'][ $i ] ?? '' );
			$pricing[ $i ]['cost']          = wc_clean( $post['wc_appointment_pricing_cost'][ $i ] ?? '' );
			$pricing[ $i ]['modifier']      = wc_clean( $post['wc_appointment_pricing_cost_modifier'][ $i ] ?? '' );
			$pricing[ $i ]['base_cost']     = wc_clean( $post['wc_appointment_pricing_base_cost'][ $i ] ?? '' );
			$pricing[ $i ]['base_modifier'] = wc_clean( $post['wc_appointment_pricing_base_cost_modifier'][ $i ] ?? '' );

			switch ( $pricing[ $i ]['type'] ) {
				case 'custom':
					$pricing[ $i ]['from'] = wc_clean( $post['wc_appointment_pricing_from_date'][ $i ] ?? '' );
					$pricing[ $i ]['to']   = wc_clean( $post['wc_appointment_pricing_to_date'][ $i ] ?? '' );
					break;
				case 'months':
					$pricing[ $i ]['from'] = wc_clean( $post['wc_appointment_pricing_from_month'][ $i ] ?? '' );
					$pricing[ $i ]['to']   = wc_clean( $post['wc_appointment_pricing_to_month'][ $i ] ?? '' );
					break;
				case 'weeks':
					$pricing[ $i ]['from'] = wc_clean( $post['wc_appointment_pricing_from_week'][ $i ] ?? '' );
					$pricing[ $i ]['to']   = wc_clean( $post['wc_appointment_pricing_to_week'][ $i ] ?? '' );
					break;
				case 'days':
					$pricing[ $i ]['from'] = wc_clean( $post['wc_appointment_pricing_from_day_of_week'][ $i ] ?? '' );
					$pricing[ $i ]['to']   = wc_clean( $post['wc_appointment_pricing_to_day_of_week'][ $i ] ?? '' );
					break;
				case 'time':
				case 'time:1':
				case 'time:2':
				case 'time:3':
				case 'time:4':
				case 'time:5':
				case 'time:6':
				case 'time:7':
					$pricing[ $i ]['from'] = wc_appointment_sanitize_time( $post['wc_appointment_pricing_from_time'][ $i ] ?? '' );
					$pricing[ $i ]['to']   = wc_appointment_sanitize_time( $post['wc_appointment_pricing_to_time'][ $i ] ?? '' );
					break;
				case 'time:range':
					$pricing[ $i ]['from'] = wc_appointment_sanitize_time( $post['wc_appointment_pricing_from_time'][ $i ] ?? '' );
					$pricing[ $i ]['to']   = wc_appointment_sanitize_time( $post['wc_appointment_pricing_to_time'][ $i ] ?? '' );

					$pricing[ $i ]['from_date'] = wc_clean( $post['wc_appointment_pricing_from_date'][ $i ] ?? '' );
					$pricing[ $i ]['to_date']   = wc_clean( $post['wc_appointment_pricing_to_date'][ $i ] ?? '' );
					break;
				default:
					$pricing[ $i ]['from'] = wc_clean( $post['wc_appointment_pricing_from'][ $i ] ?? '' );
					$pricing[ $i ]['to']   = wc_clean( $post['wc_appointment_pricing_to'][ $i ] ?? '' );
					break;
			}

			if ( WC_Appointments_Cost_Calculation::is_sessions_pricing_rule( $pricing[ $i ] ) ) {
				$pricing[ $i ]['cost']     = '';
				$pricing[ $i ]['modifier'] = '';
			}
		}
		return $pricing;
	}

	/**
	 * Get posted staff.
	 *
	 * Staffs are global, but appointment products store information about the relationship.
	 *
	 * @since 1.0.0
	 *
	 * @return array<int, array{base_cost: string, qty: string}>
	 */
	private function get_posted_staff(): array {
		$staff = [];
		$post  = $this->get_product_post_data();
		// Prefer keyed rows from the product Staff tab (DOM order = assignment order).
		if ( isset( $post['wca_staff'] ) && is_array( $post['wca_staff'] ) ) {
			foreach ( $post['wca_staff'] as $staff_id => $row ) {
				$staff_id = absint( $staff_id );
				if ( ! $staff_id || ! is_array( $row ) ) {
					continue;
				}
				$staff[ $staff_id ] = [
					'base_cost' => wc_clean( $row['cost'] ?? '' ),
					'qty'       => wc_clean( $row['qty'] ?? '' ),
				];
			}
			return $staff;
		}
		// Legacy loop-indexed fields (staff profile / older posts).
		if ( isset( $post['staff_id'] ) && is_array( $post['staff_id'] ) ) {
			$staff_ids        = $post['staff_id'];
			$staff_menu_order = $post['staff_menu_order'] ?? [];
			$staff_base_cost  = $post['staff_cost'] ?? [];
			$staff_qty        = $post['staff_qty'] ?? [];

			foreach ( $staff_menu_order as $key => $value ) {
				$staff[ absint( $staff_ids[ $key ] ?? 0 ) ] = [
					'base_cost' => wc_clean( $staff_base_cost[ $key ] ?? '' ),
					'qty'       => wc_clean( $staff_qty[ $key ] ?? '' ),
				];
			}
		}
		return $staff;
	}

	/**
	 * Get posted appointment product properties from POST data.
	 *
	 * Sanitizes and extracts all appointment product properties from $_POST.
	 * Returns an array ready to be passed to set_props().
	 *
	 * @since 5.0.2
	 * @return array<string, mixed> Array of sanitized appointment product properties.
	 */
	private function get_posted_appointment_props(): array {
		$prefix = '_wc_appointment_';
		$post   = $this->get_product_post_data();

		// Helper to get POST value with optional default.
		$get_posted = function( string $key, $default = '' ) use ( $prefix, $post ) {
			$full_key = $prefix . $key;
			return wc_clean( $post[ $full_key ] ?? '' ) ?: $default;
		};

		// Helper to check if POST key exists (for boolean fields).
		$has_posted = fn( string $key ): bool => isset( $post[ $prefix . $key ] );

		// Get qty_basis with validation.
		$qty_basis = $get_posted( 'qty_basis', WC_Product_Appointment::QTY_BASIS_SLOT );
		$qty_basis = in_array( $qty_basis, [ WC_Product_Appointment::QTY_BASIS_DAY, WC_Product_Appointment::QTY_BASIS_SLOT ], true )
			? $qty_basis
			: WC_Product_Appointment::QTY_BASIS_SLOT;

		$staff = $this->get_posted_staff();
		list( $location_mode, $location_ids, $location_costs ) = $this->get_posted_location_props();

		return [
			'has_price_label'         => $has_posted( 'has_price_label' ),
			'price_label'             => $get_posted( 'price_label' ),
			'has_pricing'             => $has_posted( 'has_pricing' ),
			'pricing'                 => $this->get_posted_pricing(),
			'qty'                     => $get_posted( 'qty' ),
			'qty_basis'               => $qty_basis,
			'qty_min'                 => $get_posted( 'qty_min' ),
			'qty_max'                 => $get_posted( 'qty_max' ),
			'duration_unit'           => $get_posted( 'duration_unit' ),
			'duration'                => $get_posted( 'duration' ),
			'interval_unit'           => $get_posted( 'interval_unit' ),
			'interval'                => $get_posted( 'interval' ),
			'padding_duration_unit'   => $get_posted( 'padding_duration_unit' ),
			'padding_duration'        => $get_posted( 'padding_duration' ),
			'padding_after_duration'  => $get_posted( 'padding_after_duration' ),
			'min_date_unit'           => $get_posted( 'min_date_unit' ),
			'min_date'                => $get_posted( 'min_date' ),
			'max_date_unit'           => $get_posted( 'max_date_unit' ),
			'max_date'                => $get_posted( 'max_date' ),
			'user_can_cancel'         => $has_posted( 'user_can_cancel' ),
			'cancel_limit_unit'       => $get_posted( 'cancel_limit_unit' ),
			'cancel_limit'            => $get_posted( 'cancel_limit' ),
			'user_can_reschedule'     => $has_posted( 'user_can_reschedule' ),
			'reschedule_limit_unit'   => $get_posted( 'reschedule_limit_unit' ),
			'reschedule_limit'        => $get_posted( 'reschedule_limit' ),
			'requires_confirmation'   => $has_posted( 'requires_confirmation' ),
			'cal_color'               => in_array( $get_posted( 'cal_color' ), [ '', '#000000' ], true ) ? self::get_default_cal_color() : $get_posted( 'cal_color' ),
			'availability_span'       => $get_posted( 'availability_span' ),
			'availability_autoselect' => $has_posted( 'availability_autoselect' ),
			'has_restricted_days'     => $has_posted( 'has_restricted_days' ),
			'restricted_days'         => wc_clean( $post[ $prefix . 'restricted_days' ] ?? '' ),
			'staff_label'             => $get_posted( 'staff_label' ),
			'staff_ids'               => array_keys( $staff ),
			'staff_base_costs'        => wp_list_pluck( $staff, 'base_cost' ),
			'staff_qtys'              => wp_list_pluck( $staff, 'qty' ),
			'staff_assignment'        => $get_posted( 'staff_assignment' ),
			'staff_nopref'            => $has_posted( 'staff_nopref' ),
			'location_mode'           => $location_mode,
			'location_ids'            => $location_ids,
			'location_costs'          => $location_costs,
			'location_label'          => $get_posted( 'location_label' ),
			'resource_requirements'   => $this->get_posted_resource_requirements(),
			'resource_label'          => $get_posted( 'resource_label' ),
			'resource_assignment'     => $this->get_posted_resource_assignment(),
			'meeting_provider'        => $this->get_posted_meeting_provider(),
			'appointments_version'    => WC_APPOINTMENTS_VERSION,
			'appointments_db_version' => WC_APPOINTMENTS_DB_VERSION,
		];
	}

	/**
	 * Sanitize posted resource assignment mode.
	 *
	 * @since 5.5.0
	 * @return string
	 */
	private function get_posted_resource_assignment(): string {
		$post = $this->get_product_post_data();
		$mode = wc_clean( $post['_wc_appointment_resource_assignment'] ?? 'display' );
		return in_array( $mode, [ 'hidden', 'display', 'customer' ], true ) ? $mode : 'display';
	}

	/**
	 * Sanitize posted meeting provider (none|google_meet).
	 *
	 * @since 5.5.0
	 * @return string
	 */
	private function get_posted_meeting_provider(): string {
		$post     = $this->get_product_post_data();
		$provider = wc_clean( $post['_wc_appointment_meeting_provider'] ?? 'none' );
		return in_array( $provider, [ 'none', 'google_meet' ], true ) ? $provider : 'none';
	}

	/**
	 * Sanitize posted location mode.
	 *
	 * @since 5.5.0
	 * @return string
	 */
	private function get_posted_location_mode(): string {
		$post = $this->get_product_post_data();
		$mode = wc_clean( $post['_wc_appointment_location_mode'] ?? 'none' );
		return in_array( $mode, [ 'none', 'fixed', 'hidden', 'customer_choice' ], true ) ? $mode : 'none';
	}

	/**
	 * Sanitize posted location IDs. Fixed / Fixed (hidden) keeps one. Customer selected stores empty unless two or more are picked (empty = every location A-Z). Order of posted IDs is the storefront dropdown order (first = default).
	 *
	 * @since 5.5.0
	 * @return int[]
	 */
	private function get_posted_location_ids(): array {
		$post = $this->get_product_post_data();
		$mode = $this->get_posted_location_mode();
		$ids  = isset( $post['_wc_appointment_location_ids'] ) ? array_map( 'absint', (array) $post['_wc_appointment_location_ids'] ) : [];
		$ids  = array_values( array_filter( $ids ) );
		if ( WC_Appointments_Location::is_fixed_mode( $mode ) ) {
			$ids = $ids ? [ (int) $ids[0] ] : [];
		} elseif ( 'customer_choice' === $mode && count( $ids ) < 2 ) {
			$ids = [];
		}
		return $ids;
	}

	/**
	 * Resolve location mode, IDs, and costs for product save.
	 *
	 * @since 5.5.0
	 * @return array{0: string, 1: list<int>, 2: array<int, mixed>}
	 */
	private function get_posted_location_props(): array {
		$mode  = $this->get_posted_location_mode();
		$ids   = $this->get_posted_location_ids();
		$costs = [];
		foreach ( (array) ( $this->get_product_post_data()['wca_location'] ?? [] ) as $lid => $row ) {
			if ( ( $lid = (int) $lid ) > 0 ) {
				$costs[ $lid ] = is_array( $row ) ? ( $row['cost'] ?? 0 ) : 0;
			}
		}
		if ( WC_Appointments_Location::is_fixed_mode( $mode ) && [] === $ids ) {
			if ( class_exists( 'WC_Admin_Meta_Boxes' ) ) {
				WC_Admin_Meta_Boxes::add_error( __( 'Select a location, or set Location to None or Customer selected.', 'woocommerce-appointments' ) );
			}
			return [ 'none', [], [] ];
		}
		return [ $mode, $ids, $costs ];
	}

	/**
	 * Posted resource requirements from the product Resources tab (DOM order).
	 * Sanitized in WC_Product_Appointment::set_resource_requirements().
	 *
	 * @since 5.5.0
	 * @return list<array<string, mixed>>
	 */
	private function get_posted_resource_requirements(): array {
		$post = $this->get_product_post_data();
		$reqs = [];
		foreach ( (array) ( $post['wca_resource'] ?? [] ) as $rid => $row ) {
			$reqs[] = [
				'resource_id' => (int) $rid,
				'capacity'    => $row['capacity'] ?? 1,
				'cost'        => $row['cost'] ?? 0,
			];
		}
		return $reqs;
	}

	/**
	 * Set data in 3.0.x
	 *
	 * @version  3.3.0
	 * @param    WC_Product $product
	 * @return   void
	 */
	public function set_props( $product ): void {
		// Only set props if the product is a appointable product.
		if ( ! is_wc_appointment_product( $product ) ) {
			return;
		}

		$props = $this->get_posted_appointment_props();
		// Tab not rendered: keep stored values (missing POST would otherwise clear them).
		if ( ! WC_Appointments_Features::should_show_location_tab( $product ) ) {
			unset( $props['location_mode'], $props['location_ids'], $props['location_costs'], $props['location_label'] );
		}
		if ( ! WC_Appointments_Features::should_show_resources_tab( $product ) ) {
			unset( $props['resource_requirements'], $props['resource_label'], $props['resource_assignment'] );
		}
		$product->set_props( $props );
	}

	/**
	 * Init product edit tabs.
	 *
	 * @return void
	 */
	public function init_tabs(): void {
		add_filter( 'woocommerce_product_data_tabs', [ $this, 'register_tab' ], 5 );
		add_action( 'woocommerce_product_data_panels', [ $this, 'appointment_panels' ], 10, 0 );
	}

	/**
	 * Add tabs to WC 2.6+
	 *
	 * @param array<string, array<string, mixed>> $tabs
	 * @return array<string, array<string, mixed>>
	 */
	public function register_tab( array $tabs ): array {
		$product = get_wc_product_appointment( get_the_ID() );

		if ( WC_Appointments_Features::should_show_location_tab( $product ) ) {
			$tabs['appointments_locations'] = [
				'label'    => __( 'Location', 'woocommerce-appointments' ),
				'target'   => 'appointments_locations',
				'class'    => [
					'show_if_appointment',
				],
				'priority' => 24,
			];
		}
		if ( WC_Appointments_Features::should_show_resources_tab( $product ) ) {
			$tabs['appointments_resources'] = [
				'label'    => __( 'Resources', 'woocommerce-appointments' ),
				'target'   => 'appointments_resources',
				'class'    => [
					'show_if_appointment',
				],
				'priority' => 24,
			];
		}
		$tabs['appointments_staff'] = [
			'label'    => __( 'Staff', 'woocommerce-appointments' ),
			'target'   => 'appointments_staff',
			'class'    => [
				'show_if_appointment',
			],
			'priority' => 25,
		];
		$tabs['appointments_availability'] = [
			'label'    => __( 'Availability', 'woocommerce-appointments' ),
			'target'   => 'appointments_availability',
			'class'    => [
				'show_if_appointment',
			],
			'priority' => 25,
		];

		// Inventory
		$tabs['inventory']['class'][] = 'show_if_appointment';

		return $tabs;
	}

	/**
	 * Public access to instance object
	 *
	 * @return WC_Appointments_Admin
	 */
	public static function get_instance(): \WC_Appointments_Admin {
		return self::$_this;
	}

	/**
	 * Get the default calendar color for new appointable products.
	 *
	 * @since 5.0.2
	 * @return string Hex color string.
	 */
	public static function get_default_cal_color(): string {
		return '#0073aa';
	}

	/**
	 * Duplicate a post.
	 *
	 * @param  WC_Product $new_product Duplicated product.
	 * @param  WC_Product $product     Original product.
	 * @return void
	 */
	public function woocommerce_duplicate_product( $new_product, $product ): void {
		if ( is_wc_appointment_product( $product ) ) {
			// Get all product availability rules.
			$product_rules = WC_Data_Store::load( 'appointments-availability' )->get_all(
			    [
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => 'availability#product',
					],
					[
						'key'     => 'kind_id',
						'compare' => '=',
						'value'   => $product->get_id(),
					],
				],
			);

			// Stop here when no rules.
			if ( ! $product_rules ) {
				return;
			}

			// Clone and re-save availabilities.
			foreach ( $product_rules as $availability ) {
				$dupe_availability = clone $availability;
				$dupe_availability->set_id( 0 );
				$dupe_availability->set_kind_id( $new_product->get_id() );
				$dupe_availability->save();
			}
		}
	}

	/**
	 * Change messages when a post type is updated.
	 *
	 * @param array<string, array<int, string>> $messages
	 * @return array<string, array<int, string>>
	 */
	public function post_updated_messages( array $messages ): array {
		$messages['wc_appointment'] = [
			0  => '', // Unused. Messages start at index 1.
			1  => __( 'Appointment updated.', 'woocommerce-appointments' ),
			2  => __( 'Custom field updated.', 'woocommerce-appointments' ),
			3  => __( 'Custom field deleted.', 'woocommerce-appointments' ),
			4  => __( 'Appointment updated.', 'woocommerce-appointments' ),
			5  => '',
			6  => __( 'Appointment updated.', 'woocommerce-appointments' ),
			7  => __( 'Appointment saved.', 'woocommerce-appointments' ),
			8  => __( 'Appointment submitted.', 'woocommerce-appointments' ),
			9  => '',
			10 => '',
		];

		return $messages;
	}

	/**
	 * Show appointment data if a line item is linked to an appointment ID.
	 * @param mixed $item
	 * @param int $item_id
	 * @param WC_Product $product
	 */
	public function appointment_display( $item_id, $item, $product ): void {
		if ( ! is_wc_appointment_product( $product ) ) {
			return;
		}

		$order = wc_get_order( $item->get_order_id() );
		if ( $order && WC_Appointment_Series_Email::render_order_series_display( $item_id, $item, $order, true ) ) {
			return;
		}

		$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $item_id, true, $item->get_order_id() );

		wc_get_template(
		    'order/admin/appointment-display.php',
		    [
				'appointment_ids' => $appointment_ids,
				'is_rtl'          => is_rtl() ? 'right' : 'left',
			],
		    'woocommerce-appointments',
		    WC_APPOINTMENTS_TEMPLATE_PATH,
		);
	}

	/**
	 * Include meta box handlers
	 *
	 * @return void
	 */
	public function include_meta_box_handlers(): void {
		include __DIR__ . '/class-wc-appointments-admin-meta-boxes.php';
	}

	/**
	 * Redirect the default add appointment url to the custom one.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function redirect_new_add_appointment_url() {
	}

	/**
	 * Get appointment products.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $show_all Whether to show all products or just publish/private.
	 *
	 * @return list<WC_Product_Appointment|false>
	 */
	public static function get_appointment_products( $show_all = false ): array {
		$ids                  = WC_Data_Store::load( 'product-appointment' )->get_appointable_product_ids( $show_all );
		$appointable_products = [];

		if ( ! $ids ) {
			return $appointable_products;
		}

		foreach ( $ids as $id ) {
			$appointable_products[] = get_wc_product_appointment( $id );
		}

		return $appointable_products;
	}

	/**
	 * Get appointment staff.
	 *
	 * @since 1.0.0
	 *
	 * @return list<WP_User>
	 */
	public static function get_appointment_staff(): array {
		// Cache query.
		$cache_group = 'wc-appointments-admin-staff';
		$cache_key   = WC_Cache_Helper::get_cache_prefix( $cache_group ) . 'get_appointment_staff';

		$data = wp_cache_get( $cache_key, $cache_group );

		if ( false === $data ) {
			$data = get_users(
			    apply_filters(
			        'get_appointment_staff_args',
			        [
						'role'    => 'shop_staff',
						'orderby' => 'nicename',
						'order'   => 'asc',
					],
			    ),
			);

			wp_cache_set( $cache_key, $data, $cache_group );
		}

		return $data;
	}

	/**
	 * On before delete product hook remove the product from all appointments
	 *
	 * @param int $product_id The id of the product that we are deleting
	 * @return void
	 */
	public function before_delete_product( $product_id ): void {
		if ( ! current_user_can( 'delete_posts' ) ) {
			return;
		}

		if ( 0 < $product_id && 'product' === get_post_type( $product_id ) ) {
			$product_appointments = WC_Appointment_Data_Store::get_appointments_for_product( $product_id, get_wc_appointment_statuses( 'validate' ) );
			// Loop appointable products is added to remove the product from it
			foreach ( $product_appointments as $product_appointment ) {
				WC_Appointment_Data_Store::clear_product_id( (int) $product_appointment->get_id() );
			}
		}
	}

	/**
	 * Show the appointment inventory view
	 *
	 * @return void
	 */
	public function appointment_inventory(): void {
		global $appointable_product;

		if ( empty( $appointable_product ) || $appointable_product->get_id() !== get_the_ID() ) {
			$appointable_product = get_wc_product_appointment( get_the_ID() );
		}

		include __DIR__ . '/views/html-appointment-inventory.php';
	}

	/**
	 * Tweak product type options
	 *
	 * @param array<string, array<string, mixed>> $options
	 * @return array<string, array<string, mixed>>
	 */
	public function product_type_options( array $options ): array {
		$options['virtual']['wrapper_class']      .= ' show_if_appointment';
		$options['downloadable']['wrapper_class'] .= ' show_if_appointment';

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( get_the_ID() ) : false;
		if ( $product && $product->is_type( 'appointment' ) ) {
			$options['virtual']['description'] = __( 'Appointments are usually not shipped. Uncheck only if you send a physical item. Video calls use an Online location, not this checkbox.', 'woocommerce-appointments' );
		}

		return $options;
	}

	/**
	 * Show the appointment general view
	 *
	 * @return void
	 */
	public function appointment_general(): void {
		global $appointable_product;

		if ( empty( $appointable_product ) || $appointable_product->get_id() !== get_the_ID() ) {
			$appointable_product = get_wc_product_appointment( get_the_ID() );
		}

		include __DIR__ . '/views/html-appointment-general.php';
	}

	/**
	 * Show the appointment panels views
	 *
	 * @return void
	 */
	public function appointment_panels(): void {
		global $appointable_product;

		if ( empty( $appointable_product ) || $appointable_product->get_id() !== get_the_ID() ) {
			$appointable_product = get_wc_product_appointment( get_the_ID() );
		}

		wp_enqueue_script( 'wc_appointments_writepanel_js' );

		if ( WC_Appointments_Features::should_show_location_tab( $appointable_product ) ) {
			include __DIR__ . '/views/html-appointment-locations.php';
		}
		if ( WC_Appointments_Features::should_show_resources_tab( $appointable_product ) ) {
			include __DIR__ . '/views/html-appointment-resources.php';
		}
		include __DIR__ . '/views/html-appointment-staff.php';
		include __DIR__ . '/views/html-appointment-availability.php';
	}

	/**
	 * Add admin styles
	 *
	 * @return void
	 */
	public function styles_and_scripts(): void {
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style( 'wc_appointments_admin_styles', WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin.css', [], (string) filemtime( WC_APPOINTMENTS_ABSPATH . 'assets/css/admin.css' ) );
		wp_add_inline_style(
			'wc_appointments_admin_styles',
			'.wc-appointments-google-identity-btn.button{background:#fff!important;border:1px solid #747775!important;border-color:#747775!important;color:#1f1f1f!important;box-shadow:none!important;font-family:Roboto,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif!important;font-weight:500!important;font-size:14px!important;line-height:20px!important;height:auto!important;min-height:40px;padding:8px 12px!important;display:inline-flex!important;align-items:center!important;vertical-align:middle}.wc-appointments-google-identity-btn .wc-appointments-google-identity-btn__inner{display:inline-flex;align-items:center;gap:10px}.wc-appointments-google-identity-btn .wc-appointments-google-identity-btn__icon{display:inline-flex;line-height:0}.wc-appointments-google-identity-btn .wc-appointments-google-identity-btn__icon img{display:block}.wc-appointments-google-identity-btn.button:focus,.wc-appointments-google-identity-btn.button:hover{background:#f8f9fa!important;border-color:#747775!important;color:#1f1f1f!important;box-shadow:none!important}'
		);
		if ( ! wp_style_is( 'select2', 'enqueued' ) ) {
			wp_enqueue_style( 'select2' );
		}
		wp_enqueue_script( 'wp-color-picker' );
		// Force unminified writepanel.js and cache-bust by file modification time
		// so settings UI updates apply immediately without stale browser assets.
		$writepanel_js_version = (string) filemtime( WC_APPOINTMENTS_ABSPATH . 'assets/js/writepanel.js' );
		wp_register_script( 'wc_appointments_writepanel_js', WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/writepanel.js', [ 'jquery', 'jquery-ui-datepicker', 'jquery-ui-sortable', 'jquery-blockui', 'wc-enhanced-select' ], $writepanel_js_version, true );
		wp_register_script( 'wc_appointments_exporter_js', WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/appointment-export' . $suffix . '.js', [ 'jquery', 'jquery-ui-datepicker', 'wc-enhanced-select' ], WC_APPOINTMENTS_VERSION, true );

        wp_enqueue_script( 'wc_appointments_timezone_utils_js' );

        // Enqueue the admin panel on all admin pages when the panel feature is enabled.
        // This ensures the panel's click interceptors are available for the WP submenu
        // "Add New" link on any admin page, not just the calendar and list table.
        require_once __DIR__ . '/class-wc-appointments-admin-panel.php';
        if ( WC_Appointments_Admin_Panel::is_enabled() && ! wp_script_is( 'wca-admin-panel-js', 'enqueued' ) ) {
            WC_Appointments_Admin_Panel::enqueue_standalone( $suffix );
        }

        // Remove ACF plugin's timepicker scripts.
        if ( 'product' === get_post_type() ) {
            wp_deregister_script( 'acf-timepicker' );
            wp_dequeue_style( 'acf-timepicker' );
        }

        // Get default location.
        $default_location = wc_get_customer_default_location();

        // Determine site timezone string for consistent admin time display.
        $site_tz = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : get_option( 'timezone_string' );
        if ( empty( $site_tz ) ) {
            $site_tz = 'UTC';
        }

        // Get admin user's timezone (staff/admin preference or site default). Only when timezone display is enabled for admin.
        $admin_tz = $site_tz;
        if ( class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) ) {
            $admin_tz = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
        }

        $current_staff_id = 0;
		if ( ! current_user_can( 'manage_others_appointments' ) ) {
			$current_staff_id = get_current_user_id();
		}

		// Use admin/user locale in wp-admin, fallback to site locale.
		$wp_locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$wp_locale = str_replace( '_', '-', (string) $wp_locale );

        $params = [
            'nonce_delete_staff'        => wp_create_nonce( 'delete-appointable-staff' ),
            'nonce_add_product'         => wp_create_nonce( 'add-staff-product' ),
            'nonce_staff_html'          => wp_create_nonce( 'appointable-staff-html' ),
            'nonce_manual_sync'         => wp_create_nonce( 'add-manual-sync' ),
            'nonce_gcal_backup'         => wp_create_nonce( 'wc_appointments_gcal_backup' ),
            'nonce_oauth_redirect'      => wp_create_nonce( 'add-oauth-redirect' ),
			'nonce_export_appointemnts' => wp_create_nonce( 'wc-appointment-export' ),
			'nonce_appointment_order'   => wp_create_nonce( 'search-appointment-order' ),
			'nonce_indexing'            => wp_create_nonce( 'wc_appointments_admin_nonce' ),
			'nonce_get_products'        => wp_create_nonce( 'get-appointable-products' ),
			'nonce_search_products'     => wp_create_nonce( 'search-products' ),
			'nonce_get_product_details' => wp_create_nonce( 'get-product-details' ),
			'nonce_get_times'           => wp_create_nonce( 'get-available-times' ),
			'nonce_create_appointment'  => wp_create_nonce( 'create-appointment' ),
			'nonce_search_customers'    => wp_create_nonce( 'search-customers' ),
			'nonce_get_customer_details' => wp_create_nonce( 'get-customer-details' ),
			'nonce_search_orders'       => wp_create_nonce( 'search-orders' ),
			// New availability check nonce
			'nonce_check_availability'  => wp_create_nonce( 'wc_appointments_check_availability' ),
			// New pretty duration nonce
			'nonce_pretty_duration'     => wp_create_nonce( 'wc_appointments_pretty_duration' ),
			// Availability-first panel nonces
			'nonce_get_day_slots'       => wp_create_nonce( 'wc_appointments_get_day_slots' ),
			'nonce_get_month_availability' => wp_create_nonce( 'wc_appointments_get_month_availability' ),
			'current_staff_id'          => $current_staff_id,
			'staff_permissions'         => $this->get_staff_permissions_for_js(),
            'i18n_confirmation'         => esc_js( __( 'Are you sure?', 'woocommerce-appointments' ) ),
			'i18n_edit'                 => __( 'Edit', 'woocommerce-appointments' ),
			'i18n_click_to_toggle'      => __( 'Click to toggle', 'woocommerce-appointments' ),
			'i18n_location'             => __( 'Location', 'woocommerce-appointments' ),
			'i18n_locations'            => __( 'Locations', 'woocommerce-appointments' ),
			'i18n_select_location'      => __( 'Select a location', 'woocommerce-appointments' ),
			'i18n_select_locations'     => __( 'Select locations', 'woocommerce-appointments' ),
			'i18n_added'                => __( 'Added', 'woocommerce-appointments' ),
			'admin_url'                 => esc_url_raw( admin_url() ),
			'i18n_virtual_appointment_tip' => __( 'Appointments are usually not shipped. Uncheck only if you send a physical item. Video calls use an Online location, not this checkbox.', 'woocommerce-appointments' ),
            'i18n_days'                 => esc_js( __( 'days', 'woocommerce-appointments' ) ),
            'i18n_addons_required'      => esc_js( __( 'Please select required add-ons.', 'woocommerce-appointments' ) ),
            'i18n_complete_required_fields' => esc_js( __( 'Please complete required fields:', 'woocommerce-appointments' ) ),
            // Availability i18n
            'i18n_checking_availability' => esc_js( __( 'Checking availability…', 'woocommerce-appointments' ) ),
            'i18n_available'            => esc_js( __( 'Available', 'woocommerce-appointments' ) ),
            'i18n_unavailable'          => esc_js( __( 'Not available', 'woocommerce-appointments' ) ),
            'i18n_select_available_time' => esc_js( __( 'Select an available time slot below.', 'woocommerce-appointments' ) ),
            'i18n_time_unavailable_on_date' => esc_js( __( 'Your selected time is not available on this date. Please select an available time slot below.', 'woocommerce-appointments' ) ),
            'i18n_no_slots_on_date'     => esc_js( __( 'No available time slots on this date. Please select a different date.', 'woocommerce-appointments' ) ),
            'i18n_error_checking'       => esc_js( __( 'Error checking availability', 'woocommerce-appointments' ) ),
            'i18n_manual_sync_confirm_staff' => __( 'This will re-sync all events from Google Calendar. Existing synced availability rules will be replaced with fresh data. Do you want to continue?', 'woocommerce-appointments' ),
            'i18n_manual_sync_confirm_global' => __( 'This will re-sync all events from Google Calendar. Existing synced availability rules will be replaced with fresh data. Do you want to continue?', 'woocommerce-appointments' ),
            'i18n_manual_sync_syncing' => esc_js( __( 'Re-syncing from Google Calendar...', 'woocommerce-appointments' ) ),
            'i18n_manual_sync_failed' => esc_js( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) ),
			/* translators: %s: status string */
			'i18n_gcal_sync_status_format' => esc_js( __( 'Status: %s', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_status_timeout' => esc_js( __( 'Status: timeout', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_status_error' => esc_js( __( 'Status: error', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_status_starting' => esc_js( __( 'Status: starting…', 'woocommerce-appointments' ) ),
			/* translators: %s: failure reason */
			'i18n_gcal_sync_status_failed' => esc_js( __( 'Status: failed - %s', 'woocommerce-appointments' ) ),
			/* translators: %s: AJAX status text */
			'i18n_gcal_sync_status_failed_ajax' => esc_js( __( 'Status: failed - AJAX error: %s', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_phase_backup' => esc_js( __( 'Backing up current rules...', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_phase_delete' => esc_js( __( 'Removing previously synced rules...', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_phase_sync' => esc_js( __( 'Syncing events from Google Calendar...', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_phase_complete' => esc_js( __( 'Sync complete.', 'woocommerce-appointments' ) ),
			/* translators: %s: synchronization phase (backup, delete, sync, complete) */
			'i18n_gcal_sync_preparing' => esc_js( __( 'Preparing sync...', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_failed_short' => esc_js( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_stopped' => esc_js( __( 'Sync stopped by user.', 'woocommerce-appointments' ) ),
			/* translators: %d: number of synced events */
			'i18n_gcal_sync_completed_count' => esc_js( __( '%d event(s) synced.', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_unknown_error' => esc_js( __( 'Unknown error', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_no_response_data' => esc_js( __( 'No response data', 'woocommerce-appointments' ) ),
			'i18n_gcal_sync_confirm' => esc_js( __( 'This will perform a full re-sync from Google Calendar, replacing existing synced rules with fresh data. A backup will be created automatically, which you can restore later from the Backups section if needed. Do you want to continue?', 'woocommerce-appointments' ) ),
			'i18n_show_password' => esc_js( __( 'Show', 'woocommerce-appointments' ) ),
			'i18n_hide_password' => esc_js( __( 'Hide', 'woocommerce-appointments' ) ),
			'i18n_reindex_confirm' => __( "Rebuild the full availability index from scratch? This may take several minutes and slow availability checks until complete.\n\nContinue?", 'woocommerce-appointments' ),
			/* translators: %s: status string */
			'i18n_reindex_status_format' => esc_js( __( 'Status: %s', 'woocommerce-appointments' ) ),
			'i18n_reindex_status_starting' => esc_js( __( 'Status: starting…', 'woocommerce-appointments' ) ),
			'i18n_reindex_status_timeout' => esc_js( __( 'Status: timed out — re-index stopped.', 'woocommerce-appointments' ) ),
			'i18n_reindex_status_error' => esc_js( __( 'Status: error', 'woocommerce-appointments' ) ),
			/* translators: %s: failure reason */
			'i18n_reindex_status_failed' => esc_js( __( 'Status: failed — %s', 'woocommerce-appointments' ) ),
			/* translators: %s: AJAX status text */
			'i18n_reindex_status_failed_ajax' => esc_js( __( 'Status: failed — AJAX error: %s', 'woocommerce-appointments' ) ),
			'i18n_reindex_stopped' => esc_js( __( 'Re-index stopped. You can start a new re-index when ready.', 'woocommerce-appointments' ) ),
			'i18n_reindex_preparing' => esc_js( __( 'Preparing index…', 'woocommerce-appointments' ) ),
			'i18n_reindex_resume_prompt' => esc_js( __( 'A re-index was interrupted. Resume processing or stop it and start fresh.', 'woocommerce-appointments' ) ),
			'i18n_reindex_unknown_error' => esc_js( __( 'Unknown error', 'woocommerce-appointments' ) ),
			'i18n_reindex_no_response_data' => esc_js( __( 'No response data', 'woocommerce-appointments' ) ),
			// Backup & Restore i18n
			'i18n_gcal_exporting' => esc_js( __( 'Exporting rules...', 'woocommerce-appointments' ) ),
			'i18n_gcal_export_failed' => esc_js( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) ),
			'i18n_gcal_importing' => esc_js( __( 'Importing rules...', 'woocommerce-appointments' ) ),
			/* translators: %d: number of rules to import */
			'i18n_gcal_import_confirm' => esc_js( __( 'Import %d rules? This will add them to existing rules.', 'woocommerce-appointments' ) ),
			'i18n_gcal_import_success' => esc_js( __( 'Import successful.', 'woocommerce-appointments' ) ),
			'i18n_gcal_import_failed' => esc_js( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) ),
			'i18n_gcal_invalid_json' => esc_js( __( 'Invalid JSON file.', 'woocommerce-appointments' ) ),
			'i18n_gcal_no_backups' => esc_js( __( 'No backups available.', 'woocommerce-appointments' ) ),
			'i18n_gcal_restore_confirm' => esc_js( __( 'Are you sure?', 'woocommerce-appointments' ) ),
			'i18n_gcal_restore_success' => esc_js( __( 'Restore successful.', 'woocommerce-appointments' ) ),
			'i18n_gcal_restore_failed' => esc_js( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) ),
			'i18n_gcal_delete_backup_confirm' => esc_js( __( 'Are you sure?', 'woocommerce-appointments' ) ),
			'i18n_gcal_delete_backup_failed' => esc_js( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) ),
			'i18n_gcal_backup_date' => esc_js( __( 'Date', 'woocommerce-appointments' ) ),
			'i18n_gcal_backup_rules' => esc_js( __( 'Rules', 'woocommerce-appointments' ) ),
			'i18n_gcal_backup_actions' => esc_js( __( 'Actions', 'woocommerce-appointments' ) ),
			'i18n_gcal_backup_restore' => esc_js( __( 'Restore', 'woocommerce-appointments' ) ),
			'i18n_gcal_backup_download' => esc_js( __( 'Download', 'woocommerce-appointments' ) ),
			'i18n_gcal_backup_delete' => esc_js( __( 'Delete', 'woocommerce-appointments' ) ),

            'post'                      => get_the_ID(),
            'plugin_url'                => WC()->plugin_url(),
            'ajax_url'                  => admin_url( 'admin-ajax.php' ),
            'site_timezone'             => $site_tz,
            'admin_timezone'            => $admin_tz,
			'locale'                    => $wp_locale,
            'firstday'                  => absint( get_option( 'start_of_week', 1 ) ),
            'calendar_image'            => WC()->plugin_url() . '/assets/images/calendar.png',
            'appointments_list_url'    => esc_url_raw( admin_url( 'edit.php?post_type=wc_appointment' ) ),

	        'exporter'                  => [
				'string'     => esc_js( __( 'Export', 'woocommerce-appointments' ) ),
				'url'        => esc_url_raw( admin_url( 'edit.php?post_type=wc_appointment&page=appointment_exporter' ) ),
				'permission' => (bool) ( current_user_can( 'export' ) || ( class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'export_appointments' ) ) ),
			],

			'billing'                   => [
				'countries'       => wp_json_encode( array_merge( WC()->countries->get_allowed_country_states(), WC()->countries->get_shipping_country_states() ) ),
				'default_country' => $default_location['country'] ?? '',
				'default_state'   => $default_location['state'] ?? '',
			],
            'i18n' => [
				'select_product' => __( 'Select a product...', 'woocommerce-appointments' ),
				'search_products' => __( 'Search for an appointable product...', 'woocommerce-appointments' ),
				'select_time' => __( 'Select time...', 'woocommerce-appointments' ),
				'select_duration' => __( 'Select duration...', 'woocommerce-appointments' ),
				'any_staff' => __( 'Any staff member', 'woocommerce-appointments' ),
				'all_staff_assigned' => __( 'All staff assigned', 'woocommerce-appointments' ),
				'no_preference' => __( 'No preference', 'woocommerce-appointments' ),
				'creating' => __( 'Creating...', 'woocommerce-appointments' ),
				'create_appointment' => __( 'Create Appointment', 'woocommerce-appointments' ),
				'error_loading_products' => __( 'Error loading products.', 'woocommerce-appointments' ),
				'error_loading_product' => __( 'Error loading product details.', 'woocommerce-appointments' ),
				'error_creating' => __( 'Error creating appointment.', 'woocommerce-appointments' ),
				'appointment_created' => __( 'Appointment created successfully.', 'woocommerce-appointments' ),
				'edit_appointment' => __( 'Edit Appointment', 'woocommerce-appointments' ),
				'edit_order' => __( 'Edit Order', 'woocommerce-appointments' ),
				'create_another' => __( 'Add New Appointment', 'woocommerce-appointments' ),
				'close' => __( 'Close', 'woocommerce-appointments' ),
				'available_slots' => __( 'Available Slots', 'woocommerce-appointments' ),
				'no_slots' => __( 'No available slots', 'woocommerce-appointments' ),
				'loading_slots' => __( 'Loading slots…', 'woocommerce-appointments' ),
				'slots_available' => __( 'available', 'woocommerce-appointments' ),
				'select_date_for_slots' => __( 'Select a date to see available slots', 'woocommerce-appointments' ),
				'staff_count' => __( 'staff', 'woocommerce-appointments' ),
            ],
		];

		wp_localize_script( 'wc_appointments_writepanel_js', 'wc_appointments_writepanel_js_params', $params );
		wp_localize_script( 'wc_appointments_exporter_js', 'wc_appointments_exporter_js_params', $params );
	}

	/**
     * Reset the ics exporter timezone string cache.
     */
    public function reset_ics_exporter_timezone_cache(): void {
		$settings_updated = filter_input( INPUT_GET, 'settings-updated' );
		if ( 'true' === $settings_updated ) {
			wp_cache_delete( 'wc_appointments_timezone_string' );
		}
	}

	/**
	 * Add memberships settings page
	 *
	 * @since 1.0
	 * @param array<string, mixed> $settings
	 * @return array<string, mixed>
	 */
	public function add_settings_page( $settings ): array {
		// One instance per request. Bare include() redeclares the class if tests loaded it early;
		// constructing again would double-register admin field actions.
		static $page = null;
		if ( null === $page ) {
			if ( ! class_exists( 'WC_Appointments_Admin_Settings', false ) ) {
				$page = include __DIR__ . '/class-wc-appointments-admin-settings.php';
			} else {
				$page = new WC_Appointments_Admin_Settings();
			}
		}
		$settings[] = $page;

		return $settings;
	}

	/**
	 * Support scanning for template overrides in extension.
	 *
	 * @param array<string, string> $paths
	 * @return array<string, string>
	 */
	public function template_scan_path( array $paths ): array {
		$paths['WooCommerce Appointments'] = WC_APPOINTMENTS_TEMPLATE_PATH;

		return $paths;
	}

	/**
	 * Show a notice highlighting bad template files.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function template_file_check_notice(): void {
		$core_templates = WC_Admin_Status::scan_template_files( WC_APPOINTMENTS_TEMPLATE_PATH );
		$outdated       = false;

		foreach ( $core_templates as $file ) {

			$theme_file = false;
			$bases      = [
				get_stylesheet_directory() . '/woocommerce-appointments/',
				get_stylesheet_directory() . '/woocommerce/',
				get_template_directory() . '/woocommerce-appointments/',
				get_template_directory() . '/woocommerce/',
			];
			foreach ( $bases as $base ) {
				if ( file_exists( $base . $file ) ) {
					$theme_file = $base . $file;
					break;
				}
			}

			if ( false !== $theme_file ) {
				$core_version  = WC_Admin_Status::get_file_version( WC_APPOINTMENTS_TEMPLATE_PATH . $file );
				$theme_version = WC_Admin_Status::get_file_version( $theme_file );

				if ( $core_version && $theme_version && version_compare( $theme_version, $core_version, '<' ) ) {
					$outdated = true;
					break;
				}
			}
		}

		if ( $outdated ) {
			$theme = wp_get_theme();

			WC_Admin_Notices::add_custom_notice(
			    'wc_appointments_template_files',
			    sprintf(
					/* translators: %1$s: Theme name, %2$d: Admin URL, %3$s: Link to template strucure docs */
					__( '<p><strong>Your theme (%1$s) contains outdated copies of some WooCommerce Appointments template files.</strong> These files may need updating to ensure they are compatible with the current version of WooCommerce Appointments. You can see which files are affected from the <a href="%2$s">system status page</a>. If in doubt, check with the author of the theme.<p><p class="submit"><a class="button-primary" href="%3$s" target="_blank">Learn More About Templates</a></p>', 'woocommerce-appointments' ),
			        esc_html( $theme['Name'] ),
			        esc_url( admin_url( 'admin.php?page=wc-status' ) ),
			        esc_url( 'https://docs.woocommerce.com/document/template-structure/' ),
			    ),
			);
		} else {
			WC_Admin_Notices::remove_notice( 'wc_appointments_template_files' );
		}
	}

	/**
	 * Get staff permissions for JavaScript.
	 * Returns permission flags that the calendar UI can use to show/hide features.
	 *
	 * @return array<string, mixed>
	 */
	private function get_staff_permissions_for_js(): array {
		$user_id = get_current_user_id();

		// Admins have all permissions.
		if ( ! class_exists( 'WC_Appointments_Staff_Permissions' ) || ! WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
			return [
				'is_staff'                  => false,
				'can_create_appointments'   => true,
				'can_cancel_appointments'   => true,
				'can_manage_status'         => true,
				'can_manage_availability'   => true,
				'can_view_products'         => true,
				'can_export'                => true,
			];
		}

		// Staff user - check specific permissions.
		return [
			'is_staff'                  => true,
			'can_create_appointments'   => WC_Appointments_Staff_Permissions::can( $user_id, 'create_appointments' ),
			'can_cancel_appointments'   => WC_Appointments_Staff_Permissions::can( $user_id, 'cancel_appointments' ),
			'can_manage_status'         => WC_Appointments_Staff_Permissions::can( $user_id, 'manage_appointment_status' ),
			'can_manage_availability'   => WC_Appointments_Staff_Permissions::can( $user_id, 'manage_own_availability' ),
			'can_view_products'         => WC_Appointments_Staff_Permissions::can( $user_id, 'view_assigned_products' ),
			'can_export'                => WC_Appointments_Staff_Permissions::can( $user_id, 'export_appointments' ),
		];
	}

	/**
	 * Override product type for New Product screen, if a request parameter is set.
	 *
	 * @since 1.0.0
	 *
	 * @param string $override Product Type
	 * @param int    $product_id
	 *
	 * @return string
	 */
	public function maybe_override_product_type( $override, $product_id ): string {
		$appointable_product = filter_input( INPUT_GET, 'appointable_product' );
		if ( null === $appointable_product || false === $appointable_product ) {
			$appointable_product = filter_input( INPUT_POST, 'appointable_product' );
		}
		if ( ! empty( $appointable_product ) ) {
			return 'appointment';
		}

		return $override;
	}
	/**
	 * Intercept and suppress specific PHP 8.1+ deprecation warnings in WooCommerce core.
	 *
	 * Targeted at html-order-items.php where null is used as an array offset.
	 * Register this before the problematic code starts.
	 *
	 * @since 5.3.0
	 */
	public function intercept_order_item_deprecations(): void {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_set_error_handler -- Scoped PHP 8.1 deprecation suppression for WooCommerce html-order-items.php until core is fixed.
		set_error_handler(
			function ( $errno, $errstr, $errfile, $errline ) {
				// Only intercept E_DEPRECATED
				if ( E_DEPRECATED !== $errno ) {
					return false;
				}

				// Only intercept the specific "null as array offset" warning from html-order-items.php
				if ( false !== strpos( $errstr, 'null as an array offset' ) && false !== strpos( $errfile, 'html-order-items.php' ) ) {
					return true; // Suppress it.
				}

				return false; // Pass through everything else.
			},
			E_DEPRECATED
		);
	}

	/**
	 * Restore the original error handler after the problematic code has finished.
	 *
	 * @since 5.3.0
	 */
	public function restore_order_item_deprecations(): void {
		restore_error_handler();
	}

	/**
	 * Show configuration notices on product edit and Availability hub product deep links.
	 */
	public function product_config_notices(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen ) {
			return;
		}

		$on_hub  = false;
		$post_id = 0;

		if ( 'product' === $screen->id ) {
			$post_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		} elseif ( class_exists( 'WC_Appointments_Admin_Availability_Hub' ) && WC_Appointments_Admin_Availability_Hub::is_hub_screen() ) {
			$layer = isset( $_GET['layer'] ) ? sanitize_key( wp_unslash( (string) $_GET['layer'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( 'product' !== $layer ) {
				return;
			}
			$post_id = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$on_hub  = true;
		} else {
			return;
		}

		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$product = wc_get_product( $post_id );
		if ( ! is_wc_appointment_product( $product ) ) {
			return;
		}

		if ( ! $on_hub ) {
			wp_enqueue_script( 'wc_appointments_writepanel_js' );
		}

		foreach ( self::get_product_config_notices( $product, $on_hub ) as $notice ) {
			printf(
				'<div class="notice notice-%1$s wca-product-config-notice%3$s" data-product-id="%4$d"><p>%2$s</p></div>',
				esc_attr( $notice['level'] ),
				wp_kses(
					$notice['message'],
					[
						'strong' => [],
						'a'      => [
							'href'  => true,
							'class' => true,
						],
					]
				),
				'info' === $notice['level'] ? ' is-dismissible' : '',
				(int) $product->get_id()
			);
		}
	}

	/**
	 * Saved-settings smoke check through the product booking horizon. Not live AJAX.
	 *
	 * @param bool $on_hub Omit hub self-links when already on that product in the hub.
	 * @return array<int, array{level: string, message: string}>
	 */
	public static function get_product_config_notices( WC_Product_Appointment $product, bool $on_hub = false ): array {
		if ( ! $product->get_id() ) {
			return [];
		}

		$notices  = [];
		$edit_url = (string) get_edit_post_link( $product->get_id(), 'raw' );

		if ( $product->get_qty() > 1 ) {
			$rules = WC_Data_Store::load( 'appointments-availability' )->get_all(
				[
					[
						'key' => 'kind',
						'compare' => '=',
						'value' => 'availability#product',
					],
					[
						'key' => 'kind_id',
						'compare' => '=',
						'value' => $product->get_id(),
					],
				]
			);
			foreach ( $rules as $rule ) {
				$rule_qty = (int) $rule->get_qty();
				if ( 'yes' !== $rule->get_appointable() || $rule_qty < 1 || $rule_qty >= $product->get_qty() ) {
					continue;
				}
				$capacity_limit = sprintf(
					/* translators: %d: Capacity set on the open-hours rule */
					__( 'limited to a capacity of %d', 'woocommerce-appointments' ),
					$rule_qty
				);
				$notices[] = self::config_notice(
					'info',
					sprintf(
						/* translators: 1: open-hours rule title or time range, 2: "limited to a capacity of N", 3: product capacity */
						__( 'Rule "%1$s" is %2$s; this product has %3$d available. OK if intentional.', 'woocommerce-appointments' ),
						self::format_availability_rule_label( $rule ),
						$capacity_limit,
						$product->get_qty()
					),
					$on_hub ? '' : WC_Appointments_Admin_Availability_Hub::url( 'product', $product->get_id(), $rule->get_id() ),
					'',
					$on_hub ? '' : __( 'Edit', 'woocommerce-appointments' )
				);
				break;
			}
		}

		list( $min_bound, $max_bound ) = WC_Appointment_Slots_Provider::resolve_schedule_bounds( $product, 0, 0 );
		$tomorrow = strtotime( 'tomorrow', current_time( 'timestamp' ) );
		$start    = max( $tomorrow, $min_bound );
		$probe    = WC_Appointment_Slots_Provider::probe_for_config_check( $product, $start, $max_bound, true, true );
		$slots  = $probe['slots'];
		$reason = (string) ( is_array( $probe['diagnostics'] ?? null ) ? ( $probe['diagnostics']['primary_reason'] ?? 'unknown' ) : 'unknown' );

		$unfiltered_bookable = $raw = $bookable = 0;
		$unit                = $product->has_time() ? $product->get_duration_unit() : '';
		$duration            = $product->has_time() ? $product->get_duration_in_minutes() : 0;
		foreach ( $slots as $slot ) {
			$has_capacity = $slot->available && $slot->capacity_available > 0;
			if ( $has_capacity ) {
				$unfiltered_bookable++;
			}
			if ( $product->has_time()
				&& ! WC_Appointment_Slots_Display_Rules::is_bookable_start_for_time_product( $unit, $duration, $slot ) ) {
				continue;
			}
			$raw++;
			if ( $has_capacity ) {
				$bookable++;
			}
		}

		$fully_booked = __( 'Probe window is fully booked (saved settings).', 'woocommerce-appointments' );

		if ( $raw > 0 && 0 === $bookable ) {
			$notices[] = self::config_notice( 'info', $fully_booked );
		} elseif ( 0 === $raw ) {
			if ( $product->has_time() && $unfiltered_bookable > 0 ) {
				$fix = self::no_slots_notice( 'skip_span_guard' );
			} elseif ( ! empty( $slots ) && 0 === $unfiltered_bookable ) {
				$notices[] = self::config_notice( 'info', $fully_booked );
				$fix       = null;
			} else {
				$fix = self::no_slots_notice( $reason, $product->get_name() );
			}
			if ( ! empty( $fix ) ) {
				$hub = ( 'hub' === $fix['anchor'] );
				$notices[] = self::config_notice(
					'error',
					$fix['message'],
					$hub ? ( $on_hub ? '' : WC_Appointments_Admin_Availability_Hub::url( 'product', $product->get_id() ) ) : $edit_url,
					$hub ? '' : $fix['anchor'],
					( $hub && $on_hub ) ? '' : $fix['label']
				);
			}
		}

		return $notices;
	}

	/**
	 * @return array{level: string, message: string}
	 */
	private static function config_notice( string $level, string $text, string $edit_url = '', string $anchor = '', string $link_text = '' ): array {
		$message = esc_html( $text );
		if ( $edit_url && $link_text ) {
			$message .= sprintf(
				' <a href="%s" class="wca-product-config-tab-link">%s</a>',
				esc_url( $anchor ? $edit_url . $anchor : $edit_url ),
				esc_html( $link_text )
			);
		}

		return [
			'level'   => $level,
			'message' => $message,
		];
	}

	private static function format_availability_rule_label( WC_Appointments_Availability $rule ): string {
		$title = trim( $rule->get_title() );
		if ( '' !== $title ) {
			return $title;
		}

		$from = $rule->get_from_range();
		$to   = $rule->get_to_range();
		$type = $rule->get_range_type();
		$days = [
			'1' => __( 'Monday', 'woocommerce-appointments' ),
			'2' => __( 'Tuesday', 'woocommerce-appointments' ),
			'3' => __( 'Wednesday', 'woocommerce-appointments' ),
			'4' => __( 'Thursday', 'woocommerce-appointments' ),
			'5' => __( 'Friday', 'woocommerce-appointments' ),
			'6' => __( 'Saturday', 'woocommerce-appointments' ),
			'7' => __( 'Sunday', 'woocommerce-appointments' ),
		];

		if ( preg_match( '/^time:(\d)$/', $type, $matches ) ) {
			return trim( ( $days[ $matches[1] ] ?? '' ) . " {$from}-{$to}" );
		}
		if ( false !== strpos( $from, ':' ) ) {
			return "{$from}-{$to}";
		}
		if ( 'days' === $type ) {
			$from_day = $days[ $from ] ?? $from;
			$to_day   = $days[ $to ] ?? $to;
			return $from === $to ? $from_day : "{$from_day}-{$to_day}";
		}

		$from_date = $rule->get_from_date();
		$to_date   = $rule->get_to_date();

		return ( $from_date || $to_date ) ? trim( "{$from_date}-{$to_date}", '-' ) : $type;
	}

	/**
	 * @return array{message: string, anchor: string, label: string}
	 */
	private static function no_slots_notice( string $reason, string $product_name = '' ): array {
		$scope              = __( ' (saved settings)', 'woocommerce-appointments' );
		$duration_fix       = [
			'message' => __( 'Duration or interval does not fit appointable windows', 'woocommerce-appointments' ) . $scope . '.',
			'anchor'  => '#appointments_general',
			'label'   => __( 'Review duration and interval', 'woocommerce-appointments' ),
		];
		$availability_check = [
			'message' => __( 'Duration does not fit with Availability check', 'woocommerce-appointments' ) . $scope . '.',
			'anchor'  => '#appointments_availability',
			'label'   => __( 'Review Availability check', 'woocommerce-appointments' ),
		];
		$map                = [
			'no_appointable_minutes' => [
				/* translators: %s: product name */
				'message' => sprintf( __( 'No appointable times for "%s" (saved settings).', 'woocommerce-appointments' ), $product_name ),
				'anchor'  => 'hub',
				'label'   => __( 'Review availability rules', 'woocommerce-appointments' ),
			],
			'slot_count_zero'        => $duration_fix,
			'span_duration_mismatch' => $duration_fix,
			'skip_min_max_date'      => [
				'message' => __( 'Booking limits exclude the probe window', 'woocommerce-appointments' ) . $scope . '.',
				'anchor'  => '#appointments_general',
				'label'   => __( 'Review booking limits', 'woocommerce-appointments' ),
			],
			'skip_span_guard'        => $availability_check,
		];

		if ( isset( $map[ $reason ] ) ) {
			return $map[ $reason ];
		}

		return [
			/* translators: %s: product name */
			'message' => sprintf( __( 'No bookable times for "%s" (saved settings).', 'woocommerce-appointments' ), $product_name ),
			'anchor'  => 'hub',
			'label'   => __( 'Review appointment settings', 'woocommerce-appointments' ),
		];
	}

}

$GLOBALS['wc_appointments_admin'] = new WC_Appointments_Admin();
