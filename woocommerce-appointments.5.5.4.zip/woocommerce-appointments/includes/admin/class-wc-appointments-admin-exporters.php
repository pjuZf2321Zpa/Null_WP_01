<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Exporters Class.
 */
class WC_Appointments_Admin_Exporters {

	/**
	 * Array of exporter IDs.
	 *
	 * @var string[]
	 */
	protected array $exporters = [];

	/**
	 * Export manager instance.
	 *
	 * @var WC_Appointments_Export_Manager
	 */
	protected WC_Appointments_Export_Manager $export_manager;

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Initialize export manager.
		$this->export_manager = new WC_Appointments_Export_Manager();

		// Register default exporters.
		$this->register_default_exporters();

		// Register download handler very early to prevent page load (fallback).
		add_action( 'admin_init', [ $this, 'download_export_file' ], 1 );
		// Also hook into load-{page} to catch it even earlier.
		add_action( 'load-wc_appointment_page_appointment_exporter', [ $this, 'download_export_file' ], 1 );

		// Check for download request in admin_menu before page structure loads.
		add_action( 'admin_menu', [ $this, 'maybe_handle_download' ], 5 );

		// Register admin menu.
		add_action( 'admin_menu', [ $this, 'add_to_menus' ], 20 );
		// Hide menu item from main menu (page still accessible via direct URL).
		add_action( 'admin_menu', [ $this, 'hide_from_menus' ], 99 );

		// Ensure page title is set to prevent null values in admin-header.php.
		add_filter( 'admin_title', [ $this, 'set_admin_page_title' ], 10, 2 );

		// Register AJAX handler for export.
		add_action( 'wp_ajax_woocommerce_do_ajax_appointment_export', [ $this, 'do_ajax_appointment_export' ] );
	}

	/**
	 * Register default exporters with the export manager.
	 *
	 * @return void
	 */
	protected function register_default_exporters(): void {
		include_once WC_APPOINTMENTS_ABSPATH . 'includes/admin/export/class-wc-appointments-csv-exporter.php';
		include_once WC_APPOINTMENTS_ABSPATH . 'includes/admin/export/class-wc-appointments-ics-exporter.php';

		// Register CSV exporter.
		$this->export_manager->register_exporter( new WC_Appointments_CSV_Exporter() );

		// Register ICS exporter.
		$this->export_manager->register_exporter( new WC_Appointments_ICS_Exporter() );
	}

	/**
	 * Get the export manager instance.
	 *
	 * @return WC_Appointments_Export_Manager Export manager instance.
	 */
	public function get_export_manager(): WC_Appointments_Export_Manager {
		return $this->export_manager;
	}

	/**
	 * Return true if WooCommerce export is allowed for current user, false otherwise.
	 *
	 * @return bool Whether current user can perform export.
	 */
	protected function export_allowed(): bool {
		if ( current_user_can( 'edit_appointments' ) && current_user_can( 'export' ) ) {
			return true;
		}

		// Allow staff with export_appointments permission.
		if ( current_user_can( 'edit_appointments' ) && class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'export_appointments' ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Sanitized GET string for export download requests.
	 *
	 * @param string $key GET parameter name.
	 * @return string
	 */
	private function export_get_text( string $key ): string {
		$value = filter_input( INPUT_GET, $key );
		if ( null === $value || false === $value ) {
			return '';
		}

		return sanitize_text_field( wp_unslash( $value ) );
	}

	/**
	 * Resolve a candidate export path and ensure it stays under uploads.
	 *
	 * @param string $file_path Candidate absolute path.
	 * @return string Real path under uploads, or empty string if unsafe/missing.
	 */
	private function export_resolve_safe_path( string $file_path ): string {
		if ( '' === $file_path ) {
			return '';
		}

		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['error'] ) || empty( $upload_dir['basedir'] ) ) {
			return '';
		}

		$uploads_real = realpath( $upload_dir['basedir'] );
		if ( false === $uploads_real ) {
			return '';
		}

		$resolved = realpath( $file_path );
		if ( false === $resolved || ! is_file( $resolved ) ) {
			return '';
		}

		$uploads_prefix = $uploads_real . DIRECTORY_SEPARATOR;
		if ( 0 !== strpos( $resolved, $uploads_prefix ) && $resolved !== $uploads_real ) {
			return '';
		}

		return $resolved;
	}

	/**
	 * Unslashed POST payload (call only after check_ajax_referer).
	 *
	 * @return array<string, mixed>
	 */
	private function export_post_unslashed(): array {
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field; check_ajax_referer verified.
	}

	/**
	 * Check for download request early in admin_menu hook.
	 */
	public function maybe_handle_download(): void {
		$action = $this->export_get_text( 'action' );
		$nonce  = $this->export_get_text( 'nonce' );

		if ( '' !== $action && '' !== $nonce
			&& in_array( $action, [ 'download_appointment_csv', 'download_appointment_export' ], true )
			&& wp_verify_nonce( $nonce, 'appointment-export' )
		) {
			$this->download_export_file();
			// Should never reach here, but exit just in case.
			exit;
		}
	}

	/**
	 * Set admin page title to prevent null values.
	 *
	 * @param string $admin_title The page title.
	 * @param string $title The original title.
	 * @return string
	 */
	public function set_admin_page_title( $admin_title, $title ): string {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		
		if ( $screen && 'wc_appointment_page_appointment_exporter' === $screen->id ) {
			// Ensure we have a valid title - never return null or empty.
			$page_title = __( 'Appointment Export', 'woocommerce-appointments' );
			
			// Handle null or empty title parameter.
			if ( empty( $title ) ) {
				return $page_title;
			}

			// Ensure the admin_title itself is not empty.
			if ( '' === $admin_title ) {
				return $page_title;
			}
			
			// Ensure title is a string, not null.
			$title = (string) $title;
		}
		
		// Ensure we never return null - convert to string if needed.
		if ( '' === $admin_title ) {
			return __( 'Appointment Export', 'woocommerce-appointments' );
		}
		
		return (string) $admin_title;
	}

	/**
	 * Add menu items for our custom exporters.
	 */
	public function add_to_menus(): void {
		add_submenu_page(
		    'edit.php?post_type=wc_appointment',
		    __( 'Appointment Export', 'woocommerce-appointments' ),
		    __( 'Appointment Export', 'woocommerce-appointments' ),
		    'edit_appointments',
		    'appointment_exporter',
		    [ $this, 'appointment_exporter' ],
		);
	}

	/**
	 * Hide menu items from view so the pages exist, but the menu items do not.
	 *
	 * For staff users with export permission, the submenu entry must remain
	 * in $submenu so WordPress's user_can_access_admin_page() allows access.
	 * Admins (with WP 'export' cap) can access the page regardless.
	 */
	public function hide_from_menus(): void {
		// Staff with export permission need the submenu entry to remain
		// so WordPress allows them to access the page.
		if ( class_exists( 'WC_Appointments_Staff_Permissions' )
			&& WC_Appointments_Staff_Permissions::is_staff_user()
			&& WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'export_appointments' )
		) {
			return;
		}

		global $submenu;

		$menu_to_unset = 'edit.php?post_type=wc_appointment';

		if ( isset( $submenu[ $menu_to_unset ] ) ) {
			foreach ( $submenu[ $menu_to_unset ] as $key => $menu ) {
				if ( 'appointment_exporter' === $menu[2] ) {
					unset( $submenu[ $menu_to_unset ][ $key ] );
				}
			}
		}
	}

	/**
	 * Export page UI.
	 */
	public function appointment_exporter(): void {
		// If this is a download request, the download handler should have already processed it.
		// This should not be reached, but just in case, exit early.
		$action = $this->export_get_text( 'action' );
		if ( in_array( $action, [ 'download_appointment_csv', 'download_appointment_export' ], true ) ) {
			return;
		}

		// Check permissions before displaying the page.
		if ( ! $this->export_allowed() ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'woocommerce-appointments' ) );
		}

		include_once WC_APPOINTMENTS_ABSPATH . 'includes/admin/export/class-wc-appointments-csv-exporter.php';
		include_once __DIR__ . '/views/html-appointment-export.php';
	}

	/**
	 * Serve the generated file.
	 */
	public function download_export_file(): void {
		// Check if this is a download request.
		$action = $this->export_get_text( 'action' );
		$nonce  = $this->export_get_text( 'nonce' );

		if ( ! is_admin()
		    || '' === $action
		    || '' === $nonce
			|| ! in_array( $action, [ 'download_appointment_csv', 'download_appointment_export' ], true )
		) {
			return;
		}

		// Verify nonce (support both old and new nonce names for backward compatibility).
		$nonce_action = ( 'download_appointment_csv' === $action ) ? 'appointment-csv' : 'appointment-export';
		if ( ! wp_verify_nonce( $nonce, $nonce_action ) ) {
			wp_die( esc_html__( 'Security check failed.', 'woocommerce-appointments' ) );
		}

		// Check permissions before serving the file.
		if ( ! $this->export_allowed() ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to download this file.', 'woocommerce-appointments' ) );
		}

		// Prevent any output or page rendering.
		// Clear all output buffers.
		while ( ob_get_level() ) {
			ob_end_clean();
		}

		// Prevent any output before we send the file.
		if ( ob_get_level() ) {
			ob_end_clean();
		}

		// Get format and filename from the request.
		$format   = $this->export_get_text( 'format' );
		if ( '' === $format ) {
			$format = 'csv';
		}
		// Basename + sanitize_file_name: never honor ../ or absolute paths from the client.
		$filename = sanitize_file_name( basename( $this->export_get_text( 'filename' ) ) );
		if ( '' === $filename ) {
			$filename = 'export.' . $format;
		}

		// The file should already be generated by the AJAX handler.
		// Find it in the uploads directory.
		$upload_dir = wp_upload_dir();
		$file_path  = trailingslashit( $upload_dir['path'] ) . $filename;

		// If not found in path, try basedir.
		if ( ! file_exists( $file_path ) ) {
			$file_path = trailingslashit( $upload_dir['basedir'] ) . $filename;
		}

		// If still not found, try to get it from the exporter's expected location.
		if ( ! file_exists( $file_path ) ) {
			$exporter = $this->export_manager->get_exporter( $format );
			if ( $exporter ) {
				// For CSV exporter.
				if ( 'csv' === $format && method_exists( $exporter, 'set_filename' ) && method_exists( $exporter, 'get_export_file_path' ) ) {
					$exporter->set_filename( $filename );
					$file_path = $exporter->get_export_file_path();
				}
				// For ICS exporter, files are created with full path, so check uploads directory more thoroughly.
				elseif ( 'ics' === $format ) {
					// ICS files are stored in uploads directory with sanitized filename.
					$sanitized_filename = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) ) . '.ics';
					$file_path          = trailingslashit( $upload_dir['path'] ) . $sanitized_filename;
					if ( ! file_exists( $file_path ) ) {
						$file_path = trailingslashit( $upload_dir['basedir'] ) . $sanitized_filename;
					}
				}
			}
		}

		// Only serve files that resolve under uploads (blocks path traversal / symlink escape).
		$file_path = $this->export_resolve_safe_path( is_string( $file_path ) ? $file_path : '' );
		if ( '' === $file_path ) {
			wp_die( esc_html__( 'Export file could not be found.', 'woocommerce-appointments' ) );
		}

		if ( file_exists( $file_path ) ) {
			// CSV batch exporter writes column headers to a sidecar (WC core pattern).
			$headers_path = $file_path . '.headers';
			$csv_prefix   = '';
			if ( 'csv' === $format ) {
				if ( file_exists( $headers_path ) ) {
					// Sidecar already includes UTF-8 BOM + header row.
					$csv_prefix = (string) file_get_contents( $headers_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				} else {
					$csv_prefix = "\xEF\xBB\xBF";
				}
			}

			// Determine content type based on format.
			$content_type = 'csv' === $format ? 'text/csv; charset=utf-8' : 'text/calendar; charset=utf-8';
			$content_len  = strlen( $csv_prefix ) + (int) filesize( $file_path );

			// Set headers for file download.
			nocache_headers();
			header( 'Content-Type: ' . $content_type );
			header( 'Content-Disposition: attachment; filename=' . sanitize_file_name( basename( $file_path ) ) );
			header( 'Pragma: no-cache' );
			header( 'Expires: 0' );
			header( 'Content-Length: ' . $content_len );

			// Output CSV column headers (with BOM) then row data.
			if ( '' !== $csv_prefix ) {
				echo $csv_prefix; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			// Output the file.
			if ( false !== ( $handle = fopen( $file_path, 'r' ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fopen
				while ( ! feof( $handle ) ) {
					echo fread( $handle, 8192 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_system_read_fread
				}
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fclose
			}

			// Clean up temporary files.
			@unlink( $file_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
			if ( file_exists( $headers_path ) ) {
				@unlink( $headers_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
			}
		} else {
			wp_die( esc_html__( 'Export file could not be generated.', 'woocommerce-appointments' ) );
		}

		exit; // Prevent further execution after file download.
	}

	/**
	 * AJAX callback for doing the actual export.
	 */
	public function do_ajax_appointment_export(): void {
		check_ajax_referer( 'wc-appointment-export', 'security' );

		if ( ! $this->export_allowed() ) {
			wp_send_json_error(
			    [
					'message' => __( 'Insufficient privileges to export appointments.', 'woocommerce-appointments' ),
				],
			);
		}

		$posted = $this->export_post_unslashed();

		// Get format from POST data, default to CSV for backward compatibility.
		$format = sanitize_text_field( $posted['format'] ?? 'csv' );

		// ICS needs the full list up front; CSV loads its own rows in the exporter.
		$appointments = [];
		if ( 'ics' === $format ) {
			$appointments = $this->get_appointments_for_export( $posted );
		}

		// For ICS format, export directly (no batch processing needed).
		if ( 'ics' === $format ) {
			$filename = sanitize_file_name( $posted['filename'] ?? '' );
			if ( empty( $filename ) ) {
				$filename = 'appointments-' . gmdate( 'Ymd-His', current_time( 'timestamp' ) );
			}

			// Remove .ics extension if present (exporter will add it).
			$filename = preg_replace( '/\.ics$/i', '', $filename );
			// Remove any "-ics" suffix.
			$filename = preg_replace( '/-ics$/i', '', $filename );

			// Check if add-ons should be exported.
			$export_addons = ! empty( $posted['export_addon'] );

			$file_path = $this->export_manager->export_appointments(
				'ics',
				$appointments,
				[
					'filename'     => $filename,
					'export_addons' => $export_addons,
				]
			);

			if ( $file_path ) {
				$query_args = apply_filters(
					'woocommerce_export_get_ajax_query_args',
					[
						'nonce'    => wp_create_nonce( 'appointment-export' ),
						'action'   => 'download_appointment_export',
						'format'   => 'ics',
						'filename' => basename( $file_path ),
					],
				);

				wp_send_json_success(
					[
						'step'       => 'done',
						'percentage' => 100,
						'url'        => add_query_arg( $query_args, admin_url( 'edit.php?post_type=wc_appointment&page=appointment_exporter' ) ),
					],
				);
			} else {
				wp_send_json_error(
					[
						'message' => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
					],
				);
			}
		}

		// CSV format (batch processing).
		include_once WC_APPOINTMENTS_ABSPATH . 'includes/admin/export/class-wc-appointments-csv-exporter.php';

		$step     = isset( $posted['step'] ) ? absint( $posted['step'] ) : 1;
		$exporter = new WC_Appointments_CSV_Exporter();

		if ( ! empty( $posted['columns'] ) ) {
			$exporter->set_column_names( $posted['columns'] );
		}

		if ( ! empty( $posted['selected_columns'] ) ) {
			$exporter->set_columns_to_export( $posted['selected_columns'] );
		}

		if ( ! empty( $posted['export_start'] ) ) {
			$exporter->set_start_date_to_export( sanitize_text_field( $posted['export_start'] ) );
		}

		if ( ! empty( $posted['export_end'] ) ) {
			$exporter->set_end_date_to_export( sanitize_text_field( $posted['export_end'] ) );
		}

		if ( ! empty( $posted['export_product'] ) && is_array( $posted['export_product'] ) ) {
			$exporter->set_appointment_product_to_export( array_values( $posted['export_product'] ) );
		}

		if ( ! empty( $posted['export_staff'] ) && is_array( $posted['export_staff'] ) ) {
			$exporter->set_appointment_staff_to_export( array_values( $posted['export_staff'] ) );
		}

		// Force staff filter for staff users to only export their own appointments.
		$current_user_id = get_current_user_id();
		if ( class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $current_user_id ) ) {
			$exporter->set_appointment_staff_to_export( [ $current_user_id ] );
		}

		if ( ! empty( $posted['export_addon'] ) ) {
			$exporter->enable_addon_export( true );
		}

		if ( ! empty( $posted['filename'] ) ) {
			$exporter->set_filename( sanitize_file_name( $posted['filename'] ) );
		}

		$exporter->set_page( $step );
		$exporter->generate_file();

		$query_args = apply_filters(
		    'woocommerce_export_get_ajax_query_args',
		    [
				'nonce'    => wp_create_nonce( 'appointment-export' ),
				'action'   => 'download_appointment_export',
				'format'   => 'csv',
				'filename' => $exporter->get_filename(),
			],
		);

		if ( 100 === $exporter->get_percent_complete() ) {
			wp_send_json_success(
			    [
					'step'       => 'done',
					'percentage' => 100,
					'url'        => add_query_arg( $query_args, admin_url( 'edit.php?post_type=wc_appointment&page=appointment_exporter' ) ),
				],
			);
		} else {
			wp_send_json_success(
			    [
					'step'       => ++$step,
					'percentage' => $exporter->get_percent_complete(),
					'columns'    => $exporter->get_column_names(),
				],
			);
		}
	}

	/**
	 * Get appointments for export based on POST filters.
	 *
	 * @param array<string, mixed> $posted Unslashed POST payload (nonce verified by caller).
	 * @return list<WC_Appointment> Array of WC_Appointment objects.
	 */
	protected function get_appointments_for_export( array $posted = [] ): array {
		$args = [
			'start'    => '',
			'end'      => '',
			'product'  => [],
			'staff'    => [],
			'status'   => array_unique( array_merge( get_wc_appointment_statuses( 'all' ), get_wc_appointment_statuses( 'user' ), get_wc_appointment_statuses( 'cancel' ) ) ),
			'limit'    => -1,
			'order_by' => 'date_created',
			'order'    => 'DESC',
			'return'   => 'objects',
		];

		if ( ! empty( $posted['export_start'] ) ) {
			$args['start'] = strtotime( urldecode( sanitize_text_field( $posted['export_start'] ) ) );
		}

		if ( ! empty( $posted['export_end'] ) ) {
			$args['end'] = strtotime( urldecode( sanitize_text_field( $posted['export_end'] ) ) );
		}

		if ( ! empty( $posted['export_product'] ) && is_array( $posted['export_product'] ) ) {
			$args['product'] = array_map( 'intval', array_values( $posted['export_product'] ) );
		}

		if ( ! empty( $posted['export_staff'] ) && is_array( $posted['export_staff'] ) ) {
			$args['staff'] = array_map( 'intval', array_values( $posted['export_staff'] ) );
		}

		// Force staff filter for staff users to only export their own appointments.
		$current_user_id = get_current_user_id();
		if ( class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $current_user_id ) ) {
			$args['staff'] = [ $current_user_id ];
		}

		// Allow 3rd parties to process the arguments.
		$args = apply_filters( 'woocommerce_appointment_export_data_args', $args, $this );

		$appointments = WC_Appointment_Data_Store::get_appointments_in_date_range(
			$args['start'],
			$args['end'],
			$args['product'],
			$args['staff'],
			false,
			$args,
		);

		return is_array( $appointments ) ? $appointments : [];
	}
}

new WC_Appointments_Admin_Exporters();
