<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

class WC_Appointment_Meta_Box_Data {
	use WC_Appointments_Meta_Box_Trait;

	/**
     * Are meta boxes saved?
     */
    private static bool $saved_meta_box = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id         = 'woocommerce-appointment-data';
		$this->title      = __( 'Appointment Details', 'woocommerce-appointments' );
		$this->context    = 'normal';
		$this->priority   = 'high';
		$this->post_types = [ 'wc_appointment' ];

		add_action( 'save_post', [ $this, 'meta_box_save' ], 10, 2 );
	}

	/**
	 * Check data and output warnings.
	 * @param WC_Appointment $appointment
	 * @param WC_Product $product
	 */
	private function sanity_check_notices( $appointment, $product ): void {
		if ( $appointment->get_start() && $appointment->get_start() > strtotime( '+ 2 year', current_time( 'timestamp' ) ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_attr__( 'This appointment is scheduled over 2 years into the future. Please ensure this is correct.', 'woocommerce-appointments' ) . '</p></div>';
		}

		if ( $product && is_callable( [ $product, 'get_max_date_a' ] ) ) {
			$max      = $product->get_max_date_a();
			$max_date = strtotime( "+{$max['value']} {$max['unit']}", current_time( 'timestamp' ) );
			if ( $appointment->get_start() > $max_date || $appointment->get_end() > $max_date ) {
				/* translators: %s: maximum appointable date */
				echo '<div class="notice notice-warning"><p>' . sprintf( esc_attr__( 'This appointment is scheduled over the products allowed max appointment date (%s). Please ensure this is correct.', 'woocommerce-appointments' ), esc_attr( date_i18n( wc_appointments_date_format(), $max_date ) ) ) . '</p></div>';
			}
		}

		if ( $appointment->get_start() && $appointment->get_end() && $appointment->get_start() > $appointment->get_end() ) {
			echo '<div class="error"><p>' . esc_attr__( 'This appointment has an end date set before the start date.', 'woocommerce-appointments' ) . '</p></div>';
		}

		if ( ! $product ) {
			echo '<div class="error"><p>' . esc_attr__( 'It appears the appointment product associated with this appointment has been removed.', 'woocommerce-appointments' ) . '</p></div>';
			return;
		}

		if ( is_callable( [ $product, 'is_skeleton' ] ) && $product->is_skeleton() ) {
			$product_type = $product instanceof WC_Product ? $product->get_type() : '';
			echo '<div class="error"><p>' . sprintf(
				/* translators: %s: product type */
				esc_attr__( 'This appointment is missing a required add-on (product type: %s). Some information is shown below but might be incomplete. Please install the missing add-on through the plugins screen.', 'woocommerce-appointments' ),
				esc_attr( $product_type )
			) . '</p></div>';
		}
	}

	public function meta_box_inner( $post ): void {
		global $appointment;

		// Nonce.
		wp_nonce_field( 'wc_appointments_details_meta_box', 'wc_appointments_details_meta_box_nonce' );

		// Scripts.
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_script( 'jquery-ui-datepicker' );

		if ( ! is_a( $appointment, 'WC_Appointment' ) || $appointment->get_id() !== $post->ID ) {
			$appointment = get_wc_appointment( $post->ID );
		}

		// Sanity check saved dates
		$order           = $appointment->get_order();
		$product_id      = $appointment->get_product_id( 'edit' );
		$staff_ids       = $appointment->get_staff_ids( 'edit' );
		$staff_ids       = wc_appointments_normalize_staff_ids( $staff_ids );
		$product         = wc_get_product( $product_id );
		$product_name    = $product ? $product->get_title() . ' (#' . $product->get_id() . ')' : '';
		$statuses        = array_unique(
		    array_merge(
		        get_wc_appointment_statuses( null, true ),
		        get_wc_appointment_statuses( 'user', true ),
		        get_wc_appointment_statuses( 'cancel', true ),
		    ),
		);
		$customer        = (object) $appointment->get_customer();
		$customer_string = sprintf(
			/* translators: %1$s: full name, %2$s: user ID, %3$s: email */
			esc_html__( '%1$s (#%2$s &ndash; %3$s)', 'woocommerce-appointments' ),
		    $customer->full_name,
		    $customer->user_id,
		    $customer->email,
		);
		$this->sanity_check_notices( $appointment, $product );
		?>
		<div class="panel-wrap woocommerce">
			<div id="appointment_data" class="panel">

				<div class="appointment_data_container appointment_data_general">
					<div class="appointment_data_column data_column_wide">
						<h2>
						<?php
						printf(
							/* translators: %d: Appointment ID */
							esc_attr__( 'Appointment #%d', 'woocommerce-appointments' ),
							esc_attr( $post->ID ),
						);
						// Calendar view.
						printf(
						    '<a href="%1$s" class="view-on-calendar" title="%2$s"><span>☶</span></a>',
						    esc_url(
						        admin_url(
						            'edit.php?post_type=wc_appointment&page=appointment_calendar&view=day&calendar_day=' . $appointment->get_start_date( 'Y-m-d', '' ),
						        ),
						    ),
						    esc_attr__( 'View on calendar', 'woocommerce-appointments' ),
						);
						?>
						</h2>
						<p class="appointment-order-number">
						<?php
						if ( $order ) {
							// Check if current user can view orders
							$can_view_orders = ! class_exists( 'WC_Appointments_Staff_Permissions' ) || 
											  ! WC_Appointments_Staff_Permissions::is_staff_user( get_current_user_id() ) || 
											  WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'view_orders' );

							if ( $can_view_orders ) {
								printf(
									/* translators: %s: link to order (anchor with order number) or plain order number */
									' ' . esc_attr__( 'Linked to Order #%s', 'woocommerce-appointments' ),
									'<a href="' . esc_url( $order->get_edit_order_url() ) . '">' . esc_html( $order->get_order_number() ) . '</a>',
								);
							} else {
								printf(
									/* translators: %s: link to order (anchor with order number) or plain order number */
									' ' . esc_attr__( 'Linked to Order #%s', 'woocommerce-appointments' ),
									esc_html( $order->get_order_number() ),
								);
							}
						}

						if ( $product && method_exists( $product, 'is_appointments_addon' ) && $product->is_appointments_addon() && method_exists( $product, 'appointments_addon_title' ) ) {
							printf(
								/* translators: %s: appointments addon title */
								' ' . esc_attr__( 'Appointment type: %s', 'woocommerce-appointments' ),
							    esc_attr( $product->appointments_addon_title() ),
							);
						}
						?>
						</p>
						<?php
						#print '<pre>'; print_r( $appointment ); print '</pre>';
						?>
					</div>
					<div class="clear"></div>
					<div class="appointment_data_column">
						<h4><?php esc_html_e( 'General Details', 'woocommerce-appointments' ); ?></h4>

						<p class="form-field form-field-wide customer-form-field">
							<label for="_appointment_customer_id"><?php esc_html_e( 'Customer', 'woocommerce-appointments' ); ?>:</label>
							<select name="_appointment_customer_id" id="_appointment_customer_id" class="wc-customer-search" data-placeholder="<?php echo esc_attr( $customer->full_name ); ?>" data-allow_clear="true">
								<?php if ( $customer->user_id ) : ?>
									<option selected="selected" value="<?php echo esc_attr( $customer->user_id ); ?>"><?php echo esc_html( $customer_string ); ?></option>
								<?php endif; ?>
							</select>
						</p>

						<?php
							$customer_statuses = array_unique( get_wc_appointment_statuses( 'customer', true ) );
							// Remove Expected status, when appointment is past current time.
							if ( $appointment->get_start() < current_time( 'timestamp' ) && $appointment->get_end() < current_time( 'timestamp' ) ) {
								unset( $customer_statuses['expected'] );
							}
						?>

						<p class="form-field form-field-wide customer-status-field">
							<label for="_appointment_customer_status"><?php esc_html_e( 'Customer Status', 'woocommerce-appointments' ); ?>:</label>
							<select id="_appointment_customer_status" name="_appointment_customer_status" class="wc-enhanced-select">
								<?php
								foreach ( $customer_statuses as $key => $value ) {
									echo '<option value="' . esc_attr( $key ) . '" ' . selected( $key, $appointment->get_customer_status(), false ) . '>' . esc_html( $value ) . '</option>';
								}
								?>
							</select>
						</p>

						<?php
							$statuses = array_unique( array_merge( get_wc_appointment_statuses( null, true ), get_wc_appointment_statuses( 'user', true ), get_wc_appointment_statuses( 'cancel', true ) ) );
						?>

						<p class="form-field form-field-wide appointment-status-field">
							<label for="_appointment_status"><?php esc_html_e( 'Appointment Status', 'woocommerce-appointments' ); ?>:</label>
							<select id="_appointment_status" name="_appointment_status" class="wc-enhanced-select">
								<?php
								foreach ( $statuses as $key => $value ) {
									echo '<option value="' . esc_attr( $key ) . '" ' . selected( $key, $appointment->get_status(), false ) . '>' . esc_html( $value ) . '</option>';
								}
								?>
							</select>
							<input type="hidden" name="post_status" value="<?php echo esc_attr( $appointment->get_status() ); ?>">
						</p>

						<?php do_action( 'woocommerce_admin_appointment_data_after_appointment_details', $post->ID ); ?>
					</div>
					<div class="appointment_data_column">
						<h4><?php esc_html_e( 'Specification', 'woocommerce-appointments' ); ?></h4>
						<?php
						// Product select.
						?>
						<p class="form-field form-field-wide">
							<label for="product_id"><?php esc_html_e( 'Product', 'woocommerce-appointments' ); ?>:</label>
							<select class="wc-product-search" id="product_id" name="product_id" data-placeholder="<?php esc_html_e( 'N/A', 'woocommerce-appointments' ); ?>" data-action="woocommerce_json_search_appointable_products">
								<option value="<?php echo esc_attr( $product_id ); ?>" selected="selected"><?php echo esc_html( $product_name ); ?></option>';
							</select>
						</p>

						<?php
						// Staff select.
						if ( current_user_can( 'manage_others_appointments' ) ) {
							$staff = WC_Appointments_Admin::get_appointment_staff(); #all staff
						} elseif ( $product_id && $product && method_exists( $product, 'get_staff_ids' ) ) { #product staff
							$staff = [];
							foreach ( $product->get_staff_ids() as $staff_id ) {
								$staff[] = new WC_Product_Appointment_Staff( $staff_id );
							}
						} else {
							$staff = WC_Appointments_Admin::get_appointment_staff(); #all staff
						}

						$appointable_staff = [];
						foreach ( $staff as $staff_member ) {
							$appointable_staff[ $staff_member->ID ] = $staff_member->display_name;
						}
						?>
						<p class="form-field form-field-wide">
							<label for="staff_ids"><?php esc_html_e( 'Staff', 'woocommerce-appointments' ); ?>:<?php
								// Staff timezone abbr(s) next to label — only when different from logged-in user's TZ.
								if (
									! empty( $staff_ids ) &&
									class_exists( 'WC_Appointments_Timezone_Helper' ) &&
									'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' ) &&
									WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() )
								) {
									foreach ( $staff_ids as $_sid ) {
										echo wp_kses_post( WC_Appointments_Timezone_Helper::build_staff_timezone_abbr( (int) $_sid, $appointment ) );
									}
								}
							?></label>
							<select multiple="multiple" id="staff_ids" name="staff_ids[]" class="multiselect wc-enhanced-select" data-placeholder="<?php esc_html_e( 'N/A', 'woocommerce-appointments' ); ?>" data-allow_clear="true">
								<?php
								foreach ( $appointable_staff as $key => $value ) {
									echo '<option value="' . esc_attr( $key ) . '" ' . selected( in_array( $key, $staff_ids ), true ) . '>' . esc_html( $value ) . '</option>';
								}
								?>
							</select>
						</p>
						<?php
						$location_id = (int) $appointment->get_location_id( 'edit' );
						$locations   = ( class_exists( 'WC_Appointments_Location' ) && is_a( $product, 'WC_Product_Appointment' ) && $product->has_locations() )
							? array_intersect_key( WC_Appointments_Location::get_location_choices(), array_flip( WC_Appointments_Location::get_allowed_location_ids( $product ) ) )
							: [];
						if ( $location_id ) {
							$locations += [ $location_id => get_the_title( $location_id ) ];
						}
						if ( $locations ) {
							woocommerce_wp_select(
								[
									'id'            => 'location_id',
									'label'         => __( 'Location', 'woocommerce-appointments' ),
									'options'       => [ '' => __( 'N/A', 'woocommerce-appointments' ) ] + $locations,
									'value'         => $location_id,
									'wrapper_class' => 'form-field-wide',
									'class'         => 'wc-enhanced-select',
								]
							);
						}

						// Required resources (OR pool). Keep historical pick when beta off / outside current location filter.
						$resource_pool = [];
						if ( class_exists( 'WC_Appointments_Resource' ) && $product instanceof WC_Product_Appointment ) {
							$resource_choices = [];
							$current_rid      = 0;
							$allocs           = $appointment->get_resource_allocations( 'edit' );
							if ( is_array( $allocs ) && isset( $allocs[0]['resource_id'] ) ) {
								$current_rid = (int) $allocs[0]['resource_id'];
							}
							if ( $product->has_resources() ) {
								$loc_for_pool = $location_id > 0 ? $location_id : 0;
								foreach ( WC_Appointments_Resource::normalize_requirements( $product ) as $req ) {
									$rid = (int) ( $req['resource_id'] ?? 0 );
									if ( $rid <= 0 ) {
										continue;
									}
									$res_loc = (int) WC_Appointments_Resource_Data_Store::get_location_id( $rid );
									$title   = get_the_title( $rid );
									if ( ! $title ) {
										continue;
									}
									$resource_pool[ (string) $rid ] = [
										'title'       => $title,
										'location_id' => $res_loc,
									];
									if ( $loc_for_pool > 0 && $res_loc > 0 && $res_loc !== $loc_for_pool ) {
										continue;
									}
									$resource_choices[ $rid ] = $title;
								}
							}
							if ( $current_rid && ! isset( $resource_choices[ $current_rid ] ) ) {
								$resource_choices[ $current_rid ] = get_the_title( $current_rid ) ?: ( '#' . $current_rid );
							}
							if ( $resource_choices ) {
								if ( $current_rid <= 0 || ! isset( $resource_choices[ $current_rid ] ) ) {
									$current_rid = (int) array_key_first( $resource_choices );
								}
								woocommerce_wp_select(
									[
										'id'                => 'appointment_resource_id',
										'label'             => get_wc_appointment_data_label( 'resource', $product ),
										'options'           => $resource_choices,
										'value'             => $current_rid,
										'wrapper_class'     => 'form-field-wide',
										'class'             => 'wc-enhanced-select',
										'custom_attributes' => [
											'data-wca-pool' => wp_json_encode( $resource_pool ),
										],
									]
								);
							}
						}

						// Parent product ID.
						woocommerce_wp_text_input(
						    [
								'type'        => 'number',
								'id'          => '_appointment_parent_id',
								'label'       => __( 'Parent Appointment ID', 'woocommerce-appointments' ),
								'placeholder' => 'N/A',
							],
						);

						// Number of customers.
						if ( $appointment->get_qty( 'edit' ) ) {
							woocommerce_wp_text_input(
							    [
									'type'          => 'number',
									'id'            => '_appointment_qty',
									'label'         => __( 'Qty', 'woocommerce-appointments' ),
									'placeholder'   => '0',
									'value'         => $appointment->get_qty( 'edit' ),
									'custom_attributes' => [
										'min'  => '1',
										'step' => '1',
									],
									'wrapper_class' => 'appointment-qty',
								],
							);
						}

						?>
					</div>
					<div class="appointment_data_column last_column">
						<?php
						// Get admin user's timezone for display - times are shown in staff's timezone (or site when timezone display is disabled).
						$site_tz = class_exists( 'WC_Appointments_Timezone_Helper' )
							? WC_Appointments_Timezone_Helper::get_site_timezone_string()
							: wc_timezone_string();
						$admin_tz = ( class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) )
							? WC_Appointments_Timezone_Helper::get_admin_user_timezone()
							: $site_tz;
						$admin_has_different_tz = $admin_tz !== $site_tz;

						// Convert stored timestamps to admin timezone for display.
						$start_ts = $appointment->get_start( 'edit' );
						$end_ts = $appointment->get_end( 'edit' );

						// All-day end dates are stored as exclusive boundaries (midnight of the
						// day after the last booked day). For display in the "End Date (inclusive)"
						// field, subtract 1 second so the date shown is the last booked day.
						$is_all_day = $appointment->get_all_day( 'edit' );
						$display_end_ts = ( $is_all_day && $end_ts ) ? $end_ts - 1 : $end_ts;

						if ( $admin_has_different_tz && $start_ts && $end_ts ) {
							try {
								$site_tz_obj = new DateTimeZone( $site_tz );
								$admin_tz_obj = new DateTimeZone( $admin_tz );

								// Timestamps are semantic: UTC value = site-local time.
								// Use date() (PHP TZ = UTC) to extract site-local components,
								// NOT date_i18n() which double-converts by adding the offset.
								$start_site_str = date( 'Y-m-d H:i:s', $start_ts );
								$start_dt = new DateTime( $start_site_str, $site_tz_obj );
								$start_dt->setTimezone( $admin_tz_obj );
								$display_start_date = $start_dt->format( 'Y-m-d' );
								$display_start_time = $start_dt->format( 'H:i' );

								$end_site_str = date( 'Y-m-d H:i:s', $display_end_ts );
								$end_dt = new DateTime( $end_site_str, $site_tz_obj );
								$end_dt->setTimezone( $admin_tz_obj );
								$display_end_date = $end_dt->format( 'Y-m-d' );
								$display_end_time = $end_dt->format( 'H:i' );
							} catch ( Exception $e ) {
								// Fallback to site timezone display (date() for semantic timestamps).
								$display_start_date = date( 'Y-m-d', $start_ts );
								$display_start_time = date( 'H:i', $start_ts );
								$display_end_date = date( 'Y-m-d', $display_end_ts );
								$display_end_time = date( 'H:i', $display_end_ts );
							}
						} else {
							// No conversion needed — use date() for semantic timestamps
							// (UTC value = site-local time). Matches WC Bookings pattern.
							$display_start_date = date( 'Y-m-d', $start_ts );
							$display_start_time = date( 'H:i', $start_ts );
							$display_end_date = date( 'Y-m-d', $display_end_ts );
							$display_end_time = date( 'H:i', $display_end_ts );
						}
						?>
						<h4>
							<?php esc_html_e( 'Date/Time', 'woocommerce-appointments' ); ?>
							<?php
							if ( class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
								echo wp_kses_post( WC_Appointments_Timezone_Helper::build_timezone_indicator_html( $admin_tz ) );
							}
							?>
						</h4>
						<?php
						// Pass timezone info to JavaScript for save conversion.
						if ( $admin_has_different_tz ) {
							printf(
								'<input type="hidden" id="_admin_timezone" name="_admin_timezone" value="%s" />',
								esc_attr( $admin_tz )
							);
							printf(
								'<input type="hidden" id="_site_timezone" name="_site_timezone" value="%s" />',
								esc_attr( $site_tz )
							);
						}
						?>

						<?php
						woocommerce_wp_checkbox(
							[
								'id'          => '_appointment_all_day',
								'label'       => __( 'All Day:', 'woocommerce-appointments' ),
								'description' => __( 'Check this box if the appointment lasts all day.', 'woocommerce-appointments' ),
								'value'       => $appointment->get_all_day( 'edit' ) ? 'yes' : 'no',
							],
						);

						woocommerce_wp_text_input(
						    [
								'id'          => 'appointment_start_date',
								'type'        => 'text',
								'label'       => __( 'Start Date', 'woocommerce-appointments' ) . ':',
								'placeholder' => 'yyyy-mm-dd',
								'value'       => $display_start_date,
								'class'       => 'date-picker',
							],
						);

						woocommerce_wp_text_input(
						    [
								'id'          => 'appointment_start_time',
								'type'        => 'time',
								'label'       => __( 'Start Time:', 'woocommerce-appointments' ),
								'placeholder' => 'hh:mm',
								'value'       => $display_start_time,
								'class'       => 'time-picker',
							],
						);

						woocommerce_wp_text_input(
						    [
								'id'          => 'appointment_end_date',
								'type'        => 'text',
								'label'       => __( 'End Date', 'woocommerce-appointments' ) . ' ' .  esc_html__( '(inclusive)', 'woocommerce-appointments' ) . ':',
								'placeholder' => 'yyyy-mm-dd',
								'value'       => $display_end_date,
								'class'       => 'date-picker',
							],
						);

						woocommerce_wp_text_input(
						    [
								'id'          => 'appointment_end_time',
								'type'        => 'time',
								'label'       => __( 'End Time:', 'woocommerce-appointments' ),
								'placeholder' => 'hh:mm',
								'value'       => $display_end_time,
								'class'       => 'time-picker',
							],
						);

						$_customer_tz_abbr = '';
						$_booking_tz_abbr  = '';
						if (
							class_exists( 'WC_Appointments_Timezone_Helper' ) &&
							'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' ) &&
							WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() )
						) {
							// Customer TZ abbr — only when different from logged-in user's TZ.
							$_customer_tz_abbr = WC_Appointments_Timezone_Helper::build_customer_timezone_abbr( $appointment );

							// Booking TZ row — show only when the appointment's stored local_timezone
							// differs from the customer's current account timezone preference.
							$_booking_tz   = $appointment->get_local_timezone();
							$_customer_tz  = WC_Appointments_Timezone_Helper::get_appointment_customer_timezone( $appointment );
							$_viewer_tz    = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
							if (
								$_booking_tz &&
								$_booking_tz !== $_customer_tz &&
								WC_Appointments_Timezone_Helper::is_valid_timezone( $_booking_tz )
							) {
								$_booking_tz_abbr = WC_Appointments_Timezone_Helper::build_timezone_context_abbr( $_booking_tz, $_viewer_tz, $appointment );
							}
						}
						if ( $_customer_tz_abbr ) :
							?>
						<p class="form-field wca-customer-tz-info" style="margin-top:8px;">
							<label><?php esc_html_e( "Customer's Timezone", 'woocommerce-appointments' ); ?>:</label>
							<?php echo wp_kses_post( $_customer_tz_abbr ); ?>
						</p>
						<?php endif; ?>
						<?php if ( $_booking_tz_abbr ) : ?>
						<p class="form-field wca-booking-tz-info" style="margin-top:4px;">
							<label><?php esc_html_e( 'Booking Timezone', 'woocommerce-appointments' ); ?>:</label>
							<?php echo wp_kses_post( $_booking_tz_abbr ); ?>
						</p>
						<?php endif; ?>
					</div>
					<div class="clear"></div>
				</div>
				<?php
				$appointment_addons = $appointment->get_addons();
				if ( $appointment_addons ) {
				?>
					<div class="appointment_data_container appointment_data_addons">
						<div class="clear"></div>
						<div class="appointment_data_column data_column_wide">
							<h3><?php esc_html_e( 'Add-ons', 'woocommerce-appointments' ); ?></h3>
							<?php echo $appointment_addons; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Add-ons HTML built by WC Product Add-ons. ?>
						</div>
						<div class="clear"></div>
					</div>
				<?php } ?>
			</div>
		</div>
		<?php
		// Select2 handling.
		$handle = 'wc-appointments-meta-box-data';
		wp_register_script( $handle, '', [ 'jquery', 'jquery-ui-datepicker' ], WC_APPOINTMENTS_VERSION, true );
		wp_enqueue_script( $handle );
		wp_add_inline_script(
		    $handle,
		    "
			jQuery(function($) {
				$( '#_appointment_all_day' ).on( 'change', function () {
					if ( $( this ).is( ':checked' ) ) {
						$( '#appointment_start_time, #appointment_end_time' ).closest( 'p' ).hide();
					} else {
						$( '#appointment_start_time, #appointment_end_time' ).closest( 'p' ).show();
					}
				}).trigger( 'change' );

				$( '.date-picker' ).datepicker({
					dateFormat: 'yy-mm-dd',
					numberOfMonths: 1,
					showOtherMonths: true,
					changeMonth: true,
					showButtonPanel: true,
					firstDay: '" . absint( get_option( 'start_of_week', 1 ) ) . "'
				});

				// Check if start- and end date are correct
				var start = $( '#appointment_start_date' );
				var end = $( '#appointment_end_date' );
				var start_date = start.val().replace(/-/g,'');
				var end_date = end.val().replace(/-/g,'');
				$( '#appointment_start_date, #appointment_end_date' ).on( 'click', function() {
					update_dates();
				});
				start.on( 'change', function() {
					if ( start_date > end_date ) {
						end.val( $( this ).val() );
						input_animate(end);
					} else if ( start_date === end_date ) {
							end.val( $( this ).val() );
						input_animate(end);
						}
				});
				end.on( 'change', function() {
					update_dates();
					if ( end_date < start_date ) {
						start.val( $( this ).val() );
						input_animate(start);
					}
				});

				function update_dates(){
					start_date = start.val().replace(/-/g,'');
					end_date = end.val().replace(/-/g,'');
				}

				function input_animate(e){
					e.stop().css({backgroundColor:'#ddd'}).animate({backgroundColor:'none'}, 500);
				}

				$( '#location_id' ).on( 'change', function() {
					var \$r = $( '#appointment_resource_id' ), pool = \$r.data( 'wcaPool' ), loc = parseInt( this.value, 10 ) || 0, cur = String( \$r.val() || '' ), kept = [];
					if ( ! \$r.length || ! pool ) { return; }
					\$r.empty();
					$.each( pool, function( rid, row ) {
						var rl = parseInt( row.location_id, 10 ) || 0;
						if ( loc && rl && rl !== loc ) { return; }
						kept.push( String( rid ) );
						\$r.append( $( '<option>', { value: rid, text: row.title || rid } ) );
					} );
					\$r.val( -1 !== kept.indexOf( cur ) ? cur : ( kept[0] || '' ) ).trigger( 'change' );
				} );
			});
		",
		);
	}

	/**
     * Returns an array of labels (statuses wrapped in gettext)
     *
     * @param array<string, string>  $statuses
     * @deprecated since 2.3.0. $this->get_wc_appointment_statuses now also comes with globalised strings.
	 * @return array<string, mixed>
     */
    public function get_labels_for_statuses( $statuses = [] ): array {
		$labels = [];

		foreach ( $statuses as $status ) {
			$labels[ $status ] = $status;
		}

		return $labels;
	}

	/**
	 * Whether admin POST date/time pieces are safe to pass to mktime().
	 *
	 * @param list<string|int> $start_date Year, month, day (from `appointment_start_date`).
	 * @param list<string|int> $end_date   Year, month, day (from `appointment_end_date`).
	 * @param list<string|int> $start_time Hour, minute (from `appointment_start_time`).
	 * @param list<string|int> $end_time   Hour, minute (from `appointment_end_time`).
	 * @param bool  $is_all_day All-day flag (times ignored when true).
	 * @return bool
	 */
	private function is_valid_appointment_datetime_input( $start_date, $end_date, $start_time, $end_time, $is_all_day ): bool {
		if ( ! is_array( $start_date ) || 3 !== count( $start_date ) || ! is_array( $end_date ) || 3 !== count( $end_date ) ) {
			return false;
		}

		$sy = absint( $start_date[0] );
		$sm = absint( $start_date[1] );
		$sd = absint( $start_date[2] );
		$ey = absint( $end_date[0] );
		$em = absint( $end_date[1] );
		$ed = absint( $end_date[2] );

		if ( ! checkdate( $sm, $sd, $sy ) || ! checkdate( $em, $ed, $ey ) ) {
			return false;
		}

		if ( ! $is_all_day ) {
			if ( ! is_array( $start_time ) || count( $start_time ) < 2 || ! is_array( $end_time ) || count( $end_time ) < 2 ) {
				return false;
			}
			$sh = absint( $start_time[0] );
			$smi = absint( $start_time[1] );
			$eh = absint( $end_time[0] );
			$emi = absint( $end_time[1] );
			if ( $sh > 23 || $smi > 59 || $eh > 23 || $emi > 59 ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Save handler.
	 *
	 * @param  int     $post_id
	 * @param  WP_Post $post
     *
     * @return int|void
	 */
	public function meta_box_save( $post_id, $post ) {
		if ( ! isset( $_POST['wc_appointments_details_meta_box_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wc_appointments_details_meta_box_nonce'] ) ), 'wc_appointments_details_meta_box' ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		$posted = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wc_clean()/absint() per field below.

		// Check the post being saved == the $post_id to prevent triggering this call for other save_post events
		if ( empty( $posted['post_ID'] ) || absint( $posted['post_ID'] ) !== $post_id ) {
			return $post_id;
		}

		if ( ! in_array( $post->post_type, $this->post_types ) ) {
			return $post_id;
		}

		if ( self::$saved_meta_box ) {
			return $post_id;
		}

		// Get appointment object.
		$appointment = get_wc_appointment( $post_id );
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return $post_id;
		}
		$product_id  = wc_clean( $posted['product_id'] ?? '' ) ?: $appointment->get_product_id();
		$start_date  = explode( '-', wc_clean( $posted['appointment_start_date'] ?? '' ) );
		$end_date    = explode( '-', wc_clean( $posted['appointment_end_date'] ?? '' ) );
		$start_time  = explode( ':', wc_clean( $posted['appointment_start_time'] ?? '' ) );
		$end_time    = explode( ':', wc_clean( $posted['appointment_end_time'] ?? '' ) );
		$is_all_day  = ! empty( $posted['_appointment_all_day'] );

		if ( ! $this->is_valid_appointment_datetime_input( $start_date, $end_date, $start_time, $end_time, $is_all_day ) ) {
			WC_Admin_Meta_Boxes::add_error( __( 'Please enter a valid start and end date and time for this appointment.', 'woocommerce-appointments' ) );
			// Same as the success path: mark this handler so further save_post runs in this request do not re-enter (duplicate notices / loop risk).
			self::$saved_meta_box = true;
			return $post_id;
		}

		// We need this save event to run once to avoid potential endless loops. This would have been perfect:
		// remove_action( current_filter(), __METHOD__ );
		// But cannot be used due to https://github.com/woocommerce/woocommerce/issues/6485
		// When that is patched in core we can use the above. For now:
		self::$saved_meta_box = true;

		// Check if admin has different timezone - if so, convert from admin TZ to site TZ.
		$admin_tz = wc_clean( $posted['_admin_timezone'] ?? '' );
		$site_tz  = wc_clean( $posted['_site_timezone'] ?? '' );

		if ( $admin_tz && $site_tz && $admin_tz !== $site_tz ) {
			// Convert from admin timezone to site timezone.
			// WordPress stores timestamps semantically representing site timezone times,
			// so we need to convert the admin TZ time to site TZ time, then use mktime.
			try {
				$admin_tz_obj = new DateTimeZone( $admin_tz );
				$site_tz_obj  = new DateTimeZone( $site_tz );

				// Build datetime string from form inputs (in admin timezone).
				// For all-day appointments, force times to midnight (00:00:00)
				// to prevent shifting caused by UI's inclusive day display logic.
				$start_str = sprintf(
					'%04d-%02d-%02d %02d:%02d:00',
					$start_date[0],
					$start_date[1],
					$start_date[2],
					$is_all_day ? 0 : $start_time[0],
					$is_all_day ? 0 : $start_time[1]
				);
				$end_str = sprintf(
					'%04d-%02d-%02d %02d:%02d:00',
					$end_date[0],
					$end_date[1],
					$end_date[2],
					$is_all_day ? 0 : $end_time[0],
					$is_all_day ? 0 : $end_time[1]
				);

				// Create DateTime in admin timezone, convert to site timezone.
				$start_dt = new DateTime( $start_str, $admin_tz_obj );
				$start_dt->setTimezone( $site_tz_obj );
				// Get site timezone local time components and use gmmktime (Fake UTC model).
				$start = gmmktime(
					(int) $start_dt->format( 'G' ),
					(int) $start_dt->format( 'i' ),
					0,
					(int) $start_dt->format( 'n' ),
					(int) $start_dt->format( 'j' ),
					(int) $start_dt->format( 'Y' )
				);

				$end_dt = new DateTime( $end_str, $admin_tz_obj );
				$end_dt->setTimezone( $site_tz_obj );
				$end = gmmktime(
					(int) $end_dt->format( 'G' ),
					(int) $end_dt->format( 'i' ),
					0,
					(int) $end_dt->format( 'n' ),
					(int) $end_dt->format( 'j' ),
					(int) $end_dt->format( 'Y' )
				);
			} catch ( Exception $e ) {
				// Fallback: gmmktime to produce Fake UTC (store wall time as UTC-labelled int).
				$start = gmmktime( (int) $start_time[0], (int) $start_time[1], 0, (int) $start_date[1], (int) $start_date[2], (int) $start_date[0] );
				$end   = gmmktime( (int) $end_time[0], (int) $end_time[1], 0, (int) $end_date[1], (int) $end_date[2], (int) $end_date[0] );
			}
		} else {
			// No timezone conversion needed: gmmktime to produce Fake UTC (store wall time as UTC-labelled int).
			$start = gmmktime( $is_all_day ? 0 : (int) $start_time[0], $is_all_day ? 0 : (int) $start_time[1], 0, (int) $start_date[1], (int) $start_date[2], (int) $start_date[0] );
			$end   = gmmktime( $is_all_day ? 0 : (int) $end_time[0], $is_all_day ? 0 : (int) $end_time[1], 0, (int) $end_date[1], (int) $end_date[2], (int) $end_date[0] );
		}

		$product = wc_get_product( $product_id );

		// All-day appointments: the edit form shows inclusive end dates (last booked day),
		// but storage uses exclusive boundaries (midnight of the day after). Convert back.
		if ( $is_all_day ) {
			$end = strtotime( '+1 day', $end );
		}

		// New appointment meta.
		$props = [
			'all_day'         => $is_all_day,
			'customer_id'     => absint( $posted['_appointment_customer_id'] ?? 0 ),
			'date_created'    => empty( $posted['appointment_date'] ) ? current_time( 'timestamp' ) : strtotime( wc_clean( $posted['appointment_date'] ) . ' ' . absint( $posted['appointment_date_hour'] ?? 0 ) . ':' . absint( $posted['appointment_date_minute'] ?? 0 ) . ':00' ),
			'start'           => $start,
			'end'             => $end,
			'parent_id'       => absint( $posted['_appointment_parent_id'] ?? 0 ),
			'product_id'      => absint( $product_id ),
			'staff_ids'       => wc_clean( $posted['staff_ids'] ?? '' ),
			'status'          => wc_clean( $posted['_appointment_status'] ?? '' ),
			'customer_status' => wc_clean( $posted['_appointment_customer_status'] ?? '' ),
			'qty'             => absint( $posted['_appointment_qty'] ?? 1 ),
		];

		do_action( 'woocommerce_admin_process_appointment_props', $props, $appointment );

		// Save appointment meta.
		$appointment->set_props( $props );

		if ( isset( $posted['location_id'] ) && class_exists( 'WC_Appointments_Location' ) ) {
			$loc_id = absint( $posted['location_id'] );
			if ( $loc_id && ( ! is_wc_appointment_product( $product ) || ! WC_Appointments_Location::authorize_location_id( $product, $loc_id ) ) ) {
				$loc_id = 0;
			}
			WC_Appointments_Location::apply_to_appointment( $appointment, $loc_id );
		}

		// Resource allocations from product requirements (preserve admin/customer pick).
		if ( class_exists( 'WC_Appointments_Resource' ) && $product instanceof WC_Product_Appointment ) {
			$selected_resource = isset( $posted['appointment_resource_id'] ) ? absint( $posted['appointment_resource_id'] ) : 0;
			if ( $selected_resource <= 0 && $appointment->has_resource_allocations() ) {
				$existing = $appointment->get_resource_allocations( 'edit' );
				$selected_resource = (int) ( $existing[0]['resource_id'] ?? 0 );
			}
			$allocations = WC_Appointments_Resource::build_allocations_from_product(
				$product,
				$selected_resource,
				absint( $appointment->get_location_id() ),
				(int) $start,
				(int) $end,
				(int) $appointment->get_id()
			);
			if ( [] !== $allocations ) {
				WC_Appointments_Resource::apply_to_appointment( $appointment, $allocations );
			}
		}

		do_action( 'woocommerce_admin_process_appointment_object', $appointment );

		$appointment->save();

		do_action( 'woocommerce_appointment_process_meta', $post_id );
	}
}

return new WC_Appointment_Meta_Box_Data();
