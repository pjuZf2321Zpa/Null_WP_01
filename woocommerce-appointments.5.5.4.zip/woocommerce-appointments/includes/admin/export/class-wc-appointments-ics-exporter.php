<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * .ics Exporter
 *
 * ============================================================================
 * TIMEZONE ARCHITECTURE NOTE
 * ============================================================================
 *
 * ICS files require proper timezone handling for external calendar applications.
 *
 * CURRENT BEHAVIOR:
 * - Emits a VTIMEZONE component (RFC 5545 §3.6.5) for the site timezone.
 * - DTSTART/DTEND use TZID= parameter referencing the VTIMEZONE.
 * - DTSTAMP is always UTC with Z suffix (RFC 5545 §3.8.7.2).
 * - X-WR-TIMEZONE is kept as a non-standard hint for Apple iCal.
 *
 * IMPORTANT: Our stored timestamps ALREADY represent site timezone times
 * (stored as UTC but semantically meaning site TZ). When formatting for ICS:
 * - date('Ymd\THis', $timestamp) produces correct site-local time
 * - DO NOT add 'Z' suffix on DTSTART/DTEND (that would indicate UTC)
 * - DO NOT perform timezone conversion for DTSTART/DTEND
 *
 * ORGANIZER must use mailto: URI scheme per RFC 5545 §3.8.4.3.
 *
 * See docs/TIMEZONE_ARCHITECTURE.md
 * ============================================================================
 */
class WC_Appointments_ICS_Exporter implements WC_Appointments_Exporter_Interface {

	/**
	 * Appointments list to export
	 *
	 * @var list<WC_Appointment>
	 */
	protected array $appointments = [];

	/**
	 * File path
	 *
	 * @var string
	 */
	protected string $file_path = '';

	/**
	 * UID prefix.
	 *
	 * @var string
	 */
	protected string $uid_prefix = 'wc_appointments_';

	/**
	 * Whether to export add-ons.
	 *
	 * @var bool
	 */
	protected bool $export_addons = false;

	/**
	 * End of line.
	 *
	 * @var string
	 */
	protected string $eol = "\r\n";

	/**
	 * Get appointment .ics
	 *
	 * Generates an .ics file for a single appointment.
	 *
	 * @param  WC_Appointment $appointment Appointment data
	 *
	 * @return string Path to the generated .ics file.
	 */
	public function get_appointment_ics( $appointment ) {
		$product         = $appointment->get_product();
		$product_title   = $product ? $product->get_title() : 'appointment';
		$this->file_path = $this->get_file_path( $appointment->get_id() . '-' . $product_title );
		$this->appointments[] = $appointment;

		// Create the .ics
		$this->create();

		return $this->file_path;
	}

	/**
	 * Get .ics for appointments.
	 *
	 * Generates an .ics file for a list of appointments.
	 *
	 * @param array<int, mixed> $appointments Appointment objects to export; invalid entries are skipped.
	 * @param string            $filename     .ics filename (without extension, or with .ics extension)
	 *
	 * @return string Path to the generated .ics file.
	 */
	public function get_ics( $appointments, $filename = '' ) {
		// Create a generic filename.
		if ( '' == $filename ) {
			$filename = 'appointments-' . gmdate( 'Ymd-His', current_time( 'timestamp' ) );
		}

		// Remove .ics extension if present (we'll add it in get_file_path).
		$filename = preg_replace( '/\.ics$/i', '', $filename );
		// Remove any "-ics" suffix before extension.
		$filename = preg_replace( '/-ics$/i', '', $filename );

		$this->file_path    = $this->get_file_path( $filename );
		$valid_appointments = array_values(
			array_filter(
				$appointments,
				static function ( $appointment ) {
					return $appointment instanceof WC_Appointment;
				}
			)
		);
		$dropped_count      = count( $appointments ) - count( $valid_appointments );

		if ( $dropped_count > 0 && function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->warning(
				sprintf(
					'ICS export "%1$s" skipped %2$d unloadable appointment %3$s (%4$d exported).',
					$filename,
					$dropped_count,
					1 === $dropped_count ? 'entry' : 'entries',
					count( $valid_appointments )
				),
				array( 'source' => 'wc-appointments' )
			);
		}

		$this->appointments = $valid_appointments;

		// Create the .ics
		$this->create();

		return $this->file_path;
	}

	/**
     * Get file path
     *
     * Generates the absolute file path for the .ics file based on the filename.
     *
     * @param  string $filename Filename
     * @return string Absolute path to the file.
     */
    protected function get_file_path( $filename ): string {
		$upload_data = wp_upload_dir();

		return $upload_data['path'] . '/' . sanitize_title( $filename ) . '.ics';
	}

	/**
	 * Create the .ics file
	 *
	 * Writes the generated ICS content to the file system.
	 *
	 * @return void
	 */
	protected function create() {
		// @codingStandardIgnoreStart
		$handle = @fopen( $this->file_path, 'w' );
		$ics    = $this->generate();
		@fwrite( $handle, $ics );
		@fclose( $handle );
		// @codingStandardIgnoreEnd
	}

	/**
	 * Format the date for DTSTART/DTEND (local time, no Z suffix).
	 *
	 * Formats a timestamp for ICS DTSTART/DTEND properties.
	 *
	 * @version 3.0.0
	 *
	 * @param int            $timestamp   Timestamp to format.
	 * @param WC_Appointment $appointment Appointment object.
	 *
	 * @return string Formatted date string.
	 */
	protected function format_date( $timestamp, $appointment = null ) {
		$pattern = 'Ymd\THis';
		$old_ts  = $timestamp;

		if ( $appointment ) {
			$pattern = ( $appointment->is_all_day() ) ? 'Ymd' : $pattern;

			// Note: End timestamps are already stored as exclusive boundaries (00:00:00 of the day after).
			// For all-day events, ICS spec (RFC 5545) requires DTEND to be exclusive.
			// No additional +1 day adjustment needed - the stored timestamp is already correct.
		}

		return apply_filters( 'woocommerce_appointments_ics_format_date', date( $pattern, $timestamp ), $timestamp, $old_ts, $appointment );
	}

	/**
	 * Format a timestamp as UTC for DTSTAMP/LAST-MODIFIED (always Z suffix).
	 *
	 * @param int $timestamp Unix timestamp.
	 * @return string UTC date string with Z suffix.
	 */
	protected function format_date_utc( $timestamp ) {
		return gmdate( 'Ymd\THis\Z', $timestamp );
	}

	/**
	 * Generate a VTIMEZONE component for the given timezone string.
	 *
	 * Emits a minimal VTIMEZONE with STANDARD and DAYLIGHT sub-components
	 * derived from PHP's DateTimeZone transitions. This satisfies RFC 5545
	 * §3.6.5 and is required by Outlook, Thunderbird, and other strict parsers
	 * that do not honour the non-standard X-WR-TIMEZONE header.
	 *
	 * Each sub-component includes an RRULE so that parsers can extrapolate
	 * transitions to any future year (RFC 5545 §3.6.5 requires this for
	 * correct DST resolution of events beyond the year of the DTSTART).
	 *
	 * @param string $tz_string IANA timezone identifier (e.g. "Europe/London").
	 * @return string VTIMEZONE block lines (each terminated with $this->eol).
	 */
	protected function generate_vtimezone( $tz_string ) {
		try {
			$tz          = new DateTimeZone( $tz_string );
			$transitions = $tz->getTransitions( time() - YEAR_IN_SECONDS, time() + ( 2 * YEAR_IN_SECONDS ) );
		} catch ( Exception $e ) {
			return '';
		}

		// Offset-based zones (e.g. "+01:00" from gmt_offset) return false, not an empty array.
		if ( ! is_array( $transitions ) ) {
			$transitions = array();
		}

		// PHP's first getTransitions() row is the zone state at the range start,
		// not a DST change. Using it as DAYLIGHT/STANDARD yields bogus BYDAY
		// rules (e.g. "2WE in October" instead of last Sunday in March). #1480
		if ( ! empty( $transitions ) ) {
			array_shift( $transitions );
		}

		$standard = null;
		$daylight = null;

		foreach ( $transitions as $t ) {
			if ( $t['isdst'] ) {
				if ( null === $daylight ) {
					$daylight = $t;
				}
			} else {
				if ( null === $standard ) {
					$standard = $t;
				}
			}
			if ( null !== $standard && null !== $daylight ) {
				break;
			}
		}

		if ( null === $standard ) {
			// No transitions found — use current offset as a fixed STANDARD.
			$now      = new DateTime( 'now', $tz );
			$offset   = $now->getOffset();
			$sign     = $offset >= 0 ? '+' : '-';
			$abs      = abs( $offset );
			$hh       = str_pad( (string) (int) floor( $abs / 3600 ), 2, '0', STR_PAD_LEFT );
			$mm       = str_pad( (string) (int) ( ( $abs % 3600 ) / 60 ), 2, '0', STR_PAD_LEFT );
			$offset_s = $sign . $hh . $mm;

			$out  = 'BEGIN:VTIMEZONE' . $this->eol;
			$out .= 'TZID:' . $tz_string . $this->eol;
			$out .= 'BEGIN:STANDARD' . $this->eol;
			$out .= 'DTSTART:19700101T000000' . $this->eol;
			$out .= 'TZOFFSETFROM:' . $offset_s . $this->eol;
			$out .= 'TZOFFSETTO:' . $offset_s . $this->eol;
			$out .= 'END:STANDARD' . $this->eol;
			$out .= 'END:VTIMEZONE' . $this->eol;

			return $out;
		}

		$format_offset = function ( $seconds ) {
			$sign = $seconds >= 0 ? '+' : '-';
			$abs  = abs( $seconds );
			$hh   = str_pad( (string) (int) floor( $abs / 3600 ), 2, '0', STR_PAD_LEFT );
			$mm   = str_pad( (string) (int) ( ( $abs % 3600 ) / 60 ), 2, '0', STR_PAD_LEFT );
			return $sign . $hh . $mm;
		};

		// Transition timestamps from getTransitions() are true UTC integers.
		// We must format them as local wall-clock time in the target timezone
		// (RFC 5545 §3.6.5), NOT with bare date() which treats integers as fake-UTC.
		$format_transition_dt = function ( $ts ) use ( $tz ) {
			$dt = new DateTime( '@' . $ts );
			$dt->setTimezone( $tz );
			return $dt->format( 'Ymd\THis' );
		};

		// Build an RFC 5545 RRULE for a DST transition so parsers can extrapolate
		// the rule to any future year. Most DST rules follow a "Nth weekday of month"
		// pattern (e.g. "last Sunday in October"). We derive this from the transition
		// date: compute which occurrence of that weekday it is within the month
		// (1–4 = first–fourth, -1 = last), then emit RRULE:FREQ=YEARLY;BYDAY=...
		// Without RRULE, strict parsers only know about the single year in DTSTART
		// and cannot determine the correct UTC offset for future appointments.
		$build_rrule = function ( $ts ) use ( $tz ) {
			$dt      = new DateTime( '@' . $ts );
			$dt->setTimezone( $tz );
			$month   = (int) $dt->format( 'n' );
			$day_num = (int) $dt->format( 'j' );
			$days_in_month = (int) $dt->format( 't' );
			// RFC 5545 day abbreviations (SU, MO, TU, WE, TH, FR, SA).
			$day_abbrs = [ 'SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA' ];
			$dow       = $day_abbrs[ (int) $dt->format( 'w' ) ];

			// Determine ordinal: if the transition falls in the last 7 days of the
			// month it is the "last" occurrence (-1); otherwise count from the start.
			if ( $day_num > $days_in_month - 7 ) {
				$ordinal = -1;
			} else {
				$ordinal = (int) ceil( $day_num / 7 );
			}

			return 'RRULE:FREQ=YEARLY;BYDAY=' . $ordinal . $dow . ';BYMONTH=' . $month;
		};

		$out  = 'BEGIN:VTIMEZONE' . $this->eol;
		$out .= 'TZID:' . $tz_string . $this->eol;

		$out .= 'BEGIN:STANDARD' . $this->eol;
		$out .= 'DTSTART:' . $format_transition_dt( $standard['ts'] ) . $this->eol;
		$out .= $build_rrule( $standard['ts'] ) . $this->eol;
		$out .= 'TZOFFSETFROM:' . $format_offset( $standard['offset'] + ( $daylight ? $daylight['offset'] - $standard['offset'] : 0 ) ) . $this->eol;
		$out .= 'TZOFFSETTO:' . $format_offset( $standard['offset'] ) . $this->eol;
		$out .= 'TZNAME:' . $standard['abbr'] . $this->eol;
		$out .= 'END:STANDARD' . $this->eol;

		if ( null !== $daylight ) {
			$out .= 'BEGIN:DAYLIGHT' . $this->eol;
			$out .= 'DTSTART:' . $format_transition_dt( $daylight['ts'] ) . $this->eol;
			$out .= $build_rrule( $daylight['ts'] ) . $this->eol;
			$out .= 'TZOFFSETFROM:' . $format_offset( $standard['offset'] ) . $this->eol;
			$out .= 'TZOFFSETTO:' . $format_offset( $daylight['offset'] ) . $this->eol;
			$out .= 'TZNAME:' . $daylight['abbr'] . $this->eol;
			$out .= 'END:DAYLIGHT' . $this->eol;
		}

		$out .= 'END:VTIMEZONE' . $this->eol;

		return $out;
	}

	/**
	 * Sanitize strings for .ics
	 *
	 * Escapes special characters in strings for ICS format.
	 *
	 * @param  string $string Input string.
	 *
	 * @return string Sanitized string.
	 */
	protected function sanitize_string( $string ) {
		// RFC 5545 TEXT: escape backslash first, then comma/semicolon, then newlines.
		$string = str_replace( '\\', '\\\\', $string );
		$string = preg_replace( '/([,;])/', '\\\$1', $string );
		$string = str_replace( "\n", '\n', $string );

		return sanitize_text_field( $string );
	}

	/**
	 * Generate the .ics content
	 *
	 * Builds the VCALENDAR content string including all appointments.
	 *
	 * @return string ICS content.
	 */
	protected function generate() {
		$sitename  = get_option( 'blogname' );
		$tz_string = wc_timezone_string();

		// Set the ics data.
		$ics  = 'BEGIN:VCALENDAR' . $this->eol;
		$ics .= 'VERSION:2.0' . $this->eol;
		$ics .= 'PRODID:-//BookingWP//WooCommerce Appointments ' . WC_APPOINTMENTS_VERSION . '//EN' . $this->eol;
		$ics .= 'CALSCALE:GREGORIAN' . $this->eol;
		$ics .= 'METHOD:PUBLISH' . $this->eol;
		$ics .= 'X-WR-CALNAME:' . $this->sanitize_string( $sitename ) . $this->eol;
		$ics .= 'X-ORIGINAL-URL:' . $this->sanitize_string( get_site_url( get_current_blog_id(), '/' ) ) . $this->eol;
		/* translators: %s: site name */
		$ics .= 'X-WR-CALDESC:' . $this->sanitize_string( sprintf( __( 'Appointments from %s', 'woocommerce-appointments' ), $sitename ) ) . $this->eol;
		$ics .= 'X-WR-TIMEZONE:' . $tz_string . $this->eol;

		// Emit VTIMEZONE for RFC 5545 compliance (required by Outlook, Thunderbird, etc.).
		$ics .= $this->generate_vtimezone( $tz_string );

		// Set the ics appointment data.
		foreach ( $this->appointments as $appointment ) {
			$ics_appointment = $this->ics_appointment( $appointment );
			// Loop through ics data.
			foreach ( $ics_appointment as $ics_data ) {
				#error_log( var_export( $ics_data, true ) );
				$ics .= $ics_data . $this->eol;
			}
		}

		$ics .= 'END:VCALENDAR';

		return apply_filters( 'wc_appointments_ics_exporter', $ics, $this );
	}

	/**
	 * Generate the appointment ICS data.
	 *
	 * Builds the VEVENT content for a single appointment.
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 * @return array<string, mixed> Array of ICS lines.
	 */
	protected function ics_appointment( $appointment ) {
		$sitename  = get_option( 'blogname' );
		$siteadmin = sanitize_email( (string) get_option( 'admin_email' ) );

		// Set the ics data.
		$tz_string      = wc_timezone_string();
		$ics_a          = [];
		$product        = $appointment->get_product();
		$product_title  = $product ? ' - ' . $product->get_title() : '';
		$url            = $appointment->get_order() ? $appointment->get_order()->get_view_order_url() : '';
		$summary        = '#' . $appointment->get_id() . $product_title;
		$description    = '';
		$date_prefix    = $appointment->is_all_day() ? ';VALUE=DATE:' : ';TZID=' . $tz_string . ':';
		$staff_names    = $appointment->get_staff_members( true );

		if ( $staff_names ) {
			// Real newlines: sanitize_string() turns them into ICS TEXT \n escapes.
			$description .= __( 'Staff', 'woocommerce-appointments' ) . ': ' . $staff_names . "\n\n";
		}

		if ( class_exists( 'WC_Appointments_Resource' ) ) {
			$resource_line = WC_Appointments_Resource::get_context_display( $appointment, true );
			if ( '' !== $resource_line ) {
				$description .= get_wc_appointment_data_label( 'resource', $appointment->get_product() ) . ': ' . $resource_line . "\n\n";
			}
		}

		$post_excerpt = $product ? get_post( $product->get_id() )->post_excerpt : '';

		if ( '' !== $post_excerpt ) {
			$description .= __( 'Appointment description:', 'woocommerce-appointments' ) . "\n";
			$description .= wp_kses( $post_excerpt, [] );
		}

		// Include add-ons information if available and export_addons is enabled.
		if ( $this->export_addons ) {
			$addons = $appointment->get_addons(
				[
					'before'       => '',
					'after'        => '',
					'separator'    => ', ',
					'echo'         => false,
					'autop'        => false,
					'label_before' => '',
					'label_after'  => ': ',
				]
			);

			if ( ! empty( $addons ) ) {
				$description .= "\n\n" . __( 'Add-ons:', 'woocommerce-appointments' ) . "\n";
				$description .= wp_strip_all_tags( $addons );
			}
		}

		$ics_a['begin_vevent'] = 'BEGIN:VEVENT';
		$ics_a['dtstart']      = 'DTSTART' . $date_prefix . $this->format_date( $appointment->get_start(), $appointment );
		$ics_a['dtend']        = 'DTEND' . $date_prefix . $this->format_date( $appointment->get_end(), $appointment );
		$ics_a['uid']          = 'UID:' . $this->uid_prefix . $appointment->get_id();
		$ics_a['dtstamp']      = 'DTSTAMP:' . $this->format_date_utc( time() );
		$ics_a['location']     = 'LOCATION:' . $this->sanitize_string(
			class_exists( 'WC_Appointments_Meetings' )
				? WC_Appointments_Meetings::get_calendar_location_field( $appointment )
				: $appointment->get_location_display()
		);
		$ics_a['description']  = 'DESCRIPTION:' . $this->sanitize_string( $description );
		$ics_a['url']          = 'URL;VALUE=URI:' . $this->sanitize_string( $url );
		$ics_a['summary']      = 'SUMMARY:' . $this->sanitize_string( $summary );
		$ics_a['organizer']    = 'ORGANIZER;CN="' . $this->sanitize_string( $sitename ) . '":mailto:' . $this->sanitize_string( $siteadmin );
		$ics_a['end_vevent']   = 'END:VEVENT';

		return apply_filters( 'wc_appointments_ics_appointment', $ics_a, $appointment, $this );
	}

	/**
	 * Export appointments to a file (interface implementation).
	 *
	 * @param array<int, mixed> $appointments Array of WC_Appointment objects; invalid entries are skipped.
	 * @param array<string, mixed>             $args         Optional export arguments (e.g., 'filename', 'export_addons').
	 * @return string|false File path on success, false on failure.
	 */
	public function export( array $appointments, array $args = [] ) {
		$filename = $args['filename'] ?? '';
		$this->export_addons = ! empty( $args['export_addons'] );
		return $this->get_ics( $appointments, $filename );
	}

	/**
	 * Get the export file format/mime type.
	 *
	 * @return string Format identifier.
	 */
	public function get_format(): string {
		return 'ics';
	}

	/**
	 * Get the file extension for this exporter.
	 *
	 * @return string File extension.
	 */
	public function get_file_extension(): string {
		return '.ics';
	}
}
