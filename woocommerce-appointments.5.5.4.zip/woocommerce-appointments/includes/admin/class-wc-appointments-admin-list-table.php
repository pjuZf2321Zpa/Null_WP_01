<?php
/**
 * Admin functions for the appointments post type
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

if ( class_exists( 'WC_Appointments_Admin_List_Table', false ) ) {
	return;
}

if ( ! class_exists( 'WC_Admin_List_Table', false ) ) {
	include_once WC_ABSPATH . 'includes/admin/list-tables/abstract-class-wc-admin-list-table.php';
}

/**
 * WC_Appointments_Admin_List_Table Class.
 */
class WC_Appointments_Admin_List_Table extends WC_Admin_List_Table {

	/**
	 * Post type.
	 *
	 * @var string
	 */
	protected $list_table_type = 'wc_appointment';

	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct();
		add_filter( 'disable_months_dropdown', '__return_true' );
		add_action( 'parse_query', [ $this, 'appointment_filters_query' ] );
		add_action( 'parse_query', [ $this, 'search_custom_fields' ] );
		add_filter( 'get_search_query', [ $this, 'search_label' ] );
		add_filter( 'views_edit-wc_appointment', [ $this, 'appointment_views' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_list_table_assets' ] );
		add_action( 'admin_notices', [ $this, 'bulk_admin_notices' ], 10, 0 );
		add_action( 'current_screen', [ $this, 'maybe_hide_location_resource_columns' ] );
	}

	/**
	 * One-time: hide Location / Resources for users who saved Screen Options before those defaults existed.
	 *
	 * `default_hidden_columns` only applies when the user has no saved preference. After this runs once,
	 * Screen Options can still re-enable the columns.
	 *
	 * @param WP_Screen|null $screen Current screen.
	 */
	public function maybe_hide_location_resource_columns( $screen = null ): void {
		if ( ! $screen || 'edit-wc_appointment' !== $screen->id ) {
			return;
		}
		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return;
		}
		$flag = 'wca_list_hide_loc_res_v1';
		if ( get_user_meta( $user_id, $flag, true ) ) {
			return;
		}
		$option = 'manageedit-wc_appointmentcolumnshidden';
		$hidden = get_user_option( $option, $user_id );
		if ( is_array( $hidden ) ) {
			$hidden = array_values(
				array_unique(
					array_merge(
						$hidden,
						[ 'appointment_location', 'appointment_resources' ]
					)
				)
			);
			update_user_option( $user_id, $option, $hidden, true );
		}
		update_user_meta( $user_id, $flag, '1' );
	}

	/**
	 * Render blank state.
	 * @return void
	 */
	protected function render_blank_state() {
		$user_id    = get_current_user_id();
		$is_staff   = class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $user_id );
		$can_create = ! $is_staff || WC_Appointments_Staff_Permissions::can( $user_id, 'create_appointments' );

		echo '<div class="woocommerce-BlankState">';

		echo '<h2 class="woocommerce-BlankState-message">';
		if ( $is_staff ) {
			echo esc_html__( 'No appointments found.', 'woocommerce-appointments' );
		} else {
			echo esc_html__( 'Ready to start accepting appointments?', 'woocommerce-appointments' );
		}
		echo '</h2>';

		echo '<div class="woocommerce-BlankState-buttons">';

		if ( $can_create ) {
			printf(
			    '<a class="woocommerce-BlankState-cta button-primary button" href="%1$s">%2$s</a>',
			    esc_url( admin_url( 'edit.php?post_type=wc_appointment&page=add_appointment' ) ),
			    esc_html__( 'Add New Appointment', 'woocommerce-appointments' ),
			);
		}

		// Only show Add Product for non-staff users.
		if ( ! $is_staff ) {
			printf(
			    '<a class="woocommerce-BlankState-cta button" href="%1$s">%2$s</a>',
			    esc_url( admin_url( 'post-new.php?post_type=product&appointable_product=1' ) ),
			    esc_html__( 'Add Appointable Product', 'woocommerce-appointments' ),
			);
		}

		echo '</div>';

		echo '</div>';
	}

	/**
	 * Define primary column.
	 *
	 * @return string
	 */
	protected function get_primary_column(): string {
		return 'appointment_id';
	}

	/**
	 * Get row actions to show in the list table.
	 *
	 * @param array<string, string> $actions Array of actions.
	 * @param WP_Post $post Current post object.
	 * @return array<string, mixed>
	 */
	protected function get_row_actions( $actions, $post ) {
		// Remove quick edit.
		unset( $actions['inline hide-if-no-js'] );
		return array_merge(
		    [
				/* translators: %d: product ID. */
				'id' => sprintf( __( 'ID: %d', 'woocommerce-appointments' ), $post->ID ),
			],
		    $actions,
		);
	}

	/**
	 * Define hidden columns.
	 *
	 * @return list<string>
	 */
	protected function define_hidden_columns() {
		return [
			'addons',
			'appointment_location',
			'appointment_resources',
		];
	}

	/**
	 * Define which columns are sortable.
	 *
	 * @param array<string, string> $columns Existing columns.
	 * @return array<string, mixed>
	 */
	public function define_sortable_columns( $columns ) {
		$custom = [
			'appointment_id'   => 'appointment_id',
			'appointment_when' => 'appointment_when',
		];
		return wp_parse_args( $custom, $columns );
	}

	/**
	 * Define which columns to show on this screen.
	 *
	 * @param array<string, string> $columns Existing columns.
	 * @return array<string, mixed>
	 */
	public function define_columns( $columns ) {
		if ( empty( $columns ) ) {
			$columns = [];
		}

		unset( $columns['title'], $columns['comments'], $columns['date'] );

		$show_columns                        = [];
		$show_columns['cb']                  = '<input type="checkbox" />';
		$show_columns['appointment_id']      = __( 'Appointment', 'woocommerce-appointments' );
		$timezone_abbr = class_exists( 'WC_Appointments_Timezone_Helper' )
			? WC_Appointments_Timezone_Helper::build_timezone_indicator_html( WC_Appointments_Timezone_Helper::get_admin_user_timezone() )
			: '';
		$show_columns['appointment_when']    = __( 'When', 'woocommerce-appointments' ) . $timezone_abbr;
		$show_columns['scheduled_product']   = __( 'Product', 'woocommerce-appointments' );
		$show_columns['addons']              = __( 'Add-ons', 'woocommerce-appointments' );
		$show_columns['scheduled_staff']       = __( 'Staff', 'woocommerce-appointments' );
		$show_columns['appointment_location']  = __( 'Location', 'woocommerce-appointments' );
		$show_columns['appointment_resources'] = __( 'Resources', 'woocommerce-appointments' );
		$show_columns['appointment_actions']   = __( 'Actions', 'woocommerce-appointments' );

		return array_merge( $show_columns, $columns );
	}

	/**
	 * Pre-fetch any data for the row each column has access to it. the_product global is there for bw compat.
	 *
	 * @param int $post_id Post ID being shown.
	 * @return void
	 */
	protected function prepare_row_data( $post_id ) {
		global $the_appointment;

		if ( empty( $this->object ) || $this->object->get_id() !== $post_id ) {
			$the_appointment = get_wc_appointment( $post_id );
			$this->object    = $the_appointment;
		}
	}

	/**
	 * Render columm: appointment_id.
	 * @return void
	 */
	protected function render_appointment_id_column() {
		$customer = $this->object->get_order() ? $this->object->get_customer( $this->object->get_order() ) : $this->object->get_customer();
		$buyer    = $customer->full_name;

		/**
		 * Filter buyer name in list table appointments.
		 *
		 * @since 4.7.6
		 * @param string         $buyer       Buyer name.
		 * @param WC_Appointment $appointment Appointment data.
		 */
		$buyer = apply_filters( 'woocommerce_appointments_admin_buyer_name', $buyer, $this->object );

		printf(
		    '<a href="%s"><strong>%s</strong></a> - <mark class="appointment-status status-%s"><span>%s</span></mark>',
		    esc_url( admin_url( 'post.php?post=' . $this->object->get_id() . '&action=edit' ) ),
		    esc_attr( $buyer ),
		    esc_attr( $this->object->get_status() ),
		    esc_attr( wc_appointments_get_status_label( $this->object->get_status() ) ),
		);
		// Order.
		if ( $this->object->get_order() ) {
			// Check if current user can view orders
			$user_id = get_current_user_id();
			$can_view_orders = ! class_exists( 'WC_Appointments_Staff_Permissions' ) || 
							  ! WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) || 
							  WC_Appointments_Staff_Permissions::can( $user_id, 'view_orders' );

			if ( $can_view_orders ) {
				printf(
					/* translators: %2$s: order number */
					'<br /><a href="%1$s">' . esc_html__( 'Order #%2$s', 'woocommerce-appointments' ) . '</a> - %3$s',
					esc_url( $this->object->get_order()->get_edit_order_url() ),
					esc_attr( $this->object->get_order()->get_order_number() ),
					esc_attr( wc_get_order_status_name( $this->object->get_order()->get_status() ) ),
				);
			} else {
				// Show order info as text without link for staff without permission
				printf(
					/* translators: %2$s: order number */
					'<br />' . esc_html__( 'Order #%2$s', 'woocommerce-appointments' ) . ' - %3$s',
					'', // No URL
					esc_attr( $this->object->get_order()->get_order_number() ),
					esc_attr( wc_get_order_status_name( $this->object->get_order()->get_status() ) ),
				);
			}
		}
	}

	/**
	 * Render columm: appointment_when.
	 * @return void
	 */
	protected function render_appointment_when_column() {
		// Get the start timestamp.
		$start_timestamp = $this->object->get_start();

		// Format start date/time in admin user's timezone if they have a different timezone set (and timezone display is enabled).
		if ( class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) && WC_Appointments_Timezone_Helper::admin_has_different_timezone() ) {
			// Display in admin's timezone without timezone indicator.
			$formatted_start = WC_Appointments_Timezone_Helper::format_for_admin_display(
				$start_timestamp,
				wc_appointments_date_format(),
				$this->object->is_all_day() ? '' : ', ' . wc_appointments_time_format(),
				false // Don't show TZ indicator - it's now in the column header.
			);
			echo esc_html( $formatted_start );
		} else {
			// Display in site timezone (default behavior) without timezone indicator.
			echo esc_html( $this->object->get_start_date() );
		}

		// Duration.
		printf(
		    '<span class="description">%1$s</span>',
		    esc_attr( $this->object->get_duration() ),
		);

		$series_hint = $this->get_appointment_series_list_hint( $this->object );
		if ( $series_hint ) {
			WC_Appointment_Series_Admin::echo_list_hint_markup( $series_hint );
		}
	}

	/**
	 * Recurring package hint for the appointments list (count + hover title).
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return array{count: string, title: string}|null Null when not part of a series.
	 */
	protected function get_appointment_series_list_hint( $appointment ) {
		return WC_Appointment_Series_Admin::get_list_hint( $appointment );
	}

	/**
	 * Render columm: scheduled_product.
	 * @return void
	 */
	protected function render_scheduled_product_column() {
		$product = $this->object->get_product();
		if ( ! $product ) {
			echo '–';
			return;
		}
		echo $this->maybe_linked_title( $product->get_title(), (int) $product->get_id(), 'manage_products' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in helper.
		printf(
			' <div class="view"><small class="times">×</small> %d</div>',
			absint( $this->object->get_qty() ) ?: 1
		);
	}

	/**
	 * Render columm: addons.
	 * @return void
	 */
	protected function render_addons_column() {
		$addons = $this->object->get_addons();
		if ( $addons ) {
			echo $addons; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo '–';
		}
	}

	/**
	 * Render columm: scheduled_staff.
	 * @return void
	 */
	protected function render_scheduled_staff_column() {
		$staff = $this->object->get_staff_members( true, true );
		if ( $staff ) {
			echo $staff; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo '–';
		}
	}

	/**
	 * Render column: appointment_location.
	 * @return void
	 */
	protected function render_appointment_location_column() {
		$snapshot = $this->object->get_location();
		$title    = isset( $snapshot['title'] ) ? trim( (string) $snapshot['title'] ) : '';
		if ( '' === $title ) {
			echo '-';
			return;
		}
		echo $this->maybe_linked_title( $title, (int) $this->object->get_location_id(), 'manage_locations' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in helper.
	}

	/**
	 * Render column: appointment_resources.
	 * @return void
	 */
	protected function render_appointment_resources_column() {
		$allocs = $this->object->get_resource_allocations();
		if ( ! is_array( $allocs ) || [] === $allocs ) {
			echo '-';
			return;
		}
		$parts = [];
		foreach ( $allocs as $alloc ) {
			$title = isset( $alloc['title'] ) ? trim( (string) $alloc['title'] ) : '';
			$rid   = (int) ( $alloc['resource_id'] ?? 0 );
			if ( '' === $title ) {
				continue;
			}
			$parts[] = $this->maybe_linked_title( $title, $rid, 'manage_resources' );
		}
		echo [] !== $parts ? implode( ', ', $parts ) : '-'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in helper.
	}

	/**
	 * Plain title, or edit link when the current user has the staff permission.
	 *
	 * @param string $title      Label.
	 * @param int    $post_id    Target post ID.
	 * @param string $permission Staff permission key.
	 * @return string Escaped HTML.
	 */
	private function maybe_linked_title( string $title, int $post_id, string $permission ): string {
		static $can = [];
		if ( ! isset( $can[ $permission ] ) ) {
			$can[ $permission ] = WC_Appointments_Staff_Permissions::can( get_current_user_id(), $permission );
		}
		if ( $post_id && $can[ $permission ] ) {
			return '<a href="' . esc_url( admin_url( 'post.php?post=' . $post_id . '&action=edit' ) ) . '">' . esc_html( $title ) . '</a>';
		}
		return esc_html( $title );
	}

	/**
	 * Render columm: appointment_actions.
	 * @return void
	 */
	protected function render_appointment_actions_column() {
		echo '<p>';
		$panel_enabled = (bool) apply_filters( 'wc_appointments_admin_panel_enabled', true );
		$actions = [
			'view' => [
				'url'    => admin_url( 'post.php?post=' . $this->object->get_id() . '&action=edit' ),
				'name'   => __( 'View', 'woocommerce-appointments' ),
				'action' => 'view',
			],
		];

		if ( $this->object->has_status( [ 'pending-confirmation' ] ) ) {
			$actions['confirm'] = [
				'url'    => wp_nonce_url(
				    admin_url( 'admin-ajax.php?action=wc-appointment-confirm&appointment_id=' . $this->object->get_id() ),
				    'wc-appointment-confirm',
				),
				'name'   => __( 'Confirm', 'woocommerce-appointments' ),
				'action' => 'confirm',
			];
		}

		$actions = apply_filters( 'woocommerce_admin_appointment_actions', $actions, $this->object );

		foreach ( $actions as $action ) {
			$extra_attrs = '';
			if ( $panel_enabled && 'view' === $action['action'] ) {
				$extra_attrs = ' data-wca-panel-view="' . esc_attr( $this->object->get_id() ) . '"';
			}
			printf(
			    '<a class="button tips %s" href="%s" data-tip="%s"%s>%s</a>',
			    esc_attr( $action['action'] ),
			    esc_url( $action['url'] ),
			    wc_sanitize_tooltip( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					$action['name'],
			    ),
			    $extra_attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			    esc_attr( $action['name'] ),
			);
		}
		echo '</p>';
	}

	/**
	 * Handle any custom filters.
	 *
	 * @param array<string, mixed> $query_vars Query vars.
	 * @return array<string, mixed>
	 */
	protected function query_filters( $query_vars ) {
		// Custom order by arguments.
		if ( isset( $query_vars['orderby'] ) ) {
			$orderby = strtolower( $query_vars['orderby'] );
			$order   = isset( $query_vars['order'] ) ? strtoupper( $query_vars['order'] ) : 'DESC';

			if ( 'id' === $orderby ) {
				$query_vars = array_merge(
				    $query_vars,
				    [
						'orderby' => 'ID',
					],
				);
			}

			if ( 'appointment_when' === $orderby ) {
				// @codingStandardsIgnoreStart
				$query_vars = array_merge(
				    $query_vars,
				    [
						'meta_key' => '_appointment_start',
						'orderby'  => 'meta_value_num',
					],
				);
				// @codingStandardsIgnoreEnd
			}
		}

		return $query_vars;
	}

	/**
	 * Render any custom filters and search inputs for the list table.
	 * @return void
	 */
	protected function render_filters() {
		$filters = apply_filters(
		    'woocommerce_appointments_admin_list_table_filters',
		    [
				'appointment_dates'    => [ $this, 'render_appointment_dates_filter' ],
				'appointment_product'  => [ $this, 'render_appointment_product_filter' ],
				'appointment_staff'    => [ $this, 'render_appointment_staff_filter' ],
				'appointment_customer' => [ $this, 'render_appointment_customer_filter' ],
			],
		);

		ob_start();
		foreach ( $filters as $filter_callback ) {
			call_user_func( $filter_callback );
		}
		$output = ob_get_clean();

		echo apply_filters( 'woocommerce_appointment_filters', $output ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Filter output built from escaped admin filter markup.
	}

	/**
	 * Render the appointment from/end dates filter for the list table.
	 *
	 * @since 4.7.0
	 * @return void
	 */
	protected function render_appointment_dates_filter() {
		$date_from           = sanitize_text_field( (string) filter_input( INPUT_GET, 'date_from' ) );
		$date_from_formatted = $date_from ? date( 'Y-m-d', strtotime( $date_from ) ) : '';
		$date_to             = sanitize_text_field( (string) filter_input( INPUT_GET, 'date_to' ) );
		$date_to_formatted   = $date_to ? date( 'Y-m-d', strtotime( $date_to ) ) : '';
		?>
		<div class="alignleft">
			<div class="date_filter">
				<input type="search" name="date_from" class="date_from date-picker" value="<?php echo esc_attr( $date_from_formatted ); ?>" placeholder="<?php esc_attr_e( 'Start Date', 'woocommerce-appointments' ); ?>" autocomplete="off" />
			</div>
			<div class="date_filter">
				<input type="search" name="date_to" class="date_to date-picker" value="<?php echo esc_attr( $date_to_formatted ); ?>" placeholder="<?php esc_attr_e( 'End Date', 'woocommerce-appointments' ); ?>" autocomplete="off" />
			</div>
		</div>
		<?php
	}

	/**
	 * Render the appointment product filter for the list table.
	 *
	 * @since 4.7.0
	 * @return void
	 */
	protected function render_appointment_product_filter() {
		$product_id = absint( filter_input( INPUT_GET, 'filter_product' ) );
		$product    = $product_id ? get_wc_product_appointment( $product_id ) : false;
		?>
		<div class="alignleft">
			<select class="wc-product-search" name="filter_product" style="width: 200px;" data-allow_clear="true" data-placeholder="<?php esc_attr_e( 'Filter by product', 'woocommerce-appointments' ); ?>" data-action="woocommerce_json_search_appointable_products">
				<?php if ( $product ) : ?>
					<option value="<?php echo esc_attr( $product->get_id() ); ?>" selected="selected"><?php echo esc_html( $product->get_title() ); ?></option>
				<?php endif; ?>
			</select>
		</div>
		<?php
	}

	/**
	 * Render the appointment staff filter for the list table.
	 *
	 * @since 4.7.0
	 * @return void
	 */
	protected function render_appointment_staff_filter() {
		if ( ! current_user_can( 'manage_others_appointments' ) ) {
			return;
		}
		$staff_array = [];

		foreach ( WC_Appointments_Admin::get_appointment_staff() as $staff_member ) {
			$staff_array[ $staff_member->ID ] = $staff_member->display_name;
		}

		if ( [] !== $staff_array ) {
			$requested_staff = wc_clean( (string) filter_input( INPUT_GET, 'filter_staff' ) );
			?>
			<select name="filter_staff">
				<option value=""><?php esc_html_e( 'All Staff', 'woocommerce-appointments' ); ?></option>
				<option<?php selected( '–', $requested_staff ); ?> value="–">–</option>
				<?php foreach ( $staff_array as $filter_id => $filter ) { ?>
					<option<?php selected( $filter_id, $requested_staff ); ?> value="<?php echo esc_attr( absint( $filter_id ) ); ?>"><?php echo esc_html( $filter ); ?></option>
				<?php } ?>
			</select>
			<?php
		}
	}

	/**
	 * Filter the products in admin based on options
	 *
	 * @param mixed $query
	 */
	public function appointment_filters_query( $query ): void {
		global $typenow, $wp_query;

		// Get current screen.
		$screen    = function_exists( 'get_current_screen' ) ? get_current_screen() : '';
		$screen_id = $screen ? $screen->id : '';

		if ( $this->list_table_type === $typenow ) {
			$meta_query = [];

			// Only show appointments applicable to current staff member (Assigned OR Created).
			if ( ! current_user_can( 'manage_others_appointments' ) && 'edit-wc_appointment' === $screen_id ) {
				$current_user_id = get_current_user_id();
				$meta_query[] = [
					'relation' => 'OR',
					[
						'key'     => '_appointment_staff_id',
						'value'   => $current_user_id,
						'compare' => '=', // WP_Query handles single value vs array automatically
					],
					[
						'key'     => '_appointment_author',
						'value'   => $current_user_id,
						'compare' => '=',
					],
				];
			}

			// Date filters.
			$get_date_from             = sanitize_text_field( (string) filter_input( INPUT_GET, 'date_from' ) );
			$get_date_to               = sanitize_text_field( (string) filter_input( INPUT_GET, 'date_to' ) );
			$get_filter_product        = absint( filter_input( INPUT_GET, 'filter_product' ) );
			$get_filter_staff          = (string) filter_input( INPUT_GET, 'filter_staff' );
			$get_filter_customer       = absint( filter_input( INPUT_GET, 'filter_customer' ) );
			$get_filter_customer_email = sanitize_email( (string) filter_input( INPUT_GET, 'filter_customer_email' ) );
			$get_wca_recurring         = (string) filter_input( INPUT_GET, 'wca_recurring' );

			if ( $get_date_from && empty( $query->query_vars['suppress_filters'] ) ) {
				$meta_query[] = [
					'key'     => '_appointment_start',
					'value'   => esc_sql( date( 'YmdHis', strtotime( wc_clean( $get_date_from ) ) ) ),
					'compare' => '>=',
				];
			}
			if ( $get_date_to && empty( $query->query_vars['suppress_filters'] ) ) {
				$meta_query[] = [
					'key'     => '_appointment_end',
					'value'   => esc_sql( date( 'YmdHis', strtotime( wc_clean( $get_date_to ) ) ) ),
					'compare' => '<',
				];
			}

			if ( $get_filter_product && empty( $query->query_vars['suppress_filters'] ) ) {
				$meta_query[] = [
					'key'   => '_appointment_product_id',
					'value' => $get_filter_product,
				];
			}
			if ( '' !== $get_filter_staff && empty( $query->query_vars['suppress_filters'] ) ) {
				if ( '–' === $get_filter_staff ) {
					$meta_query[] = [
						'key'     => '_appointment_staff_id',
						'compare' => 'NOT EXISTS',
					];
				} else {
					$meta_query[] = [
						'key'   => '_appointment_staff_id',
						'value' => absint( $get_filter_staff ),
					];
				}
			}

			if ( $get_filter_customer && empty( $query->query_vars['suppress_filters'] ) ) {
				$meta_query[] = [
					'key'   => '_appointment_customer_id',
					'value' => $get_filter_customer,
				];
			}

			if ( '' !== $get_wca_recurring && empty( $query->query_vars['suppress_filters'] ) ) {
				$meta_query[] = [
					'key'     => '_wca_series_id',
					'value'   => 0,
					'compare' => '>',
					'type'    => 'NUMERIC',
				];
			}

			if ( $get_filter_customer_email && empty( $query->query_vars['suppress_filters'] ) ) {
				$guest_appointment_ids = $this->get_appointment_ids_by_customer_email( $get_filter_customer_email );
				if ( ! empty( $guest_appointment_ids ) ) {
					$query->query_vars['post__in'] = $guest_appointment_ids;
				} else {
					$query->query_vars['post__in'] = [ 0 ];
				}
			}

			if ( ! empty( $meta_query ) ) {
				$query->query_vars['meta_query'] = [
					'relation' => 'AND',
					$meta_query,
				];
			}

			#echo '<pre>' . var_export( $meta_query, true ) . '</pre>';
		}
	}

	/**
	 * Search custom fields
	 *
	 * @param mixed $wp
     *
     * @return void
	 */
	public function search_custom_fields( $wp ) {
		global $pagenow, $wpdb;

		if ( 'edit.php' !== $pagenow || empty( $wp->query_vars['s'] ) || $this->list_table_type !== $wp->query_vars['post_type'] ) {
			return;
		}

		$appointment_ids = [];
		$search_raw = sanitize_text_field( (string) filter_input( INPUT_GET, 's' ) );
		$term       = '' !== $search_raw ? wc_clean( $search_raw ) : [];

		if ( is_numeric( $term ) ) {
			$appointment_ids[] = $term;
		}

		$order_ids       = wc_order_search( $term );
		$appointment_ids = array_merge(
		    $appointment_ids,
		    $order_ids ? WC_Appointment_Data_Store::get_appointment_ids_from_order_id( $order_ids ) : [ 0 ],
		    wc_appointment_search( $term ),
		);

		$wp->query_vars['s']                  = false;
		$wp->query_vars['post__in']           = $appointment_ids;
		$wp->query_vars['appointment_search'] = true;
	}

	/**
	 * Change views on the edit appointment screen.
	 *
	 * @param array<string, string> $views Array of views.
	 * @return array<string, mixed>
	 */
	public function appointment_views( $views ) {
		// Appointments do not have authors.
		unset( $views['mine'] );

		// Build extra query string to preserve active customer filters across status links.
		$preserved_params = '';
		$get_filter_customer       = absint( filter_input( INPUT_GET, 'filter_customer' ) );
		$get_filter_customer_email = sanitize_email( (string) filter_input( INPUT_GET, 'filter_customer_email' ) );
		$get_wca_recurring         = (string) filter_input( INPUT_GET, 'wca_recurring' );

		if ( $get_filter_customer ) {
			$preserved_params .= '&filter_customer=' . $get_filter_customer;
		}
		if ( $get_filter_customer_email ) {
			$preserved_params .= '&filter_customer_email=' . rawurlencode( $get_filter_customer_email );
		}
		if ( '' !== $get_wca_recurring ) {
			$preserved_params .= '&wca_recurring=1';
		}

		// Appointment status sorting links for staff members
		// who cannot manage other appointments.
		if ( ! current_user_can( 'manage_others_appointments' ) ) {
			$views     = []; // empty default views
			$edit_link = '<a href="edit.php?post_type=wc_appointment' . $preserved_params . '&%s" %s>%s</a>';
			$class     = '';
			$staff_id  = get_current_user_id();
			$get_post_status = (string) filter_input( INPUT_GET, 'post_status' );
			if ( '' === $get_post_status ) {
				$class = 'class="current"';
			}
			$views['all'] = sprintf( $edit_link, '', $class, __( 'All', 'woocommerce-appointments' ) );
			// get all appointments statuses there are
			$appointments_statuses = get_wc_appointment_statuses( 'user', true );
			foreach ( $appointments_statuses as $appointment_status => $appointment_status_name ) {
				$class = '' !== $get_post_status && $appointment_status === $get_post_status ? 'class="current"' : '';
				$views[ $appointment_status ] = sprintf( $edit_link, 'post_status=' . $appointment_status, $class, $appointment_status_name );
			}
		} elseif ( $preserved_params ) {
			// For admins with customer filter active, rebuild views to preserve filter params.
			foreach ( $views as $key => $view ) {
				$views[ $key ] = preg_replace(
					'/href="([^"]*)"/',
					'href="$1' . esc_attr( $preserved_params ) . '"',
					$view
				);
			}
		}

		if ( class_exists( 'WC_Appointment_Series_Events' ) && WC_Appointment_Series_Events::is_enabled() ) {
			$recurring_count = $this->count_recurring_appointments();
			$class           = '' !== (string) filter_input( INPUT_GET, 'wca_recurring' ) ? 'current' : '';
			$views['wca_recurring'] = sprintf(
				'<a href="%s" class="%s">%s <span class="count">(%s)</span></a>',
				esc_url( admin_url( 'edit.php?post_type=wc_appointment&wca_recurring=1' ) ),
				esc_attr( $class ),
				esc_html__( 'Recurring', 'woocommerce-appointments' ),
				esc_html( number_format_i18n( $recurring_count ) )
			);
		}

		return $views;
	}

	/**
	 * Count appointments that belong to a recurring package.
	 *
	 * @return int
	 */
	protected function count_recurring_appointments() {
		$query = new WP_Query(
			[
				'post_type'      => 'wc_appointment',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				'meta_query'     => [
					[
						'key'     => '_wca_series_id',
						'value'   => 0,
						'compare' => '>',
						'type'    => 'NUMERIC',
					],
				],
			]
		);

		return (int) $query->found_posts;
	}

	/**
	 * Change the label when searching appointments.
	 *
	 * @param string $query Search Query.
	 * @return string
	 */
	public function search_label( $query ) {
		global $pagenow, $typenow;

		if ( 'edit.php' !== $pagenow || 'wc_appointment' !== $typenow || ! get_query_var( 'appointment_search' ) || null === filter_input( INPUT_GET, 's' ) ) {
			return $query;
		}

		return wc_clean( sanitize_text_field( (string) filter_input( INPUT_GET, 's' ) ) );
	}

	/**
	 * Remove edit from the bulk actions.
	 *
	 * @param mixed $actions
	 * @return array<string, mixed>
	 */
	public function define_bulk_actions( $actions ) {
		if ( isset( $actions['edit'] ) ) {
			unset( $actions['edit'] );
		}

		return $actions;
	}

	/**
	 * Handle bulk actions.
	 *
	 * @param  string $redirect_to URL to redirect to.
	 * @param  string $action      Action name.
	 * @param list<int>  $ids         List of ids.
     *
	 * @return string|void
	 */
	public function handle_bulk_actions( $redirect_to, $action, $ids ) {
		// Check staff-specific permissions for bulk actions.
		$user_id = get_current_user_id();
		if ( class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
			// Cancel action requires cancel_appointments permission.
			if ( 'cancel_appointments' === $action && ! WC_Appointments_Staff_Permissions::can( $user_id, 'cancel_appointments' ) ) {
				return;
			}
			// All other status changes require manage_appointment_status permission.
			$status_actions = [ 'confirm_appointments', 'unconfirm_appointments', 'mark_paid_appointments', 'mark_unpaid_appointments' ];
			if ( in_array( $action, $status_actions, true ) && ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_appointment_status' ) ) {
				return;
			}
		}

		switch ( $action ) {
			case 'confirm_appointments':
				$new_status    = WC_Appointments_Constants::STATUS_CONFIRMED;
				$report_action = 'appointments_confirmed';
				break;
			case 'unconfirm_appointments':
				$new_status    = 'pending-confirmation';
				$report_action = 'appointments_unconfirmed';
				break;
			case 'mark_paid_appointments':
				$new_status    = 'paid';
				$report_action = 'appointments_marked_paid';
				break;
			case 'mark_unpaid_appointments':
				$new_status    = 'unpaid';
				$report_action = 'appointments_marked_unpaid';
				break;
			case 'cancel_appointments':
				$new_status    = 'cancelled';
				$report_action = 'appointments_cancelled';
				break;
			default:
				return;
		}

		$changed = 0;

		foreach ( $ids as $id ) {
			$id = absint( $id );
			if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			$appointment = get_wc_appointment( $id );
			if ( ! $appointment || $appointment->get_status() === $new_status ) {
				continue;
			}
			$appointment->update_status( $new_status );
			$changed++;
		}

		$sendback = add_query_arg(
		    [
				'post_type'    => $this->list_table_type,
				$report_action => true,
				'changed'      => $changed,
				'ids'          => implode( ',', $ids ),
			],
		    '',
		);

		return esc_url_raw( $sendback );
	}

	/**
	 * Enqueue list table assets (JS + localized data).
	 *
	 * Registers and enqueues the admin-list-table script with localized
	 * parameters for customer filter subtitle and bulk action options.
	 *
	 * @since 5.2.0
	 */
	public function enqueue_list_table_assets(): void {
		global $post_type, $pagenow;

		// Bail out if not on wc_appointment list page.
		if ( 'edit.php' !== $pagenow || 'wc_appointment' !== $post_type ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script( 'wc_appointments_writepanel_js' );
		wp_enqueue_script(
			'wca_admin_list_table_js',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/admin-list-table' . $suffix . '.js',
			[],
			WC_APPOINTMENTS_VERSION,
			true
		);

		wp_localize_script( 'wca_admin_list_table_js', 'wca_list_table_params', $this->get_list_table_params() );

		// Enqueue panel scripts on list table page when the panel feature is enabled.
		// Delegated to the centralised WC_Appointments_Admin_Panel class.
		require_once __DIR__ . '/class-wc-appointments-admin-panel.php';
		if ( WC_Appointments_Admin_Panel::is_enabled() ) {
			WC_Appointments_Admin_Panel::enqueue_standalone( $suffix );
		}
	}

	/**
	 * Build localized parameters for the list table JS.
	 *
	 * @since 5.2.0
	 * @return array<string, mixed>
	 */
	private function get_list_table_params(): array {
		$params = [
			'customer_filter_label'     => '',
			'customer_filter_text'      => '',
			'customer_filter_clear_url' => '',
			'customer_filter_clear_title' => esc_attr__( 'Clear customer filter', 'woocommerce-appointments' ),
			'bulk_actions'              => $this->get_bulk_action_options(),
		];

		// Customer filter subtitle data.
		$customer_id    = absint( filter_input( INPUT_GET, 'filter_customer' ) );
		$customer_email = sanitize_email( (string) filter_input( INPUT_GET, 'filter_customer_email' ) );

		if ( $customer_id || $customer_email ) {
			$customer_label = '';
			if ( $customer_id ) {
				$user           = get_userdata( $customer_id );
				/* translators: %d: customer user ID. */
				$customer_label = $user ? $user->display_name : sprintf( __( 'User #%d', 'woocommerce-appointments' ), $customer_id );
			} elseif ( $customer_email ) {
				$customer_label = $customer_email;
			}

			$params['customer_filter_label'] = $customer_label;
			$params['customer_filter_text']  = sprintf(
				/* translators: %s: customer name or email */
				__( 'Showing appointments for: %s', 'woocommerce-appointments' ),
				'<strong>' . esc_html( $customer_label ) . '</strong>'
			);
			$params['customer_filter_clear_url'] = esc_url( remove_query_arg( [ 'filter_customer', 'filter_customer_email' ] ) );
		}

		return $params;
	}

	/**
	 * Get bulk action options based on user permissions.
	 *
	 * @since 5.2.0
	 * @return array<string, mixed>
	 */
	private function get_bulk_action_options(): array {
		$user_id           = get_current_user_id();
		$is_staff          = class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $user_id );
		$can_manage_status = ! $is_staff || WC_Appointments_Staff_Permissions::can( $user_id, 'manage_appointment_status' );
		$can_cancel        = ! $is_staff || WC_Appointments_Staff_Permissions::can( $user_id, 'cancel_appointments' );

		$actions = [];

		if ( $can_manage_status ) {
			$actions[] = [ 'value' => 'confirm_appointments', 'label' => __( 'Confirm appointments', 'woocommerce-appointments' ) ];
			$actions[] = [ 'value' => 'unconfirm_appointments', 'label' => __( 'Unconfirm appointments', 'woocommerce-appointments' ) ];
			$actions[] = [ 'value' => 'mark_paid_appointments', 'label' => __( 'Mark appointments as paid', 'woocommerce-appointments' ) ];
			$actions[] = [ 'value' => 'mark_unpaid_appointments', 'label' => __( 'Mark appointments as unpaid', 'woocommerce-appointments' ) ];
		}

		if ( $can_cancel ) {
			$actions[] = [ 'value' => 'cancel_appointments', 'label' => __( 'Cancel appointments', 'woocommerce-appointments' ) ];
		}

		return $actions;
	}

	/**
	 * Get appointment IDs by customer email (for guest customers).
	 *
	 * Looks up orders by billing email, then finds appointments linked to those orders.
	 *
	 * @param string $email Customer email address.
	 * @return list<int> Appointment IDs.
	 */
	private function get_appointment_ids_by_customer_email( string $email ): array {
		$orders = wc_get_orders( [
			'billing_email' => $email,
			'limit'         => 100,
			'return'        => 'ids',
		] );

		if ( empty( $orders ) ) {
			return [];
		}

		$appointment_ids = [];
		foreach ( $orders as $order_id ) {
			$ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_id( (int) $order_id );
			if ( ! empty( $ids ) ) {
				$appointment_ids = array_merge( $appointment_ids, (array) $ids );
			}
		}

		return array_unique( array_filter( $appointment_ids ) );
	}

	/**
	 * Render hidden inputs for customer filter persistence.
	 *
	 * Outputs hidden form fields so the customer filter is preserved
	 * when other filters (product, staff, dates) are applied via the form.
	 * The visual subtitle indicator is handled by admin-list-table.js.
	 *
	 * @since 5.2.0
	 * @return void
	 */
	protected function render_appointment_customer_filter() {
		$customer_id    = absint( filter_input( INPUT_GET, 'filter_customer' ) );
		$customer_email = sanitize_email( (string) filter_input( INPUT_GET, 'filter_customer_email' ) );

		if ( ! $customer_id && ! $customer_email ) {
			return;
		}
		?>
		<input type="hidden" name="filter_customer" value="<?php echo esc_attr( $customer_id ); ?>" />
		<input type="hidden" name="filter_customer_email" value="<?php echo esc_attr( $customer_email ); ?>" />
		<?php
	}

	/**
	 * Show confirmation message that order status changed for number of orders
	 */
	public function bulk_admin_notices(): void {
		global $post_type, $pagenow;

		// Bail out if not on wc_appointment list page.
		if ( 'edit.php' !== $pagenow || 'wc_appointment' !== $post_type ) {
			return;
		}

		if ( null !== filter_input( INPUT_GET, 'appointments_confirmed' )
			|| null !== filter_input( INPUT_GET, 'appointments_marked_paid' )
			|| null !== filter_input( INPUT_GET, 'appointments_marked_unpaid' )
			|| null !== filter_input( INPUT_GET, 'appointments_unconfirmed' )
			|| null !== filter_input( INPUT_GET, 'appointments_cancelled' )
		) {
			$number = absint( filter_input( INPUT_GET, 'changed' ) );

			$message = sprintf(
				/* translators: %s: number of appointment statuses changes in singular or plural */
				_n(
				    '%s appointment status change.',
				    '%s appointment status changes.',
				    number_format_i18n( $number ),
				    'woocommerce-appointments',
				),
			    number_format_i18n( $number ),
			);
			echo '<div class="updated"><p>' . $message . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
