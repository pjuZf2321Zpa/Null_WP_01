<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Settings
 */
class WC_Appointments_Admin_Settings extends WC_Settings_Page {

	// Gcal instance.
	public ?WC_Appointments_GCal $gcal = null;

	/**
	 * Setup settings class
	 *
	 * @since  1.0
	 */
	public function __construct() {
		// Appointments Settings ID.
		$this->id    = 'appointments';
		$this->label = __( 'Appointments', 'woocommerce-appointments' );

        add_action( 'woocommerce_admin_field_gcal_authorization', [ $this, 'gcal_authorization_setting' ], 10, 1 );
        add_action( 'woocommerce_admin_field_gcal_calendar_id', [ $this, 'gcal_calendar_id_setting' ], 10, 1 );
        add_action( 'woocommerce_admin_field_manual_sync', [ $this, 'manual_sync_setting' ], 10, 1 );

		// Indexing controls custom field.
		add_action( 'woocommerce_admin_field_indexing_controls', [ $this, 'indexing_controls_setting' ], 10, 0 );

		parent::__construct();
	}

	/**
	 * Get sections
	 *
	 * @return array<string, mixed>
	 */
	public function get_sections() {
		$sections = [
			''      => __( 'General', 'woocommerce-appointments' ),
			'gcal'  => __( 'Google Calendar', 'woocommerce-appointments' ),
			'index' => __( 'Indexing & Performance', 'woocommerce-appointments' ),
		];

		return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
	}

	/**
	 * Output the settings
	 *
	 * @since 1.0
	 */
	public function output(): void {
		global $current_section;

		if ( '' == $current_section ) {
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::output_fields( $settings );

			echo '<h2>' . esc_html__( 'Availability', 'woocommerce-appointments' ) . '</h2>';
			echo '<p class="wca-hub-deeplink-notice">';
			echo wp_kses_post(
				sprintf(
					/* translators: %s: Availability hub URL. "General" = default store availability rules (not a physical shop). */
					__( 'General hours, holidays, and synced busy times are managed in the <a href="%s">Availability</a> hub.', 'woocommerce-appointments' ),
					esc_url( WC_Appointments_Admin_Availability_Hub::url( 'global' ) )
				)
			);
			echo '</p>';
		} else {
			wp_enqueue_script( 'wc_appointments_writepanel_js' );
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::output_fields( $settings );
		}
	}

	/**
	 * Save settings
	 */
	public function save(): void {
		global $current_section;

		if ( '' == $current_section ) {
			// Save General settings fields.
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::save_fields( $settings );
		} else {
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::save_fields( $settings );
		}

		if ( $current_section ) {
			do_action( 'woocommerce_update_options_' . $this->id . '_' . $current_section );
		}
	}

	/**
	 * Get settings array.
	 *
	 * @param string $current_section Current section name.
	 * @return array<string, mixed>
	 */
	public function get_settings( $current_section = '' ) {
		$settings = [];
		if ( '' === $current_section ) {
			$settings = [
				[
					'title' => __( 'Timezone', 'woocommerce-appointments' ),
					'type'  => 'title',
					'desc'  => '',
					'id'    => 'wc_appointments_timezone_options',
				],
				[
					'title'    => __( 'Timezone Display', 'woocommerce-appointments' ),
					'desc'     => __( 'Control whether appointment times are converted and displayed in the user\'s local timezone.', 'woocommerce-appointments' ),
					'id'       => 'wc_appointments_timezone_display',
					'default'  => 'all',
					'type'     => 'select',
					'class'    => 'wc-enhanced-select',
					'options'  => [
						'all'      => __( 'Enabled everywhere', 'woocommerce-appointments' ),
						'frontend' => __( 'Frontend only (disable in admin)', 'woocommerce-appointments' ),
						'admin'    => __( 'Admin only (disable on frontend)', 'woocommerce-appointments' ),
						'disabled' => __( 'Disabled everywhere', 'woocommerce-appointments' ),
					],
					'desc_tip' => __( 'When enabled, appointment times are shown in each user\'s local timezone. When disabled, all times are shown in the site timezone. The woocommerce_appointments_show_timezone filter can override this setting.', 'woocommerce-appointments' ),
				],
				[
					'type' => 'sectionend',
					'id'   => 'wc_appointments_timezone_options',
				],
			];
			if ( WC_Appointments_Features::is_locations_resources_allowed() ) {
				$settings = array_merge(
					$settings,
					[
						[
							'title' => __( 'Experimental', 'woocommerce-appointments' ),
							'type'  => 'title',
							'desc'  => __( 'Features still under active testing. Enable only if you need them and are comfortable reporting issues.', 'woocommerce-appointments' ),
							'id'    => 'wc_appointments_experimental_options',
						],
						[
							'title'   => __( 'Locations & rooms (beta)', 'woocommerce-appointments' ),
							'desc'    => __( 'Enable locations and rooms for new bookings and admin (menus, product tabs, Availability hub).', 'woocommerce-appointments' ),
							'id'      => WC_Appointments_Features::OPTION_LOCATIONS_RESOURCES,
							'default' => 'no',
							'type'    => 'checkbox',
							'desc_tip' => __( 'Off by default while we validate with more shops. When off, products book without locations or rooms and related admin screens are hidden. Existing appointments still show the venue or room they were booked with. Product and location/room data stay saved so you can turn this back on.', 'woocommerce-appointments' ),
						],
						[
							'type' => 'sectionend',
							'id'   => 'wc_appointments_experimental_options',
						],
					]
				);
			}
		} elseif ( 'gcal' === $current_section ) {
			$settings = apply_filters(
			    'wc_appointments_gcal_settings',
			    [
					[
						'title' => __( 'Google Calendar Sync', 'woocommerce-appointments' ),
						'type'  => 'title',
						'desc'  => sprintf(
							/* translators: %s: link to google calendar sync tutorial */
							__( 'To use this integration go through %s instructions.', 'woocommerce-appointments' ),
						    '<a href="https://docs.bookingwp.com/appointments/setup/google-calendar" target="_blank">' . __( 'Google Calendar Integration', 'woocommerce-appointments' ) . '</a>',
						),
						'id'    => 'wc_appointments_gcal_options',
					],
					[
						'title'             => __( 'Client ID', 'woocommerce-appointments' ),
						'desc'              => __( 'Your Google Client ID.', 'woocommerce-appointments' ),
						'id'                => 'wc_appointments_gcal_client_id',
						'type'              => 'password',
						'class'             => 'password-input',
						'custom_attributes' => [
							'autocomplete' => 'off',
						],
						'default'           => '',
						'autoload'          => false,
						'desc_tip'          => true,
					],
					[
						'title'             => __( 'Client Secret', 'woocommerce-appointments' ),
						'desc'              => __( 'Your Google Client Secret.', 'woocommerce-appointments' ),
						'id'                => 'wc_appointments_gcal_client_secret',
						'type'              => 'password',
						'class'             => 'password-input',
						'custom_attributes' => [
							'autocomplete' => 'off',
						],
						'default'           => '',
						'autoload'          => false,
						'desc_tip'          => true,
					],
					[
						'title' => __( 'Authorization', 'woocommerce-appointments' ),
						'type'  => 'gcal_authorization',
					],
					[
						'title' => __( 'Calendar ID', 'woocommerce-appointments' ),
						'type'  => 'gcal_calendar_id',
						'id'    => 'wc_appointments_gcal_calendar_id',
					],
					'gcal_twoway' => [
						'title'    => __( 'Sync Preference', 'woocommerce-appointments' ),
						'desc'     => __( 'Choose the sync preference.', 'woocommerce-appointments' ),
						'options'  => [
							'one_way' => __( 'One way - from Store to Google', 'woocommerce-appointments' ),
							'two_way' => __( 'Two way - between Store and Google', 'woocommerce-appointments' ),
						],
						'id'       => 'wc_appointments_gcal_twoway',
						'default'  => 'one_way',
						'type'     => 'select',
						'class'    => 'wc-enhanced-select',
						'desc_tip' => true,
					],
					'manual_sync' => [
						'title' => __( 'Manual Sync', 'woocommerce-appointments' ),
						'type'  => 'manual_sync',
					],
					[
						'type' => 'sectionend',
						'id'   => 'gcal_twoway_options',
					],
					[
						'title' => __( 'Testing', 'woocommerce-appointments' ),
						'type'  => 'title',
						'desc'  => sprintf(
							/* translators: %s: log file name string */
							__( 'Log Google Calendar events, such as API requests, inside %s', 'woocommerce-appointments' ),
						    '<code>woocommerce/logs/' . $this->id . '-' . sanitize_file_name( wp_hash( $this->id ) ) . '.txt</code>',
						),
						'id'    => 'wc_appointments_gcal_testing',
					],
					[
						'title'   => __( 'Debug Log', 'woocommerce-appointments' ),
						'desc'    => __( 'Enable logging', 'woocommerce-appointments' ),
						'id'      => 'wc_appointments_gcal_debug',
						'default' => 'no',
						'type'    => 'checkbox',
					],
					[
						'type' => 'sectionend',
						'id'   => 'gcal_debug_options',
					],
				],
			);

			// Run Gcal oauth redirect.
			$gcal_integration_class = wc_appointments_gcal();

			// Reset to global context before checking the token.
			$gcal_integration_class->set_user_id( false );

			// Get access token.
			$access_token = $gcal_integration_class->get_access_token();

            // Get calendar ID.
            $calendar_id = get_option( 'wc_appointments_gcal_calendar_id' );

            // Stop here if not connected.
            if ( ! get_option( 'wc_appointments_gcal_refresh_token' ) || ! $calendar_id ) {
                unset( $settings['manual_sync'] );
            }

            if ( ! get_option( 'wc_appointments_gcal_refresh_token' ) ) {
                unset( $settings['gcal_twoway'] );
            }
		} elseif ( 'index' === $current_section ) {
			$settings = [
				[
					'title' => __( 'Indexing & Performance', 'woocommerce-appointments' ),
					'type'  => 'title',
					'desc'  => __( 'Configure indexed availability, caching horizon, and manual re-index for faster booking form performance.', 'woocommerce-appointments' ),
					'id'    => 'wc_appointments_indexing_options',
				],
				[
					'title'    => __( 'Use Indexed Availability', 'woocommerce-appointments' ),
					'desc'     => __( 'Enable high-performance availability checking.', 'woocommerce-appointments' ),
					'desc_tip' => __( 'Adds a database table that grows with booking volume and uses more disk space.', 'woocommerce-appointments' ),
					'id'       => 'wc_appointments_use_indexed_cache',
					'default'  => 'no',
					'type'     => 'checkbox',
				],
                'manual_reindex' => [
					'title' => __( 'Manual Re-index', 'woocommerce-appointments' ),
					'type'  => 'indexing_controls',
					'id'    => 'wc_appointments_indexing_controls',
				],
				[
					'title'    => __( 'Caching Horizon', 'woocommerce-appointments' ),
					'desc'     => __( 'How many months ahead to cache availability data for faster lookups.', 'woocommerce-appointments' ),
					'id'       => 'wc_appointments_cache_horizon_months',
					'default'  => '3',
					'type'     => 'select',
					'options'  => ( static function () {
						$options = [];
						for ( $months = 1; $months <= 12; $months++ ) {
							$options[ (string) $months ] = sprintf(
								/* translators: %d: number of months */
								_n( '%d month', '%d months', $months, 'woocommerce-appointments' ),
								$months
							);
						}
						return $options;
					} )(),
					'desc_tip' => true,
				],
				[
					'type' => 'sectionend',
					'id'   => 'wc_appointments_indexing_options',
				],
			];
            // Get indexing controls option.
            $reindex_id = 'yes' === get_option( 'wc_appointments_use_indexed_cache', 'no' );

            // Stop here if indexing not enabled.
            if ( ! $reindex_id ) {
                unset( $settings['manual_reindex'] );
            }
		} else {
			$settings = [];
		}

		return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
	}

	/**
	 * Generate the GCal Authorization field.
	 *
	 * @param array<string, mixed> $data Field data.
	 *
	 * @echo string
	 */
	public function gcal_authorization_setting( $data ): void {
		$client_id     = $this->settings_post_text( 'wc_appointments_gcal_client_id' ) ?: get_option( 'wc_appointments_gcal_client_id' );
		$client_secret = $this->settings_post_text( 'wc_appointments_gcal_client_secret' ) ?: get_option( 'wc_appointments_gcal_client_secret' );

		// Run Gcal oauth redirect.
		$gcal_integration_class = wc_appointments_gcal();

		// Reset to global context before checking the token — the singleton's user_id may have been
		// left set to a staff member's ID by a previous sync, which would cause get_access_token()
		// to look for a staff token instead of the global one and incorrectly show the Connect button.
		$gcal_integration_class->set_user_id( false );

		// Get access token.
		$is_connected = (bool) get_option( 'wc_appointments_gcal_refresh_token' );

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo wp_kses_post( $data['title'] ); ?>
			</th>
			<td class="forminp">
				<input type="hidden" name="wc_appointments_google_calendar_redirect" id="wc_appointments_google_calendar_redirect">
				<?php if ( ! $is_connected && ( $client_id && $client_secret ) ) : ?>
					<?php
					echo wp_kses(
						WC_Appointments_GCal::get_google_oauth_connect_button_html(
							[
								'data-staff'  => '0',
								'data-logout' => '0',
							]
						),
						WC_Appointments_GCal::get_google_oauth_connect_button_kses_allowed_html()
					);
					?>
				<?php elseif ( $is_connected ) : ?>
					<p style="color:green;"><?php esc_html_e( 'Successfully authenticated.', 'woocommerce-appointments' ); ?></p>
					<p class="submit"><button type="button" class="button oauth_redirect" data-staff="0" data-logout="1"><?php esc_html_e( 'Disconnect', 'woocommerce-appointments' ); ?></button></p>
				<?php else : ?>
					<p style="color:red;"><?php esc_html_e( 'Please fill out all required fields from above.', 'woocommerce-appointments' ); ?></p>
				<?php endif; ?>
			</td>
		</tr>
		<?php
		echo ob_get_clean(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup built above with escaped values.
	}

	/**
	 * Sanitized POST field while rendering settings (save uses WC options nonce).
	 *
	 * @param string $key POST key.
	 * @return string
	 */
	private function settings_post_text( string $key ): string {
		$value = filter_input( INPUT_POST, $key );
		if ( null === $value || false === $value ) {
			return '';
		}

		return sanitize_text_field( wp_unslash( $value ) );
	}

	/**
	 * Generate the GCal calendar ID field.
	 *
	 * @param array<string, mixed> $data Field data.
	 *
	 * @echo string
	 */
	public function gcal_calendar_id_setting( $data ): void {
		$client_id     = get_option( 'wc_appointments_gcal_client_id' );
		$client_secret = get_option( 'wc_appointments_gcal_client_secret' );
		$calendar_id   = get_option( 'wc_appointments_gcal_calendar_id' );

		// Run Gcal oauth redirect.
		$gcal_integration_class = wc_appointments_gcal();

		// Reset to global context before checking the token.
		$gcal_integration_class->set_user_id( false );

		// Get access token.
		$access_token = $gcal_integration_class->get_access_token();

		// Get calendars array.
		$get_calendars = $gcal_integration_class->get_calendars();

		if ( ! $access_token || ! $client_id || ! $client_secret ) {
			return;
		}

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="wc_appointments_gcal_calendar_id">
					<?php echo wp_kses_post( $data['title'] ); ?>
					<?php
					/* translators: %s: help tip text */
					echo wc_help_tip( esc_html__( 'Your Google Calendar ID. Leave empty if you only want to sync on staff level.', 'woocommerce-appointments' ) );
					?>
				</label>
			</th>
			<td class="forminp">
				<?php if ( $get_calendars ) : ?>
					<select id="wc_appointments_gcal_calendar_id" name="wc_appointments_gcal_calendar_id" class="wc-enhanced-select" style="width:25em;">
						<option value=""><?php esc_html_e( 'N/A', 'woocommerce-appointments' ); ?></option>
						<?php foreach ( $get_calendars as $cal_id => $cal_name ) : ?>
								<option value="<?php echo esc_attr( $cal_id ); ?>" <?php selected( $calendar_id, $cal_id ); ?>><?php echo esc_html( $cal_name ); ?></option>
						<?php endforeach; ?>
					</select>
				<?php else : ?>
					<input type="text" name="wc_appointments_gcal_calendar_id" id="wc_appointments_gcal_calendar_id" value="<?php echo esc_attr( $calendar_id ); ?>">
				<?php endif; ?>
			</td>
		</tr>
		<?php
		echo ob_get_clean(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup built above with escaped values.
	}

	/**
	 * Generate the Manual Sync field (standardized with reindex pattern).
	 *
	 * @param array<string, mixed> $data
	 *
	 * @echo string
	 */
	public function manual_sync_setting( $data ): void {
		$twoway     = $this->settings_post_text( 'wc_appointments_gcal_twoway' );
		$get_twoway = get_option( 'wc_appointments_gcal_twoway' );

		// Two-way sync not configured yet, enable by default.
		$twoway_enabled = 'two_way' === $get_twoway;
		$twoway_enabled = ( 'two_way' === $twoway ) ? true : $twoway_enabled;

		if ( ! $twoway_enabled ) {
			return;
		}

		wp_create_nonce( 'wc_appointments_admin_nonce' );

		// Get progress status.
		$progress = get_option( 'wc_appointments_gcal_sync_progress', [] );
		$status = esc_html( $progress['status'] ?? 'idle' );
		$message = esc_html( $progress['message'] ?? '' );
		$show_status = ! empty( $status ) && 'idle' !== $status;

		// Get current synced rules count.
		$data_store    = WC_Data_Store::load( 'appointments-availability' );
		$all_rules     = $data_store->get_all(
			[
				[
					'key'     => 'kind',
					'compare' => '=',
					'value'   => WC_Appointments_Availability::KIND_GLOBAL,
				],
				[
					'key'     => 'event_id',
					'compare' => '!=',
					'value'   => '',
				],
			]
		);
		$current_count = count(
			array_filter(
				$all_rules,
				function( $rule ) {
					$parent_id = $rule->get_parent_event_id();
					return ! $parent_id;
				}
			)
		);

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php echo wp_kses_post( $data['title'] ); ?>
			</th>
			<td class="forminp">
				<fieldset>
					<p>
						<button type="button" class="button button-primary" id="wc-appointments-start-gcal-sync" data-staff="0">
							<?php esc_html_e( 'Re-sync from Google Calendar', 'woocommerce-appointments' ); ?>
						</button>
						<?php if ( $show_status ) : ?>
							<span id="wc-appointments-gcal-sync-status">
								<?php
								printf(
									/* translators: %s: status string */
									esc_html__( 'Status: %s', 'woocommerce-appointments' ),
									esc_html( $status )
								);
								?>
							</span>
						<?php else : ?>
							<span id="wc-appointments-gcal-sync-status" style="display: none;"></span>
						<?php endif; ?>
					</p>


					<div id="wc-appointments-gcal-sync-progress" style="display: none;">
						<div class="progress-bar" style="width: 0%;"></div>
						<div class="progress-text"></div>
					</div>

					<p class="description" id="wc-appointments-gcal-sync-message" style="display: none;">
						<?php echo ( $show_status && $message ) ? esc_html( $message ) : ''; ?>
					</p>

					<div class="wc-appointments-gcal-backup-section">
						<p>
							<strong><?php esc_html_e( 'Backup & Restore', 'woocommerce-appointments' ); ?></strong>
							<span class="description">
								<?php
								printf(
									/* translators: %d: number of synced Google Calendar rules */
									esc_html__( 'Current rules: %d synced events', 'woocommerce-appointments' ),
									absint( $current_count )
								);
								?>
							</span>
						</p>
						<p>
							<button type="button" class="button" id="wc-appointments-gcal-export" data-user-id="0">
								<?php esc_html_e( 'Export Rules (JSON)', 'woocommerce-appointments' ); ?>
							</button>
							<button type="button" class="button" id="wc-appointments-gcal-import" data-user-id="0">
								<?php esc_html_e( 'Import Rules', 'woocommerce-appointments' ); ?>
							</button>
							<button type="button" class="button wc-appointments-toggle-button" id="wc-appointments-gcal-show-backups" data-user-id="0" aria-expanded="false">
								<span class="dashicons dashicons-arrow-down-alt2"></span>
								<?php esc_html_e( 'View Backups', 'woocommerce-appointments' ); ?>
							</button>
							<input type="file" id="wc-appointments-gcal-import-file" accept=".json" style="display: none;">
						</p>
						<div id="wc-appointments-gcal-backup-list" style="display: none;"></div>
					</div>
				</fieldset>
			</td>
		</tr>
		<?php
		echo ob_get_clean(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup built above with escaped values.
	}

	/**
	 * Render the indexing controls field.
	 */
	public function indexing_controls_setting(): void {
 		if ( ! current_user_can( 'manage_woocommerce' ) ) {
 			return;
 		}
 		wp_create_nonce( 'wc_appointments_admin_nonce' );

		$progress = get_option( 'wc_appointments_index_progress', [] );
		if ( ! is_array( $progress ) ) {
			$progress = [];
		}

 		$status          = isset( $progress['status'] ) ? (string) $progress['status'] : 'idle';
 		$status_label    = $status ? $status : 'idle';
 		$total_rules     = intval( $progress['total_rules'] ?? 0 );
 		$processed_rules = intval( $progress['processed_rules'] ?? 0 );
 		$total_appts     = intval( $progress['total_appointments'] ?? 0 );
 		$processed_appts = intval( $progress['processed_appts'] ?? 0 );
 		$error_message   = isset( $progress['error_message'] ) ? (string) $progress['error_message'] : '';

 		// Combine two progress streams (rules + appointments).
 		$total_all     = max( 1, $total_rules + $total_appts );
 		$processed_all = min( $total_all, $processed_rules + $processed_appts );
 		$percent       = max( 0, min( 100, round( ( $processed_all / $total_all ) * 100 ) ) );
 		if ( 'completed' === $status ) {
			$percent = 100;
		}

		$show_progress = in_array( $status, [ 'running', 'queued', 'completed' ], true );
		$show_notice   = in_array( $status, [ 'failed', 'stopped' ], true ) && '' !== $error_message;

		if ( in_array( $status, [ 'running', 'queued' ], true ) ) {
			echo '<p class="description wc-appointments-reindex-storefront-note">' . esc_html__( 'Re-index in progress: storefront uses dynamic checks until complete. Availability stays correct; performance may be slower.', 'woocommerce-appointments' ) . '</p>';
		}

		// Get last completion info
		$last_completed = get_option( 'wc_appointments_last_index_completed', [] );

		echo '<fieldset id="wc-appointments-indexing-controls" data-initial-progress="' . esc_attr( wp_json_encode( $progress ) ) . '">';
		echo '<p class="wc-appointments-index-actions">';
		echo '<button type="button" class="button button-primary" id="wc-appointments-start-reindex">' . esc_html__( 'Re-index Now', 'woocommerce-appointments' ) . '</button> ';
		echo '<button type="button" class="button" id="wc-appointments-stop-reindex" style="display:none;">' . esc_html__( 'Stop re-index', 'woocommerce-appointments' ) . '</button> ';
		echo '<button type="button" class="button" id="wc-appointments-resume-reindex" style="display:none;">' . esc_html__( 'Resume re-index', 'woocommerce-appointments' ) . '</button> ';
		/* translators: %s: status string */
		echo '<span id="wc-appointments-index-status">' . sprintf( esc_html__( 'Status: %s', 'woocommerce-appointments' ), esc_html( $status_label ) ) . '</span>';
        echo '</p>';

		if ( $show_notice ) {
			echo '<div id="wc-appointments-index-notice" class="notice inline notice-error">';
		} else {
			echo '<div id="wc-appointments-index-notice" class="notice inline" style="display:none;">';
		}
		echo '<p>';
		if ( $show_notice ) {
			echo esc_html( $error_message );
		}
		echo '</p>';
		echo '</div>';

        echo '<div id="wc-appointments-index-progress"' . ( $show_progress ? '' : ' style="display:none;"' ) . '>';
        echo '<div class="progress-bar" style="width:' . esc_attr( (string) $percent ) . '%;"></div>';
        echo '<div class="progress-text">' . esc_html( (string) $percent ) . '%</div>';
        echo '</div>';
        echo '<p class="description" id="wc-appointments-index-counts"></p>';

		// Display last completion info
		if ( ! empty( $last_completed['timestamp'] ) ) {
			$completed_time = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last_completed['timestamp'] );
			$total_rules = (int) ( $last_completed['total_rules'] ?? 0 );
			$total_appointments = (int) ( $last_completed['total_appointments'] ?? 0 );
			$total_indexed = $total_rules + $total_appointments;
			$is_auto_indexed = ! empty( $last_completed['auto_indexed'] );

			echo '<p class="description wc-appointments-last-indexing">';
			if ( $is_auto_indexed ) {
				echo sprintf(
					/* translators: %1$s: date of last indexing, %2$d: number of rules, %3$d: number of appointments */
					esc_html__( 'Last indexing update: %1$s (%2$d rules, %3$d appointments) - Automatic', 'woocommerce-appointments' ),
				    '<strong>' . esc_html( $completed_time ) . '</strong>',
				    absint( $total_rules ),
				    absint( $total_appointments ),
				);
			} else {
				$cache_rows       = (int) ( $last_completed['cache_rows_created'] ?? 0 );
				$skipped          = (int) ( $last_completed['skipped_malformed_rules'] ?? 0 );
				$skipped_suffix   = '';
				if ( 0 < $skipped ) {
					$skipped_suffix = sprintf(
						/* translators: %d: number of malformed availability rules skipped during re-index */
						esc_html__( ', %d malformed rules skipped', 'woocommerce-appointments' ),
						absint( $skipped )
					);
				}
				echo sprintf(
					/* translators: %1$s: date of last re-index, %2$d: number of rules, %3$d: number of appointments, %4$s: number of cache rows, %5$s: optional malformed-rule suffix */
					esc_html__( 'Last manual re-index: %1$s (%2$d rules, %3$d appointments, %4$s cache rows%5$s)', 'woocommerce-appointments' ),
					'<strong>' . esc_html( $completed_time ) . '</strong>',
					absint( $total_rules ),
					absint( $total_appointments ),
					esc_html( number_format_i18n( $cache_rows ) ),
					esc_html( $skipped_suffix )
				);
			}
			echo '</p>';
		} else {
			echo '<p class="description wc-appointments-last-indexing">';
			echo esc_html__( 'No previous indexing completed.', 'woocommerce-appointments' );
			echo '</p>';
		}

 		echo '</fieldset>';
	}
}

return new WC_Appointments_Admin_Settings();
