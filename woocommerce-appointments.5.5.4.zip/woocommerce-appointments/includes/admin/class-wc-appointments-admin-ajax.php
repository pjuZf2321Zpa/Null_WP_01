<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Appointment ajax callbacks.
 */
class WC_Appointments_Admin_Ajax {

	/**
	 * Absolute integer from any scalar (PHP 8+ rejects non-numeric strings in abs()).
	 *
	 * @param mixed $value Request vars, parse_str() output, meta, etc.
	 * @return int
	 */
	private static function wca_abs_int( $value ): int {
		return abs( (int) $value );
	}

	/**
	 * Unslashed POST scalar (admin AJAX handlers verify nonce before use).
	 *
	 * @param string $key     POST key.
	 * @param mixed  $default Default when absent.
	 * @return mixed
	 */
	private static function post_raw( string $key, $default = null ) {
		$value = filter_input( INPUT_POST, $key );
		if ( null !== $value && false !== $value ) {
			return wp_unslash( $value );
		}

		// filter_input() reads the original SAPI body and ignores PHPUnit/CLI $_POST overrides.
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Caller verifies nonce; PHPUnit/CLI $_POST fallback.
		if ( ! isset( $_POST[ $key ] ) ) {
			return $default;
		}

		return wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by post_text/post_absint_*.
		// phpcs:enable
	}

	/**
	 * Sanitized POST text field.
	 *
	 * @param string $key     POST key.
	 * @param string $default Default when absent.
	 * @return string
	 */
	private static function post_text( string $key, string $default = '' ): string {
		$value = self::post_raw( $key, null );
		if ( null === $value ) {
			return $default;
		}

		return sanitize_text_field( (string) $value );
	}


	/**
	 * POST integer from a named field.
	 *
	 * @param string $key POST key.
	 * @return int
	 */
	private static function post_absint_key( string $key ): int {
		return self::wca_abs_int( self::post_raw( $key, 0 ) );
	}

	/**
	 * Comma-separated POST list as positive integers.
	 *
	 * @param string $key POST key.
	 * @return int[]
	 */
	private static function post_id_list( string $key ): array {
		$raw = self::post_text( $key );
		if ( '' === $raw ) {
			return [];
		}

		return array_values( array_filter( wp_parse_id_list( $raw ) ) );
	}

	/**
	 * Unslashed GET scalar (admin JSON search / select2).
	 *
	 * @param string $key     GET key.
	 * @param mixed  $default Default when absent.
	 * @return mixed
	 */
	private static function get_raw( string $key, $default = null ) {
		$value = filter_input( INPUT_GET, $key );
		if ( null === $value || false === $value ) {
			return $default;
		}

		return wp_unslash( $value );
	}

	/**
	 * Sanitized GET text field.
	 *
	 * @param string $key     GET key.
	 * @param string $default Default when absent.
	 * @return string
	 */
	private static function get_text( string $key, string $default = '' ): string {
		$value = self::get_raw( $key, null );
		if ( null === $value ) {
			return $default;
		}

		return sanitize_text_field( (string) $value );
	}

	/**
	 * GET integer from a named field.
	 *
	 * @param string $key GET key.
	 * @return int
	 */
	private static function get_absint_key( string $key ): int {
		return self::wca_abs_int( self::get_raw( $key, 0 ) );
	}

	/**
	 * Parsed `form` POST field (admin panel / cost quote).
	 *
	 * @return array<string, mixed>
	 */
	private static function post_form_array(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Callers verify nonce; jQuery .serialize() URL-encoded blob; sanitize per key after parse_str.
		$form = isset( $_POST['form'] ) ? wp_unslash( $_POST['form'] ) : '';
		if ( ! is_string( $form ) || '' === $form ) {
			return [];
		}

		$posted = [];
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- jQuery .serialize() is URL-encoded; sanitize per key after decode.
		parse_str( $form, $posted );

		return $posted;
	}

	/**
	 * First positive integer from a list of POST keys.
	 *
	 * @param string[] $keys POST keys in priority order.
	 * @param int      $default Default when none are set.
	 * @return int
	 */
	private static function post_absint_first( array $keys, int $default = 0 ): int {
		foreach ( $keys as $key ) {
			$value = self::post_absint_key( $key );
			if ( $value > 0 ) {
				return $value;
			}
		}

		return $default;
	}

	/**
	 * POST email field.
	 *
	 * @param string $key POST key.
	 * @return string
	 */
	private static function post_email( string $key ): string {
		return sanitize_email( self::post_text( $key ) );
	}

	/**
	 * Whether a truthy POST flag is set.
	 *
	 * @param string $key POST key.
	 * @return bool
	 */
	private static function post_bool( string $key ): bool {
		return ! empty( self::post_raw( $key, null ) );
	}

	/**
	 * Full-width storefront notice inside `.slot-picker` (empty day or AJAX error).
	 *
	 * @param string $class Item class suffix (e.g. slot_empty, slot_error).
	 * @param string $text  Localized notice text.
	 */
	private static function slot_notice_html( string $class, string $text ): string {
		return '<div class="slot_row"><ul><li class="slot ' . esc_attr( $class ) . '">' . esc_html( $text ) . '</li></ul></div>';
	}

	/**
	 * Output time-slot HTML fragment from the slots renderer.
	 *
	 * Markup is escaped at build time in WC_Appointment_Slots_Time_Columns_Renderer;
	 * do not run wp_kses_post() here — it strips data-* attributes required by time-picker.js.
	 *
	 * @param string $slot_html Slot list HTML from the controller.
	 * @return bool When WCA_TEST_SUITE_NO_DIE is set.
	 */
	private static function emit_slot_html( string $slot_html ): bool {
		if ( '' === trim( wp_strip_all_tags( $slot_html ) ) ) {
			$slot_html = self::slot_notice_html( 'slot_empty', __( 'No slots available.', 'woocommerce-appointments' ) );
		}

		if ( defined( 'WCA_TEST_SUITE_NO_DIE' ) && WCA_TEST_SUITE_NO_DIE ) {
			echo $slot_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in slots renderer.
			return true;
		}

		die( $slot_html ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in slots renderer.
	}

	/**
	 * Full unslashed POST (call only after nonce verification).
	 *
	 * @return array<string, mixed>
	 */
	private static function post_unslashed_array(): array {
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Caller verifies nonce; sanitized per field or by callee.
	}

	/**
	 * First non-empty sanitized POST text from a list of keys.
	 *
	 * @param string[] $keys POST keys in priority order.
	 * @param string   $default Default when none are set.
	 * @return string
	 */
	private static function post_text_first( array $keys, string $default = '' ): string {
		foreach ( $keys as $key ) {
			$value = self::post_text( $key );
			if ( '' !== $value ) {
				return $value;
			}
		}

		return $default;
	}

	/**
	 * wc_clean() on a POST scalar.
	 *
	 * @param string $key     POST key.
	 * @param string $default Default when absent.
	 * @return string
	 */
	private static function post_wc_clean( string $key, string $default = '' ): string {
		$value = self::post_raw( $key, null );
		if ( null === $value ) {
			return $default;
		}

		return wc_clean( (string) $value );
	}

	/**
	 * Billing address fields from POST (admin create appointment).
	 *
	 * @return array<string, string>
	 */
	private static function posted_billing_address(): array {
		return [
			'first_name' => self::post_text( '_billing_first_name' ),
			'last_name'  => self::post_text( '_billing_last_name' ),
			'company'    => self::post_text( '_billing_company' ),
			'address_1'  => self::post_text( '_billing_address_1' ),
			'address_2'  => self::post_text( '_billing_address_2' ),
			'city'       => self::post_text( '_billing_city' ),
			'postcode'   => self::post_text( '_billing_postcode' ),
			'country'    => strtoupper( self::post_text( '_billing_country' ) ),
			'state'      => self::post_text( '_billing_state' ),
			'email'      => self::post_email( '_billing_email' ),
			'phone'      => self::post_text( '_billing_phone' ),
		];
	}

	/**
	 * Persist customer timezone from admin create POST onto account + appointment(s).
	 * No-op when Timezone Display is disabled everywhere. Empty / site TZ = Default.
	 *
	 * @param int                 $customer_id     Customer user ID (0 = guest).
	 * @param WC_Appointment|null $appointment     Single create: set on object before save.
	 * @param int[]|null          $appointment_ids Series: update these IDs after materialize.
	 */
	private static function apply_customer_local_timezone( int $customer_id, $appointment = null, $appointment_ids = null ): void {
		if ( 'disabled' === get_option( 'wc_appointments_timezone_display', 'all' ) || ! class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
			return;
		}
		$tz       = self::post_text( 'appointment_local_timezone' );
		$local_tz = ( '' !== $tz
			&& WC_Appointments_Timezone_Helper::is_valid_timezone( $tz )
			&& $tz !== WC_Appointments_Timezone_Helper::get_site_timezone_string() )
			? $tz
			: '';
		if ( $customer_id > 0 ) {
			WC_Appointments_Timezone_Helper::save_user_timezone( $customer_id, $local_tz );
		}
		if ( '' === $local_tz ) {
			return;
		}
		if ( $appointment instanceof WC_Appointment ) {
			$appointment->set_local_timezone( $local_tz );
			return;
		}
		foreach ( (array) $appointment_ids as $appointment_id ) {
			$appt = get_wc_appointment( (int) $appointment_id );
			if ( ! $appt ) {
				continue;
			}
			$appt->set_local_timezone( $local_tz );
			$appt->save();
		}
	}

	/**
	 * Whether any billing POST fields are non-empty.
	 *
	 * @return bool
	 */
	private static function post_has_billing_data(): bool {
		$keys = [
			'_billing_first_name',
			'_billing_last_name',
			'_billing_company',
			'_billing_address_1',
			'_billing_address_2',
			'_billing_city',
			'_billing_postcode',
			'_billing_country',
			'_billing_state',
			'_billing_email',
			'_billing_phone',
		];

		foreach ( $keys as $key ) {
			if ( '_billing_email' === $key ) {
				if ( '' !== self::post_email( $key ) ) {
					return true;
				}
				continue;
			}
			if ( '' !== self::post_text( $key ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Gross line amount for display when catalog prices include tax (net → incl without wc_get_price_including_tax quirks).
	 *
	 * @param WC_Product $product  Product.
	 * @param float      $net_line Net line total.
	 * @param int        $qty      Quantity.
	 * @return float
	 */
	private static function wca_net_line_to_incl_gross( $product, float $net_line, int $qty = 1 ): float {
		$qty_line = max( 1, $qty );
		if ( $net_line <= 0 || ! wc_tax_enabled() || ! wc_prices_include_tax() ) {
			return max( 0, (float) $net_line );
		}
		$tax_rates = WC_Tax::get_base_tax_rates( $product->get_tax_class() );
		$taxes     = WC_Tax::calc_tax( $net_line, $tax_rates, false );
		return max( 0, (float) $net_line + array_sum( $taxes ) );
	}

	/**
	 * Posted fields for panel create cost calc (matches storefront / calculate_costs).
	 *
	 * @param WC_Product_Appointment $product         Product.
	 * @param int                    $start_timestamp Slot start.
	 * @param string                 $time_from       H:i when timed.
	 * @param int                    $qty             Quantity.
	 * @param int                    $customer_id     Customer user ID.
	 * @param int                    $staff_id        Staff user ID.
	 * @param int                    $location_id     Location ID.
	 * @param int                    $resource_id     Resource ID.
	 * @return array<string, mixed>
	 */
	private static function wca_panel_cost_posted_for_slot(
		WC_Product_Appointment $product,
		int $start_timestamp,
		string $time_from,
		int $qty,
		int $customer_id,
		int $staff_id,
		int $location_id,
		int $resource_id
	): array {
		$cost_posted = [
			'wc_appointments_field_start_date_year'  => (int) date( 'Y', $start_timestamp ),
			'wc_appointments_field_start_date_month' => (int) date( 'm', $start_timestamp ),
			'wc_appointments_field_start_date_day'   => (int) date( 'd', $start_timestamp ),
			'quantity'                                => max( 1, $qty ),
			'customer_id'                             => $customer_id,
		];
		if ( $product->has_time() && '' !== $time_from ) {
			$cost_posted['wc_appointments_field_start_date_time'] = $time_from;
		}
		if ( $staff_id > 0 ) {
			$cost_posted['wc_appointments_field_staff'] = $staff_id;
		}
		if ( $location_id > 0 ) {
			$cost_posted['wc_appointments_field_location'] = $location_id;
		}
		if ( $resource_id > 0 ) {
			$cost_posted['wc_appointments_field_resource'] = $resource_id;
		}
		$posted_slot_ts = self::post_text_first( [ 'wc_appointments_field_start_date_timestamp', 'wca_slot_start_ts' ] );
		if ( '' !== $posted_slot_ts && is_numeric( $posted_slot_ts ) ) {
			$slot_ts_int = (int) $posted_slot_ts;
			if ( $slot_ts_int > 86400 && $slot_ts_int <= 2147483647 ) {
				$cost_posted['wc_appointments_field_start_date_timestamp'] = (string) $slot_ts_int;
			}
		}
		return $cost_posted;
	}

	/**
	 * Footer / quote display amounts from calculated cost and deposit line nets.
	 *
	 * @param WC_Product_Appointment $product            Product.
	 * @param float                  $combined_gross     Appointment cost (+ addons) from cost calc.
	 * @param array<string, mixed>   $deposit_totals     Result from wc_appointments_resolve_deposit_line_net().
	 * @param int                    $qty                Quantity.
	 * @param bool                   $panel_cost_excl_tax Panel quotes net when catalog is excl. tax.
	 * @param bool                   $is_admin_request   Admin panel AJAX.
	 * @return array{line:float,full:float}
	 */
	private static function wca_panel_display_amounts( WC_Product_Appointment $product, float $combined_gross, array $deposit_totals, int $qty, bool $panel_cost_excl_tax, bool $is_admin_request ): array {
		if ( $panel_cost_excl_tax || ! wc_tax_enabled() || ! wc_prices_include_tax() ) {
			return [
				'line' => self::wca_panel_display_price_for_net( $product, (float) $deposit_totals['line_net'], $panel_cost_excl_tax, $is_admin_request, $qty ),
				'full' => self::wca_panel_display_price_for_net( $product, (float) $deposit_totals['full_line_net'], $panel_cost_excl_tax, $is_admin_request, $qty ),
			];
		}

		return wc_appointments_deposit_display_amounts( $product, $combined_gross, $deposit_totals, $qty );
	}

	/**
	 * Deposit order-item meta amounts (matches WooCommerce Deposits cart: full line incl./excl., deposit excl.).
	 *
	 * @param WC_Product_Appointment $product          Product.
	 * @param float                  $combined_gross   Gross appointment line before net conversion (incl. when catalog incl. tax).
	 * @param float                  $full_line_net    Full line net.
	 * @param float                  $deposit_line_net Deposit line net.
	 * @param int                    $qty              Quantity.
	 * @return array{full_inc:float,full_ex:float,dep_ex:float}
	 */
	private static function wca_deposit_order_item_amounts( WC_Product_Appointment $product, float $combined_gross, float $full_line_net, float $deposit_line_net, int $qty ): array {
		$qty_line = max( 1, $qty );
		$full_ex  = max( 0, (float) $full_line_net );
		$dep_ex   = max( 0, (float) $deposit_line_net );

		if ( wc_tax_enabled() && wc_prices_include_tax() ) {
			$full_inc = max(
				max( 0, (float) $combined_gross ),
				self::wca_net_line_to_incl_gross( $product, $full_ex, $qty_line )
			);
		} else {
			$full_inc = (float) wc_get_price_including_tax(
				$product,
				[
					'qty'   => $qty_line,
					'price' => $full_ex / $qty_line,
				]
			);
		}

		return [
			'full_inc' => $full_inc,
			'full_ex'  => $full_ex,
			'dep_ex'   => $dep_ex,
		];
	}

	/**
	 * Net order line from admin panel override POST fields, or tax-adjusted fallback.
	 *
	 * @param WC_Product $product  Product.
	 * @param float      $fallback Catalog-basis amount when no override is posted.
	 * @return float
	 */
	private static function wca_panel_posted_line_net( $product, float $fallback ): float {
		$override_str = self::post_text( 'appointment_override_price' );
		if ( '' !== $override_str ) {
			$override_price = wc_format_decimal( $override_str );
			if ( '' !== self::post_text( 'appointment_override_price_excl_tax' ) ) {
				return max( 0, (float) $override_price );
			}

			return wc_appointments_admin_line_net_from_amount( $product, (float) $override_price );
		}

		return wc_appointments_admin_line_net_from_amount( $product, $fallback );
	}

	/**
	 * Recalculate order total after line net was set post–add_product (addons/deposits patch the item).
	 *
	 * @param WC_Order $order    Order.
	 * @param WC_Product $product Product.
	 * @param int      $item_id  Line item ID.
	 * @param int      $qty      Line quantity.
	 * @param float    $line_net Full line total excluding tax.
	 */
	private function wca_calculate_order_totals_for_line_net( WC_Order $order, $product, int $item_id, int $qty, float $line_net ): void {
		$line_net = max( 0, (float) $line_net );
		$qty      = max( 1, $qty );

		$sync_cache = function () use ( $order, $item_id, $line_net ) {
			$cached = $order->get_item( $item_id, false );
			if ( $cached && is_a( $cached, 'WC_Order_Item_Product' ) ) {
				$cached->set_subtotal( $line_net );
				$cached->set_total( $line_net );
				$cached->set_taxes( [] );
			}
		};

		$sync_cache();
		$catalog_price = $product->get_price( 'edit' );
		if ( $line_net > 0 ) {
			$product->set_price( $line_net / $qty );
		}
		$order->calculate_totals();
		$product->set_price( $catalog_price );

		$item = $order->get_item( $item_id );
		if ( ! $item || ! is_a( $item, 'WC_Order_Item_Product' ) ) {
			return;
		}
		if ( abs( (float) wc_format_decimal( $item->get_total() ) - (float) wc_format_decimal( $line_net ) ) <= 0.000001 ) {
			return;
		}
		$item->set_subtotal( $line_net );
		$item->set_total( $line_net );
		$item->save();
		$sync_cache();
		$order->calculate_totals();
	}

	/**
	 * Display price for admin panel footer from a net line amount (matches catalog tax display basis).
	 *
	 * @param WC_Product $product            Product.
	 * @param float      $net_line           Net line total.
	 * @param bool       $panel_cost_excl_tax Panel quotes net when catalog is excl. tax.
	 * @param bool       $is_admin_request   Admin panel AJAX.
	 * @param int        $qty                Line quantity.
	 * @return float
	 */
	private static function wca_panel_display_price_for_net( $product, float $net_line, bool $panel_cost_excl_tax, bool $is_admin_request, int $qty = 1 ): float {
		$qty_line = max( 1, $qty );
		$unit_net = $net_line / $qty_line;
		$args     = [
			'qty'   => $qty_line,
			'price' => $unit_net,
		];

		if ( $panel_cost_excl_tax ) {
			return (float) wc_get_price_excluding_tax( $product, $args );
		}

		$admin_catalog_incl_tax = $is_admin_request && current_user_can( 'edit_appointments' ) && wc_tax_enabled() && wc_prices_include_tax();

		if ( $admin_catalog_incl_tax || ( ! $is_admin_request && 'incl' === get_option( 'woocommerce_tax_display_shop' ) ) ) {
			return (float) wc_get_price_including_tax( $product, $args );
		}

		return (float) wc_get_price_excluding_tax( $product, $args );
	}

	/**
	 * Label for appointable product Select2 / AJAX search: name + product ID + optional "assigned to you".
	 *
	 * @param WC_Product_Appointment $product               Appointment product.
	 * @param int                    $current_user_id       Current user ID.
	 * @param bool                   $parentheses_around_id Legacy list endpoints use (#id); JSON search uses #id in HTML mode.
	 * @param bool                   $as_html               When true, return escaped name + HTML spans (admin panel). When false, plain text (WooCommerce `wc-product-search` escapes selected chips).
	 * @return string
	 */
	private static function wca_format_appointable_product_select_label( $product, int $current_user_id, bool $parentheses_around_id = false, bool $as_html = true ): string {
		if ( ! $product instanceof WC_Product_Appointment ) {
			return '';
		}
		$staff_ids = $product->get_staff_ids();
		$assigned  = $product->has_staff() && in_array( $current_user_id, array_map( 'intval', (array) $staff_ids ), true );
		$pid       = (int) $product->get_id();

		if ( $as_html ) {
			$assigned_html = $assigned
				? ' <span class="wca-search-metadata wca-search-metadata--assigned">' . esc_html__( 'assigned to you', 'woocommerce-appointments' ) . '</span>'
				: '';
			$name = esc_html( rawurldecode( $product->get_name() ) );
			if ( $parentheses_around_id ) {
				$id_html = '<span class="wca-search-metadata">(#' . $pid . ')</span>';
			} else {
				$id_html = '<span class="wca-search-metadata">#' . $pid . '</span>';
			}

			return $name . ' ' . $id_html . $assigned_html;
		}

		$name           = wp_strip_all_tags( rawurldecode( (string) $product->get_name() ) );
		$assigned_plain = $assigned
			? ' — ' . __( 'assigned to you', 'woocommerce-appointments' )
			: '';
		$id_plain       = ' (#' . $pid . ')';

		return trim( $name . $id_plain . $assigned_plain );
	}

	/**
	 * Constructor
	 */
	public function __construct() {
		// Core json_search_customers uses limit=0 for terms >= 3 chars; cap query size.
		add_filter( 'woocommerce_customer_search_customers', [ $this, 'cap_customer_json_search_query' ], 10, 1 );

		// TODO: Switch from `wp_ajax` to `wc_ajax`
		add_action( 'wp_ajax_woocommerce_remove_appointable_staff', [ $this, 'remove_appointable_staff' ], 10, 0 );
		add_action( 'wp_ajax_woocommerce_add_staff_product', [ $this, 'add_staff_product' ], 10, 0 );
		add_action( 'wp_ajax_woocommerce_manual_sync', [ $this, 'manual_sync' ], 10, 0 );
		add_action( 'wp_ajax_woocommerce_oauth_redirect', [ $this, 'oauth_redirect' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_gcal_export_rules', [ $this, 'export_gcal_rules' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_gcal_import_rules', [ $this, 'import_gcal_rules' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_gcal_get_backups', [ $this, 'get_gcal_backups' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_gcal_restore_backup', [ $this, 'restore_gcal_backup' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_gcal_delete_backup', [ $this, 'delete_gcal_backup' ], 10, 0 );
		add_action( 'wp_ajax_woocommerce_json_search_appointable_products', [ $this, 'json_search_appointable_products' ], 10, 0 );
		add_action( 'wp_ajax_wc-appointment-confirm', [ $this, 'mark_appointment_confirmed' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_calculate_costs', [ $this, 'calculate_costs' ], 10, 0 );
		add_action( 'wp_ajax_nopriv_wc_appointments_calculate_costs', [ $this, 'calculate_costs' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_get_slots', [ $this, 'get_time_slots_for_date' ], 10, 0 );
		add_action( 'wp_ajax_nopriv_wc_appointments_get_slots', [ $this, 'get_time_slots_for_date' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_json_search_order', [ $this, 'json_search_order' ], 10, 0 );

		// Indexing AJAX handlers
		add_action( 'wp_ajax_wc_appointments_start_reindex', [ $this, 'start_reindex' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_stop_reindex', [ $this, 'stop_reindex' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_process_reindex_chunk', [ $this, 'process_reindex_chunk' ], 10, 0 );
		add_action( 'init', [ $this, 'maybe_reconcile_stale_reindex_on_init' ], 5 );

		// GCal sync AJAX handlers (standardized with reindex pattern)
		add_action( 'wp_ajax_wc_appointments_start_gcal_sync', [ $this, 'start_gcal_sync' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_stop_gcal_sync', [ $this, 'stop_gcal_sync' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_process_gcal_sync_chunk', [ $this, 'process_gcal_sync_chunk' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_clear_gcal_sync_progress', [ $this, 'clear_gcal_sync_progress' ], 10, 0 );

		// Admin panel AJAX handlers
		add_action( 'wp_ajax_wc_appointments_get_appointable_products', [ $this, 'get_appointable_products' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_search_appointable_products', [ $this, 'search_appointable_products' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_get_product_details', [ $this, 'get_product_details' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_get_available_times', [ $this, 'get_available_times' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_create_appointment', [ $this, 'create_appointment' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_get_customer_details', [ $this, 'get_customer_details' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_check_availability', [ $this, 'check_availability' ], 10, 0 );
		// New: pretty duration labels for To time options
		add_action( 'wp_ajax_wc_appointments_pretty_duration', [ $this, 'pretty_duration' ], 10, 0 );
		// Calendar view preference
		add_action( 'wp_ajax_wc_appointments_save_calendar_view', [ $this, 'save_calendar_view' ], 10, 0 );
		// Admin panel browse mini-calendar: strip vs full month
		add_action( 'wp_ajax_wc_appointments_save_browse_mini_cal', [ $this, 'save_browse_mini_cal' ], 10, 0 );
		// Availability-first panel endpoints
		add_action( 'wp_ajax_wc_appointments_get_day_slots', [ $this, 'get_day_slots' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_get_first_available_slot', [ $this, 'get_first_available_slot_panel' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_get_month_availability', [ $this, 'get_month_availability' ], 10, 0 );
		add_action( 'wp_ajax_wc_appointments_admin_calendar_range', [ $this, 'admin_calendar_range' ], 10, 0 );
	}

	/**
	 * Cap WooCommerce customer JSON search when core omits a limit (terms of 3+ chars).
	 *
	 * @param array<string, mixed> $args Query args for WP_User_Query.
	 * @return array<string, mixed>
	 */
	public function cap_customer_json_search_query( $args ) {
		if ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX || ! empty( $args['number'] ) ) {
			return $args;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Action gate only; WC verifies nonce.
		$action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : '';
		if ( 'woocommerce_json_search_customers' === $action ) {
			$args['number'] = 20;
		}

		return $args;
	}

	/**
	 * Remove staff from a product (staff profile Products list).
	 */
	public function remove_appointable_staff(): void {
		check_ajax_referer( 'delete-appointable-staff', 'security' );

		$post_id   = self::post_absint_key( 'post_id' );
		$staff_id  = self::post_absint_key( 'staff_id' );

		if ( ! $post_id || ! current_user_can( 'edit_product', $post_id ) ) {
			wp_die( -1 );
		}

		$product   = get_wc_product_appointment( $post_id );
		$staff_ids = $product->get_staff_ids();
		$staff_ids = array_diff( $staff_ids, [ $staff_id ] );
		$product->set_staff_ids( $staff_ids );
		$product->save();
		die();
	}

	/**
	 * Add staff
	 */
	public function add_staff_product(): void {
		check_ajax_referer( 'add-staff-product', 'security' );

		$add_product_id    = self::post_absint_key( 'add_product_id' );
		$staff_id          = self::post_absint_key( 'staff_id' );
		$assigned_products = self::post_id_list( 'assigned_products' );

		if ( 0 === $add_product_id ) {
			wp_send_json(
			    [
					'error' => __( 'Unable to add product', 'woocommerce-appointments' ),
				],
			);
		}

		// Return html
		if ( 0 !== $add_product_id ) {
			if ( in_array( $add_product_id, $assigned_products ) ) {
				wp_send_json(
				    [
						'error' => __( 'The product has already been assigned to this staff', 'woocommerce-appointments' ),
					],
				);
			}

			// Variables needed for 'views/html-appointment-staff-fields.php'
			$user_id         = $staff_id;
			$user_product_id = $add_product_id;

			ob_start();
			include __DIR__ . '/views/html-appointment-staff-fields.php';
			wp_send_json(
			    [
					'html' => ob_get_clean(),
				],
			);
		}

		wp_send_json(
		    [
				'error' => __( 'Unable to add product', 'woocommerce-appointments' ),
			],
		);
	}

	/**
	 * Start GCal sync process (standardized with reindex pattern).
	 */
	public function start_gcal_sync(): void {
		check_ajax_referer( 'wc_appointments_admin_nonce', '_wpnonce' );

		if ( ! current_user_can( 'manage_appointments' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'staff_id' );

		if ( ! WC_Appointments_Staff_Permissions::can_manage_gcal_for_staff( $user_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		try {
			// Initialize GCal integration.
			$gcal_integration_class = wc_appointments_gcal();
			if ( $user_id ) {
				$gcal_integration_class->set_user_id( $user_id );
			} else {
				$gcal_integration_class->set_user_id( false );
			}

			// Backup existing synced availability rules before deletion.
			$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
			$filter = $user_id
				? [
					[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#staff' ],
					[ 'key' => 'kind_id', 'compare' => '=', 'value' => $user_id ],
					[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
				]
				: [
					[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#global' ],
					[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
				];

			$existing_rules = $availability_data_store->get_all( $filter );

			// Store backup with extended expiry (24 hours for revert option).
			$backup_data = [];
			foreach ( $existing_rules as $rule ) {
				$backup_data[] = [
					'id'           => $rule->get_id(),
					'event_id'     => $rule->get_event_id(),
					'title'        => $rule->get_title(),
					'range_type'   => $rule->get_range_type(),
					'from_range'   => $rule->get_from_range(),
					'to_range'     => $rule->get_to_range(),
					'from_date'    => $rule->get_from_date(),
					'to_date'      => $rule->get_to_date(),
					'appointable'  => $rule->get_appointable(),
					'priority'     => $rule->get_priority(),
					'ordering'     => $rule->get_ordering(),
					'rrule'        => $rule->get_rrule(),
					'kind'         => $rule->get_kind(),
					'kind_id'      => $rule->get_kind_id(),
				];
			}

			$backup_key = $user_id ? 'wc_appointments_gcal_backup_staff_' . $user_id : 'wc_appointments_gcal_backup_global';
			set_transient( $backup_key, $backup_data, DAY_IN_SECONDS );

			// Initialize progress tracking.
			$progress_key = $user_id ? 'wc_appointments_gcal_sync_progress_' . $user_id : 'wc_appointments_gcal_sync_progress';
			$progress = [
				'status'       => 'preparing',
				'user_id'      => $user_id,
				'phase'        => 'backup',
				'message'      => __( 'Backing up existing rules...', 'woocommerce-appointments' ),
				'started_at'   => time(),
				'updated_at'   => time(),
			];
			update_option( $progress_key, $progress, false );

			wp_send_json_success( [
				'message'  => __( 'GCal sync started successfully.', 'woocommerce-appointments' ),
				'progress' => $progress,
			] );
		} catch ( Exception $e ) {
			wp_send_json_error( [
				'message' => sprintf(
					/* translators: %s: error message */
					__( 'An error occurred: %s', 'woocommerce-appointments' ),
					$e->getMessage()
				),
			] );
		}
	}

	/**
	 * Stop GCal sync process.
	 */
	public function stop_gcal_sync(): void {
		check_ajax_referer( 'wc_appointments_admin_nonce', '_wpnonce' );

		if ( ! current_user_can( 'manage_appointments' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'staff_id' );

		if ( ! WC_Appointments_Staff_Permissions::can_manage_gcal_for_staff( $user_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		try {
			$progress_key = $user_id ? 'wc_appointments_gcal_sync_progress_' . $user_id : 'wc_appointments_gcal_sync_progress';
			$progress = get_option( $progress_key, [] );

			if ( isset( $progress['status'] ) && in_array( $progress['status'], [ 'running', 'preparing' ], true ) ) {
				$progress['status'] = 'stopped';
				$progress['updated_at'] = time();
				update_option( $progress_key, $progress, false );

				wp_send_json_success( [
					'message'  => __( 'GCal sync stopped successfully.', 'woocommerce-appointments' ),
					'progress' => $progress,
				] );
			} else {
				wp_send_json_success( [
					'message'  => __( 'No active GCal sync to stop.', 'woocommerce-appointments' ),
					'progress' => $progress,
				] );
			}
		} catch ( Exception $e ) {
			wp_send_json_error( [
				'message' => sprintf(
					/* translators: %s: error message */
					__( 'An error occurred: %s', 'woocommerce-appointments' ),
					$e->getMessage()
				),
			] );
		}
	}

	/**
	 * Process GCal sync chunk.
	 */
	public function process_gcal_sync_chunk(): void {
		check_ajax_referer( 'wc_appointments_admin_nonce', '_wpnonce' );

		if ( ! current_user_can( 'manage_appointments' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'staff_id' );

		if ( ! WC_Appointments_Staff_Permissions::can_manage_gcal_for_staff( $user_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$progress_key = $user_id ? 'wc_appointments_gcal_sync_progress_' . $user_id : 'wc_appointments_gcal_sync_progress';
		$progress = get_option( $progress_key, [] );

		if ( empty( $progress ) || ! isset( $progress['status'] ) ) {
			wp_send_json_error( [ 'message' => __( 'No active sync process.', 'woocommerce-appointments' ) ] );
		}

		if ( in_array( $progress['status'], [ 'stopped', 'completed' ], true ) ) {
			wp_send_json_success( [ 'progress' => $progress ] );
		}

		try {
			$phase = $progress['phase'] ?? 'backup';

			if ( 'backup' === $phase ) {
				// Store persistent backup BEFORE sync/deletion.
				$existing_rules = $this->get_synced_rules( $user_id );
				$backup_rules = array_map(
					[ $this, 'serialize_rule' ],
					array_filter( $existing_rules, function( $rule ) {
						$parent_id = $rule->get_parent_event_id();
						return ! $parent_id;
					} )
				);

				if ( ! empty( $backup_rules ) ) {
					$this->store_persistent_backup( $user_id, $backup_rules );
				}

				// Move to deletion phase.
				$progress['phase'] = 'delete';
				$progress['status'] = 'running';
				$progress['message'] = __( 'Clearing old synced rules...', 'woocommerce-appointments' );
				$progress['updated_at'] = time();
				update_option( $progress_key, $progress, false );

			} elseif ( 'delete' === $phase ) {
				// Delete existing synced rules.
				$gcal_integration_class = wc_appointments_gcal();
				if ( $user_id ) {
					$gcal_integration_class->set_user_id( $user_id );
				} else {
					$gcal_integration_class->set_user_id( false );
				}

				// Temporarily remove the delete_availability hook.
				remove_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

				$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
				$filter = $user_id
					? [
						[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#staff' ],
						[ 'key' => 'kind_id', 'compare' => '=', 'value' => $user_id ],
						[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
					]
					: [
						[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#global' ],
						[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
					];

				$existing_rules = $availability_data_store->get_all( $filter );
				foreach ( $existing_rules as $rule ) {
					$rule->delete();
				}

				// Re-attach the hook.
				add_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

				// Clear the incremental sync token for full re-sync.
				if ( $user_id ) {
					delete_option( 'wc_appointments_gcal_sync_token_' . $user_id );
				} else {
					delete_option( 'wc_appointments_gcal_sync_token' );
				}

				// Move to sync phase.
				$progress['phase'] = 'sync';
				$progress['message'] = __( 'Syncing from Google Calendar...', 'woocommerce-appointments' );
				$progress['updated_at'] = time();
				update_option( $progress_key, $progress, false );

			} elseif ( 'sync' === $phase ) {
				// Perform the actual sync.
				$gcal_integration_class = wc_appointments_gcal();
				if ( $user_id ) {
					$gcal_integration_class->set_user_id( $user_id );
				} else {
					$gcal_integration_class->set_user_id( false );
				}

				$gcal_integration_class->set_manual_full_resync( true );
				$gcal_integration_class->sync_from_gcal();
				$gcal_integration_class->set_manual_full_resync( false );

				// Count synced rules.
				$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
				$filter = $user_id
					? [
						[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#staff' ],
						[ 'key' => 'kind_id', 'compare' => '=', 'value' => $user_id ],
						[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
					]
					: [
						[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#global' ],
						[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
					];

				$active_rules = $availability_data_store->get_all( $filter );

				// Filter to only rules created in the last 2 minutes.
				$now = time();
				$just_synced = array_filter( $active_rules, function( $rule ) use ( $now ) {
					$parent_id = $rule->get_parent_event_id();
					if ( $parent_id ) {
						return false;
					}
					$created = $rule->get_date_created();
					if ( ! $created ) {
						return false;
					}
					$created_ts = $created->getTimestamp();
					return ( $now - $created_ts ) < 120;
				} );

				$synced_count = count( $just_synced );


				// Mark as completed.
				$progress['status'] = 'completed';
				$progress['phase'] = 'complete';
				$progress['message'] = sprintf(
					/* translators: %d: number of events synced */
					__( 'Successfully synced %d event(s) from Google Calendar.', 'woocommerce-appointments' ),
					$synced_count
				);
				$progress['synced_count'] = $synced_count;
				$progress['completed_at'] = time();
				$progress['updated_at'] = time();
				update_option( $progress_key, $progress, false );

				// Store last manual sync info in a dedicated key.
				$last_sync_key = $user_id ? 'wc_appointments_gcal_last_manual_sync_staff_' . $user_id : 'wc_appointments_gcal_last_manual_sync';
				update_option( $last_sync_key, [
					'timestamp'    => time(),
					'synced_count' => $synced_count,
				], false );
			}

			wp_send_json_success( [ 'progress' => $progress ] );

		} catch ( Exception $e ) {
			// Sync failed - mark as failed and keep backup for revert.
			$progress['status'] = 'failed';
			$progress['message'] = sprintf(
				/* translators: %s: error message */
				__( 'An error occurred: %s', 'woocommerce-appointments' ),
				$e->getMessage()
			);
			$progress['updated_at'] = time();
			update_option( $progress_key, $progress, false );

			wp_send_json_error( [
				'message'  => $progress['message'],
				'progress' => $progress,
			] );
		}
	}

	/**
	 * Clear GCal sync progress data.
	 */
	public function clear_gcal_sync_progress(): void {
		check_ajax_referer( 'wc_appointments_admin_nonce', '_wpnonce' );

		if ( ! current_user_can( 'manage_appointments' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'staff_id' );

		if ( ! WC_Appointments_Staff_Permissions::can_manage_gcal_for_staff( $user_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$progress_key = $user_id ? 'wc_appointments_gcal_sync_progress_' . $user_id : 'wc_appointments_gcal_sync_progress';
		delete_option( $progress_key );

		wp_send_json_success();
	}

	/**
	 * Manually perform calendar sync (legacy method - kept for backwards compatibility).
	 */
	public function manual_sync(): void {
		check_ajax_referer( 'add-manual-sync', 'security' );

		$user_id = self::post_absint_key( 'staff_id' );

		if ( ! WC_Appointments_Staff_Permissions::can_manage_gcal_for_staff( $user_id ) ) {
			wp_send_json_error( [ 'error' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		if ( $user_id ) {

			// Run GCal sync manually.
			$gcal_integration_class = wc_appointments_gcal();
			$gcal_integration_class->set_user_id( $user_id );

			// Backup existing synced availability rules before deletion.
			$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
			$existing_rules = $availability_data_store->get_all(
				[
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => 'availability#staff',
					],
					[
						'key'     => 'kind_id',
						'compare' => '=',
						'value'   => $user_id,
					],
					[
						'key'     => 'event_id',
						'compare' => '!=',
						'value'   => '',
					],
				]
			);

			// Store backup as serialized data in a transient (expires in 24 hours).
			$backup_data = [];
			foreach ( $existing_rules as $rule ) {
				$backup_data[] = [
					'event_id'         => $rule->get_event_id(),
					'parent_event_id'  => $rule->get_parent_event_id(),
					'title'            => $rule->get_title(),
					'range_type'       => $rule->get_range_type(),
					'from_range'       => $rule->get_from_range(),
					'to_range'         => $rule->get_to_range(),
					'from_date'        => $rule->get_from_date(),
					'to_date'          => $rule->get_to_date(),
					'appointable'      => $rule->get_appointable(),
					'priority'         => $rule->get_priority(),
					'qty'              => $rule->get_qty(),
					'ordering'         => $rule->get_ordering(),
					'rrule'            => $rule->get_rrule(),
					'kind'             => $rule->get_kind(),
					'kind_id'          => $rule->get_kind_id(),
				];
			}
			set_transient( 'wc_appointments_gcal_backup_staff_' . $user_id, $backup_data, DAY_IN_SECONDS );

			// Clear the incremental sync token so the manual sync performs a full
			// window-based fetch instead of a delta-only fetch. This ensures all
			// existing Google Calendar events are re-imported, not just changes.
			delete_option( 'wc_appointments_gcal_sync_token_' . $user_id );

			// CRITICAL: Temporarily remove the delete_availability hook to prevent
			// deleting events from Google Calendar during local cleanup.
			// We're only cleaning up local synced rules to re-import fresh data.
			remove_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

			// Delete existing synced availability rules to ensure clean re-import.
			// This fixes legacy all-day rules that have an extra day due to the bug fixed in 5.3.0-beta-6.
			foreach ( $existing_rules as $rule ) {
				$rule->delete();
			}

			// Re-attach the hook after cleanup is complete.
			add_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

			// Perform the sync.
			try {
				$gcal_integration_class->set_manual_full_resync( true );
				$gcal_integration_class->sync_from_gcal();
			} catch ( Exception $e ) {
				$gcal_integration_class->set_manual_full_resync( false );
				// Sync failed - restore from backup.
				$this->restore_availability_backup( $user_id, true );
				wp_send_json(
					[
						'error' => sprintf(
							/* translators: %s: error message */
							__( 'An error occurred: %s', 'woocommerce-appointments' ),
							$e->getMessage()
						),
					]
				);
				return;
			}

			$gcal_integration_class->set_manual_full_resync( false );

			// Read the updated sync data that sync_from_gcal() just set.
			// Do not overwrite it - gcal_fetch_events() already stored the correct timestamp and event count.
			$last_synced_saved     = get_user_meta( $user_id, 'wc_appointments_gcal_availability_last_synced', true );
			$last_synced_timestamp = ( $last_synced_saved[0] ?? false ) ? self::wca_abs_int( $last_synced_saved[0] ) : self::wca_abs_int( current_time( 'timestamp' ) );
			$last_synced_counter   = ( $last_synced_saved[1] ?? false ) ? self::wca_abs_int( $last_synced_saved[1] ) : 0;

		} else {

			// Run GCal sync manually.
			$gcal_integration_class = wc_appointments_gcal();
			// Reset to global context before syncing.
			$gcal_integration_class->set_user_id( false );

			// Backup existing synced global availability rules before deletion.
			$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
			$existing_rules = $availability_data_store->get_all(
				[
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => 'availability#global',
					],
					[
						'key'     => 'event_id',
						'compare' => '!=',
						'value'   => '',
					],
				]
			);

			// Store backup as serialized data in a transient (expires in 24 hours).
			$backup_data = [];
			foreach ( $existing_rules as $rule ) {
				$backup_data[] = [
					'event_id'         => $rule->get_event_id(),
					'parent_event_id'  => $rule->get_parent_event_id(),
					'title'            => $rule->get_title(),
					'range_type'       => $rule->get_range_type(),
					'from_range'       => $rule->get_from_range(),
					'to_range'         => $rule->get_to_range(),
					'from_date'        => $rule->get_from_date(),
					'to_date'          => $rule->get_to_date(),
					'appointable'      => $rule->get_appointable(),
					'priority'         => $rule->get_priority(),
					'qty'              => $rule->get_qty(),
					'ordering'         => $rule->get_ordering(),
					'rrule'            => $rule->get_rrule(),
					'kind'             => $rule->get_kind(),
					'kind_id'          => $rule->get_kind_id(),
				];
			}
			set_transient( 'wc_appointments_gcal_backup_global', $backup_data, DAY_IN_SECONDS );

			// Clear the incremental sync token so the manual sync performs a full
			// window-based fetch instead of a delta-only fetch.
			delete_option( 'wc_appointments_gcal_sync_token' );

			// CRITICAL: Temporarily remove the delete_availability hook to prevent
			// deleting events from Google Calendar during local cleanup.
			// We're only cleaning up local synced rules to re-import fresh data.
			remove_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

			// Delete existing synced global availability rules to ensure clean re-import.
			// This fixes legacy all-day rules that have an extra day due to the bug fixed in 5.3.0-beta-6.
			foreach ( $existing_rules as $rule ) {
				$rule->delete();
			}

			// Re-attach the hook after cleanup is complete.
			add_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

			// Perform the sync.
			try {
				$gcal_integration_class->set_manual_full_resync( true );
				$gcal_integration_class->sync_from_gcal();
			} catch ( Exception $e ) {
				$gcal_integration_class->set_manual_full_resync( false );
				// Sync failed - restore from backup.
				$this->restore_availability_backup( 0, false );
				wp_send_json(
					[
						'error' => sprintf(
							/* translators: %s: error message */
							__( 'An error occurred: %s', 'woocommerce-appointments' ),
							$e->getMessage()
						),
					]
				);
				return;
			}

			$gcal_integration_class->set_manual_full_resync( false );

			// Read the updated sync data that sync_from_gcal() just set.
			// Do not overwrite it - gcal_fetch_events() already stored the correct timestamp and event count.
			$last_synced_saved     = get_option( 'wc_appointments_gcal_availability_last_synced' );
			$last_synced_timestamp = ( $last_synced_saved[0] ?? false ) ? self::wca_abs_int( $last_synced_saved[0] ) : self::wca_abs_int( current_time( 'timestamp' ) );
			$last_synced_counter   = ( $last_synced_saved[1] ?? false ) ? self::wca_abs_int( $last_synced_saved[1] ) : 0;

		}

		// For manual re-sync, we need to count the rules that were actually synced.
		// After deleting old rules and re-syncing, count the newly created rules.
		$is_manual_sync = defined( 'DOING_AJAX' ) && DOING_AJAX && 'woocommerce_manual_sync' === self::post_text( 'action' );

		if ( $is_manual_sync ) {
			// Count total active synced rules for this context that were just created.
			// Since we deleted all old synced rules before re-syncing, all current synced rules
			// are the ones that were just imported.
			$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
			$filter = $user_id
				? [
					[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#staff' ],
					[ 'key' => 'kind_id', 'compare' => '=', 'value' => $user_id ],
					[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
				]
				: [
					[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#global' ],
					[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
				];
			$active_rules = $availability_data_store->get_all( $filter );

			// Log detailed information about what was synced.
			if ( 'yes' === get_option( 'wc_appointments_gcal_debug' ) ) {
				wc_add_appointment_log( 'gcal', '=== MANUAL SYNC COMPLETE ===' );
				wc_add_appointment_log( 'gcal', 'Total active synced rules after sync: ' . count( $active_rules ) );

				foreach ( $active_rules as $rule ) {
					$created = $rule->get_date_created();
					$created_str = $created ? $created->format( 'Y-m-d H:i:s' ) : 'unknown';
					wc_add_appointment_log( 'gcal', sprintf(
						'Rule #%d: event_id=%s, title=%s, range_type=%s, created=%s',
						$rule->get_id(),
						$rule->get_event_id(),
						$rule->get_title(),
						$rule->get_range_type(),
						$created_str
					) );
				}
			}

			// Filter to only rules created in the last minute (just synced).
			// Exclude modified instance rules (those with a parent_event_id) as they're counted as part of their parent.
			$now = time();
			$just_synced = array_filter( $active_rules, function( $rule ) use ( $now ) {
				// Exclude modified instance rules - they have a parent_event_id set.
				// Modified instances are part of their parent recurring event and shouldn't be counted separately.
				$parent_id = $rule->get_parent_event_id();
				if ( $parent_id ) {
					return false;
				}

				$created = $rule->get_date_created();
				if ( ! $created ) {
					return false;
				}
				$created_ts = $created->getTimestamp();
				// Rule was created in the last 2 minutes (generous window for slow syncs).
				return ( $now - $created_ts ) < 120;
			} );

			if ( 'yes' === get_option( 'wc_appointments_gcal_debug' ) ) {
				wc_add_appointment_log( 'gcal', 'Rules created in last 2 minutes: ' . count( $just_synced ) );
				wc_add_appointment_log( 'gcal', 'Current timestamp: ' . $now );
			}

			$last_synced_counter = count( $just_synced );

			// Store persistent backup after successful sync (exclude exceptions).
			$backup_rules = array_map(
				[ $this, 'serialize_rule' ],
				array_filter( $active_rules, function( $rule ) {
					$parent_id = $rule->get_parent_event_id();
					return ! $parent_id;
				} )
			);
			$this->store_persistent_backup( $user_id, $backup_rules );
		}

		// Last sycned event count, date, time.
		$ls_message  = sprintf( '%1$s, %2$s', date_i18n( wc_appointments_date_format(), $last_synced_timestamp ), date_i18n( wc_appointments_time_format(), $last_synced_timestamp ) );
		$ls_message .= ' - ';
		if ( $user_id ) {
			/* translators: %1$s: link to synced rules, %2$s: sync text */
			$ls_message .= sprintf(
			    '<a href="%1$s" onclick="location.reload()">%2$s</a>',
			    esc_url( admin_url( "user-edit.php?user_id=$user_id#staff-details" ) ),
			    __( 'check synced events', 'woocommerce-appointments' ),
			);
		} else {
			/* translators: %1$s: link to synced rules, %2$s: sync text */
			$ls_message .= sprintf(
			    '<a href="%1$s">%2$s</a>',
			    esc_url( admin_url( 'admin.php?page=wc-settings&tab=appointments&view=synced' ) ),
			    __( 'check synced events', 'woocommerce-appointments' ),
			);
		}

		wp_send_json(
		    [
				'result'  => 'SUCCESS',
				'html'    => $ls_message,
				'message' => sprintf(
					/* translators: %d: number of events synced */
					__( 'Successfully synced %d event(s) from Google Calendar.', 'woocommerce-appointments' ),
					$last_synced_counter
				),
			],
		);

		die();
	}

	/**
	 * Restore availability rules from backup after a failed sync.
	 *
	 * @param int  $user_id User ID for staff sync, or 0 for global sync.
	 * @param bool $is_staff Whether this is a staff sync or global sync.
	 */
	private function restore_availability_backup( int $user_id, bool $is_staff ): void {
		$transient_key = $is_staff ? 'wc_appointments_gcal_backup_staff_' . $user_id : 'wc_appointments_gcal_backup_global';
		$backup_data   = get_transient( $transient_key );

		if ( ! $backup_data || ! is_array( $backup_data ) ) {
			return;
		}

		$this->restore_rules( $backup_data, $user_id, $is_staff );
		delete_transient( $transient_key );
	}

	/**
	 * Manually perform calendar sync.
	 */
	public function oauth_redirect(): void {
		check_ajax_referer( 'add-oauth-redirect', 'security' );

		$user_id = self::post_absint_key( 'staff_id' );
		$logout  = (bool) self::post_raw( 'logout', false );

		if ( ! WC_Appointments_Staff_Permissions::can_manage_gcal_for_staff( $user_id ) ) {
			wp_send_json_error( [ 'error' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		if ( $user_id ) {
			// Run Gcal oauth redirect.
			$gcal_integration_class = wc_appointments_gcal();
			$gcal_integration_class->set_user_id( $user_id );

			// OAuth2: prompt=consent replaces deprecated approval_prompt=force; required for reliable refresh_token.
			// If users see "This app isn't verified" / "app not authorized", add them as Test users in
			// Google Cloud Console (APIs & Services → OAuth consent screen → Test users) or publish the app.
			$oauth_params = apply_filters(
				'wc_appointments_gcal_oauth_auth_params',
				[
					'scope'         => $gcal_integration_class->api_scope,
					'redirect_uri'  => $gcal_integration_class->get_redirect_uri(),
					'response_type' => 'code',
					'client_id'     => $gcal_integration_class->get_client_id(),
					'prompt'        => 'consent',
					'access_type'   => 'offline',
					'state'         => $gcal_integration_class->create_oauth_state( (int) $user_id ),
				],
				$user_id,
				$gcal_integration_class
			);
			$oauth_url = add_query_arg( $oauth_params, $gcal_integration_class->oauth_uri );

			// Logout.
			if ( $logout ) {
				$oauth_url = add_query_arg(
				    [
						'logout' => 'true',
						'state'  => $gcal_integration_class->create_oauth_state( (int) $user_id ),
					],
				    $gcal_integration_class->get_redirect_uri(),
				);
			// Run GCal sync for the first time.
			} else {
				$gcal_integration_class->sync_from_gcal();
			}
		} else {
			// Run Gcal oauth redirect.
			$gcal_integration_class = wc_appointments_gcal();

			// OAuth2: prompt=consent replaces deprecated approval_prompt=force; required for reliable refresh_token.
			$oauth_params = apply_filters(
				'wc_appointments_gcal_oauth_auth_params',
				[
					'scope'         => $gcal_integration_class->api_scope,
					'redirect_uri'  => $gcal_integration_class->get_redirect_uri(),
					'response_type' => 'code',
					'client_id'     => $gcal_integration_class->get_client_id(),
					'prompt'        => 'consent',
					'access_type'   => 'offline',
					'state'         => $gcal_integration_class->create_oauth_state( 0 ),
				],
				0,
				$gcal_integration_class
			);
			$oauth_url = add_query_arg( $oauth_params, $gcal_integration_class->oauth_uri );

			// Logout.
			if ( $logout ) {
				$oauth_url = add_query_arg(
				    [
						'logout' => 'true',
						'state'  => $gcal_integration_class->create_oauth_state( 0 ),
					],
				    $gcal_integration_class->get_redirect_uri(),
				);
			// Run GCal sync for the first time.
			} else {
				$gcal_integration_class->sync_from_gcal();
			}
		}

		wp_send_json(
		    [
				'result' => 'SUCCESS',
				'uri'    => $oauth_url,
			],
		);

		die();
	}

	/**
	 * Search for appointable products and return json.
	 *
	 * @see WC_AJAX::json_search_appointable_products()
	 */
	public static function json_search_appointable_products(): void {
		check_ajax_referer( 'search-products', 'security' );

		$limit      = self::get_absint_key( 'limit' ) ?: self::wca_abs_int( apply_filters( 'woocommerce_json_search_limit', 30 ) );
		$page       = max( 1, self::get_absint_key( 'page' ) ?: 1 );
		$term       = self::get_text( 'term' );
		$current_id = self::get_absint_key( 'current_id' );

		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			'paged'          => $page,
			'fields'         => 'ids',
			'tax_query'      => [
				[
					'taxonomy' => 'product_type',
					'field'    => 'slug',
					'terms'    => 'appointment',
				],
			],
		];

		if ( ! empty( $term ) ) {
			$args['s'] = $term;
		}

		$include = self::get_raw( 'include', [] );
		if ( ! empty( $include ) ) {
			$args['post__in'] = array_map(
				function( $id ) {
					return self::wca_abs_int( $id );
				},
				(array) $include
			);
		}
		$exclude = self::get_raw( 'exclude', [] );
		if ( ! empty( $exclude ) ) {
			$args['post__not_in'] = array_map(
				function( $id ) {
					return self::wca_abs_int( $id );
				},
				(array) $exclude
			);
		}

		$query           = new WP_Query( $args );
		$product_objects = array_filter( array_map( 'get_wc_product_appointment', $query->posts ), 'wc_products_array_filter_readable' );

		// If term is empty and page is 1, ensure current product is at the top of results.
		if ( $current_id && empty( $term ) && 1 === $page ) {
			$current_product = get_wc_product_appointment( $current_id );
			if ( $current_product && $current_product->is_type( 'appointment' ) && wc_products_array_filter_readable( $current_product ) ) {
				// Remove it if it's already in the list to avoid duplicates.
				$product_objects = array_filter( $product_objects, function( $p ) use ( $current_id ) {
					return $p->get_id() !== $current_id;
				} );
				array_unshift( $product_objects, $current_product );
			}
		}

		$products        = [];
		$current_user_id = get_current_user_id();

		// Check if user is staff with limited permissions.
		$is_staff_user  = class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $current_user_id );
		$can_create_any = $is_staff_user ? WC_Appointments_Staff_Permissions::can( $current_user_id, 'create_appointments_any' ) : true;
		$filter_by_staff = $is_staff_user && ! $can_create_any;

		foreach ( $product_objects as $product_object ) {
			if ( ! $product_object->is_type( 'appointment' ) ) {
				continue;
			}
			$staff_ids = $product_object->get_staff_ids();

			// If staff user without create_appointments_any permission, only show assigned products.
			// However, if the product has NO staff assigned, we allow it (as requested).
			if ( $filter_by_staff && ! empty( $staff_ids ) ) {
				if ( ! in_array( $current_user_id, array_map( 'intval', (array) $staff_ids ), true ) ) {
					continue;
				}
			}

			$products[ $product_object->get_id() ] = self::wca_format_appointable_product_select_label( $product_object, $current_user_id, false, false );
		}

		if ( null !== self::get_raw( 'page', null ) ) {
			wp_send_json( [
				'results' => $products,
				'more'    => $query->max_num_pages > $page,
			] );
		}

		wp_send_json( $products );
	}

	/**
	 * Mark an appointment confirmed
	 */
	public function mark_appointment_confirmed(): void {
		if ( ! current_user_can( 'manage_appointments' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'woocommerce-appointments' ) );
		}
		if ( ! check_admin_referer( 'wc-appointment-confirm' ) ) {
			wp_die( esc_html__( 'You have taken too long. Please go back and retry.', 'woocommerce-appointments' ) );
		}

		// Check staff-specific permission for managing appointment status.
		$user_id = get_current_user_id();
		if ( class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
			if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_appointment_status' ) ) {
				wp_die( esc_html__( 'You do not have permission to change appointment status.', 'woocommerce-appointments' ) );
			}
		}
		$appointment_id = self::get_absint_key( 'appointment_id' );
		if ( ! $appointment_id ) {
			die;
		}

		if ( ! current_user_can( 'edit_post', $appointment_id ) ) {
			wp_die( esc_html__( 'You do not have permission to edit this appointment.', 'woocommerce-appointments' ) );
		}

		$appointment = get_wc_appointment( $appointment_id );
		if ( WC_Appointments_Constants::STATUS_CONFIRMED !== $appointment->get_status() ) {
			$appointment->update_status( WC_Appointments_Constants::STATUS_CONFIRMED );
		}

		wp_safe_redirect( wp_get_referer() );
		die();
	}

	/**
	 * Calculate costs
	 *
	 * Take posted appointment form values and then use these to quote a price for what has been chosen.
	 * Returns a string which is appended to the appointment form.
	 */
	public function calculate_costs(): void {
		if ( class_exists( 'WC_Appointments_Rate_Limiter' ) ) {
			WC_Appointments_Rate_Limiter::throttle_guest_read_with_optional_nonce(
				'calculate_costs',
				WC_Appointments_Rate_Limiter::GUEST_READ_MAX_REQUESTS,
				WC_Appointments_Rate_Limiter::GUEST_READ_WINDOW_SECONDS
			);
		}

		// Set a flag to prevent currency conversion in admin
		// This ensures appointment costs are shown in base currency in admin panel
		// Check referer to distinguish admin AJAX from front-end AJAX (is_admin() is true for all AJAX)
		$referer = esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ?? '' ) );
		$is_admin_request = ( $referer && ( strpos( $referer, '/wp-admin/' ) !== false || strpos( $referer, (string) admin_url() ) !== false ) );

		if ( $is_admin_request && ! defined( 'WC_APPOINTMENTS_ADMIN_CREATE' ) ) {
			define( 'WC_APPOINTMENTS_ADMIN_CREATE', true );
		}

		$posted = self::post_form_array();

		$product_id = self::wca_abs_int( $posted['add-to-cart'] ?? 0 );
		if ( ! $product_id && isset( $posted['appointable-product-id'] ) ) {
			$product_id = self::wca_abs_int( $posted['appointable-product-id'] );
		}
		$product = get_wc_product_appointment( $product_id );

		if ( ! $product ) {
			wp_send_json(
			    [
					'result'  => 'ERROR',
					'success' => false,
					'html'    => apply_filters(
					    'woocommerce_appointments_appointment_cost_html',
					    '<span class="appointment-error">' . __( 'This appointment is unavailable.', 'woocommerce-appointments' ) . '</span>',
					    null,
					    $posted,
					),
					'data'    => [
						'html' => apply_filters(
						    'woocommerce_appointments_appointment_cost_html',
						    '<span class="appointment-error">' . __( 'This appointment is unavailable.', 'woocommerce-appointments' ) . '</span>',
						    null,
						    $posted,
						),
					],
				],
			);
		}

		$form = new WC_Appointment_Form( $product );
		$cost = WC_Appointments_Cost_Calculation::calculate_appointment_cost( $posted, $product );

		if ( is_wp_error( $cost ) ) {
			wp_send_json(
			    [
					'result'  => 'ERROR',
					'success' => false,
					'html'    => apply_filters(
					    'woocommerce_appointments_appointment_cost_html',
					    '<span class="appointment-error">' . $cost->get_error_message() . '</span>',
					    null,
					    $posted,
					),
					'data'    => [
						'html' => apply_filters(
						    'woocommerce_appointments_appointment_cost_html',
						    '<span class="appointment-error">' . $cost->get_error_message() . '</span>',
						    null,
						    $posted,
						),
					],
				],
			);
		}

		// Admin appointment panel: when catalog prices are entered excl. tax, quote net amounts (matches override_price_excl_tax).
		// When prices are entered incl. tax, omit this flag (see wcaPanel.pricesIncludeTax) so gross display matches the merchant basis.
		$panel_cost_excl_tax = '1' === self::post_text( 'wc_appointments_panel_cost_excl_tax' )
			&& $is_admin_request && current_user_can( 'edit_appointments' );

		$qty_line    = isset( $posted['quantity'] ) ? max( 1, (int) $posted['quantity'] ) : 1;
		$dep_option  = isset( $posted['wc_deposit_option'] ) ? sanitize_text_field( (string) $posted['wc_deposit_option'] ) : '';
		$plan_id     = isset( $posted['wc_deposit_payment_plan'] ) ? absint( $posted['wc_deposit_payment_plan'] ) : 0;
		if ( class_exists( 'WC_Deposits_Product_Manager' ) && WC_Deposits_Product_Manager::deposits_forced( $product_id ) ) {
			$dep_option = 'yes';
		}

		$deposit_totals  = wc_appointments_resolve_deposit_line_net( $product, (float) $cost, $qty_line, $dep_option, $plan_id );
		$display_amounts = self::wca_panel_display_amounts( $product, (float) $cost, $deposit_totals, $qty_line, $panel_cost_excl_tax, $is_admin_request );
		$full_display    = $display_amounts['full'];
		$display_price   = $display_amounts['line'];
		$deposit_applied = $deposit_totals['deposit_applied'];

		$is_panel_quote = is_admin() && current_user_can( 'edit_appointments' );
		$wc_price_args  = $is_panel_quote ? [ 'currency' => get_woocommerce_currency() ] : [];
		$cost_html      = wc_price( $display_price, $wc_price_args );
		if ( ! $is_panel_quote ) {
			$qty_suffix = max( 1, $qty_line );
			$cost_html .= $product->get_price_suffix( $display_price / $qty_suffix, $qty_suffix );
		}

		$cost_label = $deposit_applied
			? _x( 'Deposit due', 'appointment deposit cost string', 'woocommerce-appointments' )
			: _x( 'Cost', 'appointment cost string', 'woocommerce-appointments' );

		$full_line_html = '';
		if ( $deposit_applied && $full_display > $display_price + 0.000001 ) {
			if ( $is_panel_quote ) {
				$full_line_html = ' <span class="wca-panel-deposit-full-amount description">' . sprintf(
					/* translators: %s: full appointment line amount */
					__( 'Full amount: %s', 'woocommerce-appointments' ),
					wc_price( $full_display, [ 'currency' => get_woocommerce_currency() ] )
				) . '</span>';
			}
		}

		if ( $deposit_applied && ! $is_panel_quote && $full_display > $display_price + 0.000001 ) {
			$full_amount_html = wc_price( $full_display );
			$appointment_cost_html = '
				<dl class="wca-deposit-cost-breakdown">
					<div class="wca-deposit-cost-row">
						<dt>' . esc_html( $cost_label ) . ':</dt>
						<dd><strong>' . $cost_html . '</strong></dd>
					</div>
					<div class="wca-deposit-cost-row wca-deposit-cost-row--full">
						<dt>' . esc_html( _x( 'Full amount', 'appointment deposit cost string', 'woocommerce-appointments' ) ) . ':</dt>
						<dd>' . $full_amount_html . '</dd>
					</div>
				</dl>
			';
		} else {
			$appointment_cost_html = '
				<dl>
					<dt>' . esc_html( $cost_label ) . ':</dt>
					<dd><strong>' . $cost_html . '</strong>' . $full_line_html . '</dd>
				</dl>
			';
		}
		$appointment_cost_html = apply_filters(
		    'woocommerce_appointments_appointment_cost_html',
		    $appointment_cost_html,
		    $product,
		    $posted,
		);

		wp_send_json(
		    [
				'result'     => 'SUCCESS',
				'success'    => true,
				'html'       => apply_filters(
				    'woocommerce_appointments_calculated_appointment_cost_success_output',
				    $appointment_cost_html,
				    $display_price,
				    $product,
				),
				'raw'        => (float) wc_format_decimal( $display_price, wc_get_price_decimals() ),
				'raw_price'  => (float) wc_format_decimal( $display_price, wc_get_price_decimals() ),
				'data'       => [
					'html'               => apply_filters(
					    'woocommerce_appointments_calculated_appointment_cost_success_output',
					    $appointment_cost_html,
					    $display_price,
					    $product,
					),
					'raw'                => (float) wc_format_decimal( $display_price, wc_get_price_decimals() ),
					'raw_price'          => (float) wc_format_decimal( $display_price, wc_get_price_decimals() ),
					'raw_full_price'     => (float) wc_format_decimal( $full_display, wc_get_price_decimals() ),
					'deposit_applied'    => $deposit_applied,
				],
			],
		);
	}

	/**
	 * Get a list of time slots available on a date
	 */
	public function get_time_slots_for_date(): bool {
		if ( class_exists( 'WC_Appointments_Rate_Limiter' ) ) {
			WC_Appointments_Rate_Limiter::throttle_guest_read_with_optional_nonce(
				'get_slots',
				WC_Appointments_Rate_Limiter::GUEST_READ_MAX_REQUESTS,
				WC_Appointments_Rate_Limiter::GUEST_READ_WINDOW_SECONDS
			);
		}

		// Clean posted data.
		$posted = self::post_form_array();

 		$product_id = self::wca_abs_int( $posted['add-to-cart'] ?? 0 );
 		if ( ! $product_id && isset( $posted['appointable-product-id'] ) ) {
 			$product_id = self::wca_abs_int( $posted['appointable-product-id'] );
 		}

 		// Product Checking.
 		$product = get_wc_product_appointment( $product_id );
		if ( ! $product ) {
			return false;
		}

		// Rescheduling appointment?
		if ( isset( $posted['reschedule-appointment'] ) && $posted['reschedule-appointment'] && isset( $posted['appointment-id'] ) ) {
			$appointment       = get_wc_appointment( self::wca_abs_int( $posted['appointment-id'] ) );
			$is_wc_appointment = is_a( $appointment, 'WC_Appointment' );

 			// Is appointment object?
 			if ( $is_wc_appointment ) {
 				// Make sure only appointment duration is set to product.
 				$appointment_duration = $appointment->get_duration_parameters();
 				$product->set_duration( $appointment_duration['duration'] );
 				$product->set_duration_unit( $appointment_duration['duration_unit'] );

 				// Make sure qty is taken into account.
 				if ( 1 < $product->get_qty() ) {
 					$remaining_qty = self::wca_abs_int( $product->get_qty() ) - self::wca_abs_int( $appointment->get_qty() );
 					$product->set_qty( max( $remaining_qty, 0 ) ); #negative number is set to 0.
 				}

 				// Make sure only appointment staff is set to product.
 				if ( $appointment->get_staff_ids() ) {
 					#$product->set_staff_assignment( 'automatic' );
 					$product->set_staff_ids( $appointment->get_staff_ids() );
 					$product->set_staff_nopref( '' );
				}
			}
		}

		// Addons duration (minutes; may be negative when an add-on shortens the booking).
		$addons_duration = (int) self::post_raw( 'duration', 0 );

		// Check selected date.
		if (
			! isset( $posted['wc_appointments_field_start_date_year'] )
			|| in_array( $posted['wc_appointments_field_start_date_year'], [ '', '0', [] ], true )
			|| ! isset( $posted['wc_appointments_field_start_date_month'] )
			|| in_array( $posted['wc_appointments_field_start_date_month'], [ '', '0', [] ], true )
			|| ! isset( $posted['wc_appointments_field_start_date_day'] )
			|| in_array( $posted['wc_appointments_field_start_date_day'], [ '', '0', [] ], true )
		) {
			die( esc_html__( 'Please enter a valid date.', 'woocommerce-appointments' ) );
		}

		$year      = max( date( 'Y' ), self::wca_abs_int( $posted['wc_appointments_field_start_date_year'] ) );
		$month     = self::wca_abs_int( $posted['wc_appointments_field_start_date_month'] );
		$day       = self::wca_abs_int( $posted['wc_appointments_field_start_date_day'] );
		$timestamp = strtotime( "{$year}-{$month}-{$day}" );
		if ( 0 === $timestamp || false === $timestamp ) {
			die( esc_html__( 'Please enter a valid date.', 'woocommerce-appointments' ) );
		}

 		// Intervals.
 		[$interval, $base_interval] = $product->get_intervals();

		// Adjust duration if extended/shortened with addons.
		// Apply on the product so Provider/engine and display filter use the same length as cart validation.
		if ( 0 !== $addons_duration ) {
			// Match wc_appointments_get_posted_data(): shorten below base is allowed;
			// an adjustment down to zero or below keeps the base interval.
			$adjusted = (int) $interval + $addons_duration;
			if ( 0 < $adjusted ) {
				$interval = $adjusted;
				$product->set_duration_unit( 'minute' );
				$product->set_duration( $interval );
			}
		}

		// TIMEZONE HANDLING FOR AVAILABILITY CHECKS:
		// ==========================================
		// This section handles timezone conversion when checking availability.
		// The key principle: Always compute availability in site timezone, but allow
		// customers to select times in their own timezone (if product supports it).
		//
		// Flow:
		// 1. Determine customer-selected timezone (from form or default to site timezone)
		// 2. Parse customer input in customer timezone
		// 3. Convert to site timezone for availability calculations
		// 4. Return timestamps that are UTC but represent site timezone times
		//
		// See TIMEZONE_ARCHITECTURE.md for detailed explanation.

		// Determine customer-selected timezone (for display and input parsing).
		// Future: This will come from customer account settings when implemented.
		$tz_selected = '';
		$is_admin_panel_request = isset( $posted['is_admin_panel'] ) && $posted['is_admin_panel'];
		$show_frontend_timezone = ! class_exists( 'WC_Appointments_Timezone_Helper' )
			|| WC_Appointments_Timezone_Helper::should_show_timezone( 'frontend', get_current_user_id() );
		// Use customer-selected timezone for the civil day window whenever the product supports it,
		// including wp-admin flows, so admin slot lists match the storefront for the same date pick.
		if ( $show_frontend_timezone && is_a( $product, 'WC_Product_Appointment' ) && $product->has_timezones() && ( isset( $posted['wc_appointments_field_timezone'] ) && ! in_array( $posted['wc_appointments_field_timezone'], [ '', '0', [] ], true ) ) ) {
			$tz_selected = sanitize_text_field( $posted['wc_appointments_field_timezone'] );
		}
		if ( ! $tz_selected && $show_frontend_timezone && is_a( $product, 'WC_Product_Appointment' ) && $product->has_timezones() && ! empty( $_COOKIE['appointments_time_zone'] ) ) {
			$tz_selected = sanitize_text_field( wp_unslash( $_COOKIE['appointments_time_zone'] ) );
		}
		if ( ! $tz_selected ) {
			$tz_selected = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : wc_timezone_string();
		}
		if ( empty( $tz_selected ) ) {
			$tz_selected = 'UTC';
		}
		$tz_site_string = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : wc_timezone_string();
		if ( empty( $tz_site_string ) ) {
			$tz_site_string = 'UTC';
		}
		$tz_site   = new DateTimeZone( wc_appointments_normalize_timezone( $tz_site_string ) );
		$tz_custom = new DateTimeZone( wc_appointments_normalize_timezone( $tz_selected ) );

		// Full calendar day in the customer's timezone as absolute UTC [start, end).
		// Do not use strtotime( Y-m-d ) here — that parses in PHP's default TZ (often UTC), not site TZ,
		// and mapping only the site-local date of one instant drops slots when the customer's day
		// spans two site-calendar days.
		$dt_day_local_start = new DateTimeImmutable( sprintf( '%04d-%02d-%02d 00:00:00', $year, $month, $day ), $tz_custom );
		$dt_day_local_end   = $dt_day_local_start->modify( '+1 day' );
		$from               = $dt_day_local_start->getTimestamp();
		$to                 = $dt_day_local_end->getTimestamp() + ( (int) $interval * MINUTE_IN_SECONDS );
		$time_to_check = 0;

		if ( isset($posted['wc_appointments_field_start_date_time']) && !in_array($posted['wc_appointments_field_start_date_time'], ['', '0', []], true) ) {
			try {
				// Sanitize time value: strip non-ASCII digits and normalize AM/PM to 24h H:i format.
				// Protects against localized digits (Arabic, Bengali) or theme JS reformatting.
				$raw_sel_time = $posted['wc_appointments_field_start_date_time'];
				$norm_sel_time = preg_replace( '/[^\d:aApPmM\s]/', '', $raw_sel_time );
				if ( preg_match( '/(\d{1,2}):(\d{2})\s*(AM|PM|am|pm)?/', $norm_sel_time, $stm ) ) {
					$sh = (int) $stm[1];
					$sm = (int) $stm[2];
					if ( ! empty( $stm[3] ) ) {
						$sp = strtoupper( $stm[3] );
						if ( 'PM' === $sp && $sh < 12 ) {
							$sh += 12;
						} elseif ( 'AM' === $sp && 12 === $sh ) {
							$sh = 0;
						}
					}
					$safe_time = sprintf( '%02d:%02d', $sh, $sm );
				} else {
					$safe_time = $raw_sel_time;
				}
				// Parse selected time in customer timezone, convert to site timezone.
				// Result is UTC timestamp representing site timezone time.
				$dt_sel_local  = new DateTimeImmutable( sprintf( '%04d-%02d-%02d %s', $year, $month, $day, $safe_time ), $tz_custom );
				$time_to_check = $dt_sel_local->setTimezone( $tz_site )->getTimestamp();
			} catch ( Exception $e ) {
				$time_to_check = 0;
			}
		}
 		$staff_id_to_check = empty( $posted['wc_appointments_field_staff'] ) ? 0 : $posted['wc_appointments_field_staff'];
		$requested_qty     = isset( $posted['quantity'] ) ? max( 1, (int) $posted['quantity'] ) : 1;

 		$staff_member      = $product->get_staff_member( self::wca_abs_int( $staff_id_to_check ) );
		$staff             = $product->get_staff();
		if ( $staff_id_to_check && $staff_member ) {
			$staff_id_to_check = $staff_member->get_id();
		} elseif ( ( $staff ) && count( $staff ) === 1 ) {
			$staff_id_to_check = current( $staff )->ID;
		} elseif ( $product->is_staff_assignment_type( 'all' ) ) {
			$staff_id_to_check = $product->get_staff_ids();
		} else {
			$staff_id_to_check = 0;
		}

		$location_id = absint( $posted['wc_appointments_field_location'] ?? $posted['location_id'] ?? 0 );
		if ( $location_id > 0 && class_exists( 'WC_Appointments_Location' ) && $product->has_locations() && ! WC_Appointments_Location::authorize_location_id( $product, $location_id ) ) {
			$location_id = 0;
		}

		$resource_id = absint( $posted['wc_appointments_field_resource'] ?? $posted['resource_id'] ?? 0 );
		if ( $resource_id > 0 && class_exists( 'WC_Appointments_Resource' ) && $product->has_resources() && ! WC_Appointments_Resource::authorize_resource_id( $product, $resource_id ) ) {
			$resource_id = 0;
		}

		// Use Provider as single source of truth — get native Collection directly.
		$include_sold_out = apply_filters( 'woocommerce_appointments_include_sold_out', false, $product );

		try {
			$collection = WC_Appointment_Slots_Provider::get_time_slots_collection(
				$product,
				$from,
				$to,
				$staff_id_to_check,
				false,
				false,
				$tz_selected,
				false,
				$location_id,
				$resource_id
			);

			// Auto-select: use availability engine for default time when product autoselect is on and no posted time.
			if ( ! $time_to_check && $product->get_availability_autoselect() ) {
				$staff_for_first_slot = is_array( $staff_id_to_check ) ? 0 : (int) $staff_id_to_check;
				$first_available_ts   = $collection->get_first_available_slot_timestamp( $staff_for_first_slot );
				if ( $first_available_ts ) {
					$time_to_check = (int) $first_available_ts;
				}
			}

			// Render HTML directly from Collection slots — no legacy conversion.
			$slot_html = WC_Appointments_Controller::render_time_slots_html(
				$product,
				$collection,
				[
					'intervals'        => [ $interval, $base_interval ],
					'staff_id'         => $staff_id_to_check,
					'time_to_check'    => $time_to_check,
					'from'             => $from,
					'to'               => $to,
					'timestamp'        => $timestamp,
					// Align HTML day bucketing with the same civil-day TZ used for $from/$to and Provider projection.
					'timezone'         => $tz_selected,
					'include_sold_out' => $include_sold_out,
					'min_qty'          => $requested_qty,
				],
			);
		} catch ( Exception $e ) {
			// Provider is single source of truth — return error message on failure.
			$slot_html = self::slot_notice_html( 'slot_error', __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
		}

		return self::emit_slot_html( $slot_html );
	}

	/**
	 * Search for orders and return json. Empty term returns last 10 orders when user can view orders.
	 */
	public function json_search_order(): void {
		global $wpdb;

		check_ajax_referer( 'search-appointment-order', 'security' );

		$can_view_orders = current_user_can( 'manage_woocommerce' ) || current_user_can( 'edit_shop_orders' );
		if ( ! $can_view_orders ) {
			wp_die( -1 );
		}

		$term = self::get_text( 'term' );

		$found_orders = [];

		// Empty term: return last 10 orders if user can view orders.
		if ( $term === '' ) {
			$order_ids = wc_get_orders(
				[
					'limit'   => 10,
					'orderby' => 'date',
					'order'   => 'DESC',
					'return'  => 'ids',
				]
			);
			foreach ( $order_ids as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( is_a( $order, 'WC_Order' ) ) {
					$found_orders[ $order->get_id() ] = $order->get_order_number() . ' &ndash; ' . date_i18n( wc_appointments_date_format(), strtotime( $order->get_date_created() ) );
				}
			}
			wp_send_json( $found_orders );
		}

		$term = apply_filters( 'woocommerce_appointment_json_search_order_number', $term );

		if ( WC_Appointment_Order_Compat::is_cot_enabled() ) {
			$query_orders = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id FROM {$wpdb->prefix}wc_orders AS wc_orders
					WHERE wc_orders.id LIKE %s
					LIMIT 10",
					$term . '%',
				),
			);
			if ( $query_orders ) {
				foreach ( $query_orders as $item ) {
					$order = wc_get_order( $item->id );
					if ( is_a( $order, 'WC_Order' ) ) {
						$found_orders[ $order->get_id() ] = $order->get_order_number() . ' &ndash; ' . date_i18n( wc_appointments_date_format(), strtotime( $order->get_date_created() ) );
					}
				}
			}
		} else {
			$query_orders = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} AS posts
					WHERE posts.post_type = 'shop_order'
					AND posts.ID LIKE %s
					LIMIT 10",
					$term . '%',
				),
			);
			if ( $query_orders ) {
				foreach ( $query_orders as $item ) {
					$order = wc_get_order( $item->ID );
					if ( is_a( $order, 'WC_Order' ) ) {
						$found_orders[ $order->get_id() ] = $order->get_order_number() . ' &ndash; ' . date_i18n( wc_appointments_date_format(), strtotime( $order->get_date_created() ) );
					}
				}
			}
		}

		wp_send_json( $found_orders );
	}

	/** Seconds without progress update before a running re-index is treated as stale. */
	private const REINDEX_STALE_SECONDS = 600;

	/**
	 * Clear manual re-index flags and queue so the site is never left in a half-finished state.
	 */
	private function cleanup_reindex_runtime_state(): void {
		delete_option( 'wc_appointments_manual_reindex_full_indexing' );
		delete_option( 'wc_appointments_index_queue' );
	}

	/**
	 * Release storefront locks after manual re-index reaches a terminal state.
	 *
	 * @param string $reason completed|failed|stopped|stale
	 */
	private function release_reindex_storefront_lock( string $reason ): void {
		if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
			WC_Appointments_Cache_Availability::release_storefront_after_reindex( $reason );
		}
	}

	/**
	 * Normalize progress option shape.
	 *
	 * @return array<string, mixed>
	 */
	private function get_reindex_progress_normalized(): array {
		$progress = get_option( 'wc_appointments_index_progress', [] );
		if ( ! is_array( $progress ) ) {
			$progress = [];
		}

		return wp_parse_args(
			$progress,
			[
				'status'             => 'idle',
				'total_rules'        => 0,
				'processed_rules'    => 0,
				'total_appointments' => 0,
				'processed_appts'    => 0,
				'cache_rows_created' => 0,
				'skipped_malformed_rules' => 0,
				'updated_at'         => 0,
				'error_message'      => '',
			]
		);
	}

	/**
	 * Mark re-index as failed, persist message, and release runtime locks.
	 *
	 * @param string               $message  User-visible error.
	 * @param array<string, mixed> $progress Optional existing progress.
	 * @return array<string, mixed>
	 */
	private function mark_reindex_failed( string $message, array $progress = [] ): array {
		if ( [] === $progress ) {
			$progress = $this->get_reindex_progress_normalized();
		}

		$progress['status']        = 'failed';
		$progress['error_message'] = $message;
		$progress['updated_at']    = time();
		update_option( 'wc_appointments_index_progress', $progress, false );
		$this->cleanup_reindex_runtime_state();
		$this->release_reindex_storefront_lock( 'failed' );

		return $progress;
	}

	/**
	 * If a re-index has been "running" without updates, mark it failed so admins can recover.
	 *
	 * @param array<string, mixed> $progress Progress option.
	 * @return array<string, mixed>
	 */
	private function reconcile_stale_reindex_progress( array $progress ): array {
		$status = isset( $progress['status'] ) ? (string) $progress['status'] : 'idle';
		if ( ! in_array( $status, [ 'running', 'queued' ], true ) ) {
			return $progress;
		}

		$updated_at = (int) ( $progress['updated_at'] ?? 0 );
		$started_at = (int) ( $progress['started_at'] ?? 0 );
		$reference  = max( $updated_at, $started_at );
		if ( 0 >= $reference ) {
			$reference = time();
		}

		if ( ( time() - $reference ) <= self::REINDEX_STALE_SECONDS ) {
			return $progress;
		}

		return $this->mark_reindex_failed(
			__( 'Re-index stopped because no progress was recorded for several minutes. You can start a new re-index when ready.', 'woocommerce-appointments' ),
			$progress
		);
	}

	/**
	 * Release stale re-index locks on any request (prevents orphaned flags affecting availability).
	 */
	public function maybe_reconcile_stale_reindex_on_init(): void {
		$progress = $this->get_reindex_progress_normalized();
		$status   = isset( $progress['status'] ) ? (string) $progress['status'] : 'idle';
		if ( ! in_array( $status, [ 'running', 'queued' ], true ) ) {
			return;
		}

		$this->reconcile_stale_reindex_progress( $progress );
	}

	/**
	 * Start reindex process
	 */
	public function start_reindex(): void {
		check_ajax_referer( 'wc_appointments_admin_nonce', '_wpnonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );
		@ignore_user_abort( true );

		// Check if indexed availability is enabled
		if ( 'yes' !== get_option( 'wc_appointments_use_indexed_cache', 'no' ) ) {
			wp_send_json_error( [ 'message' => __( 'Indexed availability is not enabled. Please enable "Use Indexed Availability" option first.', 'woocommerce-appointments' ) ] );
		}

		$progress = $this->reconcile_stale_reindex_progress( $this->get_reindex_progress_normalized() );
		if ( in_array( $progress['status'], [ 'running', 'queued' ], true ) ) {
			wp_send_json_error(
				[
					'code'     => 'already_running',
					'message'  => __( 'A re-index is already in progress. Stop it first or resume from this page.', 'woocommerce-appointments' ),
					'progress' => $progress,
				]
			);
		}

		try {
			if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
				WC_Appointments_Cache_Availability::cancel_pending_index_actions();
			}

			// Clear index and caches up-front to ensure fresh data is used.
			// 1) Purge the availability/appointment index table entirely.
			if ( class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
				$data_store = new WC_Appointments_Availability_Cache_Data_Store();
				// Delete all rows from wc_appointments_availability_cache and flush its object cache group.
				$data_store->clear_all();
			}

			// 2) Invalidate front-end/transient caches used by availability and schedule rendering.
			if ( class_exists( 'WC_Appointments_Cache' ) ) {
				// Clear transients and, if using an external object cache, flush it.
				WC_Appointments_Cache::clear_cache();
				// Also bump known cache groups that gate schedule calculations.
				WC_Appointments_Cache::invalidate_cache_group( 'appointments' );
				WC_Appointments_Cache::invalidate_cache_group( 'schedule_ts' );
				WC_Appointments_Cache::invalidate_cache_group( 'schedule_dr' );
				WC_Appointments_Cache::invalidate_cache_group( 'schedule_fo' );
				WC_Appointments_Cache::invalidate_cache_group( 'staff_ps' );
				WC_Appointments_Cache::invalidate_cache_group( 'schedule_staff_ids' );
			}

			$rule_ids = [];
			if ( class_exists( 'WC_Appointments_Availability_Data_Store' ) ) {
				$availability_store = new WC_Appointments_Availability_Data_Store();
				$rule_ids           = $availability_store->get_all_availability_rule_ids_for_reindex();
			}
			$rule_ids = array_map( 'intval', (array) $rule_ids );

			// 3) Ensure each availability rule object will be read fresh from DB (avoid stale object cache).
			// Optimize: Use group flush instead of individual deletes for better performance
			if ( [] !== $rule_ids && class_exists( 'WC_Appointments_Availability_Data_Store' ) ) {
				// If the cache backend supports group flush, clear the entire availability group (much faster).
				if ( function_exists( 'wp_cache_flush_group' ) ) {
					wp_cache_flush_group( WC_Appointments_Availability_Data_Store::CACHE_GROUP );
				} else {
					// Fallback: Only delete individual items if group flush is not available
					foreach ( $rule_ids as $rid ) {
						wp_cache_delete( $rid, WC_Appointments_Availability_Data_Store::CACHE_GROUP );
					}
				}
			}

			$appt_ids = [];
			if ( class_exists( 'WC_Appointment_Data_Store' ) ) {
				// During manual re-indexing, include appointments within the retention period (30 days)
				// This matches the retention period used by prune_past_rows()
				$retention_days = defined( 'WC_Appointments_Cache_Availability::INDEX_RETENTION_DAYS' )
					? WC_Appointments_Cache_Availability::INDEX_RETENTION_DAYS
					: 30;
				$retention_cut = time() - ( $retention_days * 86400 /* DAY_IN_SECONDS */ );

				$appt_ids = WC_Appointment_Data_Store::get_appointment_ids_by( [
					'date_after' => $retention_cut,
					'limit'      => 100000,
					'offset'     => 0,
					'order'      => 'ASC',
					'order_by'   => 'start_date',
				] );
			}
			$appt_ids = array_map( 'intval', (array) $appt_ids );

			// Initialize queue storage for chunked processing
			update_option( 'wc_appointments_index_queue', [
				'rule_ids'   => $rule_ids,
				'appt_ids'   => $appt_ids,
				'rule_index' => 0,
				'appt_index' => 0,
			], false );

			// Signal to the indexer that manual reindex is running and should force full indexing per rule.
			update_option( 'wc_appointments_manual_reindex_full_indexing', 1, false );
			WC_Appointments_Cache_Availability::reset_skipped_malformed_rule_count();

			// Initialize progress tracking in running state
			$progress = [
				'status'             => 'running',
				'total_rules'        => count( $rule_ids ),
				'processed_rules'    => 0,
				'total_appointments' => count( $appt_ids ),
				'processed_appts'    => 0,
				'cache_rows_created' => 0, // Track total cache rows (indexes) created
				'skipped_malformed_rules' => 0,
				'started_at'         => time(),
				'updated_at'         => time(),
				'error_message'      => '',
			];
			update_option( 'wc_appointments_index_progress', $progress, false );

			wp_send_json_success( [
				'message'  => __( 'Reindex started successfully.', 'woocommerce-appointments' ),
				'progress' => $progress,
			] );
		} catch ( Exception $e ) {
			$progress = $this->mark_reindex_failed(
				sprintf(
					/* translators: %s: error message */
					__( 'An error occurred: %s', 'woocommerce-appointments' ),
					$e->getMessage()
				)
			);
			wp_send_json_error(
				[
					'message'  => $progress['error_message'],
					'progress' => $progress,
				]
			);
		}
	}


	/**
	 * Stop reindex process
	 */
	public function stop_reindex(): void {
		check_ajax_referer( 'wc_appointments_admin_nonce', '_wpnonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		try {
			$progress = $this->reconcile_stale_reindex_progress( $this->get_reindex_progress_normalized() );
			$status   = isset( $progress['status'] ) ? (string) $progress['status'] : 'idle';

			if ( in_array( $status, [ 'running', 'queued' ], true ) ) {
				$progress['status']        = 'stopped';
				$progress['error_message'] = __( 'Re-index stopped by user.', 'woocommerce-appointments' );
				$progress['updated_at']    = time();
				update_option( 'wc_appointments_index_progress', $progress, false );
				$this->cleanup_reindex_runtime_state();
				$this->release_reindex_storefront_lock( 'stopped' );

				wp_send_json_success(
					[
						'message'  => __( 'Re-index stopped. You can start a new re-index when ready.', 'woocommerce-appointments' ),
						'progress' => $progress,
					]
				);
			}

			$this->cleanup_reindex_runtime_state();

			wp_send_json_success(
				[
					'message'  => __( 'No active re-index process to stop.', 'woocommerce-appointments' ),
					'progress' => $progress,
				]
			);
		} catch ( Exception $e ) {
			wp_send_json_error( [
				/* translators: %s: error message */
				'message' => sprintf( __( 'An error occurred: %s', 'woocommerce-appointments' ), $e->getMessage() ),
			] );
		}
	}

	/**
	 * Process a manual reindex chunk (rules + appointments) to avoid timeouts.
	 */
	public function process_reindex_chunk(): void {
		check_ajax_referer( 'wc_appointments_admin_nonce', '_wpnonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		// Prevent PHP timeouts during indexing operations
		if ( ! function_exists( 'ini_get' ) || ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 0 );
		}
		@ini_set( 'max_execution_time', '0' );
		@ignore_user_abort( true );

		// Increase default chunk size for better performance (was 25, now 50)
		// This processes more items per request, reducing total number of AJAX calls
		$limit = max( 1, self::post_absint_key( 'limit' ) ?: 50 );

		$progress = $this->reconcile_stale_reindex_progress( $this->get_reindex_progress_normalized() );
		$queue    = get_option( 'wc_appointments_index_queue', [] );
		if ( ! is_array( $queue ) ) {
			$queue = [];
		}
		$queue = wp_parse_args(
			$queue,
			[
				'rule_ids'   => [],
				'appt_ids'   => [],
				'rule_index' => 0,
				'appt_index' => 0,
			]
		);

		$status = isset( $progress['status'] ) ? (string) $progress['status'] : 'idle';
		if ( in_array( $status, [ 'stopped', 'completed', 'idle', 'failed' ], true ) ) {
			wp_send_json_success( [ 'progress' => $progress ] );
		}

		if ( ! get_option( 'wc_appointments_index_queue', false ) ) {
			$progress = $this->mark_reindex_failed(
				__( 'Re-index queue data is missing. Start a new re-index to rebuild the availability index.', 'woocommerce-appointments' ),
				$progress
			);
			wp_send_json_error(
				[
					'message'  => $progress['error_message'],
					'progress' => $progress,
				]
			);
		}

		try {
			$processed_this_call = $this->process_reindex_chunk_inner( $limit, $progress, $queue );
		} catch ( Throwable $e ) {
			$progress = $this->mark_reindex_failed(
				sprintf(
					/* translators: %s: error message */
					__( 'Re-index failed: %s', 'woocommerce-appointments' ),
					$e->getMessage()
				),
				$progress
			);
			wp_send_json_error(
				[
					'message'  => $progress['error_message'],
					'progress' => $progress,
				]
			);
		}

		wp_send_json_success( [ 'progress' => $progress ] );
	}

	/**
	 * Process one re-index chunk (rules + appointments).
	 *
	 * @param int                  $limit    Items per chunk.
	 * @param array<string, mixed> $progress Progress by reference.
	 * @param array<string, mixed> $queue    Queue by reference.
	 * @return int Items processed in this call.
	 */
	private function process_reindex_chunk_inner( int $limit, array &$progress, array &$queue ): int {
		if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
			WC_Appointments_Cache_Availability::set_manual_reindex_inline_rule_index( true );
		}

		try {
			return $this->process_reindex_chunk_inner_body( $limit, $progress, $queue );
		} finally {
			if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
				WC_Appointments_Cache_Availability::set_manual_reindex_inline_rule_index( false );
			}
		}
	}

	/**
	 * Process one re-index chunk body (rules + appointments).
	 *
	 * @param int                  $limit    Items per chunk.
	 * @param array<string, mixed> $progress Progress by reference.
	 * @param array<string, mixed> $queue    Queue by reference.
	 * @return int Items processed in this call.
	 */
	private function process_reindex_chunk_inner_body( int $limit, array &$progress, array &$queue ): int {
		$processed_this_call = 0;

		// Process availability rules.
		$rule_ids   = (array) ( $queue['rule_ids'] ?? [] );
		$rule_index = (int) ( $queue['rule_index'] ?? 0 );

		$progress['total_rules'] = (int) ( $progress['total_rules'] ?? count( $rule_ids ) );
		if ( 0 === $progress['total_rules'] ) {
			$progress['total_rules'] = count( $rule_ids );
		}

		$rules_remaining   = max( 0, count( $rule_ids ) - $rule_index );
		// Process more rules per chunk for better performance (was limit/2, now limit/1.5)
		$rules_to_process  = min( max( 1, (int) ceil( $limit / 1.5 ) ), $rules_remaining );

		// Optimize: Get data store instance once and query total cache rows at start of chunk
		// Only query cache count if we're actually processing items (not on every poll)
		$data_store = null;
		$cache_count_before = 0;
		if ( 0 < $rules_to_process && class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			$data_store         = new WC_Appointments_Availability_Cache_Data_Store();
			$cache_count_before = $data_store->count_all_rows();
		}

		for ( $i = 0; $i < $rules_to_process; $i++ ) {
			$idx = $rule_index + $i;
			if ( ! isset( $rule_ids[ $idx ] ) ) {
				break;
			}
			$rid = (int) $rule_ids[ $idx ];
			do_action( 'wc_appointments_index_availability_rule', $rid );
			$progress['processed_rules'] = (int) $progress['processed_rules'] + 1;
			$processed_this_call++;
		}
		$queue['rule_index'] = $rule_index + $rules_to_process;

		// Calculate cache rows created for rules in this chunk
		// Only query if we actually processed rules to avoid unnecessary queries
		if ( $data_store instanceof \WC_Appointments_Availability_Cache_Data_Store && 0 < $rules_to_process ) {
			$cache_count_after  = $data_store->count_all_rows();
			$chunk_rows_created = max( 0, $cache_count_after - $cache_count_before );
			$progress['cache_rows_created'] = (int) $progress['cache_rows_created'] + $chunk_rows_created;
			$cache_count_before = $cache_count_after; // Update for next chunk
		}

		// Process appointments.
		$appt_ids   = (array) ( $queue['appt_ids'] ?? [] );
		$appt_index = (int) ( $queue['appt_index'] ?? 0 );

		$progress['total_appointments'] = (int) ( $progress['total_appointments'] ?? count( $appt_ids ) );
		if ( 0 === $progress['total_appointments'] ) {
			$progress['total_appointments'] = count( $appt_ids );
		}

		$appts_remaining  = max( 0, count( $appt_ids ) - $appt_index );
		$appts_to_process = min( max( 0, $limit - $processed_this_call ), $appts_remaining );

		// Use same data store instance and continue tracking cache count
		if ( ! $data_store && class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			$data_store = new WC_Appointments_Availability_Cache_Data_Store();
			if ( 0 === $cache_count_before ) {
				$cache_count_before = $data_store->count_all_rows();
			}
		}

		for ( $i = 0; $i < $appts_to_process; $i++ ) {
			$idx = $appt_index + $i;
			if ( ! isset( $appt_ids[ $idx ] ) ) {
				break;
			}
			$aid = (int) $appt_ids[ $idx ];
			do_action( 'wc_appointments_index_appointment', $aid );
			// Ensure processed counter increments even if handler doesn't.
			$progress['processed_appts'] = (int) $progress['processed_appts'] + 1;
		}
		$queue['appt_index'] = $appt_index + $appts_to_process;

		// Calculate cache rows created for appointments in this chunk
		// Only query if we actually processed appointments to avoid unnecessary queries
		if ( $data_store instanceof \WC_Appointments_Availability_Cache_Data_Store && 0 < $appts_to_process ) {
			$cache_count_after  = $data_store->count_all_rows();
			$chunk_rows_created = max( 0, $cache_count_after - $cache_count_before );
			$progress['cache_rows_created'] = (int) $progress['cache_rows_created'] + $chunk_rows_created;
		}

		// Completion check.
		$done_rules = ( $progress['processed_rules'] >= $progress['total_rules'] ) || ( count( $rule_ids ) <= $queue['rule_index'] );
		$done_appts = ( $progress['processed_appts'] >= $progress['total_appointments'] ) || ( count( $appt_ids ) <= $queue['appt_index'] );

		$progress['updated_at'] = time();
		$progress['skipped_malformed_rules'] = WC_Appointments_Cache_Availability::get_skipped_malformed_rule_count();
		if ( $done_rules && $done_appts ) {
			$progress['status']       = 'completed';
			$progress['completed_at']  = time();
			update_option( 'wc_appointments_last_index_completed', [
				'timestamp'                 => $progress['completed_at'],
				'total_rules'               => (int) $progress['total_rules'],
				'total_appointments'        => (int) $progress['total_appointments'],
				'current_run_rules'         => (int) $progress['processed_rules'],
				'current_run_appointments'  => (int) $progress['processed_appts'],
				'cache_rows_created'        => (int) $progress['cache_rows_created'],
				'skipped_malformed_rules'   => (int) $progress['skipped_malformed_rules'],
			], false );
			delete_option( 'wc_appointments_index_queue' );
			// Clear the manual reindex flag on completion.
			delete_option( 'wc_appointments_manual_reindex_full_indexing' );
			$this->release_reindex_storefront_lock( 'completed' );
		} else {
			$progress['status'] = 'running';
			update_option( 'wc_appointments_index_queue', $queue, false );
		}

		update_option( 'wc_appointments_index_progress', $progress, false );

		return $processed_this_call;
	}

	/**
	 * Get appointable products for the admin panel dropdown
	 */
	public function get_appointable_products(): void {
		check_ajax_referer( 'get-appointable-products', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( 'Insufficient permissions.' );
		}

		$products        = [];
		$current_user_id = get_current_user_id();
		$per_page        = self::post_absint_key( 'per_page' ) ?: 50;
		$page            = self::post_absint_key( 'page' ) ?: 1;

		if ( $per_page < 1 ) {
			$per_page = 50;
		}
		$per_page = min( 200, $per_page );
		$page     = max( 1, $page );

		// Check if user is staff with limited permissions
		$is_staff_user    = class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $current_user_id );
		$can_create_any   = $is_staff_user ? WC_Appointments_Staff_Permissions::can( $current_user_id, 'create_appointments_any' ) : true;
		$filter_by_staff  = $is_staff_user && ! $can_create_any;

		// Get appointable products (paginated for large catalogs)
		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'meta_query'     => [
				[
					'key'   => '_appointable',
					'value' => 'yes',
				],
			],
			'orderby'        => 'title',
			'order'          => 'ASC',
		];

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$product_id = get_the_ID();
				$product    = get_wc_product_appointment( $product_id );

				if ( ! $product || ! $product->is_type( 'appointment' ) ) {
					continue;
				}

				// If staff user without create_appointments_any permission, only show assigned products
				if ( $filter_by_staff ) {
					$staff_ids = $product->get_staff_ids();
					if ( ! in_array( $current_user_id, (array) $staff_ids, true ) ) {
						continue;
					}
				}

				$products[ $product_id ] = self::wca_format_appointable_product_select_label( $product, $current_user_id, true );
			}
			wp_reset_postdata();
		}

		if ( [] === $products && 1 === $page ) {
			$message = $filter_by_staff
				? __( 'No appointable products assigned to you were found.', 'woocommerce-appointments' )
				: __( 'No appointable products found.', 'woocommerce-appointments' );
			wp_send_json_error( [ 'message' => $message ] );
		}

		wp_send_json_success(
			[
				'products'   => $products,
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => (int) $query->found_posts,
					'total_pages'=> (int) $query->max_num_pages,
				],
			]
		);
	}

	/**
	 * Search appointable products for AJAX dropdown
	 */
	public function search_appointable_products(): void {
		check_ajax_referer( 'search-appointable-products', 'security' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( -1 );
		}

		$term = self::get_text( 'term' );
		$limit = 50;

		if ( empty( $term ) ) {
			wp_die();
		}

		$products        = [];
		$current_user_id = get_current_user_id();

		// Check if user is staff with limited permissions
		$is_staff_user   = class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $current_user_id );
		$can_create_any  = $is_staff_user ? WC_Appointments_Staff_Permissions::can( $current_user_id, 'create_appointments_any' ) : true;
		$filter_by_staff = $is_staff_user && ! $can_create_any;

		// Search for appointment products
		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => $limit,
			's'              => $term,
			'meta_query'     => [
				[
					'key'     => '_appointable',
					'value'   => 'yes',
					'compare' => '=',
				],
			],
		];

		$query = new WP_Query( $args );

		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$product_id = get_the_ID();
				$product    = get_wc_product_appointment( $product_id );

				if ( ! $product || ! $product->is_type( 'appointment' ) ) {
					continue;
				}

				// If staff user without create_appointments_any permission, only show assigned products
				if ( $filter_by_staff ) {
					$staff_ids = $product->get_staff_ids();
					if ( ! in_array( $current_user_id, (array) $staff_ids, true ) ) {
						continue;
					}
				}

				$products[ $product_id ] = self::wca_format_appointable_product_select_label( $product, $current_user_id, true );
			}
			wp_reset_postdata();
		}

		wp_send_json( $products );
	}

	/**
	 * Get product details for form configuration
	 */
	public function get_product_details(): void {
		check_ajax_referer( 'get-product-details', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( -1 );
		}

		$product_id      = self::post_absint_key( 'product_id' );
		$product         = get_wc_product_appointment( $product_id );
		$current_user_id = get_current_user_id();

		if ( ! $product || ! $product->is_type( 'appointment' ) ) {
			wp_send_json_error( __( 'Invalid product.', 'woocommerce-appointments' ) );
		}

		// Staff without create_appointments_any may only load assigned products (or staffless products).
		$is_staff_user = WC_Appointments_Staff_Permissions::is_staff_user( $current_user_id );
		$filter_staff  = $is_staff_user
			&& ! WC_Appointments_Staff_Permissions::can( $current_user_id, 'create_appointments_any' );

		if ( $filter_staff && $product->has_staff() && ! in_array( $current_user_id, array_map( 'intval', (array) $product->get_staff_ids() ), true ) ) {
			wp_send_json_error( __( 'You are not assigned to this product.', 'woocommerce-appointments' ) );
		}

		$cal_color = is_callable( [ $product, 'get_cal_color' ] ) ? $product->get_cal_color() : '';

		$product_data = [
			'has_time'         => $product->has_time(),
			'has_staff'        => $product->has_staff(),
			'staff_assignment' => $product->get_staff_assignment(),
			'staff_nopref'     => method_exists( $product, 'get_staff_nopref' ) ? $product->get_staff_nopref() : false,
			'staff'            => [],
			'can_choose_staff' => ! $filter_staff,
			'duration'         => $product->get_duration(),
			'duration_unit'    => $product->get_duration_unit(),
			'interval'         => method_exists( $product, 'get_interval' ) ? $product->get_interval() : 0,
			'interval_unit'    => method_exists( $product, 'get_interval_unit' ) ? $product->get_interval_unit() : 'minute',
			'product_id'       => $product->get_id(),
			'qty'              => (int) $product->get_qty(),
			'qty_max'          => (int) $product->get_qty_max(),
			'formatted_name'   => $product->get_formatted_name(),
			'cal_color'        => ( $cal_color && '' !== trim( (string) $cal_color ) ) ? trim( (string) $cal_color ) : WC_Appointments_Admin::get_default_cal_color(),
			'default_staff_id' => 0,
			'has_locations'    => false,
			'location_mode'    => 'none',
			'location_label'   => '',
			'locations'        => [],
			'has_resources'    => false,
			'resource_label'   => '',
			'resource_assignment' => 'display',
			'resources'        => [],
		];

		if ( class_exists( 'WC_Appointments_Location' ) && $product->has_locations() ) {
			$mode = $product->get_location_mode();
			$map  = [];
			foreach ( WC_Appointments_Location::get_allowed_location_ids( $product ) as $lid ) {
				$title = get_the_title( $lid );
				if ( $title ) {
					$map[ (string) (int) $lid ] = $title;
				}
			}
			if ( $map ) {
				$product_data['has_locations'] = true;
				$product_data['location_mode'] = $mode;
				$loc_label                     = trim( (string) $product->get_location_label() );
				$product_data['location_label'] = '' !== $loc_label ? $loc_label : __( 'Location', 'woocommerce-appointments' );
				$product_data['locations']      = $map;
				$product_data['location_costs'] = WC_Appointments_Location::product_location_costs_map( $product, $map );
			}
		}

		if ( class_exists( 'WC_Appointments_Resource' ) && $product->has_resources() ) {
			$res_map = [];
			foreach ( WC_Appointments_Resource::normalize_requirements( $product ) as $req ) {
				$rid = (int) ( $req['resource_id'] ?? 0 );
				if ( $rid <= 0 ) {
					continue;
				}
				$title = get_the_title( $rid );
				if ( ! $title ) {
					continue;
				}
				$res_map[ (string) $rid ] = [
					'title'       => $title,
					'location_id' => WC_Appointments_Resource_Data_Store::get_location_id( $rid ),
					'cost'        => (float) ( $req['cost'] ?? 0 ),
				];
			}
			if ( $res_map ) {
				$product_data['has_resources']        = true;
				$product_data['resources']            = $res_map;
				$product_data['resource_assignment']  = $product->get_resource_assignment();
				$res_label                            = trim( (string) $product->get_resource_label() );
				$product_data['resource_label']       = '' !== $res_label ? $res_label : __( 'Resources', 'woocommerce-appointments' );
			}
		}


		// Base product price for initial display in admin panel (match WC catalog price entry basis).
		$base_price = (float) $product->get_price();
		if ( wc_tax_enabled() && wc_prices_include_tax() ) {
			$display_price = wc_get_price_including_tax( $product, [ 'price' => $base_price ] );
		} else {
			$display_price = wc_get_price_excluding_tax( $product, [ 'price' => $base_price ] );
		}
		$product_data['price_raw']  = (float) $display_price;
		$product_data['price_html'] = wc_price( $display_price );

		// Human-readable duration label for display.
		$dur      = $product->get_duration();
		$dur_unit = $product->get_duration_unit();
		$dur_labels = [
			/* translators: %d: duration value in minutes. */
			'minute' => _n( '%d min', '%d mins', $dur, 'woocommerce-appointments' ),
			/* translators: %d: duration value in hours. */
			'hour'   => _n( '%d hour', '%d hours', $dur, 'woocommerce-appointments' ),
			/* translators: %d: duration value in days. */
			'day'    => _n( '%d day', '%d days', $dur, 'woocommerce-appointments' ),
			/* translators: %d: number of months */
			'month'  => _n( '%d month', '%d months', $dur, 'woocommerce-appointments' ),
		];
		$product_data['duration_label'] = isset( $dur_labels[ $dur_unit ] ) ? sprintf( $dur_labels[ $dur_unit ], $dur ) : $dur . ' ' . $dur_unit;

		// Get staff members if product has staff.
		if ( $product->has_staff() ) {
			$staff_ids = $product->get_staff_ids();
			if ( ! empty( $staff_ids ) ) {
				foreach ( $staff_ids as $staff_id ) {
					// If staff user without create_appointments_any permission, only show themselves
					if ( $filter_staff && (int) $staff_id !== $current_user_id ) {
						continue;
					}

					$staff = get_userdata( $staff_id );
					if ( $staff ) {
						$name = $staff->display_name;
						$product_data['staff'][ $staff_id ] = $name;
					}
				}

				// Auto-select staff if current user is staff and is assigned to this product
				if ( $is_staff_user && in_array( $current_user_id, array_map( 'intval', $staff_ids ), true ) ) {
					$product_data['default_staff_id'] = $current_user_id;
				}
			}
		}

		if ( class_exists( 'WC_Deposits_Product_Manager' ) && WC_Deposits_Product_Manager::deposits_enabled( $product_id ) ) {
			$dep_type = WC_Deposits_Product_Manager::get_deposit_type( $product_id );
			$plans    = [];
			if ( 'plan' === $dep_type && class_exists( 'WC_Deposits_Plans_Manager' ) ) {
				foreach ( WC_Deposits_Plans_Manager::get_plans_for_product( $product_id ) as $plan_obj ) {
					if ( is_object( $plan_obj ) && is_callable( [ $plan_obj, 'get_id' ] ) ) {
						$plans[] = [
							'id'   => (int) $plan_obj->get_id(),
							'name' => method_exists( $plan_obj, 'get_name' ) ? $plan_obj->get_name() : '',
						];
					}
				}
			}
			$product_data['wc_deposits'] = [
				'forced'          => WC_Deposits_Product_Manager::deposits_forced( $product_id ),
				'type'            => $dep_type,
				'default_option'  => WC_Deposits_Product_Manager::get_deposit_selected_type( $product_id ),
				'formatted_hint'  => WC_Deposits_Product_Manager::get_formatted_deposit_amount( $product_id ),
				'plans'           => $plans,
			];
		}

		// Recurring series capability.
		if ( class_exists( 'WC_Appointment_Series_Events' ) && WC_Appointment_Series_Events::is_enabled() && method_exists( $product, 'allows_recurring' ) && $product->allows_recurring() ) {
			$product_data['allow_recurring']    = true;
			$product_data['recurring_freqs']    = $product->get_recurring_allowed_freqs();
			$product_data['recurring_min'] = (int) $product->get_recurring_min_occurrences();
			$product_data['recurring_max'] = (int) $product->get_recurring_max_occurrences();
		}

		$product_data['has_addons'] = class_exists( 'WC_Appointments_Integration_Addons' )
			&& WC_Appointments_Integration_Addons::product_has_addons( $product_id );

		wp_send_json_success( $product_data );
	}

	/**
	 * Get available times for a specific date and product
	 */
	public function get_available_times(): void {
		check_ajax_referer( 'get-available-times', 'nonce' );

		if ( ! current_user_can( 'edit_appointments' ) ) {
			wp_die( -1 );
		}

		$product_id  = self::post_absint_key( 'product_id' );
		$date        = self::post_text( 'date' );
		$staff_id    = self::post_absint_key( 'staff_id' );
		$location_id = self::post_absint_first( [ 'location_id', 'appointment_location_id' ] );
		$resource_id = self::post_absint_first( [ 'resource_id', 'appointment_resource_id' ] );

		$product = get_wc_product_appointment( $product_id );

		if ( ! $product || ! $product->is_type( 'appointment' ) ) {
			wp_send_json_error( __( 'Invalid product.', 'woocommerce-appointments' ) );
		}

		if ( ! $product->has_time() ) {
			wp_send_json_success( [] );
		}

		// Site-local midnight for the calendar day (same as browse / get_posted_data).
		try {
			$timestamp = $this->wca_site_midnight_timestamp( $date );
		} catch ( Exception $e ) {
			wp_send_json_error( __( 'Invalid date.', 'woocommerce-appointments' ) );
		}

		// UNIFIED SLOTS STANDARDIZATION: Delegate to Collection for filtering and formatting.
		$available_times = [];

		try {
			$collection = WC_Appointment_Slots_Provider::get_time_slots_collection(
				$product,
				$timestamp,
				$timestamp + 86400 /* DAY_IN_SECONDS */,
				$staff_id,
				false,
				false,
				'',
				false,
				$location_id,
				$resource_id
			);

			$available_times = $collection->get_available_times_for_admin( $product );
		} catch ( Exception $e ) {
			// Return empty on Provider failure — admin can retry.
		}

		wp_send_json_success( $available_times );
	}

	/**
	 * Unix timestamp for 00:00:00 on a calendar day in the site timezone (Y-m-d).
	 * Used for minute/hour slot fetch windows only — not day/month civil tokens.
	 */
	private function wca_site_midnight_timestamp( string $ymd ): int {
		$tz = new DateTimeZone( wc_timezone_string() );
		return ( new DateTimeImmutable( $ymd . ' 00:00:00', $tz ) )->getTimestamp();
	}

	/**
	 * Fake UTC civil range for admin day/month labels (matches get_posted_data / slot engine).
	 *
	 * @param string $from Y-m-d or Y-m when $month_range.
	 * @param string $to   Inclusive last civil day (Y-m-d) or month (Y-m).
	 * @return array{0:int,1:int} Start and exclusive end timestamps.
	 */
	private function wca_fake_utc_range_timestamps( string $from, string $to, bool $month_range = false ): array {
		if ( $month_range ) {
			return [
				(int) strtotime( $from . '-01 00:00:00 UTC' ),
				(int) strtotime( $to . '-01 00:00:00 UTC +1 month' ),
			];
		}

		return [
			(int) strtotime( $from . ' 00:00:00 UTC' ),
			(int) strtotime( $to . ' 00:00:00 UTC +1 day' ),
		];
	}

	/**
	 * Zero location/resource IDs that are not on the product (or classes unavailable).
	 *
	 * @return array{0:int,1:int} Authorized location_id, resource_id.
	 */
	private function wca_authorize_product_location_resource( WC_Product_Appointment $product, int $location_id, int $resource_id ): array {
		if ( $location_id > 0 && class_exists( 'WC_Appointments_Location' ) && $product->has_locations() ) {
			if ( ! WC_Appointments_Location::authorize_location_id( $product, $location_id ) ) {
				$location_id = 0;
			}
		} else {
			$location_id = 0;
		}

		if ( $resource_id > 0 && class_exists( 'WC_Appointments_Resource' ) && $product->has_resources() ) {
			if ( ! WC_Appointments_Resource::authorize_resource_id( $product, $resource_id ) ) {
				$resource_id = 0;
			}
		} else {
			$resource_id = 0;
		}

		return [ $location_id, $resource_id ];
	}

	/**
	 * Check availability for current selection (server-side capacity and rules)
	 */
	public function check_availability(): void {

		check_ajax_referer( 'wc_appointments_check_availability', 'nonce' );

		if ( ! current_user_can( 'edit_appointments' ) ) {
			wp_die( -1 );
		}

		try {
			WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();

			$product_id = self::post_absint_first( [ 'product_id', 'appointment_product_id' ] );
			$staff_id   = self::post_absint_first( [ 'staff_id', 'appointment_staff_id' ] );
			$location_id = self::post_absint_first( [ 'location_id', 'appointment_location_id' ] );
			$resource_id = self::post_absint_first( [ 'resource_id', 'appointment_resource_id' ] );
			$qty        = max( 1, self::post_absint_key( 'quantity' ) ?: 1 );
			$prefer_same_start = self::post_bool( 'prefer_same_start_time' );

			$product = get_wc_product_appointment( $product_id );
			if ( ! $product || ! $product->is_type( 'appointment' ) ) {
				wp_send_json_error( __( 'Invalid product.', 'woocommerce-appointments' ) );
			}


			$single_date = self::post_text( 'appointment_date' );
			$month_from  = self::post_text( 'appointment_month_from' );
			$month_to    = self::post_text( 'appointment_month_to' );
			$date_from   = self::post_text( 'appointment_date_from' );
			$date_to     = self::post_text( 'appointment_date_to' );
			$time_from   = self::post_text( 'appointment_time_from' );
			$time_to     = self::post_text( 'appointment_time_to' );

			$posted_for_builder = [
				'quantity' => $qty,
			];

			$tz = new DateTimeZone( wc_timezone_string() );

			if ( ! empty( $single_date ) ) {
				// Parse date directly - already in site timezone format.
				$dt = new DateTimeImmutable( $single_date . ' 00:00:00', $tz );
				$posted_for_builder['wc_appointments_field_start_date_year']  = $dt->format( 'Y' );
				$posted_for_builder['wc_appointments_field_start_date_month'] = $dt->format( 'm' );
				$posted_for_builder['wc_appointments_field_start_date_day']   = $dt->format( 'd' );
			} elseif ( ! empty( $month_from ) ) {
				$posted_for_builder['wc_appointments_field_start_date_yearmonth'] = $month_from; // YYYY-MM
			} elseif ( ! empty( $date_from ) ) {
				// Parse date directly - already in site timezone format.
				$dt = new DateTimeImmutable( $date_from . ' 00:00:00', $tz );
				$posted_for_builder['wc_appointments_field_start_date_year']  = $dt->format( 'Y' );
				$posted_for_builder['wc_appointments_field_start_date_month'] = $dt->format( 'm' );
				$posted_for_builder['wc_appointments_field_start_date_day']   = $dt->format( 'd' );
			} else {
				throw new Exception( __( 'Start date is required.', 'woocommerce-appointments' ) );
			}

			if ( $product->has_time() && ! empty( $time_from ) ) {
				$posted_for_builder['wc_appointments_field_start_date_time'] = $time_from;
			}
			if ( $product->has_staff() && $staff_id ) {
				$posted_for_builder['wc_appointments_field_staff'] = $staff_id;
			}
			if ( $location_id > 0 ) {
				$posted_for_builder['wc_appointments_field_location'] = $location_id;
				$posted_for_builder['location_id']                   = $location_id;
			}
			if ( $resource_id > 0 ) {
				$posted_for_builder['wc_appointments_field_resource'] = $resource_id;
			}

			// Pass signed addon minutes (may shorten) so wc_appointments_get_posted_data()
			// builds _end_date with the same duration floor as storefront cart validation.
			$addons_duration = (int) self::post_raw( 'duration', 0 );
			if ( 0 !== $addons_duration ) {
				$posted_for_builder['wc_appointments_field_addons_duration'] = $addons_duration;
			}

			// Admin panel POSTs site-timezone date/time (after any JS admin→site conversion).
			// wc_appointments_get_posted_data() must ignore customer timezone cookie and skip user-TZ legacy conversion.
			if ( self::post_bool( 'is_admin_panel' ) ) {
				$posted_for_builder['is_admin_panel'] = '1';
			}

			// Browse panel / slot chips: engine start_ts matches listed slots (same as storefront data-slot-timestamp).
			// Prioritize wc_appointments_field_start_date_timestamp and short alias wca_slot_start_ts.
			$posted_slot_ts = self::post_text_first( [ 'wc_appointments_field_start_date_timestamp', 'wca_slot_start_ts' ] );
			if ( is_numeric( $posted_slot_ts ) ) {
				$posted_slot_ts = (int) $posted_slot_ts;
				if ( $posted_slot_ts >= 86400 && $posted_slot_ts <= 2147483647 ) {
					$posted_for_builder['wc_appointments_field_start_date_timestamp'] = (string) $posted_slot_ts;
				}
			}


			$appointment_data = wc_appointments_get_posted_data( $posted_for_builder, $product );
			$appointment_data['_qty'] ??= $qty;
			// Scope capacity to selected staff only when the product uses staff.
			if ( $product->has_staff() && $staff_id ) {
				$appointment_data['_staff_id'] = $staff_id;
			} elseif ( ! $product->has_staff() ) {
				$appointment_data['_staff_id'] = '';
				$staff_id                     = 0;
			} elseif ( ! isset( $appointment_data['_staff_id'] ) ) {
				$appointment_data['_staff_id'] = '';
			}

			// When editing in the admin panel, omit this appointment from booked-qty overlap
			// so its current slot is not reported as unavailable to itself.
			$overlap_exclude_appt_id = 0;
			if ( self::post_bool( 'is_admin_panel' ) ) {
				$edit_appt_cand = self::post_absint_key( 'editing_appointment_id' );
				if ( $edit_appt_cand > 0 && current_user_can( 'edit_post', $edit_appt_cand ) ) {
					$edit_appt_obj = get_wc_appointment( $edit_appt_cand );
					if ( $edit_appt_obj && (int) $edit_appt_obj->get_product_id() === (int) $product_id ) {
						$overlap_exclude_appt_id = $edit_appt_cand;
					}
				}
			}
			if ( $overlap_exclude_appt_id > 0 ) {
				WC_Appointment_Slots_Engine::set_overlap_exclude_appointment_ids( [ $overlap_exclude_appt_id ] );
			}

			// If admin provided a specific time range on a day-based product,
			// align start/end to those times so time rules are considered.
			$has_admin_time_range = ! empty( $single_date ) && ( ! empty( $time_from ) || ! empty( $time_to ) );
			if ( ! $product->has_time() && $has_admin_time_range ) {
				if ( ! empty( $time_from ) ) {
					$appointment_data['_start_date'] = ( new DateTimeImmutable( $single_date . ' ' . $time_from, $tz ) )->getTimestamp();
				}
				if ( ! empty( $time_to ) ) {
					$end_ts = ( new DateTimeImmutable( $single_date . ' ' . $time_to, $tz ) )->getTimestamp();
					$start_baseline = isset( $appointment_data['_start_date'] ) ? (int) $appointment_data['_start_date'] : ( new DateTimeImmutable( $single_date . ' 00:00:00', $tz ) )->getTimestamp();
					if ( $end_ts <= $start_baseline ) {
						$end_ts = strtotime( '+1 day', $end_ts );
					}
					$appointment_data['_end_date'] = $end_ts;
				}
			}

			// wc_appointments_get_posted_data() now sets _end_date using $duration_total which
			// includes addon duration (via wc_appointments_field_addons_duration in $posted_for_builder).
			// The controller's get_extended_range_available_capacity() handles validation for
			// ranges that span multiple consecutive slots.

			// If a custom end time is provided on a time-based product, clamp to combined duration (base + add-ons).
			if ( $product->has_time() && ! empty( $time_to ) && ! empty( $single_date ) ) {
				$start_ts = (int) $appointment_data['_start_date'];
				$combined_minutes = isset( $appointment_data['_duration'] ) ? (int) $appointment_data['_duration'] : 0;
				$default_end_ts = $combined_minutes > 0 ? $start_ts + ( $combined_minutes * 60 ) : (int) $appointment_data['_end_date'];

				// Admin-provided end timestamp.
				$end_ts = ( new DateTimeImmutable( $single_date . ' ' . $time_to, $tz ) )->getTimestamp();

				// Compare difference in minutes (rounded) to combined duration.
				$diff_minutes = (int) round( ( $end_ts - $start_ts ) / 60 );

				// Accept admin end only if same day and matches combined duration (±2 min).
				$tolerance = 2;
				$same_day  = ( (int) ( new DateTimeImmutable( '@' . $start_ts ) )->setTimezone( $tz )->format( 'Ymd' ) === (int) ( new DateTimeImmutable( '@' . $end_ts ) )->setTimezone( $tz )->format( 'Ymd' ) );
				$use_admin_end = $same_day && 0 < $combined_minutes && abs( $diff_minutes - $combined_minutes ) <= $tolerance;

				if ( ! $use_admin_end ) {
					$end_ts = $default_end_ts;
				}

				$appointment_data['_end_date'] = $end_ts;
			}

			if ( ! $product->has_time() ) {
				if ( ! empty( $month_from ) && ! empty( $month_to ) ) {
					[ $appointment_data['_start_date'], $appointment_data['_end_date'] ] = $this->wca_fake_utc_range_timestamps( $month_from, $month_to, true );
				} elseif ( ! empty( $date_from ) && ! empty( $date_to ) ) {
					[ $appointment_data['_start_date'], $appointment_data['_end_date'] ] = $this->wca_fake_utc_range_timestamps( $date_from, $date_to );
				}
			}

			// Core appointability check — used for validation only (date bounds,
			// restricted days, qty limits, etc.).  Note: is_appointable() resets
			// _staff_id to 0 for automatic/all assignment types, so its availability
			// result reflects ANY staff, not the admin-selected one.
			$appointable_result = $product->is_appointable( $appointment_data );
			$appointable        = ! is_wp_error( $appointable_result );
			$appointable_message = '';
			if ( is_wp_error( $appointable_result ) ) {
				$appointable_message = $appointable_result->get_error_message();
			}

			// Staff-specific slot check via Provider (single source of truth).
			// Use the same logic as frontend validation - check if any slot covers the requested time range
			$staff_slot_ok = true;
			if ( $staff_id && $product->has_staff() && $product->has_time() && ! empty( $single_date ) && ! empty( $time_from ) ) {
				// Build day range from the actual appointment timestamps, not the form date
				// This ensures we're checking the correct day that matches the requested time
				$requested_start = (int) $appointment_data['_start_date'];
				$requested_end   = (int) $appointment_data['_end_date'];

				// Site-local midnight for the posted calendar day (matches get_day_slots / get_posted_data).
				$day_start = $this->wca_site_midnight_timestamp( $single_date );
				$day_end   = $day_start + 86400 /* DAY_IN_SECONDS */;

				// Extend fetch range if addon-extended appointment spans beyond this day.
				$fetch_end = max( $day_end, $requested_end + 86400 );

				try {
					$collection = WC_Appointment_Slots_Provider::get_time_slots_collection(
						$product,
						$day_start,
						$fetch_end,
						$staff_id,
						false,
						false,
						'',
						false,
						$location_id,
						$resource_id
					);

					$staff_slot_ok = false;

					// Check if a single slot covers the full range.
					foreach ( $collection->get_all_slots() as $slot ) {
						if ( $slot->start_ts <= $requested_start && $slot->end_ts >= $requested_end ) {
							$staff_slot_ok = $slot->capacity_available >= $qty;
							break;
						}
						if ( (int) $slot->start_ts === $requested_start ) {
							$staff_slot_ok = $slot->capacity_available >= $qty;
							break;
						}
					}

					// Extended range: addon-extended duration may span multiple consecutive slots.
					// Verify all covering slots have sufficient capacity (bottleneck).
					if ( ! $staff_slot_ok && $requested_end > $requested_start ) {
						$covering = [];
						foreach ( $collection->get_all_slots() as $slot ) {
							if ( $slot->start_ts < $requested_end && $slot->end_ts > $requested_start ) {
								$covering[] = $slot;
							}
						}
						if ( ! empty( $covering ) ) {
							usort( $covering, static fn( $a, $b ) => $a->start_ts - $b->start_ts );
							if ( abs( $covering[0]->start_ts - $requested_start ) <= 120 ) {
								$covered_until = $requested_start;
								$ok = true;
								foreach ( $covering as $cslot ) {
									if ( $cslot->start_ts > $covered_until + 120 ) {
										$ok = false;
										break;
									}
									if ( $cslot->capacity_available < $qty ) {
										$ok = false;
										break;
									}
									$covered_until = max( $covered_until, $cslot->end_ts );
									if ( $covered_until >= $requested_end - 120 ) {
										break;
									}
								}
								$staff_slot_ok = $ok && ( $covered_until >= $requested_end - 120 );
							}
						}
					}
				} catch ( Exception $e ) {
					$staff_slot_ok = false;
				}
			}


			// Capacity calculation for the selected range.
			// Deduct 1 second from the end date to ensure the check is inclusive of the range
			// but doesn't bleed into the next day's first second (same as frontend).
			$available_total = wc_appointments_get_total_available_appointments_for_range(
				$product,
				( (int) $appointment_data['_start_date'] ),
				( (int) $appointment_data['_end_date'] ) - 1,
				$appointment_data['_staff_id'],
				$appointment_data['_qty'],
				$location_id,
				$resource_id
			);

			$capacity_num = 0;
			if ( is_array( $available_total ) ) {
				foreach ( $available_total as $v ) {
					$capacity_num += max( 0, (int) $v );
				}
			} else {
				$capacity_num = max( 0, (int) $available_total );
			}


			// Enforce time-based rules when admin specifies a time range on day-based products.
			$time_rules_ok = true;
			if ( ! $product->has_time() && $has_admin_time_range && ! empty( $appointment_data['_start_date'] ) && ! empty( $appointment_data['_end_date'] ) ) {
				$time_cap = $product->check_availability_rules_against_time(
				    (string) $appointment_data['_start_date'],
				    (string) ( (int) $appointment_data['_end_date'] - 1 ),
				    $appointment_data['_staff_id'],
				    true,
				);
				$time_rules_ok = ( ! is_wp_error( $time_cap ) ) && (bool) $time_cap;
				if ( ! $time_rules_ok ) {
					$capacity_num = 0;
				}
			}

			// Final response.
			// $staff_slot_ok gates availability using the same slot generation as
			// the slot chips, ensuring consistency between what the user sees and
			// what the availability check reports.
			$is_range_pick = ( ! $product->has_time() ) && ( ( ! empty( $month_from ) && ! empty( $month_to ) ) || ( ! empty( $date_from ) && ! empty( $date_to ) ) );
			$available     = $staff_slot_ok && ( 0 < $capacity_num ) && $time_rules_ok;
			if ( ! $is_range_pick && ! $appointable ) {
				// Honour validation errors from is_appointable (date bounds, restricted days, etc.).
				$available = false;
			}

			$notice_message = '';
			if ( $product->has_time() && $product->has_staff() && ! empty( $single_date ) && ! empty( $time_from ) ) {
				// Use the same corrected date range calculation as the main validation
				$requested_start = (int) $appointment_data['_start_date'];
				$requested_end   = (int) $appointment_data['_end_date'];

				$day_start = $this->wca_site_midnight_timestamp( $single_date );
				$day_end   = $day_start + 86400 /* DAY_IN_SECONDS */;
				$staff_scope_id = $staff_id ?: 0;

				try {
					$scope_collection = WC_Appointment_Slots_Provider::get_time_slots_collection(
						$product,
						$day_start,
						$day_end,
						$staff_scope_id,
						false,
						false,
						'',
						false,
						$location_id,
						$resource_id
					);

					$requested_ts          = (int) $appointment_data['_start_date'];
					$max_qty_for_selection = 0;

					foreach ( $scope_collection->get_all_slots() as $slot ) {
						// Use flexible matching for notice calculation too (same as main validation)
						if ( $slot->start_ts <= $requested_start && $slot->end_ts >= $requested_end ) {
							$max_qty_for_selection = max( 0, $slot->capacity_available );
							break;
						}

						// Fallback to exact start time match
						if ( (int) $slot->start_ts === $requested_ts ) {
							$max_qty_for_selection = max( 0, $slot->capacity_available );
							break;
						}
					}

					if ( $qty > $max_qty_for_selection ) {
						if ( $max_qty_for_selection > 0 ) {
							/* translators: 1: maximum quantity for this time, 2: same value (choose N or fewer) */
							$notice_message = sprintf( __( 'Maximum for this time is %1$d. Choose %2$d or fewer.', 'woocommerce-appointments' ), $max_qty_for_selection, $max_qty_for_selection );
						} else {
							$notice_message = __( 'No capacity for this time. Choose another time or reduce quantity.', 'woocommerce-appointments' );
						}
					}
				} catch ( Exception $e ) {
					// Silently fail — capacity notice is non-critical.
				}
			}

			if ( empty( $notice_message ) && ! $available && ! empty( $appointable_message ) ) {
				$notice_message = $appointable_message;
			}

			$response = [
				'available' => $available,
				'capacity'  => $staff_slot_ok ? $capacity_num : 0,
				'start'     => (int) $appointment_data['_start_date'],
				'end'       => (int) $appointment_data['_end_date'],
				'notice_message' => $notice_message,
			];


			WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();
			wp_send_json_success( $response );

		} catch ( Exception $e ) {
			WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();
			wp_send_json_error( $e->getMessage() );
		}
	}

	/**
	 * Create a new appointment
	 */
	public function create_appointment(): void {
		check_ajax_referer( 'create-appointment', 'nonce' );

		if ( ! current_user_can( 'edit_appointments' ) ) {
			wp_die( -1 );
		}

		// Check staff-specific permission for creating appointments.
		$user_id = get_current_user_id();
		if ( class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
			if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'create_appointments' ) ) {
				wp_send_json_error( [ 'message' => __( 'You do not have permission to create appointments.', 'woocommerce-appointments' ) ] );
			}
		}

		// Set a flag to prevent currency conversion in admin
		// This ensures appointment and order costs match in base currency
		// create_appointment is admin-only (no nopriv handler), so always set the flag
		if ( ! defined( 'WC_APPOINTMENTS_ADMIN_CREATE' ) ) {
			define( 'WC_APPOINTMENTS_ADMIN_CREATE', true );
		}

		$lock_acquired         = false;
		$product_id            = 0;
		$start_timestamp       = 0;
		$end_timestamp         = 0;
		$staff_ids_to_assign   = 0;

		try {
			$posted = self::post_unslashed_array();

			// Sanitize and validate input
			$product_id  = self::post_absint_key( 'appointment_product_id' );
			$staff_id    = self::post_absint_key( 'appointment_staff_id' );
			$customer_id = self::post_absint_key( 'appointment_customer_id' );
			$order_type  = self::post_text( 'order_type' );
			$wca_admin_create_context = self::post_text( 'wca_admin_create_context', 'standalone' );
			if ( ! in_array( $wca_admin_create_context, [ 'calendar', 'standalone' ], true ) ) {
				$wca_admin_create_context = 'standalone';
			}
			$order_id    = self::post_absint_key( 'appointment_order_id' );
			$status      = self::post_text( 'appointment_status' );
			$qty         = max( 1, self::post_absint_key( 'quantity' ) ?: 1 );
			$create_account = self::post_bool( 'appointment_create_account' );
			$customer_status = self::post_text( 'appointment_customer_status' );

			// Validate status; staff without manage_appointment_status stay on confirmed (no price override either).
			$valid_statuses = get_wc_appointment_statuses( 'validate' ); // slug list
			$default_status = WC_Appointments_Constants::STATUS_CONFIRMED;
			if ( '' === $status ) {
				$status = $default_status;
			} elseif ( ! in_array( $status, $valid_statuses, true ) ) {
				throw new Exception( __( 'Invalid appointment status.', 'woocommerce-appointments' ) );
			}

			$staff_may_set_status_and_price = ! WC_Appointments_Staff_Permissions::is_staff_user( $user_id )
				|| WC_Appointments_Staff_Permissions::can( $user_id, 'manage_appointment_status' );
			if ( ! $staff_may_set_status_and_price ) {
				$status = $default_status;
			}

			// Range-aware fields
			$single_date = self::post_text( 'appointment_date' );
			$time_from   = self::post_text( 'appointment_time_from' );
			$time_to     = self::post_text( 'appointment_time_to' );
			$date_from   = self::post_text( 'appointment_date_from' );
			$date_to     = self::post_text( 'appointment_date_to' );
			$month_from  = self::post_text( 'appointment_month_from' );
			$month_to    = self::post_text( 'appointment_month_to' );

			if ( ! $product_id ) {
				throw new Exception( __( 'This field is required.', 'woocommerce-appointments' ) );
			}

			$product = get_wc_product_appointment( $product_id );
			if ( ! $product || ! $product->is_type( 'appointment' ) ) {
				throw new Exception( __( 'Invalid product.', 'woocommerce-appointments' ) );
			}

			// Enforce staff product assignment on write (UI filters alone are not enough).
			if ( class_exists( 'WC_Appointments_Staff_Permissions' ) && WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
				$can_create_any = WC_Appointments_Staff_Permissions::can( $user_id, 'create_appointments_any' );
				if ( ! $can_create_any && $product->has_staff() ) {
					$assigned = array_map( 'intval', (array) $product->get_staff_ids() );
					if ( ! in_array( (int) $user_id, $assigned, true ) ) {
						throw new Exception( __( 'You are not assigned to this product.', 'woocommerce-appointments' ) );
					}
				}
			}

			// Attaching to an existing order requires order edit capability.
			if ( 'existing' === $order_type && $order_id ) {
				if ( ! current_user_can( 'edit_shop_order', $order_id ) && ! current_user_can( 'manage_woocommerce' ) ) {
					throw new Exception( __( 'You do not have permission to edit this order.', 'woocommerce-appointments' ) );
				}
			}

			if ( ! $customer_id && $create_account && 'existing' !== $order_type ) {
				// Same gate as billing update: order editors may create the customer-role account for that order.
				// (edit_users is do_not_allow for non-super-admins on multisite, so it is not a usable proxy.)
				if ( ! current_user_can( 'create_users' ) && ! current_user_can( 'edit_shop_orders' ) && ! current_user_can( 'manage_woocommerce' ) ) {
					throw new Exception( __( 'You do not have permission to create customer accounts.', 'woocommerce-appointments' ) );
				}
				$billing_email = self::post_email( '_billing_email' );
				if ( ! $billing_email || ! is_email( $billing_email ) ) {
					throw new Exception( __( 'A valid billing email is required to create an account.', 'woocommerce-appointments' ) );
				}

				$existing_user = get_user_by( 'email', $billing_email );
				if ( $existing_user && $existing_user->ID ) {
					$customer_id = (int) $existing_user->ID;

					// Update existing customer's billing data if provided
					$this->update_customer_billing_data( $customer_id, $posted );
				} else {
					// Collect all billing fields for customer creation
					$billing_first_name = self::post_text( '_billing_first_name' );
					$billing_last_name  = self::post_text( '_billing_last_name' );

					$username = '';
					$password = '';

					$customer_id = wc_create_new_customer(
					    $billing_email,
					    $username,
					    $password,
					    [
							'first_name' => $billing_first_name,
							'last_name'  => $billing_last_name,
						],
					);

					if ( is_wp_error( $customer_id ) ) {
						throw new Exception( $customer_id->get_error_message() );
					}

					// Save all billing data to the new customer account (similar to WooCommerce checkout)
					$this->update_customer_billing_data( $customer_id, $posted );
				}
			}

			// Update existing customer's billing data if customer is selected and billing fields are provided.
			// This ensures customer data is saved for future use, even if they already exist.
			if ( $customer_id > 0 && self::post_has_billing_data() ) {
				$this->update_customer_billing_data( $customer_id, $posted );
			}

			// Compute start/end timestamps based on picker style
			// Get admin user's timezone for parsing input dates/times.
			// The admin enters dates/times in their timezone, and we need to save them
			// as timestamps that represent site timezone time (per existing architecture).
			$admin_tz_string = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : 'UTC';
			$site_tz_string  = $admin_tz_string;
			if ( class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
				$admin_tz_string = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
				$site_tz_string  = WC_Appointments_Timezone_Helper::get_site_timezone_string();
			}

			$admin_tz = new DateTimeZone( $admin_tz_string );
			$site_tz  = new DateTimeZone( $site_tz_string );

			$start_timestamp = 0;
			$end_timestamp   = 0;

			if ( $product->has_time() ) {
				if ( empty( $single_date ) || empty( $time_from ) || empty( $time_to ) ) {
					throw new Exception( __( 'Date and start/end times are required.', 'woocommerce-appointments' ) );
				}

				// For admin panel submissions, client now sends site timezone time directly
				// No timezone conversion needed - parse as site timezone time
				try {
					// Parse date/time strings using strtotime() to create "semantic" timestamps.
					// These timestamps are stored as UTC but REPRESENT site timezone times.
					// strtotime() interprets strings in PHP's default timezone (set to site timezone),
					// creating timestamps that match the system's architecture.
					$start_timestamp = strtotime( $single_date . ' ' . $time_from );
					$end_timestamp   = strtotime( $single_date . ' ' . $time_to );
				} catch ( Exception $e ) {
					throw new Exception( __( 'Invalid date/time format.', 'woocommerce-appointments' ) );
				}

				if ( ! $start_timestamp || ! $end_timestamp ) {
					throw new Exception( __( 'Invalid time range.', 'woocommerce-appointments' ) );
				}

				// Handle overnight / multi-day end times.
				// The JS sends appointment_end_days_offset when the computed end time
				// crosses midnight (e.g. 10:00 + 25h addon = 11:00 +1d).
				$end_days_offset = self::post_absint_key( 'appointment_end_days_offset' );
				if ( $end_days_offset > 0 ) {
					$end_timestamp = strtotime( "+{$end_days_offset} day", $end_timestamp );
				} elseif ( $end_timestamp <= $start_timestamp ) {
					// Fallback: if no explicit offset but end <= start, assume next-day
					$end_timestamp = strtotime( '+1 day', $end_timestamp );
				}
				if ( $end_timestamp <= $start_timestamp ) {
					throw new Exception( __( 'Invalid time range.', 'woocommerce-appointments' ) );
				}
			} else {
				try {
					if ( ! empty( $month_from ) && ! empty( $month_to ) ) {
						[ $start_timestamp, $end_timestamp ] = $this->wca_fake_utc_range_timestamps( $month_from, $month_to, true );
					} elseif ( ! empty( $date_from ) && ! empty( $date_to ) ) {
						[ $start_timestamp, $end_timestamp ] = $this->wca_fake_utc_range_timestamps( $date_from, $date_to );
					} elseif ( ! empty( $single_date ) ) {
						[ $start_timestamp, $end_timestamp ] = $this->wca_fake_utc_range_timestamps( $single_date, $single_date );
					} else {
						throw new Exception( __( 'Start and end dates are required.', 'woocommerce-appointments' ) );
					}
				} catch ( Exception $e ) {
					throw new Exception( __( 'Invalid date format.', 'woocommerce-appointments' ) );
				}

				if ( ! $start_timestamp || ! $end_timestamp || $end_timestamp <= $start_timestamp ) {
					throw new Exception( __( 'Invalid date range.', 'woocommerce-appointments' ) );
				}
			}

			// Default refuse unavailable; Screen Options / filter opts in.
			if ( ! apply_filters( 'woocommerce_appointments_admin_allow_unavailable', '1' === get_user_meta( get_current_user_id(), 'wc_appointments_allow_unavailable', true ) ) ) {
				$available = wc_appointments_get_total_available_appointments_for_range(
					$product,
					$start_timestamp,
					$end_timestamp,
					$staff_id ?: null,
					max( 1, (int) $qty ),
					self::post_absint_key( 'appointment_location_id' ),
					self::post_absint_key( 'appointment_resource_id' )
				);
				if ( ! $available ) {
					throw new Exception( __( 'This slot is not available.', 'woocommerce-appointments' ) );
				}
			}

			// Handle order creation/selection
			if ( 'existing' === $order_type && $order_id ) {
				$order = wc_get_order( $order_id );
				if ( ! $order ) {
					throw new Exception( __( 'Invalid order.', 'woocommerce-appointments' ) );
				}
            } else {
                // Create new order
                // Do not set default status explicitly; let WooCommerce defaults apply
                $order = wc_create_order( [
                    'customer_id' => $customer_id,
                ] );

				if ( is_wp_error( $order ) ) {
					throw new Exception( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
				}

                $order_id = $order->get_id();

				do_action( 'woocommerce_new_appointment_order', $order_id );

                // Apply billing details from the admin panel
                $billing = self::posted_billing_address();
                $order->set_address( $billing, 'billing' );

                // Mark created via Appointments for downstream logic and reporting
                $order->set_created_via( 'appointments' );

                // Optional transaction ID
                $transaction_id_raw = self::post_raw( '_billing_transaction_id', null );
                if ( null === $transaction_id_raw ) {
                    $transaction_id_raw = self::post_raw( '_transaction_id', null );
                }
                if ( null !== $transaction_id_raw ) {
                    $transaction_id = wc_clean( (string) $transaction_id_raw );
                    if ( '' !== $transaction_id ) {
                        $order->set_props( [ 'transaction_id' => $transaction_id ] );
                    }
                }

                // Optional payment method selection
                $payment_method_raw = self::post_raw( '_billing_payment_method', null );
                if ( null === $payment_method_raw ) {
                    $payment_method_raw = self::post_raw( '_payment_method', null );
                }
                if ( null !== $payment_method_raw ) {
                    $payment_method = wc_clean( (string) $payment_method_raw );
                    if ( '' !== $payment_method ) {
                        $methods = WC()->payment_gateways() ? WC()->payment_gateways->payment_gateways() : [];
                        if ( isset( $methods[ $payment_method ] ) ) {
                            // Known gateway: set via object to populate id and title
                            $order->set_payment_method( $methods[ $payment_method ] );
                        } else {
                            // Unknown or "other": set both id and title explicitly
                            $order->set_props( [
                                'payment_method'       => $payment_method,
                                'payment_method_title' => ( 'other' === $payment_method ) ? __( 'Other', 'woocommerce-appointments' ) : $payment_method,
                            ] );
                        }
                    }
                }

            }

			// Location first (occupancy / series write depend on it).
			$location_id = self::post_absint_key( 'appointment_location_id' );
			if ( class_exists( 'WC_Appointments_Location' ) && $product->has_locations() ) {
				if ( $location_id <= 0 ) {
					if ( WC_Appointments_Location::is_fixed_mode( $product->get_location_mode() ) ) {
						$allowed     = WC_Appointments_Location::get_allowed_location_ids( $product );
						$location_id = ! empty( $allowed[0] ) ? (int) $allowed[0] : 0;
					} elseif ( 'customer_choice' === $product->get_location_mode() ) {
						$location_id = WC_Appointments_Location::sole_allowed_location_id( $product );
					}
				}
				if ( 'customer_choice' === $product->get_location_mode() && $location_id <= 0 ) {
					wp_send_json_error( [ 'message' => __( 'Please choose a location.', 'woocommerce-appointments' ) ] );
				}
				if ( $location_id > 0 && ! WC_Appointments_Location::authorize_location_id( $product, $location_id ) ) {
					wp_send_json_error( [ 'message' => __( 'Selected location is not available for this product.', 'woocommerce-appointments' ) ] );
				}
			} else {
				$location_id = 0;
			}

			// ── Recurring series branch ──────────────────────────────────────────────
			$wca_recurring_enabled = self::post_bool( 'wca_recurring_enabled' );
			$wca_rrule_raw         = self::post_text( 'wca_rrule' );
			$wca_rrule             = '' !== $wca_rrule_raw
				? WC_Appointment_Series_RRule::sanitize_ical_block( $wca_rrule_raw )
				: '';

			if ( $wca_recurring_enabled && $wca_rrule && class_exists( 'WC_Appointment_Series_Manager' ) ) {
				$preview_args = WC_Appointment_Series_Request::merge_schedule_adjustments(
					[
						'product_id'       => $product_id,
						'dtstart_ts'       => $start_timestamp,
						'timezone'         => wc_timezone_string(),
						'rrule'            => $wca_rrule,
						'duration_seconds' => (int) $product->get_duration_in_minutes() * MINUTE_IN_SECONDS,
						'staff_id'         => $staff_id,
						'location_id'      => $location_id,
						'qty'              => max( 1, (int) $qty ),
						'payment_model'    => WC_Appointment_Series::PAYMENT_PREPAID,
					],
					$posted
				);

				$override_str      = $staff_may_set_status_and_price ? self::post_wc_clean( 'appointment_override_price' ) : '';
				$line_net_override = '' !== $override_str ? self::wca_panel_posted_line_net( $product, 0 ) : null;

				$result = ( new WC_Appointment_Series_Manager() )->create_from_admin_panel_order(
					$order,
					$product,
					$preview_args,
					$line_net_override
				);

				if ( is_wp_error( $result ) ) {
					throw new Exception( $result->get_error_message() );
				}

				self::apply_customer_local_timezone( (int) $customer_id, null, (array) $result->get_appointment_ids() );

				wp_send_json_success( [
					'appointment_id' => $result->get_appointment_ids()[0] ?? 0,
					'series_id'      => $result->get_id(),
					'order_id'       => $order_id,
					'series_count'   => $result->get_materialized_count(),
					'message'        => sprintf(
						/* translators: %d: number of appointments in the series. */
						__( 'Series created with %d appointments.', 'woocommerce-appointments' ),
						$result->get_materialized_count()
					),
				] );
			}

			// Determine staff assignment when none selected, mirroring frontend behavior
			$staff_ids_to_assign = [];
			$eligible_staff      = $product->has_staff() ? array_map( 'intval', (array) $product->get_staff_ids() ) : [];

			if ( $product->has_staff() ) {
				if ( $staff_id ) {
					$staff_ids_to_assign = [ $staff_id ];
				} else {
					$assignment_type = $product->get_staff_assignment();
					$staff_nopref = method_exists( $product, 'get_staff_nopref' ) ? $product->get_staff_nopref() : false;

					if ( 'all' === $assignment_type ) {
						$staff_ids_to_assign = $eligible_staff ? $eligible_staff : $product->get_staff_ids();
					} else {
						$available = wc_appointments_get_total_available_appointments_for_range(
						    $product,
						    $start_timestamp,
						    $end_timestamp,
						    0,
						    1,
						    $location_id
						);
						if ( is_array( $available ) && [] !== $available ) {
							if ( $eligible_staff ) {
								$available = array_intersect_key( $available, array_flip( $eligible_staff ) );
							}
							$keys = array_keys( $available );
							shuffle( $keys );
							$staff_id = (int) reset( $keys );
							if ( 0 !== $staff_id ) {
								$staff_ids_to_assign = [ $staff_id ];
							}
						} else {
							$product_staff_ids = $eligible_staff ? $eligible_staff : $product->get_staff_ids();
							if ( ! empty( $product_staff_ids ) ) {
								$product_staff_ids = array_values( $product_staff_ids );
								shuffle( $product_staff_ids );
								$staff_id = (int) reset( $product_staff_ids );
								$staff_ids_to_assign = [ $staff_id ];
							}
						}
					}
				}
			}

			// Normalize staff_ids - ensure it's in the correct format for the appointment object.
			// The appointment object stores staff_ids as string (comma-separated) or array.
			// For new appointments, we want to avoid triggering staff transitions from empty to assigned.
			// Convert empty arrays to empty string, and ensure arrays are properly formatted.
			$normalized_staff_ids = '';
			if ( ! empty( $staff_ids_to_assign ) ) {
				if ( is_array( $staff_ids_to_assign ) ) {
					// Filter out any empty values and ensure all are integers
					$staff_ids_to_assign = array_filter( array_map( 'intval', $staff_ids_to_assign ) );
					if ( ! empty( $staff_ids_to_assign ) ) {
						$normalized_staff_ids = array_values( $staff_ids_to_assign ); // Re-index array
					}
				}
			}
			// If empty after normalization, use empty string (not empty array) to match default data structure

			// Prepare appointment data but defer saving until everything is set,
			// so events are scheduled only once.
			$appointment_data = [
				'product_id'  => $product_id,
				'start'       => $start_timestamp,
				'end'         => $end_timestamp,
				'all_day'     => ! $product->has_time(),
				'order_id'    => $order_id,
				'customer_id' => $customer_id,
				'staff_ids'   => $normalized_staff_ids,
				'status'      => $status,
			];

			// Resource allocations: honor explicit selection when posted; otherwise auto-pick from pool.
			if ( class_exists( 'WC_Appointments_Resource' ) && $product instanceof WC_Product_Appointment && $product->has_resources() ) {
				$selected_resource    = self::post_absint_key( 'appointment_resource_id' );
				$resource_allocations = WC_Appointments_Resource::build_allocations_from_product(
					$product,
					$selected_resource,
					$location_id,
					(int) $start_timestamp,
					(int) $end_timestamp
				);
				if ( [] === $resource_allocations ) {
					wp_send_json_error( [ 'message' => __( 'This time is no longer available. Please choose another.', 'woocommerce-appointments' ) ] );
				}
				$appointment_data['resource_allocations'] = $resource_allocations;
			}

			// Acquire booking lock to prevent race conditions (admin can also create concurrent bookings).
			$lock_acquired = wc_appointments_acquire_booking_lock( $product_id, $start_timestamp, $end_timestamp, $staff_ids_to_assign );

			if ( ! $lock_acquired ) {
				// Another booking is in progress for this slot, wait briefly and retry once.
				usleep( 100000 ); // 100ms delay.
				$lock_acquired = wc_appointments_acquire_booking_lock( $product_id, $start_timestamp, $end_timestamp, $staff_ids_to_assign );

				if ( ! $lock_acquired ) {
					wp_send_json_error( [ 'message' => __( 'This time slot is currently being processed. Please try again in a moment.', 'woocommerce-appointments' ) ] );
				}
			}

			$appointment = new WC_Appointment( $appointment_data );

			if ( $location_id > 0 && class_exists( 'WC_Appointments_Location' ) ) {
				WC_Appointments_Location::apply_to_appointment( $appointment, $location_id );
			}

			// Set qty and customer status on the object early, but do not save yet.
			$appointment->set_qty( max( 1, (int) $qty ) );
			if ( ! empty( $customer_status ) ) {
				$appointment->set_customer_status( $customer_status );
			}

			// Customer timezone for emails / My Account (display only; schedule stays site/admin TZ).
			self::apply_customer_local_timezone( (int) $customer_id, $appointment );

			// Determine final cost (override or calculated). Staff without status permission cannot forge a custom price.
			$override_str  = $staff_may_set_status_and_price ? self::post_wc_clean( 'appointment_override_price' ) : '';
			$override_price = '' !== $override_str ? wc_format_decimal( $override_str ) : '';
			$final_cost     = null;
			$override_includes_tax = false;
			// Admin panel sends override excluding tax.
			$override_is_excl_tax = self::post_bool( 'appointment_override_price_excl_tax' );

			if ( '' !== $override_price ) {
				$final_cost            = self::wca_panel_posted_line_net( $product, 0 );
				$override_includes_tax = ! $override_is_excl_tax && wc_tax_enabled() && wc_prices_include_tax();
			} else {
				$cost_posted = self::wca_panel_cost_posted_for_slot(
					$product,
					(int) $start_timestamp,
					(string) $time_from,
					(int) $qty,
					(int) $customer_id,
					(int) $staff_id,
					(int) $location_id,
					self::post_absint_key( 'appointment_resource_id' )
				);
				$raw_cost   = WC_Appointments_Cost_Calculation::calculate_appointment_cost( $cost_posted, $product );
				$final_cost = is_wp_error( $raw_cost ) ? 0 : (float) $raw_cost;
			}

			// Panel footer quotes deposit due; a mistaken override can send that slice instead of full base — restore calculated full.
			if ( '' !== $override_price && $final_cost > 0 && class_exists( 'WC_Deposits_Product_Manager' ) && WC_Deposits_Product_Manager::deposits_enabled( $product_id ) ) {
				$dep_option_fix = self::post_wc_clean( 'wc_deposit_option' );
				$plan_id_fix    = self::post_absint_key( 'wc_deposit_payment_plan' );
				if ( WC_Deposits_Product_Manager::deposits_forced( $product_id ) ) {
					$dep_option_fix = 'yes';
				}
				$pay_deposit_fix = WC_Deposits_Product_Manager::deposits_forced( $product_id ) || ( 'yes' === $dep_option_fix );
				if ( $pay_deposit_fix ) {
					$plan_id_fix         = wc_appointments_resolve_deposit_plan_id( $product_id, $plan_id_fix );
					$cost_posted_fix     = self::wca_panel_cost_posted_for_slot(
						$product,
						(int) $start_timestamp,
						(string) $time_from,
						(int) $qty,
						(int) $customer_id,
						(int) $staff_id,
						(int) $location_id,
						self::post_absint_key( 'appointment_resource_id' )
					);
					$calculated_full_fix = WC_Appointments_Cost_Calculation::calculate_appointment_cost( $cost_posted_fix, $product );
					if ( ! is_wp_error( $calculated_full_fix ) && (float) $calculated_full_fix > (float) $final_cost + 0.001 ) {
						$qty_fix   = max( 1, (int) $qty );
						$dep_unit_fix = WC_Deposits_Product_Manager::get_deposit_amount( $product, $plan_id_fix, 'order', (float) $final_cost / $qty_fix );
						if ( false !== $dep_unit_fix && is_numeric( $dep_unit_fix ) && abs( (float) $dep_unit_fix * $qty_fix - (float) $final_cost ) < 0.02 ) {
							$final_cost = (float) $calculated_full_fix;
						}
					}
				}
			}

			// Add product to order and set item totals
			$item_id = $order->add_product( $product, max( 1, (int) $qty ) );

			if ( ! $item_id ) {
				throw new Exception( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
			}

			$item = $order->get_item( $item_id );
			if ( ! $item || ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				throw new Exception( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
			}

			// Handle Product Add-Ons if present
			$addon_cart   = $GLOBALS['Product_Addon_Cart'] ?? null;
			$addons_values = [];
			$addons_total  = 0.0;

			if ( $addon_cart && is_callable( [ $addon_cart, 'add_cart_item_data' ] ) ) {
				$addons_values = $addon_cart->add_cart_item_data( [], $product_id, $posted );
			}

			if ( ! empty( $addons_values['addons'] ) ) {
				$item_data = [
					'product_id'   => $product_id,
					'variation_id' => 0,
					'quantity'     => max( 1, (int) $qty ),
					'data'         => $product,
					'nyp'          => $final_cost,
				];
				$addon_cart->order_line_item( $item, null, array_merge( $item_data, $addons_values ) );
				$addons_total = (float) $item->get_meta( '_pao_total', true );
			}

			// Net line total (excluding tax). Tax is applied later via WC_Order::calculate_totals().
			// When catalog prices are entered inclusive of tax, calculated appointment base + PAO sum match the panel gross quote;
			// convert that combined gross to net before set_subtotal. Manual override amounts are already normalized to net above.
			$had_manual_override_price = ( '' !== $override_price );
			$__wca_combined_gross      = (float) $final_cost + (float) $addons_total;
			$total_cost                = $had_manual_override_price
				? $__wca_combined_gross
				: wc_appointments_admin_line_net_from_amount( $product, $__wca_combined_gross );

			$dep_option = self::post_wc_clean( 'wc_deposit_option' );
			$plan_id    = self::post_absint_key( 'wc_deposit_payment_plan' );
			if ( class_exists( 'WC_Deposits_Product_Manager' ) && WC_Deposits_Product_Manager::deposits_forced( $product_id ) ) {
				$dep_option = 'yes';
			}

			$deposit_totals        = wc_appointments_resolve_deposit_line_net( $product, (float) $total_cost, max( 1, (int) $qty ), $dep_option, $plan_id, true );
			$full_line_net_total   = $deposit_totals['full_line_net'];
			$line_item_net_total   = $deposit_totals['line_net'];
			$wca_deposit_applied   = $deposit_totals['deposit_applied'];
			$plan_id               = $deposit_totals['plan_id'];

			// WooCommerce Deposits item meta (same as storefront order flow).
			if ( $wca_deposit_applied ) {
				$deposit_meta = self::wca_deposit_order_item_amounts(
					$product,
					$__wca_combined_gross,
					$full_line_net_total,
					$line_item_net_total,
					max( 1, (int) $qty )
				);

				$item->add_meta_data( '_is_deposit', 'yes', true );
				$item->add_meta_data( '_deposit_full_amount', $deposit_meta['full_inc'], true );
				$item->add_meta_data( '_deposit_full_amount_ex_tax', $deposit_meta['full_ex'], true );
				$item->add_meta_data( '_deposit_deposit_amount_ex_tax', $deposit_meta['dep_ex'], true );
				if ( $plan_id > 0 ) {
					$item->add_meta_data( '_payment_plan', $plan_id, true );
				}
			}

			$total_cost = $line_item_net_total;

			// Set line item totals (excluding tax); clear taxes so calculate_totals() can compute from order address.
			$item->set_subtotal( $total_cost );
			$item->set_total( $total_cost );
			$item->set_taxes( [] );

			$item->save();

			// Order totals before appointment save so SSE order_info.total is not still 0.
			$this->wca_calculate_order_totals_for_line_net( $order, $product, $item_id, max( 1, (int) $qty ), $total_cost );

			if ( $wca_deposit_applied && defined( 'WC_DEPOSITS_VERSION' ) ) {
				$order->update_meta_data( '_wc_deposits_version', WC_DEPOSITS_VERSION );
				$order->save();
			}

			// Set the appointment cost
			$appointment->set_cost( $total_cost );
			// Link appointment to order item
			$appointment->set_order_item_id( $item_id );
			$appointment_id = $appointment->save();
			if ( 0 === $appointment_id ) {
				wc_appointments_release_booking_lock( $product_id, $start_timestamp, $end_timestamp, $staff_ids_to_assign );
				throw new Exception( __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) );
			}

			// Release lock on success
			wc_appointments_release_booking_lock( $product_id, $start_timestamp, $end_timestamp, $staff_ids_to_assign );

			// Persist internal link on the line item (underscore prefix: hidden from wc_display_item_meta / emails).
			$item->add_meta_data( '_appointment_id', [ $appointment_id ], true );
			$item->delete_meta_data( 'appointment_id' );
			$item->save();

			// Send success response — `success_when`: WC formats; site→admin via wc_appointment_timezone_locale when TZs differ (panel adds abbr).
			$df = function_exists( 'wc_appointments_date_format' ) ? wc_appointments_date_format() : get_option( 'date_format', 'F j, Y' );
			$tf = function_exists( 'wc_appointments_time_format' ) ? wc_appointments_time_format() : get_option( 'time_format', 'g:i a' );
			$tz = ( $admin_tz_string !== $site_tz_string && '' !== $admin_tz_string );
			$ca = function ( int $ts ) use ( $tz, $admin_tz_string ) {
				if ( ! $tz || ! function_exists( 'wc_appointment_timezone_locale' ) ) {
					return $ts;
				}
				$o = wc_appointment_timezone_locale( 'site', 'user', $ts, 'U', $admin_tz_string );
				return false !== $o ? (int) $o : $ts;
			};
			$success_when = '';
			if ( ! empty( $single_date ) ) {
				if ( $product->has_time() && ! empty( $time_from ) && ! empty( $time_to ) ) {
					$s = $ca( $start_timestamp );
					$e = $ca( $end_timestamp );
					$d1 = wp_date( $df, $s );
					$d2 = wp_date( $df, $e );
					$success_when = ( $d1 === $d2 )
						? $d1 . ' ' . wp_date( $tf, $s ) . "\xe2\x80\x93" . wp_date( $tf, $e )
						: $d1 . ' ' . wp_date( $tf, $s ) . ' – ' . $d2 . ' ' . wp_date( $tf, $e );
				} else {
					$success_when = wp_date( $df, $ca( $start_timestamp ) );
				}
			} elseif ( ! empty( $date_from ) ) {
				$d1 = wp_date( $df, $ca( $start_timestamp ) );
				$d2 = wp_date( $df, $ca( $end_timestamp - 1 ) );
				$success_when = ( ! empty( $date_to ) && $date_to !== $date_from ) ? $d1 . ' -> ' . $d2 : $d1;
			} elseif ( ! empty( $month_from ) ) {
				$a = wp_date( 'F Y', $ca( $start_timestamp ) );
				$b = wp_date( 'F Y', $ca( $end_timestamp - 1 ) );
				$success_when = ( ! empty( $month_to ) && $month_to !== $month_from ) ? $a . ' -> ' . $b : $a;
			}

			$redirect_context = ( 'calendar' === $wca_admin_create_context ) ? 'admin_ajax_calendar' : 'admin_ajax_standalone';
			$filtered = apply_filters(
				'woocommerce_appointments_add_appointment_page_redirect',
				'',
				$appointment,
				$order_id ? wc_get_order( $order_id ) : false,
				'existing' !== $order_type,
				$redirect_context
			);
			$raw = is_string( $filtered ) ? trim( $filtered ) : '';
			$post_create_redirect = '' !== $raw
				? (string) wp_validate_redirect( esc_url_raw( $raw ), '' )
				: '';
			if ( 'admin_ajax_calendar' === $redirect_context ) {
				$post_create_redirect = '';
			}

			$created_status = $appointment->get_status();
			if ( in_array( $created_status, get_wc_appointment_statuses( 'user' ), true ) ) {
				update_user_meta( $user_id, 'wc_appointments_admin_create_status', $created_status );
			}

			wp_send_json_success( [
				'appointment_id' => $appointment_id,
				'order_id' => $order_id,
				'success_when' => $success_when,
				'message' => __( 'Appointment created successfully.', 'woocommerce-appointments' ),
				'post_create_redirect' => $post_create_redirect,
			] );

		} catch ( Exception $e ) {
			// Release lock on error if it was acquired.
			if ( $lock_acquired && $product_id && $start_timestamp && $end_timestamp ) {
				wc_appointments_release_booking_lock( $product_id, $start_timestamp, $end_timestamp, $staff_ids_to_assign );
			}
			wp_send_json_error( $e->getMessage() );
		}
	}

	public function get_customer_details(): void {
		check_ajax_referer( 'get-customer-details', 'security' );

		if ( ! current_user_can( 'edit_shop_orders' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( __( 'Unauthorized', 'woocommerce-appointments' ), 403 );
		}

		$user_id = self::post_absint_key( 'user_id' );
		if ( ! $user_id ) {
			wp_send_json_error( __( 'Invalid user.', 'woocommerce-appointments' ), 400 );
		}

		$viewer     = get_current_user_id();
		$can_create = false;
		if ( WC_Appointments_Staff_Permissions::is_staff_user( $viewer ) ) {
			$can_create = WC_Appointments_Staff_Permissions::can( $viewer, 'create_appointments' );
			if ( ! $can_create && ! WC_Appointments_Staff_Permissions::can( $viewer, 'view_all_customers' ) ) {
				if ( ! WC_Appointments_Staff_Permissions::can( $viewer, 'view_customers' ) ) {
					wp_send_json_error( __( 'Unauthorized', 'woocommerce-appointments' ), 403 );
				}
				$linked = false;
				foreach ( (array) WC_Appointment_Data_Store::get_appointment_ids_by(
					[
						'object_id'   => $user_id,
						'object_type' => 'customer',
						'limit'       => 25,
					]
				) as $appointment_id ) {
					$appointment = get_wc_appointment( (int) $appointment_id );
					if ( $appointment && in_array( $viewer, array_map( 'intval', (array) $appointment->get_staff_ids() ), true ) ) {
						$linked = true;
						break;
					}
				}
				if ( ! $linked ) {
					wp_send_json_error( __( 'Unauthorized', 'woocommerce-appointments' ), 403 );
				}
			}
		}

		$user = get_userdata( $user_id );
		$data = [
			'first_name'       => get_user_meta( $user_id, 'billing_first_name', true ),
			'last_name'        => get_user_meta( $user_id, 'billing_last_name', true ),
			'company'          => get_user_meta( $user_id, 'billing_company', true ),
			'address_1'        => get_user_meta( $user_id, 'billing_address_1', true ),
			'address_2'        => get_user_meta( $user_id, 'billing_address_2', true ),
			'city'             => get_user_meta( $user_id, 'billing_city', true ),
			'postcode'         => get_user_meta( $user_id, 'billing_postcode', true ),
			'country'          => get_user_meta( $user_id, 'billing_country', true ),
			'state'            => get_user_meta( $user_id, 'billing_state', true ),
			'email'            => get_user_meta( $user_id, 'billing_email', true ),
			'phone'            => get_user_meta( $user_id, 'billing_phone', true ),
			// Empty = Default (site timezone), same as My Account / staff profile.
			'timezone'         => class_exists( 'WC_Appointments_Timezone_Helper' )
				? WC_Appointments_Timezone_Helper::get_user_timezone_raw( $user_id )
				: '',
			'user_first_name'  => get_user_meta( $user_id, 'first_name', true ),
			'user_last_name'   => get_user_meta( $user_id, 'last_name', true ),
			'display_name'     => $user ? $user->display_name : '',
		];
		$full_name = trim( ( $data['user_first_name'] ?: '' ) . ' ' . ( $data['user_last_name'] ?: '' ) );
		if ( ( '' === $full_name || '0' === $full_name ) && $user ) {
			$full_name = $user->display_name;
		}
		$data['name'] = $full_name;
		if ( empty( $data['email'] ) && $user ) {
			$data['email'] = $user->user_email;
		}

		// Create autofill needs email/phone; otherwise soft Contact Customers.
		if ( ! $can_create
			&& WC_Appointments_Staff_Permissions::is_staff_user( $viewer )
			&& ! WC_Appointments_Staff_Permissions::can( $viewer, 'contact_customers' ) ) {
			$data['email'] = '';
			$data['phone'] = '';
		}

		$data = array_map( 'wc_clean', $data );
		wp_send_json_success( $data );
	}

	/**
	 * Return pretty labels for a list of minute durations using wc_appointment_pretty_timestamp.
	 */
	public function pretty_duration(): void {
		check_ajax_referer( 'wc_appointments_pretty_duration', 'security' );

		$raw  = self::post_raw( 'durations', '' );
		$unit = self::post_text( 'duration_unit', 'minute' );

		$durations = json_decode( $raw, true );
		if ( ! is_array( $durations ) ) {
			$durations = array_filter( array_map( function( $id ) { return self::wca_abs_int( $id ); }, explode( ',', (string) $raw ) ) );
		} else {
			$durations = array_map( function( $id ) { return self::wca_abs_int( $id ); }, $durations );
		}

		$labels = [];
		foreach ( $durations as $d ) {
			$labels[] = WC_Appointment_Duration::format_minutes( $d, $unit );
		}

		wp_send_json_success( [ 'labels' => $labels ] );
	}

	/**
	 * Update customer billing data from POST data.
	 *
	 * Saves all billing fields to user meta, similar to WooCommerce checkout.
	 * This ensures customer data can be reused for future orders.
	 *
	 * @since 5.1.0
	 *
	 * @param int   $customer_id Customer/User ID.
	 * @param array<string, mixed> $post_data   POST data array containing billing fields.
	 *
	 * @return void
	 */
	private function update_customer_billing_data( int $customer_id, array $post_data ): void {
		if ( $customer_id <= 0 ) {
			return;
		}

		// Object-level: require customer edit, shop manage, or order-edit (staff booking flow).
		if (
			! current_user_can( 'edit_user', $customer_id )
			&& ! current_user_can( 'manage_woocommerce' )
			&& ! current_user_can( 'edit_shop_orders' )
		) {
			throw new Exception( __( 'You do not have permission to update this customer.', 'woocommerce-appointments' ) );
		}

		// Map POST field names to user meta keys
		$billing_fields = [
			'_billing_first_name' => 'billing_first_name',
			'_billing_last_name'  => 'billing_last_name',
			'_billing_company'    => 'billing_company',
			'_billing_address_1'  => 'billing_address_1',
			'_billing_address_2'  => 'billing_address_2',
			'_billing_city'       => 'billing_city',
			'_billing_postcode'   => 'billing_postcode',
			'_billing_country'    => 'billing_country',
			'_billing_state'      => 'billing_state',
			'_billing_email'      => 'billing_email',
			'_billing_phone'      => 'billing_phone',
		];

		// Save each billing field to user meta
		foreach ( $billing_fields as $post_key => $meta_key ) {
			if ( isset( $post_data[ $post_key ] ) ) {
				$value = '';

				// Sanitize based on field type
				if ( '_billing_email' === $post_key ) {
					$value = sanitize_email( wp_unslash( $post_data[ $post_key ] ) );
				} elseif ( '_billing_country' === $post_key ) {
					$value = strtoupper( sanitize_text_field( wp_unslash( $post_data[ $post_key ] ) ) );
				} else {
					$value = sanitize_text_field( wp_unslash( $post_data[ $post_key ] ) );
				}

				// Only update if value is not empty (preserve existing data if field is empty)
				if ( ! empty( $value ) ) {
					update_user_meta( $customer_id, $meta_key, $value );
				}
			}
		}

		// Also update first_name and last_name user meta (used by WordPress and WooCommerce)
		if ( isset( $post_data['_billing_first_name'] ) && ! empty( $post_data['_billing_first_name'] ) ) {
			update_user_meta( $customer_id, 'first_name', sanitize_text_field( wp_unslash( $post_data['_billing_first_name'] ) ) );
		}
		if ( isset( $post_data['_billing_last_name'] ) && ! empty( $post_data['_billing_last_name'] ) ) {
			update_user_meta( $customer_id, 'last_name', sanitize_text_field( wp_unslash( $post_data['_billing_last_name'] ) ) );
		}

		// Update display name if first and last name are available
		if ( isset( $post_data['_billing_first_name'] ) && isset( $post_data['_billing_last_name'] ) ) {
			$first_name = sanitize_text_field( wp_unslash( $post_data['_billing_first_name'] ) );
			$last_name  = sanitize_text_field( wp_unslash( $post_data['_billing_last_name'] ) );

			if ( ! empty( $first_name ) && ! empty( $last_name ) ) {
				wp_update_user(
					[
						'ID'           => $customer_id,
						'display_name' => trim( $first_name . ' ' . $last_name ),
					]
				);
			}
		}
	}

	/**
	 * Get all available time slots for a single day.
	 *
	 * Returns slot-level availability with capacity and staff info so the admin
	 * panel can display a chip panel of available times without blind guessing.
	 *
	 * Uses WC_Appointment_Slots_Provider::get_collection() — the same single
	 * source of truth as the frontend date picker and admin month availability.
	 */
	public function get_day_slots(): void {

		check_ajax_referer( 'wc_appointments_get_day_slots', 'nonce' );

		if ( ! current_user_can( 'edit_appointments' ) ) {
			wp_die( -1 );
		}


		$product_id = self::post_absint_key( 'product_id' );
		$date       = self::post_text( 'date' );
		$staff_id   = self::post_absint_key( 'staff_id' );
		$location_id = self::post_absint_first( [ 'location_id', 'appointment_location_id' ] );
		$resource_id = self::post_absint_first( [ 'resource_id', 'appointment_resource_id' ] );
		$qty        = max( 1, self::post_absint_key( 'quantity' ) ?: 1 );
		$edit_appt_cand = self::post_absint_key( 'editing_appointment_id' );

		if ( ! $product_id || ! $date ) {
			wp_send_json_error( __( 'Product and date are required.', 'woocommerce-appointments' ) );
		}

		$product = get_wc_product_appointment( $product_id );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			wp_send_json_error( __( 'Invalid product.', 'woocommerce-appointments' ) );
		}

		$overlap_exclude_appt_id = 0;
		if ( $edit_appt_cand > 0 && current_user_can( 'edit_post', $edit_appt_cand ) ) {
			$edit_appt_obj = get_wc_appointment( $edit_appt_cand );
			if ( $edit_appt_obj && (int) $edit_appt_obj->get_product_id() === (int) $product_id ) {
				$overlap_exclude_appt_id = $edit_appt_cand;
			}
		}

		if ( ! $product->has_time() ) {
			wp_send_json_success( [ 'slots' => [], 'total_available' => 0, 'date' => $date ] );
		}

		// Site-local midnight for the browse calendar day (matches check_availability / get_posted_data).
		try {
			$day_start = $this->wca_site_midnight_timestamp( $date );
		} catch ( Exception $e ) {
			wp_send_json_error( __( 'Invalid date.', 'woocommerce-appointments' ) );
		}

		// Admin/Staff timezone: when a user is logged in and timezone display is enabled,
		// display slot times in their personal timezone (matching adjust_appointment_to_timezone behavior).
		$admin_tz_display = '';
		$should_show_admin_tz = is_user_logged_in() && class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() );
		if ( $should_show_admin_tz ) {
			$site_tz = WC_Appointments_Timezone_Helper::get_site_timezone_string();
			$user_tz = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
			// Only convert when the user TZ differs from the site TZ.
			if ( $user_tz && $user_tz !== $site_tz ) {
				$admin_tz_display = $user_tz;
			}
		}

		// Normalize staff_ids to an array.
		$staff_ids = [];
		if ( $product->has_staff() && $staff_id && 0 < $staff_id ) {
			$staff_ids = [ $staff_id ];
		} elseif ( $product->has_staff() ) {
			if ( $product->is_staff_assignment_type( 'all' ) ) {
				// Staff all together at the same time.
				$staff_ids = array_map( 'intval', (array) $product->get_staff_ids() );
			}
			// For 'customer' assignment with no staff selected, pass empty array
			// to allow individual staff processing (same as frontend).
		} else {
			$staff_ids = [ 0 ];
		}
		$staff_ids = array_unique( $staff_ids );

		[ $location_id, $resource_id ] = $this->wca_authorize_product_location_resource( $product, $location_id, $resource_id );

		// If timezone conversion is active (or for boundary safety), expand query range.
		// Use $day_start from wca_site_midnight_timestamp() for timezone-safe calculation.
		$provider_start = $day_start - DAY_IN_SECONDS;
		$provider_end   = $day_start + ( 2 * DAY_IN_SECONDS );

		if ( $overlap_exclude_appt_id > 0 ) {
			WC_Appointment_Slots_Engine::set_overlap_exclude_appointment_ids( [ $overlap_exclude_appt_id ] );
		}

		try {
			$collection = WC_Appointment_Slots_Provider::get_collection(
				$product,
				$provider_start,
				$provider_end,
				$staff_ids,
				false,
				false,
				'',
				$location_id,
				false,
				$resource_id
			);
		} catch ( Exception $e ) {
			WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();
			wp_send_json_success( [ 'slots' => [], 'total_available' => 0, 'date' => $date ] );
		}
		WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();

		// UNIFIED SLOTS STANDARDIZATION: Delegate to Collection for grouping and formatting.
		// All post-processing (filtering, grouping, timezone conversion, pricing) done in slots subsystem.
		$has_pricing = $product->get_has_pricing() && wc_appointments_slots_display_pricing( $product );

		$result = $collection->get_grouped_for_admin_json(
			$product,
			$date,
			$admin_tz_display,
			$qty,
			$has_pricing
		);

		wp_send_json_success( [
			'slots'           => $result['slots'],
			'total_available' => $result['total_available'],
			'date'            => $date,
		] );
	}

	/**
	 * First bookable slot for admin panel auto-pick (same Provider path as storefront date picker).
	 */
	public function get_first_available_slot_panel(): void {
		check_ajax_referer( 'wc_appointments_get_first_available_slot', 'nonce' );

		if ( ! current_user_can( 'edit_appointments' ) ) {
			wp_die( -1 );
		}

		$product_id = self::post_absint_key( 'product_id' );
		$staff_id   = self::post_absint_key( 'staff_id' );

		if ( ! $product_id ) {
			wp_send_json_error( __( 'This field is required.', 'woocommerce-appointments' ) );
		}

		$product = get_wc_product_appointment( $product_id );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			wp_send_json_error( __( 'Invalid product.', 'woocommerce-appointments' ) );
		}

		$now      = strtotime( 'midnight', current_time( 'timestamp' ) );
		$min      = $product->get_min_date_a();
		$max      = $product->get_max_date_a();
		$min_date = $now;
		if ( ! empty( $min ) ) {
			$min_date = strtotime( "+{$min['value']} {$min['unit']}", $now );
		}
		$from_date = self::post_text( 'from_date' );
		if ( $from_date && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from_date ) ) {
			try {
				$from_ts = $this->wca_site_midnight_timestamp( $from_date );
				if ( $from_ts > $min_date ) {
					$min_date = $from_ts;
				}
			} catch ( Exception $e ) {
				// Keep product min.
			}
		}
		$max_date       = strtotime( "+{$max['value']} {$max['unit']}", $now );
		$staff_for_slot = $staff_id > 0 ? $staff_id : 0;

		$first_ts = WC_Appointment_Slots_Provider::find_first_available_slot_chunked(
			$product,
			$min_date,
			$max_date,
			$staff_for_slot,
			false,
			14
		);

		if ( ! $first_ts ) {
			wp_send_json_success( [ 'found' => false ] );
		}

		$admin_tz_display = '';
		if ( is_user_logged_in() && class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) ) {
			$site_tz = WC_Appointments_Timezone_Helper::get_site_timezone_string();
			$user_tz = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
			if ( $user_tz && $user_tz !== $site_tz ) {
				$admin_tz_display = $user_tz;
			}
		}
		$site_tz_string = wc_timezone_string();
		if ( $admin_tz_display && $admin_tz_display !== $site_tz_string ) {
			$converted_ts = WC_Appointments_Timezone_Helper::convert_timestamp( (int) $first_ts, $site_tz_string, $admin_tz_display );
		} else {
			$converted_ts = (int) $first_ts;
		}
		$admin_date = gmdate( 'Y-m-d', $converted_ts );
		$admin_time = $product->has_time() ? gmdate( 'H:i', $converted_ts ) : '';
		$site_date  = gmdate( 'Y-m-d', (int) $first_ts );
		$site_time  = $product->has_time() ? gmdate( 'H:i', (int) $first_ts ) : '';

		$payload = [
			'found'         => true,
			'start_ts'      => (int) $first_ts,
			'date'          => $admin_date,
			'time'          => $admin_time,
			'site_date'     => $site_date,
			'site_time'     => $site_time,
			'duration_unit' => $product->get_duration_unit(),
		];
		if ( 'month' === $product->get_duration_unit() ) {
			$payload['month'] = gmdate( 'Y-m', $converted_ts );
		}

		wp_send_json_success( $payload );
	}

	/**
	 * Get lightweight availability summary for an entire month.
	 *
	 * Uses WC_Appointment_Slots_Provider::get_collection() — the same single
	 * source of truth as the frontend date picker and admin day slots.
	 * When admin calendar timezone display is enabled (see get_day_slots),
	 * minute/hour products rebucket slots by that timezone so each grid day
	 * matches the day chips / slot list; otherwise day keys follow the Collection
	 * (site-local), same as storefront without customer offset.
	 */
	public function get_month_availability(): void {
		check_ajax_referer( 'wc_appointments_get_month_availability', 'nonce' );

		if ( ! current_user_can( 'edit_appointments' ) ) {
			wp_die( -1 );
		}

		// POST values may be "" (PHP 8+ abs() is int|float only); ?? does not treat "" as missing.
		$product_id     = self::post_absint_key( 'product_id' );
		$year_month     = self::post_text( 'year_month' );
		$staff_id       = self::post_absint_key( 'staff_id' );
		$location_id    = self::post_absint_first( [ 'location_id', 'appointment_location_id' ] );
		$resource_id    = self::post_absint_first( [ 'resource_id', 'appointment_resource_id' ] );
		$focus_date     = self::post_text( 'date' );
		$edit_appt_cand = self::post_absint_key( 'editing_appointment_id' );
		$requested_qty  = max( 1, self::post_absint_key( 'quantity' ) ?: 1 );

		if ( ! $product_id || ! $year_month ) {
			wp_send_json_error( __( 'Product and month are required.', 'woocommerce-appointments' ) );
		}

		// Validate year_month format (YYYY-MM).
		if ( ! preg_match( '/^\d{4}-\d{2}$/', $year_month ) ) {
			wp_send_json_error( __( 'Invalid month format.', 'woocommerce-appointments' ) );
		}

		$product = get_wc_product_appointment( $product_id );
		if ( ! $product || ! is_wc_appointment_product( $product ) ) {
			wp_send_json_error( __( 'Invalid product.', 'woocommerce-appointments' ) );
		}

		$duration_unit = $product->get_duration_unit();

		$civil_utc_bounds = in_array( $duration_unit, [ 'day', 'month' ], true );
		if ( $civil_utc_bounds ) {
			$month_start   = (int) strtotime( $year_month . '-01 00:00:00 UTC' );
			$days_in_month = (int) gmdate( 't', $month_start );
			$month_end     = (int) strtotime( $year_month . '-' . $days_in_month . ' 00:00:00 UTC +1 day' );
		} else {
			$month_start   = strtotime( $year_month . '-01 00:00:00' );
			$days_in_month = (int) date( 't', $month_start );
			$month_end     = strtotime( $year_month . '-' . $days_in_month . ' 23:59:59' ) + 1;
		}

		// Admin display TZ: same rules as get_day_slots() — calendar cells must match slot filtering.
		$admin_tz_display = '';
		if ( is_user_logged_in() && class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) ) {
			$site_tz = WC_Appointments_Timezone_Helper::get_site_timezone_string();
			$user_tz = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
			if ( $user_tz && $user_tz !== $site_tz ) {
				$admin_tz_display = $user_tz;
			}
		}

		$rebucket_admin_calendar_days = ( '' !== $admin_tz_display )
			&& $product->has_time()
			&& in_array( $duration_unit, [ 'minute', 'hour' ], true );

		$provider_start = $month_start;
		$provider_end   = $month_end;
		if ( $rebucket_admin_calendar_days ) {
			$provider_start = $month_start - DAY_IN_SECONDS;
			$provider_end   = $month_end + DAY_IN_SECONDS;
		}

		// Normalize staff_ids to an array.
		$staff_ids = [];
		if ( $product->has_staff() && $staff_id && 0 < $staff_id ) {
			$staff_ids = [ $staff_id ];
		} elseif ( $product->has_staff() ) {
			if ( $product->is_staff_assignment_type( 'all' ) ) {
				// Staff all together at the same time.
				$staff_ids = array_map( 'intval', (array) $product->get_staff_ids() );
			}
			// For 'customer' assignment with no staff selected, pass empty array
			// to allow individual staff processing (same as frontend).
		} else {
			$staff_ids = [ 0 ];
		}
		$staff_ids = array_unique( $staff_ids );

		[ $location_id, $resource_id ] = $this->wca_authorize_product_location_resource( $product, $location_id, $resource_id );

		// Empty multi-staff strip: narrow provider to ~±8 days around the visible center.
		$empty_multi_staff = $product->has_staff() && empty( $staff_ids );
		if ( $empty_multi_staff && '1' === self::post_text( 'strip' ) ) {
			$strip_center = self::post_text( 'strip_center' );
			if ( $focus_date && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $focus_date ) ) {
				$anchor = $focus_date;
			} elseif ( $strip_center && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $strip_center ) ) {
				$anchor = $strip_center;
			} else {
				$anchor = $year_month . '-15';
			}
			try {
				$anchor_dt      = new DateTimeImmutable( $anchor . ' 00:00:00', new DateTimeZone( wc_timezone_string() ) );
				$provider_start = $anchor_dt->modify( '-8 days' )->getTimestamp();
				$provider_end   = $anchor_dt->modify( '+9 days' )->getTimestamp();
			} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch -- Keep month bounds.
			}
		}

		$overlap_exclude_appt_id = 0;
		if ( $edit_appt_cand > 0 && current_user_can( 'edit_post', $edit_appt_cand ) ) {
			$edit_appt_obj = get_wc_appointment( $edit_appt_cand );
			if ( $edit_appt_obj && (int) $edit_appt_obj->get_product_id() === (int) $product_id ) {
				$overlap_exclude_appt_id = $edit_appt_cand;
			}
		}
		if ( $overlap_exclude_appt_id > 0 ) {
			WC_Appointment_Slots_Engine::set_overlap_exclude_appointment_ids( [ $overlap_exclude_appt_id ] );
		}

		// ── Month-based products: return per-month data ──────────────
		// The admin JS expects availability for all 12 months of the year,
		// so we expand the range to the full year before calling the Provider.
		if ( 'month' === $duration_unit ) {
			$year_parts   = explode( '-', $year_month );
			$request_year = (int) $year_parts[0];
			$year_start   = (int) strtotime( $request_year . '-01-01 00:00:00 UTC' );
			$year_end     = (int) strtotime( $request_year . '-12-01 00:00:00 UTC +1 month' );

			try {
				$collection = WC_Appointment_Slots_Provider::get_collection( $product, $year_start, $year_end, $staff_ids, false, false, '', $location_id, false, $resource_id );
			} catch ( Exception $e ) {
				$collection = null;
			}
			WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();

			$months = [];
			if ( $collection ) {
				foreach ( $collection->get_months() as $month_key => $month_summary ) {
					$months[ $month_key ] = [
						'available'   => $month_summary->has_availability,
						'slots_count' => $month_summary->has_availability ? 1 : 0,
					];
				}
			}

			// Fill any missing months in the requested year.
			for ( $m = 1; $m <= 12; $m++ ) {
				$month_str = $request_year . '-' . str_pad( (string) $m, 2, '0', STR_PAD_LEFT );
				if ( ! isset( $months[ $month_str ] ) ) {
					$months[ $month_str ] = [ 'available' => false, 'slots_count' => 0 ];
				}
			}

			ksort( $months );


			wp_send_json_success( [
				'months'        => $months,
				'days'          => [],
				'duration_unit' => $duration_unit,
			] );
		}

		// ── Single source of truth: Provider::get_collection() ───────
		// Identical call to the frontend find_scheduled_day_slots handler.
		// Handles all duration types (minute, hour, day) via the
		// unified engine. No separate branches, no divergent paths.
		try {
			$collection = WC_Appointment_Slots_Provider::get_collection( $product, $provider_start, $provider_end, $staff_ids, false, false, '', $location_id, false, $resource_id );
		} catch ( Exception $e ) {
			$collection = null;
		}
		WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();

		// ── Day-level availability (all other duration types) ────────
		$days          = [];
		$day_summaries = $collection ? $collection->get_days() : [];

		$tz_day = null;
		if ( $collection && $rebucket_admin_calendar_days ) {
			try {
				$tz_day = new DateTimeZone( $admin_tz_display );
			} catch ( Exception $e ) {
				$tz_day = null;
			}
		}

		if ( $collection && $tz_day ) {
			$slots_by_display_day = [];
			$site_tz_for_bucket   = wc_timezone_string();
			foreach ( $collection->get_all_slots() as $slot ) {
				// Fake UTC start_ts: convert wall to admin TZ, then gmdate civil day (not wp_date on raw token).
				$converted = WC_Appointments_Timezone_Helper::convert_timestamp(
					(int) $slot->start_ts,
					$site_tz_for_bucket,
					$admin_tz_display
				);
				$dk = gmdate( 'Y-m-d', $converted );
				$slots_by_display_day[ $dk ][] = $slot;
			}
			for ( $d = 1; $d <= $days_in_month; $d++ ) {
				$day_str = $year_month . '-' . str_pad( (string) $d, 2, '0', STR_PAD_LEFT );
				$slots   = WC_Appointment_Slots_Collection::slots_for_day_summary(
					$product,
					$slots_by_display_day[ $day_str ] ?? []
				);
				if ( empty( $slots ) ) {
					$days[ $day_str ] = [ 'available' => false, 'slots_count' => 0 ];
					continue;
				}
				$day_summary = WC_Appointment_Day_Summary::from_slots( $day_str, $slots, $requested_qty );
				if ( in_array( $day_summary->status, [ 'unavailable', 'fully_booked' ], true ) ) {
					$days[ $day_str ] = [ 'available' => false, 'slots_count' => 0 ];
					continue;
				}
				$days[ $day_str ] = [
					'available'   => $day_summary->available_slots > 0,
					'slots_count' => $day_summary->available_slots,
				];
			}
		} else {
			// Site-TZ day keys: use Collection day summaries (bookable-start filter applied in from_slots).
			$by_day = ( $requested_qty > 1 && $collection ) ? $collection->get_slots_by_day() : null;
			for ( $d = 1; $d <= $days_in_month; $d++ ) {
				$day_str     = $year_month . '-' . str_pad( (string) $d, 2, '0', STR_PAD_LEFT );
				$day_summary = $day_summaries[ $day_str ] ?? null;
				if ( $by_day && $day_summary && $day_summary->available_slots > 0 ) {
					$day_summary = WC_Appointment_Day_Summary::from_slots( $day_str, WC_Appointment_Slots_Collection::slots_for_day_summary( $product, $by_day[ $day_str ] ?? [] ), $requested_qty );
				}

				if ( null === $day_summary || in_array( $day_summary->status, [ 'unavailable', 'fully_booked' ], true ) ) {
					$days[ $day_str ] = [ 'available' => false, 'slots_count' => 0 ];
					continue;
				}

				$days[ $day_str ] = [
					'available'   => $day_summary->available_slots > 0,
					'slots_count' => $day_summary->available_slots,
				];
			}
		}

		ksort( $days );

		wp_send_json_success( [
			'days'          => $days,
			'duration_unit' => $duration_unit,
		] );
	}

	/**
	 * Admin calendar: fetch appointment rows for a visible range (internal API, no REST HTTP).
	 */
	public function admin_calendar_range(): void {
		if ( ! check_ajax_referer( 'wp_rest', 'security', false ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Invalid security token. Reload the page.', 'woocommerce-appointments' ),
				],
				403
			);
		}

		if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_appointments' ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Sorry, you cannot list calendar appointments.', 'woocommerce-appointments' ),
				],
				403
			);
		}

		$start_ts = self::post_absint_key( 'start_ts' );
		$end_ts   = self::post_absint_key( 'end_ts' );

		if ( ! $start_ts || ! $end_ts || $end_ts <= $start_ts ) {
			wp_send_json_error(
				[
					'message' => __( 'Invalid date range.', 'woocommerce-appointments' ),
				]
			);
		}

		$product_id = self::post_absint_key( 'product_id' );

		$staff_filter = null;
		if ( null !== self::post_raw( 'staff_id', null ) ) {
			$staff_filter = self::post_absint_key( 'staff_id' );
		}

		if ( ! class_exists( 'WC_Appointments_Admin_Calendar' ) ) {
			require_once WC_APPOINTMENTS_ABSPATH . 'includes/admin/class-wc-appointments-admin-calendar.php';
		}

		$appointments = WC_Appointments_Admin_Calendar::fetch_calendar_appointments_for_range(
			$start_ts,
			$end_ts,
			$product_id,
			$staff_filter
		);

		wp_send_json_success( $appointments );
	}

	/**
	 * Save user's preferred calendar view.
	 */
	public function save_calendar_view(): void {
		check_ajax_referer( 'wc_appointments_calendar_view', 'security' );

		$view = self::post_text( 'view' );
		$allowed_views = [ 'week', 'day', 'month', 'list', 'staff' ];

		if ( ! in_array( $view, $allowed_views, true ) ) {
			wp_send_json_error( [ 'message' => 'Invalid view' ] );
		}

		update_user_meta( get_current_user_id(), 'calendar_view', $view );
		wp_send_json_success();
	}

	/**
	 * Save user's preferred admin panel browse mini-calendar layout (7-day strip vs full month).
	 *
	 * Uses the same nonce as {@see save_calendar_view()} for consistency.
	 */
	public function save_browse_mini_cal(): void {
		check_ajax_referer( 'wc_appointments_calendar_view', 'security' );

		$expanded = self::post_text( 'expanded' );

		if ( '1' !== $expanded && '0' !== $expanded ) {
			wp_send_json_error( [ 'message' => 'Invalid value' ] );
		}

		update_user_meta( get_current_user_id(), 'wc_appointments_browse_mini_cal_expanded', $expanded );
		wp_send_json_success();
	}

	/**
	 * Export Google Calendar sync rules as JSON.
	 */
	public function export_gcal_rules(): void {
		check_ajax_referer( 'wc_appointments_gcal_backup', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'user_id' );
		$rules = $this->get_synced_rules( $user_id );

		$export_data = [
			'version'     => '1.0',
			'export_date' => gmdate( 'Y-m-d\TH:i:s\Z' ),
			'context'     => $user_id ? 'staff' : 'global',
			'context_id'  => $user_id,
			'rule_count'  => count( $rules ),
			'rules'       => array_map( [ $this, 'serialize_rule' ], $rules ),
		];

		wp_send_json_success( $export_data );
	}

	/**
	 * Import Google Calendar sync rules from JSON.
	 */
	public function import_gcal_rules(): void {
		check_ajax_referer( 'wc_appointments_gcal_backup', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$json_data = self::post_raw( 'data', '' );
		$data = json_decode( $json_data, true );

		if ( ! $data || ! isset( $data['rules'] ) || ! is_array( $data['rules'] ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid import data.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::wca_abs_int( $data['context_id'] ?? 0 );
		$imported = $this->restore_rules( $data['rules'], $user_id, 'staff' === ( $data['context'] ?? '' ) );

		wp_send_json_success( [
			'message' => sprintf(
				/* translators: %d: number of rules imported */
				__( 'Successfully imported %d rules.', 'woocommerce-appointments' ),
				$imported
			),
			'imported' => $imported,
		] );
	}

	/**
	 * Get list of available backups.
	 */
	public function get_gcal_backups(): void {
		check_ajax_referer( 'wc_appointments_gcal_backup', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'user_id' );
		$backups = $this->get_stored_backups( $user_id );

		wp_send_json_success( [ 'backups' => $backups ] );
	}

	/**
	 * Restore a specific backup.
	 */
	public function restore_gcal_backup(): void {
		check_ajax_referer( 'wc_appointments_gcal_backup', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'user_id' );
		$backup_id = self::post_text( 'backup_id' );

		if ( empty( $backup_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid backup ID.', 'woocommerce-appointments' ) ] );
		}

		$backup_data = $this->get_backup_by_id( $user_id, $backup_id );
		if ( ! $backup_data ) {
			wp_send_json_error( [ 'message' => __( 'Backup not found.', 'woocommerce-appointments' ) ] );
		}

		// Delete existing rules and restore from backup.
		$this->delete_synced_rules( $user_id );
		$restored = $this->restore_rules( $backup_data['rules'], $user_id, ! empty( $user_id ) );

		wp_send_json_success( [
			'message' => sprintf(
				/* translators: %d: number of rules restored */
				__( 'Successfully restored %d rules.', 'woocommerce-appointments' ),
				$restored
			),
			'restored' => $restored,
		] );
	}

	/**
	 * Delete a specific backup.
	 */
	public function delete_gcal_backup(): void {
		check_ajax_referer( 'wc_appointments_gcal_backup', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'woocommerce-appointments' ) ] );
		}

		$user_id = self::post_absint_key( 'user_id' );
		$backup_id = self::post_text( 'backup_id' );

		if ( empty( $backup_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid backup ID.', 'woocommerce-appointments' ) ] );
		}

		$this->delete_backup_by_id( $user_id, $backup_id );

		wp_send_json_success( [ 'message' => __( 'Backup deleted successfully.', 'woocommerce-appointments' ) ] );
	}

	/**
	 * Get all stored backups for a context.
	 *
	 * @param int $user_id User ID for staff context, or 0 for global.
	 * @return list<array<string, mixed>> List of backups with metadata.
	 */
	private function get_stored_backups( int $user_id ): array {
		$option_key = $user_id ? 'wc_appointments_gcal_backups_staff_' . $user_id : 'wc_appointments_gcal_backups_global';
		$backups = get_option( $option_key, [] );

		// Clean up expired backups (older than 7 days).
		$now = time();
		$backups = array_filter( $backups, function( $backup ) use ( $now ) {
			return isset( $backup['timestamp'] ) && ( $now - $backup['timestamp'] ) < ( 7 * DAY_IN_SECONDS );
		} );

		// Sort by timestamp descending (newest first).
		usort( $backups, function( $a, $b ) {
			return ( $b['timestamp'] ?? 0 ) - ( $a['timestamp'] ?? 0 );
		} );

		// Keep only last 5 backups.
		$backups = array_slice( $backups, 0, 5 );

		// Update option with cleaned backups.
		update_option( $option_key, $backups, false );

		return $backups;
	}

	/**
	 * Get a specific backup by ID.
	 *
	 * @param int    $user_id User ID for staff context, or 0 for global.
	 * @param string $backup_id Backup ID.
	 * @return array<string, mixed>|null Backup data or null if not found.
	 */
	private function get_backup_by_id( int $user_id, string $backup_id ): ?array {
		$backups = $this->get_stored_backups( $user_id );
		foreach ( $backups as $backup ) {
			if ( $backup['id'] === $backup_id ) {
				return $backup;
			}
		}
		return null;
	}

	/**
	 * Delete a specific backup by ID.
	 *
	 * @param int    $user_id User ID for staff context, or 0 for global.
	 * @param string $backup_id Backup ID.
	 */
	private function delete_backup_by_id( int $user_id, string $backup_id ): void {
		$option_key = $user_id ? 'wc_appointments_gcal_backups_staff_' . $user_id : 'wc_appointments_gcal_backups_global';
		$backups = get_option( $option_key, [] );

		$backups = array_filter( $backups, function( $backup ) use ( $backup_id ) {
			return $backup['id'] !== $backup_id;
		} );

		update_option( $option_key, array_values( $backups ), false );
	}

	/**
	 * Store a persistent backup after successful sync.
	 *
	 * @param int   $user_id User ID for staff context, or 0 for global.
	 * @param list<array<string, mixed>> $rules Array of availability rules.
	 */
	private function store_persistent_backup( int $user_id, array $rules ): void {
		$backup_id = 'backup_' . time() . '_' . wp_generate_password( 8, false );
		$backup_data = [
			'id'        => $backup_id,
			'timestamp' => time(),
			'rule_count' => count( $rules ),
			'rules'     => $rules,
		];

		$option_key = $user_id ? 'wc_appointments_gcal_backups_staff_' . $user_id : 'wc_appointments_gcal_backups_global';
		$backups = get_option( $option_key, [] );
		array_unshift( $backups, $backup_data );

		// Keep only last 5 backups.
		$backups = array_slice( $backups, 0, 5 );

		update_option( $option_key, $backups, false );
	}

	/**
	 * Get synced rules for a context (global or staff).
	 *
	 * @param int $user_id User ID for staff context, or 0 for global.
	 * @return array<int, mixed> Array of WC_Appointments_Availability objects.
	 */
	private function get_synced_rules( int $user_id ): array {
		$availability_data_store = WC_Data_Store::load( 'appointments-availability' );
		$filter = $user_id
			? [
				[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#staff' ],
				[ 'key' => 'kind_id', 'compare' => '=', 'value' => $user_id ],
				[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
			]
			: [
				[ 'key' => 'kind', 'compare' => '=', 'value' => 'availability#global' ],
				[ 'key' => 'event_id', 'compare' => '!=', 'value' => '' ],
			];

		return $availability_data_store->get_all( $filter );
	}

	/**
	 * Serialize a rule object to array.
	 *
	 * @param WC_Appointments_Availability $rule Rule object.
	 * @return array<string, mixed> Serialized rule data.
	 */
	private function serialize_rule( $rule ): array {
		return [
			'event_id'        => $rule->get_event_id(),
			'parent_event_id' => $rule->get_parent_event_id(),
			'title'           => $rule->get_title(),
			'range_type'      => $rule->get_range_type(),
			'from_date'       => $rule->get_from_date(),
			'to_date'         => $rule->get_to_date(),
			'from_range'      => $rule->get_from_range(),
			'to_range'        => $rule->get_to_range(),
			'appointable'     => $rule->get_appointable(),
			'priority'        => $rule->get_priority(),
			'qty'             => $rule->get_qty(),
			'ordering'        => $rule->get_ordering(),
			'rrule'           => $rule->get_rrule(),
			'kind'            => $rule->get_kind(),
			'kind_id'         => $rule->get_kind_id(),
		];
	}

	/**
	 * Delete synced rules for a context with Google Calendar protection.
	 *
	 * @param int $user_id User ID for staff context, or 0 for global.
	 */
	private function delete_synced_rules( int $user_id ): void {
		$gcal_integration_class = wc_appointments_gcal();
		remove_action( 'woocommerce_before_appointments_availability_object_save', [ $gcal_integration_class, 'sync_availability' ] );
		remove_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

		try {
			$rules = $this->get_synced_rules( $user_id );
			foreach ( $rules as $rule ) {
				$rule->delete();
			}
		} finally {
			add_action( 'woocommerce_before_appointments_availability_object_save', [ $gcal_integration_class, 'sync_availability' ] );
			add_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );
		}
	}

	/**
	 * Restore rules from serialized data with Google Calendar protection.
	 *
	 * @param list<array<string, mixed>> $rules_data Array of serialized rule data.
	 * @param int   $user_id User ID for staff context, or 0 for global.
	 * @param bool  $is_staff Whether this is a staff context.
	 * @return int Number of rules restored.
	 */
	private function restore_rules( array $rules_data, int $user_id, bool $is_staff ): int {
		$gcal_integration_class = wc_appointments_gcal();
		remove_action( 'woocommerce_before_appointments_availability_object_save', [ $gcal_integration_class, 'sync_availability' ] );
		remove_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );

		$restored = 0;
		try {
			foreach ( $rules_data as $rule_data ) {
				$availability = get_wc_appointments_availability();
				$availability->set_event_id( $rule_data['event_id'] ?? '' );
				$availability->set_parent_event_id( $rule_data['parent_event_id'] ?? '' );
				$availability->set_title( $rule_data['title'] ?? '' );
				$availability->set_range_type( $rule_data['range_type'] ?? 'custom' );
				$availability->set_from_range( $rule_data['from_range'] ?? '' );
				$availability->set_to_range( $rule_data['to_range'] ?? '' );
				$availability->set_from_date( $rule_data['from_date'] ?? '' );
				$availability->set_to_date( $rule_data['to_date'] ?? '' );
				$availability->set_appointable( $rule_data['appointable'] ?? 'no' );
				$availability->set_priority( $rule_data['priority'] ?? 10 );
				$availability->set_qty( $rule_data['qty'] ?? '' );
				$availability->set_ordering( $rule_data['ordering'] ?? 0 );
				$availability->set_rrule( $rule_data['rrule'] ?? '' );
				$availability->set_kind( $rule_data['kind'] ?? ( $is_staff ? 'availability#staff' : 'availability#global' ) );
				$availability->set_kind_id( $rule_data['kind_id'] ?? $user_id );
				$availability->save();
				$restored++;
			}
		} finally {
			add_action( 'woocommerce_before_appointments_availability_object_save', [ $gcal_integration_class, 'sync_availability' ] );
			add_action( 'woocommerce_appointments_before_delete_appointment_availability', [ $gcal_integration_class, 'delete_availability' ] );
		}

		return $restored;
	}

}

$GLOBALS['wc_appointments_admin_ajax'] = new WC_Appointments_Admin_Ajax();
