<?php
/**
 * Recurring series options on the appointable product edit screen.
 *
 * @var WC_Product $product_object
 *
 * @package WooCommerce\Appointments\Admin\Views
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

$product = WC_Product_Appointment::as_appointment_product( $product_object ?? null );
if ( ! $product ) {
	return;
}

$allow_recurring  = $product->get_allow_recurring( 'edit' );
$limits           = $product->get_recurring_occurrence_limits();
$allowed_freqs    = $product->get_recurring_allowed_freqs();
$absolute_max     = WC_Product_Appointment::RECURRING_ABSOLUTE_MAX_OCCURRENCES;

woocommerce_wp_checkbox(
	array(
		'id'          => '_wc_appointment_allow_recurring',
		'label'       => __( 'Can be recurring?', 'woocommerce-appointments' ),
		'value'       => $allow_recurring ? 'yes' : 'no',
		'description' => __( 'Customers can book a recurring package.', 'woocommerce-appointments' ),
	)
);
?>
<div class="appointment-recurring-storefront-options" style="<?php echo $allow_recurring ? '' : 'display:none;'; ?>">
	<p class="form-field wca-recurring-freqs-field">
		<label><?php esc_html_e( 'Repeat frequencies', 'woocommerce-appointments' ); ?></label>
		<span class="wca-admin-checkbox-list">
			<?php foreach ( WC_Product_Appointment::get_recurring_freq_choices() as $freq_code => $freq_label ) : ?>
			<label class="wca-admin-checkbox-item">
				<input
					type="checkbox"
					name="_wc_appointment_recurring_allowed_freqs[]"
					value="<?php echo esc_attr( $freq_code ); ?>"
					<?php checked( in_array( $freq_code, $allowed_freqs, true ) ); ?>
				/>
				<?php echo esc_html( $freq_label ); ?>
			</label>
			<?php endforeach; ?>
		</span>
	</p>

	<?php
	woocommerce_wp_select(
		array(
			'id'          => WC_Product_Appointment::META_RECURRING_PAYMENT_OPTIONS,
			'label'       => __( 'Payment options', 'woocommerce-appointments' ),
			'value'       => $product->get_recurring_payment_setting(),
			'options'     => WC_Product_Appointment::get_recurring_payment_setting_choices(),
			'class'       => 'wc-enhanced-select',
			'desc_tip'    => true,
			'description' => __( 'Payment options on the booking form. When both are allowed, pay-all is pre-selected.', 'woocommerce-appointments' ),
		)
	);
	?>

	<?php
	foreach (
		array(
			WC_Product_Appointment::META_RECURRING_MIN_OCCURRENCES => array(
				'label'       => __( 'Minimum (required)', 'woocommerce-appointments' ),
				'description' => __( 'Billable appointments required at checkout.', 'woocommerce-appointments' ),
				'value'       => $limits['min'],
				'custom_attributes' => array(
					'step' => 1,
					'min'  => 2,
					'max'  => $limits['max'],
				),
			),
			WC_Product_Appointment::META_RECURRING_MAX_OCCURRENCES => array(
				'label'       => __( 'Maximum (allowed)', 'woocommerce-appointments' ),
				'description' => __( 'Maximum billable appointments allowed at checkout.', 'woocommerce-appointments' ),
				'value'       => $limits['max'],
				'custom_attributes' => array(
					'step' => 1,
					'min'  => max( 2, $limits['min'] ),
					'max'  => $absolute_max,
				),
			),
		) as $field_id => $field
	) {
		woocommerce_wp_text_input(
			array_merge(
				array(
					'type'     => 'number',
					'id'       => $field_id,
					'desc_tip' => true,
				),
				$field
			)
		);
	}
	?>
</div>
