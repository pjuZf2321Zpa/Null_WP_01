<?php
/**
 * Staff Customers View
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 *
 * @var array<int, array<string, mixed>> $customers        Set by WC_Appointments_Admin_Staff_Menu::render_customers_page().
 * @var bool                             $can_view_all     Set by WC_Appointments_Admin_Staff_Menu::render_customers_page().
 * @var bool                             $can_view_history Set by WC_Appointments_Admin_Staff_Menu::render_customers_page().
 * @var bool                             $can_contact      Set by WC_Appointments_Admin_Staff_Menu::render_customers_page().
 */

defined( 'ABSPATH' ) || exit;

$customer_count = count( $customers );
?>

<div class="wca-admin-page wca-staff-customers">
	<div class="wca-page-header">
		<div class="wca-page-header-content">
			<a href="<?php echo esc_url( admin_url( 'index.php' ) ); ?>" class="wca-page-back">
				<span class="dashicons dashicons-arrow-left-alt2"></span>
				<?php esc_html_e( 'Dashboard', 'woocommerce-appointments' ); ?>
			</a>
			<h1 class="wca-page-title">
				<?php esc_html_e( 'Customers', 'woocommerce-appointments' ); ?>
				<?php if ( $can_view_all ) : ?>
					<span class="wca-badge wca-badge-primary"><?php esc_html_e( 'All Customers', 'woocommerce-appointments' ); ?></span>
				<?php endif; ?>
			</h1>
			<p class="wca-page-subtitle">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of customers */
						_n(
							'%d customer across your appointments',
							'%d customers across your appointments',
							$customer_count,
							'woocommerce-appointments'
						),
						(int) $customer_count
					)
				);
				?>
			</p>
		</div>
	</div>

	<!-- Toolbar -->
	<div class="wca-toolbar">
		<div class="wca-toolbar-left">
			<div class="wca-search-box">
				<span class="dashicons dashicons-search"></span>
				<input type="text" id="wca-customer-search" placeholder="<?php esc_attr_e( 'Search by name or email...', 'woocommerce-appointments' ); ?>">
			</div>
			<div class="wca-filter-group">
				<select id="wca-customer-filter">
					<option value="all"><?php esc_html_e( 'All Customers', 'woocommerce-appointments' ); ?></option>
					<option value="returning"><?php esc_html_e( 'Returning Customers', 'woocommerce-appointments' ); ?></option>
					<option value="new"><?php esc_html_e( 'New Customers', 'woocommerce-appointments' ); ?></option>
				</select>
			</div>
		</div>
		<div class="wca-toolbar-right">
			<span
				class="wca-results-count"
				id="wca-results-count"
				data-singular="<?php
					echo esc_attr(
						/* translators: %d: number of results */
						__( '%d result', 'woocommerce-appointments' )
					);
				?>"
				data-plural="<?php
					echo esc_attr(
						/* translators: %d: number of results */
						__( '%d results', 'woocommerce-appointments' )
					);
				?>"
			>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: number of results */
						_n( '%d result', '%d results', $customer_count, 'woocommerce-appointments' ),
						(int) $customer_count
					)
				);
				?>
			</span>
			<select id="wca-customer-sort">
				<option value="name-asc"><?php esc_html_e( 'Name (A-Z)', 'woocommerce-appointments' ); ?></option>
				<option value="name-desc"><?php esc_html_e( 'Name (Z-A)', 'woocommerce-appointments' ); ?></option>
				<option value="appointments-desc"><?php esc_html_e( 'Most Appointments', 'woocommerce-appointments' ); ?></option>
				<option value="appointments-asc"><?php esc_html_e( 'Fewest Appointments', 'woocommerce-appointments' ); ?></option>
				<option value="recent"><?php esc_html_e( 'Most Recent', 'woocommerce-appointments' ); ?></option>
			</select>
		</div>
	</div>

	<?php if ( ! empty( $customers ) ) : ?>
		<!-- List View -->
		<div class="wca-customers-list wca-view-container active" data-view="list">
			<table class="wca-table">
				<thead>
					<tr>
						<th class="wca-col-customer"><?php esc_html_e( 'Customer', 'woocommerce-appointments' ); ?></th>
						<th class="wca-col-contact"><?php esc_html_e( 'Contact', 'woocommerce-appointments' ); ?></th>
						<?php if ( ! empty( $show_timezone_column ) ) : ?>
							<th class="wca-col-timezone"><?php esc_html_e( 'Timezone', 'woocommerce-appointments' ); ?></th>
						<?php endif; ?>
						<th class="wca-col-appointments"><?php esc_html_e( 'Appointments', 'woocommerce-appointments' ); ?></th>
						<th class="wca-col-last"><?php esc_html_e( 'Last Visit', 'woocommerce-appointments' ); ?></th>
						<?php if ( $can_view_history ) : ?>
							<th class="wca-col-actions"><?php esc_html_e( 'Actions', 'woocommerce-appointments' ); ?></th>
						<?php endif; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $customers as $customer ) : ?>
						<tr class="wca-customer-row"
							data-name="<?php echo esc_attr( strtolower( $customer['name'] ) ); ?>"
							data-email="<?php echo esc_attr( strtolower( $customer['email'] ) ); ?>"
							data-appointments="<?php echo esc_attr( $customer['appointment_count'] ); ?>"
							data-last="<?php echo esc_attr( $customer['last_appointment'] ?: 0 ); ?>">
							<td class="wca-col-customer" data-label="<?php esc_attr_e( 'Customer', 'woocommerce-appointments' ); ?>">
								<div class="wca-customer-cell">
									<div class="wca-customer-avatar wca-avatar-sm">
										<?php if ( $customer['avatar'] ) : ?>
											<img src="<?php echo esc_url( $customer['avatar'] ); ?>" alt="<?php echo esc_attr( $customer['name'] ); ?>">
										<?php else : ?>
											<span class="wca-avatar-placeholder">
												<?php echo esc_html( strtoupper( substr( $customer['name'], 0, 1 ) ) ); ?>
											</span>
										<?php endif; ?>
									</div>
									<div class="wca-customer-details">
										<span class="wca-customer-name"><?php echo esc_html( $customer['name'] ); ?></span>
										<?php if ( $customer['appointment_count'] > 1 ) : ?>
											<span class="wca-badge wca-badge-success wca-badge-sm"><?php esc_html_e( 'Returning', 'woocommerce-appointments' ); ?></span>
										<?php endif; ?>
									</div>
								</div>
							</td>
							<td class="wca-col-contact" data-label="<?php esc_attr_e( 'Contact', 'woocommerce-appointments' ); ?>">
								<div class="wca-contact-cell">
									<?php if ( $can_contact && $customer['email'] ) : ?>
										<a href="mailto:<?php echo esc_attr( $customer['email'] ); ?>" class="wca-contact-inline" title="<?php esc_attr_e( 'Send Email', 'woocommerce-appointments' ); ?>">
											<span class="dashicons dashicons-email-alt"></span>
											<?php echo esc_html( $customer['email'] ); ?>
										</a>
									<?php endif; ?>
									<?php if ( $can_contact && ! empty( $customer['phone'] ) ) : ?>
										<a href="tel:<?php echo esc_attr( $customer['phone'] ); ?>" class="wca-contact-inline" title="<?php esc_attr_e( 'Call', 'woocommerce-appointments' ); ?>">
											<span class="dashicons dashicons-phone"></span>
											<?php echo esc_html( $customer['phone'] ); ?>
										</a>
									<?php endif; ?>
								</div>
							</td>
							<?php if ( ! empty( $show_timezone_column ) ) : ?>
								<td class="wca-col-timezone" data-label="<?php esc_attr_e( 'Timezone', 'woocommerce-appointments' ); ?>">
									<?php if ( ! empty( $customer['timezone_string'] ) && class_exists( 'WC_Appointments_Timezone_Helper' ) ) : ?>
										<?php echo wp_kses_post( WC_Appointments_Timezone_Helper::build_timezone_indicator_html( $customer['timezone_string'] ) ); ?>
									<?php else : ?>
										<span class="wca-muted">&ndash;</span>
									<?php endif; ?>
								</td>
							<?php endif; ?>
							<td class="wca-col-appointments" data-label="<?php esc_attr_e( 'Appointments', 'woocommerce-appointments' ); ?>">
								<span class="wca-appointment-pill">
									<?php echo esc_html( $customer['appointment_count'] ); ?>
								</span>
							</td>
							<td class="wca-col-last" data-label="<?php esc_attr_e( 'Last Visit', 'woocommerce-appointments' ); ?>">
								<?php if ( $customer['last_appointment'] ) : ?>
									<span class="wca-date" title="<?php echo esc_attr( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $customer['last_appointment'] ) ); ?>">
										<?php echo esc_html( date_i18n( get_option( 'date_format' ), $customer['last_appointment'] ) ); ?>
									</span>
								<?php else : ?>
									<span class="wca-muted">&ndash;</span>
								<?php endif; ?>
							</td>
							<?php if ( $can_view_history ) : ?>
								<td class="wca-col-actions" data-label="<?php esc_attr_e( 'Actions', 'woocommerce-appointments' ); ?>">
									<?php if ( $customer['id'] ) : ?>
										<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&filter_customer=' . $customer['id'] ) ); ?>" class="wca-btn wca-btn-text wca-btn-sm">
											<span class="dashicons dashicons-calendar-alt"></span>
											<?php esc_html_e( 'View History', 'woocommerce-appointments' ); ?>
										</a>
									<?php elseif ( $customer['email'] ) : ?>
										<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&filter_customer_email=' . rawurlencode( $customer['email'] ) ) ); ?>" class="wca-btn wca-btn-text wca-btn-sm">
											<span class="dashicons dashicons-calendar-alt"></span>
											<?php esc_html_e( 'View History', 'woocommerce-appointments' ); ?>
										</a>
									<?php endif; ?>
								</td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<div class="wca-no-results hidden">
			<div class="wca-empty-icon">
				<span class="dashicons dashicons-search"></span>
			</div>
			<h3><?php esc_html_e( 'No customers found', 'woocommerce-appointments' ); ?></h3>
			<p><?php esc_html_e( 'Try adjusting your search or filter criteria.', 'woocommerce-appointments' ); ?></p>
		</div>
	<?php else : ?>
		<div class="wca-empty-state">
			<div class="wca-empty-icon">
				<span class="dashicons dashicons-groups"></span>
			</div>
			<h2><?php esc_html_e( 'No customers yet', 'woocommerce-appointments' ); ?></h2>
			<p><?php esc_html_e( 'Customers who book appointments with you will appear here.', 'woocommerce-appointments' ); ?></p>
		</div>
	<?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
	var $listView = $('.wca-customers-list');
	var $noResults = $('.wca-no-results');

	function filterAndSort() {
		var query = $('#wca-customer-search').val().toLowerCase();
		var filter = $('#wca-customer-filter').val();
		var sort = $('#wca-customer-sort').val();
		var visibleCount = 0;

		// Get all items
		var $listItems = $listView.find('.wca-customer-row');

		// Filter
		$listItems.each(function() {
			var $item = $(this);
			var name = $item.data('name') || '';
			var email = $item.data('email') || '';
			var appointments = parseInt($item.data('appointments')) || 0;
			var matchesSearch = name.indexOf(query) !== -1 || email.indexOf(query) !== -1;
			var matchesFilter = filter === 'all' ||
				(filter === 'returning' && appointments > 1) ||
				(filter === 'new' && appointments <= 1);

			if (matchesSearch && matchesFilter) {
				$item.removeClass('hidden');
				visibleCount++;
			} else {
				$item.addClass('hidden');
			}
		});

		// Sort items
		var $sortedList = $listItems.sort(function(a, b) {
			var $a = $(a);
			var $b = $(b);
			
			switch (sort) {
				case 'name-asc':
					return ($a.data('name') || '').localeCompare($b.data('name') || '');
				case 'name-desc':
					return ($b.data('name') || '').localeCompare($a.data('name') || '');
				case 'appointments-desc':
					return (parseInt($b.data('appointments')) || 0) - (parseInt($a.data('appointments')) || 0);
				case 'appointments-asc':
					return (parseInt($a.data('appointments')) || 0) - (parseInt($b.data('appointments')) || 0);
				case 'recent':
					return (parseInt($b.data('last')) || 0) - (parseInt($a.data('last')) || 0);
				default:
					return 0;
			}
		});
		$listView.find('tbody').append($sortedList);

		// Update results count from translated singular/plural templates.
		var $count = $('#wca-results-count');
		var template = visibleCount === 1 ? $count.data('singular') : $count.data('plural');
		$count.text(String(template || '%d results').replace('%d', String(visibleCount)));

		// Show/hide no results message
		if (visibleCount === 0) {
			$noResults.removeClass('hidden');
		} else {
			$noResults.addClass('hidden');
		}
	}

	// Event handlers
	$('#wca-customer-search').on('input', filterAndSort);
	$('#wca-customer-filter').on('change', filterAndSort);
	$('#wca-customer-sort').on('change', filterAndSort);

});
</script>
