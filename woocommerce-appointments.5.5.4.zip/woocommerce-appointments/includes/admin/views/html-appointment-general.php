<?php
/**
 * Product edit panel — general appointment options.
 *
 * @var WC_Product_Appointment $appointable_product Global; set by WC_Appointments_Admin::appointment_general().
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
?>
<div class="options_group show_if_appointment">
	<?php
	woocommerce_wp_checkbox(
		[
			'id'          => '_wc_appointment_has_price_label',
			'label'       => __( 'Label instead of price?', 'woocommerce-appointments' ),
			'value'       => $appointable_product->get_has_price_label( 'edit' ) ? 'yes' : 'no',
			'description' => __( 'Replaces the numeric price on the product page.', 'woocommerce-appointments' ),
		],
	);

	woocommerce_wp_text_input(
	    [
			'id'          => '_wc_appointment_price_label',
			'label'       => __( 'Price Label', 'woocommerce-appointments' ),
			'placeholder' => __( 'Price Varies', 'woocommerce-appointments' ),
			'value'       => $appointable_product->get_price_label( 'edit' ),
			'desc_tip'    => true,
			'description' => __( 'Shown on the product page.', 'woocommerce-appointments' ),
		],
	);

		woocommerce_wp_checkbox(
		    [
			'id'          => '_wc_appointment_has_pricing',
			'label'       => __( 'Custom pricing rules?', 'woocommerce-appointments' ),
			'value'       => $appointable_product->get_has_pricing( 'edit' ) ? 'yes' : 'no',
			'description' => __( 'Adjust cost by day, time, or date range.', 'woocommerce-appointments' ),
		],
		);
	?>
	<?php do_action( 'woocommerce_appointments_after_display_cost', get_the_ID() ); ?>
	<?php
	// Determine pricing behavior based on product modified date vs when plugin was updated to 5.0.0
	// Products saved after 5.0.0 update use interval-based, older products use duration-based
	$product_id = $appointable_product->get_id();
	$product_post = get_post( $product_id );
	$use_interval_based = true; // Default to interval-based for new products

	if ( $product_post ) {
		$product_modified = $product_post->post_modified_gmt;
		$plugin_5_0_0_update_time = get_option( 'wc_appointments_version_5_0_0_update_time', '' );

		// If product was modified before 5.0.0 update, use duration-based
		if ( $plugin_5_0_0_update_time && $product_modified && $product_modified < $plugin_5_0_0_update_time ) {
			$use_interval_based = false;
		}
	}

	// Build slot cost explanation based on product modified date
	if ( $use_interval_based ) {
		// Interval-based pricing: slot = interval (for products saved after 5.0.0)
		$slot_cost_explanation = __( 'Slot is interval. Applied to each interval segment of the appointment. For example, if duration is 3 hours and interval is 1 hour, a 3-hour appointment is divided into 3 segments (each 1 hour), and this cost is applied to each segment separately.', 'woocommerce-appointments' );
	} else {
		// Duration-based pricing: slot = duration (for products saved before 5.0.0)
		$slot_cost_explanation = __( 'Slot is duration. Applied to each duration segment of the appointment. For example, if duration is 3 hours and interval is 1 hour, a 3-hour appointment is 1 segment (3 hours), and this cost is applied once. When appointment lasts for 2 days or more, this cost applies to each day in range separately.', 'woocommerce-appointments' );
	}

	// Build base cost explanation
	$base_cost_explanation = __( 'Applied once to the entire appointment when any part of the appointment overlaps with the rule\'s time/date range. This is a fixed cost per appointment, regardless of duration or number of segments.', 'woocommerce-appointments' );
	?>
	<div id="appointments_pricing">
		<div class="table_grid">
			<table class="widefat">
				<thead>
					<tr>
						<th class="sort">&nbsp;</th>
						<th class="range_type"><?php esc_html_e( 'Type', 'woocommerce-appointments' ); ?></th>
						<th class="range_name"><?php esc_html_e( 'Range', 'woocommerce-appointments' ); ?></th>
						<th class="range_name2"></th>
						<th class="range_cost"><?php esc_html_e( 'Base cost', 'woocommerce-appointments' ); ?><?php echo wc_help_tip( esc_html( $base_cost_explanation ) ); ?></th>
						<th class="range_cost"><?php esc_html_e( 'Slot cost', 'woocommerce-appointments' ); ?><?php echo wc_help_tip( esc_html( $slot_cost_explanation ) ); ?></th>
						<th class="remove">&nbsp;</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th colspan="7">
							<a
								href="#"
								class="button add_grid_row"
								<?php
								ob_start();
								require __DIR__ . '/html-appointment-pricing-fields.php';
								$html = ob_get_clean();
								echo 'data-row="' . esc_attr( $html ) . '"';
								?>
							>
								<?php esc_html_e( 'Add Rule', 'woocommerce-appointments' ); ?>
							</a>
							<span class="description"><?php esc_html_e( 'All matching rules will be applied to the appointment.', 'woocommerce-appointments' ); ?></span>
						</th>
					</tr>
				</tfoot>
				<tbody id="pricing_rows">
					<?php
					$values = $appointable_product->get_pricing( 'edit' );
					#print '<pre>'; print_r( $values ); print '</pre>';
					if ( ! empty( $values ) && is_array( $values ) ) {
						foreach ( $values as $pricing ) {
							require __DIR__ . '/html-appointment-pricing-fields.php';
							do_action( 'woocommerce_appointments_pricing_fields', $pricing );
						}
					}
					?>
				</tbody>
			</table>
		</div>
		<?php do_action( 'woocommerce_appointments_after_appointments_pricing', get_the_ID() ); ?>
	</div>
</div>
<div class="options_group show_if_appointment" id="appointments_general">
	<?php
	$duration      = 0 === $appointable_product->get_duration( 'edit' ) ? 1 : max( absint( $appointable_product->get_duration( 'edit' ) ), 1 );
	$duration_unit = $appointable_product->get_duration_unit( 'edit' );
	if ( '' == $duration_unit ) {
		$duration_unit = WC_Appointments_Constants::DURATION_HOUR;
	}
	?>
	<p class="form-field">
		<label for="_wc_appointment_duration"><?php esc_html_e( 'Duration', 'woocommerce-appointments' ); ?></label>
		<input type="number" name="_wc_appointment_duration" id="_wc_appointment_duration" value="<?php echo esc_html( $duration ); ?>" step="1" min="1">
		<select name="_wc_appointment_duration_unit" id="_wc_appointment_duration_unit" class="short">
			<option value="minute" <?php selected( $duration_unit, 'minute' ); ?>><?php esc_html_e( 'Minute(s)', 'woocommerce-appointments' ); ?></option>
			<option value="hour" <?php selected( $duration_unit, 'hour' ); ?>><?php esc_html_e( 'Hour(s)', 'woocommerce-appointments' ); ?></option>
			<option value="day" <?php selected( $duration_unit, 'day' ); ?>><?php esc_html_e( 'Day(s)', 'woocommerce-appointments' ); ?></option>
			<option value="month" <?php selected( $duration_unit, 'month' ); ?>><?php esc_html_e( 'Month(s)', 'woocommerce-appointments' ); ?></option>
		</select>
		<?php echo wc_help_tip( esc_html__( 'How long each appointment lasts. Must fit inside any appointable time-range availability rule. Do not increase duration to shift start times; use a time-range rule instead.', 'woocommerce-appointments' ) ); ?>
	</p>
	<?php
	$interval_s = $appointable_product->get_interval( 'edit' );
	$interval = '' == $interval_s ? $duration : max( absint( $interval_s ), 1 );
	$interval_unit = $appointable_product->get_interval_unit( 'edit' );
	if ( '' == $interval_unit ) {
		$interval_unit = $duration_unit;
	} elseif ( 'day' == $interval_unit ) {
		$interval_unit = WC_Appointments_Constants::DURATION_HOUR;
	}
	?>
	<p class="form-field _wc_appointment_interval_duration_wrap">
		<label for="_wc_appointment_interval"><?php esc_html_e( 'Interval', 'woocommerce-appointments' ); ?></label>
		<input type="number" name="_wc_appointment_interval" id="_wc_appointment_interval" value="<?php echo esc_html( $interval ); ?>" step="1" min="1">
		<select name="_wc_appointment_interval_unit" id="_wc_appointment_interval_unit" class="short">
			<option value="minute" <?php selected( $interval_unit, 'minute' ); ?>><?php esc_html_e( 'Minute(s)', 'woocommerce-appointments' ); ?></option>
			<option value="hour" <?php selected( $interval_unit, 'hour' ); ?>><?php esc_html_e( 'Hour(s)', 'woocommerce-appointments' ); ?></option>
		</select>
		<?php echo wc_help_tip( esc_html__( 'How often start times are offered. Without a time-range availability rule, starts step from midnight (e.g. 00:00, 08:00, 16:00). For one daily departure, set interval equal to duration and add a time-range rule for the start time.', 'woocommerce-appointments' ) ); ?>
	</p>
	<?php
	$padding_duration       = absint( $appointable_product->get_padding_duration( 'edit' ) );
	$padding_after_duration = absint( $appointable_product->get_padding_after_duration( 'edit' ) );
	$padding_duration_unit  = $appointable_product->get_padding_duration_unit( 'edit' );
	if ( '' == $padding_duration_unit ) {
		$padding_duration_unit = WC_Appointments_Constants::DURATION_MINUTE;
	}
	?>
	<p class="form-field _wc_appointment_padding_duration_wrap">
		<label for="_wc_appointment_padding_duration"><?php esc_html_e( 'Padding', 'woocommerce-appointments' ); ?></label>
		<span class="wca-padding-fields">
			<span class="wca-padding-float">
				<input type="number" name="_wc_appointment_padding_duration" id="_wc_appointment_padding_duration" value="<?php echo esc_html( $padding_duration ); ?>" step="1" min="0">
				<span class="wca-padding-float__label" aria-hidden="true"><?php esc_html_e( 'Before', 'woocommerce-appointments' ); ?></span>
			</span>
			<span class="wca-padding-float">
				<input type="number" name="_wc_appointment_padding_after_duration" id="_wc_appointment_padding_after_duration" value="<?php echo esc_html( $padding_after_duration ); ?>" step="1" min="0" aria-label="<?php esc_attr_e( 'After', 'woocommerce-appointments' ); ?>">
				<span class="wca-padding-float__label" aria-hidden="true"><?php esc_html_e( 'After', 'woocommerce-appointments' ); ?></span>
			</span>
			<select name="_wc_appointment_padding_duration_unit" id="_wc_appointment_padding_duration_unit" class="short">
				<option value="minute" <?php selected( $padding_duration_unit, 'minute' ); ?>><?php esc_html_e( 'Minute(s)', 'woocommerce-appointments' ); ?></option>
				<option value="hour" <?php selected( $padding_duration_unit, 'hour' ); ?>><?php esc_html_e( 'Hour(s)', 'woocommerce-appointments' ); ?></option>
				<option value="day" <?php selected( $padding_duration_unit, 'day' ); ?>><?php esc_html_e( 'Day(s)', 'woocommerce-appointments' ); ?></option>
				<option value="month" <?php selected( $padding_duration_unit, 'month' ); ?>><?php esc_html_e( 'Month(s)', 'woocommerce-appointments' ); ?></option>
			</select>
			<?php echo wc_help_tip( esc_html__( 'Buffer time reserved before and after each appointment (prep, setup, or cleanup). The gap between two appointments is the earlier appointment\'s after buffer plus the later appointment\'s before buffer.', 'woocommerce-appointments' ) ); ?>
		</span>
	</p>
	<?php
	$min_date      = absint( $appointable_product->get_min_date( 'edit' ) );
	$min_date_unit = $appointable_product->get_min_date_unit( 'edit' );
	if ( '' == $min_date_unit ) {
		$min_date_unit = WC_Appointments_Constants::DURATION_MONTH;
	}
	?>
	<p class="form-field">
		<label for="_wc_appointment_min_date"><?php esc_html_e( 'Lead Time', 'woocommerce-appointments' ); ?></label>
		<input type="number" name="_wc_appointment_min_date" id="_wc_appointment_min_date" value="<?php echo esc_html( $min_date ); ?>" step="1" min="0">
		<select name="_wc_appointment_min_date_unit" id="_wc_appointment_min_date_unit" class="short">
			<option value="hour" <?php selected( $min_date_unit, 'hour' ); ?>><?php esc_html_e( 'Hour(s)', 'woocommerce-appointments' ); ?></option>
			<option value="day" <?php selected( $min_date_unit, 'day' ); ?>><?php esc_html_e( 'Day(s)', 'woocommerce-appointments' ); ?></option>
			<option value="week" <?php selected( $min_date_unit, 'week' ); ?>><?php esc_html_e( 'Week(s)', 'woocommerce-appointments' ); ?></option>
			<option value="month" <?php selected( $min_date_unit, 'month' ); ?>><?php esc_html_e( 'Month(s)', 'woocommerce-appointments' ); ?></option>
		</select> <?php echo wc_help_tip( esc_html__( 'How much in advance do you need before a client schedules an appointment?', 'woocommerce-appointments' ) ); ?>
	</p>
	<?php
	$max_date = $appointable_product->get_max_date( 'edit' );
	if ( '' == $max_date ) {
		$max_date = 12;
	}
	$max_date      = max( absint( $max_date ), 1 );
	$max_date_unit = $appointable_product->get_max_date_unit( 'edit' );
	if ( '' == $max_date_unit ) {
		$max_date_unit = WC_Appointments_Constants::DURATION_MONTH;
	}
	?>
	<p class="form-field">
		<label for="_wc_appointment_max_date"><?php esc_html_e( 'Scheduling Window', 'woocommerce-appointments' ); ?></label>
		<input type="number" name="_wc_appointment_max_date" id="_wc_appointment_max_date" value="<?php echo esc_html( $max_date ); ?>" step="1" min="1">
		<select name="_wc_appointment_max_date_unit" id="_wc_appointment_max_date_unit" class="short">
			<option value="hour" <?php selected( $max_date_unit, 'hour' ); ?>><?php esc_html_e( 'Hour(s)', 'woocommerce-appointments' ); ?></option>
			<option value="day" <?php selected( $max_date_unit, 'day' ); ?>><?php esc_html_e( 'Day(s)', 'woocommerce-appointments' ); ?></option>
			<option value="week" <?php selected( $max_date_unit, 'week' ); ?>><?php esc_html_e( 'Week(s)', 'woocommerce-appointments' ); ?></option>
			<option value="month" <?php selected( $max_date_unit, 'month' ); ?>><?php esc_html_e( 'Month(s)', 'woocommerce-appointments' ); ?></option>
		</select>
		<?php echo wc_help_tip( esc_html__( 'How far in advance are customers allowed to schedule an appointment?', 'woocommerce-appointments' ) ); ?>
	</p>
</div>
<div class="options_group show_if_appointment">
	<?php
	woocommerce_wp_checkbox(
		[
			'id'          => '_wc_appointment_requires_confirmation',
			'label'       => __( 'Requires confirmation?', 'woocommerce-appointments' ),
			'value'       => $appointable_product->get_requires_confirmation( 'edit' ) ? 'yes' : 'no',
			'description' => __( 'Pending until you approve; no payment at checkout.', 'woocommerce-appointments' ),
		],
	);

	woocommerce_wp_checkbox(
	    [
			'id'          => '_wc_appointment_user_can_cancel',
			'label'       => __( 'Can be cancelled?', 'woocommerce-appointments' ),
			'value'       => $appointable_product->get_user_can_cancel( 'edit' ) ? 'yes' : 'no',
			'description' => __( 'Customers cancel from My Account; refunds are manual.', 'woocommerce-appointments' ),
		],
	);

	$cancel_limit      = max( absint( $appointable_product->get_cancel_limit( 'edit' ) ), 1 );
	$cancel_limit_unit = $appointable_product->get_cancel_limit_unit( 'edit' );
	if ( '' == $cancel_limit_unit ) {
		$cancel_limit_unit = 'day';
	}
	?>
	<p class="form-field appointment-cancel-limit">
		<label for="_wc_appointment_cancel_limit"><?php esc_html_e( 'Cancelled at least', 'woocommerce-appointments' ); ?></label>
		<input type="number" name="_wc_appointment_cancel_limit" id="_wc_appointment_cancel_limit" value="<?php echo esc_html( $cancel_limit ); ?>" step="1" min="1">
		<select name="_wc_appointment_cancel_limit_unit" id="_wc_appointment_cancel_limit_unit" class="short">
			<option value="month" <?php selected( $cancel_limit_unit, 'month' ); ?>><?php esc_html_e( 'Month(s)', 'woocommerce-appointments' ); ?></option>
			<option value="day" <?php selected( $cancel_limit_unit, 'day' ); ?>><?php esc_html_e( 'Day(s)', 'woocommerce-appointments' ); ?></option>
			<option value="hour" <?php selected( $cancel_limit_unit, 'hour' ); ?>><?php esc_html_e( 'Hour(s)', 'woocommerce-appointments' ); ?></option>
			<option value="minute" <?php selected( $cancel_limit_unit, 'minute' ); ?>><?php esc_html_e( 'Minute(s)', 'woocommerce-appointments' ); ?></option>
		</select>
		<span class="description"><?php esc_html_e( 'before the start date.', 'woocommerce-appointments' ); ?></span>
	</p>
	<?php
	woocommerce_wp_checkbox(
		[
			'id'          => '_wc_appointment_user_can_reschedule',
			'label'       => __( 'Can be rescheduled?', 'woocommerce-appointments' ),
			'value'       => $appointable_product->get_user_can_reschedule( 'edit' ) ? 'yes' : 'no',
			'description' => __( 'Customers pick a new slot from My Account.', 'woocommerce-appointments' ),
		],
	);

	$reschedule_limit      = max( absint( $appointable_product->get_reschedule_limit( 'edit' ) ), 1 );
	$reschedule_limit_unit = $appointable_product->get_reschedule_limit_unit( 'edit' );
	if ( '' == $reschedule_limit_unit ) {
		$reschedule_limit_unit = 'day';
	}
	?>
	<p class="form-field appointment-reschedule-limit">
		<label for="_wc_appointment_reschedule_limit"><?php esc_html_e( 'Rescheduled at least', 'woocommerce-appointments' ); ?></label>
		<input type="number" name="_wc_appointment_reschedule_limit" id="_wc_appointment_reschedule_limit" value="<?php echo esc_html( $reschedule_limit ); ?>" step="1" min="1">
		<select name="_wc_appointment_reschedule_limit_unit" id="_wc_appointment_reschedule_limit_unit" class="short">
			<option value="month" <?php selected( $reschedule_limit_unit, 'month' ); ?>><?php esc_html_e( 'Month(s)', 'woocommerce-appointments' ); ?></option>
			<option value="day" <?php selected( $reschedule_limit_unit, 'day' ); ?>><?php esc_html_e( 'Day(s)', 'woocommerce-appointments' ); ?></option>
			<option value="hour" <?php selected( $reschedule_limit_unit, 'hour' ); ?>><?php esc_html_e( 'Hour(s)', 'woocommerce-appointments' ); ?></option>
			<option value="minute" <?php selected( $reschedule_limit_unit, 'minute' ); ?>><?php esc_html_e( 'Minute(s)', 'woocommerce-appointments' ); ?></option>
		</select>
		<span class="description"><?php esc_html_e( 'before the start date.', 'woocommerce-appointments' ); ?></span>
	</p>
	<?php
	if ( class_exists( 'WC_Appointment_Series_Events' ) && WC_Appointment_Series_Events::is_enabled() ) {
		/**
		 * Recurring series product options (General tab, after cancel/reschedule settings).
		 *
		 * @param WC_Product $appointable_product Appointable product.
		 */
		do_action( 'woocommerce_appointments_product_recurring_options', $appointable_product );
	}
	?>
	<script type="text/javascript">
		jQuery( '._tax_status_field' ).closest( '.show_if_simple' ).addClass( 'show_if_appointment' );
		jQuery( '#_wc_appointment_duration_unit' ).trigger( 'change' );
	</script>
</div>
<div class="options_group show_if_appointment">
	<?php
	$cal_color_val = $appointable_product->get_cal_color( 'edit' );
	if ( '' === $cal_color_val ) {
		$cal_color_val = WC_Appointments_Admin::get_default_cal_color();
	}
	woocommerce_wp_text_input(
	    [
			'id'          => '_wc_appointment_cal_color',
			'label'       => __( 'Calendar color', 'woocommerce-appointments' ),
			'value'       => $cal_color_val,
			'description' => __( 'Used on the admin calendar.', 'woocommerce-appointments' ),
		],
	);
	?>
</div>
