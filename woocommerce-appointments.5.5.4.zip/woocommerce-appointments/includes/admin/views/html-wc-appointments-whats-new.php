<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$wca_locations_resources_active  = class_exists( 'WC_Appointments_Features' ) && WC_Appointments_Features::is_locations_resources_active();
$wca_locations_resources_allowed = class_exists( 'WC_Appointments_Features' ) && WC_Appointments_Features::is_locations_resources_allowed();
$wca_experimental_settings_url   = admin_url( 'admin.php?page=wc-settings&tab=appointments#wc_appointments_experimental_options' );
$wca_availability_hub_url        = admin_url( 'edit.php?post_type=wc_appointment&page=wc-appointments-availability' );
$wca_locations_url               = $wca_locations_resources_active ? admin_url( 'edit.php?post_type=wca_location' ) : '';
$wca_resources_url               = $wca_locations_resources_active ? admin_url( 'edit.php?post_type=wca_resource' ) : '';
?>
<div class="wca-whats-new-page">
	<style>
		:root {
			--wca-surface-secondary: #f8f9fa;
			--wca-border: #e0e4e7;
			--wca-text-main: #101517;
			--wca-text-muted: #646970;
			--wca-shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
			--wca-shadow-md: 0 4px 12px rgba(0, 0, 0, 0.08);
			--wca-radius-md: 8px;
			--wca-radius-lg: 12px;
			--wca-accent: var(--wp-admin-theme-color, #2271b1);
			--wca-accent-soft: rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08);
			--wca-accent-border: rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35);
			--wca-progress: #d97706;
			--wca-progress-soft: #fff7ed;
		}

		/* Mirror WP #wpcontent left pad; keep mobile admin bar fixed. */
		body.wca-whats-new-screen #wpcontent { padding-right: 20px; }
		@media screen and (max-width: 782px) {
			body.wca-whats-new-screen #wpcontent { padding-right: 10px; }
			body.wca-whats-new-screen #wpadminbar { position: fixed !important; }
		}

		.wca-whats-new-page {
			margin: 0 auto;
			max-width: 100%;
			padding: 8px 12px 40px;
			color: var(--wca-text-main);
			font-size: 16px;
			line-height: 1.55;
			overflow-x: clip;
		}

		.wca-whats-new-page *,
		.wca-whats-new-page *::before,
		.wca-whats-new-page *::after { box-sizing: border-box; }

		.wca-placeholder {
			min-height: 0;
			display: block;
			margin: 0 0 8px;
			border: none;
			border-radius: 0;
			background: transparent;
			overflow: visible;
			position: relative;
			width: 100%;
			box-shadow: none;
		}

		.wca-placeholder svg {
			width: 100%;
			height: auto;
			max-width: 100%;
			display: block;
			border-radius: var(--wca-radius-lg);
		}

		/* Typography */
		.wca-whats-new-page h1 {
			font-size: clamp(1.5rem, 5.5vw, 2rem);
			font-weight: 700;
			margin: 0 0 12px;
			padding: 0;
			line-height: 1.25;
			color: var(--wca-text-main);
			letter-spacing: -0.02em;
			text-wrap: balance;
		}

		.wca-whats-new-page h2 {
			font-size: clamp(1.2rem, 4vw, 1.5rem);
			font-weight: 600;
			margin: 28px 0 14px;
			color: var(--wca-text-main);
			letter-spacing: -0.01em;
			line-height: 1.3;
		}

		.wca-whats-new-page h3 {
			font-size: 18px;
			font-weight: 600;
			margin: 0 0 12px;
			color: var(--wca-text-main);
			line-height: 1.4;
		}

		.wca-whats-new-page p {
			font-size: 16px;
			line-height: 1.6;
			margin-bottom: 24px;
			color: #3c434a;
		}

		.wca-whats-new-page strong {
			font-weight: 600;
			color: var(--wca-text-main);
		}

		.wca-whats-new-page .nav-tab-wrapper {
			display: flex;
			width: 100%;
			border-bottom: 1px solid var(--wca-border);
			padding: 0;
			margin: 0 0 24px;
			gap: 0;
			float: none;
		}

		.wca-whats-new-page .nav-tab {
			flex: 1 1 0;
			min-width: 0;
			justify-content: center;
			text-align: center;
			font-size: 12px;
			font-weight: 500;
			line-height: 1.25;
			padding: 10px 4px;
			margin: 0 0 -1px;
			background: transparent;
			border: none;
			border-bottom: 2px solid transparent;
			border-radius: 0;
			color: var(--wca-text-muted);
			text-decoration: none;
			display: inline-flex;
			align-items: center;
			gap: 6px;
			transition: color 0.2s ease, border-color 0.2s ease;
			white-space: normal;
		}

		.wca-whats-new-page .nav-tab:hover {
			color: var(--wca-text-main);
			background: transparent;
		}

		.wca-whats-new-page .nav-tab:focus {
			box-shadow: none;
			outline: none;
			color: var(--wp-admin-theme-color);
		}

		.wca-whats-new-page .nav-tab-active {
			background: transparent;
			border-bottom-color: var(--wp-admin-theme-color);
			color: var(--wca-text-main);
			font-weight: 600;
		}

		.wca-whats-new-page .nav-tab .wca-new-badge { display: none; }

		.about-section { margin-top: 32px; }
		.wca-improvement-subsection { margin-top: 0; }
		.wca-whats-new-page .is-hidden { display: none; }

		.wca-improvements-nav-shell { margin: 0 0 20px; }

		.wca-improvements-nav-toolbar {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 10px;
			padding: 0 0 10px;
		}

		.wca-improvements-nav-toolbar .button {
			min-height: 32px;
			line-height: 2.1;
			padding: 0 10px;
		}

		.wca-improvements-nav-status {
			font-size: 12px;
			font-weight: 600;
			color: var(--wca-text-muted);
			white-space: nowrap;
		}

		.wca-improvements-nav {
			display: flex;
			flex-wrap: nowrap;
			gap: 10px;
			margin: 0;
			padding: 0;
			overflow-x: auto;
			-webkit-overflow-scrolling: touch;
			scroll-snap-type: x mandatory;
			scrollbar-width: none;
		}

		.wca-improvements-nav::-webkit-scrollbar {
			display: none;
		}

		.wca-improvements-nav-item {
			flex: 0 0 100%;
			scroll-snap-align: start;
			scroll-snap-stop: always;
			padding: 14px 16px;
			background: #fff;
			border: 1px solid var(--wca-border);
			border-radius: var(--wca-radius-md);
			cursor: pointer;
			text-align: left;
			text-decoration: none;
			color: inherit;
			display: flex;
			flex-direction: column;
		}

		.wca-improvements-nav-item.is-active {
			border-color: var(--wp-admin-theme-color);
			box-shadow: 0 0 0 1px var(--wp-admin-theme-color);
		}

		.wca-improvements-nav-item .wca-chip {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			margin-bottom: 10px;
			padding: 4px 10px;
			border-radius: 999px;
			background: var(--wca-surface-secondary);
			font-size: 11px;
			font-weight: 700;
			letter-spacing: 0.04em;
			text-transform: uppercase;
			color: var(--wca-text-muted);
			width: max-content;
			max-width: 100%;
		}

		.wca-improvements-nav-item .wca-chip .dot {
			width: 7px;
			height: 7px;
			border-radius: 50%;
			background: var(--wp-admin-theme-color, #2271b1);
		}

		.wca-improvements-nav-item.is-active .wca-chip {
			background: rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12);
			color: var(--wp-admin-theme-color, #2271b1);
		}

		.wca-improvements-nav-item.is-prior {
			opacity: 0.72;
			background: #fafafa;
			border-style: dashed;
		}

		.wca-improvements-nav-item.is-prior:hover,
		.wca-improvements-nav-item.is-prior.is-active {
			opacity: 1;
			border-style: solid;
		}

		.wca-improvements-nav-item.is-prior .wca-chip {
			background: #f0f0f1;
			color: #8c8f94;
		}

		.wca-improvements-nav-item.is-prior .wca-chip .dot {
			background: #c3c4c7;
		}

		.wca-improvements-nav-item h4 {
			margin: 0 0 4px;
			font-size: 15px;
			font-weight: 600;
			color: var(--wca-text-main);
			line-height: 1.35;
			text-wrap: balance;
		}

		.wca-improvements-nav-item p {
			margin: 0;
			font-size: 13px;
			line-height: 1.4;
			color: var(--wca-text-muted);
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 2;
			overflow: hidden;
		}

		.wca-version-pill {
			display: inline-flex;
			align-items: flex-start;
			gap: 8px;
			padding: 6px 12px;
			border-radius: 20px;
			background: rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.1);
			color: var(--wp-admin-theme-color);
			font-weight: 600;
			font-size: 13px;
			letter-spacing: 0.3px;
			margin-bottom: 12px;
			max-width: 100%;
			line-height: 1.35;
		}

		.wca-version-pill .wca-dot {
			width: 8px;
			height: 8px;
			margin-top: 0.45em;
			flex-shrink: 0;
			border-radius: 50%;
			background: var(--wp-admin-theme-color);
			box-shadow: 0 0 0 2px rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.2);
		}

		.wca-version-pill-copy {
			display: inline-flex;
			flex-wrap: wrap;
			align-items: center;
			gap: 8px;
			min-width: 0;
		}

		.has-2-columns {
			display: flex;
			flex-direction: column;
			gap: 20px;
		}

		/* Text and CTAs before decorative SVGs on small screens. */
		.has-2-columns.is-wider-right > .column:first-child {
			order: 2;
		}

		.has-2-columns.is-wider-right > .column:last-child {
			order: 1;
		}

		/* Components */
		hr {
			border: 0;
			border-top: 1px solid var(--wca-border);
			margin: 28px 0;
		}

		ul.ul-disc {
			list-style-type: disc;
			margin-left: 20px;
			line-height: 1.7;
			color: #3c434a;
			font-size: 15px;
		}

		ul.ul-disc li {
			margin-bottom: 10px;
		}

		ul.ul-disc li::marker {
			color: var(--wca-text-muted);
		}

		code {
			background: #f6f7f7;
			padding: 3px 6px;
			border-radius: 4px;
			font-size: 0.9em;
			font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
			border: 1px solid var(--wca-border);
			color: #2c3338;
		}

		.wca-get-started-strip .wca-cta-links {
			margin-top: 32px;
			margin-bottom: 0;
		}

		.wca-cta-links,
		.wca-hero-cta {
			display: flex;
			flex-direction: column;
			gap: 10px;
			margin: 20px 0 8px;
			align-items: stretch;
		}

		.wca-hero-cta {
			margin: 4px 0 0;
		}

		.wca-cta-links .button-primary,
		.wca-cta-links .button,
		.wca-hero-cta .button {
			padding: 12px 16px;
			font-size: 15px;
			font-weight: 500;
			border-radius: 6px;
			text-align: center;
			height: auto;
			min-height: 44px;
			line-height: 1.35;
			white-space: normal;
			width: 100%;
			box-sizing: border-box;
		}

		.wca-hero-cta .button {
			font-weight: 600;
		}

		.wca-new-badge,
		.wca-beta-badge {
			display: inline-flex;
			align-items: center;
			justify-content: center;
			padding: 2px 7px;
			border-radius: 3px;
			font-weight: 600;
			font-size: 10px;
			letter-spacing: 0.03em;
			line-height: 1.3;
			margin-left: 6px;
			vertical-align: middle;
			text-transform: uppercase;
			white-space: nowrap;
		}

		.wca-new-badge {
			background: #e8f5e9;
			color: #1b5e20;
			border: 1px solid rgba(27, 94, 32, 0.16);
		}

		.wca-new-badge::before {
			content: 'NEW';
		}

		.wca-beta-badge {
			background: var(--wca-progress-soft);
			color: #9a3412;
			border: 1px solid rgba(217, 119, 6, 0.26);
		}

		.wca-beta-badge::before {
			content: 'BETA';
		}

		.wca-experimental-note {
			margin: 16px 0 0;
			padding: 12px 14px;
			border-radius: var(--wca-radius-md);
			border: 1px solid rgba(217, 119, 6, 0.28);
			background: var(--wca-progress-soft);
			font-size: 13px;
			line-height: 1.5;
			color: #9a3412;
		}

		.wca-experimental-note a {
			color: #9a3412;
			font-weight: 600;
		}

		/* Roadmap */
		.wca-roadmap {
			position: relative;
			padding-left: 40px;
			margin-top: 40px;
		}

		.wca-roadmap::before {
			content: '';
			position: absolute;
			left: 11px;
			top: 0;
			bottom: 0;
			width: 2px;
			background: var(--wca-border);
		}

		.wca-roadmap-item {
			position: relative;
			padding: 0 0 40px 0;
		}
		
		.wca-roadmap-item:last-child {
			padding-bottom: 0;
		}

		.wca-roadmap-item::before {
			content: '';
			position: absolute;
			left: -36px;
			top: 4px;
			width: 14px;
			height: 14px;
			border-radius: 50%;
			background: #fff;
			border: 2px solid #c3c4c7;
			z-index: 2;
			transition: all 0.3s ease;
		}

		.wca-roadmap-item.is-complete::before {
			background: var(--wp-admin-theme-color);
			border-color: var(--wp-admin-theme-color);
			box-shadow: 0 0 0 3px #fff;
		}

		.wca-roadmap-item.is-progress::before {
			background: conic-gradient(var(--wca-progress) 0 40%, #fff 40%);
			border-color: var(--wca-progress);
			box-shadow: 0 0 0 3px #fff;
		}

		.wca-roadmap-item.is-next::before {
			border-color: var(--wp-admin-theme-color);
			box-shadow: 0 0 0 3px rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.18);
		}

		.wca-roadmap-item h3 {
			margin: 0 0 8px;
			font-size: 18px;
		}

		.wca-roadmap-header {
			display: flex;
			flex-wrap: wrap;
			align-items: center;
			gap: 10px 14px;
			margin-bottom: 8px;
		}

		.wca-roadmap-header h3 {
			margin: 0;
			flex: 1 1 auto;
			min-width: 0;
		}

		.wca-roadmap-status {
			display: inline-flex;
			align-items: center;
			padding: 4px 10px;
			border-radius: 999px;
			font-size: 11px;
			font-weight: 700;
			letter-spacing: 0.03em;
			text-transform: uppercase;
			background: #f0f0f1;
			color: #646970;
			white-space: nowrap;
		}

		.wca-roadmap-status.is-complete {
			background: rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12);
			color: var(--wp-admin-theme-color, #2271b1);
		}

		.wca-roadmap-status.is-progress {
			background: var(--wca-progress-soft);
			color: #9a3412;
		}

		.wca-roadmap-status.is-next {
			background: rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12);
			color: var(--wp-admin-theme-color, #2271b1);
		}

		.wca-roadmap-progress {
			margin: 16px 0 20px;
			padding: 14px 16px;
			border-radius: var(--wca-radius-md);
			border: 1px solid #fed7aa;
			background: linear-gradient(180deg, #fffbf5 0%, #fff 100%);
		}

		.wca-roadmap-progress-meta {
			display: flex;
			flex-wrap: wrap;
			align-items: baseline;
			justify-content: space-between;
			gap: 8px 16px;
			margin-bottom: 10px;
		}

		.wca-roadmap-progress-meta strong {
			font-size: 13px;
			font-weight: 600;
			color: #9a3412;
		}

		.wca-roadmap-progress-meta span {
			font-size: 12px;
			color: var(--wca-text-muted);
		}

		.wca-roadmap-progress-track {
			height: 8px;
			border-radius: 999px;
			background: #f3e8d8;
			overflow: hidden;
		}

		.wca-roadmap-progress-fill {
			height: 100%;
			width: 40%;
			border-radius: 999px;
			background: linear-gradient(90deg, #f59e0b 0%, #ea580c 100%);
			box-shadow: 0 0 0 1px rgba(234, 88, 12, 0.15);
		}

		.wca-roadmap-checklist {
			display: grid;
			grid-template-columns: 1fr;
			gap: 8px;
			margin: 0 0 16px;
			padding: 0;
			list-style: none;
		}

		.wca-roadmap-checklist li {
			display: grid;
			grid-template-columns: 18px 1fr;
			gap: 10px;
			align-items: start;
			margin: 0;
			font-size: 14px;
			line-height: 1.45;
			color: #3c434a;
		}

		.wca-roadmap-checklist .mark {
			width: 16px;
			height: 16px;
			margin-top: 2px;
			border-radius: 50%;
			display: inline-flex;
			align-items: center;
			justify-content: center;
			font-size: 10px;
			font-weight: 700;
			line-height: 1;
		}

		.wca-roadmap-checklist .is-done .mark {
			background: #dcfce7;
			color: #166534;
		}

		.wca-roadmap-checklist .is-todo .mark {
			background: #f3f4f5;
			color: #8c8f94;
			border: 1px dashed #c3c4c7;
		}

		.wca-roadmap-checklist .is-todo {
			color: var(--wca-text-muted);
		}

		.wca-roadmap::after {
			content: '';
			position: absolute;
			left: 11px;
			top: var(--completed-line-top, 0);
			height: var(--completed-line-height, 0);
			width: 2px;
			background: var(--wp-admin-theme-color);
			z-index: 1;
			pointer-events: none;
		}

		.wca-inline-note {
			background: var(--wca-surface-secondary);
			border: 1px solid var(--wca-border);
			border-radius: var(--wca-radius-md);
			padding: 12px 16px;
			margin: 20px 0 16px;
			font-size: 14px;
			color: var(--wca-text-muted);
		}

		.wca-inline-note p {
			display: inline-flex;
			margin: 0 10px 0 0;
		}

		.wca-inline-note strong {
			color: var(--wca-text-main);
		}

		.wca-major-release-badge {
			display: inline-flex;
			align-items: center;
			padding: 4px 10px;
			margin-left: 0;
			border-radius: 6px;
			background: var(--wp-admin-theme-color, #2271b1);
			color: #fff;
			font-size: 11px;
			font-weight: 700;
			letter-spacing: 0.04em;
			text-transform: uppercase;
			vertical-align: middle;
		}

		.about-text.wca-hero-lead {
			font-size: 16px;
			line-height: 1.55;
			color: #50575e;
			max-width: 52em;
			margin: 0;
		}

		.wca-hero-story {
			margin: 0 0 28px;
		}

		.about-header {
			display: grid;
			grid-template-columns: minmax(0, 1fr);
			grid-template-areas:
				"pill"
				"title"
				"graphic"
				"lead"
				"cta"
				"note";
			gap: 12px 16px;
			align-items: start;
			margin: 0;
		}

		.about-header-title {
			display: contents;
		}

		.about-header .wca-version-pill { grid-area: pill; margin-bottom: 0; }
		.about-header h1 { grid-area: title; margin-bottom: 0; }
		.about-header-graphic {
			grid-area: graphic;
			width: 100%;
			min-width: 0;
			overflow: hidden;
			border-radius: 12px;
		}
		.about-header .wca-hero-lead { grid-area: lead; margin-bottom: 0; }
		.about-header .wca-hero-cta { grid-area: cta; }
		.about-header .wca-hero-note { grid-area: note; }

		.wca-hero-note {
			margin: 0;
			font-size: 13px;
			line-height: 1.45;
			color: var(--wca-text-muted);
			max-width: 40em;
		}

		.wca-hero-note a {
			color: inherit;
			font-weight: 600;
		}

		.about-header-graphic svg.wca-hero-svg {
			width: 100%;
			height: auto;
			max-height: min(78vw, 440px);
			display: block;
			overflow: visible;
			filter: drop-shadow(0 6px 14px rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.1));
			--hero-p: 0;
		}

		/* Mobile: crop SVG to hub board (355×384 at 42,64 in 440×500). */
		@media (max-width: 767px) {
			.wca-hero-story { margin-bottom: 20px; }
			.about-header-graphic {
				position: relative;
				overflow: hidden;
				border-radius: 12px;
				aspect-ratio: 355 / 384;
			}
			.about-header-graphic svg.wca-hero-svg {
				position: absolute;
				width: calc(100% * 440 / 355);
				max-width: none;
				max-height: none;
				left: calc(100% * -42 / 355);
				top: calc(100% * -64 / 384);
				margin: 0;
			}
			.wca-hero-tip { display: none; }
		}

		.wca-hero-scene {
			opacity: clamp(0, calc((var(--hero-p) - var(--in, 0)) / 0.08), 1);
		}

		.wca-hero-tip {
			opacity: min(
				clamp(0, calc((var(--hero-p) - var(--in, 0)) / 0.05), 1),
				clamp(0, calc((var(--out, 1) - var(--hero-p)) / 0.05), 1)
			);
		}

		.wca-hero-scene.is-rule { --in: 0.22; }
		.wca-hero-scene.is-saved { --in: 0.55; }
		.wca-hero-scene.is-beta { --in: 0.8; }
		.wca-hero-fade { opacity: clamp(0, calc((0.26 - var(--hero-p)) / 0.08), 1); }
		.wca-hero-week-fill {
			transform-box: fill-box;
			transform-origin: left center;
			transform: scaleX(clamp(0, calc((var(--hero-p) - 0.45) / 0.2), 1));
		}

		.wca-hero-tip.is-t1 { --in: 0; --out: 0.2; }
		.wca-hero-tip.is-t2 { --in: 0.24; --out: 0.46; }
		.wca-hero-tip.is-t3 { --in: 0.5; --out: 0.72; }
		.wca-hero-tip.is-t4 { --in: 0.76; --out: 1.05; }

		.wca-hero-tip .lead {
			fill: none;
			stroke: #8c8f94;
			stroke-width: 1.2;
			stroke-dasharray: 3.5 3;
		}
		.wca-hero-tip .dot { fill: #8c8f94; }
		.wca-hero-tip .chip { fill: #fff; stroke: #c3c4c7; }

		@media (prefers-reduced-motion: reduce) {
			.about-header-graphic svg.wca-hero-svg { --hero-p: 1; }
			.wca-hero-scene,
			.wca-hero-tip,
			.wca-hero-fade { opacity: 1; }
			.wca-hero-tip:not(.is-last) { opacity: 0; }
			.wca-hero-week-fill { transform: none; }
		}

		.wca-release-highlight-card.is-featured .wca-release-highlight-visual svg {
			box-shadow: 0 0 0 1px var(--wca-accent-border);
		}

		.wca-prior-release-banner {
			display: flex;
			flex-wrap: wrap;
			align-items: flex-start;
			gap: 12px 20px;
			margin: 0 0 28px;
			padding: 14px 16px;
			border-radius: var(--wca-radius-md);
			border: 1px dashed #dcdcde;
			background: #fafafa;
		}

		.wca-prior-release-banner strong {
			display: block;
			font-size: 14px;
			margin-bottom: 4px;
		}

		.wca-prior-release-banner p {
			margin: 0;
			font-size: 14px;
			line-height: 1.5;
			color: var(--wca-text-muted);
		}

		.wca-feature-split {
			display: grid;
			grid-template-columns: minmax(0, 1fr);
			gap: 12px;
			margin: 16px 0 0;
		}

		.wca-feature-split-item {
			padding: 14px 16px;
			border-radius: var(--wca-radius-md);
			border: 1px solid var(--wca-border);
			background: #fff;
		}

		.wca-feature-split-item.is-accent {
			border-color: var(--wca-accent-border);
			background: var(--wca-accent-soft);
		}

		.wca-feature-split-item strong {
			display: block;
			font-size: 13px;
			margin-bottom: 4px;
			color: var(--wca-text-muted);
			font-weight: 600;
			text-transform: uppercase;
			letter-spacing: 0.03em;
		}

		.wca-feature-split-item span {
			font-size: 15px;
			font-weight: 600;
			line-height: 1.4;
			color: var(--wca-text-main);
		}

		.wca-release-highlights {
			margin: 32px 0 0;
		}

		.wca-release-highlights-heading {
			font-size: clamp(1.15rem, 4vw, 1.375rem);
			font-weight: 600;
			line-height: 1.3;
			letter-spacing: -0.01em;
			color: var(--wca-text-main);
			margin: 0 0 18px;
		}

		.wca-release-highlights-grid {
			display: grid;
			grid-template-columns: minmax(0, 1fr);
			gap: 16px;
		}

		.wca-release-highlight-card {
			display: flex;
			flex-direction: column;
			align-items: stretch;
			padding: 14px;
			margin: 0;
			background: #fff;
			border: 1px solid var(--wca-border);
			border-radius: var(--wca-radius-md);
			box-shadow: none;
			text-decoration: none;
			color: inherit;
			transition: border-color 0.15s ease, box-shadow 0.15s ease, transform 0.15s ease;
		}

		a.wca-release-highlight-card:hover,
		a.wca-release-highlight-card:focus {
			border-color: var(--wca-accent-border);
			box-shadow: var(--wca-shadow-sm);
			transform: translateY(-1px);
			outline: none;
		}

		a.wca-release-highlight-card:focus-visible {
			box-shadow: 0 0 0 2px #fff, 0 0 0 4px var(--wca-accent);
		}

		.wca-release-highlight-card.is-featured {
			border-color: var(--wca-accent-border);
			background: linear-gradient(180deg, var(--wca-accent-soft) 0%, #fff 48%);
		}

		.wca-release-highlight-visual {
			height: auto;
			margin-bottom: 12px;
			border-radius: 8px;
			background: transparent;
			display: block;
			padding: 0;
			overflow: visible;
		}

		.wca-release-highlight-visual svg {
			width: 100%;
			max-width: 100%;
			height: auto;
			display: block;
			border-radius: 8px;
		}

		.wca-release-highlight-body {
			min-width: 0;
		}

		.wca-release-highlight-card h3 {
			margin: 0 0 8px;
			font-size: 17px;
			font-weight: 600;
			line-height: 1.3;
			letter-spacing: -0.01em;
			color: var(--wca-text-main);
		}

		.wca-release-highlight-card p {
			margin: 0;
			font-size: 15px;
			line-height: 1.55;
			color: var(--wca-text-muted);
		}

		.wca-release-highlight-more {
			display: inline-block;
			margin-top: 10px;
			font-size: 13px;
			font-weight: 600;
			color: var(--wca-accent);
		}

		.wca-roadmap-more {
			margin: 28px 0 0;
			padding: 16px 18px;
			border: 1px solid var(--wca-border);
			border-radius: var(--wca-radius-md);
			background: #fafafa;
		}

		.wca-roadmap-more > summary {
			cursor: pointer;
			font-size: 15px;
			font-weight: 600;
			color: var(--wca-text-main);
			list-style: none;
		}

		.wca-roadmap-more > summary::-webkit-details-marker {
			display: none;
		}

		.wca-roadmap-more > summary::after {
			content: 'Show';
			float: right;
			font-weight: 500;
			font-size: 13px;
			color: var(--wca-text-muted);
		}

		.wca-roadmap-more[open] > summary::after {
			content: 'Hide';
		}

		.wca-roadmap-more .wca-roadmap {
			margin-top: 20px;
			padding-left: 28px;
		}

		.wca-get-started-strip {
			margin: 36px 0 32px;
			padding: 0;
			background: none;
			border: none;
		}

		.wca-get-started-strip h2 {
			margin: 0 0 10px;
			font-size: clamp(1.15rem, 4vw, 1.375rem);
			font-weight: 600;
			line-height: 1.3;
			letter-spacing: -0.01em;
			color: var(--wca-text-main);
		}

		.wca-get-started-strip > p {
			margin: 0 0 20px;
			font-size: 15px;
			line-height: 1.55;
			color: var(--wca-text-muted);
			max-width: 42em;
		}

		.wca-get-started-steps {
			display: grid;
			grid-template-columns: 1fr;
			gap: 28px;
			margin: 0;
			padding: 0;
			list-style: none;
		}

		.wca-get-started-steps li {
			display: grid;
			grid-template-columns: 36px minmax(0, 1fr);
			gap: 16px;
			align-items: start;
			padding: 0;
			background: none;
			border: none;
		}

		.wca-whats-new-page .wca-get-started-step-num {
			width: 36px;
			height: 36px;
			margin-top: 1px;
			border-radius: 50%;
			border: 2px solid #2271b1;
			background: #ffffff;
			color: #2271b1;
			font-size: 15px;
			font-weight: 700;
			line-height: 1;
			display: inline-flex;
			align-items: center;
			justify-content: center;
			flex-shrink: 0;
		}

		.wca-get-started-step-body {
			min-width: 0;
		}

		.wca-get-started-steps strong {
			display: block;
			font-size: 16px;
			font-weight: 600;
			line-height: 1.35;
			margin-bottom: 6px;
			color: var(--wca-text-main);
		}

		.wca-get-started-steps span {
			display: block;
			font-size: 15px;
			line-height: 1.65;
			color: var(--wca-text-muted);
		}

		@media (min-width: 600px) {
			.wca-release-highlights-grid {
				grid-template-columns: repeat(2, minmax(0, 1fr));
				gap: 20px 28px;
			}
		}

		@media (min-width: 960px) {
			.wca-release-highlights-grid {
				grid-template-columns: repeat(3, minmax(0, 1fr));
				gap: 24px 32px;
			}

			.wca-get-started-steps {
				grid-template-columns: repeat(3, minmax(0, 1fr));
				gap: 32px;
			}
		}

		.wca-use-cases {
			margin-bottom: 32px;
		}

		.wca-use-cases-heading {
			font-size: 20px;
			margin: 0 0 8px;
		}

		.wca-use-cases-intro {
			font-size: 15px;
			line-height: 1.55;
			color: var(--wca-text-muted);
			margin: 0 0 20px;
			max-width: 42em;
		}

		.wca-use-cases-grid {
			display: grid;
			grid-template-columns: 1fr;
			gap: 16px;
		}

		.wca-use-case-card {
			display: flex;
			flex-direction: column;
			background: #fff;
			border: 1px solid var(--wca-border);
			border-radius: var(--wca-radius-lg);
			overflow: hidden;
			box-shadow: var(--wca-shadow-sm);
		}

		.wca-use-case-visual {
			min-height: 0;
			background: transparent;
			border-bottom: none;
			display: block;
			padding: 12px 12px 0;
		}

		.wca-use-case-visual svg {
			width: 100%;
			max-width: 100%;
			height: auto;
			display: block;
		}

		.wca-use-case-body {
			padding: 16px 18px 18px;
		}

		.wca-use-case-body strong {
			display: block;
			font-size: 15px;
			margin-bottom: 6px;
			color: var(--wca-text-main);
		}

		.wca-use-case-body p {
			margin: 0 0 10px;
			font-size: 14px;
			line-height: 1.5;
			color: var(--wca-text-muted);
		}

		.wca-use-case-tag {
			display: inline-block;
			padding: 3px 8px;
			border-radius: 4px;
			font-size: 11px;
			font-weight: 600;
			text-transform: uppercase;
			letter-spacing: 0.03em;
		}

		.wca-use-case-tag.is-prepaid {
			background: #e8f1fb;
			color: var(--wp-admin-theme-color, #2271b1);
		}

		.wca-use-case-tag.is-payfirst {
			background: #fff3cd;
			color: #856404;
		}

		.wca-use-case-tag.is-membership {
			background: #e8f5e9;
			color: #2e7d32;
		}

		@media (min-width: 782px) {
			.wca-use-cases-grid {
				grid-template-columns: repeat(2, 1fr);
			}
		}

		@media (min-width: 1100px) {
			.wca-use-cases-grid {
				grid-template-columns: repeat(4, 1fr);
			}
		}

		.wca-subsection-lead {
			font-size: 15px;
			line-height: 1.55;
			color: #50575e;
			margin: 0 0 16px;
			max-width: 40em;
		}

		.wca-callout-excitement {
			margin: 20px 0 0;
			padding: 14px 18px;
			border-radius: var(--wca-radius-md);
			border-left: 4px solid var(--wp-admin-theme-color);
			background: rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08);
			font-size: 15px;
			line-height: 1.55;
			color: var(--wca-text-main);
		}

		.wca-callout-excitement p {
			margin: 0;
			font-size: inherit;
			color: inherit;
		}

		/* Changelog specific styles */
		.wca-changelog-intro {
			max-width: 640px;
			margin-bottom: 28px;
			color: #50575e;
		}


		.wca-changelog .wca-highlights {
			background: linear-gradient(180deg, #f8fbff 0%, #fff 48%);
			border: 1px solid var(--wca-border);
			border-top: 3px solid var(--wp-admin-theme-color);
			border-radius: var(--wca-radius-lg);
			padding: 20px;
			box-shadow: var(--wca-shadow-md);
		}

		.wca-changelog .wca-chip {
			display: inline-flex;
			align-items: center;
			gap: 8px;
			background: var(--wca-surface-secondary);
			padding: 6px 12px;
			border-radius: 16px;
			font-size: 13px;
			font-weight: 600;
			color: var(--wca-text-main);
			margin-bottom: 16px;
		}

		.wca-changelog .wca-chip .dot {
			width: 8px;
			height: 8px;
			border-radius: 50%;
			background: var(--wp-admin-theme-color);
		}

		.wca-changelog .ul-disc {
			margin: 0;
			padding-left: 20px;
		}

		.wca-changelog .ul-disc li {
			margin-bottom: 8px;
			line-height: 1.6;
			padding-left: 4px;
		}

		.wca-changelog .ul-disc li:last-child {
			margin-bottom: 0;
		}


		/* Full changelog footer - uniform with feedback footer */
		.wca-full-changelog-footer {
			margin-top: 40px;
		}

		.wca-full-changelog-button {
			display: inline-flex;
			align-items: center;
			gap: 8px;
		}

		.wca-button-arrow {
			transition: transform 0.2s ease;
		}

		.wca-full-changelog-button:hover .wca-button-arrow {
			transform: translateX(2px);
		}

		@media (min-width: 768px) {
			.wca-whats-new-page {
				margin: 40px auto;
				max-width: 1040px;
				padding: 0 40px 48px;
			}

			.wca-whats-new-page .nav-tab-wrapper {
				gap: 28px;
				margin-bottom: 40px;
			}

			.wca-whats-new-page .nav-tab {
				flex: 0 0 auto;
				justify-content: flex-start;
				font-size: 15px;
				line-height: 1.5;
				padding: 12px 0;
				white-space: nowrap;
			}

			.wca-whats-new-page .nav-tab .wca-new-badge {
				display: inline-flex;
			}

			.about-header {
				grid-template-columns: minmax(0, 0.72fr) minmax(0, 1.55fr);
				grid-template-areas:
					"pill graphic"
					"title graphic"
					"lead graphic"
					"cta graphic"
					"note graphic";
				gap: 12px 24px;
				margin-bottom: 0;
				align-items: start;
			}

			.about-header-graphic svg.wca-hero-svg {
				max-height: min(72vh, 680px);
			}

			.about-text.wca-hero-lead {
				font-size: 17px;
				line-height: 1.6;
			}

			.wca-cta-links,
			.wca-hero-cta {
				flex-direction: row;
				flex-wrap: wrap;
				align-items: center;
				justify-content: flex-start;
			}

			.wca-cta-links .button,
			.wca-cta-links .button-primary,
			.wca-hero-cta .button {
				width: auto;
				min-width: 0;
				max-width: 100%;
			}

			.wca-placeholder {
				margin-bottom: 0;
			}

			.about-header-graphic {
				overflow: visible;
			}

			.has-2-columns {
				display: grid;
				grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
				gap: 48px;
			}

			.has-2-columns.is-wider-right {
				grid-template-columns: minmax(0, 1fr) minmax(0, 1.4fr);
			}

			.has-2-columns.is-wider-left {
				grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr);
			}

			.has-2-columns.is-wider-right > .column:first-child,
			.has-2-columns.is-wider-right > .column:last-child {
				order: unset;
			}

			.wca-improvements-nav-shell {
				margin: 0 0 32px;
			}

			.wca-improvements-nav-toolbar {
				display: none;
			}

			.wca-improvements-nav {
				display: grid;
				grid-template-columns: repeat(auto-fit, minmax(148px, 1fr));
				gap: 16px;
				overflow: visible;
				scroll-snap-type: none;
			}

			.wca-improvements-nav-item {
				flex: none;
				height: 100%;
				border-radius: var(--wca-radius-lg);
				box-shadow: var(--wca-shadow-sm);
				scroll-snap-align: unset;
			}

			.wca-improvements-nav-item.is-active {
				box-shadow: 0 0 0 1px var(--wp-admin-theme-color), var(--wca-shadow-md);
			}

			.wca-feature-split {
				grid-template-columns: repeat(auto-fit, minmax(148px, 1fr));
			}

			.wca-roadmap-checklist {
				grid-template-columns: repeat(2, minmax(0, 1fr));
			}

			.wca-release-highlights {
				margin-top: 48px;
			}

			.wca-get-started-strip {
				margin: 48px 0 40px;
			}

			.wca-subsection-lead {
				font-size: 17px;
				line-height: 1.6;
			}

			hr {
				margin: 40px 0;
			}
		}
	</style>

	<div class="wca-hero-story" id="wca-hero-story">
		<div class="about-header">
				<div class="about-header-title">
					<div class="wca-version-pill">
						<span class="wca-dot" aria-hidden="true"></span>
						<span class="wca-version-pill-copy">
							<?php printf( esc_html( 'Version %s is here' ), esc_html( WC_APPOINTMENTS_VERSION ) ); ?>
							<span class="wca-major-release-badge"><?php echo esc_html( 'Major release' ); ?></span>
						</span>
					</div>
					<h1><?php echo esc_html( 'Stop juggling open hours across five screens.' ); ?></h1>
					<p class="about-text wca-hero-lead"><?php echo esc_html( 'Edit once in the Availability hub and watch the week update live. Multi-venue booking, shared rooms, and Google Meet are ready when you need them.' ); ?></p>
					<div class="wca-hero-cta">
						<a class="button button-primary" href="<?php echo esc_url( $wca_availability_hub_url ); ?>">
							<?php echo esc_html( 'Open Availability hub' ); ?>
						</a>
						<?php if ( $wca_locations_resources_active && $wca_locations_url ) : ?>
							<a class="button button-secondary" href="<?php echo esc_url( $wca_locations_url ); ?>"><?php echo esc_html( 'Manage locations' ); ?></a>
						<?php elseif ( $wca_locations_resources_allowed ) : ?>
							<a class="button button-secondary" href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Explore Locations & rooms' ); ?></a>
						<?php endif; ?>
					</div>
					<p class="wca-hero-note">
						<?php if ( $wca_locations_resources_active ) : ?>
							<?php echo esc_html( 'Locations & rooms is on for this shop. Past bookings keep their venue even if you turn it off later.' ); ?>
						<?php elseif ( $wca_locations_resources_allowed ) : ?>
							<?php echo esc_html( 'Locations, rooms, and Meet stay off until you opt in under ' ); ?>
							<a href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Settings → Appointments → Experimental' ); ?></a><?php echo esc_html( '.' ); ?>
						<?php else : ?>
							<?php echo esc_html( 'The Availability hub is ready now on every shop.' ); ?>
						<?php endif; ?>
					</p>
				</div>
				<div class="about-header-graphic" aria-hidden="true">
					<svg class="wca-hero-svg" viewBox="0 0 440 500" focusable="false">
						<defs>
							<linearGradient id="wcaHeroGlow" x1="0" y1="0" x2="1" y2="1">
								<stop offset="0%" stop-color="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.14)"/>
								<stop offset="100%" stop-color="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.03)"/>
							</linearGradient>
						</defs>

						<g class="wca-hero-board" transform="translate(42, 64) scale(1.2)">
							<rect width="296" height="320" rx="14" fill="url(#wcaHeroGlow)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.28)"/>

							<rect x="10" y="10" width="88" height="300" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.18)"/>
							<text x="20" y="30" fill="#1d2327" font-size="10" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Availability' ); ?></text>
							<rect x="18" y="40" width="72" height="20" rx="6" fill="#f6f7f7" stroke="#dcdcde"/>
							<text x="54" y="54" text-anchor="middle" fill="#8c8f94" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'Search' ); ?></text>
							<rect x="18" y="72" width="72" height="20" rx="6" fill="var(--wp-admin-theme-color, #2271b1)"/>
							<text x="28" y="86" fill="#fff" font-size="8" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'General' ); ?></text>
							<rect x="18" y="98" width="72" height="20" rx="6" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.07)"/>
							<text x="28" y="112" fill="#1d2327" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Products' ); ?></text>
							<rect x="18" y="124" width="72" height="20" rx="6" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.07)"/>
							<text x="28" y="138" fill="#1d2327" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Staff' ); ?></text>

							<rect x="108" y="10" width="178" height="72" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.2)"/>
							<text x="118" y="26" fill="#646970" font-size="7" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'WEEK AT A GLANCE' ); ?></text>
							<?php foreach ( [ [ 'M', 122 ], [ 'T', 144 ], [ 'W', 166 ], [ 'T', 188 ], [ 'F', 210 ], [ 'S', 232 ], [ 'S', 254 ] ] as $d ) : ?>
								<text x="<?php echo (int) $d[1]; ?>" y="40" text-anchor="middle" fill="#646970" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( $d[0] ); ?></text>
								<rect x="<?php echo (int) ( $d[1] - 9 ); ?>" y="46" width="18" height="26" rx="3" fill="#f0f0f1"/>
							<?php endforeach; ?>
							<?php foreach ( [ 122, 144, 166, 188, 210 ] as $x ) : ?>
								<rect class="wca-hero-week-fill" x="<?php echo (int) ( $x - 6 ); ?>" y="54" width="12" height="6" rx="2" fill="var(--wp-admin-theme-color, #2271b1)"/>
							<?php endforeach; ?>

							<rect x="108" y="92" width="178" height="218" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.2)"/>
							<text x="118" y="112" fill="#1d2327" font-size="10" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open hours' ); ?></text>
							<g class="wca-hero-fade">
								<rect x="118" y="122" width="100" height="18" rx="5" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.1)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)"/>
								<text x="168" y="135" text-anchor="middle" fill="var(--wp-admin-theme-color, #2271b1)" font-size="8" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( '+ Add open hours' ); ?></text>
								<text x="118" y="162" fill="#8c8f94" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'No open hours yet' ); ?></text>
							</g>

							<g class="wca-hero-scene is-rule">
								<rect x="116" y="122" width="162" height="78" rx="8" fill="#fff" stroke="var(--wp-admin-theme-color, #2271b1)"/>
								<rect x="126" y="132" width="40" height="16" rx="8" fill="var(--wp-admin-theme-color, #2271b1)"/>
								<text x="146" y="143" text-anchor="middle" fill="#fff" font-size="7" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open' ); ?></text>
								<rect x="172" y="132" width="46" height="16" rx="8" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.3)"/>
								<text x="195" y="143" text-anchor="middle" fill="var(--wp-admin-theme-color, #2271b1)" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'Closed' ); ?></text>
								<text x="126" y="166" fill="#646970" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'Mon-Fri' ); ?></text>
								<rect x="160" y="154" width="40" height="15" rx="4" fill="#f6f7f7" stroke="#c3c4c7"/>
								<text x="180" y="165" text-anchor="middle" fill="#1d2327" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( '09:00' ); ?></text>
								<rect x="208" y="154" width="40" height="15" rx="4" fill="#f6f7f7" stroke="#c3c4c7"/>
								<text x="228" y="165" text-anchor="middle" fill="#1d2327" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( '17:00' ); ?></text>
								<text x="126" y="190" fill="#646970" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'New rule' ); ?></text>
							</g>

							<g class="wca-hero-scene is-saved">
								<rect x="116" y="210" width="162" height="22" rx="6" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.1)" stroke="var(--wp-admin-theme-color, #2271b1)"/>
								<text x="126" y="225" fill="var(--wp-admin-theme-color, #2271b1)" font-size="7" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open · Mon-Fri · 09:00-17:00' ); ?></text>
							</g>

							<g class="wca-hero-scene is-beta">
								<rect x="18" y="156" width="72" height="20" rx="6" fill="#fff7ed" stroke="rgba(217, 119, 6, 0.35)"/>
								<text x="28" y="170" fill="#9a3412" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Locations' ); ?></text>
								<rect x="18" y="182" width="72" height="20" rx="6" fill="#fff7ed" stroke="rgba(217, 119, 6, 0.28)"/>
								<text x="28" y="196" fill="#9a3412" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Resources' ); ?></text>
							</g>
						</g>

						<g class="wca-hero-tip is-t1">
							<path class="lead" d="M220 52 L220 62 L277 105"/>
							<circle class="dot" cx="277" cy="105" r="2.8"/>
							<rect class="chip" x="138" y="4" width="164" height="44" rx="10"/>
							<text x="220" y="22" text-anchor="middle" fill="#1d2327" font-size="12" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Week at a glance' ); ?></text>
							<text x="220" y="38" text-anchor="middle" fill="#646970" font-size="10" font-family="system-ui,sans-serif"><?php echo esc_html( 'Live open ranges on top' ); ?></text>
						</g>
						<g class="wca-hero-tip is-t2">
							<path class="lead" d="M248 52 L248 64 L248 220"/>
							<circle class="dot" cx="248" cy="220" r="2.8"/>
							<rect class="chip" x="186" y="4" width="124" height="44" rx="10"/>
							<text x="248" y="22" text-anchor="middle" fill="#1d2327" font-size="11" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Add open hours' ); ?></text>
							<text x="248" y="38" text-anchor="middle" fill="#646970" font-size="10" font-family="system-ui,sans-serif"><?php echo esc_html( 'Same page editing' ); ?></text>
						</g>
						<g class="wca-hero-tip is-t3">
							<path class="lead" d="M282 460 L282 448 L282 328"/>
							<circle class="dot" cx="282" cy="328" r="2.8"/>
							<rect class="chip" x="196" y="460" width="172" height="40" rx="10"/>
							<text x="282" y="478" text-anchor="middle" fill="#1d2327" font-size="11" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Rule saved · week updates' ); ?></text>
							<text x="282" y="492" text-anchor="middle" fill="#646970" font-size="10" font-family="system-ui,sans-serif"><?php echo esc_html( 'Mon-Fri 09:00-17:00' ); ?></text>
						</g>
						<g class="wca-hero-tip is-t4 is-last">
							<path class="lead" d="M112 460 L112 400 L112 274"/>
							<circle class="dot" cx="112" cy="274" r="2.8"/>
							<rect class="chip" x="46" y="460" width="132" height="40" rx="10"/>
							<text x="112" y="478" text-anchor="middle" fill="#1d2327" font-size="11" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Locations & rooms' ); ?></text>
							<text x="112" y="492" text-anchor="middle" fill="#646970" font-size="10" font-family="system-ui,sans-serif"><?php echo esc_html( 'Optional beta' ); ?></text>
						</g>
					</svg>
				</div>
		</div>
	</div>

	<section class="wca-release-highlights" aria-labelledby="wca-release-highlights-heading">
		<h2 id="wca-release-highlights-heading" class="wca-release-highlights-heading"><?php echo esc_html( 'Three reasons to open 5.5' ); ?></h2>
		<div class="wca-release-highlights-grid">
			<a class="wca-release-highlight-card is-featured" href="#availability-55">
				<div class="wca-release-highlight-visual" aria-hidden="true">
					<svg viewBox="0 0 260 56" focusable="false">
						<rect width="260" height="56" rx="6" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)" stroke-width="1"/>
						<rect x="12" y="12" width="44" height="16" rx="8" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="34" y="23" text-anchor="middle" fill="#fff" font-size="7" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open' ); ?></text>
						<rect x="62" y="12" width="52" height="16" rx="8" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)"/>
						<text x="88" y="23" text-anchor="middle" fill="var(--wp-admin-theme-color, #2271b1)" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'Closed' ); ?></text>
						<rect x="12" y="36" width="70" height="8" rx="3" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.16)"/>
						<rect x="88" y="36" width="54" height="8" rx="3" fill="#f0f0f1"/>
						<text x="156" y="28" fill="#1d2327" font-size="9" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'One hub' ); ?></text>
						<text x="156" y="42" fill="#646970" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Edit once · week updates' ); ?></text>
					</svg>
				</div>
				<div class="wca-release-highlight-body">
					<h3><?php echo esc_html( 'Availability hub' ); ?> <span class="wca-new-badge"></span></h3>
					<p><?php echo esc_html( 'Open hours and closed rules for General, product, and staff in one place. Save without hopping screens.' ); ?></p>
					<span class="wca-release-highlight-more"><?php echo esc_html( 'See how it works' ); ?></span>
				</div>
			</a>
			<a class="wca-release-highlight-card is-featured" href="#locations-55">
				<div class="wca-release-highlight-visual" aria-hidden="true">
					<svg viewBox="0 0 260 56" focusable="false">
						<rect width="260" height="56" rx="6" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)" stroke-width="1"/>
						<rect x="12" y="12" width="54" height="18" rx="9" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="39" y="24" text-anchor="middle" fill="#fff" font-size="8" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'In person' ); ?></text>
						<rect x="72" y="12" width="48" height="18" rx="9" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)"/>
						<text x="96" y="24" text-anchor="middle" fill="var(--wp-admin-theme-color, #2271b1)" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Online' ); ?></text>
						<circle cx="24" cy="42" r="5" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<path d="M24 39.2 C22.4 39.2 21.2 40.4 21.2 41.8 C21.2 43.5 24 46 24 46 C24 46 26.8 43.5 26.8 41.8 C26.8 40.4 25.6 39.2 24 39.2 Z" fill="#fff"/>
						<text x="34" y="45" fill="#1d2327" font-size="9" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Downtown · Westside · Online' ); ?></text>
					</svg>
				</div>
				<div class="wca-release-highlight-body">
					<h3><?php echo esc_html( 'Locations & rooms' ); ?> <span class="wca-beta-badge"></span></h3>
					<p><?php echo esc_html( 'Branches, home visits, and treatment rooms that block double-bookings across your catalog.' ); ?></p>
					<span class="wca-release-highlight-more"><?php echo esc_html( 'Explore the beta' ); ?></span>
				</div>
			</a>
			<a class="wca-release-highlight-card is-featured" href="#virtual-meetings-55">
				<div class="wca-release-highlight-visual" aria-hidden="true">
					<svg viewBox="0 0 260 56" focusable="false">
						<rect width="260" height="56" rx="6" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="1"/>
						<circle cx="28" cy="28" r="12" fill="#fff" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="1.4"/>
						<path transform="translate(17.8,17.8) scale(0.85)" d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="50" y="24" fill="#1d2327" font-size="10" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Join' ); ?></text>
						<text x="50" y="40" fill="var(--wp-admin-theme-color, #2271b1)" font-size="9" font-family="system-ui,sans-serif"><?php echo esc_html( 'Google Meet · starts in 45m' ); ?></text>
						<rect x="188" y="18" width="60" height="20" rx="5" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="218" y="32" text-anchor="middle" fill="#fff" font-size="8" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Join' ); ?></text>
					</svg>
				</div>
				<div class="wca-release-highlight-body">
					<h3><?php echo esc_html( 'Google Meet join links' ); ?> <span class="wca-beta-badge"></span></h3>
					<p><?php echo esc_html( 'Calendar sync creates the room. Customers get Join with a starts-in countdown on My Account.' ); ?></p>
					<span class="wca-release-highlight-more"><?php echo esc_html( 'See Meet details' ); ?></span>
				</div>
			</a>
		</div>
	</section>

	<div class="wca-get-started-strip">
		<?php if ( $wca_locations_resources_active ) : ?>
			<h2><?php echo esc_html( 'You are ready to go' ); ?></h2>
			<p><?php echo esc_html( 'Locations & rooms is already on. Jump into the hub for hours, or manage venues and rooms next.' ); ?></p>
		<?php else : ?>
			<h2><?php echo esc_html( 'Try it in about two minutes' ); ?></h2>
			<p><?php echo esc_html( 'Start with the hub. Turn on Locations & rooms only if you need multi-venue booking or Meet.' ); ?></p>
		<?php endif; ?>
		<ol class="wca-get-started-steps">
			<li>
				<div class="wca-get-started-step-num">1</div>
				<div class="wca-get-started-step-body">
					<strong><?php echo esc_html( 'Open the Availability hub' ); ?></strong>
					<span><?php echo esc_html( 'Appointments → Availability. Add open hours, watch Week at a glance update.' ); ?></span>
				</div>
			</li>
			<li>
				<div class="wca-get-started-step-num">2</div>
				<div class="wca-get-started-step-body">
					<?php if ( $wca_locations_resources_active ) : ?>
						<strong><?php echo esc_html( 'Add a venue or room' ); ?></strong>
						<span><?php echo esc_html( 'Appointments → Locations or Rooms & resources, then assign them on the product.' ); ?></span>
					<?php else : ?>
						<strong><?php echo esc_html( 'Need venues or Meet?' ); ?></strong>
						<span><?php echo esc_html( 'Enable Locations & rooms under Settings → Appointments → Experimental.' ); ?></span>
					<?php endif; ?>
				</div>
			</li>
			<li>
				<div class="wca-get-started-step-num">3</div>
				<div class="wca-get-started-step-body">
					<strong><?php echo esc_html( 'Book a test appointment' ); ?></strong>
					<span><?php echo esc_html( 'Create one from the calendar. Confirm times, venue, and Join look right for your shop.' ); ?></span>
				</div>
			</li>
		</ol>
		<div class="wca-cta-links">
			<a class="button button-primary" href="<?php echo esc_url( $wca_availability_hub_url ); ?>">
				<?php echo esc_html( 'Open Availability hub' ); ?>
			</a>
			<?php if ( $wca_locations_resources_active && $wca_locations_url && $wca_resources_url ) : ?>
				<a class="button button-secondary" href="<?php echo esc_url( $wca_locations_url ); ?>"><?php echo esc_html( 'Manage locations' ); ?></a>
				<a class="button button-secondary" href="<?php echo esc_url( $wca_resources_url ); ?>"><?php echo esc_html( 'Manage rooms & resources' ); ?></a>
			<?php elseif ( $wca_locations_resources_allowed ) : ?>
				<a class="button button-secondary" href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Enable Locations & rooms (beta)' ); ?></a>
			<?php endif; ?>
		</div>
	</div>

	<nav class="nav-tab-wrapper wp-clearfix" aria-label="<?php echo esc_attr('Secondary menu'); ?>">
		<a href="#improvements" class="nav-tab nav-tab-active"><?php echo esc_html('What\'s New'); ?><span class="wca-new-badge"></span></a>
		<a href="#documentation" class="nav-tab"><?php echo esc_html('Documentation'); ?></a>
		<a href="#future" class="nav-tab"><?php echo esc_html('What\'s Next'); ?></a>
		<a href="#changelog" class="nav-tab"><?php echo esc_html('Changelog'); ?></a>
	</nav>

	<div id="improvements" class="about-section">
		<div class="wca-improvements-nav-shell">
			<div class="wca-improvements-nav-toolbar">
				<button type="button" class="button wca-improvements-nav-btn is-prev"><?php echo esc_html( 'Previous' ); ?></button>
				<span class="wca-improvements-nav-status" aria-live="polite">1 / 5</span>
				<button type="button" class="button wca-improvements-nav-btn is-next"><?php echo esc_html( 'Next' ); ?></button>
			</div>
			<div class="wca-improvements-nav" role="tablist" aria-label="<?php echo esc_attr( 'Improvement categories' ); ?>">
				<a href="#availability-55" class="wca-improvements-nav-item is-active" role="tab" aria-selected="true" data-target="availability-55">
					<div class="wca-chip"><span class="dot" aria-hidden="true"></span><?php echo esc_html( 'Availability' ); ?></div>
					<h4><?php echo esc_html( 'Availability hub' ); ?> <span class="wca-new-badge"></span></h4>
					<p><?php echo esc_html( 'Edit once. Week updates live.' ); ?></p>
				</a>
				<a href="#locations-55" class="wca-improvements-nav-item" role="tab" aria-selected="false" data-target="locations-55">
					<div class="wca-chip"><span class="dot" aria-hidden="true"></span><?php echo esc_html( 'Locations' ); ?></div>
					<h4><?php echo esc_html( 'Multi-location support' ); ?> <span class="wca-beta-badge"></span></h4>
					<p><?php echo esc_html( 'Branches, visits, and online' ); ?></p>
				</a>
				<a href="#resources-55" class="wca-improvements-nav-item" role="tab" aria-selected="false" data-target="resources-55">
					<div class="wca-chip"><span class="dot" aria-hidden="true"></span><?php echo esc_html( 'Resources' ); ?></div>
					<h4><?php echo esc_html( 'Rooms & resources' ); ?> <span class="wca-beta-badge"></span></h4>
					<p><?php echo esc_html( 'End double-booked rooms' ); ?></p>
				</a>
				<a href="#virtual-meetings-55" class="wca-improvements-nav-item" role="tab" aria-selected="false" data-target="virtual-meetings-55">
					<div class="wca-chip"><span class="dot" aria-hidden="true"></span><?php echo esc_html( 'Meetings' ); ?></div>
					<h4><?php echo esc_html( 'Google Meet join links' ); ?> <span class="wca-beta-badge"></span></h4>
					<p><?php echo esc_html( 'Join with a starts-in countdown' ); ?></p>
				</a>
				<a href="#from-54" class="wca-improvements-nav-item is-prior" role="tab" aria-selected="false" data-target="from-54">
					<div class="wca-chip"><span class="dot" aria-hidden="true"></span><?php echo esc_html( '5.4' ); ?></div>
					<h4><?php echo esc_html( 'Series & memberships' ); ?></h4>
					<p><?php echo esc_html( 'Still fully supported' ); ?></p>
				</a>
			</div>
		</div>
		<div class="wca-improvements-content" id="wca-improvements-content">
		</div>
	</div>

	<div id="locations-55" class="about-section wca-improvement-subsection is-hidden">
		<div class="has-2-columns is-wider-right">
			<div class="column">
				<div class="wca-placeholder">
					<svg viewBox="0 0 320 200" role="img" focusable="false" aria-hidden="true">
						<rect x="16" y="16" width="288" height="168" rx="12" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)" stroke-width="1.4"/>
						<rect x="40" y="48" width="72" height="22" rx="11" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="76" y="63" text-anchor="middle" fill="#fff" font-size="8" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'In person' ); ?></text>
						<rect x="120" y="48" width="56" height="22" rx="11" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.06)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)"/>
						<text x="148" y="63" text-anchor="middle" fill="var(--wp-admin-theme-color, #2271b1)" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Online' ); ?></text>
						<circle cx="56" cy="110" r="10" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)" stroke="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="76" y="114" fill="#1d2327" font-size="10" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Locations' ); ?></text>
					</svg>
				</div>
			</div>
			<div class="column">
				<h2><?php echo esc_html( 'Multi-location support' ); ?> <span class="wca-beta-badge"></span></h2>
				<p class="wca-subsection-lead"><?php echo esc_html( 'One catalog for downtown, westside, home visits, and video consults. Customers pick a branch (or you fix it), and the venue sticks on cart, emails, and calendar files.' ); ?></p>
				<p class="wca-experimental-note">
					<?php if ( $wca_locations_resources_active ) : ?>
						<?php echo esc_html( 'Locations & rooms is on for this shop. You can turn it off anytime under Settings → Appointments → Experimental. Past appointments still show their venue.' ); ?>
					<?php elseif ( $wca_locations_resources_allowed ) : ?>
						<?php echo esc_html( 'Off by default. Enable Locations & rooms (beta) under ' ); ?>
						<a href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Settings → Appointments → Experimental' ); ?></a>
						<?php echo esc_html( ' to show menus, product tabs, and hub layers.' ); ?>
					<?php else : ?>
						<?php echo esc_html( 'Locations & rooms is not available on this shop (disabled by configuration).' ); ?>
					<?php endif; ?>
				</p>
				<ul class="ul-disc">
					<li><strong><?php echo esc_html( 'In person or Online:' ); ?></strong> <?php echo esc_html( 'Chip toggles on the edit screen. Online can carry a static Join URL and instructions even before Meet generates a link.' ); ?></li>
					<li><strong><?php echo esc_html( 'Product modes:' ); ?></strong> <?php echo esc_html( 'None; Fixed, show name (one venue in cart and emails); Fixed (one venue, hidden from customers); or Customer selected (all venues A-Z, or two or more you list and order).' ); ?></li>
					<li><strong><?php echo esc_html( 'Additional cost:' ); ?></strong> <?php echo esc_html( 'Optional signed cost per assigned location on the product Location tab (negative = discount; appointment total still floors at zero).' ); ?></li>
					<li><strong><?php echo esc_html( 'Snapshots:' ); ?></strong> <?php echo esc_html( 'Cart, emails, order details, calendar files, and Google Calendar keep the venue the customer booked, even if you rename it later.' ); ?></li>
					<li><strong><?php echo esc_html( 'Staff permissions:' ); ?></strong> <?php echo esc_html( 'Manage Locations is off by default and included in the Full staff preset.' ); ?></li>
				</ul>
				<div class="wca-feature-split">
					<div class="wca-feature-split-item is-accent">
						<strong><?php echo esc_html( 'Fixed, show name' ); ?></strong>
						<span><?php echo esc_html( 'One venue in cart and emails' ); ?></span>
					</div>
					<div class="wca-feature-split-item is-accent">
						<strong><?php echo esc_html( 'Fixed' ); ?></strong>
						<span><?php echo esc_html( 'One venue, hidden from customers' ); ?></span>
					</div>
					<div class="wca-feature-split-item is-accent">
						<strong><?php echo esc_html( 'Customer selected' ); ?></strong>
						<span><?php echo esc_html( 'Customer picks before times' ); ?></span>
					</div>
				</div>
				<div class="wca-cta-links">
					<?php if ( $wca_locations_resources_active && $wca_locations_url ) : ?>
						<a class="button button-primary" href="<?php echo esc_url( $wca_locations_url ); ?>"><?php echo esc_html( 'Open Locations' ); ?></a>
						<a class="button button-secondary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wca_location' ) ); ?>"><?php echo esc_html( 'Add a location' ); ?></a>
					<?php elseif ( $wca_locations_resources_allowed ) : ?>
						<a class="button button-primary" href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Enable Locations & rooms (beta)' ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<hr />

		<div class="wca-use-cases">
			<h3 class="wca-use-cases-heading"><?php echo esc_html( 'Popular setups' ); ?></h3>
			<p class="wca-use-cases-intro"><?php echo esc_html( 'Real setups shops run after turning the beta on.' ); ?></p>
			<div class="wca-use-cases-grid">
				<article class="wca-use-case-card">
					<div class="wca-use-case-visual" aria-hidden="true">
						<svg viewBox="0 0 300 148" focusable="false">
							<rect x="8" y="8" width="284" height="132" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.28)" stroke-width="1.2"/>
							<rect x="24" y="32" width="120" height="20" rx="10" fill="var(--wp-admin-theme-color, #2271b1)"/>
							<text x="84" y="46" text-anchor="middle" fill="#fff" font-size="8" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Choose a location' ); ?></text>
							<rect x="24" y="64" width="200" height="12" rx="4" fill="#f0f0f1"/>
							<rect x="24" y="84" width="160" height="12" rx="4" fill="#f0f0f1"/>
						</svg>
					</div>
					<div class="wca-use-case-body">
						<strong><?php echo esc_html( 'Multi-branch clinic' ); ?></strong>
						<p><?php echo esc_html( 'Same treatment product: customer chooses a branch first, then staff and time. Staff stay busy across venues for that product.' ); ?></p>
						<span class="wca-use-case-tag is-prepaid"><?php echo esc_html( 'Customer selected' ); ?></span>
					</div>
				</article>
				<article class="wca-use-case-card">
					<div class="wca-use-case-visual" aria-hidden="true">
						<svg viewBox="0 0 300 148" focusable="false">
							<rect x="8" y="8" width="136" height="132" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.28)" stroke-width="1.2"/>
							<text x="20" y="48" fill="#1d2327" font-size="9" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'In person' ); ?></text>
							<rect x="156" y="8" width="136" height="132" rx="10" fill="#fff" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="1.4"/>
							<circle cx="224" cy="64" r="16" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)"/>
							<text x="224" y="104" text-anchor="middle" fill="#1d2327" font-size="9" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Online' ); ?></text>
						</svg>
					</div>
					<div class="wca-use-case-body">
						<strong><?php echo esc_html( 'Studio + video consult' ); ?></strong>
						<p><?php echo esc_html( 'List an In person location and an Online location. Meet creates the join link only for the online choice.' ); ?></p>
						<span class="wca-use-case-tag is-membership"><?php echo esc_html( 'Hybrid' ); ?></span>
					</div>
				</article>
				<article class="wca-use-case-card">
					<div class="wca-use-case-visual" aria-hidden="true">
						<svg viewBox="0 0 300 148" focusable="false">
							<rect x="8" y="8" width="284" height="132" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.28)" stroke-width="1.2"/>
							<rect x="24" y="32" width="64" height="20" rx="6" fill="var(--wp-admin-theme-color, #2271b1)"/>
							<text x="56" y="46" text-anchor="middle" fill="#fff" font-size="8" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Fixed' ); ?></text>
							<rect x="24" y="64" width="200" height="12" rx="4" fill="#f0f0f1"/>
							<rect x="24" y="84" width="160" height="12" rx="4" fill="#f0f0f1"/>
						</svg>
					</div>
					<div class="wca-use-case-body">
						<strong><?php echo esc_html( 'Single mobile service' ); ?></strong>
						<p><?php echo esc_html( 'Use Fixed, show name for one Service area so emails show the territory, or Fixed to keep the venue internal only.' ); ?></p>
						<span class="wca-use-case-tag is-payfirst"><?php echo esc_html( 'Fixed' ); ?></span>
					</div>
				</article>
				<article class="wca-use-case-card">
					<div class="wca-use-case-visual" aria-hidden="true">
						<svg viewBox="0 0 300 148" focusable="false">
							<rect x="8" y="8" width="120" height="132" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.28)" stroke-width="1.2"/>
							<text x="20" y="48" fill="#1d2327" font-size="9" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Room A' ); ?></text>
							<path d="M136 74 L152 74" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="2" stroke-linecap="round"/>
							<rect x="164" y="8" width="128" height="132" rx="10" fill="#fff" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="1.4"/>
							<text x="176" y="48" fill="#1d2327" font-size="9" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Massage' ); ?></text>
							<text x="176" y="68" fill="#646970" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( '+ Facial' ); ?></text>
						</svg>
					</div>
					<div class="wca-use-case-body">
						<strong><?php echo esc_html( 'One room, many services' ); ?></strong>
						<p><?php echo esc_html( 'Require the same treatment room on several products. When Room A is booked, every product that needs it stays unavailable.' ); ?></p>
						<span class="wca-use-case-tag is-prepaid"><?php echo esc_html( 'Shared resource' ); ?></span>
					</div>
				</article>
			</div>
		</div>
	</div>

	<div id="resources-55" class="about-section wca-improvement-subsection is-hidden">
		<div class="has-2-columns is-wider-right">
			<div class="column">
				<div class="wca-placeholder">
					<svg viewBox="0 0 320 200" role="img" focusable="false" aria-hidden="true">
						<rect x="16" y="16" width="288" height="168" rx="12" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)" stroke-width="1.4"/>
						<rect x="40" y="48" width="100" height="72" rx="10" fill="#fff" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="1.4"/>
						<text x="90" y="80" text-anchor="middle" fill="var(--wp-admin-theme-color, #2271b1)" font-size="12" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Room A' ); ?></text>
						<text x="90" y="98" text-anchor="middle" fill="#646970" font-size="8" font-family="system-ui,sans-serif"><?php echo esc_html( 'Capacity 1 · Downtown' ); ?></text>
						<rect x="160" y="56" width="120" height="24" rx="6" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)"/>
						<text x="220" y="72" text-anchor="middle" fill="#1d2327" font-size="9" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Massage' ); ?></text>
						<rect x="160" y="92" width="120" height="24" rx="6" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)"/>
						<text x="220" y="108" text-anchor="middle" fill="#1d2327" font-size="9" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Facial' ); ?></text>
						<text x="160" y="148" fill="var(--wp-admin-theme-color, #2271b1)" font-size="9" font-family="system-ui,sans-serif"><?php echo esc_html( 'One booking blocks both' ); ?></text>
					</svg>
				</div>
			</div>
			<div class="column">
				<h2><?php echo esc_html( 'Rooms & resources' ); ?> <span class="wca-beta-badge"></span></h2>
				<p class="wca-subsection-lead"><?php echo esc_html( 'Room A booked for a massage should not stay open for a facial. Shared rooms and equipment limit availability across every product that needs them.' ); ?></p>
				<p class="wca-experimental-note">
					<?php if ( $wca_locations_resources_active ) : ?>
						<?php echo esc_html( 'Rooms share the Locations & rooms experimental switch (already on here). Capacity lives on each product\'s Resources tab.' ); ?>
					<?php elseif ( $wca_locations_resources_allowed ) : ?>
						<?php echo esc_html( 'Included in the same Locations & rooms (beta) setting. Enable it under ' ); ?>
						<a href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Settings → Appointments → Experimental' ); ?></a>
						<?php echo esc_html( ' before adding rooms.' ); ?>
					<?php else : ?>
						<?php echo esc_html( 'Rooms & resources is not available on this shop (disabled by configuration).' ); ?>
					<?php endif; ?>
				</p>
				<ul class="ul-disc">
					<li><strong><?php echo esc_html( 'Capacity:' ); ?></strong> <?php echo esc_html( 'Set concurrent bookings per product on the Resources tab. Use the same number on every product that shares the room. 1 means exclusive use for the booking window.' ); ?></li>
					<li><strong><?php echo esc_html( 'Additional cost:' ); ?></strong> <?php echo esc_html( 'Optional signed cost per resource on the product Resources tab, added like staff cost (appointment total still floors at zero).' ); ?></li>
					<li><strong><?php echo esc_html( 'OR pool:' ); ?></strong> <?php echo esc_html( 'Checked resources on a product are alternatives. Automatic picks a free room; Customer selects lets them choose.' ); ?></li>
					<li><strong><?php echo esc_html( 'Venue-scoped:' ); ?></strong> <?php echo esc_html( 'Rooms belong to a location when you run multiple venues, so Downtown never grabs Westside\'s suite.' ); ?></li>
					<li><strong><?php echo esc_html( 'Everywhere it matters:' ); ?></strong> <?php echo esc_html( 'Allocated rooms show on the calendar, list, emails, ICS, Google Calendar, and My Account when Selection is Automatic show name or Customer selects (admins always see them).' ); ?></li>
				</ul>
				<div class="wca-cta-links">
					<?php if ( $wca_locations_resources_active && $wca_resources_url ) : ?>
						<a class="button button-primary" href="<?php echo esc_url( $wca_resources_url ); ?>"><?php echo esc_html( 'Open Rooms & resources' ); ?></a>
						<a class="button button-secondary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wca_resource' ) ); ?>"><?php echo esc_html( 'Add a room or resource' ); ?></a>
					<?php elseif ( $wca_locations_resources_allowed ) : ?>
						<a class="button button-primary" href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Enable Locations & rooms (beta)' ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>

	<div id="availability-55" class="about-section wca-improvement-subsection">
		<div class="has-2-columns is-wider-right">
			<div class="column">
				<div class="wca-placeholder">
					<svg viewBox="0 0 320 200" role="img" focusable="false" aria-hidden="true">
						<rect x="12" y="12" width="296" height="176" rx="12" fill="#f6f7f7" stroke="#d8dadd"/>
						<rect x="20" y="20" width="72" height="160" rx="8" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.2)"/>
						<text x="28" y="38" fill="#1d2327" font-size="8" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Availability' ); ?></text>
						<rect x="28" y="48" width="56" height="14" rx="4" fill="#f0f0f1" stroke="#dcdcde"/>
						<text x="56" y="58" text-anchor="middle" fill="#8c8f94" font-size="6" font-family="system-ui,sans-serif"><?php echo esc_html( 'Search' ); ?></text>
						<rect x="28" y="70" width="56" height="16" rx="4" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="36" y="81" fill="#fff" font-size="7" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'General' ); ?></text>
						<rect x="28" y="92" width="56" height="16" rx="4" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08)"/>
						<text x="36" y="103" fill="#1d2327" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'Products' ); ?></text>
						<rect x="28" y="114" width="56" height="16" rx="4" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08)"/>
						<text x="36" y="125" fill="#1d2327" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'Staff' ); ?></text>
						<rect x="100" y="20" width="196" height="48" rx="8" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.2)"/>
						<text x="110" y="34" fill="#646970" font-size="6" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'WEEK AT A GLANCE' ); ?></text>
						<?php foreach ( [ 118, 142, 166, 190, 214, 238, 262 ] as $i => $wx ) : ?>
							<rect x="<?php echo (int) ( $wx - 8 ); ?>" y="42" width="16" height="18" rx="2" fill="#f0f0f1"/>
							<?php if ( $i < 5 ) : ?>
								<rect x="<?php echo (int) ( $wx - 5 ); ?>" y="48" width="10" height="5" rx="1.5" fill="var(--wp-admin-theme-color, #2271b1)"/>
							<?php endif; ?>
						<?php endforeach; ?>
						<rect x="100" y="76" width="196" height="104" rx="8" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.2)"/>
						<text x="110" y="94" fill="#1d2327" font-size="8" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open hours' ); ?></text>
						<rect x="110" y="104" width="40" height="14" rx="7" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="130" y="114" text-anchor="middle" fill="#fff" font-size="6" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open' ); ?></text>
						<rect x="156" y="104" width="44" height="14" rx="7" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)"/>
						<text x="178" y="114" text-anchor="middle" fill="var(--wp-admin-theme-color, #2271b1)" font-size="6" font-family="system-ui,sans-serif"><?php echo esc_html( 'Closed' ); ?></text>
						<rect x="110" y="128" width="176" height="18" rx="5" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.1)" stroke="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="118" y="140" fill="var(--wp-admin-theme-color, #2271b1)" font-size="6" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open · Mon-Fri · 09:00-17:00' ); ?></text>
						<rect x="110" y="154" width="140" height="12" rx="3" fill="#f0f0f1"/>
					</svg>
				</div>
			</div>
			<div class="column">
				<h2><?php echo esc_html( 'Availability hub' ); ?> <span class="wca-new-badge"></span></h2>
				<p class="wca-subsection-lead"><?php echo esc_html( 'Before: open hours lived in settings, products, and staff screens. Now: Appointments → Availability is one hub. Switch layers instantly, edit Open hours or Unavailable, and see Week at a glance update while you work. No experimental switch required.' ); ?></p>
				<ul class="ul-disc">
					<li><?php echo esc_html( 'General, product, and staff layers in one shell for every shop.' ); ?></li>
					<li><?php echo esc_html( 'Location and resource layers appear only when Locations & rooms (beta) is on (including Range of days open/closed for venue and room schedules).' ); ?></li>
					<li><?php echo esc_html( 'Week at a glance on the hub and product Availability tab; deep links open the matching entity.' ); ?></li>
					<li><?php echo esc_html( 'Availability Check, Auto-select, and Restrict start days stay on the product Availability tab beside a hub link.' ); ?></li>
					<li><?php echo esc_html( 'Capacity is the shared label for product inventory, staff, resources, and availability overrides (Minimum and Maximum stay visible for per-booking quantity).' ); ?></li>
				</ul>
				<div class="wca-cta-links">
					<a class="button button-primary" href="<?php echo esc_url( $wca_availability_hub_url ); ?>">
						<?php echo esc_html( 'Open Availability hub' ); ?>
					</a>
				</div>
			</div>
		</div>
	</div>

	<div id="virtual-meetings-55" class="about-section wca-improvement-subsection is-hidden">
		<div class="has-2-columns is-wider-right">
			<div class="column">
				<div class="wca-placeholder">
					<svg viewBox="0 0 320 200" role="img" focusable="false" aria-hidden="true">
						<rect x="16" y="16" width="288" height="168" rx="12" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.35)" stroke-width="1.4"/>
						<circle cx="120" cy="96" r="24" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)"/>
						<path transform="translate(104,80) scale(1.2)" d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<rect x="180" y="80" width="88" height="28" rx="6" fill="var(--wp-admin-theme-color, #2271b1)"/>
						<text x="224" y="98" text-anchor="middle" fill="#fff" font-size="10" font-weight="600" font-family="system-ui,sans-serif"><?php echo esc_html( 'Join' ); ?></text>
					</svg>
				</div>
			</div>
			<div class="column">
				<h2><?php echo esc_html( 'Google Meet join links' ); ?> <span class="wca-beta-badge"></span></h2>
				<p class="wca-subsection-lead"><?php echo esc_html( 'Customers stop hunting for the Zoom link in email threads. Meet creates a join URL per booking via your Google Calendar connection, with Join and a starts-in countdown on My Account.' ); ?></p>
				<?php if ( ! $wca_locations_resources_active && $wca_locations_resources_allowed ) : ?>
					<p class="wca-experimental-note">
						<?php echo esc_html( 'Enable Locations & rooms under ' ); ?>
						<a href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Settings → Appointments → Experimental' ); ?></a>
						<?php echo esc_html( ', add an Online location, then set Video meeting → Google Meet on the product Location tab.' ); ?>
					</p>
				<?php endif; ?>
				<ul class="ul-disc">
					<li><strong><?php echo esc_html( 'Product setting:' ); ?></strong> <?php echo esc_html( 'Video meeting → Google Meet on the product Location tab (shown when an assigned location is Online).' ); ?></li>
					<li><strong><?php echo esc_html( 'Automatic links:' ); ?></strong> <?php echo esc_html( 'When Google Calendar syncs the appointment, it creates the Meet room and saves the join link on the booking. The provider is snapshotted at booking time.' ); ?></li>
					<li><strong><?php echo esc_html( 'Customer UX:' ); ?></strong> <?php echo esc_html( 'My Account, emails, and order summaries share the same Join link (Meet, else the location static Join URL), with a starts-in countdown on My Account.' ); ?></li>
					<li><strong><?php echo esc_html( 'Cancel cleanup:' ); ?></strong> <?php echo esc_html( 'Cancelling the appointment clears the Meet link on the booking (Google Calendar updates as usual).' ); ?></li>
				</ul>
				<div class="wca-callout-excitement">
					<p><?php echo esc_html( 'Static online Join URLs still work as a fallback when Meet is not enabled, or while the generated link is pending. Zoom, Teams, and a Connections hub are next on the roadmap.' ); ?></p>
				</div>
				<?php if ( ! $wca_locations_resources_active && $wca_locations_resources_allowed ) : ?>
					<div class="wca-cta-links">
						<a class="button button-primary" href="<?php echo esc_url( $wca_experimental_settings_url ); ?>"><?php echo esc_html( 'Enable Locations & rooms (beta)' ); ?></a>
					</div>
				<?php elseif ( $wca_locations_resources_active && $wca_locations_url ) : ?>
					<div class="wca-cta-links">
						<a class="button button-primary" href="<?php echo esc_url( $wca_locations_url ); ?>"><?php echo esc_html( 'Open Locations' ); ?></a>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<div id="from-54" class="about-section wca-improvement-subsection is-hidden">
		<div class="wca-prior-release-banner">
			<div>
				<strong><?php echo esc_html( 'Shipped in 5.4' ); ?></strong>
				<p><?php echo esc_html( 'Recurring packages, pay-first balance orders, and Subscriptions membership credits. Still fully supported; this tab is a short recap so 5.5 can stay in focus.' ); ?></p>
			</div>
		</div>
		<ul class="ul-disc">
			<li><?php echo esc_html( 'Prepaid or pay-first series packages with balance orders.' ); ?></li>
			<li><?php echo esc_html( 'WooCommerce Subscriptions membership credits on the booking form.' ); ?></li>
			<li><?php echo esc_html( 'Apply to scope for cancel and reschedule in admin; My Account reschedule offers this appointment or this and following.' ); ?></li>
		</ul>
	</div>

	<div id="documentation" class="about-section is-hidden">
		<div class="has-2-columns is-wider-right">
			<div class="column">
				<div class="wca-placeholder">
					<svg viewBox="0 0 320 200" role="img"
						aria-label="<?php echo esc_attr( 'docs.bookingwp.com: merchant guides for setup and day-to-day work, plus developer REST API and hooks' ); ?>"
						focusable="false">
						<!-- Browser shell -->
						<rect x="8" y="10" width="304" height="180" rx="10" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.28)" stroke-width="1.4"/>
						<rect x="8" y="10" width="304" height="26" rx="10" fill="#f6f7f7"/>
						<rect x="8" y="28" width="304" height="8" fill="#f6f7f7"/>
						<circle cx="22" cy="23" r="3.5" fill="#dcdcde"/>
						<circle cx="34" cy="23" r="3.5" fill="#dcdcde"/>
						<circle cx="46" cy="23" r="3.5" fill="#dcdcde"/>
						<rect x="64" y="17" width="196" height="12" rx="6" fill="#fff" stroke="#dcdcde"/>
						<text x="162" y="26" text-anchor="middle" fill="#8c8f94" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'docs.bookingwp.com' ); ?></text>

						<!-- Sidebar: how the docs are organized -->
						<rect x="8" y="36" width="102" height="154" fill="#f8f9fa"/>
						<line x1="110" y1="36" x2="110" y2="190" stroke="#e0e4e7"/>
						<text x="16" y="50" fill="#8c8f94" font-size="6" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'FOR YOUR SHOP' ); ?></text>

						<text x="16" y="66" fill="#1d2327" font-size="8" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Setup' ); ?></text>
						<text x="20" y="78" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Install & settings' ); ?></text>
						<text x="20" y="88" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Create a product' ); ?></text>
						<text x="20" y="98" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Open hours & rules' ); ?></text>

						<text x="16" y="116" fill="#1d2327" font-size="8" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Day to day' ); ?></text>
						<text x="20" y="128" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Calendar & panel' ); ?></text>
						<text x="20" y="138" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Staff & permissions' ); ?></text>

						<text x="16" y="156" fill="#8c8f94" font-size="6" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'FOR BUILDERS' ); ?></text>
						<rect x="14" y="162" width="88" height="22" rx="4" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.12)"/>
						<text x="20" y="172" fill="var(--wp-admin-theme-color, #2271b1)" font-size="7.5" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Developers' ); ?></text>
						<text x="20" y="181" fill="#646970" font-size="6" font-family="system-ui,sans-serif"><?php echo esc_html( 'REST API, hooks, PHP' ); ?></text>

						<!-- Main: search + topic cards (what people come for) -->
						<rect x="120" y="46" width="180" height="18" rx="9" fill="#fff" stroke="#dcdcde"/>
						<text x="132" y="58" fill="#8c8f94" font-size="7" font-family="system-ui,sans-serif"><?php echo esc_html( 'Search guides…' ); ?></text>

						<text x="120" y="80" fill="#1d2327" font-size="10" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'How can we help?' ); ?></text>

						<rect x="120" y="90" width="86" height="42" rx="6" fill="#fff" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.3)"/>
						<text x="128" y="106" fill="var(--wp-admin-theme-color, #2271b1)" font-size="7.5" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Go live' ); ?></text>
						<text x="128" y="118" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Install, product,' ); ?></text>
						<text x="128" y="127" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'first booking' ); ?></text>

						<rect x="214" y="90" width="86" height="42" rx="6" fill="#fff" stroke="#dcdcde"/>
						<text x="222" y="106" fill="#1d2327" font-size="7.5" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Run the shop' ); ?></text>
						<text x="222" y="118" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Calendar, staff,' ); ?></text>
						<text x="222" y="127" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'emails, export' ); ?></text>

						<rect x="120" y="140" width="86" height="42" rx="6" fill="#fff" stroke="#dcdcde"/>
						<text x="128" y="156" fill="#1d2327" font-size="7.5" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Add features' ); ?></text>
						<text x="128" y="168" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'Google Calendar,' ); ?></text>
						<text x="128" y="177" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'recurring, Meet' ); ?></text>

						<rect x="214" y="140" width="86" height="42" rx="6" fill="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.08)" stroke="rgba(var(--wp-admin-theme-color-rgb, 34, 113, 177), 0.28)"/>
						<text x="222" y="156" fill="var(--wp-admin-theme-color, #2271b1)" font-size="7.5" font-weight="700" font-family="system-ui,sans-serif"><?php echo esc_html( 'Build on it' ); ?></text>
						<text x="222" y="168" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'REST, hooks,' ); ?></text>
						<text x="222" y="177" fill="#646970" font-size="6.5" font-family="system-ui,sans-serif"><?php echo esc_html( 'custom code' ); ?></text>
					</svg>
				</div>
			</div>
			<div class="column">
				<h2><?php echo esc_html( 'Documentation hub' ); ?></h2>
				<p><?php echo esc_html( 'docs.bookingwp.com is built around jobs, not release notes: go live, run the shop day to day, add features, or build with the REST API and hooks.' ); ?></p>
				<p><?php echo esc_html( 'Merchant guides under Setup and Management; developer reference under Developers. Search works across both.' ); ?></p>
				<div class="wca-cta-links">
					<a class="button button-primary" href="https://docs.bookingwp.com" target="_blank"
						rel="noopener noreferrer">
						<?php echo esc_html( 'Visit documentation' ); ?>
					</a>
					<a class="button button-secondary" href="https://docs.bookingwp.com/appointments/developers" target="_blank"
						rel="noopener noreferrer">
						<?php echo esc_html( 'Developer docs' ); ?>
					</a>
				</div>
			</div>
		</div>
	</div>

	<div id="future" class="about-section is-hidden">
		<h2><?php echo esc_html('What\'s next'); ?></h2>
		<p style="max-width: 640px; margin-bottom: 32px;">
			<?php echo esc_html('5.5 shipped the Availability hub and optional locations, rooms, and Meet. Here is what we are building next (timing may shift with feedback).'); ?>
		</p>

		<div class="wca-roadmap">
			<div class="wca-roadmap-item is-complete">
				<div class="wca-roadmap-header">
					<h3><?php echo esc_html('5.5: Hub, locations & rooms'); ?></h3>
					<span class="wca-roadmap-status is-complete"><?php echo esc_html('Shipped'); ?></span>
				</div>
				<p><?php echo esc_html('Availability hub for every shop. Locations & rooms as an opt-in beta. Calendar filters, Capacity labels, and admin create improvements.'); ?></p>
			</div>

			<div class="wca-roadmap-item is-progress">
				<div class="wca-roadmap-header">
					<h3><?php echo esc_html('Virtual meeting rooms'); ?></h3>
					<span class="wca-roadmap-status is-progress"><?php echo esc_html('In progress'); ?></span>
				</div>
				<p><?php echo esc_html('Google Meet is live via Calendar sync. Zoom, Teams, and a shared Connections hub are next.'); ?></p>
				<div class="wca-roadmap-progress">
					<div class="wca-roadmap-progress-meta">
						<strong><?php echo esc_html( 'Provider rollout' ); ?></strong>
						<span><?php echo esc_html( 'Meet live · Zoom and Teams next' ); ?></span>
					</div>
					<div class="wca-roadmap-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="40" aria-label="<?php echo esc_attr( 'Virtual meeting rooms progress' ); ?>">
						<div class="wca-roadmap-progress-fill"></div>
					</div>
				</div>
				<ul class="wca-roadmap-checklist">
					<li class="is-done"><span class="mark" aria-hidden="true">✓</span><span><?php echo esc_html( 'Google Meet via Google Calendar sync' ); ?></span></li>
					<li class="is-done"><span class="mark" aria-hidden="true">✓</span><span><?php echo esc_html( 'Join in My Account; Join Meeting in emails and admin' ); ?></span></li>
					<li class="is-done"><span class="mark" aria-hidden="true">✓</span><span><?php echo esc_html( 'Static online URL and pending-link messaging' ); ?></span></li>
					<li class="is-todo"><span class="mark" aria-hidden="true">·</span><span><?php echo esc_html( 'Zoom OAuth meeting rooms' ); ?></span></li>
					<li class="is-todo"><span class="mark" aria-hidden="true">·</span><span><?php echo esc_html( 'Microsoft Teams' ); ?></span></li>
					<li class="is-todo"><span class="mark" aria-hidden="true">·</span><span><?php echo esc_html( 'Connections settings hub' ); ?></span></li>
				</ul>
			</div>

			<div class="wca-roadmap-item is-next">
				<div class="wca-roadmap-header">
					<h3><?php echo esc_html('Group bookings & classes'); ?></h3>
					<span class="wca-roadmap-status is-next"><?php echo esc_html('Up next'); ?></span>
				</div>
				<p><?php echo esc_html('Multi-person booking with clear capacity, waitlists, and class-friendly attendance.'); ?></p>
			</div>
		</div>

		<details class="wca-roadmap-more">
			<summary><?php echo esc_html( 'Further ahead' ); ?></summary>
			<div class="wca-roadmap">
				<div class="wca-roadmap-item">
					<div class="wca-roadmap-header">
						<h3><?php echo esc_html('Modern date/time picker'); ?></h3>
						<span class="wca-roadmap-status"><?php echo esc_html('Planned'); ?></span>
					</div>
					<p><?php echo esc_html('Touch-first storefront booking with clearer availability and progressive slot loading.'); ?></p>
				</div>
				<div class="wca-roadmap-item">
					<div class="wca-roadmap-header">
						<h3><?php echo esc_html('Analytics & automation'); ?></h3>
						<span class="wca-roadmap-status"><?php echo esc_html('Planned'); ?></span>
					</div>
					<p><?php echo esc_html('Revenue and staff insights, then visual workflows for reminders and follow-ups.'); ?></p>
				</div>
				<div class="wca-roadmap-item">
					<div class="wca-roadmap-header">
						<h3><?php echo esc_html('Deeper integrations'); ?></h3>
						<span class="wca-roadmap-status"><?php echo esc_html('Exploring'); ?></span>
					</div>
					<p><?php echo esc_html( 'Outlook/Apple calendar sync, series ICS RRULE export, staff PWA, and CRM connectors.' ); ?></p>
				</div>
			</div>
		</details>

		<hr />


		<div class="wca-feedback-footer">
			<div class="has-2-columns is-wider-left">
				<div class="column">
					<h3><?php echo esc_html('Help Shape What Comes Next'); ?></h3>
					<p><?php echo esc_html('Spotted an issue or have an idea? Share it with us so we can prioritize the fixes and improvements that matter most to you and the community.'); ?>
					</p>
					<div class="wca-cta-links">
						<a class="button button-primary"
							href="<?php echo esc_url('https://github.com/bookingwp/woocommerce-appointments/issues'); ?>"
							target="_blank" rel="noopener noreferrer">
							<?php echo esc_html('Report an Issue on GitHub'); ?>
						</a>
						<a class="button"
							href="<?php echo esc_url('https://github.com/bookingwp/woocommerce-appointments/issues?q=is%3Aissue+is%3Aopen'); ?>"
							target="_blank" rel="noopener noreferrer">
							<?php echo esc_html('View Open Issues'); ?>
						</a>
					</div>
				</div>
				<div class="column">
					<div class="wca-placeholder">
						<svg viewBox="0 0 320 200" role="img" focusable="false" aria-hidden="true">
							<rect x="18" y="22" width="284" height="156" rx="14" fill="#f6f7f7" stroke="#d8dadd"
								stroke-width="1.5" />
							<!-- Issue card -->
							<rect x="42" y="50" width="110" height="64" rx="12" fill="#ffffff"
								stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="1.4" />
							<rect x="56" y="62" width="74" height="10" rx="5"
								fill="var(--wp-admin-theme-color, #2271b1)" opacity="0.9" />
							<rect x="56" y="80" width="58" height="8" rx="4" fill="var(--wp-admin-theme-color, #2271b1)"
								opacity="0.5" />
							<rect x="56" y="96" width="42" height="8" rx="4" fill="#d8dadd" />
							<path d="M96 114 L106 128 L88 116" fill="#ffffff"
								stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="1.2" />

							<!-- Activity / comments -->
							<rect x="176" y="66" width="110" height="72" rx="12" fill="#ffffff"
								stroke="var(--wp-admin-theme-color, #2271b1)" stroke-opacity="0.5" stroke-width="1.4" />
							<rect x="190" y="78" width="78" height="10" rx="5"
								fill="var(--wp-admin-theme-color, #2271b1)" opacity="0.9" />
							<rect x="190" y="94" width="64" height="8" rx="4"
								fill="var(--wp-admin-theme-color, #2271b1)" opacity="0.5" />
							<rect x="190" y="110" width="54" height="8" rx="4" fill="#d8dadd" />
							<circle cx="214" cy="130" r="6" fill="var(--wp-admin-theme-color, #2271b1)" />
							<circle cx="232" cy="130" r="6" fill="var(--wp-admin-theme-color, #2271b1)"
								fill-opacity="0.5" />

							<!-- Link/branch to tracker -->
							<path d="M152 92 C168 92, 180 92, 188 92" stroke="var(--wp-admin-theme-color, #2271b1)"
								stroke-width="3" marker-end="url(#issueArrow)" />
							<path d="M152 108 C172 116, 178 124, 188 132" stroke="var(--wp-admin-theme-color, #2271b1)"
								stroke-opacity="0.5" stroke-width="3" stroke-dasharray="6 4"
								marker-end="url(#issueArrow)" />

							<!-- Speed lines -->
							<path d="M226 40 H282" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-opacity="0.5"
								stroke-width="4" stroke-linecap="round" opacity="0.8" />
							<path d="M236 32 H268" stroke="var(--wp-admin-theme-color, #2271b1)" stroke-width="4"
								stroke-linecap="round" opacity="0.8" />

							<defs>
								<marker id="issueArrow" markerWidth="6" markerHeight="6" refX="5" refY="3"
									orient="auto">
									<path d="M0,0 L6,3 L0,6 z" fill="var(--wp-admin-theme-color, #2271b1)" />
								</marker>
							</defs>
						</svg>
					</div>
				</div>
			</div>
			<!-- Quick tips spanning full width -->
			<div class="wca-inline-note">
				<strong><?php echo esc_html('Quick tips:'); ?></strong>
				<?php echo esc_html('Add a summary, steps to reproduce, and screenshots/logs if available. Your feedback directly shapes our next sprint.'); ?>
			</div>
		</div>
	</div>

	<div id="changelog" class="about-section is-hidden">
		<h2><?php echo esc_html( 'Recent Changes' ); ?></h2>
		<p class="wca-changelog-intro">
			<?php echo esc_html( 'The short list. Full notes live on docs.bookingwp.com.' ); ?>
		</p>
		<div class="wca-changelog">
			<div class="wca-highlights changelog-card">
				<div class="wca-chip"><span class="dot" aria-hidden="true"></span><?php echo esc_html( '5.5 highlights' ); ?></div>
				<ul class="ul-disc">
					<li><?php echo esc_html( 'Availability hub for every shop, with Week at a glance while you edit.' ); ?></li>
					<li><?php echo esc_html( 'Locations & rooms (beta): Fixed show/hide or Customer selected; shared rooms with Capacity; optional costs.' ); ?></li>
					<li><?php echo esc_html( 'Google Meet join links via Calendar sync (beta + Online venue).' ); ?></li>
					<li><?php echo esc_html( 'Admin create: customer timezone; open times only by default.' ); ?></li>
					<li><?php echo esc_html( 'Faster calendars, clearer timezone labels, AutomateWoo and Germanized Pro hooks for location/resources.' ); ?></li>
				</ul>
			</div>
			<div class="wca-full-changelog-footer">
				<div class="wca-inline-note">
					<p><?php echo esc_html( 'For complete version history and detailed release notes:' ); ?></p>
					<a class="button button-primary wca-full-changelog-button" href="https://docs.bookingwp.com/appointments/changelog" target="_blank" rel="noopener noreferrer">
						<?php echo esc_html( 'View Full Changelog' ); ?>
						<span aria-hidden="true" class="wca-button-arrow">&rarr;</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	(function () {
		if ('scrollRestoration' in history) {
			history.scrollRestoration = 'manual';
		}

		const tabs = document.querySelectorAll('.nav-tab-wrapper .nav-tab');
		const mainIds = ['improvements', 'documentation', 'future', 'changelog'];
		const navItems = document.querySelectorAll('.wca-improvements-nav-item');
		const navPrev = document.querySelector('.wca-improvements-nav-btn.is-prev');
		const navNext = document.querySelector('.wca-improvements-nav-btn.is-next');
		const navStatus = document.querySelector('.wca-improvements-nav-status');
		const rail = document.querySelector('.wca-improvements-nav');
		const content = document.getElementById('wca-improvements-content');
		const subIds = Array.from(navItems).map(function (el) {
			return el.getAttribute('data-target');
		}).filter(Boolean);

		function showOnly(ids, id) {
			ids.forEach(function (x) {
				const el = document.getElementById(x);
				if (el) {
					el.classList.toggle('is-hidden', x !== id);
				}
			});
		}

		function syncChrome() {
			const idx = Array.from(navItems).findIndex(function (el) {
				return el.classList.contains('is-active');
			});
			if (navStatus) {
				navStatus.textContent = (idx + 1) + ' / ' + navItems.length;
			}
			if (navPrev) {
				navPrev.disabled = idx <= 0;
			}
			if (navNext) {
				navNext.disabled = idx >= navItems.length - 1;
			}
		}

		function loadSub(id, scrollRail) {
			const section = document.getElementById(id);
			if (!section || !content) {
				return;
			}
			navItems.forEach(function (el) {
				const on = el.getAttribute('data-target') === id;
				el.classList.toggle('is-active', on);
				el.setAttribute('aria-selected', on ? 'true' : 'false');
				if (on && scrollRail && rail) {
					rail.scrollLeft = el.offsetLeft;
				}
			});
			syncChrome();
			if (section.parentElement !== content) {
				content.appendChild(section);
			}
			showOnly(subIds, id);
		}

		function activateTab(id, scrollRail) {
			tabs.forEach(function (tab) {
				tab.classList.toggle('nav-tab-active', tab.getAttribute('href') === '#' + id);
			});
			showOnly(mainIds, id);
			if (id === 'improvements') {
				const active = document.querySelector('.wca-improvements-nav-item.is-active');
				loadSub(active ? active.getAttribute('data-target') : 'availability-55', scrollRail);
			}
			if (id === 'future') {
				updateRoadmap();
			}
		}

		function stepNav(delta) {
			const idx = Array.from(navItems).findIndex(function (el) {
				return el.classList.contains('is-active');
			});
			const next = navItems[idx + delta];
			if (!next) {
				return;
			}
			const id = next.getAttribute('data-target');
			loadSub(id, true);
			history.replaceState(null, '', '#' + id);
		}

		function updateRoadmap() {
			const roadmap = document.querySelector('.wca-roadmap');
			if (!roadmap) {
				return;
			}
			const done = roadmap.querySelectorAll('.wca-roadmap-item.is-complete');
			if (!done.length) {
				roadmap.style.setProperty('--completed-line-height', '0');
				roadmap.style.setProperty('--completed-line-top', '0');
				return;
			}
			const first = done[0];
			const last = done[done.length - 1];
			roadmap.style.setProperty('--completed-line-top', first.offsetTop + 'px');
			roadmap.style.setProperty('--completed-line-height', (last.offsetTop + last.offsetHeight - first.offsetTop) + 'px');
		}

		function initHeroScrub() {
			const story = document.getElementById('wca-hero-story');
			const svg = story && story.querySelector('svg.wca-hero-svg');
			if (!story || !svg) {
				return;
			}
			if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
				svg.style.setProperty('--hero-p', '1');
				return;
			}

			let start = null;
			let running = false;
			let raf = 0;
			const cycle = 11000;
			const frame = function (ts) {
				raf = 0;
				if (!running) {
					return;
				}
				if (start === null) {
					start = ts;
				}
				const t = ((ts - start) % cycle) / cycle;
				let p;
				if (t < 0.72) {
					p = t / 0.72;
				} else if (t < 0.88) {
					p = 1;
				} else {
					p = 1 - ((t - 0.88) / 0.12);
				}
				svg.style.setProperty('--hero-p', Math.max(0, Math.min(1, p)).toFixed(4));
				raf = window.requestAnimationFrame(frame);
			};
			const play = function () {
				if (running && !raf) {
					raf = window.requestAnimationFrame(frame);
				}
			};

			if ('IntersectionObserver' in window) {
				const io = new IntersectionObserver(function (entries) {
					const on = entries.some(function (e) { return e.isIntersecting; });
					if (on && !running) {
						start = null;
						running = true;
						play();
					} else if (!on) {
						running = false;
					}
				}, { threshold: 0.15 });
				io.observe(story);
			} else {
				running = true;
				play();
			}
		}

		if (navPrev) {
			navPrev.addEventListener('click', function () { stepNav(-1); });
		}
		if (navNext) {
			navNext.addEventListener('click', function () { stepNav(1); });
		}

		tabs.forEach(function (tab) {
			tab.addEventListener('click', function (e) {
				e.preventDefault();
				const id = this.getAttribute('href').substring(1);
				activateTab(id, true);
				history.pushState(null, '', '#' + id);
			});
		});

		navItems.forEach(function (el) {
			el.addEventListener('click', function (e) {
				e.preventDefault();
				loadSub(this.getAttribute('data-target'), true);
			});
		});

		document.querySelectorAll('a.wca-release-highlight-card[href^="#"]').forEach(function (card) {
			card.addEventListener('click', function (e) {
				const id = card.getAttribute('href').substring(1);
				if (subIds.indexOf(id) === -1) {
					return;
				}
				e.preventDefault();
				activateTab('improvements', true);
				loadSub(id, true);
				history.pushState(null, '', '#' + id);
				const section = document.getElementById(id);
				if (section && section.scrollIntoView) {
					section.scrollIntoView({ behavior: 'smooth', block: 'start' });
				}
			});
		});

		window.addEventListener('hashchange', function () {
			const hash = window.location.hash.substring(1);
			if (subIds.indexOf(hash) !== -1) {
				activateTab('improvements', true);
				loadSub(hash, true);
			} else if (mainIds.indexOf(hash) !== -1) {
				activateTab(hash, true);
			}
		});

		window.addEventListener('resize', updateRoadmap);

		subIds.forEach(function (id) {
			const section = document.getElementById(id);
			if (section && content && section.parentElement !== content) {
				content.appendChild(section);
			}
		});

		const hash = window.location.hash.substring(1);
		if (subIds.indexOf(hash) !== -1) {
			activateTab('improvements', false);
			loadSub(hash, false);
		} else if (mainIds.indexOf(hash) !== -1) {
			activateTab(hash, false);
		} else {
			activateTab('improvements', false);
		}

		window.scrollTo(0, 0);
		updateRoadmap();
		initHeroScrub();
	})();
</script>
