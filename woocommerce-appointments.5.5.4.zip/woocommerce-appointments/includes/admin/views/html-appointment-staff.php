<?php
/**
 * Product edit panel - staff assignment.
 *
 * @var WC_Product_Appointment $appointable_product Global; set by WC_Appointments_Admin::appointment_panels().
 */

defined( 'ABSPATH' ) || exit;

global $post;

$all_staff        = WC_Appointments_Admin::get_appointment_staff();
$assigned_staff   = array_map( 'intval', (array) $appointable_product->get_staff_ids( 'edit' ) );
$staff_base_costs = $appointable_product->get_staff_base_costs( 'edit' );
$staff_qtys       = $appointable_product->get_staff_qtys( 'edit' );
$can_manage_staff = current_user_can( 'manage_others_appointments' );
$can_create_users = current_user_can( 'create_users' );

$staff_by_id = [];
foreach ( $all_staff as $staff_user ) {
	$staff_by_id[ (int) $staff_user->ID ] = $staff_user;
}

$rows = [];
foreach ( $assigned_staff as $sid ) {
	if ( isset( $staff_by_id[ $sid ] ) ) {
		$rows[ $sid ] = $staff_by_id[ $sid ];
	}
}
$unassigned = array_diff_key( $staff_by_id, $rows );
uasort(
	$unassigned,
	static function ( $a, $b ): int {
		return strcasecmp( (string) $a->display_name, (string) $b->display_name );
	}
);
$rows += $unassigned;

// One query: product counts for row meta.
$staff_ids      = array_values( array_filter( array_map( 'intval', array_keys( $rows ) ) ) );
$product_counts = WC_Product_Appointment_Data_Store_CPT::get_product_counts_for_staff_ids( $staff_ids );
?>
<div id="appointments_staff" class="woocommerce_options_panel panel wc-metaboxes-wrapper">

	<div class="options_group" id="staff_options">
		<?php
		woocommerce_wp_text_input(
			[
				'id'          => '_wc_appointment_staff_label',
				'placeholder' => __( 'Providers', 'woocommerce-appointments' ),
				'label'       => __( 'Label', 'woocommerce-appointments' ),
				'value'       => $appointable_product->get_staff_label( 'edit' ),
				'desc_tip'    => true,
				'description' => __( 'The label shown on the frontend if the staff is customer defined.', 'woocommerce-appointments' ),
			]
		);

		woocommerce_wp_select(
			[
				'id'          => '_wc_appointment_staff_assignment',
				'label'       => __( 'Selection', 'woocommerce-appointments' ),
				'value'       => $appointable_product->get_staff_assignment( 'edit' ),
				'options'     => [
					'customer'  => __( 'Customer selected', 'woocommerce-appointments' ),
					'automatic' => __( 'Automatically assigned', 'woocommerce-appointments' ),
					'all'       => __( 'Automatically assigned (all staff together)', 'woocommerce-appointments' ),
				],
				'desc_tip'    => true,
				'description' => __( 'Customer selected staff allow customers to choose one from the appointment form.', 'woocommerce-appointments' ),
			]
		);

		woocommerce_wp_checkbox(
			[
				'id'          => '_wc_appointment_staff_nopref',
				'label'       => __( 'No Preference?', 'woocommerce-appointments' ),
				'value'       => $appointable_product->get_staff_nopref( 'edit' ) ? 'yes' : 'no',
				'description' => __( 'Check this box if you want to show No preference option.', 'woocommerce-appointments' ),
			]
		);
		?>
	</div>

	<div class="options_group">
		<div class="wca-entity-picker">
			<div class="wca-entity-picker__head">
				<h3><?php esc_html_e( 'Staff', 'woocommerce-appointments' ); ?></h3>
				<?php if ( $can_manage_staff || $can_create_users ) : ?>
					<div class="wca-entity-picker__actions">
						<?php if ( $can_manage_staff ) : ?>
							<a class="wca-hub-ext" href="<?php echo esc_url( admin_url( 'users.php?role=shop_staff' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Manage Staff', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
						<?php endif; ?>
						<?php if ( $can_create_users ) : ?>
							<a class="wca-hub-ext" href="<?php echo esc_url( admin_url( 'user-new.php' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Add Staff', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
			<?php if ( $all_staff ) : ?>
				<select id="add_staff_id" class="wc-enhanced-select wca-entity-picker-select" data-list="#wca_staff_list" data-placeholder="<?php esc_attr_e( 'Select staff', 'woocommerce-appointments' ); ?>">
					<option value=""></option>
					<?php foreach ( $all_staff as $staff_user ) : ?>
						<option value="<?php echo esc_attr( (string) $staff_user->ID ); ?>" <?php disabled( in_array( (int) $staff_user->ID, $assigned_staff, true ) ); ?>><?php echo esc_html( $staff_user->display_name ); ?></option>
					<?php endforeach; ?>
				</select>
			<?php endif; ?>

			<?php if ( $rows ) : ?>
				<div class="woocommerce_appointable_staff wc-metaboxes wca-entity-list" id="wca_staff_list" data-entity="staff" data-id-attr="data-staff-id" data-picker="#add_staff_id">
					<?php
					foreach ( $rows as $sid => $staff_user ) {
						$staff           = new WC_Product_Appointment_Staff( (int) $sid );
						$assigned        = in_array( (int) $sid, $assigned_staff, true );
						$staff_base_cost = $staff_base_costs[ $sid ] ?? '';
						$staff_qty       = $staff_qtys[ $sid ] ?? '';
						$meta_bits       = [];
						$email           = is_object( $staff_user ) ? (string) $staff_user->user_email : '';
						if ( $email ) {
							$meta_bits[] = $email;
						}
						$pcnt = (int) ( $product_counts[ (int) $sid ] ?? 0 );
						$meta_bits[] = sprintf(
							/* translators: %d: number of appointable products this staff is assigned to */
							_n( '%d product', '%d products', $pcnt, 'woocommerce-appointments' ),
							$pcnt
						);
						$staff_meta = implode( ', ', $meta_bits );
						include __DIR__ . '/html-appointment-staff-member.php';
					}
					?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
