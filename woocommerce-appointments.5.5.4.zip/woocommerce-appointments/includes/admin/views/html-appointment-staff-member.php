<?php
/**
 * Product edit panel - single staff metabox row.
 *
 * @var WC_Product_Appointment_Staff $staff
 * @var bool                         $assigned
 * @var string|float                 $staff_base_cost
 * @var string|int                   $staff_qty
 * @var string                       $staff_meta Secondary line (email, product count).
 * @var WP_Post                      $post
 */

defined( 'ABSPATH' ) || exit;

$staff_id  = absint( $staff->get_id() );
$assigned  = ! empty( $assigned );
$staff_meta = isset( $staff_meta ) ? (string) $staff_meta : '';
$row_class  = 'woocommerce_appointment_staff wc-metabox closed' . ( $assigned ? ' is-assigned' : '' );
?>
<div
	class="<?php echo esc_attr( $row_class ); ?>"
	data-staff-id="<?php echo esc_attr( (string) $staff_id ); ?>"
	<?php echo $assigned ? '' : ' hidden'; ?>
>
	<h3>
		<?php
		echo get_avatar( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_avatar() returns safe HTML.
			$staff_id,
			64,
			'',
			$staff->get_display_name(),
			[ 'class' => 'photo' ]
		);
		?>
		<strong>
			<span class="staff_name"><?php echo esc_html( $staff->get_display_name() ); ?></span>
			<?php if ( $staff_meta ) : ?>
				<span class="wca-entity-meta"><?php echo esc_html( $staff_meta ); ?></span>
			<?php endif; ?>
		</strong>
		<div class="handle-item" title="<?php esc_attr_e( 'Click to toggle', 'woocommerce-appointments' ); ?>"></div>
		<?php if ( current_user_can( 'edit_user', $staff_id ) ) : ?>
			<a href="<?php echo esc_url( get_edit_user_link( $staff_id ) ); ?>" target="_blank" rel="noopener noreferrer" class="edit_staff wca-hub-ext"><?php esc_html_e( 'Edit', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
		<?php endif; ?>
		<button type="button" class="remove_appointment_staff button" aria-label="<?php esc_attr_e( 'Remove', 'woocommerce-appointments' ); ?>">x</button>
	</h3>
	<table cellpadding="0" cellspacing="0" class="wc-metabox-content">
		<tbody>
			<tr>
				<td>
					<label><?php esc_html_e( 'Additional Cost', 'woocommerce-appointments' ); ?>:</label>
					<input
						type="number"
						name="wca_staff[<?php echo esc_attr( (string) $staff_id ); ?>][cost]"
						value="<?php echo '' !== $staff_base_cost && null !== $staff_base_cost ? esc_attr( (string) $staff_base_cost ) : ''; ?>"
						placeholder="0.00"
						step="0.01"
						<?php disabled( ! $assigned ); ?>
					/>
					<?php do_action( 'woocommerce_appointments_after_staff_cost', $staff_id, $post->ID ); ?>
				</td>
				<td>
					<label><?php esc_html_e( 'Capacity', 'woocommerce-appointments' ); ?>:</label>
					<input
						type="number"
						name="wca_staff[<?php echo esc_attr( (string) $staff_id ); ?>][qty]"
						value="<?php echo '' !== $staff_qty && null !== $staff_qty ? esc_attr( (string) $staff_qty ) : ''; ?>"
						placeholder="<?php esc_attr_e( 'N/A', 'woocommerce-appointments' ); ?>"
						step="1"
						min="0"
						<?php disabled( ! $assigned ); ?>
					/>
					<?php do_action( 'woocommerce_appointments_after_staff_qty', $staff_id, $post->ID ); ?>
				</td>
			</tr>
		</tbody>
	</table>
</div>
