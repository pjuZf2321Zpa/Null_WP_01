<?php
/**
 * Staff Dashboard Widget: This Week
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 *
 * @var array<string, mixed> $stats Injected by WC_Appointments_Admin_Staff_Dashboard::render_week_widget().
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="wca-dashboard-widget wca-widget-week">
	<div class="wca-week-breakdown">
		<?php
		$max_count = max( array_column( $stats['daily_breakdown'], 'count' ) );
		$max_count = max( 1, $max_count );
		foreach ( $stats['daily_breakdown'] as $day ) :
			$is_today = $day['date'] === ( $stats['staff_today'] ?? '' );
			$height = ( $day['count'] / $max_count ) * 100;
		?>
		<div class="wca-week-day <?php echo $is_today ? 'wca-week-day-today' : ''; ?>" title="<?php echo esc_attr( sprintf( '%s: %d appointments', $day['label'], $day['count'] ) ); ?>">
			<div class="wca-week-bar-container">
				<div class="wca-week-bar" data-count="<?php echo esc_attr( $day['count'] ); ?>" data-height="<?php echo esc_attr( $height ); ?>">
					<span class="wca-week-count"><?php echo esc_html( $day['count'] ); ?></span>
				</div>
			</div>
			<span class="wca-week-label"><?php echo esc_html( $day['label'] ); ?></span>
		</div>
		<?php endforeach; ?>
	</div>
	<div class="wca-week-summary">
		<span class="wca-week-total">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of appointments */
					__( '%d total this week', 'woocommerce-appointments' ),
					(int) $stats['week_count']
				)
			);
			?>
		</span>
	</div>
</div>
