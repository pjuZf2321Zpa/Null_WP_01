<?php
/**
 * Staff Dashboard Widget: Welcome / Overview
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 *
 * @var array<string, mixed> $stats   Injected by WC_Appointments_Admin_Staff_Dashboard::render_welcome_widget().
 * @var int                  $user_id Injected by WC_Appointments_Admin_Staff_Dashboard::render_welcome_widget().
 * @var WP_User              $user    Injected by WC_Appointments_Admin_Staff_Dashboard::render_welcome_widget().
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="wca-dashboard-widget wca-widget-welcome">
	<div class="wca-welcome-header">
		<div class="wca-welcome-text">
			<h2>
				<?php
				printf(
					/* translators: %s: Staff name */
					esc_html__( 'Welcome back, %s', 'woocommerce-appointments' ),
					esc_html( $user->display_name )
				);
				?>
			</h2>
			<p class="wca-page-subtitle">
				<?php echo esc_html( date_i18n( 'l, F j, Y' ) ); ?>
				<?php echo class_exists( 'WC_Appointments_Timezone_Helper' ) ? wp_kses_post( WC_Appointments_Timezone_Helper::get_admin_timezone_indicator() ) : ''; ?>
			</p>
		</div>
		<div class="wca-welcome-actions">
			<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'create_appointments' ) ) : ?>
				<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wc_appointment' ) ); ?>" class="button button-primary wca-btn-icon">
					<span class="dashicons dashicons-plus-alt2"></span>
					<?php esc_html_e( 'New Appointment', 'woocommerce-appointments' ); ?>
				</a>
			<?php endif; ?>
			<button type="button" class="button wca-refresh-stats wca-btn-icon">
				<span class="dashicons dashicons-update"></span>
				<?php esc_html_e( 'Refresh', 'woocommerce-appointments' ); ?>
			</button>
		</div>
	</div>
</div>
