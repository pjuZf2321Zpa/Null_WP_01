<?php
/**
 * Staff Dashboard Widget: Appointment Trends Chart
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 *
 * @var array<string, mixed> $stats Injected by WC_Appointments_Admin_Staff_Dashboard::render_chart_widget().
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="wca-dashboard-widget wca-widget-chart">
	<div class="wca-chart-controls">
		<button type="button" class="wca-chart-range active" data-range="7days"><?php esc_html_e( '7 Days', 'woocommerce-appointments' ); ?></button>
		<button type="button" class="wca-chart-range" data-range="30days"><?php esc_html_e( '30 Days', 'woocommerce-appointments' ); ?></button>
		<button type="button" class="wca-chart-range" data-range="90days"><?php esc_html_e( '90 Days', 'woocommerce-appointments' ); ?></button>
	</div>
	<div class="wca-chart-container">
		<canvas id="wca-appointments-chart"></canvas>
	</div>
	<div class="wca-chart-totals" id="wca-chart-totals" style="display: none;">
		<div class="wca-totals-grid">
			<div class="wca-total-item">
				<span class="wca-total-label"><?php esc_html_e( 'Total Appointments', 'woocommerce-appointments' ); ?></span>
				<span class="wca-total-value" id="wca-total-appointments">-</span>
			</div>
			<?php if ( $stats['can_view_earnings'] ) : ?>
			<div class="wca-total-item wca-total-revenue">
				<span class="wca-total-label"><?php esc_html_e( 'Total Revenue', 'woocommerce-appointments' ); ?></span>
				<span class="wca-total-value" id="wca-total-revenue">-</span>
			</div>
			<?php endif; ?>
		</div>
	</div>
</div>
