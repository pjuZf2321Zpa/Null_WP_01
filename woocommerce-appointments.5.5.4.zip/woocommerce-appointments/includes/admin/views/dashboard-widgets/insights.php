<?php
/**
 * Staff Dashboard Widget: Insights
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="wca-dashboard-widget wca-widget-insights">
	<?php if ( ! empty( $stats['popular_times'] ) && $stats['month_count'] > 0 ) : ?>
		<div class="wca-insights-list">
			<div class="wca-insight-item">
				<span class="wca-insight-icon"><span class="dashicons dashicons-clock"></span></span>
				<div class="wca-insight-content">
					<span class="wca-insight-label"><?php esc_html_e( 'Busiest Time', 'woocommerce-appointments' ); ?></span>
					<span class="wca-insight-value"><?php echo esc_html( $stats['popular_times']['peak_hour'] ); ?></span>
				</div>
			</div>
			<div class="wca-insight-item">
				<span class="wca-insight-icon"><span class="dashicons dashicons-calendar"></span></span>
				<div class="wca-insight-content">
					<span class="wca-insight-label"><?php esc_html_e( 'Busiest Day', 'woocommerce-appointments' ); ?></span>
					<span class="wca-insight-value"><?php echo esc_html( $stats['popular_times']['peak_day'] ); ?></span>
				</div>
			</div>
			<div class="wca-insight-item">
				<span class="wca-insight-icon"><span class="dashicons dashicons-groups"></span></span>
				<div class="wca-insight-content">
					<span class="wca-insight-label"><?php esc_html_e( 'Unique Customers', 'woocommerce-appointments' ); ?></span>
					<span class="wca-insight-value"><?php echo esc_html( $stats['unique_customers'] ); ?></span>
				</div>
			</div>
		</div>
	<?php else : ?>
		<p class="wca-no-data"><?php esc_html_e( 'No insights available yet. Data will appear as appointments are scheduled.', 'woocommerce-appointments' ); ?></p>
	<?php endif; ?>
</div>
