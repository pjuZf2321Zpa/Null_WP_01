<?php
/**
 * Staff Dashboard Widget: Monthly Schedule Heatmap
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

defined( 'ABSPATH' ) || exit;

$current_month = date_i18n( 'F Y' );
?>

<div class="wca-dashboard-widget wca-widget-heatmap">
	<?php if ( ! empty( $stats['occupancy_heatmap'] ) ) : ?>
		<div class="wca-month-navigation">
			<button type="button" class="wca-month-nav wca-month-prev" id="wca-month-prev" title="<?php esc_attr_e( 'Previous month', 'woocommerce-appointments' ); ?>">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M15 18l-6-6 6-6"/>
				</svg>
			</button>
			<span class="wca-month-label" id="wca-month-label"><?php echo esc_html( $current_month ); ?></span>
			<button type="button" class="wca-month-nav wca-month-next" id="wca-month-next" title="<?php esc_attr_e( 'Next month', 'woocommerce-appointments' ); ?>">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M9 18l6-6-6-6"/>
				</svg>
			</button>
		</div>
		<div class="wca-heatmap-legend">
			<span class="wca-legend-label"><?php esc_html_e( 'Less', 'woocommerce-appointments' ); ?></span>
			<span class="wca-legend-scale">
				<span class="wca-legend-box" data-level="0"></span>
				<span class="wca-legend-box" data-level="1"></span>
				<span class="wca-legend-box" data-level="2"></span>
				<span class="wca-legend-box" data-level="3"></span>
				<span class="wca-legend-box" data-level="4"></span>
			</span>
			<span class="wca-legend-label"><?php esc_html_e( 'More', 'woocommerce-appointments' ); ?></span>
		</div>
		<div class="wca-heatmap-grid">
			<div class="wca-heatmap-days">
				<?php
				// Get WordPress week start day setting (0 = Sunday, 1 = Monday, etc.)
				$start_of_week = (int) get_option( 'start_of_week', 0 );

				// Generate localized day abbreviations starting from the configured week start day
				$day_letters = [];
				for ( $i = 0; $i < 7; $i++ ) {
					$day_index = ( $start_of_week + $i ) % 7;
					// Use WordPress's date_i18n for proper localization
					$day_letters[] = date_i18n( 'D', strtotime( "next Sunday +{$day_index} days" ) );
				}

				// Output the day letters
				foreach ( $day_letters as $day_letter ) :
				?>
					<span><?php echo esc_html( $day_letter ); ?></span>
				<?php endforeach; ?>
			</div>
			<div class="wca-heatmap-cells" id="wca-heatmap-cells">
				<?php
				$first_date = array_key_first( $stats['occupancy_heatmap'] );
				$first_weekday = $stats['occupancy_heatmap'][ $first_date ]['weekday'];

				// Calculate empty cells needed based on WordPress week start day
				$start_of_week = (int) get_option( 'start_of_week', 0 );
				$adjusted_weekday = ( $first_weekday - $start_of_week + 7 ) % 7;

				// Add empty cells for days before the first of the month
				for ( $i = 0; $i < $adjusted_weekday; $i++ ) :
				?>
					<span class="wca-heatmap-cell wca-heatmap-empty"></span>
				<?php endfor; ?>
				<?php foreach ( $stats['occupancy_heatmap'] as $date => $data ) :
					$is_today = ! empty( $data['is_today'] );
				?>
					<span class="wca-heatmap-cell <?php echo $is_today ? 'wca-heatmap-today' : ''; ?>"
						data-level="<?php echo esc_attr( $data['intensity'] ); ?>"
						data-date="<?php echo esc_attr( $date ); ?>"
						title="<?php echo esc_attr( sprintf( '%s: %d appointments', date_i18n( 'M j', strtotime( $date ) ), $data['count'] ) ); ?>">
						<span class="wca-heatmap-day"><?php echo esc_html( $data['day'] ); ?></span>
					</span>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="wca-occupancy-summary">
			<span class="wca-occupancy-rate" id="wca-occupancy-rate">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: occupancy percentage */
						__( '%d%% occupancy rate', 'woocommerce-appointments' ),
						(int) $stats['occupancy']
					)
				);
				?>
			</span>
		</div>
	<?php else : ?>
		<p class="wca-no-data"><?php esc_html_e( 'No schedule data available for this month.', 'woocommerce-appointments' ); ?></p>
	<?php endif; ?>
</div>
