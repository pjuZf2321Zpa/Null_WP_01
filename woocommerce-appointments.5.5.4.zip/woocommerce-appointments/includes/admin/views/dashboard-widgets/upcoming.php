<?php
/**
 * Staff Dashboard Widget: Upcoming Appointments
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 *
 * @var array<string, mixed> $stats   Injected by WC_Appointments_Admin_Staff_Dashboard::render_upcoming_widget().
 * @var int                  $user_id Injected by WC_Appointments_Admin_Staff_Dashboard::render_upcoming_widget().
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="wca-dashboard-widget wca-widget-upcoming">
	<?php if ( ! empty( $stats['upcoming'] ) ) : ?>
		<div class="wca-widget-header-extra">
			<span class="wca-count-badge"><?php echo count( $stats['upcoming'] ); ?></span>
			<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_calendar' ) ) : ?>
			<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&page=appointment_calendar' ) ); ?>" class="wca-card-action">
				<?php esc_html_e( 'View Calendar', 'woocommerce-appointments' ); ?>
				<span class="dashicons dashicons-arrow-right-alt2"></span>
			</a>
			<?php endif; ?>
		</div>
		<div class="wca-appointments-list">
			<?php foreach ( $stats['upcoming'] as $appointment ) :
				$product    = $appointment->get_product();
				$customer   = $appointment->get_customer();
				$appointment_status = $appointment->get_status();
				$start_time = (int) $appointment->get_start();
				$end_time   = (int) $appointment->get_end();
				$is_soon    = $start_time <= strtotime( '+2 hours' );

				// Match appointments list: shift display into staff TZ when needed.
				if ( class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
					$start_time = WC_Appointments_Timezone_Helper::convert_to_admin_timezone( $start_time );
					$end_time   = WC_Appointments_Timezone_Helper::convert_to_admin_timezone( $end_time );
				}
				$is_today = date_i18n( 'Y-m-d', $start_time ) === date_i18n( 'Y-m-d' );
			?>
				<div class="wca-appointment-row <?php echo $is_today ? 'wca-appointment-today' : ''; ?> <?php echo $is_soon ? 'wca-appointment-soon' : ''; ?>">
					<div class="wca-appointment-date">
						<?php if ( $is_today ) : ?>
							<span class="wca-appointment-badge"><?php esc_html_e( 'Today', 'woocommerce-appointments' ); ?></span>
						<?php endif; ?>
						<span class="wca-appointment-day"><?php echo esc_html( date_i18n( 'j', $start_time ) ); ?></span>
						<span class="wca-appointment-month"><?php echo esc_html( date_i18n( 'M', $start_time ) ); ?></span>
					</div>
					<div class="wca-appointment-details">
						<div class="wca-appointment-title">
							<?php echo $product ? esc_html( $product->get_name() ) : esc_html__( 'Unknown Service', 'woocommerce-appointments' ); ?>
						</div>
						<div class="wca-appointment-meta">
							<span class="wca-appointment-time">
								<span class="dashicons dashicons-clock"></span>
								<?php echo esc_html( date_i18n( wc_appointments_time_format(), $start_time ) ); ?>
								–
								<?php echo esc_html( date_i18n( wc_appointments_time_format(), $end_time ) ); ?>
							</span>
							<?php if ( $customer && $customer->name ) : ?>
							<span class="wca-appointment-customer">
								<span class="dashicons dashicons-admin-users"></span>
								<?php echo esc_html( $customer->name ); ?>
							</span>
							<?php endif; ?>
							<?php
							$location_title = trim( (string) ( $appointment->get_location()['title'] ?? '' ) );
							if ( '' !== $location_title ) :
								?>
							<span class="wca-appointment-location"><span class="dashicons dashicons-location"></span><?php echo esc_html( $location_title ); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="wca-appointment-status">
						<span class="wca-status wca-status-<?php echo esc_attr( $appointment_status ); ?>">
							<?php echo esc_html( wc_appointments_get_status_label( $appointment_status ) ); ?>
						</span>
					</div>
					<div class="wca-appointment-actions">
						<a href="<?php echo esc_url( get_edit_post_link( $appointment->get_id() ) ); ?>" class="wca-action-btn" title="<?php esc_attr_e( 'View Details', 'woocommerce-appointments' ); ?>" data-wca-panel-view="<?php echo esc_attr( (string) $appointment->get_id() ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</a>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<div class="wca-empty-state">
			<div class="wca-empty-icon">
				<span class="dashicons dashicons-calendar-alt"></span>
			</div>
			<h3><?php esc_html_e( 'No Upcoming Appointments', 'woocommerce-appointments' ); ?></h3>
			<p>
				<?php
				if ( ! empty( $filter_location_name ) ) {
					printf(
						/* translators: %s: location name */
						esc_html__( 'No upcoming appointments at %s. Try another location or All locations.', 'woocommerce-appointments' ),
						esc_html( $filter_location_name )
					);
				} else {
					esc_html_e( 'Your upcoming schedule is clear. New appointments will appear here.', 'woocommerce-appointments' );
				}
				?>
			</p>
			<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'create_appointments' ) ) : ?>
			<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wc_appointment' ) ); ?>" class="button button-primary">
				<?php esc_html_e( 'Create Appointment', 'woocommerce-appointments' ); ?>
			</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</div>
