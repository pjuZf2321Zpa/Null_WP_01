<?php
/**
 * Staff Dashboard Widget: Top Products
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="wca-dashboard-widget wca-widget-top-products">
	<?php if ( ! empty( $stats['top_products'] ) ) : ?>
		<div class="wca-products-list">
			<?php
			$max_product_count = max( array_column( $stats['top_products'], 'count' ) );
			foreach ( $stats['top_products'] as $index => $product ) :
				$bar_width = ( $product['count'] / $max_product_count ) * 100;
			?>
			<div class="wca-product-row">
				<span class="wca-product-rank"><?php echo esc_html( $index + 1 ); ?></span>
				<div class="wca-product-info">
					<span class="wca-product-name"><?php echo esc_html( $product['name'] ); ?></span>
					<div class="wca-product-bar">
						<div class="wca-product-bar-fill" data-width="<?php echo esc_attr( $bar_width ); ?>"></div>
					</div>
				</div>
				<span class="wca-product-count"><?php echo esc_html( $product['count'] ); ?></span>
			</div>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<p class="wca-no-data"><?php esc_html_e( 'No product data available yet.', 'woocommerce-appointments' ); ?></p>
	<?php endif; ?>
</div>
