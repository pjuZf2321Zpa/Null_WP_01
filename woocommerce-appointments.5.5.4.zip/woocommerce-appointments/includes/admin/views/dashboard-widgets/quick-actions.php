<?php
/**
 * Staff Dashboard Widget: Quick Actions
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 *
 * @var int $user_id Injected by WC_Appointments_Admin_Staff_Dashboard::render_quick_actions_widget().
 */

defined( 'ABSPATH' ) || exit;

$can_view_customers = WC_Appointments_Staff_Permissions::can( $user_id, 'view_customers' );
?>

<div class="wca-dashboard-widget wca-widget-quick-actions">
	<div class="wca-quick-links">
		<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_calendar' ) ) : ?>
		<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&page=appointment_calendar' ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-calendar-alt"></span>
			<span><?php esc_html_e( 'Calendar', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php endif; ?>
		<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_appointments_list' ) ) : ?>
		<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment' ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-list-view"></span>
			<span><?php esc_html_e( 'All Appointments', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php endif; ?>
		<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'manage_own_availability' ) ) : ?>
		<a href="<?php echo esc_url( WC_Appointments_Admin_Availability_Hub::url( 'staff', $user_id ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-clock"></span>
			<span><?php esc_html_e( 'Availability', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php endif; ?>
		<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'manage_locations' ) ) : ?>
		<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wca_location' ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-location"></span>
			<span><?php esc_html_e( 'Locations', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php endif; ?>
		<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'manage_resources' ) ) : ?>
		<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wca_resource' ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-building"></span>
			<span><?php esc_html_e( 'Rooms & resources', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php endif; ?>
		<a href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-admin-users"></span>
			<span><?php esc_html_e( 'Profile', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php if ( $can_view_customers ) : ?>
		<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&page=wca-staff-customers' ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-groups"></span>
			<span><?php esc_html_e( 'Customers', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php endif; ?>
		<?php if ( WC_Appointments_Staff_Permissions::can( $user_id, 'export_appointments' ) ) : ?>
		<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&page=appointment_export' ) ); ?>" class="wca-quick-link">
			<span class="dashicons dashicons-download"></span>
			<span><?php esc_html_e( 'Export', 'woocommerce-appointments' ); ?></span>
		</a>
		<?php endif; ?>
	</div>
</div>
