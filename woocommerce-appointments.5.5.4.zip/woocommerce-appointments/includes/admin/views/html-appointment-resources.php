<?php
/**
 * Product edit panel - resources (sortable rows with cost and max appointments).
 *
 * @var WC_Product_Appointment $appointable_product Global; set by WC_Appointments_Admin::appointment_panels().
 * @since 5.5.0
 */

defined( 'ABSPATH' ) || exit;

$requirements = $appointable_product->get_resource_requirements( 'edit' );
$by_id        = [];
$assigned_ids = [];
foreach ( $requirements as $req ) {
	$rid = (int) ( $req['resource_id'] ?? 0 );
	if ( $rid > 0 ) {
		$assigned_ids[] = $rid;
		$by_id[ $rid ]  = $req;
	}
}

$all_resources   = class_exists( 'WC_Appointments_Resource' ) ? WC_Appointments_Resource::get_resource_choices() : [];
$grouped_choices = [];
$loc_meta        = []; // rid => [ key, label ]

foreach ( $all_resources as $rid => $title ) {
	$rid     = (int) $rid;
	$loc_id  = WC_Appointments_Resource_Data_Store::get_location_id( $rid );
	$loc_key = $loc_id > 0 ? (string) $loc_id : '0';
	if ( ! isset( $grouped_choices[ $loc_key ] ) ) {
		$grouped_choices[ $loc_key ] = [
			'label' => WC_Appointments_Resource::get_location_label( $rid ),
			'items' => [],
		];
	}
	$grouped_choices[ $loc_key ]['items'][ $rid ] = $title;
	$loc_meta[ $rid ]                             = [
		'key'   => $loc_key,
		'label' => $grouped_choices[ $loc_key ]['label'],
	];
}

if ( $grouped_choices ) {
	uksort(
		$grouped_choices,
		static function ( string $a, string $b ) use ( $grouped_choices ): int {
			return strcasecmp( $grouped_choices[ $a ]['label'], $grouped_choices[ $b ]['label'] );
		}
	);
}

// Assigned first (stored order), then unassigned A-Z, then missing.
$rows = [];
foreach ( $assigned_ids as $rid ) {
	if ( isset( $all_resources[ $rid ] ) ) {
		$rows[ $rid ] = $all_resources[ $rid ];
	}
}
$unassigned = array_diff_key( $all_resources, $rows );
asort( $unassigned, SORT_NATURAL | SORT_FLAG_CASE );
foreach ( $unassigned as $rid => $title ) {
	$rows[ (int) $rid ] = $title;
}
foreach ( $assigned_ids as $rid ) {
	if ( ! isset( $all_resources[ $rid ] ) ) {
		$rows[ $rid ] = '';
	}
}
?>
<div id="appointments_resources" class="woocommerce_options_panel panel wc-metaboxes-wrapper">

	<div class="options_group" id="resource_options">
		<?php
		woocommerce_wp_select(
			[
				'id'          => '_wc_appointment_resource_assignment',
				'label'       => __( 'Selection', 'woocommerce-appointments' ),
				'value'       => $appointable_product->get_resource_assignment( 'edit' ),
				'options'     => [
					'display'  => __( 'Automatic, show name', 'woocommerce-appointments' ),
					'hidden'   => __( 'Automatic', 'woocommerce-appointments' ),
					'customer' => __( 'Customer selects', 'woocommerce-appointments' ),
				],
				'desc_tip'    => true,
				'description' => __( 'Automatic assigns one free resource. Show name reveals it in cart and order. Customer selects lets them pick one.', 'woocommerce-appointments' ),
			]
		);

		woocommerce_wp_text_input(
			[
				'id'          => '_wc_appointment_resource_label',
				'placeholder' => __( 'Resources', 'woocommerce-appointments' ),
				'label'       => __( 'Label', 'woocommerce-appointments' ),
				'value'       => $appointable_product->get_resource_label( 'edit' ),
				'desc_tip'    => true,
				'description' => __( 'Heading for the resource name in cart and on the form.', 'woocommerce-appointments' ),
			]
		);
		?>
	</div>

	<div class="options_group">
		<div class="wca-resource-need-location" hidden>
			<img src="<?php echo esc_url( WC()->plugin_url() . '/assets/images/icons/info.svg' ); ?>" alt="" width="80" height="80" />
			<p>
				<?php
				echo wp_kses_post(
					sprintf(
						/* translators: %s: link to the Locations product data tab */
						__( 'First choose a location on the %s tab. Then come back here to assign resources.', 'woocommerce-appointments' ),
						'<a href="#appointments_locations" class="wca-product-config-tab-link">' . esc_html__( 'Locations', 'woocommerce-appointments' ) . '</a>'
					)
				);
				?>
			</p>
		</div>

		<div class="wca-entity-picker">
			<div class="wca-entity-picker__head">
				<h3>
					<?php esc_html_e( 'Resources', 'woocommerce-appointments' ); ?>
					<?php echo wc_help_tip( esc_html__( 'Rooms and equipment. Drag to set Automatic pick order and the customer list (first is the storefront default).', 'woocommerce-appointments' ) ); ?>
				</h3>
				<div class="wca-entity-picker__actions">
					<a class="wca-hub-ext" href="<?php echo esc_url( admin_url( 'edit.php?post_type=wca_resource' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Manage Resources', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
					<a class="wca-hub-ext" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wca_resource' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Add Resource', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
				</div>
			</div>
			<?php if ( $grouped_choices ) : ?>
				<select id="add_resource_id" class="wc-enhanced-select wca-entity-picker-select" data-list="#wca_resource_list" data-placeholder="<?php esc_attr_e( 'Select resources', 'woocommerce-appointments' ); ?>">
					<option value=""></option>
					<?php foreach ( $grouped_choices as $loc_key => $group ) : ?>
						<optgroup label="<?php echo esc_attr( $group['label'] ); ?>">
							<?php foreach ( $group['items'] as $rid => $title ) : ?>
								<option value="<?php echo esc_attr( (string) $rid ); ?>" data-location-id="<?php echo esc_attr( (string) $loc_key ); ?>" <?php disabled( in_array( (int) $rid, $assigned_ids, true ) ); ?>><?php echo esc_html( $title ); ?></option>
							<?php endforeach; ?>
						</optgroup>
					<?php endforeach; ?>
				</select>
			<?php endif; ?>

			<?php if ( $rows ) : ?>
				<div class="woocommerce_appointable_resources wc-metaboxes wca-entity-list" id="wca_resource_list" data-entity="resource" data-id-attr="data-resource-id" data-picker="#add_resource_id">
				<?php foreach ( $rows as $rid => $title ) : ?>
					<?php
					$rid        = (int) $rid;
					$assigned   = in_array( $rid, $assigned_ids, true );
					$is_missing = '' === $title;
					$loc_key    = $is_missing ? 'missing' : ( $loc_meta[ $rid ]['key'] ?? '0' );
					$loc_label  = $is_missing ? '' : ( $loc_meta[ $rid ]['label'] ?? '' );
					$req        = $by_id[ $rid ] ?? [];
					$cost       = $req['cost'] ?? '';
					$capacity   = $req['capacity'] ?? '';
					$thumb_url  = $is_missing ? '' : (string) ( get_the_post_thumbnail_url( $rid, 'thumbnail' ) ?: '' );
					$name       = $is_missing
						? sprintf(
							/* translators: %d: resource ID */
							__( 'Resource #%d (missing)', 'woocommerce-appointments' ),
							$rid
						)
						: $title;
					$row_class = 'woocommerce_appointment_resource wc-metabox closed' . ( $assigned ? ' is-assigned' : '' ) . ( $is_missing ? ' is-missing' : '' );
					?>
					<div
						class="<?php echo esc_attr( $row_class ); ?>"
						data-resource-id="<?php echo esc_attr( (string) $rid ); ?>"
						data-location-id="<?php echo esc_attr( $loc_key ); ?>"
						<?php echo $assigned ? '' : ' hidden'; ?>
					>
						<h3>
							<?php if ( $thumb_url ) : ?>
								<img src="<?php echo esc_url( $thumb_url ); ?>" class="photo" alt="" width="32" height="32" />
							<?php endif; ?>
							<strong>
								<span class="resource_name"><?php echo esc_html( $name ); ?></span>
								<?php if ( $loc_label ) : ?>
									<span class="wca-entity-meta">
										<span class="dashicons dashicons-location" aria-hidden="true"></span>
										<?php echo esc_html( $loc_label ); ?>
									</span>
								<?php endif; ?>
							</strong>
							<div class="handle-item" title="<?php esc_attr_e( 'Click to toggle', 'woocommerce-appointments' ); ?>"></div>
							<?php if ( ! $is_missing && current_user_can( 'edit_post', $rid ) ) : ?>
								<a href="<?php echo esc_url( get_edit_post_link( $rid, 'raw' ) ); ?>" target="_blank" rel="noopener noreferrer" class="edit_resource wca-hub-ext"><?php esc_html_e( 'Edit', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
							<?php endif; ?>
							<button type="button" class="remove_appointment_resource button" aria-label="<?php esc_attr_e( 'Remove', 'woocommerce-appointments' ); ?>">x</button>
						</h3>
						<table cellpadding="0" cellspacing="0" class="wc-metabox-content">
							<tbody>
								<tr>
									<td>
										<label><?php esc_html_e( 'Additional Cost', 'woocommerce-appointments' ); ?>:<?php echo wc_help_tip( esc_html__( 'Added to the appointment price when this resource is assigned.', 'woocommerce-appointments' ) ); ?></label>
										<input
											type="number"
											name="wca_resource[<?php echo esc_attr( (string) $rid ); ?>][cost]"
											value="<?php echo '' !== $cost ? esc_attr( (string) $cost ) : ''; ?>"
											placeholder="0.00"
											step="0.01"
											<?php disabled( ! $assigned ); ?>
										/>
									</td>
									<td>
										<label><?php esc_html_e( 'Capacity', 'woocommerce-appointments' ); ?>:<?php echo wc_help_tip( esc_html__( 'How many bookings can use this at the same time. Use the same number on every product that shares it.', 'woocommerce-appointments' ) ); ?></label>
										<input
											type="number"
											name="wca_resource[<?php echo esc_attr( (string) $rid ); ?>][capacity]"
											value="<?php echo '' !== $capacity ? esc_attr( (string) $capacity ) : ''; ?>"
											placeholder="1"
											step="1"
											min="1"
											<?php disabled( ! $assigned ); ?>
										/>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( ! $rows ) : ?>
			<p class="description wca-resource-empty">
				<?php esc_html_e( 'No resources yet. Create a room or equipment resource, then assign it here.', 'woocommerce-appointments' ); ?>
			</p>
		<?php endif; ?>
	</div>
</div>
