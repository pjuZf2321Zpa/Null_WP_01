<?php
/**
 * Appointment membership plan fields on WCS subscription products.
 *
 * @var WC_Product $product_object
 *
 * @package WooCommerce\Appointments\Admin\Views
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $product_object ) || ! $product_object ) {
	return;
}

if ( ! class_exists( 'WC_Appointments_Integration_Subscription_Plan' ) ) {
	return;
}

$is_membership = 'yes' === $product_object->get_meta( WC_Appointments_Integration_Subscription_Plan::META_MEMBERSHIP );
$per_period    = (int) $product_object->get_meta( WC_Appointments_Integration_Subscription_Plan::META_APPOINTMENTS_PER_PERIOD );
$is_unlimited  = 'yes' === $product_object->get_meta( WC_Appointments_Integration_Subscription_Plan::META_UNLIMITED );
$rollover      = 'yes' === $product_object->get_meta( WC_Appointments_Integration_Subscription_Plan::META_ROLLOVER );
$eligible_raw  = $product_object->get_meta( WC_Appointments_Integration_Subscription_Plan::META_ELIGIBLE_PRODUCTS );
$eligible_ids  = is_array( $eligible_raw ) ? $eligible_raw : array_filter( array_map( 'absint', explode( ',', (string) $eligible_raw ) ) );

$per_period_options = WC_Appointments_Integration_Subscription_Plan::get_appointments_per_period_options();

if ( $per_period <= 0 ) {
	$per_period = 4;
}

if ( $is_unlimited ) {
	$per_period_value = 'unlimited';
} elseif ( isset( $per_period_options[ (string) $per_period ] ) ) {
	$per_period_value = (string) $per_period;
} else {
	$per_period_value = 'custom';
}

// Match linked products (upsells / cross-sells) field width in WooCommerce product admin.
$wordpress_version = get_bloginfo( 'version' );
if ( $wordpress_version ) {
	$version_parts     = explode( '-', $wordpress_version );
	$wordpress_version = count( $version_parts ) > 1 ? $version_parts[0] : $wordpress_version;
}
$select_width = $wordpress_version && version_compare( $wordpress_version, '7.0', '>=' ) ? 'width: 55%;' : 'width: 50%;';

// WooCommerce product admin: show_if_{checkbox_id_without_leading_underscore}, optional hidden until toggled.
$show_if_membership = 'show_if_wca_appointment_membership';
$membership_group   = $show_if_membership . ( $is_membership ? '' : ' hidden' );
$limit_wrapper      = '_wca_appointments_per_period_limit_field' . ( 'custom' === $per_period_value ? '' : ' hidden' );
?>
<div class="options_group">
	<?php
	woocommerce_wp_checkbox(
		array(
			'id'          => WC_Appointments_Integration_Subscription_Plan::META_MEMBERSHIP,
			'label'       => __( 'Appointment membership', 'woocommerce-appointments' ),
			'value'       => $is_membership ? 'yes' : 'no',
			'description' => __( 'Credits for appointable products each billing cycle.', 'woocommerce-appointments' ),
		)
	);
	?>
</div>
<div class="options_group <?php echo esc_attr( $membership_group ); ?>">
	<?php
	woocommerce_wp_select(
		array(
			'id'          => '_wca_appointments_per_period_mode',
			'label'       => __( 'Appointments per period', 'woocommerce-appointments' ),
			'value'       => $per_period_value,
			'options'     => $per_period_options,
			'class'       => 'select',
			'style'       => $select_width,
			'desc_tip'    => true,
			'description' => __( 'Credits per billing cycle. Price and interval are on General.', 'woocommerce-appointments' ),
		)
	);

	woocommerce_wp_text_input(
		array(
			'id'                => WC_Appointments_Integration_Subscription_Plan::META_APPOINTMENTS_PER_PERIOD,
			'label'             => __( 'Limit', 'woocommerce-appointments' ),
			'type'              => 'number',
			'class'             => 'short',
			'value'             => (string) $per_period,
			'wrapper_class'     => $limit_wrapper,
			'custom_attributes' => array(
				'min'  => '1',
				'max'  => '365',
				'step' => '1',
			),
		)
	);

	woocommerce_wp_checkbox(
		array(
			'id'          => WC_Appointments_Integration_Subscription_Plan::META_ROLLOVER,
			'label'       => __( 'Rollover unused', 'woocommerce-appointments' ),
			'value'       => $rollover ? 'yes' : 'no',
			'description' => __( 'Add unused credits to the next period.', 'woocommerce-appointments' ),
		)
	);
	?>

	<p class="form-field _wca_eligible_appointment_products_field">
		<label for="_wca_eligible_appointment_products"><?php esc_html_e( 'Eligible products', 'woocommerce-appointments' ); ?></label>
		<select class="wc-product-search" multiple="multiple" style="<?php echo esc_attr( $select_width ); ?>" id="_wca_eligible_appointment_products" name="_wca_eligible_appointment_products[]" data-placeholder="<?php echo esc_attr( __( 'All products', 'woocommerce-appointments' ) ); ?>" data-action="woocommerce_json_search_appointable_products" data-exclude="<?php echo esc_attr( (string) $product_object->get_id() ); ?>">
			<?php
			if ( ! empty( $eligible_ids ) ) {
				_prime_post_caches( $eligible_ids );

				foreach ( $eligible_ids as $eligible_id ) {
					$eligible_product = wc_get_product( $eligible_id );
					if ( $eligible_product ) {
						echo '<option value="' . esc_attr( (string) $eligible_id ) . '" selected="selected">' . esc_html( wp_strip_all_tags( $eligible_product->get_formatted_name() ) ) . '</option>';
					}
				}
			}
			?>
		</select> <?php echo wc_help_tip( esc_html__( 'Leave empty to allow any appointable product.', 'woocommerce-appointments' ) ); ?>
	</p>
</div>
