<?php
/**
 * Availability hub shell (rail + panels painted by admin-availability-hub.js).
 *
 * @package WooCommerce_Appointments
 *
 * @var array<string, bool>   $hub_presence Presence flags from bootstrap().
 * @var list<string>          $hub_allowed  Allowed layer keys from bootstrap() (display order).
 * @var string                $hub_tab      Initial layer tab key.
 * @var array<string, int>    $hub_counts   Rule totals per layer.
 * @var string $hub_rail_sub Rail subtitle (layers from allowed list).
 */

defined( 'ABSPATH' ) || exit;

$hub_presence = is_array( $hub_presence ?? null ) ? $hub_presence : [];
$hub_allowed  = is_array( $hub_allowed ?? null ) ? $hub_allowed : [];
$hub_tab      = isset( $hub_tab ) ? (string) $hub_tab : 'global';
$hub_counts   = is_array( $hub_counts ?? null ) ? $hub_counts : [];
$hub_rail_sub = isset( $hub_rail_sub ) ? (string) $hub_rail_sub : '';

$labels = [
	'global'   => _x( 'General', 'availability hub layer: default hours for the store, not a physical shop', 'woocommerce-appointments' ),
	'location' => __( 'Locations', 'woocommerce-appointments' ),
	'resource' => __( 'Resources', 'woocommerce-appointments' ),
	'product'  => __( 'Products', 'woocommerce-appointments' ),
	'staff'    => __( 'Staff', 'woocommerce-appointments' ),
];

$present = [
	'global'   => ! empty( $hub_presence['global'] ),
	'location' => ! empty( $hub_presence['locations'] ),
	'resource' => ! empty( $hub_presence['resources'] ),
	'product'  => ! empty( $hub_presence['products'] ),
	'staff'    => ! empty( $hub_presence['staff'] ),
];

$badge = static function ( string $layer ) use ( $hub_counts ): string {
	$n = (int) ( $hub_counts[ $layer ] ?? 0 );
	return sprintf(
		'<span class="n" data-count="%1$s" data-empty="%2$s">%3$s</span>',
		esc_attr( $layer ),
		$n ? '0' : '1',
		$n ? esc_html( (string) $n ) : ''
	);
};
?>
<div class="wrap wca-availability-hub">
	<div class="hub hub-layout">
		<aside class="hub-rail" id="hub-rail">
			<div class="hub-brand">
				<h1><?php esc_html_e( 'Availability', 'woocommerce-appointments' ); ?></h1>
				<p class="sub"><?php echo esc_html( $hub_rail_sub ); ?></p>
			</div>
			<button type="button" class="hub-rail-toggle" id="hub-rail-toggle" aria-expanded="false" aria-controls="hub-rail">
				<span class="hub-rail-toggle-label" id="hub-rail-toggle-label"><?php echo esc_html( $labels[ $hub_tab ] ?? $labels['global'] ); ?></span>
				<span class="chev" aria-hidden="true"></span>
			</button>
			<div class="hub-rail-search" id="hub-rail-search">
				<div class="wca-search-box">
					<span class="search-ico" aria-hidden="true"></span>
					<input type="search" id="side-search" placeholder="<?php esc_attr_e( 'Search', 'woocommerce-appointments' ); ?>" value="" autocomplete="off" aria-label="<?php esc_attr_e( 'Search', 'woocommerce-appointments' ); ?>">
					<button type="button" class="search-clear" data-clear-search aria-label="<?php esc_attr_e( 'Clear search', 'woocommerce-appointments' ); ?>">&times;</button>
				</div>
				<div class="hub-entities is-search" id="hub-results" hidden></div>
			</div>
			<nav class="hub-layers" id="hub-layers" aria-label="<?php esc_attr_e( 'Availability layers', 'woocommerce-appointments' ); ?>">
				<?php if ( in_array( 'global', $hub_allowed, true ) ) : ?>
					<a class="hub-layer is-root" href="<?php echo esc_url( WC_Appointments_Admin_Availability_Hub::url( 'global' ) ); ?>" data-tab="global" aria-current="<?php echo 'global' === $hub_tab ? 'page' : 'false'; ?>"<?php echo ! empty( $present['global'] ) ? '' : ' hidden'; ?>>
						<?php echo esc_html( $labels['global'] ); ?>
						<?php echo $badge( 'global' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</a>
				<?php endif; ?>
				<div class="hub-layers-rest">
					<?php foreach ( array_values( array_diff( $hub_allowed, [ 'global' ] ) ) as $layer ) : ?>
						<a class="hub-layer" href="<?php echo esc_url( WC_Appointments_Admin_Availability_Hub::url( $layer ) ); ?>" data-tab="<?php echo esc_attr( $layer ); ?>" aria-current="<?php echo $hub_tab === $layer ? 'page' : 'false'; ?>"<?php echo ! empty( $present[ $layer ] ) ? '' : ' hidden'; ?>>
							<?php echo esc_html( $labels[ $layer ] ); ?>
							<?php echo $badge( $layer ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
					<?php endforeach; ?>
				</div>
				<div class="hub-entities" id="hub-entities" hidden></div>
			</nav>
		</aside>
		<div class="hub-main">
			<hr class="wp-header-end">
			<?php foreach ( $hub_allowed as $layer ) : ?>
				<section class="panel<?php echo $hub_tab === $layer ? ' active' : ''; ?>" role="tabpanel" id="panel-<?php echo esc_attr( $layer ); ?>" data-panel="<?php echo esc_attr( $layer ); ?>"<?php echo $hub_tab === $layer ? '' : ' hidden'; ?>></section>
			<?php endforeach; ?>
		</div>
	</div>
</div>
