<?php
/**
 * Legacy admin calendar — month view (included from WC_Appointments_Admin_Calendar::output()).
 *
 * @var WC_Appointments_Admin_Calendar $this
 * @var string                         $view
 * @var array<int, WP_User>            $staff_list
 * @var int|string                     $product_filter
 * @var int|string                     $staff_filter
 * @var int                            $month
 * @var int                            $year
 * @var int                            $start_time
 * @var int                            $end_time
 */
?>
<div class="wrap woocommerce">
	<h2><?php esc_attr_e( 'Calendar', 'woocommerce-appointments' ); ?> <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&page=add_appointment' ) ); ?>" class="add-new-h2"><?php esc_attr_e( 'Add New Appointment', 'woocommerce-appointments' ); ?></a></h2>
	<form method="get" id="mainform" enctype="multipart/form-data" class="wc_appointments_calendar_form month_view">
		<input type="hidden" name="post_type" value="wc_appointment" />
		<input type="hidden" name="page" value="appointment_calendar" />
		<input type="hidden" name="calendar_month" value="<?php echo absint( $month ); ?>" />
		<input type="hidden" name="view" value="<?php echo esc_attr( $view ); ?>" />
		<input type="hidden" name="tab" value="calendar" />

		<?php require __DIR__ . '/html-calendar-nav.php'; ?>

		<table class="wc_appointments_calendar widefat">
			<thead>
				<tr>
					<?php $start_of_week = absint( get_option( 'start_of_week', 1 ) ); ?>
					<?php for ( $ii = $start_of_week; $start_of_week + 7 > $ii; $ii ++ ) : ?>
						<th><?php echo esc_html( date_i18n( _x( 'l', 'date format', 'woocommerce-appointments' ), strtotime( "next sunday +{$ii} day" ) ) ); ?></th>
					<?php endfor; ?>
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php
					$timestamp    = $start_time;
					$current_date = date( 'Y-m-d', current_time( 'timestamp' ) );
					$index        = 0;
					while ( $timestamp <= $end_time ) :
						$timestamp_date = date( 'Y-m-d', $timestamp );
						$is_today       = $timestamp_date === $current_date;
						?>
						<td width="14.285%" class="<?php
						if ( date( 'n', $timestamp ) != absint( $month ) ) {
							echo 'calendar-diff-month';
						}
						if ( current_time( 'timestamp' ) > ( $timestamp + DAY_IN_SECONDS ) ) {
							echo ' calendar-passed-day';
						}
						if ( $is_today ) {
							echo ' calendar-current-day';
						}
						?>">
							<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wc_appointment&page=appointment_calendar&view=day&tab=calendar&calendar_day=' . date( 'Y-m-d', $timestamp ) ) ); ?>" class="datenum">
								<?php echo esc_html( date( 'd', $timestamp ) ); ?>
							</a>
							<div class="events bymonth">
								<?php
								$this->list_events(
									(int) date( 'd', $timestamp ),
									(int) date( 'm', $timestamp ),
									(int) date( 'Y', $timestamp ),
									'by_month',
								);
								?>
							</div>
						</td>
						<?php
						$timestamp = strtotime( '+1 day', $timestamp );
						$index ++;

						if ( 0 === $index % 7 ) {
							echo '</tr><tr>';
						}
					endwhile;
					?>
				</tr>
			</tbody>
		</table>
	</form>
</div>
