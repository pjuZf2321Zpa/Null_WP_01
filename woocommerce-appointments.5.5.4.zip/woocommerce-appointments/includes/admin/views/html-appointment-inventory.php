<?php
/**
 * Product edit panel — inventory / capacity.
 *
 * @var WC_Product_Appointment $appointable_product Global; set by WC_Appointments_Admin::appointment_inventory().
 */

defined( 'ABSPATH' ) || exit;

$stock_quantity = max( absint( $appointable_product->get_qty( 'edit' ) ), 1 );
$capacity_min   = max( absint( $appointable_product->get_qty_min( 'edit' ) ), 1 );
$capacity_max   = 0 === $appointable_product->get_qty_max( 'edit' ) ? 1 : max( absint( $appointable_product->get_qty_max( 'edit' ) ), 1 );
$qty_basis      = $appointable_product->get_qty_basis( 'edit' );
$capacity_tip   = WC_Appointments_Features::is_locations_resources_active()
	? __( 'How many appointments can share the same slot. Staff Capacity overrides this when set; without staff, capacity is per location. Rooms use Capacity on Resources.', 'woocommerce-appointments' )
	: __( 'How many appointments can share the same slot. Staff Capacity overrides this when set.', 'woocommerce-appointments' );
?>
<div class="options_group show_if_appointment">
	<p class="form-field _wc_appointment_qty_field">
		<label for="_wc_appointment_qty"><?php esc_html_e( 'Capacity', 'woocommerce-appointments' ); ?></label>
		<input type="number" class="short wc_input_stock" name="_wc_appointment_qty" id="_wc_appointment_qty" value="<?php echo esc_attr( (string) wc_stock_amount( $stock_quantity ) ); ?>" step="1" min="1">
		<?php echo wc_help_tip( esc_html( $capacity_tip ) ); ?>
	</p>
	<p class="form-field _wc_appointment_qty_basis_field">
		<label for="_wc_appointment_qty_basis"><?php esc_html_e( 'Capacity applies', 'woocommerce-appointments' ); ?></label>
		<select name="_wc_appointment_qty_basis" id="_wc_appointment_qty_basis" class="select short">
			<option value="slot" <?php selected( $qty_basis, 'slot' ); ?>><?php esc_html_e( 'Per slot', 'woocommerce-appointments' ); ?></option>
			<option value="day" <?php selected( $qty_basis, 'day' ); ?>><?php esc_html_e( 'Per day', 'woocommerce-appointments' ); ?></option>
		</select>
		<?php echo wc_help_tip( esc_html__( 'Count per slot, or across the whole day.', 'woocommerce-appointments' ) ); ?>
	</p>
	<p class="form-field _wc_appointment_qty_min_field">
		<label for="_wc_appointment_qty_min"><?php esc_html_e( 'Minimum', 'woocommerce-appointments' ); ?></label>
		<input type="number" class="short wc_input_stock" name="_wc_appointment_qty_min" id="_wc_appointment_qty_min" value="<?php echo esc_attr( (string) wc_stock_amount( $capacity_min ) ); ?>" step="1" min="1">
		<?php echo wc_help_tip( esc_html__( 'Min quantity in one booking.', 'woocommerce-appointments' ) ); ?>
	</p>
	<p class="form-field _wc_appointment_qty_max_field">
		<label for="_wc_appointment_qty_max"><?php esc_html_e( 'Maximum', 'woocommerce-appointments' ); ?></label>
		<input type="number" class="short wc_input_stock" name="_wc_appointment_qty_max" id="_wc_appointment_qty_max" value="<?php echo esc_attr( (string) wc_stock_amount( $capacity_max ) ); ?>" step="1" min="1">
		<?php echo wc_help_tip( esc_html__( 'Max quantity in one booking. Raise for group bookings when staff Capacity is higher than product Capacity.', 'woocommerce-appointments' ) ); ?>
	</p>
</div>
