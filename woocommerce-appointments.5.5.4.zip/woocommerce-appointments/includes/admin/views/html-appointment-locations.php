<?php
/**
 * Product edit panel - location mode and allow-list.
 *
 * @var WC_Product_Appointment $appointable_product Global; set by WC_Appointments_Admin::appointment_panels().
 * @since 5.5.0
 */

defined( 'ABSPATH' ) || exit;

$location_choices = class_exists( 'WC_Appointments_Location' ) ? WC_Appointments_Location::get_location_choices() : [];
$selected_ids     = array_map( 'intval', (array) $appointable_product->get_location_ids( 'edit' ) );
$mode             = $appointable_product->get_location_mode( 'edit' );

// Resource counts per venue (one pass; shown on location rows and picker).
$resource_counts = [];
if ( class_exists( 'WC_Appointments_Resource' ) ) {
	foreach ( WC_Appointments_Resource::get_resource_choices() as $rid => $_title ) {
		$lid = WC_Appointments_Resource_Data_Store::get_location_id( (int) $rid );
		if ( $lid > 0 ) {
			$resource_counts[ $lid ] = ( $resource_counts[ $lid ] ?? 0 ) + 1;
		}
	}
}

// Kind + resource counts once (picker options and rows share labels).
$by_id = [];
foreach ( $location_choices as $loc_id => $title ) {
	$loc_id    = (int) $loc_id;
	$loc_obj   = get_wc_appointments_location( $loc_id );
	$loc_kind  = $loc_obj ? $loc_obj->get_kind() : '';
	$res_count = (int) ( $resource_counts[ $loc_id ] ?? 0 );
	$kind_lbl  = WC_Appointments_Location::get_kind_label( $loc_kind );
	$res_lbl   = sprintf(
		/* translators: %d: number of resources at this location */
		_n( '%d resource', '%d resources', $res_count, 'woocommerce-appointments' ),
		$res_count
	);
	$by_id[ $loc_id ] = [
		'title'    => $title,
		'kind_key' => WC_Appointments_Location::KIND_ONLINE === $loc_kind
			? WC_Appointments_Location::KIND_ONLINE
			: WC_Appointments_Location::KIND_PHYSICAL,
		'opt'      => $title . ' (' . $kind_lbl . ', ' . $res_lbl . ')',
		'meta'     => $kind_lbl . ', ' . $res_lbl,
	];
}

// Assigned first (saved order), then unassigned A-Z, then missing.
$rows = [];
foreach ( $selected_ids as $selected_id ) {
	if ( isset( $by_id[ $selected_id ] ) ) {
		$rows[ $selected_id ] = $by_id[ $selected_id ];
	}
}
$unassigned = array_diff_key( $by_id, $rows );
uasort(
	$unassigned,
	static function ( array $a, array $b ): int {
		return strnatcasecmp( (string) $a['title'], (string) $b['title'] );
	}
);
$rows += $unassigned;
foreach ( $selected_ids as $selected_id ) {
	if ( ! isset( $by_id[ $selected_id ] ) ) {
		$rows[ $selected_id ] = [
			'title'    => '',
			'kind_key' => WC_Appointments_Location::KIND_PHYSICAL,
			'opt'      => '',
			'meta'     => '',
		];
	}
}

$is_fixed           = WC_Appointments_Location::is_fixed_mode( $mode );
$locations_heading  = $is_fixed ? __( 'Location', 'woocommerce-appointments' ) : __( 'Locations', 'woocommerce-appointments' );
$picker_placeholder = $is_fixed
	? __( 'Select a location', 'woocommerce-appointments' )
	: __( 'Select locations', 'woocommerce-appointments' );
$location_costs     = $appointable_product->get_location_costs( 'edit' );
?>
<div id="appointments_locations" class="woocommerce_options_panel panel wc-metaboxes-wrapper">

	<div class="options_group">
		<?php
		woocommerce_wp_text_input(
			[
				'id'          => '_wc_appointment_location_label',
				'placeholder' => __( 'Location', 'woocommerce-appointments' ),
				'label'       => __( 'Label', 'woocommerce-appointments' ),
				'value'       => $appointable_product->get_location_label( 'edit' ),
				'desc_tip'    => true,
				'description' => __( 'The label shown on the frontend if the location is customer selected.', 'woocommerce-appointments' ),
			]
		);
		woocommerce_wp_select(
			[
				'id'          => '_wc_appointment_location_mode',
				'label'       => __( 'Location', 'woocommerce-appointments' ),
				'value'       => $mode,
				'options'     => [
					'none'            => __( 'None', 'woocommerce-appointments' ),
					'fixed'           => __( 'Fixed, show name', 'woocommerce-appointments' ),
					'hidden'          => __( 'Fixed', 'woocommerce-appointments' ),
					'customer_choice' => __( 'Customer selected', 'woocommerce-appointments' ),
				],
				'desc_tip'    => true,
				'description' => __( 'None: no venue. Fixed, show name: one location in cart and emails. Fixed: one location, hidden from customers. Customer selected: shopper picks (all venues, or two or more you list).', 'woocommerce-appointments' ),
			]
		);
		$meeting_provider = $appointable_product->get_meeting_provider( 'edit' );
		$meeting_options  = class_exists( 'WC_Appointments_Meetings' )
			? WC_Appointments_Meetings::get_product_provider_options()
			: [
				'none'        => __( 'None', 'woocommerce-appointments' ),
				'google_meet' => __( 'Google Meet', 'woocommerce-appointments' ),
			];
		woocommerce_wp_select(
			[
				'id'          => '_wc_appointment_meeting_provider',
				'label'       => __( 'Video meeting', 'woocommerce-appointments' ),
				'value'       => $meeting_provider,
				'options'     => $meeting_options,
				'desc_tip'    => true,
				'description' => __( 'Google Meet creates a unique join link per booking (needs Google Calendar). None uses the location join link, if you set one.', 'woocommerce-appointments' ),
			]
		);
		?>
	</div>

	<div class="options_group" id="appointment_locations_list">
		<div class="wca-entity-picker">
			<div class="wca-entity-picker__head">
				<h3>
					<span class="wca-locations-list-title"><?php echo esc_html( $locations_heading ); ?></span>
					<?php echo wc_help_tip( esc_html__( 'Fixed / Fixed, show name: pick one. Customer selected: leave empty for all (A-Z), or pick two or more and drag rows to set order (first is the storefront default).', 'woocommerce-appointments' ) ); ?>
				</h3>
				<div class="wca-entity-picker__actions">
					<a class="wca-hub-ext" href="<?php echo esc_url( admin_url( 'edit.php?post_type=wca_location' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Manage Locations', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
					<a class="wca-hub-ext" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=wca_location' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Add Location', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
				</div>
			</div>
			<?php if ( $by_id ) : ?>
				<select
					id="add_location_id"
					class="wc-enhanced-select wca-entity-picker-select"
					data-list="#wca_location_list"
					data-placeholder="<?php echo esc_attr( $picker_placeholder ); ?>"
					data-placeholder-fixed="<?php echo esc_attr( __( 'Select a location', 'woocommerce-appointments' ) ); ?>"
					data-placeholder-customer="<?php echo esc_attr( __( 'Select locations', 'woocommerce-appointments' ) ); ?>"
				>
					<option value=""></option>
					<?php foreach ( $by_id as $loc_id => $loc ) : ?>
						<option value="<?php echo esc_attr( (string) $loc_id ); ?>" <?php disabled( in_array( (int) $loc_id, $selected_ids, true ) ); ?>>
							<?php echo esc_html( $loc['opt'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			<?php else : ?>
				<p class="description">
					<?php esc_html_e( 'Add a location first, then set Location to Fixed or Customer selected.', 'woocommerce-appointments' ); ?>
				</p>
			<?php endif; ?>

			<?php if ( $rows ) : ?>
				<div class="woocommerce_appointable_locations wc-metaboxes wca-entity-list" id="wca_location_list" data-entity="location" data-id-attr="data-location-id" data-picker="#add_location_id">
					<?php foreach ( $rows as $loc_id => $loc ) : ?>
						<?php
						$loc_id     = (int) $loc_id;
						$assigned   = in_array( $loc_id, $selected_ids, true );
						$is_missing = '' === $loc['title'];
						$name       = $is_missing
							? sprintf(
								/* translators: %d: location ID */
								__( 'Location #%d (missing)', 'woocommerce-appointments' ),
								$loc_id
							)
							: $loc['title'];
						$row_class = 'woocommerce_appointment_location wc-metabox closed' . ( $assigned ? ' is-assigned' : '' ) . ( $is_missing ? ' is-missing' : '' );
						$cost      = $location_costs[ $loc_id ] ?? '';
						?>
						<div
							class="<?php echo esc_attr( $row_class ); ?>"
							data-location-id="<?php echo esc_attr( (string) $loc_id ); ?>"
							data-kind="<?php echo esc_attr( $loc['kind_key'] ); ?>"
							<?php echo $assigned ? '' : ' hidden'; ?>
						>
							<h3>
								<strong>
									<span class="location_name"><?php echo esc_html( $name ); ?></span>
									<?php if ( ! $is_missing ) : ?>
										<span class="wca-entity-meta"><?php echo esc_html( $loc['meta'] ); ?></span>
									<?php endif; ?>
								</strong>
								<div class="handle-item" title="<?php esc_attr_e( 'Click to toggle', 'woocommerce-appointments' ); ?>"></div>
								<?php if ( ! $is_missing && current_user_can( 'edit_post', $loc_id ) ) : ?>
									<a href="<?php echo esc_url( get_edit_post_link( $loc_id, 'raw' ) ); ?>" target="_blank" rel="noopener noreferrer" class="edit_location wca-hub-ext"><?php esc_html_e( 'Edit', 'woocommerce-appointments' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
								<?php endif; ?>
								<button type="button" class="remove_appointment_location button" aria-label="<?php esc_attr_e( 'Remove', 'woocommerce-appointments' ); ?>">x</button>
								<input type="hidden" name="_wc_appointment_location_ids[]" value="<?php echo esc_attr( (string) $loc_id ); ?>" <?php disabled( ! $assigned ); ?> />
							</h3>
							<table cellpadding="0" cellspacing="0" class="wc-metabox-content">
								<tbody>
									<tr>
										<td>
											<label><?php esc_html_e( 'Additional Cost', 'woocommerce-appointments' ); ?>:</label>
											<input
												type="number"
												name="wca_location[<?php echo esc_attr( (string) $loc_id ); ?>][cost]"
												value="<?php echo '' !== $cost ? esc_attr( (string) $cost ) : ''; ?>"
												placeholder="0.00"
												step="0.01"
												<?php disabled( ! $assigned ); ?>
											/>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
