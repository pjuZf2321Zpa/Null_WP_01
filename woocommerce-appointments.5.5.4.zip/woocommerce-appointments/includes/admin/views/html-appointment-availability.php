<?php
/**
 * Product edit panel - availability options (hours stay in the Availability hub).
 *
 * @var WC_Product_Appointment $appointable_product Global; set by WC_Appointments_Admin::appointment_panels().
 */

defined( 'ABSPATH' ) || exit;

?>
<div id="appointments_availability" class="panel woocommerce_options_panel">
	<div class="options_group">
		<?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_* in hub helper.
		echo WC_Appointments_Admin_Availability_Hub::product_tab_hours_html( $appointable_product );
		?>
	</div>
	<div class="options_group show_if_appointment">
		<?php
		$availability_span = $appointable_product->get_availability_span( 'edit' );
		?>
		<p class="form-field _wc_appointment_availability_span_field">
			<label for="_wc_appointment_availability_span"><?php esc_html_e( 'Availability Check', 'woocommerce-appointments' ); ?></label>
			<select name="_wc_appointment_availability_span" id="_wc_appointment_availability_span" class="select short">
				<option value="" <?php selected( $availability_span, '' ); ?>><?php esc_html_e( 'All slots in availability range', 'woocommerce-appointments' ); ?></option>
				<option value="start" <?php selected( $availability_span, 'start' ); ?>><?php esc_html_e( 'The starting slot only', 'woocommerce-appointments' ); ?></option>
			</select>
			<?php echo wc_help_tip( esc_html__( '"All slots in availability range" requires every interval within the window to be free. "The starting slot only" checks availability at the start time only, allowing the appointment to extend past the rule window. Use starting slot for fixed departures where the trip fills the day.', 'woocommerce-appointments' ) ); ?>
		</p>
		<?php
		woocommerce_wp_checkbox(
			[
				'id'          => '_wc_appointment_availability_autoselect',
				'label'       => __( 'Auto-select?', 'woocommerce-appointments' ),
				'value'       => $appointable_product->get_availability_autoselect( 'edit' ) ? 'yes' : 'no',
				'description' => __( 'Prefills the booking form with the earliest slot.', 'woocommerce-appointments' ),
			],
		);

		woocommerce_wp_checkbox(
			[
				'id'          => '_wc_appointment_has_restricted_days',
				'value'       => $appointable_product->has_restricted_days() ? 'yes' : 'no',
				'label'       => __( 'Restrict start days?', 'woocommerce-appointments' ),
				'description' => __( 'Limits which weekdays customers can start on. Does not change open hours.', 'woocommerce-appointments' ),
			],
		);

		$days = array_map( 'intval', (array) $appointable_product->get_restricted_days() );
		$sow  = (int) get_option( 'start_of_week', 1 );
		global $wp_locale;
		echo '<div class="appointment-day-restriction wca-admin-checkbox-list">';
		for ( $i = 0; 7 > $i; $i++ ) {
			$d = ( $sow + $i ) % 7;
			printf(
				'<label class="wca-admin-checkbox-item"><input type="checkbox" class="checkbox" name="_wc_appointment_restricted_days[%1$d]" value="%1$d"%2$s> %3$s</label>',
				absint( $d ),
				checked( in_array( $d, $days, true ), true, false ),
				esc_html( $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $d ) ) )
			);
		}
		echo '</div>';
		?>
	</div>
</div>
