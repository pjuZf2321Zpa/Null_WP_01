<?php
/**
 * Staff Permissions Settings
 *
 * Adds staff permissions configuration to WooCommerce Appointments settings.
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Staff_Permissions_Settings class.
 */
class WC_Appointments_Admin_Staff_Permissions_Settings {

	/**
	 * Get translatable category labels (literal strings for translation extraction).
	 *
	 * @return array<string, mixed>
	 */
	private function get_translated_categories(): array {
		return [
			'calendar'     => __( 'Calendar & Appointments', 'woocommerce-appointments' ),
			'availability' => __( 'Availability', 'woocommerce-appointments' ),
			'products'     => __( 'Products', 'woocommerce-appointments' ),
			'orders'       => __( 'Orders', 'woocommerce-appointments' ),
			'customers'    => __( 'Customers', 'woocommerce-appointments' ),
			'data'         => __( 'Data & Reports', 'woocommerce-appointments' ),
		];
	}

	/**
	 * Get translatable permission labels/descriptions (literal strings for translation extraction).
	 *
	 * @return array<string, mixed>
	 */
	private function get_translated_permission_texts(): array {
		return [
			'view_calendar' => [
				'label'       => __( 'View Calendar', 'woocommerce-appointments' ),
				'description' => __( 'Access the appointment calendar showing their assigned appointments', 'woocommerce-appointments' ),
			],
			'view_appointments_list' => [
				'label'       => __( 'View Appointments List', 'woocommerce-appointments' ),
				'description' => __( 'Access the appointments list view filtered to their appointments', 'woocommerce-appointments' ),
			],
			'manage_appointment_status' => [
				'label'       => __( 'Change Appointment Status', 'woocommerce-appointments' ),
				'description' => __( 'Confirm, complete, or update appointment status', 'woocommerce-appointments' ),
			],
			'create_appointments' => [
				'label'       => __( 'Create Appointments', 'woocommerce-appointments' ),
				'description' => __( 'Manually create new appointments from the calendar (only for assigned products)', 'woocommerce-appointments' ),
			],
			'create_appointments_any' => [
				'label'       => __( 'Create Appointments for Any Product', 'woocommerce-appointments' ),
				'description' => __( 'Create appointments for other staff members or products without staff assignment', 'woocommerce-appointments' ),
			],
			'cancel_appointments' => [
				'label'       => __( 'Cancel Appointments', 'woocommerce-appointments' ),
				'description' => __( 'Cancel existing appointments (may trigger refunds)', 'woocommerce-appointments' ),
			],
			'manage_own_availability' => [
				'label'       => __( 'Manage Own Availability', 'woocommerce-appointments' ),
				'description' => __( 'Edit personal open hours and unavailable times in the Availability hub', 'woocommerce-appointments' ),
			],
			'manage_global_availability' => [
				'label'       => __( 'Manage General Availability', 'woocommerce-appointments' ),
				/* translators: "General" = default availability layer in the hub (not a physical shop). */
				'description' => __( 'Edit general hours and holidays in the Availability hub', 'woocommerce-appointments' ),
			],
			'manage_product_availability' => [
				'label'       => __( 'Manage Product Availability', 'woocommerce-appointments' ),
				'description' => __( 'Edit product open hours and unavailable times in the Availability hub', 'woocommerce-appointments' ),
			],
			'manage_location_availability' => [
				'label'       => __( 'Manage Location Availability', 'woocommerce-appointments' ),
				'description' => __( 'Edit venue / online location hours in the Availability hub', 'woocommerce-appointments' ),
			],
			'manage_resource_availability' => [
				'label'       => __( 'Manage Resource Availability', 'woocommerce-appointments' ),
				'description' => __( 'Edit room and equipment hours in the Availability hub', 'woocommerce-appointments' ),
			],
			'availability_set_appointable' => [
				'label'       => __( 'Set Available / Unavailable', 'woocommerce-appointments' ),
				'description' => __( 'Add open hours (Available). Without this, staff may only add closed / unavailable dates.', 'woocommerce-appointments' ),
			],
			'availability_rule_type_daterange' => [
				'label'       => __( 'Rule Type: Date Range with Time', 'woocommerce-appointments' ),
				'description' => __( 'Allow using the "Date range with time" rule type in addition to the basic "Date range".', 'woocommerce-appointments' ),
			],
			'availability_rule_type_recurring' => [
				'label'       => __( 'Rule Type: Recurring (Months / Weeks / Days)', 'woocommerce-appointments' ),
				'description' => __( 'Allow using month, week, and day-of-week recurring rule types.', 'woocommerce-appointments' ),
			],
			'availability_rule_type_time' => [
				'label'       => __( 'Rule Type: Time Ranges', 'woocommerce-appointments' ),
				'description' => __( 'Allow using recurring time and time-range rule types.', 'woocommerce-appointments' ),
			],
			'view_assigned_products' => [
				'label'       => __( 'View Assigned Products', 'woocommerce-appointments' ),
				'description' => __( 'See assigned products including pricing, duration, and capacity', 'woocommerce-appointments' ),
			],
			'manage_products' => [
				'label'       => __( 'Create & Edit Products', 'woocommerce-appointments' ),
				'description' => __( 'Create new appointment products and edit existing ones', 'woocommerce-appointments' ),
			],
			'manage_locations' => [
				'label'       => __( 'Manage Locations', 'woocommerce-appointments' ),
				'description' => __( 'Create and edit shop locations (venues and online)', 'woocommerce-appointments' ),
			],
			'manage_resources' => [
				'label'       => __( 'Manage Rooms & Resources', 'woocommerce-appointments' ),
				'description' => __( 'Create and edit shared resources (rooms, equipment)', 'woocommerce-appointments' ),
			],
			'view_customers' => [
				'label'       => __( 'View Customers', 'woocommerce-appointments' ),
				'description' => __( 'Access to view customer information from their appointments', 'woocommerce-appointments' ),
			],
			'view_all_customers' => [
				'label'       => __( 'View All Customers', 'woocommerce-appointments' ),
				'description' => __( 'View all customers, not just those who booked with this staff member', 'woocommerce-appointments' ),
			],
			'view_customer_history' => [
				'label'       => __( 'View Customer History', 'woocommerce-appointments' ),
				'description' => __( 'See past appointments and booking history for customers', 'woocommerce-appointments' ),
			],
			'contact_customers' => [
				'label'       => __( 'Contact Customers', 'woocommerce-appointments' ),
				'description' => __( 'View customer email and phone for direct communication', 'woocommerce-appointments' ),
			],
			'view_own_earnings' => [
				'label'       => __( 'View Earnings', 'woocommerce-appointments' ),
				'description' => __( 'See revenue generated from their appointments', 'woocommerce-appointments' ),
			],
			'export_appointments' => [
				'label'       => __( 'Export Appointments', 'woocommerce-appointments' ),
				'description' => __( 'Download their appointments as CSV or ICS file', 'woocommerce-appointments' ),
			],
			'view_orders' => [
				'label'       => __( 'View Orders', 'woocommerce-appointments' ),
				'description' => __( 'View orders related to their appointments', 'woocommerce-appointments' ),
			],
			'manage_orders' => [
				'label'       => __( 'Create & Edit Orders', 'woocommerce-appointments' ),
				'description' => __( 'Create new orders and edit existing ones', 'woocommerce-appointments' ),
			],
		];
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_filter( 'woocommerce_get_sections_appointments', [ $this, 'add_section' ] );
		add_filter( 'woocommerce_get_settings_appointments', [ $this, 'get_settings' ], 10, 2 );
		add_action( 'woocommerce_admin_field_staff_permissions_matrix', [ $this, 'render_permissions_matrix' ] );
		add_action( 'woocommerce_settings_save_appointments', [ $this, 'save_permissions_matrix' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_permissions_scripts' ] );

		// Default preset dropdown to 'standard' when no permissions have been configured.
		add_filter( 'option_wc_appointments_staff_permission_preset', [ $this, 'default_preset_value' ] );
	}

	/**
	 * Default the preset dropdown to 'standard' when no permissions are configured.
	 *
	 * @param mixed $value Current option value.
	 * @return string
	 */
	public function default_preset_value( $value ): string {
		if ( '' === $value || false === $value ) {
			$permissions = get_option( 'wc_appointments_staff_permissions', [] );

			// No permissions configured yet — default to standard.
			if ( empty( $permissions ) ) {
				return 'standard';
			}

			// Detect active preset by comparing current permissions against presets.
			foreach ( WC_Appointments_Staff_Permissions::PRESETS as $preset_key => $preset_perms ) {
				$match = true;
				foreach ( array_keys( WC_Appointments_Staff_Permissions::DEFAULTS ) as $perm_key ) {
					$is_enabled     = ! empty( $permissions[ $perm_key ] );
					$should_enabled = in_array( $perm_key, $preset_perms, true );
					if ( $is_enabled !== $should_enabled ) {
						$match = false;
						break;
					}
				}
				if ( $match ) {
					return $preset_key;
				}
			}
		}
		return (string) $value;
	}

	/**
	 * Add Staff Permissions section to Appointments settings.
	 *
	 * @param array<string, string> $sections Existing sections.
	 * @return array<string, mixed>
	 */
	public function add_section( array $sections ): array {
		$sections['staff_permissions'] = __( 'Staff Permissions', 'woocommerce-appointments' );
		return $sections;
	}

	/**
	 * Get settings for the Staff Permissions section.
	 *
	 * @param array<int, array<string, mixed>> $settings        Existing settings.
	 * @param string                           $current_section Current section.
	 * @return array<int, array<string, mixed>>
	 */
	public function get_settings( array $settings, string $current_section ): array {
		if ( 'staff_permissions' !== $current_section ) {
			return $settings;
		}

		return [
			[
				'title' => __( 'Global Staff Permissions', 'woocommerce-appointments' ),
				'type'  => 'title',
				'desc'  => __( 'Configure what staff members can access and manage. Some permissions depend on others being enabled.', 'woocommerce-appointments' ),
				'id'    => 'wc_appointments_staff_permissions_section',
			],

			[
				'title'   => __( 'Permission Preset', 'woocommerce-appointments' ),
				'desc'    => __( 'Quick-apply a permission preset. Selecting a preset will update all permissions below.', 'woocommerce-appointments' ),
				'id'      => 'wc_appointments_staff_permission_preset',
				'type'    => 'select',
				'options' => [
					''         => __( 'Custom', 'woocommerce-appointments' ),
					'minimal'  => __( 'Minimal – View calendar only', 'woocommerce-appointments' ),
					'standard' => __( 'Standard – Manage appointments & availability (recommended)', 'woocommerce-appointments' ),
					'full'     => __( 'Full – All permissions including analytics', 'woocommerce-appointments' ),
				],
				'default' => 'standard',
				'class'   => 'wc-enhanced-select',
			],

			[
				'type'      => 'staff_permissions_matrix',
				'id'        => 'wc_appointments_staff_permissions',
				// Prevent WC_Admin_Settings::save_fields() default case from overwriting this
				// option with only checked POST keys (wc_clean on the checkbox array).
				'is_option' => false,
			],

			[
				'type' => 'sectionend',
				'id'   => 'wc_appointments_staff_permissions_section',
			],
		];
	}

	/**
	 * Enqueue scripts and styles for permissions matrix UI.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_permissions_scripts( string $hook ): void {
		if ( 'woocommerce_page_wc-settings' !== $hook ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$section = isset( $_GET['section'] ) ? sanitize_text_field( wp_unslash( $_GET['section'] ) ) : '';

		if ( 'appointments' !== $tab || 'staff_permissions' !== $section ) {
			return;
		}

		wp_enqueue_style(
			'wca-staff-permissions-admin',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin-staff-permissions.css',
			[],
			WC_APPOINTMENTS_VERSION
		);

		wp_enqueue_script(
			'wca-staff-permissions-admin',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/admin-staff-permissions.js',
			[ 'jquery', 'wc-enhanced-select' ],
			WC_APPOINTMENTS_VERSION,
			true
		);

		wp_localize_script( 'wca-staff-permissions-admin', 'wcaPermissions', [
			'presets' => WC_Appointments_Staff_Permissions::PRESETS,
		] );
	}

	/**
	 * Render permissions matrix.
	 *
	 * @param array<string, mixed> $value Field config from WooCommerce settings API.
	 */
	public function render_permissions_matrix( array $value ): void {
		$permissions = get_option( 'wc_appointments_staff_permissions', [] );
		if ( empty( $permissions ) ) {
			// Default to standard preset permissions when none configured.
			$permissions = [];
			foreach ( array_keys( WC_Appointments_Staff_Permissions::DEFAULTS ) as $perm_key ) {
				$permissions[ $perm_key ] = in_array( $perm_key, WC_Appointments_Staff_Permissions::PRESETS['standard'], true ) ? 1 : 0;
			}
		}
		$dependencies = WC_Appointments_Staff_Permissions::get_dependencies();
		$categories   = $this->get_translated_categories();

		$defaults         = WC_Appointments_Staff_Permissions::DEFAULTS;
		$permission_texts = $this->get_translated_permission_texts();
		if ( ! WC_Appointments_Features::is_locations_resources_active() ) {
			foreach ( WC_Appointments_Staff_Permissions::LOCATIONS_RESOURCES_CAPS as $cap ) {
				unset( $defaults[ $cap ] );
			}
		}
		foreach ( $defaults as $perm_key => $perm_data ) {
			if ( isset( $permission_texts[ $perm_key ] ) ) {
				$defaults[ $perm_key ]['label']       = $permission_texts[ $perm_key ]['label'];
				$defaults[ $perm_key ]['description'] = $permission_texts[ $perm_key ]['description'];
			}
		}

		$permissions_by_category = [];
		foreach ( $defaults as $perm_key => $perm_data ) {
			$category = $perm_data['category'];
			$permissions_by_category[ $category ][ $perm_key ] = $perm_data;
		}

		$category_icons = [
			'calendar'     => 'dashicons-calendar-alt',
			'availability' => 'dashicons-clock',
			'products'     => 'dashicons-products',
			'orders'       => 'dashicons-cart',
			'customers'    => 'dashicons-groups',
			'data'         => 'dashicons-chart-bar',
		];

		$category_descriptions = [
			'calendar'     => __( 'Control access to the appointment calendar and what actions staff can take on appointments.', 'woocommerce-appointments' ),
			'availability' => __( 'Allow staff to manage their own working hours and availability rules.', 'woocommerce-appointments' ),
			'products'     => __( 'Control visibility of products assigned to staff.', 'woocommerce-appointments' ),
			'orders'       => __( 'Control access to order viewing and management capabilities.', 'woocommerce-appointments' ),
			'customers'    => __( 'Control access to customer information and booking history.', 'woocommerce-appointments' ),
			'data'         => __( 'Access to earnings, analytics, and data export features.', 'woocommerce-appointments' ),
		];
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<?php esc_html_e( 'Permissions', 'woocommerce-appointments' ); ?>
			</th>
			<td class="forminp">
				<div class="wca-permissions-wrapper">
					<div class="wca-permissions-header">
						<input type="text" id="wca-permissions-search" placeholder="<?php esc_attr_e( 'Search permissions...', 'woocommerce-appointments' ); ?>" class="regular-text">
						<div class="wca-permissions-actions">
							<button type="button" class="button wca-enable-all"><?php esc_html_e( 'Enable All', 'woocommerce-appointments' ); ?></button>
							<button type="button" class="button wca-disable-all"><?php esc_html_e( 'Disable All', 'woocommerce-appointments' ); ?></button>
						</div>
					</div>

					<div class="wca-permissions-accordion">
						<?php
						foreach ( $categories as $category_key => $category_title ) :
							$category_permissions = $permissions_by_category[ $category_key ] ?? [];
							if ( empty( $category_permissions ) ) {
								continue;
							}
							$icon_class = $category_icons[ $category_key ] ?? 'dashicons-admin-generic';
							?>
							<div class="wca-permission-category" data-category="<?php echo esc_attr( $category_key ); ?>">
								<div class="wca-category-header" role="button" tabindex="0" aria-expanded="false" aria-controls="wca-category-<?php echo esc_attr( $category_key ); ?>">
									<h3 class="wca-category-title">
										<span class="dashicons <?php echo esc_attr( $icon_class ); ?>"></span>
										<?php echo esc_html( $category_title ); ?>
									</h3>
									<span class="wca-category-count">0</span>
									<span class="wca-category-toggle dashicons dashicons-arrow-down-alt2"></span>
								</div>

								<div id="wca-category-<?php echo esc_attr( $category_key ); ?>" class="wca-category-content" aria-hidden="true">
									<div class="wca-category-description">
										<?php echo esc_html( $category_descriptions[ $category_key ] ?? '' ); ?>
									</div>
									<div class="wca-category-actions">
										<button type="button" class="button button-small wca-enable-all" data-category="<?php echo esc_attr( $category_key ); ?>">
											<?php esc_html_e( 'Enable All', 'woocommerce-appointments' ); ?>
										</button>
										<button type="button" class="button button-small wca-disable-all" data-category="<?php echo esc_attr( $category_key ); ?>">
											<?php esc_html_e( 'Disable All', 'woocommerce-appointments' ); ?>
										</button>
									</div>

										<?php
										foreach ( $category_permissions as $perm_key => $perm_data ) :
											$dep_keys   = isset( $dependencies[ $perm_key ] ) ? $dependencies[ $perm_key ] : [];
											$dep_labels = [];
											foreach ( $dep_keys as $dep_key ) {
												if ( isset( $defaults[ $dep_key ] ) ) {
													$dep_labels[] = $defaults[ $dep_key ]['label'];
												}
											}
											?>
											<div class="wca-permission-item" data-permission="<?php echo esc_attr( $perm_key ); ?>">
												<label class="wca-permission-label">
													<input
														type="checkbox"
														name="wc_appointments_staff_permissions[<?php echo esc_attr( $perm_key ); ?>]"
														value="1"
														class="wca-permission-checkbox"
														<?php checked( ! empty( $permissions[ $perm_key ] ) ); ?>
														<?php disabled( ! current_user_can( 'manage_options' ) ); ?>
													>
													<span class="wca-permission-title"><?php echo esc_html( $perm_data['label'] ); ?></span>
												</label>
												<div class="wca-permission-description"><?php echo esc_html( $perm_data['description'] ); ?></div>
												<?php if ( ! empty( $dep_labels ) ) : ?>
												<div class="wca-permission-dependency">
													<?php
													/* translators: %s: comma-separated list of required permission labels. */
													printf( esc_html__( 'Requires: %s', 'woocommerce-appointments' ), implode( ', ', array_map( 'esc_html', $dep_labels ) ) );
													?>
												</div>
												<?php endif; ?>
											</div>
										<?php endforeach; ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</td>
		</tr>
		<?php
	}

	/**
	 * Unslashed POST for staff-permissions save (WC admin options nonce verified).
	 *
	 * @return array<string, mixed>
	 */
	private function get_settings_post_data(): array {
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field; WC settings save verifies nonce.
	}

	/**
	 * Save permissions matrix.
	 */
	public function save_permissions_matrix(): void {
		$section_raw = filter_input( INPUT_GET, 'section' );
		$section     = is_string( $section_raw ) ? sanitize_text_field( wp_unslash( $section_raw ) ) : '';

		if ( 'staff_permissions' !== $section ) {
			return;
		}

		$posted = $this->get_settings_post_data();

		// Preset select only drives checkboxes in JS; persist the posted matrix.
		if ( isset( $posted['wc_appointments_staff_permissions'] ) && is_array( $posted['wc_appointments_staff_permissions'] ) ) {
			$defaults    = WC_Appointments_Staff_Permissions::DEFAULTS;
			$permissions = [];

			foreach ( array_keys( $defaults ) as $perm_key ) {
				$permissions[ $perm_key ] = isset( $posted['wc_appointments_staff_permissions'][ $perm_key ] ) ? 1 : 0;
			}

			update_option( 'wc_appointments_staff_permissions', $permissions );
		}

		update_option( 'wc_appointments_staff_permission_preset', '' );
	}
}

return new WC_Appointments_Admin_Staff_Permissions_Settings();
