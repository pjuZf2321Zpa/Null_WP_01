<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Calendar class.
 */
class WC_Appointments_Admin_Calendar {

	/**
	 * Stores events.
	 *
	 * @var array<int, WC_Appointment|WC_Appointments_Availability>
	 */
	private array $events = [];

	/**
	 * Sanitized GET/POST text request param.
	 *
	 * @param string $key     Request key.
	 * @param string $default Default when absent.
	 * @return string
	 */
	private static function request_text( string $key, string $default = '' ): string {
		$value = filter_input( INPUT_GET, $key );
		if ( null === $value || false === $value ) {
			$value = filter_input( INPUT_POST, $key );
		}
		if ( ! is_string( $value ) || '' === $value ) {
			return $default;
		}

		return sanitize_text_field( wp_unslash( $value ) );
	}

	/**
	 * Sanitized GET/POST integer request param.
	 *
	 * @param string $key     Request key.
	 * @param int    $default Default when absent.
	 * @return int
	 */
	private static function request_absint( string $key, int $default = 0 ): int {
		$value = filter_input( INPUT_GET, $key, FILTER_VALIDATE_INT );
		if ( false === $value || null === $value ) {
			$value = filter_input( INPUT_POST, $key, FILTER_VALIDATE_INT );
		}

		return false !== $value && null !== $value ? abs( (int) $value ) : $default;
	}

	/**
	 * Calendar view slug from request or default.
	 * @param list<string> $allowed
	 */
	private static function request_view( string $default, array $allowed = [ 'day', 'week', 'month', 'staff' ] ): string {
		$view = self::request_text( 'view', $default );

		return in_array( $view, $allowed, true ) ? $view : ( in_array( $default, $allowed, true ) ? $default : 'week' );
	}

	/**
	 * Output the calendar view
	 */
	public function output(): void {
		$filter_view  = apply_filters( 'woocommerce_appointments_calendar_view', 'week' );
		$user_view    = get_user_meta( get_current_user_id(), 'calendar_view', true );
		$default_view = $user_view ?: $filter_view;
		$view         = self::request_view( $default_view );
		$react_mode   = (bool) apply_filters( 'wc_appointments_admin_enable_react_calendar', true );
		$legacy_toggle = get_user_meta( get_current_user_id(), 'wc_appointments_legacy_calendar', true );
		if ( '1' === $legacy_toggle ) {
			$react_mode = false;
		}
		$staff_list = WC_Appointments_Admin::get_appointment_staff();

		$product_filter = self::request_absint( 'filter_appointable_product' );
		$staff_filter   = self::request_absint( 'filter_appointable_staff' );

		// Override to only show appointments for current staff member.
		if ( ! current_user_can( 'manage_others_appointments' ) ) {
			$staff_filter = get_current_user_id();
		}

		// Update calendar view seletion.
		$request_view = self::request_text( 'view' );
		if ( '' !== $request_view ) {
			update_user_meta( get_current_user_id(), 'calendar_view', sanitize_key( $request_view ) );
		}

		if ( $react_mode ) {
			echo '<div class="wrap woocommerce"><hr class="wp-header-end" /><div id="wca-react-calendar-root"></div></div>';
			return;
		}

		// No additional warning on page; the Screen Options label carries the deprecation text.

		if ( in_array( $view, [ 'day', 'staff' ], true ) ) {
			$day           = self::request_text( 'calendar_day', date_i18n( 'Y-m-d' ) );
			$day_formatted = date( 'Y-m-d', strtotime( $day ) );
			$prev_day      = date( 'Y-m-d', strtotime( '-1 day', strtotime( $day ) ) );
			$next_day      = date( 'Y-m-d', strtotime( '+1 day', strtotime( $day ) ) );

			$args_filters = [
				'strict'   => true,
				'order_by' => 'start_date',
				'order'    => 'ASC',
			];

			$this->events = WC_Appointments_Availability_Data_Store::get_events_in_date_range(
				strtotime( 'midnight', strtotime( $day ) ),
				strtotime( 'midnight +1 day', strtotime( $day ) ),
				$product_filter,
				$staff_filter,
				false,
				$args_filters,
			);
		} elseif ( 'week' === $view ) {
			$day           = self::request_text( 'calendar_day', date_i18n( 'Y-m-d' ) );
			$day_formatted = date( 'Y-m-d', strtotime( $day ) );
			$week          = date_i18n( 'w', strtotime( $day ) );
			$start_of_week = abs( (int) get_option( 'start_of_week', 1 ) );
			$week_start    = strtotime( "previous sunday +{$start_of_week} day", strtotime( $day ) );
			// Use midnight of the day after the week ends to ensure appointments spanning midnight are included
			$week_end       = strtotime( '+1 week', $week_start );
			$week_formatted = date_i18n( wc_appointments_date_format(), $week_start ) . ' &mdash; ' . date_i18n( wc_appointments_date_format(), strtotime( '-1 day', $week_end ) );
			$prev_week      = date( 'Y-m-d', strtotime( '-1 week', strtotime( $day ) ) );
			$next_week      = date( 'Y-m-d', strtotime( '+1 week', strtotime( $day ) ) );

			#$prev_day = date_i18n( wc_appointments_date_format(), strtotime( '-1 day', strtotime( $day ) ) );
			#print '<pre>'; print_r( $_REQUEST ); print '</pre>';

			$args_filters = [
				'strict'   => true,
				'order_by' => 'start_date',
				'order'    => 'ASC',
			];

			$this->events = WC_Appointments_Availability_Data_Store::get_events_in_date_range(
				$week_start,
				$week_end,
				$product_filter,
				$staff_filter,
				false,
				$args_filters,
			);
		} else {
			$month = self::request_absint( 'calendar_month', (int) date_i18n( 'n' ) );
			$year  = self::request_absint( 'calendar_year', (int) date_i18n( 'Y' ) );

			if ( $year < ( (int) date_i18n( 'Y' ) - 10 ) || 2100 < $year ) {
				$year = date_i18n( 'Y' );
			}

			if ( 12 < $month ) {
				$month = 1;
				$year++;
			}

			if ( 1 > $month ) {
				$month = 12;
				$year--;
			}

			$start_of_week = abs( (int) get_option( 'start_of_week', 1 ) );
			$last_day      = date( 't', strtotime( "$year-$month-01" ) );
			$start_date_w  = abs( (int) date( 'w', strtotime( "$year-$month-01" ) ) );
			$end_date_w    = abs( (int) date( 'w', strtotime( "$year-$month-$last_day" ) ) );

			// Calc day offset
			$day_offset = $start_date_w - $start_of_week;
			$day_offset = 0 <= $day_offset ? $day_offset : 7 - abs( $day_offset );

			// Calc end day offset
			$end_day_offset = 7 - ( $last_day % 7 ) - $day_offset;
			$end_day_offset = 0 <= $end_day_offset && 7 > $end_day_offset ? $end_day_offset : 7 - abs( $end_day_offset );

			// We want to get the last minute of the day, so we will go forward one day to midnight and subtract a min
			$end_day_offset += 1;

			$start_time = strtotime( "-{$day_offset} day", strtotime( "$year-$month-01" ) );
			// Use midnight of the day after the last day shown to ensure appointments spanning midnight are included
			$end_time = strtotime( "+{$end_day_offset} day", strtotime( "$year-$month-$last_day" ) );

			$args_filters = [
				'strict'   => true,
				'order_by' => 'start_date',
				'order'    => 'ASC',
			];

			$this->events = WC_Appointments_Availability_Data_Store::get_events_in_date_range(
				$start_time,
				$end_time,
				$product_filter,
				$staff_filter,
				false,
				$args_filters,
			);
		}

		include __DIR__ . '/views/html-calendar-' . $view . '.php';
		include __DIR__ . '/views/html-calendar-dialog.php';
	}

	/**
	 * List appointments for a day
	 *
	 * @param int    $day
	 * @param int    $month
	 * @param int    $year
	 * @param mixed      $list
	 * @param int|string $staff_id
	 * @return void
	 */
	public function list_events( $day, $month, $year, $list = 'by_time', $staff_id = '' ): void {
		$date_start = strtotime( "$year-$month-$day midnight" ); // Midnight today.
		$date_end   = strtotime( "$year-$month-$day tomorrow" ); // Midnight next day.

		foreach ( $this->events as $event ) {
			$event_type       = is_a( $event, 'WC_Appointment' ) ? 'appointment' : 'availability';
			$event_is_all_day = $event->is_all_day();
			// Get start and end timestamps.
			if ( 'appointment' === $event_type ) {
				$event_start = $event->get_start();
				$event_end   = $event->get_end();
			} else {
				$range = $event->get_time_range_for_date( $date_start );
				if ( is_null( $range ) ) {
					continue;
				}
				$event_start      = $range['start'];
				$event_end        = $range['end'];
				$event_is_all_day = false; #Set all availability to be displayed as hourly.
			}

			if ( 'all_day' === $list && $event_is_all_day && $event_start < $date_end && $event_end > $date_start ) {
				if ( $staff_id && 'appointment' === $event_type ) {
					$staff_ids     = $event->get_staff_ids();
					$staff_ids     = wc_appointments_normalize_staff_ids( $staff_ids );
					$is_unassigned = empty( $staff_ids ) || ( count( $staff_ids ) === 1 && empty( $staff_ids[0] ) );
					$creator_id    = $event->get_creator_id();
					$is_creator    = $creator_id && ( (int) $staff_id === $creator_id );

					if ( in_array( $staff_id, $staff_ids ) || $is_creator ) {
						$this->event_card( $event, $event_start, $event_end, $list = 'all_day' );
					} elseif ( $is_unassigned && 'unassigned' === $staff_id ) {
						$this->event_card( $event, $event_start, $event_end, $list = 'all_day' );
					}
				} else {
					$this->event_card( $event, $event_start, $event_end, $list = 'all_day' );
				}
			} elseif ( 'by_time' === $list && ! $event_is_all_day && $event_start < $date_end && $event_end > $date_start ) {
				if ( $staff_id && 'appointment' === $event_type ) {
					$staff_ids     = $event->get_staff_ids();
					$staff_ids     = wc_appointments_normalize_staff_ids( $staff_ids );
					$is_unassigned = empty( $staff_ids ) || ( count( $staff_ids ) === 1 && empty( $staff_ids[0] ) );
					$creator_id    = $event->get_creator_id();
					$is_creator    = $creator_id && ( (int) $staff_id === $creator_id );
					if ( in_array( $staff_id, $staff_ids ) || $is_creator ) {
						$this->event_card( $event, $event_start, $event_end, $list = 'by_time' );
					} elseif ( $is_unassigned && 'unassigned' === $staff_id ) {
						$this->event_card( $event, $event_start, $event_end, $list = 'by_time' );
					}
				} else {
					$this->event_card( $event, $event_start, $event_end, $list = 'by_time' );
				}
			} elseif ( 'by_month' === $list && $event_start < $date_end && $event_end > $date_start ) {
				if ( $staff_id && 'appointment' === $event_type ) {
					$staff_ids     = $event->get_staff_ids();
					$staff_ids     = wc_appointments_normalize_staff_ids( $staff_ids );
					$is_unassigned = empty( $staff_ids ) || ( count( $staff_ids ) === 1 && empty( $staff_ids[0] ) );
					$creator_id    = $event->get_creator_id();
					$is_creator    = $creator_id && ( (int) $staff_id === $creator_id );
					if ( in_array( $staff_id, $staff_ids ) || $is_creator ) {
						$this->event_card( $event, $event_start, $event_end, $list = 'by_month' );
					} elseif ( $is_unassigned && 'unassigned' === $staff_id ) {
						$this->event_card( $event, $event_start, $event_end, $list = 'by_month' );
					}
				} else {
					$this->event_card( $event, $event_start, $event_end, $list = 'by_month' );
				}
			}
		}
	}

	/**
	 * Event card.
	 * @param mixed $event
	 * @param mixed $event_end
	 * @param mixed $event_start
	 * @param mixed $list
	 */
	public function event_card( $event, $event_start, $event_end, $list = '' ): void {
		// Convert timestamps to admin timezone for display.
		$display_start = $event_start;
		$display_end   = $event_end;
		if ( class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::admin_has_different_timezone() ) {
			$display_start = WC_Appointments_Timezone_Helper::convert_to_admin_timezone( $event_start );
			$display_end   = WC_Appointments_Timezone_Helper::convert_to_admin_timezone( $event_end );
		}

		// Event defaults.
		$datarray               = [];
		$datarray['id']         = $event->get_id();
		$datarray['classes']    = [ 'event_card' ];
		$datarray['type']       = is_a( $event, 'WC_Appointment' ) ? 'appointment' : 'availability';
		$datarray['start']      = $display_start;
		$datarray['end']        = $display_end;
		$datarray['is_all_day'] = $event->is_all_day();
		$datarray['when']       = wc_appointment_format_timestamp( $datarray['start'], $datarray['is_all_day'] ) . ' &mdash; ' . wc_appointment_format_timestamp( $datarray['end'], $datarray['is_all_day'] );
		if ( date_i18n( 'ymd', $datarray['start'] ) === date_i18n( 'ymd', $datarray['start'] ) && ! $datarray['is_all_day'] ) {
			$datarray['when'] = wc_appointment_format_timestamp( $datarray['start'], $datarray['is_all_day'] ) . ' &mdash; ' . date_i18n( wc_appointments_time_format(), $datarray['end'] );
		}
		$datarray['duration']       = WC_Appointment_Duration::calculate_minutes( $event_start, $event_end ); // Use original timestamps for duration.
		$datarray['duration_unit']  = WC_Appointments_Constants::DURATION_MINUTE;
		$datarray['event_customer'] = '';
		$datarray['event_status']   = '';
		$datarray['event_name']     = '';
		$datarray['addons']         = '';
		$datarray['event_datetime'] = $datarray['is_all_day'] ? '' : date_i18n( wc_appointments_time_format(), $datarray['start'] );
		if ( 'all_day' === $list ) {
			$datarray['start_time'] = date( 'Y-m-d', $datarray['start'] );
			$datarray['end_time']   = date( 'Y-m-d', $datarray['start'] );
		} else {
			$datarray['start_time'] = date( 'Hi', $datarray['start'] );
			$datarray['end_time']   = date( 'Hi', $datarray['end'] );
		}
		if ( 'appointment' === $datarray['type'] ) {
			$event_product        = $event->get_product();
			$datarray['status']   = $event->get_status();
			$datarray['order_id'] = wp_get_post_parent_id( $event->get_id() );
			$datarray['staff_id'] = $event->get_staff_ids();
			if ( ! is_array( $datarray['staff_id'] ) ) {
				$datarray['staff_id'] = [ $datarray['staff_id'] ];
			}
			$datarray['staff_name']    = $event->get_staff_members( true ) ? htmlentities( $event->get_staff_members( true, true ) ) : '';
			$datarray['duration']      = WC_Appointment_Duration::calculate_minutes( $datarray['start'], $datarray['end'] );
			$datarray['duration_unit'] = $event->get_duration_unit();
			$datarray['event_qty']     = $event->get_qty();
			$datarray['order_id']      = wp_get_post_parent_id( $event->get_id() );
			if ( $datarray['order_id'] ) {
				$order                    = wc_get_order( $datarray['order_id'] );
				$datarray['order_status'] = is_a( $order, 'WC_Order' ) ? $order->get_status() : '';
			}
			$datarray['event_cost'] = esc_html( wc_price( (float) $event->get_cost() ) );
			if ( $datarray['order_id'] ) {
				$order                  = wc_get_order( $datarray['order_id'] );
				$datarray['event_cost'] = is_a( $order, 'WC_Order' ) ? esc_html( wc_price( (float) $order->get_total() ) ) : $datarray['event_cost'];
			}
			$datarray['event_status']       = $event->get_status();
			$datarray['classes'][]          = $datarray['event_status'];
			$datarray['event_status_label'] = wc_appointments_get_status_label( $event->get_status() );
			$customer_status                = $event->get_customer_status();
			$datarray['customer_status']    = $customer_status ?: 'expected';
			$datarray['classes'][]          = $datarray['customer_status'];
			$customer                       = $event->get_customer();
			if ( $customer ) {
				$datarray['event_customer'] = $customer->full_name;
				$datarray['customer_name']  = $customer->full_name;
				$datarray['customer_phone'] = preg_replace( '/\s+/', '', $customer->phone );
				$datarray['customer_email'] = $customer->email;
				if ( $customer->user_id ) {
					$datarray['customer_id']     = $customer->user_id;
					$datarray['customer_url']    = get_edit_user_link( $customer->user_id );
					$datarray['customer_avatar'] = get_avatar_url(
						$customer->user_id,
						[
							'size'    => 110,
							'default' => 'mm',
						],
					);
				}
			}
			$datarray['product_id']    = $event->get_product_id();
			$datarray['product_title'] = is_object( $event_product ) ? $event_product->get_title() : '';
			$datarray['addons']        = esc_html( $event->get_addons() );
			$datarray['location_id']   = $event->get_location_id();
			$datarray['location_display'] = $event->get_location_display();
			$datarray['resource_allocations'] = $event->get_resource_allocations();
			$datarray['resource_display']     = $event->get_resource_display();
			$datarray['edit_link']     = esc_url( admin_url( 'post.php?post=' . $event->get_id() . '&action=edit' ) );
			$datarray['color']         = is_object( $event_product ) && $event_product->get_cal_color() ? $event_product->get_cal_color() : '#0073aa';
		} else {
			$is_rrule    = 'rrule' === $event->get_range_type();
			$is_google   = ! empty( $event->get_event_id() );
			$is_all_day  = false === strpos( $event->get_from_range(), ':' );
			$rrule_str   = wc_appointments_esc_rrule( $event->get_rrule(), $is_all_day );
			$date_format = $is_all_day ? 'Y-m-d' : 'Y-m-d g:i A';
			$from_date   = new WC_DateTime( $event->get_from_range() );
			$to_date     = new WC_DateTime( $event->get_to_range() );
			$timezone    = new DateTimeZone( wc_timezone_string() );
			$from_date->setTimezone( $timezone );
			$to_date->setTimezone( $timezone );
			$human_readable_options = [
				'date_formatter' => fn($date) => $date->format( $date_format ),
				'locale'         => 'en',
			];
			$datarray['event_name'] = empty( $event->get_title() ) ? '' : $event->get_title() . ' - ';
			if ( $is_google ) {
				if ( $is_rrule ) {
					$datarray['event_name'] .= '<small>' . esc_html__( 'Google Recurring Event', 'woocommerce-appointments' ) . '</small>';
				} else {
					$datarray['event_name'] .= '<small>' . esc_html__( 'Google Event', 'woocommerce-appointments' ) . '</small>';
				}
			}
			if ( $is_rrule ) {
				$rset             = new \RRule\RSet( $rrule_str, $is_all_day ? $from_date->format( $date_format ) : $from_date );
				$datarray['when'] = esc_html__( 'Repeating ', 'woocommerce-appointments' );
				foreach ( $rset->getRRules() as $rrule ) {
					$datarray['when'] .= esc_html( $rrule->humanReadable( $human_readable_options ) );
				}
				if ( $rset->getExDates() ) {
					$datarray['when'] .= esc_html__( ', except ', 'woocommerce-appointments' );
					$datarray['when'] .= esc_html(
						implode(
							' and ',
							array_map(
								fn($date) => $date->format( $date_format ),
								$rset->getExDates(),
							),
						),
					);
				}
				$datarray['duration'] = '';
			}
			if ( $is_all_day ) {
				$datarray['duration']       = '';
				$datarray['event_datetime'] = '';
			}
			$datarray['edit_link'] = esc_url( admin_url( 'admin.php?page=wc-settings&tab=appointments&view=synced' ) );
			$datarray['color']     = '#555';
		}

		// Card -data attributes.
		$card_data_attr = '';
		foreach ( $datarray as $attribute => $value ) {
			if ( is_array( $value ) ) {
				$attrs = '';
				foreach ( $value as $attr_key => $attr_val ) {
					$attrs .= "{$attr_key}: {$attr_val};";
				}
				$value = $attrs;
			} else {
				// Data attributes are read by JS via .attr(); keep them plain text.
				$value = wp_strip_all_tags( (string) $value );
			}

			$card_data_attr .= 'data-' . esc_attr( $attribute ) . '="' . esc_attr( (string) $value ) . '" ';
		}
		$card_data_html = apply_filters( 'woocommerce_appointments_calendar_single_card_data', $card_data_attr, $datarray, $event );

		// Card style.
		$calendar_scale = apply_filters( 'woocommerce_appointments_calendar_view_day_scale', 60 );
		$event_top      = ( ( intval( substr( $datarray['start_time'], 0, 2 ) ) * 60 ) + intval( substr( $datarray['start_time'], -2 ) ) ) / 60 * $calendar_scale;
		$card_style     = '';
		if ( 'by_time' === $list ) {
			$duration_minutes = WC_Appointment_Duration::calculate_minutes( $datarray['start'], $datarray['end'] );
			$height           = intval( ( $duration_minutes / 60 ) * $calendar_scale );
			$card_style      .= ' background: ' . $datarray['color'] . '; top: ' . $event_top . 'px; height: ' . $height . 'px;';
		} else {
			$card_style .= ' background: ' . $datarray['color'];
		}

		// Build card variables.
		$card_title     = __( 'View / Edit', 'woocommerce-appointments' );
		$card_classes   = implode( ' ', $datarray['classes'] );
		$card_edit_link = $datarray['edit_link'];
		#$card_header     = $datarray['event_datetime'] ? '<strong class="event_datetime">' . $datarray['event_datetime'] . '</strong>' : '';
		$card_header     = $datarray['event_customer'] ? '<strong class="event_customer status-' . esc_attr( $datarray['customer_status'] ) . '">' . esc_html( $datarray['event_customer'] ) . '</strong>' : '';
		$card_content_li = '';
		if ( '' !== $datarray['event_datetime'] && '0' !== $datarray['event_datetime'] ) {
			$card_content_li .= '<li class="event_datetime">' . esc_html( $datarray['event_datetime'] ) . '</li>';
		} elseif ( '' !== $datarray['event_name'] && '0' !== $datarray['event_name'] ) {
			$card_content_li .= '<li class="event_availability">' . wp_kses_post( $datarray['event_name'] ) . '</li>';
		}
		if ( $datarray['event_status'] && $datarray['event_status_label'] ) {
			$card_content_li .= '<li class="event_status status-' . esc_attr( $datarray['event_status'] ) . '" data-tip="' . esc_attr( wc_sanitize_tooltip( $datarray['event_status_label'] ) ) . '"></li>';
		}

		// Build card html.
		$card_html  = '<div class="' . esc_attr( $card_classes ) . '" title="' . esc_attr( $card_title ) . '" ' . $card_data_html . ' style="' . esc_attr( $card_style ) . '">';
		$card_html .= '<a href="' . esc_url( $card_edit_link ) . '">';
		$card_html .= $card_header;
		$card_html .= '<ul>';
		$card_html .= $card_content_li;
		$card_html .= '</ul>';
		$card_html .= '</a>';
		$card_html .= '</div>';

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Card fields use esc_* at build; wp_kses_post strips data-* the legacy JS needs.
		echo apply_filters( 'woocommerce_appointments_calendar_view_single_card', $card_html, $datarray, $event );
	}

	/**
	 * Filters staff for narrowing search
	 * @return mixed[]
	 */
	public function staff_filters(): array {
		$filters = [];

		// Only show staff filter if current user can see other staff's appointments.
		if ( ! current_user_can( 'manage_others_appointments' ) ) {
			return $filters;
		}

		$staff = WC_Appointments_Admin::get_appointment_staff();

		foreach ( $staff as $staff_member ) {
			$filters[ $staff_member->ID ] = $staff_member->display_name;
		}

		return $filters;
	}

	/**
	 * Enqueue calendar scripts and styles for React calendar mode.
	 *
	 * Handles script registration, localization, and configuration for the admin calendar.
	 * This method is called from WC_Appointments_Admin_Menus::admin_scripts().
	 */
	public static function enqueue_react_calendar_scripts(): void {
		add_action( 'in_admin_header', static function (): void {
			remove_all_actions( 'admin_notices' );
			remove_all_actions( 'all_admin_notices' );
		}, 1000 );

		// Load calendar class if not already loaded
		if ( ! class_exists( 'WC_Appointments_Admin_Calendar' ) ) {
			require_once __DIR__ . '/class-wc-appointments-admin-calendar.php';
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script( 'wp-element' );
		// FullCalendar v6 global JS + CSS
		wp_enqueue_script( 'fullcalendar-global' );
		wp_enqueue_script( 'fullcalendar-locales' );
		wp_enqueue_script( 'wc_appointments_timezone_utils_js' );
		// React calendar styles moved to assets/css/admin.scss
		$script_handle = 'wca-admin-calendar-react';
		wp_register_script(
			$script_handle,
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/appointment-admin-calendar' . $suffix . '.js',
			[ 'wp-element', 'fullcalendar-global', 'wc_appointments_timezone_utils_js' ],
			WC_APPOINTMENTS_VERSION,
			true,
		);

		// Build months arrays using user's locale for admin
		$months_full    = [];
		$months_short   = [];
		$current_locale = function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();

		// Use date_i18n with locale switching for proper month names
		$original_locale = get_locale();
		if ( function_exists( 'switch_to_locale' ) && $current_locale !== $original_locale ) {
			switch_to_locale( $current_locale );
		}

		for ( $i = 1; 12 >= $i; $i++ ) {
			$timestamp      = mktime( 0, 0, 0, $i, 1, 2020 );
			$months_full[]  = date_i18n( 'F', $timestamp );
			$months_short[] = date_i18n( 'M', $timestamp );
		}

		// Restore original locale
		if ( function_exists( 'restore_current_locale' ) && $current_locale !== $original_locale ) {
			restore_current_locale();
		}

		// Build currency symbols map
		$symbols_map = [];
		if ( function_exists( 'get_woocommerce_currencies' ) ) {
			foreach ( get_woocommerce_currencies() as $code => $name ) {
				$symbols_map[ $code ] = html_entity_decode( get_woocommerce_currency_symbol( $code ), ENT_NOQUOTES, 'UTF-8' );
			}
		}

		$locale_bcp47 = str_replace( '_', '-', $current_locale );

		// Preload appointments server-side for instant calendar rendering
		// Use saved user preference if no view specified in URL
		$filter_view    = apply_filters( 'woocommerce_appointments_calendar_view', 'week' );
		$user_view      = get_user_meta( get_current_user_id(), 'calendar_view', true );
		$default_view   = $user_view ?: $filter_view;
		$initial_view   = self::request_view( $default_view, [ 'week', 'day', 'month', 'list' ] );
		$initial_date   = self::request_text( 'calendar_day' );
		$product_filter = self::request_absint( 'filter_appointable_product' );
		$staff_filter   = self::request_absint( 'filter_appointable_staff' );

		// Override to only show appointments for current staff member
		if ( ! current_user_can( 'manage_others_appointments' ) ) {
			$staff_filter = get_current_user_id();
		}

		// Only pass initialStaffId to JavaScript if there's a valid staff filter
		$initial_staff_id = $staff_filter > 0 ? $staff_filter : '';

		$preloaded_appointments = self::get_preloaded_appointments(
			$initial_view,
			$initial_date,
			$product_filter,
			$staff_filter,
		);

		// Get site timezone for comparison with customer timezones
		$site_timezone = class_exists( 'WC_Appointments_Timezone_Helper' )
			? WC_Appointments_Timezone_Helper::get_site_timezone_string()
			: wc_timezone_string();

		// Get admin user's timezone for display (staff members may have different timezone from site).
		// When timezone display is disabled via filter, use site timezone and no short name so the view modal does not show timezone.
		$show_admin_timezone = class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() );
		$admin_user_timezone = $site_timezone;
		if ( $show_admin_timezone ) {
			$admin_user_timezone = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
		}

		// Calculate timezone offsets in minutes for JS (positive = ahead of UTC)
		$admin_tz_offset_minutes = 0;
		$site_tz_offset_minutes  = 0;
		try {
			$now = new DateTime( 'now' );

			$admin_tz_obj            = new DateTimeZone( $admin_user_timezone );
			$admin_tz_offset_minutes = (int) ( $admin_tz_obj->getOffset( $now ) / 60 );

			$site_tz_obj            = new DateTimeZone( $site_timezone );
			$site_tz_offset_minutes = (int) ( $site_tz_obj->getOffset( $now ) / 60 );
		} catch ( Exception $e ) {
			// Fallback to gmt_offset
			$gmt_offset              = (int) ( get_option( 'gmt_offset', 0 ) * 60 );
			$admin_tz_offset_minutes = $gmt_offset;
			$site_tz_offset_minutes  = $gmt_offset;
		}

		// Build configuration array
		$config = [
			'restUrl'               => esc_url_raw( rest_url() ),
			'nonce'                 => wp_create_nonce( 'wp_rest' ),
			// Full admin calendar screen (panel create AJAX suppresses post-create redirect unless opted in via filter).
			'adminCalendarPage'     => true,
			'adminPost'             => admin_url( 'post.php' ),
			'ajaxUrl'               => admin_url( 'admin-ajax.php' ),
			'viewNonce'             => wp_create_nonce( 'wc_appointments_calendar_view' ),
			'blogId'                => get_current_blog_id(), // Site-specific identifier for multisite localStorage keys
			'initialView'           => $initial_view,
			'initialDate'           => $initial_date,
			'initialStaffId'        => $initial_staff_id, // Pass initial staff filter to JavaScript
			'preloadedAppointments' => $preloaded_appointments,
			'calendarPanelFields'   => WC_Appointments_REST_V2_Calendar_Controller::PANEL_FIELDS,
			'excludedStatuses'      => WC_Appointment_Data_Store::get_calendar_excluded_statuses(),
			'canManageOthers'       => current_user_can( 'manage_others_appointments' ),
			'canCreateAppointments' => ! class_exists( 'WC_Appointments_Staff_Permissions' )
				|| ! WC_Appointments_Staff_Permissions::is_staff_user( get_current_user_id() )
				|| WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'create_appointments' ),
			'addAppointmentUrl'     => admin_url( 'edit.php?post_type=wc_appointment&page=add_appointment' ),
			'staffPermissions'      => WC_Appointments_Staff_Permissions::admin_ui_flags(),
			'current_user'          => [
				'id'           => get_current_user_id(),
				'login'        => wp_get_current_user()->user_login,
				'roles'        => wp_get_current_user()->roles,
				'capabilities' => wp_get_current_user()->allcaps,
			],
			'is_staff'              => current_user_can( 'manage_woocommerce' ) || in_array( 'shop_staff', wp_get_current_user()->roles ) || in_array( 'wc_appointment_staff', wp_get_current_user()->roles ),
			'dateFormat'            => wc_appointments_date_format(),
			'timeFormat'            => wc_appointments_time_format(),
			'locale'                => $locale_bcp47,
			'firstDay'              => (int) get_option( 'start_of_week' ),
			'monthsFull'            => $months_full,
			'monthsShort'           => $months_short,
			'siteTimezone'          => $site_timezone,
			'siteTimezoneOffset'    => $site_tz_offset_minutes, // Site timezone offset in minutes
			'adminTimezone'         => $admin_user_timezone, // Staff member's timezone for display
			'adminTimezoneHtml'     => class_exists( 'WC_Appointments_Timezone_Helper' )
				? WC_Appointments_Timezone_Helper::build_timezone_indicator_html( $admin_user_timezone )
				: '',
			'adminTimezoneOffset'   => $admin_tz_offset_minutes, // Offset in minutes for JS conversion
			'showTimezoneContext'   => $show_admin_timezone, // Whether to show timezone context abbrs in modal
			// Store currency for panel create footer price overrides (matches creation modal behaviour)
			'currency'              => get_woocommerce_currency(),
			'sseRetryMs'            => WC_Appointments_SSE::get_retry_ms(),
			'i18n'                  => [
				'product'                             => __( 'Product', 'woocommerce-appointments' ),
				'staff'                               => __( 'Staff', 'woocommerce-appointments' ),
				'when'                                => __( 'When', 'woocommerce-appointments' ),
				'duration'                            => __( 'Duration', 'woocommerce-appointments' ),
				'addons'                              => __( 'Add-ons', 'woocommerce-appointments' ),
				'cost'                                => __( 'Cost', 'woocommerce-appointments' ),
				'coupon'                              => __( 'Coupon', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- Reuse WooCommerce core translations.
				'coupons'                             => __( 'Coupons', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- Reuse WooCommerce core translations.
				'discount'                            => __( 'Discount', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- Reuse WooCommerce core translations.
				'tax'                                 => __( 'Tax', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- Reuse WooCommerce core translations.
				'currencySymbols'                     => $symbols_map,
				'currencyFormat'                      => [
					'decimalSeparator'  => wc_get_price_decimal_separator(),
					'thousandSeparator' => wc_get_price_thousand_separator(),
					'priceDecimals'     => wc_get_price_decimals(),
					'currencyPosition'  => get_option( 'woocommerce_currency_pos' ),
				],
				'close'                               => __( 'Close', 'woocommerce-appointments' ),
				'editAppointment'                     => __( 'Edit Appointment', 'woocommerce-appointments' ),
				'unavailableRule'                     => __( 'Unavailable Rule', 'woocommerce-appointments' ),
				'ruleLevelGlobal'                     => _x( 'General', 'availability rule level: default store hours, not a physical shop', 'woocommerce-appointments' ),
				'ruleTypeDateRange'                   => __( 'Date range', 'woocommerce-appointments' ),
				'ruleTypeDateRangeTime'               => __( 'Date range + time', 'woocommerce-appointments' ),
				'ruleTypeRecurring'                   => __( 'Recurring', 'woocommerce-appointments' ),
				'ruleTypeAllDays'                     => __( 'All days', 'woocommerce-appointments' ),
				'ruleTypeDaysOfWeek'                  => __( 'Days of week', 'woocommerce-appointments' ),
				'ruleTypeDayOfWeek'                   => __( 'Day of week', 'woocommerce-appointments' ),
				'ruleId'                              => __( 'Rule ID', 'woocommerce-appointments' ),
				'scope'                               => __( 'Scope', 'woocommerce-appointments' ),
				'start'                               => __( 'Start', 'woocommerce-appointments' ),
				'end'                                 => __( 'End', 'woocommerce-appointments' ),
				'month'                               => __( 'Month', 'woocommerce-appointments' ),
				'week'                                => __( 'Week', 'woocommerce-appointments' ),
				'day'                                 => __( 'Day', 'woocommerce-appointments' ),
				'list'                                => __( 'List', 'woocommerce-appointments' ),
				'view'                                => __( 'View', 'woocommerce-appointments' ),
				'allDay'                              => __( 'All day', 'woocommerce-appointments' ),
				'prev'                                => __( 'Prev', 'woocommerce-appointments' ),
				'today'                               => __( 'Today', 'woocommerce-appointments' ),
				'next'                                => __( 'Next', 'woocommerce-appointments' ),
				'backToMonth'                         => __( 'Back to month', 'woocommerce-appointments' ),
				'addNewAppointment'                   => __( 'Add New Appointment', 'woocommerce-appointments' ),
				'addNew'                              => __( 'New', 'woocommerce-appointments' ),
				'allProducts'                         => __( 'All Products', 'woocommerce-appointments' ),
				'allStaff'                            => __( 'All Staff', 'woocommerce-appointments' ),
				'guest'                               => __( 'Guest', 'woocommerce-appointments' ),
				'customer'                            => __( 'Customer', 'woocommerce-appointments' ),
				'unassigned'                          => __( 'Unassigned', 'woocommerce-appointments' ),
				'noLocation'                          => __( 'No location', 'woocommerce-appointments' ),
				'stripedBackgroundLegend'             => __( 'Striped background indicates unavailable time blocked by availability rules.', 'woocommerce-appointments' ),
				'calendarLibFailed'                   => __( 'Calendar library failed to load.', 'woocommerce-appointments' ),
				'clear'                               => __( 'Clear', 'woocommerce-appointments' ),
				'loading'                             => __( 'Loading…', 'woocommerce-appointments' ),
				'typeToSearch'                        => __( 'Type to search', 'woocommerce-appointments' ),
				'editCustomer'                        => __( 'Edit Customer', 'woocommerce-appointments' ),
				'confirmCancel'                       => __( 'Are you sure?', 'woocommerce-appointments' ),
				'cancelFailed'                        => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
				'statusChangeFailed'                  => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
				'cancelAppointment'                   => __( 'Cancel', 'woocommerce-appointments' ),
				'current'                             => __( 'Current', 'woocommerce-appointments' ),
				'changeStatusTo'                      => __( 'Change status to', 'woocommerce-appointments' ),
				'autoSetStatus'                       => __( 'Set automatically', 'woocommerce-appointments' ),
				'moreStatuses'                        => __( 'More statuses', 'woocommerce-appointments' ),
				'appointmentStatus'                   => __( 'Appointment status', 'woocommerce-appointments' ),
				'timezonePrefix'                      => __( 'Timezone', 'woocommerce-appointments' ),
				'ahead'                               => __( 'ahead', 'woocommerce-appointments' ),
				'behind'                              => __( 'behind', 'woocommerce-appointments' ),
				/* translators: %d: number of hours (timezone offset); "h" = hours abbreviation. Used in modal for "Xh ahead" / "Xh behind". */
				'hoursFormat'                         => _x( '%dh', 'timezone offset hours in admin calendar modal', 'woocommerce-appointments' ),
				'restFetchFailed'                     => __( 'Failed to load calendar data: ', 'woocommerce-appointments' ),
				'restApiUnavailable'                  => __( 'REST API is not available. Calendar will display preloaded appointments only. Please contact your site administrator if this persists.', 'woocommerce-appointments' ),
				'sessionExpired'                      => __( 'Your session has expired. Please reload the page to continue editing.', 'woocommerce-appointments' ),
				'reloadPage'                          => __( 'Reload page', 'woocommerce-appointments' ),
				'appointment'                         => __( 'Appointment', 'woocommerce-appointments' ),
				'order_total'                         => __( 'Order Total', 'woocommerce' ), // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- Reuse WooCommerce core translations.
				'confirm'                             => __( 'Confirm', 'woocommerce-appointments' ),
				'confirmAppointmentTitle'             => __( 'Confirm this appointment', 'woocommerce-appointments' ),
				'cancelAppointmentTitle'              => __( 'Cancel this appointment', 'woocommerce-appointments' ),
				'rescheduleConfirmTitle'              => __( 'Reschedule appointment?', 'woocommerce-appointments' ),
				'rescheduleAction'                    => __( 'Reschedule', 'woocommerce-appointments' ),
				'notifyCustomer'                      => __( 'Email customer about this change', 'woocommerce-appointments' ),
				'notifyNoCustomerEmail'               => __( 'No customer email on this order, so the customer will not be notified about the change.', 'woocommerce-appointments' ),
				'notifyCancelledAppointment'          => __( 'Appointment is cancelled, so the customer will not be notified about the change.', 'woocommerce-appointments' ),
				'appointmentRescheduledCustomerNote'  => __( 'Your appointment was rescheduled.', 'woocommerce-appointments' ),
				'rescheduling'                        => __( 'Rescheduling…', 'woocommerce-appointments' ),
				'durationDay'                         => __( 'day', 'woocommerce-appointments' ),
				'durationDays'                        => __( 'days', 'woocommerce-appointments' ),
				'durationMonth'                       => __( 'month', 'woocommerce-appointments' ),
				'durationMonths'                      => __( 'months', 'woocommerce-appointments' ),
				'durationHour'                        => __( 'hour', 'woocommerce-appointments' ),
				'durationHours'                       => __( 'hours', 'woocommerce-appointments' ),
				'durationHr'                          => __( 'hr', 'woocommerce-appointments' ),
				'durationHrs'                         => __( 'hrs', 'woocommerce-appointments' ),
				'durationMin'                         => __( 'min', 'woocommerce-appointments' ),
				'dismiss'                             => __( 'Dismiss', 'woocommerce-appointments' ),
				// Toast notification messages (semantic, translatable)
				// Placeholders: {customer} = customer name, {datetime} = appointment date/time, {status} = status label
				'toastAvailabilitySaved'              => __( 'Availability rule saved', 'woocommerce-appointments' ),
				'toastAvailabilityDeleted'            => __( 'Availability rule deleted', 'woocommerce-appointments' ),
				/* translators: %d: number of availability rules */
				'toastMultipleAvailabilityCreated'     => __( '%d availability rules created', 'woocommerce-appointments' ),
				/* translators: %d: number of availability rules */
				'toastMultipleAvailabilityUpdated'     => __( '%d availability rules updated', 'woocommerce-appointments' ),
				/* translators: %d: number of availability rules */
				'toastMultipleAvailabilityDeleted'     => __( '%d availability rules deleted', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {datetime} = appointment date/time */
				'toastAddedToCart'                    => __( 'Appointment with {customer} added to cart for {datetime}', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {datetime} = appointment date/time, {id} = appointment ID */
				'toastAppointmentCreatedSemantic'     => __( 'Appointment #{id} with {customer} created for {datetime}', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {pattern} = series pattern summary (e.g. Weekly, 5 appointments) */
				'toastSeriesCreated'                  => __( '{customer} booked a recurring series ({pattern})', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {datetime} = appointment date/time, {id} = appointment ID */
				'toastAppointmentCancelledSemantic'   => __( 'Appointment #{id} with {customer} for {datetime} was cancelled', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {id} = appointment ID */
				'toastAppointmentDeletedSemantic'     => __( 'Appointment #{id} with {customer} was removed', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {datetime} = appointment date/time, {id} = appointment ID */
				'toastAppointmentRescheduledSemantic' => __( 'Appointment #{id} with {customer} rescheduled to {datetime}', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {datetime} = appointment date/time, {id} = appointment ID */
				'toastAppointmentBooked'              => __( '{customer} booked appointment #{id} for {datetime}', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name */
				'toastRemovedFromCart'                => __( 'Appointment with {customer} removed from cart', 'woocommerce-appointments' ),
				/* translators: {customer} = customer name, {status} = status label, {id} = appointment ID */
				'toastAppointmentStatusChanged'       => __( 'Appointment #{id} with {customer} status changed to {status}', 'woocommerce-appointments' ),
				/* translators: %d: number of appointments */
				'toastMultipleAppointmentsCreated'    => __( '%d appointments created', 'woocommerce-appointments' ),
				/* translators: %d: number of appointments */
				'toastMultipleAppointmentsUpdated'    => __( '%d appointments updated', 'woocommerce-appointments' ),
				'statuses'                            => [
					'unpaid'               => __( 'Unpaid', 'woocommerce-appointments' ),
					'pending-confirmation' => __( 'Pending Confirmation', 'woocommerce-appointments' ),
					'confirmed'            => __( 'Confirmed', 'woocommerce-appointments' ),
					'paid'                 => __( 'Paid', 'woocommerce-appointments' ),
					'cancelled'            => __( 'Cancelled', 'woocommerce-appointments' ),
					'complete'             => __( 'Complete', 'woocommerce-appointments' ),
					'in-cart'              => __( 'In Cart', 'woocommerce-appointments' ),
					'was-in-cart'          => __( 'Was In Cart', 'woocommerce-appointments' ),
				],
				'customerStatuses'                    => get_wc_appointment_statuses( 'customer', true ),
				'filters'                             => __( 'Filters', 'woocommerce-appointments' ),
				'chooseDate'                          => __( 'Choose date', 'woocommerce-appointments' ),
				'chooseMonth'                         => __( 'Choose month', 'woocommerce-appointments' ),
				'filterProducts'                      => __( 'Products', 'woocommerce-appointments' ),
				'filterStaff'                         => __( 'Staff', 'woocommerce-appointments' ),
				'filterLocations'                     => __( 'Locations', 'woocommerce-appointments' ),
				'filterStatus'                        => __( 'Status', 'woocommerce-appointments' ),
				'search'                              => __( 'Search', 'woocommerce-appointments' ),
				'clearAll'                            => __( 'Clear all', 'woocommerce-appointments' ),
				'noResults'                           => __( 'No results', 'woocommerce-appointments' ),
				'selected'                            => __( 'selected', 'woocommerce-appointments' ),
			],
		];

		// Preload products and staff lists for instant filter display
		$can_manage_others = current_user_can( 'manage_others_appointments' );

		require_once __DIR__ . '/class-wc-appointments-admin-panel.php';
		$config['preloadedProducts'] = WC_Appointments_Admin_Panel::get_preloaded_products_for_js();

		// Preload staff list
		$preloaded_staff = [];
		if ( $can_manage_others ) {
			// Admin: load all staff members for multi-select filter
			$staff_members = WC_Appointments_Admin::get_appointment_staff();
			if ( ! empty( $staff_members ) ) {
				foreach ( $staff_members as $member ) {
					$_staff_tz         = class_exists( 'WC_Appointments_Timezone_Helper' )
						? WC_Appointments_Timezone_Helper::get_staff_timezone( $member->ID )
						: '';
					$preloaded_staff[] = [
						'id'       => $member->ID,
						'name'     => $member->display_name,
						'avatar'   => get_avatar_url(
                             $member->ID,
                            [
								'size'    => 36,
								'default' => 'mm',
							]
                            ),
						'timezone' => $_staff_tz,
					];
				}
				usort(
                    $preloaded_staff,
                    function ( $a, $b ) {
					return strcasecmp( $a['name'], $b['name'] );
				}
                    );
			}
		} else {
			// Staff user: include own info so the chip displays their name properly
			$current_user = wp_get_current_user();
			if ( $current_user && $current_user->ID ) {
				$_staff_tz         = class_exists( 'WC_Appointments_Timezone_Helper' )
					? WC_Appointments_Timezone_Helper::get_staff_timezone( $current_user->ID )
					: '';
				$preloaded_staff[] = [
					'id'       => $current_user->ID,
					'name'     => $current_user->display_name,
					'avatar'   => get_avatar_url(
                         $current_user->ID,
                        [
							'size'    => 36,
							'default' => 'mm',
						]
                        ),
					'timezone' => $_staff_tz,
				];
			}
		}
		$config['preloadedStaff'] = $preloaded_staff;

		$preloaded_locations = [];
		if ( class_exists( 'WC_Appointments_Location' ) ) {
			// All published locations until optional staff-profile "works at" exists.
			foreach ( WC_Appointments_Location::get_location_choices() as $loc_id => $loc_name ) {
				$preloaded_locations[] = [
					'id'   => (int) $loc_id,
					'name' => $loc_name,
				];
			}
		}
		$config['preloadedLocations'] = $preloaded_locations;

		/*
		 * Admin calendar side panel (create/view/edit appointments, filters). Enabled by default.
		 * To disable, add to theme functions.php or a must-use plugin:
		 *
		 *   add_filter( 'wc_appointments_admin_panel_enabled', '__return_false' );
		 */
		$panel_enabled          = (bool) apply_filters( 'wc_appointments_admin_panel_enabled', true );
		$config['panelEnabled'] = $panel_enabled;

		wp_localize_script( $script_handle, 'wcAppointmentsReactCalendar', $config );
		wp_enqueue_script( $script_handle );

		// Contextual panel scripts and styles — delegated to centralised class.
		if ( $panel_enabled ) {
			WC_Appointments_Admin_Panel::enqueue( $suffix, $script_handle );
		}
	}

	/**
	 * FullCalendar month-grid range (leading/trailing week padding), matching appointment-admin-calendar.js calculateMonthRange.
	 *
	 * @param int $year  Four-digit year.
	 * @param int $month Month 1–12.
	 * @return array{start:int,end:int} Unix timestamps for grid start (inclusive) and end (exclusive).
	 */
	private static function calculate_month_grid_range( int $year, int $month ): array {
		$start_of_week  = abs( (int) get_option( 'start_of_week', 0 ) );
		$first_ts       = (int) strtotime( sprintf( '%d-%02d-01 00:00:00 UTC', $year, $month ) );
		$last_day       = (int) gmdate( 't', $first_ts );
		$start_date_w   = (int) gmdate( 'w', $first_ts );
		$day_offset     = ( $start_date_w - $start_of_week + 7 ) % 7;
		$end_day_offset = 7 - ( ( $last_day + $day_offset ) % 7 );
		if ( 7 === $end_day_offset ) {
			$end_day_offset = 0;
		}
		$last_ts  = (int) strtotime( sprintf( '%d-%02d-%02d 00:00:00 UTC', $year, $month, $last_day ) );
		$start_ts = $first_ts - ( $day_offset * DAY_IN_SECONDS );
		$end_ts   = $last_ts + ( ( $end_day_offset + 1 ) * DAY_IN_SECONDS );

		return [
			'start' => $start_ts,
			'end'   => $end_ts,
		];
	}

	/**
	 * Union of prev/current/next month FullCalendar grids (Fake UTC civil month axis).
	 *
	 * @param string $initial_date Civil anchor date (Y-m-d).
	 * @return array{start:int,end:int}
	 */
	private static function get_three_month_preload_grid_range( string $initial_date ): array {
		$day_timestamp = (int) strtotime( $initial_date . ' 00:00:00 UTC' );
		$anchor        = new DateTimeImmutable( gmdate( 'Y-m-01 00:00:00', $day_timestamp ), new DateTimeZone( 'UTC' ) );
		$start_ts      = PHP_INT_MAX;
		$end_ts        = 0;

		for ( $offset = -1; $offset <= 1; $offset++ ) {
			$month_dt = $anchor->modify( (string) $offset . ' month' );
			$grid     = self::calculate_month_grid_range( (int) $month_dt->format( 'Y' ), (int) $month_dt->format( 'n' ) );
			$start_ts = min( $start_ts, $grid['start'] );
			$end_ts   = max( $end_ts, $grid['end'] );
		}

		return [
			'start' => $start_ts,
			'end'   => $end_ts,
		];
	}

	/**
	 * Get preloaded appointments for initial calendar view.
	 *
	 * Preloads appointments server-side to eliminate initial API call and enable
	 * instant calendar rendering. Similar to how Google Calendar and other major
	 * calendar apps handle initial data loading.
	 *
	 * @param string $view The calendar view (week, month, day, list).
	 * @param string $initial_date Optional initial date (Y-m-d format).
	 * @param int    $product_id Optional product filter.
	 * @param int    $staff_id Optional staff filter.
	 * @return list<array<string, mixed>> Preloaded appointments data formatted for FullCalendar.
	 */
	public static function get_preloaded_appointments( $view = 'week', $initial_date = '', $product_id = 0, $staff_id = 0 ): array {
		if ( empty( $initial_date ) ) {
			$initial_date = date_i18n( 'Y-m-d' );
		}

		$grid_range = self::get_three_month_preload_grid_range( $initial_date );

		$staff_filter = null;
		if ( 0 < $staff_id ) {
			$staff_filter = (int) $staff_id;
		} elseif ( 'unassigned' === $staff_id ) {
			$staff_filter = 0;
		}

		return self::fetch_calendar_appointments_for_range(
			(int) $grid_range['start'],
			(int) $grid_range['end'],
			(int) $product_id,
			$staff_filter
		);
	}

	/**
	 * Fetch calendar rows for a unix range via the internal API (no HTTP).
	 *
	 * @param int      $start_ts   Range start (unix).
	 * @param int      $end_ts     Range end (unix).
	 * @param int      $product_id Product filter (0 = all).
	 * @param int|null $staff_id   Staff filter: null = all, 0 = unassigned, >0 = staff ID.
	 * @return array<int, array<string, mixed>>
	 */
	public static function fetch_calendar_appointments_for_range( int $start_ts, int $end_ts, int $product_id = 0, $staff_id = null ): array {
		if ( ! class_exists( 'WC_Appointments_REST_API_Internal' ) ) {
			if ( class_exists( 'WC_Appointments_REST_API' ) ) {
				$rest_api = new WC_Appointments_REST_API();
				$rest_api->rest_api_includes();
			} else {
				$internal_api_file = WC_APPOINTMENTS_ABSPATH . 'includes/api/class-wc-appointments-rest-api-internal.php';
				if ( file_exists( $internal_api_file ) ) {
					include_once $internal_api_file;
				}
			}
		}

		if ( ! class_exists( 'WC_Appointments_REST_API_Internal' ) ) {
			return [];
		}

		$request_params = [
			'date_from'             => '@' . $start_ts,
			'date_to'               => '@' . $end_ts,
			'include_order_details' => true,
			'_fields'               => WC_Appointments_REST_V2_Calendar_Controller::PANEL_FIELDS,
		];

		if ( 0 < $product_id ) {
			$request_params['product_id'] = $product_id;
		}

		if ( null !== $staff_id ) {
			$request_params['staff_id'] = 0 < $staff_id ? (int) $staff_id : 0;
		}

		$all_appointments = WC_Appointments_REST_API_Internal::calendar()->get(
			$request_params,
			[
				'auto_paginate' => false,
			]
		);

		if ( is_wp_error( $all_appointments ) ) {
			$all_appointments = WC_Appointments_REST_API_Internal::appointments( 'v2' )->get(
				$request_params,
				[
					'per_page'  => 100,
					'max_pages' => 20,
				]
			);

			if ( is_wp_error( $all_appointments ) ) {
				return [];
			}

			$all_appointments = array_filter(
				$all_appointments,
				static function ( array $appt ): bool {
					if ( ! isset( $appt['status'] ) ) {
						return false;
					}

					return ! WC_Appointment_Data_Store::is_calendar_excluded_status( $appt['status'] );
				}
			);
		}

		return array_values( $all_appointments );
	}

}
