<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Admin\Features\Navigation\Menu;
use Automattic\WooCommerce\Admin\Features\Navigation\Screen;

/**
 * WC_Appointments_Admin_Menus.
 */
class WC_Appointments_Admin_Menus {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'current_screen', [ $this, 'buffer' ] );
		add_filter( 'woocommerce_screen_ids', [ $this, 'woocommerce_screen_ids' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ] );
		add_action( 'admin_menu', [ $this, 'remove_default_appointments_menu_links' ], 10, 0 );
		add_action( 'admin_menu', [ $this, 'admin_menu' ], 49, 0 );
		add_filter( 'menu_order', [ $this, 'menu_order' ], 20 );
		add_action( 'load-wc_appointment_page_appointment_calendar', [ $this, 'calendar_screen_options' ] );
		add_filter( 'screen_settings', [ $this, 'calendar_screen_settings' ], 10, 2 );
		add_filter( 'screen_options_show_screen', [ $this, 'show_calendar_screen_options' ] );
		add_action( 'load-post-new.php', [ $this, 'maybe_redirect_add_new_screen' ] );
		add_action( 'admin_init', [ $this, 'reload_translations_for_user_locale' ] );
	}

	/**
	 * output buffer.
	 */
	public function buffer(): void {
		// Get current screen.
		$screen    = function_exists( 'get_current_screen' ) ? get_current_screen() : '';
		$screen_id = $screen ? $screen->id : '';

		if ( 'wc_appointment_page_add_appointment' === $screen_id ) {
			ob_start();
		}
	}

	/**
     * Screen IDS.
     *
     * @param list<string> $ids
	 * @return list<string>
     */
    public function woocommerce_screen_ids( $ids ): array {
		return array_merge(
		    $ids,
		    [
				'edit-wc_appointment',
				'wc_appointment',
				'wc_appointment_page_appointment_calendar',
				'wc_appointment_page_appointment_notification',
				'wc_appointment_page_add_appointment',
				'wc_appointment_page_wc_appointments_global_availability',
			],
		);
	}

	/**
	 * Add appointment scripts in admin pages.
	 *
	 * @param  string $hook
	 * @return void meta in header
	 */
	public function admin_scripts( $hook ): void {

		// Admin calendar page scripts.
		if ( 'wc_appointment_page_appointment_calendar' == $hook ) {
			// Enqueue common dependencies
			wp_enqueue_script( 'wc-enhanced-select' );
			wp_enqueue_script( 'jquery-ui-datepicker' );

			// Check if React calendar mode is enabled
			$react_mode = (bool) apply_filters( 'wc_appointments_admin_enable_react_calendar', true );
			$legacy_toggle = get_user_meta( get_current_user_id(), 'wc_appointments_legacy_calendar', true );
			if ( '1' === $legacy_toggle ) {
				$react_mode = false;
			}
			if ( $react_mode ) {
				// Load calendar class and delegate script enqueuing to it
				if ( ! class_exists( 'WC_Appointments_Admin_Calendar' ) ) {
					require_once __DIR__ . '/class-wc-appointments-admin-calendar.php';
				}
				WC_Appointments_Admin_Calendar::enqueue_react_calendar_scripts();
			}

			// Auto-submit Screen Options form when legacy calendar checkbox changes
			wp_enqueue_script( 'jquery' );
			$auto_submit_script = "
			jQuery( document ).ready( function( $ ) {
				$( '#screen-options-wrap input[name=\"wca_legacy_calendar\"], #screen-options-wrap input[name=\"wca_legacy_add_as_customer\"], #screen-options-wrap input[name=\"wca_allow_unavailable\"]' ).on( 'change', function() {
					var \$form = $( this ).closest( 'form' );
					if ( \$form.length ) {
						\$form.submit();
					}
				} );
			} );
			";
			wp_add_inline_script( 'jquery', $auto_submit_script );

		// Admin add new appointment page scripts.
		} elseif ( 'wc_appointment_page_add_appointment' == $hook ) {
			WC_Appointments_Init::appointment_form_styles();
		}

	}

	/**
	 * Register and handle Screen Options for the calendar screen.
	 */
	public function calendar_screen_options(): void {
		if ( isset( $_POST['screenoptionnonce'] ) ) {
			check_admin_referer( 'screen-options-nonce', 'screenoptionnonce' );
			foreach (
				[
					'wca_legacy_calendar'         => 'wc_appointments_legacy_calendar',
					'wca_legacy_add_as_customer'  => 'wc_appointments_legacy_add_as_customer',
					'wca_allow_unavailable'       => 'wc_appointments_allow_unavailable',
				] as $field => $meta
			) {
				update_user_meta( get_current_user_id(), $meta, isset( $_POST[ $field ] ) ? '1' : '0' );
			}
		}
	}

	/**
	 * Ensure Screen Options tab is visible on the calendar screen.
	 *
	 * @param bool $show
	 * @return bool
	 */
	public function show_calendar_screen_options( $show ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && 'wc_appointment_page_appointment_calendar' === $screen->id ) {
			return true;
		}
		return $show;
	}

	/**
	 * Add a simple checkbox to Screen Options to toggle legacy calendar.
	 *
	 * @param string $settings Screen settings HTML.
	 * @param object $screen   Current screen object.
	 * @return string
	 */
	public function calendar_screen_settings( $settings, $screen ) {
		if ( ! $screen || 'wc_appointment_page_appointment_calendar' !== $screen->id ) {
			return $settings;
		}

		$uid = get_current_user_id();
		$settings .= '<h5>' . esc_html__( 'Calendar Options', 'woocommerce-appointments' ) . '</h5>';
		$settings .= '<div class="metabox-prefs"><label><input type="checkbox" name="wca_legacy_calendar" value="1"' . ( get_user_meta( $uid, 'wc_appointments_legacy_calendar', true ) === '1' ? ' checked="checked"' : '' ) . ' /> ' . esc_html__( 'Use legacy calendar temporarily', 'woocommerce-appointments' ) . '</label></div>';
		$settings .= '<div class="metabox-prefs"><label><input type="checkbox" name="wca_legacy_add_as_customer" value="1"' . ( get_user_meta( $uid, 'wc_appointments_legacy_add_as_customer', true ) === '1' ? ' checked="checked"' : '' ) . ' /> ' . esc_html__( 'Use legacy Create as a customer temporarily', 'woocommerce-appointments' ) . '</label></div>';
		$settings .= '<div class="metabox-prefs"><label><input type="checkbox" name="wca_allow_unavailable" value="1"' . ( get_user_meta( $uid, 'wc_appointments_allow_unavailable', true ) === '1' ? ' checked="checked"' : '' ) . ' /> ' . esc_html__( 'Allow booking unavailable times', 'woocommerce-appointments' ) . '</label></div>';

		return $settings;
	}

	/**
	 * Removes the default appointments menu links from the main admin menu.
	 * @return void
	 */
	public function remove_default_appointments_menu_links()
    {
    }

	/**
	 * Add a submenu for managing appointments pages.
	 */
	public function admin_menu(): void {
		// After All Appointments + Add New; before Locations / Resources CPTs.
		add_submenu_page(
		    'edit.php?post_type=wc_appointment',
		    __( 'Calendar', 'woocommerce-appointments' ),
		    __( 'Calendar', 'woocommerce-appointments' ),
		    'manage_appointments',
		    'appointment_calendar',
		    [
				$this,
				'calendar_page',
			],
			2
		);

		// Register legacy "Add Appointment" page so direct URL still works, but hide it from the menu.
		add_submenu_page(
		    'edit.php?post_type=wc_appointment',
		    __( 'Add New Appointment (Legacy)', 'woocommerce-appointments' ),
		    __( 'Add New (Legacy)', 'woocommerce-appointments' ),
		    'edit_appointments',
		    'add_appointment',
		    [ $this, 'add_appointment_page' ],
		);
		remove_submenu_page( 'edit.php?post_type=wc_appointment', 'add_appointment' );
	}

	/**
	 * Create appointment page
	 */
	public function add_appointment_page(): void {
		require_once __DIR__ . '/class-wc-appointments-admin-add.php';
		$page = new WC_Appointments_Admin_Add();
		$page->output();
	}

	/**
	 * Output the calendar page
	 */
	public function calendar_page(): void {
		require_once __DIR__ . '/class-wc-appointments-admin-calendar.php';
		$page = new WC_Appointments_Admin_Calendar();
		$page->output();
	}

	/**
     * Reorder the WC menu items in admin.
     *
     * @param list<string> $menu_order Menu order.
	 * @return list<string>
     */
    public function menu_order( array $menu_order ): array {
		// Initialize our custom order array
		$new_menu_order = [];

		// Get index of product menu
		$appointment_menu = array_search( 'edit.php?post_type=wc_appointment', $menu_order );

		// Loop through menu order and do some rearranging
		foreach ( $menu_order as $item ) :
			if ( ( ( 'edit.php?post_type=product' ) == $item ) ) :
				$new_menu_order[] = $item;
				$new_menu_order[] = 'edit.php?post_type=wc_appointment';
				unset( $menu_order[ $appointment_menu ] );
			else :
				$new_menu_order[] = $item;
			endif;
		endforeach;

		// Return order
		return $new_menu_order;
	}

	/**
	 * Filters the add new appointment url to point to the appointments list screen
	 * where the admin panel can be opened.
	 *
	 * @param string $url original url
	 * @param string $path requested path that we can match against
	 * @return string new url
	 */
	public function add_new_appointment_url( $url, $path ) {
		if ( 'post-new.php?post_type=wc_appointment' == $path ) {
			return admin_url( 'edit.php?post_type=wc_appointment&open_panel=1' );
		}

		return $url;
	}

	public function maybe_redirect_add_new_screen(): void {
		if ( ! is_admin() ) {
			return;
		}

		$post_type = sanitize_key( (string) filter_input( INPUT_GET, 'post_type' ) );
		if ( 'wc_appointment' !== $post_type ) {
			return;
		}

		wp_safe_redirect( admin_url( 'edit.php?post_type=wc_appointment&open_panel=1' ) );
		exit;
	}

	/**
	 * Reload translations for user-specific locale on admin calendar page.
	 *
	 * This ensures that staff users see the calendar in their preferred language
	 * as set in their user profile, not the site's default language.
	 */
	public function reload_translations_for_user_locale(): void {
		if ( ! function_exists( 'get_user_locale' ) ) {
			return;
		}

		// Check if we're on the calendar page using query string
		$page = sanitize_key( (string) filter_input( INPUT_GET, 'page' ) );
		if ( 'appointment_calendar' !== $page ) {
			return;
		}

		// Get the user's preferred locale
		$user_locale = get_user_locale();
		$site_locale = determine_locale();

		// Only reload if user locale differs from site locale
		if ( $user_locale !== $site_locale ) {
			// Unload existing textdomain
			unload_textdomain( 'woocommerce-appointments', true );

			// Reload with user's locale
			load_textdomain( 'woocommerce-appointments', WP_LANG_DIR . '/woocommerce-appointments/woocommerce-appointments-' . $user_locale . '.mo' );
			load_plugin_textdomain( 'woocommerce-appointments', false, dirname( plugin_basename( WC_APPOINTMENTS_MAIN_FILE ) ) . '/languages/' );
		}
	}
}

$GLOBALS['wc_appointment_admin_menus'] = new WC_Appointments_Admin_Menus();
