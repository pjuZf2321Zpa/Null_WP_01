<?php
/**
 * Staff Dashboard
 *
 * Provides a dedicated dashboard page for staff members with stats and quick actions.
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Staff_Dashboard class.
 */
class WC_Appointments_Admin_Staff_Dashboard {

	/**
	 * Cached dashboard stats for the current request.
	 *
	 * @var array<string, mixed>
	 */
	private $stats = [];

	/**
	 * Current staff user ID.
	 *
	 * @var int
	 */
	private $user_id = 0;

	/**
	 * Active location filter for dashboard queries (0 = all).
	 *
	 * @var int
	 */
	private $filter_location_id = 0;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_dashboard_setup', [ $this, 'register_dashboard_widgets' ] );
		add_action( 'wp_ajax_wca_staff_dashboard_stats', [ $this, 'ajax_get_stats' ] );
		add_action( 'wp_ajax_wca_staff_dashboard_refresh_widgets', [ $this, 'ajax_refresh_widgets' ] );
		add_action( 'wp_ajax_wca_staff_dashboard_chart_data', [ $this, 'ajax_get_chart_data' ] );
		add_action( 'wp_ajax_wca_staff_dashboard_monthly_heatmap', [ $this, 'ajax_get_monthly_heatmap' ] );
		add_action( 'admin_notices', [ $this, 'render_dashboard_notices' ] );

		// Register scripts and styles early
		add_action( 'init', [ $this, 'register_assets' ] );
	}

	/**
	 * Register dashboard assets.
	 */
	public function register_assets(): void {
		// Register Chart.js from CDN if not already registered
		if ( ! wp_script_is( 'chartjs', 'registered' ) ) {
			wp_register_script(
				'chartjs',
				'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js',
				[],
				'4.4.1',
				true
			);
		}

		// Register common staff admin style
		wp_register_style(
			'wca-staff-common',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin-staff-common.css',
			[ 'woocommerce_admin_styles' ],
			WC_APPOINTMENTS_VERSION
		);

		// Register script with Chart.js dependency
		wp_register_script(
			'wca-staff-dashboard',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/admin-staff-dashboard.js',
			[ 'chartjs' ],
			WC_APPOINTMENTS_VERSION,
			true
		);
	}

	/**
	 * Register dashboard widgets for staff users.
	 *
	 * Replaces the old custom submenu page with native WP dashboard widgets.
	 */
	public function register_dashboard_widgets(): void {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return;
		}

		$user_id = get_current_user_id();

		// Enqueue assets on the WP dashboard.
		wp_enqueue_style( 'wca-staff-common' );
		wp_enqueue_script( 'wca-staff-dashboard' );

		$locations = [];
		if ( class_exists( 'WC_Appointments_Location' ) ) {
			foreach ( WC_Appointments_Location::get_location_choices() as $location_id => $location_name ) {
				$locations[] = [
					'id'   => (int) $location_id,
					'name' => $location_name,
				];
			}
			if ( count( $locations ) > 1 ) {
				array_unshift(
					$locations,
					[
						'id'   => 0,
						'name' => __( 'All locations', 'woocommerce-appointments' ),
					]
				);
			}
		}

		wp_localize_script(
			'wca-staff-dashboard',
			'wcaStaffDashboard',
			[
				'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
				'nonce'           => wp_create_nonce( 'wca_staff_dashboard_stats' ),
				'canViewEarnings' => WC_Appointments_Staff_Permissions::can( $user_id, 'view_own_earnings' ),
				'startOfWeek'     => (int) get_option( 'start_of_week', 0 ),
				'locations'       => $locations,
				'currency'        => [
					'symbol'   => html_entity_decode( get_woocommerce_currency_symbol() ),
					'position' => get_option( 'woocommerce_currency_pos', 'left' ),
				],
				'i18n'            => [
					'confirmDelete'    => __( 'Are you sure?', 'woocommerce-appointments' ),
					'error'            => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
					'appointments'     => __( 'Appointments', 'woocommerce-appointments' ),
					'revenue'          => __( 'Revenue', 'woocommerce-appointments' ),
					'noData'           => __( 'No data available', 'woocommerce-appointments' ),
					'locationFilter'   => __( 'Filter by location', 'woocommerce-appointments' ),
					/* translators: %d: number of pending appointments */
					'pendingSingular'  => __( 'You have %d appointment awaiting confirmation.', 'woocommerce-appointments' ),
					/* translators: %d: number of pending appointments (plural) */
					'pendingPlural'    => __( 'You have %d appointments awaiting confirmation.', 'woocommerce-appointments' ),
					/* translators: %d: occupancy percentage */
					'occupancyRate'    => __( '%d%% occupancy rate', 'woocommerce-appointments' ),
				],
			]
		);

		// Compute stats once and cache for all widget render callbacks.
		$this->stats   = $this->get_dashboard_stats( $user_id );
		$this->user_id = $user_id;

		// Welcome / Overview widget (normal column = main).
		wp_add_dashboard_widget(
			'wca_staff_welcome',
			__( 'Appointments Overview', 'woocommerce-appointments' ),
			[ $this, 'render_welcome_widget' ]
		);

		// Chart widget.
		wp_add_dashboard_widget(
			'wca_staff_chart',
			__( 'Appointment Trends', 'woocommerce-appointments' ),
			[ $this, 'render_chart_widget' ]
		);

		// Upcoming appointments widget.
		wp_add_dashboard_widget(
			'wca_staff_upcoming',
			__( 'Upcoming Appointments', 'woocommerce-appointments' ),
			[ $this, 'render_upcoming_widget' ]
		);

		// Insights widget (side column).
		wp_add_dashboard_widget(
			'wca_staff_insights',
			__( 'Insights', 'woocommerce-appointments' ),
			[ $this, 'render_insights_widget' ]
		);

		// This Week widget.
		wp_add_dashboard_widget(
			'wca_staff_week',
			__( 'This Week', 'woocommerce-appointments' ),
			[ $this, 'render_week_widget' ]
		);

		// Monthly heatmap widget.
		wp_add_dashboard_widget(
			'wca_staff_heatmap',
			__( 'Monthly Schedule', 'woocommerce-appointments' ),
			[ $this, 'render_heatmap_widget' ]
		);

		// Top Products widget.
		wp_add_dashboard_widget(
			'wca_staff_top_products',
			__( 'Top Products', 'woocommerce-appointments' ),
			[ $this, 'render_top_products_widget' ]
		);

		// Quick Actions widget.
		wp_add_dashboard_widget(
			'wca_staff_quick_actions',
			__( 'Quick Actions', 'woocommerce-appointments' ),
			[ $this, 'render_quick_actions_widget' ]
		);

		// Force 3-column layout and widget placement for staff on first visit.
		$this->set_default_widget_layout( $user_id );
	}

	/**
	 * Set default dashboard widget layout for staff users.
	 *
	 * Places overview/chart/upcoming in the main column and
	 * insights/week/heatmap/products/actions in the side column.
	 *
	 * @param int $user_id Staff user ID.
	 */
	private function set_default_widget_layout( int $user_id ): void {
		// Force 3-column dashboard layout.
		$columns_key = 'screen_layout_dashboard';
		$current_columns = get_user_meta( $user_id, $columns_key, true );
		if ( empty( $current_columns ) || (int) $current_columns < 3 ) {
			update_user_meta( $user_id, $columns_key, 3 );
		}

		$meta_key = 'meta-box-order_dashboard';
		$existing = get_user_meta( $user_id, $meta_key, true );

		// Only set defaults if the user has never customised the layout.
		if ( ! empty( $existing ) ) {
			return;
		}

		// Distribute widgets across all 3 columns.
		$layout = [
			'normal'  => 'wca_staff_welcome,wca_staff_chart,wca_staff_heatmap',
			'column3' => 'wca_staff_upcoming',
			'side'    => 'wca_staff_quick_actions,wca_staff_insights,wca_staff_week,wca_staff_top_products',
			'column4' => '',
		];

		update_user_meta( $user_id, $meta_key, $layout );
	}

	/**
	 * Render pending appointment notices on the WP dashboard.
	 */
	public function render_dashboard_notices(): void {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || 'dashboard' !== $screen->id ) {
			return;
		}

		$user_id = get_current_user_id();
		$pending = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'status'      => [ 'pending-confirmation' ],
		] );

		$pending_count = count( $pending );
		if ( $pending_count < 1 ) {
			return;
		}

		$review_url = admin_url( 'edit.php?post_type=wc_appointment&post_status=pending-confirmation' );
		$message    = sprintf(
			/* translators: %d: number of pending appointments */
			_n(
				'You have %d appointment awaiting confirmation.',
				'You have %d appointments awaiting confirmation.',
				$pending_count,
				'woocommerce-appointments'
			),
			$pending_count
		);
		?>
		<div class="notice wca-notice wca-notice-warning is-dismissible">
			<p>
				<span class="dashicons dashicons-warning"></span>
				<strong><?php esc_html_e( 'Action Required', 'woocommerce-appointments' ); ?></strong>
				<?php echo esc_html( $message ); ?>
				<a href="<?php echo esc_url( $review_url ); ?>" class="button button-small" style="margin-left: 8px;">
					<?php esc_html_e( 'Review Now', 'woocommerce-appointments' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Render the Welcome / Overview widget.
	 */
	public function render_welcome_widget(): void {
		$stats   = $this->stats;
		$user_id = $this->user_id;
		$user    = wp_get_current_user();

		include __DIR__ . '/views/dashboard-widgets/welcome.php';
	}

	/**
	 * Render the Appointment Trends chart widget.
	 */
	public function render_chart_widget(): void {
		$stats = $this->stats;

		include __DIR__ . '/views/dashboard-widgets/chart.php';
	}

	/**
	 * Render the Upcoming Appointments widget.
	 */
	public function render_upcoming_widget(): void {
		$stats               = $this->stats;
		$user_id             = $this->user_id;
		$filter_location_id  = $this->filter_location_id;
		$filter_location_name = $filter_location_id > 0 ? get_the_title( $filter_location_id ) : '';

		include __DIR__ . '/views/dashboard-widgets/upcoming.php';
	}

	/**
	 * Render the Insights widget.
	 */
	public function render_insights_widget(): void {
		$stats = $this->stats;

		include __DIR__ . '/views/dashboard-widgets/insights.php';
	}

	/**
	 * Render the This Week widget.
	 */
	public function render_week_widget(): void {
		$stats = $this->stats;

		include __DIR__ . '/views/dashboard-widgets/week.php';
	}

	/**
	 * Render the Monthly Heatmap widget.
	 */
	public function render_heatmap_widget(): void {
		$stats = $this->stats;

		include __DIR__ . '/views/dashboard-widgets/heatmap.php';
	}

	/**
	 * Render the Top Products widget.
	 */
	public function render_top_products_widget(): void {
		$stats = $this->stats;

		include __DIR__ . '/views/dashboard-widgets/top-products.php';
	}

	/**
	 * Render the Quick Actions widget.
	 */
	public function render_quick_actions_widget(): void {
		$user_id = $this->user_id;

		include __DIR__ . '/views/dashboard-widgets/quick-actions.php';
	}

	/**
	 * Appointment IDs for the current dashboard location scope.
	 *
	 * @param array<string, mixed> $args Args for WC_Appointment_Data_Store::get_appointment_ids_by().
	 * @return int[]
	 */
	private function appointment_ids( array $args ): array {
		if ( $this->filter_location_id > 0 ) {
			$args['location_id'] = $this->filter_location_id;
		}
		return WC_Appointment_Data_Store::get_appointment_ids_by( $args );
	}

	/**
	 * Allow only published location IDs (0 = all).
	 *
	 * @param int $location_id Requested location ID.
	 * @return int
	 */
	private function sanitize_location_id( int $location_id ): int {
		if ( $location_id <= 0 || ! class_exists( 'WC_Appointments_Location' ) ) {
			return 0;
		}
		return isset( WC_Appointments_Location::get_location_choices()[ $location_id ] ) ? $location_id : 0;
	}

	/**
	 * Get dashboard statistics.
	 *
	 * @param int $user_id     Staff user ID.
	 * @param int $location_id Optional location filter (0 = all).
	 * @return array<string, mixed>
	 */
	private function get_dashboard_stats( int $user_id, int $location_id = 0 ): array {
		$this->filter_location_id = $this->sanitize_location_id( $location_id );

		$now          = current_time( 'timestamp' );
		$today        = strtotime( 'today midnight' );
		$tomorrow     = strtotime( 'tomorrow midnight' );
		$week_start   = strtotime( 'monday this week midnight' );
		$month_start  = strtotime( 'first day of this month midnight' );
		$month_end    = strtotime( 'last day of this month 23:59:59' );
		$last_month_start = strtotime( 'first day of last month midnight' );
		$last_month_end   = strtotime( 'last day of last month 23:59:59' );

		$staff_today = $this->staff_today_key();

		// Today count: staff civil day (padded query), scheduled only.
		$today_by_day = $this->count_appointments_by_staff_day(
			$user_id,
			$today,
			$tomorrow - 1,
			get_wc_appointment_statuses( 'scheduled' )
		);
		$today_count = (int) ( $today_by_day[ $staff_today ] ?? 0 );

		$pending_appointments = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'status'      => [ 'pending-confirmation' ],
		] );

		// Get upcoming appointments (limit 10) - use current time to show only future appointments.
		$upcoming_ids = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $now,
			'status'      => get_wc_appointment_statuses( 'scheduled' ),
			'limit'       => 10,
			'order_by'    => 'start_date',
			'order'       => 'ASC',
		] );

		$upcoming_appointments = [];
		if ( ! empty( $upcoming_ids ) ) {
			foreach ( $upcoming_ids as $appointment_id ) {
				$appointment = get_wc_appointment( $appointment_id );
				if ( $appointment ) {
					$upcoming_appointments[] = $appointment;
				}
			}
		}

		// Get monthly stats.
		$month_appointments = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $month_start,
			'date_before' => $month_end,
			'status'      => get_wc_appointment_statuses( 'scheduled' ),
		] );

		// Get completed this month.
		$completed_this_month = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $month_start,
			'date_before' => $month_end,
			'status'      => [ 'complete' ],
		] );

		// Get last month appointments for comparison.
		$last_month_appointments = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $last_month_start,
			'date_before' => $last_month_end,
			'status'      => get_wc_appointment_statuses( 'scheduled' ),
		] );

		// Calculate revenue if permission granted.
		$month_revenue      = 0;
		$last_month_revenue = 0;
		$can_view_earnings  = WC_Appointments_Staff_Permissions::can( $user_id, 'view_own_earnings' );

		if ( $can_view_earnings ) {
			$month_revenue      = $this->calculate_revenue( $month_appointments );
			$last_month_revenue = $this->calculate_revenue( $last_month_appointments );
		}

		// Calculate occupancy rate.
		$occupancy = $this->calculate_occupancy( $user_id, $month_start, $month_end, count( $month_appointments ) );

		// Get unique customers this month.
		$unique_customers = $this->get_unique_customers_count( $month_appointments );

		// Get appointments by status for pie chart.
		$status_breakdown = $this->get_status_breakdown( $user_id, $month_start, $month_end );

		// Get top products.
		$top_products = $this->get_top_products( $user_id, $month_start, $month_end );

		// Calculate trends.
		$month_trend = $this->calculate_trend( count( $month_appointments ), count( $last_month_appointments ) );
		$revenue_trend = $can_view_earnings ? $this->calculate_trend( $month_revenue, $last_month_revenue ) : 0;

		// Get daily breakdown for the current week (staff civil days).
		$daily_breakdown = $this->get_daily_breakdown( $user_id, $week_start, strtotime( '+7 days', $week_start ) );
		$week_count      = (int) array_sum( array_column( $daily_breakdown, 'count' ) );

		// Get popular booking times.
		$popular_times = $this->get_popular_times( $user_id, $month_start, $month_end );

		// Get occupancy heatmap data for the month.
		$occupancy_heatmap = $this->get_occupancy_heatmap( $user_id, $month_start, $month_end );

		// Calculate completion rate.
		$total_past = count( $completed_this_month ) + count( $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $month_start,
			'date_before' => min( $now, $month_end ),
			'status'      => [ 'cancelled', 'no-show' ],
		] ) );
		$completion_rate = $total_past > 0 ? round( ( count( $completed_this_month ) / $total_past ) * 100 ) : 100;

		return [
			'today_count'       => $today_count,
			'pending_count'     => count( $pending_appointments ),
			'week_count'        => $week_count,
			'month_count'       => count( $month_appointments ),
			'last_month_count'  => count( $last_month_appointments ),
			'completed_count'   => count( $completed_this_month ),
			'completion_rate'   => $completion_rate,
			'upcoming'          => $upcoming_appointments,
			'month_revenue'     => $month_revenue,
			'last_month_revenue' => $last_month_revenue,
			'revenue_formatted' => $can_view_earnings ? wc_price( $month_revenue ) : '',
			'occupancy'         => $occupancy,
			'occupancy_heatmap' => $occupancy_heatmap,
			'unique_customers'  => $unique_customers,
			'status_breakdown'  => $status_breakdown,
			'top_products'      => $top_products,
			'popular_times'     => $popular_times,
			'month_trend'       => $month_trend,
			'revenue_trend'     => $revenue_trend,
			'daily_breakdown'   => $daily_breakdown,
			'staff_today'       => $staff_today,
			'can_view_earnings' => $can_view_earnings,
		];
	}

	/**
	 * Calculate revenue from appointment IDs.
	 *
	 * @param list<int> $appointment_ids Appointment IDs.
	 * @return float
	 */
	private function calculate_revenue( array $appointment_ids ): float {
		$revenue = 0;

		foreach ( $appointment_ids as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment ) {
				continue;
			}

			$order = $appointment->get_order();
			if ( ! $order ) {
				continue;
			}

			$order_item_id = $appointment->get_order_item_id();
			if ( $order_item_id ) {
				$item = $order->get_item( $order_item_id );
				if ( $item ) {
					$revenue += (float) $item->get_total();
				}
			}
		}

		return $revenue;
	}

	/**
	 * Calculate occupancy rate.
	 *
	 * @param int $user_id        Staff user ID.
	 * @param int $start          Start timestamp.
	 * @param int $end            End timestamp.
	 * @param int $booked_count   Number of booked appointments.
	 * @return int Occupancy percentage.
	 */
	private function calculate_occupancy( int $user_id, int $start, int $end, int $booked_count ): int {
		// Estimate available slots based on working days.
		$working_days = 0;
		$current      = $start;

		while ( $current <= $end ) {
			$day_of_week = (int) gmdate( 'N', $current );
			if ( $day_of_week >= 1 && $day_of_week <= 5 ) {
				$working_days++;
			}
			$current = strtotime( '+1 day', $current );
		}

		// Assume average 8 slots per working day.
		$estimated_slots = $working_days * 8;

		if ( $estimated_slots <= 0 ) {
			return 0;
		}

		$occupancy = min( 100, (int) round( ( $booked_count / $estimated_slots ) * 100 ) );
		return max( 0, $occupancy );
	}

	/**
	 * Get unique customers count from appointments.
	 *
	 * @param list<int> $appointment_ids Appointment IDs.
	 * @return int
	 */
	private function get_unique_customers_count( array $appointment_ids ): int {
		$customers = [];

		foreach ( $appointment_ids as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment ) {
				continue;
			}

			$customer_id = $appointment->get_customer_id();
			if ( $customer_id ) {
				$customers[ $customer_id ] = true;
			} else {
				// Guest customer - use order email.
				$order = $appointment->get_order();
				if ( $order ) {
					$email = $order->get_billing_email();
					if ( $email ) {
						$customers[ 'guest_' . md5( $email ) ] = true;
					}
				}
			}
		}

		return count( $customers );
	}

	/**
	 * Get appointment status breakdown.
	 *
	 * @param int $user_id Staff user ID.
	 * @param int $start   Start timestamp.
	 * @param int $end     End timestamp.
	 * @return array<string, mixed>
	 */
	private function get_status_breakdown( int $user_id, int $start, int $end ): array {
		$statuses = [
			'confirmed'            => 0,
			'complete'             => 0,
			'pending-confirmation' => 0,
			'cancelled'            => 0,
			'paid'                 => 0,
		];

		foreach ( array_keys( $statuses ) as $status ) {
			$ids = $this->appointment_ids( [
				'object_id'   => $user_id,
				'object_type' => 'staff',
				'date_after'  => $start,
				'date_before' => $end,
				'status'      => [ $status ],
			] );
			$statuses[ $status ] = count( $ids );
		}

		return $statuses;
	}

	/**
	 * Get top products by appointment count.
	 *
	 * @param int $user_id Staff user ID.
	 * @param int $start   Start timestamp.
	 * @param int $end     End timestamp.
	 * @return list<array<string, mixed>>
	 */
	private function get_top_products( int $user_id, int $start, int $end ): array {
		$appointment_ids = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $start,
			'date_before' => $end,
			'status'      => get_wc_appointment_statuses( 'scheduled' ),
		] );

		$products = [];

		foreach ( $appointment_ids as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment ) {
				continue;
			}

			$product_id = $appointment->get_product_id();
			if ( ! $product_id ) {
				continue;
			}

			if ( ! isset( $products[ $product_id ] ) ) {
				$product = wc_get_product( $product_id );
				$products[ $product_id ] = [
					'id'    => $product_id,
					'name'  => $product ? $product->get_name() : __( 'Unknown', 'woocommerce-appointments' ),
					'count' => 0,
				];
			}
			$products[ $product_id ]['count']++;
		}

		// Sort by count descending.
		usort( $products, function( $a, $b ) {
			return $b['count'] - $a['count'];
		} );

		return array_slice( $products, 0, 5 );
	}

	/**
	 * Calculate percentage trend.
	 *
	 * @param float $current  Current value.
	 * @param float $previous Previous value.
	 * @return int
	 */
	private function calculate_trend( float $current, float $previous ): int {
		if ( $previous <= 0 ) {
			return $current > 0 ? 100 : 0;
		}

		return (int) round( ( ( $current - $previous ) / $previous ) * 100 );
	}

	/**
	 * Appointment start as a staff-display timestamp.
	 */
	private function staff_display_ts( int $start_ts ): int {
		if ( ! $start_ts || ! class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
			return $start_ts;
		}
		return WC_Appointments_Timezone_Helper::convert_to_admin_timezone( $start_ts );
	}

	/**
	 * Civil Y-m-d for an appointment start in the viewing staff timezone.
	 */
	private function staff_day_key( int $start_ts ): string {
		// phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date -- Digits from Fake UTC / convert_to_admin_timezone.
		return date( 'Y-m-d', $this->staff_display_ts( $start_ts ) );
	}

	/**
	 * Staff "today" civil day key.
	 */
	private function staff_today_key(): string {
		return $this->staff_day_key( (int) current_time( 'timestamp' ) );
	}

	/**
	 * Statuses for a date range: past / future / overlapping "now".
	 *
	 * @param bool $include_closed When true, past and overlapping ranges also include cancelled and no-show.
	 * @return string[]
	 */
	private function statuses_for_range( int $start, int $end, bool $include_closed = false ): array {
		$now       = current_time( 'timestamp' );
		$scheduled = get_wc_appointment_statuses( 'scheduled' );

		if ( $end < $now ) {
			$extra = [ 'complete' ];
			if ( $include_closed ) {
				$extra[] = 'cancelled';
				$extra[] = 'no-show';
			}
			return array_merge( $scheduled, $extra );
		}

		if ( $start > $now ) {
			return array_merge( $scheduled, [ 'pending-confirmation', 'unpaid' ] );
		}

		$extra = [ 'pending-confirmation', 'unpaid', 'complete' ];
		if ( $include_closed ) {
			$extra[] = 'cancelled';
			$extra[] = 'no-show';
		}
		return array_merge( $scheduled, $extra );
	}

	/**
	 * Appointment IDs grouped by staff civil day (query window padded ±1 day for midnight slips).
	 *
	 * @param int   $user_id  Staff user ID.
	 * @param int   $start    Range start (inclusive), site Fake UTC.
	 * @param int   $end      Range end (inclusive), site Fake UTC.
	 * @param array<string, string> $statuses Appointment statuses.
	 * @return array<string, int[]> Map of Y-m-d => appointment IDs.
	 */
	private function appointments_by_staff_day( int $user_id, int $start, int $end, array $statuses ): array {
		$ids = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $start - DAY_IN_SECONDS,
			'date_before' => $end + DAY_IN_SECONDS,
			'status'      => $statuses,
		] );

		$by_day = [];
		foreach ( $ids as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment ) {
				continue;
			}
			$start_ts = (int) $appointment->get_start();
			if ( ! $start_ts ) {
				continue;
			}
			$by_day[ $this->staff_day_key( $start_ts ) ][] = (int) $appointment_id;
		}

		return $by_day;
	}

	/**
	 * Count appointments per staff civil day.
	 *
	 * @param array<string, string> $statuses
	 * @return array<string, int> Map of Y-m-d => count.
	 */
	private function count_appointments_by_staff_day( int $user_id, int $start, int $end, array $statuses ): array {
		return array_map( 'count', $this->appointments_by_staff_day( $user_id, $start, $end, $statuses ) );
	}

	/**
	 * Get daily breakdown for a week.
	 *
	 * @param int $user_id Staff user ID.
	 * @param int $start   Start timestamp.
	 * @param int $end     End timestamp.
	 * @return list<array<string, mixed>>
	 */
	private function get_daily_breakdown( int $user_id, int $start, int $end ): array {
		$days    = [];
		$current = $start;
		$counts  = $this->count_appointments_by_staff_day(
			$user_id,
			$start,
			$end - 1,
			$this->statuses_for_range( $start, $end - 1 )
		);

		while ( $current < $end ) {
			$day_key = gmdate( 'Y-m-d', $current );
			$days[]  = [
				'label' => date_i18n( 'D', $current ),
				'date'  => $day_key,
				'count' => (int) ( $counts[ $day_key ] ?? 0 ),
			];
			$current = strtotime( '+1 day', $current );
		}

		return $days;
	}
	/**
	 * Get recent customers for this staff member.
	 *
	 * @param int $user_id Staff user ID.
	 * @param int $limit   Maximum number of customers.
	 * @return list<array<string, mixed>>
	 */
	public function get_recent_customers( int $user_id, int $limit = 5 ): array {
		$appointment_ids = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'status'      => get_wc_appointment_statuses( 'scheduled' ),
			'limit'       => 50,
			'order_by'    => 'start_date',
			'order'       => 'DESC',
		] );

		$customers = [];
		$seen      = [];

		foreach ( $appointment_ids as $appointment_id ) {
			if ( count( $customers ) >= $limit ) {
				break;
			}

			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment ) {
				continue;
			}

			$customer = $appointment->get_customer();
			if ( ! $customer || ! $customer->user_id ) {
				continue;
			}

			if ( isset( $seen[ $customer->user_id ] ) ) {
				continue;
			}

			$seen[ $customer->user_id ] = true;
			$customers[] = [
				'id'     => $customer->user_id,
				'name'   => $customer->name,
				'email'  => $customer->email,
				'avatar' => get_avatar_url( $customer->user_id, [ 'size' => 40 ] ),
			];
		}

		return $customers;
	}

	/**
	 * AJAX handler for refreshing stats.
	 */
	public function ajax_get_stats(): void {
		check_ajax_referer( 'wca_staff_dashboard_stats', 'nonce' );

		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			wp_die( -1 );
		}

		$user_id = get_current_user_id();
		$stats   = $this->get_dashboard_stats( $user_id );

		// Remove heavy data for AJAX response.
		unset( $stats['upcoming'] );

		wp_send_json_success( $stats );
	}

	/**
	 * AJAX handler for refreshing all widget HTML.
	 *
	 * Returns pre-rendered HTML for each widget so the refresh button
	 * can replace widget contents without duplicating template logic in JS.
	 */
	public function ajax_refresh_widgets(): void {
		check_ajax_referer( 'wca_staff_dashboard_stats', 'nonce' );

		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			wp_die( -1 );
		}

		$user_id     = get_current_user_id();
		$location_id = isset( $_POST['location_id'] ) ? absint( wp_unslash( $_POST['location_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$this->user_id = $user_id;
		$stats         = $this->get_dashboard_stats( $user_id, $location_id );
		$user          = wp_get_current_user();
		$filter_location_id   = $this->filter_location_id;
		$filter_location_name = $filter_location_id > 0 ? get_the_title( $filter_location_id ) : '';

		$widgets = [
			'welcome',
			'upcoming',
			'insights',
			'week',
			'heatmap',
			'top-products',
		];

		$html = [];
		foreach ( $widgets as $widget ) {
			ob_start();
			include __DIR__ . '/views/dashboard-widgets/' . $widget . '.php';
			$html[ $widget ] = ob_get_clean();
		}

		wp_send_json_success( $html );
	}

	/**
	 * AJAX handler for chart data.
	 */
	public function ajax_get_chart_data(): void {
		check_ajax_referer( 'wca_staff_dashboard_stats', 'nonce' );

		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			wp_die( -1 );
		}

		$user_id     = get_current_user_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$range       = isset( $_POST['range'] ) ? sanitize_text_field( wp_unslash( $_POST['range'] ) ) : '30days';
		$location_id = isset( $_POST['location_id'] ) ? absint( wp_unslash( $_POST['location_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$this->filter_location_id = $this->sanitize_location_id( $location_id );

		$data = $this->get_chart_data( $user_id, $range );

		wp_send_json_success( $data );
	}

	/**
	 * Get chart data for a date range.
	 *
	 * @param int    $user_id Staff user ID.
	 * @param string $range   Date range (7days, 30days, 90days).
	 * @return array<string, mixed>
	 */
	private function get_chart_data( int $user_id, string $range ): array {
		$days = 30;
		switch ( $range ) {
			case '7days':
				$days = 7;
				break;
			case '90days':
				$days = 90;
				break;
		}

		$start   = strtotime( "-{$days} days midnight" );
		$end     = strtotime( 'tomorrow midnight' );
		$current = $start;

		$labels      = [];
		$appointments = [];
		$revenue     = [];

		$can_view_earnings = WC_Appointments_Staff_Permissions::can( $user_id, 'view_own_earnings' );

		// Bucket by staff civil day so midnight crossings match Upcoming / Insights.
		$by_day = $this->appointments_by_staff_day(
			$user_id,
			$start,
			$end - 1,
			$this->statuses_for_range( $start, $end - 1, true )
		);
		$counts = array_map( 'count', $by_day );

		$total_appointments = 0;
		$total_revenue      = 0;

		while ( $current < $end ) {
			$day_key   = gmdate( 'Y-m-d', $current );
			$day_count = (int) ( $counts[ $day_key ] ?? 0 );

			$labels[]       = gmdate( 'M j', $current );
			$appointments[] = $day_count;
			$total_appointments += $day_count;

			if ( $can_view_earnings ) {
				$day_revenue = $this->calculate_revenue( $by_day[ $day_key ] ?? [] );
				$revenue[]   = $day_revenue;
				$total_revenue += $day_revenue;
			}

			$current = strtotime( '+1 day', $current );
		}

		return [
			'labels'           => $labels,
			'appointments'      => $appointments,
			'revenue'          => $can_view_earnings ? $revenue : [],
			'total_appointments' => $total_appointments,
			'total_revenue'    => $can_view_earnings ? $total_revenue : 0,
			'can_view_earnings' => $can_view_earnings,
		];
	}

	/**
	 * AJAX handler for monthly heatmap data.
	 */
	public function ajax_get_monthly_heatmap(): void {
		check_ajax_referer( 'wca_staff_dashboard_stats', 'nonce' );

		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			wp_die( -1 );
		}

		$user_id = get_current_user_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$month = isset( $_POST['month'] ) ? (int) sanitize_text_field( wp_unslash( $_POST['month'] ) ) : (int) date_i18n( 'n' );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$year = isset( $_POST['year'] ) ? (int) sanitize_text_field( wp_unslash( $_POST['year'] ) ) : (int) date_i18n( 'Y' );
		$location_id = isset( $_POST['location_id'] ) ? absint( wp_unslash( $_POST['location_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$this->filter_location_id = $this->sanitize_location_id( $location_id );

		$start = strtotime( "{$year}-{$month}-01 midnight" );
		$end = strtotime( 'last day of ' . gmdate( 'F Y', $start ) . ' 23:59:59', $start );

		$heatmap = $this->get_occupancy_heatmap( $user_id, $start, $end );
		$occupancy = $this->calculate_occupancy( $user_id, $start, $end, array_sum( array_column( $heatmap, 'count' ) ) );

		wp_send_json_success( [
			'heatmap'   => $heatmap,
			'occupancy' => $occupancy,
			'month'     => $month,
			'year'      => $year,
			'month_label' => date_i18n( 'F Y', $start ),
		] );
	}

	/**
	 * Get popular booking times analysis.
	 *
	 * @param int $user_id Staff user ID.
	 * @param int $start   Start timestamp.
	 * @param int $end     End timestamp.
	 * @return array<string, mixed>
	 */
	private function get_popular_times( int $user_id, int $start, int $end ): array {
		$appointment_ids = $this->appointment_ids( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'date_after'  => $start - DAY_IN_SECONDS,
			'date_before' => $end + DAY_IN_SECONDS,
			'status'      => get_wc_appointment_statuses( 'scheduled' ),
		] );

		$hours    = array_fill( 0, 24, 0 );
		$days     = array_fill( 0, 7, 0 );
		$range_lo = gmdate( 'Y-m-d', $start );
		$range_hi = gmdate( 'Y-m-d', $end );

		foreach ( $appointment_ids as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment ) {
				continue;
			}

			$start_time = (int) $appointment->get_start();
			if ( ! $start_time ) {
				continue;
			}

			// Hour and weekday both follow staff civil clock (same as Upcoming day slip).
			$display_ts = $this->staff_display_ts( $start_time );
			$day_key    = date( 'Y-m-d', $display_ts ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
			if ( $day_key < $range_lo || $day_key > $range_hi ) {
				continue;
			}

			$hour = (int) date( 'G', $display_ts ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
			$day  = (int) date( 'w', $display_ts ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
			$hours[ $hour ]++;
			$days[ $day ]++;
		}

		// Find peak hour.
		$peak_hour = array_search( max( $hours ), $hours, true );
		$peak_hour_label = date_i18n( get_option( 'time_format' ), strtotime( "{$peak_hour}:00" ) );

		// Find peak day.
		$day_labels = [
			__( 'Sunday', 'woocommerce-appointments' ),
			__( 'Monday', 'woocommerce-appointments' ),
			__( 'Tuesday', 'woocommerce-appointments' ),
			__( 'Wednesday', 'woocommerce-appointments' ),
			__( 'Thursday', 'woocommerce-appointments' ),
			__( 'Friday', 'woocommerce-appointments' ),
			__( 'Saturday', 'woocommerce-appointments' ),
		];
		$peak_day = array_search( max( $days ), $days, true );

		return [
			'peak_hour'       => $peak_hour_label,
			'peak_hour_count' => $hours[ $peak_hour ],
			'peak_day'        => $day_labels[ $peak_day ],
			'peak_day_count'  => $days[ $peak_day ],
			'hours'           => $hours,
			'days'            => $days,
		];
	}

	/**
	 * Get occupancy heatmap data for calendar visualization.
	 *
	 * @param int $user_id Staff user ID.
	 * @param int $start   Start timestamp.
	 * @param int $end     End timestamp.
	 * @return array<string, mixed>
	 */
	private function get_occupancy_heatmap( int $user_id, int $start, int $end ): array {
		$heatmap = [];
		$current = $start;
		$counts  = $this->count_appointments_by_staff_day(
			$user_id,
			$start,
			$end,
			$this->statuses_for_range( $start, $end, true )
		);
		$today = $this->staff_today_key();

		while ( $current <= $end ) {
			$date_key = gmdate( 'Y-m-d', $current );
			$count    = (int) ( $counts[ $date_key ] ?? 0 );

			$heatmap[ $date_key ] = [
				'count'     => $count,
				'intensity' => min( 4, $count ),
				'day'       => (int) gmdate( 'j', $current ),
				'weekday'   => (int) gmdate( 'w', $current ),
				'is_today'  => $date_key === $today,
			];

			$current = strtotime( '+1 day', $current );
		}

		return $heatmap;
	}

}
