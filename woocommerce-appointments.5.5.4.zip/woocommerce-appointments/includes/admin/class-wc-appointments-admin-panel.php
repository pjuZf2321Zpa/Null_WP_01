<?php
/**
 * Admin Panel Assets
 *
 * Centralised registration, localisation and enqueue of the
 * React-based admin side-panel (view / edit / create appointments).
 *
 * @package WooCommerce Appointments
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Panel class.
 */
class WC_Appointments_Admin_Panel {

    /**
     * Whether scripts have already been registered in this request.
     *
     * @var bool
     */
    private static bool $registered = false;

    /**
     * Check if the panel feature is enabled via the filter.
     *
     * @return bool
     */
    public static function is_enabled(): bool {
        return (bool) apply_filters( 'wc_appointments_admin_panel_enabled', true );
    }

    /**
     * Register (but do not enqueue) all panel scripts and styles.
     *
     * Safe to call multiple times — will only register once per request.
     *
     * @param string $suffix          Script debug suffix ('' or '.min').
     * @param string $extra_js_dep    Optional extra JS dependency handle
     *                                (e.g. the calendar script handle).
     */
    public static function register( string $suffix = '', string $extra_js_dep = '' ): void {
        if ( self::$registered ) {
            return;
        }
        self::$registered = true;

        // ── Styles ───────────────────────────────────────────────
        wp_register_style(
            'wca-admin-panel-css',
            WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/appointment-admin-panel.css',
            [ 'wc_appointments_admin_styles' ],
            WC_APPOINTMENTS_VERSION,
        );

        // ── WordPress Icons (SVG paths from @wordpress/icons; no Dashicons font) ──
        wp_register_script(
            'wca-panel-wp-icons-js',
            WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/panel/wp-icons' . $suffix . '.js',
            [],
            WC_APPOINTMENTS_VERSION,
            true,
        );

        // ── Panel sub-modules ────────────────────────────────────
        wp_register_script(
            'wca-panel-helpers-js',
            WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/panel/panel-helpers' . $suffix . '.js',
            [],
            WC_APPOINTMENTS_VERSION,
            true,
        );
        wp_register_script(
            'wca-panel-status-js',
            WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/panel/panel-status' . $suffix . '.js',
            [ 'wp-element', 'wca-panel-wp-icons-js' ],
            WC_APPOINTMENTS_VERSION,
            true,
        );
        wp_register_script(
            'wca-panel-browse-js',
            WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/panel/panel-browse' . $suffix . '.js',
            [ 'wp-element', 'wca-panel-helpers-js' ],
            WC_APPOINTMENTS_VERSION,
            true,
        );
        wp_register_script(
            'wca-panel-form-js',
            WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/panel/panel-form' . $suffix . '.js',
            [ 'wp-element', 'wca-panel-helpers-js' ],
            WC_APPOINTMENTS_VERSION,
            true,
        );

        if ( class_exists( 'WC_Appointment_Series_Events' ) && WC_Appointment_Series_Events::is_enabled() ) {
            wp_register_script(
                'wca-panel-series-js',
                WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/panel/panel-series' . $suffix . '.js',
                [ 'wp-element', 'wca-panel-helpers-js', 'wca-shared-js' ],
                WC_APPOINTMENTS_VERSION,
                true,
            );
        }

        // ── Main panel script ────────────────────────────────────
        $deps = [
        	'wp-element',
        	'wca-panel-wp-icons-js',
        	'wca-shared-js',
        	'wc_appointments_timezone_utils_js',
        	'selectWoo',
			'wc-enhanced-select',
        	'wca-panel-helpers-js',
        	'wca-panel-status-js',
        	'wca-panel-browse-js',
        	'wca-panel-form-js',
        ];
        if ( wp_script_is( 'wca-panel-series-js', 'registered' ) ) {
            $deps[] = 'wca-panel-series-js';
        }
        if ( $extra_js_dep ) {
            array_splice( $deps, 1, 0, [ $extra_js_dep ] );
        }

        wp_register_script(
            'wca-admin-panel-js',
            WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/appointment-admin-panel' . $suffix . '.js',
            $deps,
            WC_APPOINTMENTS_VERSION,
            true,
        );
    }

    /**
     * Localise and enqueue all panel assets.
     *
     * Calls `self::register()` first if needed.
     *
     * @param string $suffix       Script debug suffix.
     * @param string $extra_js_dep Optional extra JS dependency handle.
     */
    public static function enqueue( string $suffix = '', string $extra_js_dep = '' ): void {
        self::register( $suffix, $extra_js_dep );

        self::maybe_enqueue_woocommerce_admin_styles();

        // Styles.
        wp_enqueue_style( 'wca-admin-panel-css' );

        // Localise wcaPanel (only once).
        if ( ! wp_script_is( 'wca-panel-helpers-js', 'enqueued' ) ) {
            wp_localize_script( 'wca-panel-helpers-js', 'wcaPanel', self::get_panel_config() );
        }

        wp_enqueue_script( 'wca-admin-panel-js' );
    }

    /**
     * Load WooCommerce core admin.css when the panel runs outside WC admin screens.
     *
     * WC_Admin_Assets only enqueues `woocommerce_admin_styles` for screens in
     * `wc_get_screen_ids()`. The panel is also loaded globally for submenu hooks,
     * so we mirror registration and enqueue here when needed.
     */
    private static function maybe_enqueue_woocommerce_admin_styles(): void {
        if ( ! function_exists( 'WC' ) || ! WC() ) {
            return;
        }
        if ( ! wp_style_is( 'woocommerce_admin_styles', 'registered' ) ) {
            $version = defined( 'WC_VERSION' ) ? WC_VERSION : WC()->version;
            wp_register_style(
                'woocommerce_admin_styles',
                WC()->plugin_url() . '/assets/css/admin.css',
                [],
                $version
            );
            wp_style_add_data( 'woocommerce_admin_styles', 'rtl', 'replace' );
        }
        if ( ! wp_style_is( 'woocommerce_admin_styles', 'enqueued' ) ) {
            wp_enqueue_style( 'woocommerce_admin_styles' );
        }
    }

    // ─── Configuration builders ──────────────────────────────────

    /**
     * Build the `wcaPanel` localised config array.
     *
     * @return array<string, mixed>
     */
    public static function get_panel_config(): array {
        // Match admin React calendar: user profile language in admin when available.
        $panel_locale = function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
        $saved_create_status = get_user_meta( get_current_user_id(), 'wc_appointments_admin_create_status', true );

        $config = [
        	'panelEnabled'          => true,
        	// Match appointment admin pricing to WooCommerce “prices entered with tax” (catalog basis).
        	'pricesIncludeTax'      => wc_tax_enabled() && wc_prices_include_tax(),
        	'taxEnabled'            => wc_tax_enabled(),
        	// Keep admin browse cache behavior aligned with frontend slot cache.
        	'slotsCacheEnabled'     => (bool) apply_filters( 'wc_appointments_slots_cache_enabled', false, null ),
        	'restUrl'               => esc_url_raw( rest_url() ),
        	'nonce'                 => wp_create_nonce( 'wp_rest' ),
        	// Same field mask as calendar; list/widget opens have no wcAppointmentsReactCalendar.
        	'calendarPanelFields'   => class_exists( 'WC_Appointments_REST_V2_Calendar_Controller' )
        		? WC_Appointments_REST_V2_Calendar_Controller::PANEL_FIELDS
        		: '',
        	'ajaxUrl'               => admin_url( 'admin-ajax.php' ),
        	'ajaxNonces'            => [
        		'create'               => wp_create_nonce( 'create-appointment' ),
        		'searchProducts'       => wp_create_nonce( 'search-products' ),
        		'getProductDetails'    => wp_create_nonce( 'get-product-details' ),
        		'searchCustomers'      => wp_create_nonce( 'search-customers' ),
        		'getCustomerDetails'   => wp_create_nonce( 'get-customer-details' ),
        		'searchOrder'          => wp_create_nonce( 'search-appointment-order' ),
        		'checkAvailability'    => wp_create_nonce( 'wc_appointments_check_availability' ),
        		'getDaySlots'               => wp_create_nonce( 'wc_appointments_get_day_slots' ),
        		'getFirstAvailableSlot'     => wp_create_nonce( 'wc_appointments_get_first_available_slot' ),
        		'getMonthAvailability'      => wp_create_nonce( 'wc_appointments_get_month_availability' ),
        		'calendarView'         => wp_create_nonce( 'wc_appointments_calendar_view' ),
        	],
        	'browseMiniCalExpanded' => ( '1' === get_user_meta( get_current_user_id(), 'wc_appointments_browse_mini_cal_expanded', true ) ),
        	'canViewOrders'         => current_user_can( 'manage_woocommerce' ) || current_user_can( 'edit_shop_orders' ),
        	'i18n'                  => self::get_i18n(),
        	'firstday'              => absint( get_option( 'start_of_week', 1 ) ),
        	'locale'                => $panel_locale,
        	'paymentMethods'        => self::get_available_payment_methods(),
        	// Admin create-order billing: same country list as storefront checkout (`get_allowed_countries()`).
        	'billingCountries'      => ( function_exists( 'WC' ) && WC()->countries ) ? WC()->countries->get_allowed_countries() : [],
        	'billingStates'         => ( function_exists( 'WC' ) && WC()->countries ) ? WC()->countries->get_states() : [],
        	// Empty when TZ display is disabled site-wide (create field hides).
        	'timezoneOptionsHtml'   => ( class_exists( 'WC_Appointments_Timezone_Helper' ) && 'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' ) )
        		? WC_Appointments_Timezone_Helper::get_timezone_dropdown( '' )
        		: '',
        	'legacyAddAsCustomer'   => ( '1' === get_user_meta( get_current_user_id(), 'wc_appointments_legacy_add_as_customer', true ) ),
        	'allowUnavailable'      => ( '1' === get_user_meta( get_current_user_id(), 'wc_appointments_allow_unavailable', true ) ),
        	'defaultCreateStatus'   => ( is_string( $saved_create_status ) && in_array( $saved_create_status, get_wc_appointment_statuses( 'user' ), true ) ) ? $saved_create_status : 'confirmed',
        ];

        if ( class_exists( 'WC_Appointment_Series_Events' ) && WC_Appointment_Series_Events::is_enabled() ) {
            $config['seriesRestUrl'] = esc_url_raw( rest_url( 'wc-appointments/v2/series' ) );
            $config['recurring']     = array_merge(
                [
            	'repeatThisAppointment' => __( 'Repeat this appointment', 'woocommerce-appointments' ),
            	'recurringLabel' => __( 'Recurring package', 'woocommerce-appointments' ),
            	'recurringShort' => __( 'Recurring', 'woocommerce-appointments' ),
            	'seriesExpand'   => __( 'Show all appointments', 'woocommerce-appointments' ),
            	'seriesCollapse' => __( 'Hide appointments', 'woocommerce-appointments' ),
				/* translators: %1$d: current appointment number in series, %2$d: total appointments in series */
				'sessionOf'      => __( 'Appointment %1$d of %2$d', 'woocommerce-appointments' ),
            	'loading'        => __( 'Loading…', 'woocommerce-appointments' ),
            	'noOccurrences'  => __( 'No appointments loaded.', 'woocommerce-appointments' ),
            	/* translators: Verb: open this appointment from the series list (button), not an availability status. */
            	'openSession'    => _x( 'Open', 'verb: open this appointment in the series', 'woocommerce-appointments' ),
            	/* translators: Label for the appointment currently shown in the panel (state), not a verb. */
            	'currentSession' => _x( 'Current', 'series appointment currently displayed', 'woocommerce-appointments' ),
            	'scopeLegend'       => __( 'Apply to', 'woocommerce-appointments' ),
            	'scopeOne'          => __( 'This appointment only', 'woocommerce-appointments' ),
            	'scopeFuture'       => __( 'This and following appointments', 'woocommerce-appointments' ),
            	'scopeAll'          => __( 'All appointments in the series', 'woocommerce-appointments' ),
            	'balanceTitle'           => __( 'Package balance', 'woocommerce-appointments' ),
            	'balanceDue'             => __( 'Balance due', 'woocommerce-appointments' ),
            	'paidUpfront'            => __( 'Paid upfront', 'woocommerce-appointments' ),
            	'seriesTotal'            => __( 'Series total', 'woocommerce-appointments' ),
            	'balancePaid'            => __( 'Balance paid', 'woocommerce-appointments' ),
            	'createBalanceOrder'     => __( 'Create balance order', 'woocommerce-appointments' ),
            	'sendPaymentRequest'     => __( 'Send payment request', 'woocommerce-appointments' ),
            	'markPaidOffline'        => __( 'Mark paid offline', 'woocommerce-appointments' ),
            	'markPaidOfflineConfirm' => __( 'Mark the remaining balance as paid offline?', 'woocommerce-appointments' ),
            	'viewBalanceOrder'       => __( 'View balance order', 'woocommerce-appointments' ),
            	'balanceOrderCreated'    => __( 'Balance order created.', 'woocommerce-appointments' ),
            	'paymentRequestSent'     => __( 'Payment request sent.', 'woocommerce-appointments' ),
            	'balanceMarkedPaid'      => __( 'Balance marked paid.', 'woocommerce-appointments' ),
            	'balanceActionDone'      => __( 'Saved.', 'woocommerce-appointments' ),
            	'balanceActionFailed'    => __( 'Action failed.', 'woocommerce-appointments' ),
            	'daily'                  => __( 'Daily', 'woocommerce-appointments' ),
            	'weekly'                 => __( 'Weekly', 'woocommerce-appointments' ),
            	'monthly'                => __( 'Monthly', 'woocommerce-appointments' ),
				'frequency'              => __( 'Frequency', 'woocommerce-appointments' ),
				'countLabel'             => __( 'Count', 'woocommerce-appointments' ),
            	'previewFailed'          => __( 'Preview failed.', 'woocommerce-appointments' ),
            	'unavailable'            => __( 'Unavailable', 'woocommerce-appointments' ),
                ],
                wc_appointments_recurring_shared_i18n()
            );
        }

        /**
         * Allow integrations (e.g. WCML multicurrency) to extend panel config without core coupling.
         *
         * @param array $config Panel config passed to `wcaPanel` in JS.
         */
        return apply_filters( 'wc_appointments_admin_panel_config', $config );
    }

    /**
     * Lightweight product rows for calendar/panel JS (id, name, cal_color, duration, staff, addons).
     * Direct SQL (not WP_Query): list/admin screens can short-circuit product queries to empty.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function get_preloaded_products_for_js(): array {
        global $wpdb;

        $current_user_id = get_current_user_id();
        // Match AJAX product search / get_product_details: limited staff only.
        $filter_staff = class_exists( 'WC_Appointments_Staff_Permissions' )
            && WC_Appointments_Staff_Permissions::is_staff_user( $current_user_id )
            && ! WC_Appointments_Staff_Permissions::can( $current_user_id, 'create_appointments_any' );

        $staff_product_ids = [];
        if ( $filter_staff && $current_user_id ) {
            $staff_product_ids = array_map(
                'absint',
                (array) WC_Data_Store::load( 'product-appointment' )->get_appointable_product_ids_for_staff( $current_user_id )
            );
            if ( ! $staff_product_ids ) {
                return [];
            }
        }

        $sql    = "SELECT p.ID, p.post_title
			FROM {$wpdb->posts} AS p
			INNER JOIN {$wpdb->term_relationships} AS tr ON tr.object_id = p.ID
			INNER JOIN {$wpdb->term_taxonomy} AS tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			INNER JOIN {$wpdb->terms} AS t ON t.term_id = tt.term_id
			WHERE p.post_type = 'product'
			AND p.post_status = 'publish'
			AND tt.taxonomy = %s
			AND t.slug = %s";
        $params = [ 'product_type', 'appointment' ];
        if ( $staff_product_ids ) {
            $ids_ph = implode( ',', array_fill( 0, count( $staff_product_ids ), '%d' ) );
            $sql   .= " AND p.ID IN ( {$ids_ph} )";
            $params = array_merge( $params, $staff_product_ids );
        }
        $sql .= ' ORDER BY p.post_title ASC';

        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders, WordPress.DB.PreparedSQL.NotPrepared -- Dynamic IN placeholders; IDs int-cast.
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
        // phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders, WordPress.DB.PreparedSQL.NotPrepared

        $product_ids = array_map( 'absint', wp_list_pluck( (array) $rows, 'ID' ) );
        if ( $product_ids ) {
            update_meta_cache( 'post', $product_ids );
        }

        $default_color = WC_Appointments_Admin::get_default_cal_color();
        $out           = [];
        foreach ( (array) $rows as $row ) {
            $pid       = (int) $row->ID;
            $cal_color = trim( (string) get_post_meta( $pid, '_wc_appointment_cal_color', true ) );
            $unit      = (string) get_post_meta( $pid, '_wc_appointment_duration_unit', true );
            if ( '' === $unit ) {
                $unit = 'hour';
            }
            $duration = absint( get_post_meta( $pid, '_wc_appointment_duration', true ) );
            $item     = [
                'id'            => $pid,
                'name'          => (string) $row->post_title,
                'cal_color'     => '' !== $cal_color ? $cal_color : $default_color,
                'duration'      => $duration > 0 ? $duration : 1,
                'duration_unit' => $unit,
                'has_time'      => in_array( $unit, [ 'hour', 'minute' ], true ),
                'has_addons'    => false,
            ];
            if ( class_exists( 'WC_Appointments_Integration_Addons' ) && WC_Appointments_Integration_Addons::product_has_addons( $pid ) ) {
                $tax_display = ( wc_tax_enabled() && wc_prices_include_tax() ) ? 'incl' : 'excl';
                $addons      = WC_Appointments_Integration_Addons::get_panel_addons_data( $pid, $tax_display );
                $item['has_addons']          = true;
                $item['addons_html']         = isset( $addons['html'] ) ? (string) $addons['html'] : '';
                $item['has_required_addons'] = ! empty( $addons['has_required_addons'] );
            }
            $out[] = $item;
        }

        // One JOIN: product → staff id/name for create Staff field (no deferred reveal).
        if ( $product_ids ) {
            $rel_rows = WC_Product_Appointment_Data_Store_CPT::get_staff_display_rows_for_products(
                $product_ids,
                $filter_staff ? (int) $current_user_id : 0
            );
            $staff_by_product = [];
            foreach ( (array) $rel_rows as $rel ) {
                $staff_by_product[ (int) $rel->product_id ][ (string) (int) $rel->staff_id ] = (string) $rel->display_name;
            }
            foreach ( $out as &$row ) {
                $map = $staff_by_product[ (int) $row['id'] ] ?? null;
                if ( ! $map ) {
                    continue;
                }
                $assign                  = (string) get_post_meta( (int) $row['id'], '_wc_appointment_staff_assignment', true );
                $staff_label             = trim( (string) get_post_meta( (int) $row['id'], '_wc_appointment_staff_label', true ) );
                $row['has_staff']        = true;
                $row['staff']            = $map;
                $row['staff_assignment'] = '' !== $assign ? $assign : 'customer';
                $row['staff_label']      = '' !== $staff_label ? $staff_label : __( 'Providers', 'woocommerce-appointments' );
            }
            unset( $row );
        }

        foreach ( $out as &$row ) {
            $mode = (string) get_post_meta( (int) $row['id'], '_wc_appointment_location_mode', true );
            if ( ! in_array( $mode, [ 'fixed', 'hidden', 'customer_choice' ], true ) ) {
                continue;
            }
            $ids = array_filter( array_map( 'absint', (array) get_post_meta( (int) $row['id'], '_wc_appointment_location_ids', true ) ) );
            if ( ! $ids && 'customer_choice' !== $mode ) {
                continue;
            }
            $product_obj = get_wc_product_appointment( (int) $row['id'] );
            if ( ! $product_obj || ! class_exists( 'WC_Appointments_Location' ) || ! $product_obj->has_locations() ) {
                continue;
            }
            $map = [];
            foreach ( WC_Appointments_Location::get_allowed_location_ids( $product_obj ) as $lid ) {
                $title = get_the_title( $lid );
                if ( $title ) {
                    $map[ (string) (int) $lid ] = $title;
                }
            }
            if ( ! $map ) {
                continue;
            }
            $row['has_locations'] = true;
            $row['location_mode'] = $product_obj->get_location_mode();
            $location_label       = trim( (string) $product_obj->get_location_label( 'edit' ) );
            $row['location_label'] = '' !== $location_label ? $location_label : __( 'Location', 'woocommerce-appointments' );
            $row['locations']      = $map;
            $row['location_costs'] = WC_Appointments_Location::product_location_costs_map( $product_obj, $map );
        }
        unset( $row );

        foreach ( $out as &$row ) {
            $product_obj = get_wc_product_appointment( (int) $row['id'] );
            if ( ! $product_obj || ! class_exists( 'WC_Appointments_Resource' ) || ! $product_obj->has_resources() ) {
                continue;
            }
            $res_map = [];
            foreach ( WC_Appointments_Resource::normalize_requirements( $product_obj ) as $req ) {
                $rid = (int) ( $req['resource_id'] ?? 0 );
                if ( $rid <= 0 ) {
                    continue;
                }
                $title = get_the_title( $rid );
                if ( ! $title ) {
                    continue;
                }
                $res_map[ (string) $rid ] = [
                    'title'       => $title,
                    'location_id' => WC_Appointments_Resource_Data_Store::get_location_id( $rid ),
                    'cost'        => (float) ( $req['cost'] ?? 0 ),
                ];
            }
            if ( ! $res_map ) {
                continue;
            }
            $row['has_resources']       = true;
            $row['resources']           = $res_map;
            $row['resource_assignment'] = $product_obj->get_resource_assignment();
            $res_label                  = trim( (string) $product_obj->get_resource_label( 'edit' ) );
            $row['resource_label']      = '' !== $res_label ? $res_label : __( 'Resources', 'woocommerce-appointments' );
        }
        unset( $row );

        // Duplicate titles: append SKU, else #id (unique names stay plain).
        $title_n = array_count_values( array_column( $out, 'name' ) );
        foreach ( $out as &$row ) {
            if ( ( $title_n[ $row['name'] ] ?? 0 ) < 2 ) {
                continue;
            }
            $sku = (string) get_post_meta( (int) $row['id'], '_sku', true );
            $row['name'] .= '' !== $sku ? ' (' . $sku . ')' : ' (#' . $row['id'] . ')';
        }
        unset( $row );

        return $out;
    }

    /**
     * Build the calendar-config stub that the panel JS reads for timezone,
     * statuses, products and staff when it runs outside the calendar page.
     *
     * On the calendar page the full `wcAppointmentsReactCalendar` object is
     * already present, so this is only needed on standalone pages (e.g. the
     * appointments list table).
     *
     * @return array<string, mixed>
     */
    public static function get_standalone_calendar_config(): array {
        $can_manage_others = current_user_can( 'manage_others_appointments' );
        $current_user_id   = get_current_user_id();

        $preloaded_products = self::get_preloaded_products_for_js();

        // ── Staff ────────────────────────────────────────────────
        $preloaded_staff = [];
        if ( $can_manage_others ) {
            $staff_members = WC_Appointments_Admin::get_appointment_staff();
            if ( ! empty( $staff_members ) ) {
                foreach ( $staff_members as $member ) {
                    $_staff_tz         = class_exists( 'WC_Appointments_Timezone_Helper' )
                    	? WC_Appointments_Timezone_Helper::get_staff_timezone( $member->ID )
                    	: '';
                    $preloaded_staff[] = [
                    	'id'       => $member->ID,
                    	'name'     => $member->display_name,
                    	'avatar'   => get_avatar_url(
                    	    $member->ID,
                    	    [
                    	    	'size'    => 36,
                    	    	'default' => 'mm',
                    	    ]
                    	),
                    	'timezone' => $_staff_tz,
                    ];
                }
                usort(
                    $preloaded_staff,
                    function ( $a, $b ) {
                        return strcasecmp( $a['name'], $b['name'] );
                    }
                );
            }
        } else {
            $current_user = wp_get_current_user();
            if ( $current_user && $current_user->ID ) {
                $_staff_tz         = class_exists( 'WC_Appointments_Timezone_Helper' )
                	? WC_Appointments_Timezone_Helper::get_staff_timezone( $current_user->ID )
                	: '';
                $preloaded_staff[] = [
                	'id'       => $current_user->ID,
                	'name'     => $current_user->display_name,
                	'avatar'   => get_avatar_url(
                	    $current_user->ID,
                	    [
                	    	'size'    => 36,
                	    	'default' => 'mm',
                	    ]
                	),
                	'timezone' => $_staff_tz,
                ];
            }
        }

        // ── Timezone context ─────────────────────────────────────
        $site_timezone = class_exists( 'WC_Appointments_Timezone_Helper' )
        	? WC_Appointments_Timezone_Helper::get_site_timezone_string()
        	: wc_timezone_string();

        $show_tz_context     = class_exists( 'WC_Appointments_Timezone_Helper' )
        	&& WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', $current_user_id );
        $admin_user_timezone = $site_timezone;
        if ( $show_tz_context ) {
            $admin_user_timezone = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
        }

        $admin_tz_offset_minutes = 0;
        $site_tz_offset_minutes  = 0;
        try {
            $now                     = new \DateTime( 'now' );
            $admin_tz_obj            = new \DateTimeZone( $admin_user_timezone );
            $admin_tz_offset_minutes = (int) ( $admin_tz_obj->getOffset( $now ) / 60 );
            $site_tz_obj             = new \DateTimeZone( $site_timezone );
            $site_tz_offset_minutes  = (int) ( $site_tz_obj->getOffset( $now ) / 60 );
        } catch ( \Exception $e ) {
            $gmt_offset              = (int) ( get_option( 'gmt_offset', 0 ) * 60 );
            $admin_tz_offset_minutes = $gmt_offset;
            $site_tz_offset_minutes  = $gmt_offset;
        }

        // ── Statuses ─────────────────────────────────────────────
        $statuses = self::get_appointment_status_labels();

        return [
        	'panelEnabled'          => true,
        	'preloadedProducts'     => $preloaded_products,
        	'preloadedStaff'        => $preloaded_staff,
        	'adminPost'             => admin_url( 'post.php' ),
			'canManageOthers'       => $can_manage_others,
        	'siteTimezone'          => $site_timezone,
        	'adminTimezone'         => $admin_user_timezone,
        	'adminTimezoneHtml'     => class_exists( 'WC_Appointments_Timezone_Helper' )
        		? WC_Appointments_Timezone_Helper::build_timezone_indicator_html( $admin_user_timezone )
        		: '',
        	'adminTimezoneOffset'   => $admin_tz_offset_minutes,
        	'siteTimezoneOffset'    => $site_tz_offset_minutes,
        	'showTimezoneContext'   => $show_tz_context,
        	'dateFormat'            => wc_appointments_date_format(),
        	'timeFormat'            => wc_appointments_time_format(),
        	'currency'              => get_woocommerce_currency(),
        	'staffPermissions'      => WC_Appointments_Staff_Permissions::admin_ui_flags(),
        	'statuses'              => $statuses,
        	'browseMiniCalExpanded' => ( '1' === get_user_meta( get_current_user_id(), 'wc_appointments_browse_mini_cal_expanded', true ) ),
        	'legacyAddAsCustomer'   => ( '1' === get_user_meta( get_current_user_id(), 'wc_appointments_legacy_add_as_customer', true ) ),
        	'allowUnavailable'      => ( '1' === get_user_meta( get_current_user_id(), 'wc_appointments_allow_unavailable', true ) ),
        ];
    }

    /**
     * Localise the standalone calendar config and enqueue.
     *
     * Used on non-calendar admin pages (e.g. list table) where the full
     * `wcAppointmentsReactCalendar` object is not already present.
     *
     * @param string $suffix       Script debug suffix.
     */
    public static function enqueue_standalone( string $suffix = '' ): void {
        self::enqueue( $suffix );

        // Only localise the calendar stub if the calendar page hasn't already done so.
        if ( ! wp_script_is( 'wca-react-calendar-js', 'enqueued' ) ) {
            wp_localize_script( 'wca-admin-panel-js', 'wcAppointmentsReactCalendar', self::get_standalone_calendar_config() );
        }
    }

    // ─── i18n ────────────────────────────────────────────────────

    /**
     * Translated appointment status slug => label map for panel JS (view/edit/create).
     *
     * @return array<string, string>
     */
    private static function get_appointment_status_labels(): array {
        $statuses = [];
        if ( function_exists( 'wc_appointments_get_status_label' ) ) {
            $status_keys = [ 'confirmed', 'paid', 'pending-confirmation', 'unpaid', 'cancelled', 'complete', 'in-cart', 'was-in-cart' ];
            foreach ( $status_keys as $sk ) {
                $statuses[ $sk ] = wc_appointments_get_status_label( $sk );
            }
        }
        return $statuses;
    }

    /**
     * Currency code => symbol map for JS footer price formatting (matches calendar localisation).
     *
     * @return array<string, string>
     */
    private static function get_currency_symbols_map(): array {
        $symbols_map = [];
        if ( function_exists( 'get_woocommerce_currencies' ) ) {
            foreach ( get_woocommerce_currencies() as $code => $name ) {
                $symbols_map[ $code ] = html_entity_decode( get_woocommerce_currency_symbol( $code ), ENT_NOQUOTES, 'UTF-8' );
            }
        }
        return $symbols_map;
    }

    /**
     * Get all translatable strings used by the panel JS.
     *
     * @return array<string, mixed>
     */
    private static function get_i18n(): array {
        return [
        	'statuses'              => self::get_appointment_status_labels(),
        	'viewOrder'             => __( 'View Order', 'woocommerce-appointments' ),
        	'emailCustomer'         => __( 'Email customer', 'woocommerce-appointments' ),
        	'moreActions'           => __( 'More actions', 'woocommerce-appointments' ),
        	'trash'                 => __( 'Trash', 'woocommerce-appointments' ),
        	'confirmDelete'         => __( 'Are you sure?', 'woocommerce-appointments' ),
        	'confirmCancel'         => __( 'Are you sure?', 'woocommerce-appointments' ),
        	'deleteFailed'          => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
        	'unknown_staff'         => __( 'Staff', 'woocommerce-appointments' ),
        	'date'                  => __( 'Date', 'woocommerce-appointments' ),
        	'month'                 => __( 'Month', 'woocommerce-appointments' ),
        	'status'                => __( 'Status', 'woocommerce-appointments' ),
        	'update'                => __( 'Update', 'woocommerce-appointments' ),
        	'saving'                => __( 'Saving…', 'woocommerce-appointments' ),
        	'updateFailed'          => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
        	'discardChanges'        => __( 'You have unsaved changes. Discard them?', 'woocommerce-appointments' ),
        	'timesShownIn'          => __( 'Times shown in', 'woocommerce-appointments' ),
        	'newAppointment'        => __( 'New Appointment', 'woocommerce-appointments' ),
        	'product'               => __( 'Product', 'woocommerce-appointments' ),
        	'selectProduct'         => __( 'Select a product…', 'woocommerce-appointments' ),
        	'productRequired'       => __( 'This field is required.', 'woocommerce-appointments' ),
        	'dateRequired'          => __( 'This field is required.', 'woocommerce-appointments' ),
        	'timeRequired'          => __( 'This field is required.', 'woocommerce-appointments' ),
        	'timeStartEndSame'      => __( 'Start and end times cannot be the same.', 'woocommerce-appointments' ),
        	'requiredAddons'        => __( 'Please select required add-ons.', 'woocommerce-appointments' ),
        	'create'                => __( 'Create', 'woocommerce-appointments' ),
        	'creating'              => __( 'Creating…', 'woocommerce-appointments' ),
        	'createFailed'          => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
        	'createAnother'         => __( 'Create Another', 'woocommerce-appointments' ),
        	'appointmentCreated'    => __( 'Appointment created successfully.', 'woocommerce-appointments' ),
        	'appointmentIdLabel'    => __( 'Appointment', 'woocommerce-appointments' ),
        	/* translators: %d: Appointment ID */
        	'appointmentWithId'     => __( 'Appointment #%d', 'woocommerce-appointments' ),
        	'appointmentLoadFailed' => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
        	'autoAssign'            => __( 'Automatic (any available)', 'woocommerce-appointments' ),
        	'anyAvailable'          => __( 'Any available', 'woocommerce-appointments' ),
        	'allStaffAssigned'      => __( 'All staff assigned', 'woocommerce-appointments' ),
        	'searchCustomer'        => __( 'Search customers…', 'woocommerce-appointments' ),
        	'guest'                 => __( 'Guest', 'woocommerce-appointments' ),
        	'newOrder'              => __( 'Create new order', 'woocommerce-appointments' ),
        	'existingOrder'         => __( 'Add to an existing order', 'woocommerce-appointments' ),
        	'noOrder'               => __( 'No order', 'woocommerce-appointments' ),
        	'orderType'             => __( 'Order', 'woocommerce-appointments' ),
        	'searchOrder'           => __( 'Search order…', 'woocommerce-appointments' ),
        	'existingOrderLabel'    => __( 'Existing order', 'woocommerce-appointments' ),
        	'quantity'              => __( 'Quantity', 'woocommerce-appointments' ),
        	'qty'                   => __( 'Qty', 'woocommerce-appointments' ),
			'customer'              => __( 'Customer', 'woocommerce-appointments' ),
        	'customerStatus'        => __( 'Attendance', 'woocommerce-appointments' ),
        	'expected'              => __( 'Expected', 'woocommerce-appointments' ),
        	'arrived'               => __( 'Arrived', 'woocommerce-appointments' ),
        	'noShow'                => __( 'No-show', 'woocommerce-appointments' ),
        	'loading'               => __( 'Loading…', 'woocommerce-appointments' ),
        	'clear'                 => __( 'Clear', 'woocommerce-appointments' ),
        	'edit'                  => __( 'Edit', 'woocommerce-appointments' ),
        	'firstName'             => __( 'First name', 'woocommerce-appointments' ),
        	'lastName'              => __( 'Last name', 'woocommerce-appointments' ),
        	'company'               => __( 'Company', 'woocommerce-appointments' ),
        	'address1'              => __( 'Address line 1', 'woocommerce-appointments' ),
        	'address2'              => __( 'Address line 2', 'woocommerce-appointments' ),
        	'city'                  => __( 'City', 'woocommerce-appointments' ),
        	'postcode'              => __( 'Postcode / ZIP', 'woocommerce-appointments' ),
        	'country'               => __( 'Country / Region', 'woocommerce-appointments' ),
        	'state'                 => __( 'State / County', 'woocommerce-appointments' ),
        	'selectCountry'         => __( 'Select a country / region…', 'woocommerce-appointments' ),
        	'selectState'           => __( 'Select a state / county…', 'woocommerce-appointments' ),
        	'emailAddress'          => __( 'Email address', 'woocommerce-appointments' ),
        	'phone'                 => __( 'Phone', 'woocommerce-appointments' ),
        	'timezone'              => __( 'Timezone', 'woocommerce-appointments' ),
        	'paymentMethod'         => __( 'Payment method', 'woocommerce-appointments' ),
        	'selectPayment'         => __( 'Select a payment method', 'woocommerce-appointments' ),
        	'transactionId'         => __( 'Transaction ID', 'woocommerce-appointments' ),
        	'createAccount'         => __( 'Create an account for this customer', 'woocommerce-appointments' ),
        	'addons'                => __( 'Add-ons', 'woocommerce-appointments' ),
        	'addons_total'          => __( 'Add-ons total', 'woocommerce-appointments' ),
        	'depositPayment'        => __( 'Deposit payment', 'woocommerce-appointments' ),
        	'payDeposit'            => __( 'Pay deposit', 'woocommerce-appointments' ),
        	'payInFull'             => __( 'Pay in full', 'woocommerce-appointments' ),
			'paymentPlan'           => __( 'Payment plan', 'woocommerce-appointments' ),
        	'unassigned'            => __( 'Unassigned', 'woocommerce-appointments' ),
        	'editAppointment'       => __( 'Edit Appointment', 'woocommerce-appointments' ),
        	'createAppointment'     => __( 'Create', 'woocommerce-appointments' ),
        	'createAsCustomer'      => __( 'Create as a Customer', 'woocommerce-appointments' ),
        	'searchProduct'         => __( 'Search for an appointable product…', 'woocommerce-appointments' ),
        	'from'                  => __( 'From', 'woocommerce-appointments' ),
        	'to'                    => __( 'To', 'woocommerce-appointments' ),
        	'close'                 => __( 'Close', 'woocommerce-appointments' ),
        	'expandToFullMonth'     => __( 'Expand to full month', 'woocommerce-appointments' ),
        	'pickFromCalendar'      => __( 'Pick from a calendar', 'woocommerce-appointments' ),
        	'showWeekView'          => __( 'Show week view', 'woocommerce-appointments' ),
        	'availableSlots'        => __( 'Available Slots', 'woocommerce-appointments' ),
        	'slotsAvailable'        => __( 'available', 'woocommerce-appointments' ),
        	'staffCount'            => __( 'staff', 'woocommerce-appointments' ),
        	'noSlots'               => __( 'No available slots', 'woocommerce-appointments' ),
        	'noSlotsOnDate'         => __( 'No available time slots on this date.', 'woocommerce-appointments' ),
        	'noSlotsOnDateSelect'   => __( 'No available time slots on this date. Please select a different date.', 'woocommerce-appointments' ),
        	'timeUnavailable'       => __( 'Your selected time is not available on this date.', 'woocommerce-appointments' ),
        	'timeUnavailableOnDate' => __( 'Your selected time is not available on this date. Please select an available time slot below.', 'woocommerce-appointments' ),
        	'dateRangeUnavailable'  => __( 'This date range is not available. Please select different dates.', 'woocommerce-appointments' ),
        	'monthRangeUnavailable' => __( 'This month range is not available. Please select different months.', 'woocommerce-appointments' ),
        	'endsNextDay'           => __( 'Ends on a different day', 'woocommerce-appointments' ),
        	'selectDateRange'       => __( 'Select a start date for this day-based product.', 'woocommerce-appointments' ),
        	'selectMonthRange'      => __( 'Select a start month for this month-based product.', 'woocommerce-appointments' ),
        	'staff'                 => __( 'Staff', 'woocommerce-appointments' ),
        	'location'              => __( 'Location', 'woocommerce-appointments' ),
        	'chooseLocation'        => __( 'Choose a location', 'woocommerce-appointments' ),
        	'locationRequired'      => __( 'Please choose a location.', 'woocommerce-appointments' ),
        	'locationGate'          => __( 'Choose a location to see available times.', 'woocommerce-appointments' ),
        	'resources'             => __( 'Resources', 'woocommerce-appointments' ),
        	'resourceAutomatic'     => __( 'Automatic', 'woocommerce-appointments' ),
        	'resourceNeedLocation'  => __( 'Choose a location to see available resources.', 'woocommerce-appointments' ),
        	'resourceGate'          => __( 'Choose a resource to see available times.', 'woocommerce-appointments' ),
        	'resourceRequired'      => __( 'Please choose a resource.', 'woocommerce-appointments' ),
        	'joinMeeting'           => __( 'Join Meeting', 'woocommerce-appointments' ),
        	'openMeeting'           => __( 'Open meeting', 'woocommerce-appointments' ),
        	'checkingAvailability'  => __( 'Checking availability…', 'woocommerce-appointments' ),
        	'slotUnavailable'       => __( 'This slot is not available.', 'woocommerce-appointments' ),
        	'loadingInProgress'     => __( 'Background tasks are still running', 'woocommerce-appointments' ),
        	'loadingAddons'         => __( 'Add-ons', 'woocommerce-appointments' ),
        	'proceedAnyway'         => __( 'Proceed anyway?', 'woocommerce-appointments' ),
        	'confirmation'          => __( 'Are you sure?', 'woocommerce-appointments' ),
        	'appointmentStatus'     => __( 'Appointment status', 'woocommerce-appointments' ),
        	'statusChangeFailed'    => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ),
        	'current'               => __( 'Current', 'woocommerce-appointments' ),
        	'changeStatusTo'        => __( 'Change status to', 'woocommerce-appointments' ),
        	'moreStatuses'          => __( 'More statuses', 'woocommerce-appointments' ),
        	/* translators: %d: hour count for timezone offset display */
        	'hoursFormat'           => __( '%dh', 'woocommerce-appointments' ),
        	'durationMin'           => __( 'min', 'woocommerce-appointments' ),
        	'ahead'                 => __( 'ahead', 'woocommerce-appointments' ),
        	'behind'                => __( 'behind', 'woocommerce-appointments' ),
        	'durationDay'           => __( 'day', 'woocommerce-appointments' ),
        	'durationDays'          => __( 'days', 'woocommerce-appointments' ),
        	'durationMonth'         => __( 'month', 'woocommerce-appointments' ),
        	'durationMonths'        => __( 'months', 'woocommerce-appointments' ),
        	'durationHour'          => __( 'hour', 'woocommerce-appointments' ),
        	'durationHours'         => __( 'hours', 'woocommerce-appointments' ),
        	'durationHr'            => __( 'hr', 'woocommerce-appointments' ),
        	'durationHrs'           => __( 'hrs', 'woocommerce-appointments' ),
        	'price'                 => __( 'Price', 'woocommerce-appointments' ),
        	// WooCommerce tax labels (same slugs as WC()->countries->ex_tax_or_vat() / inc_tax_or_vat()).
        	'priceExclTaxShort'     => ( function_exists( 'WC' ) && WC()->countries ) ? WC()->countries->ex_tax_or_vat() : __( 'excl. tax', 'woocommerce-appointments' ),
        	'priceInclTaxShort'     => ( function_exists( 'WC' ) && WC()->countries ) ? WC()->countries->inc_tax_or_vat() : __( 'incl. tax', 'woocommerce-appointments' ),
        	'pricing'               => __( 'Pricing', 'woocommerce-appointments' ),
        	'cost'                  => __( 'Cost', 'woocommerce-appointments' ),
        	'tax'                   => __( 'Tax', 'woocommerce-appointments' ),
        	'order_total'           => __( 'Order Total', 'woocommerce-appointments' ),
        	'discount'              => __( 'Discount', 'woocommerce-appointments' ),
        	'coupon'                => __( 'Coupon', 'woocommerce-appointments' ),
        	'coupons'               => __( 'Coupons', 'woocommerce-appointments' ),
        	'timezones'             => __( 'Timezones', 'woocommerce-appointments' ),
        	'customerTimezone'      => __( "Customer's Timezone", 'woocommerce-appointments' ),
        	'bookingTimezone'       => __( 'Booking Timezone', 'woocommerce-appointments' ),
        	'currencySymbols'       => self::get_currency_symbols_map(),
        	'currencyFormat'        => [
        		'decimalSeparator'  => wc_get_price_decimal_separator(),
        		'thousandSeparator' => wc_get_price_thousand_separator(),
        		'priceDecimals'     => wc_get_price_decimals(),
        		'currencyPosition'  => get_option( 'woocommerce_currency_pos' ),
        	],
        ];
    }

    /**
     * Get available payment methods for the admin creation panel dropdown.
     *
     * @return list<array{id: string, title: string}>
     */
    private static function get_available_payment_methods(): array {
        $gateways_instance = WC()->payment_gateways();
        $payment_gateways  = [];
        if ( $gateways_instance ) {
            if ( is_array( $gateways_instance->payment_gateways ) ) {
                $payment_gateways = $gateways_instance->payment_gateways;
            } elseif ( method_exists( $gateways_instance, 'payment_gateways' ) ) {
                $payment_gateways = $gateways_instance->payment_gateways();
            }
        }
        $payment_gateways = is_array( $payment_gateways ) ? $payment_gateways : [];
        $list             = [];
        foreach ( $payment_gateways as $gateway ) {
            if ( ! is_object( $gateway ) || 'yes' !== $gateway->enabled ) {
                continue;
            }
            if ( 'wcappointmentsgateway' === $gateway->id ) {
                continue;
            }
            $list[] = [
            	'id'    => $gateway->id,
            	'title' => $gateway->get_title(),
            ];
        }
        $list[] = [
        	'id'    => 'other',
        	'title' => __( 'Other', 'woocommerce-appointments' ),
        ];
        return $list;
    }
}
