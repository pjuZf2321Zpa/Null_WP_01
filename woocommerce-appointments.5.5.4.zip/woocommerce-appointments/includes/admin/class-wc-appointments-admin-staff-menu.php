<?php
/**
 * Staff Admin Menu
 *
 * Customizes the WordPress admin menu for staff members.
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Staff_Menu class.
 */
class WC_Appointments_Admin_Staff_Menu {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'customize_staff_menu' ], 999 );
		add_action( 'admin_init', [ $this, 'check_product_access' ] );
		add_filter( 'admin_footer_text', [ $this, 'customize_footer_text' ] );
		add_action( 'admin_head', [ $this, 'add_pending_badge' ] );
		add_action( 'admin_bar_menu', [ $this, 'customize_admin_bar' ], 999 );
		add_action( 'wp_dashboard_setup', [ $this, 'remove_dashboard_widgets' ], 999 );
		add_filter( 'user_has_cap', [ $this, 'grant_staff_product_caps' ], 10, 4 );
		
		// Register common staff admin styles
		add_action( 'init', [ $this, 'register_assets' ] );
	}

	/**
	 * Grant product editing capabilities when staff has manage_products permission.
	 *
	 * @param array<string, bool>   $allcaps All capabilities for the user.
	 * @param array<string, mixed>   $caps    Required primitive capabilities.
	 * @param array<string, mixed>   $args    Arguments that accompany the capability check.
	 * @param WP_User $user    User object.
	 * @return array<string, mixed>
	 */
	public function grant_staff_product_caps( array $allcaps, array $caps, array $args, $user ): array {
		static $is_processing = false;

		if ( ! ( $user instanceof WP_User ) ) {
			return $allcaps;
		}

		$requested_cap = isset( $args[0] ) && is_string( $args[0] ) ? $args[0] : '';

		$product_meta_caps = [
			'edit_product',
			'read_product',
			'delete_product',
		];

		$product_primitive_caps = [
			'edit_products',
			'edit_others_products',
			'edit_published_products',
			'edit_private_products',
			'publish_products',
			'read_private_products',
			'delete_products',
			'delete_others_products',
			'delete_published_products',
			'delete_private_products',
			'create_products',
		];

		if ( ! in_array( $requested_cap, $product_meta_caps, true ) && 0 === count( array_intersect( $caps, $product_primitive_caps ) ) ) {
			return $allcaps;
		}

		if ( $is_processing ) {
			return $allcaps;
		}

		if ( ! WC_Appointments_Staff_Permissions::is_staff_user( (int) $user->ID ) ) {
			return $allcaps;
		}

		$is_processing = true;
		$can_manage_products = WC_Appointments_Staff_Permissions::can( (int) $user->ID, 'manage_products' );
		$is_processing = false;

		if ( ! $can_manage_products ) {
			return $allcaps;
		}

		foreach ( $product_primitive_caps as $cap ) {
			$allcaps[ $cap ] = true;
		}

		return $allcaps;
	}

	/**
	 * Register common staff admin assets.
	 */
	public function register_assets(): void {
		// Register common staff admin style
		wp_register_style(
			'wca-staff-common',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin-staff-common.css',
			[ 'woocommerce_admin_styles' ],
			WC_APPOINTMENTS_VERSION
		);
	}

	/**
	 * Check if staff has permission to access product, order, and location pages.
	 * Redirects to appointments page if access is denied.
	 */
	public function check_product_access(): void {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return;
		}

		// Don't check on AJAX requests.
		if ( wp_doing_ajax() ) {
			return;
		}

		global $pagenow;

		$is_product_page  = false;
		$is_order_page    = false;
		$is_location_page = false;
		$is_resource_page = false;

		if ( 'post-new.php' === $pagenow ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$post_type = isset( $_GET['post_type'] ) ? sanitize_text_field( wp_unslash( $_GET['post_type'] ) ) : '';
			$is_product_page  = 'product' === $post_type;
			$is_order_page    = 'shop_order' === $post_type;
			$is_location_page = 'wca_location' === $post_type;
			$is_resource_page = 'wca_resource' === $post_type;
		} elseif ( 'post.php' === $pagenow ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
			if ( $post_id ) {
				$post = get_post( $post_id );
				$is_product_page  = $post && 'product' === $post->post_type;
				$is_order_page    = $post && 'shop_order' === $post->post_type;
				$is_location_page = $post && 'wca_location' === $post->post_type;
				$is_resource_page = $post && 'wca_resource' === $post->post_type;
			}
		} elseif ( 'edit.php' === $pagenow ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$post_type = isset( $_GET['post_type'] ) ? sanitize_text_field( wp_unslash( $_GET['post_type'] ) ) : '';
			$is_product_page  = 'product' === $post_type;
			$is_order_page    = 'shop_order' === $post_type;
			$is_location_page = 'wca_location' === $post_type;
			$is_resource_page = 'wca_resource' === $post_type;
		}

		$user_id = get_current_user_id();

		if ( $is_product_page && ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_products' ) ) {
			wp_safe_redirect( admin_url( 'edit.php?post_type=wc_appointment' ) );
			exit;
		}

		if ( $is_location_page && ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_locations' ) ) {
			wp_safe_redirect( admin_url( 'edit.php?post_type=wc_appointment' ) );
			exit;
		}

		if ( $is_resource_page && ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_resources' ) ) {
			wp_safe_redirect( admin_url( 'edit.php?post_type=wc_appointment' ) );
			exit;
		}

		if ( $is_order_page && ! WC_Appointments_Staff_Permissions::can( $user_id, 'view_orders' ) ) {
			wp_safe_redirect( admin_url( 'edit.php?post_type=wc_appointment' ) );
			exit;
		}

		if ( $is_order_page && WC_Appointments_Staff_Permissions::can( $user_id, 'view_orders' ) ) {
			$is_editing_action = ( 'post-new.php' === $pagenow ) ||
								( 'post.php' === $pagenow && isset( $_GET['action'] ) && 'edit' === $_GET['action'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			if ( $is_editing_action && ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_orders' ) ) {
				wp_safe_redirect( admin_url( 'edit.php?post_type=shop_order' ) );
				exit;
			}
		}
	}

	/**
	 * Customize admin menu for staff users.
	 */
	public function customize_staff_menu(): void {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return;
		}

		global $menu, $submenu;

		$user_id = get_current_user_id();

		// Items to keep for staff.
		$allowed_menus = [
			'index.php',                           // WP Dashboard (staff widgets live here).
			'edit.php?post_type=wc_appointment',  // Appointments.
		];

		// Conditionally allow Products management.
		if ( WC_Appointments_Staff_Permissions::can( $user_id, 'manage_products' ) ) {
			$allowed_menus[] = 'edit.php?post_type=product';
		}

		// Conditionally allow Orders management.
		if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_orders' ) ) {
			$allowed_menus[] = 'edit.php?post_type=shop_order';
		}

		// Remove disallowed menus - including the default dashboard.
		if ( is_array( $menu ) ) {
			foreach ( $menu as $key => $item ) {
				if ( isset( $item[2] ) && ! in_array( $item[2], $allowed_menus, true ) ) {
					remove_menu_page( $item[2] );
				}
			}
		}

		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_locations' ) ) {
			remove_submenu_page( 'edit.php?post_type=wc_appointment', 'edit.php?post_type=wca_location' );
		}

		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_resources' ) ) {
			remove_submenu_page( 'edit.php?post_type=wc_appointment', 'edit.php?post_type=wca_resource' );
		}

		// Add a standalone top-level Profile menu for staff.
		add_menu_page(
			__( 'Profile', 'woocommerce-appointments' ),
			__( 'Profile', 'woocommerce-appointments' ),
			'read',
			'profile.php',
			'',
			'dashicons-admin-users',
			71
		);

		// Add staff-specific submenus.
		$this->add_staff_submenus();
	}

	/**
	 * Add staff-specific submenu items.
	 * 
	 * Note: Availability and Services are managed via the staff profile page
	 * to provide a unified, simpler experience.
	 */
	private function add_staff_submenus(): void {
		$user_id = get_current_user_id();

		// Add customers page if permission is granted.
		if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_customers' ) ) {
			add_submenu_page(
				'edit.php?post_type=wc_appointment',
				__( 'Customers', 'woocommerce-appointments' ),
				__( 'Customers', 'woocommerce-appointments' ),
				'manage_appointments',
				'wca-staff-customers',
				[ $this, 'render_customers_page' ]
			);
		}
	}

	/**
	 * Render the staff customers page.
	 */
	public function render_customers_page(): void {
		$user_id = get_current_user_id();

		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'view_customers' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'woocommerce-appointments' ) );
		}

		// Enqueue common staff admin styles
		wp_enqueue_style( 'wca-staff-common' );

		$can_view_all = WC_Appointments_Staff_Permissions::can( $user_id, 'view_all_customers' );
		$can_view_history = WC_Appointments_Staff_Permissions::can( $user_id, 'view_customer_history' );
		$can_contact = WC_Appointments_Staff_Permissions::can( $user_id, 'contact_customers' );

		$customers = $this->get_staff_customers( $user_id, $can_view_all );

		$show_timezone_column = class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', $user_id );

		include __DIR__ . '/views/html-staff-customers.php';
	}

	/**
	 * Get customers for a staff member.
	 *
	 * @param int  $user_id      Staff user ID.
	 * @param bool $view_all     Whether to view all customers.
	 * @return list<array{id: int, name: string, email: string, phone: string, avatar: string, appointment_count: int, last_appointment: int, timezone_string: string}>
	 */
	private function get_staff_customers( int $user_id, bool $view_all = false ): array {
		/** @var list<array{id: int, name: string, email: string, phone: string, avatar: string, appointment_count: int, last_appointment: int, timezone_string: string}> $customers */
		$customers = [];
		$seen      = [];

		// Get appointment IDs for this staff member.
		$args = [
			'status'   => get_wc_appointment_statuses( 'scheduled' ),
			'limit'    => 500,
			'order_by' => 'start_date',
			'order'    => 'DESC',
		];

		if ( ! $view_all ) {
			$args['object_id']   = $user_id;
			$args['object_type'] = 'staff';
		}

		$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_by( $args );

		foreach ( $appointment_ids as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment ) {
				continue;
			}

			$customer = $appointment->get_customer();
			if ( ! $customer ) {
				continue;
			}

			$customer_key = $customer->user_id ? 'user_' . $customer->user_id : 'email_' . md5( $customer->email );

			if ( isset( $seen[ $customer_key ] ) ) {
				$customers[ $seen[ $customer_key ] ]['appointment_count']++;
				$customers[ $seen[ $customer_key ] ]['last_appointment'] = max(
					$customers[ $seen[ $customer_key ] ]['last_appointment'],
					$appointment->get_start()
				);
				continue;
			}

			$seen[ $customer_key ] = count( $customers );
			$timezone_string       = '';
			if ( $customer->user_id && class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) ) {
				$timezone_string = WC_Appointments_Timezone_Helper::get_user_timezone( $customer->user_id );
			}
			$customers[] = [
				'id'                => $customer->user_id,
				'name'              => $customer->name ?: __( 'Guest', 'woocommerce-appointments' ),
				'email'             => $customer->email,
				'phone'             => $customer->phone ?? '',
				'avatar'            => $customer->user_id ? get_avatar_url( $customer->user_id, [ 'size' => 48 ] ) : '',
				'appointment_count' => 1,
				'last_appointment'  => $appointment->get_start(),
				'timezone_string'   => $timezone_string,
			];
		}

		// Sort by appointment count descending.
		if ( [] !== $customers ) {
			$counts = array_column( $customers, 'appointment_count' );
			array_multisort( $counts, SORT_DESC, $customers );
		}

		return $customers;
	}


	/**
	 * Add pending appointment badge to menu.
	 */
	public function add_pending_badge(): void {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return;
		}

		$user_id = get_current_user_id();

		// Get pending count.
		$pending_appointments = WC_Appointment_Data_Store::get_appointment_ids_by( [
			'object_id'   => $user_id,
			'object_type' => 'staff',
			'status'      => [ 'pending-confirmation' ],
		] );

		$pending_count = is_array( $pending_appointments ) ? count( $pending_appointments ) : 0;

		if ( $pending_count > 0 ) {
			?>
			<script>
			jQuery(document).ready(function($) {
				var $menuItem = $('#menu-posts-wc_appointment .wp-submenu a[href*="appointment_calendar"]');
				if ($menuItem.length) {
					$menuItem.append(' <span class="awaiting-mod count-<?php echo esc_js( $pending_count ); ?>"><span class="pending-count"><?php echo esc_js( $pending_count ); ?></span></span>');
				}
			});
			</script>
			<?php
		}
	}

	/**
	 * Customize admin footer text for staff.
	 *
	 * @param string|null $text Default footer text.
	 * @return string
	 */
	public function customize_footer_text( ?string $text ): string {
		// WordPress may pass `null` to the `admin_footer_text` filter in some admin contexts.
		$text = (string) $text;

		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return $text;
		}

		return sprintf(
			/* translators: %s: Plugin name */
			__( 'Thank you for using %s Staff Portal', 'woocommerce-appointments' ),
			'WooCommerce Appointments'
		);
	}

	/**
	 * Customize admin bar for staff users.
	 * Removes items staff shouldn't see (like creating posts, comments, etc.)
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Admin bar instance.
	 */
	public function customize_admin_bar( $wp_admin_bar ): void {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return;
		}

		$user_id = get_current_user_id();

		// Remove "New" menu items staff shouldn't have access to.
		$wp_admin_bar->remove_node( 'new-post' );
		$wp_admin_bar->remove_node( 'new-page' );
		$wp_admin_bar->remove_node( 'new-media' );
		$wp_admin_bar->remove_node( 'new-link' );
		$wp_admin_bar->remove_node( 'new-user' );

		// Remove product creation if staff doesn't have permission
		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_products' ) ) {
			$wp_admin_bar->remove_node( 'new-product' );
		}

		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_locations' ) ) {
			$wp_admin_bar->remove_node( 'new-wca_location' );
		}

		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_resources' ) ) {
			$wp_admin_bar->remove_node( 'new-wca_resource' );
		}

		// Remove order creation if staff doesn't have permission
		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'manage_orders' ) ) {
			$wp_admin_bar->remove_node( 'new-shop_order' );
		}

		// Remove comments.
		$wp_admin_bar->remove_node( 'comments' );

		// Remove updates.
		$wp_admin_bar->remove_node( 'updates' );

		// Remove site menu items.
		$wp_admin_bar->remove_node( 'site-name' );
		$wp_admin_bar->remove_node( 'view-site' );
		// Keep 'dashboard' node — it now points to the WP dashboard with our widgets.
		$wp_admin_bar->remove_node( 'menus' );
		$wp_admin_bar->remove_node( 'customize' );
		$wp_admin_bar->remove_node( 'themes' );
		$wp_admin_bar->remove_node( 'widgets' );

		// Check if staff can create appointments - if not, remove new-wc_appointment.
		if ( ! WC_Appointments_Staff_Permissions::can( $user_id, 'create_appointments' ) ) {
			$wp_admin_bar->remove_node( 'new-wc_appointment' );
		}

		// Add staff-specific menu item for appointments.
		$wp_admin_bar->add_node( [
			'id'    => 'wca-appointments',
			'title' => '<span class="ab-icon dashicons-calendar-alt"></span>' . __( 'Appointments', 'woocommerce-appointments' ),
			'href'  => admin_url( 'edit.php?post_type=wc_appointment&page=appointment_calendar' ),
			'meta'  => [ 'class' => 'wca-staff-menu-item' ],
		] );

		// Add submenu for staff dashboard.
		$wp_admin_bar->add_node( [
			'id'     => 'wca-dashboard',
			'parent' => 'wca-appointments',
			'title'  => __( 'Dashboard', 'woocommerce-appointments' ),
			'href'   => admin_url( 'index.php' ),
		] );

		// Add submenu for calendar.
		if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_calendar' ) ) {
			$wp_admin_bar->add_node( [
				'id'     => 'wca-calendar',
				'parent' => 'wca-appointments',
				'title'  => __( 'Calendar', 'woocommerce-appointments' ),
				'href'   => admin_url( 'edit.php?post_type=wc_appointment&page=appointment_calendar' ),
			] );
		}

		// Add submenu for list view.
		if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_appointments_list' ) ) {
			$wp_admin_bar->add_node( [
				'id'     => 'wca-list',
				'parent' => 'wca-appointments',
				'title'  => __( 'All Appointments', 'woocommerce-appointments' ),
				'href'   => admin_url( 'edit.php?post_type=wc_appointment' ),
			] );
		}

		// Add submenu for customers if permitted.
		if ( WC_Appointments_Staff_Permissions::can( $user_id, 'view_customers' ) ) {
			$wp_admin_bar->add_node( [
				'id'     => 'wca-customers',
				'parent' => 'wca-appointments',
				'title'  => __( 'Customers', 'woocommerce-appointments' ),
				'href'   => admin_url( 'edit.php?post_type=wc_appointment&page=wca-staff-customers' ),
			] );
		}
	}

	/**
	 * Remove default dashboard widgets for staff users.
	 * Staff use the WP dashboard with custom appointment widgets.
	 * Remove default widgets to keep the dashboard clean and focused.
	 */
	public function remove_dashboard_widgets(): void {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user() ) {
			return;
		}

		// Remove WordPress default widgets.
		remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
		remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
		remove_meta_box( 'dashboard_secondary', 'dashboard', 'side' );
		remove_meta_box( 'dashboard_right_now', 'dashboard', 'normal' );
		remove_meta_box( 'dashboard_activity', 'dashboard', 'normal' );
		remove_meta_box( 'dashboard_incoming_links', 'dashboard', 'normal' );
		remove_meta_box( 'dashboard_plugins', 'dashboard', 'normal' );
		remove_meta_box( 'dashboard_recent_drafts', 'dashboard', 'side' );
		remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
		remove_meta_box( 'dashboard_site_health', 'dashboard', 'normal' );

		// Remove WooCommerce widgets.
		remove_meta_box( 'woocommerce_dashboard_status', 'dashboard', 'normal' );
		remove_meta_box( 'woocommerce_dashboard_recent_reviews', 'dashboard', 'normal' );

		// Remove Jetpack widgets.
		remove_meta_box( 'jetpack_summary_widget', 'dashboard', 'normal' );
	}

}
