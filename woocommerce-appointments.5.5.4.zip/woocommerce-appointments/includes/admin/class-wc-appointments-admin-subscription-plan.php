<?php
/**
 * Admin fields for appointment membership on WCS subscription products.
 *
 * @package WooCommerce\Appointments\Admin
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Subscription product appointment plan settings.
 */
class WC_Appointments_Admin_Subscription_Plan {

	const TAB_PANEL_ID = 'wca_subscription_appointment_plan';

	/**
	 * @since 5.4.0
	 */
	public function __construct() {
		if ( ! class_exists( 'WC_Subscriptions' ) ) {
			return;
		}

		add_action( 'plugins_loaded', array( $this, 'register_hooks' ), 25 );
	}

	/**
	 * Register product edit hooks after WCS and integration helpers are available.
	 * @return void
	 */
	public function register_hooks() {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return;
		}

		$this->load_dependencies();

		add_action( 'woocommerce_product_write_panel_tabs', array( $this, 'render_tab' ), 25 );
		add_action( 'woocommerce_product_data_panels', array( $this, 'render_panel' ), 25 );
		add_action( 'woocommerce_admin_process_product_object', array( $this, 'save_product_meta' ), 25 );
	}

	/**
	 * Load subscription plan helpers for admin (no full integration bootstrap required).
	 * @return void
	 */
	protected function load_dependencies() {
		if ( class_exists( 'WC_Appointments_Integration_Subscription_Plan' ) ) {
			return;
		}

		include_once WC_APPOINTMENTS_ABSPATH . 'includes/integrations/woocommerce-subscriptions/class-wc-appointments-integration-subscription-entitlement.php';
	}

	/**
	 * Resolve the product being edited on the admin product screen.
	 *
	 * @return WC_Product|null
	 */
	protected function get_admin_product() {
		global $post;

		if ( ! $post || 'product' !== $post->post_type ) {
			return null;
		}

		$product = wc_get_product( $post );
		return ( $product instanceof WC_Product ) ? $product : null;
	}

	/**
	 * Appointments tab on subscription product edit screen (same pattern as Deposits / Add-ons).
	 * @return void
	 */
	public function render_tab() {
		printf(
			'<li class="wca_subscription_appointments_tab show_if_subscription show_if_variable-subscription hide_if_grouped hide_if_external"><a href="#%1$s"><span>%2$s</span></a></li>',
			esc_attr( self::TAB_PANEL_ID ),
			esc_html__( 'Appointments', 'woocommerce-appointments' )
		);
	}

	/**
	 * Appointments panel for subscription membership plan settings.
	 * @return void
	 */
	public function render_panel() {
		$this->load_dependencies();

		$product_object = $this->get_admin_product();
		if ( ! $product_object ) {
			return;
		}

		printf( '<div id="%s" class="panel woocommerce_options_panel">', esc_attr( self::TAB_PANEL_ID ) );
		include __DIR__ . '/views/html-subscription-appointment-plan.php';
		echo '</div>';
	}

	/**
	 * Unslashed POST payload (WooCommerce product save verifies nonce).
	 *
	 * @return array<string, mixed>
	 */
	private function get_product_post_data(): array {
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field below.
	}

	/**
	 * @param WC_Product $product Product.
	 * @return void
	 */
	public function save_product_meta( $product ) {
		$this->load_dependencies();

		if ( ! WC_Appointments_Integration_Subscription_Plan::is_wcs_subscription_product( $product ) ) {
			return;
		}

		$posted     = $this->get_product_post_data();
		$membership = isset( $posted[ WC_Appointments_Integration_Subscription_Plan::META_MEMBERSHIP ] ) ? 'yes' : 'no';
		$product->update_meta_data( WC_Appointments_Integration_Subscription_Plan::META_MEMBERSHIP, $membership );

		$old_unlimited = WC_Appointments_Integration_Subscription_Plan::is_unlimited( $product );
		$old_grant     = WC_Appointments_Integration_Subscription_Plan::appointments_per_period( $product );

		$rollover = isset( $posted[ WC_Appointments_Integration_Subscription_Plan::META_ROLLOVER ] ) ? 'yes' : 'no';
		$product->update_meta_data( WC_Appointments_Integration_Subscription_Plan::META_ROLLOVER, $rollover );

		$per_period_options = WC_Appointments_Integration_Subscription_Plan::get_appointments_per_period_options();
		$per_period_mode    = sanitize_text_field( $posted['_wca_appointments_per_period_mode'] ?? '4' );

		if ( 'unlimited' === $per_period_mode ) {
			$unlimited  = 'yes';
			$per_period = 4;
		} elseif ( 'custom' === $per_period_mode ) {
			$unlimited  = 'no';
			$per_period = isset( $posted[ WC_Appointments_Integration_Subscription_Plan::META_APPOINTMENTS_PER_PERIOD ] )
				? max( 1, min( 365, (int) $posted[ WC_Appointments_Integration_Subscription_Plan::META_APPOINTMENTS_PER_PERIOD ] ) )
				: 4;
		} elseif ( isset( $per_period_options[ $per_period_mode ] ) && ctype_digit( $per_period_mode ) ) {
			$unlimited  = 'no';
			$per_period = (int) $per_period_mode;
		} else {
			$unlimited  = 'no';
			$per_period = 4;
		}

		$product->update_meta_data( WC_Appointments_Integration_Subscription_Plan::META_UNLIMITED, $unlimited );
		$product->update_meta_data( WC_Appointments_Integration_Subscription_Plan::META_APPOINTMENTS_PER_PERIOD, $per_period );

		if ( 'yes' === $membership && ( $old_unlimited !== ( 'yes' === $unlimited ) || ( 'yes' !== $unlimited && $old_grant !== $per_period ) ) ) {
			WC_Appointments_Integration_Subscription_Entitlement::sync_balances_for_plan_grant_change( $product, $old_unlimited ? 0 : $old_grant, 'yes' === $unlimited ? 0 : $per_period );
		}

		$eligible = array();
		if ( isset( $posted['_wca_eligible_appointment_products'] ) && is_array( $posted['_wca_eligible_appointment_products'] ) ) {
			$eligible = array_values( array_unique( array_filter( array_map( 'absint', $posted['_wca_eligible_appointment_products'] ) ) ) );
		}
		$product->update_meta_data( WC_Appointments_Integration_Subscription_Plan::META_ELIGIBLE_PRODUCTS, implode( ',', $eligible ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}
}

new WC_Appointments_Admin_Subscription_Plan();

