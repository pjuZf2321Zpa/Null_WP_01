<?php
/**
 * Availability hub admin page.
 *
 * One shell load + bootstrap JSON; client paints layer editors.
 *
 * @package WooCommerce_Appointments
 */

defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Admin_Availability_Hub
 */
class WC_Appointments_Admin_Availability_Hub {

	public const PAGE_SLUG = 'wc-appointments-availability';

	/**
	 * Cached bootstrap payload for this request (enqueue + render share one build).
	 *
	 * @var array<string, mixed>|null
	 */
	private static $bootstrap_cache = null;

	/**
	 * Hook menu, assets, AJAX, Screen Options.
	 */
	public static function init(): void {
		add_action( 'admin_menu', [ __CLASS__, 'register_menu' ], 50 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_action( 'wp_ajax_wc_appointments_availability_hub_save', [ __CLASS__, 'ajax_save' ] );
		add_action( 'wp_ajax_wc_appointments_availability_hub_screen_option', [ __CLASS__, 'ajax_screen_option' ] );
		add_filter( 'woocommerce_screen_ids', [ __CLASS__, 'screen_ids' ] );
		add_action( 'load-wc_appointment_page_' . self::PAGE_SLUG, [ __CLASS__, 'handle_screen_options' ] );
		add_filter( 'screen_settings', [ __CLASS__, 'screen_settings' ], 10, 2 );
		add_filter( 'screen_options_show_screen', [ __CLASS__, 'show_screen_options' ] );
	}

	/**
	 * @param list<string> $ids Screen IDs.
	 * @return list<string>
	 */
	public static function screen_ids( array $ids ): array {
		$ids[] = 'wc_appointment_page_' . self::PAGE_SLUG;
		return $ids;
	}

	/**
	 * Register Appointments → Availability.
	 */
	public static function register_menu(): void {
		if ( ! WC_Appointments_Staff_Permissions::can_access_availability_hub() ) {
			return;
		}
		add_submenu_page(
			'edit.php?post_type=wc_appointment',
			__( 'Availability', 'woocommerce-appointments' ),
			__( 'Availability', 'woocommerce-appointments' ),
			'manage_appointments',
			self::PAGE_SLUG,
			[ __CLASS__, 'render_page' ]
		);
	}

	/**
	 * Whether the current screen is the hub.
	 */
	public static function is_hub_screen(): bool {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();
		return $screen && ( 'wc_appointment_page_' . self::PAGE_SLUG ) === $screen->id;
	}

	/**
	 * Persist Screen Options for this hub.
	 */
	public static function handle_screen_options(): void {
		if ( ! isset( $_POST['screenoptionnonce'] ) ) {
			return;
		}
		check_admin_referer( 'screen-options-nonce', 'screenoptionnonce' );
		$uid = get_current_user_id();
		update_user_meta( $uid, 'wc_appointments_hub_show_priority', isset( $_POST['wca_hub_show_priority'] ) ? '1' : '0' );
		update_user_meta( $uid, 'wc_appointments_hub_show_status', isset( $_POST['wca_hub_show_status'] ) ? '1' : '0' );
		update_user_meta( $uid, 'wc_appointments_hub_show_title', isset( $_POST['wca_hub_show_title'] ) ? '1' : '0' );
	}

	/**
	 * Keep Screen Options visible on the hub (no per_page option registered).
	 *
	 * @param bool $show Whether to show Screen Options.
	 * @return bool
	 */
	public static function show_screen_options( $show ) {
		return self::is_hub_screen() ? true : $show;
	}

	/**
	 * Screen Options: optional rule table columns.
	 *
	 * @param string         $settings Existing HTML.
	 * @param WP_Screen|null $screen   Current screen.
	 */
	public static function screen_settings( $settings, $screen ): string {
		if ( ! $screen || ( 'wc_appointment_page_' . self::PAGE_SLUG ) !== $screen->id ) {
			return (string) $settings;
		}
		$pri = self::user_wants_priority() ? ' checked="checked"' : '';
		$st  = self::user_wants_status() ? ' checked="checked"' : '';
		$ti  = self::user_wants_title() ? ' checked="checked"' : '';
		$html  = '<fieldset class="metabox-prefs">';
		$html .= '<legend>' . esc_html__( 'Availability', 'woocommerce-appointments' ) . '</legend>';
		$html .= '<label><input type="checkbox" name="wca_hub_show_status" value="1"' . $st . ' /> ';
		$html .= esc_html__( 'Show status', 'woocommerce-appointments' ) . '</label> ';
		$html .= '<label><input type="checkbox" name="wca_hub_show_title" value="1"' . $ti . ' /> ';
		$html .= esc_html__( 'Show title', 'woocommerce-appointments' ) . '</label> ';
		$html .= '<label><input type="checkbox" name="wca_hub_show_priority" value="1"' . $pri . ' /> ';
		$html .= esc_html__( 'Show priority', 'woocommerce-appointments' ) . '</label>';
		$html .= '</fieldset>';
		return (string) $settings . $html;
	}

	/**
	 * Whether the current user shows the priority column.
	 *
	 * Explicit Screen Options win. Unset: site default from Install (off on fresh installs,
	 * on on upgrades). Lazy-fills that option if an upgrade has not re-run Install yet.
	 */
	public static function user_wants_priority(): bool {
		$raw = get_user_meta( get_current_user_id(), 'wc_appointments_hub_show_priority', true );
		if ( '' !== $raw && false !== $raw ) {
			return '1' === (string) $raw;
		}
		$flag = get_option( 'wc_appointments_hub_priority_default', '' );
		if ( '' === $flag ) {
			$flag = get_option( 'wc_appointments_version' ) ? '1' : '0';
			add_option( 'wc_appointments_hub_priority_default', $flag );
		}
		return '1' === (string) $flag;
	}

	/**
	 * Whether the current user shows the status column (on by default until explicitly off).
	 */
	public static function user_wants_status(): bool {
		return '0' !== (string) get_user_meta( get_current_user_id(), 'wc_appointments_hub_show_status', true );
	}

	/**
	 * Whether the current user shows the title column (on by default until explicitly off).
	 */
	public static function user_wants_title(): bool {
		return '0' !== (string) get_user_meta( get_current_user_id(), 'wc_appointments_hub_show_title', true );
	}

	/**
	 * Default hub layer when the URL has none (submenu entry). May change later.
	 */
	public const DEFAULT_LAYER = 'global';

	/**
	 * Hub page URL with optional layer/id/rule.
	 *
	 * Bare page (no layer) when $layer is empty - used for pageUrl / submenu-style entry.
	 * Pass an explicit layer (including DEFAULT_LAYER) for deep links.
	 *
	 * @param string     $layer   Layer key, or '' for the bare hub URL.
	 * @param string|int $id      Entity id.
	 * @param string|int $rule_id Availability rule id (scrolls/focuses that row).
	 */
	public static function url( string $layer = '', $id = '', $rule_id = '' ): string {
		$args = [
			'post_type' => 'wc_appointment',
			'page'      => self::PAGE_SLUG,
		];
		if ( '' !== $layer ) {
			$args['layer'] = $layer;
		}
		if ( '' !== $id && null !== $id ) {
			$args['id'] = $id;
		}
		$rule_id = absint( $rule_id );
		if ( $rule_id > 0 ) {
			$args['rule'] = $rule_id;
		}
		return add_query_arg( $args, admin_url( 'edit.php' ) );
	}

	/**
	 * Hub deep link that opens in a new tab (edit screen stays put).
	 *
	 * @param string $url   From ::url().
	 * @param string $label Visible link text.
	 */
	public static function external_anchor( string $url, string $label ): string {
		return sprintf(
			'<a class="wca-hub-ext" href="%1$s" target="_blank" rel="noopener noreferrer">%2$s<span class="dashicons dashicons-external" aria-hidden="true"></span></a>',
			esc_url( $url ),
			esc_html( $label )
		);
	}

	/**
	 * Product Availability tab: same week strip as the hub + one hub deeplink.
	 *
	 * @param WC_Product_Appointment $product Product being edited.
	 */
	public static function product_tab_hours_html( WC_Product_Appointment $product ): string {
		$id     = wc_appointments_get_product_id_for_availability( (int) $product->get_id() );
		$hub_ok = $id > 0 && 'auto-draft' !== get_post_status( $id );
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$css    = WC_APPOINTMENTS_ABSPATH . 'assets/css/admin-availability-hub.css';
		$js     = WC_APPOINTMENTS_ABSPATH . 'assets/js/admin-availability-week' . $suffix . '.js';

		wp_enqueue_style(
			'wc-appointments-availability-hub',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin-availability-hub.css',
			[ 'wc_appointments_admin_styles' ],
			file_exists( $css ) ? (string) filemtime( $css ) : WC_APPOINTMENTS_VERSION
		);
		wp_enqueue_script(
			'wc-appointments-availability-week',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/admin-availability-week' . $suffix . '.js',
			[],
			file_exists( $js ) ? (string) filemtime( $js ) : WC_APPOINTMENTS_VERSION,
			true
		);
		wp_localize_script(
			'wc-appointments-availability-week',
			'wcaProductAvailabilityWeek',
			[
				'mount'       => '#wca-product-week',
				'productRows' => $hub_ok ? self::rules_for_kind( WC_Appointments_Availability::KIND_PRODUCT, $id ) : [],
				'globalRows'  => self::rules_for_kind( WC_Appointments_Availability::KIND_GLOBAL, 0 ),
				'daily'       => 'day' === $product->get_duration_unit(),
				'dayShort'    => self::day_short_labels(),
				'startOfWeek' => (int) get_option( 'start_of_week', 1 ),
				'i18n'        => [
					'weekAria' => __( 'Open days', 'woocommerce-appointments' ),
					'closed'   => _x( 'Closed', 'availability status label (adjective), not a button', 'woocommerce-appointments' ),
					'allDay'   => __( 'All day', 'woocommerce-appointments' ),
				],
			]
		);

		$hub = self::external_anchor(
			$hub_ok ? self::url( 'product', $id ) : self::url( 'global' ),
			__( 'Availability hub', 'woocommerce-appointments' )
		);
		if ( $hub_ok ) {
			$text = sprintf(
				/* translators: %s: Availability hub link */
				esc_html__( 'Open hours and unavailable times for this product are managed in the %s.', 'woocommerce-appointments' ),
				$hub
			);
		} else {
			$text = sprintf(
				/* translators: %s: Availability hub link */
				esc_html__( 'Save the product (a draft is fine) to set product hours in the %s.', 'woocommerce-appointments' ),
				$hub
			);
		}

		return '<div id="wca-product-week" class="wca-week-host"></div><p class="description">' . wp_kses_post( $text ) . '</p>';
	}

	/**
	 * @return array<int, string> Keys 1-7 (Mon-Sun); PHP casts numeric string keys to int.
	 */
	private static function day_short_labels(): array {
		return [
			1 => __( 'Mon', 'woocommerce-appointments' ),
			2 => __( 'Tue', 'woocommerce-appointments' ),
			3 => __( 'Wed', 'woocommerce-appointments' ),
			4 => __( 'Thu', 'woocommerce-appointments' ),
			5 => __( 'Fri', 'woocommerce-appointments' ),
			6 => __( 'Sat', 'woocommerce-appointments' ),
			7 => __( 'Sun', 'woocommerce-appointments' ),
		];
	}

	/**
	 * Enqueue hub assets only on this screen.
	 *
	 * @param string $hook Hook suffix.
	 */
	public static function enqueue( $hook ): void {
		if ( 'wc_appointment_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}

		$suffix   = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$css_path = WC_APPOINTMENTS_ABSPATH . 'assets/css/admin-availability-hub.css';
		$week_js  = WC_APPOINTMENTS_ABSPATH . 'assets/js/admin-availability-week' . $suffix . '.js';
		$js_path  = WC_APPOINTMENTS_ABSPATH . 'assets/js/admin-availability-hub' . $suffix . '.js';
		$css_ver  = file_exists( $css_path ) ? (string) filemtime( $css_path ) : WC_APPOINTMENTS_VERSION;
		$js_ver   = file_exists( $js_path ) ? (string) filemtime( $js_path ) : WC_APPOINTMENTS_VERSION;

		wp_enqueue_style( 'jquery-ui-style' );
		wp_enqueue_style(
			'wc_appointments_admin_styles',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin.css',
			[],
			(string) filemtime( WC_APPOINTMENTS_ABSPATH . 'assets/css/admin.css' )
		);
		wp_enqueue_style(
			'wc-appointments-availability-hub',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin-availability-hub.css',
			[ 'jquery-ui-style', 'wc_appointments_admin_styles' ],
			$css_ver
		);
		wp_enqueue_script(
			'wc-appointments-availability-week',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/admin-availability-week' . $suffix . '.js',
			[],
			file_exists( $week_js ) ? (string) filemtime( $week_js ) : WC_APPOINTMENTS_VERSION,
			true
		);
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script(
			'wc-appointments-availability-hub',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/admin-availability-hub' . $suffix . '.js',
			[ 'jquery', 'jquery-ui-datepicker', 'wc-appointments-availability-week' ],
			$js_ver,
			true
		);
		wp_localize_script( 'wc-appointments-availability-hub', 'wcaAvailabilityHub', self::bootstrap() );
	}

	/**
	 * Render shell.
	 */
	public static function render_page(): void {
		if ( ! WC_Appointments_Staff_Permissions::can_access_availability_hub() ) {
			wp_die( esc_html__( 'You do not have permission to manage availability.', 'woocommerce-appointments' ) );
		}
		$hub          = self::bootstrap();
		$hub_presence = $hub['presence'] ?? [];
		$hub_allowed  = $hub['allowedLayers'] ?? [];
		$hub_tab      = isset( $hub['initial']['tab'] ) ? (string) $hub['initial']['tab'] : self::DEFAULT_LAYER;
		$hub_counts   = $hub['counts'] ?? [];
		$hub_rail_sub = (string) ( $hub['i18n']['railSub'] ?? '' );
		include __DIR__ . '/views/html-admin-availability-hub.php';
	}

	/**
	 * Bootstrap payload for first paint.
	 *
	 * @return array<string, mixed>
	 */
	public static function bootstrap(): array {
		if ( null !== self::$bootstrap_cache ) {
			return self::$bootstrap_cache;
		}
		$user_id     = get_current_user_id();
		$edit_layers = self::allowed_layers_for_user( $user_id );
		$view_layers = self::view_layers_for_user( $edit_layers, $user_id );
		$entities    = self::scope_entities_for_staff_view( self::load_entities( $view_layers ), $user_id, $edit_layers );
		/* Entity bags are scoped to $view_layers (edit + read-only context). */
		$presence = [
			'staff'     => ! empty( $entities['staff'] ),
			'locations' => ! empty( $entities['locations'] ),
			'resources' => ! empty( $entities['resources'] ),
			'products'  => ! empty( $entities['products'] ),
			'global'    => in_array( 'global', $view_layers, true ),
		];
		$rules = self::load_rules_bag( $entities, $view_layers );

		$is_staff = WC_Appointments_Staff_Permissions::is_staff_user( $user_id );
		$default  = ( $is_staff && in_array( 'staff', $view_layers, true ) )
			? 'staff'
			: ( in_array( self::DEFAULT_LAYER, $view_layers, true ) ? self::DEFAULT_LAYER : ( $edit_layers[0] ?? ( $view_layers[0] ?? 'staff' ) ) );
		$layer    = isset( $_GET['layer'] ) ? sanitize_key( wp_unslash( (string) $_GET['layer'] ) ) : $default; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$id       = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! in_array( $layer, $view_layers, true ) ) {
			$layer = $default;
		}
		$need = [ 'staff' => 'staff', 'location' => 'locations', 'resource' => 'resources', 'product' => 'products' ];
		if ( isset( $need[ $layer ] ) && ! $presence[ $need[ $layer ] ] ) {
			$layer = $default;
		}

		$staff_default = $is_staff ? (string) $user_id : ( $entities['staff'][0]['id'] ?? '' );

		$rule_id = isset( $_GET['rule'] ) ? absint( wp_unslash( $_GET['rule'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$product_initial = $id && 'product' === $layer
			? (string) wc_appointments_get_product_id_for_availability( absint( $id ) )
			: ( $entities['products'][0]['id'] ?? '' );

		$initial = [
			'tab'        => $layer,
			'locationId' => $id && 'location' === $layer ? $id : ( $entities['locations'][0]['id'] ?? '' ),
			'resourceId' => $id && 'resource' === $layer ? $id : ( $entities['resources'][0]['id'] ?? '' ),
			'productId'  => $product_initial,
			'staffId'    => $id && 'staff' === $layer ? $id : $staff_default,
			'ruleId'     => $rule_id > 0 ? $rule_id : 0,
		];

		$can_set_appointable = ! $is_staff
			|| WC_Appointments_Staff_Permissions::can( $user_id, 'availability_set_appointable' );

		$counts = [ 'global' => count( $rules['global'] ?? [] ) ];
		foreach ( [ 'location', 'resource', 'product', 'staff' ] as $layer ) {
			$n = 0;
			foreach ( (array) ( $rules[ $layer ] ?? [] ) as $rows ) {
				$n += is_array( $rows ) ? count( $rows ) : 0;
			}
			$counts[ $layer ] = $n;
		}

		$rail_list  = self::format_layer_list( $view_layers );
		$blurb_list = self::format_layer_list( array_values( array_diff( $view_layers, [ 'global' ] ) ) );

		// Site-wall open-hours defaults (09:00–17:00), shown in the viewer timezone.
		$suggest = self::convert_rule_times_for_display(
			[
				'type' => 'time',
				'from' => '09:00',
				'to'   => '17:00',
			]
		);

		self::$bootstrap_cache = [
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'pageUrl'     => self::url(),
			'defaultLayer' => $default,
			'nonce'       => wp_create_nonce( 'wc_appointments_availability_hub' ),
			'startOfWeek' => (int) get_option( 'start_of_week', 1 ),
			'presence'    => $presence,
			'counts'      => $counts,
			'allowedLayers' => $view_layers,
			'editableLayers' => $edit_layers,
			'canSetAppointable' => $can_set_appointable,
			'entities'    => $entities,
			'rules'       => $rules,
			'initial'     => $initial,
			'showPriority' => self::user_wants_priority(),
			'showStatus'   => self::user_wants_status(),
			'showTitle'    => self::user_wants_title(),
			'typesFull'   => self::types_full(),
			'typesPlace'  => self::types_place(),
			// null = all types (admins / full staff). Limited staff permission levels get a subset on the Staff tab.
			'staffAllowedTypes' => self::viewer_staff_allowed_types(),
			'dayShort'    => self::day_short_labels(),
			'months'      => self::month_pairs(),
			'suggestFrom' => (string) ( $suggest['from'] ?? '09:00' ),
			'suggestTo'   => (string) ( $suggest['to'] ?? '17:00' ),
			'tzHtml'      => class_exists( 'WC_Appointments_Timezone_Helper' ) ? [
				'site'  => WC_Appointments_Timezone_Helper::build_timezone_indicator_html( WC_Appointments_Timezone_Helper::get_site_timezone_string() ),
				'staff' => WC_Appointments_Timezone_Helper::build_timezone_indicator_html( WC_Appointments_Timezone_Helper::get_admin_user_timezone() ),
			] : null,
			'i18n'        => [
				'layerGlobal'            => _x( 'General', 'availability hub layer: default hours for the store, not a physical shop', 'woocommerce-appointments' ),
				'layerLocation'          => __( 'Location', 'woocommerce-appointments' ),
				'layerLocations'         => __( 'Locations', 'woocommerce-appointments' ),
				'layerResource'          => __( 'Resource', 'woocommerce-appointments' ),
				'layerResources'         => __( 'Resources', 'woocommerce-appointments' ),
				'layerProduct'           => __( 'Product', 'woocommerce-appointments' ),
				'layerProducts'          => __( 'Products', 'woocommerce-appointments' ),
				'layerStaff'             => __( 'Staff', 'woocommerce-appointments' ),
				'railSub'                => $rail_list
					? sprintf(
						/* translators: %s: localized list of layers (e.g. "general hours, products, and staff"). */
						__( 'When %s can be booked.', 'woocommerce-appointments' ),
						$rail_list
					)
					: __( 'When appointments can be booked.', 'woocommerce-appointments' ),
				'blurbGlobal'            => $blurb_list
					? sprintf(
						/* translators: %s: localized list of layers (e.g. "products and staff"). */
						__( 'Applies to all %s. Rules on those levels override them.', 'woocommerce-appointments' ),
						$blurb_list
					)
					: __( 'Applies shop-wide. Rules on other levels override them.', 'woocommerce-appointments' ),
				'blurbLocation'          => __( 'Add rules only when this venue should differ from other layers.', 'woocommerce-appointments' ),
				'blurbResource'          => __( 'Add rules only when this room or equipment should differ from other layers.', 'woocommerce-appointments' ),
				'blurbProduct'           => __( 'Add rules only to limit this product further.', 'woocommerce-appointments' ),
				'blurbStaff'             => __( 'Add rules only when the schedule should differ from other layers.', 'woocommerce-appointments' ),
				/* translators: Badge on location/resource/product/staff layers (adjective), not a form field label. */
				'optional'               => _x( 'Optional', 'availability hub layer badge', 'woocommerce-appointments' ),
				'emptyHoursGlobal'       => __( 'Add when appointments are usually available.', 'woocommerce-appointments' ),
				'emptyHoursInherit'      => __( 'Add hours only when they should differ from other layers.', 'woocommerce-appointments' ),
				'emptyHoursProduct'      => __( 'No product hours yet.', 'woocommerce-appointments' ),
				'emptyExcepGlobal'       => __( 'Add holidays, maintenance, or other shop-wide closures.', 'woocommerce-appointments' ),
				'emptyExcepLocation'     => __( 'Block days or hours this venue cannot take appointments.', 'woocommerce-appointments' ),
				'emptyExcepResource'     => __( 'Block days or hours this room or equipment is out of service.', 'woocommerce-appointments' ),
				'emptyExcepProduct'      => __( 'Add closures that apply only to this product, not the whole shop.', 'woocommerce-appointments' ),
				'emptyExcepStaff'        => __( 'Add vacation, sick leave, or other blocked times.', 'woocommerce-appointments' ),
				'emptyHoursTitle'        => __( 'No open hours yet', 'woocommerce-appointments' ),
				'emptyExcepTitle'        => __( 'Nothing unavailable yet', 'woocommerce-appointments' ),
				/* translators: %s: comma-separated availability layer names the product inherits from. */
				'productHoursEmpty'      => __( 'Follows %s when those layers allow the time. Add product hours only to limit this service further.', 'woocommerce-appointments' ),
				'productHoursEmptyTitle' => __( 'No product hours yet', 'woocommerce-appointments' ),
				'saved'                  => __( 'Changes saved', 'woocommerce-appointments' ),
				'saving'                 => __( 'Saving…', 'woocommerce-appointments' ),
				'allSaved'               => __( 'All changes saved', 'woocommerce-appointments' ),
				'unsaved'                => __( 'Unsaved changes', 'woocommerce-appointments' ),
				'saveFailed'             => __( 'Could not save changes.', 'woocommerce-appointments' ),
				'discarded'              => __( 'Changes discarded', 'woocommerce-appointments' ),
				'leaveDirty'             => __( 'You have unsaved changes. Leave this screen without saving?', 'woocommerce-appointments' ),
				'discardConfirm'         => __( 'Discard unsaved changes?', 'woocommerce-appointments' ),
				'discard'                => __( 'Discard', 'woocommerce-appointments' ),
				'save'                   => __( 'Save', 'woocommerce-appointments' ),
				'saveChanges'            => __( 'Save changes', 'woocommerce-appointments' ),
				'addOpenHours'           => __( 'Add open hours', 'woocommerce-appointments' ),
				'addClosedDate'          => __( 'Add unavailable time', 'woocommerce-appointments' ),
				/* translators: Availability hub section: bookable time ranges (not only the start time). */
				'openHours'              => __( 'Open hours', 'woocommerce-appointments' ),
				/* translators: Availability hub section: closed rules and synced busy (not dates only). */
				'closedDates'            => __( 'Unavailable', 'woocommerce-appointments' ),
				'weekGlance'             => __( 'Week at a glance', 'woocommerce-appointments' ),
				/* translators: Aria label for pills linking to other rule layers that apply with the entity being edited. */
				'alsoAffecting'          => __( 'Other rules that apply', 'woocommerce-appointments' ),
				/* translators: %s: layer or entity name (e.g. General). Tooltip on those pills. */
				'alsoAffectingTip'       => __( '%s rules also apply to this schedule', 'woocommerce-appointments' ),
				'viewOnly'               => __( 'View only. You can edit your own hours.', 'woocommerce-appointments' ),
				/* translators: Accessibility label for the week preview strip (days that are bookable / open). */
				'weekAria'               => __( 'Open days', 'woocommerce-appointments' ),
				'closed'                 => _x( 'Closed', 'availability status label (adjective), not a button', 'woocommerce-appointments' ),
				'open'                   => _x( 'Open', 'availability status label (adjective), not a button', 'woocommerce-appointments' ),
				'busy'                   => _x( 'Busy', 'availability status label (adjective), not a button', 'woocommerce-appointments' ),
				/* translators: Rule covers a full calendar day (status/description), not a control to open something. */
				'allDay'                 => __( 'All day', 'woocommerce-appointments' ),
				'status'                 => __( 'Status', 'woocommerce-appointments' ),
				'title'                  => __( 'Title', 'woocommerce-appointments' ),
				'type'                   => __( 'Type', 'woocommerce-appointments' ),
				'range'                  => __( 'Range', 'woocommerce-appointments' ),
				'priority'               => __( 'Priority', 'woocommerce-appointments' ),
				'spots'                  => __( 'Capacity', 'woocommerce-appointments' ),
				'actions'                => __( 'Actions', 'woocommerce-appointments' ),
				/* translators: Button to delete a rule row (verb). */
				'remove'                 => __( 'Remove', 'woocommerce-appointments' ),
				'reorder'                => __( 'Reorder', 'woocommerce-appointments' ),
				'dragReorder'            => __( 'Drag to reorder', 'woocommerce-appointments' ),
				'titleHint'              => __( 'Shown on the admin calendar.', 'woocommerce-appointments' ),
				'spotsHint'              => __( 'Optional. Leave blank to inherit from the product (or a higher layer).', 'woocommerce-appointments' ),
				/* translators: Placeholder when capacity inherits from product inventory (noun: the default value). */
				'spotsPlaceholder'       => __( 'Default', 'woocommerce-appointments' ),
				'spotsInheritTitle'      => __( 'Leave blank to inherit from the product Capacity (or a higher layer).', 'woocommerce-appointments' ),
				'spotsNaTitle'           => __( 'Capacity only applies to open rules.', 'woocommerce-appointments' ),
				'titlePlaceholder'       => __( 'Optional title', 'woocommerce-appointments' ),
				/* translators: Badge on rules synced from Google Calendar (adjective/state), not a sync action. */
				'synced'                 => __( 'Synced', 'woocommerce-appointments' ),
				'syncedFromGcal'         => __( 'Synced from Google Calendar', 'woocommerce-appointments' ),
				'googleEvent'            => __( 'Google Event', 'woocommerce-appointments' ),
				'googleRecurring'        => __( 'Google Recurring Event', 'woocommerce-appointments' ),
				'timeRangesGroup'        => __( 'Time ranges', 'woocommerce-appointments' ),
				'endsNextDay'            => __( 'Ends the next day', 'woocommerce-appointments' ),
				'endsNextWeek'           => __( 'Ends the next week', 'woocommerce-appointments' ),
				'endsNextYear'           => __( 'Ends the next year', 'woocommerce-appointments' ),
				'fromDate'               => __( 'From date', 'woocommerce-appointments' ),
				'toDate'                 => __( 'To date', 'woocommerce-appointments' ),
				'fromTime'               => __( 'From time', 'woocommerce-appointments' ),
				'toTime'                 => __( 'To time', 'woocommerce-appointments' ),
				'fromDay'                => __( 'From day', 'woocommerce-appointments' ),
				'toDay'                  => __( 'To day', 'woocommerce-appointments' ),
				'fromMonth'              => __( 'From month', 'woocommerce-appointments' ),
				'toMonth'                => __( 'To month', 'woocommerce-appointments' ),
				'fromWeek'               => __( 'From week', 'woocommerce-appointments' ),
				'toWeek'                 => __( 'To week', 'woocommerce-appointments' ),
				'selectEntity'           => __( 'Select', 'woocommerce-appointments' ),
				'editEntity'             => __( 'Edit', 'woocommerce-appointments' ),
				'noMatches'              => __( 'No matches', 'woocommerce-appointments' ),
				'search'                 => __( 'Search', 'woocommerce-appointments' ),
				/* translators: Availability hub search filter: show hits from every layer. */
				'searchAll'              => _x( 'All', 'availability hub search layer filter', 'woocommerce-appointments' ),
				'clearSearch'            => __( 'Clear search', 'woocommerce-appointments' ),
				'rulesExplanation'       => get_wc_appointment_rules_explanation(),
			],
		];
		return self::$bootstrap_cache;
	}

	/**
	 * Localized "a, b, and c" list of hub layer names for rail / blurb copy.
	 *
	 * @param string[] $keys Layer keys (subset of global|location|resource|product|staff).
	 */
	private static function format_layer_list( array $keys ): string {
		$labels = [
			'global'   => __( 'general hours', 'woocommerce-appointments' ),
			'location' => __( 'locations', 'woocommerce-appointments' ),
			'resource' => __( 'resources', 'woocommerce-appointments' ),
			'product'  => __( 'products', 'woocommerce-appointments' ),
			'staff'    => __( 'staff', 'woocommerce-appointments' ),
		];
		$items = [];
		foreach ( [ 'global', 'location', 'resource', 'product', 'staff' ] as $key ) {
			if ( in_array( $key, $keys, true ) && isset( $labels[ $key ] ) ) {
				$items[] = $labels[ $key ];
			}
		}
		return $items ? (string) wp_sprintf( '%l', $items ) : '';
	}

	/**
	 * Month number => localized name for hub range pickers.
	 *
	 * @return array<int, array{0: string, 1: string}>
	 */
	private static function month_pairs(): array {
		global $wp_locale;
		$out = [];
		for ( $m = 1; 12 >= $m; $m++ ) {
			$out[] = [ (string) $m, $wp_locale->get_month( $m ) ];
		}
		return $out;
	}

	/**
	 * AJAX: persist hub Screen Options without reload.
	 */
	public static function ajax_screen_option(): void {
		check_ajax_referer( 'wc_appointments_availability_hub', 'security' );
		if ( ! WC_Appointments_Staff_Permissions::can_access_availability_hub() ) {
			wp_send_json_error( [ 'message' => __( 'Forbidden', 'woocommerce-appointments' ) ], 403 );
		}
		$uid = get_current_user_id();
		$pri = ! empty( $_POST['show_priority'] ) ? '1' : '0';
		$st  = ! empty( $_POST['show_status'] ) ? '1' : '0';
		$ti  = ! empty( $_POST['show_title'] ) ? '1' : '0';
		update_user_meta( $uid, 'wc_appointments_hub_show_priority', $pri );
		update_user_meta( $uid, 'wc_appointments_hub_show_status', $st );
		update_user_meta( $uid, 'wc_appointments_hub_show_title', $ti );
		wp_send_json_success(
			[
				'showPriority' => ( '1' === $pri ),
				'showStatus'   => ( '1' === $st ),
				'showTitle'    => ( '1' === $ti ),
			]
		);
	}

	/**
	 * AJAX save for one kind + kind_id.
	 */
	public static function ajax_save(): void {
		if ( ! WC_Appointments_Staff_Permissions::can_access_availability_hub() ) {
			wp_send_json_error( [ 'message' => __( 'Forbidden', 'woocommerce-appointments' ) ], 403 );
		}
		// Stale CSRF nonce: hand back a fresh one (auth cookie still valid) so the client can retry once.
		if ( ! check_ajax_referer( 'wc_appointments_availability_hub', 'security', false ) ) {
			wp_send_json_error( [ 'nonce' => wp_create_nonce( 'wc_appointments_availability_hub' ) ], 403 );
		}

		$layer   = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( (string) $_POST['kind'] ) ) : '';
		$kind_id = isset( $_POST['kind_id'] ) ? absint( $_POST['kind_id'] ) : 0;
		$kind    = self::layer_to_kind( $layer );
		if ( ! $kind || ! in_array( $layer, self::allowed_layers_for_user( get_current_user_id() ), true ) ) {
			wp_send_json_error( [ 'message' => __( 'Invalid layer.', 'woocommerce-appointments' ) ], 400 );
		}
		if ( 'global' !== $layer && $kind_id <= 0 ) {
			wp_send_json_error( [ 'message' => __( 'Missing entity.', 'woocommerce-appointments' ) ], 400 );
		}
		if ( WC_Appointments_Availability::KIND_PRODUCT === $kind ) {
			$kind_id = wc_appointments_get_product_id_for_availability( $kind_id );
		}
		if ( ! self::user_can_edit_kind( $kind, $kind_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Forbidden', 'woocommerce-appointments' ) ], 403 );
		}

		/**
		 * @var WC_Appointments_Availability_Data_Store $data_store
		 */
		$data_store = WC_Data_Store::load( 'appointments-availability' );
		$raw_json   = isset( $_POST['rules'] ) ? wp_unslash( (string) $_POST['rules'] ) : '[]'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$rules      = $data_store->decode_rules_json( $raw_json );
		$deleted    = [];
		if ( ! empty( $_POST['deleted'] ) ) {
			$deleted = array_filter( array_map( 'absint', explode( ',', sanitize_text_field( wp_unslash( (string) $_POST['deleted'] ) ) ) ) );
		}
		$deleted = self::filter_owned_rule_ids( $deleted, $kind, $kind_id );

		$user_id             = get_current_user_id();
		$can_set_appointable = ! WC_Appointments_Staff_Permissions::is_staff_user( $user_id )
			|| WC_Appointments_Staff_Permissions::can( $user_id, 'availability_set_appointable' );

		$normalized = [];
		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}
			// GCal / synced rows are read-only in the hub.
			if ( ! empty( $rule['event_id'] ) || ( isset( $rule['source'] ) && 'google' === $rule['source'] ) ) {
				continue;
			}
			$rule = self::normalize_hub_rule( $rule );
			if ( ! self::rule_type_allowed_for_save( $kind, $rule ) ) {
				continue;
			}
			// Existing rows must belong to this kind/kind_id (prevent re-parent / cross-entity edits).
			$id = isset( $rule['id'] ) ? absint( $rule['id'] ) : 0;
			if ( $id > 0 && $id < 1000000000 && ! self::rule_belongs_to_kind( $id, $kind, $kind_id ) ) {
				continue;
			}
			if ( ! $can_set_appointable ) {
				// Staff without Open permission: only Closed rules; force unavailable.
				$val = $rule['appointable'] ?? 'no';
				$is_open = true === $val || 1 === $val || '1' === (string) $val || 'yes' === (string) $val;
				if ( $is_open ) {
					continue;
				}
				$rule['appointable'] = 'no';
			}
			if ( $data_store->is_rule_valid( $rule ) ) {
				$normalized[] = $rule;
			}
		}

		// Viewer TZ → site TZ on write (staff profile TZ; admins are a no-op).
		$normalized = self::convert_rules_to_site_tz( $normalized );

		$saved_ids = $data_store->save_rules( $normalized, $kind, $kind_id, $deleted );

		if ( WC_Appointments_Availability::KIND_GLOBAL === $kind ) {
			do_action( 'wc_appointments_global_availability_on_save' );
		}

		WC_Appointments_Cache::invalidate_cache_group( 'wc-appointments-availability' );
		WC_Appointments_Cache::delete_appointment_slots_transient();
		if ( class_exists( 'WC_Appointment_Slots_Provider' ) ) {
			WC_Appointment_Slots_Provider::flush();
		}

		$fresh = self::rules_for_kind( $kind, $kind_id );

		$response = [ 'rules' => $fresh ];
		$notice_id = isset( $_POST['config_notice_product_id'] ) ? absint( $_POST['config_notice_product_id'] ) : 0;
		if ( ! $notice_id && 'product' === $layer ) {
			$notice_id = $kind_id;
		}
		if ( $notice_id && ( 'global' === $layer || 'product' === $layer ) ) {
			$notice_product = wc_get_product( $notice_id );
			if ( is_wc_appointment_product( $notice_product ) && current_user_can( 'edit_post', $notice_id )
				&& ! in_array( 'error', array_column( WC_Appointments_Admin::get_product_config_notices( $notice_product, true ), 'level' ), true ) ) {
				$response['clearConfigNotice'] = true;
			}
		}

		wp_send_json_success( $response );
	}

	/**
	 * Map hub layer key to KIND_* constant.
	 *
	 * @param string $layer Layer.
	 * @return string Empty when invalid.
	 */
	public static function layer_to_kind( string $layer ): string {
		$map = [
			'global'   => WC_Appointments_Availability::KIND_GLOBAL,
			'location' => WC_Appointments_Availability::KIND_LOCATION,
			'resource' => WC_Appointments_Availability::KIND_RESOURCE,
			'product'  => WC_Appointments_Availability::KIND_PRODUCT,
			'staff'    => WC_Appointments_Availability::KIND_STAFF,
		];
		return $map[ $layer ] ?? '';
	}

	/**
	 * Capability gate per kind.
	 *
	 * @param string $kind    Kind constant.
	 * @param int    $kind_id Entity id.
	 */
	private static function user_can_edit_kind( string $kind, int $kind_id ): bool {
		$kind_to_layer = [
			WC_Appointments_Availability::KIND_GLOBAL   => 'global',
			WC_Appointments_Availability::KIND_LOCATION => 'location',
			WC_Appointments_Availability::KIND_RESOURCE => 'resource',
			WC_Appointments_Availability::KIND_PRODUCT  => 'product',
			WC_Appointments_Availability::KIND_STAFF    => 'staff',
		];
		$layer = $kind_to_layer[ $kind ] ?? '';
		if ( '' === $layer || ! WC_Appointments_Staff_Permissions::can_edit_availability_layer( $layer, $kind_id ) ) {
			return false;
		}
		if ( WC_Appointments_Availability::KIND_PRODUCT === $kind ) {
			return current_user_can( 'edit_product', $kind_id );
		}
		if ( WC_Appointments_Availability::KIND_LOCATION === $kind || WC_Appointments_Availability::KIND_RESOURCE === $kind ) {
			return current_user_can( 'edit_post', $kind_id );
		}
		if ( WC_Appointments_Availability::KIND_STAFF === $kind ) {
			return current_user_can( 'edit_user', $kind_id )
				|| (int) $kind_id === get_current_user_id()
				|| current_user_can( 'manage_others_appointments' );
		}
		return true;
	}

	/**
	 * Hub layers the current user may edit (and save).
	 *
	 * @param int $user_id User ID.
	 * @return string[]
	 */
	private static function allowed_layers_for_user( int $user_id ): array {
		$order = [ 'global', 'location', 'resource', 'product', 'staff' ];
		if ( ! WC_Appointments_Features::is_locations_resources_active() ) {
			$order = array_values( array_diff( $order, [ 'location', 'resource' ] ) );
		}
		if ( user_can( $user_id, 'manage_others_appointments' ) ) {
			return $order;
		}
		$out = [];
		foreach ( WC_Appointments_Staff_Permissions::availability_hub_layer_permissions() as $layer => $perm ) {
			if ( WC_Appointments_Staff_Permissions::can( $user_id, $perm ) ) {
				$out[] = $layer;
			}
		}
		return array_values( array_intersect( $order, $out ) );
	}

	/**
	 * Layers in the rail: edit layers, or full browse set for staff with own hours.
	 *
	 * @param string[] $edit_layers Edit-capable layers.
	 * @param int      $user_id     User ID.
	 * @return string[]
	 */
	private static function view_layers_for_user( array $edit_layers, int $user_id ): array {
		$order = [ 'global', 'location', 'resource', 'product', 'staff' ];
		if ( ! WC_Appointments_Features::is_locations_resources_active() ) {
			$order = array_values( array_diff( $order, [ 'location', 'resource' ] ) );
		}
		if ( WC_Appointments_Staff_Permissions::is_staff_user( $user_id )
			&& in_array( 'staff', $edit_layers, true ) ) {
			return $order;
		}
		return array_values( array_intersect( $order, $edit_layers ) );
	}

	/**
	 * For staff: assigned-only bags when a layer is view-only; drop Edit URLs they cannot open.
	 *
	 * @param array<string, mixed>    $entities    Entity bags from load_entities().
	 * @param int      $user_id     Staff user ID.
	 * @param string[] $edit_layers Layers the user may edit.
	 * @return array<string, mixed>
	 */
	private static function scope_entities_for_staff_view( array $entities, int $user_id, array $edit_layers ): array {
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
			return $entities;
		}
		$uid = (string) $user_id;

		if ( ! in_array( 'product', $edit_layers, true ) ) {
			$entities['products'] = array_values(
				array_filter(
					$entities['products'] ?? [],
					static function ( $row ) use ( $uid ) {
						return in_array( $uid, $row['staffIds'] ?? [], true );
					}
				)
			);
		}

		$ids_from_products = static function ( array $products, string $key ): array {
			$keep = [];
			foreach ( $products as $product ) {
				foreach ( $product[ $key ] ?? [] as $id ) {
					$keep[ (string) $id ] = true;
				}
			}
			return $keep;
		};

		if ( ! in_array( 'location', $edit_layers, true ) ) {
			$keep                  = $ids_from_products( $entities['products'] ?? [], 'locationIds' );
			$entities['locations'] = array_values(
				array_filter(
					$entities['locations'] ?? [],
					static function ( $row ) use ( $keep ) {
						return isset( $keep[ (string) $row['id'] ] );
					}
				)
			);
		}

		if ( ! in_array( 'resource', $edit_layers, true ) ) {
			$keep                  = $ids_from_products( $entities['products'] ?? [], 'resourceIds' );
			$entities['resources'] = array_values(
				array_filter(
					$entities['resources'] ?? [],
					static function ( $row ) use ( $keep ) {
						return isset( $keep[ (string) $row['id'] ] );
					}
				)
			);
		}

		foreach (
			[
				'products'  => 'manage_products',
				'locations' => 'manage_locations',
				'resources' => 'manage_resources',
			] as $bag => $perm
		) {
			if ( WC_Appointments_Staff_Permissions::can( $user_id, $perm ) ) {
				continue;
			}
			foreach ( $entities[ $bag ] as $i => $row ) {
				$entities[ $bag ][ $i ]['editUrl'] = '';
			}
		}

		return $entities;
	}

	/**
	 * Whether a rule ID belongs to the given kind/kind_id.
	 *
	 * @param int    $rule_id Rule ID.
	 * @param string $kind    Kind constant.
	 * @param int    $kind_id Kind id.
	 */
	private static function rule_belongs_to_kind( int $rule_id, string $kind, int $kind_id ): bool {
		$obj = get_wc_appointments_availability( $rule_id );
		if ( ! $obj || ! $obj->get_id() ) {
			return false;
		}
		if ( (string) $obj->get_kind() !== $kind ) {
			return false;
		}
		if ( WC_Appointments_Availability::KIND_GLOBAL === $kind ) {
			return true;
		}
		return (int) $obj->get_kind_id() === $kind_id;
	}

	/**
	 * Drop delete IDs that do not belong to this kind/kind_id.
	 *
	 * @param int[]  $ids     Candidate delete IDs.
	 * @param string $kind    Kind constant.
	 * @param int    $kind_id Kind id.
	 * @return int[]
	 */
	private static function filter_owned_rule_ids( array $ids, string $kind, int $kind_id ): array {
		$out = [];
		foreach ( $ids as $id ) {
			$id = absint( $id );
			if ( $id && self::rule_belongs_to_kind( $id, $kind, $kind_id ) ) {
				$out[] = $id;
			}
		}
		return $out;
	}

	/**
	 * Short label for statuses customers cannot book; empty when published.
	 *
	 * @param string $status Post / product status.
	 */
	private static function status_badge( string $status ): string {
		$labels = [
			'draft'   => __( 'Draft', 'woocommerce-appointments' ),
			'pending' => __( 'Pending review', 'woocommerce-appointments' ),
			'private' => __( 'Private', 'woocommerce-appointments' ),
			'future'  => __( 'Scheduled', 'woocommerce-appointments' ),
		];
		return $labels[ $status ] ?? '';
	}

	/**
	 * @param string[] $allowed Allowed hub layers.
	 * @return array{locations: list<array<string, mixed>>, resources: list<array<string, mixed>>, products: list<array<string, mixed>>, staff: list<array<string, mixed>>}
	 */
	private static function load_entities( array $allowed ): array {
		$statuses  = [ 'publish', 'private', 'draft', 'pending', 'future' ];
		$locations = [];
		$resources = [];
		$products  = [];
		$staff     = [];
		$want_loc  = in_array( 'location', $allowed, true );
		$want_res  = in_array( 'resource', $allowed, true );

		if ( $want_loc && post_type_exists( WC_Appointments_Location::POST_TYPE ) ) {
			foreach ( WC_Appointments_Location_Data_Store::query( $statuses, false, 500 ) as $post ) {
				$loc_obj     = get_wc_appointments_location( (int) $post->ID );
				$kind        = $loc_obj ? $loc_obj->get_kind() : '';
				$locations[] = [
					'id'      => (string) $post->ID,
					'name'    => $post->post_title,
					'meta'    => WC_Appointments_Location::get_kind_label( $kind ),
					'badge'   => self::status_badge( (string) $post->post_status ),
					'editUrl' => (string) ( get_edit_post_link( $post->ID, 'raw' ) ?? '' ),
				];
			}
		}

		if ( $want_res && post_type_exists( WC_Appointments_Resource::POST_TYPE ) ) {
			$loc_titles = [];
			foreach ( $locations as $loc ) {
				$loc_titles[ (int) $loc['id'] ] = $loc['name'];
			}
			// Resource meta needs venue titles even when the location layer itself is hidden.
			if ( ! $want_loc && post_type_exists( WC_Appointments_Location::POST_TYPE ) ) {
				foreach ( WC_Appointments_Location_Data_Store::query( $statuses, true, 500 ) as $lid ) {
					$loc_titles[ (int) $lid ] = get_the_title( $lid );
				}
			}
			foreach ( WC_Appointments_Resource_Data_Store::query( $statuses, false, 500 ) as $post ) {
				$lid  = WC_Appointments_Resource_Data_Store::get_location_id( (int) $post->ID );
				$meta = $lid && isset( $loc_titles[ $lid ] )
					? sprintf(
						/* translators: %s: location name */
						__( 'At %s', 'woocommerce-appointments' ),
						$loc_titles[ $lid ]
					)
					: __( 'Shared', 'woocommerce-appointments' );
				$resources[] = [
					'id'       => (string) $post->ID,
					'name'     => $post->post_title,
					'meta'     => $meta,
					'badge'    => self::status_badge( (string) $post->post_status ),
					'location' => $lid ? (string) $lid : '',
					'editUrl'  => (string) ( get_edit_post_link( $post->ID, 'raw' ) ?? '' ),
				];
			}
		}

		if ( in_array( 'product', $allowed, true ) ) {
			foreach ( (array) wc_get_products(
				[
					'type'    => 'appointment',
					'status'  => $statuses,
					'limit'   => 500,
					'orderby' => 'title',
					'order'   => 'ASC',
				]
			) as $product ) {
				if ( ! $product instanceof WC_Product_Appointment ) {
					continue;
				}
				$product_id = (int) $product->get_id();
				// Language translations share the original product's rules; list the owner only.
				if ( $product_id !== wc_appointments_get_product_id_for_availability( $product_id ) ) {
					continue;
				}
				$unit      = $product->get_duration_unit();
				$staff_ids = array_map( 'strval', array_values( array_filter( array_map( 'absint', (array) $product->get_staff_ids() ) ) ) );
				$row       = [
					'id'       => (string) $product_id,
					'name'     => $product->get_name(),
					'meta'     => WC_Appointment_Duration::format_minutes( $product->get_duration_in_minutes(), $unit ),
					'badge'    => self::status_badge( (string) $product->get_status() ),
					'duration' => $unit,
					'editUrl'  => (string) ( get_edit_post_link( $product->get_id(), 'raw' ) ?? '' ),
					'staffIds' => $staff_ids,
				];
				if ( $want_loc && $product->has_locations() ) {
					$row['locationIds'] = array_map( 'strval', $product->get_location_ids() );
				}
				if ( $want_res && $product->has_resources() ) {
					$resource_ids = [];
					foreach ( $product->get_resource_requirements() as $req ) {
						$rid = absint( $req['resource_id'] ?? 0 );
						if ( $rid ) {
							$resource_ids[] = (string) $rid;
						}
					}
					$row['resourceIds'] = array_values( array_unique( $resource_ids ) );
				}
				if ( $product->has_restricted_days() ) {
					global $wp_locale;
					$days = array_map(
						static function ( $d ) use ( $wp_locale ) {
							return $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( (int) $d ) );
						},
						(array) $product->get_restricted_days()
					);
					if ( $days ) {
						$row['restrictedStartNote'] = sprintf(
							/* translators: %s: comma-separated weekday abbreviations (e.g. Mon, Wed). */
							__( 'Starts on %s only (product setting, not these rules).', 'woocommerce-appointments' ),
							implode( ', ', $days )
						);
					}
				}
				$products[] = $row;
			}
		}

		if ( in_array( 'staff', $allowed, true ) ) {
			$user_id   = get_current_user_id();
			$own_only  = WC_Appointments_Staff_Permissions::is_staff_user( $user_id )
				&& ! user_can( $user_id, 'manage_others_appointments' );
			foreach ( WC_Appointments_Admin::get_appointment_staff() as $user ) {
				if ( $own_only && (int) $user->ID !== $user_id ) {
					continue;
				}
				$staff[] = [
					'id'      => (string) $user->ID,
					'name'    => $user->display_name,
					'meta'    => $user->user_email,
					'editUrl' => (string) ( get_edit_user_link( $user->ID ) ?? '' ),
				];
			}
		}

		return compact( 'locations', 'resources', 'products', 'staff' );
	}

	/**
	 * Load hub rules into bags.
	 *
	 * @param array<string, mixed>    $entities Entity lists.
	 * @param string[] $allowed  Allowed layers.
	 * @return array<string, mixed>
	 */
	private static function load_rules_bag( array $entities, array $allowed ): array {
		$bag = [
			'global'   => [],
			'location' => [],
			'resource' => [],
			'product'  => [],
			'staff'    => [],
		];

		$kinds = [];
		if ( in_array( 'global', $allowed, true ) ) {
			$kinds[] = WC_Appointments_Availability::KIND_GLOBAL;
		}
		if ( in_array( 'product', $allowed, true ) ) {
			$kinds[] = WC_Appointments_Availability::KIND_PRODUCT;
		}
		if ( in_array( 'location', $allowed, true ) && ! empty( $entities['locations'] ) ) {
			$kinds[] = WC_Appointments_Availability::KIND_LOCATION;
		}
		if ( in_array( 'resource', $allowed, true ) && ! empty( $entities['resources'] ) ) {
			$kinds[] = WC_Appointments_Availability::KIND_RESOURCE;
		}
		if ( in_array( 'staff', $allowed, true ) && ! empty( $entities['staff'] ) ) {
			$kinds[] = WC_Appointments_Availability::KIND_STAFF;
		}
		if ( [] === $kinds ) {
			return $bag;
		}

		$data_store = WC_Data_Store::load( 'appointments-availability' );
		$rows       = $data_store->get_all_as_array(
			[
				[
					'key'     => 'kind',
					'compare' => 'IN',
					'value'   => $kinds,
				],
			]
		);

		$staff_ids = array_fill_keys( array_column( $entities['staff'], 'id' ), true );
		$product_ids = array_fill_keys( array_column( $entities['products'], 'id' ), true );
		$location_ids = array_fill_keys( array_column( $entities['locations'], 'id' ), true );
		$resource_ids = array_fill_keys( array_column( $entities['resources'], 'id' ), true );

		foreach ( (array) $rows as $row ) {
			$hub = self::hub_row_from_db( $row );
			$kind = (string) ( $row['kind'] ?? '' );
			$kid  = (string) ( $row['kind_id'] ?? '0' );
			if ( WC_Appointments_Availability::KIND_STAFF === $kind && ! isset( $staff_ids[ $kid ] ) ) {
				continue;
			}
			// All layers: show times in the viewer timezone (staff profile TZ when it differs).
			$hub = self::convert_rule_times_for_display( $hub );
			if ( WC_Appointments_Availability::KIND_GLOBAL === $kind ) {
				$bag['global'][] = $hub;
			} elseif ( WC_Appointments_Availability::KIND_LOCATION === $kind ) {
				if ( ! isset( $location_ids[ $kid ] ) ) {
					continue;
				}
				if ( ! isset( $bag['location'][ $kid ] ) ) {
					$bag['location'][ $kid ] = [];
				}
				$bag['location'][ $kid ][] = $hub;
			} elseif ( WC_Appointments_Availability::KIND_RESOURCE === $kind ) {
				if ( ! isset( $resource_ids[ $kid ] ) ) {
					continue;
				}
				if ( ! isset( $bag['resource'][ $kid ] ) ) {
					$bag['resource'][ $kid ] = [];
				}
				$bag['resource'][ $kid ][] = $hub;
			} elseif ( WC_Appointments_Availability::KIND_PRODUCT === $kind ) {
				if ( ! isset( $product_ids[ $kid ] ) ) {
					continue;
				}
				if ( ! isset( $bag['product'][ $kid ] ) ) {
					$bag['product'][ $kid ] = [];
				}
				$bag['product'][ $kid ][] = $hub;
			} elseif ( WC_Appointments_Availability::KIND_STAFF === $kind ) {
				if ( ! isset( $bag['staff'][ $kid ] ) ) {
					$bag['staff'][ $kid ] = [];
				}
				$bag['staff'][ $kid ][] = $hub;
			}
		}

		return $bag;
	}

	/**
	 * Rules for one kind after save (includes GCal rows).
	 *
	 * @param string $kind    Kind.
	 * @param int    $kind_id Kind id.
	 * @return list<array<string, mixed>>
	 */
	private static function rules_for_kind( string $kind, int $kind_id ): array {
		$filters = [
			[
				'key'     => 'kind',
				'compare' => '=',
				'value'   => $kind,
			],
		];
		if ( WC_Appointments_Availability::KIND_GLOBAL !== $kind ) {
			$filters[] = [
				'key'     => 'kind_id',
				'compare' => '=',
				'value'   => $kind_id,
			];
		}
		$data_store = WC_Data_Store::load( 'appointments-availability' );
		$rows       = $data_store->get_all_as_array( $filters );
		$out        = [];
		foreach ( (array) $rows as $row ) {
			$out[] = self::convert_rule_times_for_display( self::hub_row_from_db( $row ) );
		}
		return $out;
	}

	/**
	 * DB row → hub rule shape (demo-compatible).
	 *
	 * @param array<string, mixed> $row DB/array row.
	 * @return array<string, mixed>
	 */
	private static function hub_row_from_db( array $row ): array {
		$is_gcal = ! empty( $row['event_id'] );
		$type    = (string) ( $row['type'] ?? $row['range_type'] ?? '' );
		$from    = (string) ( $row['from'] ?? $row['from_range'] ?? '' );
		$to      = (string) ( $row['to'] ?? $row['to_range'] ?? '' );
		// Normalize HH:MM:SS → HH:MM for <input type="time">.
		if ( preg_match( '/^\d{1,2}:\d{2}/', $from ) ) {
			$from = substr( $from, 0, 5 );
		}
		if ( preg_match( '/^\d{1,2}:\d{2}/', $to ) ) {
			$to = substr( $to, 0, 5 );
		}
		$appointable = isset( $row['appointable'] ) ? (string) $row['appointable'] : 'yes';

		$hub = [
			'id'        => (int) ( $row['id'] ?? $row['ID'] ?? 0 ),
			'type'      => $type,
			'from'      => $from,
			'to'        => $to,
			'available' => ( 'yes' === $appointable ) ? 'yes' : 'no',
			'priority'  => (int) ( $row['priority'] ?? 10 ),
			'source'    => $is_gcal ? 'google' : 'manual',
			'title'     => (string) ( $row['title'] ?? '' ),
		];
		if ( ! empty( $row['from_date'] ) ) {
			$hub['from_date'] = (string) $row['from_date'];
		}
		if ( ! empty( $row['to_date'] ) ) {
			$hub['to_date'] = (string) $row['to_date'];
		}
		if ( ! empty( $row['qty'] ) ) {
			$hub['qty'] = (string) absint( $row['qty'] );
		}
		if ( $is_gcal ) {
			$hub['event_id']  = (string) $row['event_id'];
			$hub['recurring'] = ! empty( $row['rrule'] );
			if ( 'rrule' === $type && ! empty( $row['rrule'] ) ) {
				$hub['range_text'] = self::gcal_rrule_range_text( $row );
			}
		}
		return $hub;
	}

	/**
	 * Compact Google RRULE label for the hub range column (classic fields approach, no exception list).
	 *
	 * @param array<string, mixed> $row DB availability row.
	 */
	private static function gcal_rrule_range_text( array $row ): string {
		$from = (string) ( $row['from_range'] ?? $row['from'] ?? '' );
		$to   = (string) ( $row['to_range'] ?? $row['to'] ?? '' );
		$raw  = (string) ( $row['rrule'] ?? '' );
		if ( '' === $from || '' === $raw ) {
			return trim( $from . ( $to ? ' - ' . $to : '' ) );
		}

		$all_day = false === strpos( $from, ':' );
		$fmt     = $all_day ? 'Y-m-d' : 'Y-m-d g:i A';
		$pair    = self::hub_tz_shift_pair();
		$tz      = new DateTimeZone( $pair ? $pair[1] : wc_timezone_string() );

		try {
			$fd = ( new WC_DateTime( $from ) )->setTimezone( $tz );
			$td = ( new WC_DateTime( $to ? $to : $from ) )->setTimezone( $tz );
			$out = $fd->format( $fmt ) . ' ' . __( 'to', 'woocommerce-appointments' ) . ' ' . $td->format( $fmt );
			$out .= ' · ' . __( 'Repeating ', 'woocommerce-appointments' );
			$rset = new \RRule\RSet( wc_appointments_esc_rrule( $raw, $all_day ), $all_day ? $fd->format( $fmt ) : $fd );
			foreach ( $rset->getRRules() as $rrule ) {
				$out .= $rrule->humanReadable( [ 'locale' => function_exists( 'determine_locale' ) ? determine_locale() : get_locale() ] );
			}
			return $out;
		} catch ( Exception $e ) {
			return __( 'Invalid recurring rule', 'woocommerce-appointments' );
		}
	}

	/**
	 * Hub rule → save_rules shape.
	 *
	 * @param array<string, mixed> $rule Hub rule.
	 * @return array<string, mixed>
	 */
	private static function normalize_hub_rule( array $rule ): array {
		if ( isset( $rule['available'] ) && ! isset( $rule['appointable'] ) ) {
			$rule['appointable'] = $rule['available'];
		}
		$id = isset( $rule['id'] ) ? (int) $rule['id'] : 0;
		if ( $id >= 1000000000 ) {
			unset( $rule['id'] );
		}
		$type = (string) ( $rule['type'] ?? '' );
		if ( 'custom' === $type ) {
			if ( empty( $rule['from_date'] ) && ! empty( $rule['from'] ) ) {
				$rule['from_date'] = $rule['from'];
			}
			if ( empty( $rule['to_date'] ) && ! empty( $rule['to'] ) ) {
				$rule['to_date'] = $rule['to'];
			}
		}
		// Hub UI owns from/to. Always sync to from_range/to_range on write so a
		// stale range left over from display TZ conversion cannot overwrite edits.
		$has_time = ( 0 === strpos( $type, 'time' ) ) || 'custom:daterange' === $type;
		if ( $has_time ) {
			if ( isset( $rule['from'] ) && '' !== (string) $rule['from'] ) {
				$rule['from_range'] = $rule['from'];
			}
			if ( isset( $rule['to'] ) && '' !== (string) $rule['to'] ) {
				$rule['to_range'] = $rule['to'];
			}
		}
		unset( $rule['available'], $rule['source'], $rule['recurring'] );
		return $rule;
	}

	/**
	 * Site + viewer TZ when hub times should shift; null when no conversion.
	 *
	 * @return array{0: string, 1: string}|null
	 */
	private static function hub_tz_shift_pair(): ?array {
		if ( ! class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
			return null;
		}
		$site = WC_Appointments_Timezone_Helper::get_site_timezone_string();
		if ( ! WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) ) {
			return null;
		}
		$display = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
		if ( ! $site || ! $display || $site === $display ) {
			return null;
		}
		return [ $site, $display ];
	}

	/**
	 * Convert stored site-TZ times to hub display TZ (viewer TZ).
	 *
	 * @param array<string, mixed> $rule Hub rule.
	 * @return array<string, mixed>
	 */
	private static function convert_rule_times_for_display( array $rule ): array {
		$pair = self::hub_tz_shift_pair();
		if ( ! $pair ) {
			return $rule;
		}
		$shifted = self::shift_rule_times( $rule, $pair[0], $pair[1] );
		// Hub client only edits from/to; do not round-trip from_range/to_range.
		unset( $shifted['from_range'], $shifted['to_range'] );
		return $shifted;
	}

	/**
	 * Convert hub display times (viewer TZ) to site timezone on write.
	 *
	 * @param list<array<string, mixed>> $rules Rules.
	 * @return list<array<string, mixed>>
	 */
	private static function convert_rules_to_site_tz( array $rules ): array {
		$pair = self::hub_tz_shift_pair();
		if ( ! $pair ) {
			return $rules;
		}
		$out = [];
		foreach ( $rules as $rule ) {
			$out[] = self::shift_rule_times( $rule, $pair[1], $pair[0] );
		}
		return $out;
	}

	/**
	 * Shift time (and date+time) fields between timezones.
	 *
	 * @param array<string, mixed> $rule    Rule.
	 * @param string               $from_tz Source TZ.
	 * @param string               $to_tz   Target TZ.
	 * @return array<string, mixed>
	 */
	private static function shift_rule_times( array $rule, string $from_tz, string $to_tz ): array {
		$type = (string) ( $rule['type'] ?? '' );
		if ( 0 !== strpos( $type, 'time' ) && 'custom:daterange' !== $type ) {
			return $rule;
		}
		try {
			$from_obj = new DateTimeZone( $from_tz );
			$to_obj   = new DateTimeZone( $to_tz );
			// Prefer hub canonical from/to (issue #1506).
			$from = $rule['from'] ?? $rule['from_range'] ?? '';
			$to   = $rule['to'] ?? $rule['to_range'] ?? '';
			if ( 'custom:daterange' === $type ) {
				if ( $from && ! empty( $rule['from_date'] ) && false !== strpos( (string) $from, ':' ) ) {
					$from_dt = new DateTime( $rule['from_date'] . ' ' . $from, $from_obj );
					$from_dt->setTimezone( $to_obj );
					$rule['from']       = $from_dt->format( 'H:i' );
					$rule['from_range'] = $rule['from'];
					$rule['from_date']  = $from_dt->format( 'Y-m-d' );
				}
				if ( $to && ! empty( $rule['to_date'] ) && false !== strpos( (string) $to, ':' ) ) {
					$to_dt = new DateTime( $rule['to_date'] . ' ' . $to, $from_obj );
					$to_dt->setTimezone( $to_obj );
					$rule['to']       = $to_dt->format( 'H:i' );
					$rule['to_range'] = $rule['to'];
					$rule['to_date']  = $to_dt->format( 'Y-m-d' );
				}
			} else {
				// Weekly / time:range: times shift; date bounds on time:range stay civil.
				$anchor = ( new DateTime( 'now', $from_obj ) )->format( 'Y-m-d' );
				if ( $from && false !== strpos( (string) $from, ':' ) ) {
					$from_dt = new DateTime( $anchor . ' ' . $from, $from_obj );
					$from_dt->setTimezone( $to_obj );
					$rule['from']       = $from_dt->format( 'H:i' );
					$rule['from_range'] = $rule['from'];
				}
				if ( $to && false !== strpos( (string) $to, ':' ) ) {
					$to_dt = new DateTime( $anchor . ' ' . $to, $from_obj );
					$to_dt->setTimezone( $to_obj );
					$rule['to']       = $to_dt->format( 'H:i' );
					$rule['to_range'] = $rule['to'];
				}
			}
		} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
			// Keep original values.
		}
		return $rule;
	}

	/**
	 * @return array<int, array{0: string, 1: string}>
	 */
	private static function types_full(): array {
		return [
			[ 'custom', __( 'Date range', 'woocommerce-appointments' ) ],
			[ 'custom:daterange', __( 'Date range with time', 'woocommerce-appointments' ) ],
			[ 'months', __( 'Range of months', 'woocommerce-appointments' ) ],
			[ 'weeks', __( 'Range of weeks', 'woocommerce-appointments' ) ],
			[ 'days', __( 'Range of days', 'woocommerce-appointments' ) ],
			[ 'time', __( 'Recurring Time (all week)', 'woocommerce-appointments' ) ],
			[ 'time:range', __( 'Recurring Time (date range)', 'woocommerce-appointments' ) ],
			[ 'time:1', __( 'Monday', 'woocommerce-appointments' ) ],
			[ 'time:2', __( 'Tuesday', 'woocommerce-appointments' ) ],
			[ 'time:3', __( 'Wednesday', 'woocommerce-appointments' ) ],
			[ 'time:4', __( 'Thursday', 'woocommerce-appointments' ) ],
			[ 'time:5', __( 'Friday', 'woocommerce-appointments' ) ],
			[ 'time:6', __( 'Saturday', 'woocommerce-appointments' ) ],
			[ 'time:7', __( 'Sunday', 'woocommerce-appointments' ) ],
		];
	}

	/**
	 * Location / resource open/closed subset (includes `days`; no months/weeks/time:range).
	 *
	 * @return array<int, array{0: string, 1: string}>
	 */
	private static function types_place(): array {
		$allow = [ 'custom' => true, 'custom:daterange' => true, 'days' => true, 'time' => true ];
		$out   = [];
		foreach ( self::types_full() as $pair ) {
			if ( isset( $allow[ $pair[0] ] ) || preg_match( '/^time:[1-7]$/', $pair[0] ) ) {
				$out[] = $pair;
			}
		}
		return $out;
	}

	/**
	 * Staff permission rule-type level for the current viewer.
	 * null = unrestricted (shop managers / full staff level "all").
	 *
	 * @return string[]|null
	 */
	private static function viewer_staff_allowed_types(): ?array {
		if ( ! class_exists( 'WC_Appointments_Staff_Permissions' ) ) {
			return null;
		}
		$user_id = get_current_user_id();
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
			return null;
		}
		$level = WC_Appointments_Staff_Permissions::get_rule_type_level( $user_id );
		if ( 'all' === $level ) {
			return null;
		}
		return WC_Appointments_Staff_Permissions::RULE_TYPE_SETS[ $level ] ?? WC_Appointments_Staff_Permissions::RULE_TYPE_SETS['date_range'];
	}

	/**
	 * Whether a rule type may be saved for this kind (layer caps + staff permission levels).
	 * Existing DB rows outside the current allowlist are preserved (classic locked-type behavior).
	 *
	 * @param string               $kind Kind constant.
	 * @param array<string, mixed> $rule Normalized rule.
	 */
	private static function rule_type_allowed_for_save( string $kind, array $rule ): bool {
		$type = isset( $rule['type'] ) ? (string) $rule['type'] : '';
		if ( '' === $type || 'rrule' === $type ) {
			return true;
		}

		$allowed = null;
		if ( WC_Appointments_Availability::KIND_LOCATION === $kind || WC_Appointments_Availability::KIND_RESOURCE === $kind ) {
			$allowed = array_column( self::types_place(), 0 );
		} elseif ( WC_Appointments_Availability::KIND_STAFF === $kind ) {
			$allowed = self::viewer_staff_allowed_types();
		}

		if ( null === $allowed ) {
			return true;
		}

		$ok = preg_match( '/^time:[1-7]$/', $type )
			? in_array( 'time', $allowed, true )
			: in_array( $type, $allowed, true );

		if ( $ok ) {
			return true;
		}

		// Keep existing rules whose type the viewer may not create (staff permission levels).
		$id = isset( $rule['id'] ) ? absint( $rule['id'] ) : 0;
		return $id > 0 && $id < 1000000000;
	}
}

WC_Appointments_Admin_Availability_Hub::init();
