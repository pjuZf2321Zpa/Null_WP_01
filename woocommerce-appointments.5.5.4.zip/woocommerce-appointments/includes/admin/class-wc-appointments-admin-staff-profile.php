<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Staff Profile - Simplified sidebar navigation approach.
 *
 * This class adds staff-specific fields to the user profile and uses
 * JavaScript to transform all profile sections into a sidebar navigation.
 */
class WC_Appointments_Admin_Staff_Profile {

	/**
	 * Constructor
	 */
	public function __construct() {
		// Add staff-specific fields
		add_action( 'show_user_profile', [ $this, 'add_staff_meta_fields' ] );
		add_action( 'edit_user_profile', [ $this, 'add_staff_meta_fields' ] );

		// Enqueue assets
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

		// Save and delete handlers
		add_action( 'personal_options_update', [ $this, 'save_staff_meta_fields' ] );
		add_action( 'edit_user_profile_update', [ $this, 'save_staff_meta_fields' ] );

		add_action( 'delete_user', [ $this, 'delete_staff' ], 11 );

		// Remove Application Passwords section for staff users
		add_filter( 'wp_is_application_passwords_available_for_user', [ $this, 'disable_application_passwords_for_staff' ], 10, 2 );

		// Also hide the Application Passwords section in the profile
		add_action( 'admin_init', [ $this, 'hide_application_passwords_section' ] );
	}

	/**
	 * Check if we should render the staff profile UI.
	 * @param WP_User $user
	 */
	private function is_staff_user( $user ): bool {
		if ( ! $user instanceof WP_User ) {
			return false;
		}
		return in_array( 'shop_staff', (array) $user->roles, true );
	}

	/**
	 * Disable Application Passwords for staff users.
	 *
	 * @param bool   $available Whether Application Passwords are available for the user.
	 * @param int|WP_User $user     The user object or ID.
	 * @return bool
	 */
	public function disable_application_passwords_for_staff( $available, $user ): bool {
		if ( is_numeric( $user ) ) {
			$user = get_userdata( $user );
		}
		if ( $this->is_staff_user( $user ) ) {
			return false;
		}
		return $available;
	}

	/**
	 * Hide Application Passwords section with CSS for staff users.
	 */
	public function hide_application_passwords_section(): void {
		$user_id = get_current_user_id();
		$user    = get_userdata( $user_id );

		if ( $this->is_staff_user( $user ) ) {
			// Add inline CSS to hide the Application Passwords section
			wp_add_inline_style( 'common', '
				#application-passwords-section,
				.application-passwords {
					display: none !important;
				}
			' );
		}
	}

	/**
	 * Enqueue scripts and styles for staff profile.
	 */
	public function enqueue_scripts( string $hook ): void {
		// Determine context: staff viewing own profile, or admin viewing staff profile.
		$is_own_profile  = ( 'profile.php' === $hook );
		$is_admin_edit   = ( 'user-edit.php' === $hook );

		if ( ! $is_own_profile && ! $is_admin_edit ) {
			return;
		}

		$user = null;

		if ( $is_own_profile ) {
			$user_id = get_current_user_id();
			$user    = get_userdata( $user_id );
		} elseif ( $is_admin_edit ) {
			$user_id = absint( filter_input( INPUT_GET, 'user_id' ) );
			$user    = $user_id ? get_userdata( $user_id ) : null;
		}

		if ( ! $this->is_staff_user( $user ) ) {
			return;
		}

		// Enqueue WooCommerce admin styles (needed for form elements)
		wp_enqueue_style( 'woocommerce_admin_styles' );

		// Enqueue appointments admin styles (needed for availability table)
		wp_enqueue_style(
			'wc_appointments_admin_styles',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin.css',
			[ 'woocommerce_admin_styles' ],
			WC_APPOINTMENTS_VERSION
		);

		// Enqueue staff profile styles (must come after to override)
		wp_enqueue_style(
			'wca-admin-staff-profile',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/admin-staff-profile.css',
			[ 'wc_appointments_admin_styles' ],
			WC_APPOINTMENTS_VERSION
		);

		// Enqueue Select2 for product search
		wp_enqueue_script( 'select2' );
		wp_enqueue_style( 'select2' );

		// Enqueue WC enhanced select for product search
		wp_enqueue_script( 'wc-enhanced-select' );

		// Use minified JS in production
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_script(
			'wca-admin-staff-profile',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/admin-staff-profile' . $suffix . '.js',
			[ 'wc-enhanced-select' ],
			WC_APPOINTMENTS_VERSION,
			true
		);

		$is_admin = current_user_can( 'manage_others_appointments' );

		wp_localize_script( 'wca-admin-staff-profile', 'wcaStaffProfile', [
			'isAdmin'       => $is_admin,
			'isAdminEdit'   => $is_admin_edit,
			'dashboardUrl'  => ! $is_admin ? esc_url( admin_url( 'index.php' ) ) : '',
			'currency'      => [
				'symbol'    => html_entity_decode( get_woocommerce_currency_symbol() ),
				'position'  => get_option( 'woocommerce_currency_pos', 'left' ),
				'decimals'  => absint( get_option( 'woocommerce_price_num_decimals', 2 ) ),
				'decSep'    => get_option( 'woocommerce_price_decimal_sep', '.' ),
				'thousSep'  => get_option( 'woocommerce_price_thousand_sep', ',' ),
			],
			'sectionLabels' => array_filter(
				[
					// phpcs:disable WordPress.WP.I18n.TextDomainMismatch -- WordPress core profile section labels.
					'personal-options'     => __( 'Personal Options', 'default' ),
					'name'                 => __( 'Name', 'default' ),
					'contact-info'         => __( 'Contact Info', 'default' ),
					'about-yourself'       => __( 'About Yourself', 'default' ),
					'about-the-user'       => __( 'About the User', 'default' ),
					'account-management'   => __( 'Account Management', 'default' ),
					// phpcs:enable WordPress.WP.I18n.TextDomainMismatch
					'timezone'             => __( 'Timezone', 'woocommerce-appointments' ),
					'availability'         => __( 'Availability Rules', 'woocommerce-appointments' ),
					'google-calendar'      => __( 'Google Calendar', 'woocommerce-appointments' ),
					'assigned-products'    => __( 'Assigned Products', 'woocommerce-appointments' ),
				]
			),
			'i18n'          => [
				'staffSettings'            => __( 'Staff Profile', 'woocommerce-appointments' ),
				'availability'             => __( 'Availability', 'woocommerce-appointments' ),
				'googleCalendar'           => __( 'Google Calendar', 'woocommerce-appointments' ),
				'assignedProducts'         => __( 'Assigned Products', 'woocommerce-appointments' ),
				'otherSettings'            => __( 'Other Settings', 'woocommerce-appointments' ),
				'menuToggle'                => __( 'Toggle menu', 'woocommerce-appointments' ),
				'backToDashboard'          => __( 'Dashboard', 'woocommerce-appointments' ),
			],
		] );

		// Enqueue availability script with dependencies
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script( 'wc_appointments_writepanel_js' );
	}

	/**
	 * Add staff meta fields to the user profile.
	 * @param WP_User $user
	 */
	public function add_staff_meta_fields( $user ): void {
		if ( ! $this->is_staff_user( $user ) ) {
			return;
		}

		$is_admin      = current_user_can( 'manage_others_appointments' );
		$is_admin_edit = $is_admin && ( get_current_user_id() !== $user->ID );
		?>

		<?php if ( $is_admin_edit ) : ?>
		<div class="wca-staff-profile-fields">
		<?php endif; ?>

		<h2 id="wca-section-google-calendar" data-section="google-calendar">
			<?php esc_html_e( 'Google Calendar', 'woocommerce-appointments' ); ?>
		</h2>
		<?php $this->render_google_calendar_fields( $user ); ?>

		<h2 id="wca-section-availability" data-section="availability">
			<?php esc_html_e( 'Availability Rules', 'woocommerce-appointments' ); ?>
			<?php
			if ( class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::should_show_timezone( 'admin', get_current_user_id() ) ) {
				$availability_heading_tz = WC_Appointments_Timezone_Helper::get_staff_timezone( $user->ID );
				if ( $is_admin_edit ) {
					$availability_heading_tz = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
				}
				if ( $availability_heading_tz ) {
					echo wp_kses_post( WC_Appointments_Timezone_Helper::build_timezone_indicator_html( $availability_heading_tz ) );
				}
			}
			?>
		</h2>
		<?php $this->render_availability_fields( $user, $is_admin_edit ); ?>

		<h2 id="wca-section-assigned-products" data-section="assigned-products">
			<?php esc_html_e( 'Assigned Products', 'woocommerce-appointments' ); ?>
		</h2>
		<?php $this->render_products_fields( $user ); ?>

		<?php if ( $is_admin_edit ) : ?>
		</div><!-- .wca-staff-profile-fields -->
		<?php endif; ?>
		<?php
	}

	/**
	 * Render availability fields.
	 * @param WP_User $user
	 */
	private function render_availability_fields( $user, bool $is_admin_edit = false ): void {
		unset( $is_admin_edit );
		$hub_url = WC_Appointments_Admin_Availability_Hub::url( 'staff', $user->ID );
		?>
		<p class="description wca-hub-deeplink-notice">
			<?php
			echo wp_kses_post(
				sprintf(
					/* translators: %s: Availability hub URL */
					__( 'Working hours and time off are managed in the <a href="%s">Availability</a> hub.', 'woocommerce-appointments' ),
					esc_url( $hub_url )
				)
			);
			?>
		</p>
		<?php
	}

	/**
	 * @param WP_User $user
	 */
	private function render_google_calendar_fields( $user ): void {
		$calendar_id = get_user_meta( $user->ID, 'wc_appointments_gcal_calendar_id', true );
		$two_way     = get_user_meta( $user->ID, 'wc_appointments_gcal_twoway', true );

		if ( ! class_exists( 'WC_Appointments_GCal' ) ) {
			echo '<p class="description">' . esc_html__( 'Google Calendar integration is not available.', 'woocommerce-appointments' ) . '</p>';
			return;
		}

		$gcal = wc_appointments_gcal();

		// Check global OAuth setup first (client_id and client_secret must be configured).
		$has_client_id     = $gcal->get_client_id();
		$has_client_secret = $gcal->get_client_secret();

		if ( ! $has_client_id || ! $has_client_secret ) {
			?>
			<p class="description">
				<?php
				if ( current_user_can( 'manage_others_appointments' ) ) {
					echo wp_kses_post(
						sprintf(
							/* translators: %s: link to google calendar sync settings */
							__( 'Google Calendar sync requires configuration. Please set up <a href="%s">Google Calendar Sync settings</a>.', 'woocommerce-appointments' ),
							esc_url( admin_url( 'admin.php?page=wc-settings&tab=appointments&section=gcal' ) )
						)
					);
				} else {
					esc_html_e( 'Google Calendar sync has not been configured yet. Please contact an administrator to set it up.', 'woocommerce-appointments' );
				}
				?>
			</p>
			<?php
			return;
		}

		// Check authentication — staff must have their own token.
		// Do NOT fall back to global token; staff should not see/select
		// calendars from the globally synced account.
		$is_authenticated = (bool) get_user_meta( $user->ID, 'wc_appointments_gcal_refresh_token', true );

		?>
		<table class="form-table">
			<?php if ( $is_authenticated ) : ?>
				<tr>
					<th><label for="wc_appointments_gcal_calendar_id"><?php esc_html_e( 'Calendar', 'woocommerce-appointments' ); ?></label></th>
					<td>
						<?php
						// Staff is authenticated with their own token at this point.
						$gcal->set_user_id( $user->ID );
						$calendars = $gcal->get_calendars();
						if ( ! empty( $calendars ) ) : ?>
							<select id="wc_appointments_gcal_calendar_id" name="wc_appointments_gcal_calendar_id" class="wca-wide-select">
								<option value=""><?php esc_html_e( 'Select a calendar', 'woocommerce-appointments' ); ?></option>
								<?php foreach ( $calendars as $cal_id => $cal_summary ) : ?>
									<option value="<?php echo esc_attr( $cal_id ); ?>" <?php selected( $calendar_id, $cal_id ); ?>>
										<?php echo esc_html( $cal_summary ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'No calendars found. The Google Calendar connection may need to be re-authorized.', 'woocommerce-appointments' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><label for="wc_appointments_gcal_twoway"><?php esc_html_e( 'Sync Mode', 'woocommerce-appointments' ); ?></label></th>
					<td>
						<select id="wc_appointments_gcal_twoway" name="wc_appointments_gcal_twoway" class="wca-wide-select">
							<option value="one_way" <?php selected( $two_way, 'one_way' ); ?>><?php esc_html_e( 'One-way (Appointments → Google)', 'woocommerce-appointments' ); ?></option>
							<option value="two_way" <?php selected( $two_way, 'two_way' ); ?>><?php esc_html_e( 'Two-way sync', 'woocommerce-appointments' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Connection', 'woocommerce-appointments' ); ?></th>
					<td>
						<span class="wca-gcal-status wca-gcal-connected">
							<span class="dashicons dashicons-yes-alt"></span>
							<?php esc_html_e( 'Connected', 'woocommerce-appointments' ); ?>
						</span>
						<button type="button" class="button button-secondary oauth_redirect" data-staff="<?php echo esc_attr( $user->ID ); ?>" data-logout="1">
							<?php esc_html_e( 'Disconnect', 'woocommerce-appointments' ); ?>
						</button>
					</td>
				</tr>
			<?php else : ?>
				<tr>
					<th><?php esc_html_e( 'Connection', 'woocommerce-appointments' ); ?></th>
					<td>
						<?php
						echo wp_kses(
							WC_Appointments_GCal::get_google_oauth_connect_button_html(
								[
									'data-staff'  => (string) $user->ID,
									'data-logout' => '0',
								]
							),
							WC_Appointments_GCal::get_google_oauth_connect_button_kses_allowed_html()
						);
						?>
						<p class="description"><?php esc_html_e( 'Connect your Google account to sync appointments with your calendar.', 'woocommerce-appointments' ); ?></p>
					</td>
				</tr>
			<?php endif; ?>
		</table>
		<?php
	}

	/**
	 * Render assigned products fields.
	 * @param WP_User $user
	 */
	private function render_products_fields( $user ): void {
		$staff_product_ids = WC_Data_Store::load( 'product-appointment' )->get_appointable_product_ids_for_staff( $user->ID );
		$can_edit_products = WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'manage_products' );
		$can_view_details  = WC_Appointments_Staff_Permissions::can( get_current_user_id(), 'view_assigned_products' );

		// Duration unit labels.
		$duration_unit_labels = [
			'minute' => _x( 'min', 'duration unit abbreviation', 'woocommerce-appointments' ),
			'hour'   => _x( 'hr', 'duration unit abbreviation', 'woocommerce-appointments' ),
			'day'    => _x( 'day', 'duration unit abbreviation', 'woocommerce-appointments' ),
			'month'  => _x( 'mo', 'duration unit abbreviation', 'woocommerce-appointments' ),
		];
		?>

		<?php if ( empty( $staff_product_ids ) ) : ?>
			<div class="wca-no-products">
				<span class="dashicons dashicons-products"></span>
				<p><strong><?php esc_html_e( 'No products assigned yet', 'woocommerce-appointments' ); ?></strong></p>
				<p><?php esc_html_e( 'Products will appear here once an administrator assigns you to appointable products.', 'woocommerce-appointments' ); ?></p>
			</div>
		<?php else : ?>
			<?php if ( $can_view_details ) : ?>
				<p class="description"><?php esc_html_e( 'These are the products/services you are assigned to. Your additional cost is added to the base price. Your capacity overrides the product default.', 'woocommerce-appointments' ); ?></p>
			<?php else : ?>
				<p class="description"><?php esc_html_e( 'These are the products/services you are assigned to.', 'woocommerce-appointments' ); ?></p>
			<?php endif; ?>

			<table class="widefat wca-staff-products-table <?php echo $can_view_details ? 'wca-has-details' : ''; ?>">
				<thead>
					<tr>
						<th class="wca-col-product"><?php esc_html_e( 'Product', 'woocommerce-appointments' ); ?></th>
						<?php if ( $can_view_details ) : ?>
							<th class="wca-col-price"><?php esc_html_e( 'Base Price', 'woocommerce-appointments' ); ?></th>
							<th class="wca-col-cost"><?php esc_html_e( 'Your Cost (+/−)', 'woocommerce-appointments' ); ?></th>
							<th class="wca-col-product-qty"><?php esc_html_e( 'Product Capacity', 'woocommerce-appointments' ); ?></th>
							<th class="wca-col-staff-qty"><?php esc_html_e( 'Your Capacity', 'woocommerce-appointments' ); ?></th>
						<?php endif; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $staff_product_ids as $product_id ) :
						$product = get_wc_product_appointment( $product_id );
						if ( ! is_wc_appointment_product( $product ) ) continue;

						$staff_base_costs = $product->get_staff_base_costs();
						$staff_qtys       = $product->get_staff_qtys();
						$base_cost        = isset( $staff_base_costs[ $user->ID ] ) ? $staff_base_costs[ $user->ID ] : '';
						$qty              = isset( $staff_qtys[ $user->ID ] ) ? $staff_qtys[ $user->ID ] : '';

						// Staff qty: treat 0 as "no override" (empty).
						$staff_qty_display = ( '' !== $qty && 0 !== (int) $qty ) ? $qty : '';

						// Product info.
						$base_price    = (float) $product->get_price();
						$duration      = $product->get_duration();
						$duration_unit = $product->get_duration_unit();
						$duration_label = $duration . ' ' . ( $duration_unit_labels[ $duration_unit ] ?? $duration_unit );

						// Quantity basis: per slot or per day.
						$qty_basis       = $product->get_qty_basis();
						$qty_basis_label = 'day' === $qty_basis
							? __( 'per day', 'woocommerce-appointments' )
							: __( 'per slot', 'woocommerce-appointments' );

						// Product capacity (default).
						$product_qty = $product->get_qty();

						// Effective price when staff cost is set.
						$has_staff_cost  = ( '' !== $base_cost && 0 != (float) $base_cost );
						$effective_price = $has_staff_cost ? $base_price + (float) $base_cost : null;
					?>
					<tr>
						<td class="wca-col-product">
							<?php if ( $can_edit_products ) : ?>
								<a href="<?php echo esc_url( get_edit_post_link( $product_id ) ); ?>">
									<?php echo esc_html( $product->get_name() ); ?>
								</a>
							<?php else : ?>
								<strong><?php echo esc_html( $product->get_name() ); ?></strong>
							<?php endif; ?>
							<span class="wca-product-duration"><?php echo esc_html( $duration_label ); ?></span>
						</td>
						<?php if ( $can_view_details ) : ?>
						<td class="wca-col-price">
							<span class="wca-base-price"><?php echo wp_kses_post( wc_price( $base_price ) ); ?></span>
						</td>
						<td class="wca-col-cost">
							<input type="number" name="staff_base_costs[<?php echo esc_attr( $product_id ); ?>]" value="<?php echo esc_attr( $base_cost ); ?>" step="0.01" placeholder="0.00" class="wca-price-input" data-base-price="<?php echo esc_attr( $base_price ); ?>" />
							<span class="wca-effective-price" <?php echo ( null === $effective_price ) ? 'style="display:none"' : ''; ?>>
								= <span class="wca-effective-amount <?php echo ( $has_staff_cost && (float) $base_cost < 0 ) ? 'wca-discount' : ''; ?>"><?php echo null !== $effective_price ? wp_kses_post( wc_price( $effective_price ) ) : ''; ?></span>
							</span>
						</td>
						<td class="wca-col-product-qty">
							<span class="wca-product-qty-value"><?php echo esc_html( $product_qty ); ?></span>
							<span class="wca-qty-basis"><?php echo esc_html( $qty_basis_label ); ?></span>
						</td>
						<td class="wca-col-staff-qty">
							<input type="number" name="staff_qtys[<?php echo esc_attr( $product_id ); ?>]" value="<?php echo esc_attr( $staff_qty_display ); ?>" min="0" placeholder="&#8212;" class="wca-qty-input" />
							<span class="wca-qty-basis"><?php echo esc_html( $qty_basis_label ); ?></span>
						</td>
						<input type="hidden" name="staff_product_id[]" value="<?php echo esc_attr( $product_id ); ?>" />
						<?php endif; ?>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif;
	}

	/**
	 * Save staff meta fields.
	 * @param int $user_id
	 */
	public function save_staff_meta_fields( $user_id ): void {
		$user = get_userdata( $user_id );
		if ( ! $this->is_staff_user( $user ) ) {
			return;
		}

		$posted = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field; profile save verifies nonce.

		// Availability rules moved to the Availability hub (AJAX save).

		// Save assigned products
		$staff_products   = isset( $posted['staff_product_id'] ) && is_array( $posted['staff_product_id'] ) ? array_map( 'absint', $posted['staff_product_id'] ) : [];
		$staff_base_costs = isset( $posted['staff_base_costs'] ) && is_array( $posted['staff_base_costs'] ) ? $posted['staff_base_costs'] : [];
		$staff_qtys       = isset( $posted['staff_qtys'] ) && is_array( $posted['staff_qtys'] ) ? $posted['staff_qtys'] : [];

		if ( [] !== $staff_products ) {
			foreach ( $staff_products as $staff_product_id ) {
				$appointable_product = get_wc_product_appointment( $staff_product_id );
				if ( ! is_wc_appointment_product( $appointable_product ) ) {
					continue;
				}

				$staff_ids = $appointable_product->get_staff_ids();
				if ( ! in_array( $user_id, $staff_ids ) ) {
					$staff_ids[] = $user_id;
				}
				$appointable_product->set_staff_ids( $staff_ids );

				$product_staff_base_costs             = $appointable_product->get_staff_base_costs();
				$product_staff_base_costs[ $user_id ] = floatval( wc_clean( $staff_base_costs[ $staff_product_id ] ?? 0 ) );
				$appointable_product->set_staff_base_costs( $product_staff_base_costs );

				$product_staff_qtys             = $appointable_product->get_staff_qtys();
				$product_staff_qtys[ $user_id ] = absint( $staff_qtys[ $staff_product_id ] ?? 0 );
				$appointable_product->set_staff_qtys( $product_staff_qtys );

				$appointable_product->save();
			}
		}

		// Google Calendar settings
		$calendar_id = wc_clean( $posted['wc_appointments_gcal_calendar_id'] ?? '' );
		update_user_meta( $user_id, 'wc_appointments_gcal_calendar_id', $calendar_id );

		$two_way = wc_clean( $posted['wc_appointments_gcal_twoway'] ?? 'one_way' );
		update_user_meta( $user_id, 'wc_appointments_gcal_twoway', $two_way );

		WC_Appointments_Cache::flush_staff_products_transients( $user_id );
	}

	/**
	 * Actions to be done when staff is deleted.
	 */
	public function delete_staff( string $user_id ): void {
		$user_meta = get_userdata( (int) $user_id );

		if ( in_array( 'shop_staff', (array) $user_meta->roles ) ) {
			// Remove staff from appointments
			$appointments_args  = [
				'status'      => get_wc_appointment_statuses( 'validate' ),
				'object_id'   => absint( $user_id ),
				'object_type' => 'staff',
			];
			$staff_appointments = WC_Appointment_Data_Store::get_appointment_ids_by( $appointments_args );
			if ( ! empty( $staff_appointments ) ) {
				foreach ( $staff_appointments as $staff_appointment_id ) {
					WC_Appointment_Data_Store::clear_staff_ids( (int) $staff_appointment_id );
				}
			}

			// Remove staff from products
			$staff_product_ids = WC_Data_Store::load( 'product-appointment' )->get_appointable_product_ids_for_staff( (int) $user_id );
			if ( ! empty( $staff_product_ids ) ) {
				foreach ( $staff_product_ids as $staff_product_id ) {
					WC_Data_Store::load( 'product-appointment' )->remove_staff_from_product( (int) $user_id, $staff_product_id );
				}
			}

		} elseif ( in_array( 'customer', (array) $user_meta->roles ) ) {
			$customer_appointments_args = [
				'status'      => get_wc_appointment_statuses( 'user' ),
				'object_id'   => absint( $user_id ),
				'object_type' => 'customer',
			];
			$customer_appointments      = WC_Appointment_Data_Store::get_appointment_ids_by( $customer_appointments_args );
			if ( ! empty( $customer_appointments ) ) {
				foreach ( $customer_appointments as $customer_appointment_id ) {
					WC_Appointment_Data_Store::clear_customer_id( (int) $customer_appointment_id );
				}
			}
		}

		WC_Appointments_Cache::flush_staff_products_transients( $user_id );
	}
}

return new WC_Appointments_Admin_Staff_Profile();
