<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Checkout_Manager class.
 */
class WC_Appointment_Checkout_Manager {
	use WC_Appointments_Manager_Trait;

	/**
	 * Constructor
	 */
	public function __construct() {
		if ( $this->is_active() ) {
			$this->register_hooks();
		}
	}

	/**
	 * Register WordPress hooks for this manager.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_filter( 'woocommerce_available_payment_gateways', [ $this, 'remove_payment_methods' ] );
		add_filter( 'woocommerce_available_payment_gateways', [ $this, 'series_balance_order_payment_gateways' ], 999 );
		add_filter( 'woocommerce_cart_needs_payment', [ $this, 'appointment_requires_confirmation' ], 10, 2 );
		add_filter( 'woocommerce_order_needs_payment', [ $this, 'appointment_order_requires_confirmation' ], 10, 3 );
		add_filter( 'woocommerce_order_needs_payment', [ $this, 'series_balance_order_needs_payment' ], 100, 3 );
	}

	/**
     * Removes all payment methods when cart has an appointment that requires confirmation.
     *
     * @since 1.0.0
     *
     * @param array<string, WC_Payment_Gateway> $available_gateways Available payment gateways.
     *
     * @return array<string, WC_Payment_Gateway>
     */
    public function remove_payment_methods( array $available_gateways ) {
		if ( is_wc_endpoint_url( 'order-pay' ) || absint( get_query_var( 'order-pay' ) ) ) {
			return $available_gateways;
		}

		if ( wc_appointment_cart_requires_confirmation() ) {
			unset( $available_gateways );

			$available_gateways                          = [];
			$available_gateways['wcappointmentsgateway'] = new WC_Appointments_Gateway();
		}

		return $available_gateways;
	}

	/**
	 * Always require payment if the order have an appointment that requires confirmation.
	 *
	 * @since 1.0.0
	 *
	 * @param  bool $needs_payment
	 * @param  WC_Cart $cart
	 *
	 * @return bool
	 */
	public function appointment_requires_confirmation( $needs_payment, $cart ) {
		if ( ! $needs_payment ) {
			foreach ( $cart->cart_contents as $cart_item ) {
				if ( wc_appointment_requires_confirmation( $cart_item['product_id'] ) ) {
					$needs_payment = true;
					break;
				}
			}
		}

		return $needs_payment;
	}

	/**
	 * If a appointable product is in the order and that appointable product requires confirmation, the order
	 * "requires payment" regardless of the order total.
	 *
	 * @since 1.0.0
	 *
	 * @param  bool          $needs_payment the WooCommerce value passed to the 'woocommerce_order_needs_payment' filter
	 * @param  WC_Order      $order the WooCommerce order
	 * @param  list<string>  $valid_order_statuses
	 * @return bool  the filtered value of $needs_payment
	 */
	public function appointment_order_requires_confirmation( $needs_payment, $order, $valid_order_statuses ) {
		if ( ! $needs_payment && $order->has_status( $valid_order_statuses ) ) {
			$order_items = $order->get_items();
			foreach ( $order_items as $order_item ) {
				if ( wc_appointment_requires_confirmation( $order_item['product_id'] ) ) {
					$needs_payment = true;
					break;
				}
			}
		}

		return $needs_payment;
	}

	/**
	 * Fee-only pay-first balance orders must be payable when total &gt; 0 and status is pending/failed.
	 *
	 * @param bool         $needs_payment        Filtered flag.
	 * @param WC_Order     $order                Order.
	 * @param list<string> $valid_order_statuses Payable statuses.
	 * @return bool
	 */
	public function series_balance_order_needs_payment( $needs_payment, $order, $valid_order_statuses ) {
		unset( $valid_order_statuses );

		if ( $needs_payment || ! $order instanceof WC_Order || ! class_exists( 'WC_Appointment_Series_Payment', false ) || ! WC_Appointment_Series_Payment::is_balance_order( $order ) ) {
			return $needs_payment;
		}

		return WC_Appointment_Series_Payment::balance_order_is_payable( $order );
	}

	/**
	 * Order-pay gateways for series balance orders (restore when empty; omit WCPay express shells).
	 *
	 * @param array<string, WC_Payment_Gateway> $gateways Available gateways.
	 * @return array<string, WC_Payment_Gateway>
	 */
	public function series_balance_order_payment_gateways( $gateways ) {
		if ( ! class_exists( 'WC_Appointment_Series_Payment', false ) ) {
			return $gateways;
		}

		$order_id = absint( get_query_var( 'order-pay' ) );
		if ( ! is_wc_endpoint_url( 'order-pay' ) && ! $order_id ) {
			return $gateways;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || ! WC_Appointment_Series_Payment::is_balance_order( $order ) ) {
			return $gateways;
		}

		if ( empty( $gateways ) ) {
			$gateways = WC()->payment_gateways()->payment_gateways();
		}

		foreach ( array_keys( $gateways ) as $gateway_id ) {
			$gateway = $gateways[ $gateway_id ];
			if ( 'wcappointmentsgateway' === $gateway_id || 'yes' !== $gateway->enabled || ! $gateway->is_available() ) {
				unset( $gateways[ $gateway_id ] );
				continue;
			}
			if ( class_exists( 'WC_Payment_Gateway_WCPay', false ) && $gateway instanceof WC_Payment_Gateway_WCPay && WC_Payment_Gateway_WCPay::GATEWAY_ID !== $gateway_id ) {
				unset( $gateways[ $gateway_id ] );
			}
		}

		return $gateways;
	}
}

$GLOBALS['wc_appointment_checkout_manager'] = new WC_Appointment_Checkout_Manager();
