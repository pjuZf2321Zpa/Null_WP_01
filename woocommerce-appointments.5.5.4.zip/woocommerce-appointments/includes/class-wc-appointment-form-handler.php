<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Handle frontend forms
 *
 * Manages frontend appointment actions including cancellation and rescheduling.
 * Handles form submissions and user-initiated appointment modifications.
 *
 * @package WooCommerce Appointments
 * @since 1.0.0
 */
class WC_Appointment_Form_Handler implements WC_Appointments_Form_Handler_Interface {

	/**
	 * Hook in methods.
	 *
	 * @since 1.0.0
	 */
	public static function init(): void {
		add_action( 'wp_loaded', [ self::class, 'cancel_appointment' ], 20 );
		add_action( 'wp_loaded', [ self::class, 'reschedule_appointment' ], 20 );
	}

	/**
	 * @param array<string, mixed> $posted_data Posted form data.
	 * @param WC_Product_Appointment $product Product.
	 * @return WC_Appointment|WP_Error
	 */
	public function process_submission( array $posted_data, WC_Product_Appointment $product ) {
		$validation = $this->validate_submission( $posted_data, $product );
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$data = wc_appointments_get_posted_data( $posted_data, $product );

		$appointment_data = [
			'product_id'     => $product->get_id(),
			'cost'           => $data['_cost'] ?? 0,
			'start_date'     => $data['_start_date'] ?? '',
			'end_date'       => $data['_end_date'] ?? '',
			'all_day'        => $data['_all_day'] ?? false,
			'qty'            => $data['_qty'] ?? 1,
			'timezone'       => $data['_timezone'] ?? '',
			'local_timezone' => $data['_local_timezone'] ?? '',
		];

		if ( isset( $data['_staff_id'] ) ) {
			$appointment_data['staff_id'] = $data['_staff_id'];
		}

		if ( isset( $data['_staff_ids'] ) ) {
			$appointment_data['staff_ids'] = $data['_staff_ids'];
		}

		$handler = new WC_Appointment_Booking_Handler();
		return $handler->create_appointment( $product->get_id(), $appointment_data, WC_Appointments_Constants::STATUS_IN_CART, true );
	}

	/**
	 * @param array<string, mixed> $posted_data Posted form data.
	 * @param WC_Product_Appointment $product Product.
	 * @return true|WP_Error
	 */
	public function validate_submission( array $posted_data, WC_Product_Appointment $product ) {
		$data = wc_appointments_get_posted_data( $posted_data, $product );

		$start = isset( $data['_start_date'] ) ? intval( $data['_start_date'] ) : 0;
		$end   = isset( $data['_end_date'] ) ? intval( $data['_end_date'] ) : 0;

		if ( $start <= 0 || $end <= 0 ) {
			return new WP_Error( 'invalid_dates', __( 'Missing appointment dates.', 'woocommerce-appointments' ) );
		}

		if ( $end <= $start ) {
			return new WP_Error( 'invalid_dates_order', __( 'End date must be after start date.', 'woocommerce-appointments' ) );
		}

		return true;
	}

	// ------------------------------------------------------------------
	//  Shared guards
	// ------------------------------------------------------------------

	/**
	 * Check whether the current user owns the appointment (via customer_id or order).
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 * @return bool
	 */
	private static function current_user_owns( WC_Appointment $appointment ): bool {
		$owner_id = (int) $appointment->get_customer_id();
		if ( ! $owner_id ) {
			$order    = $appointment->get_order();
			$owner_id = $order ? (int) $order->get_customer_id() : 0;
		}
		return $owner_id === get_current_user_id();
	}

	/**
	 * Add an error notice and optionally redirect + exit.
	 *
	 * @param string      $message  Notice text.
	 * @param string|null $redirect Redirect URL (null = no redirect).
	 * @param string      $type     Notice type. Default 'error'.
	 */
	private static function bail( string $message, ?string $redirect = null, string $type = 'error' ): void {
		wc_add_notice( $message, $type );
		if ( $redirect ) {
			wp_safe_redirect( $redirect );
			exit;
		}
	}

	/**
	 * Apply posted location/resource snapshots onto a rescheduled appointment.
	 *
	 * @param WC_Appointment       $appointment Appointment.
	 * @param array<string, mixed> $data        Posted appointment data.
	 */
	private static function apply_posted_entities( WC_Appointment $appointment, array $data ): void {
		if ( ! empty( $data['_location_id'] ) && class_exists( 'WC_Appointments_Location' ) ) {
			WC_Appointments_Location::apply_to_appointment( $appointment, (int) $data['_location_id'], $data['_location'] ?? null );
		}
		if ( ! empty( $data['_resource_allocations'] ) && class_exists( 'WC_Appointments_Resource' ) ) {
			WC_Appointments_Resource::apply_to_appointment( $appointment, $data['_resource_allocations'] );
		}
	}

	/**
	 * Build the reschedule success notice and fire hooks.
	 *
	 * Shared between series and non-series paths.
	 *
	 * @param WC_Appointment   $appointment     Refreshed appointment.
	 * @param WC_Order|false   $order           Parent order (or false).
	 * @param string           $prev_start_date Previous start date string (customer/notice display).
	 * @param string           $prev_end_date   Previous end date string (customer/notice display).
	 * @param int              $prev_start_ts   Previous start site-axis timestamp for email TZ formatting.
	 * @param int              $prev_end_ts     Previous end site-axis timestamp for email TZ formatting.
	 */
	private static function reschedule_success( WC_Appointment $appointment, $order, string $prev_start_date, string $prev_end_date, int $prev_start_ts = 0, int $prev_end_ts = 0 ): void {
		$notice = apply_filters(
			'woocommerce_appointment_rescheduled_notice',
			sprintf(
				/* translators: %1$d: appointment id, %2$s: old appointment time, %3$s: new appointment time */
				__( 'Appointment #%1$d has been rescheduled from %2$s to %3$s.', 'woocommerce-appointments' ),
				$appointment->get_id(),
				$prev_start_date,
				$appointment->get_start_date()
			)
		);

		if ( $order ) {
			$order->add_order_note( $notice, 0, true );
		}

		wc_add_notice(
			$notice,
			apply_filters( 'woocommerce_appointment_rescheduled_notice_type', 'notice' )
		);

		do_action( 'woocommerce_appointments_rescheduled_appointment', $appointment->get_id(), $prev_start_date, $prev_end_date, $prev_start_ts, $prev_end_ts );
	}

	// ------------------------------------------------------------------
	//  Cancel
	// ------------------------------------------------------------------

	/**
	 * Cancel an appointment.
	 *
	 * @since 1.0.0
	 */
	public static function cancel_appointment(): void {
		if ( ! isset( $_GET['cancel_appointment'], $_GET['appointment_id'] ) ) {
			return;
		}

		$appointment_id = absint( $_GET['appointment_id'] );
		$appointment    = get_wc_appointment( $appointment_id );

		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			wc_add_notice( __( 'Invalid appointment.', 'woocommerce-appointments' ), 'error' );
			return;
		}

		$redirect = apply_filters(
			'woocommerce_appointments_cancel_appointment_redirect',
			isset( $_GET['redirect'] ) ? esc_url_raw( wp_unslash( $_GET['redirect'] ) ) : '',
			$appointment,
		);

		if ( ! self::current_user_owns( $appointment ) ) {
			self::bail( __( 'You do not have permission to cancel this appointment.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		if ( $appointment->has_status( WC_Appointments_Constants::STATUS_CANCELLED ) ) {
			self::bail( __( 'Your appointment has already been cancelled.', 'woocommerce-appointments' ), $redirect, 'notice' );
			return;
		}

		if ( ! $appointment->has_status( get_wc_appointment_statuses( 'cancel' ) ) ) {
			self::bail( __( 'Your appointment can no longer be cancelled. Please contact us if you need assistance.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		$cancel_nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
		if ( $appointment->get_id() != $appointment_id
			|| '' === $cancel_nonce
			|| ! wp_verify_nonce( $cancel_nonce, 'woocommerce-appointments-cancel_appointment' )
		) {
			self::bail( __( 'Invalid appointment.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		// Series occurrence: cancel via scope layer (EXDATE) instead of orphaning the occurrence.
		if ( class_exists( 'WC_Appointment_Series_Scope' ) && class_exists( 'WC_Appointment_Series_Events' ) && WC_Appointment_Series_Events::is_enabled() && (int) $appointment->get_meta( '_wca_series_id' ) > 0 ) {
			$sr = WC_Appointment_Series_Scope::apply_status( $appointment, 'cancelled', WC_Appointment_Series_Scope::ONE );
			if ( is_wp_error( $sr ) ) {
				self::bail( $sr->get_error_message(), $redirect );
				return;
			}
		} else {
			$appointment->update_status( WC_Appointments_Constants::STATUS_CANCELLED );
		}
		WC_Cache_Helper::get_transient_version( 'appointments', true );

		wc_add_notice(
			apply_filters( 'woocommerce_appointment_cancelled_notice', __( 'Your appointment has been cancelled.', 'woocommerce-appointments' ) ),
			apply_filters( 'woocommerce_appointment_cancelled_notice_type', 'notice' )
		);

		do_action( 'woocommerce_appointments_cancelled_appointment', $appointment->get_id() );

		if ( $redirect ) {
			wp_safe_redirect( $redirect );
			exit;
		}
	}

	// ------------------------------------------------------------------
	//  Reschedule
	// ------------------------------------------------------------------

	/**
	 * Reschedule an appointment.
	 *
	 * @since 4.9.8
	 */
	public static function reschedule_appointment(): void {
		if ( ! isset( $_POST['reschedule-appointment'], $_POST['appointment-id'] ) ) {
			return;
		}

		$appointment_id = intval( $_POST['appointment-id'] );
		$appointment    = get_wc_appointment( $appointment_id );

		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			wc_add_notice( __( 'Invalid appointment.', 'woocommerce-appointments' ), 'error' );
			return;
		}

		$redirect = apply_filters(
			'woocommerce_appointments_reschedule_appointment_redirect',
			esc_url( wc_get_endpoint_url( 'appointments', '', wc_get_page_permalink( 'myaccount' ) ) ),
			$appointment,
		);

		// --- Guards (before any mutation) ---

		if ( $appointment->has_status( WC_Appointments_Constants::STATUS_CANCELLED ) ) {
			self::bail( __( 'Your appointment has already been cancelled.', 'woocommerce-appointments' ), $redirect, 'notice' );
			return;
		}

		$reschedule_nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
		if ( $appointment->get_id() != $appointment_id
			|| '' === $reschedule_nonce
			|| ! wp_verify_nonce( $reschedule_nonce, 'woocommerce-appointments-reschedule_appointment' )
		) {
			self::bail( __( 'Invalid appointment.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		if ( ! self::current_user_owns( $appointment ) ) {
			self::bail( __( 'Invalid appointment.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		$reschedulable_statuses = apply_filters(
			'woocommerce_appointments_reschedulable_statuses',
			[ 'confirmed', 'paid', 'pending-confirmation', 'unpaid' ]
		);
		if ( ! $appointment->has_status( $reschedulable_statuses ) ) {
			self::bail( __( 'This appointment can no longer be rescheduled.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		if ( $appointment->passed_reschedule_day() ) {
			self::bail( __( 'Your appointment can no longer be rescheduled. Please contact us if you need assistance.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		// --- Product & data ---

		$order           = $appointment->get_order();
		$prev_start_ts   = (int) $appointment->get_start();
		$prev_end_ts     = (int) $appointment->get_end();
		$prev_start_date = $appointment->get_start_date();
		$prev_end_date   = $appointment->get_end_date();
		$product         = $appointment->get_product();

		if ( ! is_wc_appointment_product( $product ) ) {
			self::bail( __( 'Invalid appointment.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		$appointment_duration = $appointment->get_duration_parameters();
		$product->set_duration( $appointment_duration['duration'] );
		$product->set_duration_unit( $appointment_duration['duration_unit'] );

		if ( $appointment->get_staff_ids() ) {
			$product->set_staff_ids( $appointment->get_staff_ids() );
			$product->set_staff_nopref( '' );
		}

		$posted           = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized per field in wc_appointments_get_posted_data().
		$appointment_data = wc_appointments_get_posted_data( $posted, $product );

		// --- Series occurrence (delegates to series manager) ---

		if ( class_exists( 'WC_Appointment_Series_My_Account', false )
			&& class_exists( 'WC_Appointment_Series_Events', false )
			&& WC_Appointment_Series_Events::is_enabled()
			&& (int) $appointment->get_meta( '_wca_series_id' ) > 0
		) {
			$result = WC_Appointment_Series_My_Account::reschedule_occurrence_from_post( $appointment, $appointment_data );
			if ( is_wp_error( $result ) ) {
				wc_add_notice( $result->get_error_message(), 'error' );
			} else {
				$refreshed = get_wc_appointment( $appointment_id );
				if ( is_a( $refreshed, 'WC_Appointment' ) ) {
					self::apply_posted_entities( $refreshed, $appointment_data );
					$refreshed->save();
				}
				self::reschedule_success( is_a( $refreshed, 'WC_Appointment' ) ? $refreshed : $appointment, $order, $prev_start_date, $prev_end_date, $prev_start_ts, $prev_end_ts );
			}

			if ( $redirect ) {
				wp_safe_redirect( $redirect );
				exit;
			}
			return;
		}

		// --- Non-series: validate dates & availability ---

		$start_to_store = isset( $appointment_data['_start_date'] ) ? (int) $appointment_data['_start_date'] : 0;
		$end_to_store   = isset( $appointment_data['_end_date'] ) ? (int) $appointment_data['_end_date'] : 0;
		$all_day_flag   = ! empty( $appointment_data['_all_day'] );

		if ( $start_to_store <= 0 || $end_to_store <= 0 ) {
			self::bail( __( 'Invalid appointment dates.', 'woocommerce-appointments' ), $redirect );
			return;
		}

		$reschedule_qty = max( 1, (int) $appointment->get_qty() );
		$avail_staff_id = 0;
		if ( $product->has_staff() && ! $product->is_staff_assignment_type( 'all' ) ) {
			$avail_staff_id = (int) ( $appointment->get_staff_id() ?: 0 );
		}

		\WC_Appointment_Slots_Engine::set_overlap_exclude_appointment_ids( [ $appointment->get_id() ] );
		try {
			$available = \WC_Appointments_Controller::get_indexed_total_available_for_range(
				$product,
				$start_to_store,
				$end_to_store,
				$avail_staff_id > 0 ? $avail_staff_id : null,
				$reschedule_qty
			);

			if ( \WC_Appointments_Controller::is_indexed_range_unavailable( $product, $available, $avail_staff_id, $reschedule_qty ) ) {
				self::bail( __( 'The selected time slot is no longer available. Please choose another.', 'woocommerce-appointments' ), $redirect );
				return;
			}
		} finally {
			\WC_Appointment_Slots_Engine::clear_overlap_exclude_appointment_ids();
		}

		// --- Persist ---

		do_action( 'woocommerce_appointments_before_rescheduled_appointment', $appointment, $appointment_data );

		$appointment->set_all_day( $all_day_flag );
		if ( ! $all_day_flag ) {
			if ( isset( $appointment_data['_timezone'] ) && is_string( $appointment_data['_timezone'] ) ) {
				$appointment->set_timezone( $appointment_data['_timezone'] );
			}
			if ( isset( $appointment_data['_local_timezone'] ) ) {
				$appointment->set_local_timezone( (string) $appointment_data['_local_timezone'] );
			}
		} else {
			$appointment->set_local_timezone( '' );
		}

		$appointment->set_start( $start_to_store );
		$appointment->set_end( $end_to_store );
		self::apply_posted_entities( $appointment, $appointment_data );
		$appointment->save();

		WC_Cache_Helper::get_transient_version( 'appointments', true );

		self::reschedule_success( $appointment, $order, $prev_start_date, $prev_end_date, $prev_start_ts, $prev_end_ts );

		if ( $redirect ) {
			wp_safe_redirect( $redirect );
			exit;
		}
	}
}

WC_Appointment_Form_Handler::init();
