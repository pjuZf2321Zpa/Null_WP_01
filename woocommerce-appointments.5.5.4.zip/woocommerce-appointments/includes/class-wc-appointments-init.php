<?php
// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * Initializes appointments.
 *
 * @since 4.3.4
 */
class WC_Appointments_Init
{
	/**
	 * Constructor.
	 *
	 * Initialize the plugin and hook into WordPress/WooCommerce.
	 *
	 * @since 4.3.4
	 */
	public function __construct()
	{
		add_action('init', [$this, 'init_post_types'], 9);

		// Load payment gateway name.
		add_filter('woocommerce_payment_gateways', [$this, 'include_gateway']);

		add_action('admin_init', [$this, 'init_wc_admin_bar']);
		add_action('admin_init', [$this, 'register_admin_calendar_assets']);
		add_action('wp_enqueue_scripts', [$this, 'appointment_form_styles'], 99); #front
		add_action('wp_enqueue_scripts', [$this, 'appointment_form_scripts'], 99); #front
		add_action('admin_enqueue_scripts', [$this, 'appointment_form_scripts'], 99); #admin
		add_action('admin_enqueue_scripts', [$this, 'appointment_admin_analytics'], 99); #admin
		add_filter('woocommerce_data_stores', [$this, 'register_data_stores']);
		add_filter('woocommerce_product_class', [$this, 'woocommerce_product_class'], 10, 2);
		add_filter('product_type_selector', [$this, 'product_type_selector']);
		add_filter( 'woocommerce_locate_template', [ $this, 'woocommerce_locate_template' ], 10, 3 );

		// Default date and time formats must not be empty.
		add_filter('woocommerce_date_format', [$this, 'default_date_format']);
		add_filter('woocommerce_time_format', [$this, 'default_time_format']);

		// Adjust appointment time to staff/customer timezone.
		#add_filter( 'woocommerce_appointments_get_start_date_with_time', [ $this, 'adjust_appointment_to_timezone' ], 15, 3 ); #lower priority
		#add_filter( 'woocommerce_appointments_get_end_date_with_time',  [ $this, 'adjust_appointment_to_timezone' ], 15, 3 ); #lower priority

		// Disable WooCommerce Bloat.
		add_filter('woocommerce_allow_marketplace_suggestions', '__return_false');
		add_filter('woocommerce_admin_onboarding_product_types', [$this, 'onboarding_product_types']);

		// Customer timezone preference in My Account > Account Details.
		add_action('woocommerce_edit_account_form', [$this, 'output_timezone_preference_field']);
		add_action('woocommerce_save_account_details', [$this, 'save_timezone_preference_field']);

		// Show and optionally edit customer timezone in WP Admin user profile.
		add_action('show_user_profile', [$this, 'output_admin_user_timezone_field']);
		add_action('edit_user_profile', [$this, 'output_admin_user_timezone_field']);
		add_action('personal_options_update', [$this, 'save_admin_user_timezone_field']);
		add_action('edit_user_profile_update', [$this, 'save_admin_user_timezone_field']);

		// AJAX handler for saving timezone preference from booking form.
		add_action('wp_ajax_wc_appointments_save_user_timezone', [$this, 'ajax_save_user_timezone']);

		// Tag new appointments with creation timezone metadata.
		add_action('woocommerce_new_appointment', [$this, 'tag_appointment_creation_timezone'], 5, 1);
	}

	/**
	 * Init post types.
	 *
	 * Registers the 'wc_appointment' post type and custom statuses.
	 */
	public function init_post_types(): void
	{
		$this->register_appointment_icon();

		register_post_type(
			'wc_appointment',
			apply_filters(
				'woocommerce_register_post_type_wc_appointment',
				[
					'label' => __('Appointment', 'woocommerce-appointments'),
					'labels' => [
						'name' => __('Appointments', 'woocommerce-appointments'),
						'singular_name' => __('Appointment', 'woocommerce-appointments'),
						'add_new' => __('Add New', 'woocommerce-appointments'),
						'add_new_item' => __('Add New', 'woocommerce-appointments'),
						'edit' => __('Edit', 'woocommerce-appointments'),
						'edit_item' => __('Edit Appointment', 'woocommerce-appointments'),
						'new_item' => __('New Appointment', 'woocommerce-appointments'),
						'view' => __('View Appointment', 'woocommerce-appointments'),
						'view_item' => __('View Appointment', 'woocommerce-appointments'),
						'search_items' => __('Search Appointments', 'woocommerce-appointments'),
						'not_found' => __('No Appointments found', 'woocommerce-appointments'),
						'not_found_in_trash' => __('No Appointments found in trash', 'woocommerce-appointments'),
						'parent' => __('Parent Appointments', 'woocommerce-appointments'),
						'menu_name' => _x('Appointments', 'Admin menu name', 'woocommerce-appointments'),
						'all_items' => __('All Appointments', 'woocommerce-appointments'),
					],
					'description' => __('This is where appointments are stored.', 'woocommerce-appointments'),
					'public' => false,
					'show_ui' => true,
					'capability_type' => 'appointment',
					'menu_icon' => $this->get_appointment_menu_icon(),
					'map_meta_cap' => true,
					'publicly_queryable' => false,
					'exclude_from_search' => true,
					'show_in_menu' => true,
					'hierarchical' => false,
					'show_in_nav_menus' => false,
					'rewrite' => false,
					'query_var' => false,
					'supports' => [''],
					'has_archive' => false,
				],
			),
		);

		/**
		 * Post status
		 */
		register_post_status(
			'complete',
			[
				'label' => '<span class="status-complete tips" data-tip="' . wc_sanitize_tooltip( esc_html__( 'Complete', 'woocommerce-appointments' ) ) . '">' . esc_html__( 'Complete', 'woocommerce-appointments' ) . '</span>',
				'public' => true,
				'exclude_from_search' => false,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count' => _n_noop('Complete <span class="count">(%s)</span>', 'Complete <span class="count">(%s)</span>', 'woocommerce-appointments'),
			],
		);
		register_post_status(
			'paid',
			[
				'label' => '<span class="status-paid tips" data-tip="' . wc_sanitize_tooltip( esc_html__( 'Paid &amp; Confirmed', 'woocommerce-appointments' ) ) . '">' . esc_html__( 'Paid &amp; Confirmed', 'woocommerce-appointments' ) . '</span>',
				'public' => true,
				'exclude_from_search' => false,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count' => _n_noop('Paid &amp; Confirmed <span class="count">(%s)</span>', 'Paid &amp; Confirmed <span class="count">(%s)</span>', 'woocommerce-appointments'),
			],
		);
		register_post_status(
			'confirmed',
			[
				'label' => '<span class="status-confirmed tips" data-tip="' . wc_sanitize_tooltip( esc_html__( 'Confirmed', 'woocommerce-appointments' ) ) . '">' . esc_html__( 'Confirmed', 'woocommerce-appointments' ) . '</span>',
				'public' => true,
				'exclude_from_search' => false,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count' => _n_noop('Confirmed <span class="count">(%s)</span>', 'Confirmed <span class="count">(%s)</span>', 'woocommerce-appointments'),
			],
		);
		register_post_status(
			'unpaid',
			[
				'label' => '<span class="status-unpaid tips" data-tip="' . wc_sanitize_tooltip( esc_html__( 'Un-paid', 'woocommerce-appointments' ) ) . '">' . esc_html__( 'Un-paid', 'woocommerce-appointments' ) . '</span>',
				'public' => true,
				'exclude_from_search' => true,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count' => _n_noop('Un-paid <span class="count">(%s)</span>', 'Un-paid <span class="count">(%s)</span>', 'woocommerce-appointments'),
			],
		);
		register_post_status(
			'pending-confirmation',
			[
				'label' => '<span class="status-pending tips" data-tip="' . wc_sanitize_tooltip( esc_html__( 'Pending Confirmation', 'woocommerce-appointments' ) ) . '">' . esc_html__( 'Pending Confirmation', 'woocommerce-appointments' ) . '</span>',
				'public' => true,
				'exclude_from_search' => false,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count' => _n_noop('Pending Confirmation <span class="count">(%s)</span>', 'Pending Confirmation <span class="count">(%s)</span>', 'woocommerce-appointments'),
			],
		);
		register_post_status(
			'cancelled',
			[
				'label' => '<span class="status-cancelled tips" data-tip="' . wc_sanitize_tooltip( esc_html__( 'Cancelled', 'woocommerce-appointments' ) ) . '">' . esc_html__( 'Cancelled', 'woocommerce-appointments' ) . '</span>',
				'public' => true,
				'exclude_from_search' => false,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count' => _n_noop('Cancelled <span class="count">(%s)</span>', 'Cancelled <span class="count">(%s)</span>', 'woocommerce-appointments'),
			],
		);
		register_post_status(
			'in-cart',
			[
				'label' => '<span class="status-incart tips" data-tip="' . wc_sanitize_tooltip( esc_html__( 'In Cart', 'woocommerce-appointments' ) ) . '">' . esc_html__( 'In Cart', 'woocommerce-appointments' ) . '</span>',
				'public' => false,
				'exclude_from_search' => false,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => true,
				/* translators: %s: count */
				'label_count' => _n_noop('In Cart <span class="count">(%s)</span>', 'In Cart <span class="count">(%s)</span>', 'woocommerce-appointments'),
			],
		);
		register_post_status(
			'was-in-cart',
			[
				'label' => false,
				'public' => false,
				'exclude_from_search' => false,
				'show_in_admin_all_list' => true,
				'show_in_admin_status_list' => false,
				'label_count' => false,
			],
		);

	}

	/**
	 * Register WooCommerce admin bar for appointments.
	 *
	 * Adds Appointments links to the WooCommerce Admin Bar.
	 *
	 * @since 4.9.0
	 */
	public function init_wc_admin_bar(): void
	{
		if (!current_user_can('manage_others_appointments')) {
			return;
		}

		if (function_exists('wc_admin_connect_page')) {
			$posttype_list_base = 'edit.php';

			// WooCommerce > Appointments.
			wc_admin_connect_page(
				[
					'id' => 'woocommerce-appointments',
					'screen_id' => 'edit-wc_appointment',
					'title' => __('Appointments', 'woocommerce-appointments'),
					'path' => add_query_arg('post_type', 'wc_appointment', $posttype_list_base),
				],
			);

			// WooCommerce > Appointments > Export Appointments.
			wc_admin_connect_page(
				[
					'id' => 'woocommerce-export-appointments',
					'parent' => 'woocommerce-appointments',
					'screen_id' => 'wc_appointment_page_appointment_exporter',
					'title' => __('Export Appointments', 'woocommerce-appointments'),
				],
			);

			// WooCommerce > Appointments > Add New.
			wc_admin_connect_page(
				[
					'id' => 'woocommerce-add-appointment',
					'parent' => 'woocommerce-appointments',
					'screen_id' => 'wc_appointment_page_add_appointment',
					'title' => __('Add New', 'woocommerce-appointments'),
				],
			);

			// WooCommerce > Appointments > Edit Appointment.
			wc_admin_connect_page(
				[
					'id' => 'woocommerce-edit-appointment',
					'parent' => 'woocommerce-appointments',
					'screen_id' => 'wc_appointment',
					'title' => __('Edit Appointment', 'woocommerce-appointments'),
				],
			);

			// Calendar is not connected: classic WP Screen Options/Help appear (no WC sticky header).
		}
	}

	/**
	 * Register the Appointments admin menu SVG (WordPress 7.1+ Icons API).
	 *
	 * @since 5.5.1
	 */
	private function register_appointment_icon(): void {
		if ( ! function_exists( 'wp_register_icon' ) ) {
			return;
		}

		wp_register_icon_collection(
			'woocommerce-appointments',
			[ 'label' => __( 'WooCommerce Appointments', 'woocommerce-appointments' ) ]
		);
		wp_register_icon(
			'woocommerce-appointments/appointment',
			[
				'label'     => __( 'Appointments', 'woocommerce-appointments' ),
				'file_path' => WC_APPOINTMENTS_PLUGIN_PATH . '/assets/images/icons/appointment.svg',
			]
		);
	}

	/**
	 * CPT menu icon: Icons API name on WP 7.2+, else base64 SVG data URI.
	 *
	 * Pre-7.2: bake the default admin menu icon gray (`#a2aab2`, same as WooCommerce)
	 * so first paint matches the color scheme; svg-painter.js then recolors for hover/current.
	 * Using `black` flashes until that script runs.
	 *
	 * @since 5.5.1
	 */
	private function get_appointment_menu_icon(): string {
		if ( function_exists( 'wp_is_valid_icon_name' ) ) {
			return 'woocommerce-appointments/appointment';
		}

		$file = WC_APPOINTMENTS_PLUGIN_PATH . '/assets/images/icons/appointment.svg';
		$svg  = is_readable( $file ) ? (string) file_get_contents( $file ) : '';

		return $svg
			? 'data:image/svg+xml;base64,' . base64_encode( str_replace( 'currentColor', '#a2aab2', $svg ) )
			: 'dashicons-clock';
	}

	/**
	 * Register data stores for appointments.
	 *
	 * Registers the data stores for appointments and availability.
	 *
	 * @param array<string, string> $data_stores List of data stores.
	 * @return array<string, string> Modified list of data stores.
	 */
	public function register_data_stores(array $data_stores = []): array
	{
		$data_stores['appointment'] = 'WC_Appointment_Data_Store';
		$data_stores['appointments-availability'] = 'WC_Appointments_Availability_Data_Store';
		$data_stores['appointments-availability-cache'] = 'WC_Appointments_Availability_Cache_Data_Store';
		$data_stores['appointment-series'] = 'WC_Appointment_Series_Data_Store';
		$data_stores['product-appointment'] = 'WC_Product_Appointment_Data_Store_CPT';
		$data_stores['appointments-location'] = 'WC_Appointments_Location_Data_Store';
		$data_stores['appointments-resource'] = 'WC_Appointments_Resource_Data_Store';

		return $data_stores;
	}

	/**
	 * Checks the classname being used for a appointable product type to see if it should be an appointable product
	 * and if so, returns this as the class which should be instantiated (instead of the default
	 * WC_Product_Simple class).
	 *
	 * @param string $classname    The name of the WC_Product_* class which should be instantiated to create an instance of this product.
	 * @param string $product_type Product type slug.
	 * @return string
	 * @since 3.9.4
	 */
	public function woocommerce_product_class($classname, $product_type)
	{
		if ('appointment' === $product_type) {
			return 'WC_Product_Appointment';
		}

		return $classname;
	}

	/**
	 * Register the appointable product type for WooCommerce product queries.
	 *
	 * Must run outside wp-admin so wc_get_products() and similar queries include
	 * appointment products (e.g. AutomateWoo delayed emails via Action Scheduler).
	 *
	 * @param array<string, string> $types Product type labels keyed by slug.
	 * @return array<string, string>
	 */
	public function product_type_selector( array $types ): array {
		$types['appointment'] = __( 'Appointable product', 'woocommerce-appointments' );

		return $types;
	}

	/**
	 * Also allow yourtheme/woocommerce/{template_name} for appointment templates.
	 *
	 * Primary path is already yourtheme/woocommerce-appointments/ via $template_path.
	 *
	 * @param string $template      Located template path.
	 * @param string $template_name Template name.
	 * @param string $template_path Template path slug.
	 * @return string
	 */
	public function woocommerce_locate_template( $template, string $template_name, $template_path ) {
		if ( 'woocommerce-appointments' !== untrailingslashit( (string) $template_path ) ) {
			return $template;
		}

		// Prefer namespaced, then WooCommerce folder (WC already tried namespaced when path matches).
		$theme = locate_template(
			[
				'woocommerce-appointments/' . $template_name,
				trailingslashit( WC()->template_path() ) . $template_name,
			]
		);

		return $theme ? $theme : $template;
	}

	/**
	 * Add a custom payment gateway
	 * This gateway works with appointments that require confirmation.
	 * It's only needed on the front-end so we make sure we hide
	 * that gateway in the admin, as it has no options to configure.
	 *
	 * @param list<string> $gateways Gateway class names.
	 * @return list<string>
	 */
	public function include_gateway($gateways)
	{
		$page = isset($_GET['page']) ? wc_clean(wp_unslash($_GET['page'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$tab = isset($_GET['tab']) ? wc_clean(wp_unslash($_GET['tab'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if (is_admin() && 'wc-settings' === $page && 'checkout' === $tab) {
			return $gateways;
		}

		// Hide the gateway on the payment providers API request (New react-based payments settings page), as it has no options to configure.
		if ($this->is_payment_providers_api_request()) {
			return $gateways;
		}

		$gateways[] = 'WC_Appointments_Gateway';

		return $gateways;
	}

	/**
	 * Default date format.
	 *
	 * Sets the default date format if empty.
	 *
	 * @since 4.2.7
	 * @param string $format Date format.
	 * @return string
	 */
	public function default_date_format($format)
	{
		if ('' === $format) {
			return 'F j, Y';
		}

		return $format;
	}

	/**
	 * Time format should not be zero.
	 *
	 * @since 4.2.7
	 * @param string $format Time format.
	 * @return string
	 */
	public function default_time_format($format)
	{
		if ('' === $format) {
			return 'g:i a';
		}

		return $format;
	}

	/**
	 * Adjust appointment time to staff/customer timezone.
	 *
	 * @since 4.9.3
	 *
	 * @param  string $timestring  Start or End time string.
	 * @param  object $appointment WC_Appointment object.
	 * @param  int    $timestamp   Start or End time stamp.
	 *
	 * @return string Date/time string.
	 */
	public function adjust_appointment_to_timezone($timestring, $appointment, $timestamp)
	{
		if (is_user_logged_in()) {
			$user = wp_get_current_user();
			$current_offset = get_option('gmt_offset');
			$tzstring_site = get_option('timezone_string');
			$tzstring = get_user_meta($user->ID, 'timezone_string', true);
			$tzstring = $tzstring ?: $tzstring_site;
			$date_format = wc_appointments_date_format();
			$time_format = ', ' . wc_appointments_time_format();
			$roles = (array) $user->roles;

			#print '<pre>'; print_r( $roles ); print '</pre>';

			if (in_array('shop_staff', $roles)) {
				$start_date = wc_appointment_timezone_locale( 'site', 'user', $timestamp, 'U', $tzstring );
				$timestring = date_i18n( $date_format . $time_format, $start_date );
				if ( class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
					$timestring .= WC_Appointments_Timezone_Helper::build_timezone_indicator_html(
						$tzstring,
						'wc-appointments-tz-abbr',
						WC_Appointments_Timezone_Helper::get_appointment_utc_start( $appointment )
					);
				}
			} else {
				return $timestring;
			}
		}

		return $timestring;
	}

	/**
	 * Adjust products in the onbarding screen.
	 *
	 * @since 4.10.1
	 *
	 * @param  array<string, array<string, mixed>> $product_types  Product type in the onbarding screen.
	 *
	 * @return array<string, array<string, mixed>> $product_types.
	 */
	public function onboarding_product_types(array $product_types): array
	{
		// Remove Bookings from the onboarding.
		if (isset($product_types['bookings'])) {
			unset($product_types['bookings']);
		}

		// Remove Product Add-ons from the onboarding.
		if (isset($product_types['product-add-ons'])) {
			unset($product_types['product-add-ons']);
		}

		return $product_types;
	}

	/**
	 * Appointment form styles.
	 *
	 * Enqueues stylesheets for the appointment form.
	 */
	public static function appointment_form_styles(): void
	{
		if (!wp_style_is('woocommerce-addons-css', 'registered')) {
			wp_register_style(
				'woocommerce-addons-css',
				WC_APPOINTMENTS_PLUGIN_URL . '/includes/integrations/woocommerce-product-addons/assets/css/frontend/frontend.css',
				[],
				WC_APPOINTMENTS_VERSION,
			);
		}
		wp_register_style(
			'wc-appointments-styles',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/css/frontend.css',
			[
				'woocommerce-addons-css',
			],
			WC_APPOINTMENTS_VERSION,
		);

		// Enqueue styles.
		if (!wp_style_is('select2', 'enqueued')) {
			wp_enqueue_style('select2');
		}
		wp_enqueue_style('wc-appointments-styles');
	}

	/**
	 * Appointment form scripts
	 */
	public static function appointment_form_scripts(): void
	{
		// JS suffix.
		$suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

		// filemtime so Local/browser caches pick up storefront JS without a version bump.
		$script_ver = WC_APPOINTMENTS_VERSION;
		$base       = WC_APPOINTMENTS_PLUGIN_PATH . '/assets/js/';
		$t          = 0;
		foreach ( [ 'appointment-form', 'date-picker', 'time-picker', 'staff-picker' ] as $name ) {
			$path = $base . $name . ( '' === $suffix ? '.js' : $suffix . '.js' );
			if ( file_exists( $path ) ) {
				$t = max( $t, (int) filemtime( $path ) );
			}
		}
		if ( $t > 0 ) {
			$script_ver = WC_APPOINTMENTS_VERSION . '-' . $t;
		}

		wp_register_script(
			'wc-appointments-appointment-form',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/appointment-form' . $suffix . '.js',
			[
				'jquery',
				'jquery-blockui',
				'wca-shared-js',
			],
			$script_ver,
			true,
		);
		wp_register_script(
			'wc-appointments-month-picker',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/month-picker' . $suffix . '.js',
			[
				'wc-appointments-appointment-form',
			],
			WC_APPOINTMENTS_VERSION,
			true,
		);
		wp_register_script(
			'wc-appointments-date-picker',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/date-picker' . $suffix . '.js',
			[
				'wc-appointments-appointment-form',
				'wc-appointments-rrule',
				'jquery-ui-datepicker',
				'underscore',
			],
			$script_ver,
			true,
		);
		wp_register_script(
			'wc-appointments-time-picker',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/time-picker' . $suffix . '.js',
			[
				'wc-appointments-appointment-form',
			],
			$script_ver,
			true,
		);
		wp_register_script(
			'wc-appointments-timezone-picker',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/timezone-picker' . $suffix . '.js',
			[
				'wc-appointments-appointment-form',
			],
			WC_APPOINTMENTS_VERSION,
			true,
		);
		wp_register_script(
			'wc-appointments-staff-picker',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/staff-picker' . $suffix . '.js',
			[
				'wc-appointments-appointment-form',
			],
			$script_ver,
			true,
		);
		wp_register_script(
			'wc-appointments-rrule',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/vendor/rrule/rrule.min.js',
			[],
			WC_APPOINTMENTS_VERSION,
			true,
		);
		wp_register_script(
			'wc-appointments-rrule-tz',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/vendor/rrule/rrule-tz.min.js',
			[],
			WC_APPOINTMENTS_VERSION,
			true,
		);
		wp_register_script(
			'wc-appointments-my-account',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/my-account' . $suffix . '.js',
			[],
			WC_APPOINTMENTS_VERSION,
			true,
		);
		wp_register_script(
			'wc_appointments_analytics_script',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/appointment-analytics.js',
			[
				'wp-i18n',
				'wp-hooks',
				'wc-settings',
			],
			WC_APPOINTMENTS_VERSION,
			true,
		);
		// Ensure translations for analytics strings.
		if (function_exists('wp_set_script_translations')) {
			wp_set_script_translations(
				'wc_appointments_analytics_script',
				'woocommerce-appointments',
				WC_APPOINTMENTS_PLUGIN_PATH . '/languages',
			);
		}

		// Move "Select2" above "selectWoo".
		// Remove once WooCommerce fixes the html rendering issues.
		if (function_exists('get_current_screen')) {
			// Get current screen.
			$screen = get_current_screen();
			$screen_id = $screen ? $screen->id : '';

			if (wp_script_is('selectWoo', 'enqueued') && 'wc_appointment_page_add_appointment' === $screen_id) {
				wp_deregister_script('selectWoo');
				wp_register_script(
					'selectWoo',
					WC()->plugin_url() . '/assets/js/selectWoo/selectWoo.full' . $suffix . '.js',
					[
						'select2',
					],
					WC_APPOINTMENTS_VERSION,
					true,
				);
			}
		}

		// Get $wp_locale.
		$wp_locale = new WP_Locale();

		// Variables for JS scripts
		$appointment_form_params = [
			'nonce_find_day_slots' => wp_create_nonce('find-scheduled-day-slots'),
			'nonce_set_timezone_cookie' => wp_create_nonce('set-timezone-cookie'),
			'nonce_staff_html' => wp_create_nonce('appointable-staff-html'),
			'closeText' => esc_js(__('Close', 'woocommerce-appointments')),
			'currentText' => esc_js(__('Today', 'woocommerce-appointments')),
			'prevText' => esc_js(__('Previous', 'woocommerce-appointments')),
			'nextText' => esc_js(__('Next', 'woocommerce-appointments')),
			'monthNames' => array_values($wp_locale->month),
			'monthNamesShort' => array_values($wp_locale->month_abbrev),
			'dayNames' => array_values($wp_locale->weekday),
			'dayNamesShort' => array_values($wp_locale->weekday_abbrev),
			'dayNamesMin' => array_values($wp_locale->weekday_initial),
			'firstDay' => get_option('start_of_week'),
			'current_time' => gmdate( 'Ymd', current_time( 'timestamp' ) ),
			'showWeek' => false,
			'showOn' => false,
			'numberOfMonths' => 1,
			'showButtonPanel' => false,
			'showOtherMonths' => true,
			'selectOtherMonths' => true,
			'gotoCurrent' => true,
			'changeMonth' => false,
			'changeYear' => false,
			'duration_changed' => false,
			'default_availability' => false,
			'costs_changed' => false,
			'ajax_url' => admin_url('admin-ajax.php'),
			'i18n_date_unavailable' => esc_js(__('Selected date is unavailable', 'woocommerce-appointments')),
			'i18n_date_invalid' => esc_js(__('Selected date is not valid', 'woocommerce-appointments')),
			'i18n_time_unavailable' => esc_js(__('Selected time is unavailable', 'woocommerce-appointments')),
			'i18n_show_first_available' => esc_js(__('Show first available', 'woocommerce-appointments')),
			'i18n_date_fully_scheduled' => esc_js(__('Selected date is fully scheduled and unavailable', 'woocommerce-appointments')),
			'i18n_date_partially_scheduled' => esc_js(__('Selected date is partially scheduled - but appointments still remain', 'woocommerce-appointments')),
			'i18n_date_available' => esc_js(__('Selected date is available', 'woocommerce-appointments')),
			'i18n_start_date' => esc_js(__('Choose a Start Date', 'woocommerce-appointments')),
			'i18n_end_date' => esc_js(__('Choose an End Date', 'woocommerce-appointments')),
			'i18n_dates' => esc_js(__('Dates', 'woocommerce-appointments')),
			'i18n_clear_date_selection' => esc_js(__('To clear selection, pick a new start date', 'woocommerce-appointments')),
			'i18n_confirmation' => esc_js(__('Are you sure?', 'woocommerce-appointments')),
			'is_admin' => is_admin(),
			'isRTL' => is_rtl(),
			'server_timezone' => wc_timezone_string(),
			'use_site_timezone' => ( isset( $_COOKIE['appointments_use_site_timezone'] ) && '1' === $_COOKIE['appointments_use_site_timezone'] )
				|| ( is_user_logged_in() && '1' === get_user_meta( get_current_user_id(), 'wc_appointments_use_site_timezone', true ) ),
			// JS day/request cache: disabled by default; enable via wc_appointments_slots_cache_enabled filter.
			'disable_slots_cache' => ( class_exists( 'WC_Appointment_Slots_Perf_Logger' ) && WC_Appointment_Slots_Perf_Logger::is_enabled() )
				? true
				: ! apply_filters( 'wc_appointments_slots_cache_enabled', false, null ),
			'date_format' => wc_appointments_date_format(),
			'time_format' => wc_appointments_time_format(),
			// 'server_time_format'            => wc_appointments_convert_to_moment_format( wc_appointments_time_format() ),
			// 'product_id'                    => $this->product->get_id(),
		];

		// Variables for JS scripts
		$appointment_analytics_params = [
			'i18n_appointable_products' => esc_js(__('Appointable products', 'woocommerce-appointments')),
			'i18n_staff' => esc_js(__('Staff', 'woocommerce-appointments')),
		];

		$locale = function_exists('determine_locale') ? determine_locale() : get_locale();
		$wc_appointments_analytics_locale_data = [
			'' => [
				'domain' => 'woocommerce-appointments',
				'lang' => $locale,
			],
			'Appointable products' => [__('Appointable products', 'woocommerce-appointments')],
			'Staff' => [__('Staff', 'woocommerce-appointments')],
		];

		$wc_appointments_date_picker_args = [
			'ajax_url' => WC_Ajax_Compat::get_endpoint('wc_appointments_find_scheduled_day_slots'),
		];

		$wc_appointments_timezone_picker_args = [
			'ajax_url' => WC_Ajax_Compat::get_endpoint( 'wc_appointments_set_timezone_cookie' ),
		];

		wp_localize_script(
			'wc-appointments-appointment-form',
			'wc_appointment_form_params',
			apply_filters(
				'wc_appointment_form_params',
				$appointment_form_params,
			),
		);
		wp_localize_script(
			'wc-appointments-date-picker',
			'wc_appointments_date_picker_args',
			$wc_appointments_date_picker_args,
		);
		wp_localize_script(
			'wc-appointments-timezone-picker',
			'wc_appointments_timezone_picker_args',
			$wc_appointments_timezone_picker_args,
		);
		wp_localize_script(
			'wc-appointments-my-account',
			'wc_appointments_my_account_params',
			[
				'i18n_confirmation' => esc_js( __( 'Are you sure?', 'woocommerce-appointments' ) ),
				'i18n_in_progress'  => __( 'In progress', 'woocommerce-appointments' ),
				'i18n_ended'        => __( 'Ended', 'woocommerce-appointments' ),
			]
		);
		wp_localize_script(
			'wc_appointments_analytics_script',
			'wc_appointments_analytics_params',
			apply_filters(
				'wc_appointment_form_params',
				$appointment_analytics_params,
			),
		);
		wp_localize_script(
			'wc_appointments_analytics_script',
			'wcAppointmentsAnalyticsLocaleData',
			$wc_appointments_analytics_locale_data,
		);
	}

	/**
	 * Register admin calendar assets.
	 *
	 * Registers scripts for the admin calendar.
	 */
	public function register_admin_calendar_assets(): void
	{
		wp_register_script(
			'fullcalendar-global',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/vendor/fullcalendar/index.global.min.js',
			[],
			WC_APPOINTMENTS_VERSION,
			true,
		);
		wp_register_script(
			'fullcalendar-locales',
			WC_APPOINTMENTS_PLUGIN_URL . '/assets/vendor/fullcalendar/locales-all.global.min.js',
			['fullcalendar-global'],
			WC_APPOINTMENTS_VERSION,
			true,
		);
	}

	/**
	 * Register/enqueue admin dependencies.
	 *
	 * @since 4.20.0
	 */
	public function appointment_admin_analytics(): void
	{
		// Enqueue Analytics JS.
		wp_enqueue_script('wc_appointments_analytics_script');
	}

	/**
	 * Attempt to convert a date formatting string from PHP to Moment
	 *
	 * @deprecated 4.7.0 Use wc_appointments_convert_to_jquery_datepicker_format() instead.
	 *
	 * @param string $format
	 * @return string
	 */
	protected function convert_to_moment_format($format)
	{
		wc_deprecated_function(__METHOD__, '4.7.0', 'wc_appointments_convert_to_jquery_datepicker_format');
		return wc_appointments_convert_to_jquery_datepicker_format($format);
	}

	/**
	 * Returns true if the request is a payment settings providers REST API request.
	 *
	 * @return bool
	 */
	public function is_payment_providers_api_request()
	{
		if (empty($_SERVER['REQUEST_URI'])) {
			return false;
		}
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		return false !== strpos($_SERVER['REQUEST_URI'], trailingslashit(rest_get_url_prefix()) . 'wc-admin/settings/payments/providers');
	}

	/**
	 * Output timezone preference field on My Account > Account Details.
	 *
	 * Allows customers to set their preferred timezone for appointment display.
	 *
	 * @since 5.2.0
	 */
	public function output_timezone_preference_field(): void
	{
		if (!class_exists('WC_Appointments_Timezone_Helper') || !WC_Appointments_Timezone_Helper::should_show_timezone('frontend', get_current_user_id())) {
			return;
		}

		// Get raw value - empty means "use Default".
		$current_tz_raw = WC_Appointments_Timezone_Helper::get_user_timezone_raw();
		// Effective timezone for comparison/display.
		$current_tz = WC_Appointments_Timezone_Helper::get_user_timezone();
		$site_tz = WC_Appointments_Timezone_Helper::get_site_timezone_string();
		?>
		<fieldset class="woocommerce-appointments-timezone-preference">
			<legend><?php esc_html_e('Appointment Timezone', 'woocommerce-appointments'); ?></legend>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label
					for="wc_appointments_timezone"><?php esc_html_e('Your timezone', 'woocommerce-appointments'); ?></label>
				<select name="wc_appointments_timezone" id="wc_appointments_timezone"
					class="woocommerce-Input woocommerce-Input--select input-select">
					<?php echo wc_appointments_wp_timezone_choice($current_tz_raw); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</select>
				<br>
				<span
					class="description"><?php esc_html_e('Appointment times will be displayed in this timezone.', 'woocommerce-appointments'); ?></span>
			</p>
			<p class="wc-appointments-browser-timezone-hint" style="display:none; margin-top: 10px;">
				<button type="button" class="button wc-appointments-use-browser-timezone">
					<?php esc_html_e('Use my current timezone', 'woocommerce-appointments'); ?>
				</button>
				<span class="detected-tz-name" style="margin-left: 10px;"></span>
			</p>
		</fieldset>
		<script>
			(function () {
				'use strict';
				var browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
				var siteTz = <?php echo wp_json_encode($site_tz); ?>;
				var currentTz = <?php echo wp_json_encode($current_tz); ?>;
				var hint = document.querySelector('.wc-appointments-browser-timezone-hint');
				var select = document.getElementById('wc_appointments_timezone');

				if (hint && browserTz && browserTz !== currentTz) {
					hint.style.display = 'block';
					var nameSpan = hint.querySelector('.detected-tz-name');
					if (nameSpan) {
						nameSpan.textContent = '(' + browserTz.replace(/_/g, ' ') + ')';
					}
				}

				var btn = document.querySelector('.wc-appointments-use-browser-timezone');
				if (btn && select) {
					btn.addEventListener('click', function (e) {
						e.preventDefault();
						var option = select.querySelector('option[value="' + browserTz + '"]');
						if (option) {
							select.value = browserTz;
							hint.style.display = 'none';
						} else {
							alert('<?php echo esc_js(__('Your browser timezone is not available in the list.', 'woocommerce-appointments')); ?>');
						}
					});
				}
			})();
		</script>
		<?php
	}

	/**
	 * Save timezone preference from My Account > Account Details.
	 *
	 * @since 5.2.0
	 *
	 * @param int $user_id User ID.
	 */
	public function save_timezone_preference_field(int $user_id): void
	{
		if (!class_exists('WC_Appointments_Timezone_Helper')) {
			return;
		}

		// Empty value = "Default" = use site timezone dynamically.
		if (isset($_POST['wc_appointments_timezone'])) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$timezone = sanitize_text_field(wp_unslash($_POST['wc_appointments_timezone'])); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			WC_Appointments_Timezone_Helper::save_user_timezone($user_id, $timezone);
		}
	}

	/**
	 * Output customer timezone field on WP Admin user profile (Users > Edit User).
	 *
	 * Allows admins to see and optionally edit the customer's appointment timezone.
	 *
	 * @since 5.2.0
	 *
	 * @param WP_User $user The user being edited.
	 */
	public function output_admin_user_timezone_field($user): void
	{
		if (!class_exists('WC_Appointments_Timezone_Helper') || !WC_Appointments_Timezone_Helper::should_show_timezone('admin', (int) $user->ID)) {
			return;
		}

		$current_tz_raw = WC_Appointments_Timezone_Helper::get_user_timezone_raw($user->ID);
		$current_tz = WC_Appointments_Timezone_Helper::get_user_timezone($user->ID);
		$site_tz = WC_Appointments_Timezone_Helper::get_site_timezone_string();
		$label = $current_tz ? WC_Appointments_Timezone_Helper::get_timezone_label($current_tz) : '';
		$is_editable = current_user_can('edit_user', (int) $user->ID);
		$is_staff = in_array('shop_staff', (array) $user->roles, true);
		?>
		<?php if ($is_staff) : ?>
			<h2 id="wca-section-timezone" data-section="timezone"><?php esc_html_e('Timezone', 'woocommerce-appointments'); ?></h2>
		<?php else : ?>
			<h3><?php esc_html_e('Appointment Timezone', 'woocommerce-appointments'); ?></h3>
		<?php endif; ?>
		<table class="form-table" role="presentation">
			<tr>
				<th><label for="wc_appointments_timezone"><?php esc_html_e( 'Your timezone', 'woocommerce-appointments' ); ?></label></th>
				<td>
					<?php if ( $is_editable ) : ?>
						<select name="wc_appointments_timezone" id="wc_appointments_timezone" class="regular-text">
							<?php echo wc_appointments_wp_timezone_choice( $current_tz_raw ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</select>
						<p class="description"><?php esc_html_e( 'Appointment times will be displayed in this timezone.', 'woocommerce-appointments' ); ?></p>
					<?php else : ?>
						<?php if ( $current_tz_raw && $label ) : ?>
							<strong><?php echo esc_html( $label ); ?></strong>
							<span class="description">(<?php echo esc_html( $current_tz ); ?>)</span>
						<?php else : ?>
							<span class="description"><?php
							$site_city  = WC_Appointments_Timezone_Helper::get_city_name( $site_tz );
							$site_short = WC_Appointments_Timezone_Helper::get_timezone_short_name( $site_tz );
							$site_label = ( $site_city && $site_short ) ? $site_city . ' - ' . $site_short : ( $site_short ?: $site_tz );
							printf(
								/* translators: %s: default site timezone label (city and abbr, e.g. "Sydney - AEDT"). */
								esc_html__( 'Default (%s)', 'woocommerce-appointments' ),
								esc_html( $site_label )
							);
							?></span>
						<?php endif; ?>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Save customer timezone from WP Admin user profile.
	 *
	 * @since 5.2.0
	 *
	 * @param int $user_id User ID.
	 */
	public function save_admin_user_timezone_field(int $user_id): void
	{
		if (!current_user_can('edit_user', $user_id) || !class_exists('WC_Appointments_Timezone_Helper')) {
			return;
		}

		if (isset($_POST['wc_appointments_timezone'])) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$timezone = sanitize_text_field(wp_unslash($_POST['wc_appointments_timezone'])); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			WC_Appointments_Timezone_Helper::save_user_timezone($user_id, $timezone);
		}
	}

	/**
	 * AJAX handler to save user timezone preference from booking form.
	 *
	 * @since 5.2.0
	 */
	public function ajax_save_user_timezone(): void
	{
		check_ajax_referer('wc_appointments_save_timezone', 'nonce');

		if (!is_user_logged_in()) {
			wp_send_json_error(['message' => __('You must be logged in.', 'woocommerce-appointments')]);
		}

		if (class_exists('WC_Appointments_Timezone_Helper') && !WC_Appointments_Timezone_Helper::should_show_timezone('frontend', get_current_user_id())) {
			wp_send_json_error(['message' => __('Timezone preference is not available.', 'woocommerce-appointments')]);
		}

		$timezone = isset($_POST['timezone']) ? sanitize_text_field(wp_unslash($_POST['timezone'])) : '';

		if (empty($timezone)) {
			wp_send_json_error(['message' => __('Missing timezone.', 'woocommerce-appointments')]);
		}

		if (!class_exists('WC_Appointments_Timezone_Helper') || !WC_Appointments_Timezone_Helper::is_valid_timezone($timezone)) {
			wp_send_json_error(['message' => __('Invalid timezone.', 'woocommerce-appointments')]);
		}

		$saved = WC_Appointments_Timezone_Helper::save_user_timezone(get_current_user_id(), $timezone);

		if ($saved) {
			wp_send_json_success(['message' => __('Timezone saved.', 'woocommerce-appointments'), 'timezone' => $timezone]);
		} else {
			wp_send_json_error( [ 'message' => __( 'An error occurred. Please try again.', 'woocommerce-appointments' ) ] );
		}
	}

	/**
	 * Tag new appointments with creation timezone metadata.
	 *
	 * Records the timezone at the time of appointment creation for accurate
	 * timezone conversion in the future, especially across DST changes.
	 *
	 * @since 5.2.0
	 *
	 * @param int $appointment_id Appointment ID.
	 */
	public function tag_appointment_creation_timezone(int $appointment_id): void
	{
		if (!class_exists('WC_Appointments_Timezone_Helper')) {
			return;
		}

		$appointment = get_wc_appointment($appointment_id);
		if (!$appointment || !$appointment->get_id()) {
			return;
		}

		// Get the site timezone at the time of creation.
		$site_tz = WC_Appointments_Timezone_Helper::get_site_timezone_string();

		// Store creation timezone meta.
		$appointment->update_meta_data(WC_Appointments_Timezone_Helper::CREATION_TZ_META_KEY, $site_tz);

		// Check if timezone was inferred vs explicitly set by customer.
		$local_tz = $appointment->get_local_timezone();
		$is_inferred = empty($local_tz) || $local_tz === $site_tz;
		$appointment->update_meta_data(WC_Appointments_Timezone_Helper::TIMEZONE_INFERRED_META_KEY, $is_inferred ? 'yes' : 'no');

		$appointment->save_meta_data();

		// Auto-save booking timezone to customer's account if they don't have one set yet.
		// This ensures new customers get their timezone preference populated from their first booking.
		if ( $local_tz && WC_Appointments_Timezone_Helper::is_valid_timezone( $local_tz ) ) {
			$customer_id = $appointment->get_customer_id();
			if ( $customer_id ) {
				$existing_tz = get_user_meta( $customer_id, WC_Appointments_Timezone_Helper::USER_META_KEY, true );
				if ( empty( $existing_tz ) ) {
					WC_Appointments_Timezone_Helper::save_user_timezone( $customer_id, $local_tz );
				}
			}
		}
	}
}

new WC_Appointments_Init();
