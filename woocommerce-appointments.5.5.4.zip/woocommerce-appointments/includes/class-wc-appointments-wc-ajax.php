<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Appointments WC ajax callbacks.
 */
class WC_Appointments_WC_Ajax {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wc_ajax_wc_appointments_find_scheduled_day_slots', [ $this, 'find_scheduled_day_slots' ] );
		add_action( 'wc_ajax_wc_appointments_set_timezone_cookie', [ $this, 'set_timezone_cookie' ] );
		add_action( 'wc_ajax_wc_appointments_add_appointment_to_cart', [ $this, 'add_appointment_to_cart' ] );
	}

	/**
	 * Find scheduled slots.
	 *
	 * AJAX handler to find scheduled slots for a given day range.
	 */
	public function find_scheduled_day_slots(): void {
		// Guests: rate limit. Optional nonce failure → stricter limit (does not block logged-in customers).
		if ( class_exists( 'WC_Appointments_Rate_Limiter' ) ) {
			WC_Appointments_Rate_Limiter::throttle_guest_read_with_optional_nonce(
				'find_slots',
				WC_Appointments_Rate_Limiter::GUEST_READ_MAX_REQUESTS,
				WC_Appointments_Rate_Limiter::GUEST_READ_WINDOW_SECONDS,
				'find-scheduled-day-slots',
				'find_slots_strict'
			);
		}

		$posted_raw = $this->wc_ajax_post_unslashed();
		$posted     = apply_filters( 'wc_appointments_before_find_scheduled_day_slots', $posted_raw );
		$posted     = $this->sanitize_find_scheduled_day_slots_post( is_array( $posted ) ? $posted : [] );

		// Get product ID-
		$product_id = absint( $posted['product_id'] ?? 0 );

		if ( empty( $product_id ) ) {
			wp_send_json_error( 'Missing product ID' );
		}

		try {
			$args                         = [];
			$product                      = get_wc_product_appointment( $product_id );
			$args['default_availability'] = $product->get_default_availability();
			$args['has_staff']            = $product->has_staff();
			$args['has_staff_ids']        = $product->get_staff_ids();
			$args['set_staff_id']         = empty( $posted['set_staff_id'] ) ? 0 : absint( $posted['set_staff_id'] );
			$args['appointment_duration'] = in_array( $product->get_duration_unit(), [ 'minute', 'hour' ] ) ? 1 : $product->get_duration();
			$args['staff_assignment']     = $product->has_staff() ? $product->get_staff_assignment() : 'customer';
			$args['duration_unit']        = $product->get_duration_unit();
			$args['min_date']             = isset( $posted['min_date'] ) ? strtotime( $posted['min_date'] ) : $product->get_min_date_a();
			$args['max_date']             = isset( $posted['max_date'] ) ? strtotime( $posted['max_date'] ) : $product->get_max_date_a();

			$min_date          = isset( $posted['min_date'] ) ? $args['min_date'] : strtotime( "+{$args['min_date']['value']} {$args['min_date']['unit']}", current_time( 'timestamp' ) );
			$max_date          = isset( $posted['max_date'] ) ? $args['max_date'] : strtotime( "+{$args['max_date']['value']} {$args['max_date']['unit']}", current_time( 'timestamp' ) );
			$staff_id_to_check = $args['set_staff_id'] && ! is_array( $args['set_staff_id'] ) ? [ $args['set_staff_id'] ] : [];

			// Normalize staff IDs.
			$staff_ids_a = [];
			if ( ! empty( $staff_id_to_check ) ) {
				$staff_ids_a = array_map( 'intval', $staff_id_to_check );
			} elseif ( $product->has_staff() ) {
				if ( $product->is_staff_assignment_type( 'all' ) ) {
					// Staff all together at the same time.
					$staff_ids_a = array_map( 'intval', (array) $product->get_staff_ids() );
				} else {
					// When no specific staff is selected, pass empty array to allow individual staff processing
					$staff_ids_a = [];
				}
			} else {
				$staff_ids_a = [ 0 ];
			}

			$location_id = absint( $posted['location_id'] ?? 0 );
			if ( $location_id > 0 && class_exists( 'WC_Appointments_Location' ) && $product->has_locations() && ! WC_Appointments_Location::authorize_location_id( $product, $location_id ) ) {
				$location_id = 0;
			}

			$resource_id = absint( $posted['resource_id'] ?? $posted['set_resource_id'] ?? 0 );
			if ( $resource_id > 0 && class_exists( 'WC_Appointments_Resource' ) && $product->has_resources() && ! WC_Appointments_Resource::authorize_resource_id( $product, $resource_id ) ) {
				$resource_id = 0;
			}

			$staff_ids = array_unique( $staff_ids_a );

			// Customer timezone for calendar bucketing: must match what the customer sees.
			// Priority: product timezone field → display_timezone (POST, from date-picker) → cookie.
			// Relying on the cookie alone breaks when the select shows e.g. ET but a stale cookie still says Sydney.
			$tz_site_string      = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : wc_timezone_string();
			$tz_cookie_disabled  = class_exists( 'WC_Appointments_Timezone_Helper' ) && ! WC_Appointments_Timezone_Helper::should_show_timezone( 'frontend', get_current_user_id() );
			$tz_user_string      = $tz_site_string;
			if ( ! $tz_cookie_disabled ) {
				$candidate = '';
				$posted_tz_field = isset( $posted['wc_appointments_field_timezone'] ) ? sanitize_text_field( $posted['wc_appointments_field_timezone'] ) : '';
				if ( $product->has_timezones() && '' !== $posted_tz_field && '0' !== $posted_tz_field ) {
					$candidate = $posted_tz_field;
				} elseif ( ! empty( $posted['display_timezone'] ) ) {
					$candidate = sanitize_text_field( $posted['display_timezone'] );
				}
				$candidate_ok = false;
				if ( '' !== $candidate ) {
					if ( class_exists( 'WC_Appointments_Timezone_Helper' ) && WC_Appointments_Timezone_Helper::is_valid_timezone( $candidate ) ) {
						$candidate_ok = true;
					} else {
						try {
							new DateTimeZone( wc_appointments_normalize_timezone( $candidate ) );
							$candidate_ok = true;
						} catch ( Exception $e ) {
							$candidate_ok = false;
						}
					}
				}
				if ( $candidate_ok ) {
					$tz_user_string = $candidate;
				} else {
					$cookie_tz = '';
					$cookie_raw = filter_input( INPUT_COOKIE, 'appointments_time_zone' );
					if ( is_string( $cookie_raw ) && '' !== $cookie_raw ) {
						$cookie_tz = sanitize_text_field( wp_unslash( $cookie_raw ) );
					}
					if ( '' !== $cookie_tz ) {
						$tz_user_string = $cookie_tz;
					}
				}
			}
			$tz_offset_minutes = 0;
			try {
				$tz_site  = new DateTimeZone( wc_appointments_normalize_timezone( $tz_site_string ) );
				$tz_user  = new DateTimeZone( wc_appointments_normalize_timezone( $tz_user_string ) );
				$dt_ref   = new DateTimeImmutable( '@' . (int) $min_date );
				$offset_s = (int) ( $tz_user->getOffset( $dt_ref ) - $tz_site->getOffset( $dt_ref ) );
				$tz_offset_minutes = (int) round( $offset_s / MINUTE_IN_SECONDS );

				// Day/month duration appointments are anchored to the business's calendar day.
				// Do not shift daylight/availability into the customer's offset.
				if ( in_array( $args['duration_unit'], [ 'day', 'month' ], true ) ) {
					$tz_offset_minutes = 0;
				}
			} catch ( Exception $e ) {
				$tz_offset_minutes = 0;
			}

			$built            = self::build_day_data( $product, (int) $min_date, (int) $max_date, $staff_ids, $location_id, $resource_id, $tz_user_string, $tz_offset_minutes );
			$args['day_data'] = $built['day_data'];
			$args['meta']     = [
				'business_timezone' => $tz_site_string,
				'display_timezone'  => $tz_user_string,
				'engine'            => $built['engine'],
			];

			// Filter all arguments.
			$args = apply_filters( 'wc_appointments_find_scheduled_day_slots', $args, $product );

			wp_send_json( $args );

		} catch ( Exception $e ) {
			// Send JSON so the client never receives an empty body (which causes datepicker JS to crash).
			wp_send_json(
				array(
					'error'    => true,
					'day_data' => array(),
					'meta'     => array(),
				)
			);
		}
	}

	/**
	 * Set timezone cookie.
	 *
	 * AJAX handler to save the user's timezone preference in a cookie.
	 */
	public function set_timezone_cookie(): void {
		$nonce = isset( $_POST['security'] ) ? sanitize_text_field( wp_unslash( $_POST['security'] ) ) : '';
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'set-timezone-cookie' ) ) {
			wp_send_json_error( __( 'Security check failed.', 'woocommerce-appointments' ), 403 );
		}

		$timezone = isset( $_POST['timezone'] ) ? sanitize_text_field( wp_unslash( $_POST['timezone'] ) ) : '';

		$site_tz             = wc_timezone_string();
		$is_default_timezone = ( '' === $timezone || $timezone === $site_tz );
		$cookie_opts         = [
			'path'     => COOKIEPATH,
			'domain'   => COOKIE_DOMAIN,
			'secure'   => is_ssl(),
			'samesite' => 'Lax',
		];

		// When timezone display/selection is disabled on frontend, force site-timezone mode:
		// clear cookie and clear persisted user preference.
		if ( class_exists( 'WC_Appointments_Timezone_Helper' ) && ! WC_Appointments_Timezone_Helper::should_show_timezone( 'frontend', get_current_user_id() ) ) {
			setcookie( 'appointments_time_zone', '', array_merge( $cookie_opts, [ 'expires' => time() - HOUR_IN_SECONDS ] ) );
			setcookie( 'appointments_use_site_timezone', '', array_merge( $cookie_opts, [ 'expires' => time() - HOUR_IN_SECONDS ] ) );
			if ( is_user_logged_in() ) {
				$user_id = get_current_user_id();
				delete_user_meta( $user_id, 'wc_appointments_use_site_timezone' );
				WC_Appointments_Timezone_Helper::save_user_timezone( $user_id, '' );
			}
			wp_send_json( '' );
			return;
		}

		// Validate timezone string.
		if ( ! $is_default_timezone && class_exists( 'WC_Appointments_Timezone_Helper' ) && ! WC_Appointments_Timezone_Helper::is_valid_timezone( $timezone ) ) {
			wp_send_json_error( __( 'Invalid timezone', 'woocommerce-appointments' ) );
		}

		try {
			if ( $is_default_timezone ) {
				$timezone = '';
				setcookie( 'appointments_time_zone', '', array_merge( $cookie_opts, [ 'expires' => time() - HOUR_IN_SECONDS ] ) );
				setcookie( 'appointments_use_site_timezone', '1', array_merge( $cookie_opts, [ 'expires' => time() + ( DAY_IN_SECONDS * 30 ) ] ) );
			} else {
				setcookie( 'appointments_time_zone', $timezone, array_merge( $cookie_opts, [ 'expires' => time() + ( DAY_IN_SECONDS * 30 ) ] ) );
				setcookie( 'appointments_use_site_timezone', '', array_merge( $cookie_opts, [ 'expires' => time() - HOUR_IN_SECONDS ] ) );
			}

			// If user is logged in, persist so the next full page load matches the picker.
			if ( is_user_logged_in() && class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
				$user_id = get_current_user_id();
				if ( $is_default_timezone ) {
					update_user_meta( $user_id, 'wc_appointments_use_site_timezone', '1' );
					WC_Appointments_Timezone_Helper::save_user_timezone( $user_id, '' );
				} else {
					delete_user_meta( $user_id, 'wc_appointments_use_site_timezone' );
					WC_Appointments_Timezone_Helper::save_user_timezone( $user_id, $timezone );
				}
			}

			wp_send_json( $timezone );
		} catch ( Exception $e ) {
			wp_die();
		}
	}

	/**
	 * Adds the appointment to the cart using WC().
	 *
	 * @since 4.5.0
	 */
	public function add_appointment_to_cart(): void {
		check_ajax_referer( 'add-appointment-to-cart', 'security' );

		$product_id_raw = filter_input( INPUT_GET, 'product_id' );
		$date_raw       = filter_input( INPUT_GET, 'date' );
		$product_id     = is_string( $product_id_raw ) ? absint( wp_unslash( $product_id_raw ) ) : 0;
		$date           = is_string( $date_raw ) ? sanitize_text_field( wp_unslash( $date_raw ) ) : '';

		if ( ! $product_id || '' === $date ) {
			wp_die();
		}

		$product = get_wc_product_appointment( $product_id );

		if ( ! is_wc_appointment_product( $product ) ) {
			wp_die();
		}

		$link = apply_filters( 'woocommerce_loop_product_link', $product->get_permalink(), $product );

		try {
			/*
			 * At this point we need to check if appointment can be
			 * made without any further user selection such as
			 * staff or product add-ons...etc. If so we cannot
			 * add appointment to cart via AJAX. Redirect them.
			 */
			if ( $product->has_staff() && $product->is_staff_assignment_type( 'customer' ) ) {
				wp_send_json(
				    [
						'scheduled' => false,
						'link'      => esc_url( $link ),
					],
				);
			}

			$cart_post = [];
			if ( 'hour' === $product->get_duration_unit() || 'minute' === $product->get_duration_unit() ) {
				$cart_post['wc_appointments_field_start_date_time'] = $date;
			} else {
				$date_time = new DateTime( $date );
				$cart_post['wc_appointments_field_start_date_month'] = $date_time->format( 'm' );
				$cart_post['wc_appointments_field_start_date_day']   = $date_time->format( 'd' );
				$cart_post['wc_appointments_field_start_date_year']  = $date_time->format( 'Y' );
			}

			$inject_cart_post = static function () use ( $cart_post ) {
				return $cart_post;
			};
			add_filter( 'wc_appointments_cart_post_unslashed', $inject_cart_post );

			$added = WC()->cart->add_to_cart(
			    $product->get_id(),
			);

			remove_filter( 'wc_appointments_cart_post_unslashed', $inject_cart_post );

			wp_send_json(
			    [
					'scheduled' => false !== $added,
					'link'      => esc_url( $link ),
				],
			);
		} catch ( Exception $e ) {
			wp_send_json(
			    [
					'scheduled' => false,
					'link'      => esc_url( $link ),
				],
			);
		}
	}

	/**
	 * @param int[] $staff_ids Staff scope.
	 * @return array{day_data:array<string,mixed>,engine:int}
	 */
	private static function build_day_data(
		WC_Product_Appointment $product,
		int $min_date,
		int $max_date,
		array $staff_ids,
		int $location_id,
		int $resource_id,
		string $tz_user,
		int $tz_offset
	): array {
		$collection = WC_Appointment_Slots_Provider::get_collection(
			$product,
			$min_date,
			$max_date,
			array_values( array_unique( array_map( 'intval', $staff_ids ) ) ),
			false,
			false,
			$tz_user,
			$location_id,
			true,
			$resource_id
		);
		$unit    = $product->get_duration_unit();
		$padding = [];
		if ( ! in_array( $unit, [ 'minute', 'hour' ], true ) ) {
			$prelim  = $collection->to_day_data( $product, $tz_offset, 'Y-n-j', null, [], false );
			$anchors = [];
			foreach ( $prelim['day_data'] as $key => $entry ) {
				if ( 'fully_booked' === ( $entry['status'] ?? '' ) ) {
					$anchors[] = $key;
				}
			}
			$padding = WC_Appointment_Slots_Provider::get_padding_days_for_fully_booked_dates( $product, $anchors );
		}
		$display_tz = ( in_array( $unit, [ 'minute', 'hour' ], true ) && 0 !== $tz_offset ) ? $tz_user : null;
		$day        = $collection->to_day_data(
			$product,
			$tz_offset,
			'Y-n-j',
			$display_tz,
			$padding,
			$product->has_restricted_days() ? $product->get_restricted_days() : false
		);
		return [
			'day_data' => $day['day_data'],
			'engine'   => (int) ( $collection->get_meta()['engine'] ?? 2 ),
		];
	}

	/**
	 * Embed first-month day_data as inline JS for the date picker.
	 *
	 * Called from storefront date/datetime picker templates so the first visible
	 * month can hydrate without a separate wc-ajax round-trip (full WP boot).
	 * Honors valid `?date=` when that month is on/after the min-date anchor month.
	 *
	 * @param WC_Product_Appointment $product Product.
	 */
	public static function localize_initial_day_slots( WC_Product_Appointment $product ): void {
		static $done = [];
		$pid         = $product->get_id();
		if ( isset( $done[ $pid ] ) ) {
			return;
		}
		$done[ $pid ] = true;

		$scope_loc = 0;
		$match_loc = 0;
		if ( $product->has_locations() && class_exists( 'WC_Appointments_Location' ) ) {
			$opts = [];
			foreach ( WC_Appointments_Location::get_allowed_location_ids( $product ) as $lid ) {
				if ( (int) $lid > 0 && get_the_title( (int) $lid ) ) {
					$opts[] = (int) $lid;
				}
			}
			// $_GET (not filter_input): WP/tests can set query vars after request start.
			$req       = isset( $_GET['location'] ) ? absint( wp_unslash( $_GET['location'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$scope_loc = ( $req > 0 && in_array( $req, $opts, true ) ) ? $req : (int) ( $opts[0] ?? 0 );
			if ( $scope_loc <= 0 ) {
				return;
			}
			if ( WC_Appointments_Location::MODE_CUSTOMER === $product->get_location_mode() && count( $opts ) >= 2 ) {
				$match_loc = $scope_loc;
			}
		}

		$scope_res = 0;
		if ( $product->has_resources() && class_exists( 'WC_Appointments_Resource' )
			&& 'customer' === $product->get_resource_assignment() ) {
			$req   = isset( $_GET['resource'] ) ? absint( wp_unslash( $_GET['resource'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$cands = [];
			if ( $req > 0 && WC_Appointments_Resource::authorize_resource_id( $product, $req ) ) {
				$cands[] = $req;
			}
			foreach ( WC_Appointments_Resource::normalize_requirements( $product ) as $row ) {
				$cands[] = (int) ( $row['resource_id'] ?? 0 );
			}
			foreach ( array_unique( $cands ) as $rid ) {
				$rloc = (int) WC_Appointments_Resource_Data_Store::get_location_id( $rid );
				if ( $rid > 0 && get_the_title( $rid ) && ( $scope_loc <= 0 || 0 === $rloc || $rloc === $scope_loc ) ) {
					$scope_res = $rid;
					break;
				}
			}
		}

		$staff_id = 0;
		if ( $product->has_staff() && 'customer' === $product->get_staff_assignment() ) {
			$ids      = array_map( 'absint', (array) $product->get_staff_ids() );
			$req      = isset( $_GET['staff'] ) ? absint( wp_unslash( $_GET['staff'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$staff_id = ( $req > 0 && in_array( $req, $ids, true ) )
				? $req
				: ( ( ! $product->get_staff_nopref() && $ids ) ? (int) $ids[0] : 0 );
		}

		$now    = current_time( 'timestamp' );
		$min_a  = $product->get_min_date_a();
		$anchor = ! empty( $min_a['value'] ) ? strtotime( "+{$min_a['value']} {$min_a['unit']}", $now ) : $now;
		// current_time() is Fake UTC (site wall digits as UTC-labelled ints). Use gmdate(), not
		// wp_date(), or positive-offset stores (e.g. Australia/Sydney evening) shift civil today
		// forward a day and bootstrap day_data omits the real storefront today.
		$y = (int) gmdate( 'Y', $anchor );
		$m = (int) gmdate( 'n', $anchor );
		// Deep link: boot the ?date= month when it is on/after the anchor month.
		$qs_raw = isset( $_GET['date'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['date'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( preg_match( '/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $qs_raw, $dm )
			&& checkdate( (int) $dm[2], (int) $dm[3], (int) $dm[1] )
			&& strtotime( sprintf( '%04d-%02d-01', (int) $dm[1], (int) $dm[2] ) ) >= strtotime( sprintf( '%04d-%02d-01', $y, $m ) )
		) {
			$y      = (int) $dm[1];
			$m      = (int) $dm[2];
			$anchor = strtotime( sprintf( '%04d-%02d-%02d 00:00:00', $y, $m, (int) $dm[3] ) );
		}
		$today = strtotime( gmdate( 'Y-m-d', $now ) . ' 00:00:00' );
		$min   = max( $today, strtotime( sprintf( '%04d-%02d-01 00:00:00', $y, $m ) ) - 7 * DAY_IN_SECONDS );
		$max   = strtotime( sprintf( '%04d-%02d-%02d 23:59:59', $y, $m, (int) gmdate( 't', $anchor ) ) ) + 7 * DAY_IN_SECONDS;
		if ( $max < $min ) {
			$max = $min + 7 * DAY_IN_SECONDS;
		}
		if ( ( $max - $min ) < 14 * DAY_IN_SECONDS ) {
			$max = $min + 21 * DAY_IN_SECONDS;
		}

		$tz    = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : wc_timezone_string();
		$unit  = $product->get_duration_unit();
		$built = self::build_day_data(
			$product,
			(int) $min,
			(int) $max,
			$staff_id ? [ $staff_id ] : [],
			$scope_loc,
			$scope_res,
			$tz,
			0
		);

		wp_add_inline_script(
			'wc-appointments-date-picker',
			'window.wc_appointments_initial_day_slots=' . wp_json_encode(
				[
					'product_id'  => $pid,
					'staff_id'    => $staff_id,
					'location_id' => $match_loc,
					'resource_id' => $scope_res,
					'data'        => [
						'appointment_duration' => in_array( $unit, [ 'minute', 'hour' ], true ) ? 1 : $product->get_duration(),
						'duration_unit'        => $unit,
						'day_data'             => $built['day_data'],
						'meta'                 => [ 'engine' => $built['engine'] ],
					],
				]
			) . ';',
			'before'
		);
	}

	/**
	 * Sanitize known POST fields for find_scheduled_day_slots (after wp_unslash + filter).
	 *
	 * Preserves unknown keys for `wc_appointments_before_find_scheduled_day_slots` consumers.
	 *
	 * @param array<string, mixed> $posted Unslashed POST payload.
	 * @return array<string, mixed>
	 */
	private function sanitize_find_scheduled_day_slots_post( array $posted ): array {
		$posted['product_id']   = absint( $posted['product_id'] ?? 0 );
		$posted['set_staff_id'] = absint( $posted['set_staff_id'] ?? 0 );
		$posted['location_id']  = absint( $posted['location_id'] ?? 0 );

		if ( isset( $posted['min_date'] ) ) {
			$posted['min_date'] = sanitize_text_field( (string) $posted['min_date'] );
		}
		if ( isset( $posted['max_date'] ) ) {
			$posted['max_date'] = sanitize_text_field( (string) $posted['max_date'] );
		}
		if ( isset( $posted['wc_appointments_field_timezone'] ) ) {
			$posted['wc_appointments_field_timezone'] = sanitize_text_field( (string) $posted['wc_appointments_field_timezone'] );
		}
		if ( isset( $posted['display_timezone'] ) ) {
			$posted['display_timezone'] = sanitize_text_field( (string) $posted['display_timezone'] );
		}

		return $posted;
	}

	/**
	 * Unslashed POST for guest read AJAX (rate-limited by caller).
	 *
	 * @return array<string, mixed>
	 */
	private function wc_ajax_post_unslashed(): array {
		return wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field in sanitize_find_scheduled_day_slots_post().
	}
}

new WC_Appointments_WC_Ajax();
