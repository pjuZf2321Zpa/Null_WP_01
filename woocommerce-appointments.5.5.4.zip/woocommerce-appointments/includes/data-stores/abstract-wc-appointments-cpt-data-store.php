<?php
/**
 * Shared CPT data store for location/resource entities.
 *
 * WordPress owns post create/trash; we read post+meta and write meta on save.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * @since 5.5.0
 */
abstract class WC_Appointments_CPT_Data_Store extends WC_Data_Store_WP {

	abstract protected function post_type(): string;

	/** @return array<string, string> Meta key => prop. */
	abstract protected function meta_key_to_props(): array;

	abstract protected function invalid_message(): string;

	/**
	 * Not used: CPT rows are created via wp-admin / wp_insert_post.
	 *
	 * @param WC_Appointments_CPT_Data $object Object.
	 */
	public function create( &$object ): void {}

	/**
	 * @param WC_Appointments_CPT_Data $object Object.
	 * @throws Exception Invalid object.
	 */
	public function read( &$object ): void {
		$object->set_defaults();
		$id   = $object->get_id();
		$post = $id ? get_post( $id ) : false;
		if ( ! $id || ! $post || $this->post_type() !== $post->post_type ) {
			throw new Exception( $this->invalid_message() );
		}

		$fields = [
			'name'   => $post->post_title,
			'status' => $post->post_status,
		];
		foreach ( $this->meta_key_to_props() as $meta_key => $prop ) {
			$value            = get_post_meta( $id, $meta_key, true );
			$fields[ $prop ] = ( 'location_id' === $prop ) ? absint( $value ) : (string) $value;
		}
		$object->set_fields( $fields );
		$object->set_object_read( true );
	}

	/**
	 * Persist meta only (title/status stay on the WP post form).
	 *
	 * @param WC_Appointments_CPT_Data $object Object.
	 */
	public function update( &$object ): void {
		foreach ( $this->meta_key_to_props() as $meta_key => $prop ) {
			update_post_meta( $object->get_id(), $meta_key, $object->get_field( $prop, 'edit' ) );
		}
		$object->apply_changes();
	}

	/**
	 * @param WC_Appointments_CPT_Data $object Object.
	 * @param array<string, mixed>     $args   Args.
	 */
	public function delete( &$object, $args = [] ): void {
		$id   = $object->get_id();
		$args = wp_parse_args( $args, [ 'force_delete' => false ] );
		if ( $args['force_delete'] ) {
			wp_delete_post( $id, true );
			$object->set_id( 0 );
		} else {
			wp_trash_post( $id );
			$object->set_fields( [ 'status' => 'trash' ] );
		}
	}

	/**
	 * List CPT rows (hub / admin). Prefer this over ad-hoc get_posts().
	 *
	 * @param string          $post_type    CPT.
	 * @param string|string[] $post_status  Status or list.
	 * @param bool            $ids_only     Return IDs only.
	 * @param int             $limit        posts_per_page (-1 = all).
	 * @return int[]|WP_Post[]
	 */
	protected static function query_posts( string $post_type, $post_status = 'publish', bool $ids_only = false, int $limit = -1 ): array {
		$args = [
			'post_type'      => $post_type,
			'post_status'    => $post_status,
			'posts_per_page' => $limit,
			'orderby'        => 'title',
			'order'          => 'ASC',
		];
		if ( $ids_only ) {
			$args['fields'] = 'ids';
		}
		$posts = get_posts( $args );
		if ( $ids_only ) {
			return array_map( 'intval', (array) $posts );
		}
		return is_array( $posts ) ? $posts : [];
	}

	/** @return int[] */
	protected static function query_published_ids( string $post_type ): array {
		return self::query_posts( $post_type, 'publish', true, -1 );
	}

	/**
	 * Whether any CPT row exists (Features tab / auto-enable probes).
	 *
	 * Direct SQL so probes can run before register_post_type.
	 * Positive-only static cache so a later create still flips tab / auto-enable.
	 */
	protected static function posts_exist( string $post_type, bool $published_only ): bool {
		static $cache = [];

		$key = $post_type . ( $published_only ? ':p' : ':a' );
		if ( ! empty( $cache[ $key ] ) ) {
			return true;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- existence check; positives cached statically.
		$id = $published_only
			? $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' LIMIT 1",
					$post_type
				)
			)
			: $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status IN ( 'publish', 'draft', 'pending', 'private', 'future' ) LIMIT 1",
					$post_type
				)
			);

		if ( $id ) {
			$cache[ $key ] = true;
			return true;
		}

		return false;
	}
}
