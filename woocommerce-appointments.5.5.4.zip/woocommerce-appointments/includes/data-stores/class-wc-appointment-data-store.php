<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC Appointment Data Store: Stored in CPT.
 *
 * @todo When 2.6 support is dropped, implement WC_Object_Data_Store_Interface
 */
class WC_Appointment_Data_Store extends WC_Data_Store_WP {

	public const CACHE_GROUP = 'wc-appointments';

	/**
	 * Meta keys and how they transfer to CRUD props.
	 *
	 * @var array<string, string>
	 */
	private array $appointment_meta_key_to_props = [
		'_appointment_all_day'                  => 'all_day',
		'_appointment_cost'                     => 'cost',
		'_appointment_customer_id'              => 'customer_id',
		'_appointment_order_item_id'            => 'order_item_id',
		'_appointment_parent_id'                => 'parent_id',
		'_appointment_product_id'               => 'product_id',
		'_appointment_staff_id'                 => 'staff_ids',
		'_appointment_location_id'              => 'location_id',
		'_appointment_location'                 => 'location',
		'_appointment_resource_allocations'     => 'resource_allocations',
		'_wca_meeting_provider'                 => 'meeting_provider',
		'_wca_meeting_id'                       => 'meeting_id',
		'_wca_meeting_join_url'                 => 'meeting_join_url',
		'_wca_meeting_host_url'                 => 'meeting_host_url',
		'_wca_meeting_password'                 => 'meeting_password',
		'_wca_meeting_status'                   => 'meeting_status',
		'_appointment_start'                    => 'start',
		'_appointment_end'                      => 'end',
		'_wc_appointments_gcal_event_id'        => 'google_calendar_event_id',
		'_wc_appointments_gcal_staff_event_ids' => 'google_calendar_staff_event_ids',
		'_appointment_customer_status'          => 'customer_status',
		'_appointment_qty'                      => 'qty',
		'_appointment_timezone'                 => 'timezone',
		'_local_timezone'                       => 'local_timezone',
		'_appointment_author'                   => 'creator_id',
	];

	/*
	|--------------------------------------------------------------------------
	| CRUD Methods
	|--------------------------------------------------------------------------
	*/

	/**
	 * Create a new appointment in the database.
	 *
	 * Inserts a new appointment record and saves all associated metadata.
	 *
	 * @param WC_Appointment $appointment Appointment object. $appointment The appointment object to create.
	 */
	public function create( &$appointment ): void {
		if ( ! $appointment->get_date_created( 'edit' ) ) {
			$appointment->set_date_created( current_time( 'timestamp' ) );
		}

		// Set creator ID if not set and we're in an administrative context (Admin, REST, AJAX).
		if ( ! $appointment->get_creator_id( 'edit' ) ) {
			$current_user_id = get_current_user_id();
			if ( $current_user_id ) {
				$is_rest = defined( 'REST_REQUEST' ) && REST_REQUEST;
				$is_ajax = defined( 'DOING_AJAX' ) && DOING_AJAX;

				if ( is_admin() || $is_rest || $is_ajax ) {
					$appointment->set_creator_id( $current_user_id );
				}
			}
		}

		// @codingStandardsIgnoreStart
		$post_data = apply_filters(
			'woocommerce_new_appointment_data',
			[
				'post_date'     => gmdate(
					'Y-m-d H:i:s',
					$appointment->get_date_created( 'edit' ),
				),
				'post_date_gmt' => get_gmt_from_date(
					gmdate(
						'Y-m-d H:i:s',
						$appointment->get_date_created( 'edit' ),
					),
				),
				'post_type'     => 'wc_appointment',
				'post_status'   => $appointment->get_status( 'edit' ),
				'post_author'   => $appointment->get_customer_id( 'edit' ),
				'post_title'    => sprintf(
					/* translators: %s: Appointment date */
					__( 'Appointment &ndash; %s', 'woocommerce-appointments' ),
					gmdate(
						/* translators: Appointment date format parsed by gmdate() function */
						_x( 'M d, Y @ H:i a', 'Appointment date parsed by date()', 'woocommerce-appointments' ),
						$appointment->get_date_created( 'edit' ),
					),
				),
				'post_parent'   => $appointment->get_order_id( 'edit' ),
				'ping_status'   => 'closed',
			],
			$appointment,
		);
		$id = wp_insert_post( $post_data, true );
		// @codingStandardsIgnoreEnd

		if ( $id && ! is_wp_error( $id ) ) {
			$appointment->set_id( $id );
			$this->update_post_meta( $appointment );
			$appointment->save_meta_data();
			$appointment->apply_changes();
			WC_Cache_Helper::get_transient_version( 'appointments', true );

			do_action( 'woocommerce_new_appointment', $appointment->get_id() );
		}

		// Stop deleting the transient if the product is added to the cart.
		// Action Scheduler will be used to update new availability.
		// Add some meta to track that this product requires updating.
		$product_id = absint( filter_input( INPUT_POST, 'add-to-cart', FILTER_SANITIZE_NUMBER_INT ) );
		$min_date   = 0;
		$max_date   = 0;
		$min_date_raw = filter_input( INPUT_POST, 'min_date' );
		if ( is_string( $min_date_raw ) && '' !== $min_date_raw ) {
			$min_date = strtotime( sanitize_text_field( wp_unslash( $min_date_raw ) ) );
		}
		$max_date_raw = filter_input( INPUT_POST, 'max_date' );
		if ( is_string( $max_date_raw ) && '' !== $max_date_raw ) {
			$max_date = strtotime( sanitize_text_field( wp_unslash( $max_date_raw ) ) );
		}

		// If $min_date or $max_date are somehow was not updated by the JS, stop and clear transient.
		if ( $product_id && $min_date && $max_date ) {
			$timezone_offset_raw = filter_input( INPUT_GET, 'timezone_offset' );
			$timezone_offset     = null !== $timezone_offset_raw ? (string) $timezone_offset_raw : '0';

			/**
			 * Filter the maximum number of appointments before scheduling the transient delete.
			 *
			 * @since 4.18.1
			 *
			 * @param int $max_appointment_count Maximum appointments before deferring transient delete.
			 * @param int $product_id            Appointable product ID.
			 * @param int $min_date              Start date timestamp.
			 * @param int $max_date              End date timestamp.
			 */
			$max_appointment_count = apply_filters( 'woocommerce_appointments_max_appointments_to_delete_transient', 1000, (int) $product_id, $min_date, $max_date );

			// If existing appointments' count is less than 1000, delete the transient now,
			// otherwise schedule it via an action scheduler.
			$existing_appointments = self::get_appointments_in_date_range( (int) $min_date, (int) $max_date, (int) $product_id );
			if ( count( $existing_appointments ) < $max_appointment_count ) {
				WC_Appointments_Cache::delete_appointment_slots_transient();
				WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );
			} else {
				// Warm up the slot cache for the product's date range.
				$warmup_product = wc_get_product( $product_id );
				if ( is_wc_appointment_product( $warmup_product ) ) {
					WC_Appointment_Slots_Provider::get_day_data( $warmup_product, $min_date, $max_date, (int) $timezone_offset, [], 'Y-n-j' );
				}
			}
		} else {
			WC_Appointments_Cache::delete_appointment_slots_transient();
			WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );
		}
	}

	/**
	 * Method to read an order from the database.
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 */
	public function read( &$appointment ): void {
		$appointment->set_defaults();
		$appointment_id = $appointment->get_id();
		$post_object    = $appointment_id ? get_post( $appointment_id ) : false;

		if ( ! $appointment_id || ! $post_object || 'wc_appointment' !== $post_object->post_type ) {
			throw new Exception(
			    __( 'Invalid appointment.', 'woocommerce-appointments' ),
			);
		}

		$set_props = [];

		// Read post data.
		$set_props['date_created']  = $post_object->post_date;
		$set_props['date_modified'] = $post_object->post_modified;
		$set_props['status']        = $post_object->post_status;
		$set_props['order_id']      = $post_object->post_parent;

		// Read meta data.
		foreach ( $this->appointment_meta_key_to_props as $key => $prop ) {
			$value = get_post_meta( $appointment->get_id(), $key, true );

			switch ( $prop ) {
				case 'end':
				case 'start':
					#error_log( var_export( $value ? ( (bool) strtotime( $value ) ? strtotime( $value ) : $value ) : '', true ) );
					$set_props[ $prop ] = $value ? strtotime( $value ) : 0;
					break;
				case 'all_day':
					$set_props[ $prop ] = wc_appointments_string_to_bool( $value );
					break;
				case 'staff_ids':
					// Staff can be saved multiple times to same meta key.
					$value              = get_post_meta( $appointment->get_id(), $key, false );
					$set_props[ $prop ] = $value;
					break;
				case 'location_id':
					$set_props[ $prop ] = absint( $value );
					break;
				case 'location':
					$set_props[ $prop ] = is_array( $value ) ? $value : [];
					break;
				case 'resource_allocations':
					$set_props[ $prop ] = is_array( $value ) ? $value : [];
					break;
				default:
					$set_props[ $prop ] = $value;
					break;
			}
		}

		#error_log( var_export( $set_props, true ) );

		$appointment->set_props( $set_props );
		$appointment->set_object_read( true );
	}

	/**
	 * Method to update an order in the database.
	 *
	 * @param WC_Appointment $appointment Appointment object. $appointment
	 */
	public function update( &$appointment ): void {
		wp_update_post(
		    [
				'ID'            => $appointment->get_id(),
				'post_date'     => date(
				    'Y-m-d H:i:s',
				    $appointment->get_date_created( 'edit' ),
				),
				'post_date_gmt' => get_gmt_from_date(
				    date(
				        'Y-m-d H:i:s',
				        $appointment->get_date_created( 'edit' ),
				    ),
				),
				'post_status'   => $appointment->get_status( 'edit' ),
				'post_author'   => $appointment->get_customer_id( 'edit' ),
				'post_parent'   => $appointment->get_order_id( 'edit' ),
			],
		);
		$this->update_post_meta( $appointment );
		$appointment->save_meta_data();
		$appointment->apply_changes();
		WC_Cache_Helper::get_transient_version( 'appointments', true );
		WC_Appointments_Cache::flush_all_appointment_connected_transients( $appointment );
		WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );
		// Emit an explicit update event so WooCommerce webhooks can deliver
		// `appointment.updated` without relying solely on status transitions.
		do_action( 'woocommerce_update_appointment', $appointment->get_id() );
	}

	/**
	 * Delete an appointment from the database.
	 *
	 * Removes the appointment record and associated metadata.
	 *
	 * @param WC_Appointment       $appointment Appointment object. $appointment The appointment object to delete.
	 * @param array<string, mixed> $args        Array of args to pass to the delete method.
	 */
	public function delete( &$appointment, $args = [] ): void {
		$id   = $appointment->get_id();
		$args = wp_parse_args(
		    $args,
		    [
				'force_delete' => false,
			],
		);

		WC_Appointments_Cache::flush_all_appointment_connected_transients( $appointment );
		WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );

		if ( $args['force_delete'] ) {
			wp_delete_post( $id );
			$appointment->set_id( 0 );
			do_action( 'woocommerce_delete_appointment', $id );
		} else {
			wp_trash_post( $id );
			$appointment->set_status( 'trash' );
			do_action( 'woocommerce_trash_appointment', $id );
		}
	}

	/**
	 * Helper method that updates all the post meta for an appointment based on it's settings in the WC_Appointment class.
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 * @return void
	 */
	protected function update_post_meta( &$appointment ) {
		foreach ( $this->appointment_meta_key_to_props as $key => $prop ) {
			if ( is_callable( [ $appointment, "get_$prop" ] ) ) {
				$value = $appointment->{ "get_$prop" }( 'edit' );

				switch ( $prop ) {
					case 'all_day':
						update_post_meta( $appointment->get_id(), $key, $value ? 1 : 0 );
						break;
					case 'local_timezone':
						if ( $appointment->get_all_day( 'edit' ) || '' === $value ) {
							delete_post_meta( $appointment->get_id(), $key );
						} else {
							update_post_meta( $appointment->get_id(), $key, $value );
						}
						break;
					case 'end':
					case 'start':
						update_post_meta( $appointment->get_id(), $key, $value ? date( 'YmdHis', $value ) : '' );
						break;
					case 'staff_ids':
						delete_post_meta( $appointment->get_id(), $key );
						if ( is_array( $value ) ) {
							foreach ( $value as $staff_id ) {
								add_post_meta( $appointment->get_id(), '_appointment_staff_id', $staff_id );
							}
						} elseif ( is_numeric( $value ) ) {
							add_post_meta( $appointment->get_id(), '_appointment_staff_id', $value );
						}
						break;
					case 'location_id':
						if ( empty( $value ) ) {
							delete_post_meta( $appointment->get_id(), $key );
						} else {
							update_post_meta( $appointment->get_id(), $key, absint( $value ) );
						}
						break;
					case 'location':
						if ( empty( $value ) || ! is_array( $value ) ) {
							delete_post_meta( $appointment->get_id(), $key );
						} else {
							update_post_meta( $appointment->get_id(), $key, $value );
						}
						break;
					case 'resource_allocations':
						if ( empty( $value ) || ! is_array( $value ) ) {
							delete_post_meta( $appointment->get_id(), $key );
						} else {
							update_post_meta( $appointment->get_id(), $key, $value );
						}
						// Sync repeatable _appointment_resource_id for meta_query IN lookups.
						delete_post_meta( $appointment->get_id(), '_appointment_resource_id' );
						if ( is_array( $value ) ) {
							foreach ( $value as $alloc ) {
								$rid = (int) ( $alloc['resource_id'] ?? 0 );
								if ( $rid > 0 ) {
									add_post_meta( $appointment->get_id(), '_appointment_resource_id', $rid );
								}
							}
						}
						break;
					case 'google_calendar_staff_event_ids':
						// Merge incoming keys onto the stored map (incoming wins) so sync_to_gcal can
						// write one staff at a time. Empty event id removes that staff key; empty map deletes.
						if ( is_array( $value ) ) {
							if ( [] === $value ) {
								delete_post_meta( $appointment->get_id(), $key );
								break;
							}
							$current_value = get_post_meta( $appointment->get_id(), $key, true );
							$new_value     = is_array( $current_value ) ? $current_value : [];
							foreach ( $value as $staff_id => $event_id ) {
								if ( '' === $event_id || null === $event_id ) {
									unset( $new_value[ $staff_id ], $new_value[ (string) $staff_id ] );
									if ( is_numeric( $staff_id ) ) {
										unset( $new_value[ (int) $staff_id ] );
									}
								} else {
									$new_value[ $staff_id ] = $event_id;
								}
							}
							if ( [] === $new_value ) {
								delete_post_meta( $appointment->get_id(), $key );
							} else {
								update_post_meta( $appointment->get_id(), $key, $new_value );
							}
						} elseif ( ! $value ) {
							delete_post_meta( $appointment->get_id(), $key );
						}
						break;
					default:
						update_post_meta( $appointment->get_id(), $key, $value );
						break;
				}
			}
		}
	}

	/**
	 * Clear product link when the product is deleted (admin cleanup).
	 *
	 * @since 5.5.0
	 */
	public static function clear_product_id( int $appointment_id ): void {
		if ( $appointment_id > 0 ) {
			delete_post_meta( $appointment_id, '_appointment_product_id' );
		}
	}

	/**
	 * Clear staff assignment meta when a staff user is deleted.
	 *
	 * @since 5.5.0
	 */
	public static function clear_staff_ids( int $appointment_id ): void {
		if ( $appointment_id > 0 ) {
			delete_post_meta( $appointment_id, '_appointment_staff_id' );
		}
	}

	/**
	 * Clear customer link when a customer user is deleted.
	 *
	 * @since 5.5.0
	 */
	public static function clear_customer_id( int $appointment_id ): void {
		if ( $appointment_id > 0 ) {
			delete_post_meta( $appointment_id, '_appointment_customer_id' );
		}
	}

	/**
	 * Record that a reminder email was sent for this start timestamp.
	 *
	 * @since 5.5.0
	 */
	public static function mark_reminder_sent( int $appointment_id, int $start_ts ): void {
		if ( $appointment_id <= 0 ) {
			return;
		}
		update_post_meta( $appointment_id, '_wca_reminder_sent_for_start_ts', $start_ts );
		update_post_meta( $appointment_id, '_wca_reminder_sent_at', time() );
	}

	/**
	 * Clear reminder duplicate-send guard (e.g. when start changes).
	 *
	 * @since 5.5.0
	 */
	public static function clear_reminder_meta( int $appointment_id ): void {
		if ( $appointment_id <= 0 ) {
			return;
		}
		delete_post_meta( $appointment_id, '_wca_reminder_sent_for_start_ts' );
		delete_post_meta( $appointment_id, '_wca_reminder_sent_at' );
	}

	/**
	 * Follow-Up Emails last status snapshot on the appointment.
	 *
	 * @since 5.5.0
	 */
	public static function update_last_status( int $appointment_id, string $status ): void {
		if ( $appointment_id > 0 ) {
			update_post_meta( $appointment_id, '_last_status', $status );
		}
	}

	/**
	 * Check if all appointments for a given order ID are confirmed.
	 *
	 * @param int $order_id
	 * @return bool
	 */
	 public static function all_appointments_in_order_confirmed( $order_id ) {
		$order_id = absint( $order_id );

		// Use existing helper to gather appointment IDs linked to this order.
		$appointment_ids = (array) self::get_appointment_ids_from_order_id( $order_id );
		if ( [] === $appointment_ids ) {
			return false; // No appointments for this order.
		}

		// Check each appointment object's status instead of querying a non-existent custom table.
		foreach ( $appointment_ids as $aid ) {
			$aid = (int) $aid;
			if ( 0 >= $aid ) {
				return false;
			}
			try {
				$appt = get_wc_appointment( $aid );
			} catch ( \Exception $e ) {
				return false;
			}
			if ( ! $appt || 'confirmed' !== $appt->get_status() ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * For a given order ID, get all appointments that belong to it.
	 * DO NOT CACHE
	 *
	 * @param  int|int[] $order_id
	 *
	 * @return int[] Array of appointment IDs.
	 */
	public static function get_appointment_ids_from_order_id( $order_id ) {
		global $wpdb;

		// Search multiple in multiple order IDs.
		if ( is_array( $order_id ) ) {
			global $wpdb;

			$order_ids = wp_parse_id_list( $order_id );
			if ( [] === $order_ids ) {
				return [];
			}

			return wp_parse_id_list(
				$wpdb->get_col(
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'wc_appointment' AND post_parent IN (" . implode( ', ', array_fill( 0, count( $order_ids ), '%d' ) ) . ')',
						...$order_ids
					)
				)
			);

		// Search in single order ID.
		} else {
			global $wpdb;

			$order_id = absint( $order_id );

			$data = wp_parse_id_list(
			    $wpdb->get_col(
			        $wpdb->prepare(
			            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'wc_appointment' AND post_parent = %d;",
			            $order_id,
			        ),
			    ),
			);

			if ( empty( $data ) ) {
				$order = wc_get_order( $order_id );
				if ( is_a( $order, 'WC_Order' ) ) {
					$by_items = [];
					foreach ( $order->get_items() as $item_id => $item ) {
						if ( $item->is_type( 'line_item' ) ) {
							$raw_ids = self::query_appointment_ids_by_order_item_meta( $item_id );
							$ids     = self::resolve_order_scoped_line_lookup( $raw_ids, $order_id, false );
							if ( ! empty( $ids ) ) {
								$by_items = array_merge( $by_items, (array) $ids );
							}
						}
					}
					$data = wp_parse_id_list( $by_items );
				}
			}

			return $data;
		}
	}

	/**
	 * Appointments linked to an order line item ID.
	 *
	 * Pass `$order_id` to scope results to the canonical order (`post_parent`). Required for
	 * admin, checkout, invoices, and anywhere WooCommerce line IDs may be reused.
	 *
	 * Canonical source: appointment `_appointment_order_item_id` meta (queried each time).
	 * Order-line `_appointment_id` denormalized cache is opt-in only â€” off by default.
	 *
	 * @since 5.4.1 Added optional `$order_id` for order-scoped lookup and post_parent fallback.
	 *
	 * @param int  $order_item_id Order line id.
	 * @param bool $no_cache      When true (default), skip order-line `_appointment_id` read/write.
	 * @param int  $order_id      Order ID â€” required for scoped lookup (see doing_it_wrong when omitted).
	 * @return int[]
	 */
	public static function get_appointment_ids_from_order_item_id( $order_item_id, $no_cache = true, $order_id = 0 ) {
		$order_item_id = absint( $order_item_id );
		$order_id      = absint( $order_id );
		if ( $order_item_id <= 0 ) {
			return array();
		}

		$appointment_ids = self::query_appointment_ids_by_order_item_meta( $order_item_id );
		$use_cache       = ! $no_cache && $order_id <= 0 && apply_filters( 'woocommerce_appointments_use_order_item_appointment_cache', false, $order_item_id );

		if ( $order_id <= 0 && ! $use_cache ) {
			wc_doing_it_wrong(
				__FUNCTION__,
				__( 'Pass a valid $order_id so appointment lookup is scoped to the order being viewed. Unscoped lookup can return appointments from other orders when WooCommerce line item IDs are reused.', 'woocommerce-appointments' ),
				WC_APPOINTMENTS_VERSION
			);
		}

		if ( $use_cache ) {
			$cached = wp_parse_id_list( (array) wc_get_order_item_meta( $order_item_id, '_appointment_id', true ) );
			if ( empty( $cached ) ) {
				$cached = wp_parse_id_list( (array) wc_get_order_item_meta( $order_item_id, 'appointment_id', true ) );
			}

			$appointment_ids = array_values(
				array_unique(
					array_merge( $appointment_ids, $cached )
				)
			);
			$appointment_ids = array_values(
				array_filter(
					$appointment_ids,
					static function ( $appointment_id ) use ( $order_item_id ) {
						return (int) self::get_appointment_order_item_id( $appointment_id ) === $order_item_id;
					}
				)
			);

			if ( ! empty( $appointment_ids ) ) {
				wc_update_order_item_meta( $order_item_id, '_appointment_id', $appointment_ids );
			} else {
				wc_delete_order_item_meta( $order_item_id, '_appointment_id' );
			}
		}

		return self::resolve_order_scoped_line_lookup( $appointment_ids, $order_id, true, $order_item_id );
	}

	/**
	 * @deprecated 5.4.1 Use get_appointment_ids_from_order_item_id( $order_item_id, true, $order_id ).
	 *
	 * @param int $order_id      Order ID.
	 * @param int $order_item_id Order line item ID.
	 * @return int[]
	 */
	public static function get_appointment_ids_from_order_and_item_id( $order_id = 0, $order_item_id = 0 ) {
		wc_deprecated_function( __FUNCTION__, '5.4.1', 'WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $order_item_id, true, $order_id )' );

		return self::get_appointment_ids_from_order_item_id( $order_item_id, true, $order_id );
	}

	/**
	 * Clear `_appointment_order_item_id` on appointments when a WooCommerce order line is deleted.
	 *
	 * Only appointments whose canonical order (`post_parent`) matches the line's order are
	 * updated so a reused line ID cannot leave stale meta on another order's appointment.
	 *
	 * @since 5.4.1
	 *
	 * @param int $order_item_id Deleted order line id.
	 * @return void
	 */
	public static function clear_order_item_id_for_deleted_line( $order_item_id ) {
		$order_item_id = absint( $order_item_id );
		if ( $order_item_id <= 0 ) {
			return;
		}

		$order_id = wc_get_order_id_by_order_item_id( $order_item_id );
		if ( ! $order_id ) {
			return;
		}

		foreach ( self::query_appointment_ids_by_order_item_meta( $order_item_id ) as $appointment_id ) {
			if ( (int) self::get_appointment_order_id( $appointment_id ) !== (int) $order_id ) {
				continue;
			}

			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment instanceof WC_Appointment ) {
				continue;
			}

			$appointment->set_order_item_id( 0 );
			$appointment->save();
		}
	}

	/**
	 * Check if a given order contains only Appointments items.
	 * If the order contains non-appointment items, it will return false.
	 * Otherwise, it will return an array of Appointments.
	 *
	 * @param  WC_Order $order
	 * @return bool|int[] False if any non-appointment item; otherwise appointment IDs.
	 */
	public static function get_order_contains_only_appointments( $order ) {
		$all_appointment_ids = [];

		foreach ( array_keys( $order->get_items() ) as $order_item_id ) {
			$appointment_ids = self::get_appointment_ids_from_order_item_id( $order_item_id, true, $order->get_id() );

			if ( empty( $appointment_ids ) ) {
				return false;
			}

			$all_appointment_ids = array_merge( $all_appointment_ids, $appointment_ids );
		}

		return $all_appointment_ids;
	}

	/**
	 * Get appointment ids for an object  by ID. e.g. product.
	 * DO NOT CACHE
	 *
	 * @param array<string, mixed> $filters Query filters.
	 * @return array<int, int>
	 */
	public static function get_appointment_ids_by( $filters = [] ) {
		global $wpdb;

		// Normalize defaults.
		$filters = wp_parse_args(
		    $filters,
		    [
				'object_id'        => 0,
				'product_id'       => 0,
				'staff_id'         => 0,
				'object_type'      => 'product',
				'strict'           => false,
				'status'           => false,
				'limit'            => -1,
				'offset'           => 0,
				'order_by'         => 'date_created',
				'order'            => 'DESC',
				'date_before'      => false,
				'date_after'       => false,
				'gcal_event_id'    => false,
				'date_between'     => [
					'start' => false,
					'end'   => false,
				],
				'status_not_in'    => [],
				'location_id'      => 0,
				// Back-compat (these were referenced in code).
				'post_date_before' => false,
				'post_date_after'  => false,
			],
		);

		// Product and staff fallbacks.
		$filters['product_id'] = $filters['product_id'] ?: $filters['object_id'];
		$filters['staff_id']   = $filters['staff_id'] ?: $filters['object_id'];

		// Normalize arrays of IDs.
		$filters['object_id']  = array_filter( wp_parse_id_list( is_array( $filters['object_id'] ) ? $filters['object_id'] : [ $filters['object_id'] ] ) );
		$filters['product_id'] = array_filter( wp_parse_id_list( is_array( $filters['product_id'] ) ? $filters['product_id'] : [ $filters['product_id'] ] ) );
		$filters['staff_id']   = array_filter( wp_parse_id_list( is_array( $filters['staff_id'] ) ? $filters['staff_id'] : [ $filters['staff_id'] ] ) );

		// Cache key (prefix invalidates on appointment create/update via invalidate_cache_group).
		$cache_key = WC_Cache_Helper::get_cache_prefix( self::CACHE_GROUP ) . 'appt_ids_by:' . md5( wp_json_encode( $filters ) );
		$cached    = wp_cache_get( $cache_key, self::CACHE_GROUP );
		if ( false !== $cached ) {
			return $cached;
		}

		// Whitelist order_by and order.
		$order_by = 'p.post_date';
		if ( isset( $filters['order_by'] ) ) {
			switch ( $filters['order_by'] ) {
				case 'date_created':
					$order_by = 'p.post_date';
					break;
				case 'start_date':
					// Will add meta join for _appointment_start later.
					$order_by = '_appointment_start.meta_value';
					break;
			}
		}
		$order_dir = ( isset( $filters['order'] ) && 'ASC' === strtoupper( $filters['order'] ) ) ? 'ASC' : 'DESC';

		$joins        = [];
		$where        = [];
		$params       = [];
		$meta_to_join = [];

		// Base constraints.
		$where[] = "p.post_type = 'wc_appointment'";

		// Statuses.
		if ( ! empty( $filters['status'] ) ) {
			$statuses = array_filter( array_map( 'strval', (array) $filters['status'] ) );
			if ( [] !== $statuses ) {
				$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
				$where[]      = "p.post_status IN ($placeholders)";
				$params       = array_merge( $params, $statuses );
			}
		} elseif ( ! empty( $filters['status_not_in'] ) ) {
			$excluded = array_filter( array_map( 'strval', (array) $filters['status_not_in'] ) );
			if ( [] !== $excluded ) {
				$placeholders = implode( ',', array_fill( 0, count( $excluded ), '%s' ) );
				$where[]      = "p.post_status NOT IN ($placeholders)";
				$params       = array_merge( $params, $excluded );
			}
		}

		// Google Calendar event ID.
		if ( ! empty( $filters['gcal_event_id'] ) ) {
			$meta_to_join['_wc_appointments_gcal_event_id'] = true;
			$gids         = array_map( 'strval', (array) $filters['gcal_event_id'] );
			$placeholders = implode( ',', array_fill( 0, count( $gids ), '%s' ) );
			$where[]      = "_wc_appointments_gcal_event_id.meta_value IN ($placeholders)";
			$params       = array_merge( $params, $gids );
		}

		// Post date filters (posts table uses DATETIME).
		if ( ! empty( $filters['post_date_before'] ) ) {
			$where[]  = 'p.post_date < %s';
			$params[] = gmdate( 'Y-m-d H:i:s', (int) $filters['post_date_before'] );
		}
		if ( ! empty( $filters['post_date_after'] ) ) {
			$where[]  = 'p.post_date > %s';
			$params[] = gmdate( 'Y-m-d H:i:s', (int) $filters['post_date_after'] );
		}

		// Object type filters: product/staff/customer.
		switch ( $filters['object_type'] ) {
			case 'product':
			case 'product_and_staff':
				if ( ! empty( $filters['product_id'] ) && ( isset( $filters['staff_id'] ) && [] !== $filters['staff_id'] ) ) {
					$meta_to_join['_appointment_product_id'] = true;
					$meta_to_join['_appointment_staff_id']   = true;

					$pids      = $filters['product_id'];
					$sids      = $filters['staff_id'];
					$pid_place = implode( ',', array_fill( 0, count( $pids ), '%d' ) );
					$sid_place = implode( ',', array_fill( 0, count( $sids ), '%d' ) );

					if ( ! empty( $filters['strict'] ) ) {
						$where[] = "( (_appointment_product_id.meta_value IN ($pid_place)) AND (_appointment_staff_id.meta_value IN ($sid_place)) )";
					} else {
						$where[] = "( (_appointment_product_id.meta_value IN ($pid_place)) OR (_appointment_staff_id.meta_value IN ($sid_place)) )";
					}
					$params = array_merge( $params, $pids, $sids );
				} elseif ( ! empty( $filters['product_id'] ) ) {
					$meta_to_join['_appointment_product_id'] = true;
					$pids                                    = $filters['product_id'];
					$pid_place                               = implode( ',', array_fill( 0, count( $pids ), '%d' ) );
					$where[]                                 = "_appointment_product_id.meta_value IN ($pid_place)";
					$params                                  = array_merge( $params, $pids );
				} elseif ( isset( $filters['staff_id'] ) && [] !== $filters['staff_id'] ) {
					$meta_to_join['_appointment_staff_id'] = true;
					$sids                                  = $filters['staff_id'];
					$sid_place                             = implode( ',', array_fill( 0, count( $sids ), '%d' ) );
					$where[]                               = "_appointment_staff_id.meta_value IN ($sid_place)";
					$params                                = array_merge( $params, $sids );
				}
				break;

			case 'staff':
				if ( isset( $filters['staff_id'] ) && [] !== $filters['staff_id'] ) {
					$meta_to_join['_appointment_staff_id'] = true;
					$sids                                  = $filters['staff_id'];
					$sid_place                             = implode( ',', array_fill( 0, count( $sids ), '%d' ) );
					$where[]                               = "_appointment_staff_id.meta_value IN ($sid_place)";
					$params                                = array_merge( $params, $sids );
				}
				break;

			case 'customer':
				if ( ! empty( $filters['object_id'] ) ) {
					$meta_to_join['_appointment_customer_id'] = true;
					$cids                                     = $filters['object_id'];
					$cid_place                                = implode( ',', array_fill( 0, count( $cids ), '%d' ) );
					$where[]                                  = "_appointment_customer_id.meta_value IN ($cid_place)";
					$params                                   = array_merge( $params, $cids );
				}
				break;
		}

		if ( ! empty( $filters['location_id'] ) ) {
			$meta_to_join['_appointment_location_id'] = true;
			$where[]                                  = '_appointment_location_id.meta_value = %d';
			$params[]                                 = absint( $filters['location_id'] );
		}

		// Date between in meta (string dates in YmdHis).
		if ( ! empty( $filters['date_between']['start'] ) && ! empty( $filters['date_between']['end'] ) ) {
			$meta_to_join['_appointment_start']   = true;
			$meta_to_join['_appointment_end']     = true;
			$meta_to_join['_appointment_all_day'] = true;

			$end_dt    = gmdate( 'YmdHis', (int) $filters['date_between']['end'] );
			$start_dt  = gmdate( 'YmdHis', (int) $filters['date_between']['start'] );
			$end_day   = gmdate( 'Ymd000000', (int) $filters['date_between']['end'] );
			$start_day = gmdate( 'Ymd000000', (int) $filters['date_between']['start'] );

			$where[] = "( (
				_appointment_start.meta_value <= %s AND
				_appointment_end.meta_value > %s AND
				_appointment_all_day.meta_value = '0'
			) OR (
				_appointment_start.meta_value <= %s AND
				_appointment_end.meta_value >= %s AND
				_appointment_all_day.meta_value = '1'
			) )";
			$params  = array_merge( $params, [ $end_dt, $start_dt, $end_day, $start_day ] );
		}

		// Date after/before in meta (string dates in YmdHis).
		if ( ! empty( $filters['date_after'] ) ) {
			$meta_to_join['_appointment_start'] = true;
			$where[]                            = '_appointment_start.meta_value > %s';
			$params[]                           = gmdate( 'YmdHis', (int) $filters['date_after'] );
		}
		if ( ! empty( $filters['date_before'] ) ) {
			$meta_to_join['_appointment_end'] = true;
			$where[]                          = '_appointment_end.meta_value < %s';
			$params[]                         = gmdate( 'YmdHis', (int) $filters['date_before'] );
		}

		// If ordering by start_date, ensure join.
		if ( '_appointment_start.meta_value' === $order_by ) {
			$meta_to_join['_appointment_start'] = true;
		}

		// Early path: no meta joins needed -> query posts only.
		if ( [] === $meta_to_join ) {
			$sql = "SELECT p.ID FROM {$wpdb->posts} p WHERE " . implode( ' AND ', $where ) . " ORDER BY {$order_by} {$order_dir}";
			if ( 0 < $filters['limit'] ) {
				$sql .= $wpdb->prepare( ' LIMIT %d, %d', absint( $filters['offset'] ), absint( $filters['limit'] ) );
			}
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Dynamic WHERE/JOIN fragments; values via placeholders.
			$prepared_sql = $wpdb->prepare( $sql, ...$params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$ids = array_values(
				array_unique(
					array_filter(
						wp_parse_id_list(
							// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
							$wpdb->get_col( $prepared_sql )
						)
					)
				)
			);
			wp_cache_set( $cache_key, $ids, self::CACHE_GROUP );
			return $ids;
		}

		// Simpler and reliable approach: JOIN necessary meta keys directly.
		$select = "SELECT p.ID FROM {$wpdb->posts} p";
		$joins  = [];
		// Build JOINs for every meta key we referenced.
		foreach ( array_keys( $meta_to_join ) as $key ) {
			$joins[] = "INNER JOIN {$wpdb->postmeta} {$key} ON ( {$key}.post_id = p.ID AND {$key}.meta_key = '{$key}' )";
		}
		$sql = $select;
		$sql .= ' ' . implode( ' ', $joins );
		$sql .= ' WHERE ' . implode( ' AND ', $where );
		$sql .= " ORDER BY {$order_by} {$order_dir}";
		if ( 0 < $filters['limit'] ) {
			$sql .= $wpdb->prepare( ' LIMIT %d, %d', absint( $filters['offset'] ), absint( $filters['limit'] ) );
		}
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Dynamic WHERE/JOIN fragments; values via placeholders.
		$prepared_sql = $wpdb->prepare( $sql, ...$params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$ids = array_values(
			array_unique(
				array_filter(
					wp_parse_id_list(
						// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
						$wpdb->get_col( $prepared_sql )
					)
				)
			)
		);

		wp_cache_set( $cache_key, $ids, self::CACHE_GROUP );
		return $ids;
	}

	/**
	 * For a given appointment ID, get it's linked order ID if set.
	 *
	 * @param  int $appointment_id
	 *
	 * @return int
	 */
	public static function get_appointment_order_id( $appointment_id ) {
		return absint( wp_get_post_parent_id( $appointment_id ) );
	}

	/**
	 * Future/ongoing appointments that have no indexed occupancy row in the cache.
	 *
	 * Used by appointment backfill so large sites only process gaps, not every post.
	 *
	 * @param int $now            UTC timestamp; appointments ending after this are candidates.
	 * @param int $limit          Max IDs to return.
	 * @param int $appointment_id Optional appointment ID to check (0 = any gap).
	 * @return int[]
	 */
	public static function get_future_appointment_ids_missing_from_cache( int $now, int $limit = 200, int $appointment_id = 0 ): array {
		global $wpdb;

		if ( $limit <= 0 || ! class_exists( 'WC_Appointments_Cache_Availability' ) ) {
			return array();
		}

		// Meta is Fake UTC YmdHis (same as other appointment range queries). Comparing CAST(... AS UNSIGNED)
		// to a unix $now treats past YmdHis values (e.g. 20201028160000) as forever-future gaps.
		$now_ymd = gmdate( 'YmdHis', $now );

		$sql = "SELECT p.ID
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id AND pm_start.meta_key = '_appointment_start'
			INNER JOIN {$wpdb->postmeta} pm_end ON p.ID = pm_end.post_id AND pm_end.meta_key = '_appointment_end'
			WHERE p.post_type = 'wc_appointment'
			AND p.post_status NOT IN ('trash', 'auto-draft', 'in-cart', 'was-in-cart', 'cancelled')
			AND pm_start.meta_value > '0'
			AND pm_end.meta_value > pm_start.meta_value
			AND pm_end.meta_value > %s
			AND NOT EXISTS (
				SELECT 1 FROM {$wpdb->prefix}wc_appointments_availability_cache c
				WHERE c.source = 'appointment'
				AND c.source_id = p.ID
				AND c.end_ts > %d
			)";

		if ( $appointment_id > 0 ) {
			$sql    .= ' AND p.ID = %d';
			$params  = [ $now_ymd, $now, $appointment_id, $limit ];
		} else {
			$params = [ $now_ymd, $now, $limit ];
		}

		$sql .= ' ORDER BY p.ID ASC LIMIT %d';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from wpdb; values via placeholders.
		$prepared_sql = $wpdb->prepare( $sql, ...$params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$ids = $wpdb->get_col( $prepared_sql );

		if ( empty( $ids ) ) {
			return array();
		}

		return array_values( array_map( 'absint', $ids ) );
	}

	/**
	 * Whether a single future appointment is absent from the occupancy cache.
	 *
	 * @param int $appointment_id Appointment ID.
	 * @param int $now            UTC timestamp.
	 */
	public static function is_future_appointment_missing_from_cache( int $appointment_id, int $now ): bool {
		return ! empty( self::get_future_appointment_ids_missing_from_cache( $now, 1, $appointment_id ) );
	}

	/**
	 * Keep only appointments whose canonical order (post_parent) matches.
	 *
	 * @param int[] $appointment_ids Appointment IDs.
	 * @param int   $order_id        Order ID.
	 * @return int[]
	 */
	private static function filter_appointment_ids_for_order( $appointment_ids, $order_id ) {
		$order_id = absint( $order_id );
		if ( $order_id <= 0 || empty( $appointment_ids ) ) {
			return array();
		}

		return array_values(
			array_filter(
				wp_parse_id_list( $appointment_ids ),
				static function ( $appointment_id ) use ( $order_id ) {
					return (int) self::get_appointment_order_id( $appointment_id ) === $order_id;
				}
			)
		);
	}

	/**
	 * Query appointment IDs by `_appointment_order_item_id` meta only.
	 *
	 * @param int $order_item_id Order line id.
	 * @return int[]
	 */
	private static function query_appointment_ids_by_order_item_meta( $order_item_id ) {
		global $wpdb;

		$order_item_id = absint( $order_item_id );
		if ( $order_item_id <= 0 ) {
			return array();
		}

		return array_values(
			array_unique(
				wp_parse_id_list(
					(array) $wpdb->get_col(
						$wpdb->prepare(
							"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_appointment_order_item_id' AND meta_value = %d",
							$order_item_id
						)
					)
				)
			)
		);
	}

	/**
	 * Apply order scoping (and optional post_parent fallback) to line-item lookup results.
	 *
	 * @param int[] $raw_line_ids          Appointment IDs from line-item meta.
	 * @param int   $order_id              Order ID to scope to.
	 * @param bool  $allow_order_fallback  When true and no line meta claims exist, fall back to post_parent lookup.
	 * @param int   $order_item_id         Line item id (gates fallback to appointable products only).
	 * @return int[]
	 */
	private static function resolve_order_scoped_line_lookup( $raw_line_ids, $order_id, $allow_order_fallback = true, $order_item_id = 0 ) {
		$order_id = absint( $order_id );
		if ( $order_id <= 0 ) {
			return wp_parse_id_list( $raw_line_ids );
		}

		$raw_line_ids    = wp_parse_id_list( $raw_line_ids );
		$appointment_ids = self::filter_appointment_ids_for_order( $raw_line_ids, $order_id );

		if ( ! empty( $appointment_ids ) ) {
			return $appointment_ids;
		}

		if ( $allow_order_fallback && empty( $raw_line_ids ) ) {
			$item    = WC_Order_Factory::get_order_item( $order_item_id );
			$product = ( $item instanceof WC_Order_Item_Product )
				? ( $item->get_product() ?: wc_get_product( $item->get_product_id() ) )
				: null;

			if ( $product && is_wc_appointment_product( $product ) ) {
				return (array) self::get_appointment_ids_from_order_id( $order_id );
			}
		}

		return array();
	}

	/**
	 * For a given appointment ID, get it's linked order item ID if set.
	 *
	 * @param  int $appointment_id
	 * @return int
	 */
	public static function get_appointment_order_item_id( $appointment_id ) {
		return absint( get_post_meta( $appointment_id, '_appointment_order_item_id', true ) );
	}

	/**
	 * For a given appointment ID, get it's linked order customer ID if set.
	 *
	 * @param  int $appointment_id
	 * @return int
	 */
	public static function get_appointment_customer_id( $appointment_id ) {
		return absint( get_post_meta( $appointment_id, '_appointment_customer_id', true ) );
	}

	/**
	 * Gets appointments for product ids and staff ids
	 *
	 * @param  int[]    $product_ids
	 * @param  int[]    $staff_ids
	 * @param  string[] $status
	 * @param  integer  $date_from
	 * @param  integer  $date_to
	 *
	 * @return int[] Appointment IDs.
	 */
	public static function get_appointments_for_objects_query( $product_ids, $staff_ids, $status, $date_from = 0, $date_to = 0 ) {
		$status    = empty( $status ) ? get_wc_appointment_statuses( 'fully_scheduled' ) : $status;
		$date_from = empty( $date_from ) ? strtotime( 'midnight', current_time( 'timestamp' ) ) : $date_from;
		$date_to   = empty( $date_to ) ? strtotime( '+12 month', current_time( 'timestamp' ) ) : $date_to;

		// Filter the arguments
		$args = apply_filters(
		    'woocommerce_appointments_for_objects_query_args',
		    [
				'status'       => $status,
				'product_id'   => $product_ids,
				'staff_id'     => $staff_ids,
				'object_type'  => 'product_and_staff',
				'date_between' => [
					'start' => $date_from,
					'end'   => $date_to,
				],
			],
		);

		$appointment_ids = self::get_appointment_ids_by( $args );

		return apply_filters( 'woocommerce_appointments_for_objects_query', $appointment_ids );
	}

	/**
	 * Gets appointments for product ids and staff ids
	 *
	 * @param  int[]    $product_ids
	 * @param  int[]    $staff_ids
	 * @param  string[] $status
	 * @param  integer  $date_from
	 * @param  integer  $date_to
	 *
	 * @return WC_Appointment[]
	 */
	public static function get_appointments_for_objects( $product_ids = [], $staff_ids = [], $status = [], $date_from = 0, $date_to = 0 ) {
		// TODO: We need to round date_from/date_to to something specific.
		// Otherwise, one might abuse the DB transient cache by calling various combinations from the front-end with min-date/max-date.
		$transient_name  = 'schedule_fo_' . md5( http_build_query( [ $product_ids, $staff_ids, $date_from, $date_to, WC_Cache_Helper::get_transient_version( 'appointments' ) ] ) );
		$status          = ( empty( $status ) ) ? get_wc_appointment_statuses( 'fully_scheduled' ) : $status;
		$date_from       = empty( $date_from ) ? strtotime( 'midnight', current_time( 'timestamp' ) ) : $date_from;
		$date_to         = empty( $date_to ) ? strtotime( '+12 month', current_time( 'timestamp' ) ) : $date_to;
		$appointment_ids = WC_Appointments_Cache::get( $transient_name );

		if ( false === $appointment_ids ) {
			$appointment_ids = self::get_appointments_for_objects_query( $product_ids, $staff_ids, $status, $date_from, $date_to );
			WC_Appointments_Cache::set( $transient_name, $appointment_ids, DAY_IN_SECONDS * 30 );
		}

		#echo '<pre>' . var_export( $appointment_ids, true ) . '</pre>';

		// Get objects.
		if ( ! empty( $appointment_ids ) ) {
			return array_map( 'get_wc_appointment', wp_parse_id_list( $appointment_ids ) );
		}

		return [];
	}

	/**
	 * Finds existing appointments for a product and its tied staff.
	 *
	 * @param  int|WC_Product_Appointment $appointable_product  Product ID or object
	 * @param  int                        $min_date
	 * @param  int                        $max_date
	 * @param  int[]                      $staff_ids
	 *
	 * @return WC_Appointment[]
	 */
	public static function get_all_existing_appointments( $appointable_product, $min_date = 0, $max_date = 0, array $staff_ids = [] ) {
		if ( is_int( $appointable_product ) ) {
			$appointable_product = wc_get_product( $appointable_product );
		}
		if ( ! is_wc_appointment_product( $appointable_product ) ) {
			return [];
		}
		$find_appointments_for_product = [ $appointable_product->get_id() ];
		$find_appointments_for_staff   = [];

		// Account for staff?
		if ( $appointable_product->has_staff() ) {
			$staff_ids   = 0 === absint( $staff_ids ) ? $appointable_product->get_staff_ids() : $staff_ids; #no preference
			$staff_ids   = wc_appointments_normalize_staff_ids( $staff_ids );
			$staff_array = [] === $staff_ids ? $appointable_product->get_staff_ids() : $staff_ids;
			// Loop through staff.
			foreach ( $staff_array as $staff_member_id ) {
				$find_appointments_for_staff[] = $staff_member_id;
			}
		}

		// Account for padding? Widen the search window by the larger buffer on both sides so
		// bookings whose before/after buffer reaches into the range are still fetched.
		$padding_window_in_minutes = max(
			$appointable_product->get_padding_before_in_minutes(),
			$appointable_product->get_padding_after_in_minutes()
		);
		if ( $padding_window_in_minutes && in_array( $appointable_product->get_duration_unit(), [ 'hour', 'minute', 'day' ], true ) ) {
			if ( ! empty( $min_date ) ) {
				$min_date = strtotime( "-{$padding_window_in_minutes} minutes", $min_date );
			}
			if ( ! empty( $max_date ) ) {
				$max_date = strtotime( "+{$padding_window_in_minutes} minutes", $max_date );
			}
		}

		if ( empty( $min_date ) ) {
			// Determine a min and max date
			$min_date = $appointable_product->get_min_date_a();
			$min_date = empty( $min_date ) ? [
				'unit'  => 'minute',
				'value' => 1,
			] : $min_date;
			$min_date = strtotime( "midnight +{$min_date['value']} {$min_date['unit']}", current_time( 'timestamp' ) );
		}

		if ( empty( $max_date ) ) {
			$max_date = $appointable_product->get_max_date_a();
			$max_date = empty( $max_date ) ? [
				'unit'  => 'month',
				'value' => 12,
			] : $max_date;
			$max_date = strtotime( "+{$max_date['value']} {$max_date['unit']}", current_time( 'timestamp' ) );
		}

		$appointments = self::get_appointments_for_objects(
		    $find_appointments_for_product,
		    $find_appointments_for_staff,
		    get_wc_appointment_statuses( 'fully_scheduled' ),
		    $min_date,
		    $max_date,
		);

		// Resource cross-product: load appointments sharing any required resource.
		// These are tagged with _wca_resource_only so the overlap index builder
		// routes them ONLY to the resource bucket (not the staff/cross-product bucket).
		if ( class_exists( 'WC_Appointments_Resource' ) && $appointable_product->has_resources() ) {
			$requirements  = WC_Appointments_Resource::normalize_requirements( $appointable_product );
			$resource_ids  = array_column( $requirements, 'resource_id' );
			if ( [] !== $resource_ids ) {
				$resource_appts = self::get_appointments_for_resource_ids( $resource_ids, $min_date, $max_date );
				if ( [] !== $resource_appts ) {
					$existing_ids = [];
					foreach ( $appointments as $a ) {
						$existing_ids[ $a->get_id() ] = true;
					}
					foreach ( $resource_appts as $ra ) {
						if ( ! isset( $existing_ids[ $ra->get_id() ] ) ) {
							$ra->update_meta_data( '_wca_resource_only', '1' );
							$appointments[] = $ra;
						}
					}
				}
			}
		}

		return $appointments;
	}

	/**
	 * Load appointments that hold any of the given resource IDs in a date range.
	 *
	 * @since 5.5.0
	 *
	 * @param int[] $resource_ids Resource IDs.
	 * @param int   $min_date    Start timestamp.
	 * @param int   $max_date    End timestamp.
	 * @return WC_Appointment[]
	 */
	private static function get_appointments_for_resource_ids( array $resource_ids, int $min_date, int $max_date ): array {
		$ids = WC_Appointments_Resource_Data_Store::get_appointment_ids_in_range( $resource_ids, $min_date, $max_date );
		if ( [] === $ids ) {
			return [];
		}

		return array_filter( array_map( 'get_wc_appointment', $ids ) );
	}

	/**
	 * Return all appointments for a product and/or staff in a given range  - the query part (no cache)
	 * @param integer              $start_date
	 * @param integer              $end_date
	 * @param integer              $product_id
	 * @param integer              $staff_id
	 * @param bool                 $check_in_cart
	 * @param array<string, mixed> $filters
	 * @param bool                 $strict
	 *
	 * @return int[] Appointment IDs.
	 */
	private static function get_appointments_in_date_range_query( $start_date, $end_date, $product_id, $staff_id, $check_in_cart, $filters, $strict ) {
		$args = wp_parse_args(
		    $filters,
		    [
				'status'       => get_wc_appointment_statuses(),
				'object_id'    => 0,
				'product_id'   => 0,
				'staff_id'     => 0,
				'object_type'  => 'product',
				'strict'       => $strict,
				'date_between' => [
					'start' => $start_date,
					'end'   => $end_date,
				],
			],
		);

		if ( ! $check_in_cart ) {
			$args['status'] = array_diff( $args['status'], [ 'in-cart' ] );
		}

		if ( $product_id ) {
			$args['product_id'] = $product_id;
		}

		if ( $staff_id ) {
			$args['staff_id'] = $staff_id;
		}

		if ( ! $product_id && $staff_id ) {
			$args['object_type'] = 'staff';
		}

		if ( $product_id && $staff_id ) {
			$args['object_type'] = 'product_and_staff';
		}

		// Filter the arguments
		$args = apply_filters( 'woocommerce_appointments_in_date_range_query_args', $args );

		// Filter the appointment IDs.
		return apply_filters( 'woocommerce_appointments_in_date_range_query', self::get_appointment_ids_by( $args ) );
	}

	/**
	 * Return all appointments for a product and/or staff in a given range
	 * @param integer              $start_date
	 * @param integer              $end_date
	 * @param integer              $product_id
	 * @param integer              $staff_id
	 * @param bool                 $check_in_cart
	 * @param array<string, mixed> $filters
	 * @param bool                 $strict
	 *
	 * @return WC_Appointment[]
	 */
	public static function get_appointments_in_date_range( $start_date, $end_date, $product_id = 0, $staff_id = 0, $check_in_cart = true, $filters = [], $strict = false ) {
		$appointment_ids = self::get_appointments_in_date_range_query( $start_date, $end_date, $product_id, $staff_id, $check_in_cart, $filters, $strict );

		// Get objects
		return array_map( 'get_wc_appointment', wp_parse_id_list( $appointment_ids ) );
	}

	/**
	 * Gets appointments for a user by ID
	 *
	 * @param  int                          $user_id    The id of the user that we want appointments for
	 * @param  array<string, mixed>|null    $query_args The query arguments used to get appointment IDs
	 *
	 * @return WC_Appointment[]
	 */
	public static function get_appointments_for_user( $user_id, $query_args = null ) {
		$appointment_ids = self::get_appointment_ids_by(
		    array_merge(
		        [
					'status'      => get_wc_appointment_statuses( 'user' ),
					'object_id'   => $user_id,
					'object_type' => 'customer',
				],
		        $query_args,
		    ),
		);

		return array_map( 'get_wc_appointment', $appointment_ids );
	}

	/**
	 * Gets appointments for a product by ID
	 *
	 * @param int      $product_id The id of the product that we want appointments for
	 * @param string[] $status
	 *
	 * @return WC_Appointment[]
	 */
	public static function get_appointments_for_product( $product_id, $status = [ WC_Appointments_Constants::STATUS_CONFIRMED, WC_Appointments_Constants::STATUS_PAID ] ) {
		$appointment_ids = self::get_appointment_ids_by(
		    [
				'object_id'   => $product_id,
				'object_type' => 'product',
				'status'      => $status,
			],
		);

		return array_map( 'get_wc_appointment', $appointment_ids );
	}

	/**
	 * Search appointment data for a term and return ids.
	 *
	 * @since 4.10.2
	 *
	 * @param  string $term Searched term.
	 * @return int[] Appointment IDs.
	 */
	public function search_appointments( $term ) {
		global $wpdb;

		$search_fields   = array_map(
		    'wc_clean',
		    apply_filters( 'woocommerce_appointment_search_fields', [] ),
		);
		$appointment_ids = [];

		if ( is_numeric( $term ) ) {
			$appointment_ids[] = absint( $term );
		}

		if ( [] !== $search_fields ) {
			$appointment_ids = array_unique(
			    array_merge(
			        $appointment_ids,
			        $wpdb->get_col(
			            $wpdb->prepare(
			                "SELECT DISTINCT p1.post_id
							FROM {$wpdb->postmeta} p1
							WHERE p1.meta_value LIKE %s
							AND p1.meta_key IN ('" . implode( "','", array_map( 'esc_sql', $search_fields ) ) . "')", // @codingStandardsIgnoreLine
							'%' . $wpdb->esc_like( wc_clean( $term ) ) . '%',
			            ),
			        ),
			    ),
			);
		}

		$appointment_ids = array_unique(
		    array_merge(
		        $appointment_ids,
		        $wpdb->get_col(
		            $wpdb->prepare(
		                "SELECT p.id
						FROM {$wpdb->prefix}posts p
						INNER JOIN $wpdb->users u ON p.post_author = u.id
						WHERE display_name LIKE %s OR user_nicename LIKE %s",
		                '%' . $wpdb->esc_like( wc_clean( $term ) ) . '%',
		                '%' . $wpdb->esc_like( wc_clean( $term ) ) . '%',
		            ),
		        ),
		        $wpdb->get_col(
		            $wpdb->prepare(
		                "SELECT pm.post_id
						FROM {$wpdb->prefix}postmeta pm
						INNER JOIN {$wpdb->prefix}posts p ON p.id = pm.meta_value
						WHERE meta_key = '_appointment_product_id' AND p.post_title LIKE %s",
		                '%' . $wpdb->esc_like( wc_clean( $term ) ) . '%',
		            ),
		        ),
		    ),
		);

		return apply_filters( 'woocommerce_appointment_search_results', $appointment_ids, $term, $search_fields );
	}

	/**
	 * Post statuses hidden from the admin calendar by default (holds, trash, drafts).
	 *
	 * Cancelled appointments are visible on the calendar (styled via is-cancelled).
	 *
	 * @since 5.4.3
	 *
	 * @return string[]
	 */
	public static function get_calendar_excluded_statuses(): array {
		$statuses = [ 'trash', 'auto-draft', 'in-cart', 'was-in-cart' ];

		/**
		 * Filter default excluded appointment statuses for admin calendar queries.
		 *
		 * @param string[] $statuses Bare post_status slugs to exclude when no explicit status filter is set.
		 */
		return apply_filters( 'woocommerce_appointments_calendar_excluded_statuses', $statuses );
	}

	/**
	 * Whether an appointment status should be hidden from the admin calendar.
	 *
	 * @since 5.4.3
	 *
	 * @param string $status Appointment status (bare slug or wc-prefixed).
	 * @return bool
	 */
	public static function is_calendar_excluded_status( $status ): bool {
		$status = strtolower( str_replace( 'wc-', '', (string) $status ) );

		return in_array( $status, self::get_calendar_excluded_statuses(), true );
	}

	/**
	 * Get appointments optimized for calendar display (eligible IDs + batched hydration).
	 *
	 * @since 5.0.0
	 *
	 * @param array<string, mixed> $args Query arguments.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_calendar_appointments( array $args ): array {
		global $wpdb;

		$start_ts   = absint( $args['start_ts'] ?? 0 );
		$end_ts     = absint( $args['end_ts'] ?? 0 );
		$product_id = absint( $args['product_id'] ?? 0 );
		$staff_id   = absint( $args['staff_id'] ?? 0 );
		$status     = $args['status'] ?? [];

		if ( 0 >= $start_ts || 0 >= $end_ts ) {
			return [];
		}

		$where  = array( "p.post_type = 'wc_appointment'" );
		$params = array();

		$start_str = gmdate( 'YmdHis', $start_ts );
		$end_str   = gmdate( 'YmdHis', $end_ts );
		$where[]   = 'pm_start.meta_value < %s';
		$params[]  = $end_str;
		$where[]   = 'pm_end.meta_value > %s';
		$params[]  = $start_str;

		if ( 0 < $product_id ) {
			$where[]  = "EXISTS ( SELECT 1 FROM {$wpdb->postmeta} pm_product_elig WHERE pm_product_elig.post_id = p.ID AND pm_product_elig.meta_key = '_appointment_product_id' AND pm_product_elig.meta_value = %d )";
			$params[] = $product_id;
		}

		if ( 0 < $staff_id ) {
			$where[]  = "( EXISTS ( SELECT 1 FROM {$wpdb->postmeta} pm_staff_match WHERE pm_staff_match.post_id = p.ID AND pm_staff_match.meta_key = '_appointment_staff_id' AND pm_staff_match.meta_value = %d )
				OR EXISTS ( SELECT 1 FROM {$wpdb->postmeta} pm_author_match WHERE pm_author_match.post_id = p.ID AND pm_author_match.meta_key = '_appointment_author' AND pm_author_match.meta_value = %d ) )";
			$params[] = $staff_id;
			$params[] = $staff_id;
		}

		if ( ! empty( $status ) ) {
			$statuses = array_filter(
				array_map(
					static function ( $status_value ) {
						$status_value = sanitize_text_field( (string) $status_value );
						return str_starts_with( $status_value, 'wc-' ) ? substr( $status_value, 3 ) : $status_value;
					},
					(array) $status
				)
			);
			if ( [] !== $statuses ) {
				$placeholders = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );
				$where[]      = "p.post_status IN ($placeholders)";
				$params       = array_merge( $params, $statuses );
			}
		} else {
			$excluded = self::get_calendar_excluded_statuses();
			if ( [] !== $excluded ) {
				$placeholders = implode( ', ', array_fill( 0, count( $excluded ), '%s' ) );
				$where[]      = "p.post_status NOT IN ($placeholders)";
				$params       = array_merge( $params, $excluded );
			}
		}

		$where_sql = 'WHERE ' . implode( ' AND ', $where );
		$limit     = absint( apply_filters( 'woocommerce_appointments_calendar_query_limit', 2000 ) );

		$eligible_sql = "
			SELECT p.ID
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id AND pm_start.meta_key = '_appointment_start'
			INNER JOIN {$wpdb->postmeta} pm_end ON p.ID = pm_end.post_id AND pm_end.meta_key = '_appointment_end'
			{$where_sql}
			ORDER BY pm_start.meta_value ASC
			LIMIT %d
		";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$appointment_ids = $wpdb->get_col( $wpdb->prepare( $eligible_sql, ...array_merge( $params, array( $limit ) ) ) );
		if ( empty( $appointment_ids ) ) {
			return [];
		}

		return array_map(
			[ __CLASS__, 'process_calendar_row' ],
			self::hydrate_calendar_appointment_rows( array_map( 'absint', $appointment_ids ), $staff_id )
		);
	}

	/**
	 * @param int[] $appointment_ids Ordered appointment IDs.
	 * @param int   $staff_id        Active staff filter.
	 * @return array<int, array<string, mixed>>
	 */
	private static function hydrate_calendar_appointment_rows( array $appointment_ids, int $staff_id ): array {
		global $wpdb;

		if ( empty( $appointment_ids ) ) {
			return array();
		}

		$id_ph = implode( ', ', array_fill( 0, count( $appointment_ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
		$post_rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_status, post_parent FROM {$wpdb->posts} WHERE ID IN ({$id_ph})", ...$appointment_ids ), ARRAY_A );
		$posts_by_id = array();
		foreach ( (array) $post_rows as $post_row ) {
			$posts_by_id[ (int) $post_row['ID'] ] = $post_row;
		}

		$meta_keys = array(
			'_appointment_start', '_appointment_end', '_appointment_product_id', '_appointment_staff_id', '_appointment_staff_ids',
			'_appointment_customer_id', '_appointment_customer_status', '_appointment_cost', '_appointment_all_day',
			'_appointment_order_item_id', '_appointment_qty', '_local_timezone', '_wca_series_id', '_wca_series_occurrence', '_appointment_author',
			'_appointment_location_id', '_appointment_location', '_appointment_resource_allocations', '_wca_meeting_join_url', '_wca_meeting_status',
		);
		$key_ph = implode( ', ', array_fill( 0, count( $meta_keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
		$meta_rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id IN ({$id_ph}) AND meta_key IN ({$key_ph})", ...array_merge( $appointment_ids, $meta_keys ) ) );
		$meta_by_post = array();
		foreach ( (array) $meta_rows as $meta_row ) {
			$meta_by_post[ (int) $meta_row->post_id ][ (string) $meta_row->meta_key ] = $meta_row->meta_value;
		}

		$rows = array();
		foreach ( $appointment_ids as $appointment_id ) {
			if ( ! isset( $posts_by_id[ $appointment_id ] ) ) {
				continue;
			}
			$post = $posts_by_id[ $appointment_id ];
			$meta = $meta_by_post[ $appointment_id ] ?? array();
			$rows[] = array(
				'id'                    => $appointment_id,
				'status'                => $post['post_status'],
				'order_id'              => $post['post_parent'],
				'start_raw'             => $meta['_appointment_start'] ?? '',
				'end_raw'               => $meta['_appointment_end'] ?? '',
				'product_id'            => $meta['_appointment_product_id'] ?? 0,
				'staff_id'              => $meta['_appointment_staff_id'] ?? 0,
				'staff_ids_raw'         => $meta['_appointment_staff_ids'] ?? '',
				'customer_id'           => $meta['_appointment_customer_id'] ?? 0,
				'customer_status'       => $meta['_appointment_customer_status'] ?? '',
				'cost'                  => $meta['_appointment_cost'] ?? '',
				'all_day'               => $meta['_appointment_all_day'] ?? '',
				'order_item_id'         => $meta['_appointment_order_item_id'] ?? 0,
				'qty'                   => $meta['_appointment_qty'] ?? '',
				'local_timezone'        => $meta['_local_timezone'] ?? '',
				'series_id_raw'         => $meta['_wca_series_id'] ?? '',
				'series_occurrence_raw' => $meta['_wca_series_occurrence'] ?? '',
				'creator_id'            => $meta['_appointment_author'] ?? 0,
				'location_id'           => $meta['_appointment_location_id'] ?? 0,
				'location_raw'          => $meta['_appointment_location'] ?? '',
				'resource_alloc_raw'    => $meta['_appointment_resource_allocations'] ?? '',
				'meeting_join_url_raw'  => $meta['_wca_meeting_join_url'] ?? '',
				'meeting_status'        => $meta['_wca_meeting_status'] ?? '',
			);
		}

		if ( empty( $rows ) ) {
			return array();
		}

		$customer_ids = $staff_ids = $product_ids = array();
		foreach ( $rows as $row ) {
			$cid = absint( $row['customer_id'] );
			$sid = absint( $row['staff_id'] );
			$pid = absint( $row['product_id'] );
			if ( $cid > 0 ) {
				$customer_ids[ $cid ] = $cid;
			}
			if ( $sid > 0 ) {
				$staff_ids[ $sid ] = $sid;
			}
			if ( $pid > 0 ) {
				$product_ids[ $pid ] = $pid;
			}
		}

		$user_map = $user_meta_map = array();
		if ( ! empty( $customer_ids ) ) {
			$ids  = array_values( $customer_ids );
			$u_ph = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, display_name, user_email FROM {$wpdb->users} WHERE ID IN ({$u_ph})", ...$ids ), ARRAY_A ) as $user_row ) {
				$user_map[ (int) $user_row['ID'] ] = $user_row;
			}
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE user_id IN ({$u_ph}) AND meta_key IN ('first_name', 'last_name', 'billing_phone')", ...$ids ) ) as $meta_row ) {
				$user_meta_map[ (int) $meta_row->user_id ][ (string) $meta_row->meta_key ] = $meta_row->meta_value;
			}
		}

		if ( ! empty( $staff_ids ) ) {
			foreach ( get_users( array( 'include' => array_values( $staff_ids ), 'fields' => array( 'ID', 'display_name', 'user_email' ) ) ) as $user ) {
				$user_map[ (int) $user->ID ] = array( 'display_name' => $user->display_name, 'user_email' => $user->user_email );
			}
		}

		$titles = $prod_meta = array();
		if ( ! empty( $product_ids ) ) {
			$ids  = array_values( $product_ids );
			$p_ph = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title FROM {$wpdb->posts} WHERE ID IN ({$p_ph})", ...$ids ), ARRAY_A ) as $title_row ) {
				$titles[ (int) $title_row['ID'] ] = $title_row['post_title'];
			}
			$pm_keys = array( '_wc_appointment_cal_color', '_wc_appointment_duration_unit', '_wc_appointment_duration' );
			$k_ph    = implode( ', ', array_fill( 0, count( $pm_keys ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id IN ({$p_ph}) AND meta_key IN ({$k_ph})", ...array_merge( $ids, $pm_keys ) ) ) as $pm_row ) {
				$prod_meta[ (int) $pm_row->post_id ][ (string) $pm_row->meta_key ] = $pm_row->meta_value;
			}
		}

		$missing_staff_ids = array();
		foreach ( $rows as &$row ) {
			if ( ! empty( $row['staff_ids_raw'] ) ) {
				$ids = maybe_unserialize( $row['staff_ids_raw'] );
				if ( is_array( $ids ) && ! empty( $ids ) ) {
					$row['staff_ids'] = array_map( 'absint', $ids );
					if ( empty( $row['staff_id'] ) ) {
						$row['staff_id'] = reset( $ids );
					}
				}
				unset( $row['staff_ids_raw'] );
			}

			$cid = absint( $row['customer_id'] );
			if ( $cid > 0 && isset( $user_map[ $cid ] ) ) {
				$row['customer_display_name'] = $user_map[ $cid ]['display_name'];
				$row['customer_email']        = $user_map[ $cid ]['user_email'];
				if ( isset( $user_meta_map[ $cid ] ) ) {
					$row['customer_first_name'] = $user_meta_map[ $cid ]['first_name'] ?? '';
					$row['customer_last_name']  = $user_meta_map[ $cid ]['last_name'] ?? '';
					$row['customer_phone']      = $user_meta_map[ $cid ]['billing_phone'] ?? '';
				}
			}

			$sid = absint( $row['staff_id'] );
			if ( $sid > 0 && isset( $user_map[ $sid ] ) ) {
				$row['staff_name']  = $user_map[ $sid ]['display_name'];
				$row['staff_email'] = $user_map[ $sid ]['user_email'];
			} elseif ( $sid > 0 ) {
				$missing_staff_ids[] = $sid;
			}

			$pid = absint( $row['product_id'] );
			if ( $pid > 0 ) {
				$row['product_title'] = $titles[ $pid ] ?? '';
				$row['cal_color']     = $prod_meta[ $pid ]['_wc_appointment_cal_color'] ?? '';
				$row['duration_unit'] = $prod_meta[ $pid ]['_wc_appointment_duration_unit'] ?? '';
				$row['duration_raw']  = $prod_meta[ $pid ]['_wc_appointment_duration'] ?? 0;
			}
		}
		unset( $row );

		if ( ! empty( $missing_staff_ids ) ) {
			foreach ( get_users( array( 'include' => array_unique( $missing_staff_ids ), 'fields' => array( 'ID', 'display_name', 'user_email' ) ) ) as $user ) {
				$user_map[ (int) $user->ID ] = array( 'display_name' => $user->display_name, 'user_email' => $user->user_email );
			}
			foreach ( $rows as &$row ) {
				$sid = absint( $row['staff_id'] );
				if ( $sid > 0 && isset( $user_map[ $sid ] ) ) {
					if ( empty( $row['staff_name'] ) ) {
						$row['staff_name'] = $user_map[ $sid ]['display_name'];
					}
					if ( empty( $row['staff_email'] ) ) {
						$row['staff_email'] = $user_map[ $sid ]['user_email'];
					}
				}
			}
			unset( $row );
		}

		return $rows;
	}

	/**
	 * Process a single row from get_calendar_appointments query.
	 *
	 * @since 5.0.0
	 *
	 * @param array<string, mixed> $row Raw database row.
	 * @return array<string, mixed> Processed appointment data.
	 */
	private static function process_calendar_row( array $row ): array {
		// Convert Fake UTC YmdHis wall tokens to epoch (do not use strtotime — PHP TZ can shift).
		if ( isset( $row['start_raw'] ) ) {
			$parsed = DateTimeImmutable::createFromFormat( 'YmdHis', (string) $row['start_raw'], new DateTimeZone( 'UTC' ) );
			$row['start'] = $parsed ? $parsed->getTimestamp() : 0;
			unset( $row['start_raw'] );
		}
		if ( isset( $row['end_raw'] ) ) {
			$parsed = DateTimeImmutable::createFromFormat( 'YmdHis', (string) $row['end_raw'], new DateTimeZone( 'UTC' ) );
			$row['end'] = $parsed ? $parsed->getTimestamp() : 0;
			unset( $row['end_raw'] );
		}

		if ( isset( $row['status'] ) ) {
			$row['status'] = str_replace( 'wc-', '', $row['status'] );
		}

		$row['id']         = absint( $row['id'] ?? 0 );
		$row['product_id'] = absint( $row['product_id'] ?? 0 );
		$row['order_id']   = absint( $row['order_id'] ?? 0 );

		if ( isset( $row['customer_id'] ) ) {
			$row['customer_id'] = absint( $row['customer_id'] );
		}
		if ( isset( $row['order_item_id'] ) ) {
			$row['order_item_id'] = absint( $row['order_item_id'] );
		}
		if ( isset( $row['cost'] ) ) {
			$row['cost'] = (float) $row['cost'];
		}
		if ( isset( $row['qty'] ) ) {
			$row['qty'] = absint( $row['qty'] ) ?: 1;
		}
		if ( isset( $row['all_day'] ) ) {
			$row['all_day'] = wc_appointments_string_to_bool( $row['all_day'] );
		}

		if ( isset( $row['staff_ids_raw'] ) ) {
			$ids = maybe_unserialize( $row['staff_ids_raw'] );
			if ( is_array( $ids ) ) {
				$row['staff_ids'] = array_map( 'absint', $ids );
			}
			unset( $row['staff_ids_raw'] );
		}

		if ( ! isset( $row['staff_ids'] ) && isset( $row['staff_id'] ) ) {
			$staff_val        = $row['staff_id'];
			$row['staff_ids'] = 0 < absint( $staff_val ) ? [ absint( $staff_val ) ] : [];
		}

		if ( isset( $row['staff_id'] ) ) {
			$row['staff_id'] = absint( $row['staff_id'] );
		}

		$first_name    = trim( $row['customer_first_name'] ?? '' );
		$last_name     = trim( $row['customer_last_name'] ?? '' );
		$display_name  = trim( $row['customer_display_name'] ?? '' );
		$full_name     = trim( $first_name . ' ' . $last_name );
		$customer_name = '' !== $full_name ? $full_name : $display_name;

		if ( '' !== $customer_name ) {
			$row['customer_name']       = $customer_name;
			$row['customer_first_name'] = $first_name;
			$row['customer_last_name']  = $last_name;
			$row['customer_full_name']  = $full_name ?: $display_name;
		} else {
			$row['customer_name']       = __( 'Guest', 'woocommerce-appointments' );
			$row['customer_first_name'] = '';
			$row['customer_last_name']  = '';
			$row['customer_full_name']  = __( 'Guest', 'woocommerce-appointments' );
		}
		unset( $row['customer_display_name'] );

		if ( empty( $row['cal_color'] ) ) {
			$row['cal_color'] = '';
		}

		if ( isset( $row['duration_unit'] ) ) {
			$row['duration_unit'] = (string) $row['duration_unit'];
		} else {
			$row['duration_unit'] = '';
		}
		if ( isset( $row['duration_raw'] ) ) {
			$row['duration'] = absint( $row['duration_raw'] );
			unset( $row['duration_raw'] );
		} else {
			$row['duration'] = 0;
		}

		if ( empty( $row['customer_status'] ) ) {
			$row['customer_status'] = 'expected';
		}

		$customer_email         = isset( $row['customer_email'] ) ? $row['customer_email'] : '';
		$row['customer_avatar'] = get_avatar_url( $customer_email, [ 'size' => 48 ] );
		if ( ! isset( $row['customer_phone'] ) ) {
			$row['customer_phone'] = '';
		}

		$staff_email         = isset( $row['staff_email'] ) ? $row['staff_email'] : '';
		$row['staff_avatar'] = get_avatar_url( $staff_email, [ 'size' => 48 ] );
		unset( $row['staff_email'] );

		if ( ! isset( $row['staff_name'] ) || '' === $row['staff_name'] ) {
			$row['staff_name'] = '';
		}

		if ( isset( $row['series_id_raw'] ) ) {
			$row['series_id'] = absint( $row['series_id_raw'] );
			unset( $row['series_id_raw'] );
		}
		if ( isset( $row['series_occurrence_raw'] ) ) {
			$row['series_occurrence'] = absint( $row['series_occurrence_raw'] );
			unset( $row['series_occurrence_raw'] );
		}

		$row['location_id'] = absint( $row['location_id'] ?? 0 );
		$snapshot           = null;
		if ( isset( $row['location_raw'] ) ) {
			$snapshot = maybe_unserialize( $row['location_raw'] );
			$row['location_display'] = ( is_array( $snapshot ) && class_exists( 'WC_Appointments_Location' ) )
				? WC_Appointments_Location::format_snapshot_for_display( $snapshot )
				: '';
			unset( $row['location_raw'] );
		} else {
			$row['location_display'] = '';
		}

		if ( isset( $row['resource_alloc_raw'] ) ) {
			$allocs = maybe_unserialize( $row['resource_alloc_raw'] );
			$row['resource_allocations'] = is_array( $allocs ) ? $allocs : [];
			$row['resource_display']     = ( [] !== $row['resource_allocations'] && class_exists( 'WC_Appointments_Resource' ) )
				? WC_Appointments_Resource::format_allocations_for_display( $row['resource_allocations'] )
				: '';
			unset( $row['resource_alloc_raw'] );
		} else {
			$row['resource_allocations'] = [];
			$row['resource_display']     = '';
		}

		$meeting_status = isset( $row['meeting_status'] ) ? (string) $row['meeting_status'] : '';
		$meeting_url    = isset( $row['meeting_join_url_raw'] ) ? (string) $row['meeting_join_url_raw'] : '';
		$row['meeting_join_url'] = ( 'created' === $meeting_status && '' !== $meeting_url ) ? $meeting_url : '';
		unset( $row['meeting_join_url_raw'], $row['meeting_status'] );

		// When a generated join URL exists, omit static URL from location_display (no snapshot mutation).
		if ( '' !== $row['meeting_join_url'] && is_array( $snapshot ) && class_exists( 'WC_Appointments_Location' ) ) {
			$copy = $snapshot;
			unset( $copy['static_join_url'] );
			$row['location_display'] = WC_Appointments_Location::format_snapshot_for_display( $copy );
		}

		if ( class_exists( 'WC_Appointments_Timezone_Helper' ) ) {
			$local_tz    = $row['local_timezone'] ?? '';
			$customer_id = absint( $row['customer_id'] ?? 0 );
			$resolved_tz = '';

			if ( $customer_id ) {
				$account_tz = get_user_meta( $customer_id, WC_Appointments_Timezone_Helper::USER_META_KEY, true );
				if ( $account_tz && WC_Appointments_Timezone_Helper::is_valid_timezone( $account_tz ) ) {
					$resolved_tz = $account_tz;
				}
			}

			if ( ! $resolved_tz && $local_tz && WC_Appointments_Timezone_Helper::is_valid_timezone( $local_tz ) ) {
				$resolved_tz = $local_tz;
			}

			if ( ! $resolved_tz ) {
				$resolved_tz = WC_Appointments_Timezone_Helper::get_site_timezone_string();
			}

			$row['customer_timezone'] = $resolved_tz;
		}

		// Keep creator_id for client staff-filter parity (author match), same as legacy calendar.
		$row['creator_id'] = absint( $row['creator_id'] ?? 0 );

		return $row;
	}

	/**
	 * @param array<string, string> $item_meta Order item meta map.
	 * @return array<int, array{key: string, value: mixed, display_key: string, display_value: string}>
	 */
	private static function format_calendar_line_item_meta_map( array $item_meta ): array {
		$meta_data = array();

		foreach ( $item_meta as $key => $value ) {
			if ( '' === $value || ! is_scalar( $value ) ) {
				continue;
			}

			if ( 0 === strpos( $key, '_' ) ) {
				continue;
			}

			$value         = rawurldecode( (string) $value );
			$attribute_key = str_replace( 'attribute_', '', $key );

			$meta_data[] = array(
				'key'           => $key,
				'value'         => $value,
				'display_key'   => wc_attribute_label( $attribute_key ),
				'display_value' => self::format_calendar_line_item_display_value( $key, $value ),
			);
		}

		return $meta_data;
	}

	/**
	 * Human-readable order line meta for calendar payloads (matches WC order item display).
	 *
	 * @param string $meta_key Order item meta key.
	 * @param string $value    Stored meta value (decoded).
	 * @return string
	 */
	private static function format_calendar_line_item_display_value( string $meta_key, string $value ): string {
		if ( 0 === strpos( $meta_key, 'attribute_' ) ) {
			$taxonomy = str_replace( 'attribute_', '', $meta_key );
			if ( taxonomy_exists( $taxonomy ) ) {
				$term = get_term_by( 'slug', $value, $taxonomy );
				if ( $term && ! is_wp_error( $term ) ) {
					return wp_strip_all_tags( $term->name );
				}
			}
		}

		return wp_strip_all_tags( $value );
	}

	/**
	 * Meta keys for batched calendar order payloads.
	 *
	 * @return string[]
	 */
	private static function calendar_order_meta_keys(): array {
		return array(
			'_billing_first_name',
			'_billing_last_name',
			'_billing_email',
			'_billing_phone',
			'_order_currency',
			'_order_total',
			'_order_tax',
			'_cart_discount',
			'_cart_discount_tax',
		);
	}

	/**
	 * Get order details for calendar appointments (batched SQL, no WC_Order hydration).
	 *
	 * @param int[] $order_ids Order IDs.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_calendar_order_details( array $order_ids ): array {
		global $wpdb;

		$order_ids = array_values( array_unique( array_filter( array_map( 'absint', $order_ids ) ) ) );
		if ( empty( $order_ids ) ) {
			return array();
		}

		$meta_by_order = array();
		$ph            = implode( ', ', array_fill( 0, count( $order_ids ), '%d' ) );
		$meta_keys     = self::calendar_order_meta_keys();
		$key_ph        = implode( ', ', array_fill( 0, count( $meta_keys ), '%s' ) );
		$uses_hpos     = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

		if ( $uses_hpos && class_exists( '\Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore' ) ) {
			$table = $wpdb->prefix . 'wc_orders';
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, currency, total_amount, tax_amount FROM {$table} WHERE id IN ({$ph}) AND type = 'shop_order'", ...$order_ids ), ARRAY_A ) as $row ) {
				$oid = (int) $row['id'];
				$meta_by_order[ $oid ] = array(
					'_order_currency' => (string) ( $row['currency'] ?? '' ),
					'_order_total'    => (string) ( $row['total_amount'] ?? '' ),
					'_order_tax'      => (string) ( $row['tax_amount'] ?? '' ),
				);
			}
			if ( empty( $meta_by_order ) ) {
				return array();
			}
			$valid_ids = array_keys( $meta_by_order );
			$v_ph      = implode( ', ', array_fill( 0, count( $valid_ids ), '%d' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT order_id, meta_key, meta_value FROM {$wpdb->prefix}wc_orders_meta WHERE order_id IN ({$v_ph}) AND meta_key IN ({$key_ph})", ...array_merge( $valid_ids, $meta_keys ) ) ) as $meta_row ) {
				$meta_by_order[ (int) $meta_row->order_id ][ (string) $meta_row->meta_key ] = (string) $meta_row->meta_value;
			}
			$addresses_table = $wpdb->prefix . 'wc_order_addresses';
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT order_id, first_name, last_name, email, phone FROM {$addresses_table} WHERE order_id IN ({$v_ph}) AND address_type = 'billing'", ...$valid_ids ), ARRAY_A ) as $address_row ) {
				$oid = (int) $address_row['order_id'];
				if ( ! isset( $meta_by_order[ $oid ] ) ) {
					continue;
				}
				$meta_by_order[ $oid ]['_billing_first_name'] = (string) ( $address_row['first_name'] ?? '' );
				$meta_by_order[ $oid ]['_billing_last_name']  = (string) ( $address_row['last_name'] ?? '' );
				$meta_by_order[ $oid ]['_billing_email']     = (string) ( $address_row['email'] ?? '' );
				$meta_by_order[ $oid ]['_billing_phone']     = (string) ( $address_row['phone'] ?? '' );
			}
		} else {
			$types = function_exists( 'wc_get_order_types' ) ? wc_get_order_types( 'order-type' ) : array( 'shop_order' );
			$t_ph  = implode( ', ', array_fill( 0, count( $types ), '%s' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			$valid_ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE ID IN ({$ph}) AND post_type IN ({$t_ph})", ...array_merge( $order_ids, $types ) ) ) );
			if ( empty( $valid_ids ) ) {
				return array();
			}
			$v_ph = implode( ', ', array_fill( 0, count( $valid_ids ), '%d' ) );
			foreach ( $valid_ids as $order_id ) {
				$meta_by_order[ $order_id ] = array();
			}
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id IN ({$v_ph}) AND meta_key IN ({$key_ph})", ...array_merge( $valid_ids, $meta_keys ) ) ) as $meta_row ) {
				$meta_by_order[ (int) $meta_row->post_id ][ (string) $meta_row->meta_key ] = (string) $meta_row->meta_value;
			}
		}

		$valid_ids = array_keys( $meta_by_order );
		$v_ph      = implode( ', ', array_fill( 0, count( $valid_ids ), '%d' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
		$item_rows = $wpdb->get_results( $wpdb->prepare( "SELECT order_id, order_item_id, order_item_name, order_item_type FROM {$wpdb->prefix}woocommerce_order_items WHERE order_id IN ({$v_ph}) ORDER BY order_item_id", ...$valid_ids ) );

		$item_ids = $items_by_order = array();
		foreach ( (array) $item_rows as $item_row ) {
			$oid = (int) $item_row->order_id;
			$iid = (int) $item_row->order_item_id;
			$items_by_order[ $oid ][] = $item_row;
			$item_ids[]               = $iid;
		}

		$meta_by_item = array();
		if ( $item_ids ) {
			$iph = implode( ', ', array_fill( 0, count( $item_ids ), '%d' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN placeholders; IDs int-cast.
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT order_item_id, meta_key, meta_value FROM {$wpdb->prefix}woocommerce_order_itemmeta WHERE order_item_id IN ({$iph})", ...$item_ids ) ) as $mr ) {
				$meta_by_item[ (int) $mr->order_item_id ][ (string) $mr->meta_key ] = (string) $mr->meta_value;
			}
		}

		$orders_data = array();
		foreach ( $valid_ids as $order_id ) {
			$meta         = $meta_by_order[ $order_id ] ?? array();
			$line_items   = array();
			$coupon_lines = array();
			foreach ( (array) ( $items_by_order[ $order_id ] ?? array() ) as $item_row ) {
				$iid = (int) $item_row->order_item_id;
				$im  = $meta_by_item[ $iid ] ?? array();
				if ( 'line_item' === (string) $item_row->order_item_type ) {
					$line_items[] = array(
						'id'           => $iid,
						'name'         => (string) $item_row->order_item_name,
						'product_id'   => absint( $im['_product_id'] ?? 0 ),
						'quantity'     => (float) ( $im['_qty'] ?? 0 ),
						'subtotal'     => (float) ( $im['_line_subtotal'] ?? 0 ),
						'subtotal_tax' => (float) ( $im['_line_subtotal_tax'] ?? 0 ),
						'total'        => (float) ( $im['_line_total'] ?? 0 ),
						'total_tax'    => (float) ( $im['_line_tax'] ?? 0 ),
						'meta_data'    => self::format_calendar_line_item_meta_map( $im ),
					);
				} elseif ( 'coupon' === (string) $item_row->order_item_type ) {
					$coupon_lines[] = array(
						'code'         => (string) $item_row->order_item_name,
						'discount'     => (float) ( $im['discount_amount'] ?? 0 ),
						'discount_tax' => (float) ( $im['discount_amount_tax'] ?? 0 ),
					);
				}
			}
			$orders_data[ $order_id ] = array(
				'id'             => $order_id,
				'currency'       => $meta['_order_currency'] ?? '',
				'total'          => $meta['_order_total'] ?? '',
				'total_tax'      => $meta['_order_tax'] ?? '',
				'discount_total' => $meta['_cart_discount'] ?? '',
				'discount_tax'   => $meta['_cart_discount_tax'] ?? '',
				'coupon_lines'   => $coupon_lines,
				'billing'        => array(
					'first_name' => $meta['_billing_first_name'] ?? '',
					'last_name'  => $meta['_billing_last_name'] ?? '',
					'email'      => $meta['_billing_email'] ?? '',
					'phone'      => $meta['_billing_phone'] ?? '',
				),
				'line_items'     => $line_items,
			);
		}

		return $orders_data;
	}
}
