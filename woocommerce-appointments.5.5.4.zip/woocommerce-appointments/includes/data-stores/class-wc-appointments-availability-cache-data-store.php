<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Data store for wc_appointments_availability_cache.
 *
 * @package Woocommerce/Appointments
 * @since 5.0.0
 */
class WC_Appointments_Availability_Cache_Data_Store extends WC_Data_Store_WP {

	public const TABLE_NAME  = 'wc_appointments_availability_cache';
	public const CACHE_GROUP = 'wc-appointments-availability-cache';

	/**
	 * Perform an UPSERT using a natural unique key across key columns.
	 * Requires a unique index on (source, source_id, staff_id, product_id, start_ts, end_ts, status).
	 *
	 * @param array<string, mixed> $data Column => value.
	 * @return int Insert ID if a new row is created, or existing row ID via LAST_INSERT_ID(id) on update.
	 */
	protected function upsert_row( array $data ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;

		// Build insert columns and values.
		$cols = array_keys( $data );
		$vals = array_values( $data );

		$placeholders = array_fill( 0, count( $vals ), '%s' );
		// Adjust numeric placeholders for performance/typing.
		foreach ( $cols as $i => $col ) {
			if ( in_array( $col, [ 'source_id', 'product_id', 'staff_id', 'resource_id', 'priority', 'ordering', 'qty', 'start_ts', 'end_ts' ], true ) ) {
				$placeholders[ $i ] = '%d';
			}
		}

		// Columns to update on conflict (skip natural key cols).
		$update_cols = [
			'scope',
			'appointable',
			'priority',
			'ordering',
			'qty',
			'range_type',
			'rule_kind',
			'status',
			'date_modified',
		];

		$update_formats = [
			'scope'         => 'scope = %s',
			'appointable'   => 'appointable = %s',
			'priority'      => 'priority = %d',
			'ordering'      => 'ordering = %d',
			'qty'           => 'qty = %d',
			'range_type'    => 'range_type = %s',
			'rule_kind'     => 'rule_kind = %s',
			'status'        => 'status = %s',
			'date_modified' => 'date_modified = %s',
		];

		$update_fragments = [];
		$update_values    = [];
		foreach ( $update_cols as $uc ) {
			if ( 'date_modified' === $uc ) {
				continue;
			}
			if ( array_key_exists( $uc, $data ) ) {
				$update_fragments[] = $update_formats[ $uc ];
				$update_values[]    = $data[ $uc ];
			}
		}
		$update_fragments[] = 'date_modified = %s';
		$update_values[]    = current_time( 'mysql' );

		$sql = sprintf(
		    "INSERT INTO %s (%s) VALUES (%s)
			 ON DUPLICATE KEY UPDATE %s, id = LAST_INSERT_ID(id)",
		    $table,
		    implode( ',', $cols ),
		    implode( ',', $placeholders ),
		    implode( ', ', $update_fragments ),
		);

		$prepared_sql = $wpdb->prepare( $sql, ...array_merge( $vals, $update_values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $prepared_sql );

		return (int) $wpdb->insert_id;
	}

	/**
	 * @param WC_Appointments_Availability_Cache $object Cache row object.
	 */
	public function create( &$object ): void {
		global $wpdb;

		$object->apply_changes();

		$data = [
			'source'        => $object->get_source( 'edit' ),
			'source_id'     => (int) $object->get_source_id( 'edit' ),
			'product_id'    => (int) $object->get_product_id( 'edit' ),
			'staff_id'      => (int) $object->get_staff_id( 'edit' ),
			'resource_id'   => (int) $object->get_resource_id( 'edit' ),
			'scope'         => $object->get_scope( 'edit' ),
			'appointable'   => $object->get_appointable( 'edit' ),
			'priority'      => (int) $object->get_priority( 'edit' ),
			'ordering'      => (int) $object->get_ordering( 'edit' ),
			'qty'           => (int) $object->get_qty( 'edit' ),
			'start_ts'      => (int) $object->get_start_ts( 'edit' ),
			'end_ts'        => (int) $object->get_end_ts( 'edit' ),
			'range_type'    => $object->get_range_type( 'edit' ),
			'rule_kind'     => $object->get_rule_kind( 'edit' ),
			'status'        => $object->get_status( 'edit' ),
			'date_created'  => current_time( 'mysql' ),
			'date_modified' => current_time( 'mysql' ),
		];

		// Use UPSERT to avoid delete-then-insert churn and make writes idempotent.
		$insert_id = $this->upsert_row( $data );
		$object->set_id( (int) $insert_id );

		wp_cache_delete( $object->get_id(), self::CACHE_GROUP );
	}

	/**
	 * @param WC_Appointments_Availability_Cache $object Cache row object.
	 */
	public function read( &$object ): void {
		$data = wp_cache_get( $object->get_id(), self::CACHE_GROUP );

		if ( false === $data ) {
			global $wpdb;

			$data = $wpdb->get_row(
			    $wpdb->prepare(
			        "SELECT
						id as id,
						source,
						source_id,
						product_id,
						staff_id,
						resource_id,
						scope,
						appointable,
						priority,
						ordering,
						qty,
						start_ts,
						end_ts,
						range_type,
						rule_kind,
						status,
						date_created,
						date_modified
					FROM {$wpdb->prefix}wc_appointments_availability_cache WHERE id = %d LIMIT 1",
			        $object->get_id(),
			    ),
			    ARRAY_A,
			);

			if ( empty( $data ) ) {
				throw new Exception( __( 'Invalid availability cache item.', 'woocommerce-appointments' ) );
			}

			wp_cache_set( $object->get_id(), $data, self::CACHE_GROUP );
		}

		if ( is_array( $data ) ) {
			$object->set_props( $data );
			$object->set_object_read( true );
		}
	}

	/**
	 * @param WC_Appointments_Availability_Cache $object Cache row object.
	 */
	public function update( &$object ): void {
		global $wpdb;

		$changes                  = $object->get_changes();
		$changes['date_modified'] = current_time( 'mysql' );

		// If natural-key columns are unchanged, normal update is fine; otherwise fall back to UPSERT for safety.
		$natural_keys    = [ 'source', 'source_id', 'product_id', 'staff_id', 'start_ts', 'end_ts', 'status' ];
		$mutated_natural = array_intersect( array_keys( $changes ), $natural_keys );

		if ( [] === $mutated_natural ) {
			$wpdb->update(
			    $wpdb->prefix . self::TABLE_NAME,
			    $changes,
			    [ 'id' => $object->get_id() ],
			    null,
			    [ '%d' ],
			);
		} else {
			// Rebuild the full row using current values from the object and upsert.
			$data = [
				'source'        => $object->get_source( 'edit' ),
				'source_id'     => (int) $object->get_source_id( 'edit' ),
				'product_id'    => (int) $object->get_product_id( 'edit' ),
				'staff_id'      => (int) $object->get_staff_id( 'edit' ),
				'resource_id'   => (int) $object->get_resource_id( 'edit' ),
				'scope'         => $object->get_scope( 'edit' ),
				'appointable'   => $object->get_appointable( 'edit' ),
				'priority'      => (int) $object->get_priority( 'edit' ),
				'ordering'      => (int) $object->get_ordering( 'edit' ),
				'qty'           => (int) $object->get_qty( 'edit' ),
				'start_ts'      => (int) $object->get_start_ts( 'edit' ),
				'end_ts'        => (int) $object->get_end_ts( 'edit' ),
				'range_type'    => $object->get_range_type( 'edit' ),
				'rule_kind'     => $object->get_rule_kind( 'edit' ),
				'status'        => $object->get_status( 'edit' ),
				'date_created'  => $object->get_date_created( 'edit' ) ? $object->get_date_created( 'edit' )->date( 'Y-m-d H:i:s' ) : current_time( 'mysql' ),
				'date_modified' => current_time( 'mysql' ),
			];
			$this->upsert_row( $data );
		}

		$object->apply_changes();
		wp_cache_delete( $object->get_id(), self::CACHE_GROUP );
	}

	/**
	 * @param WC_Appointments_Availability_Cache $object Cache row object.
	 * @param array<string, mixed>               $args   Unused delete args.
	 */
	public function delete( &$object, $args = [] ): void {
		global $wpdb;

		$wpdb->delete(
		    $wpdb->prefix . self::TABLE_NAME,
		    [ 'id' => $object->get_id() ],
		    [ '%d' ],
		);

		wp_cache_delete( $object->get_id(), self::CACHE_GROUP );
		$object->set_id( 0 );
	}

	/**
	 * Query cached rows by filters.
	 *
	 * Filters (all optional):
	 * - product_id (int|int[]) - filter by product(s)
	 * - staff_id (int|int[])   - filter by staff
	 * - scope ('global'|'product'|'staff'|string[])
	 * - appointable ('yes'|'no'|string[])
	 * - time_between ['start_ts' => x, 'end_ts' => y] - intersecting rows with range
	 * - source ('availability'|'appointment'|string[])
	 * - status ('unpaid'|'paid'|'confirmed'|'expired'|...string[])
	 * - limit, offset, order ('ASC'|'DESC'), order_by (start_ts|end_ts|priority)
	 *
	 * Returns array of associative rows; callers can wrap them in data-objects if desired.
	 *
	 * @param array<string, mixed> $filters Query filters (see method docblock).
	 * @return array<int, array<string, mixed>>
	 */
	public function get_items( array $filters = [] ) {
		global $wpdb;

		$where = [ '1=1' ];

		$add_in = function( $field, $values, bool $allow_zero = false ) use ( &$where ): void {
			$values = is_array( $values ) ? array_map( 'intval', $values ) : [ (int) $values ];
			$values = array_filter( $values, static fn( int $v ): bool => $allow_zero ? ( 0 <= $v ) : ( 0 < $v ) );
			if ( [] !== $values ) {
				$where[] = sprintf( "%s IN (%s)", esc_sql( $field ), implode( ',', array_map( 'intval', $values ) ) );
			}
		};

		if ( isset( $filters['product_id'] ) ) {
			$add_in( 'product_id', $filters['product_id'] );
		}
		if ( isset( $filters['staff_id'] ) ) {
			$add_in( 'staff_id', $filters['staff_id'], true );
		}
		if ( isset( $filters['source_id'] ) ) {
			$add_in( 'source_id', $filters['source_id'] );
		}

		if ( isset( $filters['scope'] ) ) {
			$scopes = (array) $filters['scope'];
			$scopes = array_map( 'sanitize_text_field', $scopes );
			if ( [] !== $scopes ) {
				$esc     = implode( "','", array_map( 'esc_sql', $scopes ) );
				$where[] = "scope IN ('{$esc}')";
			}
		}

		if ( isset( $filters['appointable'] ) ) {
			$vals = (array) $filters['appointable'];
			$vals = array_map( 'sanitize_text_field', $vals );
			if ( [] !== $vals ) {
				$esc     = implode( "','", array_map( 'esc_sql', $vals ) );
				$where[] = "appointable IN ('{$esc}')";
			}
		}

		if ( isset( $filters['source'] ) ) {
			$vals = (array) $filters['source'];
			$vals = array_map( 'sanitize_text_field', $vals );
			if ( [] !== $vals ) {
				$esc     = implode( "','", array_map( 'esc_sql', $vals ) );
				$where[] = "source IN ('{$esc}')";
			}
		}

		if ( isset( $filters['status'] ) ) {
			$statuses = (array) $filters['status'];
			$statuses = array_map( 'sanitize_text_field', $statuses );
			if ( [] !== $statuses ) {
				$esc     = implode( "','", array_map( 'esc_sql', $statuses ) );
				$where[] = "status IN ('{$esc}')";
			}
		}

		if ( isset( $filters['time_between']['start_ts'], $filters['time_between']['end_ts'] ) ) {
			$start_ts = (int) $filters['time_between']['start_ts'];
			$end_ts   = (int) $filters['time_between']['end_ts'];
			// Intersecting ranges.
			$where[] = $wpdb->prepare( '(end_ts > %d AND start_ts < %d)', $start_ts, $end_ts );
		}

		$order_by = 'start_ts';
		if ( ! empty( $filters['order_by'] ) && in_array( $filters['order_by'], [ 'start_ts', 'end_ts', 'priority' ], true ) ) {
			$order_by = $filters['order_by'];
		}

		$order = 'ASC';
		if ( ! empty( $filters['order'] ) && in_array( strtoupper( $filters['order'] ), [ 'ASC', 'DESC' ], true ) ) {
			$order = strtoupper( $filters['order'] );
		}

		$limit  = isset( $filters['limit'] ) ? max( -1, (int) $filters['limit'] ) : -1;
		$offset = isset( $filters['offset'] ) ? max( 0, (int) $filters['offset'] ) : 0;

		$sql = "SELECT *
				  FROM {$wpdb->prefix}" . self::TABLE_NAME . '
				 WHERE ' . implode( ' AND ', $where ) . "
				 ORDER BY {$order_by} {$order}";

		if ( -1 < $limit ) {
			$sql .= $wpdb->prepare( ' LIMIT %d OFFSET %d', $limit, $offset );
		}

		return $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Delete multiple rows by source and source_id.
	 *
	 * @param string $source The source type ('availability' or 'appointment')
	 * @param int    $source_id The source ID
	 * @return int Number of rows deleted
	 */
	public function delete_by_source( $source, $source_id ) {
		global $wpdb;

		$deleted = $wpdb->delete(
		    $wpdb->prefix . self::TABLE_NAME,
		    [
				'source'    => sanitize_text_field( $source ),
				'source_id' => (int) $source_id,
			],
		    [ '%s', '%d' ],
		);

		// Clear any cached objects that might be affected
		wp_cache_flush_group( self::CACHE_GROUP );

		return (int) $deleted;
	}

	/**
	 * Delete rows by multiple criteria (for cart operations).
	 *
	 * @param array<string, mixed> $criteria Array of criteria to match
	 * @return int Number of rows deleted
	 */
	public function delete_by_criteria( array $criteria ) {
		global $wpdb;

		// Sanitize criteria
		$sanitized_criteria = [];
		$formats            = [];

		foreach ( $criteria as $key => $value ) {
			switch ( $key ) {
				case 'source':
				case 'scope':
				case 'appointable':
				case 'status':
					$sanitized_criteria[ $key ] = sanitize_text_field( $value );
					$formats[]                  = '%s';
					break;
				case 'source_id':
				case 'product_id':
				case 'staff_id':
				case 'start_ts':
				case 'end_ts':
				case 'priority':
				case 'qty':
					$sanitized_criteria[ $key ] = (int) $value;
					$formats[]                  = '%d';
					break;
			}
		}

		if ( [] === $sanitized_criteria ) {
			return 0;
		}

		$deleted = $wpdb->delete(
		    $wpdb->prefix . self::TABLE_NAME,
		    $sanitized_criteria,
		    $formats,
		);

		// Clear any cached objects that might be affected
		wp_cache_flush_group( self::CACHE_GROUP );

		return (int) $deleted;
	}

	/**
	 * Bulk insert multiple cache rows efficiently.
	 *
	 * @param array<int, array<string, mixed>> $rows Array of row data arrays
	 * @return int Number of rows inserted
	 */
	public function bulk_insert( array $rows ) {
		global $wpdb;

		if ( [] === $rows ) {
			return 0;
		}

		$table   = $wpdb->prefix . self::TABLE_NAME;
		$columns = [
			'source',
			'source_id',
			'product_id',
			'staff_id',
			'resource_id',
			'scope',
			'appointable',
			'priority',
			'ordering',
			'qty',
			'start_ts',
			'end_ts',
			'range_type',
			'rule_kind',
			'status',
			'date_created',
			'date_modified',
		];

		// Optimize: Process in chunks to avoid query size limits and improve performance
		// Larger batches are more efficient, but we need to balance with query size limits
		$chunk_size     = 500; // Process 500 rows at a time for optimal performance
		$total_rows     = count( $rows );
		$total_inserted = 0;

		// Process rows in chunks
		for ( $offset = 0; $offset < $total_rows; $offset += $chunk_size ) {
			$chunk = array_slice( $rows, $offset, $chunk_size );
			if ( [] === $chunk ) {
				break;
			}

			$values = [];
			foreach ( $chunk as $row ) {
				// Ensure all required fields are present with defaults
				$row = wp_parse_args(
                     $row,
                    [
						'source'        => '',
						'source_id'     => 0,
						'product_id'    => 0,
						'staff_id'      => 0,
						'resource_id'   => 0,
						'scope'         => 'global',
						'appointable'   => 'yes',
						'priority'      => 10,
						'ordering'      => 0,
						'qty'           => 0,
						'start_ts'      => 0,
						'end_ts'        => 0,
						'range_type'    => '',
						'rule_kind'     => '',
						'status'        => '',
						'date_created'  => current_time( 'mysql' ),
						'date_modified' => current_time( 'mysql' ),
					]
                    );

				$values[] = $wpdb->prepare(
				    "( %s, %d, %d, %d, %d, %s, %s, %d, %d, %d, %d, %d, %s, %s, %s, %s, %s )",
				    sanitize_text_field( $row['source'] ),
				    (int) $row['source_id'],
				    (int) $row['product_id'],
				    (int) $row['staff_id'],
				    (int) $row['resource_id'],
				    sanitize_text_field( $row['scope'] ),
				    sanitize_text_field( $row['appointable'] ),
				    (int) $row['priority'],
				    (int) $row['ordering'],
				    (int) $row['qty'],
				    (int) $row['start_ts'],
				    (int) $row['end_ts'],
				    sanitize_text_field( $row['range_type'] ),
				    sanitize_text_field( $row['rule_kind'] ),
				    sanitize_text_field( $row['status'] ),
				    $row['date_created'],
				    $row['date_modified'],
				);
			}

			$values_sql  = implode( ',', $values );
			$columns_sql = implode( ',', $columns );

			$sql = "INSERT INTO {$table} ({$columns_sql}) VALUES {$values_sql}
					ON DUPLICATE KEY UPDATE
						scope = VALUES(scope),
						appointable = VALUES(appointable),
						priority = VALUES(priority),
						ordering = VALUES(ordering),
						qty = VALUES(qty),
						start_ts = VALUES(start_ts),
						end_ts = VALUES(end_ts),
						range_type = VALUES(range_type),
						rule_kind = VALUES(rule_kind),
						status = VALUES(status),
						date_modified = VALUES(date_modified)";

			$result          = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$total_inserted += (int) $result;
		}

		// Clear cache group since we've inserted new data (only once at the end)
		wp_cache_flush_group( self::CACHE_GROUP );

		return $total_inserted;
	}

	/**
	 * Count rows by source and source_id.
	 *
	 * @param string $source The source type
	 * @param int    $source_id The source ID
	 * @return int Number of matching rows
	 */
	public function count_by_source( $source, $source_id ) {
		global $wpdb;

		return (int) $wpdb->get_var(
		    $wpdb->prepare(
		        "SELECT COUNT(*) FROM {$wpdb->prefix}wc_appointments_availability_cache WHERE source = %s AND source_id = %d",
		        sanitize_text_field( $source ),
		        (int) $source_id,
		    ),
		);
	}

	/**
	 * Delete rows by time range and optional criteria.
	 *
	 * @param array<string, mixed> $criteria Deletion criteria
	 * @return int Number of rows deleted
	 */
	public function delete_by_time_criteria( array $criteria ) {
		global $wpdb;

		$where  = [];
		$values = [];

		if ( isset( $criteria['source'] ) ) {
			$where[]  = 'source = %s';
			$values[] = sanitize_text_field( $criteria['source'] );
		}

		if ( isset( $criteria['status'] ) ) {
			$where[]  = 'status = %s';
			$values[] = sanitize_text_field( $criteria['status'] );
		}

		if ( isset( $criteria['end_ts_before'] ) ) {
			$where[]  = 'end_ts < %d';
			$values[] = (int) $criteria['end_ts_before'];
		}

		if ( [] === $where ) {
			return 0;
		}

		$where_sql = implode( ' AND ', $where );
		$sql       = "DELETE FROM {$wpdb->prefix}" . self::TABLE_NAME . " WHERE {$where_sql}";

		$result = $wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		// Clear cache group since we've deleted data
		wp_cache_flush_group( self::CACHE_GROUP );

		return (int) $result;
	}

	/**
	 * Clear all rows from the cache table.
	 *
	 * @return int Number of rows deleted
	 */
	public function clear_all() {
		global $wpdb;

		// Use TRUNCATE instead of DELETE for much faster performance on large tables
		// TRUNCATE is faster because it doesn't log individual row deletions
		$result = $wpdb->query( 'TRUNCATE TABLE ' . $wpdb->prefix . 'wc_appointments_availability_cache' );

		// Clear cache group since we've deleted all data
		wp_cache_flush_group( self::CACHE_GROUP );

		return (int) $result;
	}

	/**
	 * Total rows in the availability cache table.
	 *
	 * @return int
	 */
	public function count_all_rows(): int {
		global $wpdb;

		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'wc_appointments_availability_cache' );
	}

	/**
	 * Get availability rules for slots calculation with complex filtering.
	 * Optimized version with better query structure and caching.
	 *
	 * @param int   $product_id Product ID
	 * @param int   $start_ts Start timestamp
	 * @param int   $end_ts End timestamp
	 * @param int[] $staff_ids Array of staff IDs to include
	 * @param int   $limit Optional limit for pagination (default: -1 for no limit)
	 * @param int   $offset Optional offset for pagination (default: 0)
	 * @return array<int, array<string, mixed>> Array of rule data
	 */
	public function get_availability_rules_for_slots( $product_id, $start_ts, $end_ts, $staff_ids = [], $limit = -1, $offset = 0 ) {
		global $wpdb;

		// Normalize and validate inputs
		$product_id = wc_appointments_get_product_id_for_availability( (int) $product_id );
		$start_ts   = (int) $start_ts;
		$end_ts     = (int) $end_ts;

		// Extend time range to include overnight rules
		// Query one day before start and one day after end to capture rules that might affect the period
		$extended_start_ts = $start_ts - DAY_IN_SECONDS;
		$extended_end_ts   = $end_ts + DAY_IN_SECONDS;

		if ( empty( $staff_ids ) ) {
			$staff_ids = [ 0 ];
		}
		$staff_ids = array_unique( array_map( 'intval', $staff_ids ) );

		// Validate pagination parameters
		$limit  = (int) $limit;
		$offset = max( 0, (int) $offset );

		// Create cache key for this query (include pagination + layer context)
		$layers      = class_exists( 'WC_Appointment_Slots_Engine', false )
			? WC_Appointment_Slots_Engine::resolve_availability_layer_ids()
			: [ 'location_id' => 0, 'resource_id' => 0 ];
		$location_id = (int) ( $layers['location_id'] ?? 0 );
		$resource_id = (int) ( $layers['resource_id'] ?? 0 );
		$cache_key     = 'avail_rules_' . md5( serialize( [ $product_id, $start_ts, $end_ts, $staff_ids, $limit, $offset, $location_id, $resource_id ] ) );
		$cached_result = wp_cache_get( $cache_key, self::CACHE_GROUP );

		if ( false !== $cached_result ) {
			#error_log( 'Cache hit for availability rules for slots: ' . $cache_key );
			return $cached_result;
		}

		$staff_placeholders = implode( ',', array_fill( 0, count( $staff_ids ), '%d' ) );

		// Optimized query: Use UNION to separate different rule types for better index usage
		$query_parts  = [];
		$query_params = [];

		// 1. Global rules (scope = 'global')
		$query_parts[] = "
			SELECT product_id, staff_id, resource_id, scope, start_ts, end_ts, appointable, qty, priority, ordering
			FROM {$wpdb->prefix}wc_appointments_availability_cache
			WHERE source = 'availability'
			  AND scope = 'global'
			  AND start_ts <= %d
			  AND end_ts >= %d
			  AND staff_id IN ({$staff_placeholders})
		";
		$query_params  = array_merge( $query_params, [ $extended_end_ts, $extended_start_ts ], $staff_ids );

		// 2. Location rules (kind_id stored in product_id)
		if ( $location_id > 0 ) {
			$query_parts[] = "
				SELECT product_id, staff_id, resource_id, scope, start_ts, end_ts, appointable, qty, priority, ordering
				FROM {$wpdb->prefix}wc_appointments_availability_cache
				WHERE source = 'availability'
				  AND scope = 'location'
				  AND product_id = %d
				  AND start_ts <= %d
				  AND end_ts >= %d
			";
			$query_params = array_merge( $query_params, [ $location_id, $extended_end_ts, $extended_start_ts ] );
		}

		// 3. Resource rules (kind_id stored in resource_id)
		if ( $resource_id > 0 ) {
			$query_parts[] = "
				SELECT product_id, staff_id, resource_id, scope, start_ts, end_ts, appointable, qty, priority, ordering
				FROM {$wpdb->prefix}wc_appointments_availability_cache
				WHERE source = 'availability'
				  AND scope = 'resource'
				  AND resource_id = %d
				  AND start_ts <= %d
				  AND end_ts >= %d
			";
			$query_params = array_merge( $query_params, [ $resource_id, $extended_end_ts, $extended_start_ts ] );
		}

		// 4. Product-specific rules (scope = 'product' AND product_id matches)
		$query_parts[] = "
			SELECT product_id, staff_id, resource_id, scope, start_ts, end_ts, appointable, qty, priority, ordering
			FROM {$wpdb->prefix}wc_appointments_availability_cache
			WHERE source = 'availability'
			  AND scope = 'product'
			  AND product_id = %d
			  AND start_ts <= %d
			  AND end_ts >= %d
			  AND staff_id IN ({$staff_placeholders})
		";
		$query_params  = array_merge( $query_params, [ $product_id, $extended_end_ts, $extended_start_ts ], $staff_ids );

		// 5. Staff-specific rules (scope = 'staff')
		$query_parts[] = "
			SELECT product_id, staff_id, resource_id, scope, start_ts, end_ts, appointable, qty, priority, ordering
			FROM {$wpdb->prefix}wc_appointments_availability_cache
			WHERE source = 'availability'
			  AND scope = 'staff'
			  AND start_ts <= %d
			  AND end_ts >= %d
			  AND staff_id IN ({$staff_placeholders})
		";
		$query_params  = array_merge( $query_params, [ $extended_end_ts, $extended_start_ts ], $staff_ids );

		// Combine with UNION and sort so that last-writer-wins in the minute mask
		// produces the correct override: global < product < location < resource < staff.
		$query_params = array_merge( $query_params, [ 'global', 'product', 'location', 'resource', 'staff' ] );

		$final_query = '(' . implode( ') UNION ALL (', $query_parts ) . ') ORDER BY priority DESC, FIELD(scope, %s, %s, %s, %s, %s) ASC, ordering ASC, start_ts DESC';

		if ( 0 < $limit ) {
			$final_query .= $wpdb->prepare( ' LIMIT %d OFFSET %d', $limit, $offset );
		}

		$prepared_query = $wpdb->prepare( $final_query, ...$query_params ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$results = $wpdb->get_results( $prepared_query );

		// Cache the results for 5 minutes
		wp_cache_set( $cache_key, $results, self::CACHE_GROUP, 5 * MINUTE_IN_SECONDS );

		return $results;
	}

	/**
	 * Whether appointable availability rows exist for a product/range (optionally staff-scoped).
	 *
	 * @param int   $product_id Product ID.
	 * @param int   $start_ts   Range start.
	 * @param int   $end_ts     Range end.
	 * @param int[] $staff_ids  When non-empty, require rows for staff 0 and/or these IDs.
	 * @return bool
	 */
	public function has_availability_index_for_range( int $product_id, int $start_ts, int $end_ts, array $staff_ids = [] ): bool {
		global $wpdb;

		$requested_product_id = $product_id;
		$product_id           = wc_appointments_get_product_id_for_availability( $product_id );

		if ( 0 >= $product_id || 0 >= $start_ts || 0 >= $end_ts ) {
			return false;
		}

		$staff_ids = array_values( array_unique( array_map( 'intval', $staff_ids ) ) );
		$staff_sql = '';
		$params    = [ $end_ts, $start_ts, $product_id ];

		if ( ! empty( $staff_ids ) ) {
			$staff_filter       = array_values( array_unique( array_merge( [ 0 ], $staff_ids ) ) );
			$staff_placeholders = implode( ',', array_fill( 0, count( $staff_filter ), '%d' ) );
			$staff_sql          = " AND staff_id IN ({$staff_placeholders})";
			$params             = array_merge( $params, $staff_filter );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN list; IDs int-cast.
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}wc_appointments_availability_cache
				WHERE source = 'availability'
				AND appointable = 'yes'
				AND start_ts <= %d
				AND end_ts >= %d
				AND ( product_id = %d OR product_id = 0 OR scope = 'global' )
				AND NOT ( scope = 'product' AND product_id = 0 )
				AND NOT ( scope = 'staff' AND staff_id = 0 )
				{$staff_sql}",
				$params
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders

		if ( 0 >= $count ) {
			return false;
		}

		if ( empty( $staff_ids ) ) {
			return true;
		}

		// A shared product/global row does not prove staff rules were indexed.
		// Skip expired rules (indexer never expands them; daily cleanup appends :expired).
		// Treat a rule as indexed if it has any staff-scoped cache rows. Requiring rows
		// inside the requested window falsely fails month/weekday rules that correctly
		// produce no rows in that window (e.g. months 7-8 when asking for September).
		$staff_placeholders = implode( ',', array_fill( 0, count( $staff_ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN list; IDs int-cast.
		$missing_staff_rule = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT availability.ID
				FROM {$wpdb->prefix}wc_appointments_availability AS availability
				WHERE availability.kind = 'availability#staff'
				AND availability.kind_id IN ({$staff_placeholders})
				AND availability.range_type NOT LIKE %s
				AND NOT EXISTS (
					SELECT 1
					FROM {$wpdb->prefix}wc_appointments_availability_cache AS cache
					WHERE cache.source = 'availability'
					AND cache.scope = 'staff'
					AND cache.source_id = availability.ID
				)
				LIMIT 1",
				array_merge( $staff_ids, [ '%:expired' ] )
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders

		return null === $missing_staff_rule;
	}

	/**
	 * Get cached appointment rows for availability calculation.
	 *
	 * @param int   $product_id Product ID
	 * @param int   $start_ts Start timestamp
	 * @param int   $end_ts End timestamp
	 * @param int[] $staff_ids Array of staff IDs
	 * @return array<int, array<string, mixed>> Array of appointment data
	 */
	public function get_cached_appointments_for_availability( $product_id, $start_ts, $end_ts, $staff_ids = [] ) {
		$filters = [
			'source'       => 'appointment',
			'product_id'   => (int) $product_id,
			'time_between' => [
				'start_ts' => (int) $start_ts,
				'end_ts'   => (int) $end_ts,
			],
			'order_by'     => 'start_ts',
			'order'        => 'ASC',
		];

		if ( ! empty( $staff_ids ) ) {
			$filters['staff_id'] = array_map( 'intval', $staff_ids );
		}

		return $this->get_items( $filters );
	}
}
