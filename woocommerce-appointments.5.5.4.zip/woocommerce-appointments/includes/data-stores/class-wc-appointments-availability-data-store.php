<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Appointments_Availability_Data_Store
 *
 * @package Woocommerce/Appointments
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC Availability Data Store: Stored in Custom table.
 * @todo When 2.6 support is dropped, implement WC_Object_Data_Store_Interface
 */
class WC_Appointments_Availability_Data_Store extends WC_Data_Store_WP {

	public const TABLE_NAME       = 'wc_appointments_availability';
	public const CACHE_GROUP      = 'wc-appointments-availability';
	public const DEFAULT_MIN_DATE = '0000-00-00';
	public const DEFAULT_MAX_DATE = '9999-99-99';

	/** @var string[] Allowlisted filter column names for build_query(). */
	private const FILTER_COLUMNS = [
		'ID', 'kind', 'kind_id', 'event_id', 'parent_event_id', 'title', 'range_type',
		'from_date', 'to_date', 'from_range', 'to_range', 'rrule', 'appointable',
		'priority', 'qty', 'ordering', 'date_created', 'date_modified',
	];

	/**
	 * Create a new availability in the database.
	 *
	 * @param WC_Appointments_Availability $availability WC_Appointments_Availability instance.
	 */
	public function create( &$availability ): void {
		global $wpdb;

		$availability->apply_changes();

		$data = [
			'kind'                  => $availability->get_kind( 'edit' ),
			'kind_id'               => $availability->get_kind_id( 'edit' ),
			'event_id'              => $availability->get_event_id( 'edit' ),
			'parent_event_id'       => $availability->get_parent_event_id( 'edit' ),
			'title'                 => $availability->get_title( 'edit' ),
			'range_type'            => $availability->get_range_type( 'edit' ),
			'from_date'             => $availability->get_from_date( 'edit' ),
			'to_date'               => $availability->get_to_date( 'edit' ),
			'from_range'            => $availability->get_from_range( 'edit' ),
			'to_range'              => $availability->get_to_range( 'edit' ),
			'appointable'           => $availability->get_appointable( 'edit' ),
			'priority'              => $availability->get_priority( 'edit' ),
			'qty'                   => $availability->get_qty( 'edit' ),
			'ordering'              => $availability->get_ordering( 'edit' ),
			'rrule'                 => $availability->get_rrule( 'edit' ),
			'date_created'          => current_time( 'mysql' ),
			'date_modified'         => current_time( 'mysql' ),
		];

		$wpdb->insert( $wpdb->prefix . self::TABLE_NAME, $data );
		$availability->set_id( $wpdb->insert_id );
		WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );
		WC_Appointments_Cache::delete_appointment_slots_transient();

		// Fire a create event for webhooks: `availability.created`.
		do_action( 'woocommerce_appointments_availability_created', (int) $availability->get_id(), $availability, $this );

		// Notify listeners (e.g., availability cache indexer) that a rule was saved.
		// This enables immediate re-indexing of the rule in the cache table.
		do_action( 'woocommerce_after_appointments_availability_object_save', $availability, $this );
	}

	/**
	 * Read availability from the database.
	 *
	 * @param  WC_Appointments_Availability $availability Instance.
	 * @throws Exception When webhook is invalid.
	 */
	public function read( &$availability ): void {
		$data = wp_cache_get( $availability->get_id(), self::CACHE_GROUP );

		if ( false === $data ) {
			global $wpdb;

			$table = $wpdb->prefix . self::TABLE_NAME;
			// phpcs:disable WordPress.DB.PreparedSQL -- Table name from wpdb->prefix constant.
			$sql  = $wpdb->prepare(
				"SELECT ID as id, kind, kind_id, event_id, parent_event_id, title, range_type, from_date, to_date, from_range, to_range, appointable, priority, qty, ordering, date_created, date_modified, rrule FROM {$table} WHERE ID = %d LIMIT 1",
				$availability->get_id()
			);
			$data = $wpdb->get_row( $sql, ARRAY_A );
			// phpcs:enable WordPress.DB.PreparedSQL

			if ( empty( $data ) ) {
				throw new Exception( __( 'Invalid event.', 'woocommerce-appointments' ) );
			}

			wp_cache_add( $availability->get_id(), $data, self::CACHE_GROUP );
		}

		if ( is_array( $data ) ) {
			$availability->set_props( $data );
			$availability->set_object_read( true );
		}
	}

	/**
	 * Update a webhook.
	 *
	 * @param WC_Appointments_Availability $availability Instance.
	 */
	public function update( &$availability ): void {
		global $wpdb;

		$changes = $availability->get_changes();

		$changes['date_modified'] = current_time( 'mysql' );

		$wpdb->update(
		    $wpdb->prefix . self::TABLE_NAME,
		    $changes,
		    [
				'ID' => $availability->get_id(),
			],
		);

		$availability->apply_changes();

		wp_cache_delete( $availability->get_id(), self::CACHE_GROUP );
		WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );
		WC_Appointments_Cache::delete_appointment_slots_transient();

		// Fire an update event for webhooks: `availability.updated`.
		do_action( 'woocommerce_appointments_availability_updated', (int) $availability->get_id(), $availability, $changes, $this );

		// Notify listeners (e.g., availability cache indexer) that a rule was saved.
		// This enables immediate re-indexing of the updated rule in the cache table.
		do_action( 'woocommerce_after_appointments_availability_object_save', $availability, $this );
	}

	/**
	 * Remove a webhook from the database.
	 *
	 * @param WC_Appointments_Availability $availability Instance.
	 */
	public function delete( &$availability ): void {
		global $wpdb;

		do_action( 'woocommerce_appointments_before_delete_appointment_availability', $availability, $this ); // WC_Data::delete does not trigger an action like save() so we have to do it here.

		$wpdb->delete(
		    $wpdb->prefix . self::TABLE_NAME,
		    [
				'ID' => $availability->get_id(),
			],
		    [ '%d' ],
		);
		wp_cache_delete( $availability->get_id(), self::CACHE_GROUP );
		WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );
		WC_Appointments_Cache::delete_appointment_slots_transient();

		// Also delete any indexed cache rows tied to this availability rule directly,
		// so we don't rely solely on hooks to keep the index in sync.
		if ( class_exists( 'WC_Appointments_Availability_Cache_Data_Store' ) ) {
			try {
				$data_store = new \WC_Appointments_Availability_Cache_Data_Store();
				$data_store->delete_by_source( 'availability', (int) $availability->get_id() );
			} catch ( \Exception $e ) {
				// Silently ignore; hook below will handle listeners.
			}
		}

		// Notify listeners (e.g., availability cache indexer) that a rule was deleted.
		// Pass the ID to match listener expectations.
		do_action( 'woocommerce_after_appointments_availability_object_delete', (int) $availability->get_id() );
	}

	/**
	 * Get all availabilties defined in the database as objetcs.
	 *
	 * @param array<int, array<string, mixed>> $filters { @see self::build_query() }.
	 * @param string                           $min_date { @see self::build_query() }.
	 * @param string                           $max_date { @see self::build_query() }.
	 *
	 * @return WC_Appointments_Availability[]
	 * @throws Exception Validation fails.
	 */
	public function get_all( $filters = [], $min_date = self::DEFAULT_MIN_DATE, $max_date = self::DEFAULT_MAX_DATE ) {

		$data = $this->get_all_as_array( $filters, $min_date, $max_date );

		$availabilities = [];
		foreach ( $data as $row ) {
			$availability = get_wc_appointments_availability();
			$availability->set_object_read( false );
			$availability->set_props( $row );
			$availability->set_object_read( true );
			$availabilities[] = $availability;
		}

		return apply_filters( 'woocommerce_appointments_get_all_availabilities', $availabilities );
	}

	/**
	 * Get all availabilties defined in the database as objetcs.
	 *
	 * Returns all availability rule IDs.
	 *
	 * @return array<int, int> Rule IDs.
	 * @throws Exception Validation fails.
	 */
	public function get_all_availability_rule_ids() {
		global $wpdb;
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT ID FROM ' . $wpdb->prefix . 'wc_appointments_availability WHERE range_type NOT LIKE %s',
				'%:expired'
			)
		);
		if ( empty( $ids ) ) {
			return [];
		}
		return array_map( 'intval', $ids );
	}

	/**
	 * All availability rule IDs for manual re-index (includes expired rules, stable order).
	 *
	 * @return int[]
	 */
	public function get_all_availability_rule_ids_for_reindex() {
		global $wpdb;
		$ids = $wpdb->get_col(
			'SELECT ID FROM ' . $wpdb->prefix . 'wc_appointments_availability ORDER BY ID ASC'
		);
		if ( empty( $ids ) ) {
			return [];
		}
		return array_map( 'intval', $ids );
	}

	/**
	 * Get global availability as array.
	 *
	 * @param array<int, array<string, mixed>> $filters { @see self::build_query() }.
	 * @param string                           $min_date { @see self::build_query() }.
	 * @param string                           $max_date { @see self::build_query() }.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public function get_all_as_array( $filters = [], $min_date = self::DEFAULT_MIN_DATE, $max_date = self::DEFAULT_MAX_DATE ) {
		if ( ! is_array( $filters ) ) {
			$filters = []; // WC_Data_Store uses call_user_func_array to call this function so the default parameter is not used.
		}

		$sql = $this->build_query( $filters, $min_date, $max_date );

		$cache_key = WC_Cache_Helper::get_cache_prefix( self::CACHE_GROUP ) . 'get_all:' . md5( $sql );
		$array     = wp_cache_get( $cache_key, self::CACHE_GROUP );

		#echo '<pre>' . var_export( $array, true ) . '</pre>';

		if ( false === $array ) {
			global $wpdb;

			$array = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Dynamic query from build_query(); values escaped in builder.

			foreach ( $array as &$row ) {
				/*
				 * Simplify and set BC keys to use later in functions.
				 *
				 * 'range_type' is now 'type'
				 * 'to_range' is now 'to'
				 * 'from_range' is now 'from'
				 * 'ID' is now 'id'
				 */
				$row['id']   = (int) $row['ID'];
				$row['type'] = $row['range_type'];
				$row['to']   = $row['to_range'];
				$row['from'] = $row['from_range'];
			}

			wp_cache_add( $cache_key, $array, self::CACHE_GROUP );
		}

		return $array;
	}

	/**
	 * Builds query string for availability.
	 *
	 * @param array<int, array<string, mixed>> $filters Filter rows with key/compare/value.
	 * @param string                           $min_date Minimum date to select intersecting availability entries for (yyyy-mm-dd format).
	 * @param string                           $max_date Maximum date to select intersecting availability entries for (yyyy-mm-dd format).
	 */
	private function build_query( array $filters, $min_date, $max_date ): string {
		global $wpdb;

		/*
		 * Build list of fields with virtual fields 'start_date' and 'end_date'.
		 * 'start_date' shall be '0000-00-00' for recurring events.
		 * 'end_date' shall be '9999-99-99' for recurring events.
		 */
		$fields = [
			'ID',
			'kind',
			'kind_id',
			'event_id',
			'parent_event_id',
			'title',
			'range_type',
			'from_date',
			'to_date',
			'from_range',
			'to_range',
			'rrule',
			'appointable',
			'priority',
			'qty',
			'ordering',
			'date_created',
			'date_modified',
			'(CASE
				WHEN range_type = \'custom\' THEN from_range
				WHEN range_type = \'time:range\' THEN from_date
				WHEN range_type = \'custom:daterange\' THEN from_date
				WHEN range_type = \'store_availability\' THEN from_date
				ELSE \'0000-00-00\'
			END) AS start_date',
			'(CASE
				WHEN range_type = \'custom\' THEN to_range
				WHEN range_type = \'time:range\' THEN to_date
				WHEN range_type = \'custom:daterange\' THEN to_date
				WHEN range_type = \'store_availability\' THEN to_date
				ELSE \'9999-99-99\'
			END) AS end_date',
		];

		$table = $wpdb->prefix . self::TABLE_NAME;

		// Real-column predicates belong on the base table so indexes (event_id, kind+kind_id) apply.
		$base_where = [ "(range_type NOT LIKE '%:expired')" ];

		foreach ( $filters as $filter ) {
			$raw_key = $filter['key'] ?? '';
			$col     = is_string( $raw_key ) && '' !== $raw_key
				? ( 'id' === strtolower( $raw_key ) ? 'ID' : $raw_key )
				: '';
			if ( ! in_array( $col, self::FILTER_COLUMNS, true ) ) {
				continue;
			}

			$compare = $this->validate_compare( $filter['compare'] ?? '=' );

			switch ( $compare ) {
				case 'IN':
				case 'NOT IN':
					$value        = implode( "','", array_map( 'esc_sql', $filter['value'] ) );
					$base_where[] = "`{$col}` {$compare} ('{$value}')";
					break;
				case 'BETWEEN':
				case 'NOT BETWEEN':
					$value        = implode( "' AND '", array_map( 'esc_sql', $filter['value'] ) );
					$base_where[] = "(`{$col}` {$compare} '{$value}')";
					break;
				default:
					$value        = esc_sql( $filter['value'] );
					$base_where[] = "`{$col}` {$compare} '{$value}'";
					break;
			}
		}

		sort( $base_where );

		$fields_sql = implode( ', ', $fields );
		$base_sql   = implode( ' AND ', $base_where );

		// Date intersection uses virtual start_date/end_date — derived table only when needed.
		if ( self::DEFAULT_MIN_DATE === $min_date && self::DEFAULT_MAX_DATE === $max_date ) {
			return sprintf(
				'SELECT %s FROM %s WHERE %s ORDER BY ordering ASC',
				$fields_sql,
				$table,
				$base_sql
			);
		}

		$min_max_dates       = [
			esc_sql( $min_date ),
			esc_sql( $max_date ),
		];
		$date_intersect_or   = [];
		$date_intersect_or[] = vsprintf( "( start_date BETWEEN '%s' AND '%s' )", $min_max_dates );
		$date_intersect_or[] = vsprintf( "( end_date BETWEEN '%s' AND '%s' )", $min_max_dates );
		$date_intersect_or[] = vsprintf( "( start_date <= '%s' AND end_date >= '%s' )", $min_max_dates );
		$outer_where         = sprintf( '( %s )', implode( ' OR ', $date_intersect_or ) );

		return sprintf(
			'SELECT * FROM ( SELECT %s FROM %s WHERE %s ) AS a_data WHERE %s ORDER BY ordering ASC',
			$fields_sql,
			$table,
			$base_sql,
			$outer_where
		);
	}

	/**
	 * Validates query filter comparison (defaults to '=')
	 *
	 * @param string $compare Raw compare string.
	 * @return string Validated compare string.
	 */
	private function validate_compare( $compare ): string {

		$compare = strtoupper( $compare );

		if (! in_array(
		    $compare,
		    [
				'=',
				'!=',
				'>',
				'>=',
				'<',
				'<=',
				'LIKE',
				'NOT LIKE',
				'IN',
				'NOT IN',
				'BETWEEN',
				'NOT BETWEEN',
			],
		)) {
            return '=';
        }

		return $compare;
	}

	/**
	 * Return all appointments and blocked availability for a product and/or staff in a given range.
	 *
	 * @since 4.4.0
	 *
	 * @param integer              $start_date
	 * @param integer              $end_date
	 * @param integer              $product_id
	 * @param integer              $staff_id
	 * @param bool                 $check_in_cart
	 * @param array<string, mixed> $filters Optional query args merged via wp_parse_args into appointment range query (see WC_Appointment_Data_Store::get_appointments_in_date_range_query()).
	 *
	 * @return array<int, WC_Appointment|WC_Appointments_Availability> Appointments and Availabilities (merged in one array)
	 */
	public static function get_events_in_date_range( $start_date, $end_date, $product_id = 0, $staff_id = 0, $check_in_cart = true, $filters = [] ) {
		$appointments = WC_Appointment_Data_Store::get_appointments_in_date_range( $start_date, $end_date, $product_id, $staff_id, $check_in_cart, $filters, true );
		$min_date     = date( 'Y-m-d', $start_date );
		$max_date     = date( 'Y-m-d', $end_date );

		// Filter only for events synced from Google Calendar.
		$availability_filters = [
			[
				'key'     => 'kind',
				'compare' => '=',
				'value'   => 'availability#global',
			],
			[
				'key'     => 'event_id',
				'compare' => '!=',
				'value'   => '',
			],
		];

		$global_availabilities = WC_Data_Store::load( 'appointments-availability' )->get_all( $availability_filters, $min_date, $max_date );

		return array_merge( $appointments, $global_availabilities );
	}

	/**
	 * Return an array global_availability_rules
	 *
	 * @since 4.4.0
	 *
	 * @param  int  $start_date
	 * @param  int  $end_date
	 *
	 * @return WC_Appointments_Availability[] Global availability rules
	 */
	public static function get_global_availability_in_date_range( $start_date, $end_date ) {
		// Filter only for events from Global availability.
		$filters = [
			[
				'key'     => 'kind',
				'compare' => '=',
				'value'   => 'availability#global',
			],
			[
				'key'     => 'event_id',
				'compare' => '==',
				'value'   => '',
			],
		];

		$min_date = date( 'Y-m-d', $start_date );
		$max_date = date( 'Y-m-d', $end_date );

		return WC_Data_Store::load( 'appointments-availability' )->get_all( $filters, $min_date, $max_date );
	}

	/**
	 * Get global availability rules.
	 *
	 * @param  bool $with_gcal
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_global_availability( $with_gcal = true ) {
		if ( $with_gcal ) {
			$global_rules = WC_Data_Store::load( 'appointments-availability' )->get_all_as_array(
			    [
					[
						'key'     => 'kind',
						'compare' => 'IN',
						'value'   => [ 'availability#global' ],
					],
				],
			);
		} else {
			$global_rules = WC_Data_Store::load( 'appointments-availability' )->get_all_as_array(
			    [
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => 'availability#global',
					],
					[
						'key'     => 'event_id',
						'compare' => '==',
						'value'   => '',
					],
				],
			);
		}

		return apply_filters( 'wc_appointments_global_availability', $global_rules );
	}

	/**
	 * Get staff availability rules.
	 *
	 * @param  int|int[] $staff_ids
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_staff_availability( $staff_ids = [] ) {
		if ( is_int( $staff_ids ) && $staff_ids ) {
			$staff_rules = WC_Data_Store::load( 'appointments-availability' )->get_all_as_array(
			    [
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => 'availability#staff',
					],
					[
						'key'     => 'kind_id',
						'compare' => '=',
						'value'   => $staff_ids,
					],
				],
			);
		} elseif ( [] !== $staff_ids ) {
			$staff_rules = WC_Data_Store::load( 'appointments-availability' )->get_all_as_array(
			    [
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => 'availability#staff',
					],
					[
						'key'     => 'kind_id',
						'compare' => 'IN',
						'value'   => $staff_ids,
					],
				],
			);
		} else {
			$staff_rules = WC_Data_Store::load( 'appointments-availability' )->get_all_as_array(
			    [
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => 'availability#staff',
					],
				],
			);
		}

		return apply_filters( 'wc_appointments_all_staff_availability', $staff_rules );
	}

	/**
	 * Get location availability rules.
	 *
	 * @param int|int[] $location_ids Location post ID(s). Empty = all location rules.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_location_availability( $location_ids = [] ) {
		return self::get_availability_for_kind( WC_Appointments_Availability::KIND_LOCATION, $location_ids, 'wc_appointments_all_location_availability' );
	}

	/**
	 * Get resource availability rules.
	 *
	 * @param int|int[] $resource_ids Resource post ID(s). Empty = all resource rules.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_resource_availability( $resource_ids = [] ) {
		return self::get_availability_for_kind( WC_Appointments_Availability::KIND_RESOURCE, $resource_ids, 'wc_appointments_all_resource_availability' );
	}

	/**
	 * Load availability rows for a kind, optionally filtered by kind_id.
	 *
	 * @param string    $kind        Kind constant (e.g. KIND_LOCATION).
	 * @param int|int[] $kind_ids    Kind ID(s). Empty array = all rows for kind.
	 * @param string    $filter_hook Filter applied to the result list.
	 * @return array<int, array<string, mixed>>
	 */
	private static function get_availability_for_kind( string $kind, $kind_ids, string $filter_hook ): array {
		$store = WC_Data_Store::load( 'appointments-availability' );

		if ( is_int( $kind_ids ) ) {
			if ( $kind_ids <= 0 ) {
				return apply_filters( $filter_hook, [] );
			}
			$rules = $store->get_all_as_array(
				[
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => $kind,
					],
					[
						'key'     => 'kind_id',
						'compare' => '=',
						'value'   => $kind_ids,
					],
				]
			);
		} elseif ( is_array( $kind_ids ) && [] !== $kind_ids ) {
			$rules = $store->get_all_as_array(
				[
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => $kind,
					],
					[
						'key'     => 'kind_id',
						'compare' => 'IN',
						'value'   => $kind_ids,
					],
				]
			);
		} else {
			$rules = $store->get_all_as_array(
				[
					[
						'key'     => 'kind',
						'compare' => '=',
						'value'   => $kind,
					],
				]
			);
		}

		return apply_filters( $filter_hook, $rules );
	}

	/**
	 * Decode availability rules from JSON, with robust unslash fallbacks.
	 *
	 * @param string $json Raw JSON string from POST.
	 * @return array<int, array<string, mixed>> Array of rule objects, or empty array.
	 */
	public function decode_rules_json( $json ) {
		if ( ! is_string( $json ) || '' === $json ) {
			return [];
		}

		$decoded = json_decode( $json, true );
		if ( is_array( $decoded ) ) {
			return $decoded;
		}

		// Legacy callers may pass a slashed payload straight from $_POST.
		// wp_unslash() on a string is stripslashes(), so a third stripslashes()
		// pass would only corrupt legitimate lone backslashes (e.g. Windows paths).
		$decoded = json_decode( wp_unslash( $json ), true );

		return is_array( $decoded ) ? $decoded : [];
	}

	/**
	 * Apply a single normalized JSON rule to an availability object.
	 *
	 * Does not set kind/kind_id; caller should set those contextually.
	 *
	 * @param WC_Appointments_Availability $availability Availability object to mutate.
	 * @param array<string, mixed>         $rule Normalized rule array.
	 */
	public function apply_json_rule_to_availability( &$availability, $rule ): void {
		if ( isset( $rule['appointable'] ) ) {
			$availability->set_appointable( wc_string_to_bool( $rule['appointable'] ) ? 'yes' : 'no' );
		}
		if ( isset( $rule['title'] ) ) {
			$availability->set_title( sanitize_text_field( $rule['title'] ) );
		}
		// Cleared inventory omits qty from JSON; always set so updates do not keep a stale value.
		if ( isset( $rule['qty'] ) && '' !== $rule['qty'] ) {
			$availability->set_qty( intval( $rule['qty'] ) );
		} else {
			$availability->set_qty( 0 );
		}
		if ( array_key_exists( 'priority', $rule ) ) {
			$availability->set_priority( $rule['priority'] );
		}
		if ( isset( $rule['event_id'] ) ) {
			$availability->set_event_id( sanitize_text_field( $rule['event_id'] ) );
		}
        $range_type = isset( $rule['type'] ) ? wc_clean( $rule['type'] ) : $availability->get_range_type( 'edit' );

		// GET aliases (from/to) and REST range_type; normalize before switch.
		if ( ! isset( $rule['from_range'] ) && isset( $rule['from'] ) ) {
			$rule['from_range'] = $rule['from'];
		}
		if ( ! isset( $rule['to_range'] ) && isset( $rule['to'] ) ) {
			$rule['to_range'] = $rule['to'];
		}
		if ( ! isset( $rule['type'] ) && isset( $rule['range_type'] ) ) {
			$range_type = wc_clean( $rule['range_type'] );
		}

		switch ( $range_type ) {
			case 'custom':
				if ( isset( $rule['from_date'], $rule['to_date'] ) ) {
					$availability->set_from_range( wc_clean( $rule['from_date'] ) );
					$availability->set_to_range( wc_clean( $rule['to_date'] ) );
				}
				break;
			case 'months':
			case 'weeks':
			case 'days':
				if ( isset( $rule['from_range'], $rule['to_range'] ) ) {
					$availability->set_from_range( wc_clean( $rule['from_range'] ) );
					$availability->set_to_range( wc_clean( $rule['to_range'] ) );
				}
				break;
			case 'rrule':
				// Read-only; skip.
				break;
			case 'time':
			case 'time:1':
			case 'time:2':
			case 'time:3':
			case 'time:4':
			case 'time:5':
			case 'time:6':
			case 'time:7':
				if ( isset( $rule['from_range'], $rule['to_range'] ) ) {
					$availability->set_from_range( wc_appointment_sanitize_time( $rule['from_range'] ) );
					$availability->set_to_range( wc_appointment_sanitize_time( $rule['to_range'] ) );
				}
				break;
			case 'time:range':
			case 'custom:daterange':
				if ( isset( $rule['from_range'], $rule['to_range'] ) ) {
					$availability->set_from_range( wc_appointment_sanitize_time( $rule['from_range'] ) );
					$availability->set_to_range( wc_appointment_sanitize_time( $rule['to_range'] ) );
				}
				if ( isset( $rule['from_date'], $rule['to_date'] ) ) {
					$availability->set_from_date( wc_clean( $rule['from_date'] ) );
					$availability->set_to_date( wc_clean( $rule['to_date'] ) );
				}
				break;
		}

		$this->clear_date_columns_unless_used_by_range_type( $availability, $range_type );
	}

	/**
	 * Clear from_date/to_date when the range type does not use those DB columns.
	 *
	 * WC_Data::save() only persists changed props; leaving stale dates after a type
	 * change would keep old values in the database and break cache indexing windows.
	 *
	 * @param WC_Appointments_Availability $availability Rule being saved.
	 * @param string                       $range_type Normalized range type (same as rule type).
	 */
	private function clear_date_columns_unless_used_by_range_type( WC_Appointments_Availability $availability, $range_type ): void {
		if ( '' === $range_type ) {
			return;
		}
		// These types persist calendar bounds in from_date / to_date.
		if ( 'time:range' === $range_type || 'custom:daterange' === $range_type || 'store_availability' === $range_type ) {
			return;
		}
		$availability->set_from_date( '' );
		$availability->set_to_date( '' );
	}

	/**
	 * Decode availability rules from a POST payload (caller must verify save context / capability).
	 *
	 * @param array<string, mixed> $posted Unslashed POST fields (typically `wp_unslash( $_POST )` from admin save hooks).
	 * @return array<int, array<string, mixed>> Array of normalized rule arrays
	 */
	public function decode_rules_from_post( array $posted ) {
		$rules = [];
		$json  = isset( $posted['wc_appointment_availability_json'] ) ? $posted['wc_appointment_availability_json'] : '';
		if ( is_string( $json ) && '' !== $json ) {
			$rules = $this->decode_rules_json( $json );
			if ( ! empty( $rules ) ) {
				return $rules;
			}
		}

		return $this->decode_legacy_rules_from_post( $posted );
	}

	/**
	 * Check if a rule array is valid.
	 *
	 * Validates a rule array against required fields based on its type.
	 *
	 * @param array<string, mixed> $rule Rule data.
	 * @return bool                True if valid.
	 */
	public function is_rule_valid( $rule ) {
		if ( empty( $rule ) || ! is_array( $rule ) ) {
			return false;
		}
		$type = $rule['type'] ?? $rule['range_type'] ?? '';
		if ( '' === $type ) {
			return false;
		}
		$from_range = $rule['from_range'] ?? $rule['from'] ?? '';
		$to_range   = $rule['to_range'] ?? $rule['to'] ?? '';
		switch ( $type ) {
			case 'custom':
				return ! empty( $rule['from_date'] ) && ! empty( $rule['to_date'] );
			case 'months':
			case 'weeks':
			case 'days':
			case 'time':
			case 'time:1':
			case 'time:2':
			case 'time:3':
			case 'time:4':
			case 'time:5':
			case 'time:6':
			case 'time:7':
			case 'time:range':
				return '' !== $from_range && '' !== $to_range;
			case 'custom:daterange':
				return '' !== $from_range && '' !== $to_range && ! empty( $rule['from_date'] ) && ! empty( $rule['to_date'] );
			case 'rrule':
				return ! empty( $rule['rrule'] );
			default:
				return false;
		}
	}

	/**
	 * Persist an array of normalized rule arrays for a given kind/kind_id.
	 *
	 * Handles create, update, ordering, and deletion of removed rules.
	 *
	 * @param array<int, array<string, mixed>> $rules      Validated rule arrays (caller should filter via is_rule_valid first).
	 * @param string                           $kind       e.g. KIND_PRODUCT, KIND_GLOBAL, KIND_STAFF, KIND_LOCATION, KIND_RESOURCE.
	 * @param int                              $kind_id    Entity ID for the kind, or 0 for global.
	 * @param int[]                            $delete_ids Rule IDs to delete (from admin UI hidden field).
	 * @return int[] Saved availability rule IDs.
	 */
	public function save_rules( array $rules, string $kind, int $kind_id = 0, array $delete_ids = [] ): array {
		$saved_ids = [];

		foreach ( $delete_ids as $delete_id ) {
			$obj = get_wc_appointments_availability( absint( $delete_id ) );
			if ( $obj ) {
				$obj->delete();
			}
		}

		foreach ( $rules as $i => $rule ) {
			$current_id = empty( $rule['id'] ) ? 0 : intval( $rule['id'] );
			$range_type = empty( $rule['type'] ) ? '' : wc_clean( $rule['type'] );

			$availability = get_wc_appointments_availability( $current_id );
			$availability->set_ordering( intval( $i ) );
			$availability->set_range_type( $range_type );
			$availability->set_kind( $kind );
			if ( $kind_id ) {
				$availability->set_kind_id( $kind_id );
			}

			$this->apply_json_rule_to_availability( $availability, $rule );
			$availability->save();

			$id = (int) $availability->get_id();
			if ( $id > 0 ) {
				$saved_ids[] = $id;
			}

		}

		return $saved_ids;
	}

	/**
	 * Delete all availability rules for a kind + kind_id (orphans on entity delete).
	 *
	 * @since 5.5.0
	 *
	 * @param string $kind    Kind constant.
	 * @param int    $kind_id Entity ID.
	 * @return int Number of rules deleted.
	 */
	public function delete_rules_for_kind( string $kind, int $kind_id ): int {
		if ( '' === $kind || ( WC_Appointments_Availability::KIND_GLOBAL !== $kind && $kind_id <= 0 ) ) {
			return 0;
		}
		$filters = [
			[
				'key'     => 'kind',
				'compare' => '=',
				'value'   => $kind,
			],
		];
		if ( WC_Appointments_Availability::KIND_GLOBAL !== $kind ) {
			$filters[] = [
				'key'     => 'kind_id',
				'compare' => '=',
				'value'   => $kind_id,
			];
		}
		$rows  = $this->get_all_as_array( $filters );
		$count = 0;
		foreach ( (array) $rows as $row ) {
			$id = absint( $row['id'] ?? $row['ID'] ?? 0 );
			if ( ! $id ) {
				continue;
			}
			$obj = get_wc_appointments_availability( $id );
			if ( $obj ) {
				$obj->delete();
				$count++;
			}
		}
		return $count;
	}

	/**
	 * Parse deleted availability IDs from a POST payload.
	 *
	 * @param array<string, mixed> $posted Unslashed POST fields.
	 * @return int[]
	 */
	public function parse_deleted_ids_from_post( array $posted ): array {
		if ( empty( $posted['wc_appointment_availability_deleted'] ) ) {
			return [];
		}
		return array_filter( array_map( 'absint', explode( ',', wc_clean( (string) $posted['wc_appointment_availability_deleted'] ) ) ) );
	}

	/**
	 * Build normalized rules from legacy availability POST arrays.
	 *
	 * @param array<string, mixed> $posted Unslashed POST fields.
	 * @return array<int, array<string, mixed>> Array of normalized rule arrays
	 */
	protected function decode_legacy_rules_from_post( array $posted ) {
		$types    = isset( $posted['wc_appointment_availability_type'] ) ? $posted['wc_appointment_availability_type'] : [];
		$row_size = is_array( $types ) ? count( $types ) : 0;
		$rules    = [];

		for ( $i = 0; $i < $row_size; $i++ ) {
			$rule = [];
			$rule['type'] = isset( $types[ $i ] ) ? wc_clean( $types[ $i ] ) : '';
			// ID
			if ( isset( $posted['wc_appointment_availability_id'][ $i ] ) ) {
				$rule['id'] = absint( $posted['wc_appointment_availability_id'][ $i ] );
			}
			// Common fields
			if ( isset( $posted['wc_appointment_availability_appointable'][ $i ] ) ) {
				$rule['appointable'] = wc_clean( $posted['wc_appointment_availability_appointable'][ $i ] );
			}
			if ( isset( $posted['wc_appointment_availability_title'][ $i ] ) ) {
				$rule['title'] = sanitize_text_field( $posted['wc_appointment_availability_title'][ $i ] );
			}
			if ( isset( $posted['wc_appointment_availability_qty'][ $i ] ) ) {
				$rule['qty'] = absint( $posted['wc_appointment_availability_qty'][ $i ] );
			}
			if ( isset( $posted['wc_appointment_availability_priority'][ $i ] ) ) {
				$rule['priority'] = $posted['wc_appointment_availability_priority'][ $i ];
			}

			// Range-specific mapping
			switch ( $rule['type'] ) {
				case 'custom':
					if ( isset( $posted['wc_appointment_availability_from_date'][ $i ] ) && isset( $posted['wc_appointment_availability_to_date'][ $i ] ) ) {
						$rule['from_date'] = wc_clean( $posted['wc_appointment_availability_from_date'][ $i ] );
						$rule['to_date']   = wc_clean( $posted['wc_appointment_availability_to_date'][ $i ] );
					}
					break;
				case 'months':
					if ( isset( $posted['wc_appointment_availability_from_month'][ $i ] ) && isset( $posted['wc_appointment_availability_to_month'][ $i ] ) ) {
						$rule['from_range'] = wc_clean( $posted['wc_appointment_availability_from_month'][ $i ] );
						$rule['to_range']   = wc_clean( $posted['wc_appointment_availability_to_month'][ $i ] );
					}
					break;
				case 'weeks':
					if ( isset( $posted['wc_appointment_availability_from_week'][ $i ] ) && isset( $posted['wc_appointment_availability_to_week'][ $i ] ) ) {
						$rule['from_range'] = wc_clean( $posted['wc_appointment_availability_from_week'][ $i ] );
						$rule['to_range']   = wc_clean( $posted['wc_appointment_availability_to_week'][ $i ] );
					}
					break;
				case 'days':
					if ( isset( $posted['wc_appointment_availability_from_day_of_week'][ $i ] ) && isset( $posted['wc_appointment_availability_to_day_of_week'][ $i ] ) ) {
						$rule['from_range'] = wc_clean( $posted['wc_appointment_availability_from_day_of_week'][ $i ] );
						$rule['to_range']   = wc_clean( $posted['wc_appointment_availability_to_day_of_week'][ $i ] );
					}
					break;
				case 'rrule':
					// Read-only; skip mapping.
					break;
				case 'time':
				case 'time:1':
				case 'time:2':
				case 'time:3':
				case 'time:4':
				case 'time:5':
				case 'time:6':
				case 'time:7':
					if ( isset( $posted['wc_appointment_availability_from_time'][ $i ] ) && isset( $posted['wc_appointment_availability_to_time'][ $i ] ) ) {
						$rule['from_range'] = wc_appointment_sanitize_time( $posted['wc_appointment_availability_from_time'][ $i ] );
						$rule['to_range']   = wc_appointment_sanitize_time( $posted['wc_appointment_availability_to_time'][ $i ] );
					}
					break;
				case 'time:range':
				case 'custom:daterange':
					if ( isset( $posted['wc_appointment_availability_from_time'][ $i ] ) && isset( $posted['wc_appointment_availability_to_time'][ $i ] ) ) {
						$rule['from_range'] = wc_appointment_sanitize_time( $posted['wc_appointment_availability_from_time'][ $i ] );
						$rule['to_range']   = wc_appointment_sanitize_time( $posted['wc_appointment_availability_to_time'][ $i ] );
					}
					if ( isset( $posted['wc_appointment_availability_from_date'][ $i ] ) && isset( $posted['wc_appointment_availability_to_date'][ $i ] ) ) {
						$rule['from_date'] = wc_clean( $posted['wc_appointment_availability_from_date'][ $i ] );
						$rule['to_date']   = wc_clean( $posted['wc_appointment_availability_to_date'][ $i ] );
					}
					break;
			}

			$rules[] = $rule;
		}

		return $rules;
	}

	/**
	 * Candidate rows for expired-availability cron cleanup.
	 *
	 * @since 5.5.0
	 *
	 * @return object[]
	 */
	public function get_expired_cleanup_candidates( bool $process_rrule_until, bool $process_rrule_count, int $batch_size ): array {
		global $wpdb;

		$batch_size = max( 1, $batch_size );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, rrule, from_date, to_date, from_range, to_range, range_type
				 FROM {$wpdb->prefix}wc_appointments_availability
				 WHERE (
				 	    ( (rrule IS NULL OR rrule = '') AND to_date IS NOT NULL AND to_date <> '' )
				 	 OR ( (rrule IS NULL OR rrule = '') AND range_type = 'custom' AND to_range IS NOT NULL AND to_range <> '' )
				     OR ( %d = 1 AND rrule IS NOT NULL AND rrule <> '' AND rrule LIKE %s )
				     OR ( %d = 1 AND rrule IS NOT NULL AND rrule <> '' AND rrule LIKE %s )
				 )
				   AND (range_type NOT LIKE %s)
				 ORDER BY ID ASC
				 LIMIT %d",
				$process_rrule_until ? 1 : 0,
				'%UNTIL%',
				$process_rrule_count ? 1 : 0,
				'%COUNT%',
				'%:expired',
				$batch_size
			)
		);

		return is_array( $rows ) ? $rows : [];
	}

	/**
	 * Append `:expired` to range_type for the given IDs (idempotent).
	 *
	 * @since 5.5.0
	 *
	 * @param int[] $ids Rule IDs.
	 */
	public function mark_ids_expired( array $ids ): void {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( [] === $ids ) {
			return;
		}

		global $wpdb;

		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$wpdb->prefix}wc_appointments_availability
			    SET range_type = CASE
					WHEN RIGHT(range_type, 8) = ':expired' THEN range_type
					ELSE CONCAT(range_type, ':expired')
				END
			  WHERE ID IN ({$placeholders})
			    AND (range_type NOT LIKE %s)",
				...array_merge( $ids, [ '%:expired' ] )
			)
		);
		// phpcs:enable

		WC_Appointments_Cache::invalidate_cache_group( self::CACHE_GROUP );
	}

}
