<?php
/**
 * Resource CPT data store.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * @since 5.5.0
 */
class WC_Appointments_Resource_Data_Store extends WC_Appointments_CPT_Data_Store {

	const META_LOCATION_ID = '_wca_resource_location_id';
	const META_NOTES       = '_wca_resource_notes';

	protected function post_type(): string {
		return WC_Appointments_Resource::POST_TYPE;
	}

	protected function meta_key_to_props(): array {
		return [
			self::META_LOCATION_ID => 'location_id',
			self::META_NOTES       => 'notes',
		];
	}

	protected function invalid_message(): string {
		return __( 'Invalid resource.', 'woocommerce-appointments' );
	}

	/** Hot-path location scope without hydrating a full object. */
	public static function get_location_id( int $resource_id ): int {
		return max( 0, absint( get_post_meta( $resource_id, self::META_LOCATION_ID, true ) ) );
	}

	/** Persist location scope without a full object load. */
	public static function update_location_id( int $resource_id, int $location_id ): void {
		update_post_meta( $resource_id, self::META_LOCATION_ID, max( 0, $location_id ) );
	}

	/** @return int[] */
	public static function get_ids_for_location( int $location_id ): array {
		if ( $location_id <= 0 ) {
			return [];
		}
		$ids = get_posts(
			[
				'post_type'      => WC_Appointments_Resource::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'orderby'        => 'title',
				'order'          => 'ASC',
				'meta_query'     => [
					[
						'key'   => self::META_LOCATION_ID,
						'value' => $location_id,
						'type'  => 'NUMERIC',
					],
				],
			]
		);
		return array_map( 'intval', (array) $ids );
	}

	/** @return int[] */
	public static function get_published_ids(): array {
		return self::query_published_ids( WC_Appointments_Resource::POST_TYPE );
	}

	/**
	 * @param string|string[] $post_status Status or list.
	 * @return int[]|WP_Post[]
	 */
	public static function query( $post_status = 'publish', bool $ids_only = false, int $limit = -1 ): array {
		return self::query_posts( WC_Appointments_Resource::POST_TYPE, $post_status, $ids_only, $limit );
	}

	/** Whether any resource CPT exists. */
	public static function exists( bool $published_only = true ): bool {
		return self::posts_exist( WC_Appointments_Resource::POST_TYPE, $published_only );
	}

	/**
	 * Appointment IDs holding any of the given resource IDs in a date range.
	 *
	 * @param int[] $resource_ids Resource IDs.
	 * @return int[]
	 */
	public static function get_appointment_ids_in_range( array $resource_ids, int $min_ts, int $max_ts ): array {
		$resource_ids = array_values( array_filter( array_map( 'intval', $resource_ids ) ) );
		if ( [] === $resource_ids || $min_ts <= 0 || $max_ts < $min_ts ) {
			return [];
		}

		global $wpdb;

		$statuses    = get_wc_appointment_statuses( 'fully_scheduled' );
		$status_ph   = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
		$resource_ph = implode( ',', array_fill( 0, count( $resource_ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT p.ID
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm_res ON p.ID = pm_res.post_id AND pm_res.meta_key = '_appointment_resource_id'
				INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id AND pm_start.meta_key = '_appointment_start'
				INNER JOIN {$wpdb->postmeta} pm_end ON p.ID = pm_end.post_id AND pm_end.meta_key = '_appointment_end'
				WHERE p.post_type = 'wc_appointment'
				AND p.post_status IN ({$status_ph})
				AND pm_res.meta_value IN ({$resource_ph})
				AND pm_end.meta_value >= %s
				AND pm_start.meta_value <= %s",
				array_merge( $statuses, $resource_ids, [ gmdate( 'YmdHis', $min_ts ), gmdate( 'YmdHis', $max_ts ) ] )
			)
		);
		// phpcs:enable

		return empty( $ids ) ? [] : array_map( 'intval', $ids );
	}
}
