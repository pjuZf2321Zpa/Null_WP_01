<?php
/**
 * Location CPT data store.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * @since 5.5.0
 */
class WC_Appointments_Location_Data_Store extends WC_Appointments_CPT_Data_Store {

	protected function post_type(): string {
		return WC_Appointments_Location::POST_TYPE;
	}

	protected function meta_key_to_props(): array {
		return [
			'_wca_location_kind'            => 'kind',
			'_wca_location_instructions'    => 'instructions',
			'_wca_location_address'         => 'address',
			'_wca_location_city'            => 'city',
			'_wca_location_state'           => 'state',
			'_wca_location_postcode'        => 'postcode',
			'_wca_location_country'         => 'country',
			'_wca_location_phone'           => 'phone',
			'_wca_location_static_join_url' => 'static_join_url',
		];
	}

	protected function invalid_message(): string {
		return __( 'Invalid location.', 'woocommerce-appointments' );
	}

	/** @return int[] */
	public static function get_published_ids(): array {
		return self::query_published_ids( WC_Appointments_Location::POST_TYPE );
	}

	/**
	 * @param string|string[] $post_status Status or list.
	 * @return int[]|WP_Post[]
	 */
	public static function query( $post_status = 'publish', bool $ids_only = false, int $limit = -1 ): array {
		return self::query_posts( WC_Appointments_Location::POST_TYPE, $post_status, $ids_only, $limit );
	}

	/** Whether any location CPT exists. */
	public static function exists( bool $published_only = true ): bool {
		return self::posts_exist( WC_Appointments_Location::POST_TYPE, $published_only );
	}
}
