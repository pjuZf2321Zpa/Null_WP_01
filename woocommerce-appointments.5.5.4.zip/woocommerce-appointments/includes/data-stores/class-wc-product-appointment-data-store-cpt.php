<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC Bookable Product Data Store: Stored in CPT.
 *
 * @todo When 2.6 support is dropped, implement WC_Object_Data_Store_Interface
 */
class WC_Product_Appointment_Data_Store_CPT extends WC_Product_Data_Store_CPT {

	/**
	 * Meta keys and how they transfer to CRUD props.
	 *
	 * @var array<string, string>
	 */
	private array $appointment_meta_key_to_props = [
		'_has_additional_costs'                   => 'has_additional_costs',
		'_wc_appointment_has_price_label'         => 'has_price_label',
		'_wc_appointment_price_label'             => 'price_label',
		'_wc_appointment_has_pricing'             => 'has_pricing',
		'_wc_appointment_pricing'                 => 'pricing',
		'_wc_appointment_qty'                     => 'qty',
		'_wc_appointment_qty_basis'               => 'qty_basis',
		'_wc_appointment_qty_min'                 => 'qty_min',
		'_wc_appointment_qty_max'                 => 'qty_max',
		'_wc_appointment_duration_unit'           => 'duration_unit',
		'_wc_appointment_duration'                => 'duration',
		'_wc_appointment_interval_unit'           => 'interval_unit',
		'_wc_appointment_interval'                => 'interval',
		'_wc_appointment_padding_duration_unit'   => 'padding_duration_unit',
		'_wc_appointment_padding_duration'        => 'padding_duration',
		'_wc_appointment_padding_after_duration'  => 'padding_after_duration',
		'_wc_appointment_min_date_unit'           => 'min_date_unit',
		'_wc_appointment_min_date'                => 'min_date',
		'_wc_appointment_max_date_unit'           => 'max_date_unit',
		'_wc_appointment_max_date'                => 'max_date',
		'_wc_appointment_user_can_cancel'         => 'user_can_cancel',
		'_wc_appointment_cancel_limit_unit'       => 'cancel_limit_unit',
		'_wc_appointment_cancel_limit'            => 'cancel_limit',
		'_wc_appointment_user_can_reschedule'     => 'user_can_reschedule',
		'_wc_appointment_reschedule_limit_unit'   => 'reschedule_limit_unit',
		'_wc_appointment_reschedule_limit'        => 'reschedule_limit',
		'_wc_appointment_requires_confirmation'   => 'requires_confirmation',
		'_wc_appointment_cal_color'               => 'cal_color',
		'_wc_appointment_availability_span'       => 'availability_span',
		'_wc_appointment_availability_autoselect' => 'availability_autoselect',
		'_wc_appointment_has_restricted_days'     => 'has_restricted_days',
		'_wc_appointment_restricted_days'         => 'restricted_days',
		/*'_wc_appointment_availability'            => 'availability',*/
		'_wc_appointment_staff_label'             => 'staff_label',
		'_wc_appointment_staff_assignment'        => 'staff_assignment',
		'_wc_appointment_staff_nopref'            => 'staff_nopref',
		'_wc_appointment_location_mode'           => 'location_mode',
		'_wc_appointment_location_ids'            => 'location_ids',
		'_wc_appointment_location_costs'          => 'location_costs',
		'_wc_appointment_location_label'          => 'location_label',
		'_wc_appointment_resource_requirements'   => 'resource_requirements',
		'_wc_appointment_resource_label'          => 'resource_label',
		'_wc_appointment_resource_assignment'     => 'resource_assignment',
		'_wc_appointment_meeting_provider'        => 'meeting_provider',
	];

	/**
	 * Method to create a new product in the database.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function create( &$product ): void {
		parent::create( $product );
		WC_Appointments_Cache::delete_appointment_slots_transient( $product->get_id() );
	}

	/**
	 * Method to read product data.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function read( &$product ): void {
		parent::read( $product );
	}

	/**
	 * Method to update a product in the database.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function update( &$product ): void {
		parent::update( $product );
		WC_Appointments_Cache::delete_appointment_slots_transient( $product->get_id() );
	}

	/**
	 * Method to delete a product from the database.
	 *
	 * @param WC_Product           $product Product object.
	 * @param array<string, mixed> $args    Array of args to pass to the delete method.
	 * @return bool
	 */
	public function delete( &$product, $args = [] ) {
		$deleted = parent::delete( $product, $args );
		WC_Appointments_Cache::delete_appointment_slots_transient( $product->get_id() );

		return $deleted;
	}

	/**
	 * Helper method that updates all the post meta for a product based on it's settings in the WC_Product class.
	 *
	 * @param WC_Product $product Product object.
	 * @param bool       $force   Force all props to be written even if not changed. This is used during creation.
	 * @since 3.0.0
	 */
	public function update_post_meta( &$product, $force = false ): void {
		parent::update_post_meta( $product, $force );
		$updated_props = [];

		foreach ( $this->appointment_meta_key_to_props as $key => $prop ) {
			if ( is_callable( [ $product, "get_$prop" ] ) ) {
				update_post_meta( $product->get_id(), $key, $product->{ "get_$prop" }( 'edit' ) );
				$updated_props[] = $prop;
			}
		}

		if ( $product instanceof WC_Product_Appointment ) {
			$this->update_staff( $product );
		}
		if ( array_intersect( $updated_props, [ 'price', 'average_rating', 'tax_status', 'tax_class' ] ) ) {
			$this->update_lookup_table( $product->get_id(), 'wc_product_meta_lookup' );
		}
	}

	/**
	 * Read product data. Can be overridden by child classes to load other props.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function read_product_data( &$product ): void {
		parent::read_product_data( $product );
		$set_props = [];

		foreach ( $this->appointment_meta_key_to_props as $key => $prop ) {
			if ( ! metadata_exists( 'post', $product->get_id(), $key ) ) {
				continue;
			}

			$value              = get_post_meta( $product->get_id(), $key, true );
			$set_props[ $prop ] = $value;
		}

		$product->set_props( $set_props );
		if ( $product instanceof WC_Product_Appointment ) {
			$this->read_staff( $product );
		}
	}

	/**
	 * Read staff from the database.
	 *
	 * @param WC_Product_Appointment $product
	 * @return void
	 */
	protected function read_staff( &$product ) {
		if ( ! $product instanceof WC_Product_Appointment ) {
			return;
		}

		global $wpdb;

		/*
		// Set transient caching.
		$transient_name = 'schedule_staff_ids_' . md5( http_build_query( [ $product->get_id(), WC_Cache_Helper::get_transient_version( 'appointments' ) ] ) );
		$staff_ids      = WC_Appointments_Cache::get( $transient_name );

		if ( false === $staff_ids ) {
			$staff_ids = wp_parse_id_list(
				$wpdb->get_col(
					$wpdb->prepare(
						"SELECT users.ID
							FROM {$wpdb->prefix}wc_appointment_relationships AS relationships
							LEFT JOIN $wpdb->users AS users ON users.ID = relationships.staff_id
							WHERE relationships.product_id = %d
							ORDER BY sort_order ASC",
						$product->get_id()
					)
				)
			);
			// Update cache.
			WC_Appointments_Cache::set( $transient_name, $staff_ids, DAY_IN_SECONDS * 30 );
		}
		*/

		// Don't cache when editing product.
		$product_edit_screen = false;
		if ( is_admin() ) {
			global $current_screen;
			if ( isset( $current_screen ) && 'edit' === $current_screen->parent_base && 'product' === $current_screen->post_type ) {
				$product_edit_screen = true;
				#echo '<pre>' . var_export( $current_screen, true ) . '</pre>';
			}
		}

		// Remove duplicate calls, by only one call per page load.
		$product_staff_cache = wp_cache_get( 'read_staff_for_' . $product->get_id(), 'read_staff' );
		if ( $product_edit_screen || ! $product_staff_cache ) {
			// Delete cache.
			wp_cache_delete( 'read_staff_for_' . $product->get_id(), 'read_staff' );

			$get_staff_ids = wp_parse_id_list(
			    $wpdb->get_col(
			        $wpdb->prepare(
			            "SELECT users.ID
							FROM {$wpdb->prefix}wc_appointment_relationships AS relationships
							LEFT JOIN $wpdb->users AS users ON users.ID = relationships.staff_id
							WHERE relationships.product_id = %d
							ORDER BY sort_order ASC",
			            $product->get_id(),
			        ),
			    ),
			);

			if ( $get_staff_ids ) {
				wp_cache_set( 'read_staff_for_' . $product->get_id(), $get_staff_ids, 'read_staff' );
				$product_staff_cache = $get_staff_ids;
			} else {
				wp_cache_set( 'read_staff_for_' . $product->get_id(), true, 'read_staff' );
				$product_staff_cache = true;
			}
		}

		// When product has no staff, load it from cach anyways as empty array.
		$staff_ids = is_array( $product_staff_cache ) ? $product_staff_cache : [];

		/*
		$staff_ids = wp_parse_id_list( $wpdb->get_col( $wpdb->prepare( "
			SELECT users.ID
			FROM {$wpdb->prefix}wc_appointment_relationships AS relationships
			LEFT JOIN $wpdb->users AS users ON users.ID = relationships.staff_id
			WHERE relationships.product_id = %d
			ORDER BY sort_order ASC
		", $product->get_id() ) ) );
		*/

		$product->set_staff_ids( $staff_ids );
		$product->set_staff_base_costs( get_post_meta( $product->get_id(), '_staff_base_costs', true ) );
		$product->set_staff_qtys( get_post_meta( $product->get_id(), '_staff_qtys', true ) );
	}

	/**
	 * Update staff.
	 *
	 * @param WC_Product_Appointment $product
	 * @return void
	 */
	protected function update_staff( &$product ) {
		if ( ! $product instanceof WC_Product_Appointment ) {
			return;
		}

		// Delete cache on ajax calls.
		wp_cache_delete( 'read_staff_for_' . $product->get_id(), 'read_staff' );

		update_post_meta( $product->get_id(), '_staff_base_costs', $product->get_staff_base_costs( 'edit' ) );
		update_post_meta( $product->get_id(), '_staff_qtys', $product->get_staff_qtys( 'edit' ) );

		$index             = 0;
		$current_staff_ids = [];
		foreach ( self::get_relationship_rows_for_product( (int) $product->get_id() ) as $staff ) {
			$current_staff_ids[ (int) $staff['staff_id'] ] = $staff;
		}

		foreach ( $product->get_staff_ids( 'edit' ) as $staff_id ) {
			$staff_id = (int) $staff_id;
			$replace  = [
				'sort_order' => ( $index++ ),
				'product_id' => $product->get_id(),
				'staff_id'   => $staff_id,
			];

			if ( isset( $current_staff_ids[ $staff_id ] ) ) {
				$replace['ID'] = $current_staff_ids[ $staff_id ]['ID'];
				unset( $current_staff_ids[ $staff_id ] );
			}

			self::replace_relationship( $replace );
		}

		foreach ( $current_staff_ids as $staff ) {
			self::delete_relationship( [ 'ID' => $staff['ID'] ] );
		}
	}

	/**
	 * Remove staff from product by staff ID and product ID.
	 *
	 * @param int $staff_id staff ID (user ID).
	 * @param int $product_id product ID (post ID).
	 * @return void
	 */
	public static function remove_staff_from_product( $staff_id, $product_id ): void {
		// Delete cache on ajax calls.
		wp_cache_delete( 'read_staff_for_' . $product_id, 'read_staff' );

		self::delete_relationship(
			[
				'product_id' => $product_id,
				'staff_id'   => $staff_id,
			]
		);

		// Re-pack sort_order for remaining staff (admin product staff UI).
		foreach ( self::get_relationship_rows_for_product( (int) $product_id ) as $i => $row ) {
			self::update_relationship(
				[ 'sort_order' => $i ],
				[
					'product_id' => $product_id,
					'staff_id'   => (int) $row['staff_id'],
				]
			);
		}
	}

	/**
	 * Get staff products by staff ID.
	 *
	 * @param int $staff_id staff ID (user ID).
	 * @return int[] Product IDs.
	 */
	public static function get_appointable_product_ids_for_staff( $staff_id ) {
		global $wpdb;

		$ids = [];

		if ( ! $staff_id ) {
			return $ids;
		}

		// Only get products that exist in posts table.
		$ids = wp_parse_id_list(
		    $wpdb->get_col(
		        $wpdb->prepare(
		            "SELECT posts.ID
						FROM {$wpdb->prefix}wc_appointment_relationships AS relationships
						LEFT JOIN $wpdb->posts AS posts ON posts.ID = relationships.product_id
						WHERE relationships.staff_id = %d AND posts.ID != ''
						ORDER BY sort_order ASC",
		            $staff_id,
		        ),
		    ),
		);

		return $ids;
	}

	/**
	 * Default WP_Query args for appointable product ID lists.
	 *
	 * @var array<string, mixed>
	 */
	private static array $appointment_products_query_args = [
		'post_status'      => 'publish',
		'post_type'        => 'product',
		'posts_per_page'   => -1,
		'tax_query'        => [
			[
				'taxonomy' => 'product_type',
				'field'    => 'slug',
				'terms'    => 'appointment',
			],
		],
		'suppress_filters' => true,
		'fields'           => 'ids',
		'orderby'          => 'title',
		'order'            => 'ASC',
	];

	/**
	 * Delete legacy product availability meta after migration to the rules table.
	 *
	 * @since 5.5.0
	 */
	public static function delete_legacy_availability_meta( int $product_id ): void {
		if ( $product_id > 0 ) {
			delete_post_meta( $product_id, '_wc_appointment_availability' );
		}
	}

	/**
	 * Persist pricing rules meta (e.g. WCML multi-currency overlays).
	 *
	 * @since 5.5.0
	 *
	 * @param mixed $pricing Pricing rows.
	 */
	public static function update_pricing_meta( int $product_id, $pricing ): void {
		if ( $product_id > 0 ) {
			update_post_meta( $product_id, '_wc_appointment_pricing', $pricing );
		}
	}

	/**
	 * @since 5.5.0
	 *
	 * @param mixed $value Meta value.
	 */
	public static function update_staff_base_costs_meta( int $product_id, $value ): void {
		if ( $product_id > 0 ) {
			update_post_meta( $product_id, '_staff_base_costs', $value );
		}
	}

	/**
	 * @since 5.5.0
	 *
	 * @param mixed $value Meta value.
	 */
	public static function update_staff_qtys_meta( int $product_id, $value ): void {
		if ( $product_id > 0 ) {
			update_post_meta( $product_id, '_staff_qtys', $value );
		}
	}

	/**
	 * Staff↔product relationship rows for a product.
	 *
	 * @since 5.5.0
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_relationship_rows_for_product( int $product_id ): array {
		if ( $product_id <= 0 ) {
			return [];
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}wc_appointment_relationships WHERE product_id = %d ORDER BY sort_order ASC",
				$product_id
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : [];
	}

	/**
	 * staff_id + sort_order for a product (translation sync).
	 *
	 * @since 5.5.0
	 *
	 * @return object[]
	 */
	public static function get_staff_sort_for_product( int $product_id ): array {
		if ( $product_id <= 0 ) {
			return [];
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT staff_id, sort_order FROM {$wpdb->prefix}wc_appointment_relationships WHERE product_id = %d ORDER BY sort_order ASC",
				$product_id
			)
		);

		return is_array( $rows ) ? $rows : [];
	}

	/**
	 * Single staff_id + sort_order row for a product/staff pair.
	 *
	 * @since 5.5.0
	 */
	public static function get_staff_sort_row( int $product_id, int $staff_id ): ?object {
		if ( $product_id <= 0 || $staff_id <= 0 ) {
			return null;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT staff_id, sort_order FROM {$wpdb->prefix}wc_appointment_relationships WHERE product_id = %d AND staff_id = %d",
				$product_id,
				$staff_id
			)
		);

		return $row instanceof stdClass ? $row : null;
	}

	/** @since 5.5.0 */
	public static function relationship_exists( int $product_id, int $staff_id ): bool {
		if ( $product_id <= 0 || $staff_id <= 0 ) {
			return false;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}wc_appointment_relationships WHERE product_id = %d AND staff_id = %d",
				$product_id,
				$staff_id
			)
		);
	}

	/**
	 * @since 5.5.0
	 *
	 * @param array<string, mixed> $data Column => value.
	 */
	public static function insert_relationship( array $data ): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert( $wpdb->prefix . 'wc_appointment_relationships', $data );
		return (int) $wpdb->insert_id;
	}

	/**
	 * @since 5.5.0
	 *
	 * @param array<string, mixed> $data Column => value.
	 */
	public static function replace_relationship( array $data ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->replace( $wpdb->prefix . 'wc_appointment_relationships', $data );
	}

	/**
	 * @since 5.5.0
	 *
	 * @param array<string, mixed> $data  Column => value.
	 * @param array<string, mixed> $where Where clause.
	 */
	public static function update_relationship( array $data, array $where ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $wpdb->prefix . 'wc_appointment_relationships', $data, $where );
	}

	/**
	 * @since 5.5.0
	 *
	 * @param array<string, mixed> $where Where clause.
	 */
	public static function delete_relationship( array $where ): void {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $wpdb->prefix . 'wc_appointment_relationships', $where );
	}

	/**
	 * Product counts per staff ID (staff product tab meta).
	 *
	 * @since 5.5.0
	 *
	 * @param int[] $staff_ids Staff user IDs.
	 * @return array<int, int> staff_id => count
	 */
	public static function get_product_counts_for_staff_ids( array $staff_ids ): array {
		$staff_ids = array_values( array_filter( array_map( 'intval', $staff_ids ) ) );
		if ( [] === $staff_ids ) {
			return [];
		}

		global $wpdb;

		$in = implode( ',', array_fill( 0, count( $staff_ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT staff_id, COUNT(*) AS c FROM {$wpdb->prefix}wc_appointment_relationships WHERE staff_id IN ({$in}) GROUP BY staff_id",
				...$staff_ids
			)
		);
		// phpcs:enable

		$out = [];
		foreach ( (array) $rows as $row ) {
			$out[ (int) $row->staff_id ] = (int) $row->c;
		}
		return $out;
	}

	/**
	 * Staff id/name map rows for a set of products (admin panel create).
	 *
	 * @since 5.5.0
	 *
	 * @param int[] $product_ids Product IDs.
	 * @return object[]
	 */
	public static function get_staff_display_rows_for_products( array $product_ids, int $filter_staff_id = 0 ): array {
		$product_ids = array_values( array_filter( array_map( 'intval', $product_ids ) ) );
		if ( [] === $product_ids ) {
			return [];
		}

		global $wpdb;

		$ids_ph = implode( ',', array_fill( 0, count( $product_ids ), '%d' ) );
		$params = $product_ids;
		$extra  = '';
		if ( $filter_staff_id > 0 ) {
			$extra    = ' AND r.staff_id = %d';
			$params[] = $filter_staff_id;
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT r.product_id, r.staff_id, u.display_name
				FROM {$wpdb->prefix}wc_appointment_relationships AS r
				INNER JOIN {$wpdb->users} AS u ON u.ID = r.staff_id
				WHERE r.product_id IN ( {$ids_ph} ){$extra}
				ORDER BY r.sort_order ASC",
				...$params
			)
		);
		// phpcs:enable

		return is_array( $rows ) ? $rows : [];
	}

	/**
	 * WP_Query JOIN fragment to filter products by staff IDs (REST).
	 *
	 * @since 5.5.0
	 *
	 * @param int[] $staff_ids Staff user IDs.
	 */
	public static function get_staff_filter_join_sql( array $staff_ids ): string {
		$staff_ids = array_values( array_filter( array_map( 'absint', $staff_ids ) ) );
		if ( [] === $staff_ids ) {
			return '';
		}

		global $wpdb;

		$staff_id_in = implode( ',', $staff_ids );

		return " INNER JOIN
			{$wpdb->prefix}wc_appointment_relationships ON
			({$wpdb->posts}.ID = {$wpdb->prefix}wc_appointment_relationships.product_id AND
			{$wpdb->prefix}wc_appointment_relationships.staff_id IN ({$staff_id_in}))";
	}

	/**
	 * Get all appointment products.
	 *
	 * @param bool $show_all When true, skip author/staff scoping for the current user.
	 * @return int[]
	 */
	public static function get_appointable_product_ids( $show_all = false ) {
		$args = self::$appointment_products_query_args;

		// Get products, where current user is author.
		if ( ! current_user_can( 'manage_others_appointments' ) && ! $show_all ) {
			$args['author'] = get_current_user_id();
		}

		$args = apply_filters( 'get_appointment_products_args', $args );

		$posts_query = new WP_Query();
	    $ids         = $posts_query->query( $args );

		// Get products, where current user assigned as staff member.
		if ( ! current_user_can( 'manage_others_appointments' ) && ! $show_all ) {
			$staff_product_ids = self::get_appointable_product_ids_for_staff( get_current_user_id() );

			// Merge Products where current user is author with
			// products, where current user is assigned as staff member.
			$ids = array_merge( (array) $ids, (array) $staff_product_ids );
		}

		return wp_parse_id_list( $ids );
	}
}
