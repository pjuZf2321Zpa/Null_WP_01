<?php
/**
 * CRUD for wp_wc_appointment_series with optimistic locking.
 *
 * @package WooCommerce\Appointments
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Series table data store (custom table; mirrors availability CRUD shape).
 */
class WC_Appointment_Series_Data_Store extends WC_Data_Store_WP {

	const TABLE_NAME = 'wc_appointment_series';

	/**
	 * @var string
	 */
	protected $meta_type = 'wc_appointment_series';

	/**
	 * @var string
	 */
	protected $object_id_field_for_meta = 'wc_appointment_series_id';

	/**
	 * Create a series row.
	 *
	 * @param WC_Appointment_Series $series Series object.
	 * @return void
	 */
	public function create( &$series ) {
		global $wpdb;

		$series->apply_changes();

		$now = current_time( 'mysql', true );

		$data = array(
			'version'               => 1,
			'status'                => $series->get_status( 'edit' ),
			'product_id'            => $series->get_product_id( 'edit' ),
			'customer_id'           => $series->get_customer_id( 'edit' ),
			'staff_assignment_mode' => $series->get_staff_assignment_mode( 'edit' ),
			'locked_staff_id'       => $series->get_locked_staff_id( 'edit' ),
			'order_id'              => $series->get_order_id( 'edit' ),
			'subscription_id'       => $series->get_subscription_id( 'edit' ),
			'payment_model'         => $series->get_payment_model( 'edit' ),
			'rrule'                 => $series->get_rrule( 'edit' ),
			'dtstart_ts'            => $series->get_dtstart_ts( 'edit' ),
			'duration_seconds'      => $series->get_duration_seconds( 'edit' ),
			'timezone'              => $series->get_timezone( 'edit' ),
			'horizon_days'          => 0,
			'next_materialize_ts'   => $series->get_next_materialize_ts( 'edit' ),
			'last_materialized_ts'  => 0,
			'materialized_count'    => 0,
			'rrule_count_cap'       => $series->get_rrule_count_cap( 'edit' ),
			'created_at'            => $now,
			'updated_at'            => $now,
		);

		$wpdb->insert( $wpdb->prefix . self::TABLE_NAME, $data );
		$series->set_id( $wpdb->insert_id );
		$series->set_version( 1 );
		$series->set_created_at( $now );
		$series->set_updated_at( $now );
		$series->apply_changes();
		$series->save_meta_data();
		$series->set_object_read( true );

		$this->clear_cache( $series );

		WC_Appointment_Series_Events::series_created( $series );
	}

	/**
	 * Read a series row into the object.
	 *
	 * @param WC_Appointment_Series $series Series object.
	 * @return void
	 * @throws Exception When the row is missing.
	 */
	public function read( &$series ) {
		global $wpdb;

		$cache_group = WC_Appointment_Series::CACHE_GROUP;
		$data        = WC_Appointment_Series::cache_enabled()
			? wp_cache_get( $series->get_id(), $cache_group )
			: false;

		if ( false === $data ) {
			$table = $wpdb->prefix . self::TABLE_NAME;
			$sql   = sprintf( 'SELECT * FROM %1$s WHERE id = %%d LIMIT 1', $table );
			$prepared_sql = $wpdb->prepare(
				$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$series->get_id()
			);
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$data = $wpdb->get_row( $prepared_sql, ARRAY_A );

			if ( empty( $data ) ) {
				throw new Exception( __( 'Invalid appointment series.', 'woocommerce-appointments' ) );
			}

			if ( WC_Appointment_Series::cache_enabled() ) {
				wp_cache_set( $series->get_id(), $data, $cache_group );
			}
		}

		$series->set_id( (int) $data['id'] );
		unset( $data['id'], $data['horizon_days'] );
		$series->set_props( $data );
		$series->read_meta_data();
		$series->set_object_read( true );
	}

	/**
	 * Standard update: optimistic lock using the object's current version.
	 *
	 * @param WC_Appointment_Series $series Series object.
	 * @return void
	 * @throws WC_Appointment_Series_Version_Conflict When version mismatched.
	 */
	public function update( &$series ) {
		$this->update_if_version( $series, $series->get_version( 'edit' ) );
	}

	/**
	 * Optimistic-locked update (REST If-Match / manager mutations).
	 *
	 * @param WC_Appointment_Series $series           Series object.
	 * @param int                   $expected_version Client version (If-Match).
	 * @return void
	 * @throws WC_Appointment_Series_Version_Conflict When version mismatched.
	 */
	public function update_if_version( &$series, $expected_version ) {
		global $wpdb;

		$series->apply_changes();

		$now   = current_time( 'mysql', true );
		$table = $wpdb->prefix . self::TABLE_NAME;
		$sql   = sprintf(
			'UPDATE %1$s
			 SET version = version + 1,
			     status = %%s,
			     rrule = %%s,
			     next_materialize_ts = %%d,
			     last_materialized_ts = %%d,
			     materialized_count = %%d,
			     locked_staff_id = %%d,
			     updated_at = %%s
			 WHERE id = %%d AND version = %%d',
			$table
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$updated = $wpdb->query(
			$wpdb->prepare(
				$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$series->get_status( 'edit' ),
				$series->get_rrule( 'edit' ),
				$series->get_next_materialize_ts( 'edit' ),
				$series->get_last_materialized_ts( 'edit' ),
				$series->get_materialized_count( 'edit' ),
				$series->get_locked_staff_id( 'edit' ),
				$now,
				$series->get_id(),
				$expected_version
			)
		);

		if ( 0 === (int) $updated ) {
			throw new WC_Appointment_Series_Version_Conflict( $series->get_id(), $expected_version );
		}

		$this->clear_cache( $series );

		$series->save_meta_data();
		$this->read( $series );

		WC_Appointment_Series_Events::series_updated( $series );
	}

	/**
	 * Delete a series row.
	 *
	 * @param WC_Appointment_Series $series             Series object.
	 * @param array<string, mixed>  $args               Optional args (unused).
	 * @return void
	 */
	public function delete( &$series, $args = array() ) {
		global $wpdb;

		$wpdb->delete(
			$wpdb->prefix . self::TABLE_NAME,
			array( 'id' => $series->get_id() ),
			array( '%d' )
		);
		$wpdb->delete(
			$wpdb->prefix . 'wc_appointment_seriesmeta',
			array( 'wc_appointment_series_id' => $series->get_id() ),
			array( '%d' )
		);

		$this->clear_cache( $series );
	}

	/**
	 * List series rows with optional filters.
	 *
	 * @param array<string, mixed> $args {
	 *     @type string $status      Optional status filter.
	 *     @type int    $customer_id Optional customer id.
	 *     @type int    $limit       Max rows (default 20).
	 *     @type int    $offset      Offset (default 0).
	 * }
	 * @return WC_Appointment_Series[]
	 */
	public function query( $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'status'          => '',
				'customer_id'     => 0,
				'subscription_id' => 0,
				'limit'           => 20,
				'offset'          => 0,
			)
		);

		$where  = array( '1=1' );
		$values = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$values[] = $args['status'];
		}

		if ( ! empty( $args['customer_id'] ) ) {
			$where[]  = 'customer_id = %d';
			$values[] = (int) $args['customer_id'];
		}

		if ( ! empty( $args['subscription_id'] ) ) {
			$where[]  = 'subscription_id = %d';
			$values[] = (int) $args['subscription_id'];
		}

		$limit  = max( 1, (int) $args['limit'] );
		$offset = max( 0, (int) $args['offset'] );

		$table    = $wpdb->prefix . self::TABLE_NAME;
		$sql      = sprintf(
			'SELECT * FROM %1$s WHERE %2$s ORDER BY id DESC LIMIT %%d OFFSET %%d',
			$table,
			implode( ' AND ', $where )
		);
		$values[] = $limit;
		$values[] = $offset;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				$values
			),
			ARRAY_A
		);

		$out = array();
		foreach ( (array) $rows as $row ) {
			$series = new WC_Appointment_Series();
			$series->set_id( (int) $row['id'] );
			unset( $row['id'] );
			$series->set_props( $row );
			$series->set_object_read( true );
			$out[] = $series;
		}

		return $out;
	}

	/**
	 * Count series rows with optional filters.
	 *
	 * @since 5.4.0
	 *
	 * @param array<string, mixed> $args {
	 *     @type string $status      Optional status filter.
	 *     @type int    $customer_id Optional customer id.
	 * }
	 * @return int
	 */
	public function count( $args = array() ) {
		global $wpdb;

		$args = wp_parse_args(
			$args,
			array(
				'status'          => '',
				'customer_id'     => 0,
				'subscription_id' => 0,
			)
		);

		$where  = array( '1=1' );
		$values = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$values[] = $args['status'];
		}

		if ( ! empty( $args['customer_id'] ) ) {
			$where[]  = 'customer_id = %d';
			$values[] = (int) $args['customer_id'];
		}

		if ( ! empty( $args['subscription_id'] ) ) {
			$where[]  = 'subscription_id = %d';
			$values[] = (int) $args['subscription_id'];
		}

		$table = $wpdb->prefix . self::TABLE_NAME;
		$sql   = sprintf(
			'SELECT COUNT(*) FROM %1$s WHERE %2$s',
			$table,
			implode( ' AND ', $where )
		);

		if ( ! empty( $values ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Series ids due for materialization (cron sweep).
	 *
	 * @param int $now_ts Unix timestamp.
	 * @param int $limit  Max ids.
	 * @return int[]
	 */
	public function get_due_for_materialization( $now_ts, $limit = 200 ) {
		global $wpdb;

		$table = $wpdb->prefix . self::TABLE_NAME;
		$sql   = sprintf(
			"SELECT id FROM %s WHERE status = 'active' AND next_materialize_ts <= %%d ORDER BY next_materialize_ts ASC LIMIT %%d",
			$table
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return array_map(
			'intval',
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->get_col(
				$wpdb->prepare(
					$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
					$now_ts,
					$limit
				)
			)
		);
	}

	/**
	 * Atomically set `notified_created_at` when still zero (idempotent `created` send).
	 *
	 * @param int $series_id Series id.
	 * @return bool True when this call claimed the send slot.
	 */
	public function mark_created_notified( $series_id ) {
		global $wpdb;

		$series_id = (int) $series_id;
		if ( $series_id <= 0 ) {
			return false;
		}

		$now = time();

		$table = $wpdb->prefix . self::TABLE_NAME;
		$sql   = sprintf(
			'UPDATE %1$s SET notified_created_at = %%d WHERE id = %%d AND notified_created_at = 0',
			$table
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$prepared_sql = $wpdb->prepare(
			$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$now,
			$series_id
		);
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$updated = $wpdb->query( $prepared_sql );

		if ( 1 === (int) $updated ) {
			if ( WC_Appointment_Series::cache_enabled() ) {
				wp_cache_delete( $series_id, WC_Appointment_Series::CACHE_GROUP );
			}
			return true;
		}

		return false;
	}

	/**
	 * @return array<string, string>
	 */
	protected function get_db_info() {
		global $wpdb;

		return array(
			'table'           => $wpdb->wc_appointment_seriesmeta,
			'object_id_field' => $this->object_id_field_for_meta,
			'meta_id_field'   => 'meta_id',
		);
	}

	/**
	 * @param WC_Appointment_Series $series Series object.
	 * @return void
	 */
	protected function clear_cache( $series ) {
		if ( ! WC_Appointment_Series::cache_enabled() ) {
			return;
		}

		$id = $series->get_id();
		if ( $id <= 0 ) {
			return;
		}

		$cache_group = $series->get_cache_group();
		wp_cache_delete( $id, WC_Appointment_Series::CACHE_GROUP );
		if ( '' !== $cache_group ) {
			wp_cache_delete( WC_Appointment_Series::generate_meta_cache_key( $id, $cache_group ), $cache_group );
		}
	}
}
