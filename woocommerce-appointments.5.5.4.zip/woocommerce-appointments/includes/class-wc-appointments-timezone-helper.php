<?php
/**
 * Timezone Helper for WooCommerce Appointments.
 *
 * Centralized timezone handling utilities for customer preferences,
 * timezone conversion, and DST-safe operations.
 *
 * @package WooCommerce Appointments
 * @since   5.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Timezone_Helper class.
 *
 * Provides centralized timezone handling for WooCommerce Appointments.
 * Handles user preferences, timezone conversion, and DST-safe calculations.
 */
class WC_Appointments_Timezone_Helper {

	/**
	 * User meta key for storing timezone preference.
	 *
	 * @var string
	 */
	const USER_META_KEY = 'wc_appointments_timezone';

	/**
	 * Get timezone short name.
	 *
	 * Returns the Olson abbreviation for the timezone at a given instant
	 * (e.g. BST/GMT, CEST/CET, EDT/EST). Pass the appointment instant for
	 * booked times; omit $at for pickers/profile ("now").
	 *
	 * @since 5.2.0
	 * @since 5.5.0 DST-aware via DateTime::format( 'T' ); optional $at instant.
	 *
	 * @param string                      $timezone Timezone string (IANA identifier).
	 * @param DateTimeInterface|int|null  $at       Optional. True-UTC epoch, or any DateTimeInterface
	 *                                              for that instant. Null = now.
	 *
	 * @return string Short timezone name (e.g., 'CEST', 'BST', 'JST').
	 */
	public static function get_timezone_short_name( string $timezone, $at = null ): string {
		if ( empty( $timezone ) ) {
			return '';
		}

		// WooCommerce offset IDs (e.g. +00:00) and UTC* strings — never format('T') (Windows → GMT+0000).
		if ( preg_match( '/^UTC([+-]\d{1,2}(:\d{2})?)?$/', $timezone ) ) {
			return $timezone;
		}
		if ( preg_match( '/^([+-])(\d{1,2})(?::?(\d{2}))?$/', $timezone, $m ) ) {
			$hours   = (int) $m[2];
			$minutes = isset( $m[3] ) ? (int) $m[3] : 0;
			$seconds = ( ( '+' === $m[1] ) ? 1 : -1 ) * ( ( $hours * 3600 ) + ( $minutes * 60 ) );
			return self::format_utc_offset( $seconds );
		}

		try {
			$tz = new DateTimeZone( $timezone );

			if ( $at instanceof DateTimeInterface ) {
				$dt = ( new DateTimeImmutable( '@' . $at->getTimestamp() ) )->setTimezone( $tz );
			} elseif ( null !== $at && is_numeric( $at ) ) {
				$dt = ( new DateTimeImmutable( '@' . (int) $at ) )->setTimezone( $tz );
			} else {
				$dt = new DateTimeImmutable( 'now', $tz );
			}

			$abbr = $dt->format( 'T' );

			// Keep CET/CEST/BST/GMT/EDT. Reject offset-style T (GMT+0100, UTC+1, +01).
			if (
				$abbr
				&& ! preg_match( '/^(?:GMT|UTC)[+-]/i', $abbr )
				&& ! preg_match( '/^[+-]?\d/', $abbr )
			) {
				return $abbr;
			}

			return self::format_utc_offset( $dt->getOffset() );
		} catch ( Exception $e ) {
			return $timezone;
		}
	}

	/**
	 * Format a UTC offset in seconds to a readable string.
	 *
	 * @since 5.2.0
	 *
	 * @param int $offset_seconds Offset in seconds.
	 *
	 * @return string Formatted offset (e.g., 'UTC+1', 'UTC-5:30').
	 */
	public static function format_utc_offset( int $offset_seconds ): string {
		if ( 0 === $offset_seconds ) {
			return 'UTC';
		}

		$hours   = abs( intdiv( $offset_seconds, 3600 ) );
		$minutes = abs( ( $offset_seconds % 3600 ) / 60 );
		$sign    = $offset_seconds >= 0 ? '+' : '-';

		if ( $minutes > 0 ) {
			return sprintf( 'UTC%s%d:%02d', $sign, $hours, $minutes );
		}
		return sprintf( 'UTC%s%d', $sign, $hours );
	}

	/**
	 * Get timezone display label with short name.
	 *
	 * Returns a label suitable for dropdown displays showing the short name.
	 *
	 * @since 5.2.0
	 *
	 * @param string                     $timezone Timezone string.
	 * @param DateTimeInterface|int|null $at       Optional. Instant for DST-correct abbr. Null = now.
	 *
	 * @return string Display label (e.g., 'CEST', 'BST').
	 */
	public static function get_timezone_label( string $timezone, $at = null ): string {
		if ( empty( $timezone ) ) {
			return '';
		}

		return self::get_timezone_short_name( $timezone, $at );
	}

	/**
	 * Get localized city name from timezone identifier.
	 *
	 * @since 5.2.0
	 *
	 * @param string $timezone Timezone string.
	 *
	 * @return string Localized city name or empty string.
	 */
	public static function get_city_name( string $timezone ): string {
		static $mo_loaded = false, $locale_loaded = null;

		if ( empty( $timezone ) || preg_match( '/^UTC[+-]?/', $timezone ) || preg_match( '/^[+-]\d/', $timezone ) ) {
			return '';
		}

		$locale = get_user_locale();
		if ( ! $mo_loaded || $locale !== $locale_loaded ) {
			$locale_loaded = $locale ?: get_locale();
			$mofile        = WP_LANG_DIR . '/continents-cities-' . $locale_loaded . '.mo';
			unload_textdomain( 'continents-cities' );
			load_textdomain( 'continents-cities', $mofile );
			$mo_loaded = true;
		}

		$parts = explode( '/', $timezone );
		if ( count( $parts ) >= 2 && 'Etc' !== $parts[0] ) {
			// phpcs:ignore WordPress.WP.I18n.LowLevelTranslationFunction,WordPress.WP.I18n.NonSingularStringLiteralText,WordPress.WP.I18n.TextDomainMismatch -- WordPress core continents-cities MO for IANA city names.
			return translate( str_replace( '_', ' ', $parts[1] ), 'continents-cities' );
		}

		return '';
	}

	/**
	 * Build timezone dropdown HTML with city names and short abbreviations.
	 *
	 * Format: "City — CET (UTC+1)" with hover showing "Timezone: Europe/Berlin (CET)"
	 *
	 * @since 5.2.0
	 *
	 * @param string $selected        Selected timezone value.
	 * @param string $locale          Locale for translations.
	 * @param bool   $include_default Include "Default" option.
	 *
	 * @return string HTML options.
	 */
	public static function get_timezone_dropdown( string $selected = '', string $locale = '', bool $include_default = true ): string {
		if ( '' === $locale ) {
			$locale = get_user_locale();
		}

		// Same site TZ string the storefront form uses (wc_timezone_string), not a parallel UTC alias.
		$site_tz    = function_exists( 'wc_timezone_string' ) ? wc_timezone_string() : self::get_site_timezone_string();
		$site_city  = self::get_city_name( $site_tz );
		$site_short = self::get_timezone_short_name( $site_tz );
		$site_label = ( $site_city && $site_short ) ? $site_city . ' - ' . $site_short : ( $site_short ?: $site_tz );

		// Get WordPress timezone dropdown and enhance it.
		$wp_timezones = wp_timezone_choice( $selected ?: '__none__', $locale );
		$wp_timezones = preg_replace( '/<option value=""[^>]*>.*?<\/option>/i', '', $wp_timezones, 1 );

		// Enhance options with short names and title attributes.
		$wp_timezones = preg_replace_callback(
			'/<option([^>]*)value="([^"]*)"([^>]*)>([^<]*)<\/option>/',
			[ __CLASS__, 'enhance_timezone_option' ],
			$wp_timezones
		);

		$output = '';
		if ( $include_default ) {
			$sel = ( '' === $selected ) ? ' selected="selected"' : '';
			$output .= sprintf(
				'<option value=""%s title="%s">%s</option>',
				$sel,
				esc_attr( sprintf(
					'%s: %s - %s',
					__( 'Timezone', 'woocommerce-appointments' ),
					$site_tz,
					self::get_timezone_short_name( $site_tz )
				) ),
				/* translators: %s: default site timezone label (city and abbr, e.g. "Sydney - AEDT"). */
				sprintf( esc_html__( 'Default (%s)', 'woocommerce-appointments' ), esc_html( $site_label ) )
			);
		}

		return apply_filters( 'woocommerce_appointments_wp_timezone_choice', $output . $wp_timezones, $selected, $locale );
	}

	/**
	 * Callback for enhancing timezone dropdown options.
	 *
	 * @param array<int, string> $m Regex matches.
	 *
	 * @return string Enhanced option HTML.
	 */
	public static function enhance_timezone_option( array $m ): string {
		$full_tag    = $m[0];
		$attr_before = $m[1];
		$tz          = $m[2];
		$attr_after  = $m[3];
		$city        = $m[4];

		if ( empty( $tz ) || preg_match( '/^UTC[+-]?\d*/', $tz ) ) {
			return $full_tag;
		}

		$short = self::get_timezone_label( $tz );
		if ( $short && $short !== $city ) {
			$display  = $city . ' — ' . $short;
			$title    = sprintf( '%s: %s - %s', __( 'Timezone', 'woocommerce-appointments' ), $tz, self::get_timezone_short_name( $tz ) );
			$selected = ( false !== strpos( $attr_before . $attr_after, 'selected' ) ) ? ' selected="selected"' : '';
			return sprintf( '<option value="%s"%s title="%s">%s</option>', esc_attr( $tz ), $selected, esc_attr( $title ), esc_html( $display ) );
		}
		return $full_tag;
	}

	/**
	 * Appointment meta key for creation timezone.
	 *
	 * @var string
	 */
	const CREATION_TZ_META_KEY = '_creation_tz';

	/**
	 * Appointment meta key for inferred timezone flag.
	 *
	 * @var string
	 */
	const TIMEZONE_INFERRED_META_KEY = '_timezone_inferred';

	/**
	 * Get the site's timezone string.
	 *
	 * Returns the WordPress timezone setting as a proper timezone string.
	 * Falls back to UTC offset conversion if timezone_string is not set.
	 *
	 * @since 5.2.0
	 *
	 * @return string Timezone string (e.g., 'America/New_York' or 'UTC').
	 */
	public static function get_site_timezone_string(): string {
		$tz_string = get_option( 'timezone_string' );

		if ( $tz_string ) {
			return $tz_string;
		}

		// Fall back to UTC offset.
		$offset = (float) get_option( 'gmt_offset', 0 );

		if ( 0.0 === $offset ) {
			return 'UTC';
		}

		// Try to get a named timezone from the offset.
		$tz_name = timezone_name_from_abbr( '', (int) ( $offset * HOUR_IN_SECONDS ), 0 );

		if ( $tz_name ) {
			return $tz_name;
		}

		// Fall back to manual UTC offset format.
		$hours   = (int) $offset;
		$minutes = abs( ( $offset - $hours ) * 60 );
		$sign    = $offset >= 0 ? '+' : '-';

		return sprintf( 'UTC%s%d:%02d', $sign, abs( $hours ), $minutes );
	}

	/**
	 * Whether to show timezone display and use timezone conversions for the given context/user.
	 *
	 * Use this to disable timezone display for sites that only operate locally.
	 * Filter allows disabling on frontend only, admin only, or for specific user IDs.
	 *
	 * @since 5.2.4
	 *
	 * @param string   $context  'frontend' or 'admin'.
	 * @param int|null $user_id  User ID for whom we're displaying (e.g. current user on frontend, profile user in admin). Null = current user.
	 *
	 * @return bool True to show timezone and apply conversions, false to hide and use site timezone only.
	 */
	public static function should_show_timezone( string $context, ?int $user_id = null ): bool {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}

		// Read admin setting: 'all', 'frontend', 'admin', or 'disabled'.
		$setting = get_option( 'wc_appointments_timezone_display', 'all' );
		$setting = (string) apply_filters( 'wc_appointments_timezone_display', $setting, $context, $user_id );

		switch ( $setting ) {
			case 'disabled':
				$show = false;
				break;
			case 'frontend':
				$show = ( 'frontend' === $context );
				break;
			case 'admin':
				$show = ( 'admin' === $context );
				break;
			case 'all':
			default:
				$show = true;
				break;
		}

		// Filter can override the setting.
		return (bool) apply_filters( 'woocommerce_appointments_show_timezone', $show, $context, $user_id );
	}

	/**
	 * Get a user's preferred timezone.
	 *
	 * Priority:
	 * 1. User's saved preference (user meta)
	 * 2. Site timezone (fallback)
	 *
	 * @since 5.2.0
	 *
	 * @param int|null $user_id User ID. Defaults to current user.
	 *
	 * @return string Timezone string.
	 */
	public static function get_user_timezone( ?int $user_id = null ): string {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}

		if ( $user_id ) {
			$user_tz = get_user_meta( $user_id, self::USER_META_KEY, true );
			if ( $user_tz && self::is_valid_timezone( $user_tz ) ) {
				return $user_tz;
			}
		}

		return self::get_site_timezone_string();
	}

	/**
	 * Save a user's timezone preference.
	 *
	 * Empty string means "use default (site timezone)" - this is the preferred
	 * approach as it dynamically follows the site timezone if it changes.
	 *
	 * @since 5.2.0
	 *
	 * @param int    $user_id  User ID.
	 * @param string $timezone Timezone string to save. Empty = use default.
	 *
	 * @return bool True on success, false on failure or invalid timezone.
	 */
	public static function save_user_timezone( int $user_id, string $timezone ): bool {
		// Empty or site timezone means "use default" — do not persist a fixed IANA string.
		if ( '' === $timezone || $timezone === self::get_site_timezone_string() ) {
			delete_user_meta( $user_id, self::USER_META_KEY );
			return true;
		}

		if ( ! self::is_valid_timezone( $timezone ) ) {
			return false;
		}

		return (bool) update_user_meta( $user_id, self::USER_META_KEY, $timezone );
	}

	/**
	 * Check if a user is using the default (site) timezone.
	 *
	 * @since 5.2.0
	 *
	 * @param int|null $user_id User ID. Defaults to current user.
	 *
	 * @return bool True if using default, false if custom timezone set.
	 */
	public static function is_using_default_timezone( ?int $user_id = null ): bool {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}

		if ( ! $user_id ) {
			return true;
		}

		$user_tz = get_user_meta( $user_id, self::USER_META_KEY, true );
		return empty( $user_tz );
	}

	/**
	 * Get the raw stored timezone preference (may be empty for default).
	 *
	 * Use this when you need to know if user has explicitly set a timezone
	 * vs using the default. Empty string means default/site timezone.
	 *
	 * @since 5.2.0
	 *
	 * @param int|null $user_id User ID. Defaults to current user.
	 *
	 * @return string Stored timezone or empty string for default.
	 */
	public static function get_user_timezone_raw( ?int $user_id = null ): string {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}

		if ( ! $user_id ) {
			return '';
		}

		return (string) get_user_meta( $user_id, self::USER_META_KEY, true );
	}

	/**
	 * Get staff member's timezone preference.
	 *
	 * Falls back to site timezone if staff hasn't set a preference.
	 *
	 * @since 5.2.0
	 *
	 * @param int $staff_id Staff user ID.
	 *
	 * @return string Timezone string.
	 */
	public static function get_staff_timezone( int $staff_id ): string {
		$staff_tz = get_user_meta( $staff_id, self::USER_META_KEY, true );
		if ( $staff_tz && self::is_valid_timezone( $staff_tz ) ) {
			return $staff_tz;
		}
		return self::get_site_timezone_string();
	}

	/**
	 * Get the current admin user's timezone preference.
	 *
	 * For admin views, only staff members (service providers) can have their
	 * own timezone - they legitimately need it when working remotely from a
	 * different location than the business.
	 *
	 * Regular admins/shop managers always see site timezone for consistency,
	 * preventing confusion when they accidentally set a timezone preference
	 * via My Account or frontend browsing.
	 *
	 * @since 5.2.0
	 *
	 * @return string Timezone string.
	 */
	public static function get_admin_user_timezone(): string {
		if ( ! is_user_logged_in() ) {
			return self::get_site_timezone_string();
		}

		$user_id = get_current_user_id();

		// Only staff members (not admins) can use their profile timezone in admin.
		// Staff are service providers who may work remotely and need their local time.
		// Regular admins always see site timezone for consistency.
		$is_staff_only = class_exists( 'WC_Appointments_Staff_Permissions' )
			&& WC_Appointments_Staff_Permissions::is_staff_user( $user_id );

		if ( $is_staff_only ) {
			return self::get_user_timezone( $user_id );
		}

		// Regular admins/shop managers always use site timezone.
		return self::get_site_timezone_string();
	}

	/**
	 * Format a timestamp with timezone indicator if different from site timezone.
	 *
	 * Returns formatted date/time with optional timezone abbreviation shown
	 * discretely when the display timezone differs from site timezone.
	 *
	 * @since 5.2.0
	 *
	 * @param int         $timestamp   Unix timestamp.
	 * @param string      $format      PHP date format.
	 * @param string|null $timezone    Display timezone (null = site timezone).
	 * @param bool        $show_tz     Force show/hide timezone indicator.
	 *
	 * @return string Formatted date with optional timezone indicator.
	 */
	public static function format_with_timezone_indicator( int $timestamp, string $format, ?string $timezone = null, ?bool $show_tz = null ): string {
		$site_tz    = self::get_site_timezone_string();
		$display_tz = $timezone ?: $site_tz;

		// Determine if we should show the timezone indicator.
		$tz_differs = $display_tz !== $site_tz;
		if ( $show_tz === null ) {
			$show_tz = $tz_differs;
		}
		// When timezone display is disabled (e.g. admin or frontend), never append abbr.
		if ( is_admin() && ! self::should_show_timezone( 'admin', get_current_user_id() ) ) {
			$show_tz = false;
		}

		try {
			// Our timestamps are "site-tz-as-UTC" integers: date('H:i', $ts) returns
			// the site-local wall-clock time because PHP runs in UTC mode.
			// Extract wall-clock, create DateTime in site TZ, then convert to display TZ.
			$wall_clock = date( 'Y-m-d H:i:s', $timestamp );
			$dt         = new DateTime( $wall_clock, new DateTimeZone( $site_tz ) );

			if ( $tz_differs ) {
				$dt->setTimezone( new DateTimeZone( $display_tz ) );
			}

			$formatted = $dt->format( $format );

			if ( $show_tz && $tz_differs ) {
				$formatted .= self::build_timezone_indicator_html( $display_tz, 'wc-appointments-tz-abbr', $dt );
			}

			return $formatted;
		} catch ( Exception $e ) {
			return date_i18n( $format, $timestamp );
		}
	}

	/**
	 * Build uniform timezone indicator HTML.
	 *
	 * Creates consistent timezone display across admin and frontend.
	 * Format: ShortName with hover "Timezone: Europe/London - BST"
	 *
	 * @since 5.2.1
	 *
	 * @param string                     $timezone  Timezone identifier.
	 * @param string                     $css_class Optional CSS class. Default 'wc-appointments-tz-abbr'.
	 * @param DateTimeInterface|int|null $at        Optional. Instant for DST-correct abbr. Null = now.
	 *
	 * @return string HTML abbr element.
	 */
	public static function build_timezone_indicator_html( string $timezone, string $css_class = 'wc-appointments-tz-abbr', $at = null ): string {
		// When timezone display is disabled via filter, never output abbr labels.
		$context = is_admin() ? 'admin' : 'frontend';
		if ( ! self::should_show_timezone( $context, get_current_user_id() ) ) {
			return '';
		}

		$tz_abbr = self::get_timezone_short_name( $timezone, $at );
		$title   = sprintf( '%s: %s - %s', __( 'Timezone', 'woocommerce-appointments' ), $timezone, $tz_abbr );

		return sprintf(
			' <abbr class="%s" aria-label="%s" tabindex="0">%s</abbr>',
			esc_attr( $css_class ),
			esc_attr( $title ),
			esc_html( $tz_abbr )
		);
	}

	/**
	 * Timezone indicator HTML for My Account appointment tables.
	 *
	 * @since 5.4.0
	 * @return string
	 */
	public static function get_my_account_indicator_html(): string {
		$display_tz = self::get_booking_form_timezone();
		return $display_tz ? self::build_timezone_indicator_html( $display_tz ) : '';
	}

	/**
	 * Format customer timezone context for admin/staff display.
	 *
	 * Returns a rich, human-readable string that shows the customer's timezone
	 * with the appointment time converted to their local time and the offset
	 * difference from the viewer's timezone. Only returns content when the
	 * customer's timezone actually differs from the viewer's timezone.
	 *
	 * The viewer timezone defaults to the current admin user's timezone so that
	 * the offset label (e.g. "6h behind") reflects the difference relative to
	 * the person viewing the appointment, not the site timezone.
	 *
	 * Examples:
	 * - HTML: "New York (ET) — Jan 15, 2:00 PM (6h behind)"
	 * - Plain: "New York (ET) — Jan 15, 2:00 PM (6h behind)"
	 * - Half-hour offsets: "Mumbai (IST) — Jan 15, 7:30 PM (4h 30min ahead)"
	 *
	 * @since 5.3.0
	 *
	 * @param WC_Appointment $appointment  Appointment object.
	 * @param bool           $plain_text   Whether to return plain text (true) or HTML (false).
	 * @param string         $viewer_tz    Optional. The viewer's timezone to compare against.
	 *                                     Defaults to the current admin user's timezone.
	 *
	 * @return string Contextual timezone string for admin display, or empty string if TZ matches viewer.
	 */
	public static function format_customer_timezone_context_for_admin( $appointment, bool $plain_text = false, string $viewer_tz = '' ): string {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return '';
		}

		$customer_tz = self::get_appointment_customer_timezone( $appointment );
		$site_tz     = self::get_site_timezone_string();

		// Determine the viewer's timezone: explicit param > admin user preference > site timezone.
		if ( empty( $viewer_tz ) ) {
			$viewer_tz = self::get_admin_user_timezone();
		}

		// Only show when customer TZ differs from the viewer's TZ.
		if ( $customer_tz === $viewer_tz ) {
			return '';
		}

		// All-day appointments don't benefit from timezone context.
		if ( $appointment->is_all_day() ) {
			return '';
		}

		$start_ts = $appointment->get_start();
		if ( ! $start_ts ) {
			// No start time — just show timezone name.
			return self::format_timezone_for_display( $customer_tz );
		}

		// Convert appointment start time to customer's timezone.
		try {
			$site_tz_obj     = new DateTimeZone( $site_tz );
			$customer_tz_obj = new DateTimeZone( $customer_tz );
			$viewer_tz_obj   = new DateTimeZone( $viewer_tz );

			// Interpret stored timestamp as site timezone wall-clock time.
			$site_dt = new DateTime( date( 'Y-m-d H:i:s', $start_ts ), $site_tz_obj );

			// Get offsets at this specific moment (DST-aware).
			// Offset difference is relative to the viewer's timezone, not the site timezone.
			$viewer_offset   = $viewer_tz_obj->getOffset( $site_dt );
			$customer_offset = $customer_tz_obj->getOffset( $site_dt );
			$diff_seconds    = $customer_offset - $viewer_offset;

			// Convert to customer timezone.
			$customer_dt = clone $site_dt;
			$customer_dt->setTimezone( $customer_tz_obj );

			// Format the customer's local time.
			$date_format = wc_appointments_date_format();
			$time_format = wc_appointments_time_format();
			$customer_time_str = $customer_dt->format(
				self::convert_php_date_format( $date_format . ', ' . $time_format )
			);

			// Build the offset difference label.
			$offset_label = self::format_offset_difference( $diff_seconds );

			// Build timezone display name (abbr at appointment instant).
			$tz_display = self::format_timezone_for_display( $customer_tz, $customer_dt );

			if ( $plain_text ) {
				/* translators: %s: customer's local appointment time, e.g. "Jan 15, 2:00 PM" */
				return $tz_display . ' — ' . $customer_time_str . ( $offset_label ? ' (' . $offset_label . ')' : '' );
			}

			// HTML version with styling.
			/* translators: %s: customer's local appointment time, e.g. "Jan 15, 2:00 PM" */
			$offset_html = $offset_label ? ' <span class="wca-tz-offset">(' . esc_html( $offset_label ) . ')</span>' : '';

			return sprintf(
				'<span class="wca-customer-tz-context">%s — %s%s</span>',
				esc_html( $tz_display ),
				esc_html( $customer_time_str ),
				$offset_html
			);
		} catch ( Exception $e ) {
			// Fallback to simple timezone name.
			return self::format_timezone_for_display( $customer_tz );
		}
	}

	/**
	 * Format an offset difference as a human-readable string.
	 *
	 * @since 5.3.0
	 *
	 * @param int $diff_seconds Difference in seconds (positive = ahead, negative = behind).
	 *
	 * @return string e.g. "6h behind", "4h 30min ahead", or empty string if same.
	 */
	public static function format_offset_difference( int $diff_seconds ): string {
		if ( 0 === $diff_seconds ) {
			return '';
		}

		$abs_seconds = abs( $diff_seconds );
		$hours       = intdiv( $abs_seconds, 3600 );
		$minutes     = ( $abs_seconds % 3600 ) / 60;

		if ( $hours > 0 && $minutes > 0 ) {
			/* translators: 1: hours, 2: minutes */
			$amount = sprintf( __( '%1$dh %2$dmin', 'woocommerce-appointments' ), $hours, $minutes );
		} elseif ( $hours > 0 ) {
			/* translators: %d: hours (duration) */
			$amount = sprintf( _x( '%dh', 'duration hours', 'woocommerce-appointments' ), $hours );
		} else {
			/* translators: %d: minutes */
			$amount = sprintf( __( '%dmin', 'woocommerce-appointments' ), $minutes );
		}

		if ( $diff_seconds > 0 ) {
			/* translators: %s: time amount, e.g. "6h" or "4h 30min" */
			return sprintf( __( '%s ahead', 'woocommerce-appointments' ), $amount );
		}

		/* translators: %s: time amount, e.g. "6h" or "4h 30min" */
		return sprintf( __( '%s behind', 'woocommerce-appointments' ), $amount );
	}

	/**
	 * Build a compact timezone abbreviation HTML element.
	 *
	 * Creates an <abbr> element where:
	 * - Visible text: "City (ABBR)" e.g. "New York (ET)"
	 * - Tooltip: "City (ABBR) — 18/03/2026, 07:00 (5h behind)" relative to $viewer_tz
	 *
	 * For plain text: returns "City (ABBR)" only; the tooltip data is omitted.
	 *
	 * Returns empty string when:
	 * - Timezone display is disabled
	 * - $subject_tz equals $viewer_tz
	 * - Appointment is all-day
	 *
	 * @since 5.3.0
	 *
	 * @param string         $subject_tz  The timezone to display (customer or staff).
	 * @param string         $viewer_tz   The viewer's timezone for offset calculation.
	 * @param WC_Appointment $appointment Appointment object (for start time context).
	 * @param bool           $plain_text  Whether to return plain text instead of HTML.
	 * @param string         $css_class   Optional CSS class. Default 'wca-tz-context-abbr'.
	 *
	 * @return string HTML <abbr> element, plain text label, or empty string.
	 */
	public static function build_timezone_context_abbr(
		string $subject_tz,
		string $viewer_tz,
		$appointment,
		bool $plain_text = false,
		string $css_class = 'wca-tz-context-abbr'
	): string {
		if ( empty( $subject_tz ) || empty( $viewer_tz ) ) {
			return '';
		}

		// Same timezone — nothing to show.
		if ( $subject_tz === $viewer_tz ) {
			return '';
		}

		// All-day appointments don't benefit from timezone context.
		if ( is_a( $appointment, 'WC_Appointment' ) && $appointment->is_all_day() ) {
			return '';
		}

		// If no appointment or no start time, return just the label (abbr at now).
		$start_ts = is_a( $appointment, 'WC_Appointment' ) ? $appointment->get_start() : 0;
		if ( ! $start_ts ) {
			$tz_display = self::format_timezone_for_display( $subject_tz );
			if ( empty( $tz_display ) ) {
				return '';
			}
			if ( $plain_text ) {
				return $tz_display;
			}
			return sprintf(
				' <abbr class="%s" aria-label="%s" tabindex="0">%s</abbr>',
				esc_attr( $css_class ),
				esc_attr( $tz_display ),
				esc_html( $tz_display )
			);
		}

		// Label first so catch can fall back if rich tooltip build fails.
		$tz_display = self::format_timezone_for_display( $subject_tz );
		if ( empty( $tz_display ) ) {
			return '';
		}

		try {
			$site_tz_obj    = new DateTimeZone( self::get_site_timezone_string() );
			$subject_tz_obj = new DateTimeZone( $subject_tz );
			$viewer_tz_obj  = new DateTimeZone( $viewer_tz );

			$site_dt = new DateTime( date( 'Y-m-d H:i:s', $start_ts ), $site_tz_obj );

			$viewer_offset  = $viewer_tz_obj->getOffset( $site_dt );
			$subject_offset = $subject_tz_obj->getOffset( $site_dt );
			$diff_seconds   = $subject_offset - $viewer_offset;

			$subject_dt = clone $site_dt;
			$subject_dt->setTimezone( $subject_tz_obj );

			$tz_display = self::format_timezone_for_display( $subject_tz, $subject_dt );

			$date_format    = wc_appointments_date_format();
			$time_format    = wc_appointments_time_format();
			$local_time_str = $subject_dt->format( self::convert_php_date_format( $date_format . ', ' . $time_format ) );
			$offset_label   = self::format_offset_difference( $diff_seconds );

			// Build tooltip: "New York (EDT) - 18/03/2026, 07:00 (5h behind)"
			$tooltip = $tz_display . ' — ' . $local_time_str;
			if ( $offset_label ) {
				$tooltip .= ' (' . $offset_label . ')';
			}

			if ( $plain_text ) {
				return $tz_display;
			}

			return sprintf(
				' <abbr class="%s" aria-label="%s" tabindex="0">%s</abbr>',
				esc_attr( $css_class ),
				esc_attr( $tooltip ),
				esc_html( $tz_display )
			);
		} catch ( Exception $e ) {
			if ( $plain_text ) {
				return $tz_display;
			}
			return sprintf(
				' <abbr class="%s" aria-label="%s" tabindex="0">%s</abbr>',
				esc_attr( $css_class ),
				esc_attr( $tz_display ),
				esc_html( $tz_display )
			);
		}
	}

	/**
	 * Build timezone context abbr for a staff member on an appointment.
	 *
	 * Shows the staff member's timezone relative to the viewer (admin/recipient).
	 * Returns empty string when staff TZ matches the viewer's TZ or when timezone
	 * display is disabled.
	 *
	 * @since 5.3.0
	 *
	 * @param int            $staff_id    Staff user ID.
	 * @param WC_Appointment $appointment Appointment object.
	 * @param bool           $plain_text  Whether to return plain text.
	 * @param string         $viewer_tz   Optional. Viewer's timezone. Defaults to admin user TZ.
	 *
	 * @return string HTML <abbr> or plain text, or empty string.
	 */
	public static function build_staff_timezone_abbr(
		int $staff_id,
		$appointment,
		bool $plain_text = false,
		string $viewer_tz = ''
	): string {
		if ( ! $staff_id ) {
			return '';
		}

		$staff_tz = self::get_staff_timezone( $staff_id );
		if ( empty( $viewer_tz ) ) {
			$viewer_tz = self::get_admin_user_timezone();
		}

		return self::build_timezone_context_abbr( $staff_tz, $viewer_tz, $appointment, $plain_text );
	}

	/**
	 * Build timezone context abbr for the customer on an appointment.
	 *
	 * Shows the customer's timezone relative to the viewer (admin/recipient).
	 * Returns empty string when customer TZ matches the viewer's TZ or when
	 * timezone display is disabled.
	 *
	 * @since 5.3.0
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 * @param bool           $plain_text  Whether to return plain text.
	 * @param string         $viewer_tz   Optional. Viewer's timezone. Defaults to admin user TZ.
	 *
	 * @return string HTML <abbr> or plain text, or empty string.
	 */
	public static function build_customer_timezone_abbr(
		$appointment,
		bool $plain_text = false,
		string $viewer_tz = ''
	): string {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return '';
		}

		$customer_tz = self::get_appointment_customer_timezone( $appointment );
		if ( empty( $viewer_tz ) ) {
			$viewer_tz = self::get_admin_user_timezone();
		}

		return self::build_timezone_context_abbr( $customer_tz, $viewer_tz, $appointment, $plain_text );
	}

	/**
	 * Get customer timezone context data for JavaScript/REST API consumption.
	 *
	 * Returns structured data that can be used by the admin calendar modal
	 * to display customer timezone context without additional PHP rendering.
	 *
	 * The viewer timezone defaults to the current admin user's timezone so that
	 * the offset label reflects the difference relative to the person viewing
	 * the appointment, not the site timezone.
	 *
	 * @since 5.3.0
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 * @param string         $viewer_tz   Optional. The viewer's timezone to compare against.
	 *                                    Defaults to the current admin user's timezone.
	 *
	 * @return array{show: bool, tz_display: string, local_time: string, offset_label: string, raw_tz: string}
	 */
	public static function get_customer_timezone_context_data( $appointment, string $viewer_tz = '' ): array {
		$default = [
			'show'         => false,
			'tz_display'   => '',
			'local_time'   => '',
			'offset_label' => '',
			'raw_tz'       => '',
		];

		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return $default;
		}

		$customer_tz = self::get_appointment_customer_timezone( $appointment );
		$site_tz     = self::get_site_timezone_string();

		// Determine the viewer's timezone: explicit param > admin user preference > site timezone.
		if ( empty( $viewer_tz ) ) {
			$viewer_tz = self::get_admin_user_timezone();
		}

		if ( $customer_tz === $viewer_tz || $appointment->is_all_day() ) {
			return $default;
		}

		$start_ts = $appointment->get_start();
		if ( ! $start_ts ) {
			return array_merge( $default, [
				'show'       => true,
				'tz_display' => self::format_timezone_for_display( $customer_tz ),
				'raw_tz'     => $customer_tz,
			] );
		}

		try {
			$site_tz_obj     = new DateTimeZone( $site_tz );
			$customer_tz_obj = new DateTimeZone( $customer_tz );
			$viewer_tz_obj   = new DateTimeZone( $viewer_tz );

			$site_dt         = new DateTime( date( 'Y-m-d H:i:s', $start_ts ), $site_tz_obj );
			$viewer_offset   = $viewer_tz_obj->getOffset( $site_dt );
			$customer_offset = $customer_tz_obj->getOffset( $site_dt );
			$diff_seconds    = $customer_offset - $viewer_offset;

			$customer_dt = clone $site_dt;
			$customer_dt->setTimezone( $customer_tz_obj );

			$date_format = wc_appointments_date_format();
			$time_format = wc_appointments_time_format();

			return [
				'show'         => true,
				'tz_display'   => self::format_timezone_for_display( $customer_tz, $customer_dt ),
				'local_time'   => $customer_dt->format( self::convert_php_date_format( $date_format . ', ' . $time_format ) ),
				'offset_label' => self::format_offset_difference( $diff_seconds ),
				'raw_tz'       => $customer_tz,
			];
		} catch ( Exception $e ) {
			return array_merge( $default, [
				'show'       => true,
				'tz_display' => self::format_timezone_for_display( $customer_tz ),
				'raw_tz'     => $customer_tz,
			] );
		}
	}

	/**
	 * Format a timezone identifier for human-readable display.
	 *
	 * Returns a friendly string like "New York (EDT)" for named timezones,
	 * or "UTC+5:30" for offset-only timezones. Used in email notifications
	 * and admin views to label the customer's timezone.
	 *
	 * @since 5.3.0
	 *
	 * @param string                     $timezone Timezone identifier (e.g., 'America/New_York').
	 * @param DateTimeInterface|int|null $at       Optional. Instant for DST-correct abbr. Null = now.
	 *
	 * @return string Human-readable label (e.g., 'New York (EDT)').
	 */
	public static function format_timezone_for_display( string $timezone, $at = null ): string {
		if ( empty( $timezone ) ) {
			return '';
		}

		$abbr = self::get_timezone_short_name( $timezone, $at );

		// For UTC offset formats, the abbreviation is already the full useful label.
		if ( preg_match( '/^UTC([+-]\d{1,2}(:\d{2})?)?$/', $timezone ) ) {
			return $abbr ?: $timezone;
		}

		$city = self::get_city_name( $timezone );
		if ( $city && $abbr && $city !== $abbr ) {
			return $city . ' (' . $abbr . ')';
		}

		if ( $abbr ) {
			return $abbr;
		}

		return $timezone;
	}

	/**
	 * Validate a timezone string.
	 *
	 * @since 5.2.0
	 *
	 * @param string $timezone Timezone string to validate.
	 *
	 * @return bool True if valid.
	 */
	public static function is_valid_timezone( string $timezone ): bool {
		if ( empty( $timezone ) ) {
			return false;
		}

		// Check against PHP's timezone identifiers.
		if ( in_array( $timezone, timezone_identifiers_list(), true ) ) {
			return true;
		}

		// Also accept UTC offset formats (UTC, UTC+1, UTC-5:30, etc.).
		if ( preg_match( '/^UTC([+-]\d{1,2}(:\d{2})?)?$/', $timezone ) ) {
			return true;
		}

		// Try to create a DateTimeZone to validate.
		try {
			new DateTimeZone( $timezone );
			return true;
		} catch ( Exception $e ) {
			return false;
		}
	}

	/**
	 * Convert a timestamp from one timezone to another.
	 *
	 * @since 5.2.0
	 *
	 * @param int    $timestamp Unix timestamp.
	 * @param string $from_tz   Source timezone string.
	 * @param string $to_tz     Target timezone string.
	 *
	 * @return int Converted Unix timestamp.
	 */
	public static function convert_timestamp( int $timestamp, string $from_tz, string $to_tz ): int {
		if ( $from_tz === $to_tz ) {
			return $timestamp;
		}

		try {
			// Our timestamps are "site-tz-as-UTC" integers: date('H:i', $ts) returns
			// the source-timezone wall-clock time because PHP runs in UTC mode.
			// Extract wall-clock components, then create DateTime in the source timezone.
			// DateTime::setTimezone() handles DST correctly.
			$wall_clock = date( 'Y-m-d H:i:s', $timestamp );
			$dt         = new DateTime( $wall_clock, new DateTimeZone( $from_tz ) );
			$dt->setTimezone( new DateTimeZone( $to_tz ) );

			// Return a site-tz-as-UTC style integer: extract the converted wall-clock
			// and run through strtotime() so date('H:i', $result) gives target-tz time.
			return (int) strtotime( $dt->format( 'Y-m-d H:i:s' ) );
		} catch ( Exception $e ) {
			return $timestamp;
		}
	}

	/**
	 * Get the effective customer timezone for an appointment.
	 *
	 * Priority:
	 * 1. Customer's account timezone preference (most authoritative)
	 * 2. Appointment's stored local_timezone (booking-time fallback)
	 * 3. Site timezone (last resort)
	 *
	 * @since 5.2.0
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 *
	 * @return string Timezone string.
	 */
	public static function get_appointment_customer_timezone( $appointment ): string {
		// 1. Check customer's account preference (most authoritative).
		if ( method_exists( $appointment, 'get_customer_id' ) ) {
			$customer_id = $appointment->get_customer_id();
			if ( $customer_id ) {
				$user_tz = get_user_meta( $customer_id, self::USER_META_KEY, true );
				if ( $user_tz && self::is_valid_timezone( $user_tz ) ) {
					return $user_tz;
				}
			}
		}

		// 2. Check appointment's stored timezone (booking-time fallback).
		if ( method_exists( $appointment, 'get_local_timezone' ) ) {
			$local_tz = $appointment->get_local_timezone();
			if ( $local_tz && self::is_valid_timezone( $local_tz ) ) {
				return $local_tz;
			}
		}

		// 3. Fall back to site timezone.
		return self::get_site_timezone_string();
	}

	/**
	 * Get the true UTC timestamp for an appointment.
	 *
	 * Since appointments store timestamps that semantically represent site timezone,
	 * this method converts them to true UTC for external systems.
	 *
	 * @since 5.2.0
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 * @param string         $which       'start' or 'end'.
	 *
	 * @return DateTimeImmutable|null DateTime in UTC, or null on error.
	 */
	public static function get_appointment_utc( $appointment, string $which = 'start' ): ?DateTimeImmutable {
		try {
			$timestamp = 'end' === $which ? $appointment->get_end() : $appointment->get_start();

			if ( ! $timestamp ) {
				return null;
			}

			// Get the creation timezone (or site timezone as fallback).
			$creation_tz = $appointment->get_meta( self::CREATION_TZ_META_KEY );
			if ( ! $creation_tz || ! self::is_valid_timezone( $creation_tz ) ) {
				$creation_tz = self::get_site_timezone_string();
			}

			$site_tz = new DateTimeZone( $creation_tz );
			$utc_tz  = new DateTimeZone( 'UTC' );

			// Interpret stored timestamp as site timezone time.
			$as_site_time = date( 'Y-m-d H:i:s', $timestamp );
			$dt           = new DateTimeImmutable( $as_site_time, $site_tz );

			// Convert to UTC.
			return $dt->setTimezone( $utc_tz );
		} catch ( Exception $e ) {
			return null;
		}
	}

	/**
	 * Get appointment start in true UTC.
	 *
	 * @since 5.2.0
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 *
	 * @return DateTimeImmutable|null DateTime in UTC.
	 */
	public static function get_appointment_utc_start( $appointment ): ?DateTimeImmutable {
		return self::get_appointment_utc( $appointment, 'start' );
	}

	/**
	 * Get appointment end in true UTC.
	 *
	 * @since 5.2.0
	 *
	 * @param WC_Appointment $appointment Appointment object.
	 *
	 * @return DateTimeImmutable|null DateTime in UTC.
	 */
	public static function get_appointment_utc_end( $appointment ): ?DateTimeImmutable {
		return self::get_appointment_utc( $appointment, 'end' );
	}

	/**
	 * Format appointment time for display in customer's timezone.
	 *
	 * @since 5.2.0
	 *
	 * @param WC_Appointment $appointment  Appointment object.
	 * @param string         $which        'start' or 'end'.
	 * @param string|null    $date_format  Date format. Default: site setting.
	 * @param string|null    $time_format  Time format. Default: site setting.
	 * @param bool           $show_tz_name Whether to append timezone name.
	 *
	 * @return string Formatted date/time string.
	 */
	public static function format_appointment_time_for_customer(
		$appointment,
		string $which = 'start',
		?string $date_format = null,
		?string $time_format = null,
		bool $show_tz_name = true
	): string {
		$timestamp = 'end' === $which ? $appointment->get_end() : $appointment->get_start();

		if ( ! $timestamp ) {
			return '';
		}

		if ( null === $date_format ) {
			$date_format = wc_appointments_date_format();
		}
		if ( null === $time_format ) {
			$time_format = ', ' . wc_appointments_time_format();
		}

		$customer_tz = self::get_appointment_customer_timezone( $appointment );
		$site_tz     = self::get_site_timezone_string();

		// If customer timezone differs from site, convert.
		if ( $customer_tz !== $site_tz ) {
			$converted = wc_appointment_timezone_locale( 'site', 'user', $timestamp, 'U', $customer_tz );
			$formatted = date_i18n( $date_format . $time_format, $converted );

			if ( $show_tz_name ) {
				$at = self::get_appointment_utc( $appointment, $which );
				$formatted .= ' (' . wc_appointment_get_timezone_name( $customer_tz, false, $at ) . ')';
			}

			return $formatted;
		}

		return date_i18n( $date_format . $time_format, $timestamp );
	}

	/**
	 * Check if a timestamp falls during a DST transition period.
	 *
	 * @since 5.2.0
	 *
	 * @param int    $timestamp Unix timestamp.
	 * @param string $timezone  Timezone string.
	 *
	 * @return array{is_transition: bool, type: string|null, offset_change: int}
	 */
	public static function check_dst_transition( int $timestamp, string $timezone ): array {
		$result = [
			'is_transition' => false,
			'type'          => null,
			'offset_change' => 0,
		];

		try {
			$tz          = new DateTimeZone( $timezone );
			$transitions = $tz->getTransitions( $timestamp - 7200, $timestamp + 7200 );

			foreach ( $transitions as $transition ) {
				if ( abs( $transition['ts'] - $timestamp ) < 3600 ) {
					$result['is_transition'] = true;
					$result['type']          = $transition['isdst'] ? 'spring_forward' : 'fall_back';
					$result['offset_change'] = $transition['offset'];
					break;
				}
			}
		} catch ( Exception $e ) {
			// Return default result on error.
		}

		return $result;
	}

	/**
	 * Add duration to timestamp respecting DST.
	 *
	 * Uses DateTimeImmutable::modify() which is DST-aware and maintains
	 * wall-clock time across DST boundaries.
	 *
	 * @since 5.2.0
	 *
	 * @param int    $timestamp Base timestamp.
	 * @param int    $duration  Duration value.
	 * @param string $unit      Duration unit (minute, hour, day, month).
	 * @param string $timezone  Timezone for calculation.
	 *
	 * @return int Resulting timestamp.
	 */
	public static function add_duration_dst_safe( int $timestamp, int $duration, string $unit, string $timezone ): int {
		try {
			$tz = new DateTimeZone( $timezone );
			$dt = ( new DateTimeImmutable( '@' . $timestamp ) )->setTimezone( $tz );

			switch ( $unit ) {
				case 'minute':
					$dt = $dt->modify( "+{$duration} minutes" );
					break;
				case 'hour':
					$dt = $dt->modify( "+{$duration} hours" );
					break;
				case 'day':
					$dt = $dt->modify( "+{$duration} days" );
					break;
				case 'month':
					$dt = $dt->modify( "+{$duration} months" );
					break;
				default:
					$dt = $dt->modify( "+{$duration} {$unit}s" );
			}

			return $dt->getTimestamp();
		} catch ( Exception $e ) {
			// Fall back to simple arithmetic.
			$multipliers = [
				'minute' => MINUTE_IN_SECONDS,
				'hour'   => HOUR_IN_SECONDS,
				'day'    => DAY_IN_SECONDS,
				'month'  => MONTH_IN_SECONDS,
			];

			$multiplier = $multipliers[ $unit ] ?? MINUTE_IN_SECONDS;
			return $timestamp + ( $duration * $multiplier );
		}
	}

	/**
	 * Get timezone offset in seconds for a specific timestamp.
	 *
	 * This is DST-aware and returns the correct offset for the given moment.
	 *
	 * @since 5.2.0
	 *
	 * @param string $timezone  Timezone string.
	 * @param int    $timestamp Unix timestamp (default: now).
	 *
	 * @return int Offset in seconds.
	 */
	public static function get_timezone_offset( string $timezone, int $timestamp = 0 ): int {
		if ( 0 === $timestamp ) {
			$timestamp = time();
		}

		try {
			$tz = new DateTimeZone( $timezone );
			$dt = new DateTimeImmutable( '@' . $timestamp );
			return $tz->getOffset( $dt );
		} catch ( Exception $e ) {
			return 0;
		}
	}

	/**
	 * Get human-readable timezone name.
	 *
	 * @since 5.2.0
	 *
	 * @param string $timezone Timezone string.
	 *
	 * @return string Short timezone name (e.g., 'CEST', 'BST').
	 */
	public static function get_timezone_display_name( string $timezone ): string {
		return self::get_timezone_short_name( $timezone );
	}

	/**
	 * Get list of common timezones for dropdown.
	 *
	 * @since 5.2.0
	 *
	 * @param string $selected Currently selected timezone.
	 *
	 * @return string HTML options for select element.
	 */
	public static function get_timezone_options( string $selected = '' ): string {
		return self::get_timezone_dropdown( $selected );
	}

	/**
	 * Detect browser timezone from JavaScript.
	 *
	 * Returns the timezone string that was detected by JavaScript
	 * and stored in a cookie. Only used for frontend contexts.
	 *
	 * Admin users should never have their display timezone determined by a
	 * frontend cookie - this prevents confusion when admins browse the frontend
	 * (selecting a timezone) and later manage appointments in wp-admin where
	 * they expect consistent site-timezone or profile-based display.
	 *
	 * @since 5.2.0
	 *
	 * @return string|null Browser timezone or null if not detected or in admin context.
	 */
	public static function get_browser_timezone(): ?string {
		// Never use cookie timezone in admin context. Admins should use their
		// profile timezone (staff) or site timezone for consistent display.
		// This prevents confusion when frontend browsing affects admin views.
		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST && is_user_logged_in() && current_user_can( 'edit_others_posts' ) ) ) {
			return null;
		}

		// When timezone display is disabled for frontend, ignore the browser cookie
		// so all paths fall back to site timezone automatically.
		if ( ! self::should_show_timezone( 'frontend', get_current_user_id() ) ) {
			return null;
		}

		if ( isset( $_COOKIE['appointments_time_zone'] ) ) {
			$tz = sanitize_text_field( wp_unslash( $_COOKIE['appointments_time_zone'] ) );
			if ( self::is_valid_timezone( $tz ) ) {
				return $tz;
			}
		}
		return null;
	}

	/**
	 * Get the best timezone for a booking form.
	 *
	 * Priority:
	 * 1. Cookie (session persistence)
	 * 2. User preference (logged in)
	 * 3. Browser detection (will be set by JS)
	 * 4. Site timezone
	 *
	 * @since 5.2.0
	 *
	 * @return string Timezone string.
	 */
	public static function get_booking_form_timezone( ?int $user_id = null ): string {
		$user_id = null !== $user_id ? $user_id : get_current_user_id();
		if ( ! self::should_show_timezone( 'frontend', (int) $user_id ) ) {
			return self::get_site_timezone_string();
		}
		$raw = self::get_user_timezone_raw( $user_id ?: null );
		if ( $raw && self::is_valid_timezone( $raw ) ) {
			return $raw;
		}
		$use_site = ( $user_id && '1' === (string) get_user_meta( $user_id, 'wc_appointments_use_site_timezone', true ) )
			|| ( isset( $_COOKIE['appointments_use_site_timezone'] ) && '1' === $_COOKIE['appointments_use_site_timezone'] );
		return $use_site ? self::get_site_timezone_string() : ( self::get_browser_timezone() ?: self::get_site_timezone_string() );
	}

	/**
	 * Format a timestamp for admin display in the current admin user's timezone.
	 *
	 * Use this for all admin views (calendar, list table, modals) to ensure
	 * staff members see times in their preferred timezone.
	 *
	 * @since 5.2.1
	 *
	 * @param int         $timestamp    Unix timestamp (stored in site timezone).
	 * @param string|null $date_format  Date format. Default: site setting.
	 * @param string|null $time_format  Time format. Default: site setting.
	 * @param bool        $show_tz_indicator Whether to show timezone indicator when different from site.
	 *
	 * @return string Formatted date/time string.
	 */
	public static function format_for_admin_display(
		int $timestamp,
		?string $date_format = null,
		?string $time_format = null,
		bool $show_tz_indicator = false
	): string {
		if ( ! $timestamp ) {
			return '';
		}

		if ( null === $date_format ) {
			$date_format = wc_appointments_date_format();
		}
		if ( null === $time_format ) {
			$time_format = ', ' . wc_appointments_time_format();
		}

		// When timezone display is disabled for admin, show site timezone only.
		if ( ! self::should_show_timezone( 'admin', get_current_user_id() ) ) {
			return date_i18n( $date_format . $time_format, $timestamp );
		}

		$admin_tz = self::get_admin_user_timezone();
		$site_tz  = self::get_site_timezone_string();

		// If admin timezone differs from site, convert the timestamp.
		if ( $admin_tz !== $site_tz ) {
			try {
				// Create DateTime from timestamp in site timezone.
				$site_tz_obj  = new DateTimeZone( $site_tz );
				$admin_tz_obj = new DateTimeZone( $admin_tz );

				// Interpret the timestamp as site timezone wall-clock time.
				$dt = new DateTime( date( 'Y-m-d H:i:s', $timestamp ), $site_tz_obj );
				// Convert to admin's timezone.
				$dt->setTimezone( $admin_tz_obj );

				$formatted = $dt->format( self::convert_php_date_format( $date_format . $time_format ) );

				if ( $show_tz_indicator ) {
					$formatted .= self::build_timezone_indicator_html( $admin_tz, 'wc-appointments-tz-abbr', $dt );
				}

				return $formatted;
			} catch ( Exception $e ) {
				// Fall through to default formatting.
			}
		}

		return date_i18n( $date_format . $time_format, $timestamp );
	}


	/**
	 * Convert PHP date format characters to DateTime::format() compatible.
	 *
	 * WordPress date_i18n() uses translated month/day names, but DateTime::format()
	 * returns English names. This is a simple pass-through for now, but could be
	 * extended to handle translation if needed.
	 *
	 * @since 5.2.1
	 *
	 * @param string $format PHP date format string.
	 *
	 * @return string Format string compatible with DateTime::format().
	 */
	private static function convert_php_date_format( string $format ): string {
		// For now, just return as-is. DateTime::format() uses same format chars.
		// The main difference is translation which we handle separately if needed.
		return $format;
	}

	/**
	 * Convert a timestamp from site timezone to admin user's timezone.
	 *
	 * Returns a new timestamp that, when used with date_i18n(), will display
	 * the correct time in the admin user's timezone.
	 *
	 * @since 5.2.1
	 *
	 * @param int $timestamp Unix timestamp (stored in site timezone).
	 *
	 * @return int Adjusted timestamp for admin display.
	 */
	public static function convert_to_admin_timezone( int $timestamp ): int {
		if ( ! $timestamp ) {
			return 0;
		}

		// When timezone display is disabled, show site time only (no conversion).
		if ( ! self::should_show_timezone( 'admin', get_current_user_id() ) ) {
			return $timestamp;
		}

		$admin_tz = self::get_admin_user_timezone();
		$site_tz  = self::get_site_timezone_string();

		if ( $admin_tz === $site_tz ) {
			return $timestamp;
		}

		try {
			$site_tz_obj  = new DateTimeZone( $site_tz );
			$admin_tz_obj = new DateTimeZone( $admin_tz );

			// Create DateTime interpreting timestamp as site timezone.
			$dt = new DateTime( date( 'Y-m-d H:i:s', $timestamp ), $site_tz_obj );
			// Convert to admin timezone.
			$dt->setTimezone( $admin_tz_obj );

			// Return timestamp that will display correct time when used with date_i18n.
			// We need to adjust for the offset difference.
			$site_offset  = $site_tz_obj->getOffset( $dt );
			$admin_offset = $admin_tz_obj->getOffset( $dt );
			$offset_diff  = $admin_offset - $site_offset;

			return $timestamp + $offset_diff;
		} catch ( Exception $e ) {
			return $timestamp;
		}
	}

	/**
	 * Check if the current admin user has a different timezone than the site.
	 *
	 * @since 5.2.1
	 *
	 * @return bool True if admin user's timezone differs from site timezone.
	 */
	public static function admin_has_different_timezone(): bool {
		if ( ! is_user_logged_in() ) {
			return false;
		}

		$admin_tz = self::get_admin_user_timezone();
		$site_tz  = self::get_site_timezone_string();

		return $admin_tz !== $site_tz;
	}

	/**
	 * Get timezone indicator HTML for admin display.
	 *
	 * Shows the admin user's timezone name/abbreviation if different from site timezone.
	 * Uses friendly names instead of raw "GMT".
	 *
	 * @since 5.2.1
	 *
	 * @return string HTML timezone indicator or empty string if same as site.
	 */
	public static function get_admin_timezone_indicator(): string {
		if ( ! self::should_show_timezone( 'admin', get_current_user_id() ) || ! self::admin_has_different_timezone() ) {
			return '';
		}

		return self::build_timezone_indicator_html( self::get_admin_user_timezone(), 'wc-appointments-tz-abbr' );
	}
}
