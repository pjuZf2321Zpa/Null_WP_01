<?php
/**
 * WP-CLI commands for appointment series (foundation: list/get).
 *
 * @package WooCommerce\Appointments\CLI
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * wp wca series …
 */
class WC_Appointments_Series_CLI {

	/**
	 * @param string $message Error message.
	 * @return never
	 */
	private static function cli_abort( $message ) {
		WP_CLI::error( $message );
		exit( 1 );
	}

	/**
	 * Load a series or abort when missing.
	 *
	 * @param int $id Series id.
	 * @return WC_Appointment_Series
	 */
	private static function load_series( $id ) {
		try {
			return new WC_Appointment_Series( (int) $id );
		} catch ( Exception $e ) {
			/* translators: %d: series id */
			self::cli_abort( sprintf( __( 'Series %d not found.', 'woocommerce-appointments' ), (int) $id ) );
		}
	}

	/**
	 * List series rows.
	 *
	 * @subcommand list
	 *
	 * ## OPTIONS
	 *
	 * [--status=<status>]
	 * : Filter by status (pending, active, completed, cancelled).
	 *
	 * [--customer_id=<id>]
	 * : Filter by customer user id.
	 *
	 * [--limit=<n>]
	 * : Max rows. Default 20.
	 *
	 * [--format=<format>]
	 * : table, json, csv. Default table.
	 *
	 * @param array<int, string>    $args       Positional args.
	 * @param array<string, string> $assoc_args Flags.
	 * @return void
	 */
	public function list_series( $args, $assoc_args ) {
		$store = WC_Data_Store::load( WC_Appointment_Series::DATA_STORE );
		$rows  = $store->query(
			array(
				'status'      => isset( $assoc_args['status'] ) ? $assoc_args['status'] : '',
				'customer_id' => isset( $assoc_args['customer_id'] ) ? (int) $assoc_args['customer_id'] : 0,
				'limit'       => isset( $assoc_args['limit'] ) ? (int) $assoc_args['limit'] : 20,
			)
		);

		$items = array();
		foreach ( $rows as $series ) {
			$items[] = array(
				'id'          => $series->get_id(),
				'version'     => $series->get_version(),
				'status'      => $series->get_status(),
				'product_id'  => $series->get_product_id(),
				'customer_id' => $series->get_customer_id(),
				'rrule'       => $series->get_rrule(),
				'dtstart_ts'  => $series->get_dtstart_ts(),
				'timezone'    => $series->get_timezone(),
			);
		}

		$format = isset( $assoc_args['format'] ) ? $assoc_args['format'] : 'table';
		WP_CLI\Utils\format_items(
			$format,
			$items,
			array( 'id', 'version', 'status', 'product_id', 'customer_id', 'rrule', 'dtstart_ts', 'timezone' )
		);
	}

	/**
	 * Get one series by id.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Series id.
	 *
	 * [--format=<format>]
	 * : table, json. Default table.
	 *
	 * @param array<int, string>    $args       Positional args.
	 * @param array<string, string> $assoc_args Flags.
	 * @return void
	 */
	public function get( $args, $assoc_args ) {
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		if ( $id <= 0 ) {
			self::cli_abort( __( 'Series id is required.', 'woocommerce-appointments' ) );
		}

		$series = self::load_series( $id );

		$item = array(
			'id'                    => $series->get_id(),
			'version'               => $series->get_version(),
			'status'                => $series->get_status(),
			'product_id'            => $series->get_product_id(),
			'customer_id'           => $series->get_customer_id(),
			'staff_assignment_mode' => $series->get_staff_assignment_mode(),
			'locked_staff_id'       => $series->get_locked_staff_id(),
			'order_id'              => $series->get_order_id(),
			'payment_model'         => $series->get_payment_model(),
			'rrule'                 => $series->get_rrule(),
			'dtstart_ts'            => $series->get_dtstart_ts(),
			'duration_seconds'      => $series->get_duration_seconds(),
			'timezone'              => $series->get_timezone(),
			'next_materialize_ts'   => $series->get_next_materialize_ts(),
			'materialized_count'    => $series->get_materialized_count(),
			'rrule_count_cap'       => $series->get_rrule_count_cap(),
			'created_at'            => $series->get_created_at(),
			'updated_at'            => $series->get_updated_at(),
		);

		$format = isset( $assoc_args['format'] ) ? $assoc_args['format'] : 'table';
		if ( 'json' === $format ) {
			WP_CLI::print_value( $item, array( 'format' => 'json' ) );
			return;
		}

		WP_CLI\Utils\format_items( 'table', array( $item ), array_keys( $item ) );
	}

	/**
	 * Materialize the next batch for a series.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Series id.
	 *
	 * [--batch=<n>]
	 * : Batch size. Default 50.
	 *
	 * @param array<int, string>    $args       Positional args.
	 * @param array<string, string> $assoc_args Flags.
	 * @return void
	 */
	public function materialize( $args, $assoc_args ) {
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		if ( $id <= 0 ) {
			self::cli_abort( __( 'Series id is required.', 'woocommerce-appointments' ) );
		}

		$batch   = isset( $assoc_args['batch'] ) ? (int) $assoc_args['batch'] : 50;
		$created = ( new WC_Appointment_Series_Materializer() )->materialize_batch( $id, $batch );

		/* translators: %1$d: series id, %2$d: appointments created */
		WP_CLI::success( sprintf( __( 'Series %1$d: materialized %2$d occurrence(s).', 'woocommerce-appointments' ), $id, $created ) );
	}

	/**
	 * Cancel future occurrences for a series.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Series id.
	 *
	 * [--version=<n>]
	 * : Expected series version (If-Match). Default: current version from DB.
	 *
	 * @param array<int, string>    $args       Positional args.
	 * @param array<string, string> $assoc_args Flags.
	 * @return void
	 */
	public function cancel_future( $args, $assoc_args ) {
		$id = isset( $args[0] ) ? (int) $args[0] : 0;
		if ( $id <= 0 ) {
			self::cli_abort( __( 'Series id is required.', 'woocommerce-appointments' ) );
		}

		$series = self::load_series( $id );

		$version = isset( $assoc_args['version'] ) ? (int) $assoc_args['version'] : $series->get_version();
		$result  = ( new WC_Appointment_Series_Manager() )->cancel( $id, $version, 'future', 'cli-' . wp_generate_uuid4() );

		if ( is_wp_error( $result ) ) {
			self::cli_abort( $result->get_error_message() );
		}

		WP_CLI::success( __( 'Future series occurrences cancelled.', 'woocommerce-appointments' ) );
	}
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'wca series', 'WC_Appointments_Series_CLI' );
}
