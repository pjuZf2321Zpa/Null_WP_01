<?php
/**
 * Staff Permissions System
 *
 * Handles granular permission checks for staff members.
 * Permissions can be configured globally and overridden per-staff.
 *
 * @package WooCommerce Appointments
 * @since 5.2.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointments_Staff_Permissions class.
 */
class WC_Appointments_Staff_Permissions {

	/**
	 * Permission categories for organized admin UI.
	 *
	 * @var array<string, string>
	 */
	const CATEGORIES = [
		'calendar'     => 'Calendar & Appointments',
		'availability' => 'Availability',
		'products'     => 'Products',
		'orders'       => 'Orders',
		'customers'    => 'Customers',
		'data'         => 'Data & Reports',
	];

	/**
	 * Default permission matrix.
	 * Only includes permissions that have actual functionality implemented.
	 *
	 * Structure: 'permission_key' => [ 'default' => bool, 'category' => string, 'label' => string, 'description' => string ]
	 *
	 * @var array<string, array{default: bool, category: string, label: string, description: string}>
	 */
	const DEFAULTS = [
		// CALENDAR & APPOINTMENTS
		'view_calendar'            => [
			'default'     => true,
			'category'    => 'calendar',
			'label'       => 'View Calendar',
			'description' => 'Access the appointment calendar showing their assigned appointments',
		],
		'view_appointments_list'   => [
			'default'     => true,
			'category'    => 'calendar',
			'label'       => 'View Appointments List',
			'description' => 'Access the appointments list view filtered to their appointments',
		],
		'manage_appointment_status' => [
			'default'     => true,
			'category'    => 'calendar',
			'label'       => 'Change Appointment Status',
			'description' => 'Confirm, complete, or update appointment status',
		],
		'create_appointments'      => [
			'default'     => false,
			'category'    => 'calendar',
			'label'       => 'Create Appointments',
			'description' => 'Manually create new appointments from the calendar (only for assigned products)',
		],
		'create_appointments_any'  => [
			'default'     => false,
			'category'    => 'calendar',
			'label'       => 'Create Appointments for Any Product',
			'description' => 'Create appointments for other staff members or products without staff assignment',
		],
		'cancel_appointments'      => [
			'default'     => false,
			'category'    => 'calendar',
			'label'       => 'Cancel Appointments',
			'description' => 'Cancel existing appointments (may trigger refunds)',
		],

		// AVAILABILITY
		'manage_own_availability'  => [
			'default'     => true,
			'category'    => 'availability',
			'label'       => 'Manage Own Availability',
			'description' => 'Edit personal open hours and unavailable times in the Availability hub',
		],
		'manage_global_availability' => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Manage General Availability',
			'description' => 'Edit general hours and holidays in the Availability hub',
		],
		'manage_product_availability' => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Manage Product Availability',
			'description' => 'Edit product open hours and unavailable times in the Availability hub',
		],
		'manage_location_availability' => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Manage Location Availability',
			'description' => 'Edit venue / online location hours in the Availability hub',
		],
		'manage_resource_availability' => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Manage Resource Availability',
			'description' => 'Edit room and equipment hours in the Availability hub',
		],
		'availability_set_appointable' => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Set Available / Unavailable',
			'description' => 'Add open hours (Available). Without this, staff may only add closed / unavailable dates.',
		],
		'availability_rule_type_daterange' => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Rule Type: Date Range with Time',
			'description' => 'Allow using the "Date range with time" rule type in addition to the basic "Date range".',
		],
		'availability_rule_type_recurring' => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Rule Type: Recurring (Months / Weeks / Days)',
			'description' => 'Allow using month, week, and day-of-week recurring rule types.',
		],
		'availability_rule_type_time'      => [
			'default'     => false,
			'category'    => 'availability',
			'label'       => 'Rule Type: Time Ranges',
			'description' => 'Allow using recurring time and time-range rule types.',
		],

		// PRODUCTS
		'view_assigned_products'   => [
			'default'     => true,
			'category'    => 'products',
			'label'       => 'View Assigned Products',
			'description' => 'See assigned products including pricing, duration, and capacity',
		],
		'manage_products'          => [
			'default'     => false,
			'category'    => 'products',
			'label'       => 'Create & Edit Products',
			'description' => 'Create new appointment products and edit existing ones',
		],
		'manage_locations'         => [
			'default'     => false,
			'category'    => 'products',
			'label'       => 'Manage Locations',
			'description' => 'Create and edit shop locations (venues and online)',
		],
		'manage_resources'         => [
			'default'     => false,
			'category'    => 'products',
			'label'       => 'Manage Rooms & Resources',
			'description' => 'Create and edit shared resources (rooms, equipment)',
		],

		// CUSTOMERS
		'view_customers'           => [
			'default'     => false,
			'category'    => 'customers',
			'label'       => 'View Customers',
			'description' => 'Access to view customer information from their appointments',
		],
		'view_all_customers'       => [
			'default'     => false,
			'category'    => 'customers',
			'label'       => 'View All Customers',
			'description' => 'View all customers, not just those who booked with this staff member',
		],
		'view_customer_history'    => [
			'default'     => false,
			'category'    => 'customers',
			'label'       => 'View Customer History',
			'description' => 'See past appointments and booking history for customers',
		],
		'contact_customers'        => [
			'default'     => false,
			'category'    => 'customers',
			'label'       => 'Contact Customers',
			'description' => 'View customer email and phone for direct communication',
		],

		// DATA & REPORTS
		'view_own_earnings'        => [
			'default'     => false,
			'category'    => 'data',
			'label'       => 'View Earnings',
			'description' => 'See revenue generated from their appointments',
		],
		'export_appointments'      => [
			'default'     => false,
			'category'    => 'data',
			'label'       => 'Export Appointments',
			'description' => 'Download their appointments as CSV or ICS file',
		],

		// ORDERS
		'view_orders'              => [
			'default'     => false,
			'category'    => 'orders',
			'label'       => 'View Orders',
			'description' => 'View orders related to their appointments',
		],
		'manage_orders'            => [
			'default'     => false,
			'category'    => 'orders',
			'label'       => 'Create & Edit Orders',
			'description' => 'Create new orders and edit existing ones',
		],
	];

	/**
	 * Permission presets for quick setup.
	 *
	 * @var array<string, list<string>>
	 */
	const PRESETS = [
		'minimal'  => [
			'view_calendar',
			'view_appointments_list',
			'manage_own_availability',
			// availability_set_appointable: off (unavailable-only rules)
			// availability_rule_type_daterange: off
			// availability_rule_type_recurring: off
			// availability_rule_type_time: off
		],
		'standard' => [
			'view_calendar',
			'view_appointments_list',
			'manage_appointment_status',
			'create_appointments',
			'manage_own_availability',
			'availability_set_appointable',
			'availability_rule_type_daterange',
			'view_assigned_products',
			'view_customers',
		],
		'full'     => [
			'view_calendar',
			'view_appointments_list',
			'manage_appointment_status',
			'create_appointments',
			'create_appointments_any',
			'cancel_appointments',
			'manage_own_availability',
			'manage_global_availability',
			'manage_product_availability',
			'manage_location_availability',
			'manage_resource_availability',
			'availability_set_appointable',
			'availability_rule_type_daterange',
			'availability_rule_type_recurring',
			'availability_rule_type_time',
			'view_assigned_products',
			'manage_products',
			'manage_locations',
			'manage_resources',
			'view_orders',
			'manage_orders',
			'view_customers',
			'view_all_customers',
			'view_customer_history',
			'contact_customers',
			'view_own_earnings',
			'export_appointments',
		],
	];

	/**
	 * Allowed rule type sets, keyed by permission level.
	 * Level is derived from the combination of availability_rule_type_* permissions.
	 *
	 * @var array<string, list<string>>
	 */
	const RULE_TYPE_SETS = [
		'date_range_no' => [ 'custom' ],
		'date_range'    => [ 'custom', 'custom:daterange' ],
		'all'           => [ 'custom', 'custom:daterange', 'months', 'weeks', 'days', 'time', 'time:range' ],
	];

	/**
	 * Caps that require locations & rooms admin surface (beta / usage / hard-disable filter).
	 *
	 * @var string[]
	 */
	const LOCATIONS_RESOURCES_CAPS = [
		'manage_locations',
		'manage_resources',
		'manage_location_availability',
		'manage_resource_availability',
	];

	/**
	 * Whether the current user may manage Google Calendar for a staff target.
	 *
	 * Shop managers / manage_others: any staff or global (0).
	 * Staff with manage_appointments only: their own user id.
	 *
	 * @param int $staff_id Staff user id, or 0 for the global calendar.
	 */
	public static function can_manage_gcal_for_staff( int $staff_id ): bool {
		if ( current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_others_appointments' ) ) {
			return true;
		}

		if ( ! current_user_can( 'manage_appointments' ) ) {
			return false;
		}

		if ( 0 === $staff_id ) {
			return false;
		}

		return (int) get_current_user_id() === $staff_id;
	}

	/**
	 * Check if staff has permission.
	 *
	 * @param int    $user_id    Staff user ID.
	 * @param string $permission Permission key.
	 * @return bool
	 */
	public static function can( int $user_id, string $permission ): bool {
		// Validate permission key exists.
		if ( ! isset( self::DEFAULTS[ $permission ] ) ) {
			return false;
		}

		// Locations & rooms off: no manage/availability caps.
		if ( in_array( $permission, self::LOCATIONS_RESOURCES_CAPS, true )
			&& ! WC_Appointments_Features::is_locations_resources_active() ) {
			return false;
		}

		// Admins always have all permissions.
		if ( user_can( $user_id, 'manage_others_appointments' ) ) {
			return true;
		}

		// Check if user is staff.
		if ( ! user_can( $user_id, 'manage_appointments' ) ) {
			return false;
		}

		// Check user-specific override first.
		$user_permissions = get_user_meta( $user_id, '_wca_staff_permissions', true );
		if ( is_array( $user_permissions ) && isset( $user_permissions[ $permission ] ) ) {
			return (bool) $user_permissions[ $permission ];
		}

		// Fall back to global settings.
		$global_permissions = get_option( 'wc_appointments_staff_permissions', [] );
		
		// If global permissions are configured, check if this specific permission is set
		if ( ! empty( $global_permissions ) ) {
			if ( isset( $global_permissions[ $permission ] ) ) {
				return (bool) $global_permissions[ $permission ];
			} else {
				// Global permissions exist but this specific permission is not set
				return false;
			}
		}

		// Fall back to standard preset when no permissions have been configured.
		return in_array( $permission, self::PRESETS['standard'], true );
	}

	/**
	 * Get the allowed rule type level for a staff member.
	 *
	 * Derived from the stored availability_rule_type_* permission flags.
	 * Admins always get 'all'.
	 *
	 * Returns one of: 'date_range_no', 'date_range', 'all'.
	 *
	 * @param int $user_id Staff user ID.
	 * @return string
	 */
	public static function get_rule_type_level( int $user_id ): string {
		if ( user_can( $user_id, 'manage_others_appointments' ) ) {
			return 'all';
		}

		$has_recurring = self::can( $user_id, 'availability_rule_type_recurring' );
		$has_time      = self::can( $user_id, 'availability_rule_type_time' );
		$has_daterange = self::can( $user_id, 'availability_rule_type_daterange' );

		if ( $has_recurring || $has_time ) {
			return 'all';
		}

		if ( $has_daterange ) {
			return 'date_range';
		}

		return 'date_range_no';
	}

	/**
	 * Get the allowed rule types for a staff member.
	 *
	 * @param int $user_id Staff user ID.
	 * @return string[] Array of allowed rule type strings.
	 */
	public static function get_allowed_rule_types( int $user_id ): array {
		$level = self::get_rule_type_level( $user_id );
		return self::RULE_TYPE_SETS[ $level ] ?? self::RULE_TYPE_SETS['date_range'];
	}

	/**
	 * Get all permissions for a staff member.
	 *
	 * @param int $user_id Staff user ID.
	 * @return array<string, bool>
	 */
	public static function get_all( int $user_id ): array {
		$permissions = [];
		foreach ( array_keys( self::DEFAULTS ) as $key ) {
			$permissions[ $key ] = self::can( $user_id, $key );
		}
		return $permissions;
	}

	/**
	 * Permission flags for admin calendar / panel JS.
	 *
	 * @return array{canViewOrders: bool, canManageOrders: bool, canManageProducts: bool, canManageLocations: bool, canManageResources: bool}
	 */
	public static function admin_ui_flags(): array {
		$user_id = get_current_user_id();

		return [
			'canViewOrders'      => self::can( $user_id, 'view_orders' ),
			'canManageOrders'    => self::can( $user_id, 'manage_orders' ),
			'canManageProducts'  => self::can( $user_id, 'manage_products' ),
			'canManageLocations' => self::can( $user_id, 'manage_locations' ),
			'canManageResources' => self::can( $user_id, 'manage_resources' ),
		];
	}

	/**
	 * Get permissions grouped by category.
	 *
	 * @param int $user_id Staff user ID.
	 * @return array<string, array{label: string, permissions: array<string, array<string, mixed>>}>
	 */
	public static function get_grouped( int $user_id ): array {
		$grouped = [];
		foreach ( self::CATEGORIES as $cat_key => $cat_label ) {
			$grouped[ $cat_key ] = [
				'label'       => $cat_label,
				'permissions' => [],
			];
		}

		foreach ( self::DEFAULTS as $perm_key => $perm_data ) {
			$category = $perm_data['category'];
			if ( isset( $grouped[ $category ] ) ) {
				$grouped[ $category ]['permissions'][ $perm_key ] = [
					'label'       => $perm_data['label'],
					'description' => $perm_data['description'],
					'enabled'     => self::can( $user_id, $perm_key ),
					'default'     => $perm_data['default'],
				];
			}
		}

		return $grouped;
	}

	/**
	 * Get permission dependencies for UI warnings.
	 *
	 * @return array<string, list<string>>
	 */
	public static function get_dependencies(): array {
		return [
			'manage_appointment_status'        => [ 'view_calendar' ],
			'create_appointments'              => [ 'view_calendar' ],
			'create_appointments_any'          => [ 'create_appointments' ],
			'cancel_appointments'              => [ 'view_calendar' ],
			'availability_set_appointable'     => [ 'manage_own_availability' ],
			'availability_rule_type_daterange' => [ 'manage_own_availability' ],
			'availability_rule_type_recurring' => [ 'manage_own_availability' ],
			'availability_rule_type_time'      => [ 'manage_own_availability' ],
			'manage_product_availability'      => [ 'manage_products' ],
			'manage_location_availability'     => [ 'manage_locations' ],
			'manage_resource_availability'     => [ 'manage_resources' ],
			'view_all_customers'               => [ 'view_customers' ],
			'view_customer_history'            => [ 'view_customers' ],
			'contact_customers'                => [ 'view_customers' ],
		];
	}

	/**
	 * Whether the user may open the Availability hub at all.
	 *
	 * @param int|null $user_id User ID. Defaults to current user.
	 */
	public static function can_access_availability_hub( ?int $user_id = null ): bool {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id || ! user_can( $user_id, 'manage_appointments' ) ) {
			return false;
		}
		if ( user_can( $user_id, 'manage_others_appointments' ) ) {
			return true;
		}
		foreach ( self::availability_hub_layer_permissions() as $perm ) {
			if ( self::can( $user_id, $perm ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Hub layer key => staff permission key.
	 *
	 * @return array<string, string>
	 */
	public static function availability_hub_layer_permissions(): array {
		return [
			'global'   => 'manage_global_availability',
			'product'  => 'manage_product_availability',
			'location' => 'manage_location_availability',
			'resource' => 'manage_resource_availability',
			'staff'    => 'manage_own_availability',
		];
	}

	/**
	 * Whether the user may edit a hub layer (and for staff, only their own row unless manage_others).
	 *
	 * @param string   $layer   Hub layer key.
	 * @param int      $kind_id Entity id (0 for global).
	 * @param int|null $user_id User ID. Defaults to current user.
	 */
	public static function can_edit_availability_layer( string $layer, int $kind_id = 0, ?int $user_id = null ): bool {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}
		if ( ! $user_id || ! user_can( $user_id, 'manage_appointments' ) ) {
			return false;
		}
		if ( user_can( $user_id, 'manage_others_appointments' ) ) {
			return true;
		}
		$map = self::availability_hub_layer_permissions();
		if ( ! isset( $map[ $layer ] ) || ! self::can( $user_id, $map[ $layer ] ) ) {
			return false;
		}
		if ( 'staff' === $layer ) {
			return $kind_id === (int) $user_id;
		}
		return true;
	}

	/**
	 * Apply a preset to global permissions.
	 *
	 * @param string $preset_key Preset key (minimal, standard, advanced).
	 * @return bool
	 */
	public static function apply_preset( string $preset_key ): bool {
		if ( ! isset( self::PRESETS[ $preset_key ] ) ) {
			return false;
		}

		$enabled_permissions = self::PRESETS[ $preset_key ];
		$permissions         = [];

		foreach ( array_keys( self::DEFAULTS ) as $perm_key ) {
			$permissions[ $perm_key ] = in_array( $perm_key, $enabled_permissions, true ) ? 1 : 0;
		}

		update_option( 'wc_appointments_staff_permissions', $permissions );
		return true;
	}

	/**
	 * Save user-specific permission overrides.
	 *
	 * @param int                  $user_id     Staff user ID.
	 * @param array<string, bool>  $permissions Permission overrides.
	 * @return bool
	 */
	public static function save_user_permissions( int $user_id, array $permissions ): bool {
		$sanitized = [];
		foreach ( $permissions as $key => $value ) {
			if ( ! isset( self::DEFAULTS[ $key ] ) ) {
				continue;
			}
			$sanitized[ $key ] = (bool) $value;
		}

		return update_user_meta( $user_id, '_wca_staff_permissions', $sanitized );
	}

	/**
	 * Clear user-specific permission overrides.
	 *
	 * @param int $user_id Staff user ID.
	 * @return bool
	 */
	public static function clear_user_permissions( int $user_id ): bool {
		return delete_user_meta( $user_id, '_wca_staff_permissions' );
	}

	/**
	 * Check if user is a staff member (not admin).
	 *
	 * @param int|null $user_id User ID. Defaults to current user.
	 * @return bool
	 */
	public static function is_staff_user( ?int $user_id = null ): bool {
		if ( null === $user_id ) {
			$user_id = get_current_user_id();
		}

		if ( ! $user_id ) {
			return false;
		}

		return user_can( $user_id, 'manage_appointments' ) && ! user_can( $user_id, 'manage_others_appointments' );
	}

	/**
	 * Restrict edit/delete/read of others' appointments for staff without manage_others.
	 *
	 * Only narrows real staff; admins and custom roles keep normal CPT caps.
	 * Authors and assigned staff keep their caps; everyone else is denied.
	 *
	 * @param list<string> $caps    Required capabilities.
	 * @param string       $cap     Capability being checked.
	 * @param int          $user_id User ID.
	 * @param list<mixed>  $args    Extra args (post ID).
	 * @return list<string>
	 */
	public static function map_meta_cap( $caps, $cap, $user_id, $args ) {
		if ( ! in_array( $cap, [ 'edit_post', 'delete_post', 'read_post' ], true ) ) {
			return $caps;
		}

		$post_id = isset( $args[0] ) ? absint( $args[0] ) : 0;
		if ( ! $post_id ) {
			return $caps;
		}

		$post = get_post( $post_id );
		if ( ! $post || 'wc_appointment' !== $post->post_type ) {
			return $caps;
		}

		$user_id = absint( $user_id );
		if ( ! self::is_staff_user( $user_id ) ) {
			return $caps;
		}

		if ( (int) $post->post_author === $user_id ) {
			return $caps;
		}

		$appointment = get_wc_appointment( $post_id );
		if ( $appointment && in_array( $user_id, array_map( 'intval', (array) $appointment->get_staff_ids() ), true ) ) {
			return $caps;
		}

		return [ 'do_not_allow' ];
	}
}

add_filter( 'map_meta_cap', [ 'WC_Appointments_Staff_Permissions', 'map_meta_cap' ], 10, 4 );
