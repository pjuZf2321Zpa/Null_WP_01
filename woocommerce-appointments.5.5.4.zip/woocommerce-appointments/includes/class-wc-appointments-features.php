<?php
/**
 * Feature flags and admin presence helpers.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Store-level feature gates (locations & resources beta, product tab presence).
 *
 * @since 5.5.0
 */
class WC_Appointments_Features {

	const OPTION_LOCATIONS_RESOURCES = 'wc_appointments_enable_locations_resources';

	/**
	 * Boot. Runs before location/resource CPT registration (priority 6).
	 *
	 * @since 5.5.0
	 */
	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'maybe_auto_enable_locations_resources' ], 5 );
	}

	/**
	 * Whether the force-off filter allows locations & rooms (ignores the checkbox).
	 *
	 * False from `woocommerce_appointments_locations_resources_active` hides the
	 * Experimental setting and keeps forward/admin off. Appointment snapshots stay.
	 *
	 * @since 5.5.0
	 */
	public static function is_locations_resources_allowed(): bool {
		return (bool) apply_filters( 'woocommerce_appointments_locations_resources_active', true );
	}

	/**
	 * Whether locations & rooms are on for forward booking and admin chrome.
	 *
	 * Requires {@see is_locations_resources_allowed()} and the Experimental checkbox.
	 * Appointment snapshot labels are not gated here.
	 *
	 * @since 5.5.0
	 */
	public static function is_locations_resources_active(): bool {
		return self::is_locations_resources_allowed()
			&& self::is_locations_resources_enabled();
	}

	/**
	 * Whether the Experimental "Locations & rooms" setting is on.
	 *
	 * @since 5.5.0
	 */
	public static function is_locations_resources_enabled(): bool {
		return 'yes' === get_option( self::OPTION_LOCATIONS_RESOURCES, 'no' );
	}

	/**
	 * One-time: enable beta when the store already has locations, resources, or product use.
	 *
	 * @since 5.5.0
	 */
	public static function maybe_auto_enable_locations_resources(): void {
		if ( false !== get_option( self::OPTION_LOCATIONS_RESOURCES, false ) ) {
			return;
		}

		update_option(
			self::OPTION_LOCATIONS_RESOURCES,
			self::store_has_usage() ? 'yes' : 'no',
			false
		);
	}

	/**
	 * Show Location product data tab.
	 *
	 * @since 5.5.0
	 *
	 * @param mixed $product Product being edited (or false).
	 */
	public static function should_show_location_tab( $product ): bool {
		if ( ! self::is_locations_resources_active() ) {
			return false;
		}
		$uses = $product instanceof WC_Product_Appointment
			&& 'none' !== $product->get_location_mode( 'edit' );
		return WC_Appointments_Location_Data_Store::exists( true ) || $uses;
	}

	/**
	 * Show Resources product data tab.
	 *
	 * @since 5.5.0
	 *
	 * @param mixed $product Product being edited (or false).
	 */
	public static function should_show_resources_tab( $product ): bool {
		if ( ! self::is_locations_resources_active() ) {
			return false;
		}
		$uses = $product instanceof WC_Product_Appointment
			&& [] !== $product->get_resource_requirements( 'edit' );
		return $uses || WC_Appointments_Resource_Data_Store::exists( true );
	}

	/**
	 * Any location/resource posts or products already configured (auto-enable probe).
	 */
	private static function store_has_usage(): bool {
		if ( WC_Appointments_Location_Data_Store::exists( false ) || WC_Appointments_Resource_Data_Store::exists( false ) ) {
			return true;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- upgrade / auto-enable probe.
		return (bool) $wpdb->get_var(
			"SELECT meta_id FROM {$wpdb->postmeta}
			WHERE (
				meta_key = '_wc_appointment_location_mode'
				AND meta_value != '' AND meta_value != 'none'
			) OR (
				meta_key = '_wc_appointment_resource_requirements'
				AND meta_value != '' AND meta_value != 'a:0:{}'
			)
			LIMIT 1"
		);
	}

}
