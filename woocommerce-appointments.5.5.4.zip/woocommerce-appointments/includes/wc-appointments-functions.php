<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Get an appointment object by ID.
 *
 * Creates and returns a WC_Appointment instance for the given appointment ID.
 * Returns false if the appointment cannot be loaded or an error occurs.
 *
 * @since 1.0.0
 *
 * @param int|string|array<string, mixed> $id Optional. Appointment ID or creation data array. Default empty string.
 *
 * @return WC_Appointment|false Appointment object on success, false on failure.
 *
 * @throws Exception If appointment data cannot be loaded (logged, not thrown).
 *
 * @example
 * // Get appointment by ID
 * $appointment = get_wc_appointment( 123 );
 * if ( $appointment ) {
 *     echo $appointment->get_start();
 * }
 */
function get_wc_appointment( $id = '' ) { // phpcs:ignore Generic.CodeAnalysis.UselessOverridingMethod.Found
	try {
		return new WC_Appointment( $id );
	} catch ( Exception $e ) {
		wc_get_logger()->error( $e->getMessage() );
		return false;
	}
}

/**
 * Get an appointable product object by ID.
 *
 * Creates and returns a WC_Product_Appointment instance for the given product ID.
 * Returns false if the product cannot be loaded, is not an appointment product, or an error occurs.
 *
 * @since 1.0.0
 *
 * @param int $id Optional. Product ID. Default 0.
 *
 * @return WC_Product_Appointment|false Product object on success, false on failure.
 *
 * @throws Exception If product data cannot be loaded (logged, not thrown).
 *
 * @example
 * // Get appointable product
 * $product = get_wc_product_appointment( 456 );
 * if ( $product ) {
 *     echo $product->get_duration();
 * }
 */
function get_wc_product_appointment( $id = 0 ) { // phpcs:ignore Generic.CodeAnalysis.UselessOverridingMethod.Found
	try {
		return new WC_Product_Appointment( (int) $id );
	} catch ( Exception $e ) {
		wc_get_logger()->error( $e->getMessage() );
		return false;
	}
}

/**
 * Get an availability rules object by ID.
 *
 * Creates and returns a WC_Appointments_Availability instance for the given availability ID.
 * Returns false if the availability rule cannot be loaded or an error occurs.
 *
 * @since 1.0.0
 *
 * @param int|string $id Optional. Availability rule ID. Default empty string.
 *
 * @return WC_Appointments_Availability|false Availability object on success, false on failure.
 *
 * @example
 * // Get availability rule
 * $availability = get_wc_appointments_availability( 789 );
 * if ( $availability ) {
 *     echo $availability->get_title();
 * }
 */
function get_wc_appointments_availability( $id = '' ) { // phpcs:ignore Generic.CodeAnalysis.UselessOverridingMethod.Found
	try {
		return new WC_Appointments_Availability( $id );
	} catch ( Exception $e ) {
		return false;
	}
}

/**
 * Product ID that owns product-scoped availability rules.
 *
 * Under WPML / Polylang, translations share the original (or default-language) product's
 * schedule. Do not store a separate rule set per language product.
 *
 * @since 5.5.1
 *
 * @param int $product_id Requested product ID.
 * @return int Canonical product ID for rules / index product scope.
 */
function wc_appointments_get_product_id_for_availability( int $product_id ): int {
	if ( $product_id <= 0 ) {
		return 0;
	}

	$resolved = $product_id;

	$trid = apply_filters( 'wpml_element_trid', null, $product_id, 'post_product' );
	if ( $trid ) {
		$translations = apply_filters( 'wpml_get_element_translations', null, $trid, 'post_product' );
		if ( is_array( $translations ) ) {
			foreach ( $translations as $translation ) {
				if ( is_object( $translation ) && ! empty( $translation->original ) && ! empty( $translation->element_id ) ) {
					$resolved = (int) $translation->element_id;
					break;
				}
			}
		}
	} elseif ( function_exists( 'pll_get_post_translations' ) && function_exists( 'pll_default_language' ) ) {
		$translations = pll_get_post_translations( $product_id );
		if ( is_array( $translations ) && $translations ) {
			$default = pll_default_language();
			if ( is_string( $default ) && isset( $translations[ $default ] ) ) {
				$resolved = (int) $translations[ $default ];
			}
		}
	}

	/**
	 * Filter the product ID used for product-scoped availability rules.
	 *
	 * @since 5.5.1
	 *
	 * @param int $resolved   Canonical product ID.
	 * @param int $product_id Requested product ID.
	 */
	return (int) apply_filters( 'wc_appointments_product_id_for_availability', $resolved, $product_id );
}

/**
 * @param int|string $id Location ID.
 * @return WC_Appointments_Location|false
 */
function get_wc_appointments_location( $id = '' ) {
	try {
		return new WC_Appointments_Location( $id );
	} catch ( Exception $e ) {
		return false;
	}
}

/**
 * @param int|string $id Resource ID.
 * @return WC_Appointments_Resource|false
 */
function get_wc_appointments_resource( $id = '' ) {
	try {
		return new WC_Appointments_Resource( $id );
	} catch ( Exception $e ) {
		return false;
	}
}

/**
 * Sanitize and format a string into a valid 24-hour time format.
 *
 * Cleans the input string and converts it to 'H:i' format (24-hour time).
 * Handles various time input formats and normalizes them to HH:MM.
 *
 * @since 1.0.0
 *
 * @param string $raw_time Raw time string to sanitize and format.
 *
 * @return string Formatted time in 'H:i' format (e.g., '14:30').
 *
 * @example
 * // Sanitize various time formats
 * $time1 = wc_appointment_sanitize_time( '2:30 PM' );  // Returns '14:30'
 * $time2 = wc_appointment_sanitize_time( '14:30:00' ); // Returns '14:30'
 * $time3 = wc_appointment_sanitize_time( '2pm' );      // Returns '14:00'
 */
function wc_appointment_sanitize_time( $raw_time ): string {
	$time = wc_clean( $raw_time );

	return date( 'H:i', strtotime( $time ) );
}

/**
 * Check if a product is an appointment product.
 *
 * Verifies that the given product is a valid WC_Product_Appointment instance.
 *
 * @since 1.0.0
 *
 * @param mixed $product Product object, ID, or other value to check.
 *
 * @return bool True if product is a WC_Product_Appointment instance, false otherwise.
 *
 * @phpstan-assert-if-true \WC_Product_Appointment $product
 *
 * @example
 * // Check if product is appointable
 * $product = wc_get_product( 123 );
 * if ( is_wc_appointment_product( $product ) ) {
 *     // Handle appointment product
 * }
 */
function is_wc_appointment_product( $product ): bool {
	return isset( $product ) && is_object( $product ) && is_a( $product, 'WC_Product_Appointment' );
}

/**
 * Whether to compute and display per-slot prices in the slot picker.
 *
 * Default false: slot generation skips pricing (slots have null price_raw/price_display) for better
 * performance. Checkout still uses product and cost rules for the final price.
 * Enable via filter: add_filter( 'woocommerce_appointments_slots_display_pricing', '__return_true' );
 *
 * @since 5.3.0
 * @param WC_Product_Appointment|null $product Product context for the filter.
 * @return bool True if slot pricing should be enabled.
 */
function wc_appointments_slots_display_pricing( $product = null ): bool {
	return (bool) apply_filters( 'woocommerce_appointments_slots_display_pricing', false, $product );
}

/**
 * Convert appointment data key to a human-readable label.
 *
 * Returns a translated label for common appointment data keys (staff, date, time, duration).
 * Labels can be customized via the 'woocommerce_appointments_data_labels' filter.
 *
 * @since 1.0.0
 *
 * @param string                $key     Data key to get label for (e.g., 'staff', 'date', 'time', 'duration').
 * @param WC_Product_Appointment|mixed $product Product instance (used for staff and location label customization).
 *
 * @return string Human-readable label for the key, or the key itself if no label exists.
 *
 * @example
 * // Get label for staff field
 * $label = get_wc_appointment_data_label( 'staff', $product );
 * // Returns: 'Providers' (or custom staff label from product)
 */
function get_wc_appointment_data_label( string $key, $product ): string {
	$labels = apply_filters(
	    'woocommerce_appointments_data_labels',
	    [
			'location' => ( $product instanceof WC_Product_Appointment && $product->get_location_label()
				? $product->get_location_label()
				: __( 'Location', 'woocommerce-appointments' ) ),
			'staff'    => ( $product instanceof WC_Product_Appointment && $product->get_staff_label()
				? $product->get_staff_label()
				: __( 'Providers', 'woocommerce-appointments' ) ),
			'resource' => ( $product instanceof WC_Product_Appointment && $product->get_resource_label()
				? $product->get_resource_label()
				: __( 'Resources', 'woocommerce-appointments' ) ),
			'date'     => __( 'Date', 'woocommerce-appointments' ),
			'time'     => __( 'Time', 'woocommerce-appointments' ),
			'duration' => __( 'Duration', 'woocommerce-appointments' ),
		],
	);

	if ( ! array_key_exists( $key, $labels ) ) {
		return $key;
	}

	return $labels[ $key ];
}

/**
 * Convert appointment status to human-readable label.
 *
 * Returns a translated label for the given appointment status. Statuses include:
 * unpaid, pending-confirmation, confirmed, paid, cancelled, complete, in-cart.
 * Labels can be customized via the 'woocommerce_appointments_get_status_label' filter.
 *
 * @since 3.0.0
 *
 * @param string $status Appointment status key.
 *
 * @return string Human-readable status label, or the status key if no label exists.
 *
 * @example
 * // Get status label
 * $label = wc_appointments_get_status_label( 'pending-confirmation' );
 * // Returns: 'Pending Confirmation'
 */
function wc_appointments_get_status_label( string $status ): string {
	$statuses = [
		WC_Appointments_Constants::STATUS_UNPAID               => __( 'Unpaid', 'woocommerce-appointments' ),
		WC_Appointments_Constants::STATUS_PENDING_CONFIRMATION => __( 'Pending Confirmation', 'woocommerce-appointments' ),
		WC_Appointments_Constants::STATUS_CONFIRMED            => __( 'Confirmed', 'woocommerce-appointments' ),
		WC_Appointments_Constants::STATUS_PAID                 => __( 'Paid', 'woocommerce-appointments' ),
		WC_Appointments_Constants::STATUS_CANCELLED            => __( 'Cancelled', 'woocommerce-appointments' ),
		WC_Appointments_Constants::STATUS_COMPLETE             => __( 'Complete', 'woocommerce-appointments' ),
		WC_Appointments_Constants::STATUS_IN_CART              => __( 'In Cart', 'woocommerce-appointments' ),
		WC_Appointments_Constants::STATUS_WAS_IN_CART          => __( 'Was In Cart', 'woocommerce-appointments' ),
	];

	/**
	 * Filter the return value of wc_appointments_get_status_label.
	 *
	 * @since 3.5.6
	 */
	$statuses = apply_filters( 'woocommerce_appointments_get_status_label', $statuses );

	return array_key_exists( $status, $statuses ) ? $statuses[ $status ] : $status;
}

/**
 * Get a list of appointment statuses.
 *
 * Returns appointment statuses based on the provided context. Statuses can be
 * returned as keys only or as key-value pairs with translated labels.
 *
 * @since 2.3.0
 * @since 2.3.0 Added $include_translation_strings parameter.
 *
 * @param string|null $context                  Optional. Context filter ('user', 'validate', 'customer', 'cancel', 'scheduled', 'all', 'fully_scheduled'). Default 'fully_scheduled'.
 * @param bool        $include_translation_strings Optional. Whether to include translated labels. Default false.
 *
 * @return array<string>|array<string, string> {
 *     Return format depends on $include_translation_strings:
 *     - If false: array<int, string> Array of status keys (e.g., ['unpaid', 'confirmed', 'paid']).
 *     - If true:  array<string, string> Associative array with status keys as keys and translated labels as values
 *                (e.g., ['unpaid' => 'Unpaid', 'confirmed' => 'Confirmed']).
 * }
 *
 * @example
 * // Get status keys only
 * $statuses = get_wc_appointment_statuses( 'user' );
 * // Returns: ['unpaid', 'pending-confirmation', 'confirmed', ...]
 *
 * // Get statuses with labels
 * $statuses = get_wc_appointment_statuses( 'user', true );
 * // Returns: ['unpaid' => 'Unpaid', 'confirmed' => 'Confirmed', ...]
 */
function get_wc_appointment_statuses( ?string $context = 'fully_scheduled', bool $include_translation_strings = false ): array {
	// Handle null context by using default.
	if ( null === $context ) {
		$context = 'fully_scheduled';
	}
	if ( 'user' === $context ) {
		$statuses = apply_filters(
		    'woocommerce_appointment_statuses_for_user',
		    [
				WC_Appointments_Constants::STATUS_UNPAID               => __( 'Unpaid', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PENDING_CONFIRMATION => __( 'Pending Confirmation', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_CONFIRMED            => __( 'Confirmed', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PAID                 => __( 'Paid', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_CANCELLED            => __( 'Cancelled', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_COMPLETE             => __( 'Complete', 'woocommerce-appointments' ),
			],
		);
    } elseif ( 'validate' === $context ) {
        $statuses = apply_filters(
            'woocommerce_appointment_statuses_for_validation',
            [
                WC_Appointments_Constants::STATUS_UNPAID               => __( 'Unpaid', 'woocommerce-appointments' ),
                WC_Appointments_Constants::STATUS_PENDING_CONFIRMATION => __( 'Pending Confirmation', 'woocommerce-appointments' ),
                WC_Appointments_Constants::STATUS_CONFIRMED            => __( 'Confirmed', 'woocommerce-appointments' ),
                WC_Appointments_Constants::STATUS_PAID                 => __( 'Paid', 'woocommerce-appointments' ),
                WC_Appointments_Constants::STATUS_CANCELLED            => __( 'Cancelled', 'woocommerce-appointments' ),
                WC_Appointments_Constants::STATUS_COMPLETE             => __( 'Complete', 'woocommerce-appointments' ),
            ],
        );
	} elseif ( 'customer' === $context ) {
		$statuses = apply_filters(
		    'woocommerce_appointment_statuses_for_customer',
		    [
				'expected' => __( 'Expected', 'woocommerce-appointments' ),
				'arrived'  => __( 'Arrived', 'woocommerce-appointments' ),
				'no-show'  => __( 'No-show', 'woocommerce-appointments' ),
			],
		);
	} elseif ( 'cancel' === $context ) {
		$statuses = apply_filters(
		    'woocommerce_appointment_statuses_for_cancel',
		    [
				WC_Appointments_Constants::STATUS_UNPAID               => __( 'Unpaid', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PENDING_CONFIRMATION => __( 'Pending Confirmation', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_CONFIRMED            => __( 'Confirmed', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PAID                 => __( 'Paid', 'woocommerce-appointments' ),
			],
		);
	} elseif ( 'scheduled' === $context ) {
		$statuses = apply_filters(
		    'woocommerce_appointment_statuses_for_scheduled',
		    [
				WC_Appointments_Constants::STATUS_CONFIRMED => __( 'Confirmed', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PAID      => __( 'Paid', 'woocommerce-appointments' ),
			],
		);
	} elseif ( 'all' === $context ) {
		$statuses = apply_filters(
		    'woocommerce_appointment_statuses_for_all',
		    [
				WC_Appointments_Constants::STATUS_UNPAID               => __( 'Unpaid', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PAID                 => __( 'Paid', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PENDING_CONFIRMATION => __( 'Pending Confirmation', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_CONFIRMED            => __( 'Confirmed', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_CANCELLED            => __( 'Cancelled', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_COMPLETE             => __( 'Complete', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_WAS_IN_CART          => __( 'Was In Cart', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_IN_CART              => __( 'In Cart', 'woocommerce-appointments' ),
			],
		);
	} else {
		$statuses = apply_filters(
		    'woocommerce_appointment_statuses_for_fully_scheduled',
		    [
				WC_Appointments_Constants::STATUS_UNPAID               => __( 'Unpaid', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PAID                 => __( 'Paid', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_PENDING_CONFIRMATION => __( 'Pending Confirmation', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_CONFIRMED            => __( 'Confirmed', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_COMPLETE             => __( 'Complete', 'woocommerce-appointments' ),
				WC_Appointments_Constants::STATUS_IN_CART              => __( 'In Cart', 'woocommerce-appointments' ),
			],
		);
	}

	/**
 	 * Filter the return value of get_wc_appointment_statuses.
 	 *
 	 * @since 3.5.6
 	 */
	$statuses = apply_filters( 'woocommerce_appointments_get_wc_appointment_statuses', $statuses );

	// backwards compatibility
	return $include_translation_strings ? $statuses : array_keys( $statuses );
}

/**
 * Acquire a booking lock for a specific time slot to prevent race conditions.
 *
 * Creates a transient-based lock to prevent concurrent bookings of the same time slot.
 * Locks are automatically released after a short TTL (default 5 seconds).
 *
 * @since 4.0.0
 *
 * @param int        $product_id Product ID.
 * @param int        $start_date Start timestamp.
 * @param int        $end_date   End timestamp.
 * @param int|int[]  $staff_id   Optional. Staff ID(s). Default 0.
 *
 * @return bool True if lock acquired, false if already locked.
 */
function wc_appointments_acquire_booking_lock( int $product_id, int $start_date, int $end_date, $staff_id = 0 ): bool {
	// Use booking lock class for consistency.
	$lock = new WC_Appointment_Booking_Lock();
	return $lock->acquire( $product_id, $start_date, $end_date, $staff_id );
}

/**
 * Release a booking lock.
 *
 * Removes the transient-based lock for a specific time slot.
 *
 * @since 4.0.0
 *
 * @param int       $product_id Product ID.
 * @param int       $start_date Start timestamp.
 * @param int       $end_date   End timestamp.
 * @param int|int[] $staff_id   Optional. Staff ID(s). Default 0.
 */
function wc_appointments_release_booking_lock( int $product_id, int $start_date, int $end_date, $staff_id = 0 ): void {
	// Use booking lock class for consistency.
	$lock = new WC_Appointment_Booking_Lock();
	$lock->release( $product_id, $start_date, $end_date, $staff_id );
}

/**
 * Validate and create a new appointment manually.
 *
 * Creates a new appointment for the specified product with the provided data.
 * Validates availability and optionally finds the next available slot if the requested
 * time is unavailable (when $exact is false).
 *
 * @since 1.10.7
 *
 * @see WC_Appointment::new_appointment() for available $new_appointment_data args
 *
 * @param int                  $product_id            Product ID for the appointment.
 * @param array<string, mixed> $new_appointment_data  Optional. Appointment data. {
 *     @type string $start_date Start date/time (timestamp or date string).
 *     @type string $end_date   End date/time (timestamp or date string).
 *     @type int    $staff_id   Staff ID (single staff).
 *     @type array  $staff_ids  Staff IDs (multiple staff).
 *     @type string $timezone   Timezone string.
 * }
 * @param string               $status                Optional. Initial appointment status. Default 'confirmed'.
 * @param bool                 $exact                 Optional. If false, find next available slot if requested time unavailable. Default false.
 *
 * @return WC_Appointment|false Appointment object on success, false on failure.
 *
 * @throws Exception If appointment cannot be created (logged, not thrown).
 *
 * @example
 * // Create appointment for tomorrow at 2 PM
 * $appointment = create_wc_appointment(
 *     123,
 *     [
 *         'start_date' => strtotime( 'tomorrow 14:00' ),
 *         'end_date'   => strtotime( 'tomorrow 15:00' ),
 *         'staff_id'   => 5,
 *     ],
 *     'confirmed',
 *     true  // Exact time required
 * );
 */
function create_wc_appointment( int $product_id, $new_appointment_data = [], $status = WC_Appointments_Constants::STATUS_CONFIRMED, $exact = false ) {
	// Use booking handler for appointment creation.
	$handler = new WC_Appointment_Booking_Handler();
	$result  = $handler->create_appointment( $product_id, $new_appointment_data, $status, $exact );

	// Maintain backward compatibility: return false on error (not WP_Error).
	if ( is_wp_error( $result ) ) {
		return false;
	}

	return $result;
}

/**
 * Check if product/appointment requires confirmation.
 *
 * @since 1.0.0
 *
 * @param int $id Product ID.
 *
 * @return bool True if product requires confirmation, false otherwise.
 */
function wc_appointment_requires_confirmation( int $id ): bool {
	$product = wc_get_product( $id );
    return is_wc_appointment_product( $product ) && $product->requires_confirmation();
}

/**
 * Check if product/appointment is sold individually.
 *
 * @since 1.0.0
 *
 * @param int $id Product ID.
 *
 * @return bool True if product is sold individually, false otherwise.
 */
function wc_appointment_sold_individually( int $id ): bool {
	$product = wc_get_product( $id );
    return is_wc_appointment_product( $product ) && $product->is_sold_individually();
}

/**
 * Check if the cart has appointment that requires confirmation.
 *
 * Iterates through cart contents to determine if any appointment product
 * requires confirmation before booking.
 *
 * @since 1.0.0
 *
 * @return bool True if any cart item requires confirmation, false otherwise.
 */
function wc_appointment_cart_requires_confirmation(): bool {
	$has_it = false;

	if ( ! empty( WC()->cart->cart_contents ) ) {
		foreach ( WC()->cart->cart_contents as $item ) {
			if ( wc_appointment_requires_confirmation( $item['product_id'] ) ) {
				$has_it = true;
				break;
			}
		}
	}

	return $has_it;
}

/**
 * Check if the order has appointment that requires confirmation.
 *
 * Iterates through order items to determine if any appointment product
 * requires confirmation before booking.
 *
 * @since 1.0.0
 *
 * @param WC_Order|int|false $order Order object, order ID, or false.
 *
 * @return bool True if any order item requires confirmation, false otherwise.
 */
function wc_appointment_order_requires_confirmation( $order ): bool {
	$requires = false;

	if ( $order && is_a( $order, 'WC_Order' ) ) {
		foreach ( $order->get_items() as $item ) {
			if ( wc_appointment_requires_confirmation( $item['product_id'] ) ) {
				$requires = true;
				break;
			}
		}
	}

	return $requires;
}

/**
 * Get timezone string.
 *
 * Deprecated wrapper for wc_timezone_string(). Use wc_timezone_string() directly.
 * Inspired by https://wordpress.org/plugins/event-organiser/
 *
 * @since 1.0.0
 * @deprecated 4.22.5 Use wc_timezone_string() instead.
 *
 * @return string Timezone string (e.g., 'America/New_York', 'UTC+5').
 */
function wc_appointment_get_timezone_string(): string {
	wc_deprecated_function( __FUNCTION__, '4.22.5', 'wc_timezone_string' );
	return wc_timezone_string();
}

/**
 * Calculate appointment duration in minutes.
 *
 * Calculates the duration between start and end timestamps, optionally
 * formatting the result based on the duration unit.
 *
 * @since 1.0.0
 *
 * @param int    $start         Start timestamp.
 * @param int    $end           End timestamp.
 * @param string $duration_unit Optional. Duration unit for formatting. Default 'minute'.
 * @param bool   $pretty        Optional. Whether to return formatted string. Default true.
 *
 * @return string|int Formatted duration string if $pretty is true, otherwise minutes as integer.
 */
function wc_appointment_duration_in_minutes( int $start, int $end, ?string $duration_unit = WC_Appointments_Constants::DURATION_MINUTE, bool $pretty = true ) {
	$duration_unit = is_string( $duration_unit ) && '' !== $duration_unit ? $duration_unit : WC_Appointments_Constants::DURATION_MINUTE;
	if ( ! in_array( $duration_unit, WC_Appointments_Constants::get_duration_units(), true ) ) {
		$duration_unit = WC_Appointments_Constants::DURATION_MINUTE;
	}

	if ( $start && $end ) {
		$start_time = round( $start / 60 ) * 60; #round to nearest minute
		$end_time   = round( $end / 60 ) * 60; #round to nearest minute
		$timeDiff   = abs( $end_time - $start_time ); #calculate difference
		$time       = intval( $timeDiff / 60 ); #force integer value

		// Return minutes.
		if ( $pretty ) {
			return WC_Appointment_Duration::format_minutes( $time, $duration_unit );
		}

		return $time;
	}

	return 0;
}

/**
 * Convert timestamp to formated time.
 *
 * @param  int  $timestamp
 * @param  bool $is_all_day
 *
 * @return string|false
 */
function wc_appointment_format_timestamp( $timestamp, bool $is_all_day = false ) {
	if ( $timestamp ) {
		$date_format = wc_appointments_date_format();
		$time_format = ', ' . wc_appointments_time_format();
		if ( $is_all_day ) {
			return wc_appointments_format_all_day_civil_date( (int) $timestamp, $date_format );
		}
        return date_i18n( $date_format . $time_format, $timestamp );
	}
	return false;
}

/** Fake UTC civil Y-m-d → localized date (day/month tokens; not wp_date). */
function wc_appointments_format_all_day_civil_date( int $timestamp, ?string $date_format = null ): string {
	return $timestamp ? date_i18n( $date_format ?: wc_appointments_date_format(), strtotime( gmdate( 'Y-m-d', $timestamp ) ) ) : '';
}

/**
 * Convert time in minutes to hours and minutes.
 *
 * @since 1.0.0
 * @deprecated 5.1.0 Use WC_Appointment_Duration::format_addon_duration() instead.
 *
 * @param int $time Time in minutes (can be negative).
 *
 * @return string|false Formatted addon duration with prefix, or false if time is empty/zero.
 */
function wc_appointment_pretty_addon_duration( $time ) {
	wc_deprecated_function( __FUNCTION__, '5.1.0', 'WC_Appointment_Duration::format_addon_duration()' );

	global $product;

	return WC_Appointment_Duration::format_addon_duration( (int) $time, $product );
}

/**
 * Convert duration in minutes to pretty time display.
 *
 * Formats a duration in minutes as a human-readable string based on the duration unit.
 *
 * @since 1.0.0
 * @deprecated 5.1.0 Use WC_Appointment_Duration::format_minutes() instead.
 *
 * @param int    $time          Duration in minutes.
 * @param string $duration_unit Optional. Duration unit for formatting. Default 'minute'.
 *
 * @return string Formatted duration string (e.g., "2 hours", "30 minutes").
 */
function wc_appointment_pretty_timestamp( int $time, ?string $duration_unit = WC_Appointments_Constants::DURATION_MINUTE ): string {
	wc_deprecated_function( __FUNCTION__, '5.1.0', 'WC_Appointment_Duration::format_minutes()' );

	$duration_unit = is_string( $duration_unit ) && '' !== $duration_unit ? $duration_unit : WC_Appointments_Constants::DURATION_MINUTE;
	if ( ! in_array( $duration_unit, WC_Appointments_Constants::get_duration_units(), true ) ) {
		$duration_unit = WC_Appointments_Constants::DURATION_MINUTE;
	}

	return WC_Appointment_Duration::format_minutes( $time, $duration_unit );
}

/**
 * Convert duration in minutes to array of duration parameters.
 * Convert time in minutes to duration parameters (duration and duration_unit).
 *
 * Calculates the most appropriate duration unit (month, day, hour, or minute)
 * based on the total time in minutes, breaking down larger units when possible.
 *
 * @since 4.9.8
 * @deprecated 5.1.0 Use WC_Appointment_Duration::from_minutes() instead.
 *
 * @param int $time Time in minutes to convert.
 *
 * @return array{
 *     duration: int,
 *     duration_unit: string
 * } Duration parameters array with 'duration' (int) and 'duration_unit' (string) keys.
 *   Duration unit will be one of: 'minute', 'hour', 'day', 'month'.
 *
 * @example
 * // Convert 1440 minutes (1 day) to duration parameters
 * $params = wc_appointment_duration_parameters( 1440 );
 * // Returns: ['duration' => 1, 'duration_unit' => 'day']
 *
 * @see WC_Appointment_Duration For a structured result object version with additional methods.
 */
function wc_appointment_duration_parameters( int $time ): array {
	wc_deprecated_function( __FUNCTION__, '5.1.0', 'WC_Appointment_Duration::from_minutes()' );

	$result = WC_Appointment_Duration::from_minutes( $time );
	return apply_filters( 'wc_appointment_duration_parameters', $result->to_array(), $time );
}

/**
 * Get timezone offset in seconds.
 *
 * Calculates the timezone offset in seconds for the site's configured timezone.
 * Falls back to GMT offset if timezone string is not available.
 *
 * @since 3.1.8
 *
 * @return int Timezone offset in seconds (can be negative for timezones behind UTC).
 */
function wc_appointment_timezone_offset(): int {
	$timezone = wc_timezone_string();

	if ( $timezone ) {
		$timezone_object = new DateTimeZone( $timezone );
		return $timezone_object->getOffset( new DateTime( 'now' ) );
	}
	return (int) round( floatval( get_option( 'gmt_offset', 0 ) ) * HOUR_IN_SECONDS );
}

/**
 * Get the offset in seconds between a timezone and UTC.
 *
 * Calculates the timezone offset in seconds for a given timezone string.
 * Returns false if timezone is invalid or empty.
 *
 * @since 1.0.0
 *
 * @param string $timezone Timezone string (e.g., 'America/New_York', 'UTC+5').
 *
 * @return int|false Timezone offset in seconds, or false on failure.
 */
function wc_appointment_get_timezone_offset( string $timezone ) {
	if ( ! $timezone ) {
		return false;
	}

	$gmt_offset = 0;

	// Map UTC+- timezones to gmt_offsets and set timezone_string to empty.
	if ( preg_match( '/^UTC[+-]/', $timezone ) ) {
		$gmt_offset = $timezone;
		$gmt_offset = preg_replace( '/UTC\+?/', '', $gmt_offset );
		$gmt_offset *= HOUR_IN_SECONDS;
		$timezone   = '';
	}

	if ( $timezone ) {
		$utc_tz   = new DateTimeZone( $timezone );
		$utc_date = new DateTime( 'now', $utc_tz );

		$offset = $utc_tz->getOffset( $utc_date );

		return (int) $offset;

	}
    $offset = $gmt_offset;
    return (int) $offset;
}

/**
 * Localized timezone name.
 *
 * Returns short timezone abbreviations (CEST, BST, JST) instead of city names.
 * Pass $at for appointment-bound display so DST acronyms match the booked moment.
 *
 * @since 4.0.0
 * @since 5.2.0 Changed to return short names instead of city names.
 * @since 5.5.0 DST-aware; optional $at instant.
 *
 * @param string                     $timezone    Timezone string.
 * @param bool                       $with_offset Include UTC offset in display.
 * @param DateTimeInterface|int|null $at          Optional. Instant for DST-correct abbr. Null = now.
 *
 * @return string Timezone short name (e.g., 'CEST', 'BST').
 */
function wc_appointment_get_timezone_name( $timezone = '', $with_offset = false, $at = null ): string {
	if ( empty( $timezone ) ) {
		return '';
	}
	if ( $with_offset ) {
		return WC_Appointments_Timezone_Helper::get_timezone_label( $timezone, $at );
	}
	return WC_Appointments_Timezone_Helper::get_timezone_short_name( $timezone, $at );
}

/**
 * Get the city name for a timezone.
 *
 * @since 5.2.0
 *
 * @param string $timezone Timezone string.
 *
 * @return string Localized city name.
 */
function wc_appointment_get_timezone_city_name( $timezone = '' ): string {
	return WC_Appointments_Timezone_Helper::get_city_name( $timezone );
}

/**
 * Convert Unix timestamps to/from various locales.
 *
 * Converts a timestamp from one timezone/locale to another, applying timezone offsets
 * and formatting the result according to the specified format.
 *
 * ============================================================================
 * TIMEZONE ARCHITECTURE - CRITICAL FOR DEVELOPERS
 * ============================================================================
 *
 * This function handles timezone conversion and is DST-AWARE.
 *
 * WHEN TO USE THIS FUNCTION:
 * ✅ Converting for DISPLAY when customer timezone differs from site timezone
 * ✅ Converting customer INPUT from their timezone TO site timezone
 * ✅ Email display in customer's preferred timezone
 *
 * WHEN NOT TO USE THIS FUNCTION:
 * ❌ Extracting time components for admin display (use date() directly)
 * ❌ Comparing timestamps for availability (timestamps are already comparable)
 * ❌ Storing timestamps (they should be site timezone as UTC)
 *
 * DST HANDLING:
 * This function uses DateTimeZone::getOffset() which automatically accounts for
 * Daylight Saving Time. The offset is calculated FOR THE SPECIFIC TIMESTAMP,
 * not as a fixed value.
 *
 * See docs/TIMEZONE_ARCHITECTURE.md for full explanation.
 * ============================================================================
 *
 * @since 1.0.0
 *
 * @param string $from         Source timezone identifier ('site', 'user', or timezone string). Default empty (GMT).
 * @param string $to           Target timezone identifier ('site', 'user', or timezone string). Default empty (GMT).
 * @param int|string $time         Unix timestamp to convert.
 * @param string $format       Optional. PHP date format string. Default 'U' (Unix timestamp).
 * @param string $user_timezone Optional. User timezone string (used when $from or $to is 'user'). Default empty.
 * @param bool   $reverse      Optional. Reverse the conversion direction. Default false.
 *
 * @return string|false Formatted date string, or false if timestamp is invalid.
 *
 * @example
 * // Convert timestamp from site timezone to user timezone
 * $formatted = wc_appointment_timezone_locale( 'site', 'user', time(), 'Y-m-d H:i:s', 'America/New_York' );
 */
function wc_appointment_timezone_locale( string $from = '', string $to = '', $time = '', string $format = 'U', string $user_timezone = '', bool $reverse = false ) {
	if ( ! is_numeric( $time ) || PHP_INT_MAX < $time || $time < ~PHP_INT_MAX ) {
		return false;
	}

	$from_tz_str = ( 'site' === $from ) ? wc_timezone_string() : ( ( 'user' === $from ) ? $user_timezone : 'GMT' );
	$to_tz_str   = ( 'site' === $to ) ? wc_timezone_string() : ( ( 'user' === $to ) ? $user_timezone : 'GMT' );

	// Wall-clock-based conversion (DST-safe).
	//
	// Our timestamps are "site-tz-as-UTC" integers: date('H:i', $time) returns
	// the site-local wall-clock time because PHP runs in UTC mode. We leverage
	// this by extracting the wall-clock string, then creating a proper DateTime
	// in the source timezone. DateTime::setTimezone() handles DST correctly
	// because it knows the exact wall-clock moment in the source timezone.
	//
	// The old offset-arithmetic approach evaluated offsets at the stored integer
	// (which is NOT the true UTC instant), causing 1-hour errors when the gap
	// between stored value and true UTC straddled a DST transition.
	try {
		// Extract wall-clock components from the stored integer.
		$wall_clock = date( 'Y-m-d H:i:s', (int) $time );

		if ( $reverse ) {
			// Reverse: $time is in $to_tz_str, convert to $from_tz_str.
			$dt = new DateTime( $wall_clock, new DateTimeZone( wc_appointments_normalize_timezone( $to_tz_str ) ) );
			$dt->setTimezone( new DateTimeZone( wc_appointments_normalize_timezone( $from_tz_str ) ) );
		} else {
			// Forward: $time is in $from_tz_str, convert to $to_tz_str.
			$dt = new DateTime( $wall_clock, new DateTimeZone( wc_appointments_normalize_timezone( $from_tz_str ) ) );
			$dt->setTimezone( new DateTimeZone( wc_appointments_normalize_timezone( $to_tz_str ) ) );
		}

		// For 'U' format, return a site-tz-as-UTC integer (matching our architecture):
		// extract the converted wall-clock and run it through strtotime() so
		// date('H:i', $result) returns the target-timezone time.
		if ( 'U' === $format ) {
			return (string) strtotime( $dt->format( 'Y-m-d H:i:s' ) );
		}

		return $dt->format( $format );
	} catch ( Exception $e ) {
		// Fallback: return the original time formatted as requested.
		return date( $format, (int) $time );
	}
}

/**
 * Filter core WP function wp_timezone_choice().
 *
 * Shows city names with short timezone abbreviations (CET, PT, JST).
 *
 * @since 4.25.0
 * @since 5.2.0 Enhanced to show short names alongside city names.
 *
 * @param string $selected        Selected timezone value.
 * @param string $locale          Locale for translations.
 * @param bool   $include_default Include "Default" option.
 *
 * @return string HTML select dropdown with timezone choices.
 */
function wc_appointments_wp_timezone_choice( $selected = '', $locale = '', $include_default = true ): string {
	return WC_Appointments_Timezone_Helper::get_timezone_dropdown( $selected, $locale, $include_default );
}

/**
 * Normalize a timezone string to a format accepted by PHP's DateTimeZone.
 *
 * PHP's DateTimeZone accepts named timezones (e.g. "America/New_York") and
 * numeric offsets in "+HH:MM" / "-HH:MM" format, but NOT the "UTC+X" or
 * "UTC-X" style that WordPress timezone pickers may produce.
 *
 * Examples:
 *   "UTC+12"   → "+12:00"
 *   "UTC-5"    → "-05:00"
 *   "UTC+5:30" → "+05:30"
 *   "UTC"      → "UTC"
 *   "America/New_York" → "America/New_York" (unchanged)
 *
 * @since 4.7.0
 *
 * @param string $timezone Timezone string to normalize.
 * @return string Normalized timezone string safe for DateTimeZone::__construct().
 */
function wc_appointments_normalize_timezone( string $timezone ): string {
	if ( preg_match( '/^UTC([+-])(\d{1,2})(?::(\d{2}))?$/', $timezone, $m ) ) {
		$sign    = $m[1];
		$hours   = str_pad( $m[2], 2, '0', STR_PAD_LEFT );
		$minutes = isset( $m[3] ) ? $m[3] : '00';
		return $sign . $hours . ':' . $minutes;
	}
	return $timezone;
}

/**
 * Convert minutes offset to timestamp.
 *
 * Adds the specified number of minutes to a base date and returns the resulting timestamp.
 *
 * @since 3.0.0
 *
 * @param int $minute    Number of minutes to add.
 * @param int $check_date Base timestamp to add minutes to.
 *
 * @return int Timestamp after adding minutes.
 *
 * @example
 * // Add 30 minutes to current time
 * $future_time = wc_appointment_minute_to_time_stamp( 30, time() );
 */
function wc_appointment_minute_to_time_stamp( $minute, $check_date ): int {
	return strtotime( "+ $minute minutes", $check_date );
}

/**
 * Convert a timestamp into the minutes after 0:00 (midnight).
 *
 * Calculates how many minutes have passed since midnight for a given timestamp.
 * Useful for time-of-day calculations and scheduling.
 *
 * @since 3.0.0
 *
 * @param int $timestamp Unix timestamp.
 *
 * @return int Minutes after midnight (0-1439).
 *
 * @example
 * // Get minutes after midnight for 2:30 PM
 * $minutes = wc_appointment_time_stamp_to_minutes_after_midnight( strtotime( '14:30' ) );
 * // Returns: 870 (14 * 60 + 30)
 */
function wc_appointment_time_stamp_to_minutes_after_midnight( $timestamp ): int {
	$hour = absint( date( 'H', $timestamp ) );
	$min  = absint( date( 'i', $timestamp ) );

	return $min + ( $hour * 60 );
}

/**
 * Convert a timestamp into ISO8601 format.
 *
 * Converts a Unix timestamp to ISO8601 date-time format (YYYY-MM-DDTHH:MM:SS)
 * using the site's configured timezone.
 *
 * @since 4.2.5
 *
 * @param int $timestamp Unix timestamp to convert.
 *
 * @return string ISO8601 formatted date-time string (e.g., '2024-01-15T14:30:00').
 */
function get_wc_appointment_time_as_iso8601( $timestamp ): string {
	$timezone    = wc_timezone_string();
	$server_time = new DateTime( date( 'Y-m-d\TH:i:s', $timestamp ), new DateTimeZone( $timezone ) );

	return $server_time->format( 'Y-m-d\TH:i:s' );
}

/**
 * Get explanation text for appointment availability rules.
 *
 * Returns translated explanation of how availability rules work (rules lower
 * in the table override rules higher in the table).
 *
 * @since 1.9.13
 *
 * @return string Translated explanation text about availability rules.
 */
function get_wc_appointment_rules_explanation(): string {
	return __( 'Rules further down the table will override those at the top.', 'woocommerce-appointments' );
}

/**
 * Get explanation text for appointment rule priority system.
 *
 * Returns translated explanation of how priority numbers work in appointment availability rules.
 *
 * @since 1.9.13
 *
 * @return string Translated explanation text about priority rules.
 */
function get_wc_appointment_priority_explanation(): string {
	return __( 'Rules with lower priority numbers will override rules with a higher priority (e.g. 9 overrides 10 ). General rules take priority over product rules which take priority over staff rules. By using priority numbers you can execute rules in different orders.', 'woocommerce-appointments' );
}

/**
 * Write to WooCommerce log files.
 *
 * Adds a log entry to the WooCommerce logger with the specified log ID and message.
 *
 * @since 1.0.0
 *
 * @param string $log_id  Log identifier/context (e.g., 'appointments', 'booking').
 * @param string $message Log message to write.
 *
 * @return void
 *
 * @example
 * // Log an appointment creation
 * wc_add_appointment_log( 'appointments', 'Appointment #123 created successfully' );
 */
function wc_add_appointment_log( $log_id, $message ): void {
	$log = wc_get_logger();
	$log->add( $log_id, $message );
}

/**
 * Normalize staff IDs to an array format.
 *
 * Ensures staff IDs are always in array format, converting single values to arrays.
 * If empty, returns an empty array.
 *
 * @since 5.0.2
 *
 * @param int|int[]|mixed $staff_ids Staff ID(s) to normalize. Can be a single ID, array of IDs, or empty.
 * @return int[] Array of staff IDs. Empty array if input is empty or invalid.
 *
 * @example
 * // Single ID
 * $ids = wc_appointments_normalize_staff_ids( 123 ); // Returns [123]
 *
 * // Already an array
 * $ids = wc_appointments_normalize_staff_ids( [123, 456] ); // Returns [123, 456]
 *
 * // Empty
 * $ids = wc_appointments_normalize_staff_ids( [] ); // Returns []
 */
function wc_appointments_normalize_staff_ids( $staff_ids ): array {
	if ( empty( $staff_ids ) ) {
		return [];
	}

	if ( is_array( $staff_ids ) ) {
		return array_filter( array_map( 'intval', $staff_ids ) );
	}

	return [ (int) $staff_ids ];
}

/**
 * Validate appointment cart item structure.
 *
 * Checks if a cart item contains valid appointment data structure.
 * Returns true if the cart item has appointment data in the expected format.
 *
 * @since 5.0.2
 *
 * @param array<string, mixed> $cart_item Cart item array to validate.
 * @return bool True if cart item has valid appointment data, false otherwise.
 *
 * @example
 * // Validate cart item
 * if ( wc_appointments_validate_cart_item( $cart_item ) ) {
 *     $appointment_data = $cart_item['appointment'];
 *     // Process appointment...
 * }
 */
function wc_appointments_validate_cart_item( array $cart_item ): bool {
	return ! empty( $cart_item['appointment'] ) && is_array( $cart_item['appointment'] );
}

/**
 * In-cart hold post ID for a single-booking cart line.
 *
 * @since 5.4.0
 *
 * @param array<string, mixed> $cart_item Cart line.
 * @return int
 */
function wc_appointments_get_cart_item_hold_appointment_id( array $cart_item ): int {
	return (int) ( $cart_item['appointment']['_appointment_id'] ?? 0 );
}

/**
 * Normalize appointment start for comparing to Provider slot `start_ts` during checkout.
 *
 * Day-duration slots already use the same Unix instant as `WC_Appointment::get_start()`; re-parsing
 * through `date()` and the site timezone would shift that value when PHP default TZ is UTC and the
 * store uses a non-UTC zone, causing false "slot no longer available" at checkout.
 *
 * @since 5.3.6
 *
 * @param int    $appointment_start_ts `WC_Appointment::get_start()`.
 * @param string $duration_unit        Product duration unit (`WC_Product_Appointment::get_duration_unit()`).
 * @return int Timestamp to compare with `WC_Appointment_Slot::$start_ts`.
 */
function wc_appointments_checkout_slot_compare_start_ts( int $appointment_start_ts, string $duration_unit ): int {
	$compare_start = $appointment_start_ts;
	// Month may still use site-local midnights; day/night use Fake UTC tokens (compare as-is).
	if ( WC_Appointments_Constants::DURATION_MONTH === $duration_unit ) {
		$site_tz_obj   = new DateTimeZone( wc_timezone_string() );
		$site_date_str = date( 'Y-m-d H:i:s', $compare_start );
		$dt            = new DateTime( $site_date_str, $site_tz_obj );
		$compare_start = (int) $dt->getTimestamp();
	}
	return $compare_start;
}

/**
 * Get staff members from staff IDs.
 *
 * Retrieves staff member objects, names, or HTML links based on staff IDs.
 * Can return an array of staff objects, a comma-separated string of names, or HTML links.
 *
 * @since 1.0.0
 *
 * @param list<int>|int $ids       Staff ID(s) - can be single ID or array of IDs.
 * @param bool          $names     Optional. If true, returns comma-separated string of names. Default false.
 * @param bool          $with_link Optional. If true, returns HTML links. Default false.
 *
 * @return array<int, WC_Product_Appointment_Staff>|string {
 *     Return format depends on parameters:
 *     - If $names is true: comma-separated string of staff names.
 *     - If $with_link is true: array of HTML anchor tags.
 *     - Otherwise: array of WC_Product_Appointment_Staff objects.
 * }
 *
 * @example
 * // Get staff objects
 * $staff = wc_appointments_get_staff_from_ids( [ 1, 2, 3 ] );
 *
 * // Get staff names as string
 * $names = wc_appointments_get_staff_from_ids( [ 1, 2 ], true );
 * // Returns: "John Doe, Jane Smith"
 */
function wc_appointments_get_staff_from_ids( $ids = [], bool $names = false, bool $with_link = false ) {
	if ( ! is_array( $ids ) ) {
		$ids = [ $ids ];
	}

	$staff_members = [];

	foreach ( $ids as $id ) {
			$staff_member = new WC_Product_Appointment_Staff( $id );

			if ( $with_link ) {
				$staff_members[] = '<a href="' . get_edit_user_link( $staff_member->get_id() ) . '">' . $staff_member->get_display_name() . '</a>';
			} elseif ( $names ) {
				$staff_members[] = $staff_member->get_display_name();
			} else {
				$staff_members[] = $staff_member;
			}
		}

	if ( $names ) {
		if ( [] !== $staff_members ) {
			return implode( ', ', $staff_members );
		}
		// Return empty string when names requested but no staff members found
		return '';
	}

	return $staff_members;
}

/**
 * Get the minimum timestamp that is appointable based on settings.
 *
 * Calculates the earliest bookable timestamp for a given date. If the date is today,
 * the offset starts from NOW rather than midnight. Otherwise, offset starts from midnight.
 *
 * @since 1.0.0
 *
 * @param int    $date   Date timestamp to calculate minimum time for.
 * @param int    $offset Offset value (e.g., 2 for "2 hours").
 * @param string $unit   Offset unit (e.g., 'hours', 'days', 'minutes').
 *
 * @return int Minimum appointable timestamp for the given date.
 */
function wc_appointments_get_min_timestamp_for_day( $date, $offset, $unit ): int {
	$timestamp = $date;

	$now      = current_time( 'timestamp' );
	$is_today = date( 'y-m-d', $date ) === date( 'y-m-d', $now );

	if ($is_today || empty( $date )) {
        return strtotime( "midnight +{$offset} {$unit}", $now );
    }

	return $timestamp;
}

/**
 * Get total available appointments for a date range.
 *
 * Calculates how many appointment slots are available for the requested quantity
 * within the specified date range. Returns availability data for all staff members
 * if product has staff, or a single availability value if no staff.
 *
 * Replaces the WC_Product_Appointment::get_available_appointments method.
 *
 * @since 1.0.0
 *
 * @param WC_Product_Appointment|int $appointable_product Product object or product ID.
 * @param int                        $start_date          Start date timestamp.
 * @param int                        $end_date            End date timestamp.
 * @param int|int[]|null             $staff_id            Optional. Staff ID(s) to check. Default null.
 * @param int                        $qty                 Optional. Quantity requested. Default 1.
 * @param int                        $location_id         Occupancy location (0 = unscoped).
 * @param int                        $resource_id         Customer-selected resource (0 = unscoped).
 *
 * @return array<int, int>|int|false {
 *     Return format depends on product configuration:
 *     - If product has staff and 'all' assignment: array<int, int> Associative array with staff_id => available_qty
 *     - If product has single staff or no staff: int Available quantity for the slot
 *     - If no slots available or invalid dates: false
 * }
 *
 * @example
 * // Check availability for a specific date range
 * $available = wc_appointments_get_total_available_appointments_for_range(
 *     $product,
 *     strtotime( '2024-01-15 10:00' ),
 *     strtotime( '2024-01-15 11:00' ),
 *     null,
 *     1
 * );
 * // Returns: 5 (if 5 slots available) or false (if none available)
 */
function wc_appointments_get_total_available_appointments_for_range( $appointable_product, $start_date, $end_date, $staff_id = null, $qty = 1, $location_id = 0, $resource_id = 0 ) {
	if ( $appointable_product->get_availability_span() ) {
		$end_date = wc_appointments_availability_span_end_date( $appointable_product, $start_date );
	}

	if ( wc_appointments_is_past_request_date( $appointable_product, (int) $start_date ) ) {
		return false;
	}

	// Check we have a staff if needed
	if ( $appointable_product->has_staff() && ! is_numeric( $staff_id ) && !$appointable_product->is_staff_assignment_type( 'all' ) && (is_array($staff_id) && 1 < count( $staff_id )) ) {
		return false;
	}

	$min_date   = $appointable_product->get_min_date_a();
	$max_date   = $appointable_product->get_max_date_a();
	$check_from = strtotime( "midnight +{$min_date['value']} {$min_date['unit']}", current_time( 'timestamp' ) );
	$check_to   = strtotime( "+{$max_date['value']} {$max_date['unit']}", current_time( 'timestamp' ) );

	// Min max checks
	if ( 'month' === $appointable_product->get_duration_unit() ) {
		$check_to = strtotime( 'midnight', strtotime( date( 'Y-m-t', $check_to ) ) );
	}
	if ( $end_date < $check_from || $start_date > $check_to ) {
		return false;
	}

	// PRIMARY PATH: Delegate to the Controller which routes through the
	// Slots Provider (single source of truth). The Provider auto-selects
	// the best engine (index or dynamic) internally — no need to gate
	// on index availability here.
	$available_appointments = \WC_Appointments_Controller::get_indexed_total_available_for_range(
		$appointable_product,
		(int) $start_date,
		(int) $end_date,
		$staff_id,
		(int) $qty,
		null,
		(int) $location_id,
		(int) $resource_id
	);

	if ( $appointable_product->has_staff() && $appointable_product->is_staff_assignment_type( 'all' ) && is_array( $available_appointments ) ) {
		$staff_ids = array_map( 'intval', (array) $appointable_product->get_staff_ids() );
		if ( [] === $staff_ids ) {
			return false;
		}
		foreach ( $staff_ids as $sid ) {
			if ( ! isset( $available_appointments[ $sid ] ) ) {
				return false;
			}
		}
	}

	return $available_appointments;
}

/**
 * Summary of appointment data for admin and checkout.
 *
 * Outputs a formatted summary list of appointment details including product,
 * providers/staff, date, and duration. Used in admin and checkout displays.
 *
 * @since 3.3.0
 *
 * @param WC_Appointment $appointment Appointment object to display summary for.
 * @param bool           $is_admin   Optional. Whether this is being called in admin context. Default false.
 *
 * @return void Outputs HTML directly.
 */
function wc_appointments_get_summary_list( $appointment, $is_admin = false ): void {
	$product   = $appointment->get_product();
	$providers = $appointment->get_staff_members( true );
	$label     = $product && is_callable( [ $product, 'get_staff_label' ] ) && $product->get_staff_label() ? $product->get_staff_label() : __( 'Providers', 'woocommerce-appointments' );

	// Detect email context from WooCommerce order email rendering.
	// When inside a WC order email (e.g. "New Order"), the order manager sets
	// email_sent_to_admin and current_email so we can adapt the timezone.
	$email_sent_to_admin = WC_Appointment_Order_Manager::$email_sent_to_admin;
	$current_email       = WC_Appointment_Order_Manager::$current_email;

	// Override $is_admin when inside a WooCommerce order email sent to admin.
	if ( null !== $email_sent_to_admin && $email_sent_to_admin ) {
		$is_admin = true;
	}

	// Determine timezone for display.
	$customer_tz = $appointment->get_effective_customer_timezone();
	$site_tz     = wc_timezone_string();

	if ( $is_admin ) {
		// Admin context: use recipient_timezone from appointment email class if available,
		// otherwise fall back to site timezone.
		$display_tz = $site_tz;
		if ( $current_email && isset( $current_email->recipient_timezone ) && $current_email->recipient_timezone ) {
			$display_tz = $current_email->recipient_timezone;
		}
	} else {
		// Customer context: use customer's effective timezone.
		$display_tz = $customer_tz;
	}

	// Format date with timezone abbreviation appended via abbr element.
	$date = $appointment->get_start_date_for_email( $display_tz );
	$date = apply_filters( 'wc_appointments_summary_list_date', $date, $appointment, $is_admin );

	$duration = sprintf( '%1$s', $appointment->get_duration() );

	// Customer & staff timezone abbrs for admin display.
	$customer_tz_abbr = '';
	$staff_tz_abbrs   = '';
	if (
		$is_admin &&
		class_exists( 'WC_Appointments_Timezone_Helper' ) &&
		'disabled' !== get_option( 'wc_appointments_timezone_display', 'all' )
	) {
		// Viewer TZ: email recipient's TZ when in email context, otherwise logged-in user's TZ.
		$viewer_tz = $display_tz;
		if ( ! $current_email ) {
			$viewer_tz = WC_Appointments_Timezone_Helper::get_admin_user_timezone();
		}

		// Customer TZ abbr — only when different from viewer's TZ.
		$customer_tz_abbr = WC_Appointments_Timezone_Helper::build_customer_timezone_abbr( $appointment, false, $viewer_tz );

		// Staff TZ abbrs — only when different from viewer's TZ.
		$staff_ids = $appointment->get_staff_ids();
		if ( ! empty( $staff_ids ) ) {
			foreach ( $staff_ids as $_sid ) {
				$staff_tz_abbrs .= WC_Appointments_Timezone_Helper::build_staff_timezone_abbr( (int) $_sid, $appointment, false, $viewer_tz );
			}
		}
	}

		$template_args = apply_filters(
		    'wc_appointments_get_summary_list',
		    [
				'appointment'         => $appointment,
				'product'             => $product,
				'providers'           => $providers,
				'label'               => $label,
				'date'                => $date,
				'duration'            => $duration,
				'location'            => class_exists( 'WC_Appointments_Location' )
					? WC_Appointments_Location::get_context_display( $appointment, $is_admin )
					: $appointment->get_location_display(),
				'location_label'      => get_wc_appointment_data_label( 'location', $product ),
				'resource'            => class_exists( 'WC_Appointments_Resource' )
					? WC_Appointments_Resource::get_context_display( $appointment, $is_admin )
					: '',
				'resource_label'      => class_exists( 'WC_Appointments_Resource' )
					? get_wc_appointment_data_label( 'resource', $product )
					: get_wc_appointment_data_label( 'resource', $product ),
				'meeting_join_url'    => class_exists( 'WC_Appointments_Meetings' )
					? WC_Appointments_Meetings::get_my_account_join_context( $appointment )['url']
					: $appointment->get_meeting_join_url(),
				'is_admin'            => $is_admin,
				'is_rtl'              => is_rtl() ? 'right' : 'left',
				'customer_tz_abbr'    => $customer_tz_abbr,
				'staff_tz_abbrs'      => $staff_tz_abbrs,
			],
		);

	wc_get_template( 'order/appointment-summary-list.php', $template_args, 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
}

/**
 * Converts a string (e.g. 'yes' or 'no') to a boolean.
 *
 * Converts various string representations of boolean values to actual boolean.
 * Uses WooCommerce's wc_string_to_bool() if available, otherwise falls back to custom logic.
 *
 * @since 1.0.0
 *
 * @param string|bool|int $string Value to convert. Accepts 'yes', 'no', 'true', 'false', '1', '0', or actual boolean/int.
 *
 * @return bool Boolean representation of the input.
 *
 * @example
 * // Convert string to bool
 * $result = wc_appointments_string_to_bool( 'yes' );  // Returns true
 * $result = wc_appointments_string_to_bool( 'no' );   // Returns false
 */
function wc_appointments_string_to_bool( $string ): bool {
	if ( function_exists( 'wc_string_to_bool' ) ) {
		return wc_string_to_bool( $string );
	}

	return is_bool( $string ) ? $string : ( 'yes' === $string || 1 === $string || 'true' === $string || '1' === $string );
}

/**
 * Escape and format RRULE string for iCal compatibility.
 *
 * Processes RRULE strings to ensure proper formatting for iCal/calendar systems.
 * Handles UNTIL date adjustments for all-day vs timed events.
 *
 * @since 4.5.14
 *
 * @param string $rrule      RRULE string to process (may contain multiple lines).
 * @param bool   $is_all_day Optional. Whether this is an all-day event. Default false.
 *
 * @return string Processed and escaped RRULE string.
 */
function wc_appointments_esc_rrule( $rrule, $is_all_day = false ): string {
	// Handle multi-line RRULE strings (RRULE + EXDATE lines).
	$lines = array_filter( array_map( 'trim', explode( "\n", $rrule ) ) );
	$processed_lines = [];

	foreach ( $lines as $line ) {
		// Only process RRULE lines for UNTIL adjustments.
		if ( strpos( $line, 'RRULE:' ) === 0 ) {
			// UNTIL is missing time.
			$until_time_missing = false;
			foreach ( explode( ';', $line ) as $pair ) {
				$pair = explode( '=', $pair );
                if (! isset( $pair[1] )) {
                    continue;
                }
                if (isset( $pair[2] )) {
                    continue;
                }
				[$key, $value] = $pair;
				if ( 'UNTIL' === $key && false === strpos( $value, 'T' ) ) {
                    $until_time_missing = true;
                    break;
                }
			}

			// Remove time from UNTIL.
			if ( $is_all_day ) {
				$line = preg_replace_callback(
				    '/UNTIL=([\dTZ]+)(?=;?)/',
				    function( array $matches ): string {
						$dtUntil = new WC_DateTime( substr( $matches[1], 0, 8 ) );
						return 'UNTIL=' . $dtUntil->format( 'Ymd' );
					},
				    $line,
				);

			// Append time to UNTIL.
			} elseif ( $until_time_missing ) {
				$line = preg_replace( '/UNTIL=(\d{8})(?!T)/', 'UNTIL=$1T235959Z', $line );
			}
		}

		// Keep all lines (RRULE, EXDATE, etc.).
		$processed_lines[] = $line;
	}

	return implode( "\n", $processed_lines );
}

/**
 * Return appointment object.
 *
 * @since 4.6.0
 *
 * @param mixed $appointment Appointment object, appointment ID, or order object/ID.
 *
 * @return WC_Appointment|false Appointment object on success, false on failure.
 */
function wc_appointments_maybe_appointment_object( $appointment ) {
	// Check if provided $appointment_id is indeed an $appointment.
	if ( is_a( $appointment, 'WC_Appointment' ) ) {
		return $appointment;
	}
    // Check if provided $appointment_id is an $order.
    // Some extensions use only orders as email triggers
    // so make sure they are also included.
    $order = wc_get_order( $appointment );
    if ( is_a( $order, 'WC_Order' ) ) {
			// Get $appointment_ids from an $order.
			$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_id( $order->get_id() );
			if ( ! empty( $appointment_ids ) && isset( $appointment_ids[0] ) ) {
				// Set $appointment_id from an $order.
				$appointment_id = absint( $appointment_ids[0] );
				// Set $this->object from $appointment_id.
				return get_wc_appointment( $appointment_id );
			}
        return false;
		}
	return false;
}

/**
 * Get an array of formatted time values from a timestamp.
 *
 * Extracts various date/time components from a timestamp and returns them
 * in a structured array format for easy access.
 *
 * @since 1.0.0
 *
 * @param int $timestamp Unix timestamp to extract values from.
 *
 * @return array<string, int|string> {
 * @return array{
 *     timestamp: int,
 *     year: int,
 *     month: int,
 *     day: int,
 *     week: int,
 *     day_of_week: int,
 *     time: string
 * } Formatted time values array with all date/time components extracted from timestamp.
 *
 * Calendar fields (year, month, day, week, day_of_week, time) use the WordPress **site**
 * timezone (wp_timezone), not PHP's default timezone, so server-side pricing matches
 * admin rules and the selected calendar day.
 *
 * When the booking used a posted slot-engine timestamp (see `_slot_token_timestamp` in
 * wc_appointments_get_posted_data()), use wc_appointments_slot_token_formatted_times() instead
 * so components match the slot list and gmdate-based form fields.
 */
function wc_appointments_get_formatted_times( $timestamp ): array {
	$timestamp = (int) $timestamp;
	// Use WordPress site timezone for calendar fields — not PHP's date_default_timezone_get(),
	// which often stays UTC on hosts and breaks pricing rules vs. site-local days (e.g. CEST).
	$tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
	try {
		$dt = ( new DateTimeImmutable( '@' . $timestamp ) )->setTimezone( $tz );
	} catch ( Exception $e ) {
		$dt = new DateTimeImmutable( '@0', new DateTimeZone( 'UTC' ) );
	}

	return [
		'timestamp'   => $timestamp,
		'year'        => (int) $dt->format( 'Y' ),
		'month'       => (int) $dt->format( 'n' ),
		'day'         => (int) $dt->format( 'j' ),
		'week'        => (int) $dt->format( 'W' ),
		'day_of_week' => (int) $dt->format( 'N' ),
		'time'        => $dt->format( 'YmdHi' ),
	];
}

/**
 * Fake UTC civil-day midnight key (day/month slot token axis).
 *
 * @param int $timestamp Slot-engine token or range start.
 * @return int
 */
function wc_appointments_day_slot_midnight_key( $timestamp ): int {
	return (int) strtotime( gmdate( 'Y-m-d 00:00:00', (int) $timestamp ) . ' UTC' );
}

/**
 * End of range when availability span is enabled (caller must check span first).
 *
 * @param WC_Product|object $product    Appointment product.
 * @param int               $start_date Range start.
 * @return int
 */
function wc_appointments_availability_span_end_date( $product, $start_date ) {
	$unit = $product->get_duration_unit();
	// Night is not a PHP strtotime unit; advance in civil days (same as day).
	if ( WC_Appointments_Constants::DURATION_NIGHT === $unit ) {
		$unit = WC_Appointments_Constants::DURATION_DAY;
	}
	$anchor = in_array( $unit, [ 'day', 'month' ], true ) ? wc_appointments_day_slot_midnight_key( $start_date ) : $start_date;

	return (int) strtotime( '+' . (int) $product->get_duration() . ' ' . $unit, $anchor );
}

/**
 * Whether the requested start is before today (Fake UTC civil axis vs site today).
 *
 * Booking and slot-engine instants store site wall digits as UTC-labelled ints; civil
 * day extraction uses gmdate() on both the start and Fake UTC "now". Using wp_date() on
 * current_time() re-applies the site offset and flips "today" forward on positive-offset
 * stores (e.g. Australia/Sydney after ~13:00), rejecting same-day slots as past (#1478).
 *
 * @param WC_Product|object|null $product    Appointment product (reserved for callers).
 * @param int                    $start_date Range start timestamp (Fake UTC wall).
 * @param int|null               $now        Optional Fake UTC "now" (tests); default current_time().
 * @return bool
 */
function wc_appointments_is_past_request_date( $product, int $start_date, ?int $now = null ): bool {
	if ( $start_date <= 0 ) {
		return true;
	}

	if ( null === $now ) {
		$now = current_time( 'timestamp' );
	}

	return gmdate( 'Ymd', $start_date ) < gmdate( 'Ymd', $now );
}

/**
 * Formatted time parts for a slot-engine "wall clock as UTC" timestamp.
 *
 * The slot list posts `wc_appointments_field_start_date_timestamp` values that are decoded
 * with gmdate() in wc_appointments_get_posted_data(); interpreting those with wp_timezone()
 * would shift civil time. This helper returns the same shape as wc_appointments_get_formatted_times()
 * using UTC calendar extraction (gmdate) so pricing windows align with listed slots.
 *
 * @param int $timestamp Slot-engine token timestamp.
 * @return array<string, int|string> Same keys as wc_appointments_get_formatted_times().
 */
function wc_appointments_slot_token_formatted_times( $timestamp ): array {
	$timestamp = (int) $timestamp;

	return [
		'timestamp'   => $timestamp,
		'year'        => (int) gmdate( 'Y', $timestamp ),
		'month'       => (int) gmdate( 'n', $timestamp ),
		'day'         => (int) gmdate( 'j', $timestamp ),
		'week'        => (int) gmdate( 'W', $timestamp ),
		'day_of_week' => (int) gmdate( 'N', $timestamp ),
		'time'        => gmdate( 'YmdHi', $timestamp ),
	];
}

/**
 * Get posted form data into a neat array.
 *
 * Processes and sanitizes appointment booking form data from $_POST or provided array.
 * Extracts date, time, staff, quantity, and other appointment-related fields.
 *
 * @since 4.7.0
 *
 * @param array<string, mixed> $posted   Optional. Posted data array. Default empty (uses $_POST).
 * @param WC_Product|false     $product  Optional. Product object. Default false.
 * @param string|bool          $get_data Optional. Additional data retrieval flag. Default false.
 *
 * @return array<string, mixed>|false {
 *     Processed appointment data array, or false on failure.
 *
 *     Common keys include:
 *     - _year (string): Year value
 *     - _month (string): Month value
 *     - _day (string): Day value
 *     - _date (string): Combined date string (Y-m-d)
 *     - _start_date (int): Start timestamp
 *     - _end_date (int): End timestamp
 *     - _staff_id (int|string): Staff ID (or empty string for 'all' assignment)
 *     - staff (string): Staff name(s)
 *     - _qty (int): Quantity
 *     - _timezone (string): Timezone string
 *     - _local_timezone (string): Local timezone string
 *     - _slot_token_timestamp (bool): True when start instant came from posted slot-engine timestamp (use token-aware pricing).
 *     - Additional keys may be present based on product configuration
 * }
 */
/**
 * Get and process posted appointment data with timezone handling.
 *
 * TIMEZONE ARCHITECTURE:
 * ======================
 * This function processes appointment form data and handles timezone conversion when necessary.
 *
 * Core Principle:
 * - Timestamps are stored as UTC but represent times in the site's configured timezone
 * - When customer timezone differs from site timezone, conversion happens here
 * - Final timestamps always represent site timezone times (stored as UTC)
 *
 * Timezone Handling:
 * 1. If product supports timezones AND customer selected a timezone:
 *    - Parse input in customer's timezone
 *    - Convert to site timezone
 *    - Store as UTC timestamp (representing site timezone time)
 *    - Save customer timezone in _local_timezone for future reference
 *
 * 2. If no customer timezone or product doesn't support timezones:
 *    - Parse input in site timezone
 *    - Store as UTC timestamp (representing site timezone time)
 *
 * 3. Final timestamps (_start_date, _end_date):
 *    - Always UTC timestamps representing site timezone times
 *    - Use local methods (date(), format()) to extract components
 *    - Never use UTC-specific methods when extracting
 *
 * Future Customer Timezone Support:
 * - When customer accounts have timezone preferences, this function will:
 *   1. Get customer timezone from account settings
 *   2. Convert customer timezone → site timezone → UTC timestamp
 *   3. Store both timezone and local_timezone metadata
 *
 * @param array<string, mixed> $posted   Posted form data (defaults to $_POST if empty).
 * @param object|false  $product  Product object (WC_Product_Appointment).
 * @param string|bool|false $get_data Optional. Specific data key to return, or legacy true for full data.
 *
 * @return array<string, mixed>|mixed Processed appointment data array, or specific value if $get_data provided.
 */
function wc_appointments_get_posted_data( $posted = [], $product = false, $get_data = false ) {
	if ( empty( $posted ) ) {
		$posted = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- Sanitized per field below; caller may verify nonce.
	}
	if ( ! is_array( $posted ) ) {
		$posted = [];
	}

	$data = [
		'_year'                   => '',
		'_month'                  => '',
		'_day'                    => '',
		'_timezone'               => '',        // Site timezone (always set)
		'_local_timezone'         => '',        // Customer timezone (if different from site)
		'_slot_token_timestamp'   => false,     // True when start came from posted slot-engine token.
	];

	// Get year month field.
	if ( ! empty( $posted['wc_appointments_field_start_date_yearmonth'] ) ) {
		$yearmonth      = strtotime( $posted['wc_appointments_field_start_date_yearmonth'] . '-01' );
		$data['_year']  = absint( date( 'Y', $yearmonth ) );
		$data['_month'] = absint( date( 'm', $yearmonth ) );
		$data['_day']   = 1;
		$data['_date']  = $data['_year'] . '-' . $data['_month'] . '-' . $data['_day'];
		$data['date']   = date_i18n( 'F Y', $yearmonth );
	// Get date fields (y, m, d).
	} elseif (
		! empty( $posted['wc_appointments_field_start_date_year'] ) &&
		! empty( $posted['wc_appointments_field_start_date_month'] ) &&
		! empty( $posted['wc_appointments_field_start_date_day'] )
	) {
		$data['_year']  = absint( $posted['wc_appointments_field_start_date_year'] );
		$data['_year']  = $data['_year'] ?: date( 'Y' );
		$data['_month'] = absint( $posted['wc_appointments_field_start_date_month'] );
		$data['_day']   = absint( $posted['wc_appointments_field_start_date_day'] );
		$data['_date']  = $data['_year'] . '-' . $data['_month'] . '-' . $data['_day'];
		$data['date']   = date_i18n( wc_appointments_date_format(), strtotime( $data['_date'] ) );
	}

	// Get time field.
	// IMPORTANT: The _time value is machine-readable (used in strtotime) and must always
	// be in H:i format with ASCII digits. Sanitize to protect against:
	// - Localized digits from date_i18n() (Arabic, Bengali, etc.) in cached/stale slot HTML
	// - Theme JS that reformats the hidden field using user's WP time format (e.g. "2:30 PM")
	// - Any other non-standard format that would break strtotime() and cause overbooking
	if ( ! empty( $posted['wc_appointments_field_start_date_time'] ) ) {
		$raw_time = wc_clean( $posted['wc_appointments_field_start_date_time'] );
		// Normalize: strip non-ASCII digits, parse hours:minutes robustly.
		// Handles "14:30", "2:30 PM", "٢:٣٠", etc.
		$normalized_time = preg_replace( '/[^\d:aApPmM\s]/', '', $raw_time );
		if ( preg_match( '/(\d{1,2}):(\d{2})\s*(AM|PM|am|pm)?/', $normalized_time, $tm ) ) {
			$h = (int) $tm[1];
			$m = (int) $tm[2];
			if ( ! empty( $tm[3] ) ) {
				$period = strtoupper( $tm[3] );
				if ( 'PM' === $period && $h < 12 ) {
					$h += 12;
				} elseif ( 'AM' === $period && 12 === $h ) {
					$h = 0;
				}
			}
			$data['_time'] = sprintf( '%02d:%02d', $h, $m );
		} else {
			// Last resort: use as-is (will be validated by strtotime below).
			$data['_time'] = $raw_time;
		}
		$data['time'] = date_i18n( wc_appointments_time_format(), strtotime( "{$data['_year']}-{$data['_month']}-{$data['_day']} {$data['_time']}" ) );
	} else {
		$data['_time'] = '';
	}

	// Quantity being scheduled.
	$data['_qty'] = absint( $posted['quantity'] ?? 1 );

	// TIMEZONE HANDLING (REFACTORED 5.2.0):
	// ====================================
	// Timezone support is now always enabled site-wide (not per-product).
	// The slot timestamp is passed directly from frontend to avoid double conversion.
	//
	// New Flow (using data-slot-timestamp):
	// 1. Slots are generated in site timezone with original timestamp stored in data-slot-timestamp
	// 2. Display is converted to user timezone for UI only
	// 3. Form submits original timestamp (site TZ) - NO CONVERSION NEEDED
	// 4. Customer timezone is stored in _local_timezone for display purposes
	//
	// Legacy Flow (fallback if timestamp not provided):
	// - Parse display time and convert from user TZ to site TZ
	//
	// Get customer timezone for metadata.
	$site_tzstring = wc_timezone_string();
	$tzstring      = '';

	// When timezone display is disabled, ignore customer timezone entirely — use site timezone.
	$tz_enabled = ! class_exists( 'WC_Appointments_Timezone_Helper' ) || WC_Appointments_Timezone_Helper::should_show_timezone( 'frontend', get_current_user_id() );

	if ( $tz_enabled && isset( $posted['wc_appointments_field_timezone'] ) && $posted['wc_appointments_field_timezone'] ) {
		$tzstring = $posted['wc_appointments_field_timezone'];
	} elseif ( $tz_enabled && ! empty( $_COOKIE['appointments_time_zone'] ) ) {
		$tzstring = sanitize_text_field( wp_unslash( $_COOKIE['appointments_time_zone'] ) );
	}

	// Admin UI (panel + create modal) sends site-local y/m/d/time; never reinterpret via customer cookie.
	$is_admin_site_timezone_input = isset( $posted['is_admin_panel'] ) && '1' === $posted['is_admin_panel'];

	// TIMEZONE FIX: Check if we have the original slot timestamp (preferred method).
	// This avoids double conversion issues - timestamp is already in site timezone.
	// Validate that the value is a real Unix timestamp: reject time strings (e.g. "06:00" or "06%3A00")
	// that broken custom filters can cause when data-slot-timestamp is missing from slot HTML.
	$raw_timestamp = isset( $posted['wc_appointments_field_start_date_timestamp'] ) ? $posted['wc_appointments_field_start_date_timestamp'] : '';
	if ( is_numeric( $raw_timestamp ) ) {
		$slot_timestamp = (int) $raw_timestamp;
		// Reject values that are too small (e.g. absint("06%3A00") = 6) or out of Unix range.
		if ( $slot_timestamp < 86400 || $slot_timestamp > 2147483647 ) {
			$slot_timestamp = 0;
		}
	} else {
		$slot_timestamp = 0;
	}

	if ( $slot_timestamp > 0 ) {
		// Use the original timestamp directly - no conversion needed!
		// Slot timestamp is a wall-clock-as-UTC value; extract components with gmdate() to avoid
		// applying site offset a second time (which can shift late slots into adjacent days).
		$data['_day']    = gmdate( 'd', $slot_timestamp );
		$data['_date']   = gmdate( 'Y-m-d', $slot_timestamp );
		$data['_year']   = gmdate( 'Y', $slot_timestamp );
		$data['_month']  = gmdate( 'm', $slot_timestamp );
		if ( is_object( $product ) && method_exists( $product, 'has_time' ) && $product->has_time() ) {
			$data['_time'] = gmdate( 'H:i', $slot_timestamp );
		} else {
			$data['_time'] = '';
		}
		$data['_slot_timestamp'] = $slot_timestamp;
		$data['_slot_token_timestamp'] = true;
	} elseif ( ! $is_admin_site_timezone_input && $tzstring && $tzstring !== $site_tzstring && ! empty( $data['_time'] ) ) {
		// LEGACY FALLBACK: Timestamp field not available, convert display time from user TZ to site TZ.
		// This handles cases where slots were selected but timestamp wasn't submitted.
		$user_datetime_str   = "{$data['_year']}-{$data['_month']}-{$data['_day']} {$data['_time']}";
		$converted_timestamp = wc_appointment_timezone_locale( 'user', 'site', strtotime( $user_datetime_str ), 'U', $tzstring );

		if ( $converted_timestamp && is_numeric( $converted_timestamp ) ) {
			$converted_timestamp = (int) $converted_timestamp;
			$data['_day']   = gmdate( 'd', $converted_timestamp );
			$data['_date']  = gmdate( 'Y-m-d', $converted_timestamp );
			$data['_time']  = gmdate( 'H:i', $converted_timestamp );
			$data['_year']  = gmdate( 'Y', $converted_timestamp );
			$data['_month'] = gmdate( 'm', $converted_timestamp );
		}
	}

	// Set appointment timezone for saving (always site timezone).
	// This is the timezone that the stored timestamps represent.
	$data['_timezone'] = wc_timezone_string();

	if ( ! is_wc_appointment_product( $product ) ) {
		return $get_data ? ( $data[ $get_data ] ?? false ) : $data;
	}

	// Fixed duration.
	$product_duration_unit = $product->get_duration_unit();
	$product_duration_unit = '' !== $product_duration_unit ? $product_duration_unit : WC_Appointments_Constants::DURATION_MINUTE;

	$duration_unit     = in_array( $product_duration_unit, [ WC_Appointments_Constants::DURATION_MINUTE, WC_Appointments_Constants::DURATION_HOUR ], true ) ? WC_Appointments_Constants::DURATION_MINUTE : $product_duration_unit;
	$duration_in_mins  = WC_Appointments_Constants::DURATION_HOUR === $product_duration_unit ? $product->get_duration() * 60 : $product->get_duration();
	$duration_in_total = WC_Appointments_Constants::DURATION_MONTH === $product_duration_unit ? $product->get_duration() : $duration_in_mins;
	$duration_base  = (float) $duration_in_total;
	$duration_total = $duration_base;
	if ( isset( $posted['wc_appointments_field_addons_duration'] ) && is_numeric( $posted['wc_appointments_field_addons_duration'] ) ) {
		$addon_duration = (float) $posted['wc_appointments_field_addons_duration'];
		if ( 0.0 !== $addon_duration ) {
			$duration_total += $addon_duration;
		}
	}
	$duration_total = (float) apply_filters( 'appointment_form_posted_total_duration', $duration_total, $product, $posted );
	$duration_total = (float) apply_filters( 'wc_appointments_adjust_addon_duration', $duration_total, $duration_base, $product, $posted );
	// Signed Product Add-on minutes may shorten below base. A zero or negative result
	// (filter returning 0/false, or an add-on shortening past zero) keeps the base duration.
	$duration_total = 0 < $duration_total ? $duration_total : $duration_base;

	// Display hours and minutes in a readable form.
	if ( WC_Appointments_Constants::DURATION_MONTH === $product_duration_unit ) {
		/* translators: %s: months in singular or plural */
		$total_duration_n = sprintf( _n( '%s month', '%s months', (int) $duration_total, 'woocommerce-appointments' ), $duration_total );
	} elseif ( WC_Appointments_Constants::DURATION_DAY === $product_duration_unit ) {
		/* translators: %s: days in singular or plural */
		$total_duration_n = sprintf( _n( '%s day', '%s days', (int) $duration_total, 'woocommerce-appointments' ), $duration_total );
	} elseif ( WC_Appointments_Constants::DURATION_NIGHT === $product_duration_unit ) {
		/* translators: %s: nights in singular or plural */
		$total_duration_n = sprintf( _n( '%s night', '%s nights', (int) $duration_total, 'woocommerce-appointments' ), $duration_total );
	} else {
		/* translators: %s: minutes */
		$total_duration_n = WC_Appointment_Duration::format_minutes( (int) $duration_total, WC_Appointments_Constants::DURATION_MINUTE );
	}

	// Calculate start and end timestamps.
	// CRITICAL: These timestamps are UTC but represent times in site timezone.
	// For time-based slots, _end_date uses $duration_total (which includes addon-adjusted
	// duration via 'appointment_form_posted_total_duration' filter). This ensures availability
	// is checked against the full appointment duration by default. When the product's
	// "Availability Check" is set to 'start', wc_appointments_get_total_available_appointments_for_range()
	// overrides end_date to one base slot — so the setting is respected downstream.

	// Guard: if no date components were posted (e.g. admin panel before date selection),
	// skip timestamp parsing entirely — callers handle missing _start_date gracefully.
	if ( empty( $data['_year'] ) || empty( $data['_month'] ) || empty( $data['_day'] ) ) {
		if ( $get_data ) {
			return $data[ $get_data ] ?? false;
		}
		return $data;
	}

	if ( ! empty( $data['_time'] ) && in_array( $product_duration_unit, [ WC_Appointments_Constants::DURATION_MINUTE, WC_Appointments_Constants::DURATION_HOUR ], true ) ) {
		if ( ! empty( $data['_slot_timestamp'] ) ) {
			// Engine start_ts: use as-is so validation matches listed slots (no round-trip via strings).
			$data['_start_date'] = (int) $data['_slot_timestamp'];
			$data['_end_date']   = $data['_start_date'] + ( $duration_total * 60 );
		} else {
			// Site wall clock as UTC-labelled int (Fake UTC), matching slot-engine start_ts.
			$data['_start_date'] = (int) strtotime(
				sprintf( '%04d-%02d-%02d %s:00', $data['_year'], $data['_month'], $data['_day'], $data['_time'] ) . ' UTC'
			);
			$data['_end_date']   = $data['_start_date'] + ( $duration_total * 60 );
		}
		$data['_all_day']  = 0;
		if ( $tzstring && $tzstring !== $site_tzstring ) {
			$data['_local_timezone'] = $tzstring;
		}
		$data['_duration'] = $duration_total;
		$data['duration']  = $total_duration_n;
	} elseif ( in_array( $product_duration_unit, [ WC_Appointments_Constants::DURATION_DAY, WC_Appointments_Constants::DURATION_NIGHT, WC_Appointments_Constants::DURATION_MONTH ], true ) ) {
		// Day/month/night: Fake UTC midnight tokens (Y-m-d 00:00:00 parsed in UTC) so
		// occupancy indexing and slot listing share the same calendar keys.
		// End timestamp must match slot end_ts (midnight of next day/month); do not use "- 1 second".
		$tz_utc = new DateTimeZone( 'UTC' );
		if ( ! empty( $data['_slot_timestamp'] ) ) {
			$start_dt = new DateTimeImmutable( gmdate( 'Y-m-d 00:00:00', (int) $data['_slot_timestamp'] ), $tz_utc );
		} else {
			$start_dt = new DateTimeImmutable(
				sprintf( '%04d-%02d-%02d 00:00:00', $data['_year'], $data['_month'], $data['_day'] ),
				$tz_utc
			);
		}
		$data['_start_date'] = $start_dt->getTimestamp();
		// Night spans use civil days (1 night = midnight → next midnight).
		$span_unit           = WC_Appointments_Constants::DURATION_NIGHT === $product_duration_unit
			? WC_Appointments_Constants::DURATION_DAY
			: $duration_unit;
		$end_dt              = $start_dt->modify( "+{$duration_total} {$span_unit}" );
		$data['_end_date']   = $end_dt->getTimestamp();

		// Day/month/night are civil stays (no clock time). Night must not use the timed display path.
		$data['_all_day']    = 1;
		$data['_duration']   = $duration_total;
		$data['duration']    = $total_duration_n;
		$data['_time']       = '';
		$data['time']        = '';
		// Fake UTC midnight tokens: pricing/cost rules must use gmdate (slot-token axis), not wp_timezone.
		$data['_slot_token_timestamp'] = true;

	}

	// If requested, return data directly
	// before going through expensive resources.
	if ( $get_data ) {
		return $data[ $get_data ] ?? false;
	}

	// Resolve location once (occupancy checks + snapshot write share the same ID).
	$resolved_location = null;
	if ( class_exists( 'WC_Appointments_Location' ) && $product->has_locations() ) {
		$resolved_location = WC_Appointments_Location::resolve_from_posted( $product, $posted );
	}

	// Get posted staff or assign one for the date range.
	if ( $product->has_staff() ) {
		$location_id_for_staff = ( ! is_wp_error( $resolved_location ) && $resolved_location ) ? (int) $resolved_location : 0;

		if ( $product->is_staff_assignment_type( 'customer' ) && ! empty( $posted['wc_appointments_field_staff'] ) ) {
			$staff_id = absint( $posted['wc_appointments_field_staff'] );
			$staff    = $product->get_staff_member( $staff_id );
			if ( $staff ) {
				$data['_staff_id'] = $staff->get_id();
				$data['staff']     = $staff->get_display_name();
			} else {
				$data['_staff_id'] = 0;
			}
		} elseif ( $product->is_staff_assignment_type( 'all' ) ) {
			$eligible             = array_map( 'intval', (array) $product->get_staff_ids() );
			$data['_staff_ids']   = $eligible;
			$data['_staff_names'] = [];
			foreach ( $eligible as $sid ) {
				$member                 = $product->get_staff_member( $sid );
				$data['_staff_names'][] = $member ? $member->get_display_name() : '';
			}
			$data['_staff_id'] = $eligible[0] ?? 0;
			$data['staff']     = implode( ', ', array_filter( $data['_staff_names'] ) );
		} else {
			// Assign an available staff automatically; stop on first hit.
			$eligible = array_values( array_filter( array_map( 'intval', (array) $product->get_staff_ids() ) ) );
			if ( $eligible ) {
				shuffle( $eligible );
				foreach ( $eligible as $candidate_staff_id ) {
					$available = wc_appointments_get_total_available_appointments_for_range(
						$product,
						$data['_start_date'],
						$data['_end_date'],
						(int) $candidate_staff_id,
						$data['_qty'],
						$location_id_for_staff
					);
					if ( false === $available ) {
						continue;
					}
					$cap = is_array( $available )
						? (int) ( $available[ (int) $candidate_staff_id ] ?? reset( $available ) )
						: (int) $available;
					if ( $cap < (int) $data['_qty'] ) {
						continue;
					}
					$staff             = get_user_by( 'id', (int) $candidate_staff_id );
					$data['_staff_id'] = (int) $candidate_staff_id;
					$data['staff']     = $staff ? $staff->display_name : '';
					break;
				}
			}
		}
	}

	// Location (write ID + snapshot at origin; cart display string for label loop).
	if ( null !== $resolved_location ) {
		if ( is_wp_error( $resolved_location ) ) {
			$data['_location_error'] = $resolved_location->get_error_message();
		} elseif ( $resolved_location > 0 ) {
			$lid                  = (int) $resolved_location;
			$snapshot             = WC_Appointments_Location::build_snapshot( $lid );
			$snapshot['cost']     = WC_Appointments_Location::product_location_cost( $product, $lid );
			$data['_location_id'] = $lid;
			$data['_location']    = $snapshot;
			// Fixed (hidden): keep ID/snapshot; omit public cart line like resource assignment "Automatic".
			if ( WC_Appointments_Location::MODE_HIDDEN !== $product->get_location_mode() ) {
				$data['location'] = WC_Appointments_Location::format_snapshot_for_display( $snapshot );
			}
		}
	}

	// Resource allocations from product requirements (OR pool: one resource).
	if ( class_exists( 'WC_Appointments_Resource' ) && $product->has_resources() ) {
		$selected_resource = 0;
		$assignment        = $product->get_resource_assignment();
		if ( $product->is_resource_assignment_type( 'customer' ) ) {
			$selected_resource    = absint( $posted['wc_appointments_field_resource'] ?? 0 );
			$data['_resource_id'] = $selected_resource;
		}
		$loc_for_res = ( ! is_wp_error( $resolved_location ) && $resolved_location ) ? (int) $resolved_location : 0;
		$allocations = WC_Appointments_Resource::build_allocations_from_product(
			$product,
			$selected_resource,
			$loc_for_res,
			isset( $data['_start_date'] ) ? (int) $data['_start_date'] : 0,
			isset( $data['_end_date'] ) ? (int) $data['_end_date'] : 0
		);
		if ( [] !== $allocations ) {
			$data['_resource_allocations'] = $allocations;
			// Automatic + visibility / Customer selects: public cart line like staff.
			if ( in_array( $assignment, [ 'display', 'customer' ], true ) ) {
				$data['resource'] = WC_Appointments_Resource::format_allocations_for_display( $allocations );
			}
		}
	}

	return apply_filters( 'woocommerce_appointments_get_posted_data', $data, $product, $posted );
}

/**
 * Convert a PHP date format string to jQuery UI Datepicker format tokens.
 *
 * Used by the availability filter widget/block. Only date tokens are mapped;
 * time tokens are stripped (the filter is date-only).
 *
 * @since 5.4.0
 *
 * @param string $format PHP date format string (e.g., 'Y-m-d', 'F j, Y').
 *
 * @return string jQuery UI Datepicker format string (e.g., 'yy-mm-dd', 'MM d, yy').
 */
function wc_appointments_convert_to_jquery_datepicker_format( $format ): string {
	$replacements = [
		'd' => 'dd',   // Day with leading zero (01-31).
		'D' => 'D',    // Short weekday (Mon).
		'j' => 'd',    // Day without leading zero (1-31).
		'l' => 'DD',   // Full weekday (Monday).
		'F' => 'MM',   // Full month (January).
		'm' => 'mm',   // Month with leading zero (01-12).
		'M' => 'M',    // Short month (Jan).
		'n' => 'm',    // Month without leading zero (1-12).
		'o' => 'yy',   // ISO year.
		'Y' => 'yy',   // 4-digit year.
		'y' => 'y',    // 2-digit year.
		'S' => '',     // Ordinal suffix (no jQuery UI equivalent).
	];

	return strtr( $format, $replacements );
}

/**
 * Renders a JSON object with a paginated availability set.
 *
 * Paginates an availability array and returns records for the specified page
 * along with the total count of records.
 *
 * @since 4.5.0
 *
 * @param array<int|string, mixed> $availability     Full availability array to paginate.
 * @param int|false                $page            Page number (1-based), or false for all records.
 * @param int                      $records_per_page Number of records per page.
 *
 * @return array{
 *     records: array<int|string, mixed>,
 *     count: int
 * } Paginated result with 'records' (paginated array) and 'count' (total count) keys.
 */
function wc_appointments_paginated_availability( $availability, $page, $records_per_page ): array {
	if ( false === $page ) {
		$records = $availability;
	} else {
		$records = array_slice( $availability, ( $page - 1 ) * $records_per_page, $records_per_page );
	}

	return [
		'records' => $records,
		'count'   => count( $availability ),
	];
}

/**
 * Return WordPress date format, defaulting to a non-empty one if it is unset.
 *
 * Gets the date format from WooCommerce settings, with fallback to 'F j, Y'.
 * Filterable via 'woocommerce_appointments_date_format'.
 *
 * @since 1.0.0
 *
 * @return string Date format string (e.g., 'F j, Y' for "January 15, 2024").
 */
function wc_appointments_date_format(): string {
	return apply_filters( 'woocommerce_appointments_date_format', wc_date_format() ?: 'F j, Y' );
}

/**
 * Return WordPress time format, defaulting to a non-empty one if it is unset.
 *
 * Gets the time format from WooCommerce settings, with fallback to 'g:i a'.
 * Filterable via 'woocommerce_appointments_time_format'.
 *
 * @since 1.0.0
 *
 * @return string Time format string (e.g., 'g:i a' for "2:30 pm").
 */
function wc_appointments_time_format(): string {
	return apply_filters( 'woocommerce_appointments_time_format', wc_time_format() ?: 'g:i a' );
}

/**
 * Combined date + time format from WooCommerce / site settings.
 *
 * @since 5.4.0
 *
 * @return string PHP date format (e.g. `F j, Y, g:i a`).
 */
function wc_appointments_datetime_format(): string {
	$format = wc_appointments_date_format() . ', ' . wc_appointments_time_format();

	return apply_filters( 'woocommerce_appointments_datetime_format', $format );
}

/**
 * Resolve a display timezone for wp_date().
 *
 * @since 5.4.0
 *
 * @param DateTimeZone|string|null $timezone IANA id or zone object; null = site.
 * @return DateTimeZone
 */
function wc_appointments_format_timezone( $timezone = null ): DateTimeZone {
	if ( $timezone instanceof DateTimeZone ) {
		return $timezone;
	}

	if ( is_string( $timezone ) && '' !== $timezone ) {
		try {
			return new DateTimeZone( wc_appointments_normalize_timezone( $timezone ) );
		} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedCatch
		}
	}

	return wp_timezone();
}

/**
 * Format a real Unix instant (WooCommerce date/time settings via wp_date).
 *
 * @since 5.4.0
 *
 * @param int                      $timestamp Unix timestamp (real instant).
 * @param DateTimeZone|string|null $timezone  Display IANA timezone.
 * @param bool                     $date_only Date without time.
 * @return string
 */
function wc_appointments_format_timestamp( $timestamp, $timezone = null, $date_only = false ): string {
	$timestamp = (int) $timestamp;
	if ( $timestamp <= 0 ) {
		return '';
	}

	$tz     = wc_appointments_format_timezone( $timezone );
	$format = $date_only ? wc_appointments_date_format() : wc_appointments_datetime_format();

	return wp_date( $format, $timestamp, $tz );
}

/**
 * @since 5.4.0
 * @param int $timestamp
 * @param DateTimeZone|string|null $timezone
 */
function wc_appointments_format_date( $timestamp, $timezone = null ): string {
	return wc_appointments_format_timestamp( $timestamp, $timezone, true );
}

/**
 * @since 5.4.0
 * @param int $timestamp
 * @param DateTimeZone|string|null $timezone
 */
function wc_appointments_format_datetime( $timestamp, $timezone = null ): string {
	return wc_appointments_format_timestamp( $timestamp, $timezone, false );
}

/**
 * @since 5.4.0
 * @param WC_Product|WC_Product_Appointment|mixed $product
 */
function wc_appointments_is_timed_slot_product( $product ): bool {
	$appt = $product instanceof WC_Product_Appointment ? $product : WC_Product_Appointment::as_appointment_product( $product );

	return $appt && $appt->has_time() && in_array( $appt->get_duration_unit(), array( 'minute', 'hour' ), true );
}

/**
 * Booking IANA zone for timed series preview/conflicts, or null when conversion does not apply.
 *
 * @since 5.4.0
 * @param WC_Product|WC_Product_Appointment|mixed $product
 * @param string $booking_tz
 * @return DateTimeZone|null
 */
function wc_appointments_series_booking_timezone( $product, $booking_tz = '' ) {
	return wc_appointments_is_timed_slot_product( $product )
		? wc_appointments_format_timezone( $booking_tz ?: wc_timezone_string() )
		: null;
}

/**
 * @since 5.4.0
 * @param int $booking_fake_ts
 * @param string $booking_tz
 * @param bool $date_only
 */
function wc_appointments_format_booking_fake_utc( $booking_fake_ts, $booking_tz = '', $date_only = false ): string {
	$booking_fake_ts = (int) $booking_fake_ts;
	if ( $booking_fake_ts <= 0 ) {
		return '';
	}

	$tz = wc_appointments_format_timezone( $booking_tz ?: wc_timezone_string() );

	return wc_appointments_format_timestamp(
		WC_Appointment_Series_RRule::fake_utc_to_zoned( $booking_fake_ts, $tz )->getTimestamp(),
		$tz,
		$date_only
	);
}

/**
 * Search appointments.
 *
 * Searches for appointments by term, removing "Appointment #" prefix if present.
 * Uses the appointment data store to perform the search.
 *
 * @since 1.0.0
 *
 * @param string $term Search term (appointment ID or other searchable field).
 *
 * @return array<int> Array of appointment IDs matching the search term.
 */
function wc_appointment_search( string $term ): array {
	$data_store = WC_Data_Store::load( 'appointment' );
	return $data_store->search_appointments( str_replace( 'Appointment #', '', wc_clean( $term ) ) );
}

/**
 * (via Action Scheduler) Find available and scheduled slots for specific resources and update cache.
 *
 * Scheduled function that updates appointment slot availability cache for a product.
 * Deletes existing transients and regenerates time slots for the specified date range.
 *
 * @since 4.18.1
 *
 * @param int $product_id      Product ID to update slots for.
 * @param int $min_date        Starting date timestamp for the set of slots.
 * @param int $max_date        Ending date timestamp for the set of slots.
 * @param int $timezone_offset Timezone offset in seconds.
 *
 * @return void
 */
add_action( 'wc-appointment-scheduled-update-availability', 'wc_appointments_get_time_slots_scheduled', 10, 8 );
/**
 * @param int $product_id
 * @param int $min_date
 * @param int $max_date
 * @param int $timezone_offset
 * @return void
 */
function wc_appointments_get_time_slots_scheduled( $product_id, $min_date, $max_date, $timezone_offset ): void {

	// Add meta to mark the event is started.
	$transient_name = 'schedule_ts_' . md5( http_build_query( [ $product_id, 0, $min_date, $max_date, false ] ) );
	update_post_meta( $product_id, 'cache_update_started-' . $transient_name, true );

	// Delete transient, we can't delete it for a specific product,
	// because the same resource may be in use by other products,
	// so we also need to delete their transients, perhaps a work for the future.
	// right now deleting all transients.
	WC_Appointments_Cache::delete_appointment_slots_transient();

	// Flush the Slots Provider L1 cache.
	if ( class_exists( 'WC_Appointment_Slots_Provider' ) ) {
		WC_Appointment_Slots_Provider::flush();
	}

	// Re-call the function to generate the latest time slots (cache warmup).
	// Uses `WC_Appointment_Slots_Provider::get_day_data()` directly.
	$warmup_product = wc_get_product( $product_id );
	if ( is_wc_appointment_product( $warmup_product ) ) {
		try {
			WC_Appointment_Slots_Provider::get_day_data(
				$warmup_product,
				$min_date,
				$max_date,
				(int) $timezone_offset,
				[],
				'Y-n-j',
			);
		} catch ( Exception $e ) {
			// Best-effort warmup only.
		}
	}
}

/**
 * Get the cache horizon in months for availability indexing.
 *
 * Retrieves the number of months ahead to cache appointment availability data.
 * Value is clamped between 1 and 12 months, with a default of 3 months.
 * Filterable for advanced customization.
 *
 * @since 4.15.0
 *
 * @return int Number of months to cache ahead (1-12, default 3).
 */
function wc_appointments_get_cache_horizon_months(): int {
	// Get the setting value, default to 3 months
	$months = get_option( 'wc_appointments_cache_horizon_months', 3 );

	// Ensure it's an integer and within valid range
	$months = absint( $months );
	$months = max( 1, min( 12, $months ) );

	/**
	 * Filter the cache horizon months for advanced customization.
	 *
	 * This allows advanced customers to extend the horizon beyond 12 months if needed.
	 *
	 * @param int $months Number of months to cache ahead
	 * @since 4.15.0
	 */
	return apply_filters( 'wc_appointments_cache_horizon_months', $months );
}

/**
 * Catalog-basis amount (preview quote, calculated cost) → net line total for order items.
 *
 * @param WC_Product $product Appointable product.
 * @param float      $amount  Amount in the same basis as admin panel quotes.
 * @return float
 */
function wc_appointments_admin_line_net_from_amount( $product, float $amount ): float {
	$line_net = max( 0, $amount );
	if ( wc_tax_enabled() && wc_prices_include_tax() ) {
		$tax_rates = WC_Tax::get_base_tax_rates( $product->get_tax_class() );
		$line_net  = max( 0, $line_net - array_sum( WC_Tax::calc_tax( $line_net, $tax_rates, true ) ) );
	}

	return $line_net;
}

/**
 * Normalize payment plan ID for WooCommerce Deposits (matches create_appointment / storefront).
 *
 * @param int $product_id Product ID.
 * @param int $plan_id    Posted plan ID.
 * @return int Valid plan ID or 0.
 */
function wc_appointments_resolve_deposit_plan_id( int $product_id, int $plan_id ): int {
	if ( ! class_exists( 'WC_Deposits_Product_Manager' ) || 'plan' !== WC_Deposits_Product_Manager::get_deposit_type( $product_id ) ) {
		return 0;
	}
	if ( ! class_exists( 'WC_Deposits_Plans_Manager' ) ) {
		return 0;
	}
	$valid_plans = WC_Deposits_Plans_Manager::get_plan_ids_for_product( $product_id );
	if ( $plan_id && is_array( $valid_plans ) && ! in_array( $plan_id, array_map( 'intval', $valid_plans ), true ) ) {
		return 0;
	}
	if ( ! $plan_id && is_array( $valid_plans ) && 1 === count( $valid_plans ) ) {
		return absint( reset( $valid_plans ) );
	}
	return $plan_id;
}

/**
 * Net line totals for quotes and order create (deposit-aware).
 *
 * @param WC_Product_Appointment $product         Appointment product.
 * @param float                  $combined_gross  Appointment cost + addons (catalog gross basis from cost calc).
 * @param int                    $qty             Quantity.
 * @param string                 $dep_option      wc_deposit_option (yes|no).
 * @param int                    $plan_id         Payment plan ID (0 if N/A).
 * @param bool                   $combined_is_net True when $combined_gross is already net (create path after conversion / manual override).
 * @return array{full_line_net:float,line_net:float,deposit_applied:bool,plan_id:int}
 */
function wc_appointments_resolve_deposit_line_net( WC_Product_Appointment $product, float $combined_gross, int $qty, string $dep_option, int $plan_id = 0, bool $combined_is_net = false ): array {
	$product_id      = $product->get_id();
	$qty_line        = max( 1, $qty );
	$full_line_net   = max( 0, (float) $combined_gross );
	$line_net        = $full_line_net;
	$deposit_applied = false;

	if ( ! $combined_is_net && wc_tax_enabled() && wc_prices_include_tax() ) {
		$tax_rates    = WC_Tax::get_base_tax_rates( $product->get_tax_class() );
		$taxes_on_sum = WC_Tax::calc_tax( $full_line_net, $tax_rates, true );
		$full_line_net = max( 0, $full_line_net - array_sum( $taxes_on_sum ) );
		$line_net      = $full_line_net;
	}

	if ( $full_line_net <= 0 || ! class_exists( 'WC_Deposits_Product_Manager' ) || ! WC_Deposits_Product_Manager::deposits_enabled( $product_id ) ) {
		return [
			'full_line_net'   => $full_line_net,
			'line_net'        => $line_net,
			'deposit_applied' => false,
			'plan_id'         => 0,
		];
	}

	$plan_id     = wc_appointments_resolve_deposit_plan_id( $product_id, $plan_id );
	$dep_forced  = WC_Deposits_Product_Manager::deposits_forced( $product_id );
	$pay_deposit = $dep_forced || ( 'yes' === $dep_option );

	if ( ! $pay_deposit ) {
		return [
			'full_line_net'   => $full_line_net,
			'line_net'        => $line_net,
			'deposit_applied' => false,
			'plan_id'         => $plan_id,
		];
	}

	$unit_net       = $full_line_net / $qty_line;
	$deposit_unit   = WC_Deposits_Product_Manager::get_deposit_amount( $product, $plan_id, 'order', $unit_net );
	if ( false === $deposit_unit || ! is_numeric( $deposit_unit ) ) {
		return [
			'full_line_net'   => $full_line_net,
			'line_net'        => $line_net,
			'deposit_applied' => false,
			'plan_id'         => $plan_id,
		];
	}

	$deposit_line = min( $full_line_net, (float) $deposit_unit * $qty_line );
	if ( $deposit_line > 0 && $deposit_line + 0.000001 < $full_line_net ) {
		$deposit_applied = true;
		$line_net        = $deposit_line;
	}

	return [
		'full_line_net'   => $full_line_net,
		'line_net'        => $line_net,
		'deposit_applied' => $deposit_applied,
		'plan_id'         => $plan_id,
	];
}

/**
 * Storefront/panel display amounts from catalog-basis cost and deposit line nets.
 *
 * When catalog prices include tax, scales the gross quote by the deposit net ratio
 * so Due today / deposit quotes stay in catalog basis for wc_get_price_to_display().
 *
 * @param WC_Product_Appointment $product         Appointment product.
 * @param float                  $combined_gross  Appointment cost (+ addons) from cost calc.
 * @param array<string, mixed>   $deposit_totals  Result from wc_appointments_resolve_deposit_line_net().
 * @param int                    $qty             Quantity.
 * @return array{line:float,full:float}
 */
function wc_appointments_deposit_display_amounts( WC_Product_Appointment $product, float $combined_gross, array $deposit_totals, int $qty = 1 ): array {
	if ( ! wc_tax_enabled() || ! wc_prices_include_tax() ) {
		return [
			'line' => (float) $deposit_totals['line_net'],
			'full' => (float) $deposit_totals['full_line_net'],
		];
	}

	$full_gross = max( 0, (float) $combined_gross );
	$line_gross = $full_gross;
	if ( ! empty( $deposit_totals['deposit_applied'] ) && (float) $deposit_totals['full_line_net'] > 0 ) {
		$line_gross = $full_gross * ( (float) $deposit_totals['line_net'] / (float) $deposit_totals['full_line_net'] );
	}

	return [
		'line' => $line_gross,
		'full' => $full_gross,
	];
}

/**
 * Register shared JS handles (wca-shared-js, timezone utils).
 */
function wc_appointments_register_js_assets(): void {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	if ( ! wp_script_is( 'wca-shared-js', 'registered' ) ) {
		wp_register_script( 'wca-shared-js', WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/wca-shared' . $suffix . '.js', array(), WC_APPOINTMENTS_VERSION, true );
	}
	if ( ! wp_script_is( 'wc_appointments_timezone_utils_js', 'registered' ) ) {
		wp_register_script( 'wc_appointments_timezone_utils_js', WC_APPOINTMENTS_PLUGIN_URL . '/assets/js/appointment-timezone-utils' . $suffix . '.js', array(), WC_APPOINTMENTS_VERSION, true );
	}
}
add_action( 'init', 'wc_appointments_register_js_assets', 5 );

/**
 * Whether an availability rule range_type is marked expired (past window).
 *
 * Daily cleanup appends `:expired` to range_type; the indexer never expands those rules.
 * Readiness checks must ignore them or the storefront stays on the dynamic engine forever.
 *
 * @since 5.4.0
 * @param string $range_type Availability range_type column / rule type.
 * @return bool
 */
function wc_appointments_availability_range_type_is_expired( string $range_type ): bool {
	return false !== strpos( $range_type, ':expired' );
}

/**
 * Whether indexed availability should RRULE-expand (range_type `rrule` only, like dynamic path).
 *
 * @param object $availability WC_Appointments_Availability object.
 */
function wc_appointments_availability_should_expand_rrule_index( $availability ): bool {
	if ( ! is_object( $availability ) || ! method_exists( $availability, 'get_range_type' ) ) {
		return false;
	}

	$range_type = (string) $availability->get_range_type();

	return 'rrule' === $range_type
		&& ! wc_appointments_availability_range_type_is_expired( $range_type )
		&& '' !== trim( (string) $availability->get_rrule() );
}
