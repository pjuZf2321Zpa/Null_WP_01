<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Germanized Pro (StoreaBill) invoice integration.
 *
 * Appointment date/time are rendered on emails and My Account via
 * `woocommerce_order_item_meta_start`, not as order item meta. Germanized Pro
 * invoices sync line attributes from the order item, so we inject appointment
 * rows during StoreaBill line-item sync.
 *
 * Last compatibility check: StoreaBill `storeabill_woo_order_item_line_item_sync_props`
 * + `\Vendidero\StoreaBill\Document\Attribute` (Vendidero docs / gist).
 *
 * @since 5.5.0
 */
class WC_Appointments_Integration_Germanized_Pro implements WC_Appointments_Integration_Interface {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->add_hooks();
	}

	/**
	 * Register WordPress hooks for this integration.
	 *
	 * @return void
	 */
	public function add_hooks(): void {
		add_filter( 'storeabill_woo_order_item_line_item_sync_props', [ $this, 'sync_appointment_attributes' ], 20, 3 );
	}

	/**
	 * Inject appointment summary fields into StoreaBill invoice line attributes.
	 *
	 * @param mixed $props Sync props (expects array with optional `attributes`).
	 * @param mixed $item  StoreaBill WooCommerce order item wrapper.
	 * @param mixed $args  Sync args (unused).
	 * @return mixed
	 */
	public function sync_appointment_attributes( $props, $item, $args = null ) {
		unset( $args );

		if ( ! is_array( $props ) || ! class_exists( '\Vendidero\StoreaBill\Document\Attribute' ) ) {
			return $props;
		}

		if ( ! is_object( $item ) || ! is_callable( [ $item, 'get_order_item' ] ) ) {
			return $props;
		}

		$order_item = $item->get_order_item();
		if ( ! $order_item instanceof WC_Order_Item_Product ) {
			return $props;
		}

		$order    = $order_item->get_order();
		$order_id = $order instanceof WC_Order ? $order->get_id() : 0;

		$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $order_item->get_id(), true, $order_id );
		if ( empty( $appointment_ids ) ) {
			return $props;
		}

		if ( ! isset( $props['attributes'] ) || ! is_array( $props['attributes'] ) ) {
			$props['attributes'] = [];
		}

		$count = count( $appointment_ids );
		$index = 0;

		foreach ( $appointment_ids as $appointment_id ) {
			$appointment = get_wc_appointment( $appointment_id );
			if ( ! $appointment instanceof WC_Appointment ) {
				continue;
			}

			++$index;
			$suffix = $count > 1 ? ' ' . $index : '';

			foreach ( $this->get_appointment_attribute_rows( $appointment ) as $row ) {
				$props['attributes'][] = new \Vendidero\StoreaBill\Document\Attribute(
					[
						'key'   => $row['key'] . ( $count > 1 ? '_' . $index : '' ),
						'label' => $row['label'] . $suffix,
						'value' => $row['value'],
					]
				);
			}
		}

		return $props;
	}

	/**
	 * Build plain-text attribute rows for one appointment (mirrors appointment-summary-list).
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return array<int, array{key: string, label: string, value: string}>
	 */
	private function get_appointment_attribute_rows( WC_Appointment $appointment ): array {
		$rows    = [];
		$product = $appointment->get_product();

		$display_tz = $appointment->get_effective_customer_timezone();
		$when       = $appointment->get_start_date_for_email( $display_tz, true );
		if ( $when ) {
			$rows[] = [
				'key'   => 'wca_when',
				'label' => __( 'When', 'woocommerce-appointments' ),
				'value' => wp_strip_all_tags( (string) $when ),
			];
		}

		$duration = $appointment->get_duration();
		if ( $duration ) {
			$rows[] = [
				'key'   => 'wca_duration',
				'label' => __( 'Duration', 'woocommerce-appointments' ),
				'value' => (string) $duration,
			];
		}

		$location = class_exists( 'WC_Appointments_Location' )
			? WC_Appointments_Location::get_context_display( $appointment, false )
			: $appointment->get_location_display();
		if ( $location ) {
			$rows[] = [
				'key'   => 'wca_location',
				'label' => get_wc_appointment_data_label( 'location', $product ),
				'value' => (string) $location,
			];
		}

		if ( class_exists( 'WC_Appointments_Resource' ) ) {
			$resource = WC_Appointments_Resource::get_context_display( $appointment, false );
			if ( $resource ) {
				$rows[] = [
					'key'   => 'wca_resource',
					'label' => get_wc_appointment_data_label( 'resource', $product ),
					'value' => (string) $resource,
				];
			}
		}

		$providers = $appointment->get_staff_members( true );
		if ( $providers ) {
			$rows[] = [
				'key'   => 'wca_staff',
				'label' => get_wc_appointment_data_label( 'staff', $product ),
				'value' => (string) $providers,
			];
		}

		return $rows;
	}
}
