<?php

namespace AutomateWoo\Variables;

use AutomateWoo\Variable;
use WC_Appointment;

defined( 'ABSPATH' ) || exit;

/**
 * Class AppointmentLocation
 *
 * @since 5.5.0
 */
class AppointmentLocation extends Variable {

	/**
	 * Load admin details.
	 */
	public function load_admin_details(): void {
		$this->description = __( 'Displays the location of the appointment (name and address).', 'woocommerce-appointments' );
	}

	/**
	 * Get variable value.
	 *
	 * @param WC_Appointment $appointment
	 * @param array          $parameters
	 *
	 * @return string
	 */
	public function get_value( $appointment, $parameters ) {
		return $appointment->get_location_display();
	}
}
