<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use WCPay\MultiCurrency\MultiCurrency;

/**
 * WooCommerce Payments integration class.
 *
 * Last compatibility check: 9.2.0
 */
class WC_Appointments_Integration_WC_Payments implements WC_Appointments_Integration_Interface {

	public const ADDONS_CONVERTED_META_KEY = '_wcpay_multi_currency_addons_converted';

	/**
	 * Admin appointment create AJAX actions that need WC Payments multicurrency.
	 *
	 * @var string[]
	 */
	private const ADMIN_APPOINTMENT_MC_AJAX = [
		'wc_appointments_calculate_costs',
		'wc_appointments_create_appointment',
		'wc_appointments_get_product_addons',
		'wcpay_appointment_set_currency',
	];

	/**
	 * Multi-currency currencies.
	 *
	 * @var WC_Payments_Multi_Currency class
	 */
	private $multi_currency;

	/** @var bool WCPay MC on with multiple enabled currencies (resolved in add_hooks on init). */
	private $mc_active = false;

	/**
	 * Constructor
	 */
	public function __construct() {
		add_filter( 'wcpay_payment_request_supported_types', [ $this, 'appointments_add_to_supported_types' ] );
		add_filter( 'wcpay_woopay_button_is_product_supported', [ $this, 'woopay_button_is_product_supported' ], 10, 2 );
		add_action( 'init', [ $this, 'add_hooks' ], 10 );
	}

	/**
	 * Register WordPress hooks for this integration.
	 *
	 * @return void
	 */
	public function add_hooks(): void {
		if ( ! function_exists( 'WC_Payments_Multi_Currency' ) ) {
			return;
		}

		$this->multi_currency = WC_Payments_Multi_Currency();
		add_filter( MultiCurrency::FILTER_PREFIX . 'override_selected_currency', [ $this, 'override_selected_currency' ], 999 );

		if ( ! class_exists( 'WC_Payments_Features' ) || WC_Payments_Features::is_customer_multi_currency_enabled() ) {
			$enabled_currencies = $this->multi_currency->get_enabled_currencies();
			$this->mc_active    = is_array( $enabled_currencies ) && count( $enabled_currencies ) > 1;
		}

		if ( ! $this->mc_active ) {
			return;
		}

		if ( ! is_admin() || wp_doing_ajax() ) {
			add_filter( 'appointment_form_calculated_appointment_cost', [ $this, 'adjust_amount_for_calculated_appointment_cost' ], 50, 3 );
			add_filter( 'appointments_calculated_product_price', [ $this, 'adjust_amount_for_calculated_appointment_cost' ], 50, 1 );
			add_filter( MultiCurrency::FILTER_PREFIX . 'should_convert_product_price', [ $this, 'should_convert_product_price' ], 50, 2 );
			add_filter( 'woocommerce_product_get_staff_base_costs', [ $this, 'get_staff_base_costs' ], 50, 2 );

			add_action( 'wp_ajax_wc_appointments_calculate_costs', [ $this, 'add_wc_price_args_filter_for_ajax' ], 9, 0 );
			add_action( 'wp_ajax_nopriv_wc_appointments_calculate_costs', [ $this, 'add_wc_price_args_filter_for_ajax' ], 9, 0 );
		}

		add_filter( 'wc_appointments_admin_panel_config', [ $this, 'filter_admin_panel_config' ] );
		add_action( 'wp_ajax_wcpay_appointment_set_currency', [ $this, 'set_appointment_currency_ajax' ], 10, 0 );
		add_filter( 'wc_price_args', [ $this, 'filter_admin_appointment_wc_price_args' ], 99 );
		add_action( 'woocommerce_new_appointment_order', [ $this, 'set_order_currency_on_new_appointment_order' ], 10, 1 );
		add_filter( 'woocommerce_product_addons_option_price_raw', [ $this, 'convert_addon_price' ], 60, 2 );
		add_filter( 'woocommerce_product_addons_price_raw', [ $this, 'convert_addon_price' ], 60, 2 );
	}

	/**
	 * Override selected currency for admin MC, or store currency when MC is inactive.
	 *
	 * @param mixed $currency_code Currency from prior filters.
	 * @return mixed
	 */
	public function override_selected_currency( $currency_code ) {
		if ( $currency_code ) {
			return $currency_code;
		}

		if ( ! $this->mc_active ) {
			// Option only — get_woocommerce_currency() recurses through WCPay FrontendCurrencies.
			return (string) get_option( 'woocommerce_currency', 'USD' );
		}

		if ( ! $this->is_admin_appointment_create_context() ) {
			return false;
		}

		$cookie_currency = $this->get_cookie_appointment_currency();

		return $cookie_currency !== get_woocommerce_currency() ? $cookie_currency : false;
	}

	/**
	 * Adjusts the calculated appointment cost for the selected currency, applying rounding and charm pricing as necessary.
	 *
	 * @param mixed                        $costs   The original calculated appointment costs.
	 * @param WC_Product_Appointment|null  $product The appointment product.
	 * @param array<string, mixed>         $posted  Posted form data.
	 * @return mixed The appointment cost adjusted for the selected currency.
	 */
	public function adjust_amount_for_calculated_appointment_cost( $costs, $product = null, $posted = [] ) {
		/**
		 * Prevents adjustment of the calculated appointment cost during cart addition.
		 *
		 * When a appointment is added to the cart, the Booking plugin calculates the appointment cost and
		 * overrides the cart item price with this calculated amount. To avoid interfering with this process,
		 * this function skips any additional adjustments at this stage.
		 */
		if ( $this->is_call_in_backtrace( [ 'WC_Cart->add_to_cart' ] ) ) {
			return $costs;
		}

		if ( $this->is_admin_create_without_mc() ) {
			return $costs;
		}

		if ( is_wp_error( $costs ) ) {
			return $costs;
		}

		if ( is_array( $costs ) ) {
			foreach ( $costs as $key => $cost ) {
				$costs[ $key ] = $this->adjust_amount_for_calculated_appointment_cost( $cost, $product, $posted );
			}
			return $costs;
		}

		return $this->multi_currency->adjust_amount_for_selected_currency( $this->normalize_price_amount( $costs ) );
	}

	/**
	 * Normalize a price amount to float.
	 *
	 * @param mixed $amount Amount to normalize.
	 * @return float
	 */
	private function normalize_price_amount( $amount ): float {
		if ( is_int( $amount ) || is_float( $amount ) ) {
			return (float) $amount;
		}

		if ( is_string( $amount ) ) {
			$amount = wp_strip_all_tags( $amount );
		}

		if ( is_numeric( $amount ) ) {
			return (float) $amount;
		}

		if ( function_exists( 'wc_format_decimal' ) ) {
			$normalized = wc_format_decimal( $amount );
			if ( is_numeric( $normalized ) ) {
				return (float) $normalized;
			}
		}

		if ( is_string( $amount ) ) {
			$amount = preg_replace( '/[^0-9,\.\-]/', '', $amount );

			$comma_pos = strrpos( $amount, ',' );
			$dot_pos   = strrpos( $amount, '.' );

			if ( false !== $comma_pos && false !== $dot_pos ) {
				if ( $comma_pos > $dot_pos ) {
					$amount = str_replace( '.', '', $amount );
					$amount = str_replace( ',', '.', $amount );
				} else {
					$amount = str_replace( ',', '', $amount );
				}
			} elseif ( false !== $comma_pos ) {
				$amount = str_replace( ',', '.', $amount );
			}
		}

		if ( function_exists( 'wc_format_decimal' ) ) {
			return (float) wc_format_decimal( $amount );
		}

		return (float) $amount;
	}

	/**
	 * Converts appointable product prices, if needed.
	 *
	 * @param mixed  $price   The price to be filtered.
	 * @param WC_Product $product The product.
	 * @return mixed The price as a string or float.
	 */
	public function get_appointable_product_price( $price, $product ) {
		if ( ! $price || ! $this->should_convert_product_price( true, $product ) ) {
			return $price;
		}

		/**
		 * When showing the price in HTML, the function applies currency conversion, charm pricing,
		 * and rounding. For internal calculations, it uses the raw exchange rate, with charm pricing
		 * and rounding adjustments applied only to the final calculated amount (handled in
		 * adjust_amount_for_calculated_appointment_cost).
		 */
		return $this->multi_currency->get_price(
		    $price,
		    $this->is_call_in_backtrace( [ 'WC_Product_Appointment->get_price_html' ] ) ? 'product' : 'exchange_rate',
		);
	}

	/**
	 * Checks to see if the product's price should be converted.
	 *
	 * @param bool   $return  Whether to convert the product's price or not. Default is true.
	 * @param object $product Product object to test.
	 *
	 * @return bool True if it should be converted.
	 */
	public function should_convert_product_price( bool $return, $product ): bool {
		// If it's already false, ignore it.
		if ( ! $return ) {
			return $return;
		}

		// If it's not WC_Product_Appointment, ignore it.
		if ( ! is_wc_appointment_product( $product ) ) {
			return $return;
		}

		// Prevent currency conversion during cart addition to ensure base currency is stored.
		if ( $this->is_call_in_backtrace( [ 'WC_Cart->add_to_cart' ] ) ) {
			return false;
		}

		if ( $this->is_admin_create_without_mc() ) {
			return false;
		}

		return $return;
	}

	/**
	 * Returns the prices for a resource.
	 *
	 * @param mixed $prices The resource's prices in array format.
	 * @param WC_Product $product Product object to test.
	 *
	 * @return mixed The converted resource's prices.
	 */
	public function get_staff_base_costs( $prices, $product ) {
		if ( $this->is_admin_create_without_mc() ) {
			return $prices;
		}

		if ( is_array( $prices ) ) {
			foreach ( $prices as $key => $price ) {
				$prices[ $key ] = $this->get_appointable_product_price( $price, $product );
			}
		}
		return $prices;
	}

	/**
	 * Add 'appointment' product type to the array.
	 *
	 * @param array<int, string> $product_types Supported product types.
	 * @return array<int, string> Supported product types.
	 */
	public function appointments_add_to_supported_types( $product_types ) {
		$product_types[] = 'appointment';

		return $product_types;
	}

	/**
	 * Whether the product page has a product compatible with the WooPay Express button.
	 *
	 * @param bool $is_supported is express button supproted.
	 * @param object $product Product object.
	 *
	 * @return boolean $is_supported.
	 */
	public function woopay_button_is_product_supported( $is_supported, $product ) {
		// WC Appointments require confirmation products are not supported.
		if (is_wc_appointment_product( $product ) && $product->get_requires_confirmation()) {
            return false;
        }

		return $is_supported;
	}

	/**
     * Adds a filter for when there is an ajax call to calculate the appointment cost.
     */
    public function add_wc_price_args_filter_for_ajax(): void {
		add_filter( 'wc_price_args', [ $this, 'filter_wc_price_args' ], 100 );
		add_filter( 'woocommerce_product_get_price', [ $this, 'get_appointable_product_price' ], 50, 2 );
	}

	/**
	 * Returns the formatting arguments to use when a appointment price is calculated on the product.
	 *
	 * @param array<string, mixed> $args Original args from wc_price().
	 * @return array<string, mixed> New arguments matching the selected currency.
	 */
	public function filter_wc_price_args( array $args ): array {
		if ( $this->is_admin_create_without_mc() ) {
			return $args;
		}

		return wp_parse_args(
		    [
				'currency'           => $this->multi_currency->get_selected_currency()->get_code(),
				'decimal_separator'  => $this->multi_currency->get_frontend_currencies()->get_price_decimal_separator( $args['decimal_separator'] ),
				'thousand_separator' => $this->multi_currency->get_frontend_currencies()->get_price_thousand_separator( $args['thousand_separator'] ),
				'decimals'           => $this->multi_currency->get_frontend_currencies()->get_price_decimals( $args['decimals'] ),
				'price_format'       => $this->multi_currency->get_frontend_currencies()->get_woocommerce_price_format( $args['price_format'] ),
			],
		    $args,
		);
	}

	/**
	 * Checks backtrace calls to see if a certain call has been made.
	 *
	 * @param array<int, string> $calls Array of the calls to check for.
	 * @return bool True if found, false if not.
	 */
	private function is_call_in_backtrace( array $calls ): bool {
		$backtrace = wp_debug_backtrace_summary( null, 0, false ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
		foreach ( $calls as $call ) {
			if ( in_array( $call, $backtrace, true ) ) {
				return true;
			}
		}
		return false;
	}

	// ─── Admin Panel Multicurrency ───────────────────────────────────

	/**
	 * Convert addon prices for admin MC; fix negatives zeroed by WC Payments on the frontend.
	 *
	 * WC Payments get_price( ..., 'product' ) clamps via max( 0, $price ). Use exchange_rate
	 * for negatives so addon templates still receive a non-zero $price_raw to display.
	 *
	 * @param mixed                $price The addon price.
	 * @param array<string, mixed> $type  The addon type data (includes price_type and base price).
	 * @return mixed Converted price or original.
	 */
	public function convert_addon_price( $price, $type ) {
		if ( isset( $type['price_type'] ) && 'percentage_based' === $type['price_type'] ) {
			return $price;
		}

		$base = isset( $type['price'] ) && is_numeric( $type['price'] ) ? (float) $type['price'] : (float) $price;

		if ( $base < 0 && ( 0.0 === (float) $price || $this->should_use_admin_multicurrency() ) ) {
			return $this->multi_currency->get_price( $base, 'exchange_rate' );
		}

		if ( ! $this->should_use_admin_multicurrency() ) {
			return $price;
		}

		return $this->multi_currency->get_price( $price, 'product' );
	}

	/**
	 * Admin create flow using store currency (no admin MC cookie override).
	 *
	 * @return bool
	 */
	private function is_admin_create_without_mc(): bool {
		if ( $this->should_use_admin_multicurrency() ) {
			return false;
		}

		if ( defined( 'WC_APPOINTMENTS_ADMIN_CREATE' ) && WC_APPOINTMENTS_ADMIN_CREATE ) {
			return true;
		}

		if ( ! wp_doing_ajax() ) {
			return false;
		}

		$ajax_action_raw = filter_input( INPUT_POST, 'action' );
		$ajax_action     = is_string( $ajax_action_raw ) ? sanitize_text_field( wp_unslash( $ajax_action_raw ) ) : '';

		return 'wc_appointments_create_appointment' === $ajax_action;
	}

	/**
	 * Check if admin appointment context should use multicurrency conversion.
	 *
	 * Returns true when:
	 * - WC Payments multicurrency is enabled with multiple currencies
	 * - We're in admin appointment create context
	 * - A non-default currency is selected via cookie
	 *
	 * @return bool
	 */
	private function should_use_admin_multicurrency(): bool {
		return $this->mc_active
			&& $this->is_admin_appointment_create_context()
			&& $this->get_cookie_appointment_currency() !== get_woocommerce_currency();
	}

	/**
	 * WC Payments multicurrency selector for the appointments admin panel create flow.
	 *
	 * @param array<string, mixed> $config Panel config for `wcaPanel`.
	 * @return array<string, mixed>
	 */
	public function filter_admin_panel_config( array $config ): array {
		// Skip if WCML multicurrency is already providing integration (WCML takes priority).
		if ( ! empty( $config['integrationCurrency']['enabled'] ) ) {
			return $config;
		}

		if ( ! $this->mc_active
			|| ! class_exists( 'WC_Appointments_Admin_Panel' )
			|| ! WC_Appointments_Admin_Panel::is_enabled() ) {
			return $config;
		}

		$config['integrationCurrency'] = [
			'enabled'         => true,
			'current'         => $this->get_cookie_appointment_currency(),
			'options'         => $this->get_multicurrency_select_options(),
			'ajaxAction'      => 'wcpay_appointment_set_currency',
			'currencyParam'   => 'currency',
			'extraPostFields' => [
				'wcpay_nonce' => wp_create_nonce( 'wcpay_appointment_set_currency' ),
			],
			'label'           => esc_html__( 'Appointment currency', 'woocommerce-appointments' ),
		];

		return $config;
	}

	/**
	 * AJAX handler for setting the appointment currency cookie.
	 */
	public function set_appointment_currency_ajax(): void {
		$nonce = filter_input( INPUT_POST, 'wcpay_nonce', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wcpay_appointment_set_currency' ) ) {
			wp_send_json_error( [ 'message' => esc_html__( 'Invalid nonce', 'woocommerce-appointments' ) ] );
		}

		$currency = filter_input( INPUT_POST, 'currency', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
		$this->set_appointment_currency( $currency );

		wp_send_json_success();
	}

	/**
	 * Set the appointment currency cookie.
	 *
	 * @param string|false $currency_code Currency code or false to use default.
	 */
	public function set_appointment_currency( $currency_code = false ): void {
		$cookie_name = '_wcpay_appointment_currency';

		if ( ! $currency_code && ! isset( $_COOKIE[ $cookie_name ] ) && ! headers_sent() ) {
			$currency_code = get_woocommerce_currency();
		}

		if ( ! $currency_code || headers_sent() ) {
			return;
		}

		do_action( 'wpsc_add_cookie', $cookie_name );
		setcookie( $cookie_name, $currency_code, [ 'expires' => time() + 86400, 'path' => COOKIEPATH, 'domain' => COOKIE_DOMAIN ] );
		$_COOKIE[ $cookie_name ] = $currency_code;
	}

	/**
	 * Get the current appointment currency from cookie.
	 *
	 * @return string
	 */
	public function get_cookie_appointment_currency(): string {
		$cookie_raw = filter_input( INPUT_COOKIE, '_wcpay_appointment_currency' );
		if ( is_string( $cookie_raw ) && '' !== $cookie_raw ) {
			return sanitize_text_field( wp_unslash( $cookie_raw ) );
		}

		return get_woocommerce_currency();
	}

	/**
	 * Filter wc_price() args for admin appointment create context.
	 *
	 * @param array<string, mixed> $args wc_price() args.
	 * @return array<string, mixed>
	 */
	public function filter_admin_appointment_wc_price_args( array $args ): array {
		if ( $this->mc_active && $this->is_admin_appointment_create_context() ) {
			$args['currency'] = $this->get_cookie_appointment_currency();
		}

		return $args;
	}

	/**
	 * Admin panel create: persist order currency from the appointment-currency cookie.
	 *
	 * @param int $order_id Order ID.
	 */
	public function set_order_currency_on_new_appointment_order( $order_id ): void {
		if ( ! $order_id || ! $this->mc_active ) {
			return;
		}

		if ( ! $this->is_admin_appointment_create_context() ) {
			return;
		}

		$currency = $this->get_cookie_appointment_currency();
		update_post_meta( $order_id, '_order_currency', $currency );
	}

	/**
	 * Check if we're in an admin appointment create context.
	 *
	 * @return bool
	 */
	private function is_admin_appointment_create_context(): bool {
		global $pagenow;

		$posted = [];

		$form_raw = filter_input( INPUT_POST, 'form' );
		if ( wp_doing_ajax() && is_string( $form_raw ) && '' !== $form_raw ) {
			parse_str( wp_unslash( $form_raw ), $posted );
		}

		if ( 'edit.php' === $pagenow && 'add_appointment' === $this->wcpay_request_text( 'page' ) ) {
			return true;
		}

		if ( isset( $posted['_wp_http_referer'] ) && false !== strpos( $posted['_wp_http_referer'], 'page=add_appointment' ) ) {
			return true;
		}

		if ( wp_doing_ajax() ) {
			$action_raw = filter_input( INPUT_POST, 'action' );
			$action     = is_string( $action_raw ) ? sanitize_text_field( wp_unslash( $action_raw ) ) : '';

			if ( in_array( $action, self::ADMIN_APPOINTMENT_MC_AJAX, true ) && $this->is_wp_admin_ajax_referer() ) {
				return true;
			}
		}

		return (bool) apply_filters( 'wc_appointments_is_admin_appointment_create_context', false );
	}

	/**
	 * Check if the AJAX request comes from wp-admin.
	 *
	 * @return bool
	 */
	private function is_wp_admin_ajax_referer(): bool {
		$referer = esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ?? '' ) );

		return $referer && ( false !== strpos( $referer, '/wp-admin/' ) || false !== strpos( $referer, (string) admin_url() ) );
	}

	/**
	 * Sanitized GET string for WC Payments admin context reads.
	 *
	 * @param string $key GET parameter name.
	 * @return string
	 */
	private function wcpay_request_text( string $key ): string {
		$value = filter_input( INPUT_GET, $key );
		if ( null === $value || false === $value ) {
			return '';
		}

		return sanitize_text_field( wp_unslash( $value ) );
	}

	/**
	 * Currency options for admin appointment multicurrency selectors.
	 *
	 * @return array<int, array{code: string, label: string}>
	 */
	private function get_multicurrency_select_options(): array {
		$wc_currencies     = get_woocommerce_currencies();
		$enabled_currencies = $this->multi_currency->get_enabled_currencies();
		$options           = [];

		foreach ( $enabled_currencies as $currency ) {
			$code      = $currency->get_code();
			$options[] = [
				'code'  => $code,
				'label' => $wc_currencies[ $code ] ?? $code,
			];
		}

		return $options;
	}
}
