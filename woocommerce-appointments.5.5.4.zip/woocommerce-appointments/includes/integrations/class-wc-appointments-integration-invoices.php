<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce Print Invoices/Packing Lists integration class.
 */
class WC_Appointments_Integration_Invoices implements WC_Appointments_Integration_Interface {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->add_hooks();
	}

	/**
	 * Register WordPress hooks for this integration.
	 *
	 * @return void
	 */
	public function add_hooks(): void {
		add_action( 'wc_pip_order_item_meta_end', [ $this, 'appointment_invoice_display' ], 10, 3 ); #WooCommerce Print Invoices/Packing Lists.
	}

	/**
	 * Show appointment data for various Invoice plugin integrations.
	 *
	 * @param int      $item_id Order item ID.
	 * @param mixed    $item    Order item (external).
	 * @param WC_Order $order   Order object.
	 */
	public function appointment_invoice_display( $item_id, $item, $order ): void {
		$appointment_ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $item_id, true, $order->get_id() );

		if ( $appointment_ids ) {
			foreach ( $appointment_ids as $appointment_id ) {
				$appointment = get_wc_appointment( $appointment_id );
				wc_appointments_get_summary_list( $appointment );
			}
		}
	}
}
