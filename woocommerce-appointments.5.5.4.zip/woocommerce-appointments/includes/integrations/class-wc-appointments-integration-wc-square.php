<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce Payments integration class.
 *
 * Last compatibility check: 2.7.0
 */
class WC_Appointments_Integration_WC_Square implements WC_Appointments_Integration_Interface {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->add_hooks();
	}

	/**
	 * Register WordPress hooks for this integration.
	 *
	 * @return void
	 */
	public function add_hooks(): void {
		add_filter( 'wc_square_digital_wallets_supported_product_types', [ $this, 'appointments_add_to_supported_types' ] );
	}

	/**
	 * Add 'appointment' product type to the array.
	 *
	 * @param array<int, string> $product_types Supported product types.
	 * @return array<int, string> Supported product types.
	 */
	public function appointments_add_to_supported_types( $product_types ) {
		$product_types[] = 'appointment';

		return $product_types;
	}
}
