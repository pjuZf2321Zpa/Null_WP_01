<?php
/**
 * WooCommerce Subscriptions integration — appointment membership credits.
 *
 * @package WooCommerce\Appointments\Integrations\WooCommerceSubscriptions
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Loads WCS membership credit wallet when WooCommerce Subscriptions is active.
 */
class WC_Appointments_Integration_Subscriptions {

	/**
	 * @return void
	 */
	public static function init() {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return;
		}

		include_once __DIR__ . '/class-wc-appointments-integration-subscription-entitlement.php';
		include_once __DIR__ . '/class-wc-appointments-integration-subscriptions-cart.php';

		WC_Appointments_Integration_Subscriptions_Cart::init();

		add_action( 'woocommerce_checkout_subscription_created', array( __CLASS__, 'on_subscription_created' ), 20, 3 );
		add_action( 'woocommerce_subscription_status_active', array( __CLASS__, 'on_subscription_active' ), 20, 1 );
		add_action( 'woocommerce_subscription_renewal_payment_complete', array( __CLASS__, 'on_renewal_payment_complete' ), 20, 2 );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'render_thankyou_booking_cta' ), 15 );
		add_action( 'woocommerce_account_appointments_endpoint', array( __CLASS__, 'maybe_render_on_hold_banner' ), 5 );
		add_filter( 'woocommerce_appointments_my_appointments_template_args', array( __CLASS__, 'add_memberships_to_appointments_args' ), 10, 1 );
		add_action( 'wcs_subscription_details_table_after_dates', array( __CLASS__, 'render_subscription_credit_rows' ), 10, 1 );
		add_action( 'woocommerce_subscription_details_after_subscription_table', array( __CLASS__, 'render_subscription_booked_appointments' ), 10, 1 );
		add_action( 'woocommerce_my_subscriptions_after_subscription_id', array( __CLASS__, 'render_subscription_list_credits' ), 10, 1 );
	}

	/**
	 * @param int $user_id User id.
	 * @return array<int, mixed>
	 */
	public static function get_user_membership_subscriptions( $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 || ! function_exists( 'wcs_get_users_subscriptions' ) ) {
			return array();
		}

		$memberships = array();
		foreach ( wcs_get_users_subscriptions( $user_id ) as $subscription ) {
			if ( WC_Appointments_Integration_Subscription_Entitlement::is_membership_subscription( $subscription ) ) {
				$memberships[] = $subscription;
			}
		}

		return $memberships;
	}

	/**
	 * @param mixed $subscription   Subscription from WCS.
	 * @param mixed $order          Parent order (unused).
	 * @param mixed $recurring_cart Recurring cart (unused).
	 * @return void
	 */
	public static function on_subscription_created( $subscription, $order, $recurring_cart ) {
		unset( $order, $recurring_cart );
		if ( $subscription ) {
			WC_Appointments_Integration_Subscription_Entitlement::bootstrap_subscription( $subscription );
		}
	}

	/**
	 * @param mixed $subscription Subscription from WCS.
	 * @return void
	 */
	public static function on_subscription_active( $subscription ) {
		if ( $subscription ) {
			WC_Appointments_Integration_Subscription_Entitlement::bootstrap_subscription( $subscription );
		}
	}

	/**
	 * @param mixed          $subscription Subscription from WCS.
	 * @param WC_Order|mixed $last_order   Renewal order when provided.
	 * @return void
	 */
	public static function on_renewal_payment_complete( $subscription, $last_order = null ) {
		if ( $subscription ) {
			self::grant_renewal_credits( $subscription, $last_order instanceof WC_Order ? $last_order : null );
		}
	}

	/**
	 * @param mixed          $subscription  Subscription from WCS.
	 * @param WC_Order|null  $renewal_order Renewal order when known.
	 * @return void
	 */
	protected static function grant_renewal_credits( $subscription, $renewal_order ) {
		$plan = WC_Appointments_Integration_Subscription_Entitlement::get_plan_product( $subscription );
		if ( ! $plan || ! WC_Appointments_Integration_Subscription_Plan::is_membership_product( $plan ) ) {
			return;
		}

		$key  = self::renewal_idempotency_key( $subscription, $renewal_order );
		$done = $subscription->get_meta( '_wca_last_credit_grant_key', true );
		if ( $done === $key ) {
			return;
		}

		WC_Appointments_Integration_Subscription_Entitlement::grant_period_credits( $subscription, true );
		$subscription->update_meta_data( '_wca_last_credit_grant_key', $key );
		$subscription->save();
	}

	/**
	 * @param mixed         $subscription  Subscription from WCS.
	 * @param WC_Order|null $renewal_order Renewal order when known.
	 * @return string
	 */
	protected static function renewal_idempotency_key( $subscription, $renewal_order ) {
		if ( $renewal_order ) {
			return sprintf( 'wcs-renewal-credits-%d-%d', (int) $subscription->get_id(), (int) $renewal_order->get_id() );
		}

		$period_end = $subscription->get_date( 'next_payment' );
		if ( ! $period_end ) {
			$period_end = $subscription->get_date( 'end' );
		}

		return sprintf( 'wcs-scheduled-credits-%d-%s', (int) $subscription->get_id(), (string) $period_end );
	}

	/**
	 * @param mixed $subscription Subscription from WCS.
	 * @return bool
	 */
	public static function subscription_allows_booking( $subscription ) {
		if ( ! $subscription || ! is_a( $subscription, 'WC_Subscription' ) ) {
			return false;
		}

		return $subscription->has_status( array( 'active' ) );
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public static function render_thankyou_booking_cta( $order_id ) {
		$order_id = (int) $order_id;
		if ( $order_id <= 0 || ! function_exists( 'wcs_get_subscriptions_for_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || ! $order->has_status( array( 'processing', 'completed', 'on-hold', 'pending' ) ) ) {
			return;
		}

		$book_url = '';
		foreach ( wcs_get_subscriptions_for_order( $order_id, array( 'order_type' => 'parent' ) ) as $subscription ) {
			if ( ! WC_Appointments_Integration_Subscription_Entitlement::is_membership_subscription( $subscription ) ) {
				continue;
			}
			if ( ! WC_Appointments_Integration_Subscription_Entitlement::has_credit_available( $subscription ) ) {
				continue;
			}

			$url = WC_Appointments_Integration_Subscription_Entitlement::get_first_booking_url( $subscription );
			if ( $url ) {
				$book_url = $url;
				break;
			}
		}

		if ( ! $book_url ) {
			return;
		}
		?>
		<div class="woocommerce-message wca-membership-thankyou-cta">
			<a class="button" href="<?php echo esc_url( $book_url ); ?>"><?php esc_html_e( 'Book appointment', 'woocommerce-appointments' ); ?></a>
			<?php esc_html_e( 'Your membership is active. Book your first appointment.', 'woocommerce-appointments' ); ?>
		</div>
		<?php
	}

	/**
	 * @return void
	 */
	public static function maybe_render_on_hold_banner() {
		if ( ! is_user_logged_in() ) {
			return;
		}

		foreach ( self::get_user_membership_subscriptions( get_current_user_id() ) as $subscription ) {
			if ( ! $subscription->has_status( 'on-hold' ) ) {
				continue;
			}

			wc_print_notice(
				__( 'Membership payment is on hold. Credits are unavailable until payment is resolved.', 'woocommerce-appointments' ),
				'notice'
			);
			return;
		}
	}

	/**
	 * @param array<string, mixed> $args My Account appointments template args.
	 * @return array<string, mixed>
	 */
	public static function add_memberships_to_appointments_args( $args ) {
		if ( ! is_user_logged_in() ) {
			return $args;
		}

		$summaries = self::build_membership_summaries( get_current_user_id() );
		if ( empty( $summaries ) ) {
			return $args;
		}

		$args['membership_summaries'] = $summaries;

		foreach ( self::get_user_membership_subscriptions( get_current_user_id() ) as $subscription ) {
			if ( ! WC_Appointments_Integration_Subscription_Entitlement::has_credit_available( $subscription ) ) {
				continue;
			}
			$url = WC_Appointments_Integration_Subscription_Entitlement::get_first_booking_url( $subscription );
			if ( $url ) {
				$args['membership_book_url'] = $url;
				break;
			}
		}

		if ( function_exists( 'wcs_get_users_subscriptions' ) ) {
			$args['memberships_view_url'] = wc_get_endpoint_url( 'subscriptions', '', wc_get_page_permalink( 'myaccount' ) );
		}

		return $args;
	}

	/**
	 * @param int $user_id User id.
	 * @return array<int, array<string, string>>
	 */
	protected static function build_membership_summaries( $user_id ) {
		$summaries = array();
		foreach ( self::get_user_membership_subscriptions( $user_id ) as $subscription ) {
			if ( ! $subscription->has_status( array( 'active', 'on-hold' ) ) ) {
				continue;
			}

			$renewal_label = '';
			if ( $subscription->has_status( 'active' ) && $subscription->get_time( 'next_payment' ) > 0 ) {
				$renewal_label = sprintf(
					/* translators: %s: next payment date */
					__( 'Renews %s', 'woocommerce-appointments' ),
					$subscription->get_date_to_display( 'next_payment' )
				);
			}

			$status_note = '';
			if ( $subscription->has_status( 'on-hold' ) ) {
				$status_note = __( 'Unavailable while payment is on hold.', 'woocommerce-appointments' );
			}

			$summaries[] = array(
				'plan_name'     => WC_Appointments_Integration_Subscription_Entitlement::get_plan_name( $subscription ),
				'balance_label' => WC_Appointments_Integration_Subscription_Entitlement::balance_label( $subscription ),
				'renewal_label' => $renewal_label,
				'status_note'   => $status_note,
			);
		}

		return $summaries;
	}

	/**
	 * @param mixed $subscription Subscription from WCS.
	 * @return void
	 */
	public static function render_subscription_credit_rows( $subscription ) {
		if ( ! $subscription || (int) $subscription->get_user_id() !== get_current_user_id() || ! WC_Appointments_Integration_Subscription_Entitlement::is_membership_subscription( $subscription ) ) {
			return;
		}

		$balance = esc_html( WC_Appointments_Integration_Subscription_Entitlement::balance_label( $subscription ) );
		if ( $subscription->has_status( 'on-hold' ) ) {
			$balance .= '<br><small>' . esc_html__( 'Unavailable while on hold.', 'woocommerce-appointments' ) . '</small>';
		} elseif ( ! self::subscription_allows_booking( $subscription ) ) {
			$balance .= '<br><small>' . esc_html__( 'Unavailable while inactive.', 'woocommerce-appointments' ) . '</small>';
		}
		?>
		<tr>
			<td><?php esc_html_e( 'Credits', 'woocommerce-appointments' ); ?></td>
			<td><?php echo wp_kses_post( $balance ); ?></td>
		</tr>
		<?php
		if ( $subscription->has_status( 'active' ) && $subscription->get_time( 'next_payment' ) > 0 ) {
			?>
			<tr>
				<td><?php esc_html_e( 'Next renewal', 'woocommerce-appointments' ); ?></td>
				<td><?php echo esc_html( $subscription->get_date_to_display( 'next_payment' ) ); ?></td>
			</tr>
			<?php
		}
	}

	/**
	 * @param mixed $subscription Subscription from WCS.
	 * @return void
	 */
	public static function render_subscription_list_credits( $subscription ) {
		if ( $subscription && (int) $subscription->get_user_id() === get_current_user_id() && WC_Appointments_Integration_Subscription_Entitlement::is_membership_subscription( $subscription ) ) {
			echo '<br><small>' . esc_html( WC_Appointments_Integration_Subscription_Entitlement::balance_label( $subscription ) ) . '</small>';
		}
	}

	/**
	 * @param mixed $subscription Subscription from WCS.
	 * @return void
	 */
	public static function render_subscription_booked_appointments( $subscription ) {
		if ( ! $subscription || (int) $subscription->get_user_id() !== get_current_user_id() || ! WC_Appointments_Integration_Subscription_Entitlement::is_membership_subscription( $subscription ) ) {
			return;
		}

		$sub_id      = (int) $subscription->get_id();
		$by_id       = array();
		$order_query = array(
			'customer' => (int) $subscription->get_user_id(),
			'limit'    => -1,
			'status'   => wc_get_is_paid_statuses(),
			'return'   => 'objects',
		);

		foreach ( wc_get_orders( $order_query ) as $order ) {
			foreach ( $order->get_items() as $item_id => $item ) {
				if ( (int) $item->get_meta( '_wca_membership_subscription_id', true ) !== $sub_id ) {
					continue;
				}
				foreach ( WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $item_id, true, $order->get_id() ) as $appt_id ) {
					if ( ! isset( $by_id[ $appt_id ] ) && ( $appt = get_wc_appointment( $appt_id ) ) ) {
						$by_id[ $appt_id ] = $appt;
					}
				}
			}
		}

		if ( empty( $by_id ) ) {
			printf(
				'<section class="woocommerce-order-details wca-membership-redemptions"><h2>%s</h2><p>%s</p></section>',
				esc_html__( 'Credited appointments', 'woocommerce-appointments' ),
				esc_html__( 'No credited appointments yet.', 'woocommerce-appointments' )
			);
			return;
		}

		$appointments = array_values( $by_id );
		usort(
			$appointments,
			static function ( $a, $b ) {
				return $b->get_start() <=> $a->get_start();
			}
		);

		$per_page = (int) apply_filters( 'woocommerce_appointments_my_appointments_per_page', 10 );
		$page_raw = filter_input( INPUT_GET, 'wca_redemptions_page', FILTER_VALIDATE_INT );
		$page     = ( false !== $page_raw && null !== $page_raw ) ? max( 1, (int) $page_raw ) : 1;
		$slice    = array_slice( $appointments, ( $page - 1 ) * $per_page, $per_page + 1 );
		$has_more = count( $slice ) > $per_page;
		if ( $has_more ) {
			$slice = array_slice( $slice, 0, $per_page );
		}

		$base_url = $subscription->get_view_order_url();
		wc_get_template(
			'myaccount/appointments.php',
			array(
				'table_only'                => true,
				'wrap_section'              => true,
				'tables'                    => array(
					'membership' => array(
						'header'       => __( 'Credited appointments', 'woocommerce-appointments' ),
						'appointments' => $slice,
					),
				),
				'page'                      => $page,
				'endpoint'                  => '',
				'appointments_per_page'     => $per_page,
				'pagination_prev_url'       => $page > 1 ? add_query_arg( 'wca_redemptions_page', $page - 1, $base_url ) : '',
				'pagination_next_url'       => $has_more ? add_query_arg( 'wca_redemptions_page', $page + 1, $base_url ) : '',
				'timezone_indicator_html'   => class_exists( 'WC_Appointments_Timezone_Helper' ) ? WC_Appointments_Timezone_Helper::get_my_account_indicator_html() : '',
			),
			'woocommerce-appointments',
			WC_APPOINTMENTS_TEMPLATE_PATH
		);
	}
}
