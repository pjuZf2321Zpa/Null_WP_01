<?php
/**
 * Appointment credit wallet on WCS subscriptions.
 *
 * @package WooCommerce\Appointments\Integrations\WooCommerceSubscriptions
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Product meta for subscription plans that grant appointment credits.
 */
class WC_Appointments_Integration_Subscription_Plan {

	const META_MEMBERSHIP            = '_wca_appointment_membership';
	const META_APPOINTMENTS_PER_PERIOD = '_wca_appointments_per_period';
	const META_UNLIMITED             = '_wca_unlimited_appointments';
	const META_ROLLOVER              = '_wca_credit_rollover';
	const META_ELIGIBLE_PRODUCTS     = '_wca_eligible_appointment_products';

	/**
	 * @param mixed $product Product object or id.
	 * @return bool
	 */
	public static function is_wcs_subscription_product( $product ) {
		if ( ! class_exists( 'WC_Subscriptions_Product' ) ) {
			return false;
		}

		$product = self::resolve_product( $product );
		return $product && (bool) WC_Subscriptions_Product::is_subscription( $product );
	}

	/**
	 * @param mixed $product Product object or id.
	 * @return bool
	 */
	public static function is_membership_product( $product ) {
		$product = self::resolve_product( $product );
		return $product && self::is_wcs_subscription_product( $product ) && 'yes' === $product->get_meta( self::META_MEMBERSHIP );
	}

	/**
	 * @return array<int|string, string>
	 */
	public static function get_appointments_per_period_options() {
		$options = array( 'unlimited' => __( 'Unlimited', 'woocommerce-appointments' ) );
		foreach ( array( 1, 2, 4, 8, 12, 24, 30 ) as $count ) {
			$options[ (string) $count ] = (string) $count;
		}
		$options['custom'] = __( 'Custom', 'woocommerce-appointments' );
		return $options;
	}

	/**
	 * @param mixed $product Product object or id.
	 * @return int
	 */
	public static function appointments_per_period( $product ) {
		$product = self::resolve_product( $product );
		if ( ! $product ) {
			return 1;
		}
		$count = (int) $product->get_meta( self::META_APPOINTMENTS_PER_PERIOD );
		return max( 1, min( 365, $count > 0 ? $count : 1 ) );
	}

	/**
	 * @param mixed $product Product object or id.
	 * @return bool
	 */
	public static function is_unlimited( $product ) {
		$product = self::resolve_product( $product );
		return $product && 'yes' === $product->get_meta( self::META_UNLIMITED );
	}

	/**
	 * @param mixed $product Product object or id.
	 * @return bool
	 */
	public static function rollover_enabled( $product ) {
		$product = self::resolve_product( $product );
		return $product && 'yes' === $product->get_meta( self::META_ROLLOVER );
	}

	/**
	 * @param mixed $product Product object or id.
	 * @return array<int, int>
	 */
	public static function eligible_appointment_product_ids( $product ) {
		$product = self::resolve_product( $product );
		if ( ! $product ) {
			return array();
		}

		$raw = $product->get_meta( self::META_ELIGIBLE_PRODUCTS );
		if ( is_array( $raw ) ) {
			$ids = $raw;
		} elseif ( is_string( $raw ) && '' !== $raw ) {
			$ids = array_map( 'trim', explode( ',', $raw ) );
		} else {
			return array();
		}

		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	/**
	 * @param mixed $plan_product           Plan product object or id.
	 * @param int   $appointment_product_id Appointable product id.
	 * @return bool
	 */
	public static function covers_appointment_product( $plan_product, $appointment_product_id ) {
		$appointment_product_id = (int) $appointment_product_id;
		if ( $appointment_product_id <= 0 || ! self::is_membership_product( $plan_product ) ) {
			return false;
		}

		$eligible = self::eligible_appointment_product_ids( $plan_product );
		if ( empty( $eligible ) ) {
			$product = wc_get_product( $appointment_product_id );
			return $product && is_wc_appointment_product( $product );
		}

		return in_array( $appointment_product_id, $eligible, true );
	}

	/**
	 * @param mixed $plan_product Plan product object or id.
	 * @return string
	 */
	public static function credit_summary_label( $plan_product ) {
		if ( self::is_unlimited( $plan_product ) ) {
			return __( 'Unlimited per billing period', 'woocommerce-appointments' );
		}

		$count = self::appointments_per_period( $plan_product );
		return sprintf(
			/* translators: %d: number of appointments per billing period */
			_n( '%d appointment per billing period', '%d appointments per billing period', $count, 'woocommerce-appointments' ),
			$count
		);
	}

	/**
	 * @param mixed $product Product object or id.
	 * @return WC_Product|null
	 */
	protected static function resolve_product( $product ) {
		if ( is_numeric( $product ) ) {
			$product = wc_get_product( (int) $product );
		}
		return ( $product instanceof WC_Product ) ? $product : null;
	}
}

/**
 * Grant, consume, and display membership appointment credits.
 */
class WC_Appointments_Integration_Subscription_Entitlement {

	const META_BALANCE                  = '_wca_credit_balance';
	const META_PLAN_PRODUCT_ID          = '_wca_plan_product_id';
	const META_FIRST_BOOKING_PRODUCT_ID = '_wca_first_booking_product_id';
	const UNLIMITED_BALANCE             = -1;

	/**
	 * Request cache for {@see get_booking_context()}.
	 *
	 * @var array<string, array<string, mixed>|null>
	 */
	private static $booking_context_cache = array();

	/**
	 * Link subscription to its plan product and grant initial credits.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @return void
	 */
	public static function bootstrap_subscription( $subscription ) {
		if ( ! $subscription || ! is_a( $subscription, 'WC_Subscription' ) ) {
			return;
		}

		$plan_product_id = self::resolve_plan_product_id_from_subscription( $subscription );
		if ( $plan_product_id <= 0 ) {
			return;
		}

		$plan = wc_get_product( $plan_product_id );
		if ( ! $plan || ! WC_Appointments_Integration_Subscription_Plan::is_membership_product( $plan ) ) {
			return;
		}

		if ( (int) $subscription->get_meta( self::META_PLAN_PRODUCT_ID, true ) <= 0 ) {
			$subscription->update_meta_data( self::META_PLAN_PRODUCT_ID, $plan_product_id );
		}

		if ( '' === $subscription->get_meta( self::META_BALANCE, true ) ) {
			self::grant_period_credits( $subscription, false );
		}

		self::maybe_store_first_booking_product_id( $subscription, $plan );

		$subscription->save();
	}

	/**
	 * Refill credits for a billing period (initial or renewal).
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @param bool            $is_renewal   Whether this is a renewal (rollover applies).
	 * @return void
	 */
	public static function grant_period_credits( $subscription, $is_renewal = true ) {
		if ( ! $subscription || ! is_a( $subscription, 'WC_Subscription' ) ) {
			return;
		}

		$plan = self::get_plan_product( $subscription );
		if ( ! $plan || ! WC_Appointments_Integration_Subscription_Plan::is_membership_product( $plan ) ) {
			return;
		}

		if ( WC_Appointments_Integration_Subscription_Plan::is_unlimited( $plan ) ) {
			$subscription->update_meta_data( self::META_BALANCE, self::UNLIMITED_BALANCE );
			self::maybe_store_first_booking_product_id( $subscription, $plan );
			$subscription->save();
			return;
		}

		$grant   = WC_Appointments_Integration_Subscription_Plan::appointments_per_period( $plan );
		$current = (int) $subscription->get_meta( self::META_BALANCE, true );

		if ( $is_renewal && WC_Appointments_Integration_Subscription_Plan::rollover_enabled( $plan ) && $current > 0 ) {
			$grant += $current;
		}

		$subscription->update_meta_data( self::META_BALANCE, max( 0, $grant ) );
		self::maybe_store_first_booking_product_id( $subscription, $plan );
		$subscription->save();
	}

	/**
	 * Shift stored balances when the plan product grant changes (product-save origin).
	 *
	 * @param WC_Product $product   Plan product.
	 * @param int        $old_grant Previous period grant.
	 * @param int        $new_grant New period grant.
	 * @return void
	 */
	public static function sync_balances_for_plan_grant_change( $product, $old_grant, $new_grant ) {
		if ( ! $product instanceof WC_Product || ! WC_Appointments_Integration_Subscription_Plan::is_membership_product( $product ) || ! function_exists( 'wcs_get_subscription' ) ) {
			return;
		}
		$old_grant = max( 0, (int) $old_grant );
		$new_grant = max( 0, (int) $new_grant );
		$unlimited = WC_Appointments_Integration_Subscription_Plan::is_unlimited( $product );
		$plan_id   = (int) $product->get_id();
		if ( $plan_id <= 0 || ( ! $unlimited && $old_grant === $new_grant ) ) {
			return;
		}
		foreach ( wc_get_orders( array( 'type' => 'shop_subscription', 'status' => array( 'wc-active', 'wc-on-hold' ), 'limit' => -1, 'return' => 'ids', 'meta_query' => array( array( 'key' => self::META_PLAN_PRODUCT_ID, 'value' => (string) $plan_id ) ) ) ) as $sid ) {
			$sub = wcs_get_subscription( $sid );
			if ( ! $sub || '' === $sub->get_meta( self::META_BALANCE, true ) ) {
				continue;
			}
			$bal = (int) $sub->get_meta( self::META_BALANCE, true );
			if ( $unlimited ) {
				$bal = self::UNLIMITED_BALANCE;
			} elseif ( self::UNLIMITED_BALANCE === $bal ) {
				$bal = $new_grant;
			} elseif ( $old_grant > 0 && $bal <= $old_grant ) {
				$bal = max( 0, $new_grant - ( $old_grant - $bal ) );
			} else {
				$bal = $new_grant > $old_grant ? $bal + ( $new_grant - $old_grant ) : min( $bal, $new_grant );
			}
			$sub->update_meta_data( self::META_BALANCE, max( 0, $bal ) );
			$sub->save();
		}
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @return WC_Product|null
	 */
	public static function get_plan_product( $subscription ) {
		$plan_id = (int) $subscription->get_meta( self::META_PLAN_PRODUCT_ID, true );
		if ( $plan_id <= 0 ) {
			$plan_id = self::resolve_plan_product_id_from_subscription( $subscription );
		}

		if ( $plan_id <= 0 ) {
			return null;
		}

		$plan = wc_get_product( $plan_id );
		return ( $plan instanceof WC_Product ) ? $plan : null;
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @return int
	 */
	protected static function resolve_plan_product_id_from_subscription( $subscription ) {
		foreach ( $subscription->get_items() as $item ) {
			$product_id = (int) $item->get_product_id();
			if ( $product_id > 0 && WC_Appointments_Integration_Subscription_Plan::is_membership_product( $product_id ) ) {
				return $product_id;
			}
		}

		return 0;
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @return int|null Null when unlimited; otherwise remaining count.
	 */
	public static function get_balance( $subscription ) {
		if ( ! $subscription ) {
			return 0;
		}

		$balance = $subscription->get_meta( self::META_BALANCE, true );
		if ( '' === $balance ) {
			return 0;
		}

		$balance = (int) $balance;
		if ( self::UNLIMITED_BALANCE === $balance ) {
			return null;
		}

		return max( 0, $balance );
	}

	/**
	 * @param WC_Subscription $subscription Subscription.
	 * @return bool
	 */
	public static function has_credit_available( $subscription ) {
		if ( ! $subscription || ! $subscription->has_status( array( 'active' ) ) ) {
			return false;
		}

		if ( ! WC_Appointments_Integration_Subscriptions::subscription_allows_booking( $subscription ) ) {
			return false;
		}

		return self::has_credits_for_count( $subscription, 1 );
	}

	/**
	 * Whether a subscription grants appointment membership credits.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @return bool
	 */
	public static function is_membership_subscription( $subscription ) {
		if ( ! $subscription || ! is_a( $subscription, 'WC_Subscription' ) ) {
			return false;
		}

		$plan = self::get_plan_product( $subscription );
		return $plan && WC_Appointments_Integration_Subscription_Plan::is_membership_product( $plan );
	}

	/**
	 * Active memberships for a user that can book a given appointable product.
	 *
	 * @param int $user_id                User id.
	 * @param int $appointment_product_id Appointable product id.
	 * @return WC_Subscription[]
	 */
	public static function get_bookable_subscriptions_for_user( $user_id, $appointment_product_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 || ! function_exists( 'wcs_get_users_subscriptions' ) ) {
			return array();
		}

		$matches = array();
		foreach ( wcs_get_users_subscriptions( $user_id ) as $subscription ) {
			if ( ! self::subscription_covers_product( $subscription, $appointment_product_id ) ) {
				continue;
			}
			if ( ! self::has_credit_available( $subscription ) ) {
				continue;
			}
			$matches[] = $subscription;
		}

		return $matches;
	}

	/**
	 * Single resolver for membership booking UI and cart (cached per request).
	 *
	 * @param int $user_id                User id.
	 * @param int $appointment_product_id Appointable product id.
	 * @return array<string, mixed>|null Null when no bookable membership for product.
	 */
	public static function get_booking_context( $user_id, $appointment_product_id ) {
		$user_id                = (int) $user_id;
		$appointment_product_id = (int) $appointment_product_id;
		if ( $user_id <= 0 || $appointment_product_id <= 0 ) {
			return null;
		}

		$cache_key = $user_id . ':' . $appointment_product_id;
		if ( array_key_exists( $cache_key, self::$booking_context_cache ) ) {
			return self::$booking_context_cache[ $cache_key ];
		}

		$subscriptions = self::get_bookable_subscriptions_for_user( $user_id, $appointment_product_id );
		if ( empty( $subscriptions ) ) {
			self::$booking_context_cache[ $cache_key ] = null;
			return null;
		}

		$default    = $subscriptions[0];
		$context    = array(
			'subscriptions'           => $subscriptions,
			'default_subscription_id' => (int) $default->get_id(),
			'auto_apply'              => 1 === count( $subscriptions ),
		);
		$context    = apply_filters( 'wc_appointments_membership_booking_context', $context, $user_id, $appointment_product_id );
		self::$booking_context_cache[ $cache_key ] = $context;

		return $context;
	}

	/**
	 * @param int $subscription_id Subscription id.
	 * @param int $product_id      Appointable product id.
	 * @param int $user_id         User id (0 = current).
	 * @return bool
	 */
	public static function validate_membership_selection( $subscription_id, $product_id, $user_id = 0 ) {
		if ( ! function_exists( 'wcs_get_subscription' ) ) {
			return true;
		}

		$user_id      = $user_id > 0 ? $user_id : get_current_user_id();
		$subscription = wcs_get_subscription( $subscription_id );
		if ( ! $subscription || (int) $subscription->get_user_id() !== $user_id ) {
			wc_add_notice( __( 'Invalid membership selected.', 'woocommerce-appointments' ), 'error' );
			return false;
		}

		if ( ! self::can_consume_for_product( $subscription, $product_id ) ) {
			wc_add_notice( __( 'This membership cannot be used here or has no credits left.', 'woocommerce-appointments' ), 'error' );
			return false;
		}

		return true;
	}

	/**
	 * Checkout guard for membership lines.
	 *
	 * @return void
	 */
	public static function validate_checkout_membership() {
		if ( WC()->cart ) {
			self::validate_cart_membership( WC()->cart );
		}
	}

	/**
	 * First appointable product URL stored on the subscription at grant time.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @return string
	 */
	public static function get_first_booking_url( $subscription ) {
		if ( ! $subscription ) {
			return '';
		}

		$product_id = (int) $subscription->get_meta( self::META_FIRST_BOOKING_PRODUCT_ID, true );
		if ( $product_id <= 0 ) {
			return '';
		}

		$permalink = get_permalink( $product_id );
		return $permalink ? $permalink : '';
	}

	/**
	 * Resolve the default bookable product for a membership plan.
	 *
	 * @param WC_Product|int $plan Plan product.
	 * @return int
	 */
	public static function resolve_first_booking_product_id( $plan ) {
		if ( is_numeric( $plan ) ) {
			$plan = wc_get_product( (int) $plan );
		}
		if ( ! ( $plan instanceof WC_Product ) ) {
			return 0;
		}

		$eligible = WC_Appointments_Integration_Subscription_Plan::eligible_appointment_product_ids( $plan );
		if ( ! empty( $eligible ) ) {
			foreach ( $eligible as $product_id ) {
				$product = wc_get_product( (int) $product_id );
				if ( $product && $product->is_purchasable() && is_wc_appointment_product( $product ) ) {
					return (int) $product_id;
				}
			}

			return (int) $eligible[0];
		}

		$query = wc_get_products(
			array(
				'type'    => 'appointment',
				'status'  => 'publish',
				'limit'   => 1,
				'orderby' => 'title',
				'order'   => 'ASC',
				'return'  => 'ids',
			)
		);

		return ! empty( $query ) ? (int) $query[0] : 0;
	}

	/**
	 * Validate membership credits on cart lines (checkout guard).
	 *
	 * @param WC_Cart $cart Cart.
	 * @return bool True when valid or no membership lines.
	 */
	public static function validate_cart_membership( $cart ) {
		if ( ! $cart || ! is_user_logged_in() || ! function_exists( 'wcs_get_subscription' ) ) {
			return true;
		}

		$counts = array();
		foreach ( $cart->get_cart() as $cart_item ) {
			$subscription_id = (int) ( $cart_item['wca_membership_subscription_id'] ?? 0 );
			if ( $subscription_id <= 0 ) {
				continue;
			}

			if ( ! self::validate_membership_selection( $subscription_id, (int) $cart_item['product_id'] ) ) {
				return false;
			}

			$counts[ $subscription_id ] = isset( $counts[ $subscription_id ] )
				? $counts[ $subscription_id ] + WC_Appointments_Integration_Subscriptions_Cart::get_line_credits_required( $cart_item )
				: WC_Appointments_Integration_Subscriptions_Cart::get_line_credits_required( $cart_item );
		}

		foreach ( $counts as $subscription_id => $count ) {
			$subscription = wcs_get_subscription( $subscription_id );
			if ( $subscription && ! self::has_credits_for_count( $subscription, $count, true ) ) {
				self::add_insufficient_credits_notice( $count );
				return false;
			}
		}

		return true;
	}

	/**
	 * Store first-booking product id when credits are granted (write once).
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @param WC_Product      $plan         Plan product.
	 * @return void
	 */
	protected static function maybe_store_first_booking_product_id( $subscription, $plan ) {
		if ( (int) $subscription->get_meta( self::META_FIRST_BOOKING_PRODUCT_ID, true ) > 0 ) {
			return;
		}

		$product_id = self::resolve_first_booking_product_id( $plan );
		if ( $product_id > 0 ) {
			$subscription->update_meta_data( self::META_FIRST_BOOKING_PRODUCT_ID, $product_id );
		}
	}

	/**
	 * @param WC_Subscription $subscription           Subscription.
	 * @param int             $appointment_product_id Appointable product id.
	 * @return bool
	 */
	public static function subscription_covers_product( $subscription, $appointment_product_id ) {
		if ( ! $subscription || ! is_a( $subscription, 'WC_Subscription' ) ) {
			return false;
		}

		$plan = self::get_plan_product( $subscription );
		if ( ! $plan ) {
			return false;
		}

		return WC_Appointments_Integration_Subscription_Plan::covers_appointment_product( $plan, $appointment_product_id );
	}

	/**
	 * @param WC_Subscription $subscription           Subscription.
	 * @param int             $appointment_product_id Appointable product id.
	 * @return bool
	 */
	public static function can_consume_for_product( $subscription, $appointment_product_id ) {
		return self::subscription_covers_product( $subscription, $appointment_product_id ) && self::has_credit_available( $subscription );
	}

	/**
	 * Whether the subscription has enough credits for multiple appointments.
	 *
	 * @param WC_Subscription $subscription       Subscription.
	 * @param int             $count              Appointments to cover.
	 * @param bool            $use_stored_balance Compare stored wallet only (checkout total guard).
	 * @return bool
	 */
	public static function has_credits_for_count( $subscription, $count, $use_stored_balance = false ) {
		$count = (int) $count;
		if ( $count <= 0 || ! $subscription ) {
			return false;
		}

		$balance = self::get_balance( $subscription );
		if ( null === $balance ) {
			return true;
		}

		if ( ! $use_stored_balance && WC()->cart && class_exists( 'WC_Appointments_Integration_Subscriptions_Cart' ) ) {
			$balance = max(
				0,
				$balance - WC_Appointments_Integration_Subscriptions_Cart::get_cart_reserved_credits( (int) $subscription->get_id() )
			);
		}

		return $balance >= $count;
	}

	/**
	 * Storefront error when membership credits are insufficient.
	 *
	 * @param int $count Credits required.
	 * @return void
	 */
	public static function add_insufficient_credits_notice( $count ) {
		wc_add_notice(
			sprintf(
				/* translators: %d: credits required */
				_n(
					'Not enough credits for %d appointment in this order.',
					'Not enough credits for %d appointments in this order.',
					(int) $count,
					'woocommerce-appointments'
				),
				(int) $count
			),
			'error'
		);
	}

	/**
	 * Deduct one credit after a successful membership booking.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @param int             $appointment_id Optional appointment id for notes.
	 * @return bool|WP_Error
	 */
	public static function consume_credit( $subscription, $appointment_id = 0 ) {
		if ( ! $subscription || ! $subscription->has_status( array( 'active' ) ) ) {
			return new WP_Error( 'wca_no_credits', __( 'No credits remaining.', 'woocommerce-appointments' ) );
		}

		if ( ! WC_Appointments_Integration_Subscriptions::subscription_allows_booking( $subscription ) ) {
			return new WP_Error( 'wca_no_credits', __( 'No credits remaining.', 'woocommerce-appointments' ) );
		}

		$balance = self::get_balance( $subscription );
		if ( null === $balance ) {
			return true;
		}

		if ( $balance <= 0 ) {
			return new WP_Error( 'wca_no_credits', __( 'No credits remaining.', 'woocommerce-appointments' ) );
		}

		$subscription->update_meta_data( self::META_BALANCE, max( 0, $balance - 1 ) );
		$subscription->save();

		if ( $appointment_id > 0 ) {
			$appt = get_wc_appointment( $appointment_id );
			if ( $appt ) {
				$appt->update_meta_data( '_wca_membership_subscription_id', (int) $subscription->get_id() );
				$appt->save();
			}
		}

		return true;
	}

	/**
	 * Deduct multiple credits after a successful membership booking.
	 *
	 * @param WC_Subscription $subscription   Subscription.
	 * @param int             $count          Credits to deduct.
	 * @param int             $appointment_id Optional appointment id for the first credit.
	 * @return bool|WP_Error
	 */
	public static function consume_credits( $subscription, $count, $appointment_id = 0 ) {
		$count = max( 0, (int) $count );
		for ( $i = 0; $i < $count; $i++ ) {
			$result = self::consume_credit( $subscription, 0 === $i ? $appointment_id : 0 );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		return true;
	}

	/**
	 * Restore one credit when a membership booking is cancelled.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @return void
	 */
	public static function restore_credit( $subscription ) {
		if ( ! $subscription || ! is_a( $subscription, 'WC_Subscription' ) ) {
			return;
		}

		$plan = self::get_plan_product( $subscription );
		if ( ! $plan || WC_Appointments_Integration_Subscription_Plan::is_unlimited( $plan ) ) {
			return;
		}

		$balance = (int) $subscription->get_meta( self::META_BALANCE, true );
		if ( self::UNLIMITED_BALANCE === $balance ) {
			return;
		}

		$restored = $balance + 1;

		// Without rollover the balance is replaced (not accumulated) each period, so a
		// restore must never push it above the current period allotment.
		if ( ! WC_Appointments_Integration_Subscription_Plan::rollover_enabled( $plan ) ) {
			$grant    = WC_Appointments_Integration_Subscription_Plan::appointments_per_period( $plan );
			$restored = min( $restored, max( $balance, $grant ) );
		}

		$subscription->update_meta_data( self::META_BALANCE, max( 0, $restored ) );
		$subscription->save();
	}

	/**
	 * Restore multiple credits when a membership booking is cancelled.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @param int             $count        Credits to restore.
	 * @return void
	 */
	public static function restore_credits( $subscription, $count ) {
		$count = max( 0, (int) $count );
		for ( $i = 0; $i < $count; $i++ ) {
			self::restore_credit( $subscription );
		}
	}

	/**
	 * Plan product name for storefront display.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @param string          $fallback     Used when plan product is missing (empty = subscription id).
	 * @return string
	 */
	public static function get_plan_name( $subscription, $fallback = '' ) {
		$plan = self::get_plan_product( $subscription );
		if ( $plan ) {
			return $plan->get_name();
		}

		if ( '' !== $fallback ) {
			return $fallback;
		}

		return sprintf(
			/* translators: %d: subscription id */
			__( 'Subscription #%d', 'woocommerce-appointments' ),
			$subscription->get_id()
		);
	}

	/**
	 * Remaining credits label for display.
	 *
	 * @param WC_Subscription $subscription Subscription.
	 * @return string
	 */
	public static function balance_label( $subscription ) {
		$balance = self::get_balance( $subscription );
		if ( null === $balance ) {
			return __( 'Unlimited', 'woocommerce-appointments' );
		}

		if ( WC()->cart && class_exists( 'WC_Appointments_Integration_Subscriptions_Cart' ) ) {
			$balance = max( 0, $balance - WC_Appointments_Integration_Subscriptions_Cart::get_cart_reserved_credits( (int) $subscription->get_id() ) );
		}

		$plan = self::get_plan_product( $subscription );
		if ( $plan && ! WC_Appointments_Integration_Subscription_Plan::is_unlimited( $plan ) ) {
			return sprintf(
				/* translators: 1: credits remaining, 2: credits per billing period */
				__( '%1$d of %2$d remaining', 'woocommerce-appointments' ),
				$balance,
				WC_Appointments_Integration_Subscription_Plan::appointments_per_period( $plan )
			);
		}

		return sprintf(
			/* translators: %d: remaining appointment credits */
			_n( '%d credit remaining', '%d credits remaining', $balance, 'woocommerce-appointments' ),
			$balance
		);
	}

	/**
	 * Cart / checkout: plan, covered amount, current credit balance.
	 *
	 * @param WC_Subscription $subscription     Subscription.
	 * @param float           $covered_amount Nominal appointment cost covered by credit.
	 * @return string
	 */
	public static function membership_credit_summary( $subscription, $covered_amount ) {
		$parts = array( self::get_plan_name( $subscription, __( 'Membership', 'woocommerce-appointments' ) ) );

		if ( $covered_amount > 0 ) {
			$parts[] = sprintf(
				/* translators: %s: formatted price */
				__( '%s covered', 'woocommerce-appointments' ),
				wp_strip_all_tags( wc_price( $covered_amount ) )
			);
		}

		$parts[] = self::balance_label( $subscription );

		return implode( ' · ', $parts );
	}
}
