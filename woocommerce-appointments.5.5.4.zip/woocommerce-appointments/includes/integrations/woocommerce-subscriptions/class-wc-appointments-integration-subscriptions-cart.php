<?php
/**
 * Storefront - membership credits on booking form footer, cart, and checkout.
 *
 * @package WooCommerce\Appointments\Integrations\WooCommerceSubscriptions
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

class WC_Appointments_Integration_Subscriptions_Cart {

	/**
	 * @return void
	 */
	public static function init() {
		add_action( 'woocommerce_appointment_form_cost_footer', array( __CLASS__, 'render_form_footer' ) );
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'filter_membership_cart_item_data' ), 15, 2 );
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate_membership_add_to_cart' ), 15, 3 );
		add_action( 'woocommerce_review_order_before_payment', array( __CLASS__, 'render_checkout_block' ), 8 );
		add_filter( 'woocommerce_add_cart_item', array( __CLASS__, 'ensure_membership_base_cost' ), 100, 1 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( __CLASS__, 'restore_membership_base_cost' ), 25, 3 );
		add_action( 'woocommerce_checkout_process', array( __CLASS__, 'sync_membership_from_request' ), 5 );
		add_action( 'woocommerce_checkout_process', array( 'WC_Appointments_Integration_Subscription_Entitlement', 'validate_checkout_membership' ), 15 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'append_cart_item_data' ), 20, 2 );
		add_filter( 'woocommerce_cart_item_price', array( __CLASS__, 'filter_membership_cart_price_display' ), 20, 3 );
		add_filter( 'woocommerce_cart_item_subtotal', array( __CLASS__, 'filter_membership_cart_price_display' ), 20, 3 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'persist_order_line_meta' ), 60, 4 );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'consume_credits_from_order' ), 5, 1 );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'consume_credits_from_order' ), 5, 1 );
		add_action( 'woocommerce_order_status_partial-payment', array( __CLASS__, 'consume_credits_from_order' ), 5, 1 );
		add_action( 'woocommerce_payment_complete', array( __CLASS__, 'consume_credits_from_order' ), 5, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'restore_credits_from_order' ), 10, 1 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'restore_credits_from_order' ), 10, 1 );
	}

	/**
	 * @param int $product_id Appointable product id.
	 * @return void
	 */
	public static function render_form_footer( $product_id ) {
		$context = WC_Appointments_Integration_Subscription_Entitlement::get_booking_context( get_current_user_id(), (int) $product_id );
		if ( ! $context ) {
			return;
		}

		self::render_template(
			array(
				'mode'                     => 'form',
				'subscriptions'            => $context['subscriptions'],
				'selected_subscription_id' => $context['default_subscription_id'],
				'auto_apply'               => $context['auto_apply'],
			)
		);
	}

	/**
	 * @param array<string, mixed> $cart_item_meta Cart item meta.
	 * @param int                  $product_id     Product id.
	 * @return array<string, mixed>
	 */
	public static function filter_membership_cart_item_data( $cart_item_meta, $product_id ) {
		if ( ! is_user_logged_in() || empty( $cart_item_meta['appointment'] ) ) {
			return $cart_item_meta;
		}

		if ( WC_Appointment_Series_Request::is_recurring_request() && empty( $cart_item_meta['wca_recurring'] ) ) {
			return $cart_item_meta;
		}

		$subscription_id = self::resolve_posted_subscription_id( (int) $product_id );
		if ( $subscription_id > 0 ) {
			self::apply_credit_to_line_meta( $cart_item_meta, $subscription_id, (int) $product_id );
		}

		return $cart_item_meta;
	}

	/**
	 * @param bool $passed     Prior validation result.
	 * @param int  $product_id Product id.
	 * @param int  $quantity   Quantity (unused).
	 * @return bool
	 */
	public static function validate_membership_add_to_cart( $passed, $product_id, $quantity ) {
		unset( $quantity );
		if ( ! $passed || ! is_user_logged_in() ) {
			return $passed;
		}

		$subscription_id = self::resolve_posted_subscription_id( (int) $product_id );
		if ( $subscription_id <= 0 ) {
			return $passed;
		}

		if ( ! WC_Appointments_Integration_Subscription_Entitlement::validate_membership_selection( $subscription_id, (int) $product_id ) ) {
			return false;
		}

		$credits_required = self::get_line_credits_required( array(), (int) $product_id );
		$subscription     = wcs_get_subscription( $subscription_id );
		if ( $credits_required > 0 && $subscription && ! WC_Appointments_Integration_Subscription_Entitlement::has_credits_for_count( $subscription, $credits_required ) ) {
			WC_Appointments_Integration_Subscription_Entitlement::add_insufficient_credits_notice( $credits_required );
			return false;
		}

		return $passed;
	}

	/**
	 * @return void
	 */
	public static function render_checkout_block() {
		if ( ! is_user_logged_in() || ! WC()->cart ) {
			return;
		}

		$lines = self::eligible_lines();
		if ( empty( $lines ) ) {
			return;
		}

		$selected_id    = 0;
		$credit_applied = true;
		foreach ( $lines as $line ) {
			if ( $selected_id <= 0 && $line['sub_id'] > 0 ) {
				$selected_id = $line['sub_id'];
			}
			if ( $line['sub_id'] <= 0 || ( $selected_id > 0 && (int) $line['sub_id'] !== $selected_id ) ) {
				$credit_applied = false;
			}
		}

		if ( $credit_applied && $selected_id > 0 && function_exists( 'wcs_get_subscription' ) ) {
			$subscription = wcs_get_subscription( $selected_id );
			if ( $subscription ) {
				$base_cost = 0;
				foreach ( $lines as $line ) {
					if ( (int) $line['sub_id'] !== $selected_id ) {
						continue;
					}
					$item = WC()->cart->cart_contents[ $line['key'] ] ?? null;
					if ( $item ) {
						$base_cost += (float) ( $item['wca_membership_base_cost'] ?? 0 );
					}
				}
				self::render_template(
					array(
						'mode'           => 'applied',
						'credit_summary' => WC_Appointments_Integration_Subscription_Entitlement::membership_credit_summary( $subscription, $base_cost ),
					)
				);
				return;
			}
		}

		$subscriptions = self::subscriptions_for_lines( $lines );
		if ( empty( $subscriptions ) ) {
			return;
		}

		$credits_required = 0;
		foreach ( $lines as $line ) {
			$credits_required += (int) $line['credits'];
		}

		self::render_template(
			array(
				'mode'                     => 'checkout',
				'subscriptions'            => $subscriptions,
				'selected_subscription_id' => $selected_id > 0 ? $selected_id : (int) $subscriptions[0]->get_id(),
				'credits_required'         => $credits_required,
			)
		);
	}

	/**
	 * @param array<string, mixed> $cart_item Cart item.
	 * @return array<string, mixed>
	 */
	public static function ensure_membership_base_cost( $cart_item ) {
		if ( ! empty( $cart_item['appointment']['_cost'] ) && ! isset( $cart_item['wca_membership_base_cost'] ) ) {
			$cart_item['wca_membership_base_cost'] = (float) $cart_item['appointment']['_cost'];
		}
		if ( ! empty( $cart_item['wca_membership_subscription_id'] ) && ! empty( $cart_item['appointment'] ) ) {
			$cart_item['appointment']['_cost'] = 0.0;
			if ( ! empty( $cart_item['data'] ) ) {
				$cart_item['data']->set_price( 0 );
			}
		}
		return $cart_item;
	}

	/**
	 * @param array<string, mixed> $cart_item     Cart item.
	 * @param array<string, mixed> $values        Session values.
	 * @param string               $cart_item_key Cart item key (unused).
	 * @return array<string, mixed>
	 */
	public static function restore_membership_base_cost( $cart_item, $values, $cart_item_key ) {
		unset( $cart_item_key );
		if ( isset( $values['wca_membership_base_cost'] ) ) {
			$cart_item['wca_membership_base_cost'] = (float) $values['wca_membership_base_cost'];
		}
		if ( isset( $values['wca_membership_credits_required'] ) ) {
			$cart_item['wca_membership_credits_required'] = (int) $values['wca_membership_credits_required'];
		}
		return $cart_item;
	}

	/**
	 * @return void
	 */
	public static function sync_membership_from_request() {
		if ( ! is_user_logged_in() || ! WC()->cart ) {
			return;
		}

		$lines = self::eligible_lines();
		foreach ( $lines as $line ) {
			if ( $line['sub_id'] <= 0 ) {
				$posted = self::posted_membership_fields();
				if ( empty( $posted['use'] ) || '1' !== (string) $posted['use'] ) {
					return;
				}

				$subscription_id = isset( $posted['subscription_id'] ) ? absint( $posted['subscription_id'] ) : 0;
				if ( $subscription_id <= 0 ) {
					$subscriptions = self::subscriptions_for_lines( $lines );
					$subscription_id = ! empty( $subscriptions ) ? (int) $subscriptions[0]->get_id() : 0;
				}

				self::apply_membership( $lines, $subscription_id );
				WC()->cart->calculate_totals();
				return;
			}
		}
	}

	/**
	 * @param array<int, array<string, mixed>> $item_data Cart item display rows.
	 * @param array<string, mixed>             $cart_item Cart item.
	 * @return array<int, array<string, mixed>>
	 */
	public static function append_cart_item_data( $item_data, $cart_item ) {
		$label = self::membership_credit_label( $cart_item );
		if ( $label ) {
			$item_data[] = array(
				'name'    => __( 'Membership credit', 'woocommerce-appointments' ),
				'value'   => $label,
				'display' => '',
			);
		}

		return $item_data;
	}

	/**
	 * @param string               $html          Price HTML.
	 * @param array<string, mixed> $cart_item     Cart item.
	 * @param string               $cart_item_key Cart item key (unused).
	 * @return string
	 */
	public static function filter_membership_cart_price_display( $html, $cart_item, $cart_item_key ) {
		unset( $cart_item_key );
		$base = (float) ( $cart_item['wca_membership_base_cost'] ?? 0 );
		if ( $base > 0 && ! empty( $cart_item['wca_membership_subscription_id'] ) ) {
			return wc_format_sale_price( $base, 0 );
		}
		return $html;
	}

	/**
	 * @param WC_Order_Item_Product $item          Order line item.
	 * @param string                $cart_item_key Cart item key (unused).
	 * @param array<string, mixed>  $values        Cart item values.
	 * @param WC_Order              $order         Order (unused).
	 * @return void
	 */
	public static function persist_order_line_meta( $item, $cart_item_key, $values, $order ) {
		unset( $cart_item_key, $order );
		if ( empty( $values['wca_membership_subscription_id'] ) ) {
			return;
		}

		$item->add_meta_data( '_wca_membership_subscription_id', (int) $values['wca_membership_subscription_id'], true );
		$item->add_meta_data( '_wca_membership_credits_required', self::get_line_credits_required( $values ), true );

		$label = self::membership_credit_label( $values );
		if ( $label ) {
			$item->add_meta_data( __( 'Membership credit', 'woocommerce-appointments' ), $label, true );
		}

		$item->set_subtotal( 0 );
		$item->set_total( 0 );
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public static function consume_credits_from_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || ! function_exists( 'wcs_get_subscription' ) ) {
			return;
		}

		foreach ( $order->get_items() as $item_id => $item ) {
			$subscription_id = (int) $item->get_meta( '_wca_membership_subscription_id', true );
			$credits         = max( 1, (int) $item->get_meta( '_wca_membership_credits_required', true ) );
			if ( $subscription_id <= 0 || (int) $item->get_meta( '_wca_membership_credits_consumed', true ) > 0 ) {
				continue;
			}

			if ( empty( WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $item_id, true, $order->get_id() ) ) ) {
				continue;
			}

			$subscription = wcs_get_subscription( $subscription_id );
			if ( ! $subscription ) {
				continue;
			}

			$result = WC_Appointments_Integration_Subscription_Entitlement::consume_credits(
				$subscription,
				$credits,
				self::find_appointment_id_for_order_item( $order, $item_id )
			);
			if ( is_wp_error( $result ) ) {
				$order->add_order_note(
					sprintf(
						/* translators: %1$s: error message, %2$d: subscription id */
						__( 'Membership credit could not be deducted for subscription #%2$d: %1$s', 'woocommerce-appointments' ),
						$result->get_error_message(),
						$subscription_id
					)
				);
				continue;
			}

			$item->update_meta_data( '_wca_membership_credits_consumed', $credits );
			$item->save();
		}
	}

	/**
	 * @param int $order_id Order id.
	 * @return void
	 */
	public static function restore_credits_from_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || ! function_exists( 'wcs_get_subscription' ) ) {
			return;
		}

		foreach ( $order->get_items() as $item ) {
			$consumed = (int) $item->get_meta( '_wca_membership_credits_consumed', true );
			if ( $consumed <= 0 ) {
				continue;
			}

			$subscription = wcs_get_subscription( (int) $item->get_meta( '_wca_membership_subscription_id', true ) );
			if ( $subscription ) {
				WC_Appointments_Integration_Subscription_Entitlement::restore_credits( $subscription, $consumed );
			}

			$item->delete_meta_data( '_wca_membership_credits_consumed' );
			$item->save();
		}
	}

	/**
	 * Credits reserved on cart lines for a membership subscription.
	 *
	 * @param int $subscription_id Subscription id.
	 * @return int
	 */
	public static function get_cart_reserved_credits( $subscription_id ) {
		$subscription_id = (int) $subscription_id;
		if ( $subscription_id <= 0 || ! WC()->cart ) {
			return 0;
		}

		$reserved = 0;
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( (int) ( $item['wca_membership_subscription_id'] ?? 0 ) !== $subscription_id ) {
				continue;
			}
			$reserved += self::get_line_credits_required( $item );
		}

		return $reserved;
	}

	/**
	 * Credits required for one cart line (1 for single booking; billable sessions for recurring).
	 *
	 * @param array<string, mixed> $line       Cart line or cart meta.
	 * @param int                  $product_id Appointable product id during add-to-cart validation.
	 * @return int
	 */
	public static function get_line_credits_required( $line, $product_id = 0 ) {
		if ( ! empty( $line['wca_membership_credits_required'] ) ) {
			return max( 1, (int) $line['wca_membership_credits_required'] );
		}

		$billable = 0;
		if ( ! empty( $line['wca_recurring'] ) && is_array( $line['wca_recurring'] ) ) {
			$recurring = $line['wca_recurring'];
			$billable  = (int) ( $recurring['billable_count'] ?? $recurring['preview_summary']['billable_count'] ?? 0 );
		}
		if ( $billable <= 0 && $product_id > 0 ) {
			$billable = WC_Appointment_Series_Request::billable_count_from_request( $product_id );
		}

		return max( 1, $billable );
	}

	/**
	 * @param array<string, mixed> $args Template args.
	 * @return void
	 */
	protected static function render_template( array $args ) {
		wc_get_template( 'cart/membership-credits.php', $args, 'woocommerce-appointments', WC_APPOINTMENTS_TEMPLATE_PATH );
	}

	/**
	 * @param array<string, mixed> $cart_item Cart item.
	 * @return string
	 */
	protected static function membership_credit_label( $cart_item ) {
		$subscription_id = (int) ( $cart_item['wca_membership_subscription_id'] ?? 0 );
		if ( $subscription_id <= 0 || ! function_exists( 'wcs_get_subscription' ) ) {
			return '';
		}

		$subscription = wcs_get_subscription( $subscription_id );
		if ( ! $subscription ) {
			return '';
		}

		return WC_Appointments_Integration_Subscription_Entitlement::membership_credit_summary(
			$subscription,
			(float) ( $cart_item['wca_membership_base_cost'] ?? 0 )
		);
	}

	/**
	 * @return array<int, array<string, mixed>>
	 */
	protected static function eligible_lines() {
		$lines = array();
		if ( ! WC()->cart ) {
			return $lines;
		}

		foreach ( WC()->cart->get_cart() as $key => $item ) {
			if ( ! is_user_logged_in() || empty( $item['appointment'] ) || ! is_wc_appointment_product( $item['data'] ?? null ) ) {
				continue;
			}

			$lines[] = array(
				'key'        => $key,
				'product_id' => (int) $item['product_id'],
				'sub_id'     => (int) ( $item['wca_membership_subscription_id'] ?? 0 ),
				'credits'    => self::get_line_credits_required( $item ),
			);
		}

		return $lines;
	}

	/**
	 * @param array<int, array<string, mixed>> $lines Eligible cart lines.
	 * @return array<int, mixed>
	 */
	protected static function subscriptions_for_lines( array $lines ) {
		$by_id = array();
		foreach ( $lines as $line ) {
			$context = WC_Appointments_Integration_Subscription_Entitlement::get_booking_context( get_current_user_id(), (int) $line['product_id'] );
			if ( empty( $context['subscriptions'] ) ) {
				continue;
			}
			foreach ( $context['subscriptions'] as $subscription ) {
				$by_id[ (int) $subscription->get_id() ] = $subscription;
			}
		}
		return array_values( $by_id );
	}

	/**
	 * @param array<int, array<string, mixed>> $lines           Eligible cart lines.
	 * @param int                              $subscription_id Membership subscription id.
	 * @return void
	 */
	protected static function apply_membership( array $lines, $subscription_id ) {
		if ( $subscription_id <= 0 || ! function_exists( 'wcs_get_subscription' ) || ! WC()->cart ) {
			return;
		}

		$subscription = wcs_get_subscription( $subscription_id );
		if ( ! $subscription || (int) $subscription->get_user_id() !== get_current_user_id() ) {
			return;
		}

		$coverable        = array();
		$credits_required = 0;
		foreach ( $lines as $line ) {
			if ( WC_Appointments_Integration_Subscription_Entitlement::subscription_covers_product( $subscription, $line['product_id'] ) ) {
				$coverable[] = $line;
				$credits_required += (int) $line['credits'];
			} else {
				self::remove_credit( $line['key'] );
			}
		}

		if ( empty( $coverable ) || ! WC_Appointments_Integration_Subscription_Entitlement::has_credits_for_count( $subscription, $credits_required ) ) {
			WC_Appointments_Integration_Subscription_Entitlement::add_insufficient_credits_notice( $credits_required );
			return;
		}

		foreach ( $coverable as $line ) {
			if ( ! empty( WC()->cart->cart_contents[ $line['key'] ]['appointment'] ) ) {
				self::apply_credit_to_line_meta(
					WC()->cart->cart_contents[ $line['key'] ],
					$subscription_id,
					(int) $line['product_id']
				);
			}
		}
	}

	/**
	 * @param string $cart_item_key Cart item key.
	 * @return void
	 */
	protected static function remove_credit( $cart_item_key ) {
		if ( empty( WC()->cart->cart_contents[ $cart_item_key ] ) ) {
			return;
		}

		unset( WC()->cart->cart_contents[ $cart_item_key ]['wca_membership_subscription_id'] );
		unset( WC()->cart->cart_contents[ $cart_item_key ]['wca_membership_credits_required'] );
		if ( isset( WC()->cart->cart_contents[ $cart_item_key ]['wca_membership_base_cost'] ) ) {
			WC()->cart->cart_contents[ $cart_item_key ]['appointment']['_cost'] = (float) WC()->cart->cart_contents[ $cart_item_key ]['wca_membership_base_cost'];
		}
	}

	/**
	 * @param array<string, mixed> $line            Cart line (by reference).
	 * @param int                  $subscription_id Membership subscription id.
	 * @param int                  $product_id      Appointable product id.
	 * @return bool
	 */
	protected static function apply_credit_to_line_meta( &$line, $subscription_id, $product_id ) {
		if ( $subscription_id <= 0 || empty( $line['appointment'] ) || ! function_exists( 'wcs_get_subscription' ) ) {
			return false;
		}

		$credits_required = self::get_line_credits_required( $line, (int) $product_id );
		$subscription     = wcs_get_subscription( $subscription_id );
		if (
			! $subscription
			|| ! WC_Appointments_Integration_Subscription_Entitlement::subscription_covers_product( $subscription, $product_id )
			|| ! WC_Appointments_Integration_Subscription_Entitlement::has_credits_for_count( $subscription, $credits_required )
		) {
			return false;
		}

		if ( ! isset( $line['wca_membership_base_cost'] ) ) {
			$line['wca_membership_base_cost'] = (float) $line['appointment']['_cost'];
		}
		$line['wca_membership_subscription_id']  = $subscription_id;
		$line['wca_membership_credits_required'] = $credits_required;
		$line['appointment']['_cost']           = 0.0;
		if ( ! empty( $line['data'] ) ) {
			$line['data']->set_price( 0 );
		}
		return true;
	}

	/**
	 * @param int $product_id Appointable product id.
	 * @return int
	 */
	protected static function resolve_posted_subscription_id( $product_id ) {
		$context = WC_Appointments_Integration_Subscription_Entitlement::get_booking_context( get_current_user_id(), $product_id );
		if ( ! $context ) {
			return 0;
		}

		$posted = self::posted_membership_fields();
		$use    = ! empty( $context['auto_apply'] );
		if ( isset( $posted['use'] ) ) {
			$use = '1' === (string) $posted['use'];
		}
		if ( ! $use ) {
			return 0;
		}

		$subscription_id = isset( $posted['subscription_id'] ) ? absint( $posted['subscription_id'] ) : 0;
		return $subscription_id > 0 ? $subscription_id : (int) $context['default_subscription_id'];
	}

	/**
	 * @param mixed $order         Order object.
	 * @param int   $order_item_id Order item id.
	 * @return int
	 */
	protected static function find_appointment_id_for_order_item( $order, $order_item_id ) {
		if ( ! is_a( $order, 'WC_Order' ) ) {
			return 0;
		}

		$ids = WC_Appointment_Data_Store::get_appointment_ids_from_order_item_id( $order_item_id, true, $order->get_id() );

		return ! empty( $ids ) ? (int) $ids[0] : 0;
	}

	/**
	 * Unslashed membership POST fields (WooCommerce verifies nonce on add-to-cart/checkout).
	 *
	 * @return array<string, mixed>
	 */
	protected static function posted_membership_fields(): array {
		if ( ! isset( $_POST['wca_membership'] ) || ! is_array( $_POST['wca_membership'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies nonce on add-to-cart/checkout.
			return array();
		}

		return wp_unslash( $_POST['wca_membership'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- absint/string cast per field below.
	}
}
