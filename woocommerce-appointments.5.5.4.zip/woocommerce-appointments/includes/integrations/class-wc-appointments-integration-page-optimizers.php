<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Page optimizer compatibility (LiteSpeed Cache, Autoptimize, WP Rocket).
 *
 * Opts the storefront appointment form stack out of Delay / Defer / Combine when
 * the form is enqueued, so jQuery, localized params, and pickers stay ordered.
 *
 * Last compatibility check: LiteSpeed Cache 7.9, Autoptimize 3.1, WP Rocket 3.18
 *
 * @since 5.4.8
 */
class WC_Appointments_Integration_Page_Optimizers implements WC_Appointments_Integration_Interface {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->add_hooks();
	}

	/**
	 * @return void
	 */
	public function add_hooks(): void {
		add_filter( 'script_loader_tag', [ $this, 'protect_script_tag' ], 10, 2 );
		add_filter( 'litespeed_optimize_js_excludes', [ $this, 'exclude_js' ] );
		add_filter( 'litespeed_optm_js_defer_exc', [ $this, 'exclude_js' ] );
		add_filter( 'litespeed_optm_js_delay_exc', [ $this, 'exclude_js' ] );
		add_filter( 'autoptimize_filter_js_exclude', [ $this, 'exclude_js' ] );
		add_filter( 'rocket_exclude_defer_js', [ $this, 'exclude_js' ] );
		add_filter( 'rocket_delay_js_exclusions', [ $this, 'exclude_js' ] );
	}

	/**
	 * @return bool
	 */
	private function form_is_enqueued(): bool {
		return wp_script_is( 'wc-appointments-appointment-form', 'enqueued' );
	}

	/**
	 * Handles to leave alone on form pages (data-no-optimize / data-no-defer).
	 *
	 * @return string[]
	 */
	private function protected_handles(): array {
		return [
			'jquery',
			'jquery-core',
			'jquery-migrate',
			'jquery-blockui',
			'jquery-ui-core',
			'jquery-ui-datepicker',
			'select2',
			'selectWoo',
			'underscore',
			'wca-shared-js',
			'wc-appointments-appointment-form',
			'wc-appointments-date-picker',
			'wc-appointments-time-picker',
			'wc-appointments-month-picker',
			'wc-appointments-timezone-picker',
			'wc-appointments-staff-picker',
			'wc-appointments-rrule',
			'wc-appointments-rrule-tz',
		];
	}

	/**
	 * Substrings for optimizer exclude lists (files + localize globals).
	 *
	 * @return string[]
	 */
	private function exclude_patterns(): array {
		return [
			'jquery.js',
			'jquery.min.js',
			'jquery-migrate',
			'jquery-ui',
			'jquery.blockUI',
			'select2',
			'selectWoo',
			'underscore',
			'wca-shared',
			'appointment-form',
			'date-picker',
			'time-picker',
			'month-picker',
			'timezone-picker',
			'staff-picker',
			'rrule',
			'wc_appointment_form_params',
			'wc_appointments_date_picker_args',
			'wc_appointments_timezone_picker_args',
		];
	}

	/**
	 * @param string $tag    Script HTML.
	 * @param string $handle Script handle.
	 * @return string
	 */
	public function protect_script_tag( $tag, $handle ) {
		if ( is_admin() || ! is_string( $tag ) || ! is_string( $handle ) || ! $this->form_is_enqueued() ) {
			return $tag;
		}
		if ( ! in_array( $handle, $this->protected_handles(), true ) ) {
			return $tag;
		}
		if ( false === strpos( $tag, 'data-no-optimize' ) ) {
			$tag = str_replace( '<script ', '<script data-no-optimize="1" ', $tag );
		}
		if ( false === strpos( $tag, 'data-no-defer' ) ) {
			$tag = str_replace( '<script ', '<script data-no-defer="1" ', $tag );
		}
		return $tag;
	}

	/**
	 * @param array<int, string>|string $excludes Existing excludes.
	 * @return array<int, string>|string
	 */
	public function exclude_js( $excludes ) {
		if ( ! $this->form_is_enqueued() ) {
			return $excludes;
		}

		$add = $this->exclude_patterns();

		if ( is_string( $excludes ) ) {
			$parts = preg_split( '/[\s,]+/', $excludes, -1, PREG_SPLIT_NO_EMPTY ) ?: [];
			return implode( ',', array_unique( array_merge( $parts, $add ) ) );
		}

		if ( ! is_array( $excludes ) ) {
			$excludes = [];
		}

		return array_values( array_unique( array_merge( $excludes, $add ) ) );
	}
}
