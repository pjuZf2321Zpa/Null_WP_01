<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce Price Based on Country integration class.
 * https://wordpress.org/plugins/woocommerce-product-price-based-on-countries/
 *
 * Last compatibility check: 3.4.5
 */
class WC_Appointments_Integration_WCPBC implements WC_Appointments_Integration_Interface {

	/**
	 * Constructor
	 */
	public function __construct() {
		$this->add_hooks();
	}

	/**
	 * Register WordPress hooks for this integration.
	 *
	 * @return void
	 */
	public function add_hooks(): void {
		add_filter( 'wc_price_based_country_third_party_product_types', [ $this, 'third_party_product_types' ] );
		add_filter( 'wc_price_based_country_product_types_overriden', [ $this, 'product_types_overriden' ] );
		add_action( 'woocommerce_process_product_meta_appointment', [ $this, 'process_product_meta' ] );
	}

	/**
	 * Register appointable product type with Price Based on Country.
	 *
	 * @param array<string, string> $types Product types.
	 * @return array<string, string>
	 */
	public function third_party_product_types( array $types ): array {
	    $types['appointment'] = __( 'Appointable product', 'woocommerce-appointments' );

	    return $types;
	}

	/**
	 * Mark appointment as an overridden product type for Price Based on Country.
	 *
	 * @param array<int, string> $types Product types.
	 * @return array<int, string>
	 */
	public function product_types_overriden( $types ) {
	    $types[] = 'appointment';

	    return $types;
	}

	/**
	 * Save product metadata
	 *
	 * @param int $post_id Post ID.
	 * @param int|false $index Index of variations to save.
	 */
	public static function process_product_meta( $post_id, $index = false ): void {
		$fields = [ '_price_method', '_regular_price', '_sale_price', '_sale_price_dates', '_sale_price_dates_from', '_sale_price_dates_to' ];
		foreach ( WCPBC_Pricing_Zones::get_zones() as $zone ) {
			$data = [];
			foreach ( $fields as $field ) {
				$var_name       = false !== $index ? '_variable' . $field : $field;
				$data[ $field ] = $zone->get_input_var( $var_name, $index );
			}

			// Save metadata.
			wcpbc_update_product_pricing( $post_id, $zone, $data );
		}
	}
}
