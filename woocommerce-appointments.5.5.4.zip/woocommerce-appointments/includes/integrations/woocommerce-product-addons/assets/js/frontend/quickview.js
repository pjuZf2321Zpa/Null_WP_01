jQuery( document ).ready( function ( $ ) {
	/**
	 * Matches inline variation objects to chosen attributes
	 *
	 * @type {Object}
	 */
	const wc_variation_form_matcher = {
		find_matching_variations( product_variations, settings ) {
			const matching = [];
			for ( let i = 0; i < product_variations.length; i++ ) {
				const variation = product_variations[ i ];

				if (
					wc_variation_form_matcher.variations_match(
						variation.attributes,
						settings
					)
				) {
					matching.push( variation );
				}
			}
			return matching;
		},
		variations_match( attrs1, attrs2 ) {
			let match = true;
			for ( const attr_name in attrs1 ) {
				const val1 = attrs1[ attr_name ];
				const val2 = attrs2[ attr_name ];
				if (
					val1 !== undefined &&
					val2 !== undefined &&
					val1.length !== 0 &&
					val2.length !== 0 &&
					val1 !== val2
				) {
					match = false;
				}
			}
			return match;
		},
	};

	$( 'body' ).on( 'change', '.variations select', function () {
		const $form = $( '.variations_form' ),
			$product_variations = $form.data( 'product_variations' ),
			data = {};

		$form.find( '.variations select' ).each( function () {
			const attribute_name =
				$( this ).data( 'attribute_name' ) || $( this ).attr( 'name' );
			data[ attribute_name ] = $( this ).val();
		} );

		if ( typeof $product_variations === 'undefined' ) {
			return;
		}

		const $totals = $( '#product-addons-total' );
		const matching_variations =
			wc_variation_form_matcher.find_matching_variations(
				$product_variations,
				data
			);
		const variation = matching_variations.shift();

		if ( typeof variation.display_price !== 'undefined' ) {
			$totals.data( 'price', variation.display_price );
		} else if (
			$( variation.price_html ).find( '.amount' ).last().length
		) {
			let product_price = $( variation.price_html )
				.find( '.amount' )
				.last()
				.text();
			product_price = product_price.replace(
				woocommerce_addons_params.currency_format_symbol,
				''
			);
			product_price = product_price.replace(
				woocommerce_addons_params.currency_format_thousand_sep,
				''
			);
			product_price = product_price.replace(
				woocommerce_addons_params.currency_format_decimal_sep,
				'.'
			);
			product_price = product_price.replace( /[^0-9\.]/g, '' );
			product_price = parseFloat( product_price );

			$totals.data( 'price', product_price );
		}

		$( this ).trigger( 'woocommerce-product-addons-update' );
	} );
} );
