/* eslint camelcase: [2, { properties: "never", allow: ["woocommerce_addons_params"] }] */
( function ( $, window ) {
	const Validation = PaoValidation;

	// This script is not yet ready to be publicly stored in the window.
	WC_PAO = window.WC_PAO || {};

	WC_PAO.initialized_forms = [];

	WC_PAO.Helper = {
		/**
		 * Escapes HTML.
		 *
		 * @param {string} html HTML string.
		 * @return {string} Escaped HTML.
		 */
		escapeHtml( html ) {
			return document
				.createElement( 'div' )
				.appendChild( document.createTextNode( html ) ).parentNode
				.innerHTML;
		},

		/**
		 * Determines if a subscription is selected in a grouped product.
		 *
		 * @return {boolean} Whether a subscription is selected.
		 */
		isGroupedSubsSelected() {
			const group = $( '.product-type-grouped' );
			let subs = false;

			if ( group.length ) {
				group.find( '.group_table tr.product' ).each( function () {
					if ( $( this ).find( '.input-text.qty' ).val() > 0 ) {
						if (
							$( this ).find(
								'.entry-summary .subscription-details'
							).length
						) {
							subs = true;
							return false;
						}
					}
				} );
			}

			return subs;
		},

		/**
		 * Function to add minutes on a given Date object.
		 *
		 * @param {Date}   date    The Date object to be converted.
		 * @param {number} minutes Number of minutes.
		 * @return {Date} The new Date including added minutes.
		 */
		addMinutes( date, minutes ) {
			return new Date( date.getTime() + minutes * 60000 );
		},

		/**
		 * Determines if a product is a mixed or grouped product type.
		 *
		 * @return {boolean} Whether the group mixes product types.
		 */
		isGroupedMixedProductType() {
			const group = $( '.product-type-grouped' );
			let subs = 0,
				simple = 0;

			if ( group.length ) {
				group.find( '.group_table tr.product' ).each( function () {
					if ( $( this ).find( '.input-text.qty' ).val() > 0 ) {
						// For now only checking between simple and subs.
						if (
							$( this ).find(
								'.entry-summary .subscription-details'
							).length
						) {
							subs++;
						} else {
							simple++;
						}
					}
				} );

				if ( subs > 0 && simple > 0 ) {
					return true;
				}
			}

			return false;
		},

		/**
		 * Delays the execution of the callback function by ms.
		 *
		 * @param {Function} callback Callback to run.
		 * @param {number}   ms       Delay in milliseconds.
		 */
		delay( callback, ms ) {
			let timer = 0;

			clearTimeout( timer );
			timer = setTimeout( callback, ms );
		},
	};

	WC_PAO.Form = ( function () {
		/**
		 * Addons Form Controller.
		 *
		 * @param {jQuery} $form Add-ons form.
		 */
		function Form( $form ) {
			// Make sure is called as a constructor.
			if ( ! ( this instanceof Form ) ) {
				return new Form( $form );
			}

			if ( ! $form.length ) {
				return false;
			}

			// Holds the jQuery instance.
			this.$el = $form;
			this.$addons = this.$el.find( '.wc-pao-addon-field' );

			if ( ! this.$addons.length ) {
				this.$addons = false;
				return false;
			}

			this.is_rtl = document.documentElement.dir === 'rtl';
			this.validation = new Validation( this );
			// Function declaration is hoisted below the form methods.
			// eslint-disable-next-line @typescript-eslint/no-use-before-define
			this.totals = new Totals( this );
			this.show_incomplete_subtotals =
				this.totals.showIncompleteSubtotals();
			this.contains_required = this.containsRequired();

			this.setupEvents();

			this.validation.validate();
			this.updateTotals();

			// jQuery TipTip is enqueued as a dependency, but plugins / theme
			// JS optimizers can dequeue or fail to load it. Guard the call so
			// missing TipTip degrades gracefully instead of throwing
			// "$(...).tipTip is not a function" on product pages.
			if ( typeof $.fn.tipTip === 'function' ) {
				$( '.wc-pao-addon-image-swatch' ).tipTip( { delay: 200 } );
			}

			WC_PAO.initialized_forms.push( this );
		}

		/**
		 * Sets up event listeners.
		 */
		Form.prototype.setupEvents = function () {
			// Event callbacks need the form controller context.
			// eslint-disable-next-line @typescript-eslint/no-this-alias
			const self = this;

			// Validate addons on form submit.
			self.$el.find( 'button[type="submit"]' ).on( 'click', function () {
				if ( self.validation.validate( true ) ) {
					return true;
				}

				// Focus on the invalid field or error message.
				const $messages = self.$el.find( '.wc-pao-validation-notice' );

				if ( $messages.length ) {
					const $firstInvalidAddon = self.$el.find(
						$messages[ 0 ].closest( '.wc-pao-addon-container' )
					);

					if ( $firstInvalidAddon.length ) {
						const $invalidField = $firstInvalidAddon
							.find( '.wc-pao-addon-field' )
							.first();

						if ( $invalidField.length ) {
							// If the invalid field is hidden (ie image swatch), focus on the message, otherwise focus on the field itself.
							// No need to scroll the viewport, as when focusing on the message, the viewport will scroll to the field.
							if ( $invalidField.is( ':hidden' ) ) {
								$( $messages[ 0 ] ).focus();
							} else {
								$invalidField.focus();
							}
						}
					}
				}

				return false;
			} );

			/**
			 * Addons value changed.
			 */
			self.$el.on(
				'blur change',
				'.wc-pao-addon input:not(.wc-pao-addon-file-upload), .wc-pao-addon textarea, .wc-pao-addon select, .wc-pao-addon-custom-text',
				function ( e ) {
					if ( $( this ).is( '.wc-pao-addon-checkbox' ) ) {
						const $currentParent =
								$( this ).closest( '.wc-pao-fieldset' ),
							$nextParent = $( e.relatedTarget ).closest(
								'.wc-pao-fieldset'
							);
						if ( $currentParent.is( $nextParent ) ) {
							// We only want to validate when leaving the fieldset, not when tabbing over checkbox options.
							return;
						}
					}

					self.validation.validateAddon( $( this ), true );
					self.updateTotals();
				}
			);

			// Treat file fields slightly differently since they can have reset links.
			self.$el.on(
				'change',
				'.wc-pao-addon input.wc-pao-addon-file-upload',
				function () {
					const $this = $( this );
					const $parent = $this.closest( '.wc-pao-addon-container' );
					const $reset = $parent.find( '.reset_file' );
					const $selectedFile = $parent.find(
						'.wc-pao-addon-file-name'
					);

					// When a new file is uploaded, reveal the reset button.
					if ( $reset.length ) {
						$reset.addClass( 'active' );
					}

					// When the add-on field is pre-populated from a cart item, the selected file is displayed
					// as a note below the input. When a new file is selected, clear the selected file name.
					if ( $selectedFile.length ) {
						$selectedFile.hide( 250, function () {
							// Remove note with the name of the selected file.
							$( this ).remove();

							// Clear the file upload input field.
							$this.data( 'value', '' );
						} );
					}

					self.validation.validateAddon( $this, true );
					self.updateTotals();
				}
			);

			// The input event only fires when the actual value changes, not on every key press.
			self.$el.on(
				'input',
				'.wc-pao-addon input:not(.wc-pao-addon-checkbox), .wc-pao-addon textarea, .wc-pao-addon-custom-text',
				function () {
					const $addon = $( this );

					WC_PAO.Helper.delay( function () {
						self.validation.validateAddon( $addon, true );
						self.updateTotals();
					}, 300 );
				}
			);

			// Loading bar state for addons updates. //appointments
			self.$el.on( 'updated_addons', function () {
				const $total = self.$el.find( '#product-addons-total' );
				if ( $total.length ) {
					$total.find( '.wca-loading-bar' ).removeClass( 'is-active' );
				}
			} );

			// Product quantity changed.
			self.$el.on( 'change', 'input.qty', function () {
				self.updateTotals();
			} );

			// Special handling for image swatches.
			// When a user clicks on an image swatch, the selection is transferred to a hidden select element.
			let touchTime;

			self.$el.on(
				'touchstart',
				'.wc-pao-addon-image-swatch',
				function () {
					touchTime = new Date();
				}
			);

			self.$el.on(
				'click touchend',
				'.wc-pao-addon-image-swatch',
				function ( e ) {
					e.preventDefault();

					if ( e.type === 'touchend' && touchTime ) {
						const diff = new Date() - touchTime;

						if ( diff > 100 ) {
							// This is a scroll event and not a tap, so skip.
							return;
						}
					}

					self.updateImageSwatch( $( this ) );
				}
			);

			self.$el.on(
				'keydown',
				'.wc-pao-addon-image-swatch',
				function ( e ) {
					const $current = $( this ),
						$parent = $current.parents( '.wc-pao-addon-wrap' ),
						$swatches = $parent.find(
							'.wc-pao-addon-image-swatch'
						);
					let idx = $swatches.index( $current ),
						handled = false;

					if ( e.key === 'ArrowRight' || e.key === 'ArrowDown' ) {
						idx = ( idx + 1 ) % $swatches.length;
						handled = true;
					} else if ( e.key === 'ArrowLeft' || e.key === 'ArrowUp' ) {
						idx = ( idx - 1 + $swatches.length ) % $swatches.length;
						handled = true;
					} else if ( e.key === ' ' || e.key === 'Enter' ) {
						self.updateImageSwatch( $current );
						return;
					}

					if ( handled ) {
						e.preventDefault();
						const $nextSwatch = $swatches.eq( idx );
						$nextSwatch.focus();
						self.updateImageSwatch( $nextSwatch );
					}
				}
			);

			/**
			 * Variable Products.
			 */

			// Reset addon totals when the variation selection is cleared. The form is not valid until a variation is selected.
			self.$el.on( 'click', '.reset_variations', function () {
				self.totals.reset();
			} );

			// When the variation form initially loads.
			self.$el.on( 'wc_variation_form', function () {
				self.validation.validate();
				self.updateTotals();
			} );

			// When a new variation is selected, validate the form and update the addons totals.
			self.$el.on( 'found_variation', function ( event, variation ) {
				self.totals.updateVariation( variation );
				self.validation.validate();
				self.updateTotals();
			} );

			// When a variation selection is cleared by selecting "Choose an option...", reset totals as the form becomes invalid.
			self.$el.on( 'hide_variation', function () {
				self.updateTotals();
			} );

			self.$el.on( 'woocommerce-product-addons-update', function () {
				self.validation.validate();
				self.updateTotals();
			} );

			/**
			 * Add-ons Datepicker extend.
			 */
			const $datepickers = self.$el.find( '.datepicker' );

			$datepickers.each( function () {
				// Cache local instances.
				const $datepicker = $( this ),
					$container = $datepicker.parent(),
					$clearButton = $container.find( '.reset_date' ),
					$timestampInput = $container.find(
						'input[name="' +
							$datepicker.attr( 'name' ) +
							'-wc-pao-date"]'
					);
				let $offsetGmtInput = $container.find(
					'input[name="' +
						$datepicker.attr( 'name' ) +
						'-wc-pao-date-gmt-offset"]'
				);

				// Make Template backwards compatible.
				if ( ! $offsetGmtInput.length ) {
					$offsetGmtInput = $( '<input/>' );
					$offsetGmtInput.attr( 'type', 'hidden' );
					$offsetGmtInput.attr(
						'name',
						$datepicker.attr( 'name' ) + '-wc-pao-date-gmt-offset'
					);
					$container.append( $offsetGmtInput );
				}

				// Fill GMT offset.
				const now = new Date(),
					gmtOffset = parseFloat(
						woocommerce_addons_params.gmt_offset,
						10
					),
					clientOffset = now.getTimezoneOffset() / 60;

				if (
					woocommerce_addons_params.date_input_timezone_reference ===
					'default'
				) {
					$offsetGmtInput.val( clientOffset );
				} else if (
					woocommerce_addons_params.date_input_timezone_reference ===
					'store'
				) {
					$offsetGmtInput.val( gmtOffset );
				}

				// Init datepicker.
				$datepicker.datepicker( {
					beforeShow() {
						if ( woocommerce_addons_params.datepicker_class ) {
							$( '#ui-datepicker-div' ).removeClass(
								woocommerce_addons_params.datepicker_class
							);
							$( '#ui-datepicker-div' ).addClass(
								woocommerce_addons_params.datepicker_class
							);
						}
					},
					dateFormat:
						woocommerce_addons_params.datepicker_date_format,
					changeMonth: true,
					changeYear: true,
					yearRange: 'c-100:c+10',
				} );

				// Fill hidden inputs with selected date if any.
				let currentDate = $datepicker.datepicker( 'getDate' );
				if (
					currentDate !== null &&
					typeof currentDate.getTime === 'function'
				) {
					// Append current time.
					currentDate.setHours( now.getHours(), now.getMinutes() );

					if (
						woocommerce_addons_params.date_input_timezone_reference ===
						'store'
					) {
						currentDate = WC_PAO.Helper.addMinutes(
							currentDate,
							-1 * clientOffset * 60
						);
						currentDate = WC_PAO.Helper.addMinutes(
							currentDate,
							gmtOffset * 60
						);
					}

					$timestampInput.val( currentDate.getTime() / 1000 );
					$clearButton.show();
				}

				// On Change.
				$datepicker.on( 'change', function () {
					let selectedDate = $datepicker.datepicker( 'getDate' );
					if (
						selectedDate !== null &&
						typeof selectedDate.getTime === 'function'
					) {
						// Append current time.
						const currentTime = new Date();
						selectedDate.setHours(
							currentTime.getHours(),
							currentTime.getMinutes()
						);

						if (
							woocommerce_addons_params.date_input_timezone_reference ===
							'store'
						) {
							selectedDate = WC_PAO.Helper.addMinutes(
								selectedDate,
								-1 * clientOffset * 60
							);
							selectedDate = WC_PAO.Helper.addMinutes(
								selectedDate,
								gmtOffset * 60
							);
						}

						$timestampInput.val( selectedDate.getTime() / 1000 );
						$clearButton.show();
					} else {
						$clearButton.hide();
						$timestampInput.val( '' );
					}
				} );

				// On clear date.
				$clearButton.on( 'click', function ( event ) {
					event.preventDefault();
					// Sanity clear.
					$timestampInput.val( '' );
					// Trigger change.
					$datepicker.val( '' ).trigger( 'change' );
				} );
			} );

			self.$el.on( 'click', '.reset_file', function ( e ) {
				e.preventDefault();
				const $parent = $( this ).closest( '.wc-pao-addon-container' );
				const $fileField = $parent.find( 'input.wc-pao-addon-field' );
				const $selectedFile = $parent.find( '.wc-pao-addon-file-name' );

				// When the add-on field is pre-populated from a cart item, the selected file is displayed
				// as a note below the input. When the reset link is clicked, also clear the selected file name.
				if ( $selectedFile.length ) {
					$selectedFile.hide( 250, function () {
						// Remove note with the name of the selected file.
						$( this ).remove();
					} );
				}

				// Remove the reset link.
				$( this ).removeClass( 'active' ).addClass( 'inactive' );

				// Clear the file upload input.
				$fileField.data( 'value', '' );
				$fileField.val( '' );

				// Validate add-on and re-calculate totals.
				self.validation.validateAddon( $fileField, true );
				self.updateTotals();
			} );

			/**
			 * Integrations.
			 */

			// Compatibility with Smart Coupons self declared gift amount purchase.
			//
			// CAUTION: This code is unstable.
			$( '#credit_called' ).on( 'keyup', function () {
				self.validation.validate();
				self.updateTotals();
			} );
		};

		Form.prototype.updateImageSwatch = function ( $swatch ) {
			const selectedValue = $swatch.data( 'value' ),
				$parent = $swatch.parents( '.wc-pao-addon-wrap' ),
				label = $.parseHTML( $swatch.data( 'price' ) ),
				$selected = $parent.find(
					'.wc-pao-addon-image-swatch-selected-swatch'
				);

			// Clear selected swatch.
			$selected.html( '' );

			// Clear all selected.
			$parent
				.find( '.wc-pao-addon-image-swatch' )
				.removeClass( 'selected' )
				.attr( 'aria-checked', 'false' )
				.attr( 'tabindex', '-1' );

			// Select this swatch.
			$swatch
				.addClass( 'selected' )
				.attr( 'aria-checked', 'true' )
				.attr( 'tabindex', '0' );

			// Set the value in hidden select field.
			$parent
				.find( '.wc-pao-addon-image-swatch-select' )
				.val( selectedValue );

			// Display selected label below swatches.
			$selected.html( label );

			this.validation.validateAddon(
				$parent.find( 'select.wc-pao-addon-field' ),
				true
			);
			this.updateTotals();
		};

		/**
		 * Updates addons totals if the form is valid or resets them otherwise.
		 */
		Form.prototype.updateTotals = function () {
			this.totals.calculate();

			// Hide totals the product contains only optional items and none have been selected or when the form is invalid.
			const displayTotals =
				( this.show_incomplete_subtotals || this.isValid() ) &&
				( this.contains_required ||
					this.totals.$totals.data( 'price_data' ).length );

			if ( displayTotals ) {
				this.totals.render();
			} else {
				this.totals.reset();
			}
		};

		/**
		 * Determines if the form is valid.
		 *
		 * @return {boolean} Whether the form is valid.
		 */
		Form.prototype.isValid = function () {
			const $addToCartButton = this.$el.find(
				'button.single_add_to_cart_button'
			);
			let valid = true;

			if ( $addToCartButton.is( '.disabled' ) ) {
				valid = false;
				return valid;
			}

			$.each( this.validation.getValidationState(), function () {
				if ( ! this.validity ) {
					valid = false;
					return false;
				}
			} );

			return valid;
		};

		/**
		 * Determines if the product contains required add-ons
		 *
		 * @return {boolean} Whether the form has required add-ons.
		 */
		Form.prototype.containsRequired = function () {
			let containsRequired = false;

			this.$addons.each( function () {
				const validationRules = $( this ).data( 'restrictions' );

				if ( ! $.isEmptyObject( validationRules ) ) {
					if ( 'required' in validationRules ) {
						if ( validationRules.required === 'yes' ) {
							return ( containsRequired = true );
						}
					}
				}
			} );

			return containsRequired;
		};

		/**
		 * Addons Totals Controller.
		 *
		 * @param {Object} formController Add-ons form controller.
		 */
		function Totals( formController ) {
			// Make sure is called as a constructor.
			if ( ! ( this instanceof Totals ) ) {
				return new Totals( formController );
			}

			if ( $.isEmptyObject( formController ) ) {
				return false;
			}

			// Holds the jQuery instance.
			this.$form = formController.$el;
			this.$addons = formController.$addons;

			// Parameters.
			this.$variation_input = this.$form.hasClass( 'variations_form' )
				? this.$form.find(
						'input[name="variation_id"], input.variation_id'
				  )
				: false;
			this.is_variable =
				this.$variation_input && this.$variation_input.length > 0;
			this.$totals = this.$form.find( '#product-addons-total' );
			this.product_id = this.is_variable
				? this.$variation_input.val()
				: this.$totals.data( 'product-id' );

			if ( ! this.product_id ) {
				return false;
			}

			// The product base price. For Variable Products, this is the minimum variation price.
			this.base_price = this.$totals.data( 'price' );
			this.raw_price = this.$totals.data( 'raw-price' );
			this.product_type = this.$totals.data( 'type' );
			this.qty = parseFloat( this.$form.find( 'input.qty' ).val() );
			this.addons_price_data = [];
			this.$subscription_plans = this.$form.find(
				'.wcsatt-options-product'
			);
			this.has_subscription_plans = this.$subscription_plans.length > 0;
			this.is_rtl = formController.is_rtl;
			this.total = 0;
			this.total_raw = 0;
			this.show_subtotal_panel = true;
			this.price_request = null;
		}

		/**
		 * Determines if addons subtotals should be visible even if validation fails.
		 *
		 * @return {boolean} Whether incomplete subtotals should show.
		 */
		Totals.prototype.showIncompleteSubtotals = function () {
			return this.$totals.data( 'show-incomplete-sub-total' ) === 1;
		};

		/**
		 * Update addon totals when a new variation is selected.
		 *
		 * @param {Object} variation Selected variation.
		 */
		Totals.prototype.updateVariation = function ( variation ) {
			// Handle multiple variation dropdowns in a single form -- for example, a Bundle with many Variable bundled items.
			this.$variation_input = this.$form.hasClass( 'variations_form' )
				? this.$form.find(
						'input[name="variation_id"], input.variation_id'
				  )
				: false;
			this.product_id = variation.variation_id;

			this.$totals.data( 'product-id', this.product_id );

			if ( typeof variation.display_price !== 'undefined' ) {
				this.base_price = variation.display_price;
			} else if (
				$( variation.price_html ).find( '.amount' ).last().length
			) {
				this.base_price = $( variation.price_html )
					.find( '.amount' )
					.last()
					.text();

				this.base_price = this.base_price.replace(
					woocommerce_addons_params.currency_format_symbol,
					''
				);

				this.base_price = this.base_price.replace(
					woocommerce_addons_params.currency_format_thousand_sep,
					''
				);

				this.base_price = this.base_price.replace(
					woocommerce_addons_params.currency_format_decimal_sep,
					'.'
				);

				this.base_price = this.base_price.replace( /[^0-9\.]/g, '' );
				this.base_price = parseFloat( this.base_price );
			}

			this.$totals.data( 'price', this.base_price );
		};

		/**
		 * Calculates addon totals based on configured addons.
		 */
		Totals.prototype.calculate = function () {
			// Nested add-on callbacks need the totals controller context.
			// eslint-disable-next-line @typescript-eslint/no-this-alias
			const self = this;

			self.qty = parseFloat( self.$form.find( 'input.qty' ).val() );
			self.addons_price_data = [];
			self.total = 0;
			self.total_raw = 0;
			self.base_price = self.$totals.data( 'price' );
			self.raw_price = self.$totals.data( 'raw-price' );
			self.product_id = self.is_variable
				? self.$variation_input.val()
				: self.$totals.data( 'product-id' );

			/**
			 * Compatibility with Smart Coupons self declared gift amount purchase.
			 *
			 * CAUTION: This code is unstable.
			 * A dedicated Smart Coupons event should be used to change the base price based on the gift card amount.
			 */
			const customGiftCardAmount = window.custom_gift_card_amount;
			if (
				self.base_price === '' &&
				customGiftCardAmount &&
				customGiftCardAmount.length &&
				customGiftCardAmount.val() > 0
			) {
				self.base_price = customGiftCardAmount.val();
			}

			/**
			 * Compatibility with Bookings.
			 *
			 * CAUTION: This code is unstable.
			 * A dedicated Bookings event should be used to change the base price based on the bookings cost.
			 */
			if (
				woocommerce_addons_params.is_bookings &&
				$( '.wc-bookings-booking-cost' ).length
			) {
				self.base_price = parseFloat(
					$( '.wc-bookings-booking-cost' ).attr( 'data-raw-price' )
				);
			}

			/**
			 * Calculates totals of selected addons.
			 *
			 */
			this.$addons.each( function () {
				const $addon = $( this ),
					parentContainer = $addon.parents( '.wc-pao-addon' );

				if (
					( $addon.is( '.wc-pao-addon-file-upload' ) &&
						parentContainer.find( '.wc-pao-addon-file-name input' )
							.length &&
						! parentContainer
							.find( '.wc-pao-addon-file-name input' )
							.val() ) ||
					( ! (
						$addon.is( '.wc-pao-addon-file-upload' ) &&
						parentContainer.find( '.wc-pao-addon-file-name input' )
							.length
					) &&
						! $addon.val() )
				) {
					return;
				}

				const name = parentContainer.find( '.wc-pao-addon-name' ).length
						? parentContainer
								.find( '.wc-pao-addon-name' )
								.data( 'addon-name' )
						: '',
					addonData = {},
					hasPerPersonPricing = parentContainer.find(
						'.wc-pao-addon-name'
					).length
						? parentContainer
								.find( '.wc-pao-addon-name' )
								.data( 'has-per-person-pricing' )
						: false,
					hasPerBlockPricing = parentContainer.find(
						'.wc-pao-addon-name'
					).length
						? parentContainer
								.find( '.wc-pao-addon-name' )
								.data( 'has-per-block-pricing' )
						: false;
				let valueLabel = '',
					addonCost = 0,
					addonCostRaw = 0,
					priceType = $addon.data( 'price-type' ),
					addonDuration = 0, //appointments
					addonDurationRaw = 0, //appointments
					durationType = $addon.data( 'duration-type' ), //appointments
					isCustomPrice = false;

				if ( $addon.is( '.wc-pao-addon-custom-price' ) ) {
					isCustomPrice = true;
					addonCost = $addon.val();
					addonCostRaw = $addon.val();
					priceType = 'quantity_based';

					// Replace decimal separator with '.', as parseFloat rejects decimals with comma.
					if (
						woocommerce_addons_params.currency_format_decimal_sep !==
						'.'
					) {
						addonCost = addonCost.replace(
							woocommerce_addons_params.currency_format_decimal_sep,
							'.'
						);
						addonCostRaw = addonCostRaw.replace(
							woocommerce_addons_params.currency_format_decimal_sep,
							'.'
						);
					}
				} else if ( $addon.is( '.wc-pao-addon-input-multiplier' ) ) {
					// Avoid converting empty strings to 0.
					if ( $addon.val() !== '' ) {
						$addon.val( Math.ceil( $addon.val() ) );

						addonCost = $addon.data( 'price' ) * $addon.val();
						addonCostRaw =
							$addon.data( 'raw-price' ) * $addon.val();
						addonDuration =
							$addon.data( 'duration' ) * $addon.val(); //appointments
						addonDurationRaw =
							$addon.data( 'raw-duration' ) * $addon.val(); //appointments
					}
				} else if (
					$addon.is( '.wc-pao-addon-checkbox, .wc-pao-addon-radio' )
				) {
					if ( ! $addon.is( ':checked' ) ) {
						return;
					}

					valueLabel = $addon.data( 'label' );
					addonCost = $addon.data( 'price' );
					addonCostRaw = $addon.data( 'raw-price' );
					addonDuration = $addon.data( 'duration' ); //appointments
					addonDurationRaw = $addon.data( 'raw-duration' ); //appointments
				} else if (
					$addon.is(
						'.wc-pao-addon-image-swatch-select, .wc-pao-addon-select'
					)
				) {
					if (
						! $addon.find( 'option:selected' ) ||
						$addon.find( 'option:selected' ).val() === ''
					) {
						return;
					}

					priceType = $addon
						.find( 'option:selected' )
						.data( 'price-type' );
					durationType = $addon
						.find( 'option:selected' )
						.data( 'duration-type' ); //appointments
					valueLabel = $addon
						.find( 'option:selected' )
						.data( 'label' );
					addonCost = $addon
						.find( 'option:selected' )
						.data( 'price' );
					addonCostRaw = $addon
						.find( 'option:selected' )
						.data( 'raw-price' );
					addonDuration = $addon
						.find( 'option:selected' )
						.data( 'duration' ); //appointments
					addonDurationRaw = $addon
						.find( 'option:selected' )
						.data( 'raw-duration' ); //appointments
				} else if ( $addon.is( '.wc-pao-addon-file-upload' ) ) {
					addonCost = $addon.data( 'price' );
					addonCostRaw = $addon.data( 'raw-price' );
				} else {
					if ( ! $addon.val() ) {
						return;
					}

					addonCost = $addon.data( 'price' );
					addonCostRaw = $addon.data( 'raw-price' );
					addonDuration = $addon.data( 'duration' ); //appointments
					addonDurationRaw = $addon.data( 'raw-duration' ); //appointments
				}

				if ( ! addonCost ) {
					addonCost = 0;
				}
				if ( ! addonCostRaw ) {
					addonCostRaw = 0;
				}
				if ( ! addonDuration ) {
					//appointments
					addonDuration = 0;
				}
				if ( ! addonDurationRaw ) {
					//appointments
					addonDurationRaw = 0;
				}

				/**
				 * Compatibility with Bookings.
				 *
				 * CAUTION: This code is unstable.
				 * A dedicated Bookings/Accomodation Bookings event should be used to change the base price based on the bookings duration, persons and cost.
				 */
				if (
					( self.product_type === 'booking' ||
						self.product_type === 'accommodation-booking' ) &&
					woocommerce_addons_params.is_bookings
				) {
					self.qty = 0;

					// Duration field.
					let blockQty = 0;
					if (
						typeof $( '#wc_bookings_field_duration' ) !==
							'undefined' &&
						$( '#wc_bookings_field_duration' ).val() > 0
					) {
						blockQty = $( '#wc_bookings_field_duration' ).val();
					}

					// Duration fields with start and end time.
					if (
						typeof $( '#wc-bookings-form-end-time' ) !==
							'undefined' &&
						$( '#wc-bookings-form-end-time' ).val() > 0
					) {
						blockQty = $( '#wc-bookings-form-end-time' ).val();
					}

					// Persons field(s).
					const singlePersonsInput = $(
						'#wc_bookings_field_persons'
					);
					let personQty = 0;

					if ( singlePersonsInput.length === 1 ) {
						// Persons field when person types is disabled.
						personQty =
							parseInt( personQty, 10 ) +
							parseInt( singlePersonsInput.val(), 10 );
					} else {
						// Persons fields for multiple person types.
						$( '.wc-bookings-booking-form' )
							.find( 'input' )
							.each( function () {
								// There could be more than one persons field.
								const field = this.id.match(
									/wc_bookings_field_persons_(\d+)/
								);

								if (
									field !== null &&
									typeof field !== 'undefined' &&
									$( '#' + field[ 0 ] ).length
								) {
									personQty =
										parseInt( personQty, 10 ) +
										parseInt(
											$( '#' + field[ 0 ] ).val(),
											10
										);
								}
							} );
					}

					if (
						self.qty === 0 &&
						$( '.wc-bookings-booking-cost' ).length
					) {
						self.qty = 1;
					}

					// Apply person/block quantities.
					if ( hasPerPersonPricing && personQty ) {
						self.qty *= personQty;
					}
					if ( hasPerBlockPricing && blockQty ) {
						self.qty *= blockQty;
					}
				}

				// Format addon totals based on their type.
				switch ( priceType ) {
					case 'flat_fee':
						addonData.cost = parseFloat( addonCost );
						addonData.cost_raw = parseFloat( addonCostRaw );
						break;
					case 'quantity_based':
						addonData.cost_pu = parseFloat( addonCost );
						addonData.cost_raw_pu = parseFloat( addonCostRaw );
						addonData.cost = addonData.cost_pu * self.qty;
						addonData.cost_raw = addonData.cost_raw_pu * self.qty;
						break;
					case 'percentage_based':
						addonData.cost_pct = parseFloat( addonCost ) / 100;
						addonData.cost_raw_pct =
							parseFloat( addonCostRaw ) / 100;
						addonData.cost =
							parseFloat( self.base_price ) *
							addonData.cost_pct *
							self.qty;
						addonData.cost_raw =
							parseFloat( self.raw_price ) *
							addonData.cost_raw_pct *
							self.qty;
						break;
				}

				self.total += addonData.cost || 0;
				self.total_raw += addonData.cost_raw || 0;

				switch ( durationType ) {
					//appointments
					case 'flat_time':
					case '':
						addonData.duration = addonDurationRaw;
						addonData.duration_raw = addonDurationRaw;
						break;
					case 'quantity_based':
						addonData.duration_pu = addonDurationRaw;
						addonData.duration_raw_pu = addonDurationRaw;
						addonData.duration =
							addonData.duration_pu * self.qty;
						addonData.duration_raw =
							addonData.duration_raw_pu * self.qty;
						break;
				}

				/**
				 * Formats addon names to include user input.
				 * The formatted addon name will be displayed in the addons subtotal table.
				 */
				if ( typeof valueLabel !== 'undefined' ) {
					if ( typeof valueLabel === 'number' || valueLabel.length ) {
						addonData.name =
							name + ( valueLabel ? ' - ' + valueLabel : '' );

						addonData.nameFormattedHTML =
							'<span class="wc-pao-addon-name">' +
							name +
							'</span>' +
							( valueLabel
								? ' - ' +
								  '<span class="wc-pao-addon-value">' +
								  valueLabel +
								  '</span>'
								: '' );
					} else {
						const trimCharacters = parseInt(
							woocommerce_addons_params.trim_user_input_characters,
							10
						);
						let userInput = $addon.val();

						// Check if type is file upload.
						if ( $addon.is( '.wc-pao-addon-file-upload' ) ) {
							if (
								parentContainer.find(
									'.wc-pao-addon-file-name'
								).length
							) {
								userInput = parentContainer
									.find( '.wc-pao-addon-file-name' )
									.data( 'value' );
							}
							userInput = userInput.replace( /^.*[\\\/]/, '' );
						} else if (
							$addon.is( '.wc-pao-addon-custom-price' )
						) {
							// Replace decimal separator with '.', as formatMoney expects decimals with '.'.
							if (
								woocommerce_addons_params.currency_format_decimal_sep !==
								'.'
							) {
								userInput = userInput.replace(
									woocommerce_addons_params.currency_format_decimal_sep,
									'.'
								);
							}

							userInput = accounting.formatNumber( userInput, {
								symbol: '',
								decimal:
									woocommerce_addons_params.currency_format_decimal_sep,
								precision:
									parseFloat( userInput ) % 1 === 0
										? 0
										: userInput.toString().split( '.' )[ 1 ]
												.length,
							} );
						}

						if ( trimCharacters < userInput.length ) {
							userInput =
								userInput.slice( 0, trimCharacters ) + '...';
						}

						addonData.name =
							name +
							' - ' +
							WC_PAO.Helper.escapeHtml( userInput );

						addonData.nameFormattedHTML =
							'<span class="wc-pao-addon-name">' +
							name +
							'</span>' +
							' - ' +
							'<span class="wc-pao-addon-value">' +
							WC_PAO.Helper.escapeHtml( userInput ) +
							'</span>';
					}

					addonData.is_custom_price = isCustomPrice;
					addonData.price_type = priceType;
					addonData.duration_type = durationType; //appointments

					self.addons_price_data.push( addonData );
				}
			} );

			// Save prices for 3rd party access.
			self.$totals.data( 'price_data', self.addons_price_data );

			// Add loading bar. //appointments
			if ( ! self.$totals.find( '.wca-loading-bar' ).length ) {
				self.$totals.append( '<div class="wca-loading-bar"></div>' );
			}
			self.$totals.find( '.wca-loading-bar' ).addClass( 'is-active' );

			self.$form.trigger( 'updated_addons' );
		};

		/**
		 * Renders addon totals.
		 */
		Totals.prototype.render = function () {
			// Nested rendering callbacks need the totals controller context.
			// eslint-disable-next-line @typescript-eslint/no-this-alias
			const self = this;

			// Early exit if another plugin has determined that Product Addon totals should remain hidden.
			if ( ! self.$totals.data( 'show-sub-total' ) ) {
				self.$totals.empty();
				self.$form.trigger( 'updated_addons' );
				return;
			}

			if ( self.qty ) {
				let productTotalPrice,
					formattedSubTotal,
					$subscriptionDetails,
					subscriptionDetailsHtml,
					html,
					hasCustomPriceWithTaxes = false;

				if (
					typeof self.base_price !== 'undefined' &&
					self.product_id
				) {
					// If it is a bookable product.
					if ( $( '.wc-bookings-booking-form' ).length ) {
						productTotalPrice = ! isNaN( self.base_price )
							? parseFloat( self.base_price )
							: 0;
					} else if (
						$( '.wc-appointments-appointment-cost' ).length
					) {
						//appointments
						productTotalPrice = ! isNaN( self.base_price )
							? parseFloat( self.base_price )
							: 0;
					} else {
						productTotalPrice = parseFloat(
							self.base_price * self.qty
						);
					}

					const hideProductLine = !! self.$totals.data(
						'hide-product-price'
					); //appointments
					formattedSubTotal = hideProductLine
						? self.formatMoney( self.total )
						: self.formatMoney(
								productTotalPrice + self.total
						  );
				}

				/**
				 * Compatibility with Subscribe All The Things/All Products for WooCommerce Subscriptions.
				 *
				 * CAUTION: This code is unstable.
				 * An All Products for WooCommerce Subscriptions specific event should be used to get
				 * subscription details when a new subscription plan is selected.
				 */
				if ( self.has_subscription_plans ) {
					const satt = self.$form.data( 'satt_script' );

					if ( satt && satt.schemes_model.get_active_scheme_key() ) {
						const $selectedPlan =
							self.$subscription_plans.find( 'input:checked' );

						if ( $selectedPlan.val() ) {
							$subscriptionDetails = $selectedPlan
								.parent()
								.find( '.subscription-details' );
						}
					}
				} else if (
					self.$form.parent().find( '.subscription-details' ).length
				) {
					// Add-Ons added at bundle level only affect the up-front price.
					if ( ! self.$form.hasClass( 'bundle_data' ) ) {
						$subscriptionDetails = self.$form
							.parent()
							.find( '.subscription-details' );

						/*
						 * Check if product is a variable
						 * because the subscription_details HTML element will
						 * be located in different area.
						 */
						if (
							self.$variation_input &&
							self.$variation_input.length > 0
						) {
							$subscriptionDetails = self.$form
								.parent()
								.find(
									'.woocommerce-variation .subscription-details'
								);
						}
					}
				}

				if ( $subscriptionDetails && $subscriptionDetails.length > 0 ) {
					// Space is needed here in some cases.
					subscriptionDetailsHtml =
						' ' +
						$subscriptionDetails
							.clone()
							.wrap( '<p>' )
							.parent()
							.html();
				}

				/**
				 * Compatibility with Grouped and subscription products.
				 *
				 * CAUTION: This code is unstable.
				 * This code needs to be moved to a grouped/subscription-specific function.
				 */
				if ( self.product_type === 'grouped' ) {
					if (
						subscriptionDetailsHtml &&
						! WC_PAO.Helper.isGroupedMixedProductType() &&
						WC_PAO.Helper.isGroupedSubsSelected()
					) {
						if ( formattedSubTotal ) {
							formattedSubTotal += subscriptionDetailsHtml;
						}
					}
				} else if ( subscriptionDetailsHtml ) {
					if ( formattedSubTotal ) {
						formattedSubTotal += subscriptionDetailsHtml;
					}
				}

				/**
				 * Render addon subtotals in a table-like format above the Add to Cart button.
				 * As the first line item, display the main product followed by each total price (base price * quantity).
				 * Then, display one line item for each selected addon followed by each price (given that one exists).
				 */
				if ( formattedSubTotal ) {
					const productName = self.$form
							.find( '.wc-pao-addon-container' )
							.data( 'product-name' ),
						productPrice = self.formatMoney( productTotalPrice ),
						productTaxStatus = self.$form
							.find( '.wc-pao-addon-container' )
							.data( 'product-tax-status' ),
						hideProductLine = !! self.$totals.data(
							'hide-product-price'
						); //appointments

					/**
					 * Bookings compatibility code.
					 *
					 * CAUTION: This code is unstable.
					 * This code does not change addon totals for booking products if the form is right to left.
					 */
					if ( hideProductLine ) {
						//appointments
						// Start totals without the base product line.
						html = '<div class="product-addon-totals"><ul>';
					} else if ( $( '.wc-bookings-booking-form' ).length ) {
						html =
							'<div class="product-addon-totals"><ul><li><div class="wc-pao-col1"><strong>' +
							productName +
							'</strong></div><div class="wc-pao-col2"><strong><span class="amount">' +
							productPrice +
							'</span></strong></div></li>';
					} else {
						// Display the base product as the first line item in the addons subtotals table.
						const quantityString = self.is_rtl
							? woocommerce_addons_params.quantity_symbol +
							  self.qty
							: self.qty +
							  woocommerce_addons_params.quantity_symbol;

						html =
							'<div class="product-addon-totals"><ul><li><div class="wc-pao-col1"><strong><span>' +
							quantityString +
							'</span> ' +
							productName +
							'</strong></div><div class="wc-pao-col2"><strong><span class="amount">' +
							productPrice +
							'</span></strong></div></li>';
					}

					if ( self.addons_price_data.length ) {
						$.each( self.addons_price_data, function ( i, addon ) {
							const cost = addon.cost;
							let formattedValue;

							if ( cost === 0 ) {
								formattedValue = '-';
							} else if ( cost > 0 ) {
								formattedValue = self.formatMoney( cost );
							} else {
								formattedValue =
									'-' + self.formatMoney( Math.abs( cost ) );
							}

							html =
								html +
								'<li><div class="wc-pao-col1"><strong>' +
								addon.nameFormattedHTML +
								'</strong></div><div class="wc-pao-col2"><span class="amount">' +
								formattedValue +
								'</span></div></li>';

							if (
								woocommerce_addons_params.tax_enabled &&
								addon.is_custom_price
							) {
								hasCustomPriceWithTaxes = true;
							}
						} );
					}

					// To show our "price display suffix" we have to do some magic since the string can contain variables (excl/incl tax values)
					// so we have to take our sub total and find out what the tax value is, which we can do via an ajax call
					// if its a simple string, or no string at all, we can output the string without an extra call
					const subTotalString =
						typeof self.$totals.data( 'i18n_sub_total' ) ===
						'undefined'
							? woocommerce_addons_params.i18n_sub_total
							: self.$totals.data( 'i18n_sub_total' );
					let priceDisplaySuffix = '';

					// No suffix is present, so we can just output the total.
					if (
						! hasCustomPriceWithTaxes &&
						( ! woocommerce_addons_params.price_display_suffix ||
							! woocommerce_addons_params.tax_enabled )
					) {
						html =
							html +
							'<li class="wc-pao-subtotal-line"><p class="price">' +
							subTotalString +
							' <span class="amount">' +
							formattedSubTotal +
							'</span></p></li></ul></div>';

						if ( self.show_subtotal_panel ) {
							self.$totals.html( html );
						} else {
							self.$totals.html( '' );
						}

						self.$form.trigger( 'updated_addons' );
						return;
					}

					// A suffix is present, but no special labels are used - meaning we don't need to figure out any other special values - just display the plain text value
					if (
						productTaxStatus === 'taxable' &&
						! hasCustomPriceWithTaxes &&
						woocommerce_addons_params.price_display_suffix.indexOf(
							'{price_including_tax}'
						) >
							-1 ===
							false &&
						woocommerce_addons_params.price_display_suffix.indexOf(
							'{price_excluding_tax}'
						) >
							-1 ===
							false
					) {
						html =
							html +
							'<li class="wc-pao-subtotal-line"><strong>' +
							subTotalString +
							' <span class="amount">' +
							formattedSubTotal +
							'</span> ' +
							woocommerce_addons_params.price_display_suffix +
							'</strong></li></ul></div>';

						if ( self.show_subtotal_panel ) {
							self.$totals.html( html );
						} else {
							self.$totals.html( '' );
						}

						self.$form.trigger( 'updated_addons' );
						return;
					}

					// Based on the totals/info and settings we have, we need to use the get_price_*_tax functions
					// to get accurate totals. We can get these values with a special Ajax function
					self.price_request = $.ajax( {
						type: 'POST',
						url: woocommerce_addons_params.ajax_url,
						data: {
							action: 'wc_product_addons_calculate_tax',
							product_id: self.product_id,
							add_on_total: self.total,
							add_on_total_raw: self.total_raw,
							qty: self.qty,
						},
						beforeSend() {
							if ( self.price_request !== null ) {
								self.price_request.abort();
							}
						},
						complete() {
							self.price_request = null;
						},
						success( result ) {
							if ( result.result === 'SUCCESS' ) {
								priceDisplaySuffix =
									'<small class="woocommerce-price-suffix">' +
									woocommerce_addons_params.price_display_suffix +
									'</small>';

								const formattedPriceIncludingTax =
										self.formatMoney(
											result.price_including_tax
										),
									formattedPriceExcludingTax =
										self.formatMoney(
											result.price_excluding_tax
										);

								priceDisplaySuffix = priceDisplaySuffix.replace(
									'{price_including_tax}',
									'<span class="amount">' +
										formattedPriceIncludingTax +
										'</span>'
								);
								priceDisplaySuffix = priceDisplaySuffix.replace(
									'{price_excluding_tax}',
									'<span class="amount">' +
										formattedPriceExcludingTax +
										'</span>'
								);

								const subtotal =
									woocommerce_addons_params.display_include_tax
										? formattedPriceIncludingTax
										: formattedPriceExcludingTax;

								html =
									html +
									'<li class="wc-pao-subtotal-line"><p class="price">' +
									subTotalString +
									' <span class="amount">' +
									subtotal +
									'</span> ' +
									priceDisplaySuffix +
									' </p></li></ul></div>';

								if ( self.show_subtotal_panel ) {
									self.$totals.html( html );
								} else {
									self.$totals.html( '' );
								}

								self.$form.trigger( 'updated_addons' );
							} else {
								html =
									html +
									'<li class="wc-pao-subtotal-line"><p class="price">' +
									subTotalString +
									' <span class="amount">' +
									formattedSubTotal +
									'</span></p></li></ul></div>';
								if ( self.show_subtotal_panel ) {
									self.$totals.html( html );
								} else {
									self.$totals.html( '' );
								}
								self.$form.trigger( 'updated_addons' );
							}
						},
						error() {
							html =
								html +
								'<li class="wc-pao-subtotal-line"><p class="price">' +
								subTotalString +
								' <span class="amount">' +
								formattedSubTotal +
								'</span></p></li></ul></div>';

							if ( self.show_subtotal_panel ) {
								self.$totals.html( html );
							} else {
								self.$totals.html( '' );
							}
							self.$form.trigger( 'updated_addons' );
						},
					} );
				} else {
					self.$totals.empty();
					self.$form.trigger( 'updated_addons' );
				}
			} else {
				self.$totals.empty();
				self.$form.trigger( 'updated_addons' );
			}
		};

		/**
		 * Resets and hides addon totals.
		 */
		Totals.prototype.reset = function () {
			this.$totals.empty();
			this.$totals.html( '' );
			this.$form.trigger( 'updated_addons' );
		};

		/**
		 * Formats addon prices.
		 *
		 * @param {number|string} amount Price.
		 * @return {string} Formatted price.
		 */
		Totals.prototype.formatMoney = function ( amount ) {
			let formatNumDecimal =
				woocommerce_addons_params.currency_format_num_decimals;

			// Remove trailing zeros.
			if ( woocommerce_addons_params.trim_trailing_zeros ) {
				const amountIsInteger = parseFloat( amount ) % 1 === 0;

				// Remove zeros.
				// if float, 4.6500 => 4.65
				// if integer, 4.0000 => 4
				amount = parseFloat( amount );

				// Set precision value (mandatory to be passed).
				if ( amountIsInteger ) {
					// Set 0 decimal precision for integers.
					formatNumDecimal = 0;
				} else {
					// Count decimal from amount (zeros skipped already) and set as precision.
					// 4.655 => 3 digits after decimal point.
					formatNumDecimal = amount
						.toString()
						.split( '.' )[ 1 ].length;
				}
			}

			return accounting.formatMoney( amount, {
				symbol: woocommerce_addons_params.currency_format_symbol,
				decimal: woocommerce_addons_params.currency_format_decimal_sep,
				thousand:
					woocommerce_addons_params.currency_format_thousand_sep,
				precision: formatNumDecimal,
				format: woocommerce_addons_params.currency_format,
			} );
		};

		return Form;
	} )();

	$( function () {
		// Quick view.
		$( 'body' ).on( 'quick-view-displayed', function () {
			$( this )
				.find( '.cart:not(.cart_group)' )
				.each( function () {
					new WC_PAO.Form( $( this ) );
				} );
		} );

		// Initialize addon totals.
		$( 'body' )
			.find( '.cart:not(.cart_group)' )
			.each( function () {
				new WC_PAO.Form( $( this ) );
			} );
	} );
} )( jQuery, window );
