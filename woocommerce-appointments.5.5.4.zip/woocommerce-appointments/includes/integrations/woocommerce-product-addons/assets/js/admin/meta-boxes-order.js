/* eslint-disable no-alert */
/* global wc_pao_admin_order_params */
jQuery( function ( $ ) {
	function debounce( callback, ms ) {
		let timer = 0;

		clearTimeout( timer );
		timer = setTimeout( callback, ms );
	}

	const $order_items = $( '#woocommerce-order-items' );
	let view = false;
	const functions = {
		handle_events() {
			$order_items
				.on(
					'click',
					'button.configure_addons',
					{ action: 'configure' },
					this.clicked_edit_button
				)
				.on(
					'click',
					'button.edit_addons',
					{ action: 'edit' },
					this.clicked_edit_button
				)
				.on(
					'wc_pb_populate_form wc_cp_populate_form',
					( e, pb_view ) => {
						view = pb_view;
						functions.render_form();
					}
				)
				.on(
					'wc_pb_validate_form wc_cp_validate_form',
					( event, currentView ) => {
						if ( ! currentView.is_valid ) {
							return;
						}

						currentView.is_valid =
							currentView.validation.validate( true );
					}
				);
		},

		clicked_edit_button( event ) {
			const WCPAOBackboneModal = $.WCBackboneModal.View.extend( {
				addButton: functions.clicked_done_button,
			} );

			const $item = $( this ).closest( 'tr.item' ),
				item_id = $item.attr( 'data-order_item_id' );

			view = new WCPAOBackboneModal( {
				target: 'wc-modal-edit-addon',
				string: {
					action:
						event.data.action === 'configure'
							? wc_pao_admin_order_params.i18n_configure
							: wc_pao_admin_order_params.i18n_edit,
					item_id,
				},
			} );

			functions.populate_form();

			return false;
		},

		clicked_done_button( event ) {
			if ( ! view.validation.validate( true ) ) {
				return;
			}

			const data = $.extend( {}, functions.get_taxable_address(), {
				action: 'woocommerce_edit_addon_order_item',
				item_id: view._string.item_id,
				dataType: 'json',
				order_id: woocommerce_admin_meta_boxes.post_id,
				security: wc_pao_admin_order_params.edit_pao_nonce,
			} );
			const form = view.$el.find( 'form' )[ 0 ];
			const form_data = new FormData( form );
			for ( const property in data ) {
				form_data.append( property, data[ property ] );
			}

			functions.block( view.$el.find( '.wc-backbone-modal-content' ) );

			$.post( {
				url: woocommerce_admin_meta_boxes.ajax_url,
				type: 'POST',
				data: form_data,
				processData: false,
				contentType: false,
				cache: false,
				success( response ) {
					if ( response.result && response.result === 'success' ) {
						$order_items.find( '.inside' ).empty();
						$order_items.find( '.inside' ).append( response.html );

						$order_items.trigger( 'wc_order_items_reloaded' );

						// Update notes.
						if ( response.notes_html ) {
							$( 'ul.order_notes' ).empty();
							$( 'ul.order_notes' ).append(
								$( response.notes_html ).find( 'li' )
							);
						}

						functions.unblock(
							view.$el.find( '.wc-backbone-modal-content' )
						);

						// Make it look like something changed.
						functions.block( $order_items, { fadeIn: 0 } );
						setTimeout( function () {
							functions.unblock( $order_items );
						}, 250 );

						view.closeButton( event );
					} else {
						window.alert(
							response.error
								? response.error
								: wc_pao_admin_order_params.i18n_validation_error
						);
						functions.unblock(
							view.$el.find( '.wc-backbone-modal-content' )
						);
					}
				},
				error() {
					window.alert(
						wc_pao_admin_order_params.i18n_validation_error
					);
					functions.unblock(
						view.$el.find( '.wc-backbone-modal-content' )
					);
				},
			} );
		},

		populate_form() {
			functions.block( view.$el.find( '.wc-backbone-modal-content' ) );

			const data = {
				action: 'woocommerce_configure_addon_order_item',
				item_id: view._string.item_id,
				dataType: 'json',
				order_id: woocommerce_admin_meta_boxes.post_id,
				security: wc_pao_admin_order_params.edit_pao_nonce,
			};

			$.post(
				woocommerce_admin_meta_boxes.ajax_url,
				data,
				function ( response ) {
					if ( response.result && response.result === 'success' ) {
						view.$el.find( 'form' ).html( response.html );
						functions.unblock(
							view.$el.find( '.wc-backbone-modal-content' )
						);
						functions.render_form();
					} else {
						window.alert(
							wc_pao_admin_order_params.i18n_form_error
						);
						functions.unblock(
							view.$el.find( '.wc-backbone-modal-content' )
						);
						view.$el.find( '.modal-close' ).trigger( 'click' );
					}
				}
			);
		},

		render_form() {
			// Special handling for image swatches.
			// When a user clicks on an image swatch, the selection is transferred to a hidden select element.
			let touchTime;

			/**
			 * Addons value changed.
			 */
			view.$el.on(
				'blur change',
				'.wc-pao-addon input, .wc-pao-addon textarea, .wc-pao-addon select, .wc-pao-addon-custom-text',
				function () {
					view.validation.validateAddon( $( this ), true );
				}
			);

			view.$el.on(
				'keyup',
				'.wc-pao-addon input, .wc-pao-addon textarea, .wc-pao-addon-custom-text',
				function () {
					const $addon = $( this );

					debounce( function () {
						view.validation.validateAddon( $addon, true );
					}, 300 );
				}
			);

			view.$el.on(
				'touchstart',
				'.wc-pao-addon-image-swatch',
				function () {
					touchTime = new Date();
				}
			);

			view.$el.on(
				'click touchend',
				'.wc-pao-addon-image-swatch',
				function ( e ) {
					e.preventDefault();

					if ( e.type === 'touchend' && touchTime ) {
						const diff = new Date() - touchTime;

						if ( diff > 100 ) {
							// This is a scroll event and not a tap, so skip.
							return;
						}
					}

					const selected_value = $( this ).data( 'value' ),
						$parent = $( this ).parents( '.wc-pao-addon-wrap' ),
						label = $.parseHTML( $( this ).data( 'price' ) ),
						$selected = $parent.find(
							'.wc-pao-addon-image-swatch-selected-swatch'
						);

					// Clear selected swatch.
					$selected.html( '' );

					// Clear all selected.
					$parent
						.find( '.wc-pao-addon-image-swatch' )
						.removeClass( 'selected' );

					// Select this swatch.
					$( this ).addClass( 'selected' );

					// Set the value in hidden select field.
					$parent
						.find( '.wc-pao-addon-image-swatch-select' )
						.val( selected_value );

					// Display selected label below swatches.
					$selected.html( label );

					view.validation.validateAddon(
						$parent.find( 'select.wc-pao-addon-field' ),
						true
					);
				}
			);

			/**
			 * Add-ons Datepicker extend.
			 */
			const $datepickers = view.$el.find( '.datepicker' );

			$datepickers.each( function () {
				// Cache local instances.
				const $datepicker = $( this ),
					$container = $datepicker.parent(),
					$clear_button = $container.find( '.reset_date' ),
					$timestamp_input = $container.find(
						'input[name="' +
							$datepicker.attr( 'name' ) +
							'-wc-pao-date"]'
					);
				let $offset_gmt_input = $container.find(
					'input[name="' +
						$datepicker.attr( 'name' ) +
						'-wc-pao-date-gmt-offset"]'
				);

				// Make Template backwards compatible.
				if ( ! $offset_gmt_input.length ) {
					$offset_gmt_input = $( '<input/>' );
					$offset_gmt_input.attr( 'type', 'hidden' );
					$offset_gmt_input.attr(
						'name',
						$datepicker.attr( 'name' ) + '-wc-pao-date-gmt-offset'
					);
					$container.append( $offset_gmt_input );
				}

				// Fill GMT offset.
				const now = new Date(),
					gmt_offset = parseFloat(
						wc_pao_admin_order_params.gmt_offset,
						10
					),
					client_offset = now.getTimezoneOffset() / 60;

				if (
					wc_pao_admin_order_params.date_input_timezone_reference ===
					'default'
				) {
					$offset_gmt_input.val( client_offset );
				} else if (
					wc_pao_admin_order_params.date_input_timezone_reference ===
					'store'
				) {
					$offset_gmt_input.val( gmt_offset );
				}

				// Init datepicker.
				$datepicker.datepicker( {
					beforeShow() {
						if ( wc_pao_admin_order_params.datepicker_class ) {
							$( '#ui-datepicker-div' ).removeClass(
								wc_pao_admin_order_params.datepicker_class
							);
							$( '#ui-datepicker-div' ).addClass(
								wc_pao_admin_order_params.datepicker_class
							);
						}
					},
					dateFormat:
						wc_pao_admin_order_params.datepicker_date_format,
					changeMonth: true,
					changeYear: true,
					yearRange: 'c-100:c+10',
				} );

				// Fill hidden inputs with selected date if any.
				let currentDate = $datepicker.datepicker( 'getDate' );

				if (
					currentDate !== null &&
					typeof currentDate.getTime === 'function'
				) {
					// Append current time.
					currentDate.setHours( now.getHours(), now.getMinutes() );

					if (
						wc_pao_admin_order_params.date_input_timezone_reference ===
						'store'
					) {
						currentDate = WC_PAO.Helper.addMinutes(
							currentDate,
							-1 * client_offset * 60
						);
						currentDate = WC_PAO.Helper.addMinutes(
							currentDate,
							gmt_offset * 60
						);
					}

					$timestamp_input.val( currentDate.getTime() / 1000 );
					$clear_button.show();
				}

				// On Change.
				$datepicker.on( 'change', function () {
					let selectedDate = $datepicker.datepicker( 'getDate' );
					if (
						selectedDate !== null &&
						typeof selectedDate.getTime === 'function'
					) {
						// Append current time.
						const currentTime = new Date();
						selectedDate.setHours(
							currentTime.getHours(),
							currentTime.getMinutes()
						);

						if (
							wc_pao_admin_order_params.date_input_timezone_reference ===
							'store'
						) {
							selectedDate = WC_PAO.Helper.addMinutes(
								selectedDate,
								-1 * client_offset * 60
							);
							selectedDate = WC_PAO.Helper.addMinutes(
								selectedDate,
								gmt_offset * 60
							);
						}

						$timestamp_input.val( selectedDate.getTime() / 1000 );
						$clear_button.show();
					} else {
						$clear_button.hide();
						$timestamp_input.val( '' );
					}
				} );

				// On clear date.
				$clear_button.on( 'click', function ( event ) {
					event.preventDefault();
					// Sanity clear.
					$timestamp_input.val( '' );
					// Trigger change.
					$datepicker.val( '' ).trigger( 'change' );
				} );
			} );

			view.$addons = view.$el.find( '.wc-pao-addon-field' );
			view.validation = new PaoValidation( view );
			view.validation.validate();
		},

		get_taxable_address() {
			let country = '';
			let state = '';
			let postcode = '';
			let city = '';

			if ( woocommerce_admin_meta_boxes.tax_based_on === 'shipping' ) {
				country = $( '#_shipping_country' ).val();
				state = $( '#_shipping_state' ).val();
				postcode = $( '#_shipping_postcode' ).val();
				city = $( '#_shipping_city' ).val();
			}

			if (
				woocommerce_admin_meta_boxes.tax_based_on === 'billing' ||
				! country
			) {
				country = $( '#_billing_country' ).val();
				state = $( '#_billing_state' ).val();
				postcode = $( '#_billing_postcode' ).val();
				city = $( '#_billing_city' ).val();
			}

			return {
				country,
				state,
				postcode,
				city,
			};
		},

		block( $target, params ) {
			const defaults = {
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6,
				},
			};

			const opts = $.extend( {}, defaults, params || {} );

			$target.block( opts );
		},

		unblock( $target ) {
			$target.unblock();
		},
	};

	/*
	 * Initialize.
	 */
	functions.handle_events();
} );
