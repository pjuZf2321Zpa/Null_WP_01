<?php
/**
 * WC_PAO_List_Table class
 *
 * @package  WooCommerce Product Add-Ons
 * @since    6.5.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Adds a custom global add-ons list table.
 *
 * @class    WC_PAO_List_Table
 * @version  8.4.0
 */
class WC_PAO_List_Table extends WP_List_Table {

	/**
	 * Page home URL.
	 *
	 * @const PAGE_URL
	 */
	const PAGE_URL = 'edit.php?post_type=product&page=addons';

	/**
	 * Total view records.
	 *
	 * @var int
	 */
	public $total_items = 0;

	/**
	 * Constructor
	 *
	 * @version 8.4.0
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'addon',
				'plural'   => 'addons',
			)
		);
	}

	/**
	 * Handles the title column output.
	 *
	 * @param array $item
	 */
	public function column_name( $item ) {

		$actions = array(
			'edit'   => sprintf( '<a href="' . esc_url( add_query_arg( 'edit', $item['id'], admin_url( 'edit.php?post_type=product&page=addons' ) ) ) . '">%s</a>', __( 'Edit', 'woocommerce-appointments' ) ),
			'delete' => sprintf( '<a href="' . esc_url( wp_nonce_url( add_query_arg( 'delete', $item['id'], admin_url( 'edit.php?post_type=product&page=addons' ) ), 'delete_addon' ) ) . '">%s</a>', __( 'Delete', 'woocommerce-appointments' ) ),
		);

		$title = $item['name'];

		printf(
			'<a class="row-title" href="%s" aria-label="%s">%s</a>%s',
			esc_url( add_query_arg( 'edit', $item['id'], admin_url( 'edit.php?post_type=product&page=addons' ) ) ),
			/* translators: %s: Global add-on group name */
			sprintf( esc_attr__( '%s (Edit)', 'woocommerce-appointments' ), esc_attr( $title ) ),
			esc_html( $title ),
			wp_kses_post( $this->row_actions( $actions ) )
		);
	}

	/**
	 * Handles the checkbox column output.
	 *
	 * @param array $item
	 */
	public function column_cb( $item ) {
		?><label class="screen-reader-text" for="cb-select-<?php echo (int) $item['id']; ?>">
		<?php
			$title = $item['name'];

			/* translators: %s: Add-on title */
			printf( esc_html__( 'Select %s', 'woocommerce-appointments' ), esc_html( $title ) );
		?>
		</label>
		<input id="cb-select-<?php echo (int) $item['id']; ?>" type="checkbox" name="addon[]" value="<?php echo (int) $item['id']; ?>" />
		<?php
	}

	/**
	 * Handles the Priority column output.
	 *
	 * @param array $item
	 */
	public function column_priority( $item ) {
		echo esc_html( (int) $item['priority'] );
	}

	/**
	 * Handles the Product Categories column output.
	 *
	 * @param array $item
	 */
	public function column_product_categories( $item ) {
		$all_products           = '1' === get_post_meta( $item['id'], '_all_products', true ) ? true : false;
		$restrict_to_categories = $item['restrict_to_categories'];

		if ( $all_products ) {
			esc_html_e( 'All Products', 'woocommerce-appointments' );
		} elseif ( 0 === count( $restrict_to_categories ) ) {
			esc_html_e( 'No Products Assigned', 'woocommerce-appointments' );
		} else {
			$objects    = array_keys( $restrict_to_categories );
			$term_names = array_values( $restrict_to_categories );
			$term_names = apply_filters( 'woocommerce_product_addons_global_display_term_names', $term_names, $objects );
			echo wp_kses_post( implode( ', ', $term_names ) );
		}
	}

	/**
	 * Handles the Number of fields column output.
	 *
	 * @param array $item
	 */
	public function column_fields( $item ) {
		echo count( $item['fields'] );
	}

	/**
	 * Get a list of columns. The format is:
	 * 'internal-name' => 'Title'
	 */
	public function get_columns() {

		$columns                       = array();
		$columns['cb']                 = '<input type="checkbox" />';
		$columns['name']               = _x( 'Name', 'column_name', 'woocommerce-appointments' );
		$columns['priority']           = _x( 'Display Order', 'column_name', 'woocommerce-appointments' );
		$columns['product_categories'] = _x( 'Product Categories', 'column_name', 'woocommerce-appointments' );
		$columns['fields']             = _x( 'Number of fields', 'column_name', 'woocommerce-appointments' );

		return $columns;
	}

	/**
	 * Return sortable columns.
	 *
	 * @version 8.4.0
	 *
	 * @return array
	 */
	public function get_sortable_columns() {
		$sortable_columns = array(
			'name'     => array( 'name', true ),
			'priority' => array( 'priority', true ),
			'fields'   => array( 'fields', true ),
		);

		return $sortable_columns;
	}

	/**
	 * Returns bulk actions.
	 *
	 * @return array
	 */
	protected function get_bulk_actions() {

		$actions = array(
			'delete' => __( 'Delete', 'woocommerce-appointments' ),
		);

		return $actions;
	}

	/**
	 * Process bulk actions.
	 *
	 * @return void
	 */
	private function process_bulk_action() {

		if ( $this->current_action() ) {

			check_admin_referer( 'bulk-addons' );

			$addons = isset( $_GET['addon'] ) && is_array( $_GET['addon'] ) ? array_map( 'absint', $_GET['addon'] ) : array();

			if ( empty( $addons ) ) {
				return;
			}

			if ( 'delete' === $this->current_action() ) {

				foreach ( $addons as $id ) {
					WC_Product_Addons_Groups::delete_group( $id );
				}

				WC_PAO_Admin_Notices::add_notice( __( 'Add-ons deleted.', 'woocommerce-appointments' ), 'success', true );
			}

			wp_safe_redirect( admin_url( self::PAGE_URL ) );
			exit();
		}
	}

	/**
	 * Query the DB and attach items.
	 *
	 * @version 8.4.0
	 *
	 * @return void
	 */
	public function prepare_items() {

		// Read per-page from screen option, fall through to filter for backwards compatibility.
		$screen_option = (int) get_user_meta( get_current_user_id(), 'addons_page_addons_per_page', true );

		/**
		 * `woocommerce_pao_admin_edit_add_ons_per_page` filter.
		 *
		 * Control how many global add-on groups are displayed per page in admin list table.
		 *
		 * @since  6.5.0
		 *
		 * @param  int
		 * @return int
		 */
		$per_page = (int) apply_filters( 'woocommerce_pao_admin_edit_add_ons_per_page', $screen_option ? $screen_option : 10 );

		// Table columns.
		$columns               = $this->get_columns();
		$hidden                = array();
		$sortable              = $this->get_sortable_columns();
		$this->_column_headers = array( $columns, $hidden, $sortable );

		// Process actions.
		$this->process_bulk_action();

		// Setup params.
		$paged   = isset( $_REQUEST['paged'] ) ? max( 0, intval( $_REQUEST['paged'] ) - 1 ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$orderby = ( isset( $_REQUEST['orderby'] ) && in_array( $_REQUEST['orderby'], array_keys( $this->get_sortable_columns() ), true ) ) ? sanitize_text_field( wp_unslash( $_REQUEST['orderby'] ) ) : 'priority'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$order   = ( isset( $_REQUEST['order'] ) && in_array( $_REQUEST['order'], array( 'asc', 'desc' ), true ) ) ? sanitize_text_field( wp_unslash( $_REQUEST['order'] ) ) : 'asc'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// Fetch all items.
		$this->items = WC_Product_Addons_Groups::get_all_global_groups();

		// Store unfiltered count for blank state check in the view.
		$this->total_items = count( $this->items );

		// Search filter.
		$search = isset( $_REQUEST['s'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' !== $search ) {
			$this->items = array_values(
				array_filter(
					$this->items,
					function ( $item ) use ( $search ) {
						return false !== stripos( $item['name'], $search );
					}
				)
			);
		}

		// Count filtered items for pagination.
		$total_items = count( $this->items );

		// Sort items BEFORE pagination so ordering applies globally.
		$orderby_column = array_column( $this->items, $orderby );

		// For 'fields', sort by count rather than the raw arrays.
		if ( 'fields' === $orderby ) {
			$orderby_column = array_map( 'count', $orderby_column );
		}

		$sort_direction = ( 'desc' === $order ) ? SORT_DESC : SORT_ASC;
		$sort_flag      = ( 'name' === $orderby ) ? SORT_STRING | SORT_FLAG_CASE : SORT_NUMERIC;

		if ( ! empty( $orderby_column ) ) {
			array_multisort( $orderby_column, $sort_direction, $sort_flag, $this->items );
		}

		// Paginate items AFTER sorting.
		$offset      = $paged * $per_page;
		$this->items = array_slice( $this->items, $offset, $per_page );

		// Configure pagination.
		$this->set_pagination_args(
			array(
				'total_items' => $total_items,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_items / $per_page ),
			)
		);
	}

	/**
	 * Message to be displayed when there are no items.
	 *
	 * @return void
	 */
	public function no_items() {
		?>
		<p class="main">
			<?php esc_html_e( 'No add-ons found', 'woocommerce-appointments' ); ?>
		</p>
		<?php
	}
}
