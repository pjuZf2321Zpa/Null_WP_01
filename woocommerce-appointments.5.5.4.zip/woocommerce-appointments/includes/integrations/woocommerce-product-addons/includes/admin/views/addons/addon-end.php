<?php
/**
 * The Template for displaying end of field.
 *
 * @package woocommerce-product-addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'wc_product_addon_end', $addon ); ?>
</div>
