<?php
/**
 * Admin display.
 *
 * @version 8.4.0
 * @package woocommerce-product-addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="wrap woocommerce woocommerce-product-addons">
	<h1><?php esc_html_e( 'Global Add-ons', 'woocommerce-appointments' ); ?> <a href="<?php echo esc_url( add_query_arg( 'add', true, admin_url( 'edit.php?post_type=product&page=addons' ) ) ); ?>" class="page-title-action"><?php esc_html_e( 'Add new', 'woocommerce-appointments' ); ?></a></h1><br/>
	<?php

	if ( $table->total_items ) {
		?>
		<form id="addons-table" method="GET">
			<?php
				$table->search_box( __( 'Search add-ons', 'woocommerce-appointments' ), 'addon' );
				$table->display();
				$page = isset( $_REQUEST['page'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['page'] ) ) : '';
			?>
			<input type="hidden" name="page" value="<?php echo esc_attr( $page ); ?>"/>
			<input type="hidden" name="post_type" value="product" />
		</form>
		<?php
	} else {
		?>
		<div class="woocommerce-BlankState">
			<h2 class="woocommerce-BlankState-message"><span><?php echo esc_html__( 'Use global add-ons to add free or paid options to your products in bulk.', 'woocommerce-appointments' ); ?></span>
			<a class="woocommerce-BlankState-cta button-primary button" href="<?php echo esc_url( add_query_arg( 'add', true, admin_url( 'edit.php?post_type=product&page=addons' ) ) ); ?>"><?php echo esc_html__( 'Create your first add-on', 'woocommerce-appointments' ); ?></a>
		</div>
		<?php
	}
	?>
</div>
