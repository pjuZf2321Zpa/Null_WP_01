<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installation/Migration Class.
 *
 * Handles the activation/installation of the plugin.
 *
 * @package  Installation
 * @version  8.4.1
 */
class WC_Product_Addons_Install {

	/**
	 * Maximum number of index.html placeholders the daily healthcheck backfills per run.
	 *
	 * @since 8.4.1
	 */
	const INDEX_BACKFILL_LIMIT = 250;

	/**
	 * Option flagging that every pre-existing upload directory has been backfilled.
	 *
	 * @since 8.4.1
	 */
	const INDEX_BACKFILL_DONE_OPTION = 'wc_pao_upload_index_backfill_done';

	/**
	 * Initialize hooks.
	 *
	 * @since 3.0.0
	 * @return bool
	 */
	public static function init() {
		add_action( 'wc_pao_daily', array( __CLASS__, 'maybe_create_files' ) );
		add_action( 'wc_pao_backfill_upload_index_html', array( __CLASS__, 'backfill_upload_index_html' ) );
		self::run();
	}

	/**
	 * Run the installation.
	 *
	 * @since 3.0.0
	 * @return bool
	 */
	private static function run() {
		$installed_version = get_option( 'wc_pao_version' );

		/**
		 * Filter to skip the migration of data from 2.x to 3.0.
		 *
		 * @since 7.1.1
		 *
		 * @param bool $should_migrate Whether to migrate the product addons or not.
		 *
		 * @returns bool
		 */
		if ( apply_filters( 'woocommerce_product_addons_enable_migration_3_0', false ) ) {
			self::migration_3_0_product();
		}

		// Check the version before running.
		if ( ! defined( 'IFRAME_REQUEST' ) && ( $installed_version !== WC_PRODUCT_ADDONS_VERSION ) ) {
			if ( ! defined( 'WC_PAO_INSTALLING' ) ) {
				define( 'WC_PAO_INSTALLING', true );
			}

			self::update_plugin_version();
			self::create_events();
			self::create_files();

			if ( version_compare( $installed_version, '3.0', '<' ) ) {
				self::migration_3_0();
			}

			do_action( 'wc_pao_updated' );
		}
	}

	/**
	 * Updates the plugin version in db.
	 *
	 * @since 3.0.0
	 * @return bool
	 */
	private static function update_plugin_version() {
		delete_option( 'wc_pao_version' );
		add_option( 'wc_pao_version', WC_PRODUCT_ADDONS_VERSION );
	}

	/**
	 * 3.0 migration script.
	 *
	 * @since 3.0.0
	 */
	private static function migration_3_0() {
		require_once WC_PRODUCT_ADDONS_PLUGIN_PATH . '/includes/updates/class-wc-product-addons-migration-3-0.php';
	}

	/**
	 * 3.0 migration script for product level.
	 *
	 * @since 3.0.0
	 */
	private static function migration_3_0_product() {
		require_once WC_PRODUCT_ADDONS_PLUGIN_PATH . '/includes/updates/class-wc-product-addons-migration-3-0-product.php';
	}

	/**
	 * Schedule cron events.
	 *
	 * @since 6.1.3
	 */
	private static function create_events() {
		if ( ! wp_next_scheduled( 'wc_pao_daily' ) ) {
			wp_schedule_event( time() + 10, 'daily', 'wc_pao_daily' );
		}

	}

	/**
	 * Create the index.html placeholder in the PAO uploads directory.
	 *
	 * Suppresses directory listing on Apache, Nginx, and LiteSpeed without
	 * relying on server-specific configuration. Called eagerly on install/upgrade
	 * (creates the directory if needed) and again via the daily healthcheck
	 * wrapper `maybe_create_files()` if the file is ever removed after the fact.
	 *
	 * @since 8.3.1
	 */
	public static function create_files() {
		/**
		 * Filter to skip creating files. Useful for read-only filesystems.
		 *
		 * @since 8.3.1
		 *
		 * @param bool $skip Whether to skip creating files. Default false.
		 */
		if ( apply_filters( 'woocommerce_pao_install_skip_create_files', false ) ) {
			return;
		}

		$upload_dir = wp_get_upload_dir();
		$base       = $upload_dir['basedir'] . '/product_addons_uploads';

		if ( ! wp_mkdir_p( $base ) ) {
			return;
		}

		self::create_index_html( $base );
	}

	/**
	 * Create the index.html placeholder in a single directory, if missing.
	 *
	 * The directory must already exist -- callers that generate it are responsible
	 * for creating it first.
	 *
	 * @since 8.4.1
	 *
	 * @param  string $dir Absolute path of the directory to place the placeholder in.
	 * @return bool        Whether this call created the placeholder. False when it was
	 *                     already there, when creation was skipped, and when the write failed.
	 */
	public static function create_index_html( $dir ) {
		/**
		 * Filter to skip creating files. Useful for read-only filesystems.
		 *
		 * @since 8.3.1
		 *
		 * @param bool $skip Whether to skip creating files. Default false.
		 */
		if ( apply_filters( 'woocommerce_pao_install_skip_create_files', false ) ) {
			return false;
		}

		if ( ! is_string( $dir ) || '' === $dir || ! is_dir( $dir ) ) {
			return false;
		}

		$target = trailingslashit( $dir ) . 'index.html';

		if ( file_exists( $target ) ) {
			return false;
		}

		$file_handle = @fopen( $target, 'wb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( ! $file_handle ) {
			return false;
		}

		fwrite( $file_handle, '' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		fclose( $file_handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return true;
	}

	/**
	 * Daily healthcheck: re-create the index.html placeholder if the PAO uploads
	 * directory exists but the placeholder has been removed (filesystem reset,
	 * manual deletion, backup restore, etc.).
	 *
	 * Intentionally does not create the directory itself — sites that have never
	 * received a file-upload add-on don't need an empty directory pre-created
	 * just to host a placeholder. The directory is created either by the install
	 * hook (eager) or by `wp_handle_upload()` on the first real upload.
	 *
	 * @since 8.3.1
	 */
	public static function maybe_create_files() {
		$upload_dir = wp_get_upload_dir();
		$base       = $upload_dir['basedir'] . '/product_addons_uploads';

		if ( ! is_dir( $base ) ) {
			return;
		}

		self::create_files();

		// Once every pre-existing directory has been covered, stop walking the upload
		// tree daily -- directories created from here on get their placeholder on upload.
		if ( 'yes' !== get_option( self::INDEX_BACKFILL_DONE_OPTION ) ) {
			self::backfill_upload_index_html();
		}
	}

	/**
	 * Add the placeholder to upload directories generated before it was created
	 * alongside the upload itself.
	 *
	 * Walks the one directory this plugin writes uploads to. `upload_dir()` in
	 * `WC_Product_Addons_Field_File_Upload` replaces the year/month segment rather than
	 * appending to it, so uploads always land in `uploads/product_addons_uploads/<customer>`
	 * whether or not year/month folders are on. Deriving that path from `wp_get_upload_dir()`
	 * also keeps each site of a multisite network inside its own uploads tree.
	 *
	 * Idempotent, and bounded to `INDEX_BACKFILL_LIMIT` writes per run so a store with many
	 * customer directories never walks everything in one request. When a run fills its batch
	 * it schedules the next one shortly after, so a large store converges within hours
	 * instead of one batch per day.
	 *
	 * Only placeholders this run actually wrote count towards the batch, so a run that
	 * cannot write -- a read-only filesystem, a permissions problem -- never queues a
	 * successor, and the chain always terminates: every write permanently removes one
	 * directory from the work left to do.
	 *
	 * @since 8.4.1
	 */
	public static function backfill_upload_index_html() {
		/**
		 * Filter to skip creating files. Useful for read-only filesystems.
		 *
		 * @since 8.3.1
		 *
		 * @param bool $skip Whether to skip creating files. Default false.
		 */
		if ( apply_filters( 'woocommerce_pao_install_skip_create_files', false ) ) {
			return;
		}

		$upload_dir = wp_get_upload_dir();
		$root       = $upload_dir['basedir'] . '/product_addons_uploads';

		try {
			$entries = new DirectoryIterator( $root );
		} catch ( Exception $e ) {
			return;
		}

		$created = 0;
		$failed  = 0;

		foreach ( $entries as $entry ) {

			if ( $entry->isDot() || ! $entry->isDir() ) {
				continue;
			}

			$customer_dir = $entry->getPathname();

			if ( file_exists( trailingslashit( $customer_dir ) . 'index.html' ) ) {
				continue;
			}

			if ( self::create_index_html( $customer_dir ) ) {
				++$created;
			} else {
				++$failed;
			}

			if ( $created >= self::INDEX_BACKFILL_LIMIT ) {
				self::schedule_index_backfill();
				return;
			}
		}

		// A run that walked the whole tree without a single failure has nothing left to
		// do. Anything it could not write is retried by the daily healthcheck instead.
		if ( 0 === $failed ) {
			update_option( self::INDEX_BACKFILL_DONE_OPTION, 'yes', false );
		}
	}

	/**
	 * Queue the next backfill batch, unless one is already waiting.
	 *
	 * @since 8.4.1
	 */
	private static function schedule_index_backfill() {
		if ( wp_next_scheduled( 'wc_pao_backfill_upload_index_html' ) ) {
			return;
		}

		wp_schedule_single_event( time() + 5 * MINUTE_IN_SECONDS, 'wc_pao_backfill_upload_index_html' );
	}
}

WC_Product_Addons_Install::init();
