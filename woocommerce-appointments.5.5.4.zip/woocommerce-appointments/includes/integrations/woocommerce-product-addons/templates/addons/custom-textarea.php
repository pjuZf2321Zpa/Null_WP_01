<?php
/**
 * The Template for displaying custom textarea field.
 *
 * @version 8.0.0
 * @package woocommerce-product-addons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Injections:
 *
 * @var array $addon
 * @var mixed $value
 */
global $product;


$field_name       = ! empty( $addon['field_name'] ) ? $addon['field_name'] : '';
$addon_key        = 'addon-' . sanitize_title( $field_name );
$adjust_price     = ! empty( $addon['adjust_price'] ) ? $addon['adjust_price'] : '';
$price            = ! empty( $addon['price'] ) ? $addon['price'] : '';
$price_type       = ! empty( $addon['price_type'] ) ? $addon['price_type'] : '';
$adjust_duration  = ! empty( $addon['adjust_duration'] ) ? $addon['adjust_duration'] : '';
$duration         = ! empty( $addon['duration'] ) ? absint( $addon['duration'] ) : '';
$duration_type    = ! empty( $addon['duration_type'] ) ? $addon['duration_type'] : '';
$placeholder      = ! empty( $addon['placeholder'] ) ? $addon['placeholder'] : '';
$restriction_data = WC_Product_Addons_Helper::get_restriction_data( $addon );
$price_raw        = apply_filters( 'woocommerce_product_addons_price_raw', $adjust_price && $price ? $price : '', $addon );
$price_display    = apply_filters(
	'woocommerce_product_addons_price',
	$adjust_price && $price_raw ? WC_Product_Addons_Helper::get_product_addon_price_for_display( $price_raw ) : '',
	$addon,
	0,
	$addon,
	'custom_textarea'
);
$value            = ! empty( $value ) ? $value : '';
$description      = ! empty( $addon['description'] ) ? $addon['description'] : '';

if ( 'percentage_based' === $price_type ) {
	$price_display = $price_raw;
}
$duration_raw     = apply_filters( 'woocommerce_product_addons_duration_raw', $adjust_duration && $duration ? $duration : '', $addon );
$duration_display = apply_filters(
	'woocommerce_product_addons_duration',
	$adjust_duration && $duration_raw ? ' ' . WC_Appointment_Duration::format_addon_duration( (int) $duration_raw, $product ) : '',
	$addon,
	0,
	$addon,
	'custom_textarea'
);
?>

<div class="form-row form-row-wide wc-pao-addon-wrap wc-pao-addon-<?php echo esc_attr( sanitize_title( $field_name ) ); ?>">
	<textarea
		class="input-text wc-pao-addon-field wc-pao-addon-custom-textarea"
		placeholder="<?php echo esc_attr( $placeholder ); ?>"
		data-raw-price="<?php echo esc_attr( $price_raw ); ?>"
		data-price="<?php echo esc_attr( $price_display ); ?>"
		data-price-type="<?php echo esc_attr( $price_type ); ?>"
			data-raw-duration="<?php echo esc_attr( $duration_raw ); ?>"
			data-duration="<?php echo esc_attr( $duration_display ); ?>"
			data-duration-type="<?php echo esc_attr( $duration_type ); ?>"
		name="<?php echo esc_attr( $addon_key ); ?>"
		id="<?php echo esc_attr( $addon_key ); ?>"
		rows="4"
		cols="20"
		data-restrictions="<?php echo esc_attr( wp_json_encode( $restriction_data ) ); ?>"
		<?php echo WC_Product_Addons_Helper::is_addon_required( $addon ) ? 'required' : ''; ?>
		<?php echo $description ? 'aria-describedby="wc-pao-description-' . esc_attr( wptexturize( $addon['field_name'] ) ) . '"' : ''; ?>
	><?php echo esc_textarea( $value ); ?></textarea>
</div>
