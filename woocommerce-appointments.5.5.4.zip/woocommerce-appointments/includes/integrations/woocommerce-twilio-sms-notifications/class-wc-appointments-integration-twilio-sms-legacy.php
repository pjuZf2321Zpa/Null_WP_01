<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce Twilio SMS Notification integration class.
 */
class WC_Appointments_Integration_WCTSN implements WC_Appointments_Integration_Interface {

    /**
	 * Constructor
	 */
	public function __construct() {
		$this->add_hooks();
	}

	/**
	 * Register WordPress hooks for this integration.
	 *
	 * @return void
	 */
	public function add_hooks(): void {
		add_filter( 'wc_order_statuses', [ $this, 'add_twilio_sms_order_statuses' ] );
		add_action( 'wc-appointment-reminder', [ $this, 'send_twilio_sms_reminder' ] );
		add_action( 'woocommerce_settings_start', [ $this, 'add_twilio_sms_reminder_default' ] );
	}

	/**
	 * Add order statuses to WooCommerce.
	 * Plugin does not have any filters, so this is the only way to add the option.
	 *
	 * @param array<string, string> $order_statuses Order statuses.
	 * @return array<string, string>
	 */
	public function add_twilio_sms_order_statuses( array $order_statuses ): array {
		if ( ! is_admin() ) {
			return $order_statuses;
		}

		$tab_raw = filter_input( INPUT_GET, 'tab' );
		$current_tab = ( is_string( $tab_raw ) && '' !== $tab_raw ) ? sanitize_title( wp_unslash( $tab_raw ) ) : 'general';

		if ( 'twilio_sms' === $current_tab ) {
			$order_statuses['wc-reminder'] = _x( 'Appointment Reminder', 'woocommerce-appointments', 'woocommerce-appointments' );
		}

		return $order_statuses;
	}

	/**
	 * Send appointment reminder SMS.
	 *
	 * @param int $appointment_id Appointment ID.
	 */
	public function send_twilio_sms_reminder( $appointment_id ): void {
		global $wpdb;

		// Get order ID.
		$order_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_parent FROM {$wpdb->posts} WHERE ID = %d", $appointment_id ) );

		// Stop here if order not attached to appointment as we can't get customer phone
		if ( ! $order_id ) {
			return;
		}

		// Get order object.
		$order = wc_get_order( $order_id );

		// get checkbox opt-in label
		$optin = get_option( 'wc_twilio_sms_checkout_optin_checkbox_label', '' );

		// check if opt-in checkbox is enabled
		if ( ! empty( $optin ) ) {

			// get opt-in meta for order
			$optin = get_post_meta( $order_id, '_wc_twilio_sms_optin', true );

			// check if customer has opted-in
			if ( empty( $optin ) ) {
				// no meta set, so customer has not opted in
				return;
			}
		}

		// Manually set SMS status to 'reminder'.
		$sms_status = 'reminder';

		// Check if sending SMS updates for this order's status.
		if ( in_array( 'wc-' . $sms_status, get_option( 'wc_twilio_sms_send_sms_order_statuses', [] ) ) ) {

			// Get message template.
			$message = get_option( 'wc_twilio_sms_' . $sms_status . '_sms_template', '' );

			// Use the default template if status-specific one is blank.
			if ( empty( $message ) ) {
				$message = __( 'Reminder: Appointment (%appointment_name%) will take place soon (%appointment_time%).', 'woocommerce-appointments' );
			}

			// Allow modification of message before variable replace (add additional variables, etc).
			$message = apply_filters( 'wc_twilio_sms_customer_sms_before_variable_replace', $message, $order );

			// Replace template variables.
			$message = $this->sms_replace_message_variables( $message, $order, $appointment_id );

			// Allow modification of message after variable replace.
			$message = apply_filters( 'wc_twilio_sms_customer_sms_after_variable_replace', $message, $order );

			// Fire up Twilio.
			$notification = new WC_Twilio_SMS_Notification( $order_id );

			// Send the SMS.
			$notification->send_manual_customer_notification( $message );
		}

	}

	/**
	 * Replaces template variables in SMS message
	 *
	 * @param string $message        Raw SMS message to replace with variable info.
	 * @param mixed  $order          Order object (external).
	 * @param int    $appointment_id Appointment ID.
	 * @return string Message with variables replaced with indicated values.
	 */
	public function sms_replace_message_variables( $message, $order, $appointment_id ): string {
		$appointment = get_wc_appointment( $appointment_id );
		$appointment_time = $appointment->is_all_day() ? $appointment->get_start_date( wc_appointments_date_format(), '' ) : $appointment->get_start_date( wc_appointments_date_format(), '' ) . ', ' . $appointment->get_start_date( '', wc_appointments_time_format() );

		$replacements = [
			'%shop_name%'        => (string) get_bloginfo( 'name' ),
			'%order_id%'         => (string) $order->get_order_number(),
			'%order_count%'      => (string) $order->get_item_count(),
			'%order_amount%'     => (string) $order->get_total(),
			'%order_status%'     => ucfirst( (string) $order->get_status() ),
			'%billing_name%'     => (string) $order->get_billing_first_name() . ' ' . (string) $order->get_billing_last_name(),
			'%shipping_name%'    => (string) $order->get_shipping_first_name() . ' ' . (string) $order->get_shipping_last_name(),
			'%shipping_method%'  => (string) $order->get_shipping_method(),
			'%appointment_name%' => (string) $appointment->get_product_name(),
			'%appointment_time%' => (string) $appointment_time,
		];

		return str_replace( array_keys( $replacements ), array_values( $replacements ), $message );
	}

	/**
	 * Register default reminder sms message if empty
	 */
	public function add_twilio_sms_reminder_default(): void {
		$sms_status = 'reminder';

		// Get message template.
		$message = get_option( 'wc_twilio_sms_' . $sms_status . '_sms_template', '' );

		// Use the default template if status-specific one is blank.
		if ( empty( $message ) ) {
			$message = __( 'Reminder: Appointment (%appointment_name%) will take place soon (%appointment_time%).', 'woocommerce-appointments' );
			update_option( 'wc_twilio_sms_' . $sms_status . '_sms_template', $message );
		}
	}

}

$GLOBALS['wc_appointments_integration_wctsn'] = new WC_Appointments_Integration_WCTSN();
