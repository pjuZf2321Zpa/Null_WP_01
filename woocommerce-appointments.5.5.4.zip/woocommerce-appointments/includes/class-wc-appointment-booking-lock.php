<?php
/**
 * Booking Lock Manager
 *
 * Handles booking locks to prevent race conditions during appointment creation.
 * Uses exponential backoff for retry attempts with performance optimizations.
 *
 * @package WooCommerce Appointments
 * @since 4.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Booking_Lock class.
 *
 * Manages atomic locks for appointment booking slots to prevent
 * double-booking in concurrent scenarios.
 *
 * Storage strategy:
 * - Persistent object cache: wp_cache_add() with TTL (atomic, auto-expires).
 * - Options table fallback:  INSERT IGNORE for atomicity; value = expiry
 *   timestamp so stale locks are cleaned on the next acquire attempt.
 *
 * @since 4.0.0
 */
class WC_Appointment_Booking_Lock {

	const DEFAULT_LOCK_TTL         = 5;
	const MAX_RETRIES              = 3;
	const BASE_DELAY_MICROSECONDS  = 100000; // 100 ms

	/**
	 * Acquire a booking lock for a specific time slot.
	 *
	 * @since 4.0.0
	 *
	 * @param int       $product_id Product ID.
	 * @param int       $start_date Start timestamp.
	 * @param int       $end_date   End timestamp.
	 * @param int|int[] $staff_id   Staff ID(s). Default 0.
	 *
	 * @return bool True if lock was acquired.
	 */
	public function acquire( int $product_id, int $start_date, int $end_date, $staff_id = 0 ): bool {
		return $this->acquire_key( $this->generate_lock_key( $product_id, $start_date, $end_date, $staff_id ) );
	}

	/**
	 * Acquire a booking lock with exponential backoff retry.
	 *
	 * @since 4.0.0
	 *
	 * @param int       $product_id  Product ID.
	 * @param int       $start_date  Start timestamp.
	 * @param int       $end_date    End timestamp.
	 * @param int|int[] $staff_id    Staff ID(s). Default 0.
	 * @param int       $max_retries Maximum retry attempts. Default 3.
	 *
	 * @return bool True if lock was acquired.
	 */
	public function acquire_with_retry( int $product_id, int $start_date, int $end_date, $staff_id = 0, int $max_retries = self::MAX_RETRIES ): bool {
		for ( $attempt = 0; $attempt <= $max_retries; $attempt++ ) {
			if ( $attempt > 0 ) {
				usleep( self::BASE_DELAY_MICROSECONDS * ( 1 << ( $attempt - 1 ) ) );
			}

			if ( $this->acquire( $product_id, $start_date, $end_date, $staff_id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Release a booking lock by slot parameters (backward-compatible).
	 *
	 * @since 4.0.0
	 *
	 * @param int       $product_id Product ID.
	 * @param int       $start_date Start timestamp.
	 * @param int       $end_date   End timestamp.
	 * @param int|int[] $staff_id   Staff ID(s). Default 0.
	 */
	public function release( int $product_id, int $start_date, int $end_date, $staff_id = 0 ): void {
		$this->release_key( $this->generate_lock_key( $product_id, $start_date, $end_date, $staff_id ) );
	}

	/**
	 * Release a booking lock by its exact key string.
	 *
	 * Prefer this over release() when the key was captured at acquire time
	 * (avoids recomputing from potentially-mutated timestamps).
	 *
	 * @since 5.5.0
	 *
	 * @param string $lock_key The key returned by get_lock_key().
	 */
	public function release_key( string $lock_key ): void {
		if ( wp_using_ext_object_cache() ) {
			wp_cache_delete( $lock_key, 'wc_appointments_locks' );
			return;
		}

		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $wpdb->options, [ 'option_name' => '_transient_' . $lock_key ] );
	}

	/**
	 * Return the lock key for a given slot without acquiring it.
	 *
	 * @since 5.5.0
	 *
	 * @param int       $product_id Product ID.
	 * @param int       $start_date Start timestamp.
	 * @param int       $end_date   End timestamp.
	 * @param int|int[] $staff_id   Staff ID(s). Default 0.
	 *
	 * @return string Lock key.
	 */
	public function get_lock_key( int $product_id, int $start_date, int $end_date, $staff_id = 0 ): string {
		return $this->generate_lock_key( $product_id, $start_date, $end_date, $staff_id );
	}

	/**
	 * @param int       $product_id Product ID.
	 * @param int       $start_date Start timestamp.
	 * @param int       $end_date   End timestamp.
	 * @param int|int[] $staff_id   Staff ID(s). Default 0.
	 *
	 * @return string Lock key.
	 */
	private function generate_lock_key( int $product_id, int $start_date, int $end_date, $staff_id = 0 ): string {
		$staff_str     = is_array( $staff_id ) ? implode( ',', array_map( 'intval', $staff_id ) ) : (string) intval( $staff_id );
		$start_rounded = (int) floor( $start_date / 60 ) * 60;
		$end_rounded   = (int) floor( $end_date / 60 ) * 60;

		return 'wc_appt_booking_lock_' . md5( $product_id . '|' . $start_rounded . '|' . $end_rounded . '|' . $staff_str );
	}

	/**
	 * Acquire per-resource lock keys for a product's resource requirements.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Product_Appointment $product    Product.
	 * @param int                    $start_date Start timestamp.
	 * @param int                    $end_date   End timestamp.
	 * @return string[] Lock keys acquired (for release).
	 */
	public function acquire_resource_locks( $product, int $start_date, int $end_date ): array {
		if ( ! class_exists( 'WC_Appointments_Resource' ) || ! is_a( $product, 'WC_Product_Appointment' ) ) {
			return [];
		}
		$requirements = WC_Appointments_Resource::normalize_requirements( $product );
		if ( [] === $requirements ) {
			return [];
		}
		$acquired = [];
		$start_rounded = (int) floor( $start_date / 60 ) * 60;
		$end_rounded   = (int) floor( $end_date / 60 ) * 60;

		foreach ( $requirements as $req ) {
			$key = 'wc_appt_booking_lock_' . md5( 'resource:' . $req['resource_id'] . '|' . $start_rounded . '|' . $end_rounded );
			if ( $this->acquire_key( $key ) ) {
				$acquired[] = $key;
			}
		}
		return $acquired;
	}

	/**
	 * Acquire a lock by its direct key string.
	 *
	 * @since 5.5.0
	 *
	 * @param string $lock_key Lock key.
	 * @return bool
	 */
	private function acquire_key( string $lock_key ): bool {
		$ttl = (int) apply_filters( 'woocommerce_appointments_booking_lock_ttl', self::DEFAULT_LOCK_TTL, null );

		if ( wp_using_ext_object_cache() ) {
			return (bool) wp_cache_add( $lock_key, time(), 'wc_appointments_locks', $ttl );
		}

		global $wpdb;
		$option_name = '_transient_' . $lock_key;
		$now         = time();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value < %s",
				$option_name,
				(string) $now
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		return (bool) $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				$option_name,
				(string) ( $now + $ttl )
			)
		);
	}
}
