<?php
/**
 * REST API Product slots objects.
 *
 * Handles requests to the /slots endpoint.
 *
 * @package WooCommerce\Appointments\Rest\Controller
 */

/**
 * REST API Products controller class.
 *
 * Endpoint: `GET /{namespace}/slots`
 *
 * Purpose
 * - Returns available appointment slots for one or more appointable products.
 * - Filters by product, category, staff, date/time range, and visibility flags.
 * - Sorts ascending by date and supports pagination.
 *
 * Namespace
 * - Defaults to v1 (`WC_Appointments_REST_API::V1_NAMESPACE`).
 * - The v2 controller overrides the namespace and adds additional capabilities.
 *
 * Query Parameters (v1)
 * - `product_ids` (string): Comma-separated product IDs. Example: `"12,34,56"`. When omitted, all appointable products are used.
 * - `product_id` (int): Single product ID. Alternative to `product_ids`.
 * - `category_ids` (string): Comma-separated WooCommerce product category IDs to filter products. Example: `"4,9"`.
 * - `category_id` (int): Single category ID. Alternative to `category_ids`.
 * - `staff_ids` (string): Comma-separated staff IDs to filter slot results. Example: `"2,3"`.
 * - `staff_id` (int): Single staff ID. Alternative to `staff_ids`.
 * - `min_date` (string): URL-encoded date/time interpreted by `strtotime`. Recommended formats: `YYYY-MM-DD` or `YYYY-MM-DDTHH:mm`.
 * - `max_date` (string): URL-encoded date/time interpreted by `strtotime`. Recommended formats: `YYYY-MM-DD` or `YYYY-MM-DDTHH:mm`.
 * - `get_past_times` (string): `'true'` to include past slots, `'false'` to exclude. Default `'false'`.
 * - `page` (int): 1-based page index. When omitted, results are not paginated.
 * - `limit` (int): Page size when `page` is set. Default `10`.
 * - `hide_unavailable` (string): `'true'` to hide slots where `available <= 0`, `'false'` to include. Default `'false'`.
 *
 * Behavior
 * - Enforces each product's minimum and maximum appointable dates and adjusts requested range accordingly.
 * - Uses the original product slot calculations (`get_slots_in_range` / `get_time_slots`).
 * - Results are sorted by date ascending and then paginated.
 *
 * Response Schema
 * - `{ records: Array<Slot>, count: number }`
 * - `Slot` fields:
 *   - `product_id` (int)
 *   - `product_name` (string)
 *   - `date` (string, site timezone, `YYYY-MM-DDTHH:mm`)
 *   - `duration` (int)
 *   - `duration_unit` (string, e.g. `'minute'`, `'hour'`, `'day'`, `'month'`)
 *   - `available` (int)
 *   - `scheduled` (int)
 *   - `staff_id` (int)
 *
 * Examples
 * - All appointable products for a single day: `GET /wc-appointments/v1/slots?min_date=2025-11-12&max_date=2025-11-13`
 * - Single product, hide unavailable: `GET /wc-appointments/v1/slots?product_id=123&min_date=2025-11-12&max_date=2025-11-13&hide_unavailable=true`
 */
class WC_Appointments_REST_Slots_Controller extends WC_REST_Controller {

	use WC_Appointments_Rest_Permission_Check;

	/**
	 * Endpoint namespace.
	 *
	 * @var string
	 */
	protected $namespace = WC_Appointments_REST_API::V1_NAMESPACE;

	/**
	 * Route base.
	 *
	 * @var string
	 */
	protected $rest_base = 'slots';

	/**
	 * Register the route for appointments slots.
	 */
	public function register_routes(): void {
		register_rest_route(
		    $this->namespace,
		    '/' . $this->rest_base,
		    [
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_items' ],
					// Public read; guests are throttled (staff bypass). Inherited by v2.
					'permission_callback' => static fn() => WC_Appointments_Rate_Limiter::rest_permission( 'rest_slots' ),
				],
			],
		);
	}

	/**
	 * Abbreviations constants.
	 */
	public const AVAILABLE     = 'a';
	public const SCHEDULED     = 'b';
	public const DATE          = 'd';
	// New abbreviated key to carry raw unix timestamp alongside human-readable date.
	public const TIMESTAMP     = 'ts';
	public const DURATION      = 'du';
	public const DURATION_UNIT = 'duu';
	public const ID            = 'i';
	public const NAME          = 'n';
	public const STAFF         = 's';

	/**
	 * Mapping of abbrieviations to expanded versions of lables.
	 * Used to minimize storred transient size.
	 *
	 * @var array<string, string>
	 */
	protected array $transient_keys_mapping = [
		self::AVAILABLE     => 'available',
		self::SCHEDULED     => 'scheduled',
		self::DATE          => 'date',
		// Expanded label for timestamp for client-side numeric consumption.
		self::TIMESTAMP     => 'timestamp',
		self::DURATION      => 'duration',
		self::DURATION_UNIT => 'duration_unit',
		self::STAFF         => 'staff_id',
		self::ID            => 'product_id',
		self::NAME          => 'product_name',
	];

	/**
	 * @param array<string, mixed> $availability Slot payload with abbreviated labels.
	 *
	 * @return array<string, mixed> Slot payload with labels expanded to their full version.
	 */
	public function transient_expand( $availability ): array {
		$expanded_availability = [];
		foreach ( $availability['records'] as $slot ) {
			$expanded_slot = [];
			foreach ( $slot as $abbrieviation  => $value ) {
				$expanded_slot[ $this->transient_keys_mapping[ $abbrieviation ] ] = $value;
			}
			$expanded_availability[] = $expanded_slot;
		}

		return [
			'records' => $expanded_availability,
			'count'   => $availability['count'],
		];
	}

	/**
	 * Format timestamp for API.
	 *
	 * Format a timestamp to the shortest reasonable format usable in the API response,
	 * respecting the provided timezone.
	 *
	 * @param int          $timestamp Timestamp to format.
	 * @param DateTimeZone $timezone  Timezone to use for formatting.
	 *
	 * @return string Formatted date string (ISO 8601 subset).
	 */
	public function get_time( $timestamp, $timezone ): string {
		$server_time = new DateTime( date( 'Y-m-d\TH:i:s', $timestamp ), $timezone );

		return $server_time->format( "Y-m-d\TH:i" );
	}

	/**
	 * Get available appointments slots (v1).
	 *
	 * Route
	 * - `GET /{namespace}/slots` where `{namespace}` defaults to v1.
	 *
	 * Query Parameters
	 * - `product_ids` (string, optional): Comma-separated product IDs.
	 * - `product_id` (int, optional): Single product ID; alternative to `product_ids`.
	 * - `category_ids` (string, optional): Comma-separated category IDs.
	 * - `category_id` (int, optional): Single category ID; alternative to `category_ids`.
	 * - `staff_ids` (string, optional): Comma-separated staff IDs.
	 * - `staff_id` (int, optional): Single staff ID; alternative to `staff_ids`.
	 * - `location_id` (int, optional): Location ID; scopes occupancy and product location allow-list.
	 * - `min_date` (string, optional): URL-encoded date/time string parseable by `strtotime`.
	 * - `max_date` (string, optional): URL-encoded date/time string parseable by `strtotime`.
	 * - `get_past_times` (string, optional): `'true'` or `'false'`. Defaults to `'false'`.
	 * - `page` (int, optional): 1-based index for pagination. Omit for unpaginated.
	 * - `limit` (int, optional): Page size when `page` is present. Defaults to `10`.
	 * - `hide_unavailable` (string, optional): `'true'` to hide sold-out slots; defaults to `'false'`.
	 *
	 * Behavior
	 * - Adjusts requested range to honor each product's min/max appointable dates.
	 * - Uses product methods for slot calculation (non-indexed path).
	 * - Sorts by date ascending and applies pagination.
	 *
	 * Response
	 * - `{ records: Array<Slot>, count: number }`, see class docblock for field descriptions.
	 *
	 * @param WP_REST_Request<array<string, mixed>> $request Full details about the request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$product_ids    = empty( $request['product_ids'] ) ? [] : array_map( 'absint', explode( ',', $request['product_ids'] ) );
		$category_ids   = empty( $request['category_ids'] ) ? [] : array_map( 'absint', explode( ',', $request['category_ids'] ) );
		$staff_ids      = empty( $request['staff_ids'] ) ? [] : array_map( 'absint', explode( ',', $request['staff_ids'] ) );
		$location_id    = absint( $request['location_id'] ?? 0 );
		$get_past_times = isset( $request['get_past_times'] ) && 'true' === $request['get_past_times'];

		$min_date_parsed = strtotime( urldecode( $request['min_date'] ?? '' ) );
		$max_date_parsed = strtotime( urldecode( $request['max_date'] ?? '' ) );
		$min_date        = false !== $min_date_parsed ? $min_date_parsed : 0;
		$max_date        = false !== $max_date_parsed ? $max_date_parsed : 0;
		$timezone = new DateTimeZone( wc_timezone_string() );

		$page             = $request['page'] ?? false;
		$records_per_page = absint( $request['limit'] ?? 10 );
		$hide_unavailable = isset( $request['hide_unavailable'] ) && 'true' === $request['hide_unavailable'];

		// If no product ids are specified, just use all products.
		if ( [] === $product_ids ) {
			$product_ids = WC_Data_Store::load( 'product-appointment' )->get_appointable_product_ids();
		}

		$products = array_filter(
		    array_map(
		        function( $product_id ) {
					// Ensure only readable (published/visible) products are exposed on a public endpoint.
					// This mirrors WooCommerce Store API behavior for public reads.
					if ( ! wc_rest_check_post_permissions( 'product', 'read', $product_id ) ) {
						return null;
					}
					return wc_get_product( $product_id );
				},
		        $product_ids,
		    ),
		);

		foreach ( $products as $product ) {
			$is_vaild_rest_type = 'appointment' === $product->get_type();
			$is_vaild_rest_type = apply_filters( "woocommerce_appointments_product_type_rest_check", $is_vaild_rest_type, $product );
			if ( ! $is_vaild_rest_type ) {
				wp_send_json( 'Not an appointable product', 400 );
			}
		}

		// If category ids are specified filter the product ids.
		if ( [] !== $category_ids ) {
			$products = array_filter(
			    $products,
			    function( $product ) use ( $category_ids ) {
					$product_id = $product->get_id();

					return array_reduce(
					    $category_ids,
					    function( $is_in_category, $category_id ) use ( $product_id ) {
							$term = get_term_by( 'id', $category_id, 'product_cat' );

							if ( ! $term ) {
								return $is_in_category;
							}

							return $is_in_category || has_term( (int) $term->term_id, 'product_cat', $product_id );
						},
					    false,
					);
				},
			);
		}

		// Get product ids from products after they filtered by categories.
		$product_ids = array_filter(
		    array_map(
		        fn($product) => $product->get_id(),
		        $products,
		    ),
		);

		$transient_name                   = 'appointment_slots_' . md5( http_build_query( [ $product_ids, $category_ids, $staff_ids, $location_id, $min_date, $max_date, $page, $records_per_page ] ) );
		$appointment_slots_transient_keys = array_filter( (array) WC_Appointments_Cache::get( 'appointment_slots_transient_keys' ) );
		$cached_availabilities            = WC_Appointments_Cache::get( $transient_name );

		if ( $cached_availabilities ) {
			$availability = wc_appointments_paginated_availability( $cached_availabilities, $page, $records_per_page );
			return rest_ensure_response( $this->transient_expand( $availability ) );
		}

		$needs_cache_set = false;
		foreach ( $product_ids as $product_id ) {
			if ( ! isset( $appointment_slots_transient_keys[ $product_id ] ) ) {
				$appointment_slots_transient_keys[ $product_id ] = [];
			}

			// Don't store in cache if it already exists there.
			if ( ! in_array( $transient_name, $appointment_slots_transient_keys[ $product_id ] ) ) {
				$appointment_slots_transient_keys[ $product_id ][] = $transient_name;
				$needs_cache_set                                   = true;
			}
		}

		// Only set cache if existing cached data has changed.
		if ( $needs_cache_set ) {
			// Give array of keys a long ttl because if it expires we won't be able to flush the keys when needed.
			// We can't use 0 to never expire because then WordPress will autoload the option on every page.
			WC_Appointments_Cache::set( 'appointment_slots_transient_keys', $appointment_slots_transient_keys, YEAR_IN_SECONDS );
		}

		// Calculate availability for each product via the Slots Provider.
		$now = current_time( 'timestamp' );
		$scheduled_data = [];

		foreach ( $products as $appointable_product ) {
			if ( ! is_wc_appointment_product( $appointable_product ) ) {
				continue;
			}

			// Unauthorized location for a product that uses locations: no slots.
			if (
				$location_id > 0
				&& class_exists( 'WC_Appointments_Location' )
				&& $appointable_product->has_locations()
				&& ! WC_Appointments_Location::authorize_location_id( $appointable_product, $location_id )
			) {
				continue;
			}

			// Clamp to product min/max appointable dates.
			$prod_min = $min_date ?: strtotime( 'today' );
			$product_min_date     = $appointable_product->get_min_date_a();
			$min_appointable_date = strtotime( "+{$product_min_date['value']} {$product_min_date['unit']}", $now );
			if ( $prod_min < $min_appointable_date ) {
				$prod_min = $min_appointable_date;
			}

			$prod_max = $max_date ?: strtotime( 'tomorrow' );
			$product_max_date     = $appointable_product->get_max_date_a();
			$max_appointable_date = strtotime( "+{$product_max_date['value']} {$product_max_date['unit']}", $now );
			if ( $prod_max < $prod_min ) {
				$prod_max = strtotime( '+1 day', $prod_min );
			}
			if ( $prod_max > $max_appointable_date ) {
				$prod_max = $max_appointable_date;
			}

			$catalog_visibility = $appointable_product->get_catalog_visibility();
			if ( 'hidden' === $catalog_visibility ) {
				continue;
			}

			// Determine staff filter from request ∩ product staff.
			$staff_id_for_query = null;
			if ( ! empty( $staff_ids ) ) {
				$product_staff = $appointable_product->get_staff_ids() ?: [];
				$matching      = array_values( array_intersect( $product_staff, $staff_ids ) );
				$staff_id_for_query = ! empty( $matching ) ? (int) $matching[0] : null;
			}

			// Slots Provider is THE engine for slot generation.
			$records = WC_Appointment_Slots_Provider::get_rest_records(
				$appointable_product,
				$prod_min,
				$prod_max,
				$staff_id_for_query,
				$get_past_times,
				false,
				$location_id
			);

			// Filter unavailable if requested.
			if ( $hide_unavailable ) {
				$records = array_filter( $records, static fn( array $r ): bool => (int) $r['available'] >= 1 );
				$records = array_values( $records );
			}

			$scheduled_data[] = [
				'product_id'    => $appointable_product->get_id(),
				'product_title' => $appointable_product->get_title(),
				'availability'  => $records,
			];
		}

		$scheduled_data = apply_filters( 'woocommerce_appointments_rest_slots_get_items', $scheduled_data );

		// Flatten into a single records array with abbreviated keys.
		$cached_availabilities = [];
		foreach ( $scheduled_data as $value ) {
			$pid   = $value['product_id'];
			$pname = $value['product_title'];
			foreach ( $value['availability'] as $record ) {
				// Convert full keys to abbreviated keys for transient storage.
				$cached_availabilities[] = [
					self::DATE          => $record['date'],
					self::TIMESTAMP     => $record['timestamp'],
					self::DURATION      => $record['duration'],
					self::DURATION_UNIT => $record['duration_unit'],
					self::AVAILABLE     => $record['available'],
					self::SCHEDULED     => $record['scheduled'],
					self::STAFF         => $record['staff_id'],
					self::ID            => $pid,
					self::NAME          => $pname,
				];
			}
		}

		// Sort by timestamp (more reliable than formatted date string).
		usort(
		    $cached_availabilities,
		    fn(array $a, array $b): int => $a[ self::TIMESTAMP ] <=> $b[ self::TIMESTAMP ],
		);

		$availability = wc_appointments_paginated_availability( $cached_availabilities, $page, $records_per_page );

		return rest_ensure_response( $this->transient_expand( $availability ) );
	}
}
