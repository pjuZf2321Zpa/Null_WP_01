<?php
/**
 * REST API v2 for recurring appointment series.
 *
 * @package WooCommerce\Appointments\Rest\Controller\V2
 * @since   5.4.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Series endpoints under wc-appointments/v2/series.
 */
class WC_Appointments_REST_V2_Series_Controller extends WP_REST_Controller {

	const ERROR_BASE = 'https://woocommerce-appointments.com/errors/';

	/**
	 * @var string
	 */
	protected $namespace = WC_Appointments_REST_API::V2_NAMESPACE;

	/**
	 * @var string
	 */
	protected $rest_base = 'series';

	/**
	 * @var WC_Appointment_Series_Preview
	 */
	protected $preview;

	/**
	 * @var WC_Appointment_Series_Manager
	 */
	protected $manager;

	/**
	 * @param WC_Appointment_Series_Preview|null $preview  Preview helper.
	 * @param WC_Appointment_Series_Manager|null $manager Manager.
	 */
	public function __construct( $preview = null, $manager = null ) {
		$this->preview  = $preview ? $preview : new WC_Appointment_Series_Preview();
		$this->manager  = $manager ? $manager : new WC_Appointment_Series_Manager( $this->preview );
	}

	/**
	 * Register routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/preview',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'preview' ),
				'permission_callback' => array( $this, 'permissions_preview' ),
				'args'                => $this->preview_args(),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/preview/suggest',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'preview_suggest' ),
				'permission_callback' => array( $this, 'permissions_preview' ),
				'args'                => $this->suggest_args(),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'permissions_read' ),
					'args'                => $this->get_collection_params(),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'permissions_create' ),
					'args'                => $this->preview_args(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)',
			array(
				'args' => array(
					'id' => array(
						'description' => __( 'Series id.', 'woocommerce-appointments' ),
						'type'        => 'integer',
					),
				),
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'permissions_read_item' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'permissions_mutate_item' ),
					'args'                => array(
						'scope' => array(
							'type'    => 'string',
							'enum'    => array( 'future', 'all' ),
							'default' => 'future',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/occurrences',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_occurrences' ),
				'permission_callback' => array( $this, 'permissions_read_item' ),
				'args'                => array(
					'id'    => array(
						'type' => 'integer',
					),
					'after' => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'limit' => array(
						'type'    => 'integer',
						'default' => 50,
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/skip',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'skip_one' ),
				'permission_callback' => array( $this, 'permissions_mutate_item' ),
				'args'                => array(
					'recurrence_id' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/reschedule-one',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'reschedule_one' ),
				'permission_callback' => array( $this, 'permissions_mutate_item' ),
				'args'                => array(
					'recurrence_id' => array(
						'type'     => 'string',
						'required' => true,
					),
					'new_start'     => array(
						'type'     => 'integer',
						'required' => true,
					),
					'new_end'       => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/balance',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'run_balance_action' ),
				'permission_callback' => array( $this, 'permissions_manage_balance' ),
				'args'                => array(
					'action'       => array(
						'type'     => 'string',
						'enum'     => array( 'create_order', 'invoice', 'paid_offline' ),
						'required' => true,
					),
					'send_invoice' => array(
						'type'    => 'boolean',
						'default' => false,
					),
					'note'         => array(
						'type' => 'string',
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/balance-checkout',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'prepare_balance_checkout' ),
				'permission_callback' => array( $this, 'permissions_read_item' ),
			)
		);
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function preview( $request ) {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return $this->problem( 503, 'recurring-disabled', __( 'Recurring appointments are disabled.', 'woocommerce-appointments' ) );
		}

		$payload = WC_Appointment_Series_Preview::payload_from_body( (array) $request->get_json_params() );
		if ( is_wp_error( $payload ) ) {
			return $this->problem( 400, 'invalid-product', $payload->get_error_message() );
		}

		return new WP_REST_Response( $payload, 200 );
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function preview_suggest( $request ) {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return $this->problem( 503, 'recurring-disabled', __( 'Recurring appointments are disabled.', 'woocommerce-appointments' ) );
		}

		$body     = (array) $request->get_json_params();
		$around   = isset( $body['around'] ) ? (string) $body['around'] : '';
		$timezone = isset( $body['timezone'] ) ? (string) $body['timezone'] : 'UTC';
		$rrule    = isset( $body['rrule'] ) ? (string) $body['rrule'] : 'RRULE:FREQ=WEEKLY;COUNT=8';

		if ( '' === $around ) {
			return $this->problem( 400, 'invalid-request', __( 'around is required.', 'woocommerce-appointments' ) );
		}

		$base              = $this->request_to_preview_args( $request );
		$base['rrule']     = $rrule;
		$base['dtstart_ts'] = WC_Appointment_Series_Request::parse_dtstart( $around, $timezone );

		$suggestions = $this->preview->suggest_dtstarts(
			$base,
			array( 0, 7 * DAY_IN_SECONDS, 14 * DAY_IN_SECONDS ),
			3
		);

		return new WP_REST_Response( array( 'suggestions' => $suggestions ), 200 );
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_item( $request ) {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return $this->problem( 503, 'recurring-disabled', __( 'Recurring appointments are disabled.', 'woocommerce-appointments' ) );
		}

		$key = $this->get_idempotency_key( $request );
		if ( '' === $key ) {
			return $this->problem( 400, 'missing-idempotency-key', __( 'Idempotency-Key header is required.', 'woocommerce-appointments' ) );
		}

		$body = (array) $request->get_json_params();
		if ( ! isset( $body['customer_id'] ) || 0 === (int) $body['customer_id'] ) {
			$body['customer_id'] = get_current_user_id();
		}

		if ( ! $this->user_can_mutate_customer( (int) $body['customer_id'] ) ) {
			return $this->problem( 403, 'forbidden', __( 'You cannot create a series for this customer.', 'woocommerce-appointments' ) );
		}

		return $this->with_idempotency(
			$key,
			$body,
			function () use ( $body, $key ) {
				$result = $this->manager->create( $this->body_to_create_args( $body ), $key );
				if ( is_wp_error( $result ) ) {
					return $this->problem_from_wp_error( $result, '/wc-appointments/v2/series' );
				}

				$payload = $this->prepare_series_item( $result, true );
				$response = new WP_REST_Response( $payload, 201 );
				$this->add_etag_header( $response, $result->get_version() );
				return array(
					'response' => $response,
					'store'    => array(
						'series_id' => $result->get_id(),
						'code'      => 201,
						'body'      => wp_json_encode( $payload ),
					),
				);
			}
		);
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_item( $request ) {
		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return $series;
		}

		$payload  = $this->prepare_series_item( $series, true );
		$response = new WP_REST_Response( $payload, 200 );
		$this->add_etag_header( $response, $series->get_version() );

		return $response;
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		$store = WC_Data_Store::load( WC_Appointment_Series::DATA_STORE );

		$customer_id = isset( $request['customer_id'] ) ? (int) $request['customer_id'] : 0;
		$status      = isset( $request['status'] ) ? (string) $request['status'] : '';

		if ( ! current_user_can( 'manage_appointments' ) ) {
			$customer_id = get_current_user_id();
		}

		$per_page = min( 100, max( 1, (int) $request['per_page'] ) );
		$page     = max( 1, (int) $request['page'] );
		$offset   = ( $page - 1 ) * $per_page;

		$query_args = array(
			'customer_id' => $customer_id,
			'status'      => $status,
		);

		// Get total count for pagination headers.
		$total = $store->count( $query_args );

		// Get the paginated results.
		$query_args['limit']  = $per_page;
		$query_args['offset'] = $offset;
		$rows = $store->query( $query_args );

		$data = array();
		foreach ( $rows as $series ) {
			$data[] = $this->prepare_series_item( $series, false );
		}

		$total_pages = $total > 0 ? (int) ceil( $total / $per_page ) : 1;

		$response = new WP_REST_Response( $data, 200 );
		$response->header( 'X-WP-Total', (string) $total );
		$response->header( 'X-WP-TotalPages', (string) $total_pages );

		return $response;
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_occurrences( $request ) {
		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return $series;
		}

		$after = isset( $request['after'] ) ? (int) $request['after'] : 0;
		$limit = min( 100, max( 1, (int) $request['limit'] ) );
		$items = array();

		foreach ( $series->get_occurrence_appointments( $limit, $after ) as $appt ) {
			$items[] = WC_Appointment_Series::occurrence_to_rest_item( $appt );
		}

		$response = new WP_REST_Response( array( 'occurrences' => $items ), 200 );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );

		return $response;
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_item( $request ) {
		$key = $this->get_idempotency_key( $request );
		if ( '' === $key ) {
			return $this->problem( 400, 'missing-idempotency-key', __( 'Idempotency-Key header is required.', 'woocommerce-appointments' ) );
		}

		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return $series;
		}

		$version = $this->get_if_match_version( $request );
		if ( null === $version ) {
			return $this->problem( 428, 'precondition-required', __( 'If-Match header is required.', 'woocommerce-appointments' ) );
		}

		$scope = isset( $request['scope'] ) ? (string) $request['scope'] : 'future';
		$body  = array(
			'series_id' => $series->get_id(),
			'scope'    => $scope,
			'version'  => $version,
		);

		return $this->with_idempotency(
			$key,
			$body,
			function () use ( $series, $version, $scope, $key ) {
				$result = $this->manager->cancel( $series->get_id(), $version, $scope, $key );
				if ( is_wp_error( $result ) ) {
					if ( 'version_conflict' === $result->get_error_code() ) {
						$series = new WC_Appointment_Series( $series->get_id() );
						return $this->problem(
							412,
							'version-conflict',
							$result->get_error_message(),
							array( 'series' => $this->prepare_series_item( $series, false ) )
						);
					}
					return $this->problem_from_wp_error( $result );
				}

				$response = new WP_REST_Response( null, 204 );
				return array(
					'response' => $response,
					'store'    => array(
						'series_id' => $series->get_id(),
						'code'      => 204,
						'body'      => '',
					),
				);
			}
		);
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function skip_one( $request ) {
		$key = $this->get_idempotency_key( $request );
		if ( '' === $key ) {
			return $this->problem( 400, 'missing-idempotency-key', __( 'Idempotency-Key header is required.', 'woocommerce-appointments' ) );
		}

		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return $series;
		}

		$version = $this->get_if_match_version( $request );
		if ( null === $version ) {
			return $this->problem( 428, 'precondition-required', __( 'If-Match header is required.', 'woocommerce-appointments' ) );
		}

		$body = (array) $request->get_json_params();
		$recurrence_id = isset( $body['recurrence_id'] ) ? (string) $body['recurrence_id'] : '';
		if ( '' === $recurrence_id ) {
			return $this->problem( 400, 'invalid-request', __( 'recurrence_id is required.', 'woocommerce-appointments' ) );
		}

		$hash_body = array(
			'series_id'     => $series->get_id(),
			'recurrence_id' => $recurrence_id,
			'version'       => $version,
		);

		return $this->with_idempotency(
			$key,
			$hash_body,
			function () use ( $series, $version, $recurrence_id, $key ) {
				$result = $this->manager->skip_one( $series->get_id(), $version, $recurrence_id, $key );
				if ( is_wp_error( $result ) ) {
					if ( 'version_conflict' === $result->get_error_code() ) {
						$series = new WC_Appointment_Series( $series->get_id() );
						return $this->problem(
							412,
							'version-conflict',
							$result->get_error_message(),
							array( 'series' => $this->prepare_series_item( $series, false ) )
						);
					}
					return $this->problem_from_wp_error( $result );
				}

				$series   = new WC_Appointment_Series( $series->get_id() );
				$payload  = $this->prepare_series_item( $series, false );
				$response = new WP_REST_Response( $payload, 200 );
				$this->add_etag_header( $response, $series->get_version() );

				return array(
					'response' => $response,
					'store'    => array(
						'series_id' => $series->get_id(),
						'code'      => 200,
						'body'      => wp_json_encode( $payload ),
					),
				);
			}
		);
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function reschedule_one( $request ) {
		$key = $this->get_idempotency_key( $request );
		if ( '' === $key ) {
			return $this->problem( 400, 'missing-idempotency-key', __( 'Idempotency-Key header is required.', 'woocommerce-appointments' ) );
		}

		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return $series;
		}

		$version = $this->get_if_match_version( $request );
		if ( null === $version ) {
			return $this->problem( 428, 'precondition-required', __( 'If-Match header is required.', 'woocommerce-appointments' ) );
		}

		$body = (array) $request->get_json_params();
		$recurrence_id = isset( $body['recurrence_id'] ) ? (string) $body['recurrence_id'] : '';
		$new_start     = isset( $body['new_start'] ) ? (int) $body['new_start'] : 0;
		$new_end       = isset( $body['new_end'] ) ? (int) $body['new_end'] : 0;

		if ( '' === $recurrence_id || $new_start <= 0 || $new_end <= 0 ) {
			return $this->problem( 400, 'invalid-request', __( 'recurrence_id, new_start, and new_end are required.', 'woocommerce-appointments' ) );
		}

		$hash_body = array(
			'series_id'     => $series->get_id(),
			'recurrence_id' => $recurrence_id,
			'new_start'     => $new_start,
			'new_end'       => $new_end,
			'version'       => $version,
		);

		return $this->with_idempotency(
			$key,
			$hash_body,
			function () use ( $series, $version, $recurrence_id, $new_start, $new_end, $key ) {
				$result = $this->manager->reschedule_one( $series->get_id(), $version, $recurrence_id, $new_start, $new_end, $key );
				if ( is_wp_error( $result ) ) {
					if ( 'version_conflict' === $result->get_error_code() ) {
						$series = new WC_Appointment_Series( $series->get_id() );
						return $this->problem(
							412,
							'version-conflict',
							$result->get_error_message(),
							array( 'series' => $this->prepare_series_item( $series, false ) )
						);
					}
					return $this->problem_from_wp_error( $result );
				}

				$series   = new WC_Appointment_Series( $series->get_id() );
				$payload  = $this->prepare_series_item( $series, false );
				$response = new WP_REST_Response( $payload, 200 );
				$this->add_etag_header( $response, $series->get_version() );

				return array(
					'response' => $response,
					'store'    => array(
						'series_id' => $series->get_id(),
						'code'      => 200,
						'body'      => wp_json_encode( $payload ),
					),
				);
			}
		);
	}

	/**
	 * Storefront preview (guests may book recurring packages without logging in).
	 *
	 * @return bool
	 */
	public function permissions_preview() {
		return WC_Appointment_Series_Events::is_enabled();
	}

	/**
	 * @return bool|WP_Error
	 */
	public function permissions_read() {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return false;
		}
		return current_user_can( 'read' );
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return bool|WP_Error
	 */
	public function permissions_read_item( $request ) {
		if ( ! $this->permissions_read() ) {
			return false;
		}

		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return false;
		}

		if ( current_user_can( 'manage_appointments' ) ) {
			return true;
		}

		return get_current_user_id() === (int) $series->get_customer_id();
	}

	/**
	 * @return bool|WP_Error
	 */
	public function permissions_create() {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return false;
		}
		// Customers materialize series via checkout / order hooks only.
		// Bare REST create would activate unpaid appointments for any subscriber.
		return current_user_can( 'manage_appointments' );
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return bool|WP_Error
	 */
	public function permissions_mutate_item( $request ) {
		if ( ! is_user_logged_in() || ! current_user_can( 'read' ) ) {
			return false;
		}

		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return false;
		}

		return $this->user_can_mutate_customer( (int) $series->get_customer_id() );
	}

	/**
	 * @param int $customer_id Customer user id.
	 * @return bool
	 */
	protected function user_can_mutate_customer( $customer_id ) {
		if ( current_user_can( 'manage_appointments' ) ) {
			return true;
		}
		return get_current_user_id() === (int) $customer_id;
	}

	/**
	 * Staff-only balance order actions (create order, invoice, mark paid offline).
	 *
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return bool|WP_Error
	 */
	public function permissions_manage_balance( $request ) {
		if ( ! WC_Appointment_Series_Events::is_enabled() ) {
			return false;
		}
		if ( ! WC_Appointment_Series_Payment::staff_can_manage_balance() ) {
			return false;
		}

		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return false;
		}

		return true;
	}

	/**
	 * Staff balance action (`create_order`, `invoice`, `paid_offline`).
	 *
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function run_balance_action( $request ) {
		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return $series;
		}

		$result = WC_Appointment_Series_Payment::run_balance_action(
			$series,
			(string) $request->get_param( 'action' ),
			array(
				'send_invoice' => (bool) $request->get_param( 'send_invoice' ),
				'note'         => (string) $request->get_param( 'note' ),
			)
		);

		if ( is_wp_error( $result ) ) {
			return $this->problem( 400, $result->get_error_code(), $result->get_error_message() );
		}

		$series = new WC_Appointment_Series( $series->get_id() );
		return new WP_REST_Response(
			array_merge(
				array( 'series' => $this->prepare_series_item( $series, false ) ),
				$result
			),
			200
		);
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function prepare_balance_checkout( $request ) {
		$series = $this->get_series_or_error( (int) $request['id'] );
		if ( ! $series instanceof WC_Appointment_Series ) {
			return $series;
		}

		$order = WC_Appointment_Series_Payment::ensure_payable_balance_order( $series );
		if ( is_wp_error( $order ) ) {
			return $this->problem( 400, $order->get_error_code(), $order->get_error_message() );
		}

		$series = new WC_Appointment_Series( $series->get_id() );
		return new WP_REST_Response(
			array(
				'series'      => $this->prepare_series_item( $series, false ),
				'payment_url' => $order->get_checkout_payment_url(),
				'order_id'    => $order->get_id(),
			),
			200
		);
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return array<string, mixed>
	 */
	protected function request_to_preview_args( $request ) {
		return WC_Appointment_Series_Request::preview_args_from_rest( (array) $request->get_json_params() );
	}

	/**
	 * @param array<string, mixed> $body Request body.
	 * @return array<string, mixed>
	 */
	protected function body_to_create_args( $body ) {
		return WC_Appointment_Series_Request::create_args_from_rest( is_array( $body ) ? $body : array() );
	}

	/**
	 * @param WC_Appointment_Series $series           Series.
	 * @param bool                  $include_children Include materialized appointment ids.
	 * @return array<string, mixed>
	 */
	protected function prepare_series_item( WC_Appointment_Series $series, $include_children = false ) {
		$item = array(
			'id'                    => $series->get_id(),
			'version'               => $series->get_version(),
			'status'                => $series->get_status(),
			'product_id'            => $series->get_product_id(),
			'customer_id'           => $series->get_customer_id(),
			'staff_assignment_mode' => $series->get_staff_assignment_mode(),
			'locked_staff_id'       => $series->get_locked_staff_id(),
			'location_id'           => (int) $series->get_meta( '_wca_location_id', true ),
			'location'              => (array) $series->get_meta( '_wca_location', true ),
			'location_display'      => '',
			'order_id'              => $series->get_order_id(),
			'payment_model'         => $series->get_payment_model(),
			'rrule'                 => $series->get_rrule(),
			'dtstart_ts'            => $series->get_dtstart_ts(),
			'duration_seconds'      => $series->get_duration_seconds(),
			'timezone'              => $series->get_timezone(),
			'next_materialize_ts'   => $series->get_next_materialize_ts(),
			'last_materialized_ts'  => $series->get_last_materialized_ts(),
			'materialized_count'    => $series->get_materialized_count(),
			'rrule_count_cap'       => max( $series->get_rrule_count_cap(), WC_Appointment_Series_RRule::parse_count_cap( $series->get_rrule() ) ),
			'created_at'            => $series->get_created_at(),
			'updated_at'            => $series->get_updated_at(),
			'pattern_summary'       => $series->get_pattern_summary(),
		);

		if ( ! empty( $item['location'] ) && class_exists( 'WC_Appointments_Location' ) ) {
			$item['location_display'] = WC_Appointments_Location::format_snapshot_for_display( $item['location'] );
		}

		if ( $include_children ) {
			$item['appointment_ids'] = $this->get_series_appointment_ids( $series->get_id() );
		}

		$item['payment'] = $series->get_payment_snapshot();

		return $item;
	}

	/**
	 * @param int $series_id Series id.
	 * @return int[]
	 */
	protected function get_series_appointment_ids( $series_id ) {
		$query = new WP_Query(
			array(
				'post_type'      => 'wc_appointment',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 100,
				'no_found_rows'  => true,
				'meta_query'     => array(
					array(
						'key'   => '_wca_series_id',
						'value' => (int) $series_id,
					),
				),
			)
		);

		return array_map( 'intval', (array) $query->posts );
	}

	/**
	 * @param int $series_id Series id.
	 * @return WC_Appointment_Series|WP_REST_Response
	 */
	protected function get_series_or_error( $series_id ) {
		if ( $series_id <= 0 ) {
			return $this->problem( 404, 'not-found', __( 'Series not found.', 'woocommerce-appointments' ) );
		}

		try {
			return new WC_Appointment_Series( $series_id );
		} catch ( Exception $e ) {
			return $this->problem( 404, 'not-found', __( 'Series not found.', 'woocommerce-appointments' ) );
		}
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return string
	 */
	protected function get_idempotency_key( $request ) {
		$key = (string) $request->get_header( 'Idempotency-Key' );
		if ( '' !== $key ) {
			return substr( $key, 0, 80 );
		}

		$body = (array) $request->get_json_params();
		if ( isset( $body['idempotency_key'] ) ) {
			return substr( (string) $body['idempotency_key'], 0, 80 );
		}

		return '';
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return int|null
	 */
	protected function get_if_match_version( $request ) {
		$header = (string) $request->get_header( 'If-Match' );
		if ( '' === $header ) {
			$body = (array) $request->get_json_params();
			if ( isset( $body['version'] ) ) {
				return (int) $body['version'];
			}
			return null;
		}

		$header = trim( $header, '"' );
		$header = preg_replace( '/^W\//', '', $header );
		return (int) $header;
	}

	/**
	 * @param WP_REST_Response $response Response.
	 * @param int              $version  Series version.
	 * @return void
	 */
	protected function add_etag_header( WP_REST_Response $response, $version ) {
		$response->header( 'ETag', 'W/"' . (int) $version . '"' );
	}

	/**
	 * @param string   $key      Idempotency key.
	 * @param array<string, mixed> $body Body for hash.
	 * @param callable $callback Returns array{response:WP_REST_Response,store:array}|WP_Error.
	 * @return WP_REST_Response|WP_Error
	 */
	protected function with_idempotency( $key, $body, $callback ) {
		$idem = new WC_Appointment_Series_Idempotency();
		$hash = WC_Appointment_Series_Idempotency::hash_body( $body );

		try {
			$replay = $idem->lookup( $key, $hash );
		} catch ( WC_Appointment_Series_Idempotency_Conflict $e ) {
			return $this->problem( 409, 'idempotency-key-conflict', $e->getMessage() );
		}

		if ( $replay ) {
			$decoded = '' !== $replay['body'] ? json_decode( $replay['body'], true ) : null;
			$response = new WP_REST_Response( $decoded, (int) $replay['code'] );
			$response->header( 'Idempotent-Replay', 'true' );
			return $response;
		}

		$result = call_user_func( $callback );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( isset( $result['store'] ) ) {
			$idem->store(
				$key,
				$hash,
				(int) $result['store']['series_id'],
				(int) $result['store']['code'],
				(string) $result['store']['body']
			);
		}

		return $result['response'];
	}

	/**
	 * @param int    $status HTTP status.
	 * @param string $slug   Error slug.
	 * @param string $detail Detail message.
	 * @param array<string, mixed> $extra Extra fields.
	 * @return WP_REST_Response
	 */
	protected function problem( $status, $slug, $detail, $extra = array() ) {
		$body = array_merge(
			array(
				'type'   => self::ERROR_BASE . $slug,
				'title'  => str_replace( '-', ' ', $slug ),
				'status' => (int) $status,
				'detail' => $detail,
			),
			$extra
		);

		$response = new WP_REST_Response( $body, (int) $status );
		$response->header( 'Content-Type', 'application/problem+json' );

		return $response;
	}

	/**
	 * @param WP_Error $error    Error.
	 * @param string   $instance Optional instance path.
	 * @return WP_REST_Response
	 */
	protected function problem_from_wp_error( WP_Error $error, $instance = '' ) {
		$code   = $error->get_error_code();
		$status = 400;
		$data   = $error->get_error_data();
		if ( is_array( $data ) && isset( $data['status'] ) ) {
			$status = (int) $data['status'];
		} elseif ( 'series_conflict' === $code ) {
			$status = 422;
		}

		$extra = array();
		if ( 'series_conflict' === $code ) {
			$data = $error->get_error_data();
			if ( is_array( $data ) && isset( $data['conflicts'] ) ) {
				$extra['conflicts'] = $data['conflicts'];
			}
		}

		if ( '' !== $instance ) {
			$extra['instance'] = $instance;
		}

		return $this->problem( $status, $code, $error->get_error_message(), $extra );
	}

	/**
	 * @return array<string, array<string, mixed>>
	 */
	protected function preview_args() {
		return array(
			'product_id' => array(
				'type'     => 'integer',
				'required' => true,
			),
			'rrule'      => array(
				'type'     => 'string',
				'required' => true,
			),
			'dtstart'    => array(
				'type' => array( 'integer', 'string' ),
			),
			'timezone'   => array(
				'type'    => 'string',
				'default' => 'UTC',
			),
		);
	}

	/**
	 * @return array<string, array<string, mixed>>
	 */
	protected function suggest_args() {
		return array(
			'product_id' => array(
				'type' => 'integer',
			),
			'around'     => array(
				'type'     => 'string',
				'required' => true,
			),
			'rrule'      => array(
				'type' => 'string',
			),
			'timezone'   => array(
				'type'    => 'string',
				'default' => 'UTC',
			),
		);
	}

	/**
	 * @return array<string, array<string, mixed>>
	 */
	public function get_collection_params() {
		return array(
			'page'        => array(
				'type'    => 'integer',
				'default' => 1,
			),
			'per_page'    => array(
				'type'    => 'integer',
				'default' => 20,
			),
			'customer_id' => array(
				'type' => 'integer',
			),
			'status'      => array(
				'type' => 'string',
			),
		);
	}
}
