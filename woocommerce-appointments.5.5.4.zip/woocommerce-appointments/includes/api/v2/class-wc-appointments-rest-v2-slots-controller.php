<?php
/**
 * REST API v2 for slots.
 *
 * Mirrors the existing slots controller but registers under the v2
 * namespace. The underlying product slot calculations already use the
 * indexed path when the feature is enabled, so no further logic change
 * is needed—this controller focuses on namespacing and documentation.
 *
 * @package WooCommerce\Appointments\Rest\Controller\V2
 */

/**
 * V2 Slots controller.
 *
 * Endpoint: `GET /{namespace}/slots` (defaults to v2 namespace)
 *
 * Purpose
 * - Returns available appointment slots with indexed fast-path when enabled.
 * - Adds numeric timestamp support and more flexible filtering compared to v1.
 *
 * Differences vs v1
 * - Uses `WC_Appointments_Controller` cached/indexed implementations when indexing is enabled and the requested range is within the cache horizon (default 3 months via admin setting). Falls back to non-indexed product methods outside horizon or when indexing is disabled.
 * - Includes `timestamp` (UNIX epoch seconds) in each record.
 * - Supports `min_timestamp` and `max_timestamp` filters overriding `min_date`/`max_date`.
 * - Skips transient writes when `WC_APPOINTMENTS_DEBUG` is `true` to reduce I/O in development.
 *
 * Query Parameters (v2)
 * - `product_ids` / `product_id`: As in v1.
 * - `category_ids` / `category_id`: As in v1.
 * - `staff_ids` / `staff_id`: As in v1.
 * - `min_date` / `max_date`: As in v1, parsed via `strtotime`.
 * - `min_timestamp` / `max_timestamp`: Integers (epoch seconds); override `min_date`/`max_date` when provided.
 * - `get_past_times`: `'true'` or `'false'` (default `'false'`).
 * - `page` / `per_page` / `limit`: Pagination controls; applies only if `per_page` or `limit` is provided.
 * - `paged_stream`: `'true'` to enable page-aware early stop generation. Works with `combine_staff=true`.
 * - `hide_unavailable`: `'true'` or `'false'`; when `'true'`, sold-out slots are excluded upstream where possible.
 * - `combine_staff`: `'true'` to return a union across staff (single row per time).
 * - `display_timezone`: IANA timezone string for display field projection (e.g. 'America/New_York').
 *
 * Response Schema
 * - `{ records: Array<Slot>, count: number }`
 * - `Slot` fields:
 *   - `product_id`, `product_name`
 *   - `date` (formatted)
 *   - `timestamp` (epoch seconds)
 *   - `duration`, `duration_unit`
 *   - `available`, `scheduled`
 *   - `staff_id`
 *
 * Example
 * - `GET /wc-appointments/v2/slots?product_id=123&min_timestamp=1731283200&max_timestamp=1731369600&hide_unavailable=true`
 */
class WC_Appointments_REST_V2_Slots_Controller extends WC_Appointments_REST_Slots_Controller {

	/**
	 * Constructor allows overriding the namespace for indexed routes.
	 *
	 * @param string|null $namespace Optional namespace override.
	 */
	public function __construct( ?string $namespace = null ) {
		$this->namespace = $namespace ?: WC_Appointments_REST_API::V2_NAMESPACE;
	}

	/**
	 * Get available appointment slots (v2).
	 *
	 * Route
	 * - `GET /{namespace}/slots` where `{namespace}` defaults to v2.
	 *
	 * Query Parameters
	 * - `product_ids` / `product_id` (optional)
	 * - `category_ids` / `category_id` (optional)
	 * - `staff_ids` / `staff_id` (optional)
	 * - `min_date` / `max_date` (optional): URL-encoded strings parseable by `strtotime`.
	 * - `min_timestamp` / `max_timestamp` (optional): Integers overriding `min_date`/`max_date` when present.
	 * - `get_past_times` (optional): `'true'` or `'false'` (default `'false'`).
     * - `page` / `per_page` / `limit` (optional): Pagination controls; applies only if `per_page` or `limit` is provided.
     * - `paged_stream` (optional): `'true'` to stream by day and stop after `page * per_page` records (only when `combine_staff=true`).
     * - `hide_unavailable` (optional): `'true'` to exclude sold-out slots.
     * - `combine_staff` (optional): `'true'` to union staff into a single combined record per slot.
	 *
	 * Behavior
	 * - Honors product min/max appointable dates by clamping requested range.
	 * - Uses indexed fast-path (`WC_Appointments_Controller::get_cached_*`) when enabled and within cache horizon. Falls back otherwise.
	 * - Skips transient writes and key indexing when `WC_APPOINTMENTS_DEBUG` is true.
	 * - Sorts by date ascending and paginates.
	 *
	 * Response
	 * - `{ records: Array<Slot>, count: number }`; includes `timestamp` in each record.
	 *
	 * @param WP_REST_Request<array<string, mixed>> $request Full details about the request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_items( $request ) {
		// Accept both plural and singular query params for compatibility.
		// product_ids / product_id
		$product_ids_raw = '';
		if ( ! empty( $request['product_ids'] ) ) {
			$product_ids_raw = $request['product_ids'];
		} elseif ( ! empty( $request['product_id'] ) ) {
			$product_ids_raw = $request['product_id'];
		}
		$product_ids = $product_ids_raw ? array_map( 'absint', explode( ',', $product_ids_raw ) ) : [];

		// staff_ids / staff_id
		$staff_ids_raw = '';
		if ( ! empty( $request['staff_ids'] ) ) {
			$staff_ids_raw = $request['staff_ids'];
		} elseif ( ! empty( $request['staff_id'] ) ) {
			$staff_ids_raw = $request['staff_id'];
		}
		$staff_ids      = $staff_ids_raw ? array_map( 'absint', explode( ',', $staff_ids_raw ) ) : [];
		$location_id    = absint( $request['location_id'] ?? 0 );
		$get_past_times = isset( $request['get_past_times'] ) && 'true' === $request['get_past_times'];

		$min_date_raw = urldecode( $request['min_date'] ?? '' );
		$max_date_raw = urldecode( $request['max_date'] ?? '' );
		$min_date = $min_date_raw ? strtotime( $min_date_raw ) : 0;
		$max_date = $max_date_raw ? strtotime( $max_date_raw ) : 0;

		// Allow numeric timestamp filters to override date strings when provided.
		$min_timestamp = absint( $request['min_timestamp'] ?? 0 );
		$max_timestamp = absint( $request['max_timestamp'] ?? 0 );
		if ( $min_timestamp ) {
			$min_date = $min_timestamp;
		}
		if ( $max_timestamp ) {
			$max_date = $max_timestamp;
		} elseif ( $max_date > 0 && $max_date_raw ) {
			// If max_date is a date-only string (YYYY-MM-DD format without time),
			// adjust to end of day to include all slots on that day.
			$trimmed_max = trim( $max_date_raw );
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $trimmed_max ) ) {
				$max_date = strtotime( '+1 day', $max_date ) - 1;
			}
		}

		// Extract display_timezone for Unified Slots Standardization.
		$display_timezone = isset( $request['display_timezone'] ) ? sanitize_text_field( $request['display_timezone'] ) : '';

		// Provider is the single source of truth for slot generation.
		return $this->get_items_via_provider( $request, $product_ids, $staff_ids, $min_date, $max_date, $get_past_times, $display_timezone, $location_id );
	}
	/**
	 * Provider-backed slot generation for get_items().
	 *
	 * Returns the v3-format hierarchical response from WC_Appointment_Slots_Provider,
	 * converting it to the v2 records format for backward compatibility.
	 *
	 * UNIFIED SLOTS STANDARDIZATION: When display_timezone is provided,
	 * slots will have pre-calculated display fields for that timezone.
	 *
	 * @since 5.3.0
	 *
	 * @param WP_REST_Request<array<string, mixed>> $request          Full request.
	 * @param array<int, int> $product_ids      Parsed product IDs.
	 * @param array<int, int> $staff_ids        Parsed staff IDs.
	 * @param int             $min_date         Min timestamp.
	 * @param int             $max_date         Max timestamp.
	 * @param bool            $get_past_times   Include past times.
	 * @param string          $display_timezone Customer display timezone (IANA format).
	 * @param int             $location_id      Optional location ID for occupancy / product allow-list.
	 * @return WP_REST_Response
	 */
	private function get_items_via_provider(
		WP_REST_Request $request,
		array $product_ids,
		array $staff_ids,
		int $min_date,
		int $max_date,
		bool $get_past_times,
		string $display_timezone = '',
		int $location_id = 0
	) {
		$level = sanitize_text_field( $request['level'] ?? 'slots' );
		$valid_levels = [ 'summary', 'days', 'slots', 'full' ];
		if ( ! in_array( $level, $valid_levels, true ) ) {
			$level = 'slots';
		}

		$hide_unavailable = isset( $request['hide_unavailable'] ) && 'true' === $request['hide_unavailable'];
		$timezone         = new \DateTimeZone( wc_timezone_string() );

		// If no product IDs specified, use all appointable products.
		if ( empty( $product_ids ) ) {
			$product_ids = \WC_Data_Store::load( 'product-appointment' )->get_appointable_product_ids();
		}

		// Category filtering.
		$category_ids_raw = '';
		if ( ! empty( $request['category_ids'] ) ) {
			$category_ids_raw = $request['category_ids'];
		} elseif ( ! empty( $request['category_id'] ) ) {
			$category_ids_raw = $request['category_id'];
		}
		$category_ids = $category_ids_raw ? array_map( 'absint', explode( ',', $category_ids_raw ) ) : [];
		if ( ! empty( $category_ids ) ) {
			$product_ids = array_filter(
				$product_ids,
				fn( $pid ) => has_term( $category_ids, 'product_cat', $pid ),
			);
		}

		$all_records = [];

		foreach ( $product_ids as $product_id ) {
			if ( ! wc_rest_check_post_permissions( 'product', 'read', $product_id ) ) {
				continue;
			}

			$product = get_wc_product_appointment( $product_id );
			if ( ! $product || ! is_wc_appointment_product( $product ) ) {
				continue;
			}

			if (
				$location_id > 0
				&& class_exists( 'WC_Appointments_Location' )
				&& $product->has_locations()
				&& ! WC_Appointments_Location::authorize_location_id( $product, $location_id )
			) {
				continue;
			}

			// Clamp to product min/max.
			$now              = current_time( 'timestamp' );
			$product_min_date = $product->get_min_date_a();
			$product_max_date = $product->get_max_date_a();
			$min = $min_date ?: strtotime( 'today' );
			$min_appointable  = strtotime( "+{$product_min_date['value']} {$product_min_date['unit']}", $now );
			if ( $min < $min_appointable ) {
				$min = $min_appointable;
			}
			$max = $max_date ?: strtotime( 'tomorrow' );
			$max_appointable = strtotime( "+{$product_max_date['value']} {$product_max_date['unit']}", $now );
			if ( $max > $max_appointable ) {
				$max = $max_appointable;
			}
			if ( $max <= $min ) {
				$max = strtotime( '+1 day', $min );
			}

			$start_date = date( 'Y-m-d', $min );
			$end_date   = date( 'Y-m-d', $max );

			// Use first staff_id if provided (and on product), otherwise null for all.
			$staff_id = null;
			if ( ! empty( $staff_ids ) ) {
				$requested      = (int) $staff_ids[0];
				$product_staff  = array_map( 'intval', (array) $product->get_staff_ids() );
				if ( $product_staff && ! in_array( $requested, $product_staff, true ) ) {
					continue;
				}
				$staff_id = $requested;
			}

			$collection = WC_Appointment_Slots_Provider::get_slots(
				$product,
				$start_date,
				$end_date,
				$staff_id,
				$level,
				$get_past_times,
				false, // use_cache
				$display_timezone,
				false,
				$location_id
			);

			$duration      = $product->get_duration();
			$duration_unit = $product->get_duration_unit();
			$product_name  = $product->get_title();

			// Convert slots to v2 records format with display fields.
			$product_records = [];
			foreach ( $collection->get_all_slots() as $slot ) {
				if ( $hide_unavailable && ! $slot->available ) {
					continue;
				}

				$record = [
					self::DATE          => $this->get_time( $slot->start_ts, $timezone ),
					self::TIMESTAMP     => $slot->start_ts,
					self::DURATION      => $duration,
					self::DURATION_UNIT => $duration_unit,
					self::AVAILABLE     => $slot->capacity_available,
					self::SCHEDULED     => $slot->capacity_booked,
					self::STAFF         => $slot->staff_id,
					self::ID            => $product_id,
					self::NAME          => $product_name,
				];

				// Include display fields when display_timezone was requested (Unified Slots Standardization).
				if ( '' !== $display_timezone ) {
					$record['business_day']            = $slot->business_day;
					$record['business_time']           = $slot->business_time;
					$record['display_day']             = $slot->display_day;
					$record['display_time']            = $slot->display_time;
					$record['display_date_formatted']  = $slot->display_date_formatted;
					$record['display_time_formatted']  = $slot->display_time_formatted;
					$record['status']                  = $slot->status;
					$record['bookable']                = $slot->bookable;
					$record['selection_value']         = $slot->selection_value;
					$record['selection_display']       = $slot->selection_display;
				}

				$product_records[] = $record;
			}

			foreach ( $product_records as $record ) {
				$all_records[] = $record;
			}
		}

		// Sort by timestamp ascending (more reliable than formatted date string).
		usort( $all_records, fn( array $a, array $b ): int => $a[ self::TIMESTAMP ] <=> $b[ self::TIMESTAMP ] );

		// Pagination.
		$per_page_param = absint( $request['per_page'] ?? 0 );
		$limit_param    = absint( $request['limit'] ?? 0 );
		$per_page       = 0 < $per_page_param ? $per_page_param : ( 0 < $limit_param ? $limit_param : 0 );
		$page           = max( 1, absint( $request['page'] ?? 1 ) );

		if ( 0 < $per_page ) {
			$availability = wc_appointments_paginated_availability( $all_records, $page, $per_page );
		} else {
			$availability = [ 'records' => $all_records, 'count' => count( $all_records ) ];
		}

		return new WP_REST_Response( $this->transient_expand( $availability ) );
	}
}
