<?php
/**
 * REST API v2 SSE stream for appointments.
 *
 * Endpoint: GET `/wp-json/wc-appointments/v2/sse`
 * Delegates output to WC_Appointments_SSE::emit_stream().
 */

class WC_Appointments_REST_V2_SSE_Controller extends WP_REST_Controller {

	public function __construct() {
		$this->namespace = WC_Appointments_REST_API::V2_NAMESPACE;
		$this->rest_base = 'sse';
	}

	public function register_routes(): void {
		register_rest_route(
		    $this->namespace,
		    '/' . $this->rest_base,
		    [
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => [ $this, 'stream' ],
				'permission_callback' => [ $this, 'check_permissions' ],
			],
		);
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Full details about the request.
	 * @return true|WP_Error
	 */
	public function check_permissions( $request ) {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_woocommerce' ) ) {
			return new WP_Error(
				'rest_forbidden',
				__( 'You do not have permission to access this stream.', 'woocommerce-appointments' ),
				[ 'status' => rest_authorization_required_code() ]
			);
		}
		return true;
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request Request.
	 * @return void
	 */
	public function stream( $request ): void {
		if ( class_exists( 'WC_Appointments_SSE' ) ) {
			WC_Appointments_SSE::emit_stream();
		}
		exit;
	}
}
