<?php
/**
 * REST API Products controller (appointments additions).
 *
 * Extends WooCommerce Products controller to support appointment-specific
 * fields and filtering by staff.
 *
 * Endpoint
 * - `GET /{namespace}/products` (defaults to v1 namespace)
 * - `GET /{namespace}/products/{id}`
 *
 * Permissions
 * - Public read for published products; mutations handled by Woo core.
 *
 * Query Parameters (additions)
 * - `staff` (array<int>|int): Filter products by associated staff IDs.
 *
 * Response Additions
 * - Appointment fields such as `has_price_label`, `pricing`, `qty`, `duration`,
 *   `interval`, `padding_duration`, `padding_after_duration`, `padding_duration_unit`,
 *   `min_date`, `max_date`, `cancel_limit`, `reschedule_limit`,
 *   `requires_confirmation`, `cal_color`, `availability_span`,
 *   `availability_autoselect`, `availability`, `has_restricted_days`, `restricted_days`,
 *   `staff_label`, `staff_assignment`, `staff_nopref`, `staff_ids`, `staff_base_costs`,
 *   `staff_qtys`, `location_label`.
 *
 * Defaults
 * - `status = publish`, `type = appointment` for collections.
 *
 * @package WooCommerce\Appointments\Rest\Controller
 */

/**
 * REST API Products controller class.
 */
class WC_Appointments_REST_Products_Controller extends WC_REST_Products_Controller {

	use WC_Appointments_Rest_Permission_Check;

	/**
	 * Endpoint namespace.
	 *
	 * @var string
	 */
	protected $namespace = WC_Appointments_REST_API::V1_NAMESPACE;

	/**
	 * Add support for filtering by staff.
	 *
	 * @param WP_REST_Request<array<string, mixed>> $request Request data.
	 *
	 * @return array<string, mixed>
	 */
	protected function prepare_objects_query( $request ) {

		$args = parent::prepare_objects_query( $request );

		if ( ! empty( $request['staff'] ) ) {
			$args['wc_appointments_staff'] = $request['staff'];

			add_filter( 'posts_join', [ $this, 'add_staff_filter' ], 10, 2 );
		}

		return apply_filters( 'woocommerce_appointments_products_rest_endpoint', $args );
	}

	/**
	 * Get objects.
	 *
	 * @param array<string, mixed> $query_args Query args.
	 *
	 * @return array<string, mixed>
	 */
	protected function get_objects( $query_args ) {
		$objects = parent::get_objects( $query_args );

		if ( ! empty( $query_args['wc_appointments_staff'] ) ) {
			remove_filter( 'posts_join', [ $this, 'add_staff_filter' ] );
		}

		return $objects;
	}

	/**
	 * Filters products by associated staff id(s).
	 *
	 * @param string   $join     Current join clauses.
	 * @param WP_Query $wp_query Current query object.
	 *
	 * @return string
	 */
	public function add_staff_filter( $join, $wp_query ) {
		if ( ! empty( $wp_query->query['wc_appointments_staff'] ) ) {
			$join .= WC_Product_Appointment_Data_Store_CPT::get_staff_filter_join_sql( (array) $wp_query->query['wc_appointments_staff'] );
		}
		return $join;
	}

	/**
	 * Get product data.
	 *
	 * @param  WC_Product_Appointment $product Product instance.
	 * @param  string             $context Request context.
	 *                                     Options: 'view' and 'edit'.
	 * @return array<string, mixed>
	 */
	protected function get_product_data( $product, $context = 'view' ) {
		$is_vaild_rest_type = 'appointment' === $product->get_type();
		$is_vaild_rest_type = apply_filters( "woocommerce_appointments_product_type_rest_check", $is_vaild_rest_type, $product );
		if ( ! $is_vaild_rest_type ) {
			wp_send_json( 'Not an appointable product', 400 );
		}

		$data = parent::get_product_data( $product, $context );

		$appointable_data = [
			'has_price_label'         => $product->get_has_price_label( $context ),
			'price_label'             => $product->get_price_label( $context ),
			'has_pricing'             => $product->get_has_pricing( $context ),
			'pricing'                 => $product->get_pricing( $context ),
			'qty'                     => $product->get_qty( $context ),
			'qty_basis'               => $product->get_qty_basis( $context ),
			'qty_min'                 => $product->get_qty_min( $context ),
			'qty_max'                 => $product->get_qty_max( $context ),
			'duration_unit'           => $product->get_duration_unit( $context ),
			'duration'                => $product->get_duration( $context ),
			'interval_unit'           => $product->get_interval_unit( $context ),
			'interval'                => $product->get_interval( $context ),
			'padding_duration_unit'   => $product->get_padding_duration_unit( $context ),
			'padding_duration'        => $product->get_padding_duration( $context ),
			'padding_after_duration'  => $product->get_padding_after_duration( $context ),
			'min_date_unit'           => $product->get_min_date_unit( $context ),
			'min_date'                => $product->get_min_date( $context ),
			'max_date_unit'           => $product->get_max_date_unit( $context ),
			'max_date'                => $product->get_max_date( $context ),
			'user_can_cancel'         => $product->get_user_can_cancel(),
			'cancel_limit_unit'       => $product->get_cancel_limit_unit( $context ),
			'cancel_limit'            => $product->get_cancel_limit( $context ),
			'user_can_reschedule'     => $product->get_user_can_reschedule(),
			'reschedule_limit_unit'   => $product->get_reschedule_limit_unit( $context ),
			'reschedule_limit'        => $product->get_reschedule_limit( $context ),
			'requires_confirmation'   => $product->get_requires_confirmation( $context ),
			'cal_color'               => $product->get_cal_color(),
			'availability_span'       => $product->get_availability_span( $context ),
			'availability_autoselect' => $product->get_availability_autoselect( $context ),
			'availability'            => $product->get_availability( $context ),
			'has_restricted_days'     => $product->get_has_restricted_days( $context ),
			'restricted_days'         => $product->get_restricted_days( $context ),
			'staff_label'             => $product->get_staff_label( $context ),
			'staff_assignment'        => $product->get_staff_assignment( $context ),
			'staff_nopref'            => $product->get_staff_nopref( $context ),
			'staff_ids'               => $product->get_staff_ids( $context ),
			'staff_base_costs'        => $product->get_staff_base_costs( $context ),
			'staff_qtys'              => $product->get_staff_qtys( $context ),
			'location_label'          => $product->get_location_label( $context ),
		];

		return array_merge( $data, $appointable_data );
	}

	/**
	 * Update the collection params.
	 *
	 * Adds new options for 'orderby', and new parameters 'cat_operator', 'attr_operator'.
	 *
	 * @return array<string, mixed>
	 */
	public function get_collection_params() {
		$params          = parent::get_collection_params();
		$params['staff'] = [
			'description'       => 'Limit result set to products assigned a specific staff ID.',
			'type'              => 'array',
			'items'             => [
				'type' => 'integer',
			],
			'sanitize_callback' => 'wp_parse_id_list',
			'validate_callback' => 'rest_validate_request_arg',
		];

		$params['status']['default'] = 'publish';
		$params['type']['default']   = 'appointment';
		$params['type']['enum']      = [ 'appointment' ];

		return $params;
	}

	/**
	 * @param WP_REST_Request<array<string, mixed>> $request
	 * @param bool $creating
	 *
	 * @return WC_Data|WP_Error
	 */
	protected function prepare_object_for_database( $request, $creating = false ) {
		$request->set_param( 'type', 'appointment' );

		$product = parent::prepare_object_for_database( $request, $creating );

		if ( ! $product instanceof WC_Product_Appointment ) {
			wp_send_json( 'Not an appointable product', 400 );
		}

		foreach ( $this->get_appointment_product_properties() as $prop ) {
			$method = 'set_' . $prop;
			if ( isset( $request[ $prop ] ) && is_callable( [ $product, $method ] ) ) {
				$product->$method( $request[ $prop ] );
			}
		}

		if ( isset( $request['can_be_cancelled'] ) ) {
			$product->set_user_can_cancel( $request['can_be_cancelled'] );
		}

		if ( isset( $request['can_be_rescheduled'] ) ) {
			$product->set_user_can_reschedule( $request['can_be_rescheduled'] );
		}

		// Availability rules use a separate data store; persist after product save.
		if ( isset( $request['availability'] ) || isset( $request['availability_deleted'] ) ) {
			add_action( 'woocommerce_rest_insert_product_object', [ $this, 'save_availability_on_rest_insert' ], 10, 2 );
		}

		return $product;
	}

	/**
	 * Persist availability rules after a product is saved via REST.
	 *
	 * - `availability` present: full replace (like images/pricing); unstated rule ids are deleted.
	 * - `availability_deleted` only: remove those rule ids from this product (others unchanged).
	 *
	 * @param WC_Data         $product Product that was just saved.
	 * @param WP_REST_Request<array<string, mixed>> $request Request object.
	 */
	public function save_availability_on_rest_insert( $product, $request ): void {
		remove_action( 'woocommerce_rest_insert_product_object', [ $this, 'save_availability_on_rest_insert' ] );

		if ( ! $product instanceof WC_Product_Appointment ) {
			return;
		}

		$data_store   = WC_Data_Store::load( 'appointments-availability' );
		$product_id   = wc_appointments_get_product_id_for_availability( (int) $product->get_id() );
		$kind         = WC_Appointments_Availability::KIND_PRODUCT;
		$existing_ids = array_filter( array_map( [ $this, 'availability_rule_id_from_array' ], $product->get_availability( 'edit' ) ) );

		if ( isset( $request['availability'] ) ) {
			$rules      = array_values( array_filter( (array) $request['availability'], [ $data_store, 'is_rule_valid' ] ) );
			$new_ids    = array_filter( array_map( [ $this, 'availability_rule_id_from_array' ], $rules ) );
			$delete_ids = array_diff( $existing_ids, $new_ids );
			$data_store->save_rules( $rules, $kind, $product_id, $delete_ids );
			return;
		}

		$delete_ids = array_intersect( array_map( 'absint', (array) $request['availability_deleted'] ), $existing_ids );
		if ( $delete_ids ) {
			$data_store->save_rules( [], $kind, $product_id, $delete_ids );
		}
	}

	/**
	 * Extract rule ID from an availability array (handles id and ID keys).
	 *
	 * @param array<string, mixed> $rule Rule row from GET or request payload.
	 * @return int
	 */
	private function availability_rule_id_from_array( array $rule ): int {
		return absint( $rule['id'] ?? $rule['ID'] ?? 0 );
	}

	/**
	 * Get the Product's schema, conforming to JSON Schema.
	 *
	 * @return array<string, mixed>
	 */
	public function get_item_schema() {
		// TODO: Implement auto documentation here.
		return parent::get_item_schema();
	}

	/**
	 * Map of appointment product properties persisted via generic set_{prop} loop.
	 *
	 * `availability` is excluded — separate data store; see save_availability_on_rest_insert().
	 * Write-only: `availability_deleted` (array of rule ids) removes rules without replacing the full list.
	 *
	 * @return array<int, string>
	 */
	protected function get_appointment_product_properties() {
		return [
			'has_price_label',
			'price_label',
			'has_pricing',
			'pricing',
			'qty',
			'qty_basis',
			'qty_min',
			'qty_max',
			'duration_unit',
			'duration',
			'interval_unit',
			'interval',
			'padding_duration_unit',
			'padding_duration',
			'padding_after_duration',
			'min_date_unit',
			'min_date',
			'max_date_unit',
			'max_date',
			'user_can_cancel',
			'cancel_limit_unit',
			'cancel_limit',
			'user_can_reschedule',
			'reschedule_limit_unit',
			'reschedule_limit',
			'requires_confirmation',
			'cal_color',
			'availability_span',
			'availability_autoselect',
			'has_restricted_days',
			'restricted_days',
			'staff_label',
			'staff_assignment',
			'staff_nopref',
			'staff_ids',
			'staff_base_costs',
			'staff_qtys',
			'location_label',
		];
	}
}
