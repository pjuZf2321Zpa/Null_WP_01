<?php
/**
 * Virtual meetings orchestrator (Google Meet v1).
 *
 * Meeting data lives on the appointment. Never written into the location snapshot.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Meetings helpers + lifecycle hooks.
 *
 * @since 5.5.0
 */
class WC_Appointments_Meetings {

	const PROVIDER_NONE        = 'none';
	const PROVIDER_GOOGLE_MEET = 'google_meet';
	const STATUS_PENDING       = 'pending';
	const STATUS_CREATED       = 'created';
	const STATUS_FAILED        = 'failed';
	const STATUS_CANCELLED     = 'cancelled';

	/**
	 * Registered providers keyed by id.
	 *
	 * @var array<string, WC_Appointments_Meeting_Provider>
	 */
	private static $providers = [];

	/**
	 * Boot hooks and providers.
	 *
	 * @since 5.5.0
	 */
	public static function init(): void {
		self::register_providers();

		add_action( 'woocommerce_appointment_confirmed', [ __CLASS__, 'maybe_mark_failed_without_gcal' ], 20 );
		add_action( 'woocommerce_appointment_paid', [ __CLASS__, 'maybe_mark_failed_without_gcal' ], 20 );
		add_action( 'woocommerce_appointment_complete', [ __CLASS__, 'maybe_mark_failed_without_gcal' ], 20 );

		add_action( 'woocommerce_appointment_cancelled', [ __CLASS__, 'on_appointment_cancelled' ] );
		add_action( 'woocommerce_trash_appointment', [ __CLASS__, 'on_appointment_cancelled' ] );
	}

	/**
	 * Register built-in providers.
	 *
	 * @since 5.5.0
	 */
	private static function register_providers(): void {
		self::$providers = [
			self::PROVIDER_GOOGLE_MEET => new WC_Appointments_Google_Meet_Provider(),
		];

		/**
		 * Filter registered meeting providers.
		 *
		 * @since 5.5.0
		 *
		 * @param array<string, WC_Appointments_Meeting_Provider> $providers Providers.
		 */
		self::$providers = apply_filters( 'wc_appointments_meeting_providers', self::$providers );
	}

	/**
	 * Product provider options for admin select.
	 *
	 * @since 5.5.0
	 *
	 * @return array<string, string>
	 */
	public static function get_product_provider_options(): array {
		$options = [
			self::PROVIDER_NONE => __( 'None', 'woocommerce-appointments' ),
		];
		foreach ( self::$providers as $id => $provider ) {
			$options[ $id ] = $provider->get_name();
		}
		return $options;
	}

	/**
	 * Get a registered provider.
	 *
	 * @since 5.5.0
	 *
	 * @param string $id Provider id.
	 * @return WC_Appointments_Meeting_Provider|null
	 */
	public static function get_provider( string $id ) {
		return self::$providers[ $id ] ?? null;
	}

	/**
	 * Whether a Meet (or future provider) should be created for this appointment.
	 *
	 * Appointment meeting_provider (snapshotted at location apply) is google_meet and location kind is online.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return bool
	 */
	public static function should_create_for( $appointment ): bool {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return false;
		}

		if ( self::PROVIDER_GOOGLE_MEET !== $appointment->get_meeting_provider() ) {
			return false;
		}

		$snapshot = $appointment->get_location();
		$kind     = isset( $snapshot['kind'] ) ? (string) $snapshot['kind'] : '';

		return WC_Appointments_Location::KIND_ONLINE === $kind;
	}

	/**
	 * Customer-facing access string: join URL → static location URL → instructions.
	 *
	 * Does not mutate the location snapshot.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return string
	 */
	public static function get_customer_access_display( $appointment ): string {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return '';
		}

		$join = self::get_my_account_join_context( $appointment )['url'];
		if ( '' !== $join ) {
			return $join;
		}

		$snapshot = $appointment->get_location();
		if ( ! empty( $snapshot['instructions'] ) ) {
			return (string) $snapshot['instructions'];
		}

		return '';
	}

	/**
	 * Location display for emails / summary when a join URL is shown separately (omit static URL).
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return string
	 */
	public static function format_location_display( $appointment ): string {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return '';
		}

		// Same join preference as My Account / emails (Meet or static).
		if ( '' === self::get_my_account_join_context( $appointment )['url'] ) {
			return $appointment->get_location_display();
		}

		$snapshot = $appointment->get_location();
		if ( empty( $snapshot ) || ! class_exists( 'WC_Appointments_Location' ) ) {
			return '';
		}

		$copy = $snapshot;
		unset( $copy['static_join_url'] );

		return WC_Appointments_Location::format_snapshot_for_display( $copy );
	}

	/**
	 * ICS / GCal LOCATION field: join URL when available, else location display.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return string
	 */
	public static function get_calendar_location_field( $appointment ): string {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return '';
		}

		$join = self::get_my_account_join_context( $appointment )['url'];
		if ( '' !== $join ) {
			return $join;
		}

		return $appointment->get_location_display();
	}

	/**
	 * Write meeting meta from a Google Calendar event response.
	 *
	 * Caller is responsible for saving the appointment.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment                $appointment Appointment.
	 * @param array<string, mixed>|false|null $response    Decoded GCal event.
	 */
	public static function apply_from_gcal_event( $appointment, $response ): void {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return;
		}

		if ( ! self::should_create_for( $appointment ) && self::PROVIDER_GOOGLE_MEET !== $appointment->get_meeting_provider() ) {
			return;
		}

		if ( ! is_array( $response ) ) {
			if ( self::should_create_for( $appointment ) && self::STATUS_CREATED !== $appointment->get_meeting_status() ) {
				$appointment->set_meeting_provider( self::PROVIDER_GOOGLE_MEET );
				$appointment->set_meeting_status( self::STATUS_FAILED );
			}
			return;
		}

		$join = self::extract_join_url_from_gcal_event( $response );
		if ( '' === $join ) {
			if ( ! self::should_create_for( $appointment ) || self::STATUS_CREATED === $appointment->get_meeting_status() ) {
				return;
			}

			// Hard fail only; pending / empty conference shell leaves status alone so sync retries
			// with the same stable requestId (see get_gcal_conference_create_request).
			$status_code = strtolower( (string) ( $response['conferenceData']['createRequest']['status']['statusCode'] ?? '' ) );
			if ( 'failure' === $status_code || empty( $response['conferenceData'] ) ) {
				$appointment->set_meeting_provider( self::PROVIDER_GOOGLE_MEET );
				$appointment->set_meeting_status( self::STATUS_FAILED );
			}
			return;
		}

		$conference_id = '';
		if ( ! empty( $response['conferenceData']['conferenceId'] ) ) {
			$conference_id = (string) $response['conferenceData']['conferenceId'];
		}

		$appointment->set_meeting_provider( self::PROVIDER_GOOGLE_MEET );
		$appointment->set_meeting_id( $conference_id );
		$appointment->set_meeting_join_url( $join );
		$appointment->set_meeting_host_url( '' );
		$appointment->set_meeting_password( '' );
		$appointment->set_meeting_status( self::STATUS_CREATED );
	}

	/**
	 * Extract video join URL from a GCal event payload.
	 *
	 * @since 5.5.0
	 *
	 * @param array<string, mixed> $event Event.
	 * @return string
	 */
	public static function extract_join_url_from_gcal_event( array $event ): string {
		if ( ! empty( $event['hangoutLink'] ) ) {
			return esc_url_raw( (string) $event['hangoutLink'] );
		}

		if ( empty( $event['conferenceData']['entryPoints'] ) || ! is_array( $event['conferenceData']['entryPoints'] ) ) {
			return '';
		}

		foreach ( $event['conferenceData']['entryPoints'] as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$type = isset( $entry['entryPointType'] ) ? (string) $entry['entryPointType'] : '';
			if ( 'video' === $type && ! empty( $entry['uri'] ) ) {
				return esc_url_raw( (string) $entry['uri'] );
			}
		}

		return '';
	}

	/**
	 * Clear / cancel meeting data (does not touch location snapshot).
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @param bool           $save        Whether to save.
	 */
	public static function clear_meeting( $appointment, bool $save = true ): void {
		if ( ! is_a( $appointment, 'WC_Appointment' ) ) {
			return;
		}

		if ( '' === $appointment->get_meeting_provider() && '' === $appointment->get_meeting_status() ) {
			return;
		}

		$appointment->set_meeting_status( self::STATUS_CANCELLED );
		$appointment->set_meeting_join_url( '' );
		$appointment->set_meeting_host_url( '' );
		$appointment->set_meeting_password( '' );
		$appointment->set_meeting_id( '' );

		if ( $save ) {
			$appointment->skip_status_transition_events();
			$appointment->save();
		}
	}

	/**
	 * Cancel hook.
	 *
	 * @since 5.5.0
	 *
	 * @param int $appointment_id Appointment ID.
	 */
	public static function on_appointment_cancelled( $appointment_id ): void {
		$appointment = get_wc_appointment( $appointment_id );
		if ( ! $appointment ) {
			return;
		}
		self::clear_meeting( $appointment, true );
	}

	/**
	 * If Meet is required but GCal is not connected, mark failed (static URL remains for display).
	 *
	 * @since 5.5.0
	 *
	 * @param int $appointment_id Appointment ID.
	 */
	public static function maybe_mark_failed_without_gcal( $appointment_id ): void {
		$appointment = get_wc_appointment( $appointment_id );
		if ( ! $appointment || ! self::should_create_for( $appointment ) ) {
			return;
		}

		if ( self::STATUS_CREATED === $appointment->get_meeting_status() ) {
			return;
		}

		$provider = self::get_provider( self::PROVIDER_GOOGLE_MEET );
		if ( $provider && $provider->is_configured() ) {
			return;
		}

		$appointment->set_meeting_provider( self::PROVIDER_GOOGLE_MEET );
		$appointment->set_meeting_status( self::STATUS_FAILED );
		$appointment->skip_status_transition_events();
		$appointment->save();
	}

	/**
	 * My Account join row: Meet URL, else static online URL, else pending when Meet is expected.
	 *
	 * Also the join URL used by emails, order summary, and calendar LOCATION.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return array{url:string,pending:bool,start:int,end:int}
	 */
	public static function get_my_account_join_context( $appointment ): array {
		$empty = [
			'url'     => '',
			'pending' => false,
			'start'   => 0,
			'end'     => 0,
		];

		if ( ! is_a( $appointment, 'WC_Appointment' ) || $appointment->has_status( WC_Appointments_Constants::STATUS_CANCELLED ) ) {
			return $empty;
		}

		$url = $appointment->get_meeting_join_url();
		if ( '' === $url ) {
			$snapshot = $appointment->get_location();
			$url      = (string) ( $snapshot['static_join_url'] ?? '' );
		}

		$pending = ( '' === $url ) && self::should_create_for( $appointment );
		if ( '' === $url && ! $pending ) {
			return $empty;
		}

		$countdown = ! $appointment->has_status( WC_Appointments_Constants::STATUS_COMPLETE );

		return [
			'url'     => $url,
			'pending' => $pending,
			'start'   => $countdown ? (int) $appointment->get_start() : 0,
			'end'     => $countdown ? (int) $appointment->get_end() : 0,
		];
	}

	/**
	 * Echo Join / pending + countdown for My Account action cells.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 */
	public static function render_my_account_join( $appointment ): void {
		$ctx = self::get_my_account_join_context( $appointment );
		if ( '' === $ctx['url'] && ! $ctx['pending'] ) {
			return;
		}

		if ( '' !== $ctx['url'] ) {
			printf(
				'<a href="%1$s" class="woocommerce-button button anowrap wca-join-meeting" target="_blank" rel="noopener noreferrer">%2$s</a>',
				esc_url( $ctx['url'] ),
				esc_html__( 'Join', 'woocommerce-appointments' )
			);
		} else {
			printf(
				'<span class="adesc wca-join-pending">%s</span>',
				esc_html__( 'Link will appear when ready', 'woocommerce-appointments' )
			);
		}

		if ( $ctx['start'] <= 0 || $ctx['end'] <= 0 ) {
			return;
		}

		$now = time();
		if ( $now >= $ctx['end'] ) {
			$label = __( 'Ended', 'woocommerce-appointments' );
		} elseif ( $now >= $ctx['start'] ) {
			$label = __( 'In progress', 'woocommerce-appointments' );
		} else {
			/* translators: %s: relative time until start (e.g. 2 hours) */
			$label = sprintf( __( 'Starts in %s', 'woocommerce-appointments' ), human_time_diff( $now, $ctx['start'] ) );
		}

		printf(
			'<span class="adesc wca-join-countdown" data-start="%1$s" data-end="%2$s">%3$s</span>',
			esc_attr( (string) absint( $ctx['start'] ) ),
			esc_attr( (string) absint( $ctx['end'] ) ),
			esc_html( $label )
		);
	}

	/**
	 * Whether the sync payload should request a new Meet conference.
	 *
	 * @since 5.5.0
	 *
	 * @param WC_Appointment $appointment Appointment.
	 * @return bool
	 */
	public static function needs_gcal_conference_create( $appointment ): bool {
		if ( ! self::should_create_for( $appointment ) ) {
			return false;
		}

		return self::STATUS_CREATED !== $appointment->get_meeting_status();
	}

	/**
	 * conferenceData.createRequest fragment for GCal event body.
	 *
	 * Stable requestId so retries do not create a second Meet room.
	 *
	 * @since 5.5.0
	 *
	 * @param int $appointment_id Appointment ID.
	 * @return array<string, mixed>
	 */
	public static function get_gcal_conference_create_request( int $appointment_id ): array {
		return [
			'createRequest' => [
				'requestId'             => 'wca-' . $appointment_id,
				'conferenceSolutionKey' => [
					'type' => 'hangoutsMeet',
				],
			],
		];
	}
}

WC_Appointments_Meetings::init();
