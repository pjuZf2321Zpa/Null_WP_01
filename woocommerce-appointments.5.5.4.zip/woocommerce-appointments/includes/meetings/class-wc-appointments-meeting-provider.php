<?php
/**
 * Thin abstract for virtual meeting providers.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Meeting provider contract (v1: Google Meet only).
 *
 * @since 5.5.0
 */
abstract class WC_Appointments_Meeting_Provider {

	/**
	 * Provider slug (e.g. google_meet).
	 *
	 * @since 5.5.0
	 *
	 * @return string
	 */
	abstract public function get_id(): string;

	/**
	 * Human-readable name.
	 *
	 * @since 5.5.0
	 *
	 * @return string
	 */
	abstract public function get_name(): string;

	/**
	 * Whether site credentials / OAuth are ready for this provider.
	 *
	 * @since 5.5.0
	 *
	 * @return bool
	 */
	abstract public function is_configured(): bool;
}
