<?php
/**
 * Google Meet via existing Google Calendar OAuth / sync.
 *
 * @package WooCommerce Appointments
 * @since   5.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Google Meet provider (conferenceData on GCal events).
 *
 * @since 5.5.0
 */
class WC_Appointments_Google_Meet_Provider extends WC_Appointments_Meeting_Provider {

	/**
	 * {@inheritdoc}
	 */
	public function get_id(): string {
		return 'google_meet';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_name(): string {
		return __( 'Google Meet', 'woocommerce-appointments' );
	}

	/**
	 * Site or staff GCal connected (same gate sync uses for outbound writes).
	 *
	 * {@inheritdoc}
	 */
	public function is_configured(): bool {
		if ( ! function_exists( 'wc_appointments_gcal' ) ) {
			return false;
		}

		$gcal = wc_appointments_gcal();
		if ( ! $gcal ) {
			return false;
		}

		if ( $gcal->is_calendar_set() && get_option( 'wc_appointments_gcal_refresh_token' ) ) {
			return true;
		}

		$staff = $gcal->get_synced_staff_ids();
		return ! empty( $staff );
	}
}