<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Gets appointments
 */
class WC_Appointments_Controller {

	/**
	 * Render time-slots HTML directly from a Collection (native path).
	 *
	 * UNIFIED SLOTS STANDARDIZATION (Phase G):
	 * This method is now a thin delegate to WC_Appointment_Slots_Time_Columns_Renderer.
	 * All clock logic, bucketing, and HTML generation lives in the slots subsystem.
	 *
	 * @since 5.3.0
	 * @since 5.3.6 Refactored to thin delegate (Phase G implementation).
	 *
	 * @param WC_Product_Appointment          $product    Product instance.
	 * @param WC_Appointment_Slots_Collection $collection Collection of slots.
	 * @param array<string, mixed>            $args       {
	 *     @type int    $time_to_check    Currently selected time. Default 0.
	 *     @type int    $timestamp        Selected calendar day timestamp. Default 0.
	 *     @type string $timezone         Customer timezone string. Default 'UTC'.
	 *     @type bool   $include_sold_out Include fully-booked slots. Default false.
	 *     @type int    $staff_id         Staff ID (for legacy filter compat). Default 0.
	 * }
	 * @return string HTML markup.
	 */
	public static function render_time_slots_html(
		WC_Product_Appointment $product,
		WC_Appointment_Slots_Collection $collection,
		array $args = []
	): string {
		$args = wp_parse_args( $args, [
			'time_to_check'    => 0,
			'timestamp'        => 0,
			'timezone'         => 'UTC',
			'include_sold_out' => false,
			'staff_id'         => 0,
			'intervals'        => [],
			'from'             => 0,
			'to'               => 0,
		] );

		$result = WC_Appointment_Slots_Time_Columns_Renderer::render( $product, $collection, $args );

		return apply_filters(
			'woocommerce_appointments_time_slots_html',
			$result['html'],
			$result['timestamps'],
			$args['intervals'],
			$args['time_to_check'],
			$args['staff_id'],
			$args['from'],
			$args['to'],
			$args['timezone'],
			$product,
			[]
		);
	}

	private static function slot_matches_requested_range( WC_Appointment_Slot $slot, int $start_date, int $end_date ): bool {
		$match = false;
		// Match start with the same ±120s tolerance already used for end (exclusive
		// midnight boundaries can differ by a few seconds between DateTime paths).
		if ( abs( $slot->start_ts - $start_date ) <= 120 ) {
			if ( $slot->end_ts === $end_date || $end_date === $slot->end_ts - 1 ) {
				$match = true;
			} else {
				$end_diff = abs( $end_date - $slot->end_ts );
				if ( $end_diff <= 120 ) {
					$match = true;
				}
			}
		}

		return $match;
	}

	/**
	 * @param WC_Appointment_Slots_Collection $collection Slots collection.
	 * @param int                             $start_date Range start.
	 * @param int                             $end_date   Range end.
	 * @param WC_Product_Appointment|null     $product    Product (optional).
	 * @param int|null                        $staff_id   Staff scope.
	 */
	private static function get_exact_available_capacity_for_slot( WC_Appointment_Slots_Collection $collection, int $start_date, int $end_date, $product = null, ?int $staff_id = null ): int {
		$available_capacity = 0;

		foreach ( $collection->get_all_slots() as $slot ) {
			if ( null !== $staff_id && $staff_id > 0 && (int) $slot->staff_id !== $staff_id ) {
				continue;
			}
			if ( ! self::slot_matches_requested_range( $slot, $start_date, $end_date ) ) {
				continue;
			}
			$available_capacity += max( 0, (int) $slot->capacity_available );
		}

		$range_days = (int) round( ( $end_date - $start_date ) / DAY_IN_SECONDS );

		$base_day_duration = 0;
		$use_multi_day_start_row = true;
		$duration_unit           = is_object( $product ) && method_exists( $product, 'get_duration_unit' )
			? (string) $product->get_duration_unit()
			: '';
		if ( in_array( $duration_unit, [ 'day', 'night' ], true ) && method_exists( $product, 'get_duration' ) ) {
			$base_day_duration = (int) $product->get_duration();
			if ( $base_day_duration > 0 && $range_days > $base_day_duration ) {
				$use_multi_day_start_row = false;
			}
		}

		// Multi-day daily products: the engine generates individual 1-day slots
		// but the requested range spans multiple days. Check that every day in
		// the range has an available slot; return the minimum (bottleneck) capacity.
		if ( 0 === $available_capacity ) {
			// Include single-day appointments: exact slot match can fail on end boundary
			// while the per-day slot at start midnight still has capacity (all-day / day unit).
			if ( $range_days >= 1 && $use_multi_day_start_row ) {
				$available_capacity = self::get_day_civil_span_capacity( $collection, $start_date, $range_days, false, $staff_id );
			}
		}

		// Extended range fallback for addon-extended time-based appointments.
		// When add-ons extend duration beyond the base slot interval (e.g. 12h product + 12h addon = 24h),
		// the requested range spans multiple consecutive slots. Verify that every slot covering the
		// extended range has capacity; return the minimum (bottleneck) across all covering slots.
		if ( 0 === $available_capacity ) {
			if (
				in_array( $duration_unit, [ 'day', 'night' ], true )
				&& $base_day_duration > 0
				&& $range_days > $base_day_duration
			) {
				// Day/night slots use Fake UTC civil keys; walk each day in the posted span (min capacity).
				$available_capacity = self::get_day_civil_span_capacity( $collection, $start_date, $range_days, true, $staff_id );
			} else {
				$available_capacity = self::get_extended_range_available_capacity( $collection, $start_date, $end_date, $product, $staff_id );
			}
		}

		return $available_capacity;
	}

	/**
	 * Read available capacity for a multi-calendar-day range on day-unit products.
	 *
	 * The slots engine emits one slot per calendar day and, when duration &gt; 1 day,
	 * applies apply_multi_day_start_bottleneck_to_day_slots() so the D-day bottleneck
	 * is stored on the slot that starts that calendar day.
	 * Later days in the same booking window can legitimately have capacity_available 0 on
	 * their *start* rows (a new booking cannot start there) while the requested start date
	 * remains valid. Therefore validation must use the slot row(s) at the requested
	 * start date only—not a per-day walk of start-slot capacities.
	 *
	 * @param WC_Appointment_Slots_Collection $collection Slots collection.
	 * @param int                             $start_date Range start timestamp (midnight).
	 * @param int                             $range_days Number of days in the range (caller contract; bottleneck uses product duration in engine).
	 * @return int
	 */
	/**
	 * Day-unit capacity on Fake UTC civil-day keys ($min_across_days: start row only vs span bottleneck).
	 *
	 * @param WC_Appointment_Slots_Collection $collection       Slots collection.
	 * @param int                             $start_date       Range start token.
	 * @param int                             $range_days       Posted span in days (addon path only).
	 * @param bool                            $min_across_days  True = min capacity across each day in span.
	 * @return int
	 */
	private static function get_day_civil_span_capacity( WC_Appointment_Slots_Collection $collection, int $start_date, int $range_days, bool $min_across_days, ?int $staff_id = null ): int {
		$by_key = [];
		foreach ( $collection->get_all_slots() as $slot ) {
			if ( null !== $staff_id && $staff_id > 0 && (int) $slot->staff_id !== $staff_id ) {
				continue;
			}
			if ( $slot->duration_minutes < 1440 ) {
				continue;
			}
			$by_key[ wc_appointments_day_slot_midnight_key( $slot->start_ts ) ][] = $slot;
		}

		$start_key = wc_appointments_day_slot_midnight_key( $start_date );
		$days      = $min_across_days ? max( 1, $range_days ) : 1;
		$min_cap   = PHP_INT_MAX;

		for ( $i = 0; $i < $days; $i++ ) {
			$key = $start_key + ( $i * DAY_IN_SECONDS );
			if ( ! isset( $by_key[ $key ] ) ) {
				return 0;
			}
			$day_sum = 0;
			foreach ( $by_key[ $key ] as $slot ) {
				if ( null !== $staff_id && $staff_id > 0 && (int) $slot->staff_id !== $staff_id ) {
					continue;
				}
				$day_sum += max( 0, (int) $slot->capacity_available );
			}
			if ( ! $day_sum ) {
				return 0;
			}
			if ( ! $min_across_days ) {
				return $day_sum;
			}
			$min_cap = min( $min_cap, $day_sum );
		}

		return PHP_INT_MAX === $min_cap ? 0 : $min_cap;
	}

	/**
	 * Check extended range availability for addon-extended time-based appointments.
	 *
	 * When add-ons extend duration beyond the base slot interval, the requested range
	 * spans multiple consecutive time-based slots. This method verifies that every slot
	 * covering the extended range has capacity and returns the minimum (bottleneck).
	 *
	 * Example: 12h product + 12h addon = 24h range starting at 10:00.
	 * The engine generates two 12h slots: [10:00-22:00] and [22:00-10:00+1].
	 * Both must have capacity for the extended appointment to be valid.
	 *
	 * @param WC_Appointment_Slots_Collection $collection Slots collection.
	 * @param int                             $start_date Range start timestamp.
	 * @param int                             $end_date   Range end timestamp.
	 * @param WC_Product_Appointment|null     $product    Product (optional).
	 * @param int|null                        $staff_id   Staff scope.
	 * @return int Minimum available capacity across all covering slots, or 0 if any gap/unavailable.
	 */
	private static function get_extended_range_available_capacity( WC_Appointment_Slots_Collection $collection, int $start_date, int $end_date, $product = null, ?int $staff_id = null ): int {
		$padding_seconds = 0;
		if ( is_object( $product ) && method_exists( $product, 'get_duration_unit' ) && method_exists( $product, 'get_padding_duration' ) ) {
			$unit = (string) $product->get_duration_unit();
			if ( in_array( $unit, [ 'minute', 'hour' ], true ) ) {
				$padding_seconds = max( 0, (int) $product->get_padding_duration() ) * MINUTE_IN_SECONDS;
			}
		}

		// Time-based grid: slot rows use product duration for end_ts, but starts are spaced by
		// base_interval. When duration < base_interval, addon-extended bookings still occupy the
		// full grid cell (e.g. 30m slots on 60m steps + 10m addon = 40m fits before the next start).
		$grid_step_seconds = 0;
		if ( is_object( $product ) && method_exists( $product, 'get_duration_unit' ) && method_exists( $product, 'get_intervals' ) ) {
			$unit_grid = (string) $product->get_duration_unit();
			if ( in_array( $unit_grid, [ 'minute', 'hour' ], true ) ) {
				$iv = $product->get_intervals();
				if ( isset( $iv[1] ) ) {
					$grid_step_seconds = max( 0, (int) $iv[1] ) * MINUTE_IN_SECONDS;
				}
			}
		}

		// Collect all slots that overlap with the requested range.
		$covering_slots = [];
		foreach ( $collection->get_all_slots() as $slot ) {
			if ( null !== $staff_id && $staff_id > 0 && (int) $slot->staff_id !== $staff_id ) {
				continue;
			}
			// Slot overlaps if: slot_start < end_date AND slot_end > start_date.
			if ( $slot->start_ts < $end_date && $slot->end_ts > $start_date ) {
				$covering_slots[] = $slot;
			}
		}

		if ( empty( $covering_slots ) ) {
			return 0;
		}

		// Sort by start time.
		usort( $covering_slots, static function ( $a, $b ) {
			return $a->start_ts - $b->start_ts;
		} );

		// Anchor on a grid row that starts at the requested time (±120s), not one that merely
		// contains it (an overlap-only row undercounts addon-extended ranges).
		$tolerance = 120;
		$slice_from  = null;
		foreach ( $covering_slots as $idx => $slot ) {
			if ( abs( $slot->start_ts - $start_date ) <= $tolerance && $slot->end_ts > $start_date ) {
				$slice_from = $idx;
				break;
			}
		}
		// Off-grid starts (legacy or manually edited appointments) have no aligned row;
		// fall back to the first covering row instead of failing closed.
		if ( null === $slice_from ) {
			foreach ( $covering_slots as $idx => $slot ) {
				if ( $slot->start_ts <= $start_date + $tolerance && $slot->end_ts > $start_date ) {
					$slice_from = $idx;
					break;
				}
			}
		}
		if ( null === $slice_from ) {
			return 0;
		}
		$covering_slots = array_slice( $covering_slots, $slice_from );

		// Walk through covering slots: verify continuous coverage and track minimum capacity.
		$min_capacity  = PHP_INT_MAX;
		$covered_until = $start_date;

		foreach ( $covering_slots as $slot ) {
			// Gap in coverage — range is not fully appointable.
			if ( $slot->start_ts > $covered_until + 120 ) {
				return 0;
			}

			$capacity = max( 0, (int) $slot->capacity_available );
			if ( 0 === $capacity ) {
				return 0;
			}

			$min_capacity  = min( $min_capacity, $capacity );
			// Include explicit padding for time-based products.
			$covered_until = max( $covered_until, $slot->end_ts + $padding_seconds );
			if ( $grid_step_seconds > 0 ) {
				$covered_until = max( $covered_until, $slot->start_ts + $grid_step_seconds );
			}

			// Fully covered.
			if ( $covered_until >= $end_date - 120 ) {
				break;
			}
		}

		// Verify full coverage (with ±120s tolerance for rounding).
		if ( $covered_until < $end_date - 120 ) {
			return 0;
		}

		return PHP_INT_MAX === $min_capacity ? 0 : $min_capacity;
	}

	/**
	 * Fast path: compute total available appointments for a range using indexed cache
	 * when the requested range is within the cache horizon.
	 *
	 * Behavior mirrors wc_appointments_get_total_available_appointments_for_range:
	 * - If product has staff and no specific staff_id is provided, return an array of staff => available_count
	 *   (only staff with at least one available slot are returned).
	 * - Otherwise, return an integer count of available slots that can satisfy $qty.
	 *
	 * Returns false when not available or request out of allowed min/max bounds.
	 *
	 * @since 4.0.0
	 *
	 * @param WC_Product_Appointment $product
	 * @param int                    $start_date
	 * @param int                    $end_date
	 * @param int|list<int>|null     $staff_id
	 * @param int                    $qty
	 * @param array<int, WC_Appointment_Slots_Collection>|null $collections_by_staff Preloaded staff id => collection (recurring batch checks).
	 * @param int                    $location_id          Occupancy location (0 = unscoped / auto-fixed).
	 * @param int                    $resource_id          Customer-selected resource occupancy (0 = OR / unscoped).
	 * @return array<int, int>|int|false
	 */
	public static function get_indexed_total_available_for_range( $product, int $start_date, int $end_date, $staff_id = null, int $qty = 1, $collections_by_staff = null, int $location_id = 0, int $resource_id = 0 ) {
		$__t0 = microtime( true );
		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return false;
		}

		if ( $product->get_availability_span() ) {
			$end_date = wc_appointments_availability_span_end_date( $product, $start_date );
		}

		if ( wc_appointments_is_past_request_date( $product, $start_date ) ) {
			return false;
		}

		// Staff selection validation (same as legacy).
		if ( $product->has_staff() && ! is_numeric( $staff_id ) && ! $product->is_staff_assignment_type( 'all' ) && is_array( $staff_id ) && count( $staff_id ) > 1 ) {
			return false;
		}

		// Min/max bounds — mirror wc_appointments_get_total_available_appointments_for_range() exactly.
		$min        = $product->get_min_date_a();
		$max        = $product->get_max_date_a();
		$check_from = strtotime( "midnight +{$min['value']} {$min['unit']}", current_time( 'timestamp' ) );
		$check_to   = strtotime( "+{$max['value']} {$max['unit']}", current_time( 'timestamp' ) );

		if ( 'month' === $product->get_duration_unit() ) {
			$check_to = strtotime( 'midnight', strtotime( date( 'Y-m-t', $check_to ) ) );
		}

		if ( $end_date < $check_from || $start_date > $check_to ) {
			return false;
		}

		// Match storefront get_slots: when the requested length differs from base (addon),
		// regenerate the collection at that length so exact capacity matches listing.
		// Preloaded collections were built at base duration, so they cannot be reused.
		$validation_product = self::get_product_for_range_validation( $product, $start_date, $end_date );
		$duration_adjusted  = $validation_product !== $product;
		$use_preloaded      = ! $duration_adjusted && is_array( $collections_by_staff ) && ! empty( $collections_by_staff );

		// Staff fan-out path.
		if ( $product->has_staff() && ( ! $staff_id || ( is_array( $staff_id ) && 1 < count( $staff_id ) ) ) ) {
			$staff_ids = is_array( $staff_id ) && ! empty( $staff_id )
				? array_values( array_unique( array_map( 'intval', $staff_id ) ) )
				: array_values( array_unique( array_map( 'intval', (array) $product->get_staff_ids() ) ) );
			$result    = array();

			foreach ( $staff_ids as $sid ) {
				if ( $sid <= 0 ) {
					continue;
				}

				if ( $use_preloaded ) {
					if ( ! isset( $collections_by_staff[ (int) $sid ] ) ) {
						continue;
					}
					$collection = $collections_by_staff[ (int) $sid ];
				} else {
					try {
						$collection = WC_Appointment_Slots_Provider::get_time_slots_collection( $validation_product, $start_date, $end_date, (int) $sid, false, false, '', true, $location_id, $resource_id );
					} catch ( Exception $e ) {
						continue;
					}
				}

				$available_for_staff = self::get_exact_available_capacity_for_slot( $collection, $start_date, $end_date, $validation_product );

				if ( $available_for_staff >= $qty ) {
					$result[ (int) $sid ] = $available_for_staff;
				}
			}

			if ( apply_filters( 'wc_appointments_debug_timing', false, __FUNCTION__ ) && function_exists( 'wc_get_logger' ) ) {
				wc_get_logger()->debug(
					'[WC Appointments Timing] ' . __FUNCTION__ . ' product=' . (int) $product->get_id() . ' fanout_staffs=' . count( $staff_ids ) . ' took=' . number_format( ( microtime( true ) - $__t0 ) * 1000, 2 ) . 'ms',
					array( 'source' => 'woocommerce-appointments-timing' )
				);
			}

			return array() === $result ? false : $result;
		}

		// Single staff or no-staff path.
		$resolved_staff_id = null === $staff_id ? 0 : ( is_array( $staff_id ) ? (int) reset( $staff_id ) : (int) $staff_id );

		if ( $use_preloaded ) {
			$collection = $collections_by_staff[ $resolved_staff_id ] ?? reset( $collections_by_staff );
			if ( ! $collection instanceof WC_Appointment_Slots_Collection ) {
				return false;
			}
		} else {
			try {
				$collection = WC_Appointment_Slots_Provider::get_time_slots_collection( $validation_product, $start_date, $end_date, $resolved_staff_id, false, false, '', true, $location_id, $resource_id );
			} catch ( Exception $e ) {
				return false;
			}
		}

		$total = self::get_exact_available_capacity_for_slot( $collection, $start_date, $end_date, $validation_product );

		if ( apply_filters( 'wc_appointments_debug_timing', false, __FUNCTION__ ) && function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->debug(
				'[WC Appointments Timing] ' . __FUNCTION__ . ' product=' . (int) $product->get_id() . ' total=' . $total . ' took=' . number_format( ( microtime( true ) - $__t0 ) * 1000, 2 ) . 'ms',
				array( 'source' => 'woocommerce-appointments-timing' )
			);
		}

		return $total >= $qty ? $total : false;
	}

	/**
	 * Clone with duration set to the requested range when it differs from product base (addons).
	 * In-memory only; never saved. Mirrors storefront get_slots duration mutation.
	 *
	 * @param WC_Product_Appointment $product    Product.
	 * @param int                    $start_date Range start.
	 * @param int                    $end_date   Range end.
	 * @return WC_Product_Appointment
	 */
	private static function get_product_for_range_validation( $product, int $start_date, int $end_date ) {
		if ( ! $product instanceof WC_Product_Appointment ) {
			return $product;
		}

		$unit = (string) $product->get_duration_unit();
		if ( ! in_array( $unit, [ 'minute', 'hour' ], true ) ) {
			return $product;
		}

		$base = 'hour' === $unit ? (int) $product->get_duration() * 60 : (int) $product->get_duration();
		$need = (int) ceil( max( 0, $end_date - $start_date ) / MINUTE_IN_SECONDS );
		if ( $need < 1 || $need === $base ) {
			return $product;
		}

		$copy = clone $product;
		$copy->set_duration_unit( 'minute' );
		$copy->set_duration( $need );

		return $copy;
	}

	/**
	 * Whether a get_indexed_total_available_for_range() result means the slot cannot satisfy qty.
	 *
	 * @param WC_Product_Appointment      $product   Product.
	 * @param array<int, int>|int|false   $available Availability result.
	 * @param int                         $staff_id  Selected staff (0 = product default / fan-out).
	 * @param int                         $qty       Required quantity.
	 * @return bool
	 */
	public static function is_indexed_range_unavailable( $product, $available, $staff_id, $qty ) {
		if ( false === $available ) {
			return true;
		}

		if ( ! is_array( $available ) ) {
			return false;
		}

		$staff_id = (int) $staff_id;
		$qty      = max( 1, (int) $qty );

		if ( $staff_id > 0 ) {
			return ! isset( $available[ $staff_id ] ) || (int) $available[ $staff_id ] < $qty;
		}

		if ( $product->has_staff() && $product->is_staff_assignment_type( 'all' ) ) {
			foreach ( array_map( 'intval', (array) $product->get_staff_ids() ) as $sid ) {
				if ( $sid <= 0 || ! isset( $available[ $sid ] ) || (int) $available[ $sid ] < $qty ) {
					return true;
				}
			}

			return false;
		}

		foreach ( $available as $cap ) {
			if ( (int) $cap >= $qty ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Load slot collections once for a civil range (recurring series batch checks).
	 *
	 * @param WC_Product_Appointment $product      Product.
	 * @param int                    $range_start  Range start (Unix).
	 * @param int                    $range_end    Range end (Unix).
	 * @param int|list<int>|null     $staff_id     Staff scope (same as get_indexed_total_available_for_range).
	 * @param int                    $location_id  Occupancy location (0 = unscoped / auto-fixed).
	 * @param int                    $resource_id  Customer-selected resource occupancy (0 = OR / unscoped).
	 * @return array<int, WC_Appointment_Slots_Collection>|null Staff id => collection; null when all loads fail.
	 */
	public static function load_slots_collections_for_range( $product, int $range_start, int $range_end, $staff_id = null, int $location_id = 0, int $resource_id = 0 ) {
		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return null;
		}

		$collections = array();

		if ( $product->has_staff() && ( ! $staff_id || ( is_array( $staff_id ) && 1 < count( $staff_id ) ) ) ) {
			$staff_ids = is_array( $staff_id ) && ! empty( $staff_id )
				? array_values( array_unique( array_map( 'intval', $staff_id ) ) )
				: array_values( array_unique( array_map( 'intval', (array) $product->get_staff_ids() ) ) );

			foreach ( $staff_ids as $sid ) {
				if ( $sid <= 0 ) {
					continue;
				}

				try {
					$collections[ (int) $sid ] = WC_Appointment_Slots_Provider::get_time_slots_collection( $product, $range_start, $range_end, (int) $sid, false, false, '', true, $location_id, $resource_id );
				} catch ( Exception $e ) {
					continue;
				}
			}
		} else {
			$resolved_staff_id = null === $staff_id ? 0 : ( is_array( $staff_id ) ? (int) reset( $staff_id ) : (int) $staff_id );

			try {
				$collections[ $resolved_staff_id ] = WC_Appointment_Slots_Provider::get_time_slots_collection( $product, $range_start, $range_end, $resolved_staff_id, false, false, '', true, $location_id, $resource_id );
			} catch ( Exception $e ) {
				return null;
			}
		}

		return empty( $collections ) ? null : $collections;
	}

	/**
	 * Availability rule check when indexed cache is enabled (within horizon).
	 *
	 * Delegates to {@see WC_Product_Appointment_Rule_Manager::check_availability_rules_against_date()}.
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int|string             $check_date          Timestamp or date to evaluate.
	 * @param int|int[]              $staff_id            Staff scope.
	 * @param bool                   $get_capacity        When true, returns capacity; otherwise boolean appointable.
	 * @return bool|int
	 */
	public static function check_cached_availability_rules_against_date( $appointable_product, $check_date, $staff_id, $get_capacity = false ) {
		return WC_Product_Appointment_Rule_Manager::check_availability_rules_against_date( $appointable_product, $check_date, $staff_id, $get_capacity );
	}

	/**
	 * Time-based availability rule check when indexed cache is enabled (within horizon).
	 *
	 * Delegates to {@see WC_Product_Appointment_Rule_Manager::check_availability_rules_against_time()}.
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int|string             $slot_start_time     Slot start timestamp.
	 * @param int|string             $slot_end_time       Slot end timestamp.
	 * @param int|int[]              $staff_id            Staff scope.
	 * @param bool                   $get_capacity        When true, returns capacity; otherwise boolean appointable.
	 * @return bool|int
	 */
	public static function check_cached_availability_rules_against_time( $appointable_product, $slot_start_time, $slot_end_time, $staff_id, $get_capacity = false ) {
		return WC_Product_Appointment_Rule_Manager::check_availability_rules_against_time( $appointable_product, $slot_start_time, $slot_end_time, $staff_id, $get_capacity );
	}

}
