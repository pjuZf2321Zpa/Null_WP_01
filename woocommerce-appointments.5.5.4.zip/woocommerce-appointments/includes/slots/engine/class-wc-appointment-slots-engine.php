<?php
/**
 * Unified Slots Engine — single engine for all slot generation.
 *
 * Replaces both Index Engine and Dynamic Engine by consuming normalized
 * data from WC_Appointment_Slots_Data_Normalizer. The normalizer handles
 * data sourcing (SQL cache table vs in-memory rules); this engine handles
 * the algorithm (minute-mask → ranges → slots → capacity deduction).
 *
 * Algorithm:
 *   1. Normalizer provides availability data + overlap index (source-agnostic)
 *   2. Build minute-mask per day (delegates to Normalizer which picks builder)
 *   3. Chunk ranges into slots (pure math via shared trait)
 *   4. Deduct capacity per slot from overlap index
 *   5. Compute per-slot price
 *
 * Performance: identical to the engine that would have been selected.
 *   - Index path: 2 SQL queries (rules + occupancy cache) + in-memory math when appointment cache is healthy
 *   - Dynamic path: 0 SQL for rules + 1 SQL for appointments (unchanged)
 *   - Normalization overhead: O(n) single pass, negligible
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Engine — unified slot generator.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Engine {

	use WC_Appointment_Slots_Engine_Helpers;

	/**
	 * Data normalizer instance.
	 *
	 * @var WC_Appointment_Slots_Data_Normalizer
	 */
	private WC_Appointment_Slots_Data_Normalizer $normalizer;

	/**
	 * Which data source was used: 'index' or 'dynamic'.
	 *
	 * @var string
	 */
	private string $source = 'dynamic';

	/**
	 * Storefront data-engine code from the last generate() call: 1 rules index, 2 dynamic, 3 full index.
	 *
	 * @var int
	 */
	private int $data_engine_code = 2;

	/** @var bool */
	private $collect_diagnostics = false;

	/** @var int */
	private $diag_days = 0;

	/** @var int */
	private $diag_slots = 0;

	/** @var int */
	private $diag_bookable = 0;

	/** @var array<string, int> */
	private $diag_reasons = [];

	/** @var array{days_scanned: int, slots_generated: int, slots_bookable: int, reason_counts: array<string, int>, primary_reason: string}|null */
	private $last_diagnostics = null;

	/**
	 * Appointment post IDs to omit from overlap / booked-qty counts for this request.
	 *
	 * Admin edit-panel availability checks pass the appointment being edited so it is not
	 * treated as an overlapping booking against the same slot.
	 *
	 * @var array<int, true>
	 */
	private static array $overlap_exclude_appointment_ids = [];

	/**
	 * Location ID for this request's occupancy scope (0 = unscoped).
	 * Used for unstaffed product occupancy and resource venue checks.
	 *
	 * @var int
	 */
	private static int $occupancy_location_id = 0;

	/**
	 * Customer-selected resource for occupancy (0 = unscoped / OR across alternatives).
	 *
	 * @since 5.5.0
	 */
	private static int $occupancy_resource_id = 0;

	/**
	 * Set appointment IDs excluded from booked-capacity overlap counts.
	 *
	 * @param int[] $ids Appointment post IDs.
	 */
	public static function set_overlap_exclude_appointment_ids( array $ids ): void {
		self::$overlap_exclude_appointment_ids = [];
		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( 0 !== $id ) {
				self::$overlap_exclude_appointment_ids[ $id ] = true;
			}
		}
	}

	/**
	 * Clear overlap exclusions (call after availability checks that set them).
	 */
	public static function clear_overlap_exclude_appointment_ids(): void {
		self::$overlap_exclude_appointment_ids = [];
	}

	/**
	 * Whether an overlap index entry should be skipped when counting booked qty.
	 *
	 * @param array<string, mixed> $entry Overlap entry (dynamic: id; index: source_id).
	 */
	public static function is_overlap_entry_excluded( array $entry ): bool {
		$aid = (int) ( $entry['id'] ?? $entry['source_id'] ?? 0 );

		return self::is_overlap_appointment_excluded( $aid );
	}

	/**
	 * Whether a specific appointment ID is excluded from overlap / per-day booked counts.
	 *
	 * @param int $appointment_id Appointment post ID.
	 */
	public static function is_overlap_appointment_excluded( int $appointment_id ): bool {
		if ( [] === self::$overlap_exclude_appointment_ids || $appointment_id <= 0 ) {
			return false;
		}

		return isset( self::$overlap_exclude_appointment_ids[ $appointment_id ] );
	}

	/**
	 * Scope product-slot occupancy to a location (staff occupancy stays global).
	 *
	 * @param int $location_id Location post ID, or 0 to clear.
	 */
	public static function set_occupancy_location_id( int $location_id ): void {
		self::$occupancy_location_id = max( 0, $location_id );
	}

	/**
	 * Location used to scope unstaffed product occupancy and resource venue checks (0 = unscoped).
	 */
	public static function get_occupancy_location_id(): int {
		return self::$occupancy_location_id;
	}

	/**
	 * Scope resource occupancy to one resource (customer assignment), or 0 to clear.
	 *
	 * @since 5.5.0
	 *
	 * @param int $resource_id Resource post ID, or 0 to clear.
	 */
	public static function set_occupancy_resource_id( int $resource_id ): void {
		self::$occupancy_resource_id = max( 0, $resource_id );
	}

	/**
	 * Resource used for customer-selected capacity (0 = OR across product alternatives).
	 *
	 * @since 5.5.0
	 */
	public static function get_occupancy_resource_id(): int {
		return self::$occupancy_resource_id;
	}

	/**
	 * Location/resource IDs for availability rule layers (open/closed hours).
	 *
	 * Same IDs occupancy already threads; empty kind = no constraint.
	 *
	 * @since 5.5.0
	 *
	 * @return array{location_id: int, resource_id: int}
	 */
	public static function resolve_availability_layer_ids(): array {
		return [
			'location_id' => self::get_occupancy_location_id(),
			'resource_id' => self::get_occupancy_resource_id(),
		];
	}

	/**
	 * Site-local civil Y-m-d for an instant, as "Y-m-d 00:00:00" digits (no wp_date()/date()).
	 * Caller parses this string in UTC for Fake UTC (wall-clock-as-UTC) slot math.
	 *
	 * @param int            $unix_ts Unix instant.
	 * @param DateTimeZone $tz_site Site timezone (e.g. wp_timezone()).
	 * @return string
	 */
	private static function site_civil_midnight_token_from_real_instant( int $unix_ts, DateTimeZone $tz_site ): string {
		return ( new DateTimeImmutable( '@' . $unix_ts ) )->setTimezone( $tz_site )->format( 'Y-m-d' ) . ' 00:00:00';
	}

	/**
	 * Fake UTC civil-day midnight token for minute/hour slot timestamps.
	 *
	 * @param int $timestamp Slot or appointment instant (Fake UTC wall time).
	 * @return string UTC-parseable Y-m-d 00:00:00 for the Fake UTC civil day.
	 */
	private static function fake_utc_civil_day_midnight_token( int $timestamp ): string {
		return gmdate( 'Y-m-d 00:00:00', $timestamp );
	}

	/**
	 * Overlap day-bucket key for minute/hour products (Fake UTC — matches `day_midnight` in the slot loop).
	 *
	 * Fake UTC wall epochs are UTC-labelled civil digits, so civil midnight is floor-to-day on the
	 * epoch itself. Avoid DateTimeImmutable here: capacity checks call this once per candidate start
	 * on dense multi-staff month calendars (~thousands of times per AJAX).
	 *
	 * Do not reinterpret the epoch as a real instant in wp_timezone() — that shifts 00:00 wall slots
	 * on negative-offset stores onto the previous civil day.
	 *
	 * @param int $timestamp Slot or appointment instant (Fake UTC wall time).
	 * @return int Day-key timestamp for overlap index lookup.
	 */
	public static function timed_overlap_day_key_ts( int $timestamp ): int {
		$day = defined( 'DAY_IN_SECONDS' ) ? (int) DAY_IN_SECONDS : 86400;
		if ( $timestamp >= 0 ) {
			return $timestamp - ( $timestamp % $day );
		}

		// PHP % truncates toward zero; keep civil-day floor for rare negative epochs.
		return (int) ( floor( $timestamp / $day ) * $day );
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->normalizer = new WC_Appointment_Slots_Data_Normalizer();
	}

	/**
	 * Get the data source used in the last generate() call.
	 *
	 * @return string 'index' or 'dynamic'.
	 */
	public function get_source(): string {
		return $this->source;
	}

	/**
	 * Storefront data-engine code from the last generate() call.
	 *
	 * @return int 1|2|3
	 */
	public function get_data_engine_code(): int {
		return $this->data_engine_code;
	}

	/**
	 * Get the number of SQL queries from the last generate() call.
	 *
	 * @return int
	 */
	public function get_query_count(): int {
		return $this->normalizer->get_query_count();
	}

	/**
	 * Get the total query time in ms from the last generate() call.
	 *
	 * @return float
	 */
	public function get_query_time_ms(): float {
		return $this->normalizer->get_query_time_ms();
	}

	/**
	 * Build overlap index and record whether occupancy came from cache or live appointments.
	 *
	 * @param WC_Product_Appointment $product          Product.
	 * @param int                    $product_id       Product ID.
	 * @param int[]                  $staff_ids_filter Staff IDs for cache query.
	 * @param int                    $start_ts         Range start.
	 * @param int                    $end_ts           Range end.
	 * @param int                    $staff_id         Staff filter for live/virtual paths.
	 * @param bool                   $use_index        Whether rules use the index path.
	 * @return array<int, array<int, array<int, array{start: int, end: int, qty: int, id: int}>>>
	 */
	private function resolve_overlap_index(
		WC_Product_Appointment $product,
		int $product_id,
		array $staff_ids_filter,
		int $start_ts,
		int $end_ts,
		int $staff_id,
		bool $use_index
	): array {
		// Availability may use the index while stale/backfill; occupancy stays on live
		// appointment rows until the appointment side of the index is trustworthy.
		$use_index_occupancy = $use_index
			&& ! WC_Appointments_Cache_Availability::is_appointment_backfill_in_progress()
			&& ! WC_Appointments_Cache_Availability::is_index_stale();
		if ( ! $use_index ) {
			$this->data_engine_code = 2;
		} else {
			$this->data_engine_code = $use_index_occupancy ? 3 : 1;
		}

		if ( $use_index_occupancy ) {
			return $this->normalizer->normalize_occupancy_from_index(
				$product_id,
				$staff_ids_filter,
				$start_ts,
				$end_ts,
				$product,
				$staff_id
			);
		}

		return $this->normalizer->normalize_occupancy_from_appointments( $product, $start_ts, $end_ts, $staff_id );
	}

	/**
	 * Generate slots for a product within a date range.
	 *
	 * Single entry point replacing both Index Engine and Dynamic Engine.
	 * Automatically selects the data source based on index availability.
	 *
	 * @param WC_Product_Appointment $appointable_product The appointment product.
	 * @param int                    $start_ts       Range start timestamp.
	 * @param int                    $end_ts         Range end timestamp.
	 * @param int|null               $staff_id       Staff ID or null for product-level.
	 * @param bool                   $get_past_times Whether to include past time slots.
	 * @param bool                   $use_index      Whether index is available for this range.
	 * @param bool                   $skip_pricing         Skip inline slot pricing (availability-only generation).
	 * @param bool                   $collect_diagnostics  Record why slots were skipped (admin, storefront empty states).
	 * @return WC_Appointment_Slot[]
	 */
	public function generate(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		?int $staff_id = null,
		bool $get_past_times = false,
		bool $use_index = false,
		bool $skip_pricing = false,
		bool $collect_diagnostics = false
	): array {
		$staff_id      = $staff_id ?? 0;
		$duration_unit = $appointable_product->get_duration_unit();
		$end_ts        = self::cap_end_date( $appointable_product, $end_ts );
		$this->source  = $use_index ? 'index' : 'dynamic';

		$this->diag_begin( $collect_diagnostics );

		// Day/month/night duration: use simplified date-slot path.
		if ( in_array( $duration_unit, [ WC_Product_Appointment::DURATION_UNIT_DAY, WC_Product_Appointment::DURATION_UNIT_MONTH, WC_Appointments_Constants::DURATION_NIGHT ], true ) ) {
			$slots = $this->generate_date_slots( $appointable_product, $start_ts, $end_ts, $staff_id, $duration_unit, $use_index, $skip_pricing );
		} else {
			$slots = $this->generate_time_slots( $appointable_product, $start_ts, $end_ts, $staff_id, $get_past_times, $use_index, $skip_pricing );
		}

		$this->diag_finish();

		return $slots;
	}

	/**
	 * Summary from the last generate() call when diagnostics were collected.
	 *
	 * @return array{days_scanned: int, slots_generated: int, slots_bookable: int, reason_counts: array<string, int>, primary_reason: string}|null
	 */
	public function get_last_diagnostics(): ?array {
		return $this->last_diagnostics;
	}

	private function diag_begin( bool $collect_diagnostics ): void {
		$this->collect_diagnostics = $collect_diagnostics || (bool) apply_filters( 'wc_appointments_slots_collect_diagnostics', false );
		$this->diag_days           = 0;
		$this->diag_slots          = 0;
		$this->diag_bookable       = 0;
		$this->diag_reasons        = [];
		$this->last_diagnostics    = null;
	}

	private function diag_reason( string $code ): void {
		if ( ! $this->collect_diagnostics ) {
			return;
		}
		if ( ! isset( $this->diag_reasons[ $code ] ) ) {
			$this->diag_reasons[ $code ] = 0;
		}
		$this->diag_reasons[ $code ]++;
	}

	private function diag_day(): void {
		if ( $this->collect_diagnostics ) {
			$this->diag_days++;
		}
	}

	private function diag_slot( bool $bookable ): void {
		if ( ! $this->collect_diagnostics ) {
			return;
		}
		$this->diag_slots++;
		if ( $bookable ) {
			$this->diag_bookable++;
		}
	}

	private function diag_finish(): void {
		if ( ! $this->collect_diagnostics ) {
			return;
		}

		$this->last_diagnostics = [
			'days_scanned'    => $this->diag_days,
			'slots_generated' => $this->diag_slots,
			'slots_bookable'  => $this->diag_bookable,
			'reason_counts'   => $this->diag_reasons,
			'primary_reason'  => $this->diag_primary_reason(),
		];
		$this->collect_diagnostics = false;
	}

	/**
	 * Prefer actionable configuration causes over empty-day noise.
	 */
	private function diag_primary_reason(): string {
		return self::primary_reason_from_summary(
			$this->diag_slots,
			$this->diag_bookable,
			$this->diag_reasons,
			$this->diag_days
		);
	}

	/**
	 * @param array<string, int> $reason_counts
	 */
	public static function primary_reason_from_summary( int $slots_generated, int $slots_bookable, array $reason_counts, int $days_scanned ): string {
		if ( $slots_bookable > 0 ) {
			return 'has_bookable_slots';
		}
		if ( $slots_generated > 0 ) {
			return 'all_capacity_booked';
		}

		$priority = [
			'slot_count_zero',
			'span_duration_mismatch',
			'skip_span_guard',
			'skip_min_max_date',
			'skip_past_or_lead_time',
			'skip_out_of_range',
			'no_appointable_minutes',
		];
		foreach ( $priority as $code ) {
			if ( ! empty( $reason_counts[ $code ] ) ) {
				return $code;
			}
		}

		return $days_scanned > 0 ? 'no_appointable_minutes' : 'unknown';
	}

	/**
	 * Generate time-based slots (minute/hour duration).
	 *
	 * @param WC_Product_Appointment $appointable_product        Product.
	 * @param int                    $start_ts       Range start.
	 * @param int                    $end_ts         Range end.
	 * @param int                    $staff_id       Staff ID.
	 * @param bool                   $get_past_times Include past slots.
	 * @param bool                   $use_index      Use index data source.
	 * @return WC_Appointment_Slot[]
	 */
	private function generate_time_slots(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		int $staff_id,
		bool $get_past_times,
		bool $use_index,
		bool $skip_pricing = false
	): array {
		$product_id    = $appointable_product->get_id();
		$default_avail = $appointable_product->get_default_availability();

		// Build staff_ids filter for SQL.
		$staff_ids_filter = [ 0 ];
		if ( $staff_id ) {
			$staff_ids_filter[] = $staff_id;
		}

		// NORMALIZE — get availability and occupancy data from the appropriate source.
		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::start( 'engine_normalize' );
		}
		if ( $use_index ) {
			$availability = $this->normalizer->normalize_availability_from_index( $product_id, $staff_ids_filter, $start_ts, $end_ts );
		} else {
			$rules        = $appointable_product->get_availability_rules( $staff_id );
			$availability = $this->normalizer->normalize_availability_from_rules( $rules, $default_avail );
		}
		$overlap_index = $this->resolve_overlap_index(
			$appointable_product,
			$product_id,
			$staff_ids_filter,
			$start_ts,
			$end_ts,
			$staff_id,
			$use_index
		);
		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::stop(
                 'engine_normalize',
                [
					'source'   => $use_index ? 'index' : 'dynamic',
					'staff_id' => $staff_id,
				]
                );
		}

		// Build product context once for the slot loop.
		$ctx = self::build_product_context( $appointable_product, $start_ts, $staff_id, $skip_pricing );

		$slots = $this->run_time_slot_loop( $appointable_product, $start_ts, $end_ts, $staff_id, $get_past_times, $availability, $overlap_index, $ctx );

		return $slots;
	}

	/**
	 * Build a product context struct for the slot loop.
	 *
	 * Reads all product properties once so run_time_slot_loop doesn't re-read them.
	 *
	 * @param WC_Product_Appointment $appointable_product  Product.
	 * @param int                    $start_ts Range start.
	 * @param int                    $staff_id Staff ID.
	 * @param bool                   $skip_pricing Skip inline slot pricing.
	 * @return array{interval: int, base_interval: int, default_avail: bool, duration_unit: string, has_pricing: bool, availability_span: string, current_time: int, min_check_from: int, max_check_to: int, min_date: int, capacity_total: int, effective_base_interval: int} Product context.
	 */
	private static function build_product_context( WC_Product_Appointment $appointable_product, int $start_ts, int $staff_id, bool $skip_pricing = false ): array {
		$intervals         = $appointable_product->get_intervals();
		$duration_unit     = $appointable_product->get_duration_unit();
		$product_min_date  = $appointable_product->get_min_date_a();
		$product_max_date  = $appointable_product->get_max_date_a();
		$current_time      = current_time( 'timestamp' );
		$availability_span = $appointable_product->get_availability_span();

		// get_intervals() returns [ duration, base_interval ] in minutes. Slot *length* uses duration;
		// time between *starts* must use the product base interval (not min(duration, base): that
		// broke e.g. 90 min duration + 120 min interval by stepping every 90m instead of 120m).
		$grid_step_minutes = max( 1, (int) $intervals[1] );

		return [
			'interval'                => $intervals[0],
			'base_interval'           => $intervals[1],
			'default_avail'           => $appointable_product->get_default_availability(),
			'duration_unit'           => $duration_unit,
			'has_pricing'             => ! $skip_pricing && $appointable_product->get_has_pricing() && wc_appointments_slots_display_pricing( $appointable_product ),
			'availability_span'       => $availability_span,
			'current_time'            => $current_time,
			'min_check_from'          => strtotime( "+{$product_min_date['value']} {$product_min_date['unit']}", $current_time ),
			'max_check_to'            => strtotime( "+{$product_max_date['value']} {$product_max_date['unit']}", $current_time ),
			'min_date'                => wc_appointments_get_min_timestamp_for_day( $start_ts, $product_min_date['value'], $product_min_date['unit'] ),
			'capacity_total'          => $appointable_product->get_available_qty( $staff_id ),
			// Grid step between candidate starts is always the product base interval (even for
			// "starting slot only"); span=start only changes end clipping and occupancy window logic.
			'effective_base_interval' => $grid_step_minutes,
		];
	}

	/**
	 * Run the time-slot loop (minute-mask → ranges → slots → capacity → inline pricing).
	 *
	 * Used by generate_time_slots (single staff) and generate_multi_staff_time_slots (batch normalize).
	 *
	 * Pricing is computed INLINE during slot creation as raw floats only (pure math,
	 * no wc_price/wc_get_price_to_display calls). HTML formatting is deferred to the
	 * Collection/display layer where a dedupe map ensures each unique price is formatted once.
	 *
	 * @param WC_Product_Appointment $appointable_product        Product.
	 * @param int                    $start_ts       Range start.
	 * @param int                    $end_ts         Range end.
	 * @param int                    $staff_id       Staff ID.
	 * @param bool                   $get_past_times Include past slots.
	 * @param array{source: string, rows?: array<int, array<string, mixed>>, rules?: array<int, array<string, mixed>>, default_avail?: bool} $availability Normalized availability data.
	 * @param array<int|string, array<int, mixed>> $overlap_index Normalized overlap index (staff_id => day_ts => entries; optional 'resource' bucket).
	 * @param array{interval?: int, base_interval?: int, default_avail?: bool, duration_unit?: string, has_pricing?: bool, availability_span?: string, current_time?: int, min_check_from?: int, max_check_to?: int, min_date?: int, capacity_total?: int, effective_base_interval?: int} $ctx Pre-computed product context from build_product_context().
	 * @return WC_Appointment_Slot[]
	 */
	private function run_time_slot_loop(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		int $staff_id,
		bool $get_past_times,
		array $availability,
		array $overlap_index,
		array $ctx = []
	): array {
		// Use passed context or build it (backward compat for direct callers).
		if ( empty( $ctx ) ) {
			$ctx = self::build_product_context( $appointable_product, $start_ts, $staff_id );
		}

		$slots = [];

		// Unpack context for hot loop (avoid repeated array lookups).
		$interval                = $ctx['interval'];
		$default_avail           = $ctx['default_avail'];
		$duration_unit           = $ctx['duration_unit'];
		$has_pricing             = $ctx['has_pricing'];
		$availability_span       = $ctx['availability_span'];
		$current_time            = $ctx['current_time'];
		$min_check_from          = $ctx['min_check_from'];
		$max_check_to            = $ctx['max_check_to'];
		$min_date                = $ctx['min_date'];
		$capacity_total          = $ctx['capacity_total'];
		$effective_base_interval = $ctx['effective_base_interval'];

		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::start( 'engine_slot_loop' );
		}

		// Bounds already use Fake UTC wall time; preserve their civil-day digits.
		$tz_utc   = new DateTimeZone( 'UTC' );
		$dt_check = new DateTimeImmutable( self::fake_utc_civil_day_midnight_token( $start_ts ), $tz_utc );
		$dt_end   = new DateTimeImmutable( self::fake_utc_civil_day_midnight_token( $end_ts ), $tz_utc );
		$range_end          = $dt_end->getTimestamp();
		$day_count          = 0;
		$minute_mask_time   = 0;
		$ranges_time        = 0;
		$slot_creation_time = 0;
		$capacity_time      = 0;
		$pricing_time       = 0;
		// Phase timers only when explicitly enabled (always-on microtime crushed dense month calendars).
		$time_phases        = WC_Appointment_Slots_Perf_Logger::is_enabled();
		// Reuse masks within this staff loop: next-day preview is today's mask on the following iteration.
		$mask_by_day        = [];
		$needs_res_cap = $appointable_product->has_resources();

		// Once per staff (not per day): index path overlays filter-injected rules on each day mask.
		$filter_delta = ( 'index' === ( $availability['source'] ?? '' ) )
			? $appointable_product->get_availability_rules_filter_delta( $staff_id )
			: [];

		$build_mask = function ( int $day_midnight ) use (
			&$mask_by_day,
			$availability,
			$default_avail,
			$interval,
			$staff_id,
			$filter_delta,
			&$minute_mask_time,
			$time_phases
		): array {
			if ( isset( $mask_by_day[ $day_midnight ] ) ) {
				return $mask_by_day[ $day_midnight ];
			}
			if ( $time_phases ) {
				$mask_start = microtime( true );
			}
			$mask_by_day[ $day_midnight ] = $this->normalizer->build_minute_mask(
				$availability,
				$day_midnight,
				$default_avail,
				$interval,
				$staff_id,
				$filter_delta
			);
			if ( $time_phases ) {
				$minute_mask_time += ( microtime( true ) - $mask_start ) * 1000;
			}
			return $mask_by_day[ $day_midnight ];
		};

		$range_end_day = self::timed_overlap_day_key_ts( $range_end );

		while ( $dt_check->getTimestamp() <= $range_end ) {
			$day_midnight = $dt_check->getTimestamp();
			$day_count++;

			$this->diag_day();

			if ( $day_midnight > $range_end_day ) {
				break;
			}

			$minute_mask = $build_mask( $day_midnight );

			// Day bucket already known as $day_midnight (Fake UTC). Skip capacity when this staff
			// has no overlap entries that day and resources cannot reduce remaining.
			$day_entries = $overlap_index[ $staff_id ][ $day_midnight ] ?? [];
			$skip_cap    = ! $needs_res_cap && empty( $day_entries );

			// Convert minute-mask to contiguous ranges.
			if ( $time_phases ) {
				$ranges_start = microtime( true );
			}

			$ranges = self::minute_mask_to_ranges( $minute_mask );
			if ( $time_phases ) {
				$ranges_time += ( microtime( true ) - $ranges_start ) * 1000;
			}

			if ( empty( $ranges ) ) {
				$this->diag_reason( 'no_appointable_minutes' );
			}

			$next_day_mask = null;
			$next_day_midnight = $day_midnight + DAY_IN_SECONDS;
			if ( $next_day_midnight <= $range_end ) {
				$next_day_mask = $build_mask( $next_day_midnight );
			}


			// Chunk ranges into slots.
			foreach ( $ranges as [ $range_start_min, $range_end_min, $range_qty ] ) {
				if ( $range_start_min >= 1440 ) {
					continue;
				}
				$grid_end_min = min( $range_end_min, 1440 );
				$minutes_for_range = $range_end_min - $range_start_min;

				$slot_count = self::compute_slot_count(
					$minutes_for_range,
					$interval,
					$effective_base_interval,
					$availability_span,
					$range_start_min,
					$range_end_min,
				);

				if ( 0 === $slot_count ) {
					if ( $minutes_for_range > 0 ) {
						$this->diag_reason( 'slot_count_zero' );
					}
					continue;
				}

				$range_start_time = $day_midnight + $range_start_min * 60;
				$range_end_time   = $day_midnight + $range_end_min * 60;

				// Per-range capacity: use rule qty if set, else product capacity.
				$cap_total = ( $range_qty > 0 ) ? $range_qty : $capacity_total;

				// Every grid step inside the range (not only full-duration tiles). Clipped ends support
				// add-on–extended validations; sub–product-duration slots are hidden in time-slot HTML.
				for ( $i = 0; ; $i++ ) {
					$start_min         = $range_start_min + $i * $effective_base_interval;
					$natural_end_min = $start_min + $interval;
					if ( $start_min >= $grid_end_min ) {
						break;
					}
					if ( 'start' === $availability_span ) {
						if ( empty( $minute_mask[ $start_min ][0] ) ) {
							$this->diag_reason( 'span_duration_mismatch' );
							continue;
						}
					} elseif ( ! self::slot_start_fits_duration_in_mask( $minute_mask, $next_day_mask, $start_min, $interval ) ) {
						$this->diag_reason( 'span_duration_mismatch' );
						continue;
					}

					if ( $time_phases ) {
						$slot_start = microtime( true );
					}

					$slot_start_ts = $day_midnight + $start_min * 60;
					// Full booking end (may cross civil midnight when duration > remaining day).
					$slot_end_ts = $day_midnight + $natural_end_min * 60;
					// Span="all": same-day overhang past the appointable range is clipped for legacy
					// partial segments. Cross-midnight overflow (natural_end > 1440) was already
					// validated by slot_start_fits_duration_in_mask via next_day_mask — keep the
					// natural end so display listing is not reduced to midnight-only for 24h/1h grids.
					$guard_range_end = $range_end_time;
					if ( 'start' !== $availability_span && $natural_end_min > $range_end_min ) {
						if ( $natural_end_min <= 1440 ) {
							$slot_end_ts = $range_end_time;
						} else {
							$guard_range_end = $slot_end_ts;
						}
					}
					$slot_duration_mins = max( 1, (int) round( ( $slot_end_ts - $slot_start_ts ) / 60 ) );

					// Unified slot filter.
					$verdict = self::should_skip_slot(
						$slot_start_ts,
						$slot_end_ts,
						$guard_range_end,
						$availability_span,
						$get_past_times,
						$min_date,
						$current_time,
						$min_check_from,
						$max_check_to,
						$range_end,
						true
					);
					if ( 'ok' !== $verdict ) {
						$this->diag_reason( $verdict );
						continue;
					}

					// Deduct capacity per slot.
					if ( $time_phases ) {
						$capacity_start = microtime( true );
					}
					if ( $skip_cap ) {
						$cap_available = $cap_total;
						$booked        = 0;
					} else {
						[ $cap_available, $booked ] = self::remaining_capacity(
							$overlap_index,
							$slot_start_ts,
							$slot_end_ts,
							$staff_id,
							$cap_total,
							$appointable_product,
							true,
							$day_midnight
						);
					}

					if ( $time_phases ) {
						$capacity_time += ( microtime( true ) - $capacity_start ) * 1000;
					}

					// Inline pricing: compute raw price (pure math, no WC formatting).
					// Only for available slots with pricing enabled.
					// Returns null if price equals default (no discount badge needed).
					$price_raw = null;
					if ( $has_pricing && $cap_available > 0 ) {
						if ( $time_phases ) {
							$pricing_start_t = microtime( true );
						}
						$price_raw = WC_Appointment_Slots_Pricing::compute_slot_price_raw(
							$appointable_product,
							$slot_start_ts,
							$slot_end_ts,
							$staff_id,
							$duration_unit
						);
						if ( $time_phases ) {
							$pricing_time += ( microtime( true ) - $pricing_start_t ) * 1000;
						}
					}

					$slots[] = new WC_Appointment_Slot(
						$slot_start_ts,
						$slot_end_ts,
						$slot_duration_mins,
						$staff_id,
						$cap_total,
						$booked,
						$cap_available,
						$cap_available > 0,
						$price_raw
					);

					$this->diag_slot( $cap_available > 0 );

					if ( $time_phases ) {
						$slot_creation_time += ( microtime( true ) - $slot_start ) * 1000;
					}
				}
			}

			// Advance to next day.
			$dt_check = $dt_check->modify( '+1 day' );
		}

		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::stop(
                 'engine_slot_loop',
                [
					'slots'           => count( $slots ),
					'staff_id'        => $staff_id,
					'days'            => $day_count,
					'mask_ms'         => round( $minute_mask_time, 2 ),
					'ranges_ms'       => round( $ranges_time, 2 ),
					'slot_ms'         => round( $slot_creation_time, 2 ),
					'capacity_ms'     => round( $capacity_time, 2 ),
					'pricing_ms'      => round( $pricing_time, 2 ),
					'available_slots' => count( array_filter( $slots, fn( $s ) => $s->available ) ),
					'capacity_total'  => $capacity_total,
				]
                );
		}


		return $slots;
	}

	/**
	 * Generate time-based slots for multiple staff with shared occupancy normalize.
	 *
	 * Index path: shared availability rows + shared occupancy.
	 * Dynamic path: shared occupancy (one appointment load); per-staff rule normalize.
	 * Avoids N× occupancy SQL on nopref calendar month loads.
	 *
	 * @param WC_Product_Appointment $appointable_product        Product.
	 * @param int                    $start_ts      Range start.
	 * @param int                    $end_ts        Range end.
	 * @param int[]                  $staff_ids     Staff IDs to generate for.
	 * @param bool                   $get_past_times Include past slots.
	 * @param bool                   $use_index     Use index data source when ready.
	 * @return array{slots_by_staff: array<int, WC_Appointment_Slot[]>, source: string, query_count: int, query_time_ms: float}|null Null for day/month or empty staff.
	 */
	public function generate_multi_staff_time_slots(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		array $staff_ids,
		bool $get_past_times,
		bool $use_index,
		bool $skip_pricing = false
	) {
		$staff_ids = array_values( array_unique( array_filter( array_map( 'intval', $staff_ids ) ) ) );
		if ( [] === $staff_ids ) {
			return null;
		}

		// Day/month/night products must use generate_date_slots per staff (provider merge path), not the minute-mask loop.
		if ( in_array( $appointable_product->get_duration_unit(), [ WC_Product_Appointment::DURATION_UNIT_DAY, WC_Product_Appointment::DURATION_UNIT_MONTH, WC_Appointments_Constants::DURATION_NIGHT ], true ) ) {
			return null;
		}

		$this->source     = $use_index ? 'index' : 'dynamic';
		$product_id       = $appointable_product->get_id();
		$staff_ids_filter = array_values( array_unique( array_merge( [ 0 ], $staff_ids ) ) );
		$default_avail    = $appointable_product->get_default_availability();

		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::start( 'engine_normalize' );
		}

		$shared_availability = null;
		if ( $use_index ) {
			$shared_availability = $this->normalizer->normalize_availability_from_index( $product_id, $staff_ids_filter, $start_ts, $end_ts );
		}
		$overlap_index = $this->resolve_overlap_index(
			$appointable_product,
			$product_id,
			$staff_ids_filter,
			$start_ts,
			$end_ts,
			0,
			$use_index
		);
		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::stop(
				'engine_normalize',
				[
					'source'   => $this->source,
					'staff_id' => 'multi',
				]
			);
		}

		$slots_by_staff = [];
		foreach ( $staff_ids as $sid ) {
			$sid = (int) $sid;
			if ( null !== $shared_availability ) {
				$availability = $shared_availability;
			} else {
				$rules        = $appointable_product->get_availability_rules( $sid );
				$availability = $this->normalizer->normalize_availability_from_rules( $rules, $default_avail );
			}
			$ctx = self::build_product_context( $appointable_product, $start_ts, $sid, $skip_pricing );
			$slots_by_staff[ $sid ] = $this->run_time_slot_loop( $appointable_product, $start_ts, $end_ts, $sid, $get_past_times, $availability, $overlap_index, $ctx );
		}

		return [
			'slots_by_staff' => $slots_by_staff,
			'source'         => $this->source,
			'data_engine'    => $this->data_engine_code,
			'query_count'    => $this->normalizer->get_query_count(),
			'query_time_ms'  => $this->normalizer->get_query_time_ms(),
		];
	}

	/**
	 * Generate day/month-level slots.
	 *
	 * @param WC_Product_Appointment $appointable_product       Product.
	 * @param int                    $start_ts      Range start.
	 * @param int                    $end_ts        Range end.
	 * @param int                    $staff_id      Staff ID.
	 * @param string                 $duration_unit Duration unit.
	 * @param bool                   $use_index     Use index data source.
	 * @return WC_Appointment_Slot[]
	 */
	private function generate_date_slots(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		int $staff_id,
		string $duration_unit,
		bool $use_index,
		bool $skip_pricing = false
	): array {
		$slots      = [];
		$product_id = $appointable_product->get_id();
		$ctx        = self::build_product_context( $appointable_product, $start_ts, $staff_id, $skip_pricing );
		$has_pricing = $ctx['has_pricing'];
		$get_past_times = (bool) apply_filters( 'woocommerce_appointments_get_past_times', false );
		$min_date       = $ctx['min_date'];
		$current_time   = $ctx['current_time'];
		$min_check_from = $ctx['min_check_from'];
		$max_check_to   = $ctx['max_check_to'];

		// Build staff_ids filter.
		$staff_ids_filter = [ 0 ];
		if ( $staff_id ) {
			$staff_ids_filter[] = $staff_id;
		}

		$overlap_index = $this->resolve_overlap_index(
			$appointable_product,
			$product_id,
			$staff_ids_filter,
			$start_ts,
			$end_ts,
			$staff_id,
			$use_index
		);

		if ( in_array( $duration_unit, [ WC_Product_Appointment::DURATION_UNIT_DAY, WC_Appointments_Constants::DURATION_NIGHT ], true ) ) {
			// Day/night: UTC midnight date tokens so civil dates stay timezone-agnostic
			// end-to-end (rules, slots, and occupancy indexing). Night = one civil day per unit.
			$tz_utc   = new DateTimeZone( 'UTC' );
			$dt_check = new DateTimeImmutable( gmdate( 'Y-m-d 00:00:00', $start_ts ), $tz_utc );
			while ( $dt_check->getTimestamp() <= $end_ts ) {
				$check_date    = $dt_check->getTimestamp();
				$this->diag_day();
				$available_qty = WC_Appointment_Slots_Rule_Minutes::check_date_availability(
					$appointable_product,
                    $check_date,
                    $staff_id,
                    true
				);

				if ( $available_qty ) {
					$day_end   = $check_date + DAY_IN_SECONDS;
					$cap_total = (int) $available_qty;
					[ $cap_available, $booked ] = self::remaining_capacity(
						$overlap_index,
						$check_date,
						$day_end,
						$staff_id,
						$cap_total,
						$appointable_product
					);

					// Compute raw price only (pure math, no WC formatting).
					$price_raw = null;
					if ( $has_pricing && $cap_available > 0 ) {
						$price_raw = WC_Appointment_Slots_Pricing::compute_slot_price_raw(
							$appointable_product,
                            $check_date,
                            $day_end,
                            $staff_id,
                            $duration_unit
						);
					}

					$slots[] = new WC_Appointment_Slot(
						$check_date,
						$day_end,
						1440,
						$staff_id,
						$cap_total,
						$booked,
						$cap_available,
						$cap_available > 0,
						$price_raw
					);
					$this->diag_slot( $cap_available > 0 );
				} else {
					$this->diag_reason( 'no_appointable_minutes' );
				}

				$dt_check = $dt_check->modify( '+1 day' );
			}

			$slots = self::apply_multi_day_start_bottleneck_to_day_slots( $slots, $appointable_product );
		} elseif ( WC_Product_Appointment::DURATION_UNIT_MONTH === $duration_unit ) {
			// Site-local month boundaries (same as day slots and wc_appointments_get_posted_data).
			// DateTime('@ts') is UTC-only; using it here shifted month starts (e.g. +2h vs Europe/Ljubljana
			// CEST) so validation never matched listed slots.
			$tz_site  = new DateTimeZone( wc_timezone_string() );
			$start_dt = new DateTime( self::site_civil_midnight_token_from_real_instant( $start_ts, $tz_site ), $tz_site );
			$start_dt->modify( 'first day of this month midnight' );

			// When end_ts is exclusive (e.g. first moment of next month), use the prior instant so
			// "last day of this month" resolves to the booked month, not the following calendar month.
			$end_instant = max( $start_ts, $end_ts - 1 );
			$end_dt      = new DateTime( self::site_civil_midnight_token_from_real_instant( $end_instant, $tz_site ), $tz_site );
			$end_dt->modify( 'last day of this month midnight' );

			$from = $start_dt->getTimestamp();
			$to   = $end_dt->getTimestamp();

			$month_diff = 0;
			$check_dt   = clone $start_dt;
			$check_dt->modify( '+1 month' );

			while ( $check_dt->getTimestamp() <= $to ) {
				$check_dt->modify( '+1 month' );
				$month_diff++;
			}

			for ( $i = 0; $i <= $month_diff; $i++ ) {
				$this->diag_day();
				$month_dt = clone $start_dt;
				if ( 0 !== $i ) {
					$month_dt->modify( "+{$i} month" );
				}
				$month_start = $month_dt->getTimestamp();
				$year        = $month_dt->format( 'Y' );
				$month       = $month_dt->format( 'n' );

				$month_end_dt = clone $month_dt;
				$month_end_dt->modify( '+1 month' );
				$month_end = $month_end_dt->getTimestamp();

				$skip_reason = self::should_skip_slot(
					$month_start,
                    $month_end,
                    $month_start,
                    'start',
                    $get_past_times,
					$min_date,
                    $current_time,
                    $min_check_from,
                    $max_check_to,
                    $end_ts
				);

				if ( 'ok' !== $skip_reason ) {
					$this->diag_reason( $skip_reason );
					continue;
				}

				$available_qty = WC_Appointment_Slots_Rule_Minutes::check_date_availability(
					$appointable_product,
                    $month_start,
                    $staff_id,
                    true
				);

				if ( ! $available_qty ) {
					$this->diag_reason( 'no_appointable_minutes' );
					continue;
				}

				$duration_days = (int) round( ( $month_end - $month_start ) / 86400 );

				// Compute raw price only (pure math, no WC formatting).
				$price_raw = null;
				if ( $has_pricing ) {
					$price_raw = WC_Appointment_Slots_Pricing::compute_slot_price_raw(
						$appointable_product,
                        $month_start,
                        $month_end,
                        $staff_id,
                        $duration_unit
					);
				}

				$slots[] = new WC_Appointment_Slot(
					$month_start,
					$month_end,
					$duration_days * 1440,
					$staff_id,
					(int) $available_qty,
					0,
					(int) $available_qty,
					true,
					$price_raw
				);
				$this->diag_slot( true );
			}
		}

		return $slots;
	}

	/**
	 * For day-unit products with duration > 1, a day is a valid start only if every
	 * calendar day in [start, start + duration) has remaining capacity. This aligns
	 * the picker with get_multi_day_available_capacity / checkout validation.
	 *
	 * @param WC_Appointment_Slot[] $slots   Raw single-day slots.
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @return WC_Appointment_Slot[]
	 */
	private static function apply_multi_day_start_bottleneck_to_day_slots( array $slots, WC_Product_Appointment $appointable_product ): array {
		$dur_days = max( 1, (int) $appointable_product->get_duration() );
		if ( $dur_days <= 1 || empty( $slots ) ) {
			return $slots;
		}

		$tz_utc   = new DateTimeZone( 'UTC' );
		$by_start = [];
		foreach ( $slots as $s ) {
			$midnight_key              = ( new DateTimeImmutable( gmdate( 'Y-m-d 00:00:00', $s->start_ts ), $tz_utc ) )->getTimestamp();
			$by_start[ $midnight_key ] = $s;
		}

		$out = [];

		foreach ( $slots as $slot ) {
			$start_ts   = $slot->start_ts;
			$check_dt   = new DateTimeImmutable( gmdate( 'Y-m-d 00:00:00', $start_ts ), $tz_utc );
			$eff_avail  = PHP_INT_MAX;
			$has_window = true;

			for ( $i = 0; $i < $dur_days; $i++ ) {
				if ( $i > 0 ) {
					$check_dt = $check_dt->modify( '+1 day' );
				}
				$day_ts = $check_dt->getTimestamp();
				if ( ! isset( $by_start[ $day_ts ] ) ) {
					$has_window = false;
					break;
				}
				$peer       = $by_start[ $day_ts ];
				$eff_avail  = min( $eff_avail, $peer->capacity_available );
			}

			if ( ! $has_window || PHP_INT_MAX === $eff_avail ) {
				$eff_avail = 0;
			}
			$eff_avail = max( 0, $eff_avail );

			$price_raw = ( $eff_avail > 0 ) ? $slot->price_raw : null;

			$out[] = new WC_Appointment_Slot(
				$slot->start_ts,
				$slot->end_ts,
				$slot->duration_minutes,
				$slot->staff_id,
				$slot->capacity_total,
				$slot->capacity_booked,
				$eff_avail,
				$eff_avail > 0,
				$price_raw,
				$slot->price_display,
				$slot->location_id,
				$slot->resource_id,
				$slot->recurrence_id
			);
		}

		return $out;
	}
}
