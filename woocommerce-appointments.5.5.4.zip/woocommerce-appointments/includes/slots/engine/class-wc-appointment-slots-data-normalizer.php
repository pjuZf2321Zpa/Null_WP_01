<?php
/**
 * Data Normalizer — converts both index rows and in-memory rules/appointments
 * into a common input format for the unified Slots Engine.
 *
 * This eliminates the need for two separate engines by normalizing the two
 * data sources (SQL cache table vs product meta rules) into identical
 * intermediate structures that a single engine can consume.
 *
 * Normalized structures:
 *   - Availability: array of NormalizedRule arrays (sorted, ready for minute-mask)
 *   - Occupancy: overlap index keyed by staff_id (ready for count_overlapping)
 *
 * Performance impact of normalization: negligible.
 *   - Index path: cache rows already arrive as arrays — normalization is a thin rename.
 *   - Dynamic path: rules already arrive as arrays — normalization extracts timestamps.
 *   - Both paths: O(n) single pass over rules, no additional SQL or product lookups.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Data_Normalizer — unifies data sources for the single engine.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Data_Normalizer {
	/**
	 * Number of SQL queries executed during normalization.
	 *
	 * @var int
	 */
	private int $query_count = 0;

	/**
	 * Total query time in milliseconds during normalization.
	 *
	 * @var float
	 */
	private float $query_time_ms = 0.0;

	/**
	 * Civil calendar day key for day/month slots and bookings (timezone-agnostic).
	 *
	 * Stored instants are UTC-labelled wall times; civil Y-m-d comes from gmdate()
	 * and is parsed as UTC midnight so overlap keys match generate_date_slots().
	 * Do not use wp_date() here — site timezone is only applied when writing the
	 * availability index cache (see WC_Appointments_Cache_Availability).
	 *
	 * @param int $timestamp Source timestamp (date token).
	 * @return DateTimeImmutable
	 */
	private function build_civil_day_key_from_slot_timestamp( int $timestamp ): DateTimeImmutable {
		$tz_utc = new DateTimeZone( 'UTC' );

		// Already a UTC civil date token (listed day slots).
		if ( '00:00:00' === gmdate( 'H:i:s', $timestamp ) ) {
			return new DateTimeImmutable( gmdate( 'Y-m-d 00:00:00', $timestamp ), $tz_utc );
		}

		// Site-local midnight storage (admin / legacy posted data): civil day is the site
		// calendar date, encoded as Fake UTC midnight to match generate_date_slots().
		$tz_site = new DateTimeZone( wc_timezone_string() );
		$ymd     = ( new DateTimeImmutable( '@' . $timestamp ) )->setTimezone( $tz_site )->format( 'Y-m-d' );

		return new DateTimeImmutable( $ymd . ' 00:00:00', $tz_utc );
	}

	/**
	 * Day key for minute/hour overlap (Fake UTC site civil day — matches engine `day_midnight` buckets).
	 *
	 * @param int $timestamp Source timestamp.
	 * @return DateTimeImmutable
	 */
	private function build_timed_day_key_from_slot_timestamp( int $timestamp ): DateTimeImmutable {
		$tz_utc = new DateTimeZone( 'UTC' );
		$day_ts = WC_Appointment_Slots_Engine::timed_overlap_day_key_ts( $timestamp );

		return ( new DateTimeImmutable( '@' . $day_ts ) )->setTimezone( $tz_utc );
	}

	/**
	 * Get the number of SQL queries from the last normalize call.
	 *
	 * @return int
	 */
	public function get_query_count(): int {
		return $this->query_count;
	}

	/**
	 * Get the total query time in ms from the last normalize call.
	 *
	 * @return float
	 */
	public function get_query_time_ms(): float {
		return $this->query_time_ms;
	}

	/**
	 * Normalize availability data from the index (cache table).
	 *
	 * Fetches rows from the availability cache table and sorts them
	 * into the same priority order as in-memory rules.
	 *
	 * @param int   $product_id       Product ID.
	 * @param int[] $staff_ids_filter Staff IDs to include (always contains 0).
	 * @param int   $start_ts         Range start.
	 * @param int   $end_ts           Range end.
	 * @return array{source: string, rows: array<int, array<string, mixed>>} Normalized availability data.
	 */
	public function normalize_availability_from_index(
		int $product_id,
		array $staff_ids_filter,
		int $start_ts,
		int $end_ts
	): array {
		$rows = $this->fetch_availability_rows( $product_id, $staff_ids_filter, $start_ts, $end_ts );
		$rows = self::sort_availability_rows( $rows );


		return [
			'source' => 'index',
			'rows'   => $rows,
		];
	}

	/**
	 * Normalize availability data from in-memory rules (dynamic path).
	 *
	 * Wraps the parsed rules array with source metadata so the engine
	 * can use the Rule Resolver's build_minute_mask() for this path.
	 *
	 * @param array<int, array<string, mixed>> $rules         Parsed rules from get_availability_rules().
	 * @param bool                             $default_avail Product default availability.
	 * @return array{source: string, rules: array<int, array<string, mixed>>, default_avail: bool} Normalized availability data.
	 */
	public function normalize_availability_from_rules(
		array $rules,
		bool $default_avail
	): array {
		return [
			'source'        => 'rules',
			'rules'         => $rules,
			'default_avail' => $default_avail,
		];
	}

	/**
	 * Normalize occupancy data from the index (cache table).
	 *
	 * Fetches appointment rows from the cache table and builds
	 * an overlap index identical to what the dynamic path produces.
	 *
	 * @param int                    $product_id       Product ID.
	 * @param int[]                  $staff_ids_filter Staff IDs to include.
	 * @param int                    $start_ts         Range start.
	 * @param int                    $end_ts           Range end.
	 * @param WC_Product_Appointment $product          Product for padding/capacity config.
	 * @param int                    $staff_id         Staff filter for recurring in-cart holds (0 = all).
	 * @return array<int, array<int, array<int, array{start: int, end: int, qty: int, id: int}>>>
	 */
	public function normalize_occupancy_from_index(
		int $product_id,
		array $staff_ids_filter,
		int $start_ts,
		int $end_ts,
		WC_Product_Appointment $product,
		int $staff_id = 0
	): array {
		$appointment_rows = $this->fetch_appointment_rows(
			$product_id,
			$staff_ids_filter,
			$start_ts,
			$end_ts,
			$product->has_locations() && $product->has_staff()
		);
		$index            = $this->build_overlap_index_from_rows( $appointment_rows, $product );

		$virtual = WC_Appointment_Recurring_Cart_Occupancy::appointments_for_product( $product, $start_ts, $end_ts, $staff_id );
		if ( empty( $virtual ) ) {
			return $index;
		}

		foreach ( $this->build_overlap_index_from_objects( $virtual, $product ) as $sid => $days ) {
			foreach ( $days as $day_ts => $entries ) {
				$index[ $sid ][ $day_ts ] = array_merge( $index[ $sid ][ $day_ts ] ?? [], $entries );
			}
		}

		return $index;
	}

	/**
	 * Normalize occupancy data from appointment objects (dynamic path).
	 *
	 * Loads existing appointments via the data store and builds
	 * an overlap index identical to what the index path produces.
	 *
	 * @param WC_Product_Appointment $product  Product.
	 * @param int                    $start_ts Range start.
	 * @param int                    $end_ts   Range end.
	 * @param int                    $staff_id Staff ID (0 = all).
	 * @return array<int, array<int, array<int, array{start: int, end: int, qty: int, id: int}>>>
	 */
	public function normalize_occupancy_from_appointments(
		WC_Product_Appointment $product,
		int $start_ts,
		int $end_ts,
		int $staff_id
	): array {
		$staff_ids = $staff_id > 0 ? [ $staff_id ] : [];
		if ( $product->has_locations() && $product->has_staff() ) {
			$staff_ids = [];
		}
		$existing_appointments = array_merge(
			WC_Appointment_Data_Store::get_all_existing_appointments( $product, $start_ts, $end_ts, $staff_ids ),
			WC_Appointment_Recurring_Cart_Occupancy::appointments_for_product(
				$product,
				$start_ts,
				$end_ts,
				( $product->has_locations() && $product->has_staff() ) ? 0 : $staff_id
			)
		);

		return $this->build_overlap_index_from_objects( $existing_appointments, $product );
	}

	/**
	 * Build minute-mask for a single day from normalized availability data.
	 *
	 * Delegates to the appropriate builder based on the data source,
	 * producing identical output regardless of source.
	 *
	 * @param array{source: string, rows?: array<int, array<string, mixed>>, rules?: array<int, array<string, mixed>>, default_avail?: bool} $availability Normalized availability data from normalize_availability_*.
	 * @param int                              $day_midnight  Midnight timestamp for the day.
	 * @param bool                             $default_avail Product default availability.
	 * @param int                              $interval      Slot duration in minutes.
	 * @param int                              $staff_id      Staff ID being evaluated.
	 * @param array<int, array<string, mixed>> $filter_delta  From get_availability_rules_filter_delta(); once per staff in the engine.
	 * @return array<int, array{0: bool, 1: int}> Minute index => [appointable, qty].
	 */
	public function build_minute_mask(
		array $availability,
		int $day_midnight,
		bool $default_avail,
		int $interval,
		int $staff_id,
		array $filter_delta = []
	): array {
		$mask = [];
		if ( 'index' === $availability['source'] ) {
			$mask = $this->build_minute_mask_from_index_rows(
				$availability['rows'],
				$day_midnight,
				$default_avail,
				$interval,
				$staff_id,
			);
			// Index rows are persisted only. Overlay filter-injected rules (same as dynamic path).
			if ( ! empty( $filter_delta ) ) {
				$mask = WC_Appointment_Slots_Rule_Resolver::overlay_rules_on_mask(
					$mask,
					$filter_delta,
					$day_midnight,
					$interval,
					$staff_id
				);
			}
		} else {
			$mask = WC_Appointment_Slots_Rule_Resolver::build_minute_mask(
				$availability['rules'],
				$day_midnight,
				$default_avail,
				$interval,
				$staff_id,
			);
		}

		return $mask;
	}

	// ─── Index-specific SQL methods ──────────────────────────────

	/**
	 * Fetch availability rule rows from cache table.
	 *
	 * @param int   $product_id       Product ID.
	 * @param int[] $staff_ids_filter Staff IDs to include.
	 * @param int   $start_ts         Range start.
	 * @param int   $end_ts           Range end.
	 * @return array<int, array<string, mixed>> Raw DB rows.
	 */
	private function fetch_availability_rows( int $product_id, array $staff_ids_filter, int $start_ts, int $end_ts ): array {
		global $wpdb;

		$requested_product_id = $product_id;
		$product_id           = wc_appointments_get_product_id_for_availability( $product_id );

		$table = $wpdb->prefix . WC_Appointments_Cache_Availability::CACHE_TABLE;

		$staff_placeholders = implode( ',', array_fill( 0, count( $staff_ids_filter ), '%d' ) );

		$layers      = class_exists( 'WC_Appointment_Slots_Engine', false )
			? WC_Appointment_Slots_Engine::resolve_availability_layer_ids()
			: [ 'location_id' => 0, 'resource_id' => 0 ];
		$location_id = (int) ( $layers['location_id'] ?? 0 );
		$resource_id = (int) ( $layers['resource_id'] ?? 0 );

		$query_start = microtime( true );

		// Base: global / product / staff (exclude location/resource scopes from product_id IN).
		$where  = "source = 'availability'
			   AND scope IN ('global','product','staff')
			   AND product_id IN (0, %d)
			   AND NOT ( scope = 'product' AND product_id = 0 )
			   AND staff_id IN ({$staff_placeholders})
			   AND NOT ( scope = 'staff' AND staff_id = 0 )
			   AND start_ts < %d
			   AND end_ts > %d";
		$params = array_merge(
			[ $product_id ],
			$staff_ids_filter,
			[ $end_ts, $start_ts ]
		);

		if ( $location_id > 0 ) {
			$where   .= ' OR ( source = %s AND scope = %s AND product_id = %d AND start_ts < %d AND end_ts > %d )';
			$params[] = 'availability';
			$params[] = 'location';
			$params[] = $location_id;
			$params[] = $end_ts;
			$params[] = $start_ts;
		}

		if ( $resource_id > 0 ) {
			$where   .= ' OR ( source = %s AND scope = %s AND resource_id = %d AND start_ts < %d AND end_ts > %d )';
			$params[] = 'availability';
			$params[] = 'resource';
			$params[] = $resource_id;
			$params[] = $end_ts;
			$params[] = $start_ts;
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Cache table from wpdb; dynamic IN placeholders; IDs int-cast.
		$sql = $wpdb->prepare(
			"SELECT * FROM {$table} WHERE ({$where})",
			$params
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $sql, 'ARRAY_A' ) ?: [];

		$this->query_count++;
		$this->query_time_ms += ( microtime( true ) - $query_start ) * 1000;

		/**
		 * Filter indexed availability rows before normalization.
		 *
		 * Used by live integration tests to ignore pre-existing global index rows on shared dev sites.
		 *
		 * @param array $rows             Raw cache rows.
		 * @param int   $product_id       Product ID for the slot request.
		 * @param int[] $staff_ids_filter Staff IDs included in the query.
		 * @param int   $start_ts         Range start.
		 * @param int   $end_ts           Range end.
		 */
		return apply_filters(
			'wc_appointments_slots_index_availability_rows',
			$rows,
			$product_id,
			$staff_ids_filter,
			$start_ts,
			$end_ts
		);
	}

	/**
	 * Fetch appointment/occupancy rows from cache table.
	 *
	 * Single query: this product's appointments plus cross-product staff conflicts
	 * (replaces two separate queries to cut one DB round-trip).
	 *
	 * @param int   $product_id       Product ID.
	 * @param int[] $staff_ids_filter Staff IDs to include (always contains 0).
	 * @param int   $start_ts                Range start.
	 * @param int   $end_ts                  Range end.
	 * @param bool  $all_this_product_staff  Fetch every staff for this product (location occupancy).
	 * @return array<int, array<string, mixed>> Raw DB rows.
	 */
	private function fetch_appointment_rows( int $product_id, array $staff_ids_filter, int $start_ts, int $end_ts, bool $all_this_product_staff = false ): array {
		global $wpdb;

		$table   = $wpdb->prefix . WC_Appointments_Cache_Availability::CACHE_TABLE;
		$real_staff_ids = array_values( array_filter( $staff_ids_filter, static fn( int $id ): bool => 0 < $id ) );

		// Allow expanding product IDs for shared capacity / WCML translations (BC with dynamic path filter).
		$filtered_args = apply_filters(
			'woocommerce_appointments_for_objects_query_args',
			[
				'product_id'   => [ $product_id ],
				'staff_id'     => $real_staff_ids,
				'date_between' => [
					'start' => $start_ts,
					'end'   => $end_ts,
				],
			]
		);
		$query_product_ids = isset( $filtered_args['product_id'] )
			? array_values( array_unique( array_map( 'intval', (array) $filtered_args['product_id'] ) ) )
			: [ $product_id ];

		// Resource requirements for this product (empty = no resource rows needed).
		$resource_ids = [];
		$product_obj  = wc_get_product( $product_id );
		if ( $product_obj instanceof WC_Product_Appointment && $product_obj->has_resources() ) {
			foreach ( $product_obj->get_resource_requirements() as $req ) {
				$rid = (int) ( $req['resource_id'] ?? 0 );
				if ( $rid > 0 ) {
					$resource_ids[] = $rid;
				}
			}
			$resource_ids = array_values( array_unique( $resource_ids ) );
		}

		$query_start = microtime( true );

		$product_placeholders = implode( ',', array_fill( 0, count( $query_product_ids ), '%d' ) );

		// Resource OR branch (cross-product by resource_id).
		$resource_branch = '';
		$resource_params = [];
		if ( [] !== $resource_ids ) {
			$resource_placeholders = implode( ',', array_fill( 0, count( $resource_ids ), '%d' ) );
			$resource_branch = " OR ( resource_id IN ({$resource_placeholders}) )";
			$resource_params = $resource_ids;
		}

		if ( empty( $real_staff_ids ) ) {
			$staff_placeholders = implode( ',', array_fill( 0, count( $staff_ids_filter ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Cache table from wpdb; dynamic IN placeholders; IDs int-cast.
			$sql = $wpdb->prepare(
				"SELECT source_id, staff_id, start_ts, end_ts, qty, status, product_id, resource_id
				 FROM {$table}
				 WHERE source = 'appointment'
				   AND ( ( product_id IN ({$product_placeholders}) AND staff_id IN ({$staff_placeholders}) AND resource_id = 0 ){$resource_branch} )
				   AND start_ts < %d
				   AND end_ts > %d
				   AND status NOT IN ('cancelled', 'trash', 'was-in-cart')",
				array_merge( $query_product_ids, $staff_ids_filter, $resource_params, [ $end_ts, $start_ts ] )
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		} elseif ( $all_this_product_staff ) {
			$real_staff_placeholders = implode( ',', array_fill( 0, count( $real_staff_ids ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Cache table from wpdb; dynamic IN placeholders; IDs int-cast.
			$sql = $wpdb->prepare(
				"SELECT source_id, staff_id, start_ts, end_ts, qty, status, product_id, resource_id
				 FROM {$table}
				 WHERE source = 'appointment'
				   AND ( ( product_id IN ({$product_placeholders}) AND resource_id = 0 )
				     OR ( product_id NOT IN ({$product_placeholders}) AND staff_id IN ({$real_staff_placeholders}) AND resource_id = 0 ){$resource_branch} )
				   AND start_ts < %d
				   AND end_ts > %d
				   AND status NOT IN ('cancelled', 'trash', 'was-in-cart')",
				array_merge(
					$query_product_ids,
					$query_product_ids,
					$real_staff_ids,
					$resource_params,
					[ $end_ts, $start_ts ]
				)
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		} else {
			$staff_placeholders       = implode( ',', array_fill( 0, count( $staff_ids_filter ), '%d' ) );
			$real_staff_placeholders  = implode( ',', array_fill( 0, count( $real_staff_ids ), '%d' ) );
			// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Cache table from wpdb; dynamic IN placeholders; IDs int-cast.
			$sql = $wpdb->prepare(
				"SELECT source_id, staff_id, start_ts, end_ts, qty, status, product_id, resource_id
				 FROM {$table}
				 WHERE source = 'appointment'
				   AND ( ( product_id IN ({$product_placeholders}) AND staff_id IN ({$staff_placeholders}) AND resource_id = 0 )
				     OR ( product_id NOT IN ({$product_placeholders}) AND staff_id IN ({$real_staff_placeholders}) AND resource_id = 0 ){$resource_branch} )
				   AND start_ts < %d
				   AND end_ts > %d
				   AND status NOT IN ('cancelled', 'trash', 'was-in-cart')",
				array_merge(
					$query_product_ids,
					$staff_ids_filter,
					$query_product_ids,
					$real_staff_ids,
					$resource_params,
					[ $end_ts, $start_ts ]
				)
			);
			// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $sql, 'ARRAY_A' ) ?: [];

		$this->query_count++;
		$this->query_time_ms += ( microtime( true ) - $query_start ) * 1000;

		return $rows;
	}

	// ─── Sort (used by index path) ──────────────────────────────

	/**
	 * Sort availability cache rows to match the legacy rule priority system.
	 *
	 * Sorted ascending so last element = highest override power (last-write-wins).
	 *
	 * @param array<int, array<string, mixed>> $rows Raw DB rows from the availability cache table.
	 * @return array<int, array<string, mixed>> Sorted rows.
	 */
	private static function sort_availability_rows( array $rows ): array {
		if ( count( $rows ) < 2 ) {
			return $rows;
		}

		static $scope_weight = [
			'global'   => 1,
			'product'  => 2,
			'location' => 3,
			'resource' => 4,
			'staff'    => 5,
		];

		usort(
             $rows,
            static function ( array $a, array $b ) use ( $scope_weight ): int {
			// 1. Priority number: lower number = higher override = sorted LAST.
			$pa = (int) $a['priority'];
			$pb = (int) $b['priority'];
			if ( $pa !== $pb ) {
					return $pa < $pb ? 1 : -1;
			}

			// Full-day block rows sort after time rows at the same priority (see full_day_block on dynamic rules).
			$block_a = 'no' === ( $a['appointable'] ?? 'yes' ) && in_array( $a['range_type'] ?? '', [ 'custom', 'days', 'weeks', 'months' ], true );
			$block_b = 'no' === ( $b['appointable'] ?? 'yes' ) && in_array( $b['range_type'] ?? '', [ 'custom', 'days', 'weeks', 'months' ], true );
			if ( $block_a !== $block_b ) {
					return $block_a ? 1 : -1;
			}

			// Physical Closed veto at equal priority (matches sort_rules_callback):
			// location/resource Closed last vs any Open.
			$phys_closed_a = in_array( $a['scope'] ?? '', [ 'location', 'resource' ], true ) && 'yes' !== ( $a['appointable'] ?? 'yes' );
			$phys_closed_b = in_array( $b['scope'] ?? '', [ 'location', 'resource' ], true ) && 'yes' !== ( $b['appointable'] ?? 'yes' );
			if ( $phys_closed_a !== $phys_closed_b ) {
					return $phys_closed_a ? 1 : -1;
			}

			// 2. Scope / level: higher weight = higher override = sorted LAST.
			$sa = $scope_weight[ $a['scope'] ?? 'global' ] ?? 1;
			$sb = $scope_weight[ $b['scope'] ?? 'global' ] ?? 1;
			if ( $sa !== $sb ) {
					return $sa < $sb ? -1 : 1;
			}

			// 3. Specificity: day-specific time rules override general time rules.
			$spec_a = self::get_row_specificity( $a );
			$spec_b = self::get_row_specificity( $b );
			$both_time_family = self::is_time_family_row( $a ) && self::is_time_family_row( $b );
			// Match dynamic rule sorting: apply specificity only for time-family vs time-family.
			// Date-scoped custom rules must keep admin ordering precedence against weekday time rules.
			if ( $both_time_family && $spec_a !== $spec_b ) {
					return $spec_a > $spec_b ? 1 : -1;
			}

			// 4. Ordering: higher DB ordering = later in admin UI = higher override = sorted LAST.
			// The dynamic path array_reverse()s rules before assigning order indices,
			// so the last admin rule gets order=0 and "lower order = sorted LAST".
			// In the DB, ordering is the direct admin position (first=0, second=1),
			// so we must sort higher ordering LAST to match.
			$oa = (int) $a['ordering'];
			$ob = (int) $b['ordering'];
			return $oa > $ob ? 1 : -1;
		}
            );

		return $rows;
	}

	/**
	 * Get specificity score for a cache row.
	 *
	 * @param array<string, mixed> $row Cache row.
	 * @return int Specificity score (higher = more specific).
	 */
	private static function get_row_specificity( array $row ): int {
		$type = $row['range_type'] ?? '';
		if ( str_starts_with( $type, 'time:' ) && 'time:range' !== $type ) {
			return 2;
		}
		return 1;
	}

	/**
	 * Check if an indexed row belongs to the time-rule family.
	 *
	 * @param array<string, mixed> $row Cache row.
	 * @return bool
	 */
	private static function is_time_family_row( array $row ): bool {
		$type = (string) ( $row['range_type'] ?? '' );
		if ( 'time' === $type || 'time:range' === $type ) {
			return true;
		}
		return 0 === strpos( $type, 'time:' );
	}

	// ─── Minute-mask from index rows ────────────────────────────

	/**
	 * Build minute-mask for a single day from availability cache rows.
	 *
	 * Replicates the Rule Resolver's algorithm but using pre-computed
	 * cache table rows instead of parsing meta rules.
	 *
	 * @param array<int, array<string, mixed>> $availability_rows Cache rows (pre-sorted).
	 * @param int                              $day_midnight      Midnight timestamp for the day.
	 * @param bool                             $default_avail    Product default availability.
	 * @param int                              $interval         Slot duration in minutes.
	 * @param int                              $staff_id         Staff ID being evaluated.
	 * @return array<int, array{0: bool, 1: int}> Minute index => [appointable, qty].
	 */
	private function build_minute_mask_from_index_rows(
		array $availability_rows,
		int $day_midnight,
		bool $default_avail,
		int $interval,
		int $staff_id
	): array {
		$day_end = $day_midnight + 86400;
		$mask    = [];

		$max_minute = 1440 + $interval;
		for ( $m = 0; $m <= $max_minute; $m++ ) {
			$mask[ $m ] = [ $default_avail, 0 ];
		}

		// Filter rows that overlap this day.
		$day_rows = [];
		foreach ( $availability_rows as $row ) {
			$row_start = (int) $row['start_ts'];
			$row_end   = (int) $row['end_ts'];

			if ( $row_start >= $day_end || $row_end <= $day_midnight ) {
				continue;
			}

			$row_staff = (int) $row['staff_id'];
			if ( 0 !== $row_staff && $row_staff !== $staff_id ) {
				continue;
			}

			$day_rows[] = $row;
		}

		// 3-phase staff merge matching Rule Resolver behavior.
		$staff_masks = [];

		foreach ( $day_rows as $row ) {
			$row_start    = (int) $row['start_ts'];
			$row_end      = (int) $row['end_ts'];
			$appointable  = 'yes' === $row['appointable'];
			$row_qty      = (int) ( $row['qty'] ?? 0 );
			$row_scope    = $row['scope'] ?? 'global';
			$row_staff_id = (int) $row['staff_id'];

			$start_min = max( 0, (int) floor( ( $row_start - $day_midnight ) / 60 ) );
			$end_min   = min( $max_minute, (int) ceil( ( $row_end - $day_midnight ) / 60 ) );

			// Full-day range types always cover the entire civil day on the mask.
			$row_range_type = $row['range_type'] ?? '';
			if ( in_array( $row_range_type, [ 'days', 'months', 'weeks', 'custom' ], true ) ) {
				$start_min = 0;
				$end_min   = 1440;
			}

			// Legacy rows stop at civil midnight; new index rows include duration tail at write.
			// Match dynamic: only evening segments (start after midnight) get a duration tail.
			$tail_cap = min( $max_minute, 1440 + $interval );
			if ( $appointable && 1440 === $end_min && $end_min < $tail_cap && $row_end <= $day_end && $start_min > 0 ) {
				$end_min = $tail_cap;
			}

			// Staff-scope rows: accumulate separately.
			if ( 'staff' === $row_scope ) {
				// For specific staff evaluation, apply staff rows inline in sorted order.
				// This preserves priority semantics across global/product/staff rows.
				if ( 0 !== $staff_id && $row_staff_id === $staff_id ) {
					for ( $m = $start_min; $m < $end_min; $m++ ) {
						if ( isset( $mask[ $m ] ) ) {
							$mask[ $m ] = [ $appointable, $row_qty ];
						}
					}
					continue;
				}

				if ( ! isset( $staff_masks[ $row_staff_id ] ) ) {
					$staff_masks[ $row_staff_id ] = $mask;
				}

				for ( $m = $start_min; $m < $end_min; $m++ ) {
					if ( isset( $staff_masks[ $row_staff_id ][ $m ] ) ) {
						$staff_masks[ $row_staff_id ][ $m ] = [ $appointable, $row_qty ];
					}
				}

				continue;
			}

			// Do not clear $staff_masks here. Rows are processed in override order (see
			// sort_availability_rows); staff-scope rows may legitimately appear before a
			// full-day global/product "not available" row in the filtered day list, and
			// clearing would drop staff-specific availability that must still win at merge
			// (same as dynamic path when staff rules sort after globals).

			// Paint onto main mask.
			for ( $m = $start_min; $m < $end_min; $m++ ) {
				if ( isset( $mask[ $m ] ) ) {
					$mask[ $m ] = [ $appointable, $row_qty ];
				}
			}

			// Location/resource Closed must also close existing staff masks (physical veto vs union merge).
			if ( in_array( $row_scope, [ 'location', 'resource' ], true ) && ! $appointable && ! empty( $staff_masks ) ) {
				foreach ( $staff_masks as $sid => $unused ) {
					for ( $m = $start_min; $m < $end_min; $m++ ) {
						if ( isset( $staff_masks[ $sid ][ $m ] ) ) {
							$staff_masks[ $sid ][ $m ] = [ false, $row_qty ];
						}
					}
				}
			}
		}

		// Merge staff masks.
		if ( ! empty( $staff_masks ) ) {
			if ( 0 !== $staff_id && isset( $staff_masks[ $staff_id ] ) ) {
				// Specific staff: staff mask already inherits global+product rules
				// (initialized from $mask) with staff rules painted on top.
				// Use it directly so staff rules can both ADD and REMOVE availability,
				// properly overriding global/product rules at the same priority level.
				$mask = $staff_masks[ $staff_id ];
			} else {
				foreach ( $staff_masks as $s_mask ) {
					$mask = WC_Appointment_Slots_Rule_Resolver::merge_staff_mask_public( $mask, $s_mask, $max_minute );
				}
			}
		}

		return $mask;
	}

	// ─── Overlap index builders ─────────────────────────────────

	/**
	 * Snap day-unit booking interval to civil day keys when span is an exact multiple of 86400s.
	 *
	 * Start/end can be stored as start + N×24h without aligned civil midnight, so the exclusive end
	 * can mark the wrong calendar day busy. Preserving span from civil start-of-day fixes it.
	 *
	 * @param int                         $start         Start timestamp (before padding).
	 * @param int                         $end           Exclusive end (before padding).
	 * @param WC_Product_Appointment|null $appt_product  Appointment product.
	 * @return array{0: int, 1: int} Adjusted [ start, end ].
	 */
	private function align_day_unit_booking_to_civil_day_keys( int $start, int $end, $appt_product ): array {
		if ( ! $appt_product instanceof WC_Product_Appointment ) {
			return [ $start, $end ];
		}
		if ( WC_Product_Appointment::DURATION_UNIT_DAY !== $appt_product->get_duration_unit() ) {
			return [ $start, $end ];
		}
		$span = $end - $start;
		if ( $span <= 0 || 0 !== ( $span % 86400 ) ) {
			return [ $start, $end ];
		}
		$start_mid = $this->build_civil_day_key_from_slot_timestamp( $start )->getTimestamp();

		return [ $start_mid, $start_mid + $span ];
	}

	/**
	 * Resolve the [before, after] padding minutes for a product, with a per-call cache.
	 *
	 * @param int                                                         $product_id Product ID.
	 * @param mixed                                                       $product    Loaded product object if available, else null/false.
	 * @param array<int, array{before: int, after: int}>                  $cache      Per-call cache keyed by product ID (by reference).
	 * @return array{0: int, 1: int} [ before_minutes, after_minutes ]
	 */
	private function padding_pair_for_product( int $product_id, $product, array &$cache ): array {
		if ( ! array_key_exists( $product_id, $cache ) ) {
			$cache[ $product_id ] = [
				'before' => ( $product instanceof WC_Product_Appointment ) ? $product->get_padding_before_in_minutes() : 0,
				'after'  => ( $product instanceof WC_Product_Appointment ) ? $product->get_padding_after_in_minutes() : 0,
			];
		}

		return [ $cache[ $product_id ]['before'], $cache[ $product_id ]['after'] ];
	}

	/**
	 * Build overlap index from appointment cache rows (index path).
	 *
	 * @param array<int, array<string, mixed>> $appointment_rows Raw DB rows.
	 * @param WC_Product_Appointment           $product          Product for padding/capacity.
	 * @return array<int, array<int, array<int, array{start: int, end: int, qty: int, id: int}>>>
	 */
	private function build_overlap_index_from_rows( array $appointment_rows, WC_Product_Appointment $product ): array {
		$index         = [];
		$query_before  = $product->get_padding_before_in_minutes();
		$query_after   = $product->get_padding_after_in_minutes();
		$product_id    = $product->get_id();
		$padding_cache = [ $product_id => [ 'before' => $query_before, 'after' => $query_after ] ];
		$products_by_id = [ $product_id => $product ];
		$location_ids   = $this->location_ids_for_source_ids( array_column( $appointment_rows, 'source_id' ) );
		$staff_ids_map  = $this->staff_ids_for_source_ids( array_column( $appointment_rows, 'source_id' ) );

		foreach ( $appointment_rows as $row ) {
			$start          = (int) $row['start_ts'];
			$end            = (int) $row['end_ts'];
			$qty            = max( 1, (int) $row['qty'] );
			$source_id      = (int) $row['source_id'];
			$row_staff      = (int) $row['staff_id'];
			$row_product_id = (int) ( $row['product_id'] ?? $product_id );
			$row_resource   = (int) ( $row['resource_id'] ?? 0 );

			if ( ! array_key_exists( $row_product_id, $products_by_id ) ) {
				$loaded = wc_get_product( $row_product_id );
				$products_by_id[ $row_product_id ] = ( $loaded instanceof WC_Product_Appointment ) ? $loaded : null;
			}
			$row_appt_product = $products_by_id[ $row_product_id ];
			if ( $row_appt_product instanceof WC_Product_Appointment ) {
				[ $start, $end ] = $this->align_day_unit_booking_to_civil_day_keys( $start, $end, $row_appt_product );
			}

			// Resource rows go to their own bucket, skip cross-product blocking and qty filters.
			if ( $row_resource > 0 ) {
				$entry = [
					'start'       => $start,
					'end'         => $end,
					'qty'         => (int) $qty,
					'id'          => $source_id,
					'product_id'  => $row_product_id,
					'location_id' => (int) ( $location_ids[ $source_id ] ?? 0 ),
					'staff_ids'   => $staff_ids_map[ $source_id ] ?? [ 0 ],
				];

				$row_unit = ( $row_appt_product instanceof WC_Product_Appointment )
					? $row_appt_product->get_duration_unit()
					: '';
				$dt_day   = in_array( $row_unit, [ 'day', 'month' ], true )
					? $this->build_civil_day_key_from_slot_timestamp( $start )
					: $this->build_timed_day_key_from_slot_timestamp( $start );
				$day_ts   = $dt_day->getTimestamp();
				while ( $day_ts < $end ) {
					$index['resource'][ $row_resource ][ $day_ts ][] = $entry;
					$dt_day = $dt_day->modify( '+1 day' );
					$day_ts = $dt_day->getTimestamp();
				}
				continue;
			}

			// Staff/product rows: padding and cross-product blocking (unchanged).
			[ $stored_before, $stored_after ] = $this->padding_pair_for_product( $row_product_id, $row_appt_product, $padding_cache );
			$reserve_before = $stored_before + $query_after;
			$reserve_after  = $stored_after + $query_before;
			if ( $reserve_before > 0 ) {
				$start -= $reserve_before * 60;
			}
			if ( $reserve_after > 0 ) {
				$end += $reserve_after * 60;
			}

			if ( $row_product_id && $row_product_id !== $product_id ) {
				$check = apply_filters( 'wc_appointments_check_appointment_product', true, $source_id, $product_id );
				$check = apply_filters( 'wc_apointments_check_appointment_product', $check, $source_id, $product_id );
				if ( $check ) {
					$qty = max( 1, $product->get_available_qty() );
				}
			}

			if ( has_filter( 'wc_appointments_check_appointment_qty' ) ) {
				$appointment_obj = get_wc_appointment( $source_id );
				if ( $appointment_obj ) {
					$qty = apply_filters( 'wc_appointments_check_appointment_qty', $qty, $appointment_obj, $product );
				}
			}

			$entry = [
				'start'       => $start,
				'end'         => $end,
				'qty'         => (int) $qty,
				'id'          => $source_id,
				'product_id'  => $row_product_id,
				'location_id' => (int) ( $location_ids[ $source_id ] ?? 0 ),
			];

			$row_unit = ( $row_appt_product instanceof WC_Product_Appointment )
				? $row_appt_product->get_duration_unit()
				: '';
			$dt_day   = in_array( $row_unit, [ 'day', 'month' ], true )
				? $this->build_civil_day_key_from_slot_timestamp( $start )
				: $this->build_timed_day_key_from_slot_timestamp( $start );
			$day_ts   = $dt_day->getTimestamp();
			while ( $day_ts < $end ) {
				$index[ $row_staff ][ $day_ts ][] = $entry;
				$dt_day = $dt_day->modify( '+1 day' );
				$day_ts = $dt_day->getTimestamp();
			}
		}

		return $index;
	}

	/**
	 * Build overlap index from appointment objects (dynamic path).
	 *
	 * @param array<int, WC_Appointment> $existing_appointments Appointment objects.
	 * @param WC_Product_Appointment     $product              Product for padding/capacity.
	 * @return array<int, array<int, array<int, array{start: int, end: int, qty: int, id: int}>>>
	 */
	private function build_overlap_index_from_objects( array $existing_appointments, WC_Product_Appointment $product ): array {
		$index         = [];
		$query_before  = $product->get_padding_before_in_minutes();
		$query_after   = $product->get_padding_after_in_minutes();
		$product_id    = $product->get_id();
		$padding_cache = [ $product_id => [ 'before' => $query_before, 'after' => $query_after ] ];

		foreach ( $existing_appointments as $appointment ) {
			$appt_start = $appointment->get_start();
			$appt_end   = $appointment->get_end();

			if ( empty( $appt_start ) || empty( $appt_end ) ) {
				continue;
			}

			// All-day appointments: force end to midnight next day.
			if ( $appointment->is_all_day() && in_array( $product->get_duration_unit(), [ 'minute', 'hour' ], true ) ) {
				$appt_end = $this->build_timed_day_key_from_slot_timestamp( $appt_end )->modify( '+1 day' )->getTimestamp();
			}

			// Day/month appointments: snap start to midnight. End is already stored as an exclusive
			// boundary (see WC_Appointment::get_end); do not add +1 day — that duplicated the index
			// path mismatch and blocked the calendar day after the booking when indexed cache was off.
			$appt_product = $appointment->get_product();
			$appt_unit    = ( $appt_product instanceof WC_Product_Appointment )
				? $appt_product->get_duration_unit()
				: '';
			if ( $appt_product instanceof WC_Product_Appointment ) {
				[ $appt_start, $appt_end ] = $this->align_day_unit_booking_to_civil_day_keys( $appt_start, $appt_end, $appt_product );
			}
			if ( in_array( $appt_unit, [ 'day', 'month' ], true ) ) {
				$appt_start = $this->build_civil_day_key_from_slot_timestamp( $appt_start )->getTimestamp();
			}

			// Resource-only appointments (loaded for cross-product resource
			// sharing) skip the staff/product bucket. Only the resource bucket below.
			$appt_product_id = $appointment->get_product_id();
			$resource_only   = (bool) $appointment->get_meta( '_wca_resource_only' );

			if ( ! $resource_only ) {
				// Gap between neighbors is earlier.after + later.before. See build_overlap_index_from_rows.
				[ $stored_before, $stored_after ] = $this->padding_pair_for_product( $appt_product_id, $appt_product, $padding_cache );
				$reserve_before = $stored_before + $query_after;
				$reserve_after  = $stored_after + $query_before;
				if ( $reserve_before > 0 ) {
					$appt_start = strtotime( "-{$reserve_before} minutes", $appt_start );
				}
				if ( $reserve_after > 0 ) {
					$appt_end = strtotime( "+{$reserve_after} minutes", $appt_end );
				}

				$qty = max( 1, (int) $appointment->get_qty() );

				if ( $appt_product_id && $appt_product_id !== $product_id ) {
					$check = apply_filters( 'wc_appointments_check_appointment_product', true, $appointment->get_id(), $product_id );
					$check = apply_filters( 'wc_apointments_check_appointment_product', $check, $appointment->get_id(), $product_id );
					if ( $check ) {
						$qty = max( 1, $product->get_available_qty() );
					}
				}

				if ( has_filter( 'wc_appointments_check_appointment_qty' ) ) {
					$qty = apply_filters( 'wc_appointments_check_appointment_qty', $qty, $appointment, $product );
				}

				$entry = [
					'start'       => (int) $appt_start,
					'end'         => (int) $appt_end,
					'qty'         => (int) $qty,
					'id'          => (int) $appointment->get_id(),
					'product_id'  => (int) $appt_product_id,
					'location_id' => (int) $appointment->get_location_id(),
				];

				$dt_day  = in_array( $appt_unit, [ 'day', 'month' ], true )
					? $this->build_civil_day_key_from_slot_timestamp( $appt_start )
					: $this->build_timed_day_key_from_slot_timestamp( $appt_start );
				$day_ts  = $dt_day->getTimestamp();
				$first_index_day_ts = $day_ts;
				$staff_ids = $appointment->get_staff_ids();
				$staff_ids = is_array( $staff_ids ) ? array_map( 'intval', $staff_ids ) : [];
				if ( empty( $staff_ids ) ) {
					$staff_ids = [ 0 ];
				}
				while ( $day_ts < $appt_end ) {
					foreach ( $staff_ids as $sid ) {
						$index[ $sid ][ $day_ts ][] = $entry;
					}
					$dt_day = $dt_day->modify( '+1 day' );
					$day_ts = $dt_day->getTimestamp();
				}
			}

			// Resource allocations go to separate bucket.
			$allocs = is_a( $appointment, 'WC_Appointment' ) ? $appointment->get_resource_allocations() : [];
			if ( [] !== $allocs ) {
				$res_pad_before = ( $appt_product instanceof WC_Product_Appointment ) ? (int) $appt_product->get_padding_before_in_minutes() : 0;
				$res_pad_after  = ( $appt_product instanceof WC_Product_Appointment ) ? (int) $appt_product->get_padding_after_in_minutes() : 0;
				$res_start = (int) $appointment->get_start() - ( $res_pad_before * 60 );
				$res_end   = (int) $appointment->get_end() + ( $res_pad_after * 60 );

				foreach ( $allocs as $alloc ) {
					$rid = (int) ( $alloc['resource_id'] ?? 0 );
					if ( $rid <= 0 ) {
						continue;
					}
					$staff_ids = method_exists( $appointment, 'get_staff_ids' ) ? $appointment->get_staff_ids() : [];
					$staff_ids = is_array( $staff_ids ) ? array_values( array_filter( array_map( 'intval', $staff_ids ) ) ) : [];
					if ( [] === $staff_ids ) {
						$staff_ids = [ 0 ];
					}
					$res_entry = [
						'start'       => $res_start,
						'end'         => $res_end,
						'qty'         => max( 1, (int) ( $alloc['qty_consumed'] ?? 1 ) ),
						'id'          => (int) $appointment->get_id(),
						'product_id'  => $appt_product_id,
						'location_id' => method_exists( $appointment, 'get_location_id' ) ? (int) $appointment->get_location_id() : 0,
						'staff_ids'   => $staff_ids,
					];
					$dt_r = in_array( $appt_unit, [ 'day', 'month' ], true )
						? $this->build_civil_day_key_from_slot_timestamp( $res_start )
						: $this->build_timed_day_key_from_slot_timestamp( $res_start );
					$day_r = $dt_r->getTimestamp();
					while ( $day_r < $res_end ) {
						$index['resource'][ $rid ][ $day_r ][] = $res_entry;
						$dt_r  = $dt_r->modify( '+1 day' );
						$day_r = $dt_r->getTimestamp();
					}
				}
			}
		}

		return $index;
	}

	/**
	 * Appointment source_id => location_id from post meta (one query).
	 *
	 * @param array<int, int|string> $source_ids Appointment IDs.
	 * @return array<int, int>
	 */
	private function location_ids_for_source_ids( array $source_ids ): array {
		$source_ids = array_values( array_unique( array_filter( array_map( 'intval', $source_ids ) ) ) );
		if ( [] === $source_ids ) {
			return [];
		}

		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $source_ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN list of int IDs.
		$sql = $wpdb->prepare(
			"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id IN ({$placeholders})",
			array_merge( [ '_appointment_location_id' ], $source_ids )
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $sql, ARRAY_A ) ?: [];
		$map  = [];
		foreach ( $rows as $row ) {
			$map[ (int) $row['post_id'] ] = (int) $row['meta_value'];
		}

		return $map;
	}

	/**
	 * Appointment source_id => staff ID list from post meta (one query).
	 *
	 * @param array<int, int|string> $source_ids Appointment IDs.
	 * @return array<int, int[]>
	 */
	private function staff_ids_for_source_ids( array $source_ids ): array {
		$source_ids = array_values( array_unique( array_filter( array_map( 'intval', $source_ids ) ) ) );
		if ( [] === $source_ids ) {
			return [];
		}

		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $source_ids ), '%d' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders -- Dynamic IN list of int IDs.
		$sql = $wpdb->prepare(
			"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id IN ({$placeholders})",
			array_merge( [ '_appointment_staff_id' ], $source_ids )
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $sql, ARRAY_A ) ?: [];
		$map  = [];
		foreach ( $rows as $row ) {
			$pid = (int) $row['post_id'];
			$sid = (int) $row['meta_value'];
			if ( $sid <= 0 ) {
				continue;
			}
			$map[ $pid ][] = $sid;
		}
		foreach ( $map as $pid => $ids ) {
			$map[ $pid ] = array_values( array_unique( $ids ) );
		}

		return $map;
	}
}
