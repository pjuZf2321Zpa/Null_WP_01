<?php
/**
 * Engine Helpers Trait — shared logic for both Index and Dynamic engines.
 *
 * Eliminates code duplication between the two engines by extracting common
 * algorithms into a single trait:
 *
 *   - cap_end_date()          — clamp end timestamp to product's max future date.
 *   - minute_mask_to_ranges() — convert minute-mask array to contiguous ranges.
 *   - count_overlapping()     — sum booked qty that overlaps a slot from overlap index.
 *   - should_skip_slot()      — unified slot filter (past time, min/max, span guard).
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Trait WC_Appointment_Slots_Engine_Helpers
 *
 * @since 5.3.0
 */
trait WC_Appointment_Slots_Engine_Helpers {

	/**
	 * Cap end date to product's max allowed future date.
	 *
	 * Replicates the private WC_Product_Appointment::get_max_allowed_date_into_the_future()
	 * logic without calling the private method.
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @param int                    $end_ts  Proposed end timestamp.
	 * @return int Capped end timestamp.
	 */
	private static function cap_end_date( WC_Product_Appointment $product, int $end_ts ): int {
		$max_date_a = $product->get_max_date_a();
		$max_end    = strtotime( "+{$max_date_a['value']} {$max_date_a['unit']}", time() );

		return $end_ts > $max_end ? $max_end : $end_ts;
	}

	/**
	 * Convert a minute-mask to contiguous appointable ranges with capacity.
	 *
	 * Identical range output to WC_Product_Appointment::get_appointable_minute_start_and_end(),
	 * plus the minimum rule qty within each range (for capacity override).
	 *
	 * @param array<int, array{0: bool, 1: int}> $mask Minute index => [appointable, qty].
	 * @return array<array{0: int, 1: int, 2: int}> Ranges as [start_minute, end_minute, min_qty] triples.
	 */
	private static function minute_mask_to_ranges( array $mask ): array {
		if ( empty( $mask ) ) {
			return [];
		}
		$ranges      = [];
		$in_range    = false;
		$range_start = 0;
		$range_qty   = 0;
		$max_minute  = (int) array_key_last( $mask );

		for ( $minute = 0; $minute <= $max_minute; $minute++ ) {
			$entry       = $mask[ $minute ];
			$appointable = $entry[0];
			$qty         = $entry[1];

			if ( $appointable && ! $in_range ) {
				$in_range    = true;
				$range_start = $minute;
				$range_qty   = $qty;
			} elseif ( $appointable && $in_range ) {
				if ( $qty > 0 && ( 0 === $range_qty || $qty < $range_qty ) ) {
					$range_qty = $qty;
				}
			} elseif ( ! $appointable && $in_range ) {
				$in_range = false;
				$ranges[] = [ $range_start, $minute, $range_qty ];
			}
		}

		if ( $in_range ) {
			$ranges[] = [ $range_start, $max_minute + 1, $range_qty ];
		}

		return $ranges;
	}

	/**
	 * Build day-key timestamp for overlap index lookup.
	 *
	 * Day/month: civil date token (gmdate Y-m-d → UTC midnight; timezone-agnostic).
	 * Minute/hour: Fake UTC site civil day (see WC_Appointment_Slots_Engine::timed_overlap_day_key_ts()).
	 *
	 * @since 5.3.0
	 * @param int  $timestamp     Slot start timestamp.
	 * @param bool $timed_overlap True for minute/hour slot capacity (never use civil-token fast path).
	 * @return int Day-key timestamp for index lookup.
	 */
	private static function get_slot_day_key( int $timestamp, bool $timed_overlap = false ): int {
		if ( $timed_overlap ) {
			return WC_Appointment_Slots_Engine::timed_overlap_day_key_ts( $timestamp );
		}

		$is_utc_midnight = '00:00:00' === gmdate( 'H:i:s', $timestamp );

		// UTC midnight = day-unit "date token". Return UTC midnight to match normalizer.
		if ( $is_utc_midnight ) {
			return ( new DateTimeImmutable( gmdate( 'Y-m-d 00:00:00', $timestamp ), new DateTimeZone( 'UTC' ) ) )->getTimestamp();
		}

		// Legacy non-token timed fallback (day/month path should not reach here).
		$site_tz = new DateTimeZone( wc_timezone_string() );
		return ( new DateTimeImmutable( wp_date( 'Y-m-d 00:00:00', $timestamp ), $site_tz ) )->getTimestamp();
	}

	/**
	 * Count overlapping booked quantity for a slot from the overlap index.
	 *
	 * Supports day-indexed format (staff_id => day_ts => [entries]) for O(day_entries)
	 * instead of O(all_entries). Falls back to flat format when day key is absent.
	 *
	 * @since 5.3.0
	 * @param array<int|string, array<int, mixed>> $overlap_index Overlap index keyed by staff_id (or 'resource'), then optionally by day_ts.
	 * @param int                                  $slot_start    Slot start timestamp.
	 * @param int                                  $slot_end      Slot end timestamp.
	 * @param int                                  $staff_id      Staff ID to check.
	 * @return int Total booked quantity overlapping this slot.
	 */
	private static function count_overlapping( array $overlap_index, int $slot_start, int $slot_end, int $staff_id, bool $timed_overlap = false, int $location_id = 0, int $product_id = 0, int $slot_day_key = 0 ): int {
		$booked = 0;

		$sum_entries = static function ( array $entries ) use ( $slot_start, $slot_end, $location_id, $product_id, &$booked ): void {
			foreach ( $entries as $entry ) {
				if ( WC_Appointment_Slots_Engine::is_overlap_entry_excluded( $entry ) ) {
					continue;
				}
				if ( $location_id > 0 ) {
					$entry_loc = (int) ( $entry['location_id'] ?? 0 );
					if ( $entry_loc > 0 && $entry_loc !== $location_id ) {
						continue;
					}
					$entry_pid = (int) ( $entry['product_id'] ?? 0 );
					if ( $product_id > 0 && $entry_pid > 0 && $entry_pid !== $product_id ) {
						continue;
					}
				}
				if ( $entry['start'] < $slot_end && $entry['end'] > $slot_start ) {
					$booked += $entry['qty'];
				}
			}
		};

		// Early return if no entries for this staff.
		$by_staff = $overlap_index[ $staff_id ] ?? [];
		if ( empty( $by_staff ) ) {
			return $booked;
		}

		$first_key = array_key_first( $by_staff );

		// Guard against empty array (array_key_first returns null).
		if ( null === $first_key ) {
			return $booked;
		}

		// Day-indexed: keys are day timestamps (large integers). Only scan this day's entries.
		// Count only this staff's appointments. Do not add overlap_index[0] (no-preference bucket)
		// to individual staff counts — that would wrongly attribute unassigned appointments to
		// every staff and inflate capacity_booked (e.g. staff 2 showing 1020 booked vs 255 total).
		if ( is_int( $first_key ) && $first_key > 1000000000 ) {
			$slot_day = $slot_day_key > 0 ? $slot_day_key : self::get_slot_day_key( $slot_start, $timed_overlap );
			if ( isset( $by_staff[ $slot_day ] ) ) {
				$sum_entries( $by_staff[ $slot_day ] );
			}

			return $booked;
		}

		// Flat: staff_id => [entry, ...]. Only this staff entries.
		$sum_entries( $by_staff );
		return $booked;
	}

	/**
	 * Remaining available and appointment-booked seats for a slot window.
	 *
	 * People ceiling is `$cap_total` (staff Capacity when set, else product Capacity / rule Capacity).
	 * Staff occupancy is global (busy at every location). Unstaffed products scope product
	 * occupancy to the selected location. Resource Capacity may lower available without
	 * raising booked (staff Capacity larger than room Capacity).
	 *
	 * @param array<int|string, array<int, mixed>> $overlap_index Overlap index.
	 * @param int                                  $slot_start    Slot start.
	 * @param int                                  $slot_end      Slot end.
	 * @param int                                  $staff_id      Staff ID (0 = none).
	 * @param int                                  $cap_total     Staff or product cap for this slot.
	 * @param WC_Product_Appointment               $product       Product.
	 * @param bool                                 $timed_overlap Minute/hour overlap day keys.
	 * @param int                                  $slot_day_key  Precomputed day key (0 = derive).
	 * @return array{0: int, 1: int} [ available, booked ]
	 */
	private static function remaining_capacity(
		array $overlap_index,
		int $slot_start,
		int $slot_end,
		int $staff_id,
		int $cap_total,
		WC_Product_Appointment $product,
		bool $timed_overlap = false,
		int $slot_day_key = 0
	): array {
		$location_id = WC_Appointment_Slots_Engine::get_occupancy_location_id();
		$scope_loc   = ( $location_id > 0 && $product->has_locations() ) ? $location_id : 0;
		$product_id  = (int) $product->get_id();
		// Location scopes unstaffed product occupancy only. Staff capacity fully owns the people ceiling.
		$filter_loc  = ( $scope_loc > 0 && $staff_id <= 0 ) ? $scope_loc : 0;

		$booked    = self::count_overlapping(
			$overlap_index,
			$slot_start,
			$slot_end,
			$staff_id,
			$timed_overlap,
			$filter_loc,
			$product_id,
			$slot_day_key
		);
		$remaining = max( 0, $cap_total - $booked );

		// Location-eligible rooms may lower remaining (resource Capacity); venues without a matching room are unchanged.
		if ( $product->has_resources() ) {
			$remaining = self::resource_remaining_capacity(
				$overlap_index,
				$slot_start,
				$slot_end,
				$product,
				$remaining
			);
		}

		return [ $remaining, min( $cap_total, $booked ) ];
	}

	/**
	 * Min remaining across location-eligible required resources for a slot window.
	 *
	 * Capacity is max concurrent appointments (each booking consumes qty_consumed).
	 * Checked resources are an OR pool: sum free seats across alternatives (selected ID scopes to one).
	 * Rooms scoped to another venue are skipped (this venue does not need that room).
	 * Unscoped resources while venues exist are a hard miss: claim the resource to a venue first.
	 *
	 * @param array<int|string, array<int, mixed>> $overlap_index Full overlap index (includes optional 'resource' bucket).
	 * @param int                                  $slot_start    Slot start timestamp.
	 * @param int                                  $slot_end      Slot end timestamp.
	 * @param WC_Product_Appointment               $product       Product.
	 * @param int                                  $remaining     Current remaining from staff/product.
	 * @return int
	 */
	private static function resource_remaining_capacity(
		array $overlap_index,
		int $slot_start,
		int $slot_end,
		WC_Product_Appointment $product,
		int $remaining
	): int {
		if ( ! class_exists( 'WC_Appointments_Resource' ) ) {
			return $remaining;
		}

		$requirements = WC_Appointments_Resource::normalize_requirements( $product );
		if ( [] === $requirements ) {
			return $remaining;
		}

		// OR across checked resources. Selected ID scopes the pool to one.
		$selected_rid = WC_Appointment_Slots_Engine::get_occupancy_resource_id();
		if ( $selected_rid > 0 ) {
			$requirements = array_values(
				array_filter(
					$requirements,
					static function ( array $req ) use ( $selected_rid ): bool {
						return (int) $req['resource_id'] === $selected_rid;
					}
				)
			);
			if ( [] === $requirements ) {
				return 0;
			}
		}

		$resource_bucket = $overlap_index['resource'] ?? [];
		$booking_loc     = WC_Appointment_Slots_Engine::get_occupancy_location_id();
		$or_free         = 0;
		$eligible        = 0;
		$hard_miss       = false;

		foreach ( $requirements as $req ) {
			$rid = (int) $req['resource_id'];
			if ( ! WC_Appointments_Resource::is_available_at_location( $rid, $booking_loc ) ) {
				// Soft skip: room belongs to another venue. Hard miss: unscoped while venues exist.
					if ( WC_Appointments_Resource_Data_Store::get_location_id( $rid ) <= 0 ) {
					$hard_miss = true;
				}
				continue;
			}
			++$eligible;

			// OR-pool only: unavailable rooms contribute no seats (Closed blackout or
			// outside Open). Selected resource rules are already in the mask.
			if ( 0 === $selected_rid
				&& WC_Appointments_Resource::is_closed_for_window( $rid, $slot_start, $slot_end ) ) {
				continue;
			}

			$qty_consumed = (int) $req['qty_consumed'];
			$pool         = (int) $req['capacity'];
			$by_resource  = $resource_bucket[ $rid ] ?? [];
			$used         = 0;
			$seen         = [];
			$dt_day       = new DateTimeImmutable( gmdate( 'Y-m-d', $slot_start ) . ' 00:00:00', new DateTimeZone( 'UTC' ) );
			$day_ts       = $dt_day->getTimestamp();

			while ( $day_ts < $slot_end ) {
				foreach ( $by_resource[ $day_ts ] ?? [] as $entry ) {
					if ( WC_Appointment_Slots_Engine::is_overlap_entry_excluded( $entry ) ) {
						continue;
					}
					if ( $entry['start'] >= $slot_end || $entry['end'] <= $slot_start ) {
						continue;
					}
					$ekey = (int) $entry['id'];
					if ( isset( $seen[ $ekey ] ) ) {
						continue;
					}
					$seen[ $ekey ] = true;
					$used         += (int) $entry['qty'];
				}
				$dt_day = $dt_day->modify( '+1 day' );
				$day_ts = $dt_day->getTimestamp();
			}

			$resource_free = max( 0, $pool - $used );
			if ( $resource_free >= $qty_consumed ) {
				$or_free += (int) floor( $resource_free / $qty_consumed );
			}
		}

		if ( 0 === $eligible ) {
			// Unscoped-with-venues: close. Other-venue-only rooms: keep staff/product seats.
			return $hard_miss ? 0 : $remaining;
		}

		return $or_free > 0 ? min( $remaining, $or_free ) : 0;
	}

	/**
	 * Check whether a candidate slot should be skipped.
	 *
	 * Consolidates the 5 filter checks that both engines apply identically:
	 *   1. Span guard — slot must fit inside appointable range.
	 *   2. Past time check.
	 *   3. Min/max date check.
	 *   4. End date check — slot must not start after the requested end.
	 *   5. Break-out check — beyond range entirely (returns 'break').
	 *
	 * @param int    $slot_start       Slot start timestamp.
	 * @param int    $slot_end         Slot end timestamp.
	 * @param int    $range_end_time   End timestamp of the appointable range.
	 * @param string $availability_span Product availability span ('start' or '').
	 * @param bool   $get_past_times   Whether past times are allowed.
	 * @param int    $min_date         Minimum date timestamp for the start day.
	 * @param int    $current_time     Current timestamp.
	 * @param int    $min_check_from   Product min date timestamp.
	 * @param int    $max_check_to     Product max date timestamp.
	 * @param int    $end_ts           Requested range end timestamp.
	 * @param bool   $fake_utc_range_end When true, $end_ts is Fake UTC and check #4 uses gmdate() civil days.
	 * @return string skip_* reason code, or 'ok' to keep the slot.
	 */
	private static function should_skip_slot(
		int $slot_start,
		int $slot_end,
		int $range_end_time,
		string $availability_span,
		bool $get_past_times,
		int $min_date,
		int $current_time,
		int $min_check_from,
		int $max_check_to,
		int $end_ts,
		bool $fake_utc_range_end = false
	): string {
		// 1. Span guard: slot must fit inside appointable range.
		if ( 'start' !== $availability_span && $slot_end > $range_end_time ) {
			return 'skip_span_guard';
		}

		// 2. Past time check.
		if ( ! $get_past_times && ( $slot_start < $min_date || $slot_start <= $current_time ) ) {
			return 'skip_past_or_lead_time';
		}

		// 3. Min/max date check.
		if ( ! $get_past_times && ( $slot_start < $min_check_from || $slot_end < $min_check_from || $slot_start > $max_check_to ) ) {
			return 'skip_min_max_date';
		}

		// 4. End date check — minute/hour slots use Fake UTC; day/month use real instants.
		if ( $fake_utc_range_end ) {
			if ( gmdate( 'Y-m-d', $slot_start ) > gmdate( 'Y-m-d', $end_ts ) ) {
				return 'skip_out_of_range';
			}
		} elseif ( $slot_start > $end_ts ) {
			return 'skip_out_of_range';
		}

		return 'ok';
	}

	/**
	 * Compute slot iteration parameters from a range.
	 *
	 * Both engines use identical math to determine how many slots fit
	 * in a contiguous appointable range.
	 *
	 * @param int    $minutes_for_range Length of appointable range in minutes.
	 * @param int    $interval          Slot duration in minutes.
	 * @param int    $base_interval     Step interval in minutes.
	 * @param string $availability_span Product availability span.
	 * @param int    $range_start_min   Range start offset from day midnight (minutes).
	 * @param int    $range_end_min     Range end offset from day midnight (minutes).
	 * @return int Number of slots in this range (0 if range too small).
	 */
	private static function compute_slot_count(
		int $minutes_for_range,
		int $interval,
		int $base_interval,
		string $availability_span,
		int $range_start_min = 0,
		int $range_end_min = 0
	): int {
		// "Starting slot only": availability is evaluated at each grid start; the booking may extend
		// past the day's appointable range. Full-day ranges still allow starts when duration exceeds
		// the window (e.g. 25h in 24h). Tail fragments shorter than duration are not valid starts.
		if ( 'start' === $availability_span ) {
			if ( $minutes_for_range <= 0 ) {
				return 0;
			}
			if ( $minutes_for_range < $interval ) {
				if ( 0 === $range_start_min && $range_end_min >= 1440 ) {
					return 1;
				}
				return 0;
			}
			return 1;
		}

		if ( $minutes_for_range < $interval ) {
			return 0;
		}

		return (int) floor( ( $minutes_for_range - $interval ) / $base_interval ) + 1;
	}

	/**
	 * Whether every minute in [start, start + duration) is appointable on this day / next day.
	 *
	 * Mask tail minutes past 1440 are overlap-only; slot starts use grid_end at 1440 and this check.
	 *
	 * @param array<int, array{0: bool, 1: int}>      $day_mask      This civil day mask.
	 * @param array<int, array{0: bool, 1: int}>|null $next_day_mask Next civil day mask when duration crosses midnight.
	 * @param int                                     $start_min     Slot start offset from day midnight.
	 * @param int                                     $duration      Slot duration in minutes.
	 */
	private static function slot_start_fits_duration_in_mask(
		array $day_mask,
		?array $next_day_mask,
		int $start_min,
		int $duration
	): bool {
		$end_min = $start_min + $duration;
		for ( $m = $start_min; $m < $end_min; $m++ ) {
			if ( $m < 1440 ) {
				if ( empty( $day_mask[ $m ][0] ) ) {
					return false;
				}
			} elseif ( null === $next_day_mask || empty( $next_day_mask[ $m - 1440 ][0] ) ) {
				return false;
			}
		}
		return true;
	}
}
