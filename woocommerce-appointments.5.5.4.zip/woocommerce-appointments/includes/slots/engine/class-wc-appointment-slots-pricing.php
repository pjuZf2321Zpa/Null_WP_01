<?php
/**
 * Slot Pricing — computes per-slot price during generation.
 *
 * Evaluates the product's pricing rules against each slot's timestamp range
 * and returns a raw float price. This is a PREVIEW price — the authoritative
 * cost is still computed at checkout via WC_Appointments_Cost_Calculation.
 *
 * The preview price accounts for:
 *   - Product base price
 *   - Staff base cost (if applicable)
 *   - Pricing rules: days, months, weeks, custom, time, time:N, time:range
 *
 * Time and calendar fields for rules use gmdate() on the slot timestamp (slot-engine UTC facade),
 * consistent with wc_appointments_slot_token_formatted_times() and posted slot timestamps.
 *
 * It does NOT account for (deferred to checkout):
 *   - Customer-selected duration (slots/quant rule types)
 *   - Customer-selected quantity
 *   - Add-on durations
 *   - Filters that modify cost at checkout time
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Pricing — per-slot price computation.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Pricing {

	/**
	 * Cached pricing results per product+staff+time window.
	 * Key: "product_id:staff_id:hour:day_of_week"
	 *
	 * @var array<string, float>
	 */
	private static array $pricing_cache = [];

	/**
	 * Cached cost rules per product ID.
	 *
	 * @var array<int, array<int, mixed>>
	 */
	private static array $cost_rules_cache = [];

	/**
	 * Cached staff base costs per product+staff key.
	 *
	 * @var array<string, float>
	 */
	private static array $staff_cost_cache = [];

	/**
	 * Cached pricing defaults per product+staff key.
	 *
	 * @var array<string, float>
	 */
	private static array $defaults_cache = [];

	/**
	 * Cached slot price previews.
	 *
	 * @var array<string, array{raw: float|null, display: string|null, show: bool}>
	 */
	private static array $preview_cache = [];

	/**
	 * Cached pricing profiles per product ID.
	 *
	 * @var array<int, array{has_custom_date_rules: bool, has_month_rules: bool, has_week_rules: bool, has_day_rules: bool, has_time_rules: bool}>
	 */
	private static array $profile_cache = [];

	/**
	 * Dedupe map: raw price float → formatted HTML string.
	 * Avoids calling wc_price(wc_get_price_to_display()) more than once per unique price.
	 *
	 * @var array<string, string>
	 */
	private static array $format_cache = [];

	/**
	 * Preview price for a slot (raw, display HTML, whether to show).
	 *
	 * @param WC_Product_Appointment $product       Product.
	 * @param int                    $slot_start    Slot start timestamp.
	 * @param int                    $slot_end      Slot end timestamp.
	 * @param int                    $staff_id      Staff ID.
	 * @param string                 $duration_unit Duration unit.
	 * @return array{raw: float|null, display: string|null, show: bool}
	 */
	public static function get_slot_price_preview(
		WC_Product_Appointment $product,
		int $slot_start,
		int $slot_end,
		int $staff_id,
		string $duration_unit
	): array {
		$cache_key = self::build_pricing_cache_key( $product, $slot_start, $staff_id, $duration_unit ) . ':preview';

		if ( isset( self::$preview_cache[ $cache_key ] ) ) {
			return self::$preview_cache[ $cache_key ];
		}

		$default_price = self::get_default_slot_price_raw( $product, $staff_id );
		$raw_price     = self::compute_slot_price( $product, $slot_start, $slot_end, $staff_id, $duration_unit );
		// Only show price when slot is discounted (lower than base), and display like WooCommerce sale price.
		$show_price    = self::is_slot_price_discounted( $raw_price, $default_price );

		$preview = [
			'raw'     => $show_price ? $raw_price : null,
			'display' => $show_price ? self::format_display_price_discounted( $default_price, $raw_price, $product ) : null,
			'show'    => $show_price,
		];

		self::$preview_cache[ $cache_key ] = $preview;

		return $preview;
	}

	/**
	 * Fast path: compute raw price only (no formatting, no preview wrapper).
	 *
	 * Used by the engine to set price_raw on slots during creation.
	 * When {@see wc_appointments_slots_display_pricing()} is true for the product, always returns
	 * the computed raw price so the slot picker can show per-slot prices (base or sale).
	 * Otherwise returns null when the price equals the default (no discount) so only discounted
	 * slots carry a badge, saving downstream formatting work.
	 *
	 * @param WC_Product_Appointment $product       Product.
	 * @param int                    $slot_start    Slot start timestamp.
	 * @param int                    $slot_end      Slot end timestamp.
	 * @param int                    $staff_id      Staff ID (0 = no staff).
	 * @param string                 $duration_unit Duration unit.
	 * @return float|null Raw price, or null when display pricing is off and price equals default.
	 */
	public static function compute_slot_price_raw(
		WC_Product_Appointment $product,
		int $slot_start,
		int $slot_end,
		int $staff_id,
		string $duration_unit
	): ?float {
		$raw              = self::compute_slot_price( $product, $slot_start, $slot_end, $staff_id, $duration_unit );
		$default          = self::get_default_slot_price_raw( $product, $staff_id );
		$display_pricing  = wc_appointments_slots_display_pricing( $product );

		if ( $display_pricing ) {
			return $raw;
		}

		return self::is_slot_price_discounted( $raw, $default ) ? $raw : null;
	}

	/**
	 * Batch-format raw prices into HTML using a dedupe map.
	 *
	 * Each unique raw price calls wc_get_price_to_display + wc_price exactly once.
	 * Returns an associative array: raw_price_key => formatted HTML string.
	 *
	 * @param float[]                $raw_prices Unique raw price values to format.
	 * @param WC_Product_Appointment $product    Product for tax context.
	 * @return array<string, string> Map of price key to HTML.
	 */
	public static function batch_format_prices( array $raw_prices, WC_Product_Appointment $product ): array {
		$result = [];
		$product_id = $product->get_id();

		foreach ( $raw_prices as $raw ) {
			$key = $product_id . ':' . self::price_key( $raw );
			if ( ! isset( self::$format_cache[ $key ] ) ) {
				$display = wc_get_price_to_display( $product, [ 'qty' => 1, 'price' => $raw ] );
				self::$format_cache[ $key ] = wc_price( $display );
			}
			$result[ self::price_key( $raw ) ] = self::$format_cache[ $key ];
		}

		return $result;
	}

	/**
	 * Get cached formatted HTML for a single raw price.
	 *
	 * Uses the dedupe map — callers should call batch_format_prices() first
	 * for any prices they plan to display.
	 *
	 * @param float                  $raw_price Raw price.
	 * @param WC_Product_Appointment $product   Product for tax context.
	 * @return string Formatted HTML.
	 */
	public static function get_formatted_price( float $raw_price, WC_Product_Appointment $product ): string {
		$key = $product->get_id() . ':' . self::price_key( $raw_price );
		if ( ! isset( self::$format_cache[ $key ] ) ) {
			$display = wc_get_price_to_display( $product, [ 'qty' => 1, 'price' => $raw_price ] );
			self::$format_cache[ $key ] = wc_price( $display );
		}
		return self::$format_cache[ $key ];
	}

	/**
	 * Build a discounted price display string using the dedupe map.
	 *
	 * @param float                  $base_price Default/base price.
	 * @param float                  $sale_price Discounted price.
	 * @param WC_Product_Appointment $product    Product.
	 * @return string HTML with <del> base </del> <ins> sale </ins>.
	 */
	public static function format_discounted_cached( float $base_price, float $sale_price, WC_Product_Appointment $product ): string {
		$base_html = self::get_formatted_price( $base_price, $product );
		$sale_html = self::get_formatted_price( $sale_price, $product );
		return '<del aria-hidden="true">' . $base_html . '</del> <ins>' . $sale_html . '</ins>';
	}

	/**
	 * Normalize a float to a stable string key for the dedupe map.
	 *
	 * @param float $price Price value.
	 * @return string Stable key.
	 */
	private static function price_key( float $price ): string {
		return number_format( $price, wc_get_price_decimals() + 2, '.', '' );
	}

	/**
	 * Compute the preview price for a single slot.
	 *
	 * @param WC_Product_Appointment $product   The appointment product.
	 * @param int                    $slot_start Slot start timestamp.
	 * @param int                    $slot_end   Slot end timestamp.
	 * @param int                    $staff_id   Staff ID (0 = no staff).
	 * @param string                 $duration_unit Product duration unit.
	 * @return float Computed slot price (raw, before tax).
	 */
	public static function compute_slot_price(
		WC_Product_Appointment $product,
		int $slot_start,
		int $slot_end,
		int $staff_id,
		string $duration_unit,
		?float $unit_base = null
	): float {
		if ( null !== $unit_base ) {
			return self::compute_slot_price_internal( $product, $slot_start, $slot_end, $staff_id, $duration_unit, $unit_base );
		}

		$product_id = $product->get_id();
		$cache_key  = self::build_pricing_cache_key( $product, $slot_start, $staff_id, $duration_unit );

		if ( isset( self::$pricing_cache[ $cache_key ] ) ) {
			return self::$pricing_cache[ $cache_key ];
		}

		if ( ! WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			$price = self::compute_slot_price_internal( $product, $slot_start, $slot_end, $staff_id, $duration_unit, null );
		} else {
			$start = microtime( true );
			$price = self::compute_slot_price_internal( $product, $slot_start, $slot_end, $staff_id, $duration_unit, null );
			$elapsed = ( microtime( true ) - $start ) * 1000;
			
			// Log slow pricing calls (>0.1ms)
			if ( $elapsed > 0.1 ) {
				WC_Appointment_Slots_Perf_Logger::log( 'slow_pricing', [
					'product' => $product_id,
					'staff' => $staff_id,
					'slot_time' => date( 'Y-m-d H:i', $slot_start ),
					'ms' => round( $elapsed, 3 ),
				] );
			}
		}

		// Cache the result
		self::$pricing_cache[ $cache_key ] = $price;
		return $price;
	}

	/**
	 * Internal pricing computation without timing overhead.
	 */
	private static function compute_slot_price_internal(
		WC_Product_Appointment $product,
		int $slot_start,
		int $slot_end,
		int $staff_id,
		string $duration_unit,
		?float $unit_base = null
	): float {
		$product_id = $product->get_id();

		// Base price (product + staff), or checkout unit base when supplied.
		if ( null !== $unit_base ) {
			$base_cost = max( 0, (float) $unit_base );
		} else {
			$base_cost = max( 0, (float) $product->get_price() );
			if ( $staff_id > 0 ) {
				$base_cost += self::get_staff_base_cost( $product, $staff_id );
			}
		}

		// Get pricing rules.
		$costs = self::get_cached_cost_rules( $product );
		if ( empty( $costs ) ) {
			return $base_cost;
		}

		$slot_local_minutes = ( (int) gmdate( 'G', $slot_start ) ) * 60 + (int) gmdate( 'i', $slot_start );
		$slot_year          = (int) gmdate( 'Y', $slot_start );
		$slot_month         = (int) gmdate( 'n', $slot_start );
		$slot_day           = (int) gmdate( 'j', $slot_start );
		$slot_dow_iso       = (int) gmdate( 'N', $slot_start );
		$slot_iso_week      = (int) gmdate( 'W', $slot_start );

		// Evaluate pricing rules for this slot.
		$slot_cost = 0.0;
		$applied_base_rules = [];

		foreach ( $costs as $rule_key => $rule ) {
			$type  = $rule[0];
			$rules = $rule[1];

			if ( strrpos( $type, 'time' ) === 0 ) {
				if ( ! in_array( $duration_unit, [ 'minute', 'hour' ], true ) ) {
					continue;
				}

				if ( 'time:range' === $type ) {
					$year  = $slot_year;
					$month = $slot_month;
					$day   = $slot_day;

					if ( ! isset( $rules[ $year ][ $month ][ $day ] ) ) {
						continue;
					}

					$rule_val = $rules[ $year ][ $month ][ $day ]['rule'];
					$from     = $rules[ $year ][ $month ][ $day ]['from'];
					$to       = $rules[ $year ][ $month ][ $day ]['to'];
				} else {
					if ( ! empty( $rules['day'] ) && (int) $rules['day'] !== $slot_dow_iso ) {
						continue;
					}

					$rule_val = $rules['rule'];
					$from     = $rules['from'];
					$to       = $rules['to'];
				}

				// Convert to minutes-from-midnight so we compare like-with-like.
				$from_minutes = self::time_rule_value_to_minutes( $from );
				$to_minutes   = self::time_rule_value_to_minutes( $to );
				
				if ( $from_minutes === null || $to_minutes === null ) {
					continue;
				}

				// Slot clock uses same UTC-facade as slot engine / posted token (gmdate), not site TZ.
				if ( $slot_local_minutes >= $from_minutes && $slot_local_minutes < $to_minutes ) {
					$slot_cost = WC_Appointments_Cost_Calculation::apply_cost( $slot_cost, $rule_val['slot'][0], $rule_val['slot'][1] );
					if ( ! in_array( $rule_key, $applied_base_rules, true ) ) {
						$base_cost = WC_Appointments_Cost_Calculation::apply_cost( $base_cost, $rule_val['base'][0], $rule_val['base'][1] );
						$applied_base_rules[] = $rule_key;
					}
				}
			} else {
				// Non-time rules: days, weeks, months, custom.
				switch ( $type ) {
					case 'days':
					case 'weeks':
					case 'months':
						$date_key      = 'days' === $type ? 'day_of_week' : substr( $type, 0, -1 );
						$month         = $slot_month;

						// Cater to months beyond this year.
						if ( 'month' === $date_key ) {
							$year = $slot_year;
							if ( $year > (int) current_time( 'Y' ) ) {
								$month_beyond_this_year = $month + 12;
								$month = $month_beyond_this_year % 12;
								if ( 0 === $month ) {
									$month = 12;
								}
							}
						}

						if ( 'day_of_week' === $date_key ) {
							$day_value = $slot_dow_iso;
						} elseif ( 'month' === $date_key ) {
							$day_value = $month;
						} elseif ( 'week' === $date_key ) {
							$day_value = $slot_iso_week;
						} else {
							$day_value = (int) gmdate( substr( $type, 0, 1 ), $slot_start );
						}

						if ( isset( $rules[ $day_value ] ) ) {
							$r         = $rules[ $day_value ];
							$slot_cost = WC_Appointments_Cost_Calculation::apply_cost( $slot_cost, $r['slot'][0], $r['slot'][1] );
							if ( ! in_array( $rule_key, $applied_base_rules, true ) ) {
								$base_cost = WC_Appointments_Cost_Calculation::apply_cost( $base_cost, $r['base'][0], $r['base'][1] );
								$applied_base_rules[] = $rule_key;
							}
						}
						break;

					case 'custom':
						$year  = $slot_year;
						$month = $slot_month;
						$day   = $slot_day;
						if ( isset( $rules[ $year ][ $month ][ $day ] ) ) {
							$r         = $rules[ $year ][ $month ][ $day ];
							$slot_cost = WC_Appointments_Cost_Calculation::apply_cost( $slot_cost, $r['slot'][0], $r['slot'][1] );
							if ( ! in_array( $rule_key, $applied_base_rules, true ) ) {
								$base_cost = WC_Appointments_Cost_Calculation::apply_cost( $base_cost, $r['base'][0], $r['base'][1] );
								$applied_base_rules[] = $rule_key;
							}
						}
						break;

					// 'slots' and 'quant' types require customer-selected duration/qty
					// which is not available during slot generation — skip them.
					case 'slots':
					case 'quant':
						break;
				}
			}
		}

		$final_price = max( 0, $slot_cost + $base_cost );
		return $final_price;
	}

	/**
	 * Format a raw price for display using WooCommerce formatting.
	 *
	 * @param float                  $raw_price Raw price value.
	 * @param WC_Product_Appointment $product   Product for tax context.
	 * @return string Formatted price HTML string.
	 */
	public static function format_display_price( float $raw_price, WC_Product_Appointment $product ): string {
		$display_price = wc_get_price_to_display(
			$product,
			[
				'qty'   => 1,
				'price' => $raw_price,
			]
		);

		return wc_price( $display_price );
	}

	/**
	 * Format a discounted price for display like WooCommerce sale price (strikethrough base + sale).
	 *
	 * @param float                  $base_price Base (regular) price.
	 * @param float                  $sale_price Discounted price.
	 * @param WC_Product_Appointment $product    Product for tax context.
	 * @return string HTML with <del> base </del> <ins> sale </ins> for theme styling.
	 */
	public static function format_display_price_discounted( float $base_price, float $sale_price, WC_Product_Appointment $product ): string {
		$base_display = wc_get_price_to_display( $product, [ 'qty' => 1, 'price' => $base_price ] );
		$sale_display  = wc_get_price_to_display( $product, [ 'qty' => 1, 'price' => $sale_price ] );
		$base_html     = wc_price( $base_display );
		$sale_html     = wc_price( $sale_display );
		return '<del aria-hidden="true">' . $base_html . '</del> <ins>' . $sale_html . '</ins>';
	}

	/**
	 * Whether the slot price is a discount (strictly lower than base price).
	 *
	 * @param float $slot_price   Slot price.
	 * @param float $default_price Base price.
	 * @return bool
	 */
	public static function is_slot_price_discounted( float $slot_price, float $default_price ): bool {
		$precision = max( 2, (int) wc_get_price_decimals() + 2 );
		return round( (float) $slot_price, $precision ) < round( (float) $default_price, $precision );
	}

	public static function format_display_price_range( ?float $min_price, ?float $max_price, WC_Product_Appointment $product ): string {
		if ( null === $min_price || null === $max_price ) {
			return '';
		}

		$min_display = self::format_display_price( $min_price, $product );

		if ( ! self::is_price_different_from_default( $max_price, $min_price ) ) {
			return $min_display;
		}

		return $min_display . ' - ' . self::format_display_price( $max_price, $product );
	}

	/**
	 * Reset all pricing caches (useful for testing).
	 */
	public static function reset_cache(): void {
		self::$pricing_cache = [];
		self::$cost_rules_cache = [];
		self::$staff_cost_cache = [];
		self::$preview_cache = [];
		self::$profile_cache = [];
		self::$defaults_cache = [];
		self::$format_cache = [];
	}

	/**
	 * Get cached cost rules for a product.
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @return array<int, mixed>
	 */
	private static function get_cached_cost_rules( WC_Product_Appointment $product ): array {
		$product_id = $product->get_id();

		if ( ! isset( self::$cost_rules_cache[ $product_id ] ) ) {
			self::$cost_rules_cache[ $product_id ] = $product->get_costs();
		}

		return self::$cost_rules_cache[ $product_id ];
	}

	/**
	 * Get cached staff base cost.
	 *
	 * @param WC_Product_Appointment $product  Product.
	 * @param int                    $staff_id Staff ID.
	 * @return float
	 */
	private static function get_staff_base_cost( WC_Product_Appointment $product, int $staff_id ): float {
		$key = $product->get_id() . '_' . $staff_id;

		if ( ! isset( self::$staff_cost_cache[ $key ] ) ) {
			$staff = $product->get_staff_member( $staff_id );
			self::$staff_cost_cache[ $key ] = $staff ? $staff->get_base_cost() : 0.0;
		}

		return self::$staff_cost_cache[ $key ];
	}

	/**
	 * Clear all static caches. Called between products or test runs.
	 */
	public static function clear_cache(): void {
		self::$cost_rules_cache = [];
		self::$staff_cost_cache = [];
		self::$defaults_cache   = [];
		self::$pricing_cache    = [];
		self::$preview_cache    = [];
		self::$profile_cache    = [];
		self::$format_cache = [];
	}

	/**
	 * Get the default (base) slot price for the product and optional staff.
	 *
	 * @param WC_Product_Appointment $product  Product.
	 * @param int                    $staff_id Staff ID (0 = no staff).
	 * @return float
	 */
	public static function get_default_slot_price_raw( WC_Product_Appointment $product, int $staff_id ): float {
		$key = $product->get_id() . '_' . $staff_id;

		if ( ! isset( self::$defaults_cache[ $key ] ) ) {
			$base_cost = max( 0, (float) $product->get_price() );
			if ( $staff_id > 0 ) {
				$base_cost += self::get_staff_base_cost( $product, $staff_id );
			}
			self::$defaults_cache[ $key ] = $base_cost;
		}

		return (float) self::$defaults_cache[ $key ];
	}

	public static function is_price_different_from_default( float $price_a, float $price_b ): bool {
		$precision = max( 2, (int) wc_get_price_decimals() + 2 );

		return abs( round( $price_a - $price_b, $precision ) ) > 0;
	}

	private static function build_pricing_cache_key(
		WC_Product_Appointment $product,
		int $slot_start,
		int $staff_id,
		string $duration_unit
	): string {
		$profile       = self::get_pricing_profile( $product );
		$minute_of_day = ( (int) gmdate( 'G', $slot_start ) ) * 60 + (int) gmdate( 'i', $slot_start );
		$key_parts     = [
			$product->get_id(),
			$staff_id,
			$duration_unit,
		];

		if ( $profile['has_custom_date_rules'] ) {
			$key_parts[] = gmdate( 'Y', $slot_start );
			$key_parts[] = gmdate( 'n', $slot_start );
			$key_parts[] = gmdate( 'j', $slot_start );
		}

		if ( $profile['has_month_rules'] ) {
			$key_parts[] = 'm' . gmdate( 'n', $slot_start );
		}

		if ( $profile['has_week_rules'] ) {
			$key_parts[] = 'w' . gmdate( 'W', $slot_start );
		}

		if ( $profile['has_day_rules'] ) {
			$key_parts[] = 'd' . gmdate( 'N', $slot_start );
		}

		if ( $profile['has_time_rules'] ) {
			$key_parts[] = 't' . $minute_of_day;
		}

		if ( 3 === count( $key_parts ) ) {
			$key_parts[] = 'default';
		}

		return implode( ':', $key_parts );
	}

	/**
	 * Build a pricing profile describing which cost rule families exist.
	 *
	 * @param WC_Product_Appointment $product Product.
	 * @return array{has_custom_date_rules: bool, has_month_rules: bool, has_week_rules: bool, has_day_rules: bool, has_time_rules: bool}
	 */
	private static function get_pricing_profile( WC_Product_Appointment $product ): array {
		$product_id = $product->get_id();

		if ( isset( self::$profile_cache[ $product_id ] ) ) {
			return self::$profile_cache[ $product_id ];
		}

		$profile = [
			'has_custom_date_rules' => false,
			'has_month_rules'       => false,
			'has_week_rules'        => false,
			'has_day_rules'         => false,
			'has_time_rules'        => false,
		];

		foreach ( self::get_cached_cost_rules( $product ) as $rule ) {
			$type = $rule[0] ?? '';

			if ( 0 === strpos( $type, 'time' ) ) {
				$profile['has_time_rules'] = true;
				$profile['has_day_rules']  = true;
				if ( 'time:range' === $type ) {
					$profile['has_custom_date_rules'] = true;
				}
				continue;
			}

			if ( 'days' === $type ) {
				$profile['has_day_rules'] = true;
			} elseif ( 'weeks' === $type ) {
				$profile['has_week_rules'] = true;
			} elseif ( 'months' === $type ) {
				$profile['has_month_rules'] = true;
			} elseif ( 'custom' === $type ) {
				$profile['has_custom_date_rules'] = true;
			}
		}

		self::$profile_cache[ $product_id ] = $profile;

		return $profile;
	}

	/**
	 * Checkout span offset on the Fake UTC axis (day/month tokens) or strtotime for other units.
	 *
	 * @param int    $start_ts           Slot start timestamp.
	 * @param int    $offset             Offset amount.
	 * @param string $step_unit          Unit for offset (minute|hour|day|month).
	 * @param bool   $use_slot_token_ts  Whether start_ts is a Fake UTC day/month token.
	 * @return int
	 */
	public static function checkout_span_instant( int $start_ts, int $offset, string $step_unit, bool $use_slot_token_ts ): int {
		if ( $use_slot_token_ts && in_array( $step_unit, [ 'day', 'month' ], true ) ) {
			$dt = new DateTimeImmutable( gmdate( 'Y-m-d H:i:s', $start_ts ), new DateTimeZone( 'UTC' ) );

			return $dt->modify( "+{$offset} {$step_unit}" )->getTimestamp();
		}

		return (int) strtotime( "+{$offset} {$step_unit}", $start_ts );
	}

	/**
	 * Convert a time-rule from/to value to minutes-from-midnight (0-1439).
	 *
	 * Product cost rules store time range as strings (e.g. "09:00", "12:00") from get_time_range().
	 * This normalizes them so slot pricing can compare slot time (in minutes) correctly.
	 *
	 * @param mixed $value Either a time string ("HH:MM", "H:MM") or already minutes (int 0-1440).
	 * @return int|null Minutes from midnight, or null if unparseable.
	 */
	private static function time_rule_value_to_minutes( $value ): ?int {
		if ( is_numeric( $value ) ) {
			$mins = (int) $value;
			if ( $mins >= 0 && $mins <= 1440 ) {
				return $mins;
			}
		}
		$str = trim( (string) $value );
		if ( '' === $str ) {
			return null;
		}
		$parts = array_map( 'intval', explode( ':', $str, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] >= 0 && $parts[0] <= 23 && $parts[1] >= 0 && $parts[1] <= 59 ) {
			return $parts[0] * 60 + $parts[1];
		}
		// Fallback: strtotime relative to today (e.g. "09:00").
		$ts = strtotime( $str );
		if ( false !== $ts ) {
			return ( (int) date( 'G', $ts ) ) * 60 + (int) date( 'i', $ts );
		}
		return null;
	}
}
