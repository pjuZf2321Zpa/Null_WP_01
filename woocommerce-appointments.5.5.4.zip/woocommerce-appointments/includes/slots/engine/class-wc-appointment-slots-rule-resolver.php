<?php
/**
 * Rule Resolver — builds a minute-mask from in-memory availability rules.
 *
 * This class replaces the need for both get_minutes_from_rules() AND
 * check_availability_rules_against_time() in the slot generation path.
 *
 * Instead of:
 *   1. get_minutes_from_rules()  → flat array of appointable minute offsets
 *   2. get_appointable_minute_start_and_end() → contiguous ranges
 *   3. check_availability_rules_against_time() per slot (400-line monster)
 *
 * This class does:
 *   1. build_minute_mask() → indexed array of [appointable, qty] per minute
 *      (identical output format to Index Engine's build_minute_mask)
 *
 * The minute-mask is then converted to ranges via the shared
 * minute_mask_to_ranges() trait method, and slots are chunked with
 * capacity already resolved — no per-slot rule re-evaluation needed.
 *
 * Algorithm mirrors the legacy get_minutes_from_rules() but outputs an indexed
 * mask with capacity instead of a flat minute array.
 * Rules must be pre-sorted via WC_Product_Appointment::get_availability_rules().
 *
 * Delegates rule-to-minute computation to WC_Appointment_Slots_Rule_Minutes
 * (self-contained within the slots folder — no Rule Manager dependency).
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Rule_Resolver — minute-mask builder from parsed rules.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Rule_Resolver {
	/**
	 * Build minute-mask for a single day from parsed availability rules.
	 *
	 * Replicates the combined logic of get_minutes_from_rules() +
	 * check_availability_rules_against_time() but outputs an indexed mask
	 * identical to the Index Engine's build_minute_mask().
	 *
	 * Rules are expected to be pre-sorted via get_availability_rules() — the
	 * sort order is lowest-override-first, so last-writer-wins when we paint
	 * each rule's minutes onto the mask.
	 *
	 * @param array<int, array<string, mixed>> $rules           Parsed rules from get_availability_rules().
	 * @param int                              $day_midnight    Midnight timestamp for the day being evaluated.
	 * @param bool                             $default_avail   Product default availability.
	 * @param int                              $interval        Slot duration in minutes (for mask ceiling).
	 * @param int                              $staff_id        Staff ID being evaluated (0 = product-level).
	 * @return array<int, array{0: bool, 1: int}> Minute index => [appointable, qty].
	 */
	public static function build_minute_mask(
		array $rules,
		int $day_midnight,
		bool $default_avail,
		int $interval,
		int $staff_id
	): array {
		$max_minute = 1440 + $interval;

		// Initialize mask with default availability.
		// qty=0 means inherit product capacity (no rule override).
		$mask = array_fill( 0, $max_minute + 1, [ $default_avail, 0 ] );

		return self::overlay_rules_on_mask( $mask, $rules, $day_midnight, $interval, $staff_id );
	}

	/**
	 * Paint parsed rules onto an existing minute-mask (last-writer-wins).
	 *
	 * Index path: apply {@see 'woocommerce_appointment_get_availability_rules'}
	 * deltas after cache rows, matching dynamic append-after-sort behavior.
	 *
	 * @param array<int, array{0: bool, 1: int}> $mask         Existing mask.
	 * @param array<int, array<string, mixed>>   $rules        Parsed rules (typically filter delta).
	 * @param int                                $day_midnight Midnight timestamp for the day.
	 * @param int                                $interval     Slot duration in minutes.
	 * @param int                                $staff_id     Staff ID being evaluated.
	 * @return array<int, array{0: bool, 1: int}>
	 */
	public static function overlay_rules_on_mask(
		array $mask,
		array $rules,
		int $day_midnight,
		int $interval,
		int $staff_id
	): array {
		if ( empty( $rules ) || empty( $mask ) ) {
			return $mask;
		}

		$max_minute = 1440 + $interval;

		// Separate staff rules from product/global rules.
		// Staff rules are accumulated per staff_id and merged at the end,
		// matching the behavior of get_minutes_from_rules().
		$staff_masks = [];

		foreach ( $rules as $rule ) {
			if ( ! isset( $rule['level'] ) ) {
				continue;
			}

			$rule_data = WC_Appointment_Slots_Rule_Minutes::compute_rule_minutes( $rule, $day_midnight, $interval );
			$is_appointable = (bool) $rule_data['is_appointable'];
			$rule_minutes   = $rule_data['minutes'] ?? [];

			if ( empty( $rule_minutes ) && empty( $rule_data['is_appointable'] ) ) {
				continue;
			}

			// Extract capacity from rule if present.
			$rule_qty = 0;
			if ( isset( $rule['qty'] ) && '' !== $rule['qty'] ) {
				$rule_qty = (int) $rule['qty'];
			}

			// Staff-level rules: accumulate separately per staff, merge later.
			if ( 'staff' === $rule['level'] ) {
				$rule_staff_id = (int) ( $rule['kind_id'] ?? 0 );

				// When evaluating for a specific staff, only collect that staff's rules.
				// When staff_id=0 (product-level), collect all staff rules for union merge.
				if ( 0 !== $staff_id && $rule_staff_id !== $staff_id ) {
					continue;
				}

				// For specific staff evaluation, apply staff rules inline in sorted order.
				// This preserves priority semantics across global/product/staff rules.
				if ( 0 !== $staff_id ) {
					self::paint_minutes_on_mask(
						$mask,
						$rule_minutes,
						$is_appointable,
						$rule_qty,
						$max_minute
					);
					continue;
				}

				if ( ! isset( $staff_masks[ $rule_staff_id ] ) ) {
					// Start from current mask state (inherits product/global rules).
					$staff_masks[ $rule_staff_id ] = $mask;
				}

				self::paint_minutes_on_mask(
					$staff_masks[ $rule_staff_id ],
					$rule_minutes,
					$is_appointable,
					$rule_qty,
					$max_minute
				);

				continue;
			}

			// Do not clear $staff_masks when a global/product rule evaluates not appointable.
			// Rules are applied in override order (see get_availability_rules sort); staff-level
			// rules may appear earlier in the list than a later global/product row (e.g. when
			// priorities differ). Clearing would drop staff availability that must still apply
			// at merge — same behavior as WC_Appointment_Slots_Data_Normalizer for the index path.

			// Paint product/global/location/resource onto the main mask.
			self::paint_minutes_on_mask( $mask, $rule_minutes, $is_appointable, $rule_qty, $max_minute );

			// Location/resource Closed must also close existing staff masks so the later union
			// merge cannot reopen a shut venue/room (equal-priority staff Open after Closed).
			if ( in_array( $rule['level'], [ 'location', 'resource' ], true ) && ! $is_appointable && ! empty( $staff_masks ) ) {
				foreach ( $staff_masks as $sid => $unused ) {
					self::paint_minutes_on_mask(
						$staff_masks[ $sid ],
						$rule_minutes,
						false,
						$rule_qty,
						$max_minute
					);
				}
			}
		}

		// Merge staff masks into the main mask.
		if ( ! empty( $staff_masks ) ) {
			if ( 0 !== $staff_id && isset( $staff_masks[ $staff_id ] ) ) {
				// Specific staff: staff mask already inherits global+product rules
				// (it was initialized from $mask) with staff rules painted on top.
				// Use it directly so staff rules can both ADD and REMOVE availability,
				// properly overriding global/product rules at the same priority level.
				$mask = $staff_masks[ $staff_id ];
			} else {
				// No specific staff (staff_id=0): union all staff masks.
				// As long as ANY staff makes a minute appointable, it stays appointable.
				foreach ( $staff_masks as $s_mask ) {
					$mask = self::merge_staff_mask_into_main( $mask, $s_mask, $max_minute );
				}
			}
		}

		return $mask;
	}

	/**
	 * Paint a set of minute offsets onto a mask.
	 *
	 * "Painting" means overwriting the appointable/qty state for each minute
	 * in the given array. This is the last-writer-wins approach that matches
	 * the legacy behavior where rules are applied in sort order.
	 *
	 * @param array<int, array{0: bool, 1: int}> &$mask       Mask to modify (by reference).
	 * @param array<int, int>                      $minutes    Minute offsets to paint.
	 * @param bool                                 $appointable Whether these minutes are appointable.
	 * @param int                                  $qty        Capacity override (0 = inherit).
	 * @param int                                  $max_minute Maximum minute index in the mask.
	 */
	private static function paint_minutes_on_mask(
		array &$mask,
		array $minutes,
		bool $appointable,
		int $qty,
		int $max_minute
	): void {
		foreach ( $minutes as $m ) {
			$m = (int) $m;
			if ( $m < 0 || $m > $max_minute ) {
				continue;
			}
			if ( isset( $mask[ $m ] ) ) {
				$mask[ $m ] = [ $appointable, $qty ];
			}
		}
	}

	/**
	 * Public entry point for merge_staff_mask_into_main.
	 *
	 * Allows the Index Engine to reuse the same union-merge logic so both
	 * engines produce identical minute-mask output — single source of truth.
	 *
	 * @param array<int, array{0: bool, 1: int}> $main_mask  Current main mask.
	 * @param array<int, array{0: bool, 1: int}> $staff_mask Staff-specific mask.
	 * @param int                                $max_minute Maximum minute index.
	 * @return array<int, array{0: bool, 1: int}> Merged mask.
	 */
	public static function merge_staff_mask_public( array $main_mask, array $staff_mask, int $max_minute ): array {
		return self::merge_staff_mask_into_main( $main_mask, $staff_mask, $max_minute );
	}

	/**
	 * Merge a staff-level mask into the main mask.
	 *
	 * For each minute where the staff mask says "appointable" but the main
	 * mask says "not appointable", the staff rule wins (union merge).
	 * This matches the legacy behavior in get_minutes_from_rules() where
	 * staff appointable minutes are merged via array_merge.
	 *
	 * When staff makes a minute NOT appointable that was appointable in main,
	 * the main mask is preserved (staff can't reduce product availability,
	 * only extend it via their own rules).
	 *
	 * @param array<int, array{0: bool, 1: int}> $main_mask  Current main mask.
	 * @param array<int, array{0: bool, 1: int}> $staff_mask Staff-specific mask.
	 * @param int                                $max_minute Maximum minute index.
	 * @return array<int, array{0: bool, 1: int}> Merged mask.
	 */
	private static function merge_staff_mask_into_main( array $main_mask, array $staff_mask, int $max_minute ): array {
		for ( $m = 0; $m <= $max_minute; $m++ ) {
			if ( ! isset( $staff_mask[ $m ] ) || ! isset( $main_mask[ $m ] ) ) {
				continue;
			}

			$staff_appointable = $staff_mask[ $m ][0];
			$main_appointable  = $main_mask[ $m ][0];

			// Staff appointable overrides main not-appointable (union merge).
			if ( $staff_appointable && ! $main_appointable ) {
				$main_mask[ $m ] = $staff_mask[ $m ];
			}

			// If staff has a capacity override on an appointable minute, apply it.
			if ( $staff_appointable && $main_appointable && $staff_mask[ $m ][1] > 0 ) {
				$main_mask[ $m ][1] = $staff_mask[ $m ][1];
			}
		}

		return $main_mask;
	}
}
