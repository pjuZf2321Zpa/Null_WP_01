<?php
/**
 * Rule Minutes — self-contained rule-to-minute computation for the slots engine.
 *
 * Consolidates all rule interpretation logic that was previously scattered
 * across WC_Product_Appointment_Rule_Manager into one focused class inside
 * the slots folder. This eliminates the runtime dependency on Rule Manager
 * for the entire v3 slot generation pipeline.
 *
 * Methods inlined from Rule Manager (with improved naming):
 *  - get_rule_minute_range()                     → compute_rule_minutes()
 *  - get_rule_minutes_for_time()                 → minutes_for_time()
 *  - get_rule_minutes_for_days()                 → minutes_for_days()
 *  - get_rule_minutes_for_weeks()                → minutes_for_weeks()
 *  - get_rule_minutes_for_months()               → minutes_for_months()
 *  - get_rule_minutes_for_custom()               → minutes_for_custom()
 *  - get_rule_minutes_for_rrule()                → minutes_for_rrule()
 *  - calculate_minute_range()                    → minute_range_from_times()
 *  - check_timestamp_against_rule()              → evaluate_rule_for_timestamp()
 *  - does_rule_apply()                           → does_rule_apply_to_day()
 *  - check_availability_rules_against_date()     → check_date_availability()
 *  - rrule_matches_timestamp()                   → rrule_matches_timestamp()
 *
 * All methods are pure computation — no DB queries, no product lookups beyond
 * what is passed in. This makes them easy to test and reason about.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use RRule\RSet;

/**
 * WC_Appointment_Slots_Rule_Minutes — rule-to-minute computation.
 *
 * @since 5.3.0
 */
	final class WC_Appointment_Slots_Rule_Minutes {

	/**
	 * Default rule-minutes payload shape.
	 *
	 * @return array{is_appointable: bool, minutes: int[], overlapping_start_time: int|false, overlapping_end_time: int|false}
	 */
	private static function empty_minutes_result(): array {
		return [
			'is_appointable'         => false,
			'minutes'                => [],
			'overlapping_start_time' => false,
			'overlapping_end_time'   => false,
		];
	}

	// ──────────────────────────────────────────────────────────────
	// 1. Main dispatcher — replaces Rule Manager::get_rule_minute_range()
	// ──────────────────────────────────────────────────────────────

	/**
	 * Compute the minute offsets and appointability for a single rule on a given day.
	 *
	 * Given a parsed availability rule array and a day midnight timestamp,
	 * returns which minutes of the day this rule affects and whether those
	 * minutes are appointable.
	 *
	 * @since 5.3.0
	 *
	 * @param array<string, mixed> $rule       Parsed availability rule from get_availability_rules().
	 * @param int                  $check_date Midnight timestamp for the day being evaluated.
	 * @param int                  $mask_tail  Slot duration minutes; extends civil-midnight time windows on the mask.
	 * @return array{is_appointable: bool, minutes: int[], overlapping_start_time: int|false, overlapping_end_time: int|false}
	 */
	public static function compute_rule_minutes( array $rule, int $check_date, int $mask_tail = 0 ): array {
		$result = self::empty_minutes_result();

		$type = $rule['type'] ?? '';

		if ( ( strpos( $type, 'time' ) > -1 ) || ( 'custom:daterange' === $type ) ) {
			return self::minutes_for_time( $rule, $check_date, $mask_tail );
		}

		if ( in_array( $type, [ 'days', 'weeks', 'months', 'custom' ], true ) ) {
			return self::minutes_for_civil_unit( $rule, $check_date, $mask_tail );
		}

		if ( 'rrule' === $type ) {
			return self::minutes_for_rrule( $rule, $check_date, $mask_tail );
		}

		return $result;
	}

	// ──────────────────────────────────────────────────────────────
	// 2. Per-type minute resolvers
	// ──────────────────────────────────────────────────────────────

	/**
	 * Resolve minutes for time-based rules (time, time:N, time:range, custom:daterange).
	 *
	 * Handles:
	 *  - Regular same-day time windows
	 *  - Overnight rules (to < from) with proper day splitting
	 *  - Day-specific time rules (time:1 through time:7)
	 *  - Date-range time rules (time:range, custom:daterange)
	 *
	 * @since 5.3.0
	 *
	 * @param array<string, mixed> $rule       Parsed rule.
	 * @param int                  $check_date Midnight timestamp.
	 * @param int                  $mask_tail  Slot duration minutes past civil midnight on the mask.
	 * @return array{is_appointable: bool, minutes: int[], overlapping_start_time: int|false, overlapping_end_time: int|false}
	 */
	private static function minutes_for_time( array $rule, int $check_date, int $mask_tail = 0 ): array {
		$minutes = self::empty_minutes_result();

		$type  = $rule['type'];
		$range = $rule['range'];

		// When set, skip minute_range_from_times() below (used for time:range overnight at day midnight).
		$calculated_precomputed = null;

		// Use gmdate() to interpret timestamp in site timezone, not server timezone.
		$year        = intval( gmdate( 'Y', $check_date ) );
		$month       = intval( gmdate( 'n', $check_date ) );
		$day         = intval( gmdate( 'j', $check_date ) );
		$day_of_week = intval( gmdate( 'N', $check_date ) );

		if ( in_array( $type, [ 'time:range', 'custom:daterange' ], true ) ) {
			// Date range with time.
			if ( ! isset( $range[ $year ][ $month ][ $day ] ) ) {
				return self::empty_minutes_result();
			}
			$multi_day_grid = $range;
			$range          = $range[ $year ][ $month ][ $day ];

			$from = $range['from'];
			$to   = $range['to'];
			$minutes['is_appointable'] = $range['rule'];

			// Handle overnight rules for time:range and custom:daterange.
			if ( self::is_wrap_midnight_hhmm_pair( (string) $from, (string) $to ) ) {
				if ( 'time:range' === $type ) {
					// compute_rule_minutes() passes day midnight: gmdate( 'H:i', $check_date ) is always 00:00, so the
					// old branch/elseif split only ever kept the morning half. Merge evening + morning tail when the
					// previous calendar day is also in the range (matches indexed single-row span).
					$evening = self::minute_range_from_times( (string) $from, '24:00', $mask_tail );
					$morning = [];
					$prev_ts = strtotime( '-1 day', $check_date );
					$py      = intval( gmdate( 'Y', $prev_ts ) );
					$pm      = intval( gmdate( 'n', $prev_ts ) );
					$pd      = intval( gmdate( 'j', $prev_ts ) );
					if ( isset( $multi_day_grid[ $py ][ $pm ][ $pd ] ) ) {
						$morning = self::minute_range_from_times( '00:00', (string) $to, $mask_tail );
					}
					$calculated_precomputed = array_values( array_unique( array_merge( $evening, $morning ) ) );
					sort( $calculated_precomputed, SORT_NUMERIC );
				}
				// For custom:daterange, minute_range_from_times() below handles wrap in one call.
			}
		} elseif ( strpos( $type, 'time:' ) > -1 ) {
			// Day-specific time rule (time:1 through time:7).
			$is_overnight_rule = self::is_wrap_midnight_hhmm_pair( (string) $range['from'], (string) $range['to'] );
			$rule_applies      = false;
			$is_next_day       = false;

			if ( $day_of_week == $range['day'] ) {
				$rule_applies = true;
			} elseif ( $is_overnight_rule ) {
				// For overnight rules, also check if current day is the day after the rule's assigned day.
				$prev_day = ( $day_of_week - 1 ) === 0 ? 7 : ( $day_of_week - 1 );
				if ( $range['day'] === $prev_day ) {
					$rule_applies = true;
					$is_next_day  = true;
				}
			}

			if ( ! $rule_applies ) {
				return self::empty_minutes_result();
			}

			// For overnight rules, split the time range appropriately.
			if ( $is_overnight_rule && $is_next_day ) {
				$from = '00:00';
				$to   = $range['to'];
			} elseif ( $is_overnight_rule && ! $is_next_day ) {
				$from = $range['from'];
				$to   = '24:00';
			} else {
				$from = $range['from'];
				$to   = $range['to'];
			}
			$minutes['is_appointable'] = $range['rule'];
		} else {
			// General time rule (time — all days).
			$from                      = $range['from'];
			$to                        = $range['to'];
			$minutes['is_appointable'] = $range['rule'];
		}

		if ( null !== $calculated_precomputed ) {
			$calculated = $calculated_precomputed;
		} else {
			$calculated = self::minute_range_from_times( $from, $to, $mask_tail );
		}

		// For date-range-with-time rules, extend past midnight when the next
		// day in the same rule continues from 00:00. This produces a contiguous
		// minute range matching the index path (which uses raw timestamps and
		// naturally spans midnight). Without this, slots near end-of-day whose
		// duration crosses midnight are lost because the mask stops at 1440.
		if ( $minutes['is_appointable']
			&& in_array( $type, [ 'time:range', 'custom:daterange' ], true )
			&& ! empty( $calculated )
		) {
			$full_range  = $rule['range'];
			$next_day_ts = strtotime( '+1 day', $check_date );
			$ny          = intval( gmdate( 'Y', $next_day_ts ) );
			$nm          = intval( gmdate( 'n', $next_day_ts ) );
			$nd          = intval( gmdate( 'j', $next_day_ts ) );

			if ( isset( $full_range[ $ny ][ $nm ][ $nd ] ) ) {
				$next = $full_range[ $ny ][ $nm ][ $nd ];

				if ( isset( $next['from'] ) && '00:00' === $next['from'] ) {
					$next_to = $next['to'] ?? '';

					// Compute the next day's end as a minute offset from its midnight.
					if ( '24:00' === $next_to ) {
						$next_end_min = 1440;
					} else {
						$parts        = explode( ':', $next_to );
						$h            = isset( $parts[0] ) ? absint( $parts[0] ) : 0;
						$i            = isset( $parts[1] ) ? absint( $parts[1] ) : 0;
						$next_end_min = ( 0 === $h && 0 === $i ) ? 1440 : ( $h * 60 ) + $i;
					}

					if ( $next_end_min > 0 ) {
						$ext_start = end( $calculated ) + 1;
						$ext_end   = 1440 + $next_end_min;
						if ( $ext_start <= $ext_end ) {
							$calculated = array_merge( $calculated, range( $ext_start, $ext_end ) );
						}
					}
				}
			}
		}

		// Record boundary minutes for admin/calendar display (legacy Rule Manager
		// metadata). Paint the full half-open range on the mask — same as the
		// indexed path — so priority blocks are not left with appointable edges.
		$minutes['overlapping_start_time'] = false;
		$minutes['overlapping_end_time']   = false;

		if ( ! $minutes['is_appointable'] && ! empty( $calculated ) ) {
			$minutes['overlapping_start_time'] = (int) reset( $calculated );
			$minutes['overlapping_end_time']   = (int) end( $calculated );
		}

		$minutes['minutes'] = $calculated;

		return $minutes;
	}

	/**
	 * Resolve minutes for civil-calendar unit rules (days, weeks, months, custom).
	 *
	 * Matches legacy Rule Manager: always paint the full civil day when the rule applies,
	 * including not-appointable blocks (otherwise the mask resolver skips empty minutes).
	 *
	 * @since 5.3.0
	 *
	 * @param array<string, mixed> $rule       Parsed rule.
	 * @param int                  $check_date Midnight timestamp.
	 * @param int                  $mask_tail  Slot duration minutes past civil midnight on the mask.
	 * @return array{is_appointable: bool, minutes: int[], overlapping_start_time: int|false, overlapping_end_time: int|false}
	 */
	private static function minutes_for_civil_unit( array $rule, int $check_date, int $mask_tail = 0 ): array {
		$miss  = self::empty_minutes_result();
		$type  = $rule['type'] ?? '';
		$range = $rule['range'];

		if ( 'custom' === $type ) {
			$y = gmdate( 'Y', $check_date );
			$m = gmdate( 'n', $check_date );
			$d = gmdate( 'j', $check_date );
			if ( ! isset( $range[ $y ][ $m ][ $d ] ) ) {
				return $miss;
			}
			$appointable = $range[ $y ][ $m ][ $d ];
		} elseif ( 'days' === $type ) {
			$key = (int) gmdate( 'N', $check_date );
			if ( ! isset( $range[ $key ] ) ) {
				return $miss;
			}
			$appointable = $range[ $key ];
		} elseif ( 'weeks' === $type ) {
			$key = (int) gmdate( 'W', $check_date );
			if ( ! isset( $range[ $key ] ) ) {
				return $miss;
			}
			$appointable = $range[ $key ];
		} elseif ( 'months' === $type ) {
			$key = gmdate( 'n', $check_date );
			if ( ! isset( $range[ $key ] ) ) {
				return $miss;
			}
			$appointable = $range[ $key ];
		} else {
			return $miss;
		}

		return [
			'is_appointable'         => (bool) $appointable,
			'minutes'                => self::minute_range_from_times( '00:00', '00:00', $mask_tail ),
			'overlapping_start_time' => false,
			'overlapping_end_time'   => false,
		];
	}

	/**
	 * Resolve minutes for 'rrule' type (iCal recurrence rules).
	 *
	 * Uses the RRule library to find occurrences within the day and converts
	 * them to minute offsets. Handles both all-day and timed rrules.
	 *
	 * @since 5.3.0
	 *
	 * @param array<string, mixed> $rule       Parsed rule.
	 * @param int                  $check_date Midnight timestamp.
	 * @param int                  $mask_tail  Slot duration minutes past civil midnight on the mask.
	 * @return array{is_appointable: bool, minutes: int[], overlapping_start_time: int|false, overlapping_end_time: int|false}
	 */
	private static function minutes_for_rrule( array $rule, int $check_date, int $mask_tail = 0 ): array {
		$minutes = self::empty_minutes_result();

		try {
			$start       = new \WC_DateTime( $rule['range']['from'] );
			$end         = new \WC_DateTime( $rule['range']['to'] );
			$is_all_day  = false === strpos( $rule['range']['from'], ':' );
			$date_format = $is_all_day ? 'Y-m-d' : 'Y-m-d g:i A';

			$rrule_str = wc_appointments_esc_rrule( $rule['range']['rrule'], $is_all_day );
			$rset = new RSet( $rrule_str, $is_all_day ? $start->format( $date_format ) : $start );

			$duration = $start->diff( $end, true );
			$site_tz  = new DateTimeZone( wc_timezone_string() );

			// Use gmdate() to interpret timestamp in site timezone, not server timezone.
			$current_date  = new DateTimeImmutable( gmdate( 'Y-m-d 00:00:00', $check_date ), $site_tz );
			$tomorrow_date = $current_date->modify( '+1 day' );
			$prev_date     = $current_date->modify( '-1 day' );
			$today_ymd     = gmdate( 'Y-m-d', $check_date );
			$prev_ymd      = $prev_date->format( 'Y-m-d' );

			// Scan from the previous civil day so an overnight occurrence that starts the day
			// before (e.g. Fri 22:00–Sat 02:00) can paint its morning tail here. Each occurrence
			// contributes only the minutes that land on $check_date: the start-day evening segment
			// stays on the start day and the wrap tail moves to the following day. This matches the
			// indexed row split in the data normalizer (a raw start_ts→end_ts row crossing midnight
			// paints evening on the start day and 00:00→to on the spill day), so timed overnight
			// RRULEs no longer paint both halves onto the start day.
			$occurrences = $rset->getOccurrencesBetween( $prev_date, $tomorrow_date );

			foreach ( $occurrences as $occurrence ) {
				$occ_ymd = $occurrence->format( 'Y-m-d' );
				$from    = $occurrence->format( 'H:i' );
				$to      = $occurrence->add( $duration )->format( 'H:i' );
				$is_wrap = self::is_wrap_midnight_hhmm_pair( (string) $from, (string) $to );

				if ( $today_ymd === $occ_ymd ) {
					// Occurrence starts on this civil day: same-day window, or evening segment
					// (from→24:00) when it wraps past midnight.
					$minute_range = $is_wrap
						? self::minute_range_from_times( $from, '24:00', $mask_tail )
						: self::minute_range_from_times( $from, $to, $mask_tail );
				} elseif ( $prev_ymd === $occ_ymd && $is_wrap ) {
					// Overnight occurrence that started the previous civil day: morning tail only.
					$minute_range = self::minute_range_from_times( '00:00', $to, $mask_tail );
				} else {
					continue;
				}

				if ( ! empty( $minute_range ) ) {
					$minutes['overlapping_start_time'] = (int) reset( $minute_range );
					$minutes['overlapping_end_time']   = (int) end( $minute_range );
				}

				$minutes['minutes'] = array_merge( $minutes['minutes'], $minute_range );
			}
		} catch ( \Exception $e ) {
			if ( function_exists( 'wc_add_appointment_log' ) ) {
				wc_add_appointment_log( 0, sprintf(
					'WARNING: Invalid rrule encountered during availability calculation. Rule: %s — Error: %s',
					substr( $rule['range']['rrule'] ?? '', 0, 300 ),
					$e->getMessage()
				) );
			}
		}

		return $minutes;
	}

	// ──────────────────────────────────────────────────────────────
	// 3. Shared helpers
	// ──────────────────────────────────────────────────────────────

	/**
	 * Whether an HH:MM pair is a true wrap-across-midnight window (e.g. 22:00–06:00).
	 *
	 * Lexicographic compare is unsafe: `00:00` sorts before `08:00`, and `24:00` sorts before `08:00`,
	 * so string `$to < $from` mis-detects same-day windows and mis-detects after normalizing end to 24:00.
	 * End stored as `00:00` with a non-midnight start means end of civil day (handled in minute_range_from_times).
	 *
	 * @since 5.3.7
	 *
	 * @param string $from_hhmm Start time.
	 * @param string $to_hhmm   End time.
	 * @return bool True when the window spans calendar midnight (morning end before start on the clock).
	 */
	public static function is_wrap_midnight_hhmm_pair( string $from_hhmm, string $to_hhmm ): bool {
		$fp = explode( ':', $from_hhmm );
		$fh = isset( $fp[0] ) ? absint( $fp[0] ) : 0;
		$fM = isset( $fp[1] ) ? absint( $fp[1] ) : 0;
		$from_m = min( 1440, $fh * 60 + $fM );

		$tp = explode( ':', $to_hhmm );
		$th = isset( $tp[0] ) ? absint( $tp[0] ) : 0;
		$tM = isset( $tp[1] ) ? absint( $tp[1] ) : 0;

		// Closing midnight with a later start = through end of same day, not wrap.
		if ( 0 === $th && 0 === $tM && $from_m > 0 ) {
			return false;
		}

		$to_m = min( 1440, $th * 60 + $tM );
		return $to_m < $from_m;
	}

	/**
	 * Convert HH:MM from/to strings to an array of minute offsets.
	 *
	 * If the "from" time is greater than the "to" time (overnight),
	 * the range wraps through midnight: [from..1440] + [0..to].
	 *
	 * @since 5.3.0
	 *
	 * @param string $from Start time 'HH:MM'.
	 * @param string $to   End time 'HH:MM'.
	 * @param int    $mask_tail Slot duration minutes; extends evening segments that end at civil midnight.
	 * @return int[] Array of minute offsets.
	 */
	public static function minute_range_from_times( string $from, string $to, int $mask_tail = 0 ): array {
		$from_parts = explode( ':', $from );
		$from_hour  = isset( $from_parts[0] ) ? absint( $from_parts[0] ) : 0;
		$from_min   = isset( $from_parts[1] ) ? absint( $from_parts[1] ) : 0;

		$to_parts = explode( ':', $to );
		$to_hour  = isset( $to_parts[0] ) ? absint( $to_parts[0] ) : 0;
		$to_min   = isset( $to_parts[1] ) ? absint( $to_parts[1] ) : 0;

		// If "to" is midnight (00:00), treat as end of day (24:00 = 1440 minutes).
		if ( 0 === $to_hour && 0 === $to_min ) {
			$to_hour = 24;
		}

		$minute_start = ( $from_hour * 60 ) + $from_min;
		$minute_end   = ( $to_hour * 60 ) + $to_min;

		$merge_ranges = [];
		$minutes      = [];

		// If start > end, assume overnight (wrap through midnight).
		if ( $minute_start > $minute_end ) {
			$merge_ranges[] = [ $minute_start, 1440 ];
			$merge_ranges[] = [ 0, $minute_end ];
		} else {
			$merge_ranges[] = [ $minute_start, $minute_end ];
		}

		// Half-open [start, end): matches indexed minute-mask painting (m < end_min) in
		// WC_Appointment_Slots_Data_Normalizer::build_minute_mask_from_index_rows().
		foreach ( $merge_ranges as $r ) {
			$start         = (int) $r[0];
			$end_exclusive = (int) $r[1];
			if ( $mask_tail > 0 && 1440 === $end_exclusive && $start > 0 ) {
				$end_exclusive = 1440 + $mask_tail;
			}
			if ( $start < $end_exclusive ) {
				$minutes = array_merge( $minutes, range( $start, $end_exclusive - 1 ) );
			}
		}

		return $minutes;
	}

	// ──────────────────────────────────────────────────────────────
	// 4. Rule application checks — used by RuleResolver & engines
	// ──────────────────────────────────────────────────────────────

	/**
	 * Check if a rule applies to a specific day (date scope check).
	 *
	 * Determines whether the rule's range covers the given timestamp's
	 * date/weekday/week/month. This is a scope check, NOT an appointability
	 * check — it answers "does this rule talk about this day?" not
	 * "is this day appointable?".
	 *
	 * @since 5.3.0
	 *
	 * @param array<string, mixed> $rule      Parsed rule.
	 * @param int                  $timestamp Timestamp to check.
	 * @return bool Whether the rule applies to this day.
	 */
	public static function does_rule_apply_to_day( array $rule, int $timestamp ): bool {
		// For day-unit products, timestamps are UTC midnight "date tokens" (civil dates).
		// Use gmdate() to extract the civil date without timezone conversion.
		$year        = intval( gmdate( 'Y', $timestamp ) );
		$month       = intval( gmdate( 'n', $timestamp ) );
		$day         = intval( gmdate( 'j', $timestamp ) );
		$day_of_week = intval( gmdate( 'N', $timestamp ) );
		$week        = intval( gmdate( 'W', $timestamp ) );

		$range = $rule['range'];

		switch ( $rule['type'] ) {
			case 'months':
				if ( isset( $range[ $month ] ) ) {
					return true;
				}
				break;
			case 'weeks':
				if ( isset( $range[ $week ] ) ) {
					return true;
				}
				break;
			case 'days':
				if ( isset( $range[ $day_of_week ] ) ) {
					return true;
				}
				break;
			case 'custom':
			case 'custom:daterange':
			case 'time:range':
				if ( isset( $range[ $year ][ $month ][ $day ] ) ) {
					return true;
				}
				break;
			case 'rrule':
				if ( self::rrule_applies_to_civil_day( $range, $timestamp ) ) {
					return true;
				}
				break;
			case 'time':
			case 'time:1':
			case 'time:2':
			case 'time:3':
			case 'time:4':
			case 'time:5':
			case 'time:6':
			case 'time:7':
				if ( $day_of_week === $range['day'] || 0 === $range['day'] ) {
					return true;
				}
				// Handle overnight rules: true wrap only (not end-at-midnight same-day windows).
				if ( isset( $range['from'] ) && isset( $range['to'] )
					&& self::is_wrap_midnight_hhmm_pair( (string) $range['from'], (string) $range['to'] ) ) {
					$prev_day = ( $day_of_week - 1 ) === 0 ? 7 : ( $day_of_week - 1 );
					if ( $range['day'] === $prev_day ) {
						return true;
					}
				}
				break;
		}

		return false;
	}

	/**
	 * Evaluate a rule against a timestamp and return the appointability value.
	 *
	 * Given a timestamp and rule, determine whether the timestamp is appointable
	 * based on the rule. Returns the appointable boolean, or an integer capacity
	 * when $get_capacity is true.
	 *
	 * This is the "last-writer-wins" evaluator: the result overwrites whatever
	 * the previous rule decided, matching the priority sort order.
	 *
	 * @since 5.3.0
	 *
	 * @param int                  $timestamp    Timestamp to evaluate.
	 * @param array<string, mixed> $rule         Parsed rule.
	 * @param mixed                $default      Default appointable value (bool or int capacity from previous rule).
	 * @param int                  $capacity     Current capacity value.
	 * @param bool                 $get_capacity If true, return integer capacity instead of bool.
	 * @return mixed Bool appointable, or int capacity when $get_capacity is true.
	 */
	public static function evaluate_rule_for_timestamp( int $timestamp, array $rule, $default, int $capacity = 1, bool $get_capacity = false ) {
		// For day-unit products, timestamps are UTC midnight "date tokens" (civil dates).
		// Use gmdate() to extract the civil date without timezone conversion.
		$year        = intval( gmdate( 'Y', $timestamp ) );
		$month       = intval( gmdate( 'n', $timestamp ) );
		$day         = intval( gmdate( 'j', $timestamp ) );
		$day_of_week = intval( gmdate( 'N', $timestamp ) );
		$week        = intval( gmdate( 'W', $timestamp ) );

		$type  = $rule['type'];
		$range = $rule['range'];
		$qty   = $rule['qty'] && $rule['qty'] >= 1 ? $rule['qty'] : $capacity;

		$appointable = $default;

		switch ( $type ) {
			case 'months':
				if ( isset( $range[ $month ] ) ) {
					$appointable = $range[ $month ];
					$capacity    = $qty;
				}
				break;
			case 'weeks':
				if ( isset( $range[ $week ] ) ) {
					$appointable = $range[ $week ];
					$capacity    = $qty;
				}
				break;
			case 'days':
				if ( isset( $range[ $day_of_week ] ) ) {
					$appointable = $range[ $day_of_week ];
					$capacity    = $qty;
				}
				break;
			case 'custom':
				if ( isset( $range[ $year ][ $month ][ $day ] ) ) {
					$appointable = $range[ $year ][ $month ][ $day ];
					$capacity    = $qty;
				}
				break;
			case 'rrule':
				if ( self::rrule_applies_to_civil_day( $range, $timestamp ) ) {
					$appointable = $range['rule'];
					$capacity    = $qty;
				}
				break;
			case 'time':
			case 'time:1':
			case 'time:2':
			case 'time:3':
			case 'time:4':
			case 'time:5':
			case 'time:6':
			case 'time:7':
				$rule_applies   = false;
				$timestamp_time = gmdate( 'H:i', $timestamp );

				// Check if this is the rule's assigned day.
				if ( $day_of_week === $range['day'] || 0 === $range['day'] ) {
					if ( isset( $range['from'] ) && isset( $range['to'] )
						&& self::is_wrap_midnight_hhmm_pair( (string) $range['from'], (string) $range['to'] ) ) {
						// Overnight rule — check if timestamp falls within the time range.
						if ( $timestamp_time >= $range['from'] || $timestamp_time <= $range['to'] ) {
							$rule_applies = true;
						}
					} else {
						// Normal rule or no time specified.
						$rule_applies = true;
					}
				} elseif ( isset( $range['from'] ) && isset( $range['to'] )
					&& self::is_wrap_midnight_hhmm_pair( (string) $range['from'], (string) $range['to'] ) ) {
					// Check if this is the day after an overnight rule's assigned day.
					$prev_day = ( $day_of_week - 1 ) === 0 ? 7 : ( $day_of_week - 1 );
					if ( $range['day'] === $prev_day && $timestamp_time <= $range['to'] ) {
						$rule_applies = true;
					}
				}

				if ( $rule_applies ) {
					$appointable = $range['rule'];
					$capacity    = $qty;
				}
				break;
			case 'time:range':
			case 'custom:daterange':
				if ( isset( $range[ $year ][ $month ][ $day ] ) ) {
					$day_rule       = $range[ $year ][ $month ][ $day ];
					$timestamp_time = gmdate( 'H:i', $timestamp );

					$df = $day_rule['from'] ?? '00:00';
					$dt = $day_rule['to'] ?? '00:00';

					// Upper bound for same-day inclusive checks: midnight end is end of day (string compare is unsafe for 24:00).
					$dt_upper = $dt;
					if ( ! self::is_wrap_midnight_hhmm_pair( (string) $df, (string) $dt ) && '00:00' === $dt && '00:00' !== $df ) {
						$dt_upper = '24:00';
					}

					// Handle overnight rules for time:range.
					if ( self::is_wrap_midnight_hhmm_pair( (string) $df, (string) $dt ) ) {
						if ( $timestamp_time >= $df || $timestamp_time <= $dt ) {
							$appointable = $day_rule['rule'];
							$capacity    = $qty;
						}
					} elseif ( $timestamp_time >= $df && $timestamp_time <= $dt_upper ) {
						$appointable = $day_rule['rule'];
						$capacity    = $qty;
					}
				}
				break;
		}

		// Return capacity instead of appointability when requested.
		if ( $get_capacity ) {
			$returned_capacity = 0;
			if ( is_numeric( $appointable ) ) {
				$returned_capacity = absint( $appointable );
			} elseif ( $appointable ) {
				$returned_capacity = absint( $capacity );
			}

			return $returned_capacity;
		}

		return $appointable;
	}

	// ──────────────────────────────────────────────────────────────
	// 5. Date-level availability — used by engines for day/month slots
	// ──────────────────────────────────────────────────────────────

	/**
	 * Check a date against all availability rules and return appointability/capacity.
	 *
	 * Replaces WC_Product_Appointment_Rule_Manager::check_availability_rules_against_date()
	 * for the slot engines. Iterates all rules in priority order (last-writer-wins),
	 * checking if each rule applies to the given date.
	 *
	 * @since 5.3.0
	 *
	 * @param WC_Product_Appointment $product      The appointment product.
	 * @param int                    $check_date   Timestamp of the date to check.
	 * @param int                    $staff_id     Staff ID (0 for no staff).
	 * @param bool                   $get_capacity If true, return integer capacity instead of bool.
	 * @param mixed                  $appointable  Initial appointable value (null = use product default).
	 * @return mixed Bool appointable, or int capacity when $get_capacity is true.
	 */
	public static function check_date_availability(
		\WC_Product_Appointment $product,
		int $check_date,
		int $staff_id = 0,
		bool $get_capacity = false,
		$appointable = null
	) {
		if ( is_null( $appointable ) ) {
			$appointable = $product->get_default_availability();
		}

		$rules    = $product->get_availability_rules( $staff_id );
		$capacity = $product->get_available_qty( $staff_id );

		// evaluate_rule_for_timestamp already no-ops when a rule does not apply; do not
		// call does_rule_apply_to_day first (that re-ran RRULE expansion a second time).
		foreach ( $rules as $rule ) {
			$appointable = self::evaluate_rule_for_timestamp(
				$check_date, $rule, $appointable, $capacity, $get_capacity
			);
		}

		/**
		 * Is date appointable hook.
		 *
		 * Preserves backward compatibility with the same filter fired by Rule Manager.
		 *
		 * @since 4.0.0
		 *
		 * @param bool                   $appointable      Available or not.
		 * @param WC_Product_Appointment $product          Product.
		 * @param int                    $check_date       Timestamp.
		 * @param int                    $staff_id         Staff ID.
		 * @param bool                   $get_capacity     Whether capacity was requested.
		 */
		return apply_filters(
			'woocommerce_appointments_is_date_appointable',
			$appointable,
			$product,
			$check_date,
			$staff_id,
			$get_capacity
		);
	}

	// ──────────────────────────────────────────────────────────────
	// 6. rrule helpers
	// ──────────────────────────────────────────────────────────────

	/**
	 * Whether an RRULE has any occurrence on the civil day of $check_date.
	 *
	 * Day-unit availability uses midnight date tokens. Timed RRULE blocks (e.g.
	 * Tue 4–6pm) do not overlap midnight, so rrule_matches_timestamp() alone misses
	 * them on date-level checks. Reuses compute_rule_minutes() occurrence expansion.
	 *
	 * @since 5.3.8
	 *
	 * @param array<string, mixed> $range      Rule range with 'from', 'to', 'rrule' keys.
	 * @param int                  $check_date Civil day midnight timestamp.
	 * @return bool
	 */
	private static function rrule_applies_to_civil_day( array $range, int $check_date ): bool {
		// All-day RRULEs: rrule_matches_timestamp already reuses one RSet per rule in-request.
		// Do not run compute_rule_minutes first (that rebuilt RSet on every civil day).
		if ( false === strpos( (string) ( $range['from'] ?? '' ), ':' ) ) {
			return self::rrule_matches_timestamp( $range, $check_date );
		}

		$mins = self::compute_rule_minutes(
			[
				'type'  => 'rrule',
				'range' => $range,
			],
			$check_date
		);

		return ! empty( $mins['minutes'] );
	}

	/**
	 * Check if an rrule has an occurrence at a given timestamp.
	 *
	 * Uses static caching for rrule objects and results to avoid
	 * re-parsing the same rrule string repeatedly within a request.
	 *
	 * @since 5.3.0
	 *
	 * @param array<string, mixed> $range     Rule range with 'from', 'to', 'rrule' keys.
	 * @param int                  $timestamp Timestamp to check.
	 * @return bool
	 */
	private static function rrule_matches_timestamp( array $range, int $timestamp ): bool {
		// Per-request caches.
		static $cache       = [];
		static $rrule_cache = [];
		static $tz_gmt      = null;
		static $tz_fp               = null;
		static $gmt_offset_opt      = null;
		static $gmt_offset_interval = null;

		// Drop caches when store TZ identity changes (tests flip IANA while gmt_offset stays '').
		$fp = (string) get_option( 'timezone_string' ) . '|' . (string) get_option( 'gmt_offset' );
		if ( $tz_fp !== $fp ) {
			$tz_fp          = $fp;
			$gmt_offset_opt = null;
			$rrule_cache    = [];
			$cache          = [];
		}

		$rrule_cache_key = $range['from'] . ':' . $range['to'] . ':' . $range['rrule'];
		$cache_key       = $rrule_cache_key . ':' . $timestamp;

		if ( isset( $cache[ $cache_key ] ) ) {
			return $cache[ $cache_key ];
		}

		try {
			// Init static shared pieces once (or again after TZ flip nulls $gmt_offset_opt).
			if ( null === $tz_gmt ) {
				$tz_gmt = new \DateTimeZone( 'GMT' );
			}
			if ( null === $gmt_offset_opt ) {
				$gmt_offset_opt = (float) get_option( 'gmt_offset' );
				$abs_off        = abs( $gmt_offset_opt );
				$hours          = (int) floor( $abs_off );
				$minutes        = (int) round( ( $abs_off - $hours ) * 60 );
				$gmt_offset_interval = new \DateInterval( sprintf( 'PT%dH%dM', $hours, $minutes ) );
				if ( $gmt_offset_opt < 0 ) {
					$gmt_offset_interval->invert = 1;
				}
			}

			$datetime = new \DateTimeImmutable( '@' . (int) $timestamp );

			if ( ! isset( $rrule_cache[ $rrule_cache_key ] ) ) {
				$is_all_day = ( false === strpos( $range['from'], ':' ) );

				$start = ( new \DateTimeImmutable( $range['from'] ) )
					->setTimezone( $tz_gmt )
					->add( $gmt_offset_interval );

				$end = ( new \DateTimeImmutable( $range['to'] ) )
					->setTimezone( $tz_gmt )
					->add( $gmt_offset_interval );

				$duration_secs = abs( $end->getTimestamp() - $start->getTimestamp() );

				$rrule_str = wc_appointments_esc_rrule( $range['rrule'], $is_all_day );
				$rrule = new RSet( $rrule_str, $is_all_day ? $start->format( 'Y-m-d' ) : $start );

				$rrule_cache[ $rrule_cache_key ] = [
					'rrule_object'  => $rrule,
					'duration_secs' => $duration_secs,
				];
			}

			$rrule         = $rrule_cache[ $rrule_cache_key ]['rrule_object'];
			$duration_secs = $rrule_cache[ $rrule_cache_key ]['duration_secs'];

			// Zero duration — only exact matches count.
			if ( 0 === $duration_secs ) {
				if ( method_exists( $rrule, 'occursAt' ) ) {
					$result = (bool) $rrule->occursAt( $datetime );
					$cache[ $cache_key ] = $result;
					return $result;
				}
				// Fallback: bounded search in a 1-minute window.
				$window_start = $datetime->sub( new \DateInterval( 'PT1M' ) );
				$window_end   = $datetime->add( new \DateInterval( 'PT1M' ) );
				if ( method_exists( $rrule, 'getOccurrencesBetween' ) ) {
					$occurrences = $rrule->getOccurrencesBetween( $window_start, $window_end, true );
					foreach ( $occurrences as $occurrence ) {
						if ( (int) $occurrence->getTimestamp() === (int) $timestamp ) {
							$cache[ $cache_key ] = true;
							return true;
						}
					}
					$cache[ $cache_key ] = false;
					return false;
				}
				// Last resort: iterate and break early.
				foreach ( $rrule as $occurrence ) {
					$occ_ts = (int) $occurrence->getTimestamp();
					if ( $occ_ts === (int) $timestamp ) {
						$cache[ $cache_key ] = true;
						return true;
					}
					if ( $occ_ts > (int) $timestamp ) {
						break;
					}
				}
				$cache[ $cache_key ] = false;
				return false;
			}

			// Non-zero duration: look for occurrences that start within [timestamp - duration, timestamp].
			$window_start_ts = (int) $timestamp - (int) $duration_secs;
			$window_start    = new \DateTimeImmutable( '@' . $window_start_ts );
			$window_end      = $datetime;

			if ( method_exists( $rrule, 'getOccurrencesBetween' ) ) {
				$occurrences = $rrule->getOccurrencesBetween( $window_start, $window_end, true );
				foreach ( $occurrences as $occurrence ) {
					$occ_ts = (int) $occurrence->getTimestamp();
					if ( $occ_ts <= (int) $timestamp && ( $occ_ts + (int) $duration_secs ) >= (int) $timestamp ) {
						$cache[ $cache_key ] = true;
						return true;
					}
				}
				$cache[ $cache_key ] = false;
				return false;
			}

			// Fallback: iterate occurrences but stop once past target.
			foreach ( $rrule as $occurrence ) {
				$occ_ts = (int) $occurrence->getTimestamp();

				if ( $occ_ts <= (int) $timestamp && ( $occ_ts + (int) $duration_secs ) >= (int) $timestamp ) {
					$cache[ $cache_key ] = true;
					return true;
				}
				if ( $occ_ts > (int) $timestamp ) {
					break;
				}
				if ( $occ_ts < $window_start_ts ) {
					continue;
				}
			}
		} catch ( \Exception $e ) {
			wc_get_logger()->error( $e->getMessage() );
		}

		$cache[ $cache_key ] = false;
		return false;
	}
}
