<?php
/**
 * Unified AJAX handler for the new Slots Provider.
 *
 * Registers the `wc_appointments_get_slot_data` wc_ajax action that returns
 * hierarchical slot data from the Provider as JSON.
 *
 * This is distinct from the legacy `wp_ajax_wc_appointments_get_slots`
 * (time-picker HTML) and `wc_ajax_wc_appointments_find_scheduled_day_slots`
 * (date-picker legacy buckets) endpoints which remain for backward compat.
 *
 * Frontend JS can call this endpoint to get pre-computed day/slot data
 * with zero client-side rule processing.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Ajax — unified AJAX handler for slot queries.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Ajax {

	/**
	 * Constructor — registers AJAX actions.
	 */
	public function __construct() {
		add_action( 'wc_ajax_wc_appointments_get_slot_data', [ $this, 'get_slots' ] );
	}

	/**
	 * AJAX handler: get_slots.
	 *
	 * Expected POST params:
	 *   - product_id       (int, required)
	 *   - start_date       (string 'YYYY-MM-DD', required)
	 *   - end_date         (string 'YYYY-MM-DD', required)
	 *   - staff_id         (int, optional — 0 or absent = all staff / no preference)
	 *   - level            (string, optional — summary|days|slots|full, default: days)
	 *   - display_timezone (string, optional — IANA timezone for display projection)
	 *
	 * Returns JSON matching WC_Appointment_Slots_Collection::for_level() with
	 * pre-calculated display fields (display_day, display_time, display_time_formatted, etc.)
	 * when display_timezone is provided.
	 *
	 * @since 5.3.0
	 * @since 5.3.5 Added display_timezone parameter for Unified Slots Standardization.
	 */
	public function get_slots(): void {
		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::start( 'slots_request' );
		}

		// Rate limiting for guests; optional nonce tightens limits when stale (cached pages).
		if ( class_exists( 'WC_Appointments_Rate_Limiter' ) ) {
			WC_Appointments_Rate_Limiter::throttle_guest_read_with_optional_nonce(
				'get_slots',
				WC_Appointments_Rate_Limiter::GUEST_READ_MAX_REQUESTS,
				WC_Appointments_Rate_Limiter::GUEST_READ_WINDOW_SECONDS,
				'wc-appointments-get-slot-data',
				'get_slots_strict'
			);
		}

		// Validate required params.
		$product_id       = $this->slots_post_absint( 'product_id' );
		$start_date       = $this->slots_post_text( 'start_date' );
		$end_date         = $this->slots_post_text( 'end_date' );
		$staff_id         = $this->slots_post_absint( 'staff_id' );
		$level            = $this->slots_post_text( 'level', 'days' );
		$display_timezone = $this->slots_post_text( 'display_timezone' );

		if ( empty( $product_id ) ) {
			if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
				$this->log_slots_request_total( $product_id, $level );
			}
			wp_send_json_error( [ 'message' => 'Missing product_id' ], 400 );
		}

		if ( empty( $start_date ) || empty( $end_date ) ) {
			if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
				$this->log_slots_request_total( $product_id, $level );
			}
			wp_send_json_error( [ 'message' => 'Missing start_date or end_date' ], 400 );
		}

		// Validate date format.
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $start_date ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $end_date ) ) {
			if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
				$this->log_slots_request_total( $product_id, $level );
			}
			wp_send_json_error( [ 'message' => 'Invalid date format. Use YYYY-MM-DD.' ], 400 );
		}

		// Validate level.
		$valid_levels = [ 'summary', 'days', 'slots', 'full' ];
		if ( ! in_array( $level, $valid_levels, true ) ) {
			$level = 'days';
		}

		try {
			$product = get_wc_product_appointment( $product_id );

			if ( ! $product || ! is_wc_appointment_product( $product ) ) {
				if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
					$this->log_slots_request_total( $product_id, $level );
				}
				wp_send_json_error( [ 'message' => 'Invalid appointment product' ], 404 );
			}

			$result = WC_Appointment_Slots_Provider::get_slots_json(
				$product,
				$start_date,
				$end_date,
				$staff_id > 0 ? $staff_id : null,
				$level,
				false,                // get_past_times
				false,                // use_cache
				$display_timezone     // display_timezone for projection
			);

			if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
				$this->log_slots_request_total( $product_id, $level );
			}
			wp_send_json( $result );

		} catch ( Exception $e ) {
			if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
				$this->log_slots_request_total( $product_id, $level );
			}
			wp_send_json_error( [ 'message' => $e->getMessage() ], 500 );
		}
	}

	/**
	 * Stop slots_request timer and log total with 10ms target (AJAX).
	 *
	 * @param int    $product_id Product ID (for meta).
	 * @param string $level      Response level (for meta).
	 */
	private function log_slots_request_total( int $product_id, string $level ): void {
		$ms = WC_Appointment_Slots_Perf_Logger::stop( 'slots_request', [
			'product_id' => $product_id,
			'level'     => $level,
			'entry'     => 'ajax',
		] );
		if ( $ms > 0 ) {
			WC_Appointment_Slots_Perf_Logger::log( 'request_total', [
				'ms'          => $ms,
				'target_10ms' => $ms <= 10 ? 'OK' : 'OVER',
				'entry'       => 'ajax',
			] );
		}
	}

	/**
	 * Sanitized POST int for guest slot reads (rate-limited above).
	 *
	 * @param string $key POST field name.
	 * @return int
	 */
	private function slots_post_absint( string $key ): int {
		$value = filter_input( INPUT_POST, $key );
		if ( null === $value || false === $value ) {
			return 0;
		}

		return absint( wp_unslash( $value ) );
	}

	/**
	 * Sanitized POST string for guest slot reads (rate-limited above).
	 *
	 * @param string $key     POST field name.
	 * @param string $default Default when absent.
	 * @return string
	 */
	private function slots_post_text( string $key, string $default = '' ): string {
		$value = filter_input( INPUT_POST, $key );
		if ( null === $value || false === $value ) {
			return $default;
		}

		return sanitize_text_field( wp_unslash( $value ) );
	}
}
