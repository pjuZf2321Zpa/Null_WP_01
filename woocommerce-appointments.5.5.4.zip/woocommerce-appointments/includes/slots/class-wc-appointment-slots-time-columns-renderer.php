<?php
/**
 * Time Columns Renderer — Generates storefront time-slot HTML from Collection.
 *
 * UNIFIED SLOTS STANDARDIZATION (Phase G):
 * Moved from WC_Appointments_Controller::render_time_slots_html() so that
 * the Controller becomes a thin delegate (apply_filters + call + return).
 *
 * Clock rules (Fake UTC vs projected):
 * - Minute/hour slots from unified engine are UTC-labelled wall instants ("Fake UTC").
 * - Use gmdate() for civil day / bucket / labels when NOT converting into a
 *   different customer zone than the site.
 * - When customer timezone differs and is active, use wp_date() with that zone.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.6
 */

defined( 'ABSPATH' ) || exit;

/**
 * Renders time-slot columns (morning/afternoon/evening) from Collection data.
 *
 * All timezone math and bucketing logic lives here. Controller only delegates.
 *
 * @since 5.3.6
 */
final class WC_Appointment_Slots_Time_Columns_Renderer {

	/**
	 * Render time-slots HTML from a Collection.
	 *
	 * @param WC_Product_Appointment          $product    Product instance.
	 * @param WC_Appointment_Slots_Collection $collection Slot collection.
	 * @param array{
	 *     time_to_check?: int,
	 *     timestamp?: int,
	 *     timezone?: string,
	 *     include_sold_out?: bool,
	 *     staff_id?: int,
	 *     min_qty?: int,
	 *     intervals?: array<int, int>,
	 *     from?: int,
	 *     to?: int
	 * } $args Render options.
	 * @return array{html: string, timestamps: int[]}
	 */
	public static function render(
		WC_Product_Appointment $product,
		WC_Appointment_Slots_Collection $collection,
		array $args = []
	): array {
		$args = wp_parse_args( $args, [
			'time_to_check'    => 0,
			'timestamp'        => 0,
			'timezone'         => 'UTC',
			'include_sold_out' => false,
			'staff_id'         => 0,
			'min_qty'          => 1,
			'intervals'        => [],
			'from'             => 0,
			'to'               => 0,
		] );

		$time_to_check    = (int) $args['time_to_check'];
		$timestamp        = (int) $args['timestamp'];
		$timezone         = (string) $args['timezone'];
		$include_sold_out = (bool) $args['include_sold_out'];
		$staff_id         = (int) $args['staff_id'];
		$intervals        = $args['intervals'];
		$from             = (int) $args['from'];
		$to               = (int) $args['to'];

		$grouped = $collection->get_grouped_for_time_slots_display( $product, $include_sold_out, (int) $args['min_qty'] );
		if ( empty( $grouped ) ) {
			return [ 'html' => '', 'timestamps' => [] ];
		}

		$clock_context     = self::resolve_clock_context( $product, $timezone );
		$selected_day_ymd  = self::resolve_selected_day( $from, $timestamp, $clock_context );
		$times_columns     = self::get_times_columns();

		$slots_html      = '<div class="slot_row">';
		$slot_timestamps = [];

		foreach ( $times_columns as $column_key => $column ) {
			$slots_html .= '<ul class="slot_column ' . esc_attr( $column_key ) . '">';
			$slots_html .= '<li class="slot_heading">' . esc_html( $column['name'] ) . '</li>';
			$count       = 0;

			$column_rows = [];
			foreach ( $grouped as $ts => $data ) {
				$slot_render = self::render_single_slot(
					$product,
					(int) $ts,
					$data,
					$column,
					$clock_context,
					$selected_day_ymd,
					$time_to_check,
					$include_sold_out,
					$staff_id,
					$timezone
				);

				if ( null === $slot_render ) {
					continue;
				}

				$column_rows[] = [
					'minute' => self::slot_sort_minute_from_payload( $data, (int) $ts ),
					'ts'     => (int) $ts,
					'html'   => $slot_render['html'],
				];
			}

			usort(
				$column_rows,
				static function ( array $a, array $b ): int {
					$c = ( $a['minute'] <=> $b['minute'] );
					return 0 !== $c ? $c : ( $a['ts'] <=> $b['ts'] );
				}
			);

			foreach ( $column_rows as $row ) {
				$slots_html       .= $row['html'];
				$slot_timestamps[] = $row['ts'];
				$count++;
			}

			if ( 0 === $count ) {
				$slots_html .= '<li class="slot slot_empty">' . esc_html( '-' ) . '</li>';
			}

			$slots_html .= '</ul>';
		}

		$slots_html .= '</div>';

		if ( empty( $slot_timestamps ) ) {
			return [ 'html' => '', 'timestamps' => [] ];
		}

		return [ 'html' => $slots_html, 'timestamps' => $slot_timestamps ];
	}

	/**
	 * Minutes since midnight for ordering slots inside a column (customer display_time when H:i).
	 *
	 * @param array<string, mixed> $data Grouped slot row.
	 * @param int                  $ts   Slot start timestamp (Fake UTC when unified).
	 * @return int
	 */
	private static function slot_sort_minute_from_payload( array $data, int $ts ): int {
		if ( ! empty( $data['display_time'] ) && preg_match( '/^(\d{1,2}):(\d{2})$/', (string) $data['display_time'], $hm ) ) {
			return min( 24 * 60 - 1, max( 0, ( (int) $hm[1] * 60 ) + (int) $hm[2] ) );
		}

		return ( (int) gmdate( 'G', $ts ) ) * 60 + (int) gmdate( 'i', $ts );
	}

	/**
	 * Resolve clock context for slot rendering.
	 *
	 * Determines whether to use gmdate (Fake UTC) or wp_date (projected timezone)
	 * based on product settings and customer timezone.
	 *
	 * @param WC_Product_Appointment $product  Product instance.
	 * @param string                 $timezone Customer timezone string.
	 * @return array{use_gm: bool, slot_wall_tz: DateTimeZone, slot_day_cmp_tz: DateTimeZone, times_split_tz: DateTimeZone, local_time: string, site_time: string}
	 */
	private static function resolve_clock_context( WC_Product_Appointment $product, string $timezone ): array {
		$timezone_datetime = new DateTime();
		$local_time = $product->has_timezones()
			? wc_appointment_timezone_locale( 'site', 'user', $timezone_datetime->getTimestamp(), wc_appointments_time_format(), $timezone )
			: '';
		$site_time  = $product->has_timezones()
			? wc_appointment_timezone_locale( 'site', 'user', $timezone_datetime->getTimestamp(), wc_appointments_time_format(), wc_timezone_string() )
			: '';

		$slot_day_cmp_tz = wp_timezone();
		if ( $product->has_timezones() && '' !== $timezone ) {
			try {
				$slot_day_cmp_tz = new DateTimeZone( wc_appointments_normalize_timezone( $timezone ) );
			} catch ( Exception $e ) {
				$slot_day_cmp_tz = wp_timezone();
			}
		}

		$slot_wall_tz = $slot_day_cmp_tz;
		if ( ! $product->has_timezones() ) {
			$slot_wall_tz = new DateTimeZone( 'UTC' );
		}

		$use_gm_slot_clock = ! $product->has_timezones();
		if ( ! $use_gm_slot_clock && $slot_wall_tz instanceof DateTimeZone ) {
			try {
				$use_gm_slot_clock = ( $slot_wall_tz->getName() === wp_timezone()->getName() );
			} catch ( Exception $e ) {
				$use_gm_slot_clock = false;
			}
		}

		return [
			'use_gm'          => $use_gm_slot_clock,
			'slot_wall_tz'    => $slot_wall_tz,
			'slot_day_cmp_tz' => $slot_day_cmp_tz,
			'times_split_tz'  => wp_timezone(),
			'local_time'      => $local_time,
			'site_time'       => $site_time,
		];
	}

	/**
	 * Resolve selected day for filtering slots.
	 *
	 * @param int                                                                                                                                 $from          AJAX window start timestamp.
	 * @param int                                                                                                                                 $timestamp     Selected calendar day timestamp.
	 * @param array{use_gm: bool, slot_wall_tz: DateTimeZone, slot_day_cmp_tz: DateTimeZone, times_split_tz: DateTimeZone, local_time: string, site_time: string} $clock_context Clock context from resolve_clock_context().
	 * @return string Selected day in 'Y-m-d' format, or empty string.
	 */
	private static function resolve_selected_day( int $from, int $timestamp, array $clock_context ): string {
		$day_anchor_ts = ( $from > 0 ) ? $from : ( ( $timestamp > 0 ) ? $timestamp : 0 );
		if ( $day_anchor_ts <= 0 ) {
			return '';
		}

		if ( $clock_context['use_gm'] ) {
			return gmdate(
				'Y-m-d',
				( new DateTimeImmutable(
					wp_date( 'Y-m-d', $day_anchor_ts, $clock_context['slot_day_cmp_tz'] ) . ' 00:00:00',
					new DateTimeZone( 'UTC' )
				) )->getTimestamp()
			);
		}

		return wp_date( 'Y-m-d', $day_anchor_ts, $clock_context['slot_day_cmp_tz'] );
	}

	/**
	 * Get time columns (morning/afternoon/evening) with filters applied.
	 *
	 * Default from/to values stay strtotime()-based so existing
	 * woocommerce_appointments_times_split filters keep working.
	 *
	 * @return array<string, array{name: string, from: int, to: int}>
	 */
	private static function get_times_columns(): array {
		return apply_filters(
			'woocommerce_appointments_times_split',
			[
				'morning'   => [
					'name' => __( 'Morning', 'woocommerce-appointments' ),
					'from' => strtotime( '00:00' ),
					'to'   => strtotime( '12:00' ),
				],
				'afternoon' => [
					'name' => __( 'Afternoon', 'woocommerce-appointments' ),
					'from' => strtotime( '12:00' ),
					'to'   => strtotime( '17:00' ),
				],
				'evening'   => [
					'name' => __( 'Evening', 'woocommerce-appointments' ),
					'from' => strtotime( '17:00' ),
					'to'   => strtotime( '24:00' ),
				],
			]
		);
	}

	/**
	 * Render a single slot HTML element.
	 *
	 * @param WC_Product_Appointment                                                                                                                              $product          Product instance.
	 * @param int                                                                                                                                                 $ts               Slot timestamp.
	 * @param array<string, mixed>                                                                                                                                $data             Grouped slot data.
	 * @param array{name: string, from: int, to: int}                                                                                                             $column           Column definition (from/to).
	 * @param array{use_gm: bool, slot_wall_tz: DateTimeZone, slot_day_cmp_tz: DateTimeZone, times_split_tz: DateTimeZone, local_time: string, site_time: string} $clock_context    Clock context.
	 * @param string                                                                                                                                              $selected_day_ymd Selected day 'Y-m-d'.
	 * @param int                                                                                                                                                 $time_to_check    Currently selected time.
	 * @param bool                                                                                                                                                $include_sold_out Include sold-out slots.
	 * @param int                                                                                                                                                 $staff_id         Staff ID for filter.
	 * @param string                                                                                                                                              $timezone         Customer timezone.
	 * @return array{html: string}|null Null if slot should be skipped.
	 */
	private static function render_single_slot(
		WC_Product_Appointment $product,
		int $ts,
		array $data,
		array $column,
		array $clock_context,
		string $selected_day_ymd,
		int $time_to_check,
		bool $include_sold_out,
		int $staff_id,
		string $timezone
	): ?array {
		$use_gm       = $clock_context['use_gm'];
		$slot_wall_tz = $clock_context['slot_wall_tz'];
		$local_time   = $clock_context['local_time'];
		$site_time    = $clock_context['site_time'];

		$local_slot   = $product->has_timezones() ? wc_appointment_timezone_locale( 'site', 'user', $ts, 'U', $timezone ) : $ts;
		$display_slot = ( $product->has_timezones() && $local_time !== $site_time ) ? $local_slot : $ts;

		// Fake-UTC start_ts + wp_date in customer TZ is wrong for the civil day; use unified display_day.
		if ( in_array( $product->get_duration_unit(), [ 'minute', 'hour' ], true ) && ! empty( $data['display_day'] ) ) {
			$slot_day_display = (string) $data['display_day'];
		} elseif ( $use_gm ) {
			$slot_day_display = gmdate( 'Y-m-d', $ts );
		} else {
			$slot_day_display = wp_date( 'Y-m-d', $ts, $slot_wall_tz );
		}
		if ( '' !== $selected_day_ymd && $slot_day_display !== $selected_day_ymd ) {
			return null;
		}

		$unified_hhmm = ( in_array( $product->get_duration_unit(), [ 'minute', 'hour' ], true ) && ! empty( $data['display_time'] ) )
			? (string) $data['display_time']
			: '';

		if ( ! self::slot_in_column( (int) $display_slot, $column, $clock_context, $unified_hhmm ) ) {
			return null;
		}

		$available_qty    = (int) $data['available'];
		$spaces_left_text = $data['message'] ?? '';
		$show_spaces_left = '' !== $spaces_left_text;
		$quantity_compat  = [
			'scheduled'                 => $data['booked'],
			'available'                 => $available_qty,
			'staff'                     => $data['staff'],
			'price'                     => $data['price'] ?? [ 'show' => false, 'display' => '' ],
			'display_day'               => $data['display_day'] ?? '',
			'display_time'              => $data['display_time'] ?? '',
			'display_time_formatted'   => $data['display_time_formatted'] ?? '',
			'selection_value'          => $data['selection_value'] ?? '',
		];
		$price_html       = self::get_price_html( $quantity_compat );
		$selected         = self::is_slot_selected( $ts, $time_to_check, $use_gm, $slot_wall_tz, $unified_hhmm ) ? ' selected' : '';

		if ( $available_qty > 0 ) {
			return self::render_available_slot( $ts, $display_slot, $available_qty, $selected, $show_spaces_left, $spaces_left_text, $price_html, $quantity_compat, $time_to_check, $staff_id, $timezone, $product, $use_gm, $slot_wall_tz );
		}

		if ( 0 === $available_qty && $include_sold_out ) {
			return self::render_sold_out_slot( $ts, $display_slot, $selected, $show_spaces_left, $spaces_left_text, $price_html, $quantity_compat, $time_to_check, $staff_id, $timezone, $product, $use_gm, $slot_wall_tz );
		}

		return null;
	}

	/**
	 * Check if slot falls within a time column.
	 *
	 * @param int                                                                                                                                                 $display_slot  Display slot timestamp.
	 * @param array{name: string, from: int, to: int}                                                                                                             $column        Column definition.
	 * @param array{use_gm: bool, slot_wall_tz: DateTimeZone, slot_day_cmp_tz: DateTimeZone, times_split_tz: DateTimeZone, local_time: string, site_time: string} $clock_context Clock context.
	 * @param string                                                                                                                                              $display_hhmm  When non-empty, minutes since midnight in customer display zone (H:i) - for Fake UTC start_ts.
	 * @return bool
	 */
	private static function slot_in_column( int $display_slot, array $column, array $clock_context, string $display_hhmm = '' ): bool {
		$use_gm         = $clock_context['use_gm'];
		$times_split_tz = $clock_context['times_split_tz'];

		if ( $use_gm ) {
			$from_m = (int) gmdate( 'G', $column['from'] ) * 60 + (int) gmdate( 'i', $column['from'] );
			$to_m   = (int) gmdate( 'G', $column['to'] ) * 60 + (int) gmdate( 'i', $column['to'] );
		} elseif ( '' !== $display_hhmm && preg_match( '/^(\d{1,2}):(\d{2})$/', $display_hhmm ) ) {
			// Unified display_time (customer H:i): use gmdate on filter from/to so default
			// strtotime() bands stay 00:00–12:00–17:00–24:00 wall minutes; wp_date(..., site)
			// on those ints skews when PHP default TZ and wp_timezone() disagree.
			$from_m = (int) gmdate( 'G', (int) $column['from'] ) * 60 + (int) gmdate( 'i', (int) $column['from'] );
			$to_m   = (int) gmdate( 'G', (int) $column['to'] ) * 60 + (int) gmdate( 'i', (int) $column['to'] );
		} else {
			$from_m = (int) wp_date( 'G', $column['from'], $times_split_tz ) * 60 + (int) wp_date( 'i', $column['from'], $times_split_tz );
			$to_m   = (int) wp_date( 'G', $column['to'], $times_split_tz ) * 60 + (int) wp_date( 'i', $column['to'], $times_split_tz );
		}

		if ( $to_m <= $from_m ) {
			$to_m = 24 * 60;
		}

		$slot_m = null;
		if ( $display_hhmm !== '' && preg_match( '/^(\d{1,2}):(\d{2})$/', $display_hhmm, $hm ) ) {
			$slot_m = ( (int) $hm[1] * 60 ) + (int) $hm[2];
		}
		if ( null === $slot_m ) {
			$slot_m = $use_gm
				? ( (int) gmdate( 'G', $display_slot ) ) * 60 + (int) gmdate( 'i', $display_slot )
				: ( (int) wp_date( 'G', $display_slot, $clock_context['slot_wall_tz'] ) ) * 60 + (int) wp_date( 'i', $display_slot, $clock_context['slot_wall_tz'] );
		}

		return ( $slot_m >= $from_m && $slot_m < $to_m );
	}

	/**
	 * Check if slot is currently selected.
	 *
	 * @param int          $ts             Slot timestamp.
	 * @param int          $time_to_check  Selected time.
	 * @param bool         $use_gm         Use gmdate.
	 * @param DateTimeZone $slot_wall_tz   Slot wall timezone.
	 * @param string       $unified_hhmm   H:i in customer zone when minute/hour uses unified projection; empty = derive from $ts.
	 * @return bool
	 */
	private static function is_slot_selected( int $ts, int $time_to_check, bool $use_gm, DateTimeZone $slot_wall_tz, string $unified_hhmm = '' ): bool {
		if ( ! $time_to_check ) {
			return false;
		}

		// Engine / autoselect: time_to_check is the slot start_ts (Fake UTC site-axis).
		if ( $time_to_check === $ts ) {
			return true;
		}

		if ( $unified_hhmm !== '' && preg_match( '/^\d{1,2}:\d{2}$/', $unified_hhmm ) ) {
			// display_time is store-wall H:i on the site axis; do not wp_date() Fake UTC ints.
			if ( $use_gm ) {
				return gmdate( 'H:i', $time_to_check ) === $unified_hhmm;
			}
			$sel = wp_date( 'H:i', $time_to_check, $slot_wall_tz );
			return $sel === $unified_hhmm;
		}

		if ( $use_gm ) {
			return gmdate( 'G:i', $ts ) === gmdate( 'G:i', $time_to_check );
		}

		return wp_date( 'G:i', $ts, $slot_wall_tz ) === wp_date( 'G:i', $time_to_check, $slot_wall_tz );
	}

	/**
	 * Get price HTML snippet.
	 *
	 * @param array<string, mixed> $slot_data Slot data with price info.
	 * @return string
	 */
	private static function get_price_html( array $slot_data ): string {
		$price = $slot_data['price'] ?? null;
		if ( ! is_array( $price ) || empty( $price['show'] ) || empty( $price['display'] ) ) {
			return '';
		}
		return ' <small class="slot-price">' . wp_kses_post( $price['display'] ) . '</small>';
	}

	/**
	 * Labels and data attributes for one time row. Uses unified display_* when minute/hour (Fake UTC start_ts).
	 *
	 * @param WC_Product_Appointment $product          Product.
	 * @param int                    $ts               Slot start timestamp.
	 * @param int                    $display_slot     Display-adjusted timestamp.
	 * @param bool                   $use_gm           Whether to use gmdate clock.
	 * @param DateTimeZone           $slot_wall_tz     Wall timezone for display.
	 * @param array<string, mixed>   $quantity_compat  Grouped slot payload.
	 * @return array{display_time_formatted: string, display_day: string, display_time_24h: string, data_slot_hi: string, dv_clock: string, selection_value: string}
	 */
	private static function get_slot_clock_for_html(
		WC_Product_Appointment $product,
		int $ts,
		int $display_slot,
		bool $use_gm,
		DateTimeZone $slot_wall_tz,
		array $quantity_compat
	): array {
		$unified = in_array( $product->get_duration_unit(), [ 'minute', 'hour' ], true )
			&& ! empty( $quantity_compat['display_time'] )
			&& ! empty( $quantity_compat['display_time_formatted'] );

		if ( $unified ) {
			$display_time_24h      = (string) $quantity_compat['display_time'];
			$display_time_formatted = (string) $quantity_compat['display_time_formatted'];
			$display_day            = ! empty( $quantity_compat['display_day'] )
				? (string) $quantity_compat['display_day']
				: ( $use_gm ? gmdate( 'Y-m-d', $ts ) : wp_date( 'Y-m-d', $ts, $slot_wall_tz ) );
			$selection_value        = ! empty( $quantity_compat['selection_value'] )
				? (string) $quantity_compat['selection_value']
				: wp_date( 'c', $ts, wp_timezone() );
			$data_slot_hi           = str_replace( ':', '', $display_time_24h );
			$parts                  = array_map( 'intval', explode( ':', $display_time_24h, 2 ) );
			$dv_clock               = sprintf( '%d:%02d', $parts[0] ?? 0, $parts[1] ?? 0 );

			return [
				'display_time_formatted' => $display_time_formatted,
				'display_day'            => $display_day,
				'display_time_24h'       => $display_time_24h,
				'data_slot_hi'           => $data_slot_hi,
				'dv_clock'               => $dv_clock,
				'selection_value'        => $selection_value,
			];
		}

		$display_time_formatted = $use_gm
			? date_i18n( wc_appointments_time_format(), $ts, true )
			: wp_date( wc_appointments_time_format(), $ts, $slot_wall_tz );
		$display_day            = $use_gm ? gmdate( 'Y-m-d', $ts ) : wp_date( 'Y-m-d', $ts, $slot_wall_tz );
		$display_time_24h       = $use_gm ? gmdate( 'H:i', $ts ) : wp_date( 'H:i', $ts, $slot_wall_tz );
		$selection_value        = wp_date( 'c', $ts, wp_timezone() );
		$data_slot_hi           = $use_gm ? gmdate( 'Hi', (int) $display_slot ) : wp_date( 'Hi', (int) $display_slot, $slot_wall_tz );
		$dv_clock               = $use_gm ? gmdate( 'G:i', (int) $display_slot ) : wp_date( 'G:i', (int) $display_slot, $slot_wall_tz );

		return [
			'display_time_formatted' => $display_time_formatted,
			'display_day'            => $display_day,
			'display_time_24h'       => $display_time_24h,
			'data_slot_hi'           => $data_slot_hi,
			'dv_clock'               => $dv_clock,
			'selection_value'        => $selection_value,
		];
	}

	/**
	 * Render an available slot.
	 *
	 * @param int                    $ts               Slot start timestamp.
	 * @param int                    $display_slot     Display-adjusted timestamp.
	 * @param int                    $available_qty    Remaining capacity.
	 * @param string                 $selected         Selected CSS class fragment.
	 * @param bool                   $show_spaces_left Whether to show spaces left.
	 * @param string                 $spaces_left_text Spaces left label.
	 * @param string                 $price_html       Price HTML snippet.
	 * @param array<string, mixed>   $quantity_compat  Grouped slot payload.
	 * @param int                    $time_to_check    Currently selected time.
	 * @param int                    $staff_id         Staff ID.
	 * @param string                 $timezone         Customer timezone.
	 * @param WC_Product_Appointment $product          Product.
	 * @param bool                   $use_gm           Whether to use gmdate clock.
	 * @param DateTimeZone           $slot_wall_tz     Wall timezone for display.
	 * @return array{html: string}
	 */
	private static function render_available_slot(
		int $ts,
		int $display_slot,
		int $available_qty,
		string $selected,
		bool $show_spaces_left,
		string $spaces_left_text,
		string $price_html,
		array $quantity_compat,
		int $time_to_check,
		int $staff_id,
		string $timezone,
		WC_Product_Appointment $product,
		bool $use_gm,
		DateTimeZone $slot_wall_tz
	): array {
		$clk = self::get_slot_clock_for_html( $product, $ts, $display_slot, $use_gm, $slot_wall_tz, $quantity_compat );

		$display_time_formatted = $clk['display_time_formatted'];
		$display_day            = $clk['display_day'];
		$display_time_24h       = $clk['display_time_24h'];
		$selection_value        = $clk['selection_value'];

		$data_attrs = sprintf(
			'data-slot="%s" data-slot-timestamp="%s" data-remaining="%s" data-selection-value="%s" data-display-day="%s" data-display-time="%s" data-display-time-formatted="%s"',
			esc_attr( $clk['data_slot_hi'] ),
			esc_attr( $ts ),
			esc_attr( $available_qty ),
			esc_attr( $selection_value ),
			esc_attr( $display_day ),
			esc_attr( $display_time_24h ),
			esc_attr( $display_time_formatted )
		);

		$dv_clock = $clk['dv_clock'];

		if ( $show_spaces_left ) {
			$slot_html = '<li class="slot' . $selected . '" ' . $data_attrs . '><a href="#" data-value="' . esc_attr( $dv_clock ) . '">' . $display_time_formatted . $price_html . ' <small class="spaces-left">' . $spaces_left_text . '</small></a></li>';
		} else {
			$slot_html = '<li class="slot' . $selected . '" ' . $data_attrs . '><a href="#" data-value="' . esc_attr( $dv_clock ) . '">' . $display_time_formatted . $price_html . '</a></li>';
		}

		$filtered = apply_filters( 'woocommerce_appointments_time_slot_html', $slot_html, $display_slot, $quantity_compat, $time_to_check, $staff_id, $timezone, $product, $spaces_left_text, [] );
		$final    = self::ensure_timestamp_in_html( $filtered, $slot_html );

		return [ 'html' => $final ];
	}

	/**
	 * Render a sold-out slot.
	 *
	 * @param int                    $ts               Slot start timestamp.
	 * @param int                    $display_slot     Display-adjusted timestamp.
	 * @param string                 $selected         Selected CSS class fragment.
	 * @param bool                   $show_spaces_left Whether to show spaces left.
	 * @param string                 $spaces_left_text Spaces left label.
	 * @param string                 $price_html       Price HTML snippet.
	 * @param array<string, mixed>   $quantity_compat  Grouped slot payload.
	 * @param int                    $time_to_check    Currently selected time.
	 * @param int                    $staff_id         Staff ID.
	 * @param string                 $timezone         Customer timezone.
	 * @param WC_Product_Appointment $product          Product.
	 * @param bool                   $use_gm           Whether to use gmdate clock.
	 * @param DateTimeZone           $slot_wall_tz     Wall timezone for display.
	 * @return array{html: string}
	 */
	private static function render_sold_out_slot(
		int $ts,
		int $display_slot,
		string $selected,
		bool $show_spaces_left,
		string $spaces_left_text,
		string $price_html,
		array $quantity_compat,
		int $time_to_check,
		int $staff_id,
		string $timezone,
		WC_Product_Appointment $product,
		bool $use_gm,
		DateTimeZone $slot_wall_tz
	): array {
		$clk = self::get_slot_clock_for_html( $product, $ts, $display_slot, $use_gm, $slot_wall_tz, $quantity_compat );

		$slot_time_display  = $clk['display_time_formatted'];
		$display_day        = $clk['display_day'];
		$display_time_24h   = $clk['display_time_24h'];
		$selection_value    = $clk['selection_value'];

		$data_attrs = sprintf(
			'data-slot="%s" data-slot-timestamp="%s" data-remaining="0" data-selection-value="%s" data-display-day="%s" data-display-time="%s" data-display-time-formatted="%s"',
			esc_attr( $clk['data_slot_hi'] ),
			esc_attr( $ts ),
			esc_attr( $selection_value ),
			esc_attr( $display_day ),
			esc_attr( $display_time_24h ),
			esc_attr( $slot_time_display )
		);

		$dv_clock_so = $clk['dv_clock'];

		if ( $show_spaces_left ) {
			$slot_html = '<li class="slot slot-sold-out' . $selected . '" ' . $data_attrs . '><span data-value="' . esc_attr( $dv_clock_so ) . '"><span class="slot-time-text">' . $slot_time_display . '</span>' . $price_html . ' <small class="spaces-left">' . $spaces_left_text . '</small></span></li>';
		} else {
			$slot_html = '<li class="slot slot-sold-out' . $selected . '" ' . $data_attrs . '><span data-value="' . esc_attr( $dv_clock_so ) . '"><span class="slot-time-text">' . $slot_time_display . '</span>' . $price_html . '</span></li>';
		}

		$filtered = apply_filters( 'woocommerce_appointments_time_slot_html', $slot_html, $display_slot, $quantity_compat, $time_to_check, $staff_id, $timezone, $product, $spaces_left_text, [] );
		$final    = self::ensure_timestamp_in_html( $filtered, $slot_html );

		return [ 'html' => $final ];
	}

	/**
	 * Ensures filtered HTML contains required data-slot-timestamp.
	 *
	 * @param string $filtered_html HTML from filter.
	 * @param string $original_html Default HTML.
	 * @return string
	 */
	private static function ensure_timestamp_in_html( $filtered_html, string $original_html ): string {
		if ( ! is_string( $filtered_html ) || '' === $filtered_html ) {
			return $original_html;
		}
		if ( preg_match( '/data-slot-timestamp=["\'](\d+)["\']/', $filtered_html ) ) {
			return $filtered_html;
		}
		return $original_html;
	}
}
