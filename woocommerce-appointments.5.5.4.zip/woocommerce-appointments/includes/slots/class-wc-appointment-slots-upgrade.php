<?php
/**
 * Slots Architecture v3 — upgrade routine for covering indexes.
 *
 * Ensures the availability cache table has optimized indexes for the
 * Index Engine's 2-query pattern. Runs once via a version-gated option.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Upgrade — one-time index optimization.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Upgrade {

	/**
	 * Option key to track whether the upgrade has run.
	 *
	 * @var string
	 */
	private const OPTION_KEY = 'wca_slots_v3_indexes_applied';

	/**
	 * Current schema version.
	 *
	 * @var string
	 */
	private const SCHEMA_VERSION = '2.0';

	/**
	 * Run the upgrade if needed.
	 *
	 * Called during plugin init. Checks version-gated option to avoid repeat work.
	 */
	public static function maybe_upgrade(): void {
		$current = get_option( self::OPTION_KEY, '' );

		if ( self::SCHEMA_VERSION === $current ) {
			return;
		}

		self::add_covering_indexes();
		self::add_resource_id_column();

		update_option( self::OPTION_KEY, self::SCHEMA_VERSION, true );
	}

	/**
	 * Add covering indexes optimized for the Index Engine's queries.
	 *
	 * The Index Engine issues exactly 2 queries:
	 * 1. Availability rows: WHERE source='availability' AND product_id IN (0, ?) AND staff_id IN (?) AND start_ts < ? AND end_ts > ?
	 * 2. Appointment rows:  WHERE source='appointment' AND product_id = ? AND staff_id IN (?) AND start_ts < ? AND end_ts > ? AND status NOT IN (...)
	 *
	 * The existing indexes (avail_product_lookup, product_staff, time_idx) provide
	 * good coverage. This routine adds a specific composite index for the appointment
	 * query if it doesn't exist, ensuring the engine's 2-query pattern is fully covered.
	 */
	private static function add_covering_indexes(): void {
		global $wpdb;

		$table = $wpdb->prefix . 'wc_appointments_availability_cache';

		// Check if table exists.
		$table_exists = $wpdb->get_var(
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
		);

		if ( ! $table_exists ) {
			return;
		}

		// Index 1: Optimized for appointment occupancy query.
		// Covers: source + product_id + staff_id + time range + status (for filtering).
		if ( ! self::index_exists( $table, 'idx_v3_appt_occupancy' ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Migration DDL; table from wpdb->prefix.
			$wpdb->query( "ALTER TABLE `{$table}` ADD INDEX `idx_v3_appt_occupancy` (`source`, `product_id`, `staff_id`, `start_ts`, `end_ts`, `status`)" );
		}

		// Index 2: Optimized for availability rule query with priority ordering.
		// Covers: source + product_id + staff_id + time range + priority + ordering.
		if ( ! self::index_exists( $table, 'idx_v3_avail_rules' ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- Migration DDL; table from wpdb->prefix.
			$wpdb->query( "ALTER TABLE `{$table}` ADD INDEX `idx_v3_avail_rules` (`source`, `product_id`, `staff_id`, `start_ts`, `end_ts`, `priority`, `ordering`)" );
		}
	}

	/**
	 * Check if an index exists on a table.
	 *
	 * @param string $table     Table name.
	 * @param string $index_name Index name.
	 * @return bool
	 */
	/**
	 * Add resource_id column and update unique key to include it.
	 *
	 * dbDelta cannot redefine an existing UNIQUE KEY, so we use explicit ALTER.
	 */
	private static function add_resource_id_column(): void {
		global $wpdb;

		$table = $wpdb->prefix . 'wc_appointments_availability_cache';

		$table_exists = $wpdb->get_var(
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $table )
		);

		if ( ! $table_exists ) {
			return;
		}

		if ( ! self::column_exists( $table, 'resource_id' ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN `resource_id` bigint(20) unsigned NOT NULL default 0 AFTER `staff_id`" );
		}

		if ( ! self::index_exists( $table, 'idx_resource' ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "ALTER TABLE `{$table}` ADD INDEX `idx_resource` (`resource_id`, `start_ts`, `end_ts`)" );
		}

		// Rebuild unique key to include resource_id (dbDelta cannot do this).
		if ( self::index_exists( $table, 'uniq_occurrence' ) ) {
			// Check if the existing key already includes resource_id.
			$cols = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT COLUMN_NAME FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s ORDER BY SEQ_IN_INDEX",
					$table,
					'uniq_occurrence'
				)
			);
			if ( ! in_array( 'resource_id', $cols, true ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->query( "ALTER TABLE `{$table}` DROP INDEX `uniq_occurrence`, ADD UNIQUE KEY `uniq_occurrence` (`source`, `source_id`, `product_id`, `staff_id`, `resource_id`, `start_ts`, `end_ts`)" );
			}
		}
	}

	/**
	 * Check if a column exists on a table.
	 *
	 * @param string $table       Table name.
	 * @param string $column_name Column name.
	 * @return bool
	 */
	private static function column_exists( string $table, string $column_name ): bool {
		global $wpdb;

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = %s AND column_name = %s",
				$table,
				$column_name
			)
		);

		return (int) $result > 0;
	}

	private static function index_exists( string $table, string $index_name ): bool {
		global $wpdb;

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s",
				$table,
				$index_name
			)
		);

		return (int) $result > 0;
	}
}
