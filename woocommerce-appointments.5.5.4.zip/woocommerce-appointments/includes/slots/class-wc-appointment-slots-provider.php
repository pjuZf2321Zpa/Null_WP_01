<?php
/**
 * Slots Provider — central facade for slot generation.
 *
 * Single entry point for all slot queries. Uses the unified
 * WC_Appointment_Slots_Engine which automatically selects its data source
 * (index cache table vs in-memory rules) via the Data Normalizer.
 *
 * Features:
 *   - L1 transient cache keyed by product + date range + staff
 *   - Unified engine with automatic data-source selection
 *   - Staff merge for multi-staff products
 *   - Legacy filter bridge integration
 *   - Collection-level filter for new integrations
 *   - Modern day-level data for date picker (to_day_data)
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Provider — facade with L1 cache, engine routing, staff merge.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Provider {

	/**
	 * Whether hooks have been registered.
	 *
	 * @var bool
	 */
	private static bool $hooks_registered = false;

	/**
	 * L1 in-memory cache to avoid regeneration within the same request.
	 * Keyed by "{product_id}_{start}_{end}_s{staff_id}_{level}".
	 *
	 * @var array<string, WC_Appointment_Slots_Collection>
	 */
	private static array $l1_cache = [];

	/**
	 * Register cache invalidation hooks.
	 *
	 * Called once during plugin bootstrap. Piggybacks on the same events
	 * the existing WC_Appointments_Cache uses to clear transients.
	 */
	public static function register_hooks(): void {
		if ( self::$hooks_registered ) {
			return;
		}
		self::$hooks_registered = true;

		// Appointment mutations.
		add_action( 'woocommerce_appointment_cancelled', [ self::class, 'flush' ] );
		add_action( 'before_delete_post', [ self::class, 'flush_if_relevant' ] );
		add_action( 'wp_trash_post', [ self::class, 'flush_if_relevant' ] );
		add_action( 'untrash_post', [ self::class, 'flush_if_relevant' ] );
		add_action( 'save_post', [ self::class, 'flush_if_relevant' ] );
		add_action( 'woocommerce_pre_payment_complete', [ self::class, 'flush' ] );

		// In-cart status transitions — ensure immediate invalidation.
		add_action( 'woocommerce_appointment_in-cart', [ self::class, 'flush' ] );
		add_action( 'woocommerce_appointment_was-in-cart', [ self::class, 'flush' ] );

		// Scheduled cache clears.
		add_action( 'delete_appointment_transients', [ self::class, 'flush' ] );
		add_action( 'delete_appointment_ts_transients', [ self::class, 'flush' ] );
		add_action( 'delete_appointment_dr_transients', [ self::class, 'flush' ] );
		add_action( 'delete_appointment_staff_transients', [ self::class, 'flush' ] );
	}

	/**
	 * Transient cache TTL in seconds (5 minutes).
	 *
	 * @var int
	 */
	private const TRANSIENT_TTL = 300;

	/**
	 * Transient cache key prefix.
	 *
	 * @var string
	 */
	private const TRANSIENT_PREFIX = 'wca_slots_';

	/**
	 * Resolve Unix bounds when callers pass 0 (product min/max horizon relative to now).
	 *
	 * @since 5.3.9
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $min_date            Start timestamp (0 = product min horizon).
	 * @param int                    $max_date            End timestamp (0 = product max horizon).
	 * @return array{0: int, 1: int} Resolved `[ $min_date, $max_date ]`.
	 */
	public static function resolve_schedule_bounds( WC_Product_Appointment $appointable_product, int $min_date, int $max_date ): array {
		$now = current_time( 'timestamp' );
		if ( 0 === $min_date || 0 === $max_date ) {
			$min_a = $appointable_product->get_min_date_a();
			$max_a = $appointable_product->get_max_date_a();
			if ( 0 === $min_date ) {
				$min_date = strtotime( "+{$min_a['value']} {$min_a['unit']}", $now );
			}
			if ( 0 === $max_date ) {
				$max_date = strtotime( "+{$max_a['value']} {$max_a['unit']}", $now );
			}
		}

		return [ $min_date, $max_date ];
	}

	/**
	 * Get slots for a product within a date range.
	 *
	 * This is THE primary entry point for all slot queries.
	 *
	 * UNIFIED SLOTS STANDARDIZATION: When display_timezone is provided,
	 * all slots will have their display fields pre-calculated for that timezone.
	 * Consumers can render slots without any post-processing.
	 *
	 * @param WC_Product_Appointment $appointable_product The appointment product.
	 * @param string                 $start_date       Range start 'YYYY-MM-DD'.
	 * @param string                 $end_date         Range end 'YYYY-MM-DD'.
	 * @param int|int[]|null         $staff_id         Staff ID, staff ID list, or null for all staff / product-level.
	 * @param string                 $level            Response level: summary|days|slots|full.
	 * @param bool                   $get_past_times   Include past time slots.
	 * @param bool                   $use_cache        Whether to use L1/transient cache.
	 * @param string                 $display_timezone Customer's display timezone (IANA format). Empty = business timezone.
	 * @param bool                   $for_availability Skip display projection and inline pricing (no cache).
	 * @param int                    $location_id      Location occupancy scope (0 = unscoped).
	 * @param int                    $resource_id      Customer-selected resource occupancy (0 = OR / unscoped).
	 * @return WC_Appointment_Slots_Collection
	 */
	public static function get_slots(
		WC_Product_Appointment $appointable_product,
		string $start_date,
		string $end_date,
		$staff_id = null,
		string $level = 'days',
		bool $get_past_times = false,
		bool $use_cache = false,
		string $display_timezone = '',
		bool $for_availability = false,
		int $location_id = 0,
		int $resource_id = 0
	): WC_Appointment_Slots_Collection {
		/**
		 * Control whether the Slots Provider uses L1 and transient caching (not indexing).
		 *
		 * Default: false (transient/L1 caching disabled). Enable when needed with:
		 * add_filter( 'wc_appointments_slots_cache_enabled', '__return_true' );
		 *
		 * @since 5.3.0
		 *
		 * @param bool                   $use_cache             Whether caching is enabled.
		 * @param WC_Product_Appointment $appointable_product   The appointment product.
		 */
		$cache_enabled = (bool) apply_filters( 'wc_appointments_slots_cache_enabled', $use_cache, $appointable_product );
		if ( ! $cache_enabled ) {
			$use_cache = false;
		}

		// L1 only when callers explicitly opt into use_cache (never implied by for_availability).
		$use_l1 = $use_cache;

		// When perf logging is on, skip all caches so timings are not masked.
		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			$use_cache = false;
			$use_l1    = false;
		}

		$product_id       = $appointable_product->get_id();
		$single_staff_id  = null;
		$multi_staff_ids  = null;
		if ( is_array( $staff_id ) ) {
			$multi_staff_ids = array_values( array_unique( array_filter( array_map( 'intval', $staff_id ) ) ) );
			if ( [] === $multi_staff_ids ) {
				$single_staff_id = 0;
				$multi_staff_ids = null;
			} elseif ( 1 === count( $multi_staff_ids ) ) {
				$single_staff_id = $multi_staff_ids[0];
				$multi_staff_ids = null;
			}
		} elseif ( null !== $staff_id ) {
			$single_staff_id = (int) $staff_id;
		}
		$staff_key   = null !== $single_staff_id ? $single_staff_id : ( null !== $multi_staff_ids ? 'm' . implode( '-', $multi_staff_ids ) : 0 );
		$location_id = self::resolve_occupancy_location_id( $appointable_product, $location_id );
		$resource_id = max( 0, $resource_id );
		$cache_key   = self::build_cache_key( $product_id, $start_date, $end_date, $staff_key );
		// Addon-adjusted validation clones share the product ID; key on length so a
		// duration-mutated collection never reuses base-duration rows (or vice versa).
		$cache_key .= ':d' . (int) $appointable_product->get_duration() . $appointable_product->get_duration_unit();
		$cache_key .= ':l' . $location_id;
		$cache_key .= ':r' . $resource_id;
		if ( $for_availability ) {
			$cache_key .= ':avail';
		}

		// L1 in-memory cache check.
		if ( $use_l1 && isset( self::$l1_cache[ $cache_key ] ) ) {
			return self::$l1_cache[ $cache_key ];
		}

		// Transient cache check.
		if ( $use_cache ) {
			$cached = get_transient( $cache_key );
			if ( $cached instanceof WC_Appointment_Slots_Collection ) {
				self::$l1_cache[ $cache_key ] = $cached;
				return $cached;
			}
		}

		$prev_location = WC_Appointment_Slots_Engine::get_occupancy_location_id();
		$prev_resource = WC_Appointment_Slots_Engine::get_occupancy_resource_id();
		WC_Appointment_Slots_Engine::set_occupancy_location_id( $location_id );
		WC_Appointment_Slots_Engine::set_occupancy_resource_id( $resource_id );

		try {
		// Generate slots.
		// Use site-timezone midnight so day/month slots are anchored to the correct local day,
		// not UTC midnight (which diverges in non-UTC sites like Europe/Ljubljana UTC+2).
		$site_tz  = new DateTimeZone( wc_timezone_string() );
		$start_ts = ( new DateTime( $start_date . ' 00:00:00', $site_tz ) )->modify( '-1 day' )->getTimestamp();
		$end_ts   = ( new DateTime( $end_date . ' 00:00:00', $site_tz ) )->modify( '+1 day' )->getTimestamp();

		$all_slots = [];
		$engine    = 'dynamic';
		$meta      = [];
		$skip_pricing = $for_availability;

		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::start( 'provider_generate' );
		}
		// Determine if we should generate per-staff or product-level.
		if ( $appointable_product->has_staff() && null === $single_staff_id ) {
			// Multi-staff: generate per staff, then merge (optional location-filtered subset).
			$all_slots = self::generate_multi_staff( $appointable_product, $start_ts, $end_ts, $get_past_times, $engine, $meta, $skip_pricing, $multi_staff_ids );
		} else {
			// Single staff or no staff.
			$result    = self::generate_single( $appointable_product, $start_ts, $end_ts, $single_staff_id ?? 0, $get_past_times, $skip_pricing );
			$all_slots = $result['slots'];
			$engine    = $result['engine'];
			$meta      = $result['meta'];
		}
		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::stop(
                 'provider_generate',
                [
					'product'  => $product_id,
					'engine'   => $engine,
					'staff'    => $single_staff_id ?? ( $multi_staff_ids ?? 'all' ),
					'slots'    => count( $all_slots ),
				]
                );
		}

		// Apply legacy filters.
		$intervals = $appointable_product->get_intervals();
		$all_slots = WC_Appointment_Legacy_Filter_Bridge::apply_available_slots_filter(
			$all_slots,
            $appointable_product,
            $intervals,
            $single_staff_id ?? 0
		);
		$all_slots = WC_Appointment_Legacy_Filter_Bridge::apply_time_slots_filter(
			$all_slots,
            $appointable_product,
            $single_staff_id ?? 0,
            $start_ts,
            $end_ts
		);

		// Project display fields (Unified Slots Standardization).
		if ( ! $for_availability ) {
			$business_tz_string  = wc_timezone_string();
			$resolved_display_tz = self::resolve_display_timezone( $appointable_product, $display_timezone, $business_tz_string );
			$all_slots           = self::project_all_display_fields(
				$all_slots,
				$business_tz_string,
				$resolved_display_tz,
				$appointable_product->get_duration_unit(),
				$level
			);
		}

		$all_slots = WC_Appointment_Slots_Collection::apply_per_day_inventory_to_slots( $all_slots, $appointable_product );

		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::start( 'provider_collection_build' );
		}
		// Build collection.
		$collection = WC_Appointment_Slots_Collection::from_slots(
			$all_slots,
			$appointable_product,
			$start_date,
			$end_date,
			array_merge(
				$meta,
				[
					'engine' => (int) ( $meta['data_engine'] ?? 2 ),
				]
			)
		);

		// Apply new collection-level filter.
		$collection = WC_Appointment_Legacy_Filter_Bridge::apply_collection_filter( $collection, $appointable_product );

		if ( WC_Appointment_Slots_Perf_Logger::is_enabled() ) {
			WC_Appointment_Slots_Perf_Logger::stop(
                 'provider_collection_build',
                [
					'days' => count( $collection->get_days() ),
				]
                );
		}

		// Store in caches.
		if ( $use_l1 ) {
			self::$l1_cache[ $cache_key ] = $collection;
		}
		if ( $use_cache ) {
			set_transient( $cache_key, $collection, self::TRANSIENT_TTL );
			self::$transient_keys[ $cache_key ] = true;
		}

		return $collection;
		} finally {
			WC_Appointment_Slots_Engine::set_occupancy_location_id( $prev_location );
			WC_Appointment_Slots_Engine::set_occupancy_resource_id( $prev_resource );
		}
	}

	/**
	 * Get slots as a JSON-ready array for a specific response level.
	 *
	 * Convenience method for AJAX/REST handlers.
	 *
	 * @since 5.3.0
	 * @since 5.3.5 Added $display_timezone parameter for Unified Slots Standardization.
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param string                 $start_date       Range start 'YYYY-MM-DD'.
	 * @param string                 $end_date         Range end 'YYYY-MM-DD'.
	 * @param int|null               $staff_id         Staff ID.
	 * @param string                 $level            Response level.
	 * @param bool                   $get_past_times   Include past time slots.
	 * @param bool                   $use_cache        Whether to use L1/transient cache.
	 * @param string                 $display_timezone IANA timezone for display field projection.
	 * @return array<string, mixed>
	 */
	public static function get_slots_json(
		WC_Product_Appointment $appointable_product,
		string $start_date,
		string $end_date,
		?int $staff_id = null,
		string $level = 'days',
		bool $get_past_times = false,
		bool $use_cache = false,
		string $display_timezone = '',
		int $location_id = 0
	): array {
		$collection = self::get_slots( $appointable_product, $start_date, $end_date, $staff_id, $level, $get_past_times, $use_cache, $display_timezone, false, $location_id );
		return $collection->for_level( $level );
	}

	/**
	 * Get modern day-level data for the date picker.
	 *
	 * Returns pre-computed per-day data that consumers interpret declaratively (no client calculations).
	 *
	 * @since 5.3.0
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $min_date    Min timestamp.
	 * @param int                    $max_date    Max timestamp.
	 * @param int                    $tz_offset   Customer timezone offset in minutes. Default 0.
	 * @param int[]|int              $staff_ids   Staff IDs to filter by. Default empty array (all).
	 * @param string                 $date_format PHP date format for day keys. Default 'Y-n-j'.
	 * @param bool                   $get_past_times Include past time slots.
	 * @param bool                   $use_cache      Whether to use L1/transient cache.
	 * @return array{day_data: array<string, array<string, mixed>>} Filtered through `woocommerce_appointments_scheduled_day_slots`.
	 */
	public static function get_day_data(
		WC_Product_Appointment $appointable_product,
		int $min_date,
		int $max_date,
		int $tz_offset = 0,
		$staff_ids = [],
		string $date_format = 'Y-n-j',
		bool $get_past_times = false,
		bool $use_cache = false
	): array {
		[ $min_date, $max_date ] = self::resolve_schedule_bounds( $appointable_product, $min_date, $max_date );

		$start_date = wp_date( 'Y-m-d', $min_date );
		$end_date   = wp_date( 'Y-m-d', $max_date );

		// Determine the staff_id for the Provider query.
		$staff_id = null;
		if ( is_int( $staff_ids ) && 0 !== $staff_ids ) {
			$staff_id = $staff_ids;
		} elseif ( is_array( $staff_ids ) && ! empty( $staff_ids ) && 1 === count( $staff_ids ) ) {
			$staff_id = (int) $staff_ids[0];
		}

		$collection = self::get_slots( $appointable_product, $start_date, $end_date, $staff_id, 'days', $get_past_times, $use_cache );

		$result = $collection->to_day_data( $appointable_product, $tz_offset, $date_format, null );

		/**
		 * Filter day-level slot summary for PHP callers (same payload shape as storefront `day_data`).
		 *
		 * @since 1.0.0
		 * @since 5.3.9 Legacy four-array shape removed; value is `to_day_data()` output (`day_data` key).
		 *
		 * @param array                  $day_data_payload Array with `day_data` key (see `WC_Appointment_Slots_Collection::to_day_data()`).
		 * @param WC_Product_Appointment $appointable_product Product.
		 */
		return apply_filters( 'woocommerce_appointments_scheduled_day_slots', $result, $appointable_product );
	}

	/**
	 * Padding dates (`Y-n-j` => `Y-n-j`) adjacent to fully booked anchors for day/month products.
	 *
	 * Same rule as timed padding: the gap between two appointments is earlier.after +
	 * later.before. For this product's calendar that is (before + after) days on each
	 * side of a booked block. Contiguous fully booked runs skip the inner edge.
	 *
	 * @since 5.3.9
	 *
	 * @param WC_Product_Appointment $appointable_product Appointment product.
	 * @param string[]               $fully_booked_dates Dates in `Y-n-j` that are fully booked.
	 * @return array<string, string>
	 */
	public static function get_padding_days_for_fully_booked_dates( WC_Product_Appointment $appointable_product, array $fully_booked_dates ): array {
		$anchors = [];
		foreach ( $fully_booked_dates as $d ) {
			if ( is_string( $d ) && '' !== $d ) {
				$anchors[ $d ] = true;
			}
		}

		// Day products store padding in the shared unit (forced to "day" in the product UI).
		$edge = (int) $appointable_product->get_padding_duration() + (int) $appointable_product->get_padding_after_duration();
		if ( $edge < 1 ) {
			return [];
		}

		$padding_days = [];
		$site_tz      = wp_timezone();

		foreach ( array_keys( $anchors ) as $date ) {
			try {
				$date_dt  = new DateTimeImmutable( $date . ' 00:00:00', $site_tz );
				$next_day = $date_dt->modify( '+1 day' );
			} catch ( Exception $e ) {
				continue;
			}

			if ( isset( $anchors[ $next_day->format( 'Y-n-j' ) ] ) ) {
				continue;
			}

			for ( $i = 1; $i <= $edge; $i++ ) {
				$padding_day                  = $date_dt->modify( "+{$i} day" )->format( 'Y-n-j' );
				$padding_days[ $padding_day ] = $padding_day;
			}
		}

		foreach ( array_keys( $anchors ) as $date ) {
			try {
				$date_dt      = new DateTimeImmutable( $date . ' 00:00:00', $site_tz );
				$previous_day = $date_dt->modify( '-1 day' );
			} catch ( Exception $e ) {
				continue;
			}

			if ( isset( $anchors[ $previous_day->format( 'Y-n-j' ) ] ) ) {
				continue;
			}

			for ( $i = 1; $i <= $edge; $i++ ) {
				$padding_day                  = $date_dt->modify( "-{$i} day" )->format( 'Y-n-j' );
				$padding_days[ $padding_day ] = $padding_day;
			}
		}

		return $padding_days;
	}

	/**
	 * Padding dates for the product horizon from current `day_data` fully-booked days.
	 *
	 * @since 5.3.9
	 *
	 * @param WC_Product_Appointment|int $appointable_product Product instance or ID.
	 * @return array<string, string> Padding days keyed by `Y-n-j`.
	 */
	public static function get_padding_days_for_product( $appointable_product ): array {
		if ( is_int( $appointable_product ) ) {
			$appointable_product = wc_get_product( $appointable_product );
		}
		if ( ! is_wc_appointment_product( $appointable_product ) ) {
			return [];
		}

		try {
			$payload      = self::get_day_data( $appointable_product, 0, 0, 0, [], 'Y-n-j' );
			$day_data     = isset( $payload['day_data'] ) && is_array( $payload['day_data'] ) ? $payload['day_data'] : [];
			$anchor_dates = [];
			foreach ( $day_data as $date_key => $entry ) {
				if ( 'fully_booked' === ( $entry['status'] ?? '' ) ) {
					$anchor_dates[] = $date_key;
				}
			}

			return self::get_padding_days_for_fully_booked_dates( $appointable_product, $anchor_dates );
		} catch ( Exception $e ) {
			return [];
		}
	}

	/**
	 * Month keys (`Y-n`) whose aggregated `day_data` is fully booked (product horizon).
	 *
	 * @since 5.3.9
	 *
	 * @param WC_Product_Appointment|int $appointable_product Product instance or ID.
	 * @return array{fully_scheduled_months: array<string, array<string, mixed>>} Filtered through `woocommerce_appointments_scheduled_month_slots`.
	 */
	public static function get_scheduled_month_slots( $appointable_product ): array {
		if ( is_int( $appointable_product ) ) {
			$appointable_product = wc_get_product( $appointable_product );
		}

		$scheduled_month_slots = [
			'fully_scheduled_months' => [],
		];

		if ( ! is_wc_appointment_product( $appointable_product ) ) {
			return apply_filters( 'woocommerce_appointments_scheduled_month_slots', $scheduled_month_slots, $appointable_product );
		}

		try {
			$payload  = self::get_day_data( $appointable_product, 0, 0, 0, [], 'Y-n' );
			$day_data = isset( $payload['day_data'] ) && is_array( $payload['day_data'] ) ? $payload['day_data'] : [];
			$months   = [];
			foreach ( $day_data as $month_key => $entry ) {
				if ( 'fully_booked' === ( $entry['status'] ?? '' ) ) {
					$months[ $month_key ] = [];
				}
			}
			$scheduled_month_slots['fully_scheduled_months'] = $months;
		} catch ( Exception $e ) {
			$scheduled_month_slots['fully_scheduled_months'] = [];
		}

		/**
		 * Filter the scheduled month slots calculated per product.
		 *
		 * @since 3.7.4
		 *
		 * @param array                  $scheduled_month_slots {
		 *     @type array $fully_scheduled_months Month keys (`Y-n`) => placeholder row (keys-only semantics preserved).
		 * }
		 * @param WC_Product_Appointment $appointable_product Product.
		 */
		return apply_filters( 'woocommerce_appointments_scheduled_month_slots', $scheduled_month_slots, $appointable_product );
	}

	/**
	 * Get the raw Collection for a date range.
	 *
	 * Returns the Collection object directly so callers can derive both
	 * legacy and modern formats from a single slot-generation pass.
	 *
	 * @since 5.3.0
	 * @since 5.3.5 Added $display_timezone parameter for Unified Slots Standardization.
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $min_date         Min timestamp.
	 * @param int                    $max_date         Max timestamp.
	 * @param int[]|int              $staff_ids        Staff IDs to filter by. Default empty array (all).
	 * @param bool                   $get_past_times   Include past times.
	 * @param bool                   $use_cache        Whether to use cache.
	 * @param string                 $display_timezone IANA timezone for display field projection.
	 * @param int                    $location_id      Occupancy location scope.
	 * @param bool                   $for_availability Skip per-slot pricing/display (calendar day_data).
	 * @param int                    $resource_id      Customer-selected resource occupancy (0 = OR / unscoped).
	 * @return WC_Appointment_Slots_Collection
	 */
	public static function get_collection(
		WC_Product_Appointment $appointable_product,
		int $min_date,
		int $max_date,
		$staff_ids = [],
		bool $get_past_times = false,
		bool $use_cache = false,
		string $display_timezone = '',
		int $location_id = 0,
		bool $for_availability = false,
		int $resource_id = 0
	): WC_Appointment_Slots_Collection {
		[ $min_date, $max_date ] = self::resolve_schedule_bounds( $appointable_product, $min_date, $max_date );

		// Map Unix bounds to site-local calendar dates (same idea as get_time_slots_collection).
		$tz_site_obj = new DateTimeZone( wc_timezone_string() );
		$start_date  = wp_date( 'Y-m-d', $min_date );
		$end_date    = wp_date( 'Y-m-d', $max_date );
		if ( wp_date( 'H:i:s', $max_date ) !== '00:00:00' ) {
			$end_date = ( new DateTimeImmutable( '@' . $max_date ) )->setTimezone( $tz_site_obj )->modify( '+1 day' )->format( 'Y-m-d' );
		}

		$staff_id = null;
		if ( is_int( $staff_ids ) && 0 !== $staff_ids ) {
			$staff_id = $staff_ids;
		} elseif ( is_array( $staff_ids ) && ! empty( $staff_ids ) ) {
			$normalized = array_values( array_unique( array_filter( array_map( 'intval', $staff_ids ) ) ) );
			if ( 1 === count( $normalized ) ) {
				$staff_id = $normalized[0];
			} elseif ( count( $normalized ) > 1 ) {
				$staff_id = $normalized;
			}
		}

		return self::get_slots( $appointable_product, $start_date, $end_date, $staff_id, 'days', $get_past_times, $use_cache, $display_timezone, $for_availability, $location_id, $resource_id );
	}

	/**
	 * Get a Collection of time slots for a date range.
	 *
	 * Returns the native Collection object — the single source of truth.
	 * Consumers should read slot data directly from the Collection
	 * instead of converting to legacy formats.
	 *
	 * @since 5.3.0
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $from     Range start timestamp.
	 * @param int                    $to       Range end timestamp.
	 * @param int|array<int, int>    $staff_id Staff ID, array of staff IDs, or 0 for no preference.
	 * @param bool                   $get_past_times Include past times.
	 * @param bool                   $use_cache      Whether to use cache.
	 * @param string                 $display_timezone IANA timezone for display field projection (Unified Slots). Empty = business/site.
	 * @param bool                   $for_availability Skip display projection and inline pricing (capacity checks only).
	 * @return WC_Appointment_Slots_Collection
	 */
	public static function get_time_slots_collection(
		WC_Product_Appointment $appointable_product,
		int $from,
		int $to,
		$staff_id = 0,
		bool $get_past_times = false,
		bool $use_cache = false,
		string $display_timezone = '',
		bool $for_availability = false,
		int $location_id = 0,
		int $resource_id = 0
	): WC_Appointment_Slots_Collection {
		$tz_site_obj = new DateTimeZone( wc_timezone_string() );

		// Map Unix bounds to site-local calendar dates (not date() / strtotime in PHP default TZ).
		$start_date = wp_date( 'Y-m-d', $from );
		$end_date   = wp_date( 'Y-m-d', $to );

		// Single site-calendar day, or end not at site midnight: include the next site day.
		if ( $start_date === $end_date || wp_date( 'H:i:s', $to ) !== '00:00:00' ) {
			$end_date = ( new DateTimeImmutable( '@' . $to ) )->setTimezone( $tz_site_obj )->modify( '+1 day' )->format( 'Y-m-d' );
		}

		// Customer timezone: availability can spill across site-midnight; widen using site-local ±1 day.
		$range_seconds = $to - $from;
		if ( $appointable_product->has_timezones()
			&& in_array( $appointable_product->get_duration_unit(), [ 'minute', 'hour' ], true )
			&& $range_seconds > 0
			&& $range_seconds <= 10 * DAY_IN_SECONDS
		) {
			$widen_start = ( new DateTimeImmutable( '@' . $from ) )->setTimezone( $tz_site_obj )->modify( '-1 day' )->format( 'Y-m-d' );
			$widen_end   = ( new DateTimeImmutable( '@' . $to ) )->setTimezone( $tz_site_obj )->modify( '+1 day' )->format( 'Y-m-d' );
			if ( $widen_start < $start_date ) {
				$start_date = $widen_start;
			}
			if ( $widen_end > $end_date ) {
				$end_date = $widen_end;
			}
		}

		// Determine the staff_id for Provider query.
		$provider_staff = null;
		if ( is_array( $staff_id ) ) {
			$normalized = array_values( array_unique( array_filter( array_map( 'intval', $staff_id ) ) ) );
			if ( 1 === count( $normalized ) ) {
				$provider_staff = $normalized[0];
			} elseif ( count( $normalized ) > 1 ) {
				$provider_staff = $normalized;
			}
		} elseif ( is_int( $staff_id ) && 0 !== $staff_id ) {
			$provider_staff = $staff_id;
		}

		return self::get_slots( $appointable_product, $start_date, $end_date, $provider_staff, 'slots', $get_past_times, $use_cache, $display_timezone, $for_availability, $location_id, $resource_id );
	}

	/**
	 * Get slots as REST API v1/v2 records format.
	 *
	 * Convenience method for REST controllers.
	 *
	 * @since 5.3.0
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $min_date       Min timestamp.
	 * @param int|null               $staff_id       Staff ID (null for all).
	 * @param bool                   $get_past_times Include past times.
	 * @param bool                   $use_cache      Whether to use cache.
	 * @return array<int, array<string, mixed>> Flat slot records.
	 */
	public static function get_rest_records(
		WC_Product_Appointment $appointable_product,
		int $min_date,
		int $max_date,
		?int $staff_id = null,
		bool $get_past_times = false,
		bool $use_cache = false,
		int $location_id = 0
	): array {
		$tz_site_obj = wp_timezone();
		$start_date  = wp_date( 'Y-m-d', $min_date );
		$end_date    = wp_date( 'Y-m-d', $max_date );
		if ( wp_date( 'H:i:s', $max_date ) !== '00:00:00' ) {
			$end_date = ( new DateTimeImmutable( '@' . $max_date ) )->setTimezone( $tz_site_obj )->modify( '+1 day' )->format( 'Y-m-d' );
		}

		$collection = self::get_slots( $appointable_product, $start_date, $end_date, $staff_id, 'slots', $get_past_times, $use_cache, '', false, $location_id );

		return self::slots_collection_to_rest_records( $collection, $appointable_product );
	}

	/**
	 * Flatten slot objects into REST slot records (timezone-safe formatting).
	 *
	 * @since 5.3.9 Inlined from removed WC_Appointment_Slots_Legacy_Adapter::collection_to_rest_records().
	 *
	 * @param WC_Appointment_Slots_Collection $collection          Slots collection.
	 * @param WC_Product_Appointment          $appointable_product Product.
	 * @param string                          $timezone            Timezone for slot datetime strings (default site TZ).
	 * @return array<int, array<string, mixed>>
	 */
	private static function slots_collection_to_rest_records(
		WC_Appointment_Slots_Collection $collection,
		WC_Product_Appointment $appointable_product,
		string $timezone = ''
	): array {
		$records       = [];
		$product_id    = $appointable_product->get_id();
		$product_name  = $appointable_product->get_title();
		$duration      = $appointable_product->get_duration();
		$duration_unit = $appointable_product->get_duration_unit();
		$tz            = $timezone ?: wc_timezone_string();

		try {
			$tz_obj = new DateTimeZone( $tz );
		} catch ( Exception $e ) {
			$tz_obj = new DateTimeZone( 'UTC' );
		}

		foreach ( $collection->get_all_slots() as $slot ) {
			$dt = ( new DateTimeImmutable( '@' . $slot->start_ts ) )->setTimezone( $tz_obj );

			$records[] = [
				'date'          => $dt->format( 'Y-m-d\TH:i' ),
				'timestamp'     => $slot->start_ts,
				'duration'      => $duration,
				'duration_unit' => $duration_unit,
				'available'     => $slot->capacity_available,
				'scheduled'     => $slot->capacity_booked,
				'staff_id'      => $slot->staff_id,
				'product_id'    => $product_id,
				'product_name'  => $product_name,
			];
		}

		usort( $records, static fn( array $a, array $b ): int => $a['timestamp'] <=> $b['timestamp'] );

		return $records;
	}

	/**
	 * Get the first available slot for a product.
	 *
	 * Simplified method that leverages the Collection's optimized search.
	 * Uses day summaries to skip unavailable days, making it more efficient
	 * than iterating through all slots.
	 *
	 * @since 5.3.8
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $from          Range start timestamp.
	 * @param int                    $to            Range end timestamp.
	 * @param int                    $staff_id      Staff ID (0 = any staff).
	 * @param bool                   $get_past_times Include past times. Default false.
	 * @return int|false First available slot timestamp or false if none found.
	 */
	public static function get_first_available_slot(
		WC_Product_Appointment $appointable_product,
		int $from,
		int $to,
		int $staff_id = 0,
		bool $get_past_times = false
	) {
		$collection = self::get_time_slots_collection(
			$appointable_product,
			$from,
			$to,
			$staff_id ?: null,
			$get_past_times,
			false
		);

		return $collection->get_first_available_slot_timestamp( $staff_id );
	}

	/**
	 * Find the first bookable slot by scanning the range in day chunks (stops at first hit).
	 *
	 * Avoids building slots for the entire product max horizon when the first opening is soon.
	 * Not a cache — each chunk is generated on demand and discarded.
	 *
	 * @since 5.3.9
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $from                Range start timestamp.
	 * @param int                    $to                  Range end timestamp.
	 * @param int                    $staff_id            Staff ID (0 = any staff).
	 * @param bool                   $get_past_times      Include past times.
	 * @param int                    $chunk_days          Days per chunk (default 14).
	 * @return int|false First available slot timestamp or false if none found.
	 */
	public static function find_first_available_slot_chunked(
		WC_Product_Appointment $appointable_product,
		int $from,
		int $to,
		int $staff_id = 0,
		bool $get_past_times = false,
		int $chunk_days = 14
	) {
		list( $from, $to ) = self::resolve_schedule_bounds( $appointable_product, $from, $to );

		if ( $from > $to ) {
			return false;
		}

		$chunk_days    = max( 1, $chunk_days );
		$chunk_seconds = $chunk_days * DAY_IN_SECONDS;
		$cursor        = $from;

		while ( $cursor <= $to ) {
			$chunk_end = min( $cursor + $chunk_seconds - 1, $to );

			$collection = self::get_time_slots_collection(
				$appointable_product,
				$cursor,
				$chunk_end,
				$staff_id ?: null,
				$get_past_times,
				false
			);

			$first_ts = $collection->get_first_available_slot_timestamp( $staff_id );
			if ( $first_ts ) {
				return (int) $first_ts;
			}

			$cursor = $chunk_end + 1;
		}

		return false;
	}

	/**
	 * Track transient keys created during this request for cleanup.
	 *
	 * @var array<string, true>
	 */
	private static array $transient_keys = [];

	/**
	 * Invalidate cached slots for a product.
	 *
	 * Should be called when appointments are created/updated/deleted,
	 * or when availability rules change.
	 *
	 * @param int $product_id Product ID.
	 */
	public static function invalidate( int $product_id ): void {
		// Clear L1 cache entries for this product.
		foreach ( array_keys( self::$l1_cache ) as $key ) {
			if ( str_starts_with( $key, self::TRANSIENT_PREFIX . $product_id . '_' ) ) {
				unset( self::$l1_cache[ $key ] );
			}
		}

		// Delete tracked transients for this product.
		foreach ( array_keys( self::$transient_keys ) as $key ) {
			if ( str_starts_with( $key, self::TRANSIENT_PREFIX . $product_id . '_' ) ) {
				delete_transient( $key );
				unset( self::$transient_keys[ $key ] );
			}
		}

		// Bump the slots cache version so any surviving transients are bypassed.
		self::bump_version();
	}

	/**
	 * Flush only if the post type is relevant to appointments.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function flush_if_relevant( $post_id = 0 ): void {
		if ( $post_id ) {
			$post_type = get_post_type( $post_id );
			if ( $post_type && ! in_array( $post_type, [ 'wc_appointment', 'product', 'wca_resource' ], true ) ) {
				return;
			}
		}
		self::flush();
	}

	/**
	 * Clear all cached slot data (used during testing or full cache flush).
	 */
	public static function flush(): void {
		self::$l1_cache = [];

		// Delete all tracked transients.
		foreach ( array_keys( self::$transient_keys ) as $key ) {
			delete_transient( $key );
		}
		self::$transient_keys = [];

		// Bump the slots cache version so any surviving transients are bypassed.
		self::bump_version();
	}

	/**
	 * Get the current slots cache version.
	 *
	 * Uses the same pattern as WC_Cache_Helper::get_transient_version().
	 *
	 * @return string
	 */
	private static function get_version(): string {
		$version = get_transient( self::TRANSIENT_PREFIX . 'version' );
		if ( false === $version ) {
			$version = (string) time();
			set_transient( self::TRANSIENT_PREFIX . 'version', $version, DAY_IN_SECONDS );
		}
		return $version;
	}

	/**
	 * Whether version has been bumped in this request.
	 *
	 * @var bool
	 */
	private static bool $version_bumped = false;

	/**
	 * Bump the cache version, invalidating all existing transients.
	 * Only bumps once per request to avoid excessive writes.
	 */
	private static function bump_version(): void {
		if ( self::$version_bumped ) {
			return;
		}
		self::$version_bumped = true;
		set_transient( self::TRANSIENT_PREFIX . 'version', (string) time(), DAY_IN_SECONDS );
	}

	/**
	 * Generate slots for a single staff member (or no staff).
	 *
	 * Uses the unified engine with automatic data-source selection
	 * (index vs dynamic) via the Data Normalizer.
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $start_ts       Range start timestamp.
	 * @param int                    $end_ts         Range end timestamp.
	 * @param int                    $staff_id       Staff ID (0 = no staff).
	 * @param bool                   $get_past_times Include past times.
	 * @param bool                   $skip_pricing   Skip inline pricing.
	 * @param bool                   $collect_diagnostics Collect engine diagnostics.
	 * @param bool                   $force_dynamic  Skip index (e.g. after empty multi-staff index batch).
	 * @return array{slots: WC_Appointment_Slot[], engine: string, meta: array<string, mixed>}
	 */
	private static function generate_single(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		int $staff_id,
		bool $get_past_times,
		bool $skip_pricing = false,
		bool $collect_diagnostics = false,
		bool $force_dynamic = false
	): array {
		$product_id = (int) $appointable_product->get_id();
		$use_index  = $force_dynamic ? false : self::should_use_index( $end_ts, $product_id, $start_ts );
		$engine_obj = new WC_Appointment_Slots_Engine();
		$slots      = $engine_obj->generate( $appointable_product, $start_ts, $end_ts, $staff_id ?: null, $get_past_times, $use_index, $skip_pricing, $collect_diagnostics );
		$diagnostics = $collect_diagnostics ? $engine_obj->get_last_diagnostics() : null;

		// Safety net: incomplete index can return zero slots while dynamic is correct.
		if ( $use_index && empty( $slots ) ) {
			$fallback_engine = new WC_Appointment_Slots_Engine();
			$dynamic_slots   = $fallback_engine->generate( $appointable_product, $start_ts, $end_ts, $staff_id ?: null, $get_past_times, false, $skip_pricing, $collect_diagnostics );
			if ( ! empty( $dynamic_slots ) ) {
				$slots       = $dynamic_slots;
				$engine_obj  = $fallback_engine;
				$use_index   = false;
				$diagnostics = $collect_diagnostics ? $fallback_engine->get_last_diagnostics() : null;
				if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
					WC_Appointments_Cache_Availability::mark_index_unusable_for_product( $product_id );
				}
			} elseif ( $collect_diagnostics && is_array( $diagnostics ) ) {
				$fallback_diag = $fallback_engine->get_last_diagnostics();
				if ( is_array( $fallback_diag ) ) {
					$reason_counts = $diagnostics['reason_counts'];
					foreach ( $fallback_diag['reason_counts'] as $code => $count ) {
						$reason_counts[ $code ] = ( $reason_counts[ $code ] ?? 0 ) + (int) $count;
					}
					$slots_generated = (int) $diagnostics['slots_generated'] + (int) $fallback_diag['slots_generated'];
					$slots_bookable  = (int) $diagnostics['slots_bookable'] + (int) $fallback_diag['slots_bookable'];
					$days_scanned    = (int) $diagnostics['days_scanned'] + (int) $fallback_diag['days_scanned'];
					$diagnostics     = [
						'days_scanned'    => $days_scanned,
						'slots_generated' => $slots_generated,
						'slots_bookable'  => $slots_bookable,
						'reason_counts'   => $reason_counts,
						'primary_reason'  => WC_Appointment_Slots_Engine::primary_reason_from_summary(
							$slots_generated,
							$slots_bookable,
							$reason_counts,
							$days_scanned
						),
					];
				}
			}
		}

		if ( $use_index && ! empty( $slots ) && class_exists( 'WC_Appointments_Cache_Availability' ) ) {
			WC_Appointments_Cache_Availability::clear_index_skip_for_product( $product_id );
		}

		return [
			'slots'       => $slots,
			'engine'      => $engine_obj->get_source(),
			'meta'        => [
				'query_count'   => $engine_obj->get_query_count(),
				'query_time_ms' => $engine_obj->get_query_time_ms(),
				'data_engine'   => $engine_obj->get_data_engine_code(),
			],
			'diagnostics' => $diagnostics,
		];
	}

	/**
	 * Generate slots for the admin product-config probe (storefront index/staff parity).
	 *
	 * When $chunk_horizon is true, $end_ts is the booking-horizon cap and the range is
	 * scanned in growing chunks (14d, then up to 60d) until slots exist or the cap is reached.
	 *
	 * @return array{slots: WC_Appointment_Slot[], diagnostics: array<string, mixed>|null}
	 */
	public static function probe_for_config_check(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		bool $get_past_times = true,
		bool $chunk_horizon = false
	): array {
		if ( $chunk_horizon ) {
			if ( $start_ts > $end_ts ) {
				return [
					'slots'       => [],
					'diagnostics' => null,
				];
			}

			$cursor     = $start_ts;
			$max_end_ts = $end_ts;
			$chunk_days = 14;
			$last       = [
				'slots'       => [],
				'diagnostics' => null,
			];

			while ( $cursor <= $max_end_ts ) {
				$chunk_end = min( $cursor + $chunk_days * DAY_IN_SECONDS, $max_end_ts );
				$last      = self::probe_for_config_check( $appointable_product, $cursor, $chunk_end, $get_past_times, false );
				$reason    = is_array( $last['diagnostics'] ?? null ) ? (string) ( $last['diagnostics']['primary_reason'] ?? '' ) : '';

				if ( ! empty( $last['slots'] )
					|| in_array( $reason, [ 'slot_count_zero', 'span_duration_mismatch', 'skip_span_guard' ], true )
					|| $chunk_end >= $max_end_ts ) {
					return $last;
				}

				$cursor     = $chunk_end + DAY_IN_SECONDS;
				$chunk_days = min( $chunk_days * 2, 60 );
			}

			return $last;
		}

		$skip_pricing = true;

		if ( ! $appointable_product->has_staff() ) {
			$result = self::generate_single( $appointable_product, $start_ts, $end_ts, 0, $get_past_times, $skip_pricing, true );

			return [
				'slots'       => $result['slots'],
				'diagnostics' => $result['diagnostics'] ?? null,
			];
		}

		$engine      = 'dynamic';
		$meta        = [];
		$slots       = self::generate_multi_staff( $appointable_product, $start_ts, $end_ts, $get_past_times, $engine, $meta, $skip_pricing );
		$diagnostics = null;

		if ( empty( $slots ) ) {
			$staff_ids = array_map( 'intval', (array) $appointable_product->get_staff_ids() );
			$staff_ids = array_values( array_filter( $staff_ids ) );
			$probe_id  = $staff_ids[0] ?? 0;
			$result    = self::generate_single( $appointable_product, $start_ts, $end_ts, $probe_id, $get_past_times, $skip_pricing, true );
			$diagnostics = $result['diagnostics'] ?? null;
		}

		return [
			'slots'       => $slots,
			'diagnostics' => $diagnostics,
		];
	}


	/**
	 * Generate slots for all staff members and merge.
	 *
	 * For "customer" assignment: union of all staff slots (customer picks).
	 * For "all" assignment: intersection of all staff slots (all must be free).
	 * For "automatic" assignment: union (system picks least-busy).
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param int                    $start_ts       Range start.
	 * @param int                    $end_ts         Range end.
	 * @param bool                   $get_past_times Include past times.
	 * @param string                 &$engine        Engine name (output).
	 * @param array<string, mixed>   &$meta          Meta data (output).
	 * @param bool                   $skip_pricing   Skip inline pricing.
	 * @param int[]|null             $staff_ids      Optional staff subset; null = all product staff.
	 * @return WC_Appointment_Slot[]
	 */
	private static function generate_multi_staff(
		WC_Product_Appointment $appointable_product,
		int $start_ts,
		int $end_ts,
		bool $get_past_times,
		string &$engine,
		array &$meta,
		bool $skip_pricing = false,
		?array $staff_ids = null
	): array {
		$staff_ids = null !== $staff_ids
			? array_values( array_unique( array_filter( array_map( 'intval', $staff_ids ) ) ) )
			: array_map( 'intval', (array) $appointable_product->get_staff_ids() );
		if ( [] === $staff_ids ) {
			$staff_ids = array_map( 'intval', (array) $appointable_product->get_staff_ids() );
		}

		if ( empty( $staff_ids ) ) {
			$result = self::generate_single( $appointable_product, $start_ts, $end_ts, 0, $get_past_times, $skip_pricing );
			$engine = $result['engine'] ?? 'dynamic';
			$meta   = $result['meta'] ?? [];
			return $result['slots'];
		}

		$use_index     = self::should_use_index( $end_ts, (int) $appointable_product->get_id(), $start_ts );
		$engine_obj    = new WC_Appointment_Slots_Engine();
		$batch         = $engine_obj->generate_multi_staff_time_slots( $appointable_product, $start_ts, $end_ts, $staff_ids, $get_past_times, $use_index, $skip_pricing );
		$force_dynamic = false;

		if ( null !== $batch ) {
			$engine       = $batch['source'];
			$meta         = [
				'query_count'   => $batch['query_count'],
				'query_time_ms' => round( $batch['query_time_ms'], 2 ),
				'staff_count'   => count( $staff_ids ),
				'data_engine'   => (int) ( $batch['data_engine'] ?? $engine_obj->get_data_engine_code() ),
			];
			$is_all_staff = $appointable_product->is_staff_assignment_type( 'all' );
			$merged       = $is_all_staff
				? self::merge_intersection( $batch['slots_by_staff'], $appointable_product )
				: self::merge_union( $batch['slots_by_staff'] );
			if ( ! empty( $merged ) ) {
				return $merged;
			}
			// Empty index batch: skip re-probing index per staff (was 2× cost).
			$force_dynamic = true;
			if ( class_exists( 'WC_Appointments_Cache_Availability' ) ) {
				WC_Appointments_Cache_Availability::mark_index_unusable_for_product( (int) $appointable_product->get_id() );
			}
		}

		// Dynamic path: no batch, run per staff.
		$all_staff_slots = [];
		$total_queries   = 0;
		$total_time      = 0.0;
		$used_engine     = 'dynamic';
		$data_engine     = 2;

		foreach ( $staff_ids as $sid ) {
			$result = self::generate_single( $appointable_product, $start_ts, $end_ts, (int) $sid, $get_past_times, $skip_pricing, false, $force_dynamic );
			$all_staff_slots[ (int) $sid ] = $result['slots'];
			$used_engine                   = $result['engine'] ?? 'dynamic';
			$data_engine                   = (int) ( $result['meta']['data_engine'] ?? 2 );
			$total_queries                += (int) ( $result['meta']['query_count'] ?? 0 );
			$total_time                   += (float) ( $result['meta']['query_time_ms'] ?? 0.0 );
		}

		$engine = $used_engine;
		$meta   = [
			'query_count'   => $total_queries,
			'query_time_ms' => round( $total_time, 2 ),
			'staff_count'   => count( $staff_ids ),
			'data_engine'   => $data_engine,
		];

		$is_all_staff = $appointable_product->is_staff_assignment_type( 'all' );
		if ( $is_all_staff ) {
			return self::merge_intersection( $all_staff_slots, $appointable_product );
		}
		return self::merge_union( $all_staff_slots );
	}

	/**
	 * Merge slots across staff: union mode.
	 *
	 * All slots from all staff are included. Each slot retains its staff_id.
	 *
	 * @param array<int, WC_Appointment_Slot[]> $staff_slots Per-staff slot arrays.
	 * @return WC_Appointment_Slot[]
	 */
	private static function merge_union( array $staff_slots ): array {
		$merged = [];

		// Randomize staff order so automatic assignment doesn't always pick
		// the same staff member. Each request gets a different staff ordering,
		// and when slots share the same start_ts the staff whose slots were
		// added first will appear first — the cart manager picks the first
		// available, achieving fair distribution.
		$keys = array_keys( $staff_slots );
		shuffle( $keys );

		foreach ( $keys as $staff_id ) {
			foreach ( $staff_slots[ $staff_id ] as $slot ) {
				$merged[] = $slot;
			}
		}

		// Sort by start timestamp, preserving insertion order for same-ts slots
		// (stable sort via spaceship + original index tiebreak).
		$indexed = [];
		foreach ( $merged as $i => $slot ) {
			$indexed[] = [ $i, $slot ];
		}
		usort(
             $indexed,
            static fn( array $a, array $b ): int =>
			$a[1]->start_ts <=> $b[1]->start_ts ?: $a[0] <=> $b[0]
		);
		$merged = array_map( static fn( array $pair ) => $pair[1], $indexed );

		return $merged;
	}

	/**
	 * Merge slots across staff: intersection mode ("all staff must be free").
	 *
	 * Only includes time slots where ALL staff have availability.
	 * Capacity = min across staff for each time.
	 *
	 * @param array<int, WC_Appointment_Slot[]> $staff_slots Per-staff slot arrays.
	 * @param WC_Product_Appointment            $appointable_product Product.
	 * @return WC_Appointment_Slot[]
	 */
	private static function merge_intersection( array $staff_slots, WC_Product_Appointment $appointable_product ): array {
		if ( empty( $staff_slots ) ) {
			return [];
		}

		$staff_ids  = array_keys( $staff_slots );
		$num_staff  = count( $staff_ids );

		// Index slots by start_ts per staff for fast lookup.
		$indexed = [];
		foreach ( $staff_slots as $sid => $slots ) {
			foreach ( $slots as $slot ) {
				$indexed[ $sid ][ $slot->start_ts ] = $slot;
			}
		}

		// Use first staff's slots as the base set.
		$first_staff_id = $staff_ids[0];
		$base_slots     = $indexed[ $first_staff_id ] ?? [];
		$merged         = [];

		foreach ( $base_slots as $ts => $base_slot ) {
			$all_available = true;
			$min_total     = $base_slot->capacity_total;
			$min_available = $base_slot->capacity_available;
			$min_price     = $base_slot->price_raw;

			for ( $i = 1; $i < $num_staff; $i++ ) {
				$other_sid = $staff_ids[ $i ];
				if ( ! isset( $indexed[ $other_sid ][ $ts ] ) ) {
					$all_available = false;
					break;
				}

				$other_slot    = $indexed[ $other_sid ][ $ts ];
				$min_total     = min( $min_total, $other_slot->capacity_total );
				$min_available = min( $min_available, $other_slot->capacity_available );

				// Propagate lowest discounted price across staff.
				if ( null !== $other_slot->price_raw ) {
					$min_price = ( null === $min_price ) ? $other_slot->price_raw : min( $min_price, $other_slot->price_raw );
				}
			}

			if ( ! $all_available ) {
				continue;
			}

			$cap_total  = max( 0, $min_total );
			$cap_booked = max( 0, $cap_total - max( 0, $min_available ) );
			$merged[]  = new WC_Appointment_Slot(
				$base_slot->start_ts,
				$base_slot->end_ts,
				$base_slot->duration_minutes,
				0,
				$cap_total,
				$cap_booked,
				max( 0, min( $cap_total, $min_available ) ),
				$min_available > 0,
				$min_price
			);
		}

		// Sort by start timestamp.
		usort( $merged, static fn( WC_Appointment_Slot $a, WC_Appointment_Slot $b ): int => $a->start_ts <=> $b->start_ts );

		return $merged;
	}

	/**
	 * Check if the availability index is available and the given end timestamp
	 * falls within the cache horizon.
	 *
	 * Public entry point so external consumers can query index readiness
	 * without duplicating the check logic.
	 *
	 * @since 5.3.0
	 *
	 * @param int $end_ts End timestamp of requested range.
	 * @return bool
	 */
	public static function is_index_available( int $end_ts ): bool {
		return self::should_use_index( $end_ts );
	}

	/**
	 * Determine if the Index Engine should be used.
	 *
	 * @param int $end_ts     End timestamp of requested range.
	 * @param int $product_id Product ID (optional, for readiness check).
	 * @param int $start_ts   Range start timestamp (optional, for readiness check).
	 * @return bool
	 */
	private static function should_use_index( int $end_ts, int $product_id = 0, int $start_ts = 0 ): bool {
		if ( ! class_exists( 'WC_Appointments_Cache_Availability' ) || ! WC_Appointments_Cache_Availability::is_index_enabled() ) {
			$use = false;
		} else {
			$horizon_months = function_exists( 'wc_appointments_get_cache_horizon_months' )
				? wc_appointments_get_cache_horizon_months()
				: 3;
			if ( $end_ts > strtotime( '+' . $horizon_months . ' months UTC' ) ) {
				$use = false;
			} elseif ( $product_id > 0 && WC_Appointments_Cache_Availability::should_skip_index_for_product( $product_id ) ) {
				$use = false;
			} elseif ( $product_id <= 0 || $start_ts <= 0 ) {
				$use = true;
			} else {
				$staff_ids = [];
				if ( function_exists( 'get_wc_product_appointment' ) ) {
					$product = get_wc_product_appointment( $product_id );
					if ( $product && is_a( $product, 'WC_Product_Appointment' ) && $product->has_staff() ) {
						$staff_ids = array_map( 'intval', (array) $product->get_staff_ids() );
					}
				}
				$use = WC_Appointments_Cache_Availability::is_index_ready_for_slots( $product_id, $start_ts, $end_ts, $staff_ids );
			}
		}
		return ! empty( $use );
	}

	/**
	 * Build a cache key for slot data.
	 *
	 * @param int         $product_id Product ID.
	 * @param string      $start      Start date.
	 * @param string      $end        End date.
	 * @param int|string  $staff_id   Staff ID or multi-staff cache token.
	 * @return string
	 */
	public static function build_cache_key( int $product_id, string $start, string $end, $staff_id ): string {
		$version = self::get_version();
		return self::TRANSIENT_PREFIX . "{$product_id}_{$start}_{$end}_s{$staff_id}_v{$version}";
	}

	/**
	 * Location for occupancy scope (unstaffed product seats and resource venue). Fixed products use the assigned location when none is posted.
	 *
	 * @param WC_Product_Appointment $product     Product.
	 * @param int                    $location_id Requested location (0 = none).
	 * @return int
	 */
	private static function resolve_occupancy_location_id( WC_Product_Appointment $product, int $location_id ): int {
		if ( ! $product->has_locations() || ! class_exists( 'WC_Appointments_Location' ) ) {
			return 0;
		}
		if ( $location_id > 0 ) {
			return WC_Appointments_Location::authorize_location_id( $product, $location_id ) ? $location_id : 0;
		}
		if ( WC_Appointments_Location::is_fixed_mode( $product->get_location_mode() ) ) {
			$ids = WC_Appointments_Location::get_allowed_location_ids( $product );
			return (int) ( $ids[0] ?? 0 );
		}

		return WC_Appointments_Location::sole_allowed_location_id( $product );
	}

	// =========================================================================
	// UNIFIED SLOTS STANDARDIZATION — Display Field Projection
	// =========================================================================

	/**
	 * Resolve the display timezone for a product.
	 *
	 * Day/month products always use business timezone (no display shift).
	 * Products with timezone conversion disabled also use business timezone.
	 *
	 * @since 5.3.5
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param string                 $requested_tz   Requested display timezone (IANA format).
	 * @param string                 $business_tz    Business timezone (IANA format).
	 * @return string Resolved display timezone.
	 */
	private static function resolve_display_timezone(
		WC_Product_Appointment $appointable_product,
		string $requested_tz,
		string $business_tz
	): string {
		// Day/month/night products: always use business timezone.
		$duration_unit = $appointable_product->get_duration_unit();
		if ( in_array( $duration_unit, [ 'day', 'month', 'night' ], true ) ) {
			return $business_tz;
		}

		// No timezone conversion on product.
		if ( ! $appointable_product->has_timezones() ) {
			return $business_tz;
		}

		// Validate requested timezone.
		if ( empty( $requested_tz ) ) {
			return $business_tz;
		}

		try {
			$normalized = function_exists( 'wc_appointments_normalize_timezone' )
				? wc_appointments_normalize_timezone( $requested_tz )
				: $requested_tz;
			new DateTimeZone( $normalized );
			return $normalized;
		} catch ( Exception $e ) {
			return $business_tz;
		}
	}

	/**
	 * Project display fields onto all slots.
	 *
	 * @since 5.3.5
	 *
	 * @param WC_Appointment_Slot[] $slots             Slots to project.
	 * @param string                $business_tz_string Business timezone string.
	 * @param string                $display_tz_string  Display timezone string.
	 * @param string                $duration_unit      Product duration unit (minute|hour|day|month).
	 * @param string                $level              Response level: summary|days skip heavy wp_date per slot.
	 * @return WC_Appointment_Slot[] Slots with display fields projected.
	 */
	private static function project_all_display_fields(
		array $slots,
		string $business_tz_string,
		string $display_tz_string,
		string $duration_unit = 'day',
		string $level = 'days'
	): array {
		if ( empty( $slots ) ) {
			return $slots;
		}

		try {
			$business_tz = new DateTimeZone( $business_tz_string );
			$display_tz  = new DateTimeZone( $display_tz_string );
		} catch ( Exception $e ) {
			// Fallback to UTC if timezone creation fails.
			$business_tz = new DateTimeZone( 'UTC' );
			$display_tz  = new DateTimeZone( 'UTC' );
		}

		// Calendar / day-summary requests do not need localized date/time strings on every slot.
		$include_i18n = ! in_array( $level, [ 'summary', 'days' ], true );

		foreach ( $slots as $slot ) {
			$slot->project_display_fields( $business_tz, $display_tz, $duration_unit, $include_i18n );
		}

		return $slots;
	}
}
