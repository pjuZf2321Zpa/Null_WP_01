<?php
/**
 * Slots Performance Logger — toggleable timing instrumentation.
 *
 * Enable explicitly via wp-config.php: define( 'WCA_SLOTS_PERF_LOG', true );
 * Logs to PHP error_log with structured timing data for each phase
 * of the slots pipeline. Designed for zero overhead when disabled.
 *
 * Usage:
 *   WC_Appointment_Slots_Perf_Logger::start( 'generate_single' );
 *   // ... work ...
 *   WC_Appointment_Slots_Perf_Logger::stop( 'generate_single', [ 'staff_id' => 5, 'slots' => 200 ] );
 *
 * Output (error_log):
 *   [WCA Slots Perf] generate_single: 12.3ms | staff_id=5 slots=200
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Perf_Logger — zero-overhead toggleable perf logger.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Perf_Logger {

	/**
	 * Whether logging is enabled. Cached after first check.
	 *
	 * @var bool|null
	 */
	private static ?bool $enabled = null;

	/**
	 * Active timers: label => start microtime.
	 *
	 * @var array<string, float>
	 */
	private static array $timers = [];

	/**
	 * Accumulated log entries for the current request (optional summary).
	 *
	 * @var array<string, array{ms: float, meta: array<string, mixed>}>
	 */
	private static array $entries = [];

	/**
	 * Check if perf logging is enabled.
	 *
	 * @return bool
	 */
	public static function is_enabled(): bool {
		if ( null === self::$enabled ) {
			self::$enabled = defined( 'WCA_SLOTS_PERF_LOG' ) && (bool) constant( 'WCA_SLOTS_PERF_LOG' );
		}
		return self::$enabled;
	}

	/**
	 * Start a named timer.
	 *
	 * @param string $label Timer label (e.g., 'generate_single', 'normalize_index').
	 */
	public static function start( string $label ): void {
		if ( ! self::is_enabled() ) {
			return;
		}
		self::$timers[ $label ] = microtime( true );
	}

	/**
	 * Stop a named timer and log the elapsed time.
	 *
	 * @param string               $label Timer label matching a prior start() call.
	 * @param array<string, mixed> $meta  Optional key-value pairs to include in the log line.
	 * @return float Elapsed milliseconds (0 if not enabled or timer not found).
	 */
	public static function stop( string $label, array $meta = [] ): float {
		if ( ! self::is_enabled() ) {
			return 0.0;
		}

		if ( ! isset( self::$timers[ $label ] ) ) {
			return 0.0;
		}

		$elapsed_ms = round( ( microtime( true ) - self::$timers[ $label ] ) * 1000, 2 );
		unset( self::$timers[ $label ] );

		// Build meta string.
		$meta_str = '';
		if ( ! empty( $meta ) ) {
			$parts = [];
			foreach ( $meta as $k => $v ) {
				$parts[] = $k . '=' . ( is_array( $v ) ? wp_json_encode( $v ) : $v );
			}
			$meta_str = ' | ' . implode( ' ', $parts );
		}

		// Log to error_log.
		error_log( sprintf( '[WCA Slots Perf] %s: %.2fms%s', $label, $elapsed_ms, $meta_str ) );

		// Store for summary.
		self::$entries[ $label ] = [
			'ms'   => $elapsed_ms,
			'meta' => $meta,
		];

		return $elapsed_ms;
	}

	/**
	 * Log a one-shot message (no timer).
	 *
	 * @param string               $label Message label.
	 * @param array<string, mixed> $meta  Key-value pairs.
	 */
	public static function log( string $label, array $meta = [] ): void {
		if ( ! self::is_enabled() ) {
			return;
		}

		$meta_str = '';
		if ( ! empty( $meta ) ) {
			$parts = [];
			foreach ( $meta as $k => $v ) {
				$parts[] = $k . '=' . ( is_array( $v ) ? wp_json_encode( $v ) : $v );
			}
			$meta_str = ' | ' . implode( ' ', $parts );
		}

		error_log( sprintf( '[WCA Slots Perf] %s%s', $label, $meta_str ) );
	}

	/**
	 * Get all accumulated entries for the current request.
	 *
	 * @return array<string, array{ms: float, meta: array<string, mixed>}>
	 */
	public static function get_entries(): array {
		return self::$entries;
	}

	/**
	 * Reset all timers and entries (useful in tests).
	 */
	public static function reset(): void {
		self::$timers  = [];
		self::$entries = [];
	}
}
