<?php
/**
 * Legacy Filter Bridge — fires deprecated filters for backward compatibility.
 *
 * When the new Slots Provider generates slots, this bridge fires the same
 * legacy filters that existed in the old pipeline. This ensures third-party
 * code listening on those hooks continues to work during migration.
 *
 * These filters will be removed once all third-party consumers migrate.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Legacy_Filter_Bridge — deprecated filter compatibility.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Legacy_Filter_Bridge {

	/**
	 * Register filters to intercept legacy methods and redirect to new Slots Provider.
	 *
	 * @since 5.3.0
	 */
	public static function register_hooks(): void {
		// NOTE: The filter interceptor is intentionally disabled.
		// The old approach hijacked legacy Controller results mid-flight via
		// wc_appointments_product_get_available_slots, replacing them with
		// Dynamic Engine results — creating a circular shadow pipeline.
		//
		// The correct approach (implemented in 5.3.0) is:
		// 1. Frontend AJAX handlers call Provider directly as primary path.
		// 2. Provider routes to Dynamic Engine (or Index Engine when available).
		// 3. Real legacy Controller is the fallback, called only when Provider fails.
		// 4. apply_available_slots_filter() and apply_time_slots_filter() fire
		//    deprecated filters WITHIN the Provider pipeline for 3rd-party compat.
	}

	/**
	 * Apply the legacy `wc_appointments_product_get_available_slots` filter.
	 *
	 * This filter was applied in WC_Appointment_Slots_Provider::get_slots().
	 * Third-party code may modify the returned timestamps array.
	 *
	 * @param WC_Appointment_Slot[]  $slots     Slot objects from the new engine.
	 * @param WC_Product_Appointment $product   The product.
	 * @param array<int, int>        $intervals Product intervals [duration, step].
	 * @param int                    $staff_id  Staff ID.
	 * @return WC_Appointment_Slot[] Possibly modified slot array.
	 */
	public static function apply_available_slots_filter(
		array $slots,
		WC_Product_Appointment $product,
		array $intervals,
		int $staff_id
	): array {
		if ( ! has_filter( 'wc_appointments_product_get_available_slots' ) ) {
			return $slots;
		}

		// Convert new slot objects → legacy timestamp array for the filter.
		$legacy_timestamps = array_map(
			static fn( $slot ): int => (int) $slot->start_ts,
			$slots
		);

		// Also build the legacy "all raw slots" array (same as $slots param in old code).
		$raw_timestamps = $legacy_timestamps;

		/**
		 * Legacy filter: wc_appointments_product_get_available_slots
		 *
		 * @since 5.3.0 Fired from Slots Provider pipeline.
		 *
		 * @param array                  $available_times Timestamps of available slots.
		 * @param WC_Product_Appointment $product         Product.
		 * @param array                  $raw_slots       All raw slot timestamps.
		 * @param array                  $intervals       Product intervals [duration, step].
		 * @param int                    $staff_id        Staff ID.
		 */
		$filtered = apply_filters(
			'wc_appointments_product_get_available_slots',
			$legacy_timestamps,
			$product,
			$raw_timestamps,
			$intervals,
			$staff_id
		);

		if ( ! is_array( $filtered ) || $filtered === $legacy_timestamps ) {
			return $slots;
		}

		// If the filter modified the timestamps, reconcile back to slot objects.
		// Removed timestamps → remove slots. Added timestamps are ignored (can't create slots).
		$filtered_set = array_flip( $filtered );
		$result       = [];

		foreach ( $slots as $slot ) {
			if ( isset( $filtered_set[ $slot->start_ts ] ) ) {
				$result[] = $slot;
			}
		}

		return $result;
	}

	/**
	 * Apply the legacy `woocommerce_appointments_time_slots` filter.
	 *
	 * This filter was applied in WC_Appointment_Slots_Provider::get_slots().
	 * Third-party code may modify the available_slots associative array.
	 *
	 * @param WC_Appointment_Slot[]  $slots    Slot objects.
	 * @param WC_Product_Appointment $product  Product.
	 * @param int                    $staff_id Staff ID.
	 * @param int                    $from     Range start timestamp.
	 * @param int                    $to       Range end timestamp.
	 * @return WC_Appointment_Slot[] Possibly modified slot array.
	 */
	public static function apply_time_slots_filter(
		array $slots,
		WC_Product_Appointment $product,
		int $staff_id,
		int $from,
		int $to
	): array {
		if ( ! has_filter( 'woocommerce_appointments_time_slots' ) ) {
			return $slots;
		}

		// Build legacy available_slots format: timestamp => [ 'available' => qty, 'scheduled' => [...] ]
		$legacy_format = [];
		foreach ( $slots as $slot ) {
			$legacy_format[ $slot->start_ts ] = [
				'available' => $slot->capacity_available,
				'scheduled' => [],
				'staff'     => [ $slot->staff_id => $slot->capacity_available ],
			];
		}

		/**
		 * Legacy filter: woocommerce_appointments_time_slots
		 *
		 * @since 5.3.0 Fired from Slots Provider pipeline.
		 *
		 * @param array                  $available_slots Slot data keyed by timestamp.
		 * @param array                  $raw_slots       Raw slot timestamps.
		 * @param WC_Product_Appointment $product         Product.
		 * @param int                    $staff_id        Staff ID.
		 * @param int                    $from            Range start.
		 * @param int                    $to              Range end.
		 */
		$filtered = apply_filters(
			'woocommerce_appointments_time_slots',
			$legacy_format,
			array_map( static fn( $s ): int => (int) $s->start_ts, $slots ),
			$product,
			$staff_id,
			$from,
			$to
		);

		if ( ! is_array( $filtered ) || $filtered === $legacy_format ) {
			return $slots;
		}

		// Reconcile: only keep slots whose timestamps remain in the filtered result.
		$filtered_keys = array_flip( array_keys( $filtered ) );
		$result        = [];

		foreach ( $slots as $slot ) {
			if ( isset( $filtered_keys[ $slot->start_ts ] ) ) {
				// If capacity was modified by the filter, create updated slot.
				$filtered_entry = $filtered[ $slot->start_ts ];
				$new_available  = isset( $filtered_entry['available'] ) ? (int) $filtered_entry['available'] : $slot->capacity_available;

				if ( $new_available !== $slot->capacity_available ) {
					$new_booked = max( 0, $slot->capacity_total - $new_available );
					if ( $slot instanceof WC_Appointment_Slot ) {
						$result[] = new WC_Appointment_Slot(
							$slot->start_ts,
							$slot->end_ts,
							$slot->duration_minutes,
							$slot->staff_id,
							$slot->capacity_total,
							$new_booked,
							$new_available,
							$new_available > 0,
							$slot->price_raw,
							$slot->price_display
						);
					} else {
						$slot->capacity_booked    = $new_booked;
						$slot->capacity_available = $new_available;
						$slot->available          = $new_available > 0;
						$slot->status             = $new_available > 0 ? 'available' : 'fully_booked';
						$slot->bookable           = $new_available > 0;
						$result[]                 = $slot;
					}
				} else {
					$result[] = $slot;
				}
			}
		}

		return $result;
	}

	/**
	 * Apply the new collection-level filter (recommended for new integrations).
	 *
	 * @param WC_Appointment_Slots_Collection $collection Collection.
	 * @param WC_Product_Appointment          $product    Product.
	 * @return WC_Appointment_Slots_Collection
	 */
	public static function apply_collection_filter(
		WC_Appointment_Slots_Collection $collection,
		WC_Product_Appointment $product
	): WC_Appointment_Slots_Collection {
		/**
		 * New filter: wc_appointments_slots_collection
		 *
		 * @since 5.3.0
		 *
		 * @param WC_Appointment_Slots_Collection $collection Full slot collection.
		 * @param WC_Product_Appointment          $product    Product.
		 */
		return apply_filters( 'wc_appointments_slots_collection', $collection, $product );
	}
}
