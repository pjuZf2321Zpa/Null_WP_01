<?php
/**
 * Day-level aggregate value object.
 *
 * Derived from slots — never computed independently.
 * Single-pass: Collection groups slots by day, then calls from_slots().
 *
 * UNIFIED SLOTS STANDARDIZATION: Day summaries now include display-centric
 * fields pre-calculated for rendering without post-processing.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Day_Summary — day aggregate derived from slot data.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Day_Summary implements JsonSerializable {

	/**
	 * Date string 'YYYY-MM-DD' (business timezone).
	 *
	 * @var string
	 */
	public string $date;

	/**
	 * Day of week 0–6 (0=Sunday matching PHP date('w')).
	 *
	 * @var int
	 */
	public int $day_of_week;

	/**
	 * Status: available|filling_fast|fully_booked|unavailable.
	 *
	 * @var string
	 */
	public string $status;

	/**
	 * Reason for unavailability: rule|past|min_date|max_date|no_staff|null.
	 *
	 * @var string|null
	 */
	public ?string $unavailable_reason;

	/**
	 * Total number of slots on this day.
	 *
	 * @var int
	 */
	public int $slots_count;

	/**
	 * Number of available slots.
	 *
	 * @var int
	 */
	public int $available_slots;

	/**
	 * Number of fully booked slots.
	 *
	 * @var int
	 */
	public int $booked_slots;

	/**
	 * Occupancy percentage 0–100.
	 *
	 * @var int
	 */
	public int $occupancy_pct;

	/**
	 * First slot display time e.g. '09:00'.
	 *
	 * @var string|null
	 */
	public ?string $first_slot;

	/**
	 * Last slot display time e.g. '17:00'.
	 *
	 * @var string|null
	 */
	public ?string $last_slot;

	/**
	 * Per-staff capacity breakdown.
	 * Keys are staff IDs (string), '0' = combined "no preference".
	 *
	 * @var array<string, array{available: int, booked: int, occupancy_pct: int, status: string}>
	 */
	public array $per_staff;

	/**
	 * Minimum raw price across available slots on this day.
	 *
	 * @var float|null
	 */
	public ?float $min_price;

	/**
	 * Maximum raw price across available slots on this day.
	 *
	 * @var float|null
	 */
	public ?float $max_price;

	/**
	 * Formatted display price for the minimum price.
	 *
	 * @var string|null
	 */
	public ?string $min_price_display;

	/**
	 * Formatted display price for the maximum price.
	 *
	 * @var string|null
	 */
	public ?string $max_price_display;

	// =========================================================================
	// DISPLAY FIELDS (Unified Slots Standardization)
	// =========================================================================

	/**
	 * Display day in 'YYYY-MM-DD' format (customer timezone).
	 *
	 * @var string
	 * @since 5.3.5
	 */
	public string $display_day = '';

	/**
	 * Localized formatted date for display (e.g. "Tuesday, April 11").
	 *
	 * @var string
	 * @since 5.3.5
	 */
	public string $display_date_formatted = '';

	/**
	 * Whether the day is selectable (has at least one bookable slot).
	 *
	 * @var bool
	 * @since 5.3.5
	 */
	public bool $selectable = false;

	/**
	 * Private constructor — use static factory methods.
	 *
	 * @param string                                                                                  $date                Date 'YYYY-MM-DD'.
	 * @param int                                                                                     $day_of_week         Day of week 0-6.
	 * @param string                                                                                  $status              Status string.
	 * @param string|null                                                                             $unavailable_reason  Reason for unavailability.
	 * @param int                                                                                     $slots_count         Total slots.
	 * @param int                                                                                     $available_slots     Available slots.
	 * @param int                                                                                     $booked_slots        Booked slots.
	 * @param int                                                                                     $occupancy_pct       Occupancy 0-100.
	 * @param string|null                                                                             $first_slot          First slot time.
	 * @param string|null                                                                             $last_slot           Last slot time.
	 * @param array<string, array{available: int, booked: int, occupancy_pct: int, status: string}>   $per_staff           Per-staff breakdown.
	 * @param float|null                                                                              $min_price           Min raw price.
	 * @param float|null                                                                              $max_price           Max raw price.
	 * @param string|null                                                                             $min_price_display   Formatted min price.
	 * @param string|null                                                                             $max_price_display   Formatted max price.
	 */
	private function __construct(
		string  $date,
		int     $day_of_week,
		string  $status,
		?string $unavailable_reason,
		int     $slots_count,
		int     $available_slots,
		int     $booked_slots,
		int     $occupancy_pct,
		?string $first_slot,
		?string $last_slot,
		array   $per_staff,
		?float  $min_price = null,
		?float  $max_price = null,
		?string $min_price_display = null,
		?string $max_price_display = null
	) {
		$this->date               = $date;
		$this->day_of_week        = $day_of_week;
		$this->status             = $status;
		$this->unavailable_reason = $unavailable_reason;
		$this->slots_count        = $slots_count;
		$this->available_slots    = $available_slots;
		$this->booked_slots       = $booked_slots;
		$this->occupancy_pct      = $occupancy_pct;
		$this->first_slot         = $first_slot;
		$this->last_slot          = $last_slot;
		$this->per_staff          = $per_staff;
		$this->min_price          = $min_price;
		$this->max_price          = $max_price;
		$this->min_price_display  = $min_price_display;
		$this->max_price_display  = $max_price_display;
	}

	/**
	 * Build day summary from an array of WC_Appointment_Slot objects.
	 *
	 * @param string                 $date    Date 'YYYY-MM-DD'.
	 * @param WC_Appointment_Slot[]  $slots   Slots for this day.
	 * @param int                    $min_qty Minimum capacity for a start to count as available. Default 1.
	 * @return self
	 */
	public static function from_slots( string $date, array $slots, int $min_qty = 1 ): self {
		$min_qty = max( 1, $min_qty );
		$day_of_week = (int) date( 'w', strtotime( $date ) );

		if ( empty( $slots ) ) {
			return self::unavailable( $date, 'rule' );
		}

		$slots_count      = 0;
		$available_slots  = 0;
		$booked_slots     = 0;

		// Per-staff accumulators: staff_id => [ 'available' => int, 'booked' => int, 'total' => int, 'slots_available' => int, 'slots_total' => int, 'slots_with_bookings' => int ].
		$staff_accum = [];
		$slot_groups = [];

		$first_ts  = null;
		$last_ts   = null;
		$min_price = null;
		$max_price = null;

		// Accumulators for combined day-level occupancy across all staff.
		$day_total_booked   = 0;
		$day_total_capacity = 0;
		$agg_available           = 0;
		$agg_booked              = 0;
		$agg_total               = 0;
		$agg_slots_available     = 0;
		$agg_slots_total         = 0;
		$agg_slots_with_bookings = 0;

		foreach ( $slots as $slot ) {
			// Track first/last slot timestamps.
			if ( null === $first_ts || $slot->start_ts < $first_ts ) {
				$first_ts = $slot->start_ts;
			}
			if ( null === $last_ts || $slot->start_ts > $last_ts ) {
				$last_ts = $slot->start_ts;
			}

			// Track min/max price across available slots.
			if ( null !== $slot->price_raw && $slot->available ) {
				if ( null === $min_price || $slot->price_raw < $min_price ) {
					$min_price = $slot->price_raw;
				}
				if ( null === $max_price || $slot->price_raw > $max_price ) {
					$max_price = $slot->price_raw;
				}
			}

			// Per-staff accumulation. Cap booked at total so bad upstream data never breaks aggregates.
			$sid = (string) $slot->staff_id;
			if ( ! isset( $staff_accum[ $sid ] ) ) {
				$staff_accum[ $sid ] = [ 'available' => 0, 'booked' => 0, 'total' => 0, 'slots_available' => 0, 'slots_total' => 0, 'slots_with_bookings' => 0, 'min_price' => null, 'max_price' => null ];
			}
			$slot_booked = min( (int) $slot->capacity_booked, (int) $slot->capacity_total );
			$staff_accum[ $sid ]['available'] += $slot->capacity_available;
			$staff_accum[ $sid ]['booked']    += $slot_booked;
			$staff_accum[ $sid ]['total']     += $slot->capacity_total;
			$staff_accum[ $sid ]['slots_total']++;
			if ( null !== $slot->price_raw && $slot->available ) {
				if ( null === $staff_accum[ $sid ]['min_price'] || $slot->price_raw < $staff_accum[ $sid ]['min_price'] ) {
					$staff_accum[ $sid ]['min_price'] = $slot->price_raw;
				}
				if ( null === $staff_accum[ $sid ]['max_price'] || $slot->price_raw > $staff_accum[ $sid ]['max_price'] ) {
					$staff_accum[ $sid ]['max_price'] = $slot->price_raw;
				}
			}
			if ( $slot->available ) {
				$staff_accum[ $sid ]['slots_available']++;
			}
			if ( $slot->capacity_booked > 0 ) {
				$staff_accum[ $sid ]['slots_with_bookings']++;
			}

			$slot_group_key = (string) $slot->start_ts;
			if ( ! isset( $slot_groups[ $slot_group_key ] ) ) {
				$slot_groups[ $slot_group_key ] = [ 'available' => 0, 'booked' => 0, 'total' => 0 ];
			}
			$slot_groups[ $slot_group_key ]['available'] += $slot->capacity_available;
			$slot_groups[ $slot_group_key ]['booked']    += $slot_booked;
			$slot_groups[ $slot_group_key ]['total']     += $slot->capacity_total;
		}

		foreach ( $slot_groups as $slot_group ) {
			$slots_count++;
			$day_total_booked   += $slot_group['booked'];
			$day_total_capacity += $slot_group['total'];
			$agg_available      += $slot_group['available'];
			$agg_booked         += $slot_group['booked'];
			$agg_total          += $slot_group['total'];
			$agg_slots_total++;

			if ( $slot_group['available'] >= $min_qty ) {
				$available_slots++;
				$agg_slots_available++;
			} else {
				$booked_slots++;
			}

			if ( $slot_group['booked'] > 0 ) {
				$agg_slots_with_bookings++;
			}
		}

		// Day occupancy = combined booked / combined total across all staff and all slots.
		$occupancy_pct = $day_total_capacity > 0
			? min( 100, (int) round( $day_total_booked / $day_total_capacity * 100 ) )
			: 0;

		// Derive day status.
		if ( $available_slots <= 0 ) {
			$status = 'fully_booked';
		} elseif ( $occupancy_pct >= 70 ) {
			$status = 'filling_fast';
		} else {
			$status = 'available';
		}

		// Build per_staff arrays with cumulative occupancy (booked/total for that staff).
		$per_staff                 = [];
		$has_zero_staff_entry      = false;
		$has_nonzero_staff_entry   = false;
		foreach ( $staff_accum as $sid => $acc ) {
			if ( '0' === (string) $sid ) {
				$has_zero_staff_entry = true;
			} else {
				$has_nonzero_staff_entry = true;
			}
			$s_total = max( 1, $acc['total'] );
			$s_pct   = min( 100, (int) round( $acc['booked'] / $s_total * 100 ) );
			$per_staff[ $sid ] = [
				'available'            => $acc['available'],
				'booked'               => $acc['booked'],
				'occupancy_pct'        => $s_pct,
				'status'               => WC_Appointment_Slot_Capacity::compute_status( $acc['available'], $s_pct ),
				'slots_available'      => $acc['slots_available'],
				'slots_total'          => $acc['slots_total'],
				'slots_with_bookings'  => $acc['slots_with_bookings'],
				'min_price'            => $acc['min_price'],
				'max_price'            => $acc['max_price'],
			];
		}

		// Build "no preference" aggregate (per_staff['0']) if there are staff-specific entries.
		// Occupancy = combined booked / combined total across all staff.
		if ( $has_nonzero_staff_entry && ! $has_zero_staff_entry ) {
			$agg_total_safe = max( 1, $agg_total );
			$agg_pct        = min( 100, (int) round( $agg_booked / $agg_total_safe * 100 ) );
			$max_staff_slots_available = 0;
			$max_staff_available       = 0;
			foreach ( $staff_accum as $sid_key => $acc ) {
				if ( '0' === (string) $sid_key ) {
					continue;
				}
				$max_staff_slots_available = max( $max_staff_slots_available, (int) $acc['slots_available'] );
				$max_staff_available       = max( $max_staff_available, (int) $acc['available'] );
			}
			$nopref_slots_available = $max_staff_slots_available;
			$nopref_available       = $max_staff_available;
			$nopref_status          = $nopref_slots_available > 0
				? WC_Appointment_Slot_Capacity::compute_status( $nopref_available, $agg_pct )
				: 'unavailable';
			$per_staff['0'] = [
				'available'            => $nopref_available,
				'booked'               => $agg_booked,
				'occupancy_pct'        => $agg_pct,
				'status'               => $nopref_status,
				'slots_available'      => $nopref_slots_available,
				'slots_total'          => $agg_slots_total,
				'slots_with_bookings'  => $agg_slots_with_bookings,
				'min_price'            => $min_price,
				'max_price'            => $max_price,
			];
		}

		// Fake UTC wall H:i (site civil digits). Do not wp_date() - that re-applies the site offset.
		$first_slot = null !== $first_ts ? gmdate( 'H:i', $first_ts ) : null;
		$last_slot  = null !== $last_ts ? gmdate( 'H:i', $last_ts ) : null;

		$day_summary = new self(
			$date,
			$day_of_week,
			$status,
			null,
			$slots_count,
			$available_slots,
			$booked_slots,
			$occupancy_pct,
			$first_slot,
			$last_slot,
			$per_staff,
			$min_price,
			$max_price,
			null,
			null
		);

		// Populate display fields from first slot if available.
		$first_slot_obj = reset( $slots );
		if ( $first_slot_obj && $first_slot_obj instanceof WC_Appointment_Slot ) {
			$day_summary->display_day = $first_slot_obj->display_day ?: $date;
			if ( $first_slot_obj->display_timezone ) {
				try {
					$display_tz = new DateTimeZone( $first_slot_obj->display_timezone );
					$day_summary->display_date_formatted = wp_date(
						'l, ' . wc_appointments_date_format(),
						strtotime( $date ),
						$display_tz
					);
				} catch ( Exception $e ) {
					$day_summary->display_date_formatted = wp_date(
						'l, ' . wc_appointments_date_format(),
						strtotime( $date )
					);
				}
			}
		} else {
			$day_summary->display_day = $date;
			$day_summary->display_date_formatted = wp_date(
				'l, ' . wc_appointments_date_format(),
				strtotime( $date )
			);
		}

		$day_summary->selectable = $available_slots > 0;

		return $day_summary;
	}

	/**
	 * Create an unavailable day summary.
	 *
	 * @param string $date   Date 'YYYY-MM-DD'.
	 * @param string $reason Reason: rule|past|min_date|max_date|no_staff.
	 * @return self
	 */
	public static function unavailable( string $date, string $reason = 'rule' ): self {
		return new self(
			$date,
			(int) date( 'w', strtotime( $date ) ),
			'unavailable',
			$reason,
			0,
			0,
			0,
			0,
			null,
			null,
			[]
		);
	}

	/**
	 * JSON serialization.
	 *
	 * @return array<string, mixed>
	 */
	public function jsonSerialize(): array {
		$data = [
			// Business day data.
			'date'          => $this->date,
			'day_of_week'   => $this->day_of_week,

			// Display day data (Unified Slots Standardization).
			'display_day'            => $this->display_day ?: $this->date,
			'display_date_formatted' => $this->display_date_formatted,

			// Status.
			'status'        => $this->status,
			'selectable'    => $this->selectable,

			// Slots.
			'slots_count'     => $this->slots_count,
			'available_slots' => $this->available_slots,
			'booked_slots'    => $this->booked_slots,
			'occupancy_pct'   => $this->occupancy_pct,
			'first_slot'      => $this->first_slot,
			'last_slot'       => $this->last_slot,

			// Per-staff breakdown.
			'per_staff'     => $this->per_staff,

			// Price.
			'price'         => [
				'min'         => $this->min_price,
				'max'         => $this->max_price,
				'min_display' => $this->min_price_display,
				'max_display' => $this->max_price_display,
			],
		];

		if ( null !== $this->unavailable_reason ) {
			$data['unavailable_reason'] = $this->unavailable_reason;
		}

		return $data;
	}
}
