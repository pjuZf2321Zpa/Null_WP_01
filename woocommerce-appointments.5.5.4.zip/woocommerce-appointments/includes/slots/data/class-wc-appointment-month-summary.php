<?php
/**
 * Month-level aggregate value object.
 *
 * Derived from day summaries — never computed independently.
 * Single-pass: Collection groups days by month, then calls from_days().
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Month_Summary — month aggregate derived from day summaries.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Month_Summary implements JsonSerializable {

	/**
	 * Month string 'YYYY-MM'.
	 *
	 * @var string
	 */
	public string $month;

	/**
	 * Whether this month has any availability.
	 *
	 * @var bool
	 */
	public bool $has_availability;

	/**
	 * Number of available days in this month.
	 *
	 * @var int
	 */
	public int $available_days;

	/**
	 * Total number of days represented.
	 *
	 * @var int
	 */
	public int $total_days;

	/**
	 * First available date 'YYYY-MM-DD' or null.
	 *
	 * @var string|null
	 */
	public ?string $first_available;

	/**
	 * Total number of slots across all days.
	 *
	 * @var int
	 */
	public int $slots_count;

	/**
	 * Total booked slots across all days.
	 *
	 * @var int
	 */
	public int $booked_slots;

	/**
	 * Private constructor — use static factory method.
	 *
	 * @param string      $month           Month 'YYYY-MM'.
	 * @param bool        $has_availability Whether availability exists.
	 * @param int         $available_days  Count of available days.
	 * @param int         $total_days      Total days represented.
	 * @param string|null $first_available First available date.
	 * @param int         $slots_count     Total slots count.
	 * @param int         $booked_slots    Total booked slots.
	 */
	private function __construct(
		string  $month,
		bool    $has_availability,
		int     $available_days,
		int     $total_days,
		?string $first_available,
		int     $slots_count,
		int     $booked_slots
	) {
		$this->month            = $month;
		$this->has_availability = $has_availability;
		$this->available_days   = $available_days;
		$this->total_days       = $total_days;
		$this->first_available  = $first_available;
		$this->slots_count      = $slots_count;
		$this->booked_slots     = $booked_slots;
	}

	/**
	 * Build month summary from an array of WC_Appointment_Day_Summary objects.
	 *
	 * @param string                        $month Month 'YYYY-MM'.
	 * @param WC_Appointment_Day_Summary[]  $days  Day summaries for this month.
	 * @return self
	 */
	public static function from_days( string $month, array $days ): self {
		$total_days      = count( $days );
		$available_days  = 0;
		$first_available = null;
		$slots_count     = 0;
		$booked_slots    = 0;

		foreach ( $days as $day ) {
			$slots_count  += $day->slots_count;
			$booked_slots += $day->booked_slots;

			if ( 'unavailable' !== $day->status && 'fully_booked' !== $day->status ) {
				$available_days++;

				if ( null === $first_available || $day->date < $first_available ) {
					$first_available = $day->date;
				}
			}
		}

		return new self(
			$month,
			$available_days > 0,
			$available_days,
			$total_days,
			$first_available,
			$slots_count,
			$booked_slots
		);
	}

	/**
	 * JSON serialization.
	 *
	 * @return array{has_availability: bool, available_days: int, total_days: int, first_available: string|null, slots_count: int, booked_slots: int}
	 */
	public function jsonSerialize(): array {
		return [
			'has_availability' => $this->has_availability,
			'available_days'   => $this->available_days,
			'total_days'       => $this->total_days,
			'first_available'  => $this->first_available,
			'slots_count'      => $this->slots_count,
			'booked_slots'     => $this->booked_slots,
		];
	}
}
