<?php
/**
 * Capacity breakdown value object with per_staff aggregation.
 *
 * Used at both slot and day level to carry pre-computed capacity data.
 * The JS client reads these values directly — zero client-side computation.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slot_Capacity — aggregate capacity with per_staff breakdown.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slot_Capacity implements JsonSerializable {

	/**
	 * Total capacity.
	 *
	 * @var int
	 */
	public int $total;

	/**
	 * Booked quantity.
	 *
	 * @var int
	 */
	public int $booked;

	/**
	 * Available capacity: max(0, total - booked).
	 *
	 * @var int
	 */
	public int $available;

	/**
	 * Occupancy percentage 0–100.
	 *
	 * @var int
	 */
	public int $occupancy_pct;

	/**
	 * Status: available|filling_fast|fully_booked.
	 *
	 * @var string
	 */
	public string $status;

	/**
	 * Human-readable capacity message.
	 *
	 * @var string
	 */
	public string $message;

	/**
	 * Per-staff capacity breakdown.
	 * Keys are staff IDs (int), '0' = no-preference aggregate.
	 * Values are arrays with: available, booked, occupancy_pct, status, message.
	 *
	 * @var array<int, array{available: int, booked: int, occupancy_pct: int, status: string, message: string}>
	 */
	public array $per_staff;

	/**
	 * Constructor.
	 *
	 * @param int                                                                                          $total         Total capacity.
	 * @param int                                                                                          $booked        Booked quantity.
	 * @param int                                                                                          $available     Available capacity.
	 * @param int                                                                                          $occupancy_pct Occupancy 0-100.
	 * @param string                                                                                       $status        Status string.
	 * @param string                                                                                       $message       Human-readable message.
	 * @param array<int, array{available: int, booked: int, occupancy_pct: int, status: string, message: string}> $per_staff Per-staff breakdown.
	 */
	public function __construct(
		int    $total,
		int    $booked,
		int    $available,
		int    $occupancy_pct,
		string $status,
		string $message,
		array  $per_staff = []
	) {
		$this->total         = $total;
		$this->booked        = $booked;
		$this->available     = $available;
		$this->occupancy_pct = $occupancy_pct;
		$this->status        = $status;
		$this->message       = $message;
		$this->per_staff     = $per_staff;
	}

	/**
	 * Build a capacity object from raw totals.
	 *
	 * @param int                                                                                          $total     Total capacity.
	 * @param int                                                                                          $booked    Booked quantity.
	 * @param array<int, array{available: int, booked: int, occupancy_pct: int, status: string, message: string}> $per_staff Per-staff breakdown arrays.
	 * @return self
	 */
	public static function from_totals( int $total, int $booked, array $per_staff = [] ): self {
		$available     = max( 0, $total - $booked );
		$occupancy_pct = $total > 0 ? min( 100, (int) round( $booked / $total * 100 ) ) : 0;
		$status        = self::compute_status( $available, $occupancy_pct );
		$message       = self::compute_message( $available );

		return new self(
			$total,
			$booked,
			$available,
			$occupancy_pct,
			$status,
			$message,
			$per_staff
		);
	}

	/**
	 * Compute status string from availability and occupancy.
	 *
	 * @param int $available     Available capacity.
	 * @param int $occupancy_pct Occupancy percentage.
	 * @return string
	 */
	public static function compute_status( int $available, int $occupancy_pct ): string {
		if ( $available <= 0 ) {
			return 'fully_booked';
		}

		return $occupancy_pct >= 70 ? 'filling_fast' : 'available';
	}

	/**
	 * Compute human-readable capacity message.
	 *
	 * When $show is true the "X left" count is always rendered.
	 * When false, no message is shown (e.g. caller wants to hide count on empty slots).
	 * Controlled upstream via the 'woocommerce_appointments_show_spaces_left' filter,
	 * which defaults to true (always show).
	 *
	 * @param int  $available Available capacity.
	 * @param bool $show      When true, render the count. Defaults to true.
	 * @return string
	 */
	public static function compute_message( int $available, bool $show = true ): string {
		if ( $available <= 0 ) {
			return __( 'Full', 'woocommerce-appointments' );
		}

		if ( $show ) {
			return sprintf(
				/* translators: %d: number remaining */
				_n( '%d left', '%d left', $available, 'woocommerce-appointments' ),
				$available
			);
		}

		return '';
	}

	/**
	 * Build a per-staff entry array from raw values.
	 *
	 * @param int $available Available capacity for this staff.
	 * @param int $booked    Booked quantity for this staff.
	 * @param int $total     Total capacity for this staff.
	 * @return array{available: int, booked: int, occupancy_pct: int, status: string, message: string}
	 */
	public static function build_staff_entry( int $available, int $booked, int $total ): array {
		$occupancy_pct = $total > 0 ? min( 100, (int) round( $booked / $total * 100 ) ) : 0;

		return [
			'available'     => $available,
			'booked'        => $booked,
			'occupancy_pct' => $occupancy_pct,
			'status'        => self::compute_status( $available, $occupancy_pct ),
			'message'       => self::compute_message( $available ),
		];
	}

	/**
	 * JSON serialization.
	 *
	 * @return array{total: int, booked: int, available: int, occupancy_pct: int, status: string, message: string, per_staff: array<int, array{available: int, booked: int, occupancy_pct: int, status: string, message: string}>}
	 */
	public function jsonSerialize(): array {
		return [
			'total'         => $this->total,
			'booked'        => $this->booked,
			'available'     => $this->available,
			'occupancy_pct' => $this->occupancy_pct,
			'status'        => $this->status,
			'message'       => $this->message,
			'per_staff'     => $this->per_staff,
		];
	}
}
