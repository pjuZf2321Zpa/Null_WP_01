<?php
/**
 * Slots Collection — assembles slot[] into hierarchical response.
 *
 * Single-pass build: slots → day summaries → month summaries.
 * Always built at 'full' level. for_level() subsets before returning.
 * L1 cache stores the full collection — all four levels served from one entry.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * WC_Appointment_Slots_Collection — hierarchical slot response.
 *
 * UNIFIED SLOTS STANDARDIZATION: Collection provides grouping methods
 * that work with pre-calculated display fields from slots.
 *
 * @since 5.3.0
 */
final class WC_Appointment_Slots_Collection implements JsonSerializable {
	/**
	 * Product ID.
	 *
	 * @var int
	 */
	private int $product_id;

	/**
	 * Product instance for lazy price formatting.
	 *
	 * @var WC_Product_Appointment|null
	 */
	private ?WC_Product_Appointment $product = null;

	/**
	 * Business timezone string (IANA format).
	 *
	 * @var string
	 */
	private string $timezone;

	/**
	 * Display timezone string (IANA format, customer's timezone).
	 *
	 * @var string
	 * @since 5.3.5
	 */
	private string $display_timezone = '';

	/**
	 * Range start date 'YYYY-MM-DD'.
	 *
	 * @var string
	 */
	private string $start_date;

	/**
	 * Range end date 'YYYY-MM-DD'.
	 *
	 * @var string
	 */
	private string $end_date;

	/**
	 * Month summaries keyed by 'YYYY-MM'.
	 *
	 * @var array<string, WC_Appointment_Month_Summary>
	 */
	private array $months = [];

	/**
	 * Day summaries keyed by 'YYYY-MM-DD'.
	 *
	 * @var array<string, WC_Appointment_Day_Summary>
	 */
	private array $days = [];

	/**
	 * Slots grouped by date 'YYYY-MM-DD'.
	 *
	 * @var array<string, WC_Appointment_Slot[]>
	 */
	private array $slots = [];

	/**
	 * Staff index: staff_id => { id, name, available_slots, booked_slots }.
	 *
	 * @var array<int, array{id: int, name: string, available_slots: int, booked_slots: int}>
	 */
	private array $staff = [];

	/**
	 * Generation metadata.
	 *
	 * @var array<string, mixed>
	 */
	private array $meta = [];

	/**
	 * Private constructor — use static factory.
	 */
	private function __construct() {}

	/**
	 * Slots that count toward day-level availability (calendar dots / selectable).
	 *
	 * Minute/hour products may emit shorter engine segments; those are not pickable
	 * starts and must match {@see WC_Appointment_Slots_Display_Rules::is_bookable_start_for_time_product()}.
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param WC_Appointment_Slot[]  $slots               Slots for one civil day.
	 * @return WC_Appointment_Slot[]
	 */
	public static function slots_for_day_summary( WC_Product_Appointment $appointable_product, array $slots ): array {
		$duration_unit = $appointable_product->get_duration_unit();

		if ( ! $appointable_product->has_time()
			|| ! in_array( $duration_unit, [ 'minute', 'hour' ], true ) ) {
			return $slots;
		}

		$unit             = $duration_unit;
		$duration_minutes = (int) $appointable_product->get_duration_in_minutes();
		$filtered         = [];

		foreach ( $slots as $slot ) {
			if ( $slot instanceof WC_Appointment_Slot
				&& WC_Appointment_Slots_Display_Rules::is_bookable_start_for_time_product( $unit, $duration_minutes, $slot ) ) {
				$filtered[] = $slot;
			}
		}

		return $filtered;
	}

	/**
	 * Build a Collection from a flat array of WC_Appointment_Slot objects.
	 *
	 * Single-pass: group slots by day → day summaries → month summaries.
	 *
	 * @param WC_Appointment_Slot[]  $slots      Flat array of slot objects.
	 * @param WC_Product_Appointment $appointable_product The appointment product.
	 * @param string                 $start_date Range start 'YYYY-MM-DD'.
	 * @param string                 $end_date   Range end 'YYYY-MM-DD'.
	 * @param array<string, mixed>   $meta       Optional metadata (engine, cache_hit, etc.).
	 * @return self
	 */
	public static function from_slots(
		array $slots,
		WC_Product_Appointment $appointable_product,
		string $start_date,
		string $end_date,
		array $meta = []
	): self {
		$collection              = new self();
		$collection->product_id  = $appointable_product->get_id();
		$collection->product     = $appointable_product;
		$collection->timezone    = wc_timezone_string();
		$collection->start_date  = $start_date;
		$collection->end_date    = $end_date;
		$collection->meta        = array_merge(
			[
				'generated_at'  => time(),
				'cache_hit'     => false,
				'engine'        => 2, // 1 rules index, 2 dynamic rules, 3 rules + appointments index.
				'query_count'   => 0,
				'query_time_ms' => 0,
			],
			$meta
		);

		// Step 1: Group slots by day.
		// Day-unit slots use UTC date tokens (civil dates). Keep grouping in UTC so
		// timezone shifts (e.g. America/New_York) do not move tokens to prior day.
		// Minute/hour/month continue using existing behavior.
		$slots_by_day = [];
		foreach ( $slots as $slot ) {
			// Slot start_ts is Fake UTC (day/month/minute/hour). Civil day = gmdate, never site wp_date.
			$day_key = gmdate( 'Y-m-d', $slot->start_ts );

			// Only include slots that fall within the requested wall-clock range.
			if ( $day_key < $start_date || $day_key > $end_date ) {
				continue;
			}

			$slots_by_day[ $day_key ][] = $slot;
		}

		$collection->slots = $slots_by_day;

		// Step 2: Build day summaries for each day in range.
		$day_summaries = [];
		$site_tz       = new DateTimeZone( wc_timezone_string() );
		$current_dt    = new DateTimeImmutable( $start_date . ' 00:00:00', $site_tz );
		$end_bound_dt  = new DateTimeImmutable( $end_date . ' 00:00:00', $site_tz );

		while ( $current_dt <= $end_bound_dt ) {
			$day_key = $current_dt->format( 'Y-m-d' );

			if ( isset( $slots_by_day[ $day_key ] ) ) {
				$summary_slots = self::slots_for_day_summary( $appointable_product, $slots_by_day[ $day_key ] );
				if ( empty( $summary_slots ) ) {
					$day_summaries[ $day_key ] = WC_Appointment_Day_Summary::unavailable( $day_key );
				} else {
					$day_summaries[ $day_key ] = WC_Appointment_Day_Summary::from_slots( $day_key, $summary_slots );
				}
			} else {
				$day_summaries[ $day_key ] = WC_Appointment_Day_Summary::unavailable( $day_key );
			}

			$current_dt = $current_dt->modify( '+1 day' );
		}

		$collection->days = $day_summaries;

		// Step 3: Group day summaries by month → month summaries.
		$days_by_month = [];
		foreach ( $day_summaries as $day ) {
			$month_key = substr( $day->date, 0, 7 ); // 'YYYY-MM'
			$days_by_month[ $month_key ][] = $day;
		}

		$month_summaries = [];
		foreach ( $days_by_month as $month_key => $month_days ) {
			$month_summaries[ $month_key ] = WC_Appointment_Month_Summary::from_days( $month_key, $month_days );
		}

		$collection->months = $month_summaries;

		// Step 4: Build staff index.
		$collection->staff = self::build_staff_index( $slots, $appointable_product );

		return $collection;
	}

	/**
	 * Qty-per-day + minute/hour: mark slots sold out on civil days at capacity.
	 *
	 * Applied to the flat engine slot list before {@see from_slots()} so day summaries
	 * are derived from correct availability (not patched after the collection is built).
	 *
	 * @param WC_Appointment_Slot[]  $slots               Flat slot list from the engine.
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @return WC_Appointment_Slot[]
	 */
	public static function apply_per_day_inventory_to_slots( array $slots, WC_Product_Appointment $appointable_product ): array {
		if ( ! $slots
			|| ! $appointable_product->is_qty_per_day()
			|| ! in_array( $appointable_product->get_duration_unit(), [ 'minute', 'hour' ], true ) ) {
			return $slots;
		}

		$range_min = PHP_INT_MAX;
		$range_max = 0;
		foreach ( $slots as $slot ) {
			$day_key   = WC_Appointment_Slots_Engine::timed_overlap_day_key_ts( (int) $slot->start_ts );
			$range_min = min( $range_min, $day_key );
			$range_max = max( $range_max, $day_key + DAY_IN_SECONDS );
		}

		$appointments = WC_Appointment_Recurring_Cart_Occupancy::occupying_appointments_for_product( $appointable_product, $range_min, $range_max, 0 );

		$booked_by_staff_ymd = self::per_day_booked_totals( $appointments, $appointable_product );
		if ( ! $booked_by_staff_ymd ) {
			return $slots;
		}

		foreach ( $slots as $slot ) {
			$ymd    = gmdate( 'Y-m-d', $slot->start_ts );
			$sid    = $slot->staff_id;
			$booked = (int) ( $booked_by_staff_ymd[ $sid ][ $ymd ] ?? 0 );
			if ( $sid > 0 ) {
				$booked += (int) ( $booked_by_staff_ymd[0][ $ymd ] ?? 0 );
			}
			$cap = (int) $appointable_product->get_available_qty( $sid > 0 ? $sid : '' );
			if ( $cap > 0 && $booked >= $cap ) {
				$slot->capacity_booked    = $slot->capacity_total;
				$slot->capacity_available = 0;
				$slot->available          = false;
				$slot->status             = 'fully_booked';
				$slot->bookable           = false;
			}
		}

		return $slots;
	}

	/**
	 * @param WC_Appointment[]         $appointments Existing appointments overlapping the range.
	 * @param WC_Product_Appointment   $appointable_product      For product id + padding.
	 * @return array<int, array<string, int>> staff_id => [ 'Y-m-d' => booked_qty ]
	 */
	private static function per_day_booked_totals( array $appointments, WC_Product_Appointment $appointable_product ): array {
		$pid  = (int) $appointable_product->get_id();
		$map  = [];
		// Cache of [ 'before' => min, 'after' => min ] per product id.
		$xpad = [
			$pid => [
				'before' => (int) $appointable_product->get_padding_before_in_minutes(),
				'after'  => (int) $appointable_product->get_padding_after_in_minutes(),
			],
		];
		$tz   = new DateTimeZone( wc_timezone_string() );

		foreach ( $appointments as $a ) {
			if ( ! $a instanceof WC_Appointment ) {
				continue;
			}

			if ( WC_Appointment_Slots_Engine::is_overlap_appointment_excluded( (int) $a->get_id() ) ) {
				continue;
			}

			$ids = wc_appointments_normalize_staff_ids( $a->get_staff_ids() );
			$occ_loc  = WC_Appointment_Slots_Engine::get_occupancy_location_id();
			$appt_loc = (int) $a->get_location_id();
			if ( $occ_loc > 0 && $appt_loc > 0 && $appt_loc !== $occ_loc && [] === $ids ) {
				continue;
			}
			if ( [] === $ids ) {
				$ids = [ 0 ];
			}
			$qty = $a->get_qty() ? (int) $a->get_qty() : 1;

			// A booking reserves its own before/after buffer on the day grid.
			$opid = (int) $a->get_product_id();
			if ( ! isset( $xpad[ $opid ] ) ) {
				$op = $a->get_product();
				$xpad[ $opid ] = [
					'before' => ( $op instanceof WC_Product_Appointment ) ? (int) $op->get_padding_before_in_minutes() : 0,
					'after'  => ( $op instanceof WC_Product_Appointment ) ? (int) $op->get_padding_after_in_minutes() : 0,
				];
			}
			$pad_before = $xpad[ $opid ]['before'];
			$pad_after  = $xpad[ $opid ]['after'];

			$s = $a->get_start();
			$e = $a->get_end();
			if ( ! $s || ! $e ) {
				continue;
			}
			if ( $pad_before > 0 ) {
				$s = strtotime( "-{$pad_before} minutes", $s );
			}
			if ( $pad_after > 0 ) {
				$e = strtotime( "+{$pad_after} minutes", $e );
			}

			$e = max( $e - 1, $s );
			if ( in_array( $appointable_product->get_duration_unit(), [ 'minute', 'hour' ], true ) ) {
				// Timed appointments store Fake UTC instants — civil day keys must match slot ymd (gmdate).
				$d0 = new DateTimeImmutable( gmdate( 'Y-m-d', $s ), new DateTimeZone( 'UTC' ) );
				$d1 = new DateTimeImmutable( gmdate( 'Y-m-d', $e ), new DateTimeZone( 'UTC' ) );
			} else {
				$d0 = ( new DateTimeImmutable( '@' . $s ) )->setTimezone( $tz )->setTime( 0, 0, 0 );
				$d1 = ( new DateTimeImmutable( '@' . $e ) )->setTimezone( $tz )->setTime( 0, 0, 0 );
			}

			for ( $d = $d0; $d <= $d1; $d = $d->modify( '+1 day' ) ) {
				$ymd = $d->format( 'Y-m-d' );
				foreach ( $ids as $sk ) {
					$sk = (int) $sk;
					// [0] is only for unassigned bookings; staff qty must not roll up into [0].
					$map[ $sk ][ $ymd ] = ( $map[ $sk ][ $ymd ] ?? 0 ) + $qty;
				}
			}
		}

		return $map;
	}

	/**
	 * Unix timestamp for 00:00:00 of a calendar day in the WooCommerce site timezone.
	 *
	 * Used when shifting customer-timezone day boundaries; do not use strtotime( 'Y-m-d' )
	 * (that uses the PHP default timezone and misaligns with slot generation).
	 *
	 * @param string $ymd Date 'YYYY-MM-DD'.
	 * @return int
	 */
	public static function timestamp_site_midnight( string $ymd ): int {
		$tz = new DateTimeZone( wc_timezone_string() );
		return ( new DateTimeImmutable( $ymd . ' 00:00:00', $tz ) )->getTimestamp();
	}

	/**
	 * Build staff index from slots and product.
	 *
	 * @param WC_Appointment_Slot[]  $slots   Slot objects.
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @return array<int, array{id: int, name: string, available_slots: int, booked_slots: int}>
	 */
	private static function build_staff_index( array $slots, WC_Product_Appointment $appointable_product ): array {
		if ( ! $appointable_product->has_staff() ) {
			return [];
		}

		$staff_index = [];

		// Accumulate slot counts per staff from slot data.
		$staff_available = [];
		$staff_booked    = [];

		foreach ( $slots as $slot ) {
			$sid = $slot->staff_id;
			if ( 0 === $sid ) {
				continue; // Skip product-level aggregates.
			}

			if ( ! isset( $staff_available[ $sid ] ) ) {
				$staff_available[ $sid ] = 0;
				$staff_booked[ $sid ]    = 0;
			}

			if ( $slot->available ) {
				$staff_available[ $sid ]++;
			} else {
				$staff_booked[ $sid ]++;
			}
		}

		// Build index with staff names.
		foreach ( $appointable_product->get_staff() as $staff_member ) {
			$sid = $staff_member->get_id();
			$staff_index[ $sid ] = [
				'id'              => $sid,
				'name'            => $staff_member->get_display_name(),
				'available_slots' => $staff_available[ $sid ] ?? 0,
				'booked_slots'    => $staff_booked[ $sid ] ?? 0,
			];
		}

		return $staff_index;
	}

	/**
	 * Get subset of the collection for a specific response level.
	 *
	 * @param string $level summary|days|slots|full
	 * @return array<string, mixed>
	 */
	public function for_level( string $level ): array {
		$base = [
			'product_id' => $this->product_id,
			'timezone'   => $this->timezone,
			'range'      => [
				'start' => $this->start_date,
				'end'   => $this->end_date,
			],
		];

		// Months are always included.
		$base['months'] = $this->months;

		if ( 'summary' === $level ) {
			return $base;
		}

		// Days level and above.
		$base['days'] = $this->days;

		if ( 'days' === $level ) {
			return $base;
		}

		// Slots level and above.
		$base['slots'] = $this->serialize_slots();

		if ( 'slots' === $level ) {
			return $base;
		}

		// Full level — includes staff index and meta.
		$base['staff'] = $this->staff;
		$base['meta']  = $this->meta;

		return $base;
	}

	/**
	 * Serialize slots with display time formatting.
	 *
	 * @return array<string, array<int, array<string, mixed>>>
	 */
	private function serialize_slots(): array {
		$result  = [];
		$product = $this->product;

		foreach ( $this->slots as $day_key => $day_slots ) {
			$result[ $day_key ] = [];
			foreach ( $day_slots as $slot ) {
				$slot_data         = $slot->jsonSerialize();
				$slot_data['time'] = gmdate( 'H:i', $slot->start_ts );

				// Lazy price formatting: engine only sets price_raw (pure math).
				// jsonSerialize uses scalar `price` + price_data — set display on price_data / price_formatted.
				if ( null !== $slot->price_raw && null === $slot->price_display && null !== $product ) {
					$default_price = WC_Appointment_Slots_Pricing::get_default_slot_price_raw( $product, $slot->staff_id );
					if ( WC_Appointment_Slots_Pricing::is_slot_price_discounted( $slot->price_raw, $default_price ) ) {
						$display_html = WC_Appointment_Slots_Pricing::format_discounted_cached(
							$default_price,
							$slot->price_raw,
							$product
						);
					} else {
						$display_html = WC_Appointment_Slots_Pricing::get_formatted_price( $slot->price_raw, $product );
					}
					$slot_data['price_data']['display'] = $display_html;
					$slot_data['price_formatted']       = $display_html;
				}

				$result[ $day_key ][] = $slot_data;
			}
		}

		return $result;
	}

	/**
	 * Get raw slot objects grouped by day.
	 *
	 * @return array<string, WC_Appointment_Slot[]>
	 */
	public function get_slots_by_day(): array {
		return $this->slots;
	}

	// =========================================================================
	// UNIFIED SLOTS STANDARDIZATION — Display Day Grouping
	// =========================================================================

	/**
	 * Get slots grouped by display_day (customer timezone).
	 *
	 * Uses pre-calculated display_day from each slot for grouping.
	 * This is the preferred method for customer-facing views where
	 * timezone conversion is enabled.
	 *
	 * @since 5.3.5
	 *
	 * @return array<string, WC_Appointment_Slot[]> Slots keyed by 'YYYY-MM-DD' display day.
	 */
	public function get_slots_by_display_day(): array {
		$by_day = [];
		foreach ( $this->get_all_slots() as $slot ) {
			$day_key = $slot->display_day ?: gmdate( 'Y-m-d', $slot->start_ts );
			$by_day[ $day_key ][] = $slot;
		}
		ksort( $by_day );
		return $by_day;
	}

	/**
	 * Get day summaries keyed by display_day (customer timezone).
	 *
	 * Returns pre-computed per-day data that consumers can render directly
	 * without any additional calculations.
	 *
	 * @since 5.3.5
	 *
	 * @return array<string, array{display_day: string, business_day: string, status: string, selectable: bool, slots_total: int, slots_available: int, occupancy_pct: int, first_slot: string|null, last_slot: string|null, price: array{min: float|null, max: float|null}}> Day summaries keyed by 'YYYY-MM-DD' display day.
	 */
	public function get_day_summaries_by_display(): array {
		$by_day    = $this->get_slots_by_display_day();
		$summaries = [];

		foreach ( $by_day as $display_day => $slots ) {
			$available     = array_filter( $slots, fn( $s ) => $s->bookable );
			$total_booked  = 0;
			$total_cap     = 0;
			$min_price     = null;
			$max_price     = null;

			foreach ( $slots as $slot ) {
				$total_booked += $slot->capacity_booked;
				$total_cap    += $slot->capacity_total;
				if ( $slot->available && null !== $slot->price_raw ) {
					if ( null === $min_price || $slot->price_raw < $min_price ) {
						$min_price = $slot->price_raw;
					}
					if ( null === $max_price || $slot->price_raw > $max_price ) {
						$max_price = $slot->price_raw;
					}
				}
			}

			$occupancy_pct = $total_cap > 0 ? min( 100, (int) round( $total_booked / $total_cap * 100 ) ) : 0;
			$first_slot    = reset( $slots );
			$last_slot     = end( $slots );

			// Derive status.
			$available_count = count( $available );
			if ( $available_count <= 0 ) {
				$status = 'fully_booked';
			} elseif ( $occupancy_pct >= 70 ) {
				$status = 'filling_fast';
			} else {
				$status = 'available';
			}

			$summaries[ $display_day ] = [
				'display_day'     => $display_day,
				'business_day'    => $first_slot ? $first_slot->business_day : $display_day,
				'status'          => $status,
				'selectable'      => $available_count > 0,
				'slots_total'     => count( $slots ),
				'slots_available' => $available_count,
				'occupancy_pct'   => $occupancy_pct,
				'first_slot'      => $first_slot ? $first_slot->display_time : null,
				'last_slot'       => $last_slot ? $last_slot->display_time : null,
				'price'           => [
					'min' => $min_price,
					'max' => $max_price,
				],
			];
		}

		return $summaries;
	}

	/**
	 * Get display timezone for this collection.
	 *
	 * @since 5.3.5
	 *
	 * @return string Display timezone string (IANA format).
	 */
	public function get_display_timezone(): string {
		return $this->display_timezone ?: $this->timezone;
	}

	/**
	 * Set display timezone for this collection.
	 *
	 * @since 5.3.5
	 *
	 * @param string $timezone Display timezone string (IANA format).
	 * @return self
	 */
	public function set_display_timezone( string $timezone ): self {
		$this->display_timezone = $timezone;
		return $this;
	}

	/**
	 * Get day summaries.
	 *
	 * @return array<string, WC_Appointment_Day_Summary>
	 */
	public function get_days(): array {
		return $this->days;
	}

	/**
	 * Get month summaries.
	 *
	 * @return array<string, WC_Appointment_Month_Summary>
	 */
	public function get_months(): array {
		return $this->months;
	}

	/**
	 * Get staff index.
	 *
	 * @return array<int, array{id: int, name: string, available_slots: int, booked_slots: int}>
	 */
	public function get_staff(): array {
		return $this->staff;
	}

	/**
	 * Get generation metadata.
	 *
	 * @return array<string, mixed>
	 */
	public function get_meta(): array {
		return $this->meta;
	}

	/**
	 * Get product ID.
	 *
	 * @return int
	 */
	public function get_product_id(): int {
		return $this->product_id;
	}

	/**
	 * Get all flat slot objects.
	 *
	 * @return WC_Appointment_Slot[]
	 */
	public function get_all_slots(): array {
		$all = [];
		foreach ( $this->slots as $day_slots ) {
			foreach ( $day_slots as $slot ) {
				$all[] = $slot;
			}
		}
		return $all;
	}

	/**
	 * Get the first available slot in this collection.
	 *
	 * Uses day summaries to quickly skip unavailable days, then examines
	 * only slots for the first day that has availability. This is O(D + S_day)
	 * where D = number of days and S_day = slots in first available day,
	 * compared to O(all_slots) for iterating through everything.
	 *
	 * @since 5.3.8
	 *
	 * @param int $staff_id Optional staff ID to filter by (0 = any staff).
	 * @return WC_Appointment_Slot|null First available slot or null if none found.
	 */
	public function get_first_available_slot( int $staff_id = 0 ): ?WC_Appointment_Slot {
		$days = $this->get_days();

		// Days are keyed by 'YYYY-MM-DD' and ksort ensures chronological order.
		ksort( $days );

		foreach ( $days as $day_key => $day_summary ) {
			// Quick check: skip days with no available slots.
			if ( $day_summary->available_slots <= 0 ) {
				continue;
			}

			// This day has availability - examine its slots.
			$day_slots = $this->slots[ $day_key ] ?? [];

			// Sort slots by start time within the day.
			usort( $day_slots, static fn( WC_Appointment_Slot $a, WC_Appointment_Slot $b ): int => $a->start_ts <=> $b->start_ts );

			foreach ( $day_slots as $slot ) {
				if ( ! $slot->available ) {
					continue;
				}

				// Staff filter: 0 means any staff.
				if ( $staff_id > 0 && $slot->staff_id !== $staff_id && $slot->staff_id !== 0 ) {
					continue;
				}

				return $slot;
			}
		}

		return null;
	}

	/**
	 * Get the first available slot timestamp in this collection.
	 *
	 * Convenience method that returns just the timestamp (or false for BC).
	 *
	 * @since 5.3.8
	 *
	 * @param int $staff_id Optional staff ID to filter by (0 = any staff).
	 * @return int|false First available slot timestamp or false if none found.
	 */
	public function get_first_available_slot_timestamp( int $staff_id = 0 ) {
		$slot = $this->get_first_available_slot( $staff_id );
		return $slot ? $slot->start_ts : false;
	}

	/**
	 * Get slots grouped by start_ts for time-slots HTML display, with message pre-computed.
	 *
	 * Aggregates capacity across staff and sets 'message' (X left / Full) in slot
	 * generation: show "X left" only when the slot has appointments (booked > 0)
	 * or is in a buffer range; otherwise no message. Controller only displays the result.
	 *
	 * @since 5.3.0
	 *
	 * @param bool $include_sold_out Include slots with zero available. Default false.
	 * @param int  $min_qty          Minimum capacity required. Default 1.
	 * @return array<int, array{available: int, booked: int, total: int, staff: array<int, int>, message: string, display_day?: string, display_time?: string, display_time_formatted?: string, selection_value?: string, price?: array{show: bool, min: float, max: float, min_display: string, max_display: string, display: string}}>
	 */
	public function get_grouped_for_time_slots_display( WC_Product_Appointment $appointable_product, bool $include_sold_out = false, int $min_qty = 1 ): array {
		$min_qty = max( 1, $min_qty );
		$grouped = [];
		foreach ( $this->get_all_slots() as $slot ) {
			if ( ! WC_Appointment_Slots_Display_Rules::is_bookable_start_for_time_product(
				$appointable_product->get_duration_unit(),
				$appointable_product->get_duration_in_minutes(),
				$slot
			) ) {
				continue;
			}

			$ts  = $slot->start_ts;
			$sid = $slot->staff_id;

			if ( ! isset( $grouped[ $ts ] ) ) {
				$grouped[ $ts ] = [
					'available' => 0,
					'booked'   => 0,
					'total'    => 0,
					'staff'    => [],
					'message'  => '',
					'min_price' => null,
					'max_price' => null,
				];
			}

			$grouped[ $ts ]['staff'][ $sid ] = $slot->capacity_available;
			if ( $slot->available && null !== $slot->price_raw ) {
				if ( null === $grouped[ $ts ]['min_price'] || $slot->price_raw < $grouped[ $ts ]['min_price'] ) {
					$grouped[ $ts ]['min_price'] = $slot->price_raw;
				}
				if ( null === $grouped[ $ts ]['max_price'] || $slot->price_raw > $grouped[ $ts ]['max_price'] ) {
					$grouped[ $ts ]['max_price'] = $slot->price_raw;
				}
			}

			if ( 0 === $sid ) {
				$grouped[ $ts ]['available'] = $slot->capacity_available;
				$grouped[ $ts ]['booked']    = $slot->capacity_booked;
				$grouped[ $ts ]['total']     = $slot->capacity_total;
			} else {
				$grouped[ $ts ]['available'] += $slot->capacity_available;
				$grouped[ $ts ]['booked']    += $slot->capacity_booked;
				$grouped[ $ts ]['total']     += $slot->capacity_total;
			}
			// Unified projection fields per start_ts (customer-facing labels; start_ts is Fake UTC for minute/hour).
			if ( ! isset( $grouped[ $ts ]['display_day'] ) && is_string( $slot->display_day ) && '' !== $slot->display_day ) {
				$grouped[ $ts ]['display_day'] = $slot->display_day;
			}
			if ( ! isset( $grouped[ $ts ]['display_time'] ) && is_string( $slot->display_time ) && '' !== $slot->display_time ) {
				$grouped[ $ts ]['display_time'] = $slot->display_time;
			}
			if ( ! isset( $grouped[ $ts ]['display_time_formatted'] ) && is_string( $slot->display_time_formatted ) && '' !== $slot->display_time_formatted ) {
				$grouped[ $ts ]['display_time_formatted'] = $slot->display_time_formatted;
			}
			if ( ! isset( $grouped[ $ts ]['selection_value'] ) && is_string( $slot->selection_value ) && '' !== $slot->selection_value ) {
				$grouped[ $ts ]['selection_value'] = $slot->selection_value;
			}
		}

		foreach ( $grouped as $ts => $data ) {
			if ( $data['available'] < $min_qty ) {
				if ( ! $include_sold_out || $data['available'] > 0 ) {
					unset( $grouped[ $ts ] );
					continue;
				}
			}
			$grouped[ $ts ]['message'] = WC_Appointment_Slot_Capacity::compute_message(
				$data['available'],
				(bool) apply_filters( 'woocommerce_appointments_show_spaces_left', $data['booked'] > 0, $data['available'], $data['booked'], $ts )
			);
			$primary_staff_id = 0;
			$staff_ids        = array_keys( $data['staff'] );
			if ( 1 === count( $staff_ids ) ) {
				$primary_staff_id = (int) reset( $staff_ids );
			}
			$grouped[ $ts ]['price'] = self::build_price_payload(
				$appointable_product,
				$data['min_price'],
				$data['max_price'],
				(bool) apply_filters(
					'woocommerce_appointments_time_slot_price_visible',
					null !== $data['min_price'] && null !== $data['max_price'],
					$appointable_product,
					(int) $ts,
					$primary_staff_id,
					[
						'min' => $data['min_price'],
						'max' => $data['max_price'],
					],
					$data
				),
				$primary_staff_id
			);
			unset( $grouped[ $ts ]['min_price'], $grouped[ $ts ]['max_price'] );
		}

		// Sort by wall-clock HHMM, then by timestamp (UTC-labelled instants — use gmdate, not wp_date).
		uksort(
			$grouped,
			static function( $a_ts, $b_ts ): int {
				$a_key = gmdate( 'Hi', (int) $a_ts );
				$b_key = gmdate( 'Hi', (int) $b_ts );
				$cmp   = strcmp( $a_key, $b_key );
				if ( 0 !== $cmp ) {
					return $cmp;
				}
				return (int) $a_ts <=> (int) $b_ts;
			}
		);
		
		return $grouped;
	}

	/**
	 * Get slots grouped and formatted for admin JSON response.
	 *
	 * UNIFIED SLOTS STANDARDIZATION: Admin AJAX delegates to this method
	 * instead of doing post-processing. Returns array ready for wp_send_json_success().
	 *
	 * @since 5.3.6
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @param string                 $filter_date         Calendar date to filter (Y-m-d). Empty = no filter.
	 * @param string                 $admin_tz_display    Admin timezone for display (IANA). Empty = site TZ.
	 * @param int                    $min_qty             Minimum quantity required. Default 1.
	 * @param bool                   $include_pricing     Include price data. Default false.
	 * @return array{slots: array<int, array<string, mixed>>, total_available: int}
	 */
	public function get_grouped_for_admin_json(
		WC_Product_Appointment $appointable_product,
		string $filter_date = '',
		string $admin_tz_display = '',
		int $min_qty = 1,
		bool $include_pricing = false
	): array {
		$slots_response  = [];
		$total_available = 0;
		$site_tz_string  = wc_timezone_string();

		// Filter slots to date and bookable starts.
		$all_slots = $this->get_all_slots();
		$all_slots = array_filter(
			$all_slots,
			function ( WC_Appointment_Slot $slot ) use ( $filter_date, $admin_tz_display, $site_tz_string ): bool {
				if ( '' === $filter_date ) {
					return true;
				}
				if ( $admin_tz_display && $admin_tz_display !== $site_tz_string ) {
					$converted_ts = WC_Appointments_Timezone_Helper::convert_timestamp( $slot->start_ts, $site_tz_string, $admin_tz_display );
					return gmdate( 'Y-m-d', $converted_ts ) === $filter_date;
				}
				return gmdate( 'Y-m-d', $slot->start_ts ) === $filter_date;
			}
		);

		$all_slots = array_values(
			array_filter(
				$all_slots,
				function ( WC_Appointment_Slot $slot ) use ( $appointable_product ): bool {
					return WC_Appointment_Slots_Display_Rules::is_bookable_start_for_time_product(
						$appointable_product->get_duration_unit(),
						$appointable_product->get_duration_in_minutes(),
						$slot
					);
				}
			)
		);

		if ( empty( $all_slots ) ) {
			return [ 'slots' => [], 'total_available' => 0 ];
		}

		// Group by timestamp and aggregate capacity.
		$grouped = [];
		foreach ( $all_slots as $slot ) {
			$ts  = $slot->start_ts;
			$sid = $slot->staff_id;
			if ( ! isset( $grouped[ $ts ] ) ) {
				$grouped[ $ts ] = [
					'available'          => 0,
					'staff'              => [],
					'price_raw'          => null,
					'price_raw_staff_id' => null,
					'end_ts'             => $slot->end_ts,
				];
			}
			$grouped[ $ts ]['staff'][ $sid ] = $slot->capacity_available;

			if ( 0 === $sid ) {
				$grouped[ $ts ]['available'] = $slot->capacity_available;
			} else {
				$grouped[ $ts ]['available'] += $slot->capacity_available;
			}

			if ( $include_pricing && null === $grouped[ $ts ]['price_raw'] && null !== $slot->price_raw ) {
				$grouped[ $ts ]['price_raw']          = $slot->price_raw;
				$grouped[ $ts ]['price_raw_staff_id'] = $slot->staff_id;
			}
		}
		ksort( $grouped );

		// Build JSON response.
		$tz = new DateTimeZone( 'UTC' );
		$all_staff_ids = $appointable_product->has_staff()
			? array_map( 'intval', (array) $appointable_product->get_staff_ids() )
			: [];

		foreach ( $grouped as $slot_ts => $slot_data ) {
			$avail_count = (int) $slot_data['available'];
			if ( $avail_count < $min_qty ) {
				continue;
			}

			// Timezone conversion for display.
			if ( $admin_tz_display && $admin_tz_display !== $site_tz_string ) {
				$converted_ts = WC_Appointments_Timezone_Helper::convert_timestamp( $slot_ts, $site_tz_string, $admin_tz_display );
			} else {
				$converted_ts = $slot_ts;
			}

			// Localized wall label via UTC TZ (Fake UTC digits); machine keys use gmdate.
			$display_time    = wp_date( wc_appointments_time_format(), $converted_ts, $tz );
			$admin_time_hhmm = gmdate( 'H:i', $converted_ts );
			$admin_date_ymd  = gmdate( 'Y-m-d', $converted_ts );
			$time_value      = gmdate( 'H:i', $slot_ts );

			// Per-staff availability.
			$staff_available = [];
			if ( ! empty( $all_staff_ids ) ) {
				foreach ( $slot_data['staff'] as $sid => $sid_avail ) {
					if ( (int) $sid > 0 && (int) $sid_avail > 0 ) {
						$staff_available[] = (int) $sid;
					}
				}
			}

			$slot_entry = [
				'time'            => $time_value,
				'start_ts'        => (int) $slot_ts,
				'display_time'    => $display_time,
				'admin_time'      => $admin_time_hhmm,
				'admin_date'      => $admin_date_ymd,
				'available'       => true,
				'capacity'        => max( 0, $avail_count ),
				'staff_available' => $staff_available,
			];

			// Pricing — mirror serialize_slots(): default per slot staff; sale HTML only when strictly below default.
			if ( $include_pricing ) {
				$price_raw = $slot_data['price_raw'];
				if ( null !== $price_raw ) {
					$sid           = isset( $slot_data['price_raw_staff_id'] ) ? (int) $slot_data['price_raw_staff_id'] : 0;
					$default_price = WC_Appointment_Slots_Pricing::get_default_slot_price_raw( $appointable_product, $sid );
					if ( WC_Appointment_Slots_Pricing::is_slot_price_discounted( $price_raw, $default_price ) ) {
						$display_html = WC_Appointment_Slots_Pricing::format_discounted_cached( $default_price, $price_raw, $appointable_product );
					} else {
						$display_html = WC_Appointment_Slots_Pricing::get_formatted_price( $price_raw, $appointable_product );
					}
					$slot_entry['price'] = [
						'show'    => true,
						'display' => $display_html,
						'raw'     => $price_raw,
					];
				} else {
					$slot_entry['price'] = [ 'show' => false, 'display' => '', 'raw' => null ];
				}
			}

			$slots_response[] = $slot_entry;
			$total_available++;
		}

		return [
			'slots'           => $slots_response,
			'total_available' => $total_available,
		];
	}

	/**
	 * Get available times as simple key-value pairs for admin dropdowns.
	 *
	 * UNIFIED SLOTS STANDARDIZATION: Admin AJAX delegates to this method.
	 *
	 * @since 5.3.6
	 *
	 * @param WC_Product_Appointment $appointable_product Product.
	 * @return array<string, string> Map of 'H:i' => 'display label'.
	 */
	public function get_available_times_for_admin( WC_Product_Appointment $appointable_product ): array {
		$available_times = [];

		foreach ( $this->get_all_slots() as $slot ) {
			if ( ! WC_Appointment_Slots_Display_Rules::is_bookable_start_for_time_product(
				$appointable_product->get_duration_unit(),
				$appointable_product->get_duration_in_minutes(),
				$slot
			) ) {
				continue;
			}
			if ( ! $slot->available ) {
				continue;
			}
			$time_value = gmdate( 'H:i', $slot->start_ts );
			$time_label = date_i18n( get_option( 'time_format' ), $slot->start_ts, true );
			$available_times[ $time_value ] = $time_label;
		}

		return $available_times;
	}

	/**
	 * Convert the Collection to the modern day-level data format for date-picker.js.
	 *
	 * Instead of 4 flat categorization arrays,
	 * returns pre-computed per-day data that the date picker interprets declaratively.
	 * No calculations needed on the client — just read status, occupancy, per_staff.
	 *
	 * Output format (keyed by date format matching AJAX expectations):
	 *   'day_data' => [
	 *     'Y-n-j' => {
	 *       selectable: bool,
	 *       status: 'available'|'filling_fast'|'fully_booked'|'unavailable',
	 *       css_class: 'appointable'|'partial_scheduled'|'fully_scheduled'|'not_appointable',
	 *       occupancy_pct: int(0-100),
	 *       remaining_bucket: int(1-9),     // legacy-compat: 1=nearly full, 9=nearly empty
	 *       slots_count: int,
	 *       available_slots: int,
	 *       booked_slots: int,
	 *       first_slot: '09:00'|null,
	 *       last_slot: '17:00'|null,
	 *       price: { min, max, min_display, max_display },
	 *       per_staff: { staff_id => { selectable, status, occupancy_pct, remaining_bucket, ... } },
	 *       title: string,                  // i18n tooltip text
	 *       padding: bool,                  // true if day is blocked by padding (Phase 11)
	 *       restricted: bool,               // true if day is blocked by restricted weekdays (Phase 11)
	 *     }
	 *   ]
	 *
	 * @since 5.3.0
	 * @since 5.3.9 Added $padding_days and $restricted_days parameters (Phase 11 - Unified Slots Standardization).
	 *
	 * @param WC_Product_Appointment $product            Product (for staff list and i18n).
	 * @param int                    $tz_offset          Customer timezone offset in minutes (customer - site). Default 0.
	 * @param string                 $date_format        PHP date format for day keys. Default 'Y-n-j'.
	 * @param string|null            $customer_timezone  IANA timezone for first/last slot labels when offset is applied (minute/hour). Default null (site TZ).
	 * @param array<string, mixed>   $padding_days       Padding dates keyed by same `$date_format` as day rows (value unused; isset-only). Default empty.
	 * @param array<int, int>|false  $restricted_days    Restricted weekdays (0-6 indexed, false = no restrictions). Default false.
	 * @return array{day_data: array<string, array<string, mixed>>}
	 */
	public function to_day_data( WC_Product_Appointment $product, int $tz_offset = 0, string $date_format = 'Y-n-j', ?string $customer_timezone = null, array $padding_days = [], $restricted_days = false ): array {
		$day_data          = [];
		$has_staff         = $product->has_staff();
		$tz_offset_seconds = $tz_offset * 60;
		$duration_unit     = $product->get_duration_unit();
		$customer_day_ts_bounds = [];

		// Collect all staff IDs from product.
		$all_staff_ids = [];
		if ( $has_staff ) {
			$all_staff_ids = array_map( 'intval', (array) $product->get_staff_ids() );
		}

		$days_to_process = [];
		if ( 0 !== $tz_offset_seconds ) {
			$customer_day_slots = [];
			foreach ( $this->get_all_slots() as $slot ) {
				// For minute/hour, bucket by projection display_day (true customer civil date),
				// not by shifting fake-UTC start_ts and formatting in site TZ.
				if ( in_array( $duration_unit, [ 'minute', 'hour' ], true ) && is_string( $slot->display_day ) && '' !== $slot->display_day ) {
					$customer_date = $slot->display_day;
				} else {
					$shifted_ts    = $slot->start_ts + $tz_offset_seconds;
					$customer_date = gmdate( 'Y-m-d', $shifted_ts );
				}
				$customer_day_slots[ $customer_date ][] = $slot;
				if ( ! isset( $customer_day_ts_bounds[ $customer_date ] ) ) {
					$customer_day_ts_bounds[ $customer_date ] = [
						'min' => $slot->start_ts,
						'max' => $slot->start_ts,
					];
				} else {
					$customer_day_ts_bounds[ $customer_date ]['min'] = min( $customer_day_ts_bounds[ $customer_date ]['min'], $slot->start_ts );
					$customer_day_ts_bounds[ $customer_date ]['max'] = max( $customer_day_ts_bounds[ $customer_date ]['max'], $slot->start_ts );
				}
			}

			// Ensure we have entries for all days within the requested range,
			// plus adjacent bounds shifted by the offset to guarantee continuity.
			foreach ( $this->days as $day_key => $ds ) {
				$day_midnight = self::timestamp_site_midnight( $day_key );
				$shifted_ts   = $day_midnight + $tz_offset_seconds;
				// Seed missing keys to null so they get populated.
				$dk      = wp_date( 'Y-m-d', $shifted_ts );
				$dk_prev = wp_date( 'Y-m-d', $shifted_ts - DAY_IN_SECONDS );
				$dk_next = wp_date( 'Y-m-d', $shifted_ts + DAY_IN_SECONDS );
				if ( ! array_key_exists( $dk, $days_to_process ) ) {
					$days_to_process[ $dk ] = null;
				}
				if ( ! array_key_exists( $dk_prev, $days_to_process ) ) {
					$days_to_process[ $dk_prev ] = null;
				}
				if ( ! array_key_exists( $dk_next, $days_to_process ) ) {
					$days_to_process[ $dk_next ] = null;
				}
			}
			// Every customer date that has at least one slot (from display_day) must be processed
			// so day_data keys match the date picker (Y-n-j) for that day.
			foreach ( array_keys( $customer_day_slots ) as $ck ) {
				if ( ! array_key_exists( $ck, $days_to_process ) ) {
					$days_to_process[ $ck ] = null;
				}
			}
			
			ksort( $days_to_process );

			foreach ( array_keys( $days_to_process ) as $dk ) {
				if ( isset( $customer_day_slots[ $dk ] ) ) {
					$summary_slots = self::slots_for_day_summary( $product, $customer_day_slots[ $dk ] );
					$days_to_process[ $dk ] = empty( $summary_slots )
						? WC_Appointment_Day_Summary::unavailable( $dk )
						: WC_Appointment_Day_Summary::from_slots( $dk, $summary_slots );
				} else {
					$days_to_process[ $dk ] = WC_Appointment_Day_Summary::unavailable( $dk );
				}
			}
		} else {
			$days_to_process = $this->days;
		}

		foreach ( $days_to_process as $day_key => $day_summary ) {
			// $day_key is a civil calendar date (customer or site); format keys without strtotime()
			// (PHP default TZ) or wp_date() site bias on arbitrary instants.
			$legacy_key = wp_date(
				$date_format,
				( new DateTimeImmutable( $day_key . ' 00:00:00', new DateTimeZone( 'UTC' ) ) )->getTimestamp(),
				new DateTimeZone( 'UTC' )
			);

			// Compute day-level fields.
			$status       = $day_summary->status;
			$selectable   = ! in_array( $status, [ 'unavailable', 'fully_booked' ], true );
			$css_class    = self::status_to_css_class( $status );
			$occupancy    = $day_summary->occupancy_pct;
			$remaining    = self::occupancy_to_remaining_bucket( $occupancy );

			// i18n title.
			$title = self::status_to_title( $status );

			// Per-staff breakdown.
			$per_staff_data = [];
			$staff_to_check = $has_staff ? array_merge( [ 0 ], $all_staff_ids ) : [ 0 ];

			foreach ( $staff_to_check as $sid ) {
				$sid_key = (string) $sid;

				if ( isset( $day_summary->per_staff[ $sid_key ] ) ) {
					$s = $day_summary->per_staff[ $sid_key ];
					$s_status           = $s['status'] ?? 'available';
					$s_slots_available  = (int) ( $s['slots_available'] ?? 0 );
					$s_slots_total      = (int) ( $s['slots_total'] ?? 0 );
					$s_selectable       = ! in_array( $s_status, [ 'fully_booked' ], true ) && $s_slots_available > 0;
					$s_occupancy        = (int) ( $s['occupancy_pct'] ?? 0 );
					$s_remaining        = self::occupancy_to_remaining_bucket( $s_occupancy );
					// booked_slots = slots that are fully booked (no capacity available).
					$s_booked_slots     = max( 0, $s_slots_total - $s_slots_available );
					// slots_with_bookings = slots that have any appointments (for occupancy display).
					$s_with_bookings    = (int) ( $s['slots_with_bookings'] ?? 0 );

					$per_staff_data[ $sid ] = [
						'selectable'          => $s_selectable,
						'status'              => $s_status,
						'css_class'           => self::status_to_css_class( $s_status ),
						'occupancy_pct'       => $s_occupancy,
						'remaining_bucket'    => $s_remaining,
						'slots_available'     => $s_slots_available,
						'available_slots'     => $s_slots_available,
						'slots_total'         => $s_slots_total,
						'booked_slots'        => $s_booked_slots,
						'slots_with_bookings' => $s_with_bookings,
						'price'               => self::build_price_payload(
							$product,
							isset( $s['min_price'] ) ? $s['min_price'] : null,
							isset( $s['max_price'] ) ? $s['max_price'] : null,
							(bool) apply_filters(
								'woocommerce_appointments_date_picker_day_price_visible',
								null !== ( $s['min_price'] ?? null ) && null !== ( $s['max_price'] ?? null ),
								$product,
								$day_key,
								(int) $sid,
								[
									'min' => $s['min_price'] ?? null,
									'max' => $s['max_price'] ?? null,
								],
								$day_summary,
								$s
							),
							(int) $sid
						),
					];
				} else {
					// Staff has no slots for this day — they are unavailable (rules say they don't work).
					// Only use 'fully_booked' when the day itself is fully booked by appointments.
					$missing_status = ( 'fully_booked' === $status ) ? 'fully_booked' : 'unavailable';
					$per_staff_data[ $sid ] = [
						'selectable'          => false,
						'status'              => $missing_status,
						'css_class'           => self::status_to_css_class( $missing_status ),
						'occupancy_pct'       => 'fully_booked' === $missing_status ? 100 : 0,
						'remaining_bucket'    => 'fully_booked' === $missing_status ? 0 : 9,
						'slots_available'     => 0,
						'available_slots'     => 0,
						'slots_total'         => 0,
						'booked_slots'        => 0,
						'slots_with_bookings' => 0,
						'price'               => self::build_price_payload( $product, null, null, false ),
					];
				}
			}

			$entry = [
				'selectable'       => $selectable,
				'status'           => $status,
				'css_class'        => $css_class,
				'occupancy_pct'    => $occupancy,
				'remaining_bucket' => $remaining,
				'slots_count'      => $day_summary->slots_count,
				'available_slots'  => $day_summary->available_slots,
				'booked_slots'     => $day_summary->booked_slots,
				'first_slot'       => $day_summary->first_slot ?? '',
				'last_slot'        => $day_summary->last_slot ?? '',
				'price'            => self::build_price_payload(
					$product,
					$day_summary->min_price,
					$day_summary->max_price,
					(bool) apply_filters(
						'woocommerce_appointments_date_picker_day_price_visible',
						null !== $day_summary->min_price && null !== $day_summary->max_price,
						$product,
						$day_key,
						0,
						[
							'min' => $day_summary->min_price,
							'max' => $day_summary->max_price,
						],
						$day_summary,
						null
					),
					0
				),
				'per_staff'        => $per_staff_data,
				'title'            => $title,
				'padding'          => false,
				'restricted'       => false,
			];

			// Phase 11: Fold padding days into day_data.
			if ( ! empty( $padding_days ) && isset( $padding_days[ $legacy_key ] ) ) {
				$entry['padding'] = true;
				$entry['selectable'] = false;
				$entry['css_class'] = 'not_appointable';
				$entry['title'] = __( 'Unavailable', 'woocommerce-appointments' );
			}

			// Phase 11: Fold restricted weekdays into day_data.
			// restricted_days is an array of allowed weekdays (0-6). If day_of_week is NOT in it, day is restricted.
			if ( false !== $restricted_days && is_array( $restricted_days ) ) {
				$day_dt = new DateTimeImmutable( $day_key . ' 00:00:00', new DateTimeZone( 'UTC' ) );
				$day_of_week = (int) $day_dt->format( 'w' );
				if ( ! isset( $restricted_days[ $day_of_week ] ) ) {
					$entry['restricted'] = true;
					$entry['selectable'] = false;
					$entry['css_class'] = 'not_appointable';
					$entry['title'] = __( 'Unavailable', 'woocommerce-appointments' );
				}
			}

			if ( $customer_timezone && isset( $customer_day_ts_bounds[ $day_key ] )
				&& in_array( $product->get_duration_unit(), [ 'minute', 'hour' ], true ) ) {
				try {
					$tz_norm = function_exists( 'wc_appointments_normalize_timezone' )
						? wc_appointments_normalize_timezone( $customer_timezone )
						: $customer_timezone;
					$tz_c    = new DateTimeZone( $tz_norm );
					$entry['first_slot'] = ( new DateTimeImmutable( '@' . $customer_day_ts_bounds[ $day_key ]['min'] ) )->setTimezone( $tz_c )->format( 'H:i' );
					$entry['last_slot']  = ( new DateTimeImmutable( '@' . $customer_day_ts_bounds[ $day_key ]['max'] ) )->setTimezone( $tz_c )->format( 'H:i' );
				} catch ( Exception $e ) {
					// Leave site-time labels from day summary.
				}
			}

			// Don't overwrite a better entry (e.g., available > unavailable from tz shift).
			if ( isset( $day_data[ $legacy_key ] ) && $day_data[ $legacy_key ]['selectable'] && ! $selectable ) {
				continue;
			}
			$day_data[ $legacy_key ] = $entry;
		}

		return [ 'day_data' => $day_data ];
	}

	/**
	 * Build price payload for day or slot. Only shows price when it is a discount (min < base).
	 *
	 * @param WC_Product_Appointment $product    Product.
	 * @param float|null             $min_price  Min price.
	 * @param float|null             $max_price  Max price.
	 * @param bool                   $show_price Whether to consider showing price.
	 * @param int                    $staff_id   Staff ID for default price (0 = no staff). When set, price is only shown when min < default.
	 * @return array{show: bool, min: float, max: float, min_display: string, max_display: string, display: string}
	 */
	private static function build_price_payload( WC_Product_Appointment $product, ?float $min_price, ?float $max_price, bool $show_price, int $staff_id = 0 ): array {
		if ( ! $show_price || null === $min_price || null === $max_price ) {
			return [
				'show'        => false,
				'min'         => 0,
				'max'         => 0,
				'min_display' => '',
				'max_display' => '',
				'display'     => '',
			];
		}

		// Only display price when it is lower than base (discounted), same as slot picker.
		$default_price = WC_Appointment_Slots_Pricing::get_default_slot_price_raw( $product, $staff_id );
		$is_discounted = WC_Appointment_Slots_Pricing::is_slot_price_discounted( $min_price, $default_price );
		if ( ! $is_discounted ) {
			return [
				'show'        => false,
				'min'         => 0,
				'max'         => 0,
				'min_display' => '',
				'max_display' => '',
				'display'     => '',
			];
		}

		$min_display = WC_Appointment_Slots_Pricing::get_formatted_price( $min_price, $product );
		$max_display = WC_Appointment_Slots_Pricing::get_formatted_price( $max_price, $product );
		$display     = WC_Appointment_Slots_Pricing::format_discounted_cached( $default_price, $min_price, $product );
		if ( WC_Appointment_Slots_Pricing::is_price_different_from_default( $max_price, $min_price ) ) {
			$display .= ' - ' . $max_display;
		}

		return [
			'show'        => true,
			'min'         => $min_price,
			'max'         => $max_price,
			'min_display' => $min_display,
			'max_display' => $max_display,
			'display'     => $display,
		];
	}

	/**
	 * Map day status to CSS class for the date picker.
	 *
	 * @param string $status Day status.
	 * @return string CSS class.
	 */
	private static function status_to_css_class( string $status ): string {
		switch ( $status ) {
			case 'available':
				return 'appointable';
			case 'filling_fast':
				return 'partial_scheduled';
			case 'fully_booked':
				return 'fully_scheduled';
			case 'unavailable':
				return 'not_appointable';
			default:
				return 'not_appointable';
		}
	}

	/**
	 * Map day status to i18n title text.
	 *
	 * Uses wc_appointment_form_params i18n keys when available (frontend),
	 * falls back to English strings (PHP/REST contexts).
	 *
	 * @param string $status Day status.
	 * @return string Title text.
	 */
	private static function status_to_title( string $status ): string {
		switch ( $status ) {
			case 'available':
				return __( 'Available', 'woocommerce-appointments' );
			case 'filling_fast':
				return __( 'Partially Scheduled', 'woocommerce-appointments' );
			case 'fully_booked':
				return __( 'Fully Scheduled', 'woocommerce-appointments' );
			case 'unavailable':
				return __( 'Unavailable', 'woocommerce-appointments' );
			default:
				return __( 'Unavailable', 'woocommerce-appointments' );
		}
	}

	/**
	 * Convert occupancy percentage to remaining bucket (1-9 scale).
	 *
	 * Legacy compatibility: 1 = nearly full, 9 = nearly empty.
	 * Used by CSS classes like remaining_scheduled_5.
	 *
	 * @param int $occupancy_pct Occupancy 0-100.
	 * @return int Bucket 0-9 (0 = fully booked).
	 */
	private static function occupancy_to_remaining_bucket( int $occupancy_pct ): int {
		if ( $occupancy_pct >= 100 ) {
			return 0;
		}
		$remaining_pct = 100 - $occupancy_pct;
		$bucket        = (int) round( $remaining_pct / 10 );
		$bucket        = max( 1, min( 9, $bucket ) );
		return $bucket;
	}

	/**
	 * JSON serialization — full level by default.
	 *
	 * @return array<string, mixed>
	 */
	public function jsonSerialize(): array {
		return $this->for_level( 'full' );
	}
}
