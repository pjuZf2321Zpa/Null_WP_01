<?php
/**
 * Shared rules for which slot rows are valid “bookable starts” in UI lists.
 *
 * Storefront grouped time-slot HTML and admin day-slot chips must apply the
 * same predicate so minute/hour products do not show engine sub-segments
 * (shorter than the product booking duration) as separate pickable times.
 *
 * @package WooCommerce\Appointments\Slots
 * @since   5.3.6
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Display / listing rules for slot collections (no WordPress I/O).
 */
final class WC_Appointment_Slots_Display_Rules {

	/**
	 * Whether a slot is a valid bookable wall-clock start for minute/hour products.
	 *
	 * Mirrors the filter in `WC_Appointment_Slots_Collection::get_grouped_for_time_slots_display()`.
	 * Day/month/night units do not use this segment-length filter.
	 *
	 * @param string              $duration_unit             Product `get_duration_unit()`.
	 * @param int                 $product_duration_minutes Product `get_duration_in_minutes()`.
	 * @param WC_Appointment_Slot $slot                     Slot candidate.
	 */
	public static function is_bookable_start_for_time_product(
		string $duration_unit,
		int $product_duration_minutes,
		WC_Appointment_Slot $slot
	): bool {
		if ( in_array( $duration_unit, [ 'minute', 'hour' ], true )
			&& $slot->duration_minutes < $product_duration_minutes ) {
			return false;
		}
		return true;
	}
}
