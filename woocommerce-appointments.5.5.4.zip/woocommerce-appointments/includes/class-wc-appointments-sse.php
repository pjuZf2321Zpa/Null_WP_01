<?php
// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Core SSE support for WooCommerce Appointments.
 *
 * Captures appointment/availability changes and appends them to a bounded
 * transient-backed queue. The admin calendar consumes the stream via
 * admin-ajax; the v2 REST route delegates to `emit_stream()`.
 */
class WC_Appointments_SSE {

	/** Queue transient key. */
	public const TRANSIENT_KEY = 'wc_appointments_sse_events';
	/** Incremental ID option name. */
	public const OPTION_NEXT_ID = 'wc_appointments_sse_next_id';
	/** Max events kept in memory to bound storage. */
	public const MAX_EVENTS = 500;
	/** Transient TTL in seconds (15 minutes) for event queue. */
	public const TTL = 900;
	/**
	 * In-request dedupe: resource key => [topic, status].
	 *
	 * @var array<string, array{topic: string, status: string|null}>
	 */
	private static array $dedupe_cache = [];
	/**
	 * Request-scoped queue (null until loaded).
	 *
	 * @var list<array<string, mixed>>|null
	 */
	private static $events = null;
	/**
	 * Next event id (null until loaded); written once on flush.
	 *
	 * @var int|null
	 */
	private static $next_id = null;
	private static bool $queue_dirty = false;
	private static bool $shutdown_registered = false;

	public function __construct() {
		add_action( 'wp_ajax_wca_sse_stream', [ $this, 'handle_stream' ] );
		add_action( 'woocommerce_new_appointment', function( $id ): void {
			$this->push_event( 'appointment.created', 'appointment', (int) $id );
		}, 10, 1 );
		add_action( 'woocommerce_update_appointment', function( $id ): void {
			$this->push_event( 'appointment.updated', 'appointment', (int) $id );
		}, 10, 1 );
		add_action( 'woocommerce_appointment_status_changed', function( $from, $to, $id ): void {
			$this->push_event( 'appointment.updated', 'appointment', (int) $id, [ 'status' => (string) $to ] );
		}, 10, 3 );
		add_action( 'woocommerce_delete_appointment', function( $id ): void {
			$this->push_event( 'appointment.deleted', 'appointment', (int) $id );
		}, 10, 1 );
		add_action( 'woocommerce_trash_appointment', function( $id ): void {
			$this->push_event( 'appointment.trashed', 'appointment', (int) $id );
		}, 10, 1 );
		add_action( 'woocommerce_appointments_rescheduled_appointment', function( $id ): void {
			$this->push_event( 'appointment.rescheduled', 'appointment', (int) $id );
		}, 10, 1 );
		add_action( 'woocommerce_appointments_cancelled_appointment', function( $id ): void {
			$this->push_event( 'appointment.cancelled', 'appointment', (int) $id );
		}, 10, 1 );
		add_action( 'woocommerce_appointments_availability_created', function( $id ): void {
			$this->push_event( 'availability.created', 'availability', (int) $id );
		}, 10, 1 );
		add_action( 'woocommerce_appointments_availability_updated', function( $id, $availability, $changes ): void {
			$meaningful_changes = $this->get_meaningful_availability_changes( $changes );
			if ( ! empty( $meaningful_changes ) ) {
				$this->push_event( 'availability.updated', 'availability', (int) $id, $meaningful_changes );
			}
		}, 10, 3 );
		add_action( 'woocommerce_after_appointments_availability_object_delete', function( $id ): void {
			$this->push_event( 'availability.deleted', 'availability', (int) $id );
		}, 10, 1 );
		add_action( 'trashed_post', [ $this, 'on_trashed_post' ] );
		add_action( 'deleted_post', [ $this, 'on_deleted_post' ] );
		add_action( 'transition_post_status', [ $this, 'on_transition_post_status' ], 10, 3 );
	}


	
	/**
	 * Filter availability changes to only include meaningful ones
	 *
	 * @param array<string, mixed> $changes The changes array from the update
	 * @return array<string, mixed> Meaningful changes
	 */
	private function get_meaningful_availability_changes( $changes ) {
		if ( ! is_array( $changes ) || empty( $changes ) ) {
			return [];
		}

		// Fields that don't need toast notifications
		$ignored_fields = [
			'menu_order',      // Priority/ordering
			'sort',            // Sorting
			'position',        // Position
			'ordering',        // List drag order only
			'date_modified',   // Always updated on save
			'date_gmt',        // GMT date
			'modified',        // Modified timestamp
			'modified_gmt',    // GMT modified timestamp
			'kind_id',         // Changes when rules are reordered
		];

		$meaningful = [];
		foreach ( $changes as $field => $value ) {
			// Skip ignored fields
			if ( in_array( $field, $ignored_fields, true ) ) {
				continue;
			}
			
			// Include all other changes
			$meaningful[ $field ] = $value;
		}

		return $meaningful;
	}

	
	/**
	 * Build a compact appointment payload for SSE consumers.
	 *
	 * Constructs a lightweight array of appointment data for SSE consumption.
	 *
	 * @param int $id Appointment ID.
	 * @return array<string, mixed>
	 */
	protected function build_appointment_payload( $id ): array {
		try {
			$appointment = get_wc_appointment( (int) $id );
			if ( ! $appointment || ! $appointment->get_id() ) {
				return [];
			}
			$staff_ids = (array) $appointment->get_staff_ids();
			$staff_id_single = [] === $staff_ids ? 0 : (int) reset( $staff_ids );

			// Staff details.
			$staff_name   = '';
			$staff_avatar = '';
			if ( $staff_id_single ) {
				$staff_user = get_user_by( 'id', $staff_id_single );
				if ( $staff_user ) {
					$staff_name   = $staff_user->display_name;
					$staff_avatar = get_avatar_url( $staff_user->user_email, [ 'size' => 48 ] );
				}
			}

			// Product details.
			$product_id    = (int) $appointment->get_product_id();
			$product_title = '';
			$cal_color     = '';
			$duration_unit = '';
			$duration      = 0;
			if ( $product_id ) {
				$product_title = get_the_title( $product_id );
				$cal_color     = get_post_meta( $product_id, '_wc_appointment_cal_color', true );
				$product_obj   = wc_get_product( $product_id );
				if ( $product_obj && method_exists( $product_obj, 'get_duration_unit' ) ) {
					$duration_unit = (string) $product_obj->get_duration_unit();
					$duration      = method_exists( $product_obj, 'get_duration' ) ? (int) $product_obj->get_duration() : 0;
				}
			}
			if ( empty( $cal_color ) ) {
				$cal_color = 'var(--wp-admin-theme-color, #0073aa)';
			}

			// Order details (fetch first to use for customer fallback).
			$order_id   = (int) $appointment->get_order_id();
			$order_info = null;
			if ( $order_id && class_exists( 'WC_Appointment_Data_Store' ) ) {
				$orders_data = WC_Appointment_Data_Store::get_calendar_order_details( [ $order_id ] );
				if ( isset( $orders_data[ $order_id ] ) ) {
					$order_info = $orders_data[ $order_id ];
				}
			}

			// Customer details.
			$customer_id           = (int) $appointment->get_customer_id();
			$customer_name         = __( 'Guest', 'woocommerce-appointments' );
			$customer_first_name   = '';
			$customer_last_name    = '';
			$customer_full_name    = __( 'Guest', 'woocommerce-appointments' );
			$customer_avatar       = '';
			$customer_email        = '';
			$customer_phone        = '';

			// Try to get customer info from user first.
			if ( $customer_id ) {
				$customer_user = get_user_by( 'id', $customer_id );
				if ( $customer_user ) {
					$customer_first_name   = get_user_meta( $customer_id, 'first_name', true );
					$customer_last_name    = get_user_meta( $customer_id, 'last_name', true );
					$customer_display_name = $customer_user->display_name;
					$customer_email        = $customer_user->user_email;
					$customer_phone        = $customer_user->user_phone;
					
					$full_name = trim( $customer_first_name . ' ' . $customer_last_name );
					$customer_name      = '' !== $full_name ? $full_name : $customer_display_name;
					$customer_full_name = $full_name ?: $customer_display_name;
				}
			}

			// Fallback to order billing info if user data is missing.
			if ( ( empty( $customer_first_name ) && empty( $customer_last_name ) ) && $order_info && isset( $order_info['billing'] ) ) {
				$billing = $order_info['billing'];
				$customer_first_name = $billing['first_name'] ?? '';
				$customer_last_name  = $billing['last_name'] ?? '';
				$full_name           = trim( $customer_first_name . ' ' . $customer_last_name );

				if ( $full_name ) {
					$customer_full_name = $full_name;
					$customer_name      = $full_name;

					// Add (Guest) suffix if no customer ID.
					if ( ! $customer_id ) {
						/* translators: %s: Guest name */
						$customer_full_name = sprintf( _x( '%s (Guest)', 'Guest string with name from appointment order in brackets', 'woocommerce-appointments' ), $full_name );
						$customer_name      = $customer_full_name;
					}
				}

				if ( empty( $customer_email ) ) {
					$customer_email = $billing['email'] ?? '';
				}
				if ( empty( $customer_phone ) ) {
					$customer_phone = $billing['phone'] ?? '';
				}
			}
			
			if ( $customer_email ) {
				$customer_avatar = get_avatar_url( $customer_email, [ 'size' => 48 ] );
			}

			$payload = [
				'id'                  => (int) $appointment->get_id(),
				'start'               => (int) $appointment->get_start(),
				'end'                 => (int) $appointment->get_end(),
				'product_id'          => $product_id,
				'product_title'       => $product_title,
				'duration_unit'       => $duration_unit,
				'duration'            => $duration,
				'staff_ids'           => array_map( 'intval', $staff_ids ),
				'staff_id'            => $staff_id_single,
				'staff_name'          => $staff_name,
				'staff_avatar'        => $staff_avatar,
				'location_id'         => (int) $appointment->get_location_id(),
				'location_display'    => (string) $appointment->get_location_display(),
				'resource_display'    => (string) $appointment->get_resource_display(),
				'resource_allocations'=> $appointment->get_resource_allocations(),
				'status'              => (string) $appointment->get_status(),
				'creator_id'          => (int) $appointment->get_creator_id(),
				'customer_id'         => $customer_id,
				'customer_name'       => $customer_name,
				'customer_first_name' => $customer_first_name,
				'customer_last_name'  => $customer_last_name,
				'customer_full_name'  => $customer_full_name,
				'customer_avatar'     => $customer_avatar,
				'customer_email'      => $customer_email,
				'customer_phone'      => $customer_phone,
				'order_id'            => $order_id,
				'order_item_id'       => (int) $appointment->get_order_item_id(),
				'order_info'          => $order_info,
				'cost'                => (float) $appointment->get_cost(),
				'all_day'             => (bool) $appointment->get_all_day(),
				'qty'                 => (int) $appointment->get_qty(),
				'customer_status'     => (string) $appointment->get_customer_status(),
				'cal_color'           => (string) $cal_color,
				'local_timezone'      => (string) $appointment->get_local_timezone(),
				'customer_timezone'   => class_exists( 'WC_Appointments_Timezone_Helper' )
					? WC_Appointments_Timezone_Helper::get_appointment_customer_timezone( $appointment )
					: (string) $appointment->get_local_timezone(),
			];

			if ( class_exists( 'WC_Appointment_Series_Events' ) && WC_Appointment_Series_Events::is_enabled() ) {
				$series_id = (int) $appointment->get_meta( '_wca_series_id' );
				if ( $series_id > 0 ) {
					$payload['series_id']         = $series_id;
					$payload['series_occurrence'] = (int) $appointment->get_meta( '_wca_series_occurrence' );
					$payload                      = array_merge( $payload, WC_Appointment_Series::get_panel_preload_for_id( $series_id ) );
				}
			}

			return $payload;
		} catch ( \Exception $e ) {
			return [];
		}
	}

	/**
	 * Patch queued SSE payloads after series materialize + pay-first totals are ready.
	 *
	 * @param int $series_id Series ID.
	 */
	public static function refresh_series_payloads_in_queue( int $series_id ): void {
		if ( $series_id <= 0 || ! class_exists( 'WC_Appointment_Series' ) ) {
			return;
		}
		$preload = WC_Appointment_Series::get_panel_preload_for_id( $series_id );
		if ( empty( $preload['series_occurrences'] ) || ! is_array( $preload['series_occurrences'] ) ) {
			return;
		}
		$events = self::load_events();
		if ( ! $events ) {
			return;
		}
		$changed = false;
		foreach ( $events as $i => $evt ) {
			$payload = isset( $evt['payload'] ) && is_array( $evt['payload'] ) ? $evt['payload'] : null;
			if ( ! $payload || (int) ( $payload['series_id'] ?? 0 ) !== $series_id ) {
				continue;
			}
			$events[ $i ]['payload'] = array_merge( $payload, $preload );
			$changed                 = true;
		}
		if ( $changed ) {
			self::$events = $events;
			self::mark_dirty();
		}
	}

	/**
	 * @return list<array<string, mixed>> Event queue for this request.
	 */
	private static function load_events(): array {
		if ( null === self::$events ) {
			$stored       = get_transient( self::TRANSIENT_KEY );
			self::$events = is_array( $stored ) ? $stored : [];
		}
		return self::$events;
	}

	/**
	 * @param list<array<string, mixed>> $events Event list.
	 */
	private static function store_events( array $events ): void {
		self::$events = array_values( $events );
		self::mark_dirty();
	}

	private static function next_id(): int {
		if ( null === self::$next_id ) {
			self::$next_id = (int) get_option( self::OPTION_NEXT_ID, 1 );
		}
		$id            = (int) self::$next_id;
		self::$next_id = $id + 1;
		self::mark_dirty();
		return $id;
	}

	private static function mark_dirty(): void {
		self::$queue_dirty = true;
		if ( self::$shutdown_registered ) {
			return;
		}
		self::$shutdown_registered = true;
		register_shutdown_function( [ __CLASS__, 'flush_queue' ] );
	}

	/**
	 * Persist dirty queue + next_id once per request.
	 */
	public static function flush_queue(): void {
		if ( ! self::$queue_dirty ) {
			return;
		}
		if ( null !== self::$events ) {
			set_transient( self::TRANSIENT_KEY, self::$events, self::TTL );
		}
		if ( null !== self::$next_id ) {
			update_option( self::OPTION_NEXT_ID, (int) self::$next_id, false );
		}
		self::$queue_dirty = false;
	}

	/**
	 * Drop request-scoped queue state (integration tests; one long-lived PHP process).
	 */
	public static function reset_runtime_queue(): void {
		self::$events         = [];
		self::$dedupe_cache   = [];
		self::$queue_dirty    = false;
	}

	/**
	 * Queue one SSE event per resource per request. Status changes refresh that slot in place.
	 *
	 * @param string               $topic       Event topic.
	 * @param string               $resource    Resource type.
	 * @param int                  $resource_id Resource ID.
	 * @param array<string, mixed> $payload     Optional payload or status hint `['status' => ...]`.
	 * @return void
	 */
	protected function push_event( $topic, $resource, $resource_id, $payload = [] ) {
		/**
		 * Whether appointment/availability SSE events may be queued.
		 *
		 * Live PHPUnit loads WordPress once for the whole suite; disabling pushes
		 * avoids unbounded payload work without stripping shared WP/WC hooks.
		 *
		 * @param bool   $enabled     Default true.
		 * @param string $topic       Event topic.
		 * @param string $resource    Resource type.
		 * @param int    $resource_id Resource ID.
		 */
		if ( ! apply_filters( 'wc_appointments_sse_push_enabled', true, (string) $topic, (string) $resource, (int) $resource_id ) ) {
			return;
		}

		$resource_id = (int) $resource_id;
		$topic       = (string) $topic;
		$resource    = (string) $resource;
		$payload     = is_array( $payload ) ? $payload : [];
		$key         = $resource . ':' . $resource_id;
		$status_hint = isset( $payload['status'] ) ? (string) $payload['status'] : '';
		$needs_body  = ( 'appointment' === $resource && ! preg_match( '/\.(deleted|trashed)$/', $topic ) );
		$events      = self::load_events();

		// Already queued this request: skip, or refresh when status changes / terminal topic wins.
		if ( isset( self::$dedupe_cache[ $key ] ) ) {
			$prev         = self::$dedupe_cache[ $key ];
			$prev_status  = $prev['status'] ?? '';
			$terminal     = (bool) preg_match( '/\.(deleted|trashed|cancelled)$/', $topic );
			$status_changed = ( '' !== $status_hint && '' !== $prev_status && $status_hint !== $prev_status );
			if ( ! $terminal && ! $status_changed ) {
				return;
			}
			for ( $i = count( $events ) - 1; $i >= 0; $i-- ) {
				if ( $events[ $i ]['resource'] !== $resource || (int) $events[ $i ]['resource_id'] !== $resource_id ) {
					continue;
				}
				if ( $needs_body ) {
					$payload = $this->build_appointment_payload( $resource_id );
				}
				if ( $terminal || 'appointment.created' !== ( $events[ $i ]['topic'] ?? '' ) ) {
					$events[ $i ]['topic'] = $topic;
				}
				$events[ $i ]['payload'] = $payload;
				$events[ $i ]['ts']      = time();
				self::$dedupe_cache[ $key ] = [
					'topic'  => $events[ $i ]['topic'],
					'status' => isset( $payload['status'] ) ? (string) $payload['status'] : $status_hint,
				];
				self::store_events( $events );
				return;
			}
			return;
		}

		if ( $needs_body && ! isset( $payload['id'] ) ) {
			$payload = $this->build_appointment_payload( $resource_id );
		}
		$status = isset( $payload['status'] ) ? (string) $payload['status'] : $status_hint;
		self::$dedupe_cache[ $key ] = [ 'topic' => $topic, 'status' => $status ];

		$events[] = [
			'id'          => self::next_id(),
			'topic'       => $topic,
			'resource'    => $resource,
			'resource_id' => $resource_id,
			'payload'     => $payload,
			'ts'          => time(),
		];
		if ( self::MAX_EVENTS < count( $events ) ) {
			$events = array_slice( $events, -self::MAX_EVENTS );
		}
		self::store_events( $events );
	}

	/**
	 * Check if post is an appointment.
	 *
	 * Checks if the given post ID corresponds to an appointment.
	 *
	 * @param int $post_id Post ID.
	 * @return bool True if post is an appointment.
	 */
	protected function is_appointment_post( $post_id ) {
		$post_id = (int) $post_id;
		if (0 >= $post_id) {
            return false;
        }
		$post = get_post( $post_id );
		if (! $post) {
            return false;
        }
		return ( 'wc_appointment' === $post->post_type );
	}

	/**
	 * Handle trashed post.
	 *
	 * Handles the post trashed action.
	 *
	 * @param int $post_id Post ID.
	 */
	public function on_trashed_post( $post_id ): void {
		if ( $this->is_appointment_post( $post_id ) ) {
			$this->push_event( 'appointment.trashed', 'appointment', (int) $post_id );
		}
	}

	/**
	 * Handle deleted post.
	 *
	 * Handles the post deleted action.
	 *
	 * @param int $post_id Post ID.
	 */
	public function on_deleted_post( $post_id ): void {
		if ( $this->is_appointment_post( $post_id ) ) {
			$this->push_event( 'appointment.deleted', 'appointment', (int) $post_id );
		}
	}

	/**
	 * Handle post status transition.
	 *
	 * Handles post status transitions.
	 *
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Post object.
	 */
	public function on_transition_post_status( $new_status, $old_status, $post ): void {
		if ( $post && 'wc_appointment' === $post->post_type && ('trash' === $new_status && 'trash' !== $old_status) ) {
			$this->push_event( 'appointment.trashed', 'appointment', (int) $post->ID );
		}
	}

	/**
	 * Admin AJAX permission gate for the calendar SSE stream.
	 */
	public function handle_stream(): void {
		if ( ! is_user_logged_in() || ! ( current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_appointments' ) ) ) {
			status_header( 403 );
			echo "retry: 10000\n\n";
			exit;
		}
		self::emit_stream();
	}

	/**
	 * Shared queue is global; staff get own rows only, contact fields gated at emit.
	 *
	 * @param array<int, array<string, mixed>> $events Raw queue events.
	 * @return array<int, array<string, mixed>>
	 */
	public static function filter_events_for_current_user( array $events ): array {
		$user_id = get_current_user_id();
		if ( ! WC_Appointments_Staff_Permissions::is_staff_user( $user_id ) ) {
			return $events;
		}

		$contact = WC_Appointments_Staff_Permissions::can( $user_id, 'contact_customers' );
		$out     = [];

		foreach ( $events as $ev ) {
			if ( ! is_array( $ev ) ) {
				continue;
			}
			$payload = isset( $ev['payload'] ) && is_array( $ev['payload'] ) ? $ev['payload'] : [];

			if ( 'appointment' === ( $ev['resource'] ?? '' ) ) {
				$ids = array_map( 'intval', (array) ( $payload['staff_ids'] ?? [] ) );
				if ( ! in_array( $user_id, $ids, true ) && (int) ( $payload['creator_id'] ?? 0 ) !== $user_id ) {
					continue;
				}
			}

			if ( $payload && ! $contact ) {
				$payload['customer_email'] = '';
				$payload['customer_phone'] = '';
				if ( isset( $payload['order_info']['billing'] ) ) {
					$payload['order_info']['billing']['email'] = '';
					$payload['order_info']['billing']['phone'] = '';
				}
			}
			$ev['payload'] = $payload;
			$out[]         = $ev;
		}

		return $out;
	}

	/**
	 * Client reconnect delay for one-shot SSE (ms). Shared by stream framing and calendar localize.
	 *
	 * @return int At least 1000.
	 */
	public static function get_retry_ms(): int {
		/**
		 * Minimum delay before the admin calendar reconnects after a one-shot SSE response.
		 *
		 * @param int $retry_ms Default 15000.
		 */
		$retry_ms = (int) apply_filters( 'wc_appointments_sse_retry_ms', 15000 );
		return max( 1000, $retry_ms );
	}

	/**
	 * One-shot SSE output shared by admin-ajax and REST consumers.
	 */
	public static function emit_stream(): void {
		self::flush_queue();

		nocache_headers();
		header( 'Content-Type: text/event-stream' );
		header( 'Cache-Control: no-cache' );
		header( 'Connection: keep-alive' );
		header( 'X-Accel-Buffering: no' );
		@ini_set( 'zlib.output_compression', '0' );
		@ini_set( 'output_buffering', '0' );

		$since = 0;
		$since_raw = filter_input( INPUT_GET, 'since_id' );
		if ( null !== $since_raw ) {
			$since = absint( $since_raw );
		} elseif ( isset( $_SERVER['HTTP_LAST_EVENT_ID'] ) ) {
			$since = absint( wp_unslash( $_SERVER['HTTP_LAST_EVENT_ID'] ) );
		}

		$retry_ms = self::get_retry_ms();
		// Complete SSE field block so EventSource applies retry even when no events follow.
		echo 'retry: ' . (int) $retry_ms . "\n\n";
		$events = null !== self::$events ? self::$events : get_transient( self::TRANSIENT_KEY );
		$events = self::filter_events_for_current_user( is_array( $events ) ? $events : [] );
		if ( [] === $events ) {
			@flush();
			exit;
		}

		$max = 50;
		$sent = 0;
		foreach ( $events as $ev ) {
			if ($ev['id'] <= $since) {
                continue;
            }
			$payload = [
				'topic' => $ev['topic'],
				'resource' => $ev['resource'],
				'resource_id' => $ev['resource_id'],
				'payload' => $ev['payload'],
				'ts' => $ev['ts'],
			];
			echo 'id: ' . (int) $ev['id'] . "\n";
			$topic = preg_replace( '/[^A-Za-z0-9_.\-]/', '', (string) $ev['topic'] );
			echo 'event: ' . esc_html( $topic ) . "\n";
			echo 'data: ' . wp_json_encode( $payload ) . "\n\n";
			$sent++;
			if ($sent >= $max) {
                break;
            }
		}
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			@fastcgi_finish_request();
		} else {
			@flush();
		}
		exit;
	}
}

add_action( 'plugins_loaded', function(): void {
    if ( class_exists( 'WooCommerce' ) ) {
        new WC_Appointments_SSE();
    }
}, 20 );
