<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 11.1.0
 */

use Automattic\WooCommerce\Internal\ProductGallery\ProductMediaGallery;

defined( 'ABSPATH' ) || exit;

global $post, $product, $woocommerce, $nectar_options;

$product_gallery_style = (!empty($nectar_options['single_product_gallery_type'])) ? $nectar_options['single_product_gallery_type'] : 'default';

if( in_array($product_gallery_style, array('left_thumb_sticky','two_column_images')) ) {
	wp_enqueue_script('stickykit');
}

if( in_array($product_gallery_style, array('ios_slider','left_thumb_sticky')) ) {
	wp_enqueue_script('flickity');
}

// In case product is called from product_page shortcode
wp_enqueue_style( 'nectar-woocommerce-single' );

wp_enqueue_script('nectar-single-product');

if( isset( $nectar_options['product_reviews_style'] ) &&
    'off_canvas' === $nectar_options['product_reviews_style'] ) {
  wp_enqueue_script('nectar-single-product-reviews');
}

$gallery_thumbnail_size = nectar_woo_gallery_thumbnail_size();


if( in_array($product_gallery_style, array('ios_slider','left_thumb_sticky','left_thumb_slider')) ) {

	$media_items      = nectar_woo_gallery_media_items( $product );
	$secondary_media  = array_slice( $media_items, 1 );

	$has_gallery_imgs = ( ! empty( $secondary_media ) ) ? 'true' : 'false';

	$slider_container_class       = 'flickity';
	$slider_thumb_container_class = 'flickity';
	$slider_wrap_class            = 'slider';
	$slider_slide_class           = 'slide';


	$wrapper_classes   = apply_filters( 'woocommerce_single_product_image_gallery_classes', array(
		'woocommerce-product-gallery',
		'woocommerce-product-gallery--' . ( ! empty( $media_items ) ? 'with-images' : 'without-images' ),
		'images'
	) );

	// Add click event class for left_thumb_sticky gallery style.
	if ( 'left_thumb_sticky' === $product_gallery_style ) {
		$click_event = (isset($nectar_options['single_product_left_thumb_sticky_click_event']) && !empty($nectar_options['single_product_left_thumb_sticky_click_event'])) ? $nectar_options['single_product_left_thumb_sticky_click_event'] : 'default';
		$wrapper_classes[] = 'click-event--' . $click_event;
	}

	?>
    <div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" data-has-gallery-imgs="<?php echo esc_attr( $has_gallery_imgs ); ?>">

    	<div class="<?php echo esc_attr($slider_container_class); ?> product-slider">


				<div class="<?php echo esc_attr($slider_wrap_class); ?> generate-markup">

					<?php
					foreach ( $media_items as $media_index => $media_item ) {
						echo nectar_woo_gallery_slide_html( $media_item, array(
							'gallery_style' => $product_gallery_style,
							'main_media'    => ( 0 === $media_index ),
						) );
					}

					if ( empty( $media_items ) ) {
						echo '<div class="'.esc_attr($slider_slide_class).'">'.apply_filters( 'woocommerce_single_product_image_html', sprintf( '<img src="%s" alt="%s" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_attr__( 'Placeholder', 'woocommerce' ) ), $post->ID ) .'</div>';
					}
					?>

			</div>
		</div>

		<?php if ( ! empty( $secondary_media ) ) {  ?>

				<?php if('left_thumb_slider' === $product_gallery_style) {
					$visible_class = (sizeof($secondary_media) > 4) ? ' visible' : '';
					echo '<div class="product-thumbs-wrap'. esc_attr($visible_class) .'"><div class="button-prev"><i class="fa fa-angle-up" aria-hidden="true"></i></div>';
				} ?>

				<div class="<?php echo esc_attr($slider_thumb_container_class); ?> product-thumbs">
					<div class="<?php echo esc_attr($slider_wrap_class); ?> generate-markup">
							<?php
							$thumb_size = apply_filters('single_product_small_thumbnail_size', $gallery_thumbnail_size);

							foreach ( $media_items as $media_index => $media_item ) {
								echo nectar_woo_gallery_thumb_html( $media_item, array(
									'size'       => $thumb_size,
									'main_media' => ( 0 === $media_index ),
								) );
							}
							?>
					</div>
				</div>
				<?php

				if('left_thumb_slider' === $product_gallery_style) {
					echo '<div class="button-next"><i class="fa fa-angle-down" aria-hidden="true"></i></div></div>';
				}

			}
			?>
	</div>

<?php
} // End custom bottom thumbnail slider/left thumbnail.

// Two column gallery markup.
else if( 'two_column_images' === $product_gallery_style ) {

	global $product;

	$post_thumbnail_id = $product->get_image_id();
	$media_items       = nectar_woo_gallery_media_items( $product );
	$secondary_media   = array_slice( $media_items, 1 );
	$has_gallery_imgs  = ! empty( $secondary_media );

	$wrapper_classes    = apply_filters( 'woocommerce_single_product_image_gallery_classes', array(
		'woocommerce-product-gallery',
		'woocommerce-product-gallery--' . ( ! empty( $media_items ) ? 'with-images' : 'without-images' ),
		'images',
		'woocommerce-product-gallery-with-' . ( true === $has_gallery_imgs ? 'multiple-images' : 'single-image')
	) ); ?>

	<div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>">
		<div class="woocommerce-product-gallery__wrapper">
		<?php
		foreach ( $media_items as $media_index => $media_item ) {

			$is_main_media = ( 0 === $media_index );

			// The featured image keeps WooCommerce's own gallery markup in this style.
			if ( ! nectar_woo_gallery_media_is_video( $media_item ) && $is_main_media && has_post_thumbnail() ) {
				echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', wc_get_gallery_image_html( $post_thumbnail_id, true ), $product->get_image_id() );
				continue;
			}

			echo nectar_woo_gallery_slide_html( $media_item, array(
				'gallery_style' => $product_gallery_style,
				'main_media'    => $is_main_media,
			) );
		}

		if ( empty( $media_items ) ) {
			echo '<div class="woocommerce-product-gallery__image--placeholder">';
			echo sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'woocommerce' ) );
			echo '</div>';
		}
		?>
	</div>
	</div>

	<?php
} // End two column gallery markup.

// Default WooCommerce gallery functionality.
else { ?>


	<?php
	// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior.
	// This branch tracks WooCommerce's own product-image.php so it stays diffable against upstream; don't route it through the theme's gallery helpers.
	if( function_exists( 'wc_get_gallery_image_html' ) ) {

		global $product;

		$columns           = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
		$post_thumbnail_id = $product->get_image_id();
		$first_media_item  = array();
		$first_media_id    = $post_thumbnail_id;
		$has_media         = has_post_thumbnail();
		$is_video          = false;

		// Product gallery videos (WC 11.0+); the helper returns the full gallery order and product-thumbnails.php renders the rest.
		// Both methods are @internal with no BC guarantee, so both are probed and the calls are wrapped: a changed
		// signature or a throw falls back to the pre-11 featured image rather than taking the product page down.
		if ( class_exists( ProductMediaGallery::class ) &&
		     method_exists( ProductMediaGallery::class, 'get_product_media_gallery_items_for_display' ) &&
		     method_exists( ProductMediaGallery::class, 'get_gallery_video_html' ) ) {
			try {
				$media_items      = ProductMediaGallery::get_product_media_gallery_items_for_display( $product );
				$media_items      = is_array( $media_items ) ? $media_items : array();
				$first_media_item = ( isset( $media_items[0] ) && is_array( $media_items[0] ) ) ? $media_items[0] : array();
				$first_media_id   = ( isset( $first_media_item['id'] ) && is_scalar( $first_media_item['id'] ) ) ? absint( $first_media_item['id'] ) : $post_thumbnail_id;
				$has_media        = ! empty( $first_media_item ) && 'placeholder' !== ( $first_media_item['source_type'] ?? '' );
				$is_video         = $has_media && 'video' === ( $first_media_item['media_type'] ?? '' );
			} catch ( \Throwable $e ) {
				$first_media_item = array();
				$first_media_id   = $post_thumbnail_id;
				$has_media        = (bool) $post_thumbnail_id;
				$is_video         = false;
			}
		}

		$wrapper_classes   = apply_filters( 'woocommerce_single_product_image_gallery_classes', array(
			'woocommerce-product-gallery',
			'woocommerce-product-gallery--' . ( $has_media ? 'with-images' : 'without-images' ),
			'woocommerce-product-gallery--columns-' . absint( $columns ),
			'default-woo-gallery',
			'images',
		) );
		?>
		<div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" data-columns="<?php echo esc_attr( $columns ); ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
			<div class="woocommerce-product-gallery__wrapper">
				<?php
				if ( $is_video ) {
					try {
						$html = ProductMediaGallery::get_gallery_video_html( $first_media_item, true );
					} catch ( \Throwable $e ) {
						$html = '';
					}
				} elseif ( $has_media && $first_media_id ) {
					$html = wc_get_gallery_image_html( $first_media_id, true );
				} else {
					$wrapper_classname = $product->is_type( 'variable' ) && method_exists($product,'get_visible_children') && ! empty( $product->get_visible_children() ) && '' !== $product->get_price() ?
						'woocommerce-product-gallery__image woocommerce-product-gallery__image--placeholder' :
						'woocommerce-product-gallery__image--placeholder';
					$html              = sprintf( '<div class="%s">', esc_attr( $wrapper_classname ) );
					$html             .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'woocommerce' ) );
					$html             .= '</div>';
				}

				if ( $is_video ) {
					/**
					 * Filter product video thumbnail HTML string.
					 *
					 * @since 11.0.0
					 * @internal For exclusive usage of WooCommerce core, backwards compatibility not guaranteed.
					 *
					 * @param string $html          Product video thumbnail HTML string.
					 * @param int    $attachment_id Video attachment ID.
					 * @param array  $media_item    Product media gallery item.
					 */
					echo apply_filters( 'woocommerce_single_product_video_thumbnail_html', $html, $first_media_id, $first_media_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				} else {
					/**
					 * Filter product image thumbnail HTML string.
					 *
					 * @since 1.6.4
					 *
					 * @param string $html          Product image thumbnail HTML string.
					 * @param int    $attachment_id Attachment ID.
					 */
					echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $first_media_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}

				do_action( 'woocommerce_product_thumbnails' );
				?>
			</div>
		</div>


		<?php

	} ?>


 <?php } ?>
