<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="23,8 10,8 10,63 54,63 54,8 41,8 "/>
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="36,5 36,1 28,1 28,5 24,5 22,13 42,13 40,5 
	"/>
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" points="32,41 25.875,45 
	28,38 22,34 29.213,34 32,26 35,34 42,34 36,38 37.938,45 "/>
</svg>
