<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="55,24 22,24 22,12 55,12 62,18 "/>
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="9,28 42,28 42,40 9,40 2,34 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="40" x2="32" y2="64"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="28" x2="32" y2="24"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="12" x2="32" y2="7"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="24" y1="63" x2="40" y2="63"/>
</svg>
