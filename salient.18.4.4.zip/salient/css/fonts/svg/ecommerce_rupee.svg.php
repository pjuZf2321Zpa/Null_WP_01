<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M53.92,10.081c12.107,12.105,12.107,31.732,0,43.838
	c-12.106,12.108-31.734,12.108-43.84,0c-12.107-12.105-12.107-31.732,0-43.838C22.186-2.027,41.813-2.027,53.92,10.081z"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M36,50L21,36v-1h7c0,0,11,1,11-9c0-9-11-9-11-9h-8"
	/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="20" y1="17" x2="44" y2="17"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="20" y1="23" x2="44" y2="23"/>
</svg>
