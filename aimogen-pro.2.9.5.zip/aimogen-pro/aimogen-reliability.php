<?php
defined('ABSPATH') or die();

/**
 * Aimogen Reliability Mode and smart API-key rotation.
 *
 * This upgrades the existing fallback-model hook without changing its legacy
 * behaviour unless Reliability Mode is explicitly enabled. When enabled,
 * fallback models are tried in administrator-defined order, incompatible
 * models are skipped, temporarily failing models/providers are cooled down,
 * and unhealthy credentials are removed from rotation until they recover.
 */

if (!function_exists('aimogen_reliability_settings')) {
    function aimogen_reliability_settings($settings = null)
    {
        if (!is_array($settings)) {
            $settings = get_option('aiomatic_Main_Settings', array());
        }
        return is_array($settings) ? $settings : array();
    }
}

if (!function_exists('aimogen_reliability_enabled')) {
    function aimogen_reliability_enabled($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        return isset($settings['reliability_mode']) && $settings['reliability_mode'] === 'on';
    }
}

if (!function_exists('aimogen_reliability_model_list')) {
    function aimogen_reliability_model_list($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $raw = isset($settings['fallback_models']) ? trim((string) $settings['fallback_models']) : '';
        if ($raw === '') {
            return array();
        }

        $models = preg_split('/\r\n|\r|\n/', $raw);
        $models = array_map('trim', is_array($models) ? $models : array());
        $models = array_values(array_filter($models));

        return $models;
    }
}

if (!function_exists('aimogen_reliability_scope')) {
    function aimogen_reliability_scope($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $scope = isset($settings['reliability_scope']) ? (string) $settings['reliability_scope'] : 'cross_provider';
        return $scope === 'same_provider' ? 'same_provider' : 'cross_provider';
    }
}

if (!function_exists('aimogen_reliability_max_attempts')) {
    function aimogen_reliability_max_attempts($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $attempts = isset($settings['reliability_max_attempts']) ? absint($settings['reliability_max_attempts']) : 2;
        return max(1, min(5, $attempts));
    }
}

if (!function_exists('aimogen_reliability_cooldown_minutes')) {
    function aimogen_reliability_cooldown_minutes($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $minutes = isset($settings['reliability_cooldown']) ? absint($settings['reliability_cooldown']) : 10;
        return max(1, min(60, $minutes));
    }
}

if (!function_exists('aimogen_reliability_apply_retry_budget')) {
    function aimogen_reliability_apply_retry_budget($settings)
    {
        $settings = aimogen_reliability_settings($settings);
        if (!aimogen_reliability_enabled($settings)) {
            return $settings;
        }

        $fallback_count = count(aimogen_reliability_model_list($settings));
        if ($fallback_count === 0) {
            return $settings;
        }

        $reliability_retries = min($fallback_count, aimogen_reliability_max_attempts($settings));
        $existing_retries = isset($settings['max_retry']) && is_numeric($settings['max_retry'])
            ? max(0, (int) $settings['max_retry'])
            : 0;

        // This changes only the request-local settings copy. It never
        // overwrites the administrator's general retry preference.
        $settings['max_retry'] = max($existing_retries, $reliability_retries);
        return $settings;
    }
}

if (!function_exists('aimogen_reliability_provider_for_model')) {
    function aimogen_reliability_provider_for_model($model, $settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $model = trim((string) $model);

        if (function_exists('aiomatic_is_google_model') && aiomatic_is_google_model($model)) {
            return 'google';
        }
        if (function_exists('aiomatic_is_claude_model') && aiomatic_is_claude_model($model)) {
            return 'claude';
        }
        if (function_exists('aiomatic_is_openrouter_model') && aiomatic_is_openrouter_model($model)) {
            return 'openrouter';
        }
        if (function_exists('aiomatic_is_huggingface_model') && aiomatic_is_huggingface_model($model)) {
            return 'huggingface';
        }
        if (function_exists('aiomatic_is_ollama_model') && aiomatic_is_ollama_model($model)) {
            return 'ollama';
        }
        if (function_exists('aiomatic_is_perplexity_model') && aiomatic_is_perplexity_model($model)) {
            return 'perplexity';
        }
        if (function_exists('aiomatic_is_groq_model') && aiomatic_is_groq_model($model)) {
            return 'groq';
        }
        if (function_exists('aiomatic_is_nvidia_model') && aiomatic_is_nvidia_model($model)) {
            return 'nvidia';
        }
        if (function_exists('aiomatic_is_together_model') && aiomatic_is_together_model($model)) {
            return 'together';
        }
        if (function_exists('aiomatic_is_mistral_model') && aiomatic_is_mistral_model($model)) {
            return 'mistral';
        }
        if (function_exists('aiomatic_is_deepseek_model') && aiomatic_is_deepseek_model($model)) {
            return 'deepseek';
        }
        if (function_exists('aiomatic_is_fireworks_model') && aiomatic_is_fireworks_model($model)) {
            return 'fireworks';
        }
        if (function_exists('aiomatic_is_xai_model') && aiomatic_is_xai_model($model)) {
            return 'xai';
        }
        if (function_exists('aiomatic_is_custom_model') && aiomatic_is_custom_model($model, $settings)) {
            return 'custom';
        }

        $selector = isset($settings['api_selector']) ? (string) $settings['api_selector'] : 'openai';
        if ($selector === 'azure') {
            return 'azure';
        }
        if ($selector === 'custom') {
            return 'custom';
        }
        return 'openai';
    }
}

if (!function_exists('aimogen_reliability_provider_label')) {
    function aimogen_reliability_provider_label($provider)
    {
        $labels = array(
            'openai' => 'OpenAI / AiomaticAPI',
            'azure' => 'Microsoft Azure',
            'custom' => 'Custom OpenAI-compatible API',
            'claude' => 'Anthropic Claude',
            'google' => 'Google Gemini',
            'openrouter' => 'OpenRouter',
            'huggingface' => 'HuggingFace',
            'ollama' => 'Ollama',
            'perplexity' => 'Perplexity',
            'groq' => 'Groq',
            'nvidia' => 'NVIDIA',
            'together' => 'Together AI',
            'mistral' => 'Mistral AI',
            'deepseek' => 'DeepSeek',
            'fireworks' => 'Fireworks AI',
            'xai' => 'xAI',
        );
        return isset($labels[$provider]) ? $labels[$provider] : ucfirst((string) $provider);
    }
}

if (!function_exists('aimogen_reliability_provider_key_field')) {
    function aimogen_reliability_provider_key_field($provider)
    {
        $fields = array(
            'openai' => 'app_id',
            'azure' => 'app_id',
            'custom' => 'app_id',
            'claude' => 'app_id_claude',
            'google' => 'app_id_google',
            'openrouter' => 'app_id_openrouter',
            'huggingface' => 'app_id_huggingface',
            'perplexity' => 'app_id_perplexity',
            'groq' => 'app_id_groq',
            'nvidia' => 'app_id_nvidia',
            'together' => 'app_id_together',
            'mistral' => 'app_id_mistral',
            'deepseek' => 'app_id_deepseek',
            'fireworks' => 'app_id_fireworks',
            'xai' => 'app_id_xai',
        );
        return isset($fields[$provider]) ? $fields[$provider] : '';
    }
}

if (!function_exists('aimogen_reliability_provider_configured')) {
    function aimogen_reliability_provider_configured($provider, $settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        if ($provider === 'ollama') {
            return isset($settings['ollama_url']) && trim((string) $settings['ollama_url']) !== '';
        }

        $field = aimogen_reliability_provider_key_field($provider);
        return $field !== '' && isset($settings[$field]) && trim((string) $settings[$field]) !== '';
    }
}

if (!function_exists('aimogen_smart_key_rotation_enabled')) {
    function aimogen_smart_key_rotation_enabled($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        if (!aimogen_reliability_enabled($settings)) {
            return false;
        }

        // Existing Reliability Mode users receive the safer behaviour without
        // a migration. The settings form writes an explicit "off" when the
        // administrator disables this option.
        return !isset($settings['smart_key_rotation']) || $settings['smart_key_rotation'] === 'on';
    }
}

if (!function_exists('aimogen_smart_key_cooldown_minutes')) {
    function aimogen_smart_key_cooldown_minutes($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $minutes = isset($settings['smart_key_cooldown']) ? absint($settings['smart_key_cooldown']) : 10;
        return max(1, min(120, $minutes));
    }
}

if (!function_exists('aimogen_smart_key_quarantine_hours')) {
    function aimogen_smart_key_quarantine_hours($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $hours = isset($settings['smart_key_quarantine']) ? absint($settings['smart_key_quarantine']) : 6;
        return max(1, min(24, $hours));
    }
}

if (!function_exists('aimogen_smart_parse_key_list')) {
    function aimogen_smart_parse_key_list($raw, $unique = true)
    {
        $keys = preg_split('/\r\n|\r|\n/', trim((string) $raw));
        $keys = array_values(array_filter(array_map('trim', is_array($keys) ? $keys : array()), 'strlen'));
        if (!$unique) {
            return $keys;
        }

        $result = array();
        $seen = array();
        foreach ($keys as $key) {
            $fingerprint = aimogen_smart_key_fingerprint($key);
            if ($fingerprint === '' || isset($seen[$fingerprint])) {
                continue;
            }
            $seen[$fingerprint] = true;
            $result[] = $key;
        }
        return $result;
    }
}

if (!function_exists('aimogen_smart_key_fingerprint')) {
    function aimogen_smart_key_fingerprint($token)
    {
        $token = trim((string) $token);
        if ($token === '') {
            return '';
        }

        if (function_exists('wp_salt')) {
            $salt = wp_salt('auth');
        } elseif (defined('AUTH_SALT') && AUTH_SALT !== '') {
            $salt = AUTH_SALT;
        } elseif (defined('AIMOGEN_VERSION')) {
            $salt = 'aimogen|' . AIMOGEN_VERSION;
        } else {
            $salt = 'aimogen-key-health';
        }
        return hash_hmac('sha256', $token, (string) $salt);
    }
}

if (!function_exists('aimogen_smart_key_state_transient')) {
    function aimogen_smart_key_state_transient($fingerprint)
    {
        return 'aimogen_key_health_' . substr(preg_replace('/[^a-f0-9]/', '', (string) $fingerprint), 0, 40);
    }
}

if (!function_exists('aimogen_smart_get_key_state')) {
    function aimogen_smart_get_key_state($fingerprint)
    {
        if ($fingerprint === '') {
            return false;
        }
        $state = get_transient(aimogen_smart_key_state_transient($fingerprint));
        if (!is_array($state) || empty($state['cooldown_until'])) {
            return false;
        }
        if ((int) $state['cooldown_until'] <= time()) {
            delete_transient(aimogen_smart_key_state_transient($fingerprint));
            return false;
        }
        return $state;
    }
}

if (!function_exists('aimogen_smart_clear_key_state')) {
    function aimogen_smart_clear_key_state($fingerprint)
    {
        if ($fingerprint !== '') {
            delete_transient(aimogen_smart_key_state_transient($fingerprint));
        }
    }
}

if (!function_exists('aimogen_smart_error_text')) {
    function aimogen_smart_error_text($error, $depth = 0)
    {
        if ($depth > 5 || $error === null || $error === false) {
            return '';
        }
        if (is_scalar($error)) {
            return (string) $error;
        }
        if (function_exists('is_wp_error') && is_wp_error($error)) {
            $parts = $error->get_error_messages();
            foreach ($error->get_error_codes() as $code) {
                $parts[] = (string) $code;
                $parts[] = aimogen_smart_error_text($error->get_error_data($code), $depth + 1);
            }
            return trim(implode(' ', array_filter($parts, 'strlen')));
        }
        if (is_object($error)) {
            if (method_exists($error, 'getAll')) {
                try {
                    return aimogen_smart_error_text($error->getAll(), $depth + 1);
                } catch (Throwable $throwable) {
                    // Continue with the object's public representation.
                }
            }
            if (method_exists($error, 'toArray')) {
                try {
                    return aimogen_smart_error_text($error->toArray(), $depth + 1);
                } catch (Throwable $throwable) {
                    // Continue with the object's public representation.
                }
            }
            if (method_exists($error, '__toString')) {
                return (string) $error;
            }
            $error = get_object_vars($error);
        }
        if (is_array($error)) {
            $parts = array();
            foreach ($error as $key => $value) {
                if (is_string($key)) {
                    $parts[] = $key;
                }
                $parts[] = aimogen_smart_error_text($value, $depth + 1);
                if (strlen(implode(' ', $parts)) > 12000) {
                    break;
                }
            }
            return trim(implode(' ', array_filter($parts, 'strlen')));
        }
        return '';
    }
}

if (!function_exists('aimogen_smart_retry_after_value')) {
    function aimogen_smart_retry_after_value($value)
    {
        if (is_object($value)) {
            if (method_exists($value, 'getAll')) {
                try {
                    $value = $value->getAll();
                } catch (Throwable $throwable) {
                    $value = get_object_vars($value);
                }
            } elseif (method_exists($value, 'toArray')) {
                try {
                    $value = $value->toArray();
                } catch (Throwable $throwable) {
                    $value = get_object_vars($value);
                }
            } else {
                $value = get_object_vars($value);
            }
        }
        if (is_array($value)) {
            $maximum = 0;
            foreach ($value as $item) {
                $maximum = max($maximum, aimogen_smart_retry_after_value($item));
            }
            return $maximum;
        }
        if (is_numeric($value)) {
            return max(0, min(DAY_IN_SECONDS, (int) ceil((float) $value)));
        }
        if (!is_string($value)) {
            return 0;
        }
        $value = trim($value);
        if ($value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            return max(0, min(DAY_IN_SECONDS, (int) ceil((float) $value)));
        }
        if (preg_match('/^([0-9]+(?:\.[0-9]+)?)\s*(milliseconds?|ms|seconds?|secs?|s|minutes?|mins?|m)$/i', $value, $matches)) {
            $seconds = (float) $matches[1];
            $unit = strtolower($matches[2]);
            if ($unit === 'ms' || strpos($unit, 'millisecond') === 0) {
                $seconds /= 1000;
            } elseif ($unit === 'm' || strpos($unit, 'min') === 0) {
                $seconds *= MINUTE_IN_SECONDS;
            }
            return max(1, min(DAY_IN_SECONDS, (int) ceil($seconds)));
        }
        $timestamp = strtotime($value);
        if ($timestamp !== false && $timestamp > time()) {
            return min(DAY_IN_SECONDS, $timestamp - time());
        }
        return 0;
    }
}

if (!function_exists('aimogen_smart_retry_after_seconds')) {
    function aimogen_smart_retry_after_seconds($error, $depth = 0)
    {
        if ($depth > 6 || $error === null || $error === false) {
            return 0;
        }
        if (function_exists('is_wp_error') && is_wp_error($error)) {
            $maximum = 0;
            foreach ($error->get_error_codes() as $code) {
                $maximum = max($maximum, aimogen_smart_retry_after_seconds($error->get_error_data($code), $depth + 1));
            }
            $error = implode(' ', $error->get_error_messages());
            if ($maximum > 0) {
                return $maximum;
            }
        }
        if (is_object($error)) {
            if (method_exists($error, 'getAll')) {
                try {
                    $error = $error->getAll();
                } catch (Throwable $throwable) {
                    $error = get_object_vars($error);
                }
            } elseif (method_exists($error, 'toArray')) {
                try {
                    $error = $error->toArray();
                } catch (Throwable $throwable) {
                    $error = get_object_vars($error);
                }
            } else {
                $error = get_object_vars($error);
            }
        }
        if (is_array($error)) {
            $maximum = 0;
            foreach ($error as $key => $value) {
                $normalized = strtolower(str_replace(array('_', ' '), '-', (string) $key));
                if ($normalized === 'retry-after' || substr($normalized, -11) === 'reset-after') {
                    $maximum = max($maximum, aimogen_smart_retry_after_value($value));
                } elseif (strpos($normalized, 'ratelimit') !== false && strpos($normalized, 'reset') !== false) {
                    if (is_numeric($value) && (float) $value > DAY_IN_SECONDS) {
                        $numeric = (float) $value;
                        if ($numeric > time()) {
                            $maximum = max($maximum, min(DAY_IN_SECONDS, (int) ceil($numeric - time())));
                        }
                    } else {
                        $maximum = max($maximum, aimogen_smart_retry_after_value($value));
                    }
                }
                $maximum = max($maximum, aimogen_smart_retry_after_seconds($value, $depth + 1));
            }
            return min(DAY_IN_SECONDS, $maximum);
        }

        $text = is_scalar($error) ? (string) $error : '';
        if ($text === '') {
            return 0;
        }
        if (preg_match('/(?:try again|retry)[^0-9]{0,30}([0-9]+(?:\.[0-9]+)?)\s*(milliseconds?|ms|seconds?|secs?|s|minutes?|mins?|m)\b/i', $text, $matches)) {
            $seconds = (float) $matches[1];
            $unit = strtolower($matches[2]);
            if ($unit === 'ms' || strpos($unit, 'millisecond') === 0) {
                $seconds /= 1000;
            } elseif ($unit === 'm' || strpos($unit, 'min') === 0) {
                $seconds *= MINUTE_IN_SECONDS;
            }
            return max(1, min(DAY_IN_SECONDS, (int) ceil($seconds)));
        }
        if (preg_match('/retry[-_ ]?after\s*:?\s*([A-Z][a-z]{2},\s*[0-9]{1,2}\s+[A-Z][a-z]{2}\s+[0-9]{4}\s+[0-9:]{8}\s+GMT)/i', $text, $matches)) {
            return aimogen_smart_retry_after_value($matches[1]);
        }
        if (preg_match('/retry[-_ ]?after[^0-9]{0,20}([0-9]+(?:\.[0-9]+)?)/i', $text, $matches)) {
            return aimogen_smart_retry_after_value($matches[1]);
        }
        return 0;
    }
}

if (!function_exists('aimogen_smart_mark_key_failure')) {
    function aimogen_smart_mark_key_failure($fingerprint, $provider, $category, $error = '', $settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        if (!aimogen_smart_key_rotation_enabled($settings) || $fingerprint === '') {
            return false;
        }
        if (!in_array($category, array('retry_failure', 'rate_limit', 'authentication', 'permission', 'quota'), true)) {
            return false;
        }

        $cooldown = aimogen_smart_key_cooldown_minutes($settings) * MINUTE_IN_SECONDS;
        $status = 'cooldown';
        if ($category === 'retry_failure') {
            // An inner retry path does not always expose the provider error.
            // A short hold prevents immediate key reuse without treating an
            // unknown request/model failure as a credential problem.
            $cooldown = min($cooldown, MINUTE_IN_SECONDS);
        } elseif ($category === 'rate_limit') {
            $cooldown = max($cooldown, aimogen_smart_retry_after_seconds($error));
        } elseif ($category === 'authentication' || $category === 'quota') {
            $status = 'quarantined';
            $cooldown = aimogen_smart_key_quarantine_hours($settings) * HOUR_IN_SECONDS;
        }
        $cooldown = max(1, min(DAY_IN_SECONDS, (int) $cooldown));

        $old_state = aimogen_smart_get_key_state($fingerprint);
        $until = time() + $cooldown;
        if (is_array($old_state) && isset($old_state['cooldown_until'])) {
            $until = max($until, (int) $old_state['cooldown_until']);
            if (isset($old_state['status']) && $old_state['status'] === 'quarantined') {
                $status = 'quarantined';
                if ($category === 'retry_failure' && !empty($old_state['category'])) {
                    $category = (string) $old_state['category'];
                }
            }
        }
        $state = array(
            'provider' => sanitize_key((string) $provider),
            'category' => sanitize_key((string) $category),
            'status' => $status,
            'failure_count' => is_array($old_state) && isset($old_state['failure_count']) ? (int) $old_state['failure_count'] + 1 : 1,
            'failed_at' => time(),
            'cooldown_until' => $until,
        );
        set_transient(
            aimogen_smart_key_state_transient($fingerprint),
            $state,
            max(1, $until - time())
        );
        do_action('aimogen_smart_key_state_changed', $fingerprint, $state);
        return $state;
    }
}

if (!function_exists('aimogen_smart_provider_for_key_list')) {
    function aimogen_smart_provider_for_key_list($raw, $token = '', $settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $raw = trim((string) $raw);
        $token = trim((string) $token);
        $providers = array('claude', 'google', 'openrouter', 'huggingface', 'perplexity', 'groq', 'nvidia', 'together', 'mistral', 'deepseek', 'fireworks', 'xai');
        foreach ($providers as $provider) {
            $field = aimogen_reliability_provider_key_field($provider);
            if ($field === '' || !isset($settings[$field])) {
                continue;
            }
            $configured_raw = trim((string) $settings[$field]);
            if ($configured_raw === $raw || ($token !== '' && in_array($token, aimogen_smart_parse_key_list($configured_raw), true))) {
                return $provider;
            }
        }

        if (isset($settings['app_id'])) {
            $configured_raw = trim((string) $settings['app_id']);
            if ($configured_raw === $raw || ($token !== '' && in_array($token, aimogen_smart_parse_key_list($configured_raw), true))) {
                $selector = isset($settings['api_selector']) ? (string) $settings['api_selector'] : 'openai';
                return in_array($selector, array('azure', 'custom'), true) ? $selector : 'openai';
            }
        }
        return '';
    }
}

if (!function_exists('aimogen_smart_note_selected_key')) {
    function aimogen_smart_note_selected_key($token, $provider = '')
    {
        $fingerprint = aimogen_smart_key_fingerprint($token);
        $context = aimogen_reliability_current_context();
        if ($fingerprint === '' || !is_array($context)) {
            return $fingerprint;
        }
        $context['current_key_id'] = $fingerprint;
        $context['current_key_provider'] = sanitize_key((string) $provider);
        if (!isset($context['attempted_key_ids']) || !is_array($context['attempted_key_ids'])) {
            $context['attempted_key_ids'] = array();
        }
        if (!in_array($fingerprint, $context['attempted_key_ids'], true)) {
            $context['attempted_key_ids'][] = $fingerprint;
        }
        aimogen_reliability_update_context($context);
        return $fingerprint;
    }
}

if (!function_exists('aimogen_smart_select_key')) {
    function aimogen_smart_select_key($raw, $current_token = '', $provider = '', $failure_error = null, $failure_explicit = false)
    {
        $settings = aimogen_reliability_settings();
        $keys = aimogen_smart_parse_key_list($raw, true);
        if (empty($keys)) {
            return trim((string) $current_token);
        }
        if ($provider === '') {
            $provider = aimogen_smart_provider_for_key_list($raw, $current_token, $settings);
        }

        $current_token = trim((string) $current_token);
        $current_id = aimogen_smart_key_fingerprint($current_token);
        $context = aimogen_reliability_current_context();

        if ($failure_explicit) {
            $failed_id = $current_id;
            if (is_array($context) && isset($context['current_key_id'], $context['current_key_provider']) &&
                ($provider === '' || (string) $context['current_key_provider'] === $provider)) {
                $failed_id = (string) $context['current_key_id'];
            }
            $category = $failure_explicit && $failure_error !== null
                ? aimogen_reliability_classify_error($failure_error)
                : 'retry_failure';
            aimogen_smart_mark_key_failure($failed_id, $provider, $category, $failure_error, $settings);
            if (is_array($context)) {
                $context['last_key_failure_signature'] = hash('sha256', $failed_id . '|' . $category . '|' . aimogen_smart_error_text($failure_error));
                $context['last_rotated_failed_key_id'] = $failed_id;
                $context['last_rotated_failed_key_provider'] = sanitize_key((string) $provider);
                aimogen_reliability_update_context($context);
            }
        }

        $candidates = array();
        $recovering = array();
        $deferred_attempts = array();
        $attempted_ids = is_array($context) && isset($context['attempted_key_ids']) && is_array($context['attempted_key_ids'])
            ? $context['attempted_key_ids']
            : array();
        foreach ($keys as $key) {
            $fingerprint = aimogen_smart_key_fingerprint($key);
            if ($current_id !== '' && hash_equals($current_id, $fingerprint) && count($keys) > 1) {
                continue;
            }
            $state = aimogen_smart_get_key_state($fingerprint);
            if (count($keys) > 1 && in_array($fingerprint, $attempted_ids, true)) {
                $deferred_attempts[] = array(
                    'key' => $key,
                    'until' => is_array($state) && isset($state['cooldown_until']) ? (int) $state['cooldown_until'] : 0,
                );
                continue;
            }
            if ($state === false) {
                $candidates[] = $key;
            } else {
                $recovering[] = array('key' => $key, 'until' => (int) $state['cooldown_until']);
            }
        }

        if (!empty($candidates)) {
            $selected = $candidates[array_rand($candidates)];
        } elseif (!empty($recovering)) {
            usort($recovering, function ($left, $right) {
                return $left['until'] <=> $right['until'];
            });
            $selected = $recovering[0]['key'];
        } elseif (!empty($deferred_attempts)) {
            usort($deferred_attempts, function ($left, $right) {
                return $left['until'] <=> $right['until'];
            });
            $selected = $deferred_attempts[0]['key'];
        } elseif ($current_token !== '') {
            $selected = $current_token;
        } else {
            $selected = $keys[array_rand($keys)];
        }
        aimogen_smart_note_selected_key($selected, $provider);
        return $selected;
    }
}

if (!function_exists('aimogen_smart_select_initial_key')) {
    function aimogen_smart_select_initial_key($raw, $provider = '')
    {
        if (!aimogen_smart_key_rotation_enabled()) {
            // Match the long-standing provider adapters exactly: they trim
            // the whole setting, filter blank lines and preserve each line's
            // original whitespace and duplicate weighting.
            $legacy_keys = preg_split('/\r\n|\r|\n/', trim((string) $raw));
            $legacy_keys = array_filter(is_array($legacy_keys) ? $legacy_keys : array());
            return empty($legacy_keys) ? '' : $legacy_keys[array_rand($legacy_keys)];
        }
        $keys = aimogen_smart_parse_key_list($raw, true);
        if (empty($keys)) {
            return '';
        }
        return aimogen_smart_select_key($raw, '', $provider);
    }
}

if (!function_exists('aimogen_smart_filter_api_key')) {
    function aimogen_smart_filter_api_key($token)
    {
        static $running = false;
        if ($running || !aimogen_smart_key_rotation_enabled()) {
            return $token;
        }
        $settings = aimogen_reliability_settings();
        $provider = aimogen_smart_provider_for_key_list('', $token, $settings);
        if ($provider === '') {
            $context = aimogen_reliability_current_context();
            if (is_array($context)) {
                $context_provider = isset($context['current_key_provider']) ? (string) $context['current_key_provider'] : '';
                if (!in_array($context_provider, array('openai', 'azure', 'custom'), true)) {
                    $selector = isset($settings['api_selector']) ? (string) $settings['api_selector'] : 'openai';
                    $context_provider = in_array($selector, array('azure', 'custom'), true) ? $selector : 'openai';
                }
                aimogen_smart_note_selected_key($token, $context_provider);
            }
            return $token;
        }

        $field = aimogen_reliability_provider_key_field($provider);
        if ($field === '' || !isset($settings[$field])) {
            return $token;
        }
        $fingerprint = aimogen_smart_key_fingerprint($token);
        if (aimogen_smart_get_key_state($fingerprint) === false) {
            aimogen_smart_note_selected_key($token, $provider);
            return $token;
        }

        $running = true;
        $selected = aimogen_smart_select_key($settings[$field], $token, $provider);
        $running = false;
        return $selected;
    }
}
add_filter('aimogen_openai_api_key', 'aimogen_smart_filter_api_key', 999);
add_filter('aiomatic_openai_api_key', 'aimogen_smart_filter_api_key', 999);

if (!function_exists('aimogen_smart_filter_provider_api_key')) {
    function aimogen_smart_filter_provider_api_key($token)
    {
        if (!aimogen_smart_key_rotation_enabled() || !function_exists('current_filter')) {
            return $token;
        }
        $providers = array(
            'aimogen_anthropic_api_key' => 'claude',
            'aiomatic_anthropic_api_key' => 'claude',
            'aimogen_google_api_key' => 'google',
            'aiomatic_google_api_key' => 'google',
            'aimogen_openrouter_api_key' => 'openrouter',
            'aiomatic_openrouter_api_key' => 'openrouter',
            'aimogen_huggingface_api_key' => 'huggingface',
            'aiomatic_huggingface_api_key' => 'huggingface',
            'aimogen_perplexity_api_key' => 'perplexity',
            'aiomatic_perplexity_api_key' => 'perplexity',
            'aimogen_groq_api_key' => 'groq',
            'aiomatic_groq_api_key' => 'groq',
            'aimogen_nvidia_api_key' => 'nvidia',
            'aiomatic_nvidia_api_key' => 'nvidia',
            'aimogen_xai_api_key' => 'xai',
            'aimogen_together_api_key' => 'together',
            'aiomatic_together_api_key' => 'together',
            'aimogen_mistral_api_key' => 'mistral',
            'aiomatic_mistral_api_key' => 'mistral',
            'aimogen_deepseek_api_key' => 'deepseek',
            'aiomatic_deepseek_api_key' => 'deepseek',
            'aimogen_fireworks_api_key' => 'fireworks',
            'aiomatic_fireworks_api_key' => 'fireworks',
            'aiomatic_xai_api_key' => 'xai',
        );
        $hook = current_filter();
        if (!isset($providers[$hook])) {
            return $token;
        }
        $provider = $providers[$hook];
        $settings = aimogen_reliability_settings();
        $field = aimogen_reliability_provider_key_field($provider);
        $keys = $field !== '' && isset($settings[$field])
            ? aimogen_smart_parse_key_list($settings[$field], true)
            : array();

        if (in_array(trim((string) $token), $keys, true) &&
            aimogen_smart_get_key_state(aimogen_smart_key_fingerprint($token)) !== false) {
            return aimogen_smart_select_key($settings[$field], $token, $provider, null, false);
        }
        // Provider-key filters may deliberately supply a key that is not in
        // settings. Track only its salted fingerprint for this request and
        // never replace the external filter's choice.
        aimogen_smart_note_selected_key($token, $provider);
        return $token;
    }
}
foreach (array(
    'aimogen_anthropic_api_key',
    'aiomatic_anthropic_api_key',
    'aimogen_google_api_key',
    'aiomatic_google_api_key',
    'aimogen_openrouter_api_key',
    'aiomatic_openrouter_api_key',
    'aimogen_huggingface_api_key',
    'aiomatic_huggingface_api_key',
    'aimogen_perplexity_api_key',
    'aiomatic_perplexity_api_key',
    'aimogen_groq_api_key',
    'aiomatic_groq_api_key',
    'aimogen_nvidia_api_key',
    'aiomatic_nvidia_api_key',
    'aimogen_xai_api_key',
    'aiomatic_xai_api_key',
    'aimogen_together_api_key',
    'aiomatic_together_api_key',
    'aimogen_mistral_api_key',
    'aiomatic_mistral_api_key',
    'aimogen_deepseek_api_key',
    'aiomatic_deepseek_api_key',
    'aimogen_fireworks_api_key',
    'aiomatic_fireworks_api_key',
) as $aimogen_provider_key_filter) {
    add_filter($aimogen_provider_key_filter, 'aimogen_smart_filter_provider_api_key', 999);
}
unset($aimogen_provider_key_filter);

if (!function_exists('aimogen_smart_provider_has_healthy_keys')) {
    function aimogen_smart_provider_has_healthy_keys($provider, $settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $field = aimogen_reliability_provider_key_field($provider);
        if ($field === '' || !isset($settings[$field])) {
            return false;
        }
        foreach (aimogen_smart_parse_key_list($settings[$field], true) as $key) {
            if (aimogen_smart_get_key_state(aimogen_smart_key_fingerprint($key)) === false) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('aimogen_smart_key_health_summary')) {
    function aimogen_smart_key_health_summary($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $selector = isset($settings['api_selector']) ? (string) $settings['api_selector'] : 'openai';
        $primary_provider = in_array($selector, array('azure', 'custom'), true) ? $selector : 'openai';
        $providers = array($primary_provider, 'claude', 'google', 'openrouter', 'huggingface', 'perplexity', 'groq', 'nvidia', 'together', 'mistral', 'deepseek', 'fireworks', 'xai');
        $summary = array();

        foreach ($providers as $provider) {
            $field = aimogen_reliability_provider_key_field($provider);
            if ($field === '' || !isset($settings[$field])) {
                continue;
            }
            $keys = aimogen_smart_parse_key_list($settings[$field], true);
            if (empty($keys)) {
                continue;
            }
            $row = array(
                'provider' => $provider,
                'label' => aimogen_reliability_provider_label($provider),
                'configured' => count($keys),
                'healthy' => 0,
                'cooldown' => 0,
                'quarantined' => 0,
                'next_recovery' => 0,
            );
            foreach ($keys as $key) {
                $state = aimogen_smart_get_key_state(aimogen_smart_key_fingerprint($key));
                if ($state === false) {
                    $row['healthy']++;
                    continue;
                }
                if (isset($state['status']) && $state['status'] === 'quarantined') {
                    $row['quarantined']++;
                } else {
                    $row['cooldown']++;
                }
                $until = isset($state['cooldown_until']) ? (int) $state['cooldown_until'] : 0;
                if ($until > 0 && ($row['next_recovery'] === 0 || $until < $row['next_recovery'])) {
                    $row['next_recovery'] = $until;
                }
            }
            $summary[] = $row;
        }
        return $summary;
    }
}

if (!function_exists('aimogen_smart_reset_key_health')) {
    function aimogen_smart_reset_key_health($settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $fingerprints = array();
        foreach (array('openai', 'azure', 'custom', 'claude', 'google', 'openrouter', 'huggingface', 'perplexity', 'groq', 'nvidia', 'together', 'mistral', 'deepseek', 'fireworks', 'xai') as $provider) {
            $field = aimogen_reliability_provider_key_field($provider);
            if ($field === '' || !isset($settings[$field])) {
                continue;
            }
            foreach (aimogen_smart_parse_key_list($settings[$field], true) as $key) {
                $fingerprints[aimogen_smart_key_fingerprint($key)] = true;
            }
        }
        foreach (array_keys($fingerprints) as $fingerprint) {
            aimogen_smart_clear_key_state($fingerprint);
        }
        return count($fingerprints);
    }
}

if (!function_exists('aimogen_smart_reset_key_health_ajax')) {
    function aimogen_smart_reset_key_health_ajax()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => esc_html__('You are not allowed to reset API key health.', 'aiomatic-automatic-ai-content-writer')), 403);
        }
        check_ajax_referer('aimogen_reset_key_health', 'nonce');
        $count = aimogen_smart_reset_key_health();
        wp_send_json_success(array(
            'message' => sprintf(
                /* translators: %d: number of configured API keys reset */
                _n('%d API key health record was reset.', '%d API key health records were reset.', $count, 'aiomatic-automatic-ai-content-writer'),
                $count
            ),
        ));
    }
}
add_action('wp_ajax_aimogen_reset_key_health', 'aimogen_smart_reset_key_health_ajax');

if (!function_exists('aimogen_reliability_context_stack')) {
    function &aimogen_reliability_context_stack()
    {
        if (!isset($GLOBALS['aimogen_reliability_context_stack']) || !is_array($GLOBALS['aimogen_reliability_context_stack'])) {
            $GLOBALS['aimogen_reliability_context_stack'] = array();
        }
        return $GLOBALS['aimogen_reliability_context_stack'];
    }
}

if (!function_exists('aimogen_reliability_current_context')) {
    function aimogen_reliability_current_context()
    {
        $stack = &aimogen_reliability_context_stack();
        if (empty($stack)) {
            return false;
        }
        return $stack[count($stack) - 1];
    }
}

if (!function_exists('aimogen_reliability_update_context')) {
    function aimogen_reliability_update_context($context)
    {
        $stack = &aimogen_reliability_context_stack();
        if (!empty($stack) && is_array($context)) {
            $stack[count($stack) - 1] = $context;
        }
    }
}

if (!function_exists('aimogen_reliability_content_text')) {
    function aimogen_reliability_content_text($content)
    {
        if (is_string($content)) {
            return $content;
        }
        if (!is_array($content)) {
            return '';
        }

        $text = '';
        foreach ($content as $message) {
            if (!is_array($message) || !isset($message['content'])) {
                continue;
            }
            if (is_string($message['content'])) {
                $text .= $message['content'] . "\n";
            } elseif (is_array($message['content'])) {
                foreach ($message['content'] as $part) {
                    if (is_array($part) && isset($part['type'], $part['text']) && $part['type'] === 'text') {
                        $text .= (string) $part['text'] . "\n";
                    }
                }
            }
        }
        return trim($text);
    }
}

if (!function_exists('aimogen_reliability_begin_request')) {
    function aimogen_reliability_begin_request($model, $content, $vision_file = '', $forced_functions = array(), $stream = false, $env = '', $enabled_mcp_servers = '', $is_chat = true, $has_api_token = false, $api_token = '')
    {
        $settings = aimogen_reliability_settings();
        $fallbacks = aimogen_reliability_model_list($settings);
        if (!aimogen_reliability_enabled($settings) || (empty($fallbacks) && !aimogen_smart_key_rotation_enabled($settings))) {
            return false;
        }

        $text = aimogen_reliability_content_text($content);
        $original_provider = aimogen_reliability_provider_for_model($model, $settings);
        $context = array(
            'id' => md5((string) microtime(true) . '|' . wp_rand() . '|' . (string) $model),
            'original_model' => (string) $model,
            'current_model' => (string) $model,
            'original_provider' => $original_provider,
            'original_provider_configured' => aimogen_reliability_provider_configured(
                $original_provider,
                $settings
            ) || (bool) $has_api_token,
            'attempted' => array((string) $model),
            'events' => array(),
            'fallbacks_used' => 0,
            'requires_vision' => !empty($vision_file),
            'requires_tools' => !empty($forced_functions) || !empty($enabled_mcp_servers),
            'is_chat' => (bool) $is_chat,
            'stream' => (bool) $stream,
            'environment' => sanitize_key((string) $env),
            'current_key_id' => '',
            'current_key_provider' => '',
            'attempted_key_ids' => array(),
            'last_key_failure_signature' => '',
            'last_rotated_failed_key_id' => '',
            'last_rotated_failed_key_provider' => '',
            // Four characters/token avoids a second full tokenizer pass and is
            // sufficiently conservative for capability routing.
            'prompt_tokens' => (int) ceil(strlen($text) / 4),
        );
        if (aimogen_smart_key_rotation_enabled($settings) && is_string($api_token) && trim($api_token) !== '') {
            $context['current_key_id'] = aimogen_smart_key_fingerprint($api_token);
            $context['current_key_provider'] = $original_provider;
            $context['attempted_key_ids'][] = $context['current_key_id'];
        }

        $stack = &aimogen_reliability_context_stack();
        $stack[] = $context;
        return true;
    }
}

if (!function_exists('aimogen_reliability_model_cooldown_key')) {
    function aimogen_reliability_model_cooldown_key($model)
    {
        return 'aimogen_rel_model_' . md5((string) $model);
    }
}

if (!function_exists('aimogen_reliability_provider_cooldown_key')) {
    function aimogen_reliability_provider_cooldown_key($provider)
    {
        return 'aimogen_rel_provider_' . md5((string) $provider);
    }
}

if (!function_exists('aimogen_reliability_is_cooled_down')) {
    function aimogen_reliability_is_cooled_down($model, $settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        $model_state = get_transient(aimogen_reliability_model_cooldown_key($model));
        $provider = aimogen_reliability_provider_for_model($model, $settings);
        $provider_state = get_transient(aimogen_reliability_provider_cooldown_key($provider));
        return $model_state !== false || $provider_state !== false;
    }
}

if (!function_exists('aimogen_reliability_classify_error')) {
    function aimogen_reliability_classify_error($error)
    {
        $error = aimogen_smart_error_text($error);
        $low = function_exists('mb_strtolower') ? mb_strtolower($error) : strtolower($error);

        $groups = array(
            'safety' => array('content_filter', 'content policy', 'content_policy', 'safety filter', 'prohibited_content', 'responsible ai', 'was blocked by', 'finishreason":"safety', 'finish_reason":"safety', 'block_reason":"safety', 'blocked_reason":"safety', 'safety ratings'),
            'context' => array('context_length_exceeded', 'maximum context length', 'context window', 'prompt is too long', 'request_too_large', 'too many tokens'),
            'quota' => array('insufficient_quota', 'exceeded your current quota', 'insufficient funds', 'insufficient credits', 'out of credits', 'payment required', 'billing'),
            'authentication' => array('invalid_api_key', 'incorrect api key', 'invalid api key', 'authentication_error', 'invalid x-api-key', 'api_key_invalid', 'unauthorized', 'http 401', 'error code: 401'),
            'permission' => array('permission_error', 'permission denied', 'permission_denied', 'does not have access', 'insufficient permission', 'not authorized to access', 'http 403', 'error code: 403'),
            'model' => array('model_not_found', 'model not found', 'no such model', 'unknown model', 'has been deprecated', 'no longer available', 'invalid model', 'no endpoints found'),
            'rate_limit' => array('rate limit', 'rate-limit', 'ratelimit', 'rate-limited', 'too many requests', 'resource_exhausted', 'requests per minute', 'tokens per minute', 'http 429', 'error code: 429', 'status code 429'),
            'network' => array('could not resolve host', 'failed to connect', 'connection refused', 'connection timed out', 'network is unreachable', 'ssl connect error', 'unable to connect'),
            'provider' => array('overloaded', 'api_error', 'internal server error', 'server_error', 'service unavailable', 'temporarily unavailable', 'bad gateway', 'gateway timeout', 'timed out', 'timeout_error', 'deadline_exceeded', 'http 500', 'http 502', 'http 503', 'http 504', 'error code: 500', 'error code: 502', 'error code: 503', 'error code: 504', '529'),
        );

        foreach ($groups as $category => $tokens) {
            foreach ($tokens as $token) {
                if ($token !== '' && strpos($low, $token) !== false) {
                    return $category;
                }
            }
        }
        return trim($low) === '' ? 'network' : 'unknown';
    }
}

if (!function_exists('aimogen_reliability_mark_failure')) {
    function aimogen_reliability_mark_failure($model, $category, $error, $settings = null)
    {
        $settings = aimogen_reliability_settings($settings);
        if (in_array($category, array('safety', 'context', 'unknown'), true)) {
            return;
        }
        $provider = aimogen_reliability_provider_for_model($model, $settings);
        if (aimogen_smart_key_rotation_enabled($settings) &&
            in_array($category, array('rate_limit', 'authentication', 'permission', 'quota'), true) &&
            aimogen_smart_provider_has_healthy_keys($provider, $settings)) {
            return;
        }

        $minutes = aimogen_reliability_cooldown_minutes($settings);
        $state = array(
            'category' => $category,
            'until' => time() + ($minutes * MINUTE_IN_SECONDS),
        );
        set_transient(aimogen_reliability_model_cooldown_key($model), $state, $minutes * MINUTE_IN_SECONDS);

        // Repeated transient service failures activate a provider-wide circuit
        // breaker. Credential, quota and model errors stay model-scoped because
        // an installation can have multiple keys or model-specific access.
        $provider_categories = array('network', 'provider');
        if ($category === 'rate_limit') {
            // A rate-limited credential is not a provider outage while another
            // configured key remains healthy.
            if (!aimogen_smart_key_rotation_enabled($settings) || !aimogen_smart_provider_has_healthy_keys($provider, $settings)) {
                $provider_categories[] = 'rate_limit';
            }
        }
        if (in_array($category, $provider_categories, true)) {
            $provider = aimogen_reliability_provider_for_model($model, $settings);
            $failure_key = 'aimogen_rel_failures_' . md5($provider);
            $failures = (int) get_transient($failure_key) + 1;
            set_transient($failure_key, $failures, $minutes * MINUTE_IN_SECONDS);
            if ($failures >= 2) {
                set_transient(
                    aimogen_reliability_provider_cooldown_key($provider),
                    $state,
                    $minutes * MINUTE_IN_SECONDS
                );
            }
        }
    }
}

if (!function_exists('aimogen_reliability_model_is_compatible')) {
    function aimogen_reliability_model_is_compatible($candidate, $context)
    {
        $candidate = trim((string) $candidate);
        if ($candidate === '' || !is_array($context)) {
            return false;
        }

        $settings = aimogen_reliability_settings();
        $provider = aimogen_reliability_provider_for_model($candidate, $settings);
        $uses_original_token = $provider === $context['original_provider'] && !empty($context['original_provider_configured']);
        if (!aimogen_reliability_provider_configured($provider, $settings) && !$uses_original_token) {
            return false;
        }
        if (aimogen_reliability_scope($settings) === 'same_provider' && $provider !== $context['original_provider']) {
            return false;
        }
        if (aimogen_reliability_is_cooled_down($candidate, $settings)) {
            return false;
        }

        static $available_models = null;
        if ($available_models === null) {
            $available_models = function_exists('aiomatic_get_all_models') ? aiomatic_get_all_models(false) : array();
            $available_models = is_array($available_models) ? $available_models : array();
        }
        if (!empty($available_models) && !in_array($candidate, $available_models, true)) {
            return false;
        }

        if (!empty($context['requires_vision']) && function_exists('aiomatic_is_vision_model') && !aiomatic_is_vision_model($candidate, '')) {
            return false;
        }

        if (!empty($context['requires_tools']) && function_exists('aiomatic_get_all_models_function')) {
            $function_models = aiomatic_get_all_models_function();
            $model_parts = explode(':', $candidate);
            $base_model = isset($model_parts[0]) ? $model_parts[0] : $candidate;
            if (!in_array($candidate, $function_models, true) && !in_array($base_model, $function_models, true)) {
                return false;
            }
        }

        // The legacy completions path does not implement these chat-only
        // provider adapters.
        if (empty($context['is_chat']) && in_array($provider, array('huggingface', 'ollama'), true)) {
            return false;
        }

        if (!empty($context['prompt_tokens']) && function_exists('aimogenpro_get_max_input_tokens')) {
            $max_input = (int) aimogenpro_get_max_input_tokens($candidate);
            if ($max_input > 0 && (int) $context['prompt_tokens'] >= max(1, $max_input - 64)) {
                return false;
            }
        }

        return true;
    }
}

if (!function_exists('aimogen_reliability_select_next_model')) {
    function aimogen_reliability_select_next_model($current_model, $category, $error = '')
    {
        $context = aimogen_reliability_current_context();
        if (!is_array($context)) {
            return (string) $current_model;
        }

        // A safety decision must never trigger cross-provider policy evasion.
        if ($category === 'safety') {
            aiomatic_log_to_file('[Reliability Mode] Safety-policy response detected; provider failover was not attempted.');
            return (string) $current_model;
        }

        $settings = aimogen_reliability_settings();
        $limit = aimogen_reliability_max_attempts($settings);
        if ((int) $context['fallbacks_used'] >= $limit) {
            return (string) $current_model;
        }

        $attempted = isset($context['attempted']) && is_array($context['attempted']) ? $context['attempted'] : array();
        foreach (aimogen_reliability_model_list($settings) as $candidate) {
            if ($candidate === (string) $current_model || in_array($candidate, $attempted, true)) {
                continue;
            }
            if (!aimogen_reliability_model_is_compatible($candidate, $context)) {
                continue;
            }

            $context['attempted'][] = $candidate;
            $context['current_model'] = $candidate;
            $context['fallbacks_used'] = (int) $context['fallbacks_used'] + 1;
            $context['events'][] = array(
                'from' => (string) $current_model,
                'to' => $candidate,
                'category' => $category,
                'time' => time(),
            );
            aimogen_reliability_update_context($context);

            aiomatic_log_to_file(sprintf(
                '[Reliability Mode] %s failed (%s). Switching to %s (%s), fallback %d of %d.',
                (string) $current_model,
                $category,
                $candidate,
                aimogen_reliability_provider_label(aimogen_reliability_provider_for_model($candidate, $settings)),
                (int) $context['fallbacks_used'],
                $limit
            ));
            do_action('aimogen_reliability_failover', $current_model, $candidate, $category, $error, $context);
            return $candidate;
        }

        aiomatic_log_to_file(sprintf(
            '[Reliability Mode] No compatible fallback remained after %s failed (%s).',
            (string) $current_model,
            $category
        ));
        return (string) $current_model;
    }
}

if (!function_exists('aimogen_reliability_prepare_initial_model')) {
    function aimogen_reliability_prepare_initial_model($model)
    {
        $context = aimogen_reliability_current_context();
        $settings = aimogen_reliability_settings();
        if (!is_array($context) || !aimogen_reliability_is_cooled_down($model, $settings)) {
            return (string) $model;
        }

        $next = aimogen_reliability_select_next_model($model, 'cooldown', '');
        if ($next !== (string) $model) {
            aiomatic_log_to_file(sprintf(
                '[Reliability Mode] Skipped %s because it is temporarily cooling down.',
                (string) $model
            ));
        }
        return $next;
    }
}

if (!function_exists('aimogen_reliability_recalculate_available_tokens')) {
    function aimogen_reliability_recalculate_available_tokens($model, $content, $current_available)
    {
        if (!function_exists('aimogenpro_get_max_tokens')) {
            return $current_available;
        }
        $max_tokens = (int) aimogenpro_get_max_tokens($model);
        if ($max_tokens <= 0) {
            return $current_available;
        }

        $text = aimogen_reliability_content_text($content);
        $query_tokens = function_exists('aiomatic_encode')
            ? count(aiomatic_encode($text))
            : (int) ceil(strlen($text) / 4);
        $candidate_available = max(1, $max_tokens - $query_tokens);

        if (is_numeric($current_available) && (int) $current_available > 0) {
            return min((int) $current_available, $candidate_available);
        }
        return $candidate_available;
    }
}

if (!function_exists('aimogen_reliability_available_tokens_try_fix')) {
    function aimogen_reliability_available_tokens_try_fix($available_tokens, $error, $model)
    {
        $context = aimogen_reliability_current_context();
        if (!is_array($context) || !function_exists('aimogenpro_get_max_tokens')) {
            return $available_tokens;
        }

        $max_tokens = (int) aimogenpro_get_max_tokens($model);
        if ($max_tokens <= 0) {
            return $available_tokens;
        }

        $prompt_tokens = isset($context['prompt_tokens']) ? (int) $context['prompt_tokens'] : 0;
        $candidate_available = max(1, $max_tokens - $prompt_tokens);
        if (is_numeric($available_tokens) && (int) $available_tokens > 0) {
            return min((int) $available_tokens, $candidate_available);
        }
        return $candidate_available;
    }
}
add_filter('aiomatic_available_tokens_try_fix', 'aimogen_reliability_available_tokens_try_fix', 20, 3);

if (!function_exists('aimogen_reliability_resolve_token')) {
    function aimogen_reliability_resolve_token($current_token, $model, $settings = null)
    {
        $context = aimogen_reliability_current_context();
        $settings = aimogen_reliability_settings($settings);
        if (!is_array($context) || !aimogen_reliability_enabled($settings)) {
            return $current_token;
        }

        $provider = aimogen_reliability_provider_for_model($model, $settings);
        if (isset($context['original_provider']) && $provider === $context['original_provider']) {
            return $current_token;
        }
        if ($provider === 'ollama') {
            if (function_exists('aiomatic_is_aiomaticapi_key') && aiomatic_is_aiomaticapi_key($current_token)) {
                return 'ollama-local';
            }
            return $current_token;
        }

        $field = aimogen_reliability_provider_key_field($provider);
        if ($field === '' || !isset($settings[$field])) {
            return $current_token;
        }

        $keys = preg_split('/\r\n|\r|\n/', trim((string) $settings[$field]));
        $keys = array_values(array_filter(array_map('trim', is_array($keys) ? $keys : array()), 'strlen'));
        if (empty($keys)) {
            return $current_token;
        }

        if (in_array(trim((string) $current_token), $keys, true)) {
            if (aimogen_smart_key_rotation_enabled($settings)) {
                $fingerprint = aimogen_smart_key_fingerprint($current_token);
                if (aimogen_smart_get_key_state($fingerprint) === false) {
                    aimogen_smart_note_selected_key($current_token, $provider);
                    return $current_token;
                }
                return aimogen_smart_select_key($settings[$field], $current_token, $provider, null, false);
            }
            if (function_exists('aiomatic_try_new_key')) {
                return aiomatic_try_new_key(trim((string) $settings[$field]), $current_token);
            }
        }
        if (function_exists('aimogen_smart_select_initial_key')) {
            return aimogen_smart_select_initial_key($settings[$field], $provider);
        }
        return $keys[array_rand($keys)];
    }
}

if (!function_exists('aiomatic_fallback_model_detect')) {
    function aiomatic_fallback_model_detect($model, $error, $aicontent)
    {
        $settings = aimogen_reliability_settings();
        $fallbacks = aimogen_reliability_model_list($settings);
        if (empty($fallbacks)) {
            return $model;
        }

        // Exact backward compatibility for existing installations.
        if (!aimogen_reliability_enabled($settings)) {
            return $fallbacks[array_rand($fallbacks)];
        }

        // Image and other calls outside the active text-generation context
        // retain their established fallback behaviour.
        if (!is_array(aimogen_reliability_current_context())) {
            return $fallbacks[array_rand($fallbacks)];
        }

        $context = aimogen_reliability_current_context();
        $text = aimogen_reliability_content_text($aicontent);
        if (is_array($context) && $text !== '') {
            $context['prompt_tokens'] = max(
                isset($context['prompt_tokens']) ? (int) $context['prompt_tokens'] : 0,
                (int) ceil(strlen($text) / 4)
            );
            aimogen_reliability_update_context($context);
        }

        $category = aimogen_reliability_classify_error($error);
        $context = aimogen_reliability_current_context();
        $key_failure_provider = aimogen_reliability_provider_for_model($model, $settings);
        if (is_array($context) && !empty($context['current_key_id'])) {
            $failed_key_id = !empty($context['last_rotated_failed_key_id'])
                ? (string) $context['last_rotated_failed_key_id']
                : (string) $context['current_key_id'];
            $failed_key_provider = !empty($context['last_rotated_failed_key_provider'])
                ? (string) $context['last_rotated_failed_key_provider']
                : (isset($context['current_key_provider']) ? $context['current_key_provider'] : '');
            if ($failed_key_provider !== '') {
                $key_failure_provider = $failed_key_provider;
            }
            $signature = hash('sha256', $failed_key_id . '|' . $category . '|' . aimogen_smart_error_text($error));
            if (!isset($context['last_key_failure_signature']) || !hash_equals((string) $context['last_key_failure_signature'], $signature)) {
                aimogen_smart_mark_key_failure(
                    $failed_key_id,
                    $failed_key_provider,
                    $category,
                    $error,
                    $settings
                );
                $context['last_key_failure_signature'] = $signature;
                $context['last_rotated_failed_key_id'] = '';
                $context['last_rotated_failed_key_provider'] = '';
                aimogen_reliability_update_context($context);
            } elseif (!empty($context['last_rotated_failed_key_id'])) {
                // The rotation call already recorded this exact error.
                $context['last_rotated_failed_key_id'] = '';
                $context['last_rotated_failed_key_provider'] = '';
                aimogen_reliability_update_context($context);
            }
        }
        if (aimogen_smart_key_rotation_enabled($settings) &&
            in_array($category, array('rate_limit', 'authentication', 'permission', 'quota'), true) &&
            aimogen_smart_provider_has_healthy_keys($key_failure_provider, $settings)) {
            aiomatic_log_to_file(sprintf(
                '[Reliability Mode] %s failed for one API key (%s). Retrying the same model with another healthy %s key.',
                (string) $model,
                $category,
                aimogen_reliability_provider_label($key_failure_provider)
            ));
            return $model;
        }
        aimogen_reliability_mark_failure($model, $category, $error, $settings);
        return aimogen_reliability_select_next_model($model, $category, $error);
    }
}
add_filter('aiomatic_model_fallback', 'aiomatic_fallback_model_detect', 10, 3);

if (!function_exists('aimogen_reliability_finish_request')) {
    function aimogen_reliability_finish_request($successful)
    {
        $stack = &aimogen_reliability_context_stack();
        if (empty($stack)) {
            return;
        }
        $context = array_pop($stack);
        if (!is_array($context)) {
            return;
        }

        if ($successful) {
            if (!empty($context['current_key_id'])) {
                aimogen_smart_clear_key_state($context['current_key_id']);
                do_action(
                    'aimogen_smart_key_recovered',
                    $context['current_key_id'],
                    isset($context['current_key_provider']) ? $context['current_key_provider'] : ''
                );
            }
            $model = isset($context['current_model']) ? $context['current_model'] : '';
            if ($model !== '') {
                delete_transient(aimogen_reliability_model_cooldown_key($model));
                $provider = aimogen_reliability_provider_for_model($model);
                delete_transient(aimogen_reliability_provider_cooldown_key($provider));
                delete_transient('aimogen_rel_failures_' . md5($provider));
            }
            if (!empty($context['events'])) {
                set_transient('aimogen_reliability_last_success', array(
                    'time' => time(),
                    'original_model' => $context['original_model'],
                    'final_model' => $context['current_model'],
                    'attempts' => count($context['attempted']),
                    'environment' => $context['environment'],
                ), DAY_IN_SECONDS);
            }
        } elseif (!empty($context['events'])) {
            set_transient('aimogen_reliability_last_failure', array(
                'time' => time(),
                'original_model' => $context['original_model'],
                'final_model' => $context['current_model'],
                'attempts' => count($context['attempted']),
                'environment' => $context['environment'],
            ), DAY_IN_SECONDS);
        }
    }
}

if (!function_exists('aimogen_reliability_on_success')) {
    function aimogen_reliability_on_success($response, $content, $model, $assistant_id)
    {
        aimogen_reliability_finish_request(true);
    }
}
add_action('aiomatic_on_successful_response', 'aimogen_reliability_on_success', 999, 4);

if (!function_exists('aimogen_reliability_on_error')) {
    function aimogen_reliability_on_error($error, $content, $model, $assistant_id)
    {
        $settings = aimogen_reliability_settings();
        $context = aimogen_reliability_current_context();
        if (aimogen_smart_key_rotation_enabled($settings) && is_array($context) && !empty($context['current_key_id'])) {
            $category = aimogen_reliability_classify_error($error);
            $signature = hash('sha256', $context['current_key_id'] . '|' . $category . '|' . aimogen_smart_error_text($error));
            if (!isset($context['last_key_failure_signature']) || !hash_equals((string) $context['last_key_failure_signature'], $signature)) {
                aimogen_smart_mark_key_failure(
                    (string) $context['current_key_id'],
                    isset($context['current_key_provider']) ? $context['current_key_provider'] : '',
                    $category,
                    $error,
                    $settings
                );
            }
        }
        aimogen_reliability_finish_request(false);
    }
}
add_action('aiomatic_on_error', 'aimogen_reliability_on_error', 999, 4);
