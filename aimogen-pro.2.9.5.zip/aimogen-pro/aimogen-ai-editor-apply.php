<?php
/*
 * Aimogen AI Editor - applying accepted changes, and undoing them.
 *
 * Everything here re-validates from scratch. The browser sends field ids and values;
 * the ids are resolved against a freshly built allow-list, capabilities are checked
 * again at post level, and every value is sanitized according to the kind of field it
 * is landing in. Nothing is trusted because it was trusted during generation.
 */

defined('ABSPATH') or die();

/**
 * Sanitize a proposed value for the field it is going into.
 *
 * Post content and wysiwyg fields keep their HTML: stripping markup would destroy
 * Gutenberg blocks and shortcodes, which is the opposite of what this feature is for.
 * Users who can edit posts but lack unfiltered_html still go through kses, matching
 * what WordPress does on a normal save.
 */
function aimogen_ai_editor_sanitize_value($field, $value)
{
    $value = (string) $value;
    $format = isset($field['format']) ? $field['format'] : 'text';
    $acf_type = isset($field['acf_type']) ? $field['acf_type'] : '';

    if ($acf_type === 'number') {
        $value = trim($value);
        if ($value === '' || !is_numeric($value)) {
            return new WP_Error('aimogen_ai_editor_not_numeric', __('The value for this field must be a number.', 'aiomatic-automatic-ai-content-writer'));
        }
        return $value;
    }
    if ($acf_type === 'email') {
        $value = sanitize_email(trim($value));
        if ($value === '' || !is_email($value)) {
            return new WP_Error('aimogen_ai_editor_not_email', __('The value for this field must be an e-mail address.', 'aiomatic-automatic-ai-content-writer'));
        }
        return $value;
    }
    if ($acf_type === 'url') {
        $value = esc_url_raw(trim($value));
        if ($value === '') {
            return new WP_Error('aimogen_ai_editor_not_url', __('The value for this field must be a URL.', 'aiomatic-automatic-ai-content-writer'));
        }
        return $value;
    }

    if ($field['id'] === 'post_title') {
        return sanitize_text_field($value);
    }

    if ($format === 'html') {
        if (current_user_can('unfiltered_html')) {
            return $value;
        }
        return wp_kses_post($value);
    }

    if ($field['id'] === 'post_excerpt') {
        return current_user_can('unfiltered_html') ? $value : wp_kses_post($value);
    }

    /* Plain/text meta: collapse nothing, just strip markup the user cannot post. */
    if (current_user_can('unfiltered_html')) {
        return $value;
    }
    return wp_kses_post($value);
}

/**
 * Read a field's stored value, for the snapshot taken before overwriting it.
 */
function aimogen_ai_editor_read_stored_value($post, $field)
{
    if ($field['kind'] === 'core') {
        $key = $field['key'];
        return isset($post->$key) ? (string) $post->$key : '';
    }
    if ($field['kind'] === 'acf' && aimogen_ai_editor_acf_active()) {
        $value = get_field($field['key'], $post->ID, false);
        return is_scalar($value) ? (string) $value : '';
    }
    if ($field['kind'] === 'meta') {
        return (string) get_post_meta($post->ID, $field['key'], true);
    }
    return '';
}

/**
 * Write one field.
 *
 * Core columns are batched by the caller into a single wp_update_post(); this handles
 * the meta side, which must go through ACF's API when ACF owns the field so the
 * field-key reference row stays in sync.
 */
function aimogen_ai_editor_write_field($post, $field, $value)
{
    if ($field['kind'] === 'acf') {
        if (!aimogen_ai_editor_acf_active()) {
            return new WP_Error('aimogen_ai_editor_no_acf', __('Advanced Custom Fields is no longer available.', 'aiomatic-automatic-ai-content-writer'));
        }
        /* Re-check the field still exists and is still the type we validated against. */
        $acf_field = function_exists('acf_get_field') ? acf_get_field($field['key']) : null;
        if (!is_array($acf_field) || empty($acf_field['type'])) {
            return new WP_Error('aimogen_ai_editor_acf_gone', __('This ACF field no longer exists.', 'aiomatic-automatic-ai-content-writer'));
        }
        if (!in_array($acf_field['type'], aimogen_ai_editor_acf_supported_types(), true)) {
            return new WP_Error('aimogen_ai_editor_acf_type', __('This ACF field type cannot be edited by Aimogen.', 'aiomatic-automatic-ai-content-writer'));
        }
        $written = update_field($field['key'], $value, $post->ID);
        if ($written === false) {
            return new WP_Error('aimogen_ai_editor_acf_write', __('Advanced Custom Fields rejected the new value.', 'aiomatic-automatic-ai-content-writer'));
        }
        return true;
    }

    if ($field['kind'] === 'meta') {
        /* update_post_meta() runs the value through stripslashes, so pre-slash it to
           keep backslashes and quotes in the generated text intact. */
        $written = update_post_meta($post->ID, $field['key'], wp_slash($value));
        if ($written === false) {
            return new WP_Error('aimogen_ai_editor_meta_write', __('The custom field could not be saved.', 'aiomatic-automatic-ai-content-writer'));
        }
        return true;
    }

    return new WP_Error('aimogen_ai_editor_unknown_kind', __('Unsupported field type.', 'aiomatic-automatic-ai-content-writer'));
}

/**
 * Apply a set of accepted changes.
 *
 * $changes is field_id => proposed value, straight from the browser. When supplied,
 * $expected is field_id => value seen during generation and prevents a stale proposal
 * from overwriting a value saved in this or another editor afterward. $new_keys names
 * custom fields that do not exist on the post yet; each one is re-admitted here from
 * scratch, so an id can no more be invented at apply time than it can at generation.
 *
 * Core post columns are only written when the caller asks for it. The interactive
 * panel first verifies that the editor has no unsaved work, then writes accepted
 * core and custom fields together and reloads the edit screen from the database.
 */
function aimogen_ai_editor_apply_changes($post, $changes, $write_core = false, $expected = array(), $new_keys = array())
{
    if (!($post instanceof WP_Post)) {
        $post = get_post($post);
    }
    if (!($post instanceof WP_Post) || empty($post->ID)) {
        return new WP_Error('aimogen_ai_editor_bad_post', __('Invalid post.', 'aiomatic-automatic-ai-content-writer'));
    }
    if (!current_user_can('edit_post', $post->ID)) {
        return new WP_Error('aimogen_ai_editor_forbidden', __('You are not allowed to edit this post.', 'aiomatic-automatic-ai-content-writer'), array('status' => 403));
    }
    if (!is_array($changes) || empty($changes)) {
        return new WP_Error('aimogen_ai_editor_nothing', __('No changes were submitted.', 'aiomatic-automatic-ai-content-writer'));
    }
    if (!is_array($expected)) {
        $expected = array();
    }

    $admission = aimogen_ai_editor_admit_new_meta_keys(
        $post,
        $new_keys,
        aimogen_ai_editor_get_available_fields($post)
    );
    $available = $admission['fields'];

    $applied  = array();
    $skipped  = $admission['rejected'];
    $stored   = array();
    $snapshot = array();
    $core_args = array();

    foreach ($changes as $field_id => $value) {
        $field = aimogen_ai_editor_resolve_field($post, $field_id, $available);
        if ($field === null) {
            /* Unknown id: the field vanished, was filtered out, or was never real.
               A key that was turned down for creation already has a better reason
               recorded against it, so do not paper over it with the generic one. */
            if (!isset($skipped[(string) $field_id])) {
                $skipped[(string) $field_id] = __('This field is not available for editing.', 'aiomatic-automatic-ai-content-writer');
            }
            continue;
        }

        $clean = aimogen_ai_editor_sanitize_value($field, $value);
        if (is_wp_error($clean)) {
            $skipped[$field['id']] = $clean->get_error_message();
            continue;
        }

        $previous = aimogen_ai_editor_read_stored_value($post, $field);
        /* Compare with canonical line endings on both sides. The value the browser
           echoes back has been through multipart/form-data, which rewrites LF to CRLF,
           and a row written by the classic editor or an importer can hold CRLF of its
           own. Neither is an edit by another user, which is all this check is for. */
        if (array_key_exists($field['id'], $expected) &&
            aimogen_ai_editor_normalize_newlines($expected[$field['id']]) !== aimogen_ai_editor_normalize_newlines($previous)) {
            $skipped[$field['id']] = __('This field changed after the proposal was generated, so it was left unchanged.', 'aiomatic-automatic-ai-content-writer');
            continue;
        }

        if ($field['kind'] === 'core') {
            if (!$write_core) {
                continue;
            }
            $core_args[$field['key']] = $clean;
            $snapshot[$field['id']] = array(
                'kind'     => 'core',
                'key'      => $field['key'],
                'previous' => $previous,
                'applied'  => $clean,
            );
            $applied[] = $field['id'];
            continue;
        }

        $written = aimogen_ai_editor_write_field($post, $field, $clean);
        if (is_wp_error($written)) {
            $skipped[$field['id']] = $written->get_error_message();
            continue;
        }

        $snapshot[$field['id']] = array(
            'kind'     => $field['kind'],
            'key'      => $field['key'],
            'previous' => $previous,
            'applied'  => $clean,
        );
        /* A key this write created has no previous value to restore - undoing it means
           removing the row again, not leaving an empty one on a post that never had it. */
        if (!empty($field['is_new']) && $field['kind'] === 'meta') {
            $snapshot[$field['id']]['created'] = true;
        }
        /* Report the value after WordPress/ACF has stored it for integrations and use
           the same authoritative value for conflict-safe Undo. The interactive panel
           reloads the page rather than guessing how a custom framework holds state. */
        $stored[$field['id']] = aimogen_ai_editor_read_stored_value($post, $field);
        /* Filters in the owning plugin may normalize the submitted value. Conflict
           detection during Undo must compare against what actually landed, not the
           pre-write proposal. */
        $snapshot[$field['id']]['applied'] = $stored[$field['id']];
        $applied[] = $field['id'];
    }

    if (!empty($core_args)) {
        $core_args['ID'] = $post->ID;
        /* Same kses dance aiomatic_do_post() uses: generated content legitimately
           contains block comments and markup that the save filters would mangle. */
        remove_filter('content_save_pre', 'wp_filter_post_kses');
        remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');
        remove_filter('title_save_pre', 'wp_filter_kses');
        $updated = wp_update_post(wp_slash($core_args), true);
        add_filter('content_save_pre', 'wp_filter_post_kses');
        add_filter('content_filtered_save_pre', 'wp_filter_post_kses');
        add_filter('title_save_pre', 'wp_filter_kses');

        if (is_wp_error($updated)) {
            foreach ($core_args as $key => $ignored) {
                if ($key === 'ID') {
                    continue;
                }
                $skipped[$key] = $updated->get_error_message();
                unset($snapshot[$key]);
                $position = array_search($key, $applied, true);
                if ($position !== false) {
                    unset($applied[$position]);
                }
            }
            $applied = array_values($applied);
            aiomatic_log_to_file('[AI Editor] Post ' . $post->ID . ' update failed: ' . $updated->get_error_message());
        } else {
            /* Save filters can also normalize core columns. Preserve the post-write
               values so Undo will not mistake that normalization for a later edit. */
            $updated_post = get_post($post->ID);
            if ($updated_post instanceof WP_Post) {
                foreach ($snapshot as $snapshot_id => $snapshot_data) {
                    if (!is_array($snapshot_data) || !isset($snapshot_data['kind'], $snapshot_data['key']) || $snapshot_data['kind'] !== 'core') {
                        continue;
                    }
                    $snapshot_key = (string) $snapshot_data['key'];
                    $snapshot[$snapshot_id]['applied'] = isset($updated_post->$snapshot_key) ? (string) $updated_post->$snapshot_key : '';
                }
            }
        }
    }

    /* wp_update_post() runs save_post and framework callbacks after the earlier
       custom-field writes. Those callbacks may normalize or replace meta/ACF values,
       so refresh the response and Undo comparison value from the final database state. */
    foreach ($snapshot as $snapshot_id => $snapshot_data) {
        if (!is_array($snapshot_data) || !isset($snapshot_data['kind'], $snapshot_data['key']) || $snapshot_data['kind'] === 'core') {
            continue;
        }
        $final_field = array(
            'kind' => $snapshot_data['kind'],
            'key'  => $snapshot_data['key'],
        );
        $final_value = aimogen_ai_editor_read_stored_value($post, $final_field);
        $stored[$snapshot_id] = $final_value;
        $snapshot[$snapshot_id]['applied'] = $final_value;
    }

    if (!empty($snapshot)) {
        aimogen_ai_editor_store_snapshot($post->ID, $snapshot);
        if (function_exists('aiomatic_increment_edit_stats')) {
            aiomatic_increment_edit_stats();
        }
        if (function_exists('aiomatic_set_last_activity')) {
            aiomatic_set_last_activity('edit', array('post_id' => $post->ID));
        }
        do_action('aimogen_ai_editor_changes_applied', $post->ID, $snapshot, get_current_user_id());
    }

    return array(
        'applied' => array_values($applied),
        'skipped' => $skipped,
        'stored'  => $stored,
        'canUndo' => aimogen_ai_editor_has_history($post->ID),
    );
}

/*
 * ---------------------------------------------------------------------------
 * Snapshots / undo
 *
 * WordPress revisions cover post columns but not arbitrary post meta, so an
 * Aimogen-specific snapshot is the only way to make "undo the last AI change"
 * reliable for custom fields. It stores just enough to restore what this one
 * operation touched, bounded by both entry count and total size.
 * ---------------------------------------------------------------------------
 */

function aimogen_ai_editor_get_history($post_id)
{
    $history = get_post_meta((int) $post_id, AIMOGEN_AI_EDITOR_HISTORY_META, true);
    if (!is_array($history)) {
        return array();
    }
    return $history;
}

function aimogen_ai_editor_has_history($post_id)
{
    $history = aimogen_ai_editor_get_history($post_id);
    return !empty($history);
}

/**
 * Short description of the most recent operation, for the panel's undo affordance.
 */
function aimogen_ai_editor_last_history_summary($post_id)
{
    $history = aimogen_ai_editor_get_history($post_id);
    if (empty($history)) {
        return null;
    }
    $entry = end($history);
    if (!is_array($entry) || empty($entry['fields']) || !is_array($entry['fields'])) {
        return null;
    }

    $labels = array();
    foreach ($entry['fields'] as $field_id => $data) {
        $labels[] = isset($data['key']) ? (string) $data['key'] : (string) $field_id;
    }

    $user = isset($entry['user']) ? get_user_by('id', (int) $entry['user']) : false;

    return array(
        'time'   => isset($entry['time']) ? (int) $entry['time'] : 0,
        'when'   => isset($entry['time']) ? human_time_diff((int) $entry['time'], time()) : '',
        'user'   => ($user !== false) ? $user->display_name : '',
        'fields' => $labels,
    );
}

function aimogen_ai_editor_store_snapshot($post_id, $snapshot)
{
    $post_id = (int) $post_id;
    $history = aimogen_ai_editor_get_history($post_id);

    $history[] = array(
        'time'   => time(),
        'user'   => get_current_user_id(),
        'fields' => $snapshot,
    );

    $history = aimogen_ai_editor_prune_history($history);

    update_post_meta($post_id, AIMOGEN_AI_EDITOR_HISTORY_META, $history);
}

/**
 * Compact, deterministic comparison token for an authoritative stored value.
 *
 * This is not an authentication primitive; it lets a size-pruned undo snapshot
 * detect whether the field still contains the exact value Aimogen applied.
 */
function aimogen_ai_editor_value_hash($value)
{
    return hash('sha256', (string) $value);
}

/**
 * Move an Undo snapshot's comparison point to the value that actually remained.
 *
 * A save callback can replace a value while Undo is running. Keeping that field in
 * history is only safely retryable when the next attempt compares against the final
 * database value, using the same full-value/hash representation as the snapshot.
 */
function aimogen_ai_editor_update_retry_snapshot($data, $current)
{
    if (!is_array($data)) {
        return $data;
    }

    if (array_key_exists('applied', $data)) {
        $data['applied'] = (string) $current;
        unset($data['applied_hash']);
    } else {
        $data['applied_hash'] = aimogen_ai_editor_value_hash($current);
    }

    return $data;
}

/**
 * Keep the history within both budgets, dropping oldest first.
 */
function aimogen_ai_editor_prune_history($history)
{
    $max_entries = (int) apply_filters('aimogen_ai_editor_history_max_entries', AIMOGEN_AI_EDITOR_HISTORY_MAX_ENTRIES);
    if ($max_entries < 1) {
        $max_entries = 1;
    }
    while (count($history) > $max_entries) {
        array_shift($history);
    }

    $max_bytes = (int) apply_filters('aimogen_ai_editor_history_max_bytes', AIMOGEN_AI_EDITOR_HISTORY_MAX_BYTES);
    while (count($history) > 1 && strlen(maybe_serialize($history)) > $max_bytes) {
        array_shift($history);
    }

    /* A single operation can still exceed the budget on its own - a very long post
       plus its replacement. Keep the previous values (undo needs them), replace the
       applied copies with compact hashes, and retain conflict protection. */
    if (count($history) === 1 && strlen(maybe_serialize($history)) > $max_bytes) {
        if (isset($history[0]['fields']) && is_array($history[0]['fields'])) {
            foreach ($history[0]['fields'] as $field_id => $data) {
                if (is_array($data) && array_key_exists('applied', $data)) {
                    $history[0]['fields'][$field_id]['applied_hash'] = aimogen_ai_editor_value_hash($data['applied']);
                    unset($history[0]['fields'][$field_id]['applied']);
                }
            }
        }
    }

    return array_values($history);
}

/**
 * Restore the values captured before the most recent Aimogen application.
 *
 * Core columns are restored through wp_update_post(); meta and ACF go back through
 * their own APIs. The browser reloads after a successful restore so every editor UI
 * is rebuilt from these authoritative stored values.
 */
function aimogen_ai_editor_undo_last($post)
{
    if (!($post instanceof WP_Post)) {
        $post = get_post($post);
    }
    if (!($post instanceof WP_Post) || empty($post->ID)) {
        return new WP_Error('aimogen_ai_editor_bad_post', __('Invalid post.', 'aiomatic-automatic-ai-content-writer'));
    }
    if (!current_user_can('edit_post', $post->ID)) {
        return new WP_Error('aimogen_ai_editor_forbidden', __('You are not allowed to edit this post.', 'aiomatic-automatic-ai-content-writer'), array('status' => 403));
    }

    $history = aimogen_ai_editor_get_history($post->ID);
    if (empty($history)) {
        return new WP_Error('aimogen_ai_editor_no_history', __('There is nothing to undo on this post.', 'aiomatic-automatic-ai-content-writer'));
    }

    $entry = array_pop($history);
    if (!is_array($entry) || empty($entry['fields']) || !is_array($entry['fields'])) {
        update_post_meta($post->ID, AIMOGEN_AI_EDITOR_HISTORY_META, $history);
        return new WP_Error('aimogen_ai_editor_bad_history', __('The stored history entry could not be read.', 'aiomatic-automatic-ai-content-writer'));
    }

    /* Re-derive the allow-list: a field that has since been locked down by a filter
       or a plugin must not be writable just because a snapshot mentions it. */
    /* Refresh the object before comparing against the applied snapshot. The editor
       may have saved (or another plugin may have updated) the post since page load. */
    $fresh_post = get_post($post->ID);
    if ($fresh_post instanceof WP_Post) {
        $post = $fresh_post;
    }
    $available = aimogen_ai_editor_get_available_fields($post);

    $restored        = array();
    $skipped         = array();
    $remaining       = array();
    $core_args       = array();
    $core_field_ids  = array();
    $core_entry_data = array();
    $meta_candidates = array();

    foreach ($entry['fields'] as $field_id => $data) {
        if (!is_array($data) || !array_key_exists('previous', $data)) {
            continue;
        }
        $field = aimogen_ai_editor_resolve_field($post, $field_id, $available);
        if ($field === null) {
            $skipped[(string) $field_id] = __('This field is no longer editable.', 'aiomatic-automatic-ai-content-writer');
            $remaining[(string) $field_id] = $data;
            continue;
        }

        $current = aimogen_ai_editor_read_stored_value($post, $field);
        if (array_key_exists('applied', $data)) {
            if ((string) $current !== (string) $data['applied']) {
                $skipped[$field['id']] = __('This field changed after Aimogen applied it, so it was left unchanged.', 'aiomatic-automatic-ai-content-writer');
                $remaining[(string) $field_id] = $data;
                continue;
            }
        } elseif (!empty($data['applied_hash'])) {
            if (aimogen_ai_editor_value_hash($current) !== (string) $data['applied_hash']) {
                $skipped[$field['id']] = __('This field changed after Aimogen applied it, so it was left unchanged.', 'aiomatic-automatic-ai-content-writer');
                $remaining[(string) $field_id] = $data;
                continue;
            }
        } else {
            /* Older snapshots may predate applied-value tracking. Without either the
               value or its hash, overwriting the current field cannot be proven safe. */
            $skipped[$field['id']] = __('This undo snapshot cannot be verified safely, so the field was left unchanged.', 'aiomatic-automatic-ai-content-writer');
            $remaining[(string) $field_id] = $data;
            continue;
        }

        $previous = (string) $data['previous'];

        if ($field['kind'] === 'core') {
            $core_args[$field['key']] = $previous;
            $core_field_ids[$field['key']] = $field['id'];
            $core_entry_data[$field['id']] = $data;
            continue;
        }

        if (!empty($data['created']) && $field['kind'] === 'meta' && $previous === '') {
            /* Aimogen created this row; undoing puts the post back to not having it. */
            delete_post_meta($post->ID, $field['key']);
        } else {
            $written = aimogen_ai_editor_write_field($post, $field, $previous);
            if (is_wp_error($written)) {
                $skipped[$field['id']] = $written->get_error_message();
                $remaining[(string) $field_id] = $data;
                continue;
            }
        }
        $meta_candidates[$field['id']] = array(
            'field'    => $field,
            'expected' => $previous,
            'snapshot' => $data,
        );
    }

    if (!empty($core_args)) {
        $core_args['ID'] = $post->ID;
        remove_filter('content_save_pre', 'wp_filter_post_kses');
        remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');
        remove_filter('title_save_pre', 'wp_filter_kses');
        $updated = wp_update_post(wp_slash($core_args), true);
        add_filter('content_save_pre', 'wp_filter_post_kses');
        add_filter('content_filtered_save_pre', 'wp_filter_post_kses');
        add_filter('title_save_pre', 'wp_filter_kses');

        if (is_wp_error($updated)) {
            foreach ($core_args as $key => $ignored) {
                if ($key !== 'ID') {
                    $core_field_id = isset($core_field_ids[$key]) ? $core_field_ids[$key] : $key;
                    $skipped[$core_field_id] = $updated->get_error_message();
                    if (isset($core_entry_data[$core_field_id])) {
                        $remaining[$core_field_id] = $core_entry_data[$core_field_id];
                    }
                }
            }
        } else {
            $restored_post = get_post($post->ID);
            foreach ($core_field_ids as $key => $core_field_id) {
                if (!($restored_post instanceof WP_Post) || !isset($restored_post->$key)) {
                    $skipped[$core_field_id] = __('The restored value could not be verified, so it remains available to retry.', 'aiomatic-automatic-ai-content-writer');
                    if (isset($core_entry_data[$core_field_id])) {
                        $remaining[$core_field_id] = $core_entry_data[$core_field_id];
                    }
                    continue;
                }

                $final_value = (string) $restored_post->$key;
                if ($final_value !== (string) $core_args[$key]) {
                    $skipped[$core_field_id] = __('A save hook or field integration changed this value while it was being restored, so it remains available to retry.', 'aiomatic-automatic-ai-content-writer');
                    if (isset($core_entry_data[$core_field_id])) {
                        $remaining[$core_field_id] = aimogen_ai_editor_update_retry_snapshot($core_entry_data[$core_field_id], $final_value);
                    }
                    continue;
                }

                $restored[$core_field_id] = $final_value;
            }
        }
    }

    /* Core restoration runs save_post after meta/ACF has been written. Re-read every
       candidate afterward so callbacks cannot make Undo report stale success. */
    foreach ($meta_candidates as $field_id => $candidate) {
        $final_value = aimogen_ai_editor_read_stored_value($post, $candidate['field']);
        if ((string) $final_value !== (string) $candidate['expected']) {
            $skipped[$field_id] = __('A save hook or field integration changed this value while it was being restored, so it remains available to retry.', 'aiomatic-automatic-ai-content-writer');
            $remaining[$field_id] = aimogen_ai_editor_update_retry_snapshot($candidate['snapshot'], $final_value);
            continue;
        }
        $restored[$field_id] = $final_value;
    }

    /* A partial/conflicted Undo stays retryable, but fields restored successfully
       are removed from the entry so a retry cannot undo them twice. */
    if (!empty($remaining)) {
        $entry['fields'] = $remaining;
        $history[] = $entry;
    }
    $history = aimogen_ai_editor_prune_history($history);
    update_post_meta($post->ID, AIMOGEN_AI_EDITOR_HISTORY_META, $history);
    do_action('aimogen_ai_editor_changes_undone', $post->ID, $entry, get_current_user_id());

    return array(
        'restored' => $restored,
        'skipped'  => $skipped,
        'canUndo'  => !empty($history),
        'lastChange' => aimogen_ai_editor_last_history_summary($post->ID),
    );
}
