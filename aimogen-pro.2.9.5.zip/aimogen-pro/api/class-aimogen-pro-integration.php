<?php
/**
 * Aimogen Pro extensions for the public Aimogen integration API.
 *
 * @package AimogenPro
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'aimogen_integration_capabilities',
	static function ( $capabilities ) {
		$capabilities['chat']                = shortcode_exists( 'aimogen-chat-form' );
		$capabilities['chatbots']            = true;
		$capabilities['text']                = function_exists( 'aimogen' );
		$capabilities['images']              = function_exists( 'aiomatic_generate_ai_image' );
		$capabilities['embeddings']          = true;
		$capabilities['knowledge_bases']     = true;
		$capabilities['streaming']           = true;
		$capabilities['voice']               = true;
		$capabilities['persistent_chat']     = true;
		$capabilities['lead_capture']        = true;
		$capabilities['workflows']           = true;
		$capabilities['agents']              = true;
		$capabilities['automation']          = true;
		$capabilities['provider_management'] = true;
		$capabilities['usage_controls']      = true;

		return $capabilities;
	}
);

add_filter(
	'aimogen_integration_chatbots',
	static function ( $chatbots ) {
		return array(
			array(
				'id'          => 'default',
				'title'       => __( 'Aimogen Pro Chatbot', 'aiomatic-automatic-ai-content-writer' ),
				'description' => __( 'Uses the chatbot configured in Aimogen Pro.', 'aiomatic-automatic-ai-content-writer' ),
				'avatar'      => '',
				'source'      => 'aimogen-pro',
			),
		);
	},
	20
);

add_filter(
	'aimogen_integration_admin_urls',
	static function ( $urls ) {
		$chatbot_url = admin_url( 'admin.php?page=aiomatic_chatbot_panel' );
		return array_merge(
			$urls,
			array(
				'chatbot'        => $chatbot_url,
				'assistants'     => $chatbot_url,
				'knowledge'      => admin_url( 'admin.php?page=aiomatic_embeddings_panel' ),
				'leads'          => admin_url( 'edit.php?post_type=aiomatic_lead' ),
				'workflows'      => admin_url( 'admin.php?page=aiomatic_omniblocks' ),
				'agents'         => admin_url( 'admin.php?page=aiomatic_agents_panel' ),
				'settings'       => admin_url( 'admin.php?page=aiomatic_admin_settings' ),
				'usage_controls' => admin_url( 'admin.php?page=aiomatic_admin_settings' ),
			)
		);
	}
);

add_filter(
	'aimogen_integration_resources_knowledge_bases',
	static function ( $resources ) {
		$settings = get_option( 'aiomatic_Main_Settings', array() );
		$keys     = array(
			'pinecone_namespace',
			'embeddings_chat_short_namespace',
			'embeddings_assistant_namespace',
			'embeddings_forms_namespace',
			'embeddings_omni_namespace',
		);

		foreach ( $keys as $key ) {
			if ( empty( $settings[ $key ] ) ) {
				continue;
			}

			$namespace   = sanitize_text_field( $settings[ $key ] );
			$resources[] = array(
				'id'          => $namespace,
				'title'       => $namespace,
				'description' => __( 'Aimogen embeddings namespace', 'aiomatic-automatic-ai-content-writer' ),
				'source'      => 'aimogen-pro',
			);
		}

		return $resources;
	}
);
