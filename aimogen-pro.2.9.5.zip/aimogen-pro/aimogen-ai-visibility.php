<?php
defined('ABSPATH') or die();

/*
 * AI search visibility, the low-risk half:
 *
 * - /llms.txt: a plain-text map of the site's pages and latest posts for AI assistants
 *   (llmstxt.org format), generated on request and cached.
 * - AI crawler rules appended to WordPress's virtual robots.txt: block AI training crawlers
 *   only, or every AI crawler.
 *
 * Both are off by default and neither writes files. A physical robots.txt or llms.txt in the
 * site root is served by the web server instead, and the matching setting has no effect.
 * Crawler rules only ever add Disallow groups: an explicit Allow group would make that bot
 * ignore the site's own `User-agent: *` rules.
 */

function aimogen_ai_visibility_settings()
{
    $settings = get_option('aiomatic_Main_Settings', array());
    return is_array($settings) ? $settings : array();
}

/** AI crawler robots.txt tokens, by what they do. */
function aimogen_ai_crawlers()
{
    return apply_filters('aimogen_ai_crawlers', array(
        // Collect content for model training; blocking them does not affect search or AI answers.
        'training' => array('GPTBot', 'ClaudeBot', 'Google-Extended', 'Applebot-Extended', 'CCBot', 'meta-externalagent', 'Bytespider'),
        // Fetch pages for AI search results and answers; blocking them lowers visibility there.
        'search'   => array('OAI-SearchBot', 'ChatGPT-User', 'Claude-SearchBot', 'Claude-User', 'PerplexityBot', 'Perplexity-User'),
    ));
}

/** Append the chosen AI crawler groups to the virtual robots.txt. */
function aimogen_ai_crawler_robots_txt($output, $public)
{
    $settings = aimogen_ai_visibility_settings();
    $mode = isset($settings['ai_crawlers']) ? $settings['ai_crawlers'] : '';
    if ($mode !== 'training' && $mode !== 'all') {
        return $output;
    }
    $crawlers = aimogen_ai_crawlers();
    $agents = isset($crawlers['training']) ? (array) $crawlers['training'] : array();
    if ($mode === 'all' && isset($crawlers['search'])) {
        $agents = array_merge($agents, (array) $crawlers['search']);
    }
    $lines = array('', '# Aimogen Pro: AI crawler rules');
    foreach (array_unique($agents) as $agent) {
        $lines[] = 'User-agent: ' . $agent;
        $lines[] = 'Disallow: /';
        $lines[] = '';
    }
    return rtrim((string) $output) . "\n" . implode("\n", $lines);
}
add_filter('robots_txt', 'aimogen_ai_crawler_robots_txt', 99, 2);

/** Whether this request is for llms.txt at the site's home path. */
function aimogen_is_llms_txt_request()
{
    if (empty($_SERVER['REQUEST_URI'])) {
        return false;
    }
    $path = wp_parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $home = wp_parse_url(home_url('/'), PHP_URL_PATH);
    return $path === trailingslashit($home ? $home : '/') . 'llms.txt';
}

/** Serve llms.txt before WordPress runs its main query. */
function aimogen_maybe_serve_llms_txt()
{
    if (!aimogen_is_llms_txt_request()) {
        return;
    }
    $settings = aimogen_ai_visibility_settings();
    // Not while the site asks search engines to stay away.
    if (!isset($settings['llms_txt']) || $settings['llms_txt'] !== 'on' || !get_option('blog_public')) {
        return;
    }
    status_header(200);
    header('Content-Type: text/plain; charset=utf-8');
    echo aimogen_llms_txt();
    exit;
}
add_action('parse_request', 'aimogen_maybe_serve_llms_txt', 0);

/** One line of plain text: no tags, entities or line breaks. */
function aimogen_llms_plain($text)
{
    $text = html_entity_decode(wp_strip_all_tags((string) $text), ENT_QUOTES, 'UTF-8');
    return trim(preg_replace('/\s+/u', ' ', $text));
}

/** Short summary: the excerpt, or the start of the content. */
function aimogen_llms_summary($post)
{
    $text = $post->post_excerpt !== '' ? $post->post_excerpt : strip_shortcodes($post->post_content);
    return wp_trim_words(aimogen_llms_plain($text), 25, '...');
}

/** Pages that Yoast SEO or Rank Math keep out of search stay out of llms.txt too. */
function aimogen_llms_is_noindex($post_id)
{
    if (get_post_meta($post_id, '_yoast_wpseo_meta-robots-noindex', true) === '1') {
        return true;
    }
    $rank_math = get_post_meta($post_id, 'rank_math_robots', true);
    return is_array($rank_math) && in_array('noindex', $rank_math, true);
}

/** Build (or load from cache) the llms.txt text. */
function aimogen_llms_txt()
{
    $cached = get_transient('aimogen_llms_txt');
    if (is_string($cached) && $cached !== '') {
        return $cached;
    }
    $out = '# ' . aimogen_llms_plain(get_bloginfo('name')) . "\n";
    $tagline = aimogen_llms_plain(get_bloginfo('description'));
    if ($tagline !== '') {
        $out .= "\n> " . $tagline . "\n";
    }
    $sections = apply_filters('aimogen_llms_txt_sections', array(
        'Pages' => array('post_type' => 'page', 'orderby' => 'menu_order title', 'order' => 'ASC'),
        'Posts' => array('post_type' => 'post', 'orderby' => 'date', 'order' => 'DESC'),
    ));
    foreach ($sections as $heading => $args) {
        $posts = get_posts(array_merge(array('post_status' => 'publish', 'has_password' => false, 'numberposts' => 50), $args));
        $items = array();
        foreach ($posts as $post) {
            if (aimogen_llms_is_noindex($post->ID)) {
                continue;
            }
            $title = str_replace(array('[', ']'), array('\[', '\]'), aimogen_llms_plain(get_the_title($post)));
            $line = '- [' . ($title !== '' ? $title : $post->ID) . '](' . esc_url_raw(get_permalink($post)) . ')';
            $summary = aimogen_llms_summary($post);
            if ($summary !== '') {
                $line .= ': ' . $summary;
            }
            $items[] = $line;
        }
        if (!empty($items)) {
            $out .= "\n## " . $heading . "\n\n" . implode("\n", $items) . "\n";
        }
    }
    $out = (string) apply_filters('aimogen_llms_txt', $out);
    set_transient('aimogen_llms_txt', $out, 12 * HOUR_IN_SECONDS);
    return $out;
}

/** Rebuild llms.txt after content or site identity changes. */
function aimogen_llms_txt_flush($post_id = 0)
{
    if ($post_id && (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id))) {
        return;
    }
    delete_transient('aimogen_llms_txt');
}
add_action('save_post', 'aimogen_llms_txt_flush');
add_action('deleted_post', 'aimogen_llms_txt_flush');
add_action('update_option_blogname', 'aimogen_llms_txt_flush', 10, 0);
add_action('update_option_blogdescription', 'aimogen_llms_txt_flush', 10, 0);
