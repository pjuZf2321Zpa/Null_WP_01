<?php
defined('ABSPATH') or die();
add_action( 'wp_abilities_api_categories_init', 'aimogen_register_ability_category' );

function aimogen_register_ability_category() {
    wp_register_ability_category(
        'automation',
        array(
            'label'       => __( 'Automation', 'aiomatic-automatic-ai-content-writer' ),
            'description' => __( 'Automation and workflow related abilities.', 'aiomatic-automatic-ai-content-writer' ),
        )
    );
}

add_action( 'wp_abilities_api_init', 'aimogen_register_abilities' );
function aimogen_register_abilities() {

    wp_register_ability( 'aimogen/run-rule', [
        'label'       => esc_html__( 'Run Aimogen Rule', 'aiomatic-automatic-ai-content-writer' ),
        'description' => esc_html__( 'Runs a configured Aimogen automation rule using a specific generator.', 'aiomatic-automatic-ai-content-writer' ),
        'category'    => 'automation',

        'input_schema' => [
            'type'     => 'object',
            'required' => [ 'rule_id', 'generator' ],
            'properties' => [
                'rule_id' => [
                    'type'        => 'integer',
                    'description' => 'Rule index / ID'
                ],
                'generator' => [
                    'type'        => 'string',
                    'description' => 'Generator type',
                    'enum'        => [
                        'posts',
                        'youtube',
                        'amazon',
                        'review',
                        'csv',
                        'omniblock',
                        'listicle',
                        'forum',
                        'reply',
                    ],
                ],
            ],
        ],

        'output_schema' => [
            'type'       => 'object',
            'properties' => [
                'success' => [ 'type' => 'boolean' ],
                'message' => [ 'type' => 'string' ],
                'error'   => [ 'type' => 'string' ],
            ],
        ],

        'permission_callback' => function () {
            return current_user_can( 'manage_options' );
        },

        'execute_callback' => function ( $input ) {

            if ( ! function_exists( 'aiomatic_run_rule' ) ) {
                return [
                    'success' => false,
                    'error'   => 'Aimogen not available',
                ];
            }

            $generator_map = [
                'posts'     => 0,
                'youtube'   => 1,
                'amazon'    => 2,
                'review'    => 3,
                'csv'       => 4,
                'omniblock' => 5,
                'listicle'  => 6,
                'forum'     => 7,
                'reply'     => 8,
            ];

            $generator = $input['generator'];

            if ( ! isset( $generator_map[ $generator ] ) ) {
                return [
                    'success' => false,
                    'error'   => 'Invalid generator type',
                ];
            }

            $rule_id   = intval( $input['rule_id'] );
            if ($rule_id <= 0) {
                return [
                    'success' => false,
                    'error'   => 'Invalid rule ID',
                ];
            }
            $rule_type = $generator_map[ $generator ];

            $result = aiomatic_run_rule(
                $rule_id,
                $rule_type,
                0,
                0,
                null,
                '',
                '',
                false,
                []
            );

            if ( $result === 'fail' ) {
                return [
                    'success' => false,
                    'error'   => 'Rule execution failed',
                ];
            }

            if ( $result === 'nochange' ) {
                return [
                    'success' => false,
                    'error'   => 'Rule produced no changes',
                ];
            }

            return [
                'success' => true,
                'message' => sprintf(
                    'Rule %d executed successfully using %s generator.',
                    $rule_id,
                    $generator
                ),
            ];
        },

        'meta' => [
            'show_in_rest' => true,
            'annotations' => [
                'destructive' => true,
                'readonly'    => false,
            ],
        ],
    ] );
}
?>