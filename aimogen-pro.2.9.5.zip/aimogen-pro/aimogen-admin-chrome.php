<?php
/**
 * Shared admin chrome for Aimogen Pro: the panel hero, its Docs/Support/Video
 * resource cluster, and the per-screen WordPress contextual Help tabs.
 *
 * Every admin panel used to carry its own copy of the hero markup, which is why
 * the header drifted between screens and why help links were hard to find. The
 * hero is rendered from one place here instead.
 */
defined('ABSPATH') or die();

define('AIMOGEN_DOCS_URL', 'https://coderevolution.ro/docs/aimogen-pro/');
define('AIMOGEN_KB_URL', 'https://coderevolution.ro/knowledge-base/');
// Default knowledge-base target: the search listing of every Aimogen-related entry.
define('AIMOGEN_KB_DEFAULT_URL', 'https://coderevolution.ro/knowledge-base/?s=aimogen&submit=');
define('AIMOGEN_SUPPORT_URL', 'https://coderevolution.ro/support/tickets/aiomatic-support/');
define('AIMOGEN_TUTORIALS_URL', 'https://www.youtube.com/playlist?list=PLEiGTaa0iBIhRvgICiyvwBXH-dMBM4VAt');
define('AIMOGEN_UPDATES_URL', 'https://www.youtube.com/playlist?list=PLEiGTaa0iBIhsRSgl5czLEDAhawr_SHx2');

/**
 * Per-screen documentation and video mapping.
 *
 * 'kb' entries point at the knowledge-base article covering that screen; the
 * video ids are the ones already embedded in each screen's Tutorial tab.
 */
function aimogen_get_screen_resource_map()
{
    $kb = AIMOGEN_KB_URL . 'faq/';
    return array(
        'aiomatic_admin_settings' => array(
            'kb'    => $kb . 'aiomatic-automatic-ai-content-writer/',
            'video' => '_Ft1czw-VPU',
        ),
        'aiomatic_bulk_creators' => array(
            'kb'    => $kb . 'aiomatic-update-single-ai-post-creator-feature-added/',
            'video' => '3W-UGm7pbsU',
        ),
        'aiomatic_spinner_panel' => array(
            'kb'    => $kb . 'aiomatics-ai-content-editor-a-step-by-step-guide-to-automatic-ai-assisted-post-editing/',
            'video' => 'WVccxtXQTcc',
        ),
        'aiomatic_chatbot_panel' => array(
            'kb'    => $kb . 'aiomatic-full-ai-chatbot-tutorial/',
            'video' => 'QCkNkCrFi-o',
        ),
        'aiomatic_shortcodes_panel' => array(
            'kb'    => $kb . 'aiomatic-article-shortcode-documentation/',
            'video' => 'vtgUWMVocog',
        ),
        'aiomatic_omniblocks' => array(
            'kb'    => $kb . 'aiomatic-update-introducing-aicontent-nested-shortcode-support-for-dynamic-content-generation/',
            'video' => 'hiIwxyftnBU',
        ),
        'aiomatic_agents_panel' => array(
            'kb'    => AIMOGEN_KB_URL . '?s=aimogen+agents&submit=',
            'video' => 'rT1BiSgimbQ',
        ),
        'aiomatic_embeddings_panel' => array(
            'kb'    => $kb . 'aiomatic-update-use-embeddings-to-quickly-teach-the-ai-information-about-your-business-or-products/',
            'video' => 'hkk0d7W0kIs',
        ),
        'aiomatic_openai_training' => array(
            'kb'    => $kb . 'creating-a-custom-fine-tuned-model-with-openais-gpt-3-aiomatic-update/',
            'video' => 'MV5F2X6z_X4',
        ),
        'aiomatic_playground_panel' => array(
            'kb'    => $kb . 'aiomatic-update-back-end-playground-to-write-edit-text-create-ai-images-front-end-shortcodes/',
            'video' => '',
        ),
        'aiomatic_mcp_panel' => array(
            'kb'    => $kb . 'how-to-connect-claude-to-wordpress-with-aiomatic-mcp/',
            'video' => 'niILXouTah4',
        ),
        'aiomatic_snippets_panel' => array(
            'kb'    => $kb . 'aiomatic-plugin-developer-documentation/',
            'video' => 'E_3ff29AtsU',
        ),
        'aiomatic_batch_panel' => array(
            'kb'    => AIMOGEN_KB_URL . '?s=aimogen+batch&submit=',
            'video' => 'JqWFhJiyPh8',
        ),
        'aiomatic_assistants_panel' => array(
            'kb'    => $kb . 'aiomatic-ai-assistant-update-for-faster-post-editing-in-gutenberg-and-classic-editor/',
            'video' => 'x2mkjdOZI9Y',
        ),
        'aiomatic_openai_status' => array(
            'kb'    => $kb . 'aiomatic-full-limits-and-statistics-tutorial/',
            'video' => 'skwJz6yeqIg',
        ),
        'aiomatic_more' => array(
            'kb'    => $kb . 'how-to-create-ai-generated-content-from-any-plugin-built-by-coderevolution/',
            'video' => '',
        ),
        'aiomatic_developer_tools' => array(
            'kb'    => $kb . 'aiomatic-plugin-developer-documentation/',
            'video' => '',
        ),
    );
}

/**
 * Resolve the current admin screen slug, falling back to the Settings panel.
 */
function aimogen_current_screen_slug()
{
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    return $page !== '' ? $page : 'aiomatic_admin_settings';
}

/**
 * Docs / video / support targets for a screen. Unknown screens fall back to the
 * knowledge base and the tutorial playlist rather than to nothing at all.
 */
function aimogen_get_screen_resources($slug = '')
{
    if ($slug === '') {
        $slug = aimogen_current_screen_slug();
    }
    $map = aimogen_get_screen_resource_map();
    $entry = isset($map[$slug]) ? $map[$slug] : array('kb' => '', 'video' => '');
    $kb = (isset($entry['kb']) && $entry['kb'] !== '') ? $entry['kb'] : AIMOGEN_KB_DEFAULT_URL;
    $video = (isset($entry['video']) && $entry['video'] !== '')
        ? 'https://www.youtube.com/watch?v=' . $entry['video'] . '&list=PLEiGTaa0iBIhRvgICiyvwBXH-dMBM4VAt'
        : AIMOGEN_TUTORIALS_URL;
    return array(
        'docs'    => AIMOGEN_DOCS_URL,
        'kb'      => $kb,
        'kb_home' => AIMOGEN_KB_DEFAULT_URL,
        'video'   => $video,
        'support' => AIMOGEN_SUPPORT_URL,
    );
}

/**
 * The Docs / Support / Video cluster shown in every panel header.
 */
function aimogen_render_admin_resource_links($slug = '')
{
    $res = aimogen_get_screen_resources($slug);
    ?>
    <div class="aiomatic-admin-resources">
        <a class="aiomatic-admin-resource" href="<?php echo esc_url($res['docs']); ?>" target="_blank" rel="noopener noreferrer">
            <span class="aiomatic-admin-resource-icon dashicons dashicons-book-alt" aria-hidden="true"></span>
            <?php esc_html_e('Docs', 'aiomatic-automatic-ai-content-writer'); ?>
        </a>
        <a class="aiomatic-admin-resource" href="<?php echo esc_url($res['kb']); ?>" target="_blank" rel="noopener noreferrer">
            <span class="aiomatic-admin-resource-icon dashicons dashicons-lightbulb" aria-hidden="true"></span>
            <?php esc_html_e('Knowledge base', 'aiomatic-automatic-ai-content-writer'); ?>
        </a>
        <a class="aiomatic-admin-resource" href="<?php echo esc_url($res['video']); ?>" target="_blank" rel="noopener noreferrer">
            <span class="aiomatic-admin-resource-icon dashicons dashicons-video-alt3" aria-hidden="true"></span>
            <?php esc_html_e('Video tutorial', 'aiomatic-automatic-ai-content-writer'); ?>
        </a>
        <a class="aiomatic-admin-resource" href="<?php echo esc_url($res['support']); ?>" target="_blank" rel="noopener noreferrer">
            <span class="aiomatic-admin-resource-icon dashicons dashicons-sos" aria-hidden="true"></span>
            <?php esc_html_e('Support', 'aiomatic-automatic-ai-content-writer'); ?>
        </a>
    </div>
    <?php
}

/**
 * Render the shared panel hero.
 *
 * @param array $args {
 *     @type string $title          Main title. Defaults to the product title.
 *     @type bool   $show_version   Show the version pill.
 *     @type bool   $show_meta      Show the right-hand meta/badge column.
 *     @type bool   $free_connected Show the "Aimogen Free connected" pill.
 *     @type string $screen         Screen slug used for the resource links.
 * }
 */
function aimogen_render_admin_hero($args = array())
{
    $args = wp_parse_args($args, array(
        'title'          => '',
        'show_version'   => true,
        'show_meta'      => true,
        'free_connected' => false,
        'screen'         => '',
    ));
    if ($args['title'] === '') {
        $args['title'] = __('Aimogen - AI Writer, Editor, ChatBot & Toolkit', 'aiomatic-automatic-ai-content-writer');
    }
    $logo = plugins_url('images/ai.png', __FILE__);
    ?>
   <div class="aiomatic-admin-hero">
      <div class="aiomatic-admin-identity">
         <div class="aiomatic-admin-logo">
            <img class="client-logo" src="<?php echo esc_url($logo); ?>" alt="Aimogen" />
         </div>
         <div class="aiomatic-admin-title">
            <div class="aiomatic-admin-title-sub">
               <?php esc_html_e('AI Momentum Generator', 'aiomatic-automatic-ai-content-writer'); ?>
            </div>
            <div class="aiomatic-admin-title-main">
               <?php echo esc_html($args['title']); ?>
               <?php if ($args['show_version']) : ?>
               <span class="aiomatic-version-pill">
                  <span class="aiomatic-version-pill-dot"></span>
                  <?php esc_html_e('Version', 'aiomatic-automatic-ai-content-writer'); ?> <?php echo esc_html(aimogenpro_get_version()); ?>
               </span>
               <?php endif; ?>
               <?php if ($args['free_connected']) : ?>
               <span class="aiomatic-version-pill aiomatic-status-pill aiomatic-status-pill--connected" title="<?php echo esc_attr__('The free Aimogen plugin is active. All shared features are enabled.', 'aiomatic-automatic-ai-content-writer'); ?>">
                  <span class="aiomatic-version-pill-dot"></span>
                  <?php esc_html_e('Aimogen Free connected', 'aiomatic-automatic-ai-content-writer'); ?>
               </span>
               <?php endif; ?>
            </div>
         </div>
      </div>
      <?php if ($args['show_meta']) : ?>
      <div class="aiomatic-admin-meta">
         <?php aimogen_render_admin_resource_links($args['screen']); ?>
         <a class="aiomatic-white" href="https://wpbay.com/product/aimogen-pro/" target="_blank" rel="noopener noreferrer">
            <div class="aiomatic-admin-badge">
               <span class="aiomatic-admin-badge-dot"></span><?php esc_html_e('Ready when your ideas are', 'aiomatic-automatic-ai-content-writer'); ?>
            </div>
         </a>
      </div>
      <?php endif; ?>
   </div>
    <?php
}

/**
 * Screen-specific copy for the WordPress contextual Help tab.
 */
function aimogen_get_screen_help_summary($slug)
{
    $summaries = array(
        'aiomatic_admin_settings'    => __('Global settings: AI provider API keys, models, defaults and licensing. Add at least one provider API key here before using any other screen.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_bulk_creators'     => __('Create posts from keywords, titles, listicles, product roundups, CSV files or YouTube videos - one at a time or in bulk.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_spinner_panel'     => __('Rewrite, spin, translate and improve posts you already have, manually or on a schedule.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_chatbot_panel'     => __('Build chatbots: pick a model and persona, give the bot context, style the widget, then publish it site-wide or via shortcode.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_shortcodes_panel'  => __('Shortcodes and front-end AI forms you can drop into posts, pages and templates.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_omniblocks'        => __('Chain fixed AI steps into a repeatable sequence, such as a title/outline/draft pipeline.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_agents_panel'      => __('Autonomous agents that work from a goal and a scoped tool list. Start from a shipped template, review its tool permissions, then run it and read the log.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_embeddings_panel'  => __('Build a semantic knowledge base from your content so chatbots and agents can retrieve it.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_openai_training'   => __('Fine-tune a custom model on your own training data.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_playground_panel'  => __('Try prompts, models and images interactively before wiring them into a rule or bot.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_mcp_panel'         => __('Expose this site over MCP so external AI clients can call it, or connect the plugin to remote MCP servers.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_snippets_panel'    => __('Reusable prompt snippets shared across the plugin.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_batch_panel'       => __('Submit large jobs through provider batch APIs at lower cost.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_assistants_panel'  => __('Manage OpenAI Assistants used by the editor and the chatbot.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_openai_status'     => __('Usage, spend, API call limits and plugin logs. Check here first when something fails.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_more'              => __('Additional tools and integrations that do not fit the main categories.', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_developer_tools'   => __('Developer surface: filters, function calling and REST endpoints.', 'aiomatic-automatic-ai-content-writer'),
    );
    return isset($summaries[$slug]) ? $summaries[$slug] : '';
}

/**
 * Register contextual Help tabs on Aimogen admin screens, so the native Help
 * button carries the same guidance and support links as the header cluster.
 */
function aimogen_register_help_tabs()
{
    $screen = get_current_screen();
    if (!$screen) {
        return;
    }
    $slug = aimogen_current_screen_slug();
    $map = aimogen_get_screen_resource_map();
    if (!isset($map[$slug])) {
        return;
    }
    $res = aimogen_get_screen_resources($slug);
    $summary = aimogen_get_screen_help_summary($slug);

    $overview = '';
    if ($summary !== '') {
        $overview .= '<p>' . esc_html($summary) . '</p>';
    }
    $overview .= '<p>' . esc_html__('Each Aimogen screen also has a Tutorial tab in its own left-hand menu, with a walkthrough and a video for that feature.', 'aiomatic-automatic-ai-content-writer') . '</p>';

    $screen->add_help_tab(array(
        'id'      => 'aimogen_overview',
        'title'   => __('Aimogen', 'aiomatic-automatic-ai-content-writer'),
        'content' => $overview,
    ));

    $screen->add_help_tab(array(
        'id'      => 'aimogen_help_links',
        'title'   => __('Docs & support', 'aiomatic-automatic-ai-content-writer'),
        'content' =>
            '<p>' . esc_html__('Documentation and help for this screen:', 'aiomatic-automatic-ai-content-writer') . '</p><ul>' .
            '<li><a href="' . esc_url($res['kb']) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Knowledge base article for this screen', 'aiomatic-automatic-ai-content-writer') . '</a></li>' .
            '<li><a href="' . esc_url($res['video']) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Video tutorial for this screen', 'aiomatic-automatic-ai-content-writer') . '</a></li>' .
            '<li><a href="' . esc_url($res['docs']) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Full plugin documentation', 'aiomatic-automatic-ai-content-writer') . '</a></li>' .
            '<li><a href="' . esc_url($res['kb_home']) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Browse the knowledge base', 'aiomatic-automatic-ai-content-writer') . '</a></li>' .
            '</ul>',
    ));

    $screen->set_help_sidebar(
        '<p><strong>' . esc_html__('More help', 'aiomatic-automatic-ai-content-writer') . '</strong></p>' .
        '<p><a href="' . esc_url(AIMOGEN_SUPPORT_URL) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Open a support ticket', 'aiomatic-automatic-ai-content-writer') . '</a></p>' .
        '<p><a href="' . esc_url(AIMOGEN_TUTORIALS_URL) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Tutorial videos', 'aiomatic-automatic-ai-content-writer') . '</a></p>' .
        '<p><a href="' . esc_url(AIMOGEN_UPDATES_URL) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Update videos', 'aiomatic-automatic-ai-content-writer') . '</a></p>'
    );
}
add_action('in_admin_header', 'aimogen_register_help_tabs');

/**
 * Docs / support links under the plugin row on the Plugins screen.
 */
function aimogen_add_plugin_row_meta($links, $file)
{
    if ($file !== plugin_basename(dirname(__FILE__) . '/aimogen-pro.php')) {
        return $links;
    }
    $links[] = '<a href="' . esc_url(AIMOGEN_DOCS_URL) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Documentation', 'aiomatic-automatic-ai-content-writer') . '</a>';
    $links[] = '<a href="' . esc_url(AIMOGEN_KB_DEFAULT_URL) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Knowledge base', 'aiomatic-automatic-ai-content-writer') . '</a>';
    $links[] = '<a href="' . esc_url(AIMOGEN_TUTORIALS_URL) . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Video tutorials', 'aiomatic-automatic-ai-content-writer') . '</a>';
    return $links;
}
add_filter('plugin_row_meta', 'aimogen_add_plugin_row_meta', 10, 2);
