<?php
/*
 * Aimogen AI Editor - generation engine.
 *
 * Produces proposed values. It never writes to the database: the result is a plain
 * array handed back to the browser for review. Applying happens in
 * aimogen-ai-editor-apply.php, triggered by a separate user action.
 *
 * The AI call itself goes through aiomatic_generate_text(), the plugin's existing
 * provider-routing entry point, so every configured provider and model keeps working
 * without this module knowing anything about API keys.
 */

defined('ABSPATH') or die();

/**
 * Model + sampling settings for a generation run.
 *
 * Defaults come from the AI Content Editor's own configuration so the panel behaves
 * like the rest of the plugin without the user visiting the settings screen first.
 */
function aimogen_ai_editor_resolve_generation_settings($overrides = array())
{
    $main    = get_option('aiomatic_Main_Settings', false);
    $spinner = get_option('aiomatic_Spinner_Settings', false);
    if (!is_array($main)) {
        $main = array();
    }
    if (!is_array($spinner)) {
        $spinner = array();
    }

    $model = '';
    if (!empty($spinner['edit_model'])) {
        $model = trim($spinner['edit_model']);
    }
    if ($model === '' && function_exists('aiomatic_get_default_model_name')) {
        $model = aiomatic_get_default_model_name($main);
    }

    /* A little warmth by default: the editor's stored default is 0, which makes
       rewrite requests come back nearly identical to the input. */
    $temperature = isset($spinner['edit_temperature']) && $spinner['edit_temperature'] !== ''
        ? floatval($spinner['edit_temperature'])
        : 0.4;
    $top_p = isset($spinner['edit_top_p']) && $spinner['edit_top_p'] !== ''
        ? floatval($spinner['edit_top_p'])
        : 1;
    $presence_penalty = isset($spinner['edit_presence_penalty']) && $spinner['edit_presence_penalty'] !== ''
        ? floatval($spinner['edit_presence_penalty'])
        : 0;
    $frequency_penalty = isset($spinner['edit_frequency_penalty']) && $spinner['edit_frequency_penalty'] !== ''
        ? floatval($spinner['edit_frequency_penalty'])
        : 0;

    if (!empty($overrides['model'])) {
        $model = (string) $overrides['model'];
    }
    if (isset($overrides['temperature']) && $overrides['temperature'] !== '') {
        $temperature = floatval($overrides['temperature']);
    }

    $temperature = max(0, min(2, $temperature));
    $top_p = max(0, min(1, $top_p));

    return array(
        'model'             => $model,
        'temperature'       => $temperature,
        'top_p'             => $top_p,
        'presence_penalty'  => $presence_penalty,
        'frequency_penalty' => $frequency_penalty,
        'assistant_id'      => !empty($spinner['edit_assistant_id']) ? trim($spinner['edit_assistant_id']) : '',
        'store_data'        => (isset($spinner['store_data']) && $spinner['store_data'] === 'on') ? 'on' : 'off',
    );
}

/**
 * Pick an OpenAI key the same way aiomatic_do_post() does.
 *
 * aiomatic_generate_text() routes to the right provider based on the model name and
 * swaps in that provider's own key, so this is only the seed value.
 */
function aimogen_ai_editor_get_token()
{
    $main = get_option('aiomatic_Main_Settings', false);
    if (!is_array($main) || empty($main['app_id'])) {
        return '';
    }
    $ids = preg_split('/\r\n|\r|\n/', trim($main['app_id']));
    $ids = array_filter(array_map('trim', (array) $ids));
    if (empty($ids)) {
        return '';
    }
    return $ids[array_rand($ids)];
}

/**
 * Run one AI request and return the raw text, or a WP_Error.
 */
function aimogen_ai_editor_call_ai($prompt, $settings)
{
    if (!function_exists('aiomatic_generate_text')) {
        return new WP_Error('aimogen_ai_editor_no_engine', __('The Aimogen generation engine is unavailable.', 'aiomatic-automatic-ai-content-writer'));
    }

    $main = get_option('aiomatic_Main_Settings', false);
    if (function_exists('aiomatic_check_api_keys') && !aiomatic_check_api_keys($main)) {
        return new WP_Error('aimogen_ai_editor_no_key', __('No AI provider API key is configured. Add one in the Aimogen settings first.', 'aiomatic-automatic-ai-content-writer'));
    }

    $token = aimogen_ai_editor_get_token();
    $model = $settings['model'];

    $max_tokens = function_exists('aimogenpro_get_max_tokens') ? aimogenpro_get_max_tokens($model) : 4096;
    $query_token_count = function_exists('aiomatic_encode') ? count(aiomatic_encode($prompt)) : (int) (strlen($prompt) / 4);
    if (function_exists('aiomatic_compute_available_tokens')) {
        $available = aiomatic_compute_available_tokens($model, $max_tokens, $prompt, $query_token_count);
    } else {
        $available = $max_tokens - $query_token_count;
    }
    if ($available < 256) {
        return new WP_Error(
            'aimogen_ai_editor_too_long',
            __('The selected fields are too long for this model. Choose fewer fields, turn off "Use current post as context", or pick a model with a larger context window.', 'aiomatic-automatic-ai-content-writer')
        );
    }

    $finish_reason = '';
    $error = '';
    $thread_id = '';

    $result = aiomatic_generate_text(
        $token,
        $model,
        $prompt,
        $available,
        $settings['temperature'],
        $settings['top_p'],
        $settings['presence_penalty'],
        $settings['frequency_penalty'],
        false,
        'aiEditorInteractive',
        0,
        $finish_reason,
        $error,
        true,
        false,
        false,
        '',
        '',
        'user',
        $settings['assistant_id'],
        $thread_id,
        '',
        /* 'disabled' keeps god-mode tool calling out of an editing request. */
        'disabled',
        '',
        false,
        $settings['store_data'],
        array(),
        '',
        '',
        ''
    );

    if ($result === false || !is_string($result) || trim($result) === '') {
        $message = is_string($error) && $error !== ''
            ? $error
            : __('The AI provider returned no usable response.', 'aiomatic-automatic-ai-content-writer');
        aiomatic_log_to_file('[AI Editor] Generation failed: ' . $message);
        return new WP_Error('aimogen_ai_editor_provider', aimogen_ai_editor_safe_error($message));
    }

    return $result;
}

/**
 * Provider errors can carry endpoint URLs, organisation ids or key fragments. Keep
 * the useful part, drop anything that looks like a credential.
 */
function aimogen_ai_editor_safe_error($message)
{
    $message = wp_strip_all_tags((string) $message);
    $message = preg_replace('/\b(sk|rk|pk)-[A-Za-z0-9_\-]{8,}/', '[redacted]', $message);
    $message = preg_replace('/\bBearer\s+[A-Za-z0-9._\-]+/i', '[redacted]', $message);
    $message = preg_replace('#https?://\S+#', '[endpoint]', $message);
    $message = trim(preg_replace('/\s+/', ' ', $message));
    if (function_exists('mb_strlen') && mb_strlen($message, 'UTF-8') > 300) {
        $message = mb_substr($message, 0, 300, 'UTF-8') . '…';
    } elseif (strlen($message) > 300) {
        $message = substr($message, 0, 300) . '…';
    }
    return $message;
}

/**
 * Pull the field map out of whatever the model actually returned.
 *
 * Models drift from the requested shape in predictable ways, so several are accepted:
 *   {"fields":{"post_title":{"value":"x"}}}   the requested shape
 *   {"fields":{"post_title":"x"}}             value collapsed to a string
 *   {"post_title":{"value":"x"}}              wrapper omitted
 *   {"meta":{"product_summary":{"value":"x"}}} grouped by kind
 * Anything that does not resolve to one of the requested ids is discarded.
 */
function aimogen_ai_editor_parse_response($raw, $requested_ids)
{
    $json = function_exists('aiomatic_extract_json_object') ? aiomatic_extract_json_object($raw) : '';
    if ($json === '') {
        $json = trim((string) $raw);
    }

    $decoded = json_decode($json, true);
    if (!is_array($decoded)) {
        /* Some providers double-encode the object as a JSON string. */
        $inner = json_decode($json);
        if (is_string($inner)) {
            $decoded = json_decode($inner, true);
        }
    }
    if (!is_array($decoded) && function_exists('aiomatic_parse_multiple_json')) {
        $candidates = aiomatic_parse_multiple_json((string) $raw);
        foreach ((array) $candidates as $candidate) {
            $candidate = json_decode(wp_json_encode($candidate), true);
            if (is_array($candidate)) {
                $decoded = $candidate;
                break;
            }
        }
    }
    if (!is_array($decoded)) {
        return new WP_Error(
            'aimogen_ai_editor_bad_json',
            __('The AI did not return valid JSON. Try again, or switch to a different model in Advanced Settings.', 'aiomatic-automatic-ai-content-writer')
        );
    }

    $flat = array();
    aimogen_ai_editor_flatten_response($decoded, $requested_ids, $flat);

    $values = array();
    foreach ($requested_ids as $id) {
        if (array_key_exists($id, $flat)) {
            $values[$id] = $flat[$id];
        }
    }

    if (empty($values)) {
        return new WP_Error(
            'aimogen_ai_editor_no_fields',
            __('The AI response did not contain any of the requested fields. Try again or rephrase the instruction.', 'aiomatic-automatic-ai-content-writer')
        );
    }

    return $values;
}

/**
 * Walk the decoded response looking for the requested identifiers.
 *
 * Matching is by identifier, plus the bare key for meta:/acf: ids so a model that
 * drops the prefix still lands on the right field. Everything else is ignored - an
 * unrequested identifier is never carried forward, which is what keeps the model
 * from nominating a field the user did not select.
 */
function aimogen_ai_editor_flatten_response($node, $requested_ids, &$out, $depth = 0)
{
    if (!is_array($node) || $depth > 5) {
        return;
    }

    $lookup = array();
    foreach ($requested_ids as $id) {
        $lookup[$id] = $id;
        $colon = strpos($id, ':');
        if ($colon !== false) {
            $bare = substr($id, $colon + 1);
            /* Only register the bare name when it is unambiguous. */
            if (!isset($lookup[$bare])) {
                $lookup[$bare] = $id;
            }
        }
    }

    foreach ($node as $key => $value) {
        $key = (string) $key;
        if (isset($lookup[$key]) && !isset($out[$lookup[$key]])) {
            $extracted = aimogen_ai_editor_extract_value($value);
            if ($extracted !== null) {
                $out[$lookup[$key]] = $extracted;
                continue;
            }
        }
        if (is_array($value)) {
            aimogen_ai_editor_flatten_response($value, $requested_ids, $out, $depth + 1);
        }
    }
}

/**
 * Reduce a response entry to its string value.
 */
function aimogen_ai_editor_extract_value($value)
{
    if (is_string($value)) {
        return $value;
    }
    if (is_int($value) || is_float($value)) {
        return (string) $value;
    }
    if (is_array($value)) {
        foreach (array('value', 'new_value', 'text', 'content') as $candidate) {
            if (isset($value[$candidate]) && (is_string($value[$candidate]) || is_numeric($value[$candidate]))) {
                return (string) $value[$candidate];
            }
        }
    }
    return null;
}

/**
 * Cheap structural check on Gutenberg block markup.
 *
 * Used to warn - never to silently reject. If the original content was block-based
 * and the proposal is not, or the delimiters no longer balance, the reviewer is told
 * to look closely before accepting.
 */
function aimogen_ai_editor_blocks_look_valid($original, $proposed)
{
    $had_blocks = (strpos($original, '<!-- wp:') !== false);
    if (!$had_blocks) {
        return true;
    }
    if (strpos($proposed, '<!-- wp:') === false) {
        return false;
    }

    $open_original  = preg_match_all('/<!--\s+wp:/', $original);
    $open_proposed  = preg_match_all('/<!--\s+wp:/', $proposed);
    $close_original = preg_match_all('/<!--\s+\/wp:/', $original);
    $close_proposed = preg_match_all('/<!--\s+\/wp:/', $proposed);

    if ($open_proposed !== $open_original || $close_proposed !== $close_original) {
        return false;
    }

    if (function_exists('parse_blocks')) {
        $blocks = parse_blocks($proposed);
        if (!is_array($blocks) || empty($blocks)) {
            return false;
        }
    }

    return true;
}

/**
 * Normalize a proposed value for a field before it is shown for review.
 */
function aimogen_ai_editor_normalize_proposal($field, $value)
{
    $value = (string) $value;

    if (function_exists('aiomatic_sanitize_ai_result')) {
        $value = aiomatic_sanitize_ai_result($value);
    }

    if ($field['id'] === 'post_title') {
        $value = wp_strip_all_tags($value);
        $value = trim(trim(trim($value), '"\''));
        $value = rtrim($value, '.');
        $value = trim($value);
    } elseif (isset($field['acf_type']) && $field['acf_type'] === 'number') {
        $value = trim($value);
    } else {
        $value = trim($value);
    }

    if (!empty($field['maxlength'])) {
        $max = (int) $field['maxlength'];
        if (function_exists('mb_strlen') && mb_strlen($value, 'UTF-8') > $max) {
            $value = mb_substr($value, 0, $max, 'UTF-8');
        } elseif (strlen($value) > $max) {
            $value = substr($value, 0, $max);
        }
    }

    return $value;
}

/**
 * Generate proposals for a set of targets.
 *
 * Returns array('proposals' => array, 'errors' => array). A failure affecting one
 * field does not discard the others: whatever came back usable is returned.
 */
function aimogen_ai_editor_generate($post, $targets, $general_instruction, $use_context, $editor_values, $overrides = array())
{
    if (empty($targets)) {
        return new WP_Error('aimogen_ai_editor_no_targets', __('Select at least one field to edit.', 'aiomatic-automatic-ai-content-writer'));
    }

    $settings = aimogen_ai_editor_resolve_generation_settings($overrides);
    $prompt   = aimogen_ai_editor_build_prompt($post, $targets, $general_instruction, $use_context, $editor_values);

    $requested_ids = array();
    foreach ($targets as $target) {
        $requested_ids[] = $target['field']['id'];
    }

    $main = get_option('aiomatic_Main_Settings', false);
    if (is_array($main) && isset($main['enable_detailed_logging']) && $main['enable_detailed_logging'] === 'on') {
        aiomatic_log_to_file('[AI Editor] Post ' . $post->ID . ' (' . $settings['model'] . ') generating: ' . implode(', ', $requested_ids));
    }

    $raw = aimogen_ai_editor_call_ai($prompt, $settings);
    if (is_wp_error($raw)) {
        return $raw;
    }

    $values = aimogen_ai_editor_parse_response($raw, $requested_ids);
    if (is_wp_error($values)) {
        /* One retry with a blunter reminder: a malformed reply is usually the model
           wrapping JSON in commentary rather than a genuine inability to comply. */
        $retry_prompt = $prompt . "\n\nYour previous reply could not be parsed. Reply with the raw JSON object only. Start your reply with { and end it with }. No explanation, no markdown fence.";
        $raw = aimogen_ai_editor_call_ai($retry_prompt, $settings);
        if (is_wp_error($raw)) {
            return $raw;
        }
        $values = aimogen_ai_editor_parse_response($raw, $requested_ids);
        if (is_wp_error($values)) {
            return $values;
        }
    }

    $proposals = array();
    $errors = array();

    foreach ($targets as $target) {
        $field = $target['field'];
        $id = $field['id'];

        if (!array_key_exists($id, $values)) {
            $errors[$id] = __('The AI did not return a value for this field.', 'aiomatic-automatic-ai-content-writer');
            continue;
        }

        $proposed = aimogen_ai_editor_normalize_proposal($field, $values[$id]);
        $current  = (string) $target['current'];

        if ($proposed === '') {
            $errors[$id] = __('The AI returned an empty value for this field.', 'aiomatic-automatic-ai-content-writer');
            continue;
        }

        $warning = '';
        if ($id === 'post_content' && !aimogen_ai_editor_blocks_look_valid($current, $proposed)) {
            $warning = 'blocks';
        }

        $proposals[$id] = array(
            'id'        => $id,
            'key'       => isset($field['key']) ? (string) $field['key'] : $id,
            'label'     => $field['label'],
            'group'     => $field['group'],
            'format'    => $field['format'],
            'inEditor'  => !empty($field['editable_in_editor']),
            'current'   => $current,
            'expected'  => isset($target['expected']) ? (string) $target['expected'] : $current,
            'proposed'  => $proposed,
            'unchanged' => (trim($current) === trim($proposed)),
            'warning'   => $warning,
            'diff'      => aimogen_ai_editor_render_diff($field, $current, $proposed),
        );
    }

    return array(
        'proposals' => $proposals,
        'errors'    => $errors,
        'model'     => $settings['model'],
    );
}

/**
 * Side-by-side diff for the review UI.
 *
 * Uses WordPress's own wp_text_diff() rather than shipping a diff engine: it is the
 * same renderer the revisions screen uses, so the markup already has admin styling.
 */
function aimogen_ai_editor_render_diff($field, $current, $proposed)
{
    /* Short values read better as plain before/after blocks than as a diff table. */
    $length = strlen($current) + strlen($proposed);
    if ($length < 200 && strpos($current, "\n") === false && strpos($proposed, "\n") === false) {
        return '';
    }

    if (!function_exists('wp_text_diff')) {
        require_once(ABSPATH . WPINC . '/wp-diff.php');
    }
    if (!function_exists('wp_text_diff')) {
        return '';
    }

    $left  = aimogen_ai_editor_diff_prepare($field, $current);
    $right = aimogen_ai_editor_diff_prepare($field, $proposed);

    $diff = wp_text_diff($left, $right, array(
        'title_left'  => __('Current', 'aiomatic-automatic-ai-content-writer'),
        'title_right' => __('Proposed', 'aiomatic-automatic-ai-content-writer'),
        'show_split_view' => true,
    ));

    return is_string($diff) ? $diff : '';
}

/**
 * wp_text_diff() compares line by line, so HTML that lives on one enormous line
 * produces a single useless "everything changed" row. Break on block boundaries
 * first so the diff lands on the paragraph that actually moved.
 */
function aimogen_ai_editor_diff_prepare($field, $value)
{
    $value = (string) $value;
    if (isset($field['format']) && $field['format'] === 'html') {
        $value = preg_replace('#(<!--\s+/?wp:[^>]*-->)#', "\n$1\n", $value);
        $value = preg_replace('#(</(?:p|div|h[1-6]|li|ul|ol|blockquote|figure|table|tr|section)>)#i', "$1\n", $value);
    }
    $value = preg_replace("/\n{3,}/", "\n\n", $value);
    return trim($value);
}
