<?php
defined('ABSPATH') or die();

/** Emit one message using the chatbot's existing SSE contract. */
function aiomatic_google_argon_emit($text, $event = '')
{
    if ($event !== '') {
        echo 'event: ' . $event . "\n";
    }
    echo 'data: ' . str_replace("\n", "\ndata: ", str_replace(array("\r\n", "\r"), "\n", $text)) . "\n\n";
    if (ob_get_length()) {
        ob_flush();
    }
    flush();
}

/** Readable model name for error messages, e.g. "Gemini 4 Carbon". */
function aiomatic_google_argon_label($model)
{
    return ucwords(str_replace('-', ' ', $model));
}

/** Send one GenerateContent request, retaining every signed response part. */
function aiomatic_google_argon_request($token, $model, $payload, $stream, &$error, &$output_started = false)
{
    $settings = get_option('aiomatic_Main_Settings', array());
    $label = aiomatic_google_argon_label($model);
    $ch = curl_init();
    if ($ch === false) {
        $error = 'Error: failed to init curl in Google AI API';
        return false;
    }
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':';
    $url .= $stream ? 'streamGenerateContent?alt=sse' : 'generateContent';
    if (!empty($settings['proxy_url']) && !in_array($settings['proxy_url'], array('disable', 'disabled'), true)) {
        $proxies = explode(',', $settings['proxy_url']);
        $index = array_rand($proxies);
        curl_setopt($ch, CURLOPT_PROXY, trim($proxies[$index]));
        if (!empty($settings['proxy_auth'])) {
            $auth = explode(',', $settings['proxy_auth']);
            if (!empty($auth[$index])) {
                curl_setopt($ch, CURLOPT_PROXYUSERPWD, trim($auth[$index]));
            }
        }
    }
    try {
        $body = aiomatic_safe_json_encode(aimogen_gemini_apply_storage_preference($payload));
    } catch (Exception $exception) {
        aimogen_curl_close($ch);
        $error = 'Error encoding the ' . $label . ' request: ' . $exception->getMessage();
        return false;
    }
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'x-goog-api-key: ' . $token));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    // Hard reasoning prompts can take several minutes; respect an explicit timeout.
    curl_setopt($ch, CURLOPT_TIMEOUT, !empty($settings['max_timeout']) ? max(1, (int) $settings['max_timeout']) : 900);

    $buffer = '';
    $collected = array();
    $received_event = false;
    $consume = function ($event) use (&$collected, &$error, &$received_event, &$output_started, $label) {
        $data = array();
        foreach (explode("\n", $event) as $line) {
            if (strpos($line, 'data:') === 0) {
                $data[] = ltrim(substr($line, 5), ' ');
            }
        }
        $json = implode("\n", $data);
        if ($json === '' || $json === '[DONE]') {
            return;
        }
        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            $error = 'Invalid JSON in the ' . $label . ' stream.';
            return;
        }
        $received_event = true;
        if (isset($decoded['error'])) {
            $error = isset($decoded['error']['message']) ? $decoded['error']['message'] : 'Google API streaming error';
            return;
        }
        if (isset($decoded['promptFeedback'])) {
            $collected['promptFeedback'] = $decoded['promptFeedback'];
        }
        if (isset($decoded['candidates'][0])) {
            $candidate = $decoded['candidates'][0];
            foreach (isset($candidate['content']['parts']) ? $candidate['content']['parts'] : array() as $part) {
                $collected['candidates'][0]['content']['parts'][] = $part;
                if (isset($part['text']) && empty($part['thought'])) {
                    $output_started = true;
                    aiomatic_google_argon_emit($part['text']);
                }
            }
            $collected['candidates'][0]['content']['role'] = 'model';
            if (!empty($candidate['finishReason'])) {
                $collected['candidates'][0]['finishReason'] = $candidate['finishReason'];
            }
        }
    };
    if ($stream) {
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($handle, $chunk) use (&$buffer, $consume) {
            $buffer .= $chunk;
            while (preg_match('/\r?\n\r?\n/', $buffer, $separator, PREG_OFFSET_CAPTURE)) {
                $offset = $separator[0][1];
                $consume(substr($buffer, 0, $offset));
                $buffer = substr($buffer, $offset + strlen($separator[0][0]));
            }
            return strlen($chunk);
        });
    }
    $response = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_errno($ch) ? curl_error($ch) : '';
    aimogen_curl_close($ch);
    if ($response === false || $curl_error !== '') {
        $error = 'Google API request failed: ' . $curl_error;
        return false;
    }
    if ($stream && strpos(ltrim($buffer), 'data:') === 0) {
        $consume($buffer);
    }
    $decoded = $stream && $received_event ? $collected : json_decode($stream ? $buffer : $response, true);
    if (isset($decoded['error'])) {
        $error = isset($decoded['error']['message']) ? $decoded['error']['message'] : 'Google API request failed';
        return false;
    }
    if ($error !== '') {
        return false;
    }
    if ($status >= 400 || !is_array($decoded)) {
        $error = 'Invalid ' . $label . ' response (HTTP ' . $status . ').';
        return false;
    }
    return $decoded;
}

/** Gemini 4 (Argon, Carbon) uses signed tool turns, a shared context window and no sampling controls. */
function aiomatic_generate_text_google_argon($token, $model, $messages, $vision_file, $functions, $max_tokens, $stream, &$error, &$retry_allowed = true)
{
    $error = '';
    $label = aiomatic_google_argon_label($model);
    if (is_string($messages)) {
        $messages = array(array('role' => 'user', 'content' => $messages));
    }
    if (!is_array($messages)) {
        $error = 'Invalid ' . $label . ' conversation.';
        return false;
    }
    $contents = $instructions = array();
    foreach ($messages as $message) {
        $role = isset($message['role']) ? $message['role'] : 'user';
        $parts = isset($message['parts']) ? $message['parts'] : array();
        if (empty($parts) && isset($message['content']) && is_string($message['content']) && $message['content'] !== '') {
            $parts = array(array('text' => $message['content']));
        }
        if (empty($parts)) {
            continue;
        }
        if ($role === 'system' || $role === 'developer') {
            $instructions = array_merge($instructions, $parts);
        } else {
            $contents[] = array('role' => in_array($role, array('model', 'assistant'), true) ? 'model' : 'user', 'parts' => $parts);
        }
    }
    if (empty($contents)) {
        $error = 'Empty ' . $label . ' conversation.';
        return false;
    }
    // Gemini 4 does not accept an unfinished assistant/model prefill.
    if (end($contents)['role'] === 'model') {
        $error = $label . ' requires a user message after the last assistant response.';
        return false;
    }
    if ($vision_file !== '') {
        $image = aiomatic_get_base64_from_url($vision_file);
        if (empty($image)) {
            $error = 'Could not load the ' . $label . ' vision image.';
            return false;
        }
        $contents[count($contents) - 1]['parts'][] = array('inlineData' => array('mimeType' => 'image/jpeg', 'data' => $image));
    }
    // Direct REST supports 32K per non-streaming call and 64K per stream.
    // Long decode needs a separate continuation loop and is not advertised here.
    $limit = $stream ? 65536 : 32768;
    $payload = array('contents' => $contents, 'generationConfig' => array('maxOutputTokens' => (int) $max_tokens > 0 ? min((int) $max_tokens, $limit) : $limit));
    if (!empty($instructions)) {
        $payload['systemInstruction'] = array('parts' => $instructions);
    }
    $declarations = array();
    foreach (isset($functions['functions']) ? $functions['functions'] : array() as $tool) {
        if (!isset($tool['type']) || $tool['type'] !== 'function') {
            continue;
        }
        // Aiomatic's function/parameter serializers flatten nested schema metadata.
        $definition = $tool['function'] instanceof JsonSerializable
            ? (array) json_decode(aiomatic_safe_json_encode($tool['function']))
            : (array) $tool['function'];
        $schema = array('type' => 'object', 'properties' => new stdClass());
        $parameters = isset($definition['parameters']) ? (array) $definition['parameters'] : array();
        if (isset($parameters['properties'])) {
            $schema = $parameters;
        } else {
            $properties = $required = array();
            foreach ($parameters as $parameter) {
                $parameter = (array) $parameter;
                if (empty($parameter['name'])) {
                    continue;
                }
                $name = $parameter['name'];
                unset($parameter['name']);
                if (!empty($parameter['required'])) {
                    $required[] = $name;
                }
                unset($parameter['required']);
                $properties[$name] = $parameter;
            }
            $schema['properties'] = (object) $properties;
            if ($required) {
                $schema['required'] = $required;
            }
        }
        $declarations[] = array('name' => $definition['name'], 'description' => isset($definition['description']) ? $definition['description'] : '', 'parametersJsonSchema' => $schema);
    }
    if ($declarations) {
        $payload['tools'] = array(array('functionDeclarations' => $declarations));
    }
    $declared_names = array_column($declarations, 'name');
    // Complete tool rounds on the server so signed parts never pass through JS.
    for ($round = 0; $round < 5; $round++) {
        $output_started = false;
        $response = aiomatic_google_argon_request($token, $model, $payload, $stream, $error, $output_started);
        if ($output_started) {
            $retry_allowed = false;
        }
        if ($response === false) {
            return false;
        }
        $candidate = isset($response['candidates'][0]) ? $response['candidates'][0] : array();
        $reason = isset($candidate['finishReason']) ? $candidate['finishReason'] : '';
        if ($reason !== 'STOP') {
            $block = isset($response['promptFeedback']['blockReason']) ? $response['promptFeedback']['blockReason'] : '';
            $error = $label . ' did not complete the response (' . ($reason !== '' ? $reason : ($block !== '' ? $block : 'stream ended before completion')) . ').';
            if ($reason === 'MAX_TOKENS') {
                $error .= ' Increase the output token limit.';
            }
            if ($reason !== '' || $block !== '') {
                $retry_allowed = false;
            }
            return false;
        }
        $parts = isset($candidate['content']['parts']) ? $candidate['content']['parts'] : array();
        $text = '';
        $calls = array();
        foreach ($parts as $part) {
            if (isset($part['text']) && empty($part['thought'])) {
                $text .= $part['text'];
            }
            if (isset($part['functionCall'])) {
                $call = $part['functionCall'];
                if (empty($call['name']) || !in_array($call['name'], $declared_names, true) || !aiomatic_is_restricted_function_allowed($call['name'])) {
                    $error = 'Function call denied, not enough permissions or function not enabled.';
                    return false;
                }
                $calls[] = $call;
            }
        }
        if (!$calls) {
            if ($text === '') {
                $reason = isset($candidate['finishReason']) ? $candidate['finishReason'] : (isset($response['promptFeedback']['blockReason']) ? $response['promptFeedback']['blockReason'] : 'empty output');
                $error = $label . ' returned no answer (' . $reason . '). For MAX_TOKENS, increase the output token limit.';
                return false;
            }
            if ($stream) {
                aiomatic_google_argon_emit('[DONE]');
                return '';
            }
            return $text;
        }
        if ($round === 4) {
            $error = $label . ' reached the tool-call round limit.';
            return false;
        }
        $reply = (object) array('tool_calls' => array());
        foreach ($calls as $call) {
            $reply->tool_calls[] = (object) array('id' => isset($call['id']) ? $call['id'] : uniqid('call_', true), 'type' => 'function', 'function' => (object) array('name' => $call['name'], 'arguments' => (object) (isset($call['args']) ? $call['args'] : array())));
        }
        // Restarting the original request after this point could repeat side effects.
        $retry_allowed = false;
        $reply = apply_filters('aiomatic_google_tools_ai_reply_raw', $reply);
        if (!empty($reply->aiomatic_tool_end_conversation[0]['content'])) {
            $direct = 'AiomaticConversationEnded~!@#$%^&*()';
            $scope = 'end_message';
        } elseif (!empty($reply->aiomatic_tool_direct_message[0]['content'])) {
            $direct = $reply->aiomatic_tool_direct_message[0]['content'];
            $scope = 'user_message';
        } else {
            $direct = null;
        }
        if ($direct !== null) {
            if ($stream) {
                aiomatic_google_argon_emit(aiomatic_safe_json_encode(array('scope' => $scope, 'data' => $scope === 'end_message' ? '' : $direct)), 'aimogen_google_tool_result');
                aiomatic_google_argon_emit('[DONE]');
                return '';
            }
            return $direct;
        }
        $results = isset($reply->aiomatic_tool_results) ? $reply->aiomatic_tool_results : array();
        $response_parts = array();
        foreach ($calls as $index => $call) {
            $found = false;
            foreach ($results as $result) {
                if (isset($result['tool_call_id']) && $result['tool_call_id'] === $reply->tool_calls[$index]->id && isset($result['content'])) {
                    $function_response = array('name' => $call['name'], 'response' => array('content' => $result['content']));
                    if (isset($call['id'])) {
                        $function_response['id'] = $call['id'];
                    }
                    $response_parts[] = array('functionResponse' => $function_response);
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $error = 'No result returned for ' . $label . ' function: ' . $call['name'];
                return false;
            }
        }
        $payload['contents'][] = array('role' => 'model', 'parts' => $parts);
        $payload['contents'][] = array('role' => 'user', 'parts' => $response_parts);
    }
    return false;
}
