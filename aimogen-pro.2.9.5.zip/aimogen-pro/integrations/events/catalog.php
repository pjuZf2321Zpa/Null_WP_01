<?php
defined('ABSPATH') || exit;

/** Event definitions and pure filter validation shared by discovery and capture. */
class Aimogen_MCP_Event_Catalog {
    public static function all() {
        static $all = null;
        if ($all !== null) { return $all; }
        $all = array();
        foreach (array(
            array('post.created', 'Prepare an editorial checklist or route a new draft.', 'Content and editorial work'),
            array('post.updated', 'Check changed content, facts, links, or metadata.', 'Content and editorial work'),
            array('post.published', 'Audit SEO and prepare promotion.', 'Content and editorial work'),
            array('post.unpublished', 'Flag removed public content and affected links.', 'Content and editorial work'),
            array('post.scheduled', 'Prepare an editorial calendar and promotion plan.', 'Content and editorial work'),
            array('post.review_requested', 'Review a submission before an editor publishes it.', 'Content and editorial work'),
            array('post.status_changed', 'Track custom editorial workflows.', 'Content and editorial work'),
            array('post.trashed', 'Assess broken links and content removal.', 'Content and editorial work'),
            array('post.restored', 'Recheck restored content before promotion.', 'Content and editorial work'),
            array('post.deleted', 'Identify links and indexes requiring cleanup.', 'Content and editorial work'),
            array('post.featured_image_changed', 'Check visual consistency and image accessibility.', 'Content and editorial work'),
            array('post.terms_changed', 'Review categories, tags, and internal linking.', 'Content and editorial work'),
            array('post.seo_metadata_changed', 'Check metadata after an editor changes it.', 'Content and editorial work'),
            array('post.permalink_changed', 'Identify affected links and redirect needs.', 'Content and editorial work'),
            array('media.uploaded', 'Suggest alt text and identify where an asset can be used.', 'Media and taxonomy'),
            array('media.updated', 'Review changed media titles, descriptions, or dimensions.', 'Media and taxonomy'),
            array('media.alt_text_changed', 'Check accessibility and descriptive accuracy.', 'Media and taxonomy'),
            array('media.deleted', 'Find content referring to removed media.', 'Media and taxonomy'),
            array('taxonomy.term_created', 'Prepare term descriptions and category guidance.', 'Media and taxonomy'),
            array('taxonomy.term_updated', 'Check taxonomy descriptions and navigation changes.', 'Media and taxonomy'),
            array('taxonomy.term_deleted', 'Review category landing pages and affected content.', 'Media and taxonomy'),
            array('comment.created', 'Summarize feedback or draft a response.', 'Comments and discussion'),
            array('comment.updated', 'Review changed feedback.', 'Comments and discussion'),
            array('comment.approved', 'Respond to newly visible feedback.', 'Comments and discussion'),
            array('comment.unapproved', 'Flag feedback requiring moderator attention.', 'Comments and discussion'),
            array('comment.marked_spam', 'Summarize recurring abuse patterns.', 'Comments and discussion'),
            array('comment.trashed', 'Review discussion removals.', 'Comments and discussion'),
            array('comment.restored', 'Resume handling restored feedback.', 'Comments and discussion'),
            array('comment.deleted', 'Update moderation summaries.', 'Comments and discussion'),
            array('user.registered', 'Prepare onboarding suggestions.', 'Users and access'),
            array('user.profile_updated', 'Review author bios or customer context.', 'Users and access'),
            array('user.role_changed', 'Review access changes.', 'Users and access'),
            array('user.password_reset', 'Audit an account-recovery event.', 'Users and access'),
            array('user.deleted', 'Review reassigned content and access removal.', 'Users and access'),
            array('woocommerce.order.created', 'Summarize a new order and suggest fulfillment priorities.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.updated', 'Review changed totals, line items, or order details.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.status_changed', 'Handle custom order workflows.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.paid', 'Prepare a fulfillment summary.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.completed', 'Prepare post-purchase follow-up drafts.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.failed', 'Explain a failed-order queue.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.cancelled', 'Summarize cancellation trends or draft a follow-up.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.on_hold', 'Review orders awaiting payment or action.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.refunded', 'Summarize refund reasons and outcomes.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.note_created', 'Summarize fulfillment or support notes.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.item_created', 'Review an order-line addition.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.item_updated', 'Review an order-line change.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.item_deleted', 'Review removed order lines.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.trashed', 'Audit removed orders.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.restored', 'Resume follow-up on a restored order.', 'WooCommerce orders and refunds'),
            array('woocommerce.order.deleted', 'Update operational summaries.', 'WooCommerce orders and refunds'),
            array('woocommerce.refund.created', 'Prepare a refund case summary.', 'WooCommerce orders and refunds'),
            array('woocommerce.refund.deleted', 'Review a removed refund record.', 'WooCommerce orders and refunds'),
            array('woocommerce.product.created', 'Prepare a product-launch checklist.', 'WooCommerce products and inventory'),
            array('woocommerce.product.updated', 'Check changed product descriptions and specifications.', 'WooCommerce products and inventory'),
            array('woocommerce.product.published', 'Prepare launch content from verified product details.', 'WooCommerce products and inventory'),
            array('woocommerce.product.trashed', 'Review removed catalog entries and landing pages.', 'WooCommerce products and inventory'),
            array('woocommerce.product.restored', 'Review a returned catalog entry.', 'WooCommerce products and inventory'),
            array('woocommerce.product.deleted', 'Find related content needing cleanup.', 'WooCommerce products and inventory'),
            array('woocommerce.variation.created', 'Check variation naming and completeness.', 'WooCommerce products and inventory'),
            array('woocommerce.variation.updated', 'Review changed variation options.', 'WooCommerce products and inventory'),
            array('woocommerce.variation.deleted', 'Review affected product descriptions.', 'WooCommerce products and inventory'),
            array('woocommerce.product.stock_changed', 'Summarize inventory movement.', 'WooCommerce products and inventory'),
            array('woocommerce.product.stock_status_changed', 'Handle custom inventory states.', 'WooCommerce products and inventory'),
            array('woocommerce.product.low_stock', 'Prepare a restocking summary.', 'WooCommerce products and inventory'),
            array('woocommerce.product.out_of_stock', 'Suggest catalog and campaign adjustments.', 'WooCommerce products and inventory'),
            array('woocommerce.product.back_in_stock', 'Draft a back-in-stock announcement.', 'WooCommerce products and inventory'),
            array('woocommerce.product.price_changed', 'Check landing pages for stale prices.', 'WooCommerce products and inventory'),
            array('woocommerce.product.sale_started', 'Prepare promotion copy.', 'WooCommerce products and inventory'),
            array('woocommerce.product.sale_ended', 'Find stale sale claims.', 'WooCommerce products and inventory'),
            array('woocommerce.review.created', 'Filter low-rated feedback and draft a response.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.review.updated', 'Revisit a response draft after feedback changes.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.review.approved', 'Handle newly public product feedback.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.review.rating_changed', 'Flag deteriorating customer feedback.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.review.deleted', 'Update feedback summaries.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.coupon.created', 'Prepare promotional campaign suggestions.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.coupon.updated', 'Review changed promotion terms.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.coupon.deleted', 'Identify promotion copy requiring cleanup.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.coupon.usage_changed', 'Summarize coupon adoption or reversals.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.customer.created', 'Prepare customer onboarding drafts.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.customer.updated', 'Refresh customer context using allowed fields.', 'WooCommerce reviews, coupons, and customers'),
            array('woocommerce.subscription.created', 'Prepare subscription onboarding.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.status_changed', 'Summarize subscription lifecycle changes.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.activated', 'Prepare activation or reactivation guidance.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.on_hold', 'Review suspended subscriptions.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.cancellation_requested', 'Draft retention options for review.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.cancelled', 'Summarize cancellations.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.expired', 'Prepare reactivation suggestions.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.renewal_due', 'Prepare a renewal queue summary.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.renewal_paid', 'Summarize successful renewals.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.renewal_failed', 'Draft a payment-recovery response.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.payment_completed', 'Review initial or recurring payments.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.payment_failed', 'Review payment failures.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.trial_ended', 'Prepare trial-conversion follow-up drafts.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('woocommerce.subscription.plan_switched', 'Review a plan change.', 'WooCommerce Subscriptions (conditional adapter)'),
            array('form.submitted', 'Qualify a lead, research a company, or summarize a support request.', 'Forms and leads (provider adapters)'),
            array('form.submission_rejected', 'Review aggregated form friction using metadata only.', 'Forms and leads (provider adapters)'),
            array('form.notification_failed', 'Flag submissions whose email notification failed.', 'Forms and leads (provider adapters)'),
            array('membership.level_changed', 'Prepare onboarding or access-change guidance.', 'Paid Memberships Pro (conditional adapter)'),
            array('membership.checkout_completed', 'Prepare a welcome draft.', 'Paid Memberships Pro (conditional adapter)'),
            array('membership.expired', 'Prepare a renewal suggestion.', 'Paid Memberships Pro (conditional adapter)'),
            array('membership.payment_completed', 'Summarize membership revenue events.', 'Paid Memberships Pro (conditional adapter)'),
            array('membership.payment_failed', 'Draft payment-recovery guidance.', 'Paid Memberships Pro (conditional adapter)'),
            array('membership.billing_updated', 'Review a billing-update event without payment credentials.', 'Paid Memberships Pro (conditional adapter)'),
            array('plugin.activated', 'Review a newly enabled integration.', 'Site maintenance and delivery'),
            array('plugin.deactivated', 'Identify affected workflows.', 'Site maintenance and delivery'),
            array('plugin.updated', 'Prepare a change summary and follow-up checks.', 'Site maintenance and delivery'),
            array('plugin.update_failed', 'Prepare an actionable maintenance report.', 'Site maintenance and delivery'),
            array('theme.activated', 'Review navigation and content after a theme switch.', 'Site maintenance and delivery'),
            array('theme.updated', 'Prepare a design regression checklist.', 'Site maintenance and delivery'),
            array('theme.update_failed', 'Explain a failed theme update.', 'Site maintenance and delivery'),
            array('wordpress.updated', 'Prepare a compatibility checklist.', 'Site maintenance and delivery'),
            array('wordpress.update_failed', 'Prepare a recovery checklist.', 'Site maintenance and delivery'),
            array('site.health_changed', 'Flag newly worse core health results.', 'Site maintenance and delivery'),
            array('email.delivery_failed', 'Report WordPress email handoff failures.', 'Site maintenance and delivery'),
            array('aimogen.automation.started', 'Track a meaningful automation run.', 'Aimogen operations'),
            array('aimogen.automation.completed', 'Review a completed WordPress-triggered OmniBlock run.', 'Aimogen operations'),
            array('aimogen.automation.failed', 'Explain a failed automation and suggest recovery.', 'Aimogen operations'),
            array('aimogen.editor.changes_applied', 'Audit applied AI edits.', 'Aimogen operations'),
            array('aimogen.editor.changes_undone', 'Review reverted changes and improve future instructions.', 'Aimogen operations'),
            array('aimogen.provider.failover', 'Explain provider/model fallback.', 'Aimogen operations'),
            array('aimogen.provider.key_state_changed', 'Review provider availability.', 'Aimogen operations'),
            array('aimogen.provider.key_recovered', 'Resume delayed workflows.', 'Aimogen operations'),
            array('security.administrator_granted', 'Review newly granted administrator access.', 'Security observations and registered findings'),
            array('security.administrator_removed', 'Review removed administrator access.', 'Security observations and registered findings'),
            array('security.login_failures_detected', 'Report a measured burst of failed logins.', 'Security observations and registered findings'),
            array('security.issue.detected', 'Summarize a reported security finding using its evidence reference.', 'Security observations and registered findings'),
        ) as $row) {
            $name = $row[0];
            $family = self::family($name);
            $dependency = strpos($name, 'woocommerce.subscription.') === 0 ? 'subscriptions' :
                (strpos($name, 'woocommerce.') === 0 ? 'woocommerce' :
                (strpos($name, 'membership.') === 0 ? 'membership' :
                (strpos($name, 'form.') === 0 ? ($name === 'form.submitted' ? 'forms' : 'cf7') :
                ($name === 'post.seo_metadata_changed' ? 'seo' : ($name === 'security.issue.detected' ? 'security' : 'core')))));
            $filters = self::event_filters($name,$family);
            $properties = array();
            foreach ($filters as $key => $type) {
                if ($type === 'list') {
                    $properties[$key] = array('type'=>'array','items'=>array('type'=>array('string','integer')),'minItems'=>1,'maxItems'=>100,'uniqueItems'=>true);
                } elseif ($type === 'rating') {
                    $properties[$key] = array('type'=>'integer','minimum'=>0,'maximum'=>5);
                } elseif ($type === 'money') {
                    $properties[$key] = array('type'=>'string','pattern'=>'^[0-9]{1,18}(\\.[0-9]{1,8})?$');
                } elseif ($type === 'boolean') {
                    $properties[$key] = array('type'=>'boolean');
                } elseif ($type === 'fields') {
                    $properties[$key] = array('type'=>'object','maxProperties'=>20,'additionalProperties'=>array('type'=>'string','maxLength'=>200));
                } else {
                    $properties[$key] = array('type'=>'string','minLength'=>1,'maxLength'=>80);
                }
            }
            $payload = array();
            foreach (self::payload_fields($family) as $field => $type) {
                $payload[$field] = array('type'=>$type);
                if ($type === 'array') { $payload[$field]['items'] = array('type'=>array('string','integer')); }
                if ($type === 'object') { $payload[$field]['additionalProperties'] = array('type'=>'string'); }
            }
            $all[$name] = array(
                'name'=>$name, 'description'=>$row[1], 'delivery'=>array('webhook'),
                'inputSchema'=>array('type'=>'object','properties'=>(object)$properties,'additionalProperties'=>false),
                'payloadSchema'=>array('type'=>'object','properties'=>(object)$payload,'required'=>array('site_id','resource_type','resource_id'),'additionalProperties'=>false),
                '_family'=>$family, '_dependency'=>$dependency, '_group'=>$row[2],
                '_access'=>in_array($family,array('post','media','taxonomy','comment','product','review'),true) ? 'read' : 'admin',
            );
        }
        return $all;
    }

    public static function definition($name) {
        $all = self::all();
        return is_string($name) && isset($all[$name]) ? $all[$name] : null;
    }

    public static function family($name) {
        foreach (array('woocommerce.subscription.'=>'subscription','woocommerce.order.'=>'order','woocommerce.refund.'=>'order',
            'woocommerce.variation.'=>'product','woocommerce.product.'=>'product','woocommerce.review.'=>'review',
            'woocommerce.coupon.'=>'coupon','woocommerce.customer.'=>'customer','taxonomy.'=>'taxonomy',
            'post.'=>'post','media.'=>'media','comment.'=>'comment','user.'=>'user','form.'=>'form',
            'membership.'=>'membership','aimogen.'=>'aimogen','security.'=>'security') as $prefix=>$family) {
            if (strpos($name,$prefix) === 0) { return $family; }
        }
        return 'maintenance';
    }

    public static function filters($family) {
        $families = array(
            'post'=>array('post_ids'=>'list','post_types'=>'list','statuses'=>'list','previous_statuses'=>'list','author_ids'=>'list','taxonomies'=>'list','term_ids'=>'list','changed_fields'=>'list'),
            'media'=>array('media_ids'=>'list','mime_types'=>'list','parent_ids'=>'list','changed_fields'=>'list'),
            'taxonomy'=>array('taxonomies'=>'list','term_ids'=>'list','parent_ids'=>'list','changed_fields'=>'list'),
            'comment'=>array('post_ids'=>'list','comment_ids'=>'list','comment_types'=>'list','statuses'=>'list'),
            'user'=>array('user_ids'=>'list','roles'=>'list','changed_fields'=>'list'),
            'order'=>array('order_ids'=>'list','statuses'=>'list','previous_statuses'=>'list','product_ids'=>'list','currency'=>'string','minimum_total'=>'money','maximum_total'=>'money','payment_method_ids'=>'list','changed_fields'=>'list'),
            'product'=>array('product_ids'=>'list','parent_ids'=>'list','product_types'=>'list','category_ids'=>'list','skus'=>'list','stock_statuses'=>'list','changed_fields'=>'list'),
            'review'=>array('product_ids'=>'list','review_ids'=>'list','minimum_rating'=>'rating','maximum_rating'=>'rating','statuses'=>'list'),
            'coupon'=>array('coupon_ids'=>'list','codes'=>'list','changed_fields'=>'list'),
            'customer'=>array('customer_ids'=>'list','changed_fields'=>'list'),
            'subscription'=>array('subscription_ids'=>'list','product_ids'=>'list','statuses'=>'list','previous_statuses'=>'list'),
            'form'=>array('providers'=>'list','form_ids'=>'list','statuses'=>'list','field_matches'=>'fields'),
            'membership'=>array('user_ids'=>'list','level_ids'=>'list','statuses'=>'list'),
            'maintenance'=>array('component_ids'=>'list','component_types'=>'list','automatic'=>'boolean','severities'=>'list','changed_fields'=>'list'),
            'aimogen'=>array('rule_ids'=>'list','providers'=>'list','models'=>'list','outcomes'=>'list','error_categories'=>'list'),
            'security'=>array('providers'=>'list','finding_ids'=>'list','severities'=>'list','component_ids'=>'list','user_ids'=>'list'),
        );
        return array_merge(array('include_mcp_changes'=>'boolean'),isset($families[$family]) ? $families[$family] : array());
    }

    /** Discovery and validation expose only filters populated by that source. */
    public static function event_filters($name,$family) {
        $filters=self::filters($family);
        $changes=array('post.updated','post.published','post.unpublished','post.scheduled','post.review_requested','post.status_changed',
            'post.featured_image_changed','post.terms_changed','post.seo_metadata_changed','post.permalink_changed','user.profile_updated',
            'woocommerce.order.updated','woocommerce.product.updated','woocommerce.variation.updated');
        if (!in_array($name,$changes,true)) { unset($filters['changed_fields']); }
        $previous=array('post.published','post.unpublished','post.scheduled','post.review_requested','post.status_changed','post.trashed',
            'woocommerce.order.status_changed','woocommerce.order.completed','woocommerce.order.failed','woocommerce.order.cancelled','woocommerce.order.on_hold',
            'woocommerce.subscription.status_changed','woocommerce.subscription.activated','woocommerce.subscription.on_hold',
            'woocommerce.subscription.cancellation_requested','woocommerce.subscription.cancelled','woocommerce.subscription.expired');
        if (!in_array($name,$previous,true)) { unset($filters['previous_statuses']); }
        if ($family==='maintenance') {
            if (!preg_match('/\\.(updated|update_failed)$/',$name)) { unset($filters['automatic']); }
            if (!in_array($name,array('plugin.update_failed','theme.update_failed','wordpress.update_failed','site.health_changed','email.delivery_failed'),true)) { unset($filters['severities']); }
        }
        if ($family==='aimogen') {
            $supported=strpos($name,'aimogen.automation.')===0 ? array('rule_ids','outcomes') :
                (strpos($name,'aimogen.editor.')===0 ? array('post_ids') :
                ($name==='aimogen.provider.failover' ? array('models','error_categories') :
                ($name==='aimogen.provider.key_state_changed' ? array('providers','error_categories') : array('providers'))));
            $filters=array_intersect_key(array_merge($filters,array('post_ids'=>'list')),array_flip(array_merge(array('include_mcp_changes'),$supported)));
        }
        if ($family==='security' && $name!=='security.issue.detected') {
            $supported=$name==='security.login_failures_detected' ? array('providers','severities') : array('providers','severities','user_ids');
            $filters=array_intersect_key($filters,array_flip(array_merge(array('include_mcp_changes'),$supported)));
        }
        if ($family==='form' && $name!=='form.submitted') { unset($filters['field_matches']); }
        return $filters;
    }

    public static function payload_fields($family) {
        $common = array('site_id'=>'string','resource_type'=>'string','resource_id'=>'string','actor_id'=>'string','source'=>'string','url'=>'string','changed_fields'=>'array');
        $families = array(
            'post'=>array('post_id'=>'string','post_type'=>'string','status'=>'string','previous_status'=>'string','author_id'=>'string','title'=>'string','excerpt'=>'string','taxonomy'=>'string','taxonomies'=>'array','term_ids'=>'array','previous_url'=>'string'),
            'media'=>array('media_id'=>'string','mime_type'=>'string','parent_id'=>'string','title'=>'string','alt_text'=>'string','width'=>'integer','height'=>'integer'),
            'taxonomy'=>array('taxonomy'=>'string','term_id'=>'string','parent_id'=>'string','name'=>'string','slug'=>'string','description'=>'string'),
            'comment'=>array('post_id'=>'string','comment_id'=>'string','parent_comment_id'=>'string','comment_type'=>'string','status'=>'string','text'=>'string'),
            'user'=>array('user_id'=>'string','display_name'=>'string','roles'=>'array'),
            'order'=>array('order_id'=>'string','status'=>'string','previous_status'=>'string','currency'=>'string','total'=>'string','product_ids'=>'array','item_count'=>'integer','refund_id'=>'string','refund_amount'=>'string','note_id'=>'string','note'=>'string','item_id'=>'string','payment_method_id'=>'string'),
            'product'=>array('product_id'=>'string','parent_id'=>'string','product_type'=>'string','name'=>'string','sku'=>'string','price'=>'string','previous_price'=>'string','quantity'=>'string','previous_quantity'=>'string','stock_status'=>'string','previous_stock_status'=>'string','threshold'=>'string','category_ids'=>'array'),
            'review'=>array('product_id'=>'string','review_id'=>'string','rating'=>'integer','previous_rating'=>'integer','status'=>'string','text'=>'string'),
            'coupon'=>array('coupon_id'=>'string','code'=>'string','discount_type'=>'string','amount'=>'string','usage_count'=>'integer'),
            'customer'=>array('customer_id'=>'string','display_name'=>'string'),
            'subscription'=>array('subscription_id'=>'string','order_id'=>'string','status'=>'string','previous_status'=>'string','product_ids'=>'array','currency'=>'string','total'=>'string'),
            'form'=>array('provider'=>'string','form_id'=>'string','entry_id'=>'string','status'=>'string','fields'=>'object'),
            'membership'=>array('provider'=>'string','user_id'=>'string','level_id'=>'string','previous_level_id'=>'string','order_id'=>'string','status'=>'string','currency'=>'string','total'=>'string'),
            'maintenance'=>array('component_id'=>'string','component_type'=>'string','previous_version'=>'string','version'=>'string','automatic'=>'boolean','severity'=>'string','error_category'=>'string','critical'=>'integer','recommended'=>'integer','good'=>'integer'),
            'aimogen'=>array('rule_id'=>'string','run_id'=>'string','outcome'=>'string','provider'=>'string','model'=>'string','previous_model'=>'string','error_category'=>'string','post_id'=>'string','output_ids'=>'array'),
            'security'=>array('provider'=>'string','finding_id'=>'string','evidence_reference'=>'string','severity'=>'string','component_id'=>'string','user_id'=>'string','count'=>'integer','window_seconds'=>'integer'),
        );
        return array_merge($common, isset($families[$family]) ? $families[$family] : array());
    }

    public static function validate_arguments($name, $arguments) {
        $definition = self::definition($name);
        if (!$definition || !is_array($arguments) || (count($arguments) && array_keys($arguments) === range(0,count($arguments)-1))) {
            return new WP_Error('invalid_arguments','Unknown event or invalid filter object.');
        }
        $allowed = self::event_filters($name,$definition['_family']);
        $normalized = array();
        foreach ($arguments as $key=>$value) {
            if (!isset($allowed[$key])) { return new WP_Error('invalid_arguments','Unsupported event filter.'); }
            $type = $allowed[$key];
            if ($type === 'list') {
                if (!is_array($value) || !$value || count($value)>100 || array_keys($value)!==range(0,count($value)-1)) { return new WP_Error('invalid_arguments','Filters require a list of 1 to 100 values.'); }
                $values = array();
                foreach ($value as $item) {
                    if ((!is_string($item) && !is_int($item)) || strlen((string)$item)>100 || (string)$item === '' || preg_match('/[\\x00-\\x1f]/',(string)$item)) { return new WP_Error('invalid_arguments','Invalid filter value.'); }
                    if (in_array($key,array('post_ids','author_ids','media_ids','parent_ids','term_ids','comment_ids','user_ids','order_ids','product_ids','category_ids','review_ids','coupon_ids','customer_ids','subscription_ids','level_ids'),true) && !preg_match('/^[0-9]+$/',(string)$item)) { return new WP_Error('invalid_arguments','WordPress resource IDs must contain digits only.'); }
                    $values[] = (string)$item;
                }
                $value = array_values(array_unique($values)); sort($value,SORT_STRING);
            } elseif ($type === 'rating') {
                if (!is_int($value) || $value<0 || $value>5) { return new WP_Error('invalid_arguments','Review ratings must be integers from 0 to 5.'); }
            } elseif ($type === 'money') {
                if (!is_string($value) || !preg_match('/^[0-9]{1,18}(\\.[0-9]{1,8})?$/',$value)) { return new WP_Error('invalid_arguments','Amounts must be decimal strings.'); }
            } elseif ($type === 'boolean') {
                if (!is_bool($value)) { return new WP_Error('invalid_arguments','A boolean is required.'); }
            } elseif ($type === 'fields') {
                if (!is_array($value) || !$value || count($value)>20) { return new WP_Error('invalid_arguments','Invalid field filters.'); }
                foreach ($value as $field=>$match) {
                    if (!preg_match('/^[A-Za-z0-9_.-]{1,64}$/',(string)$field) || !is_string($match) || strlen($match)>200) { return new WP_Error('invalid_arguments','Invalid field filter.'); }
                }
                ksort($value,SORT_STRING);
            } elseif (!is_string($value) || $value === '' || strlen($value)>80) {
                return new WP_Error('invalid_arguments','Invalid string filter.');
            }
            $normalized[$key]=$key==='currency' ? strtoupper($value) : $value;
        }
        foreach (array(array('minimum_rating','maximum_rating'),array('minimum_total','maximum_total')) as $range) {
            if (isset($normalized[$range[0]],$normalized[$range[1]]) && self::decimal_compare($normalized[$range[0]],$normalized[$range[1]])>0) {
                return new WP_Error('invalid_arguments','Minimum cannot exceed maximum.');
            }
        }
        if ((isset($normalized['minimum_total']) || isset($normalized['maximum_total'])) && empty($normalized['currency'])) {
            return new WP_Error('invalid_arguments','Amount filters require a currency.');
        }
        ksort($normalized,SORT_STRING);
        return $normalized;
    }

    public static function matches($arguments, $data) {
        $map = array('post_ids'=>'post_id','post_types'=>'post_type','statuses'=>'status','previous_statuses'=>'previous_status','author_ids'=>'author_id',
            'taxonomies'=>'taxonomy','term_ids'=>'term_ids','media_ids'=>'media_id','mime_types'=>'mime_type','parent_ids'=>'parent_id',
            'comment_ids'=>'comment_id','comment_types'=>'comment_type','user_ids'=>'user_id','roles'=>'roles','order_ids'=>'order_id',
            'product_ids'=>'product_ids','payment_method_ids'=>'payment_method_id','product_types'=>'product_type','category_ids'=>'category_ids',
            'skus'=>'sku','stock_statuses'=>'stock_status','review_ids'=>'review_id','coupon_ids'=>'coupon_id','codes'=>'code',
            'customer_ids'=>'customer_id','subscription_ids'=>'subscription_id','providers'=>'provider','form_ids'=>'form_id','level_ids'=>'level_id',
            'component_ids'=>'component_id','component_types'=>'component_type','severities'=>'severity','rule_ids'=>'rule_id','models'=>'model',
            'outcomes'=>'outcome','error_categories'=>'error_category','finding_ids'=>'finding_id','changed_fields'=>'changed_fields');
        foreach ($arguments as $key=>$expected) {
            if ($key === 'include_mcp_changes') { continue; }
            if ($key === 'minimum_rating' || $key === 'maximum_rating') {
                if (!isset($data['rating']) || ($key==='minimum_rating' && $data['rating']<$expected) || ($key==='maximum_rating' && $data['rating']>$expected)) { return false; }
            } elseif ($key === 'minimum_total' || $key === 'maximum_total') {
                if (!isset($data['total']) || !preg_match('/^[0-9]+(\\.[0-9]+)?$/',(string)$data['total'])) { return false; }
                $comparison=self::decimal_compare($data['total'],$expected);
                if (($key==='minimum_total' && $comparison<0) || ($key==='maximum_total' && $comparison>0)) { return false; }
            } elseif ($key === 'field_matches') {
                $fields=isset($data['fields']) ? (array)$data['fields'] : array();
                foreach ($expected as $field=>$value) { if (!isset($fields[$field]) || $fields[$field]!==$value) { return false; } }
            } elseif (is_array($expected)) {
                $field=isset($map[$key]) ? $map[$key] : $key;
                if ($key==='product_ids' && isset($data['product_id'])) { $actual=array($data['product_id']); }
                elseif ($key==='term_ids' && isset($data['term_id'])) { $actual=array($data['term_id']); }
                elseif ($key==='taxonomies') { $actual=isset($data['taxonomy']) ? array($data['taxonomy']) : (isset($data['taxonomies']) ? (array)$data['taxonomies'] : array()); }
                else { $actual=isset($data[$field]) ? (array)$data[$field] : array(); }
                if (!array_intersect($expected,array_map('strval',$actual))) { return false; }
            } elseif (!array_key_exists($key,$data) || $data[$key]!==$expected) { return false; }
        }
        return true;
    }

    public static function decimal_compare($a,$b) {
        $a=explode('.',(string)$a,2); $b=explode('.',(string)$b,2);
        $aw=ltrim($a[0],'0'); $bw=ltrim($b[0],'0');
        if (strlen($aw)!==strlen($bw)) { return strlen($aw)>strlen($bw) ? 1 : -1; }
        $whole=strcmp($aw,$bw);
        if ($whole) { return $whole>0 ? 1 : -1; }
        $af=isset($a[1]) ? $a[1] : ''; $bf=isset($b[1]) ? $b[1] : '';
        $scale=max(strlen($af),strlen($bf));
        $fraction=strcmp(str_pad($af,$scale,'0'),str_pad($bf,$scale,'0'));
        return $fraction===0 ? 0 : ($fraction>0 ? 1 : -1);
    }
}
