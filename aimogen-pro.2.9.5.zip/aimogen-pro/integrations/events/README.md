# Aimogen AI Automations

An optional PHP module on Aimogen's existing authenticated MCP endpoint. It adds 126 event definitions without changing the existing tools, rules, or schedules. No extra service or Node installation is required.

For site owners, use the [setup and testing user guide](USER-GUIDE.md). A quick walkthrough with the site's actual server URL is also available in **Aimogen → AI MCP Integration → Create Your MCP Server → Aimogen AI Automations → Setup and testing guide**.

## Enable

1. Install Aimogen Pro and the matching updated Aimogen MCP Server extension.
2. Open **Aimogen → AI MCP Integration → Create Your MCP Server**.
3. Keep the MCP server enabled and select **Enable AI Automations events**. Select the source packs you want, then save.
4. Connect an event-capable ChatGPT client to the existing HTTP endpoint on a publicly reachable HTTPS site. Ask it to watch an event and follow your instructions.

Examples: check SEO after publication; prepare a restocking summary when inventory crosses the low-stock threshold; draft a response to reviews rated 1 or 2; qualify leads using approved form fields.

The site exposes subscriptions and signed events. The connected client creates and renews subscriptions and performs the follow-up action. A delivery receipt only means the receiver acknowledged the event.

## Sources and privacy

- WordPress: post lifecycle, media, taxonomy, comments, user/access changes, updates, Site Health counts, and mail handoff failures.
- WooCommerce: order/refund/item lifecycle, product/variation changes, threshold crossings, reviews/ratings, coupons, and customer changes. CRUD hooks support both WooCommerce order stores.
- Conditional adapters: WooCommerce Subscriptions, Paid Memberships Pro, Yoast SEO/Rank Math metadata, Contact Form 7, Gravity Forms, WPForms, and Fluent Forms.
- Aimogen: WordPress-triggered OmniBlock run start/return/failure, AI Editor apply/undo, provider failover and key-state signals.
- Security: measured failed-login bursts and administrator role changes. Third-party findings require an explicit provider registration and evidence reference; no security scan is performed.

Only installed/selected sources are advertised. Forms contain provider, form and entry identifiers plus status; fields are excluded by default. Approve individual fields in the existing settings page using JSON such as `{"contactform7:123":["company","message"]}`. Provider IDs are `aimogen`, `contactform7`, `gravityforms`, `wpforms`, and `fluentforms`. Aimogen's scalar form input is named `input`. Credential and payment field names are refused.

Payloads use family-specific allowlists. Core user events exclude email/password details; order events exclude billing/payment credentials; email failures include an error category, without mail recipients/content. Removing an approved form field cancels queued deliveries containing that field before transmission. Client instructions should treat post, comment, review, and form text as untrusted input.

MCP-origin changes, including those after nested REST requests inside a tool, are excluded unless a subscription explicitly sets `include_mcp_changes: true`, preventing routine feedback loops. Autosaves/revisions and no-op post saves do not create content-update events. A low-stock event describes crossing from above the current WooCommerce threshold to a positive quantity at or below it. Duplicate source hooks coalesce while distinct recorded transitions retain distinct occurrence IDs. A skipped OmniBlock run does not emit a completion event.

## Protocol and delivery

The optional companion hooks add `server/discover`, `events/list`, `events/subscribe`, and `events/unsubscribe`, with protocol `2026-07-28`. Existing initialization, authentication, tool definitions and transports retain their previous behavior. Remote bearer subscriptions bind to the configured token; OAuth subscriptions bind to a hidden stable grant that survives refresh and stops on revocation. A fresh revocation check and a 38-day revocation marker prevent a concurrent refresh from restoring a revoked grant. Legacy OAuth tokens need reconnecting to create persistent watches.

Callbacks require verified public HTTPS on port 443. DNS is rechecked and the selected validated IP is pinned for each connection; TLS hostname verification remains enabled, proxies and redirects are disabled. A signed verification challenge must succeed before activation. Secrets are encrypted using an installation-derived AES-GCM key, and callback bodies use Standard Webhooks signatures.

Subscriptions default to 24 hours, accept finite lifetimes from 5 minutes to 7 days, and refresh idempotently using the same principal/name/filter/callback identity. A null requested lifetime receives the finite default. Non-null replay cursors are refused. Discovery advertises filters supported by each source; publication snapshots include saved taxonomy/term IDs and deletion events retain required pre-delete facts. Filters combine with AND, lists match any listed value, rating filters are inclusive, monetary ranges require a currency, and form comparisons require explicit approved provider/form scope.

Delivery runs through WordPress cron in batches of 10 with atomic 60-second worker leases. Transient failures retry at most 8 times with bounded exponential backoff; retries preserve event ID and exact body. Permanent failures, HTTP 410 and 413 stop that delivery; 410 also stops the subscription. Recheck permissions, source enablement, credential/grant and expiry before each send. An already in-flight HTTP request cannot be recalled after unsubscribe.

Queue limits are 100 subscriptions per principal and 1,000 pending deliveries per subscription. Overflow pauses that subscription. Pending payloads expire after 24 hours; completed payloads are removed after 24 hours and delivery diagnostics after 7 days. Expired subscriptions lose signing material. Disabling events immediately stops subscriptions and clears retained payloads and signing secrets; a daily cleanup-only cron remains while diagnostics await expiry. Pause/resume/stop controls and recent status appear in the existing settings page. Quiet sites need a system trigger for WordPress cron if prompt delivery matters.

## Extension hooks

A security adapter registers stable provider IDs with `aimogen_mcp_security_event_providers` and emits `aimogen_mcp_security_finding` with `provider`, `finding_id`, `severity` (low/medium/high/critical), and `evidence_reference`. Payloads are still allowlisted by the engine.

## Validation

Run `php integrations/events/tests/unit.php` for standalone filter/signature/encryption/address contracts. `php integrations/events/tests/wordpress.php` is a CLI-only local integration scenario that creates isolated fixtures, compares the original MCP baseline, substitutes callback delivery, and restores settings and its fixtures. Run it only on a disposable local installation with empty event tables: its preflight refuses existing subscriptions/deliveries because the scenario exercises disablement and retention. The baseline path in this local test points to the preserved pre-change backup; configure that path for another checkout.

Validation passed 18 standalone checks and 77 WordPress integration checks, including exact enabled/disabled comparison with the original 74 MCP tool definitions. The integration scenario checks real local WordPress/WooCommerce hooks, authenticated RPC, permissions, metadata timing, secret rotation, retry/lease/unsubscribe behavior and OAuth refresh/revocation races. A settings-only browser preview was checked at desktop and 375-pixel widths; the authenticated full admin page was not exercised. Optional plugins that are not active have discovery checks and documented adapters, not live-provider integration evidence. Callback fixtures do not validate public DNS, remote TLS, installed ChatGPT subscriptions or its downstream actions. A public HTTPS installation and a real event-capable client are required for that final end-to-end check.

Protocol reference: [OpenAI MCP Events](https://developers.openai.com/plugins/build/mcp-events).
