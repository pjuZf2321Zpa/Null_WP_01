<?php
defined('ABSPATH') || exit;

/** Narrow adapters: optional plugins are never loaded or called when absent. */
function aimogen_mcp_event_form($provider,$formId,$submissionId,$status,$values=array(),$name='form.submitted') {
    $settings=Aimogen_MCP_Events::settings();
    $approved=isset($settings['form_fields'][$provider . ':' . $formId]) ? (array)$settings['form_fields'][$provider . ':' . $formId] : array();
    $fields=array();
    // Read only explicitly approved scalar fields; never serialize the complete submission.
    foreach ($approved as $field) {
        if (isset($values[$field]) && is_scalar($values[$field])) { $fields[$field]=(string)$values[$field]; }
    }
    $data=array('provider'=>$provider,'form_id'=>(string)$formId,'entry_id'=>(string)$submissionId,'status'=>$status,'fields'=>$fields);
    Aimogen_MCP_Event_Sources::queue($name,$submissionId ?: $formId,$data,array(),$submissionId ?: wp_generate_uuid4());
}

function aimogen_mcp_event_extra_sources($packs) {
    if (in_array('forms',$packs,true)) {
        add_action('aimogen_mcp_form_submitted',function($id,$values) {
            aimogen_mcp_event_form('aimogen',$id,wp_generate_uuid4(),'accepted',is_array($values) ? $values : array('input'=>$values));
        },20,2);
        if (class_exists('GFForms')) {
            add_action('gform_after_submission',function($entry,$form) {
                if (!is_array($entry) || !is_array($form) || (isset($entry['status']) && $entry['status']!=='active')) { return; }
                aimogen_mcp_event_form('gravityforms',$form['id'],$entry['id'],'accepted',$entry);
            },20,2);
        }
        if (function_exists('wpforms')) {
            add_action('wpforms_process_complete',function($fields,$entry,$form,$entryId) {
                $approved=Aimogen_MCP_Events::settings(); $id=isset($form['id']) ? $form['id'] : '';
                $values=array();
                foreach (isset($approved['form_fields']['wpforms:' . $id]) ? $approved['form_fields']['wpforms:' . $id] : array() as $field) {
                    if (isset($fields[$field]['value']) && is_scalar($fields[$field]['value'])) { $values[$field]=$fields[$field]['value']; }
                }
                aimogen_mcp_event_form('wpforms',$id,$entryId ?: wp_generate_uuid4(),'accepted',$values);
            },20,4);
        }
        if (defined('FLUENTFORM_VERSION') || function_exists('wpFluentForm')) {
            add_action('fluentform/submission_inserted',function($id,$values,$form) {
                $formId=is_object($form) && isset($form->id) ? $form->id : (is_array($form) && isset($form['id']) ? $form['id'] : '');
                if ($formId) { aimogen_mcp_event_form('fluentforms',$formId,$id,'accepted',(array)$values); }
            },20,3);
        }
    }
    if ((in_array('forms',$packs,true) || in_array('cf7',$packs,true)) && class_exists('WPCF7_ContactForm')) {
        add_action('wpcf7_submit',function($form,$result) {
            $status=isset($result['status']) ? $result['status'] : '';
            $accepted=in_array($status,array('mail_sent','mail_failed'),true);
            if (!$accepted && !in_array($status,array('validation_failed','spam','acceptance_missing','aborted'),true)) { return; }
            $submission=WPCF7_Submission::get_instance();
            $values=$accepted && $submission ? $submission->get_posted_data() : array();
            aimogen_mcp_event_form('contactform7',$form->id(),wp_generate_uuid4(),$status,(array)$values,$accepted ? 'form.submitted' : 'form.submission_rejected');
        },20,2);
        add_action('wpcf7_mail_failed',function($form) {
            // Metadata only: notification failure does not authorize sending submission fields.
            $data=array('provider'=>'contactform7','form_id'=>(string)$form->id(),'status'=>'mail_failed');
            Aimogen_MCP_Event_Sources::queue('form.notification_failed',$form->id(),$data,array(),wp_generate_uuid4());
        },20);
    }
    if (in_array('membership',$packs,true) && function_exists('pmpro_getMembershipLevelForUser')) {
        $snapshot=function($userId,$levelId=0,$order=null) {
            $level=$levelId ?: pmpro_getMembershipLevelForUser($userId);
            $data=array('user_id'=>(string)$userId,'level_id'=>(string)(is_object($level) ? $level->id : $level),'status'=>'changed');
            if (is_object($order)) {
                foreach (array('id'=>'order_id','status'=>'status') as $property=>$key) { if (isset($order->$property) && is_scalar($order->$property)) { $data[$key]=(string)$order->$property; } }
            }
            return $data;
        };
        add_action('pmpro_after_change_membership_level',function($levelId,$userId) use ($snapshot) {
            Aimogen_MCP_Event_Sources::queue('membership.level_changed',$userId,$snapshot($userId,$levelId),array(),wp_generate_uuid4());
        },20,2);
        add_action('pmpro_after_checkout',function($userId,$order) use ($snapshot) {
            Aimogen_MCP_Event_Sources::queue('membership.checkout_completed',$userId,$snapshot($userId,isset($order->membership_id) ? $order->membership_id : 0,$order));
        },20,2);
        add_action('pmpro_membership_post_membership_expiry',function($userId,$levelId) use ($snapshot) {
            $data=$snapshot($userId,$levelId); $data['status']='expired'; Aimogen_MCP_Event_Sources::queue('membership.expired',$userId,$data);
        },20,2);
        foreach (array('pmpro_subscription_payment_completed'=>'membership.payment_completed','pmpro_subscription_payment_failed'=>'membership.payment_failed') as $hook=>$name) {
            add_action($hook,function($order) use ($snapshot,$name) {
                if (!is_object($order) || empty($order->user_id)) { return; }
                $data=$snapshot($order->user_id,isset($order->membership_id) ? $order->membership_id : 0,$order);
                $data['status']=$name==='membership.payment_completed' ? 'completed' : 'failed';
                Aimogen_MCP_Event_Sources::queue($name,isset($order->id) ? $order->id : $order->user_id,$data);
            },20);
        }
        add_action('pmpro_after_update_billing',function($userId,$order=null) use ($snapshot) {
            Aimogen_MCP_Event_Sources::queue('membership.billing_updated',$userId,$snapshot($userId,0,$order),array(),wp_generate_uuid4());
        },20,2);
    }
    if (in_array('subscriptions',$packs,true) && function_exists('wcs_get_subscription')) {
        $emit=function($name,$value,$extra=array()) {
            $subscription=is_object($value) ? $value : wcs_get_subscription($value);
            if (!$subscription || !is_a($subscription,'WC_Subscription')) { return; }
            $data=Aimogen_MCP_Event_Sources::order_data($subscription);
            $data['subscription_id']=(string)$subscription->get_id(); $data['order_id']=(string)$subscription->get_parent_id();
            Aimogen_MCP_Event_Sources::queue('woocommerce.subscription.' . $name,$subscription->get_id(),array_merge($data,$extra));
        };
        add_action('woocommerce_checkout_subscription_created',function($subscription) use ($emit) { $emit('created',$subscription); },20);
        add_action('woocommerce_subscription_status_updated',function($subscription,$new,$old) use ($emit) {
            if ($new===$old) { return; }
            $extra=array('status'=>$new,'previous_status'=>$old); $emit('status_changed',$subscription,$extra);
            $map=array('active'=>'activated','on-hold'=>'on_hold','pending-cancel'=>'cancellation_requested','cancelled'=>'cancelled','expired'=>'expired');
            if (isset($map[$new])) { $emit($map[$new],$subscription,$extra); }
        },20,3);
        foreach (array('woocommerce_scheduled_subscription_payment'=>'renewal_due','woocommerce_subscription_renewal_payment_complete'=>'renewal_paid',
            'woocommerce_subscription_renewal_payment_failed'=>'renewal_failed','woocommerce_subscription_payment_complete'=>'payment_completed',
            'woocommerce_subscription_payment_failed'=>'payment_failed','woocommerce_scheduled_subscription_trial_end'=>'trial_ended') as $hook=>$name) {
            add_action($hook,function($subscription) use ($emit,$name) { $emit($name,$subscription); },20);
        }
        add_action('woocommerce_subscriptions_switch_completed',function($order) use ($emit) {
            if (!function_exists('wcs_get_subscriptions_for_order')) { return; }
            foreach (wcs_get_subscriptions_for_order($order,array('order_type'=>'any')) as $subscription) { $emit('plan_switched',$subscription); }
        },20);
    }
    if (in_array('security',$packs,true)) {
        add_action('aimogen_mcp_security_finding',function($finding) {
            if (!is_array($finding) || empty($finding['provider']) || empty($finding['finding_id']) || empty($finding['evidence_reference']) ||
                !isset($finding['severity']) || !in_array($finding['severity'],array('low','medium','high','critical'),true)) { return; }
            $providers=(array)apply_filters('aimogen_mcp_security_event_providers',array());
            if (!in_array($finding['provider'],$providers,true)) { return; }
            Aimogen_MCP_Event_Sources::queue('security.issue.detected',$finding['finding_id'],$finding);
        },20);
    }
}
