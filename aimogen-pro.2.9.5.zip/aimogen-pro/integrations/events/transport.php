<?php
defined('ABSPATH') || exit;

/** Pinned HTTPS callbacks and Standard Webhooks; never changes the global HTTP client. */
class Aimogen_MCP_Event_Transport {
    public static function secret_key($secret) {
        if (!is_string($secret) || !preg_match('~^whsec_[A-Za-z0-9+/]+={0,2}$~D',$secret)) {
            return new WP_Error('invalid_secret','A valid whsec_ signing secret is required.');
        }
        $key=base64_decode(substr($secret,6),true);
        if ($key===false || strlen($key)<24 || strlen($key)>64) {
            return new WP_Error('invalid_secret','Signing keys must contain 24 to 64 bytes.');
        }
        return $key;
    }

    public static function sign($id,$timestamp,$body,$secret) {
        $key=self::secret_key($secret);
        if (is_wp_error($key)) { return $key; }
        return 'v1,' . base64_encode(hash_hmac('sha256',$id . '.' . (string)$timestamp . '.' . $body,$key,true));
    }

    public static function encrypt($secret) {
        if (!function_exists('openssl_encrypt')) { return new WP_Error('encryption_unavailable','OpenSSL is required for event subscriptions.'); }
        try { $iv=random_bytes(12); } catch (Throwable $error) { return new WP_Error('encryption_unavailable','Secure randomness is unavailable.'); }
        $tag='';
        $encrypted=openssl_encrypt($secret,'aes-256-gcm',hash('sha256',wp_salt('auth') . ':aimogen-events',true),OPENSSL_RAW_DATA,$iv,$tag);
        if ($encrypted===false || strlen($tag)!==16) { return new WP_Error('encryption_unavailable','Could not encrypt the signing secret.'); }
        return 'v1:' . base64_encode($iv . $tag . $encrypted);
    }

    public static function decrypt($stored) {
        if (!function_exists('openssl_decrypt') || !is_string($stored) || strpos($stored,'v1:')!==0) { return new WP_Error('invalid_secret','The stored signing secret is unavailable. Reconnect monitoring.'); }
        $bytes=base64_decode(substr($stored,3),true);
        if ($bytes===false || strlen($bytes)<29) { return new WP_Error('invalid_secret','Invalid encrypted signing secret.'); }
        $secret=openssl_decrypt(substr($bytes,28),'aes-256-gcm',hash('sha256',wp_salt('auth') . ':aimogen-events',true),OPENSSL_RAW_DATA,substr($bytes,0,12),substr($bytes,12,16));
        if ($secret===false || is_wp_error(self::secret_key($secret))) { return new WP_Error('invalid_secret','The signing secret cannot be read. Reconnect monitoring.'); }
        return $secret;
    }

    public static function in_network($ip,$network,$bits) {
        $address=inet_pton($ip); $base=inet_pton($network);
        if ($address===false || $base===false || strlen($address)!==strlen($base)) { return false; }
        $bytes=(int)floor($bits/8); $remainder=$bits%8;
        if (substr($address,0,$bytes)!==substr($base,0,$bytes)) { return false; }
        return !$remainder || ((ord($address[$bytes]) & (255 << (8-$remainder))) === (ord($base[$bytes]) & (255 << (8-$remainder))));
    }

    public static function is_public_ip($ip) {
        if (!is_string($ip) || !filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) { return false; }
        $blocked=array('0.0.0.0/8','10.0.0.0/8','100.64.0.0/10','127.0.0.0/8','169.254.0.0/16','172.16.0.0/12',
            '192.0.0.0/24','192.0.2.0/24','192.88.99.0/24','192.168.0.0/16','198.18.0.0/15','198.51.100.0/24','203.0.113.0/24','224.0.0.0/4','240.0.0.0/4',
            '::/96','::ffff:0:0/96','64:ff9b::/96','64:ff9b:1::/48','100::/64','2001::/32','2001:2::/48','2001:10::/28','2001:20::/28','2001:db8::/32','2002::/16','fc00::/7','fe80::/10','fec0::/10','ff00::/8');
        foreach ($blocked as $cidr) { list($base,$bits)=explode('/',$cidr); if (self::in_network($ip,$base,(int)$bits)) { return false; } }
        // Only global unicast IPv6 is usable; reject transition and reserved ranges.
        return strpos($ip,':')===false || self::in_network($ip,'2000::',3);
    }

    public static function callback($url) {
        if (!is_string($url) || strlen($url)>4096 || preg_match('/[\\x00-\\x20]/',$url) || !filter_var($url,FILTER_VALIDATE_URL)) { return new WP_Error('invalid_callback','A valid HTTPS callback URL is required.'); }
        $parts=parse_url($url);
        if (!$parts || strtolower($parts['scheme'])!=='https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment']) || (isset($parts['port']) && $parts['port']!==443)) {
            return new WP_Error('invalid_callback','Callbacks require HTTPS on port 443 without URL credentials or fragments.');
        }
        $host=strtolower(rtrim(trim($parts['host'],'[]'),'.'));
        if (filter_var($host,FILTER_VALIDATE_IP)) {
            if (!self::is_public_ip($host)) { return new WP_Error('invalid_callback','Callbacks must use public destinations.'); }
        } elseif (!preg_match('/^[a-z0-9.-]+$/',$host) || strpos($host,'.')===false || preg_match('/(^|\\.)(localhost|local|internal|test|invalid)$/',$host)) {
            return new WP_Error('invalid_callback','Callbacks must use public hostnames.');
        }
        $authority=strpos($host,':')===false ? $host : '[' . $host . ']';
        return 'https://' . $authority . (isset($parts['path']) && $parts['path']!=='' ? $parts['path'] : '/') . (isset($parts['query']) ? '?' . $parts['query'] : '');
    }

    private static function addresses($host,$depth=0) {
        if (filter_var($host,FILTER_VALIDATE_IP)) { return array($host); }
        if ($depth>5) { return new WP_Error('dns_failed','Callback DNS could not be resolved safely.'); }
        $records=@dns_get_record($host,DNS_A | DNS_AAAA | DNS_CNAME);
        if (!is_array($records) || !$records) { return new WP_Error('dns_failed','Callback DNS lookup failed.'); }
        $addresses=array();
        foreach ($records as $record) {
            if (isset($record['ip'])) { $addresses[]=$record['ip']; }
            if (isset($record['ipv6'])) { $addresses[]=$record['ipv6']; }
            if (isset($record['target'])) {
                $alias=self::addresses($record['target'],$depth+1);
                if (is_wp_error($alias)) { return $alias; }
                $addresses=array_merge($addresses,$alias);
            }
        }
        $addresses=array_values(array_unique($addresses));
        if (!$addresses) { return new WP_Error('dns_failed','Callback has no usable address.'); }
        foreach ($addresses as $ip) { if (!self::is_public_ip($ip)) { return new WP_Error('unsafe_destination','Callback resolved to a nonpublic destination.'); } }
        return $addresses;
    }

    public static function send($url,$headers,$body) {
        $url=self::callback($url);
        if (is_wp_error($url)) { return $url; }
        if (!is_string($body) || strlen($body)>262144) { return new WP_Error('payload_too_large','The event payload is too large.'); }
        // Explicit CLI-only fixture injection. This branch cannot run in a web request.
        if (PHP_SAPI==='cli' && defined('AIMOGEN_MCP_EVENTS_TESTING') && AIMOGEN_MCP_EVENTS_TESTING) {
            $fixture=apply_filters('aimogen_mcp_events_test_transport',null,$url,$headers,$body);
            return is_array($fixture) || is_wp_error($fixture) ? $fixture : new WP_Error('fixture_missing','No callback fixture was installed.');
        }
        if (!function_exists('curl_init') || !defined('CURLOPT_RESOLVE')) { return new WP_Error('transport_unavailable','cURL with address pinning is required for event callbacks.'); }
        $host=trim(parse_url($url,PHP_URL_HOST),'[]');
        $addresses=self::addresses($host);
        if (is_wp_error($addresses)) { return $addresses; }
        $ip=$addresses[0];
        $responseBody=''; $retryAfter=0;
        $curl=curl_init($url);
        $options=array(
            CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>$body, CURLOPT_FOLLOWLOCATION=>false, CURLOPT_MAXREDIRS=>0,
            CURLOPT_CONNECTTIMEOUT=>5, CURLOPT_TIMEOUT=>10, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_PROXY=>'', CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS, CURLOPT_USERAGENT=>'Aimogen-MCP-Events/1.0',
            CURLOPT_HTTPHEADER=>array_map(function($key,$value) { return $key . ': ' . $value; },array_keys($headers),array_values($headers)),
            CURLOPT_WRITEFUNCTION=>function($handle,$chunk) use (&$responseBody) {
                if (strlen($responseBody)+strlen($chunk)>16384) { return 0; }
                $responseBody.=$chunk; return strlen($chunk);
            },
            CURLOPT_HEADERFUNCTION=>function($handle,$line) use (&$retryAfter) {
                if (stripos($line,'Retry-After:')===0) {
                    $value=trim(substr($line,12));
                    $retryAfter=ctype_digit($value) ? min(86400,(int)$value) : max(0,min(86400,(int)strtotime($value)-time()));
                }
                return strlen($line);
            },
        );
        if (!filter_var($host,FILTER_VALIDATE_IP)) {
            $options[CURLOPT_RESOLVE]=array($host . ':443:' . (strpos($ip,':')!==false ? '[' . $ip . ']' : $ip));
        }
        $certificates=ABSPATH . WPINC . '/certificates/ca-bundle.crt';
        if (is_file($certificates)) { $options[CURLOPT_CAINFO]=$certificates; }
        curl_setopt_array($curl,$options);
        $ok=curl_exec($curl);
        $status=(int)curl_getinfo($curl,CURLINFO_HTTP_CODE);
        $errno=curl_errno($curl);
        curl_close($curl);
        if ($ok===false) { return new WP_Error($errno===28 ? 'timeout' : 'connection_failed','The HTTPS callback request did not complete.'); }
        return array('status'=>$status,'body'=>$responseBody,'retry_after'=>$retryAfter);
    }
}

