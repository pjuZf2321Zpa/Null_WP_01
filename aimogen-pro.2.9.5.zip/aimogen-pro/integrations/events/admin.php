<?php
defined('ABSPATH') || exit;

class Aimogen_MCP_Event_Admin {
    public static function packs() {
        return array('core'=>'WordPress and Aimogen','woocommerce'=>'WooCommerce','subscriptions'=>'WooCommerce Subscriptions',
            'forms'=>'Forms: Aimogen, Contact Form 7, Gravity Forms, WPForms, Fluent Forms','cf7'=>'Contact Form 7 failures',
            'membership'=>'Paid Memberships Pro','seo'=>'Yoast SEO and Rank Math metadata','security'=>'Registered security findings');
    }

    public static function sanitize($input) {
        if (!is_array($input)) { return Aimogen_MCP_Events::settings(); }
        $result=array('enabled'=>!empty($input['enabled']),'packs'=>array_values(array_intersect(array_keys(self::packs()),isset($input['packs']) ? (array)$input['packs'] : array())),'form_fields'=>array());
        $fields=isset($input['form_fields_json']) && is_string($input['form_fields_json']) ? json_decode($input['form_fields_json'],true) : (isset($input['form_fields']) ? $input['form_fields'] : array());
        if ($fields===null || !is_array($fields) || count($fields)>100) {
            add_settings_error('aimogen_mcp_events','form_fields','Form field allowlist must be a JSON object with at most 100 forms.');
            $result['form_fields']=Aimogen_MCP_Events::settings()['form_fields'];
            return $result;
        }
        foreach ($fields as $form=>$names) {
            if (!preg_match('/^(aimogen|contactform7|gravityforms|wpforms|fluentforms):[A-Za-z0-9_.-]{1,100}$/',(string)$form) || !is_array($names) || count($names)>20) {
                add_settings_error('aimogen_mcp_events','form_fields','Use provider:form_id keys and lists of up to 20 approved field names.');
                $result['form_fields']=Aimogen_MCP_Events::settings()['form_fields']; return $result;
            }
            foreach ($names as $name) {
                if (!is_string($name) || !preg_match('/^[A-Za-z0-9_.-]{1,64}$/',$name) ||
                    preg_match('/password|passwd|secret|token|api.?key|credit.?card|card.?number|cvv|cvc/i',$name)) {
                    add_settings_error('aimogen_mcp_events','form_fields','Use simple field names; credentials and payment fields cannot be approved.');
                    $result['form_fields']=Aimogen_MCP_Events::settings()['form_fields']; return $result;
                }
            }
            $result['form_fields'][$form]=array_values(array_unique($names));
        }
        return $result;
    }

    public static function register() {
        register_setting('aiomatic_mcp','aimogen_mcp_events',array('type'=>'array','sanitize_callback'=>array(__CLASS__,'sanitize')));
    }

    public static function render() {
        if (!current_user_can('manage_options')) { return; }
        $settings=Aimogen_MCP_Events::settings();
        $mcp=get_option('aiomatic_mcp_settings',array());
        $server_enabled=isset($mcp['enable_sse']) && $mcp['enable_sse']==='on';
        $events_enabled=!empty($settings['enabled']);
        echo '<h3>' . esc_html__('Aimogen AI Automations','aiomatic-automatic-ai-content-writer') . '</h3>';
        echo '<p>' . esc_html__('Let a connected ChatGPT client watch site events and follow your instructions. Events use the existing authenticated MCP endpoint; the client creates and renews its subscriptions.','aiomatic-automatic-ai-content-writer') . '</p>';
        self::help();
        echo '<input type="hidden" id="aimogen-mcp-events-enabled-fallback" name="aimogen_mcp_events[enabled]" value="' . (!$server_enabled && $events_enabled ? '1' : '0') . '">';
        echo '<p><label for="aimogen-mcp-events-enabled"><input type="checkbox" id="aimogen-mcp-events-enabled" name="aimogen_mcp_events[enabled]" value="1" aria-describedby="aimogen-mcp-events-dependency" ' . checked($events_enabled,true,false) . ' ' . disabled(!$server_enabled,true,false) . '> ' . esc_html__('Enable AI Automations events','aiomatic-automatic-ai-content-writer') . '</label></p>';
        echo '<p class="description" id="aimogen-mcp-events-dependency">' . esc_html__('Requires','aiomatic-automatic-ai-content-writer') . ' <a href="#aiomatic-mcp-server-enabled">' . esc_html__('Enable MCP server','aiomatic-automatic-ai-content-writer') . '</a>. ' . esc_html__('Turn on the MCP server above to select this option, then save your settings.','aiomatic-automatic-ai-content-writer') . '</p>';
        echo '<div id="aimogen-mcp-events-server-warning" class="notice notice-warning inline" role="status"' . ($server_enabled || !$events_enabled ? ' hidden' : '') . '><p>' . esc_html__('AI Automations events are selected, but cannot run while the MCP server is off. Enable MCP server above and save your settings to activate them.','aiomatic-automatic-ai-content-writer') . '</p></div>';
        if (!class_exists('Aiomatic_MCP_Server') || !method_exists('Aiomatic_MCP_Server','get_event_context')) {
            echo '<p class="description">' . esc_html__('Install or update the Aimogen MCP Server extension to use events.','aiomatic-automatic-ai-content-writer') . '</p>';
        } elseif (!function_exists('curl_init') || !function_exists('openssl_encrypt')) {
            echo '<p class="description">' . esc_html__('PHP cURL and OpenSSL are required for signed webhook delivery.','aiomatic-automatic-ai-content-writer') . '</p>';
        }
        if (strpos(home_url(),'https://')!==0) {
            echo '<p class="description">' . esc_html__('ChatGPT needs a publicly reachable HTTPS site to connect. Local testing can check capture and delivery with fixtures.','aiomatic-automatic-ai-content-writer') . '</p>';
        }
        echo '<p><strong>' . esc_html__('Event sources','aiomatic-automatic-ai-content-writer') . '</strong></p><input type="hidden" name="aimogen_mcp_events[packs][]" value="">';
        foreach (self::packs() as $pack=>$label) {
            echo '<p><label><input type="checkbox" name="aimogen_mcp_events[packs][]" value="' . esc_attr($pack) . '" ' . checked(in_array($pack,(array)$settings['packs'],true),true,false) . '> ' . esc_html($label) . '</label></p>';
        }
        echo '<p><label for="aimogen-event-fields"><strong>' . esc_html__('Approved form fields (optional)','aiomatic-automatic-ai-content-writer') . '</strong></label></p>';
        echo '<textarea id="aimogen-event-fields" name="aimogen_mcp_events[form_fields_json]" rows="4" class="large-text code">' . esc_textarea(wp_json_encode((object)$settings['form_fields'],JSON_PRETTY_PRINT)) . '</textarea>';
        echo '<p class="description">' . esc_html__('Form events contain metadata only by default. Approve fields individually, for example {"contactform7:123":["company","message"]}. Avoid personal information unless needed for the automation.','aiomatic-automatic-ai-content-writer') . '</p>';
        echo '<details><summary>' . esc_html__('Event catalog and examples','aiomatic-automatic-ai-content-writer') . '</summary>';
        echo '<p>' . esc_html__('Try: “Whenever a post is published, check its SEO and notify me about serious problems.” “When a product becomes low stock, prepare a restocking summary.” “For product reviews rated 1 or 2, draft a response.”','aiomatic-automatic-ai-content-writer') . '</p>';
        echo '<p class="description">' . esc_html__('MCP-triggered changes are excluded by default to prevent feedback loops. Subscriptions can explicitly opt in with include_mcp_changes.','aiomatic-automatic-ai-content-writer') . '</p>';
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Event','aiomatic-automatic-ai-content-writer') . '</th><th>' . esc_html__('Use','aiomatic-automatic-ai-content-writer') . '</th><th>' . esc_html__('Source','aiomatic-automatic-ai-content-writer') . '</th></tr></thead><tbody>';
        foreach (Aimogen_MCP_Event_Catalog::all() as $definition) {
            echo '<tr><td style="overflow-wrap:anywhere"><code>' . esc_html($definition['name']) . '</code></td><td>' . esc_html($definition['description']) . '</td><td>' . esc_html(Aimogen_MCP_Events::available($definition) ? __('Available when enabled','aiomatic-automatic-ai-content-writer') : __('Source disabled or plugin unavailable','aiomatic-automatic-ai-content-writer')) . '</td></tr>';
        }
        echo '</tbody></table></details>';
    }

    public static function help() {
        echo '<details id="aimogen-automations-help"><summary><strong>' . esc_html__('Setup and testing guide','aiomatic-automatic-ai-content-writer') . '</strong></summary>';
        echo '<p>' . esc_html__('Start on a public HTTPS staging site with a simple post notification. ChatGPT event subscriptions require a Work chat on the web, or Work with Cloud selected in the desktop app. Your workspace must allow plugins and event-triggered tasks.','aiomatic-automatic-ai-content-writer') . '</p>';
        echo '<ol style="padding-left:1.5em">';
        foreach (array(
            __('Update both Aimogen Pro and the Aimogen MCP Server extension. In Create Your MCP Server, turn on Enable MCP server, keep Transport on Both or Streamable HTTP, and enable Sign-in (OAuth). The MCP server must be on before you can select Enable AI Automations events. Select WordPress and Aimogen below, then click Save Settings.','aiomatic-automatic-ai-content-writer'),
            __('Add the server URL below as a personal ChatGPT plugin using OAuth, and sign in with a WordPress administrator account. Install/select that plugin in your Work chat. Rescan an existing plugin to discover its new events; reconnect an old OAuth connection if requested.','aiomatic-automatic-ai-content-writer'),
            __('Send the test prompt below. Return here with the WordPress account that approved the connection and check for an active post.published row under AI Automations subscriptions, below Save Settings. Wait for that row before publishing.','aiomatic-automatic-ai-content-writer'),
            __('In WordPress, create a draft called Aimogen automation test, then publish it publicly. Delivery uses WordPress cron; allow a few minutes, visit a normal site page, and refresh this settings page.','aiomatic-automatic-ai-content-writer'),
            __('Check Recent event deliveries for post.published: delivered, then check the subscribed ChatGPT chat for the title and link. Ask ChatGPT to stop monitoring and publish a second test post to confirm the watch stopped.','aiomatic-automatic-ai-content-writer'),
        ) as $step) { echo '<li><p>' . esc_html($step) . '</p></li>'; }
        echo '</ol>';
        echo '<p><strong>' . esc_html__('Server URL for ChatGPT','aiomatic-automatic-ai-content-writer') . '</strong><br><code style="overflow-wrap:anywhere">' . esc_html(rest_url('aiomatic-mcp/v1/http')) . '</code></p>';
        echo '<p><strong>' . esc_html__('First test prompt','aiomatic-automatic-ai-content-writer') . '</strong></p>';
        echo '<blockquote><p>' . esc_html__('Use my Aimogen site to subscribe to post.published. Whenever a new post is published, reply in this chat with its title and link. Do not edit the site.','aiomatic-automatic-ai-content-writer') . '</p></blockquote>';
        echo '<p class="description">' . esc_html__('Enabling the checkbox makes events available; it does not create a watch. A delivered status confirms receipt, while ChatGPT performs the requested action separately. Only events occurring after an active subscription are captured.','aiomatic-automatic-ai-content-writer') . '</p>';
        echo '<p><strong>' . esc_html__('If the test does not work','aiomatic-automatic-ai-content-writer') . '</strong></p><ul style="list-style:disc;padding-left:1.5em">';
        foreach (array(
            __('No active subscription: check the ChatGPT Work/Cloud mode, selected plugin, OAuth connection and event rescan. A working tools connection alone does not confirm event support.','aiomatic-automatic-ai-content-writer'),
            __('No delivery row: publish a new public post after the watch is active, check its filters and source selection, and make the change in WordPress. Changes made through MCP tools are excluded by default.','aiomatic-automatic-ai-content-writer'),
            __('Pending delivery: WordPress cron must run, and your host must permit outbound HTTPS with PHP cURL and OpenSSL. Ask your host to check cron if it remains pending.','aiomatic-automatic-ai-content-writer'),
            __('Failed or cancelled delivery: use the status/error shown below. Reconnect after revoked access; recheck approved form fields and source settings. Delivered without a reply means the ChatGPT task still needs checking.','aiomatic-automatic-ai-content-writer'),
            __('On localhost: settings and the catalog can be inspected here, but ChatGPT cannot reach this address. Use a public HTTPS staging site for the full test; local developer checks are documented in the technical README.','aiomatic-automatic-ai-content-writer'),
        ) as $tip) { echo '<li>' . esc_html($tip) . '</li>'; }
        echo '</ul><p>';
        echo '<a href="' . esc_url(plugin_dir_url(__FILE__) . 'USER-GUIDE.md') . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Full user guide, example automations and troubleshooting','aiomatic-automatic-ai-content-writer') . '</a>';
        echo ' &middot; <a href="' . esc_url('https://developers.openai.com/plugins/quickstart') . '" target="_blank" rel="noopener noreferrer">' . esc_html__('ChatGPT plugin connection guide','aiomatic-automatic-ai-content-writer') . '</a>';
        echo ' &middot; <a href="' . esc_url('https://developers.openai.com/plugins/build/mcp-events') . '" target="_blank" rel="noopener noreferrer">' . esc_html__('OpenAI event requirements','aiomatic-automatic-ai-content-writer') . '</a>';
        echo ' &middot; <a href="' . esc_url(plugin_dir_url(__FILE__) . 'README.md') . '" target="_blank" rel="noopener noreferrer">' . esc_html__('Technical README and local checks','aiomatic-automatic-ai-content-writer') . '</a>';
        echo '</p></details>';
    }

    public static function history() {
        if (!current_user_can('manage_options') || get_option('aimogen_mcp_events_db')!=='1') { return; }
        global $wpdb; list($subscriptions,$deliveries)=Aimogen_MCP_Events::tables();
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,name,status,expires FROM $subscriptions WHERE user_id=%d ORDER BY updated DESC LIMIT 100",get_current_user_id()),ARRAY_A);
        echo '<h3>' . esc_html__('AI Automations subscriptions','aiomatic-automatic-ai-content-writer') . '</h3>';
        echo '<p>' . esc_html__('A subscription pauses when its queue reaches 1,000 pending deliveries. Pending payloads expire after 24 hours. Delivery means the receiver acknowledged the event; the connected client handles the follow-up action.','aiomatic-automatic-ai-content-writer') . '</p>';
        if (!$rows) { echo '<p>' . esc_html__('No subscriptions for your account yet.','aiomatic-automatic-ai-content-writer') . '</p>'; return; }
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Event','aiomatic-automatic-ai-content-writer') . '</th><th>' . esc_html__('Status','aiomatic-automatic-ai-content-writer') . '</th><th>' . esc_html__('Controls','aiomatic-automatic-ai-content-writer') . '</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $status=(int)$row['expires']<time() ? 'expired' : $row['status'];
            echo '<tr><td style="overflow-wrap:anywhere"><code>' . esc_html($row['name']) . '</code></td><td>' . esc_html($status) . '</td><td>';
            foreach (array('pause','resume','stop') as $op) {
                $url=wp_nonce_url(add_query_arg(array('action'=>'aimogen_mcp_event_control','op'=>$op,'id'=>$row['id']),admin_url('admin-post.php')),'aimogen_event_' . $op . '_' . $row['id']);
                echo '<a class="button button-small" href="' . esc_url($url) . '">' . esc_html(ucfirst($op)) . '</a> ';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
        $recent=$wpdb->get_results($wpdb->prepare("SELECT d.name,d.status,d.error,d.attempts FROM $deliveries d JOIN $subscriptions s ON s.id=d.subscription_id WHERE s.user_id=%d ORDER BY d.id DESC LIMIT 20",get_current_user_id()),ARRAY_A);
        if ($recent) {
            echo '<h4>' . esc_html__('Recent event deliveries','aiomatic-automatic-ai-content-writer') . '</h4><ul>';
            foreach ($recent as $row) { echo '<li><code>' . esc_html($row['name']) . '</code>: ' . esc_html($row['status'] . ' (' . $row['attempts'] . ' attempts)' . ($row['error'] ? ' — ' . $row['error'] : '')) . '</li>'; }
            echo '</ul>';
        }
    }

    public static function control() {
        if (!current_user_can('manage_options')) { wp_die('Event access denied.',403); }
        $op=isset($_GET['op']) ? sanitize_key(wp_unslash($_GET['op'])) : '';
        $id=isset($_GET['id']) ? sanitize_key(wp_unslash($_GET['id'])) : '';
        if (!in_array($op,array('pause','resume','stop'),true) || !preg_match('/^[a-f0-9]{64}$/',$id)) { wp_die('Invalid subscription.',400); }
        check_admin_referer('aimogen_event_' . $op . '_' . $id);
        if (get_option('aimogen_mcp_events_db')==='1') {
            global $wpdb; list($subscriptions,$deliveries)=Aimogen_MCP_Events::tables();
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $subscriptions WHERE id=%s AND user_id=%d",$id,get_current_user_id()),ARRAY_A);
            if ($row) {
                if ($op==='stop') {
                    $wpdb->delete($subscriptions,array('id'=>$id,'user_id'=>get_current_user_id()));
                    $wpdb->query($wpdb->prepare("UPDATE $deliveries SET status='cancelled',body='',guard='',lease='',lease_until=0 WHERE subscription_id=%s AND status IN ('pending','sending')",$id));
                } else {
                    // Resume needs a still-valid, verified subscription; renewal remains the client's job.
                    if ($op!=='resume' || ((int)$row['expires']>time() && (int)$row['verified']>0 && in_array($row['status'],array('active','paused'),true))) {
                        $wpdb->update($subscriptions,array('status'=>$op==='pause' ? 'paused' : 'active','version'=>(int)$row['version']+1,'updated'=>time()),array('id'=>$id,'version'=>$row['version']));
                    }
                }
            }
        }
        wp_safe_redirect(admin_url('admin.php?page=aiomatic_mcp_panel')); exit;
    }
}
add_action('admin_init',array('Aimogen_MCP_Event_Admin','register'));
add_action('aiomatic_mcp_settings_extra',array('Aimogen_MCP_Event_Admin','render'));
add_action('aiomatic_mcp_settings_after',array('Aimogen_MCP_Event_Admin','history'));
add_action('admin_post_aimogen_mcp_event_control',array('Aimogen_MCP_Event_Admin','control'));
