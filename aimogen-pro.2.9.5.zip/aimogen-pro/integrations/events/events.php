<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/catalog.php';
require_once __DIR__ . '/transport.php';

/** Opt-in events on the companion's authenticated endpoint. Existing tools are not replaced. */
class Aimogen_MCP_Events {
    private static $installed=false;
    private static $seen=array();

    public static function settings() {
        $settings=get_option('aimogen_mcp_events',array());
        return wp_parse_args(is_array($settings) ? $settings : array(),array('enabled'=>false,'packs'=>array('core','woocommerce'),'form_fields'=>array()));
    }

    public static function enabled() {
        $settings=self::settings(); $mcp=get_option('aiomatic_mcp_settings',array());
        return !empty($settings['enabled']) && !empty($mcp['enable_sse']) && $mcp['enable_sse']==='on' &&
            class_exists('Aiomatic_MCP_Server') && method_exists('Aiomatic_MCP_Server','get_event_context');
    }

    public static function boot() {
        if (!self::enabled()) {
            if (get_option('aimogen_mcp_events_db')==='1') {
                global $wpdb; list($subscriptions,$deliveries)=self::tables();
                $retained=$wpdb->get_var("SELECT id FROM $subscriptions LIMIT 1") || $wpdb->get_var("SELECT id FROM $deliveries LIMIT 1");
                if ($retained && !wp_next_scheduled('aimogen_mcp_events_worker')) { wp_schedule_event(time()+3600,'daily','aimogen_mcp_events_worker'); }
                if (!$retained) { wp_clear_scheduled_hook('aimogen_mcp_events_worker'); }
            }
            return;
        }
        self::schema();
        require_once __DIR__ . '/sources.php';
        Aimogen_MCP_Event_Sources::register();
        if (wp_get_schedule('aimogen_mcp_events_worker')!=='aimogen_events_minute') { wp_clear_scheduled_hook('aimogen_mcp_events_worker'); wp_schedule_event(time()+60,'aimogen_events_minute','aimogen_mcp_events_worker'); }
    }

    public static function changed($old,$new) {
        if (empty($new['enabled'])) { self::disabled(); }
        else { self::boot(); }
    }

    public static function disabled() {
        wp_clear_scheduled_hook('aimogen_mcp_events_worker');
        if (get_option('aimogen_mcp_events_db')!=='1') { return; }
        global $wpdb; list($subscriptions,$deliveries)=self::tables();
        $wpdb->query("UPDATE $subscriptions SET secret='',old_secret='',status='stopped',version=version+1");
        $wpdb->query("UPDATE $deliveries SET body='',guard='',status=IF(status IN ('pending','sending'),'cancelled',status),lease='',lease_until=0");
        self::boot();
    }

    public static function tables() {
        global $wpdb;
        return array($wpdb->prefix . 'aimogen_mcp_subscriptions',$wpdb->prefix . 'aimogen_mcp_deliveries');
    }

    public static function schema() {
        if (self::$installed) { return; }
        self::$installed=true;
        if (get_option('aimogen_mcp_events_db')==='1') { return; }
        global $wpdb;
        list($subscriptions,$deliveries)=self::tables();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $subscriptions (
            id varchar(64) NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            binding varchar(128) NOT NULL,
            role varchar(16) NOT NULL,
            name varchar(100) NOT NULL,
            arguments longtext NOT NULL,
            callback longtext NOT NULL,
            secret longtext NOT NULL,
            old_secret longtext NOT NULL,
            rotate_until bigint(20) unsigned NOT NULL DEFAULT 0,
            expires bigint(20) unsigned NOT NULL,
            verified bigint(20) unsigned NOT NULL DEFAULT 0,
            version bigint(20) unsigned NOT NULL DEFAULT 1,
            status varchar(16) NOT NULL DEFAULT 'verifying',
            updated bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (id),
            KEY owner (user_id,status),
            KEY events (name,status,expires)
        ) $charset;");
        dbDelta("CREATE TABLE $deliveries (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            subscription_id varchar(64) NOT NULL,
            event_id varchar(64) NOT NULL,
            name varchar(100) NOT NULL,
            body longtext NOT NULL,
            guard longtext NOT NULL,
            created bigint(20) unsigned NOT NULL,
            due bigint(20) unsigned NOT NULL,
            attempts int unsigned NOT NULL DEFAULT 0,
            status varchar(16) NOT NULL DEFAULT 'pending',
            lease varchar(64) NOT NULL DEFAULT '',
            lease_until bigint(20) unsigned NOT NULL DEFAULT 0,
            error varchar(64) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY occurrence (subscription_id,event_id),
            KEY due_jobs (status,due),
            KEY subscriptions (subscription_id)
        ) $charset;");
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($subscriptions)))===$subscriptions &&
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($deliveries)))===$deliveries) {
            update_option('aimogen_mcp_events_db','1',false);
        }
    }

    public static function available($definition) {
        if (!$definition) { return false; }
        $settings=self::settings();
        if (!in_array($definition['_dependency'],(array)$settings['packs'],true)) { return false; }
        switch ($definition['_dependency']) {
            case 'woocommerce': return class_exists('WooCommerce');
            case 'subscriptions': return function_exists('wcs_get_subscription');
            case 'membership': return function_exists('pmpro_getMembershipLevelForUser');
            case 'forms': return true; // Aimogen has a native form source.
            case 'cf7': return class_exists('WPCF7_ContactForm');
            case 'seo': return defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION');
            case 'security': return (bool)apply_filters('aimogen_mcp_security_event_providers',array());
            default: return true;
        }
    }

    private static function role() {
        $mcp=get_option('aiomatic_mcp_settings',array());
        $role=isset($mcp['mcp_role']) ? $mcp['mcp_role'] : 'admin';
        return in_array($role,array('admin','readwrite','readonly'),true) ? $role : 'admin';
    }

    public static function authorized($definition,$user,$role,$data=array(),$guard=array()) {
        if (!$definition || !$user || !user_can($user,'administrator')) { return false; }
        if ($definition['_access']==='admin') { return $role==='admin' && user_can($user,'manage_options'); }
        if (!$data) { return true; }
        $family=$definition['_family']; $public=false;
        if (in_array($family,array('post','media','product'),true)) {
            $id=isset($data['post_id']) ? $data['post_id'] : (isset($data['media_id']) ? $data['media_id'] : (isset($data['product_id']) ? $data['product_id'] : 0));
            $post=get_post((int)$id);
            if ($post && $post->post_type==='product_variation') { $post=get_post($post->post_parent); }
            if ($post && $post->post_type==='attachment' && $post->post_parent) { $post=get_post($post->post_parent); }
            $public=$post ? ($post->post_status==='publish' && empty($post->post_password) && is_post_type_viewable($post->post_type)) : !empty($guard['public']);
            if ($family==='media' && $post && $post->post_type==='attachment' && !$post->post_parent) { $public=in_array($post->post_status,array('inherit','publish'),true) && empty($post->post_password); }
            return $public || ($role==='admin' && ($post ? user_can($user,'read_post',$post->ID) : !empty($guard['private_cap']) && user_can($user,$guard['private_cap'])));
        }
        if ($family==='comment' || $family==='review') {
            $id=isset($data['comment_id']) ? $data['comment_id'] : (isset($data['review_id']) ? $data['review_id'] : 0);
            $comment=get_comment((int)$id);
            $post=get_post(isset($data['post_id']) ? (int)$data['post_id'] : (isset($data['product_id']) ? (int)$data['product_id'] : 0));
            $public=$post && $post->post_status==='publish' && empty($post->post_password) && is_post_type_viewable($post->post_type) &&
                ($comment ? $comment->comment_approved==='1' : !empty($guard['public']));
            return $public || ($role==='admin' && user_can($user,'moderate_comments'));
        }
        if ($family==='taxonomy') {
            $taxonomy=get_taxonomy(isset($data['taxonomy']) ? $data['taxonomy'] : '');
            return $taxonomy && ($taxonomy->public || ($role==='admin' && user_can($user,$taxonomy->cap->manage_terms)));
        }
        return $role==='admin';
    }

    private static function binding_valid($subscription) {
        if (!self::enabled() || !user_can((int)$subscription['user_id'],'administrator')) { return false; }
        $mcp=get_option('aiomatic_mcp_settings',array());
        if (strpos($subscription['binding'],'bearer:')===0) {
            return !empty($mcp['bearer_token']) && hash_equals($subscription['binding'],'bearer:' . hash_hmac('sha256',$mcp['bearer_token'],wp_salt('auth')));
        }
        if (strpos($subscription['binding'],'oauth:')===0) {
            $grantId=substr($subscription['binding'],6); $grant=get_transient('aiomatic_mcp_grant_' . $grantId);
            return !empty($mcp['mcp_oauth']) && $mcp['mcp_oauth']==='on' && method_exists('Aiomatic_MCP_OAuth','grant_revoked') && !Aiomatic_MCP_OAuth::grant_revoked($grantId) &&
                is_array($grant) && isset($grant['user_id']) && (int)$grant['user_id']===(int)$subscription['user_id'];
        }
        return false; // Persistent watches require a remote credential, not an admin cookie.
    }

    public static function active($subscription,$data=array(),$guard=array()) {
        $definition=Aimogen_MCP_Event_Catalog::definition($subscription['name']);
        if ($definition && $definition['_family']==='form' && isset($data['fields'])) {
            $settings=self::settings(); $form=(isset($data['provider']) ? $data['provider'] : '') . ':' . (isset($data['form_id']) ? $data['form_id'] : '');
            $approved=isset($settings['form_fields'][$form]) ? (array)$settings['form_fields'][$form] : array();
            if (array_diff(array_keys((array)$data['fields']),$approved)) { return false; }
        }
        return $subscription['status']==='active' && (int)$subscription['expires']>time() && self::binding_valid($subscription) &&
            self::available($definition) && self::authorized($definition,(int)$subscription['user_id'],self::role(),$data,$guard);
    }

    public static function versions($versions) {
        if (self::enabled()) { $versions[]='2026-07-28'; }
        return array_values(array_unique($versions));
    }

    private static function error($id,$code,$message,$reason=null) {
        $error=array('code'=>$code,'message'=>$message);
        if ($reason!==null) { $error['data']=array('reason'=>$reason); }
        return array('jsonrpc'=>'2.0','id'=>$id,'error'=>$error);
    }

    private static function reply($id,$result) { return array('jsonrpc'=>'2.0','id'=>$id,'result'=>$result); }

    public static function rpc($previous,$data,$request,$server) {
        if ($previous!==null || !self::enabled()) { return $previous; }
        $method=isset($data['method']) ? $data['method'] : '';
        if ($method==='tools/call') {
            if (class_exists('Aimogen_MCP_Event_Sources')) { Aimogen_MCP_Event_Sources::mcp_origin(); }
            return null;
        }
        if (!in_array($method,array('server/discover','events/list','events/subscribe','events/unsubscribe'),true)) { return null; }
        $id=isset($data['id']) ? $data['id'] : null;
        if (!isset($data['jsonrpc']) || $data['jsonrpc']!=='2.0' || $id===null || (!is_string($id) && !is_int($id))) { return self::error($id,-32600,'Invalid JSON-RPC event request.'); }
        $params=isset($data['params']) ? $data['params'] : array();
        if (!is_array($params)) { return self::error($id,-32602,'Invalid event parameters.'); }
        $context=$server->get_event_context();
        if (empty($context['user_id']) || !user_can((int)$context['user_id'],'administrator')) { return self::error($id,-32001,'Event access denied.'); }
        if ($method==='server/discover') {
            return self::reply($id,array('resultType'=>'complete','supportedVersions'=>array('2026-07-28'),'capabilities'=>array('tools'=>new stdClass(),'events'=>new stdClass())));
        }
        if ($method==='events/list') {
            $cursor=isset($params['cursor']) ? $params['cursor'] : null; $offset=0;
            if ($cursor!==null) {
                if (!is_string($cursor) || strlen($cursor)>20 || !ctype_digit((string)base64_decode($cursor,true))) { return self::error($id,-32602,'Invalid event cursor.'); }
                $offset=(int)base64_decode($cursor,true);
            }
            $available=array();
            foreach (Aimogen_MCP_Event_Catalog::all() as $definition) {
                if (self::available($definition) && self::authorized($definition,(int)$context['user_id'],$context['role'])) {
                    foreach (array_keys($definition) as $key) { if ($key[0]==='_') { unset($definition[$key]); } }
                    $available[]=$definition;
                }
            }
            $result=array('events'=>array_slice($available,$offset,100));
            if (count($available)>$offset+100) { $result['nextCursor']=base64_encode((string)($offset+100)); }
            return self::reply($id,$result);
        }
        return self::subscription($id,$method,$params,$context);
    }

    private static function subscription($id,$method,$params,$context) {
        global $wpdb;
        $name=isset($params['name']) ? $params['name'] : null;
        $definition=Aimogen_MCP_Event_Catalog::definition($name);
        if (!self::available($definition) || !self::authorized($definition,(int)$context['user_id'],$context['role'])) { return self::error($id,-32602,'Event unavailable or not permitted.'); }
        $arguments=Aimogen_MCP_Event_Catalog::validate_arguments($name,isset($params['arguments']) ? $params['arguments'] : array());
        if (is_wp_error($arguments)) { return self::error($id,-32602,$arguments->get_error_message()); }
        $delivery=isset($params['delivery']) ? $params['delivery'] : null;
        if (!is_array($delivery) || !isset($delivery['mode']) || $delivery['mode']!=='webhook' || !isset($delivery['url'])) { return self::error($id,-32602,'Webhook delivery is required.'); }
        $url=Aimogen_MCP_Event_Transport::callback($delivery['url']);
        if (is_wp_error($url)) { return self::error($id,-32602,$url->get_error_message()); }
        if (empty($context['binding'])) { return self::error($id,-32001,'Connect using a bearer credential or reconnect OAuth before creating persistent watches.'); }
        if (isset($arguments['field_matches'])) {
            $settings=self::settings();
            if (empty($arguments['providers']) || empty($arguments['form_ids'])) { return self::error($id,-32602,'Field filters require an explicit provider and form.'); }
            foreach ($arguments['providers'] as $provider) { foreach ($arguments['form_ids'] as $form) {
                $allowed=isset($settings['form_fields'][$provider . ':' . $form]) ? (array)$settings['form_fields'][$provider . ':' . $form] : array();
                if (array_diff(array_keys($arguments['field_matches']),$allowed)) { return self::error($id,-32602,'A form field has not been approved for delivery.'); }
            } }
        }
        $subscriptionId=hash('sha256',wp_json_encode(array((int)$context['user_id'],$context['binding'],$name,(object)$arguments,$url)));
        self::schema(); list($subscriptions,$deliveries)=self::tables();
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM $subscriptions WHERE id=%s",$subscriptionId),ARRAY_A);
        if ($method==='events/unsubscribe') {
            $wpdb->delete($subscriptions,array('id'=>$subscriptionId,'user_id'=>(int)$context['user_id']));
            $wpdb->query($wpdb->prepare("UPDATE $deliveries SET status='cancelled',body='',lease='',lease_until=0 WHERE subscription_id=%s AND status IN ('pending','sending')",$subscriptionId));
            return self::reply($id,new stdClass());
        }
        $secret=isset($delivery['secret']) ? $delivery['secret'] : null;
        if (is_wp_error(Aimogen_MCP_Event_Transport::secret_key($secret))) { return self::error($id,-32602,'A valid whsec_ signing secret is required.'); }
        if (isset($params['cursor']) && $params['cursor']!==null) { return self::error($id,-32602,'Historical replay is not supported by this event source.'); }
        $ttl=86400;
        if (array_key_exists('ttlMs',$params) && $params['ttlMs']!==null) {
            if (!is_int($params['ttlMs']) || $params['ttlMs']<=0) { return self::error($id,-32602,'ttlMs must be a positive integer or null.'); }
            $ttl=max(300,min(604800,(int)ceil($params['ttlMs']/1000)));
        }
        if ($existing && $existing['status']==='paused') { return self::error($id,-32001,'This subscription is paused in WordPress. Resume it there first.'); }
        if (!$existing && (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $subscriptions WHERE user_id=%d AND expires>%d",(int)$context['user_id'],time()))>=100) {
            return self::error($id,-32000,'The active subscription limit has been reached.');
        }
        $encrypted=Aimogen_MCP_Event_Transport::encrypt($secret);
        if (is_wp_error($encrypted)) { return self::error($id,-32000,$encrypted->get_error_message()); }
        $version=$existing ? (int)$existing['version'] : 1;
        if (!$existing) {
            $inserted=$wpdb->insert($subscriptions,array('id'=>$subscriptionId,'user_id'=>(int)$context['user_id'],'binding'=>$context['binding'],'role'=>$context['role'],
                'name'=>$name,'arguments'=>wp_json_encode((object)$arguments),'callback'=>$url,'secret'=>$encrypted,'old_secret'=>'','expires'=>time()+$ttl,
                'version'=>$version,'status'=>'verifying','updated'=>time()));
            if (!$inserted) { return self::error($id,-32000,'Subscription is already being created. Retry the request.'); }
        }
        $oldSecret=$existing ? Aimogen_MCP_Event_Transport::decrypt($existing['secret']) : null;
        $cached=$existing && $existing['status']==='active' && (int)$existing['verified']>time()-300 && !is_wp_error($oldSecret) && hash_equals($oldSecret,$secret);
        if (!$cached) {
            $challenge=bin2hex(random_bytes(24)); $verificationId='msg_' . str_replace('-','',wp_generate_uuid4());
            $body=wp_json_encode(array('type'=>'verification','challenge'=>$challenge));
            $response=Aimogen_MCP_Event_Transport::send($url,self::headers($verificationId,$body,$secret,$subscriptionId),$body);
            $decoded=is_wp_error($response) ? null : json_decode($response['body'],true);
            if (is_wp_error($response) || $response['status']<200 || $response['status']>=300 || !isset($decoded['challenge']) || !is_string($decoded['challenge']) || !hash_equals($challenge,$decoded['challenge'])) {
                if (!$existing) { $wpdb->delete($subscriptions,array('id'=>$subscriptionId,'version'=>$version,'status'=>'verifying')); }
                return self::error($id,-32015,'Callback verification failed.',is_wp_error($response) ? $response->get_error_code() : 'challenge_failed');
            }
        }
        $expires=time()+$ttl;
        $values=array('secret'=>$encrypted,'expires'=>$expires,'verified'=>time(),'version'=>$version+1,'status'=>'active','updated'=>time(),'role'=>$context['role']);
        if ($existing && !is_wp_error($oldSecret) && !hash_equals($oldSecret,$secret)) {
            $values['old_secret']=$existing['secret']; $values['rotate_until']=time()+300;
        }
        $updated=$wpdb->update($subscriptions,$values,array('id'=>$subscriptionId,'version'=>$version,'status'=>$existing ? $existing['status'] : 'verifying'));
        if (!$updated) { return self::error($id,-32000,'Subscription changed during verification. Retry the request.'); }
        if (class_exists('Aimogen_MCP_Event_Sources')) { Aimogen_MCP_Event_Sources::baseline($name,$arguments); }
        return self::reply($id,array('id'=>$subscriptionId,'refreshBefore'=>gmdate('Y-m-d\\TH:i:s\\Z',$expires),'cursor'=>null,'truncated'=>false));
    }

    private static function headers($id,$body,$secret,$subscription,$oldSecret=null) {
        $timestamp=time(); $signature=Aimogen_MCP_Event_Transport::sign($id,$timestamp,$body,$secret);
        if ($oldSecret!==null && !is_wp_error($oldSecret)) { $signature.=' ' . Aimogen_MCP_Event_Transport::sign($id,$timestamp,$body,$oldSecret); }
        return array('Content-Type'=>'application/json','webhook-id'=>$id,'webhook-timestamp'=>(string)$timestamp,'webhook-signature'=>$signature,'X-MCP-Subscription-Id'=>$subscription);
    }

    public static function emit($name,$data,$guard=array()) {
        if (!self::enabled()) { return false; }
        $definition=Aimogen_MCP_Event_Catalog::definition($name);
        if (!self::available($definition) || !is_array($data)) { return false; }
        self::schema();
        $payload=array('site_id'=>(string)get_current_blog_id(),'resource_type'=>$definition['_family'],'resource_id'=>isset($data['resource_id']) ? (string)$data['resource_id'] : '0',
            'actor_id'=>(string)get_current_user_id(),'source'=>'wordpress');
        $allowed=Aimogen_MCP_Event_Catalog::payload_fields($definition['_family']);
        foreach ($data as $key=>$value) {
            if (!isset($allowed[$key])) { continue; }
            $type=$allowed[$key];
            if ($type==='string' && is_scalar($value)) {
                $text=wp_strip_all_tags((string)$value);
                $payload[$key]=function_exists('mb_substr') ? mb_substr($text,0,2000) : substr($text,0,2000);
            } elseif ($type==='integer' && is_numeric($value)) { $payload[$key]=(int)$value; }
            elseif ($type==='boolean' && is_bool($value)) { $payload[$key]=$value; }
            elseif ($type==='array' && is_array($value)) { $payload[$key]=array_slice(array_values(array_map('strval',array_filter($value,'is_scalar'))),0,100); }
            elseif ($type==='object' && is_array($value) && $definition['_family']==='form') {
                $settings=self::settings(); $keyName=(isset($data['provider']) ? $data['provider'] : '') . ':' . (isset($data['form_id']) ? $data['form_id'] : '');
                $fields=array();
                foreach (isset($settings['form_fields'][$keyName]) ? (array)$settings['form_fields'][$keyName] : array() as $field) {
                    if (isset($value[$field]) && is_scalar($value[$field])) { $text=wp_strip_all_tags((string)$value[$field]); $fields[$field]=function_exists('mb_substr') ? mb_substr($text,0,2000) : substr($text,0,2000); }
                }
                $payload['fields']=(object)$fields;
            }
        }
        $identity=$name . ':' . hash('sha256',wp_json_encode(array($payload,isset($guard['operation']) ? $guard['operation'] : null)));
        if (isset(self::$seen[$identity])) { return false; }
        self::$seen[$identity]=true;
        $eventId='evt_' . str_replace('-','',wp_generate_uuid4());
        $body=wp_json_encode(array('eventId'=>$eventId,'name'=>$name,'timestamp'=>gmdate('Y-m-d\\TH:i:s\\Z'),'data'=>(object)$payload,'cursor'=>null));
        if (!is_string($body) || strlen($body)>65536) { return false; }
        global $wpdb; list($subscriptions,$deliveries)=self::tables();
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $subscriptions WHERE name=%s AND status='active' AND expires>%d LIMIT 500",$name,time()),ARRAY_A);
        $count=0;
        foreach ($rows as $subscription) {
            $arguments=json_decode($subscription['arguments'],true);
            if (!self::active($subscription,$payload,$guard) || !Aimogen_MCP_Event_Catalog::matches($arguments,$payload)) { continue; }
            if ($payload['source']==='mcp' && empty($arguments['include_mcp_changes'])) { continue; }
            if ((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $deliveries WHERE subscription_id=%s AND status IN ('pending','sending')",$subscription['id']))>=1000) {
                $wpdb->update($subscriptions,array('status'=>'paused'),array('id'=>$subscription['id']));
                continue;
            }
            $count+=(int)(bool)$wpdb->insert($deliveries,array('subscription_id'=>$subscription['id'],'event_id'=>$eventId,'name'=>$name,'body'=>$body,
                'guard'=>wp_json_encode($guard),'created'=>time(),'due'=>time(),'status'=>'pending'));
        }
        return $count;
    }

    public static function work() {
        if (get_option('aimogen_mcp_events_db')!=='1') { return; }
        global $wpdb; list($subscriptions,$deliveries)=self::tables();
        $now=time();
        $wpdb->query($wpdb->prepare("UPDATE $deliveries SET body='',status='expired',lease='',lease_until=0 WHERE created<%d AND status IN ('pending','sending')",$now-86400));
        $wpdb->query($wpdb->prepare("UPDATE $deliveries SET body='',guard='' WHERE created<%d AND status NOT IN ('pending','sending')",$now-86400));
        $wpdb->query($wpdb->prepare("DELETE FROM $deliveries WHERE created<%d",$now-604800));
        $wpdb->query($wpdb->prepare("DELETE FROM $subscriptions WHERE expires<%d",$now-604800));
        $wpdb->query($wpdb->prepare("UPDATE $subscriptions SET secret='',old_secret='' WHERE expires<%d",$now));
        $wpdb->query($wpdb->prepare("UPDATE $subscriptions SET old_secret='' WHERE rotate_until<%d AND old_secret<>''",$now));
        if (!self::enabled()) { self::boot(); return; }
        $jobs=$wpdb->get_results($wpdb->prepare("SELECT * FROM $deliveries WHERE due<=%d AND (status='pending' OR (status='sending' AND lease_until<%d)) ORDER BY id LIMIT 10",$now,$now),ARRAY_A);
        $deadline=microtime(true)+30;
        foreach ($jobs as $job) {
            if (microtime(true)>$deadline) { break; }
            $lease=bin2hex(random_bytes(16));
            $claimed=$wpdb->query($wpdb->prepare("UPDATE $deliveries SET status='sending',lease=%s,lease_until=%d WHERE id=%d AND due<=%d AND (status='pending' OR (status='sending' AND lease_until<%d))",$lease,time()+60,$job['id'],time(),time()));
            if (!$claimed) { continue; }
            $subscription=$wpdb->get_row($wpdb->prepare("SELECT * FROM $subscriptions WHERE id=%s",$job['subscription_id']),ARRAY_A);
            $event=json_decode($job['body'],true); $guard=json_decode($job['guard'],true);
            if (!$subscription || !$event || !self::active($subscription,$event['data'],is_array($guard) ? $guard : array())) {
                self::finish($job['id'],$lease,array('status'=>'cancelled','body'=>'','error'=>'access_or_subscription_changed')); continue;
            }
            $secret=Aimogen_MCP_Event_Transport::decrypt($subscription['secret']);
            if (is_wp_error($secret)) { self::finish($job['id'],$lease,array('status'=>'failed','body'=>'','error'=>'signing_key_unavailable')); continue; }
            $oldSecret=(int)$subscription['rotate_until']>time() ? Aimogen_MCP_Event_Transport::decrypt($subscription['old_secret']) : null;
            $response=Aimogen_MCP_Event_Transport::send($subscription['callback'],self::headers($job['event_id'],$job['body'],$secret,$subscription['id'],$oldSecret),$job['body']);
            $attempts=(int)$job['attempts']+1;
            if (!is_wp_error($response) && $response['status']>=200 && $response['status']<300) {
                self::finish($job['id'],$lease,array('status'=>'delivered','attempts'=>$attempts,'error'=>''));
            } else {
                $status=is_wp_error($response) ? 0 : (int)$response['status'];
                $transient=$status===0 || $status===408 || $status===425 || $status===429 || $status>=500;
                if (is_wp_error($response) && in_array($response->get_error_code(),array('invalid_callback','unsafe_destination','invalid_secret','transport_unavailable'),true)) { $transient=false; }
                $retry=$transient && $attempts<8 && (int)$job['created']>time()-86400;
                $delay=min(3600,30*(1 << min($attempts,7)))+random_int(0,20);
                if (!is_wp_error($response) && isset($response['retry_after'])) { $delay=max($delay,min(86400,(int)$response['retry_after'])); }
                self::finish($job['id'],$lease,array('status'=>$retry ? 'pending' : 'failed','attempts'=>$attempts,'due'=>time()+$delay,
                    'error'=>is_wp_error($response) ? $response->get_error_code() : 'http_' . $status,'body'=>$retry ? $job['body'] : ''));
                if ($status===410) { $wpdb->update($subscriptions,array('status'=>'stopped'),array('id'=>$subscription['id'],'version'=>$subscription['version'])); }
            }
        }
    }

    private static function finish($id,$lease,$values) {
        global $wpdb; list($subscriptions,$deliveries)=self::tables();
        $values['lease']=''; $values['lease_until']=0;
        $wpdb->update($deliveries,$values,array('id'=>$id,'lease'=>$lease,'status'=>'sending'));
    }
}

add_filter('aiomatic_mcp_jsonrpc',array('Aimogen_MCP_Events','rpc'),10,4);
add_filter('aiomatic_mcp_protocol_versions',array('Aimogen_MCP_Events','versions'));
add_filter('cron_schedules',function($schedules) { $schedules['aimogen_events_minute']=array('interval'=>60,'display'=>'Aimogen events every minute'); return $schedules; });
add_action('plugins_loaded',array('Aimogen_MCP_Events','boot'),25);
add_action('aimogen_mcp_events_worker',array('Aimogen_MCP_Events','work'));
add_action('update_option_aimogen_mcp_events',array('Aimogen_MCP_Events','changed'),10,2);
add_action('delete_option_aimogen_mcp_events',array('Aimogen_MCP_Events','disabled'),10,0);
require_once __DIR__ . '/admin.php';
