<?php
defined('ABSPATH') || exit;

/** Source adapters capture persisted facts; network work is left to the worker. */
class Aimogen_MCP_Event_Sources {
    private static $registered=false;
    private static $pending=array();
    private static $sequence=0;
    private static $mcp=false;
    private static $createdComments=array();
    private static $commentOps=array();
    private static $deleted=array();
    private static $products=array();
    private static $productOps=array();
    private static $productFields=array();
    private static $orders=array();
    private static $orderFields=array();
    private static $metaBefore=array();
    private static $healthBefore=null;
    private static $versions=array();
    private static $automatic=array();
    private static $updateOps=array();

    public static function mcp_origin() { self::$mcp=true; }
    public static function reset_origin($response,$handler=null,$request=null) {
        if ($request instanceof WP_REST_Request && strpos($request->get_route(),'/aiomatic-mcp/v1/')!==0) { return $response; }
        self::$mcp=false; return $response;
    }

    private static function hook($hook,$callback,$args=1,$priority=20) { add_action($hook,$callback,$priority,$args); }

    public static function register() {
        if (self::$registered || !Aimogen_MCP_Events::enabled()) { return; }
        self::$registered=true;
        self::hook('shutdown',array(__CLASS__,'flush'),0,5);
        add_filter('rest_request_after_callbacks',array(__CLASS__,'reset_origin'),10,3);
        $settings=Aimogen_MCP_Events::settings(); $packs=(array)$settings['packs'];
        if (in_array('core',$packs,true)) {
            self::hook('wp_after_insert_post',array(__CLASS__,'post_saved'),4);
            self::hook('trashed_post',function($id,$previous='') { self::post_lifecycle('post.trashed',$id,$previous); },2);
            self::hook('untrashed_post',function($id) { self::post_lifecycle('post.restored',$id); });
            self::hook('before_delete_post',function($id,$post) { self::$deleted['post:' . $id]=$post; self::$deleted['post_data:' . $id]=self::post($id,$post); },2);
            self::hook('deleted_post',array(__CLASS__,'post_deleted'),2);
            self::hook('add_attachment',function($id) { self::queue('media.uploaded',$id,function() use ($id) { return self::media($id); }); });
            self::hook('attachment_updated',function($id) { self::queue('media.updated',$id,function() use ($id) { return self::media($id); }); });
            foreach (array('created_term'=>'taxonomy.term_created','edited_term'=>'taxonomy.term_updated') as $hook=>$name) {
                self::hook($hook,function($id,$tt,$taxonomy) use ($name) { self::queue($name,$id,self::term($id,$taxonomy)); },3);
            }
            self::hook('delete_term',function($id,$tt,$taxonomy,$term) { self::queue('taxonomy.term_deleted',$id,self::term($id,$taxonomy,$term)); },4);
            self::hook('set_object_terms',function($id,$terms,$tt,$taxonomy,$append,$old) {
                if (array_values((array)$tt)!==array_values((array)$old)) { $data=self::post($id); if (!$data) { return; } $data['taxonomy']=$taxonomy; $ids=wp_get_object_terms($id,$taxonomy,array('fields'=>'ids')); $data['term_ids']=is_wp_error($ids) ? array() : array_map('strval',$ids); $data['changed_fields']=array('terms'); self::queue('post.terms_changed',$id,$data); }
            },6);
            self::hook('deleted_term_relationships',function($id,$tt,$taxonomy) { $data=self::post($id); if (!$data) { return; } $data['taxonomy']=$taxonomy; $terms=wp_get_object_terms($id,$taxonomy,array('fields'=>'ids')); $data['term_ids']=is_wp_error($terms) ? array() : array_map('strval',$terms); $data['changed_fields']=array('terms'); self::queue('post.terms_changed',$id,$data); },3);
            self::hook('user_register',function($id) { self::queue('user.registered',$id,self::user($id)); });
            self::hook('profile_update',function($id,$old) {
                $data=self::user($id); $new=get_userdata($id); $changed=array();
                foreach (array('display_name','first_name','last_name','description','user_url') as $key) { if ($new && (string)$old->$key!==(string)$new->$key) { $changed[]=$key; } }
                if ($changed) { $data['changed_fields']=$changed; self::queue('user.profile_updated',$id,$data); }
            },2);
            self::hook('set_user_role',function($id,$role,$old) { self::role_changed($id,(array)$old); },3);
            self::hook('add_user_role',function($id,$role) { $user=get_userdata($id); self::role_changed($id,$user ? array_values(array_diff($user->roles,array($role))) : array()); },2);
            self::hook('remove_user_role',function($id,$role) { $user=get_userdata($id); self::role_changed($id,$user ? array_merge($user->roles,array($role)) : array($role)); },2);
            self::hook('after_password_reset',function($user) { self::queue('user.password_reset',$user->ID,self::user($user->ID)); });
            self::hook('delete_user',function($id) { self::$deleted['user:' . $id]=self::user($id); });
            self::hook('deleted_user',function($id) { self::queue('user.deleted',$id,isset(self::$deleted['user:' . $id]) ? self::$deleted['user:' . $id] : array('user_id'=>(string)$id)); });
            self::hook('wp_login_failed',array(__CLASS__,'login_failed'),0);
            self::maintenance();
            self::aimogen();
        }
        if (in_array('core',$packs,true) || in_array('woocommerce',$packs,true)) {
            foreach (array('comment_post','wp_insert_comment') as $hook) { self::hook($hook,function($id) { self::comment_created($id); }); }
            self::hook('edit_comment',function($id) { self::discussion('updated',$id); });
            self::hook('transition_comment_status',array(__CLASS__,'comment_status'),3);
            self::hook('delete_comment',function($id,$comment) { self::$deleted['comment:' . $id]=$comment; },2);
            self::hook('deleted_comment',function($id,$comment=null) { if (!$comment && isset(self::$deleted['comment:' . $id])) { $comment=self::$deleted['comment:' . $id]; } self::discussion('deleted',$id,$comment); },2);
        }
        if (in_array('core',$packs,true) || in_array('seo',$packs,true)) {
            foreach (array('added_post_meta','updated_post_meta','deleted_post_meta') as $hook) { self::hook($hook,array(__CLASS__,'post_meta'),4); }
        }
        if (in_array('woocommerce',$packs,true) && class_exists('WooCommerce')) { self::woocommerce(); }
        require_once __DIR__ . '/sources-extra.php';
        aimogen_mcp_event_extra_sources($packs);
    }

    public static function queue($name,$id,$data,$guard=array(),$operation=null) {
        if (!Aimogen_MCP_Events::available(Aimogen_MCP_Event_Catalog::definition($name))) { return; }
        $operation=$operation===null ? (is_array($data) ? hash('sha256',wp_json_encode($data)) : 'deferred') : (string)$operation;
        $key=$name . ':' . (string)$id . ':' . $operation;
        $guard['operation']=$operation;
        self::$pending[$key]=array('name'=>$name,'id'=>(string)$id,'data'=>$data,'guard'=>$guard,'mcp'=>self::$mcp,'actor'=>get_current_user_id());
    }

    public static function flush() {
        $pending=self::$pending; self::$pending=array();
        foreach ($pending as $item) {
            $data=is_callable($item['data']) ? call_user_func($item['data']) : $item['data'];
            if (!is_array($data) || !$data) { continue; }
            $data['resource_id']=$item['id']; $data['source']=$item['mcp'] ? 'mcp' : (isset($data['source']) ? $data['source'] : 'wordpress');
            $data['actor_id']=(string)$item['actor'];
            Aimogen_MCP_Events::emit($item['name'],$data,$item['guard']);
        }
        self::$createdComments=array(); self::$commentOps=array();
    }

    public static function post($id,$post=null) {
        $post=$post ?: get_post($id);
        if (!$post || wp_is_post_revision($post->ID) || $post->post_status==='auto-draft') { return array(); }
        $taxonomies=array(); $termIds=array();
        foreach (get_object_taxonomies($post->post_type,'objects') as $taxonomy) {
            if (!$taxonomy->public) { continue; }
            $ids=wp_get_object_terms($post->ID,$taxonomy->name,array('fields'=>'ids'));
            if (!is_wp_error($ids) && $ids) { $taxonomies[]=$taxonomy->name; $termIds=array_merge($termIds,array_map('strval',$ids)); }
        }
        return array('post_id'=>(string)$post->ID,'post_type'=>$post->post_type,'status'=>$post->post_status,'author_id'=>(string)$post->post_author,
            'title'=>$post->post_title,'excerpt'=>wp_trim_words(wp_strip_all_tags($post->post_excerpt ?: $post->post_content),100,''),
            'taxonomies'=>$taxonomies,'term_ids'=>array_values(array_unique($termIds)),'url'=>get_permalink($post));
    }

    private static function post_guard($post) {
        $type=$post ? get_post_type_object($post->post_type) : null;
        $visible=$post;
        if ($post && in_array($post->post_type,array('attachment','product_variation'),true) && $post->post_parent) { $visible=get_post($post->post_parent); }
        $public=$visible && $visible->post_status==='publish' && !$visible->post_password && is_post_type_viewable($visible->post_type);
        if ($post && $post->post_type==='attachment' && !$post->post_parent) { $public=in_array($post->post_status,array('inherit','publish'),true) && !$post->post_password; }
        return array('public'=>$public,
            'private_cap'=>$type ? $type->cap->edit_posts : 'edit_posts');
    }

    public static function post_saved($id,$post,$update,$before) {
        if (wp_is_post_revision($id) || wp_is_post_autosave($id) || $post->post_status==='auto-draft' || in_array($post->post_type,array('attachment','product','product_variation','shop_order','shop_order_refund','shop_subscription','shop_coupon','aiomatic_agent','aiomatic_form'),true)) { return; }
        $data=self::post($id,$post); $operation=++self::$sequence; $guard=self::post_guard($before ?: $post);
        $map=array('post_title'=>'title','post_content'=>'content','post_excerpt'=>'excerpt','post_status'=>'status','post_author'=>'author','post_name'=>'slug','post_parent'=>'parent','post_password'=>'visibility','post_date'=>'scheduled_date');
        $changed=array();
        if ($before) { foreach ($map as $field=>$label) { if ((string)$before->$field!==(string)$post->$field) { $changed[]=$label; } } }
        $data['changed_fields']=$changed;
        if (!$update) { self::queue('post.created',$id,$data,$guard,$operation); }
        elseif ($changed) { self::queue('post.updated',$id,$data,$guard,$operation); }
        $old=$before ? $before->post_status : 'new';
        if ($old!==$post->post_status) {
            $data['previous_status']=$old;
            self::queue('post.status_changed',$id,$data,$guard,$operation);
            if ($post->post_status==='publish') { self::queue('post.published',$id,$data,$guard,$operation); }
            if ($old==='publish' && $post->post_status!=='publish') { self::queue('post.unpublished',$id,$data,$guard,$operation); }
            if ($post->post_status==='pending') { self::queue('post.review_requested',$id,$data,$guard,$operation); }
        }
        if ($post->post_status==='future' && ($old!=='future' || in_array('scheduled_date',$changed,true))) { self::queue('post.scheduled',$id,$data,$guard,$operation); }
        if ($before && (in_array('slug',$changed,true) || in_array('parent',$changed,true))) {
            $data['previous_url']=get_permalink($before);
            self::queue('post.permalink_changed',$id,$data,$guard,$operation);
        }
    }

    public static function post_lifecycle($name,$id,$previous='') {
        $post=get_post($id);
        if (!$post || $post->post_type==='attachment') { return; }
        $guard=self::post_guard($post);
        if ($previous==='publish') { $guard['public']=true; }
        if ($post->post_type==='product') { if (!function_exists('wc_get_product')) { return; } $name=str_replace('post.','woocommerce.product.',$name); $data=self::product_data(wc_get_product($id)); }
        else { $data=self::post($id,$post); }
        if ($previous) { $data['previous_status']=$previous; }
        self::queue($name,$id,$data,$guard,++self::$sequence);
    }

    public static function post_deleted($id,$post=null) {
        $post=$post ?: (isset(self::$deleted['post:' . $id]) ? self::$deleted['post:' . $id] : null);
        if (!$post) { return; }
        if ($post->post_type==='attachment') { self::queue('media.deleted',$id,array('media_id'=>(string)$id,'parent_id'=>(string)$post->post_parent,'mime_type'=>$post->post_mime_type,'title'=>$post->post_title),self::post_guard($post)); }
        elseif (!in_array($post->post_type,array('product','product_variation','shop_order','shop_order_refund','shop_subscription','shop_coupon','revision'),true)) { self::queue('post.deleted',$id,isset(self::$deleted['post_data:' . $id]) ? self::$deleted['post_data:' . $id] : self::post($id,$post),self::post_guard($post)); }
    }

    private static function media($id) {
        $post=get_post($id); if (!$post) { return array(); }
        $data=array('media_id'=>(string)$id,'parent_id'=>(string)$post->post_parent,'mime_type'=>$post->post_mime_type,'title'=>$post->post_title,'alt_text'=>(string)get_post_meta($id,'_wp_attachment_image_alt',true));
        $metadata=wp_get_attachment_metadata($id);
        foreach (array('width','height') as $key) { if (is_array($metadata) && isset($metadata[$key])) { $data[$key]=(int)$metadata[$key]; } }
        $url=wp_get_attachment_url($id); if ($url) { $data['url']=$url; }
        return $data;
    }

    private static function term($id,$taxonomy,$term=null) {
        $term=$term ?: get_term($id,$taxonomy);
        if (!$term || is_wp_error($term)) { return array(); }
        $data=array('term_id'=>(string)$id,'taxonomy'=>$taxonomy,'name'=>$term->name,'slug'=>$term->slug,'parent_id'=>(string)$term->parent,'description'=>$term->description);
        $url=get_term_link($term); if (!is_wp_error($url)) { $data['url']=$url; }
        return $data;
    }

    public static function post_meta($metaId,$id,$key,$value) {
        $post=get_post($id);
        if (!$post || wp_is_post_revision($id) || wp_is_post_autosave($id)) { return; }
        if ($key==='_thumbnail_id') { $data=self::post($id); $data['changed_fields']=array('featured_image'); self::queue('post.featured_image_changed',$id,$data); }
        elseif ($key==='_wp_attachment_image_alt') { self::queue('media.alt_text_changed',$id,function() use ($id) { return self::media($id); }); }
        elseif ($key==='_wp_attachment_metadata') { self::queue('media.updated',$id,function() use ($id) { return self::media($id); }); }
        elseif (in_array($key,array('rank_math_title','rank_math_description','rank_math_focus_keyword','_yoast_wpseo_title','_yoast_wpseo_metadesc','_yoast_wpseo_focuskw'),true)) {
            $data=self::post($id); $data['changed_fields']=array($key); self::queue('post.seo_metadata_changed',$id,$data);
        }
    }

    private static function is_review($comment) {
        $post=$comment ? get_post($comment->comment_post_ID) : null;
        return $post && $post->post_type==='product' && !$comment->comment_parent && $comment->comment_type!=='order_note';
    }

    public static function comment_created($id) {
        if (!isset(self::$createdComments[$id])) { self::$createdComments[$id]=true; self::$commentOps[$id]=++self::$sequence; }
        self::discussion('created',$id);
    }

    public static function discussion($action,$id,$captured=null) {
        $comment=$captured ?: get_comment($id);
        if (!$comment || $comment->comment_type==='order_note') { return; }
        $review=self::is_review($comment);
        $name=($review ? 'woocommerce.review.' : 'comment.') . $action;
        if (!Aimogen_MCP_Event_Catalog::definition($name)) { return; }
        $operation=isset(self::$commentOps[$id]) ? self::$commentOps[$id] : ++self::$sequence;
        self::queue($name,$id,function() use ($id,$captured,$review) {
            $comment=$captured ?: get_comment($id); if (!$comment) { return array(); }
            $data=array('status'=>self::comment_state($comment->comment_approved),'text'=>$comment->comment_content);
            if ($review) { $data['review_id']=(string)$id; $data['product_id']=(string)$comment->comment_post_ID; $rating=get_comment_meta($id,'rating',true); if ($rating!=='') { $data['rating']=(int)$rating; } }
            else { $data['comment_id']=(string)$id; $data['post_id']=(string)$comment->comment_post_ID; $data['parent_comment_id']=(string)$comment->comment_parent; $data['comment_type']=$comment->comment_type ?: 'comment'; }
            return $data;
        },array('public'=>$comment->comment_approved==='1'),$operation);
    }

    private static function comment_state($status) { return $status==='1' ? 'approved' : ($status==='0' ? 'unapproved' : $status); }

    public static function comment_status($new,$old,$comment) {
        if ($new===$old) { return; }
        self::$commentOps[$comment->comment_ID]=++self::$sequence;
        $map=array('approved'=>'approved','unapproved'=>'unapproved','spam'=>'marked_spam','trash'=>'trashed');
        if (isset($map[$new])) { self::discussion($map[$new],$comment->comment_ID); }
        if ($old==='trash' && $new!=='trash') { self::discussion('restored',$comment->comment_ID); }
    }

    private static function user($id) {
        $user=get_userdata($id);
        return $user ? array('user_id'=>(string)$id,'display_name'=>$user->display_name,'roles'=>array_values($user->roles)) : array('user_id'=>(string)$id);
    }

    private static function role_changed($id,$old) {
        $data=self::user($id); $roles=isset($data['roles']) ? $data['roles'] : array();
        if (array_values($roles)===array_values($old)) { return; }
        self::queue('user.role_changed',$id,$data);
        $had=in_array('administrator',$old,true); $has=in_array('administrator',$roles,true);
        if ($had!==$has) { self::queue($has ? 'security.administrator_granted' : 'security.administrator_removed',$id,array('user_id'=>(string)$id,'severity'=>'high','provider'=>'wordpress')); }
    }

    public static function login_failed() {
        $window=(int)floor(time()/600); $key='aimogen_mcp_login_failures_' . $window;
        $count=(int)get_transient($key)+1; set_transient($key,$count,700);
        if ($count===10) { self::queue('security.login_failures_detected',$window,array('provider'=>'wordpress','severity'=>'warning','count'=>$count,'window_seconds'=>600)); }
    }

    private static function maintenance() {
        self::hook('pre_auto_update',function($type,$item) {
            if (!in_array($type,array('plugin','theme','core'),true)) { return; }
            $id=isset($item->$type) ? $item->$type : $type;
            self::$automatic[$type . ':' . $id]=true;
            self::remember_version(array('type'=>$type,$type=>$id));
        },2);
        foreach (array('activated_plugin'=>'plugin.activated','deactivated_plugin'=>'plugin.deactivated') as $hook=>$name) { self::hook($hook,function($plugin) use ($name) { self::queue($name,$plugin,array('component_id'=>$plugin,'component_type'=>'plugin')); }); }
        self::hook('after_switch_theme',function($oldName,$oldTheme) { $theme=wp_get_theme(); self::queue('theme.activated',$theme->get_stylesheet(),array('component_id'=>$theme->get_stylesheet(),'component_type'=>'theme','version'=>$theme->get('Version'))); },2);
        add_filter('upgrader_pre_install',function($result,$extra) { self::remember_version($extra); return $result; },10,2);
        add_filter('upgrader_install_package_result',function($result,$extra) { self::updater($result,$extra,false); return $result; },PHP_INT_MAX,2);
        self::hook('automatic_updates_complete',function($results) {
            foreach ((array)$results as $type=>$items) { foreach ((array)$items as $item) {
                if (isset($item->result,$item->item)) { $extra=array('type'=>$type); if ($type==='plugin') { $extra['plugin']=$item->item->plugin; } elseif ($type==='theme') { $extra['theme']=$item->item->theme; } elseif ($type==='core' && isset($item->item->current)) { $extra['version']=$item->item->current; } self::updater($item->result,$extra,true); }
            } }
            self::$automatic=array();
        });
        self::hook('_core_updated_successfully',function($version) { self::updater(true,array('type'=>'core','action'=>'update','version'=>(string)$version),false); });
        add_filter('pre_set_transient_health-check-site-status-result',function($value) { $old=get_transient('health-check-site-status-result'); self::$healthBefore=is_string($old) ? json_decode($old,true) : $old; return $value; });
        self::hook('set_transient_health-check-site-status-result',function($value) {
            $data=is_string($value) ? json_decode($value,true) : $value;
            if (!is_array($data) || !is_array(self::$healthBefore) || $data===self::$healthBefore) { return; }
            $data=array_intersect_key($data,array_flip(array('critical','recommended','good')));
            $data['component_type']='site_health'; $data['component_id']='site_health'; $data['severity']=!empty($data['critical']) ? 'critical' : 'recommended';
            self::queue('site.health_changed','site_health',$data);
        });
        self::hook('wp_mail_failed',function($error) { self::queue('email.delivery_failed','wordpress_mail',array('component_type'=>'email','component_id'=>'wordpress_mail','error_category'=>is_wp_error($error) ? sanitize_key($error->get_error_code()) : 'send_failed','severity'=>'warning')); });
    }

    private static function remember_version($extra) {
        $type=isset($extra['type']) ? $extra['type'] : (isset($extra['plugin']) ? 'plugin' : (isset($extra['theme']) ? 'theme' : ''));
        $id=isset($extra[$type]) ? $extra[$type] : $type;
        self::$updateOps[$type . ':' . $id]=++self::$sequence;
        if ($type==='plugin' && is_file(WP_PLUGIN_DIR . '/' . $id)) { $data=get_file_data(WP_PLUGIN_DIR . '/' . $id,array('Version'=>'Version'),'plugin'); self::$versions[$type . ':' . $id]=$data['Version']; }
        elseif ($type==='theme') { self::$versions[$type . ':' . $id]=wp_get_theme($id)->get('Version'); }
        elseif ($type==='core') { global $wp_version; self::$versions['core:core']=$wp_version; }
    }

    private static function updater($result,$extra,$automatic) {
        $type=isset($extra['type']) ? $extra['type'] : (isset($extra['plugin']) ? 'plugin' : (isset($extra['theme']) ? 'theme' : ''));
        if (!in_array($type,array('plugin','theme','core'),true) || (isset($extra['action']) && $extra['action']!=='update')) { return; }
        $id=isset($extra[$type]) ? $extra[$type] : $type;
        $prefix=$type==='core' ? 'wordpress' : $type;
        $failed=is_wp_error($result) || $result===false;
        $operation=isset(self::$updateOps[$type . ':' . $id]) ? self::$updateOps[$type . ':' . $id] : 'update:' . $type . ':' . $id;
        $automatic=$automatic || !empty(self::$automatic[$type . ':' . $id]);
        $data=array('component_type'=>$prefix,'component_id'=>$type==='core' ? 'wordpress' : $id,'automatic'=>(bool)$automatic);
        if (isset(self::$versions[$type . ':' . $id])) { $data['previous_version']=self::$versions[$type . ':' . $id]; }
        if ($failed) { $data['error_category']=is_wp_error($result) ? sanitize_key($result->get_error_code()) : 'update_failed'; $data['severity']='warning'; }
        elseif ($type==='plugin' && is_file(WP_PLUGIN_DIR . '/' . $id)) { $plugin=get_file_data(WP_PLUGIN_DIR . '/' . $id,array('Version'=>'Version'),'plugin'); $data['version']=$plugin['Version']; }
        elseif ($type==='theme') { $data['version']=wp_get_theme($id)->get('Version'); }
        elseif ($type==='core') { global $wp_version; $data['version']=isset($extra['version']) ? (string)$extra['version'] : $wp_version; }
        self::queue($prefix . ($failed ? '.update_failed' : '.updated'),$type==='core' ? 'wordpress' : $id,$data,array(),$operation);
    }

    private static function aimogen() {
        self::hook('aimogen_ai_editor_changes_applied',function($id) { self::queue('aimogen.editor.changes_applied',$id,array('post_id'=>(string)$id)); });
        self::hook('aimogen_ai_editor_changes_undone',function($id) { self::queue('aimogen.editor.changes_undone',$id,array('post_id'=>(string)$id)); });
        self::hook('aimogen_reliability_failover',function($from,$to,$category) { self::queue('aimogen.provider.failover',$to,array('model'=>(string)$to,'previous_model'=>(string)$from,'error_category'=>sanitize_key($category))); },3);
        self::hook('aimogen_smart_key_state_changed',function($fingerprint,$state) {
            $data=array(); foreach (array('provider','category') as $key) { if (!empty($state[$key]) && is_scalar($state[$key])) { $data[$key==='category' ? 'error_category' : $key]=sanitize_key($state[$key]); } }
            if ($data) { self::queue('aimogen.provider.key_state_changed','provider',$data); }
        },2);
        self::hook('aimogen_smart_key_recovered',function($key,$provider) { self::queue('aimogen.provider.key_recovered',$provider,array('provider'=>sanitize_key($provider))); },2);
        foreach (array('started','completed','failed') as $state) { self::hook('aimogen_mcp_automation_' . $state,function($rule,$run) use ($state) { self::queue('aimogen.automation.' . $state,$run,array('rule_id'=>(string)$rule,'run_id'=>(string)$run,'outcome'=>$state)); },2); }
        self::hook('aimogen_mcp_automation_skipped',function($rule,$run) {
            foreach (self::$pending as $key=>$item) { if ($item['name']==='aimogen.automation.started' && $item['id']===(string)$run) { unset(self::$pending[$key]); } }
        },2);
    }

    public static function product_data($product) {
        if (!$product || !is_a($product,'WC_Product')) { return array(); }
        return array('product_id'=>(string)$product->get_id(),'parent_id'=>(string)$product->get_parent_id(),'product_type'=>$product->get_type(),
            'name'=>$product->get_name(),'sku'=>$product->get_sku(),'price'=>(string)$product->get_price(),'quantity'=>(string)$product->get_stock_quantity(),
            'stock_status'=>$product->get_stock_status(),'threshold'=>(string)wc_get_low_stock_amount($product),'category_ids'=>array_map('strval',$product->get_category_ids()),'url'=>$product->get_permalink());
    }

    public static function product_before($product) {
        if (!$product || !$product->get_id()) { return; }
        $id=$product->get_id();
        if (!isset(self::$products[$id])) { self::$products[$id]=self::product_data(wc_get_product($id)); self::$productOps[$id]=++self::$sequence; }
        self::$productFields[$id]=array_keys($product->get_changes());
    }

    public static function baseline($name,$arguments) {
        if (strpos($name,'woocommerce.product.')!==0 || !function_exists('wc_get_product') || empty($arguments['product_ids'])) { return; }
        foreach ($arguments['product_ids'] as $id) { $data=self::product_data(wc_get_product($id)); if ($data) { set_transient('aimogen_mcp_stock_' . $id,$data,172800); } }
    }

    public static function product_after($product,$created=false) {
        if (!$product || !$product->get_id()) { return; }
        $id=$product->get_id(); $data=self::product_data($product); $old=isset(self::$products[$id]) ? self::$products[$id] : get_transient('aimogen_mcp_stock_' . $id);
        $operation=isset(self::$productOps[$id]) ? self::$productOps[$id] : ++self::$sequence;
        $prefix=$product->is_type('variation') ? 'woocommerce.variation.' : 'woocommerce.product.';
        if ($created) { self::queue($prefix . 'created',$id,$data,array(),$operation); }
        else {
            $changed=isset(self::$productFields[$id]) ? self::$productFields[$id] : array_keys($product->get_changes());
            if (is_array($old)) { foreach (array('name','sku','price','quantity','stock_status') as $field) { if ($old[$field]!==$data[$field]) { $changed[]=$field; } } }
            // WooCommerce supplies a committed object change even when a cached baseline is absent.
            if ($changed) { $data['changed_fields']=array_values(array_unique($changed)); self::queue($prefix . 'updated',$id,$data,array(),$operation); }
            if (is_array($old)) {
                if ($old['price']!==$data['price']) { $data['previous_price']=$old['price']; self::queue('woocommerce.product.price_changed',$id,$data,array(),$operation); }
                if ($old['quantity']!==$data['quantity']) { $data['previous_quantity']=$old['quantity']; self::queue('woocommerce.product.stock_changed',$id,$data,array(),$operation); }
                if ($old['stock_status']!==$data['stock_status']) {
                    $data['previous_stock_status']=$old['stock_status']; self::queue('woocommerce.product.stock_status_changed',$id,$data,array(),$operation);
                    if ($data['stock_status']==='outofstock') { self::queue('woocommerce.product.out_of_stock',$id,$data,array(),$operation); }
                    if ($old['stock_status']==='outofstock' && $data['stock_status']==='instock') { self::queue('woocommerce.product.back_in_stock',$id,$data,array(),$operation); }
                }
                if ($data['quantity']!=='' && $old['quantity']!=='' && (float)$old['quantity']>(float)$data['threshold'] && (float)$data['quantity']<=(float)$data['threshold'] && (float)$data['quantity']>0) { self::queue('woocommerce.product.low_stock',$id,$data,array(),$operation); }
            }
        }
        set_transient('aimogen_mcp_stock_' . $id,self::product_data($product),172800);
        unset(self::$products[$id],self::$productFields[$id]);
    }

    public static function order_data($order) {
        if (!$order || !is_a($order,'WC_Abstract_Order')) { return array(); }
        $ids=array(); $count=0;
        foreach ($order->get_items() as $item) { $ids[]=(string)$item->get_product_id(); $count+=(int)$item->get_quantity(); }
        return array('order_id'=>(string)$order->get_id(),'status'=>$order->get_status(),'currency'=>$order->get_currency(),'total'=>(string)$order->get_total(),
            'product_ids'=>array_values(array_unique($ids)),'item_count'=>$count,'payment_method_id'=>is_callable(array($order,'get_payment_method')) ? $order->get_payment_method() : '');
    }

    private static function woocommerce() {
        $packs=Aimogen_MCP_Events::settings()['packs'];
        if (!in_array('core',(array)$packs,true)) {
            self::hook('trashed_post',function($id,$previous='') { if (get_post_type($id)==='product') { self::post_lifecycle('post.trashed',$id,$previous); } },2);
            self::hook('untrashed_post',function($id) { if (get_post_type($id)==='product') { self::post_lifecycle('post.restored',$id); } });
        }
        self::hook('before_delete_post',function($id,$post) {
            if (in_array($post->post_type,array('product','product_variation'),true)) { self::$deleted['product:' . $id]=array('data'=>self::product_data(wc_get_product($id)),'guard'=>self::post_guard($post)); }
        },2);
        self::hook('woocommerce_before_product_object_save',array(__CLASS__,'product_before'));
        foreach (array('woocommerce_product_before_set_stock','woocommerce_variation_before_set_stock') as $hook) { self::hook($hook,array(__CLASS__,'product_before')); }
        foreach (array('woocommerce_new_product','woocommerce_new_product_variation') as $hook) { self::hook($hook,function($id,$product) { self::product_after($product,true); },2); }
        foreach (array('woocommerce_update_product','woocommerce_update_product_variation') as $hook) { self::hook($hook,function($id,$product) { self::product_after($product); },2); }
        foreach (array('woocommerce_product_set_stock','woocommerce_variation_set_stock') as $hook) { self::hook($hook,array(__CLASS__,'product_after')); }
        foreach (array('woocommerce_product_set_stock_status','woocommerce_variation_set_stock_status') as $hook) { self::hook($hook,function($id,$status,$product) { self::product_after($product); },3); }
        self::hook('transition_post_status',function($new,$old,$post) {
            if ($post->post_type==='product' && $new==='publish' && $old!=='publish') { self::queue('woocommerce.product.published',$post->ID,function() use ($post) { return self::product_data(wc_get_product($post->ID)); }); }
        },3);
        foreach (array('woocommerce_delete_product'=>'woocommerce.product.deleted','woocommerce_delete_product_variation'=>'woocommerce.variation.deleted') as $hook=>$name) {
            self::hook($hook,function($id) use ($name) { $snapshot=isset(self::$deleted['product:' . $id]) ? self::$deleted['product:' . $id] : array('data'=>array('product_id'=>(string)$id),'guard'=>array('private_cap'=>'edit_products')); self::queue($name,$id,$snapshot['data'],$snapshot['guard']); delete_transient('aimogen_mcp_stock_' . $id); });
        }
        foreach (array('wc_after_products_starting_sales'=>'woocommerce.product.sale_started','wc_after_products_ending_sales'=>'woocommerce.product.sale_ended') as $hook=>$name) { self::hook($hook,function($ids) use ($name) { foreach ((array)$ids as $id) { self::queue($name,$id,self::product_data(wc_get_product($id))); } }); }
        self::hook('woocommerce_before_order_object_save',function($order) { if ($order->get_id()) { $old=wc_get_order($order->get_id()); if ($old) { self::$orders[$order->get_id()]=self::order_data($old); self::$orderFields[$order->get_id()]=array_keys($order->get_changes()); } } });
        foreach (array('woocommerce_new_order'=>'woocommerce.order.created','woocommerce_update_order'=>'woocommerce.order.updated') as $hook=>$name) {
            self::hook($hook,function($id,$order=null) use ($name) {
                $order=$order ?: wc_get_order($id); if (!$order || $order->get_type()!=='shop_order' || in_array($order->get_status(),array('checkout-draft','auto-draft'),true)) { return; }
                $data=self::order_data($order);
                $changed=isset(self::$orderFields[$id]) ? self::$orderFields[$id] : array_keys($order->get_changes());
                if (isset(self::$orders[$id])) { foreach ($data as $key=>$value) { if (!isset(self::$orders[$id][$key]) || self::$orders[$id][$key]!==$value) { $changed[]=$key; } } }
                if ($name==='woocommerce.order.updated' && !$changed) { return; }
                $data['changed_fields']=array_values(array_unique($changed));
                self::queue($name,$id,$data);
                unset(self::$orders[$id],self::$orderFields[$id]);
            },2);
        }
        self::hook('woocommerce_order_status_changed',function($id,$old,$new,$order) {
            if ($old===$new || $new==='checkout-draft' || $order->get_type()!=='shop_order') { return; }
            $data=self::order_data($order); $data['previous_status']=$old; self::queue('woocommerce.order.status_changed',$id,$data);
            $map=array('completed'=>'completed','failed'=>'failed','cancelled'=>'cancelled','on-hold'=>'on_hold');
            if (isset($map[$new])) { self::queue('woocommerce.order.' . $map[$new],$id,$data); }
        },4);
        self::hook('woocommerce_payment_complete',function($id) { self::queue('woocommerce.order.paid',$id,self::order_data(wc_get_order($id))); });
        self::hook('woocommerce_before_delete_order',function($id,$order) { self::$deleted['order:' . $id]=self::order_data($order); },2);
        self::hook('woocommerce_before_delete_order_refund',function($id) { $refund=wc_get_order($id); if ($refund) { self::$deleted['refund:' . $id]=array_merge(self::order_data(wc_get_order($refund->get_parent_id())),array('refund_id'=>(string)$id)); } });
        foreach (array('woocommerce_trash_order'=>'woocommerce.order.trashed','woocommerce_untrash_order'=>'woocommerce.order.restored','woocommerce_delete_order'=>'woocommerce.order.deleted') as $hook=>$name) { self::hook($hook,function($id) use ($name) { $data=$name==='woocommerce.order.deleted' && isset(self::$deleted['order:' . $id]) ? self::$deleted['order:' . $id] : self::order_data(wc_get_order($id)); if (!$data) { $data=array('order_id'=>(string)$id); } self::queue($name,$id,$data); }); }
        self::hook('woocommerce_order_note_added',function($id,$order) { $data=self::order_data($order); $comment=get_comment($id); $data['note_id']=(string)$id; if ($comment) { $data['note']=$comment->comment_content; } self::queue('woocommerce.order.note_created',$order->get_id(),$data); },2);
        foreach (array('woocommerce_new_order_item'=>'created','woocommerce_update_order_item'=>'updated') as $hook=>$action) { self::hook($hook,function($id,$item,$orderId=0) use ($action) { if (!$orderId) { $item=WC_Order_Factory::get_order_item($id); $orderId=$item ? $item->get_order_id() : 0; } if (!$orderId) { return; } $data=self::order_data(wc_get_order($orderId)); if (!$data) { return; } $data['item_id']=(string)$id; self::queue('woocommerce.order.item_' . $action,$orderId,$data); },3); }
        self::hook('woocommerce_before_delete_order_item',function($id) { $item=WC_Order_Factory::get_order_item($id); if ($item) { self::$deleted['item:' . $id]=$item->get_order_id(); } });
        self::hook('woocommerce_delete_order_item',function($id) { if (isset(self::$deleted['item:' . $id])) { $orderId=self::$deleted['item:' . $id]; $data=self::order_data(wc_get_order($orderId)); $data['item_id']=(string)$id; self::queue('woocommerce.order.item_deleted',$orderId,$data); } });
        self::hook('woocommerce_refund_created',function($id,$args) { $refund=wc_get_order($id); if ($refund) { $data=self::order_data(wc_get_order($refund->get_parent_id())); $data['refund_id']=(string)$id; $data['refund_amount']=(string)$refund->get_amount(); self::queue('woocommerce.refund.created',$id,$data); } },2);
        self::hook('woocommerce_order_refunded',function($id,$refundId) { $data=self::order_data(wc_get_order($id)); $data['refund_id']=(string)$refundId; self::queue('woocommerce.order.refunded',$id,$data); },2);
        foreach (array('woocommerce_refund_deleted','woocommerce_delete_order_refund') as $hook) { self::hook($hook,function($id,$orderId=0) { self::queue('woocommerce.refund.deleted',$id,isset(self::$deleted['refund:' . $id]) ? self::$deleted['refund:' . $id] : array('refund_id'=>(string)$id,'order_id'=>(string)$orderId)); },2); }
        foreach (array('woocommerce_new_coupon'=>'created','woocommerce_update_coupon'=>'updated','woocommerce_delete_coupon'=>'deleted','woocommerce_increase_coupon_usage_count'=>'usage_changed','woocommerce_decrease_coupon_usage_count'=>'usage_changed') as $hook=>$action) {
            self::hook($hook,function($value,$count=null) use ($action) { $coupon=is_object($value) ? $value : new WC_Coupon($value); $id=$action==='deleted' && !is_object($value) ? (int)$value : $coupon->get_id(); $data=array('coupon_id'=>(string)$id); if ($action!=='deleted' && $coupon->get_id()) { $data['code']=$coupon->get_code(); $data['discount_type']=$coupon->get_discount_type(); $data['amount']=(string)$coupon->get_amount(); $data['usage_count']=$action==='usage_changed' && is_numeric($count) ? (int)$count : (int)$coupon->get_usage_count(); } self::queue('woocommerce.coupon.' . $action,$id,$data); },2);
        }
        foreach (array('woocommerce_created_customer'=>'created','woocommerce_update_customer'=>'updated') as $hook=>$action) { self::hook($hook,function($id) use ($action) { $user=get_userdata($id); self::queue('woocommerce.customer.' . $action,$id,array('customer_id'=>(string)$id,'display_name'=>$user ? $user->display_name : '')); }); }
        foreach (array('added_comment_meta','updated_comment_meta','deleted_comment_meta') as $hook) { self::hook($hook,function($meta,$id,$key) {
            if ($key!=='rating' || isset(self::$createdComments[$id])) { return; }
            $comment=get_comment($id); if (!$comment || !self::is_review($comment)) { return; }
            self::queue('woocommerce.review.rating_changed',$id,function() use ($id,$comment) { return array('review_id'=>(string)$id,'product_id'=>(string)$comment->comment_post_ID,'rating'=>(int)get_comment_meta($id,'rating',true),'status'=>self::comment_state($comment->comment_approved)); });
        },3); }
    }
}
