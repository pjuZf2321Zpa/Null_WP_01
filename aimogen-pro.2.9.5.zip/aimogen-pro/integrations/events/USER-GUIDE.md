# Aimogen AI Automations: setup and first test

AI Automations lets a connected ChatGPT client react to activity on your WordPress site. Start with a notification when a post is published; once that works, ask for an SEO review, a restocking summary or another useful follow-up.

## What you need

- Updated copies of **Aimogen Pro** and the **Aimogen MCP Server extension**. Both contain parts of this feature.
- A public HTTPS WordPress site, preferably a staging site for your first test. ChatGPT cannot connect to your `localhost` address.
- A WordPress administrator account to configure events and approve the connection.
- A ChatGPT workspace that allows plugins and event-triggered tasks. Use **Work** on ChatGPT web, or **Work + Cloud** in the desktop app. [OpenAI event requirements](https://developers.openai.com/plugins/build/mcp-events).
- Working WordPress cron and hosting support for PHP cURL, OpenSSL and outbound HTTPS.

Turning on AI Automations exposes events. A watch begins when the connected client creates a subscription; selecting an event source alone does not start an automation.

## 1. Enable events in WordPress

Open **Aimogen → AI MCP Integration → Create Your MCP Server**.

1. Enable **Enable MCP server**. This master switch enables the MCP server, including its HTTP endpoint, and is required for AI Automations events.
2. Set **Transport** to **Both - legacy SSE and Streamable HTTP (recommended)** or **Streamable HTTP only**.
3. Enable **Sign-in (OAuth)** for the ChatGPT connection.
4. In **Aimogen AI Automations**, select **Enable AI Automations events** and **WordPress and Aimogen**. The events checkbox is available once the MCP server is on. If you turn the server off, the selected events preference is retained and an inactive warning appears.
5. Click **Save Settings**.

Keep other source packs and approved form fields as they are for this first test. The public post notification works with read-only MCP access. Commerce, private data and operation events can require the administrator Access Level; enable only the access needed for your chosen workflow.

The expandable **Setup and testing guide** on this page displays your site's server URL. It ends in `/wp-json/aiomatic-mcp/v1/http` on sites using the normal WordPress REST URL format; use the displayed URL rather than assembling it yourself.

## 2. Connect ChatGPT

In ChatGPT, enable Developer mode in **Settings → Security and login**, then use **Plugins → +** to create a personal plugin from the displayed server URL. Choose OAuth and complete the WordPress administrator sign-in/approval. Install the personal plugin and select it with `@` in a Work chat. [ChatGPT plugin quickstart](https://developers.openai.com/plugins/quickstart).

For an existing plugin, rescan the server to pick up its events. An OAuth connection created before this update may need disconnecting and reconnecting to establish a persistent watch. Check that the plugin's discovered events include `post.published`. [Connection and rescan instructions](https://developers.openai.com/plugins/deploy/connect-chatgpt).

Use the connection's authentication flow for credentials. The URL shown in the Automations guide contains no bearer token.

## 3. Run the first test

Select your site plugin in the Work chat and send:

> Use my Aimogen site to subscribe to post.published. Whenever a new post is published, reply in this chat with its title and link. Do not edit the site.

Return to the WordPress settings page using the account that approved the OAuth connection. Look below **Save Settings** for **AI Automations subscriptions**. Wait for an **active** `post.published` subscription before proceeding.

In **Posts → Add New**, create a draft titled **Aimogen automation test**, then publish it publicly through WordPress. Allow a few minutes for cron; visit a normal site page and refresh the settings page.

Check both results:

- WordPress shows `post.published: delivered` under **Recent event deliveries**.
- The subscribed ChatGPT chat receives the post's title and link.

Delivery status means the receiver acknowledged the event. ChatGPT's follow-up runs separately, so a delivery receipt alone does not prove that the requested task finished.

Existing published posts are not replayed when you create a watch. Saving an already-published post produces an update rather than another first publication. For this test, publish a new draft after the watch is active. Changes made through MCP tools are excluded by default to prevent feedback loops.

## 4. Check filters and stop the test

To test a narrower watch, ask ChatGPT to watch `post.published` for one specific post ID. Publish that draft, then another test draft with a different ID. Only the selected draft should reach that subscription. Stop the original broad watch first so its notifications do not confuse this check.

Ask ChatGPT:

> Stop monitoring post publications on my Aimogen site.

Confirm the matching subscription stops, then publish another test draft and check that it produces no delivery for that watch.

WordPress also provides **Pause**, **Resume** and **Stop** controls. Resume needs a still-valid subscription; ask ChatGPT to renew an expired watch. Events missed while stopped or paused are not replayed. Stop monitoring in ChatGPT too, so the client does not later create the watch again. Disabling **Enable AI Automations events** stops all site event subscriptions and clears retained payloads and signing secrets. Subscriptions normally expire after 24 hours unless renewed by the client.

## Useful automations after the first test

| Goal | Suggested prompt | WordPress setup / trigger |
| --- | --- | --- |
| SEO review | Whenever a post is published on my Aimogen site, check its SEO and report serious problems in this chat. | WordPress and Aimogen; publish a new draft. |
| Restocking | Watch woocommerce.product.low_stock for product ID 123 and prepare a restocking summary in this chat. | WooCommerce pack, WooCommerce active, stock management enabled. Replace 123. If the product's current low-stock threshold is 2, save stock at 3, then reduce it to 2. Staying below the threshold does not repeat the crossing event. |
| Review response | Watch woocommerce.review.created for ratings 1 or 2 and draft a response in this chat for my approval. | WooCommerce pack; submit a new rated review on a test product. Access Level must permit WooCommerce review events. |
| Form leads | Watch form.submitted for Contact Form 7 form 123. Use the approved company and message fields to summarize promising leads in this chat. | Forms pack and Contact Form 7 active. Replace 123 and approve the form's actual field names before subscribing. |

For the form example, enter `{"contactform7:123":["company","message"]}` in **Approved form fields**, replacing the ID and field names with your form's values, then save. Fields are excluded by default. Only approve information the automation needs; credential and payment field names cannot be approved.

Expand **Event catalog and examples** on the settings page for all 126 event definitions. A source marked unavailable needs its pack selected and, where applicable, its source plugin activated. The connected account's Access Level can further limit which events ChatGPT discovers.

## Troubleshooting

| What you see | What to check |
| --- | --- |
| Only tools appear in ChatGPT | Rescan the personal plugin after enabling events. Use a supported Work/Cloud chat and check workspace event permissions. Ordinary tool calls do not establish a watch. |
| No active subscription | Check the site's public HTTPS URL, updated MCP extension, OAuth approval and the ChatGPT subscription response. In WordPress, use the same account that approved the connection to view its subscriptions. |
| Active subscription, no delivery row | Check filters, selected source pack and trigger timing. Use a new public post after subscribing; make the change in WordPress for the first test. |
| `pending` | Cron may not have run yet, or a temporary callback failure is awaiting retry. Visit a site page and refresh. If it persists, ask your host to check WordPress cron and outbound HTTPS. |
| `failed` | Read the error beside the delivery. A callback verification failure prevents activation; `http_410` means the receiver no longer accepts the watch and `http_413` means the payload was refused. Ask the client to establish a fresh valid subscription after resolving the cause. |
| `cancelled` / `access_or_subscription_changed` | The watch, source, permission, credential or approved form fields changed. Recheck the settings and reconnect/subscribe if appropriate. |
| `expired` | Renew the subscription. Unsent deliveries expire after 24 hours; missed events are not replayed. |
| `delivered`, but no ChatGPT response | Check the subscribed chat's task state, instructions and any requested approval. WordPress delivery does not confirm completion of the AI action. |

## Testing on localhost

You can inspect settings and the catalog locally. The complete WordPress → ChatGPT → response test requires a public HTTPS staging site. Copy both updated plugins there and follow the steps above.

For developers, the [technical README](README.md#validation) includes CLI-only unit and isolated WordPress scenarios. The WordPress scenario requires empty event tables and uses a preserved pre-change MCP baseline plus simulated callbacks. These checks do not prove that a real ChatGPT account can subscribe or receive a notification. Site owners do not need Node/npm or a separate event service.
