<?php
/*
 * Aimogen AI Editor - AJAX endpoints.
 *
 * Uses admin-ajax with the plugin's established check_ajax_referer pattern rather
 * than a REST namespace, because the plugin's REST routes are an opt-in public API
 * with __return_true permission callbacks - the wrong place for post editing.
 *
 * Every handler runs the same gate: valid nonce, feature enabled, post exists, post
 * type supported, and current_user_can('edit_post', $post_id). Field identifiers are
 * resolved against a freshly built allow-list on each call.
 */

defined('ABSPATH') or die();

/**
 * Shared entry gate. Returns a WP_Post or sends a JSON error and exits.
 */
function aimogen_ai_editor_guard()
{
    check_ajax_referer(AIMOGEN_AI_EDITOR_NONCE, 'nonce');

    if (!aimogen_ai_editor_is_enabled()) {
        wp_send_json_error(array('message' => __('The Aimogen AI Editor is disabled.', 'aiomatic-automatic-ai-content-writer')), 403);
    }

    $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
    if ($post_id < 1) {
        wp_send_json_error(array('message' => __('Invalid post.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    $post = get_post($post_id);
    if (!($post instanceof WP_Post)) {
        wp_send_json_error(array('message' => __('Invalid post.', 'aiomatic-automatic-ai-content-writer')), 404);
    }
    if (!aimogen_ai_editor_supports_post_type($post->post_type)) {
        wp_send_json_error(array('message' => __('This post type is not supported.', 'aiomatic-automatic-ai-content-writer')), 400);
    }
    if (!current_user_can('edit_post', $post->ID)) {
        wp_send_json_error(array('message' => __('You are not allowed to edit this post.', 'aiomatic-automatic-ai-content-writer')), 403);
    }

    return $post;
}

/**
 * Instruction text is user-authored prose that ends up in a prompt, never in the
 * page or the database, so newlines are preserved and only tags are removed.
 */
function aimogen_ai_editor_clean_instruction($value)
{
    $value = wp_unslash((string) $value);
    $value = wp_strip_all_tags($value);
    $value = str_replace(array("\r\n", "\r"), "\n", $value);
    $value = trim($value);
    if (function_exists('mb_strlen') && mb_strlen($value, 'UTF-8') > 4000) {
        $value = mb_substr($value, 0, 4000, 'UTF-8');
    } elseif (strlen($value) > 4000) {
        $value = substr($value, 0, 4000);
    }
    return $value;
}

/**
 * Values coming from the open editor, used as the "current" value so unsaved work is
 * respected. Only the three core fields can be supplied this way; meta and ACF always
 * read from the database.
 */
function aimogen_ai_editor_read_editor_values()
{
    $out = array();
    if (!isset($_POST['editor_values']) || !is_array($_POST['editor_values'])) {
        return $out;
    }
    $allowed = array('post_title', 'post_content', 'post_excerpt');
    foreach ($allowed as $key) {
        if (isset($_POST['editor_values'][$key])) {
            $out[$key] = aimogen_ai_editor_normalize_newlines(wp_unslash((string) $_POST['editor_values'][$key]));
        }
    }
    return $out;
}

/**
 * Custom field keys the panel is asking to create on this post.
 *
 * Only the spelling of each key is taken from the browser. Whether any of them may be
 * written is decided by aimogen_ai_editor_admit_new_meta_keys().
 */
function aimogen_ai_editor_read_new_meta_keys()
{
    $out = array();
    if (!isset($_POST['new_fields']) || !is_array($_POST['new_fields'])) {
        return $out;
    }
    foreach ($_POST['new_fields'] as $key) {
        $key = sanitize_text_field(wp_unslash((string) $key));
        if ($key !== '' && !in_array($key, $out, true)) {
            $out[] = $key;
        }
        if (count($out) >= AIMOGEN_AI_EDITOR_MAX_FIELDS) {
            break;
        }
    }
    return $out;
}

/**
 * Build the target list from the submitted field ids.
 *
 * An id that does not resolve is reported, not silently dropped, so the user finds
 * out that a field disappeared rather than wondering why it was ignored.
 */
function aimogen_ai_editor_build_targets($post, $field_ids, $per_field, $editor_values, $new_keys = array())
{
    $admission = aimogen_ai_editor_admit_new_meta_keys(
        $post,
        $new_keys,
        aimogen_ai_editor_get_available_fields($post)
    );
    $available = $admission['fields'];
    $targets = array();
    $unknown = array();

    foreach ((array) $field_ids as $raw_id) {
        $field_id = sanitize_text_field(wp_unslash((string) $raw_id));
        $field = aimogen_ai_editor_resolve_field($post, $field_id, $available);
        if ($field === null) {
            $unknown[] = $field_id;
            continue;
        }

        $instruction = '';
        if (isset($per_field[$field['id']])) {
            $instruction = $per_field[$field['id']];
        }
        $instruction = aimogen_ai_editor_expand_placeholders($instruction, $post);

        $targets[] = array(
            'field'       => $field,
            'instruction' => $instruction,
            'current'     => aimogen_ai_editor_current_value($post, $field, $editor_values),
            /* Keep the database value separate from the live editor representation.
               TinyMCE and Gutenberg can normalize markup without changing meaning;
               stale-write protection must compare against what is actually stored. */
            'expected'    => aimogen_ai_editor_read_stored_value($post, $field),
        );
    }

    return array(
        'targets'   => $targets,
        'unknown'   => $unknown,
        'available' => $available,
        'rejected'  => $admission['rejected'],
    );
}

/**
 * The value the user is looking at right now: the editor's copy for core fields when
 * one was supplied, the stored value otherwise.
 */
function aimogen_ai_editor_current_value($post, $field, $editor_values)
{
    if ($field['kind'] === 'core' && isset($editor_values[$field['id']])) {
        return (string) $editor_values[$field['id']];
    }
    return aimogen_ai_editor_read_stored_value($post, $field);
}

function aimogen_ai_editor_read_per_field_instructions()
{
    $out = array();
    if (!isset($_POST['field_instructions']) || !is_array($_POST['field_instructions'])) {
        return $out;
    }
    foreach ($_POST['field_instructions'] as $field_id => $instruction) {
        $field_id = sanitize_text_field(wp_unslash((string) $field_id));
        $instruction = aimogen_ai_editor_clean_instruction($instruction);
        if ($field_id !== '' && $instruction !== '') {
            $out[$field_id] = $instruction;
        }
    }
    return $out;
}

/**
 * Generate proposed changes. Makes no database write of any kind.
 */
add_action('wp_ajax_aimogen_ai_editor_generate', 'aimogen_ai_editor_ajax_generate');
function aimogen_ai_editor_ajax_generate()
{
    $post = aimogen_ai_editor_guard();

    $field_ids = isset($_POST['fields']) && is_array($_POST['fields']) ? $_POST['fields'] : array();
    if (empty($field_ids)) {
        wp_send_json_error(array('message' => __('Select at least one field to edit.', 'aiomatic-automatic-ai-content-writer')), 400);
    }
    if (count($field_ids) > AIMOGEN_AI_EDITOR_MAX_FIELDS) {
        wp_send_json_error(array('message' => __('Too many fields were selected.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    $general = aimogen_ai_editor_clean_instruction(isset($_POST['instruction']) ? $_POST['instruction'] : '');
    $general = aimogen_ai_editor_expand_placeholders($general, $post);
    $per_field = aimogen_ai_editor_read_per_field_instructions();

    if ($general === '' && empty($per_field)) {
        wp_send_json_error(array('message' => __('Enter an instruction, or pick a preset or saved template.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    $use_context = !isset($_POST['use_context']) || $_POST['use_context'] === '1' || $_POST['use_context'] === 'true';
    $editor_values = aimogen_ai_editor_read_editor_values();

    $built = aimogen_ai_editor_build_targets($post, $field_ids, $per_field, $editor_values, aimogen_ai_editor_read_new_meta_keys());
    if (empty($built['targets'])) {
        $reason = !empty($built['rejected'])
            ? implode(' ', $built['rejected'])
            : __('None of the selected fields are available for editing.', 'aiomatic-automatic-ai-content-writer');
        wp_send_json_error(array('message' => $reason), 400);
    }

    $overrides = array();
    if (!empty($_POST['model'])) {
        $overrides['model'] = sanitize_text_field(wp_unslash((string) $_POST['model']));
    }
    if (isset($_POST['temperature']) && $_POST['temperature'] !== '') {
        $overrides['temperature'] = floatval(wp_unslash((string) $_POST['temperature']));
    }

    $result = aimogen_ai_editor_generate($post, $built['targets'], $general, $use_context, $editor_values, $overrides);
    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()), 200);
    }

    foreach ($built['unknown'] as $unknown_id) {
        $result['errors'][$unknown_id] = __('This field is no longer available.', 'aiomatic-automatic-ai-content-writer');
    }
    foreach ($built['rejected'] as $rejected_id => $reason) {
        $result['errors'][$rejected_id] = $reason;
    }

    /* Proposals carry raw field values, including HTML. They are transported as JSON
       and rendered with textContent on the client, so they are not escaped here - the
       review UI must show exactly what would be written. */
    wp_send_json_success(array(
        'proposals' => array_values($result['proposals']),
        'errors'    => $result['errors'],
        'model'     => $result['model'],
    ));
}

/**
 * Regenerate a single field, leaving every other proposal alone.
 */
add_action('wp_ajax_aimogen_ai_editor_regenerate', 'aimogen_ai_editor_ajax_regenerate');
function aimogen_ai_editor_ajax_regenerate()
{
    $post = aimogen_ai_editor_guard();

    $field_id = isset($_POST['field']) ? sanitize_text_field(wp_unslash((string) $_POST['field'])) : '';
    if ($field_id === '') {
        wp_send_json_error(array('message' => __('No field was specified.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    $general = aimogen_ai_editor_clean_instruction(isset($_POST['instruction']) ? $_POST['instruction'] : '');
    $general = aimogen_ai_editor_expand_placeholders($general, $post);
    $per_field = aimogen_ai_editor_read_per_field_instructions();
    if ($general === '' && empty($per_field)) {
        wp_send_json_error(array('message' => __('Enter an instruction first.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    $use_context = !isset($_POST['use_context']) || $_POST['use_context'] === '1' || $_POST['use_context'] === 'true';
    $editor_values = aimogen_ai_editor_read_editor_values();

    $built = aimogen_ai_editor_build_targets($post, array($field_id), $per_field, $editor_values, aimogen_ai_editor_read_new_meta_keys());
    if (empty($built['targets'])) {
        $reason = !empty($built['rejected'])
            ? implode(' ', $built['rejected'])
            : __('This field is not available for editing.', 'aiomatic-automatic-ai-content-writer');
        wp_send_json_error(array('message' => $reason), 400);
    }

    $overrides = array();
    if (!empty($_POST['model'])) {
        $overrides['model'] = sanitize_text_field(wp_unslash((string) $_POST['model']));
    }
    if (isset($_POST['temperature']) && $_POST['temperature'] !== '') {
        $overrides['temperature'] = floatval(wp_unslash((string) $_POST['temperature']));
    }

    $result = aimogen_ai_editor_generate($post, $built['targets'], $general, $use_context, $editor_values, $overrides);
    if (is_wp_error($result)) {
        wp_send_json_error(array('message' => $result->get_error_message()), 200);
    }

    if (empty($result['proposals'])) {
        $message = isset($result['errors'][$field_id])
            ? $result['errors'][$field_id]
            : __('The AI did not return a new value for this field.', 'aiomatic-automatic-ai-content-writer');
        wp_send_json_error(array('message' => $message), 200);
    }

    $proposals = array_values($result['proposals']);
    wp_send_json_success(array('proposal' => $proposals[0]));
}

/**
 * Apply accepted changes.
 *
 * The interactive client sets write_core after confirming that the open edit screen
 * has no unsaved work. This lets title/content/excerpt and custom fields be persisted
 * in one request before the browser reloads from the authoritative database values.
 */
add_action('wp_ajax_aimogen_ai_editor_apply', 'aimogen_ai_editor_ajax_apply');
function aimogen_ai_editor_ajax_apply()
{
    $post = aimogen_ai_editor_guard();

    if (!isset($_POST['changes']) || !is_array($_POST['changes'])) {
        wp_send_json_error(array('message' => __('No changes were submitted.', 'aiomatic-automatic-ai-content-writer')), 400);
    }
    if (count($_POST['changes']) > AIMOGEN_AI_EDITOR_MAX_FIELDS) {
        wp_send_json_error(array('message' => __('Too many changes were submitted.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    $changes = array();
    foreach ($_POST['changes'] as $field_id => $value) {
        $field_id = sanitize_text_field(wp_unslash((string) $field_id));
        if ($field_id === '') {
            continue;
        }
        $changes[$field_id] = aimogen_ai_editor_normalize_newlines(wp_unslash((string) $value));
    }
    if (empty($changes)) {
        wp_send_json_error(array('message' => __('No changes were submitted.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    if (!isset($_POST['expected']) || !is_array($_POST['expected']) ||
        count($_POST['expected']) > AIMOGEN_AI_EDITOR_MAX_FIELDS) {
        wp_send_json_error(array('message' => __('This review is missing its original field values. Reload the page and generate the changes again.', 'aiomatic-automatic-ai-content-writer')), 409);
    }
    $expected = array();
    foreach ($_POST['expected'] as $field_id => $value) {
        $field_id = sanitize_text_field(wp_unslash((string) $field_id));
        if ($field_id !== '' && array_key_exists($field_id, $changes)) {
            $expected[$field_id] = aimogen_ai_editor_normalize_newlines(wp_unslash((string) $value));
        }
    }
    foreach ($changes as $field_id => $value) {
        if (!array_key_exists($field_id, $expected)) {
            wp_send_json_error(array('message' => __('This review is missing its original field values. Reload the page and generate the changes again.', 'aiomatic-automatic-ai-content-writer')), 409);
        }
    }

    $write_core = isset($_POST['write_core']) && ($_POST['write_core'] === '1' || $_POST['write_core'] === 'true');

    $result = aimogen_ai_editor_apply_changes($post, $changes, $write_core, $expected, aimogen_ai_editor_read_new_meta_keys());
    if (is_wp_error($result)) {
        $data = $result->get_error_data();
        $status = (is_array($data) && isset($data['status'])) ? (int) $data['status'] : 200;
        wp_send_json_error(array('message' => $result->get_error_message()), $status);
    }

    wp_send_json_success($result);
}

/**
 * Undo the most recent Aimogen application on this post.
 */
add_action('wp_ajax_aimogen_ai_editor_undo', 'aimogen_ai_editor_ajax_undo');
function aimogen_ai_editor_ajax_undo()
{
    $post = aimogen_ai_editor_guard();

    $result = aimogen_ai_editor_undo_last($post);
    if (is_wp_error($result)) {
        $data = $result->get_error_data();
        $status = (is_array($data) && isset($data['status'])) ? (int) $data['status'] : 200;
        wp_send_json_error(array('message' => $result->get_error_message()), $status);
    }

    wp_send_json_success($result);
}

/**
 * Model list for Advanced Settings.
 *
 * Deliberately lazy: aiomatic_get_all_models() queries OpenRouter and Ollama over the
 * network, which is far too expensive to run on every post edit screen load.
 */
add_action('wp_ajax_aimogen_ai_editor_models', 'aimogen_ai_editor_ajax_models');
function aimogen_ai_editor_ajax_models()
{
    aimogen_ai_editor_guard();

    $models = function_exists('aiomatic_get_all_models') ? aiomatic_get_all_models(true) : array();
    if (!is_array($models)) {
        $models = array();
    }
    $models = array_values(array_unique(array_filter(array_map('strval', $models))));

    $settings = aimogen_ai_editor_resolve_generation_settings();

    wp_send_json_success(array(
        'models'  => $models,
        'current' => $settings['model'],
        'temperature' => $settings['temperature'],
    ));
}

/**
 * Load a saved AI Content Editor template's instructions into the panel.
 */
add_action('wp_ajax_aimogen_ai_editor_template', 'aimogen_ai_editor_ajax_template');
function aimogen_ai_editor_ajax_template()
{
    $post = aimogen_ai_editor_guard();

    $template_id = isset($_POST['template_id']) ? absint($_POST['template_id']) : 0;
    if ($template_id < 1) {
        wp_send_json_error(array('message' => __('Invalid template.', 'aiomatic-automatic-ai-content-writer')), 400);
    }

    $template = get_post($template_id);
    if (!($template instanceof WP_Post) || $template->post_type !== 'aiomatic_editor_temp') {
        wp_send_json_error(array('message' => __('Template not found.', 'aiomatic-automatic-ai-content-writer')), 404);
    }

    $data = aimogen_ai_editor_decode_template($template_id);
    if (empty($data)) {
        wp_send_json_error(array('message' => __('This template has no stored instructions.', 'aiomatic-automatic-ai-content-writer')), 200);
    }

    $instructions = aimogen_ai_editor_template_instructions($data);

    /* Only report per-field instructions for fields that exist on THIS post, so a
       template written for a different post type does not offer phantom fields. */
    $available = aimogen_ai_editor_get_available_fields($post);
    $per_field = array();
    foreach ($instructions['perField'] as $field_id => $instruction) {
        if (isset($available[$field_id])) {
            $per_field[$field_id] = $instruction;
        }
    }

    wp_send_json_success(array(
        'general'  => $instructions['general'],
        'perField' => $per_field,
        'label'    => get_the_title($template_id),
    ));
}

/**
 * Run a whole saved AI Content Editor template against this post.
 *
 * This is the legacy automation path, kept because a template does far more than the
 * review workflow above: featured and in-content images, categories and tags, SEO
 * fields, slug, post status and date, Elementor data, internal links. aiomatic_do_post()
 * generates and writes in a single pass and has never had a preview stage, so there is
 * deliberately no accept/reject step here - the UI says so plainly.
 *
 * Passing 'skip' as the template makes the engine fall back to the currently saved
 * configuration, which is what the old "Use currently saved configuration" option did.
 */
add_action('wp_ajax_aimogen_ai_editor_run_template', 'aimogen_ai_editor_ajax_run_template');
function aimogen_ai_editor_ajax_run_template()
{
    $post = aimogen_ai_editor_guard();

    if (!function_exists('aiomatic_do_post')) {
        wp_send_json_error(array('message' => __('The Aimogen editing engine is unavailable.', 'aiomatic-automatic-ai-content-writer')), 200);
    }

    $template_id = isset($_POST['template_id']) ? absint($_POST['template_id']) : 0;
    $template = 'skip';
    $label = __('currently saved configuration', 'aiomatic-automatic-ai-content-writer');

    if ($template_id > 0) {
        $template_post = get_post($template_id);
        if (!($template_post instanceof WP_Post) || $template_post->post_type !== 'aiomatic_editor_temp') {
            wp_send_json_error(array('message' => __('Template not found.', 'aiomatic-automatic-ai-content-writer')), 404);
        }
        $template = $template_id;
        $label = get_the_title($template_id);
    }

    $before = array(
        'title'   => $post->post_title,
        'content' => $post->post_content,
        'excerpt' => $post->post_excerpt,
    );

    /* The engine logs rather than prints, but a notice from any hooked third-party
       code would corrupt the JSON response, so anything emitted is swallowed. */
    ob_start();
    aiomatic_do_post($post, true, $template, false);
    $stray = ob_get_clean();
    if ($stray !== '' && $stray !== false) {
        aiomatic_log_to_file('[AI Editor] Template run produced unexpected output: ' . substr($stray, 0, 500));
    }

    clean_post_cache($post->ID);
    $after = get_post($post->ID);
    if (!($after instanceof WP_Post)) {
        wp_send_json_error(array('message' => __('The post could not be reloaded after processing.', 'aiomatic-automatic-ai-content-writer')), 200);
    }

    $changed = (
        $after->post_title !== $before['title'] ||
        $after->post_content !== $before['content'] ||
        $after->post_excerpt !== $before['excerpt'] ||
        aimogen_ai_editor_is_marked_edited($post->ID)
    );

    wp_send_json_success(array(
        'label'   => $label,
        'changed' => $changed,
        'marked'  => aimogen_ai_editor_is_marked_edited($post->ID),
    ));
}

/**
 * Flip the "already edited by Aimogen" marker.
 *
 * Carried over from the old Gutenberg sidebar so that removing it costs no
 * functionality. The marker is what stops scheduled runs re-editing a post.
 */
add_action('wp_ajax_aimogen_ai_editor_toggle_marker', 'aimogen_ai_editor_ajax_toggle_marker');
function aimogen_ai_editor_ajax_toggle_marker()
{
    $post = aimogen_ai_editor_guard();

    $state = aimogen_ai_editor_toggle_marker($post->ID);

    wp_send_json_success(array(
        'marked' => ($state === 'pub'),
        'key'    => aimogen_ai_editor_marker_meta_key(),
    ));
}
