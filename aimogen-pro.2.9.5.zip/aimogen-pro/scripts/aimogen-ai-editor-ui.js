"use strict";
/*
 * Aimogen AI Editor - panel rendering.
 *
 * Plain DOM so the same markup mounts inside a classic metabox and inside a Gutenberg
 * PluginSidebar without pulling in a second rendering stack.
 *
 * Proposed values are inserted with textContent, never innerHTML: generated content is
 * arbitrary HTML and must be shown as text in the review pane, not executed. The one
 * exception is the server-rendered diff, which comes from WordPress's own
 * wp_text_diff() and is inserted as markup so it keeps the admin's diff styling.
 */
(function (window, document) {

    var api = window.AimogenAiEditor;
    if (!api) {
        return;
    }

    var boot = api.boot;
    var t = boot.i18n || {};
    var storagePrefix = 'aimogen-ai-editor:' + String(boot.postId || 0) + ':';
    var storageLifetime = 30 * 60 * 1000;
    var persistedStateKeys = [
        'selected',
        'perField',
        'perFieldOpen',
        'newFields',
        'instruction',
        'presetId',
        'templateId',
        'useContext',
        'model',
        'temperature',
        'advancedOpen',
        'proposals',
        'decisions',
        'rebaseExpected',
        'resume'
    ];

    /*
     * sessionStorage is deliberately used instead of localStorage. A pending review
     * belongs to this browser tab and this post only; another tab must not inherit it.
     * Storage can be disabled or full, so every operation is allowed to fail safely.
     */
    function writeStoredValue(name, value) {
        try {
            if (!window.sessionStorage) {
                return false;
            }
            window.sessionStorage.setItem(storagePrefix + name, JSON.stringify({
                expires: Date.now() + storageLifetime,
                value: value
            }));
            return true;
        } catch (error) {
            return false;
        }
    }

    function removeStoredValue(name) {
        try {
            if (window.sessionStorage) {
                window.sessionStorage.removeItem(storagePrefix + name);
            }
        } catch (error) {
            // Storage is an optional recovery aid; applying changes must not depend on it.
        }
    }

    function consumeStoredValue(name) {
        var raw;
        var parsed;
        try {
            if (!window.sessionStorage) {
                return null;
            }
            raw = window.sessionStorage.getItem(storagePrefix + name);
            if (!raw) {
                return null;
            }
            window.sessionStorage.removeItem(storagePrefix + name);
            parsed = JSON.parse(raw);
        } catch (error) {
            removeStoredValue(name);
            return null;
        }

        if (!parsed || typeof parsed !== 'object' ||
            typeof parsed.expires !== 'number' || parsed.expires < Date.now()) {
            return null;
        }
        return parsed.value;
    }

    function persistPanelState(state, overrides) {
        var saved = {};
        var source = overrides || {};

        persistedStateKeys.forEach(function (key) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
                saved[key] = source[key];
            } else {
                saved[key] = state[key];
            }
        });
        return writeStoredValue('pending', saved);
    }

    /*
     * A field row for a custom field that is not on the post yet.
     *
     * The server's field list can only describe keys that already exist, so the panel
     * builds this one itself to have something to tick. It is a display row and
     * nothing more: the server decides, on every request, whether the key may be
     * written at all.
     */
    function newFieldRow(key) {
        var label = String(key).replace(/[_-]+/g, ' ').trim();
        return {
            id: 'meta:' + key,
            key: key,
            label: label === '' ? key : label.charAt(0).toUpperCase() + label.slice(1),
            group: 'meta',
            format: 'text',
            inEditor: false,
            preview: '',
            empty: true,
            isNew: true
        };
    }

    function isRecord(value) {
        return !!value && typeof value === 'object' && !Array.isArray(value);
    }

    function isValidPersistedStateValue(key, value) {
        if (key === 'selected' || key === 'perField' || key === 'perFieldOpen' ||
            key === 'decisions' || key === 'rebaseExpected' || key === 'newFields') {
            return isRecord(value);
        }
        if (key === 'instruction' || key === 'presetId' || key === 'templateId' || key === 'model') {
            return typeof value === 'string';
        }
        if (key === 'useContext' || key === 'advancedOpen') {
            return typeof value === 'boolean';
        }
        if (key === 'temperature') {
            return typeof value === 'string' || typeof value === 'number';
        }
        if (key === 'resume') {
            return value === 'apply' || value === 'undo';
        }
        if (key === 'proposals') {
            return Array.isArray(value) && value.every(function (proposal) {
                return isRecord(proposal) && typeof proposal.id === 'string' &&
                    typeof proposal.proposed === 'string';
            });
        }
        return false;
    }

    /*
     * Returns 'apply' or 'undo' when the review was parked for a save that had to go
     * through a page reload, so the caller can finish what the user already asked for.
     */
    function restorePanelState(state) {
        var saved = consumeStoredValue('pending');
        if (!saved || typeof saved !== 'object') {
            return null;
        }

        persistedStateKeys.forEach(function (key) {
            if (key === 'rebaseExpected' || key === 'resume') {
                return;
            }
            if (Object.prototype.hasOwnProperty.call(saved, key) &&
                isValidPersistedStateValue(key, saved[key])) {
                state[key] = saved[key];
            }
        });
        if (isValidPersistedStateValue('rebaseExpected', saved.rebaseExpected) &&
            Array.isArray(state.proposals)) {
            state.proposals.forEach(function (proposal) {
                if (proposal && Object.prototype.hasOwnProperty.call(saved.rebaseExpected, proposal.id)) {
                    proposal.expected = saved.rebaseExpected[proposal.id];
                }
            });
        }
        state.status = Array.isArray(state.proposals) && state.proposals.length ? 'generated' : 'idle';
        state.busyField = '';

        return isValidPersistedStateValue('resume', saved.resume) ? saved.resume : null;
    }

    function restoreFlashMessage(state) {
        var flash = consumeStoredValue('flash');
        if (!flash || typeof flash !== 'object' || typeof flash.message !== 'string') {
            return;
        }
        state.message = flash.message;
        state.messageKind = typeof flash.kind === 'string' ? flash.kind : 'info';
    }

    function beginCommit(message, options) {
        if (api.editor && typeof api.editor.beginCommit === 'function') {
            api.editor.beginCommit(message || t.committingChanges, options);
        }
    }

    /*
     * Compare two versions of the same field, ignoring line endings.
     *
     * One copy can arrive as LF from the block editor's store and the other as CRLF
     * from a form control or a multipart round trip; that difference says nothing
     * about whether anyone actually edited the text.
     */
    function sameText(left, right) {
        function normalize(value) {
            var text = String(value === null || value === undefined ? '' : value);
            return text.split('\r\n').join('\n').split('\r').join('\n');
        }
        return normalize(left) === normalize(right);
    }

    /*
     * Move stale-write baselines onto a post that Aimogen has just saved.
     *
     * The server refuses to apply a proposal when the stored value is no longer the
     * one the proposal was generated from. Saving the editor deliberately changes that
     * stored value, so for the fields the save just wrote the baseline has to move
     * with it - but only where the text that was saved is the same text the proposal
     * was generated from. If the user carried on typing after generating, the baseline
     * stays put and the server drops the field as stale, which is the whole point of
     * the check.
     *
     * `stored` is what the server echoed back after the save and is preferred, since
     * save filters can normalize markup on the way in; without it the editor's own
     * copy is the best available baseline.
     */
    function rebaseAfterSave(proposals, live, stored, clean) {
        var rebased = {};
        if (!clean || !live) {
            return rebased;
        }
        proposals.forEach(function (proposal) {
            if (!proposal.inEditor || !Object.prototype.hasOwnProperty.call(live, proposal.id)) {
                return;
            }
            if (!sameText(live[proposal.id], proposal.current)) {
                return;
            }
            rebased[proposal.id] = (stored && Object.prototype.hasOwnProperty.call(stored, proposal.id))
                ? stored[proposal.id]
                : proposal.current;
        });
        return rebased;
    }

    function endCommit() {
        if (api.editor && typeof api.editor.endCommit === 'function') {
            api.editor.endCommit();
        }
    }

    function el(tag, attrs, children) {
        var node = document.createElement(tag);
        if (attrs) {
            Object.keys(attrs).forEach(function (key) {
                if (key === 'class') {
                    node.className = attrs[key];
                } else if (key === 'text') {
                    node.textContent = attrs[key];
                } else if (key.indexOf('on') === 0 && typeof attrs[key] === 'function') {
                    node.addEventListener(key.slice(2).toLowerCase(), attrs[key]);
                } else if (attrs[key] === true) {
                    node.setAttribute(key, key);
                } else if (attrs[key] !== false && attrs[key] !== null && attrs[key] !== undefined) {
                    node.setAttribute(key, attrs[key]);
                }
            });
        }
        (children || []).forEach(function (child) {
            if (child === null || child === undefined || child === false) {
                return;
            }
            node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
        });
        return node;
    }

    function Panel(root) {
        this.root = root;
        this.state = api.createState();
        this.fields = boot.fields || [];
        var resume = restorePanelState(this.state);
        this.adoptNewFields();
        restoreFlashMessage(this.state);
        this.render();
        this.resume(resume);
    }

    /*
     * Finish an operation that had to send the classic editor through a save reload.
     *
     * The stored flag is written immediately before the form is submitted and is
     * consumed by the restore that just ran, so it can fire at most once per submit.
     * This deliberately calls the send* methods rather than apply()/undo(): those
     * would re-run the dirty check, and a screen that still looked dirty here would
     * submit the form again and loop. The user has already saved - that reload is why
     * we are here - so the request goes straight out, and if the server refuses it,
     * it refuses visibly in the panel.
     */
    Panel.prototype.resume = function (resume) {
        var self = this;
        if (resume !== 'apply' && resume !== 'undo') {
            return;
        }

        /* Let the editor and its metaboxes finish booting before touching them. */
        window.setTimeout(function () {
            if (resume === 'undo') {
                self.sendUndo();
                return;
            }
            var accepted = self.state.proposals.filter(function (proposal) {
                return self.state.decisions[proposal.id] === 'accepted';
            });
            if (accepted.length) {
                self.sendApply(accepted, {});
            }
        }, 0);
    };

    /*
     * Put back the rows for keys the user added by hand before a reload.
     *
     * Once a key has actually been written it comes back in the server's own field
     * list, and the panel forgets it was ever a pending addition.
     */
    Panel.prototype.adoptNewFields = function () {
        var self = this;
        var pending = this.state.newFields || {};

        Object.keys(pending).forEach(function (id) {
            var known = self.fields.some(function (field) { return field.id === id; });
            if (known) {
                delete self.state.newFields[id];
                return;
            }
            self.fields.push(newFieldRow(pending[id]));
        });
    };

    Panel.prototype.setState = function (patch) {
        var self = this;
        Object.keys(patch).forEach(function (key) {
            self.state[key] = patch[key];
        });
        this.render();
    };

    Panel.prototype.notify = function (message, kind) {
        this.setState({ message: message || '', messageKind: kind || 'info' });
    };

    Panel.prototype.render = function () {
        var scrollTop = this.root.scrollTop;
        this.root.textContent = '';
        /* The container's class is set once when it is created. Assigning className
           here would wipe whatever the host put on the element - the --metabox
           modifier in the classic editor, or React's own class in the sidebar. */
        this.root.appendChild(this.renderComposer());
        if (this.state.proposals.length) {
            this.root.appendChild(this.renderReview());
        }
        if (this.state.message) {
            this.root.appendChild(this.renderMessage());
        }
        this.root.appendChild(this.renderTemplateRunner());
        this.root.appendChild(this.renderFooter());
        this.root.scrollTop = scrollTop;
    };

    /* ---------------------------------------------------------------- composer */

    Panel.prototype.renderComposer = function () {
        var self = this;
        var state = this.state;
        var busy = (state.status === 'generating' || state.status === 'applying');

        var groups = { core: [], acf: [], meta: [] };
        this.fields.forEach(function (field) {
            (groups[field.group] || groups.meta).push(field);
        });

        var sections = [];
        if (groups.core.length) {
            sections.push(this.renderFieldGroup(t.coreFields, groups.core));
        }
        if (groups.acf.length) {
            sections.push(this.renderFieldGroup(t.acfFields, groups.acf));
        }
        if (groups.meta.length) {
            sections.push(this.renderFieldGroup(t.metaFields, groups.meta));
        }
        if (!groups.acf.length && !groups.meta.length) {
            sections.push(el('p', { class: 'aimogen-ai-editor__hint', text: t.noCustomFields }));
        }
        sections.push(this.renderNewField(busy));

        var presetButtons = (boot.presets || []).map(function (preset) {
            return el('button', {
                type: 'button',
                class: 'aimogen-ai-editor__chip' + (state.presetId === preset.id ? ' is-active' : ''),
                disabled: busy,
                onClick: function () {
                    self.setState({
                        presetId: preset.id,
                        instruction: preset.instruction || state.instruction
                    });
                }
            }, [preset.label]);
        });

        var instructionBox = el('textarea', {
            class: 'aimogen-ai-editor__instruction',
            rows: 3,
            placeholder: t.instructionHint,
            disabled: busy,
            onInput: function (event) {
                /* Not routed through setState: re-rendering on every keystroke would
                   lose the caret position. */
                state.instruction = event.target.value;
            }
        });
        instructionBox.value = state.instruction;

        var children = [
            el('h3', { class: 'aimogen-ai-editor__heading', text: t.whatToChange })
        ].concat(sections).concat([
            el('div', { class: 'aimogen-ai-editor__block' }, [
                el('label', { class: 'aimogen-ai-editor__label', text: t.instruction }),
                el('div', { class: 'aimogen-ai-editor__chips' }, presetButtons),
                instructionBox
            ]),
            this.renderTemplatePicker(busy),
            this.renderAdvanced(busy),
            el('div', { class: 'aimogen-ai-editor__actions' }, [
                el('button', {
                    type: 'button',
                    class: 'button button-primary button-large aimogen-ai-editor__generate',
                    disabled: busy,
                    onClick: function () { self.generate(); }
                }, [state.status === 'generating' ? t.generating : t.generate]),
                state.status === 'generating' ? el('span', { class: 'spinner is-active' }) : null
            ])
        ]);

        return el('div', { class: 'aimogen-ai-editor__composer' }, children);
    };

    Panel.prototype.renderFieldGroup = function (title, fields) {
        var self = this;
        var state = this.state;
        var busy = (state.status === 'generating' || state.status === 'applying');

        var rows = fields.map(function (field) {
            var checkbox = el('input', {
                type: 'checkbox',
                id: 'aimogen-field-' + encodeURIComponent(field.id),
                disabled: busy,
                onChange: function (event) {
                    if (event.target.checked) {
                        state.selected[field.id] = true;
                    } else {
                        delete state.selected[field.id];
                        delete state.perFieldOpen[field.id];
                    }
                    self.render();
                }
            });
            checkbox.checked = !!state.selected[field.id];

            var meta = [];
            if (field.key && field.key !== field.label && field.group !== 'core') {
                meta.push(el('code', { class: 'aimogen-ai-editor__key', text: field.key }));
            }
            if (field.isNew) {
                meta.push(el('span', { class: 'aimogen-ai-editor__badge', text: t.newFieldBadge }));
            } else if (field.empty) {
                meta.push(el('span', { class: 'aimogen-ai-editor__badge', text: t.emptyValue }));
            }
            if (field.isNew) {
                meta.push(el('button', {
                    type: 'button',
                    class: 'button-link aimogen-ai-editor__field-remove',
                    disabled: busy,
                    title: t.newFieldRemove,
                    'aria-label': t.newFieldRemove,
                    onClick: function (event) {
                        event.preventDefault();
                        self.removeNewField(field.id);
                    }
                }, ['\u00d7']));
            }

            var row = el('div', { class: 'aimogen-ai-editor__field' }, [
                el('label', { class: 'aimogen-ai-editor__field-label', for: checkbox.id }, [
                    checkbox,
                    el('span', { class: 'aimogen-ai-editor__field-name', text: field.label })
                ].concat(meta)),
                field.preview ? el('p', { class: 'aimogen-ai-editor__preview', text: field.preview }) : null
            ]);

            if (state.selected[field.id]) {
                row.appendChild(self.renderPerFieldInstruction(field, busy));
            }

            return row;
        });

        return el('div', { class: 'aimogen-ai-editor__group' }, [
            el('h4', { class: 'aimogen-ai-editor__group-title', text: title })
        ].concat(rows));
    };

    /*
     * Add a custom field the post does not have yet.
     *
     * Field discovery lists what is stored, which leaves no way to fill in a key that
     * has never been set. Naming it here adds a row to tick like any other; the key
     * travels with every request and is re-checked server side each time, so this box
     * grants no access that ticking an existing row would not.
     */
    Panel.prototype.renderNewField = function (busy) {
        var self = this;
        var state = this.state;

        var input = el('input', {
            type: 'text',
            class: 'aimogen-ai-editor__new-field-key',
            placeholder: t.newFieldPlaceholder,
            disabled: busy,
            onInput: function (event) {
                /* Not routed through setState: re-rendering would lose the caret. */
                state.newFieldKey = event.target.value;
            },
            onKeydown: function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    self.addNewField();
                }
            }
        });
        input.value = state.newFieldKey || '';

        return el('div', { class: 'aimogen-ai-editor__group' }, [
            el('h4', { class: 'aimogen-ai-editor__group-title', text: t.newFieldTitle }),
            el('div', { class: 'aimogen-ai-editor__new-field' }, [
                input,
                el('button', {
                    type: 'button',
                    class: 'button',
                    disabled: busy,
                    onClick: function () { self.addNewField(); }
                }, [t.newFieldAdd])
            ]),
            el('p', { class: 'aimogen-ai-editor__hint', text: t.newFieldHint })
        ]);
    };

    Panel.prototype.addNewField = function () {
        var state = this.state;
        var key = String(state.newFieldKey || '').trim();
        if (key === '') {
            return;
        }
        /* The same shape the server insists on, checked here only so an obvious typo
           is answered immediately instead of after a round trip. */
        if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(key)) {
            this.notify(t.newFieldInvalid, 'error');
            return;
        }

        var id = 'meta:' + key;
        var known = this.fields.some(function (field) { return field.id === id; });

        state.newFieldKey = '';
        state.selected[id] = true;
        if (!known) {
            this.fields.push(newFieldRow(key));
            state.newFields[id] = key;
        }
        this.setState({ message: known ? t.newFieldExists : '', messageKind: 'info' });
    };

    Panel.prototype.removeNewField = function (id) {
        var state = this.state;
        this.fields = this.fields.filter(function (field) { return field.id !== id; });
        delete state.newFields[id];
        delete state.selected[id];
        delete state.perField[id];
        delete state.perFieldOpen[id];
        this.render();
    };

    /*
     * Per-field instruction. Collapsed by default so the common case stays one
     * instruction box, but available for the case the feature exists for: different
     * fields on the same post genuinely want different instructions.
     */
    Panel.prototype.renderPerFieldInstruction = function (field, busy) {
        var self = this;
        var state = this.state;

        if (!state.perFieldOpen[field.id] && !state.perField[field.id]) {
            return el('button', {
                type: 'button',
                class: 'aimogen-ai-editor__link',
                disabled: busy,
                onClick: function () {
                    state.perFieldOpen[field.id] = true;
                    self.render();
                }
            }, ['+ ' + t.perFieldAdd]);
        }

        var box = el('textarea', {
            class: 'aimogen-ai-editor__instruction aimogen-ai-editor__instruction--field',
            rows: 2,
            placeholder: t.perFieldHint,
            disabled: busy,
            onInput: function (event) {
                state.perField[field.id] = event.target.value;
            }
        });
        box.value = state.perField[field.id] || '';

        return el('div', { class: 'aimogen-ai-editor__override' }, [box]);
    };

    Panel.prototype.renderTemplatePicker = function (busy) {
        var self = this;
        var templates = boot.templates || [];
        if (!templates.length) {
            return null;
        }

        var select = el('select', {
            class: 'aimogen-ai-editor__select',
            disabled: busy,
            onChange: function (event) {
                self.loadTemplate(event.target.value);
            }
        }, [el('option', { value: '', text: t.noTemplate })].concat(
            templates.map(function (template) {
                return el('option', { value: String(template.id), text: template.label });
            })
        ));
        select.value = this.state.templateId;

        return el('div', { class: 'aimogen-ai-editor__block' }, [
            el('label', { class: 'aimogen-ai-editor__label', text: t.useTemplate }),
            select
        ]);
    };

    Panel.prototype.renderAdvanced = function (busy) {
        var self = this;
        var state = this.state;

        var toggle = el('button', {
            type: 'button',
            class: 'aimogen-ai-editor__disclosure',
            'aria-expanded': state.advancedOpen ? 'true' : 'false',
            onClick: function () {
                var opening = !state.advancedOpen;
                state.advancedOpen = opening;
                self.render();
                if (opening && state.models === null) {
                    self.loadModels();
                }
            }
        }, [t.advanced + (state.advancedOpen ? ' ▴' : ' ▾')]);

        if (!state.advancedOpen) {
            return el('div', { class: 'aimogen-ai-editor__block' }, [toggle]);
        }

        var contextBox = el('input', {
            type: 'checkbox',
            id: 'aimogen-ai-editor-context',
            disabled: busy,
            onChange: function (event) {
                state.useContext = event.target.checked;
            }
        });
        contextBox.checked = state.useContext;

        var modelSelect;
        if (state.models === null) {
            modelSelect = el('p', { class: 'aimogen-ai-editor__hint', text: t.loadingModels });
        } else {
            modelSelect = el('select', {
                class: 'aimogen-ai-editor__select',
                disabled: busy,
                onChange: function (event) { state.model = event.target.value; }
            }, [el('option', { value: '', text: t.defaultModel })].concat(
                state.models.map(function (model) {
                    return el('option', { value: model, text: model });
                })
            ));
            modelSelect.value = state.model;
        }

        var temperature = el('input', {
            type: 'range',
            min: '0',
            max: '1',
            step: '0.1',
            class: 'aimogen-ai-editor__range',
            disabled: busy,
            onInput: function (event) { state.temperature = event.target.value; }
        });
        temperature.value = state.temperature !== '' ? state.temperature : '0.4';

        return el('div', { class: 'aimogen-ai-editor__block' }, [
            toggle,
            el('div', { class: 'aimogen-ai-editor__advanced' }, [
                el('label', { class: 'aimogen-ai-editor__checkbox', for: contextBox.id }, [
                    contextBox,
                    el('span', { text: t.useContext })
                ]),
                el('p', { class: 'aimogen-ai-editor__hint', text: t.useContextHint }),
                el('label', { class: 'aimogen-ai-editor__label', text: t.model }),
                modelSelect,
                el('label', { class: 'aimogen-ai-editor__label', text: t.creativity }),
                temperature
            ])
        ]);
    };

    /* ------------------------------------------------------------------ review */

    Panel.prototype.renderReview = function () {
        var self = this;
        var state = this.state;

        var cards = state.proposals.map(function (proposal) {
            return self.renderProposal(proposal);
        });

        var accepted = state.proposals.filter(function (proposal) {
            return state.decisions[proposal.id] === 'accepted';
        }).length;

        var applying = (state.status === 'applying');

        return el('div', { class: 'aimogen-ai-editor__review' }, [
            el('h3', { class: 'aimogen-ai-editor__heading', text: t.proposedChanges })
        ].concat(cards).concat([
            el('div', { class: 'aimogen-ai-editor__actions' }, [
                el('button', {
                    type: 'button',
                    class: 'button button-primary button-large',
                    disabled: applying || accepted === 0,
                    onClick: function () { self.apply(); }
                }, [applying ? t.applying : t.applyAccepted + (accepted ? ' (' + accepted + ')' : '')]),
                el('button', {
                    type: 'button',
                    class: 'button button-link aimogen-ai-editor__discard',
                    disabled: applying,
                    onClick: function () {
                        removeStoredValue('pending');
                        self.setState({ proposals: [], decisions: {}, status: 'idle', message: '' });
                    }
                }, [t.discard]),
                applying ? el('span', { class: 'spinner is-active' }) : null
            ])
        ]));
    };

    Panel.prototype.renderProposal = function (proposal) {
        var self = this;
        var state = this.state;
        var decision = state.decisions[proposal.id] || '';
        var busy = (state.busyField === proposal.id) || state.status === 'applying';

        var notices = [];
        if (proposal.warning === 'blocks') {
            notices.push(el('p', { class: 'aimogen-ai-editor__warning', text: t.blockWarning }));
        }
        if (proposal.unchanged) {
            notices.push(el('p', { class: 'aimogen-ai-editor__hint', text: t.unchanged }));
        }

        var body;
        if (proposal.diff && state['diffOpen_' + proposal.id]) {
            /* Server-rendered by wp_text_diff(); trusted markup from WordPress core. */
            body = el('div', { class: 'aimogen-ai-editor__diff' });
            body.innerHTML = proposal.diff;
        } else {
            body = el('div', { class: 'aimogen-ai-editor__compare' }, [
                el('div', { class: 'aimogen-ai-editor__side' }, [
                    el('span', { class: 'aimogen-ai-editor__side-label', text: t.current }),
                    el('pre', { class: 'aimogen-ai-editor__value', text: proposal.current || t.emptyValue })
                ]),
                el('div', { class: 'aimogen-ai-editor__side aimogen-ai-editor__side--new' }, [
                    el('span', { class: 'aimogen-ai-editor__side-label', text: t.proposed }),
                    el('pre', { class: 'aimogen-ai-editor__value', text: proposal.proposed })
                ])
            ]);
        }

        var controls = [
            el('button', {
                type: 'button',
                class: 'button button-small' + (decision === 'accepted' ? ' button-primary' : ''),
                disabled: busy,
                onClick: function () {
                    state.decisions[proposal.id] = (decision === 'accepted') ? '' : 'accepted';
                    self.render();
                }
            }, [decision === 'accepted' ? t.accepted : t.accept]),
            el('button', {
                type: 'button',
                class: 'button button-small' + (decision === 'ignored' ? ' is-active' : ''),
                disabled: busy,
                onClick: function () {
                    state.decisions[proposal.id] = (decision === 'ignored') ? '' : 'ignored';
                    self.render();
                }
            }, [decision === 'ignored' ? t.ignored : t.ignore]),
            el('button', {
                type: 'button',
                class: 'button button-small',
                disabled: busy,
                onClick: function () { self.regenerate(proposal.id); }
            }, [busy ? t.generating : t.regenerate])
        ];

        if (proposal.diff) {
            controls.push(el('button', {
                type: 'button',
                class: 'button-link aimogen-ai-editor__link',
                onClick: function () {
                    var key = 'diffOpen_' + proposal.id;
                    var patch = {};
                    patch[key] = !state[key];
                    self.setState(patch);
                }
            }, [state['diffOpen_' + proposal.id] ? t.hideDiff : t.showDiff]));
        }

        return el('div', {
            class: 'aimogen-ai-editor__proposal' + (decision ? ' is-' + decision : '')
        }, [
            el('div', { class: 'aimogen-ai-editor__proposal-head' }, [
                el('strong', { text: proposal.label }),
                /* The storage key, not the internal id: "field_sum" reads better than
                   "acf:field_sum" and matches what the field list above shows. */
                proposal.inEditor ? null : el('span', { class: 'aimogen-ai-editor__key', text: proposal.key || proposal.id })
            ])
        ].concat(notices).concat([body, el('div', { class: 'aimogen-ai-editor__controls' }, controls)]));
    };

    /* ---------------------------------------------------------- template runner */

    /*
     * The legacy whole-template workflow, kept intact alongside the review flow.
     *
     * A saved template drives far more than the text fields above - images,
     * taxonomies, SEO fields, slug, status - and the engine behind it writes and saves
     * in one pass. It gets its own section, visually separated and explicitly labelled,
     * so the difference from "generate and review" is never in doubt.
     */
    Panel.prototype.renderTemplateRunner = function () {
        var self = this;
        var state = this.state;

        if (!boot.canRunTemplates) {
            return el('div', { class: 'aimogen-ai-editor__runner' });
        }

        var running = (state.runnerStatus === 'running');
        var blocked = running || state.status === 'generating' || state.status === 'applying';

        var select = el('select', {
            class: 'aimogen-ai-editor__select',
            disabled: blocked,
            onChange: function (event) { state.runnerTemplateId = event.target.value; }
        }, [el('option', { value: '', text: t.runnerSaved })].concat(
            (boot.templates || []).map(function (template) {
                return el('option', { value: String(template.id), text: template.label });
            })
        ));
        select.value = state.runnerTemplateId;

        var children = [
            el('h3', { class: 'aimogen-ai-editor__heading', text: t.runnerTitle }),
            el('p', { class: 'aimogen-ai-editor__hint', text: t.runnerHint }),
            el('p', { class: 'aimogen-ai-editor__warning', text: t.runnerWarning }),
            el('label', { class: 'aimogen-ai-editor__label', text: t.runnerTemplate }),
            select,
            el('div', { class: 'aimogen-ai-editor__actions' }, [
                el('button', {
                    type: 'button',
                    class: 'button button-secondary button-large',
                    disabled: blocked,
                    onClick: function () { self.runTemplate(); }
                }, [running ? t.runnerRunning : t.runnerRun]),
                running ? el('span', { class: 'spinner is-active' }) : null
            ])
        ];

        if (state.runnerMessage) {
            children.push(el('div', {
                class: 'aimogen-ai-editor__message aimogen-ai-editor__message--' +
                    (state.runnerStatus === 'failed' ? 'error' : 'success'),
                text: state.runnerMessage
            }));
        }

        /* Editing-status marker, carried over from the old sidebar. */
        children.push(el('div', { class: 'aimogen-ai-editor__status' }, [
            el('h4', { class: 'aimogen-ai-editor__group-title', text: t.statusTitle }),
            el('p', { class: 'aimogen-ai-editor__hint', text: state.marked ? t.statusEdited : t.statusNotEdited }),
            el('button', {
                type: 'button',
                class: 'button button-small',
                disabled: state.markerBusy || blocked,
                onClick: function () { self.toggleMarker(); }
            }, [state.markerBusy ? t.statusToggling : t.statusToggle])
        ]));

        return el('div', { class: 'aimogen-ai-editor__runner' }, children);
    };

    Panel.prototype.runTemplate = function () {
        var self = this;
        var state = this.state;

        /* The engine runs against the saved row, then rewrites it. Anything unsaved
           in the browser is about to be thrown away, so say so before starting. */
        var question = api.editor.isDirty() ? t.runnerConfirmDirty : t.runnerConfirm;
        if (!window.confirm(question)) {
            return;
        }

        this.setState({ runnerStatus: 'running', runnerMessage: '' });

        api.request('aimogen_ai_editor_run_template', {
            template_id: state.runnerTemplateId || '0'
        }).then(function (data) {
            self.state.marked = !!data.marked;
            self.setState({ runnerStatus: 'done', runnerMessage: t.runnerDone });
            /* The row has been rewritten wholesale - title, content, images,
               taxonomies. Nothing in the open editor is trustworthy any more. */
            window.location.reload();
        }).catch(function (error) {
            if (error && error.message === 'busy') {
                return;
            }
            self.setState({
                runnerStatus: 'failed',
                runnerMessage: error.message || t.runnerFailed
            });
        });
    };

    Panel.prototype.toggleMarker = function () {
        var self = this;
        if (!window.confirm(t.statusConfirm)) {
            return;
        }
        this.setState({ markerBusy: true });

        api.request('aimogen_ai_editor_toggle_marker', {}).then(function (data) {
            self.state.marked = !!data.marked;
            self.setState({ markerBusy: false });
        }).catch(function (error) {
            if (error && error.message === 'busy') {
                return;
            }
            self.setState({ markerBusy: false });
            self.notify(error.message || t.requestFailed, 'error');
        });
    };

    Panel.prototype.renderMessage = function () {
        return el('div', {
            class: 'aimogen-ai-editor__message aimogen-ai-editor__message--' + this.state.messageKind,
            text: this.state.message
        });
    };

    Panel.prototype.renderFooter = function () {
        var self = this;
        var state = this.state;
        if (!state.canUndo) {
            return el('div', { class: 'aimogen-ai-editor__footer' });
        }

        var caption = t.undo;
        if (state.lastChange && state.lastChange.when) {
            caption += ' (' + state.lastChange.when + ')';
        }

        return el('div', { class: 'aimogen-ai-editor__footer' }, [
            el('button', {
                type: 'button',
                class: 'button button-link aimogen-ai-editor__undo',
                disabled: state.status === 'applying' || state.status === 'undoing',
                onClick: function () { self.undo(); }
            }, [state.status === 'undoing' ? t.undoing : caption])
        ]);
    };

    /* ----------------------------------------------------------------- actions */

    Panel.prototype.collectRequest = function () {
        var state = this.state;
        var selected = Object.keys(state.selected);

        var perField = {};
        selected.forEach(function (id) {
            if (state.perField[id] && state.perField[id].trim() !== '') {
                perField[id] = state.perField[id];
            }
        });

        var newFields = [];
        selected.forEach(function (id) {
            if (state.newFields && state.newFields[id]) {
                newFields.push(state.newFields[id]);
            }
        });

        return {
            fields: selected,
            new_fields: newFields,
            instruction: state.instruction,
            field_instructions: perField,
            use_context: state.useContext ? '1' : '0',
            model: state.model || '',
            temperature: state.temperature === '' ? '' : state.temperature,
            editor_values: api.editor.getValues()
        };
    };

    Panel.prototype.generate = function () {
        var self = this;
        var state = this.state;
        var payload = this.collectRequest();

        if (!payload.fields.length) {
            this.notify(t.noFields, 'error');
            return;
        }
        if (payload.instruction.trim() === '' && !Object.keys(payload.field_instructions).length) {
            this.notify(t.noInstruction, 'error');
            return;
        }

        this.setState({ status: 'generating', message: '', proposals: [], decisions: {} });

        api.request('aimogen_ai_editor_generate', payload).then(function (data) {
            var decisions = {};
            var errors = data.errors || {};
            var errorKeys = Object.keys(errors);

            var message = '';
            var kind = 'success';
            if (errorKeys.length) {
                kind = 'warning';
                message = errorKeys.map(function (key) {
                    return key + ': ' + errors[key];
                }).join(' · ');
            }

            self.setState({
                status: 'generated',
                proposals: data.proposals || [],
                decisions: decisions,
                message: message,
                messageKind: kind
            });
        }).catch(function (error) {
            if (error && error.message === 'busy') {
                return;
            }
            self.setState({ status: 'failed' });
            self.notify(error.message || t.requestFailed, 'error');
        });
    };

    Panel.prototype.regenerate = function (fieldId) {
        var self = this;
        var state = this.state;
        var payload = this.collectRequest();
        payload.field = fieldId;
        delete payload.fields;

        this.setState({ busyField: fieldId, message: '' });

        api.request('aimogen_ai_editor_regenerate', payload).then(function (data) {
            var proposals = state.proposals.map(function (proposal) {
                return proposal.id === fieldId ? data.proposal : proposal;
            });
            /* A regenerated field goes back to undecided: the previous accept applied
               to the previous text. */
            delete state.decisions[fieldId];
            self.setState({ proposals: proposals, busyField: '' });
        }).catch(function (error) {
            if (error && error.message === 'busy') {
                return;
            }
            self.setState({ busyField: '' });
            self.notify(error.message || t.requestFailed, 'error');
        });
    };

    Panel.prototype.apply = function () {
        var self = this;
        var state = this.state;

        var accepted = state.proposals.filter(function (proposal) {
            return state.decisions[proposal.id] === 'accepted';
        });
        if (!accepted.length) {
            this.notify(t.nothingAccepted, 'error');
            return;
        }

        if (!api.editor.isDirty()) {
            this.sendApply(accepted, {});
            return;
        }

        /*
         * The screen holds work the user has not saved, and applying writes to the
         * post and then reloads, so that work would be lost. Save it for them.
         *
         * Gutenberg saves in place, so the whole sequence finishes without the user
         * doing anything. The classic editor only saves by submitting its form, which
         * navigates, so the review is parked and picked up again after the reload.
         */
        if (api.editor.canSaveInPlace()) {
            var live = api.editor.getValues();

            this.setState({ status: 'applying', message: '' });
            /* Gutenberg has to stay free to run this save, so the overlay goes up
               without the saving lock; sendApply() engages it once Aimogen writes. */
            beginCommit(t.savingFirst, { allowPostSaving: true });

            api.editor.save().then(function (outcome) {
                if (!outcome.saved) {
                    endCommit();
                    self.setState({ status: 'generated' });
                    self.notify(t.autoSaveFailed, 'error');
                    return;
                }
                self.sendApply(accepted, rebaseAfterSave(accepted, live, outcome.stored, outcome.clean));
            });
            return;
        }

        this.applyThroughReload();
    };

    /*
     * Classic editor: save by submitting WordPress's own form, and finish the apply
     * when the page comes back.
     *
     * Submitting is the only way the classic editor persists its metaboxes, so there
     * is no version of this that avoids the reload. What it does avoid is making the
     * user press Update and then come back and press Apply a second time.
     */
    Panel.prototype.applyThroughReload = function () {
        var live = api.editor.getValues();
        var rebaseExpected = rebaseAfterSave(this.state.proposals, live, null, true);

        this.setState({ status: 'applying', message: '' });
        this.saveThroughReload('apply', { rebaseExpected: rebaseExpected }, t.saveBeforeApplyNoStorage);
    };

    /*
     * Park the panel, then let WordPress's own Update button save and reload.
     *
     * `resume` is what the panel should finish once the page comes back. It is
     * cleared again if the navigation never happens: another plugin's form validation
     * can stop the submit, and a flag left parked would otherwise fire on an
     * unrelated later reload of this tab.
     */
    Panel.prototype.saveThroughReload = function (resume, overrides, fallbackMessage) {
        var self = this;
        var state = this.state;
        var saved = overrides || {};
        saved.resume = resume;

        function giveUp() {
            removeStoredValue('pending');
            endCommit();
            self.setState({ status: state.proposals.length ? 'generated' : 'idle' });
            self.notify(fallbackMessage, 'warning');
        }

        if (!persistPanelState(state, saved)) {
            giveUp();
            return;
        }

        beginCommit(t.savingFirst, { allowPostSaving: true });

        var leaving = false;
        function markLeaving() {
            leaving = true;
        }
        window.addEventListener('pagehide', markLeaving);

        if (!api.editor.submitSave()) {
            window.removeEventListener('pagehide', markLeaving);
            giveUp();
            return;
        }

        window.setTimeout(function () {
            if (leaving) {
                return;
            }
            window.removeEventListener('pagehide', markLeaving);
            giveUp();
        }, 15000);
    };

    /*
     * Write the accepted values.
     *
     * All of them go through one authenticated server request, title/content/excerpt
     * included: after the write succeeds the page reloads, so no custom field
     * framework can later submit a stale browser-side value over the top.
     *
     * `rebased` carries the post-save baselines for stale-write protection, and is
     * empty when nothing was saved on the panel's behalf.
     */
    Panel.prototype.sendApply = function (accepted, rebased) {
        var self = this;
        var state = this.state;
        var baselines = rebased || {};

        var serverChanges = {};
        var expectedValues = {};
        var newFields = [];
        accepted.forEach(function (proposal) {
            serverChanges[proposal.id] = proposal.proposed;
            if (state.newFields && state.newFields[proposal.id]) {
                newFields.push(state.newFields[proposal.id]);
            }
            var expected;
            if (Object.prototype.hasOwnProperty.call(baselines, proposal.id)) {
                expected = baselines[proposal.id];
            } else {
                expected = proposal.expected === null || proposal.expected === undefined
                    ? proposal.current
                    : proposal.expected;
            }
            expectedValues[proposal.id] = expected === null || expected === undefined
                ? ''
                : expected;
        });

        /* Keep a complete retryable review before the first database write. This is
           also the recovery point when a response is lost after PHP has committed. */
        if (!persistPanelState(state)) {
            endCommit();
            this.setState({ status: state.proposals.length ? 'generated' : 'idle' });
            this.notify(t.reviewStorageUnavailable, 'error');
            return;
        }

        this.setState({ status: 'applying', message: '' });
        beginCommit();

        api.request('aimogen_ai_editor_apply', {
            changes: serverChanges,
            expected: expectedValues,
            new_fields: newFields,
            write_core: '1'
        }).then(function (data) {
            var skipped = data.skipped && typeof data.skipped === 'object' ? data.skipped : {};
            var problems = Object.keys(skipped).map(function (key) {
                return key + ': ' + skipped[key];
            });
            var applied = Array.isArray(data.applied) ? data.applied : [];
            var remaining = state.proposals.filter(function (proposal) {
                return applied.indexOf(proposal.id) === -1;
            });
            var remainingDecisions = {};

            remaining.forEach(function (proposal) {
                if (state.decisions[proposal.id]) {
                    remainingDecisions[proposal.id] = state.decisions[proposal.id];
                }
            });
            self.state.canUndo = !!data.canUndo;

            if (applied.length) {
                if (remaining.length) {
                    persistPanelState(state, {
                        proposals: remaining,
                        decisions: remainingDecisions
                    });
                } else {
                    removeStoredValue('pending');
                }

                writeStoredValue('flash', {
                    message: [t.appliedReloaded]
                        .concat(problems.length ? [t.applyPartial].concat(problems) : [])
                        .join(' '),
                    kind: problems.length ? 'warning' : 'success'
                });
                window.location.reload();
                return;
            }

            removeStoredValue('pending');
            endCommit();
            self.setState({
                status: 'failed',
                message: [t.nothingApplied].concat(problems).join(' '),
                messageKind: 'warning'
            });
        }).catch(function (error) {
            if (error && error.message === 'busy') {
                return;
            }
            if (!error || error.aimogenResponseReceived !== true) {
                writeStoredValue('flash', {
                    message: t.applyUnknown,
                    kind: 'warning'
                });
                window.location.reload();
                return;
            }
            removeStoredValue('pending');
            endCommit();
            self.setState({ status: 'failed' });
            self.notify(error.message || t.requestFailed, 'error');
        });
    };

    Panel.prototype.undo = function () {
        var self = this;
        if (!window.confirm(t.confirmUndo)) {
            return;
        }

        if (!api.editor.isDirty()) {
            this.sendUndo();
            return;
        }

        /* Undo restores stored values and reloads, so unsaved work on the screen is
           saved first for the same reason Apply saves it. The user has already
           confirmed the undo itself, so nothing else needs asking. */
        if (api.editor.canSaveInPlace()) {
            this.setState({ status: 'undoing', message: '' });
            beginCommit(t.savingFirst, { allowPostSaving: true });

            api.editor.save().then(function (outcome) {
                if (!outcome.saved) {
                    endCommit();
                    self.setState({ status: self.state.proposals.length ? 'generated' : 'idle' });
                    self.notify(t.autoSaveFailed, 'error');
                    return;
                }
                self.sendUndo();
            });
            return;
        }

        this.setState({ status: 'undoing', message: '' });
        this.saveThroughReload('undo', {}, t.saveBeforeUndo);
    };

    Panel.prototype.sendUndo = function () {
        var self = this;

        this.setState({ status: 'undoing', message: '' });
        beginCommit();

        api.request('aimogen_ai_editor_undo', {}).then(function (data) {
            var restored = data.restored || {};
            var skipped = data.skipped || {};
            var problems = Object.keys(skipped).map(function (fieldId) {
                return fieldId + ': ' + skipped[fieldId];
            });

            self.state.canUndo = !!data.canUndo;
            self.state.lastChange = data.lastChange || null;

            if (Object.keys(restored).length) {
                removeStoredValue('pending');
                writeStoredValue('flash', {
                    message: [t.undone]
                        .concat(problems.length ? [t.undoIncomplete].concat(problems) : [])
                        .join(' '),
                    kind: problems.length ? 'warning' : 'success'
                });
                window.location.reload();
                return;
            }

            endCommit();
            var message = [];
            if (problems.length) {
                message.push(t.undoIncomplete);
                message = message.concat(problems);
            }
            if (!message.length) {
                message.push(t.nothingApplied);
            }
            self.setState({
                status: 'idle',
                message: message.join(' '),
                messageKind: problems.length ? 'warning' : 'success'
            });
        }).catch(function (error) {
            if (error && error.message === 'busy') {
                return;
            }
            if (!error || error.aimogenResponseReceived !== true) {
                writeStoredValue('flash', {
                    message: t.undoUnknown,
                    kind: 'warning'
                });
                window.location.reload();
                return;
            }
            endCommit();
            self.setState({ status: 'idle' });
            self.notify(error.message || t.requestFailed, 'error');
        });
    };

    Panel.prototype.loadModels = function () {
        var self = this;
        api.request('aimogen_ai_editor_models', {}).then(function (data) {
            self.setState({ models: data.models || [] });
        }).catch(function () {
            self.setState({ models: [] });
        });
    };

    Panel.prototype.loadTemplate = function (templateId) {
        var self = this;
        var state = this.state;

        state.templateId = templateId;
        if (!templateId) {
            this.render();
            return;
        }

        api.request('aimogen_ai_editor_template', { template_id: templateId }).then(function (data) {
            if (data.general) {
                state.instruction = data.general;
                state.presetId = 'custom';
            }
            Object.keys(data.perField || {}).forEach(function (fieldId) {
                state.perField[fieldId] = data.perField[fieldId];
                /* A template that names a field is also selecting it: that is what
                   running the template used to do. */
                state.selected[fieldId] = true;
                state.perFieldOpen[fieldId] = true;
            });
            self.setState({ message: t.templateLoaded, messageKind: 'info' });
        }).catch(function (error) {
            if (error && error.message === 'busy') {
                return;
            }
            self.notify(error.message || t.requestFailed, 'error');
        });
    };

    /*
     * There is exactly one panel per page, living in a container the panel owns.
     *
     * Gutenberg destroys and recreates the sidebar's DOM every time the user closes
     * and reopens it. Building a fresh Panel on each mount would throw away whatever
     * was in progress - the instruction, the field selection, a whole set of proposals
     * waiting to be reviewed. Keeping one container and MOVING it into whichever host
     * is currently on screen means that state survives, so the block editor behaves
     * the way the always-present classic metabox does.
     */
    var panel = null;
    var container = null;

    function ensurePanel() {
        if (!panel) {
            container = document.createElement('div');
            container.className = 'aimogen-ai-editor__panel';
            panel = new Panel(container);
        }
        return panel;
    }

    /* appendChild moves an already-parented node, it does not clone it. */
    function attach(host) {
        if (!host) {
            return panel;
        }
        ensurePanel();
        if (container.parentNode !== host) {
            host.appendChild(container);
        }
        return panel;
    }

    window.AimogenAiEditor.attach = attach;
    window.AimogenAiEditor.mount = attach;
    window.AimogenAiEditor.getPanel = function () { return panel; };

    document.addEventListener('DOMContentLoaded', function () {
        var root = document.getElementById('aimogen-ai-editor-root');
        if (root) {
            attach(root);
        }
    });

})(window, document);
