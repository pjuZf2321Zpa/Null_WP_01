"use strict";
jQuery(document).ready(function(){
    (function($) {
        var CRUMB_SEP = String.fromCharCode(8250);
        var MENU_ARROW = String.fromCharCode(8627);
        var breadcrumb = null;
        function aiTrim(text) {
            if (typeof text !== 'string') {
                return '';
            }
            var out = text.replace(/^\s+/, '').replace(/\s+$/, '');
            while (out.length > 0 && out.charAt(0) === MENU_ARROW) {
                out = out.substring(1).replace(/^\s+/, '');
            }
            return out;
        }
        function aiActiveAnchor() {
            return $('.aiomatic-nav-tab-active, .nav-tab-active').first();
        }
        function aiLabelOf(anchor) {
            if (anchor.length === 0) {
                return '';
            }
            var label = aiTrim(anchor.find('.aiomatic-sidebar-label').first().text());
            return label !== '' ? label : aiTrim(anchor.text());
        }
        function aiSectionLabel(anchor) {
            if (anchor.length === 0) {
                return '';
            }
            return aiTrim(anchor.closest('.aiomatic-sidebar-nav').prevAll('.aiomatic-sidebar-heading').first().text());
        }
        function aiSectionHomeHref(anchor) {
            if (anchor.length === 0) {
                return '';
            }
            var first = anchor.closest('.nav-tab-wrapper').find('a').first();
            if (first.length === 0 || first.is(anchor)) {
                return '';
            }
            return first.attr('href') || '';
        }
        function aiMenuCrumb() {
            var item = $('#adminmenu li.current > a').first();
            if (item.length === 0) {
                return null;
            }
            var label = aiTrim(item.clone().children('span').remove().end().text());
            if (label === '') {
                return null;
            }
            return { label: label, href: item.attr('href') || '' };
        }
        function aiRootCrumb() {
            var link = $('#adminmenu li.wp-has-current-submenu > a.menu-top').first();
            if (link.length === 0) {
                link = $('#adminmenu li.wp-menu-open > a.menu-top').first();
            }
            if (link.length === 0) {
                return null;
            }
            var href = link.attr('href') || '';
            if (href === '') {
                return null;
            }
            var label = aiTrim(link.find('.wp-menu-name').first().text());
            if (label === '') {
                label = aiTrim(link.text());
            }
            return { label: label, href: href };
        }
        function aiI18n(key, fallback) {
            if (typeof aimogenBreadcrumb !== 'undefined' && aimogenBreadcrumb && aimogenBreadcrumb[key]) {
                return aimogenBreadcrumb[key];
            }
            return fallback;
        }
        function aiTutorialAnchor(active) {
            var label = aiI18n('tutorialLabel', 'Tutorial');
            var found = null;
            var scopes = [];
            if (active.length > 0) {
                scopes.push(active.closest('.nav-tab-wrapper'));
            }
            scopes.push($('.nav-tab-wrapper'));
            for (var i = 0; i < scopes.length && found === null; i++) {
                scopes[i].find('a[href^="#"]').each(function() {
                    if (found !== null) {
                        return;
                    }
                    var a = $(this);
                    if (aiLabelOf(a) === label) {
                        var tab = (a.attr('href') || '').substring(1);
                        if (tab !== '' && $('#' + tab).length > 0) {
                            found = a;
                        }
                    }
                });
            }
            return found;
        }
        function aiCrumbLink(label, href) {
            if (href === '') {
                return $('<span/>', { 'class': 'aiomatic-crumb', text: label });
            }
            return $('<a/>', { 'class': 'aiomatic-crumb', href: href, text: label });
        }
        function aiRender() {
            if (breadcrumb === null || breadcrumb.length === 0) {
                return;
            }
            var anchor = aiActiveAnchor();
            var crumbs = [];
            var root = aiRootCrumb();
            var menu = aiMenuCrumb();
            var section = aiSectionLabel(anchor);
            var leaf = aiLabelOf(anchor);
            if (root !== null) {
                crumbs.push(aiCrumbLink(root.label, root.href));
            }
            if (menu !== null && menu.label !== leaf) {
                if (root === null || menu.label !== root.label) {
                    crumbs.push(aiCrumbLink(menu.label, menu.href));
                }
            }
            if (section !== '' && section !== leaf) {
                if (menu === null || section !== menu.label) {
                    crumbs.push(aiCrumbLink(section, aiSectionHomeHref(anchor)));
                }
            }
            if (leaf === '' && menu !== null) {
                leaf = menu.label;
                if (crumbs.length > 1) {
                    crumbs.pop();
                }
            }
            if (leaf !== '') {
                crumbs.push($('<span/>', { 'class': 'aiomatic-crumb aiomatic-crumb-current', 'aria-current': 'page', text: leaf }));
            }
            breadcrumb.empty();
            for (var i = 0; i < crumbs.length; i++) {
                if (i > 0) {
                    breadcrumb.append($('<span/>', { 'class': 'aiomatic-crumb-sep', 'aria-hidden': 'true', text: CRUMB_SEP }));
                }
                breadcrumb.append(crumbs[i]);
            }
            var tut = aiTutorialAnchor(anchor);
            if (tut !== null && !tut.hasClass('aiomatic-nav-tab-active') && !tut.hasClass('nav-tab-active')) {
                breadcrumb.append($('<a/>', {
                    'class': 'aiomatic-crumb-tutorial',
                    href: tut.attr('href'),
                    text: aiI18n('viewTutorial', 'View tutorial')
                }));
            }
        }
        function aiBuild() {
            var hero = $('.aiomatic-admin-hero').first();
            if (hero.length === 0) {
                return;
            }
            breadcrumb = $('<nav/>', { 'class': 'aiomatic-admin-breadcrumb', 'aria-label': 'Breadcrumb' });
            hero.after(breadcrumb);
            aiRender();
        }
        aiBuild();
        $(document).on('aimogen:tabchange', aiRender);
    })(jQuery);
});
