"use strict";

function aiomaticClearReplyNotice(targetId) {
    var notice = document.getElementById(targetId + '-incomplete-notice');
    if (notice && notice.parentNode) {
        notice.parentNode.removeChild(notice);
    }
}

function aiomaticShowReplyNotice(targetId, data, eventType) {
    if (!data || typeof data !== 'object') {
        return;
    }
    var response = data.response || {};
    var choice = data.choices && data.choices[0] || {};
    var candidate = data.candidates && data.candidates[0] || {};
    var reason = data.finish_reason || data.stop_reason ||
        (data.delta && data.delta.stop_reason) || choice.finish_reason ||
        candidate.finishReason || (response.incomplete_details && response.incomplete_details.reason);
    var limited = ['length', 'max_tokens', 'max_output_tokens', 'MAX_TOKENS'].indexOf(reason) !== -1;
    if (!limited && eventType !== 'response.incomplete' && data.type !== 'response.incomplete' && response.status !== 'incomplete') {
        return;
    }
    var target = document.getElementById(targetId);
    if (!target || !target.parentNode) {
        return;
    }
    var notice = document.getElementById(targetId + '-incomplete-notice');
    if (!notice) {
        notice = document.createElement('div');
        notice.id = targetId + '-incomplete-notice';
        notice.className = 'aiomatic-reply-notice text-primary highlight-text';
        notice.setAttribute('role', 'status');
        target.parentNode.insertBefore(notice, target);
    }
    var messages = typeof aiomatic_reply_notices === 'object' ? aiomatic_reply_notices : {};
    // Keep this outside the answer so it is not saved, sent back to the AI, or spoken.
    notice.textContent = limited
        ? (messages.limit || 'The reply reached its length limit and may be incomplete.')
        : (messages.incomplete || 'The reply ended before it was complete. Please try again.');
}

function aiomaticWatchReplyNotice(source, targetId) {
    function checkReply(event) {
        if (!event.data || event.data === '[DONE]') {
            return;
        }
        var data;
        try {
            data = JSON.parse(event.data);
        } catch (error) {
            return;
        }
        aiomaticShowReplyNotice(targetId, data, event.type);
    }
    ['message', 'completion', 'message_delta', 'response.incomplete'].forEach(function(type) {
        source.addEventListener(type, checkReply);
    });
}
