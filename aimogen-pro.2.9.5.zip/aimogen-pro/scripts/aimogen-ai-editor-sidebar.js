"use strict";
/*
 * Aimogen AI Editor - block editor adapter.
 *
 * The panel itself is plain DOM (aimogen-ai-editor-ui.js); this file only decides
 * where it lives in Gutenberg. Two surfaces are registered:
 *
 *   - a PluginSidebar holding the panel, which is where the work happens;
 *   - a small panel in the Document sidebar with a button that opens it, because a
 *     PluginSidebar is otherwise reachable only through the toolbar icon or the
 *     options menu, and the classic-editor metabox is impossible to miss by
 *     comparison.
 *
 * Kept separate from the legacy 'aiomatic-sidebar' plugin, which still provides the
 * template-and-run workflow unchanged.
 */
(function (wp, window, document) {

    if (!wp || !wp.plugins || !wp.element || !window.AimogenAiEditor) {
        return;
    }

    var el = wp.element.createElement;
    var Fragment = wp.element.Fragment;
    var useRef = wp.element.useRef;
    var useEffect = wp.element.useEffect;
    var registerPlugin = wp.plugins.registerPlugin;

    /* wp.editor is the modern home for these; wp.editPost is the pre-6.6 fallback. */
    var editorPkg = wp.editor || {};
    var editPostPkg = wp.editPost || {};
    var PluginSidebar = editorPkg.PluginSidebar || editPostPkg.PluginSidebar;
    var PluginSidebarMoreMenuItem = editorPkg.PluginSidebarMoreMenuItem || editPostPkg.PluginSidebarMoreMenuItem;
    var PluginDocumentSettingPanel = editorPkg.PluginDocumentSettingPanel || editPostPkg.PluginDocumentSettingPanel;

    if (!PluginSidebar) {
        return;
    }

    var PLUGIN_NAME = 'aimogen-ai-editor';
    var SIDEBAR_NAME = 'aimogen-ai-editor';
    var SIDEBAR_ID = PLUGIN_NAME + '/' + SIDEBAR_NAME;

    var boot = window.AimogenAiEditor.boot || {};
    var strings = boot.i18n || {};
    var title = strings.panelTitle || 'Aimogen AI Editor';

    var icon = el('svg', {
        xmlns: 'http://www.w3.org/2000/svg',
        width: 20,
        height: 20,
        viewBox: '0 0 24 24',
        'aria-hidden': 'true',
        focusable: 'false'
    }, el('path', {
        d: 'M12 2l2.4 6.1L21 10.5l-6.6 2.4L12 19l-2.4-6.1L3 10.5l6.6-2.4L12 2zm7 11l.9 2.3 2.1.8-2.1.8L19 19l-.9-2.1-2.1-.8 2.1-.8L19 13z'
    }));

    /*
     * Host for the shared panel. The effect runs on every mount, and attach() moves
     * the one existing panel container in here, so reopening the sidebar restores
     * whatever was in progress instead of starting over.
     */
    function PanelHost() {
        var ref = useRef(null);

        useEffect(function () {
            if (ref.current) {
                window.AimogenAiEditor.attach(ref.current);
            }
        });

        return el('div', { className: 'aimogen-ai-editor__host', ref: ref });
    }

    /*
     * Open the sidebar programmatically. The interface store is the current API; the
     * edit-post store is kept as a fallback for older builds.
     */
    function openSidebar() {
        var dispatch = wp.data && wp.data.dispatch;
        if (!dispatch) {
            return;
        }
        var editPostStore = dispatch('core/edit-post');
        if (editPostStore && typeof editPostStore.openGeneralSidebar === 'function') {
            editPostStore.openGeneralSidebar(SIDEBAR_ID);
            return;
        }
        var interfaceStore = dispatch('core/interface');
        if (interfaceStore && typeof interfaceStore.enableComplementaryArea === 'function') {
            interfaceStore.enableComplementaryArea('core', SIDEBAR_ID);
        }
    }

    function OpenButton() {
        var Button = wp.components && wp.components.Button;
        var label = strings.openEditor || title;

        if (!Button) {
            return el('button', {
                type: 'button',
                className: 'components-button is-secondary',
                onClick: openSidebar
            }, label);
        }
        return el(Button, {
            variant: 'secondary',
            icon: icon,
            onClick: openSidebar
        }, label);
    }

    registerPlugin(PLUGIN_NAME, {
        icon: icon,
        render: function () {
            return el(Fragment, null,
                PluginSidebarMoreMenuItem
                    ? el(PluginSidebarMoreMenuItem, { target: SIDEBAR_NAME, icon: icon }, title)
                    : null,
                el(PluginSidebar, {
                    name: SIDEBAR_NAME,
                    icon: icon,
                    title: title,
                    className: 'aimogen-ai-editor__sidebar'
                }, el(PanelHost, null)),
                PluginDocumentSettingPanel
                    ? el(PluginDocumentSettingPanel, {
                        name: 'aimogen-ai-editor-launch',
                        title: title,
                        className: 'aimogen-ai-editor__doc-panel'
                    },
                        el('p', { className: 'aimogen-ai-editor__doc-hint' },
                            strings.docPanelHint || 'Edit this post’s fields with AI, review the changes, then apply them.'),
                        el(OpenButton, null))
                    : null
            );
        }
    });

})(window.wp, window, document);
