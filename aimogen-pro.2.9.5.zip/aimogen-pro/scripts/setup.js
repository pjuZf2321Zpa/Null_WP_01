"use strict"; 
jQuery(document).ready(function($) 
{
    $(window).off('beforeunload');
    window.onbeforeunload = function () {return null;};
});
document.addEventListener('DOMContentLoaded', function () {

    function aiomaticToggleWorkspace(state) {
        document.querySelectorAll('.aiomatic-workspace-grid input[type="checkbox"]').forEach(cb => {
            if (cb.disabled) return;
            cb.checked = state;
        });
    }

    const selectAllBtn = document.querySelector('.aiomatic-select-all');
    const selectNoneBtn = document.querySelector('.aiomatic-select-none');

    if (selectAllBtn) {
        selectAllBtn.addEventListener('click', function () {
            aiomaticToggleWorkspace(true);
        });
    }

    if (selectNoneBtn) {
        selectNoneBtn.addEventListener('click', function () {
            aiomaticToggleWorkspace(false);
        });
    }

});