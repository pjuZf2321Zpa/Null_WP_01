"use strict";
jQuery(document).ready(function(){
    (function($) {
        var TAB_PATTERN = /^tab-[0-9a-z_-]+$/i;
        var tabs = $('.nav-tab-wrapper a');
        var supportsHistory = !!(window.history && window.history.pushState);
        var syncdone1 = sessionStorage.getItem("syncdone1");
        var syncdone2 = sessionStorage.getItem("syncdone2");
        var syncdone3 = sessionStorage.getItem("syncdone3");
        var search = window.location.search || '';
        var isSettingsPage = search.indexOf('page=aiomatic_admin_settings') !== -1;
        var isChatbotPage = search.indexOf('page=aiomatic_chatbot_panel') !== -1;
        var pageMatch = /[?&]page=([0-9a-z_-]+)/i.exec(search);
        var storageKey = 'aiomatic-active-tab:' + (pageMatch ? pageMatch[1] : 'default');
        var currentTab = '';
        function aiEscapeId(tab) {
            return tab.replace(/([ #;?%&,.+*~\':"!^$[\]()=>|\/@])/g, '\\$1');
        }
        function aiTabExists(tab) {
            return typeof tab === 'string' && tab !== '' && $('#' + aiEscapeId(tab)).length > 0;
        }
        function aiTabFromHash() {
            var hash = (window.location.hash || '').substring(1);
            return TAB_PATTERN.test(hash) === true ? hash : '';
        }
        function aiReadStoredTab() {
            try {
                return localStorage.getItem(storageKey) || '';
            } catch (e) {
                return '';
            }
        }
        function aiStoreTab(tab) {
            try {
                localStorage.setItem(storageKey, tab);
            } catch (e) {}
        }
        function aiFallbackTab() {
            if (aiTabExists('tab-1')) {
                return 'tab-1';
            }
            var first = $('.tab-content').first().attr('id');
            return (typeof first === 'string' && first !== '') ? first : 'tab-1';
        }
        function aiResolveInitialTab() {
            var tab = aiTabFromHash();
            if (aiTabExists(tab)) {
                return tab;
            }
            tab = aiReadStoredTab();
            if (aiTabExists(tab)) {
                return tab;
            }
            return aiFallbackTab();
        }
        function aiSyncPageChrome(tab) {
            if (isChatbotPage) {
                if (tab == 'tab-16' || tab == 'tab-7' || tab == 'tab-tr' || tab == 'tab-0r') {
                    $('#btnSubmit').hide();
                } else {
                    $('#btnSubmit').show();
                }
            }
        }
        function aiRunSyncHooks() {
            if($("#aiomatic_sync_files").is(":visible"))
            {
                if(syncdone1 === false || syncdone1 === null)
                {
                    sessionStorage.setItem("syncdone1", true);
                    $('.aiomatic_sync_files').click();
                }
            }
            if($("#aiomatic_sync_batches").is(":visible"))
            {
                if(syncdone3 === false || syncdone3 === null)
                {
                    sessionStorage.setItem("syncdone3", true);
                    $('.aiomatic_sync_batches').click();
                }
            }
            if($("#aiomatic_sync_finetunes").is(":visible"))
            {
                if(syncdone2 === false || syncdone2 === null)
                {
                    sessionStorage.setItem("syncdone2", true);
                    $('.aiomatic_sync_finetunes').click();
                }
            }
        }
        function aiActivateTab(tab, pushHistory, runSyncHooks) {
            if (!aiTabExists(tab)) {
                return false;
            }
            $('.tab-content').hide();
            $('#' + aiEscapeId(tab)).show();
            tabs.removeClass('aiomatic-nav-tab-active');
            $('.nav-tab[href="#' + tab + '"], .aiomatic-nav-tab[href="#' + tab + '"]').addClass('aiomatic-nav-tab-active');
            currentTab = tab;
            aiStoreTab(tab);
            aiSyncPageChrome(tab);
            $(document).trigger('aimogen:tabchange');
            if (pushHistory === true && supportsHistory) {
                window.history.pushState({ aiomaticTab: tab }, '', '#' + tab);
            }
            if (runSyncHooks === true) {
                aiRunSyncHooks();
            }
            return true;
        }
        currentTab = aiResolveInitialTab();
        $('.tab-content').hide();
        if (aiActivateTab(currentTab, false, false) === true) {
            if (supportsHistory && aiTabFromHash() !== currentTab) {
                window.history.replaceState({ aiomaticTab: currentTab }, '', '#' + currentTab);
            }
        }
        if (isSettingsPage) {
            var settingsForm = $('#myForm');
            var settingsBar = $('.aiomatic-settings-actionbar');
            var settingsBarText = settingsBar.find('.aiomatic-settings-actionbar-copy span');
            // The save bar is a response to unsaved work, not permanent furniture:
            // it stays off screen (and costs no page padding) until something changes.
            function aiRevealSettingsBar() {
                if (settingsBar.hasClass('is-visible')) {
                    return;
                }
                settingsBar.addClass('is-visible');
                $('body').addClass('aiomatic-has-settings-bar');
            }
            settingsForm.on('input change', ':input', function() {
                aiRevealSettingsBar();
                settingsBar.addClass('aiomatic-settings-actionbar-dirty');
                settingsBarText.text('Unsaved changes');
            });
            settingsForm.on('submit', function() {
                aiRevealSettingsBar();
                settingsBar.removeClass('aiomatic-settings-actionbar-dirty').addClass('aiomatic-settings-actionbar-saving');
                settingsBarText.text('Saving settings...');
            });
        }
        tabs.on('click', function(e) {
            var link = $(this).attr('datahref');
            if(link !== undefined && link !== null && link !== '')
            {
                e.preventDefault();
                window.location.href = link;
                return;
            }
            var href = $(this).attr('href') || '';
            if (href.charAt(0) !== '#') {
                return;
            }
            e.preventDefault();
            var tab = href.substring(1);
            if (!aiTabExists(tab)) {
                return;
            }
            aiActivateTab(tab, tab !== currentTab, true);
        });
        $(window).on('popstate hashchange', function() {
            var tab = aiTabFromHash();
            if (!aiTabExists(tab) || tab === currentTab) {
                return;
            }
            aiActivateTab(tab, false, true);
        });
    })(jQuery);
});
