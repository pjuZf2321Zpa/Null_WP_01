"use strict";
/*
 * Aimogen AI Editor - state, transport, and editor-state bridge.
 *
 * No DOM rendering lives here. aimogen-ai-editor-ui.js owns the markup, and the two
 * Gutenberg/Classic adapters only decide where that markup is mounted.
 */
(function (window) {

    var boot = window.aimogenAiEditor || {};

    /*
     * A request is only ever in flight once per kind. Generate, apply and undo all
     * disable their buttons in the UI, but a second click that slips through (double
     * submit, Enter key, a stray keyboard shortcut) must not reach the provider and
     * bill the user twice.
     */
    var inFlight = {};
    var externalDirty = false;
    var dirtyTrackingSuppressed = 0;
    var dirtyTrackingReady = typeof document === 'undefined' || document.readyState !== 'loading';
    var jqueryDirtyTrackingBound = false;
    var commitOverlay = null;
    var commitPreviousFocus = null;
    var postSavingLocked = false;
    var commitActive = false;

    /*
     * Custom-field frameworks do not share one dirty-state API. Capture real user
     * input anywhere outside Aimogen's own panel so applying or undoing can never race
     * an unsaved metabox, React control, or framework-specific editor. Synthetic
     * events dispatched while synchronizing controls are intentionally ignored.
     */
    function trackExternalChange(event) {
        var target = event && event.target;
        if (!event || !dirtyTrackingReady || dirtyTrackingSuppressed > 0) {
            return;
        }
        if (target && typeof target.closest === 'function' &&
            target.closest('.aimogen-ai-editor__panel')) {
            return;
        }
        externalDirty = true;
    }

    function withDirtyTrackingSuppressed(callback) {
        dirtyTrackingSuppressed += 1;
        try {
            return callback();
        } finally {
            dirtyTrackingSuppressed -= 1;
        }
    }

    function bindJqueryDirtyTracking() {
        if (jqueryDirtyTrackingBound || typeof window.jQuery !== 'function' || typeof document === 'undefined') {
            return;
        }

        try {
            var jqueryDocument = window.jQuery(document);
            if (jqueryDocument && typeof jqueryDocument.on === 'function') {
                jqueryDocument.on(
                    'input.aimogenAiEditorDirty change.aimogenAiEditorDirty',
                    trackExternalChange
                );
                jqueryDirtyTrackingBound = true;
            }
        } catch (error) {
            /* Native tracking and editor APIs remain available if another plugin
               replaces jQuery with a partial compatibility layer. */
        }
    }

    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
        document.addEventListener('input', trackExternalChange, true);
        document.addEventListener('change', trackExternalChange, true);
        bindJqueryDirtyTracking();
        if (!dirtyTrackingReady) {
            document.addEventListener('DOMContentLoaded', function () {
                dirtyTrackingReady = true;
                bindJqueryDirtyTracking();
            });
        }
    }

    function tinyMceEditorIsDirty(editor) {
        try {
            return !!(editor && typeof editor.isDirty === 'function' && editor.isDirty());
        } catch (error) {
            /* Detached third-party editors can remain in TinyMCE's registry briefly. */
            return false;
        }
    }

    /*
     * The latched dirty flag above cannot tell that the work it saw reached the
     * database afterwards. Every completed save clears it, whether Aimogen triggered
     * that save or the user pressed Update themselves.
     */
    function markSaved() {
        externalDirty = false;
    }

    function lockPostSaving() {
        if (postSavingLocked) {
            return;
        }
        try {
            var dispatcher = window.wp && window.wp.data && typeof window.wp.data.dispatch === 'function'
                ? window.wp.data.dispatch('core/editor')
                : null;
            if (dispatcher && typeof dispatcher.lockPostSaving === 'function') {
                dispatcher.lockPostSaving('aimogen-ai-editor');
                postSavingLocked = true;
            }
        } catch (error) {
            postSavingLocked = false;
        }
    }

    /*
     * Cover the screen for the duration of an Aimogen write.
     *
     * An automated apply calls this twice: once with allowPostSaving while the editor
     * persists the user's own unsaved work - Gutenberg has to be free to run that save
     * - and again when it becomes Aimogen's turn to write, which engages the lock and
     * swaps the message. The overlay itself is only built on the first call.
     */
    function beginCommit(message, options) {
        if (!options || !options.allowPostSaving) {
            lockPostSaving();
        }

        if (commitActive) {
            if (commitOverlay && typeof message === 'string') {
                commitOverlay.textContent = message;
            }
            return;
        }
        commitActive = true;

        if (typeof document === 'undefined' || !document.body || typeof document.createElement !== 'function') {
            return;
        }

        commitPreviousFocus = document.activeElement || null;
        if (commitPreviousFocus && typeof commitPreviousFocus.blur === 'function') {
            commitPreviousFocus.blur();
        }

        commitOverlay = document.createElement('div');
        commitOverlay.className = 'aimogen-ai-editor__commit-lock';
        commitOverlay.setAttribute('role', 'status');
        commitOverlay.setAttribute('aria-live', 'assertive');
        commitOverlay.setAttribute('tabindex', '-1');
        commitOverlay.textContent = message || '';
        document.body.appendChild(commitOverlay);
        if (typeof commitOverlay.focus === 'function') {
            commitOverlay.focus();
        }
    }

    function endCommit() {
        if (postSavingLocked) {
            try {
                var dispatcher = window.wp && window.wp.data && typeof window.wp.data.dispatch === 'function'
                    ? window.wp.data.dispatch('core/editor')
                    : null;
                if (dispatcher && typeof dispatcher.unlockPostSaving === 'function') {
                    dispatcher.unlockPostSaving('aimogen-ai-editor');
                }
            } catch (error) {
                // The request is already finished; continue removing the interaction lock.
            }
            postSavingLocked = false;
        }

        if (commitOverlay) {
            if (commitOverlay.parentNode && typeof commitOverlay.parentNode.removeChild === 'function') {
                commitOverlay.parentNode.removeChild(commitOverlay);
            } else if (typeof commitOverlay.remove === 'function') {
                commitOverlay.remove();
            }
            commitOverlay = null;
        }

        if (commitPreviousFocus && typeof commitPreviousFocus.focus === 'function' &&
            (!document.contains || document.contains(commitPreviousFocus))) {
            commitPreviousFocus.focus();
        }
        commitPreviousFocus = null;
        commitActive = false;
    }

    /*
     * Wait for the block editor to go quiet after a save.
     *
     * savePost() resolves when the REST request is done, but Gutenberg then posts the
     * classic metabox form in a second request, and that request runs edit_post() -
     * it can rewrite post columns. Aimogen's own write has to come last, or a metabox
     * save lands on top of an applied value. Quiet is measured over several
     * consecutive checks so a metabox request that has not started yet is not
     * mistaken for one that has finished.
     */
    function waitForSaveToSettle(timeoutMs) {
        var deadline = Date.now() + (timeoutMs || 20000);

        function isQuiet() {
            try {
                var select = window.wp.data.select('core/editor');
                if (select && typeof select.isSavingPost === 'function' && select.isSavingPost()) {
                    return false;
                }
                var editPost = window.wp.data.select('core/edit-post');
                if (editPost && typeof editPost.isSavingMetaBoxes === 'function' && editPost.isSavingMetaBoxes()) {
                    return false;
                }
            } catch (error) {
                /* A store that is not registered cannot be saving anything. */
            }
            return true;
        }

        return new Promise(function (resolve) {
            var quiet = 0;
            var timer = window.setInterval(function () {
                quiet = isQuiet() ? quiet + 1 : 0;
                if (quiet >= 3 || Date.now() > deadline) {
                    window.clearInterval(timer);
                    resolve();
                }
            }, 120);
        });
    }

    /*
     * The values the server actually stored, taken from its own save response.
     *
     * Preferred over the editor's copy when rebasing stale-write protection: the save
     * filters can normalize markup on the way in, and the comparison that guard makes
     * server side is against the row, not against the screen.
     */
    function readSavedPostValues() {
        var out = {};
        var post;
        try {
            var select = window.wp.data.select('core/editor');
            post = select && typeof select.getCurrentPost === 'function' ? select.getCurrentPost() : null;
        } catch (error) {
            return out;
        }
        if (!post) {
            return out;
        }

        var columns = { post_title: 'title', post_content: 'content', post_excerpt: 'excerpt' };
        Object.keys(columns).forEach(function (fieldId) {
            var value = post[columns[fieldId]];
            /* context=edit gives {raw, rendered}; older shapes give a plain string. */
            if (value && typeof value === 'object') {
                value = typeof value.raw === 'string' ? value.raw : null;
            }
            if (typeof value === 'string') {
                out[fieldId] = value;
            }
        });
        return out;
    }

    /*
     * Clear the latched dirty flag whenever the block editor finishes a save of its
     * own, so pressing Update never leaves the panel believing there is still unsaved
     * work on the screen.
     */
    var blockEditorSaveWatchAttached = false;

    function watchBlockEditorSaves() {
        if (blockEditorSaveWatchAttached || boot.isBlockEditor === false ||
            !window.wp || !window.wp.data || typeof window.wp.data.subscribe !== 'function') {
            return;
        }

        var wasSaving = false;
        try {
            window.wp.data.subscribe(function () {
                var select = window.wp.data.select('core/editor');
                if (!select || typeof select.isSavingPost !== 'function') {
                    return;
                }
                var autosaving = typeof select.isAutosavingPost === 'function' && select.isAutosavingPost();
                var saving = select.isSavingPost() && !autosaving;
                if (wasSaving && !saving) {
                    var failed = typeof select.didPostSaveRequestFail === 'function' &&
                        select.didPostSaveRequestFail();
                    if (!failed) {
                        markSaved();
                    }
                }
                wasSaving = saving;
            });
            blockEditorSaveWatchAttached = true;
        } catch (error) {
            /* A partial wp.data shim from another plugin just keeps the flag latched,
               which is the conservative behaviour rather than a broken one. */
        }
    }

    /* This file is enqueued without dependencies, so wp.data need not exist yet when
       it evaluates. Retry where the editor bundle is certainly loaded; attaching is
       idempotent, and the subscriber tolerates a store that registers later still. */
    watchBlockEditorSaves();
    if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
        document.addEventListener('DOMContentLoaded', watchBlockEditorSaves);
        window.addEventListener('load', watchBlockEditorSaves);
    }

    function request(action, payload) {
        if (inFlight[action]) {
            return Promise.reject(new Error('busy'));
        }
        inFlight[action] = true;

        var body = new window.FormData();
        body.append('action', action);
        body.append('nonce', boot.nonce);
        body.append('post_id', boot.postId);
        appendPayload(body, payload, null);

        return window.fetch(boot.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: body
        }).then(function (response) {
            return response.json().catch(function () {
                throw new Error(boot.i18n.requestFailed);
            });
        }).then(function (json) {
            if (!json || json.success !== true) {
                var message = (json && json.data && json.data.message)
                    ? json.data.message
                    : boot.i18n.requestFailed;
                var responseError = new Error(message);
                responseError.aimogenResponseReceived = true;
                throw responseError;
            }
            return json.data;
        }).finally(function () {
            inFlight[action] = false;
        });
    }

    /* Flatten nested objects/arrays into PHP's fields[key] form. */
    function appendPayload(body, value, prefix) {
        if (value === null || value === undefined) {
            return;
        }
        if (Array.isArray(value)) {
            value.forEach(function (item) {
                body.append(prefix + '[]', item);
            });
            return;
        }
        if (typeof value === 'object') {
            Object.keys(value).forEach(function (key) {
                var name = prefix ? prefix + '[' + key + ']' : key;
                appendPayload(body, value[key], name);
            });
            return;
        }
        body.append(prefix, value);
    }

    /*
     * Reading and writing the live editor.
     *
     * Gutenberg keeps the post in the core/editor data store; the classic editor keeps
     * it in form inputs plus, when the visual tab is active, a TinyMCE instance. Both
     * can hold work the user has not saved, so generation reads their live values and
     * database writes are blocked until the editor is clean.
     */
    var editorBridge = {

        beginCommit: beginCommit,

        endCommit: endCommit,

        isBlockEditor: function () {
            /* The server already knows which editor rendered the screen; trusting it
               first stops a classic page from ever reaching into the block store
               because some other plugin happened to register wp.data. */
            if (boot.isBlockEditor === false) {
                return false;
            }
            return !!(
                window.wp &&
                window.wp.data &&
                typeof window.wp.data.select === 'function' &&
                window.wp.data.select('core/editor')
            );
        },

        hasClassicEditor: function () {
            return !!document.getElementById('title') || !!document.getElementById('content');
        },

        /*
         * Whether the open editor holds edits that have not been saved.
         *
         * Matters before running a whole template: that runs server side against the
         * last saved version and then rewrites the row, so anything unsaved in the
         * browser is about to be discarded. Better to say so first.
         */
        isDirty: function () {
            if (this.isBlockEditor()) {
                var sel = window.wp.data.select('core/editor');
                if (sel && (
                    (typeof sel.isEditedPostDirty === 'function' && sel.isEditedPostDirty()) ||
                    (typeof sel.isSavingPost === 'function' && sel.isSavingPost()) ||
                    (typeof sel.isAutosavingPost === 'function' && sel.isAutosavingPost())
                )) {
                    return true;
                }
            } else if (window.wp && window.wp.autosave && window.wp.autosave.server &&
                typeof window.wp.autosave.server.postChanged === 'function') {
                try {
                    if (window.wp.autosave.server.postChanged()) {
                        return true;
                    }
                } catch (error) {
                    /* Some Classic Editor replacements expose only part of the
                       autosave object. Continue with the framework-neutral checks. */
                }
            }

            /* TinyMCE is also used by ACF, JetEngine and many bespoke metaboxes. Check
               every mounted instance, not only WordPress's main content editor. */
            var tinyMceEditors = window.tinymce && window.tinymce.editors;
            if (tinyMceEditors) {
                var editorKeys = typeof tinyMceEditors.length === 'number'
                    ? Array.prototype.map.call(tinyMceEditors, function (editor, index) { return index; })
                    : Object.keys(tinyMceEditors);
                if (editorKeys.some(function (key) {
                    return tinyMceEditorIsDirty(tinyMceEditors[key]);
                })) {
                    return true;
                }
            }

            /* Older TinyMCE builds may not expose the editors collection. */
            var contentEditor = window.tinymce && typeof window.tinymce.get === 'function'
                ? window.tinymce.get('content')
                : null;
            if (tinyMceEditorIsDirty(contentEditor)) {
                return true;
            }

            return externalDirty;
        },

        /*
         * Whether the editor can persist the screen without navigating away.
         *
         * Gutenberg can: savePost() writes the post and its metaboxes in place. The
         * classic editor cannot - its metaboxes only reach the database by submitting
         * the whole form - so callers have to take the reload route there instead.
         */
        canSaveInPlace: function () {
            if (!this.isBlockEditor()) {
                return false;
            }
            try {
                var dispatcher = window.wp.data.dispatch('core/editor');
                return !!(dispatcher && typeof dispatcher.savePost === 'function');
            } catch (error) {
                return false;
            }
        },

        /*
         * Save the user's unsaved work in place, then report what the server stored.
         *
         * Apply and Undo both write to the post and reload the page afterwards, so
         * unsaved work on the screen would be lost. Rather than refusing and asking
         * the user to go and press Update, the panel saves for them.
         *
         * Resolves with { saved, clean, stored }:
         *   saved  the post reached the database
         *   clean  nothing re-dirtied the editor while it was saving, so the row and
         *          the screen still agree and `stored` can be trusted as a baseline
         *   stored post_title/post_content/post_excerpt exactly as the server kept them
         */
        save: function () {
            if (!this.canSaveInPlace()) {
                return Promise.resolve({ saved: false, clean: false, stored: {} });
            }

            var dispatcher = window.wp.data.dispatch('core/editor');
            var selector = window.wp.data.select('core/editor');

            /* Another plugin can hold the post closed for saving - an unfinished
               required field, a validation gate. savePost() does not refuse the write
               itself, it just would not stick, so treat the lock as a failed save and
               say so rather than applying on top of a post that never saved. */
            try {
                if (selector && typeof selector.isPostSavingLocked === 'function' &&
                    selector.isPostSavingLocked()) {
                    return Promise.resolve({ saved: false, clean: false, stored: {} });
                }
                if (selector && typeof selector.isEditedPostSaveable === 'function' &&
                    !selector.isEditedPostSaveable()) {
                    return Promise.resolve({ saved: false, clean: false, stored: {} });
                }
            } catch (error) {
                /* A selector this build does not have tells us nothing; carry on. */
            }

            return Promise.resolve()
                .then(function () {
                    return dispatcher.savePost();
                })
                .then(function () {
                    return waitForSaveToSettle();
                })
                .then(function () {
                    if (selector && typeof selector.didPostSaveRequestFail === 'function' &&
                        selector.didPostSaveRequestFail()) {
                        return { saved: false, clean: false, stored: {} };
                    }
                    markSaved();
                    var stillDirty = !!(selector && typeof selector.isEditedPostDirty === 'function' &&
                        selector.isEditedPostDirty());
                    return {
                        saved: true,
                        clean: !stillDirty,
                        stored: readSavedPostValues()
                    };
                })
                .catch(function () {
                    return { saved: false, clean: false, stored: {} };
                });
        },

        /*
         * Classic editor: hand the save to WordPress's own submit button.
         *
         * Clicking the real button rather than calling form.submit() keeps every
         * handler WordPress and other plugins bound to it - TinyMCE's triggerSave
         * among them. Save Draft is preferred when it exists so a draft is never
         * published as a side effect of applying an edit; a published post only has
         * Update, which is what it should get.
         *
         * Returns true once the submit is under way, which means the page is about to
         * navigate and the caller must stop.
         */
        submitSave: function () {
            if (this.isBlockEditor() || !document.getElementById('post')) {
                return false;
            }
            var button = document.getElementById('save-post') || document.getElementById('publish');
            if (!button || typeof button.click !== 'function' || button.disabled) {
                return false;
            }
            button.click();
            return true;
        },

        getValues: function () {
            var values = {};

            if (this.isBlockEditor()) {
                var editor = window.wp.data.select('core/editor');
                values.post_title = editor.getEditedPostAttribute('title') || '';
                values.post_content = editor.getEditedPostAttribute('content') || '';
                values.post_excerpt = editor.getEditedPostAttribute('excerpt') || '';
                return values;
            }

            var titleField = document.getElementById('title');
            if (titleField) {
                values.post_title = titleField.value;
            }
            var excerptField = document.getElementById('excerpt');
            if (excerptField) {
                values.post_excerpt = excerptField.value;
            }

            var tinymce = window.tinymce && window.tinymce.get('content');
            if (tinymce && !tinymce.isHidden()) {
                values.post_content = tinymce.getContent();
            } else {
                var contentField = document.getElementById('content');
                if (contentField) {
                    values.post_content = contentField.value;
                }
            }

            return values;
        },

        /*
         * Push a value into the editor. Returns true when the editor took ownership,
         * false when the caller must persist it server side instead.
         */
        setValue: function (fieldId, value) {
            if (fieldId !== 'post_title' && fieldId !== 'post_content' && fieldId !== 'post_excerpt') {
                return false;
            }

            if (this.isBlockEditor()) {
                var dispatch = window.wp.data.dispatch('core/editor');
                if (!dispatch || typeof dispatch.editPost !== 'function') {
                    return false;
                }

                /*
                 * Content is a special case. The canvas renders the parsed block list,
                 * not the raw content string, so editPost({content}) alone changes what
                 * would be saved while leaving the visible blocks stale - the user sees
                 * their old text and has no idea the change landed. Parsing the new
                 * content and resetting the block list updates both.
                 */
                if (fieldId === 'post_content') {
                    var blocks = window.wp.blocks;
                    if (blocks && typeof blocks.parse === 'function' && typeof dispatch.resetEditorBlocks === 'function') {
                        var parsed = blocks.parse(value);
                        /*
                         * parse() returns [] when no block types are registered yet,
                         * whatever it was given. Resetting to an empty list would wipe
                         * the post body outright, so an empty parse of non-empty
                         * content is treated as a parser failure, not as a result.
                         */
                        if (parsed && parsed.length) {
                            dispatch.resetEditorBlocks(parsed);
                            return true;
                        }
                    }
                    dispatch.editPost({ content: value });
                    return true;
                }

                /* editPost marks the post dirty, so the normal Update button becomes
                   the save action - the panel never saves the post behind the user. */
                dispatch.editPost(
                    fieldId === 'post_title' ? { title: value } : { excerpt: value }
                );
                return true;
            }

            if (fieldId === 'post_title') {
                var titleField = document.getElementById('title');
                if (!titleField) {
                    return false;
                }
                titleField.value = value;
                /* Nudge the classic editor's own "title has content" handling. */
                if (window.jQuery) {
                    window.jQuery(titleField).trigger('input').trigger('change');
                }
                if (window.wp && window.wp.autosave) {
                    // no-op: keeps autosave's dirty tracking consistent
                }
                return true;
            }

            if (fieldId === 'post_excerpt') {
                var excerptField = document.getElementById('excerpt');
                if (!excerptField) {
                    return false;
                }
                excerptField.value = value;
                if (window.jQuery) {
                    window.jQuery(excerptField).trigger('change');
                }
                return true;
            }

            var tinymce = window.tinymce && window.tinymce.get('content');
            if (tinymce && !tinymce.isHidden()) {
                tinymce.setContent(value);
                tinymce.undoManager.add();
                tinymce.setDirty(true);
                return true;
            }
            var contentField = document.getElementById('content');
            if (contentField) {
                contentField.value = value;
                if (window.jQuery) {
                    window.jQuery(contentField).trigger('change');
                }
                return true;
            }

            return false;
        },

        /*
         * Legacy compatibility bridge for callers that still synchronize an open
         * custom-field control. The primary Apply/Undo workflow reloads from storage
         * and no longer depends on recognizing a framework's DOM. This bridge still
         * supports WordPress native rows and known JetEngine controls without making
         * unsafe global id/name guesses.
         *
         * Returns true only when a matching control was synchronized. A missing or
         * failed editor bridge returns false so the UI can tell the user to reload
         * before their next save.
        */
        syncStoredValue: function (fieldId, value) {
            if (typeof fieldId !== 'string' || fieldId.indexOf('meta:') !== 0) {
                return false;
            }

            var metaKey = fieldId.slice(5);
            var storedValue = value === null || value === undefined ? '' : String(value);
            var controls = [];
            var synchronizationFailed = false;

            function addControl(control) {
                if (!control || controls.indexOf(control) !== -1) {
                    return;
                }
                var tagName = String(control.tagName || '').toLowerCase();
                if (tagName === 'input' || tagName === 'textarea' || tagName === 'select') {
                    controls.push(control);
                }
            }

            var metaBox = document.getElementById('postcustomstuff');
            if (metaBox) {
                var keyFields = metaBox.querySelectorAll('input[name^="meta["][name$="][key]"]');

                for (var i = 0; i < keyFields.length; i++) {
                    var keyField = keyFields[i];
                    if (keyField.value !== metaKey) {
                        continue;
                    }

                    var match = /^meta\[(\d+)\]\[key\]$/.exec(keyField.name || '');
                    var row = typeof keyField.closest === 'function' ? keyField.closest('tr') : null;
                    if (!match || !row) {
                        continue;
                    }

                    addControl(row.querySelector('[name="meta[' + match[1] + '][value]"]'));
                }
            }

            /* Do not interpolate the key into a CSS selector: valid WordPress meta
               keys may contain characters with special selector meaning. Comparing
               DOM properties keeps the lookup exact without an escaping dependency. */
            if (typeof document.querySelectorAll === 'function') {
                var customFields = document.querySelectorAll('input, textarea, select');
                var bracketedName = '[' + metaKey + ']';
                for (var j = 0; j < customFields.length; j++) {
                    var customField = customFields[j];
                    /* Native rows are handled above by matching the row's key. Their
                       generic names all end in [key] or [value], so allowing them into
                       this fallback would corrupt every row for meta keys literally
                       named "key" or "value". */
                    if (metaBox && typeof metaBox.contains === 'function' && metaBox.contains(customField)) {
                        continue;
                    }
                    var controlName = String(customField.name || '');
                    var controlId = String(customField.id || '');
                    var hasBracketedName = controlName.length >= bracketedName.length &&
                        controlName.slice(-bracketedName.length) === bracketedName;
                    /* The customer implementation shown here is JetEngine, which
                       gives its controls an ownership wrapper. Even exact ids such as
                       "content", "post_ID" or "action" are unsafe globally because
                       WordPress itself uses them. Only synchronize a custom control
                       after positively identifying that wrapper. */
                    var isJetEngineField = typeof customField.closest === 'function' &&
                        !!customField.closest('.jet-engine-meta-wrap');
                    if (isJetEngineField && (controlId === metaKey || controlName === metaKey || hasBracketedName)) {
                        addControl(customField);
                    }
                }
            } else {
                var fallbackField = document.getElementById(metaKey);
                if (fallbackField && typeof fallbackField.closest === 'function' && fallbackField.closest('.jet-engine-meta-wrap')) {
                    addControl(fallbackField);
                }
            }

            for (var k = 0; k < controls.length; k++) {
                var valueField = controls[k];
                var inputType = String(valueField.type || '').toLowerCase();
                if (inputType === 'checkbox' || inputType === 'radio') {
                    valueField.checked = String(valueField.value) === storedValue;
                } else {
                    valueField.value = storedValue;

                    /* WordPress WYSIWYG meta fields keep their authoritative editing
                       state in TinyMCE while the Visual tab is active. Updating only
                       the backing textarea looks successful in the DOM, but TinyMCE
                       writes its old content back into that textarea when the post is
                       saved. Keep both representations in lockstep. */
                    try {
                        var editorId = String(valueField.id || '');
                        var richEditor = editorId &&
                            String(valueField.tagName || '').toLowerCase() === 'textarea' &&
                            window.tinymce &&
                            typeof window.tinymce.get === 'function'
                            ? window.tinymce.get(editorId)
                            : null;
                        if (richEditor && typeof richEditor.setContent === 'function') {
                            withDirtyTrackingSuppressed(function () {
                                richEditor.setContent(storedValue);
                                if (richEditor.undoManager && typeof richEditor.undoManager.add === 'function') {
                                    richEditor.undoManager.add();
                                }
                                if (typeof richEditor.setDirty === 'function') {
                                    richEditor.setDirty(true);
                                }
                                if (typeof richEditor.save === 'function') {
                                    richEditor.save();
                                }
                            });
                        }
                    } catch (error) {
                        /* The database write already succeeded. Convert a detached or
                           broken editor instance into the existing reload warning
                           instead of turning the completed request into a false AJAX
                           failure and leaving the stale editor silently active. */
                        synchronizationFailed = true;
                    }
                }

                ['input', 'change'].forEach(function (eventName) {
                    var event;
                    if (typeof window.Event === 'function') {
                        event = new window.Event(eventName, { bubbles: true });
                    } else {
                        event = document.createEvent('Event');
                        event.initEvent(eventName, true, false);
                    }
                    withDirtyTrackingSuppressed(function () {
                        valueField.dispatchEvent(event);
                    });
                });
            }

            if (controls.length) {
                return !synchronizationFailed;
            }
            return false;
        }
    };

    /*
     * Panel state. Generation never touches the database. The UI normally owns this
     * state in memory and temporarily mirrors a bounded copy to per-tab sessionStorage
     * only when a safe reload/recovery path requires it.
     */
    function createState() {
        return {
            selected: {},          /* field id -> true */
            perField: {},          /* field id -> instruction override */
            perFieldOpen: {},      /* field id -> override box is visible */
            newFields: {},         /* field id -> meta key the panel is asking to create */
            newFieldKey: '',       /* what is typed in the "add a custom field" box */
            instruction: '',
            presetId: 'custom',
            templateId: '',
            useContext: true,
            model: '',
            temperature: '',
            advancedOpen: false,
            proposals: [],         /* ordered list from the last generate */
            decisions: {},         /* field id -> 'accepted' | 'ignored' */
            fieldErrors: {},
            status: 'idle',        /* idle | generating | generated | applying | applied | failed */
            message: '',
            messageKind: 'info',
            busyField: '',
            models: null,
            canUndo: !!boot.canUndo,
            lastChange: boot.lastChange || null,

            /* Template runner: the legacy whole-template path, which applies and
               saves in one go rather than proposing changes for review. */
            runnerTemplateId: '',
            runnerStatus: 'idle',   /* idle | running | done | failed */
            runnerMessage: '',
            marked: !!boot.marked,
            markerBusy: false
        };
    }

    window.AimogenAiEditor = {
        boot: boot,
        request: request,
        editor: editorBridge,
        createState: createState
    };

})(window);
