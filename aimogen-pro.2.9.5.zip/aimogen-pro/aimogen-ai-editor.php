<?php
/*
 * Aimogen AI Editor - interactive, review-before-apply editing of EXISTING content.
 *
 * This module is deliberately separate from aiomatic_do_post() (aiomatic-do-post.php).
 * That function is the shared automation engine: cron (aiomaticeditaction),
 * transition_post_status, bulk processing, agents, god-mode and WP-CLI all call it,
 * and it generates + applies + saves in a single pass. Teaching it a preview stage
 * would change behaviour for every one of those callers, so this module reuses the
 * plugin's generation primitives instead and leaves the automation path untouched.
 *
 * The legacy "Aimogen AI Content Editor" metabox and the aiomatic-sidebar Gutenberg
 * panel keep working unchanged; saved templates are reused here as presets.
 */

defined('ABSPATH') or die();

if (!defined('AIMOGEN_AI_EDITOR_NONCE')) {
    define('AIMOGEN_AI_EDITOR_NONCE', 'aimogen_ai_editor');
}
/* Meta key holding the undo snapshots. Underscore-prefixed so the field discovery
   in aimogen-ai-editor-fields.php treats it as protected and never offers it. */
if (!defined('AIMOGEN_AI_EDITOR_HISTORY_META')) {
    define('AIMOGEN_AI_EDITOR_HISTORY_META', '_aimogen_ai_editor_history');
}
if (!defined('AIMOGEN_AI_EDITOR_HISTORY_MAX_ENTRIES')) {
    define('AIMOGEN_AI_EDITOR_HISTORY_MAX_ENTRIES', 3);
}
/* Total serialized budget for one post's snapshot history. Post content can be huge,
   so undo keeps a small bounded window rather than an unlimited archive. */
if (!defined('AIMOGEN_AI_EDITOR_HISTORY_MAX_BYTES')) {
    define('AIMOGEN_AI_EDITOR_HISTORY_MAX_BYTES', 1048576);
}
/* Meta values longer than this are treated as blobs/documents, not editable content. */
if (!defined('AIMOGEN_AI_EDITOR_MAX_META_LENGTH')) {
    define('AIMOGEN_AI_EDITOR_MAX_META_LENGTH', 50000);
}
if (!defined('AIMOGEN_AI_EDITOR_MAX_FIELDS')) {
    define('AIMOGEN_AI_EDITOR_MAX_FIELDS', 100);
}
/* Characters of post_content used as prompt context when the content itself is not
   the field being rewritten. Keeps payloads sane on very long articles. */
if (!defined('AIMOGEN_AI_EDITOR_CONTEXT_CONTENT_CHARS')) {
    define('AIMOGEN_AI_EDITOR_CONTEXT_CONTENT_CHARS', 6000);
}

require_once(dirname(__FILE__) . '/aimogen-ai-editor-fields.php');
require_once(dirname(__FILE__) . '/aimogen-ai-editor-prompt.php');
require_once(dirname(__FILE__) . '/aimogen-ai-editor-engine.php');
require_once(dirname(__FILE__) . '/aimogen-ai-editor-apply.php');
require_once(dirname(__FILE__) . '/aimogen-ai-editor-ajax.php');

/**
 * Whether the interactive editor should be offered at all.
 *
 * Mirrors the gate used by the legacy metabox so a site that turned the post editor
 * integration off does not suddenly grow a new panel.
 */
function aimogen_ai_editor_is_enabled()
{
    $settings = get_option('aiomatic_Main_Settings', false);
    if (!is_array($settings)) {
        return false;
    }
    if (!isset($settings['aiomatic_enabled']) || $settings['aiomatic_enabled'] !== 'on') {
        return false;
    }
    if (isset($settings['no_post_editor']) && $settings['no_post_editor'] === 'on') {
        return false;
    }
    if (isset($settings['no_ai_editor_panel']) && $settings['no_ai_editor_panel'] === 'on') {
        return false;
    }
    return (bool) apply_filters('aimogen_ai_editor_enabled', true);
}

/**
 * Post types the interactive editor is offered on.
 *
 * Deliberately not a hardcoded post/page list: every editable post type qualifies,
 * minus the plugin's own internal CPTs (the same exclusion set the legacy metabox
 * and aiomatic_do_post() use).
 */
function aimogen_ai_editor_supports_post_type($post_type)
{
    $post_type = (string) $post_type;
    if ($post_type === '') {
        return false;
    }
    $never = array(
        'attachment',
        'revision',
        'nav_menu_item',
        'wp_block',
        'wp_template',
        'wp_template_part',
        'wp_navigation',
        'wp_global_styles',
        'custom_css',
        'customize_changeset',
        'oembed_cache',
        'user_request',

        /* WooCommerce transactional records. They are post types, so they would
           otherwise qualify, but an order or a coupon is commerce data rather than
           editorial content - there is nothing here an AI rewrite should touch.
           Products themselves stay supported. */
        'shop_order',
        'shop_order_refund',
        'shop_order_placehold',
        'shop_coupon',
        'shop_subscription',
        'product_variation',
        'wc_order_email',
    );
    if (in_array($post_type, $never, true)) {
        return false;
    }
    if (strpos($post_type, 'aiomatic_') === 0 || strpos($post_type, 'aimogen_') === 0) {
        return false;
    }
    if (defined('AIMOGEN_EXCEPTED_POST_TYPES_FROM_EDITING') && in_array($post_type, AIMOGEN_EXCEPTED_POST_TYPES_FROM_EDITING, true)) {
        return false;
    }
    $object = get_post_type_object($post_type);
    if ($object === null || empty($object->show_ui)) {
        return false;
    }
    return (bool) apply_filters('aimogen_ai_editor_supports_post_type', true, $post_type);
}

/**
 * Resolve the post being edited on a post edit screen, or null.
 */
function aimogen_ai_editor_current_post()
{
    if (!is_admin() || !function_exists('get_current_screen')) {
        return null;
    }
    $screen = get_current_screen();
    if ($screen === null || $screen->base !== 'post' || $screen->action === 'add') {
        return null;
    }
    $post = get_post();
    if (!($post instanceof WP_Post) || empty($post->ID)) {
        return null;
    }
    if (!aimogen_ai_editor_supports_post_type($post->post_type)) {
        return null;
    }
    if (!current_user_can('edit_post', $post->ID)) {
        return null;
    }
    return $post;
}

function aimogen_ai_editor_is_block_editor()
{
    if (!function_exists('get_current_screen')) {
        return false;
    }
    $screen = get_current_screen();
    if ($screen === null) {
        return false;
    }
    if (method_exists($screen, 'is_block_editor')) {
        return (bool) $screen->is_block_editor();
    }
    return false;
}

/**
 * Meta key marking a post as already edited by Aimogen.
 *
 * The key is configurable in the AI Content Editor settings and may carry a date
 * placeholder, so it has to be derived rather than hardcoded. Same resolution the
 * legacy metabox and aiomatic_do_post() use.
 */
function aimogen_ai_editor_marker_meta_key()
{
    $spinner = get_option('aiomatic_Spinner_Settings', false);
    if (is_array($spinner) && isset($spinner['custom_name']) && trim($spinner['custom_name']) !== '') {
        $key = trim($spinner['custom_name']);
        return str_replace('%%current_date%%', date('Y-m-d'), $key);
    }
    return 'aiomatic_published';
}

/**
 * Whether this post is currently marked as edited by Aimogen.
 */
function aimogen_ai_editor_is_marked_edited($post_id)
{
    return get_post_meta((int) $post_id, aimogen_ai_editor_marker_meta_key(), true) === 'pub';
}

/**
 * Flip the marker. Returns the new state ('pub' or '').
 */
function aimogen_ai_editor_toggle_marker($post_id)
{
    $post_id = (int) $post_id;
    $key = aimogen_ai_editor_marker_meta_key();
    if (get_post_meta($post_id, $key, true) === 'pub') {
        delete_post_meta($post_id, $key);
        return '';
    }
    update_post_meta($post_id, $key, 'pub');
    return 'pub';
}

/**
 * Data handed to the browser. Carries no API keys and no provider configuration:
 * everything the model needs stays server side.
 */
function aimogen_ai_editor_boot_data($post)
{
    $fields = aimogen_ai_editor_get_available_fields($post);

    return array(
        'ajaxUrl'    => admin_url('admin-ajax.php'),
        'nonce'      => wp_create_nonce(AIMOGEN_AI_EDITOR_NONCE),
        'postId'     => (int) $post->ID,
        'postType'   => $post->post_type,
        'fields'     => aimogen_ai_editor_fields_for_client($fields),
        'presets'    => aimogen_ai_editor_get_presets(),
        'templates'  => aimogen_ai_editor_get_template_choices(),
        'hasAcf'     => aimogen_ai_editor_acf_active(),
        'canUndo'    => aimogen_ai_editor_has_history((int) $post->ID),
        'lastChange' => aimogen_ai_editor_last_history_summary((int) $post->ID),
        'isBlockEditor' => aimogen_ai_editor_is_block_editor(),
        'marked'     => aimogen_ai_editor_is_marked_edited((int) $post->ID),
        'canRunTemplates' => function_exists('aiomatic_do_post'),
        'i18n'       => aimogen_ai_editor_strings(),
    );
}

function aimogen_ai_editor_strings()
{
    return array(
        'panelTitle'      => __('Aimogen AI Editor', 'aiomatic-automatic-ai-content-writer'),
        'whatToChange'    => __('What should Aimogen change?', 'aiomatic-automatic-ai-content-writer'),
        'coreFields'      => __('Post fields', 'aiomatic-automatic-ai-content-writer'),
        'metaFields'      => __('Custom fields', 'aiomatic-automatic-ai-content-writer'),
        'acfFields'       => __('Advanced Custom Fields', 'aiomatic-automatic-ai-content-writer'),
        'noCustomFields'  => __('No editable custom fields were found on this post.', 'aiomatic-automatic-ai-content-writer'),
        /* Naming a custom field the post does not have yet. The key is re-checked
           server side on every request, so these are labels, not permissions. */
        'newFieldTitle'   => __('Add a custom field', 'aiomatic-automatic-ai-content-writer'),
        'newFieldPlaceholder' => __('custom_field_key', 'aiomatic-automatic-ai-content-writer'),
        'newFieldAdd'     => __('Add', 'aiomatic-automatic-ai-content-writer'),
        'newFieldHint'    => __('Name a custom field this post does not have yet. Aimogen writes the value when you apply the change.', 'aiomatic-automatic-ai-content-writer'),
        'newFieldBadge'   => __('will be created', 'aiomatic-automatic-ai-content-writer'),
        'newFieldRemove'  => __('Remove this custom field', 'aiomatic-automatic-ai-content-writer'),
        'newFieldInvalid' => __('A custom field key must start with a letter and contain only letters, numbers, hyphens and underscores.', 'aiomatic-automatic-ai-content-writer'),
        'newFieldExists'  => __('This post already has that custom field, so it has been selected for you.', 'aiomatic-automatic-ai-content-writer'),
        'instruction'     => __('Instruction', 'aiomatic-automatic-ai-content-writer'),
        'instructionHint' => __('Improve this content while keeping the meaning. Make it clearer and more concise.', 'aiomatic-automatic-ai-content-writer'),
        'perFieldAdd'     => __('Add a separate instruction for this field', 'aiomatic-automatic-ai-content-writer'),
        'perFieldHint'    => __('Leave empty to use the main instruction.', 'aiomatic-automatic-ai-content-writer'),
        'useTemplate'     => __('Use saved template', 'aiomatic-automatic-ai-content-writer'),
        'noTemplate'      => __('None', 'aiomatic-automatic-ai-content-writer'),
        'templateLoaded'  => __('Instruction loaded from the saved template. You can edit it before generating.', 'aiomatic-automatic-ai-content-writer'),
        'generate'        => __('Generate Changes', 'aiomatic-automatic-ai-content-writer'),
        'generating'      => __('Generating…', 'aiomatic-automatic-ai-content-writer'),
        'generated'       => __('Generated', 'aiomatic-automatic-ai-content-writer'),
        'applying'        => __('Applying…', 'aiomatic-automatic-ai-content-writer'),
        'applied'         => __('Applied', 'aiomatic-automatic-ai-content-writer'),
        'failed'          => __('Failed', 'aiomatic-automatic-ai-content-writer'),
        'advanced'        => __('Advanced Settings', 'aiomatic-automatic-ai-content-writer'),
        'useContext'      => __('Use current post as context', 'aiomatic-automatic-ai-content-writer'),
        'useContextHint'  => __('Sends the title, excerpt and a trimmed copy of the content so the AI understands what it is editing.', 'aiomatic-automatic-ai-content-writer'),
        'model'           => __('Model', 'aiomatic-automatic-ai-content-writer'),
        'defaultModel'    => __('Use Aimogen default', 'aiomatic-automatic-ai-content-writer'),
        'loadingModels'   => __('Loading models…', 'aiomatic-automatic-ai-content-writer'),
        'creativity'      => __('Creativity', 'aiomatic-automatic-ai-content-writer'),
        'proposedChanges' => __('Proposed changes', 'aiomatic-automatic-ai-content-writer'),
        'current'         => __('Current', 'aiomatic-automatic-ai-content-writer'),
        'proposed'        => __('Proposed', 'aiomatic-automatic-ai-content-writer'),
        'accept'          => __('Accept', 'aiomatic-automatic-ai-content-writer'),
        'accepted'        => __('Accepted', 'aiomatic-automatic-ai-content-writer'),
        'ignore'          => __('Ignore', 'aiomatic-automatic-ai-content-writer'),
        'ignored'         => __('Ignored', 'aiomatic-automatic-ai-content-writer'),
        'regenerate'      => __('Regenerate', 'aiomatic-automatic-ai-content-writer'),
        'applyAccepted'   => __('Apply Accepted Changes', 'aiomatic-automatic-ai-content-writer'),
        'discard'         => __('Discard proposals', 'aiomatic-automatic-ai-content-writer'),
        'undo'            => __('Undo last Aimogen change', 'aiomatic-automatic-ai-content-writer'),
        'undoing'         => __('Undoing…', 'aiomatic-automatic-ai-content-writer'),
        'noFields'        => __('Select at least one field to edit.', 'aiomatic-automatic-ai-content-writer'),
        'noInstruction'   => __('Enter an instruction, or pick a preset or saved template.', 'aiomatic-automatic-ai-content-writer'),
        'nothingAccepted' => __('Accept at least one proposed change first.', 'aiomatic-automatic-ai-content-writer'),
        'nothingApplied'  => __('Nothing was applied.', 'aiomatic-automatic-ai-content-writer'),
        /* Unsaved work no longer stops Apply and Undo: the panel saves the post
           itself first. These two cover the save the panel could not make -
           a classic editor with no session storage to park the review in, or an
           editor that refused the save. */
        'savingFirst'     => __('Saving your unsaved changes first…', 'aiomatic-automatic-ai-content-writer'),
        'autoSaveFailed'  => __('Aimogen could not save the post automatically. Save or update it yourself, then try again.', 'aiomatic-automatic-ai-content-writer'),
        'saveBeforeApplyNoStorage' => __('Save or update the post first, then reload this page and generate the changes again.', 'aiomatic-automatic-ai-content-writer'),
        'saveBeforeUndo'  => __('Save or update the post, then reload this page before undoing an Aimogen change.', 'aiomatic-automatic-ai-content-writer'),
        'appliedReloaded' => __('Accepted changes were saved and the editor was reloaded from the database.', 'aiomatic-automatic-ai-content-writer'),
        'applyPartial'    => __('Some accepted changes could not be saved.', 'aiomatic-automatic-ai-content-writer'),
        'reviewStorageUnavailable' => __('Aimogen could not safely preserve this review for the required reload. Reload the page and try again.', 'aiomatic-automatic-ai-content-writer'),
        'applyUnknown'    => __('The save result could not be confirmed. The editor was reloaded to verify the stored values; review the restored proposals before retrying.', 'aiomatic-automatic-ai-content-writer'),
        'undoUnknown'     => __('The undo result could not be confirmed. The editor was reloaded to show the authoritative stored values.', 'aiomatic-automatic-ai-content-writer'),
        'committingChanges' => __('Saving Aimogen changes…', 'aiomatic-automatic-ai-content-writer'),
        'editorUpdated'   => __('Applied to the editor — press Update to save the post.', 'aiomatic-automatic-ai-content-writer'),
        'reloadRequired'  => __('Saved to the database, but the open editor still shows the old text. Reload this page before pressing Update, or your next save will overwrite the change.', 'aiomatic-automatic-ai-content-writer'),
        'savedDirectly'   => __('Custom field values were saved to the database straight away.', 'aiomatic-automatic-ai-content-writer'),
        'showDiff'        => __('Show differences', 'aiomatic-automatic-ai-content-writer'),
        'hideDiff'        => __('Hide differences', 'aiomatic-automatic-ai-content-writer'),
        'emptyValue'      => __('(empty)', 'aiomatic-automatic-ai-content-writer'),
        'blockWarning'    => __('This proposal changes the block structure of the content. Review it carefully before accepting.', 'aiomatic-automatic-ai-content-writer'),
        'unchanged'       => __('The AI returned this value unchanged.', 'aiomatic-automatic-ai-content-writer'),
        'noHistory'       => __('Nothing to undo.', 'aiomatic-automatic-ai-content-writer'),
        'confirmUndo'     => __('Restore the field values from before the last Aimogen change?', 'aiomatic-automatic-ai-content-writer'),
        'requestFailed'   => __('The request failed. Please try again.', 'aiomatic-automatic-ai-content-writer'),
        'undone'          => __('Previous values restored.', 'aiomatic-automatic-ai-content-writer'),
        'undoIncomplete'  => __('Some fields were not restored and remain available to retry.', 'aiomatic-automatic-ai-content-writer'),
        'reloadNeeded'    => __('Reload the editor to see the restored values.', 'aiomatic-automatic-ai-content-writer'),
        'customInstruction' => __('Custom instruction', 'aiomatic-automatic-ai-content-writer'),
        'runnerTitle'     => __('Run a saved template', 'aiomatic-automatic-ai-content-writer'),
        'runnerHint'      => __('Runs the whole template exactly as the scheduled editor does — images, taxonomies, SEO fields, slug and status included, not just the text fields above.', 'aiomatic-automatic-ai-content-writer'),
        'runnerWarning'   => __('This writes to the post immediately. There is no review step.', 'aiomatic-automatic-ai-content-writer'),
        'runnerTemplate'  => __('Template', 'aiomatic-automatic-ai-content-writer'),
        'runnerSaved'     => __('Use currently saved configuration', 'aiomatic-automatic-ai-content-writer'),
        'runnerRun'       => __('Process with Aimogen', 'aiomatic-automatic-ai-content-writer'),
        'runnerRunning'   => __('Processing… do not close this page', 'aiomatic-automatic-ai-content-writer'),
        'runnerDone'      => __('Done — reloading the editor…', 'aiomatic-automatic-ai-content-writer'),
        'runnerConfirm'   => __('Run this template on the post now? It will be rewritten and saved straight away.', 'aiomatic-automatic-ai-content-writer'),
        'runnerConfirmDirty' => __('You have unsaved changes. The template runs against the last saved version, and your unsaved edits will be lost. Continue?', 'aiomatic-automatic-ai-content-writer'),
        'runnerFailed'    => __('The template run failed. Check Activity and Logging for details.', 'aiomatic-automatic-ai-content-writer'),
        'statusTitle'     => __('Aimogen editing status', 'aiomatic-automatic-ai-content-writer'),
        'statusEdited'    => __('This post has been edited with Aimogen.', 'aiomatic-automatic-ai-content-writer'),
        'statusNotEdited' => __('This post has not been edited with Aimogen yet.', 'aiomatic-automatic-ai-content-writer'),
        'statusToggle'    => __('Toggle editing status', 'aiomatic-automatic-ai-content-writer'),
        'statusToggling'  => __('Updating…', 'aiomatic-automatic-ai-content-writer'),
        'statusConfirm'   => __('Change the Aimogen editing status of this post?', 'aiomatic-automatic-ai-content-writer'),
        'openEditor'      => __('Open AI Editor', 'aiomatic-automatic-ai-content-writer'),
        'docPanelHint'    => __('Edit this post’s fields with AI, review the changes, then apply them.', 'aiomatic-automatic-ai-content-writer'),
    );
}

/**
 * Register the panel. The classic editor gets a metabox; the block editor gets a
 * PluginSidebar, because __back_compat_meta_box metaboxes are hidden there.
 */
add_action('add_meta_boxes', 'aimogen_ai_editor_register_meta_box');
function aimogen_ai_editor_register_meta_box()
{
    if (!aimogen_ai_editor_is_enabled() || aimogen_ai_editor_is_block_editor()) {
        return;
    }
    $post = aimogen_ai_editor_current_post();
    if ($post === null) {
        return;
    }
    /*
     * Placed in the 'advanced' context rather than 'normal'.
     *
     * WordPress renders the whole 'normal' context before 'advanced', and plugins that
     * own the post type put their primary boxes in 'normal'/'high' - WooCommerce's
     * "Product data" among them. Sitting there pushed this panel above the box people
     * actually came to the screen to use. 'advanced'/'high' keeps it below those and
     * directly above the Aimogen AI Content Writer box, which is 'advanced'/'default'.
     */
    add_meta_box(
        'aimogen_ai_editor',
        esc_html__('Aimogen AI Editor', 'aiomatic-automatic-ai-content-writer'),
        'aimogen_ai_editor_render_meta_box',
        $post->post_type,
        'advanced',
        'high',
        array('__back_compat_meta_box' => true)
    );
}

function aimogen_ai_editor_render_meta_box($post)
{
    require(dirname(__FILE__) . '/res/admin/ai-editor-panel.php');
}

/**
 * Assets load on post edit screens only, and only for supported post types, so
 * nothing extra is added to the rest of wp-admin.
 */
function aimogen_ai_editor_asset_version($relative_path)
{
    $path = dirname(__FILE__) . '/' . ltrim((string) $relative_path, '/\\');
    $modified = is_file($path) ? filemtime($path) : false;
    return ($modified !== false) ? (string) $modified : AIMOGEN_MAJOR_VERSION;
}

add_action('admin_enqueue_scripts', 'aimogen_ai_editor_enqueue_assets');
function aimogen_ai_editor_enqueue_assets($hook)
{
    if ($hook !== 'post.php' || !aimogen_ai_editor_is_enabled()) {
        return;
    }
    $post = aimogen_ai_editor_current_post();
    if ($post === null) {
        return;
    }

    $base = plugin_dir_url(__FILE__);

    wp_enqueue_style(
        'aimogen-ai-editor',
        $base . 'styles/aimogen-ai-editor.css',
        array(),
        aimogen_ai_editor_asset_version('styles/aimogen-ai-editor.css')
    );
    wp_enqueue_script(
        'aimogen-ai-editor-core',
        $base . 'scripts/aimogen-ai-editor-core.js',
        array(),
        aimogen_ai_editor_asset_version('scripts/aimogen-ai-editor-core.js'),
        true
    );
    wp_enqueue_script(
        'aimogen-ai-editor-ui',
        $base . 'scripts/aimogen-ai-editor-ui.js',
        array('aimogen-ai-editor-core'),
        aimogen_ai_editor_asset_version('scripts/aimogen-ai-editor-ui.js'),
        true
    );
    wp_localize_script('aimogen-ai-editor-core', 'aimogenAiEditor', aimogen_ai_editor_boot_data($post));

    if (aimogen_ai_editor_is_block_editor()) {
        /* wp-editor and wp-components are declared because the sidebar reads
           PluginSidebar/PluginDocumentSettingPanel and Button off them. Relying on
           the block editor happening to enqueue them first would work today and
           break silently the moment that order changed. */
        wp_enqueue_script(
            'aimogen-ai-editor-sidebar',
            $base . 'scripts/aimogen-ai-editor-sidebar.js',
            array('aimogen-ai-editor-ui', 'wp-plugins', 'wp-element', 'wp-data', 'wp-editor', 'wp-components'),
            aimogen_ai_editor_asset_version('scripts/aimogen-ai-editor-sidebar.js'),
            true
        );
    }
}
