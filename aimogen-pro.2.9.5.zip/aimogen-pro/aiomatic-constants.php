<?php
defined('ABSPATH') or die();
if(!defined('AIMOGEN_ASSISTANTS_API_RETIRED'))
{
    define('AIMOGEN_ASSISTANTS_API_RETIRED', true);
}
if(!defined('AIMOGEN_DEFAULT_BIG_TIMEOUT'))
{
    define('AIMOGEN_MIGRATION_NOTICE_DATE', '3025-12-08');
    define('AIMOGEN_MIGRATION_CUTOFF_DATE', '3026-02-09');
    define('AIMOGEN_DEFAULT_BIG_TIMEOUT', 160);
    define('AIMOGEN_DEFAULT_MODEL', 'gpt-5-mini');
    define('AIMOGEN_DEFAULT_IMAGE_MODEL', 'gpt-image-2');
    define('AIMOGEN_MODELS', array('gpt-3.5-turbo-instruct'));
    define('AIMOGEN_NO_REASONING_MODELS', array());
    define('AIMOGEN_MODELS_CHAT', array('gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-luna', 'gpt-6-sol', 'gpt-4.1-mini', 'gpt-6-astra', 'gpt-5.6-luna', 'gpt-5.6-terra', 'gpt-5.6-sol', 'gpt-5.5', 'gpt-5.5-pro', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-pro', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5', 'gpt-5-2025-08-07', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5-mini', 'gpt-5-mini-2025-08-07', 'gpt-5-nano', 'gpt-5-nano-2025-08-07', 'gpt-4.1-mini-2025-04-14', 'gpt-4.1-nano', 'gpt-4.1-nano-2025-04-14', 'gpt-4.1', 'gpt-4.1-2025-04-14', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-1106', 'gpt-3.5-turbo-0125', 'gpt-4', 'gpt-4-0613', 'gpt-4-1106-preview', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-turbo-2024-04-09', 'gpt-4-turbo', 'gpt-4o', 'gpt-4o-2024-05-13', 'gpt-4o-2024-08-06', 'gpt-4o-2024-11-20', 'o1-pro', 'o3', 'o3-2025-04-16', 'o4-mini', 'o4-mini-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o3-pro', 'o3-pro-2025-06-10', 'gpt-5.3-codex'));
    define('AIMOGEN_MODELS_VISION', array('gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-luna', 'gpt-6-sol', 'gpt-5.6-luna', 'gpt-5.6-terra', 'gpt-5.6-sol', 'gpt-6-astra', 'gpt-5.5', 'gpt-5.5-pro', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-pro', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5', 'gpt-5-2025-08-07', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5-mini', 'gpt-5-mini-2025-08-07', 'gpt-5-nano', 'gpt-5-nano-2025-08-07', 'gpt-4-turbo-2024-04-09', 'gpt-4-turbo', 'gpt-4o', 'gpt-4o-2024-05-13', 'gpt-4o-2024-08-06', 'gpt-4o-2024-11-20', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.1-nano-2025-04-14', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-mini-2025-04-14', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview', 'o1', 'o1-2024-12-17'));
    define('AIMOGEN_MODELS_OLLAMA_VISION', array('llama3.2-vision', 'llava', 'llava-llama3', 'bakllava', 'moondream', 'llava-phi3', 'hhao/openbmb-minicpm-llama3-v-2_5', 'aiden_lu/minicpm-v2.6', 'minicpm-v', 'xuxx/minicpm2.6', 'benzie/llava-phi-3', 'mskimomadto/chat-gph-vision', 'xiayu/openbmb-minicpm-llama3-v-2_5', '0ssamaak0/xtuner-llava', 'srizon/pixie', 'jyan1/paligemma-mix-224', 'knoopx/llava-phi-2', 'nsheth/llama-3-lumimaid-8b-v0.1-iq-imatrix', 'rohithbojja/llava-med-v1.6', 'anas/video-llava', 'bigbug/minicpm-v2.5', 'qnguyen3/nanollava', 'knoopx/mobile-vlm',
'nsheth/llava-llama-3-8b-v1_1-int4', 'ManishThota/llava_next_video', 'mannix/llava-phi3', 'dimweb/bunny-llama3-8b-v', 'chatgph/gph-main', 'childof7sins/llava-llama3-f16', 'doreilly/minicpm26', 'zctech/x-ai-vis', 'rohithbojja/llava-med-v1.5', 'leilasultan/florencemed', 'HammerAI/openbmb-minicpm-llama3-v-2_5', 'knoopx/obsidian', 'ih0dl/ardo', 'ManishThota/llava-video-merge', 'ih0dl/octocore.multimodal.v0.1', 'sroecker/moondream', 'doreilly/minicpm26_q5_k_m', 'agurla/moondream', 'sparksammy/samantha-mixed', 'bfhui/smart-pig', 'darkneighbor667/prac04', 'astra/astralm2-7b', 'injoon5/shoe-explainer', 'doreilly/minicpm26_q4_k_m', 'archiea/dobie-em', 'giannisan/penny', 'chevalblanc/gpt-4o-mini', 'highsunz/llava', 'aratan/vision', 'bfhui/better-siri', 'mike/vision', 'pdevine/vision-test', 'rameshrajamani/vision', 'arkohut/minicpm-v', 'abhiraj/uml_reader', 'starsnatched/radiology', 'jmorgan/llava', 'zxf945/minicpm-v', 'sparksammy/micro-sep', 'AnonY0324/bunny-llama-3-8b', 'sparksammy/agsamantha', 'sparksammy/samantha-eggplant', 'darkneighbor667/prac03', 'bigbug/test', 'hhui/fan1.0'));
    define('AIMOGEN_ASSISTANT_MODELS', array('gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-nano', 'gpt-4o', 'gpt-4o-mini'));
    define('AIMOGEN_RETRIEVAL_MODELS', array('gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-luna', 'gpt-6-sol', 'gpt-5.6-luna', 'gpt-5.6-terra', 'gpt-5.6-sol', 'gpt-6-astra', 'gpt-5.5', 'gpt-5.5-pro', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-pro', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5', 'gpt-5-2025-08-07', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5-mini', 'gpt-5-mini-2025-08-07', 'gpt-5-nano', 'gpt-5-nano-2025-08-07', 'gpt-4-1106-preview', 'gpt-4-0125-preview', 'gpt-4-turbo-preview', 'gpt-4-turbo-2024-04-09', 'gpt-4-turbo', 'gpt-4o', 'gpt-4o-2024-05-13', 'gpt-4o-2024-08-06', 'gpt-4o-2024-11-20', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.1-nano-2025-04-14', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-mini-2025-04-14', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview', 'o1-pro', 'o3', 'o3-2025-04-16', 'o4-mini', 'o4-mini-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o3-pro', 'o3-pro-2025-06-10'));
    define('AIMOGEN_PERPLEXITY_MODELS', array('sonar', 'sonar-pro', 'sonar-reasoning', 'sonar-reasoning-pro', 'sonar-deep-research'));
    define('AIMOGEN_EDIT_MODELS', array());
    define('AIMOGEN_DEFAULT_VIDEO_MODEL', 'sora-2');
    define('AIMOGEN_MODELS_VIDEO', array('sora-2', 'sora-2-pro'));
    define('AIMOGEN_MODELS_VIDEO_PARAMS', array(
        'sora-2' => array(
            'durations' => [ 4, 8, 12 ],
            'unit' => 'second',
            'resolutions' => [
                '1280x720' =>
                    [
                        'name' => '1280x720',
                        'label' => 'Landscape (1280x720)',
                        'price' => 0.10
                    ],
                '720x1280' =>
                    [
                        'name' => '720x1280',
                        'label' => 'Portrait (720x1280)',
                        'price' => 0.10
                    ]
            ]
        ),
        'sora-2-pro' => array(
            'durations' => [ 4, 8, 12 ],
            'unit' => 'second',
            'resolutions' => [
                '1280x720' =>
                    [
                        'name' => '1280x720',
                        'label' => 'Landscape (1280x720)',
                        'price' => 0.30
                    ],
                '720x1280' =>
                    [
                        'name' => '720x1280',
                        'label' => 'Portrait (720x1280)',
                        'price' => 0.30
                    ],
                '1792x1024' =>
                    [
                        'name' => '1792x1024',
                        'label' => 'Landscape High Resolution (1792x1024)',
                        'price' => 0.50
                    ],
                '1024x1792' =>
                    [
                        'name' => '1024x1792',
                        'label' => 'Portrait High Resolution (1024x1792)',
                        'price' => 0.50
                    ]
            ],
        ),
    ));
    define('AIMOGEN_REALTIME_MODELS', array('gpt-realtime', 'gpt-realtime-mini', 'gpt-realtime-1.5', 'gpt-realtime-2', 'gpt-realtime-2.1', 'gpt-realtime-2.1-mini'));
    define('AIMOGEN_DEFAULT_REALTIME_MODEL', 'gpt-realtime-2.1');
    define('AIMOGEN_REALTIME_VOICES', array('verse', 'alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer'));
    define('AIMOGEN_DEFAULT_REALTIME_VOICE', 'verse');
    define('AIMOGEN_DEFAULT_MODEL_EMBEDDING', 'text-embedding-3-small');
    define('AIMOGEN_EMBEDDINGS_MODELS', array('text-embedding-3-small', 'text-embedding-3-large', 'text-embedding-ada-002'));
    define('AIMOGEN_DALLE_IMAGE_MODELS', array('gpt-image-1', 'gpt-image-1-mini', 'gpt-image-1.5', 'chatgpt-image-latest', 'gpt-image-2', 'gpt-image-2.5-sunburst', 'gpt-image-2.5-flare'));
    define('AIMOGEN_GOOGLE_IMAGE_MODELS', array('gemini-3.1-flash-image', 'gemini-3.1-flash-lite-image', 'gemini-3-pro-image', 'gemini-2.5-flash-image'));
    define('AIMOGEN_GOOGLE_IMAGE_DEFAULT_MODEL', 'gemini-3.1-flash-image');
    define('AIMOGEN_NVIDIA_MODELS', array(
        'nvidia/nemotron-3-ultra-550b-a55b',
        'stepfun-ai/step-3.7-flash',
        'moonshotai/kimi-k2.6',
        'mistralai/mistral-medium-3.5-128b',
        'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning',
        'deepseek-ai/deepseek-v4-flash',
        'deepseek-ai/deepseek-v4-pro',
        'z-ai/glm-5.1',
        'mistralai/mistral-small-4-119b-2603',
        'google/gemma-4-31b-it',
        'nvidia/nemotron-3-super-120b-a12b',
        'qwen/qwen3.5-122b-a10b',
        'qwen/qwen3.5-397b-a17b',
        'nvidia/nemotron-nano-12b-v2-vl',
        'qwen/qwen3-coder-480b-a35b-instruct',
        'bytedance/seed-oss-36b-instruct',
        'nvidia/nvidia-nemotron-nano-9b-v2',
        'nvidia/llama-3.3-nemotron-super-49b-v1.5',
        'sarvamai/sarvam-m',
        'google/gemma-3n-e2b-it',
        'mistralai/mistral-nemotron',
        'nvidia/llama-3.1-nemotron-nano-vl-8b-v1',
        'nvidia/llama-3.1-nemotron-nano-8b-v1',
        'nvidia/llama-3.3-nemotron-super-49b-v1',
        'microsoft/phi-4-mini-instruct',
        'meta/llama-3.2-3b-instruct',
        'abacusai/dracarys-llama-3.1-70b-instruct',
        'nvidia/nemotron-mini-4b-instruct',
        'google/gemma-2-2b-it',
        'meta/llama-3.1-8b-instruct',
        'meta/llama-3.1-70b-instruct',
        'mistralai/mixtral-8x7b-instruct-v0.1'
    ));
    define('AIMOGEN_XAI_MODELS', array('grok-4.7', 'grok-4.6', 'grok-4.5', 'grok-4.3', 'grok-4.20-multi-agent-0309', 'grok-4.20-0309-non-reasoning', 'grok-4.20-0309-reasoning', 'grok-build-0.1'));
    define('AIMOGEN_VISION_XAI_MODELS', array('grok-4.7', 'grok-4.6', 'grok-4.5', 'grok-4.3', 'grok-4.20-multi-agent-0309', 'grok-4.20-0309-non-reasoning', 'grok-4.20-0309-reasoning', 'grok-build-0.1'));
    // Together model IDs overlap with other providers. The internal prefix keeps
    // provider routing unambiguous and is removed before requests are sent.
    define('AIMOGEN_TOGETHER_MODELS', array(
        'together/thinkingmachines/Inkling',
        'together/MiniMaxAI/MiniMax-M3',
        'together/Qwen/Qwen3.8-2.4T-A95B',
        'together/Qwen/Qwen3.7-Max',
        'together/Qwen/Qwen3.6-Plus',
        'together/Qwen/Qwen3.5-9B',
        'together/moonshotai/Kimi-K3',
        'together/zai-org/GLM-5.3',
        'together/zai-org/GLM-5.3-Flash',
        'together/zai-org/GLM-5.2',
        'together/openai/gpt-oss-120b',
        'together/openai/gpt-oss-20b',
        'together/deepseek-ai/DeepSeek-V4-Flash-0731',
        'together/deepseek-ai/DeepSeek-V4-Pro-0813',
        'together/meta-llama/Llama-3.3-70B-Instruct-Turbo',
        'together/google/gemma-4-31B-it',
        'together/Qwen/Qwen3.7-Plus',
        'together/thinkingmachines/Inkling-Small',
        'together/Prism-ML/Ternary-Bonsai-27B',
        'together/meta-models/Muse-Glimmer-30B'
    ));
    define('AIMOGEN_VISION_TOGETHER_MODELS', array(
        'together/Qwen/Qwen3.5-9B',
        'together/google/gemma-4-31B-it',
        'together/MiniMaxAI/MiniMax-M3',
        'together/moonshotai/Kimi-K3'
    ));
    // Mistral model IDs are namespaced internally to keep provider routing
    // unambiguous. The prefix is removed immediately before API requests.
    define('AIMOGEN_MISTRAL_MODELS', array(
        'mistral/mistral-medium-latest',
        'mistral/mistral-small-latest',
        'mistral/mistral-large-latest',
        'mistral/ministral-14b-latest',
        'mistral/ministral-8b-latest',
        'mistral/ministral-3b-latest',
        'mistral/codestral-latest',
        'mistral/zai-glm-5-2'
    ));
    define('AIMOGEN_VISION_MISTRAL_MODELS', array(
        'mistral/mistral-medium-latest',
        'mistral/mistral-small-latest',
        'mistral/mistral-large-latest',
        'mistral/ministral-14b-latest',
        'mistral/ministral-8b-latest',
        'mistral/ministral-3b-latest'
    ));
    // DeepSeek model IDs are namespaced internally so they cannot collide with
    // the same models exposed by Together AI, NVIDIA, Ollama, or OpenRouter.
    // The prefix is deliberately NOT "deepseek/": that is OpenRouter's own vendor
    // namespace, so those IDs matched the OpenRouter catalogue verbatim and every
    // DeepSeek call was routed to OpenRouter instead.
    define('AIMOGEN_DEEPSEEK_MODELS', array(
        'deepseek-api/deepseek-v4-flash',
        'deepseek-api/deepseek-v4-pro'
    ));
    // Fireworks AI serves models under full account paths
    // (accounts/fireworks/models/<name>), so the internal prefix is simply
    // stripped to recover the exact API model ID. This static list is only a
    // seed: aiomatic_get_fireworks_models() replaces it from the live catalogue
    // once an API key is present.
    define('AIMOGEN_FIREWORKS_MODELS', array(
        'fireworks/accounts/fireworks/models/llama-v3p3-70b-instruct',
        'fireworks/accounts/fireworks/models/llama-v3p1-8b-instruct',
        'fireworks/accounts/fireworks/models/qwen3-235b-a22b',
        'fireworks/accounts/fireworks/models/deepseek-v3',
        'fireworks/accounts/fireworks/models/kimi-k2-instruct'
    ));
    define('AIMOGEN_GROQ_MODELS', array('llama-3.1-8b-instant', 'llama-3.3-70b-versatile', 'openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'canopylabs/orpheus-arabic-saudi','canopylabs/orpheus-v1-english', 'meta-llama/llama-prompt-guard-2-22m', 'meta-llama/llama-prompt-guard-2-86m', 'openai/gpt-oss-safeguard-20b', 'qwen/qwen3.8-27b'));
    define('AIMOGEN_VISION_GROQ_MODELS', array());
    define('AIMOGEN_AZURE_MODELS', array('gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-luna', 'gpt-6-sol', 'gpt-5.6-luna', 'gpt-5.6-terra', 'gpt-5.6-sol', 'gpt-6-astra', 'gpt-5.5', 'gpt-5.5-pro', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-pro', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5', 'gpt-5-2025-08-07', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5-mini', 'gpt-5-mini-2025-08-07', 'gpt-5-nano', 'gpt-5-nano-2025-08-07', 'o1', 'o1-pro', 'o3', 'o3-2025-04-16', 'o4-mini', 'o4-mini-2025-04-16', 'o3-mini', 'o3-pro', 'o3-pro-2025-06-10', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-3.5-turbo-1106', 'gpt-4', 'gpt-4-1106-preview', 'gpt-4-0125-preview', 'gpt-4-0613', 'gpt-4-turbo', 'gpt-4-turbo-2024-04-09', 'gpt-4o', 'gpt-4o-2024-05-13', 'gpt-4o-2024-08-06', 'gpt-4o-2024-11-20', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.1-nano-2025-04-14', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-mini-2025-04-14', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview', 'gpt-3.5-turbo-instruct', 'gpt-3.5-turbo-instruct-0914', 'text-embedding-3-large', 'text-embedding-3-small', 'text-embedding-ada-002'));
    define('AIMOGEN_CLAUDE_MODELS', array('claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-opus-5-5', 'claude-sonnet-5', 'claude-opus-5', 'claude-opus-4-8', 'claude-opus-4-7', 'claude-opus-4-6', 'claude-sonnet-4-6', 'claude-opus-4-5-20251101', 'claude-3-haiku-20240307', 'claude-haiku-4-5-20251001', 'claude-sonnet-4-5-20250929', 'claude-opus-4-1-20250805', 'claude-opus-4-20250514', 'claude-sonnet-4-20250514', 'claude-3-7-sonnet-20250219', 'claude-3-5-haiku-20241022', 'claude-fable-5', 'claude-fable-5-1', 'claude-mythos-5'));
    define('AIMOGEN_CLAUDE_CHAT', array('claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-opus-5-5', 'claude-sonnet-5', 'claude-opus-5', 'claude-opus-4-8', 'claude-opus-4-7', 'claude-opus-4-6', 'claude-sonnet-4-6', 'claude-opus-4-5-20251101', 'claude-sonnet-4-5-20250929', 'claude-opus-4-1-20250805', 'claude-opus-4-20250514', 'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 'claude-3-7-sonnet-20250219', 'claude-3-5-haiku-20241022', 'claude-3-haiku-20240307', 'claude-fable-5', 'claude-fable-5-1', 'claude-mythos-5'));
    define('AIMOGEN_CLAUDE_MODELS_200K', array('claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-opus-5-5', 'claude-sonnet-5', 'claude-opus-5', 'claude-opus-4-8', 'claude-opus-4-7', 'claude-opus-4-6', 'claude-sonnet-4-6', 'claude-opus-4-5-20251101', 'claude-sonnet-4-5-20250929', 'claude-opus-4-1-20250805', 'claude-opus-4-20250514', 'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 'claude-3-7-sonnet-20250219', 'claude-3-5-haiku-20241022', 'claude-3-haiku-20240307', 'claude-fable-5', 'claude-fable-5-1', 'claude-mythos-5'));
    define('AIMOGEN_VISION_CLAUDE_MODELS', array('claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-opus-5-5', 'claude-sonnet-5', 'claude-opus-5', 'claude-opus-4-8', 'claude-opus-4-7', 'claude-opus-4-6', 'claude-sonnet-4-6', 'claude-opus-4-5-20251101', 'claude-sonnet-4-5-20250929', 'claude-opus-4-1-20250805', 'claude-opus-4-20250514', 'claude-sonnet-4-20250514', 'claude-haiku-4-5-20251001', 'claude-3-7-sonnet-20250219', 'claude-3-5-haiku-20241022', 'claude-3-haiku-20240307', 'claude-fable-5', 'claude-fable-5-1', 'claude-mythos-5'));
    define('AIMOGEN_GOOGLE_MODELS', array('gemini-4-argon', 'gemini-4-carbon', 'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.1-flash-lite-preview', 'gemini-3-flash-preview', 'gemini-3.1-pro-preview', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'));
    define('AIMOGEN_GOOGLE_VISION_MODELS', array('gemini-4-argon', 'gemini-4-carbon', 'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.1-flash-lite-preview', 'gemini-3-flash-preview', 'gemini-3.1-pro-preview', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'));
    define('AIMOGEN_GOOGLE_STREAMING_MODELS', array('gemini-4-argon', 'gemini-4-carbon', 'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.1-flash-lite-preview', 'gemini-3-flash-preview', 'gemini-3.1-pro-preview', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'));
    define('AIMOGEN_STABLE_NEW_MODELS', array('stable-diffusion-ultra', 'stable-diffusion-core', 'stable-diffusion-3-0-large', 'stable-diffusion-3-0-turbo', 'stable-diffusion-3-0-medium', 'sd3.5-large', 'sd3.5-large-turbo', 'sd3.5-medium'));
    define('AIMOGEN_IDEOGRAM_MODELS', array('V_3', 'V_2_TURBO', 'V_2', 'V_1_TURBO', 'V_1'));
    define('AIMOGEN_STABLE_DEFAULT_MODE', 'sd3.5-large-turbo');
    define('AIMOGEN_REPLICATE_DEFAULT_API_VERSION', 'ac732df83cea7fff18b8472768c88ad041fa750ff7682a21affe81863cbe77e4');
    define('AIMOGEN_STABLE_IMAGE_MODELS', array('stable-diffusion-xl-1024-v1-0', 'stable-diffusion-v1-6', 'stable-diffusion-ultra', 'stable-diffusion-core', 'stable-diffusion-3-0-large', 'stable-diffusion-3-0-medium', 'stable-diffusion-3-0-turbo', 'sd3.5-large', 'sd3.5-large-turbo', 'sd3.5-medium'));
    define('AIMOGEN_GOOGLE_EMBEDDINGS_MODELS', array('gemini-embedding-2-preview', 'gemini-embedding-001', 'text-embedding-005'));
    define('AIMOGEN_BATCH_MODELS', array('gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-luna', 'gpt-6-sol', 'gpt-5.6-luna', 'gpt-5.6-terra', 'gpt-5.6-sol', 'gpt-6-astra', 'gpt-5.5', 'gpt-5.5-pro', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-pro', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5', 'gpt-5-2025-08-07', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5-mini', 'gpt-5-mini-2025-08-07', 'gpt-5-nano', 'gpt-5-nano-2025-08-07', 'gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-4', 'gpt-4-turbo-preview', 'gpt-4-turbo', 'gpt-3.5-turbo-1106', 'gpt-4-turbo-2024-04-09', 'text-embedding-3-large', 'text-embedding-3-small', 'text-embedding-ada-002', 'gpt-4o', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.1-nano-2025-04-14', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1', 'gpt-4.1-mini', 'gpt-4.1-mini-2025-04-14', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview', 'o1-pro', 'o3', 'o3-2025-04-16', 'o4-mini', 'o4-mini-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o3-pro', 'o3-pro-2025-06-10'));
    define('AIMOGEN_BATCH_MODELS_NO_EMBEDDING', array('gpt-3.5-turbo', 'gpt-3.5-turbo-16k', 'gpt-4', 'gpt-4-turbo-preview', 'gpt-4-turbo', 'gpt-3.5-turbo-1106', 'gpt-4-turbo-2024-04-09'));
    define('AIMOGEN_FUNCTION_CALLING_MODELS', array('gpt-6.1-sol', 'gpt-6.1-terra', 'gpt-6-luna', 'gpt-6-sol', 'gpt-4.1-mini', 'gpt-5.6-luna', 'gpt-5.6-terra', 'gpt-5.6-sol', 'gpt-6-astra', 'gpt-5.5', 'gpt-5.5-pro', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.4-nano', 'gpt-5.4-pro', 'gpt-5.3-codex', 'gpt-5.2', 'gpt-5.2-2025-12-11', 'gpt-5.2-pro', 'gpt-5.2-pro-2025-12-11', 'gpt-5.1', 'gpt-5.1-2025-11-13', 'gpt-5', 'gpt-5-2025-08-07', 'gpt-5-pro', 'gpt-5-pro-2025-10-06', 'gpt-5-mini', 'gpt-5-mini-2025-08-07', 'gpt-5-nano', 'gpt-5-nano-2025-08-07', 'gpt-3.5-turbo', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-1106', 'gpt-4', 'gpt-4-turbo-preview', 'gpt-4-0125-preview', 'gpt-4-1106-preview', 'gpt-4-0613', 'gpt-4-turbo-2024-04-09', 'gpt-4-turbo', 'gpt-4o', 'gpt-4o-2024-05-13', 'gpt-4o-2024-08-06', 'gpt-4o-2024-11-20', 'gpt-4o-mini', 'gpt-4o-mini-2024-07-18', 'gpt-4.1-nano-2025-04-14', 'gpt-4.1-nano', 'gpt-4.1-2025-04-14', 'gpt-4.1', 'gpt-4.1-mini-2025-04-14', 'gpt-4o-mini-search-preview', 'gpt-4o-search-preview', 'o1-pro', 'o3', 'o3-2025-04-16', 'o4-mini', 'o4-mini-2025-04-16', 'o3-mini', 'o3-mini-2025-01-31', 'o1', 'o1-2024-12-17', 'o3-pro', 'o3-pro-2025-06-10'));
    define('AIMOGEN_XAI_FUNCTION_CALLING_MODELS', array('grok-4.7', 'grok-4.6', 'grok-4.5', 'grok-4.3', 'grok-4.20-multi-agent-0309', 'grok-4.20-0309-non-reasoning', 'grok-4.20-0309-reasoning', 'grok-build-0.1'));
    define('AIMOGEN_TOGETHER_FUNCTION_CALLING_MODELS', array(
        'together/thinkingmachines/Inkling',
        'together/MiniMaxAI/MiniMax-M3',
        'together/Qwen/Qwen3.5-9B',
        'together/moonshotai/Kimi-K3',
        'together/zai-org/GLM-5.3',
        'together/zai-org/GLM-5.3-Flash',
        'together/zai-org/GLM-5.2',
        'together/openai/gpt-oss-120b',
        'together/openai/gpt-oss-20b',
        'together/deepseek-ai/DeepSeek-V4-Flash-0731',
        'together/deepseek-ai/DeepSeek-V4-Pro-0813',
        'together/meta-llama/Llama-3.3-70B-Instruct-Turbo',
        'together/google/gemma-4-31B-it'
    ));
    define('AIMOGEN_MISTRAL_FUNCTION_CALLING_MODELS', array(
        'mistral/mistral-medium-latest',
        'mistral/mistral-small-latest',
        'mistral/mistral-large-latest',
        'mistral/ministral-14b-latest',
        'mistral/ministral-8b-latest',
        'mistral/ministral-3b-latest'
    ));
    define('AIMOGEN_DEEPSEEK_FUNCTION_CALLING_MODELS', array(
        'deepseek-api/deepseek-v4-flash',
        'deepseek-api/deepseek-v4-pro'
    ));
    define('AIMOGEN_FIREWORKS_FUNCTION_CALLING_MODELS', array(
        'fireworks/accounts/fireworks/models/llama-v3p3-70b-instruct',
        'fireworks/accounts/fireworks/models/llama-v3p1-8b-instruct',
        'fireworks/accounts/fireworks/models/qwen3-235b-a22b',
        'fireworks/accounts/fireworks/models/deepseek-v3',
        'fireworks/accounts/fireworks/models/kimi-k2-instruct'
    ));
    define('AIMOGEN_GOOGLE_CHAT_MODELS', array('gemini-4-argon', 'gemini-4-carbon', 'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.1-flash-lite-preview', 'gemini-3-flash-preview', 'gemini-3.1-pro-preview', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'));
    define('AIMOGEN_GOOGLE_FUNCTION_CALLING_MODELS', array('gemini-4-argon', 'gemini-4-carbon', 'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-3.1-flash-lite-preview', 'gemini-3-flash-preview', 'gemini-3.1-pro-preview', 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'));
    define('AIMOGEN_GROQ_FUNCTION_CALLING_MODELS', array('llama-3.1-8b-instant', 'llama-3.3-70b-versatile', 'openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'canopylabs/orpheus-arabic-saudi','canopylabs/orpheus-v1-english', 'meta-llama/llama-prompt-guard-2-22m', 'meta-llama/llama-prompt-guard-2-86m', 'openai/gpt-oss-safeguard-20b', 'qwen/qwen3.8-27b'));
    define('AIMOGEN_OLLAMA_FUNCTION_CALLING_MODELS', array('deepseek-r1', 'llama3.3', 'phi4', 'llama3.2', 'llama3.1', 'qwen2.5', 'nemotron-mini', 'mistral-small', 'mistral-nemo', 'mistral', 'mixtral', 'command-r', 'command-r-plus', 'qwen2', 'qwen2.5-coder', 'mistral-large', 'gdisney/mistral-large-uncensored', 'hermes3', 'llama3-groq-tool-use', 'crown/artificium', 'firefunction-v2', 'rolandroland/llama3.1-uncensored', 'mannix/llama3.1-8b-abliterated', 'ajindal/llama3.1-storm', 'mannix/llama3.1-8b-lexi', 'wangshenzhi/llama3.1_8b_chinese_chat', 'incept5/llama3.1-claude', 'sam4096/qwen2tools', 'Yarflam/pouet', 'finalend/hermes-3-llama-3.1', 'ALIENTELLIGENCE/nextjs14', 'allenporter/xlam', 'wangshenzhi/llama3.1_70b_chinese_chat', 'MFDoom/deepseek-coder-v2-tool-calling', 'steamdj/llama3.1-cpu-only', 'gdisney/mistral-nemo-uncensored', 'yantien/llama3.1-uncensored', 'hhao/qwen2.5-coder-tools', 'HammerAI/hermes-3-llama-3.1', 'crown/darkidol', 'finalend/llama-3.1-storm', 'mannix/llama3.1-storm', 'ALIENTELLIGENCE/whiterabbitv2', 'benedict/linkbricks-llama3.1-korean', 'leeplenty/lumimaid-v0.2', 'HammerAI/mistral-nemo-uncensored', 
    'vanilj/llama-3.1-70b-instruct-lorablated-iq2_xs', 'mannix/hermes-3-llama-3.1-8b', 'vanilj/hermes-3-llama-3.1-8b', 'mtaylor91/llama3.2-uncensored', 'kuro/mistral-nemo-minitron-8b-base-q8_0-gguf', 'xiayu/wc-llama-bk-8', 'mannix/llama3-groq-tool-8b', 'sammcj/qwen2.5-coder-7b-instruct', 'rjmalagon/dolphin-2.9.3-mistral-nemo', 'ALIENTELLIGENCE/codewriterv2', 'rjmalagon/lumimaid-v0.2-12b', 'hhao/qwen2.5-tools', 'xe/mimi', 'allenporter/assist-llm', 'imac/mistral-nemo-instruct-2407', 'fingerliu/llama3.1', 'MFDoom/deepseek-v2-tool-calling', 'interstellarninja/llama3.1-8b-tools', 'tomasmcm/undi95-meta-llama-3.1-8b-claude', 'krtkygpta/gemma2_tools', 'vanilj/supernova-medius', 'ALIENTELLIGENCE/sarahv2', 'lucianotonet/llamaclaude', 'kuqoi/qwen2-tools', 'rscr/vikhr_nemo_12b', 'mannix/llama3.1-70b', 'chevalblanc/o1-mini', 'ALIENTELLIGENCE/cybersecuritythreatanalysisv2', 'mike/mistral', 'interstellarninja/hermes-2-pro-llama-3-8b-tools', 'ALIENTELLIGENCE/cyberaisecurityv2', 'krith/meta-llama-3.2-3b-instruct-uncensored', 'krith/meta-llama-3.1-8b-instruct', 'sammcj/deepseek-coder-v2-lite-toolcalling', 'majx13/test', 'Tohur/natsumura-assistant-llama-3.1', 
    'ALIENTELLIGENCE/attorney2', 'vanilj/calme-2.4-rys-78b', 'xiayu/wc-llama-bk-7', 'goekdenizguelmez/josiefied-qwen2.5-7b-abliterated-v2', 'zcohn/llama3.1-uncensored-cot', 'mannix/hermes-3-llama-3.1-70b', 'krith/qwen2.5-7b-instruct', 'ALIENTELLIGENCE/linuxcmdxpert', 'sammcj/llama-3-1-8b-smcleod-golang-coder-v3', 'krith/qwen2.5-14b-instruct', 'cyberwald/sauerkrautlm-nemo-12b-instruct', 'vanilj/llama3.1-70b-iquants', 'interstellarninja/hermes-3-llama-3.1-8b-tools', 'dwightfoster03/functionary-small-v3.1', 'kangali/room-coder', 'mannix/llama3.1-8b', 'phuzzy/darknemo', 'ALIENTELLIGENCE/codingassistantv2', 'mychen76/llama3.1-intuitive-thinker', 'ALIENTELLIGENCE/roleplaymaster', 'krith/meta-llama-3.1-70b-instruct-abliterated', 'fatfish/internal-ref-extractor', 'benedict/linkbricks-mistral-nemo-korean', 'krith/meta-llama-3.2-1b-instruct-uncensored', 'xiayu/wc-llama3.1-0805', 'ALIENTELLIGENCE/cybersecuritymonitoring', 'xiayu/wc-llama-bk-2', 'ALIENTELLIGENCE/pythoncoderv2', 'krith/mistral-nemo-instruct-2407-abliterated', 'ALIENTELLIGENCE/automationgeneratorv2', 'InfoForge/forge-8b', 'rjmalagon/dolphin-2.9.3-mistral', 'phuzzy/darkllama3.1', 'ALIENTELLIGENCE/psychologistv2', 
    'rjmalagon/llama-3.1-supernova-lite', 'd89ftekb7/mistral-nemo-uncensored', 'ticlazau/qwen2.5-coder-7b-instruct', 'krith/meta-llama-3.1-8b-instruct-abliterated', 'ALIENTELLIGENCE/medicalimaginganalysis', 'ALIENTELLIGENCE/deepseekcoder16kcontextv2', 'vanilj/mistral-nemo-gutenberg-12b-v2', 'ALIENTELLIGENCE/contentsummarizer', 'krith/qwen2.5-72b-instruct', 'krith/meta-llama-3.1-70b-instruct', 'sam4096/phi2tools', 'ALIENTELLIGENCE/imagepromptengineer', 'TheAzazel/qwen2.5-14b-instruct-abliterated', 'ALIENTELLIGENCE/medicaldiagnostictools', 'ALIENTELLIGENCE/deeplearningengineerv2', 'ALIENTELLIGENCE/holybible', 'rongfengliang/openbuddy-llama3.1', 'ALIENTELLIGENCE/personalizednutrition', 'rongfengliang/bamboo-llm', 'bazsalanszky/mistral-large', 'zxf945/mistral-nemo', 
    'ALIENTELLIGENCE/randomroleplaypromptgenerator', 'ALIENTELLIGENCE/lawfirm', 'vitoreafeliciano/deepseek-coder', 'vitoreafeliciano/codefuse-deepseek', 'SlyOtis/git-auto-message', 'ALIENTELLIGENCE/genaiimagecspromptv', 'ALIENTELLIGENCE/mechanicalengineerv2', 'rscr/vikhr_llama3.1_8b', 'socialnetwooky/hermes3-llama3.1-abliterated', 'ALIENTELLIGENCE/computerhardwareengineer', 'ALIENTELLIGENCE/chemicalengineer', 'ALIENTELLIGENCE/ai2ndbrain', 'krith/qwen2.5-32b-instruct', 'ALIENTELLIGENCE/buffett', 'ALIENTELLIGENCE/aidatascientistv2', 'ALIENTELLIGENCE/bioengineerbiomedicalengineer', 'ALIENTELLIGENCE/electricalengineerv2', 'goekdenizguelmez/josiefied-qwen2.5-1.5b-instruct-abliterated-v1', 'krith/mistral-small-instruct-2409', 'rscr/vikhr_llama3.2_1b', 'ALIENTELLIGENCE/mentalwellness', 'ALIENTELLIGENCE/musicindustry', 'kangali/room-research', 'ALIENTELLIGENCE/multiagentv2', 'ALIENTELLIGENCE/characterconversationsimulator', 'ALIENTELLIGENCE/personalizedmedicine', 'ALIENTELLIGENCE/marketingexpertv2', 'jean-luc/cydonia', 'vanilj/cathallama-70b-i1-iq2_s', 'ALIENTELLIGENCE/predictiveanalyticsforbusinesses', 'artifish/llama3.2-uncensored', 'ALIENTELLIGENCE/musicprompts', 'ALIENTELLIGENCE/jarvisv2',
    'solonglin/qwen2.5-q6_k-abliterated', 'anpigon/qwen2.5-7b-instruct-kowiki', 'ALIENTELLIGENCE/structureddataextraction', 'rjmalagon/rys_llama-3.1-8b-instruct', 'ALIENTELLIGENCE/computervisionengineer', 'RobinBially/xlam-8k', 'ALIENTELLIGENCE/radiofrequencyengineer', 'ALIENTELLIGENCE/streamingdefenselevel3', 'ALIENTELLIGENCE/filmandvideoproduction', 'ALIENTELLIGENCE/modelcreate2', 'starsnatched/thinking', 'ALIENTELLIGENCE/plantdoctor', 'ALIENTELLIGENCE/gamemasterroleplaying', 'ALIENTELLIGENCE/medicalbillingandcoding', 'flori/llama3.1-wopr', 'ALIENTELLIGENCE/gourmetglobetrotter', 'RobinBially/llama3.1-32k', 'ALIENTELLIGENCE/avengineer', 'ALIENTELLIGENCE/chiefinformationsecurityofficerv2', 'ALIENTELLIGENCE/grantwriterv2', 'benedict/linkbricks-hermes3-llama3.1-8b-korean-advanced-q8', 'ALIENTELLIGENCE/seomanager', 'ALIENTELLIGENCE/contractanalyzerv2', 'ALIENTELLIGENCE/digitalmarketingexpert', 'ALIENTELLIGENCE/financialadvisor', 'ALIENTELLIGENCE/veterinarymedicine', 'kovacs/llama3.1', 'ALIENTELLIGENCE/doctorai', 'ALIENTELLIGENCE/aerospaceengineer', 'ALIENTELLIGENCE/unrealgamedev', 'ALIENTELLIGENCE/startupagiassistant2', 'interstellarninja/hermes-2-theta-llama-3-8b-tools', 'vanilj/mistral-large-instruct-2407-iq3_xx', 
    'ALIENTELLIGENCE/lyricist', 'ALIENTELLIGENCE/mindwell', 'ALIENTELLIGENCE/civilengineerv2', 'Artalius/lixi', 'adhilroshan/uiforger', 'ALIENTELLIGENCE/extremecreativityerebus', 'ALIENTELLIGENCE/aipromptassistant', 'ALIENTELLIGENCE/tesla', 'darsankumar89/leglai', 'ALIENTELLIGENCE/mindpal', 'ALIENTELLIGENCE/teachai', 'krith/mistral-large-instruct-2407', 'RobinBially/qwen2.5-coder-16k', 'InfoForge/openforge', 'ALIENTELLIGENCE/embeddedsystemsengineer', 'ALIENTELLIGENCE/leonardodavinci', 'Shailesh714/emotion', 'ALIENTELLIGENCE/schematicdesign', 'ALIENTELLIGENCE/yourcfov2', 'chrypnotoad/erebus', 'Maoyue/mistral-nemo-minitron-8b-instruct', 'teevorian/mistral-nemo-sauerkraut', 'isaacramthal/llama3.1', 'froehnerel/llama-3.1-storm', 'ALIENTELLIGENCE/sapabapcoder', 'site-ir-llm/llm', 'ALIENTELLIGENCE/projectmanager', 'ALIENTELLIGENCE/shelldonv2', 'ALIENTELLIGENCE/librarianv2', 'ALIENTELLIGENCE/tutorai', 'TheAzazel/replete-llm-2.5-qwen-14b', 'ALIENTELLIGENCE/brainstorming', 'ALIENTELLIGENCE/searchfund', 'lawmancs2024/qwen2-function-q5', 'ALIENTELLIGENCE/aipoweredlawfirms', 'ALIENTELLIGENCE/chloev2', 'timdata_seturan/llm-botika-fp16', 'johnnyboy/qwen2.5-math-7b', 'DaddyLLAMA/euryale_v2.2_q4', 
    'TheAzazel/replete-llm-2.5-qwen-7b', 'TheAzazel/replete-llm-2.5-qwen-32b', 'phuzzy/darkidol', 'Kevinization/medicllama1.6', 'laszlo/bob-silly-dungeon-master', 'ALIENTELLIGENCE/humancomputerinteractiondesigner', 'ALIENTELLIGENCE/accountingandtaxation', 'ALIENTELLIGENCE/veterinarian', 
    'rjmalagon/llama-spark', 'ALIENTELLIGENCE/suntzu', 'ALIENTELLIGENCE/alberteinstein', 'ALIENTELLIGENCE/airesearcherv2', 'ALIENTELLIGENCE/pythonconsultantv2', 'ALIENTELLIGENCE/chiefaccountingofficerv2', 'ALIENTELLIGENCE/carljung', 'ALIENTELLIGENCE/edgarcaycev2', 'etracker/sauerkrautlm-3.1-instruct-q8', 'k33g/jean-luc-picard', 'zenoverflow/replete_coder_3_1_8b_q8_custom', 'ALIENTELLIGENCE/roominteriorsuggester', 'ALIENTELLIGENCE/psychiatrist', 'ALIENTELLIGENCE/policymaker', 'ahmedag/hackerbot_spl', 'ALIENTELLIGENCE/generalcounselv2', 'ALIENTELLIGENCE/tutoraiblueprint', 'vanilj/qwen2.5-72b-instruct-iq3_xxs', 'ALIENTELLIGENCE/engineeringtechnicalmanuals', 'ALIENTELLIGENCE/strategist', 'ALIENTELLIGENCE/alienbuddy', 'ALIENTELLIGENCE/emotionalintelligenceanalysis', 'ALIENTELLIGENCE/constructiontakeoffestimatorv2', 'ALIENTELLIGENCE/ceov2', 'ALIENTELLIGENCE/staugustine', 'michaelbui/qwen2.5-14b', 'ALIENTELLIGENCE/genealogist', 'ALIENTELLIGENCE/mindreaderdecoder', 'ALIENTELLIGENCE/foodservice', 'ALIENTELLIGENCE/neuralnetworkengineer', 'ALIENTELLIGENCE/nlpengineer2', 'cow/gemma2_tools', 'TheAzazel/qwen2.5-1.5b-v3-instruct-abliterated-v3.q8_0', 'TheAzazel/qwen2.5-coder-7b-instruct-abliterated.q8_0', 'siswabaru001/pussertifai', 
    'rjmalagon/barcena-8b-juridico-mexicano', 'rohitrajt/emotibot', 'ALIENTELLIGENCE/humorbot', 'ALIENTELLIGENCE/sentimentanalyzer', 'ALIENTELLIGENCE/insuranceservices', 'sparksammy/samantha-3.1', 'ALIENTELLIGENCE/systemsengineer', 'ALIENTELLIGENCE/productmanager', 'ALIENTELLIGENCE/chiefmarketingofficer2', 'ALIENTELLIGENCE/civilstructureengineerv2', 'AG1/kbmtderfla', 'crown/golang3.1', 'ALIENTELLIGENCE/crewaiconsultant', 'ALIENTELLIGENCE/askai', 'ALIENTELLIGENCE/hackerreporter', 'ALIENTELLIGENCE/geotechnicalengineer', 'ALIENTELLIGENCE/healthcareservices', 'ALIENTELLIGENCE/rockefeller', 'ALIENTELLIGENCE/riskmanager', 
    'ALIENTELLIGENCE/officemanager', 'ALIENTELLIGENCE/socialmediamanager', 'ALIENTELLIGENCE/chiefbusinessdevelopmentofficerv2', 'mike/firefunction', 'Kevinization/medicllama1.7', 'benedict/linkbricks-hermes3-llama3.1-8b-korean-advanced-q4', 'ALIENTELLIGENCE/coworkingmanager', 'ALIENTELLIGENCE/manufacturingprogrammingengineer', 'ALIENTELLIGENCE/businessintelligencedeveloper', 'ALIENTELLIGENCE/fashiondesign', 'ALIENTELLIGENCE/stressmoodmentalhealthsupport', 'ArzzKurz/koreansupport', 'ALIENTELLIGENCE/datacollectionentryanalysis', 'ALIENTELLIGENCE/nuclearengineer', 'ALIENTELLIGENCE/projectconstructionmanager', 'ALIENTELLIGENCE/trainingmanager', 'ALIENTELLIGENCE/brandmanager', 'chrypnotoad/fucksorry', 'ALIENTELLIGENCE/chiefsalesofficer2', 'ALIENTELLIGENCE/chiefaiofficerv2', 'thirty3/linux', 'TheAzazel/replete-llm-2.5-qwen-1.5b', 'benevolentjoker/the_economistmini', 'mhw/sin', 'ALIENTELLIGENCE/lifecoach', 'zctech/x-ai-dev', 'ALIENTELLIGENCE/startupcommunity', 'ALIENTELLIGENCE/aigaming', 'timdata_seturan/llm-botika', 'ALIENTELLIGENCE/travelplanningbooking', 'ALIENTELLIGENCE/incidentresponseautomation', 'ALIENTELLIGENCE/dentistry', 'ALIENTELLIGENCE/constructionplanning', 'ALIENTELLIGENCE/jesusofnazareth', 'ALIENTELLIGENCE/crisisintervention', 
    'ALIENTELLIGENCE/materialsengineer', 'ALIENTELLIGENCE/designmanager', 'ALIENTELLIGENCE/salesmanager', 'eliocosta/teste', 'jmorgan/msn', 'Kevinization/medicllama1.10', 'vanilj/llama-3.1-instruct-bellman-8b-swedish', 'bippy/rnld', 'magejosh/llama32instruct1buncensoredq6k', 'thirty3/kali', 'TheAzazel/replete-llm-2.5-qwen-3b', 'sthenno/miscii-14b-preview', 't/qwen2.5', 'RobinBially/qwen2.5-16k', 'aratan/valeryh', 'rizkiagungid/rasxgpt', 'fatfish/external-ref-extractor', 'luobin/coder', 'pdevine/discollama-unsloth', 'ALIENTELLIGENCE/enoch', 'ALIENTELLIGENCE/virtualfinancialadvisors', 'ALIENTELLIGENCE/automatedaccountingtaxpreparation', 'ALIENTELLIGENCE/horticulture', 'ALIENTELLIGENCE/pharmacy', 'ALIENTELLIGENCE/surveyingandmapping', 'mikolajewski/emojitron', 'ALIENTELLIGENCE/plato', 'ALIENTELLIGENCE/socrates', 'ALIENTELLIGENCE/shunryusuzuki', 'ALIENTELLIGENCE/aiengineer', 'ALIENTELLIGENCE/telecommunicationsengineer', 'ALIENTELLIGENCE/serverlesscomputingengineer', 'ALIENTELLIGENCE/metallurgicalengineer', 'dansullivan/test1', 'rosemarla/mistral-small-instruct-abliterated', 'Tales/llama_doc', 'DaddyLLAMA/magum_v2_123b_iq3_xxs', 'rizkiagungid/rasxlite2', 'abhisharma/mini_alisa', 'abhisharma/saniya', 'dominic/adamlinux', 
    'dharmapurikar/qwen2.5-7b-64k', 'rscr/llama3_70b_ru', 'franek/analytics', 'InfoForge/forge-70b', 'ALIENTELLIGENCE/solopreneur', 'ALIENTELLIGENCE/machinelearningengineerv2', 'saifsprezi/sprezi-llama-8b', 'ALIENTELLIGENCE/startupventurestudio', 'ALIENTELLIGENCE/ufology', 'ALIENTELLIGENCE/personalizedmarketingcampaigns', 'ALIENTELLIGENCE/aipowerededucationalgames', 'ALIENTELLIGENCE/clinicaltrialmanagement', 'ALIENTELLIGENCE/virtualeventplanning', 'ALIENTELLIGENCE/predictivethreatdetection', 'ALIENTELLIGENCE/mindfulnessandmeditation', 'ALIENTELLIGENCE/internetofthingsiot', 'ALIENTELLIGENCE/designsimulation', 'ALIENTELLIGENCE/financialplanning', 'ALIENTELLIGENCE/governmentagencies', 'ALIENTELLIGENCE/transportationandlogistics', 'ALIENTELLIGENCE/hawking', 'ALIENTELLIGENCE/elderlycompanion', 'ALIENTELLIGENCE/spectrumanalyzer', 'ALIENTELLIGENCE/ethicalphilosopher', 'ALIENTELLIGENCE/newsproducer', 'ALIENTELLIGENCE/investigativejournalist', 'ALIENTELLIGENCE/healthsafetyengineer', 'ALIENTELLIGENCE/agriculturalengineer', 'ALIENTELLIGENCE/noamchomsk', 'ALIENTELLIGENCE/conceptualdesigntutor', 'jiayuan1/bamboo', 'Azazel-AI/qwen2.5-14b-instruct-abliterated-v2-q8_0', 'mtaylor91/l3-stheno-maid-blackroot', 'anisha24/model1_llama3.1', 'DaddyLLAMA/magum_123b_iq4_xs', 'vanilj/qwen2.5-32b-instruct_iq4_xs',
    'zxf945/llama3.2', 'FjordAI/fjord-ai', 'Kevinization/medicllama1.9.2.q8', 'blinzki/bimtrazer', 'Kevinization/medicllama1.5', 'ALIENTELLIGENCE/detectiveanya', 'ALIENTELLIGENCE/fitgenius', 'ALIENTELLIGENCE/pcarchitect', 'ALIENTELLIGENCE/christiancounselor', 'ALIENTELLIGENCE/airegulatoryspecialist', 'ALIENTELLIGENCE/airesearchscientist', 'ALIENTELLIGENCE/terrorismexpert', 'ALIENTELLIGENCE/sustainabilityanalysistools', 'ALIENTELLIGENCE/portfoliomanagement', 
    'ALIENTELLIGENCE/intelligenttutoringsystems', 'ALIENTELLIGENCE/virtualteachingassistants', 'ALIENTELLIGENCE/supplychainoptimization', 'ALIENTELLIGENCE/tourismhospitalitymanagement', 'ALIENTELLIGENCE/textileandapparelmanufacturing', 'ALIENTELLIGENCE/manufacturing', 'ALIENTELLIGENCE/educationservices', 'ALIENTELLIGENCE/retail', 'ALIENTELLIGENCE/shakespeare', 'ALIENTELLIGENCE/enriquecastillorincon', 'ALIENTELLIGENCE/newsreporter', 'shamyukr2904/gynocologist', 'ALIENTELLIGENCE/signalprocessingengineer', 'ALIENTELLIGENCE/realestatebroker', 'ALIENTELLIGENCE/realestateagent', 'ALIENTELLIGENCE/arvrcloudengineer', 'ALIENTELLIGENCE/ancientalienttheorist', 'ALIENTELLIGENCE/mininggeologicalengineer', 'ALIENTELLIGENCE/environmentalengineer', 'ALIENTELLIGENCE/advertisingmanager', 'ALIENTELLIGENCE/businessadministrator', 'ALIENTELLIGENCE/digitalmarketingmanager', 'ALIENTELLIGENCE/businessdevelopmentbizdev', 'ALIENTELLIGENCE/chiefprojectmanager', 'ALIENTELLIGENCE/coretransformation', 'artifish/spongeass-v4', 'chimiste/llama-3.1-8b-graph', 'DaddyLLAMA/euryale_v2.2_q6_k', 'Hamberfim/myguru_v04', 'abhisharma/alisa', 'gwyntel/psm-v2', 'vince_ai/mmmistral', 'gwyntel/psr-v5', 'rohitrajt/sihemotibot', 'starsnatched/thinkingmistral', 'franek/bank-statement-analyzer', 'jayeshusa22/sensei', 'XTeMixX/ai-x', 
    'AG1/sdso', 'gtandon/ft_llama3_1_swe_bench', 'AG1/gc', 'AG1/strat', 'AG1/manufengprog', 'ALIENTELLIGENCE/learningguidementortutor', 'ALIENTELLIGENCE/birbal', 'ALIENTELLIGENCE/footballcoachassistant', 'RobinBially/mistral-nemo-16k', 'ALIENTELLIGENCE/madamhelenablavatsky', 'ALIENTELLIGENCE/cloudengineer', 'ALIENTELLIGENCE/aiaccessibility', 'ALIENTELLIGENCE/aiethicist', 'ALIENTELLIGENCE/aipoweredproductrecommendations', 'ALIENTELLIGENCE/personalizedducationplans', 'ALIENTELLIGENCE/virtualconsultingservices', 'ALIENTELLIGENCE/virtualnursingassistants', 'ALIENTELLIGENCE/communityengagement', 'ALIENTELLIGENCE/accessibilityservices', 'ALIENTELLIGENCE/urbanplanning', 'ALIENTELLIGENCE/seniorsvirtualassistant', 'ALIENTELLIGENCE/specialneedseducation', 'ALIENTELLIGENCE/confucius', 'ALIENTELLIGENCE/turing', 'ALIENTELLIGENCE/galileo', 'ALIENTELLIGENCE/leaddev', 'maxtheconquerer/mentorships-analysis', 'ALIENTELLIGENCE/yogananda', 'ALIENTELLIGENCE/bezos', 'ALIENTELLIGENCE/sigmundfreud', 'ALIENTELLIGENCE/tvchiefmeteorologist', 'ALIENTELLIGENCE/tvlocalnewsproducer', 'ALIENTELLIGENCE/realtimeeditor', 'ALIENTELLIGENCE/broadcastchiefengineer', 'ALIENTELLIGENCE/microwaveengineer', 'ALIENTELLIGENCE/industrializingmachinelearningengineer', 'ALIENTELLIGENCE/laotse', 'ALIENTELLIGENCE/marineengineernavalarchitect', 'ALIENTELLIGENCE/petroleumengineer', 
    'ALIENTELLIGENCE/salesengineer', 'ALIENTELLIGENCE/industrialengineer', 'ALIENTELLIGENCE/projectsuperintendent', 'ALIENTELLIGENCE/tonystark', 'ALIENTELLIGENCE/predesignresearchtutor', 'ALIENTELLIGENCE/kimclement', 'venetanji/llama3.2-tool', 'Tales/parametros', 'Emile/filou', 'DaddyLLAMA/chronos_platinum_72b_q4_k_m', 'worstcoaster/tinyfilth', 'lly/qwen2.5-32b-instruct-iq3_m', 'guna/ihac-llama-3.2-3b-instruct-4', 'wwwcy/test1', 'benevolentjoker/demarquiscousin', 'vanilj/qwen2.5-14b-instruct-iq4_xs', 'benevolentjoker/the_illustrator', 'guna/ihac-llama-3.2-3b-instruct-2', 'DaddyLLAMA/replete_llm_v2.5_qwen_72b_q5_k_m', 'guna/ihac-llama-3.2-3b-instruct', 'benevolentjoker/the_caldecott', 'toan/hi', 'anthonyarutyunov/ollama-mini', 'dmovalente23/diogo_virtualente_v1', 'Nicotaglia/clinia_v3_8b', 'Nicotaglia/clinia_v2', 'RobinBially/qwen2.5-12k', 'niveo/laminha3.1', 'akiii/mochibi_3b', 'AG1/btderfla', 'panalepe/my_finetune', 'ahmedag/llama-3.1-spl-assistant', 'AG1/jbojfo', 'AG1/cdtfo', 'AG1/edgc', 'AG1/lrbof', 'jxjwilliam/bestitconsulting', 'AG1/ftngen', 'AG1/pcojof', 'AG1/chrof', 'AG1/chopof', 'AG1/sfsf', 'EZZYDMAN/summarisey', 'hhbach/ollama', 'ALIENTELLIGENCE/earthstationoperationsassistant', 
    'pki/logpt2', 'mhw/sin-ia', 'sammcj/llama-3-1-8b-smcleod-golang-coder-v1', 'ALIENTELLIGENCE/player2games', 'ALIENTELLIGENCE/esolevelestimator', 'ALIENTELLIGENCE/venturestartupstudiodragons', 'ALIENTELLIGENCE/startupventurestudionnllapproach', 'ALIENTELLIGENCE/startupventurestudioplaybook', 'RobinBially/mistral-nemo-8k', 'dsi/model', 'ALIENTELLIGENCE/aiprivateequityrollups', 'ALIENTELLIGENCE/vonbraun', 'ALIENTELLIGENCE/aiinputoutputmanager', 'ALIENTELLIGENCE/virtualproductdemonstrations', 'ALIENTELLIGENCE/automatedorderfulfillment', 'ALIENTELLIGENCE/virtualtutoringservices', 'ALIENTELLIGENCE/aipoweredportfoliomanagement', 'ALIENTELLIGENCE/virtualnursingservices', 'ALIENTELLIGENCE/aipoweredpatientengagement', 'ALIENTELLIGENCE/digitalconciergeervices', 'ALIENTELLIGENCE/personalizedcustomerexperience', 'MTBS/anonymizer', 'ALIENTELLIGENCE/ecofriendlysupplychainoptimization', 'ALIENTELLIGENCE/automatedaccountingsystems', 'ALIENTELLIGENCE/adaptivelearningplatforms', 'ALIENTELLIGENCE/aquaculture', 'ALIENTELLIGENCE/gamingservice', 'ALIENTELLIGENCE/autonomousystem', 'ALIENTELLIGENCE/digitaltwintechnology', 'ALIENTELLIGENCE/environmentalconsulting', 'ALIENTELLIGENCE/realestateservice', 'ALIENTELLIGENCE/moses', 'ALIENTELLIGENCE/travelandhospitality', 'ALIENTELLIGENCE/prayerlinecrisisintervention', 'ALIENTELLIGENCE/prayerline', 'ALIENTELLIGENCE/paultheapostle',
    'ALIENTELLIGENCE/archimedes', 'ALIENTELLIGENCE/newton', 'ALIENTELLIGENCE/aristotle', 'kelvi23/axum', 'ALIENTELLIGENCE/feynman', 'ALIENTELLIGENCE/raykurzweil', 'ALIENTELLIGENCE/dalecarnegie', 'ALIENTELLIGENCE/kissinger', 'ALIENTELLIGENCE/aynrand', 'ALIENTELLIGENCE/raydalio', 'ALIENTELLIGENCE/samwalton', 'ALIENTELLIGENCE/jackwelch', 'ALIENTELLIGENCE/peterdrucker', 'ALIENTELLIGENCE/howardhughes', 'ALIENTELLIGENCE/benjaminfranklin', 'ALIENTELLIGENCE/tvnationalnewscastproducer', 'ALIENTELLIGENCE/tvcommercialproducer', 
    'ALIENTELLIGENCE/tvdirectorofsales', 'ALIENTELLIGENCE/streamingsalesinsights', 'ALIENTELLIGENCE/mastercontroloperator', 'ALIENTELLIGENCE/tvadsalesdirector', 'ALIENTELLIGENCE/digitalanchorproducer', 'ALIENTELLIGENCE/broadcastproductionengineer', 'ALIENTELLIGENCE/tvstationchiefengineer', 'ALIENTELLIGENCE/broadcastengineer', 'ALIENTELLIGENCE/tvchiefengineer', 'ALIENTELLIGENCE/mediaengineer', 'ALIENTELLIGENCE/neuromorphicngineer', 'ALIENTELLIGENCE/publicrelationsdirector', 'ALIENTELLIGENCE/communicationsdirector', 'ALIENTELLIGENCE/promotionsmanager', 'ALIENTELLIGENCE/facilitiesmanager', 'ALIENTELLIGENCE/marketingcommunicationmgr', 'Clem81/test', 'zctech/x-ai-12b', 'jelebruh/qwen2.5', 'chimiste/llama-3.2-1b-graph', 'guna/regpg-ihac-llama-3.2-3b-instruct', 'DaddyLLAMA/llama3.2_1b_q4', 'AG1/mqzbtm', 'vince_ai/mmmistral8', 'kufudemir/kufudemir', 'aratan/codebiblia', 'uwbfritz/mgannon', 'Nicotaglia/clinia_v4', 't/qwen2.5-patent-claims-explain', 'Nicotaglia/clinia_v3_70b', 'RobinBially/llama3.1-16k', 'Nicotaglia/clinia_v1', 'incept5/swiftral', 'starsnatched/tm', 'liutechs/soulqwen2', 'starsnatched/t', 'AG1/mrafafa', 'AG1/pscocfofo', 'AG1/rsmefofo', 'blackalpha/todlymist', 'AG1/arefofo', 'AG1/mafetfoo', 'AG1/syefofo', 'AG1/sfefofofo', 'AG1/cmhfofo', 'AG1/emefofo', 'AG1/elgfofo',
    'AG1/chlgfofo', 'AG1/caifofo', 'AG1/cpvfofo', 'benedict/linkbricks-hermes3-llama3.1-70b-korean-advanced-q5', 'benedict/linkbricks-hermes3-llama3.1-70b-korean-advanced-q4', 'AG1/chrfeof', 'AG1/chepofd', 'AG1/cafafafo', 'AG1/chsavbfo', 'AG1/chdtfo', 'AG1/chstfo', 'AG1/chtafofo', 'AG1/mnmetfo', 'AG1/chfofofo', 'AG1/clstfofo', 'AG1/atfgo', 'AG1/nktfgo', 'AG1/rkfgo', 'AG1/rdfgf', 'AG1/mfskfo', 'AG1/mdfgo', 'AG1/hwkofo', 'AG1/dmfo', 'AG1/ctmof', 'AG1/cnsfo', 'AG1/cwofr', 'AG1/anofo', 'AG1/enstfo', 'AG1/jnzfo', 'AG1/bbfor', 'AG1/vtrof', 'AG1/tsdfo', 'AG1/sdvdrfo', 'AG1/svspfo', 'AG1/snrpfo', 'AG1/pdanfo', 'AG1/prlcsfo', 'AG1/smpfo', 'AG1/mdbofo', 'AG1/mwdfo', 'AG1/mchegof', 'AG1/lofcfo', 'AG1/ingnof', 'AG1/dcfofo', 'AG1/ctkofof', 'AG1/scengof', 'AG1/cevngio', 'AG1/bnstmo', 'AG1/aytof', 'AG1/cstaof', 'AG1/chconof', 'AG1/bisinof', 'AG1/gwrof', 'AG1/chrzfo', 'AG1/prfofo', 'AG1/vsofs', 'AG1/vocfa', 'AG1/chfofo', 'AG1/perlu', 'AG1/chefoe', 'AG1/canof', 'AG1/cadvof', 'AG1/agoffo', 'AG1/canyof', 'AG1/caudof', 'AG1/cbrdof', 'AG1/cbdvo', 'AG1/ccomuof', 'AG1/ccoplo', 'AG1/ccontof', 'AG1/ccrof', 'AG1/ccsuof', 
    'AG1/cdatof', 'AG1/cdesof', 'AG1/cdigof', 'AG1/cevntof', 'AG1/cevnof', 'AG1/cxpof', 'AG1/cfutof', 'AG1/cgmof', 'AG1/cgrwof', 'AG1/cinof', 'AG1/cisof', 'AG1/cinoof', 'AG1/cinspo', 'AG1/cipco', 'AG1/cinvof', 'AG1/cknwof', 'AG1/clarnof', 'AG1/chlogof', 'AG1/cmarkof', 'AG1/cmer', 'AG1/cprocof', 'AG1/chprdof', 'AG1/chprmg', 'AG1/crepuof', 'AG1/crescof', 'AG1/cscenof', 'AG1/crevo', 'AG1/crsko', 'AG1/csalof', 'AG1/csecof', 'AG1/cstrao', 'AG1/cscof', 'AG1/ctalo', 'AG1/cwo', 'AG1/chteco', 'AG1/chtecof', 'AG1/cowk', 'AG1/lf', 'AG1/gw', 'swapnil_teke/8_nap_model', 'jun47ade/callama', 'darsankumar89/octilyassist', 'zctech/x-ai-kit', 'xiayu/wc-llama-bk-6', 'xiayu/llama3.1-wizard',
    'janne/raindance', 'kelvi23/custom_axum', 'a99divx/lok', 'kelvi23/caller', 'gedesiwen/my-models', 'crown/craigsprompter', 'dylanravel/allied_interest', 'chevalblanc/claude-3-haiku', 'phonpadithpp/laosllm', 'Tales/massas', 'chimiste/llama-3.2-3b-graph', 'richasdy/hello', 'GyuHyeon/naps-llama-3.1-v0.6.0-f32', 'saish_15/tethysai_research', 'StoneSage/marcus', 'hungvturing/pd-mario', 'eggitai/gienwen', 'vladm90/vv2', 'wjwjx/apioverflow', 'JerickUN/javagpt', 'dougstrouth/blog_assistant', 'emre198/emreai', 'fbriones/freya', 'remington2002/vector2', 'richlee/mario', 'Hamberfim/myguru', 'bmizerany/pap', 'tryfonas/tref', 'rakalantari/myllama', 'lsctw/lsctwman', 'aratan/valeryq-coder',
    'Kevinization/medicllama1.9.2.q9_1', 'Kevinization/medicllama1.9.2.q9', 'rumpl/llama3.1', 'laszlo/bob', 'niveo/laminha', 'starsnatched/thinkingsmolmistral', 'peter6432/cat', 'peter6432/test', 'gbejarano-mc/murrayllama', 'gurjant1229/smart-model', 'josepana/oda', 'kamil5b/ciwastra', 'divanshurc/wyzard-discovery', 'Jakub123/discord2.0', 'kaany/llm1', 'Javi/dev-genai-plexus', 'Akshita/testing-llama', 'Karlsefni/chatofexile', 'xiayu/wc-llama-bk-3', 'xiayu/wc-llama-bk-1', 'jacksonian_r_taylor/initial_testing', 'sezi_kim/ollama3.1', 'shamyukr2904/othopaedist', 'AshtonLKY/llama3.1narsim', 'mohamedrady/clockwok-temptation'));
    define('AIMOGEN_EMBEDDING_OLLAMA_MODELS', array('nomic-embed-text', 'mxbai-embed-large', 'snowflake-arctic-embed', 'all-minilm', 'unclemusclez/jina-embeddings-v2-base-code', 'hellord/mxbai-embed-large-v1', 'znbang/bge', 'bge-m3', 'shaw/dmeta-embedding-zh', 'jina/jina-embeddings-v2-base-de', 'chroma/all-minilm-l6-v2-f32', 'bge-large', 'quentinz/bge-large-zh-v1.5', 'paraphrase-multilingual', 'milkey/m3e', 'jina/jina-embeddings-v2-base-en', 'chevalblanc/acge_text_embedding', 'chatfire/bge-m3', 'dztech/bge-large-zh', 'mofanke/acge_text_embedding', '893379029/piccolo-large-zh-v2', 'jina/jina-embeddings-v2-small-en', 'mofanke/dmeta-embedding-zh', 'milkey/gte', 'herald/dmeta-embedding-zh', 'nextfire/paraphrase-multilingual-minilm', 'jina/jina-embeddings-v2-base-es', 'milkey/dmeta-embedding-zh', 'cwchang/jina-embeddings-v2-base-zh', 'smartcreation/dmeta-embedding-zh', 'evilfreelancer/enbeddrus', 'smartcreation/bge-large-zh-v1.5', 'yxl/m3e', 'jmorgan/gte-small', 'shaw/dmeta-embedding-zh-small-q4', 'zylonai/multilingual-e5-large', 'royalpha/sentence-camembert-large', 'jeffh/intfloat-multilingual-e5-large', 'quentinz/bge-base-zh-v1.5', 'karuniaperjuangan/multilingual-e5-small', 'jeffh/intfloat-multilingual-e5-large-instruct', 'aerok/xiaobu-embedding-v2', 'zailiang/bge-large-zh-v1.5', 'shaw/dmeta-embedding-zh-small',
    'aerok/acge_text_embedding', 'twwch/m3e-base', 'shaw/dmeta-embedding-zh-q4', 'viosay/conan-embedding-v1', 'smartwang/bge-large-zh-v1.5-f32.gguf', 'tazarov/all-minilm-l6-v2-f32', 'zw66/bgelarge', 'sunzhiyuan/suntray-embedding', 'joanfm/jina-embeddings-v2-base-en', 'jmorgan/nomic-embed-text', 'chinashrimp/jina-embeddings-v2-base-zh', 'albertogg/multi-qa-minilm-l6-cos-v1', 'bnksys/baia', 'imcurie/bge-large-en-v1.5', 'joanfm/jina-embeddings-v2-base-es', 'chevalblanc/text-embedding-3-small', 'shunyue/llama3-chinese-shunyue', '0ssamaak0/nomic-embed-text', 'theepicdev/nomic-embed-text', 'pankajrajdeo/sentence-transformers_all-minilm-l6-v2', 'kun432/cl-nagoya-ruri-large', 'locusai/multi-qa-minilm-l6-cos-v1', 'chinashrimp/xiaobu-embedding-v2', 'yuki_ho/bce-embedding', 'joanfm/jina-embeddings-v2-base-de', 'davisgao/m3e', 'zxf945/nomic-embed-text', 'quentinz/bge-small-zh-v1.5', 'zw66/llama3-8b-gguf', 'waterdrop/embeding', 'yxchia/paraphrase-multilingual-minilm-l12-v2', 'imac/zpoint_large_embedding_zh', 'zctech/x-ai-txt', 'jmorgan/all-minilm-l6', 'viosay/xiaobu-embedding-v2', 'plutonioumguy/bge-m3', 'zw66/llama3-8b', 'HuTangZhu/gte-small-zh', 'aerok/zpoint_large_embedding_zh', 'diepho/all-minilm', 'msc802/xiaobu-embedding-v2', 'zw66/llama3-chat-8.0bpw', 'woodylee1974/dmeta', 'modelbao/bge-large-zh-v1.5', 'zailiang/m3e', 'zw66/llama3-lora8b', 
    'liebe-magi/multilingual-e5-large', 'kun432/cl-nagoya-ruri-base', 'stanus74/e5-base-sts-en-de', 'imcurie/bge-large-zh-v1.5', 'yuki_ho/conan-embedding-v1', 'zylonai/bge-m3', 'leoho0722/zpoint_large_embedding_zh', 'shirt/snowflake-arctic-secret', 'viosay/zpoint_large_embedding_zh', 'charaf/bge-m3-f32', 'ollamay/w3e', 'lrs33/bce-embedding-base_v1', 'jaluma/arabert-all-nli-triplet-matryoshka', 'bona/bge-m3-korean', 'lrs33/conan-embedding-v1', 'zylonai/paraphrase-multilingual-minilm-l12', 'ohko/bge-small-zh-hk', 'imcurie/bge-m3', 'yuki_ho/xiaobu-embedding-v2', 'ehd0309/lgko', 'cowolff/science_bge_large', 'aroxima/multilingual-e5-large-instruct', 'xiaoming/bge-large-zh-v1.5', 'xiaoming/multilingual-e5-large', 'xiaoming/bce-embedding-base_v1', 'lrs33/xiaobu-embedding-v2', 'lrs33/acge_text_embedding'));
    define('AIMOGEN_TRAINING_MODELS', array('gpt-4o-2024-08-06', 'gpt-4o-mini-2024-07-18', 'gpt-4-0613', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-1106'));
    define('AIMOGEN_TRAINING_MODELS_CHAT', array('gpt-4o-2024-08-06', 'gpt-4o-mini-2024-07-18', 'gpt-4-0613', 'gpt-3.5-turbo-0125', 'gpt-3.5-turbo-1106'));
    define('AIMOGEN_DEFAULT_TRAINING_MODEL', array('gpt-4o-mini-2024-07-18'));
    define('AIMOGEN_OLLAMA_MODELS', array('llama3'));
    define('AIMOGEN_OPENAI_SPEECH_MODELS', array('whisper-1', 'gpt-4o-mini-transcribe', 'gpt-4o-transcribe'));
    define('AIMOGEN_DEFAULT_MAX_TOKENS', 2048);
    define('AIMOGEN_BULK_CONTENT_MAX_TOKENS', 4096);
    define('AIMOGEN_DEFAULT_COMPLETION_TOKENS', 2000);
    define('AIMOGEN_MINIMUM_TOKENS_FOR_COMPLETIONS', 50);
    define('AIMOGEN_MINIMUM_TOKENS_FOR_CHAT', 50);
    define('AIMOGEN_MAX_HUGGINGFACE_TOKEN_COUNT', 2000);
    define('AIMOGEN_MAX_OLLAMA_TOKEN_COUNT', 4000);
    define('AIMOGEN_IS_DEBUG', false);
    define('AIMOGEN_EXCEPTED_POST_TYPES_FROM_EDITING', array('aiomatic_agent', 'aiomatic_video', 'aiomatic_embeddings', 'aiomatic_file', 'aiomatic_remote_chat', 'aiomatic_convert', 'aiomatic_finetune', 'aiomatic_forms', 'aiomatic_personas', 'aiomatic_assistants', 'aiomatic_batches', 'aiomatic_omni_temp', 'aiomatic_editor_temp', 'aiomatic_omni_file', 'aiomatic_themes', 'aiomatic_user_data'));
    define('AIMOGEN_AZURE_API_VERSION', '?api-version=2025-06-01');
    define('AIMOGEN_AZURE_API_VERSION_EMBEDDINGS', '?api-version=2024-06-01');
    define('AIMOGEN_AZURE_DALLE_API_VERSION', '?api-version=2023-06-01-preview');
    define('AIMOGEN_AZURE_DALLE3_API_VERSION', '?api-version=2024-06-01');
    define('AIMOGEN_AZURE_ASSISTANTS_API_VERSION', '?api-version=2024-05-01-preview');
    define('AIMOGEN_AZURE_BATCHES_API_VERSION', '?api-version=2024-10-21');
    define('AIMOGEN_AZURE_DEPLOYMENT_API_VERSION', '?api-version=2023-03-15-preview');
    define('AIMOGEN_AMAZON_CATEGORIES', array('AmazonVideo', 'Apparel', 'Appliances', 'ArtsAndCrafts', 'Automotive', 'Baby', 'Beauty', 'Books', 'Classical', 'Collectibles', 'Computers', 'CreditCards', 'DigitalMusic', 'DigitalEducationalResources', 'Electronics', 'EverythingElse', 'Fashion', 'FashionBaby', 'FashionBoys', 'FashionGirls', 'FashionMen', 'FashionWomen', 'ForeignBooks', 'Furniture', 
    'GardenAndOutdoor', 'Garden', 'GiftCards', 'GroceryAndGourmetFood', 'Handmade', 'HealthPersonalCare', 'Hobbies', 'HomeAndKitchen', 'Home', 'Industrial', 'Jewelry', 'KindleStore', 'LocalServices', 'Lighting', 'Luggage', 
    'MobileAndAccessories', 'LuxuryBeauty', 'Magazines', 'Miscellaneous', 'MobileApps', 'MoviesAndTV', 'Music', 'MusicalInstruments', 'OfficeProducts', 'PetSupplies', 'Photo', 'Shoes', 'Software', 'SportsAndOutdoors', 'ToolsAndHomeImprovement', 'ToysAndGames', 'Vehicles', 'VHS', 'VideoGames', 'Watches'));
}
?>
