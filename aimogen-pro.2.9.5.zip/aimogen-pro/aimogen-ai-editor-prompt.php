<?php
/*
 * Aimogen AI Editor - context assembly and prompt construction.
 *
 * Two jobs: decide what the model is allowed to see about the post, and turn the
 * user's plain-language instruction into a request for a strict JSON object keyed by
 * the field identifiers the user actually selected.
 */

defined('ABSPATH') or die();

/**
 * One-click instruction presets.
 *
 * These are prompt text, not a second backend: each one just fills the instruction
 * box, and the user can edit the result before generating.
 */
function aimogen_ai_editor_get_presets()
{
    $presets = array(
        array(
            'id'          => 'custom',
            'label'       => __('Custom instruction', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => '',
        ),
        array(
            'id'          => 'improve',
            'label'       => __('Improve writing', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Improve this content while keeping the meaning and the facts exactly as they are. Make it clearer, better structured and more pleasant to read.', 'aiomatic-automatic-ai-content-writer'),
        ),
        array(
            'id'          => 'grammar',
            'label'       => __('Fix grammar', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Fix spelling, grammar and punctuation only. Preserve my writing style, tone, word choices and formatting. Do not rewrite sentences that are already correct.', 'aiomatic-automatic-ai-content-writer'),
        ),
        array(
            'id'          => 'rewrite',
            'label'       => __('Rewrite', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Rewrite this in fresh wording while keeping every fact, claim and piece of information intact. Do not add information that is not already present.', 'aiomatic-automatic-ai-content-writer'),
        ),
        array(
            'id'          => 'shorten',
            'label'       => __('Shorten', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Make this noticeably shorter and tighter. Cut filler and repetition, keep every important point.', 'aiomatic-automatic-ai-content-writer'),
        ),
        array(
            'id'          => 'expand',
            'label'       => __('Expand', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Expand this with more useful detail and explanation, building only on information already present in the post. Do not invent facts, statistics or sources.', 'aiomatic-automatic-ai-content-writer'),
        ),
        array(
            'id'          => 'summarize',
            'label'       => __('Summarize', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Write a concise summary based on the article content.', 'aiomatic-automatic-ai-content-writer'),
        ),
        array(
            'id'          => 'tone',
            'label'       => __('Change tone', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Rewrite this in a friendly, conversational tone while keeping the meaning and all the facts unchanged.', 'aiomatic-automatic-ai-content-writer'),
        ),
        array(
            'id'          => 'translate',
            'label'       => __('Translate', 'aiomatic-automatic-ai-content-writer'),
            'instruction' => __('Translate this into German. Preserve all HTML markup, shortcodes and formatting exactly as they are, translating only the human-readable text.', 'aiomatic-automatic-ai-content-writer'),
        ),
    );

    return apply_filters('aimogen_ai_editor_presets', $presets);
}

/**
 * Saved AI Content Editor templates offered as presets inside the new panel.
 *
 * The template CPT and its aiomatic_json payload are the existing format; nothing
 * about how templates are stored or used by aiomatic_do_post() changes here.
 */
function aimogen_ai_editor_get_template_choices()
{
    $choices = array();
    $template_ids = get_posts(array(
        'post_type'        => 'aiomatic_editor_temp',
        'post_status'      => array('publish'),
        'posts_per_page'   => 200,
        'orderby'          => 'title',
        'order'            => 'ASC',
        'fields'           => 'ids',
        'suppress_filters' => false,
    ));

    if (empty($template_ids)) {
        return $choices;
    }

    foreach ($template_ids as $template_id) {
        $data = aimogen_ai_editor_decode_template((int) $template_id);
        $choices[] = array(
            'id'           => (int) $template_id,
            'label'        => get_the_title($template_id),
            'instructions' => aimogen_ai_editor_template_instructions($data),
        );
    }

    return $choices;
}

/**
 * Decode a template's aiomatic_json payload.
 *
 * The slash juggling mirrors aiomatic_do_post() and aimogen_content_editor_templates_list():
 * templates saved by older plugin versions are stored with escaped single quotes.
 */
function aimogen_ai_editor_decode_template($template_id)
{
    $post = get_post($template_id);
    if (!($post instanceof WP_Post) || $post->post_type !== 'aiomatic_editor_temp') {
        return array();
    }
    $json = get_post_meta($template_id, 'aiomatic_json', true);
    if (is_array($json)) {
        return $json;
    }
    if (!is_string($json) || $json === '') {
        return array();
    }
    $normalized = str_replace("\\'", "'", $json);
    $normalized = str_replace("'", "\\\\'", $normalized);
    $decoded = json_decode($normalized, true);
    if (!is_array($decoded)) {
        $decoded = json_decode($json, true);
    }
    return is_array($decoded) ? $decoded : array();
}

/**
 * Map a template's stored instructions onto the new panel's field identifiers, so a
 * template can pre-fill the instruction box and per-field overrides.
 */
function aimogen_ai_editor_template_instructions($data)
{
    $out = array(
        'general'  => '',
        'perField' => array(),
    );
    if (!is_array($data)) {
        return $out;
    }

    $map = array(
        'ai_instruction'         => 'post_content',
        'ai_instruction_title'   => 'post_title',
        'ai_instruction_excerpt' => 'post_excerpt',
    );
    foreach ($map as $setting_key => $field_id) {
        if (!empty($data[$setting_key]) && is_string($data[$setting_key])) {
            $out['perField'][$field_id] = trim($data[$setting_key]);
        }
    }

    /* The legacy custom-field format is one "slug => prompt" per line. */
    if (!empty($data['ai_custom_field']) && is_string($data['ai_custom_field'])) {
        $lines = preg_split('/\r\n|\r|\n/', trim($data['ai_custom_field']));
        foreach ((array) $lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '=>') === false) {
                continue;
            }
            $parts = explode('=>', $line, 2);
            $slug   = trim($parts[0]);
            $prompt = trim($parts[1]);
            if ($slug === '' || $prompt === '') {
                continue;
            }
            $out['perField']['meta:' . $slug] = $prompt;
        }
    }

    /* Whichever instruction the template leads with becomes the general one, so the
       user sees something meaningful in the box even before picking fields. */
    if (!empty($out['perField']['post_content'])) {
        $out['general'] = $out['perField']['post_content'];
    } elseif (!empty($out['perField'])) {
        $first = reset($out['perField']);
        $out['general'] = (string) $first;
    }

    return $out;
}

/**
 * Trim a value to a character budget without cutting mid-word where avoidable.
 */
function aimogen_ai_editor_truncate($value, $chars)
{
    $value = (string) $value;
    $length = function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
    if ($length <= $chars) {
        return $value;
    }
    $cut = function_exists('mb_substr') ? mb_substr($value, 0, $chars, 'UTF-8') : substr($value, 0, $chars);
    $space = strrpos($cut, ' ');
    if ($space !== false && $space > ($chars * 0.8)) {
        $cut = substr($cut, 0, $space);
    }
    return $cut . "\n\n[…truncated…]";
}

/**
 * Build the context block describing the post.
 *
 * Only what the operation plausibly needs: the post type, the title, the excerpt and
 * a trimmed copy of the content. A field's own current value is NOT repeated here -
 * it is already in the per-field section of the prompt, and duplicating a long
 * post_content would double the request payload for no benefit.
 */
function aimogen_ai_editor_build_context($post, $targets, $use_context, $editor_values)
{
    if (!$use_context) {
        return '';
    }

    $target_ids = array();
    foreach ($targets as $target) {
        $target_ids[$target['field']['id']] = true;
    }

    $post_type_object = get_post_type_object($post->post_type);
    $type_label = ($post_type_object !== null && isset($post_type_object->labels->singular_name))
        ? $post_type_object->labels->singular_name
        : $post->post_type;

    $lines = array();
    $lines[] = 'CONTEXT - the existing WordPress ' . $type_label . ' being edited:';

    if (!isset($target_ids['post_title'])) {
        $title = aimogen_ai_editor_context_value($post, 'post_title', $editor_values);
        if ($title !== '') {
            $lines[] = 'Title: ' . $title;
        }
    }
    if (!isset($target_ids['post_excerpt'])) {
        $excerpt = aimogen_ai_editor_context_value($post, 'post_excerpt', $editor_values);
        if ($excerpt !== '') {
            $lines[] = 'Excerpt: ' . aimogen_ai_editor_truncate($excerpt, 1000);
        }
    }
    if (!isset($target_ids['post_content'])) {
        $content = aimogen_ai_editor_context_value($post, 'post_content', $editor_values);
        if ($content !== '') {
            /* Markup is noise when the content is only background for another field. */
            $plain = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($content)));
            if ($plain !== '') {
                $lines[] = 'Article content: ' . aimogen_ai_editor_truncate($plain, AIMOGEN_AI_EDITOR_CONTEXT_CONTENT_CHARS);
            }
        }
    }

    if (count($lines) === 1) {
        return '';
    }

    $context = implode("\n", $lines);

    /* Integrations can widen or narrow what the model sees. Note the contract: this
       string is inserted verbatim into the prompt, so anything added here is sent. */
    return (string) apply_filters('aimogen_ai_editor_context', $context, $post, $targets, $editor_values);
}

/**
 * Prefer the value currently open in the editor over the stored one.
 *
 * A user who has typed into Gutenberg without saving should get the AI working on
 * what they see, not on a stale database row.
 */
function aimogen_ai_editor_context_value($post, $field_id, $editor_values)
{
    if (is_array($editor_values) && array_key_exists($field_id, $editor_values)) {
        return (string) $editor_values[$field_id];
    }
    if ($field_id === 'post_title') {
        return (string) $post->post_title;
    }
    if ($field_id === 'post_excerpt') {
        return (string) $post->post_excerpt;
    }
    if ($field_id === 'post_content') {
        return (string) $post->post_content;
    }
    return '';
}

/**
 * Per-field rules that keep the model from wrecking structural markup.
 */
function aimogen_ai_editor_format_rules($field)
{
    $format = isset($field['format']) ? $field['format'] : 'text';

    if ($field['id'] === 'post_content') {
        return 'This is WordPress post content. Preserve the structural markup exactly: keep every Gutenberg block delimiter comment (<!-- wp:... --> and <!-- /wp:... -->) byte-for-byte including its JSON attributes, keep every shortcode, embed, HTML tag, attribute and class. Edit only the human-readable text between them. Never add, remove, reorder or renumber block delimiters. If you cannot change the text without breaking a block, leave that block alone.';
    }
    if ($format === 'html') {
        return 'This value contains HTML. Preserve all tags, attributes and shortcodes; change only the human-readable text.';
    }
    if (isset($field['acf_type']) && $field['acf_type'] === 'number') {
        return 'Reply with a number only - no units, currency symbols, thousands separators or commentary.';
    }
    if (isset($field['acf_type']) && $field['acf_type'] === 'url') {
        return 'Reply with a single absolute URL only.';
    }
    if (isset($field['acf_type']) && $field['acf_type'] === 'email') {
        return 'Reply with a single e-mail address only.';
    }
    if ($field['id'] === 'post_title') {
        return 'Reply with plain text only - no HTML, no surrounding quotes, no trailing full stop.';
    }
    return 'Reply with plain text. Do not add HTML that is not already present.';
}

/**
 * Assemble the full prompt.
 *
 * $targets is a list of array('field' => descriptor, 'instruction' => string,
 * 'current' => string) - the current value is resolved by the caller so the editor's
 * unsaved state wins over the database.
 */
function aimogen_ai_editor_build_prompt($post, $targets, $general_instruction, $use_context, $editor_values)
{
    $sections = array();

    $sections[] = 'You are an editing assistant working on an existing WordPress post. '
        . 'You rewrite the fields you are given and return them as JSON. '
        . 'You never invent facts that are not supported by the material you are given.';

    $context = aimogen_ai_editor_build_context($post, $targets, $use_context, $editor_values);
    if ($context !== '') {
        $sections[] = $context;
    }

    if (trim((string) $general_instruction) !== '') {
        $sections[] = "GENERAL INSTRUCTION (applies to every field unless a field overrides it):\n" . trim((string) $general_instruction);
    }

    $field_blocks = array();
    foreach ($targets as $target) {
        $field = $target['field'];
        $current = (string) $target['current'];

        $block = 'FIELD "' . $field['id'] . '" (' . $field['label'] . ')';
        if (!empty($target['instruction'])) {
            $block .= "\nInstruction for this field: " . trim($target['instruction']);
        }
        $block .= "\nRules: " . aimogen_ai_editor_format_rules($field);
        if (!empty($field['maxlength'])) {
            $block .= "\nHard limit: at most " . (int) $field['maxlength'] . ' characters.';
        }
        if ($current === '') {
            $block .= "\nCurrent value: (empty - create a suitable value from the context above)";
        } else {
            $budget = ($field['id'] === 'post_content') ? 60000 : 20000;
            $block .= "\nCurrent value:\n<<<CURRENT\n" . aimogen_ai_editor_truncate($current, $budget) . "\nCURRENT";
        }
        $field_blocks[] = $block;
    }
    $sections[] = implode("\n\n", $field_blocks);

    $ids = array();
    foreach ($targets as $target) {
        $ids[] = '"' . $target['field']['id'] . '"';
    }

    $schema = "OUTPUT FORMAT - this part is not optional:\n"
        . "Reply with a single JSON object and nothing else. No prose before or after it, no markdown code fence.\n"
        . "The object has one key, \"fields\". Under it, one entry per field, keyed by the exact field identifier given above.\n"
        . "Each entry is an object with a single \"value\" key holding the complete new value for that field as a string.\n"
        . 'Return exactly these ' . count($ids) . ' field identifiers and no others: ' . implode(', ', $ids) . ".\n"
        . "Return the whole new value, never a fragment, a diff or a description of your changes.\n"
        . "Example shape: {\"fields\":{\"post_title\":{\"value\":\"...\"}}}";
    $sections[] = $schema;

    $prompt = implode("\n\n", $sections);

    return (string) apply_filters('aimogen_ai_editor_prompt', $prompt, $post, $targets, $general_instruction);
}

/**
 * Expand the plugin's %%post_title%% style placeholders inside an instruction, so a
 * saved template's instruction behaves the same here as it does in automation.
 */
function aimogen_ai_editor_expand_placeholders($instruction, $post)
{
    $instruction = (string) $instruction;
    if ($instruction === '' || strpos($instruction, '%%') === false) {
        return $instruction;
    }
    if (!function_exists('aiomatic_replaceAIPostShortcodes')) {
        return $instruction;
    }

    $author = get_user_by('id', $post->post_author);
    $author_name = ($author !== false && isset($author->user_nicename)) ? $author->user_nicename : '';

    if (function_exists('aiomatic_replaceSynergyShortcodes')) {
        $instruction = aiomatic_replaceSynergyShortcodes($instruction);
    }

    return aiomatic_replaceAIPostShortcodes(
        $instruction,
        get_permalink($post->ID),
        $post->post_title,
        html_entity_decode(get_bloginfo('title')),
        $post->post_excerpt,
        $post->post_content,
        $author_name,
        (string) get_the_post_thumbnail_url($post->ID, 'post-thumbnail'),
        '',
        '',
        $post->ID,
        '',
        '',
        '',
        '',
        '',
        ''
    );
}
