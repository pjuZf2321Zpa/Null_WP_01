<?php
defined('ABSPATH') or die(); 
function aiomatic_more()
{
$aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
?>
<div class="wp-header-end"></div>
<div class="aiomatic-admin-shell">
<?php aimogen_render_admin_hero(); ?>
<div class="aiomatic-admin-layout">
    <aside class="aiomatic-admin-sidebar">
         <div class="aiomatic-admin-sidebar-inner">
            <div class="aiomatic-sidebar-heading">
               <?php esc_html_e( 'More Features', 'aiomatic-automatic-ai-content-writer' ); ?>
            </div>
            <div class="aiomatic-sidebar-nav">
               <nav class="nav-tab-wrapper">
                  <a href="#tab-e" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧾</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Extensions", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-0" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧥</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Extra Features", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-1" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧪</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Media Library Extensions", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-2" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧰</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Content Wizard", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-3" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧭</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Comment Replier", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-10" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧮</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Product Review Writer", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-5" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧴</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("AI Taxonomy Descriptions", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-4" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⛉</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("[aicontent] Shortcode", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-6" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">♛</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Ultimate Membership Pro", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-11" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⚿</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Restrict Content Pro", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-12" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⛨</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Paid Memberships Pro", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-8" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">♚</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("AI Charts and Graphs", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-9" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">✍︎</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("AI Product/Post Writer", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-7" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">✑</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Developer Tools Tutorials", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
               </nav>
            </div>
            <div class="aiomatic-sidebar-footer">
               <strong><?php esc_html_e( 'Need a quick start?', 'aiomatic-automatic-ai-content-writer' ); ?></strong>
               <span><?php esc_html_e( '1. Check tutorials of more AI features offered by the plugin.', 'aimogen' ); ?></span>
               <span><?php esc_html_e( '2. Learn how to integrate Aimogen with many other plugins.', 'aimogen' ); ?></span>
               <span>
                  <?php esc_html_e( 'Watch tutorials on', 'aiomatic-automatic-ai-content-writer' ); ?>
                  <a href="https://www.youtube.com/channel/UCVLIksvzyk-D_oEdHab2Lgg" target="_blank" rel="noopener noreferrer">CodeRevolutionTV</a>
               </span>
            </div>
         </div>
      </aside>
<section class="aiomatic-admin-main">
<div class="gs_popuptype_holder seo_pops">
<div>
   <div id="tab-e" class="tab-content">
      <br/>
      
<section class="aiomatic-admin-main">
<div class="wp-header-end"></div><div class="aiomatic-top-message-new-extension">
	<?php echo esc_html_e('Extend your ', 'aiomatic-automatic-ai-content-writer');?> <strong>Aimogen</strong><?php esc_html_e(' plugin with extra features and functionality. Check additional available ', 'aiomatic-automatic-ai-content-writer');?> <strong>Extensions</strong> <a href="https://wpbay.com/product-tag/aiomatic/" target="_blank"><?php esc_html_e('here', 'aiomatic-automatic-ai-content-writer');?></a>
</div>
<div class="gs_popuptype_holder gs_display_table">
<form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to delete all logs?', 'aiomatic-automatic-ai-content-writer');?>');">
    <input name="aiomatic_delete" type="submit" value="<?php echo esc_html__('Delete Logs', 'aiomatic-automatic-ai-content-writer');?>" class="cr_none">
    <input name="aiomatic_nonce" type="hidden" value="<?php echo wp_create_nonce('openai-secret-nonce');?>">
</form>
<?php
$exts = aiomatic_get_extensions();
foreach ($exts as $k => $v):?>
	<div class="aiomatic-magic-box-wrap<?php echo ($v['enabled']) ? '' : ' aiomatic-disabled-box';?>">
		<a href="<?php if($v['enabled']) {echo esc_url($v['link']);}else{echo esc_url($v['getlink']);}?>" <?php if(!$v['enabled'] || $k == 'new_extension'):
			echo ' target="_blank" ';
		endif;
		?>
		>
			<div class="aiomatic-magic-feature <?php echo esc_html($k);?> <?php echo esc_html($v['extra_class']);?>">
				<?php if (isset($v['pro']) && $v['pro'] === TRUE){ ?>
						<div class="aiomatic-adm-ribbon aiomatic-adm-ribbon-top-left"><span>PRO</span></div>
				<?php } ?>
				<div class="aiomatic-magic-box-icon"><img src="<?php echo esc_url($v['icon']);?>"></div>
				<div class="aiomatic-magic-box-title"><?php echo esc_html($v['label']);?></div>
				<div class="aiomatic-magic-box-desc"><?php echo esc_html($v['description']);?></div>
                <?php
                if($k != 'new_extension')
                {
                    if($v['enabled'])
                    {
                    ?>
                    <div class="aiomatic-magic-box-desc">>> <?php echo esc_html_e('SETUP', 'aiomatic-automatic-ai-content-writer');?> <<</div>
                    <?php
                    }
                    else
                    {
                    ?>
                    <div class="aiomatic-magic-box-desc">>> <?php echo esc_html_e('GET IT', 'aiomatic-automatic-ai-content-writer');?> <<</div>
                    <?php
                    }
                }
                ?>
			</div>
		</a>
	</div>
<?php endforeach;?>
</div>
</section>
   </div>
        <div id="tab-0" class="tab-content">
         <br/>
<?php echo esc_html__("In addition to the powerful core features, Aimogen has some hidden gems that will take your website to the next level. Let's explore these exciting features and see how they can supercharge your site.", 'aiomatic-automatic-ai-content-writer');?>
<br/><br/>
<h3><?php echo esc_html__("Content Wizard:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("First up, we have the Content Wizard, your reliable companion in managing and optimizing your content. This intelligent assistant helps you with various tasks, from generating AI-powered meta tags to suggesting relevant keywords and optimizing your content for better search engine rankings. The Content Wizard is your virtual content strategist, guiding you every step of the way.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("AI Media Library Extensions:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Aimogen takes your media library to new heights with the AI Media Library Extension. With Extension 1, you can automatically generate alt text, captions, and descriptions for your images, saving you valuable time and effort. Extension 2 brings even more power by suggesting relevant tags and keywords for your media files, ensuring optimal search engine optimization and discoverability.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("Comment Replier:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Engaging with your audience is crucial, and Aimogen makes it easier with the Comment Replier feature. This handy tool uses AI algorithms to analyze and understand comments on your website, providing you with suggested responses. You can quickly reply to comments, foster meaningful conversations, and provide better user engagement, all with the help of AI.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("AI Taxonomy Description Writer:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("In WordPress, taxonomies are used to classify and organize content. They allow you to group posts, pages, or custom post types together based on shared characteristics. Taxonomies can be hierarchical (like categories) or non-hierarchical (like tags). When creating taxonomies in WP, it is important to set descriptions for SEO purposes.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("[aicontent] Shortcode:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("This is maybe the biggest 'hidden gem' of Aimogen. It is able to combine its power with any other plugin I created, allowing AI generated content to be produced in posts created by any other of my plugins. Imagine having AI-generated content in all your plugins, from social media to scraper plugins or news posts. Well, with Aimogen, that dream is now a reality.", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("In this video, I'll take a closer look at how the latest update of Aimogen works and what it can do for you. I'll explore how you can easily post AI-generated text to your social media channels, saving you time and effort while keeping your followers engaged.", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("I'll also dive into how Aimogen can enhance your scraped or news posts, ensuring that your content is always fresh, relevant, and engaging. Say goodbye to boring, uninspired content, and hello to Aimogen!", 'aiomatic-automatic-ai-content-writer');?></p>
<h3><?php echo esc_html__("Check The Tutorial Videos From The Above Tabs!", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("To access more details about each feature, simply navigate to the respective tabs at the top of this menu page. Within each tab, you'll find tutorial videos that walk you through the setup, configuration, and utilization of each feature. These videos provide step-by-step guidance, ensuring you make the most out of Aimogen's hidden features.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("Developer Tools Tutorials:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Aimogen allows developers to customize the prompts sent to the AI models and also the responses returned by the AI, before they are processed in the plugin, allowing high customizability of the AI and its results.", 'aiomatic-automatic-ai-content-writer');?></p>

<h3><?php echo esc_html__("AI Charts and Graphs", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("Using a special shortcode provided by the plugin, the AI writer can incorporate charts and graphs naturally into the created content, to visually represent data.", 'aiomatic-automatic-ai-content-writer') . '<br/>' . esc_html__("Usage of the shortcode: ", 'aiomatic-automatic-ai-content-writer');
echo '<br/><br/>[aiomatic_charts type="Pie|Doughnut|Radar|Bar|Line" labels="Label1,Label2" data="Value1,Value2" representing="Data1" colors="#RGB1,#RGB2"]<br/><br/>';
echo esc_html__("Customize the chart using:", 'aiomatic-automatic-ai-content-writer');?>
<ul><li>
<?php echo '- ' . esc_html__("type: Choose from Pie, Doughnut, Radar, Bar, Line,", 'aiomatic-automatic-ai-content-writer');?></li><li>
<?php echo '- ' . esc_html__("labels: Comma-separated list of labels (e.g., \"Monday,Tuesday\"),", 'aiomatic-automatic-ai-content-writer');?></li><li>
<?php echo '- ' . esc_html__("data: Comma-separated data points (e.g., \"10,20\"),", 'aiomatic-automatic-ai-content-writer');?></li><li>
<?php echo '- ' . esc_html__("representing: What is the chart data representing. (e.g., \"Birth Count\"),", 'aiomatic-automatic-ai-content-writer');?></li><li>
<?php echo '- ' . esc_html__("colors: the RGB color of each chart data section (e.g., \"#69D2E7,#a0a48C\").", 'aiomatic-automatic-ai-content-writer');?></li></ul></p>

<h3><a href="https://1.envato.market/UltimateMember" target="_blank"><?php echo esc_html__("'Ultimate Membership Pro' Integration:", 'aiomatic-automatic-ai-content-writer');?></a></h3>
<p><?php echo esc_html__("Integrate Aimogen with the 'Ultimate Membership Pro' plugin to offer exclusive functionality to your website's members. You can restrict plugin usage based on subscription plans, enabling you to effortlessly create an AI membership site.", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("Unlock the true potential of Aimogen's hidden features, harnessing the power of AI to streamline your content management, optimize your media library, engage with your audience, and enhance the visual impact of your website. It's time to take your WordPress experience to new heights with Aimogen!", 'aiomatic-automatic-ai-content-writer');?></p>

<p><?php echo esc_html__("Enjoy exploring Aimogen's hidden features and maximizing the potential of your WordPress website!", 'aiomatic-automatic-ai-content-writer');?></p>
       </div>
        <div id="tab-1" class="tab-content">
         <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
         <h3><?php echo esc_html__("Media Library Extensions Tutorial Videos:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/wRY6ElVZawI" frameborder="0" allowfullscreen></iframe></div></p>
    <h3><?php echo esc_html__("Automatic AI Written SEO Tags For Media Library Items:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/7MEPZhMVjf0" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-2" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("Content Wizard Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/e5tPgqOB8ss" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-3" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("AI Comment Replier Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/VknKvIcKRuw" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-10" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("AI WooCommerce Product Review Writer Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/GimgMmyVl5c" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-5" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("AI Taxonomy Description Writer Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/k5BFo9jcmcs" frameborder="0" allowfullscreen></iframe></div></p>
        <h3><?php echo esc_html__("Automate the AI Taxonomy Description Writing Process:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/1OibwD73JIA" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-6" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("'Ultimate Membership Pro' Integration Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/Ej4fPlA91N4" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-11" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("'Restrict Content Pro' Integration Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/7z4e7vp5ifk" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-12" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("'Paid Memberships Pro' Integration Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/6EBSMhp3zHM" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-9" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("AI Product/Post Writer Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/RGIzC-HFD0o" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-7" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <p><?php echo esc_html__("Check the filters and action hooks documentation of Aimogen,", 'aiomatic-automatic-ai-content-writer');?> <a href="https://coderevolution.ro/knowledge-base/faq/aiomatic-plugin-developer-documentation" target="_blank"><?php echo esc_html__("here", 'aiomatic-automatic-ai-content-writer');?></a>.</p>
        <h3><?php echo esc_html__("AI Content Filters Feature Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/lDJOnhSS_5o" frameborder="0" allowfullscreen></iframe></div></p>
        <h3><?php echo esc_html__("OpenAI API Functions Calling Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/dCOOQXqBHQM" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-8" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("AI Charts and Graphs", 'aiomatic-automatic-ai-content-writer');?></h3>
        <p>
<h2 class="wp-block-heading"><?php echo esc_html__("Overview:", 'aiomatic-automatic-ai-content-writer');?></h2>
<p><?php echo esc_html__("The aiomatic_charts", 'aiomatic-automatic-ai-content-writer');?> <?php echo esc_html__("shortcode allows users to embed dynamic and customizable charts and graphs into WordPress posts and pages. It supports multiple chart types, including:", 'aiomatic-automatic-ai-content-writer')?> Line, Bar, Radar, Pie, Doughnut, PolarArea, <?php echo esc_html__("and provides a wide range of customization options through shortcode parameters.", 'aiomatic-automatic-ai-content-writer');?></p>
<h3 class="wp-block-heading"><?php echo esc_html__("Shortcode Setup:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("To use the shortcode in your WordPress posts or pages, include it as follows:", 'aiomatic-automatic-ai-content-writer');?></p>
<p><code>[aiomatic_charts type="Line" title="SampleChart" data="10,20,30,40"]</code></p>
<h3 class="wp-block-heading"><?php echo esc_html__("Parameters:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p><?php echo esc_html__("The shortcode provides several parameters for chart customization:", 'aiomatic-automatic-ai-content-writer');?></p>
<ul>
<li><code>type</code> <?php echo esc_html__("(string): Specifies the type of chart to be displayed. Available options include:", 'aiomatic-automatic-ai-content-writer');?> Line, Bar, Radar, Pie, Doughnut, PolarArea. <?php echo esc_html__("Default:", 'aiomatic-automatic-ai-content-writer');?> <code>Line</code>.</li>
<li><code>title</code> <?php echo esc_html__("(string): A unique identifier for the chart, auto-generated using a prefix and a random suffix if not specified.", 'aiomatic-automatic-ai-content-writer');?></li>
<li><strong><?php echo esc_html__("Dimensions", 'aiomatic-automatic-ai-content-writer');?></strong>:
<ul>
<li><code>canvaswidth</code>: <?php echo esc_html__("Width of the chart canvas. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>625</code>.</li>
<li><code>canvasheight</code>: <?php echo esc_html__("Height of the chart canvas. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>625</code>.</li>
<li><code>width</code>: <?php echo esc_html__("Overall width of the chart container. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>100%</code>.</li>
<li><code>height</code>: <?php echo esc_html__("Overall height of the chart container. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>auto</code>.</li>
</ul>
</li>
<li><strong><?php echo esc_html__("Data Handling", 'aiomatic-automatic-ai-content-writer');?></strong>:
<ul>
<li><code>labels</code>: <?php echo esc_html__("Comma-separated list of labels for the chart's X-axis. Example:", 'aiomatic-automatic-ai-content-writer');?> <code>"Jan,Feb,Mar,Apr"</code>.</li>
<li><code>datalabels</code>: <?php echo esc_html__("Comma-separated list of labels for each data series in Line, Radar, and Bar charts.", 'aiomatic-automatic-ai-content-writer');?></li>
<li><code>data</code>: <?php echo esc_html__("Comma-separated list of data points for simple charts (e.g., Pie, Doughnut).", 'aiomatic-automatic-ai-content-writer');?></li>
<li><code>datasets</code>: <?php echo esc_html__("Data points for complex charts (e.g., Line, Bar), separated by", 'aiomatic-automatic-ai-content-writer');?> <code>next</code>.</li>
</ul>
</li>
<li><strong><?php echo esc_html__("Customization", 'aiomatic-automatic-ai-content-writer');?></strong>:
<ul>
<li><code>colors</code>: <?php echo esc_html__("Comma-separated list of colors to style each dataset or data point. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>#69D2E7,#a0a48C,#F38630,#96CE7F,#CEBC17,#CE4264</code>.</li>
<li><code>fillopacity</code>: <?php echo esc_html__("Opacity level for filling chart areas. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>0.7</code>.</li>
<li><code>animation</code>: <?php echo esc_html__("Enable or disable animation (true/false). Default:", 'aiomatic-automatic-ai-content-writer');?> <code>true</code>.</li>
</ul>
</li>
<li><strong><?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></strong>:
<ul>
<li><code>scalefontsize</code>: <?php echo esc_html__("Size of scale labels in pixels. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>12</code>.</li>
<li><code>scalefontcolor</code>: <?php echo esc_html__("Color of the scale labels. Default:", 'aiomatic-automatic-ai-content-writer');?> <code>#666</code>.</li>
<li><code>scaleoverride</code>: <?php echo esc_html__("Custom scale override (true/false). Default:", 'aiomatic-automatic-ai-content-writer');?> <code>false</code>.</li>
<li><code>scalesteps</code>, <code>scalestepwidth</code>, <code>scalestartvalue</code>: <?php echo esc_html__("Custom scale parameters.", 'aiomatic-automatic-ai-content-writer');?></li>
</ul>
</li>
</ul>
<h3 class="wp-block-heading"><?php echo esc_html__("Behavior Controls:", 'aiomatic-automatic-ai-content-writer');?></h3>
<ul>
<li><strong><?php echo esc_html__("Script/Style Loading", 'aiomatic-automatic-ai-content-writer');?></strong>: <?php echo esc_html__("Scripts and styles are conditionally loaded to prevent conflicts in admin pages, utilizing the WordPress", 'aiomatic-automatic-ai-content-writer');?> <code>pagenow</code> <?php echo esc_html__("global variable.", 'aiomatic-automatic-ai-content-writer');?></li>
<li><strong><?php echo esc_html__("Responsive Design", 'aiomatic-automatic-ai-content-writer');?></strong>: <?php echo esc_html__("CSS styles are included within the shortcode for both regular and mobile views.", 'aiomatic-automatic-ai-content-writer');?></li></ul>
<h3 class="wp-block-heading"><?php echo esc_html__("Usage Examples:", 'aiomatic-automatic-ai-content-writer');?></h3>
<ol>
<li><strong><?php echo esc_html__("Line Chart Example", 'aiomatic-automatic-ai-content-writer');?></strong>: <code>[aiomatic_charts type="Line" title="MonthlySales" labels="Jan,Feb,Mar,Apr" data="30,50,70,90"]</code></li>
<li><strong><?php echo esc_html__("Pie Chart Example", 'aiomatic-automatic-ai-content-writer');?></strong>: <code>[aiomatic_charts type="Pie" title="ExpenseDistribution" labels="Rent,Utilities,Groceries" data="40,30,30" colors="#FF6384,#36A2EB,#FFCE56"]</code></li>
</ol>
<h3 class="wp-block-heading"><?php echo esc_html__("AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p>
<?php echo esc_html__("You can use the below prompt (or any other variation of it, to instruct the AI to use the chart shortcode to generate charts and graphs using it, directly in the content it creates:", 'aiomatic-automatic-ai-content-writer');?>
<br/><br/><code>Incorporate the [aiomatic_charts] shortcode naturally into the created content, to visually represent data using dynamic charts. Usage:
[aiomatic_charts type="Pie|Doughnut|Radar|Bar|Line" labels="Label1,Label2" data="Value1,Value2" representing="Data1" colors="#RGB1,#RGB2"]
Customize the chart using:
- type: Choose from Pie, Doughnut, Radar, Bar, Line,
- labels: Comma-separated list of labels (e.g., "Monday,Tuesday"),
- data: Comma-separated data points (e.g., "10,20"),
- representing: What is the chart data representing. (e.g., "Birth Count"),
- colors: the RGB color of each chart data section (e.g., "#69D2E7,#a0a48C").
</code>
</p>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
<h3 class="wp-block-heading"><?php echo esc_html__("Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/H3VUDhxWEtA" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
        <div id="tab-4" class="tab-content">
        <br/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
        <h3><?php echo esc_html__("[aicontent] Shortcode Tutorial Video:", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/z_mGPlBsQQA" frameborder="0" allowfullscreen></iframe></div></p>
        <h3><?php echo esc_html__("[aicontent] Nested Shortcode Support (Advanced Feature):", 'aiomatic-automatic-ai-content-writer');?></h3>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/SdNjVEfQzhs" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
        </div>
</div>
</div>
<?php
}
?>