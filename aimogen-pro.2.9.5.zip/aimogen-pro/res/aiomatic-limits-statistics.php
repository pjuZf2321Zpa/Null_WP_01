<?php
defined('ABSPATH') or die(); 

/*
 * Builds a plain-text, support-friendly diagnostics report for the "Copy diagnostics"
 * button on the System & Logs page. It intentionally contains NO secrets: API keys are
 * reported only as "configured / not configured" booleans, never their values.
 */
if (!function_exists('aimogen_build_diagnostics_report')) {
function aimogen_build_diagnostics_report()
{
    global $wpdb;

    $settings = get_option('aiomatic_Main_Settings', array());
    if (!is_array($settings)) {
        $settings = array();
    }

    $bool_yn = function ($value) {
        return $value ? 'yes' : 'no';
    };

    // --- REST API reachability (cached to avoid a remote call on every page load) ---
    $rest_status = get_transient('aimogen_diag_rest_status');
    if ($rest_status === false) {
        $rest_probe = wp_remote_get(rest_url(), array(
            'timeout'   => 8,
            'sslverify' => false,
            'headers'   => array('Accept' => 'application/json'),
        ));
        if (is_wp_error($rest_probe)) {
            $rest_status = 'unreachable (' . $rest_probe->get_error_message() . ')';
        } else {
            $rc = (int) wp_remote_retrieve_response_code($rest_probe);
            if ($rc === 200) {
                $rest_status = 'reachable (HTTP 200)';
            } elseif ($rc >= 200 && $rc < 500) {
                $rest_status = 'responded (HTTP ' . $rc . ')';
            } else {
                $rest_status = 'error (HTTP ' . $rc . ')';
            }
        }
        set_transient('aimogen_diag_rest_status', $rest_status, 5 * MINUTE_IN_SECONDS);
    }

    // --- Providers: report only whether a key is present, never the key itself. ---
    $provider_fields = array(
        'OpenAI'             => 'app_id',
        'xAI'                => 'app_id_xai',
        'Anthropic Claude'   => 'app_id_claude',
        'Google Gemini'      => 'app_id_google',
        'Perplexity'         => 'app_id_perplexity',
        'Groq'               => 'app_id_groq',
        'NVIDIA'             => 'app_id_nvidia',
        'Together AI'        => 'app_id_together',
        'Mistral AI'         => 'app_id_mistral',
        'DeepSeek'           => 'app_id_deepseek',
        'Fireworks AI'       => 'app_id_fireworks',
        'OpenRouter'         => 'app_id_openrouter',
        'HuggingFace'        => 'app_id_huggingface',
        'Stability AI'       => 'stability_app_id',
        'Replicate'          => 'replicate_app_id',
        'Ideogram'           => 'ideogram_app_id',
        'ElevenLabs'         => 'elevenlabs_app_id',
        'GoAPI (Midjourney)' => 'midjourney_app_id',
    );
    $providers_configured = 0;
    $provider_lines       = array();
    foreach ($provider_fields as $label => $field) {
        $has = isset($settings[$field]) && trim((string) $settings[$field]) !== '';
        if ($has) {
            $providers_configured++;
        }
        $provider_lines[] = '  - ' . $label . ': ' . $bool_yn($has);
    }

    $free_active = (apply_filters('aimogen-is-installed', false) === true) || function_exists('aimogen_get_version');

    $plugin_version = defined('AIMOGEN_MAJOR_VERSION') ? AIMOGEN_MAJOR_VERSION : 'unknown';

    $memory_php = ini_get('memory_limit');
    $memory_wp  = defined('WP_MEMORY_LIMIT') ? size_format(aiomatic_let_to_num(WP_MEMORY_LIMIT)) : 'n/a';

    $curl_version = function_exists('curl_version') ? curl_version() : false;

    $rest_keys_configured = isset($settings['rest_api_keys']) && trim((string) $settings['rest_api_keys']) !== '';
    $usage_tracking       = isset($settings['enable_tracking']) && trim((string) $settings['enable_tracking']) === 'on';
    $default_model        = defined('AIMOGEN_DEFAULT_MODEL') ? AIMOGEN_DEFAULT_MODEL : 'n/a';
    $reliability_enabled  = isset($settings['reliability_mode']) && $settings['reliability_mode'] === 'on';
    $reliability_models   = function_exists('aimogen_reliability_model_list')
        ? aimogen_reliability_model_list($settings)
        : array();
    $reliability_scope    = function_exists('aimogen_reliability_scope')
        ? aimogen_reliability_scope($settings)
        : 'cross_provider';
    $reliability_attempts = function_exists('aimogen_reliability_max_attempts')
        ? aimogen_reliability_max_attempts($settings)
        : 2;
    $reliability_cooldown = function_exists('aimogen_reliability_cooldown_minutes')
        ? aimogen_reliability_cooldown_minutes($settings)
        : 10;
    $smart_key_rotation   = function_exists('aimogen_smart_key_rotation_enabled')
        ? aimogen_smart_key_rotation_enabled($settings)
        : false;
    $smart_key_cooldown   = function_exists('aimogen_smart_key_cooldown_minutes')
        ? aimogen_smart_key_cooldown_minutes($settings)
        : 10;
    $smart_key_quarantine = function_exists('aimogen_smart_key_quarantine_hours')
        ? aimogen_smart_key_quarantine_hours($settings)
        : 6;
    $smart_key_health     = function_exists('aimogen_smart_key_health_summary')
        ? aimogen_smart_key_health_summary($settings)
        : array();
    $reliability_success  = get_transient('aimogen_reliability_last_success');
    $reliability_failure  = get_transient('aimogen_reliability_last_failure');

    $lines   = array();
    $lines[] = '=== Aimogen Pro diagnostics ===';
    $lines[] = 'Generated: ' . gmdate('Y-m-d H:i:s') . ' UTC';
    $lines[] = '';

    $lines[] = '[Plugin]';
    $lines[] = 'Aimogen Pro version: ' . $plugin_version;
    $lines[] = 'Free Aimogen plugin active: ' . $bool_yn($free_active);
    $lines[] = 'Default text model: ' . $default_model;
    $lines[] = 'Usage tracking enabled: ' . $bool_yn($usage_tracking);
    $lines[] = '';

    $lines[] = '[Reliability Mode]';
    $lines[] = 'Enabled: ' . $bool_yn($reliability_enabled);
    $lines[] = 'Fallback models configured: ' . count($reliability_models);
    $lines[] = 'Provider scope: ' . ($reliability_scope === 'same_provider' ? 'original provider only' : 'any configured provider');
    $lines[] = 'Maximum fallback attempts: ' . $reliability_attempts;
    $lines[] = 'Failure cooldown: ' . $reliability_cooldown . ' minute(s)';
    $lines[] = 'Smart API-key rotation: ' . $bool_yn($smart_key_rotation);
    $lines[] = 'API-key cooldown: ' . $smart_key_cooldown . ' minute(s)';
    $lines[] = 'Credential/quota quarantine: ' . $smart_key_quarantine . ' hour(s)';
    foreach ($smart_key_health as $key_health) {
        $lines[] = sprintf(
            'API-key health, %s: %d configured, %d healthy, %d cooling, %d quarantined',
            isset($key_health['label']) ? $key_health['label'] : 'unknown provider',
            isset($key_health['configured']) ? (int) $key_health['configured'] : 0,
            isset($key_health['healthy']) ? (int) $key_health['healthy'] : 0,
            isset($key_health['cooldown']) ? (int) $key_health['cooldown'] : 0,
            isset($key_health['quarantined']) ? (int) $key_health['quarantined'] : 0
        );
    }
    if (is_array($reliability_success) && isset($reliability_success['time'])) {
        $lines[] = 'Last recovered request: ' . gmdate('Y-m-d H:i:s', (int) $reliability_success['time']) . ' UTC'
            . ' (' . (isset($reliability_success['original_model']) ? $reliability_success['original_model'] : 'unknown')
            . ' -> ' . (isset($reliability_success['final_model']) ? $reliability_success['final_model'] : 'unknown') . ')';
    }
    if (is_array($reliability_failure) && isset($reliability_failure['time'])) {
        $lines[] = 'Last exhausted request: ' . gmdate('Y-m-d H:i:s', (int) $reliability_failure['time']) . ' UTC'
            . ' (' . (isset($reliability_failure['original_model']) ? $reliability_failure['original_model'] : 'unknown')
            . ' -> ' . (isset($reliability_failure['final_model']) ? $reliability_failure['final_model'] : 'unknown') . ')';
    }
    $lines[] = '';

    $lines[] = '[WordPress]';
    $lines[] = 'Home URL: ' . home_url('/');
    $lines[] = 'Site URL: ' . site_url();
    $lines[] = 'WP version: ' . get_bloginfo('version');
    $lines[] = 'Multisite: ' . $bool_yn(is_multisite());
    $lines[] = 'Locale: ' . get_locale();
    $lines[] = 'WP_DEBUG: ' . $bool_yn(defined('WP_DEBUG') && WP_DEBUG);
    $lines[] = 'Active theme: ' . (function_exists('wp_get_theme') ? (wp_get_theme()->get('Name') . ' ' . wp_get_theme()->get('Version')) : 'n/a');
    $lines[] = '';

    $lines[] = '[Server / PHP]';
    $lines[] = 'PHP version: ' . (function_exists('phpversion') ? phpversion() : PHP_VERSION);
    $lines[] = 'PHP OS: ' . PHP_OS;
    $lines[] = 'Server software: ' . (isset($_SERVER['SERVER_SOFTWARE']) ? sanitize_text_field($_SERVER['SERVER_SOFTWARE']) : 'n/a');
    $lines[] = 'MySQL version: ' . (isset($wpdb) ? $wpdb->db_version() : 'n/a');
    $lines[] = '';

    $lines[] = '[PHP limits]';
    $lines[] = 'PHP memory_limit: ' . $memory_php;
    $lines[] = 'WP memory limit: ' . $memory_wp;
    $lines[] = 'max_execution_time: ' . ini_get('max_execution_time');
    $lines[] = 'max_input_vars: ' . ini_get('max_input_vars');
    $lines[] = 'post_max_size: ' . ini_get('post_max_size');
    $lines[] = 'upload_max_filesize: ' . ini_get('upload_max_filesize');
    $lines[] = 'WP max upload size: ' . size_format(wp_max_upload_size());
    $lines[] = '';

    $lines[] = '[PHP extensions]';
    $lines[] = 'cURL: ' . ($curl_version ? ('yes (' . $curl_version['version'] . ', ' . $curl_version['ssl_version'] . ')') : 'no');
    $lines[] = 'OpenSSL: ' . $bool_yn(extension_loaded('openssl'));
    $lines[] = 'mbstring: ' . $bool_yn(extension_loaded('mbstring'));
    $lines[] = 'dom: ' . $bool_yn(extension_loaded('dom'));
    $lines[] = 'xml: ' . $bool_yn(extension_loaded('xml'));
    $lines[] = 'GD: ' . $bool_yn(extension_loaded('gd'));
    $lines[] = '';

    $lines[] = '[Connectivity]';
    $lines[] = 'Remote POST: ' . (function_exists('aiomatic_test_post_reponse') ? ($bool_yn(aiomatic_test_post_reponse())) : 'n/a');
    $lines[] = 'Remote GET: ' . (function_exists('aiomatic_test_get_reponse') ? ($bool_yn(aiomatic_test_get_reponse())) : 'n/a');
    if (function_exists('aiomatic_check_cron_status')) {
        $cron_status = aiomatic_check_cron_status();
        $lines[] = 'WP-Cron running: ' . (is_wp_error($cron_status) ? ('no (' . $cron_status->get_error_message() . ')') : 'yes');
    }
    $lines[] = 'REST API base: ' . esc_url_raw(rest_url());
    $lines[] = 'REST API status: ' . $rest_status;
    $lines[] = 'Pretty permalinks: ' . $bool_yn(get_option('permalink_structure') !== '');
    $lines[] = 'Shared REST API keys configured: ' . $bool_yn($rest_keys_configured);
    $lines[] = '';

    $lines[] = '[Providers configured] (' . $providers_configured . ' of ' . count($provider_fields) . ')';
    $lines   = array_merge($lines, $provider_lines);
    $lines[] = '';

    // Active plugins (names + versions only).
    $active_plugins = (array) get_option('active_plugins', array());
    if (is_multisite()) {
        $active_plugins = array_merge($active_plugins, array_keys((array) get_site_option('active_sitewide_plugins', array())));
    }
    if (!function_exists('get_plugin_data')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $lines[] = '[Active plugins] (' . count($active_plugins) . ')';
    foreach ($active_plugins as $plugin) {
        $plugin_file = WP_PLUGIN_DIR . '/' . $plugin;
        if (file_exists($plugin_file)) {
            $data = get_plugin_data($plugin_file, false, false);
            if (!empty($data['Name'])) {
                $lines[] = '  - ' . $data['Name'] . ' ' . (isset($data['Version']) ? $data['Version'] : '');
            }
        }
    }

    return implode("\n", $lines);
}
}

function aiomatic_get_editable_roles() {
   global $wp_roles;
   $all_roles = $wp_roles->roles;
   $editable_roles = apply_filters('editable_roles', $all_roles);
   return $editable_roles;
}
function aiomatic_save_restrictions($data) {
   check_admin_referer( 'aiomatic_save_restrictions', '_aiomaticr_nonce_restrictions' );
   $data = $_POST['aiomatic_Limit_Rules'];
   $restrictions = array();
   for($i = 0; $i < sizeof($data['user_credits']); ++$i) {
         $bundle = array();
         $user_credits = trim( sanitize_text_field( $data['user_credits'][$i] ) );
         $bundle[] = $user_credits;
         $bundle[] = trim($data['user_credit_type'][$i]);
         $bundle[] = trim( sanitize_text_field( $data['user_time_frame'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['absolute'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['role'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['active'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['ums_sub'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['message'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['rule_description'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['user_list'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['rest_sub'][$i] ) );
         $bundle[] = trim( sanitize_text_field( $data['paid_sub'][$i] ) );
      if ($user_credits == '') { continue; }
      else { $restrictions[$i] = $bundle; }
   }
   aiomatic_update_option('aiomatic_Limit_Rules', $restrictions);
}
if (isset($_POST['aiomatic_Limit_Rules'])) {
	add_action('admin_init', 'aiomatic_save_restrictions');
}
function aiomatic_save_menu_limits($data) {
   check_admin_referer( 'aiomatic_save_menus', '_aiomaticr_nonce' );
   $data = $_POST['aiomatic_Menu_Rules'];
   $restrictions = array();
   $cat_cont = 0;
   for($i = 0; $i < sizeof($data['role']); ++$i) 
   {
      $bundle = array();
      $user_roles = $data['role'][$i];
      $bundle[] = $user_roles;
      if($i == sizeof($data['role']) - 1)
      {
            if(isset($data['menu_limit']))
            {
               $bundle[]     = $data['menu_limit'];
            }
            else
            {
               if(!isset($data['menu_limit' . $cat_cont]))
               {
                  $cat_cont++;
               }
               if(!isset($data['menu_limit' . $cat_cont]))
               {
                  $bundle[]     = array('');
               }
               else
               {
                  $bundle[]     = $data['menu_limit' . $cat_cont];
               }
            }
      }
      else
      {
            if(!isset($data['menu_limit' . $cat_cont]))
            {
               $cat_cont++;
            }
            if(!isset($data['menu_limit' . $cat_cont]))
            {
               $bundle[]     = array('');
            }
            else
            {
               $bundle[]     = $data['menu_limit' . $cat_cont];
            }
      }
      $bundle[] = $data['rule_description'][$i];
      $cat_cont++; 
      if (empty($user_roles)) 
      { 
         continue; 
      }
      else 
      { 
         $restrictions[$i] = $bundle;
      }
   }
   $restrictions = aimogen_filter_retired_assistants_from_menu_rules($restrictions);
   aiomatic_update_option('aiomatic_Menu_Rules', $restrictions);
}
if (isset($_POST['aiomatic_Menu_Rules'])) {
	add_action('admin_init', 'aiomatic_save_menu_limits');
}
function aiomatic_expand_limitations($roles) {
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   if(empty(trim($aiomatic_Main_Settings['app_id'])))
   {
       return 'You need to add an API key in plugin settings for this to work!';
   }
   $limitations = get_option('aiomatic_Limit_Rules');
   $output = '';
   if (!empty($limitations)) {
      $name = md5(get_bloginfo());
      wp_register_script($name . '-stats-extra-script', '');
      wp_enqueue_script($name . '-stats-extra-script');
      foreach ($limitations as $cont => $bundle[]) {
              $bundle_values = array_values($bundle); 
              $myValues = $bundle_values[$cont];
              
              $array_my_values = array_values($myValues);
              for($iji=0;$iji<count($array_my_values);++$iji){if(is_string($array_my_values[$iji])){$array_my_values[$iji]=stripslashes($array_my_values[$iji]);}} 
              $user_credits = $array_my_values[0];
              $user_credit_type = $array_my_values[1];
              $user_time_frame = $array_my_values[2];
              $absolute = $array_my_values[3];
              $role = $array_my_values[4];
              $active = $array_my_values[5];
              $ums_sub = $array_my_values[6];
              $message = $array_my_values[7];
              $rule_description = $array_my_values[8];
              $user_list = $array_my_values[9];
              $rest_sub = $array_my_values[10];
              $paid_sub = $array_my_values[11];
              if($rule_description == '')
              {
                 $rule_description = $cont;
              }
              wp_add_inline_script($name . '-stats-extra-script', 'aiomaticCreateAdmin(' . esc_html($cont) . ');', 'after');
         $output .= '
         <tr>
            <td class="cr_td_xo"><input type="text" name="aiomatic_Limit_Rules[rule_description][]" id="rule_description' . esc_html($cont) . '" class="cr_center" placeholder="Rule ID" value="' . esc_html($rule_description) . '" class="cr_width_full"/></td>
            <td class="cr_min_100"><input type="number" min="0" required step="0.01" name="aiomatic_Limit_Rules[user_credits][]" value="'.esc_attr($user_credits).'" class="cr_width_full" placeholder="Maximum Credits For Users"/></td>
            <td class="cr_min_100">
            <select name="aiomatic_Limit_Rules[user_credit_type][]" class="cr_width_full">
                <option value="queries" ';
                if($user_credit_type === 'queries')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Queries', 'aiomatic-automatic-ai-content-writer') . '</option>';
$appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
$appids = array_filter($appids);
if(empty($appids)){$token = '';}else{$token = $appids[array_rand($appids)];}
$token = apply_filters('aimogen_openai_api_key', $token);$token = apply_filters('aiomatic_openai_api_key', $token);
if(!aiomatic_is_aiomaticapi_key($token))
{
   $output .= '<option value="units" ';
                if($user_credit_type === 'units')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Tokens', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="price" ';
                if($user_credit_type === 'price')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Price', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="pdf" ';
                if($user_credit_type === 'pdf')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Maximum Chatbot Uploaded PDF Page Count (Per PDF File)', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="pdfchar" ';
                if($user_credit_type === 'pdfchar')
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Maximum Chatbot Uploaded PDF Character Count (Per PDF File)', 'aiomatic-automatic-ai-content-writer') . '</option>';
}
                $output .= '</select></td>
            <td class="cr_6cust"><select class="cr_max_width_80" name="aiomatic_Limit_Rules[user_time_frame][]">
            <option value="day" ';
            if($user_time_frame === 'day')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Day', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="week" ';
            if($user_time_frame === 'week')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Week', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="month" ';
            if($user_time_frame === 'month')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Month', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="year" ';
            if($user_time_frame === 'year')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Year', 'aiomatic-automatic-ai-content-writer') . '</option>
            </select></td>
            <td class="cr_td_q">
            <select class="cr_max_width_80" name="aiomatic_Limit_Rules[absolute][]">
            <option value="0" ';
            if($absolute === '0')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('No', 'aiomatic-automatic-ai-content-writer') . '</option>
            <option value="1" ';
            if($absolute === '1')
            {
                  $output .= 'selected="selected"';
            }
            $output .= '>' . esc_html__('Yes', 'aiomatic-automatic-ai-content-writer') . '</option>
            </select></td>
            <td class="cr_width_70">
         <center><input type="button" id="mybtnfzr' . esc_html($cont) . '" class="button" value="Settings"></center>
         <div id="mymodalfzr' . esc_html($cont) . '" class="codemodalfzr">
<div class="codemodalfzr-content">
<div class="codemodalfzr-header">
<span id="aiomatic_close' . esc_html($cont) . '" class="codeclosefzr">&times;</span>
<h2>' . esc_html__('Rule', 'aiomatic-automatic-ai-content-writer') . ' <span class="cr_color_white">ID ' . esc_html($cont) . '</span> ' . esc_html__('Advanced Settings', 'aiomatic-automatic-ai-content-writer') . '</h2>
</div>
<div class="codemodalfzr-body">
<div class="table-responsive">
<table class="responsive table cr_main_table_nowr">
<tr><td colspan="2"><h2>' . esc_html__('What to Restrict', 'aiomatic-automatic-ai-content-writer') . ':</h2></td></tr>
<tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text" >' . esc_html__('Select the user role to be restricted.', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b>' . esc_html__("User Role:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <select name="aiomatic_Limit_Rules[role][]" class="cr_width_full">
      <option value="none" ';
         if($role === 'none')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Don\'t check', 'aiomatic-automatic-ai-content-writer') . '</option>
      <option value="any" ';
         if($role === 'any')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Apply For Any Role', 'aiomatic-automatic-ai-content-writer') . '</option>';
      foreach($roles as $urole => $caps)
      {
         $output .= '<option value="' . $urole . '"';
         if($urole === $role)
         {
            $output .= ' selected="selected"';
         }
         $output .= '>' . $urole . '</option>';
      }
      $output .= '</select>
  </div>
  </td></tr>
<tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text" >' . esc_html__('Integration with \'Ultimate Membership Pro\'', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b><a href="https://1.envato.market/UltimateMember" target="_blank">' . esc_html__("Ultimate Membership Pro", 'aiomatic-automatic-ai-content-writer')  . '</a>&nbsp;' . esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <select name="aiomatic_Limit_Rules[ums_sub][]" class="cr_width_full">
      <option value="none" ';
         if($ums_sub === 'none')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Don\'t check', 'aiomatic-automatic-ai-content-writer') . '</option>';
$levels = array();
if(class_exists('\Indeed\Ihc\Db\Memberships') && function_exists('ihc_reorder_arr'))
{
   $levels = \Indeed\Ihc\Db\Memberships::getAll();
   $levels = ihc_reorder_arr($levels);
}
if(count($levels) > 0)
{
   $output .= '<option value="any" ';
   if($ums_sub === 'any')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Apply For Any Subscription', 'aiomatic-automatic-ai-content-writer') . '</option>';
   $output .= '<option value="nosub" ';
   if($ums_sub === 'nosub')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Not Subscribed Users', 'aiomatic-automatic-ai-content-writer') . '</option>';
}
      foreach($levels as $levelid => $larr)
      {
         $output .= '<option value="' . esc_attr($levelid) . '"';
         if((string)$levelid === $ums_sub)
         {
            $output .= ' selected="selected"';
         }
         $output .= '>' . esc_html($larr['label']) . '</option>';
      }
      $output .= '</select>
  </div>
  </td></tr>
<tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text" >' . esc_html__('Integration with \'Restrict Content Pro\'', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b><a href="https://restrictcontentpro.com/pricing/" target="_blank">' . esc_html__("Restrict Content Pro", 'aiomatic-automatic-ai-content-writer')  . '</a>&nbsp;' . esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <select name="aiomatic_Limit_Rules[rest_sub][]" class="cr_width_full">
      <option value="none" ';
         if($rest_sub === 'none')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Don\'t check', 'aiomatic-automatic-ai-content-writer') . '</option>';
$levels = array();
if(function_exists('rcp_get_membership_levels'))
{
   $levels = rcp_get_membership_levels();
}
if(count($levels) > 0)
{
   $output .= '<option value="any" ';
   if($rest_sub === 'any')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Apply For Any Subscription', 'aiomatic-automatic-ai-content-writer') . '</option>';
   $output .= '<option value="nosub" ';
   if($rest_sub === 'nosub')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Not Subscribed Users', 'aiomatic-automatic-ai-content-writer') . '</option>';
}
      foreach($levels as $level)
      {
         $output .= '<option value="' . esc_attr($level->id) . '"';
         if((string)$level->id === $rest_sub)
         {
            $output .= ' selected="selected"';
         }
         $output .= '>' . esc_html($level->name) . '</option>';
      }
      $output .= '</select>
  </div>
  </td></tr>
<tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text" >' . esc_html__('Integration with \'Paid Memberships Pro\'', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b><a href="https://www.paidmembershipspro.com/pricing/" target="_blank">' . esc_html__("Paid Memberships Pro", 'aiomatic-automatic-ai-content-writer')  . '</a>&nbsp;' . esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <select name="aiomatic_Limit_Rules[paid_sub][]" class="cr_width_full">
      <option value="none" ';
         if($paid_sub === 'none')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Don\'t check', 'aiomatic-automatic-ai-content-writer') . '</option>';
$levels = array();
if (function_exists('pmpro_getAllLevels')) 
{
   $levels = pmpro_getAllLevels(false, true);
}
if(count($levels) > 0)
{
   $output .= '<option value="any" ';
   if($paid_sub === 'any')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Apply For Any Subscription', 'aiomatic-automatic-ai-content-writer') . '</option>';
   $output .= '<option value="nosub" ';
   if($paid_sub === 'nosub')
   {
         $output .= 'selected="selected"';
   }
   $output .= '>' . esc_html__('Not Subscribed Users', 'aiomatic-automatic-ai-content-writer') . '</option>';
}
      foreach($levels as $level)
      {
         $output .= '<option value="' . esc_attr($level->id) . '"';
         if((string)$level->id === $paid_sub)
         {
            $output .= ' selected="selected"';
         }
         $output .= '>' . esc_html($level->name) . '</option>';
      }
      $output .= '</select>
  </div>
  </td></tr>
<tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text" >' . esc_html__('Set the user ID list to cover with this restriction. You can enter a comma separated list of user IDs.', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b>'. esc_html__("User ID List:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <input type="text" name="aiomatic_Limit_Rules[user_list][]" value="'.esc_attr($user_list).'" class="cr_width_full" placeholder="User ID List"/>
  </div>
  </td></tr>
  <tr><td colspan="2"><h2>' . esc_html__('More Settings', 'aiomatic-automatic-ai-content-writer') . ':</h2></td></tr>
  <tr>
<td class="cr_min_width_200">
<div>
  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text">' . esc_html__('Set the message to show to restricted users.', 'aiomatic-automatic-ai-content-writer') . '
         </div>
      </div>
      <b>' . esc_html__("User Restricted Message:", 'aiomatic-automatic-ai-content-writer') . '</b>
      
      </td><td>
      <input type="text" name="aiomatic_Limit_Rules[message][]" value="'.esc_attr($message).'" class="cr_width_full" placeholder="You are restricted"/>
  </div>
  </td></tr>
</table></div> 
</div>
<div class="codemodalfzr-footer">
<br/>
<h3 class="cr_inline">Aimogen Restrictions</h3><span id="aiomatic_ok' . esc_html($cont) . '" class="codeokfzr cr_inline">OK&nbsp;</span>
<br/><br/>
</div>
</div>

</div>     
              </td>
              <td class="cr_30 cr_center" ><span class="wpaiomatic-delete">X</span></td>
                  <td class="cr_short_td">
                  <select name="aiomatic_Limit_Rules[active][]" class="cr_width_full">
      <option value="1" ';
         if($active === '1')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('Yes', 'aiomatic-automatic-ai-content-writer') . '</option>
         <option value="0" ';
         if($active === '0')
         {
               $output .= 'selected="selected"';
         }
         $output .= '>' . esc_html__('No', 'aiomatic-automatic-ai-content-writer') . '</option></select></td>
         </tr>	
         ';
              $cont = $cont + 1;
      }
   }
   return $output;
}

function aiomatic_expand_menu_limits($roles) {
   $limitations = get_option('aiomatic_Menu_Rules');
   $output = '';
   if (!empty($limitations)) {
      foreach ($limitations as $cont => $bundle[]) {
              $bundle_values = array_values($bundle); 
              $myValues = $bundle_values[$cont];
              
              $array_my_values = array_values($myValues);
              for($iji=0;$iji<count($array_my_values);++$iji){if(is_string($array_my_values[$iji])){$array_my_values[$iji]=stripslashes($array_my_values[$iji]);}} 
              $user_role = $array_my_values[0];
              $user_menus = $array_my_values[1];
              $rule_description = $array_my_values[2];
              if(!is_array($user_menus))
              {
                 $user_menus = array($user_menus);
              }
              if($rule_description == '')
              {
                 $rule_description = $cont;
              }
         $output .= '
         <tr>
            <td class="cr_td_xo"><input type="text" name="aiomatic_Menu_Rules[rule_description][]" id="rule_description' . esc_html($cont) . '" class="cr_center" placeholder="Rule ID" value="' . esc_html($rule_description) . '" class="cr_width_full"/></td>
            <td class="cr_min_100"><select name="aiomatic_Menu_Rules[role][]" class="cr_width_full">';
      foreach($roles as $urole => $caps)
      {
         $output .= '<option value="' . $urole . '"';
         if($urole === $user_role)
         {
            $output .= ' selected="selected"';
         }
         $output .= '>' . $urole . '</option>';
      }
      $output .= '</select></td>
            <td class="cr_min_100">
            <select required multiple name="aiomatic_Menu_Rules[menu_limit' . esc_html($cont) . '][]" class="cr_width_full">
                <option value="aiomatic_admin_settings" ';
                if(in_array('aiomatic_admin_settings', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Settings', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_omniblocks" ';
                if(in_array('aiomatic_omniblocks', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI OmniBlocks', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_bulk_creators" ';
                if(in_array('aiomatic_bulk_creators', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('Bulk AI Post Creator', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_spinner_panel" ';
                if(in_array('aiomatic_spinner_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Content Editor', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_chatbot_panel" ';
                if(in_array('aiomatic_chatbot_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Chatbot', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_agents_panel" ';
                if(in_array('aiomatic_agents_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Agents', 'aiomatic-automatic-ai-content-writer') . '</option>';
                if(!(defined('AIMOGEN_ASSISTANTS_API_RETIRED') && AIMOGEN_ASSISTANTS_API_RETIRED))
                {
                    $output .= '<option value="aiomatic_assistants_panel" ';
                    if(in_array('aiomatic_assistants_panel', $user_menus))
                    {
                        $output .= 'selected="selected"';
                    }
                    $output .= '>' . esc_html__('AI Assistants', 'aiomatic-automatic-ai-content-writer') . '</option>';
                }
                $output .= '<option value="aiomatic_shortcodes_panel" ';
                if(in_array('aiomatic_shortcodes_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Shortcodes and Forms', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_embeddings_panel" ';
                if(in_array('aiomatic_embeddings_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Embeddings', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_batch_panel" ';
                if(in_array('aiomatic_batch_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Batch Requests', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_openai_training" ';
                if(in_array('aiomatic_openai_training', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Model Training', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_mcp_panel" ';
                if(in_array('aiomatic_mcp_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Site Builder MCP Server', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_playground_panel" ';
                if(in_array('aiomatic_playground_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Playground', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_openai_status" ';
                if(in_array('aiomatic_openai_status', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('System & Logs', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_snippets_panel" ';
                if(in_array('aiomatic_snippets_panel', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('AI Snippets', 'aiomatic-automatic-ai-content-writer') . '</option>
                <option value="aiomatic_more" ';
                if(in_array('aiomatic_more', $user_menus))
                {
                    $output .= 'selected="selected"';
                }
                $output .= '>' . esc_html__('More Features', 'aiomatic-automatic-ai-content-writer') . '</option>';
                $output .= '</select></td>
              <td class="cr_30 cr_center" ><span class="wpaiomatic-delete">X</span></td>
         </tr>	
         ';
              $cont = $cont + 1;
      }
   }
   return $output;
}
function aiomatic_display_arrows($curpage)
{
   if(isset($_GET['pagesort']) && $_GET['pagesort'] == $curpage)
   {
      if (isset($_GET['pageord']) && $_GET['pageord'] == 'asc')
      {
         echo '&nbsp;>';
      }
      else
      {
         echo '&nbsp;<';
      }
   }
   else
   {
      if(!isset($_GET['pagesort']) && $curpage == 'time')
      {
         echo '&nbsp;>';
      }
   }
}
function aiomatic_openai_status()
{
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   if(!AIMOGEN_IS_DEBUG)
   {
      $log_file = WP_CONTENT_DIR . '/aiomatic_info.log';
   }
   else
   {
      $log_file = trailingslashit(get_temp_dir()) . 'aiomatic_info.log';
   }
   global $wp_filesystem;
   if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
      include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
      wp_filesystem($creds);
   }
   if(isset($_POST['aiomatic_delete']) && isset($_POST['aiomatic_nonce']) && wp_verify_nonce( $_POST['aiomatic_nonce'], 'openai-secret-nonce'))
   {
      if($wp_filesystem->exists($log_file))
      {
         $wp_filesystem->delete($log_file);
      }
   }
   if(isset($_POST['aiomatic_delete_rules']) && isset($_POST['aiomatic_nonce']) && wp_verify_nonce( $_POST['aiomatic_nonce'], 'openai-secret-nonce'))
   {
      $running = array();
      aiomatic_update_option('aiomatic_running_list', $running);
      $flock_disabled = explode(',', ini_get('disable_functions'));
      if(!in_array('flock', $flock_disabled))
      {
         foreach (glob(get_temp_dir() . 'aiomatic_*') as $filename) 
         {
            $f = fopen($filename, 'w');
            if($f !== false)
            {
               flock($f, LOCK_UN);
               fclose($f);
            }
            $wp_filesystem->delete($filename);
         }
      }
   }
   if(isset($_POST['aiomatic_restore_defaults']) && isset($_POST['aiomatic_nonce']) && wp_verify_nonce( $_POST['aiomatic_nonce'], 'openai-secret-nonce'))
   {
      aiomatic_activation_callback(true);
   }
   if(isset($_POST['aiomatic_delete_all']) && isset($_POST['aiomatic_nonce']) && wp_verify_nonce( $_POST['aiomatic_nonce'], 'openai-secret-nonce'))
   {
      $delete_date_from = isset($_POST['aiomatic_delete_date_from']) ? sanitize_text_field(wp_unslash($_POST['aiomatic_delete_date_from'])) : '';
      $delete_date_to = isset($_POST['aiomatic_delete_date_to']) ? sanitize_text_field(wp_unslash($_POST['aiomatic_delete_date_to'])) : '';
      aiomatic_delete_all_posts($delete_date_from, $delete_date_to);
   }
   if(isset($_POST['aiomatic_delete_all_rules']) && isset($_POST['aiomatic_nonce']) && wp_verify_nonce( $_POST['aiomatic_nonce'], 'openai-secret-nonce'))
   {
      aiomatic_delete_all_rules();
   }
   
   $aiomatic_Limit_Settings = get_option('aiomatic_Limit_Settings', false);
   if (isset($aiomatic_Limit_Settings['user_credits'])) {
      $user_credits = $aiomatic_Limit_Settings['user_credits'];
  } else {
      $user_credits = '';
  }
  if (isset($aiomatic_Limit_Settings['user_credit_type'])) {
      $user_credit_type = $aiomatic_Limit_Settings['user_credit_type'];
  } else {
      $user_credit_type = '';
  }
  if (isset($aiomatic_Limit_Settings['user_time_frame'])) {
      $user_time_frame = $aiomatic_Limit_Settings['user_time_frame'];
  } else {
      $user_time_frame = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_time_frame'])) {
      $guest_time_frame = $aiomatic_Limit_Settings['guest_time_frame'];
  } else {
      $guest_time_frame = '';
  }
  if (isset($aiomatic_Limit_Settings['is_absolute_user'])) {
      $is_absolute_user = $aiomatic_Limit_Settings['is_absolute_user'];
  } else {
      $is_absolute_user = '';
  }
  if (isset($aiomatic_Limit_Settings['is_absolute_guest'])) {
      $is_absolute_guest = $aiomatic_Limit_Settings['is_absolute_guest'];
  } else {
      $is_absolute_guest = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_credit_type'])) {
      $guest_credit_type = $aiomatic_Limit_Settings['guest_credit_type'];
  } else {
      $guest_credit_type = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_credits'])) {
      $guest_credits = $aiomatic_Limit_Settings['guest_credits'];
  } else {
      $guest_credits = '';
  }
  if (isset($aiomatic_Limit_Settings['limit_message_logged'])) {
      $limit_message_logged = $aiomatic_Limit_Settings['limit_message_logged'];
  } else {
      $limit_message_logged = '';
  }
  if (isset($aiomatic_Limit_Settings['limit_message_not_logged'])) {
      $limit_message_not_logged = $aiomatic_Limit_Settings['limit_message_not_logged'];
  } else {
      $limit_message_not_logged = '';
  }
  if (isset($aiomatic_Limit_Settings['limit_message_rule'])) {
      $limit_message_rule = $aiomatic_Limit_Settings['limit_message_rule'];
  } else {
      $limit_message_rule = '';
  }
  if (isset($aiomatic_Limit_Settings['ignored_users'])) {
      $ignored_users = $aiomatic_Limit_Settings['ignored_users'];
  } else {
      $ignored_users = '';
  }
  if (isset($aiomatic_Limit_Settings['block_userids'])) {
      $block_userids = $aiomatic_Limit_Settings['block_userids'];
  } else {
      $block_userids = '';
  }
  if (isset($aiomatic_Limit_Settings['block_userips'])) {
      $block_userips = $aiomatic_Limit_Settings['block_userips'];
  } else {
      $block_userips = '';
  }
  if (isset($aiomatic_Limit_Settings['enable_limits'])) {
      $enable_limits = $aiomatic_Limit_Settings['enable_limits'];
  } else {
      $enable_limits = '';
  }
  if (isset($aiomatic_Limit_Settings['enable_limits_text'])) {
      $enable_limits_text = $aiomatic_Limit_Settings['enable_limits_text'];
  } else {
      $enable_limits_text = '';
  }
  if (isset($aiomatic_Limit_Settings['user_credits_text'])) {
      $user_credits_text = $aiomatic_Limit_Settings['user_credits_text'];
  } else {
      $user_credits_text = '';
  }
  if (isset($aiomatic_Limit_Settings['user_credit_type_text'])) {
      $user_credit_type_text = $aiomatic_Limit_Settings['user_credit_type_text'];
  } else {
      $user_credit_type_text = '';
  }
  if (isset($aiomatic_Limit_Settings['user_time_frame_text'])) {
      $user_time_frame_text = $aiomatic_Limit_Settings['user_time_frame_text'];
  } else {
      $user_time_frame_text = '';
  }
  if (isset($aiomatic_Limit_Settings['is_absolute_user_text'])) {
      $is_absolute_user_text = $aiomatic_Limit_Settings['is_absolute_user_text'];
  } else {
      $is_absolute_user_text = '';
  }
  if (isset($aiomatic_Limit_Settings['ignored_users_text'])) {
      $ignored_users_text = $aiomatic_Limit_Settings['ignored_users_text'];
  } else {
      $ignored_users_text = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_credits_text'])) {
      $guest_credits_text = $aiomatic_Limit_Settings['guest_credits_text'];
  } else {
      $guest_credits_text = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_credit_type_text'])) {
      $guest_credit_type_text = $aiomatic_Limit_Settings['guest_credit_type_text'];
  } else {
      $guest_credit_type_text = '';
  }
  if (isset($aiomatic_Limit_Settings['guest_time_frame_text'])) {
      $guest_time_frame_text = $aiomatic_Limit_Settings['guest_time_frame_text'];
  } else {
      $guest_time_frame_text = '';
  }
  if (isset($aiomatic_Limit_Settings['is_absolute_guest_text'])) {
      $is_absolute_guest_text = $aiomatic_Limit_Settings['is_absolute_guest_text'];
  } else {
      $is_absolute_guest_text = '';
  }
  if (isset($aiomatic_Limit_Settings['additional_roles'])) {
      $additional_roles = $aiomatic_Limit_Settings['additional_roles'];
  } else {
      $additional_roles = array();
  }
  $max_per_page = 100;
?>
<div class="wp-header-end"></div>
<div class="aiomatic-admin-shell">
<?php aimogen_render_admin_hero(); ?>
<div class="aiomatic-admin-layout">
    <aside class="aiomatic-admin-sidebar">
         <div class="aiomatic-admin-sidebar-inner">
            <div class="aiomatic-sidebar-heading">
               <?php esc_html_e( 'System & Logs', 'aiomatic-automatic-ai-content-writer' ); ?>
            </div>
            <div class="aiomatic-sidebar-nav">
               <nav class="nav-tab-wrapper">
                  <a href="#tab-0" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">▶︎</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Tutorial", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-1" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧝</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Usage Logs", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-5" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧉</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Usage Graphs", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-8" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">∑</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Chatbot Usage", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-2" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧞</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("AI Usage Limits", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-6" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧜</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Text-to-Speech Limits", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-4" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧟</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Plugin Menu Restrictions", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-x" datahref="<?php echo esc_url(admin_url('admin.php?page=aiomatic_admin_settings#tab-5'));?>" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧡</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Limits & Statistics Settings", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-7" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⌘</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Live AI Activity", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-0l" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧖</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Activity Logs", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-1l" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⛮</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Maintenance", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-2l" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">ⓘ</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("System Info", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-3l" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⧣</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Language Pack Manager", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
               </nav>
            </div>
            <div class="aiomatic-sidebar-footer">
               <strong><?php esc_html_e( 'Need a quick start?', 'aiomatic-automatic-ai-content-writer' ); ?></strong>
               <span><?php esc_html_e( '1. Check usage logs for AI models.', 'aimogen' ); ?></span>
               <span><?php esc_html_e( '2. Follow usage graphs to check daily costs.', 'aimogen' ); ?></span>
               <span><?php esc_html_e( '3. Set limits for AI model usage.', 'aimogen' ); ?></span>
               <span><?php esc_html_e( '4. Restrict who sees the menus of the plugin.', 'aimogen' ); ?></span>
               <span>
                  <?php esc_html_e( 'Watch tutorials on', 'aiomatic-automatic-ai-content-writer' ); ?>
                  <a href="https://www.youtube.com/channel/UCVLIksvzyk-D_oEdHab2Lgg" target="_blank" rel="noopener noreferrer">CodeRevolutionTV</a>
               </span>
            </div>
         </div>
      </aside>
<section class="aiomatic-admin-main">
<div class="gs_popuptype_holder seo_pops">
<div>
        <div id="tab-0" class="tab-content">
         <br/>
<?php echo esc_html__("The Aimogen plugin provides a set of features for monitoring the usage of AI services. This tutorial will guide you through the 'Limits and Statistics' feature of the Aimogen plugin.", 'aiomatic-automatic-ai-content-writer');?>

<h2><?php echo esc_html__("Usage Logs", 'aiomatic-automatic-ai-content-writer');?></h2>
<ol><li>
<?php echo esc_html__("Navigate to the 'Limits and Statistics' section of the Aimogen plugin.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Click on the 'Usage Logs' tab. Here, you will see a table with the following columns:", 'aiomatic-automatic-ai-content-writer');?>
<ul>
<li>
<?php echo esc_html__("User: The user who made the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("IP: The IP address from which the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Source: The source of the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Model: The AI model used for the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Mode: The mode in which the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Units: The number of units used for the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Type: The type of units listed.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Price: The cost of the request.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Time: The time when the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("Session ID: The ID of the session in which the request was made.", 'aiomatic-automatic-ai-content-writer');?>
</li><li>
<?php echo esc_html__("You can use this table to monitor the usage of the plugin and track any unusual activity.", 'aiomatic-automatic-ai-content-writer');?>
</li>
</ul>
</li>
</ol>
<h2><?php echo esc_html__("Usage Graphs", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__("Click on the 'Usage Graphs' tab in the 'Limits and Statistics' section. Here, you can view graphs that represent the call count, used token count, usage cost, and generated AI image count. These graphs provide a visual representation of the plugin's usage over time, helping you understand usage trends and patterns.", 'aiomatic-automatic-ai-content-writer');?>
<h2><?php echo esc_html__("Chatbot Usage", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__("Click on the 'Chatbot Usage' tab to see total tokens and words generated for each chatbot over a chosen time period (today, last 7/30 days, this/last month, or a custom range). This helps with ops and billing visibility after deploying multiple chatbots.", 'aiomatic-automatic-ai-content-writer');?>
<h2><?php echo esc_html__("Usage Limits", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__("Click on the 'Usage Limits' tab in the 'Limits and Statistics' section. Here, you can set usage limits for both logged in and not logged in users. You can set limits based on token usage, price usage, or call count usage. You can also create usage limiting rules. For example, you might limit the number of requests a user can make in a given time period. The Aimogen plugin can be integrated with the 'Ultimate Membership Pro' plugin, 'Paid Memberships Pro' plugin or the 'Restrict Content Pro' plugin. This allows you to set different usage amounts for members who have joined different membership plans. You can also limit usage based on user role. For example, you might allow administrators to make more requests than regular users.", 'aiomatic-automatic-ai-content-writer');?>
<h2><?php echo esc_html__("OpenAI Status", 'aiomatic-automatic-ai-content-writer');?></h2>
<?php echo esc_html__("Click on the 'OpenAI Status' tab in the 'Limits and Statistics' section. Here, you can see reported incidents from OpenAI's part and their API service status. This can help you troubleshoot any issues with the AI services provided by the plugin. Remember, the 'Limits and Statistics' feature is a powerful tool for managing and monitoring the usage of the Aimogen plugin. By understanding how to use this feature, you can ensure that your AI services are being used effectively and responsibly.", 'aiomatic-automatic-ai-content-writer');?>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?><h2><?php echo esc_html__("Limits and Statistics Tutorial Video", 'aiomatic-automatic-ai-content-writer');?></h2>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/skwJz6yeqIg" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
       </div>
        <div id="tab-x" class="tab-content">
        <br/>
        <p><?php echo esc_html__("Redirecting...", 'aiomatic-automatic-ai-content-writer');?></p>
        </div>
        <div id="tab-7" class="tab-content">
  <br/>
<?php
   if(!aiomatic_check_plugin_active('aimogen/aimogen.php'))
   {
      echo wp_kses_post(sprintf(
         __(
            'You need to install and activate the <a href="%s">Aimogen free plugin</a> to use this feature.',
            'aiomatic-automatic-ai-content-writer'
         ),
         esc_url( 'https://wordpress.org/plugins/aimogen/' )
      ));
   }
   else
   {
      if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
         echo '<div id="aiomatic_live_feed_toolbar">';
         echo '<strong>Live AI Activity</strong>';
         echo '<span style="opacity:.8;">Status: <span id="aiomatic_live_feed_status">Starting…</span></span>';
         echo '<span style="opacity:.8;">Last ID: <span id="aiomatic_live_feed_last_id">0</span></span>';
         echo '<a href="#" class="button" id="aiomatic_live_feed_pause">Pause</a>';
         echo '<a href="#" class="button" id="aiomatic_live_feed_jump">Jump to bottom</a>';
         echo '<a href="#" class="button" id="aiomatic_live_feed_clear">Clear</a>';
         echo '</div>';
         echo '<div id="aiomatic_live_feed_box"></div>';
      } else {
            echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
      }
   }
?>
</div>
        <div id="tab-1" class="tab-content">
         <br/>
         <?php
         if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
            echo '<div id="aiomatic_statistics_holder">';
            if (isset($_GET['pagenum']) && $_GET['pagenum'] != '' && is_numeric($_GET['pagenum'])) 
            {
               $shiftp = intval($_GET['pagenum']);
            }
            else
            {
               $shiftp = 1;
            }
            $shiftn = ($shiftp - 1) * $max_per_page;
            $sor_arr = array();
            if (isset($_GET['pagesort']))
            {
               if ($_GET['pagesort'] == 'id')
               {
                  $sor_arr["accessor"] = "id";
               }
               elseif ($_GET['pagesort'] == 'user')
               {
                  $sor_arr["accessor"] = "userId";
               }
               elseif ($_GET['pagesort'] == 'assistant_id')
               {
                  $sor_arr["accessor"] = "assistant_id";
               }
               elseif ($_GET['pagesort'] == 'ip')
               {
                  $sor_arr["accessor"] = "ip";
               }
               elseif ($_GET['pagesort'] == 'source')
               {
                  $sor_arr["accessor"] = "env";
               }
               elseif ($_GET['pagesort'] == 'model')
               {
                  $sor_arr["accessor"] = "model";
               }
               elseif ($_GET['pagesort'] == 'mode')
               {
                  $sor_arr["accessor"] = "mode";
               }
               elseif ($_GET['pagesort'] == 'units')
               {
                  $sor_arr["accessor"] = "units";
               }
               elseif ($_GET['pagesort'] == 'type')
               {
                  $sor_arr["accessor"] = "type";
               }
               elseif ($_GET['pagesort'] == 'price')
               {
                  $sor_arr["accessor"] = "price";
               }
               elseif ($_GET['pagesort'] == 'time')
               {
                  $sor_arr["accessor"] = "time";
               }
               elseif ($_GET['pagesort'] == 'session')
               {
                  $sor_arr["accessor"] = "session";
               }
               if (isset($_GET['pageord']) && $_GET['pageord'] == 'asc')
               {
                  $sor_arr["by"] = "asc";
               }
               else
               {
                  $sor_arr["by"] = "desc";
               }
            }
            $statistics_res = $GLOBALS['aiomatic_stats']->logs_query( [], $shiftn, $max_per_page, null, $sor_arr );
            if($statistics_res['total'] == 0)
            {
               echo esc_html__("Empty results.", 'aiomatic-automatic-ai-content-writer');
            }
            else
            {
               echo '<div id="aiomatic-main-stat-holder" class="table-responsive">';
               echo '<button href="#" id="aiomatic_delete_logs" class="page-title-action aiomatic_delete_logs button-primary">' . esc_html__("Delete All Logs", 'aiomatic-automatic-ai-content-writer') . '</button>&nbsp;';
               echo '<a href="https://platform.openai.com/usage" target="_blank" id="aiomatic_check_openai" class="page-title-action aiomatic_delete_logs button-primary">' . esc_html__("Check On OpenAI", 'aiomatic-automatic-ai-content-writer') . '</a><br/>';
               echo '<div class="tablediv"><div class="tablecelldiv"><input type="text" id="user_name_delete" placeholder="' . esc_html__("Username for which to delete logs", 'aiomatic-automatic-ai-content-writer') . '"/></div><button href="#" id="aiomatic_delete_user_logs" class="page-title-action full_w_button button-primary">' . esc_html__("Delete", 'aiomatic-automatic-ai-content-writer') . '</button></div>';
               echo '<div class="aiomatic-paging-controller">';
               if($statistics_res['total'] > $max_per_page)
               {
                  $pages = ceil($statistics_res['total'] / $max_per_page);
                  $nextp = $shiftp + 1;
                  $prevp = $shiftp - 1;
                  if($nextp > $pages)
                  {
                     $nextp = $pages;
                  }
                  if($prevp < 1)
                  {
                     $prevp = 1;
                  }
                  $first_url = aiomatic_add_to_url('pagenum', 1);
                  $next_url = aiomatic_add_to_url('pagenum', $nextp);
                  $prev_url = aiomatic_add_to_url('pagenum', $prevp);
                  $last_url = aiomatic_add_to_url('pagenum', $pages);
                  echo '&nbsp;<span class="aiomatic-results-count">' . esc_html($statistics_res['total']) . '&nbsp;' . esc_html__("results", 'aiomatic-automatic-ai-content-writer') . '</span>&nbsp;&nbsp;';
                  echo '&nbsp;<a href="' . esc_url($first_url) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M18.41 7.41L17 6l-6 6l6 6l1.41-1.41L13.83 12l4.58-4.59m-6 0L11 6l-6 6l6 6l1.41-1.41L7.83 12l4.58-4.59Z"></path></svg></a>';
                  echo '&nbsp;<a href="' . esc_url($prev_url) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M15.41 16.58L10.83 12l4.58-4.59L14 6l-6 6l6 6l1.41-1.42Z"></path></svg></a>';
                  echo '&nbsp;<span class="aiomatic-paging">' . esc_html__("Page", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . esc_html($shiftp) . '&nbsp;' . esc_html__("of", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . esc_html($pages) . '</span>';
                  echo '&nbsp;<a href="' . esc_url($next_url) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M8.59 16.58L13.17 12L8.59 7.41L10 6l6 6l-6 6l-1.41-1.42Z"></path></svg></a>';
                  echo '&nbsp;<a href="' . esc_url($last_url) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M5.59 7.41L7 6l6 6l-6 6l-1.41-1.41L10.17 12L5.59 7.41m6 0L13 6l6 6l-6 6l-1.41-1.41L16.17 12l-4.58-4.59Z"></path></svg></a>';
               }
               else
               {
                  echo '&nbsp;<span class="aiomatic-results-count">' . esc_html($statistics_res['total']) . '&nbsp;' . esc_html__("results", 'aiomatic-automatic-ai-content-writer') . '</span>&nbsp;&nbsp;';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M18.41 7.41L17 6l-6 6l6 6l1.41-1.41L13.83 12l4.58-4.59m-6 0L11 6l-6 6l6 6l1.41-1.41L7.83 12l4.58-4.59Z"></path></svg>';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M15.41 16.58L10.83 12l4.58-4.59L14 6l-6 6l6 6l1.41-1.42Z"></path></svg>';
                  echo '&nbsp;<span class="aiomatic-paging">' . esc_html__("Page", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . '1' . '&nbsp;' . esc_html__("of", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . '1' . '</span>';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M8.59 16.58L13.17 12L8.59 7.41L10 6l6 6l-6 6l-1.41-1.42Z"></path></svg>';
                  echo '&nbsp;<svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M5.59 7.41L7 6l6 6l-6 6l-1.41-1.41L10.17 12L5.59 7.41m6 0L13 6l6 6l-6 6l-1.41-1.41L16.17 12l-4.58-4.59Z"></path></svg>';
               }
               echo '</div>';
               echo '<table id="stat_table" class="widefat responsive table cr_main_table" style="display: block;overflow-x: auto;white-space: nowrap;">';
               $id_sort = aiomatic_add_to_url('pagesort', 'id');
               $user_sort = aiomatic_add_to_url('pagesort', 'user');
               $ip_sort = aiomatic_add_to_url('pagesort', 'ip');
               $source_sort = aiomatic_add_to_url('pagesort', 'source');
               $model_sort = aiomatic_add_to_url('pagesort', 'model');
               $assistant_id_sort = aiomatic_add_to_url('pagesort', 'assistant_id');
               $mode_sort = aiomatic_add_to_url('pagesort', 'mode');
               $units_sort = aiomatic_add_to_url('pagesort', 'units');
               $type_sort = aiomatic_add_to_url('pagesort', 'type');
               $price_sort = aiomatic_add_to_url('pagesort', 'price');
               $time_sort = aiomatic_add_to_url('pagesort', 'time');
               $session_sort = aiomatic_add_to_url('pagesort', 'session');
               if (isset($_GET['pageord']) && $_GET['pageord'] != '')
               {
                  if($_GET['pageord'] == 'asc')
                  {
                     $id_sort = aiomatic_add_to_url('pageord', 'desc', $id_sort);
                     $user_sort = aiomatic_add_to_url('pageord', 'desc', $user_sort);
                     $ip_sort = aiomatic_add_to_url('pageord', 'desc', $ip_sort);
                     $source_sort = aiomatic_add_to_url('pageord', 'desc', $source_sort);
                     $model_sort = aiomatic_add_to_url('pageord', 'desc', $model_sort);
                     $assistant_id_sort = aiomatic_add_to_url('pageord', 'desc', $assistant_id_sort);
                     $mode_sort = aiomatic_add_to_url('pageord', 'desc', $mode_sort);
                     $units_sort = aiomatic_add_to_url('pageord', 'desc', $units_sort);
                     $type_sort = aiomatic_add_to_url('pageord', 'desc', $type_sort);
                     $price_sort = aiomatic_add_to_url('pageord', 'desc', $price_sort);
                     $time_sort = aiomatic_add_to_url('pageord', 'desc', $time_sort);
                     $session_sort = aiomatic_add_to_url('pageord', 'desc', $session_sort);
                  }
                  elseif($_GET['pageord'] == 'desc')
                  {
                     $id_sort = aiomatic_add_to_url('pageord', 'asc', $id_sort);
                     $user_sort = aiomatic_add_to_url('pageord', 'asc', $user_sort);
                     $ip_sort = aiomatic_add_to_url('pageord', 'asc', $ip_sort);
                     $source_sort = aiomatic_add_to_url('pageord', 'asc', $source_sort);
                     $model_sort = aiomatic_add_to_url('pageord', 'asc', $model_sort);
                     $assistant_id_sort = aiomatic_add_to_url('pageord', 'asc', $assistant_id_sort);
                     $mode_sort = aiomatic_add_to_url('pageord', 'asc', $mode_sort);
                     $units_sort = aiomatic_add_to_url('pageord', 'asc', $units_sort);
                     $type_sort = aiomatic_add_to_url('pageord', 'asc', $type_sort);
                     $price_sort = aiomatic_add_to_url('pageord', 'asc', $price_sort);
                     $time_sort = aiomatic_add_to_url('pageord', 'asc', $time_sort);
                     $session_sort = aiomatic_add_to_url('pageord', 'asc', $session_sort);
                  }
               }
               else
               {
                  $id_sort = aiomatic_add_to_url('pageord', 'asc', $id_sort);
                  $user_sort = aiomatic_add_to_url('pageord', 'asc', $user_sort);
                  $ip_sort = aiomatic_add_to_url('pageord', 'asc', $ip_sort);
                  $source_sort = aiomatic_add_to_url('pageord', 'asc', $source_sort);
                  $model_sort = aiomatic_add_to_url('pageord', 'asc', $model_sort);
                  $assistant_id_sort = aiomatic_add_to_url('pageord', 'asc', $assistant_id_sort);
                  $mode_sort = aiomatic_add_to_url('pageord', 'asc', $mode_sort);
                  $units_sort = aiomatic_add_to_url('pageord', 'asc', $units_sort);
                  $type_sort = aiomatic_add_to_url('pageord', 'asc', $type_sort);
                  $price_sort = aiomatic_add_to_url('pageord', 'asc', $price_sort);
                  $time_sort = aiomatic_add_to_url('pageord', 'asc', $time_sort);
                  $session_sort = aiomatic_add_to_url('pageord', 'asc', $session_sort);
               }
               echo '<tr><th><a class="aiomatic_normal" href="' . esc_url($id_sort) . '">' . esc_html__("ID", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('id');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($user_sort) . '">' . esc_html__("User", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('user');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($ip_sort) . '">' . esc_html__("IP", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('ip');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($source_sort) . '">' . esc_html__("Source", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('source');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($model_sort) . '">' . esc_html__("Model", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('model');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($assistant_id_sort) . '">' . esc_html__("Assistant ID", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('assistant_id');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($mode_sort) . '">' . esc_html__("Mode", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('mode');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($units_sort) . '">' . esc_html__("Units", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('units');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($type_sort) . '">' . esc_html__("Type", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('type');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($price_sort) . '">' . esc_html__("Price", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('price');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($time_sort) . '">' . esc_html__("Time", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('time');
               echo '</a></th><th><a class="aiomatic_normal" href="' . esc_url($session_sort) . '">' . esc_html__("Session ID", 'aiomatic-automatic-ai-content-writer');
               aiomatic_display_arrows('session');
               echo '</a></th><th>' . esc_html__('Details', 'aiomatic-automatic-ai-content-writer') . '</th></tr>';
               $myusers = array();
               foreach($statistics_res['rows'] as $stat_row)
               {
                  if(!isset($myusers[$stat_row['userId']]))
                  {
                     $thisuser = get_user_by( 'id', $stat_row['userId'] );
                     if($thisuser !== false)
                     {
                        $myusers[$stat_row['userId']] = $thisuser->user_login;
                     }
                  }
                  echo '<tr>';
                  echo '<td>' . esc_html($stat_row['id']) . '</td>';
                  if(isset($myusers[$stat_row['userId']]))
                  {
                     echo '<td>' . esc_html($myusers[$stat_row['userId']]) . '</td>';
                  }
                  else
                  {
                     echo '<td>ID: ' . esc_html($stat_row['userId']) . '</td>';
                  }
                  echo '<td>' . esc_html($stat_row['ip']) . '</td>';
                  echo '<td>' . esc_html($stat_row['env']) . '</td>';
                  echo '<td>' . esc_html($stat_row['model']) . '</td>';
                  if(isset($stat_row['assistant_id']) && !empty($stat_row['assistant_id']))
                  {
                     echo '<td>' . esc_html($stat_row['assistant_id']) . '</td>';
                  }
                  else
                  {
                     echo '<td>-</td>';
                  }
                  echo '<td>' . esc_html($stat_row['mode']) . '</td>';
                  echo '<td>' . esc_html($stat_row['units']) . '</td>';
                  echo '<td>' . esc_html($stat_row['type']) . '</td>';
                  if(aiomatic_is_aiomaticapi_key($stat_row['apiRef']))
                  {
                     echo '<td>N/A</td>';
                  }
                  else
                  {
                     echo '<td>' . esc_html($stat_row['price']) . '$</td>';
                  }
                  echo '<td>' . esc_html($stat_row['time']) . '</td>';
                  echo '<td>' . esc_html($stat_row['session']) . '</td>';
                  echo '<td class="cr_center">';
echo '<button 
        class="button button-small aiomatic-view-log-details" 
        data-log-id="' . esc_attr($stat_row['id']) . '">'
        . esc_html__('View', 'aiomatic-automatic-ai-content-writer') .
     '</button>';
echo '<button class="button button-small button-link-delete aiomatic-delete-log"
      data-log-id="' . esc_attr($stat_row['id']) . '">'
      . esc_html__('Delete', 'aiomatic-automatic-ai-content-writer') .
   '</button>';
echo '</td>';
                  echo '</tr>';
                  echo '<tr class="aiomatic-log-details-row" id="aiomatic-log-details-' . esc_attr($stat_row['id']) . '" style="display:none">';
echo '<td colspan="13">'; 
echo '<div class="aiomatic-log-details-content">';
echo esc_html__('Loading...', 'aiomatic-automatic-ai-content-writer');
echo '</div>';
echo '</td>';
echo '</tr>';
               }
               echo '</table>';
               echo '</div>';
            }
            echo '</div>';
         }
         else
         {
             echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
         }
         ?>
        </div>
        <form id="myForm" method="post" action="<?php if(is_multisite() && is_network_admin()){echo '../options.php';}else{echo 'options.php';}?>">
<?php
settings_fields('aiomatic_option_group3');
do_settings_sections('aiomatic_option_group3');
?>
        <div id="tab-6" class="tab-content">
        <br/>
        <?php
$roles = aiomatic_get_editable_roles();
         if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
        ?>
   <div class="cr_autocomplete">
      <input type="password" id="PreventChromeAutocomplete2" 
         name="PreventChromeAutocomplete" autocomplete="address-level4" />
   </div>
        <table class="widefat">
        <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to enable text-to-speech usage limits?", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Enable Text-to-Speech Usage Limits:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="enable_limits_text" onclick="limitsTextChanged();" name="aiomatic_Limit_Settings[enable_limits_text]" <?php
                        if ($enable_limits_text == 'on')
                            echo ' checked ';
                        ?>>
                     </td>
                  </tr>
        <tr class="hideTextLimits"><td colspan="2"><h3><?php echo esc_html__("Text-to-Speech Restrictions For Logged In Users:", 'aiomatic-automatic-ai-content-writer');?></h3></td></tr>
         <tr class="hideTextLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the maximum number of credits for logged in users. Also, you can select the type of credits: queries, tokens or price. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Max User Credits:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="number" id="user_credits_text" step="0.01" min="0" placeholder="<?php echo esc_html__("Maximum Credits For Users", 'aiomatic-automatic-ai-content-writer');?>" name="aiomatic_Limit_Settings[user_credits_text]" value="<?php
                     echo esc_html($user_credits_text);
                     ?>"/>
                     <select id="user_credit_type_text" name="aiomatic_Limit_Settings[user_credit_type_text]" >
                     <option value="characters"<?php
                        if ($user_credit_type_text == "characters") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Characters", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="queries"<?php
                           if ($user_credit_type_text == "queries") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideTextLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Time Frame:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <select id="user_time_frame_text" name="aiomatic_Limit_Settings[user_time_frame_text]" >
                     <option value="day"<?php
                        if ($user_time_frame_text == "day") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="week"<?php
                        if ($user_time_frame_text == "week") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="month"<?php
                        if ($user_time_frame_text == "month") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"<?php
                           if ($user_time_frame_text == "year") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideTextLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Absolute Timeframe:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="checkbox" id="is_absolute_user_text" name="aiomatic_Limit_Settings[is_absolute_user_text]"<?php
                  if ($is_absolute_user_text == 'on')
                        echo ' checked ';
                  ?>>
               </div>
            </td>
         </tr>
         <tr class="hideTextLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the users who will have full access when interacting with the features of the plugin.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Full Access Users:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <select id="ignored_users_text" name="aiomatic_Limit_Settings[ignored_users_text]" >
                     <option value="admin"<?php
                        if ($ignored_users_text == "admin") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Admins Only", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="editor"<?php
                        if ($ignored_users_text == "editor") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Editors & Admins", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="none"<?php
                        if ($ignored_users_text == "none") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("None", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideTextLimits"><td colspan="2"><h3><?php echo esc_html__("Text-to-Speech Restrictions For Not Logged In Users:", 'aiomatic-automatic-ai-content-writer');?></h3></td></tr>
         <tr class="hideTextLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the maximum number of credits for guests who are not logged in. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Max Guest Credits:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="number" id="guest_credits_text" step="0.01" min="0" placeholder="<?php echo esc_html__("Maximum Credits For Guests", 'aiomatic-automatic-ai-content-writer');?>" name="aiomatic_Limit_Settings[guest_credits_text]" value="<?php
                     echo esc_html($guest_credits_text);
                     ?>"/>
                     <select id="guest_credit_type_text" name="aiomatic_Limit_Settings[guest_credit_type_text]" >
                     <option value="characters"<?php
                        if ($guest_credit_type_text == "characters") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Characters", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="queries"<?php
                           if ($guest_credit_type_text == "queries") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="pdf"<?php
                              if ($guest_credit_type_text == "pdf") {
                                    echo " selected";
                              }
                              ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Page Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="pdfchar"<?php
                                 if ($guest_credit_type_text == "pdfchar") {
                                       echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Character Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideTextLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Time Frame:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <select id="guest_time_frame_text" name="aiomatic_Limit_Settings[guest_time_frame_text]" >
                     <option value="day"<?php
                        if ($guest_time_frame_text == "day") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="week"<?php
                        if ($guest_time_frame_text == "week") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="month"<?php
                        if ($guest_time_frame_text == "month") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"<?php
                           if ($guest_time_frame_text == "year") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideTextLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Absolute Timeframe:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="checkbox" id="is_absolute_guest_text" name="aiomatic_Limit_Settings[is_absolute_guest_text]"<?php
                  if ($is_absolute_guest_text == 'on')
                        echo ' checked ';
                  ?>>
               </div>
            </td>
         </tr>
         </table>
         <div><p class="crsubmit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p></div>
         <?php
         }
         else
         {
             echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
         }
            ?>
        </div>
        <div id="tab-2" class="tab-content">
        <br/>
        <?php
         if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
         ?>
   <div class="cr_autocomplete">
      <input type="password" id="PreventChromeAutocomplete" 
         name="PreventChromeAutocomplete" autocomplete="address-level4" />
   </div>
        <table class="widefat">
         <tr><td colspan="2">
        <h3><?php echo esc_html__("General Restrictions:", 'aiomatic-automatic-ai-content-writer');?></h3>
         </td></tr>
         <tr>
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Do you want to set a comma separated list of user IDs which are blocked from using the AI?", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Restrict User IDs List From Using The AI:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="text" name="aiomatic_Limit_Settings[block_userids]" id="block_userids" placeholder="User IDs to block" value="<?php echo esc_attr($block_userids);?>" class="cr_width_full"/>
            </td>
         </tr>
         <tr>
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Do you want to set a comma separated list of user IPs which are blocked from using the AI?", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Restrict User IPs List From Using The AI:", 'aiomatic-automatic-ai-content-writer');?></b>
            </td>
            <td>
            <input type="text" name="aiomatic_Limit_Settings[block_userips]" id="block_userips" placeholder="User IPs to block" value="<?php echo esc_attr($block_userips);?>" class="cr_width_full"/>
            </td>
         </tr>
        <tr>
                     <td>
                        <div>
                           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                              <div class="bws_hidden_help_text cr_min_260px">
                                 <?php
                                    echo esc_html__("Do you want to enable global usage limits?", 'aiomatic-automatic-ai-content-writer');
                                    ?>
                              </div>
                           </div>
                           <b><?php echo esc_html__("Enable Global Usage Limits:", 'aiomatic-automatic-ai-content-writer');?></b>
                     </td>
                     <td>
                     <input type="checkbox" id="enable_limits" onclick="limitsChanged();" name="aiomatic_Limit_Settings[enable_limits]" <?php
                        if ($enable_limits == 'on')
                            echo ' checked ';
                        ?>>
                     </td>
                  </tr>
        <tr class="hideLimits"><td colspan="2"><h3><?php echo esc_html__("AI Restrictions For Logged In Users:", 'aiomatic-automatic-ai-content-writer');?></h3></td></tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the maximum number of credits for logged in users. Also, you can select the type of credits: queries, tokens or price. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Max User Credits:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="number" id="user_credits" step="0.01" min="0" placeholder="<?php echo esc_html__("Maximum Credits For Users", 'aiomatic-automatic-ai-content-writer');?>" name="aiomatic_Limit_Settings[user_credits]" value="<?php
                     echo esc_html($user_credits);
                     ?>"/>
                     <select id="user_credit_type_settings" name="aiomatic_Limit_Settings[user_credit_type]" >
                     <option value="queries"<?php
                        if ($user_credit_type == "queries") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
                     $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
                     $appids = array_filter($appids);
                     if(empty($appids))
                     {
                        $token = '';
                     }
                     else
                     {
                        if(empty($appids)){$token = '';}else{$token = $appids[array_rand($appids)];}
                        $token = apply_filters('aimogen_openai_api_key', $token);$token = apply_filters('aiomatic_openai_api_key', $token);
                     } 
                     if(!aiomatic_is_aiomaticapi_key($token))
                     {
?>
                     <option value="units"<?php
                        if ($user_credit_type == "units") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Tokens", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="price"<?php
                        if ($user_credit_type == "price") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Price", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="pdf"<?php
                        if ($user_credit_type == "pdf") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Page Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="pdfchar"<?php
                        if ($user_credit_type == "pdfchar") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Character Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
                        <?php
                     }
                     ?>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Time Frame:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <select id="user_time_frame" name="aiomatic_Limit_Settings[user_time_frame]" >
                     <option value="day"<?php
                        if ($user_time_frame == "day") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="week"<?php
                        if ($user_time_frame == "week") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="month"<?php
                        if ($user_time_frame == "month") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"<?php
                           if ($user_time_frame == "year") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Absolute Timeframe:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="checkbox" id="is_absolute_user" name="aiomatic_Limit_Settings[is_absolute_user]"<?php
                  if ($is_absolute_user == 'on')
                        echo ' checked ';
                  ?>>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the users who will have full access when interacting with the features of the plugin.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Full Access Users:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <select id="ignored_users" name="aiomatic_Limit_Settings[ignored_users]" >
                     <option value="admin"<?php
                        if ($ignored_users == "admin") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Admins Only", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="editor"<?php
                        if ($ignored_users == "editor") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Editors & Admins", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="none"<?php
                        if ($ignored_users == "none") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("None", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Set the message to be displayed to logged in users when usage limit is reached.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Message When Limit Reached (Logged In Users):", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <textarea rows="1" cols="70" name="aiomatic_Limit_Settings[limit_message_logged]" placeholder="<?php echo esc_html__("Usage limit message", 'aiomatic-automatic-ai-content-writer');?>"><?php
               echo esc_textarea($limit_message_logged);
               ?></textarea>
               </div>
            </td>
         </tr>
         <tr class="hideLimits"><td colspan="2"><h3><?php echo esc_html__("AI Restrictions For Not Logged In Users:", 'aiomatic-automatic-ai-content-writer');?></h3></td></tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the maximum number of credits for guests who are not logged in. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Max Guest Credits:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="number" id="guest_credits" step="0.01" min="0" placeholder="<?php echo esc_html__("Maximum Credits For Guests", 'aiomatic-automatic-ai-content-writer');?>" name="aiomatic_Limit_Settings[guest_credits]" value="<?php
                     echo esc_html($guest_credits);
                     ?>"/>
                     <select id="guest_credit_type" name="aiomatic_Limit_Settings[guest_credit_type]" >
                     <option value="queries"<?php
                        if ($guest_credit_type == "queries") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
<?php 
                     if(!aiomatic_is_aiomaticapi_key($token))
                     {
?>
                     <option value="units"<?php
                        if ($guest_credit_type == "units") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Tokens", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="price"<?php
                        if ($guest_credit_type == "price") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Price", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="pdf"<?php
                           if ($guest_credit_type == "pdf") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Page Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="pdfchar"<?php
                              if ($guest_credit_type == "pdfchar") {
                                    echo " selected";
                              }
                              ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Character Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
}
?>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Time Frame:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <select id="guest_time_frame" name="aiomatic_Limit_Settings[guest_time_frame]" >
                     <option value="day"<?php
                        if ($guest_time_frame == "day") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="week"<?php
                        if ($guest_time_frame == "week") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="month"<?php
                        if ($guest_time_frame == "month") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"<?php
                           if ($guest_time_frame == "year") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Absolute Timeframe:", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <input type="checkbox" id="is_absolute_guest" name="aiomatic_Limit_Settings[is_absolute_guest]"<?php
                  if ($is_absolute_guest == 'on')
                        echo ' checked ';
                  ?>>
               </div>
            </td>
         </tr>
         <tr class="hideLimits">
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Set the message to be displayed to not logged in users when usage limit is reached.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Message When Limit Reached (Not Logged In Users):", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <textarea rows="1" cols="70" name="aiomatic_Limit_Settings[limit_message_not_logged]" placeholder="<?php echo esc_html__("Usage limit message", 'aiomatic-automatic-ai-content-writer');?>"><?php
               echo esc_textarea($limit_message_not_logged);
               ?></textarea>
               </div>
            </td>
         </tr>
         <tr>
            <td colspan="2"><hr/></td>
         </tr>
         <tr>
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Set the message to be displayed to logged in users when usage limit is reached for the 'Rule Based Restrictions'.", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("Message When Limit Reached (Rule Based Restrictions - Global):", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
                  <textarea rows="1" cols="70" name="aiomatic_Limit_Settings[limit_message_rule]" placeholder="<?php echo esc_html__("Usage limit message", 'aiomatic-automatic-ai-content-writer');?>"><?php
               echo esc_textarea($limit_message_rule);
               ?></textarea>
               </div>
            </td>
         </tr>
         <tr><td colspan="2"><hr/></td></tr>
         <tr><td colspan="2">
         <h3><?php echo esc_html__("Rule Based Restrictions:", 'aiomatic-automatic-ai-content-writer');?></h3>
         <?php
         wp_nonce_field( 'aiomatic_save_restrictions', '_aiomaticr_nonce_restrictions' );
         ?>
         <table class="responsive table cr_main_table wrapspace">
            <thead>
               <tr>
                  <th class="cr_center">
                     <?php echo esc_html__("ID", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("This is the ID of the rule. ", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("Max User Credits", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the maximum number of credits for logged in users. Also, you can select the type of credits: queries, tokens or price. To disable this feature, leave this field blank.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("Credit Type", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the type of credits.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("Time Frame", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the time frame for which to apply the above limitation.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_30">
                  <?php echo esc_html__("Absolute", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select if you want to apply an absolute timeframe. With absolute, a day represents today. Otherwise, it represent the past 24 hours from now. The same logic applies to the other time frames.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_80">
                     <?php echo esc_html__("Options", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Shows advanced settings for this rule.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_30">
                     <?php echo esc_html__("Del", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Do you want to delete this rule?", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_32" >
                     <?php echo esc_html__("Active", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Do you want to enable this rule? You can deactivate any rule (you don't have to delete them to deactivate them).", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
               </tr>
            </thead>
            <tbody>
               <?php 
echo aiomatic_expand_limitations($roles); ?>
               <tr>
                  <td class="cr_td_xo"><input type="text" name="aiomatic_Limit_Rules[rule_description][]" id="rule_description" class="cr_center" placeholder="Rule ID" value="" class="cr_width_full"/></td>
                  <td class="cr_custx"><input type="number" min="0" step="0.01" placeholder="Max user credits" name="aiomatic_Limit_Rules[user_credits][]" value="" class="cr_width_full" /></td>
                  <td class="cr_custx">
                     <select id="user_credit_type" name="aiomatic_Limit_Rules[user_credit_type][]" >
                     <option value="queries"<?php
                        if ($user_credit_type == "queries") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Queries", 'aiomatic-automatic-ai-content-writer');?></option>
                        <?php 
                     if(!aiomatic_is_aiomaticapi_key($token))
                     {
                     ?>
                     <option value="units"<?php
                        if ($user_credit_type == "units") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Tokens", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="price"<?php
                        if ($user_credit_type == "price") {
                              echo " selected";
                        }
                        ?>><?php echo esc_html__("Price", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="pdf"<?php
                           if ($user_credit_type == "pdf") {
                                 echo " selected";
                           }
                           ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Page Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="pdfchar"<?php
                                 if ($user_credit_type == "pdfchar") {
                                       echo " selected";
                                 }
                                 ?>><?php echo esc_html__("Maximum Chatbot Uploaded PDF Character Count (Per PDF File)", 'aiomatic-automatic-ai-content-writer');?></option>
                        <?php
                     }
                     ?>
                  </select></td>
                  <td class="cr_6cust">
                     <select class="cr_max_width_80" name="aiomatic_Limit_Rules[user_time_frame][]">
                        <option value="day" selected><?php echo esc_html__("Day", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="week"><?php echo esc_html__("Week", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="month"><?php echo esc_html__("Month", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="year"><?php echo esc_html__("Year", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select>
                  </td>
                  <td class="cr_td_q">
                     <select class="cr_max_width_80" name="aiomatic_Limit_Rules[absolute][]">
                        <option value="0" selected><?php echo esc_html__("No", 'aiomatic-automatic-ai-content-writer');?></option>
                        <option value="1"><?php echo esc_html__("Yes", 'aiomatic-automatic-ai-content-writer');?></option>
                     </select></td>
                  <td class="cr_width_70">
                     <center><input type="button" id="mybtnfzr" value="<?php echo esc_html__("Settings", 'aiomatic-automatic-ai-content-writer');?>"></center>
                     <div id="mymodalfzr" class="codemodalfzr">
                        <div class="codemodalfzr-content">
                           <div class="codemodalfzr-header">
                              <span id="aiomatic_close" class="codeclosefzr">&times;</span>
                              <h2><span class="cr_color_white"><?php echo esc_html__("New Rule", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
                           </div>
                           <div class="codemodalfzr-body">
                              <div class="table-responsive">
                                 <table class="responsive table cr_main_table_nowr">
                                    <tr>
                                    <td colspan="2">
                                    <h2><?php echo esc_html__("What to Restrict:", 'aiomatic-automatic-ai-content-writer');?></h2>
                                    </td>
                                    </tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Select the user role to be restricted.", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><?php echo esc_html__("User Role:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td>
                                       <select name="aiomatic_Limit_Rules[role][]" class="cr_width_full">
                                       <option value="none" selected><?php echo esc_html__("Don't check", 'aiomatic-automatic-ai-content-writer');?></option>
                                       <option value="any"><?php echo esc_html__("Apply For Any Role", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
foreach($roles as $urole => $caps)
{
?>
   <option value="<?php echo esc_html($urole);?>"><?php echo esc_html($urole);?></option>
<?php
}
?>
                                       </select>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Integration with 'Ultimate Membership Pro'", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><a href="https://1.envato.market/UltimateMember" target="_blank"><?php echo esc_html__("Ultimate Membership Pro", 'aiomatic-automatic-ai-content-writer');?></a>&nbsp;<?php echo esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td>
                                       <select name="aiomatic_Limit_Rules[ums_sub][]" class="cr_width_full">
                                       <option value="none" selected><?php echo esc_html__("Don't check", 'aiomatic-automatic-ai-content-writer');?></option>
                                       
<?php
$levels = array();
if(class_exists('\Indeed\Ihc\Db\Memberships') && function_exists('ihc_reorder_arr'))
{
   $levels = \Indeed\Ihc\Db\Memberships::getAll();
   $levels = ihc_reorder_arr($levels);
}
if(is_array($levels))
{
   if(count($levels) > 0)
   {
   ?>
   <option value="nosub"><?php echo esc_html__("Not Subscribed Users", 'aiomatic-automatic-ai-content-writer');?></option>
   <option value="any"><?php echo esc_html__("Apply For Any Subscription", 'aiomatic-automatic-ai-content-writer');?></option>
   <?php
   }
   foreach($levels as $levelid => $larr)
   {
   ?>
      <option value="<?php echo esc_attr($levelid);?>"><?php echo esc_html($larr['label']);?></option>
   <?php
   }
}
?>
                                       </select>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Integration with 'Restrict Content Pro'", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><a href="https://restrictcontentpro.com/pricing/" target="_blank"><?php echo esc_html__("Restrict Content Pro", 'aiomatic-automatic-ai-content-writer');?></a>&nbsp;<?php echo esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td>
                                       <select name="aiomatic_Limit_Rules[rest_sub][]" class="cr_width_full">
                                       <option value="none" selected><?php echo esc_html__("Don't check", 'aiomatic-automatic-ai-content-writer');?></option>
                                       
<?php
$levels = array();
if(function_exists('rcp_get_membership_levels'))
{
   $levels = rcp_get_membership_levels();
}
if(is_array($levels))
{
   if(count($levels) > 0)
   {
   ?>
   <option value="nosub"><?php echo esc_html__("Not Subscribed Users", 'aiomatic-automatic-ai-content-writer');?></option>
   <option value="any"><?php echo esc_html__("Apply For Any Subscription", 'aiomatic-automatic-ai-content-writer');?></option>
   <?php
   }
   foreach($levels as $level)
   {
   ?>
      <option value="<?php echo esc_attr($level->id);?>"><?php echo esc_html($level->name);?></option>
   <?php
   }
}
?>
                                       </select>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Integration with 'Paid Memberships Pro'", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><a href="https://www.paidmembershipspro.com/pricing/" target="_blank"><?php echo esc_html__("Paid Memberships Pro", 'aiomatic-automatic-ai-content-writer');?></a>&nbsp;<?php echo esc_html__("Subscription Plan:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td>
                                       <select name="aiomatic_Limit_Rules[paid_sub][]" class="cr_width_full">
                                       <option value="none" selected><?php echo esc_html__("Don't check", 'aiomatic-automatic-ai-content-writer');?></option>
                                       
<?php
$levels = array();
if (function_exists('pmpro_getAllLevels')) 
{
   $levels = pmpro_getAllLevels(false, true);
}
if(is_array($levels))
{
   if(count($levels) > 0)
   {
   ?>
   <option value="nosub"><?php echo esc_html__("Not Subscribed Users", 'aiomatic-automatic-ai-content-writer');?></option>
   <option value="any"><?php echo esc_html__("Apply For Any Subscription", 'aiomatic-automatic-ai-content-writer');?></option>
   <?php
   }
   foreach($levels as $level)
   {
   ?>
      <option value="<?php echo esc_attr($level->id);?>"><?php echo esc_html($level->name);?></option>
   <?php
   }
}
?>
                                       </select>
                                       </td>
                                    </tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Set the user ID list to cover with this restriction. You can enter a comma separated list of user IDs.", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><?php echo esc_html__("User ID List:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td>
                                       <input type="text" placeholder="User ID list" name="aiomatic_Limit_Rules[user_list][]" value="" class="cr_width_full" />
                                       </td>
                                    </tr>
                                    <tr><td colspan="2">
                                    <h2><?php echo esc_html__("More Settings:", 'aiomatic-automatic-ai-content-writer');?></h2>
                                    </td></tr>
                                    <tr>
                                       <td class="cr_min_width_200">
                                             <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                <div class="bws_hidden_help_text cr_min_260px">
                                                   <?php
                                                      echo esc_html__("Set the message to show to restricted users.", 'aiomatic-automatic-ai-content-writer');
                                                      ?>
                                                </div>
                                             </div>
                                             <b><?php echo esc_html__("User Restricted Message:", 'aiomatic-automatic-ai-content-writer');?></b>
                                       </td>
                                       <td><input type="text" placeholder="You are restricted" name="aiomatic_Limit_Rules[message][]" value="" class="cr_width_full" />
                                       </td>
                                    </tr>
                                 </table>
                           <div class="codemodalfzr-footer">
                              <br/>
                              <h3 class="cr_inline">Aimogen Restriction Rules</h3>
                              <span id="aiomatic_ok" class="codeokfzr cr_inline">OK&nbsp;</span>
                              <br/><br/>
                           </div>
                        </div>
                        </div>
                        </div>
                        </div>
                  </td>
                  <td class="cr_30 cr_center" ><span class="cr_30">X</span></td>
                  <td class="cr_short_td">
                  <select name="aiomatic_Limit_Rules[active][]" class="cr_width_full">
                     <option value="1" selected><?php echo esc_html__("Yes", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="0"><?php echo esc_html__("No", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select></td>
               </tr>
            </tbody>
         </table>
</td></tr>
         </table>
         <div><p class="crsubmit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p></div>
         <?php
            echo esc_html__("API usage for this user account: ", 'aiomatic-automatic-ai-content-writer') . do_shortcode('[aimogen-user-remaining-credits-bar]');
         }
         else
         {
             echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
         }
            ?>
        </div>
        <div id="tab-4" class="tab-content">
        <br/>
        <h3><?php echo esc_html__("Plugin Visibility Settings:", 'aiomatic-automatic-ai-content-writer');?></h3>
        <table class="responsive table cr_main_table">
         <tr>
            <td>
               <div>
                  <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                     <div class="bws_hidden_help_text cr_min_260px">
                        <?php
                           echo esc_html__("Select the additional user roles who will have access to the Aimogen plugin, in the admin menu. Note that the administrator user role will always have access to the plugin (this is why it is not shown).", 'aiomatic-automatic-ai-content-writer');
                           ?>
                     </div>
                  </div>
                  <b><?php echo esc_html__("User Roles To See The Plugin In Admin Menu (Besides Administrators):", 'aiomatic-automatic-ai-content-writer');?></b>
               </div>
            </td>
            <td>
               <div>
               <select id="additional_roles" multiple name="aiomatic_Limit_Settings[additional_roles][]" >
               <?php
foreach($roles as $urole => $caps)
{
   if($urole === 'administrator')
   {
      continue;
   }
   echo '<option value="'; echo esc_html($urole); echo '"'; if(in_array($urole, $additional_roles)){ echo ' selected';} echo '>'; echo esc_html($urole); echo '</option>';
}
?>
                  </select>
               </div>
            </td>
         </tr>
         </table>
        <h3><?php echo esc_html__("User Role Based Plugin Menu Restrictions:", 'aiomatic-automatic-ai-content-writer');?></h3>
         <?php
         wp_nonce_field( 'aiomatic_save_menus', '_aiomaticr_nonce' );
         ?>
   <div class="cr_autocomplete">
      <input type="password" id="PreventChromeAutocomplete1" 
         name="PreventChromeAutocomplete" autocomplete="address-level4" />
   </div>
         <table class="aimogen-border responsive table cr_main_table">
            <thead>
               <tr>
                  <th>
                     <?php echo esc_html__("ID", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("This is the ID of the rule. ", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("User Role", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the user role for which to apply the restriction.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th>
                     <?php echo esc_html__("Select Menu Entries To Show", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Select the menu entries to show for this specific user.", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
                  <th class="cr_30">
                     <?php echo esc_html__("Del", 'aiomatic-automatic-ai-content-writer');?>
                     <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                        <div class="bws_hidden_help_text cr_min_260px">
                           <?php
                              echo esc_html__("Do you want to delete this rule?", 'aiomatic-automatic-ai-content-writer');
                              ?>
                        </div>
                     </div>
                  </th>
               </tr>
            </thead>
            <tbody>
               <?php echo aiomatic_expand_menu_limits($roles); ?>
               <tr>
                  <td class="cr_td_xo"><input type="text" name="aiomatic_Menu_Rules[rule_description][]" id="rule_description_menu" class="cr_center" placeholder="Rule ID" value="" class="cr_width_full"/></td>
                  <td class="cr_custx">
                     <select name="aiomatic_Menu_Rules[role][]" class="cr_width_full">
                        <option value="" selected><?php echo esc_html__("Select a role...", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
foreach($roles as $urole => $caps)
{
?>
   <option value="<?php echo esc_html($urole);?>"><?php echo esc_html($urole);?></option>
<?php
}
?>
                                       </select>
                                    </td>
               <td class="cr_custx">
                  <select id="menu_limit" multiple name="aiomatic_Menu_Rules[menu_limit][]" >
                     <option value="aiomatic_admin_settings"><?php echo esc_html__("Settings", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_omniblocks"><?php echo esc_html__("AI OmniBlocks", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_bulk_creators"><?php echo esc_html__("Bulk AI Post Creator", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_spinner_panel"><?php echo esc_html__("AI Content Editor", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_chatbot_panel"><?php echo esc_html__("AI Chatbot", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_agents_panel"><?php echo esc_html__("AI Agents", 'aiomatic-automatic-ai-content-writer');?></option>
                     <?php if(!(defined('AIMOGEN_ASSISTANTS_API_RETIRED') && AIMOGEN_ASSISTANTS_API_RETIRED)){ ?>
                     <option value="aiomatic_assistants_panel"><?php echo esc_html__("AI Assistants", 'aiomatic-automatic-ai-content-writer');?></option>
                     <?php } ?>
                     <option value="aiomatic_shortcodes_panel"><?php echo esc_html__("AI Shortcodes and Forms", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_embeddings_panel"><?php echo esc_html__("AI Embeddings", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_batch_panel"><?php echo esc_html__("AI Batch Requests", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_openai_training"><?php echo esc_html__("AI Model Training", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_playground_panel"><?php echo esc_html__("AI Playground", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_mcp_panel"><?php echo esc_html__("MCP Integration", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_openai_status"><?php echo esc_html__("System & Logs", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_snippets_panel"><?php echo esc_html__("AI Snippets", 'aiomatic-automatic-ai-content-writer');?></option>
                     <option value="aiomatic_more"><?php echo esc_html__("More Features", 'aiomatic-automatic-ai-content-writer');?></option>
                  </select></td>
                  <td class="cr_30 cr_center" ><span class="cr_30">X</span></td>
                     </tr>
                     </tbody>
                  </table>
                  <div><p class="crsubmit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p></div>
        </div>
        </form>
        <div id="tab-5" class="tab-content">
         <br/>
         <?php
         if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
?>
         <div id="aiomatic_chart_holder">
<?php
echo '<span class="pagination-links">';
$current_page = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$older = 0;
if(isset($_GET['older']) && $_GET['older'] != '')
{
   $older = intval($_GET['older']);
   if($older < 0)
   {
      $older = 0;
   }
}
echo '&nbsp;<a href="' . esc_url(add_query_arg( array( 'older' => $older + 12 ), $current_page )) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M18.41 7.41L17 6l-6 6l6 6l1.41-1.41L13.83 12l4.58-4.59m-6 0L11 6l-6 6l6 6l1.41-1.41L7.83 12l4.58-4.59Z"></path></svg></a>';
echo '&nbsp;<a href="' . esc_url(add_query_arg( array( 'older' => $older + 1 ), $current_page )) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M15.41 16.58L10.83 12l4.58-4.59L14 6l-6 6l6 6l1.41-1.42Z"></path></svg></a>';
echo '&nbsp;<span class="aiomatic-paging">' . esc_html__("Page", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . ($older + 1) . '&nbsp;</span>';
if($older > 0)
{
   echo '&nbsp;<a href="' . esc_url(add_query_arg( array( 'older' => $older - 1 ), $current_page )) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M8.59 16.58L13.17 12L8.59 7.41L10 6l6 6l-6 6l-1.41-1.42Z"></path></svg></a>';
   echo '&nbsp;<a href="' . esc_url(add_query_arg( array( 'older' => 0 ), $current_page )) . '"><svg xmlns="http://www.w3.org/2000/svg" focusable="false" class="aiomatic-paging-controller-icon disabled" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" style="transform: rotate(360deg);"><path fill="currentColor" d="M5.59 7.41L7 6l6 6l-6 6l-1.41-1.41L10.17 12L5.59 7.41m6 0L13 6l6 6l-6 6l-1.41-1.41L16.17 12l-4.58-4.59Z"></path></svg></a>';
}
echo '</span>';
   if(isset($_GET['older']) && $_GET['older'] != '' && $_GET['older'] != '0')
   {
      $older = intval($_GET['older']);
      if($older < 0)
      {
         $older = 0;
      }
      $day0time = strtotime(($older * 30) . ' days ago', time());
   }
   else
   {
      $day0time = time();
   }
   $how_many_more_days = 30;
   $results = array();
   $priceresults = array();
   $tokenresults = array();
   $imageresults = array();
   for($j = 0; $j < $how_many_more_days; $j++)
   {
      $total_usd = 0;
      $total_tokens = 0;
      $total_images = 0;
      $strx = "-" . $j . " day";
      if($j > 1)
      {
         $strx .= 's';
      }
      $my_day = date('M d Y', strtotime($strx, $day0time));
      $my_daystart = date('Y-m-d H:i:s', strtotime($my_day . ' 00:00'));
      $my_dayend = date('Y-m-d H:i:s', strtotime($my_day . ' 23:59'));
      $filters['from'] = $my_daystart;
      $filters['to'] = $my_dayend;
      $myday_res = $GLOBALS['aiomatic_stats']->logs_query( [], 0, 100, $filters, null );
      foreach($myday_res['rows'] as $resz)
      {
         $total_usd += $resz['price'];
         if($resz['type'] == 'token' || $resz['type'] == 'tokens')
         {
            $total_tokens += $resz['units'];
         }
         elseif($resz['type'] == 'image' || $resz['type'] == 'images')
         {
            $total_images += $resz['units'];
         }
      }
      $results[$my_day] = $myday_res['total'];
      $priceresults[$my_day] = $total_usd;
      $tokenresults[$my_day] = $total_tokens;
      $imageresults[$my_day] = $total_images;
   }
   $results = array_reverse($results);
   $priceresults = array_reverse($priceresults);
   $tokenresults = array_reverse($tokenresults);
   $imageresults = array_reverse($imageresults);
   $results_html = implode(',' , $results);
   $price_html = implode(',' , $priceresults);
   $token_html = implode(',' , $tokenresults);
   $image_html = implode(',' , $imageresults);
   $days_html = implode(', ',array_keys($results));
   $days_html = str_replace(', ', ',', $days_html);
   $results_html = str_replace(', ', ',', $results_html);
   $our_short = '[aiomatic_charts title="Chart' . uniqid() . '" datalabels="' . esc_html__('API Call Count', 'aiomatic-automatic-ai-content-writer') . ',' . esc_html__('API Call Cost (USD)', 'aiomatic-automatic-ai-content-writer') . ',' . esc_html__('API Token Count', 'aiomatic-automatic-ai-content-writer') . ',' . esc_html__('AI Image Count', 'aiomatic-automatic-ai-content-writer') . '" labels="' . $days_html . '" type="Line" align="aligncenter" margin="5px 20px" datasets="' . $results_html . 'next' . $price_html . 'next' . $token_html . 'next' . $image_html . '" canvasheight="200" width="100%" height="400" relativewidth="1" classn="" colors="#D040D2,#A0A48C,#69D2E1,#40D240" fillopacity="0.7" animation="true" scalefontsize="12" scalefontcolor="#666" scaleoverride="false" scalesteps="null" scalestepwidth="null" scalestartvalue="null"]';
   $returnhtml = do_shortcode($our_short);
   echo $returnhtml;
?>
         </div>
<?php
}
else
{
    echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
}
?>
      </div>

        <div id="tab-8" class="tab-content">
         <br/>
<?php
if (isset($aiomatic_Main_Settings['enable_tracking']) && $aiomatic_Main_Settings['enable_tracking'] === 'on') {
   $cb_period = isset($_GET['cb_period']) ? sanitize_key(wp_unslash($_GET['cb_period'])) : '30d';
   $allowed_periods = array('today', '7d', '30d', 'month', 'last_month', 'custom', 'all');
   if (!in_array($cb_period, $allowed_periods, true)) {
      $cb_period = '30d';
   }
   $cb_from_input = isset($_GET['cb_from']) ? sanitize_text_field(wp_unslash($_GET['cb_from'])) : '';
   $cb_to_input = isset($_GET['cb_to']) ? sanitize_text_field(wp_unslash($_GET['cb_to'])) : '';
   $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
   $now = new DateTimeImmutable('now', $tz);
   $from_dt = null;
   $to_dt = $now->setTime(23, 59, 59);
   switch ($cb_period) {
      case 'today':
         $from_dt = $now->setTime(0, 0, 0);
         break;
      case '7d':
         $from_dt = $now->modify('-6 days')->setTime(0, 0, 0);
         break;
      case 'month':
         $from_dt = $now->modify('first day of this month')->setTime(0, 0, 0);
         break;
      case 'last_month':
         $from_dt = $now->modify('first day of last month')->setTime(0, 0, 0);
         $to_dt = $now->modify('last day of last month')->setTime(23, 59, 59);
         break;
      case 'custom':
         if ($cb_from_input !== '') {
            $tmp = DateTimeImmutable::createFromFormat('Y-m-d', $cb_from_input, $tz);
            if ($tmp instanceof DateTimeImmutable) {
               $from_dt = $tmp->setTime(0, 0, 0);
            }
         }
         if ($cb_to_input !== '') {
            $tmp = DateTimeImmutable::createFromFormat('Y-m-d', $cb_to_input, $tz);
            if ($tmp instanceof DateTimeImmutable) {
               $to_dt = $tmp->setTime(23, 59, 59);
            }
         }
         if ($from_dt === null) {
            $from_dt = $now->modify('-29 days')->setTime(0, 0, 0);
         }
         break;
      case 'all':
         $from_dt = null;
         $to_dt = null;
         break;
      case '30d':
      default:
         $from_dt = $now->modify('-29 days')->setTime(0, 0, 0);
         break;
   }
   $from_sql = ($from_dt instanceof DateTimeImmutable) ? $from_dt->format('Y-m-d H:i:s') : null;
   $to_sql = ($to_dt instanceof DateTimeImmutable) ? $to_dt->format('Y-m-d H:i:s') : null;
   $usage = array('rows' => array(), 'totals' => array('tokens' => 0, 'words' => 0, 'price' => 0, 'requests' => 0, 'chatbots' => 0));
   if (!empty($GLOBALS['aiomatic_stats']) && method_exists($GLOBALS['aiomatic_stats'], 'chatbot_usage_query')) {
      $usage = $GLOBALS['aiomatic_stats']->chatbot_usage_query($from_sql, $to_sql);
   }
   $period_labels = array(
      'today' => esc_html__('Today', 'aiomatic-automatic-ai-content-writer'),
      '7d' => esc_html__('Last 7 days', 'aiomatic-automatic-ai-content-writer'),
      '30d' => esc_html__('Last 30 days', 'aiomatic-automatic-ai-content-writer'),
      'month' => esc_html__('This month', 'aiomatic-automatic-ai-content-writer'),
      'last_month' => esc_html__('Last month', 'aiomatic-automatic-ai-content-writer'),
      'custom' => esc_html__('Custom range', 'aiomatic-automatic-ai-content-writer'),
      'all' => esc_html__('All time', 'aiomatic-automatic-ai-content-writer'),
   );
?>
         <style>
            .aimogen-cb-usage-wrap{margin-top:8px;}
            .aimogen-cb-usage-intro{max-width:860px;color:#50575e;margin:0 0 16px;line-height:1.5;}
            .aimogen-cb-usage-filters{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin:0 0 18px;padding:14px 16px;border:1px solid #e2e4e7;border-radius:10px;background:#fff;}
            .aimogen-cb-usage-filters label{display:block;font-size:12px;font-weight:600;margin:0 0 4px;color:#1d2327;}
            .aimogen-cb-usage-filters select,.aimogen-cb-usage-filters input[type="date"]{min-width:160px;}
            .aimogen-cb-usage-summary{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 18px;}
            .aimogen-cb-usage-card{flex:1 1 140px;min-width:140px;padding:14px 16px;border:1px solid #e2e4e7;border-radius:10px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.04);}
            .aimogen-cb-usage-card .lbl{display:block;font-size:12px;color:#646970;margin-bottom:6px;}
            .aimogen-cb-usage-card .val{display:block;font-size:22px;font-weight:700;color:#1d2327;line-height:1.2;}
            .aimogen-cb-usage-table-wrap{border:1px solid #e2e4e7;border-radius:10px;background:#fff;overflow:auto;}
            .aimogen-cb-usage-table{margin:0;border:0;width:100%;}
            .aimogen-cb-usage-table th,.aimogen-cb-usage-table td{padding:10px 12px;vertical-align:middle;}
            .aimogen-cb-usage-id{font-family:Consolas,Monaco,monospace;font-size:12px;color:#646970;}
            .aimogen-cb-usage-empty{padding:28px 18px;color:#646970;}
            .aimogen-cb-usage-note{margin-top:12px;color:#646970;font-size:13px;}
         </style>
         <div class="aimogen-cb-usage-wrap">
            <p class="aimogen-cb-usage-intro"><?php echo esc_html__('Totals below are attributed per chatbot configuration (shortcode fingerprint). New conversations are tracked automatically when usage tracking is enabled. Historical logs created before this feature will not appear here.', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" class="aimogen-cb-usage-filters">
               <input type="hidden" name="page" value="aiomatic_openai_status" />
               <div>
                  <label for="cb_period"><?php echo esc_html__('Time period', 'aiomatic-automatic-ai-content-writer'); ?></label>
                  <select name="cb_period" id="cb_period" onchange="var c=document.getElementById('aimogen-cb-custom-dates'); if(c){c.style.display=(this.value==='custom')?'flex':'none';}">
                     <?php foreach ($period_labels as $key => $lab) : ?>
                        <option value="<?php echo esc_attr($key); ?>" <?php selected($cb_period, $key); ?>><?php echo esc_html($lab); ?></option>
                     <?php endforeach; ?>
                  </select>
               </div>
               <div id="aimogen-cb-custom-dates" style="display:<?php echo ($cb_period === 'custom') ? 'flex' : 'none'; ?>;gap:10px;flex-wrap:wrap;">
                  <div>
                     <label for="cb_from"><?php echo esc_html__('From', 'aiomatic-automatic-ai-content-writer'); ?></label>
                     <input type="date" name="cb_from" id="cb_from" value="<?php echo esc_attr($cb_from_input !== '' ? $cb_from_input : (($from_dt instanceof DateTimeImmutable) ? $from_dt->format('Y-m-d') : '')); ?>" />
                  </div>
                  <div>
                     <label for="cb_to"><?php echo esc_html__('To', 'aiomatic-automatic-ai-content-writer'); ?></label>
                     <input type="date" name="cb_to" id="cb_to" value="<?php echo esc_attr($cb_to_input !== '' ? $cb_to_input : (($to_dt instanceof DateTimeImmutable) ? $to_dt->format('Y-m-d') : '')); ?>" />
                  </div>
               </div>
               <div>
                  <button type="submit" class="button button-primary"><?php echo esc_html__('Apply', 'aiomatic-automatic-ai-content-writer'); ?></button>
               </div>
            </form>
            <script>
               (function(){
                  // Keep hash so the Chatbot Usage tab stays open after filtering.
                  var form = document.querySelector('.aimogen-cb-usage-filters');
                  if (!form) return;
                  form.addEventListener('submit', function(){
                     if (window.location.hash !== '#tab-8') {
                        // Navigate with hash after submit via hidden field is unreliable; set after load instead.
                     }
                  });
                  if (window.location.search.indexOf('cb_period=') !== -1) {
                     window.location.hash = 'tab-8';
                  }
               })();
            </script>
            <div class="aimogen-cb-usage-summary">
               <div class="aimogen-cb-usage-card"><span class="lbl"><?php echo esc_html__('Chatbots', 'aiomatic-automatic-ai-content-writer'); ?></span><span class="val"><?php echo esc_html(number_format_i18n((int) $usage['totals']['chatbots'])); ?></span></div>
               <div class="aimogen-cb-usage-card"><span class="lbl"><?php echo esc_html__('Requests', 'aiomatic-automatic-ai-content-writer'); ?></span><span class="val"><?php echo esc_html(number_format_i18n((int) $usage['totals']['requests'])); ?></span></div>
               <div class="aimogen-cb-usage-card"><span class="lbl"><?php echo esc_html__('Tokens', 'aiomatic-automatic-ai-content-writer'); ?></span><span class="val"><?php echo esc_html(number_format_i18n((int) $usage['totals']['tokens'])); ?></span></div>
               <div class="aimogen-cb-usage-card"><span class="lbl"><?php echo esc_html__('Words generated', 'aiomatic-automatic-ai-content-writer'); ?></span><span class="val"><?php echo esc_html(number_format_i18n((int) $usage['totals']['words'])); ?></span></div>
               <div class="aimogen-cb-usage-card"><span class="lbl"><?php echo esc_html__('Estimated cost (USD)', 'aiomatic-automatic-ai-content-writer'); ?></span><span class="val"><?php echo esc_html(number_format_i18n((float) $usage['totals']['price'], 4)); ?></span></div>
            </div>
<?php if (empty($usage['rows'])) : ?>
            <div class="aimogen-cb-usage-table-wrap"><div class="aimogen-cb-usage-empty"><?php echo esc_html__('No per-chatbot usage found for this period yet. Send a few chatbot messages after enabling tracking, then refresh this page.', 'aiomatic-automatic-ai-content-writer'); ?></div></div>
<?php else : ?>
            <div class="aimogen-cb-usage-table-wrap">
               <table class="widefat striped aimogen-cb-usage-table">
                  <thead>
                     <tr>
                        <th><?php echo esc_html__('Chatbot', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <th><?php echo esc_html__('Requests', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <th><?php echo esc_html__('Tokens', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <th><?php echo esc_html__('Words', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <th><?php echo esc_html__('Avg tokens / request', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <th><?php echo esc_html__('Cost (USD)', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <th><?php echo esc_html__('ID', 'aiomatic-automatic-ai-content-writer'); ?></th>
                     </tr>
                  </thead>
                  <tbody>
                  <?php foreach ($usage['rows'] as $row) :
                     $avg = ($row['requests'] > 0) ? ($row['tokens'] / $row['requests']) : 0;
                  ?>
                     <tr>
                        <td><strong><?php echo esc_html($row['label']); ?></strong></td>
                        <td><?php echo esc_html(number_format_i18n((int) $row['requests'])); ?></td>
                        <td><?php echo esc_html(number_format_i18n((int) $row['tokens'])); ?></td>
                        <td><?php echo esc_html(number_format_i18n((int) $row['words'])); ?></td>
                        <td><?php echo esc_html(number_format_i18n($avg, 1)); ?></td>
                        <td><?php echo esc_html(number_format_i18n((float) $row['price'], 4)); ?></td>
                        <td><span class="aimogen-cb-usage-id" title="<?php echo esc_attr($row['chatbot_id']); ?>"><?php echo esc_html(substr($row['chatbot_id'], 0, 12)); ?><?php echo (strlen($row['chatbot_id']) > 12) ? '…' : ''; ?></span></td>
                     </tr>
                  <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
<?php endif; ?>
            <p class="aimogen-cb-usage-note"><?php
               if ($from_sql && $to_sql) {
                  echo esc_html(sprintf(
                     /* translators: 1: from datetime, 2: to datetime */
                     __('Showing usage from %1$s to %2$s (site timezone).', 'aiomatic-automatic-ai-content-writer'),
                     $from_sql,
                     $to_sql
                  ));
               } elseif ($from_sql) {
                  echo esc_html(sprintf(
                     /* translators: %s: from datetime */
                     __('Showing usage since %s (site timezone).', 'aiomatic-automatic-ai-content-writer'),
                     $from_sql
                  ));
               } else {
                  echo esc_html__('Showing all recorded per-chatbot usage.', 'aiomatic-automatic-ai-content-writer');
               }
            ?></p>
         </div>
<?php
} else {
    echo esc_html__("You need to enable the 'Enable Usage Tracking For Statistics And Usage Limits' checkbox from the plugin's 'Settings' menu to enable this feature.", 'aiomatic-automatic-ai-content-writer');
}
?>
      </div>
      
<div id="tab-2l" class="tab-content">
      <?php $aimogen_diag_report = aimogen_build_diagnostics_report(); ?>
      <style>
         .aimogen-diag-box{border:1px solid #e2e4e7;border-radius:10px;background:#fff;padding:18px 20px;margin:16px 0 8px;box-shadow:0 1px 2px rgba(0,0,0,.04);}
         .aimogen-diag-head{display:flex;align-items:flex-start;gap:10px;}
         .aimogen-diag-head .dashicons{color:#2563eb;font-size:20px;width:20px;height:20px;margin-top:2px;flex:0 0 auto;}
         .aimogen-diag-text strong{display:block;font-size:15px;font-weight:600;color:#1d2327;line-height:1.3;}
         .aimogen-diag-desc{margin:5px 0 0;color:#646970;font-size:13px;line-height:1.5;max-width:760px;}
         .aimogen-diag-actions{display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin-top:16px;}
         .aimogen-diag-box .aimogen-diag-btn{display:inline-flex;align-items:center;justify-content:center;height:36px;min-height:36px;padding:0 16px;margin:0;border-radius:6px;border:1px solid transparent;background:none;box-sizing:border-box;font-size:13px;font-weight:600;line-height:1;text-decoration:none;box-shadow:none;cursor:pointer;transition:background .15s ease,border-color .15s ease,color .15s ease;}
         .aimogen-diag-box .aimogen-diag-btn:focus{outline:2px solid rgba(37,99,235,.35);outline-offset:1px;}
         .aimogen-diag-box .aimogen-diag-btn--primary{background:#2563eb;border-color:#2563eb;color:#fff;}
         .aimogen-diag-box .aimogen-diag-btn--primary:hover{background:#1d4ed8;border-color:#1d4ed8;color:#fff;}
         .aimogen-diag-box .aimogen-diag-btn--secondary{background:#fff;border-color:#cbd5e1;color:#1e293b;}
         .aimogen-diag-box .aimogen-diag-btn--secondary:hover{background:#f1f5f9;border-color:#94a3b8;color:#1e293b;}
         .aimogen-diag-box .aimogen-diag-btn--ghost{background:none;border-color:transparent;color:#2563eb;padding:0 10px;}
         .aimogen-diag-box .aimogen-diag-btn--ghost:hover{background:#eff6ff;color:#1d4ed8;}
         .aimogen-diag-box .aimogen-diag-btn[disabled]{opacity:.6;cursor:default;}
         .aimogen-diag-status{font-size:13px;font-weight:600;line-height:1.4;margin-left:2px;}
         .aimogen-diag-status.is-ok{color:#0a7d4d;}
         .aimogen-diag-status.is-error{color:#b32d2e;}
         .aimogen-diag-report{display:none;width:100%;margin-top:14px;padding:12px 14px;box-sizing:border-box;font-family:Consolas,Monaco,monospace;font-size:12px;line-height:1.55;white-space:pre;overflow:auto;background:#f6f7f7;border:1px solid #e2e4e7;border-radius:8px;color:#1d2327;}
      </style>
      <div class="aimogen-diag-box">
         <div class="aimogen-diag-head">
            <span class="dashicons dashicons-sos" aria-hidden="true"></span>
            <div class="aimogen-diag-text">
               <strong><?php echo esc_html__('Support diagnostics', 'aiomatic-automatic-ai-content-writer'); ?></strong>
               <p class="aimogen-diag-desc"><?php echo esc_html__('One click copies a clean, shareable summary of your environment (PHP, WordPress, configured providers, REST status and more) so support can help you faster. No API keys or secrets are ever included.', 'aiomatic-automatic-ai-content-writer'); ?></p>
            </div>
         </div>
         <div class="aimogen-diag-actions">
            <button type="button" class="aimogen-diag-btn aimogen-diag-btn--primary aimogen-diag-copy"><?php echo esc_html__('Copy diagnostics', 'aiomatic-automatic-ai-content-writer'); ?></button>
            <button type="button" class="aimogen-diag-btn aimogen-diag-btn--secondary aimogen-diag-download"><?php echo esc_html__('Download .txt', 'aiomatic-automatic-ai-content-writer'); ?></button>
            <button type="button" class="aimogen-diag-btn aimogen-diag-btn--ghost aimogen-diag-toggle"><?php echo esc_html__('View', 'aiomatic-automatic-ai-content-writer'); ?></button>
            <span class="aimogen-diag-status" role="status" aria-live="polite"></span>
         </div>
         <textarea id="aimogen-diag-report" class="aimogen-diag-report" readonly rows="18" wrap="off"><?php echo esc_textarea($aimogen_diag_report); ?></textarea>
      </div>
      <script>
      (function(){
         var i18n = {
            copied: <?php echo wp_json_encode(__('Copied to clipboard.', 'aiomatic-automatic-ai-content-writer')); ?>,
            manual: <?php echo wp_json_encode(__('Select the text and press Ctrl/Cmd+C to copy.', 'aiomatic-automatic-ai-content-writer')); ?>,
            downloaded: <?php echo wp_json_encode(__('Diagnostics downloaded.', 'aiomatic-automatic-ai-content-writer')); ?>,
            view: <?php echo wp_json_encode(__('View', 'aiomatic-automatic-ai-content-writer')); ?>,
            hide: <?php echo wp_json_encode(__('Hide', 'aiomatic-automatic-ai-content-writer')); ?>
         };
         var ta = document.getElementById('aimogen-diag-report');
         if (!ta) { return; }
         var copyBtn = document.querySelector('.aimogen-diag-copy');
         var dlBtn = document.querySelector('.aimogen-diag-download');
         var toggleBtn = document.querySelector('.aimogen-diag-toggle');
         var statusEl = document.querySelector('.aimogen-diag-status');
         var statusTimer = null;
         function flash(msg, ok){
            if (!statusEl) { return; }
            statusEl.textContent = msg;
            statusEl.className = 'aimogen-diag-status ' + (ok === false ? 'is-error' : 'is-ok');
            if (statusTimer) { clearTimeout(statusTimer); }
            statusTimer = setTimeout(function(){ statusEl.textContent = ''; statusEl.className = 'aimogen-diag-status'; }, 5000);
         }
         function legacyCopy(){
            var hidden = window.getComputedStyle(ta).display === 'none';
            if (hidden) { ta.style.display = 'block'; }
            ta.removeAttribute('readonly');
            ta.focus();
            ta.select();
            var ok = false;
            try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
            ta.setAttribute('readonly', 'readonly');
            if (hidden) { ta.style.display = 'none'; }
            flash(ok ? i18n.copied : i18n.manual, ok);
         }
         if (copyBtn) {
            copyBtn.addEventListener('click', function(){
               if (navigator.clipboard && navigator.clipboard.writeText) {
                  navigator.clipboard.writeText(ta.value).then(function(){ flash(i18n.copied, true); }, function(){ legacyCopy(); });
               } else {
                  legacyCopy();
               }
            });
         }
         if (dlBtn) {
            dlBtn.addEventListener('click', function(){
               try {
                  var blob = new Blob([ta.value], { type: 'text/plain' });
                  var url = URL.createObjectURL(blob);
                  var a = document.createElement('a');
                  a.href = url;
                  a.download = 'aimogen-diagnostics.txt';
                  document.body.appendChild(a);
                  a.click();
                  setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
                  flash(i18n.downloaded, true);
               } catch (e) {
                  legacyCopy();
               }
            });
         }
         if (toggleBtn) {
            toggleBtn.addEventListener('click', function(){
               var visible = window.getComputedStyle(ta).display !== 'none';
               ta.style.display = visible ? 'none' : 'block';
               toggleBtn.textContent = visible ? i18n.view : i18n.hide;
            });
         }
      })();
      </script>
      <h3>
         <?php echo esc_html__("General System Info:", 'aiomatic-automatic-ai-content-writer');?> 
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
            <div class="bws_hidden_help_text cr_min_260px">
               <?php
                  echo esc_html__("Some general system information.", 'aiomatic-automatic-ai-content-writer');
                  ?>
            </div>
         </div>
      </h3>
      <hr/>
      <table class="cr_server_stat">
         <tr class="cdr-dw-tr">
            <td class="cdr-dw-td"><?php echo esc_html__("Your User Agent:", 'aiomatic-automatic-ai-content-writer');?></td>
            <td class="cdr-dw-td-value"><?php echo esc_html(sanitize_text_field($_SERVER['HTTP_USER_AGENT'])); ?></td>
         </tr>
         <tr class="cdr-dw-tr">
            <td class="cdr-dw-td"><?php echo esc_html__("PHP Memory Limit:", 'aiomatic-automatic-ai-content-writer');?></td>
            <td class="cdr-dw-td-value"><?php echo esc_html(ini_get('memory_limit')); ?></td>
         </tr>
         <tr class="cdr-dw-tr">
            <td class="cdr-dw-td"><?php echo esc_html__("PHP DateTime Class:", 'aiomatic-automatic-ai-content-writer');?></td>
            <td class="cdr-dw-td-value"><?php echo (class_exists('DateTime') && class_exists('DateTimeZone')) ? '<span class="cdr-green">' . esc_html__('Available', 'aiomatic-automatic-ai-content-writer') . '</span>' : '<span class="cdr-red">' . esc_html__('Not available', 'aiomatic-automatic-ai-content-writer') . '</span> | <a href="http://php.net/manual/en/datetime.installation.php" target="_blank">more info&raquo;</a>'; ?> </td>
         </tr>
         <tr class="cdr-dw-tr">
            <td class="cdr-dw-td"><?php echo esc_html__("PHP Curl:", 'aiomatic-automatic-ai-content-writer');?></td>
            <td class="cdr-dw-td-value"><?php echo (function_exists('curl_version')) ? '<span class="cdr-green">' . esc_html__('Available', 'aiomatic-automatic-ai-content-writer') . '</span>' : '<span class="cdr-red">' . esc_html__('Not available', 'aiomatic-automatic-ai-content-writer') . '</span>'; ?> </td>
         </tr>
         <?php do_action('coderevolution_dashboard_widget_server') ?>
      </table>
      <hr/>
      <h3>
         <?php echo esc_html__("Detailed System Info:", 'aiomatic-automatic-ai-content-writer');?> 
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
            <div class="bws_hidden_help_text cr_min_260px">
               <?php
                  echo esc_html__("More advanced and detailed system information.", 'aiomatic-automatic-ai-content-writer');
                  ?>
            </div>
         </div>
      </h3>
<h4 class="screen-reader-text"><?php esc_html_e( 'WordPress Environment', 'aiomatic-automatic-ai-content-writer' ); ?></h4>
<table class="widefat" cellspacing="0">
    <thead>
    <tr>
        <th colspan="3" data-export-label="<?php echo esc_attr__( 'WordPress Environment', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'WordPress Environment', 'aiomatic-automatic-ai-content-writer' ); ?></th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td data-export-label="<?php echo esc_attr__( 'Home URL', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'Home URL:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help">
			<?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The URL of your site\'s homepage.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?>
		</td>
        <td><?php echo esc_url_raw( home_url('/') ); ?></td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__( 'Site URL', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'Site URL:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The root URL of your site.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
        <td><?php echo esc_url_raw( site_url() ); ?></td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__( 'WP Version', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'WP Version:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help">
			<?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The version of WordPress installed on your site.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
        <td><?php echo esc_html( bloginfo( 'version' ) ); ?></td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__( 'WP Multisite', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'WP Multisite:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help">
			<?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Whether or not you have WordPress Multisite enabled.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?>
		</td>
        <td><?php echo ( is_multisite() ) ? '&#10004;' : '&ndash;'; ?></td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__('WP Memory Limit', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'WP Memory Limit:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help">
			<?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The maximum amount of memory (RAM) that your site can use at one time.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?>
		</td>
        <td>
			<?php
				$memory = aiomatic_let_to_num( WP_MEMORY_LIMIT );
				if ( $memory < 64000000 ) {
					echo '<mark class="error">' . sprintf( wp_kses_post( __( '%1$s - We recommend setting memory to at least <strong>64MB</strong>. To learn how, see: <a href="%2$s" target="_blank" rel="noopener noreferrer">Increasing memory allocated to PHP.</a>', 'aiomatic-automatic-ai-content-writer' ) ), esc_html(size_format( $memory )), 'https://coderevolution.ro/knowledge-base/faq/my-allocated-wordpress-memory-is-too-low-how-do-i-increase-it/' ) . '</mark>';
				} else {
					echo '<mark class="yes">' . esc_html( size_format( $memory ) ) . '</mark>';
				}
			?>
        </td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__('WP Debug Mode','aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'WP Debug Mode:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help">
			<?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Displays whether or not WordPress is in Debug Mode.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?>
		</td>
        <td>
			<?php if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) : ?>
                <mark class="yes">&#10004;</mark>
			<?php else : ?>
                <mark class="no">&ndash;</mark>
			<?php endif; ?>
        </td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__('Language', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'Language:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help">
			<?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The current language used by WordPress. Default = English', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?>
		</td>
        <td><?php echo esc_html(get_locale()); ?></td>
    </tr>
    </tbody>
</table>

<h3 class="screen-reader-text"><?php esc_html_e( 'Server Environment', 'aiomatic-automatic-ai-content-writer' ); ?></h3>
<table class="widefat" cellspacing="0">
    <thead>
    <tr>
        <th colspan="3" data-export-label="<?php echo esc_attr__('Server Environment', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'Server Environment', 'aiomatic-automatic-ai-content-writer' ); ?></th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td data-export-label="<?php echo esc_attr__('PHP Version', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'PHP Version:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The version of PHP installed on your hosting server.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
        <td><?php if ( function_exists( 'phpversion' ) ) {
				echo esc_html( phpversion() );
		} ?></td>
    </tr>

	<?php if ( function_exists( 'ini_get' ) ) : ?>
        <tr>
            <td data-export-label="<?php echo esc_attr__('PHP Post Max Size', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'PHP Post Max Size:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
            <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The largest file size that can be contained in one post.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
            <td><?php echo esc_html(size_format( aiomatic_let_to_num( ini_get( 'post_max_size' ) ) )); ?></td>
        </tr>
        <tr>
            <td data-export-label="<?php echo esc_attr__('PHP Time Limit', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'PHP Time Limit:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
            <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The amount of time (in seconds) that your site will spend on a single operation before timing out (to avoid server lockups)', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
            <td>
				<?php
					$time_limit = ini_get( 'max_execution_time' );
					if ( 600 > $time_limit && 0 != $time_limit ) {
						echo '<mark class="error">' . sprintf( wp_kses_post( __( '%1$s - We recommend setting max execution time to at least 600. <br /> To generate long articles, <strong>1000</strong> seconds of max execution time is recommended.<br />See: <a href="%2$s" target="_blank" rel="noopener noreferrer">Increasing max execution to PHP</a>', 'aiomatic-automatic-ai-content-writer' ) ), esc_html($time_limit), 'https://coderevolution.ro/knowledge-base/faq/how-to-increase-the-max_execution_time-settings-on-your-server/' ) . '</mark>';
					} else {
						echo '<mark class="yes">' . esc_html( $time_limit ) . '</mark>';
						if ( 1000 > $time_limit && 0 != $time_limit ) {
							echo '<br /><mark class="error">' . sprintf( wp_kses_post( __( '%1$s - We recommend setting max execution time to at least 600. <br /> To generate long articles, <strong>1000</strong> seconds of max execution time is recommended.<br />See: <a href="%2$s" target="_blank" rel="noopener noreferrer">Increasing max execution to PHP</a>', 'aiomatic-automatic-ai-content-writer' ) ), esc_html($time_limit), 'https://coderevolution.ro/knowledge-base/faq/how-to-increase-the-max_execution_time-settings-on-your-server/' ) . '</mark>';
						}
					}
				?>
            </td>
        </tr>
        <tr>
            <td data-export-label="<?php echo esc_attr__('PHP Max Input Vars', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'PHP Max Input Vars (optional):', 'aiomatic-automatic-ai-content-writer' ); ?></td>
            <td class="help">
				<?php echo 	'<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The maximum number of variables your server can use for a single function to avoid overloads. This is an optional settings, as the plugin can handle also cases when this is lower than the required value.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?>
			</td>
			<?php
				$registered_navs  = get_nav_menu_locations();
				$menu_items_count = array( '0' => '0' );
				foreach ( $registered_navs as $handle => $registered_nav ) {
					$menu = wp_get_nav_menu_object( $registered_nav );
					if ( $menu ) {
						$menu_items_count[] = $menu->count;
					}
				}
				$max_items = max( $menu_items_count );
				$required_input_vars = $max_items * 12;
			?>
            <td>
				<?php
					$max_input_vars      = ini_get( 'max_input_vars' );
					$required_input_vars = $required_input_vars + ( 500 + 1000 );
					if ( $max_input_vars < $required_input_vars ) {
						echo '<mark class="error">' . sprintf( wp_kses_post( __( '%1$s - Recommended Value: %2$s.<br />Max input vars limitation will truncate POST data such as menus. See: <a href="%3$s" target="_blank" rel="noopener noreferrer">Increasing max input vars limit.</a>', 'aiomatic-automatic-ai-content-writer' ) ), esc_html($max_input_vars), '<strong>' . esc_html($required_input_vars) . '</strong>', 'http://sevenspark.com/docs/ubermenu-3/faqs/menu-item-limit' ) . '</mark>';
					} else {
						echo '<mark class="yes">' . esc_html( $max_input_vars ) . '</mark>';
					}
				?>
            </td>
        </tr>
        <tr>
            <td data-export-label="<?php echo esc_attr__('SUHOSIN Installed', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'SUHOSIN Installed:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
            <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Suhosin is an advanced protection system for PHP installations. It was designed to protect your servers on the one hand against a number of well known problems in PHP applications and on the other hand against potential unknown vulnerabilities within these applications or the PHP core itself.
		If enabled on your server, Suhosin may need to be configured to increase its data submission limits.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>';?></td>
            <td><?php echo extension_loaded( 'suhosin' ) ? '&#10004;' : '&ndash;'; ?></td>
        </tr>
		<?php if ( extension_loaded( 'suhosin' ) ) : ?>
            <tr>
                <td data-export-label="<?php echo esc_attr__('Suhosin Post Max Vars', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'Suhosin Post Max Vars:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
                <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The maximum number of variables your server can use for a single function to avoid overloads.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
				<?php
					$registered_navs  = get_nav_menu_locations();
					$menu_items_count = array( '0' => '0' );
					foreach ( $registered_navs as $handle => $registered_nav ) {
						$menu = wp_get_nav_menu_object( $registered_nav );
						if ( $menu ) {
							$menu_items_count[] = $menu->count;
						}
					}
					$max_items = max( $menu_items_count );
					
					$required_input_vars = $max_items * 12;
				?>
                <td>
					<?php
						$max_input_vars      = ini_get( 'suhosin.post.max_vars' );
						$required_input_vars = $required_input_vars + ( 500 + 1000 );
						if ( $max_input_vars < $required_input_vars ) {
							echo '<mark class="error">' . sprintf( wp_kses_post( __( '%1$s - Recommended Value: %2$s.<br />Max input vars limitation will truncate POST data such as menus. See: <a href="%3$s" target="_blank" rel="noopener noreferrer">Increasing max input vars limit.</a>', 'aiomatic-automatic-ai-content-writer' ) ), esc_html($max_input_vars), '<strong>' . esc_html($required_input_vars) . '</strong>', 'http://sevenspark.com/docs/ubermenu-3/faqs/menu-item-limit' ) . '</mark>';
						} else {
							echo '<mark class="yes">' . esc_html( $max_input_vars ) . '</mark>';
						}
					?>
                </td>
            </tr>
            <tr>
                <td data-export-label="<?php echo esc_attr__( 'Suhosin Request Max Vars', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'Suhosin Request Max Vars:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
                <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The maximum number of variables your server can use for a single function to avoid overloads.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>', 'aiomatic-automatic-ai-content-writer'; ?></td>
				<?php
					$registered_navs  = get_nav_menu_locations();
					$menu_items_count = array( '0' => '0' );
					foreach ( $registered_navs as $handle => $registered_nav ) {
						$menu = wp_get_nav_menu_object( $registered_nav );
						if ( $menu ) {
							$menu_items_count[] = $menu->count;
						}
					}
					$max_items = max( $menu_items_count );
					
					$required_input_vars = ini_get( 'suhosin.request.max_vars' );
				?>
                <td>
					<?php
						$max_input_vars      = ini_get( 'suhosin.request.max_vars' );
						$required_input_vars = $required_input_vars + ( 500 + 1000 );
						if ( $max_input_vars < $required_input_vars ) {
							echo '<mark class="error">' . sprintf( wp_kses_post( __( '%1$s - Recommended Value: %2$s.<br />Max input vars limitation will truncate POST data such as menus. See: <a href="%3$s" target="_blank" rel="noopener noreferrer">Increasing max input vars limit.</a>', 'aiomatic-automatic-ai-content-writer' ) ), esc_html($max_input_vars), '<strong>' . esc_html($required_input_vars + ( 500 + 1000 )) . '</strong>', 'http://sevenspark.com/docs/ubermenu-3/faqs/menu-item-limit' ) . '</mark>';
						} else {
							echo '<mark class="yes">' . esc_html( $max_input_vars ) . '</mark>';
						}
					?>
                </td>
            </tr>
            <tr>
                <td data-export-label="<?php echo esc_attr__( 'Suhosin Post Max Value Length', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'Suhosin Post Max Value Length:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
                <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Defines the maximum length of a variable that is registered through a POST request.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
                <td><?php
						$suhosin_max_value_length     = ini_get( 'suhosin.post.max_value_length' );
						$recommended_max_value_length = 2000000;
						if ( $suhosin_max_value_length < $recommended_max_value_length ) {
							echo '<mark class="error">' . sprintf( wp_kses_post( __( '%1$s - Recommended Value: %2$s.<br />Post Max Value Length limitation may prohibit the Theme Options data from being saved to your database. See: <a href="%3$s" target="_blank" rel="noopener noreferrer">Suhosin Configuration Info</a>.', 'aiomatic-automatic-ai-content-writer' ) ), esc_html($suhosin_max_value_length), '<strong>' . esc_html($recommended_max_value_length) . '</strong>', 'http://suhosin.org/stories/configuration.html' ) . '</mark>';
						} else {
							echo '<mark class="yes">' . esc_html( $suhosin_max_value_length ) . '</mark>';
						}
					?></td>
            </tr>
		<?php endif; ?><?php endif; ?>
    <tr>
        <td data-export-label="<?php echo esc_attr__( 'MySQL Version', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php esc_html_e( 'MySQL Version:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The version of MySQL installed on your hosting server.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
        <td>
			<?php global $wpdb; ?><?php echo esc_html( $wpdb->db_version() ); ?>
        </td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__('WP Max Upload Size', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'WP Max Upload Size:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The largest file size that can be uploaded to your WordPress installation.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
        <td><?php echo esc_html(size_format( wp_max_upload_size() )); ?></td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__('DOMDocument', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'DOMDocument:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'DOMDocument is required for the Fusion Builder plugin to properly function.', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
        <td><?php echo class_exists( 'DOMDocument' ) ? '<mark class="yes">&#10004;</mark>' : '<mark class="error">DOMDocument is not installed on your server, but is required if you need to use the Fusion Page Builder.</mark>'; ?></td>
    </tr>
    <tr>
        <td data-export-label="<?php echo esc_attr__('GD Library', 'aiomatic-automatic-ai-content-writer'); ?>"><?php esc_html_e( 'GD Library:', 'aiomatic-automatic-ai-content-writer' ); ?></td>
        <td class="help"><?php echo'<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Aimogen uses this library to resize images and speed up your site\'s loading time', 'aiomatic-automatic-ai-content-writer' ) . '">[?]</a>'; ?></td>
        <td>
			<?php
				$info = esc_attr__( 'Not Installed', 'aiomatic-automatic-ai-content-writer' );
				if ( extension_loaded( 'gd' ) && function_exists( 'gd_info' ) ) {
					$info    = esc_attr__( 'Installed', 'aiomatic-automatic-ai-content-writer' );
					$gd_info = gd_info();
					if ( isset( $gd_info['GD Version'] ) ) {
						$info = $gd_info['GD Version'];
					}
				}
				echo esc_html( $info );
			?>
        </td>
    </tr>
    </tbody>
</table>
<h3 class="screen-reader-text"><?php esc_html_e( 'More Info', 'aiomatic-automatic-ai-content-writer' ); ?></h3>
<?php
$loaded_extensions      = get_loaded_extensions();
$extensions             = array();
$extensions['dom']      = in_array( 'dom', $loaded_extensions ) ? '<mark class="yes">dom</mark>' : '<mark class="no">dom</mark>';
$extensions['xml']      = in_array( 'xml', $loaded_extensions ) ? '<mark class="yes">xml</mark>' : '<mark class="no">xml</mark>';
$extensions['mbstring'] = in_array( 'mbstring', $loaded_extensions ) ? '<mark class="yes">mbstring</mark>' : '<mark class="no">mbstring</mark>';
$extensions['curl'] = in_array( 'curl', $loaded_extensions ) ? '<mark class="yes">curl</mark>' : '<mark class="no">curl</mark>';
$information = array();

$information['mysql_version'] = array(
	'label' => __( 'MySQL Detailed version', 'aiomatic-automatic-ai-content-writer' ),
	'value' => $wpdb->get_var( "SELECT VERSION() AS version" ),
);

$information['curl_version'] = array(
	'label' => __( 'cURL version', 'aiomatic-automatic-ai-content-writer' ),
	'value' => function_exists( 'curl_version' ) ? curl_version()['version'] : '',
);

$information['curlssl_version'] = array(
	'label' => __( 'cURL SSL version', 'aiomatic-automatic-ai-content-writer' ),
	'value' => function_exists( 'curl_version' ) ? curl_version()['ssl_version'] : '',
);

$information['cron_url'] = array(
	'label' => __( 'WP-Cron url', 'aiomatic-automatic-ai-content-writer' ),
	'value' => site_url( 'wp-cron.php' ),
);

$information['docroot'] = array(
	'label' => __( 'Document root', 'aiomatic-automatic-ai-content-writer' ),
	'value' => sanitize_text_field($_SERVER['DOCUMENT_ROOT']),
);

$information['server'] = array(
	'label' => __( 'SERVER', 'aiomatic-automatic-ai-content-writer' ),
	'value' => sanitize_text_field($_SERVER['SERVER_SOFTWARE']),
);

$information['os'] = array(
	'label' => __( 'Operating System', 'aiomatic-automatic-ai-content-writer' ),
	'value' => PHP_OS,
);

$information['maxexectime'] = array(
	'label' => __( 'Maximum execution time', 'aiomatic-automatic-ai-content-writer' ),
	'value' => sprintf( __( '%s seconds', 'aiomatic-automatic-ai-content-writer' ), ini_get( 'max_execution_time' ) ),
);

$information['language'] = array(
	'label' => __( 'Language', 'aiomatic-automatic-ai-content-writer' ),
	'value' => get_bloginfo( 'language' ),
);

$information['mysql_encoding'] = array(
	'label' => __( 'MySQL Client encoding', 'aiomatic-automatic-ai-content-writer' ),
	'value' => ! empty( DB_CHARSET ) ? DB_CHARSET : '-',
);

$information['max_upload'] = array(
	'label' => __( 'PHP Max Upload Size', 'aiomatic-automatic-ai-content-writer' ),
	'value' => ini_get( 'memory_limit' ),
);

$information['remote_post'] = array(
	'label' => __( 'Remote Post', 'aiomatic-automatic-ai-content-writer' ),
	'value' => aiomatic_test_post_reponse() ? 'ON' : 'OFF',
);

$information['remote_get'] = array(
	'label' => __( 'Remote Get', 'aiomatic-automatic-ai-content-writer' ),
	'value' => aiomatic_test_get_reponse() ? 'ON' : 'OFF',
);
global $wpdb;

$cron_status = aiomatic_check_cron_status();
$information['cron_running'] = array(
	'label' => __( 'Is CRON running', 'aiomatic-automatic-ai-content-writer' ),
	'value' => is_wp_error($cron_status)? 'No '.esc_html($cron_status->get_error_message()): 'Yes' ,
);


$information['loaded_extensions']   = array(
	'label' => __( 'Loaded PHP Extensions', 'aiomatic-automatic-ai-content-writer' ),
	'value' => implode( ', ', $loaded_extensions ),
);
$information['required_extensions'] = array(
	'label' => __( 'Required PHP Extensions', 'aiomatic-automatic-ai-content-writer' ),
	'value' => implode( ', ', $extensions ),
);
?>


	<table class="wp-list-table widefat fixed" cellspacing="0">
		<thead>
		<tr>
			<th colspan="2"><h4><?php esc_html_e( 'System Information', 'aiomatic-automatic-ai-content-writer' ) ?></h4></th>
		</tr>
		<tr>
			<th width="35%"><?php esc_html_e( 'Setting', 'aiomatic-automatic-ai-content-writer' ) ?></th>
			<th><?php esc_html_e( 'Value', 'aiomatic-automatic-ai-content-writer' ) ?></th>
		</tr>
		</thead>
		<tbody>

		<?php foreach ( $information as $info ) { ?>
			<tr>
				<td><?php echo esc_html($info['label']); ?></td>
				<td><?php echo esc_html($info['value']); ?></td>
			</tr>
		<?php } ?>

		</tbody>
	</table>

   <h3 class="screen-reader-text"><?php esc_html_e( 'Active Plugins', 'aiomatic-automatic-ai-content-writer' ); ?></h3>
<table class="widefat" cellspacing="0" id="status">
    <thead>
    <tr>
        <th colspan="3" data-export-label="<?php echo esc_attr__('Active Plugins', 'aiomatic-automatic-ai-content-writer'); ?> (<?php echo count( (array) get_option( 'active_plugins' ) ); ?>)"><?php esc_html_e( 'Active Plugins', 'aiomatic-automatic-ai-content-writer' ); ?>
            (<?php echo count( (array) get_option( 'active_plugins' ) ); ?>)
        </th>
    </tr>
    </thead>
    <tbody>
	<?php
		$active_plugins = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );
		}
		foreach ( $active_plugins as $plugin ) {
			$plugin_data    = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin );
			if ( ! empty( $plugin_data['Name'] ) ) {
				// Link the plugin name to the plugin url if available.
				$plugin_name = esc_html( $plugin_data['Name'] );
				if ( ! empty( $plugin_data['PluginURI'] ) ) {
					$plugin_name = '<a href="' . esc_url_raw( $plugin_data['PluginURI'] ) . '" title="' . esc_html__( 'Visit plugin homepage', 'aiomatic-automatic-ai-content-writer' ) . '">' . $plugin_name . '</a>';
				}
				?>
                <tr>
                    <td><?php echo wp_kses_post( $plugin_name ); ?></td>
                    <td class="help">&nbsp;</td>
                    <td><?php echo esc_html__( 'by', 'aiomatic-automatic-ai-content-writer' ) . '&nbsp;' . esc_html($plugin_data['Author']) . ' &ndash; ' . esc_html( $plugin_data['Version'] ) ; ?></td>
                </tr>
				<?php
			}
		}
	?>
    </tbody>
</table>
      </div>
      <div id="tab-3l" class="tab-content">
    <br/>
    <hr class="cr_special_hr"/>
<?php
$language_pack_url = 'https://wpinitiate.com/aiomatic-language-packs/';
$local_language_dir = WP_PLUGIN_DIR . '/aiomatic-automatic-ai-content-writer/languages';
if (!$wp_filesystem->exists($local_language_dir)) {
    wp_mkdir_p($local_language_dir);
}
$available_packs = aiomatic_fetch_available_language_packs($language_pack_url);
$installed_packs = aiomatic_get_installed_language_packs($local_language_dir);
?>
<h2><?php esc_html_e('Language Pack Manager', 'aiomatic-automatic-ai-content-writer'); ?></h2>
<p><?php esc_html_e('Manage the language packs for the Aimogen plugin. Below is the list of available language packs, their status, and download links. You can also contact us if you want to contribute translations in your own language.', 'aiomatic-automatic-ai-content-writer'); ?></p>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th><?php esc_html_e('Language', 'aiomatic-automatic-ai-content-writer'); ?></th>
            <th><?php esc_html_e('Status', 'aiomatic-automatic-ai-content-writer'); ?></th>
            <th><?php esc_html_e('Direct Download', 'aiomatic-automatic-ai-content-writer'); ?></th>
            <th><?php esc_html_e('Action', 'aiomatic-automatic-ai-content-writer'); ?></th>
        </tr>
    </thead>
    <tbody>
    <?php if(is_array($available_packs)){
        foreach ($available_packs as $pack): ?>
        <tr>
            <td><?php echo esc_html($pack); ?></td>
            <td>
                <?php
                $installed_packs = aiomatic_get_installed_language_packs_meta();
                if(in_array($pack, $installed_packs))
                {
                    echo esc_html__('Installed', 'aiomatic-automatic-ai-content-writer');
                    $local_language_dir = plugin_dir_path(dirname(__FILE__)) . 'languages';;
                    $mo_path = $local_language_dir . '/' . $pack . '.mo';
                    $po_path = $local_language_dir . '/' . $pack . '.po';
                    if (!$wp_filesystem->exists($mo_path) || !$wp_filesystem->exists($po_path)) {
                        echo ' - ' . esc_html__('Translation files are missing', 'aiomatic-automatic-ai-content-writer');
                    }
                }
                else
                {
                    echo esc_html__('Not Installed', 'aiomatic-automatic-ai-content-writer');
                }
                ?>
            </td>
            <td>
                <a href="<?php echo esc_url($language_pack_url . $pack . '.mo'); ?>" download="<?php echo esc_url($language_pack_url . $pack . '.mo'); ?>" target="_blank">
                    <?php esc_html_e('Download .mo', 'aiomatic-automatic-ai-content-writer'); ?>
                </a>
                |
                <a href="<?php echo esc_url($language_pack_url . $pack . '.po'); ?>" target="_blank">
                    <?php esc_html_e('View .po', 'aiomatic-automatic-ai-content-writer'); ?>
                </a>
            </td>
            <td>
                <?php if (!in_array($pack, $installed_packs)): ?>
                    <button class="button aiomatic-language-action" data-action="install_language" data-pack="<?php echo esc_attr($pack); ?>">
                        <?php esc_html_e('Install', 'aiomatic-automatic-ai-content-writer'); ?>
                    </button>
                <?php else: ?>
                    <button class="button aiomatic-language-action" data-action="uninstall_language" data-pack="<?php echo esc_attr($pack); ?>">
                        <?php esc_html_e('Uninstall', 'aiomatic-automatic-ai-content-writer'); ?>
                    </button>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; 
        }?>
</tbody>
</table>
<hr class="cr_special_hr"/>
    <h3><?php esc_html_e('Want to Help Translate Aimogen?', 'aiomatic-automatic-ai-content-writer'); ?></h3>
    <p>
        <?php esc_html_e('If you would like to contribute translations for Aimogen in your language, I would love your help!', 'aiomatic-automatic-ai-content-writer'); ?>
        <br/>
        <?php esc_html_e('Contact me at:', 'aiomatic-automatic-ai-content-writer'); ?>
        <a href="mailto:support@coderevolution.ro">support@coderevolution.ro</a>
    </p>
    <p><?php esc_html_e('I appreciate your support in making Aimogen accessible to users worldwide.', 'aiomatic-automatic-ai-content-writer'); ?></p><br/><h2 class="aiomatic-inner-title"><?php echo esc_html__('Tutorial Video:', 'aiomatic-automatic-ai-content-writer');?></h2>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
    <div class="cr_center embedtool"><iframe src="https://www.youtube.com/embed/wt18jwFTyg4" allowfullscreen></iframe></div>
<?php } ?>
</div>
<div id="tab-1l" class="tab-content">
      <br/>
      <hr class="cr_special_hr"/>
      <div>
         <h3>
            <?php echo esc_html__("Rules Currently Running:", 'aiomatic-automatic-ai-content-writer');?>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
               <div class="bws_hidden_help_text cr_min_260px">
                  <?php
                     echo esc_html__("These rules are currently running on your server.", 'aiomatic-automatic-ai-content-writer');
                     ?>
               </div>
            </div>
         </h3>
         <div>
            <?php
               if (!get_option('aiomatic_running_list')) {
                   $running = array();
               } else {
                   $running = get_option('aiomatic_running_list');
               }
               if (!empty($running)) {
                   echo '<ul>';
                   foreach($running as $key => $thread)
                   {
                        if(is_array($thread))
                        {
                            foreach($thread as $param => $type)
                            {
                                echo '<li><b>' . esc_html($type) . '</b> - ID' . esc_html($param) . '</li>';
                            }
                        }
                        else
                        {
                            echo '<li>ID - ' . esc_html($thread) . '</li>';
                        }
                   }
                   echo '</ul>';        
               }
               else
               {
                   echo esc_html__('No rules are running right now', 'aiomatic-automatic-ai-content-writer');
               }
               ?>
         </div>
         <hr/>
         <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to clear the running list?', 'aiomatic-automatic-ai-content-writer');?>');">
            <input name="aiomatic_delete_rules" class="button-primary" type="submit" title="<?php echo esc_html__('Caution! This is for debugging purpose only!', 'aiomatic-automatic-ai-content-writer');?>" value="<?php echo esc_html__('Clear Running Rules List', 'aiomatic-automatic-ai-content-writer');?>">
            <input name="aiomatic_nonce" type="hidden" value="<?php echo esc_html(wp_create_nonce('openai-secret-nonce'));?>">
         </form>
      </div>
         <br/>
         <hr class="cr_special_hr"/>
         <div>
            <h3>
               <?php echo esc_html__('Restore Plugin Default Settings', 'aiomatic-automatic-ai-content-writer');?> 
               <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                  <div class="bws_hidden_help_text cr_min_260px">
                     <?php
                        echo esc_html__('Hit this button and the plugin settings will be restored to their default values. Warning! All settings will be lost!', 'aiomatic-automatic-ai-content-writer');
                        ?>
                  </div>
               </div>
            </h3>
            <hr/>
            <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to restore the default plugin settings?', 'aiomatic-automatic-ai-content-writer');?>');"><input name="aiomatic_restore_defaults" class="button-primary" type="submit" value="<?php echo esc_html__('Restore Plugin Default Settings', 'aiomatic-automatic-ai-content-writer');?>">
         <input name="aiomatic_nonce" type="hidden" value="<?php echo esc_html(wp_create_nonce('openai-secret-nonce'));?>"></form>
         </div>
         <br/>
         <hr class="cr_special_hr"/>
         <div>
            <h3>
               <?php echo esc_html__('Delete All Posts Generated by this Plugin:', 'aiomatic-automatic-ai-content-writer');?> 
               <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                  <div class="bws_hidden_help_text cr_min_260px">
                     <?php
                        echo esc_html__('Hit this button and all posts generated by this plugin will be deleted! Optionally set a date range to delete only posts published between those dates. Leave the dates empty to delete all generated posts.', 'aiomatic-automatic-ai-content-writer');
                        ?>
                  </div>
               </div>
            </h3>
            <hr/>
            <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to delete the selected generated posts? This can take a while, please wait until it finishes.', 'aiomatic-automatic-ai-content-writer');?>');">
               <p>
                  <label for="aiomatic_delete_date_from"><b><?php echo esc_html__('From date:', 'aiomatic-automatic-ai-content-writer');?></b></label>
                  <input type="date" name="aiomatic_delete_date_from" id="aiomatic_delete_date_from" value="" />
                  &nbsp;
                  <label for="aiomatic_delete_date_to"><b><?php echo esc_html__('To date:', 'aiomatic-automatic-ai-content-writer');?></b></label>
                  <input type="date" name="aiomatic_delete_date_to" id="aiomatic_delete_date_to" value="" />
               </p>
               <input class="button-primary" name="aiomatic_delete_all" type="submit" value="<?php echo esc_html__('Delete All Generated Posts', 'aiomatic-automatic-ai-content-writer');?>">
         <input name="aiomatic_nonce" type="hidden" value="<?php echo esc_html(wp_create_nonce('openai-secret-nonce'));?>"></form>
         </div>
         <br/>
         <hr class="cr_special_hr"/>
         <div>
            <h3>
               <?php echo esc_html__('Delete All Rules from All Section: ', 'aiomatic-automatic-ai-content-writer');?>
               <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                  <div class="bws_hidden_help_text cr_min_260px">
                     <?php
                        echo esc_html__("Hit this button and all rules will be deleted!", 'aiomatic-automatic-ai-content-writer');
                        ?>
                  </div>
               </div>
            </h3>
            <hr/>
            <form method="post" onsubmit="return confirm('Are you sure you want to delete all rules?');"><input class="button-primary" name="aiomatic_delete_all_rules" type="submit" value="Delete All Generated Rules">
         <input name="aiomatic_nonce" type="hidden" value="<?php echo esc_html(wp_create_nonce('openai-secret-nonce'));?>"></form>
         </div>
         <br/>
   </div>
   <div id="tab-0l" class="tab-content">
         <hr class="cr_special_hr"/>
         <h3>
            <?php echo esc_html__('Activity Log:', 'aiomatic-automatic-ai-content-writer');?>
            <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
               <div class="bws_hidden_help_text cr_min_260px">
                  <?php
                     echo esc_html__('This is the main log of your plugin. Here will be listed every single instance of the rules you run or are automatically run by schedule jobs (if you enable logging, in the plugin configuration). Log location: ', 'aiomatic-automatic-ai-content-writer') . esc_html($log_file);
                     ?>
               </div>
            </div>
         </h3>
      <hr/>
      <form method="post" onsubmit="return confirm('<?php echo esc_html__('Are you sure you want to delete all logs?', 'aiomatic-automatic-ai-content-writer');?>');">
         <input name="aiomatic_delete" type="submit" class="button-primary" value="<?php echo esc_html__('Delete Logs', 'aiomatic-automatic-ai-content-writer');?>">
         <input name="aiomatic_nonce" type="hidden" value="<?php echo wp_create_nonce('openai-secret-nonce');?>">
      </form>
      <hr/>
         <div>
            <?php
               if($wp_filesystem->exists($log_file))
               {
                    $log = $wp_filesystem->get_contents($log_file);
                    $log = esc_html($log);$log = str_replace('&lt;br/&gt;', '<br/>', $log);echo wp_kses_post($log);
               }
               else
               {
                   echo esc_html__('Log empty', 'aiomatic-automatic-ai-content-writer');
               }
               ?>
         </div>
      </div>
</div>
</div>
</section>
</div>
</div>
<?php
}
?>
