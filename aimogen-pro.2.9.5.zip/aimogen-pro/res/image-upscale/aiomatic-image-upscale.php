<?php
if ( ! defined ( 'ABSPATH' ) ) {
	die ( 'Not allowed' );
}

function aimogenpro_get_upscale_image_url( $id ) {
	$nonce = wp_create_nonce( 'aiomatic_upscale_image_nonce' );
	return admin_url( 'admin-ajax.php' ) . '?action=aimogenpro_upscale_image_page&post=' . intval( $id ) . '&nonce=' . $nonce;
}

function aimogenpro_get_upscale_image_anchor( $id, $style = '', $classes = '' ) {
	add_thickbox();
	$upscale_url = aimogenpro_get_upscale_image_url( $id );
	return '<a class="autox-thickbox aiomatic ' . esc_attr( $classes ) . '" style="' . esc_attr( $style ) . '" href="' . esc_url( $upscale_url ) . '" title="' . esc_attr__( 'AI Image Upscale (Stable Diffusion)', 'aiomatic-automatic-ai-content-writer' ) . '">' . esc_html__( 'AI Image Upscale', 'aiomatic-automatic-ai-content-writer' ) . '</a>';
}

function aimogenpro_get_upscale_image_anchor_ajax() {
	check_ajax_referer( 'openai-ajax-nonce', 'nonce' );
	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
	}
	$classes = empty( $_POST['classes'] ) ? 'edit-attachment' : sanitize_text_field( wp_unslash( $_POST['classes'] ) );
	$post_id = isset( $_POST['post'] ) ? intval( $_POST['post'] ) : 0;
	echo aimogenpro_get_upscale_image_anchor( $post_id, 'margin-right:10px;', $classes );
	die();
}
add_action( 'wp_ajax_aimogenpro_get_upscale_image_anchor', 'aimogenpro_get_upscale_image_anchor_ajax' );

function aimogenpro_upscale_image_page() {
	if ( ! isset( $_GET['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'aiomatic_upscale_image_nonce' ) ) {
		wp_send_json_error( array( 'message' => 'Invalid nonce' ), 403 );
	}
	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
	}
	global $aiomatic_upscale_image_id;
	$aiomatic_upscale_image_id = isset( $_GET['post'] ) ? intval( $_GET['post'] ) : 0;
	if ( current_user_can( 'access_aiomatic_menu', $aiomatic_upscale_image_id ) && wp_attachment_is_image( $aiomatic_upscale_image_id ) ) {
		include dirname( __FILE__ ) . '/upscale-panel.php';
	} else {
		die();
	}
}
add_action( 'wp_ajax_aimogenpro_upscale_image_page', 'aimogenpro_upscale_image_page' );

function aimogenpro_print_upscale_media_templates() {
	?>
	<script>
	jQuery(document).ready(function()
	{
		if (window.aiomaticExtendMediaLightboxTemplate)
		{
			aiomaticExtendMediaLightboxTemplate(
				'<?php echo aimogenpro_get_upscale_image_anchor( '{{ data.id }}', 'display:block;text-decoration:none;' ); ?>',
				'<?php echo aimogenpro_get_upscale_image_anchor( '{{ data.id }}', 'text-decoration:none;' ); ?>',
				'<?php echo aimogenpro_get_upscale_image_anchor( '{{ data.id }}', '', 'button' ); ?>',
				'<?php echo aimogenpro_get_upscale_image_anchor( '{{ data.attachment.id }}', '', 'button' ); ?>'
			);
		}
	});
	</script>
	<?php
}
add_action( 'print_media_templates', 'aimogenpro_print_upscale_media_templates' );

function aimogenpro_upscale_media_row_actions( $actions, $post, $detached ) {
	if ( wp_attachment_is_image( $post->ID ) && current_user_can( 'access_aiomatic_menu', $post->ID ) ) {
		$actions['aiomatic_upscale'] = aimogenpro_get_upscale_image_anchor( $post->ID );
	}
	return $actions;
}
add_filter( 'media_row_actions', 'aimogenpro_upscale_media_row_actions', 10, 3 );

function aiomatic_upscale_image_ajax() {
	check_ajax_referer( 'openai-ajax-nonce', 'nonce' );
	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_send_json( array( 'status' => 'error', 'msg' => 'Unauthorized' ) );
	}
	@set_time_limit( 660 );
	$aiomatic_Main_Settings = get_option( 'aiomatic_Main_Settings', false );
	if ( ! isset( $aiomatic_Main_Settings['stability_app_id'] ) || trim( $aiomatic_Main_Settings['stability_app_id'] ) == '' ) {
		wp_send_json( array( 'status' => 'error', 'msg' => 'You need to insert a valid Stability.AI API Key for this to work!' ) );
	}

	$attachment_id = isset( $_POST['attachment_id'] ) ? intval( $_POST['attachment_id'] ) : 0;
	$mode = isset( $_POST['mode'] ) ? sanitize_text_field( wp_unslash( $_POST['mode'] ) ) : 'fast';
	$prompt = isset( $_POST['prompt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['prompt'] ) ) : '';
	$negative_prompt = isset( $_POST['negative_prompt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['negative_prompt'] ) ) : '';
	$creativity = isset( $_POST['creativity'] ) ? sanitize_text_field( wp_unslash( $_POST['creativity'] ) ) : '';
	$output_format = isset( $_POST['output_format'] ) ? sanitize_text_field( wp_unslash( $_POST['output_format'] ) ) : 'png';
	$save_mode = isset( $_POST['save_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['save_mode'] ) ) : 'new';

	if ( $attachment_id <= 0 || ! wp_attachment_is_image( $attachment_id ) ) {
		wp_send_json( array( 'status' => 'error', 'msg' => 'Invalid image attachment.' ) );
	}
	if ( ! current_user_can( 'access_aiomatic_menu', $attachment_id ) ) {
		wp_send_json( array( 'status' => 'error', 'msg' => 'Unauthorized for this attachment.' ) );
	}

	$image_path = get_attached_file( $attachment_id );
	$image_url = wp_get_attachment_url( $attachment_id );
	$source = ( $image_path && file_exists( $image_path ) ) ? $image_path : $image_url;
	if ( empty( $source ) ) {
		wp_send_json( array( 'status' => 'error', 'msg' => 'Could not locate the source image file.' ) );
	}

	$options = array(
		'output_format' => $output_format,
	);
	if ( $negative_prompt !== '' ) {
		$options['negative_prompt'] = $negative_prompt;
	}
	if ( $creativity !== '' && is_numeric( $creativity ) ) {
		$options['creativity'] = floatval( $creativity );
	}

	$ierror = '';
	$result = aiomatic_generate_stability_upscale( $source, $prompt, $mode, 'mediaLibraryStableUpscale', 0, false, $ierror, true, $options );
	if ( $result === false || empty( $result[0] ) || empty( $result[1] ) ) {
		wp_send_json( array( 'status' => 'error', 'msg' => 'Upscale failed: ' . ( $ierror !== '' ? $ierror : 'Unknown error' ) ) );
	}

	$new_path = $result[0];
	$new_url = $result[1];
	$new_attachment_id = 0;

	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	if ( $save_mode === 'replace' ) {
		$original_path = get_attached_file( $attachment_id );
		$copied = false;
		if ( $original_path && file_exists( $new_path ) ) {
			$copied = @copy( $new_path, $original_path );
			if ( $copied ) {
				$meta = wp_generate_attachment_metadata( $attachment_id, $original_path );
				wp_update_attachment_metadata( $attachment_id, $meta );
				update_post_meta( $attachment_id, '_aiomatic_upscaled', current_time( 'mysql' ) );
				update_post_meta( $attachment_id, '_aiomatic_upscale_mode', $mode );
				if ( file_exists( $new_path ) && realpath( $new_path ) !== realpath( $original_path ) ) {
					wp_delete_file( $new_path );
				}
				$new_attachment_id = $attachment_id;
				$new_url = wp_get_attachment_url( $attachment_id );
			}
		}
		if ( ! $copied || ! $new_attachment_id ) {
			wp_send_json( array( 'status' => 'error', 'msg' => 'Failed to replace the original attachment file.' ) );
		}
	} else {
		$filetype = wp_check_filetype( basename( $new_path ), null );
		$attachment = array(
			'guid'           => $new_url,
			'post_mime_type' => $filetype['type'],
			'post_title'     => sanitize_file_name( pathinfo( $new_path, PATHINFO_FILENAME ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);
		$parent_id = wp_get_post_parent_id( $attachment_id );
		$new_attachment_id = wp_insert_attachment( $attachment, $new_path, $parent_id ? $parent_id : 0 );
		if ( is_wp_error( $new_attachment_id ) || ! $new_attachment_id ) {
			wp_send_json( array( 'status' => 'error', 'msg' => 'Failed to create a new media attachment for the upscaled image.' ) );
		}
		$attach_data = wp_generate_attachment_metadata( $new_attachment_id, $new_path );
		wp_update_attachment_metadata( $new_attachment_id, $attach_data );
		update_post_meta( $new_attachment_id, '_aiomatic_upscaled_from', $attachment_id );
		update_post_meta( $new_attachment_id, '_aiomatic_upscale_mode', $mode );
		$new_url = wp_get_attachment_url( $new_attachment_id );
	}

	wp_send_json( array(
		'status'        => 'success',
		'url'           => $new_url,
		'attachment_id' => $new_attachment_id,
		'msg'           => __( 'Image upscaled successfully.', 'aiomatic-automatic-ai-content-writer' ),
	) );
}
add_action( 'wp_ajax_aiomatic_upscale_image_ajax', 'aiomatic_upscale_image_ajax' );
