<?php
if ( ! defined ( 'ABSPATH' ) ) {
	die ( 'Not allowed' );
}
global $aiomatic_upscale_image_id;
$attachment_id = intval( $aiomatic_upscale_image_id );
$thumb = wp_get_attachment_image_src( $attachment_id, 'medium' );
$full = wp_get_attachment_url( $attachment_id );
$title = get_the_title( $attachment_id );
?>
<div id="aiomatic-upscale-wrapper">
	<div class="media-modal wp-core-ui">
		<button type="button" class="media-modal-close" onclick="aiomaticCancelCropImage();">
			<span class="media-modal-icon">
				<span class="screen-reader-text"><?php esc_html_e( 'Close panel', 'aiomatic-automatic-ai-content-writer' ); ?></span>
			</span>
		</button>
		<div class="media-modal-content">
			<div class="media-frame wp-core-ui">
				<div class="media-frame-title"><h1><?php esc_html_e( 'Aimogen - Stable Diffusion Image Upscale', 'aiomatic-automatic-ai-content-writer' ); ?></h1></div>
				<div class="media-frame-content" style="padding:20px;">
					<div style="display:flex;gap:24px;flex-wrap:wrap;">
						<div style="flex:0 0 220px;">
							<?php if ( ! empty( $thumb[0] ) ) : ?>
								<img src="<?php echo esc_url( $thumb[0] ); ?>" alt="" style="max-width:100%;height:auto;border:1px solid #ccd0d4;" />
							<?php endif; ?>
							<p><strong><?php echo esc_html( $title ); ?></strong></p>
							<p><a href="<?php echo esc_url( $full ); ?>" target="_blank"><?php esc_html_e( 'Open original', 'aiomatic-automatic-ai-content-writer' ); ?></a></p>
						</div>
						<div style="flex:1 1 360px;">
							<p>
								<label for="aiomatic_upscale_mode"><strong><?php esc_html_e( 'Upscale mode', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<select id="aiomatic_upscale_mode" class="aiomatic-full" style="width:100%;max-width:100%;">
									<option value="fast"><?php esc_html_e( 'Fast (~4x, cheapest)', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="conservative"><?php esc_html_e( 'Conservative (up to ~4MP, preserves fidelity)', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="creative"><?php esc_html_e( 'Creative (async, best for degraded images)', 'aiomatic-automatic-ai-content-writer' ); ?></option>
								</select>
							</p>
							<p class="aiomatic-upscale-prompt-wrap">
								<label for="aiomatic_upscale_prompt"><strong><?php esc_html_e( 'Prompt', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<textarea id="aiomatic_upscale_prompt" rows="3" style="width:100%;max-width:100%;" placeholder="<?php esc_attr_e( 'Describe the image (required for Conservative & Creative)', 'aiomatic-automatic-ai-content-writer' ); ?>"><?php echo esc_textarea( $title ); ?></textarea>
								<small><?php esc_html_e( 'Required for Conservative and Creative modes. Optional for Fast.', 'aiomatic-automatic-ai-content-writer' ); ?></small>
							</p>
							<p>
								<label for="aiomatic_upscale_negative"><strong><?php esc_html_e( 'Negative prompt (optional)', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="text" id="aiomatic_upscale_negative" style="width:100%;max-width:100%;" value="" />
							</p>
							<p>
								<label for="aiomatic_upscale_creativity"><strong><?php esc_html_e( 'Creativity', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="number" id="aiomatic_upscale_creativity" min="0.1" max="0.5" step="0.05" value="0.35" style="width:120px;" />
								<small><?php esc_html_e( 'Conservative: 0.2–0.5 · Creative: 0.1–0.5', 'aiomatic-automatic-ai-content-writer' ); ?></small>
							</p>
							<p>
								<label for="aiomatic_upscale_format"><strong><?php esc_html_e( 'Output format', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<select id="aiomatic_upscale_format">
									<option value="png">PNG</option>
									<option value="jpeg">JPEG</option>
									<option value="webp">WEBP</option>
								</select>
							</p>
							<p>
								<label for="aiomatic_upscale_save_mode"><strong><?php esc_html_e( 'Save result as', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<select id="aiomatic_upscale_save_mode">
									<option value="new"><?php esc_html_e( 'New media library item', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="replace"><?php esc_html_e( 'Replace original file', 'aiomatic-automatic-ai-content-writer' ); ?></option>
								</select>
							</p>
							<p>
								<button type="button" class="button button-primary" id="aiomatic_run_upscale" data-attachment-id="<?php echo esc_attr( $attachment_id ); ?>">
									<?php esc_html_e( 'Upscale Image', 'aiomatic-automatic-ai-content-writer' ); ?>
								</button>
								<span id="aiomatic_upscale_status" style="margin-left:10px;"></span>
							</p>
							<div id="aiomatic_upscale_result" style="display:none;">
								<h3><?php esc_html_e( 'Result', 'aiomatic-automatic-ai-content-writer' ); ?></h3>
								<img id="aiomatic_upscale_result_img" src="" alt="" style="max-width:100%;height:auto;border:1px solid #ccd0d4;" />
								<p><a id="aiomatic_upscale_result_link" href="#" target="_blank"><?php esc_html_e( 'Open upscaled image', 'aiomatic-automatic-ai-content-writer' ); ?></a></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
jQuery(function($){
	function togglePromptHint(){
		var mode = $('#aiomatic_upscale_mode').val();
		$('.aiomatic-upscale-prompt-wrap small').text(
			mode === 'fast'
				? <?php echo wp_json_encode( __( 'Optional for Fast mode.', 'aiomatic-automatic-ai-content-writer' ) ); ?>
				: <?php echo wp_json_encode( __( 'Required for Conservative and Creative modes.', 'aiomatic-automatic-ai-content-writer' ) ); ?>
		);
	}
	$('#aiomatic_upscale_mode').on('change', togglePromptHint);
	togglePromptHint();
	$('#aiomatic_run_upscale').on('click', function(){
		var $btn = $(this);
		var mode = $('#aiomatic_upscale_mode').val();
		var prompt = $('#aiomatic_upscale_prompt').val();
		if ((mode === 'conservative' || mode === 'creative') && !$.trim(prompt)) {
			alert(<?php echo wp_json_encode( __( 'Please enter a prompt for this upscale mode.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
			return;
		}
		$btn.prop('disabled', true);
		$('#aiomatic_upscale_status').text(<?php echo wp_json_encode( __( 'Upscaling… this may take a while for Creative mode.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
		$('#aiomatic_upscale_result').hide();
		$.ajax({
			url: ajaxurl,
			type: 'POST',
			timeout: (mode === 'creative' ? 660000 : 180000),
			data: {
				action: 'aiomatic_upscale_image_ajax',
				nonce: (typeof aiomatic_media_object !== 'undefined' ? aiomatic_media_object.nonce : ''),
				attachment_id: $btn.data('attachment-id'),
				mode: mode,
				prompt: prompt,
				negative_prompt: $('#aiomatic_upscale_negative').val(),
				creativity: $('#aiomatic_upscale_creativity').val(),
				output_format: $('#aiomatic_upscale_format').val(),
				save_mode: $('#aiomatic_upscale_save_mode').val()
			}
		}).done(function(res){
			if (res && res.status === 'success') {
				$('#aiomatic_upscale_status').text(res.msg || <?php echo wp_json_encode( __( 'Done.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
				$('#aiomatic_upscale_result_img').attr('src', res.url);
				$('#aiomatic_upscale_result_link').attr('href', res.url);
				$('#aiomatic_upscale_result').show();
			} else {
				$('#aiomatic_upscale_status').text('');
				alert((res && res.msg) ? res.msg : <?php echo wp_json_encode( __( 'Upscale failed.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
			}
		}).fail(function(){
			$('#aiomatic_upscale_status').text('');
			alert(<?php echo wp_json_encode( __( 'Request failed. Please try again.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
		}).always(function(){
			$btn.prop('disabled', false);
		});
	});
});
</script>
