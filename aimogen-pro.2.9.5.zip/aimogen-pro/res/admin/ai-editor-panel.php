<?php
/*
 * Aimogen AI Editor - classic editor mount point.
 *
 * The panel renders itself from scripts/aimogen-ai-editor-ui.js, which picks this
 * container up on DOMContentLoaded. Everything it needs was already localised onto
 * window.aimogenAiEditor by aimogen_ai_editor_enqueue_assets().
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div id="aimogen-ai-editor-root" class="aimogen-ai-editor aimogen-ai-editor--metabox">
    <noscript>
        <p><?php echo esc_html__('The Aimogen AI Editor needs JavaScript enabled.', 'aiomatic-automatic-ai-content-writer'); ?></p>
    </noscript>
</div>
