<?php
defined('ABSPATH') or die(); 
function aiomatic_mcp_panel()
{
    $settings = get_option('aiomatic_mcp_settings', []);
    $bearer_token = isset($settings['bearer_token']) ? $settings['bearer_token'] : '';
    $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
    $sse_url = esc_url_raw( rest_url('aiomatic-mcp/v1/sse') );
    $http_url = esc_url_raw( rest_url('aiomatic-mcp/v1/http') );
    $messages_url = esc_url_raw( rest_url('aiomatic-mcp/v1/messages') );
    $tools_url = esc_url_raw( rest_url('aiomatic-mcp/v1/aiomatic-tools') );
    ?>
<div class="wp-header-end"></div>
<div class="aiomatic-admin-shell">
<?php aimogen_render_admin_hero(); ?>
<div class="aiomatic-admin-layout">
    <aside class="aiomatic-admin-sidebar">
         <div class="aiomatic-admin-sidebar-inner">
            <div class="aiomatic-sidebar-heading">
               <?php esc_html_e( 'MCP Servers', 'aiomatic-automatic-ai-content-writer' ); ?>
            </div>
            <div class="aiomatic-sidebar-nav">
               <nav class="nav-tab-wrapper">
                  <a href="#tab-0" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">▶︎</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Tutorial", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-1" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⩰</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Create Your MCP Server", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
                  <a href="#tab-2" class="aiomatic-nav-tab">
                     <span class="aiomatic-sidebar-icon">⩯</span>
                     <span class="aiomatic-sidebar-label"><?php echo esc_html__("Connect To A MCP Server", 'aiomatic-automatic-ai-content-writer');?></span>
                  </a>
               </nav>
            </div>
            <div class="aiomatic-sidebar-footer">
               <strong><?php esc_html_e( 'Need a quick start?', 'aiomatic-automatic-ai-content-writer' ); ?></strong>
               <span><?php esc_html_e( '1. Set up your own MCP server, exposing specific tools and allow AI models to connect to them.', 'aimogen' ); ?></span>
               <span><?php esc_html_e( '2. Connect your AI models to external MCP servers and use custom tools provided by them.', 'aimogen' ); ?></span>
               <span>
                  <?php esc_html_e( 'Watch tutorials on', 'aiomatic-automatic-ai-content-writer' ); ?>
                  <a href="https://www.youtube.com/channel/UCVLIksvzyk-D_oEdHab2Lgg" target="_blank" rel="noopener noreferrer">CodeRevolutionTV</a>
               </span>
            </div>
         </div>
      </aside>
<section class="aiomatic-admin-main">
    <div class="gs_popuptype_holder">

        <div id="tab-0" class="tab-content" style="display:block">
            <br/><h3><?php echo esc_html__('MCP Server Tutorial', 'aiomatic-automatic-ai-content-writer'); ?></h3>
<div>
    <p>
        <?php echo esc_html__('The Model Context Protocol (MCP) support built into Aimogen allows your WordPress site to become more than just a publishing platform. 
        Once enabled, your site acts as an MCP server using Server Sent Events (SSE). 
        This means tools like Claude Desktop can connect through a local relay script, and services like OpenAI Deep Research can discover and call the functions you expose here.', 'aiomatic-automatic-ai-content-writer'); ?>
    </p>
    <p>
        <?php echo esc_html__('Enabling the MCP extension plugin unlocks a control panel where you can decide which tool packs are exposed. 
        The Core WordPress pack is recommended because it registers useful functions that let AI models interact with posts, pages, media, taxonomies, and other essentials. 
        You can also turn on plugin oriented helpers, theme oriented helpers, or even WooCommerce helpers if you run a shop. 
        There is an option to generate a dynamic REST layer that creates CRUD style endpoints for content, giving models a way to create or update posts directly.', 'aiomatic-automatic-ai-content-writer'); ?>
    </p>
    <p>
        <?php echo esc_html__('Once you check Enable MCP server, an endpoint will be available and protected by the Bearer Token you configure. 
        Any client connecting to this endpoint must provide the correct token. 
        There is also a Debug Mode which is only intended for local testing, it lets you see raw function registrations and requests.', 'aiomatic-automatic-ai-content-writer'); ?>
    </p>
    <p>
        <?php echo esc_html__('When the extension is active and the MCP server is enabled you will see your live endpoints listed below. 
        These are the exact URLs that an MCP client or relay script will consume. 
        For example, Claude Desktop requires a relay script pointing to the SSE endpoint, while Deep Research clients may call the Messages endpoint to exchange structured data.', 'aiomatic-automatic-ai-content-writer'); ?>
    </p>
    <p>
        <?php echo esc_html__('If you scroll further down in the MCP panel you will also see the Messages endpoint and the list of registered tools. 
        The refresh button will query your server and print the current function set in JSON format, which makes it easy to verify what is exposed.', 'aiomatic-automatic-ai-content-writer'); ?>
    </p>
    <p>
        <?php echo esc_html__('For users running multiple MCP servers, the Connect tab lets you register and manage external servers. 
        Each server entry has a name, description, URL, authentication token, and a flag for global enablement. 
        Aimogen will then merge those into the active context for supported AI models, allowing you to extend functionality across different environments.', 'aiomatic-automatic-ai-content-writer'); ?>
    </p>
    <p>
        <?php echo esc_html__('In short, Aimogen\'s MCP support turns your WordPress site into a living API hub that AI tools can call. 
        By enabling SSE, protecting it with a token, and choosing the right tool packs, you gain fine control over how AI assistants interact with your content, plugins, themes, and store. 
        The extension plugin is required for this functionality and once active, everything can be configured directly here in the WordPress admin panel.', 'aiomatic-automatic-ai-content-writer'); ?>
    </p>
    <p><?php echo wp_kses(
    sprintf(
        __(
            'Check %s for more details on usage of the MCP server feature of Aimogen.',
            'aiomatic-automatic-ai-content-writer'
        ),
        '<a href="https://coderevolution.ro/knowledge-base/faq/how-to-connect-claude-to-wordpress-with-aiomatic-mcp/" target="_blank">this tutorial</a>'
    ),
    array(
        'a' => array(
            'href'   => array(),
            'target' => array(),
        ),
    )
);?></p>
</div>

            <?php if (!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on') { ?>
                <h3><?php echo esc_html__('Tutorial Video', 'aiomatic-automatic-ai-content-writer'); ?></h3>
                <p class="cr_center">
                    <div class="embedtool">
                        <iframe src="https://www.youtube.com/embed/niILXouTah4" frameborder="0" allowfullscreen></iframe>
                    </div>
                </p>
            <?php } ?>
        </div>

        <div id="tab-1" class="tab-content" style="display:none">
            <br/>
            <h3><?php echo esc_html__('Create Your Own MCP Server', 'aiomatic-automatic-ai-content-writer'); ?></h3>
            <p><?php echo esc_html__('Create a MCP server on your website and allow AI models to directly connect to it and use tools published by it. Like this, external AI models can control your site, query information from it and insert or update data on it.', 'aiomatic-automatic-ai-content-writer'); ?></p>

<?php
// Everything below is read-only help text; the values come from the settings
// saved further down this page.
$tut_token   = ($bearer_token !== '') ? $bearer_token : 'YOUR_TOKEN';
$tut_transport = isset($settings['mcp_transport']) ? $settings['mcp_transport'] : 'both';
if (!in_array($tut_transport, ['legacy', 'streamable', 'both'], true)) { $tut_transport = 'both'; }
// Point the instructions at whichever endpoint is actually switched on.
$tut_url = ($tut_transport === 'legacy') ? $sse_url : $http_url;
$tut_is_http  = (stripos($sse_url, 'https://') !== 0);
?>
            <h4><?php echo esc_html__('How to connect an AI agent', 'aiomatic-automatic-ai-content-writer'); ?></h4>
            <p><?php echo esc_html__('Your site exposes a single MCP endpoint. Every agent needs the same two things: the endpoint URL, and the Bearer Token set in the settings below.', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php echo esc_html__('Endpoint URL', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <td>
                        <p><code><?php echo esc_html($tut_url); ?></code></p>
                        <?php if ($tut_transport === 'both'): ?>
                        <p class="description"><?php echo esc_html__('This is the modern Streamable HTTP endpoint. The older SSE endpoint below still answers as well, for anything already set up against it:', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        <p><code><?php echo esc_html($sse_url); ?></code></p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('Authentication', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <td>
                        <p><?php echo esc_html__('Send this HTTP header:', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        <p><code>Authorization: Bearer <?php echo esc_html($tut_token); ?></code></p>
                        <p class="description"><?php echo esc_html__('The word "Bearer" followed by a space is required - sending the token on its own is rejected. If an agent has no place to add headers, append the token to the URL instead:', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        <p><code><?php echo esc_html($tut_url); ?>?token=<?php echo esc_html($tut_token); ?></code></p>
                    </td>
                </tr>
            </table>

            <?php if ($tut_is_http): ?>
            <div style="margin:15px 0; padding:15px; border:1px solid #ccd0d4; border-radius:8px; background:#fff3cd; color:#856404;">
                <?php if ($tut_is_http): ?>
                <p><strong><?php echo esc_html__('This site is not using HTTPS.', 'aiomatic-automatic-ai-content-writer'); ?></strong> <?php echo esc_html__('Some agents refuse plain HTTP for remote MCP servers, and the Bearer Token would travel unencrypted. Use an HTTPS address before connecting anything.', 'aiomatic-automatic-ai-content-writer'); ?></p>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <h4><?php echo esc_html__('ChatGPT', 'aiomatic-automatic-ai-content-writer'); ?></h4>
            <p><?php echo esc_html__('Open Settings -> Connectors -> Advanced -> turn on Developer mode. Go back to Connectors, click Create, then fill in:', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <ul style="list-style:disc; margin-left:25px;">
                <li><?php echo esc_html__('Name: any name you like, for example My Site', 'aiomatic-automatic-ai-content-writer'); ?></li>
                <li><?php echo esc_html__('Type: Streamable HTTP', 'aiomatic-automatic-ai-content-writer'); ?></li>
                <li><?php echo esc_html__('URL: the endpoint URL above', 'aiomatic-automatic-ai-content-writer'); ?></li>
                <li><?php echo esc_html__('Headers: add a header with the key Authorization and the value Bearer followed by your token', 'aiomatic-automatic-ai-content-writer'); ?></li>
            </ul>
            <p><?php echo esc_html__('Leave the "Bearer token env var" box empty - it expects the name of an environment variable, not the token itself. Click Save, then start a new chat and pick the connector from the tools menu.', 'aiomatic-automatic-ai-content-writer'); ?></p>

            <h4><?php echo esc_html__('Claude Desktop', 'aiomatic-automatic-ai-content-writer'); ?></h4>
            <p><?php echo esc_html__('Open Settings -> Developer -> Edit Config, and add this to the mcpServers section (Node.js is required):', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <pre style="background:#f6f7f7; border:1px solid #ccd0d4; border-radius:6px; padding:12px; overflow:auto;"><code>{
  "mcpServers": {
    "my-site": {
      "command": "npx",
      "args": [
        "-y", "mcp-remote",
        "<?php echo esc_html($tut_url); ?>",
        "--header", "Authorization: Bearer <?php echo esc_html($tut_token); ?>"
      ]
    }
  }
}</code></pre>
            <p><?php echo esc_html__('Save the file and restart Claude Desktop. The tools appear under the connectors icon in the message box.', 'aiomatic-automatic-ai-content-writer'); ?></p>

            <h4><?php echo esc_html__('Claude Code', 'aiomatic-automatic-ai-content-writer'); ?></h4>
            <p><?php echo esc_html__('Run this in a terminal:', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <pre style="background:#f6f7f7; border:1px solid #ccd0d4; border-radius:6px; padding:12px; overflow:auto;"><code>claude mcp add --transport http my-site <?php echo esc_html($tut_url); ?> --header "Authorization: Bearer <?php echo esc_html($tut_token); ?>"</code></pre>
            <p><?php echo esc_html__('Check it connected with the /mcp command inside Claude Code.', 'aiomatic-automatic-ai-content-writer'); ?></p>

            <h4><?php echo esc_html__('Cursor', 'aiomatic-automatic-ai-content-writer'); ?></h4>
            <p><?php echo esc_html__('Create or edit the file .cursor/mcp.json in your project, or ~/.cursor/mcp.json for every project:', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <pre style="background:#f6f7f7; border:1px solid #ccd0d4; border-radius:6px; padding:12px; overflow:auto;"><code>{
  "mcpServers": {
    "my-site": {
      "url": "<?php echo esc_html($tut_url); ?>",
      "headers": { "Authorization": "Bearer <?php echo esc_html($tut_token); ?>" }
    }
  }
}</code></pre>

            <h4><?php echo esc_html__('Any other agent', 'aiomatic-automatic-ai-content-writer'); ?></h4>
            <p><?php echo esc_html__('The endpoint answers JSON-RPC over HTTP POST. Anything that can post JSON with a custom header will work. Test the connection from a terminal before wiring up an agent - this should list the available tools:', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <pre style="background:#f6f7f7; border:1px solid #ccd0d4; border-radius:6px; padding:12px; overflow:auto;"><code>curl -X POST "<?php echo esc_html($tut_url); ?>" -H "Content-Type: application/json" -H "Authorization: Bearer <?php echo esc_html($tut_token); ?>" -d "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/list\"}"</code></pre>
            <p class="description"><?php echo esc_html__('A 401 answer means the token is wrong or the Bearer prefix is missing. A 404 means the MCP server is switched off in the settings below. Agents that insist on opening a GET event stream or on session headers are not supported yet; those that post JSON-RPC, such as the ones above, are.', 'aiomatic-automatic-ai-content-writer'); ?></p>

            <h4><?php echo esc_html__('Before you connect anything', 'aiomatic-automatic-ai-content-writer'); ?></h4>
            <p><?php echo esc_html__('The Bearer Token is the only thing protecting your site: whoever holds it can use every enabled tool, which may include editing posts, reading settings and managing users. Use a long random token, hand it only to agents you trust, and narrow what it can reach with the Access Level setting below.', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <p><?php echo esc_html__('If your server is behind Cloudflare, go to Cloudflare settings for your site -> Security -> Security Rules -> click Create Rule -> Custom Rules -> add a name of your choice -> in Field select URI -> in Value add: ', 'aiomatic-automatic-ai-content-writer') 
            . '<strong>/wp-json/aiomatic-mcp/v1/*</strong>' . esc_html__(' -> in Choose action select Skip -> select all checkboxes in WAF components to skip -> click More components to skip and also select all new checkboxes which appeared -> click Deploy', 'aiomatic-automatic-ai-content-writer'); ?></p>
<hr/>
<?php
if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }

    if ( is_plugin_active( 'aiomatic-extension-mcp-server/aiomatic-extension-mcp-server.php' ) ) 
    {
?>
            <form method="post" action="options.php">
                <?php settings_fields('aiomatic_mcp'); ?>
                <?php $opt = wp_parse_args($settings, [
                    'enable_sse' => '', 'bearer_token' => '', 'enable_debug' => '',
                    'tuned_core' => 'on', 'tuned_plugins' => '', 'tuned_themes' => '',
                    'dynamic_rest' => '', 'tuned_woocommerce' => '', 'session_memory' => '', 'embeddings_sse' => '', 'advanced_sse' => '', 'mcp_role' => 'admin', 'mcp_transport' => 'both', 'mcp_oauth' => 'on', 'mcp_activity_log' => 'on'
                ]); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="aiomatic-mcp-server-enabled"><?php echo esc_html__('Enable MCP server', 'aiomatic-automatic-ai-content-writer'); ?></label></th>
                        <td><input type="hidden" name="aiomatic_mcp_settings[enable_sse]" value="" /><label><input type="checkbox" id="aiomatic-mcp-server-enabled" name="aiomatic_mcp_settings[enable_sse]" aria-describedby="aiomatic-mcp-server-description" <?php checked($opt['enable_sse'], 'on'); ?> /> <?php echo esc_html__('Enable MCP client connections', 'aiomatic-automatic-ai-content-writer'); ?></label>
                            <p class="description" id="aiomatic-mcp-server-description"><?php echo esc_html__('Required for MCP tools and AI Automations events. The Transport setting below controls Streamable HTTP and legacy SSE.', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        </td>
                    </tr>
                    <tr class="mcp_sse">
                        <th scope="row"><?php echo esc_html__('Bearer Token', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <td><input type="text" name="aiomatic_mcp_settings[bearer_token]" value="<?php echo esc_attr($opt['bearer_token']); ?>" class="regular-text" /><p class="description"><?php echo esc_html__('MCP will be usable by using this Bearer Token. If you intend to use this in Claude Desktop, don\'t use any upper case letters in the token.', 'aiomatic-automatic-ai-content-writer'); ?></p></td>
                    </tr>
                    <tr class="mcp_sse">
                        <th scope="row"><?php echo esc_html__('Enable Debug Mode', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <td><input type="hidden" name="aiomatic_mcp_settings[enable_debug]" value="" /><label><input type="checkbox" name="aiomatic_mcp_settings[enable_debug]" <?php checked($opt['enable_debug'], 'on'); ?> /> <?php echo esc_html__('Enables debug mode - only use for local testing', 'aiomatic-automatic-ai-content-writer'); ?></label></td>
                    </tr>
                    <tr class="mcp_sse">
                        <th scope="row"><?php echo esc_html__('Transport', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <td>
                            <?php $mcp_transport = in_array($opt['mcp_transport'], ['legacy', 'streamable', 'both'], true) ? $opt['mcp_transport'] : 'both'; ?>
                            <select name="aiomatic_mcp_settings[mcp_transport]">
                                <option value="both" <?php selected($mcp_transport, 'both'); ?>><?php echo esc_html__('Both - legacy SSE and Streamable HTTP (recommended)', 'aiomatic-automatic-ai-content-writer'); ?></option>
                                <option value="streamable" <?php selected($mcp_transport, 'streamable'); ?>><?php echo esc_html__('Streamable HTTP only', 'aiomatic-automatic-ai-content-writer'); ?></option>
                                <option value="legacy" <?php selected($mcp_transport, 'legacy'); ?>><?php echo esc_html__('Legacy SSE only', 'aiomatic-automatic-ai-content-writer'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Streamable HTTP is what ChatGPT, Claude and Cursor connect to directly, with no relay program needed. Legacy SSE is the older two-URL transport. Keeping both means existing connections carry on working while new ones can use the modern endpoint.', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        </td>
                    </tr>
                    <tr class="mcp_sse">
                        <th scope="row"><?php echo esc_html__('Activity Log', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <td>
                            <input type="hidden" name="aiomatic_mcp_settings[mcp_activity_log]" value="" />
                            <label><input type="checkbox" name="aiomatic_mcp_settings[mcp_activity_log]" <?php checked($opt['mcp_activity_log'], 'on'); ?> /> <?php echo esc_html__('Record every tool call an AI makes', 'aiomatic-automatic-ai-content-writer'); ?></label>
                            <p class="description"><?php echo esc_html__('Keeps the last 200 calls, listed further down this page: which tool, by whom, how long it took and whether it worked. Other plugins can hook aiomatic_mcp_tool_called to send the same record somewhere permanent.', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        </td>
                    </tr>
                    <tr class="mcp_sse">
                        <th scope="row"><?php echo esc_html__('Sign-in (OAuth)', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <td>
                            <input type="hidden" name="aiomatic_mcp_settings[mcp_oauth]" value="" />
                            <label><input type="checkbox" name="aiomatic_mcp_settings[mcp_oauth]" <?php checked($opt['mcp_oauth'], 'on'); ?> /> <?php echo esc_html__('Let AI clients connect by signing in instead of pasting a token', 'aiomatic-automatic-ai-content-writer'); ?></label>
                            <p class="description"><?php echo esc_html__('Needed by claude.ai and Claude Desktop, which register themselves and send you to a WordPress sign-in page rather than accepting a token. Only administrators can approve a connection. The Bearer Token above keeps working either way, so leave this off unless a client asks for it.', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        </td>
                    </tr>
                    <tr class="mcp_sse">
                        <th scope="row"><?php echo esc_html__('Access Level', 'aiomatic-automatic-ai-content-writer'); ?></th>
                        <td>
                            <?php $mcp_role = in_array($opt['mcp_role'], ['admin', 'readwrite', 'readonly'], true) ? $opt['mcp_role'] : 'admin'; ?>
                            <select name="aiomatic_mcp_settings[mcp_role]">
                                <option value="admin" <?php selected($mcp_role, 'admin'); ?>><?php echo esc_html__('Administrator - every tool', 'aiomatic-automatic-ai-content-writer'); ?></option>
                                <option value="readwrite" <?php selected($mcp_role, 'readwrite'); ?>><?php echo esc_html__('Read & write - no deletions, users, options, plugins, themes or orders', 'aiomatic-automatic-ai-content-writer'); ?></option>
                                <option value="readonly" <?php selected($mcp_role, 'readonly'); ?>><?php echo esc_html__('Read only - no changes of any kind', 'aiomatic-automatic-ai-content-writer'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('How far the Bearer Token above reaches. Tools outside the chosen level are hidden from the AI and refused if called anyway. Administrators logged into this site are not affected.', 'aiomatic-automatic-ai-content-writer'); ?></p>
                        </td>
                    </tr>
                    <tr class="mcp_sse"><th colspan="2"><h3><?php echo esc_html__('Enabled Tool Packs', 'aiomatic-automatic-ai-content-writer'); ?></h3></th></tr>
                    <tr class="mcp_sse"><th scope="row"><?php echo esc_html__('Core WordPress Functionality', 'aiomatic-automatic-ai-content-writer'); ?></th><td><input type="hidden" name="aiomatic_mcp_settings[tuned_core]" value="" /><label><input type="checkbox" name="aiomatic_mcp_settings[tuned_core]" <?php checked($opt['tuned_core'], 'on'); ?> /> <?php echo esc_html__('Registers core WordPress tools (recommended)', 'aiomatic-automatic-ai-content-writer'); ?></label></td></tr>
                    <tr class="mcp_sse"><th scope="row"><?php echo esc_html__('Plugins Related Functionality', 'aiomatic-automatic-ai-content-writer'); ?></th><td><input type="hidden" name="aiomatic_mcp_settings[tuned_plugins]" value="" /><label><input type="checkbox" name="aiomatic_mcp_settings[tuned_plugins]" <?php checked($opt['tuned_plugins'], 'on'); ?> /> <?php echo esc_html__('Plugin oriented helpers (optional)', 'aiomatic-automatic-ai-content-writer'); ?></label></td></tr>
                    <tr class="mcp_sse"><th scope="row"><?php echo esc_html__('Themes Related Functionality', 'aiomatic-automatic-ai-content-writer'); ?></th><td><input type="hidden" name="aiomatic_mcp_settings[tuned_themes]" value="" /><label><input type="checkbox" name="aiomatic_mcp_settings[tuned_themes]" <?php checked($opt['tuned_themes'], 'on'); ?> /> <?php echo esc_html__('Theme oriented helpers (optional)', 'aiomatic-automatic-ai-content-writer'); ?></label></td></tr>
                    <tr class="mcp_sse"><th scope="row"><?php echo esc_html__('Dynamic REST API', 'aiomatic-automatic-ai-content-writer'); ?></th><td><input type="hidden" name="aiomatic_mcp_settings[dynamic_rest]" value="" /><label><input type="checkbox" name="aiomatic_mcp_settings[dynamic_rest]" <?php checked($opt['dynamic_rest'], 'on'); ?> /> <?php echo esc_html__('Generate CRUD tools for posts, pages, media (optional)', 'aiomatic-automatic-ai-content-writer'); ?></label></td></tr>
<tr class="mcp_sse">
    <th scope="row">
        <?php echo esc_html__( 'Agent Session Memory', 'aiomatic-automatic-ai-content-writer' ); ?>
    </th>
    <td>
        <input type="hidden" name="aiomatic_mcp_settings[session_memory]" value="" />
        <label>
            <input type="checkbox"
                   name="aiomatic_mcp_settings[session_memory]"
                   <?php checked( $opt['session_memory'], 'on' ); ?>
                   <?php disabled( ! function_exists( 'aiomatic_mcp_session_tools' ) ); ?> />
            <?php echo esc_html__( 'Allows the AI to memorize information for its processing (optional)', 'aiomatic-automatic-ai-content-writer' ); ?>
        </label>
        <?php if ( ! function_exists( 'aiomatic_mcp_session_tools' ) ) : ?>
            <p class="description">
                <?php echo esc_html__( 'Requires latest update of the "Aimogen Extension - MCP Server Creator" plugin.', 'aiomatic-automatic-ai-content-writer' ); ?>
            </p>
        <?php endif; ?>
    </td>
</tr>
<tr class="mcp_sse">
    <th scope="row">
        <?php echo esc_html__( 'Embeddings', 'aiomatic-automatic-ai-content-writer' ); ?>
    </th>
    <td>
        <input type="hidden" name="aiomatic_mcp_settings[embeddings_sse]" value="" />
        <label>
            <input type="checkbox"
                   name="aiomatic_mcp_settings[embeddings_sse]"
                   <?php checked( $opt['embeddings_sse'], 'on' ); ?>
                   <?php disabled( ! function_exists( 'aiomatic_mcp_embeddings_tools' ) ); ?> />
            <?php echo esc_html__( 'Allows access to the AI to internal embeddings (optional)', 'aiomatic-automatic-ai-content-writer' ); ?>
        </label>
        <?php if ( ! function_exists( 'aiomatic_mcp_embeddings_tools' ) ) : ?>
            <p class="description">
                <?php echo esc_html__( 'Requires latest update of the "Aimogen Extension - MCP Server Creator" plugin.', 'aiomatic-automatic-ai-content-writer' ); ?>
            </p>
        <?php endif; ?>
    </td>
</tr>
<tr class="mcp_sse">
    <th scope="row">
        <?php echo esc_html__( 'Advanced Functionality', 'aiomatic-automatic-ai-content-writer' ); ?>
    </th>
    <td>
        <input type="hidden" name="aiomatic_mcp_settings[advanced_sse]" value="" />
        <label>
            <input type="checkbox"
                   name="aiomatic_mcp_settings[advanced_sse]"
                   <?php checked( $opt['advanced_sse'], 'on' ); ?>
                   <?php disabled( ! function_exists( 'aiomatic_mcp_advanced_tools' ) ); ?> />
            <?php echo esc_html__( 'Access tools like: Amazon Product Details, Scrape Sites & RSS, Internet Search Result, YouTube Video Search & Captions, Send Email (optional)', 'aiomatic-automatic-ai-content-writer' ); ?>
        </label>
        <?php if ( ! function_exists( 'aiomatic_mcp_advanced_tools' ) ) : ?>
            <p class="description">
                <?php echo esc_html__( 'Requires latest update of the "Aimogen Extension - MCP Server Creator" plugin.', 'aiomatic-automatic-ai-content-writer' ); ?>
            </p>
        <?php endif; ?>
    </td>
</tr>
<tr class="mcp_sse">
    <th scope="row">
        <?php echo esc_html__( 'WooCommerce Related Functionality', 'aiomatic-automatic-ai-content-writer' ); ?>
    </th>
    <td>
        <input type="hidden" name="aiomatic_mcp_settings[tuned_woocommerce]" value="" />
        <label>
            <input type="checkbox"
                   name="aiomatic_mcp_settings[tuned_woocommerce]"
                   <?php checked( $opt['tuned_woocommerce'], 'on' ); ?>
                   <?php disabled( ! class_exists( 'WooCommerce' ) ); ?> />
            <?php echo esc_html__( 'WooCommerce oriented helpers (optional)', 'aiomatic-automatic-ai-content-writer' ); ?>
        </label>
        <?php if ( ! class_exists( 'WooCommerce' ) ) : ?>
            <p class="description">
                <?php echo esc_html__( 'Requires WooCommerce to be active.', 'aiomatic-automatic-ai-content-writer' ); ?>
            </p>
        <?php endif; ?>
    </td>
</tr>
<tr class="mcp_sse">
<td colspan="2">

            <h3><?php echo esc_html__('Endpoints', 'aiomatic-automatic-ai-content-writer'); ?></h3>
            <table class="widefat striped">
                <tbody>
                    <?php if ($mcp_transport !== 'legacy'): ?>
                    <tr>
  <th class="align-top pr-4 text-gray-600 font-medium">
    &nbsp;<?php echo esc_html__('Streamable HTTP Endpoint', 'aiomatic-automatic-ai-content-writer'); ?>
  </th>
  <td>
    <div class="flex items-center gap-2 bg-gray-100 rounded-xl px-3 py-2 border border-gray-200">
      <strong class="cr_red">
        <code class="text-sm text-gray-800 break-all">
        <?php echo esc_html($http_url); ?>
        </code>
      </strong>
      <button
        type="button"
        class="ml-2 inline-flex items-center px-2 py-1 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-gray-50 active:bg-gray-100 transition"
        onclick="navigator.clipboard.writeText('<?php echo esc_js($http_url); ?>'); this.innerText='Copied!'; setTimeout(() =&gt; this.innerText='Copy', 2000);"
      >
        <?php echo esc_html__('Copy', 'aiomatic-automatic-ai-content-writer'); ?>
      </button>
    </div>
    <p class="description"><?php echo esc_html__('Use this one for ChatGPT, Claude, Cursor and Claude Code - they connect to it directly, no relay program needed.', 'aiomatic-automatic-ai-content-writer'); ?></p>
  </td>
</tr>
                    <?php endif; ?>
                    <?php if ($mcp_transport !== 'streamable'): ?>
                    <tr>
  <th class="align-top pr-4 text-gray-600 font-medium">
    &nbsp;<?php echo esc_html__('SSE Endpoint (legacy)', 'aiomatic-automatic-ai-content-writer'); ?>
  </th>
  <td>
    <div class="flex items-center gap-2 bg-gray-100 rounded-xl px-3 py-2 border border-gray-200">
      <strong class="cr_red">
        <code class="text-sm text-gray-800 break-all">
        <?php echo esc_html($sse_url); ?>
        </code>
      </strong>
      <button 
        type="button"
        class="ml-2 inline-flex items-center px-2 py-1 text-xs font-medium text-gray-600 bg-white border border-gray-300 rounded-lg shadow-sm hover:bg-gray-50 active:bg-gray-100 transition"
        onclick="navigator.clipboard.writeText('<?php echo esc_js($sse_url); ?>'); this.innerText='Copied!'; setTimeout(() => this.innerText='Copy', 2000);"
      >
        <?php echo esc_html__('Copy', 'aiomatic-automatic-ai-content-writer'); ?>
      </button>
    </div>
  </td>
</tr>
                    <tr><th>&nbsp;<?php echo esc_html__('Messages Endpoint (legacy)', 'aiomatic-automatic-ai-content-writer'); ?></th><td><code><?php echo esc_html($messages_url); ?></code></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </td>
    </tr>
                </table>
                <?php do_action('aiomatic_mcp_settings_extra'); ?>
                <p class="crsubmit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p>
            </form>
            <?php do_action('aiomatic_mcp_settings_after'); ?>

            <h3><?php echo esc_html__('Connection Self-Test', 'aiomatic-automatic-ai-content-writer'); ?></h3>
            <p><?php echo esc_html__('Calls this site the way an AI client would and reports exactly what came back, including whether a firewall is answering instead of WordPress.', 'aiomatic-automatic-ai-content-writer'); ?></p>
            <p><button class="button button-primary" id="aiomatic-mcp-selftest"><?php echo esc_html__('Run Self-Test', 'aiomatic-automatic-ai-content-writer'); ?></button>
            <span id="aiomatic-mcp-selftest-status" style="margin-left:8px;"></span></p>
            <div id="aiomatic-mcp-selftest-out"></div>

            <h3><?php echo esc_html__('Recent AI Activity', 'aiomatic-automatic-ai-content-writer'); ?></h3>
            <?php
            $mcp_activity = get_option('aiomatic_mcp_activity', []);
            if (!is_array($mcp_activity)) { $mcp_activity = []; }
            $mcp_activity = array_reverse($mcp_activity);
            if (empty($mcp_activity)) {
                echo '<p>' . esc_html__('No tool calls recorded yet.', 'aiomatic-automatic-ai-content-writer') . '</p>';
            } else {
            ?>
            <p><button type="button" class="button" id="aiomatic-mcp-clear-activity"><?php echo esc_html__('Clear Log', 'aiomatic-automatic-ai-content-writer'); ?></button>
            <span id="aiomatic-mcp-clear-status" style="margin-left:8px;"></span></p>
            <table class="widefat striped" style="max-width:1000px;">
                <thead><tr>
                    <th><?php echo esc_html__('When', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <th><?php echo esc_html__('Tool', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <th><?php echo esc_html__('Result', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <th><?php echo esc_html__('Took', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <th><?php echo esc_html__('Via', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <th><?php echo esc_html__('User', 'aiomatic-automatic-ai-content-writer'); ?></th>
                    <th><?php echo esc_html__('Arguments', 'aiomatic-automatic-ai-content-writer'); ?></th>
                </tr></thead>
                <tbody>
                <?php foreach (array_slice($mcp_activity, 0, 100) as $mcp_row) :
                    $mcp_state = isset($mcp_row['status']) ? $mcp_row['status'] : 'error';
                    $mcp_colour = $mcp_state === 'success' ? '#008a20' : ($mcp_state === 'denied' ? '#996800' : '#d63638');
                    $mcp_user = !empty($mcp_row['user_id']) ? get_userdata($mcp_row['user_id']) : null;
                ?>
                    <tr>
                        <td><?php echo esc_html(date_i18n('Y-m-d H:i:s', (int) (isset($mcp_row['time']) ? $mcp_row['time'] : 0))); ?></td>
                        <td><code><?php echo esc_html(isset($mcp_row['tool']) ? $mcp_row['tool'] : ''); ?></code></td>
                        <td style="color:<?php echo esc_attr($mcp_colour); ?>;">
                            <?php echo esc_html($mcp_state); ?>
                            <?php if (!empty($mcp_row['error'])) : ?>
                                <br /><small><?php echo esc_html($mcp_row['error']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html((int) (isset($mcp_row['duration_ms']) ? $mcp_row['duration_ms'] : 0)); ?> ms</td>
                        <td><?php echo esc_html(isset($mcp_row['auth']) ? $mcp_row['auth'] : '-'); ?></td>
                        <td><?php echo esc_html($mcp_user ? $mcp_user->user_login : '-'); ?></td>
                        <td style="word-break:break-all;"><small><?php echo esc_html(isset($mcp_row['args']) ? (string) $mcp_row['args'] : ''); ?></small></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php } ?>

            <h3><?php echo esc_html__('Debug', 'aiomatic-automatic-ai-content-writer'); ?></h3>
            <p><button class="button" id="aiomatic-mcp-refresh"><?php echo esc_html__('Refresh Function List', 'aiomatic-automatic-ai-content-writer'); ?></button>
            <span id="aiomatic-mcp-refresh-status" style="margin-left:6px;"></span></p>
            <pre id="aiomatic-mcp-functions" style="max-height:380px;overflow:auto;background:#111;color:#eee;padding:12px;border-radius:8px;"></pre>
<?php
    }
    else
    {
?>
        <div style="padding:20px; border-radius:12px; background:#f9f9f9; border:1px solid #ddd; text-align:center; max-width:600px; margin:20px auto;">
            <h2 style="margin-bottom:10px; color:#333;">
                <?php echo esc_html__('MCP Extension Required', 'aiomatic-automatic-ai-content-writer'); ?>
            </h2>
            <p style="margin-bottom:15px; color:#555; font-size:15px;">
                <?php echo esc_html__('This functionality is only available if the Aimogen MCP Server Extension plugin is active.', 'aiomatic-automatic-ai-content-writer'); ?>
            </p>
            <a href="https://wpbay.com/product/aiomatic-extension-mcp-server-creator/" target="_blank" 
               style="display:inline-block; padding:10px 20px; background:#0073aa; color:#fff; text-decoration:none; border-radius:6px; font-weight:bold;">
                <?php echo esc_html__('Purchase Plugin', 'aiomatic-automatic-ai-content-writer'); ?>
            </a>
        </div>
<?php
    }
?>
        </div>
<?php
$aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);

$aiomatic_enabled = isset($aiomatic_Main_Settings['aiomatic_enabled']) ? $aiomatic_Main_Settings['aiomatic_enabled'] : '';
$responses_api    = isset($aiomatic_Main_Settings['responses_api']) ? $aiomatic_Main_Settings['responses_api'] : '';
$api_selector     = isset($aiomatic_Main_Settings['api_selector']) ? $aiomatic_Main_Settings['api_selector'] : 'openai';

$is_aiomaticapi = false;
$token = '';
if (!empty($aiomatic_Main_Settings['app_id'])) {
    $appids = preg_split('/\r\n|\r|\n/', trim($aiomatic_Main_Settings['app_id']));
    $appids = array_filter($appids);
    if (count($appids) == 1) {
        $token = $appids[array_rand($appids)];
        $token = apply_filters('aimogen_openai_api_key', $token);$token = apply_filters('aiomatic_openai_api_key', $token);
        if (aiomatic_is_aiomaticapi_key($token)) {
            $call_count = get_transient('aiomaticapi_tokens');
            if ($token != '' && $call_count !== false) {
                $is_aiomaticapi = true;
            }
        }
    }
}
?>
        <div id="tab-2" class="tab-content" style="display:none">
            <br/>
            <h3><?php echo esc_html__('MCP Server Connections', 'aiomatic-automatic-ai-content-writer'); ?></h3>
<?php
$mcp_client_openai = ($aiomatic_enabled === 'on' && $responses_api === 'on' && $api_selector === 'openai' && !$is_aiomaticapi);
// The Anthropic path builds its mcp_servers list from this same option, but it
// is reached by model name using the Claude key, so none of the OpenAI
// selector settings above apply to it.
$mcp_client_claude = ($aiomatic_enabled === 'on' && !empty($aiomatic_Main_Settings['app_id_claude']));
if ($mcp_client_openai || $mcp_client_claude): ?>
            <p><?php echo esc_html__('Configure external MCP servers here. These servers extend AI capabilities by providing tools and functions that AI models can call during conversations.', 'aiomatic-automatic-ai-content-writer'); ?></p>
<hr/><br/>
            <div class="mcp-servers-container">
                <button type="button" class="button button-primary" id="add-mcp-server"><?php echo esc_html__('New MCP Server Connection', 'aiomatic-automatic-ai-content-writer'); ?></button>
                <div id="mcp-server-list" style="margin-top:20px;">
                    <?php
                    $mcp_servers = get_option('aiomatic_mcp_servers', array());
                    if (!empty($mcp_servers)) {
                        foreach ($mcp_servers as $id => $server) {
                            ?>
                            <div class="mcp-server-entry" data-id="<?php echo esc_attr($id); ?>" style="border:1px solid #ccd0d4;padding:12px;margin-bottom:12px;border-radius:6px;background:#fff;">
                                <h4><?php echo esc_html($server['name']); ?></h4>
                                <?php if (!empty($server['description'])): ?>
                                    <p><strong><?php echo esc_html__('Description:', 'aiomatic-automatic-ai-content-writer'); ?></strong> <span class="descr"><?php echo esc_html($server['description']); ?></span></p>
                                <?php endif; ?>
                                <p>
  <strong><?php echo esc_html__('URL:', 'aiomatic-automatic-ai-content-writer'); ?></strong>
  <?php echo esc_html($server['url']); ?>
  <span class="srv-url" style="display:none;"><?php echo esc_attr($server['url']); ?></span>
</p>
                                <p>
    <strong><?php echo esc_html__('Token:', 'aiomatic-automatic-ai-content-writer'); ?></strong>
    <?php if (!empty($server['token'])): ?>
        ********
        <span class="has-tkn" style="display:none;">1</span>
    <?php else: ?>
        -
    <?php endif; ?>
</p>
<p>
    <strong><?php echo esc_html__('Enabled Globally:', 'aiomatic-automatic-ai-content-writer'); ?></strong>
    <?php echo !empty($server['global']) && $server['global'] === 'on' ? esc_html__('Yes', 'aiomatic-automatic-ai-content-writer') : esc_html__('No', 'aiomatic-automatic-ai-content-writer'); ?>
    <span class="srv-global" style="display:none;"><?php echo !empty($server['global']) && $server['global'] === 'on' ? 'on' : 'off'; ?></span>
</p>
                                <p><strong><?php echo esc_html__('Server ID:', 'aiomatic-automatic-ai-content-writer'); ?></strong> <?php echo esc_html($id); ?></p>
                                <button type="button" class="button edit-mcp-server"><?php echo esc_html__('Edit', 'aiomatic-automatic-ai-content-writer'); ?></button>
                                <button type="button" class="button delete-mcp-server" onclick="unsaved = false;"><?php echo esc_html__('Delete', 'aiomatic-automatic-ai-content-writer'); ?></button>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p>' . esc_html__('No MCP servers configured yet.', 'aiomatic-automatic-ai-content-writer') . '</p>';
                    }
                    ?>
                </div>
            </div>

            <!-- Add/Edit form -->
            <div id="mcp-server-form" style="display:none; margin-top:20px; background:#f9f9f9; padding:15px; border:1px solid #ccd0d4; border-radius:6px;">
                <h4><?php echo esc_html__('Add / Edit MCP Server', 'aiomatic-automatic-ai-content-writer'); ?></h4>
                <table class="form-table">
                    <tr>
                        <th><label for="mcp-server-name"><?php echo esc_html__('Name', 'aiomatic-automatic-ai-content-writer'); ?></label></th>
                        <td>
                            <input type="text" id="mcp-server-name" class="regular-text" placeholder="Your MCP Server Name" />
                            <input type="hidden" id="mcp-server-id" />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="mcp-server-description"><?php echo esc_html__('Description', 'aiomatic-automatic-ai-content-writer'); ?></label></th>
                        <td>
                            <textarea id="mcp-server-description" class="large-text" rows="3" placeholder="Short description of what this server does"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="mcp-server-url"><?php echo esc_html__('URL', 'aiomatic-automatic-ai-content-writer'); ?></label></th>
                        <td><input type="text" id="mcp-server-url" class="regular-text" placeholder="Example: https://dmcp-server.deno.dev/sse" /></td>
                    </tr>
                    <tr>
                        <th><label for="mcp-server-token"><?php echo esc_html__('Token', 'aiomatic-automatic-ai-content-writer'); ?></label></th>
                        <td><input type="password" id="mcp-server-token" class="regular-text" placeholder="Bearer token for authentication (optional)" /></td>
                    </tr>
                    <tr>
                        <th><label for="mcp-server-global"><?php echo esc_html__('Enable Globally', 'aiomatic-automatic-ai-content-writer'); ?></label></th>
                        <td><input type="checkbox" id="mcp-server-global" /></td>
                    </tr>
                </table>
                <p>
                    <button type="button" class="button button-primary" onclick="unsaved = false;" id="save-mcp-server"><?php echo esc_html__('Save Server Connection', 'aiomatic-automatic-ai-content-writer'); ?></button>
                    <button type="button" class="button" id="cancel-mcp-server"><?php echo esc_html__('Cancel', 'aiomatic-automatic-ai-content-writer'); ?></button>
                </p>
            </div>
            <?php else: ?>
        <div style="margin:20px 0; padding:20px; border:1px solid #ccd0d4; border-radius:8px; background:#fff3cd; color:#856404;">
            <strong><?php echo esc_html__('MCP Servers Disabled', 'aiomatic-automatic-ai-content-writer'); ?></strong>
            <p><?php echo esc_html__('This functionality needs Aimogen Pro enabled, plus either the Responses API turned on with the API selector set to OpenAI and no AimogenAPI API key, or an Anthropic API key configured. Please adjust your settings to enable MCP server connections.', 'aiomatic-automatic-ai-content-writer'); ?></p>
        </div>
    <?php endif; ?>
        </div>
</div>
</section>
        </div>
</div>
<script>
jQuery(document).ready(function($) {
    function toggleMcpSse() {
        const serverEnabled = $('input[name="aiomatic_mcp_settings[enable_sse]"]').is(':checked');
        if (serverEnabled) {
            $('.mcp_sse').show();
        } else {
            $('.mcp_sse').hide();
        }
        const events = $('#aimogen-mcp-events-enabled');
        events.prop('disabled', !serverEnabled);
        // Disabled fields are not submitted. Preserve the selected preference
        // while the server is off instead of clearing existing subscriptions.
        $('#aimogen-mcp-events-enabled-fallback').val(!serverEnabled && events.is(':checked') ? '1' : '0');
        $('#aimogen-mcp-events-server-warning').prop('hidden', serverEnabled || !events.is(':checked'));
    }

    toggleMcpSse();

    $(document).on('change', 'input[name="aiomatic_mcp_settings[enable_sse]"], #aimogen-mcp-events-enabled', function() {
        toggleMcpSse();
    });
});
(function(){
    const tabs = document.querySelectorAll('.nav-tab-wrapper .nav-tab');
    const contents = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => tab.addEventListener('click', function(e){
        e.preventDefault();
        tabs.forEach(t => t.classList.remove('nav-tab-active'));
        this.classList.add('nav-tab-active');
        contents.forEach(c => c.style.display = 'none');
        const target = document.querySelector(this.getAttribute('href'));
        if (target) target.style.display = 'block';
    }));
    const stBtn = document.getElementById('aiomatic-mcp-selftest');
    const mcpNonce = '<?php echo esc_js(wp_create_nonce('aiomatic_mcp_nonce')); ?>';
    stBtn && stBtn.addEventListener('click', async function (ev) {
        ev.preventDefault();
        const status = document.getElementById('aiomatic-mcp-selftest-status');
        const out = document.getElementById('aiomatic-mcp-selftest-out');
        status.textContent = 'Running...';
        out.innerHTML = '';
        try {
            const res = await fetch(ajaxurl, {
                method: 'POST',
                body: new URLSearchParams({ action: 'aiomatic_mcp_self_test', _ajax_nonce: mcpNonce })
            });
            const json = await res.json();
            if (!json.success) {
                throw new Error((json.data && json.data.message) || 'Request failed');
            }
            const colour = { pass: '#008a20', warn: '#996800', fail: '#d63638' };
            const mark = { pass: 'OK', warn: 'CHECK', fail: 'FAILED' };
            const table = document.createElement('table');
            table.className = 'widefat striped';
            table.style.maxWidth = '900px';
            const tbody = document.createElement('tbody');
            json.data.checks.forEach(function (c) {
                const tr = document.createElement('tr');
                const tdState = document.createElement('td');
                tdState.style.color = colour[c.state] || '#50575e';
                tdState.style.fontWeight = '600';
                tdState.style.whiteSpace = 'nowrap';
                tdState.textContent = mark[c.state] || c.state;
                const tdBody = document.createElement('td');
                const strong = document.createElement('strong');
                strong.textContent = c.label;
                tdBody.appendChild(strong);
                const detail = document.createElement('div');
                detail.textContent = c.detail;
                tdBody.appendChild(detail);
                if (c.fix) {
                    const fix = document.createElement('div');
                    fix.style.marginTop = '4px';
                    fix.style.color = '#996800';
                    fix.textContent = 'Fix: ' + c.fix;
                    tdBody.appendChild(fix);
                }
                tr.appendChild(tdState);
                tr.appendChild(tdBody);
                tbody.appendChild(tr);
            });
            table.appendChild(tbody);
            out.appendChild(table);
            const failed = json.data.checks.filter(function (c) { return c.state === 'fail'; }).length;
            status.textContent = failed ? (failed + ' problem(s) found') : 'All checks passed';
        } catch (err) {
            status.textContent = 'Error';
            out.textContent = err.message;
        }
    });

    const clrBtn = document.getElementById('aiomatic-mcp-clear-activity');
    clrBtn && clrBtn.addEventListener('click', async function () {
        const status = document.getElementById('aiomatic-mcp-clear-status');
        status.textContent = 'Clearing...';
        try {
            const res = await fetch(ajaxurl, {
                method: 'POST',
                body: new URLSearchParams({ action: 'aiomatic_mcp_clear_activity', _ajax_nonce: mcpNonce })
            });
            const json = await res.json();
            if (json.success) { location.reload(); }
            else { status.textContent = 'Failed'; }
        } catch (err) {
            status.textContent = err.message;
        }
    });

    const btn = document.getElementById('aiomatic-mcp-refresh');
    if (btn) {
        btn.addEventListener('click', async function(){
            const pre = document.getElementById('aiomatic-mcp-functions');
            const status = document.getElementById('aiomatic-mcp-refresh-status');
            status.textContent = 'Loading...';
            try {
                const res = await fetch('<?php echo esc_js($tools_url); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                            'Authorization': 'Bearer <?php echo esc_js($bearer_token); ?>'
                    }
                });
                if (!res.ok) throw new Error("HTTP " + res.status);
                const json = await res.json();
                pre.textContent = JSON.stringify(json, null, 2);
                status.textContent = 'Done';
            } catch(e){
                status.textContent = 'Error';
                pre.textContent = e.message;
            }
        });
    }
    const addBtn = document.getElementById('add-mcp-server');
    const form = document.getElementById('mcp-server-form');
    const saveBtn = document.getElementById('save-mcp-server');
    const cancelBtn = document.getElementById('cancel-mcp-server');

    const idInput = document.getElementById('mcp-server-id'); 
    const nameInput = document.getElementById('mcp-server-name');
    const descInput = document.getElementById('mcp-server-description');
    const urlInput = document.getElementById('mcp-server-url');
    const tokenInput = document.getElementById('mcp-server-token');
    const enableGlobal = document.getElementById('mcp-server-global');

    addBtn?.addEventListener('click', () => {
        form.style.display = 'block';
        idInput.value = '';
        nameInput.value = '';
        urlInput.value = '';
        descInput.value = '';
        tokenInput.value = '';
        tokenInput.placeholder = 'Bearer token for authentication (optional)';
        enableGlobal.checked = false;
    });

    cancelBtn?.addEventListener('click', () => { 
        form.style.display = 'none'; 
    });

    saveBtn?.addEventListener('click', async () => {
        const name = nameInput.value.trim();
        const url = urlInput.value.trim();
        const token = tokenInput.value.trim();
        const description = descInput.value.trim();
        const id = idInput.value || 'srv-' + Math.random().toString(36).substr(2, 9);
        const globalEnabled = enableGlobal.checked ? 'on' : 'off';

        if (!name) {
            alert('Please enter a server name.');
            return;
        }
        if (!url) {
            alert('Please enter a server URL.');
            return;
        }
        if (!/^http.+/i.test(url)) {
            alert('The URL must start with http');
            return;
        }

        const data = {
            action: 'aiomatic_save_mcp_server',
            id: id,
            name: name,
            description: description,
            url: url,
            global: globalEnabled,
            token: token,
            _ajax_nonce: '<?php echo wp_create_nonce("aiomatic_mcp_nonce"); ?>'
        };

        try {
            const res = await fetch(ajaxurl, {
                method: 'POST',
                body: new URLSearchParams(data)
            });
            const json = await res.json();
            if (!json.success) {
                alert('Error saving MCP server.');
            } else {
                location.reload();
            }
        } catch (e) {
            alert('Request failed: ' + e.message);
        }
    });

    document.querySelectorAll('.edit-mcp-server').forEach(btn =>
        btn.addEventListener('click', e => {
            const entry = e.target.closest('.mcp-server-entry');
            idInput.value = entry.dataset.id;
            nameInput.value = entry.querySelector('h4').textContent.trim();
            const descrSpan = entry.querySelector('.descr');
            descInput.value = descrSpan ? descrSpan.textContent.trim() : '';

            const urlSpan = entry.querySelector('.srv-url');
            urlInput.value = urlSpan ? urlSpan.textContent.trim() : '';

            // The saved token is never rendered into the page, so the field
            // starts empty and blank means "keep whatever is stored".
            const hasTkn = entry.querySelector('.has-tkn');
            tokenInput.value = '';
            tokenInput.placeholder = hasTkn
                ? 'Leave blank to keep the saved token'
                : 'Bearer token for authentication (optional)';
            
            const globalSpan = entry.querySelector('.srv-global');
            enableGlobal.checked = globalSpan && globalSpan.textContent.trim() === 'on';

            form.style.display = 'block';
        })
    );

    document.querySelectorAll('.delete-mcp-server').forEach(btn => btn.addEventListener('click', async e => {
        if (!confirm('Delete this server?')) return;
        const entry = e.target.closest('.mcp-server-entry');
        try {
            const res = await fetch(ajaxurl, {
                method: 'POST',
                body: new URLSearchParams({
                    action: 'aiomatic_delete_mcp_server',
                    id: entry.dataset.id,
                    _ajax_nonce: '<?php echo wp_create_nonce("aiomatic_mcp_nonce"); ?>'
                })
            });
            const json = await res.json();
            if (json.success) {
                location.reload();
            } else {
                alert('Error deleting server.');
            }
        } catch (e) {
            alert('Delete failed: ' + e.message);
        }
    }));

})();
</script>
<?php
}
?>
