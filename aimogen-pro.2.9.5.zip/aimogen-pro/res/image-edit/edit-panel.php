<?php
if ( ! defined ( 'ABSPATH' ) ) {
	die ( 'Not allowed' );
}
global $aiomatic_edit_image_id;
$attachment_id = intval( $aiomatic_edit_image_id );
$thumb = wp_get_attachment_image_src( $attachment_id, 'medium' );
$full = wp_get_attachment_url( $attachment_id );
$title = get_the_title( $attachment_id );
?>
<div id="aiomatic-edit-wrapper">
	<div class="media-modal wp-core-ui">
		<button type="button" class="media-modal-close" onclick="aiomaticCancelCropImage();">
			<span class="media-modal-icon">
				<span class="screen-reader-text"><?php esc_html_e( 'Close panel', 'aiomatic-automatic-ai-content-writer' ); ?></span>
			</span>
		</button>
		<div class="media-modal-content">
			<div class="media-frame wp-core-ui">
				<div class="media-frame-title"><h1><?php esc_html_e( 'Aimogen - Stable Diffusion Image Edit', 'aiomatic-automatic-ai-content-writer' ); ?></h1></div>
				<div class="media-frame-content" style="padding:20px;">
					<div style="display:flex;gap:24px;flex-wrap:wrap;">
						<div style="flex:0 0 220px;">
							<?php if ( ! empty( $thumb[0] ) ) : ?>
								<img src="<?php echo esc_url( $thumb[0] ); ?>" alt="" style="max-width:100%;height:auto;border:1px solid #ccd0d4;" />
							<?php endif; ?>
							<p><strong><?php echo esc_html( $title ); ?></strong></p>
							<p><a href="<?php echo esc_url( $full ); ?>" target="_blank"><?php esc_html_e( 'Open original', 'aiomatic-automatic-ai-content-writer' ); ?></a></p>
						</div>
						<div style="flex:1 1 420px;">
							<p>
								<label for="aiomatic_edit_mode"><strong><?php esc_html_e( 'Edit mode', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<select id="aiomatic_edit_mode" style="width:100%;max-width:100%;">
									<option value="remove-background"><?php esc_html_e( 'Remove Background', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="search-and-replace"><?php esc_html_e( 'Search and Replace', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="search-and-recolor"><?php esc_html_e( 'Search and Recolor', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="outpaint"><?php esc_html_e( 'Outpaint (extend edges)', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="inpaint"><?php esc_html_e( 'Inpaint (mask + prompt)', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="erase"><?php esc_html_e( 'Erase (mask)', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="replace-background"><?php esc_html_e( 'Replace Background & Relight (async)', 'aiomatic-automatic-ai-content-writer' ); ?></option>
								</select>
							</p>

							<p class="aiomatic-edit-field aiomatic-edit-prompt">
								<label for="aiomatic_edit_prompt"><strong><?php esc_html_e( 'Prompt', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<textarea id="aiomatic_edit_prompt" rows="3" style="width:100%;max-width:100%;" placeholder="<?php esc_attr_e( 'Describe the desired result', 'aiomatic-automatic-ai-content-writer' ); ?>"></textarea>
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-search">
								<label for="aiomatic_edit_search_prompt"><strong><?php esc_html_e( 'Search prompt (object to replace)', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="text" id="aiomatic_edit_search_prompt" style="width:100%;max-width:100%;" value="" />
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-select">
								<label for="aiomatic_edit_select_prompt"><strong><?php esc_html_e( 'Select prompt (object to recolor)', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="text" id="aiomatic_edit_select_prompt" style="width:100%;max-width:100%;" value="" />
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-background">
								<label for="aiomatic_edit_background_prompt"><strong><?php esc_html_e( 'Background prompt', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<textarea id="aiomatic_edit_background_prompt" rows="2" style="width:100%;max-width:100%;" placeholder="<?php esc_attr_e( 'Describe the new background', 'aiomatic-automatic-ai-content-writer' ); ?>"></textarea>
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-negative">
								<label for="aiomatic_edit_negative"><strong><?php esc_html_e( 'Negative prompt (optional)', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="text" id="aiomatic_edit_negative" style="width:100%;max-width:100%;" value="" />
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-outpaint">
								<label><strong><?php esc_html_e( 'Outpaint pixels', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<span style="display:inline-block;margin:4px 8px 4px 0;">Left <input type="number" id="aiomatic_edit_left" min="0" max="2000" value="0" style="width:80px;" /></span>
								<span style="display:inline-block;margin:4px 8px 4px 0;">Right <input type="number" id="aiomatic_edit_right" min="0" max="2000" value="256" style="width:80px;" /></span>
								<span style="display:inline-block;margin:4px 8px 4px 0;">Up <input type="number" id="aiomatic_edit_up" min="0" max="2000" value="0" style="width:80px;" /></span>
								<span style="display:inline-block;margin:4px 8px 4px 0;">Down <input type="number" id="aiomatic_edit_down" min="0" max="2000" value="0" style="width:80px;" /></span>
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-mask">
								<label for="aiomatic_edit_mask"><strong><?php esc_html_e( 'Mask image (optional)', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="file" id="aiomatic_edit_mask" accept="image/png,image/jpeg,image/webp" />
								<small><?php esc_html_e( 'White = edit area, black = keep. If omitted, alpha channel is used when available.', 'aiomatic-automatic-ai-content-writer' ); ?></small>
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-grow">
								<label for="aiomatic_edit_grow_mask"><strong><?php esc_html_e( 'Grow mask (px)', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="number" id="aiomatic_edit_grow_mask" min="0" max="100" value="5" style="width:100px;" />
							</p>
							<p class="aiomatic-edit-field aiomatic-edit-creativity">
								<label for="aiomatic_edit_creativity"><strong><?php esc_html_e( 'Creativity', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<input type="number" id="aiomatic_edit_creativity" min="0" max="1" step="0.05" value="0.5" style="width:100px;" />
							</p>
							<p>
								<label for="aiomatic_edit_format"><strong><?php esc_html_e( 'Output format', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<select id="aiomatic_edit_format">
									<option value="png">PNG</option>
									<option value="webp">WEBP</option>
									<option value="jpeg">JPEG</option>
								</select>
							</p>
							<p>
								<label for="aiomatic_edit_save_mode"><strong><?php esc_html_e( 'Save result as', 'aiomatic-automatic-ai-content-writer' ); ?></strong></label><br />
								<select id="aiomatic_edit_save_mode">
									<option value="new"><?php esc_html_e( 'New media library item', 'aiomatic-automatic-ai-content-writer' ); ?></option>
									<option value="replace"><?php esc_html_e( 'Replace original file', 'aiomatic-automatic-ai-content-writer' ); ?></option>
								</select>
							</p>
							<p>
								<button type="button" class="button button-primary" id="aiomatic_run_edit" data-attachment-id="<?php echo esc_attr( $attachment_id ); ?>">
									<?php esc_html_e( 'Edit Image', 'aiomatic-automatic-ai-content-writer' ); ?>
								</button>
								<span id="aiomatic_edit_status" style="margin-left:10px;"></span>
							</p>
							<div id="aiomatic_edit_result" style="display:none;">
								<h3><?php esc_html_e( 'Result', 'aiomatic-automatic-ai-content-writer' ); ?></h3>
								<img id="aiomatic_edit_result_img" src="" alt="" style="max-width:100%;height:auto;border:1px solid #ccd0d4;" />
								<p><a id="aiomatic_edit_result_link" href="#" target="_blank"><?php esc_html_e( 'Open edited image', 'aiomatic-automatic-ai-content-writer' ); ?></a></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
jQuery(function($){
	function syncEditFields(){
		var mode = $('#aiomatic_edit_mode').val();
		$('.aiomatic-edit-field').hide();
		if (mode === 'remove-background') {
			// no extra fields
		} else if (mode === 'search-and-replace') {
			$('.aiomatic-edit-prompt,.aiomatic-edit-search,.aiomatic-edit-negative,.aiomatic-edit-grow').show();
		} else if (mode === 'search-and-recolor') {
			$('.aiomatic-edit-prompt,.aiomatic-edit-select,.aiomatic-edit-negative,.aiomatic-edit-grow').show();
		} else if (mode === 'outpaint') {
			$('.aiomatic-edit-prompt,.aiomatic-edit-outpaint,.aiomatic-edit-creativity').show();
		} else if (mode === 'inpaint') {
			$('.aiomatic-edit-prompt,.aiomatic-edit-mask,.aiomatic-edit-negative,.aiomatic-edit-grow').show();
		} else if (mode === 'erase') {
			$('.aiomatic-edit-mask,.aiomatic-edit-grow').show();
		} else if (mode === 'replace-background') {
			$('.aiomatic-edit-background,.aiomatic-edit-prompt,.aiomatic-edit-negative').show();
		}
		if (mode === 'remove-background') {
			$('#aiomatic_edit_format option[value="jpeg"]').prop('disabled', true);
			if ($('#aiomatic_edit_format').val() === 'jpeg') {
				$('#aiomatic_edit_format').val('png');
			}
		} else {
			$('#aiomatic_edit_format option[value="jpeg"]').prop('disabled', false);
		}
	}
	$('#aiomatic_edit_mode').on('change', syncEditFields);
	syncEditFields();

	$('#aiomatic_run_edit').on('click', function(){
		var $btn = $(this);
		var mode = $('#aiomatic_edit_mode').val();
		var prompt = $('#aiomatic_edit_prompt').val();
		if ((mode === 'search-and-replace' || mode === 'search-and-recolor' || mode === 'inpaint') && !$.trim(prompt)) {
			alert(<?php echo wp_json_encode( __( 'Please enter a prompt for this edit mode.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
			return;
		}
		if (mode === 'search-and-replace' && !$.trim($('#aiomatic_edit_search_prompt').val())) {
			alert(<?php echo wp_json_encode( __( 'Please enter a search prompt (object to replace).', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
			return;
		}
		if (mode === 'search-and-recolor' && !$.trim($('#aiomatic_edit_select_prompt').val())) {
			alert(<?php echo wp_json_encode( __( 'Please enter a select prompt (object to recolor).', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
			return;
		}
		if (mode === 'outpaint') {
			var total = parseInt($('#aiomatic_edit_left').val()||0,10)+parseInt($('#aiomatic_edit_right').val()||0,10)+parseInt($('#aiomatic_edit_up').val()||0,10)+parseInt($('#aiomatic_edit_down').val()||0,10);
			if (total <= 0) {
				alert(<?php echo wp_json_encode( __( 'Set at least one outpaint direction above 0.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
				return;
			}
		}
		if (mode === 'replace-background' && !$.trim($('#aiomatic_edit_background_prompt').val())) {
			alert(<?php echo wp_json_encode( __( 'Please enter a background prompt.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
			return;
		}

		var fd = new FormData();
		fd.append('action', 'aiomatic_edit_image_ajax');
		fd.append('nonce', (typeof aiomatic_media_object !== 'undefined' ? aiomatic_media_object.nonce : ''));
		fd.append('attachment_id', $btn.data('attachment-id'));
		fd.append('mode', mode);
		fd.append('prompt', prompt);
		fd.append('negative_prompt', $('#aiomatic_edit_negative').val());
		fd.append('search_prompt', $('#aiomatic_edit_search_prompt').val());
		fd.append('select_prompt', $('#aiomatic_edit_select_prompt').val());
		fd.append('background_prompt', $('#aiomatic_edit_background_prompt').val());
		fd.append('grow_mask', $('#aiomatic_edit_grow_mask').val());
		fd.append('creativity', $('#aiomatic_edit_creativity').val());
		fd.append('left', $('#aiomatic_edit_left').val());
		fd.append('right', $('#aiomatic_edit_right').val());
		fd.append('up', $('#aiomatic_edit_up').val());
		fd.append('down', $('#aiomatic_edit_down').val());
		fd.append('output_format', $('#aiomatic_edit_format').val());
		fd.append('save_mode', $('#aiomatic_edit_save_mode').val());
		var maskFile = $('#aiomatic_edit_mask')[0].files[0];
		if (maskFile) {
			fd.append('mask', maskFile);
		}

		$btn.prop('disabled', true);
		$('#aiomatic_edit_status').text(<?php echo wp_json_encode( __( 'Editing… this may take a while for async modes.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
		$('#aiomatic_edit_result').hide();

		$.ajax({
			url: ajaxurl,
			type: 'POST',
			data: fd,
			processData: false,
			contentType: false,
			timeout: (mode === 'replace-background' ? 660000 : 180000)
		}).done(function(res){
			if (res && res.status === 'success') {
				$('#aiomatic_edit_status').text(res.msg || <?php echo wp_json_encode( __( 'Done.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
				$('#aiomatic_edit_result_img').attr('src', res.url);
				$('#aiomatic_edit_result_link').attr('href', res.url);
				$('#aiomatic_edit_result').show();
			} else {
				$('#aiomatic_edit_status').text('');
				alert((res && res.msg) ? res.msg : <?php echo wp_json_encode( __( 'Edit failed.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
			}
		}).fail(function(){
			$('#aiomatic_edit_status').text('');
			alert(<?php echo wp_json_encode( __( 'Request failed. Please try again.', 'aiomatic-automatic-ai-content-writer' ) ); ?>);
		}).always(function(){
			$btn.prop('disabled', false);
		});
	});
});
</script>
