<?php
defined('ABSPATH') or die(); 
function aiomatic_admin_settings()
{
   $plugin = plugin_basename(__FILE__);
   $plugin_slug = explode('/', $plugin);
   $plugin_slug = $plugin_slug[0];
   $uoptions = array();
   $is_activated = aiomatic_is_activated($plugin_slug, $uoptions);
   if($is_activated === true)
   {
?>
   <div class="verification-container">
     <div class="help-section">
       <div class="help-icon">
         <span class="dashicons dashicons-editor-help"></span>
       </div>
       <div class="help-text">
         <?php
           echo sprintf( wp_kses( __( 'The plugin is registered correctly. You can revoke your license here.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url_raw( '//coderevolution.ro/knowledge-base/faq/how-do-i-find-my-items-purchase-code-for-plugin-license-activation/' ) );
         ?>
       </div>
     </div>
     <div class="input-section">
       <label><b><?php echo esc_html__("Revoke Your Purchase Code:", 'aiomatic-automatic-ai-content-writer');?></b></label>
       <input type="hidden" id="<?php echo esc_html($plugin_slug);?>_activation_nonce" value="<?php echo esc_html(wp_create_nonce('activation-secret-nonce'));?>">
       <button type="button" id="<?php echo esc_html($plugin_slug);?>_revoke_license" class="button button-primary modern-button" onclick="unsaved = false;"><?php echo esc_html__("Revoke License", 'aiomatic-automatic-ai-content-writer');?></button>
     </div>
   </div>
<?php
   }
   elseif($is_activated === 2)
   {
      ?>
         <div class="verification-container">
           <div class="help-section">
             <div class="help-icon">
               <span class="dashicons dashicons-editor-help"></span>
             </div>
             <div class="help-text">
               <?php
                 echo sprintf( wp_kses( __( 'The plugin is in DEMO Mode, no registration is required. You can freely test its functionality.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url_raw( '//coderevolution.ro/knowledge-base/faq/how-do-i-find-my-items-purchase-code-for-plugin-license-activation/' ) );
               ?>
             </div>
           </div>
         </div>
      <?php

   }
   elseif($is_activated === -2)
  {
  ?>
  <div class="verification-container">
      <div class="help-section">
        <div class="help-text">
          <span class="cr_red"><?php echo esc_html__( 'Your license is set to expire soon!', 'aiomatic-automatic-ai-content-writer' ); ?></span>
            <br/><br/>
            <?php 
              printf(
                  esc_html__(
                    'Your Aimogen license was created on Envato before the WPBay migration. Starting %s, Envato-based licenses purchased before this date will no longer be supported directly in the plugin.',
                    'aiomatic-automatic-ai-content-writer'
                  ),
                  esc_html( AIMOGEN_MIGRATION_CUTOFF_DATE )
              );
            ?>
            <br/><br/>
            <?php 
              echo esc_html__(
                  'To continue receiving updates and functionality, please migrate your license to WPBay before the cutoff date. During this grace period, your plugin will keep working normally.',
                  'aiomatic-automatic-ai-content-writer'
              );
            ?>
            <br/><br/>

            <!-- VIDEO LINK -->
            <strong><?php echo esc_html__( 'Watch the announcement video:', 'aiomatic-automatic-ai-content-writer' ); ?></strong>
            <a href="https://www.youtube.com/watch?v=EAiBAczyuoA" target="_blank">
              <?php echo esc_html__( 'Rename + migration explained', 'aiomatic-automatic-ai-content-writer' ); ?>
            </a>

            <br/><br/>
            <strong><?php echo esc_html__( 'Migrate now:', 'aiomatic-automatic-ai-content-writer' ); ?></strong>
            <a href="https://wpbay.com/product/aimogen-pro/#pills-migration" target="_blank">
              <?php echo esc_html__( 'Go to WPBay migration page', 'aiomatic-automatic-ai-content-writer' ); ?>
            </a>

            <br><br>
            <input type="button" onclick="unsaved = false;" class="button button-primary" id="<?php echo esc_html( $plugin_slug ); ?>_revoke_license" value="<?php echo esc_html__( 'Revoke License', 'aiomatic-automatic-ai-content-writer' ); ?>">
            <input type="hidden" id="<?php echo esc_html( $plugin_slug ); ?>_activation_nonce" value="<?php echo esc_html( wp_create_nonce( 'activation-secret-nonce' ) ); ?>">
        </div>
      </div>
  </div>
  <?php
  }
  elseif($is_activated === -3)
  {
  ?>
  <div class="verification-container">
      <div class="help-section">
        <div class="help-text">
          <span class="cr_red"><?php echo esc_html__( 'Your license has expired!', 'aiomatic-automatic-ai-content-writer' ); ?></span>
            <br/><br/>
            <?php 
              printf(
                  esc_html__(
                    'Your Aimogen license was created on Envato before the WPBay migration. As of %s, Envato-based licenses which were purchased before %s need to be migrated to WPBay to continue functioning.',
                    'aiomatic-automatic-ai-content-writer'
                  ),
                  esc_html( AIMOGEN_MIGRATION_CUTOFF_DATE ),
                  esc_html( AIMOGEN_MIGRATION_NOTICE_DATE )
              );
            ?>
            <br/><br/>
            <?php 
              echo esc_html__(
                  'Your current license is no longer valid for activation or updates. To continue using the plugin and receive new features, please migrate your license to WPBay.',
                  'aiomatic-automatic-ai-content-writer'
              );
            ?>
            <br/><br/>

            <!-- VIDEO LINK -->
            <strong><?php echo esc_html__( 'Watch the announcement video:', 'aiomatic-automatic-ai-content-writer' ); ?></strong>
            <a href="https://www.youtube.com/watch?v=EAiBAczyuoA" target="_blank">
              <?php echo esc_html__( 'Rename + migration explained', 'aiomatic-automatic-ai-content-writer' ); ?>
            </a>

            <br/><br/>
            <strong><?php echo esc_html__( 'Migrate now:', 'aiomatic-automatic-ai-content-writer' ); ?></strong>
            <a href="https://wpbay.com/product/aimogen-pro/#pills-migration" target="_blank">
              <?php echo esc_html__( 'Go to WPBay migration page', 'aiomatic-automatic-ai-content-writer' ); ?>
            </a>

            <br><br>
            <input type="button" onclick="unsaved = false;" class="button button-primary" id="<?php echo esc_html( $plugin_slug ); ?>_revoke_license" value="<?php echo esc_html__( 'Revoke License', 'aiomatic-automatic-ai-content-writer' ); ?>">
            <input type="hidden" id="<?php echo esc_html( $plugin_slug ); ?>_activation_nonce" value="<?php echo esc_html( wp_create_nonce( 'activation-secret-nonce' ) ); ?>">
        </div>
      </div>
  </div>
  <?php
  }
   elseif($is_activated === -1)
   {
      ?>
         <div class="verification-container">
           <div class="help-section">
             <div class="help-icon">
               <span class="dashicons dashicons-editor-help"></span>
             </div>
             <div class="help-text"><p class="cr_red"><?php echo esc_html__("You are using a PIRATED version of the plugin! Because of this, the main functionality of the plugin is not available. Please revoke your license and activate a genuine license for the Aimogen plugin. Note that the only place where you can get a valid license for the plugin is found here (if you find the plugin for sale also on other websites, do not buy, they are selling pirated copies): ", 'aiomatic-automatic-ai-content-writer');?><a href="https://wpbay.com/product/aimogen-pro/" target="_blank"><?php echo esc_html__("Aimogen on WPBay", 'aiomatic-automatic-ai-content-writer');?></a></p>
             </div>
           </div>
           <div class="input-section">
             <label><b><?php echo esc_html__("Revoke Your Purchase Code:", 'aiomatic-automatic-ai-content-writer');?></b></label>
             <input type="hidden" id="<?php echo esc_html($plugin_slug);?>_activation_nonce" value="<?php echo esc_html(wp_create_nonce('activation-secret-nonce'));?>">
             <button type="button" id="<?php echo esc_html($plugin_slug);?>_revoke_license" class="button button-primary modern-button" onclick="unsaved = false;"><?php echo esc_html__("Revoke License", 'aiomatic-automatic-ai-content-writer');?></button>
           </div>
         </div>
      <?php
   }
   else
   {
   ?>
<div class="verification-container">
  <div class="help-section">
    <div class="help-icon">
      <span class="dashicons dashicons-editor-help"></span>
    </div>
    <div class="help-text">
      <?php
        echo sprintf( wp_kses( __( 'Please input your purchase code, to activate the plugin. To get your purchase code, please follow <a href="%s" target="_blank">this tutorial</a>.', 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url_raw( '//coderevolution.ro/knowledge-base/faq/how-do-i-find-my-items-purchase-code-for-plugin-license-activation/' ) );
      ?>
    </div>
  </div>
  <div class="input-section">
    <label for="<?php echo esc_html($plugin_slug);?>_register_code"><b><?php echo esc_html__("Register Your Purchase Code To Activate The Plugin:", 'aiomatic-automatic-ai-content-writer');?></b></label>
    <input type="text" id="<?php echo esc_html($plugin_slug);?>_register_code" placeholder="<?php echo esc_html__("Purchase Code", 'aiomatic-automatic-ai-content-writer');?>" class="input-text">
    <input type="hidden" id="<?php echo esc_html($plugin_slug);?>_activation_nonce" value="<?php echo esc_html(wp_create_nonce('activation-secret-nonce'));?>">
    <button type="button" id="<?php echo esc_html($plugin_slug);?>_register" class="button button-primary modern-button" onclick="unsaved = false;"><?php echo esc_html__("Register Purchase Code", 'aiomatic-automatic-ai-content-writer');?></button>
  </div>
</div>
<?php
   }
}
?>