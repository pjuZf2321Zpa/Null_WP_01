<?php
if ( ! defined ( 'ABSPATH' ) ) {
	die ( 'Not allowed' );
}
function aimogenpro_get_edit_image_url( $id ) {
	$nonce = wp_create_nonce( 'aiomatic_edit_thumbnails_nonce' );
	return admin_url( 'admin-ajax.php' ) . '?action=aimogenpro_edit_thumbnails_page&post=' . $id . '&nonce=' . $nonce;
}

function aimogenpro_get_edit_image_anchor( $id, $style = '', $classes = '' ) {
	add_thickbox();
	$edit_crops_url = aimogenpro_get_edit_image_url( $id );
	return '<a class="autox-thickbox aiomatic ' . $classes . '" style="' . $style . '" href="' . $edit_crops_url . '" title="' . esc_html__( 'AI Generated SEO Fields', 'aiomatic-automatic-ai-content-writer' ) . '">' . esc_html__( 'AI Generated SEO Fields', 'aiomatic-automatic-ai-content-writer' ) . '</a>';
}

function aimogenpro_get_edit_image_anchor_ajax() {
	check_ajax_referer('openai-ajax-nonce', 'nonce');
	if ( ! current_user_can('edit_posts') ) {
		wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
	}
	$classes = empty( $_POST['classes'] ) ? 'edit-attachment' : esc_html( $_POST['classes'] );
	echo aimogenpro_get_edit_image_anchor( esc_html( $_POST['post'] ), 'margin-right:10px;', $classes );
	die();
}
add_action( 'wp_ajax_aimogenpro_get_edit_image_anchor', 'aimogenpro_get_edit_image_anchor_ajax' );

function aimogenpro_edit_thumbnails_page() {
	if ( ! isset($_GET['nonce']) || ! wp_verify_nonce( $_GET['nonce'], 'aiomatic_edit_thumbnails_nonce') ) {
        wp_send_json_error( array( 'message' => 'Invalid nonce' ), 403 );
    }
	if ( ! current_user_can('edit_posts') ) {
		wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
	}
	global $aiomatic_image_id;
	$aiomatic_image_id = esc_html( $_GET ['post'] );

	if (current_user_can ( 'access_aiomatic_menu', $aiomatic_image_id ) ) {
		include (dirname(__FILE__) . '/seo-panel.php');
	} else {
		die ();
	}
}
add_action( 'wp_ajax_aimogenpro_edit_thumbnails_page', 'aimogenpro_edit_thumbnails_page' );

function aimogenpro_admin_post_thumbnail_html( $content, $id, $thumb_id = null ) {
	global $wp_version;
	if ( version_compare( $wp_version, '4.6.0', '>=' ) ) {
		if ( ! empty( $thumb_id ) ) {
			$image_id = $thumb_id;
		} else {
			return $content;
		}
	} else {
		if ( has_post_thumbnail( $id ) ) {
			$image_id = get_post_thumbnail_id( $id );
		} else {
			return $content;
		}
	}
	if ( ! current_user_can( 'access_aiomatic_menu', $image_id ) ) {
		return $content;
	}
	$edit_crops_content = '<p>' . aimogenpro_get_edit_image_anchor( $image_id ) . '</p>';
	return $content . $edit_crops_content;
}

add_filter( 'admin_post_thumbnail_html', 'aimogenpro_admin_post_thumbnail_html', 10, 3 );

function aimogenpro_print_media_templates() {
	?>
	<script>
	jQuery(document).ready(function() 
	{
		if (window.aiomaticExtendMediaLightboxTemplate) 
		{
			aiomaticExtendMediaLightboxTemplate(
				'<?php echo aimogenpro_get_edit_image_anchor( '{{ data.id }}', 'display:block;text-decoration:none;' ); ?>',
				'<?php echo aimogenpro_get_edit_image_anchor( '{{ data.id }}', 'text-decoration:none;' ); ?>',
				'<?php echo aimogenpro_get_edit_image_anchor( '{{ data.id }}', '', 'button' ); ?>',
				'<?php echo aimogenpro_get_edit_image_anchor( '{{ data.attachment.id }}', '', 'button' ); ?>'
			);
		}
	});
	</script>
	<?php
}

add_action( 'print_media_templates', 'aimogenpro_print_media_templates' );

function aimogenpro_media_row_actions( $actions, $post, $detached ) {
	if ( wp_attachment_is_image( $post->ID ) && current_user_can( 'access_aiomatic_menu', $post->ID ) ) {
		$actions['aiomatic_crop'] = aimogenpro_get_edit_image_anchor( $post->ID );
	}
	return $actions;
}
add_filter( 'media_row_actions', 'aimogenpro_media_row_actions', 10, 3);
?>