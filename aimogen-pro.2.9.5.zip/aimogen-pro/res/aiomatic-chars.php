<?php
defined('ABSPATH') or die(); 
$xchars = array('​', '‌', '‍', '⁢', '⁣', '⁤');
?>