<?php
   defined('ABSPATH') or die(); 
   function aiomatic_reply_panel()
   {
   $aiomatic_language_names = array(
      esc_html__("English", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Spanish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("French", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Italian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Afrikaans", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Albanian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Arabic", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Amharic", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Armenian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Belarusian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Bulgarian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Catalan", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Chinese Simplified", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Croatian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Czech", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Danish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Dutch", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Estonian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Filipino", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Finnish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Galician", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("German", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Greek", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Hebrew", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Hindi", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Hungarian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Icelandic", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Indonesian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Irish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Japanese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Korean", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Latvian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Lithuanian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Norwegian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Macedonian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Malay", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Maltese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Persian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Polish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Portuguese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Romanian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Russian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Serbian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Slovak", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Slovenian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Swahili", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Swedish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Thai", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Turkish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Ukrainian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Vietnamese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Welsh", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Yiddish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Tamil", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Azerbaijani", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Kannada", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Basque", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Bengali", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Latin", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Chinese Traditional", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Esperanto", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Georgian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Telugu", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Gujarati", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Haitian Creole", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Urdu", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Burmese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Bosnian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Cebuano", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Chichewa", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Corsican", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Frisian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Scottish Gaelic", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Hausa", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Hawaian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Hmong", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Igbo", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Javanese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Kazakh", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Khmer", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Kurdish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Kyrgyz", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Lao", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Luxembourgish", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Malagasy", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Malayalam", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Maori", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Marathi", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Mongolian", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Nepali", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Pashto", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Punjabi", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Samoan", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Sesotho", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Shona", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Sindhi", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Sinhala", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Somali", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Sundanese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Swahili", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Tajik", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Uzbek", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Xhosa", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Yoruba", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Zulu", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Assammese", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Aymara", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Bambara", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Bhojpuri", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Dhivehi", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Dogri", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Ewe", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Guarani", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Ilocano", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Kinyarwanda", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Konkani", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Krio", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Kurdish - Sorani", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Lingala", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Luganda", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Maithili", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Meiteilon", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Mizo", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Odia", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Oromo", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Quechua", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Sanskrit", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Sepedi", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Tatar", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Tigrinya", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Tsonga", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Turkmen", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Twi", 'aiomatic-automatic-ai-content-writer'),
      esc_html__("Uyghur", 'aiomatic-automatic-ai-content-writer')
   );
   $all_models = aiomatic_get_all_models(true);
   $all_assistants = aiomatic_get_all_assistants(true);
   $all_rules = get_option('aiomatic_reply_list', array());
   if($all_rules === false)
   {
       $all_rules = array();
   }
   $rules_count = count($all_rules);
   $rules_per_page = get_option('aiomatic_posts_per_page', 12);
   $max_pages = ceil($rules_count/$rules_per_page);
   if($max_pages == 0)
   {
       $max_pages = 1;
   }
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   if (!aiomatic_check_api_keys($aiomatic_Main_Settings)) 
   {
      ?>
<h1><?php echo esc_html__("You must add an AI service API Key into the plugin's 'Settings' -> 'API Keys' tab before you can use this feature!", 'aiomatic-automatic-ai-content-writer');?></h1>
<?php
return;
   }
   if ( ! function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
   }
   if ( !is_plugin_active( 'wpforo/wpforo.php' ) ) 
   {
            ?><div style="padding:20px; border-radius:12px; background:#f9f9f9; border:1px solid #ddd; text-align:center; max-width:600px; margin:20px auto;">
            <h2 style="margin-bottom:10px; color:#333;">
                <?php echo esc_html__('wpForo Plugin Required', 'aiomatic-automatic-ai-content-writer'); ?>
            </h2>
            <p style="margin-bottom:15px; color:#555; font-size:15px;">
                <?php echo esc_html__('This functionality is only available if the wpForo plugin is active.', 'aiomatic-automatic-ai-content-writer'); ?>
            </p>
            <a href="https://wordpress.org/plugins/wpforo/" target="_blank" 
               style="display:inline-block; padding:10px 20px; background:#0073aa; color:#fff; text-decoration:none; border-radius:6px; font-weight:bold;">
                <?php echo esc_html__('Download Plugin', 'aiomatic-automatic-ai-content-writer'); ?>
            </a>
        </div>
<?php
return;
   }
   if ( !is_plugin_active( 'aiomatic-extension-wpforo/aiomatic-extension-wpforo.php' ) ) 
   {
            ?><div style="padding:20px; border-radius:12px; background:#f9f9f9; border:1px solid #ddd; text-align:center; max-width:600px; margin:20px auto;">
            <h2 style="margin-bottom:10px; color:#333;">
                <?php echo esc_html__('AI Forum Creator Extension Required', 'aiomatic-automatic-ai-content-writer'); ?>
            </h2>
            <p style="margin-bottom:15px; color:#555; font-size:15px;">
                <?php echo esc_html__('This functionality is only available if the Aimogen AI Forum Creator Extension plugin is active.', 'aiomatic-automatic-ai-content-writer'); ?>
            </p>
            <a href="https://wpbay.com/product/aiomatic-extension-wpforo-integration/" target="_blank" 
               style="display:inline-block; padding:10px 20px; background:#0073aa; color:#fff; text-decoration:none; border-radius:6px; font-weight:bold;">
                <?php echo esc_html__('Purchase Plugin', 'aiomatic-automatic-ai-content-writer'); ?>
            </a>
        </div>
<?php
return;
   }
   $forums = WPF()->forum->get_forums(); 
   $forum_hierarchy = [];
   foreach ($forums as $forum) {
      $forum_id = intval($forum['forumid']);
      $parent_id = intval($forum['parentid']);
      $forum_hierarchy[$parent_id][] = $forum;
   }

   function aiomatic_render_forum_options($forums, $hierarchy, $selected_forum = '', $parent_id = 0, $prefix = '') {
      $retval = '';
      if (!isset($hierarchy[$parent_id])) {
            return $retval;
      }
      foreach ($hierarchy[$parent_id] as $forum) {
            $forum_id = intval($forum['forumid']);
            $forum_title = esc_html($forum['title']);
            $display_title = $prefix . $forum_title; 
            $selected = $selected_forum == $forum_id ? 'selected' : '';
            $retval .= "<option value='" . esc_attr($forum_id) . "' " . esc_html($selected) . ">" . esc_html($display_title) . "</option>";
            $retval .= aiomatic_render_forum_options($forums, $hierarchy, $selected_forum, $forum_id, $prefix . '&nbsp;&nbsp;-> ');
      }
      return $retval;
   }
   ?>
<div class="wp-header-end"></div>
<div class="wrap">
   <h2><?php echo esc_html__("Keywords/Titles To Forum Replies", 'aiomatic-automatic-ai-content-writer');?></h2>
</div>
<?php
$max_execution = ini_get('max_execution_time');
if($max_execution != 0 && $max_execution < 1000)
{
    ?>
    <div class="notice notice-error">
        <p class="cr_red">
            <?php echo sprintf( wp_kses( __( "Warning! Your PHP INI max_execution_time is less than 1000 seconds (%s). This means that the plugin's execution will be forcefully stopped by your server after this amount of seconds. Please increase it to ensure that the plugin functions properly. Please check details on server settings, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_html($max_execution), esc_url_raw( get_admin_url() . 'admin.php?page=aiomatic_openai_status#tab-2l' ) );?>
        </p>
    </div>
    <?php
}
?>
<div class="wrap gs_popuptype_holder seo_pops">
   <div>
      <form id="myForm" method="post" action="<?php echo esc_url((aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");?>">
         <?php
            wp_nonce_field('aiomatic_save_rules', '_aiomaticr_nonce');
            
            if (isset($_GET['settings-updated'])) {
            ?>
         <div>
            <p class="cr_saved_notif"><strong><?php echo esc_html__("Settings saved.", 'aiomatic-automatic-ai-content-writer');?></strong></p>
         </div>
         <?php
            }
            ?>
         <div>
            <div class="hideMain">
               <hr/>
               <div class="table-responsive">
<div class="tablenav top">
    <div class="alignleft actions bulkactions">
        <label for="aiomatic_bulk_action" class="screen-reader-text">
            <?php echo esc_html__("Bulk actions", 'aiomatic-automatic-ai-content-writer');?>
        </label>
<select name="action" id="aiomatic_bulk_action" class="codemainfzr" onclick="unsaved = false;">
    <option value="-1"><?php echo esc_html__("Bulk actions", 'aiomatic-automatic-ai-content-writer');?></option>
    <option value="run"><?php echo esc_html__("Run Selected Rules", 'aiomatic-automatic-ai-content-writer');?></option>
    <option value="duplicate"><?php echo esc_html__("Duplicate Selected Rules", 'aiomatic-automatic-ai-content-writer');?></option>
    <option value="trash"><?php echo esc_html__("Send Posts To Trash", 'aiomatic-automatic-ai-content-writer');?></option>
    <option value="delete"><?php echo esc_html__("Permanently Delete Posts", 'aiomatic-automatic-ai-content-writer');?></option>
    <option value="activate"><?php echo esc_html__("Activate Rules", 'aiomatic-automatic-ai-content-writer');?></option>
    <option value="deactivate"><?php echo esc_html__("Deactivate Rules", 'aiomatic-automatic-ai-content-writer');?></option>
    <option value="deleterule"><?php echo esc_html__("Delete Rules", 'aiomatic-automatic-ai-content-writer');?></option>
</select>
        <input type="button"
               id="aiomatic_apply_bulk"
               class="button action"
               value="Apply" />
    </div>
    <br class="clear" />
</div>
                  <table id="mainRules" class="responsive table cr_main_table">
                     <thead>
                        <tr>
                            <th class="cr_width_40">
                              <label>
        <input type="checkbox" id="aiomatic_select_all_rules" class="aiomatic_rule_select_box">
    </label>
                           </th>
                           <th class="cr_width_160">
                              <?php echo esc_html__("ID", 'aiomatic-automatic-ai-content-writer');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("This is the ID of the rule.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <span id="aiomatic_mode_sel"><?php echo esc_html__("Forum Selector", 'aiomatic-automatic-ai-content-writer');?>*</span>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the forum for which you want to create the content.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <span id="aiomatic_mode_title"><?php echo esc_html__("Reply Strategy", 'aiomatic-automatic-ai-content-writer');?>*</span>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the reply creations trategy you want to use for this rule.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <?php echo esc_html__("Schedule", 'aiomatic-automatic-ai-content-writer');?>*
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       $unlocker = get_option('aiomatic_minute_running_unlocked', false);
                                       if($unlocker == '1')
                                       {
                                           echo esc_html__("Select the interval in minutes after which you want this rule to run. Defined in minutes.", 'aiomatic-automatic-ai-content-writer');
                                       }
                                       else
                                       {
                                           echo esc_html__("Select the interval in hours after which you want this rule to run. Defined in hours.", 'aiomatic-automatic-ai-content-writer');
                                       }
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <?php echo esc_html__("# Of Topics To Process", 'aiomatic-automatic-ai-content-writer');?>*
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the maximum number of topica that this rule can create at once.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th>
                              <?php echo esc_html__("Options", 'aiomatic-automatic-ai-content-writer');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Shows advanced settings for this rule.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th class="cr_width_60">
                              <?php echo esc_html__("Delete", 'aiomatic-automatic-ai-content-writer');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Do you want to delete this rule?", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th class="cr_width_60">
                              <?php echo esc_html__("Active", 'aiomatic-automatic-ai-content-writer');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Do you want to enable this rule? You can deactivate any rule (you don't have to delete them to deactivate them).", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                              <br/>
                              <input type="checkbox" onchange="thisonChangeHandler(this)" id="exclusion">
                           </th>
                           <th class="cr_width_160">
                              <?php echo esc_html__("Info", 'aiomatic-automatic-ai-content-writer');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("The number of items (posts, pages) this rule has generated so far.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                           <th class="cr_actions">
                              <?php echo esc_html__("Actions", 'aiomatic-automatic-ai-content-writer');?>
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Do you want to run this rule now? Note that only one instance of a rule is allowed at once.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </th>
                        </tr>
                        
                     </thead>
                     <tbody>
                        <?php
                           echo aiomatic_expand_reply_manual($aiomatic_Main_Settings, $forums, $forum_hierarchy);
                           if(isset($_GET['aiomatic_page']))
                           {
                              $current_page = $_GET['aiomatic_page'];
                           }
                           else
                           {
                              $current_page = '';
                           }
                           if($current_page == '' || (is_numeric($current_page) && $current_page == $max_pages))
                           {
                           ?>
                        
                        <tr>
                           <td class="cr_short_td">
    <input type="checkbox"
        disabled>
</td>
                           <td class="cr_short_td"><input type="text" name="aiomatic_reply_list[rule_description][]" id="rule_description" class="cr_center" placeholder="Rule ID" value="" class="cr_width_full"/></td>
                           <td class="cr_width_80 cr_center">
                              <select autocomplete="off" id="selected_forum" name="aiomatic_reply_list[selected_forum][]" class="cr_width_full">
<?php
if (!empty($forums)) {
   echo '<option value="">' . esc_html__("Select a Forum", 'aiomatic-automatic-ai-content-writer') . '</option>';
   echo aiomatic_render_forum_options($forums, $forum_hierarchy);
} else {
   echo '<option value="">' . esc_html__("No forums available", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
?>
                           </select> 
                           </td>
                           <td class="cr_loi">
                              <select autocomplete="off" id="post_title" name="aiomatic_reply_list[post_title][]" class="cr_width_full">
                                 <option value="" disabled selected><?php echo esc_html__("Select Reply Strategy", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_grow"><?php echo esc_html__("Auto Grow (Spawns new replies in quiet topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_unaswered"><?php echo esc_html__("Auto Unanswered (Replies to unanswered topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_random"><?php echo esc_html__("Auto Random (Replies to random topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_latest"><?php echo esc_html__("Auto Latest (Replies to latest topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_oldest"><?php echo esc_html__("Auto Oldest (Replies to oldest topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_popular"><?php echo esc_html__("Auto Most Popular (Replies to most popular topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_least_popular"><?php echo esc_html__("Auto Least Popular (Replies to least popular topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_most_replied"><?php echo esc_html__("Auto Most Replied (Replies to most replied topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_least_replied"><?php echo esc_html__("Auto Least Replied (Replies to least replied topics)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_oldest_no_replies"><?php echo esc_html__("Auto Oldest No Replies (Replies to oldest topics with no replies)", 'aiomatic-automatic-ai-content-writer');?></option>
                                 <option value="auto_latest_no_replies"><?php echo esc_html__("Auto Latest No Replies (Replies to latest topics with no replies)", 'aiomatic-automatic-ai-content-writer');?></option>
                              </select>
                           </td>
                           <td class="cr_comm_td"><input type="number" step="1" min="1" name="aiomatic_reply_list[schedule][]" max="8765812" class="cr_width_60" placeholder="Select the rule schedule interval" value="24"/></td>
                           <td class="cr_comm_td"><input type="number" step="1" min="0" name="aiomatic_reply_list[max][]" class="cr_width_60" placeholder="Select the # of generated posts" value="1" /></td>
                           <td class="cr_width_70 cr_center">
                              <input type="button" id="mybtnfzr" class="button" value="Settings">
                              <div id="mymodalfzr" class="codemodalfzr" data-creator="reply">
                                 <div class="codemodalfzr-content">
                                    <div class="codemodalfzr-header">
                                       <span id="aiomatic_close" class="codeclosefzr">&times;</span>
                                       <h2><span class="cr_color_white"><?php echo esc_html__("New Rule", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
                                    </div>
                                    <div class="codemodalfzr-body">
                                       <div class="table-responsive">
                                          <table class="responsive table cr_main_table_nowr">
                                             <tr><td colspan="2">
                                                  <h3><?php echo esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                                             </td></tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td><select id="assistant_id" name="aiomatic_reply_list[assistant_id][]" class="cr_width_full" onchange="assistantSelected('');">
<?php
if($all_assistants === false)
{
    echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
    if(count($all_assistants) == 0)
    {
        echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
    }
    else
    {
        echo '<option value="" selected';
        echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
        foreach($all_assistants as $myassistant)
        {
            echo '<option value="' . esc_html($myassistant->ID) .'"';
            echo '>' . esc_html($myassistant->post_title);
            echo '</option>';
        }
    }
}
?>
    </select>  
                                                </td>
                                             </tr>
                                             <tr><td colspan="2">
                                                  <h3><?php echo esc_html__("Reply Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                                             </td></tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the number of automatic replies to add to created topics. You can also define custom ranges, like: 3-5. To disable this feature, leave it blank.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Reply Count To Add To The Topic:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="text" name="aiomatic_reply_list[reply_count][]" placeholder="Reply number to add to the topic" class="cr_width_full" value="1">
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the maximum number of replies a topic can have, when it will still be processed.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Maximum Reply Count For Topics:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="text" name="aiomatic_reply_list[more_replies][]" placeholder="Don't process if it has more replies than" class="cr_width_full" value="">
                                                </td>
                                             </tr><tr>
                                                <td>
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Select the AI Model to be used for the reply generator.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("AI Model For The AI Reply Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                                                </td>
                                                <td class="cr_min_width_200">
                                                <select autocomplete="off" id="reply_model" name="aiomatic_reply_list[reply_model][]" class="hideAssistant cr_width_full">
                                                <?php
foreach($all_models as $modelx)
{
   echo '<option value="' . esc_html($modelx) .'"';
   echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                                                </select>   
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the command based on which, the reply users will be selected. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%participant_list%%, %%conversation%%, %%post_title%%, %%random_sentence%%, %%post_original_title%%, %%random_sentence2%%, %%blog_title%%. You can also add a link to a TXT file, containing keywords (one per line), or to an RSS feed. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/' );
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Prompt For The AI Topic Reply User Selector:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/" target="_blank">&#9432;</a></b>
                                                </td>
                                                <td>
                                                <textarea rows="4" cols="70" name="aiomatic_reply_list[choose_prompt][]" placeholder="Please insert a command for the AI" class="cr_width_full">The following is a discussion between forum users. The participants are: %%participant_list%%.\n\n 
Based on the tone, flow, and topic, choose which participant should naturally post the next reply. Answer ONLY with the participant's display name, nothing else. If you want to bring in a new user into the conversation, reply exactly with this text: NEW. If there is only one person in the conversation so far, in most cases reply with NEW, so a new user will be selected. Here is the latest part of the discussion:\n\n 
%%conversation%% 
\n\n</textarea>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the prompt command you want to use to create the reply content. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%reply_user_name%%, %%participant_list%%, %%conversation%%, %%post_title%%, %%random_sentence%%, %%post_original_title%%, %%random_sentence2%%, %%blog_title%%. You can also add a link to a TXT file, containing keywords (one per line), or to an RSS feed. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/' );
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Prompt For The AI Topic Reply Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/" target="_blank">&#9432;</a></b>
                                                </td>
                                                <td>
                                                <textarea rows="4" cols="70" name="aiomatic_reply_list[reply_prompt][]" placeholder="Please insert a command for the AI" class="cr_width_full">Continue the following forum discussion naturally. You are %%reply_user_name%%.\n 
Write in %%language%% language. Writing Style: %%writing_style%%. Tone: %%writing_tone%%. Stay consistent with their voice and previous tone.\n\n
=== Conversation so far ===\n
%%conversation%%\n
=== %%reply_user_name%%'s reply ===</textarea>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td>
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Select the user role from where random users will be selected.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("User Role For Random User Selection:", 'aiomatic-automatic-ai-content-writer');?></b>  
                                                </td>
                                                <td class="cr_min_width_200">
                                                <select autocomplete="off" id="user_role" name="aiomatic_reply_list[user_role][]" class="cr_width_full">
                                                   <option value="any"><?php echo esc_html__("Any", 'aiomatic-automatic-ai-content-writer');?></option>
                                                <?php
        global $wp_roles;
        $roles = $wp_roles->roles;

        foreach ($roles as $role_key => $role) {
            echo '<option value="' . esc_attr($role_key) . '">' . esc_html($role['name']) . '</option>';
        }
    ?>
                                                </select>   
                                                </td>
                                             </tr>
                                             <tr><td colspan="2">
                                                  <h2><?php echo esc_html__("Content Parameters", 'aiomatic-automatic-ai-content-writer');?>:</h2>
                                             </td></tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the language of the created content. This will set the value of the %%language%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Content Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input id="content_language" name="aiomatic_reply_list[content_language][]" type="text" list="languages" placeholder="Created content language" class="coderevolution_gutenberg_input" value="English"/>
							<datalist id="languages">
<?php
foreach($aiomatic_language_names as $ln)
{
	echo '<option>' . esc_html($ln) . '</option>';
}
?>
							</datalist>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the writing style of the created content. This will set the value of the %%writing_style%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Writing Style:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input id="writing_style" name="aiomatic_reply_list[writing_style][]" type="text" placeholder="Created content writing style" list="writing_styles" class="coderevolution_gutenberg_input" value="Creative"/>
                                                <datalist id="writing_styles">
<option>Informative</option>
<option>Academic</option>
<option>Descriptive</option>
<option>Detailed</option>
<option>Dramative</option>
<option>Fiction</option>
<option>Expository</option>
<option>Historical</option>
<option>Dialogue</option>
<option>Creative</option>
<option>Critical</option>
<option>Narrative</option>
<option>Persuasive</option>
<option>Reflective</option>
<option>Argumentative</option>
<option>Analytical</option>
<option>Blog</option>
<option>News</option>
<option>Casual</option>
<option>Pastoral</option>
<option>Personal</option>
<option>Poetic</option>
<option>Satirical</option>
<option>Sensory</option>
<option>Articulate</option>
<option>Monologue</option>
<option>Colloquial</option>
<option>Comparative</option>
<option>Concise</option>
<option>Biographical</option>
<option>Anecdotal</option>
<option>Evaluative</option>
<option>Letter</option>
<option>Lyrical</option>
<option>Simple</option>
<option>Vivid</option>
<option>Journalistic</option>
<option>Technical</option>
<option>Direct</option>
<option>Emotional</option>
<option>Metaphorical</option>
<option>Objective</option>
<option>Rhetorical</option>
<option>Theoretical</option>
<option>Business</option>
<option>Report</option>
<option>Research</option>
</datalist>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the writing tone of the created content. This will set the value of the %%writing_tone%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Writing Tone:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input id="writing_tone" name="aiomatic_reply_list[writing_tone][]" type="text" list="writing_tones" placeholder="Created content writing tone" class="coderevolution_gutenberg_input" value="Neutral"/>
                                                <datalist id="writing_tones">
<option>Neutral</option>
<option>Formal</option>
<option>Assertive</option>
<option>Cheerful</option>
<option>Humorous</option>
<option>Informal</option>
<option>Inspirational</option>
<option>Professional</option>
<option>Emotional</option>
<option>Persuasive</option>
<option>Supportive</option>
<option>Sarcastic</option>
<option>Condescending</option>
<option>Skeptical</option>
<option>Narrative</option>
<option>Journalistic</option>
<option>Conversational</option>
<option>Factual</option>
<option>Friendly</option>
<option>Polite</option>
<option>Scientific</option>
<option>Sensitive</option>
<option>Sincere</option>
<option>Curious</option>
<option>Dissapointed</option>
<option>Encouraging</option>
<option>Optimistic</option>
<option>Surprised</option>
<option>Worried</option>
<option>Confident</option>
<option>Authoritative</option>
<option>Nostalgic</option>
<option>Sympathetic</option>
<option>Suspenseful</option>
<option>Romantic</option>
<option>Serious</option>
</datalist>
                                                </td>
                                             </tr>
                                          <tr><td colspan="2">
                                                  <h3><?php echo esc_html__("Global Prompt Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                                             </td></tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%%, %%royalty_free_image_attribution%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Prepend Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <textarea rows="2" cols="70" name="aiomatic_reply_list[global_prepend][]" placeholder="Global prompt prepend text" class="cr_width_full"></textarea>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%%, %%royalty_free_image_attribution%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Append Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <textarea rows="2" cols="70" name="aiomatic_reply_list[global_append][]" placeholder="Global prompt append text" class="cr_width_full"></textarea>
                                                </td>
                                             </tr>
                                          <tr><td colspan="2">
                                                  <h3><?php echo esc_html__("Advanced AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                                             </td></tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="number" min="1" name="aiomatic_reply_list[max_tokens][]" value="" placeholder="32768" class="cr_width_full">
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="number" min="1" name="aiomatic_reply_list[max_seed_tokens][]" value="" placeholder="1000" class="cr_width_full">
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("AI Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="number" min="0" step="0.01" max="2" name="aiomatic_reply_list[temperature][]" value="" placeholder="1" class="cr_width_full">
                                                </td>
                                             </tr><tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("AI Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="number" min="0" max="1" step="0.01" name="aiomatic_reply_list[top_p][]" value="" placeholder="1" class="cr_width_full">
                                                </td>
                                             </tr><tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="number" min="-2" step="0.01" max="2" name="aiomatic_reply_list[presence_penalty][]" value="" placeholder="0" class="cr_width_full">
                                                </td>
                                             </tr><tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="number" min="0" max="2" step="0.01" name="aiomatic_reply_list[frequency_penalty][]" value="" placeholder="0" class="cr_width_full">
                                                </td>
                                             </tr>
                                             <tr><td colspan="2">
                                                  <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                                             </td></tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("HTML Text To Prepend To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                                                </td>
                                                <td>
                                                <textarea rows="2" cols="70" name="aiomatic_reply_list[post_prepend][]" placeholder="HTML content to prepend to the AI generated content" class="cr_width_full"></textarea>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Enter a HTML text that should be appended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("HTML Text To Append To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                                                </td>
                                                <td>
                                                <textarea rows="2" cols="70" name="aiomatic_reply_list[post_append][]" placeholder="HTML content to append to the AI generated content" class="cr_width_full"></textarea>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="cr_min_width_200">
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-4.1-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Custom Shortcode Creator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b><span class="tool" data-tip="Supported models: <?php echo esc_html(implode(',', aiomatic_get_all_models()));?>">&nbsp;&#9432;</span>
                                                </td>
                                                <td>
                                                <textarea rows="2" cols="70" name="aiomatic_reply_list[custom_shortcodes][]" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="cr_width_full"></textarea>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td>
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Do Not Spin Topics Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="checkbox" id="skip_spin" name="aiomatic_reply_list[skip_spin][]">               
                                                </td>
                                             </tr>
                                             <tr>
                                                <td>
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Do Not Translate Topics Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <input type="checkbox" id="skip_translate" name="aiomatic_reply_list[skip_translate][]">               
                                                </td>
                                             </tr>
                                             <tr>
                                                <td>
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <textarea rows="1" class="cr_width_full" name="aiomatic_reply_list[strip_by_regex][]" placeholder="regex expression"></textarea>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td>
                                                      <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                                         <div class="bws_hidden_help_text cr_min_260px">
                                                            <?php
                                                               echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                                               ?>
                                                         </div>
                                                      </div>
                                                      <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                                                </td>
                                                <td>
                                                <textarea rows="1" class="cr_width_full" name="aiomatic_reply_list[replace_regex][]" placeholder="regex replacement"></textarea>
                                                </td>
                                             </tr>
                                          </table>
                                       </div>
                                    </div>
                                    <div class="codemodalfzr-footer">
                                       <br/>
                                       <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                                       <span id="aiomatic_ok" class="codeokfzr cr_inline">OK&nbsp;</span>
                                       <br/><br/>
                                    </div>
                                 </div>
                              </div>
                           </td>
                           <td class="cr_shrt_td2"><span class="cr_gray20">X</span></td>
                           <td class="cr_short_td"><input type="checkbox" name="aiomatic_reply_list[active][]" value="1" checked />
                              <input type="hidden" name="aiomatic_reply_list[last_run][]" value="1988-01-27 00:00:00"/>
                           <input type="hidden" name="aiomatic_reply_list[rule_unique_id][]" value="<?php echo esc_html(uniqid('', true));?>"/>
                           </td>
                           <td class="cr_short_td">
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("No info.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                           </td>
                           <td class="cr_center">
                              <div>
                                 <img src="<?php
                                    echo esc_url_raw(plugin_dir_url(dirname(__FILE__)) . 'images/running.gif');
                                    ?>" alt="Running" class="cr_running">
                                 <div class="codemainfzr cr_gray_back cr_width_80p">
                                    <select autocomplete="off" class="codemainfzr" id="actions" class="actions" name="actions" disabled>
                                       <option value="select" disabled selected><?php echo esc_html__("Select an Action", 'aiomatic-automatic-ai-content-writer');?></option>
                                       <option value="run" onclick=""><?php echo esc_html__("Run This Rule Now", 'aiomatic-automatic-ai-content-writer');?></option>
                                       <option value="duplicate" onclick=""><?php echo esc_html__("Duplicate This Rule", 'aiomatic-automatic-ai-content-writer');?></option>
                                       <option value="up" onclick=""><?php echo esc_html__("Move This Rule Up", 'aiomatic-automatic-ai-content-writer');?></option>
                                       <option value="down" onclick=""><?php echo esc_html__("Move This Rule Down", 'aiomatic-automatic-ai-content-writer');?></option>
                                    </select>
                                 </div>
                              </div>
                           </td>
                        </tr>
                     <?php
                        }
                        ?>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <hr/>
         
      <div>
         <?php
            $next_url = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(stristr($next_url, 'aiomatic_page=') === false)
            {
                if(stristr($next_url, '?') === false)
                {
                    if($max_pages == 1)
                    {
                        $next_url .= '?aiomatic_page=1';
                    }
                    else
                    {
                        $next_url .= '?aiomatic_page=2';
                    }
                }
                else
                {
                    if($max_pages == 1)
                    {
                        $next_url .= '&aiomatic_page=1';
                    }
                    else
                    {
                        $next_url .= '&aiomatic_page=2';
                    }
                }
            }
            else
            {
                if(isset($_GET['aiomatic_page']))
                {
                    $curent_page = $_GET["aiomatic_page"];
                }
                else
                {
                    $curent_page = '';
                }
                if(is_numeric($curent_page))
                {
                    $next_page = $curent_page + 1;
                    if($next_page > $max_pages)
                    {
                        $next_page = $max_pages;
                    }
                    if($next_page <= 0)
                    {
                        $next_page = 1;
                    }
                    $next_url = str_replace('aiomatic_page=' . $curent_page, 'aiomatic_page=' . $next_page, $next_url);
                }
                else
                {
                    if(stristr($next_url, '?') === false)
                    {
                        if($max_pages == 1)
                        {
                            $next_url .= '?aiomatic_page=1';
                        }
                        else
                        {
                            $next_url .= '?aiomatic_page=2';
                        }
                    }
                    else
                    {
                        if($max_pages == 1)
                        {
                            $next_url .= '&aiomatic_page=1';
                        }
                        else
                        {
                            $next_url .= '&aiomatic_page=2';
                        }
                    }
                }
            }
            $prev_url = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(stristr($prev_url, 'aiomatic_page=') === false)
            {
                if(stristr($prev_url, '?') === false)
                {
                    $prev_url .= '?aiomatic_page=1';
                }
                else
                {
                    $prev_url .= '&aiomatic_page=1';
                }
            }
            else
            {
                if(isset($_GET['aiomatic_page']))
                {
                    $curent_page = $_GET["aiomatic_page"];
                }
                else
                {
                    $curent_page = '';
                }
                if(is_numeric($curent_page))
                {
                    $go_to = $curent_page - 1;
                    if($go_to <= 0)
                    {
                        $go_to = 1;
                    }
                    if($go_to > $max_pages)
                    {
                        $go_to = $max_pages;
                    }
                    $prev_url = str_replace('aiomatic_page=' . $curent_page, 'aiomatic_page=' . $go_to, $prev_url);
                }
                else
                {
                    if(stristr($prev_url, '?') === false)
                    {
                        $prev_url .= '?aiomatic_page=1';
                    }
                    else
                    {
                        $prev_url .= '&aiomatic_page=1';
                    }
                }
            }
            $first_url = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(stristr($first_url, 'aiomatic_page=') === false)
            {
                if(stristr($first_url, '?') === false)
                {
                    $first_url .= '?aiomatic_page=1';
                }
                else
                {
                    $first_url .= '&aiomatic_page=1';
                }
            }
            else
            {
                if(isset($_GET['aiomatic_page']))
                {
                    $curent_page = $_GET["aiomatic_page"];
                }
                else
                {
                    $curent_page = '';
                }
                if(is_numeric($curent_page))
                {
                    $first_url = str_replace('aiomatic_page=' . $curent_page, 'aiomatic_page=1', $first_url);
                }
                else
                {
                    if(stristr($first_url, '?') === false)
                    {
                        $first_url .= '?aiomatic_page=1';
                    }
                    else
                    {
                        $first_url .= '&aiomatic_page=1';
                    }
                }
            }
            $last_url = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(stristr($last_url, 'aiomatic_page=') === false)
            {
                if(stristr($last_url, '?') === false)
                {
                    $last_url .= '?aiomatic_page=' . $max_pages;
                }
                else
                {
                    $last_url .= '&aiomatic_page=' . $max_pages;
                }
            }
            else
            {
                if(isset($_GET['aiomatic_page']))
                {
                    $curent_page = $_GET["aiomatic_page"];
                }
                else
                {
                    $curent_page = '';
                }
                if(is_numeric($curent_page))
                {
                    $last_url = str_replace('aiomatic_page=' . $curent_page, 'aiomatic_page=' . $max_pages, $last_url);
                }
                else
                {
                    if(stristr($last_url, '?') === false)
                    {
                        $last_url .= '?aiomatic_page=' . $max_pages;
                    }
                    else
                    {
                        $last_url .= '&aiomatic_page=' . $max_pages;
                    }
                }
            }
            if(isset($_GET['aiomatic_page']))
            {
                $this_page = $_GET["aiomatic_page"];
            }
            else
            {
                $this_page = '1';
            }
            echo '<center><a href="' . esc_url_raw($first_url) . '">' . esc_html__('First Page', 'aiomatic-automatic-ai-content-writer') . '</a>&nbsp;&nbsp;&nbsp;<a href="' . esc_url_raw($prev_url) . '">' . esc_html__('Previous Page', 'aiomatic-automatic-ai-content-writer') . '</a>&nbsp;&nbsp;' . esc_html__('Page', 'aiomatic-automatic-ai-content-writer') . ' ' . esc_html($this_page) . ' ' . esc_html__('of', 'aiomatic-automatic-ai-content-writer') . ' ' . esc_html($max_pages) . '&nbsp;-&nbsp;' . esc_html__("Rules Per Page:", 'aiomatic-automatic-ai-content-writer') . '&nbsp;&nbsp;<input class="cr_50" type="number" min="2" step="1" max="999" name="posts_per_page" value="' . esc_attr($rules_per_page). '" required/>&nbsp;&nbsp;&nbsp;<a href="' . esc_url_raw($next_url) . '">' . esc_html__('Next Page', 'aiomatic-automatic-ai-content-writer') . '</a>&nbsp;&nbsp;&nbsp;<a href="' . esc_url_raw($last_url) . '">' . esc_html__('Last Page', 'aiomatic-automatic-ai-content-writer') . '</a></center>
            <center></center>
            <center>Info: You can add new rules only on the last page.</center>';
            ?> 
         <div>
            <p class="crsubmit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="<?php echo esc_html__("Save Settings", 'aiomatic-automatic-ai-content-writer');?>"/></p>
         </div>
         <hr/>
      </form>
   </div>
    <div id="running_status_ai"></div>
</div>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
<div class="wrap">
        <h3><?php echo esc_html__("Keywords/Titles To Forum Replies Tutorial Video", 'aiomatic-automatic-ai-content-writer');?></h3>
        <div id="ai-video-container"><br/>
            <iframe class="ai-video" width="560" height="315" src="https://www.youtube.com/embed/OEz9FSWSONQ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
<?php
   }
}
   if (isset($_POST['aiomatic_reply_list'])) {
       add_action('admin_init', 'aiomatic_save_rules_reply');
   }
   
   function aiomatic_save_rules_reply($data2)
   {
       $init_rules_per_page = get_option('aiomatic_posts_per_page', 12);
       $rules_per_page = get_option('aiomatic_posts_per_page', 12);
       if(isset($_POST['posts_per_page']))
       {
           aiomatic_update_option('aiomatic_posts_per_page', $_POST['posts_per_page']);
       }
       check_admin_referer('aiomatic_save_rules', '_aiomaticr_nonce');
       
       $data2 = $_POST['aiomatic_reply_list'];
       $rules = get_option('aiomatic_reply_list', array());
       if(!is_array($rules))
       {
          $rules = array();
       }
       $initial_count = count($rules);
       $add = false;
       $scad = false;
       if(isset($_GET["aiomatic_page"]) && is_numeric($_GET["aiomatic_page"]))
       {
           $curent_page = $_GET["aiomatic_page"];
       }
       else
       {
           $curent_page = 1;
       }
       $offset = ($curent_page - 1) * $rules_per_page;
       $cat_cont = $offset;
       $cont  = 0;
       if (isset($data2['post_title'][0])) {
           for ($i = 0; $i < sizeof($data2['post_title']); ++$i) 
           {
               $bundle = array();
               if (isset($data2['schedule'][$i]) && $data2['schedule'][$i] != '' && $data2['post_title'][$i] != '' && $data2['selected_forum'][$i] != '') {
                   $bundle[] = trim(sanitize_text_field($data2['schedule'][$i]));
                   if (isset($data2['active'][$i])) {
                       $bundle[] = trim(sanitize_text_field($data2['active'][$i]));
                   } else {
                       $bundle[] = '0';
                   }
                   $bundle[]     = trim(sanitize_text_field($data2['last_run'][$i]));
                   $bundle[]     = trim(sanitize_text_field($data2['max'][$i]));
                   $bundle[]     = $data2['post_title'][$i];
                   $bundle[]     = trim($data2['temperature'][$i]);
                   $bundle[]     = trim($data2['top_p'][$i]);
                   $bundle[]     = trim($data2['presence_penalty'][$i]);
                   $bundle[]     = trim($data2['frequency_penalty'][$i]);
                   $bundle[]     = trim($data2['max_tokens'][$i]);
                   $bundle[]     = trim($data2['max_seed_tokens'][$i]);
                   $bundle[]     = trim($data2['post_prepend'][$i]);
                   $bundle[]     = trim($data2['post_append'][$i]);
                   $bundle[]     = trim($data2['skip_spin'][$i]);
                   $bundle[]     = trim($data2['skip_translate'][$i]);
                   $bundle[]     = trim($data2['selected_forum'][$i]);
                   $bundle[]     = trim($data2['rule_description'][$i]);
                   $bundle[]     = trim($data2['custom_shortcodes'][$i]);
                   $bundle[]     = trim($data2['strip_by_regex'][$i]);
                   $bundle[]     = trim($data2['replace_regex'][$i]);
                   $bundle[]     = trim($data2['global_prepend'][$i]);
                   $bundle[]     = trim($data2['global_append'][$i]);
                   $bundle[]     = trim($data2['rule_unique_id'][$i]);
                   $bundle[]     = isset($data2['assistant_id'][$i]) ? trim($data2['assistant_id'][$i]) : '';
                   $bundle[]     = trim($data2['reply_count'][$i]);
                   $bundle[]     = trim($data2['reply_model'][$i]);
                   $bundle[]     = trim($data2['choose_prompt'][$i]);
                   $bundle[]     = trim($data2['reply_prompt'][$i]);
                   $bundle[]     = trim($data2['content_language'][$i]);
                   $bundle[]     = trim($data2['writing_style'][$i]);
                   $bundle[]     = trim($data2['writing_tone'][$i]);
                   $bundle[]     = trim($data2['more_replies'][$i]);
                   $bundle[]     = trim($data2['user_role'][$i]);
                   $rules[$offset + $cont] = $bundle;
                   $cont++;
                   $cat_cont++;
               }
           }
           while($cont < $init_rules_per_page)
           {
               if(isset($rules[$offset + $cont]))
               {
                   $rules[$offset + $cont] = false;
               }
               $cont = $cont + 1;
               $cat_cont++;
           }
           $rules = array_values(array_filter($rules));
       }
       else
       {
           $rules = array();
       }
       $final_count = count($rules);
       if($final_count > $initial_count)
       {
           $add = true;
       }
       elseif($final_count < $initial_count)
       {
           $scad = true;
       }
       aiomatic_update_option('aiomatic_reply_list', $rules, false);
       if(count($rules) % $rules_per_page === 1 && $add === true)
       {
           $rules_count = count($rules);
           $max_pages = ceil($rules_count/$rules_per_page);
           if($max_pages == 0)
           {
               $max_pages = 1;
           }
           $last_url = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
           if(stristr($last_url, 'aiomatic_page=') === false)
           {
               if(stristr($last_url, '?') === false)
               {
                   $last_url .= '?aiomatic_page=' . $max_pages;
               }
               else
               {
                   $last_url .= '&aiomatic_page=' . $max_pages;
               }
           }
           else
           {
               if(isset($_GET['aiomatic_page']))
               {
                   $curent_page = $_GET["aiomatic_page"];
               }
               else
               {
                   $curent_page = '';
               }
               if(is_numeric($curent_page))
               {
                   $last_url = str_replace('aiomatic_page=' . $curent_page, 'aiomatic_page=' . $max_pages, $last_url);
               }
               else
               {
                   if(stristr($last_url, '?') === false)
                   {
                       $last_url .= '?aiomatic_page=' . $max_pages;
                   }
                   else
                   {
                       $last_url .= '&aiomatic_page=' . $max_pages;
                   }
               }
           }
           aiomatic_redirect($last_url);
       }
       elseif(count($rules) != 0 && count($rules) % $rules_per_page === 0 && $scad === true)
       {
           $rules_count = count($rules);
           $max_pages = ceil($rules_count/$rules_per_page);
           if($max_pages == 0)
           {
               $max_pages = 1;
           }
           $last_url = (aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
           if(stristr($last_url, 'aiomatic_page=') === false)
           {
               if(stristr($last_url, '?') === false)
               {
                   $last_url .= '?aiomatic_page=' . $max_pages;
               }
               else
               {
                   $last_url .= '&aiomatic_page=' . $max_pages;
               }
           }
           else
           {
               if(isset($_GET['aiomatic_page']))
               {
                   $curent_page = $_GET["aiomatic_page"];
               }
               else
               {
                   $curent_page = '';
               }
               if(is_numeric($curent_page))
               {
                   $last_url = str_replace('aiomatic_page=' . $curent_page, 'aiomatic_page=' . $max_pages, $last_url);
               }
               else
               {
                   if(stristr($last_url, '?') === false)
                   {
                       $last_url .= '?aiomatic_page=' . $max_pages;
                   }
                   else
                   {
                       $last_url .= '&aiomatic_page=' . $max_pages;
                   }
               }
           }
           aiomatic_redirect($last_url);
       }
   }
   function aiomatic_expand_reply_manual($aiomatic_Main_Settings, $forums, $forum_hierarchy)
   {
       $all_models = aiomatic_get_all_models(true);
       $all_assistants = aiomatic_get_all_assistants(true);
       if (!get_option('aiomatic_running_list')) {
           $running = array();
       } else {
           $running = get_option('aiomatic_running_list');
       }
       $GLOBALS['wp_object_cache']->delete('aiomatic_reply_list', 'options');
       $rules  = get_option('aiomatic_reply_list');
       if(!is_array($rules))
       {
         $rules = array();
       }
       $output = '';
       $cont   = 0;
       if (!empty($rules)) {
            if(isset($_GET["aiomatic_page"]) && is_numeric($_GET["aiomatic_page"]))
            {
               $curent_page = $_GET["aiomatic_page"];
            }
            else
            {
               $curent_page = 1;
            }
            $unlocker = get_option('aiomatic_minute_running_unlocked', false);
            $rules_per_page = get_option('aiomatic_posts_per_page', 12);
            foreach ($rules as $request => $bundle[]) {
               if(($cont < ($curent_page - 1) * $rules_per_page) || ($cont >= $curent_page * $rules_per_page))
               {
                  $cont++;
                  continue;
               }
               $bundle_values          = array_values($bundle);
               $myValues               = $bundle_values[$cont];
               $array_my_values        = array_values($myValues);for($iji=0;$iji<count($array_my_values);++$iji){if(is_string($array_my_values[$iji])){$array_my_values[$iji]=stripslashes($array_my_values[$iji]);}}
               $schedule               = $array_my_values[0];
               $active                 = $array_my_values[1];
               $last_run               = $array_my_values[2];
               $max                    = $array_my_values[3];
               $post_title             = $array_my_values[4];
               $temperature            = $array_my_values[5];
               $top_p                  = $array_my_values[6];
               $presence_penalty       = $array_my_values[7];
               $frequency_penalty      = $array_my_values[8];
               $max_tokens             = $array_my_values[9];
               $max_seed_tokens        = $array_my_values[10];
               $post_prepend           = $array_my_values[11];
               $post_append            = $array_my_values[12];
               $skip_spin              = $array_my_values[13];
               $skip_translate         = $array_my_values[14];
               $selected_forum         = $array_my_values[15];
               $rule_description       = $array_my_values[16];
               $custom_shortcodes      = $array_my_values[17];
               $strip_by_regex         = $array_my_values[18];
               $replace_regex          = $array_my_values[19];
               $global_prepend         = $array_my_values[20];
               $global_append          = $array_my_values[21];
               $rule_unique_id         = $array_my_values[22];
               $assistant_id           = $array_my_values[23];
               $reply_count            = $array_my_values[24];
               $reply_model            = $array_my_values[25];
               $choose_prompt          = $array_my_values[26];
               $reply_prompt           = $array_my_values[27];
               $content_language       = $array_my_values[28];
               $writing_style          = $array_my_values[29];
               $writing_tone           = $array_my_values[30];
               $more_replies           = $array_my_values[31];
               $user_role              = $array_my_values[32];
               if(empty($rule_unique_id))
               {
                  $rule_unique_id = $cont;
               }
               if($rule_description == '')
               {
                  $rule_description = $cont;
               }
               $name = md5(get_bloginfo());
               wp_add_inline_script($name . '-footer-script', 'createAdmin(' . esc_html($cont) . ');createModeSelect(' . esc_html($cont) . ');hideLinks(' . esc_html($cont) . ');', 'after');
               $output .= '<tr>
               <td class="cr_short_td">
    <input type="checkbox"
 class="aiomatic_rule_select"
 data-ruleid="' . esc_attr($cont) . '"
 data-type="8"
 data-unique="' . esc_attr($rule_unique_id) . '"
 value="' . esc_attr($rule_unique_id) . '">
</td>
                           <td class="cr_short_td"><input type="text" name="aiomatic_reply_list[rule_description][]" id="rule_description' . esc_html($cont) . '" class="cr_center" placeholder="Rule ID" value="' . esc_html($rule_description) . '" class="cr_width_full"/></td>
                           <td class="cr_width_80 cr_center">
                           <select autocomplete="off" id="selected_forum' . esc_html($cont) . '"  name="aiomatic_reply_list[selected_forum][]" class="cr_width_full">';
if (!empty($forums)) {
   $output .= '<option value="" disabled>' . esc_html__("Select a Forum", 'aiomatic-automatic-ai-content-writer') . '</option>';
   $output .= aiomatic_render_forum_options($forums, $forum_hierarchy, $selected_forum);
} else {
   $output .= '<option value="">' . esc_html__("No forums available", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
                              
               $output .= '</select>
                           </td>
                           <td class="cr_loi">
                           <select autocomplete="off" id="post_title" name="aiomatic_reply_list[post_title][]" class="cr_width_full">
                                 <option value="auto_grow"'; if($post_title == 'auto_grow'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Grow (Spawns new replies in quiet topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_unaswered"'; if($post_title == 'auto_unaswered'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Unanswered (Replies to unanswered topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_random"'; if($post_title == 'auto_random'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Random (Replies to random topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_latest"'; if($post_title == 'auto_latest'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Latest (Replies to latest topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_oldest"'; if($post_title == 'auto_oldest'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Oldest (Replies to oldest topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_popular"'; if($post_title == 'auto_popular'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Most Popular (Replies to most popular topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_least_popular"'; if($post_title == 'auto_least_popular'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Least Popular (Replies to least popular topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_most_replied"'; if($post_title == 'auto_most_replied'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Most Replied (Replies to most replied topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_least_replied"'; if($post_title == 'auto_least_replied'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Least Replied (Replies to least replied topics)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_oldest_no_replies"'; if($post_title == 'auto_oldest_no_replies'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Oldest No Replies (Replies to oldest topics with no replies)", 'aiomatic-automatic-ai-content-writer') . '</option>
                                 <option value="auto_latest_no_replies"'; if($post_title == 'auto_latest_no_replies'){$output .=  ' selected';} $output .= '>' . esc_html__("Auto Latest No Replies (Replies to latest topics with no replies)", 'aiomatic-automatic-ai-content-writer') . '</option>
                              </select>
                           </td>
                           <td class="cr_comm_td"><input type="number" step="1" min="1" placeholder="# h" name="aiomatic_reply_list[schedule][]" max="8765812" value="' . esc_attr($schedule) . '" class="cr_width_60" required></td>
                           <td class="cr_comm_td"><input type="number" step="1" min="0" placeholder="#" name="aiomatic_reply_list[max][]" value="' . esc_attr($max) . '"  class="cr_width_60" required></td>
                       <td class="cr_width_70 cr_center">
                       <input type="button" id="mybtnfzr' . esc_html($cont) . '" class="button" value="Settings">
                       <div id="mymodalfzr' . esc_html($cont) . '" class="codemodalfzr">
     <div class="codemodalfzr-content">
       <div class="codemodalfzr-header">
         <span id="aiomatic_close' . esc_html($cont) . '" class="codeclosefzr">&times;</span>
         <h2>' . esc_html__('Rule', 'aiomatic-automatic-ai-content-writer') . ' <span class="cr_color_white">ID ' . esc_html($cont) . '</span> ' . esc_html__('Advanced Settings', 'aiomatic-automatic-ai-content-writer') . '</h2>
       </div>
       <div class="codemodalfzr-body">
       <div class="table-responsive">
         <table class="responsive table cr_main_table_nowr"><tr><td colspan="2"><h3>' . esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer') . ':</h3>
         </td></tr><tr>
         <td class="cr_min_width_200">
               <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                  <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer') . '</div>
               </div>
               <b>' . esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer') . '</b>
         </td>
         <td><select id="assistant_id' . esc_html($cont) . '" name="aiomatic_reply_list[assistant_id][]" class="cr_width_full" onchange="assistantSelected(\'' . esc_html($cont) . '\');">';
if($all_assistants === false)
{
   $output .= '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
if(count($all_assistants) == 0)
{
   $output .= '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
   $output .= '<option value=""';
   if($assistant_id == ''){$output .= ' selected';}
$output .= '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
foreach($all_assistants as $myassistant)
{
   $output .= '<option value="' . esc_html($myassistant->ID) .'"';
   if($assistant_id == $myassistant->ID){$output .= ' selected';}
   $output .= '>' . esc_html($myassistant->post_title);
$output .= '</option>';
}
}
}
$output .= '</select>  
         </td>
      </tr>
         <tr><td colspan="2"><h3>' . esc_html__('Reply Options', 'aiomatic-automatic-ai-content-writer') . ':</h3></td></tr>
         <tr><td class="cr_min_width_200">
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the number of automatic replies to add to created topics. You can also define custom ranges, like: 3-5. To disable this feature, leave it blank.", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("Reply Count To Add To The Topic", 'aiomatic-automatic-ai-content-writer') . ':</b>
                       </td><td>
                       <input type="text" name="aiomatic_reply_list[reply_count][]" placeholder="Add the number of replies to create" class="cr_width_full" value="' . esc_attr($reply_count) . '">
           </div>
           </td></tr><tr><td class="cr_min_width_200">
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the maximum number of replies a topic can have, when it will still be processed.", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("Maximum Reply Count For Topics", 'aiomatic-automatic-ai-content-writer') . ':</b>
                       </td><td>
                       <input type="text" name="aiomatic_reply_list[more_replies][]" placeholder="Don\'t process if it has more replies than" class="cr_width_full" value="' . esc_attr($more_replies) . '">
           </div>
           </td></tr>
         <tr><td>
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Select the AI Model to be used for the reply generator.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("AI Model For The AI Reply Generator", 'aiomatic-automatic-ai-content-writer') . ':</b>   
                     </td><td class="cr_min_width_200">
                     <select autocomplete="off" name="aiomatic_reply_list[reply_model][]" class="hideAssistant' . esc_html($cont) . ' cr_width_full">';
if(empty($reply_model))
{
   $reply_model = AIMOGEN_DEFAULT_MODEL;
}
foreach($all_models as $modelx)
{
   $output .= '<option value="' . esc_html($modelx) .'"';
   if ($reply_model == $modelx) 
   {
      $output .= " selected";
   }
   else
   {
      $output .= (($assistant_id != '') ? ' disabled ' : '');
   }
   $output .= '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}                                  
            $output .= '</select>
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the prompt to use for the user selector for the replies. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%participant_list%%, %%conversation%%, %%post_title%%, %%random_sentence%%, %%post_original_title%%, %%random_sentence2%%, %%blog_title%%. You can also add a link to a TXT file, containing keywords (one per line), or to an RSS feed. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/' ) . '
                         </div>
                     </div>
                     <b>' . esc_html__("Prompt For The AI Topic Reply User Selector", 'aiomatic-automatic-ai-content-writer') . ':</b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/" target="_blank">&#9432;</a></b>
                     
                     </td><td>
                     <textarea rows="4" cols="70" name="aiomatic_reply_list[choose_prompt][]" placeholder="Please insert a command for the AI" class="cr_width_full">' . esc_textarea($choose_prompt) . '</textarea>
                         
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the prompt to use for the reply content generator. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%reply_user_name%%, %%participant_list%%, %%conversation%%, %%post_title%%, %%random_sentence%%, %%post_original_title%%, %%random_sentence2%%, %%blog_title%%. You can also add a link to a TXT file, containing keywords (one per line), or to an RSS feed. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/' ) . '
                         </div>
                     </div>
                     <b>' . esc_html__("Prompt For The AI Topic Reply Generator", 'aiomatic-automatic-ai-content-writer') . ':</b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/" target="_blank">&#9432;</a></b>
                     
                     </td><td>
                     <textarea rows="4" cols="70" name="aiomatic_reply_list[reply_prompt][]" placeholder="Please insert a command for the AI" class="cr_width_full">' . esc_textarea($reply_prompt) . '</textarea>
                         
         </div>
         </td></tr><tr><td>
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Select the user role from where random users will be selected.", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("User Role For Random User Selection", 'aiomatic-automatic-ai-content-writer') . ':</b>   
                       </td><td class="cr_min_width_200">
                       <select autocomplete="off" id="user_role' . esc_html($cont) . '" name="aiomatic_reply_list[user_role][]" class="cr_width_full">';
                       $output .= '<option value="any"';
                       if ($user_role == "any") {
                               $output .= " selected";
                           }
                       $output .= '>' . esc_html__("Any", 'aiomatic-automatic-ai-content-writer') . '</option>';
        global $wp_roles;
        $roles = $wp_roles->roles;
        foreach ($roles as $role_key => $role) {
            $output .= '<option value="' . esc_attr($role_key) . '"';
            if ($user_role == $role_key) {
               $output .= " selected";
            }
            $output .= '>' . esc_html($role['name']) . '</option>';
        }
               $output .= '</select>  
           </div>
           </td></tr>
         <tr><td colspan="2"><h2>' . esc_html__('Content Parameters', 'aiomatic-automatic-ai-content-writer') . ':</h2></td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the language of the created content. This will set the value of the %%language%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("Content Language", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     
                     </td><td>
                     <input id="content_language' . esc_html($cont) . '" name="aiomatic_reply_list[content_language][]" type="text" list="languages" placeholder="Created content language" class="coderevolution_gutenberg_input" value="' . esc_attr($content_language) . '"/>                         
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the writing style of the created content. This will set the value of the %%writing_style%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("Writing Style", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     
                     </td><td>
                     <input id="writing_style' . esc_html($cont) . '" name="aiomatic_reply_list[writing_style][]" type="text" list="writing_styles" placeholder="Created content writing style" class="coderevolution_gutenberg_input" value="' . esc_attr($writing_style) . '"/>                         
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the writing tone of the created content. This will set the value of the %%writing_tone%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("Writing Tone", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     
                     </td><td>
                     <input id="writing_tone' . esc_html($cont) . '" name="aiomatic_reply_list[writing_tone][]" type="text" list="writing_tones" placeholder="Created content writing tone" class="coderevolution_gutenberg_input" value="' . esc_attr($writing_tone) . '"/>                         
         </div>
         </td></tr>
         <tr><td colspan="2"><h3>' . esc_html__('Global Prompt Options', 'aiomatic-automatic-ai-content-writer') . ':</h3></td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%%, %%royalty_free_image_attribution%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("Prepend Text To All Textual AI Prompts", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     
                     </td><td>
                     <textarea rows="2" cols="70" name="aiomatic_reply_list[global_prepend][]" placeholder="Global prompt prepend text" class="cr_width_full">' . esc_textarea($global_prepend) . '</textarea>
                         
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%%, %%royalty_free_image_attribution%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("Append Text To All Textual AI Prompts", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     
                     </td><td>
                     <textarea rows="2" cols="70" name="aiomatic_reply_list[global_append][]" placeholder="Global prompt append text" class="cr_width_full">' . esc_textarea($global_append) . '</textarea>
                         
         </div>
         </td></tr>
         <tr><td colspan="2"><h3>' . esc_html__('Advanced AI Text Generator Options', 'aiomatic-automatic-ai-content-writer') . ':</h3></td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("Maximum Total Token Count To Use Per API Request", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     </td><td>
                     <input type="number" min="1" name="aiomatic_reply_list[max_tokens][]" value="' . esc_attr($max_tokens) . '" placeholder="32768" class="cr_width_full">
                         
         </div>
         </td></tr><tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("Maximum Prompt Token Count To Use Per API Request", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     </td><td>
                     <input type="number" min="1" name="aiomatic_reply_list[max_seed_tokens][]" value="' . esc_attr($max_seed_tokens) . '" placeholder="1000" class="cr_width_full">
                         
         </div>
         </td></tr><tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("AI Temperature", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     </td><td>
                     <input type="number" min="0" step="0.01" max="2" name="aiomatic_reply_list[temperature][]" value="' . esc_attr($temperature) . '" placeholder="1" class="cr_width_full">
                         
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("AI Top_p", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     </td><td>
                     <input type="number" min="0" step="0.01" max="1" name="aiomatic_reply_list[top_p][]" value="' . esc_attr($top_p) . '" placeholder="1" class="cr_width_full">
                         
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("AI Presence Penalty", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     </td><td>
                     <input type="number" min="-2" max="2" step="0.01" name="aiomatic_reply_list[presence_penalty][]" value="' . esc_attr($presence_penalty) . '" placeholder="0" class="cr_width_full">
                         
         </div>
         </td></tr>
         <tr><td class="cr_min_width_200">
         <div>
         <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                         <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer') . '
                         </div>
                     </div>
                     <b>' . esc_html__("AI Frequency Penalty", 'aiomatic-automatic-ai-content-writer') . ':</b>
                     </td><td>
                     <input type="number" min="-2" step="0.01" max="2" name="aiomatic_reply_list[frequency_penalty][]" value="' . esc_attr($frequency_penalty) . '" placeholder="0" class="cr_width_full">
                         
         </div>
         </td></tr>
         <tr><td colspan="2"><h3>' . esc_html__('Posting Options', 'aiomatic-automatic-ai-content-writer') . ':</h3></td></tr>
           <tr><td class="cr_min_width_200">
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("HTML Text To Prepend To AI Created Content", 'aiomatic-automatic-ai-content-writer') . ':</b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                       </td><td>
                       <textarea rows="2" cols="70" name="aiomatic_reply_list[post_prepend][]" placeholder="HTML content to prepend to the AI generated content" class="cr_width_full">' . esc_textarea($post_prepend) . '</textarea>
           </div>
           </td></tr><tr><td class="cr_min_width_200">
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Enter a HTML text that should be append to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("HTML Text To Append To AI Created Content", 'aiomatic-automatic-ai-content-writer') . ':</b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                       </td><td>
                       <textarea rows="2" cols="70" name="aiomatic_reply_list[post_append][]" placeholder="HTML content to append to the AI generated content" class="cr_width_full">' . esc_textarea($post_append) . '</textarea>
           </div>
           </td></tr><tr><td class="cr_min_width_200">
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-4.1-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("Custom Shortcode Creator (Optional)", 'aiomatic-automatic-ai-content-writer') . ':</b><span class="tool" data-tip="Supported models: ' . implode(',', aiomatic_get_all_models()) . '">&nbsp;&#9432;</span>
                       </td><td>
                       <textarea rows="2" cols="70" name="aiomatic_reply_list[custom_shortcodes][]" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="cr_width_full">' . esc_textarea($custom_shortcodes) . '</textarea>
           </div>
           </td></tr><tr><td>
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("Do Not Spin Topics Generated By This Rule", 'aiomatic-automatic-ai-content-writer') . ':</b>
                       
                       </td><td>
                       <input type="checkbox" id="skip_spin' . esc_html($cont) . '" name="aiomatic_reply_list[skip_spin][]"';
           if($skip_spin == '1')
           {
               $output .= ' checked';
           }
           $output .= '>               
           </div>
           </td></tr><tr><td>
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("Do Not Translate Topics Generated By This Rule", 'aiomatic-automatic-ai-content-writer') . ':</b>
                       
                       </td><td>
                       <input type="checkbox" id="skip_translate' . esc_html($cont) . '" name="aiomatic_reply_list[skip_translate][]"';
           if($skip_translate == '1')
           {
               $output .= ' checked';
           }
           $output .= '>               
           </div>
           </td></tr><tr><td>
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("Run Regex On Content", 'aiomatic-automatic-ai-content-writer') . ':</b>
                       
                       </td><td>
                       <textarea rows="1" class="cr_width_full" name="aiomatic_reply_list[strip_by_regex][]" placeholder="regex" class="cr_width_full">' . esc_textarea($strip_by_regex) . '</textarea>
                           
           </div>
           </td></tr><tr><td>
           <div>
           <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                           <div class="bws_hidden_help_text cr_min_260px">' . esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer') . '
                           </div>
                       </div>
                       <b>' . esc_html__("Replace Matches From Regex (Content)", 'aiomatic-automatic-ai-content-writer') . ':</b>
                       
                       </td><td>
                       <textarea rows="1" class="cr_width_full" name="aiomatic_reply_list[replace_regex][]" placeholder="regex replacement" class="cr_width_full">' . esc_textarea($replace_regex) . '</textarea>
                           
           </div>
           </td></tr>
         </table></div> 
       </div>
       <div class="codemodalfzr-footer">
         <br/>
         <h3 class="cr_inline">Aimogen Automatic Post Generator</h3><span id="aiomatic_ok' . esc_html($cont) . '" class="codeokfzr cr_inline">OK&nbsp;</span>
         <br/><br/>
       </div>
     </div>
   
   </div>       
                       </td>
   						<td class="cr_shrt_td2"><span class="wpaiomatic-delete">X</span></td>
                           <td class="cr_short_td"><input type="checkbox" name="aiomatic_reply_list[active][]" class="activateDeactivateClass" value="1"';
               if (isset($active) && $active === '1') {
                   $output .= ' checked';
               }
               $output .= '/>
                           <input type="hidden" name="aiomatic_reply_list[last_run][]" value="' . esc_attr($last_run) . '"/>
                           <input type="hidden" name="aiomatic_reply_list[rule_unique_id][]" value="' . esc_attr($rule_unique_id) . '"/></td>
                           <td class="cr_shrt_td2"><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                           <div class="bws_hidden_help_text cr_min_260px">' . sprintf( wp_kses( __( 'Shortcode for this rule<br/>(to cross-post from this plugin in other plugins):', 'aiomatic-automatic-ai-content-writer'), array(  'br' => array( ) ) ) ) . '<br/><b>%%aiomatic_7_' . esc_html($cont) . '%% and %%aiomatic_title_7_' . esc_html($cont) . '%%</b><br/>';
               $output .= esc_html__('Last Run: ', 'aiomatic-automatic-ai-content-writer');
               if ($last_run == '1988-01-27 00:00:00') {
                   $output .= 'Never';
               } else {
                   $output .= $last_run;
               }
               $output .= '<br/>' . esc_html__('Next Run: ', 'aiomatic-automatic-ai-content-writer');
               if($unlocker == '1')
               {
                   $nextrun = aiomatic_add_minute($last_run, $schedule);
               }
               else
               {
                   $nextrun = aiomatic_add_hour($last_run, $schedule);
               }
               $now     = aiomatic_get_date_now();
               if (isset($active) && $active === '1') {
                  if($unlocker == '1')
                  {
                     $aiomatic_hour_diff = (int)aiomatic_minute_diff($now, $nextrun);
                  }
                  else
                  {
                     $aiomatic_hour_diff = (int)aiomatic_hour_diff($now, $nextrun);
                  }
                   if ($aiomatic_hour_diff >= 0) {
                     if($unlocker == '1')
                     {
                         $append = 'Now.';
                     }
                     else
                     {
                         $append = 'Now.';
                     }
                       $cron   = _get_cron_array();
                       if ($cron != FALSE) {
                           $date_format = _x('Y-m-d H:i:s', 'Date Time Format1', 'aiomatic-automatic-ai-content-writer');
                           foreach ($cron as $timestamp => $cronhooks) {
                               foreach ((array) $cronhooks as $hook => $events) {
                                   if ($hook == 'aiomaticaction') {
                                       foreach ((array) $events as $key => $event) {
                                           $append = date_i18n($date_format, $timestamp);
                                       }
                                   }
                               }
                           }
                       }
                       $output .= $append;
                   } else {
                       $output .= $nextrun;
                   }
               } else {
                  $output .= esc_html__('Rule Disabled', 'aiomatic-automatic-ai-content-writer');
               }
               $output .= '<br/>' . esc_html__('Local Time: ', 'aiomatic-automatic-ai-content-writer') . $now;
               if(isset($aiomatic_Main_Settings['rule_webhook']) && $aiomatic_Main_Settings['rule_webhook'] == 'on')
               {
                  $attsx = array();
                  $attsx['secret'] = aiomatic_generate_site_secret();
                  $attsx['ruleid'] = $cont;
                  $attsx['ruletype'] = '8';
                  $queryParams = http_build_query($attsx);
                  $webhookUrl = esc_url(get_site_url() . '/wp-json/aiomatic/v1/rules?' . $queryParams);
                  $webhookUrl = '<a href="' . $webhookUrl . '" target="_blank">' . $webhookUrl . '</a>';
                  $output .= '<br/>' . esc_html__('Webhook To Run Rule: ', 'aiomatic-automatic-ai-content-writer') . '<br/>' . $webhookUrl;
               }
               $output .= '</div>
                       </div></td>
                           <td class="cr_center">
                           <div>
                           <img id="run_img' . esc_html($cont) . '" src="' . plugin_dir_url(dirname(__FILE__)) . 'images/running.gif' . '" alt="Running" class="cr_status_icon';
               if (!empty($running)) {
                  if (!in_array(array($cont => 8), $running)) {
                        $f = fopen(get_temp_dir() . 'aiomatic_8_' . $cont, 'w');
                        if($f !== false)
                        {
                           flock($f, LOCK_UN);
                           fclose($f);
                           global $wp_filesystem;
                           if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
                                 include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
                                 wp_filesystem($creds);
                           }
                           $wp_filesystem->delete(get_temp_dir() . 'aiomatic_8_' . $cont);
                        }
                        $output .= ' cr_hidden';
                   }
                   else
                   {
                       $f = fopen(get_temp_dir() . 'aiomatic_8_' . $cont, 'w');
                       if($f !== false)
                       {
                           if (!flock($f, LOCK_EX | LOCK_NB)) {
                           }
                           else
                           {
                               $output .= ' cr_hidden';
                               flock($f, LOCK_UN);
                               if (($xxkey = array_search(array($cont => 8), $running)) !== false) {
                                   unset($running[$xxkey]);
                                   aiomatic_update_option('aiomatic_running_list', $running);
                               }
                           }
                       }
                   }
               } 
               else 
               {
                  $f = fopen(get_temp_dir() . 'aiomatic_8_' . $cont, 'w');
                  if($f !== false)
                  {
                     flock($f, LOCK_UN);
                     fclose($f);
                     global $wp_filesystem;
                     if ( ! is_a( $wp_filesystem, 'WP_Filesystem_Base') ){
                        include_once(ABSPATH . 'wp-admin/includes/file.php');$creds = request_filesystem_credentials( site_url() );
                        wp_filesystem($creds);
                     }
                     $wp_filesystem->delete(get_temp_dir() . 'aiomatic_8_' . $cont);
                  }
                  $output .= ' cr_hidden';
               }
               $output .= '" title="status">
                           <div class="codemainfzr cr_width_80p">
                           <select autocomplete="off" class="codemainfzr" id="actions' . esc_html($cont) . '" class="actions" name="actions" onchange="actionsChangedManual(' . esc_html($cont) . ', this.value, 8, \'' . esc_html($rule_unique_id) . '\');" onfocus="this.selectedIndex = 0;">
                               <option value="select" disabled selected>' . esc_html__("Select an Action", 'aiomatic-automatic-ai-content-writer') . '</option>
                               <option value="run">' . esc_html__("Run This Rule Now", 'aiomatic-automatic-ai-content-writer') . '</option>
                               <option value="duplicate">' . esc_html__("Duplicate This Rule", 'aiomatic-automatic-ai-content-writer') . '</option>
                               <option value="up">' . esc_html__("Move This Rule Up", 'aiomatic-automatic-ai-content-writer') . '</option>
                               <option value="down">' . esc_html__("Move This Rule Down", 'aiomatic-automatic-ai-content-writer') . '</option>
                           </select>
                           </div>
                           </div>
                           </td>
   					</tr>	
   					';
               $cont = $cont + 1;
           }
       }
       return $output;
   }
   ?>